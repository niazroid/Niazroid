'use strict';
// Dedicated Watch Party session. Normal MPV launch never enters this module.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
function mediaUrl(value){try{const raw=String(value||'');const u=new URL(raw);if(!['http:','https:'].includes(u.protocol)||u.username||u.password||/[\x00-\x20]/.test(raw))return '';const h=u.hostname.toLowerCase();if(h==='localhost'||h.endsWith('.localhost')||h.endsWith('.local')||h.startsWith('[')||/^(?:0|10|127|169\.254|192\.168|172\.(?:1[6-9]|2[0-9]|3[01]))(?:\.|$)/.test(h))return '';return raw;}catch{return '';}}
function roomCode(value){let s=String(value||'').trim();if(/^https?:\/\//i.test(s)){try{s=new URL(s).searchParams.get('room')||''}catch{return ''}}return /^[A-Za-z0-9_-]{24,96}$/.test(s)?s:'';}
const num=(v,d=0)=>Number.isFinite(Number(v))?Number(v):d;
const bounded=(v,min,max,d=min)=>Math.max(min,Math.min(max,num(v,d)));
const str=(v,n=300)=>String(v??'').replace(/[\x00-\x1f\x7f]/g,' ').slice(0,n);
const flag=v=>v===true||v===1||v==='1';
function stateFrom(p){const s=p.state||{},r=p.room||{};let pos=bounded(s.current_time,0,172800);const paused=flag(s.paused),buffering=flag(s.buffering),rate=bounded(s.playback_rate,.5,2,1);if(!paused&&!buffering&&num(s.updated_at_ms)>0)pos+=bounded((num(p.server_time_ms)-num(s.updated_at_ms))/1000,0,30)*rate;return {position:pos,paused,buffering,rate,sequence:num(s.sequence_no),secondsLeft:bounded(r.seconds_left,0,86400),scheduledStart:num(r.scheduled_start_at_ms),serverTime:num(p.server_time_ms)};}
function jsonRead(file,limit=262144){try{if(fs.statSync(file).size>limit)return null;return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}}
function atomic(file,value){const tmp=file+'.tmp';fs.writeFileSync(tmp,JSON.stringify(value),{encoding:'utf8',mode:0o600});try{fs.renameSync(tmp,file)}catch{fs.copyFileSync(tmp,file);fs.unlinkSync(tmp)}}
function classify(prev,next,elapsed){if(!prev)return 'state';if(prev.paused!==next.paused)return next.paused?'pause':'play';if(prev.buffering!==next.buffering)return 'buffering';const expected=prev.position+(prev.paused||prev.buffering?0:elapsed*prev.rate);if(Math.abs(expected-next.position)>2.5)return 'seek';return 'state';}
class WatchParty {
 constructor(deps){this.d=deps;this.active=null;this.starting=false;}
 async start(mode,input={}){if(this.starting||this.active)throw Error('ابتدا اتاق فعلی را ببندید.');this.starting=true;let s;try{
  const status=await this.d.request('watch_party_status',{});if(!status?.enabled)throw Error('تماشای دونفره غیرفعال است.');
  const identity=this.d.identity();const guestToken=identity?'':this.d.guestToken();
  s={identity,guestToken,code:'',role:'guest',dir:null,child:null,closed:false,afterEvent:0,afterMessage:0,messages:[],themes:Array.isArray(status.themes)?status.themes.slice(0,30):[],lastPoll:0,lastControl:0,offset:0,tail:Buffer.alloc(0),serial:0,lastSample:null,lastError:'',lastOk:Date.now(),queue:[],accent:/^#[0-9a-f]{6}$/i.test(input.accent||'')?input.accent:'#327CF6'};
  const req=(a,b)=>this.call(s,a,b);let response;
  if(mode==='create'){
   if(!status.is_logged_in||!status.is_vip)throw Error('ساخت اتاق فقط برای کاربران VIP فعال است.');
   const source=mediaUrl(input.source_url);if(!source)throw Error('لینک پخش معتبر نیست.');
   const archive=Number(input.archive_no);if(!Number.isInteger(archive)||archive<1||archive>5)throw Error('آرشیو معتبر نیست.');
   response=await req('create',{movie_id:Math.max(0,Math.trunc(num(input.movie_id))),archive_no:archive,media_type:['series','episode'].includes(input.media_type)?input.media_type:'movie',source_ref:str(input.source_ref,180),source_url:source,subtitle_url:mediaUrl(input.subtitle_url),content_title:str(input.content_title,240),poster_url:mediaUrl(input.poster_url)});
   s.code=roomCode(response.room?.invite_code);s.role='host';s.joined=true;s.reused=!!response.room?.reused;s.invite=mediaUrl(response.room?.invite_url);
  }else if(mode==='join'){
   if(input.pin){if(!/^\d{4,12}$/.test(String(input.join_code))||!/^\d{3,12}$/.test(String(input.pin)))throw Error('کد یا رمز اتاق معتبر نیست.');response=await req('join_numeric',{join_code:String(input.join_code),pin:String(input.pin)});s.code=roomCode(response.room_code);}
   else {s.code=roomCode(input.room_code);if(!s.code)throw Error('لینک یا کد اتاق معتبر نیست.');response=await req('join',{room_code:s.code});}
   s.role=response.membership?.member_role==='host'?'host':'guest';s.joined=true;
  }else throw Error('درخواست نامعتبر است.');
  if(!s.code)throw Error('کد اتاق از سرور دریافت نشد.');
  const p=await req('poll',{after_event_id:0,after_message_id:0});this.consume(s,p);s.lastPoll=Date.now();if(!s.source)throw Error('لینک پخش اتاق موجود نیست.');
  s.dir=fs.mkdtempSync(path.join(this.d.temp,'bm-watch-party-'));this.write(s);this.active=s;
  s.child=await this.d.launch(s.source,{title:s.title,subtitleUrl:s.subtitle,accent:input.accent,partyDir:s.dir});
  s.child.once('exit',()=>{void this.finish(s,false)});s.child.once('error',()=>{void this.finish(s,false)});
  s.timer=setInterval(()=>void this.tick(s),700);return {ok:true,role:s.role};
 }catch(e){if(s)await this.finish(s,false);throw e;}finally{this.starting=false;}}
 async call(s,action,body={}){if(this.d.identity()!==s.identity)throw Error('نشست حساب تغییر کرده است.');const r=await this.d.request('watch_party_'+action,{...(s.code?{room_code:s.code}:{}),...(s.guestToken?{guest_token:s.guestToken}:{}),...body});if(!r||r.success===false||r.status==='error')throw Error(r?.message||'پاسخ اتاق نامعتبر است.');return r;}
 consume(s,p){const r=p.room||{};s.role=p.member_role==='host'?'host':'guest';s.source=mediaUrl(r.shared_source_url);s.subtitle=mediaUrl(r.shared_subtitle_url);s.title=str(r.content_title,240);s.theme=str(r.theme_key,40);s.chatEnabled=flag(p.chat_enabled??true);s.maxMembers=bounded(r.max_members,2,50,2);s.state=stateFrom(p);s.lastOk=Date.now();s.members=(p.members||[]).slice(0,10).map(m=>({id:num(m.member_id),name:str(m.username,80),role:m.member_role==='host'?'host':'guest',seen:str(m.last_seen_at,30)}));s.kicked=(p.kicked_members||[]).slice(0,10).map(m=>({id:num(m.member_id),name:str(m.member_name,80)}));for(const e of p.events||[])s.afterEvent=Math.max(s.afterEvent,num(e.id));for(const m of p.messages||[]){const id=num(m.id);if(id<=s.afterMessage)continue;s.afterMessage=id;s.messages.push({id,name:str(m.username,80),text:str(m.text??m.message,1000),mine:flag(m.is_mine),delivered:!!m.delivered_at,created:str(m.created_at,30),media:!!m.media});}const delivered=num(p.my_delivered_through_id);for(const m of s.messages)if(m.mine&&m.id<=delivered)m.delivered=true;s.messages=s.messages.slice(-150);}
 write(s){if(!s.dir||s.closed)return;atomic(path.join(s.dir,'state.json'),{serial:++s.serial,role:s.role,title:s.title,source:s.source,subtitle:s.subtitle,theme:s.theme,chatEnabled:s.chatEnabled,ack:s.ack,clock:s.state,connected:Date.now()-s.lastOk<10000,secondsSincePoll:(Date.now()-s.lastOk)/1000,members:s.members,kicked:s.kicked,messages:s.messages.slice(-60),themes:s.themes.map(t=>({key:str(t.key,40),label:str(t.label,60)})),error:s.lastError});}
 async tick(s){if(s.closed||s.busy)return;s.busy=true;try{
  if(this.d.identity()!==s.identity){await this.finish(s,true);return;}
  s.lastError='';await this.commands(s);if(s.closed)return;await this.drain(s);if(s.closed)return;
  const now=Date.now();const sample=jsonRead(path.join(s.dir,'sample.json'),8192);
  if(s.role==='host'&&sample?.ready===true&&now-num(sample.at)>-5000&&now-num(sample.at)<10000){const next={position:bounded(sample.position,0,172800),paused:flag(sample.paused),buffering:flag(sample.buffering),rate:bounded(sample.rate,.5,2,1)};const event=classify(s.lastSample,next,(now-s.lastControl)/1000);if(now-s.lastControl>=3000||event!=='state'){await this.call(s,'control',{event,current_time:next.position,paused:next.paused,buffering:next.buffering,playback_rate:next.rate});s.lastSample=next;s.lastControl=now;}}
  if(now-s.lastPoll>=2000){s.lastPoll=now;const p=await this.call(s,'poll',{after_event_id:s.afterEvent,after_message_id:s.afterMessage});this.consume(s,p);if(!s.source)throw Error('لینک پخش اتاق حذف شده است.');}
 }catch(e){s.lastError=str(e.message,180);if(/اخراج|عضو این اتاق نیست|اتاق پیدا نشد|اتاق در دسترس نیست|زمان اتاق به پایان|HTTP 404|HTTP 403/.test(s.lastError)){try{this.write(s)}catch{}await this.finish(s,true);return;}}finally{if(!s.closed){try{this.write(s)}catch{}}s.busy=false;}}
 async commands(s){const file=path.join(s.dir,'commands.jsonl');let raw;try{if(fs.statSync(file).size>4*1024*1024)throw Error('command limit');raw=fs.readFileSync(file);}catch{return;}const pending=Buffer.concat([s.tail,raw.subarray(s.offset)]);s.offset=raw.length;const last=pending.lastIndexOf(10);if(last<0){s.tail=pending;return;}s.tail=pending.subarray(last+1);const lines=pending.subarray(0,last).toString('utf8').split('\n');for(const line of lines.slice(-40)){if(s.closed)return;let a;try{a=JSON.parse(line)}catch{continue;}try{await this.execute(s,a);if(a.kind==='message'&&/^[0-9]{1,20}-[0-9]{1,10}$/.test(a.requestId||''))s.ack={id:a.requestId,ok:true};}catch(e){s.lastError=str(e.message,180);if(a?.kind==='message'&&/^[0-9]{1,20}-[0-9]{1,10}$/.test(a.requestId||''))s.ack={id:a.requestId,ok:false,error:s.lastError};}}
 }
 snapshot(s){if(!s||s.closed||this.active!==s||this.d.identity()!==s.identity)return null;return {role:s.role,title:s.title,theme:s.theme,accent:s.accent,chatEnabled:s.chatEnabled,connected:Date.now()-s.lastOk<10000,clock:s.state,members:s.members,kicked:s.kicked,messages:s.messages,themes:s.themes.map(t=>({key:str(t.key,40),label:str(t.label,60)})),error:s.lastError,maxMembers:s.maxMembers};}
 enqueue(s,a){if(!s||s.closed||this.active!==s||this.d.identity()!==s.identity)return Promise.reject(Error('اتاق فعال نیست.'));if(!a||typeof a!=='object'||!['message','copy','leave','close','kick','undo_kick','theme','refresh'].includes(a.kind))return Promise.reject(Error('درخواست نامعتبر است.'));if(s.queue.length>=8)return Promise.reject(Error('لطفاً دوباره تلاش کنید.'));return new Promise((resolve,reject)=>s.queue.push({a,resolve,reject}));}
 async drain(s){while(s.queue.length&&!s.closed){const q=s.queue.shift();try{await this.execute(s,q.a);q.resolve({ok:true});}catch(e){s.lastError=str(e.message,180);q.reject(e);}}}
 async execute(s,a){
   if(s.closed||this.d.identity()!==s.identity)throw Error('اتاق فعال نیست.');
   if(a.kind==='message'){
     if(!s.chatEnabled)throw Error('گفتگو غیرفعال است.');const message=str(a.text,500).trim();if(!message)throw Error('پیام خالی است.');
     const requestId=/^[0-9]{1,20}-[0-9]{1,10}$/.test(a.requestId||'')?a.requestId:'';const digest=requestId?crypto.createHash('sha256').update(s.dir+'|'+requestId).digest('hex'):'';const clientId=digest?'win-'+[digest.slice(0,8),digest.slice(8,12),digest.slice(12,16),digest.slice(16,20),digest.slice(20,32)].join('-'):typeof a.clientId==='string'&&/^win-[a-f0-9-]{36}$/i.test(a.clientId)?a.clientId:'win-'+crypto.randomUUID();
     await this.call(s,'message',{message,client_message_id:clientId});s.lastPoll=0;
   }
   else if(a.kind==='copy'){this.d.copy(s.invite||s.code);}
   else if(a.kind==='leave'){await this.finish(s,true);}
   else if(s.role==='host'&&a.kind==='close'){await this.call(s,'close');s.serverClosed=true;await this.finish(s,true);}
   else if(s.role==='host'&&['kick','undo_kick'].includes(a.kind)){const list=a.kind==='kick'?s.members.filter(m=>m.role!=='host'):s.kicked;if(!list.some(m=>m.id===num(a.id)))throw Error('عضو معتبر نیست.');await this.call(s,a.kind,{member_id:num(a.id)});s.lastPoll=0;}
   else if(s.role==='host'&&a.kind==='theme'&&s.themes.some(t=>t.key===a.key)){await this.call(s,'room_settings',{theme_key:a.key});s.lastPoll=0;}
   else if(a.kind==='refresh'){s.lastPoll=0;}
   else throw Error('این عملیات در اختیار میزبان است.');
 }
 async finish(s,kill){if(s.closed)return;s.closed=true;clearInterval(s.timer);for(const q of s.queue||[])q.reject(Error('اتاق بسته شد.'));s.queue=[];if(kill&&s.child)try{s.child.kill()}catch{}if(s.joined&&s.code&&!s.serverClosed&&(!s.reused||s.child)){try{await this.call(s,'leave')}catch{}}if(s.dir)try{fs.rmSync(s.dir,{recursive:true,force:true})}catch{}if(this.active===s)this.active=null;}
 stop(){if(this.active)void this.finish(this.active,true);}
}
module.exports={WatchParty,mediaUrl,roomCode,stateFrom,classify};
