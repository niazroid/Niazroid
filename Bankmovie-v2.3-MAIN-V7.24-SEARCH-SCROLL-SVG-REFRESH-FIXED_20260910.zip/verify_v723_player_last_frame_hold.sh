#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
GRADLE='app/build.gradle'
MANIFEST='app/src/main/AndroidManifest.xml'

# Cast must remain removed.
! grep -E "play-services-cast|androidx\.mediarouter|androidx\.appcompat:appcompat|androidx\.fragment:fragment" "$GRADLE" >/dev/null
! grep -E 'CastContext|CastSession|RemoteMediaClient|MediaRoute|DlnaRouteProvider|DlnaController|Chromecast|ic_player_cast' "$PLAYER" >/dev/null
! grep -E 'com\.google\.android\.gms\.cast|OPTIONS_PROVIDER_CLASS_NAME|CHANGE_WIFI_MULTICAST_STATE' "$MANIFEST" >/dev/null

# V7.22 retained session must stay intact.
grep -Fq 'PLAYER_BACKGROUND_RETAIN_MS = 180_000L' "$PLAYER"
grep -Fq 'retained.attachViews(videoLayout, null, false, false)' "$PLAYER"
grep -Fq 'handler.postDelayed(releaseRetainedPlayerRunnable, PLAYER_BACKGROUND_RETAIN_MS)' "$PLAYER"

# V7.23 no-black bridge.
grep -Fq 'BANKMOVIE_V7_23_PLAYER_LAST_FRAME_HOLD' "$PLAYER"
grep -Fq 'import android.view.PixelCopy' "$PLAYER"
grep -Fq 'private lateinit var lifecycleFrameOverlay: ImageView' "$PLAYER"
grep -Fq 'private fun captureLifecycleVideoFrame()' "$PLAYER"
grep -Fq 'PixelCopy.request(surface, bitmap' "$PLAYER"
grep -Fq 'private fun showLifecycleFrameOverlay()' "$PLAYER"
grep -Fq 'private fun hideLifecycleFrameOverlay()' "$PLAYER"
grep -Fq 'MediaPlayer.Event.Vout -> {' "$PLAYER"
grep -Fq 'MediaPlayer.Event.TimeChanged -> {' "$PLAYER"
grep -Fq 'handler.postDelayed({ detachRetainedViewsForBackground() }, 110L)' "$PLAYER"
grep -Fq 'captureLifecycleVideoFrame()' "$PLAYER"
grep -Fq 'sourceMainUpdateFourthHotfixTag=BANKMOVIE-2.3-V723-20260910' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V723_PLAYER_LAST_FRAME_HOLD_OK
