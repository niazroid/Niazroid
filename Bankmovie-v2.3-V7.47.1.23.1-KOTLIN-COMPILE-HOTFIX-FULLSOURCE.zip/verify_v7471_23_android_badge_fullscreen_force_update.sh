#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_23_ANDROID_BADGE_FULLSCREEN_FORCE_UPDATE_FA.md"
ANDROID_ICON="$ROOT/app/src/main/res/drawable/ic_android_color.xml"
for f in "$MAIN" "$META" "$NOTE" "$ANDROID_ICON"; do test -s "$f"; done

grep -Fq 'mainUpdateV7471_23=V7.47.1.23 ANDROID DEVICE BADGE + FULLSCREEN MANDATORY UPDATE REDESIGN' "$META"

grep -Fq 'setImageResource(R.drawable.ic_android_color)' "$MAIN"
grep -Fq 'text = aboutDeviceLabel()' "$MAIN"
grep -Fq 'Build.VERSION.RELEASE' "$MAIN"
grep -Fq 'Build.MANUFACTURER' "$MAIN"
grep -Fq 'Build.MODEL' "$MAIN"
grep -Fq 'android:fillColor="#95CF00"' "$ANDROID_ICON"
grep -Fq 'android:translateX="-301"' "$ANDROID_ICON"
grep -Fq 'android:translateY="-560"' "$ANDROID_ICON"

grep -Fq 'V7.47.1.23: Update UI is a mandatory full-screen surface.' "$MAIN"
grep -Fq 'android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen' "$MAIN"
grep -Fq 'setCancelable(false)' "$MAIN"
grep -Fq 'setCanceledOnTouchOutside(false)' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_BACK' "$MAIN"
grep -Fq 'text = t("⇩  آپدیت الان", "⇩  Update now")' "$MAIN"
grep -Fq 'text = t("↻  آپدیت کردم، دوباره بررسی کن", "↻  I updated, check again")' "$MAIN"
grep -Fq 't("لیست تغییرات", "What'"'"'s new")' "$MAIN"

python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
a=s.index('    private fun showUpdateDialog(')
b=s.index('\n    private fun telegramProCard()', a)
block=s[a:b]
assert 'setCancelable(false)' in block
assert 'setCanceledOnTouchOutside(false)' in block
assert 'KEYCODE_BACK' in block
assert 'text = "×"' not in block
assert 't("بعداً", "Later")' not in block
assert 'dialog.dismiss()' in block  # allowed only after runtime version check succeeds
assert 'if (!stillOld)' in block
assert 'Theme_DeviceDefault_NoActionBar_Fullscreen' in block
PY

echo BANKMOVIE_V7471_23_ANDROID_BADGE_FULLSCREEN_FORCE_UPDATE_OK
