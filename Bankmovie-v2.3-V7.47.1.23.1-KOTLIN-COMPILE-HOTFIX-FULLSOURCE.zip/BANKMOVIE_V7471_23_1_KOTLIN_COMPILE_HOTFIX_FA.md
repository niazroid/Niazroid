# BankMovie V7.47.1.23.1 — Kotlin Compile Hotfix

این هات‌فیکس فقط خطای کامپایل V7.47.1.23 را اصلاح می‌کند و طراحی اجباری صفحه آپدیت، آیکون Android و رفتارهای نسخه قبل را دست‌نخورده نگه می‌دارد.

## اصلاح

در `MainActivity.kt` برای افزودن محتوای صفحه آپدیت به `ScrollView` از `FrameLayout.LayoutParams` استفاده می‌شود. `ScrollView.LayoutParams` در Kotlin به‌صورت مرجع مستقیم قابل resolve نبود و باعث خطای `Unresolved reference 'LayoutParams'` در `compileAbi2LiteReleaseKotlin` می‌شد.

## نتیجه

- خطای Kotlin مربوط به `ScrollView.LayoutParams` حذف شد.
- صفحه آپدیت همچنان Fullscreen و اجباری است.
- Back/Close/Later همچنان وجود ندارد.
- منطق V7.47.1.23 تغییر نکرده است.
