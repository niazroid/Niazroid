#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_23_1_KOTLIN_COMPILE_HOTFIX_FA.md"

test -s "$MAIN"
test -s "$META"
test -s "$NOTE"
grep -Fq 'mainUpdateV7471_23_1Hotfix=V7.47.1.23.1 KOTLIN COMPILE HOTFIX FOR FULLSCREEN UPDATE LAYOUTPARAMS' "$META"
grep -Fq 'scroll.addView(page, FrameLayout.LayoutParams(-1, -2))' "$MAIN"
if grep -Fq 'scroll.addView(page, ScrollView.LayoutParams(-1, -2))' "$MAIN"; then
  echo 'ERROR: stale ScrollView.LayoutParams compile regression remains' >&2
  exit 1
fi
grep -Fq 'Unresolved reference' "$NOTE"
echo BANKMOVIE_V7471_23_1_KOTLIN_COMPILE_HOTFIX_OK
