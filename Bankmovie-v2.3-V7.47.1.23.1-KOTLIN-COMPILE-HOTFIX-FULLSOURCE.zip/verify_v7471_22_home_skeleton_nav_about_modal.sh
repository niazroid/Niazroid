#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_22_HOME_SKELETON_NAV_ABOUT_MODAL_FA.md"
for f in "$MAIN" "$META" "$NOTE"; do test -s "$f"; done

grep -Fq 'mainUpdateV7471_22=V7.47.1.22 HOME SKELETON ROUNDING + LIGHT NAV PREVIEWS + DYNAMIC ABOUT + LIGHT MODAL CONTRAST' "$META"

# Home poster skeleton is truly clipped to a rounded outline.
grep -Fq 'V7.47.1.22: Home skeleton cards now share the same rounded poster' "$MAIN"
grep -Fq 'outline.setRoundRect(0, 0, view.width, view.height, posterRadius)' "$MAIN"
grep -Fq 'clipToOutline = true' "$MAIN"

# Light nav preview/selection has real contrast and dynamic readable Accent.
grep -Fq 'val activeAccent = if (p.light) UiPreferences.readableAccent(this) else p.primary' "$MAIN"
grep -Fq 'else if (p.light) { if (active) activeAccent else Color.rgb(74, 79, 88) }' "$MAIN"
grep -Fq 'val selectedAccent = if (p.light) UiPreferences.readableAccent(this) else p.primary' "$MAIN"

# About page device information is runtime-derived, never hard-coded.
grep -Fq 'private fun aboutDeviceLabel(): String' "$MAIN"
grep -Fq 'Build.VERSION.RELEASE' "$MAIN"
grep -Fq 'Build.MANUFACTURER' "$MAIN"
grep -Fq 'Build.MODEL' "$MAIN"
grep -Fq 'text = aboutDeviceLabel()' "$MAIN"
grep -Fq 't("معرفی بانک مووی", "About BankMovie")' "$MAIN"

# Legacy TV deterministic About tags are retained.
for n in 0 1 2 3 4; do grep -Fq "bm_v71_about_row_$n" "$MAIN"; done

# Bulk-copy sheet is opaque/readable in Light Theme.
grep -Fq 'background = if (p.light) rounded(p.panel, dp(27), p.stroke) else bankGlassDrawable(27, 250, 78, true)' "$MAIN"
grep -Fq 'view.setTextColor(if (selected) selectedAccent else palette.text)' "$MAIN"

# Detail hero floating controls are theme-aware in Light Theme.
grep -Fq 'Light Theme no longer keeps black floating controls' "$MAIN"
grep -Fq 'rounded(Color.argb(248, 255, 255, 255), dp(999), Color.argb(150, 214, 218, 224))' "$MAIN"
grep -Fq 'setColorFilter(if (p.light) Color.rgb(30, 33, 38) else Color.WHITE)' "$MAIN"

python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
# About runtime label must not regress to the old hard-coded "Android" line.
a=s.index('private fun aboutDeviceLabel(): String')
b=s.index('private fun addProfileContinueSection', a)
about=s[a:b]
for needle in ('Build.VERSION.RELEASE','Build.MANUFACTURER','Build.MODEL','Android $release • $device'):
    assert needle in about, f'missing dynamic device marker: {needle}'
assert 'نسخه ${appVersionName()}  •  Android' not in about, 'old hard-coded Android label still present'
# Light modal content itself must stay full-opacity.
a=s.index('private fun showSeriesBulkCopyDialog')
b=s.index('\n    private fun ', a+20)
modal=s[a:b]
assert 'alpha = 1f' in modal
assert 'if (palette.light)' in modal
PY

echo BANKMOVIE_V7471_22_HOME_SKELETON_NAV_ABOUT_MODAL_OK
