-- Windows CI only. Check actual property support and local settings load in staged MPV.
local mp=require 'mp'
local msg=require 'mp.msg'
local input=require 'mp.input'
assert(type(input.get)=='function','mp.input missing')
mp.register_event('file-loaded',function()
    assert(mp.get_property('sub-font')=='Tahoma','saved font was not restored')
    assert(mp.get_property_number('sub-font-size')==64,'saved font size was not restored')
    assert(mp.get_property('sub-ass-override')=='force','saved ASS preference was not restored')
    assert(mp.get_property('sub-border-style')=='background-box','saved background style was not restored')
    assert(mp.get_property('sub-color'):upper():sub(-6)=='FFFF00','saved color was not restored')
    assert(mp.set_property_number('sub-delay',0.1))
    assert(mp.set_property_number('audio-delay',0.1))
    assert(mp.set_property_number('sub-pos',90))
    assert(mp.set_property_number('sub-outline-size',3))
    assert(mp.set_property_number('sub-shadow-offset',2))
    assert(mp.set_property('sub-outline-color','#000000'))
    assert(mp.set_property('sub-back-color','#A6000000'))
    assert(mp.set_property('sub-bold','yes'))
    assert(mp.set_property('video-aspect-override','16:9'))
    assert(mp.set_property_number('video-zoom',0.1))
    assert(mp.set_property_number('panscan',1))
    msg.info('BM_SETTINGS_RUNTIME_OK')
end)
