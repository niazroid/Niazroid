-- Isolated Lua control logic test; not a real MPV rendering or Windows test.
local bindings,events,commands={}, {}, {}
local props={pause=true,duration=3600,['time-pos']=60,volume=50,speed=1,['media-title']='Movie {unsafe}', ['track-list']={{id=1,type='sub',lang='fas',codec='ass'},{id=2,type='audio',lang='eng'}}}
local time,xx,yy,ow,oh=0,0,0,1280,720
local ov={update=function()end};local timer
local mp={create_osd_overlay=function()return ov end,get_time=function()return time end,get_osd_size=function()return ow,oh,ow/oh end,get_mouse_pos=function()return xx,yy end,get_property=function(n,d)return props[n] or d end,get_property_number=function(n,d)return props[n] or d end,get_property_bool=function(n,d)if props[n]==nil then return d end return props[n] end,get_property_native=function(n,d)return props[n] or d end,set_property=function(n,v)props[n]=v;return true end,set_property_bool=function(n,v)props[n]=v;return true end,set_property_number=function(n,v)props[n]=v;return true end,commandv=function(...)local a={...};commands[#commands+1]=a;if a[1]=='cycle' then props[a[2]]=not props[a[2]] end;return true end,add_forced_key_binding=function(k,n,f)bindings[k]=f end,register_event=function(k,f)events[k]=f end,observe_property=function()end,add_periodic_timer=function(_,f)timer=f end,osd_message=function()end}
local inputRequest
local filePath=os.tmpname();os.remove(filePath)
local prefsData, fileData
local originalOpen,originalGetenv=io.open,os.getenv
os.getenv=function(k)if k=='LOCALAPPDATA' then return 'test-local-appdata' end;return originalGetenv(k)end
io.open=function(p,mode) if p=='test-local-appdata/BankMovie-player-settings.json' then
  if mode=='wb' then return {write=function(_,v)fileData=v end,close=function()end} end
  if fileData then return {read=function()return fileData end,close=function()end} end
  return nil
end;return originalOpen(p,mode)end
package.loaded['mp.utils']={format_json=function(t)prefsData={};for k,v in pairs(t)do prefsData[k]=v end;return 'mock-json' end,parse_json=function()return prefsData end,file_info=function(p)if p=='C:\\movie.srt' then return {is_file=true} end end}
package.loaded['mp.input']={get=function(o)inputRequest=o end}
mp.remove_key_binding=function(n)end
package.loaded.mp=mp
mp.set_property_native=function(n,v)props[n]=v;return true end
dofile('player/cinema.lua')
local function click(x,y)xx,yy=x,y;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});bindings.MBTN_LEFT({event='up'})end
assert(ov.data:find('Movie',1,true));assert(not ov.data:find('{unsafe}',1,true));assert(ov.data:find('F67C32',1,true));events['playback-restart']();timer()
local function geometry()local sc=math.min(ow/760,oh/480,1.15);return ow/sc,oh/sc,sc end
local function at(x,y)local _,_,sc=geometry();click(x*sc,y*sc)end
local w,h=geometry();local cy=math.min(h*.48,h-126);local step=math.min(42,w*.055)
at(w/2,cy);assert(props.pause==false)
at(w/2,cy);assert(props.pause==true)
bindings.RIGHT();assert(commands[#commands][1]=='seek' and commands[#commands][2]==10)
at(w/2,h-56);assert(commands[#commands][1]=='seek' and commands[#commands][3]=='absolute-percent+exact')
at(w-30-step*3,h-26);assert(ov.data:find('Subtitles',1,true));assert(ov.data:find('fas',1,true))
local my=h-83-5*36-48
at(w-100,my+48+36+18);assert(props.sid=='1')
at(29,h-26);at(34+104,h-88);assert(math.abs(props.volume-50)<1)
at(29,h-26)
at(w-30,h-26);assert(props.fullscreen==true)
bindings.ESC();assert(props.fullscreen==false)
at(w-30-step,h-26);assert(not ov.data:find('Movie',1,true));bindings.ESC();assert(ov.data:find('Movie',1,true))
assert(ov.data:find('\\p4',1,true),'site SVG vector outlines')
props.pause=false;time=10;timer();assert(ov.data=='');bindings.MOUSE_MOVE();assert(ov.data~='')
for _,size in ipairs({{640,360},{1920,1080},{800,600},{3440,1440}}) do ow,oh=size[1],size[2];timer();assert(ov.res_x>0 and ov.res_y>0 and #ov.data>0)end
-- Drive the real menu hit regions at the default size.
ow,oh=1280,720;props.pause=true;timer();w,h=geometry();step=math.min(42,w*.055)
local function rowAt(count,i) local shown=math.min(count,math.max(1,math.floor((h-145)/36)));at(w-120,h-83-shown*36-48+48+(i-1)*36+18) end
local function settings()at(w-30-step*2,h-26)end
settings();rowAt(6,3) -- subtitle style
rowAt(11,1);rowAt(14,2);assert(props['sub-font']=='Tahoma');assert(prefsData['sub-font']=='Tahoma')
bindings.ESC();rowAt(11,2);rowAt(9,7);assert(props['sub-font-size']==72)
bindings.ESC();rowAt(11,3);rowAt(8,2);assert(props['sub-color']=='#FFFF00')
bindings.ESC();rowAt(11,5);rowAt(7,6);assert(props['sub-outline-size']==4)
bindings.ESC();rowAt(11,6);rowAt(4,2);assert(props['sub-back-color']=='#A6000000')
bindings.ESC();rowAt(11,9);rowAt(2,2);assert(props['sub-ass-override']=='force')
bindings.ESC();bindings.ESC(); -- subtitle menu
rowAt(5,5);rowAt(6,4);assert(math.abs(props['sub-delay']-0.1)<0.001)
bindings.ESC();rowAt(5,3);assert(inputRequest);inputRequest.submit('https://bad.example/file.srt');assert(commands[#commands][1]~='sub-add');inputRequest.submit('C:\\movie.srt');assert(commands[#commands][1]=='sub-add');inputRequest.closed();timer()
bindings.ESC();rowAt(6,1);rowAt(2,2);rowAt(6,5);assert(props['audio-delay']==1)
bindings.ESC();bindings.ESC();rowAt(6,5);rowAt(2,1);rowAt(5,2);assert(props['video-aspect-override']=='16:9')
bindings.ESC();rowAt(2,2);rowAt(4,2);assert(props.panscan==1)
-- Start a fresh script with the saved local settings; no account or media data is read.
props['sub-font']=nil;props['sub-color']=nil;dofile('player/cinema.lua');assert(props['sub-font']=='Tahoma' and props['sub-color']=='#FFFF00')
io.open=originalOpen;os.getenv=originalGetenv
print('PASS: subtitle font, size, color, outline, background, ASS override, delays, local file input validation, aspect/crop, settings reload')
print('PASS: Lua overlay title escaping, playback toggle, skip, seek, subtitle selection, lock, auto-hide, responsive sizes')
