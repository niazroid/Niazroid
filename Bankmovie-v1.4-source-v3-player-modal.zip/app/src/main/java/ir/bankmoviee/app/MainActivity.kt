package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.LinkedHashMap
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private var apiBase = "https://bankmoviee.ir/app_api.php"
    private val appConfigUrl = "https://bankmoviee.ir/app_config.php"
    private var activeDomain = "https://bankmoviee.ir"
    private var remoteNoticeTitle = ""
    private var remoteNoticeMessage = ""
    private var remoteNoticeId = ""
    private var remoteNoticeEnabled = false
    private var maintenanceMode = false
    private var maintenanceMessage = "اپ موقتاً در دسترس نیست."
    private var remoteVersionCode = 0
    private var remoteVersionName = ""
    private var remoteApkUrl = ""
    private var remoteForceUpdate = false
    private var remoteUpdateEnabled = true
    private var remoteUpdateTitle = "آپدیت جدید آماده است"
    private var remoteUpdateMessage = "برای تجربه بهتر نسخه جدید را نصب کنید."
    private var remoteUpdateChanges = mutableListOf<String>()
    private var remoteApkUrlUniversal = ""
    private var remoteApkUrlArm64 = ""
    private var remoteApkUrlV7a = ""
    private var versionPolicyEnabled = false
    private var minimumSupportedVersionCode = 0
    private var minimumSupportedVersionName = ""
    private val blockedVersionNames = linkedSetOf<String>()
    private val blockedVersionCodes = linkedSetOf<Int>()
    private var blockedVersionMessage = "این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید."
    private var forceUpdateBlockedVersions = true
    private val bmAppKey = "bm_android_v1_7c2f40"
    private val bmAppSecret = listOf("9e1d4a7b3167f4c9", "b2d83f0a64e597f3", "d7f4b1a72638f90c", "6e2f2bd29d6aa8c1").joinToString("")
    private val defaultArchive = 1
    private var serverClockOffsetSec = 0L

    private var bg = Color.rgb(3, 7, 14)
    private var bg2 = Color.rgb(7, 13, 24)
    private var panel = Color.rgb(9, 17, 31)
    private var panel2 = Color.rgb(13, 24, 42)
    private var card = Color.rgb(12, 22, 38)
    private var stroke = Color.rgb(39, 63, 96)
    private var blue = Color.rgb(28, 32, 40)
    private var blue2 = Color.rgb(245, 245, 245)
    private var gold = Color.rgb(235, 235, 235)
    private var white = Color.WHITE
    private var muted = Color.rgb(166, 180, 203)
    private var faint = Color.rgb(105, 123, 150)

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomNav: LinearLayout
    private var isMainHomePage = false

    private var currentScreen = "home"
    private val imageCache = LinkedHashMap<String, Bitmap>()
    private val heroItems = mutableListOf<JSONObject>()
    private var bootJson: JSONObject? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        applyThemeColors()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showSplashOnly()
        boot()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (::root.isInitialized && currentScreen != "home") {
            showHome()
            return
        }
        super.onBackPressed()
    }


    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action == android.view.KeyEvent.ACTION_DOWN && ::bottomNav.isInitialized && isTvLike()) {
            when (event.keyCode) {
                android.view.KeyEvent.KEYCODE_DPAD_UP,
                android.view.KeyEvent.KEYCODE_DPAD_DOWN,
                android.view.KeyEvent.KEYCODE_DPAD_LEFT,
                android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    if (bottomNav.visibility != View.VISIBLE || bottomNav.translationY > 0f) {
                        bottomNav.visibility = View.VISIBLE
                        bottomNav.animate().translationY(0f).alpha(1f).setDuration(150).start()
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun showSplashOnly() {
        val splash = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
        }
        splash.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, FrameLayout.LayoutParams(dp(330), dp(152), Gravity.CENTER).apply {
            bottomMargin = dp(95)
        })
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        bottom.addView(ProgressBar(this).apply {
            isIndeterminate = true
        }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { bottomMargin = dp(16) })
        bottom.addView(TextView(this).apply {
            text = "لطفا صبر کنید..."
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        bottom.addView(TextView(this).apply {
            text = "نسخه ۱.۴"
            setTextColor(Color.argb(135, 255, 255, 255))
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        splash.addView(bottom, FrameLayout.LayoutParams(-1, dp(150), Gravity.BOTTOM).apply {
            bottomMargin = dp(72)
        })
        setContentView(splash)
    }

    private fun showNetworkError(message: String) {
        val disabled = maintenanceMode
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(dp(22), dp(22), dp(22), dp(22))
        }
        page.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(320), dp(145)).apply { bottomMargin = dp(18) })
        page.addView(TextView(this).apply {
            text = if (disabled) t("اپ موقتاً غیرفعال است", "App is temporarily disabled") else t("اتصال برقرار نشد", "Connection failed")
            setTextColor(white)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = if (disabled) t("بعداً دوباره امتحان کن.", "Please try again later.") else friendlyError(message)
            setTextColor(muted)
            textSize = 13.5f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(18))
        })
        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        if (!disabled) {
            page.addView(TextView(this).apply {
                text = t("تلاش دوباره", "Retry")
                setTextColor(white)
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.rgb(24, 37, 57), dp(17), Color.argb(110, 255, 255, 255))
                setOnClickListener { showSplashOnly(); boot() }
            }, LinearLayout.LayoutParams(-1, dp(50)))
        }
        setContentView(page)
    }

    private fun normalizeDomain(raw: String): String {
        var d = raw.trim()
        if (d.isBlank()) return ""
        if (!d.startsWith("http://", true) && !d.startsWith("https://", true)) d = "https://$d"
        while (d.endsWith("/")) d = d.dropLast(1)
        return d
    }

    private fun loadAppConfig(done: () -> Unit) {
        Thread {
            try {
                val c = (URL(appConfigUrl).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 6500
                    readTimeout = 9000
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "BankmovieAndroidNative/1.4")
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val code = c.responseCode
                c.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let { serverClockOffsetSec = it / 1000L - System.currentTimeMillis() / 1000L }
                val body = (if (code in 200..299) c.inputStream else c.errorStream)
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                if (code in 200..299) {
                    applyAppConfig(JSONObject(body))
                }
            } catch (_: Throwable) {
                // اگر app_config در دسترس نبود، اپ با API پیش‌فرض خودش بالا می‌آید.
            }
            done()
        }.start()
    }

    private fun applyAppConfig(json: JSONObject) {
        maintenanceMode = false
        if (!json.optBoolean("ready", true)) {
            maintenanceMode = true
            maintenanceMessage = json.optString("message").ifBlank { maintenanceMessage }
            return
        }

        val d = normalizeDomain(
            json.optString("active_domain")
                .ifBlank { json.optString("domain") }
                .ifBlank { json.optString("base_url") }
        )
        if (d.isNotBlank()) activeDomain = d

        val remoteApi = json.optString("api_url")
            .ifBlank { json.optString("api") }
            .ifBlank { json.optString("api_base") }

        apiBase = when {
            remoteApi.isNotBlank() && remoteApi.startsWith("http", true) -> remoteApi
            remoteApi.isNotBlank() -> activeDomain + "/" + remoteApi.trimStart('/')
            activeDomain.isNotBlank() -> "$activeDomain/app_api.php"
            else -> "https://bankmoviee.ir/app_api.php"
        }

        val notice = json.optJSONObject("notice")
        remoteNoticeEnabled = notice?.optBoolean("enabled", false) ?: json.optBoolean("notice_enabled", false)
        remoteNoticeTitle = notice?.optString("title").orEmpty().ifBlank { json.optString("notice_title") }
        remoteNoticeMessage = notice?.optString("message").orEmpty()
            .ifBlank { json.optString("notice_message") }
            .ifBlank { if (remoteNoticeEnabled) json.optString("notice") else "" }
            .ifBlank { if (remoteNoticeEnabled) json.optString("message") else "" }
        remoteNoticeId = notice?.optString("id").orEmpty().ifBlank { json.optString("notice_id") }

        val update = json.optJSONObject("update")
        remoteVersionCode = update?.optInt("version_code", 0) ?: json.optInt("version_code", json.optInt("latest_version_code", 0))
        remoteVersionName = update?.optString("version_name").orEmpty()
            .ifBlank { json.optString("version_name") }
            .ifBlank { json.optString("latest_version_name") }
        val apkUrls = update?.optJSONObject("apk_urls")
        remoteApkUrlUniversal = apkUrls?.optString("universal").orEmpty()
            .ifBlank { update?.optString("apk_url").orEmpty() }
            .ifBlank { update?.optString("download_url").orEmpty() }
            .ifBlank { json.optString("apk_url") }
            .ifBlank { json.optString("download_url") }
        remoteApkUrlArm64 = apkUrls?.optString("arm64_v8a").orEmpty()
            .ifBlank { apkUrls?.optString("arm64").orEmpty() }
        remoteApkUrlV7a = apkUrls?.optString("armeabi_v7a").orEmpty()
            .ifBlank { apkUrls?.optString("v7a").orEmpty() }
        remoteApkUrl = remoteApkUrlUniversal
        remoteUpdateEnabled = update?.optBoolean("enabled", true) ?: json.optBoolean("update_enabled", true)
        remoteForceUpdate = update?.optBoolean("force", false) ?: json.optBoolean("force_update", false)
        remoteUpdateTitle = update?.optString("title").orEmpty().ifBlank { json.optString("update_title") }.ifBlank { remoteUpdateTitle }
        remoteUpdateMessage = update?.optString("message").orEmpty().ifBlank { json.optString("update_message") }.ifBlank { remoteUpdateMessage }
        remoteUpdateChanges.clear()
        val changesArr = update?.optJSONArray("changes") ?: json.optJSONArray("changes") ?: json.optJSONArray("what_new")
        if (changesArr != null) {
            for (i in 0 until changesArr.length()) {
                val s = changesArr.optString(i).trim()
                if (s.isNotBlank()) remoteUpdateChanges.add(s)
            }
        }
        val changeText = update?.optString("changelog").orEmpty().ifBlank { json.optString("changelog") }
        if (remoteUpdateChanges.isEmpty() && changeText.isNotBlank()) {
            changeText.split("\n", "•", "-", "،").map { it.trim() }.filter { it.isNotBlank() }.take(8).forEach { remoteUpdateChanges.add(it) }
        }

        val policy = json.optJSONObject("version_policy")
        versionPolicyEnabled = policy?.optBoolean("enabled", false) ?: false
        minimumSupportedVersionCode = policy?.optInt("minimum_version_code", 0) ?: 0
        minimumSupportedVersionName = policy?.optString("minimum_version_name").orEmpty().trim()
        blockedVersionMessage = policy?.optString("block_message").orEmpty().ifBlank { blockedVersionMessage }
        forceUpdateBlockedVersions = policy?.optBoolean("force_update_blocked", true) ?: true
        blockedVersionNames.clear()
        blockedVersionCodes.clear()
        policy?.optJSONArray("blocked_version_names")?.let { arr ->
            for (i in 0 until arr.length()) {
                normalizeVersionLabel(arr.optString(i)).takeIf { it.isNotBlank() }?.let { blockedVersionNames.add(it) }
            }
        }
        policy?.optJSONArray("blocked_version_codes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val value = arr.optInt(i, 0)
                if (value > 0) blockedVersionCodes.add(value)
            }
        }

        appPrefs().edit()
            .putString("active_domain", activeDomain)
            .putString("api_base", apiBase)
            .apply()
    }

    private fun showRemoteNoticeIfNeeded() {
        val msg = remoteNoticeMessage.trim()
        if (!remoteNoticeEnabled || msg.isBlank()) return
        val id = remoteNoticeId.ifBlank { msg.hashCode().toString() }
        val lastSeen = appPrefs().getString("remote_notice_seen_id", "") ?: ""
        if (lastSeen == id) return

        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18, 19, 28), Color.rgb(8, 10, 17))).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.argb(95, 155, 98, 255))
            }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply {
            text = remoteNoticeTitle.ifBlank { t("پیام مدیریت", "Admin message") }
            setTextColor(Color.WHITE)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(Color.rgb(220, 224, 238))
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(58, 255, 255, 255), dp(17), Color.argb(45, 255, 255, 255))
            setOnClickListener {
                appPrefs().edit().putString("remote_notice_seen_id", id).apply()
                dialog.dismiss()
            }
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(TextView(this).apply {
            text = msg
            setTextColor(Color.rgb(230, 233, 242))
            textSize = 14f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(4).toFloat(), 1.0f)
        })
        box.addView(TextView(this).apply {
            text = t("متوجه شدم", "Got it")
            setTextColor(Color.WHITE)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(139, 92, 246), Color.rgb(93, 54, 220))).apply { cornerRadius = dp(21).toFloat() }
            setOnClickListener {
                appPrefs().edit().putString("remote_notice_seen_id", id).apply()
                dialog.dismiss()
            }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(18) })
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        if (isTvLike()) {
            applyTvFocusToClickableTree(box)
            focusFirstTvClickable(box)
        }
    }

    private fun normalizeVersionLabel(value: String): String {
        return value.trim().lowercase(Locale.ROOT)
            .removePrefix("version")
            .removePrefix("ver")
            .removePrefix("v")
            .trim()
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
            .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
    }

    private fun versionNumberParts(value: String): List<Int> {
        return Regex("\d+").findAll(normalizeVersionLabel(value)).mapNotNull { it.value.toIntOrNull() }.toList()
    }

    private fun compareReleaseVersions(left: String, right: String): Int {
        val a = versionNumberParts(left)
        val b = versionNumberParts(right)
        val size = maxOf(a.size, b.size)
        for (i in 0 until size) {
            val av = a.getOrElse(i) { 0 }
            val bv = b.getOrElse(i) { 0 }
            if (av != bv) return av.compareTo(bv)
        }
        return 0
    }

    private fun selectedRemoteApkUrl(): String {
        val abis = android.os.Build.SUPPORTED_ABIS?.map { it.lowercase(Locale.ROOT) }.orEmpty()
        return when {
            abis.any { it == "arm64-v8a" } && remoteApkUrlArm64.isNotBlank() -> remoteApkUrlArm64
            abis.any { it == "armeabi-v7a" } && remoteApkUrlV7a.isNotBlank() -> remoteApkUrlV7a
            remoteApkUrlUniversal.isNotBlank() -> remoteApkUrlUniversal
            remoteApkUrl.isNotBlank() -> remoteApkUrl
            else -> ""
        }
    }

    private fun currentVersionBlockReason(): String? {
        if (!versionPolicyEnabled) return null
        val currentCode = appVersionCode()
        val currentName = normalizeVersionLabel(appVersionName())
        val blockedByName = currentName.isNotBlank() && blockedVersionNames.contains(currentName)
        val blockedByCode = currentCode > 0 && blockedVersionCodes.contains(currentCode)
        val belowMinimumCode = minimumSupportedVersionCode > 0 && currentCode < minimumSupportedVersionCode
        val belowMinimumName = minimumSupportedVersionName.isNotBlank() && compareReleaseVersions(appVersionName(), minimumSupportedVersionName) < 0
        return if (blockedByName || blockedByCode || belowMinimumCode || belowMinimumName) blockedVersionMessage else null
    }

    private fun showBlockedVersionScreen(message: String) {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        page.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(280), dp(126)).apply { bottomMargin = dp(22) })
        page.addView(TextView(this).apply {
            text = t("این نسخه غیرفعال شده است", "This version is disabled")
            setTextColor(Color.WHITE)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = message
            setTextColor(Color.rgb(180, 190, 208))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(18))
        })
        val apkUrl = selectedRemoteApkUrl()
        if (apkUrl.isNotBlank()) {
            page.addView(TextView(this).apply {
                text = t("نصب نسخه جدید", "Install latest version")
                setTextColor(Color.WHITE)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(139, 92, 246), Color.rgb(93, 54, 220))).apply { cornerRadius = dp(24).toFloat() }
                setOnClickListener { openExternal(apkUrl, null) }
            }, LinearLayout.LayoutParams(-1, dp(56)))
        }
        setContentView(page)
    }

    private fun showConfigUpdateIfNeeded(showToastIfLatest: Boolean): Boolean {
        val blockReason = currentVersionBlockReason()
        if (blockReason != null) {
            val apkUrl = selectedRemoteApkUrl()
            if (apkUrl.isBlank() || !forceUpdateBlockedVersions) {
                showBlockedVersionScreen(blockReason)
            } else {
                showUpdateDialog(
                    remoteUpdateTitle.ifBlank { t("این نسخه غیرفعال شده است", "This version is disabled") },
                    blockReason,
                    apkUrl,
                    true,
                    remoteVersionName.ifBlank { t("نسخه جدید", "Latest version") },
                    appVersionName(),
                    remoteUpdateChanges
                )
            }
            return true
        }

        if (!remoteUpdateEnabled) return false
        val currentCode = appVersionCode()
        val currentName = appVersionName().trim()
        val targetName = remoteVersionName.trim()
        val hasNamedVersion = versionNumberParts(targetName).isNotEmpty()
        val hasUpdate = selectedRemoteApkUrl().isNotBlank() && when {
            hasNamedVersion -> compareReleaseVersions(targetName, currentName) > 0
            remoteVersionCode > 0 -> remoteVersionCode > currentCode
            else -> false
        }
        if (!hasUpdate) return false

        val latestName = targetName.ifBlank { if (remoteVersionCode > 0) remoteVersionCode.toString() else t("جدید", "New") }
        showUpdateDialog(
            remoteUpdateTitle,
            remoteUpdateMessage,
            selectedRemoteApkUrl(),
            remoteForceUpdate,
            latestName,
            currentName,
            remoteUpdateChanges
        )
        return true
    }

    private fun boot() {
        loadAppConfig {
            if (maintenanceMode) {
                runOnUiThread { showNetworkError(maintenanceMessage) }
                return@loadAppConfig
            }
            val versionBlockReason = currentVersionBlockReason()
            if (versionBlockReason != null) {
                runOnUiThread {
                    val apkUrl = selectedRemoteApkUrl()
                    if (apkUrl.isNotBlank() && forceUpdateBlockedVersions) {
                        showUpdateDialog(
                            remoteUpdateTitle.ifBlank { t("این نسخه غیرفعال شده است", "This version is disabled") },
                            versionBlockReason,
                            apkUrl,
                            true,
                            remoteVersionName.ifBlank { t("نسخه جدید", "Latest version") },
                            appVersionName(),
                            remoteUpdateChanges
                        )
                    } else {
                        showBlockedVersionScreen(versionBlockReason)
                    }
                }
                return@loadAppConfig
            }

            fetch("$apiBase?action=boot") { ok, json, err ->
                runOnUiThread {
                    if (ok && json != null && json.optBoolean("ready", false)) {
                        bootJson = json
                        appPrefs().edit()
                            .putString("theme_mode", "black")
                            .putBoolean("setup_done_v15_bw", true)
                            .apply()
                        buildShell()
                        showHome()
                        showRemoteNoticeIfNeeded()
                        showConfigUpdateIfNeeded(false)
                    } else {
                        showNetworkError(err ?: t("خطا در اتصال به Bankmovie", "Could not connect to Bankmovie"))
                    }
                }
            }
        }
    }

        private fun attachSmartHeader(scroll: ScrollView) {
        val headerAllowed = false
        if (::topBar.isInitialized) {
            topBar.visibility = View.GONE
            topBar.translationY = 0f
            topBar.alpha = 0f
        }

        val footerAllowed = currentScreen != "detail" && currentScreen != "player"
        val footerHeight = dp(if (isTvLike()) 66 else 92) + dp(22)

        fun showFooterNow(animated: Boolean = true) {
            if (!::bottomNav.isInitialized || !footerAllowed) return
            bottomNav.visibility = View.VISIBLE
            if (animated) {
                bottomNav.animate().translationY(0f).alpha(1f).setDuration(165).start()
            } else {
                bottomNav.translationY = 0f
                bottomNav.alpha = 1f
            }
        }

        fun hideFooterNow() {
            if (!::bottomNav.isInitialized || !footerAllowed) return
            if (bottomNav.visibility != View.VISIBLE) return
            bottomNav.animate()
                .translationY(footerHeight.toFloat())
                .alpha(0f)
                .setDuration(175)
                .withEndAction {
                    if (bottomNav.translationY > 0f) bottomNav.visibility = View.GONE
                }
                .start()
        }

        if (::bottomNav.isInitialized) {
            if (footerAllowed) showFooterNow(false) else bottomNav.visibility = View.GONE
        }

        if (isTvLike()) {
            scroll.layoutDirection = View.LAYOUT_DIRECTION_LTR
            applyTvFocusToClickableTree(scroll)
            scroll.postDelayed({ applyTvFocusToClickableTree(scroll) }, 900)
            scroll.postDelayed({ applyTvFocusToClickableTree(scroll) }, 1800)
        }

        var lastY = 0
        scroll.setOnScrollChangeListener { _, _, sy, _, oldSy ->
            if (footerAllowed) {
                val goingDown = sy > oldSy && sy > dp(46)
                val goingUp = sy < oldSy || sy < dp(14)
                if (goingDown) hideFooterNow()
                else if (goingUp) showFooterNow(true)
            }

            if (::topBar.isInitialized && headerAllowed) {
                val goingDown = sy > oldSy && sy > dp(40)
                if (goingDown && topBar.visibility == View.VISIBLE) {
                    topBar.animate().translationY(-dp(76).toFloat()).alpha(0f).setDuration(170).withEndAction { topBar.visibility = View.GONE }.start()
                } else if (!goingDown && sy < lastY) {
                    topBar.visibility = View.VISIBLE
                    topBar.animate().translationY(0f).alpha(1f).setDuration(170).start()
                }
            }
            lastY = sy
        }
    }

    private fun ui(raw: String): String {
        if (isFa()) return raw
        var s = raw.trim()
        val exact = mapOf(
            "خانه" to "Home",
            "جستجو" to "Search",
            "کالکشن‌ها" to "Collections",
            "پروفایل" to "Profile",
            "فیلم" to "Movie",
            "فیلم‌ها" to "Movies",
            "سریال" to "Series",
            "سریال‌ها" to "Series",
            "همه" to "All",
            "مشاهده همه ‹" to "View all ‹",
            "مشاهده همه" to "View all",
            "مشاهده همه نتایج" to "View all results",
            "مشاهده بیشتر" to "Load more",
            "مشاهده نتایج بیشتر" to "Load more results",
            "صفحه بعد" to "Next page",
            "در حال بارگذاری..." to "Loading...",
            "در حال جستجو..." to "Searching...",
            "نتایج در حال آماده‌سازی است" to "Preparing results",
            "در حال دریافت صفحه بازیگر" to "Loading actor page",
            "تلاش مجدد" to "Retry",
            "بارگذاری دوباره" to "Reload",
            "فیلم‌های بروز شده" to "Updated Movies",
            "سریال‌های بروز شده" to "Updated Series",
            "فیلم‌های به‌روز شده" to "Updated Movies",
            "سریال‌های به‌روز شده" to "Updated Series",
            "فیلم‌های جدید" to "New Movies",
            "سریال‌های جدید" to "New Series",
            "سریال‌های کره‌ای" to "Korean Series",
            "دوبله فارسی" to "Persian Dubbed",
            "برترین‌های 2026" to "Best of 2026",
            "پیشنهاد فیلم" to "Recommended",
            "انیمه" to "Anime",
            "ترکی" to "Turkish",
            "ادامه تماشا" to "Continue Watching",
            "واچ‌لیست" to "Watchlist",
            "آخرین بازدیدها" to "History",
            "هنوز چیزی برای ادامه تماشا نداری" to "Nothing to continue yet",
            "واچ‌لیست خالی است" to "Your watchlist is empty",
            "هنوز فیلمی باز نکردی" to "No recent titles yet",
            "هنوز چیزی ذخیره نشده" to "Nothing saved yet",
            "ظاهر سینمایی و مرتب برای مرور سریع" to "A clean cinematic view for quick browsing",
            "بروزرسانی" to "Updated",
            "محبوب" to "Popular",
            "لینک پخش مستقیم پیدا نشد" to "No direct playback link found",
            "انتخاب نسخه پخش" to "Choose playback version",
            "انتخاب فصل و قسمت" to "Choose season and episode",
            "باکس دانلود" to "Download Box",
            "فصل‌ها و قسمت‌ها / دانلود" to "Seasons, Episodes and Downloads",
            "دوبله" to "Dubbed",
            "زیرنویس" to "Subtitle",
            "سافت ساب" to "Soft-sub",
            "هاردساب" to "Hard-sub",
            "صوت دوبله" to "Dubbed Audio",
            "نسخه زیرنویس فارسی" to "Persian Subtitle Version",
            "لینک‌ها" to "Links",
            "لینک‌های دانلود" to "Download Links",
            "لینک‌های دانلود آماده است" to "Download links are ready",
            "سایر لینک‌ها" to "Other links",
            "فصل" to "Season",
            "قسمت" to "Episode",
            "قسمت‌ها" to "Episodes",
            "فیلم‌ها و سریال‌ها" to "Movies and Series",
            "فیلمی پیدا نشد" to "No title found",
            "برای این بازیگر هنوز اثری ثبت نشده است." to "No title is registered for this actor yet.",
            "خطا در دریافت کالکشن" to "Collection loading error",
            "خطا در دریافت بازیگر" to "Actor loading error",
            "خطا در جستجو" to "Search error",
            "نتیجه‌ای پیدا نشد" to "No results found",
            "با کلمه کوتاه‌تر یا تب همه امتحان کن" to "Try a shorter keyword or All tab",
            "برای دانلود VPN را خاموش کنید و از IP ایران استفاده نمایید." to "For downloads, turn off VPN and use an Iran IP.",
            "برای پخش روی دکمه سبز بزن. برای دانلود روی آیکن دانلود کنار هر نسخه بزن." to "Tap the green button to play. Tap the download icon next to each version to download.",
            "کانال تلگرام @BANKMOVIE_ORG" to "Telegram Channel @BANKMOVIE_ORG",
            "اطلاعات این بخش لود نشد" to "This section could not be loaded",
            "نامشخص" to "Unknown",
            "اپ فعال نیست" to "App is disabled",
            "متوجه شدم" to "Got it",
            "آپدیت جدید آماده است" to "Update available",
            "آپدیت الان" to "Update now",
            "بعداً" to "Later",
            "تغییرات نسخه" to "What is new",
            "آخرین نسخه" to "Latest",
            "نصب‌شده" to "Installed",
            "زبان برنامه" to "App language",
            "بررسی آپدیت داخلی" to "Check update",
            "پخش" to "Play",
            "دانلود" to "Download",
            "ادامه مطلب" to "Read more",
            "جعبه دانلود" to "Download Box",
            "پخش آنلاین" to "Watch Online",
            "تریلر" to "Trailer",
            "سال" to "Year",
            "بازیگر" to "Actor",
            "بازیگران" to "Cast",
            "اطلاعات فیلم" to "Movie Info",
            "اطلاعات سریال" to "Series Info",
            "دانلود فیلم" to "Download Movie",
            "دانلود سریال" to "Download Series",
            "مشاهده" to "View",
            "تلاش دوباره" to "Try again",
            "چیزی پیدا نشد" to "Nothing found",
            "تب همه یا کلمه کوتاه‌تر را امتحان کن" to "Try All tab or a shorter keyword",
            "نتیجه جدیدی باقی نمانده" to "No more results",
            "در حال آوردن همه نتایج..." to "Loading all results...",
            "صفحه بازیگر" to "Actor Page",
            "فیلم‌های این مجموعه" to "Titles in this collection",
            "فیلم‌های این بازیگر" to "Titles with this actor",
            "بازگشت" to "Back",
            "بستن" to "Close",
            "لغو" to "Cancel",
            "انتخاب لینک" to "Choose link",
            "دانلود با مرورگر" to "Download with browser",
            "کپی لینک" to "Copy link",
            "لینک کپی شد" to "Link copied",
            "ظاهر سینمایی و مرتب برای مرور سریع" to "A clean cinematic layout for quick browsing",
            "بروزرسانی" to "Updated",
            "محبوب" to "Popular",
            "نامشخص" to "Unknown",
            "فصل" to "Season",
            "قسمت" to "Episode",
            "دانلود فایل" to "Download file",
            "نسخه انتخاب‌شده" to "Selected version",
            "دانلود مستقیم" to "Direct download",
            "لینک دانلود نامعتبر است" to "Invalid download link",
            "لینک مستقیم دانلود پیدا نشد" to "No direct download link found",
            "پیشنهاد فیلم" to "Recommended titles",
            "بازیگران" to "Cast",
            "کمتر" to "Less",
            "ادامه مطلب ⌄" to "Read more ⌄",
            "کمتر ⌃" to "Less ⌃"
        )
        exact[s]?.let { return it }
        s = s.replace("عنوان", "titles")
            .replace("فصل", "Season")
            .replace("قسمت", "Episode")
            .replace("خطا", "Error")
            .replace("در حال جستجو...", "Searching...")
            .replace("نتایج در حال آماده‌سازی است", "Preparing results")
            .replace("در حال بارگذاری...", "Loading...")
            .replace("مشاهده همه", "View all")
            .replace("دوبله فارسی", "Persian Dubbed")
            .replace("زیرنویس فارسی", "Persian Subtitle")
            .replace("صوت دوبله", "Dubbed Audio")
            .replace("هاردساب", "Hard-sub")
            .replace("سافت ساب", "Soft-sub")
            .replace("دوبله", "Dubbed")
            .replace("زیرنویس", "Subtitle")
            .replace("فیلم", "Movie")
            .replace("سریال", "Series")
            .replace("کالکشن", "Collection")
        return s
    }

    private fun tvFocusHaloDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(2), Color.argb(215, 139, 92, 246))
        }
    }

    private fun applyTvFocusHalo(view: View, radiusDp: Int = 24, scale: Float = 1.055f, normalElevation: Float = 0f) {
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        view.setOnFocusChangeListener { v, has ->
            v.foreground = if (has) tvFocusHaloDrawable(radiusDp) else null
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .alpha(1f)
                .setDuration(135)
                .start()
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
            resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun applyTvFocusToClickableTree(view: View) {
        if (!isTvLike()) return
        view.postDelayed({
            fun walk(v: View) {
                val skip = v is EditText || v is ScrollView || v is HorizontalScrollView || v is GridLayout
                if (!skip && v.hasOnClickListeners()) {
                    applyTvFocusHalo(v, 22, 1.045f, v.elevation)
                }
                if (v is ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 180)
    }

    private fun focusFirstTvClickable(view: View) {
        if (!isTvLike()) return
        view.postDelayed({
            fun walk(v: View): Boolean {
                if (v.isFocusable && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                    v.requestFocus()
                    return true
                }
                if (v is ViewGroup) {
                    for (i in 0 until v.childCount) {
                        if (walk(v.getChildAt(i))) return true
                    }
                }
                return false
            }
            walk(view)
        }, 260)
    }


    private fun tvGridColumns(): Int = 8

    private fun tvGridCardWidth(): Int {
        val columns = tvGridColumns()
        val available = resources.displayMetrics.widthPixels - dp(36)
        return (available / columns - dp(14)).coerceAtLeast(dp(118))
    }

    private fun tvGridCardHeight(width: Int): Int {
        return (width * 1.88f).toInt().coerceAtLeast(dp(235))
    }

    private fun buildShell() {
        applyThemeColors()
        val tv = isTvLike()
        root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }

        content = FrameLayout(this).apply {
            setBackgroundColor(bg)
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }

        bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            setPadding(dp(if (tv) 8 else 9), dp(if (tv) 5 else 7), dp(if (tv) 8 else 9), dp(if (tv) 5 else 7))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.argb(if (tv) 228 else 238, 20, 22, 28),
                Color.argb(if (tv) 218 else 226, 9, 12, 20)
            )).apply {
                cornerRadius = dp(if (tv) 36 else 42).toFloat()
                setStroke(dp(1), Color.argb(82, 255, 255, 255))
            }
            elevation = dp(if (tv) 18 else 26).toFloat()
            alpha = 1f
            translationY = 0f
        }

        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(bottomNav, FrameLayout.LayoutParams(if (tv) dp(760) else -1, dp(if (tv) 70 else 78), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = dp(if (tv) 120 else 18)
            rightMargin = dp(if (tv) 120 else 18)
            bottomMargin = dp(if (tv) 12 else 10)
        })
        setContentView(root)
        buildBottomNav()
    }

    private fun buildBottomNav() {
        bottomNav.removeAllViews()
        navSvg(t("خانه", "Home"), "home", R.drawable.ic_nav_home) { showHome() }
        navSvg(t("جستجو", "Search"), "search", R.drawable.ic_search_clean) { showSearch() }
        navSvg(t("کالکشن‌ها", "Collections"), "collections", R.drawable.ic_nav_grid) { showCollections() }
        navSvg(t("پروفایل", "Profile"), "profile", R.drawable.ic_nav_profile) { showProfile() }
    }

    private fun navSvg(label: String, key: String, iconRes: Int, action: () -> Unit) {
        val active = currentScreen == key
        val tv = isTvLike()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = if (active) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(230, 0, 108, 255), Color.argb(205, 22, 60, 170))).apply {
                    cornerRadius = dp(if (tv) 28 else 32).toFloat()
                    setStroke(dp(1), Color.argb(125, 166, 222, 255))
                }
            } else {
                rounded(Color.TRANSPARENT, dp(if (tv) 24 else 30), Color.TRANSPARENT)
            }
            setPadding(dp(if (tv) 2 else 4), dp(if (tv) 4 else 7), dp(if (tv) 2 else 4), dp(if (tv) 3 else 6))
            applyTvFocusHalo(this, if (tv) 26 else 32, if (tv) 1.045f else 1.055f, 0f)
            setOnClickListener {
                animate().scaleX(0.96f).scaleY(0.96f).setDuration(65).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(115).start()
                    action()
                }.start()
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(if (active) Color.WHITE else Color.rgb(230, 236, 246))
            alpha = if (active) 1f else 0.92f
        }, LinearLayout.LayoutParams(dp(if (tv) 22 else if (active) 28 else 26), dp(if (tv) 22 else if (active) 28 else 26)).apply {
            bottomMargin = dp(if (tv) 2 else 3)
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(if (active) Color.WHITE else Color.rgb(235, 238, 246))
            textSize = if (tv) 9.4f else if (active) 11.8f else 10.8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
        })
        bottomNav.addView(box, LinearLayout.LayoutParams(0, -1, 1f).apply {
            marginStart = dp(if (tv) 4 else 5)
            marginEnd = dp(if (tv) 4 else 5)
        })
    }

    private fun nav(label: String, key: String, icon: String, action: () -> Unit) {
        val active = currentScreen == key
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = if (active) blueGradient(dp(22)) else rounded(Color.TRANSPARENT, dp(22), Color.TRANSPARENT)
            setPadding(dp(4), dp(6), dp(4), dp(4))
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply {
            text = icon
            setTextColor(if (active) white else Color.argb(210, 190, 205, 225))
            textSize = 18f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) rounded(Color.argb(35, 255, 255, 255), dp(14), Color.TRANSPARENT) else null
            setPadding(dp(10), dp(4), dp(10), dp(4))
        })
        box.addView(TextView(this).apply { text = label; setTextColor(if (active) white else muted); textSize = 10.5f; gravity = Gravity.CENTER; maxLines = 1; setPadding(0, dp(3), 0, 0) })
        bottomNav.addView(box, LinearLayout.LayoutParams(0, dp(60), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
    }

    private fun clear() {
        topBar.visibility = View.GONE
        isMainHomePage = false
        content.removeAllViews()
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = if (currentScreen == "detail" || currentScreen == "player") View.GONE else View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }
    }

    private fun movieDetailLoading(seed: JSONObject): View {
        return FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            val center = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            center.addView(ProgressBar(this@MainActivity).apply {
                isIndeterminate = true
                indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(52), dp(52)))
            addView(center, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
    }

    private fun skeletonPosterCard(width: Int, height: Int): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            alpha = 0.88f
            layoutParams = ViewGroup.MarginLayoutParams(width, height).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
                bottomMargin = dp(12)
            }
        }
        wrap.addView(FrameLayout(this).apply {
            background = rounded(Color.rgb(15, 22, 34), dp(18), Color.rgb(28, 40, 60))
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(18, 28, 42), Color.rgb(36, 48, 68), Color.rgb(18, 28, 42))).apply {
                    cornerRadius = dp(18).toFloat()
                }
            }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(-1, (height * 0.72f).roundToInt()))
        wrap.addView(View(this).apply { background = rounded(Color.rgb(22, 32, 48), dp(6), Color.TRANSPARENT) }, LinearLayout.LayoutParams(-1, dp(13)).apply { topMargin = dp(8); marginStart = dp(4); marginEnd = dp(4) })
        wrap.addView(View(this).apply { background = rounded(Color.rgb(16, 24, 38), dp(5), Color.TRANSPARENT) }, LinearLayout.LayoutParams((width * 0.62f).roundToInt(), dp(10)).apply { topMargin = dp(6); marginStart = dp(4); marginEnd = dp(4) })
        return wrap
    }

    private fun movieSpecChip(label: String, strong: Boolean = false): TextView {
        return TextView(this).apply {
            text = label.ifBlank { "-" }
            setTextColor(if (strong) Color.rgb(255, 230, 150) else white)
            textSize = 10.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            background = rounded(Color.argb(185, 10, 14, 22), dp(12), Color.argb(100, 255, 255, 255))
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
    }

    private fun posterSpecsOverlay(item: JSONObject): FrameLayout {
        val frame = FrameLayout(this)
        val rating = cleanRating(item.optString("rating"))
        val topSpecs = listOf("IMDb $rating", item.optString("year")).filter { it.isNotBlank() && it != "IMDb -" }
        val bottomSpecs = mutableListOf<String>()
        item.optString("runtime").takeIf { it.isNotBlank() }?.let { bottomSpecs.add(it) }
        if (item.optBoolean("has_dubbed")) bottomSpecs.add("دوبله")
        if (item.optBoolean("has_subtitle")) bottomSpecs.add("زیرنویس")
        item.optString("country").takeIf { it.isNotBlank() }?.let { bottomSpecs.add(it) }

        fun chipRow(specs: List<String>): HorizontalScrollView {
            val scroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                clipToPadding = false
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(6), 0, dp(6), 0)
            }
            specs.forEachIndexed { i, s ->
                row.addView(movieSpecChip(s, i == 0), LinearLayout.LayoutParams(-2, -2).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                })
            }
            scroll.addView(row)
            return scroll
        }

        if (topSpecs.isNotEmpty()) {
            frame.addView(chipRow(topSpecs.take(2)), FrameLayout.LayoutParams(-1, dp(34), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(8)
            })
        }
        if (bottomSpecs.isNotEmpty()) {
            frame.addView(chipRow(bottomSpecs), FrameLayout.LayoutParams(-1, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(8)
            })
        }
        return frame
    }

    private fun appPrefs() = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)

    private fun isLightTheme(): Boolean = false

        private fun isFa(): Boolean = (appPrefs().getString("lang_code", "fa") ?: "fa") != "en"

    private fun t(fa: String, en: String): String {
        return if ((appPrefs().getString("lang_code", "fa") ?: "fa") == "en") en else fa
    }

    private fun applyThemeColors() {
        bg = Color.rgb(1, 4, 10)
        bg2 = Color.rgb(5, 10, 20)
        panel = Color.rgb(8, 15, 28)
        panel2 = Color.rgb(13, 26, 46)
        card = Color.rgb(10, 20, 36)
        stroke = Color.rgb(54, 76, 112)
        blue = Color.rgb(0, 108, 255)
        blue2 = Color.rgb(30, 160, 255)
        gold = Color.rgb(255, 204, 74)
        white = Color.WHITE
        muted = Color.rgb(176, 190, 212)
        faint = Color.rgb(110, 130, 158)
    }

    private fun setupChoice(label: String, active: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(if (active) Color.WHITE else white)
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) {
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(20, 22, 26), Color.rgb(80, 84, 92))).apply { cornerRadius = dp(16).toFloat() }
            } else rounded(panel2, dp(16), stroke)
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun showLanguageThemeDialog() {
        var lang = appPrefs().getString("lang_code", "fa") ?: "fa"
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = rounded(Color.rgb(8, 12, 20), dp(26), stroke)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply { text = t("زبان برنامه", "App language"); setTextColor(white); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply { text = "×"; setTextColor(white); textSize = 25f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; background = rounded(Color.argb(58,255,255,255), dp(17), Color.argb(45,255,255,255)); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(TextView(this).apply { text = t("فارسی به صورت پیش‌فرض فعال است. می‌توانی زبان انگلیسی را هم انتخاب کنی.", "Persian is enabled by default. You can switch to English."); setTextColor(muted); textSize = 12.8f; gravity = Gravity.RIGHT; setPadding(0, 0, 0, dp(14)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        row.addView(setupChoice("فارسی", lang == "fa") { lang = "fa"; Toast.makeText(this, "فارسی", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        row.addView(setupChoice("English", lang == "en") { lang = "en"; Toast.makeText(this, "English", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        box.addView(TextView(this).apply {
            text = t("ذخیره", "Save")
            setTextColor(Color.WHITE); textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(139, 92, 246), Color.rgb(93, 54, 220))).apply { cornerRadius = dp(20).toFloat() }
            setOnClickListener { appPrefs().edit().putString("lang_code", lang).putString("theme_mode", "black").apply(); dialog.dismiss(); buildShell(); showHome() }
        }, LinearLayout.LayoutParams(-1, dp(52)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        if (isTvLike()) {
            applyTvFocusToClickableTree(box)
            focusFirstTvClickable(box)
        }
    }

    private fun storageKey(item: JSONObject): String {
        val id = item.optString("id").ifBlank { item.optString("movie_id") }.ifBlank { item.optString("slug") }
        val type = item.optString("type", "movie")
        val archive = item.optInt("archive", defaultArchive)
        return "$archive|$type|${id.ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }}"
    }

    private fun compactItem(item: JSONObject): JSONObject {
        val out = JSONObject()
        listOf("id", "archive", "type", "title", "title_fa", "poster", "rating", "year", "runtime", "description", "long_description", "has_dubbed", "has_subtitle").forEach { key ->
            if (item.has(key)) out.put(key, item.opt(key))
        }
        out.put("_key", storageKey(item))
        out.put("_saved_at", System.currentTimeMillis())
        return out
    }

    private fun storeItems(key: String): MutableList<JSONObject> {
        val arr = JSONArray(appPrefs().getString(key, "[]") ?: "[]")
        val list = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { list.add(it) }
        return list
    }

    private fun saveStoreItems(key: String, list: List<JSONObject>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        appPrefs().edit().putString(key, arr.toString()).apply()
    }

    private fun upsertStoreItem(key: String, item: JSONObject, limit: Int = 30) {
        val c = compactItem(item)
        val id = c.optString("_key")
        val list = storeItems(key).filter { it.optString("_key") != id }.toMutableList()
        list.add(0, c)
        saveStoreItems(key, list.take(limit))
    }

    private fun isFavorite(item: JSONObject): Boolean {
        val id = storageKey(item)
        return storeItems("favorites").any { it.optString("_key") == id }
    }

    private fun toggleFavorite(item: JSONObject) {
        val id = storageKey(item)
        val list = storeItems("favorites").toMutableList()
        val oldSize = list.size
        val filtered = list.filter { it.optString("_key") != id }.toMutableList()
        if (filtered.size == oldSize) {
            filtered.add(0, compactItem(item))
            Toast.makeText(this, "به علاقه‌مندی‌ها اضافه شد", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "از علاقه‌مندی‌ها حذف شد", Toast.LENGTH_SHORT).show()
        }
        saveStoreItems("favorites", filtered.take(60))
    }

    private fun recordHistory(item: JSONObject) {
        if (item.optString("id").isNotBlank() || item.optString("title_fa").isNotBlank() || item.optString("title").isNotBlank()) {
            // حداکثر ۱۰۰ بازدید: جدید می‌آید بالا، قدیمی‌ترین حذف می‌شود.
            upsertStoreItem("history", item, 100)
        }
    }

    private fun recordContinue(item: JSONObject, link: JSONObject) {
        if (item.length() == 0) return
        val c = compactItem(item)
        c.put("quality", link.optString("quality"))
        c.put("display_label", link.optString("display_label"))
        c.put("url", link.optString("url"))
        c.put("type_fa", linkTypeFa(link))
        c.put("season", link.optInt("season", 0))
        c.put("episode", link.optInt("episode", 0))
        val id = c.optString("_key")
        val list = storeItems("continue").filter { it.optString("_key") != id }.toMutableList()
        list.add(0, c)
        // حداکثر ۱۰۰ ادامه تماشا: نسخه جدید جایگزین نسخه قدیمی همان فیلم می‌شود.
        saveStoreItems("continue", list.take(100))
    }

    private fun clearWatchHistory() {
        if (storeItems("history").isEmpty()) {
            Toast.makeText(this, ui("تاریخچه‌ای برای پاک کردن نیست"), Toast.LENGTH_SHORT).show()
            return
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = rounded(Color.rgb(10, 14, 23), dp(24), Color.argb(100, 255, 255, 255))
        }
        box.addView(TextView(this).apply {
            text = ui("پاک کردن تاریخچه مشاهده")
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        box.addView(TextView(this).apply {
            text = ui("همه آخرین بازدیدها حذف می‌شوند. ادامه تماشا دست‌نخورده می‌ماند.")
            setTextColor(muted)
            textSize = 12.8f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        row.addView(modalButton(ui("پاک کن"), R.drawable.ic_close_clean, true) {
            saveStoreItems("history", emptyList())
            dialog.dismiss()
            Toast.makeText(this, ui("تاریخچه پاک شد"), Toast.LENGTH_SHORT).show()
            showProfile()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        row.addView(modalButton(ui("انصراف"), R.drawable.ic_more_lines, false) {
            dialog.dismiss()
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(row)
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        if (isTvLike()) {
            applyTvFocusToClickableTree(box)
            focusFirstTvClickable(box)
        }
    }
    private fun addLocalRail(page: LinearLayout, title: String, storeKey: String, emptyText: String) {
        val items = storeItems(storeKey)
        if (items.isEmpty()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) }
        }
        box.addView(sectionHeader(title) { showLocalList(title, storeKey, emptyText) })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        items.take(12).forEach { row.addView(posterCard(it, dp(122), dp(223))) }
        page.addView(box)
    }

    private fun profileCountPill(label: String, value: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(11, 20, 36), dp(18), Color.argb(110, 235, 35, 45))
            setPadding(dp(10), dp(10), dp(10), dp(10))
            addView(TextView(this@MainActivity).apply {
                text = value.toString()
                setTextColor(white)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(muted)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
            })
        }
    }

    private fun appVersionCode(): Int {
        return try {
            val p = packageManager.getPackageInfo(packageName, 0)
            if (android.os.Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else p.versionCode
        } catch (_: Throwable) { 1 }
    }

    private fun appVersionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.1"
        } catch (_: Throwable) { "1.1" }
    }

        private fun checkInternalUpdate(showToastIfLatest: Boolean = true) {
        if (showConfigUpdateIfNeeded(showToastIfLatest)) return
        if (showToastIfLatest) {
            val msg = if (!remoteUpdateEnabled) t("آپدیت از پنل غیرفعال است", "Update is disabled from the panel") else t("آپدیت جدیدی ثبت نشده است", "No update is registered")
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePill(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.rgb(255, 210, 120))
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(65, 255, 170, 20), dp(16), Color.argb(80, 255, 190, 80))
            setPadding(dp(12), 0, dp(12), 0)
        }
    }

    private fun showUpdateDialog(
        title: String,
        message: String,
        apkUrl: String,
        force: Boolean,
        latestVersion: String = "",
        installedVersion: String = appVersionName(),
        changes: List<String> = emptyList()
    ) {
        lateinit var dialog: AlertDialog
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(17, 18, 24), Color.rgb(8, 9, 14))).apply {
                cornerRadius = dp(34).toFloat()
                setStroke(dp(1), Color.argb(115, 155, 98, 255))
            }
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val icon = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(126, 70, 255), Color.rgb(88, 35, 210))).apply {
                cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(120, 255, 255, 255))
            }
            elevation = dp(10).toFloat()
        }
        icon.addView(TextView(this).apply { text = "✦"; setTextColor(Color.WHITE); textSize = 27f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, -1))
        head.addView(icon, LinearLayout.LayoutParams(dp(60), dp(60)).apply { marginStart = dp(14) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titleBox.addView(TextView(this).apply { text = title.ifBlank { t("آپدیت جدید آماده است", "Update available") }; setTextColor(Color.WHITE); textSize = 21f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        titleBox.addView(TextView(this).apply { text = if (force) t("برای ادامه باید نسخه جدید نصب شود.", "Install the latest version to continue.") else t("می‌توانید الان آپدیت کنید یا بعداً نصب کنید.", "You can update now or later."); setTextColor(Color.rgb(172, 178, 194)); textSize = 12.7f; gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0) })
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        if (!force) {
            head.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.rgb(220, 224, 238))
                textSize = 25f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.argb(58, 255, 255, 255), dp(17), Color.argb(45, 255, 255, 255))
                setOnClickListener { dialog.dismiss() }
            }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        }
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        box.addView(TextView(this).apply { text = message.ifBlank { t("نسخه جدید Bankmovie آماده دانلود است.", "A new Bankmovie version is ready to download.") }; setTextColor(Color.rgb(232, 234, 242)); textSize = 14.2f; gravity = Gravity.RIGHT; setLineSpacing(dp(3).toFloat(), 1.0f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val versions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.RIGHT }
        versions.addView(updatePill(t("آخرین نسخه  $latestVersion", "Latest  $latestVersion")), LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(8) })
        versions.addView(updatePill(t("نصب‌شده  $installedVersion", "Installed  $installedVersion")), LinearLayout.LayoutParams(-2, dp(38)))
        box.addView(versions, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        box.addView(TextView(this).apply { text = t("تغییرات نسخه", "What is new"); setTextColor(Color.WHITE); textSize = 14.8f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        val finalChanges = if (changes.isNotEmpty()) changes else listOf(t("بهبود پایداری و رفع خطاها", "Stability improvements"), t("بهبود ظاهر اپ و پلیر", "Better app and player design"), t("بهبود اتصال به سرور و مدیریت دامنه", "Improved connection and domain management"))
        val changeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.argb(72, 255, 255, 255), dp(18), Color.argb(60, 255, 255, 255)); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        finalChanges.take(7).forEach { item -> changeBox.addView(TextView(this).apply { text = "●  $item"; setTextColor(Color.rgb(226, 229, 238)); textSize = 13.2f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, dp(4)) }) }
        box.addView(changeBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        box.addView(TextView(this).apply { text = t("آپدیت الان", "Update now"); setTextColor(Color.WHITE); textSize = 15.2f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(139, 92, 246), Color.rgb(93, 54, 220))).apply { cornerRadius = dp(24).toFloat() }; setOnClickListener { openExternal(apkUrl, null) } }, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(10) })
        if (!force) box.addView(TextView(this).apply { text = t("بعداً", "Later"); setTextColor(Color.rgb(185, 150, 255)); textSize = 14.4f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(-1, dp(44)))
        dialog = AlertDialog.Builder(this).setView(scroll).setCancelable(!force).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun telegramProCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(9, 28, 48), Color.rgb(5, 14, 28))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(150, 42, 171, 238))
            }
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val head = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            head.addView(FrameLayout(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(42,171,238), Color.rgb(28,105,190))).apply { shape = GradientDrawable.OVAL }
                addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_telegram) }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
            val txt = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            txt.addView(TextView(this@MainActivity).apply {
                text = "کانال رسمی Bankmovie"
                setTextColor(white)
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            txt.addView(TextView(this@MainActivity).apply {
                text = "@BANKMOVIE_ORG"
                setTextColor(Color.rgb(150, 220, 255))
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(4), 0, 0)
            })
            head.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            addView(head)
            addView(TextView(this@MainActivity).apply {
                text = "اطلاعیه‌ها، لینک آپدیت و اخبار رفع مشکل اینترنت اینجا قرار می‌گیرد."
                setTextColor(muted)
                textSize = 12.2f
                gravity = Gravity.RIGHT
                setPadding(0, dp(12), 0, dp(12))
            })
            addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(50)))
        }
    }

    private fun showTelegramCardDialog() {
        AlertDialog.Builder(this).setView(telegramProCard()).show()
    }

    private fun showProfile() {
        currentScreen = "profile"
        buildBottomNav()
        clear()
        isMainHomePage = true
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(100))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(14), dp(12), dp(28))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(35, 12, 22), Color.rgb(9, 16, 29))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(140, 235, 35, 45))
            }
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        header.addView(TextView(this).apply {
            text = t("پروفایل", "Profile")
            setTextColor(white)
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        header.addView(TextView(this).apply {
            text = t("ادامه تماشا، واچ‌لیست و آخرین بازدیدها اینجا ذخیره می‌شود", "Continue watching, watchlist and recent visits are saved here")
            setTextColor(muted)
            textSize = 12.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, 0)
        })
        page.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        stats.addView(profileCountPill(t("واچ‌لیست", "Watchlist"), storeItems("favorites").size), LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginStart = dp(7) })
        stats.addView(profileCountPill(t("ادامه", "Continue"), storeItems("continue").size), LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginStart = dp(7); marginEnd = dp(7) })
        stats.addView(profileCountPill(t("بازدید", "History"), storeItems("history").size), LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginEnd = dp(7) })
        page.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        page.addView(telegramProCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        page.addView(modalButton(t("زبان برنامه", "App language"), R.drawable.ic_more_lines, false) { showLanguageThemeDialog() }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })
        page.addView(modalButton(t("بررسی آپدیت داخلی", "Check Update"), R.drawable.ic_download, false) { checkInternalUpdate(true) }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })
        page.addView(modalButton(t("پاک کردن تاریخچه مشاهده", "Clear watch history"), R.drawable.ic_close_clean, true) { clearWatchHistory() }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(16) })

        val before = page.childCount
        addLocalRail(page, ui("ادامه تماشا"), "continue", ui("هنوز چیزی برای ادامه تماشا نداری"))
        addLocalRail(page, ui("واچ‌لیست"), "favorites", ui("واچ‌لیست خالی است"))
        addLocalRail(page, ui("آخرین بازدیدها"), "history", ui("هنوز فیلمی باز نکردی"))
        if (page.childCount == before) {
            page.addView(errorView(ui("هنوز چیزی ذخیره نشده")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
        }
    }

    private fun removeStoreItem(storeKey: String, item: JSONObject) {
        val id = item.optString("_key").ifBlank { storageKey(item) }
        val list = storeItems(storeKey).filter { it.optString("_key") != id }
        saveStoreItems(storeKey, list)
        Toast.makeText(this, "حذف شد", Toast.LENGTH_SHORT).show()
    }

    private fun openStoredContinue(item: JSONObject) {
        val url = item.optString("url")
        if (url.isBlank()) {
            showDetail(item)
            return
        }
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "Bankmovie" }
        val arr = JSONArray().put(JSONObject().apply {
            put("url", url)
            put("title", title)
            put("quality", item.optString("quality"))
            put("display_label", item.optString("display_label"))
            put("type_fa", item.optString("type_fa"))
            put("type", item.optString("type"))
            put("season", item.optInt("season", 0))
            put("episode", item.optInt("episode", 0))
        })
        val payload = JSONObject().apply {
            put("video", url)
            put("title", title)
            put("selectedIndex", 0)
            put("tracks", arr)
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, url)
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, payload.toString())
        })
    }

    private fun progressTextFor(item: JSONObject): String {
        val url = item.optString("url")
        if (url.isBlank()) return ""
        val ms = appPrefs().getLong("progress_$url", 0L)
        if (ms <= 0L) return ""
        val totalSec = ms / 1000L
        val m = totalSec / 60L
        val s = totalSec % 60L
        return String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun profileStoredCard(storeKey: String, item: JSONObject): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))

            if (storeKey == "continue") {
                val frame = FrameLayout(this@MainActivity).apply {
                    background = rounded(card, dp(15), stroke)
                    setOnClickListener { openStoredContinue(item) }
                    applyTvFocusHalo(this, 16, 1.035f, 0f)
                }
                val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                frame.addView(img, FrameLayout.LayoutParams(-1, -1))
                loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, img)
                frame.addView(View(this@MainActivity).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(232, 0, 0, 0)))
                }, FrameLayout.LayoutParams(-1, -1))
                frame.addView(TextView(this@MainActivity).apply {
                    text = "▶"
                    setTextColor(white)
                    textSize = 19f
                    gravity = Gravity.CENTER
                    background = rounded(Color.argb(135, 0, 0, 0), dp(20), Color.argb(180, 255, 255, 255))
                }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
                val overlay = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.BOTTOM or Gravity.RIGHT
                    setPadding(dp(7), dp(7), dp(7), dp(8))
                }
                overlay.addView(TextView(this@MainActivity).apply {
                    text = item.optString("title_fa").ifBlank { item.optString("title") }
                    setTextColor(white)
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                val watched = listOf(item.optString("quality"), item.optString("type_fa")).filter { it.isNotBlank() }.joinToString(" • ")
                overlay.addView(TextView(this@MainActivity).apply {
                    text = if (watched.isNotBlank()) "این نسخه را دیدید • $watched" else "این را دیدید"
                    setTextColor(Color.rgb(255, 205, 120))
                    textSize = 9.6f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
                addView(frame, LinearLayout.LayoutParams(dp(116), dp(206)))
                val p = progressTextFor(item)
                if (p.isNotBlank()) addView(TextView(this@MainActivity).apply {
                    text = "ادامه از $p"
                    setTextColor(Color.rgb(255, 205, 120))
                    textSize = 10.8f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    background = rounded(Color.rgb(24, 28, 42), dp(12), Color.argb(80,255,255,255))
                }, LinearLayout.LayoutParams(-1, dp(28)).apply { topMargin = dp(2) })
                return@apply
            }

            addView(posterCard(item, dp(116), dp(206)))
            if (storeKey == "favorites") {
                addView(TextView(this@MainActivity).apply {
                    text = "حذف از واچ‌لیست"
                    setTextColor(white)
                    textSize = 10.5f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    background = rounded(Color.rgb(150, 18, 30), dp(12), Color.TRANSPARENT)
                    setOnClickListener {
                        removeStoreItem(storeKey, item)
                        showLocalList("واچ‌لیست", "favorites", "واچ‌لیست خالی است")
                    }
                }, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(4) })
            }
        }
    }

    private fun showLocalList(title: String, storeKey: String, emptyText: String) {
        currentScreen = if (storeKey == "favorites") "profile" else "profile"
        buildBottomNav()
        clear()
        val scroll = ScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(100)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(title))
        val items = storeItems(storeKey)
        if (items.isEmpty()) {
            page.addView(emptyStateBox(emptyText, "برای ذخیره، از صفحه فیلم استفاده کن"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(30) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 3 }
        page.addView(grid)
        items.forEach { grid.addView(profileStoredCard(storeKey, it), ViewGroup.MarginLayoutParams(dp(122), -2).apply { marginStart = dp(4); marginEnd = dp(4); bottomMargin = dp(10) }) }
    }

    private fun copyLink(url: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("download_link", url))
        Toast.makeText(this, "لینک کپی شد", Toast.LENGTH_SHORT).show()
    }

    private fun modalButton(label: String, iconRes: Int, red: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (red) GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(235, 35, 45), Color.rgb(170, 18, 34))).apply { cornerRadius = dp(15).toFloat() }
            else rounded(Color.rgb(15, 25, 42), dp(15), Color.argb(105, 90, 120, 165))
            setPadding(dp(10), 0, dp(10), 0)
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                if (iconRes != R.drawable.adm_logo_transparent && iconRes != R.drawable.ic_chrome) setColorFilter(white)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(white)
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun showDownloadChoiceModal(link: JSONObject) {
        val url = link.optString("url")
        if (url.isBlank()) {
            Toast.makeText(this, "لینک دانلود نامعتبر است", Toast.LENGTH_SHORT).show()
            return
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = rounded(Color.rgb(7, 12, 22), dp(24), Color.argb(150, 235, 35, 45))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, dp(12))
        }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.adm_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titles.addView(TextView(this).apply {
            text = "دانلود فایل"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = link.optString("display_label").ifBlank { link.optString("quality").ifBlank { "نسخه انتخاب‌شده" } }
            setTextColor(Color.rgb(188, 198, 214))
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(head)
        box.addView(modalButton("ADM", R.drawable.adm_logo_transparent, true) { openExternal(url, "com.dv.adm") }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })
        box.addView(modalButton(if (isFa()) "دانلود با Chrome" else "Download with Chrome", R.drawable.ic_chrome, false) { openExternal(url, "com.android.chrome") }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })
        box.addView(modalButton("دانلود مستقیم", R.drawable.ic_download, false) { openExternal(url, null) }, LinearLayout.LayoutParams(-1, dp(46)))
        AlertDialog.Builder(this).setView(box).show()
    }

    private fun showHome() {
        currentScreen = "home"
        buildBottomNav()
        clear()
        isMainHomePage = true
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(120))
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(34))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(siteSlider(bootJson?.optJSONArray("sliders") ?: JSONArray()))
        addQuickTabs(page)

        addRail(page, "فیلم‌های بروز شده", defaultArchive, "updated_movies", false)
        addRail(page, "سریال‌های بروز شده", defaultArchive, "updated_series", false)
        addSearchRail(page, "سریال‌های کره‌ای", "سریال کره ای", "series")
        addSearchRail(page, "دوبله فارسی", "دوبله فارسی", "all")
        addSearchRail(page, "برترین‌های 2026", "2026", "all")
        addRail(page, "انیمه", defaultArchive, "anime", false)
        addRail(page, "ترکی", defaultArchive, "turkish", false)
        addCollectionsRail(page)

        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(54)).apply {
            topMargin = dp(12)
            bottomMargin = dp(10)
        })
    }

    private fun openTelegramChannel() {
        openExternal("https://t.me/BANKMOVIE_ORG", "org.telegram.messenger")
    }

        private fun fancySpinnerText(textValue: String, subValue: String = ""): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            addView(ProgressBar(this@MainActivity).apply {
                isIndeterminate = true
                indeterminateTintList = android.content.res.ColorStateList.valueOf(Color.rgb(139, 92, 246))
            }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { bottomMargin = dp(12) })
            addView(TextView(this@MainActivity).apply { text = ui(textValue); setTextColor(white); textSize = 15f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
            if (subValue.isNotBlank()) addView(TextView(this@MainActivity).apply {
                text = ui(subValue)
                setTextColor(muted)
                textSize = 11.7f
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(6), 0, 0)
            })
        }
    }

    private fun friendlyError(raw: String?): String {
        val s = raw ?: ""
        return when {
            s.contains("unexpected", true) ||
            s.contains("stream", true) ||
            s.contains("okhttp", true) ||
            s.contains("Address", true) ||
            s.contains("timeout", true) ||
            s.contains("failed", true) ||
            s.contains("Unable", true) -> "اتصال کامل برقرار نشد. اینترنت را عوض کن یا برنامه را ببند و دوباره باز کن."
            s.isBlank() -> "اطلاعات این بخش فعلاً لود نشد. دوباره تلاش کن."
            else -> "اطلاعات این بخش فعلاً لود نشد. دوباره تلاش کن."
        }
    }

        private fun errorView(message: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.argb(78, 255, 255, 255), dp(18), Color.argb(75, 255, 255, 255))
            setPadding(dp(14), dp(18), dp(14), dp(18))
            addView(TextView(this@MainActivity).apply {
                text = friendlyError(message)
                setTextColor(Color.rgb(226, 232, 244))
                textSize = 12.8f
                gravity = Gravity.CENTER
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun emptyStateBox(title: String, sub: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(9, 16, 29), dp(22), Color.argb(90, 95, 120, 160))
            setPadding(dp(18), dp(30), dp(18), dp(30))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.bankmovie_logo_transparent)
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
            }, LinearLayout.LayoutParams(dp(126), dp(54)).apply { bottomMargin = dp(14) })
            addView(TextView(this@MainActivity).apply { text = ui(title); setTextColor(white); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply {
                text = if (title.contains("خطا")) friendlyError(sub) else ui(sub)
                setTextColor(muted)
                textSize = 12.2f
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            })
            if (title.contains("خطا")) {
                addView(TextView(this@MainActivity).apply {
                    text = ui("بارگذاری دوباره")
                    setTextColor(Color.WHITE)
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = blueGradient(dp(18))
                    setPadding(dp(20), 0, dp(20), 0)
                    applyTvFocusHalo(this, 18, 1.04f, 0f)
                    setOnClickListener { recreate() }
                }, LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(16) })
            }
        }
    }

        private fun telegramJoinButton(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(20, 162, 229), Color.rgb(34, 143, 222))).apply { cornerRadius = dp(18).toFloat() }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            minimumHeight = dp(54)
            isClickable = true
            isFocusable = true
            setOnClickListener { openTelegramChannel() }
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_telegram); alpha = 0.98f }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = ui("کانال تلگرام @BANKMOVIE_ORG")
                setTextColor(Color.WHITE)
                textSize = 13.4f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun homeSearchHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(14), 0, dp(12))
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(104), dp(44)).apply { marginStart = dp(9) })

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 20, 34), dp(23), Color.argb(135, 235, 35, 45))
            setPadding(dp(13), 0, dp(13), 0)
            setOnClickListener { showSearch() }
        }
        pill.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_search_clean)
            setColorFilter(Color.rgb(160, 170, 188))
        }, LinearLayout.LayoutParams(dp(23), dp(23)).apply { marginStart = dp(9) })
        pill.addView(TextView(this).apply {
            text = "جستجو..."
            setTextColor(Color.rgb(160, 170, 188))
            textSize = 14.5f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 1
        }, LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(pill, LinearLayout.LayoutParams(0, dp(48), 1f))
        return row
    }

    private fun searchResultRow(item: JSONObject): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(Color.TRANSPARENT, dp(0), Color.TRANSPARENT)
            applyTvFocusHalo(this, 18, 1.03f, 0f)
            isFocusable = true
            isFocusableInTouchMode = false
            setOnClickListener { showDetail(item) }
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(20, 30, 45), dp(8), Color.TRANSPARENT)
            clipToOutline = true
        }
        loadImage(item.optString("poster").ifBlank { item.optString("image") }, poster)
        row.addView(poster, LinearLayout.LayoutParams(dp(58), dp(82)).apply { marginStart = dp(14) })
        row.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -1, 1f))
        return row
    }

    private fun siteSlider(items: JSONArray): View {
        val count = items.length().coerceAtMost(8)
        val frame = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(485)).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = dp(18)
            }
            elevation = dp(14).toFloat()
            clipToPadding = false
        }

        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))

        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(20, 0, 0, 0),
                    Color.argb(60, 0, 0, 0),
                    Color.argb(205, 2, 6, 12)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(
                    Color.argb(130, 0, 0, 0),
                    Color.argb(35, 0, 0, 0),
                    Color.TRANSPARENT
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        val header = FrameLayout(this).apply { setPadding(dp(18), dp(12), dp(18), 0) }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, FrameLayout.LayoutParams(dp(112), dp(44), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(8) })
        header.addView(svgIconButton(R.drawable.ic_search_clean) { showSearch() }, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(6) })
        frame.addView(header, FrameLayout.LayoutParams(-1, dp(76), Gravity.TOP))

        val contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            setPadding(dp(22), dp(18), dp(22), dp(32))
        }
        val genre = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(110, 0, 0, 0), dp(16), Color.argb(80, 255, 255, 255))
            setPadding(dp(12), dp(6), dp(12), dp(6))
        }
        val title = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(6f, 0f, 2f, Color.argb(160, 0, 0, 0))
        }
        val desc = TextView(this).apply {
            setTextColor(Color.argb(232, 238, 240, 246))
            textSize = 13.3f
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setLineSpacing(dp(2).toFloat(), 1.0f)
            setPadding(0, dp(8), 0, dp(14))
        }
        val meta = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val currentIndex = intArrayOf(0)
        val watchButton = iconActionButton(t("تماشا کنید", "Watch Now"), R.drawable.ic_play_fill, true) {
            val item = items.optJSONObject(currentIndex[0]) ?: return@iconActionButton
            val seed = seedFromSlider(item)
            if (seed != null) showDetail(seed)
        }

        contentBox.addView(genre, LinearLayout.LayoutParams(-2, dp(34)).apply { gravity = Gravity.RIGHT; bottomMargin = dp(8) })
        contentBox.addView(title)
        contentBox.addView(meta, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(8) })
        contentBox.addView(desc)
        contentBox.addView(watchButton, LinearLayout.LayoutParams(-1, dp(54)))
        frame.addView(contentBox, FrameLayout.LayoutParams(-1, -1))

        val dots = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        frame.addView(dots, FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(14)
        })

        fun sliderImage(item: JSONObject): String {
            return item.optString("image")
                .ifBlank { item.optString("backdrop") }
                .ifBlank { item.optString("poster") }
        }

        fun bind(idx: Int, animate: Boolean) {
            val item = items.optJSONObject(idx) ?: return
            loadImage(sliderImage(item), image)

            val genreText = item.optJSONArray("genres")?.let { arr ->
                (0 until arr.length()).mapNotNull { i -> arr.optString(i).takeIf { s -> s.isNotBlank() } }.joinToString(" • ")
            }.orEmpty().ifBlank { item.optString("type") }

            if (genreText.isBlank()) {
                genre.visibility = View.GONE
            } else {
                genre.visibility = View.VISIBLE
                genre.text = genreText
            }
            title.text = item.optString("title_fa").ifBlank { item.optString("title") }
            val sliderDesc = item.optString("subtitle_fa")
                .ifBlank { item.optString("subtitle") }
                .ifBlank { item.optString("description") }
                .trim()
            desc.text = sliderDesc
            desc.visibility = if (sliderDesc.isBlank() || sliderDesc.equals("null", true)) View.GONE else View.VISIBLE

            meta.removeAllViews()
            val rating = item.optDouble("rating", 0.0)
            if (rating > 0) {
                meta.addView(alphaPill("IMDb ${String.format(Locale.US, "%.1f", rating)}", true), LinearLayout.LayoutParams(-2, dp(32)).apply { marginStart = dp(7) })
            }
            item.optString("title").takeIf { it.isNotBlank() }?.let {
                meta.addView(alphaPill(t("ویژه", "Featured"), false), LinearLayout.LayoutParams(-2, dp(32)).apply { marginStart = dp(7) })
            }

            dots.removeAllViews()
            repeat(count.coerceAtLeast(1)) { i ->
                dots.addView(View(this).apply {
                    background = rounded(if (i == idx) Color.WHITE else Color.argb(100, 255, 255, 255), dp(4), Color.TRANSPARENT)
                }, LinearLayout.LayoutParams(if (i == idx) dp(26) else dp(8), dp(8)).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                })
            }

            if (animate) {
                contentBox.alpha = 0f
                contentBox.translationY = dp(14).toFloat()
                contentBox.animate().alpha(1f).translationY(0f).setDuration(220).start()
            }
        }

        if (count > 0) {
            bind(0, false)

            val auto = object : Runnable {
                override fun run() {
                    if (count > 1) {
                        currentIndex[0] = (currentIndex[0] + 1) % count
                        bind(currentIndex[0], true)
                        frame.postDelayed(this, 3600)
                    }
                }
            }
            frame.postDelayed(auto, 3600)

            var downX = 0f
            frame.setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = ev.x; true }
                    MotionEvent.ACTION_UP -> {
                        val dx = ev.x - downX
                        if (kotlin.math.abs(dx) > dp(36)) {
                            currentIndex[0] = if (dx < 0) (currentIndex[0] + 1) % count else (currentIndex[0] - 1 + count) % count
                            bind(currentIndex[0], true)
                            true
                        } else {
                            val item = items.optJSONObject(currentIndex[0])
                            val seed = if (item != null) seedFromSlider(item) else null
                            if (seed != null) showDetail(seed)
                            true
                        }
                    }
                    else -> true
                }
            }
        }
        return frame
    }

    private fun addCollectionsRail(page: LinearLayout) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader("کالکشن‌ها") { showCollections() })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        fetch("$apiBase?action=collections&page=1&limit=12") { ok, json, err ->
            runOnUiThread {
                if (!ok || json == null) {
                    row.addView(errorView(err ?: "خطا در دریافت کالکشن‌ها"))
                    return@runOnUiThread
                }
                val items = json.optJSONArray("items") ?: JSONArray()
                for (i in 0 until minOf(items.length(), 12)) items.optJSONObject(i)?.let { row.addView(collectionCard(it)) }
            }
        }
    }

        private fun collectionCard(item: JSONObject): View {
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { item.optString("name") }
        val cover = item.optString("cover_image")
            .ifBlank { item.optString("poster") }
            .ifBlank { item.optString("image") }
            .ifBlank { item.optString("backdrop") }

        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(8, 14, 27), dp(25), Color.argb(88, 150, 125, 255))
            layoutParams = ViewGroup.MarginLayoutParams(dp(178), dp(126)).apply { marginStart = dp(7); marginEnd = dp(7) }
            elevation = dp(10).toFloat()
            applyTvFocusHalo(this, 28, 1.07f, dp(4).toFloat())
            setOnClickListener { showCollectionItems(item.optString("slug"), title) }
        }

        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.96f
        }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(cover, img)

        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(10, 0, 0, 0),
                    Color.argb(68, 0, 0, 0),
                    Color.argb(238, 0, 0, 0)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(Color.argb(165, 5, 7, 14), Color.argb(45, 5, 7, 14), Color.TRANSPARENT)
            )
        }, FrameLayout.LayoutParams(-1, -1))

        frame.addView(TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(8f, 0f, 2f, Color.BLACK)
            setPadding(dp(13), dp(10), dp(13), dp(34))
        }, FrameLayout.LayoutParams(-1, -1))

        val count = item.optInt("movie_count", item.optInt("count", 0))
        if (count > 0) frame.addView(TextView(this).apply {
            text = if (isFa()) "$count عنوان" else "$count titles"
            setTextColor(Color.WHITE)
            textSize = 10.3f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(121, 61, 240), Color.rgb(70, 43, 160))).apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.argb(105, 255, 255, 255))
            }
            setPadding(dp(10), dp(4), dp(10), dp(4))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(10)
            bottomMargin = dp(8)
        })

        return frame
    }

    private fun showCollections() {
        currentScreen = "collections"
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(108))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(t("کالکشن‌ها", "Collections")))
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 4 else 2
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, -2))
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(110) })

        fun loadCollections(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.isEnabled = false
            fetch("$apiBase?action=collections&page=$p&limit=24") { ok, json, err ->
                runOnUiThread {
                    more.isEnabled = true
                    if (!ok || json == null) {
                        more.text = t("تلاش مجدد", "Retry")
                        Toast.makeText(this, friendlyError(err), Toast.LENGTH_SHORT).show()
                        return@runOnUiThread
                    }
                    val items = json.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until items.length()) items.optJSONObject(i)?.let {
                        val card = collectionCard(it)
                        card.layoutParams = ViewGroup.MarginLayoutParams(if (tv) dp(260) else dp(168), if (tv) dp(170) else dp(132)).apply {
                            marginStart = dp(6)
                            marginEnd = dp(6)
                            bottomMargin = dp(12)
                        }
                        grid.addView(card)
                    }
                    if (json.optBoolean("has_more", false)) {
                        val next = json.optInt("next_page", p + 1)
                        more.visibility = View.VISIBLE
                        more.text = t("مشاهده بیشتر", "Load more")
                        more.setOnClickListener { loadCollections(next) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadCollections(1)
    }

        private fun showCollectionItems(slug: String, title: String) {
        currentScreen = "collections"
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.VISIBLE
        val tv = isTvLike()
        val scroll = ScrollView(this).apply { layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL; setPadding(0, 0, 0, dp(108)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) { gravity = Gravity.LEFT; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(title))
        val grid = GridLayout(this).apply { columnCount = if (tv) 8 else 3; layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        val more = moreButton(ui("صفحه بعد")) { }
        page.addView(more)
        val cardW = if (tv) tvGridCardWidth() else dp(116)
        val cardH = if (tv) tvGridCardHeight(cardW) else dp(252)
        val limit = if (tv) 24 else 24
        fun loadItems(p: Int) {
            more.text = ui("در حال بارگذاری...")
            more.isEnabled = false
            fetch("$apiBase?action=collection&slug=${enc(slug)}&page=$p&limit=$limit") { ok, json, err ->
                runOnUiThread {
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت کالکشن", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = ui("تلاش مجدد")
                        more.setOnClickListener { loadItems(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }
                    val items = json.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until items.length()) items.optJSONObject(i)?.let { grid.addView(posterCard(it, cardW, cardH)) }
                    if (json.optBoolean("has_more", false) || items.length() >= limit) {
                        val next = json.optInt("next_page", p + 1)
                        more.visibility = View.VISIBLE
                        more.text = ui("صفحه بعد")
                        more.setOnClickListener { loadItems(next) }
                    } else more.visibility = View.GONE
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadItems(1)
    }

    private fun addQuickTabs(page: LinearLayout) {
        val hsv = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        hsv.addView(row)
        val tabs = listOf(
            Triple("✓ ${t("جدیدترین", "Newest")}", defaultArchive, "updated_movies"),
            Triple(t("فیلم", "Movies"), defaultArchive, "updated_movies"),
            Triple(t("سریال", "Series"), defaultArchive, "updated_series"),
            Triple(t("دوبله", "Dubbed"), defaultArchive, "dubbed"),
            Triple("IMDb", defaultArchive, "imdb"),
            Triple(t("کالکشن", "Collections"), defaultArchive, "collections")
        )
        tabs.forEachIndexed { idx, tab ->
            val v = chip(tab.first, idx == 0)
            v.setOnClickListener {
                when (tab.third) {
                    "collections" -> showCollections()
                    "dubbed" -> showKeywordList(t("دوبله فارسی", "Persian Dubbed"), "دوبله فارسی", "all")
                    "imdb" -> showKeywordList(t("IMDb بالا", "Top IMDb"), "imdb 8", "all")
                    else -> showList(tab.first.replace("✓ ", ""), tab.second, tab.third)
                }
            }
            row.addView(v, LinearLayout.LayoutParams(-2, dp(44)).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        page.addView(hsv, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(12) })
    }

    private fun addSearchRail(page: LinearLayout, title: String, query: String, typeFilter: String = "all") {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader(title) { showKeywordList(title, query, typeFilter) })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        repeat(6) { row.addView(skeletonPosterCard(dp(122), dp(223))) }

        fetch("$apiBase?action=live_search&archive=$defaultArchive&q=${enc(query)}&page=1&limit=24") { ok, json, err ->
            runOnUiThread {
                row.removeAllViews()
                if (!ok || json == null) {
                    row.addView(errorView(err ?: "خطا در دریافت اطلاعات"))
                    return@runOnUiThread
                }
                val items = json.optJSONArray("items") ?: JSONArray()
                var added = 0
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i) ?: continue
                    if (!searchAcceptsType(item, typeFilter)) continue
                    row.addView(posterCard(item, dp(134), dp(244)))
                    added++
                    if (added >= 12) break
                }
                if (added == 0) row.addView(emptyStateBox("چیزی پیدا نشد", title))
            }
        }
    }

    private fun showKeywordList(title: String, query: String, typeFilter: String = "all") {
        currentScreen = "home"
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(if (tv) 82 else 100))
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(title))
        val loading = fancySpinnerText("در حال آماده‌سازی لیست", title)
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        val seen = mutableSetOf<String>()
        val perPage = if (tv) 24 else 24
                val cardW = if (tv) tvGridCardWidth() else dp(116)
        val cardH = if (tv) tvGridCardHeight(cardW) else dp(222)

        page.addView(loading, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "${ui("مشاهده نتایج بیشتر")}  ${seen.size}" else ui("مشاهده نتایج بیشتر")
        }

        fun loadPage(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false
            fetch("$apiBase?action=live_search&archive=$defaultArchive&q=${enc(query)}&page=$p&limit=$perPage") { ok, json, err ->
                runOnUiThread {
                    loading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت اطلاعات", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = ui("تلاش دوباره")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (!searchAcceptsType(item, typeFilter)) continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    if (grid.childCount == 0) {
                        page.addView(emptyStateBox("چیزی پیدا نشد", "بعداً دوباره امتحان کن"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        more.visibility = View.GONE
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val next = json.optInt("next_page", p + 1)
                    val total = json.optInt("total", json.optInt("total_count", json.optInt("all_count", 0)))
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p || (total > 0 && seen.size < total)
                    val guessedMore = arr.length() >= perPage
                    val canLoadMore = serverHasMore || guessedMore

                    if (canLoadMore && added > 0) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(if (next > p) next else p + 1) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

    private fun addRail(page: LinearLayout, title: String, archive: Int, section: String, progressCards: Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader(title) { showList(title, archive, section) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        repeat(6) { row.addView(skeletonPosterCard(dp(122), dp(223))) }

        fetch("$apiBase?action=section&archive=$archive&section=$section&page=1&limit=24") { ok, json, err ->
            runOnUiThread {
                row.removeAllViews()
                if (!ok || json == null) {
                    row.addView(errorView(err ?: "خطا در دریافت اطلاعات"))
                    return@runOnUiThread
                }
                val items = json.optJSONArray("items") ?: JSONArray()
                for (i in 0 until minOf(items.length(), if (progressCards) 8 else 12)) {
                    val item = items.optJSONObject(i) ?: continue
                    row.addView(if (progressCards) continueCard(item) else posterCard(item, dp(134), dp(244)))
                }
            }
        }
    }

    private fun paperSlider(items: List<JSONObject>): View {
        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(5, 10, 18), dp(28), Color.TRANSPARENT)
        }

        fun backCard(item: JSONObject?, w: Int, h: Int, gravity: Int, margin: Int, alphaValue: Float) {
            val card = heroMiniCard(item, false).apply { alpha = alphaValue }
            val lp = FrameLayout.LayoutParams(dp(w), dp(h), gravity).apply {
                leftMargin = dp(margin)
                rightMargin = dp(margin)
                topMargin = dp(22)
            }
            frame.addView(card, lp)
        }

        backCard(items.getOrNull(2), 120, 162, Gravity.LEFT or Gravity.TOP, 12, 0.36f)
        backCard(items.getOrNull(1), 138, 176, Gravity.LEFT or Gravity.TOP, 42, 0.55f)
        backCard(items.getOrNull(4), 120, 162, Gravity.RIGHT or Gravity.TOP, 12, 0.36f)
        backCard(items.getOrNull(3), 138, 176, Gravity.RIGHT or Gravity.TOP, 42, 0.55f)

        frame.addView(heroMiniCard(items.getOrNull(0), true), FrameLayout.LayoutParams(dp(190), dp(210), Gravity.CENTER))

        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(6) { i ->
            dots.addView(View(this).apply {
                background = rounded(if (i == 0) blue else Color.rgb(80, 92, 112), dp(4), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(if (i == 0) dp(18) else dp(7), dp(7)).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            })
        }
        frame.addView(dots, FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(4) })
        return frame
    }

    private fun heroMiniCard(item: JSONObject?, main: Boolean): View {
        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(10, 18, 32), dp(if (main) 18 else 16), Color.rgb(72, 89, 112))
            setOnClickListener { item?.let { showDetail(it) } }
        }

        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = if (main) 0.90f else 0.72f
        }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        item?.optString("poster")?.let { loadImage(it, img) }

        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(230, 0, 0, 0)))
        }, FrameLayout.LayoutParams(-1, -1))

        if (main) {
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setPadding(dp(10), dp(8), dp(10), dp(13))
            }
            info.addView(TextView(this).apply {
                text = item?.optString("title_fa")?.ifBlank { item.optString("title") } ?: "BANK MOVIE"
                setTextColor(white)
                textSize = 23f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                letterSpacing = 0.06f
            })
            info.addView(TextView(this).apply {
                text = if (item != null) "Bankmovie • ${item.optString("year")}" else "آرشیو ۱ به صورت پیش‌فرض"
                setTextColor(muted)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
            })
            info.addView(TextView(this).apply {
                text = "مشاهده"
                setTextColor(white)
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = blueGradient(dp(13))
                setPadding(dp(18), dp(4), dp(18), dp(4))
            }, LinearLayout.LayoutParams(dp(104), dp(30)).apply { topMargin = dp(8) })
            frame.addView(info, FrameLayout.LayoutParams(-1, -1))
        }

        return frame
    }

    private fun continueCard(item: JSONObject): View {
        val frame = FrameLayout(this).apply {
            background = rounded(card, dp(15), stroke)
            layoutParams = ViewGroup.MarginLayoutParams(dp(104), dp(148)).apply {
                marginStart = dp(6)
                marginEnd = dp(6)
            }
            setOnClickListener { showDetail(item) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, img)

        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(230, 0, 0, 0)))
        }, FrameLayout.LayoutParams(-1, -1))

        frame.addView(TextView(this).apply {
            text = "▶"
            setTextColor(white)
            textSize = 19f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(135, 0, 0, 0), dp(20), Color.argb(180, 255, 255, 255))
        }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.RIGHT
            setPadding(dp(7), dp(7), dp(7), dp(8))
        }
        info.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = item.optString("update_note").ifBlank { item.optString("type") }
            setTextColor(muted)
            textSize = 10f
            maxLines = 1
        })
        info.addView(View(this).apply { background = blueGradient(dp(2)) }, LinearLayout.LayoutParams(dp(52), dp(3)).apply { topMargin = dp(5) })
        frame.addView(info, FrameLayout.LayoutParams(-1, -1))
        return frame
    }

        private fun moreButton(textValue: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = ui(textValue)
            setTextColor(white)
            textSize = 13.6f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(alphaSurface2(), dp(20), alphaLine(95))
            setPadding(dp(16), 0, dp(16), 0)
            applyTvFocusHalo(this, 22, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun sectionHeader(title: String, more: () -> Unit): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(2), dp(8), dp(2), dp(14))
        }
        row.addView(TextView(this).apply {
            text = ui("مشاهده همه ‹")
            setTextColor(Color.WHITE)
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(72, 255, 255, 255), dp(18), Color.argb(58, 255, 255, 255))
            setPadding(dp(12), 0, dp(12), 0)
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener { more() }
        }, LinearLayout.LayoutParams(dp(112), dp(40)).apply { marginEnd = dp(14) })
        row.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, Color.rgb(235, 35, 45))).apply { cornerRadius = dp(2).toFloat() }
        }, LinearLayout.LayoutParams(0, dp(4), 1f).apply { marginEnd = dp(14) })
        row.addView(TextView(this).apply {
            text = ui(title)
            setTextColor(white)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-2, dp(46)))
        return row
    }

    private fun showList(title: String, archive: Int, section: String) {
        currentScreen = if (archive == 1) "archive1" else if (section.contains("series")) "series" else "home"
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = ScrollView(this).apply { layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(title))
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        val perPage = if (tv) 24 else 24
                val cardW = if (tv) tvGridCardWidth() else dp(116)
        val cardH = if (tv) tvGridCardHeight(cardW) else dp(222)
        val seen = mutableSetOf<String>()

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "مشاهده بیشتر  ${seen.size}" else "مشاهده بیشتر"
        }

        repeat(if (tv) 16 else 9) { grid.addView(skeletonPosterCard(cardW, cardH)) }

        fun loadPage(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false
            fetch("$apiBase?action=section&archive=$archive&section=$section&page=$p&limit=$perPage") { ok, json, err ->
                runOnUiThread {
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت اطلاعات", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = t("تلاش مجدد", "Retry")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    if (p == 1) grid.removeAllViews()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    val next = json.optInt("next_page", p + 1)
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p
                    val guessedMore = arr.length() >= perPage
                    val canLoadMore = serverHasMore || guessedMore

                    if (canLoadMore && added > 0) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(if (next > p) next else p + 1) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

        private fun listTop(title: String): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, dp(14)) }
        box.addView(TextView(this).apply { text = ui(title); setTextColor(white); textSize = 24f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), dp(4), dp(2), dp(4)) })
        box.addView(TextView(this).apply { text = ui("ظاهر سینمایی و مرتب برای مرور سریع"); setTextColor(muted); textSize = 12f; setPadding(dp(2), 0, dp(2), dp(10)) })
        return box
    }

    private fun showCategories() {
        currentScreen = "categories"
        buildBottomNav()
        clear()

        val scroll = ScrollView(this).apply { clipToPadding = false; setPadding(0,0,0,dp(100)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(TextView(this).apply {
            text = "فیلترها"
            setTextColor(white)
            textSize = 23f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(12))
        })
        val groups = linkedMapOf(
            "نوع محتوا" to listOf("همه", "فیلم", "سریال"),
            "وضعیت" to listOf("دوبله", "زیرنویس", "IMDb بالا"),
            "سال" to listOf("2026", "2025", "2024", "2023", "قدیمی‌تر"),
            "کشور" to listOf("آمریکا", "ایران", "کره", "ترکیه", "هند"),
            "ژانر" to listOf("اکشن", "درام", "ترسناک", "انیمیشن", "جنایی", "کمدی", "رازآلود", "تاریخی", "خانوادگی", "علمی تخیلی")
        )
        groups.forEach { group ->
            page.addView(sectionHeader(group.key) { })
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val sc = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
            group.value.forEach { label ->
                row.addView(TextView(this).apply {
                    text = label
                    setTextColor(white)
                    textSize = 12.3f
                    gravity = Gravity.CENTER
                    typeface = Typeface.DEFAULT_BOLD
                    background = rounded(Color.rgb(13, 23, 40), dp(17), Color.argb(95, 235, 35, 45))
                    setPadding(dp(14), 0, dp(14), 0)
                    setOnClickListener {
                        showSearch()
                        Toast.makeText(this@MainActivity, "برای فیلتر دقیق، همین عبارت را سرچ کن: $label", Toast.LENGTH_SHORT).show()
                    }
                }, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(6); marginEnd = dp(6); bottomMargin = dp(10) })
            }
            page.addView(sc, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) })
    }

    private fun searchAcceptsType(item: JSONObject, filter: String): Boolean {
        if (filter == "all") return true
        val type = item.optString("type").lowercase(Locale.US)
        val title = (item.optString("title") + " " + item.optString("title_fa")).lowercase(Locale.US)
        val isSeries = type.contains("series") || type.contains("serial") || title.contains("series") || title.contains("سریال")
        return if (filter == "series") isSeries else !isSeries
    }

    private fun showSearch() {
        currentScreen = "search"
        buildBottomNav()
        clear()
        topBar.visibility = View.GONE

        val rootFrame = FrameLayout(this).apply { setBackgroundColor(bg) }
        content.addView(rootFrame)

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(110))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (isTvLike()) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            setPadding(dp(14), dp(18), dp(14), dp(24))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        rootFrame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        attachSmartHeader(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(150), dp(62)).apply { marginStart = dp(10) })

        val searchBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            background = rounded(Color.rgb(12, 20, 34), dp(23), Color.argb(140, 235, 35, 45))
            setPadding(dp(10), 0, dp(12), 0)
        }

        val close = ImageView(this).apply {
            setImageResource(R.drawable.ic_close_clean)
            setColorFilter(Color.rgb(145, 154, 172))
            setOnClickListener { showHome() }
        }
        searchBox.addView(close, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(7) })

        val input = EditText(this).apply {
            hint = t("اسم فیلم یا سریال...", "Movie or series name...")
            setHintTextColor(Color.rgb(145, 154, 172))
            setTextColor(white)
            textSize = 14.5f
            gravity = Gravity.CENTER
            setSingleLine(true)
            background = null
        }
        searchBox.addView(input, LinearLayout.LayoutParams(0, dp(46), 1f))

        val clearBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_close_clean)
            setColorFilter(Color.rgb(145, 154, 172))
            visibility = View.GONE
            setOnClickListener { showSearch() }
        }
        searchBox.addView(clearBtn, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(5) })

        searchBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_search_clean)
            setColorFilter(Color.rgb(145, 154, 172))
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(7) })

        header.addView(searchBox, LinearLayout.LayoutParams(0, dp(48), 1f))
        page.addView(header, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })

        val filterState = arrayOf("all")
        val tabRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val tabs = mutableMapOf<String, TextView>()
        fun makeTab(label: String, key: String): TextView {
            return TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                textSize = 12.2f
                applyTvFocusHalo(this, 16, 1.035f, 0f)
                setOnClickListener {
                    filterState[0] = key
                    tabs.forEach { k, v ->
                        val active = k == filterState[0]
                        v.setTextColor(if (active) white else muted)
                        v.background = if (active) blueGradient(dp(15)) else rounded(Color.rgb(13, 23, 40), dp(15), Color.argb(75, 100, 125, 165))
                    }
                    val q = input.text?.toString()?.trim() ?: ""
                    if (q.length >= 2) liveSearch(page, input, filterState[0])
                }
            }
        }
        tabs["all"] = makeTab(t("همه", "All"), "all")
        tabs["movie"] = makeTab(t("فیلم", "Movies"), "movie")
        tabs["series"] = makeTab(t("سریال", "Series"), "series")
        tabs.forEach { k, v -> tabRow.addView(v, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4); marginEnd = dp(4) }) }
        page.addView(tabRow, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(10) })
        tabs["all"]?.performClick()

        val resultsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(14, 23, 39), dp(16), Color.argb(75, 95, 115, 150))
            visibility = View.GONE
        }
        page.addView(resultsBox, LinearLayout.LayoutParams(-1, -2))

        val progress = LinearLayout(this).apply {
            visibility = View.GONE
            addView(fancySpinnerText("در حال جستجو...", "نتایج در حال آماده‌سازی است"), LinearLayout.LayoutParams(-1, -2))
        }
        page.addView(progress, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        var lastQuery = ""
        fun live(q: String) {
            val query = q.trim()
            clearBtn.visibility = if (query.isBlank()) View.GONE else View.VISIBLE
            if (query.length < 2) {
                resultsBox.removeAllViews()
                resultsBox.visibility = View.GONE
                progress.visibility = View.GONE
                return
            }
            if (query == lastQuery && resultsBox.childCount > 0) return
            lastQuery = query
            progress.visibility = View.VISIBLE
            fetch("$apiBase?action=live_search&archive=1&q=${enc(query)}&page=1&limit=${if (isTvLike()) 50 else 18}") { ok, json, err ->
                runOnUiThread {
                    progress.visibility = View.GONE
                    resultsBox.removeAllViews()
                    if (!ok || json == null) {
                        resultsBox.visibility = View.VISIBLE
                        resultsBox.addView(emptyStateBox(ui("خطا در جستجو"), friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        applyTvFocusToClickableTree(resultsBox)
                        return@runOnUiThread
                    }
                    val arr = json.optJSONArray("items") ?: JSONArray()
                    val filtered = mutableListOf<JSONObject>()
                    for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { if (searchAcceptsType(it, filterState[0])) filtered.add(it) }
                    if (filtered.isEmpty()) {
                        resultsBox.visibility = View.VISIBLE
                        resultsBox.addView(emptyStateBox(ui("نتیجه‌ای پیدا نشد"), ui("با کلمه کوتاه‌تر یا تب همه امتحان کن")), LinearLayout.LayoutParams(-1, -2))
                        applyTvFocusToClickableTree(resultsBox)
                        return@runOnUiThread
                    }
                    resultsBox.visibility = View.VISIBLE
                    val maxItems = minOf(filtered.size, if (isTvLike()) 10 else 8)
                    for (i in 0 until maxItems) {
                        val item = filtered[i]
                        resultsBox.addView(searchResultRow(item), LinearLayout.LayoutParams(-1, dp(100)))
                        if (i < maxItems - 1) resultsBox.addView(View(this).apply { setBackgroundColor(Color.argb(50, 120, 135, 160)) }, LinearLayout.LayoutParams(-1, 1))
                    }
                    resultsBox.addView(TextView(this).apply {
                        text = ui("مشاهده همه نتایج")
                        setTextColor(white)
                        textSize = 14f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.CENTER
                        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(235, 35, 45), Color.rgb(170, 18, 34))).apply { cornerRadius = dp(16).toFloat() }
                        applyTvFocusHalo(this, 18, 1.035f, 0f)
                        isFocusable = true
                        isFocusableInTouchMode = false
                        setOnClickListener { doSearch(page, query, filterState[0]) }
                    }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(10); bottomMargin = dp(8); marginStart = dp(10); marginEnd = dp(10) })
                    applyTvFocusToClickableTree(resultsBox)
                }
            }
        }

        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { live(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        input.requestFocus()
    }

    private fun liveSearch(page: LinearLayout, input: EditText, filter: String) {
        val q = input.text?.toString()?.trim() ?: ""
        if (q.length >= 2) doSearch(page, q, filter)
    }

    private fun doSearch(page: LinearLayout, q: String, typeFilter: String = "all") {
        while (page.childCount > 2) page.removeViewAt(2)
        val tv = isTvLike()
        if (tv) {
            page.gravity = Gravity.LEFT
            page.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        // فقط سرچ واقعی: وقتی کاربر «مشاهده همه نتایج» می‌زند، دیگر سراغ سکشن‌های خانه/فیلم جدید/سریال جدید نمی‌رویم.
        // برای اینکه نتیجه‌ها گم نشوند، هر صفحه را بزرگ‌تر گرفتیم و تا ۱۰ صفحه اجازه ادامه می‌دهیم.
        val perPage = 100
        val maxSearchPages = 10
        val cardW = if (tv) tvGridCardWidth() else dp(116)
        val cardH = if (tv) tvGridCardHeight(cardW) else dp(222)

        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            useDefaultMargins = false
        }
        val more = moreButton(ui("مشاهده نتایج بیشتر")) { }
        val loading = fancySpinnerText("در حال آوردن همه نتایج...", q)
        page.addView(loading, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(12) })
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        val seen = mutableSetOf<String>()
        var lastLoadedPage = 0

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("source_url") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "${ui("مشاهده نتایج بیشتر")}  ${seen.size}" else ui("مشاهده نتایج بیشتر")
        }

        fun loadPage(p: Int) {
            if (p > maxSearchPages) {
                more.visibility = View.GONE
                return
            }
            lastLoadedPage = maxOf(lastLoadedPage, p)
            val query = URLEncoder.encode(q, "UTF-8")
            val typeParam = if (typeFilter == "all") "" else "&type=${enc(typeFilter)}"
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false

            fetch("$apiBase?action=search&archive=1&q=$query$typeParam&page=$p&limit=$perPage&search_only=1") { ok, json, err ->
                runOnUiThread {
                    loading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) {
                            page.addView(emptyStateBox(ui("خطا در جستجو"), friendlyError(err)), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        }
                        more.text = ui("تلاش دوباره")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (!searchAcceptsType(item, typeFilter)) continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    if (arr.length() == 0 && grid.childCount == 0) {
                        page.addView(emptyStateBox(ui("چیزی پیدا نشد"), ui("تب همه یا کلمه کوتاه‌تر را امتحان کن")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        more.visibility = View.GONE
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val next = json.optInt("next_page", p + 1).let { if (it > p) it else p + 1 }
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p
                    val guessedMore = arr.length() >= perPage
                    val safeMore = p < maxSearchPages && arr.length() > 0 && added > 0
                    val canLoadMore = serverHasMore || guessedMore || safeMore

                    if (canLoadMore && p < maxSearchPages) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(next) }
                    } else {
                        more.visibility = View.GONE
                        if (added == 0 && p > 1) Toast.makeText(this, ui("نتیجه جدیدی باقی نمانده"), Toast.LENGTH_SHORT).show()
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

    private fun posterCard(item: JSONObject, width: Int, height: Int): View {
        val tv = isTvLike()
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = rounded(Color.argb(36, 255, 255, 255), dp(24), Color.argb(28, 255, 255, 255))
            applyTvFocusHalo(this, if (tv) 24 else 26, if (tv) 1.055f else 1.065f, 0f)
            setOnClickListener {
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    showDetail(item)
                }.start()
            }
            layoutParams = ViewGroup.MarginLayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = dp(7)
                marginEnd = dp(7)
                bottomMargin = dp(if (tv) 18 else 14)
            }
        }

        val pf = FrameLayout(this).apply {
            background = rounded(Color.argb(105, 255, 255, 255), dp(22), Color.argb(70, 255, 255, 255))
            elevation = dp(10).toFloat()
            clipToOutline = true
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        pf.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, img)

        pf.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(12,0,0,0), Color.argb(130,0,0,0)))
        }, FrameLayout.LayoutParams(-1, -1))

        fun yearChip(textValue: String): TextView {
            return TextView(this).apply {
                text = textValue
                setTextColor(Color.WHITE)
                textSize = if (tv) 9.2f else 9.7f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(155, 0, 0, 0), dp(13), Color.argb(55, 255, 255, 255))
                setPadding(dp(8), dp(3), dp(8), dp(3))
                maxLines = 1
            }
        }

        item.optString("year").trim().takeIf {
            it.isNotBlank() && !it.equals("null", true) && !it.equals("false", true) && it != "0"
        }?.let { year ->
            pf.addView(yearChip(year), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply {
                topMargin = dp(9)
                rightMargin = dp(9)
            })
        }

        val posterHeight = (height * if (tv) 0.70f else 0.71f).toInt()
        wrap.addView(pf, LinearLayout.LayoutParams(-1, posterHeight))
        wrap.minimumHeight = posterHeight + dp(if (tv) 38 else 42)
        wrap.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = if (tv) 11.6f else 12.7f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            gravity = if (tv) Gravity.CENTER else Gravity.RIGHT
            includeFontPadding = true
            setLineSpacing(dp(2).toFloat(), 1.0f)
            setPadding(dp(3), dp(if (tv) 6 else 8), dp(3), dp(6))
        }, LinearLayout.LayoutParams(-1, -2))
        return wrap
    }

    private fun mergeSeedVisuals(seed: JSONObject, detail: JSONObject): JSONObject {
        val out = JSONObject(detail.toString())
        fun emptyValue(v: String): Boolean {
            val s = v.trim()
            return s.isBlank() || s.equals("null", true) || s.equals("false", true) || s.equals("undefined", true)
        }
        fun fill(key: String, vararg alternatives: String) {
            if (emptyValue(out.optString(key))) {
                for (k in alternatives) {
                    val v = seed.optString(k)
                    if (!emptyValue(v)) { out.put(key, v); return }
                }
            }
        }
        fill("poster", "poster", "image", "cover_image", "backdrop")
        fill("image", "image", "poster", "cover_image", "backdrop")
        fill("cover_image", "cover_image", "poster", "image", "backdrop")
        fill("backdrop", "backdrop", "poster", "image", "cover_image")
        fill("title_fa", "title_fa", "full_title", "title")
        fill("title", "title", "original_title", "title_fa")
        if (emptyValue(out.optString("imdb_code"))) fill("imdb_code", "imdb_code", "imdb", "imdb_id")
        if (emptyValue(out.optString("backdrop")) && !emptyValue(out.optString("poster"))) out.put("backdrop", out.optString("poster"))
        if (emptyValue(out.optString("image")) && !emptyValue(out.optString("poster"))) out.put("image", out.optString("poster"))
        if (emptyValue(out.optString("cover_image")) && !emptyValue(out.optString("poster"))) out.put("cover_image", out.optString("poster"))
        return out
    }

    private fun showDetail(seed: JSONObject) {
        val archive = when (seed.optInt("archive", defaultArchive)) {
            2 -> 2
            3 -> 3
            else -> 1
        }
        val id = seed.optString("id")
        val type = seed.optString("type", "movie")
        if (id.isBlank()) return

        currentScreen = "detail"
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE
        content.addView(movieDetailLoading(seed), FrameLayout.LayoutParams(-1, -1))

        fun showLoadedDetail(detailItem: JSONObject) {
            content.removeAllViews()
            val scroll = ScrollView(this).apply {
                clipToPadding = false
                setPadding(0, 0, 0, if (currentScreen == "detail") dp(24) else dp(100))
            }
            val page = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(0), dp(12), dp(30))
            }
            scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
            content.addView(scroll)
        attachSmartHeader(scroll)
            try {
                renderDetail(page, mergeSeedVisuals(seed, detailItem))
            } catch (e: Throwable) {
                page.removeAllViews()
                page.addView(emptyStateBox(t("خطا در نمایش اطلاعات", "Display error"), e.message ?: "Unknown error"), LinearLayout.LayoutParams(-1, -2))
            }
        }

        val url = "$apiBase?action=detail&archive=$archive&id=${URLEncoder.encode(id, "UTF-8")}&type=$type"
        fetch(url) { ok, json, err ->
            runOnUiThread {
                if (!ok || json == null) {
                    showLoadedDetail(seed)
                    Toast.makeText(this, friendlyError(err), Toast.LENGTH_SHORT).show()
                } else {
                    showLoadedDetail(json.optJSONObject("item") ?: seed)
                }
            }
        }
    }

    private fun renderDetail(page: LinearLayout, item: JSONObject) {
        val title = item.optString("title_fa").ifBlank { item.optString("title") }
        val originalTitle = item.optString("title").ifBlank { item.optString("original_title") }
        fun mediaCandidate(vararg values: String): String {
            for (v in values) {
                val s = v.trim()
                if (s.isNotBlank() && !s.equals("null", true) && !s.equals("false", true) && !s.equals("undefined", true)) return s
            }
            return ""
        }
        val poster = mediaCandidate(
            item.optString("poster"),
            item.optString("poster_url"),
            item.optString("image"),
            item.optString("cover_image"),
            item.optString("thumbnail"),
            item.optString("thumb")
        )
        val backdrop = mediaCandidate(
            item.optString("backdrop"),
            item.optString("background"),
            item.optString("backdrop_url"),
            item.optString("cover"),
            item.optString("image"),
            item.optString("poster"),
            poster
        )
        val desc = item.optString("long_description").ifBlank { item.optString("description") }
        val genres = genresText(item).split("،", ",", "•").map { it.trim() }.filter { it.isNotBlank() }

        recordHistory(item)

        val hero = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(690)).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = dp(8)
            }
            setBackgroundColor(bg)
        }

        // آرشیو ۱ معمولاً backdrop واقعی نمی‌دهد؛ پوستر را هم حتماً پشت صفحه می‌گذاریم
        // تا بک‌گراند صفحه اطلاعات حتی وقتی backdrop خراب/خالی بود دیده شود.
        val posterBg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.52f
        }
        loadImage(poster, posterBg)
        hero.addView(posterBg, FrameLayout.LayoutParams(-1, -1))

        val heroImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.92f
        }
        loadImage(backdrop, heroImg)
        hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1))

        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(0, 0, 0, 0),
                    Color.argb(8, 0, 0, 0),
                    Color.argb(68, 0, 0, 0),
                    if (isLightTheme()) Color.rgb(242, 243, 246) else Color.rgb(3, 7, 14)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(Color.argb(98, 0, 0, 0), Color.argb(18, 0, 0, 0), Color.TRANSPARENT)
            )
        }, FrameLayout.LayoutParams(-1, -1))

        hero.addView(svgIconButton(R.drawable.ic_player_back) { showHome() }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.LEFT).apply {
            topMargin = dp(18)
            leftMargin = dp(16)
        })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            setPadding(dp(22), dp(20), dp(22), dp(18))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.BOTTOM
        }

        val posterFrame = FrameLayout(this).apply {
            background = rounded(Color.argb(170, 4, 7, 13), dp(22), Color.argb(120, 255, 255, 255))
            clipToOutline = true
            elevation = dp(14).toFloat()
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val posterImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            adjustViewBounds = true
        }
        loadImage(poster, posterImg)
        posterFrame.addView(posterImg, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        topRow.addView(posterFrame, LinearLayout.LayoutParams(dp(138), dp(202)).apply {
            marginStart = dp(16)
        })

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
        }
        info.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(7f, 0f, 2f, Color.argb(185, 0, 0, 0))
        })
        if (originalTitle.isNotBlank() && originalTitle != title) {
            info.addView(TextView(this).apply {
                text = originalTitle
                setTextColor(Color.argb(210, 230, 233, 240))
                textSize = 12.5f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(4), 0, dp(6))
            })
        }

        val meta1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
        }
        val ratingText = cleanRating(item.optString("rating"))
        if (ratingText.isNotBlank() && ratingText != "-") {
            meta1.addView(alphaPill("IMDb $ratingText", true), LinearLayout.LayoutParams(-2, dp(34)).apply { marginStart = dp(7) })
        }
        item.optString("year").takeIf { it.isNotBlank() }?.let {
            meta1.addView(alphaPill(it, false), LinearLayout.LayoutParams(-2, dp(34)).apply { marginStart = dp(7) })
        }
        val rawType = item.optString("type_fa").ifBlank { item.optString("type") }
        val typeLabel = when {
            rawType.contains("series", true) || rawType.contains("serial", true) || rawType.contains("tv", true) || rawType.contains("سریال") -> "سریال"
            rawType.contains("movie", true) || rawType.contains("film", true) || rawType.contains("فیلم") -> "فیلم"
            else -> rawType
        }
        if (typeLabel.isNotBlank()) meta1.addView(alphaPill(typeLabel, false), LinearLayout.LayoutParams(-2, dp(34)).apply { marginStart = dp(7) })
        info.addView(meta1, LinearLayout.LayoutParams(-1, dp(38)).apply { topMargin = dp(9) })

        val meta2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
        }
        genres.take(3).forEach {
            meta2.addView(alphaPill(it.take(18), false), LinearLayout.LayoutParams(-2, dp(33)).apply { marginStart = dp(7) })
        }
        info.addView(meta2, LinearLayout.LayoutParams(-1, dp(37)).apply { topMargin = dp(6) })
        topRow.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(topRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(detailActionButton("پخش آنلاین", R.drawable.ic_play_fill, true) { showPlayableSheet(item) }, LinearLayout.LayoutParams(0, dp(58), 1.2f).apply { marginStart = dp(10) })
        actions.addView(purpleTrailerButton { playTrailer(item) }, LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(16) })
        actions.addView(favoriteHeartButton(item) {
            toggleFavorite(item)
            page.removeAllViews()
            renderDetail(page, item)
        }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
        content.addView(actions, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(18) })

        val descView = TextView(this).apply {
            text = desc.ifBlank { "توضیحی برای این عنوان ثبت نشده است." }
            setTextColor(Color.argb(220, 218, 224, 235))
            textSize = 13.9f
            gravity = Gravity.RIGHT
            setMaxLines(4)
            ellipsize = TextUtils.TruncateAt.END
            setLineSpacing(dp(3).toFloat(), 1.0f)
            setPadding(dp(4), 0, dp(4), 0)
        }
        content.addView(descView, LinearLayout.LayoutParams(-1, -2))

        val expanded = booleanArrayOf(false)
        val moreText = TextView(this).apply {
            text = "ادامه مطلب ⌄"
            setTextColor(Color.WHITE)
            textSize = 12.8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(dp(4), dp(8), dp(4), 0)
            setOnClickListener {
                expanded[0] = !expanded[0]
                if (expanded[0]) {
                    descView.setMaxLines(Int.MAX_VALUE)
                    descView.ellipsize = null
                    text = "کمتر ⌃"
                } else {
                    descView.setMaxLines(4)
                    descView.ellipsize = TextUtils.TruncateAt.END
                    text = "ادامه مطلب ⌄"
                }
            }
        }
        content.addView(moreText, LinearLayout.LayoutParams(-1, -2))

        hero.addView(content, FrameLayout.LayoutParams(-1, -1))
        page.addView(hero)

        renderActors(page, item)
        renderEpisodeBlocks(page, item)
        val related = item.optJSONArray("related") ?: item.optJSONArray("related_movies") ?: JSONArray()
        if (related.length() > 0) {
            addJsonRail(page, "پیشنهاد فیلم", related)
        } else {
            val similarQuery = genres.firstOrNull().orEmpty().ifBlank { title }
            addSearchRail(page, "پیشنهاد فیلم", similarQuery, "all")
        }
    }

    private fun playTrailer(item: JSONObject) {
        val trailer = item.optString("trailer_url").ifBlank { item.optString("trailer") }
        if (trailer.isBlank()) {
            Toast.makeText(this, "تریلر برای این عنوان ثبت نشده", Toast.LENGTH_SHORT).show()
            return
        }
        val arr = JSONArray().put(JSONObject().apply {
            put("url", trailer)
            put("title", item.optString("title_fa").ifBlank { item.optString("title") })
            put("quality", "Trailer")
            put("type", "trailer")
            put("type_fa", "تریلر")
            put("display_label", "تریلر")
        })
        val payload = JSONObject().apply {
            put("video", trailer)
            put("title", item.optString("title_fa").ifBlank { item.optString("title") })
            put("selectedIndex", 0)
            put("tracks", arr)
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, trailer)
            putExtra(PlayerActivity.EXTRA_TITLE, item.optString("title_fa").ifBlank { item.optString("title") })
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, payload.toString())
        })
    }

    private fun showDownloadOptions(item: JSONObject) {
        val links = sortedArchive1Links(playableLinks(item))
        if (links.isEmpty()) {
            Toast.makeText(this, "لینک مستقیم دانلود پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        showDownloadForLinks(item, links)
    }

    private fun openExternal(url: String, packageName: String?) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (packageName != null) intent.setPackage(packageName)
        try { startActivity(intent) } catch (_: Throwable) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    private fun seedFromSlider(item: JSONObject): JSONObject? {
        val link = item.optString("link_abs").ifBlank { item.optString("link") }
        if (link.isBlank()) return null
        return try {
            val uri = Uri.parse(link)
            uri.getQueryParameter("imdb")?.takeIf { it.isNotBlank() }?.let {
                return JSONObject().put("id", it).put("archive", defaultArchive).put("type", "movie")
            }
            val slug = uri.getQueryParameter("slug")
            val arc = uri.getQueryParameter("arc")?.toIntOrNull() ?: defaultArchive
            val type = uri.getQueryParameter("type") ?: "movie"
            if (!slug.isNullOrBlank()) return JSONObject().put("id", slug).put("archive", arc).put("type", type)
            val path = uri.pathSegments.lastOrNull().orEmpty()
            if (path.isNotBlank()) JSONObject().put("id", path).put("archive", defaultArchive).put("type", "movie") else null
        } catch (_: Throwable) { null }
    }

    private fun detailSectionTitle(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(16), 0, dp(10))
            addView(View(this@MainActivity).apply {
                background = rounded(Color.rgb(235, 35, 45), dp(3), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(dp(5), dp(27)).apply { marginStart = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })
        }
    }

    private fun detailMetaPill(iconRes: Int, label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 22, 39), dp(17), Color.argb(105, 80, 115, 165))
            setPadding(dp(10), dp(7), dp(10), dp(7))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                if (iconRes != R.drawable.ic_imdb) setColorFilter(Color.rgb(235, 35, 45))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(if (iconRes == R.drawable.ic_imdb) dp(38) else dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = if (label.isBlank()) value.ifBlank { "-" } else "$label: ${value.ifBlank { "-" }}"
                setTextColor(white)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
    }

    private fun detailGenreChip(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.rgb(225, 232, 244))
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.rgb(12, 23, 39), dp(19), Color.argb(115, 80, 110, 160))
            setPadding(dp(16), 0, dp(16), 0)
        }
    }

    private fun trailerPurpleButton(click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(105, 72, 255), Color.rgb(62, 48, 160))).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(160, 175, 155, 255))
            }
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_trailer)
                setColorFilter(white)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginStart = dp(7) })
            addView(TextView(this@MainActivity).apply {
                text = "تماشای تریلر"
                setTextColor(white)
                textSize = 12.3f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }


    private fun favoriteHeartButton(item: JSONObject, click: () -> Unit): FrameLayout {
        val active = isFavorite(item)
        return FrameLayout(this).apply {
            background = if (active) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(235, 235, 35, 45), Color.argb(205, 120, 8, 22))).apply {
                    cornerRadius = dp(999).toFloat()
                    setStroke(dp(1), Color.argb(150, 255, 150, 160))
                }
            } else {
                rounded(if (isLightTheme()) Color.argb(225,255,255,255) else Color.argb(135,0,0,0), dp(999), alphaLine(80))
            }
            elevation = dp(8).toFloat()
            applyTvFocusHalo(this, 999, 1.08f, dp(8).toFloat())
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(if (active) R.drawable.ic_watchlist_filled else R.drawable.ic_watchlist_outline)
                setColorFilter(if (active) Color.WHITE else Color.rgb(235, 35, 45))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        }
    }

    private fun purpleTrailerButton(click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(235, 35, 45), Color.rgb(155, 16, 32))
            ).apply {
                cornerRadius = dp(23).toFloat()
                setStroke(dp(1), Color.argb(145, 255, 145, 150))
            }
            elevation = dp(10).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            applyTvFocusHalo(this, 24, 1.045f, dp(10).toFloat())
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(105).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_trailer)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = "تریلر"
                setTextColor(Color.WHITE)
                textSize = 12.9f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun detailActionButton(label: String, iconRes: Int, red: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (red) blueGradient(dp(23)) else rounded(alphaSurface2(), dp(23), alphaLine(95))
            elevation = if (red) dp(9).toFloat() else dp(4).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            applyTvFocusHalo(this, 24, 1.045f, elevation)
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(105).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply { setImageResource(iconRes); setColorFilter(if (red) alphaTextOnPrimary() else white) }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(if (red) alphaTextOnPrimary() else white)
                textSize = 12.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun expandableDescription(desc: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(8, 15, 27), dp(18), Color.rgb(28, 45, 72))
            setPadding(dp(14), dp(14), dp(14), dp(12))
        }
        val body = TextView(this).apply {
            text = desc.ifBlank { "توضیحاتی برای این عنوان ثبت نشده است." }
            setTextColor(Color.rgb(218, 226, 240))
            textSize = 14.2f
            setLineSpacing(dp(5).toFloat(), 1f)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
        }
        val more = TextView(this).apply {
            text = "ادامه بیشتر"
            setTextColor(Color.rgb(235, 35, 45))
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(10), 0, 0)
            setOnClickListener {
                if (body.maxLines == 3) {
                    body.maxLines = 100
                    body.ellipsize = null
                    text = "بستن توضیحات"
                } else {
                    body.maxLines = 3
                    body.ellipsize = TextUtils.TruncateAt.END
                    text = "ادامه بیشتر"
                }
            }
        }
        box.addView(body)
        if ((desc.length) > 160) box.addView(more)
        return box
    }

    private fun addJsonRail(page: LinearLayout, title: String, items: JSONArray) {
        if (items.length() == 0) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader(title) { })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        for (i in 0 until minOf(items.length(), 14)) {
            items.optJSONObject(i)?.let { row.addView(posterCard(it, dp(134), dp(244))) }
        }
    }

    private fun showActorPage(actor: JSONObject) {
        val slug = actor.optString("slug").ifBlank {
            val url = actor.optString("url").ifBlank { actor.optString("bankmovie_url") }
            Uri.parse(url).pathSegments.let { segs ->
                val idx = segs.indexOf("actors")
                if (idx >= 0 && idx + 1 < segs.size) segs[idx + 1] else ""
            }
        }
        val actorUrl = actor.optString("url").ifBlank { actor.optString("bankmovie_url") }
        val nameFallback = actor.optString("name")
        currentScreen = "actor"
        buildBottomNav()
        clear()

        val scroll = ScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(108)) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(28)) }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(fancySpinnerText(t("در حال دریافت صفحه بازیگر", "Loading actor page"), nameFallback))

        val url = when {
            slug.isNotBlank() -> "$apiBase?action=actor&slug=${enc(slug)}&name=${enc(nameFallback)}"
            actorUrl.isNotBlank() -> "$apiBase?action=actor&url=${enc(actorUrl)}&name=${enc(nameFallback)}"
            else -> "$apiBase?action=actor&name=${enc(nameFallback)}"
        }

        fetch(url) { ok, json, err ->
            runOnUiThread {
                page.removeAllViews()
                if (!ok || json == null) {
                    page.addView(emptyStateBox(t("خطا در دریافت بازیگر", "Actor load failed"), friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                    return@runOnUiThread
                }
                val obj = json.optJSONObject("actor") ?: JSONObject()
                val name = obj.optString("name").ifBlank { nameFallback.ifBlank { t("بازیگر", "Actor") } }
                val photo = obj.optString("image").ifBlank { obj.optString("photo") }
                page.addView(actorHeroCard(name, photo))
                val items = json.optJSONArray("items") ?: json.optJSONArray("movies") ?: JSONArray()
                page.addView(sectionHeader(t("فیلم‌ها و سریال‌ها", "Movies and Series") ) { })
                val tv = isTvLike()
                val grid = GridLayout(this).apply { columnCount = if (tv) 8 else 3; layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL }
                page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
                val w = if (tv) tvGridCardWidth() else dp(116)
                val h = if (tv) tvGridCardHeight(w) else dp(222)
                for (i in 0 until items.length()) items.optJSONObject(i)?.let { grid.addView(posterCard(it, w, h)) }
                if (items.length() == 0) page.addView(emptyStateBox(t("فیلمی پیدا نشد", "No titles found"), t("برای این بازیگر هنوز اثری ثبت نشده است.", "No movies or series are linked to this actor yet.")), LinearLayout.LayoutParams(-1, -2))
                applyTvFocusToClickableTree(page)
            }
        }
    }

    private fun actorHeroCard(name: String, photo: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.argb(112, 255, 255, 255), dp(28), Color.argb(75, 255, 255, 255))
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val avatar = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(25, 30, 48), Color.rgb(7, 9, 18))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(100, 139, 92, 246))
            }
            clipToOutline = true
        }
        if (photo.isNotBlank()) {
            val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
            avatar.addView(img, FrameLayout.LayoutParams(-1, -1))
            loadImage(photo, img)
        } else {
            avatar.addView(ImageView(this).apply { setImageResource(R.drawable.ic_avatar_circle); setColorFilter(Color.rgb(139, 92, 246)) }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        }
        box.addView(avatar, LinearLayout.LayoutParams(dp(112), dp(148)).apply { marginStart = dp(16) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        info.addView(TextView(this).apply {
            text = name
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = t("فیلم‌ها و سریال‌های مرتبط", "Related movies and series")
            setTextColor(muted)
            textSize = 12.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, 0)
        })
        box.addView(info, LinearLayout.LayoutParams(0, -1, 1f))
        return box
    }

    private fun renderActors(page: LinearLayout, item: JSONObject) {
        val actors = item.optJSONArray("actors") ?: return
        if (actors.length() == 0) return
        page.addView(sectionHeader("بازیگران") { })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) }
        for (i in 0 until minOf(actors.length(), 14)) {
            val obj = actors.optJSONObject(i) ?: JSONObject().put("name", actors.optString(i))
            val name = obj.optString("name").takeIf { it.isNotBlank() } ?: actors.optString(i)
            val role = obj.optString("role")
            val image = obj.optString("image").ifBlank { obj.optString("photo") }
            if (name.isBlank() || name.startsWith("{")) continue
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(Color.argb(90, 255, 255, 255), dp(18), Color.argb(70, 255, 255, 255))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = ViewGroup.MarginLayoutParams(dp(96), dp(136)).apply { marginStart = dp(5); marginEnd = dp(5) }
                applyTvFocusHalo(this, 20, 1.06f, 0f)
                setOnClickListener { showActorPage(obj) }
            }
            val avatarWrap = FrameLayout(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(16, 28, 46)); setStroke(dp(1), Color.argb(110, 139, 92, 246)) }
                clipToOutline = true
            }
            if (image.isNotBlank()) {
                val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true }
                loadImage(image, img)
                avatarWrap.addView(img, FrameLayout.LayoutParams(-1,-1))
            } else {
                avatarWrap.addView(ImageView(this).apply { setImageResource(R.drawable.ic_avatar_circle); setColorFilter(Color.rgb(139, 92, 246)) }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            }
            card.addView(avatarWrap, LinearLayout.LayoutParams(dp(56), dp(56)))
            card.addView(TextView(this).apply { text = name; setTextColor(white); textSize = 10.8f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(-1,-2))
            if (role.isNotBlank()) card.addView(TextView(this).apply { text = role; setTextColor(muted); textSize = 9.2f; gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) }, LinearLayout.LayoutParams(-1,-2))
            row.addView(card)
        }
        page.addView(scroll, LinearLayout.LayoutParams(-1, dp(148)).apply { bottomMargin = dp(14) })
    }

    private fun infoGrid(item: JSONObject): View {
        val grid = GridLayout(this).apply {
            columnCount = 2
            background = rounded(Color.rgb(8, 15, 27), dp(18), Color.rgb(28, 45, 72))
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val country = item.optJSONArray("country")?.optString(0) ?: item.optString("country")
        val cells: List<Triple<Int, String, String>> = listOf(
            Triple(R.drawable.ic_imdb, "امتیاز", cleanRating(item.optString("rating"))),
            Triple(R.drawable.ic_info_globe, "کشور", country.ifBlank { "نامشخص" }),
            Triple(R.drawable.ic_info_calendar, "سال", item.optString("year")),
            Triple(R.drawable.ic_info_runtime, "زمان", item.optString("runtime")),
            Triple(R.drawable.ic_info_badge, "رده سنی", item.optString("age_rate").ifBlank { "+16" }),
            Triple(R.drawable.ic_info_archive, "آرشیو", "۱")
        )
        cells.forEach { cell: Triple<Int, String, String> ->
            grid.addView(infoCell(cell.first, cell.second, cell.third), ViewGroup.MarginLayoutParams(0, -2).apply {
                width = dp(160)
                marginStart = dp(4)
                marginEnd = dp(4)
                bottomMargin = dp(8)
            })
        }
        return grid
    }

        private fun downloadNotice(): TextView {
        return TextView(this).apply {
            text = ui("برای پخش روی دکمه سبز بزن. برای دانلود روی آیکن دانلود کنار هر نسخه بزن.")
            setTextColor(Color.rgb(205, 214, 230))
            textSize = 12.1f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.0f)
            background = rounded(Color.argb(72, 255, 255, 255), dp(14), Color.argb(58, 255, 255, 255))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
    }


    private fun downloadSeasonCard(item: JSONObject, allLinks: List<JSONObject>, season: Int, seasonLinks: List<JSONObject>): LinearLayout {
        val seasonTitle = if (season > 0) "${ui("فصل")} $season" else ui("قسمت‌ها")
        val sortedSeasonLinks = sortedArchive1Links(seasonLinks)

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface(), dp(20), alphaLine(78))
            elevation = dp(3).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val seasonContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(9), 0, 0)
        }

        val seasonArrow = ImageView(this).apply {
            setImageResource(R.drawable.ic_expand_double)
            setColorFilter(Color.WHITE)
            rotation = 0f
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.argb(105, 139, 92, 246), Color.argb(58, 30, 36, 58))
            ).apply {
                cornerRadius = dp(17).toFloat()
                setStroke(dp(1), Color.argb(70, 255, 255, 255))
            }
            setPadding(dp(12), 0, dp(12), 0)
            applyTvFocusHalo(this, 18, 1.025f, 0f)
        }

        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_download)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(8) })

        header.addView(TextView(this).apply {
            text = seasonTitle
            setTextColor(Color.WHITE)
            textSize = 15.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(52), 1f))

        val epCount = sortedSeasonLinks.map { it.optInt("episode", 0) }.filter { it > 0 }.distinct().size
        header.addView(TextView(this).apply {
            text = if (epCount > 0) "$epCount ${ui("قسمت")}" else "${sortedSeasonLinks.size} ${ui("لینک‌ها")}"
            setTextColor(Color.rgb(226, 230, 245))
            textSize = 11.2f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(54, 255, 255, 255), dp(12), Color.argb(50, 255, 255, 255))
            setPadding(dp(9), dp(4), dp(9), dp(4))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })

        header.addView(seasonArrow, LinearLayout.LayoutParams(dp(30), dp(52)))

        header.setOnClickListener {
            val open = seasonContent.visibility != View.VISIBLE
            seasonContent.visibility = if (open) View.VISIBLE else View.GONE
            seasonArrow.animate().rotation(if (open) 180f else 0f).setDuration(160).start()
        }

        box.addView(header, LinearLayout.LayoutParams(-1, dp(52)))

        val episodeGroups = sortedSeasonLinks.groupBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 0 } }
            .toSortedMap(compareBy<Int> { if (it == 0) 9999 else it })

        episodeGroups.forEach { (episode, epLinksRaw) ->
            val epLinks = sortedArchive1Links(epLinksRaw).sortedWith(
                compareBy<JSONObject> { linkKindOrder(linkKindKey(it)) }
                    .thenBy { qualitySortRank(it) }
                    .thenBy { it.optString("display_label").ifBlank { it.optString("quality") } }
            )

            val epBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.rgb(8, 15, 28), dp(16), Color.argb(58, 255, 255, 255))
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }

            val epContent = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(0, dp(7), 0, 0)
            }

            val epArrow = ImageView(this).apply {
                setImageResource(R.drawable.ic_expand_double)
                setColorFilter(Color.WHITE)
                rotation = 0f
            }

            val epHeader = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = rounded(Color.rgb(15, 25, 43), dp(14), Color.argb(70, 139, 92, 246))
                setPadding(dp(10), 0, dp(10), 0)
                applyTvFocusHalo(this, 16, 1.025f, 0f)
            }

            epHeader.addView(TextView(this).apply {
                text = if (episode > 0) "${ui("قسمت")} $episode" else ui("لینک‌های فصل")
                setTextColor(Color.WHITE)
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, dp(46), 1f))

            val typeSummary = epLinks.map { linkTypeFa(it) }.filter { it.isNotBlank() }.distinct().take(3).joinToString(" / ")
            epHeader.addView(TextView(this).apply {
                text = if (typeSummary.isNotBlank()) typeSummary else "${epLinks.size} ${ui("کیفیت")}"
                setTextColor(muted)
                textSize = 10.4f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                background = rounded(alphaSurface(), dp(10), Color.TRANSPARENT)
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(7) })

            epHeader.addView(epArrow, LinearLayout.LayoutParams(dp(28), dp(46)))

            epHeader.setOnClickListener {
                val open = epContent.visibility != View.VISIBLE
                epContent.visibility = if (open) View.VISIBLE else View.GONE
                epArrow.animate().rotation(if (open) 180f else 0f).setDuration(160).start()
            }

            epBox.addView(epHeader, LinearLayout.LayoutParams(-1, dp(46)))

            // وقتی قسمت باز شد، همه کیفیت‌ها یک‌جا دیده می‌شوند.
            // هاردساب/دوبله/زیرنویس داخل خود ردیف کیفیت نوشته می‌شود و دیگر nested accordion اضافه نداریم.
            epLinks.forEach { link ->
                val idx = allLinks.indexOf(link).coerceAtLeast(0)
                epContent.addView(downloadQualityRow(item, allLinks, idx, link), LinearLayout.LayoutParams(-1, dp(62)).apply {
                    bottomMargin = dp(7)
                })
            }

            epBox.addView(epContent, LinearLayout.LayoutParams(-1, -2))
            seasonContent.addView(epBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }

        box.addView(seasonContent, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun linkKindOrder(kind: String): Int {
        return when (kind) {
            "dub" -> 0
            "hard" -> 1
            "sub" -> 2
            "audio" -> 3
            else -> 4
        }
    }

    private fun qualitySortRank(link: JSONObject): Int {
        val q = link.optString("quality").ifBlank { link.optString("display_label") }.lowercase(Locale.US)
        return when {
            q.contains("2160") || q.contains("4k") -> 0
            q.contains("1080") -> 1
            q.contains("720") -> 2
            q.contains("480") -> 3
            q.contains("360") -> 4
            else -> 8
        }
    }

    private fun archive1LinkSortWeight(link: JSONObject): Int {
        val season = link.optInt("season", 0).let { if (it > 0) it else 999 }
        val episode = link.optInt("episode", 0).let { if (it > 0) it else 999 }
        val kind = linkKindKey(link)
        val group = when (kind) {
            "dub" -> 0
            "hard" -> 1
            "sub" -> 2
            "audio" -> 3
            else -> 4
        }
        val q = link.optString("quality").ifBlank { link.optString("display_label") }.lowercase(Locale.US)
        val qRank = when {
            q.contains("2160") || q.contains("4k") -> 0
            q.contains("1080") -> 1
            q.contains("720") -> 2
            q.contains("480") -> 3
            q.contains("360") -> 4
            else -> 8
        }
        return season * 1000000 + episode * 10000 + group * 100 + qRank
    }

    private fun sortedArchive1Links(links: List<JSONObject>): List<JSONObject> {
        return links.sortedWith(compareBy<JSONObject> { archive1LinkSortWeight(it) }
            .thenBy { it.optString("display_label").ifBlank { it.optString("quality") } })
    }

    private fun groupedDownloadBlocks(item: JSONObject, links: List<JSONObject>): List<View> {
        val all = sortedArchive1Links(links)
        if (isSeriesLinks(all)) {
            val bySeason = all.groupBy { it.optInt("season", 0).let { s -> if (s > 0) s else 0 } }
                .toSortedMap(compareBy<Int> { if (it == 0) 9999 else it })
            return bySeason.map { (season, arr) ->
                downloadSeasonCard(item, all, season, arr)
            }
        }
        return groupedDownloadBlocks(item, all) { title, arr ->
            // فیلم‌ها و لینک‌های ساده نباید خودکار باز باشند؛ کاربر خودش گروه را باز می‌کند.
            downloadGroupCard(item, all, title, arr, false)
        }
    }

    private fun groupedDownloadBlocks(item: JSONObject, links: List<JSONObject>, render: (String, List<JSONObject>) -> View): List<View> {
        val sorted = sortedArchive1Links(links)
        val groups = linkedMapOf<String, MutableList<JSONObject>>()
        for (l in sorted) {
            val title = when (linkKindKey(l)) {
                "dub" -> ui("دوبله فارسی")
                "hard" -> ui("هاردساب")
                "sub" -> ui("زیرنویس")
                "audio" -> ui("صوت دوبله")
                else -> ui("سایر لینک‌ها")
            }
            groups.getOrPut(title) { mutableListOf() }.add(l)
        }
        val out = mutableListOf<View>()
        groups.forEach { (title, arr) ->
            if (arr.isNotEmpty()) out.add(render(title, arr))
        }
        return out
    }

    private fun linkKindKey(link: JSONObject): String {
        val raw = listOf(
            link.optString("type"),
            link.optString("type_fa"),
            link.optString("label"),
            link.optString("display_label"),
            link.optString("quality"),
            link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)

        return when {
            raw.contains("dub") || raw.contains("دوبله") -> "dub"
            raw.contains("hard") || raw.contains("هارد") -> "hard"
            raw.contains("audio") || raw.contains("voice") || raw.contains("صوت") -> "audio"
            raw.contains("sub") || raw.contains("زیرنویس") -> "sub"
            else -> "other"
        }
    }

    private fun renderEpisodeBlocks(page: LinearLayout, item: JSONObject) {
        val links = playableLinks(item)
        if (links.isEmpty()) return
        page.addView(sectionHeader(if (isSeriesLinks(links)) "فصل‌ها و قسمت‌ها / دانلود" else "باکس دانلود") { showPlayableSheet(item) })
        page.addView(downloadNotice())
        groupedDownloadBlocks(item, links).forEach { block -> page.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }) }
    }

    private fun downloadGroupCard(item: JSONObject, allLinks: List<JSONObject>, title: String, links: List<JSONObject>, openDefault: Boolean): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface(), dp(18), alphaLine(75))
            elevation = dp(3).toFloat()
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(alphaSurface2(), dp(18), alphaLine(65))
            setPadding(dp(12), 0, dp(12), 0)
        }
        val arrow = TextView(this).apply {
            text = if (openDefault) "⌃" else "⌄"
            setTextColor(white)
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        header.addView(ImageView(this).apply { setImageResource(R.drawable.ic_download); setColorFilter(white) }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(8) })
        header.addView(TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        header.addView(TextView(this).apply {
            text = "${links.size}"
            setTextColor(muted)
            textSize = 11f
            gravity = Gravity.CENTER
            background = rounded(alphaSurface(), dp(11), Color.TRANSPARENT)
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        header.addView(arrow, LinearLayout.LayoutParams(dp(30), dp(54)))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (openDefault) View.VISIBLE else View.GONE
            setPadding(dp(8), dp(10), dp(8), dp(8))
        }
        links.sortedWith(compareByDescending<JSONObject> { qualityScore(it.optString("quality")) }.thenBy { it.optString("display_label") }).forEach { link ->
            val idx = allLinks.indexOf(link).coerceAtLeast(0)
            content.addView(downloadQualityRow(item, allLinks, idx, link), LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(7) })
        }
        applyTvFocusHalo(header, 18, 1.025f, header.elevation)
        header.setOnClickListener {
            val open = content.visibility != View.VISIBLE
            content.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "⌃" else "⌄"
        }
        box.addView(header)
        box.addView(content)
        return box
    }

    private fun downloadQualityRow(item: JSONObject, allLinks: List<JSONObject>, index: Int, link: JSONObject): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.argb(58, 255, 255, 255), dp(16), Color.argb(48, 255, 255, 255))
            setPadding(dp(7), dp(6), dp(7), dp(6))

            val canPlay = isVideo(link.optString("url")) || isAudioOnly(link)
            addView(FrameLayout(this@MainActivity).apply {
                background = rounded(if (canPlay) Color.argb(205, 20, 92, 54) else Color.argb(175, 42, 48, 66), dp(12), if (canPlay) Color.argb(80, 90, 245, 140) else Color.argb(75, 180, 190, 210))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(if (canPlay) R.drawable.ic_play_fill else R.drawable.ic_download)
                    setColorFilter(if (canPlay) Color.rgb(95, 245, 145) else Color.rgb(220, 226, 238))
                }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
                applyTvFocusHalo(this, 14, 1.075f, 0f)
                setOnClickListener {
                    if (canPlay) {
                        if (item.length() > 0) recordContinue(item, link)
                        openPlayer(item, allLinks, index)
                    } else {
                        showDownloadChoiceModal(link)
                    }
                }
            }, LinearLayout.LayoutParams(dp(38), dp(44)).apply { marginStart = dp(7) })

            val info = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(8), 0, dp(8), 0)
            }
            info.addView(TextView(this@MainActivity).apply {
                text = link.optString("quality").ifBlank { link.optString("display_label").ifBlank { ui("نامشخص") } }
                setTextColor(white)
                textSize = 12.9f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
            })
            info.addView(TextView(this@MainActivity).apply {
                text = listOf(linkTypeFa(link), if (link.optInt("season",0)>0) "${ui("فصل")} ${link.optInt("season",0)}" else "", if (link.optInt("episode",0)>0) "${ui("قسمت")} ${link.optInt("episode",0)}" else "", link.optString("size")).filter { it.isNotBlank() }.distinct().joinToString(" • ")
                setTextColor(Color.rgb(190, 201, 218))
                textSize = 10.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
            })
            addView(info, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = dp(7) })

            addView(FrameLayout(this@MainActivity).apply {
                background = rounded(Color.argb(215, 235, 35, 45), dp(12), Color.argb(105, 255, 150, 160))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(Color.WHITE)
                }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                applyTvFocusHalo(this, 14, 1.075f, 0f)
                setOnClickListener { showDownloadChoiceModal(link) }
            }, LinearLayout.LayoutParams(dp(38), dp(44)))
        }
    }

    private fun movieVersionPanel(item: JSONObject, links: List<JSONObject>): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(7, 13, 25), dp(24), Color.argb(135, 65, 105, 170))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        box.addView(TextView(this).apply {
            text = "انتخاب نسخه پخش"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        links.forEachIndexed { idx, link ->
            box.addView(movieVersionCard(item, links, idx, link), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        return box
    }

    private fun movieVersionCard(item: JSONObject, links: List<JSONObject>, idx: Int, link: JSONObject): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(10, 19, 35), dp(20), Color.argb(115, 58, 96, 155))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        top.addView(TextView(this).apply {
            text = link.optString("display_label").ifBlank { linkLabel(link) }
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(premiumQualityChip(link, true) { openPlayer(item, links, idx) }, LinearLayout.LayoutParams(-2, dp(34)))
        card.addView(top)
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(10), 0, 0)
        }
        buttons.addView(premiumMiniButton("▶ پخش") { openPlayer(item, links, idx) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        buttons.addView(premiumMiniButton("⇩ دانلود") { showDownloadForLinks(item, listOf(link)) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        card.addView(buttons)
        return card
    }

    private fun seasonPremiumCard(item: JSONObject, allLinks: List<JSONObject>, seasonNumber: Int, seasonLinks: List<JSONObject>, initiallyOpen: Boolean): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(7, 13, 25), dp(24), Color.argb(145, 65, 105, 170))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }

        val episodes = seasonLinks.groupBy { it.optInt("episode", 0) }.toSortedMap()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(11, 21, 39), dp(18), Color.argb(110, 60, 103, 178))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val arrow = TextView(this).apply {
            text = if (initiallyOpen) "⌃" else "⌄"
            setTextColor(blue2)
            textSize = 22f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titleBox.addView(TextView(this).apply {
            text = if (seasonNumber > 0) "فصل ${seasonNumber}" else "قسمت‌ها"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })
        titleBox.addView(TextView(this).apply {
            text = "${episodes.size} قسمت • ${seasonLinks.size} نسخه قابل پخش"
            setTextColor(muted)
            textSize = 11.5f
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(arrow, LinearLayout.LayoutParams(dp(38), dp(38)))

        val episodeContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (initiallyOpen) View.VISIBLE else View.GONE
            setPadding(0, dp(12), 0, 0)
        }
        episodes.forEach { ep ->
            episodeContainer.addView(episodePremiumCard(item, allLinks, ep.key, ep.value), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        applyTvFocusHalo(header, 18, 1.025f, header.elevation)
        header.setOnClickListener {
            val open = episodeContainer.visibility != View.VISIBLE
            episodeContainer.visibility = if (open) View.VISIBLE else View.GONE
            arrow.text = if (open) "⌃" else "⌄"
        }

        outer.addView(header)
        outer.addView(episodeContainer)
        return outer
    }

    private fun episodePremiumCard(item: JSONObject, allLinks: List<JSONObject>, episodeNumber: Int, epLinks: List<JSONObject>): View {
        val best = bestEpisodeLink(epLinks)
        val bestIndex = allLinks.indexOf(best).coerceAtLeast(0)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(10, 19, 35), dp(20), Color.argb(105, 45, 80, 135))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        info.addView(TextView(this).apply {
            text = if (episodeNumber > 0) "قسمت ${episodeNumber}" else "لینک‌ها"
            setTextColor(white)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        info.addView(TextView(this).apply {
            text = episodeSubtitle(best, epLinks)
            setTextColor(muted)
            textSize = 11.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
        })
        top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = runtimeText(best)
            setTextColor(blue2)
            textSize = 11f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(80, 0, 108, 255), dp(13), Color.argb(95, 70, 120, 200))
            setPadding(dp(9), dp(5), dp(9), dp(5))
        })
        card.addView(top)

        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(10), 0, dp(8))
        }
        epLinks.sortedByDescending { qualityScore(it.optString("quality")) }.forEach { link ->
            val idx = allLinks.indexOf(link)
            chips.addView(premiumQualityChip(link, idx == bestIndex) { openPlayer(item, allLinks, idx) }, LinearLayout.LayoutParams(-2, dp(34)).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
            })
        }
        chipScroll.addView(chips)
        card.addView(chipScroll, LinearLayout.LayoutParams(-1, -2))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(premiumMiniButton("▶ پخش") { openPlayer(item, allLinks, bestIndex) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        actions.addView(premiumMiniButton("⇩ دانلود") { showDownloadForLinks(item, epLinks) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        card.addView(actions)
        return card
    }

    private fun bestEpisodeLink(epLinks: List<JSONObject>): JSONObject {
        return epLinks.sortedWith(
            compareByDescending<JSONObject> { qualityScore(it.optString("quality")) }
                .thenBy { if (it.optString("type") == "dub") 0 else 1 }
        ).firstOrNull() ?: JSONObject()
    }

    private fun episodeSubtitle(first: JSONObject, epLinks: List<JSONObject>): String {
        val name = first.optString("episode_name").ifBlank { first.optString("name") }
        val versions = epLinks.map { linkTypeFa(it) }.distinct().joinToString(" / ")
        val quality = epLinks.map { it.optString("quality") }.filter { it.isNotBlank() }.distinct().joinToString("، ")
        return listOf(name, versions, quality).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "نسخه‌های قابل پخش" }
    }

    private fun runtimeText(link: JSONObject): String {
        return link.optString("runtime").ifBlank { link.optString("duration").ifBlank { "--" } }
    }


    private fun isAudioOnly(link: JSONObject): Boolean {
        val raw = listOf(
            link.optString("type"),
            link.optString("type_fa"),
            link.optString("label"),
            link.optString("display_label"),
            link.optString("title"),
            link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)

        return raw.contains("audio") ||
                raw.contains("voice") ||
                raw.contains("dubbed_audio") ||
                raw.contains("sound") ||
                raw.contains("صوت") ||
                raw.contains("صدا") ||
                raw.contains("دوبله جدا") ||
                raw.contains("صوت دوبله")
    }

        private fun linkTypeFa(link: JSONObject): String {
        if (isAudioOnly(link)) return ui("صوت دوبله")
        val t = (link.optString("type") + " " + link.optString("type_fa") + " " + link.optString("label") + " " + link.optString("display_label")).lowercase(Locale.US)
        return when {
            t.contains("dub") || t.contains("دوبله") -> ui("دوبله")
            t.contains("hard") || t.contains("هارد") -> ui("هاردساب")
            t.contains("sub") || t.contains("زیرنویس") -> ui("زیرنویس")
            else -> ui("زیرنویس")
        }
    }

    private fun premiumQualityChip(link: JSONObject, active: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = qualityChipText(link)
            setTextColor(white)
            textSize = 10.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = qualityGradient(link, active)
            applyTvFocusHalo(this, 16, 1.04f, 0f)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { click() }
            minWidth = dp(70)
        }
    }

    private fun qualityChipText(link: JSONObject): String {
        val q = link.optString("quality").ifBlank { "نامشخص" }.uppercase(Locale.US)
        val kind = linkTypeFa(link)
        val label = (link.optString("display_label") + " " + link.optString("label")).uppercase(Locale.US)
        val tags = mutableListOf<String>()
        if (label.contains("4K") || q.contains("2160")) tags.add("4K")
        if (label.contains("HDR")) tags.add("HDR")
        if (label.contains("DOLBY")) tags.add("DV")
        if (label.contains("HEVC") || label.contains("H265")) tags.add("HEVC")
        return (listOf(q, kind) + tags).joinToString(" • ")
    }

    private fun qualityGradient(link: JSONObject, active: Boolean): GradientDrawable {
        val label = qualityChipText(link).uppercase(Locale.US)
        val colors = when {
            label.contains("4K") -> intArrayOf(Color.rgb(120, 70, 255), Color.rgb(30, 170, 255))
            label.contains("1080") -> intArrayOf(Color.rgb(0, 105, 255), Color.rgb(30, 175, 255))
            label.contains("720") -> intArrayOf(Color.rgb(0, 145, 130), Color.rgb(0, 205, 175))
            label.contains("480") -> intArrayOf(Color.rgb(85, 95, 125), Color.rgb(125, 140, 175))
            label.contains("دوبله") -> intArrayOf(Color.rgb(30, 90, 215), Color.rgb(90, 70, 245))
            label.contains("زیرنویس") -> intArrayOf(Color.rgb(180, 115, 20), Color.rgb(225, 170, 45))
            else -> intArrayOf(Color.rgb(42, 55, 82), Color.rgb(70, 88, 125))
        }
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = dp(16).toFloat()
            setStroke(dp(if (active) 2 else 1), if (active) Color.argb(230, 230, 245, 255) else Color.argb(105, 150, 180, 230))
        }
    }

    private fun premiumMiniButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 12.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.rgb(14, 27, 50), dp(16), Color.argb(125, 65, 105, 170))
            applyTvFocusHalo(this, 16, 1.04f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun showDownloadForLinks(item: JSONObject, links: List<JSONObject>) {
        if (links.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(Color.rgb(8, 14, 26), dp(22), Color.argb(155, 235, 35, 45))
        }
        scroll.addView(box)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, dp(12))
        }
        head.addView(FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(235, 35, 45), Color.rgb(245, 184, 75))).apply { cornerRadius = dp(18).toFloat() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_download)
                setColorFilter(white)
            }, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titleBox.addView(TextView(this).apply {
            text = "باکس دانلود"
            setTextColor(white)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titleBox.addView(TextView(this).apply {
            text = "روی آیکن دانلود بزن و روش دانلود را انتخاب کن"
            setTextColor(muted)
            textSize = 11.8f
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(head)
        box.addView(downloadNotice())
        groupedDownloadBlocks(item, links).forEach { block ->
            box.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        AlertDialog.Builder(this)
            .setView(scroll)
            .show()
    }

    private fun showPlayablePage(item: JSONObject, links: List<JSONObject>) {
        currentScreen = "player"
        buildBottomNav()
        clear()

        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "پخش آنلاین" }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(82))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(9, 16, 29), dp(22), Color.argb(110, 255, 185, 45))
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        head.addView(svgIconButton(R.drawable.ic_player_back) { showDetail(item) }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(14) })
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titleBox.addView(TextView(this).apply {
            text = if (isSeriesLinks(links)) "انتخاب فصل و قسمت" else "انتخاب نسخه پخش"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titleBox.addView(TextView(this).apply {
            text = title
            setTextColor(Color.rgb(178, 188, 205))
            textSize = 13.5f
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(5), 0, 0)
        })
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        page.addView(TextView(this).apply {
            text = "با کنترل روی نسخه برو و OK را بزن. برای دانلود از آیکن دانلود کنار هر نسخه استفاده کن."
            setTextColor(Color.rgb(205, 214, 230))
            textSize = 12.6f
            gravity = Gravity.RIGHT
            background = rounded(Color.argb(90, 255, 176, 30), dp(13), Color.argb(75, 255, 214, 90))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        page.addView(downloadNotice(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        groupedDownloadBlocks(item, links).forEach { block ->
            page.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }

        applyTvFocusToClickableTree(page)
        focusFirstTvClickable(page)
    }

        private fun showPlayableSheet(item: JSONObject) {
        val links = playableLinks(item)
        if (links.isEmpty()) {
            Toast.makeText(this, ui("لینک پخش مستقیم پیدا نشد"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isTvLike()) { showPlayablePage(item, links); return }

        lateinit var dialog: AlertDialog
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { ui("انتخاب نسخه پخش") }
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = rounded(Color.rgb(7, 12, 22), dp(24), Color.argb(150, 139, 92, 246))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply {
            text = if (isSeriesLinks(links)) ui("انتخاب فصل و قسمت") else ui("انتخاب نسخه پخش")
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(Color.WHITE)
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(58,255,255,255), dp(17), Color.argb(45,255,255,255))
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        shell.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        shell.addView(TextView(this).apply { text = title; setTextColor(Color.rgb(178, 188, 205)); textSize = 12f; gravity = Gravity.RIGHT; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(5), 0, dp(10)) })
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        scroll.addView(box)
        box.addView(downloadNotice(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        groupedDownloadBlocks(item, links).forEach { block -> box.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }) }
        shell.addView(scroll)
        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
    }

    private fun svgHeaderIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(Color.TRANSPARENT, dp(20), Color.TRANSPARENT)
            applyTvFocusHalo(this, 999, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (isLightTheme()) Color.rgb(25, 28, 34) else Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER))
        }
    }

    private fun svgIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(if (isLightTheme()) Color.argb(225,255,255,255) else Color.argb(150,0,0,0), dp(999), alphaLine(80))
            elevation = dp(8).toFloat()
            applyTvFocusHalo(this, 999, 1.08f, dp(8).toFloat())
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (isLightTheme()) Color.rgb(18,20,24) else Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
    }

    private fun iconActionButton(label: String, iconRes: Int, primary: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (primary) blueGradient(dp(22)) else rounded(Color.argb(if (isLightTheme()) 210 else 130, if (isLightTheme()) 255 else 0, if (isLightTheme()) 255 else 0, if (isLightTheme()) 255 else 0), dp(22), alphaLine(110))
            setPadding(dp(14), 0, dp(14), 0)
            elevation = if (primary) dp(10).toFloat() else dp(4).toFloat()
            applyTvFocusHalo(this, 24, 1.045f, elevation)
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (primary) alphaTextOnPrimary() else white)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(if (primary) alphaTextOnPrimary() else white)
                textSize = 13.1f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun downloadBrandButton(label: String, iconRes: Int, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 24, 42), dp(16), Color.argb(160, 74, 115, 180))
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(white)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun infoCell(iconRes: Int, label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(11, 19, 34), dp(14), Color.rgb(23, 39, 64))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(blue2)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            texts.addView(TextView(this@MainActivity).apply { text = label; setTextColor(faint); textSize = 10.5f })
            texts.addView(TextView(this@MainActivity).apply { text = value.ifBlank { "-" }; setTextColor(white); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1 })
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun linkButton(label: String, primary: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = if (primary) 14f else 11.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (primary) blueGradient(dp(16)) else rounded(Color.rgb(6, 11, 20), dp(14), Color.rgb(39, 62, 96))
            setOnClickListener { click() }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = blueGradient(dp(18))
            setOnClickListener { click() }
        }
    }

    private fun playbackChoiceButton(
        iconRes: Int,
        title: String,
        subtitle: String,
        accent: Int,
        tintIcon: Boolean = false,
        click: () -> Unit
    ): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 21, 37), dp(19), Color.argb(165, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setPadding(dp(13), dp(11), dp(13), dp(11))
            elevation = dp(3).toFloat()
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 20, 1.025f, elevation)
            setOnClickListener {
                animate().scaleX(0.975f).scaleY(0.975f).setDuration(65).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(95).start()
                    click()
                }.start()
            }

            val iconShell = FrameLayout(this@MainActivity).apply {
                background = rounded(Color.argb(245, 255, 255, 255), dp(15), Color.argb(70, 255, 255, 255))
            }
            iconShell.addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = title
                if (tintIcon) setColorFilter(accent)
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addView(iconShell, LinearLayout.LayoutParams(dp(50), dp(50)).apply { marginStart = dp(12) })

            val labels = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            labels.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.4f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            labels.addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(Color.rgb(163, 177, 198))
                textSize = 11.2f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(4), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))

            addView(TextView(this@MainActivity).apply {
                text = "‹"
                setTextColor(accent)
                textSize = 27f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(28), dp(44)))
        }
    }

    private fun playbackMime(link: JSONObject): String {
        return if (isAudioOnly(link)) "audio/*" else "video/*"
    }

    private fun launchVlcPlayer(link: JSONObject, title: String) {
        val url = link.optString("url").trim()
        if (url.isBlank()) {
            Toast.makeText(this, t("لینک پخش معتبر نیست", "Playback link is invalid"), Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), playbackMime(link))
            setPackage("org.videolan.vlc")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("title", title)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        try {
            startActivity(intent)
        } catch (_: Throwable) {
            Toast.makeText(this, t("VLC نصب نیست؛ پلیرهای دیگر نمایش داده شدند", "VLC is not installed; showing other players"), Toast.LENGTH_LONG).show()
            launchOtherPlayers(link, title)
        }
    }

    private fun launchOtherPlayers(link: JSONObject, title: String) {
        val url = link.optString("url").trim()
        if (url.isBlank()) {
            Toast.makeText(this, t("لینک پخش معتبر نیست", "Playback link is invalid"), Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), playbackMime(link))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        try {
            startActivity(Intent.createChooser(intent, t("انتخاب پلیر خارجی", "Choose an external player")))
        } catch (_: Throwable) {
            Toast.makeText(this, t("پلیر سازگاری روی دستگاه پیدا نشد", "No compatible player was found"), Toast.LENGTH_LONG).show()
        }
    }

    private fun showPlaybackMethodDialog(
        item: JSONObject,
        selectedLink: JSONObject,
        title: String,
        payload: JSONObject
    ) {
        lateinit var dialog: AlertDialog
        val accentBlue = Color.rgb(45, 144, 255)
        val accentOrange = Color.rgb(247, 144, 30)
        val accentPurple = Color.rgb(167, 109, 255)
        val selectedLabel = selectedLink.optString("display_label")
            .ifBlank { selectedLink.optString("quality") }
            .ifBlank { selectedLink.optString("label") }
            .ifBlank { t("نسخه انتخاب‌شده", "Selected version") }

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(17), dp(15), dp(17), dp(17))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(8, 14, 26), Color.rgb(15, 23, 41))).apply {
                cornerRadius = dp(27).toFloat()
                setStroke(dp(1), Color.argb(125, 112, 79, 228))
            }
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val brandIcon = FrameLayout(this).apply {
            background = rounded(Color.argb(245, 255, 255, 255), dp(16), Color.argb(60, 255, 255, 255))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.app_icon_bankmovie)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        }
        head.addView(brandIcon, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(12) })

        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        heading.addView(TextView(this@MainActivity).apply {
            text = t("نحوه پخش را انتخاب کنید", "Choose how to play")
            setTextColor(Color.WHITE)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        heading.addView(TextView(this@MainActivity).apply {
            text = "$selectedLabel • $title"
            setTextColor(Color.rgb(157, 171, 193))
            textSize = 11.5f
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))

        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(52, 255, 255, 255), dp(16), Color.argb(55, 255, 255, 255))
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(8) })
        shell.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        shell.addView(TextView(this).apply {
            text = t("پلیر دلخواهت را انتخاب کن؛ کیفیت و لینک همان نسخه حفظ می‌شود.", "Choose your preferred player; the selected quality and link stay unchanged.")
            setTextColor(Color.rgb(194, 204, 221))
            textSize = 12f
            gravity = Gravity.RIGHT
            background = rounded(Color.argb(55, 92, 119, 176), dp(14), Color.argb(55, 117, 142, 196))
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        shell.addView(playbackChoiceButton(
            R.drawable.app_icon_bankmovie,
            t("پخش با Bankmovie", "Play with Bankmovie"),
            t("پلیر داخلی، هماهنگ با زیرنویس و ادامه تماشا", "Built-in player with subtitles and continue watching"),
            accentBlue,
            false
        ) {
            dialog.dismiss()
            if (item.length() > 0) recordContinue(item, selectedLink)
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_VIDEO_URL, selectedLink.optString("url"))
                putExtra(PlayerActivity.EXTRA_TITLE, title)
                putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, payload.toString())
            })
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        shell.addView(playbackChoiceButton(
            R.drawable.ic_vlc_logo,
            t("پخش با VLC", "Play with VLC"),
            t("بازکردن مستقیم همین نسخه در VLC", "Open this version directly in VLC"),
            accentOrange,
            false
        ) {
            dialog.dismiss()
            if (item.length() > 0) recordContinue(item, selectedLink)
            launchVlcPlayer(selectedLink, title)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        shell.addView(playbackChoiceButton(
            R.drawable.ic_external_player,
            t("پخش با دیگر پلیرهای خارجی", "Play with another external player"),
            t("MX Player، XPlayer و پلیرهای نصب‌شده دستگاه", "MX Player, XPlayer, and other installed apps"),
            accentPurple,
            true
        ) {
            dialog.dismiss()
            if (item.length() > 0) recordContinue(item, selectedLink)
            launchOtherPlayers(selectedLink, title)
        })

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setDimAmount(0.72f)
            dialog.window?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val width = (resources.displayMetrics.widthPixels - dp(28)).coerceAtMost(dp(470))
            dialog.window?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog.window?.setGravity(Gravity.CENTER)
        }
        dialog.show()
    }

    private fun openPlayer(item: JSONObject, links: List<JSONObject>, selected: Int) {
        if (links.isEmpty()) return
        val safeIndex = selected.coerceIn(0, links.size - 1)
        val selectedLink = links[safeIndex]
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { t("پخش آنلاین", "Online playback") }
        val arr = JSONArray()
        links.forEach { l ->
            arr.put(JSONObject().apply {
                put("url", l.optString("url"))
                put("title", title)
                put("quality", l.optString("quality"))
                put("type", l.optString("type"))
                put("label", l.optString("label"))
                put("display_label", l.optString("display_label"))
                put("type_fa", l.optString("type_fa"))
                put("is_audio", l.optBoolean("is_audio", false))
                put("season", l.optString("season"))
                put("episode", l.optString("episode"))
            })
        }
        val payload = JSONObject().apply {
            put("video", selectedLink.optString("url"))
            put("title", title)
            put("selectedIndex", safeIndex)
            put("tracks", arr)
        }
        showPlaybackMethodDialog(item, selectedLink, title, payload)
    }

    private fun playableLinks(item: JSONObject): List<JSONObject> {
        val play = item.optJSONObject("play")
        val arr = play?.optJSONArray("links") ?: item.optJSONArray("links") ?: item.optJSONArray("downloads") ?: JSONArray()
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val l = arr.optJSONObject(i) ?: continue
            val url = l.optString("url")
            if (url.isBlank()) continue
            val http = url.startsWith("http://", true) || url.startsWith("https://", true)
            val direct = l.optBoolean("is_direct", true)
            if (http || direct || isVideo(url) || isAudioOnly(l)) out.add(l)
        }
        return out.sortedWith(
            compareBy<JSONObject> { it.optInt("season", 0) }
                .thenBy { it.optInt("episode", 0) }
                .thenBy { linkKindKey(it) }
                .thenByDescending { qualityScore(it.optString("quality")) }
                .thenBy { it.optString("display_label") }
        )
    }

    private fun isSeriesLinks(links: List<JSONObject>) = links.any { it.optInt("season", 0) > 0 || it.optInt("episode", 0) > 0 }

    private fun isVideo(url: String): Boolean {
        val u = url.lowercase(Locale.US)
        return u.startsWith("http") && (
            u.contains(".mkv") || u.contains(".mp4") || u.contains(".m3u8") || u.contains(".mpd") ||
            u.contains("format=mpd") || u.contains("dash") || u.contains("hls") ||
            u.contains(".avi") || u.contains(".webm") || u.contains(".mov")
        )
    }

    private fun qualityScore(q: String) = Regex("(\\d+)").find(q)?.value?.toIntOrNull() ?: 0

    private fun linkLabel(link: JSONObject): String {
        val ep = if (link.optInt("season", 0) > 0 || link.optInt("episode", 0) > 0) "فصل ${link.optInt("season", 0)} قسمت ${link.optInt("episode", 0)} • " else ""
        return ep + link.optString("display_label").ifBlank { shortLinkLabel(link) }
    }

    private fun shortLinkLabel(link: JSONObject): String {
        val display = link.optString("display_label").trim()
        if (display.isNotBlank() && !display.equals("unknown", true) && display != "نامشخص") return display
        val kind = linkTypeFa(link)
        val q = link.optString("quality").ifBlank { "کیفیت نامشخص" }
        return "$q • $kind"
    }

    private fun genresText(item: JSONObject): String {
        val arr = item.optJSONArray("genres") ?: return ""
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) out.add(arr.optString(i))
        return out.joinToString("   ")
    }

    private fun cleanRating(v: String): String {
        if (v.isBlank() || v == "null") return "N/A"
        return try { String.format(Locale.US, "%.1f", v.toDouble()) } catch (_: Throwable) { v.take(3) }
    }

    private fun iconText(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(60, 15, 25, 42), dp(17), Color.TRANSPARENT)
        }
    }

        private fun chip(label: String, active: Boolean): TextView {
        return TextView(this).apply {
            text = ui(label)
            setTextColor(if (active) alphaTextOnPrimary() else white)
            textSize = 12.6f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) blueGradient(dp(18)) else rounded(alphaSurface2(), dp(18), alphaLine(80))
            setPadding(dp(18), 0, dp(18), 0)
            applyTvFocusHalo(this, 20, 1.05f, 0f)
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")


    private fun showMenuDialog() {
        val items = arrayOf("خانه", "فیلم‌های بروز شده", "سریال‌های بروز شده", "انیمه", "ترکی", "کالکشن‌ها", "جستجو")
        AlertDialog.Builder(this)
            .setTitle("Bankmovie")
            .setItems(items) { _, which ->
                when (which) {
                    0 -> showHome()
                    1 -> showList("فیلم‌های بروز شده", 1, "updated_movies")
                    2 -> showList("سریال‌های بروز شده", 1, "updated_series")
                    3 -> showList("انیمه", 1, "anime")
                    4 -> showList("ترکی", 1, "turkish")
                    5 -> showCollections()
                    6 -> showSearch()
                }
            }.show()
    }

    private fun hmacSha256Hex(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun fetch(url: String, cb: (Boolean, JSONObject?, String?) -> Unit) {
        Thread {
            fun request(retried: Boolean) {
                try {
                    val u = URL(url)
                    val c = (u.openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000
                        readTimeout = 18000
                        instanceFollowRedirects = true
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("User-Agent", "BankmovieAndroidNative/1.4")
                        setRequestProperty("Cache-Control", "no-cache")
                    }
                    if (u.path.endsWith("app_api.php")) {
                        val ts = (System.currentTimeMillis() / 1000L + serverClockOffsetSec).toString()
                        val pathQuery = u.path + if (u.query.isNullOrBlank()) "" else "?${u.query}"
                        c.setRequestProperty("X-BM-App-Key", bmAppKey)
                        c.setRequestProperty("X-BM-Ts", ts)
                        c.setRequestProperty("X-BM-Sign", hmacSha256Hex("$ts|$pathQuery", bmAppSecret))
                    }
                    val code = c.responseCode
                    c.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let { serverClockOffsetSec = it / 1000L - System.currentTimeMillis() / 1000L }
                    if (code == 401 && !retried) { c.disconnect(); request(true); return }
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    if (code in 200..299) cb(true, JSONObject(body), null)
                    else cb(false, null, if (code == 401) "اعتبارسنجی ارتباط انجام نشد. ساعت گوشی را روی حالت خودکار بگذارید و دوباره تلاش کنید." else "خطای موقت ارتباطی")
                    c.disconnect()
                } catch (_: Throwable) {
                    cb(false, null, "خطای اتصال")
                }
            }
            request(false)
        }.start()
    }

    private fun normalizeImageUrl(raw: String): String {
        var u = raw.trim()
        if (u.isBlank() || u == "null") return ""
        if (u.startsWith("//")) return "https:$u"
        if (u.startsWith("http://") || u.startsWith("https://")) return u
        if (u.startsWith("/")) return activeDomain.trimEnd('/') + u
        if (u.startsWith("posters/") || u.startsWith("uploads/") || u.startsWith("assets/") || u.startsWith("storage/")) {
            return activeDomain.trimEnd('/') + "/" + u.trimStart('/')
        }
        return activeDomain.trimEnd('/') + "/" + u.trimStart('/')
    }

    private fun loadImage(url: String, target: ImageView) {
        val finalUrl = normalizeImageUrl(url)
        if (finalUrl.isBlank()) return
        val cached = imageCache[finalUrl]
        if (cached != null) {
            target.setImageBitmap(cached)
            return
        }
        Thread {
            var conn: HttpURLConnection? = null
            try {
                conn = URL(finalUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 6500
                conn.readTimeout = 8500
                conn.instanceFollowRedirects = true
                conn.setRequestProperty("User-Agent", "Bankmovie Android")
                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                var bmp = BitmapFactory.decodeStream(conn.inputStream, null, opts)
                if (bmp != null) {
                    val maxSide = 1300
                    val w = bmp.width
                    val h = bmp.height
                    val bigger = kotlin.math.max(w, h)
                    if (bigger > maxSide) {
                        val ratio = maxSide.toFloat() / bigger.toFloat()
                        val scaled = Bitmap.createScaledBitmap(bmp, (w * ratio).toInt().coerceAtLeast(1), (h * ratio).toInt().coerceAtLeast(1), true)
                        if (scaled != bmp) {
                            try { bmp.recycle() } catch (_: Throwable) {}
                            bmp = scaled
                        }
                    }
                    synchronized(imageCache) {
                        if (imageCache.size > 90) imageCache.clear()
                        imageCache[finalUrl] = bmp
                    }
                    runOnUiThread {
                        try { target.setImageBitmap(bmp) } catch (_: Throwable) {}
                    }
                }
            } catch (_: OutOfMemoryError) {
                try { synchronized(imageCache) { imageCache.clear() } } catch (_: Throwable) {}
            } catch (_: Throwable) {
            } finally {
                try { conn?.disconnect() } catch (_: Throwable) {}
            }
        }.start()
    }

    private fun alphaSurface(): Int = if (isLightTheme()) Color.rgb(255,255,255) else Color.rgb(13,13,15)
    private fun alphaSurface2(): Int = if (isLightTheme()) Color.rgb(245,246,249) else Color.rgb(22,22,25)
    private fun alphaLine(a: Int = 90): Int = if (isLightTheme()) Color.argb(a, 10, 12, 16) else Color.argb(a, 255, 255, 255)
    private fun alphaTextOnPrimary(): Int = if (isLightTheme()) Color.WHITE else Color.rgb(12, 12, 14)
    private fun alphaPrimary(): Int = if (isLightTheme()) Color.rgb(18, 20, 24) else Color.WHITE
    private fun alphaSecondaryText(): Int = if (isLightTheme()) Color.rgb(94, 96, 104) else Color.rgb(178, 182, 192)

    private fun alphaPill(label: String, active: Boolean = false): TextView {
        val clean = label.trim().ifBlank { return TextView(this) }
        val imdb = clean.startsWith("IMDb", ignoreCase = true)
        return TextView(this).apply {
            text = clean
            setTextColor(
                when {
                    imdb -> Color.rgb(20, 20, 20)
                    active -> alphaTextOnPrimary()
                    else -> white
                }
            )
            textSize = 12.0f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            minWidth = dp(48)
            background = when {
                imdb -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(255, 215, 72), Color.rgb(255, 184, 28))).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), Color.argb(150, 255, 235, 120))
                }
                active -> blueGradient(dp(17))
                else -> rounded(if (isLightTheme()) Color.rgb(246,247,250) else Color.argb(118,255,255,255), dp(17), Color.argb(62, 255, 255, 255))
            }
            setPadding(dp(13), 0, dp(13), 0)
        }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun blueGradient(radius: Int): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.rgb(0, 108, 255), Color.rgb(32, 164, 255))
        ).apply {
            cornerRadius = radius.toFloat()
            setStroke(dp(1), Color.argb(135, 145, 210, 255))
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
