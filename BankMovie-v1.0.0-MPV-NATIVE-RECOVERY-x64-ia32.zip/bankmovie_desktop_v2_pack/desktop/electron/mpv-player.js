'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
function bundledPlayer(resourcesPath, packaged, root=path.join(__dirname,'..')) {
  const base = packaged ? resourcesPath : root;
  const exe = path.join(base, packaged ? 'mpv' : 'vendor/mpv', 'mpv.exe');
  const script = path.join(base, 'player', 'cinema.lua');
  if (!fs.existsSync(exe) || !fs.existsSync(script)) return null;
  return {id:'bm-mpv',name:'BankMovie (MPV)',path:exe,script,score:1000,subtitleSupport:true};
}
function cleanTitle(value) {return String(value||'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,240);}
function argsFor(player, target, meta={}, local=false) {
  if (typeof target!=='string'||!target||/[\x00-\x1f]/.test(target)) throw Error('Invalid media path');
  if(local){if(!path.isAbsolute(target))throw Error('Invalid local media path');}
  else {const u=new URL(target);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid media URL');}
  const args=['--no-config','--load-scripts=no','--osc=no','--input-default-bindings=no','--input-builtin-dragging=no','--input-builtin-drag-and-drop=no','--ytdl=no','--load-unsafe-playlists=no','--tls-verify=yes','--no-terminal','--force-window=yes','--idle=no','--keep-open=yes','--geometry=80%x80%','--hwdec=auto-safe','--cache=auto','--sub-auto='+ (local?'exact':'no'),'--audio-file-auto=no','--cover-art-auto=no','--slang=fa,fas,per,persian,en,eng','--script='+player.script];
  const title=cleanTitle(meta.title || (local?path.basename(target):'BankMovie'));
  if(title)args.push('--force-media-title='+title);
  if(meta.subtitlePath)args.push('--sub-file='+meta.subtitlePath);
  args.push('--',target);
  return args;
}
async function launch(player,target,meta={},local=false,spawnFn=spawn){
  const args=argsFor(player,target,meta,local);
  await new Promise((resolve,reject)=>{
    const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:true,stdio:'ignore',windowsHide:false});
    child.once('error',()=>reject(new Error('اجرای موتور MPV ناموفق بود.')));
    child.once('spawn',()=>{child.unref();resolve();});
  });
  return {ok:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)};
}
// Standalone native MPV: no HWND parenting and no opaque Electron overlay.
// One supervised process per BankMovie window. Never hide the main interface.
const active = new WeakMap();
function closeManaged(win) { const session=win&&active.get(win); if(session)session.close(); }
function launchManaged(player,target,meta={},local=false,win,opts={}) {
  if(!win||win.isDestroyed()) return Promise.reject(Error('پنجره بانک‌مووی در دسترس نیست.'));
  let args;
  try { args=argsFor(player,target,meta,local); } catch(e) { return Promise.reject(e); }
  closeManaged(win);
  const spawnFn=opts.spawnFn||spawn;
  return new Promise((resolve,reject)=>{
    let child,finished=false,started=false,intentional=false;
    const session={close};
    function cleanup(error){
      if(finished)return;finished=true;
      if(active.get(win)===session)active.delete(win);
      win.removeListener('closed',close);
      if(!started)reject(error||Error('راه‌اندازی پلیر لغو شد.'));
      else if(error&&!intentional&&opts.onError)opts.onError(error);
    }
    function close(){
      if(finished)return;intentional=true;
      if(child&&!child.killed&&child.exitCode==null){try{child.kill();}catch{}}
      cleanup();
    }
    active.set(win,session);
    win.once('closed',close);
    try {
      child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:false,stdio:'ignore',windowsHide:false});
      child.once('spawn',()=>{
        if(finished)return;started=true;
        resolve({ok:true,embedded:false,started:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)});
      });
      child.once('error',()=>cleanup(Error('اجرای موتور MPV ناموفق بود.')));
      child.once('exit',(code)=>{
        const error=!intentional&&(!started||code!==0)?Error('MPV بسته شد (کد '+(Number.isInteger(code)?code:'نامشخص')+').'):null;
        cleanup(error);
      });
    } catch(e) { cleanup(Error('اجرای موتور MPV ناموفق بود.')); }
  });
}
module.exports={bundledPlayer,argsFor,launch,launchManaged,closeManaged};
