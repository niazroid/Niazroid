param([Parameter(Mandatory=$true)][ValidateSet('x64','ia32')][string]$Arch)
$ErrorActionPreference = 'Stop'
$root = Split-Path $PSScriptRoot -Parent
$version = '0.42.0'
if ($Arch -eq 'x64') {
  $name = "mpv-v$version-x86_64-pc-windows-msvc.zip"
  $expected = '8dd69cbab079086765fa5d873c09513b2834b85d146c1301718a757e8c0595ef'
  $machine = 0x8664
} else {
  $name = "mpv-v$version-i686-w64-mingw32.zip"
  $expected = 'af2e344e617f6af3ac7d9e03c55251b22e9797c354ad9ebc6d3b6c13bd39b2d9'
  $machine = 0x014c
}
$temp = Join-Path ([System.IO.Path]::GetTempPath()) ('bm-mpv-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $temp | Out-Null
try {
  $zip = Join-Path $temp $name
  $expanded = Join-Path $temp 'expanded'
  $url = "https://github.com/mpv-player/mpv/releases/download/v$version/$name"
  Invoke-WebRequest -Uri $url -OutFile $zip
  $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $zip).Hash.ToLowerInvariant()
  if ($actual -ne $expected) { throw 'MPV archive SHA256 mismatch' }
  Expand-Archive -LiteralPath $zip -DestinationPath $expanded
  $exes = @(Get-ChildItem -LiteralPath $expanded -Recurse -File -Filter 'mpv.exe')
  if ($exes.Count -ne 1) { throw 'Expected exactly one mpv.exe in verified archive' }
  $bytes = [System.IO.File]::ReadAllBytes($exes[0].FullName)
  $pe = [BitConverter]::ToInt32($bytes,0x3c)
  if ([BitConverter]::ToUInt32($bytes,$pe) -ne 0x4550 -or [BitConverter]::ToUInt16($bytes,$pe+4) -ne $machine) { throw 'MPV executable architecture mismatch' }
  $target = Join-Path $root 'vendor/mpv'
  if (Test-Path $target) { Remove-Item -LiteralPath $target -Recurse -Force }
  New-Item -ItemType Directory -Path $target -Force | Out-Null
  # Copy the executable directory, then retain any notices/docs from wrapper directory too.
  Get-ChildItem -LiteralPath $exes[0].Directory.FullName -Force | Copy-Item -Destination $target -Recurse -Force
  if ($exes[0].Directory.FullName -ne $expanded) {
    $original = Join-Path $target 'upstream-archive'
    New-Item -ItemType Directory -Path $original -Force | Out-Null
    Get-ChildItem -LiteralPath $expanded -File -Force | Copy-Item -Destination $original -Force
  }
  if (-not (Test-Path -LiteralPath (Join-Path $target 'mpv.exe'))) { throw 'MPV not staged' }
  # Do not ship debug symbols or the console launcher (not used by our GUI).
  Get-ChildItem -LiteralPath $target -Recurse -File | Where-Object { $_.Extension -in '.pdb','.lib','.exp' -or $_.Name -eq 'mpv.com' } | Remove-Item -Force
  $size = (Get-ChildItem -LiteralPath $target -Recurse -File | Measure-Object Length -Sum).Sum
  Write-Host ("MPV staged size: {0:N2} MiB" -f ($size / 1MB))
  @("version=$version","archive=$name","sha256=$actual","source=$url") | Set-Content -LiteralPath (Join-Path $target 'BANKMOVIE-UPSTREAM.txt') -Encoding ascii
  Write-Host "Verified MPV $version for $Arch"
} finally { Remove-Item -LiteralPath $temp -Recurse -Force -ErrorAction SilentlyContinue }
