'use strict';
const assert=require('node:assert/strict');const {EventEmitter}=require('node:events');const P=require('../electron/mpv-player');
const player={id:'bm-mpv',name:'BankMovie',path:'C:/mpv.exe',script:'C:/cinema.lua'};
const url='https://example.com/movie.mkv';
function fixture(){
 const win=new EventEmitter();win.isDestroyed=()=>false;
 // No native handle, overlay, hide or fullscreen methods: the renderer must remain untouched.
 const children=[],errors=[];const opts={onError:e=>errors.push(e),spawnFn(exe,args,o){
  assert.equal(exe,player.path);assert.equal(o.shell,false);assert.equal(o.detached,false);
  assert.ok(!args.some(a=>/^--(?:wid|input-ipc-server|script-opts)=/.test(a)));
  assert.ok(args.includes('--geometry=80%x80%'));assert.ok(args.includes('--tls-verify=yes'));
  const c=new EventEmitter();c.exitCode=null;c.kill=()=>{c.killed=true;queueMicrotask(()=>c.emit('exit',1));};children.push(c);return c;
 }};return {win,opts,children,errors};
}
(async()=>{
 const f=fixture();let a=P.launchManaged(player,url,{},false,f.win,f.opts);f.children[0].emit('spawn');assert.equal((await a).embedded,false);
 let b=P.launchManaged(player,url,{},false,f.win,f.opts);assert.ok(f.children[0].killed);f.children[1].emit('spawn');await b;assert.equal(f.errors.length,0);assert.equal(f.win.listenerCount('closed'),1);
 f.children[1].emit('exit',7);assert.match(f.errors[0].message,/7/);assert.equal(f.win.listenerCount('closed'),0);
 let c=P.launchManaged(player,url,{},false,f.win,f.opts);f.children[2].emit('error',Error('secret'));await assert.rejects(c,/MPV/);assert.equal(f.win.listenerCount('closed'),0);
 const d=P.launchManaged(player,url,{},false,f.win,f.opts);const rejected=assert.rejects(d,/لغو/);const e=P.launchManaged(player,url,{},false,f.win,f.opts);await rejected;f.children[4].emit('spawn');await e;f.win.emit('closed');assert.ok(f.children[4].killed);assert.equal(f.win.listenerCount('closed'),0);
 const g=fixture();const file=require('path').resolve('example.mkv');const h=P.launchManaged(player,file,{},true,g.win,g.opts);g.children[0].emit('spawn');await h;P.closeManaged(g.win);assert.ok(g.children[0].killed);
 assert.equal(g.errors.length,0);console.log('PASS: native standalone only, no opaque host, replacement, exit, spawn failure, close and local playback dispatch');
})().catch(e=>{console.error(e);process.exitCode=1});
