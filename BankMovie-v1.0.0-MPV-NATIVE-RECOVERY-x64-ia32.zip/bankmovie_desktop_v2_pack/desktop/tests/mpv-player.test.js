'use strict';
const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');const os=require('os');const {EventEmitter}=require('events');const P=require('../electron/mpv-player');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'bm-mpv-'));
(async()=>{try{
assert.equal(P.bundledPlayer(root,true),null);fs.mkdirSync(path.join(root,'mpv'));fs.mkdirSync(path.join(root,'player'));fs.writeFileSync(path.join(root,'mpv/mpv.exe'),'');fs.writeFileSync(path.join(root,'player/cinema.lua'),'');const p=P.bundledPlayer(root,true);assert.equal(p.id,'bm-mpv');assert.equal(p.score,1000);
const u='https://example.com/movie.mkv?x=1&y=2';const a=P.argsFor(p,u,{title:'--script=evil\nMovie',subtitlePath:'test.srt'});assert.deepEqual(a.slice(-2),['--',u]);assert.ok(a.includes('--tls-verify=yes'));assert.ok(a.includes('--no-config'));assert.ok(a.includes('--script='+p.script));assert.ok(a.includes('--force-media-title=--script=evil Movie'));assert.ok(a.includes('--sub-file=test.srt'));assert.throws(()=>P.argsFor(p,'file:///secret'));assert.throws(()=>P.argsFor(p,'https://user:pass@example.com'));assert.throws(()=>P.argsFor(p,'--script=evil'));assert.throws(()=>P.argsFor(p,'relative.mkv',{},true));
const local=path.join(root,'example.mkv');assert.deepEqual(P.argsFor(p,local,{},true).slice(-2),['--',local]);assert.ok(P.argsFor(p,local,{},true).includes('--sub-auto=exact'));
let ran=false;const result=await P.launch(p,u,{},false,(exe,args,options)=>{assert.equal(exe,p.path);assert.equal(options.shell,false);assert.equal(args.at(-1),u);const e=new EventEmitter();e.unref=()=>{ran=true};queueMicrotask(()=>e.emit('spawn'));return e;});assert.equal(result.player.id,'bm-mpv');assert.ok(ran);
await assert.rejects(P.launch(p,u,{},false,()=>{const e=new EventEmitter();queueMicrotask(()=>e.emit('error',Error('test')));return e;}),/MPV/);
console.log('PASS: bundled discovery, online/local arguments, no shell, safe spawn error and title handling');
}finally{fs.rmSync(root,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exitCode=1;});
