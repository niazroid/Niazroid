// Runs only in the Windows build job, with the verified engine already staged.
const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawnSync}=require('node:child_process');const P=require('../electron/mpv-player');
assert.equal(process.platform,'win32','Windows runtime test');
const root=path.resolve(__dirname,'..');const p=P.bundledPlayer('',false,root);assert.ok(p,'Bundled MPV is staged');
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'bm-mpv-runtime-'));const log=path.join(dir,'mpv.log');
try {
  const args=P.argsFor(p,path.join(__dirname,'mpv-smoke.mkv'),{},true);
  args.splice(args.length-2,0,'--vo=null','--ao=null','--hwdec=no','--force-window=no','--keep-open=no','--frames=12','--sid=1','--log-file='+log);
  const result=spawnSync(p.path,args,{cwd:path.dirname(p.path),windowsHide:true,timeout:30000,stdio:'ignore'});
  assert.ifError(result.error);assert.equal(result.status,0,'MPV runtime exited cleanly');
  const output=fs.readFileSync(log,'utf8');assert.match(output,/Subtitles|Subtitle|subrip/i,'embedded subtitle track detected');
  assert.doesNotMatch(output,/Error parsing option|Lua error|stack traceback|Error opening\/initializing|Failed to open.*mpv-smoke/i);
  console.log('PASS: actual Windows MPV headless MKV video/audio/subtitle startup');
} finally {fs.rmSync(dir,{recursive:true,force:true});}
