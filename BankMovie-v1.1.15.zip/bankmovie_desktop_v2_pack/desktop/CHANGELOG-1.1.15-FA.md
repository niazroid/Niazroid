# BankMovie Desktop 1.1.15

- رفع warning 6010 اینستالر NSIS.
- اتصال BM_GUIINIT از طریق customInit.
- حفظ تم تمام‌مشکی اینستالر.
