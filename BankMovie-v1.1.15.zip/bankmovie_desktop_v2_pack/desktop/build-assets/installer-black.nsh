!include "LogicLib.nsh"

!macro customHeader
  !ifdef MUI_BGCOLOR
    !undef MUI_BGCOLOR
  !endif
  !ifdef MUI_TEXTCOLOR
    !undef MUI_TEXTCOLOR
  !endif
  !ifdef MUI_INSTFILESPAGE_COLORS
    !undef MUI_INSTFILESPAGE_COLORS
  !endif

  !define MUI_BGCOLOR "000000"
  !define MUI_TEXTCOLOR "F5F8FC"
  !define MUI_INSTFILESPAGE_COLORS "F5F8FC 000000"
!macroend

Function BM_DarkControls
  SetCtlColors $HWNDPARENT F5F8FC 000000

  StrCpy $0 1
  bm_parent_low:
    GetDlgItem $1 $HWNDPARENT $0
    StrCmp $1 0 +2
      SetCtlColors $1 F5F8FC 000000
    IntOp $0 $0 + 1
    IntCmp $0 24 bm_parent_high bm_parent_low bm_parent_high

  bm_parent_high:
    StrCpy $0 1000
  bm_parent_high_loop:
    GetDlgItem $1 $HWNDPARENT $0
    StrCmp $1 0 +2
      SetCtlColors $1 F5F8FC 000000
    IntOp $0 $0 + 1
    IntCmp $0 1301 bm_inner bm_parent_high_loop bm_inner

  bm_inner:
    GetDlgItem $2 $HWNDPARENT 1018
    StrCmp $2 0 bm_done
    SetCtlColors $2 F5F8FC 000000

    StrCpy $0 1
  bm_inner_low:
    GetDlgItem $1 $2 $0
    StrCmp $1 0 +2
      SetCtlColors $1 F5F8FC 000000
    IntOp $0 $0 + 1
    IntCmp $0 24 bm_inner_high bm_inner_low bm_inner_high

  bm_inner_high:
    StrCpy $0 1000
  bm_inner_high_loop:
    GetDlgItem $1 $2 $0
    StrCmp $1 0 +2
      SetCtlColors $1 F5F8FC 000000
    IntOp $0 $0 + 1
    IntCmp $0 1301 bm_done bm_inner_high_loop bm_done

  bm_done:
FunctionEnd

Function BM_GUIINIT
  System::Call 'dwmapi::DwmSetWindowAttribute(p $HWNDPARENT, i 20, *i 1, i 4)'
  Call BM_DarkControls
  nsDialogs::CreateTimer BM_DarkControls 140
FunctionEnd

!macro customInit
  Call BM_GUIINIT
!macroend
