const { app, BrowserWindow, ipcMain, dialog, shell, session, safeStorage, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn, execFile, execFileSync } = require('child_process');
const RUNTIME = require('./runtime.generated');

const DEFAULT = Object.freeze({
  controllerUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_config.php`,
  domain: String(RUNTIME.domain || '').replace(/\/$/,''),
  apiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_api.php`,
  fallbackApiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_api.php`,
  accountApiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_user_api.php`
});

let win = null;
let runtimeConfig = null;
const pendingDownloadMeta = new Map(); // id -> meta
const pendingDownloadUrl = new Map();  // original URL -> id
const cancelledPendingDownloads = new Set();
const downloadItems = new Map();
const downloadState = new Map();
const downloadMonitors = new Map();
const forcedPausedDownloads = new Set();
const childWindows = new Set();

/* ===== BankMovie Desktop v1.1.32 — local-only safe Windows shutdown scheduler ===== */
let powerTimer = null;
let powerPlan = { mode:'off', armedAt:0, targetAt:0, countdownUntil:0, trackedIds:[], reason:'' };

function powerSupported(){ return process.platform === 'win32'; }
function trustedMainRenderer(event){
  try {
    if (!win || win.isDestroyed() || !event?.sender || event.sender.id !== win.webContents.id) return false;
    const url = String(event.sender.getURL?.() || '');
    return url.startsWith('file://');
  } catch { return false; }
}
function terminalDownloadState(state){ return ['completed','cancelled','interrupted'].includes(String(state||'')); }
function activeDownloadIds(){
  const ids = new Set();
  for (const id of pendingDownloadMeta.keys()) ids.add(String(id));
  for (const [id, st] of downloadState.entries()) if (!terminalDownloadState(st?.state)) ids.add(String(id));
  return [...ids];
}
function powerPublicStatus(extra={}){
  return {
    supported: powerSupported(),
    mode: powerPlan.mode,
    armed: powerPlan.mode!=='off',
    armedAt:Number(powerPlan.armedAt||0),
    targetAt:Number(powerPlan.targetAt||0),
    countdownUntil:Number(powerPlan.countdownUntil||0),
    trackedCount:Array.isArray(powerPlan.trackedIds)?powerPlan.trackedIds.length:0,
    activeDownloads:activeDownloadIds().length,
    reason:String(powerPlan.reason||''),
    now:Date.now(),
    ...extra
  };
}
function publishPowerStatus(extra={}){
  const st=powerPublicStatus(extra);
  sendToMainWindow('power:status', st);
  return st;
}
function clearPowerTimer(){ if(powerTimer){ clearTimeout(powerTimer); powerTimer=null; } }
function resetPowerPlan(reason=''){
  clearPowerTimer();
  powerPlan={mode:'off',armedAt:0,targetAt:0,countdownUntil:0,trackedIds:[],reason:String(reason||'')};
  return publishPowerStatus();
}
function scheduleAtTimestamp(targetAt){
  clearPowerTimer();
  powerTimer=setTimeout(()=>beginWindowsShutdownCountdown('time'),Math.max(0,Number(targetAt||0)-Date.now()));
}
function runShutdownExe(args){
  return new Promise((resolve,reject)=>{
    execFile('shutdown.exe',args,{windowsHide:true},(err,stdout,stderr)=>{
      if(err)return reject(new Error(String(stderr||err.message||'shutdown.exe failed').trim()));
      resolve(String(stdout||''));
    });
  });
}
async function beginWindowsShutdownCountdown(reason='downloads'){
  if(!powerSupported())return resetPowerPlan('unsupported');
  if(powerPlan.mode==='countdown')return powerPublicStatus();
  clearPowerTimer();
  powerPlan={...powerPlan,mode:'countdown',countdownUntil:Date.now()+60_000,reason:String(reason||'downloads')};
  publishPowerStatus();
  nativeDownloadNotification('خاموشی خودکار BankMovie','ویندوز تا ۶۰ ثانیه دیگر خاموش می‌شود؛ از صفحه دانلودها می‌توانید لغو کنید.');
  try{
    await runShutdownExe(['/s','/t','60','/c','BankMovie: scheduled shutdown. Open BankMovie Downloads to cancel.']);
  }catch(err){
    resetPowerPlan('shutdown_failed');
    nativeDownloadNotification('خاموشی انجام نشد',String(err?.message||err||'خطای ویندوز'));
  }
  return powerPublicStatus();
}
function evaluateAfterDownloadsPlan(){
  if(powerPlan.mode!=='after_downloads')return;
  const ids=Array.isArray(powerPlan.trackedIds)?powerPlan.trackedIds:[];
  if(!ids.length)return;
  let waiting=false;
  for(const id of ids){
    const st=downloadState.get(String(id));
    const state=String(st?.state||'');
    if(state==='cancelled'||state==='interrupted'){
      resetPowerPlan('download_not_completed');
      nativeDownloadNotification('خاموشی خودکار لغو شد','حداقل یک دانلود کامل نشد یا لغو شد.');
      return;
    }
    if(state!=='completed')waiting=true;
  }
  if(!waiting)beginWindowsShutdownCountdown('downloads');
}
function powerTrackDownloadId(id){
  if(powerPlan.mode!=='after_downloads')return;
  const v=String(id||'');if(!v||powerPlan.trackedIds.includes(v))return;
  powerPlan={...powerPlan,trackedIds:[...powerPlan.trackedIds,v]};
  publishPowerStatus();
}
function parseLocalClockTarget(clock){
  const m=String(clock||'').trim().match(/^(\d{2}):(\d{2})$/);if(!m)return 0;
  const hh=Number(m[1]),mm=Number(m[2]);if(hh>23||mm>59)return 0;
  const now=new Date();const d=new Date(now);d.setHours(hh,mm,0,0);
  if(d.getTime()<=now.getTime()+30_000)d.setDate(d.getDate()+1);
  return d.getTime();
}
async function armPowerPlan(event,payload={}){
  if(!trustedMainRenderer(event))throw new Error('درخواست خاموشی از پنجره معتبر نیست');
  if(!win?.isFocused())throw new Error('برای فعال‌سازی خاموشی، پنجره BankMovie باید فعال باشد');
  if(!powerSupported())throw new Error('خاموشی خودکار فقط در نسخه Windows فعال است');
  const mode=String(payload.mode||'');
  if(!['after_downloads','at_time'].includes(mode))throw new Error('حالت خاموشی معتبر نیست');
  if(powerPlan.mode==='countdown')throw new Error('خاموشی ویندوز در حال شمارش معکوس است؛ ابتدا آن را لغو کنید');

  if(mode==='after_downloads'){
    const ids=activeDownloadIds();
    if(!ids.length)throw new Error('هیچ دانلود فعالی برای انتظار وجود ندارد');
    const confirm=await dialog.showMessageBox(win,{type:'question',buttons:['فعال کن','انصراف'],defaultId:1,cancelId:1,title:'خاموشی بعد از دانلودها',message:`بعد از کامل‌شدن ${ids.length} دانلود فعال، ویندوز خاموش شود؟`,detail:'اگر دانلودی لغو یا متوقف شود، خاموشی خودکار لغو می‌شود. قبل از خاموشی ۶۰ ثانیه فرصت لغو دارید.'});
    if(confirm.response!==0)return powerPublicStatus({cancelled:true});
    powerPlan={mode:'after_downloads',armedAt:Date.now(),targetAt:0,countdownUntil:0,trackedIds:ids,reason:'downloads'};
    publishPowerStatus();
    evaluateAfterDownloadsPlan();
    return powerPublicStatus();
  }

  const targetAt=parseLocalClockTarget(payload.time);
  if(!targetAt)throw new Error('زمان معتبر وارد کنید');
  const when=new Date(targetAt).toLocaleString('fa-IR');
  const confirm=await dialog.showMessageBox(win,{type:'warning',buttons:['زمان‌بندی کن','انصراف'],defaultId:1,cancelId:1,title:'خاموشی زمان‌بندی‌شده',message:`ویندوز در ${when} خاموش شود؟`,detail:'این حالت در زمان تعیین‌شده اجرا می‌شود حتی اگر دانلودی هنوز فعال باشد. قبل از خاموشی ۶۰ ثانیه فرصت لغو دارید.'});
  if(confirm.response!==0)return powerPublicStatus({cancelled:true});
  powerPlan={mode:'at_time',armedAt:Date.now(),targetAt,countdownUntil:0,trackedIds:[],reason:'time'};
  scheduleAtTimestamp(targetAt);
  return publishPowerStatus();
}
async function cancelPowerPlan(event){
  if(!trustedMainRenderer(event))throw new Error('درخواست لغو از پنجره معتبر نیست');
  const hadCountdown=powerPlan.mode==='countdown'&&Number(powerPlan.countdownUntil||0)>Date.now();
  clearPowerTimer();
  if(hadCountdown&&powerSupported()){
    try{await runShutdownExe(['/a']);}catch{}
  }
  return resetPowerPlan('cancelled_by_user');
}

function statePath() { return path.join(app.getPath('userData'), 'desktop-state.json'); }
function readState() {
  try { return JSON.parse(fs.readFileSync(statePath(), 'utf8')); } catch { return {}; }
}
function writeState(next) {
  const current = readState();
  const merged = { ...current, ...next };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(merged, null, 2));
  return merged;
}
function saveToken(token) {
  if (!token) return writeState({ authToken: '' });
  if (safeStorage.isEncryptionAvailable()) {
    return writeState({ authToken: safeStorage.encryptString(token).toString('base64'), authEncrypted: true });
  }
  return writeState({ authToken: token, authEncrypted: false });
}
function loadToken() {
  const s = readState();
  if (!s.authToken) return '';
  try {
    return s.authEncrypted && safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(s.authToken, 'base64'))
      : String(s.authToken);
  } catch { return ''; }
}
function settings() {
  const s = readState();
  return {
    downloadDir: s.downloadDir || app.getPath('downloads'),
    preferredArchive: Number(s.preferredArchive || 1),
    preferredPlayer: String(s.preferredPlayer || 'auto'),
    language: String(s.language || 'fa') === 'en' ? 'en' : 'fa'
  };
}
function normalizeBase(url, fallback) {
  try { const u = new URL(url || fallback); return u.toString(); } catch { return fallback; }
}
async function fetchJson(url, options = {}, timeoutMs = 22000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal, headers: { 'Accept': 'application/json', 'X-BM-Client': 'windows', ...(options.headers || {}) } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (!res.ok && !data?.success) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function loadRemoteConfig(force = false) {
  if (runtimeConfig && !force) return runtimeConfig;
  const controller = normalizeBase(DEFAULT.controllerUrl, DEFAULT.controllerUrl);
  try {
    const remote = await fetchJson(controller, { cache: 'no-store' }, 12000);
    const domain = String(remote.active_domain || remote.desktop?.active_domain || DEFAULT.domain).replace(/\/$/, '');
    runtimeConfig = {
      ...remote,
      active_domain: domain,
      api_url: remote.desktop_api_url || remote.api_url || `${domain}/desktop_api.php`,
      account_api_url: remote.account_api_url || `${domain}/desktop_user_api.php`,
      controller_url: controller,
      _online: true
    };
  } catch (error) {
    runtimeConfig = {
      platform: 'windows', active_domain: DEFAULT.domain,
      api_url: DEFAULT.fallbackApiUrl, desktop_api_url: DEFAULT.apiUrl,
      account_api_url: DEFAULT.accountApiUrl, controller_url: controller,
      features: {}, desktop: { enabled: true, features: {} }, _online: false,
      _error: error.message
    };
  }
  return runtimeConfig;
}
function queryUrl(base, params = {}) {
  const u = new URL(base);
  Object.entries(params).forEach(([k,v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach(x => u.searchParams.append(k, String(x)));
    else u.searchParams.set(k, String(v));
  });
  return u;
}
function contentRequestTimeoutMs(action, params = {}) {
  const a = String(action || '').toLowerCase();
  // Large series can return hundreds/thousands of episode/source rows.
  // The website can legitimately need 20-30s, so Detail must not inherit
  // the short generic JSON timeout.
  if (a === 'detail') return 90000;
  if (a === 'play') return 65000;
  if (a === 'boot') return 35000;
  return 30000;
}
async function contentRequest(action, params = {}) {
  const cfg = await loadRemoteConfig();
  // Desktop calls the server-side facade. Static API signing secrets never ship in the EXE.
  const candidates = [cfg.desktop_api_url, cfg.api_url, DEFAULT.apiUrl].filter(Boolean);
  let last;
  for (const base of [...new Set(candidates)]) {
    const url = queryUrl(base, { action, ...params }).toString();
    try {
      const token = loadToken();
      const headers = {
        'X-BM-Client': 'windows',
        'X-BM-Download-System': '2'
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
        headers['X-BM-User-Token'] = token;
      }
      return await fetchJson(url, { cache: 'no-store', headers }, contentRequestTimeoutMs(action, params));
    } catch (e) { last = e; }
  }
  const msg = String(last?.message || '');
  if (/\.php\b|https?:\/\/|bankmovie|runtime|api\d*[_-]?lib|source[_ -]?unavailable/i.test(msg)) {
    throw new Error('ارتباط با این بخش برقرار نشد. لطفاً دوباره تلاش کنید.');
  }
  throw last || new Error('سرور محتوا در دسترس نیست');
}
const searchOptionsCache = new Map();
async function searchOptionsRequest(archive = 3) {
  const a = Number(archive) || 3;
  if (a !== 3) return { success: true, archive: a };
  const hit = searchOptionsCache.get(a);
  if (hit && Date.now() - hit.at < 4 * 60 * 60 * 1000) return hit.data;
  const cfg = await loadRemoteConfig();
  const domain = String(cfg.active_domain || DEFAULT.domain).replace(/\/$/, '');
  const url = queryUrl(`${domain}/api6.php`, { search_options: 1, client: 'app' }).toString();
  try {
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 14000);
    const data = raw?.options || raw?.data || raw || {};
    const result = { success: raw?.success !== false, archive: a, ...data };
    searchOptionsCache.set(a, { at: Date.now(), data: result });
    return result;
  } catch (error) {
    return { success: false, archive: a, message: String(error?.message || 'search options unavailable') };
  }
}


async function advancedSearchRequest(params = {}) {
  const a = Number(params.archive) || 1;
  const page = Math.max(1, Number(params.page) || 1);
  const limit = Math.max(1, Math.min(60, Number(params.limit) || 36));
  const q = String(params.q || params.s || '').trim();
  const type = String(params.type || 'all').trim() || 'all';
  const genre = String(params.genre || '').trim();
  const country = String(params.country || '').trim();
  const director = String(params.director || '').trim();
  const actor = String(params.actor || '').trim();
  const yearFrom = String(params.yearFrom || params.fromYear || params.year_from || '').trim();
  const yearTo = String(params.yearTo || params.toYear || params.year_to || '').trim();
  const exactYear = String(params.exactYear || params.year || params.yearse || '').trim();
  const rating = String(params.rating || params.imdbScore || params.imdbrate || '').trim();
  const sort = String(params.sort || params.sortby || '').trim();
  const language = String(params.language || params.lang || '').trim();
  const dubbed = Boolean(params.dubbed);
  const subtitle = Boolean(params.subtitle);

  // Archive 3 uses the real API6 contract directly, exactly like the site/app source.
  if (a === 3) {
    const cfg = await loadRemoteConfig();
    const domain = String(cfg.active_domain || DEFAULT.domain).replace(/\/$/, '');
    const url = queryUrl(`${domain}/api6.php`, {
      client: 'app', q, s: q, type, genre, country, director, actor,
      year: exactYear, yearse: exactYear, fromYear: yearFrom, toYear: yearTo,
      imdbScore: rating, sort: sort || 'newest', lang: language,
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : '', page
    }).toString();
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 18000);
    const items = raw?.movies || raw?.items || raw?.results || [];
    return {
      ...raw,
      status: raw?.status || 'success',
      archive: 3,
      page: Number(raw?.page || page) || page,
      items,
      results: items,
      total: Number(raw?.total ?? raw?.total_count ?? raw?.count ?? items.length) || items.length,
      total_count: Number(raw?.total_count ?? raw?.total ?? raw?.count ?? items.length) || items.length
    };
  }

  // Archive 1: use the same current API2 search contract as the website.
  // No typing/live dropdown exists in Windows; actor discovery is resolved only
  // when the user submits Search, then actor filmography uses API2 pagination.
  if (a === 1) {
    return archive1SearchRequest({
      q, page, limit, type, genre, country, director, actor, rating, sort,
      yearFrom, yearTo, dubbed, subtitle
    });
  }

  // Archive 2 is the site-owned DB catalogue behind app_api.php.
  if (a === 2) {
    return contentRequest('search', {
      archive: 2, q, page, limit, type: type === 'all' ? '' : type,
      genre, country, year_from: yearFrom, year_to: yearTo,
      rating, sort: sort || 'newest',
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : ''
    });
  }

  // Archive 4 desktop bridge mirrors api4.php/site query names.
  if (a === 4) {
    return contentRequest('search', {
      archive: 4, q, s: q, page, limit, type,
      genre, country, director, actor,
      year: exactYear, yearse: exactYear, fromYear: yearFrom, toYear: yearTo,
      imdbScore: rating, rating, sort: sort || 'newest', lang: language,
      dubbed: dubbed ? 1 : '', subtitle: subtitle ? 1 : ''
    });
  }

  // Archive 5 has no verified advanced-search contract in the Android/site sources.
  // Keep only real basic search instead of pretending unsupported filters worked.
  return contentRequest('search', { archive: a, q, page, limit, type: type === 'all' ? '' : type });
}


/* ===== BankMovie Desktop v1.1.31 — Archive 1 site-synced submitted search + actor pagination ===== */
function archive1ActorSlug(value = '') {
  let raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const u = new URL(raw, 'https://bankmovie.top');
    const m = u.pathname.match(/\/actors\/([^/]+)/i);
    if (m) return decodeURIComponent(m[1]);
  } catch {}
  const m = raw.match(/(?:^|\/)actors\/([^/?#]+)/i);
  if (m) raw = m[1];
  return raw.replace(/^\/+|\/+$/g, '').replace(/^actors\//i, '').trim();
}
function archive1NormalizeActor(row = {}) {
  const title = String(row?.name || row?.title || '').trim();
  const url = String(row?.source_url || row?.url || '').trim();
  const slug = String(row?.slug || archive1ActorSlug(url || title)).trim();
  return {
    archive: 1,
    kind: 'actor',
    entity_type: 'actor',
    is_actor: true,
    id: row?.term_id || row?.id || slug,
    term_id: row?.term_id || row?.id || null,
    slug,
    name: title,
    title,
    image: String(row?.image || row?.poster || row?.thumbnail || '').trim(),
    poster: String(row?.poster || row?.image || row?.thumbnail || '').trim(),
    url,
    meta_data: String(row?.meta_data || 'بازیگر').trim()
  };
}
function archive1HasText(value = '') { return String(value || '').trim() !== ''; }
async function archive1SearchRequest(params = {}) {
  const cfg = await loadRemoteConfig();
  const domain = String(cfg.active_domain || DEFAULT.domain).replace(/\/$/, '');
  const page = Math.max(1, Number(params.page) || 1);
  const limit = Math.max(1, Math.min(60, Number(params.limit) || 36));
  const typedQ = String(params.q || '').trim();
  const actorQ = String(params.actor || '').trim();
  const directorQ = String(params.director || '').trim();
  // Match the website: actor/director becomes the text query only when the main title query is empty.
  const q = typedQ || actorQ || directorQ;
  const rawType = String(params.type || 'all').trim().toLowerCase();
  const type = rawType === 'movie' ? 'movie' : (rawType === 'series' ? 'series' : 'both');

  // Keep the simple request simple, exactly like the current website/API2 fix:
  // ?s=TITLE&type=both. Optional filters are appended only when the user selected them.
  const searchParams = { client: 'app', s: q, type };
  const genre = String(params.genre || '').trim();
  const country = String(params.country || '').trim();
  const sort = String(params.sort || '').trim();
  const rating = String(params.rating || '').trim();
  const yearFrom = String(params.yearFrom || '').trim();
  const yearTo = String(params.yearTo || '').trim();
  if (/^\d+$/.test(genre) && Number(genre) > 0) searchParams.genre = genre;
  if (/^\d+$/.test(country) && Number(country) > 0) searchParams.country = country;
  if (sort && sort !== 'newest') searchParams.sortby = sort;
  if (rating && Number(rating) > 0) searchParams.imdbrate = rating;
  if (yearFrom && Number(yearFrom) > 1800) searchParams.min_year = yearFrom;
  if (yearTo && Number(yearTo) > 0 && Number(yearTo) < new Date().getFullYear()) searchParams.max_year = yearTo;
  if (params.dubbed) searchParams.dubbed = 1;
  if (params.subtitle) searchParams.subtitle = 1;
  if (page > 1) searchParams.page = page;

  const url = queryUrl(`${domain}/api2.php`, searchParams).toString();
  const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 24000);
  const mediaRows = raw?.movies || raw?.items || raw?.results || [];
  const items = (Array.isArray(mediaRows) ? mediaRows : []).slice(0, limit).map(it => ({ ...it, archive: 1 }));

  // There is NO live-search UI in Windows. On submit/page 1 only, ask the website's
  // own API2 quick-search endpoint for actor entities so actor results stay in sync
  // with the website without the desktop talking to the upstream source directly.
  let actors = [];
  const actorLookup = actorQ || typedQ;
  if (page === 1 && actorLookup.length >= 2) {
    try {
      const peopleUrl = queryUrl(`${domain}/api2.php`, { live_search: actorLookup, limit: 20, client: 'app' }).toString();
      const quick = await fetchJson(peopleUrl, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 12000);
      const people = Array.isArray(quick?.people) ? quick.people : (Array.isArray(quick?.results) ? quick.results : []);
      actors = people
        .filter(row => String(row?.entity_type || row?.kind || '').toLowerCase() === 'actor' || /\/actors\//i.test(String(row?.source_url || row?.url || '')))
        .map(archive1NormalizeActor)
        .filter(a => a.name && a.slug)
        .slice(0, 8);
    } catch {}
  }

  const hasMore = raw?.has_more === true || raw?.next_page != null || items.length >= Math.min(20, limit);
  return {
    ...raw,
    status: raw?.status || 'success',
    success: raw?.success !== false,
    archive: 1,
    source: 'api2-site-search',
    query: q,
    page,
    items,
    results: items,
    movies: items,
    actors,
    people: actors,
    count: items.length,
    total: Number(raw?.total ?? raw?.total_count ?? items.length) || items.length,
    total_count: Number(raw?.total_count ?? raw?.total ?? items.length) || items.length,
    has_more: hasMore,
    next_page: raw?.next_page ?? (hasMore ? page + 1 : null)
  };
}
async function archive1ActorRequest(params = {}) {
  const cfg = await loadRemoteConfig();
  const domain = String(cfg.active_domain || DEFAULT.domain).replace(/\/$/, '');
  const page = Math.max(1, Number(params.page) || 1);
  const slug = archive1ActorSlug(params.slug || params.url || params.name || '');
  if (!slug) throw new Error('شناسه بازیگر نامعتبر است');
  try {
    const url = queryUrl(`${domain}/api2.php`, { actor: slug, page, client: 'app' }).toString();
    const raw = await fetchJson(url, { cache: 'no-store', headers: { 'X-BM-Client': 'windows' } }, 24000);
    const items = (raw?.items || raw?.movies || raw?.results || []).map(it => ({ ...it, archive: 1 }));
    const actor = raw?.actor || raw?.person || { name: params.name || slug, slug };
    const current = Number(raw?.page || raw?.current_page || page) || page;
    const totalPages = Number(raw?.total_pages || raw?.pages || raw?.last_page || 0) || 0;
    const total = Number(raw?.total || raw?.total_count || actor?.count || items.length) || items.length;
    const hasMore = raw?.has_more === true || raw?.next_page != null || (totalPages > current);
    return { ...raw, success: raw?.success !== false, archive: 1, actor, items, movies: items, page: current, total, total_count: total, total_pages: totalPages, has_more: hasMore };
  } catch (directError) {
    const fallback = await contentRequest('actor', { archive: 1, slug, name: params.name || '', page });
    const items = (fallback?.items || fallback?.movies || fallback?.results || []).map(it => ({ ...it, archive: 1 }));
    return { ...fallback, archive: 1, items, movies: items, page: Number(fallback?.page || page) || page };
  }
}

async function userRequest(action, body = {}, method = 'POST') {
  const cfg = await loadRemoteConfig();
  const url = queryUrl(cfg.account_api_url || DEFAULT.accountApiUrl, method === 'GET' ? { action, ...body } : {});
  const token = loadToken();
  const headers = {
    'X-BM-Client': 'windows',
    'X-BM-Notification-Protocol': '2',
    'Content-Type': 'application/json'
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
    headers['X-BM-User-Token'] = token;
  }
  const opts = { method, headers, cache: 'no-store' };
  if (method !== 'GET') opts.body = JSON.stringify({ action, ...body });
  const data = await fetchJson(url.toString(), opts);
  if ((action === 'login' || action === 'register') && data?.token) saveToken(data.token);
  if (action === 'logout') saveToken('');
  return data;
}
function safeFileName(name) {
  return String(name || 'BankMovie').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'BankMovie';
}

const PLAYER_DEFS = [
  {
    id: 'potplayer', name: 'PotPlayer', score: 100,
    exes: ['PotPlayerMini64.exe','PotPlayerMini.exe','PotPlayer.exe'],
    paths: [
      ['ProgramFiles','DAUM','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles(x86)','DAUM','PotPlayer','PotPlayerMini.exe'],
      ['ProgramFiles(x86)','PotPlayer','PotPlayerMini.exe']
    ]
  },
  {
    id: 'vlc', name: 'VLC', score: 95,
    exes: ['vlc.exe'],
    paths: [
      ['ProgramFiles','VideoLAN','VLC','vlc.exe'],
      ['ProgramFiles(x86)','VideoLAN','VLC','vlc.exe']
    ]
  },
  {
    id: 'kmplayer', name: 'KMPlayer', score: 80,
    exes: ['KMPlayer64.exe','KMPlayer.exe'],
    paths: [
      ['ProgramFiles','KMPlayer 64X','KMPlayer64.exe'],
      ['ProgramFiles','KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','The KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','KMPlayer','KMPlayer.exe']
    ]
  }
];

function uniqExisting(paths) {
  const seen = new Set();
  return paths.filter(p => {
    if (!p) return false;
    const q = path.resolve(p);
    if (seen.has(q.toLowerCase()) || !fs.existsSync(q)) return false;
    seen.add(q.toLowerCase());
    return true;
  });
}
function appPathFromRegistry(exe) {
  if (process.platform !== 'win32') return '';
  const roots = ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths', 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths'];
  for (const root of roots) {
    try {
      const out = execFileSync('reg.exe', ['query', `${root}\\${exe}`, '/ve'], { encoding:'utf8', windowsHide:true, timeout:1800 });
      const m = out.match(/REG_(?:EXPAND_)?SZ\s+(.+)$/mi);
      if (m && fs.existsSync(m[1].trim())) return m[1].trim();
    } catch {}
  }
  return '';
}
function appPathFromWhere(exe) {
  if (process.platform !== 'win32') return '';
  try {
    const out = execFileSync('where.exe', [exe], { encoding:'utf8', windowsHide:true, timeout:1800 });
    return out.split(/\r?\n/).map(x=>x.trim()).find(x=>x && fs.existsSync(x)) || '';
  } catch { return ''; }
}
function detectPlayers() {
  if (process.platform !== 'win32') return [];
  const found = [];
  for (const def of PLAYER_DEFS) {
    const candidates = [];
    for (const parts of def.paths) {
      const root = process.env[parts[0]];
      if (root) candidates.push(path.join(root, ...parts.slice(1)));
    }
    for (const exe of def.exes) {
      candidates.push(appPathFromRegistry(exe));
      candidates.push(appPathFromWhere(exe));
    }
    const existing = uniqExisting(candidates);
    if (existing.length) {
      const executable = existing.find(x => /64\.exe$/i.test(x)) || existing[0];
      found.push({ id:def.id, name:def.name, path:executable, score:def.score, subtitleSupport:def.id !== 'kmplayer' });
    }
  }
  return found.sort((a,b)=>b.score-a.score);
}
function selectedPlayer(preferred = 'auto') {
  const players = detectPlayers();
  if (!players.length) return null;
  if (preferred && preferred !== 'auto') return players.find(p=>p.id===preferred) || players[0];
  return players[0];
}
async function materializeSubtitle(url) {
  if (!url || !/^https?:\/\//i.test(url)) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { signal:ctrl.signal, redirect:'follow' });
    if (!res.ok) return '';
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > 8 * 1024 * 1024) return '';
    let ext = '.srt';
    try {
      const e = path.extname(new URL(url).pathname).toLowerCase();
      if (['.srt','.vtt','.ass','.ssa','.sub'].includes(e)) ext = e;
    } catch {}
    const dir = path.join(app.getPath('temp'), 'BankMovie', 'subtitles');
    fs.mkdirSync(dir, { recursive:true });
    const file = path.join(dir, `${crypto.createHash('sha1').update(url).digest('hex')}${ext}`);
    fs.writeFileSync(file, buf);
    return file;
  } catch { return ''; }
  finally { clearTimeout(timer); }
}
async function launchExternalPlayer(meta = {}) {
  const url = String(meta.url || '');
  if (!/^https?:\/\//i.test(url)) throw new Error('لینک پخش معتبر نیست');
  const pref = String(meta.preferredPlayer || settings().preferredPlayer || 'auto');
  const player = selectedPlayer(pref);
  if (!player) throw new Error('هیچ‌کدام از VLC، PotPlayer یا KMPlayer روی ویندوز پیدا نشد. یکی از آن‌ها را نصب کن.');
  const subtitlePath = await materializeSubtitle(String(meta.subtitleUrl || ''));
  const args = [];
  if (player.id === 'vlc') {
    args.push(url, '--one-instance');
    if (subtitlePath) args.push(`--sub-file=${subtitlePath}`);
  } else if (player.id === 'potplayer') {
    args.push(url);
    if (subtitlePath) args.push(`/sub=${subtitlePath}`);
  } else {
    args.push(url);
  }
  try {
    const child = spawn(player.path, args, { detached:true, stdio:'ignore', windowsHide:false });
    child.unref();
  } catch (e) {
    throw new Error(`اجرای ${player.name} ناموفق بود: ${e.message}`);
  }
  return { ok:true, player:{ id:player.id, name:player.name, path:player.path }, subtitleApplied:Boolean(subtitlePath && player.subtitleSupport) };
}


async function fetchBoxOffice(){
  const url = `${DEFAULT.domain}/api_boxoffice.php?mode=weekend`;
  return fetchJson(url, { cache:'no-store', headers:{ 'Accept':'application/json', 'X-BM-Client':'windows' } });
}

async function probeMediaContentType(raw){
  if(/\.(mp4|webm|ogg|mov|m4v)(?:$|[?#])/i.test(raw)) return 'video/direct';
  if(/\.(mp3|m4a|aac|wav)(?:$|[?#])/i.test(raw)) return 'audio/direct';
  try{
    const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),5000);
    const res=await fetch(raw,{method:'HEAD',redirect:'follow',signal:ctrl.signal,headers:{'User-Agent':'BankMovieDesktop/1.9.3'}});
    clearTimeout(timer);
    return String(res.headers.get('content-type')||'').toLowerCase();
  }catch{return ''}
}
function mediaPlayerHtml(raw,title){
  const safeUrl=JSON.stringify(String(raw||'')).replace(/</g,'\\u003c');
  const safeTitle=JSON.stringify(String(title||'BankMovie Trailer')).replace(/</g,'\\u003c');
  return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${String(title||'BankMovie Trailer').replace(/[<>&"]/g,'')}</title><style>
  html,body{margin:0;width:100%;height:100%;background:#03060b;color:#fff;font-family:Segoe UI,Tahoma,sans-serif;overflow:hidden}
  .wrap{width:100%;height:100%;display:flex;flex-direction:column;background:radial-gradient(circle at 50% 0,#0d1d33,#03060b 58%)}
  header{height:52px;display:flex;align-items:center;justify-content:space-between;padding:0 18px;border-bottom:1px solid rgba(78,161,255,.18);background:#050911}
  header strong{font-size:14px}header span{font-size:11px;color:#6eb5ff}
  main{flex:1;display:grid;place-items:center;min-height:0;padding:16px}
  video{width:100%;height:100%;max-width:1500px;max-height:calc(100vh - 84px);background:#000;border-radius:14px;box-shadow:0 18px 60px rgba(0,0,0,.55);outline:none}
  </style></head><body><div class="wrap"><header><strong id="ttl"></strong><span>BankMovie Trailer</span></header><main><video id="v" controls autoplay playsinline preload="auto"></video></main></div><script>
  const u=${safeUrl},t=${safeTitle};document.getElementById('ttl').textContent=t;const v=document.getElementById('v');v.src=u;v.play().catch(()=>{});
  </script></body></html>`;
}
async function openWebWindow(url, title='BankMovie'){
  const raw=String(url||'').trim();
  if(!/^https?:\/\//i.test(raw)) throw new Error('لینک وب معتبر نیست');
  const child=new BrowserWindow({
    width:1180,height:760,minWidth:900,minHeight:620,
    parent:win||undefined,modal:false,show:false,
    backgroundColor:'#05070b',title:String(title||'BankMovie'),
    autoHideMenuBar:true,
    webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true}
  });
  childWindows.add(child);
  child.once('closed',()=>childWindows.delete(child));
  child.setMenuBarVisibility(false);
  child.once('ready-to-show',()=>{ if(!child.isDestroyed()) child.show(); });
  const ctype=await probeMediaContentType(raw);
  const direct=/^video\//i.test(ctype)||ctype==='video/direct'||/\.(mp4|webm|ogg|mov|m4v)(?:$|[?#])/i.test(raw);
  if(direct){
    const html=mediaPlayerHtml(raw,title);
    await child.loadURL('data:text/html;charset=utf-8,'+encodeURIComponent(html));
  }else{
    await child.loadURL(raw);
  }
  if(!child.isDestroyed()){child.show();child.focus();}
  return true;
}


function sendToMainWindow(channel, payload) {
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
    try { win.webContents.send(channel, payload); } catch {}
  }
}
function nativeDownloadNotification(title, body) {
  try {
    if (Notification.isSupported()) {
      new Notification({
        title: String(title || 'BankMovie'),
        body: String(body || ''),
        icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
        silent: false
      }).show();
    }
  } catch {}
}


function mergeDownloadState(id, patch = {}) {
  const prev = downloadState.get(id) || {};
  const next = { ...prev, ...patch, id, at: Date.now() };
  downloadState.set(id, next);
  return next;
}
function publishDownloadState(id, patch = {}, preferredWebContents = null) {
  const next = mergeDownloadState(id, patch);
  const targets = [];
  if (preferredWebContents && typeof preferredWebContents.isDestroyed === 'function' && !preferredWebContents.isDestroyed()) targets.push(preferredWebContents);
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed() && !targets.includes(win.webContents)) targets.push(win.webContents);
  for (const target of targets) {
    try { target.send('download:update', next); } catch {}
  }
  if (terminalDownloadState(next.state)) setTimeout(evaluateAfterDownloadsPlan, 0);
  return next;
}
function downloadSnapshot() {
  return [...downloadState.values()].sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0));
}
function clearDownloadMonitor(id) {
  const timer = downloadMonitors.get(id);
  if (timer) clearInterval(timer);
  downloadMonitors.delete(id);
}
function startDownloadMonitor(id, item, sourceWebContents) {
  clearDownloadMonitor(id);
  let lastBytes = item.getReceivedBytes();
  let lastAt = Date.now();
  const timer = setInterval(() => {
    if (!downloadItems.has(id)) { clearDownloadMonitor(id); return; }
    const now = Date.now();
    if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
    const received = item.getReceivedBytes();
    const dt = Math.max(.05, (now-lastAt)/1000);
    const speed = Math.max(0, received-lastBytes)/dt;
    lastBytes = received;
    lastAt = now;
    publishDownloadState(id, {
      state: item.isPaused() ? 'progressing' : 'progressing',
      received,
      total: item.getTotalBytes(),
      paused: forcedPausedDownloads.has(id) || item.isPaused(),
      savePath: item.getSavePath(),
      speed
    }, sourceWebContents);
  }, 500);
  downloadMonitors.set(id, timer);
}

function installDownloadHooks() {
  session.defaultSession.on('will-download', (_event, item, sourceWebContents) => {
    const url = item.getURL();
    const chain = typeof item.getURLChain === 'function' ? item.getURLChain() : [url];

    let id = '';
    for (const u of chain) {
      if (pendingDownloadUrl.has(u)) { id = pendingDownloadUrl.get(u); break; }
    }
    if (!id && pendingDownloadUrl.has(url)) id = pendingDownloadUrl.get(url);
    if (!id) {
      const first = pendingDownloadMeta.keys().next();
      if (!first.done) id = first.value;
    }

    const meta = id ? (pendingDownloadMeta.get(id) || {}) : {};
    if (!id) id = crypto.randomUUID();

    pendingDownloadMeta.delete(id);
    for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) {
      if (mappedId === id) pendingDownloadUrl.delete(u);
    }

    const folder = settings().downloadDir;
    fs.mkdirSync(folder, { recursive: true });
    let ext = '.mp4';
    try { ext = path.extname(new URL(url).pathname) || '.mp4'; } catch {}
    const requestedName = meta.fileName || item.getFilename() || `BankMovie-${id}${ext}`;
    item.setSavePath(path.join(folder, safeFileName(requestedName)));
    downloadItems.set(id, item);

    if (cancelledPendingDownloads.has(id)) {
      cancelledPendingDownloads.delete(id);
      try { item.cancel(); } catch {}
      publishDownloadState(id, { url, ...meta, state:'cancelled', received:0, total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
      downloadItems.delete(id);
      return;
    }

    publishDownloadState(id, { url, ...meta, state:'starting', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
    startDownloadMonitor(id, item, sourceWebContents);

    // Delay the native "started" notification slightly so a request that fails
    // immediately does not show both "started" and an error at the same time.
    const notifyTimer=setTimeout(()=>{
      const st=downloadState.get(id);
      if(st && !['cancelled','interrupted','completed'].includes(st.state)){
        nativeDownloadNotification('دانلود شروع شد', meta.title || meta.fileName || 'BankMovie');
      }
    },700);

    item.on('updated', (_e, state) => {
      if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
      publishDownloadState(id, {
        state,
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:forcedPausedDownloads.has(id) || item.isPaused(),
        savePath:item.getSavePath()
      }, sourceWebContents);
    });

    item.once('done', (_e, state) => {
      clearTimeout(notifyTimer);
      clearDownloadMonitor(id);
      publishDownloadState(id, {
        state,
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:false,
        savePath:item.getSavePath(),
        finishedAt:Date.now()
      }, sourceWebContents);
      downloadItems.delete(id);
      forcedPausedDownloads.delete(id);
      if (state === 'completed') nativeDownloadNotification('دانلود کامل شد', meta.title || item.getFilename() || 'BankMovie');
      else if (state === 'cancelled') nativeDownloadNotification('دانلود لغو شد', meta.title || item.getFilename() || 'BankMovie');
      else nativeDownloadNotification('دانلود متوقف شد', meta.title || item.getFilename() || 'BankMovie');
    });
  });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    frame: false, backgroundColor: '#060708', show: false,
    icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, '../src/index.html'));
  const sendFullscreenState = () => {
    if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
      win.webContents.send('window:fullscreen-state', win.isFullScreen());
    }
  };
  win.on('enter-full-screen', sendFullscreenState);
  win.on('leave-full-screen', sendFullscreenState);
  win.once('ready-to-show', () => { win.show(); sendFullscreenState(); });
}

app.whenReady().then(() => { installDownloadHooks(); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('bootstrap', async () => ({ config: await loadRemoteConfig(true), settings: settings(), players: detectPlayers(), hasToken: Boolean(loadToken()), version: app.getVersion() }));
ipcMain.handle('content:request', (_e, action, params) => contentRequest(action, params));
ipcMain.handle('search:options', (_e, archive) => searchOptionsRequest(archive));
ipcMain.handle('search:advanced', (_e, params) => advancedSearchRequest(params || {}));
ipcMain.handle('archive1:actor', (_e, params) => archive1ActorRequest(params || {}));
ipcMain.handle('user:request', (_e, action, body, method) => userRequest(action, body || {}, method || 'POST'));
ipcMain.handle('auth:clear', () => { saveToken(''); return true; });
ipcMain.handle('settings:get', () => settings());
ipcMain.handle('settings:set', (_e, patch) => { writeState(patch || {}); runtimeConfig = null; return settings(); });
ipcMain.handle('settings:choose-download-dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], defaultPath: settings().downloadDir });
  if (r.canceled || !r.filePaths[0]) return settings().downloadDir;
  writeState({ downloadDir: r.filePaths[0] }); return r.filePaths[0];
});
ipcMain.handle('download:add', (_e, meta) => {
  if (!meta?.url || !/^https?:\/\//i.test(meta.url)) throw new Error('لینک دانلود معتبر نیست');
  const id = crypto.randomUUID();
  powerTrackDownloadId(id);
  const payload = { ...meta, id, queuedAt: Date.now(), state:'queued', received:0, total:0, paused:false };
  pendingDownloadMeta.set(id, payload);
  pendingDownloadUrl.set(meta.url, id);
  publishDownloadState(id, payload);
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) win.webContents.downloadURL(meta.url);
  else session.defaultSession.downloadURL(meta.url);
  return { id, state:downloadState.get(id) };
});
ipcMain.handle('download:list', () => downloadSnapshot());
ipcMain.handle('power:status', (event) => { if(!trustedMainRenderer(event)) throw new Error('پنجره نامعتبر'); return powerPublicStatus(); });
ipcMain.handle('power:schedule', (event, payload) => armPowerPlan(event, payload || {}));
ipcMain.handle('power:cancel', (event) => cancelPowerPlan(event));
ipcMain.handle('download:action', (_e, id, action) => {
  id=String(id||'');
  const item = downloadItems.get(id);
  if (!item) {
    if (action === 'cancel' && pendingDownloadMeta.has(id)) {
      cancelledPendingDownloads.add(id);
      const meta = pendingDownloadMeta.get(id) || {};
      pendingDownloadMeta.delete(id);
      for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) if (mappedId === id) pendingDownloadUrl.delete(u);
      return publishDownloadState(id, { ...meta, state:'cancelled', received:0, total:0, paused:false, finishedAt:Date.now() });
    }
    return downloadState.get(id) || null;
  }
  if (action === 'remove') {
    try { if (item && !item.isDestroyed?.()) item.cancel(); } catch {}
    clearDownloadMonitor(id);
    downloadItems.delete(id);
    forcedPausedDownloads.delete(id);
    pendingDownloadMeta.delete(id);
    for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) if (mappedId === id) pendingDownloadUrl.delete(u);
    downloadState.delete(id);
    return { id, removed:true };
  }
  if (action === 'pause') {
    forcedPausedDownloads.add(id);
    try { item.pause(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:true, savePath:item.getSavePath() });
  }
  if (action === 'resume') {
    forcedPausedDownloads.delete(id);
    try { item.resume(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() });
  }
  if (action === 'cancel') {
    forcedPausedDownloads.delete(id);
    try { item.cancel(); } catch {}
    clearDownloadMonitor(id);
    const snapshot=publishDownloadState(id, { state:'cancelled', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath(), finishedAt:Date.now() });
    downloadItems.delete(id);
    return snapshot;
  }
  return downloadState.get(id) || null;
});
ipcMain.handle('file:open', async (_e, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) return false;
  const err = await shell.openPath(filePath);
  return err === '';
});
ipcMain.handle('player:list', () => detectPlayers());
ipcMain.handle('player:play', (_e, meta) => launchExternalPlayer(meta || {}));
ipcMain.handle('boxoffice:get', () => fetchBoxOffice());
ipcMain.handle('browser:open', (_e, url, title) => openWebWindow(url, title));
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
ipcMain.handle('shell:show-item', (_e, filePath) => { shell.showItemInFolder(filePath); return true; });
ipcMain.on('window:minimize', () => win?.minimize());
ipcMain.on('window:maximize', () => win?.isMaximized() ? win.unmaximize() : win?.maximize());
ipcMain.handle('window:fullscreen', () => {
  if (!win || win.isDestroyed()) return false;
  const next = !win.isFullScreen();
  win.setFullScreen(next);
  return next;
});
ipcMain.on('window:close', () => win?.close());
