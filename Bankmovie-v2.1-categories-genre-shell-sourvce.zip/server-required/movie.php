<?php
require_once __DIR__ . '/security_bootstrap.php';
@include_once __DIR__ . '/_bm_support_widget.php';

// تنظیم سطح گزارش‌دهی (در محیط تولید بهتر است E_ALL & ~E_DEPRECATED & ~E_STRICT باشد)
error_reporting(E_ALL);
ini_set('display_errors', 0);                 // خطاها را در مرورگر نشان نده (امنیت)
ini_set('log_errors', 1);                    // فعال‌سازی لاگ خطا
if (function_exists('bm_security_private_path')) ini_set('error_log', bm_security_private_path('php-errors.log')); // مسیر لاگ خارج از public

// همچنین می‌توانید خطاهای فatal را هم با Shutdown Function ثبت کنید
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        error_log(sprintf(
            "[FATAL] %s in %s on line %d",
            $error['message'],
            $error['file'],
            $error['line']
        ));
    }
});

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'config.php';
require_once __DIR__ . '/archive_control.php';
require_once __DIR__ . '/bm_analytics.php';
$currentUser = $currentUser ?? null;
// مقداردهی اولیه برای جلوگیری از خطاهای undefined variable
$inWatchlist = false;
$userRating  = 0;
$latestNotification = $activeNotification ?? null;

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

if (!function_exists('bm_ext_safe_url')) {
    function bm_ext_safe_url($url): string {
        if (function_exists('bm_security_safe_url')) return bm_security_safe_url($url, ['http','https']);
        $url = trim((string)$url);
        return preg_match('~^https?://~i', $url) ? $url : '';
    }
}


// ====== تشخیص آرشیو ۱ ======
// ====== تعریف اولیه متغیرهای نوتیفیکیشن ======
$notificationsList = [];
$activeNotification = null;
$notificationSeen = false;

try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    $activeNotification = $stmt->fetch(PDO::FETCH_ASSOC);
    if($activeNotification) {
        $cookieName = 'notification_seen_' . $activeNotification['id'];
        if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
    }
} catch (Throwable $e) {
    $notificationsList = [];
    $activeNotification = null;
    $notificationSeen = false;
}
$rawArcSlug = trim((string)($_GET['slug'] ?? ''), "/ \t");
$isArc1   = isset($_GET['arc']) && (int)$_GET['arc'] === 1;
$isArc3   = isset($_GET['arc']) && (int)$_GET['arc'] === 3;
$isArc4   = isset($_GET['arc']) && (int)$_GET['arc'] === 4;

// پشتیبانی از URLهای تمیز مثل /movie/arc1-slug و /movie/arc3-tt123 و /movie/arc4-tt123
if (!$isArc1 && !$isArc3 && !$isArc4 && strpos($rawArcSlug, 'arc1-') === 0) {
    $isArc1 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc1 && !$isArc3 && !$isArc4 && strpos($rawArcSlug, 'arc3-') === 0) {
    $isArc3 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc1 && !$isArc3 && !$isArc4 && strpos($rawArcSlug, 'arc4-') === 0) {
    $isArc4 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}

$bmCurrentArchiveId = $isArc4 ? 'archive4' : ($isArc3 ? 'archive3' : ($isArc1 ? 'archive1' : 'archive2'));
$bmArchiveBlocked = in_array($bmCurrentArchiveId, ['archive1','archive3','archive4'], true) && !bm_archive_is_enabled($bmCurrentArchiveId);
$bmArchiveBlockedMessage = $bmArchiveBlocked ? bm_archive_disabled_message($bmCurrentArchiveId) : '';

$arcSourceLabel = $isArc4 ? 'آرشیو ۴' : ($isArc3 ? 'آرشیو ۳' : 'آرشیو ۱');
$arcSourceToastLabel = $arcSourceLabel;

// برچسب نوع نسخه برای هر آرشیو؛ فقط برای عنوان بخش‌ها/بج‌ها استفاده می‌شود، نه تنظیمات پلیر.
$bmArchiveSubFa = $isArc4 ? 'بدون زیرنویس' : ($isArc3 ? 'سافت ساب' : ($isArc1 ? 'هاردساب' : 'سافت ساب'));
$bmArchiveSubEn = $isArc4 ? 'No Subtitles' : ($isArc3 ? 'Soft Sub' : ($isArc1 ? 'Hard Sub' : 'Soft Sub'));
$arc1Slug = $rawArcSlug;
$arc1Type = in_array($_GET['type']??'', ['series','movie','anime'], true) ? $_GET['type'] : null;

// برای سازگاری با قالب قبلی، آرشیوهای خارجی ۳ و ۴ از همان مسیر رندر آرشیو ۱ استفاده می‌کنند.
if ($isArc3 || $isArc4) {
    $isArc1 = true;
}

// ID مجازی برای کامنت‌های آرشیو خارجی
// نکته مهم: بعضی دیتابیس‌ها ستون comments.movie_id را UNSIGNED دارند؛ بنابراین ID منفی باعث خطای 500 می‌شود.
// این بازه عمداً خیلی بالاست تا با ID فیلم‌های آرشیو ۲ تداخل نداشته باشد.
$arcCrcKey = ($isArc4 ? 'arc4:' : ($isArc3 ? 'arc3:' : 'arc1:')) . $arc1Slug;
$arc1VirtualMovieId = $arc1Slug !== '' ? (1000000000 + (abs(crc32($arcCrcKey)) % 1000000000)) : 0;

if (!function_exists('bm_ensure_archive1_comment_tables')) {
    function bm_ensure_archive1_comment_tables(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            movie_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NULL,
            username VARCHAR(100) NOT NULL DEFAULT '',
            comment TEXT NOT NULL,
            rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
            spoiler TINYINT(1) NOT NULL DEFAULT 0,
            parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_movie_parent_status (movie_id, parent_id, status),
            KEY idx_user_status (user_id, status),
            KEY idx_parent (parent_id),
            KEY idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            comment_id BIGINT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NOT NULL,
            type VARCHAR(10) NOT NULL DEFAULT 'like',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_comment_user (comment_id, user_id),
            KEY idx_comment_type (comment_id, type),
            KEY idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}


// ====== BankMovie safe trailer extraction for Archive 1/3 ======
// UI/feature only: uses existing arc1 player handler; does not change player source/loading logic.
if (!function_exists('bm_movie_abs_url')) {
    function bm_movie_abs_url($url, $base) {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '') return '';
        if (preg_match('~^https?://~i', $url)) return $url;
        if (strpos($url, '//') === 0) return 'https:' . $url;
        $p = @parse_url($base);
        if (!$p || empty($p['scheme']) || empty($p['host'])) return $url;
        $root = $p['scheme'] . '://' . $p['host'];
        if (strpos($url, '/') === 0) return $root . $url;
        $dir = isset($p['path']) ? preg_replace('~/[^/]*$~', '/', $p['path']) : '/';
        return $root . $dir . $url;
    }
}
if (!function_exists('bm_movie_http_get')) {
    function bm_movie_http_get($url) {
        $url = trim((string)$url);
        if ($url === '' || !preg_match('~^https?://~i', $url)) return '';
        try {
            if (function_exists('curl_init')) {
                $ch = curl_init($url);
                curl_setopt_array($ch, [
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 4,
                    CURLOPT_CONNECTTIMEOUT => 5,
                    CURLOPT_TIMEOUT => 9,
                    CURLOPT_SSL_VERIFYPEER => true,
                    CURLOPT_SSL_VERIFYHOST => 2,
                    CURLOPT_ENCODING => '',
                    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 BankMovie/1.0',
                    CURLOPT_HTTPHEADER => ['Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8']
                ]);
                $body = curl_exec($ch);
                $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
                curl_close($ch);
                return ($code >= 200 && $code < 400 && is_string($body)) ? $body : '';
            }
            $ctx = stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'timeout' => 9,
                    'ignore_errors' => true,
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) BankMovie/1.0\r\nAccept: text/html,*/*\r\n"
                ],
                'ssl' => ['verify_peer' => false, 'verify_peer_name' => false]
            ]);
            $body = @file_get_contents($url, false, $ctx);
            return is_string($body) ? $body : '';
        } catch (Throwable $e) {
            return '';
        }
    }
}
if (!function_exists('bm_movie_extract_video_src')) {
    function bm_movie_extract_video_src($html, $baseUrl = '') {
        $html = (string)$html;
        if ($html === '') return '';

        $candidates = [];

        if (preg_match_all('~<video\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~<source\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~(?:file|src|source|url)\s*[:=]\s*["\']([^"\']+\.(?:mp4|mkv|m3u8)(?:\?[^"\']*)?)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~https?://[^\s"\'<>]+?\.(?:mp4|mkv|m3u8)(?:\?[^\s"\'<>]+)?~iu', $html, $m)) {
            foreach ($m[0] as $u) $candidates[] = $u;
        }

        foreach ($candidates as $u) {
            $u = html_entity_decode(trim((string)$u), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($u === '') continue;
            if (!preg_match('~\.(mp4|mkv|m3u8)(?:\?|$)~i', $u)) continue;
            return bm_movie_abs_url($u, $baseUrl);
        }
        return '';
    }
}
if (!function_exists('bm_movie_find_trailer_url')) {
    function bm_movie_find_trailer_url($detailUrl) {
        $detailUrl = trim((string)$detailUrl);
        if ($detailUrl === '') return '';

        $html = bm_movie_http_get($detailUrl);
        if ($html === '') return '';

        // Oldtowns / آرشیو ۱ often keeps the trailer directly inside #trailerModal.
        if (preg_match('~id=["\']trailerModal["\'][\s\S]{0,6000}?<video\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            $u = bm_movie_abs_url($m[1], $detailUrl);
            if (preg_match('~\.(mp4|mkv|m3u8)(?:\?|$)~i', $u)) return $u;
        }

        $direct = bm_movie_extract_video_src($html, $detailUrl);
        if ($direct !== '') return $direct;

        // PunkMovie usually exposes a playonline URL with trailer=1; fetch that page and extract its direct video source.
        $trailerPages = [];
        if (preg_match_all('~href=["\']([^"\']*(?:trailer=1|تریلر|trailer)[^"\']*)["\']~iu', $html, $m)) {
            foreach ($m[1] as $href) {
                $u = bm_movie_abs_url($href, $detailUrl);
                if ($u !== '' && !in_array($u, $trailerPages, true)) $trailerPages[] = $u;
            }
        }

        foreach ($trailerPages as $pageUrl) {
            $pageHtml = bm_movie_http_get($pageUrl);
            $src = bm_movie_extract_video_src($pageHtml, $pageUrl);
            if ($src !== '') return $src;
        }

        return '';
    }
}

// ====== BankMovie safe related movies extraction for Archive 1 / آرشیو ۱ ======
if (!function_exists('bm_arc1_clean_text')) {
    function bm_arc1_clean_text($text) {
        $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('~<[^>]+>~u', ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim($text);
    }
}
if (!function_exists('bm_arc1_detail_from_url')) {
    function bm_arc1_detail_from_url($href) {
        $href = html_entity_decode(trim((string)$href), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $path = trim((string)(parse_url($href, PHP_URL_PATH) ?? ''), '/');
        $parts = $path !== '' ? explode('/', $path) : [];
        $type = 'movie';
        $slug = '';
        $pos = array_search('series', $parts, true);
        if ($pos !== false && !empty($parts[$pos + 1])) {
            $type = 'series';
            $slug = 'series__' . $parts[$pos + 1];
        } elseif (count($parts) >= 2 && preg_match('/^\d+$/', $parts[0])) {
            $type = 'movie';
            $slug = $parts[0] . '__' . $parts[1];
        } elseif (!empty($parts)) {
            $last = end($parts);
            $type = (strpos($href, '/series/') !== false) ? 'series' : 'movie';
            $slug = ($type === 'series' ? 'series__' : '') . $last;
        }
        return ['slug' => $slug, 'type' => $type];
    }
}
if (!function_exists('bm_arc1_extract_img_from_article')) {
    function bm_arc1_extract_img_from_article($article, $baseUrl) {
        $img = '';
        if (preg_match('~<img\b[^>]*(?:data-splide-lazy|data-src|data-lazy-src)=["\']([^"\']+)["\']~iu', $article, $m)) {
            $img = $m[1];
        } elseif (preg_match('~<img\b[^>]*src=["\']([^"\']+)["\']~iu', $article, $m)) {
            $img = $m[1];
        }
        $img = html_entity_decode(trim($img), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($img === '' || strpos($img, 'data:image') === 0) return '';
        return bm_movie_abs_url($img, $baseUrl);
    }
}
if (!function_exists('bm_arc1_fetch_related_movies')) {
    function bm_arc1_fetch_related_movies($sourceUrl, $currentSlug = '', $limit = 12) {
        $sourceUrl = trim((string)$sourceUrl);
        if ($sourceUrl === '' || !preg_match('~^https?://~i', $sourceUrl)) return [];
        $html = bm_movie_http_get($sourceUrl);
        if ($html === '') return [];

        $relatedChunk = '';
        if (preg_match('~<section\b[^>]*id=["\']related-posts["\'][\s\S]{0,90000}</section>~iu', $html, $m)) {
            $relatedChunk = $m[0];
        } elseif (preg_match('~id=["\']related-posts["\'][\s\S]{0,90000}~iu', $html, $m)) {
            $relatedChunk = $m[0];
        }
        if ($relatedChunk === '') return [];

        $items = [];
        $seen = [];
        if (preg_match_all('~<article\b[^>]*class=["\'][^"\']*\bentry\b[^"\']*["\'][\s\S]*?</article>~iu', $relatedChunk, $cards)) {
            foreach ($cards[0] as $article) {
                if (count($items) >= $limit) break;

                $href = '';
                if (preg_match('~<a\b[^>]*href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*stretched-link[^"\']*["\']~iu', $article, $m) ||
                    preg_match('~<a\b[^>]*class=["\'][^"\']*stretched-link[^"\']*["\'][^>]*href=["\']([^"\']+)["\']~iu', $article, $m) ||
                    preg_match('~<a\b[^>]*href=["\']([^"\']+)["\']~iu', $article, $m)) {
                    $href = bm_movie_abs_url($m[1], $sourceUrl);
                }
                if ($href === '') continue;

                $detail = bm_arc1_detail_from_url($href);
                if (empty($detail['slug']) || $detail['slug'] === $currentSlug) continue;
                if (isset($seen[$detail['slug']])) continue;
                $seen[$detail['slug']] = true;

                $title = '';
                if (preg_match('~<h2\b[^>]*class=["\'][^"\']*\bentry-title\b[^"\']*["\'][^>]*>([\s\S]*?)</h2>~iu', $article, $m)) {
                    $title = bm_arc1_clean_text($m[1]);
                }
                if ($title === '' && preg_match('~title=["\']([^"\']+)["\']~iu', $article, $m)) $title = bm_arc1_clean_text($m[1]);
                if ($title === '') continue;

                $poster = bm_arc1_extract_img_from_article($article, $sourceUrl);
                $rating = '';
                if (preg_match('/(\d+(?:\.\d+)?)\s*\/\s*10/u', bm_arc1_clean_text($article), $m)) $rating = $m[1];
                $year = '';
                if (preg_match('/\b(19|20)\d{2}\b/u', bm_arc1_clean_text($article), $m)) $year = $m[0];
                $note = '';
                if (preg_match('~<p\b[^>]*class=["\'][^"\']*text-muted[^"\']*["\'][^>]*>([\s\S]*?)</p>~iu', $article, $m)) $note = bm_arc1_clean_text($m[1]);

                $items[] = [
                    'title' => $title,
                    'poster' => $poster,
                    'rating' => $rating,
                    'year' => $year,
                    'note' => $note,
                    'type' => $detail['type'],
                    'slug' => $detail['slug'],
                    'url' => 'movie.php?arc=1&slug=' . rawurlencode($detail['slug']) . '&type=' . rawurlencode($detail['type'])
                ];
            }
        }
        return $items;
    }
}





/* V11 hotfix: helpers used during Archive 1 data parsing must exist before $arc1Data processing */
if (!function_exists('bm_actor_placeholder_svg')) {
    function bm_actor_placeholder_svg($name = '') {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 220 220">
            <defs>
                <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#111827"/>
                    <stop offset=".52" stop-color="#171a28"/>
                    <stop offset="1" stop-color="#05070b"/>
                </linearGradient>
                <radialGradient id="glowA" cx=".30" cy=".18" r=".8">
                    <stop offset="0" stop-color="#36ff9f" stop-opacity=".42"/>
                    <stop offset=".56" stop-color="#36ff9f" stop-opacity=".08"/>
                    <stop offset="1" stop-color="#36ff9f" stop-opacity="0"/>
                </radialGradient>
                <radialGradient id="glowB" cx=".85" cy=".12" r=".9">
                    <stop offset="0" stop-color="#7b2cff" stop-opacity=".34"/>
                    <stop offset=".54" stop-color="#7b2cff" stop-opacity=".08"/>
                    <stop offset="1" stop-color="#7b2cff" stop-opacity="0"/>
                </radialGradient>
                <linearGradient id="strokeG" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#36ff9f"/>
                    <stop offset="1" stop-color="#8b5cf6"/>
                </linearGradient>
                <filter id="soft"><feGaussianBlur stdDeviation="13"/></filter>
            </defs>
            <rect width="220" height="220" rx="48" fill="url(#bg)"/>
            <rect width="220" height="220" rx="48" fill="url(#glowA)"/>
            <rect width="220" height="220" rx="48" fill="url(#glowB)"/>
            <circle cx="48" cy="42" r="42" fill="#36ff9f" opacity=".14" filter="url(#soft)"/>
            <circle cx="178" cy="42" r="50" fill="#8b5cf6" opacity=".16" filter="url(#soft)"/>
            <circle cx="110" cy="103" r="61" fill="#0b0f17" opacity=".96" stroke="url(#strokeG)" stroke-width="3"/>
            <circle cx="110" cy="82" r="29" fill="#f8fafc" opacity=".88"/>
            <path d="M58 165c9-34 29-52 52-52s43 18 52 52" fill="#f8fafc" opacity=".82"/>
            <path d="M72 164c8-20 22-31 38-31s30 11 38 31" fill="#dbeafe" opacity=".18"/>
            <path d="M63 184h94" stroke="#ffffff" stroke-opacity=".12" stroke-width="3" stroke-linecap="round"/>
            <path d="M78 191h64" stroke="#36ff9f" stroke-opacity=".18" stroke-width="2" stroke-linecap="round"/>
        </svg>';
        return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
    }
}

if (!function_exists('bm_actor_slug_from_url')) {
    function bm_actor_slug_from_url($url) {
        $url = trim((string)$url);
        if ($url === '') return '';
        $path = trim((string)(parse_url($url, PHP_URL_PATH) ?? ''), '/');
        if ($path === '') return '';
        $parts = explode('/', $path);
        $pos = array_search('actors', $parts, true);
        if ($pos !== false && !empty($parts[$pos + 1])) return trim((string)$parts[$pos + 1]);
        return trim((string)end($parts));
    }
}


if (!function_exists('bm_actor_is_bad_placeholder_image')) {
    function bm_actor_is_bad_placeholder_image($url) {
        $u = strtolower(html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($u === '') return true;

        // Source placeholders are often inline SVGs or generic profile/avatar images.
        if (strpos($u, 'data:image/svg') === 0) return true;
        if (strpos($u, '<svg') !== false || strpos($u, '%3csvg') !== false) return true;

        $badNeedles = [
            'placeholder', 'no-image', 'no_image', 'no-photo', 'no_photo',
            'default-user', 'default_avatar', 'default-avatar',
            'user-profile', 'profile-user', 'profile.png', 'avatar.png',
            'person-placeholder', 'unknown-person', 'empty-profile',
            'profile-placeholder'
        ];
        foreach ($badNeedles as $needle) {
            if (strpos($u, $needle) !== false) return true;
        }

        return false;
    }
}

if (!function_exists('bm_normalize_arc1_actors')) {
    function bm_normalize_arc1_actors($actorsRaw) {
        $actors = [];
        if (is_string($actorsRaw)) {
            $parts = preg_split('/\s*,\s*/u', $actorsRaw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p !== '') $actors[] = ['name' => $p, 'role' => '', 'image' => '', 'url' => '', 'bankmovie_url' => ''];
            }
            return $actors;
        }
        if (!is_array($actorsRaw)) return [];
        $seen = [];
        foreach ($actorsRaw as $a) {
            if (is_string($a)) {
                $name = trim($a);
                $role = $image = $url = $bankUrl = '';
            } elseif (is_array($a)) {
                $name = trim((string)($a['name'] ?? $a['title'] ?? ''));
                $role = trim((string)($a['role'] ?? $a['character'] ?? ''));
                $image = trim((string)($a['image'] ?? $a['photo'] ?? $a['poster'] ?? ''));
                $url = trim((string)($a['url'] ?? $a['source_url'] ?? ''));
                $bankUrl = trim((string)($a['bankmovie_url'] ?? ''));
                if ($bankUrl === '' && !empty($a['slug'])) {
                    $bankUrl = 'actors.php?slug=' . rawurlencode((string)$a['slug']);
                } elseif ($bankUrl === '' && $url !== '') {
                    $slugFromUrl = bm_actor_slug_from_url($url);
                    if ($slugFromUrl !== '') $bankUrl = 'actors.php?slug=' . rawurlencode($slugFromUrl);
                }
            } else {
                continue;
            }
            if ($name === '') continue;
            if (function_exists('bm_actor_is_bad_placeholder_image') && bm_actor_is_bad_placeholder_image($image)) $image = '';
            $key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $actors[] = ['name' => $name, 'role' => $role, 'image' => $image, 'url' => $url, 'bankmovie_url' => $bankUrl];
        }
        return $actors;
    }
}


// اگر آرشیو ۱ است، داده را از api2_lib بگیر
$arc1Data  = null;
$arc1Error = null;
$arc1RelatedMovies = [];
if ($isArc1 && $arc1Slug !== '' && !$bmArchiveBlocked) {
    // فقط lib رو include کن (بدون JSON header/output)
    try {
        if ($isArc4) {
            if (!function_exists('kargadan_get_details')) {
                require_once __DIR__ . '/api4_lib.php';
            }
            $arc1Data = kargadan_get_details($arc1Slug, $arc1Type);
        } elseif ($isArc3) {
            if (!function_exists('punk_get_details')) {
                require_once __DIR__ . '/api3_lib.php';
            }
            $arc1Data = punk_get_details($arc1Slug);
        } else {
            if (!function_exists('getMovieDetails')) {
                require_once __DIR__ . '/api2_lib.php';
            }
            $arc1Data = getMovieDetails($arc1Slug, $arc1Type);
        }
    } catch (Throwable $ex) {
        $arc1Error = $ex->getMessage();
    }
    if (!$arc1Data && !$arc1Error) $arc1Error = 'اطلاعات دریافت نشد';

    if ($arc1Data) {
        $arc1Title        = $arc1Data['title_fa'] ?? ($arc1Data['title'] ?? '');
        if (trim((string)$arc1Title) === '') $arc1Title = $arc1Data['title'] ?? '';
        $arc1Year         = $arc1Data['year'] ?? '';
        $arc1PosterRaw    = $arc1Data['poster'] ?? null;
        $arc1Poster       = is_array($arc1PosterRaw) ? ($arc1PosterRaw['full'] ?? ($arc1PosterRaw['medium'] ?? null)) : $arc1PosterRaw;
        $arc1Poster       = bm_ext_safe_url($arc1Poster);
        // V39: archive 1 background intentionally uses the poster again.
        // The separate backdrop/cover extracted from the source page looked inconsistent in this layout.
        $arc1Backdrop     = '';
        $arc1HeroBg       = $arc1Poster;
        $arc1Desc         = $arc1Data['description'] ?? ($arc1Data['long_description'] ?? '');
        $arc1RatingRaw    = $arc1Data['rating'] ?? null;
        $arc1ImdbRate     = is_array($arc1RatingRaw) ? ($arc1RatingRaw['imdb'] ?? null) : $arc1RatingRaw;
        $arc1Satisfaction = is_array($arc1RatingRaw) ? ($arc1RatingRaw['feedback_satisfaction'] ?? null) : null;
        $arc1AgeRate      = trim((string)($arc1Data['age_rate'] ?? ($arc1Data['rated'] ?? '')));
        $arc1HasDub       = $arc1Data['has_dubbed'] ?? false;
        $arc1HasSub       = $arc1Data['has_subtitle'] ?? false;
        $arc1IsSeries     = ($arc1Data['type'] ?? 'movie') === 'series';
        $arc1Genres       = $arc1Data['genres'] ?? [];
        $arc1Countries    = $arc1Data['countries'] ?? ($arc1Data['country'] ?? []);
        $arc1Runtime      = trim((string)($arc1Data['runtime'] ?? ($arc1Data['duration'] ?? '')));
        $arc1ReleaseDate  = trim((string)($arc1Data['release_date'] ?? ''));
        $arc1PublishDate  = trim((string)($arc1Data['published_date'] ?? ($arc1Data['publish_date'] ?? '')));
        $arc1StatusText   = trim((string)($arc1Data['status'] ?? ''));
        $arc1LanguageText = trim((string)($arc1Data['language'] ?? ''));
        if ($arc1LanguageText === '' && !empty($arc1Data['languages']) && is_array($arc1Data['languages'])) $arc1LanguageText = implode('، ', $arc1Data['languages']);
        $arc1Network      = trim((string)($arc1Data['network'] ?? ''));
        $arc1NextEpisode  = trim((string)($arc1Data['next_episode'] ?? ''));
        $arc1EpisodeNote  = trim((string)($arc1Data['episode_note'] ?? ''));
        $arc1Actors       = bm_normalize_arc1_actors($arc1Data['actors'] ?? ($arc1Data['cast'] ?? ($arc1Data['actors_text'] ?? [])));
        $arc1SourceUrl    = $arc1Data['source_url'] ?? ($arc1Data['url'] ?? ($isArc4 ? ('https://kargadanmovie.com/'.($arc1IsSeries?'series/':'movies/').$arc1Slug.'/') : ('https://www.oldtowns.top/'.($arc1IsSeries?'series/':'').$arc1Slug.'/')));
        $arc1SourceUrl    = bm_ext_safe_url($arc1SourceUrl);
        $arc1Downloads    = $arc1Data['downloads'] ?? [];
        $arc1TrailerUrl   = (!$isArc3) ? bm_ext_safe_url(trim((string)($arc1Data['trailer_url'] ?? $arc1Data['trailer'] ?? ''))) : '';
        if (!$isArc3 && $arc1TrailerUrl === '' && !empty($arc1SourceUrl)) {
            $arc1TrailerUrl = bm_movie_find_trailer_url($arc1SourceUrl);
        }
        if (!$isArc3) {
            if (!empty($arc1Data['related_movies']) && is_array($arc1Data['related_movies'])) {
                $arc1RelatedMovies = $arc1Data['related_movies'];
            } elseif (!empty($arc1Data['related']) && is_array($arc1Data['related'])) {
                $arc1RelatedMovies = $arc1Data['related'];
            } elseif (!empty($arc1SourceUrl)) {
                // Fallback only; main source is now api2_lib.php.
                $arc1RelatedMovies = bm_arc1_fetch_related_movies($arc1SourceUrl, $arc1Slug, 12);
            }
        }

        // پردازش دانلودها؛ برای آرشیو ۳ فقط لینک‌های مستقیم ویدیو/استریم وارد پلیر داخلی می‌شوند.
        $arc1MovieDub  = [];
        $arc1MovieSoft = [];
        $arc1SeriesSeasons = [];
        $seenArcLinks = [];
        $arc1HasDubAudio = !empty($arc1Data['has_dubbed_audio']);
        if (!empty($arc1Downloads)) {
            // Real download links are authoritative. Do not trust only poster/source badges.
            $arc1HasDub = false;
            $arc1HasSub = false;
            $arc1HasDubAudio = false;
        }
        foreach ($arc1Downloads as $dl) {
            $q    = trim((string)($dl['quality'] ?? ''));
            if ($q === '') $q = 'نامشخص';
            $u    = trim((string)($dl['url'] ?? ''));
            if (!$u) continue;
            $mediaType = strtolower((string)($dl['media_type'] ?? ''));
            $isAudioOnly = !empty($dl['audio_only']) || $mediaType === 'audio' || preg_match('~\.(mka|mp3|m4a|aac|ogg|wav|flac)(?:[?#]|$)~i', $u);
            if (($isArc3 || $isArc4) && !preg_match('~\.(mkv|mp4|avi|m3u8)(?:[?#]|$)~i', $u)) continue;
            if (isset($seenArcLinks[$u])) continue;
            $seenArcLinks[$u] = true;

            if ($isArc3 || $isArc4) {
                $typeText = strtolower((string)($dl['label'] ?? '') . ' ' . $u . ' ' . (string)($dl['type'] ?? ''));
                $type = (strpos($typeText, 'dub') !== false || strpos($typeText, 'dubbed') !== false || strpos($typeText, 'دوبله') !== false) ? 'dub' : 'soft';
            } else {
                $type = ($dl['type'] ?? '') === 'dubbed' ? 'dub' : 'soft';
            }
            if ($type === 'dub') {
                if ($isAudioOnly) $arc1HasDubAudio = true;
                else $arc1HasDub = true;
            } else {
                if (!$isAudioOnly) $arc1HasSub = true;
            }

            if ($arc1IsSeries) {
                $s  = isset($dl['season']) && $dl['season'] !== null ? (int)$dl['season'] : 1;
                $ep = isset($dl['episode']) && $dl['episode'] !== null ? (int)$dl['episode'] : 0;
                $sk = 'S'.str_pad($s,2,'0',STR_PAD_LEFT);
                $ek = $ep > 0 ? ('E'.str_pad($ep,2,'0',STR_PAD_LEFT)) : 'full';
                $arc1SeriesSeasons[$sk][$ek][] = ['quality'=>$q,'type'=>$type,'url'=>$u,'size'=>$dl['size']??'','is_audio'=>$isAudioOnly,'media_type'=>$mediaType,'subtitle_url'=>bm_ext_safe_url($dl['subtitle_url'] ?? '')];
            } else {
                $arc1Item = ['quality'=>$q,'url'=>$u,'size'=>$dl['size']??'','is_audio'=>$isAudioOnly,'media_type'=>$mediaType,'subtitle_url'=>bm_ext_safe_url($dl['subtitle_url'] ?? '')];
                if ($type==='dub') $arc1MovieDub[$q][]  = $arc1Item;
                else               $arc1MovieSoft[$q][] = $arc1Item;
            }
        }
        ksort($arc1SeriesSeasons, SORT_NATURAL);
        foreach ($arc1SeriesSeasons as &$_eps) {
            ksort($_eps, SORT_NATURAL);
            foreach ($_eps as &$_links) {
                usort($_links, function($a, $b) {
                    $ta = (($a['type'] ?? '') === 'dub') ? 1 : 0;
                    $tb = (($b['type'] ?? '') === 'dub') ? 1 : 0;
                    if ($ta !== $tb) return $ta - $tb; // اول زیرنویس، بعد دوبله
                    return getQualityOrder($b['quality'] ?? '') - getQualityOrder($a['quality'] ?? '');
                });
            }
            unset($_links);
        }
        unset($_eps);

        // ثبت نگاشت آرشیو ۱ برای نمایش درست کامنت‌ها در پروفایل و جلوگیری از عنوان نامعلوم
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_items (
                virtual_movie_id INT UNSIGNED NOT NULL PRIMARY KEY,
                archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
                slug VARCHAR(220) NOT NULL DEFAULT '',
                item_link VARCHAR(500) NOT NULL DEFAULT '',
                item_title VARCHAR(300) NOT NULL DEFAULT '',
                item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
                item_year VARCHAR(10) DEFAULT NULL,
                item_poster VARCHAR(500) DEFAULT NULL,
                item_type VARCHAR(20) DEFAULT 'movie',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_slug (slug)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            try {
                $cols = $pdo->query("SHOW COLUMNS FROM archive1_items")->fetchAll(PDO::FETCH_COLUMN);
                if (!in_array('archive_no', $cols ?: [], true)) {
                    $pdo->exec("ALTER TABLE archive1_items ADD COLUMN archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER virtual_movie_id");
                }
            } catch (Throwable $e) {}
            $mapStmt = $pdo->prepare("INSERT INTO archive1_items
                (virtual_movie_id, archive_no, slug, item_link, item_title, item_title_fa, item_year, item_poster, item_type)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE
                    archive_no = VALUES(archive_no),
                    slug = VALUES(slug),
                    item_link = VALUES(item_link),
                    item_title = VALUES(item_title),
                    item_title_fa = VALUES(item_title_fa),
                    item_year = VALUES(item_year),
                    item_poster = VALUES(item_poster),
                    item_type = VALUES(item_type)");
            $mapStmt->execute([
                $arc1VirtualMovieId,
                ($isArc4 ? 4 : ($isArc3 ? 3 : 1)),
                $arc1Slug,
                $arc1SourceUrl,
                $arc1Title,
                $arc1Title,
                $arc1Year,
                $arc1Poster,
                $arc1IsSeries ? 'series' : 'movie'
            ]);
        } catch (Throwable $e) {
            error_log('Archive1 item map error: ' . $e->getMessage());
        }

        // واچ‌لیست آرشیو ۱
        $inArc1Watch = false; $arc1WatchId = null;
        if ($currentUser) {
            try {
                $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
                    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                    user_id INT UNSIGNED NOT NULL,
                    item_link VARCHAR(500) NOT NULL,
                    item_title VARCHAR(300) NOT NULL DEFAULT '',
                    item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
                    item_year VARCHAR(10) DEFAULT NULL,
                    item_poster VARCHAR(500) DEFAULT NULL,
                    item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
                    item_type VARCHAR(20) DEFAULT 'movie',
                    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE KEY uq_user_link (user_id, item_link(200)),
                    KEY idx_user (user_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
                $st = $pdo->prepare("SELECT id FROM archive1_watchlist WHERE user_id=? AND item_link=? LIMIT 1");
                $st->execute([(int)$currentUser['id'], $arc1SourceUrl]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                if ($row) { $inArc1Watch = true; $arc1WatchId = (int)$row['id']; }
            } catch (Throwable $e) {}
        }
    }
}



$userTheme = $_COOKIE['user_theme'] ?? ($currentUser['theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
$userTheme = array_key_exists($userTheme, $themes) ? $userTheme : 'dark-green';
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';
$currentTheme = $themes[$userTheme];
$currentThemeInfo = $currentTheme;
$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

if (!function_exists('e')) {
    function e($str) { return htmlspecialchars((string)($str ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('js_json')) {
    function js_json($value) {
        return json_encode(
            $value,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
        );
    }
}


if (!function_exists('bm_actor_placeholder_svg')) {
    function bm_actor_placeholder_svg($name = '') {
        $name = trim((string)$name);
        $letter = '?';
        if ($name !== '') {
            if (function_exists('mb_substr')) {
                $letter = mb_substr($name, 0, 1, 'UTF-8');
            } else {
                $letter = strtoupper(substr($name, 0, 1));
            }
        }
        $letter = htmlspecialchars($letter, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180">
            <defs>
                <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#36ff9f"/>
                    <stop offset=".55" stop-color="#7b2cff"/>
                    <stop offset="1" stop-color="#111827"/>
                </linearGradient>
                <radialGradient id="r" cx=".35" cy=".22" r=".85">
                    <stop offset="0" stop-color="#ffffff" stop-opacity=".38"/>
                    <stop offset=".55" stop-color="#ffffff" stop-opacity=".06"/>
                    <stop offset="1" stop-color="#000000" stop-opacity=".20"/>
                </radialGradient>
            </defs>
            <rect width="180" height="180" rx="38" fill="url(#g)"/>
            <rect width="180" height="180" rx="38" fill="url(#r)"/>
            <circle cx="90" cy="70" r="31" fill="#ffffff" opacity=".82"/>
            <path d="M39 151c8-31 28-48 51-48s43 17 51 48" fill="#ffffff" opacity=".74"/>
            <text x="90" y="101" text-anchor="middle" dominant-baseline="middle" font-family="Arial,Tahoma,sans-serif" font-size="58" font-weight="900" fill="#07110d" opacity=".78">'.$letter.'</text>
        </svg>';
        return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
    }
}

if (!function_exists('bm_normalize_arc1_actors')) {
    function bm_normalize_arc1_actors($actorsRaw) {
        $actors = [];
        if (is_string($actorsRaw)) {
            $parts = preg_split('/\s*,\s*/u', $actorsRaw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p !== '') $actors[] = ['name' => $p, 'role' => '', 'image' => '', 'url' => '', 'bankmovie_url' => ''];
            }
            return $actors;
        }
        if (!is_array($actorsRaw)) return [];
        $seen = [];
        foreach ($actorsRaw as $a) {
            if (is_string($a)) {
                $name = trim($a);
                $role = $image = $url = $bankUrl = '';
            } elseif (is_array($a)) {
                $name = trim((string)($a['name'] ?? $a['title'] ?? ''));
                $role = trim((string)($a['role'] ?? $a['character'] ?? ''));
                $image = trim((string)($a['image'] ?? $a['photo'] ?? $a['poster'] ?? ''));
                $url = trim((string)($a['url'] ?? $a['source_url'] ?? ''));
                $bankUrl = trim((string)($a['bankmovie_url'] ?? ''));
                if ($bankUrl === '' && !empty($a['slug'])) {
                    $bankUrl = 'actors.php?slug=' . rawurlencode((string)$a['slug']);
                } elseif ($bankUrl === '' && $url !== '') {
                    $slugFromUrl = bm_actor_slug_from_url($url);
                    if ($slugFromUrl !== '') $bankUrl = 'actors.php?slug=' . rawurlencode($slugFromUrl);
                }
            } else {
                continue;
            }
            if ($name === '') continue;
            $key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $actors[] = ['name' => $name, 'role' => $role, 'image' => $image, 'url' => $url, 'bankmovie_url' => $bankUrl];
        }
        return $actors;
    }
}



// ========== BankMovie Front Ads Layer (safe, no core logic changes) ==========
if(!function_exists('bm_ads_table_exists')){
    function bm_ads_table_exists(PDO $pdo, string $table): bool {
        static $cache = [];
        if(isset($cache[$table])) return $cache[$table];
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
            $stmt->execute([$table]);
            return $cache[$table] = ((int)$stmt->fetchColumn() > 0);
        } catch(Throwable $e) {
            return $cache[$table] = false;
        }
    }
}

if(!function_exists('bm_get_active_ads')){
    function bm_get_active_ads(PDO $pdo, string $position, int $limit = 1): array {
        $limit = max(1, min(6, (int)$limit));
        if(!bm_ads_table_exists($pdo, 'admin_banners')) return [];
        try {
            $sql = "SELECT id, title, position, image_path, link_url FROM admin_banners
                    WHERE is_active = 1
                      AND position = ?
                      AND (starts_at IS NULL OR starts_at <= NOW())
                      AND (ends_at IS NULL OR ends_at >= NOW())
                    ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
                    LIMIT " . $limit;
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$position]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch(Throwable $e) {
            return [];
        }
    }
}

if(!function_exists('bm_render_ad_slot')){
    function bm_render_ad_slot(PDO $pdo, string $position, string $variant = 'wide', int $limit = 1): string {
        $ads = bm_get_active_ads($pdo, $position, $limit);
        if(!$ads) return '';
        $lang = $GLOBALS['userLang'] ?? 'fa';
        $label = $lang === 'fa' ? 'تبلیغات' : 'Advertisement';
        $openText = $lang === 'fa' ? 'مشاهده' : 'Open';
        $closeText = $lang === 'fa' ? 'بستن تبلیغ' : 'Close ad';
        $safeVariant = preg_replace('/[^a-z0-9_-]/i', '', $variant) ?: 'wide';
        ob_start();
        ?>
<section class="bm-ad-slot bm-ad-<?= e($safeVariant) ?>" data-ad-position="<?= e($position) ?>" aria-label="<?= e($label) ?>">
    <?php if($safeVariant === 'floating'): ?>
    <button type="button" class="bm-ad-close" data-bm-ad-close aria-label="<?= e($closeText) ?>">×</button>
    <?php endif; ?>
    <div class="bm-ad-grid">
        <?php foreach($ads as $ad):
            $title = trim((string)($ad['title'] ?? '')) ?: $label;
            $imagePath = trim((string)($ad['image_path'] ?? ''));
            $linkUrl = trim((string)($ad['link_url'] ?? ''));
            $isLink = $linkUrl !== '' && filter_var($linkUrl, FILTER_VALIDATE_URL);
            $hasImage = $imagePath !== '' && (preg_match('/^https?:\/\//i', $imagePath) || is_file(__DIR__ . '/' . ltrim($imagePath, '/')));
        ?>
            <?php if($isLink): ?>
            <a class="bm-ad-card" href="<?= e($linkUrl) ?>" target="_blank" rel="noopener nofollow sponsored" title="<?= e($title) ?>">
            <?php else: ?>
            <div class="bm-ad-card" title="<?= e($title) ?>">
            <?php endif; ?>
                <?php if($hasImage): ?>
                    <img src="<?= e($imagePath) ?>" alt="<?= e($title) ?>" loading="lazy">
                <?php else: ?>
                    <div class="bm-ad-fallback">
                        <span class="bm-ad-fallback-icon">AD</span>
                        <strong><?= e($title) ?></strong>
                    </div>
                <?php endif; ?>
                <span class="bm-ad-glow"></span>
                <span class="bm-ad-badge"><?= e($label) ?></span>
                <span class="bm-ad-cta"><?= e($openText) ?></span>
            <?php if($isLink): ?>
            </a>
            <?php else: ?>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</section>
        <?php
        return trim(ob_get_clean());
    }
}
// ========== /BankMovie Front Ads Layer ==========


$t = [
    'fa' => [
        'home' => 'خانه',
        'profile' => 'پروفایل',
        'player' => 'پلیر',
        'request' => 'درخواست فیلم و سریال',
        'auth' => 'ثبت نام و ورود',
        'account' => 'حساب کاربری',
        'login' => 'ورود',
        'register' => 'ثبت نام',
        'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت',
        'guest' => 'کاربر مهمان',
        'notifications' => 'اعلان‌ها',
        'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'support_us' => 'حمایت مالی',
        'support_text' => 'اگر از سایت بانک مووی راضی هستید، با یک حمایت کوچک در هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن',
        'donate' => 'حمایت مالی',
    ],
    'en' => [
        'home' => 'Home',
        'profile' => 'Profile',
        'player' => 'Player',
        'request' => 'Request Movie / Series',
        'auth' => 'Login / Register',
        'account' => 'Account',
        'login' => 'Login',
        'register' => 'Register',
        'logout' => 'Logout',
        'admin_panel' => 'Admin Panel',
        'guest' => 'Guest',
        'notifications' => 'Notifications',
        'no_notifications' => 'No notifications',
        'support_us' => 'Support Us',
        'support_text' => 'All services on this site are free. If you would like to help us improve the site quality and renew the server, you can donate.',
        'close' => 'Close',
        'donate' => 'Donate',
    ]
];

$routeSlug = trim((string)($_GET['slug'] ?? ''), "/ \t\n\r\0\x0B");
$legacyImdbCode = trim((string)($_GET['imdb'] ?? ''));
$movieData = null;
$imdbCode = '';
if ($bmArchiveBlocked) {
    $arc1Error = $bmArchiveBlockedMessage ?: 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.';
    $arc1Data = null;
}

// ====== مقداردهی اولیه متغیرهای مورد استفاده در جاوااسکریپت برای آرشیو ۱ ======
$softLinks = [];
$dubLinks = [];
$bestQuality = '';
$hasDub = false;
$hasSoft = false;
$movieData = null;
$imdbCode = '';
$isMovie = false;

// ====== آرشیو ۱: اگر arc=1 هست، بخش دیتابیس محلی را کاملاً skip کن ======
if ($isArc1) {
    // آرشیو ۱ باید منطق اصلی خودش را حفظ کند؛ فقط داده‌های مشترک کامنت‌ها را قبل از رندر آماده می‌کنیم.
    $inWatchlist = $inArc1Watch ?? false;
    $avgRating = 0;
    $totalVotes = 0;
    $userRating = 0;
    $commentPage = isset($_GET['comment_page']) ? max(1, (int)$_GET['comment_page']) : 1;
    $commentsPerPage = 10;
    $commentOffset = ($commentPage - 1) * $commentsPerPage;
    $comments = [];
    $totalComments = 0;
    $totalCommentPages = 0;

    try {
        bm_ensure_archive1_comment_tables($pdo);
        $stmt = $pdo->prepare("
            SELECT c.*, 
                   COALESCE((SELECT COUNT(*) FROM archive1_comment_likes WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                   COALESCE((SELECT COUNT(*) FROM archive1_comment_likes WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                   COALESCE((SELECT type FROM archive1_comment_likes WHERE comment_id = c.id AND user_id = ?), '') as user_vote,
                   (SELECT COUNT(*) FROM archive1_comments WHERE parent_id = c.id AND status = 'approved') as reply_count,
                   u.role, u.avatar
            FROM archive1_comments c
            LEFT JOIN users u ON c.user_id = u.id
            WHERE c.movie_id = ? AND c.parent_id IS NULL AND c.status = 'approved'
            ORDER BY c.created_at DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$currentUser['id'] ?? 0, $arc1VirtualMovieId, $commentsPerPage, $commentOffset]);
        $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM archive1_comments WHERE movie_id = ? AND parent_id IS NULL AND status = 'approved'");
        $totalStmt->execute([$arc1VirtualMovieId]);
        $totalComments = (int)$totalStmt->fetchColumn();
        $totalCommentPages = (int)ceil($totalComments / $commentsPerPage);

        $ratingStmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM archive1_comments WHERE movie_id = ? AND rating > 0 AND status = 'approved' AND parent_id IS NULL");
        $ratingStmt->execute([$arc1VirtualMovieId]);
        $ratingRow = $ratingStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $avgRating = $ratingRow['avg_rating'] ?? 0;
        $totalVotes = $ratingRow['total_votes'] ?? 0;

        if ($currentUser) {
            $ur = $pdo->prepare("SELECT rating FROM archive1_comments WHERE movie_id = ? AND user_id = ? AND status = 'approved' AND parent_id IS NULL ORDER BY created_at DESC LIMIT 1");
            $ur->execute([$arc1VirtualMovieId, $currentUser['id']]);
            $userRating = (int)($ur->fetchColumn() ?: 0);
        }
    } catch (Throwable $e) {
        error_log('Archive1 comments init error: ' . $e->getMessage());
        $comments = [];
        $totalComments = 0;
        $totalCommentPages = 0;
        $avgRating = 0;
        $totalVotes = 0;
        $userRating = 0;
    }

    // ثبت بازدید آرشیوهای خارجی/آرشیو ۱ بدون شکستن صفحه
    bm_analytics_track($pdo, [
        'page_type' => 'archive_movie',
        'user_id' => $currentUser['id'] ?? null,
        'movie_id' => null,
        'imdb_code' => $arc1Slug,
        'movie_title' => $arc1Title ?? ($arc1Data['title'] ?? ''),
    ]);

    // همه پردازش اصلی آرشیو ۱ از بخش بالا انجام شده؛ دیتابیس محلی آرشیو ۲ نباید اجرا شود.
    goto arc1_render;
}

if ($legacyImdbCode !== '') {
    if (!preg_match('/^tt\d{5,12}$/', $legacyImdbCode)) { header('Location: index.php'); exit; }
    $movieData = $movie->getByImdb($legacyImdbCode);
    if (!$movieData) { header('Location: index.php'); exit; }
    header('Location: ' . bm_movie_url($movieData), true, 301);
    exit;
}

if ($routeSlug !== '') {
    $movieData = bm_find_movie_by_seo_slug($pdo, $routeSlug);
    if (!$movieData) { header('Location: index.php'); exit; }
    $imdbCode = trim((string)($movieData['imdb_code'] ?? ''));
    if ($imdbCode === '' || !preg_match('/^tt\d{5,12}$/', $imdbCode)) { header('Location: index.php'); exit; }
    $canonicalUrl = bm_movie_url($movieData);
    if ($canonicalUrl !== '/movie/' . $routeSlug) {
        header('Location: ' . $canonicalUrl, true, 301);
        exit;
    }
} else {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM movie_extra_info WHERE imdb_code = ?");
$stmt->execute([$imdbCode]);
$extraInfo = $stmt->fetch(PDO::FETCH_ASSOC);

if($currentUser) {
    $userIdForHistory = (int)$currentUser['id'];
    $stmt = $pdo->prepare("INSERT INTO watch_history (user_id, movie_id, last_watched) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE last_watched = NOW()");
    $stmt->execute([$userIdForHistory, (int)$movieData['id']]);

    // بعد از upsert فقط موارد اضافه‌تر از ۲۰۰ تا پاک می‌شود؛ نه قبل از آن.
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM watch_history WHERE user_id = ?");
    $stmtCount->execute([$userIdForHistory]);
    $extraHistoryRows = max(0, (int)$stmtCount->fetchColumn() - 200);
    if($extraHistoryRows > 0) {
        $stmtDel = $pdo->prepare("DELETE FROM watch_history WHERE user_id = ? ORDER BY last_watched ASC LIMIT " . $extraHistoryRows);
        $stmtDel->execute([$userIdForHistory]);
    }
}

// آمار بازدید فقط در فایل JSON و به‌صورت IP یونیک روزانه ثبت می‌شود.
// ثبت قدیمی جدول stats عمداً حذف شده است.

bm_analytics_track($pdo, [
    'page_type' => 'movie',
    'user_id' => $currentUser['id'] ?? null,
    'movie_id' => (int)($movieData['id'] ?? 0),
    'imdb_code' => $imdbCode,
    'movie_title' => trim((string)(($movieData['title_fa'] ?? '') ?: ($movieData['title'] ?? ''))),
]);

$softLinks = [];
$dubLinks = [];
$seriesSeasons = [];
$seriesHasDub = false;
$seriesHasSoft = false;
$arc2PlayerSoftLinks = [];
$arc2PlayerDubLinks = [];
$arc2LatestPlay = ['url'=>'','season'=>'','episode'=>'','label'=>'','quality'=>'','type'=>'','next_url'=>'','next_label'=>''];
$bmArc2HasDubDisplay = false;
$bmArc2HasSoftDisplay = false;
// ========== ادامه پردازش آرشیو ۲ (دیتابیس محلی) ==========
// اگر آرشیو ۱ است، همه این بخش skip می‌شود
$isMovie = !$isArc1 && ($movieData['type'] ?? '') === 'movie';
if(!$isArc1 && !$movieData) { header('Location: index.php'); exit; }
$bestQuality = '';

function getQualityOrder($q) {
    $q = strtolower($q);
    if(strpos($q, '2160p') !== false || strpos($q, '4k') !== false) return 6;
    if(strpos($q, '1080p') !== false) return 5;
    if(strpos($q, '720p') !== false) return 4;
    if(strpos($q, '480p') !== false) return 3;
    if(strpos($q, '360p') !== false) return 2;
    return 1;
}


function bmLocalColumnExists($pdo, $table, $column) {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool)$stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) { return false; }
}

function bmFormatSeasonKey($seasonValue) {
    $seasonValue = (string)($seasonValue ?? '');
    if (preg_match('/^S\d{2}$/i', $seasonValue)) return strtoupper($seasonValue);
    if (preg_match('/(\d+)/', $seasonValue, $m)) $seasonNum = (int)$m[1];
    else $seasonNum = 1;
    return 'S' . str_pad((string)$seasonNum, 2, '0', STR_PAD_LEFT);
}

function bmExtractEpisodeFromLocalLink($row) {
    if (isset($row['episode']) && $row['episode'] !== null && $row['episode'] !== '') return (int)$row['episode'];
    $hay = (string)($row['url'] ?? '') . ' ' . (string)($row['quality'] ?? '');
    if (preg_match('/\bS\d{1,2}E(\d{1,3})\b/i', $hay, $m)) return (int)$m[1];
    if (preg_match('/\bE(\d{1,3})\b/i', $hay, $m)) return (int)$m[1];
    if (preg_match('/قسمت\s*(\d+)/u', $hay, $m)) return (int)$m[1];
    return null;
}


function bmArc2CleanQuality($quality) {
    $q = trim((string)$quality);
    $q = preg_replace('/^S\d{1,2}E\d{1,3}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^S\d{1,2}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^E\d{1,3}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^قسمت\s*\d+\s*[-–—:]\s*/u', '', $q);
    return trim($q) !== '' ? trim($q) : (trim((string)$quality) ?: 'Unknown');
}

function bmArc2IsPlayableUrl($url) {
    return (bool)preg_match('~\.(mkv|mp4|m3u8|webm|avi)(?:[?#]|$)~i', (string)$url);
}


if (!$isArc1 && $isMovie) {
    $movieId = $movieData['id'];
    $stmt = $pdo->prepare("SELECT url, quality, size FROM dubbed_links WHERE movie_id = ?");
    $stmt->execute([$movieId]);
    $dubRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $stmt = $pdo->prepare("SELECT url, quality, size FROM softsub_links WHERE movie_id = ?");
    $stmt->execute([$movieId]);
    $softRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($dubRows as $link) {
        $quality = $link['quality'] ?? 'Unknown';
        $size = $link['size'] ?? '';
        $url = $link['url'] ?? '';
        if(!isset($dubLinks[$quality])) $dubLinks[$quality] = [];
        $dubLinks[$quality][] = ['url' => $url, 'size' => $size];
    }
    foreach($softRows as $link) {
        $quality = $link['quality'] ?? 'Unknown';
        $size = $link['size'] ?? '';
        $url = $link['url'] ?? '';
        $isDuplicate = false;
        foreach($dubRows as $dub) if($dub['url'] === $url) { $isDuplicate = true; break; }
        if(!$isDuplicate) {
            if(!isset($softLinks[$quality])) $softLinks[$quality] = [];
            $softLinks[$quality][] = ['url' => $url, 'size' => $size];
        }
    }
    uksort($dubLinks, function($a,$b) { return getQualityOrder($b)-getQualityOrder($a); });
    uksort($softLinks, function($a,$b) { return getQualityOrder($b)-getQualityOrder($a); });
    if(count($dubLinks)>0) $bestQuality = array_key_first($dubLinks);
    elseif(count($softLinks)>0) $bestQuality = array_key_first($softLinks);
} elseif (!$isArc1) {
    // ========== سریال آرشیو ۲: دریافت لینک‌ها از دیتابیس با استفاده از movie_id ==========
    $movieId = $movieData['id'];
    
    // دریافت لینک‌های دوبله
    $dubEpisodeSelect = bmLocalColumnExists($pdo, 'dubbed_links', 'episode') ? ', episode' : ', NULL AS episode';
    $stmtDub = $pdo->prepare("SELECT url, quality, size, season{$dubEpisodeSelect} FROM dubbed_links WHERE movie_id = ?");
    $stmtDub->execute([$movieId]);
    $dubRows = $stmtDub->fetchAll(PDO::FETCH_ASSOC);
    
    // دریافت لینک‌های زیرنویس
    $softEpisodeSelect = bmLocalColumnExists($pdo, 'softsub_links', 'episode') ? ', episode' : ', NULL AS episode';
    $stmtSoft = $pdo->prepare("SELECT url, quality, size, season{$softEpisodeSelect} FROM softsub_links WHERE movie_id = ?");
    $stmtSoft->execute([$movieId]);
    $softRows = $stmtSoft->fetchAll(PDO::FETCH_ASSOC);
    
    // آرایه‌ی نهایی برای نگهداری فصل‌ها
    $seriesSeasons = [];
    
    // پردازش لینک‌های دوبله
    foreach ($dubRows as $link) {
        $season = bmFormatSeasonKey($link['season'] ?? 'S01');
        $episode = bmExtractEpisodeFromLocalLink($link);
        if (!isset($seriesSeasons[$season])) {
            $seriesSeasons[$season] = [];
        }
        $seriesSeasons[$season][] = [
            'type'    => 'dub',
            'quality' => bmArc2CleanQuality($link['quality'] ?? ''),
            'url'     => $link['url'],
            'size'    => $link['size'] ?? '',
            'episode' => $episode
        ];
    }
    
    // پردازش لینک‌های زیرنویس
    foreach ($softRows as $link) {
        $season = bmFormatSeasonKey($link['season'] ?? 'S01');
        $episode = bmExtractEpisodeFromLocalLink($link);
        if (!isset($seriesSeasons[$season])) {
            $seriesSeasons[$season] = [];
        }
        $seriesSeasons[$season][] = [
            'type'    => 'soft',
            'quality' => bmArc2CleanQuality($link['quality'] ?? ''),
            'url'     => $link['url'],
            'size'    => $link['size'] ?? '',
            'episode' => $episode
        ];
    }
    
    // مرتب‌سازی کلیدهای فصل (S01, S02, ...)
    ksort($seriesSeasons, SORT_NATURAL);
    
    // در هر فصل، لینک‌ها را بر اساس کیفیت (۴K > ۱۰۸۰p > ۷۲۰p > ...) مرتب می‌کنیم
    foreach ($seriesSeasons as $season => $links) {
        usort($links, function($a, $b) {
            $ea = isset($a['episode']) && $a['episode'] !== null ? (int)$a['episode'] : 0;
            $eb = isset($b['episode']) && $b['episode'] !== null ? (int)$b['episode'] : 0;
            if ($ea !== $eb) return $ea - $eb;
            if (($a['type'] ?? '') !== ($b['type'] ?? '')) return (($a['type'] ?? '') === 'soft') ? -1 : 1;
            return getQualityOrder($b['quality']) - getQualityOrder($a['quality']);
        });
        $seriesSeasons[$season] = $links;
    }
    
    $seriesHasDub = count($dubRows) > 0;
    $seriesHasSoft = count($softRows) > 0;

    // انتخاب آخرین قسمت قابل پخش برای فعال کردن پلیر سریال‌های آرشیو ۲
    $arc2PlayableFlat = [];
    foreach ($seriesSeasons as $sn => $snLinks) {
        foreach ($snLinks as $lk) {
            if (empty($lk['url']) || !bmArc2IsPlayableUrl($lk['url'])) continue;
            $epNum = isset($lk['episode']) && $lk['episode'] !== null ? (int)$lk['episode'] : 0;
            $arc2PlayableFlat[] = [
                'season' => $sn,
                'episode' => $epNum,
                'quality' => bmArc2CleanQuality($lk['quality'] ?? ''),
                'type' => (string)($lk['type'] ?? ''),
                'url' => (string)$lk['url']
            ];
        }
    }
    usort($arc2PlayableFlat, function($a, $b) {
        $sa = (int)preg_replace('/\D+/', '', (string)($a['season'] ?? '0'));
        $sb = (int)preg_replace('/\D+/', '', (string)($b['season'] ?? '0'));
        if ($sa !== $sb) return $sb - $sa;
        $ea = (int)($a['episode'] ?? 0);
        $eb = (int)($b['episode'] ?? 0);
        if ($ea !== $eb) return $eb - $ea;
        $ta = (($a['type'] ?? '') === 'dub') ? 1 : 0;
        $tb = (($b['type'] ?? '') === 'dub') ? 1 : 0;
        if ($ta !== $tb) return $ta - $tb; // اول زیرنویس، بعد دوبله
        return getQualityOrder($b['quality'] ?? '') - getQualityOrder($a['quality'] ?? '');
    });
    if (!empty($arc2PlayableFlat)) {
        $arc2Latest = $arc2PlayableFlat[0];
        $epLabel = $arc2Latest['episode'] > 0 ? (($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $arc2Latest['episode']) : ($userLang === 'fa' ? 'پخش سریال' : 'Play series');
        $arc2LatestPlay = [
            'url' => $arc2Latest['url'],
            'season' => $arc2Latest['season'],
            'episode' => $arc2Latest['episode'] > 0 ? ('E' . str_pad((string)$arc2Latest['episode'], 2, '0', STR_PAD_LEFT)) : '',
            'label' => $arc2Latest['season'] . ' - ' . $epLabel,
            'quality' => $arc2Latest['quality'],
            'type' => $arc2Latest['type'],
            'next_url' => '',
            'next_label' => ''
        ];
    }
}


if (!$isMovie) {
    // برای فعال شدن همان پلیر آرشیو ۲ روی سریال‌ها، لینک‌های قسمت‌ها را به فرم قابل‌فهم پلیر می‌دهیم.
    // مهم: این تبدیل فقط برای سریال است؛ اگر روی فیلم اجرا شود، لینک‌های فیلم آرشیو ۲ خالی می‌شوند.
    $arc2PlayerSoftLinks = [];
    $arc2PlayerDubLinks = [];
    foreach ($seriesSeasons as $sn => $snLinks) {
        foreach ($snLinks as $lk) {
            if (empty($lk['url']) || !bmArc2IsPlayableUrl($lk['url'])) continue;
            $epNum = isset($lk['episode']) && $lk['episode'] !== null ? (int)$lk['episode'] : 0;
            $epKey = $epNum > 0 ? ('E' . str_pad((string)$epNum, 2, '0', STR_PAD_LEFT)) : 'EP';
            $qClean = bmArc2CleanQuality($lk['quality'] ?? '');
            $playerQualityKey = $sn . $epKey . ' - ' . $qClean;
            $playerItem = ['url' => (string)$lk['url'], 'size' => ''];
            if (($lk['type'] ?? '') === 'dub') {
                if (!isset($arc2PlayerDubLinks[$playerQualityKey])) $arc2PlayerDubLinks[$playerQualityKey] = [];
                $arc2PlayerDubLinks[$playerQualityKey][] = $playerItem;
            } else {
                if (!isset($arc2PlayerSoftLinks[$playerQualityKey])) $arc2PlayerSoftLinks[$playerQualityKey] = [];
                $arc2PlayerSoftLinks[$playerQualityKey][] = $playerItem;
            }
        }
    }
    uksort($arc2PlayerDubLinks, function($a, $b) { return strnatcasecmp($a, $b); });
    uksort($arc2PlayerSoftLinks, function($a, $b) { return strnatcasecmp($a, $b); });
    // movie-player-core فقط وقتی isMovie=true باشد فعال می‌شود؛ برای سریال آرشیو ۲ فقط در config جاوااسکریپت آن را فعال می‌کنیم، نه در منطق PHP صفحه.
    $softLinks = $arc2PlayerSoftLinks;
    $dubLinks = $arc2PlayerDubLinks;
    if (!$bestQuality) {
        if (!empty($arc2PlayerSoftLinks)) $bestQuality = array_key_first($arc2PlayerSoftLinks);
        elseif (!empty($arc2PlayerDubLinks)) $bestQuality = array_key_first($arc2PlayerDubLinks);
    }
}

$bmArc2HasDubDisplay = $isMovie ? $hasDub : $seriesHasDub;
$bmArc2HasSoftDisplay = $isMovie ? $hasSoft : $seriesHasSoft;

function getGenreRelatedMovies($pdo, $currentMovie, $limit=12) {
    if(empty($currentMovie['genres'])) return [];
    $genres = explode(',', $currentMovie['genres']);
    $genreConditions = [];
    $params = [];
    foreach($genres as $idx=>$genre) {
        $genreConditions[] = "FIND_IN_SET(:genre{$idx}, genres) > 0";
        $params[":genre{$idx}"] = trim($genre);
    }
    $whereGenre = implode(' OR ', $genreConditions);
    $sql = "SELECT imdb_code, title, title_fa, year, imdb_rate, type, genres FROM movies WHERE type = :type AND imdb_code != :imdb_code AND ({$whereGenre}) LIMIT 50";
    $params[':type'] = $currentMovie['type'];
    $params[':imdb_code'] = $currentMovie['imdb_code'];
    $stmt = $pdo->prepare($sql);
    foreach($params as $key=>$val) $stmt->bindValue($key, $val, is_int($val)?PDO::PARAM_INT:PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($results)) return [];
    $currentGenresArr = array_map('trim', explode(',', $currentMovie['genres']));
    $scored = [];
    foreach($results as $movie) {
        $movieGenres = array_map('trim', explode(',', $movie['genres']));
        $common = count(array_intersect($currentGenresArr, $movieGenres));
        $scored[] = ['movie'=>$movie, 'common'=>$common];
    }
    usort($scored, function($a,$b){ return $b['common']-$a['common']; });
    $grouped = [];
    foreach($scored as $item) $grouped[$item['common']][] = $item['movie'];
    $final = [];
    foreach($grouped as $movies) { shuffle($movies); $final = array_merge($final, $movies); }
    $unique = [];
    foreach($final as $movie) $unique[$movie['imdb_code']] = $movie;
    return array_slice($unique, 0, $limit);
}

function getRelatedMoviesFromDB($pdo, $currentMovie, $limit=12) {
    if(!$currentMovie) return [];
    $stopWords = ['the','a','an','and','of','to','in','for','on','with','by','at','from','is','was','are','were','be','been','being','have','has','had','having','do','does','did','doing','but','or','for','nor','so','yet'];
    $titleLow = mb_strtolower($currentMovie['title'], 'UTF-8');
    $titleLow = preg_replace('/[^\p{L}\p{N}]/u', ' ', $titleLow);
    $titleWords = explode(' ', $titleLow);
    $keywords = array_unique(array_filter($titleWords, function($w) use ($stopWords) { return mb_strlen($w)>2 && !in_array($w,$stopWords); }));
    if(empty($keywords)) $keywords = [mb_substr($titleLow,0,3)];
    $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, imdb_rate, type FROM movies WHERE type=? AND imdb_code!=?");
    $stmt->execute([$currentMovie['type'], $currentMovie['imdb_code']]);
    $allMovies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $scores = [];
    foreach($allMovies as $m) {
        $score = 0;
        $movieTitleLow = mb_strtolower($m['title'], 'UTF-8');
        foreach($keywords as $kw) {
            if(mb_strpos($movieTitleLow, $kw, 0, 'UTF-8') !== false) { $score+=10; if(preg_match("/\b".preg_quote($kw,'/')."\b/u", $movieTitleLow)) $score+=5; }
        }
        if(!empty($m['year']) && !empty($currentMovie['year']) && abs($m['year']-$currentMovie['year'])<=2) $score+=7;
        if(!empty($m['imdb_rate']) && !empty($currentMovie['imdb_rate']) && abs($m['imdb_rate']-$currentMovie['imdb_rate'])<=1.5) $score+=3;
        if($score>0) $scores[] = ['movie'=>$m, 'score'=>$score];
    }
    usort($scores, function($a,$b){ return $b['score']-$a['score']; });
    $unique = [];
    foreach($scores as $item) $unique[$item['movie']['imdb_code']] = $item['movie'];
    return array_slice($unique, 0, $limit);
}

$genreRelatedMovies = (!$isArc1 && $movieData) ? getGenreRelatedMovies($pdo, $movieData, 12) : [];
$relatedMovies      = (!$isArc1 && $movieData) ? getRelatedMoviesFromDB($pdo, $movieData, 12) : [];

$hasDub = $isMovie ? count($dubLinks) > 0 : $seriesHasDub;
$hasSoft = $isMovie ? count($softLinks) > 0 : $seriesHasSoft;
$bmArc2HasDubDisplay = $isMovie ? $hasDub : $seriesHasDub;
$bmArc2HasSoftDisplay = $isMovie ? $hasSoft : $seriesHasSoft;
$pageTitle = $movieData['title_fa'] ?: $movieData['title'];

// Notifications - هماهنگ با header/index
$notificationsList = [];
$activeNotification = null;
$notificationSeen = false;
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    $activeNotification = $stmt->fetch(PDO::FETCH_ASSOC);
    if($activeNotification) {
        $cookieName = 'notification_seen_' . $activeNotification['id'];
        if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
    }
} catch (Throwable $e) {
    $notificationsList = [];
    $activeNotification = null;
    $notificationSeen = false;
}

// =================== سیستم کامنت (با تأیید ادمین، اسپویلر دکمه‌ای، حذف) ===================
function updateMovieRating($pdo, $movieId) {
    $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM comments WHERE movie_id = ? AND rating > 0 AND status = 'approved' AND parent_id IS NULL");
    $stmt->execute([$movieId]);
    $data = $stmt->fetch();
    $stmt = $pdo->prepare("INSERT INTO movie_ratings (movie_id, avg_rating, total_votes) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE avg_rating = ?, total_votes = ?");
    $stmt->execute([$movieId, $data['avg_rating'] ?? 0, $data['total_votes'] ?? 0, $data['avg_rating'] ?? 0, $data['total_votes'] ?? 0]);
    return ['avg' => round($data['avg_rating'] ?? 0, 1), 'total' => $data['total_votes'] ?? 0];
}

$ratingData = null; $userRating = 0; $inWatchlist = false; $avgRating = 0; $totalVotes = 0;
if(!$isArc1 && $movieData) {
    $stmt = $pdo->prepare("SELECT avg_rating, total_votes FROM movie_ratings WHERE movie_id = ?");
    $stmt->execute([$movieData['id']]);
    $ratingData = $stmt->fetch();
    if($currentUser) {
        $stmt = $pdo->prepare("SELECT id FROM watchlist WHERE user_id = ? AND movie_id = ?");
        $stmt->execute([$currentUser['id'], $movieData['id']]);
        $inWatchlist = $stmt->fetch() ? true : false;
        $stmt = $pdo->prepare("SELECT rating FROM comments WHERE movie_id = ? AND user_id = ? AND status = 'approved' AND parent_id IS NULL");
        $stmt->execute([$movieData['id'], $currentUser['id']]);
        $userComment = $stmt->fetch();
        if($userComment) $userRating = $userComment['rating'];
    }
    $avgRating = $ratingData['avg_rating'] ?? 0;
    $totalVotes = $ratingData['total_votes'] ?? 0;
}

$commentPage = isset($_GET['comment_page']) ? (int)$_GET['comment_page'] : 1;
$commentsPerPage = 10;
$commentOffset = ($commentPage - 1) * $commentsPerPage;

$stmt = $pdo->prepare("
    SELECT c.*, 
           COALESCE((SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
           COALESCE((SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
           COALESCE((SELECT type FROM comment_likes WHERE comment_id = c.id AND user_id = ?), '') as user_vote,
           (SELECT COUNT(*) FROM comments WHERE parent_id = c.id AND status = 'approved') as reply_count,
           u.role, u.avatar
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.movie_id = ? AND c.parent_id IS NULL AND c.status = 'approved'
    ORDER BY c.created_at DESC
    LIMIT ? OFFSET ?
");
$stmt->execute([$currentUser['id'] ?? 0, ($isArc1 ? $arc1VirtualMovieId : ($movieData['id'] ?? 0)), $commentsPerPage, $commentOffset]);
$comments = $stmt->fetchAll();

$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM comments WHERE movie_id = ? AND parent_id IS NULL AND status = 'approved'");
$totalStmt->execute([($isArc1 ? $arc1VirtualMovieId : ($movieData['id'] ?? 0))]);
$totalComments = $totalStmt->fetchColumn();
$totalCommentPages = ceil($totalComments / $commentsPerPage);

function getRepliesHTML($commentId, $currentUserId, $userLang, $isArchive1 = false) {
    global $pdo, $currentUser;
    $commentId = (int)$commentId;
    $currentUserId = (int)$currentUserId;
    if ($isArchive1) bm_ensure_archive1_comment_tables($pdo);
    $commentTable = $isArchive1 ? 'archive1_comments' : 'comments';
    $likeTable = $isArchive1 ? 'archive1_comment_likes' : 'comment_likes';
    $stmt = $pdo->prepare("
        SELECT r.*, 
               COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'like'), 0) as like_count,
               COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'dislike'), 0) as dislike_count,
               COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = r.id AND user_id = ?), '') as user_vote,
               COALESCE(u.role, 'user') as role,
               COALESCE(u.avatar, '') as avatar
        FROM {$commentTable} r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = ? AND r.status = 'approved'
        ORDER BY r.created_at ASC
    ");
    $stmt->execute([$currentUserId, $commentId]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $style = 'margin-top:12px; padding-left:20px; border-left:2px solid var(--border-accent);';
    if(empty($replies)) {
        return '<div class="replies-container" id="replies-'.$commentId.'" style="display:none; '.$style.'"></div>';
    }

    $html = '<div class="replies-container" id="replies-'.$commentId.'" style="'.$style.'">';
    foreach($replies as $reply) {
        $canDelete = $currentUserId && ((int)$currentUserId === (int)$reply['user_id'] || ($currentUser && ($currentUser['role'] ?? '') === 'admin'));
        $deleteBtn = $canDelete ? '<button class="delete-comment-btn" data-id="'.(int)$reply['id'].'"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>' : '';
        $adminTick = ($reply['role'] === 'admin') ? '<svg class="admin-tick admin-verified-tick" width="14" height="14" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" aria-label="Verified admin"><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" fill="#1d9bf0"></path></svg>' : '';
        $avatarHtml = (!empty($reply['avatar']) && preg_match('/^(https?:\/\/|[A-Za-z0-9_\.\-\/]+$)/', $reply['avatar'])) ? '<img src="'.htmlspecialchars($reply['avatar'], ENT_QUOTES, 'UTF-8').'" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;">' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        $replyText = nl2br(htmlspecialchars($reply['comment'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
        if((int)$reply['spoiler'] === 1) {
            $replyText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">'.$replyText.'</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">'.($userLang === 'fa' ? 'نمایش اسپویلر' : 'Show spoiler').'</button></div>';
        } else {
            $replyText = preg_replace_callback('/\[spoiler\](.*?)\[\/spoiler\]/is', function($m) use ($userLang) {
                return '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">'.$m[1].'</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">'.($userLang === 'fa' ? 'نمایش اسپویلر' : 'Show spoiler').'</button></div>';
            }, $replyText);
        }
        $html .= '<div class="reply-item" data-id="'.(int)$reply['id'].'" data-parent-id="'.$commentId.'" style="background: var(--bg-tertiary); border-radius: 16px; padding: 12px; margin-bottom: 12px;">
            <div class="reply-header">
                <div class="reply-user">
                    <div class="reply-avatar" style="overflow:hidden; width:24px; height:24px; border-radius:50%;">'.$avatarHtml.'</div>
                    <span class="reply-name">'.htmlspecialchars($reply['username'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8').' '.$adminTick.'</span>
                </div>
                <span class="comment-date">'.formatCommentDate($reply['created_at'], $userLang).'</span>
            </div>
            <div class="reply-text">'.$replyText.'</div>
            <div class="reply-actions" style="display: flex; gap: 12px; margin-top: 8px;">
                <div class="comment-like '.($reply['user_vote'] === 'like' ? 'active' : '').'" data-id="'.(int)$reply['id'].'" data-type="like"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg><span class="like-count">'.number_format((int)$reply['like_count']).'</span></div>
                <div class="comment-dislike '.($reply['user_vote'] === 'dislike' ? 'active' : '').'" data-id="'.(int)$reply['id'].'" data-type="dislike"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg><span class="dislike-count">'.number_format((int)$reply['dislike_count']).'</span></div>
                '.$deleteBtn.'
            </div>
        </div>';
    }
    $html .= '</div>';
    return $html;
}

function formatCommentDate($date, $lang) {
    if(empty($date)) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $timestamp = strtotime($date);
    if($timestamp === false) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $diff = time() - $timestamp;
    if($diff < 0) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if($diff < 60) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if($diff < 3600) return floor($diff/60).($lang === 'fa' ? ' دقیقه پیش' : ' minutes ago');
    if($diff < 86400) return floor($diff/3600).($lang === 'fa' ? ' ساعت پیش' : ' hours ago');
    if($diff < 604800) return floor($diff/86400).($lang === 'fa' ? ' روز پیش' : ' days ago');
    if($diff < 2592000) return floor($diff/604800).($lang === 'fa' ? ' هفته پیش' : ' weeks ago');
    if($diff < 31536000) return floor($diff/2592000).($lang === 'fa' ? ' ماه پیش' : ' months ago');
    return floor($diff/31536000).($lang === 'fa' ? ' سال پیش' : ' years ago');
}

function renderStars($rating) {
    $full = floor($rating);
    $empty = 5 - $full;
    $stars = '';
    for($i=0;$i<$full;$i++) $stars .= '<svg class="star star-full" viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    for($i=0;$i<$empty;$i++) $stars .= '<svg class="star star-empty" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    return $stars;
}
function renderStarInput($selected = 0) {
    $stars = '';
    for($i=1;$i<=5;$i++) $stars .= '<svg class="star-input" data-value="'.$i.'" viewBox="0 0 24 24" fill="'.($i<=$selected ? 'currentColor' : 'none').'" stroke="currentColor" style="width:24px;height:24px;cursor:pointer;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    return $stars;
}

function renderCommentHTML($comment, $lang, $currentUserId, $isArchive1 = false) {
    global $currentUser;
    $adminTick = ($comment['role'] === 'admin') ? '<svg class="admin-tick admin-verified-tick" width="16" height="16" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" aria-label="Verified admin"><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" fill="#1d9bf0"></path></svg>' : '';
    $replyText = $lang === 'fa' ? 'پاسخ' : 'Reply';
    $replyCount = $comment['reply_count'] ?? 0;
    $replyCountHtml = $replyCount > 0 ? '<span class="reply-count">('.$replyCount.')</span>' : '';
    $avatarHtml = (!empty($comment['avatar']) && file_exists($comment['avatar'])) ? '<img src="'.htmlspecialchars($comment['avatar']).'" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;">' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    $commentText = nl2br(htmlspecialchars($comment['comment']));
    if($comment['spoiler'] == 1) {
        $commentText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">' . $commentText . '</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
    } else {
        $commentText = preg_replace_callback('/\[spoiler\](.*?)\[\/spoiler\]/is', function($m) {
            return '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">'.$m[1].'</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
        }, $commentText);
    }
    $deleteBtn = '';
    if($currentUserId && ($currentUserId == $comment['user_id'] || ($currentUser && $currentUser['role'] == 'admin'))) {
        $deleteBtn = '<button class="delete-comment-btn" data-id="'.$comment['id'].'"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>';
    }
    $repliesHtml = getRepliesHTML($comment['id'], $currentUserId, $lang, $isArchive1);
    return '
    <div class="comment-item" data-id="'.$comment['id'].'" data-reply-count="'.$replyCount.'">
        <div class="comment-header">
            <div class="comment-user">
                <div class="comment-avatar-small" style="overflow:hidden;">'.$avatarHtml.'</div>
                <div>
                    <div class="comment-name">'.htmlspecialchars($comment['username']).' '.$adminTick.'</div>
                    <div class="comment-date">'.formatCommentDate($comment['created_at'], $lang).'</div>
                </div>
            </div>
            <div class="comment-rating-stars">'.renderStars($comment['rating']).'</div>
        </div>
        <div class="comment-text">'.$commentText.'</div>
        <div class="comment-actions">
            <div class="comment-like '.($comment['user_vote'] === 'like' ? 'active' : '').'" data-id="'.$comment['id'].'" data-type="like">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                <span class="like-count">'.number_format($comment['like_count']).'</span>
            </div>
            <div class="comment-dislike '.($comment['user_vote'] === 'dislike' ? 'active' : '').'" data-id="'.$comment['id'].'" data-type="dislike">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                <span class="dislike-count">'.number_format($comment['dislike_count']).'</span>
            </div>
            <button class="reply-btn" data-id="'.$comment['id'].'">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <span>'.$replyText.'</span> '.$replyCountHtml.'
            </button>
            '.$deleteBtn.'
        </div>
        <div class="reply-form-container" id="reply-form-'.$comment['id'].'" style="display:none; margin-top:12px;"></div>
        '.$repliesHtml.'
    </div>';
}
?>
<?php arc1_render: ?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>">
<head>
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=37" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=37">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=37">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=no">
    <link rel="preload" href="/bonVF.woff2" as="font" type="font/woff2" crossorigin>
    <meta name="csrf-token" content="<?= e($csrfToken) ?>">
    <?php
    if($isArc1 && $arc1Data) {
        // SEO برای آرشیو ۱
        $seoTitleEn  = $arc1Title ?? '';
        $seoTitleFa  = $arc1Title ?? '';
        $seoYear     = $arc1Year  ?? '';
        $seoType     = ($arc1IsSeries ?? false) ? ($userLang==='fa'?'سریال':'Series') : ($userLang==='fa'?'فیلم':'Movie');
        $seoGenres   = is_array($arc1Genres ?? []) ? implode(', ', $arc1Genres) : '';
        $seoImdb     = '';
        $seoImage    = $arc1Poster ?? '';
        $seoDesc     = $arc1Desc  ?? '';
        $seoDescEn   = $arc1Desc  ?? '';
    } else {
        $seoTitleEn  = trim((string)($movieData['title']    ?? ''));
        $seoTitleFa  = trim((string)($movieData['title_fa'] ?? ''));
        $seoYear     = !empty($movieData['year'])      ? (int)$movieData['year']      : '';
        $seoType     = ($movieData['type'] ?? '') === 'series' ? ($userLang === 'fa' ? 'سریال' : 'Series') : ($userLang === 'fa' ? 'فیلم' : 'Movie');
        $seoGenres   = trim((string)($movieData['genres'] ?? ''));
        $seoImdb     = trim((string)($movieData['imdb_code'] ?? ''));
        $seoImgRaw   = trim((string)($movieData['poster'] ?? ($movieData['image'] ?? '')));
        $seoImage    = $seoImgRaw !== '' ? (preg_match('/^https?:\/\//i', $seoImgRaw) ? $seoImgRaw : rtrim(SITE_URL, '/') . '/' . ltrim($seoImgRaw, '/')) : '';
        $seoDesc     = trim((string)($movieData['description_fa'] ?? ($movieData['description'] ?? '')));
        $seoDescEn   = trim((string)($movieData['description'] ?? ''));
    }
    $seoRating   = !empty($movieData['imdb_rate']) ? (float)$movieData['imdb_rate'] : 0;
    $canonicalFull = rtrim(SITE_URL, '/') . ($canonicalUrl ?? '/movie/' . ($routeSlug ?? ''));

    // ── Title tag ──────────────────────────────────────────────────
    // فارسی: دانلود فیلم/سریال {title_fa} | {title_en} | BankMovie
    // انگلیسی: Download {type} {title_en} | {title_fa} | BankMovie
    if ($userLang === 'fa') {
        $metaTitle = 'دانلود ' . $seoType . ($seoTitleFa !== '' ? ' ' . $seoTitleFa : '') . ($seoTitleEn !== '' ? ' ' . $seoTitleEn : '') . ($seoYear !== '' ? ' ' . $seoYear : '') . ' | BankMovie';
    } else {
        $metaTitle = 'Download ' . $seoType . ($seoTitleEn !== '' ? ' ' . $seoTitleEn : '') . ($seoTitleFa !== '' ? ' ' . $seoTitleFa : '') . ($seoYear !== '' ? ' (' . $seoYear . ')' : '') . ' | BankMovie';
    }

    // ── Meta description ───────────────────────────────────────────
    $descBase = ($userLang === 'fa' && $seoDesc !== '') ? $seoDesc : ($seoDescEn !== '' ? $seoDescEn : '');
    $descBase = mb_substr(strip_tags($descBase), 0, 120, 'UTF-8');
    if ($userLang === 'fa') {
        $metaDesc = 'دانلود ' . $seoType . ($seoTitleFa !== '' ? ' ' . $seoTitleFa : '') . ($seoTitleEn !== '' ? ' | ' . $seoTitleEn : '') . ($seoYear !== '' ? ' ' . $seoYear : '') . ($descBase !== '' ? ' — ' . $descBase . '...' : '') . ' با لینک مستقیم از BankMovie';
    } else {
        $metaDesc = 'Download ' . ($seoTitleEn !== '' ? $seoTitleEn : '') . ($seoYear !== '' ? ' (' . $seoYear . ')' : '') . ($seoTitleFa !== '' ? ' | ' . $seoTitleFa : '') . ($descBase !== '' ? '. ' . $descBase . '...' : '') . ' — Direct download links on BankMovie.';
    }
    $metaDesc = htmlspecialchars(mb_substr($metaDesc, 0, 160, 'UTF-8'), ENT_QUOTES, 'UTF-8');

    // ── Meta keywords ─────────────────────────────────────────────
    $kwBase = [];
    if ($seoTitleFa !== '') $kwBase[] = $seoTitleFa;
    if ($seoTitleEn !== '') $kwBase[] = $seoTitleEn;
    if ($seoTitleFa !== '') { $kwBase[] = 'دانلود ' . $seoTitleFa; $kwBase[] = 'دانلود فیلم ' . $seoTitleFa; }
    if ($seoTitleEn !== '') { $kwBase[] = 'download ' . $seoTitleEn; }
    if ($seoYear !== '')    { $kwBase[] = $seoTitleFa . ' ' . $seoYear; $kwBase[] = $seoTitleEn . ' ' . $seoYear; }
    $kwBase[] = 'BankMovie'; $kwBase[] = 'bankmovie';
    $metaKeywords = htmlspecialchars(implode(', ', array_unique(array_filter($kwBase))), ENT_QUOTES, 'UTF-8');

    // ── JSON-LD Schema ─────────────────────────────────────────────
    $schemaType = ($movieData['type'] ?? '') === 'series' ? 'TVSeries' : 'Movie';
    $schemaData = [
        '@context'    => 'https://schema.org',
        '@type'       => $schemaType,
        'name'        => $seoTitleEn ?: $seoTitleFa,
        'alternateName' => array_filter([$seoTitleFa, $seoTitleEn]),
        'url'         => $canonicalFull,
        'description' => mb_substr(strip_tags($seoDescEn ?: $seoDesc), 0, 300, 'UTF-8'),
    ];
    if ($seoYear !== '') $schemaData['datePublished'] = (string)$seoYear;
    if ($seoImage !== '') $schemaData['image'] = $seoImage;
    if ($seoRating > 0) {
        $schemaData['aggregateRating'] = [
            '@type'       => 'AggregateRating',
            'ratingValue' => $seoRating,
            'bestRating'  => 10,
            'worstRating' => 1,
            'ratingCount' => !empty($movieData['imdb_votes']) ? (int)$movieData['imdb_votes'] : 100,
        ];
    }
    if (!empty($movieData['director'])) $schemaData['director'] = ['@type' => 'Person', 'name' => $movieData['director']];
    if ($seoGenres !== '') {
        $schemaData['genre'] = array_map('trim', explode(',', $seoGenres));
    }
    ?>
    <title><?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?></title>

    <!-- ══ SEO Core ══ -->
    <meta name="description" content="<?= $metaDesc ?>">
    <meta name="keywords"    content="<?= $metaKeywords ?>">
    <meta name="robots"      content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <link rel="canonical"    href="<?= htmlspecialchars($canonicalFull, ENT_QUOTES, 'UTF-8') ?>">

    <!-- ══ Open Graph (Facebook / Telegram / WhatsApp) ══ -->
    <meta property="og:type"        content="<?= ($movieData['type'] ?? '') === 'series' ? 'video.tv_show' : 'video.movie' ?>">
    <meta property="og:title"       content="<?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:description" content="<?= $metaDesc ?>">
    <meta property="og:url"         content="<?= htmlspecialchars($canonicalFull, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:site_name"   content="BankMovie">
    <meta property="og:locale"      content="<?= $userLang === 'fa' ? 'fa_IR' : 'en_US' ?>">
    <?php if ($seoImage !== ''): ?>
    <meta property="og:image"       content="<?= htmlspecialchars($seoImage, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="900">
    <meta property="og:image:alt"   content="<?= htmlspecialchars($seoTitleEn ?: $seoTitleFa, ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>

    <!-- ══ Twitter Card ══ -->
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:description" content="<?= $metaDesc ?>">
    <?php if ($seoImage !== ''): ?>
    <meta name="twitter:image"       content="<?= htmlspecialchars($seoImage, ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>

    <!-- ══ JSON-LD Schema.org ══ -->
    <script type="application/ld+json"><?= json_encode($schemaData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?></script>
    <style>:root{--bm-accent:<?= e($currentTheme['primary']) ?>;--bm-accent-rgb:<?= e($currentThemeRgbCss) ?>;--bm-accent-dark:<?= e($currentTheme['primary']) ?>cc;}</style>
<link rel="stylesheet" href="/assets/css/movie-inline-1.css?v=dl36">

<link rel="stylesheet" href="/assets/css/movie-inline-2.css?v=dl36">



<link rel="stylesheet" href="/assets/css/movie-inline-3.css?v=dl36">

<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script src="/assets/js/movie-inline-1.js?v=mobile-smooth37"></script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue78">
</head>
<body data-theme="<?= e($userTheme) ?>" lang="<?= e($langAttr) ?>" class="no-hero movie-page bm-design2-safe">

<div class="bm-page-loader" id="bmPageLoader" aria-label="در حال بارگذاری صفحه">
    <div class="bm-loader-card">
        <div class="bm-loader-reel">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <rect x="3" y="5" width="18" height="14" rx="3"/>
                <path d="M7 5l2 4M13 5l2 4M19 5l2 4M3 9h18M10 13l5 3-5 3v-6z"/>
            </svg>
        </div>
        <div class="bm-loader-title">BankMovie</div>
        <div class="bm-loader-sub">در حال آماده‌سازی صفحه فیلم...</div>
        <div class="bm-loader-bar"><span></span></div>
    </div>
</div>

<div class="bm-share-sheet" id="bmShareSheet" aria-hidden="true">
    <div class="bm-share-panel" role="dialog" aria-modal="true" aria-labelledby="bmShareTitle">
        <div class="bm-share-head">
            <strong id="bmShareTitle">اشتراک‌گذاری</strong>
            <button type="button" class="bm-share-close" data-bm-share-close aria-label="بستن">×</button>
        </div>
        <div class="bm-share-grid">
            <a class="bm-share-item bm-share-telegram" data-share-platform="telegram" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M21.8 4.6 18.6 20c-.2 1-1 1.2-1.8.8l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.2 9.4-8.5c.4-.4-.1-.6-.6-.3L6 13.2 1 11.6c-1-.3-1-1 .2-1.5L20.4 2.7c.9-.3 1.7.2 1.4 1.9Z"/></svg></span>
                <span>تلگرام</span>
            </a>
            <a class="bm-share-item bm-share-whatsapp" data-share-platform="whatsapp" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M20.5 3.5A11.8 11.8 0 0 0 2.2 17.7L1 23l5.4-1.4A11.8 11.8 0 0 0 12 23 11.8 11.8 0 0 0 20.5 3.5ZM12 21a9.7 9.7 0 0 1-5-1.4l-.4-.2-3.2.8.9-3.1-.2-.4A9.8 9.8 0 1 1 12 21Zm5.4-7.3c-.3-.2-1.8-.9-2.1-1s-.5-.2-.7.2-.8 1-.9 1.1-.3.2-.6.1a8 8 0 0 1-2.3-1.4A8.8 8.8 0 0 1 9.2 11c-.2-.3 0-.5.1-.6l.5-.6c.2-.2.2-.3.3-.5s0-.4 0-.6-.7-1.7-1-2.3c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4s-1.2 1.1-1.2 2.8 1.2 3.2 1.4 3.4 2.4 3.7 5.8 5.1c.8.3 1.4.5 1.9.7.8.2 1.5.2 2.1.1.6-.1 1.8-.7 2.1-1.5.3-.7.3-1.3.2-1.5-.1-.2-.3-.3-.6-.4Z"/></svg></span>
                <span>واتساپ</span>
            </a>
            <a class="bm-share-item bm-share-instagram" data-share-platform="instagram" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm5 5.4A4.6 4.6 0 1 0 12 16.6 4.6 4.6 0 0 0 12 7.4Zm0 1.8A2.8 2.8 0 1 1 12 14.8 2.8 2.8 0 0 1 12 9.2ZM17.8 6a1.1 1.1 0 1 0 0 2.2 1.1 1.1 0 0 0 0-2.2Z"/></svg></span>
                <span>اینستاگرام</span>
            </a>
            <a class="bm-share-item bm-share-x" data-share-platform="twitter" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M18.9 2h3.3l-7.2 8.2L23.5 22h-6.7l-5.2-6.8L5.6 22H2.3l7.7-8.8L1.8 2h6.9l4.7 6.2L18.9 2Zm-1.2 17.9h1.8L7.7 4H5.8l11.9 15.9Z"/></svg></span>
                <span>توییتر / X</span>
            </a>
            <a class="bm-share-item bm-share-sms" data-share-platform="sms">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z" stroke="currentColor" stroke-width="2"/></svg></span>
                <span>پیام‌رسان</span>
            </a>
            <button type="button" class="bm-share-item bm-share-copy" data-share-platform="copy">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" stroke="currentColor" stroke-width="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/></svg></span>
                <span>کپی لینک</span>
            </button>
        </div>
        <div class="bm-share-url">
            <input type="text" id="bmShareUrl" readonly value="">
            <button type="button" data-share-platform="copy">کپی</button>
        </div>
    </div>
</div>

<?php if($activeNotification && !$notificationSeen): ?>
<div class="notification-modal" id="notificationModal" style="position:fixed;inset:0;background:rgba(0,0,0,0.95);backdrop-filter:blur(20px);z-index:20000;display:flex;align-items:center;justify-content:center">
    <div style="background:#0f0f13;border:1px solid var(--border-accent);border-radius:32px;padding:40px;max-width:500px;width:90%;text-align:center">
        <div style="width:80px;height:80px;background:var(--accent-glow);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px">
            <svg width="45" height="45" viewBox="0 0 24 24" fill="none" stroke="var(--accent)"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        </div>
        <div style="font-size:24px;font-weight:800;color:var(--accent);margin-bottom:16px"><?= $userLang=='fa'?'اعلامیه مهم':'Important Announcement' ?></div>
        <div style="color:var(--text-secondary);line-height:1.6;margin-bottom:24px"><?= nl2br(e($activeNotification['message'])) ?></div>
        <button class="notification-btn" id="closeNotificationBtn" type="button" data-notification-id="<?= e((string)($activeNotification['id'] ?? '')) ?>" style="background:var(--accent);color:#000;border:none;padding:12px 32px;border-radius:40px;font-weight:700;cursor:pointer"><?= $userLang=='fa'?'متوجه شدم':'Got it' ?></button>
    </div>
</div>
<?php endif; ?>
<?php if($activeNotification && !$notificationSeen): ?>
<script>window.BM_NOTIFICATION_ID = <?= json_encode((string)($activeNotification['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="/assets/js/bm-notification.js?v=dl36"></script>
<?php endif; ?>

<div class="loading-overlay" id="loadingOverlay"><div class="loading-spinner"></div></div>
<script src="/assets/js/movie-inline-2.js?v=dl36"></script>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <?php if($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username']) ?></div><div class="sidebar-userrole"><?= $currentUser['role']==='admin'?($userLang=='fa'?'مدیر':'Admin'):($userLang=='fa'?'کاربر':'User') ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="index.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="player.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="collections.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if($currentUser): ?>
        <a href="profile.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if($currentUser['role']==='admin'): ?>
        <a href="admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; ?><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="logout.php" class="sidebar-item" onclick="return confirm('<?= $userLang=='fa'?'آیا از خروج مطمئن هستید؟':'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="login.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="register.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header"><h3><?= $t[$userLang]['notifications'] ?></h3><button class="notif-close" id="closeNotifSidebar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'])) ?></div><div class="notif-date"><?= date('Y/m/d H:i', strtotime($notif['created_at'])) ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=split82" defer></script>

<div class="container">

<?php if($isArc1): ?>
<!-- ====== آرشیو خارجی ====== -->
<?php if($arc1Error && !$arc1Data): ?>
<div style="text-align:center;padding:60px 20px;color:rgba(255,255,255,.4)">
    <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="margin:0 auto 16px;opacity:.4"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <h2 style="margin-bottom:10px;color:#fff">خطا در بارگذاری</h2>
    <p style="margin-bottom:20px"><?= e($arc1Error) ?></p>
    <a href="javascript:history.back()" style="color:rgba(255,255,255,.5);font-size:13px">← برگشت</a>
</div>
<?php else: ?>
<link rel="stylesheet" href="/assets/css/movie-inline-4.css?v=dl36">

<!-- پلیر آرشیو خارجی (مشابه آرشیو ۲) -->
<?php
$arc1FirstVideoUrl = '';
$arc1FirstSubtitleUrl = '';
if(!$arc1IsSeries) {
    // برای آرشیو ۱ اگر فیلم دوبله و نسخه زیرنویس‌دار همزمان داشت، پلیر پیش‌فرض را روی نسخه زیرنویس‌دار بگذار.
    // قبلاً بعد از بعضی آپدیت‌ها نسخه دوبله زودتر انتخاب می‌شد و کاربر فکر می‌کرد زیرنویس حذف شده است.
    foreach([$arc1MovieSoft, $arc1MovieDub] as $arc1Group) {
        foreach($arc1Group as $arc1Items) {
            foreach($arc1Items as $arc1Candidate) {
                if(empty($arc1Candidate['is_audio']) && !empty($arc1Candidate['url'])) {
                    $arc1FirstVideoUrl = $arc1Candidate['url'];
                    $arc1FirstSubtitleUrl = trim((string)($arc1Candidate['subtitle_url'] ?? ''));
                    break 3;
                }
            }
        }
    }
}

/*
 * Safe latest-episode selector for archive 1/3 series.
 * This only reads the already-built $arc1SeriesSeasons array and feeds the existing arc1 player click handler.
 * No player/source/loading logic is changed.
 */
$arc1LatestPlay = [
    'url' => '',
    'season' => '',
    'episode' => '',
    'label' => '',
    'next_url' => '',
    'next_label' => '',
    'subtitle_url' => ''
];
if($arc1IsSeries && !empty($arc1SeriesSeasons) && is_array($arc1SeriesSeasons)) {
    $seasonKeys = array_keys($arc1SeriesSeasons);
    natsort($seasonKeys);
    $lastSeasonKey = end($seasonKeys);
    $latestEpisodes = is_string($lastSeasonKey) && isset($arc1SeriesSeasons[$lastSeasonKey]) ? $arc1SeriesSeasons[$lastSeasonKey] : [];
    if(!empty($latestEpisodes) && is_array($latestEpisodes)) {
        $epKeys = array_keys($latestEpisodes);
        natsort($epKeys);
        $realEpKeys = [];
        foreach($epKeys as $ekCandidate) {
            if(preg_match('/^E\d+/i', (string)$ekCandidate)) $realEpKeys[] = $ekCandidate;
        }
        if(!empty($realEpKeys)) {
            natsort($realEpKeys);
            $lastEpKey = end($realEpKeys);
        } else {
            $lastEpKey = end($epKeys);
        }
        $latestLinks = isset($latestEpisodes[$lastEpKey]) ? $latestEpisodes[$lastEpKey] : [];
        if(!empty($latestLinks) && is_array($latestLinks)) {
            $latestLink = $latestLinks[0];
            $latestSeasonNum = ltrim(preg_replace('/[^0-9]/', '', (string)$lastSeasonKey), '0');
            if($latestSeasonNum === '') $latestSeasonNum = '1';
            $latestEpisodeNum = ((string)$lastEpKey === 'full') ? '' : ltrim(preg_replace('/[^0-9]/', '', (string)$lastEpKey), '0');
            $latestLabel = ((string)$lastEpKey === 'full' || $latestEpisodeNum === '') ? 'فصل کامل' : ('قسمت ' . $latestEpisodeNum);
            $arc1LatestPlay = [
                'url' => trim((string)($latestLink['url'] ?? '')),
                'season' => $latestSeasonNum,
                'episode' => $latestEpisodeNum,
                'label' => $latestLabel,
                'next_url' => '',
                'next_label' => '',
                'subtitle_url' => trim((string)($latestLink['subtitle_url'] ?? ''))
            ];
        }
    }
}
?>

<div class="movie-detail bm-arc1-no-backdrop" style="--bg-image:url('<?= e($arc1Poster ?? '') ?>');">
    <div class="poster-col">
        <?php if($arc1Poster): ?>
        <img src="<?= e($arc1Poster) ?>" alt="<?= e($arc1Title) ?>" onerror="this.src='uploads/no.png'" style="border-radius:18px;width:100%;object-fit:cover">
        <?php else: ?>
        <div style="width:100%;aspect-ratio:2/3;background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:18px;display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
        <?php endif; ?>
        <?php if($arc1HasDub || $arc1HasSub): ?>
        <div class="bm-poster-badges" aria-label="ویژگی‌های نسخه">
            <?php if($arc1HasDub): ?>
            <span class="bm-poster-badge bm-badge-dub" title="دوبله فارسی">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a4 4 0 0 0-4 4v6a4 4 0 0 0 8 0V6a4 4 0 0 0-4-4z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3M8 22h8"/></svg>
                <span>دوبله</span>
            </span>
            <?php endif; ?>
            <?php if($arc1HasSub): ?>
            <span class="bm-poster-badge bm-badge-cc" title="<?= e($bmArchiveSubFa) ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                <span><?= e($bmArchiveSubFa) ?></span>
            </span>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if(!$arc1IsSeries && $arc1FirstVideoUrl): ?>
        <button type="button" class="bm-poster-play arc1-play-btn" data-url="<?= e($arc1FirstVideoUrl) ?>" data-subtitle-url="<?= e($arc1FirstSubtitleUrl) ?>" aria-label="پخش آنلاین">
            <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
        </button>
        <?php elseif($arc1IsSeries && !empty($arc1LatestPlay['url'])): ?>
        <button type="button" class="bm-poster-play arc1-play-btn"
            data-url="<?= e($arc1LatestPlay['url']) ?>"
            data-season="<?= e($arc1LatestPlay['season']) ?>"
            data-episode="<?= e($arc1LatestPlay['episode']) ?>"
            data-label="<?= e($arc1LatestPlay['label']) ?>"
            data-next-url=""
            data-next-label=""
            data-subtitle-url="<?= e($arc1LatestPlay['subtitle_url'] ?? '') ?>">
            <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
        </button>
        <?php endif; ?>
    </div>

    <div class="info-col">
        <h1 class="movie-title-fa"><?= e($arc1Title) ?></h1>
        <div class="movie-rating-section">
            <?php if($arc1ImdbRate): ?>
            <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(245,197,24,.1);border:1px solid rgba(245,197,24,.25);border-radius:40px;padding:5px 12px;font-size:13px;color:#f5c518;font-weight:700">
                <img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy" style="width:32px;height:16px;object-fit:contain;border-radius:3px"> <?= number_format((float)$arc1ImdbRate,1) ?>/10
            </div>
            <?php endif; ?>
            <?php if($arc1Satisfaction): ?><div class="bm-satisfaction-chip" style="display:inline-flex;align-items:center;gap:6px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:40px;padding:5px 12px;font-size:13px;color:#4ade80;font-weight:700"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14 9V5a3 3 0 0 0-3-3L7 11v11h10.28a2 2 0 0 0 1.97-1.64l1.38-7.6A3 3 0 0 0 17.68 9H14ZM5 11H3a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2V11Z"/></svg><span><?= e($arc1Satisfaction) ?></span></div><?php endif; ?>
        </div>

        <div class="movie-info-block">
            <div class="movie-info-title"><?= $userLang==='fa'?'مشخصات':'Details' ?></div>
            <div class="movie-meta-grid">
                <?php if($arc1Year): ?><div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span class="label">سال:</span><span class="value"><?= e($arc1Year) ?></span></div><?php endif; ?>
                <?php if($arc1ImdbRate): ?><div class="meta-item bm-meta-imdb"><img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy"><span class="label">IMDb:</span><span class="value"><?= number_format((float)$arc1ImdbRate,1) ?>/10</span></div><?php endif; ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><span class="label">نوع:</span><span class="value"><?= $arc1IsSeries ? 'سریال' : 'فیلم' ?></span></div>
                <?php if(!empty($arc1AgeRate)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M8 12h8M12 8v8"/></svg><span class="label">رده سنی:</span><span class="value"><?= e($arc1AgeRate) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Runtime)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><span class="label">زمان:</span><span class="value"><?= e($arc1Runtime) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1ReleaseDate)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M8 2v4M16 2v4M3 10h18"/></svg><span class="label">اکران:</span><span class="value"><?= e($arc1ReleaseDate) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1PublishDate)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><path d="M8 2v4M16 2v4M7 14h5"/></svg><span class="label">انتشار:</span><span class="value"><?= e($arc1PublishDate) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1StatusText)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6L9 17l-5-5"/></svg><span class="label">وضعیت:</span><span class="value"><?= e($arc1StatusText) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1LanguageText)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 5h10M9 3v2c0 5-2 9-5 12"/><path d="M5 9c2 4 5 7 9 8"/><path d="M15 12h5l-2.5 7H15"/></svg><span class="label">زبان:</span><span class="value"><?= e($arc1LanguageText) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Network)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="5" width="20" height="14" rx="3"/><path d="M8 21h8M12 19v2"/></svg><span class="label">شبکه:</span><span class="value"><?= e($arc1Network) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1NextEpisode)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M13 6l6 6-6 6"/></svg><span class="label">قسمت بعدی:</span><span class="value"><?= e($arc1NextEpisode) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1EpisodeNote)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 6h16M4 12h12M4 18h9"/></svg><span class="label">آخرین وضعیت:</span><span class="value"><?= e($arc1EpisodeNote) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Genres)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><span class="label">ژانر:</span><span class="value genre-links"><?php foreach((array)$arc1Genres as $g): ?><a href="index.php?arc=1&genre=<?= urlencode($g) ?>" class="genre-link"><?= e($g) ?></a> <?php endforeach; ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Countries)): ?>
                <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg><span class="label">کشور:</span><span class="value"><?= e(is_array($arc1Countries)?implode('، ',$arc1Countries):$arc1Countries) ?></span></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if($arc1Desc): ?>
        <div class="description bm-readmore-desc" data-collapsed="1">
            <div class="bm-readmore-content"><?= nl2br(e($arc1Desc)) ?></div>
            <button type="button" class="bm-readmore-btn" data-readmore-toggle>ادامه داستان</button>
        </div>
        <?php endif; ?>

        <?php if(!empty($arc1Actors)): ?>
        <section class="bm-arc1-actors-section">
            <div class="bm-arc1-section-head">
                <div class="bm-arc1-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <span>بازیگران</span>
                </div>
                <span class="bm-arc1-section-count"><?= count($arc1Actors) ?> نفر</span>
            </div>
                        <div class="bm-arc1-actors-list" data-actors-list>
                <?php foreach($arc1Actors as $actorIndex => $actor): 
                    $actorName = $actor['name'] ?? '';
                    $actorRole = $actor['role'] ?? '';
                    $actorImg  = trim((string)($actor['image'] ?? ''));
                    $actorHasImage = ($actorImg !== '' && (!function_exists('bm_actor_is_bad_placeholder_image') || !bm_actor_is_bad_placeholder_image($actorImg)));
                    $actorUrl  = trim((string)($actor['bankmovie_url'] ?? ''));
                    if ($actorUrl === '') $actorUrl = 'javascript:void(0)';
                ?>
                <a class="bm-arc1-actor-card <?= $actorHasImage ? 'has-photo' : 'is-text-only' ?> <?= $actorIndex >= 6 ? 'bm-actor-hidden' : '' ?>" href="<?= e($actorUrl) ?>">
                    <?php if($actorHasImage): ?>
                    <span class="bm-arc1-actor-photo-wrap">
                        <img src="<?= e($actorImg) ?>" alt="<?= e($actorName) ?>" class="bm-arc1-actor-photo" loading="lazy" onerror="this.closest('.bm-arc1-actor-card').classList.add('is-text-only');this.closest('.bm-arc1-actor-card').classList.remove('has-photo');this.closest('.bm-arc1-actor-photo-wrap').remove();">
                    </span>
                    <?php else: ?>
                    <span class="bm-arc1-actor-text-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    </span>
                    <?php endif; ?>
                    <span class="bm-arc1-actor-name"><?= e($actorName) ?></span>
                    <?php if($actorRole): ?><span class="bm-arc1-actor-role"><?= e($actorRole) ?></span><?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
            <?php if(count($arc1Actors) > 6): ?>
            <button type="button" class="bm-actors-show-all" data-actors-toggle>مشاهده همه بازیگران</button>
            <?php endif; ?>
        </section>
        <?php endif; ?>

        <!-- دکمه‌های اکشن -->
        <div class="action-buttons" style="display:flex;flex-wrap:wrap;gap:10px;margin-top:16px">
            <?php if($arc1IsSeries && !empty($arc1LatestPlay['url'])): ?>
            <a href="#arc1PlayerWrapper" class="btn btn-primary hero-primary-action bm-safe-series-cta arc1-play-btn"
                data-url="<?= e($arc1LatestPlay['url']) ?>"
                data-season="<?= e($arc1LatestPlay['season']) ?>"
                data-episode="<?= e($arc1LatestPlay['episode']) ?>"
                data-label="<?= e($arc1LatestPlay['label']) ?>"
                data-next-url=""
                data-next-label=""
                data-subtitle-url="<?= e($arc1LatestPlay['subtitle_url'] ?? '') ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                پخش آخرین قسمت
            </a>
            <?php elseif($arc1IsSeries && !empty($arc1SeriesSeasons)): ?>
            <a href="#arc1DownloadSection" class="btn btn-primary hero-primary-action bm-safe-series-cta">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                پخش آخرین قسمت
            </a>
            <?php endif; ?>
            <?php if(!$isArc3 && !empty($arc1TrailerUrl)): ?>
            <a href="#arc1PlayerWrapper" class="btn btn-outline bm-trailer-cta arc1-play-btn"
                data-url="<?= e($arc1TrailerUrl) ?>"
                data-label="تریلر"
                data-direct-player="1"
                data-next-url=""
                data-next-label="">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 9l5 3-5 3V9z"/></svg>
                تماشای تریلر
            </a>
            <?php endif; ?>
            <button type="button" class="btn btn-outline bm-share-trigger bm-share-open">
                اشتراک گذاری
            </button>
            <?php if($currentUser): ?>
            <button class="arc1-wl-btn <?= $inArc1Watch?'active':'' ?>" id="arc1WlBtn"
                data-link="<?= e($arc1SourceUrl) ?>" data-title="<?= e($arc1Title) ?>"
                data-year="<?= e($arc1Year) ?>" data-poster="<?= e($arc1Poster??'') ?>"
                data-rate="<?= e($arc1ImdbRate??0) ?>" data-type="<?= $arc1IsSeries?'series':'movie' ?>"
                data-id="<?= e($arc1WatchId??0) ?>">
                <svg viewBox="0 0 24 24"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" fill="<?= $inArc1Watch?'currentColor':'none' ?>"/></svg>
                <?= $inArc1Watch ? 'نشانه شده' : 'نشانه کردن' ?>
            </button>
            <?php endif; ?>
            <a href="javascript:history.back()" style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:40px;padding:11px 18px;color:rgba(255,255,255,.7);font-size:13px;font-weight:700;text-decoration:none">
                ← برگشت
            </a>
        </div>
    </div>
</div>

<!-- پلیر داخلی آرشیو ۱ — نسخه پیشرفته -->
<link rel="stylesheet" href="/assets/css/movie-inline-5.css?v=dl36-realfix">
<div id="arc1PlayerWrapper" style="display:none;margin-bottom:24px">
    <div class="player-wrapper" id="arc1PlayerInner">
        <video id="arc1VideoEl" class="player-video" playsinline></video>
        <!-- Next Episode Panel (آرشیو ۱) -->
        <div id="arc1NextEpPanel">
            <div class="arc1-next-card">
                <div class="arc1-next-icon"><svg viewBox="0 0 24 24"><polygon points="5 3 15 12 5 21 5 3"/><line x1="19" y1="5" x2="19" y2="19"/></svg></div>
                <div class="arc1-next-info">
                    <div class="arc1-next-label">قسمت بعدی آماده‌ست</div>
                    <div class="arc1-next-title" id="arc1NextTitle">قسمت بعدی</div>
                    <div class="arc1-next-subtitle" id="arc1NextSubtitle"></div>
                </div>
                <div class="arc1-next-ring" id="arc1NextRing">
                    <svg viewBox="0 0 36 36"><circle class="arc1-next-ring-track" cx="18" cy="18" r="15.9"/><circle class="arc1-next-ring-fill" id="arc1NextRingFill" cx="18" cy="18" r="15.9"/></svg>
                    <div class="arc1-next-ring-num" id="arc1NextCount">8</div>
                </div>
                <div class="arc1-next-actions">
                    <button class="arc1-next-go" id="arc1NextGoBtn">برو قسمت بعدی ←</button>
                    <button class="arc1-next-dismiss" id="arc1NextDismiss">نه ممنون</button>
                </div>
            </div>
        </div>

        <div class="subtitle-overlay" id="arc1SubtitleOverlay"></div>
        <div class="brightness-hud" id="arc1BrightnessHud"><div><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></div><div class="hud-value" id="arc1BrightnessHudValue">100%</div></div>
        <div class="player-toast-stack" id="arc1PlayerToastStack" aria-live="polite"></div>
        <div class="player-hud" id="arc1PlayerHud" aria-hidden="true"><div class="player-hud-icon" id="arc1PlayerHudIcon">•</div><div class="player-hud-title" id="arc1PlayerHudTitle"></div><div class="player-hud-value" id="arc1PlayerHudValue"></div><div class="player-hud-bar"><span id="arc1PlayerHudBar"></span></div></div>
        <div class="unlock-overlay" id="arc1LockOverlay"><button type="button" class="unlock-pill" id="arc1UnlockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2.3"/></svg><span><?= $userLang === 'fa' ? 'باز کردن قفل' : 'Unlock controls' ?></span></button></div>
        <div class="buffering" id="arc1Buffering"></div>
        <div class="player-controls" id="arc1Controls">
            <div class="progress-container">
                <span class="progress-time" id="arc1CurrentTime">00:00</span>
                <input type="range" id="arc1ProgressBar" class="progress-bar" min="0" max="100" value="0">
                <span class="progress-time" id="arc1Duration">00:00</span>
            </div>
            <div class="controls-row">
                <div class="controls-left">
                    <button class="ctrl-btn" id="arc1PlayPause"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
                    <button class="ctrl-btn" id="arc1SeekBack"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="10 9 6 12 10 15"/><polyline points="18 9 14 12 18 15"/></svg><span style="font-size:12px;">10</span></button>
                    <button class="ctrl-btn" id="arc1SeekFwd"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="14 9 18 12 14 15"/><polyline points="6 9 10 12 6 15"/></svg><span style="font-size:12px;">10</span></button>
                    <div class="volume-control">
                        <button class="ctrl-btn" id="arc1VolBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg></button>
                        <input type="range" id="arc1VolSlider" class="volume-slider" min="0" max="100" value="100">
                    </div>
                </div>
                <div class="controls-right">
                    <div class="settings-dropdown">
                        <button class="ctrl-btn" id="arc1SettingsBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                        <div class="settings-dropdown-content player-settings-modal" id="arc1SettingsDropdown" dir="<?= e($dir) ?>">
                            <div class="settings-panel settings-main-panel active" data-settings-panel="main">
                                <div class="settings-modal-header">
                                    <div class="settings-modal-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                        <div>
                                            <div><?= $userLang === 'fa' ? 'تنظیمات پخش' : 'Playback settings' ?></div>
                                            <div class="settings-modal-subtitle"><?= $userLang === 'fa' ? 'کیفیت، سرعت، تصویر، زیرنویس و تایمر خواب' : 'Quality, speed, picture, subtitle and sleep timer' ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="arc1OpenQualityPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 13h8M8 9h8"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'انتخاب کیفیت و نوع دوبله/زیرنویس' : 'Choose quality and audio/subtitle type' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentQualityLabel"><?= $userLang === 'fa' ? 'خودکار' : 'Auto' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <button type="button" class="settings-row" id="arc1OpenSpeedPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'مودال اختصاصی قابل اسکرول' : 'Scrollable dedicated panel' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentSpeedLabel">1x</span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="arc1OpenPictureModePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7z"/><path d="M14 15h3"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'عادی، بزرگ، کشیده 16:9 یا کوچک‌تر' : 'Normal, zoom, 16:9 stretch or smaller' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentPictureModeLabel"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>


                                    <button type="button" class="settings-row" id="arc1OpenTheatrePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/><path d="M7 11h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'بزرگ‌تر شدن پلیر و تاریک شدن اطراف' : 'Larger player with darker surroundings' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentTheatreModeLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="arc1OpenBrightnessPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'کنترل نور با منو یا ژست لمسی' : 'Adjust by menu or touch gesture' ?></span></span></span><span class="settings-row-value" id="arc1CurrentBrightnessLabel">100%</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <button type="button" class="settings-row" id="arc1OpenSleepTimerPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'توقف خودکار پخش بعد از زمان انتخابی' : 'Automatically pause playback after a selected time' ?></span></span></span>
                                        <span class="settings-row-value sleep-countdown" id="arc1CurrentSleepTimerLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <div class="settings-divider"></div>
                                    <button type="button" class="settings-row" id="arc1OpenSubtitlePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'آپلود، حذف و سینک با تاخیر دقیق' : 'Upload, remove and sync delay precisely' ?></span></span></span><span class="settings-row-value" id="arc1CurrentSubtitleLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <input type="file" id="arc1SubtitleUpload" accept=".srt,.vtt,.ssa,.ass" style="display:none">

                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="quality">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1QualityModalList"></div>
                            </div>
                            <div class="settings-panel" data-settings-panel="speed">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1SpeedSettingsList">

                                    <div class="speed-touch-card" id="arc1SpeedTouchCard">
                                        <div class="speed-touch-head"><span><?= $userLang === 'fa' ? 'تنظیم لمسی سرعت' : 'Touch speed control' ?></span><strong class="speed-touch-value" id="arc1SpeedTouchValue">1x</strong></div>
                                        <div class="speed-touch-pad" id="arc1SpeedTouchPad"><span><?= $userLang === 'fa' ? 'مثل کنترل آیفونی، اینجا را بالا/پایین بکش' : 'Swipe up/down here like an iOS control' ?></span></div>
                                        <input type="range" class="settings-range speed-range" id="arc1SpeedRange" min="0.25" max="2" step="0.05" value="1">
                                    </div>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.25"><span class="settings-choice-left"><span class="settings-choice-title">0.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.5"><span class="settings-choice-left"><span class="settings-choice-title">0.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.75"><span class="settings-choice-left"><span class="settings-choice-title">0.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt active" data-speed="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">1x</span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.25"><span class="settings-choice-left"><span class="settings-choice-title">1.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.5"><span class="settings-choice-left"><span class="settings-choice-title">1.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.75"><span class="settings-choice-left"><span class="settings-choice-title">1.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="2"><span class="settings-choice-left"><span class="settings-choice-title">2x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="picture">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1PictureModeSettingsList">
                                    <button type="button" class="settings-choice picture-mode-opt active" data-picture-mode="normal"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان حالت فعلی پلیر' : 'Current default player view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="cover"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'بزرگ / پرکننده' : 'Zoom / fill' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر قاب را پر می‌کند؛ ممکن است کمی برش بخورد' : 'Fills the frame; edges may crop slightly' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="stretch"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کشیده 16:9' : '16:9 stretch' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمام قاب 16:9 بدون حاشیه، با کشیدگی احتمالی' : 'No side bars, may stretch the image' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="small"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر کمی کوچک‌تر داخل قاب نمایش داده می‌شود' : 'Shows the video slightly smaller inside the frame' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="subtitle">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="arc1UploadSubtitleOption"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'آپلود زیرنویس' : 'Upload subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'SRT، VTT و ASS ساده' : 'SRT, VTT and basic ASS' ?></span></span></span></button>
                                    <button type="button" class="settings-row" id="arc1ToggleSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'نمایش زیرنویس' : 'Show subtitles' ?></span><span class="settings-row-desc" id="arc1SubtitleVisibilityLabel"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></span></span><span class="settings-row-value" id="arc1SubtitleToggleValue"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></button>
                                    <button type="button" class="settings-row" id="arc1RemoveSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span><span class="settings-row-title"><?= $userLang === 'fa' ? 'حذف زیرنویس' : 'Remove subtitle' ?></span></span></button>
                                        <div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'رنگ زیرنویس' : 'Subtitle color' ?></div>
                                        <div class="subtitle-color-grid">
                                            <button type="button" class="subtitle-color-btn active" data-subtitle-color="#ffffff" title="White"><span class="subtitle-color-dot" style="background:#ffffff"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ffd84d" title="Yellow"><span class="subtitle-color-dot" style="background:#ffd84d"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#36ff9f" title="Green"><span class="subtitle-color-dot" style="background:#36ff9f"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#7dd3fc" title="Blue"><span class="subtitle-color-dot" style="background:#7dd3fc"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ff9ad5" title="Pink"><span class="subtitle-color-dot" style="background:#ff9ad5"></span></button>
                                        </div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'جای زیرنویس روی تصویر' : 'Subtitle position' ?></div>
                                    <div class="settings-range-card subtitle-position-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'جابجایی عمودی' : 'Vertical position' ?></span><strong id="arc1SubtitlePositionLabel">0px</strong></div>
                                        <input type="range" class="settings-range" id="arc1SubtitlePositionRange" min="-80" max="80" step="4" value="0">
                                    </div>
                                    <div class="settings-sync-grid subtitle-position-actions">
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionUpBtn"><?= $userLang === 'fa' ? 'بالاتر' : 'Higher' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionResetBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionDownBtn"><?= $userLang === 'fa' ? 'پایین‌تر' : 'Lower' ?></button>
                                    </div>
                                    <div class="settings-choice-desc subtitle-position-hint"><?= $userLang === 'fa' ? 'اگر جای زیرنویس روی موبایل یا تلویزیون مناسب نبود، همین‌جا بالا/پایینش کن.' : 'Move subtitles up or down if the default position is not comfortable.' ?></div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'سینک و تاخیر زیرنویس' : 'Subtitle sync / delay' ?></div>
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'تاخیر فعلی' : 'Current delay' ?></span><strong id="arc1SubtitleDelayLabel">0.0s</strong></div>
                                        <input type="range" class="settings-range" id="arc1SubtitleDelayRange" min="-5" max="5" step="0.1" value="0">
                                    </div>
                                    <div class="settings-sync-grid">
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleEarlierBtn"><?= $userLang === 'fa' ? 'زودتر -0.1s' : 'Earlier -0.1s' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleResetDelayBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleLaterBtn"><?= $userLang === 'fa' ? 'دیرتر +0.1s' : 'Later +0.1s' ?></button>
                                    </div>
                                    <div class="settings-choice-desc" style="padding:6px 8px 10px;line-height:1.8;"><?= $userLang === 'fa' ? 'گام تنظیم ۰.۱ ثانیه است تا دقیق‌تر از پرش‌های چندثانیه‌ای باشد.' : 'Adjustment step is 0.1s for precise subtitle sync.' ?></div>
                                </div>
                            </div>


                            <div class="settings-panel" data-settings-panel="theatre">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-choice theatre-opt active" data-theatre="off"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'نمای عادی صفحه' : 'Normal page view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice theatre-opt" data-theatre="on"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمرکز روی فیلم بدون تمام‌صفحه' : 'Focus on video without fullscreen' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'این حالت فقط با انتخاب کاربر فعال می‌شود و فول‌اسکرین را جایگزین نمی‌کند.' : 'This mode only turns on when selected and does not replace fullscreen.' ?></div>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="brightness">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'روشنایی تصویر' : 'Brightness' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'میزان نور' : 'Brightness level' ?></span><strong id="arc1BrightnessPercentLabel">100%</strong></div>
                                        <input type="range" class="settings-range" id="arc1BrightnessRange" min="40" max="160" step="5" value="100">
                                    </div>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="0.7"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کم‌نور' : 'Dim' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset active" data-brightness="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان نور اصلی ویدیو' : 'Original video brightness' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.25"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن‌تر' : 'Brighter' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.5"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خیلی روشن' : 'Very bright' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'روی موبایل با کشیدن انگشت بالا/پایین روی نیمه چپ پلیر هم نور تغییر می‌کند.' : 'On mobile, swipe up/down on the left half of the player to adjust brightness.' ?></div>
                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="sleep">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1SleepTimerSettingsList">
                                    <button type="button" class="settings-choice sleep-opt active" data-sleep-minutes="0"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تایمر فعال نیست' : 'No active timer' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="10"><span class="settings-choice-left"><span class="settings-choice-title">10 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="15"><span class="settings-choice-left"><span class="settings-choice-title">15 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="30"><span class="settings-choice-left"><span class="settings-choice-title">30 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="45"><span class="settings-choice-left"><span class="settings-choice-title">45 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="60"><span class="settings-choice-left"><span class="settings-choice-title">60 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="90"><span class="settings-choice-left"><span class="settings-choice-title">90 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="120"><span class="settings-choice-left"><span class="settings-choice-title">120 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="ctrl-btn" id="arc1DlBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
                    <button class="ctrl-btn screen-lock-btn unlocked" id="arc1LockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
                    <button class="ctrl-btn" id="arc1Fullscreen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></button>
                </div>
            </div>
        </div>
    </div>
    <div id="arc1NowPlaying" style="text-align:center;font-size:12px;color:rgba(255,255,255,.45);margin-top:8px;padding:0 4px"></div>
</div>

<!-- ===== لینک‌های دانلود / قسمت‌ها آرشیو ۱ ===== -->
<?php if(!empty($arc1Downloads)): ?>
<?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '' ?>
<div class="download-section" id="arc1DownloadSection">
    <div class="section-title">
        <span style="display:flex;align-items:center;gap:9px">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <?= $arc1IsSeries ? '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/>' : '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>' ?>
            </svg>
            <?= $arc1IsSeries ? 'قسمت‌ها' : 'لینک‌های پخش و دانلود' ?>
        </span>
    </div>

    <?php if($arc1IsSeries): ?>
    <!-- ===== سریال: سوئیچ فصل انیمیشنی ===== -->
    <?php if(count($arc1SeriesSeasons) > 1): ?>
    <div class="arc1-season-tabs" id="arc1SeasonTabs">
        <?php $firstS = array_key_first($arc1SeriesSeasons); ?>
        <?php foreach($arc1SeriesSeasons as $sk => $eps): $sn = ltrim(preg_replace('/[^0-9]/','',$sk),'0')?:'1'; ?>
        <button class="arc1-season-tab <?= $sk===$firstS?'active':'' ?>" data-target="sp-<?= e($sk) ?>" onclick="arc1SwitchSeason(this, 'sp-<?= e($sk) ?>')">
            فصل <?= $sn ?>
            <span class="tab-count">(<?= count($eps) ?>)</span>
        </button>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php foreach($arc1SeriesSeasons as $sk => $eps):
        $sn = ltrim(preg_replace('/[^0-9]/','',$sk),'0')?:'1';
        $isFirst = $sk === array_key_first($arc1SeriesSeasons);
        // ساخت آرایه مسطح قسمت‌ها برای پیدا کردن next
        $allEpKeys = array_keys($eps);
    ?>
    <div id="sp-<?= e($sk) ?>" data-sp="1" <?= $isFirst?'':'style="display:none"' ?>>
        <div class="arc1-season-header">
            <span style="font-size:14px;font-weight:900;color:var(--accent)">فصل <?= $sn ?></span>
            <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($eps) ?> قسمت</span>
        </div>
        <?php foreach($eps as $ek => $links):
            $en = $ek==='full' ? '' : ltrim(preg_replace('/[^0-9]/','',$ek),'0');
            $epLabel = $ek==='full' ? 'فصل کامل' : 'قسمت '.$en;
            $epQualities = array_unique(array_column($links,'quality'));
            // پیدا کردن قسمت بعدی
            $currentEpPos = array_search($ek, $allEpKeys);
            $nextEk = ($currentEpPos !== false && isset($allEpKeys[$currentEpPos+1])) ? $allEpKeys[$currentEpPos+1] : null;
            $nextUrl = $nextEk ? ($eps[$nextEk][0]['url'] ?? '') : '';
            $nextSubtitleUrl = $nextEk ? trim((string)($eps[$nextEk][0]['subtitle_url'] ?? '')) : '';
            $nextEnNum = $nextEk ? (ltrim(preg_replace('/[^0-9]/','',$nextEk),'0') ?: '') : '';
            $nextLabel = $nextEk ? ('فصل '.$sn.' قسمت '.$nextEnNum) : '';
        ?>
        <div class="arc1-ep-card">
            <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                <div class="arc1-ep-num"><?= e($epLabel) ?></div>
                <div style="display:flex;align-items:center;gap:8px">
                    <div class="arc1-ep-badges">
                        <?php foreach($epQualities as $qb): ?><span style="font-size:10px;padding:2px 8px;border-radius:20px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);color:var(--accent);font-weight:700"><?= e($qb) ?></span><?php endforeach; ?>
                    </div>
                    <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                </div>
            </div>
            <div class="arc1-ep-links">
                <?php foreach($links as $lkIdx => $lk): ?>
                <?php $arc1SubHref = !empty($lk['subtitle_url']) ? (string)$lk['subtitle_url'] : ''; ?>
                <div class="arc1-link-row">
                    <div class="arc1-link-meta">
                        <span class="download-type-badge <?= $lk['type']==='dub'?'is-dub':'is-soft' ?>">
                            <?php if($lk['type']==='dub'): ?><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?php endif; ?>
                            <?= $lk['type']==='dub'?'دوبله':e($bmArchiveSubFa) ?>
                        </span>
                        <div>
                            <div style="font-size:13px;font-weight:800;color:#fff"><?= e($lk['quality']) ?></div>
                            <?php if(!empty($lk['size'])): ?><div style="font-size:11px;color:rgba(255,255,255,.45)"><?= e($lk['size']) ?></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="arc1-link-actions">
                        <button class="arc1-play-inline arc1-play-btn"
                            data-url="<?= e($lk['url']) ?>"
                            data-subtitle-url="<?= e($lk['subtitle_url'] ?? '') ?>"
                            data-season="<?= e($sn) ?>"
                            data-episode="<?= e($en) ?>"
                            data-label="<?= e($epLabel) ?>"
                            data-next-url="<?= e($nextUrl) ?>"
                            data-next-label="<?= e($nextLabel) ?>"
                            data-next-subtitle-url="<?= e($nextSubtitleUrl) ?>"
                            data-next-ep="<?= e($nextEnNum) ?>"
                            data-next-season="<?= e($sn) ?>">
                            <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                            پخش
                        </button>
                        <a href="<?= e($lk['url']) ?>" download class="arc1-dl-btn">
                            <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                            دانلود
                        </a>
                        <?php if($arc1SubHref): ?>
                        <a href="<?= e($arc1SubHref) ?>" download class="arc1-sub-dl-btn" title="دانلود زیرنویس فارسی">
                            <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                            زیرنویس
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endforeach; ?>

    <?php else: ?>
    <!-- فیلم: لینک‌های دانلود/پخش داخل آکاردئون؛ سبک‌تر برای موبایل‌های ضعیف -->
    <?php if(!empty($arc1MovieDub)): ?>
    <?php $arc1DubCount = 0; foreach($arc1MovieDub as $arc1DubItems) { $arc1DubCount += is_array($arc1DubItems) ? count($arc1DubItems) : 0; } ?>
    <div class="arc1-ep-card bm-movie-download-accordion">
        <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
            <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg>
                دوبله فارسی
            </div>
            <div style="display:flex;align-items:center;gap:8px">
                <span class="bm-download-group-count"><?= (int)$arc1DubCount ?> لینک</span>
                <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
            </div>
        </div>
        <div class="arc1-ep-links bm-movie-download-panel">
        <?php foreach($arc1MovieDub as $q => $items): foreach($items as $it): ?>
        <?php $arc1SubHref = !empty($it['subtitle_url']) ? (string)$it['subtitle_url'] : ''; ?>
        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default">
            <div class="download-card-left">
                <span class="download-type-badge is-dub"><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?= !empty($it['is_audio']) ? 'صوت دوبله' : 'دوبله' ?></span>
                <div class="link-info"><span class="quality"><?= e($q) ?><?php if(!empty($it['is_audio'])): ?><span class="recommended-badge">فایل صوتی جداگانه</span><?php endif; ?></span><?php if(!empty($it['size'])): ?><span class="size"><?= e($it['size']) ?></span><?php endif; ?></div>
            </div>
            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                <button class="arc1-play-inline arc1-play-btn" data-url="<?= e($it['url']) ?>" data-subtitle-url="<?= e($it['subtitle_url'] ?? '') ?>">
                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <?= !empty($it['is_audio']) ? 'پخش صوت' : 'پخش' ?>
                </button>
                <a href="<?= e($it['url']) ?>" download class="download-icon" style="text-decoration:none">دانلود</a>
                <?php if($arc1SubHref): ?>
                <a href="<?= e($arc1SubHref) ?>" download class="arc1-sub-dl-btn" title="دانلود زیرنویس فارسی">
                    <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                    زیرنویس
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if(!empty($arc1MovieSoft)): ?>
    <?php $arc1SoftCount = 0; foreach($arc1MovieSoft as $arc1SoftItems) { $arc1SoftCount += is_array($arc1SoftItems) ? count($arc1SoftItems) : 0; } ?>
    <div class="arc1-ep-card bm-movie-download-accordion">
        <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
            <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                <?= e($bmArchiveSubFa) ?>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
                <span class="bm-download-group-count"><?= (int)$arc1SoftCount ?> لینک</span>
                <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
            </div>
        </div>
        <div class="arc1-ep-links bm-movie-download-panel">
        <?php foreach($arc1MovieSoft as $q => $items): foreach($items as $it): ?>
        <?php $arc1SubHref = !empty($it['subtitle_url']) ? (string)$it['subtitle_url'] : ''; ?>
        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default">
            <div class="download-card-left">
                <span class="download-type-badge is-soft"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h4M13 15h4"/></svg><?= e($bmArchiveSubFa) ?></span>
                <div class="link-info"><span class="quality"><?= e($q) ?></span><?php if(!empty($it['size'])): ?><span class="size"><?= e($it['size']) ?></span><?php endif; ?></div>
            </div>
            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                <button class="arc1-play-inline arc1-play-btn" data-url="<?= e($it['url']) ?>" data-subtitle-url="<?= e($it['subtitle_url'] ?? '') ?>">
                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    پخش
                </button>
                <a href="<?= e($it['url']) ?>" download class="download-icon" style="text-decoration:none">دانلود</a>
                <?php if($arc1SubHref): ?>
                <a href="<?= e($arc1SubHref) ?>" download class="arc1-sub-dl-btn" title="دانلود زیرنویس فارسی">
                    <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                    زیرنویس
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php endif; ?>





<?php if(!empty($arc1RelatedMovies)): ?>
<section class="bm-arc1-related-section">
    <div class="bm-arc1-related-head">
        <div>
            <h3>فیلم‌ها و سریال‌های مشابه</h3>
            <p>پیشنهادهای مرتبط</p>
        </div>
        <span><?= count($arc1RelatedMovies) ?> پیشنهاد</span>
    </div>
    <div class="bm-arc1-related-scroll">
        <?php foreach($arc1RelatedMovies as $rel): ?>
        <a href="<?= e($rel['bankmovie_url'] ?? $rel['url'] ?? '#') ?>" class="bm-arc1-related-card">
            <span class="bm-arc1-related-poster">
                <?php if(!empty($rel['poster'])): ?>
                <img src="<?= e($rel['poster']) ?>" alt="<?= e($rel['title']) ?>" loading="lazy">
                <?php else: ?>
                <span class="bm-arc1-related-fallback"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></span>
                <?php endif; ?>
                <?php if(!empty($rel['rating'])): ?><span class="bm-arc1-rel-imdb">IMDb <?= e($rel['rating']) ?></span><?php endif; ?>
            </span>
            <span class="bm-arc1-related-title"><?= e($rel['title']) ?></span>
            <span class="bm-arc1-related-meta">
                <?php if(!empty($rel['year'])): ?><b><?= e($rel['year']) ?></b><?php endif; ?>
                <?= ($rel['type'] ?? '') === 'series' ? 'سریال' : 'فیلم' ?>
            </span>
            <?php if(!empty($rel['note'])): ?><span class="bm-arc1-related-note"><?= e($rel['note']) ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- بخش کامنت‌ها برای آرشیو ۱ -->
    <!-- بخش کامنت‌ها -->
    <div class="comments-section">
        <div class="comments-header">
            <div class="section-title" style="margin-bottom:0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $userLang === 'fa' ? 'نظرات کاربران' : 'User Comments' ?>
            </div>
            <div class="comments-stats">
                <div class="comment-stat">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                    <span id="totalCommentsCount"><?= number_format($totalComments) ?></span>
                </div>
                <?php if($avgRating > 0): ?><div class="comment-stat"><?= renderStars($avgRating) ?><span>(<?= number_format($avgRating, 1) ?>)</span></div><?php endif; ?>
            </div>
        </div>
        
        <div class="comment-form">
            <div class="comment-form-header">
                <div class="comment-avatar">
                    <?php if($currentUser && !empty($currentUser['avatar']) && file_exists($currentUser['avatar'])): ?>
                        <img src="<?= htmlspecialchars($currentUser['avatar']) ?>" loading="lazy" decoding="async" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php endif; ?>
                </div>
                <div class="comment-form-info">
                    <span class="comment-username"><?= $currentUser ? htmlspecialchars($currentUser['username']) : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest') ?></span>
                    <span class="comment-guest-note"><?= $userLang === 'fa' ? '(برای امتیاز دادن وارد شوید)' : '(Login to rate)' ?></span>
                </div>
            </div>
            
            <div id="commentMessage" style="display:none;" class="comment-success"></div>
            <div id="commentError" style="display:none;" class="comment-error"></div>
            
    <div class="comment-toolbar" style="display: flex; justify-content: flex-end; margin-bottom: 8px;">
    <label style="display: flex; align-items: center; gap: 6px; font-size:12px;">
        <input type="checkbox" id="fullSpoilerCheckbox"> <?= $userLang === 'fa' ? 'کامنت اسپویل دار شود؟' : 'Whole comment is spoiler' ?>
    </label>
</div>
            
            <div class="star-rating-input"><span><?= $userLang === 'fa' ? 'امتیاز شما:' : 'Your rating:' ?></span><div class="star-rating" id="starRating"><?= renderStarInput($userRating) ?></div></div>
            <textarea id="commentText" class="comment-textarea" rows="3" placeholder="<?= $userLang === 'fa' ? 'نظر خود را بنویسید...' : 'Write your comment...' ?>"></textarea>
            <button id="submitCommentBtn" class="comment-submit"><?= $userLang === 'fa' ? 'ارسال نظر' : 'Submit Comment' ?></button>
        </div>
        
        <div class="comment-list" id="commentList">
            <?php if(count($comments) > 0): ?>
                <?php foreach($comments as $comment): ?>
                    <?= renderCommentHTML($comment, $userLang, $currentUser['id'] ?? 0, $isArc1) ?>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-comments" id="emptyComments"><?= $userLang === 'fa' ? 'هنوز نظری ثبت نشده است. اولین نفری باشید که نظر می‌دهید!' : 'No comments yet. Be the first to comment!' ?></div>
            <?php endif; ?>
        </div>
        
        <?php if($totalCommentPages > 1): ?>
        <div class="load-more-comments" id="loadMoreCommentsBtn">
            <button class="btn-outline" style="width:100%; padding:12px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
                <?= $userLang === 'fa' ? 'بارگذاری بیشتر' : 'Load More' ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
        </div>
        <?php endif; ?>
    </div>


<?php endif; /* arc1Data */ ?>
<?php else: ?>
<!-- ====== آرشیو ۲ — دیتابیس محلی ====== -->
<link rel="stylesheet" href="/assets/css/movie-inline-4.css?v=dl36">
    <div class="movie-detail" style="--bg-image: url('posters/<?= htmlspecialchars($movieData['imdb_code']) ?>.webp');">
        <div class="poster-col">
            <img src="posters/<?= htmlspecialchars($movieData['imdb_code']) ?>.webp" loading="eager" decoding="async" fetchpriority="high" width="240" height="360" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 200 300\'%3E%3Crect width=\'200\' height=\'300\' fill=\'%2318181d\'/%3E%3Ctext x=\'100\' y=\'150\' fill=\'%236e6e7a\' text-anchor=\'middle\' font-size=\'14\'%3ENo Poster%3C/text%3E%3C/svg%3E'" alt="<?= htmlspecialchars($movieData['title']) ?>">
            <?php if($bmArc2HasDubDisplay || $bmArc2HasSoftDisplay): ?>
            <div class="bm-poster-badges" aria-label="ویژگی‌های نسخه">
                <?php if($bmArc2HasDubDisplay): ?>
                <span class="bm-poster-badge bm-badge-dub" title="دوبله فارسی">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a4 4 0 0 0-4 4v6a4 4 0 0 0 8 0V6a4 4 0 0 0-4-4z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3M8 22h8"/></svg>
                    <span>دوبله</span>
                </span>
                <?php endif; ?>
                <?php if($bmArc2HasSoftDisplay): ?>
                <span class="bm-poster-badge bm-badge-cc" title="<?= e($bmArchiveSubFa) ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                    <span><?= e($bmArchiveSubFa) ?></span>
                </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if($isMovie && ($hasDub || $hasSoft)): ?>
            <a href="#playerWrapper" class="bm-poster-play" aria-label="<?= $userLang === 'fa' ? 'پخش آنلاین' : 'Watch Online' ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </a>
            <?php elseif(!$isMovie && !empty($arc2LatestPlay['url'])): ?>
            <button type="button" class="bm-poster-play bm-local-play-choice" aria-label="<?= $userLang === 'fa' ? 'پخش آنلاین' : 'Watch Online' ?>"
                data-url="<?= e($arc2LatestPlay['url']) ?>"
                data-season="<?= e($arc2LatestPlay['season']) ?>"
                data-episode="<?= e($arc2LatestPlay['episode']) ?>"
                data-label="<?= e($arc2LatestPlay['label']) ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </button>
            <?php elseif(!$isMovie): ?>
            <a href="#downloadSection" class="bm-poster-play" aria-label="<?= $userLang === 'fa' ? 'رفتن به باکس دانلود' : 'Go to download box' ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </a>
            <?php endif; ?>
        </div>
        <div class="info-col">
            <h1 class="movie-title-fa"><?= htmlspecialchars($movieData['title_fa'] ?: $movieData['title']) ?></h1>
            <div class="movie-title-en"><?= htmlspecialchars($movieData['title']) ?></div>
            <div class="movie-rating-section">
                <div class="user-rating"><div class="stars"><?= renderStars($avgRating) ?></div><span style="font-size:13px;">(<?= number_format($avgRating, 1) ?>/5 - <?= number_format($totalVotes) ?> <?= $userLang === 'fa' ? 'رای' : 'votes' ?>)</span></div>
                <button class="watchlist-btn <?= $inWatchlist ? 'active' : '' ?>" id="watchlistBtn"><svg width="16" height="16" viewBox="0 0 24 24" fill="<?= $inWatchlist ? 'currentColor' : 'none' ?>" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><?= $userLang === 'fa' ? 'نشانه شده' : 'Watchlist' ?></button>
            </div>
            <div class="movie-info-block">
                <div class="movie-info-title"><?= $userLang === 'fa' ? 'اطلاعات فیلم' : 'Movie Details' ?></div>
                <div class="movie-meta-grid">
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'نوع:' : 'Type:' ?></span> <span class="value"><?= $isMovie ? ($userLang === 'fa' ? 'فیلم سینمایی' : 'Movie') : ($userLang === 'fa' ? 'سریال' : 'Series') ?></span></div>
                    <?php if(!empty($movieData['year'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span class="label"><?= $userLang === 'fa' ? 'سال:' : 'Year:' ?></span><span class="value"><?= htmlspecialchars($movieData['year']) ?></span></div>
                    <?php endif; ?>
                    <?php if(isset($movieData['imdb_rate']) && (float)$movieData['imdb_rate'] > 0): ?>
                    <div class="meta-item bm-meta-imdb"><img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy"><span class="label">IMDb:</span><span class="value"><?= number_format((float)$movieData['imdb_rate'], 1) ?>/10</span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['genres'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><span class="label"><?= $userLang === 'fa' ? 'ژانر:' : 'Genre:' ?></span><span class="value genre-links"><?php $genresArray = explode(', ', $movieData['genres']); foreach($genresArray as $genre) echo '<a href="search.php?genre='.urlencode(trim($genre)).'" class="genre-link">'.htmlspecialchars(trim($genre)).'</a> '; ?></span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['director'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg><span class="label"><?= $userLang === 'fa' ? 'کارگردان:' : 'Director:' ?></span><span class="value"><a href="search.php?director=<?= urlencode($movieData['director']) ?>" class="director-link"><?= htmlspecialchars($movieData['director']) ?></a></span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['country'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg><span class="label"><?= $userLang === 'fa' ? 'کشور:' : 'Country:' ?></span><span class="value"><a href="search.php?country=<?= urlencode($movieData['country']) ?>" class="country-link"><?= htmlspecialchars($movieData['country']) ?></a></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['status'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M12 8v4l3 3"/></svg><span class="label"><?= $userLang === 'fa' ? 'وضعیت:' : 'Status:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['status']) ?></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['rated'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="9" y1="9" x2="15" y2="15"/><line x1="15" y1="9" x2="9" y2="15"/></svg><span class="label"><?= $userLang === 'fa' ? 'رده سنی:' : 'Rated:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['rated']) ?></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['language'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 5h16a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2z"/><path d="M8 10h8M8 14h4"/></svg><span class="label"><?= $userLang === 'fa' ? 'زبان:' : 'Language:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['language']) ?></span></div>
                    <?php endif; ?>
                    <?php if(!$isMovie && $extraInfo && !empty($extraInfo['seasons'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'فصل‌ها:' : 'Seasons:' ?></span><span class="value"><?= $extraInfo['seasons'] ?></span></div>
                    <?php endif; ?>
                    <?php if(!$isMovie && $extraInfo && !empty($extraInfo['episodes'])): ?>
                    <div class="meta-item"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6M9 12h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'قسمت‌ها:' : 'Episodes:' ?></span><span class="value"><?= $extraInfo['episodes'] ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(!empty($movieData['description'])): ?>
            <div class="description bm-readmore-desc" data-collapsed="1">
                <div class="bm-readmore-content"><?= nl2br(htmlspecialchars($movieData['description'])) ?></div>
                <button type="button" class="bm-readmore-btn" data-readmore-toggle><?= $userLang === 'fa' ? 'ادامه داستان' : 'Read more' ?></button>
            </div>
            <?php endif; ?>
            <?php if(!empty($movieData['actors'])): ?>
            <div class="actors-glassmorphism"><div class="actors-header"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $userLang === 'fa' ? 'بازیگران و صداپیشگان' : 'Cast & Voice Actors' ?></span></div><div class="actors-list"><?php $actorsArray = explode(', ', $movieData['actors']); foreach($actorsArray as $actor): $actorTrim = trim($actor); if(!empty($actorTrim)): ?><a href="search.php?actor=<?= urlencode($actorTrim) ?>" class="actor-chip"><?= htmlspecialchars($actorTrim) ?></a><?php endif; endforeach; ?></div></div>
            <?php endif; ?>
            <div class="action-buttons hero-actions">
                <?php if($isMovie && ($hasDub || $hasSoft)): ?>
                <a href="#playerWrapper" class="btn btn-primary hero-primary-action"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><?= $userLang === 'fa' ? 'پخش آنلاین 720p' : 'Watch Online 720p' ?></a>
                <?php elseif(!$isMovie && !empty($arc2LatestPlay['url'])): ?>
                <button type="button" class="btn btn-primary hero-primary-action bm-safe-series-cta bm-local-play-choice" data-url="<?= e($arc2LatestPlay['url']) ?>" data-season="<?= e($arc2LatestPlay['season']) ?>" data-episode="<?= e($arc2LatestPlay['episode']) ?>" data-label="<?= e($arc2LatestPlay['label']) ?>"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><?= $userLang === 'fa' ? 'پخش آخرین قسمت' : 'Play latest episode' ?></button>
                <?php elseif(!$isMovie && !empty($seriesSeasons)): ?>
                <a href="#downloadSection" class="btn btn-primary hero-primary-action bm-safe-series-cta"><svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><?= $userLang === 'fa' ? 'مشاهده قسمت‌ها' : 'View episodes' ?></a>
                <?php endif; ?>
                <button type="button" class="btn btn-outline bm-share-trigger bm-share-open" id="shareBtn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8"/><polyline points="16 6 12 2 8 6"/><line x1="12" y1="2" x2="12" y2="15"/></svg><?= $userLang === 'fa' ? 'اشتراک گذاری' : 'Share' ?></button>
                <button class="btn btn-outline" id="reportBtn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg><?= $userLang === 'fa' ? 'گزارش مشکل' : 'Report' ?></button>
            </div>
        </div>
    </div>

    <?php $bmYkMovie = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('movie_page', 'wide') : ''; ?>
<?= $bmYkMovie !== '' ? $bmYkMovie : (function_exists('bm_render_ad_with_support_card') ? bm_render_ad_with_support_card($pdo, 'movie_page', 'wide', 1, 'movie.php') : bm_render_ad_slot($pdo, 'movie_page', 'wide', 1)) ?>

    <?php if(($isMovie && ($hasDub || $hasSoft)) || (!$isMovie && !empty($arc2LatestPlay['url']))): ?>
    <div class="player-side-actions">

            <button class="player-donate-side" id="playerDonateSideBtn" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><?= $t[$userLang]['donate'] ?></button>
</div>
    <div class="player-wrapper" id="playerWrapper" style="display:none;">
        <video id="videoPlayer" class="player-video" playsinline></video>
        <div class="subtitle-overlay" id="subtitleOverlay"></div>
        <div class="brightness-hud" id="brightnessHud"><div><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></div><div class="hud-value" id="brightnessHudValue">100%</div></div>
        <div class="player-toast-stack" id="playerToastStack" aria-live="polite"></div>
        <div class="player-hud" id="playerHud" aria-hidden="true"><div class="player-hud-icon" id="playerHudIcon">•</div><div class="player-hud-title" id="playerHudTitle"></div><div class="player-hud-value" id="playerHudValue"></div><div class="player-hud-bar"><span id="playerHudBar"></span></div></div>
        <div class="unlock-overlay" id="unlockOverlay"><button type="button" class="unlock-pill" id="unlockOverlayBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2.3"/></svg><span><?= $userLang === 'fa' ? 'باز کردن قفل' : 'Unlock controls' ?></span></button></div>
        <div class="buffering" id="bufferingIndicator"></div>
        <div class="player-controls" id="playerControls">
            <div class="progress-container">
                <span class="progress-time" id="currentTimeDisplay">00:00</span>
                <input type="range" id="progressBar" class="progress-bar" min="0" max="100" value="0">
                <span class="progress-time" id="durationDisplay">00:00</span>
            </div>
            <div class="controls-row">
                <div class="controls-left">
                    <button class="ctrl-btn" id="playPauseBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
                    <button class="ctrl-btn" id="seekBack10Btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="10 9 6 12 10 15"/><polyline points="18 9 14 12 18 15"/></svg><span style="font-size:12px;">10</span></button>
                    <button class="ctrl-btn" id="seekForward10Btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="14 9 18 12 14 15"/><polyline points="6 9 10 12 6 15"/></svg><span style="font-size:12px;">10</span></button>
                    <div class="volume-control">
                        <button class="ctrl-btn" id="volumeBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg></button>
                        <input type="range" id="volumeSlider" class="volume-slider" min="0" max="100" value="100">
                    </div>
                </div>
                <div class="controls-right">
                    <div class="settings-dropdown">
                        <button class="ctrl-btn" id="settingsBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                        <div class="settings-dropdown-content player-settings-modal" id="settingsDropdown" dir="<?= e($dir) ?>">
                            <div class="settings-panel settings-main-panel active" data-settings-panel="main">
                                <div class="settings-modal-header">
                                    <div class="settings-modal-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                        <div>
                                            <div><?= $userLang === 'fa' ? 'تنظیمات پخش' : 'Playback settings' ?></div>
                                            <div class="settings-modal-subtitle"><?= $userLang === 'fa' ? 'کیفیت، سرعت، تصویر، زیرنویس و تایمر خواب' : 'Quality, speed, picture, subtitle and sleep timer' ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="openQualityPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 13h8M8 9h8"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'انتخاب کیفیت و نوع دوبله/زیرنویس' : 'Choose quality and audio/subtitle type' ?></span></span></span>
                                        <span class="settings-row-value" id="currentQualityLabel"><?= $userLang === 'fa' ? 'خودکار' : 'Auto' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <button type="button" class="settings-row" id="openSpeedPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'مودال اختصاصی قابل اسکرول' : 'Scrollable dedicated panel' ?></span></span></span>
                                        <span class="settings-row-value" id="currentSpeedLabel">1x</span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="openPictureModePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7z"/><path d="M14 15h3"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'عادی، بزرگ، کشیده 16:9 یا کوچک‌تر' : 'Normal, zoom, 16:9 stretch or smaller' ?></span></span></span>
                                        <span class="settings-row-value" id="currentPictureModeLabel"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>


                                    <button type="button" class="settings-row" id="openTheatrePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/><path d="M7 11h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'بزرگ‌تر شدن پلیر و تاریک شدن اطراف' : 'Larger player with darker surroundings' ?></span></span></span>
                                        <span class="settings-row-value" id="currentTheatreModeLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="openBrightnessPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'کنترل نور با منو یا ژست لمسی' : 'Adjust by menu or touch gesture' ?></span></span></span><span class="settings-row-value" id="currentBrightnessLabel">100%</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <button type="button" class="settings-row" id="openSleepTimerPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'توقف خودکار پخش بعد از زمان انتخابی' : 'Automatically pause playback after a selected time' ?></span></span></span>
                                        <span class="settings-row-value sleep-countdown" id="currentSleepTimerLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <div class="settings-divider"></div>
                                    <button type="button" class="settings-row" id="openSubtitlePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'آپلود، حذف و سینک با تاخیر دقیق' : 'Upload, remove and sync delay precisely' ?></span></span></span><span class="settings-row-value" id="currentSubtitleLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <input type="file" id="subtitleUpload" accept=".srt,.vtt,.ssa,.ass" style="display:none">

                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="quality">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="qualityModalList"></div>
                            </div>
                            <div class="settings-panel" data-settings-panel="speed">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="speedSettingsList">

                                    <div class="speed-touch-card" id="speedTouchCard">
                                        <div class="speed-touch-head"><span><?= $userLang === 'fa' ? 'تنظیم لمسی سرعت' : 'Touch speed control' ?></span><strong class="speed-touch-value" id="speedTouchValue">1x</strong></div>
                                        <div class="speed-touch-pad" id="speedTouchPad"><span><?= $userLang === 'fa' ? 'مثل کنترل آیفونی، اینجا را بالا/پایین بکش' : 'Swipe up/down here like an iOS control' ?></span></div>
                                        <input type="range" class="settings-range speed-range" id="speedRange" min="0.25" max="2" step="0.05" value="1">
                                    </div>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.25"><span class="settings-choice-left"><span class="settings-choice-title">0.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.5"><span class="settings-choice-left"><span class="settings-choice-title">0.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.75"><span class="settings-choice-left"><span class="settings-choice-title">0.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt active" data-speed="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">1x</span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.25"><span class="settings-choice-left"><span class="settings-choice-title">1.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.5"><span class="settings-choice-left"><span class="settings-choice-title">1.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.75"><span class="settings-choice-left"><span class="settings-choice-title">1.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="2"><span class="settings-choice-left"><span class="settings-choice-title">2x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="picture">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="pictureModeSettingsList">
                                    <button type="button" class="settings-choice picture-mode-opt active" data-picture-mode="normal"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان حالت فعلی پلیر' : 'Current default player view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="cover"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'بزرگ / پرکننده' : 'Zoom / fill' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر قاب را پر می‌کند؛ ممکن است کمی برش بخورد' : 'Fills the frame; edges may crop slightly' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="stretch"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کشیده 16:9' : '16:9 stretch' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمام قاب 16:9 بدون حاشیه، با کشیدگی احتمالی' : 'No side bars, may stretch the image' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="small"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر کمی کوچک‌تر داخل قاب نمایش داده می‌شود' : 'Shows the video slightly smaller inside the frame' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="subtitle">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="uploadSubtitleOption"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'آپلود زیرنویس' : 'Upload subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'SRT، VTT و ASS ساده' : 'SRT, VTT and basic ASS' ?></span></span></span></button>
                                    <button type="button" class="settings-row" id="toggleSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'نمایش زیرنویس' : 'Show subtitles' ?></span><span class="settings-row-desc" id="subtitleVisibilityLabel"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></span></span><span class="settings-row-value" id="subtitleToggleValue"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></button>
                                    <button type="button" class="settings-row" id="removeSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span><span class="settings-row-title"><?= $userLang === 'fa' ? 'حذف زیرنویس' : 'Remove subtitle' ?></span></span></button>
                                        <div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'رنگ زیرنویس' : 'Subtitle color' ?></div>
                                        <div class="subtitle-color-grid">
                                            <button type="button" class="subtitle-color-btn active" data-subtitle-color="#ffffff" title="White"><span class="subtitle-color-dot" style="background:#ffffff"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ffd84d" title="Yellow"><span class="subtitle-color-dot" style="background:#ffd84d"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#36ff9f" title="Green"><span class="subtitle-color-dot" style="background:#36ff9f"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#7dd3fc" title="Blue"><span class="subtitle-color-dot" style="background:#7dd3fc"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ff9ad5" title="Pink"><span class="subtitle-color-dot" style="background:#ff9ad5"></span></button>
                                        </div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'جای زیرنویس روی تصویر' : 'Subtitle position' ?></div>
                                    <div class="settings-range-card subtitle-position-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'جابجایی عمودی' : 'Vertical position' ?></span><strong id="subtitlePositionLabel">0px</strong></div>
                                        <input type="range" class="settings-range" id="subtitlePositionRange" min="-80" max="80" step="4" value="0">
                                    </div>
                                    <div class="settings-sync-grid subtitle-position-actions">
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionUpBtn"><?= $userLang === 'fa' ? 'بالاتر' : 'Higher' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionResetBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionDownBtn"><?= $userLang === 'fa' ? 'پایین‌تر' : 'Lower' ?></button>
                                    </div>
                                    <div class="settings-choice-desc subtitle-position-hint"><?= $userLang === 'fa' ? 'اگر جای زیرنویس روی موبایل یا تلویزیون مناسب نبود، همین‌جا بالا/پایینش کن.' : 'Move subtitles up or down if the default position is not comfortable.' ?></div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'سینک و تاخیر زیرنویس' : 'Subtitle sync / delay' ?></div>
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'تاخیر فعلی' : 'Current delay' ?></span><strong id="subtitleDelayLabel">0.0s</strong></div>
                                        <input type="range" class="settings-range" id="subtitleDelayRange" min="-5" max="5" step="0.1" value="0">
                                    </div>
                                    <div class="settings-sync-grid">
                                        <button type="button" class="settings-sync-btn" id="subtitleEarlierBtn"><?= $userLang === 'fa' ? 'زودتر -0.1s' : 'Earlier -0.1s' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitleResetDelayBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitleLaterBtn"><?= $userLang === 'fa' ? 'دیرتر +0.1s' : 'Later +0.1s' ?></button>
                                    </div>
                                    <div class="settings-choice-desc" style="padding:6px 8px 10px;line-height:1.8;"><?= $userLang === 'fa' ? 'گام تنظیم ۰.۱ ثانیه است تا دقیق‌تر از پرش‌های چندثانیه‌ای باشد.' : 'Adjustment step is 0.1s for precise subtitle sync.' ?></div>
                                </div>
                            </div>


                            <div class="settings-panel" data-settings-panel="theatre">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-choice theatre-opt active" data-theatre="off"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'نمای عادی صفحه' : 'Normal page view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice theatre-opt" data-theatre="on"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمرکز روی فیلم بدون تمام‌صفحه' : 'Focus on video without fullscreen' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'این حالت فقط با انتخاب کاربر فعال می‌شود و فول‌اسکرین را جایگزین نمی‌کند.' : 'This mode only turns on when selected and does not replace fullscreen.' ?></div>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="brightness">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'روشنایی تصویر' : 'Brightness' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'میزان نور' : 'Brightness level' ?></span><strong id="brightnessPercentLabel">100%</strong></div>
                                        <input type="range" class="settings-range" id="brightnessRange" min="40" max="160" step="5" value="100">
                                    </div>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="0.7"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کم‌نور' : 'Dim' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset active" data-brightness="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان نور اصلی ویدیو' : 'Original video brightness' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.25"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن‌تر' : 'Brighter' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.5"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خیلی روشن' : 'Very bright' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'روی موبایل با کشیدن انگشت بالا/پایین روی نیمه چپ پلیر هم نور تغییر می‌کند.' : 'On mobile, swipe up/down on the left half of the player to adjust brightness.' ?></div>
                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="sleep">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="sleepTimerSettingsList">
                                    <button type="button" class="settings-choice sleep-opt active" data-sleep-minutes="0"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تایمر فعال نیست' : 'No active timer' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="10"><span class="settings-choice-left"><span class="settings-choice-title">10 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="15"><span class="settings-choice-left"><span class="settings-choice-title">15 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="30"><span class="settings-choice-left"><span class="settings-choice-title">30 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="45"><span class="settings-choice-left"><span class="settings-choice-title">45 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="60"><span class="settings-choice-left"><span class="settings-choice-title">60 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="90"><span class="settings-choice-left"><span class="settings-choice-title">90 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="120"><span class="settings-choice-left"><span class="settings-choice-title">120 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="ctrl-btn" id="downloadCurrentBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
                    <button class="ctrl-btn screen-lock-btn unlocked" id="screenLockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
                    <button class="ctrl-btn" id="fullscreenBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- جایگاه رسمی یکتانت؛ بدون wrapper، CSS، JavaScript یا حالت شناور -->
    <?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '' ?>

    <!-- بخش دانلود -->
    <div class="download-section" id="downloadSection">
        <div class="section-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
            <?= $userLang === 'fa' ? 'لینک های دانلود' : 'Download Links' ?>
        </div>
        
        <?php if($isMovie): ?>
            <div class="arc1-series-downloads bm-archive2-movie-list">
                <?php if($hasDub): ?>
                <div class="bm-archive2-movie-group">
                    <div class="arc1-season-header">
                        <span style="font-size:14px;font-weight:900;color:var(--accent);display:flex;align-items:center;gap:8px">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg>
                            <?= $userLang === 'fa' ? 'دوبله فارسی' : 'Persian Dubbed' ?>
                        </span>
                        <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($dubLinks) ?> <?= $userLang === 'fa' ? 'کیفیت' : 'qualities' ?></span>
                    </div>
                    <?php foreach($dubLinks as $quality => $items): ?>
                        <?php foreach($items as $idx => $item): ?>
                        <?php if(empty($item['url'])) continue; ?>
                        <div class="arc1-link-row bm-archive2-movie-row">
                            <div class="arc1-link-meta">
                                <span class="download-type-badge is-dub"><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?= $userLang === 'fa' ? 'دوبله' : 'Dubbed' ?></span>
                                <div class="link-info bm-archive2-link-info">
                                    <span class="quality bm-archive2-quality-halo"><?= e($quality) ?></span>
                                    <?php if(!empty($item['size'])): ?>
                                    <span class="size bm-archive2-size-pill"><span class="bm-size-label"><?= $userLang === 'fa' ? 'حجم' : 'Size' ?></span><span class="bm-size-value"><?= e($item['size']) ?></span></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="arc1-link-actions">
                                <button type="button" class="arc1-play-inline bm-local-play-choice" data-url="<?= e($item['url']) ?>" data-label="<?= e($quality . ' · ' . ($userLang === 'fa' ? 'دوبله' : 'Dubbed')) ?>">
                                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                    <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                </button>
                                <a href="<?= e($item['url']) ?>" class="arc1-dl-btn" target="_blank" rel="noopener noreferrer">
                                    <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                    <?= $userLang === 'fa' ? 'دانلود' : 'Download' ?>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if($hasSoft): ?>
                <div class="bm-archive2-movie-group">
                    <div class="arc1-season-header">
                        <span style="font-size:14px;font-weight:900;color:var(--accent);display:flex;align-items:center;gap:8px">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                            <?= $userLang === 'fa' ? e($bmArchiveSubFa) : e($bmArchiveSubEn) ?>
                        </span>
                        <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($softLinks) ?> <?= $userLang === 'fa' ? 'کیفیت' : 'qualities' ?></span>
                    </div>
                    <?php foreach($softLinks as $quality => $items): ?>
                        <?php foreach($items as $idx => $item): ?>
                        <?php if(empty($item['url'])) continue; ?>
                        <div class="arc1-link-row bm-archive2-movie-row">
                            <div class="arc1-link-meta">
                                <span class="download-type-badge is-soft"><?= $userLang === 'fa' ? e($bmArchiveSubFa) : e($bmArchiveSubEn) ?></span>
                                <div class="link-info bm-archive2-link-info">
                                    <span class="quality bm-archive2-quality-halo"><?= e($quality) ?></span>
                                    <?php if(!empty($item['size'])): ?>
                                    <span class="size bm-archive2-size-pill"><span class="bm-size-label"><?= $userLang === 'fa' ? 'حجم' : 'Size' ?></span><span class="bm-size-value"><?= e($item['size']) ?></span></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="arc1-link-actions">
                                <button type="button" class="arc1-play-inline bm-local-play-choice" data-url="<?= e($item['url']) ?>" data-label="<?= e($quality . ' · ' . ($userLang === 'fa' ? $bmArchiveSubFa : $bmArchiveSubEn)) ?>">
                                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                    <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                </button>
                                <a href="<?= e($item['url']) ?>" class="arc1-dl-btn" target="_blank" rel="noopener noreferrer">
                                    <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                    <?= $userLang === 'fa' ? 'دانلود' : 'Download' ?>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if(!$hasDub && !$hasSoft): ?>
                    <div class="empty-state"><?= $userLang === 'fa' ? 'لینکی برای این فیلم ثبت نشده' : 'No links available' ?></div>
                <?php endif; ?>
            </div>
            
        <?php else: ?>
            <div id="seriesSeasonsContainer" class="arc1-series-downloads bm-arc2-series-downloads">
                <?php if(count($seriesSeasons) > 0): ?>
                    <?php if(count($seriesSeasons) > 1): ?>
                    <div class="arc1-season-tabs" id="arc2SeasonTabs">
                        <?php $firstSeasonKey = array_key_first($seriesSeasons); ?>
                        <?php foreach($seriesSeasons as $sk => $links): $snNum = ltrim(preg_replace('/[^0-9]/','',$sk),'0') ?: '1'; ?>
                        <button class="arc1-season-tab <?= $sk===$firstSeasonKey?'active':'' ?>" data-target="arc2-sp-<?= e($sk) ?>" onclick="arc1SwitchSeason(this, 'arc2-sp-<?= e($sk) ?>')">
                            <?= $userLang === 'fa' ? 'فصل ' : 'Season ' ?><?= e($snNum) ?>
                        </button>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <?php foreach($seriesSeasons as $season => $links): ?>
                    <?php
                        $isFirstSeason = $season === array_key_first($seriesSeasons);
                        $snNum = ltrim(preg_replace('/[^0-9]/','',$season),'0') ?: '1';
                        $episodeGroups = [];
                        foreach($links as $link) {
                            $ep = isset($link['episode']) && $link['episode'] !== null && $link['episode'] !== '' ? (int)$link['episode'] : 0;
                            $epKey = $ep > 0 ? ('E' . str_pad((string)$ep, 2, '0', STR_PAD_LEFT)) : 'full';
                            if(!isset($episodeGroups[$epKey])) $episodeGroups[$epKey] = [];
                            $episodeGroups[$epKey][] = $link;
                        }
                        uksort($episodeGroups, function($a, $b) {
                            if($a === 'full') return 1;
                            if($b === 'full') return -1;
                            return intval(preg_replace('/\D+/', '', $a)) - intval(preg_replace('/\D+/', '', $b));
                        });
                        $allEpKeys = array_keys($episodeGroups);
                    ?>
                    <div id="arc2-sp-<?= e($season) ?>" data-sp="1" <?= $isFirstSeason?'':'style="display:none"' ?>>
                        <div class="arc1-season-header">
                            <span style="font-size:14px;font-weight:900;color:var(--accent)"><?= $userLang === 'fa' ? 'فصل ' : 'Season ' ?><?= e($snNum) ?></span>
                            <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($episodeGroups) ?> <?= $userLang === 'fa' ? 'قسمت' : 'episodes' ?></span>
                        </div>
                        <?php foreach($episodeGroups as $episodeKey => $episodeLinks): ?>
                        <?php
                            $en = $episodeKey === 'full' ? '' : (ltrim(preg_replace('/[^0-9]/','',$episodeKey),'0') ?: '');
                            $epLabel = $episodeKey === 'full' ? ($userLang === 'fa' ? 'فصل کامل' : 'Full season') : (($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $en);
                            $epQualities = [];
                            foreach($episodeLinks as $_ql) { $epQualities[] = bmArc2CleanQuality($_ql['quality'] ?? ''); }
                            $epQualities = array_values(array_unique(array_filter($epQualities)));
                            $currentEpPos = array_search($episodeKey, $allEpKeys, true);
                            $nextEk = ($currentEpPos !== false && isset($allEpKeys[$currentEpPos+1])) ? $allEpKeys[$currentEpPos+1] : null;
                            $nextUrl = $nextEk ? ($episodeGroups[$nextEk][0]['url'] ?? '') : '';
                            $nextEnNum = $nextEk ? (ltrim(preg_replace('/[^0-9]/','',$nextEk),'0') ?: '') : '';
                            $nextLabel = $nextEk ? (($userLang === 'fa' ? 'فصل ' : 'Season ') . $snNum . ' — ' . ($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $nextEnNum) : '';
                        ?>
                        <div class="arc1-ep-card bm-arc2-ep-card">
                            <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                                <div class="arc1-ep-num bm-arc2-ep-title-line">
                                    <span><?= e($epLabel) ?></span>
                                </div>
                                <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                            </div>
                            <div class="arc1-ep-links">
                                <?php foreach($episodeLinks as $link): ?>
                                <?php $cleanQuality = bmArc2CleanQuality($link['quality'] ?? ''); ?>
                                <div class="arc1-link-row bm-arc2-link-row">
                                    <div class="arc1-link-meta">
                                        <span class="download-type-badge <?= ($link['type'] ?? '') === 'dub' ? 'is-dub' : 'is-soft' ?>">
                                            <?php if(($link['type'] ?? '') === 'dub'): ?><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?php endif; ?>
                                            <?= ($link['type'] ?? '') === 'dub' ? ($userLang === 'fa' ? 'دوبله' : 'Dubbed') : ($userLang === 'fa' ? e($bmArchiveSubFa) : e($bmArchiveSubEn)) ?>
                                        </span>
                                        <div>
                                            <div style="font-size:13px;font-weight:800;color:#fff"><?= e($cleanQuality) ?></div>
                                        </div>
                                    </div>
                                    <div class="arc1-link-actions">
                                        <button type="button" class="arc1-play-inline bm-local-play-choice"
                                            data-url="<?= e($link['url']) ?>"
                                            data-season="<?= e($snNum) ?>"
                                            data-episode="<?= e($en) ?>"
                                            data-label="<?= e(($userLang === 'fa' ? 'فصل ' : 'Season ') . $snNum . ' — ' . $epLabel . ' — ' . $cleanQuality) ?>"
                                            data-next-url="<?= e($nextUrl) ?>"
                                            data-next-label="<?= e($nextLabel) ?>">
                                            <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                                            <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                        </button>
                                        <a href="<?= e($link['url']) ?>" download class="arc1-dl-btn" target="_blank" rel="noopener noreferrer">
                                            <svg viewBox="0 0 24 24"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                                            <?= $userLang === 'fa' ? 'دانلود' : 'Download' ?>
                                        </a>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state" style="text-align:center; padding:40px;">
                        <svg width="50" height="50" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" style="margin-bottom:15px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                        <h3 style="margin-bottom:10px;"><?= $userLang === 'fa' ? 'لینکی برای این سریال ثبت نشده' : 'No links available' ?></h3>
                        <p style="margin-bottom:20px; color: var(--text-tertiary);"><?= $userLang === 'fa' ? 'اگر بعداً داخل JSON/دیتابیس لینک وارد شود، همینجا بدون نیاز به عضویت نمایش داده می‌شود.' : 'When links are imported, they will appear here without a membership gate.' ?></p>
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- بخش جستجوی زیرنویس -->
    <div class="subkade-box">
        <h4>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <?= $userLang === 'fa' ? 'جستجوی زیرنویس فارسی' : 'Search Persian Subtitle' ?>
        </h4>
        <div class="subkade-input-group">
            <input type="text" id="subkadeInput" placeholder="<?= $userLang === 'fa' ? 'نام فیلم یا سریال...' : 'Movie or series name...' ?>" value="<?= htmlspecialchars($pageTitle) ?>">
            <button id="subkadeBtn" class="btn btn-primary"><?= $userLang === 'fa' ? 'جستجو در ساب‌کده' : 'Search in Subkade' ?></button>
        </div>
        <div id="subkadeMsg" style="font-size: 11px; margin-top: 8px; color: var(--text-tertiary);"></div>
    </div>

    <!-- بخش کامنت‌ها -->
    <div class="comments-section">
        <div class="comments-header">
            <div class="section-title" style="margin-bottom:0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $userLang === 'fa' ? 'نظرات کاربران' : 'User Comments' ?>
            </div>
            <div class="comments-stats">
                <div class="comment-stat">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                    <span id="totalCommentsCount"><?= number_format($totalComments) ?></span>
                </div>
                <?php if($avgRating > 0): ?><div class="comment-stat"><?= renderStars($avgRating) ?><span>(<?= number_format($avgRating, 1) ?>)</span></div><?php endif; ?>
            </div>
        </div>
        
        <div class="comment-form">
            <div class="comment-form-header">
                <div class="comment-avatar">
                    <?php if($currentUser && !empty($currentUser['avatar']) && file_exists($currentUser['avatar'])): ?>
                        <img src="<?= htmlspecialchars($currentUser['avatar']) ?>" loading="lazy" decoding="async" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php endif; ?>
                </div>
                <div class="comment-form-info">
                    <span class="comment-username"><?= $currentUser ? htmlspecialchars($currentUser['username']) : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest') ?></span>
                    <span class="comment-guest-note"><?= $userLang === 'fa' ? '(برای امتیاز دادن وارد شوید)' : '(Login to rate)' ?></span>
                </div>
            </div>
            
            <div id="commentMessage" style="display:none;" class="comment-success"></div>
            <div id="commentError" style="display:none;" class="comment-error"></div>
            
    <div class="comment-toolbar" style="display: flex; justify-content: flex-end; margin-bottom: 8px;">
    <label style="display: flex; align-items: center; gap: 6px; font-size:12px;">
        <input type="checkbox" id="fullSpoilerCheckbox"> <?= $userLang === 'fa' ? 'کامنت اسپویل دار شود؟' : 'Whole comment is spoiler' ?>
    </label>
</div>
            
            <div class="star-rating-input"><span><?= $userLang === 'fa' ? 'امتیاز شما:' : 'Your rating:' ?></span><div class="star-rating" id="starRating"><?= renderStarInput($userRating) ?></div></div>
            <textarea id="commentText" class="comment-textarea" rows="3" placeholder="<?= $userLang === 'fa' ? 'نظر خود را بنویسید...' : 'Write your comment...' ?>"></textarea>
            <button id="submitCommentBtn" class="comment-submit"><?= $userLang === 'fa' ? 'ارسال نظر' : 'Submit Comment' ?></button>
        </div>
        
        <div class="comment-list" id="commentList">
            <?php if(count($comments) > 0): ?>
                <?php foreach($comments as $comment): ?>
                    <?= renderCommentHTML($comment, $userLang, $currentUser['id'] ?? 0) ?>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-comments" id="emptyComments"><?= $userLang === 'fa' ? 'هنوز نظری ثبت نشده است. اولین نفری باشید که نظر می‌دهید!' : 'No comments yet. Be the first to comment!' ?></div>
            <?php endif; ?>
        </div>
        
        <?php if($totalCommentPages > 1): ?>
        <div class="load-more-comments" id="loadMoreCommentsBtn">
            <button class="btn-outline" style="width:100%; padding:12px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
                <?= $userLang === 'fa' ? 'بارگذاری بیشتر' : 'Load More' ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
        </div>
        <?php endif; ?>
    </div>

    <!-- فیلم‌های مشابه -->
    <?php if(count($genreRelatedMovies) > 0): ?>
    <div class="related-section">
        <div class="section-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            <?= $userLang === 'fa' ? 'فیلم‌های مشابه براساس ژانر (تصادفی)' : 'Random Similar by Genre' ?>
        </div>
        <div class="related-scroll" id="genreRelatedContainer">
            <?php foreach($genreRelatedMovies as $related): ?>
            <a href="<?= e(bm_movie_url($related)) ?>" class="related-card">
                <img class="related-poster" src="posters/<?= htmlspecialchars($related['imdb_code']) ?>.webp" loading="lazy" decoding="async" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 150\'%3E%3Crect width=\'100\' height=\'150\' fill=\'%2318181d\'/%3E%3C/svg%3E'">
                <div class="related-info">
                    <div class="related-title-fa"><?= htmlspecialchars($related['title_fa'] ?: $related['title']) ?></div>
                    <div class="related-title-en"><?= htmlspecialchars($related['title']) ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if(count($relatedMovies) > 0): ?>
    <div class="related-section">
        <div class="section-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            <?= $userLang === 'fa' ? 'فیلم‌های هم اسم و مرتبط' : 'Same Name & Related Movies' ?>
        </div>
        <div class="related-scroll" id="relatedContainer">
            <?php foreach($relatedMovies as $related): ?>
            <a href="<?= e(bm_movie_url($related)) ?>" class="related-card">
                <img class="related-poster" src="posters/<?= htmlspecialchars($related['imdb_code']) ?>.webp" loading="lazy" decoding="async" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 150\'%3E%3Crect width=\'100\' height=\'150\' fill=\'%2318181d\'/%3E%3C/svg%3E'">
                <div class="related-info">
                    <div class="related-title-fa"><?= htmlspecialchars($related['title_fa'] ?: $related['title']) ?></div>
                    <div class="related-title-en"><?= htmlspecialchars($related['title']) ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php endif; /* isArc1 / else arc2 */ ?>

<div class="bottom-nav" aria-label="Mobile bottom navigation">
    <a href="index.php" class="nav-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span class="nav-label"><?= $t[$userLang]['home'] ?></span></a>
    <a href="player.php" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span class="nav-label"><?= $t[$userLang]['player'] ?></span></a>
    <a href="<?= $currentUser ? 'profile.php' : 'login.php' ?>" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span class="nav-label"><?= $currentUser ? $t[$userLang]['profile'] : $t[$userLang]['login'] ?></span></a>
</div>

<div id="donateModal" class="modal">
    <div class="modal-content">
        <div style="background: var(--gradient-donate); width: 70px; height: 70px; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center;">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </div>
        <h3 style="margin-bottom:12px;"><?= $userLang === 'fa' ? 'حمایت مالی' : 'Support Us' ?></h3>
        <p style="color: var(--text-secondary); margin-bottom:20px; font-size:13px;"><?= $userLang === 'fa' ? 'تمام خدمات ما رایگان است. اگر دوست دارید از ما حمایت کنید، مبلغی را واریز کنید.' : 'All our services are free. If you would like to support us, please donate.' ?></p>
        <button id="openDonateLink" class="btn btn-primary" style="width:100%; justify-content:center;"><?= $userLang === 'fa' ? 'حمایت مالی' : 'Donate' ?></button>
        <button id="closeDonateModal" style="margin-top:12px; background:none; border:none; color:var(--text-tertiary); cursor:pointer;"><?= $userLang === 'fa' ? 'بستن' : 'Close' ?></button>
    </div>
</div>


<!-- V22: انتخاب نوع پخش -->
<div class="bm-play-choice-overlay" id="bmPlayChoiceModal" aria-hidden="true">
    <div class="bm-play-choice-modal" role="dialog" aria-modal="true" aria-labelledby="bmPlayChoiceTitle">
        <div class="bm-play-choice-head">
            <div class="bm-play-choice-title">
                <span class="bm-play-choice-title-icon">
                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                </span>
                <div>
                    <strong id="bmPlayChoiceTitle">انتخاب روش پخش</strong>
                    <span id="bmPlayChoiceLabel">BankMovie Player</span>
                </div>
            </div>
            <button type="button" class="bm-play-choice-close" data-bm-play-close aria-label="بستن">×</button>
        </div>
        <div class="bm-play-choice-body">
            <button type="button" class="bm-play-option internal" data-bm-play-action="internal">
                <span class="bm-play-option-icon">
                    <svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                </span>
                <span class="bm-play-option-text">
                    <b>پخش با پلیر داخلی</b>
                    <span>پخش مستقیم در پلیر بانک مووی — فقط با مرورگر Chrome</span>
                </span>
            </button>
            <button type="button" class="bm-play-option vlc" data-bm-play-action="vlc">
                <span class="bm-play-option-icon">
                    <svg aria-label="VLC" role="img" viewBox="0 0 512 512">
                        <rect width="512" height="512" rx="15%" fill="#ffffff"/>
                        <g fill="#f7901e">
                            <path d="M437 400l-36-94c-3-10-13-16-23-16H134c-10 0-20 6-23 16l-36 94c-2 3-2 7-2 11 0 16 13 29 29 29h308a29 29 0 0 0 27-40z"/>
                            <path d="M299 109l-15-51c-3-11-13-18-24-18h-8c-11 0-21 7-24 18l-15 51a307 307 0 0 0 86 0zM256 183c-24 0-46-2-64-6l-19 65c20 8 49 13 83 13s63-5 83-13l-20-65c-17 4-39 6-63 6z"/>
                        </g>
                        <g fill="#f2f2f2">
                            <path d="M319 177l-20-68a307 307 0 0 1-86 0l-21 68c18 4 40 6 64 6s46-2 63-6z"/>
                            <path d="M173 242l-18 62c19 14 55 23 101 23s82-9 101-23l-18-62c-20 8-49 13-83 13s-63-5-83-13z"/>
                        </g>
                    </svg>
                </span>
                <span class="bm-play-option-text">
                    <b>پخش با VLC</b>
                    <span>مناسب اندروید و ویندوز — باز کردن لینک مستقیم در VLC</span>
                </span>
            </button>
            <button type="button" class="bm-play-option mx" data-bm-play-action="mx">
                <span class="bm-play-option-icon">
                    <span class="bm-mx-logo">MX</span>
                </span>
                <span class="bm-play-option-text">
                    <b>پخش با MX Player</b>
                    <span>باز کردن لینک مستقیم در MX Player اندروید</span>
                </span>
            </button>
            <button type="button" class="bm-play-option km" data-bm-play-action="km">
                <span class="bm-play-option-icon">
                    <img src="/assets/img/movie-player-option-1.png?v=dl36" alt="KM Player" loading="lazy" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b>پخش با KM Player</b>
                    <span>مناسب ویندوز — باز کردن لینک مستقیم در KMPlayer</span>
                </span>
            </button>
            <button type="button" class="bm-play-option pot" data-bm-play-action="pot">
                <span class="bm-play-option-icon">
                    <img src="/assets/img/movie-player-option-2.png?v=dl36" alt="PotPlayer" loading="lazy" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b>پخش با PotPlayer</b>
                    <span>مناسب ویندوز — باز کردن لینک مستقیم در PotPlayer</span>
                </span>
            </button>
        </div>
        <div class="bm-play-choice-foot">
            <button type="button" class="bm-play-copy-link" data-bm-play-action="copy">کپی لینک مستقیم</button>
        </div>
    </div>
</div>


<style>
.bm-arc2-series-downloads,.bm-archive2-movie-list{display:flex;flex-direction:column;gap:14px}.bm-arc2-series-downloads .arc1-ep-head{min-width:0}.bm-arc2-series-downloads .bm-arc2-ep-title-line{min-width:0;flex:1}.bm-arc2-series-downloads .bm-arc2-ep-title-line>span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bm-arc2-series-downloads .arc1-link-row,.bm-archive2-movie-list .arc1-link-row{align-items:center;min-width:0}.bm-arc2-series-downloads .arc1-link-meta,.bm-archive2-movie-list .arc1-link-meta{min-width:0;flex:1}.bm-archive2-movie-list .arc1-link-meta{gap:12px}.bm-archive2-movie-list .bm-archive2-link-info{display:flex;flex-direction:row;align-items:center;gap:9px;flex-wrap:wrap;min-width:0}.bm-archive2-movie-list .bm-archive2-quality-halo{display:inline-flex;align-items:center;justify-content:center;min-height:30px;padding:5px 14px;border-radius:999px;background:radial-gradient(circle at 35% 20%,rgba(255,255,255,.18),rgba(var(--accent-rgb),.14) 46%,rgba(255,255,255,.045) 100%);border:1px solid rgba(var(--accent-rgb),.34);box-shadow:0 0 0 1px rgba(255,255,255,.035) inset,0 0 20px rgba(var(--accent-rgb),.17);color:#fff;font-size:13px;font-weight:950;line-height:1;white-space:nowrap}.bm-archive2-movie-list .bm-archive2-size-pill{display:inline-flex!important;align-items:center;gap:7px;min-height:28px;padding:4px 10px;border-radius:999px;background:rgba(255,255,255,.065);border:1px solid rgba(255,255,255,.12);color:rgba(255,255,255,.82);font-size:12px;font-weight:850;line-height:1;white-space:nowrap}.bm-archive2-movie-list .bm-size-label{color:rgba(255,255,255,.42);font-size:10px;font-weight:950}.bm-archive2-movie-list .bm-size-value{direction:ltr;unicode-bidi:embed}.bm-archive2-movie-list .recommended-badge{display:none!important}.bm-arc2-series-downloads .arc1-link-actions,.bm-archive2-movie-list .arc1-link-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.bm-arc2-series-downloads .arc1-dl-btn,.bm-arc2-series-downloads .bm-local-play-choice,.bm-archive2-movie-list .arc1-dl-btn,.bm-archive2-movie-list .bm-local-play-choice{display:inline-flex;align-items:center;gap:6px;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:900;text-decoration:none}.bm-arc2-series-downloads .bm-local-play-choice,.bm-archive2-movie-list .bm-local-play-choice{border:0;background:var(--accent);color:#000;cursor:pointer}.bm-arc2-series-downloads .arc1-dl-btn,.bm-archive2-movie-list .arc1-dl-btn{border:1px solid rgba(255,255,255,.12);color:#fff;background:rgba(255,255,255,.05)}.bm-arc2-series-downloads svg,.bm-archive2-movie-list svg{width:14px;height:14px}.bm-archive2-movie-group{display:flex;flex-direction:column;gap:10px}.bm-arc2-ep-title-line{display:flex;align-items:center;gap:8px;flex-wrap:wrap}@media(max-width:640px){.bm-arc2-series-downloads .arc1-ep-head{padding:12px 14px}.bm-arc2-series-downloads .arc1-link-row,.bm-archive2-movie-list .arc1-link-row{align-items:flex-start;flex-direction:column}.bm-arc2-series-downloads .arc1-link-actions,.bm-archive2-movie-list .arc1-link-actions{width:100%}.bm-archive2-movie-list .arc1-link-meta{width:100%;align-items:flex-start;flex-direction:column}.bm-archive2-movie-list .bm-archive2-link-info{width:100%}.bm-archive2-movie-list .bm-archive2-quality-halo,.bm-archive2-movie-list .bm-archive2-size-pill{max-width:100%}.bm-arc2-series-downloads .arc1-dl-btn,.bm-arc2-series-downloads .bm-local-play-choice,.bm-archive2-movie-list .arc1-dl-btn,.bm-archive2-movie-list .bm-local-play-choice{flex:1;justify-content:center}.bm-arc2-series-downloads .download-type-badge{max-width:100%}}
</style>

<script>
<?php $bmArc2EnablePlayerCore = (!$isArc1 && !$isMovie && !empty($arc2LatestPlay['url'])); ?>
window.BM_MOVIE_CONFIG = {
  userLang: <?= json_encode($userLang, JSON_UNESCAPED_UNICODE) ?>,
  userId: <?= json_encode((string)($currentUser['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>,
  currentUserRole: <?= json_encode((string)($currentUser['role'] ?? 'guest'), JSON_UNESCAPED_UNICODE) ?>,
  csrfToken: <?= json_encode($csrfToken, JSON_UNESCAPED_UNICODE) ?>,
  movieId: <?= $isArc1 ? (int)$arc1VirtualMovieId : (int)($movieData['id'] ?? 0) ?>,
  isArchive1: <?= $isArc1 ? 'true' : 'false' ?>,
  imdbCode: <?= json_encode($imdbCode, JSON_UNESCAPED_UNICODE) ?>,
  isMovie: <?= ($isMovie || $bmArc2EnablePlayerCore) ? 'true' : 'false' ?>,
  hasDub: <?= $hasDub ? 'true' : 'false' ?>,
  hasSoft: <?= $hasSoft ? 'true' : 'false' ?>,
  softLinksData: <?= json_encode($softLinks, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
  dubLinksData: <?= json_encode($dubLinks, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
  bestQuality: <?= json_encode($bestQuality, JSON_UNESCAPED_UNICODE) ?>,
  archiveSubFa: <?= json_encode($bmArchiveSubFa, JSON_UNESCAPED_UNICODE) ?>,
  archiveSubEn: <?= json_encode($bmArchiveSubEn, JSON_UNESCAPED_UNICODE) ?>,
  inWatchlist: <?= $inWatchlist ? 'true' : 'false' ?>,
  userRating: <?= (int)$userRating ?>
};
</script>
<script src="/assets/js/movie-bootstrap.js?v=dl36"></script>
<script src="/assets/js/movie-play-choice.js?v=modal-choice-v43-realfix"></script>
<script src="/assets/js/movie-ui.js?v=dl36"></script>
<script src="/assets/js/movie-comments.js?v=dl36"></script>
<script src="/assets/js/movie-subtitles.js?v=dl36-arc2-manual"></script>
<script src="/assets/js/movie-player-core.js?v=dl36-arc2-manual"></script>
<script src="/assets/js/movie-actions.js?v=dl36"></script>
<script src="/assets/js/movie-init-footer.js?v=dl36"></script>
<!-- ========== FOOTER با تایپینگ هنگام اسکرول (فقط یکبار، با ایموجی) ========== -->
<?php $bmYkMovieMobile = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('mobile', 'floating') : ''; ?>
<?= $bmYkMovieMobile !== '' ? $bmYkMovieMobile : bm_render_ad_slot($pdo, 'mobile', 'floating', 1) ?>

<?php require_once __DIR__ . '/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/movie-inline-3.js?v=dl36"></script>

<?php if($isArc1 || (!$isMovie && !$isArc1)): ?>
<script src="/assets/js/movie-inline-4.js?v=dl36"></script>
<?php endif; ?>

<?php if($isArc1 && $arc1Data): ?>
<script src="/assets/js/movie-inline-5.js?v=dl36-realfix-global-scope"></script>
<?php endif; ?>
<?php if($isArc1 && $arc1Data): ?>
<script>
window.BM_ARC1_WATCH_CONFIG = {
  inList: <?= $inArc1Watch ? 'true' : 'false' ?>,
  watchId: <?= (int)($arc1WatchId??0) ?>,
  source: <?= js_json($arc1SourceUrl??'') ?>,
  title: <?= js_json($arc1Title??'') ?>,
  year: <?= js_json($arc1Year??'') ?>,
  poster: <?= js_json($arc1Poster??'') ?>,
  rate: <?= js_json($arc1ImdbRate??0) ?>,
  type: <?= js_json($arc1IsSeries?'series':'movie') ?>
};
</script>
<script src="/assets/js/movie-arc1-watchlist.js?v=dl36"></script>
<?php endif; ?>

<script src="/assets/js/movie-inline-6.js?v=dl36"></script>

<script src="/assets/js/movie-inline-7.js?v=dl36"></script>


<script src="/assets/js/movie-inline-8.js?v=dl36"></script>
<script src="/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>
