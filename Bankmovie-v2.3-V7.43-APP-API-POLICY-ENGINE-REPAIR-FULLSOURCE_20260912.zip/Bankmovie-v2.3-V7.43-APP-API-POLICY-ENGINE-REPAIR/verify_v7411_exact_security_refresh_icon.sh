#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFourthHotfixTag=BANKMOVIE-2.3-V7411-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# V7.41.1 established that the exact film-update drawable is reused by the
# auth challenge refresh control. Later releases may also keep the icon on the
# film status pill; the regression guarantee is reuse, not exclusivity.
test -s "$draw/ic_status_update_arrow.xml"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth"
! grep -Fq 'setImageResource(R.drawable.ic_auth_refresh)' "$auth"

# Keep all V7.41 behavior/regressions intact.
bash verify_v741_auth_player_modal_speed_polish.sh

echo V7411_EXACT_SECURITY_REFRESH_ICON_VERIFY_OK
