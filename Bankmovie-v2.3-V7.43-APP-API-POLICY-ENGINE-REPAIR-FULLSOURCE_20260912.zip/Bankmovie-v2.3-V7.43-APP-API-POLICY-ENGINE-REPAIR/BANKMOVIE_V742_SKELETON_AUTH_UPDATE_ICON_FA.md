BankMovie V7.42 — Skeleton/Auth/Update Icon polish
==================================================

- آیکن اصلی آپدیت در صفحه جزئیات فیلم دوباره دقیقاً مثل قبل برگشت.
- همان Drawable بدون حذف از صفحه فیلم، داخل Refresh تایید امنیتی Login/Register هم استفاده می‌شود.
- موتور Skeleton/Shimmer کل اپ بازطراحی شد: زمینه سینمایی تیره، موج نرم، حرکت پیوسته و ته‌رنگ Accent انتخابی کاربر.
- Placeholderهای پوستر، بازیگر، Box Office، Collection و لیست‌ها از موتور Shimmer جدید استفاده می‌کنند.
- Skeleton صفحه جزئیات موبایل با هندسه UI واقعی فعلی هماهنگ شد: Hero، Play، عنوان، وضعیت، Rating، Actionها و Story.
- چیدمان فیلدهای Login/Register اصلاح شد: اندازه و Alignment آیکن‌های Username/Password/Eye، فاصله‌ها و Focus tint هماهنگ با Accent.
- Drag فرم Login/Register و تایید امنیتی 4 رقمی حفظ شده‌اند.
