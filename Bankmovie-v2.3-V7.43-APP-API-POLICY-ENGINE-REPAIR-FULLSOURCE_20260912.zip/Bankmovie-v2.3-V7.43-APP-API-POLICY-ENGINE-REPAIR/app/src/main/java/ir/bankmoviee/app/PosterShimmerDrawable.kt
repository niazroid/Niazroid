package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator
import java.lang.ref.WeakReference
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.math.roundToInt

/**
 * V7.42 cinematic skeleton shimmer.
 *
 * All skeletons share one animator, so grids stay cheap. The placeholder now
 * carries a very soft trace of the user's accent instead of the old flat gray
 * slab and uses a continuous diagonal light sweep that reads closer to the
 * final glass UI.
 */
class PosterShimmerDrawable(
    private val reducedMotion: Boolean = false,
    private val accentColor: Int = Color.rgb(50, 190, 220)
) : Drawable() {

    companion object {
        private val active = CopyOnWriteArrayList<WeakReference<PosterShimmerDrawable>>()
        private var animator: ValueAnimator? = null

        @Synchronized
        private fun ensureAnimator() {
            if (animator?.isRunning == true) return
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1280L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.RESTART
                interpolator = LinearInterpolator()
                addUpdateListener { va ->
                    val value = va.animatedValue as Float
                    val stale = mutableListOf<WeakReference<PosterShimmerDrawable>>()
                    active.forEach { ref ->
                        val drawable = ref.get()
                        if (drawable == null || !drawable.running) {
                            stale += ref
                        } else {
                            drawable.phase = value
                            drawable.invalidateSelf()
                        }
                    }
                    if (stale.isNotEmpty()) active.removeAll(stale.toSet())
                    if (active.isEmpty()) {
                        va.cancel()
                        animator = null
                    }
                }
                start()
            }
        }

        @Synchronized
        private fun register(drawable: PosterShimmerDrawable) {
            active.removeAll { it.get() == null || it.get() === drawable }
            active += WeakReference(drawable)
            ensureAnimator()
        }

        @Synchronized
        private fun unregister(drawable: PosterShimmerDrawable) {
            active.removeAll { it.get() == null || it.get() === drawable }
            if (active.isEmpty()) {
                animator?.cancel()
                animator = null
            }
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0.08f
    private var drawableAlpha = 255
    private var running = false

    private fun blend(a: Int, b: Int, ratio: Float): Int {
        val r = ratio.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * r).roundToInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * r).roundToInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * r).roundToInt()
        )
    }

    fun start() {
        if (running) return
        running = true
        if (!reducedMotion) register(this) else invalidateSelf()
    }

    fun stop() {
        if (!running) return
        running = false
        unregister(this)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return

        val width = b.width().toFloat().coerceAtLeast(1f)
        val height = b.height().toFloat().coerceAtLeast(1f)
        val deep = Color.rgb(9, 12, 18)
        val baseA = blend(deep, accentColor, 0.075f)
        val baseB = blend(Color.rgb(14, 18, 25), accentColor, 0.13f)

        paint.alpha = drawableAlpha
        paint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(),
            b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(baseA, baseB, baseA),
            floatArrayOf(0f, 0.52f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(b, paint)

        // A soft breathing wash prevents large placeholders (hero/box-office)
        // from looking like dead gray blocks even when reduced motion is on.
        val pulse = if (reducedMotion) 0.42f else (0.30f + 0.22f * kotlin.math.sin((phase * Math.PI * 2.0)).toFloat())
        paint.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(),
            b.left.toFloat(), b.bottom.toFloat(),
            intArrayOf(
                Color.argb((10 + 18 * pulse).roundToInt(), 255, 255, 255),
                Color.TRANSPARENT,
                Color.argb((8 + 16 * pulse).roundToInt(), Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor))
            ),
            floatArrayOf(0f, 0.58f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(b, paint)

        if (!reducedMotion) {
            val band = width * 0.42f
            val travel = width + band * 2f
            val centerX = b.left - band + travel * phase
            paint.shader = LinearGradient(
                centerX - band,
                b.top.toFloat(),
                centerX + band,
                b.bottom.toFloat(),
                intArrayOf(
                    Color.TRANSPARENT,
                    Color.argb(20, 255, 255, 255),
                    Color.argb(62, 255, 255, 255),
                    Color.argb(28, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)),
                    Color.TRANSPARENT
                ),
                floatArrayOf(0f, 0.34f, 0.5f, 0.64f, 1f),
                Shader.TileMode.CLAMP
            )
            canvas.drawRect(b, paint)
        }

        paint.shader = null
    }

    override fun setAlpha(alpha: Int) {
        drawableAlpha = alpha.coerceIn(0, 255)
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
