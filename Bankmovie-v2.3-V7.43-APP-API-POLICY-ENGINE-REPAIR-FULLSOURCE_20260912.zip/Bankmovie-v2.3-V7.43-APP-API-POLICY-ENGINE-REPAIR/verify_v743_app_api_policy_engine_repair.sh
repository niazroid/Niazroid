#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
account='app/src/main/java/ir/bankmoviee/app/AccountApi.kt'
policy='server-required/includes/app_archive_policy.php'
app_config='server-required/app_config.php'
app_api='server-required/app_api.php'
api4='server-required/api4.php'
api6='server-required/api6.php'
arc1='server-required/archive1_live.php'
admin='server-required/bm_admin.php'

for f in "$main" "$account" "$policy" "$app_config" "$app_api" "$api4" "$api6" "$arc1" "$admin"; do
  test -s "$f" || { echo "missing: $f" >&2; exit 1; }
done

grep -Fq 'sourceMainUpdateTwentySixthHotfixTag=BANKMOVIE-2.3-V743-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Single canonical Android control plane.
grep -Fq 'private val canonicalAppDomain = "https://bankmovie.top"' "$main"
grep -Fq 'private fun appConfigCandidates(): List<String> = listOf(appConfigUrl)' "$main"
grep -Fq 'apiBase = "$canonicalAppDomain/app_api.php"' "$main"
grep -Fq 'archive1LiveApiBase = "$canonicalAppDomain/archive1_live.php"' "$main"
grep -Fq 'archive3ApiBase = "$canonicalAppDomain/api6.php"' "$main"
grep -Fq 'archive4SiteApiBase = "$canonicalAppDomain/api4.php"' "$main"
grep -Fq 'val canonical = "https://bankmovie.top/app_user_api.php"' "$account"
grep -Fq "\$contentDomain = 'https://bankmovie.top';" "$app_config"
grep -Fq "'config_urls' =" "$app_config" || grep -Fq "\$default['config_urls'] = [\$contentDomain . '/app_config.php'];" "$app_config"

# Fresh V7.43 config is authoritative and old policy cache is not restored.
grep -Fq 'cached_remote_config_v743' "$main"
grep -Fq 'last_remote_config_revision_v743' "$main"
grep -Fq '.remove("cached_remote_config_v5")' "$main"
grep -Fq '.remove("last_remote_config_revision_v736")' "$main"

# Android-specific archive policy is distinct from website blocked-item policy.
grep -Fq 'Android-only archive policy engine.' "$policy"
grep -Fq 'bm_app_archive_policy_row' "$policy"
grep -Fq 'bm_app_archive_state_payload' "$policy"
grep -Fq 'bm_app_archive_section_state_payload' "$policy"
grep -Fq 'bm_app_archive_apply_payload_policy' "$policy"
grep -Fq 'Only remove media URLs when BOTH capabilities' "$policy"

# Policy is checked before expensive/upstream adapters, so admin states cannot become generic load failures.
grep -Fq 'V7.43 policy short-circuit' "$app_api"
grep -Fq 'bm_app_archive_state_payload($earlyArchiveId, $earlyViewer)' "$app_api"
grep -Fq 'bm_app_archive_section_state_payload($earlyArchiveId, $earlyPolicySection, $earlyViewer)' "$app_api"
grep -Fq 'App-control states are business policy, not transport errors.' "$app_api"
grep -Fq 'bm_dl_wrap_payload($data, false, $managedArchiveId, false)' "$app_api"

# Archive-specific adapters are wired to the same Android policy engine.
grep -Fq "bm_app_archive_apply_payload_policy('archive4'" "$api4"
grep -Fq "bm_app_archive_apply_payload_policy('archive3'" "$api6"
grep -Fq "bm_app_archive_apply_payload_policy('archive1'" "$arc1"

# BM Admin persists every archive's state, feature scopes, section policy and monotonic revision.
grep -Fq "'home_section_policy'=>\$homeSectionPolicy" "$admin"
grep -Fq "'config_revision' => (int)floor(microtime(true) * 1000)" "$admin"
for n in 1 2 3 4; do
  grep -Fq "'archive${n}'=>['state'=>\$archiveModes[$n]" "$admin"
done
grep -Fq "\$field = 'archive' . \$archiveNumber . '_' . \$featureKey . '_scope';" "$admin"
grep -Fq 'name="archive<?= (int)$bmArchiveNumber ?>_watch_party_scope"' "$admin"
grep -Fq 'name="archive<?= (int)$bmArchiveNumber ?>_internal_player_scope"' "$admin"
grep -Fq 'name="archive<?= (int)$bmArchiveNumber ?>_external_player_scope"' "$admin"
grep -Fq 'name="archive<?= (int)$bmArchiveNumber ?>_all_players_scope"' "$admin"

# Server syntax checks.
for f in "$policy" "$app_config" "$app_api" "$api4" "$api6" "$arc1" "$admin" server-required/app_user_api.php; do
  php -l "$f" >/dev/null
done

# Behavioral policy test. It intentionally creates a temporary runtime config
# inside the extracted source, then removes/restores it on exit.
config='server-required/bankmovie_remote_config.json'
backup=''
if [[ -e "$config" ]]; then
  backup="${config}.v743-verifier-backup"
  cp -f "$config" "$backup"
fi
cleanup() {
  rm -f "$config"
  if [[ -n "$backup" && -e "$backup" ]]; then mv -f "$backup" "$config"; fi
}
trap cleanup EXIT
cat > "$config" <<'JSON'
{
  "features": {"archives": {}, "watch_party_scope":"vip", "internal_player_scope":"public", "external_player_scope":"public", "all_players_scope":"public"},
  "app_archive_policy": {
    "archive1": {"enabled": false, "hidden": true, "access_scope":"public", "download_access_scope":"public", "stream_access_scope":"public", "disabled_message":"ARCHIVE1-HIDDEN"},
    "archive2": {"enabled": false, "hidden": false, "access_scope":"public", "download_access_scope":"public", "stream_access_scope":"public", "disabled_message":"ARCHIVE2-DISABLED"},
    "archive3": {"enabled": true, "hidden": false, "access_scope":"public", "download_access_scope":"public", "stream_access_scope":"vip", "disabled_message":"ARCHIVE3"},
    "archive4": {"enabled": true, "hidden": false, "access_scope":"public", "download_access_scope":"vip", "stream_access_scope":"public", "disabled_message":"ARCHIVE4"}
  },
  "home": {
    "archive3_sections":["new_movies"],
    "archive4_sections":["new_movies"]
  },
  "home_section_policy": {
    "archive3": {
      "new_movies":{"enabled":true,"access_scope":"public"},
      "new_series":{"enabled":false,"access_scope":"public"}
    }
  }
}
JSON
php -d display_errors=1 <<'PHP'
<?php
require 'server-required/includes/app_archive_policy.php';
function v743_assert($cond, $msg) { if (!$cond) { fwrite(STDERR, "V743 ASSERT FAILED: $msg\n"); exit(11); } }

$h = bm_app_archive_state_payload('archive1', null);
v743_assert(($h['status'] ?? '') === 'hidden', 'archive1 hidden state');
v743_assert(($h['message'] ?? '') === 'ARCHIVE1-HIDDEN', 'archive1 admin message');
$d = bm_app_archive_state_payload('archive2', null);
v743_assert(($d['status'] ?? '') === 'disabled', 'archive2 disabled state');
v743_assert(($d['message'] ?? '') === 'ARCHIVE2-DISABLED', 'archive2 admin message');

$shared = 'https://cdn.example.test/movie.mp4';
$p3 = bm_app_archive_apply_payload_policy('archive3', [
  'status'=>'success',
  'item'=>['url'=>$shared,'download_url'=>$shared]
], null);
v743_assert(($p3['item']['download_url'] ?? '') === $shared, 'public download URL must survive stream VIP lock');
v743_assert(empty($p3['downloads_locked']), 'public download must not be locked');
v743_assert(!empty($p3['stream_locked']), 'VIP stream must be locked for guest');
v743_assert(($p3['stream_gate'] ?? '') === 'vip', 'stream gate must be VIP');

$p4 = bm_app_archive_apply_payload_policy('archive4', [
  'status'=>'success',
  'item'=>['url'=>$shared,'download_url'=>$shared]
], null);
v743_assert(($p4['item']['url'] ?? '') === $shared, 'public stream URL must survive download VIP lock');
v743_assert(!empty($p4['downloads_locked']), 'VIP download must be locked for guest');
v743_assert(empty($p4['stream_locked']), 'public stream must not be locked');
v743_assert(($p4['download_gate'] ?? '') === 'vip', 'download gate must be VIP');

$s1 = bm_app_archive_section_policy('archive3', 'new_movies');
v743_assert(!empty($s1['enabled']), 'enabled section must remain enabled');
$s2 = bm_app_archive_section_state_payload('archive3', 'new_series', null);
v743_assert(($s2['status'] ?? '') === 'disabled', 'disabled section must return structured disabled state');
v743_assert(!empty($s2['section_disabled']), 'disabled section flag');

echo "V743_POLICY_BEHAVIOR_OK\n";
PHP

echo V743_APP_API_POLICY_ENGINE_REPAIR_VERIFY_OK
