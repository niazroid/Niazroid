#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
shimmer='app/src/main/java/ir/bankmoviee/app/PosterShimmerDrawable.kt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFifthHotfixTag=BANKMOVIE-2.3-V742-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Same original update icon must exist in both surfaces.
test -s "$draw/ic_status_update_arrow.xml"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth"
grep -Fq 'V7.42: keep the original update glyph on the film-status pill AND reuse' "$main"
# More than one MainActivity use confirms film-status + existing update surfaces.
[[ "$(grep -Fc 'setImageResource(R.drawable.ic_status_update_arrow)' "$main")" -ge 2 ]]

# New skeleton engine is themed and shared.
grep -Fq 'V7.42 cinematic skeleton shimmer.' "$shimmer"
grep -Fq 'private val accentColor: Int' "$shimmer"
grep -Fq 'repeatMode = ValueAnimator.RESTART' "$shimmer"
grep -Fq 'PosterShimmerDrawable(lowEndDevice, UiPreferences.palette(this@MainActivity).primary)' "$main"
grep -Fq 'V7.42 mobile skeleton mirrors the current detail screen' "$main"

# Auth fields are visually aligned and focus-tinted.
grep -Fq 'val leadingIcon = ImageView(this).apply' "$auth"
grep -Fq 'leadingIcon.setColorFilter(if (focused) accent else idleIcon)' "$auth"
grep -Fq 'trailingEye?.setColorFilter(if (focused)' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"

# Keep immediate player sheet and prior security flow intact.
bash verify_v7411_exact_security_refresh_icon.sh
bash verify_v740_player_auth_notification_polish.sh
bash verify_v739_website_auth_security_update.sh

echo V742_SKELETON_AUTH_UPDATE_ICON_VERIFY_OK
