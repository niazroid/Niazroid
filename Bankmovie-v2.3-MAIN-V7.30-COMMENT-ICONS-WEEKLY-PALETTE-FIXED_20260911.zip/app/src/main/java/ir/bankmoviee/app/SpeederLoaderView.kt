package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.floor

/**
 * Native Android recreation of the supplied Uiverse "speeder" loader.
 * Geometry/timings mirror the CSS reference, while the ink is light so the
 * animation remains visible on Bankmovie's dark splash background.
 */
class SpeederLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var clock = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isInEditMode && animator?.isRunning != true) {
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 4000L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    clock = it.animatedFraction
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        // Long fazers: the supplied CSS runs four independent horizontal bands.
        val lineW = width * .20f
        val bands = floatArrayOf(.20f, .40f, .60f, .80f)
        val durations = floatArrayOf(.60f, .80f, .60f, .50f)
        val delays = floatArrayOf(-5f, -1f, 0f, -3f)
        val elapsed = clock * 4f
        bands.forEachIndexed { index, yFrac ->
            val phase = positiveModulo((elapsed + delays[index]) / durations[index], 1f)
            val startX = width * 2f
            val endX = if (index < 2) -width * 2f else -width.toFloat()
            val x = startX + (endX - startX) * phase
            strokePaint.strokeWidth = (2f * d).coerceAtLeast(2f)
            strokePaint.alpha = ((1f - phase) * 220f).toInt().coerceIn(0, 220)
            canvas.drawLine(x, height * yFrac, x + lineW, height * yFrac, strokePaint)
        }
        strokePaint.alpha = 255

        // CSS speeder jitter keyframes, sampled in ten equal steps.
        val bodyPhase = positiveModulo(elapsed / .40f, 1f)
        val key = floor(bodyPhase * 10f).toInt().coerceIn(0, 9)
        val dx = floatArrayOf(2f, -1f, -2f, 1f, 1f, -1f, -1f, 3f, -2f, 2f)[key] * d
        val dy = floatArrayOf(1f, -3f, 0f, 2f, -1f, 3f, 1f, 1f, -1f, 1f)[key] * d
        val rot = floatArrayOf(0f, -1f, 1f, 0f, 1f, -1f, 0f, -1f, 1f, 0f)[key]

        val scale = (width.coerceAtMost((220f * d).toInt()) / (220f * d)).coerceAtMost(1f)
        val cx = width / 2f
        val cy = height / 2f
        canvas.save()
        canvas.translate(cx + dx, cy + dy)
        canvas.rotate(rot)
        canvas.scale(scale, scale)
        canvas.translate(-50f * d, -4f * d)

        // Top rounded bar (.loader > span).
        paint.alpha = 255
        canvas.drawRoundRect(RectF(60f*d, -19f*d, 95f*d, -14f*d), 2f*d, 2f*d, paint)

        // Four tiny fazer streaks behind the bar.
        val fazerDur = floatArrayOf(.20f, .40f, .40f, 1.0f)
        val fazerDelay = floatArrayOf(0f, 0f, -1f, -1f)
        val fazerTravel = floatArrayOf(80f, 100f, 50f, 150f)
        val y = floatArrayOf(-19f, -16f, -18f, -15f)
        for (i in 0..3) {
            val p = positiveModulo((elapsed + fazerDelay[i]) / fazerDur[i], 1f)
            val left = 60f*d - fazerTravel[i]*d*p
            paint.alpha = ((1f-p)*235f).toInt().coerceIn(0,235)
            canvas.drawRect(left, y[i]*d, left + 30f*d, y[i]*d + 1.2f*d, paint)
        }
        paint.alpha = 255

        // Base triangular body from the CSS border-right triangle.
        val body = Path().apply {
            moveTo(0f, 0f)
            lineTo(100f*d, -6f*d)
            lineTo(100f*d, 6f*d)
            close()
        }
        canvas.drawPath(body, paint)

        // Wheel/head circle and upper wedge.
        canvas.drawCircle(110f*d, -5f*d, 11f*d, paint)
        val wedge = Path().apply {
            moveTo(45f*d, -16f*d)
            lineTo(100f*d, -16f*d)
            lineTo(100f*d, 0f)
            close()
        }
        canvas.drawPath(wedge, paint)

        // Face/helmet rotated -40deg with the small lower cheek block.
        canvas.save()
        canvas.rotate(-40f, 118f*d, -9f*d)
        canvas.drawRoundRect(RectF(108f*d, -15f*d, 128f*d, -3f*d), 6f*d, 6f*d, paint)
        canvas.restore()
        canvas.save()
        canvas.rotate(0f, 0f, 0f)
        canvas.drawRoundRect(RectF(116f*d, -2f*d, 128f*d, 10f*d), 2f*d, 2f*d, paint)
        canvas.restore()

        canvas.restore()
    }

    private fun positiveModulo(value: Float, mod: Float): Float {
        val r = value % mod
        return if (r < 0f) r + mod else r
    }
}
