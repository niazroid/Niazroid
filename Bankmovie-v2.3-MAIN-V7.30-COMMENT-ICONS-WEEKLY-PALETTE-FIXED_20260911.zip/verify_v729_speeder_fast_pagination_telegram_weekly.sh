#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
loader='app/src/main/java/ir/bankmoviee/app/SpeederLoaderView.kt'

[[ -s "$main" && -s "$loader" ]]

grep -Fq 'sourceMainUpdateTenthHotfixTag=BANKMOVIE-2.3-V729-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Splash uses the requested speeder, not the old tri-ring.
grep -Fq 'loading.addView(SpeederLoaderView(this@MainActivity)' "$main"
grep -Fq 'class SpeederLoaderView' "$loader"
grep -Fq 'duration = 4000L' "$loader"
grep -Fq 'val durations = floatArrayOf(.60f, .80f, .60f, .50f)' "$loader"
grep -Fq 'val fazerDur = floatArrayOf(.20f, .40f, .40f, 1.0f)' "$loader"

# Restore the proven fast text pagination control. The custom always-spinning
# LoadMoreLoaderButtonView may remain in source history but must not be used.
grep -Fq 'private fun moreButton(textValue: String, click: () -> Unit): TextView' "$main"
grep -Fq 'return TextView(this).apply {' "$main"
! grep -Fq 'return LoadMoreLoaderButtonView(this).apply {' "$main"
grep -Fq 'tag = "bm_comments_more_v727"' "$main"
grep -Fq 'commentActionButton(t("ادامه دیدگاه‌ها", "Load more comments"))' "$main"

# Telegram mark keeps its native round aspect ratio.
grep -Fq 'setImageResource(R.drawable.ic_telegram)' "$main"
grep -Fq 'V7.29: use the real round Telegram mark at its native aspect ratio.' "$main"

# Mobile weekly is back to two columns; TV branch/function is still present.
grep -Fq 'private fun addWeeklyScheduleSectionMobileV728(' "$main"
grep -Fq 'columnCount = 2' "$main"
grep -Fq 'V7.29: restore the proven compact two-column weekly grid on phones.' "$main"
grep -Fq 'val cell = weeklyScheduleCompactCell(item)' "$main"
grep -Fq 'if (!tv) {' "$main"
grep -Fq 'tvHomeWeeklyFocusRegistration = HomeTvWeeklyFocusRegistration' "$main"

# V7.28.2 compile hotfix and no-Cast/player regressions remain.
grep -Fq 'val commentsPayload: JSONObject = result.json ?: run {' "$main"
grep -Fq 'val mobileCommentsPayload: JSONObject = result.json ?: run {' "$main"
grep -Fq 'PLAYER_UTILITY_ICON_DP = 24' "$player"
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$player"

for v in \
  verify_v722_cast_removed_player_retained.sh \
  verify_v723_player_last_frame_hold.sh \
  verify_v724_search_scroll_svg_refresh.sh \
  verify_v726_mobile_nav_player_polish.sh \
  verify_tv_focus_v719_history_watchlist_compact_bootstrap.sh; do
  if [[ -s "$v" ]]; then bash "$v" >/dev/null; fi
done

echo V729_SPEEDER_FAST_PAGINATION_TELEGRAM_WEEKLY_OK
