#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
draw='app/src/main/res/drawable'

[[ -s "$main" ]]
grep -Fq 'sourceMainUpdateEleventhHotfixTag=BANKMOVIE-2.3-V730-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

# V7.29 baseline must remain intact.
bash verify_v729_speeder_fast_pagination_telegram_weekly.sh >/dev/null

# Comment SVG set.
for f in \
  ic_comment_like.xml \
  ic_comment_dislike.xml \
  ic_comment_reply.xml \
  ic_comment_pin.xml \
  ic_comment_delete.xml; do
  test -s "$draw/$f"
done

grep -Fq 'R.drawable.ic_comment_like' "$main"
grep -Fq 'R.drawable.ic_comment_dislike' "$main"
grep -Fq 'R.drawable.ic_comment_reply' "$main"
grep -Fq 'R.drawable.ic_comment_pin' "$main"
grep -Fq 'R.drawable.ic_comment_delete' "$main"
grep -Fq 'preserveIconColors: Boolean = false' "$main"
grep -Fq 'preserveIconColors = true' "$main"
grep -Fq 'setIcon(R.drawable.ic_comment_pin)' "$main"
grep -Fq 'setIcon(R.drawable.ic_comment_delete)' "$main"

# Weekly mobile follows the app palette and keeps V7.29 two-column layout.
grep -Fq 'val accent = p.primary' "$main"
grep -Fq 'background = rounded(p.panel, dp(24), p.stroke)' "$main"
grep -Fq 'intArrayOf(p.primary2, p.primary)' "$main"
grep -Fq 'else rounded(p.panel2,dp(18),p.stroke)' "$main"
grep -Fq 'background = rounded(palette.card, dp(15), palette.stroke)' "$main"
grep -Fq 'columnCount = 2' "$main"
grep -Fq 'V7.29: restore the proven compact two-column weekly grid on phones.' "$main"

python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET

root=Path('app/src/main/res/drawable')
for name in (
    'ic_comment_like.xml','ic_comment_dislike.xml','ic_comment_reply.xml',
    'ic_comment_pin.xml','ic_comment_delete.xml'
):
    ET.parse(root/name)

s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
a=s.index('private fun addWeeklyScheduleSectionMobileV728(')
b=s.index('private fun addWeeklyScheduleSection(', a)
chunk=s[a:b]
# These V7.28 hard-coded blue-shell colors must no longer drive the mobile Weekly section.
assert 'Color.rgb(8, 17, 31)' not in chunk
assert 'Color.rgb(28, 55, 91)' not in chunk
assert 'Color.rgb(24,154,255)' not in chunk
assert 'Color.rgb(10,99,236)' not in chunk
assert 'p.primary' in chunk and 'p.panel' in chunk and 'p.stroke' in chunk
print('V730_XML_WEEKLY_PALETTE_OK')
PY

echo V730_COMMENT_ICONS_WEEKLY_PALETTE_OK
