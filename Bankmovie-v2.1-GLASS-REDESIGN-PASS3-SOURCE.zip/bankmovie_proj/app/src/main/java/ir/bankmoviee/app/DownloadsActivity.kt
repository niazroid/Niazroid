package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.content.Intent
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.text.TextUtils
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.max

class DownloadsActivity : Activity() {
    companion object {
        private const val FILTER_ALL = "all"
        private const val FILTER_ACTIVE = "active"
        private const val FILTER_COMPLETED = "completed"
        private const val FILTER_FAILED = "failed"
    }

    private data class CardRefs(
        val progress: ProgressBar,
        val status: TextView,
        val bytes: TextView,
        val remaining: TextView,
        val fileInfo: TextView
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var downloadsBox: LinearLayout
    private lateinit var allTab: TextView
    private lateinit var activeTab: TextView
    private lateinit var completedTab: TextView
    private lateinit var failedTab: TextView
    private var scheduleStatusText: TextView? = null
    private var selectedFilter = FILTER_ALL
    private var lastStructure = ""
    private val cardRefs = linkedMapOf<String, CardRefs>()
    private val folderRequestCode = 19082
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val posterCache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private val refresh = object : Runnable {
        override fun run() {
            refreshDownloads(false)
            handler.postDelayed(this, 850L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val palette = UiPreferences.palette(this)
        window.statusBarColor = palette.background
        window.navigationBarColor = palette.background
        buildShell()
        refreshDownloads(true)
    }

    override fun onResume() {
        super.onResume()
        // If the user granted Exact alarms & reminders from Android settings,
        // re-arm the pending schedule immediately with the more precise mode.
        runCatching { DownloadScheduleManager.reschedule(this) }
        handler.removeCallbacks(refresh)
        refreshDownloads(false)
        handler.postDelayed(refresh, 250L)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        imageExecutor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != folderRequestCode || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Throwable) {
        }
        DownloadLocationPrefs.setTree(this, treeUri)
        lastStructure = ""
        refreshDownloads(true)
        Toast.makeText(this, "مسیر دانلود تغییر کرد", Toast.LENGTH_SHORT).show()
    }

    private fun buildShell() {
        val palette = UiPreferences.palette(this)
        root = FrameLayout(this).apply {
            setBackgroundColor(palette.background)
            clipChildren = false
            clipToPadding = false
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            clipChildren = false
            isFillViewport = true
            setPadding(0, 0, 0, dp(30))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isTvLike()) 28 else 14), dp(14), dp(if (isTvLike()) 28 else 14), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildHeader()
        buildFilters()
        if (AccountSession.downloadPathSelectionEnabled(this)) {
            content.addView(downloadLocationCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        content.addView(downloadScheduleCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        content.addView(bulkImportCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        downloadsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        content.addView(downloadsBox, LinearLayout.LayoutParams(-1, -2))
        content.addView(downloadHelpCard(), LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(14)
            bottomMargin = dp(18)
        })
    }

    private fun downloadHelpCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = glass(22, true)
            focusKey(this, "downloads:help")
            premiumFocus(this, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                startActivity(Intent(this@DownloadsActivity, MainActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("open_help", true)
                })
            }
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_info_archive)
                setColorFilter(palette.primary)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glassTint(palette.primary, 16)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(14) })
            addView(LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@DownloadsActivity).apply {
                    text = "راهنمای دانلود، آرشیوها و زیرنویس"
                    setTextColor(palette.text)
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                addView(TextView(this@DownloadsActivity).apply {
                    text = "حل مشکلات دانلود، هاردساب و سافت‌ساب و اتصال به سرورها"
                    setTextColor(palette.muted)
                    textSize = 11f
                    gravity = Gravity.RIGHT
                    setPadding(0, dp(4), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun buildHeader() {
        val palette = UiPreferences.palette(this)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass(24, true)
            clipChildren = false
            clipToPadding = false
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_back)
            setColorFilter(palette.text)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            focusKey(this, "header:back")
            premiumFocus(this, 999)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(10) })

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titles.addView(TextView(this).apply {
            text = "دانلودها"
            setTextColor(palette.text)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = "مدیریت حرفه‌ای، توقف و ادامه واقعی"
            setTextColor(palette.muted)
            textSize = 11.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun buildFilters() {
        // Equal-width compact tabs prevent clipping on small phones while still
        // remaining large enough for TV focus navigation.
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
        }
        allTab = filterButton("همه", FILTER_ALL)
        activeTab = filterButton("در حال دانلود", FILTER_ACTIVE)
        completedTab = filterButton("دانلود شده", FILTER_COMPLETED)
        failedTab = filterButton("ناموفق", FILTER_FAILED)
        val tabHeight = dp(if (isTvLike()) 48 else 42)
        row.addView(allTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(3) })
        row.addView(activeTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        row.addView(completedTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
        row.addView(failedTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginEnd = dp(3) })
        content.addView(row, LinearLayout.LayoutParams(-1, tabHeight + dp(8)).apply { bottomMargin = dp(6) })
    }

    private fun filterButton(label: String, key: String): TextView = TextView(this).apply {
        text = label
        textSize = if (isTvLike()) 12f else 10.4f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        includeFontPadding = false
        setPadding(dp(5), 0, dp(5), 0)
        focusKey(this, "filter:$key")
        premiumFocus(this, 16)
        setOnClickListener {
            if (selectedFilter == key) return@setOnClickListener
            selectedFilter = key
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun updateFilterUi(items: List<JSONObject>) {
        val active = items.count { isActive(it.optString("status")) || it.optString("status") == InternalDownloadStore.STATUS_SCHEDULED }
        val completed = items.count { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }
        val failed = items.count { it.optString("status") == InternalDownloadStore.STATUS_FAILED }
        allTab.text = "همه ${items.size}"
        activeTab.text = "فعال $active"
        completedTab.text = "کامل $completed"
        failedTab.text = "ناموفق $failed"
        bindFilterStyle(allTab, selectedFilter == FILTER_ALL)
        bindFilterStyle(activeTab, selectedFilter == FILTER_ACTIVE)
        bindFilterStyle(completedTab, selectedFilter == FILTER_COMPLETED)
        bindFilterStyle(failedTab, selectedFilter == FILTER_FAILED)
    }

    private fun bindFilterStyle(view: TextView, active: Boolean) {
        val palette = UiPreferences.palette(this)
        view.setTextColor(if (active) palette.onPrimary else palette.text)
        view.background = if (active) {
            glassTint(palette.primary, 15)
        } else {
            glass(15, true)
        }
    }

    private fun refreshDownloads(force: Boolean) {
        updateScheduleUi()
        if (!::downloadsBox.isInitialized) return
        val all = InternalDownloadStore.all(this)
        updateFilterUi(all)
        val visible = all.filter { item ->
            when (selectedFilter) {
                FILTER_ACTIVE -> isActive(item.optString("status")) || item.optString("status") == InternalDownloadStore.STATUS_SCHEDULED
                FILTER_COMPLETED -> item.optString("status") == InternalDownloadStore.STATUS_COMPLETED
                FILTER_FAILED -> item.optString("status") == InternalDownloadStore.STATUS_FAILED
                else -> true
            }
        }
        val structure = buildString {
            append(selectedFilter).append('|')
            if (AccountSession.downloadPathSelectionEnabled(this@DownloadsActivity)) append(DownloadLocationPrefs.displayName(this@DownloadsActivity))
            visible.forEach {
                append('|').append(it.optString("id"))
                    .append(':').append(it.optString("status"))
                    .append(':').append(it.optString("poster"))
                    .append(':').append(it.optString("error"))
                    .append(':').append(it.optBoolean("resume_checked", false))
            }
        }
        if (force || structure != lastStructure) {
            lastStructure = structure
            rebuildDownloadList(visible)
        } else {
            updateProgressOnly(visible)
        }
    }

    private fun rebuildDownloadList(items: List<JSONObject>) {
        val focusKey = currentFocus?.getTag(R.id.bm_focus_restore_key) as? String
        downloadsBox.animate().cancel()
        downloadsBox.removeAllViews()
        cardRefs.clear()

        if (items.isEmpty()) {
            downloadsBox.addView(emptyState(), LinearLayout.LayoutParams(-1, -2))
        } else {
            items.forEach { item ->
                downloadsBox.addView(downloadCard(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
            }
            if (selectedFilter != FILTER_ACTIVE && items.any { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }) {
                downloadsBox.addView(clearCompletedButton(), LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(4) })
            }
        }

        downloadsBox.alpha = 0f
        downloadsBox.translationY = dp(7).toFloat()
        downloadsBox.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(165L)
            .setInterpolator(DecelerateInterpolator())
            .start()

        if (isTvLike()) {
            downloadsBox.postDelayed({
                val restored = focusKey?.let { findFocusKey(content, it) }
                if (restored != null) restored.requestFocus() else if (currentFocus == null) focusFirst(content)
            }, 90L)
        }
    }

    private fun emptyState(): View {
        val palette = UiPreferences.palette(this)
        val text = when (selectedFilter) {
            FILTER_ACTIVE -> "دانلود فعالی وجود ندارد"
            FILTER_COMPLETED -> "هنوز دانلود کاملی نداری"
            FILTER_FAILED -> "دانلود ناموفقی وجود ندارد"
            else -> "هنوز دانلودی نداری"
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(44), dp(20), dp(44))
            background = glass(24, true)
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_download)
                setColorFilter(palette.primary)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(12) })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = text
                setTextColor(palette.text)
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = "از باکس دانلود هر فیلم یا قسمت، دانلودر داخلی را انتخاب کن."
                setTextColor(palette.muted)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(7), dp(12), 0)
            })
        }
    }

    private fun clearCompletedButton(): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = "پاک‌کردن سوابق دانلودهای کامل‌شده"
        setTextColor(Color.rgb(255, 125, 135))
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(Color.argb(45, 235, 35, 55), 18, Color.argb(130, 235, 35, 55))
        focusKey(this, "downloads:clear-completed")
        premiumFocus(this, 18)
        setOnClickListener {
            InternalDownloadStore.clearCompleted(this@DownloadsActivity)
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun downloadScheduleCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass(22, true)
            focusKey(this, "downloads:schedule")
            premiumFocus(this, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener { showScheduleDialog() }
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_info_calendar)
                setColorFilter(palette.primary)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glassTint(palette.primary, 16)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
            val textBox = LinearLayout(this@DownloadsActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            textBox.addView(TextView(this@DownloadsActivity).apply {
                text = "زمان‌بندی دانلود"
                setTextColor(palette.text); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
            })
            scheduleStatusText = TextView(this@DownloadsActivity).apply {
                setTextColor(palette.muted); textSize = 10.8f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0)
            }
            textBox.addView(scheduleStatusText)
            addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@DownloadsActivity).apply {
                text = "›"; setTextColor(palette.muted); textSize = 28f; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(30), dp(48)))
            post { updateScheduleUi() }
        }
    }

    private fun updateScheduleUi() {
        val start = DownloadScheduleManager.startAt(this)
        val end = DownloadScheduleManager.endAt(this)
        val now = System.currentTimeMillis()
        scheduleStatusText?.text = when {
            start > now && end > start -> "شروع: ${formatScheduleTime(start)}  •  پایان: ${formatScheduleTime(end)}"
            end > now -> "بازه فعال است  •  توقف خودکار: ${formatScheduleTime(end)}"
            else -> "خاموش — دانلودها بلافاصله شروع می‌شوند"
        }
    }

    private fun formatScheduleTime(time: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = time }
        return "%02d:%02d  •  %04d/%02d/%02d".format(
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    private fun setDownloadSchedule(startAt: Long, endAt: Long) {
        DownloadScheduleManager.scheduleWindow(this, startAt, endAt)
        // A download window controls the whole queue, including downloads that
        // are already running when the user arms a future start time.
        androidx.core.content.ContextCompat.startForegroundService(
            this,
            Intent(this, InternalDownloadService::class.java).apply {
                action = InternalDownloadService.ACTION_ARM_SCHEDULE
                putExtra(InternalDownloadService.EXTRA_SCHEDULE_AT, startAt)
            }
        )
        lastStructure = ""
        refreshDownloads(true)
        Toast.makeText(this, "بازه دانلود ثبت شد: ${formatScheduleTime(startAt)} تا ${formatScheduleTime(endAt)}", Toast.LENGTH_LONG).show()
        ensureReliableBackgroundAccess()
    }

    private fun maybeOfferExactScheduleAccess() = ensureReliableBackgroundAccess()

    private fun ensureReliableBackgroundAccess() {
        val needsExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            alarm.canScheduleExactAlarms() == false
        } else false
        val power = getSystemService(POWER_SERVICE) as PowerManager
        val needsBattery = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !power.isIgnoringBatteryOptimizations(packageName)
        if (!needsExact && !needsBattery) return

        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "اجرای مطمئن دانلود در پس‌زمینه"
            setTextColor(palette.text); textSize = 17.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "برای اینکه شروع و پایان دانلود در زمان انتخابی و هنگام خاموش بودن صفحه درست اجرا شود، مجوزهای لازم اندروید را فعال کنید."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        if (needsExact) box.addView(dialogButton("اجازه Alarm دقیق", false, "schedule:exact") {
            runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        if (needsBattery) box.addView(dialogButton("اجازه فعالیت پس‌زمینه", false, "schedule:battery") {
            runCatching { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        box.addView(dialogButton("بستن", true, "schedule:permissions-close") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, dp(46)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(520)), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun showScheduleDialog() {
        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "بازه دانلود"; setTextColor(palette.text); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "ساعت شروع و پایان را خودتان انتخاب کنید. در ساعت پایان، دانلودهای فعال Pause می‌شوند و فایل ناقص برای ادامه بعدی حفظ می‌شود."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        box.addView(dialogButton("انتخاب ساعت شروع و پایان", false, "schedule:window") {
            dialog.dismiss()
            val now = Calendar.getInstance()
            TimePickerDialog(this, { _, startHour, startMinute ->
                val start = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, startHour); set(Calendar.MINUTE, startMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis() + 5_000L) add(Calendar.DAY_OF_MONTH, 1)
                }
                val endDefault = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.HOUR_OF_DAY, 2) }
                TimePickerDialog(this, { _, endHour, endMinute ->
                    val end = Calendar.getInstance().apply {
                        timeInMillis = start.timeInMillis
                        set(Calendar.HOUR_OF_DAY, endHour); set(Calendar.MINUTE, endMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        if (timeInMillis <= start.timeInMillis) add(Calendar.DAY_OF_MONTH, 1)
                    }
                    setDownloadSchedule(start.timeInMillis, end.timeInMillis)
                }, endDefault.get(Calendar.HOUR_OF_DAY), endDefault.get(Calendar.MINUTE), true).apply {
                    setTitle("ساعت پایان دانلود")
                }.show()
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).apply {
                setTitle("ساعت شروع دانلود")
            }.show()
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        if (DownloadScheduleManager.isActive(this)) {
            box.addView(dialogButton("لغو بازه و شروع صف الآن", true, "schedule:cancel") {
                dialog.dismiss()
                DownloadScheduleManager.cancel(this)
                InternalDownloadStore.releaseScheduled(this)
                val service = Intent(this, InternalDownloadService::class.java).apply { action = InternalDownloadService.ACTION_RESTORE }
                androidx.core.content.ContextCompat.startForegroundService(this, service)
                lastStructure = ""
                refreshDownloads(true)
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(520)), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun bulkImportCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass(22, true)
            focusKey(this, "downloads:bulk-import")
            premiumFocus(this, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener { showBulkImportDialog() }
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_copy_link)
                setColorFilter(palette.primary)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glassTint(palette.primary, 16)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
            addView(LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@DownloadsActivity).apply {
                    text = "افزودن لیست لینک‌ها"; setTextColor(palette.text); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
                })
                addView(TextView(this@DownloadsActivity).apply {
                    text = "Paste مستقیم خروجی «کپی همه لینک‌ها» از کلیپ‌بورد"; setTextColor(palette.muted); textSize = 10.8f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun clipboardUrls(): List<String> {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        return Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).findAll(text)
            .map { it.value.trim().trimEnd(',', ';') }
            .filter { it.startsWith("http", true) }
            .distinct()
            .take(500)
            .toList()
    }

    private fun showBulkImportDialog() {
        val urls = clipboardUrls()
        if (urls.isEmpty()) {
            Toast.makeText(this, "هیچ لینک HTTP/HTTPS در کلیپ‌بورد پیدا نشد", Toast.LENGTH_LONG).show()
            return
        }
        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "ساخت لیست دانلود"; setTextColor(palette.text); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "${urls.size} لینک یکتا شناسایی شد. نام فایل از نام اصلی URL گرفته می‌شود تا شماره فصل/قسمت از بین نرود."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        box.addView(dialogButton("افزودن ${urls.size} فایل به دانلودر", false, "bulk:add") {
            dialog.dismiss()
            urls.forEach { url ->
                val fileName = InternalDownloadStore.originalFileNameFromUrl(url)
                    ?: InternalDownloadStore.safeFileName("Bankmovie-${InternalDownloadStore.idFor(url)}", "", "", url)
                val title = fileName.substringBeforeLast('.').ifBlank { "Bankmovie" }
                InternalDownloadService.start(this, url, title, "", "", "لیست لینک‌ها", "", fileName)
            }
            Toast.makeText(this, "${urls.size} فایل به صف اضافه شد", Toast.LENGTH_LONG).show()
            lastStructure = ""
            refreshDownloads(true)
        }, LinearLayout.LayoutParams(-1, dp(50)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout((resources.displayMetrics.widthPixels - dp(36)).coerceAtMost(dp(520)), WindowManager.LayoutParams.WRAP_CONTENT)
    }

    private fun downloadLocationCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = glass(22, true)
            focusKey(this, "downloads:folder")
            premiumFocus(this, 22)
            setOnClickListener { showLocationDialog() }

            addView(FrameLayout(this@DownloadsActivity).apply {
                background = rounded(
                    Color.argb(55, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)),
                    16,
                    Color.argb(145, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary))
                )
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(palette.primary)
                }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(14) })

            val labels = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = "محل ذخیره دانلودها"
                setTextColor(palette.text)
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = DownloadLocationPrefs.displayName(this@DownloadsActivity)
                setTextColor(palette.muted)
                textSize = 11.2f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(4), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@DownloadsActivity).apply {
                text = "تغییر"
                setTextColor(palette.primary)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(60), dp(38)))
        }
    }

    private fun showLocationDialog() {
        if (!AccountSession.downloadPathSelectionEnabled(this)) {
            Toast.makeText(this, "انتخاب مسیر دانلود از پنل غیرفعال شده است", Toast.LENGTH_SHORT).show()
            return
        }
        val palette = UiPreferences.palette(this)
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = glass(25, true)
            clipChildren = false
            clipToPadding = false
        }
        box.addView(TextView(this).apply {
            text = "انتخاب محل ذخیره"
            setTextColor(palette.text)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        box.addView(TextView(this).apply {
            text = "می‌توانی پوشه دلخواه را انتخاب کنی یا از حافظه اختصاصی برنامه استفاده کنی."
            setTextColor(palette.muted)
            textSize = 12.2f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val custom = dialogButton("انتخاب پوشه دلخواه", false, "location:custom") {
            dialog.dismiss()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, folderRequestCode)
        }
        val appFolder = dialogButton("حافظه اختصاصی برنامه", false, "location:app") {
            DownloadLocationPrefs.setAppFolder(this)
            dialog.dismiss()
            lastStructure = ""
            refreshDownloads(true)
            Toast.makeText(this, "حافظه اختصاصی برنامه انتخاب شد", Toast.LENGTH_SHORT).show()
        }
        box.addView(custom, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
        box.addView(appFolder, LinearLayout.LayoutParams(-1, dp(50)))

        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        val win = dialog.window
        win?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        win?.setDimAmount(0.58f)
        win?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        val maxWidth = if (isTvLike()) dp(620) else dp(500)
        win?.setLayout((resources.displayMetrics.widthPixels - dp(24)).coerceAtMost(maxWidth), ViewGroup.LayoutParams.WRAP_CONTENT)
        val decor = win?.decorView
        if (decor != null) {
            decor.alpha = 0f
            decor.scaleX = 0.97f
            decor.scaleY = 0.97f
            decor.translationY = dp(10).toFloat()
            decor.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(180L).setInterpolator(DecelerateInterpolator()).start()
        }
        if (isTvLike()) box.postDelayed({ custom.requestFocus() }, 90L)
    }

    private fun dialogButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 125, 135) else palette.text)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) rounded(Color.argb(45, 235, 35, 55), 16, Color.argb(125, 235, 35, 55)) else glass(16, false)
        focusKey(this, key)
        premiumFocus(this, 16)
        setOnClickListener { click() }
    }

    private fun downloadCard(item: JSONObject): LinearLayout {
        val palette = UiPreferences.palette(this)
        val id = item.optString("id")
        val status = item.optString("status")
        val downloaded = item.optLong("downloaded", 0L)
        val total = item.optLong("total", 0L)
        val speed = item.optLong("speed", 0L)
        val percent = percent(downloaded, total)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(palette.card, 22, palette.stroke)
            clipChildren = false
            clipToPadding = false

            val top = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.TOP
                clipChildren = false
                clipToPadding = false
            }

            val posterShell = FrameLayout(this@DownloadsActivity).apply {
                background = glass(16, false)
                clipToOutline = true
            }
            val poster = ImageView(this@DownloadsActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageResource(R.drawable.bankmovie_mark_transparent)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            posterShell.addView(poster, FrameLayout.LayoutParams(-1, -1))
            top.addView(posterShell, LinearLayout.LayoutParams(dp(78), dp(108)).apply { marginEnd = dp(16) })
            loadPoster(item.optString("poster"), poster)

            val info = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                setPadding(dp(2), 0, dp(2), 0)
            }
            info.addView(TextView(this@DownloadsActivity).apply {
                text = item.optString("title").ifBlank { item.optString("file_name") }
                setTextColor(palette.text)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            info.addView(TextView(this@DownloadsActivity).apply {
                text = listOf(item.optString("quality"), item.optString("kind"), item.optString("display_label"))
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(" • ")
                setTextColor(palette.muted)
                textSize = 11f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            })
            info.addView(TextView(this@DownloadsActivity).apply {
                text = statusChipText(status)
                setTextColor(statusColor(status, palette.primary))
                textSize = 10.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                setPadding(0, dp(8), 0, 0)
            })
            val fileInfoText = TextView(this@DownloadsActivity).apply {
                text = fileInfoLabel(item)
                setTextColor(palette.faint)
                textSize = 10.2f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(6), 0, 0)
            }
            info.addView(fileInfoText)
            info.addView(TextView(this@DownloadsActivity).apply {
                text = "ذخیره در: " + item.optString("location_label").ifBlank { DownloadLocationPrefs.displayName(this@DownloadsActivity) }
                setTextColor(palette.faint)
                textSize = 9.8f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(7), 0, 0)
            })
            top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            addView(top)

            val progress = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                this.max = 100
                this.progress = percent
                isIndeterminate = (total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING) || status == InternalDownloadStore.STATUS_VERIFYING
                progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(palette.panel2)
            }
            addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(13) })

            val statRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, dp(8), 0, 0)
            }
            val statusText = TextView(this@DownloadsActivity).apply {
                text = statusLabel(status, percent, speed)
                setTextColor(statusColor(status, palette.muted))
                textSize = 11.3f
                gravity = Gravity.RIGHT
            }
            val bytesText = TextView(this@DownloadsActivity).apply {
                text = bytesLabel(downloaded, total)
                setTextColor(palette.faint)
                textSize = 10.8f
                gravity = Gravity.CENTER
            }
            val remainingText = TextView(this@DownloadsActivity).apply {
                text = remainingLabel(downloaded, total, speed, status)
                setTextColor(palette.faint)
                textSize = 10.8f
                gravity = Gravity.LEFT
            }
            statRow.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
            statRow.addView(bytesText, LinearLayout.LayoutParams(0, -2, 1f))
            statRow.addView(remainingText, LinearLayout.LayoutParams(0, -2, 1f))
            addView(statRow)

            val actions = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT
                setPadding(0, dp(10), 0, 0)
                clipChildren = false
                clipToPadding = false
            }
            when (status) {
                InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_VERIFYING -> {
                    actions.addView(actionButton("توقف", false, "$id:pause") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    actions.addView(actionButton("لغو", true, "$id:cancel") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_QUEUED, InternalDownloadStore.STATUS_RETRYING -> {
                    actions.addView(actionButton("توقف", false, "$id:pause") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    actions.addView(actionButton("اول صف", false, "$id:first") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_MOVE_FIRST, id) }, buttonParams())
                    actions.addView(actionButton("آخر صف", false, "$id:last") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_MOVE_LAST, id) }, buttonParams())
                    actions.addView(actionButton("لغو", true, "$id:cancel") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_FAILED, InternalDownloadStore.STATUS_SCHEDULED -> {
                    actions.addView(actionButton(if (status == InternalDownloadStore.STATUS_SCHEDULED) "شروع الآن" else "ادامه", false, "$id:resume") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_RESUME, id) })
                    actions.addView(actionButton("حذف", true, "$id:delete") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_COMPLETED -> {
                    actions.addView(actionButton("بازکردن", false, "$id:open") { openDownloaded(item) })
                    actions.addView(actionButton("اشتراک", false, "$id:share") { shareDownloaded(item) }, buttonParams())
                    actions.addView(actionButton("حذف", true, "$id:delete") { showDeleteOptions(item) }, buttonParams())
                }
            }
            val actionScroll = HorizontalScrollView(this@DownloadsActivity).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                clipToPadding = false
                addView(actions, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            addView(actionScroll, LinearLayout.LayoutParams(-1, -2))

            val error = item.optString("error")
            if (error.isNotBlank() && status == InternalDownloadStore.STATUS_FAILED) {
                addView(TextView(this@DownloadsActivity).apply {
                    text = error
                    setTextColor(Color.rgb(230, 130, 140))
                    textSize = 10.5f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(7), 0, 0)
                })
            }

            cardRefs[id] = CardRefs(progress, statusText, bytesText, remainingText, fileInfoText)
        }
    }

    private fun buttonParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(dp(78), dp(40)).apply { marginStart = dp(7) }

    private fun actionButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 130, 140) else palette.onPrimary)
        textSize = 11.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) {
            rounded(Color.argb(45, 235, 35, 55), 14, Color.argb(130, 235, 35, 55))
        } else {
            glassTint(palette.primary, 14)
        }
        focusKey(this, "download:$key")
        premiumFocus(this, 14)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(78), dp(40))
    }

    private fun updateProgressOnly(items: List<JSONObject>) {
        items.forEach { item ->
            val id = item.optString("id")
            val refs = cardRefs[id] ?: return@forEach
            val downloaded = item.optLong("downloaded", 0L)
            val total = item.optLong("total", 0L)
            val speed = item.optLong("speed", 0L)
            val status = item.optString("status")
            val percent = percent(downloaded, total)
            refs.progress.isIndeterminate = (total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING) || status == InternalDownloadStore.STATUS_VERIFYING
            if (!refs.progress.isIndeterminate) refs.progress.progress = percent
            refs.status.text = statusLabel(status, percent, speed)
            refs.bytes.text = bytesLabel(downloaded, total)
            refs.remaining.text = remainingLabel(downloaded, total, speed, status)
            refs.fileInfo.text = fileInfoLabel(item)
        }
    }

    private fun downloadedUri(item: JSONObject): Pair<Uri, String>? {
        val mime = InternalDownloadStore.mimeForName(item.optString("file_name"))
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank() || !InternalDownloadStore.exists(this, item)) null else Uri.parse(raw) to mime
        } else {
            val file = File(item.optString("path"))
            if (!file.exists()) null else FileProvider.getUriForFile(this, "$packageName.files", file) to mime
        }
    }

    private fun shareDownloaded(item: JSONObject) {
        val target = downloadedUri(item)
        if (target == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "اشتراک‌گذاری فایل"))
        }.onFailure { Toast.makeText(this, "امکان اشتراک‌گذاری فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
    }

    private fun showDeleteOptions(item: JSONObject) {
        val id = item.optString("id")
        AlertDialog.Builder(this)
            .setTitle("حذف دانلود")
            .setItems(arrayOf("حذف فایل و رکورد", "حذف فقط رکورد دانلود", "انصراف")) { dialog, which ->
                when (which) {
                    0 -> InternalDownloadStore.remove(this, id, true)
                    1 -> InternalDownloadStore.remove(this, id, false)
                    else -> { dialog.dismiss(); return@setItems }
                }
                lastStructure = ""
                refreshDownloads(true)
            }.show()
    }

    private fun openDownloaded(item: JSONObject) {
        val target = downloadedUri(item)
        if (target == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(target.first, target.second)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Throwable) {
            Toast.makeText(this, "برنامه‌ای برای بازکردن فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun percent(downloaded: Long, total: Long): Int = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0

    private fun isActive(status: String): Boolean = status in setOf(
        InternalDownloadStore.STATUS_QUEUED,
        InternalDownloadStore.STATUS_DOWNLOADING,
        InternalDownloadStore.STATUS_RETRYING,
        InternalDownloadStore.STATUS_VERIFYING,
        InternalDownloadStore.STATUS_PAUSED,
        InternalDownloadStore.STATUS_SCHEDULED
    )

    private fun statusChipText(status: String): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف"
        InternalDownloadStore.STATUS_DOWNLOADING -> "در حال دانلود"
        InternalDownloadStore.STATUS_RETRYING -> "تلاش مجدد"
        InternalDownloadStore.STATUS_VERIFYING -> "بررسی فایل"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده"
        InternalDownloadStore.STATUS_SCHEDULED -> "زمان‌بندی‌شده"
        InternalDownloadStore.STATUS_COMPLETED -> "کامل شده"
        InternalDownloadStore.STATUS_FAILED -> "خطا"
        else -> "لغو شده"
    }

    private fun statusColor(status: String, primary: Int): Int = when (status) {
        InternalDownloadStore.STATUS_COMPLETED -> Color.rgb(75, 210, 135)
        InternalDownloadStore.STATUS_FAILED -> Color.rgb(255, 110, 120)
        InternalDownloadStore.STATUS_PAUSED -> Color.rgb(255, 169, 78)
        InternalDownloadStore.STATUS_SCHEDULED -> Color.rgb(160, 112, 245)
        InternalDownloadStore.STATUS_RETRYING -> Color.rgb(255, 190, 70)
        InternalDownloadStore.STATUS_VERIFYING -> Color.rgb(80, 190, 245)
        else -> primary
    }

    private fun fileInfoLabel(item: JSONObject): String {
        val total = item.optLong("total", 0L)
        val downloaded = item.optLong("downloaded", 0L)
        val checked = item.optBoolean("resume_checked", false)
        val resume = item.optBoolean("resume_supported", false)
        val multipart = item.optBoolean("multipart", false)
        val parts = item.optInt("multipart_parts", 1).coerceAtLeast(1)
        val attempt = item.optInt("retry_attempt", 0)
        val maxRetry = item.optInt("retry_max", AccountSession.downloadRetryCount(this))
        val bits = mutableListOf<String>()
        if (total > 0L) bits += "حجم: ${humanSize(total)}" else if (!checked) bits += "در حال دریافت حجم فایل..." else bits += "حجم نامشخص"
        if (total > downloaded && downloaded > 0L) bits += "باقی‌مانده: ${humanSize(total - downloaded)}"
        if (checked) bits += if (resume) "ادامه واقعی" else "ادامه در صورت پشتیبانی سرور"
        if (multipart) bits += "$parts بخش هم‌زمان"
        if (attempt > 0) bits += "تلاش $attempt از $maxRetry"
        return bits.joinToString("  •  ")
    }

    private fun statusLabel(status: String, percent: Int, speed: Long): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف دانلود"
        InternalDownloadStore.STATUS_DOWNLOADING -> "$percent٪  •  ${humanSize(speed)}/s"
        InternalDownloadStore.STATUS_RETRYING -> "اتصال ناپایدار؛ تلاش مجدد خودکار"
        InternalDownloadStore.STATUS_VERIFYING -> "در حال بررسی کامل‌بودن فایل"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده • $percent٪"
        InternalDownloadStore.STATUS_SCHEDULED -> "در انتظار زمان‌بندی"
        InternalDownloadStore.STATUS_COMPLETED -> "دانلود کامل و بررسی شد"
        InternalDownloadStore.STATUS_FAILED -> "دانلود پس از تلاش‌های مجدد ناموفق شد"
        else -> "لغو شده"
    }

    private fun bytesLabel(downloaded: Long, total: Long): String {
        return if (total > 0L) "${humanSize(downloaded)} / ${humanSize(total)}" else humanSize(downloaded)
    }

    private fun remainingLabel(downloaded: Long, total: Long, speed: Long, status: String): String {
        if (status == InternalDownloadStore.STATUS_COMPLETED) return "آماده پخش"
        if (status == InternalDownloadStore.STATUS_RETRYING) return "در انتظار اتصال پایدار"
        if (status == InternalDownloadStore.STATUS_VERIFYING) return "بررسی اندازه نهایی"
        if (status == InternalDownloadStore.STATUS_SCHEDULED) return "شروع در زمان تعیین‌شده"
        if (total > downloaded && status != InternalDownloadStore.STATUS_DOWNLOADING) return "${humanSize(total - downloaded)} باقی‌مانده"
        if (status != InternalDownloadStore.STATUS_DOWNLOADING || speed <= 0L || total <= downloaded) return ""
        val seconds = ((total - downloaded) / speed).coerceAtLeast(0L)
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val secs = seconds % 60L
        return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d مانده", hours, minutes, secs)
        else String.format(Locale.US, "%02d:%02d مانده", minutes, secs)
    }

    private fun humanSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        return if (mb >= 1024.0) String.format(Locale.US, "%.2f GB", mb / 1024.0) else String.format(Locale.US, "%.1f MB", mb)
    }

    private fun normalizePoster(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value == "null") return ""
        if (value.startsWith("//")) return "https:$value"
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return AppConfig.BASE_URL.trimEnd('/') + "/" + value.trimStart('/')
    }

    private fun loadPoster(raw: String, target: ImageView) {
        val url = normalizePoster(raw)
        if (url.isBlank()) return
        target.tag = url
        val cached = posterCache.get(url)
        if (cached != null && !cached.isRecycled) {
            target.setPadding(0, 0, 0, 0)
            target.setImageBitmap(cached)
            return
        }
        imageExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 6500
                connection.readTimeout = 8500
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "Bankmovie Android")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                var bitmap = BitmapFactory.decodeStream(connection.inputStream, null, options) ?: return@execute
                val bigger = max(bitmap.width, bitmap.height)
                if (bigger > 520) {
                    val ratio = 520f / bigger.toFloat()
                    val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true)
                    if (scaled !== bitmap) {
                        bitmap.recycle()
                        bitmap = scaled
                    }
                }
                posterCache.put(url, bitmap)
                runOnUiThread {
                    if (!isFinishing && target.tag == url && !bitmap.isRecycled) {
                        target.setPadding(0, 0, 0, 0)
                        target.alpha = 0.35f
                        target.setImageBitmap(bitmap)
                        target.animate().alpha(1f).setDuration(180L).start()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { connection?.disconnect() }
            }
        }
    }

    private fun focusKey(view: View, key: String) {
        view.setTag(R.id.bm_focus_restore_key, key)
    }

    private fun findFocusKey(view: View, key: String): View? {
        if (view.getTag(R.id.bm_focus_restore_key) == key && view.visibility == View.VISIBLE) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val found = findFocusKey(view.getChildAt(i), key)
                if (found != null) return found
            }
        }
        return null
    }

    private fun focusFirst(view: View): Boolean {
        if (view.isFocusable && view.isEnabled && view.visibility == View.VISIBLE && view.hasOnClickListeners()) {
            view.requestFocus()
            return true
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) if (focusFirst(view.getChildAt(i))) return true
        }
        return false
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun focusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val glow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.argb(42, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(160, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclamp(view: View) {
        var parent = view.parent
        while (parent is ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun premiumFocus(view: View, radius: Int = 16) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val normalElevation = view.elevation
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        view.setOnFocusChangeListener { target, focused ->
            target.animate().cancel()
            if (focused) {
                unclamp(target)
                target.bringToFront()
            }
            target.foreground = if (focused) focusDrawable(radius) else originalForeground
            target.elevation = if (focused) dp(20).toFloat() else normalElevation
            target.translationZ = if (focused) dp(7).toFloat() else 0f
            target.animate()
                .scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f)
                .setDuration(if (focused) 145L else 105L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun glass(radius: Int, elevated: Boolean = false): GradientDrawable {
        val p = palette
        val base = if (p.light) p.panel else p.panel2
        val topBase = UiPreferences.blend(base, Color.WHITE, if (p.light) 0.03f else 0.07f)
        val bottomBase = UiPreferences.blend(base, Color.BLACK, if (p.light) 0.01f else 0.05f)
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(if (p.light) 248 else 236, Color.red(topBase), Color.green(topBase), Color.blue(topBase)),
                Color.argb(if (p.light) 244 else if (elevated) 224 else 216, Color.red(bottomBase), Color.green(bottomBase), Color.blue(bottomBase))
            )
        ).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), if (p.light) Color.argb(65, 20, 24, 31) else Color.argb(68, 255, 255, 255))
        }
    }

    private fun glassTint(accent: Int, radius: Int): GradientDrawable {
        val p = palette
        val base = if (p.light) p.panel else p.panel2
        val top = UiPreferences.blend(base, accent, if (p.light) 0.13f else 0.25f)
        val bottom = UiPreferences.blend(base, Color.BLACK, if (p.light) 0.02f else 0.05f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(if (p.light) 90 else 112, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
