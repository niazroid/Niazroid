using System.Windows;
using LibVLCSharp.Shared;

namespace BankMovie.Windows;

public partial class App : Application
{
    public static LibVLC? SharedLibVlc { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            Core.Initialize();
            SharedLibVlc = new LibVLC(
                "--no-video-title-show",
                "--no-snapshot-preview",
                "--quiet");
            SharedLibVlc.SetAppId("ir.bankmovie.windows", "1.0.0", "BankMovie");
            SharedLibVlc.SetUserAgent("BankMovie Windows", "BankMovie-Windows/1.0");
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "موتور پخش داخلی بارگذاری نشد. برنامه باز می‌شود، اما پلیر تا نصب صحیح فایل‌های موتور فعال نخواهد بود.\n\n" + ex.Message,
                "BankMovie Player",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    protected override void OnExit(ExitEventArgs e)
    {
        SharedLibVlc?.Dispose();
        SharedLibVlc = null;
        base.OnExit(e);
    }
}
