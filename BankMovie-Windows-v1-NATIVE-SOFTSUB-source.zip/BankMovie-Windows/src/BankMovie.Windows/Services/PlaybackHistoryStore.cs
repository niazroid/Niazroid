using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace BankMovie.Windows.Services;

public sealed class PlaybackHistoryStore
{
    private readonly string _filePath;
    private readonly Dictionary<string, long> _items;
    private readonly object _sync = new();

    public PlaybackHistoryStore()
    {
        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie");
        Directory.CreateDirectory(root);
        _filePath = Path.Combine(root, "playback-history.json");
        _items = LoadItems();
    }

    public long Get(string url)
    {
        lock (_sync)
        {
            return _items.TryGetValue(Key(url), out var value) ? value : 0;
        }
    }

    public void Set(string url, long milliseconds)
    {
        lock (_sync)
        {
            var key = Key(url);
            if (milliseconds <= 10_000) _items.Remove(key);
            else _items[key] = milliseconds;
            Persist();
        }
    }

    public void Clear(string url)
    {
        lock (_sync)
        {
            _items.Remove(Key(url));
            Persist();
        }
    }

    private Dictionary<string, long> LoadItems()
    {
        try
        {
            if (!File.Exists(_filePath)) return new Dictionary<string, long>();
            return JsonSerializer.Deserialize<Dictionary<string, long>>(File.ReadAllText(_filePath))
                   ?? new Dictionary<string, long>();
        }
        catch
        {
            return new Dictionary<string, long>();
        }
    }

    private void Persist()
    {
        try
        {
            var temp = _filePath + ".tmp";
            File.WriteAllText(temp, JsonSerializer.Serialize(_items));
            File.Move(temp, _filePath, true);
        }
        catch
        {
            // Playback must not fail because history could not be saved.
        }
    }

    private static string Key(string value)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(value));
        return Convert.ToHexString(bytes);
    }
}
