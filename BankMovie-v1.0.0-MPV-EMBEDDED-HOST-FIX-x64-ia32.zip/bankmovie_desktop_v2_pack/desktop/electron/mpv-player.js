'use strict';
const path = require('path');
const fs = require('fs');
const net = require('net');
const crypto = require('crypto');
const { spawn } = require('child_process');
function bundledPlayer(resourcesPath, packaged, root=path.join(__dirname,'..')) {
  const base = packaged ? resourcesPath : root;
  const exe = path.join(base, packaged ? 'mpv' : 'vendor/mpv', 'mpv.exe');
  const script = path.join(base, 'player', 'cinema.lua');
  if (!fs.existsSync(exe) || !fs.existsSync(script)) return null;
  return {id:'bm-mpv',name:'BankMovie (MPV)',path:exe,script,score:1000,subtitleSupport:true};
}
function cleanTitle(value) {return String(value||'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,240);}
function argsFor(player, target, meta={}, local=false) {
  if (typeof target!=='string'||!target||/[\x00-\x1f]/.test(target)) throw Error('Invalid media path');
  if(local){if(!path.isAbsolute(target))throw Error('Invalid local media path');}
  else {const u=new URL(target);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid media URL');}
  const args=['--no-config','--load-scripts=no','--osc=no','--input-default-bindings=no','--input-builtin-dragging=no','--input-builtin-drag-and-drop=no','--ytdl=no','--load-unsafe-playlists=no','--tls-verify=yes','--no-terminal','--force-window=yes','--idle=no','--keep-open=yes','--geometry=80%x80%','--hwdec=auto-safe','--cache=auto','--sub-auto='+ (local?'exact':'no'),'--audio-file-auto=no','--cover-art-auto=no','--slang=fa,fas,per,persian,en,eng','--script='+player.script];
  const title=cleanTitle(meta.title || (local?path.basename(target):'BankMovie'));
  if(title)args.push('--force-media-title='+title);
  if(meta.subtitlePath)args.push('--sub-file='+meta.subtitlePath);
  if(meta.embed){
    if(!Number.isInteger(meta.embed.hwnd)||meta.embed.hwnd<=0||meta.embed.hwnd>0xffffffff)throw Error('Invalid window handle');
    if(typeof meta.embed.pipe!=='string'||!/^\\\\\.\\pipe\\bm-mpv-[a-f0-9]{32}$/.test(meta.embed.pipe))throw Error('Invalid private player pipe');
    args.splice(args.indexOf('--geometry=80%x80%'),1);
    args.push('--wid='+meta.embed.hwnd,'--input-ipc-server='+meta.embed.pipe,'--script-opts=bm-embedded=yes');
  }
  args.push('--',target);
  return args;
}
async function launch(player,target,meta={},local=false,spawnFn=spawn){
  const args=argsFor(player,target,meta,local);
  await new Promise((resolve,reject)=>{
    const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:true,stdio:'ignore',windowsHide:false});
    child.once('error',()=>reject(new Error('اجرای موتور MPV ناموفق بود.')));
    child.once('spawn',()=>{child.unref();resolve();});
  });
  return {ok:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)};
}
// A dedicated, renderer-free owned native window occupies the main content area.
// Do not parent MPV directly to the Chromium BrowserWindow: its surface can cover MPV.
const active = new WeakMap();
function hwndOf(win){
  if(!win||win.isDestroyed())throw Error('BankMovie window unavailable');
  const b=win.getNativeWindowHandle();
  if(!Buffer.isBuffer(b)||b.length<4)throw Error('Invalid native window');
  const id=b.readUInt32LE(0);if(!id)throw Error('Invalid native window');return id;
}
function createNativeHost(win){
  const {BaseWindow}=require('electron');
  return new BaseWindow({...win.getContentBounds(),parent:win,modal:false,show:false,
    frame:false,skipTaskbar:true,resizable:false,minimizable:false,maximizable:false,
    fullscreenable:false,backgroundColor:'#000000',title:'BankMovie'});
}
function closeEmbedded(win){const session=active.get(win);if(session)session.close();}
async function launchEmbedded(player,target,meta={},local=false,win,opts={}){
  if(!win||win.isDestroyed())throw Error('پنجره بانک‌مووی در دسترس نیست.');
  // Replacing a session must never leave the old guard or an invisible process behind.
  closeEmbedded(win);
  const createHost=opts.createHost||createNativeHost;
  const host=createHost(win);
  const pipe='\\\\.\\pipe\\bm-mpv-'+crypto.randomBytes(16).toString('hex');
  let args;
  try{args=argsFor(player,target,{...meta,embed:{hwnd:hwndOf(host),pipe}},local);}
  catch(e){if(!host.isDestroyed())host.destroy();throw e;}
  const spawnFn=opts.spawnFn||spawn, connect=opts.connect||net.createConnection;
  const initialFull=win.isFullScreen();
  const timeoutMs=opts.timeoutMs||35000;
  let child,socket,retry,deadline,buffer='',finished=false,connected=false,ready=false,videoConfigured=false,positionKnown=false,lastRequest='',intentional=false;
  let resolveReady,rejectReady;
  const started=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject;});
  const session={close:onClose};
  function send(command){if(socket&&!socket.destroyed&&connected)socket.write(JSON.stringify({command})+'\n');}
  function syncBounds(){
    if(finished||win.isDestroyed()||host.isDestroyed())return;
    if(win.isMinimized()||!win.isVisible()){if(host.isVisible())host.hide();return;}
    host.setBounds(win.getContentBounds());if(!host.isVisible())host.show();
  }
  function focusHost(){if(!finished&&!host.isDestroyed()&&host.isVisible())host.focus();}
  function syncFull(){syncBounds();if(!win.isDestroyed())send(['set_property','user-data/bm/parent-fullscreen',win.isFullScreen()]);}
  const bindings=[['move',syncBounds],['resize',syncBounds],['minimize',syncBounds],['restore',syncBounds],['show',syncBounds],['hide',syncBounds],['focus',focusHost],['enter-full-screen',syncFull],['leave-full-screen',syncFull],['closed',onClose]];
  function clean(error){
    if(finished)return;finished=true;clearTimeout(retry);clearTimeout(deadline);
    if(socket)socket.destroy();
    if(child&&!child.killed&&child.exitCode==null){try{child.kill();}catch{}}
    if(active.get(win)===session)active.delete(win);
    for(const [name,fn] of bindings)win.removeListener(name,fn);
    host.removeListener('closed',onClose);
    if(!host.isDestroyed())host.destroy();
    if(!win.isDestroyed()){
      if(win.isFullScreen()!==initialFull)win.setFullScreen(initialFull);
      if(!win.isMinimized()&&win.isVisible()){win.focus();if(win.webContents&&!win.webContents.isDestroyed())win.webContents.focus();}
    }
    if(!ready)rejectReady(error||Error('راه‌اندازی پلیر لغو شد.'));
    else if(error&&!intentional&&opts.onError)opts.onError(error);
  }
  function onClose(){intentional=true;clean();}
  function markReady(){
    if(finished||ready)return;ready=true;clearTimeout(deadline);syncBounds();
    if(!host.isDestroyed()&&host.isVisible())host.focus();
    resolveReady({ok:true,embedded:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)});
  }
  function read(chunk){
    buffer+=chunk;if(buffer.length>65536){buffer='';return;}
    let i;while((i=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,i);buffer=buffer.slice(i+1);let m;try{m=JSON.parse(line)}catch{continue}
      if(m.event==='property-change'&&m.name==='vo-configured'){videoConfigured=m.data===true;}
      if(m.event==='property-change'&&m.name==='time-pos'){positionKnown=typeof m.data==='number'&&Number.isFinite(m.data);}
      if(videoConfigured&&positionKnown)markReady();
      if(m.event==='end-file'&&m.reason==='error'){
        clean(Error('MPV نتوانست فایل یا جریان ویدیو را باز کند.'));return;
      }
      if(m.event==='property-change'&&m.name==='user-data/bm/request'&&typeof m.data==='string'&&m.data!==lastRequest){
        lastRequest=m.data;if(!win.isDestroyed()&&/^toggle:\d+$/.test(m.data))win.setFullScreen(!win.isFullScreen());
      }
    }
  }
  function attempt(){
    if(finished||connected)return;
    let current;
    try{current=connect(pipe);}catch{retry=setTimeout(attempt,150);return;}
    socket=current;current.setEncoding('utf8');current.on('data',read);
    let handled=false;
    function lost(){
      if(handled||finished||socket!==current)return;handled=true;
      if(connected){clean(Error('ارتباط داخلی MPV قطع شد.'));return;}
      current.destroy();retry=setTimeout(attempt,150);
    }
    current.on('error',lost);current.once('close',lost);
    current.once('connect',()=>{
      if(finished||handled)return;connected=true;
      send(['observe_property',1,'user-data/bm/request']);
      send(['observe_property',2,'vo-configured']);send(['observe_property',3,'time-pos']);syncFull();
    });
  }
  active.set(win,session);
  for(const [name,fn] of bindings)win.on(name,fn);
  host.once('closed',onClose);
  try{
    syncBounds();
    child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:false,stdio:'ignore',windowsHide:false});
    child.once('error',()=>clean(Error('اجرای موتور MPV ناموفق بود.')));
    child.once('exit',(code)=>clean(intentional||(ready&&code===0)?null:Error(ready?'پخش MPV متوقف شد.':'MPV پیش از آماده شدن تصویر بسته شد.')));
    child.once('spawn',attempt);
    deadline=setTimeout(()=>clean(Error(connected?'MPV وصل شد ولی تصویر آماده نشد. دوباره تلاش کنید.':'اتصال داخلی MPV برقرار نشد. دوباره تلاش کنید.')),timeoutMs);
  }catch(e){clean(e);}
  return started;
}
module.exports={bundledPlayer,argsFor,launch,launchEmbedded,closeEmbedded,hwndOf,createNativeHost};
