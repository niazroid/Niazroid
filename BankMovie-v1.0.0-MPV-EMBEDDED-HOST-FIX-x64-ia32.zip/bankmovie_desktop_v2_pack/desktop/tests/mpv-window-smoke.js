// Optional real Windows GUI smoke. No account, network or production endpoints.
'use strict';
const assert=require('node:assert/strict');const path=require('node:path');
const {app,BrowserWindow}=require('electron');const P=require('../electron/mpv-player');
let win,host;
const watchdog=setTimeout(()=>{console.error('MPV GUI smoke timed out');app.exit(1)},55000);
app.whenReady().then(async()=>{
  assert.equal(process.platform,'win32');
  const player=P.bundledPlayer('',false,path.resolve(__dirname,'..'));assert.ok(player);
  win=new BrowserWindow({width:850,height:540,show:true,frame:false,webPreferences:{sandbox:true,contextIsolation:true,nodeIntegration:false}});
  await win.loadURL('data:text/html,<body style="background:purple">BankMovie test</body>');
  const launch=()=>P.launchEmbedded(player,path.join(__dirname,'mpv-smoke.mkv'),{},true,win,{timeoutMs:16000,createHost(parent){host=P.createNativeHost(parent);return host;}});
  assert.equal((await launch()).embedded,true);assert.ok(host.isVisible());const old=host;
  P.closeEmbedded(win);assert.ok(old.isDestroyed());
  assert.equal((await launch()).embedded,true);assert.ok(host.isVisible());P.closeEmbedded(win);assert.ok(host.isDestroyed());
  console.log('PASS: real Windows Electron owned host and MPV IPC/video readiness; close and reopen');
  clearTimeout(watchdog);win.destroy();app.exit(0);
}).catch(e=>{console.error(e);clearTimeout(watchdog);if(win&&!win.isDestroyed()){P.closeEmbedded(win);win.destroy();}app.exit(1);});
