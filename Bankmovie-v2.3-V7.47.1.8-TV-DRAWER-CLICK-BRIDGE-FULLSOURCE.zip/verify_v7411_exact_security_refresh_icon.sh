#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFourthHotfixTag=BANKMOVIE-2.3-V7411-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Exact icon migration requested by owner: the detail/update arrow is now the auth challenge refresh icon.
test -s "$draw/ic_status_update_arrow.xml"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth"
! grep -Fq 'setImageResource(R.drawable.ic_auth_refresh)' "$auth"

# V7.41.1 moved the glyph to auth; V7.42 reuses the exact same glyph in
# both auth refresh and the film/series latest-update pill.
if grep -Fq 'sourceMainUpdateTwentyFifthHotfixTag=BANKMOVIE-2.3-V742-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$main"
else
  grep -Fq 'the exact update-arrow drawable that used to live here was moved' "$main"
fi

# Keep all V7.41 behavior/regressions intact.
bash verify_v741_auth_player_modal_speed_polish.sh

echo V7411_EXACT_SECURITY_REFRESH_ICON_VERIFY_OK
