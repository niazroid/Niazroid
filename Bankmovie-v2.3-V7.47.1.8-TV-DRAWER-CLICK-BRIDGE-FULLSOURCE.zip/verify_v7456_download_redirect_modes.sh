#!/usr/bin/env bash
set -euo pipefail

ARCHIVE='server-required/includes/archive_control.php'
REDIRECT='server-required/includes/download_redirect.php'
APP_POLICY='server-required/includes/app_archive_policy.php'
ADMIN='server-required/bm_admin.php'
CONFIG='server-required/app_config.php'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

for f in "$ARCHIVE" "$REDIRECT" "$APP_POLICY" "$ADMIN" "$CONFIG" "$MAIN"; do
  [[ -s "$f" ]] || { echo "Missing $f" >&2; exit 1; }
done

grep -Fq "'download_link_mode' => 'redirect'" "$ARCHIVE"
grep -Fq "['redirect', 'original', 'disabled']" "$ARCHIVE"
grep -Fq "bm_archive_download_link_mode" "$ARCHIVE"
grep -Fq "if (\$linkMode === 'original') return \$url;" "$REDIRECT"
grep -Fq "if (\$linkMode === 'disabled') return '';" "$REDIRECT"
grep -Fq "archive<?= (int)\$bmArchiveNumber ?>_download_link_mode" "$ADMIN"
grep -Fq "archive<?= (int)\$bmArchiveNumber ?>_download_base_urls" "$ADMIN"
grep -Fq "download_link_mode" "$CONFIG"
grep -Fq "download_link_mode" "$APP_POLICY"

grep -Fq 'return link.optString("box_play_url")' "$MAIN"
if sed -n '/private fun downloadBoxPlayerUrl/,/^[[:space:]]*}/p' "$MAIN" | grep -Fq 'downloadUrl(link)'; then
  echo 'downloadBoxPlayerUrl still falls back to download_url' >&2
  exit 1
fi

php -l "$ARCHIVE" >/dev/null
php -l "$REDIRECT" >/dev/null
php -l "$APP_POLICY" >/dev/null
php -l "$ADMIN" >/dev/null
php -l "$CONFIG" >/dev/null

TMP_PRIVATE="$(mktemp -d)"
trap 'rm -rf "$TMP_PRIVATE"' EXIT
BANKMOVIE_PRIVATE_DIR="$TMP_PRIVATE" php -d display_errors=1 <<'PHP'
<?php
require 'server-required/includes/archive_control.php';
require 'server-required/includes/download_redirect.php';

$settings = bm_archive_control_defaults();
$settings['archives']['archive1']['download_base_urls'] = [
    'https://dl-a.example.com',
    'https://dl-b.example.com',
];
$raw = 'https://origin.example.net/media/Movie.1080p.mkv';

$settings['archives']['archive1']['download_client_mode'] = 'all'; // V7.46: original is only valid in unrestricted client mode.
$settings['archives']['archive1']['download_link_mode'] = 'original';
if (!bm_archive_save_settings($settings)) exit(20);
if (bm_dl_wrap_url($raw, 21600, 'archive1', true) !== $raw) exit(21);

$settings = bm_archive_get_settings();
$settings['archives']['archive1']['download_link_mode'] = 'redirect';
if (!bm_archive_save_settings($settings)) exit(22);
$wrapped = bm_dl_wrap_url($raw, 21600, 'archive1', true);
if (!preg_match('~^https://dl-[ab]\\.example\\.com/~', $wrapped)) exit(23);
parse_str((string)parse_url($wrapped, PHP_URL_QUERY), $q);
$decoded = bm_dl_decode_token((string)($q['sig'] ?? ''));
if (!is_array($decoded) || ($decoded['url'] ?? '') !== $raw) exit(24);

$settings = bm_archive_get_settings();
$settings['archives']['archive1']['download_link_mode'] = 'disabled';
if (!bm_archive_save_settings($settings)) exit(25);
if (bm_dl_wrap_url($raw, 21600, 'archive1', true) !== '') exit(26);
if (bm_archive_feature_user_can_access('archive1', 'download', null)) exit(27);

echo "PHP_MODE_TEST_OK\n";
PHP

BANKMOVIE_PRIVATE_DIR="$TMP_PRIVATE" php -d display_errors=1 <<'PHP'
<?php
require 'server-required/includes/archive_control.php';
require 'server-required/includes/app_archive_policy.php';
$row = bm_app_archive_policy_row('archive1');
if (($row['download_link_mode'] ?? '') !== 'disabled') exit(30);
if (bm_app_archive_feature_scope('archive1', 'download') !== 'disabled') exit(31);
echo "APP_POLICY_MODE_TEST_OK\n";
PHP

echo V7456_DOWNLOAD_REDIRECT_MODES_OK
