#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
DOWNLOADS="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"
DRAW="$ROOT/app/src/main/res/drawable"
need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7467_MISSING: $2 in $1" >&2; exit 1; }; }
forbid() { ! grep -Fq -- "$2" "$1" || { echo "VERIFY_V7467_FORBIDDEN: $2 in $1" >&2; exit 1; }; }

# Naming and product split: Offline Gallery keeps its own SVG identity,
# while the normal downloader returns to the classic download glyph.
need "$OFFLINE" 'text = "گالری آفلاین"'
need "$MAIN" 't("گالری آفلاین", "Offline gallery")'
need "$DRAW/ic_offline_gallery.xml" 'M22,12C22,16.714 22,19.0711 20.5355,20.5355'
need "$DRAW/ic_download.xml" 'M17,9.00195C19.175,9.01406'
need "$DRAW/ic_download.xml" 'M12,2L12,15M12,15L9,11.5M12,15L15,11.5'
need "$DRAW/ic_tv_nav_download_preview.xml" 'M17,9.00195C19.175,9.01406'
forbid "$DRAW/ic_download.xml" 'M2,12.5001L3.75159,10.9675'

# Compact filters and cards match the approved reference rather than the oversized pass.
need "$OFFLINE" 'filterTab("همه", FILTER_ALL, R.drawable.ic_nav_grid)'
need "$DOWNLOADS" 'filterButton("همه", FILTER_ALL, R.drawable.ic_nav_grid)'
need "$OFFLINE" 'LinearLayout.LayoutParams(dp(if (isTvLike()) 90 else 82), dp(if (isTvLike()) 126 else 116))'
need "$DOWNLOADS" 'LinearLayout.LayoutParams(dp(if (isTvLike()) 92 else 84), dp(if (isTvLike()) 130 else 118))'
need "$OFFLINE" 'weightSum = 4f'
need "$OFFLINE" 'actionParams(first = true)'
need "$OFFLINE" 'actionParams(last = true)'

# Downloader completed row is the 3-button reference layout; deletion remains in overflow.
need "$DOWNLOADS" 'completedActionButton("اشتراک‌گذاری", R.drawable.ic_bm_share'
need "$DOWNLOADS" 'completedActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device'
need "$DOWNLOADS" 'completedActionButton("پخش آفلاین", R.drawable.ic_bm_play_offline'
forbid "$DOWNLOADS" 'actions.addView(completedActionButton("حذف", R.drawable.ic_bm_trash'
need "$DOWNLOADS" 'setItems(arrayOf("پخش آفلاین", "ارسال به دستگاه", "اشتراک‌گذاری", "حذف"))'
need "$DOWNLOADS" 'isFillViewport = status == InternalDownloadStore.STATUS_COMPLETED'
need "$DOWNLOADS" 'LinearLayout.LayoutParams(0, dp(44), 1f)'

# Preserve previous functional fixes and the V7.46.6.1 compile hotfix.
bash "$ROOT/verify_v7465_offline_adm_location_playback.sh"
bash "$ROOT/verify_v7466_1_kotlin_compile_hotfix.sh"

echo VERIFY_V7467_COMPACT_DOWNLOAD_GALLERY_UI_OK
