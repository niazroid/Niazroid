#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
OFF='app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt'
[[ -f "$MAIN" && -f "$OFF" ]] || { echo VERIFY_V7471_7_FILES_MISSING; exit 1; }
grep -q 'tvSideNavLastFocusedItem' "$MAIN"
grep -q 'V7.47.1.7 TV DRAWER STICKY FOCUS' "$MAIN"
grep -q 'focusedOrNull?.takeIf { isTvSideNavFocus(it) }' "$MAIN"
grep -q 'tvSideNavLastFocusedItem = target' "$MAIN"
grep -q 'Sticky rail: never collapse merely because focus is moving' "$MAIN"
grep -q 'wireTvFocusOrder' "$OFF"
grep -q 'requestRectangleOnScreen' "$OFF"
grep -q 'setStroke(dp(3), p.primary2)' "$OFF"
grep -q '1.055f' "$OFF"
echo VERIFY_V7471_7_TV_DRAWER_OFFLINE_FOCUS_OK
