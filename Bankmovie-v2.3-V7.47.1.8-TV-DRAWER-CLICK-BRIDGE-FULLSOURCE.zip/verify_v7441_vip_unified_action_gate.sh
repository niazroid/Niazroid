#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
draw='app/src/main/res/drawable'

# Keep all V7.44 visual/auth/player polish regressions.
bash verify_v744_vip_auth_player_polish.sh

grep -Fq 'sourceMainUpdateTwentyNinthHotfixTag=BANKMOVIE-2.3-V7441-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'vipStreamGate -> showArchiveVipGate(item, "stream")' "$main"
grep -Fq 'openPlayer(item, allLinks, index)' "$main"
grep -Fq 'val watchPartyGate = !clientScopeAllows(archiveRuntimeScope(item, "watch_party"))' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"
grep -Fq 'if (actionable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }' "$main"
grep -Fq 'if (archiveVipGateRequired(item, "stream")) {' "$main"
grep -Fq 'val protectedMetadataOnly = archiveVipGateRequired(item, "stream") ||' "$main"
grep -Fq 'remain visible and tappable without leaking the premium URL itself' "$main"
grep -Fq 'if (canDownload || item.optBoolean("downloads_locked", false)) {' "$main"

# Ordinary version/download-box Play must never bypass archive playback gates.
if grep -Fq 'bypassArchivePlaybackGates = true' "$main"; then
  echo 'V7441_ERROR: ordinary code still contains a playback-gate bypass call' >&2
  exit 1
fi

# Previous UI polish remains present.
grep -Fq 'setImageResource(R.drawable.ic_repo_close)' "$main"
grep -Fq 'setImageResource(R.drawable.ic_repo_confirm)' "$main"
grep -Fq 'V7.44 auth motion fix' "$auth"
grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"
grep -Fq 'private fun showVolumeGestureHud(volume: Int, maxVolume: Int)' "$player"
test -s "$draw/ic_repo_close.xml"
test -s "$draw/ic_repo_confirm.xml"
test -s "$draw/ic_repo_language.xml"
test -s "$draw/ic_player_volume_uiverse.xml"

echo V7441_VIP_UNIFIED_ACTION_GATE_VERIFY_OK
