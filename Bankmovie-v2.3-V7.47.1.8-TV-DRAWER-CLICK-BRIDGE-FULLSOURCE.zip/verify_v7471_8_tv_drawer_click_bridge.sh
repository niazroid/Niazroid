#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
OFF='app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt'
[[ -f "$MAIN" && -f "$OFF" ]] || { echo VERIFY_V7471_8_FILES_MISSING; exit 1; }
grep -q 'V7.47.1.8 TV DRAWER CLICK BRIDGE' "$MAIN"
grep -q 'private fun performTvSideNavClick(): Boolean' "$MAIN"
grep -q 'return performTvSideNavClick()' "$MAIN"
grep -q 'target.performClick()' "$MAIN"
grep -q 'KEYCODE_BUTTON_A' "$MAIN"
# V7.47.1.7 sticky navigation/offline focus must remain intact.
grep -q 'V7.47.1.7 TV DRAWER STICKY FOCUS' "$MAIN"
grep -q 'tvSideNavLastFocusedItem' "$MAIN"
grep -q 'wireTvFocusOrder' "$OFF"
grep -q 'requestRectangleOnScreen' "$OFF"
echo VERIFY_V7471_8_TV_DRAWER_CLICK_BRIDGE_OK
