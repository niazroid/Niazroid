# BankMovie 2.3 — V7.46.9 UI Spacing + Archive Resilience

این نسخه روی V7.46.8 ساخته شده و دو بخش دارد: پولیش رابط دانلود/گالری آفلاین و جداسازی کامل Startup از خرابی یک آرشیو.

## رابط کاربری

- فاصله بین تگ‌ها/آیکن‌های متادیتا بیشتر شده تا روی موبایل فشرده به هم نچسبند.
- فاصله بین دکمه‌های اکشن گالری آفلاین بیشتر شده است.
- آیکن تنظیمات صفحه دانلود از همان `ic_user_settings` برنامه استفاده می‌کند؛ `ic_bm_settings` دیگر در هدر دانلود استفاده نمی‌شود.
- پوستر گالری آفلاین داخل پوسته rounded قرار گرفت و با `clipToOutline` مثل کارت دانلود گوشه‌های نرم دارد.
- پخش آفلاین همچنان از SVG واقعی پلیر یعنی `ic_player_play` استفاده می‌کند.
- اصلاحات V7.46.8 شامل حذف «ارسال به دستگاه»، Flow شدن تگ‌ها و آیکن مستقل دوبله/زیرنویس/هاردساب حفظ شده‌اند.

## پایداری آرشیوها / Startup

مشکل اصلی این بود که `app_api.php?action=boot` عملاً به Archive 1 گره خورده بود و حتی `boot/init` داخل policy آرشیو 1 قرار می‌گرفت. در نتیجه Down/Hidden/Disabled شدن Archive 1 می‌توانست کل Startup را متوقف کند.

V7.46.9 این مسیر را جدا می‌کند:

- `boot/init` دیگر archive-scoped نیستند.
- Boot هیچ درخواست شبکه‌ای به Archive 1/3/4 نمی‌زند و فقط Controller/DB محلی را آماده می‌کند.
- کتابخانه‌های `api2_lib.php`، `api3_lib.php` و `api4_lib.php` lazy-load شده‌اند؛ خرابی یا نبود یکی از آن‌ها `app_api.php` را برای بقیه آرشیوها Fatal نمی‌کند.
- Section/Search/Detail/Play یک آرشیو خراب، پاسخ `degraded/source_unavailable` می‌دهد و بقیه برنامه زنده می‌ماند.
- Android برای هر آرشیو از `archiveEnabled()` استفاده می‌کند؛ Hidden هم مانند Disabled اصلاً Fetch نمی‌شود.
- Boot روی Android بعد از 4.2 ثانیه Hard Guard دارد: اگر Controller کند شود، آخرین Boot سالم یا یک Shell مینیمال باز می‌شود و Splash گیر نمی‌کند.
- `app_home_feed.php` دیگر Startup را Block نمی‌کند؛ enrichment در پس‌زمینه انجام می‌شود.
- آخرین Boot سالم در `boot_cache_v7469` ذخیره می‌شود.

## سرور

برخلاف V7.46.8، این نسخه یک تغییر سروری ضروری دارد، اما فقط در:

`app_api.php`

هیچ تغییری در `index.php` صفحه اصلی، `bm_admin.php` یا فایل‌های Homepage داده نشده است.

## تست‌های انجام‌شده

- `php -l server-required/app_api.php` پاس شد.
- Boot در محیطی که `api2_lib.php/api3_lib.php` وجود نداشتند با `ready=true` پاسخ داد.
- با Archive 1 در حالت Hidden/Disabled، Boot همچنان `ready=true` و `default_archive=2` برگرداند.
- verifierهای V7.46.5، V7.46.6.1، V7.46.8 و V7.46.9 پاس شدند.
