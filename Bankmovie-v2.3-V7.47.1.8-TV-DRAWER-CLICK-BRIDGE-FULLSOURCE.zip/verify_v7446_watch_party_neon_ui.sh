#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

# Preserve the known-good V7.44.5 gesture/VIP/archive chain.
bash verify_v7445_gesture_direction_spacing_hard_fix.sh

grep -Fq 'sourceMainUpdateThirtyFourthHotfixTag=BANKMOVIE-2.3-V7446-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Approved Watch Party neon layout.
grep -Fq 'V7.44.6 — Watch Party gets its own midnight/cyan glass language' "$player"
grep -Fq 'text = "سینمای خصوصی BankMovie"' "$player"
grep -Fq 'text = "BankMovie Watch Party"' "$player"
grep -Fq 'text = "شروع تماشا"' "$player"
grep -Fq 'text = "اعضای اتاق (${partyMembers.length()})"' "$player"
grep -Fq 'text = "گفت‌وگوی خصوصی"' "$player"
grep -Fq 'private fun sharePartyInvite()' "$player"
grep -Fq 'Intent(Intent.ACTION_SEND)' "$player"
grep -Fq 'partySoftAccent(999)' "$player"
grep -Fq 'Color.rgb(27, 225, 235)' "$player"

# Player title metadata chips from the approved mockup.
grep -Fq 'private lateinit var playerMetaRow: LinearLayout' "$player"
grep -Fq 'private fun rebuildPlayerMetaChips()' "$player"
grep -Fq 'R.drawable.ic_dubbed_mic_green' "$player"
grep -Fq 'R.drawable.ic_setup_subtitle' "$player"
grep -Fq 'R.drawable.ic_player_cc' "$player"
grep -Fq 'quality.uppercase(Locale.US)' "$player"

# Existing VIP action behaviour must remain intact.
grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"

# Syntax-shape sanity: braces/parens must balance outside strings/comments.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
stack=[]; i=0; state='code'; n=len(s)
while i<n:
    c=s[i]; nx=s[i+1] if i+1<n else ''
    if state=='code':
        if c=='/' and nx=='/': state='line'; i+=2; continue
        if c=='/' and nx=='*': state='block'; i+=2; continue
        if s[i:i+3]=='"""': state='triple'; i+=3; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append(c)
        elif c in ')]}':
            pairs={')':'(',']':'[','}':'{'}
            assert stack and stack[-1]==pairs[c], (c,i,stack[-1:] if stack else [])
            stack.pop()
        i+=1; continue
    if state=='line':
        if c=='\n': state='code'
        i+=1; continue
    if state=='block':
        if c=='*' and nx=='/': state='code'; i+=2; continue
        i+=1; continue
    if state=='string':
        if c=='\\': i+=2; continue
        if c=='"': state='code'
        i+=1; continue
    if state=='char':
        if c=='\\': i+=2; continue
        if c=="'": state='code'
        i+=1; continue
    if state=='triple':
        if s[i:i+3]=='"""': state='code'; i+=3; continue
        i+=1
assert state=='code' and not stack, (state, stack[-10:])
print('V7446_KOTLIN_SHAPE_OK')
PY

echo V7446_WATCH_PARTY_NEON_UI_VERIFY_OK
