# BankMovie V7.46.1 — همان سیستم Redirect سایت + ADM/Copy در Android

این نسخه معماری دانلود جداگانه V7.46.0 را حذف می‌کند و Android را مستقیماً به **همان سیستم لینک دانلود سایت** وصل می‌کند.

## رفتار نهایی

- سایت و `app_api.php` هر دو از `includes/download_redirect.php` مشترک استفاده می‌کنند.
- برای هر Archive، لیست ساب‌دامین‌های دانلود از همان `archive_api_settings.json` و همان BM Admin خوانده می‌شود.
- هیچ ساب‌دامینی داخل APK هاردکد نیست.
- تغییر ساب‌دامین از BM Admin برای درخواست‌های بعدی API اعمال می‌شود و نیاز به Build مجدد APK ندارد.
- Android در حالت `adm_copy` فقط `download_url` محافظت‌شده را به ADM می‌دهد یا همان را کپی می‌کند.
- `stream_url` و Player تغییر نمی‌کنند.

## Document Rootهای جدا

جدا بودن Document Root مشکلی ندارد. روی هر ساب‌دامین دانلود، همان Gateway سایت را قرار بده:

- `download_gateway.php`
- `includes/download_redirect.php`
- `includes/security_bootstrap.php`
- Rewrite route مطابق `download-route.htaccess.sample`

همه این Rootها باید به **همان کلید مشترک سایت** دسترسی داشته باشند:

`_bankmovie_private/download_redirect.key`

یا همان مقدار `BANKMOVIE_DL_REDIRECT_KEY` را در Environment داشته باشند.

در این نسخه دیگر `download_redirect.archive1.key` تا `archive4.key` و Edge اختصاصی Android وجود ندارد.

## کنترل BM Admin

برای Archive 1 تا 4:

- `download_link_mode`: redirect / original / disabled
- `download_client_mode`: adm_copy / all / disabled
- `download_base_urls`: یک یا چند ساب‌دامین HTTPS، هر کدام در یک خط

در حالت `adm_copy`، مقدار `original` خودکار به `redirect` نرمال می‌شود تا Clipboard لینک منبع را نگیرد.
