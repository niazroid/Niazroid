# BankMovie V7.45.1 — Watch Party Ready Fresh-Activity Fix

این نسخه بر پایه V7.44.9 ساخته شده و فقط مسیر «آماده‌ام / شروع تماشا» واچ‌پارتی را تغییر می‌دهد.

## علت فنی
در مسیر قدیمی، PlayerActivity ابتدا بدون VLC با لابی Watch Party باز می‌شد و پس از لمس Ready همان Activity، هم‌زمان با بسته‌شدن AlertDialog و Poll شبکه، LibVLC را به Surface متصل می‌کرد. روی بعضی MIUI/Xiaomi این ترتیب می‌تواند باعث مرگ native process چند ثانیه بعد از Ready شود.

## اصلاح
- Ready دیگر LibVLC را داخل همان Activity ایجاد نمی‌کند.
- Ready لابی را می‌بندد و PlayerActivity را با state Ready بازسازی می‌کند.
- Activity تازه، VLC را از مسیر معمول و سالم پلیر داخلی استارت می‌کند.
- Poll و heartbeat تا رویداد واقعی `MediaPlayer.Event.Playing` متوقف می‌مانند.
- بعد از Stable شدن Player، Sync با تأخیر کوتاه دوباره فعال می‌شود.
- Guard برای جلوگیری از start هم‌زمان/تکراری VLC در مسیر Guest اضافه شد.
- Heartbeat فقط وقتی Ready + Player Stable + player != null است اجرا می‌شود.
- رفتار Hard Gate لابی (عدم بسته‌شدن قبل از Ready) حفظ شده است.

## فایل تغییر کرده
- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`

## سرور
هیچ فایل سمت سرور/هاست تغییر نکرده است.
