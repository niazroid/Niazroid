#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
draw='app/src/main/res/drawable'
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

# Preserve archive/section/VIP behavior from the known-good chain.
bash verify_v7431_section_hard_hide.sh
grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'vipStreamGate -> showArchiveVipGate(item, "stream")' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"
grep -Fq 'if (actionable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }' "$main"
if grep -Fq 'bypassArchivePlaybackGates = true' "$main"; then
  echo 'V7445_ERROR: ordinary playback still bypasses VIP gates' >&2
  exit 1
fi

grep -Fq 'sourceMainUpdateThirtyThirdHotfixTag=BANKMOVIE-2.3-V7445-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Exact CC/audio controls preserved.
grep -Fq 'setImageResource(R.drawable.ic_player_cc)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_audio)' "$player"
if grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"; then
  echo 'V7445_ERROR: language globe must not be used inside PlayerActivity' >&2
  exit 1
fi

# User SVG geometry preserved exactly.
grep -Fq 'M3,9v6h4l5,5V4L7,9H3z' "$draw/ic_player_volume_gesture.xml"
grep -Fq 'M20,8.69V4h-4.69L12,0.69' "$draw/ic_player_brightness_gesture.xml"

# Hard direction fix: raw screen Y, incremental, UP => positive step.
grep -Fq 'touchStartRawY = e.rawY' "$player"
grep -Fq 'lastGestureRawY = e.rawY' "$player"
grep -Fq 'val stepUpPx = lastGestureRawY - e.rawY' "$player"
grep -Fq 'val stepRatio = (stepUpPx / root.height) * 1.42f' "$player"
grep -Fq 'val stepPercent = (stepUpPx / root.height) * 205f' "$player"
if grep -Fq 'val deltaRatio = ((touchStartY - e.y)' "$player"; then
  echo 'V7445_ERROR: old local-Y brightness direction logic still present' >&2
  exit 1
fi
if grep -Fq 'val deltaPercent = ((touchStartY - e.y)' "$player"; then
  echo 'V7445_ERROR: old local-Y volume direction logic still present' >&2
  exit 1
fi

# Fill is explicitly bottom-anchored; high values grow upward.
grep -Fq 'pivotY = volumeGestureTrackHeightPx.toFloat()' "$player"
grep -Fq 'pivotY = brightnessGestureTrackHeightPx.toFloat()' "$player"
grep -Fq 'volumeGestureLevel.scaleY = trackRatio' "$player"
grep -Fq 'brightnessGestureLevel.scaleY = ratio' "$player"

# SVG/slider spacing hard fix for BOTH volume and brightness.
grep -Fq 'FrameLayout.LayoutParams(dp(150), dp(198), Gravity.START or Gravity.CENTER_VERTICAL)' "$player"
grep -Fq 'FrameLayout.LayoutParams(dp(174), dp(198), Gravity.END or Gravity.CENTER_VERTICAL)' "$player"
count_icon_gap="$(grep -Fc 'FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL)' "$player")"
[[ "$count_icon_gap" -ge 2 ]] || { echo 'V7445_ERROR: both gesture icons must use the spaced 26dp slot' >&2; exit 1; }
count_bottom_margin="$(grep -Fc 'bottomMargin = dp(12)' "$player")"
[[ "$count_bottom_margin" -ge 2 ]] || { echo 'V7445_ERROR: both SVG icons must have bottom spacing' >&2; exit 1; }

# VLC boost remains available to 200%.
grep -Fq 'private const val VOLUME_BOOST_MAX_PERCENT = 200f' "$player"
grep -Fq 'target.javaClass.getMethod("setVolume", Integer.TYPE).invoke(target, safe)' "$player"
grep -Fq 'applyVlcAmplification(percent.roundToInt())' "$player"

python3 - <<'PY'
import xml.etree.ElementTree as ET
for path in [
    'app/src/main/res/drawable/ic_player_volume_gesture.xml',
    'app/src/main/res/drawable/ic_player_brightness_gesture.xml',
    'app/src/main/res/drawable/ic_player_cc.xml',
    'app/src/main/res/drawable/ic_player_audio.xml',
]:
    ET.parse(path)
print('V7445_VECTOR_XML_OK')
PY

echo V7445_GESTURE_DIRECTION_SPACING_HARD_FIX_VERIFY_OK
