#!/usr/bin/env bash
set -euo pipefail
MAIN="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
FCM="app/src/main/java/ir/bankmoviee/app/BankMovieFirebaseMessagingService.kt"
JOB="app/src/main/java/ir/bankmoviee/app/AdminPushJobService.kt"
TG="app/src/main/res/drawable/ic_telegram.xml"
RETRY="app/src/main/res/drawable/ic_retry_cycle.xml"

for f in "$MAIN" "$FCM" "$JOB" "$TG" "$RETRY"; do test -s "$f"; done

# Notification tap contract: no-link push behaves as a normal launcher start.
! grep -q 'putExtra("open_notifications", true)' "$FCM"
! grep -q 'putExtra("open_notifications", true)' "$JOB"
grep -q 'putExtra("admin_push_tap", true)' "$FCM"
grep -q 'putExtra("admin_push_tap", true)' "$JOB"
grep -q 'captureAdminPushIntent(intent)' "$MAIN"
grep -q 'consumePendingAdminPushUrl()' "$MAIN"
grep -q 'if (!appShellBuilt || !::root.isInitialized || !::content.isInitialized) return' "$MAIN"
grep -q '(scheme == "http" || scheme == "https") && !uri.host.isNullOrBlank()' "$MAIN"
# Old cold-start behavior called the notification UI from startup before Home existed.
! grep -A40 'private fun continueAppStartup' "$MAIN" | grep -q 'showNotificationCenter()'

# External intents are now double-guarded instead of rethrowing in the catch branch.
grep -A20 'private fun openExternal' "$MAIN" | grep -q 'No app can open this link'

# Rail actions use full-width spaced row and preserve the real Telegram/Bale icon colors.
grep -q 'private fun sizedDrawable(resId: Int, sizePx: Int): Drawable?' "$MAIN"
grep -q 'sizedDrawable(if (emergencyChannelIsBale()) R.drawable.ic_bale else R.drawable.ic_telegram, dp(18))' "$MAIN"
grep -q 'fun actionParams() = LinearLayout.LayoutParams(0, dp(40), 1f)' "$MAIN"
grep -q 'marginStart = dp(4)' "$MAIN"
grep -q 'marginEnd = dp(4)' "$MAIN"
grep -q 'tintedDrawable(R.drawable.ic_retry_cycle, p.onPrimary, dp(18))' "$MAIN"

echo V7471_3_NOTIFICATION_TAP_RAIL_ACTIONS_OK
