# BankMovie V7.45.3 — Watch Party Chat Drawer / IME Polish

این نسخه روی تجربه‌ی چت واچ‌پارتی در حالت Landscape تمرکز دارد.

## تغییرات

- چت واچ‌پارتی به پنل جانبی تمیزتر با هدر جدید، وضعیت اعضای آنلاین، پس‌زمینه Navy/Cyan و Composer ثابت در پایین تبدیل شد.
- کادر تایپ همیشه پایین پنل پین است و با باز شدن کیبورد همراه پنجره Resize می‌شود تا متن تایپ‌شده جلوی کاربر بماند.
- برای جلوگیری از Fullscreen / Extract Mode کیبورد در Landscape از `IME_FLAG_NO_FULLSCREEN` و `IME_FLAG_NO_EXTRACT_UI` استفاده شده است.
- روی پنجره‌ی چت `SOFT_INPUT_ADJUST_RESIZE` و `FLAG_ALT_FOCUSABLE_IM` پاک شده تا IME بتواند پنل را درست Resize کند.
- هنگام باز شدن چت، فوکوس مستقیم روی ورودی می‌رود و کیبورد به‌صورت Inline باز می‌شود.
- کلید Send کیبورد هم پیام را ارسال می‌کند و Composer بعد از ارسال باز می‌ماند.
- آیکون ایموجی/استیکر از SVG/Vector خود پروژه (`ic_party_emoji`) استفاده می‌کند.
- Badge متنی VIP/ADMIN داخل پیام‌ها با آیکون‌های واقعی پروژه (`ic_profile_vip` و `ic_admin_verified`) جایگزین شد.
- Bubble پیام‌های خود کاربر و بقیه اعضا از نظر رنگ، Stroke، Padding و خوانایی بازطراحی شدند.

## فایل تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`

## سرور

هیچ تغییر سمت سرور لازم نیست.
