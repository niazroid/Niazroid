# BankMovie 2.3 — V7.47.1.5

- Player meta HUD با Glass/Accent خود اپ یکدست شد؛ چیپ تکراری «زیرنویس» حذف شد و CC تنها ورودی تنظیمات صدا/زیرنویس است.
- TV Home: ورود آخرین rail به «پخش هفتگی» قبل از focus، بخش Weekly را داخل viewport می‌آورد و focus همان target زنده را تأیید می‌کند.
- TV side rail داخل ScrollView واقعی قرار گرفت؛ فوکس آیتم‌های پایین منو را همراه خود اسکرول می‌کند و دیگر زیر Profile پنهان نمی‌شود.
- Downloader TV: Header/Filter/Shell/Card/Action مسیر عمودی صریح دارند؛ overflow هر کارت دیگر فوکس را قفل نمی‌کند. نمایش صف فعال هم queue_order واقعی را رعایت می‌کند، بنابراین «اول صف/آخر صف» فوراً در ترتیب UI دیده می‌شود.
- Box Office TV: bootstrap اولین DPAD اصلاح شد؛ DOWN از وضعیت اولیه مستقیم حرکت طبیعی #1 → #2 دارد و دیگر UP اولیه برای فعال‌شدن فوکس لازم نیست.
- Profile Hero و VIP purchase در TV همان design-tokenهای Glass/Tint و palette اپ موبایل را استفاده می‌کنند؛ فقط scale تلویزیون متفاوت است.
- همه اصلاحات V7.47.1.4 (Remote روی bankmoviez.top، navigation quick setting، back animation، series copy، full-dismiss sheets) حفظ شده‌اند.
- Rail اسکرولی TV با visibility خود bottom-nav همگام شد؛ Detail/VIP/Player دیگر قاب خالی ناوبری را بعد از مخفی‌شدن منو باقی نمی‌گذارند.
- verifier تاریخی V7.47.1.4 برای cumulative release جدید backward-compatible شد تا workflow جدید روی نام V7.47.1.5 false-fail ندهد.
- زنجیره verifierهای workflow از V7.45.4 تا V7.47.1.5، PHP lint و YAML parse روی سورس نهایی پاس شده‌اند.
