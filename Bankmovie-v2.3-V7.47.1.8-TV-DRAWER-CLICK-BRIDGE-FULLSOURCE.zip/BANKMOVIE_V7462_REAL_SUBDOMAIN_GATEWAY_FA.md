# BankMovie V7.46.2 — اتصال دقیق Android به Redirect واقعی ساب‌دامین‌های سایت

این نسخه Gateway ساختگی/موازی V7.46.1 را کنار می‌گذارد و دقیقاً با ساختار واقعی ساب‌دامین دانلود کار می‌کند:

- هر Archive تنظیم `download_base_urls` مستقل در BM Admin دارد.
- `includes/download_redirect.php` در سایت اصلی token و pretty URL را می‌سازد.
- هر ساب‌دامین با Document Root مستقل فقط `index.php` و `.htaccess` واقعی خودش را دارد.
- `.htaccess` مسیرهای pretty و legacy `/r/<token>` را به `index.php` می‌فرستد.
- `index.php` helper اصلی سایت (`/includes/download_redirect.php`) را به‌صورت path-resilient پیدا می‌کند و همان token را decode می‌کند.
- Android از `download_url` API استفاده می‌کند؛ هیچ ساب‌دامینی در APK hardcode نیست.
- تغییر ساب‌دامین Archive از BM Admin از درخواست بعدی API اعمال می‌شود و APK جدید لازم ندارد.
- `adm_copy` همچنان فقط ADM + Clipboard محافظت‌شده است و browser fallback ندارد.
