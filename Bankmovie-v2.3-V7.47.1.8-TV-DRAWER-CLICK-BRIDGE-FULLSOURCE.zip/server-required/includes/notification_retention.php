<?php
/**
 * BankMovie notification retention + normalized global notification state.
 * V7.47.0
 */

if (!function_exists('bm_notification_retention_ensure')) {
    function bm_notification_retention_ensure(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_notification_gc_state (
            task_key VARCHAR(80) NOT NULL PRIMARY KEY,
            last_run DATETIME NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS app_notification_global_state (
            user_id INT UNSIGNED NOT NULL,
            notification_id INT UNSIGNED NOT NULL,
            read_at DATETIME NULL,
            dismissed_at DATETIME NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (user_id, notification_id),
            KEY idx_global_notification (notification_id),
            KEY idx_global_state_updated (updated_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // Cleanup is frequent enough that a created_at index matters on installs
        // with thousands of legacy per-user rows.
        try { $pdo->exec("CREATE INDEX idx_app_notifications_created ON app_notifications (created_at)"); } catch (Throwable $e) {}
        try { $pdo->exec("CREATE INDEX idx_notifications_created ON notifications (created_at)"); } catch (Throwable $e) {}
    }
}

if (!function_exists('bm_notification_retention_run')) {
    function bm_notification_retention_run(PDO $pdo, bool $force = false, bool $compact = false): array {
        bm_notification_retention_ensure($pdo);
        $now = time();
        $shouldRun = $force;
        if (!$shouldRun) {
            try {
                $stmt = $pdo->prepare("SELECT last_run FROM app_notification_gc_state WHERE task_key='notifications' LIMIT 1");
                $stmt->execute();
                $last = (string)($stmt->fetchColumn() ?: '');
                $lastTs = $last !== '' ? strtotime($last) : false;
                $shouldRun = ($lastTs === false || $lastTs < ($now - 21600)); // max once / 6h
            } catch (Throwable $e) {
                $shouldRun = true;
            }
        }
        if (!$shouldRun) return ['ran'=>false,'deleted_app'=>0,'deleted_global'=>0,'deleted_state'=>0,'compacted'=>false];

        $deletedApp = 0;
        $deletedGlobal = 0;
        $deletedState = 0;
        $deletedLegacy = 0;

        // One-time V7.47 normalization: old admin broadcasts were duplicated
        // into app_notifications once per user. Remove those copies once. Old
        // clients can still recreate only the latest broadcast via the legacy
        // compatibility path; protocol-v2 clients never duplicate globals.
        try {
            $claim = $pdo->prepare("INSERT IGNORE INTO app_notification_gc_state(task_key,last_run) VALUES('notifications_v2_migration',NOW())");
            $claim->execute();
            if ($claim->rowCount() > 0) {
                $deletedLegacy = (int)$pdo->exec("DELETE FROM app_notifications WHERE dedupe_key LIKE 'global-admin:%'");
            }
        } catch (Throwable $e) { error_log('notification v2 migration: ' . $e->getMessage()); }
        try {
            // Hard retention requested by BankMovie: personal notification rows
            // are not kept beyond seven days.
            $deletedApp = (int)$pdo->exec("DELETE FROM app_notifications WHERE created_at < (NOW() - INTERVAL 7 DAY)");
        } catch (Throwable $e) { error_log('notification gc app_notifications: ' . $e->getMessage()); }

        try {
            // Broadcast rows live once in `notifications`; expired/old broadcasts
            // disappear physically instead of accumulating forever.
            $deletedGlobal = (int)$pdo->exec("DELETE FROM notifications
                WHERE (expires_at IS NOT NULL AND expires_at <= NOW())
                   OR created_at < (NOW() - INTERVAL 7 DAY)");
        } catch (Throwable $e) { error_log('notification gc notifications: ' . $e->getMessage()); }

        try {
            $deletedState = (int)$pdo->exec("DELETE s FROM app_notification_global_state s
                LEFT JOIN notifications n ON n.id=s.notification_id
                WHERE n.id IS NULL OR s.updated_at < (NOW() - INTERVAL 8 DAY)");
        } catch (Throwable $e) { error_log('notification gc global state: ' . $e->getMessage()); }

        try {
            $up = $pdo->prepare("INSERT INTO app_notification_gc_state(task_key,last_run) VALUES('notifications',NOW())
                ON DUPLICATE KEY UPDATE last_run=VALUES(last_run)");
            $up->execute();
        } catch (Throwable $e) {}

        $compacted = false;
        if ($compact) {
            // This is only used by the explicit admin maintenance button. InnoDB
            // may keep allocated pages after DELETE until OPTIMIZE rebuilds them.
            foreach (['app_notifications','notifications','app_notification_global_state'] as $table) {
                try { $pdo->exec("OPTIMIZE TABLE `$table`"); $compacted = true; }
                catch (Throwable $e) { error_log('notification optimize ' . $table . ': ' . $e->getMessage()); }
            }
        }

        return [
            'ran'=>true,
            'deleted_app'=>$deletedApp,
            'deleted_global'=>$deletedGlobal,
            'deleted_state'=>$deletedState,
            'compacted'=>$compacted,
            'deleted_legacy'=>$deletedLegacy,
        ];
    }
}

if (!function_exists('bm_notification_global_state_upsert')) {
    function bm_notification_global_state_upsert(PDO $pdo, int $userId, int $notificationId, bool $read, bool $dismiss): void {
        if ($userId <= 0 || $notificationId <= 0) return;
        bm_notification_retention_ensure($pdo);
        $sql = "INSERT INTO app_notification_global_state(user_id,notification_id,read_at,dismissed_at,updated_at)
                VALUES(?,?," . ($read ? 'NOW()' : 'NULL') . "," . ($dismiss ? 'NOW()' : 'NULL') . ",NOW())
                ON DUPLICATE KEY UPDATE
                    read_at=" . ($read ? 'COALESCE(read_at,NOW())' : 'read_at') . ",
                    dismissed_at=" . ($dismiss ? 'COALESCE(dismissed_at,NOW())' : 'dismissed_at') . ",
                    updated_at=NOW()";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId,$notificationId]);
    }
}

if (!function_exists('bm_notification_global_rows')) {
    function bm_notification_global_rows(PDO $pdo, int $userId, int $limit = 30): array {
        if ($userId <= 0) return [];
        bm_notification_retention_ensure($pdo);
        $limit = max(1, min(50, $limit));
        $sql = "SELECT n.id,n.title,n.message,n.link,n.image,n.created_at,n.expires_at,
                       s.read_at,s.dismissed_at,
                       GREATEST(0,TIMESTAMPDIFF(SECOND,n.created_at,NOW())) AS age_seconds
                FROM notifications n
                LEFT JOIN app_notification_global_state s
                  ON s.notification_id=n.id AND s.user_id=?
                WHERE n.is_active=1
                  AND (n.expires_at IS NULL OR n.expires_at>NOW())
                  AND n.created_at >= (NOW() - INTERVAL 7 DAY)
                  AND s.dismissed_at IS NULL
                ORDER BY n.created_at DESC,n.id DESC
                LIMIT $limit";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$userId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }
}

if (!function_exists('bm_notification_global_unread_count')) {
    function bm_notification_global_unread_count(PDO $pdo, int $userId): int {
        if ($userId <= 0) return 0;
        bm_notification_retention_ensure($pdo);
        $stmt = $pdo->prepare("SELECT COUNT(*)
            FROM notifications n
            LEFT JOIN app_notification_global_state s
              ON s.notification_id=n.id AND s.user_id=?
            WHERE n.is_active=1
              AND (n.expires_at IS NULL OR n.expires_at>NOW())
              AND n.created_at >= (NOW() - INTERVAL 7 DAY)
              AND s.dismissed_at IS NULL
              AND s.read_at IS NULL");
        $stmt->execute([$userId]);
        return (int)$stmt->fetchColumn();
    }
}
