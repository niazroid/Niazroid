<?php
declare(strict_types=1);

/**
 * BankMovie V226 — Download Main-Domain Manager
 *
 * Goal:
 *   dls4.old-domain.tld/path -> dls4.new-domain.tld/path
 *   dls7.old-domain.tld/path -> dls7.new-domain.tld/path
 *
 * The subdomain prefix, scheme, port, path, query and fragment stay intact.
 * Existing DB links are migrated only after a Preview.
 * Future imported/admin-entered links are normalized by the active rule chain.
 *
 * No new DB table is created. Settings/preview/history live in private JSON.
 */

if (!function_exists('bm_security_private_path')) {
    require_once __DIR__ . '/security_bootstrap.php';
}

if (!function_exists('bm_ddm_domain')) {
    function bm_ddm_domain(string $value): string
    {
        $value = strtolower(trim($value));
        if ($value === '') return '';
        if (str_starts_with($value, '*.')) $value = substr($value, 2);

        if (str_contains($value, '://')) {
            $host = (string)(parse_url($value, PHP_URL_HOST) ?: '');
            $value = strtolower(trim($host));
        } else {
            $value = preg_replace('~[/?#].*$~', '', $value) ?? $value;
            $value = preg_replace('~:\d+$~', '', $value) ?? $value;
        }

        $value = trim($value, ". \t\n\r\0\x0B");
        if (
            $value === '' ||
            strlen($value) > 253 ||
            !str_contains($value, '.') ||
            !preg_match('~^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$~', $value)
        ) {
            return '';
        }
        return $value;
    }
}

if (!function_exists('bm_ddm_settings_path')) {
    function bm_ddm_settings_path(): string
    {
        return bm_security_private_path('download-domain-settings.json');
    }
}

if (!function_exists('bm_ddm_preview_path')) {
    function bm_ddm_preview_path(): string
    {
        return bm_security_private_path('download-domain-preview.json');
    }
}

if (!function_exists('bm_ddm_history_path')) {
    function bm_ddm_history_path(): string
    {
        return bm_security_private_path('download-domain-history.json');
    }
}

if (!function_exists('bm_ddm_atomic_json_write')) {
    function bm_ddm_atomic_json_write(string $path, array $data): bool
    {
        $dir = dirname($path);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        if (!is_string($json)) return false;
        $tmp = $path . '.tmp-' . bin2hex(random_bytes(4));
        if (@file_put_contents($tmp, $json . "\n", LOCK_EX) === false) return false;
        @chmod($tmp, 0600);
        if (@rename($tmp, $path)) return true;
        @unlink($tmp);
        return false;
    }
}

if (!function_exists('bm_ddm_settings')) {
    function bm_ddm_settings(bool $refresh = false): array
    {
        static $cache = null;
        if (!$refresh && is_array($cache)) return $cache;
        $default = ['version'=>226, 'enabled'=>true, 'rules'=>[], 'updated_at'=>null];
        $raw = is_file(bm_ddm_settings_path()) ? @file_get_contents(bm_ddm_settings_path()) : false;
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) $data = [];
        $out = array_replace($default, $data);

        $rules = [];
        foreach ((array)($out['rules'] ?? []) as $r) {
            if (!is_array($r)) continue;
            $from = bm_ddm_domain((string)($r['from'] ?? ''));
            $to = bm_ddm_domain((string)($r['to'] ?? ''));
            if ($from === '' || $to === '' || $from === $to) continue;
            $rules[] = [
                'from'=>$from,
                'to'=>$to,
                'created_at'=>(string)($r['created_at'] ?? ''),
            ];
        }
        $out['rules'] = array_slice($rules, -10);
        $out['enabled'] = !array_key_exists('enabled', $out) || (bool)$out['enabled'];
        return $cache = $out;
    }
}

if (!function_exists('bm_ddm_save_settings')) {
    function bm_ddm_save_settings(array $settings): bool
    {
        $settings['version'] = 226;
        $settings['updated_at'] = gmdate('c');
        $ok = bm_ddm_atomic_json_write(bm_ddm_settings_path(), $settings);
        if ($ok) bm_ddm_settings(true);
        return $ok;
    }
}

if (!function_exists('bm_ddm_rewrite_url')) {
    function bm_ddm_rewrite_url(string $url, string $fromDomain, string $toDomain): string
    {
        $url = trim($url);
        $fromDomain = bm_ddm_domain($fromDomain);
        $toDomain = bm_ddm_domain($toDomain);
        if ($url === '' || $fromDomain === '' || $toDomain === '' || $fromDomain === $toDomain) return $url;

        $parts = @parse_url($url);
        if (!is_array($parts)) return $url;
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
        if (!in_array($scheme, ['http','https'], true) || $host === '') return $url;

        if ($host === $fromDomain) {
            $newHost = $toDomain;
        } elseif (str_ends_with($host, '.' . $fromDomain)) {
            $prefix = substr($host, 0, -strlen($fromDomain));
            $newHost = $prefix . $toDomain;
        } else {
            return $url;
        }

        $auth = '';
        if (isset($parts['user'])) {
            $auth .= $parts['user'];
            if (isset($parts['pass'])) $auth .= ':' . $parts['pass'];
            $auth .= '@';
        }
        $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
        $path = (string)($parts['path'] ?? '');
        $query = isset($parts['query']) ? '?' . $parts['query'] : '';
        $fragment = isset($parts['fragment']) ? '#' . $parts['fragment'] : '';

        return $scheme . '://' . $auth . $newHost . $port . $path . $query . $fragment;
    }
}

if (!function_exists('bm_ddm_apply_active_url')) {
    function bm_ddm_apply_active_url(string $url): string
    {
        $settings = bm_ddm_settings();
        if (empty($settings['enabled'])) return trim($url);
        $out = trim($url);
        foreach ((array)($settings['rules'] ?? []) as $rule) {
            $out = bm_ddm_rewrite_url($out, (string)$rule['from'], (string)$rule['to']);
        }
        return $out;
    }
}

if (!function_exists('bm_ddm_table_exists')) {
    function bm_ddm_table_exists(PDO $pdo, string $table): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
        try {
            $pdo->query("SELECT 1 FROM `{$table}` LIMIT 0");
            return true;
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_ddm_columns')) {
    function bm_ddm_columns(PDO $pdo, string $table): array
    {
        if (!bm_ddm_table_exists($pdo, $table)) return [];
        try {
            $rows = $pdo->query("SHOW COLUMNS FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $out = [];
            foreach ($rows as $row) {
                $name = (string)($row['Field'] ?? '');
                if ($name !== '') $out[$name] = true;
            }
            return $out;
        } catch (Throwable $e) {
            return [];
        }
    }
}

if (!function_exists('bm_ddm_targets')) {
    function bm_ddm_targets(PDO $pdo): array
    {
        $targets = [];
        foreach ([
            'softsub_links'=>['url','subtitle_url'],
            'dubbed_links'=>['url'],
            'nosub_links'=>['url'],
        ] as $table=>$columns) {
            if (!bm_ddm_table_exists($pdo, $table)) continue;
            $existing = bm_ddm_columns($pdo, $table);
            foreach ($columns as $column) {
                if (isset($existing[$column])) $targets[] = ['table'=>$table,'column'=>$column];
            }
        }
        return $targets;
    }
}

if (!function_exists('bm_ddm_host_expr')) {
    function bm_ddm_host_expr(string $column): string
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $column)) throw new InvalidArgumentException('invalid column');
        // host only, without scheme/path and without a simple :port suffix
        return "LOWER(SUBSTRING_INDEX(SUBSTRING_INDEX(SUBSTRING(TRIM(`{$column}`), LOCATE('://', TRIM(`{$column}`)) + 3), '/', 1), ':', 1))";
    }
}

if (!function_exists('bm_ddm_match_sql')) {
    function bm_ddm_match_sql(string $column): string
    {
        $host = bm_ddm_host_expr($column);
        return "TRIM(`{$column}`)<>'' AND LOCATE('://', TRIM(`{$column}`))>0 AND ({$host}=? OR {$host} LIKE ?)";
    }
}

if (!function_exists('bm_ddm_count_target')) {
    function bm_ddm_count_target(PDO $pdo, string $table, string $column, string $fromDomain): int
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table.$column)) return 0;
        $where = bm_ddm_match_sql($column);
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM `{$table}` WHERE {$where}");
        $stmt->execute([$fromDomain, '%.' . $fromDomain]);
        return (int)$stmt->fetchColumn();
    }
}

if (!function_exists('bm_ddm_preview')) {
    function bm_ddm_preview(PDO $pdo, string $fromInput, string $toInput): array
    {
        $from = bm_ddm_domain($fromInput);
        $to = bm_ddm_domain($toInput);
        if ($from === '' || $to === '') throw new RuntimeException('دامنه قبلی/جدید معتبر نیست. فقط دامنه اصلی مثل example.com وارد کن.');
        if ($from === $to) throw new RuntimeException('دامنه قبلی و جدید یکی هستند.');

        $result = [
            'version'=>226,
            'from'=>$from,
            'to'=>$to,
            'created_at'=>gmdate('c'),
            'created_ts'=>time(),
            'expires_ts'=>time()+1800,
            'targets'=>[],
            'total'=>0,
            'samples'=>[],
        ];

        foreach (bm_ddm_targets($pdo) as $target) {
            $table = $target['table'];
            $column = $target['column'];
            $count = bm_ddm_count_target($pdo, $table, $column, $from);
            $result['targets'][] = ['table'=>$table,'column'=>$column,'count'=>$count];
            $result['total'] += $count;

            if ($count > 0 && count($result['samples']) < 8) {
                $where = bm_ddm_match_sql($column);
                $stmt = $pdo->prepare("SELECT `id`,`{$column}` AS u FROM `{$table}` WHERE {$where} ORDER BY `id` ASC LIMIT 3");
                $stmt->execute([$from, '%.' . $from]);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
                    $oldUrl = trim((string)($row['u'] ?? ''));
                    if ($oldUrl === '') continue;
                    $result['samples'][] = [
                        'table'=>$table,
                        'column'=>$column,
                        'id'=>(int)($row['id'] ?? 0),
                        'before'=>$oldUrl,
                        'after'=>bm_ddm_rewrite_url($oldUrl, $from, $to),
                    ];
                    if (count($result['samples']) >= 8) break;
                }
            }
        }

        if (!bm_ddm_atomic_json_write(bm_ddm_preview_path(), $result)) {
            throw new RuntimeException('ذخیره Preview خصوصی ناموفق بود.');
        }
        return $result;
    }
}

if (!function_exists('bm_ddm_load_preview')) {
    function bm_ddm_load_preview(): array
    {
        $raw = is_file(bm_ddm_preview_path()) ? @file_get_contents(bm_ddm_preview_path()) : false;
        $data = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($data)) return [];
        if ((int)($data['expires_ts'] ?? 0) < time()) return [];
        return $data;
    }
}

if (!function_exists('bm_ddm_update_target')) {
    function bm_ddm_update_target(PDO $pdo, string $table, string $column, string $from, string $to): int
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table.$column)) return 0;
        $where = bm_ddm_match_sql($column);

        // Rebuild only the hostname portion. Subdomain remains exactly the
        // same; path/query/fragment are never touched by REPLACE.
        $trim = "TRIM(`{$column}`)";
        $rest = "SUBSTRING({$trim}, LOCATE('://', {$trim}) + 3)";
        $hostPort = "SUBSTRING_INDEX({$rest}, '/', 1)";
        $suffix = "SUBSTRING({$rest}, LENGTH({$hostPort}) + 1)";
        $schemePrefix = "LEFT({$trim}, LOCATE('://', {$trim}) + 2)";
        $newHostPort = "REPLACE(LOWER({$hostPort}), ?, ?)";

        $sql = "UPDATE `{$table}`
                SET `{$column}` = CONCAT({$schemePrefix}, {$newHostPort}, {$suffix})
                WHERE {$where}";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$from, $to, $from, '%.' . $from]);
        return max(0, $stmt->rowCount());
    }
}

if (!function_exists('bm_ddm_add_rule')) {
    function bm_ddm_add_rule(string $from, string $to, array $lastResult = []): bool
    {
        $settings = bm_ddm_settings(true);
        $rules = [];
        foreach ((array)($settings['rules'] ?? []) as $r) {
            if (!is_array($r)) continue;
            if (($r['from'] ?? '') === $from && ($r['to'] ?? '') === $to) continue;
            $rules[] = $r;
        }
        $rules[] = ['from'=>$from,'to'=>$to,'created_at'=>gmdate('c')];
        $settings['rules'] = array_slice($rules, -10);
        $settings['enabled'] = true;
        $settings['last_result'] = $lastResult;
        return bm_ddm_save_settings($settings);
    }
}

if (!function_exists('bm_ddm_append_history')) {
    function bm_ddm_append_history(array $row): void
    {
        $raw = is_file(bm_ddm_history_path()) ? @file_get_contents(bm_ddm_history_path()) : false;
        $data = is_string($raw) ? json_decode($raw, true) : null;
        $history = is_array($data) ? (array)($data['items'] ?? []) : [];
        $history[] = $row;
        $history = array_slice($history, -20);
        bm_ddm_atomic_json_write(bm_ddm_history_path(), ['version'=>226,'items'=>$history]);
    }
}

if (!function_exists('bm_ddm_apply_preview')) {
    function bm_ddm_apply_preview(PDO $pdo): array
    {
        $preview = bm_ddm_load_preview();
        if (!$preview) throw new RuntimeException('Preview معتبر نیست یا بیشتر از ۳۰ دقیقه گذشته؛ دوباره Preview بگیر.');

        $from = bm_ddm_domain((string)($preview['from'] ?? ''));
        $to = bm_ddm_domain((string)($preview['to'] ?? ''));
        if ($from === '' || $to === '' || $from === $to) throw new RuntimeException('Preview دامنه نامعتبر است.');

        @set_time_limit(120);
        $result = [
            'from'=>$from,'to'=>$to,'changed'=>0,'targets'=>[],
            'started_at'=>gmdate('c'),'ok'=>false,
        ];

        try {
            if (!$pdo->inTransaction()) $pdo->beginTransaction();
            foreach (bm_ddm_targets($pdo) as $target) {
                $n = bm_ddm_update_target($pdo, $target['table'], $target['column'], $from, $to);
                $result['targets'][] = ['table'=>$target['table'],'column'=>$target['column'],'changed'=>$n];
                $result['changed'] += $n;
            }
            $pdo->commit();
            $result['ok'] = true;
            $result['finished_at'] = gmdate('c');

            if (!bm_ddm_add_rule($from, $to, $result)) {
                // DB is already migrated, so keep it successful and log the
                // config failure loudly instead of trying to rollback DB.
                error_log('V226 download-domain DB migrated but active rule could not be saved.');
                $result['rule_saved'] = false;
            } else {
                $result['rule_saved'] = true;
            }
            bm_ddm_append_history($result);
            @unlink(bm_ddm_preview_path());
            return $result;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_ddm_clear_rules')) {
    function bm_ddm_clear_rules(): bool
    {
        $settings = bm_ddm_settings(true);
        $settings['rules'] = [];
        $settings['enabled'] = false;
        return bm_ddm_save_settings($settings);
    }
}

if (!function_exists('bm_ddm_status')) {
    function bm_ddm_status(PDO $pdo): array
    {
        $settings = bm_ddm_settings();
        return [
            'settings'=>$settings,
            'preview'=>bm_ddm_load_preview(),
            'targets'=>bm_ddm_targets($pdo),
        ];
    }
}
