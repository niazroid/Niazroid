BankMovie V7.46.3 — ROOT واقعی ساب‌دامین دانلود
================================================

این پوشه دقیقاً بر اساس index.php و .htaccess واقعی ارسال‌شده از ساب‌دامین دانلود ساخته شده است.

برای هر ساب‌دامین دانلود که Document Root جدا دارد:
1) همین index.php و .htaccess را در Document Root همان ساب‌دامین قرار بده.
2) فایل includes/download_redirect.php را داخل Root ساب‌دامین کپی نکن؛ index.php خودش helper اصلی سایت را پیدا می‌کند.
3) اگر مسیر هاست خاص است، BANKMOVIE_APP_ROOT را روی Document Root سایت اصلی BankMovie تنظیم کن.
4) در BM Admin، داخل کارت همان Archive، آدرس HTTPS این ساب‌دامین را در «دامنه‌های ریدایرکت دانلود همین آرشیو» وارد کن.
5) اگر هر Archive یک ساب‌دامین مستقل دارد، برای هر کارت Archive فقط ساب‌دامین مربوط به همان Archive را ثبت کن.

جریان واقعی:
BM Admin -> archiveX.download_base_urls -> includes/download_redirect.php -> download_url امضاشده
-> ساب‌دامین واقعی / pretty path -> .htaccess -> index.php -> helper اصلی سایت
-> bm_dl_decode_token -> HTTP 302 به منبع

Android فقط download_url برگشتی API را می‌گیرد. دامنه دانلود داخل APK هاردکد نیست.
در حالت adm_copy فقط ADM و Copy از همین download_url استفاده می‌کنند.

کلید اصلی BM Admin:
- روشن: لینک‌های محافظت‌شده طبق تنظیم هر آرشیو ساخته می‌شوند.
- خاموش: لینک‌ها فوراً به حالت اصلی/خام برمی‌گردند؛ فایل‌های همین Root نیاز به تغییر ندارند.
