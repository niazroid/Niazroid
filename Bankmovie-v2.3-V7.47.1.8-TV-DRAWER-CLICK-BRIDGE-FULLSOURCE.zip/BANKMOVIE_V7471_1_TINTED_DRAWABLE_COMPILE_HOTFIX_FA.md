# BankMovie V7.47.1.1 — Kotlin compile hotfix

این نسخه فقط خطای Compile نسخه V7.47.1 را اصلاح می‌کند و هیچ تغییر سروری ندارد.

## علت دقیق خطا
در V7.47.1 شش محل جدید در `MainActivity.kt` برای آیکن Retry / Bale از تابع `tintedDrawable(...)` استفاده می‌کردند، اما خود helper در `MainActivity` تعریف نشده بود. به همین دلیل Kotlin با `Unresolved reference 'tintedDrawable'` متوقف می‌شد.

## اصلاح
- اضافه شدن importهای `Drawable` و `ContextCompat` به `MainActivity.kt`.
- اضافه شدن helper اختصاصی `tintedDrawable(resId, color, sizePx)`.
- آرگومان اندازه به صورت pixel نگه داشته شده، چون call siteهای MainActivity از قبل `dp(...)` را پاس می‌دهند؛ در نتیجه تبدیل density دوباره انجام نمی‌شود.
- verifier جدید `verify_v7471_1_tinteddrawable_compile_hotfix.sh` اضافه شده تا همین regression دوباره وارد سورس نشود.
- Workflow به V7.47.1.1 و نام ZIP جدید به‌روزرسانی شده است.

## سرور
هیچ فایل سروری نسبت به V7.47.1 تغییر نکرده است.
