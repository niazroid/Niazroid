#!/usr/bin/env bash
set -euo pipefail

ACCOUNT='app/src/main/java/ir/bankmoviee/app/AccountApi.kt'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
FONTS='app/src/main/java/ir/bankmoviee/app/BankmovieFonts.kt'
PREFS='app/src/main/java/ir/bankmoviee/app/UiPreferences.kt'
ONBOARD='app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt'
WORKFLOW='.github/workflows/build-bankmovie.yml'

for f in "$ACCOUNT" "$MAIN" "$FONTS" "$PREFS" "$ONBOARD" "$WORKFLOW"; do
  [[ -s "$f" ]] || { echo "Missing required file: $f" >&2; exit 1; }
done

grep -Fq 'isDefinitiveAccountResponse' "$ACCOUNT"
grep -Fq 'shouldRetryAccountProtocolError' "$ACCOUNT"
grep -Fq 'return last' "$ACCOUNT"
grep -Fq 'این نام کاربری قبلاً ثبت شده است' server-required/app_user_api.php
grep -Fq 'نام کاربری یا رمز عبور اشتباه است' server-required/app_user_api.php

grep -Fq 'FontOption("bankmovie", "بانک مووی", "BankMovie")' "$FONTS"
grep -Fq 'bankmovie_filimo.ttf' "$FONTS"
grep -Fq '"font" -> if (bold) irancellBold(context) else irancellRegular(context)' "$FONTS"
grep -Fq '"bankmovie"' "$PREFS"
grep -Fq 'private var appFont = "bankmovie"' "$ONBOARD"

grep -Fq 'filimo-demo-variable-vf.woff2' "$WORKFLOW"
grep -Fq 'Required Android font asset is missing' "$WORKFLOW"
if grep -Fq 'android-actions/setup-android@v3' "$WORKFLOW"; then
  echo 'Old setup-android action is still present.' >&2
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
main = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
start = main.index('    private fun showProfileMobileV736()')
end = main.index('    private fun showProfile()', start)
mobile = main[start:end]
assert mobile.count('accountVipRemainingDays(user)') == 1, mobile.count('accountVipRemainingDays(user)')
assert 'text = if (vip) accountVipStatusText(user, compact = true)' not in mobile
assert 'profileActionTile(t("مدیریت اشتراک", "Manage VIP"), t("خرید یا مدیریت پلن VIP", "Buy or manage VIP"), "VIP"' in mobile
assert 'مدیریت و تمدید اشتراک VIP' in mobile

tv_start = main.index('    private fun showProfile()', end)
tv = main[tv_start:]
assert 'if (accountUserIsVip(AccountSession.user(this))) accountVipStatusText' not in tv
print('V7.45.8 profile single-VIP-status checks passed')
PY

# Source archive intentionally contains no redistributable font binary; GitHub
# injects the user's repository/site fonts during the build.
if find app/src/main/assets/fonts -maxdepth 1 -type f ! -name 'README.txt' | grep -q .; then
  echo 'Unexpected font binary committed in source assets.' >&2
  exit 1
fi

echo VERIFY_V7458_AUTH_PROFILE_BANKMOVIE_FONT_OK
