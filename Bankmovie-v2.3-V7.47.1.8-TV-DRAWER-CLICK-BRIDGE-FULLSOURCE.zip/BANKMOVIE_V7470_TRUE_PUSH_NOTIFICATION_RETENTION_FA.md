# BankMovie V7.47.0 — Push واقعی + پاکسازی اعلان‌ها

## مشکل اصلی دیتابیس چه بود؟
در نسخه‌های قبلی اعلان عمومی پنل (`notifications`) هنگام باز شدن مرکز اعلان برای هر کاربر داخل `app_notifications` کپی می‌شد. یعنی یک اعلان عمومی می‌توانست تقریباً به تعداد کاربران ردیف جدا بسازد. `dedupe_key` جلوی کپی دوباره برای همان کاربر را می‌گرفت، اما جلوی تکثیر بین کاربران را نمی‌گرفت.

V7.47.0 این مدل را برای کلاینت جدید عوض می‌کند:
- اعلان عمومی فقط یک بار در جدول `notifications` می‌ماند.
- وضعیت خوانده/حذف‌شده هر کاربر فقط در `app_notification_global_state` ثبت می‌شود و فقط وقتی واقعاً نیاز باشد.
- `app_notifications` برای اعلان‌های شخصی مثل پاسخ دیدگاه باقی می‌ماند.
- تمام اعلان‌های شخصی و عمومی حداکثر ۷ روز نگهداری می‌شوند.
- یک مهاجرت یک‌باره کپی‌های قدیمی `global-admin:*` را پاک می‌کند.
- نسخه‌های قدیمی اپ برای سازگاری فقط آخرین اعلان عمومی را می‌توانند به مدل قدیمی کپی کنند، نه ۳۰ اعلان.

## Push واقعی
V7.47.0 از Firebase Cloud Messaging روی topic به نام `bankmovie_all` استفاده می‌کند. برای Broadcast عمومی هیچ جدول توکن دستگاه در دیتابیس BankMovie لازم نیست؛ Firebase اعضای topic را مدیریت می‌کند.

اگر FCM تنظیم نشده باشد یا دستگاه Google Play Services نداشته باشد، سیستم قبلی `AdminPushScheduler` همچنان تقریباً هر ۱۵ دقیقه اعلان‌ها را بررسی می‌کند. پس FCM یک مسیر سریع جدید است، نه یک وابستگی که بتواند اپ را از کار بیندازد.

## فایل‌های لازم Firebase
### Android / GitHub Actions
1. در Firebase یک Android app با package زیر بسازید:
   `ir.bankmoviee.app`
2. فایل `google-services.json` را دانلود کنید.
3. فایل را Base64 کنید و در GitHub Actions Secrets با نام زیر بگذارید:
   `BANKMOVIE_GOOGLE_SERVICES_JSON_B64`

Workflow V7.47.0 هنگام Build خودش این Secret را به `app/google-services.json` تبدیل می‌کند.

### Server
از Firebase > Project settings > Service accounts یک Private Key JSON بسازید.

پیشنهاد امن:
`/home/CPANEL_USER/bankmovie_private/firebase-service-account.json`

یا Environment Variable:
`BANKMOVIE_FIREBASE_SERVICE_ACCOUNT_FILE=/full/path/firebase-service-account.json`

این فایل کلید خصوصی دارد؛ داخل GitHub، APK یا public_html منتشر نشود.

## BM Admin
بخش اعلان‌ها الان:
- Push فوری FCM را در صورت آماده بودن ارسال می‌کند.
- در صورت خطای FCM، اعلان همچنان ذخیره می‌شود و fallback قدیمی فعال می‌ماند.
- Expire فقط ۱، ۳ یا ۷ روز دارد.
- دکمه «پاکسازی و فشرده‌سازی دیتابیس اعلان‌ها» دارد که ردیف‌های قدیمی را حذف و InnoDB را OPTIMIZE می‌کند.

## سازگاری نسخه‌های قدیمی
نسخه‌های قدیمی FCM جدید را ندارند، اما endpoint `notifications` و JobScheduler قدیمی باقی مانده است. بنابراین Broadcastهای جدید را همچنان از مسیر قبلی دریافت می‌کنند؛ فقط فوری بودن FCM مخصوص APK جدید است.
