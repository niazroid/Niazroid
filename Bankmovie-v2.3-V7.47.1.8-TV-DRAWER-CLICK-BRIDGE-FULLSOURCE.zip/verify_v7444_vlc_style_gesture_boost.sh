#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
draw='app/src/main/res/drawable'
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

# Preserve the known-good archive/section/VIP behavior without requiring the
# superseded V7.44.3 gesture-direction assertions.
bash verify_v7431_section_hard_hide.sh
grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'vipStreamGate -> showArchiveVipGate(item, "stream")' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"
grep -Fq 'if (actionable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }' "$main"
if grep -Fq 'bypassArchivePlaybackGates = true' "$main"; then
  echo 'V7444_ERROR: ordinary playback still bypasses VIP gates' >&2
  exit 1
fi

grep -Fq 'sourceMainUpdateThirtySecondHotfixTag=BANKMOVIE-2.3-V7444-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Player top control stays the exact CC icon requested.
grep -Fq 'setImageResource(R.drawable.ic_player_cc)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_audio)' "$player"
if grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"; then
  echo 'V7444_ERROR: language globe must not be used inside PlayerActivity' >&2
  exit 1
fi

# Approved VLC-style layout and side placement.
grep -Fq 'text = "Volume"' "$player"
grep -Fq 'text = "Brightness"' "$player"
grep -Fq 'leftMargin = dp(10)' "$player"
grep -Fq 'rightMargin = dp(10)' "$player"
grep -Fq 'gestureMode = if (partyGuestPlaybackLocked()) 2 else if (touchStartX < root.width / 2f) 2 else 1' "$player"

# Natural direction: upward finger travel increases both values.
grep -Fq 'val deltaRatio = ((touchStartY - e.y) / root.height) * 1.30f' "$player"
grep -Fq 'val deltaPercent = ((touchStartY - e.y) / root.height) * 185f' "$player"

# Smooth direct tracking: no per-MOVE scale animation.
grep -Fq 'volumeGestureLevel.scaleY = trackRatio' "$player"
grep -Fq 'brightnessGestureLevel.scaleY = ratio' "$player"
if grep -Fq 'volumeGestureLevel.animate().scaleY' "$player"; then
  echo 'V7444_ERROR: volume fill still trails the finger' >&2
  exit 1
fi
if grep -Fq 'brightnessGestureLevel.animate().scaleY' "$player"; then
  echo 'V7444_ERROR: brightness fill still trails the finger' >&2
  exit 1
fi

# 200% VLC boost and 100%=midpoint rail semantics.
grep -Fq 'private const val VOLUME_BOOST_MAX_PERCENT = 200f' "$player"
grep -Fq 'target.javaClass.getMethod("setVolume", Integer.TYPE).invoke(target, safe)' "$player"
grep -Fq 'val trackRatio = (percent / VOLUME_BOOST_MAX_PERCENT).coerceIn(0f, 1f)' "$player"
grep -Fq 'applyVlcAmplification(percent.roundToInt())' "$player"

# Exact user-supplied SVG path geometry.
grep -Fq 'M3,9v6h4l5,5V4L7,9H3z' "$draw/ic_player_volume_gesture.xml"
grep -Fq 'M20,8.69V4h-4.69L12,0.69' "$draw/ic_player_brightness_gesture.xml"

python3 - <<'PY'
import xml.etree.ElementTree as ET
for path in [
    'app/src/main/res/drawable/ic_player_volume_gesture.xml',
    'app/src/main/res/drawable/ic_player_brightness_gesture.xml',
    'app/src/main/res/drawable/ic_player_cc.xml',
    'app/src/main/res/drawable/ic_player_audio.xml',
]:
    ET.parse(path)
print('V7444_VECTOR_XML_OK')
PY

echo V7444_VLC_STYLE_GESTURE_BOOST_VERIFY_OK
