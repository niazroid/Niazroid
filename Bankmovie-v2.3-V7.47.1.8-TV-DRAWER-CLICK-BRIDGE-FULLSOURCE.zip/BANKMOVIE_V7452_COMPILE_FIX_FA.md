# BankMovie V7.45.2 — Kotlin Compile Fix

## علت خطای Build
Build در مرحله `:app:compileAbi2LiteReleaseKotlin` متوقف می‌شد چون در `PlayerActivity.kt` داخل `EditText` چت Watch Party این خط وجود داشت:

`isHorizontallyScrolling = false`

این property در API/Kotlin مورد استفاده پروژه resolve نمی‌شود و باعث `Unresolved reference` می‌شد.

## اصلاح
خط ناسازگار حذف شد. رفتار موردنظر چت همچنان با این موارد حفظ شده است:
- `setSingleLine(false)`
- `maxLines = 3`
- `TYPE_TEXT_FLAG_MULTI_LINE`
- `IME_FLAG_NO_FULLSCREEN`
- `IME_FLAG_NO_EXTRACT_UI`
- `SOFT_INPUT_ADJUST_RESIZE`

در نتیجه فیکس جلوگیری از fullscreen شدن کیبورد دست‌نخورده باقی مانده و فقط خطی که Kotlin را fail می‌کرد حذف شده است.

## فایل تغییرکرده
- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`

## سرور
هیچ تغییر سمت سرور لازم نیست.
