#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
DOWNLOADS="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
API="$ROOT/server-required/app_api.php"
need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7469_MISSING: $2 in $1" >&2; exit 1; }; }
forbid() { ! grep -Fq -- "$2" "$1" || { echo "VERIFY_V7469_FORBIDDEN: $2 in $1" >&2; exit 1; }; }

# UI polish requested after V7.46.8.
need "$DOWNLOADS" 'downloadHeaderIcon(R.drawable.ic_user_settings, "تنظیمات دانلود")'
forbid "$DOWNLOADS" 'downloadHeaderIcon(R.drawable.ic_bm_settings, "تنظیمات دانلود")'
need "$DOWNLOADS" 'marginEnd = dp(12)'
need "$OFFLINE" 'val posterShell = FrameLayout(this).apply {'
need "$OFFLINE" 'outlineProvider = ViewOutlineProvider.BACKGROUND'
need "$OFFLINE" 'clipToOutline = true'
need "$OFFLINE" 'horizontalSpacing = dp(8)'
need "$DOWNLOADS" 'horizontalSpacing = dp(8)'
need "$OFFLINE" 'compoundDrawablePadding = dp(7)'
need "$DOWNLOADS" 'compoundDrawablePadding = dp(6)'
need "$OFFLINE" 'wideActionButton("پخش آفلاین", R.drawable.ic_player_play'

# Client startup/rail isolation.
need "$MAIN" 'private var bootAttemptSerial = 0'
need "$MAIN" 'private var appShellBuilt = false'
need "$MAIN" 'private fun cachedOrMinimalBoot(): JSONObject'
need "$MAIN" 'putString("boot_cache_v7469", payload.toString())'
need "$MAIN" '}, 4200L)'
need "$MAIN" 'if (!archiveEnabled(safe)) {'
need "$MAIN" 'json.optBoolean("source_unavailable", false)'
need "$MAIN" 'Do not replace a usable Home with a global network-error screen.'

# Server: archive libraries are lazy and boot does not touch any archive source.
need "$API" 'function bm_app_try_require_site_lib($name) {'
need "$API" 'function bm_app_archive_runtime_ready($archive) {'
need "$API" 'function bm_app_safe_section($archive, $section, $page, $limit) {'
need "$API" 'function bm_app_safe_search($archive, $q, $type, $page, $limit) {'
need "$API" "'archive_independent_boot' => true"
need "$API" 'Deliberately do NOT touch Archive 1/3/4 network sources here.'
need "$API" "\$archiveActions = array('home','section','collections','collection','search','live_search','detail','play','debug_links','actor');"
forbid "$API" "bm_app_require_site_lib('api2_lib.php');"
forbid "$API" "bm_app_require_site_lib('api3_lib.php');"
forbid "$API" "bm_app_require_site_lib('api4_lib.php');"

php -l "$API" >/dev/null
bash "$ROOT/verify_v7468_offline_card_polish.sh"

echo VERIFY_V7469_UI_ARCHIVE_RESILIENCE_OK
