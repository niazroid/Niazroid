#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PRIVATE_ARCHIVE_SETTINGS="$ROOT/server-required/_bankmovie_private/archive_api_settings.json"
HAD_PRIVATE_ARCHIVE_SETTINGS=0
[[ -e "$PRIVATE_ARCHIVE_SETTINGS" ]] && HAD_PRIVATE_ARCHIVE_SETTINGS=1
cleanup_v7464_verify() {
  if [[ "$HAD_PRIVATE_ARCHIVE_SETTINGS" == "0" ]]; then rm -f "$PRIVATE_ARCHIVE_SETTINGS" 2>/dev/null || true; fi
}
trap cleanup_v7464_verify EXIT
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
STORE="$ROOT/app/src/main/java/ir/bankmoviee/app/InternalDownloadStore.kt"
SERVICE="$ROOT/app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
ARCHIVE="$ROOT/server-required/includes/archive_control.php"
REDIRECT="$ROOT/server-required/includes/download_redirect.php"
POLICY="$ROOT/server-required/includes/app_archive_policy.php"
ADMIN="$ROOT/server-required/bm_admin.php"
API="$ROOT/server-required/app_api.php"
CONFIG="$ROOT/server-required/app_config.php"
USERAPI="$ROOT/server-required/app_user_api.php"
ACCOUNT="$ROOT/app/src/main/java/ir/bankmoviee/app/AccountApi.kt"
FONTS="$ROOT/app/src/main/java/ir/bankmoviee/app/BankmovieFonts.kt"
WORKFLOW="$ROOT/.github/workflows/build-bankmovie.yml"

need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7464_MISSING: $2 in $1" >&2; exit 1; }; }
forbid() { if grep -Fq -- "$2" "$1"; then echo "VERIFY_V7464_FORBIDDEN: $2 in $1" >&2; exit 1; fi; }

# Keep the V7.45.9 font/auth hard fixes while validating the new release.
for font in bankmovie_filimo_400.ttf bankmovie_filimo_500.ttf bankmovie_filimo_700.ttf bankmovie_filimo_900.ttf bankmovie_filimo_950.ttf; do need "$FONTS" "$font"; done
need "$WORKFLOW" 'instantiateVariableFont'
need "$WORKFLOW" 'bankmovie_filimo_950.ttf'
need "$ACCOUNT" 'parseJsonPayload'
need "$ACCOUNT" 'optInt("http_status", code)'
need "$ACCOUNT" 'isDefinitiveAccountResponse(last.statusCode'

# Internal downloader must stay first-class even in adm_copy mode.
need "$MAIN" 'clientMode != "disabled" && AccountSession.internalDownloaderEnabled(this)'
need "$MAIN" 'دانلودر داخلی بانک مووی'
need "$MAIN" 'ذخیره مستقیم در مسیر انتخابی شما'
need "$MAIN" 'ارسال لینک دانلود به Advanced Download Manager'
need "$MAIN" 'آدرس دانلود BankMovie کپی می‌شود'
forbid "$MAIN" 'دکمه‌های پخش، واچ پارتی و دانلود فعال می‌مانند'

# ADM handoff is package-targeted share and must not browser-fallback inside openAdmOnly.
python3 - "$MAIN" <<'PY'
from pathlib import Path
import re, sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
m=re.search(r'private fun openAdmOnly\(url: String(?:, allowClipboardFallback: Boolean = true)?\) \{(.*?)\n    \}\n', s, re.S)
if not m: raise SystemExit('VERIFY_V7464_OPEN_ADM_BLOCK_MISSING')
b=m.group(1)
for token in ['Intent.ACTION_SEND', 'com.dv.adm', 'com.dv.adm.pay']:
    if token not in b: raise SystemExit('VERIFY_V7464_OPEN_ADM_MISSING_'+token)
if 'Intent.ACTION_VIEW' in b:
    raise SystemExit('VERIFY_V7464_ADM_BROWSER_FALLBACK_PRESENT')
PY

# Offline library + metadata + redirect-following downloader.
need "$OFFLINE" 'class OfflineLibraryActivity'
need "$OFFLINE" 'گالری آفلاین'
need "$OFFLINE" 'پخش آفلاین'
need "$OFFLINE" 'حذف فایل'
need "$MANIFEST" 'android:name=".OfflineLibraryActivity"'
need "$STORE" 'put("media_type", mediaType)'
need "$STORE" 'put("season", season)'
need "$STORE" 'put("episode", episode)'
need "$SERVICE" 'Too many redirects'
need "$MAIN" 'X-BM-Download-System", "2"'
need "$MAIN" 'X-BM-Client-Version", "2.3"'

# Server code must be based on current site feature-complete archive_control,
# not the stale reduced copy that caused homepage HTTP 500.
for symbol in \
  bm_archive_section_catalog_defaults \
  bm_archive_order \
  bm_archive_default_mode \
  bm_archive_emergency_settings \
  bm_archive_player_gates_public \
  bm_archive_download_redirect_enabled \
  bm_archive_download_modern_client_only \
  bm_archive_download_link_mode \
  bm_archive_download_client_mode; do
  need "$ARCHIVE" "function $symbol"
done
need "$REDIRECT" "require_once __DIR__ . '/download_domain_manager.php';"
need "$REDIRECT" 'bmDownloadLegacyCompat'
need "$API" 'X-BM-Download-System'
need "$CONFIG" 'X-BM-Download-System'
need "$POLICY" "'download_client_mode'"

# BM Admin: emergency master rollback + 2.2 isolation + per-archive modes.
need "$ADMIN" 'name="download_redirect_enabled"'
need "$ADMIN" 'name="download_modern_client_only"'
need "$ADMIN" 'نسخه 2.2 روی لینک و دانلود قدیمی بماند'
need "$ADMIN" '_download_link_mode'
need "$ADMIN" '_download_client_mode'
need "$ADMIN" 'دانلودر داخلی + ADM + کپی لینک'
need "$ADMIN" '_download_base_urls'
need "$ADMIN" 'دامنه‌های ریدایرکت دانلود همین آرشیو'

# Login/register validation errors must remain JSON even on hosts replacing 4xx bodies.
need "$USERAPI" 'function bm_user_api_auth_error'
for code in LOGIN_DISABLED LOGIN_FIELDS_REQUIRED INVALID_CREDENTIALS ACCOUNT_INACTIVE REGISTRATION_DISABLED USERNAME_LENGTH USERNAME_FORMAT EMAIL_INVALID PASSWORD_TOO_SHORT PASSWORD_MISMATCH EMAIL_EXISTS USERNAME_EXISTS; do
  need "$USERAPI" "'error_code'=>'$code'"
done

if command -v php >/dev/null 2>&1; then
  for f in "$CONFIG" "$USERAPI" "$ADMIN" "$API" "$POLICY" "$ARCHIVE" "$REDIRECT"; do php -l "$f" >/dev/null; done
  php -r "require '$ARCHIVE'; foreach(['bm_archive_default_mode','bm_archive_order','bm_archive_section_catalog_defaults','bm_archive_player_gates_public'] as \$f){if(!function_exists(\$f)){fwrite(STDERR,'missing '.\$f.PHP_EOL);exit(2);}} echo 'HOMEPAGE_ARCHIVE_CONTROL_OK'.PHP_EOL;" >/dev/null
  mode_check="$(php -r "require '$ARCHIVE'; echo bm_archive_download_link_mode('archive1',false).'/'.bm_archive_download_client_mode('archive1',false).'|'.bm_archive_download_link_mode('archive1',true).'/'.bm_archive_download_client_mode('archive1',true);")"
  [[ "$mode_check" == 'original/all|redirect/adm_copy' ]] || { echo "VERIFY_V7464_LEGACY_GATE_BAD: $mode_check" >&2; exit 1; }
fi

echo VERIFY_V7464_INTERNAL_OFFLINE_HOME500_LEGACY_SAFE_OK
