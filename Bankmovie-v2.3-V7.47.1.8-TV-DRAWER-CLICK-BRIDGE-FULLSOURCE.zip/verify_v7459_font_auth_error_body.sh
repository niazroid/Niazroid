#!/usr/bin/env bash
set -euo pipefail

ACCOUNT='app/src/main/java/ir/bankmoviee/app/AccountApi.kt'
AUTH='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
FONTS='app/src/main/java/ir/bankmoviee/app/BankmovieFonts.kt'
WORKFLOW='.github/workflows/build-bankmovie.yml'
SERVER='server-required/app_user_api.php'

for f in "$ACCOUNT" "$AUTH" "$FONTS" "$WORKFLOW" "$SERVER"; do
  [[ -s "$f" ]] || { echo "Missing required file: $f" >&2; exit 1; }
done

grep -Fq 'bankmovie_filimo_400.ttf' "$FONTS"
grep -Fq 'bankmovie_filimo_500.ttf' "$FONTS"
grep -Fq 'bankmovie_filimo_700.ttf' "$FONTS"
grep -Fq 'bankmovie_filimo_900.ttf' "$FONTS"
grep -Fq 'bankmovie_filimo_950.ttf' "$FONTS"
grep -Fq 'fun bold(context: Context): Typeface = bankmovieBold(context)' "$FONTS"
grep -Fq 'current === bankmovieBold(context)' "$FONTS"
grep -Fq 'preserve_typeface' "$FONTS"

grep -Fq 'instantiateVariableFont' "$WORKFLOW"
grep -Fq "weights = {400:'400', 500:'500', 700:'700', 900:'900', 950:'950'}" "$WORKFLOW"
grep -Fq "static_font['OS/2'].usWeightClass = weight" "$WORKFLOW"
grep -Fq 'bankmovie_filimo_950.ttf' "$WORKFLOW"

grep -Fq 'function bm_user_api_auth_error' "$SERVER"
grep -Fq "'http_status' => \$status" "$SERVER"
grep -Fq "'error_code' => 'INVALID_CREDENTIALS'" "$SERVER"
grep -Fq "'error_code' => 'USERNAME_EXISTS'" "$SERVER"
grep -Fq "'error_code' => 'EMAIL_EXISTS'" "$SERVER"

grep -Fq 'parseJsonPayload' "$ACCOUNT"
grep -Fq 'optInt("http_status", code)' "$ACCOUNT"
grep -Fq 'isDefinitiveAccountResponse(last.statusCode' "$ACCOUNT"
grep -Fq 'BankmovieFonts.applyToTree(this, card)' "$AUTH"
grep -Fq 'tag = "preserve_typeface"' "$AUTH"

if command -v php >/dev/null 2>&1; then
  php -l "$SERVER" >/dev/null
fi

# Font binaries are deliberately generated only during CI and must not be
# committed in the source archive.
if find app/src/main/assets/fonts -maxdepth 1 -type f ! -name 'README.txt' | grep -q .; then
  echo 'Unexpected font binary committed in source assets.' >&2
  exit 1
fi

echo VERIFY_V7459_FONT_AUTH_ERROR_BODY_OK
