#!/usr/bin/env bash
set -euo pipefail

ARCHIVE='server-required/includes/archive_control.php'
REDIRECT='server-required/includes/download_redirect.php'
POLICY='server-required/includes/app_archive_policy.php'
ADMIN='server-required/bm_admin.php'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
SUBROOT='server-required/download-subdomain-root'
INDEX="$SUBROOT/index.php"
HTACCESS="$SUBROOT/.htaccess"

for f in "$ARCHIVE" "$REDIRECT" "$POLICY" "$ADMIN" "$MAIN" "$INDEX" "$HTACCESS"; do
  [[ -s "$f" ]] || { echo "Missing $f" >&2; exit 1; }
done

# Android stays server-driven: ADM + protected copy only, no hardcoded download subdomain.
grep -Fq "'download_client_mode' => 'adm_copy'" "$ARCHIVE"
grep -Fq "['adm_copy','all','disabled']" "$ARCHIVE"
grep -Fq 'private fun openAdmOnly(url: String)' "$MAIN"
grep -Fq 'setPackage("com.dv.adm")' "$MAIN"
grep -Fq 'Only the BankMovie redirect URL is copied' "$MAIN"
! grep -Eq 'https://dl[0-9]+\.bankmovie\.top' "$MAIN"

# BM Admin owns an independent redirect-domain list for every archive.
grep -Fq 'archive<?= (int)$bmArchiveNumber ?>_download_base_urls' "$ADMIN"
grep -Fq 'این فیلد برای همین آرشیو مستقل است' "$ADMIN"
grep -Fq 'هر ساب‌دامین Document Root جدا دارد' "$ADMIN"
grep -Fq 'bm_archive_pick_download_base_url($archiveId, $seed)' "$REDIRECT"

# The subdomain root is the exact thin site gateway model: rewrite -> index.php -> main-site helper.
grep -Fq 'RewriteRule ^r/([A-Za-z0-9_-]+)$ index.php?t=$1 [L,QSA]' "$HTACCESS"
grep -Fq 'RewriteRule ^.+$ index.php [L,QSA]' "$HTACCESS"
grep -Fq 'function bm_dl10_find_helper(): string|false' "$INDEX"
grep -Fq "getenv('BANKMOVIE_APP_ROOT')" "$INDEX"
grep -Fq "/bankmovie.top/public_html/includes/download_redirect.php" "$INDEX"
grep -Fq "require_once \$helper;" "$INDEX"
grep -Fq "\$_GET['sig'] ?? \$_GET['t']" "$INDEX"
grep -Fq "preg_match('~^/r/([A-Za-z0-9_-]+)$~'" "$INDEX"
grep -Fq "header('Location: ' . \$data['url'], true, 302);" "$INDEX"
[[ ! -d "$SUBROOT/includes" ]]

php -l "$INDEX" >/dev/null
php -l "$ARCHIVE" >/dev/null
php -l "$REDIRECT" >/dev/null
php -l "$ADMIN" >/dev/null

# Four independent Archive bases must produce four different site-controlled hosts.
TMP_PRIVATE="$(mktemp -d)"
TMP_LAYOUT="$(mktemp -d)"
SERVER_PID=''
cleanup() {
  [[ -n "$SERVER_PID" ]] && kill "$SERVER_PID" >/dev/null 2>&1 || true
  rm -rf "$TMP_PRIVATE" "$TMP_LAYOUT"
}
trap cleanup EXIT

BANKMOVIE_PRIVATE_DIR="$TMP_PRIVATE" php -d display_errors=1 <<'PHP'
<?php
require 'server-required/includes/archive_control.php';
require 'server-required/includes/download_redirect.php';
$settings = bm_archive_control_defaults();
for ($i=1; $i<=4; $i++) {
    $aid = 'archive'.$i;
    $settings['archives'][$aid]['download_link_mode'] = 'redirect';
    $settings['archives'][$aid]['download_client_mode'] = 'adm_copy';
    $settings['archives'][$aid]['download_base_urls'] = ['https://archive'.$i.'-download.example.com'];
}
if (!bm_archive_save_settings($settings)) exit(20);
for ($i=1; $i<=4; $i++) {
    $aid = 'archive'.$i;
    $raw = 'https://origin'.$i.'.example.net/media/Test.S01E0'.$i.'.1080p.mkv';
    $wrapped = bm_dl_wrap_url($raw, 21600, $aid, true);
    if (!str_starts_with($wrapped, 'https://archive'.$i.'-download.example.com/')) exit(30+$i);
    parse_str((string)parse_url($wrapped, PHP_URL_QUERY), $q);
    $decoded = bm_dl_decode_token((string)($q['sig'] ?? ''));
    if (!is_array($decoded) || ($decoded['url'] ?? '') !== $raw || ($decoded['archive_id'] ?? '') !== $aid) exit(40+$i);
}
echo "V7462_PER_ARCHIVE_BASES_OK\n";
PHP

# Reproduce the real separate-DocumentRoot topology and prove the provided index.php
# can discover the main BankMovie helper without copying helper code into the subdomain.
MAINROOT="$TMP_LAYOUT/domains/bankmovie.top/public_html"
SUBDOMAINROOT="$TMP_LAYOUT/domains/archive1-download.example.com/public_html"
mkdir -p "$MAINROOT/includes" "$SUBDOMAINROOT"
cp server-required/includes/download_redirect.php "$MAINROOT/includes/download_redirect.php"
cp server-required/includes/security_bootstrap.php "$MAINROOT/includes/security_bootstrap.php"
cp server-required/includes/bm_private_cleanup.php "$MAINROOT/includes/bm_private_cleanup.php"
cp "$INDEX" "$SUBDOMAINROOT/index.php"
cp "$HTACCESS" "$SUBDOMAINROOT/.htaccess"

TEST_KEY='V7462-shared-site-key-for-verifier-only-0123456789'
TOKEN="$(BANKMOVIE_DL_REDIRECT_KEY="$TEST_KEY" php -r "require '$MAINROOT/includes/download_redirect.php'; echo bm_dl_token_for_url('https://origin.example.net/files/Test.Movie.1080p.mkv', 3600, 'archive1');")"
[[ -n "$TOKEN" ]]
PORT="$(python3 - <<'PY'
import socket
s=socket.socket(); s.bind(('127.0.0.1',0)); print(s.getsockname()[1]); s.close()
PY
)"
BANKMOVIE_DL_REDIRECT_KEY="$TEST_KEY" php -S "127.0.0.1:$PORT" -t "$SUBDOMAINROOT" "$SUBDOMAINROOT/index.php" >"$TMP_LAYOUT/php-server.log" 2>&1 &
SERVER_PID=$!
for _ in $(seq 1 50); do
  if curl -fsS "http://127.0.0.1:$PORT/health" >/dev/null 2>&1; then break; fi
  sleep 0.1
done

HEADERS="$TMP_LAYOUT/headers.txt"
curl -sS -D "$HEADERS" -o /dev/null "http://127.0.0.1:$PORT/1a/movie/x/Test.Movie.1080p.mkv?sig=$TOKEN"
grep -Eq '^HTTP/[0-9.]+ 302' "$HEADERS"
grep -Fiq 'Location: https://origin.example.net/files/Test.Movie.1080p.mkv' "$HEADERS"

LEGACY_HEADERS="$TMP_LAYOUT/legacy-headers.txt"
curl -sS -D "$LEGACY_HEADERS" -o /dev/null "http://127.0.0.1:$PORT/r/$TOKEN"
grep -Eq '^HTTP/[0-9.]+ 302' "$LEGACY_HEADERS"
grep -Fiq 'Location: https://origin.example.net/files/Test.Movie.1080p.mkv' "$LEGACY_HEADERS"

echo VERIFY_V7462_REAL_SUBDOMAIN_GATEWAY_OK
