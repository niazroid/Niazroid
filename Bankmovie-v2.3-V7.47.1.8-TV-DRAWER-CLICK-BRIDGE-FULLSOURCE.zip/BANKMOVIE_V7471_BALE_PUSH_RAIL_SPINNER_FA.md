# BankMovie V7.47.1 — Rail Error + Bale + BM Admin Push + Inline Loader

این نسخه روی V7.47.0 ساخته شده و سه بخش اصلی را اصلاح می‌کند:

- کارت «این بخش بارگذاری نشد» دیگر داخل HorizontalScrollView ریل‌ها قرار نمی‌گیرد؛ ریل خراب موقتاً مخفی و کارت خطا با عرض کامل نمایش داده می‌شود تا نصفه/اسکرولی نباشد.
- دکمه‌های «مشاهده بیشتر / View all» از InlineSpinnerButton استفاده می‌کنند؛ هنگام درخواست، Loader ده‌تکه داخل خود دکمه نمایش داده می‌شود و پس از پایان درخواست دکمه به حالت عادی برمی‌گردد.
- آیکن Retry از `ic_retry_cycle.xml` و آیکن بله از `ic_bale.xml` استفاده می‌کند.
- کنترل بله به BM Admin اضافه شده و به‌صورت پیش‌فرض خاموش است. لینک کانال و خرید VIP جداگانه قابل تنظیم هستند.
- کانال اضطراری می‌تواند Telegram یا Bale باشد. در صورت غیرفعال بودن بله یا خالی بودن URL، رفتار خودکار به Telegram برمی‌گردد.
- مسیر خرید اشتراک ویژه می‌تواند Telegram یا Bale باشد و از BM Admin تغییر کند.
- Push Notification مستقل در BM Admin قرار دارد و از مرکز اعلان داخل اپ جداست.
- اصلاحات V7.47.0 شامل FCM + fallback، Retention هفت‌روزه و پاکسازی اعلان‌ها حفظ شده است.

## فایل‌های سرور تغییرکرده نسبت به V7.47.0

- `server-required/bm_admin.php`
- `server-required/app_config.php`
- `server-required/admin.php`

## فایل‌های Android تغییرکرده/جدید نسبت به V7.47.0

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/InlineSpinnerButton.kt`
- `app/src/main/res/drawable/ic_retry_cycle.xml`
- `app/src/main/res/drawable/ic_bale.xml`
- `.github/workflows/build-bankmovie.yml`
- `verify_v7471_bale_push_rail_spinner.sh`

## نکات انتشار

1. برای سرور می‌توانی پک Cumulative را روی ریشه سایت Merge/Overwrite کنی یا فقط پک Changed-Only را برای سه PHP جدید بریزی.
2. تنظیمات بله به‌صورت پیش‌فرض خاموش‌اند؛ بعد از نصب از BM Admin فعالشان کن و URLها را وارد کن.
3. برای FCM همچنان `google-services.json` از GitHub Secret و Service Account سمت سرور نیاز است. هیچ کلید خصوصی واقعی داخل این پک قرار نگرفته است.
4. فایل Signing Key داخل سورس تحویلی قرار داده نشده است.
