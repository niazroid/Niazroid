#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
draw='app/src/main/res/drawable'

# Preserve all archive/section controls up through the last hard-hide baseline.
bash verify_v7431_section_hard_hide.sh

grep -Fq 'sourceMainUpdateThirtiethHotfixTag=BANKMOVIE-2.3-V7442-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

# V7.44.1 unified VIP action-gate behavior remains intact.
grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'vipStreamGate -> showArchiveVipGate(item, "stream")' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"
grep -Fq 'if (actionable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }' "$main"
grep -Fq 'val protectedMetadataOnly = archiveVipGateRequired(item, "stream") ||' "$main"
if grep -Fq 'bypassArchivePlaybackGates = true' "$main"; then
  echo 'V7442_ERROR: ordinary playback still bypasses VIP gates' >&2
  exit 1
fi

# V7.44.2: player icon restored, custom language icon moved to Settings.
grep -Fq 'setImageResource(R.drawable.ic_player_audio_subtitle)' "$player"
if grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"; then
  echo 'V7442_ERROR: custom language icon is still used inside PlayerActivity' >&2
  exit 1
fi
grep -Fq 'R.drawable.ic_repo_language) { showLanguageThemeDialog() }' "$main"
grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$main"

# V7.44.2: smooth paired volume/brightness gesture HUDs.
grep -Fq 'private fun showVolumeGestureHud(volume: Int, maxVolume: Int)' "$player"
grep -Fq 'private fun showBrightnessGestureHud(brightness: Float)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_brightness)' "$player"
grep -Fq '.setDuration(92L)' "$player"
grep -Fq 'showBrightnessGestureHud(currentBrightness)' "$player"
grep -Fq 'audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vol, 0)' "$player"

# Auth remains centered/draggable and the username icon is a clean user glyph.
grep -Fq 'page.gravity = Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"
grep -Fq 'android:pathData="M12,12a4,4 0,1 0,0 -8a4,4 0,0 0,0 8z"' "$draw/ic_auth_user.xml"

test -s "$draw/ic_player_brightness.xml"
test -s "$draw/ic_player_audio_subtitle.xml"
test -s "$draw/ic_repo_language.xml"
test -s "$draw/ic_auth_user.xml"

python3 - <<'PY'
import xml.etree.ElementTree as ET
for path in [
    'app/src/main/res/drawable/ic_auth_user.xml',
    'app/src/main/res/drawable/ic_player_brightness.xml',
    'app/src/main/res/drawable/ic_player_audio_subtitle.xml',
    'app/src/main/res/drawable/ic_repo_language.xml',
]:
    ET.parse(path)
print('V7442_VECTOR_XML_OK')
PY

echo V7442_PLAYER_GESTURE_SETTINGS_ICON_VERIFY_OK
