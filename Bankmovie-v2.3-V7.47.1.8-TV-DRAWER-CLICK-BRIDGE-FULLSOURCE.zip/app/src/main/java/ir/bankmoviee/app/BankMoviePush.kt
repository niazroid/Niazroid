package ir.bankmoviee.app

import android.content.Context
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging

/**
 * True push transport for BankMovie.
 *
 * Devices with Google Play services subscribe to one broadcast topic. Devices
 * without FCM keep using AdminPushScheduler, so old TVs/AOSP boxes still have
 * the existing background-poll fallback.
 */
object BankMoviePush {
    const val TOPIC_ALL = "bankmovie_all"
    private const val PREFS = "bankmovie_fcm_state"
    private const val KEY_SUBSCRIBED = "topic_all_subscribed"

    fun ensureSubscribed(context: Context) {
        try {
            if (FirebaseApp.getApps(context).isEmpty()) return
            FirebaseMessaging.getInstance().subscribeToTopic(TOPIC_ALL)
                .addOnSuccessListener {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit().putBoolean(KEY_SUBSCRIBED, true).apply()
                }
                .addOnFailureListener {
                    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit().putBoolean(KEY_SUBSCRIBED, false).apply()
                }
        } catch (_: Throwable) {
            // FCM is deliberately optional. Polling fallback must never crash app startup.
        }
    }
}
