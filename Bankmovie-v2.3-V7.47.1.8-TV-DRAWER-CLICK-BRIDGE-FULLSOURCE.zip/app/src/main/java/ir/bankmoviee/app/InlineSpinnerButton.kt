package ir.bankmoviee.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compact BankMovie action button with an inline ten-spoke pulse loader.
 *
 * The loader starts from performClick(), so it keeps working even when callers
 * replace OnClickListener later (which the catalogue pagination screens do).
 * Existing async code already re-enables the button on completion; setEnabled(true)
 * therefore ends the animation automatically.
 */
class InlineSpinnerButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : TextView(context, attrs, defStyleAttr) {

    private val spinnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var loading = false
    private var savedTextColor = Color.WHITE
    private var loadingStartedAt = 0L
    private val stopRunnable = Runnable { stopInlineLoading() }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    fun isInlineLoading(): Boolean = loading

    fun startInlineLoading() {
        if (loading || !isEnabled) return
        loading = true
        loadingStartedAt = android.os.SystemClock.uptimeMillis()
        savedTextColor = currentTextColor
        setTextColor(Color.TRANSPARENT)
        removeCallbacks(stopRunnable)
        // Safety net for navigation buttons whose destination replaces the screen
        // instead of explicitly re-enabling the source button.
        postDelayed(stopRunnable, 5000L)
        postInvalidateOnAnimation()
    }

    fun stopInlineLoading() {
        if (!loading) return
        loading = false
        removeCallbacks(stopRunnable)
        setTextColor(savedTextColor)
        invalidate()
    }

    override fun setEnabled(enabled: Boolean) {
        if (enabled && loading) stopInlineLoading()
        super.setEnabled(enabled)
    }

    override fun performClick(): Boolean {
        if (loading) return true
        startInlineLoading()
        return super.performClick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(stopRunnable)
        if (loading) {
            loading = false
            setTextColor(savedTextColor)
        }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!loading) return

        val elapsed = (android.os.SystemClock.uptimeMillis() - loadingStartedAt) % 1000L
        val cx = width / 2f
        val cy = height / 2f
        val radius = dp(5.4f)
        val baseLen = dp(4.5f)
        spinnerPaint.strokeWidth = dp(1.9f)
        spinnerPaint.color = if (savedTextColor == Color.TRANSPARENT) Color.WHITE else savedTextColor

        for (i in 0 until 10) {
            val local = ((elapsed / 1000f) - (i * 0.1f) + 1f) % 1f
            // Mirrors the supplied Uiverse loader: a small outward pulse around
            // the middle of each spoke's delayed one-second cycle.
            val pulse = if (local in 0.38f..0.62f) {
                1f + (1f - kotlin.math.abs(local - 0.5f) / 0.12f).coerceIn(0f, 1f) * 0.5f
            } else 1f
            val angle = Math.toRadians((i * 36.0) - 90.0)
            val sx = cx + cos(angle).toFloat() * radius
            val sy = cy + sin(angle).toFloat() * radius
            val ex = cx + cos(angle).toFloat() * (radius + baseLen * pulse)
            val ey = cy + sin(angle).toFloat() * (radius + baseLen * pulse)
            spinnerPaint.alpha = (90 + 165 * (1f - local)).toInt().coerceIn(70, 255)
            canvas.drawLine(sx, sy, ex, ey, spinnerPaint)
        }
        postInvalidateOnAnimation()
    }
}
