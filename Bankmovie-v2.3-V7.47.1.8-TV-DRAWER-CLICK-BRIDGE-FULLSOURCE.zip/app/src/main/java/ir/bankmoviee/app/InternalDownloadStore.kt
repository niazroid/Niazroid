package ir.bankmoviee.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.net.URLDecoder
import java.util.Locale

object InternalDownloadStore {
    const val PREFS = "bankmovie_internal_downloads"
    private const val KEY_ITEMS = "items"

    const val STATUS_QUEUED = "queued"
    const val STATUS_DOWNLOADING = "downloading"
    const val STATUS_RETRYING = "retrying"
    const val STATUS_VERIFYING = "verifying"
    const val STATUS_PAUSED = "paused"
    const val STATUS_SCHEDULED = "scheduled"
    const val STATUS_COMPLETED = "completed"
    const val STATUS_FAILED = "failed"
    const val STATUS_CANCELLED = "cancelled"

    const val STORAGE_FILE = "file"
    const val STORAGE_TREE = "tree"

    private val lock = Any()

    fun idFor(url: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        return bytes.take(10).joinToString("") { "%02x".format(it) }
    }

    fun all(context: Context): MutableList<JSONObject> = synchronized(lock) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        val array = try { JSONArray(raw) } catch (_: Throwable) { JSONArray() }
        MutableList(array.length()) { index -> JSONObject(array.optJSONObject(index)?.toString() ?: "{}") }
            .filter { it.optString("id").isNotBlank() }
            .sortedByDescending { it.optLong("created_at", 0L) }
            .toMutableList()
    }

    fun get(context: Context, id: String): JSONObject? = all(context).firstOrNull { it.optString("id") == id }

    fun upsert(context: Context, item: JSONObject) = synchronized(lock) {
        val list = all(context)
        val id = item.optString("id")
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index >= 0) list[index] = JSONObject(item.toString()) else list.add(0, JSONObject(item.toString()))
        save(context, list)
    }

    fun update(context: Context, id: String, block: (JSONObject) -> Unit): JSONObject? = synchronized(lock) {
        val list = all(context)
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index < 0) return@synchronized null
        val item = JSONObject(list[index].toString())
        block(item)
        list[index] = item
        save(context, list)
        JSONObject(item.toString())
    }

    fun isActiveStatus(status: String): Boolean = status in setOf(STATUS_QUEUED, STATUS_DOWNLOADING, STATUS_RETRYING, STATUS_VERIFYING)

    fun nextQueueOrder(context: Context): Long = synchronized(lock) {
        (all(context).maxOfOrNull { it.optLong("queue_order", 0L) } ?: 0L) + 1L
    }

    fun moveToFront(context: Context, id: String) = synchronized(lock) {
        val list = all(context)
        val min = list.minOfOrNull { it.optLong("queue_order", Long.MAX_VALUE) }?.takeIf { it != Long.MAX_VALUE } ?: 0L
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index >= 0) {
            list[index].put("queue_order", min - 1L)
            list[index].put("updated_at", System.currentTimeMillis())
            save(context, list)
        }
    }

    fun moveToEnd(context: Context, id: String) = synchronized(lock) {
        val list = all(context)
        val max = list.maxOfOrNull { it.optLong("queue_order", 0L) } ?: 0L
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index >= 0) {
            list[index].put("queue_order", max + 1L)
            list[index].put("updated_at", System.currentTimeMillis())
            save(context, list)
        }
    }

    fun recoverable(context: Context): List<JSONObject> = all(context).filter {
        it.optString("status") in setOf(STATUS_QUEUED, STATUS_DOWNLOADING, STATUS_RETRYING, STATUS_VERIFYING)
    }.sortedBy { it.optLong("queue_order", it.optLong("created_at", 0L)) }

    fun queuedBefore(context: Context, id: String): Boolean {
        val current = get(context, id) ?: return false
        val order = current.optLong("queue_order", current.optLong("created_at", 0L))
        return all(context).any {
            it.optString("id") != id && it.optString("status") in setOf(STATUS_QUEUED, STATUS_RETRYING) &&
                it.optLong("queue_order", it.optLong("created_at", 0L)) < order
        }
    }

    fun exists(context: Context, item: JSONObject): Boolean {
        return if (item.optString("storage_mode") == STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank()) false else runCatching {
                DocumentFile.fromSingleUri(context, Uri.parse(raw))?.exists() == true
            }.getOrDefault(false)
        } else {
            val path = item.optString("path")
            path.isNotBlank() && File(path).exists()
        }
    }

    fun deleteDownloadedFile(context: Context, item: JSONObject) {
        if (item.optString("storage_mode") == STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isNotBlank()) runCatching {
                DocumentFile.fromSingleUri(context, Uri.parse(raw))?.delete()
            }
        } else {
            val path = item.optString("path")
            if (path.isNotBlank()) runCatching { File(path).delete() }
        }
    }

    fun remove(context: Context, id: String, deleteFile: Boolean = false) = synchronized(lock) {
        val list = all(context)
        val item = list.firstOrNull { it.optString("id") == id }
        if (deleteFile && item != null) deleteDownloadedFile(context, item)
        if (item != null) deleteOfflinePoster(item)
        save(context, list.filterNot { it.optString("id") == id })
    }

    fun clearCompleted(context: Context) = synchronized(lock) {
        val list = all(context)
        list.filter { it.optString("status") == STATUS_COMPLETED }.forEach(::deleteOfflinePoster)
        save(context, list.filterNot { it.optString("status") == STATUS_COMPLETED })
    }

    fun offlinePosterFile(context: Context, id: String): File {
        val dir = File(context.filesDir, "offline_posters").apply { mkdirs() }
        return File(dir, "$id.img")
    }

    private fun deleteOfflinePoster(item: JSONObject) {
        val path = item.optString("poster_local_path")
        if (path.isNotBlank()) runCatching { File(path).delete() }
    }

    fun create(
        url: String,
        title: String,
        quality: String,
        kind: String,
        displayLabel: String,
        fileName: String,
        path: String,
        poster: String = "",
        mediaType: String = "",
        season: Int = 0,
        episode: Int = 0,
        contentId: String = "",
        archive: Int = 0
    ): JSONObject = JSONObject().apply {
        put("id", idFor(url))
        put("url", url)
        put("title", title.ifBlank { "Bankmovie" })
        put("quality", quality)
        put("kind", kind)
        put("display_label", displayLabel)
        put("poster", poster)
        put("poster_local_path", "")
        put("media_type", mediaType)
        put("season", season)
        put("episode", episode)
        put("content_id", contentId)
        put("archive", archive)
        put("file_name", fileName)
        put("path", path)
        put("storage_mode", STORAGE_FILE)
        put("tree_uri", "")
        put("document_uri", "")
        put("location_label", "")
        put("status", STATUS_QUEUED)
        put("queue_order", System.currentTimeMillis())
        put("downloaded", 0L)
        put("total", 0L)
        put("speed", 0L)
        put("eta_seconds", 0L)
        put("retry_attempt", 0)
        put("retry_max", 0)
        put("multipart", false)
        put("multipart_parts", 1)
        put("resume_checked", false)
        put("resume_supported", false)
        put("content_type", "")
        put("error", "")
        put("created_at", System.currentTimeMillis())
        put("updated_at", System.currentTimeMillis())
    }

    fun originalFileNameFromUrl(url: String): String? {
        if (url.isBlank()) return null
        val clean = url.substringBefore('?').substringBefore('#')
        val raw = clean.substringAfterLast('/', "").trim()
        if (raw.isBlank()) return null
        val decoded = runCatching { URLDecoder.decode(raw, "UTF-8") }.getOrDefault(raw)
        val normalized = normalizeRequestedFileName(decoded)
        val ext = normalized.substringAfterLast('.', "").lowercase(Locale.US)
        return normalized.takeIf {
            it.length >= 4 && ext.matches(Regex("[a-z0-9]{2,5}")) &&
                !it.startsWith("r-", true) && !it.equals("download", true)
        }
    }

    fun normalizeRequestedFileName(raw: String): String {
        var value = raw.substringAfterLast('/').substringBefore('?').substringBefore('#').trim()
        value = runCatching { URLDecoder.decode(value, "UTF-8") }.getOrDefault(value)
        value = value
            .replace(Regex("[\\/:*?\"<>|\\u0000-\\u001F]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (value.length > 150) {
            val ext = value.substringAfterLast('.', "").takeIf { it.length in 2..5 }.orEmpty()
            val keep = if (ext.isNotBlank()) 145 - ext.length else 150
            value = value.take(keep).trimEnd() + if (ext.isNotBlank()) ".$ext" else ""
        }
        return value.ifBlank { "Bankmovie" }
    }

    fun markWaitingForSchedule(context: Context, startAt: Long) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val list = all(context)
        list.forEach { item ->
            val status = item.optString("status")
            if (status in setOf(STATUS_QUEUED, STATUS_PAUSED, STATUS_FAILED)) {
                item.put("status", STATUS_SCHEDULED)
                item.put("schedule_at", startAt)
                item.put("speed", 0L)
                item.put("eta_seconds", 0L)
                item.put("updated_at", now)
            }
        }
        save(context, list)
    }

    fun releaseScheduled(context: Context) = synchronized(lock) {
        val now = System.currentTimeMillis()
        val list = all(context)
        list.forEach { item ->
            if (item.optString("status") == STATUS_SCHEDULED) {
                item.put("status", STATUS_QUEUED)
                item.put("schedule_at", 0L)
                item.put("updated_at", now)
            }
        }
        save(context, list)
    }

    fun safeFileName(title: String, quality: String, kind: String, url: String): String {
        val extension = extensionFromUrl(url)
        val base = listOf(title, quality, kind)
            .filter { it.isNotBlank() }
            .joinToString(" - ")
            .replace(Regex("[\\/:*?\"<>|\\u0000-\\u001F]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(110)
            .ifBlank { "Bankmovie-${idFor(url)}" }
        return "$base.$extension"
    }

    fun mimeForName(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase(Locale.US)) {
            "mkv" -> "video/x-matroska"
            "m3u8" -> "application/vnd.apple.mpegurl"
            "mp3" -> "audio/mpeg"
            "mka" -> "audio/x-matroska"
            "srt" -> "application/x-subrip"
            "vtt" -> "text/vtt"
            else -> "video/mp4"
        }
    }

    private fun extensionFromUrl(url: String): String {
        val clean = url.substringBefore('?').substringBefore('#')
        val ext = clean.substringAfterLast('.', "").lowercase(Locale.US)
        return if (ext.matches(Regex("[a-z0-9]{2,5}"))) ext else "mp4"
    }

    private fun save(context: Context, items: List<JSONObject>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject(it.toString())) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, array.toString()).apply()
    }
}
