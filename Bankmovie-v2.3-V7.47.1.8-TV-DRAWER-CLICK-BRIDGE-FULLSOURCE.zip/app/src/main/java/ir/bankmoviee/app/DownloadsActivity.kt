package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.content.Intent
import android.content.ClipboardManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.PowerManager
import android.text.TextUtils
import android.provider.Settings
import android.util.LruCache
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.Calendar
import java.util.concurrent.Executors
import kotlin.math.max

class DownloadsActivity : Activity() {
    companion object {
        private const val FILTER_ALL = "all"
        private const val FILTER_MOVIES = "movies"
        private const val FILTER_SERIES = "series"
        private const val FILTER_COMPLETED = "completed"
    }

    private data class CardRefs(
        val progress: ProgressBar,
        val status: TextView,
        val bytes: TextView,
        val remaining: TextView,
        val fileInfo: TextView
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var pageScroll: BankmovieSmoothScrollView
    private lateinit var content: LinearLayout
    private lateinit var downloadsBox: LinearLayout
    private lateinit var allTab: TextView
    private lateinit var moviesTab: TextView
    private lateinit var seriesTab: TextView
    private lateinit var completedTab: TextView
    private var storageReadyText: TextView? = null
    private var storageUsageText: TextView? = null
    private var storageProgress: ProgressBar? = null
    private var scheduleStatusText: TextView? = null
    private var selectedFilter = FILTER_ALL
    private var lastStructure = ""
    private val cardRefs = linkedMapOf<String, CardRefs>()
    private val folderRequestCode = 19082
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val posterCache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private val refresh = object : Runnable {
        override fun run() {
            refreshDownloads(false)
            handler.postDelayed(this, 850L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val palette = UiPreferences.palette(this)
        window.statusBarColor = palette.background
        window.navigationBarColor = palette.background
        buildShell()
        refreshDownloads(true)
    }

    override fun onResume() {
        super.onResume()
        // If the user granted Exact alarms & reminders from Android settings,
        // re-arm the pending schedule immediately with the more precise mode.
        runCatching { DownloadScheduleManager.reschedule(this) }
        handler.removeCallbacks(refresh)
        refreshDownloads(false)
        handler.postDelayed(refresh, 250L)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    /**
     * TV-only hard vertical focus router for the downloader.
     *
     * View-level nextFocus hints are not enough here because the page contains
     * nested HorizontalScrollViews. Some TV firmwares run their geometric focus
     * resolver before/after those hints and can bounce UP between two controls.
     * Intercept UP/DOWN at Activity level while focus is inside our main content
     * and walk one explicit logical row at a time. Dialogs are left untouched.
     */
    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (isTvLike() && event.action == android.view.KeyEvent.ACTION_DOWN &&
            event.keyCode in listOf(
                android.view.KeyEvent.KEYCODE_DPAD_UP, android.view.KeyEvent.KEYCODE_DPAD_DOWN,
                android.view.KeyEvent.KEYCODE_DPAD_LEFT, android.view.KeyEvent.KEYCODE_DPAD_RIGHT
            ) && ::pageScroll.isInitialized
        ) {
            pageScroll.releaseTvInitialFocusGuard()
        }
        if (isTvLike() &&
            event.action == android.view.KeyEvent.ACTION_DOWN &&
            (event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP ||
                event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) &&
            ::content.isInitialized
        ) {
            val focused = currentFocus
            if (focused != null && isInsideView(focused, content)) {
                // A held remote key must never trigger the platform fallback and
                // leap across multiple downloader controls.
                if (event.repeatCount != 0) return true
                if (routeDownloadsTvVerticalFocus(focused, event.keyCode)) return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun isInsideView(child: View?, ancestor: View): Boolean {
        var current = child
        while (current != null) {
            if (current === ancestor) return true
            current = current.parent as? View
        }
        return false
    }

    private fun downloadsHeaderFocusViews(): List<View> {
        if (!::content.isInitialized) return emptyList()
        val found = mutableListOf<View>()
        fun walk(view: View) {
            val key = view.getTag(R.id.bm_focus_restore_key) as? String
            if (key?.startsWith("header:") == true && view.isShown && view.isEnabled && view.isFocusable) found += view
            if (view is ViewGroup) for (i in 0 until view.childCount) walk(view.getChildAt(i))
        }
        walk(content)
        return found
    }

    private fun nearestDownloadCard(view: View?): ViewGroup? {
        var node = view
        while (node != null) {
            val tag = node.tag as? String
            if (node is ViewGroup && tag?.startsWith("bm_download_card:") == true) return node
            node = node.parent as? View
        }
        return null
    }

    private fun firstDownloadActionInCard(card: ViewGroup?): View? {
        card ?: return null
        var found: View? = null
        fun walk(view: View) {
            if (found != null || view.visibility != View.VISIBLE) return
            if (view is LinearLayout && view.tag == "bm_download_action_row" && view.childCount > 0) {
                found = view.getChildAt(0)
                return
            }
            if (view is ViewGroup) for (i in 0 until view.childCount) walk(view.getChildAt(i))
        }
        walk(card)
        return found
    }

    private fun routeDownloadsTvVerticalFocus(focused: View, keyCode: Int): Boolean {
        if (!::allTab.isInitialized) return false
        val up = keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP
        val filters = listOf(allTab, moviesTab, seriesTab, completedTab)
        val storage = findFocusKey(content, "downloads:storage-summary")
        val folder = findFocusKey(content, "downloads:folder")
        val schedule = findFocusKey(content, "downloads:schedule")
        val bulk = findFocusKey(content, "downloads:bulk-import")
        val clearCompleted = findFocusKey(content, "downloads:clear-completed")
        val help = findFocusKey(content, "downloads:help")
        val shell = listOfNotNull(storage, folder, schedule, bulk).filter { it.isShown && it.isEnabled }
        val rows = visibleDownloadActionRows().filter { it.isShown && it.isEnabled && it.childCount > 0 }
        val headers = downloadsHeaderFocusViews()

        fun visible(vararg candidates: View?): View? = candidates.firstOrNull { it != null && it.isShown && it.isEnabled }

        fun focus(target: View?): Boolean {
            val safe = target?.takeIf { it.isShown && it.isEnabled } ?: return false
            ensureDownloadFocusId(safe)
            safe.requestFocus()
            return true
        }

        headers.indexOfFirst { focused === it || isInsideView(focused, it) }.takeIf { it >= 0 }?.let {
            return if (up) true else focus(allTab)
        }

        filters.indexOfFirst { focused === it || isInsideView(focused, it) }.takeIf { it >= 0 }?.let {
            return if (up) focus(headers.firstOrNull()) else focus(visible(shell.firstOrNull(), rows.firstOrNull()?.getChildAtOrNull(0), clearCompleted, help))
        }

        shell.indexOfFirst { focused === it || isInsideView(focused, it) }.takeIf { it >= 0 }?.let { index ->
            if (up) return focus(visible(shell.getOrNull(index - 1), allTab))
            return focus(visible(shell.getOrNull(index + 1), rows.firstOrNull()?.getChildAtOrNull(0), clearCompleted, help))
        }

        rows.indexOfFirst { focused === it || isInsideView(focused, it) }.takeIf { it >= 0 }?.let { rowIndex ->
            val row = rows[rowIndex]
            val column = (0 until row.childCount).firstOrNull { childIndex ->
                val child = row.getChildAt(childIndex)
                focused === child || isInsideView(focused, child)
            } ?: 0
            val targetRow = rows.getOrNull(if (up) rowIndex - 1 else rowIndex + 1)
            if (targetRow != null && targetRow.childCount > 0) {
                return focus(targetRow.getChildAt(column.coerceAtMost(targetRow.childCount - 1)))
            }
            return if (up) focus(visible(shell.lastOrNull(), allTab)) else focus(visible(clearCompleted, help))
        }

        if (clearCompleted != null && (focused === clearCompleted || isInsideView(focused, clearCompleted))) {
            return if (up) focus(visible(rows.lastOrNull()?.getChildAtOrNull(0), shell.lastOrNull(), allTab)) else focus(visible(help))
        }

        if (help != null && (focused === help || isInsideView(focused, help))) {
            return if (up) focus(visible(clearCompleted, rows.lastOrNull()?.getChildAtOrNull(0), shell.lastOrNull(), allTab)) else true
        }

        // The per-card overflow button sits above the action row. Older routing
        // did not classify it, so Activity-level interception consumed UP/DOWN
        // without moving focus. DOWN now enters that card's primary action;
        // UP returns to the previous logical action row/shell.
        val card = nearestDownloadCard(focused)
        if (card != null) {
            val cards = (0 until downloadsBox.childCount).mapNotNull { downloadsBox.getChildAt(it) as? ViewGroup }
                .filter { (it.tag as? String)?.startsWith("bm_download_card:") == true && it.isShown }
            val cardIndex = cards.indexOf(card)
            if (!up) return focus(firstDownloadActionInCard(card) ?: rows.getOrNull(cardIndex)?.getChildAtOrNull(0))
            val previousCard = cards.getOrNull(cardIndex - 1)
            return focus(firstDownloadActionInCard(previousCard) ?: shell.lastOrNull() ?: allTab)
        }

        // Focus is inside downloader content but is not one of the logical rows.
        // Consume vertical movement instead of handing it to Android's geometric
        // resolver, which is the source of the old 1↔2 bounce.
        return true
    }

    private fun ViewGroup.getChildAtOrNull(index: Int): View? =
        if (index in 0 until childCount) getChildAt(index) else null

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        imageExecutor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != folderRequestCode || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Throwable) {
        }
        DownloadLocationPrefs.setTree(this, treeUri)
        lastStructure = ""
        refreshDownloads(true)
        Toast.makeText(this, "مسیر دانلود تغییر کرد", Toast.LENGTH_SHORT).show()
    }

    private fun buildShell() {
        val palette = UiPreferences.palette(this)
        root = FrameLayout(this).apply {
            setBackgroundColor(palette.background)
            clipChildren = false
            clipToPadding = false
        }
        pageScroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            clipChildren = false
            isFillViewport = true
            setPadding(0, 0, 0, dp(30))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isTvLike()) 24 else 16), dp(10), dp(if (isTvLike()) 24 else 16), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        pageScroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(pageScroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildHeader()
        buildFilters()
        content.addView(downloadStorageCard(), LinearLayout.LayoutParams(-1, dp(if (isTvLike()) 92 else 84)).apply { bottomMargin = dp(12) })
        // V7.33: storage location + scheduling live inside Download Settings.
        // Keep the clipboard bulk-import action on the main downloader page.
        content.addView(bulkImportCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        downloadsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        content.addView(downloadsBox, LinearLayout.LayoutParams(-1, -2))
        if (isTvLike()) content.post {
            bindDownloadsTvFocusChain()
            if (currentFocus == null) focusFirst(content)
            pageScroll.scrollTo(0, 0)
        }
    }

    private fun buildHeader() {
        val palette = UiPreferences.palette(this)
        val header = FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false
        }

        val back = ImageView(this).apply {
            setImageResource(R.drawable.ic_bm_back)
            setColorFilter(palette.text)
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = glass(16, true)
            focusKey(this, "header:back")
            premiumFocus(this, 16)
            contentDescription = "بازگشت"
            setOnClickListener { finish() }
        }
        header.addView(back, FrameLayout.LayoutParams(dp(if (isTvLike()) 48 else 44), dp(if (isTvLike()) 48 else 44), Gravity.RIGHT or Gravity.TOP))

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        titles.addView(TextView(this).apply {
            text = "دانلودها"
            setTextColor(palette.text)
            textSize = if (isTvLike()) 25f else 21.5f
            typeface = BankmovieFonts.black(this@DownloadsActivity)
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = "مدیریت، مشاهده و پخش فایل‌های دانلود شده"
            setTextColor(palette.muted)
            textSize = 10.9f
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        header.addView(titles, FrameLayout.LayoutParams(-1, -2, Gravity.RIGHT or Gravity.TOP).apply {
            rightMargin = dp(56)
            leftMargin = dp(104)
            topMargin = dp(2)
        })

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        tools.addView(downloadHeaderIcon(R.drawable.ic_user_settings, "تنظیمات دانلود") {
            showDownloadSettingsSheet()
        }, LinearLayout.LayoutParams(dp(if (isTvLike()) 46 else 42), dp(if (isTvLike()) 46 else 42)).apply { marginEnd = dp(12) })
        tools.addView(downloadHeaderIcon(R.drawable.ic_offline_gallery, "گالری آفلاین") {
            startActivity(Intent(this@DownloadsActivity, OfflineLibraryActivity::class.java))
        }, LinearLayout.LayoutParams(dp(if (isTvLike()) 46 else 42), dp(if (isTvLike()) 46 else 42)))
        header.addView(tools, FrameLayout.LayoutParams(-2, dp(if (isTvLike()) 48 else 44), Gravity.LEFT or Gravity.TOP))

        content.addView(header, LinearLayout.LayoutParams(-1, dp(if (isTvLike()) 76 else 64)).apply { bottomMargin = dp(8) })
    }

    private fun downloadHeaderIcon(iconRes: Int, description: String, click: () -> Unit): ImageView = ImageView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        setImageResource(iconRes)
        setColorFilter(palette.text)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = glass(14, true)
        contentDescription = description
        isClickable = true
        isFocusable = true
        focusKey(this, "header:$description")
        premiumFocus(this, 16)
        setOnClickListener { click() }
    }

    private fun ensureDownloadsSheetHandle(sheet: LinearLayout): View {
        val first = if (sheet.childCount > 0) sheet.getChildAt(0) else null
        if (first?.tag == "bm_download_sheet_drag_handle") return first
        val palette = UiPreferences.palette(this)
        val touchTarget = FrameLayout(this).apply {
            tag = "bm_download_sheet_drag_handle"
            isClickable = true
            isFocusable = true
            contentDescription = "برای باز و بسته کردن پنجره بکشید"
            addView(View(this@DownloadsActivity).apply {
                background = rounded(
                    Color.argb(145, Color.red(palette.muted), Color.green(palette.muted), Color.blue(palette.muted)),
                    999,
                    Color.TRANSPARENT
                )
            }, FrameLayout.LayoutParams(dp(62), dp(5), Gravity.CENTER))
        }
        sheet.addView(touchTarget, 0, LinearLayout.LayoutParams(-1, dp(34)).apply {
            bottomMargin = dp(2)
        })
        return touchTarget
    }

    private fun showDownloadsSheetDialog(
        dialog: AlertDialog,
        sheet: LinearLayout,
        preferredFocus: View? = null,
        maxWidthDp: Int = 560,
        dimAmount: Float = 0.76f
    ) {
        val dragHandle = ensureDownloadsSheetHandle(sheet)
        dialog.show()
        val win = dialog.window ?: return
        win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        win.setDimAmount(dimAmount)
        win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        val side = if (isTvLike()) dp(48) else dp(20)
        val maxWidth = dp(if (isTvLike()) maxWidthDp.coerceAtLeast(620) else maxWidthDp)
        win.setLayout((resources.displayMetrics.widthPixels - side).coerceAtMost(maxWidth), ViewGroup.LayoutParams.WRAP_CONTENT)
        if (!isTvLike()) {
            win.setGravity(Gravity.BOTTOM)
            val attrs = win.attributes
            attrs.y = dp(10)
            win.attributes = attrs
        }
        win.decorView.apply {
            animate().cancel()
            alpha = 0f
            scaleX = if (isTvLike()) 0.97f else 0.992f
            scaleY = if (isTvLike()) 0.97f else 0.992f
            translationY = dp(if (isTvLike()) 10 else 34).toFloat()
            animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .translationY(0f)
                .setDuration(180L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
        if (isTvLike()) {
            preferredFocus?.postDelayed({ preferredFocus.requestFocus() }, 90L)
        } else {
            sheet.post { wireDownloadsSheetDrag(dialog, sheet, dragHandle) }
        }
    }

    private fun wireDownloadsSheetDrag(dialog: AlertDialog, sheet: View, handle: View) {
        if (isTvLike()) return
        var downY = 0f
        var startY = 0f
        var moved = false
        val slop = dp(7).toFloat()
        fun snapTo(target: Float) {
            sheet.animate().cancel()
            sheet.animate()
                .translationY(target)
                .alpha(1f)
                .setDuration(260L)
                .setInterpolator(DecelerateInterpolator(1.7f))
                .start()
        }
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    startY = sheet.translationY
                    moved = false
                    sheet.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawY - downY
                    if (kotlin.math.abs(delta) > slop) moved = true
                    val maxY = (sheet.height * 0.72f).coerceAtLeast(dp(120).toFloat())
                    sheet.translationY = (startY + delta).coerceIn(0f, maxY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val height = sheet.height.coerceAtLeast(dp(260)).toFloat()
                    val current = sheet.translationY
                    val collapsed = height * 0.42f
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        snapTo(if (current > height * 0.18f) 0f else collapsed)
                    } else if (current > height * 0.64f) {
                        sheet.animate().cancel()
                        sheet.animate().translationY(height).alpha(0.82f).setDuration(190L).withEndAction {
                            if (dialog.isShowing) dialog.dismiss()
                        }.start()
                    } else if (current > height * 0.20f) {
                        snapTo(collapsed)
                    } else {
                        snapTo(0f)
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun showDownloadSettingsSheet() {
        val palette = UiPreferences.palette(this)
        var selectedMode = DownloadPreferences.mode(this)
        var selectedConnections = DownloadPreferences.connectionsPerFile(this)
        var completionNotification = DownloadPreferences.completionNotificationEnabled(this)
        lateinit var dialog: AlertDialog

        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(8), dp(16), dp(16))
            background = rounded(
                palette.panel,
                dp(30),
                Color.argb(150, Color.red(palette.stroke), Color.green(palette.stroke), Color.blue(palette.stroke))
            )
            clipChildren = false
            clipToPadding = false
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات دانلود"
            setTextColor(palette.text)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        val close = TextView(this).apply {
            text = "×"
            textSize = 31f
            setTextColor(palette.text)
            gravity = Gravity.CENTER
            background = rounded(palette.panel2, 999, palette.stroke)
            isClickable = true
            isFocusable = true
            premiumFocus(this, 999)
            focusKey(this, "settings:close")
            setOnClickListener { dialog.dismiss() }
        }
        header.addView(close, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(8) })
        sheet.addView(header, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })

        fun sectionCard(): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(palette.panel2, dp(22), palette.stroke)
        }

        val modeCard = sectionCard()
        modeCard.addView(TextView(this).apply {
            text = "حالت دانلود"
            setTextColor(palette.muted)
            textSize = 12f
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val modeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = rounded(UiPreferences.blend(palette.panel2, Color.BLACK, 0.18f), dp(17), Color.TRANSPARENT)
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        lateinit var simultaneous: TextView
        lateinit var sequential: TextView
        fun updateModeButtons() {
            val selectedBg = rounded(palette.primary, dp(14), Color.TRANSPARENT)
            val idleBg = rounded(Color.TRANSPARENT, dp(14), Color.TRANSPARENT)
            simultaneous.background = if (selectedMode == DownloadPreferences.MODE_SIMULTANEOUS) selectedBg else idleBg
            sequential.background = if (selectedMode == DownloadPreferences.MODE_SEQUENTIAL) selectedBg else idleBg
            simultaneous.setTextColor(if (selectedMode == DownloadPreferences.MODE_SIMULTANEOUS) palette.onPrimary else palette.muted)
            sequential.setTextColor(if (selectedMode == DownloadPreferences.MODE_SEQUENTIAL) palette.onPrimary else palette.muted)
        }
        simultaneous = TextView(this).apply {
            text = "▦  همزمان"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            premiumFocus(this, 14)
            focusKey(this, "settings:mode:simultaneous")
            setOnClickListener { selectedMode = DownloadPreferences.MODE_SIMULTANEOUS; updateModeButtons() }
        }
        sequential = TextView(this).apply {
            text = "☷  ترتیبی"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            premiumFocus(this, 14)
            focusKey(this, "settings:mode:sequential")
            setOnClickListener { selectedMode = DownloadPreferences.MODE_SEQUENTIAL; updateModeButtons() }
        }
        modeRow.addView(simultaneous, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(3) })
        modeRow.addView(sequential, LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginEnd = dp(3) })
        modeCard.addView(modeRow, LinearLayout.LayoutParams(-1, dp(60)))
        modeCard.addView(TextView(this).apply {
            text = "چند دانلود به‌صورت همزمان"
            setTextColor(palette.muted)
            textSize = 10.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(8), 0, 0)
        })
        updateModeButtons()
        sheet.addView(modeCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val connectionCard = sectionCard()
        val connectionTitleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        connectionTitleRow.addView(TextView(this).apply {
            text = "تعداد کانکشن برای هر فایل"
            setTextColor(palette.text)
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val connectionBadge = TextView(this).apply {
            text = selectedConnections.toString()
            setTextColor(palette.onPrimary)
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(palette.primary, 999, Color.TRANSPARENT)
        }
        connectionTitleRow.addView(connectionBadge, LinearLayout.LayoutParams(dp(42), dp(42)))
        connectionCard.addView(connectionTitleRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        val seek = SeekBar(this).apply {
            max = 7
            progress = selectedConnections - 1
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            isFocusable = true
            isClickable = true
            focusKey(this, "settings:connections")
            premiumFocus(this, 16)
            progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
            thumbTintList = android.content.res.ColorStateList.valueOf(palette.primary)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    selectedConnections = (progress + 1).coerceIn(1, 8)
                    connectionBadge.text = selectedConnections.toString()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
        }
        connectionCard.addView(seek, LinearLayout.LayoutParams(-1, dp(42)))
        val tickRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        (8 downTo 1).forEach { value ->
            tickRow.addView(TextView(this).apply {
                text = value.toString()
                setTextColor(palette.muted)
                textSize = 10f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(0, dp(20), 1f))
        }
        connectionCard.addView(tickRow, LinearLayout.LayoutParams(-1, dp(20)))
        connectionCard.addView(TextView(this).apply {
            text = "یک کانکشن = پایدارترین حالت"
            setTextColor(palette.muted)
            textSize = 10.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(5), 0, 0)
        })
        sheet.addView(connectionCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val notificationCard = sectionCard()
        notificationCard.addView(TextView(this).apply {
            text = "نوتیفیکیشن‌ها"
            setTextColor(palette.muted)
            textSize = 12f
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val notificationRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        notificationRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_notifications_ui)
            setColorFilter(palette.primary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        notificationRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@DownloadsActivity).apply {
                text = "اعلان اتمام دانلود"
                setTextColor(palette.text)
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@DownloadsActivity).apply {
                text = "وقتی دانلود کامل شد"
                setTextColor(palette.muted)
                textSize = 10.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(3), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val notificationToggle = BmToggleView(this).apply {
            isFocusable = true
            isClickable = true
            focusKey(this, "settings:notification-toggle")
            premiumFocus(this, 16)
            setChecked(completionNotification, animate = false, notify = false)
            setOnCheckedChangeListener { completionNotification = it }
        }
        notificationRow.addView(notificationToggle, LinearLayout.LayoutParams(dp(86), dp(42)).apply { marginStart = dp(8) })
        notificationCard.addView(notificationRow, LinearLayout.LayoutParams(-1, -2))
        sheet.addView(notificationCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val scheduleCard = sectionCard().apply {
            isClickable = true
            isFocusable = true
            focusKey(this, "settings:schedule")
            premiumFocus(this, 22)
        }
        scheduleCard.addView(TextView(this).apply {
            text = "زمان‌بندی دانلود"
            setTextColor(palette.muted)
            textSize = 12f
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val scheduleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(UiPreferences.blend(palette.panel2, Color.BLACK, 0.18f), dp(15), Color.TRANSPARENT)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        scheduleRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_info_calendar)
            setColorFilter(palette.primary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        scheduleRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@DownloadsActivity).apply {
                text = "بازه شروع و پایان"
                setTextColor(palette.text)
                textSize = 13.3f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@DownloadsActivity).apply {
                val start = DownloadScheduleManager.startAt(this@DownloadsActivity)
                val end = DownloadScheduleManager.endAt(this@DownloadsActivity)
                val now = System.currentTimeMillis()
                text = when {
                    start > now && end > start -> "شروع ${formatScheduleTime(start)}  •  پایان ${formatScheduleTime(end)}"
                    end > now -> "فعال تا ${formatScheduleTime(end)}"
                    else -> "خاموش — دانلودها بلافاصله شروع می‌شوند"
                }
                setTextColor(palette.muted)
                textSize = 10.2f
                gravity = Gravity.RIGHT
                maxLines = 2
                setPadding(0, dp(3), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        scheduleRow.addView(TextView(this).apply {
            text = "‹"
            setTextColor(palette.muted)
            textSize = 25f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(32), dp(44)))
        scheduleCard.addView(scheduleRow, LinearLayout.LayoutParams(-1, -2))
        scheduleCard.setOnClickListener {
            dialog.dismiss()
            showScheduleDialog()
        }
        sheet.addView(scheduleCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val pathCard = sectionCard().apply {
            isClickable = true
            isFocusable = true
            focusKey(this, "settings:path")
            premiumFocus(this, 22)
        }
        pathCard.addView(TextView(this).apply {
            text = "مسیر ذخیره‌سازی"
            setTextColor(palette.muted)
            textSize = 12f
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val pathRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(UiPreferences.blend(palette.panel2, Color.BLACK, 0.18f), dp(15), Color.TRANSPARENT)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        pathRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_download)
            setColorFilter(palette.primary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        pathRow.addView(TextView(this).apply {
            text = DownloadLocationPrefs.displayName(this@DownloadsActivity)
            setTextColor(palette.muted)
            textSize = 10.8f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        pathRow.addView(TextView(this).apply {
            text = "‹"
            setTextColor(palette.muted)
            textSize = 25f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(dp(32), dp(44)))
        pathCard.addView(pathRow, LinearLayout.LayoutParams(-1, dp(60)))
        pathCard.setOnClickListener {
            if (!AccountSession.downloadPathSelectionEnabled(this)) {
                Toast.makeText(this, "انتخاب مسیر دانلود از پنل غیرفعال شده است", Toast.LENGTH_SHORT).show()
            } else {
                dialog.dismiss()
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, folderRequestCode)
            }
        }
        sheet.addView(pathCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val save = TextView(this).apply {
            text = "▣  ذخیره تنظیمات"
            setTextColor(palette.onPrimary)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(palette.primary, dp(20), Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            focusKey(this, "settings:save")
            premiumFocus(this, 20)
            setOnClickListener {
                DownloadPreferences.save(this@DownloadsActivity, selectedMode, selectedConnections, completionNotification)
                dialog.dismiss()
                lastStructure = ""
                refreshDownloads(true)
                BmNotice.show(this@DownloadsActivity, "تنظیمات دانلود ذخیره شد", BmNotice.Kind.SUCCESS)
            }
        }
        sheet.addView(save, LinearLayout.LayoutParams(-1, dp(60)))

        if (isTvLike()) {
            val verticalChain = listOf(close, simultaneous, sequential, seek, notificationToggle, scheduleCard, pathCard, save)
            verticalChain.forEachIndexed { index, view ->
                if (view.id == View.NO_ID) view.id = View.generateViewId()
                view.nextFocusUpId = verticalChain[(index - 1).coerceAtLeast(0)].id.takeIf { it != View.NO_ID } ?: view.id
            }
            verticalChain.forEachIndexed { index, view ->
                view.nextFocusDownId = verticalChain[(index + 1).coerceAtMost(verticalChain.lastIndex)].id
                view.setOnKeyListener { _, keyCode, event ->
                    if (event.action != android.view.KeyEvent.ACTION_DOWN || event.repeatCount != 0) return@setOnKeyListener false
                    when (keyCode) {
                        android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                            if (index > 0) verticalChain[index - 1].requestFocus()
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (index < verticalChain.lastIndex) verticalChain[index + 1].requestFocus()
                            true
                        }
                        else -> false
                    }
                }
            }
            simultaneous.nextFocusLeftId = sequential.id
            sequential.nextFocusRightId = simultaneous.id
            close.nextFocusDownId = simultaneous.id
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            addView(sheet, ViewGroup.LayoutParams(-1, -2))
        }
        dialog = AlertDialog.Builder(this).setView(scroll).create()
        // Drag must move the visible sheet, not the ScrollView container.
        showDownloadsSheetDialog(dialog, sheet, preferredFocus = close, maxWidthDp = 560)
        dialog.window?.setLayout(
            (resources.displayMetrics.widthPixels - if (isTvLike()) dp(48) else dp(20)).coerceAtMost(dp(if (isTvLike()) 680 else 560)),
            (resources.displayMetrics.heightPixels * if (isTvLike()) 0.88f else 0.92f).toInt()
        )
    }

    private fun buildFilters() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
        }
        allTab = filterButton("همه", FILTER_ALL, R.drawable.ic_nav_grid)
        moviesTab = filterButton("فیلم‌ها", FILTER_MOVIES, R.drawable.ic_bm_film)
        seriesTab = filterButton("سریال‌ها", FILTER_SERIES, R.drawable.ic_bm_series)
        completedTab = filterButton("کامل شده", FILTER_COMPLETED, R.drawable.ic_bm_check)
        val tabHeight = dp(if (isTvLike()) 46 else 42)
        row.addView(allTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(4) })
        row.addView(moviesTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        row.addView(seriesTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        row.addView(completedTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginEnd = dp(4) })
        content.addView(row, LinearLayout.LayoutParams(-1, tabHeight + dp(6)).apply { bottomMargin = dp(8) })
    }

    private fun filterButton(label: String, key: String, iconRes: Int): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        textSize = if (isTvLike()) 11.5f else 9.8f
        typeface = BankmovieFonts.bold(this@DownloadsActivity)
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        includeFontPadding = false
        setPadding(dp(5), 0, dp(5), 0)
        compoundDrawablePadding = dp(4)
        setCompoundDrawablesRelativeWithIntrinsicBounds(tintedDrawable(iconRes, palette.muted, dp(16)), null, null, null)
        focusKey(this, "filter:$key")
        premiumFocus(this, 17)
        setOnClickListener {
            if (selectedFilter == key) return@setOnClickListener
            selectedFilter = key
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun updateFilterUi(items: List<JSONObject>) {
        val movies = items.count { !isSeriesDownload(it) }
        val series = items.count(::isSeriesDownload)
        val completed = items.count { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }
        allTab.text = "همه  ${items.size}"
        moviesTab.text = "فیلم‌ها  $movies"
        seriesTab.text = "سریال‌ها  $series"
        completedTab.text = "کامل شده  $completed"
        bindFilterStyle(allTab, selectedFilter == FILTER_ALL)
        bindFilterStyle(moviesTab, selectedFilter == FILTER_MOVIES)
        bindFilterStyle(seriesTab, selectedFilter == FILTER_SERIES)
        bindFilterStyle(completedTab, selectedFilter == FILTER_COMPLETED)
    }

    private fun bindFilterStyle(view: TextView, active: Boolean) {
        val palette = UiPreferences.palette(this)
        val color = if (active) palette.onPrimary else palette.text
        view.setTextColor(color)
        view.compoundDrawablesRelative.firstOrNull()?.setTint(color)
        view.background = if (active) glassTint(palette.primary, 15) else glass(15, true)
    }

    private fun downloadStorageCard(): View {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(19, true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            isClickable = true
            isFocusable = true
            focusKey(this, "downloads:storage-summary")
            premiumFocus(this, 22)
            setOnClickListener { startActivity(Intent(this@DownloadsActivity, OfflineLibraryActivity::class.java)) }

            val readyBox = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                val ready = TextView(this@DownloadsActivity).apply {
                    setTextColor(palette.text)
                    textSize = 11.4f
                    typeface = BankmovieFonts.medium(this@DownloadsActivity)
                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                }
                storageReadyText = ready
                addView(ready, LinearLayout.LayoutParams(0, -2, 1f))
                addView(TextView(this@DownloadsActivity).apply {
                    text = "›"
                    setTextColor(palette.primary2)
                    textSize = 23f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(22), dp(36)))
            }
            addView(readyBox, LinearLayout.LayoutParams(0, -1, 0.42f).apply { marginEnd = dp(8) })

            addView(View(this@DownloadsActivity).apply { setBackgroundColor(Color.argb(50, 255, 255, 255)) },
                LinearLayout.LayoutParams(dp(1), -1).apply { marginStart = dp(8); marginEnd = dp(8) })

            val usageBox = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                val labelRow = LinearLayout(this@DownloadsActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(this@DownloadsActivity).apply {
                        text = "فضای مصرفی"
                        setTextColor(palette.text)
                        textSize = 12.1f
                        typeface = BankmovieFonts.medium(this@DownloadsActivity)
                        gravity = Gravity.RIGHT
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    val usage = TextView(this@DownloadsActivity).apply {
                        setTextColor(palette.muted)
                        textSize = 10.3f
                        gravity = Gravity.LEFT
                    }
                    storageUsageText = usage
                    addView(usage)
                }
                addView(labelRow)
                val progressView = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 1000
                    progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
                    progressBackgroundTintList = android.content.res.ColorStateList.valueOf(UiPreferences.blend(palette.panel2, palette.muted, 0.24f))
                }
                storageProgress = progressView
                addView(progressView, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8) })
            }
            addView(usageBox, LinearLayout.LayoutParams(0, -1, 0.58f))

            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_bm_storage)
                setColorFilter(palette.primary2)
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }, 0, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(7) })
        }
    }

    private fun updateDownloadSummary(items: List<JSONObject>) {
        val ready = items.filter { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED && InternalDownloadStore.exists(this, it) }
        val used = ready.sumOf { item ->
            item.optLong("total", 0L).takeIf { it > 0L } ?: item.optLong("downloaded", 0L).coerceAtLeast(0L)
        }
        val totalSpace = runCatching { StatFs(filesDir.absolutePath).totalBytes }.getOrDefault(0L).coerceAtLeast(used)
        val progress = if (totalSpace > 0L) ((used.toDouble() / totalSpace.toDouble()) * 1000.0).toInt().coerceIn(if (used > 0L) 24 else 0, 1000) else 0
        storageReadyText?.text = "${ready.size} فایل آماده پخش"
        storageUsageText?.text = if (totalSpace > 0L) "${humanSize(used)} از ${humanSize(totalSpace)}" else humanSize(used)
        storageProgress?.progress = progress
    }

    private fun isSeriesDownload(item: JSONObject): Boolean {
        val type = item.optString("media_type").lowercase(Locale.US)
        if (type.contains("series") || type.contains("serial") || type.contains("episode") || type.contains("tv")) return true
        if (item.optInt("season", 0) > 0 || item.optInt("episode", 0) > 0) return true
        val sample = item.optString("file_name") + " " + item.optString("title")
        return Regex("(?i)(?:S\\d{1,2}E\\d{1,3}|\\bE\\d{1,3}\\b|فصل\\s*\\d+|قسمت\\s*\\d+)").containsMatchIn(sample)
    }

    private fun refreshDownloads(force: Boolean) {
        updateScheduleUi()
        if (!::downloadsBox.isInitialized) return
        val all = InternalDownloadStore.all(this)
        updateFilterUi(all)
        updateDownloadSummary(all)
        val visible = all.filter { item ->
            when (selectedFilter) {
                FILTER_MOVIES -> !isSeriesDownload(item)
                FILTER_SERIES -> isSeriesDownload(item)
                FILTER_COMPLETED -> item.optString("status") == InternalDownloadStore.STATUS_COMPLETED
                else -> true
            }
        }.sortedWith(compareBy<JSONObject> { item ->
            when (item.optString("status")) {
                InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_VERIFYING -> 0
                InternalDownloadStore.STATUS_QUEUED, InternalDownloadStore.STATUS_RETRYING -> 1
                InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_SCHEDULED -> 2
                InternalDownloadStore.STATUS_FAILED -> 3
                InternalDownloadStore.STATUS_COMPLETED -> 4
                else -> 5
            }
        }.thenBy { item ->
            if (item.optString("status") in setOf(InternalDownloadStore.STATUS_QUEUED, InternalDownloadStore.STATUS_RETRYING))
                item.optLong("queue_order", item.optLong("created_at", 0L))
            else Long.MIN_VALUE
        }.thenByDescending { item -> item.optLong("updated_at", item.optLong("created_at", 0L)) })
        val structure = buildString {
            append(selectedFilter).append('|')
            if (AccountSession.downloadPathSelectionEnabled(this@DownloadsActivity)) append(DownloadLocationPrefs.displayName(this@DownloadsActivity))
            visible.forEach {
                append('|').append(it.optString("id"))
                    .append(':').append(it.optString("status"))
                    .append(':').append(it.optString("poster"))
                    .append(':').append(it.optString("error"))
                    .append(':').append(it.optBoolean("resume_checked", false))
            }
        }
        if (force || structure != lastStructure) {
            lastStructure = structure
            rebuildDownloadList(visible)
        } else {
            updateProgressOnly(visible)
        }
    }

    private fun rebuildDownloadList(items: List<JSONObject>) {
        val focusKey = currentFocus?.getTag(R.id.bm_focus_restore_key) as? String
        downloadsBox.animate().cancel()
        downloadsBox.removeAllViews()
        cardRefs.clear()

        if (items.isEmpty()) {
            downloadsBox.addView(emptyState(), LinearLayout.LayoutParams(-1, -2))
        } else {
            items.forEach { item ->
                downloadsBox.addView(downloadCard(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
            }
            if (items.any { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }) {
                downloadsBox.addView(clearCompletedButton(), LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4) })
            }
        }

        downloadsBox.alpha = 0f
        downloadsBox.translationY = dp(7).toFloat()
        downloadsBox.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(165L)
            .setInterpolator(DecelerateInterpolator())
            .start()

        if (isTvLike()) {
            downloadsBox.postDelayed({
                bindDownloadsTvFocusChain()
                val restored = focusKey?.let { findFocusKey(content, it) }
                if (restored != null) restored.requestFocus() else if (currentFocus == null) {
                    focusFirst(content)
                    if (::pageScroll.isInitialized) pageScroll.scrollTo(0, 0)
                }
            }, 90L)
        }
    }

    private fun emptyState(): View {
        val palette = UiPreferences.palette(this)
        val text = when (selectedFilter) {
            FILTER_MOVIES -> "هنوز فیلمی دانلود نکرده‌اید"
            FILTER_SERIES -> "هنوز قسمتی از سریال‌ها دانلود نکرده‌اید"
            FILTER_COMPLETED -> "هنوز دانلود کاملی ندارید"
            else -> "هنوز فایلی دانلود نکرده‌اید"
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(28), dp(18), dp(28))
            background = glass(20, true)
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_bm_empty_download)
                setColorFilter(palette.primary2)
            }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { bottomMargin = dp(12) })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = text
                setTextColor(palette.text)
                textSize = 15.5f
                typeface = BankmovieFonts.bold(this@DownloadsActivity)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = "فایل‌های دانلود شده در این قسمت نمایش داده می‌شوند."
                setTextColor(palette.muted)
                textSize = 11.1f
                gravity = Gravity.CENTER
                setPadding(dp(10), dp(7), dp(10), dp(14))
            })
            val galleryButton = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                background = glassTint(palette.primary, 999)
                isClickable = true
                isFocusable = true
                focusKey(this, "downloads:empty-gallery")
                premiumFocus(this, 999)
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_offline_gallery)
                    setColorFilter(palette.onPrimary)
                }, LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginStart = dp(6) })
                addView(TextView(this@DownloadsActivity).apply {
                    this.text = "گالری آفلاین"
                    setTextColor(palette.onPrimary)
                    textSize = 11.4f
                    typeface = BankmovieFonts.bold(this@DownloadsActivity)
                    gravity = Gravity.CENTER
                })
                setOnClickListener { startActivity(Intent(this@DownloadsActivity, OfflineLibraryActivity::class.java)) }
            }
            addView(galleryButton, LinearLayout.LayoutParams(dp(190), dp(44)))
        }
    }

    private fun clearCompletedButton(): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = "پاک‌کردن سوابق دانلودهای کامل‌شده"
        setTextColor(Color.rgb(255, 125, 135))
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(Color.argb(45, 235, 35, 55), 16, Color.argb(130, 235, 35, 55))
        focusKey(this, "downloads:clear-completed")
        premiumFocus(this, 18)
        setOnClickListener {
            InternalDownloadStore.clearCompleted(this@DownloadsActivity)
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun downloadScheduleCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = glass(22, true)
            focusKey(this, "downloads:schedule")
            premiumFocus(this, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener { showScheduleDialog() }
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_info_calendar)
                setColorFilter(palette.primary)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glassTint(palette.primary, 16)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
            val textBox = LinearLayout(this@DownloadsActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            textBox.addView(TextView(this@DownloadsActivity).apply {
                text = "زمان‌بندی دانلود"
                setTextColor(palette.text); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
            })
            scheduleStatusText = TextView(this@DownloadsActivity).apply {
                setTextColor(palette.muted); textSize = 10.8f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0)
            }
            textBox.addView(scheduleStatusText)
            addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@DownloadsActivity).apply {
                text = "›"; setTextColor(palette.muted); textSize = 28f; gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(30), dp(48)))
            post { updateScheduleUi() }
        }
    }

    private fun updateScheduleUi() {
        val start = DownloadScheduleManager.startAt(this)
        val end = DownloadScheduleManager.endAt(this)
        val now = System.currentTimeMillis()
        scheduleStatusText?.text = when {
            start > now && end > start -> "شروع: ${formatScheduleTime(start)}  •  پایان: ${formatScheduleTime(end)}"
            end > now -> "بازه فعال است  •  توقف خودکار: ${formatScheduleTime(end)}"
            else -> "خاموش — دانلودها بلافاصله شروع می‌شوند"
        }
    }

    private fun formatScheduleTime(time: Long): String {
        val cal = Calendar.getInstance().apply { timeInMillis = time }
        return "%02d:%02d  •  %04d/%02d/%02d".format(
            cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE),
            cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH)
        )
    }

    private fun setDownloadSchedule(startAt: Long, endAt: Long) {
        DownloadScheduleManager.scheduleWindow(this, startAt, endAt)
        // A download window controls the whole queue, including downloads that
        // are already running when the user arms a future start time.
        androidx.core.content.ContextCompat.startForegroundService(
            this,
            Intent(this, InternalDownloadService::class.java).apply {
                action = InternalDownloadService.ACTION_ARM_SCHEDULE
                putExtra(InternalDownloadService.EXTRA_SCHEDULE_AT, startAt)
            }
        )
        lastStructure = ""
        refreshDownloads(true)
        Toast.makeText(this, "بازه دانلود ثبت شد: ${formatScheduleTime(startAt)} تا ${formatScheduleTime(endAt)}", Toast.LENGTH_LONG).show()
        ensureReliableBackgroundAccess()
    }

    private fun maybeOfferExactScheduleAccess() = ensureReliableBackgroundAccess()

    private fun ensureReliableBackgroundAccess() {
        val needsExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val alarm = getSystemService(ALARM_SERVICE) as AlarmManager
            alarm.canScheduleExactAlarms() == false
        } else false
        val power = getSystemService(POWER_SERVICE) as PowerManager
        val needsBattery = Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !power.isIgnoringBatteryOptimizations(packageName)
        if (!needsExact && !needsBattery) return

        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "اجرای مطمئن دانلود در پس‌زمینه"
            setTextColor(palette.text); textSize = 17.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "برای اینکه شروع و پایان دانلود در زمان انتخابی و هنگام خاموش بودن صفحه درست اجرا شود، مجوزهای لازم اندروید را فعال کنید."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        if (needsExact) box.addView(dialogButton("اجازه Alarm دقیق", false, "schedule:exact") {
            runCatching { startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName"))) }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        if (needsBattery) box.addView(dialogButton("اجازه فعالیت پس‌زمینه", false, "schedule:battery") {
            runCatching { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) }
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        box.addView(dialogButton("بستن", true, "schedule:permissions-close") { dialog.dismiss() }, LinearLayout.LayoutParams(-1, dp(46)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        showDownloadsSheetDialog(dialog, box)
    }

    private fun showScheduleDialog() {
        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "بازه دانلود"; setTextColor(palette.text); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "ساعت شروع و پایان را خودتان انتخاب کنید. در ساعت پایان، دانلودهای فعال Pause می‌شوند و فایل ناقص برای ادامه بعدی حفظ می‌شود."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        box.addView(dialogButton("انتخاب ساعت شروع و پایان", false, "schedule:window") {
            dialog.dismiss()
            val now = Calendar.getInstance()
            TimePickerDialog(this, { _, startHour, startMinute ->
                val start = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, startHour); set(Calendar.MINUTE, startMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    if (timeInMillis <= System.currentTimeMillis() + 5_000L) add(Calendar.DAY_OF_MONTH, 1)
                }
                val endDefault = Calendar.getInstance().apply { timeInMillis = start.timeInMillis; add(Calendar.HOUR_OF_DAY, 2) }
                TimePickerDialog(this, { _, endHour, endMinute ->
                    val end = Calendar.getInstance().apply {
                        timeInMillis = start.timeInMillis
                        set(Calendar.HOUR_OF_DAY, endHour); set(Calendar.MINUTE, endMinute); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                        if (timeInMillis <= start.timeInMillis) add(Calendar.DAY_OF_MONTH, 1)
                    }
                    setDownloadSchedule(start.timeInMillis, end.timeInMillis)
                }, endDefault.get(Calendar.HOUR_OF_DAY), endDefault.get(Calendar.MINUTE), true).apply {
                    setTitle("ساعت پایان دانلود")
                }.show()
            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), true).apply {
                setTitle("ساعت شروع دانلود")
            }.show()
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        if (DownloadScheduleManager.isActive(this)) {
            box.addView(dialogButton("لغو بازه و شروع صف الآن", true, "schedule:cancel") {
                dialog.dismiss()
                DownloadScheduleManager.cancel(this)
                InternalDownloadStore.releaseScheduled(this)
                val service = Intent(this, InternalDownloadService::class.java).apply { action = InternalDownloadService.ACTION_RESTORE }
                androidx.core.content.ContextCompat.startForegroundService(this, service)
                lastStructure = ""
                refreshDownloads(true)
            }, LinearLayout.LayoutParams(-1, dp(48)))
        }
        dialog = AlertDialog.Builder(this).setView(box).create()
        showDownloadsSheetDialog(dialog, box)
    }

    private fun bulkImportCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = glass(19, true)
            focusKey(this, "downloads:bulk-import")
            premiumFocus(this, 22)
            isClickable = true
            isFocusable = true
            setOnClickListener { showBulkImportDialog() }
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_copy_link)
                setColorFilter(palette.primary)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glassTint(palette.primary, 16)
            }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(10) })
            addView(LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@DownloadsActivity).apply {
                    text = "افزودن لیست لینک‌ها"; setTextColor(palette.text); textSize = 12.8f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
                })
                addView(TextView(this@DownloadsActivity).apply {
                    text = "Paste مستقیم خروجی «کپی همه لینک‌ها» از کلیپ‌بورد"; setTextColor(palette.muted); textSize = 9.9f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun clipboardUrls(): List<String> {
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString().orEmpty()
        return Regex("https?://[^\\s]+", RegexOption.IGNORE_CASE).findAll(text)
            .map { it.value.trim().trimEnd(',', ';') }
            .filter { it.startsWith("http", true) }
            .distinct()
            .take(500)
            .toList()
    }

    private fun showBulkImportDialog() {
        val urls = clipboardUrls()
        if (urls.isEmpty()) {
            Toast.makeText(this, "هیچ لینک HTTP/HTTPS در کلیپ‌بورد پیدا نشد", Toast.LENGTH_LONG).show()
            return
        }
        val palette = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = glass(24, true)
        }
        box.addView(TextView(this).apply {
            text = "ساخت لیست دانلود"; setTextColor(palette.text); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "${urls.size} لینک یکتا شناسایی شد. نام فایل از نام اصلی URL گرفته می‌شود تا شماره فصل/قسمت از بین نرود."
            setTextColor(palette.muted); textSize = 11.5f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(12))
        })
        lateinit var dialog: AlertDialog
        box.addView(dialogButton("افزودن ${urls.size} فایل به دانلودر", false, "bulk:add") {
            dialog.dismiss()
            urls.forEach { url ->
                val fileName = InternalDownloadStore.originalFileNameFromUrl(url)
                    ?: InternalDownloadStore.safeFileName("Bankmovie-${InternalDownloadStore.idFor(url)}", "", "", url)
                val title = fileName.substringBeforeLast('.').ifBlank { "Bankmovie" }
                InternalDownloadService.start(this, url, title, "", "", "لیست لینک‌ها", "", fileName)
            }
            Toast.makeText(this, "${urls.size} فایل به صف اضافه شد", Toast.LENGTH_LONG).show()
            lastStructure = ""
            refreshDownloads(true)
        }, LinearLayout.LayoutParams(-1, dp(50)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        showDownloadsSheetDialog(dialog, box)
    }

    private fun downloadLocationCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = glass(22, true)
            focusKey(this, "downloads:folder")
            premiumFocus(this, 22)
            setOnClickListener { showLocationDialog() }

            addView(FrameLayout(this@DownloadsActivity).apply {
                background = rounded(
                    Color.argb(55, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)),
                    16,
                    Color.argb(145, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary))
                )
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(palette.primary)
                }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(14) })

            val labels = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = "محل ذخیره دانلودها"
                setTextColor(palette.text)
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = DownloadLocationPrefs.displayName(this@DownloadsActivity)
                setTextColor(palette.muted)
                textSize = 11.2f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(4), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@DownloadsActivity).apply {
                text = "تغییر"
                setTextColor(palette.primary)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(60), dp(38)))
        }
    }

    private fun showLocationDialog() {
        if (!AccountSession.downloadPathSelectionEnabled(this)) {
            Toast.makeText(this, "انتخاب مسیر دانلود از پنل غیرفعال شده است", Toast.LENGTH_SHORT).show()
            return
        }
        val palette = UiPreferences.palette(this)
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = glass(25, true)
            clipChildren = false
            clipToPadding = false
        }
        box.addView(TextView(this).apply {
            text = "انتخاب محل ذخیره"
            setTextColor(palette.text)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        box.addView(TextView(this).apply {
            text = "می‌توانی پوشه دلخواه را انتخاب کنی یا از حافظه اختصاصی برنامه استفاده کنی."
            setTextColor(palette.muted)
            textSize = 12.2f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val custom = dialogButton("انتخاب پوشه دلخواه", false, "location:custom") {
            dialog.dismiss()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, folderRequestCode)
        }
        val appFolder = dialogButton("حافظه اختصاصی برنامه", false, "location:app") {
            DownloadLocationPrefs.setAppFolder(this)
            dialog.dismiss()
            lastStructure = ""
            refreshDownloads(true)
            Toast.makeText(this, "حافظه اختصاصی برنامه انتخاب شد", Toast.LENGTH_SHORT).show()
        }
        val close = dialogButton("بستن", true, "location:close") { dialog.dismiss() }
        box.addView(custom, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
        box.addView(appFolder, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
        box.addView(close, LinearLayout.LayoutParams(-1, dp(50)))

        if (isTvLike()) {
            val options = listOf(custom, appFolder, close)
            options.forEachIndexed { index, view ->
                if (view.id == View.NO_ID) view.id = View.generateViewId()
                view.nextFocusUpId = options[(index - 1).coerceAtLeast(0)].id.takeIf { it != View.NO_ID } ?: view.id
            }
            // IDs are generated above in order; wire DOWN after every ID exists.
            options.forEachIndexed { index, view ->
                view.nextFocusDownId = options[(index + 1).coerceAtMost(options.lastIndex)].id
                view.setOnKeyListener { _, keyCode, event ->
                    if (event.action != android.view.KeyEvent.ACTION_DOWN || event.repeatCount != 0) return@setOnKeyListener false
                    when (keyCode) {
                        android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                            if (index > 0) options[index - 1].requestFocus()
                            // Consume at the top instead of refocusing the same view;
                            // repeated UP no longer creates a two-item focus bounce.
                            true
                        }
                        android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                            if (index < options.lastIndex) options[index + 1].requestFocus()
                            true
                        }
                        else -> false
                    }
                }
            }
        }

        dialog = AlertDialog.Builder(this).setView(box).create()
        showDownloadsSheetDialog(dialog, box, preferredFocus = custom)
    }

    private fun dialogButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 125, 135) else palette.text)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) rounded(Color.argb(45, 235, 35, 55), 16, Color.argb(125, 235, 35, 55)) else glass(16, false)
        focusKey(this, key)
        premiumFocus(this, 16)
        setOnClickListener { click() }
    }

    private fun compactDownloadMeta(item: JSONObject): String {
        fun normalizedQuality(raw: String): String {
            val clean = raw.trim().replace(Regex("\\s+"), " ")
            val match = Regex("(?i)(\\d{3,4})\\s*p?").find(clean)
            return match?.groupValues?.getOrNull(1)?.let { "${it}P" } ?: clean
        }
        fun semanticKey(raw: String): String = raw
            .lowercase()
            .replace("persian", "فارسی")
            .replace("subtitle", "زیرنویس")
            .replace("sub", "زیرنویس")
            .replace("quality", "")
            .replace(Regex("[^0-9a-z\\u0600-\\u06ff]+"), "")

        val rawParts = listOf(
            normalizedQuality(item.optString("quality")),
            item.optString("kind").trim(),
            item.optString("display_label").trim()
        ).filter { it.isNotBlank() }
        val output = mutableListOf<String>()
        val keys = mutableListOf<String>()
        rawParts.forEach { part ->
            val key = semanticKey(part)
            if (key.isBlank()) return@forEach
            val duplicate = keys.any { existing ->
                existing == key || existing.contains(key) || key.contains(existing) ||
                    (Regex("\\d{3,4}p?").containsMatchIn(existing) && Regex("\\d{3,4}p?").find(existing)?.value == Regex("\\d{3,4}p?").find(key)?.value) ||
                    (existing.contains("زیرنویس") && key.contains("زیرنویس")) ||
                    (existing.contains("دوبله") && key.contains("دوبله"))
            }
            if (!duplicate) { keys += key; output += part }
        }
        return output.joinToString(" • ")
    }

    private fun downloadCard(item: JSONObject): LinearLayout {
        val palette = UiPreferences.palette(this)
        val id = item.optString("id")
        val status = item.optString("status")
        val downloaded = item.optLong("downloaded", 0L)
        val total = item.optLong("total", 0L)
        val speed = item.optLong("speed", 0L)
        val percent = percent(downloaded, total)

        return LinearLayout(this).apply {
            tag = "bm_download_card:$id"
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = glass(19, true)
            clipChildren = false
            clipToPadding = false

            val top = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.TOP
                clipChildren = false
                clipToPadding = false
            }

            val posterShell = FrameLayout(this@DownloadsActivity).apply {
                background = glass(13, false)
                clipToOutline = true
            }
            val poster = ImageView(this@DownloadsActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageResource(R.drawable.bankmovie_mark_transparent)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            posterShell.addView(poster, FrameLayout.LayoutParams(-1, -1))
            top.addView(posterShell, LinearLayout.LayoutParams(dp(if (isTvLike()) 92 else 84), dp(if (isTvLike()) 130 else 118)).apply { marginEnd = dp(10) })
            loadPoster(item.optString("poster"), poster)

            val info = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                setPadding(dp(2), 0, dp(2), 0)
            }

            val kindRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                val typeLabel = if (isSeriesDownload(item)) "سریال" else "فیلم"
                addView(downloadMetaPill(typeLabel, if (isSeriesDownload(item)) R.drawable.ic_bm_series else R.drawable.ic_bm_film, palette.primary2))
            }
            info.addView(kindRow, LinearLayout.LayoutParams(-1, dp(27)).apply { bottomMargin = dp(2) })

            info.addView(TextView(this@DownloadsActivity).apply {
                text = item.optString("title").ifBlank { item.optString("file_name") }
                setTextColor(palette.text)
                textSize = 15.1f
                typeface = BankmovieFonts.bold(this@DownloadsActivity)
                gravity = Gravity.RIGHT
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
            })

            val tags = GenreFlowLayout(this@DownloadsActivity).apply {
                horizontalSpacing = dp(8)
                verticalSpacing = dp(6)
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val season = item.optInt("season", 0)
            val episode = item.optInt("episode", 0)
            if (season > 0 || episode > 0) {
                val ep = buildString {
                    if (season > 0) append("فصل $season")
                    if (season > 0 && episode > 0) append(" • ")
                    if (episode > 0) append("قسمت $episode")
                }
                tags.addView(downloadMetaPill(ep, R.drawable.ic_bm_series, palette.primary2), downloadPillParams())
            }
            item.optString("quality").trim().takeIf { it.isNotBlank() }?.let {
                tags.addView(downloadMetaPill(it.uppercase(Locale.US), R.drawable.ic_bm_film, palette.primary2), downloadPillParams())
            }
            item.optString("kind").trim().takeIf { it.isNotBlank() }?.let { rawKind ->
                val kind = resolveDownloadKindUi(rawKind)
                tags.addView(downloadMetaPill(kind.label, kind.iconRes, kind.accent), downloadPillParams())
            }
            info.addView(tags, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })

            val fileRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_bm_file)
                    setColorFilter(palette.primary2)
                }, LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginStart = dp(6) })
                addView(TextView(this@DownloadsActivity).apply {
                    val size = if (total > 0L) total else downloaded
                    text = "${humanSize(size)}   |   ${item.optString("file_name").ifBlank { "فایل دانلودی" }}"
                    setTextColor(palette.muted)
                    textSize = 9.7f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.MIDDLE
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }
            info.addView(fileRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

            val fileInfoText = TextView(this@DownloadsActivity).apply {
                text = fileInfoLabel(item)
                setTextColor(palette.faint)
                textSize = 9.1f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            }
            info.addView(fileInfoText)
            info.addView(TextView(this@DownloadsActivity).apply {
                text = "ذخیره در: " + item.optString("location_label").ifBlank { DownloadLocationPrefs.displayName(this@DownloadsActivity) }
                setTextColor(palette.faint)
                textSize = 9.0f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(4), 0, 0)
            })
            top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

            val moreButton = ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_bm_more)
                setColorFilter(palette.text)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = glass(13, false)
                contentDescription = "گزینه‌های بیشتر"
                focusKey(this, "download:$id:more")
                premiumFocus(this, 14)
                setOnClickListener { showDownloadItemMenu(item) }
            }
            top.addView(moreButton, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(6) })
            addView(top)

            val progress = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                this.progress = percent
                isIndeterminate = (total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING) || status == InternalDownloadStore.STATUS_VERIFYING
                progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(UiPreferences.blend(palette.panel2, Color.WHITE, 0.06f))
            }
            addView(progress, LinearLayout.LayoutParams(-1, dp(5)).apply { topMargin = dp(10) })

            val statRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, dp(6), 0, 0)
            }
            val statusText = TextView(this@DownloadsActivity).apply {
                text = statusLabel(status, percent, speed)
                setTextColor(statusColor(status, palette.muted))
                textSize = 10.4f
                typeface = if (status == InternalDownloadStore.STATUS_COMPLETED) BankmovieFonts.bold(this@DownloadsActivity) else BankmovieFonts.medium(this@DownloadsActivity)
                gravity = Gravity.RIGHT
            }
            val bytesText = TextView(this@DownloadsActivity).apply {
                text = if (status == InternalDownloadStore.STATUS_COMPLETED) "100%" else bytesLabel(downloaded, total)
                setTextColor(palette.faint)
                textSize = 9.9f
                gravity = Gravity.CENTER
            }
            val remainingText = TextView(this@DownloadsActivity).apply {
                text = remainingLabel(downloaded, total, speed, status)
                setTextColor(palette.faint)
                textSize = 9.9f
                gravity = Gravity.LEFT
            }
            statRow.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
            statRow.addView(bytesText, LinearLayout.LayoutParams(0, -2, 0.8f))
            statRow.addView(remainingText, LinearLayout.LayoutParams(0, -2, 1f))
            addView(statRow)

            val actions = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT
                setPadding(0, dp(8), 0, 0)
                clipChildren = false
                clipToPadding = false
                tag = "bm_download_action_row"
            }
            when (status) {
                InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_VERIFYING -> {
                    actions.addView(actionButton("توقف", false, "$id:pause") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    actions.addView(actionButton("لغو", true, "$id:cancel") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_QUEUED, InternalDownloadStore.STATUS_RETRYING -> {
                    actions.addView(actionButton("توقف", false, "$id:pause") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    actions.addView(actionButton("اول صف", false, "$id:first") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_MOVE_FIRST, id) }, buttonParams())
                    actions.addView(actionButton("آخر صف", false, "$id:last") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_MOVE_LAST, id) }, buttonParams())
                    actions.addView(actionButton("لغو", true, "$id:cancel") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_FAILED, InternalDownloadStore.STATUS_SCHEDULED -> {
                    actions.addView(actionButton(if (status == InternalDownloadStore.STATUS_SCHEDULED) "شروع الآن" else "ادامه", false, "$id:resume") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_RESUME, id) })
                    actions.addView(actionButton("حذف", true, "$id:delete") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_COMPLETED -> {
                    // Two compact actions only; cast/send is intentionally removed.
                    actions.addView(completedActionButton("اشتراک‌گذاری", R.drawable.ic_bm_share, false, "$id:share") { shareDownloaded(item) }, completedActionParams())
                    actions.addView(completedActionButton("پخش آفلاین", R.drawable.ic_player_play, false, "$id:open") { playDownloadedOffline(item) }, completedActionParams())
                }
            }
            if (isTvLike()) bindDownloadActionVerticalFocus(actions)

            val actionScroll = HorizontalScrollView(this@DownloadsActivity).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = status == InternalDownloadStore.STATUS_COMPLETED
                isFocusable = false
                clipToPadding = false
                val width = if (status == InternalDownloadStore.STATUS_COMPLETED) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT
                addView(actions, ViewGroup.LayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            addView(actionScroll, LinearLayout.LayoutParams(-1, -2))

            val error = item.optString("error")
            if (error.isNotBlank() && status == InternalDownloadStore.STATUS_FAILED) {
                addView(TextView(this@DownloadsActivity).apply {
                    text = error
                    setTextColor(Color.rgb(230, 130, 140))
                    textSize = 9.7f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(7), 0, 0)
                })
            }

            cardRefs[id] = CardRefs(progress, statusText, bytesText, remainingText, fileInfoText)
        }
    }

    private data class DownloadKindUi(val label: String, val iconRes: Int, val accent: Int)

    private fun resolveDownloadKindUi(raw: String): DownloadKindUi {
        val label = raw.trim()
        val value = label.lowercase(Locale.US)
        return when {
            value.contains("hard") || label.contains("هارد") -> DownloadKindUi(label, R.drawable.ic_player_cc, Color.rgb(238, 171, 55))
            value.contains("subtitle") || value.contains("sub") || label.contains("زیرنویس") -> DownloadKindUi(label, R.drawable.ic_setup_subtitle, Color.rgb(238, 171, 55))
            value.contains("dub") || value.contains("audio") || label.contains("دوبله") || label.contains("صوت") -> DownloadKindUi(label, R.drawable.ic_dubbed_mic_green, Color.rgb(34, 205, 166))
            else -> DownloadKindUi(label, R.drawable.ic_bm_headphones, Color.rgb(34, 205, 166))
        }
    }

    private fun downloadPillParams() = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(29)).apply {
        marginStart = dp(7)
    }

    private fun downloadMetaPill(label: String, iconRes: Int, accent: Int): TextView = TextView(this).apply {
        text = label
        setTextColor(accent)
        textSize = 9.7f
        typeface = BankmovieFonts.medium(this@DownloadsActivity)
        gravity = Gravity.CENTER
        includeFontPadding = false
        compoundDrawablePadding = dp(6)
        setCompoundDrawablesRelativeWithIntrinsicBounds(tintedDrawable(iconRes, accent, dp(14)), null, null, null)
        setPadding(dp(7), 0, dp(7), 0)
        background = rounded(Color.argb(24, Color.red(accent), Color.green(accent), Color.blue(accent)), 999, Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)))
    }

    private fun completedActionParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        marginStart = dp(3)
        marginEnd = dp(3)
    }

    private fun completedActionButton(label: String, iconRes: Int, danger: Boolean, key: String, click: () -> Unit): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = if (danger) rounded(Color.argb(55, 205, 22, 58), 15, Color.argb(150, 255, 45, 85)) else glassTint(palette.primary, 15)
            isClickable = true
            isFocusable = true
            focusKey(this, "download:$key")
            premiumFocus(this, 17)
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (danger) Color.rgb(255, 102, 126) else palette.primary2)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@DownloadsActivity).apply {
                text = label
                setTextColor(if (danger) Color.rgb(255, 128, 145) else palette.text)
                textSize = 10.1f
                typeface = BankmovieFonts.bold(this@DownloadsActivity)
                gravity = Gravity.CENTER
                maxLines = 1
            })
            setOnClickListener { click() }
        }
    }

    private fun showDownloadItemMenu(item: JSONObject) {
        val status = item.optString("status")
        if (status == InternalDownloadStore.STATUS_COMPLETED) {
            AlertDialog.Builder(this)
                .setTitle(item.optString("title").ifBlank { "BankMovie" })
                .setItems(arrayOf("پخش آفلاین", "اشتراک‌گذاری", "حذف")) { _, which ->
                    when (which) {
                        0 -> playDownloadedOffline(item)
                        1 -> shareDownloaded(item)
                        2 -> showDeleteOptions(item)
                    }
                }.show()
            return
        }
        val id = item.optString("id")
        val canResume = status in setOf(InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_FAILED, InternalDownloadStore.STATUS_SCHEDULED)
        val labels = if (canResume) arrayOf("ادامه دانلود", "لغو دانلود") else arrayOf("توقف دانلود", "لغو دانلود")
        AlertDialog.Builder(this)
            .setTitle(item.optString("title").ifBlank { "دانلود" })
            .setItems(labels) { _, which ->
                if (which == 0) {
                    InternalDownloadService.command(this, if (canResume) InternalDownloadService.ACTION_RESUME else InternalDownloadService.ACTION_PAUSE, id)
                } else {
                    InternalDownloadService.command(this, InternalDownloadService.ACTION_CANCEL, id)
                }
            }.show()
    }

    private fun buttonParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(dp(78), dp(40)).apply { marginStart = dp(7) }

    private fun ensureDownloadFocusId(view: View): Int {
        if (view.id == View.NO_ID) view.id = View.generateViewId()
        return view.id
    }

    private fun visibleDownloadActionRows(): List<LinearLayout> {
        val rows = mutableListOf<LinearLayout>()
        fun collect(view: View) {
            if (view.visibility != View.VISIBLE) return
            if (view is LinearLayout && view.tag == "bm_download_action_row") rows += view
            if (view is ViewGroup) for (i in 0 until view.childCount) collect(view.getChildAt(i))
        }
        if (::downloadsBox.isInitialized) collect(downloadsBox)
        return rows
    }

    /**
     * The downloader shell used to form two geometric focus islands: the folder /
     * schedule/help cards and the horizontal action buttons. Give TV an explicit
     * vertical chain so DPAD_UP/DOWN can always enter and leave the download list.
     */
    private fun bindDownloadsTvFocusChain() {
        if (!isTvLike() || !::content.isInitialized) return
        val filters = listOf(allTab, moviesTab, seriesTab, completedTab)
        filters.forEach(::ensureDownloadFocusId)
        val storage = findFocusKey(content, "downloads:storage-summary")
        val folder = findFocusKey(content, "downloads:folder")
        val schedule = findFocusKey(content, "downloads:schedule")
        val bulk = findFocusKey(content, "downloads:bulk-import")
        val help = findFocusKey(content, "downloads:help")
        val shell = listOfNotNull(storage, folder, schedule, bulk)
        shell.forEach(::ensureDownloadFocusId)
        help?.let(::ensureDownloadFocusId)

        fun bindVerticalKey(view: View, up: View?, down: View?) {
            view.setOnKeyListener { _, keyCode, event ->
                if (event.action != android.view.KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                if (event.repeatCount != 0 && (keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP || keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN)) {
                    return@setOnKeyListener true
                }
                when (keyCode) {
                    android.view.KeyEvent.KEYCODE_DPAD_UP -> { up?.requestFocus(); true }
                    android.view.KeyEvent.KEYCODE_DPAD_DOWN -> { down?.requestFocus(); true }
                    else -> false
                }
            }
        }

        val shellTop = shell.firstOrNull()
        if (shellTop != null) filters.forEach {
            it.nextFocusDownId = shellTop.id
            bindVerticalKey(it, null, shellTop)
        }
        shell.forEachIndexed { index, view ->
            val up = shell.getOrNull(index - 1) ?: allTab
            val down = shell.getOrNull(index + 1)
            view.nextFocusUpId = up.id
            if (down != null) view.nextFocusDownId = down.id
            bindVerticalKey(view, up, down)
        }

        val rows = visibleDownloadActionRows()
        rows.forEach { row -> for (i in 0 until row.childCount) ensureDownloadFocusId(row.getChildAt(i)) }
        val firstAction = rows.firstOrNull()?.getChildAt(0)
        val lastAction = rows.lastOrNull()?.getChildAt(0)
        val bridgeAboveList = bulk ?: schedule ?: folder ?: storage ?: allTab
        if (firstAction != null) {
            shell.lastOrNull()?.let { lastShell ->
                lastShell.nextFocusDownId = firstAction.id
                bindVerticalKey(lastShell, shell.getOrNull(shell.lastIndex - 1) ?: allTab, firstAction)
            }
            for (i in 0 until (rows.firstOrNull()?.childCount ?: 0)) {
                rows.first().getChildAt(i).nextFocusUpId = bridgeAboveList.id
            }
        } else if (help != null) {
            shell.lastOrNull()?.let { lastShell ->
                lastShell.nextFocusDownId = help.id
                bindVerticalKey(lastShell, shell.getOrNull(shell.lastIndex - 1) ?: allTab, help)
            }
        }
        if (help != null) {
            val upTarget = lastAction ?: bridgeAboveList
            help.nextFocusUpId = upTarget.id
            bindVerticalKey(help, upTarget, null)
        }
    }

    /**
     * TV downloader navigation must be row-aware. Android's geometric focus search
     * sees all action buttons inside nested HorizontalScrollViews and can bounce
     * between two buttons in the same card instead of moving to the next download.
     *
     * UP/DOWN now moves exactly one download card while preserving the action
     * column as closely as possible. LEFT/RIGHT remain native inside each row.
     */
    private fun bindDownloadActionVerticalFocus(row: LinearLayout) {
        if (!isTvLike()) return
        for (i in 0 until row.childCount) {
            val button = row.getChildAt(i)
            button.setOnKeyListener { current, keyCode, event ->
                if (event.action != android.view.KeyEvent.ACTION_DOWN ||
                    (keyCode != android.view.KeyEvent.KEYCODE_DPAD_DOWN &&
                        keyCode != android.view.KeyEvent.KEYCODE_DPAD_UP)
                ) {
                    return@setOnKeyListener false
                }
                if (event.repeatCount != 0) return@setOnKeyListener true

                val rows = mutableListOf<LinearLayout>()
                fun collect(view: View) {
                    if (view.visibility != View.VISIBLE) return
                    if (view is LinearLayout && view.tag == "bm_download_action_row") rows += view
                    if (view is ViewGroup) {
                        for (childIndex in 0 until view.childCount) collect(view.getChildAt(childIndex))
                    }
                }
                collect(downloadsBox)

                val rowIndex = rows.indexOf(row)
                if (rowIndex < 0) return@setOnKeyListener false
                val nextRowIndex = if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) rowIndex + 1 else rowIndex - 1

                if (nextRowIndex !in rows.indices) {
                    if (keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                        val help = findFocusKey(content, "downloads:help")
                        if (help != null) {
                            help.requestFocus()
                            return@setOnKeyListener true
                        }
                    } else {
                        val above = findFocusKey(content, "downloads:bulk-import")
                            ?: findFocusKey(content, "downloads:schedule")
                            ?: findFocusKey(content, "downloads:folder")
                            ?: findFocusKey(content, "downloads:storage-summary")
                            ?: allTab
                        above.requestFocus()
                        return@setOnKeyListener true
                    }
                    return@setOnKeyListener false
                }

                val targetRow = rows[nextRowIndex]
                if (targetRow.childCount <= 0) return@setOnKeyListener false
                val currentColumn = row.indexOfChild(current).coerceAtLeast(0)
                val target = targetRow.getChildAt(currentColumn.coerceAtMost(targetRow.childCount - 1))
                target.requestFocus()
                true
            }
        }
    }

    private fun actionButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 130, 140) else palette.onPrimary)
        textSize = 11.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) {
            rounded(Color.argb(45, 235, 35, 55), 14, Color.argb(130, 235, 35, 55))
        } else {
            glassTint(palette.primary, 14)
        }
        focusKey(this, "download:$key")
        premiumFocus(this, 14)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(78), dp(40))
    }

    private fun updateProgressOnly(items: List<JSONObject>) {
        items.forEach { item ->
            val id = item.optString("id")
            val refs = cardRefs[id] ?: return@forEach
            val downloaded = item.optLong("downloaded", 0L)
            val total = item.optLong("total", 0L)
            val speed = item.optLong("speed", 0L)
            val status = item.optString("status")
            val percent = percent(downloaded, total)
            refs.progress.isIndeterminate = (total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING) || status == InternalDownloadStore.STATUS_VERIFYING
            if (!refs.progress.isIndeterminate) refs.progress.progress = percent
            refs.status.text = statusLabel(status, percent, speed)
            refs.bytes.text = if (status == InternalDownloadStore.STATUS_COMPLETED) "100%" else bytesLabel(downloaded, total)
            refs.remaining.text = remainingLabel(downloaded, total, speed, status)
            refs.fileInfo.text = fileInfoLabel(item)
        }
    }

    private fun downloadedUri(item: JSONObject): Pair<Uri, String>? {
        val mime = InternalDownloadStore.mimeForName(item.optString("file_name"))
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank() || !InternalDownloadStore.exists(this, item)) null else Uri.parse(raw) to mime
        } else {
            val file = File(item.optString("path"))
            if (!file.exists()) null else FileProvider.getUriForFile(this, "$packageName.files", file) to mime
        }
    }

    private fun shareDownloaded(item: JSONObject) {
        val target = downloadedUri(item)
        if (target == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "اشتراک‌گذاری فایل"))
        }.onFailure { Toast.makeText(this, "امکان اشتراک‌گذاری فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
    }

    private fun sendDownloadedToDevice(item: JSONObject) {
        val target = downloadedUri(item)
        if (target == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                putExtra(Intent.EXTRA_TITLE, item.optString("title"))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "ارسال به دستگاه"))
        }.onFailure { Toast.makeText(this, "برنامه‌ای برای ارسال فایل پیدا نشد", Toast.LENGTH_SHORT).show() }
    }

    private fun downloadedPlaybackSource(item: JSONObject): String? {
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            raw.takeIf { it.isNotBlank() && InternalDownloadStore.exists(this, item) }
        } else {
            val file = File(item.optString("path"))
            file.takeIf { it.isFile && it.length() > 0L }?.absolutePath
        }
    }

    private fun playDownloadedOffline(item: JSONObject) {
        val source = downloadedPlaybackSource(item)
        if (source.isNullOrBlank()) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            lastStructure = ""
            refreshDownloads(true)
            return
        }
        runCatching {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_VIDEO_URL, source)
                putExtra(PlayerActivity.EXTRA_TITLE, item.optString("title").ifBlank { "BankMovie" })
                putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, "offline:${item.optString("id")}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }.onFailure {
            openDownloaded(item)
        }
    }

    private fun showDeleteOptions(item: JSONObject) {
        val id = item.optString("id")
        AlertDialog.Builder(this)
            .setTitle("حذف دانلود")
            .setItems(arrayOf("حذف فایل و رکورد", "حذف فقط رکورد دانلود", "انصراف")) { dialog, which ->
                when (which) {
                    0 -> InternalDownloadStore.remove(this, id, true)
                    1 -> InternalDownloadStore.remove(this, id, false)
                    else -> { dialog.dismiss(); return@setItems }
                }
                lastStructure = ""
                refreshDownloads(true)
            }.show()
    }

    private fun openDownloaded(item: JSONObject) {
        val target = downloadedUri(item)
        if (target == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(target.first, target.second)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Throwable) {
            Toast.makeText(this, "برنامه‌ای برای بازکردن فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun percent(downloaded: Long, total: Long): Int = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0

    private fun isActive(status: String): Boolean = status in setOf(
        InternalDownloadStore.STATUS_QUEUED,
        InternalDownloadStore.STATUS_DOWNLOADING,
        InternalDownloadStore.STATUS_RETRYING,
        InternalDownloadStore.STATUS_VERIFYING,
        InternalDownloadStore.STATUS_PAUSED,
        InternalDownloadStore.STATUS_SCHEDULED
    )

    private fun statusChipText(status: String): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف"
        InternalDownloadStore.STATUS_DOWNLOADING -> "در حال دانلود"
        InternalDownloadStore.STATUS_RETRYING -> "تلاش مجدد"
        InternalDownloadStore.STATUS_VERIFYING -> "بررسی فایل"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده"
        InternalDownloadStore.STATUS_SCHEDULED -> "زمان‌بندی‌شده"
        InternalDownloadStore.STATUS_COMPLETED -> "کامل شده"
        InternalDownloadStore.STATUS_FAILED -> "خطا"
        else -> "لغو شده"
    }

    private fun statusColor(status: String, primary: Int): Int = when (status) {
        InternalDownloadStore.STATUS_COMPLETED -> Color.rgb(75, 210, 135)
        InternalDownloadStore.STATUS_FAILED -> Color.rgb(255, 110, 120)
        InternalDownloadStore.STATUS_PAUSED -> Color.rgb(255, 169, 78)
        InternalDownloadStore.STATUS_SCHEDULED -> Color.rgb(160, 112, 245)
        InternalDownloadStore.STATUS_RETRYING -> Color.rgb(255, 190, 70)
        InternalDownloadStore.STATUS_VERIFYING -> Color.rgb(80, 190, 245)
        else -> primary
    }

    private fun fileInfoLabel(item: JSONObject): String {
        val total = item.optLong("total", 0L)
        val downloaded = item.optLong("downloaded", 0L)
        val checked = item.optBoolean("resume_checked", false)
        val resume = item.optBoolean("resume_supported", false)
        val multipart = item.optBoolean("multipart", false)
        val parts = item.optInt("multipart_parts", 1).coerceAtLeast(1)
        val attempt = item.optInt("retry_attempt", 0)
        val maxRetry = item.optInt("retry_max", AccountSession.downloadRetryCount(this))
        val bits = mutableListOf<String>()
        if (total > 0L) bits += "حجم: ${humanSize(total)}" else if (!checked) bits += "در حال دریافت حجم فایل..." else bits += "حجم نامشخص"
        if (total > downloaded && downloaded > 0L) bits += "باقی‌مانده: ${humanSize(total - downloaded)}"
        if (checked) bits += if (resume) "ادامه واقعی" else "ادامه در صورت پشتیبانی سرور"
        if (multipart) bits += "$parts بخش هم‌زمان"
        if (attempt > 0) bits += "تلاش $attempt از $maxRetry"
        return bits.joinToString("  •  ")
    }

    private fun statusLabel(status: String, percent: Int, speed: Long): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف دانلود"
        InternalDownloadStore.STATUS_DOWNLOADING -> "$percent٪  •  ${humanSize(speed)}/s"
        InternalDownloadStore.STATUS_RETRYING -> "اتصال ناپایدار؛ تلاش مجدد خودکار"
        InternalDownloadStore.STATUS_VERIFYING -> "در حال بررسی کامل‌بودن فایل"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده • $percent٪"
        InternalDownloadStore.STATUS_SCHEDULED -> "در انتظار زمان‌بندی"
        InternalDownloadStore.STATUS_COMPLETED -> "✓ دانلود کامل شد"
        InternalDownloadStore.STATUS_FAILED -> "دانلود پس از تلاش‌های مجدد ناموفق شد"
        else -> "لغو شده"
    }

    private fun bytesLabel(downloaded: Long, total: Long): String {
        return if (total > 0L) "${humanSize(downloaded)} / ${humanSize(total)}" else humanSize(downloaded)
    }

    private fun remainingLabel(downloaded: Long, total: Long, speed: Long, status: String): String {
        if (status == InternalDownloadStore.STATUS_COMPLETED) return "آماده پخش"
        if (status == InternalDownloadStore.STATUS_RETRYING) return "در انتظار اتصال پایدار"
        if (status == InternalDownloadStore.STATUS_VERIFYING) return "بررسی اندازه نهایی"
        if (status == InternalDownloadStore.STATUS_SCHEDULED) return "شروع در زمان تعیین‌شده"
        if (total > downloaded && status != InternalDownloadStore.STATUS_DOWNLOADING) return "${humanSize(total - downloaded)} باقی‌مانده"
        if (status != InternalDownloadStore.STATUS_DOWNLOADING || speed <= 0L || total <= downloaded) return ""
        val seconds = ((total - downloaded) / speed).coerceAtLeast(0L)
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val secs = seconds % 60L
        return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d مانده", hours, minutes, secs)
        else String.format(Locale.US, "%02d:%02d مانده", minutes, secs)
    }

    private fun humanSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        return if (mb >= 1024.0) String.format(Locale.US, "%.2f GB", mb / 1024.0) else String.format(Locale.US, "%.1f MB", mb)
    }

    private fun normalizePoster(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value == "null") return ""
        if (value.startsWith("//")) return "https:$value"
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return AppConfig.BASE_URL.trimEnd('/') + "/" + value.trimStart('/')
    }

    private fun loadPoster(raw: String, target: ImageView) {
        val url = normalizePoster(raw)
        if (url.isBlank()) return
        target.tag = url
        val cached = posterCache.get(url)
        if (cached != null && !cached.isRecycled) {
            target.setPadding(0, 0, 0, 0)
            target.setImageBitmap(cached)
            return
        }
        imageExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 6500
                connection.readTimeout = 8500
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "Bankmovie Android")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                var bitmap = BitmapFactory.decodeStream(connection.inputStream, null, options) ?: return@execute
                val bigger = max(bitmap.width, bitmap.height)
                if (bigger > 520) {
                    val ratio = 520f / bigger.toFloat()
                    val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true)
                    if (scaled !== bitmap) {
                        bitmap.recycle()
                        bitmap = scaled
                    }
                }
                posterCache.put(url, bitmap)
                runOnUiThread {
                    if (!isFinishing && target.tag == url && !bitmap.isRecycled) {
                        target.setPadding(0, 0, 0, 0)
                        target.alpha = 0.35f
                        target.setImageBitmap(bitmap)
                        target.animate().alpha(1f).setDuration(180L).start()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { connection?.disconnect() }
            }
        }
    }

    private fun tintedDrawable(resId: Int, color: Int, sizeDp: Int): Drawable? = ContextCompat.getDrawable(this, resId)?.mutate()?.apply {
        setTint(color)
        setBounds(0, 0, dp(sizeDp), dp(sizeDp))
    }

    private fun focusKey(view: View, key: String) {
        view.setTag(R.id.bm_focus_restore_key, key)
    }

    private fun findFocusKey(view: View, key: String): View? {
        if (view.getTag(R.id.bm_focus_restore_key) == key && view.visibility == View.VISIBLE) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val found = findFocusKey(view.getChildAt(i), key)
                if (found != null) return found
            }
        }
        return null
    }

    private fun focusFirst(view: View): Boolean {
        if (view.isFocusable && view.isEnabled && view.visibility == View.VISIBLE && view.hasOnClickListeners()) {
            view.requestFocus()
            return true
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) if (focusFirst(view.getChildAt(i))) return true
        }
        return false
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun focusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val glow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.argb(42, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(160, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclamp(view: View) {
        var parent = view.parent
        while (parent is ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun premiumFocus(view: View, radius: Int = 16) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val normalElevation = view.elevation
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        view.setOnFocusChangeListener { target, focused ->
            target.animate().cancel()
            if (focused) {
                // V7.15: focus glow must be visual-only. bringToFront() mutates the
                // child order of LinearLayout action rows, so moving UP/DOWN could
                // literally reshuffle Pause/Cancel/Open/Delete buttons on screen.
                unclamp(target)
            }
            target.foreground = if (focused) focusDrawable(radius) else originalForeground
            target.elevation = if (focused) dp(20).toFloat() else normalElevation
            target.translationZ = if (focused) dp(7).toFloat() else 0f
            target.animate()
                .scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f)
                .setDuration(if (focused) 145L else 105L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun glass(radius: Int, elevated: Boolean = false): GradientDrawable {
        // PASS 3.1 compile fix: DownloadsActivity has no class-level palette property.
        // Resolve the active UI palette locally so the shared glass style remains dynamic.
        val p = UiPreferences.palette(this)
        val base = if (p.light) p.panel else p.panel2
        val topBase = UiPreferences.blend(base, Color.WHITE, if (p.light) 0.03f else 0.07f)
        val bottomBase = UiPreferences.blend(base, Color.BLACK, if (p.light) 0.01f else 0.05f)
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(if (p.light) 248 else 236, Color.red(topBase), Color.green(topBase), Color.blue(topBase)),
                Color.argb(if (p.light) 244 else if (elevated) 224 else 216, Color.red(bottomBase), Color.green(bottomBase), Color.blue(bottomBase))
            )
        ).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), if (p.light) Color.argb(65, 20, 24, 31) else Color.argb(68, 255, 255, 255))
        }
    }

    private fun glassTint(accent: Int, radius: Int): GradientDrawable {
        val p = UiPreferences.palette(this)
        val base = if (p.light) p.panel else p.panel2
        val top = UiPreferences.blend(base, accent, if (p.light) 0.13f else 0.25f)
        val bottom = UiPreferences.blend(base, Color.BLACK, if (p.light) 0.02f else 0.05f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(if (p.light) 90 else 112, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
