package ir.bankmoviee.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

object BankmovieFonts {
    data class FontOption(val key: String, val faLabel: String, val enLabel: String)

    private val cache = linkedMapOf<String, Typeface>()

    /**
     * V7.45.9: BankMovie uses static instances generated from the exact Filimo
     * variable face used by the website. The source variable font has wght=100
     * as its default axis value; loading that variable TTF directly on Android
     * therefore rendered the whole app as Thin. GitHub Actions now instantiates
     * real 400/500/700/900/950 TTF files before Gradle runs, matching the CSS
     * weights used by bankmovie.top instead of relying on synthetic Android bold.
     */
    val options = listOf(
        FontOption("bankmovie", "بانک مووی", "BankMovie"),
        FontOption("font", "ایرانسل", "Irancell"),
        FontOption("iransans", "ایران‌سنس X", "IRANSansX"),
        FontOption("diako", "دیاکو هیما", "Diako Hima"),
        FontOption("nic", "نیک", "Nic"),
        FontOption("cinema", "سینما", "Cinema"),
        FontOption("system", "سیستمی", "System")
    )

    @Synchronized
    private fun asset(context: Context, fileName: String, fallback: () -> Typeface): Typeface {
        cache[fileName]?.let { return it }
        val loaded = runCatching {
            val downloaded = java.io.File(context.filesDir, "fonts/$fileName")
            if (downloaded.isFile && downloaded.length() > 1024L) {
                Typeface.createFromFile(downloaded)
            } else {
                Typeface.createFromAsset(context.assets, "fonts/$fileName")
            }
        }.getOrElse { fallback() }
        cache[fileName] = loaded
        return loaded
    }

    /**
     * Compatibility fallback for a locally-built V7.45.8 asset pack. New
     * release builds always contain the static files below, but keeping this
     * fallback means developer installs don't silently drop to Roboto.
     */
    private fun legacyBankmovieVariable(context: Context): Typeface = asset(context, "bankmovie_filimo.ttf") {
        Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun bankmovieRegular(context: Context): Typeface = asset(context, "bankmovie_filimo_400.ttf") {
        legacyBankmovieVariable(context)
    }

    private fun bankmovieMedium(context: Context): Typeface = asset(context, "bankmovie_filimo_500.ttf") {
        bankmovieRegular(context)
    }

    private fun bankmovieSemiBold(context: Context): Typeface = asset(context, "bankmovie_filimo_700.ttf") {
        Typeface.create(bankmovieMedium(context), Typeface.BOLD)
    }

    private fun bankmovieBold(context: Context): Typeface = asset(context, "bankmovie_filimo_900.ttf") {
        bankmovieSemiBold(context)
    }

    private fun bankmovieBlack(context: Context): Typeface = asset(context, "bankmovie_filimo_950.ttf") {
        bankmovieBold(context)
    }

    private fun irancellRegular(context: Context): Typeface = asset(context, "irancell_regular.ttf") {
        bankmovieRegular(context)
    }

    private fun irancellMedium(context: Context): Typeface = asset(context, "irancell_medium.ttf") {
        irancellRegular(context)
    }

    private fun irancellSemiBold(context: Context): Typeface = asset(context, "irancell_semibold.ttf") {
        Typeface.create(irancellRegular(context), Typeface.BOLD)
    }

    private fun irancellBold(context: Context): Typeface = asset(context, "irancell_bold.ttf") {
        irancellSemiBold(context)
    }

    private fun irancellBlack(context: Context): Typeface = asset(context, "irancell_black.ttf") {
        irancellBold(context)
    }

    fun regular(context: Context): Typeface = bankmovieRegular(context)
    fun medium(context: Context): Typeface = bankmovieMedium(context)
    fun semiBold(context: Context): Typeface = bankmovieSemiBold(context)
    fun bold(context: Context): Typeface = bankmovieBold(context)
    fun black(context: Context): Typeface = bankmovieBlack(context)

    fun iranSansRegular(context: Context): Typeface = asset(context, "iransansx_regular.ttf") { regular(context) }
    fun iranSansMedium(context: Context): Typeface = asset(context, "iransansx_medium.ttf") { iranSansRegular(context) }
    fun iranSansBold(context: Context): Typeface = asset(context, "iransansx_bold.ttf") {
        Typeface.create(iranSansMedium(context), Typeface.BOLD)
    }

    fun diako(context: Context): Typeface = asset(context, "diako_hima.ttf") { regular(context) }
    fun nic(context: Context): Typeface = asset(context, "nic.ttf") { regular(context) }
    fun cinema(context: Context): Typeface = asset(context, "cinema.otf") { regular(context) }

    fun forMode(context: Context, mode: String, bold: Boolean = false): Typeface {
        return when (mode) {
            "bankmovie" -> if (bold) this.bold(context) else regular(context)
            "font" -> if (bold) irancellBold(context) else irancellRegular(context)
            "iransans" -> if (bold) iranSansBold(context) else iranSansRegular(context)
            "diako" -> Typeface.create(diako(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            "nic" -> Typeface.create(nic(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            "cinema" -> Typeface.create(cinema(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            else -> Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    fun label(mode: String, english: Boolean = false): String {
        val option = options.firstOrNull { it.key == mode } ?: options.first()
        return if (english) option.enLabel else option.faLabel
    }

    fun assetFileName(mode: String): String? = when (mode) {
        "bankmovie" -> "bankmovie_filimo_400.ttf"
        "font" -> "irancell_regular.ttf"
        "iransans" -> "iransansx_regular.ttf"
        "diako" -> "diako_hima.ttf"
        "nic" -> "nic.ttf"
        "cinema" -> "cinema.otf"
        else -> null
    }

    fun applyToTree(context: Context, view: View) {
        val mode = UiPreferences.appFontMode(context)
        fun walk(node: View) {
            if (node is TextView && node.tag?.toString() != "preserve_typeface") {
                val current = node.typeface
                node.typeface = if (mode == "bankmovie") {
                    // Preserve explicit BankMovie weights set by individual UI
                    // components. Generic DEFAULT_BOLD/other-font bold text maps
                    // to the site's 900 weight; normal text maps to 400.
                    when {
                        current === bankmovieBlack(context) -> bankmovieBlack(context)
                        current === bankmovieBold(context) -> bankmovieBold(context)
                        current === bankmovieSemiBold(context) -> bankmovieSemiBold(context)
                        current === bankmovieMedium(context) -> bankmovieMedium(context)
                        current === bankmovieRegular(context) -> bankmovieRegular(context)
                        ((current?.style ?: Typeface.NORMAL) and Typeface.BOLD) != 0 -> bankmovieBold(context)
                        else -> bankmovieRegular(context)
                    }
                } else {
                    val oldStyle = current?.style ?: Typeface.NORMAL
                    forMode(context, mode, oldStyle and Typeface.BOLD != 0)
                }
            }
            if (node is ViewGroup) {
                for (i in 0 until node.childCount) walk(node.getChildAt(i))
            }
        }
        walk(view)
    }
}
