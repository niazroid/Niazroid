Font binaries are injected at GitHub Actions build time and are not committed inside this source archive.

V7.45.9 default app font:
- BankMovie uses the exact Filimo Demo Variable face already used by the website.
- IMPORTANT: that variable font declares wght=100 as its default axis value. Loading the converted variable TTF directly on Android made the UI render Thin even when the website rendered normal/bold weights.
- The build now creates real static instances from the same source font at weights 400, 500, 700, 900 and 950.
- Website-style mapping in Android:
  - regular -> 400
  - medium -> 500
  - semibold -> 700
  - bold -> 900
  - black -> 950
- Workflow first looks for repository-root `filimo-demo-variable-vf.woff2`.
- If it is not present, Workflow downloads the same website asset from:
  https://bankmovie.top/assets/fonts/filimo-demo-variable-vf.woff2

Other repository-root font files kept from previous releases:
- irancell [@fontbazi].zip
- Cinema.otf
- Diako Hima Regular-@Fontsplua.ttf
- Nic [@fontbazi].ttf
- IRANSansXFaNum-regular*.woff2
- IRANSansXFaNum-medium*.woff2
- IRANSansXFaNum-bold*.woff2

Generated Android asset names:
- bankmovie_filimo_400.ttf
- bankmovie_filimo_500.ttf
- bankmovie_filimo_700.ttf
- bankmovie_filimo_900.ttf
- bankmovie_filimo_950.ttf
- irancell_regular.ttf
- irancell_medium.ttf
- irancell_semibold.ttf
- irancell_bold.ttf
- irancell_black.ttf
- cinema.otf
- diako_hima.ttf
- nic.ttf
- iransansx_regular.ttf
- iransansx_medium.ttf
- iransansx_bold.ttf

The workflow fails before Gradle if any required font asset is missing, so the app cannot silently fall back to the system font because a font injection step was skipped.
