# BankMovie V7.43.1 — Section Hard Hide Fix

این هات‌فیکس رفتار «غیرفعال» در کنترل ریز بخش‌های آرشیوها را اصلاح می‌کند.

## رفتار جدید

- اگر «نمایش بخش» خاموش باشد، کل ردیف از Home حذف می‌شود.
- اگر سطح دسترسی روی `disabled` باشد، آن هم معادل مخفی‌سازی کامل است؛ عنوان، هدر، اسکلتون، Empty State و Retry Card نمایش داده نمی‌شوند.
- پاسخ API با `section_disabled=true` یا `status=disabled` باعث حذف همان ردیف از درخت Home می‌شود؛ بنابراین حتی اگر تنظیمات کلاینت لحظه‌ای stale باشد، خطای «این ردیف بارگذاری نشد» نمایش داده نمی‌شود.
- Quick Tab همان بخش نیز مخفی می‌شود.
- سطح‌های `member` / `vip` / `admin` همچنان گیت دسترسی هستند و می‌توانند بخش را قابل مشاهده ولی قفل نگه دارند.
- BM Admin متن `disabled` را به «غیرفعال / مخفی کامل» تغییر داده و هنگام انتخاب آن، تیک نمایش بخش نیز خاموش می‌شود.

## فایل‌های اصلی تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `server-required/bm_admin.php`
- `server-required/app_config.php`
- `server-required/includes/app_archive_policy.php`

سمت هاست، نسخه جداگانه‌ی Server Patch بر پایه همان Assets15/V7.43 ارائه شده است و نباید `server-required` داخل سورس Android را جایگزین فایل‌های هاست کرد.
