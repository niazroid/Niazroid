#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DOWNLOADS="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"

grep -Fq 'this.text = "گالری آفلاین"' "$DOWNLOADS" || {
  echo 'VERIFY_V7466_1_MISSING: qualified TextView.text assignment' >&2
  exit 1
}
# The old unqualified assignment was captured by emptyState()'s local val `text`
# and produced: DownloadsActivity.kt:1119:21 val cannot be reassigned.
if grep -Fq '                    text = "گالری آفلاین"' "$DOWNLOADS"; then
  echo 'VERIFY_V7466_1_FORBIDDEN: unqualified gallery text assignment still present' >&2
  exit 1
fi
echo VERIFY_V7466_1_KOTLIN_COMPILE_HOTFIX_OK
