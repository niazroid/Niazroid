# BankMovie V7.45.4 — Watch Party Chat / Verified Badge / Bubble Polish

این نسخه ادامه‌ی V7.45.3 است و روی ظاهر چت واچ‌پارتی و نمایش وضعیت کاربران تمرکز دارد.

## تغییرات

### 1) اصلاح کامل Bubble پیام‌های Watch Party
- عرض Bubble دیگر از عرض کل صفحه محاسبه نمی‌شود و مستقیماً از عرض Drawer چت به دست می‌آید.
- روی Landscape و دستگاه‌های DPI بالا، Bubble + Avatar از پنل بیرون نمی‌زنند.
- برای پیام کوتاه حداقل عرض متعادل و برای پیام بلند حداکثر عرض کنترل‌شده در نظر گرفته شده است.
- گوشه‌ها، Stroke، Padding، فاصله Avatar و فاصله بین پیام‌ها مرتب‌تر شده‌اند.
- تصویر/استیکر داخل Bubble نیز به عرض واقعی Drawer محدود شده و Clip/Rounded می‌شود.

### 2) VIP = تیک سبز Verified
- نشان سبز قبلی پروژه به resource مستقل `ic_vip_verified_green.xml` منتقل شد.
- کاربران VIP در چت واچ‌پارتی و کامنت‌ها با تیک سبز نمایش داده می‌شوند.
- Border آواتار VIP در Watch Party نیز سبز شده است.

### 3) Admin = تیک آبی جدید
- `ic_admin_verified.xml` با SVG آبی ارسال‌شده جایگزین شد.
- ادمین در چت، کامنت‌ها و بخش‌های قبلی که از نشان Admin استفاده می‌کنند با Badge آبی دیده می‌شود.
- Border آواتار Admin در Watch Party آبی شده است.

### 4) کامنت‌ها
- وضعیت Admin/VIP علاوه بر `badge` از `is_admin`, `is_vip`, `vip`, `role` نیز تشخیص داده می‌شود.
- کامنت‌های موبایل و TV هر دو از Badgeهای جدید استفاده می‌کنند.
- متن وضعیت Admin آبی و VIP سبز شده است.

### 5) پروفایل داخل منوی همبرگری
- در Header حساب کاربری Drawer موبایل، کنار نام کاربر Badge قرار می‌گیرد.
- VIP = تیک سبز.
- Admin = تیک آبی.
- Border آواتار و متن وضعیت نیز با نوع حساب هماهنگ شده است.

## فایل‌های تغییرکرده
- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/res/drawable/ic_admin_verified.xml`
- `app/src/main/res/drawable/ic_vip_verified_green.xml`

## سرور
برای این تغییرات فایل سمت سرور لازم نیست.
