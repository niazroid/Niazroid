#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
admin='server-required/bm_admin.php'
appcfg='server-required/app_config.php'
policy='server-required/includes/app_archive_policy.php'

bash verify_v743_section_controls.sh

grep -Fq 'BM Admin "disabled" means a hard hide' "$main"
grep -Fq 'if (normalizeFeatureScope(remoteHomeSectionScopes[safe]?.get(key), "public") == "disabled") return false' "$main"
grep -Fq 'private fun sectionResponseRequestsHardHide(json: JSONObject?): Boolean' "$main"
grep -Fq 'json.optBoolean("section_disabled", false)' "$main"
grep -Fq 'removeHomeSectionBox(box)' "$main"
grep -Fq 'if (!homeSectionEnabled(archive, section) || homeSectionScope(archive, section) == "disabled") return' "$main"
grep -Fq "if (\$scope === 'disabled') \$enabled = false;" "$appcfg"
grep -Fq "'disabled'=>'غیرفعال / مخفی کامل'" "$admin"
grep -Fq "if (\$sectionScope === 'disabled') \$sectionEnabled = false;" "$admin"
grep -Fq "if (\$scope === 'disabled') \$enabled = false;" "$policy"
grep -Fq 'sourceMainUpdateTwentySeventhHotfixTag=BANKMOVIE-2.3-V7431-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

php -l "$admin" >/dev/null
php -l "$appcfg" >/dev/null
php -l "$policy" >/dev/null

echo V7431_SECTION_HARD_HIDE_VERIFY_OK
