#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
archive="$root/server-required/includes/archive_control.php"
redirect="$root/server-required/includes/download_redirect.php"
admin="$root/server-required/bm_admin.php"
config="$root/server-required/app_config.php"

php -l "$archive" >/dev/null
php -l "$redirect" >/dev/null
php -l "$admin" >/dev/null
php -l "$config" >/dev/null

grep -Fq "'download_redirect_enabled' => true" "$archive"
grep -Fq "function bm_archive_download_redirect_enabled" "$archive"
grep -Fq "if (!bm_archive_download_redirect_enabled()) return 'original';" "$archive"
grep -Fq "if (!bm_archive_download_redirect_enabled()) return 'all';" "$archive"
grep -Fq 'name="download_redirect_enabled"' "$admin"
grep -Fq "\$archiveSettings['download_redirect_enabled'] = \$downloadRedirectEnabled;" "$admin"
grep -Fq "'redirect_enabled'=>\$downloadRedirectEnabled" "$admin"
grep -Fq "['redirect_enabled'] = function_exists('bm_archive_download_redirect_enabled')" "$config"

tmp="$(mktemp -d)"
trap 'rm -rf "$tmp"' EXIT
cp -a "$root/server-required" "$tmp/server-required"
mkdir -p "$tmp/private"

BANKMOVIE_PRIVATE_DIR="$tmp/private" php -d display_errors=1 -r '
$root=$argv[1];
require $root . "/server-required/includes/archive_control.php";
require $root . "/server-required/includes/download_redirect.php";

$settings=bm_archive_control_defaults();
$settings["download_redirect_enabled"]=false;
$settings["archives"]["archive1"]["download_link_mode"]="redirect";
$settings["archives"]["archive1"]["download_client_mode"]="adm_copy";
$settings["archives"]["archive2"]["download_link_mode"]="disabled";
$settings["archives"]["archive2"]["download_client_mode"]="disabled";
if (!bm_archive_save_settings($settings)) exit(10);

if (bm_archive_download_redirect_enabled() !== false) exit(11);
if (bm_archive_download_link_mode("archive1") !== "original") exit(12);
if (bm_archive_download_client_mode("archive1") !== "all") exit(13);
if (bm_archive_download_link_mode("archive2") !== "disabled") exit(14);
if (bm_archive_download_client_mode("archive2") !== "disabled") exit(15);

$origin="https://cdn.example.com/movie/Test.1080p.mkv";
if (bm_dl_wrap_url($origin,21600,"archive1",true) !== $origin) exit(16);

$stored=bm_archive_get_settings();
if (($stored["archives"]["archive1"]["download_link_mode"] ?? "") !== "redirect") exit(17);
if (($stored["archives"]["archive1"]["download_client_mode"] ?? "") !== "adm_copy") exit(18);

$stored["download_redirect_enabled"]=true;
if (!bm_archive_save_settings($stored)) exit(19);
if (!bm_archive_download_redirect_enabled()) exit(20);
if (bm_archive_download_link_mode("archive1") !== "redirect") exit(21);
if (bm_archive_download_client_mode("archive1") !== "adm_copy") exit(22);
$wrapped=bm_dl_wrap_url($origin,21600,"archive1",true);
if ($wrapped === "" || $wrapped === $origin || strpos($wrapped,"sig=") === false) exit(23);

echo "V7463_ADMIN_REDIRECT_MASTER_ROLLBACK_OK\n";
' "$tmp"
