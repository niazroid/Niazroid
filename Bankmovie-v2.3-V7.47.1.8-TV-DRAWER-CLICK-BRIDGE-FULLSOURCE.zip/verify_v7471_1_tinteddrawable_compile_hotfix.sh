#!/usr/bin/env bash
set -euo pipefail
MAIN="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
test -f "$MAIN"
grep -q '^import android.graphics.drawable.Drawable$' "$MAIN"
grep -q '^import androidx.core.content.ContextCompat$' "$MAIN"
grep -q 'private fun tintedDrawable(resId: Int, color: Int, sizePx: Int): Drawable?' "$MAIN"
grep -q 'ContextCompat.getDrawable(this, resId)?.mutate()?.apply' "$MAIN"
grep -q 'setBounds(0, 0, sizePx, sizePx)' "$MAIN"
# V7.47.1.3 preserves the helper while the Telegram/Bale button now intentionally uses
# a non-tinted drawable so its real brand colors remain visible.
count="$(grep -c 'tintedDrawable(' "$MAIN")"
if [[ "$count" -lt 6 ]]; then
  echo "Expected helper + retry/icon call sites, found $count tintedDrawable occurrences" >&2
  exit 1
fi
# Guard against copying the dp-based helper from DownloadsActivity/OfflineLibraryActivity;
# MainActivity already passes dp(...) so a second dp conversion would oversize icons.
if grep -A5 'private fun tintedDrawable(resId: Int, color: Int, sizePx: Int)' "$MAIN" | grep -q 'dp(sizePx)'; then
  echo 'MainActivity tintedDrawable must treat sizePx as already-converted pixels' >&2
  exit 1
fi
echo V7471_1_TINTED_DRAWABLE_COMPILE_HOTFIX_OK
