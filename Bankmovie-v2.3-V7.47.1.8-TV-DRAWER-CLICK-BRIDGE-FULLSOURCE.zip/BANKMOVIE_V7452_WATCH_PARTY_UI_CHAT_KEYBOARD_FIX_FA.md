# BANKMOVIE V7.45.2 — WATCH PARTY UI / CHAT KEYBOARD FIX

## What changed

This pass addresses the three UI issues reported after V7.45.1:

1. **Watch Party status chip moved to the top player bar**
   - Removed the centered floating room chip from the middle/lower video area.
   - The room status now lives inside the top metadata row next to quality / dub / subtitle chips.
   - This keeps the middle of the frame clean during playback.

2. **Replaced text emoji badges with proper project icons**
   - The Watch Party chip no longer uses text emoji مثل 👥 و ♛.
   - It now uses the project's existing vector resources:
     - `ic_party_members`
     - `ic_profile_vip`
   - Host state is shown with the VIP icon on the chip.

3. **Landscape chat keyboard no longer requests fullscreen extract UI**
   - Watch Party chat input now uses:
     - `IME_FLAG_NO_FULLSCREEN`
     - `IME_FLAG_NO_EXTRACT_UI`
     - `SOFT_INPUT_ADJUST_RESIZE`
   - This prevents the fullscreen keyboard/extract panel problem seen on MIUI / landscape player screens.
   - Input stays inline like game chat/composer behavior rather than taking over the full display.

## Files changed
- `app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt`

## Notes
- This pass is UI-focused and does not change the Ready/activity rebuild logic from V7.45.1.
- No server changes were required.
