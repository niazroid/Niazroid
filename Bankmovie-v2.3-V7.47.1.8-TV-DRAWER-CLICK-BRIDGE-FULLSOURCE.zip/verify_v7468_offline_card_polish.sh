#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
DOWNLOADS="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"
need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7468_MISSING: $2 in $1" >&2; exit 1; }; }
forbid() { ! grep -Fq -- "$2" "$1" || { echo "VERIFY_V7468_FORBIDDEN: $2 in $1" >&2; exit 1; }; }

# Offline gallery: title is not repeated as a per-series section heading.
need "$OFFLINE" '// Do not repeat the series/file title above every card. The title is shown once inside the card.'
forbid "$OFFLINE" 'sectionTitle(title, items.size)'
need "$OFFLINE" 'text = visibleTitle(item)'

# Metadata wraps; no horizontal swipe is needed to reveal kind/quality/episode chips.
need "$OFFLINE" 'val tags = GenreFlowLayout(this).apply {'
need "$DOWNLOADS" 'val tags = GenreFlowLayout(this@DownloadsActivity).apply {'
need "$OFFLINE" 'private fun resolveKindUi(raw: String): KindUi {'
need "$DOWNLOADS" 'private fun resolveDownloadKindUi(raw: String): DownloadKindUi {'
need "$OFFLINE" 'R.drawable.ic_dubbed_mic_green'
need "$OFFLINE" 'R.drawable.ic_player_cc'
need "$OFFLINE" 'R.drawable.ic_setup_subtitle'

# Play action uses the exact player play drawable. Cast/send action is removed.
need "$OFFLINE" 'wideActionButton("پخش آفلاین", R.drawable.ic_player_play'
need "$DOWNLOADS" 'completedActionButton("پخش آفلاین", R.drawable.ic_player_play'
forbid "$OFFLINE" 'wideActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device'
forbid "$DOWNLOADS" 'completedActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device'
need "$OFFLINE" 'weightSum = 3f'
need "$OFFLINE" 'val labels = arrayOf("پخش آفلاین", "اشتراک‌گذاری", "حذف")'
need "$DOWNLOADS" 'setItems(arrayOf("پخش آفلاین", "اشتراک‌گذاری", "حذف"))'

# Storage indicator stays visible even when the used/total ratio is tiny.
need "$OFFLINE" 'coerceIn(if (used > 0L) 24 else 0, 1000)'
need "$DOWNLOADS" 'coerceIn(if (used > 0L) 24 else 0, 1000)'
need "$OFFLINE" 'LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8) }'
need "$DOWNLOADS" 'LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8) }'

# Preserve the functional offline/download fixes and the compile hotfix.
bash "$ROOT/verify_v7465_offline_adm_location_playback.sh"
bash "$ROOT/verify_v7466_1_kotlin_compile_hotfix.sh"

echo VERIFY_V7468_OFFLINE_CARD_POLISH_OK
