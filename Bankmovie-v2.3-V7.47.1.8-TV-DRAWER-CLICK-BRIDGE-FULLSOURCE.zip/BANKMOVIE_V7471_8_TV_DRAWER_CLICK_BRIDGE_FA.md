# BANKMOVIE V7.47.1.8 — TV Drawer Click Bridge

این هات‌فیکس فقط رفتار کلیک منوی TV را اصلاح می‌کند و تغییرات V7.47.1.7 برای Sticky Focus و فوکس گالری آفلاین را نگه می‌دارد.

- وقتی Rail باز است، DPAD_CENTER / ENTER / NUMPAD_ENTER / BUTTON_A مستقیماً توسط Rail مدیریت می‌شود.
- اگر Android TV در لحظه کلیک `currentFocus` را موقتاً null کند، آخرین آیتم واقعی Rail استفاده می‌شود.
- روی آیتم انتخاب‌شده `performClick()` اجرا می‌شود؛ بنابراین Profile، Downloads، Box Office، Search، Favorites و بقیه مقصدها باز می‌شوند.
- Long-press OK برای Quick Menu دست‌نخورده باقی مانده است.
- گالری آفلاین و فوکس TV نسخه 1.7 بدون تغییر حفظ شده‌اند.
