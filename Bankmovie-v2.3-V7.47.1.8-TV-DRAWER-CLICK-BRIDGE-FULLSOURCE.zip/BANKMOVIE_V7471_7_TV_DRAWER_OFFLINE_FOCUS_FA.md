# BankMovie V7.47.1.7 — TV Drawer Sticky Focus + Offline Gallery Focus

این نسخه فقط روی دو باگ باقی‌مانده بعد از V7.47.1.6 تمرکز دارد.

## TV Side Drawer
- آخرین آیتم واقعی فوکوس‌شده در Rail نگهداری می‌شود.
- اگر هنگام expand شدن منو `currentFocus` برای چند میلی‌ثانیه null/stale شود، UP/DOWN از آخرین آیتم Rail ادامه پیدا می‌کند و به محتوای صفحه نمی‌پرد.
- auto-collapse روی focus-loss بین آیتم‌های خود منو حذف شده است.
- Rail فقط هنگام خروج به محتوا یا انتخاب مقصد بسته می‌شود.

## Offline Gallery on TV
- فوکس اولیه و زنجیره UP/DOWN حفظ شده است.
- فوکس TV حالا حاشیه Accent واضح، Scale و Elevation دارد.
- هنگام فوکس، آیتم داخل ScrollView به viewport آورده می‌شود.
- این رفتار روی Back، کارت Storage، تب‌ها، منوی More و دکمه‌های کارت‌های آفلاین اعمال می‌شود.

## بخش‌های دست‌نخورده
- تنظیمات Downloader نسخه 1.6 بدون تغییر باقی مانده.
- آیکون Trailer نسخه 1.6 حفظ شده.
- سایر اصلاحات TV/Player بدون تغییر باقی مانده‌اند.
