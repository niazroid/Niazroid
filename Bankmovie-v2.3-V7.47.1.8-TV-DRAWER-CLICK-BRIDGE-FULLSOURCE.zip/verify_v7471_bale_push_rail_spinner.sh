#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
main="$root/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
spinner="$root/app/src/main/java/ir/bankmoviee/app/InlineSpinnerButton.kt"
admin="$root/server-required/bm_admin.php"
config="$root/server-required/app_config.php"

need(){ grep -Fq "$2" "$1" || { echo "VERIFY_FAIL missing: $2 in $1" >&2; exit 1; }; }
need "$main" 'private fun showRailFailure('
need "$main" 'R.drawable.ic_retry_cycle'
need "$main" 'R.drawable.ic_bale'
need "$main" 'remoteVipPurchaseProvider'
need "$main" 'InlineSpinnerButton(this)'
need "$spinner" 'for (i in 0 until 10)'
need "$spinner" 'i * 36.0'
need "$admin" 'id="push-notification"'
need "$admin" "send_push_notification"
need "$admin" 'name="bale_enabled"'
need "$admin" 'name="vip_purchase_provider"'
need "$config" "'bale_enabled'=>false"

if grep -Fq 'row.addView(railErrorCard(' "$main"; then
  echo 'VERIFY_FAIL rail error card is still nested inside a horizontal row' >&2
  exit 1
fi

test -s "$root/app/src/main/res/drawable/ic_retry_cycle.xml"
test -s "$root/app/src/main/res/drawable/ic_bale.xml"
php -l "$admin" >/dev/null
php -l "$config" >/dev/null
python3 - "$root/app/src/main/res/drawable/ic_retry_cycle.xml" "$root/app/src/main/res/drawable/ic_bale.xml" <<'PY'
import sys, xml.etree.ElementTree as ET
for p in sys.argv[1:]: ET.parse(p)
print('V7471_XML_OK')
PY
echo 'VERIFY_V7471_BALE_PUSH_RAIL_SPINNER_OK'
