# BANKMOVIE V7.47.1.6 — TV menu + downloader settings + offline gallery focus

## انجام‌شده

- رفع باگ منوی TV: وقتی روی «منو» بودی و با ریموت می‌خواستی پایین بروی، در بعضی تلویزیون‌ها سایدمنو وسط جابه‌جایی بسته می‌شد. حالا برای جابه‌جایی‌های داخلی منو guard گذاشته شده و ریل تا پایان انتقال فوکس باز می‌ماند.
- به tile پروفایل داخل سایدمنوی TV فوکس‌هندلر اضافه شد تا مثل بقیه آیتم‌های منو رفتار کند و موقع بالا/پایین رفتن منو پایدار بماند.
- فوکس تنظیمات دانلود بهتر شد: برای Close، حالت دانلود، اسلایدر کانکشن، سوییچ نوتیفیکیشن، زمان‌بندی، مسیر ذخیره‌سازی و دکمه ذخیره، مسیر عمودی TV تعریف شد.
- گالری آفلاین برای TV فوکس‌پذیر شد: فوکس اولیه، زنجیره بالا/پایین و بازسازی فوکس بعد از refresh لیست اضافه شد.
- آیکون Trailer با SVG جدیدی که دادی جایگزین شد.

## فایل‌های اصلی تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt`
- `app/src/main/res/drawable/ic_trailer.xml`
