#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
marker='BANKMOVIE_BUILD_SOURCE_2_3.txt'

# The approved V7.44.6 neon Watch Party/player UI must remain intact.
bash verify_v7446_watch_party_neon_ui.sh

grep -Fq 'sourceMainUpdateThirtyFifthHotfixTag=BANKMOVIE-2.3-V7449-20260914' "$marker"

# Hard UI gate only.
grep -Fq 'if (!partyActive || partyRoomCode.isBlank() || partyReadyConfirmed) return' "$player"
grep -Fq 'if (partyLobbyDialog?.isShowing == true) return' "$player"
grep -Fq 'AlertDialog.Builder(this).setView(shell).setCancelable(false).create()' "$player"
grep -Fq 'dialog.setCanceledOnTouchOutside(false)' "$player"
grep -Fq 'برای ورود به اتاق روی «شروع تماشا / آماده‌ام» بزنید' "$player"

# The known-good V7.44.6 Ready -> player transition must still be present.
grep -Fq 'partyPlaybackStarted = true' "$player"
grep -Fq 'requestedResumePosition = 0L' "$player"
grep -Fq 'pauseAfterLifecycleRestore = !partyIsHost' "$player"
grep -Fq 'launchPlayerSafely(videoUrl)' "$player"
grep -Fq 'handler.postDelayed({' "$player"
grep -Fq 'pollWatchParty()' "$player"

# Pre-ready Share must never arm a hidden player rebuild.
grep -Fq 'lifecycleRestorePending = videoUrl.isNotBlank() && current != null' "$player"

# Explicitly reject the unstable V7.44.8 state machine.
! grep -Fq 'partyReadyLaunchInFlight' "$player"
! grep -Fq 'partySharedSourceUrl' "$player"
! grep -Fq 'STATE_PARTY_READY_CONFIRMED' "$player"
! grep -Fq 'STATE_PARTY_PLAYBACK_STARTED' "$player"

# Syntax-shape sanity.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
stack=[]; i=0; state='code'; n=len(s)
while i<n:
    c=s[i]; nx=s[i+1] if i+1<n else ''
    if state=='code':
        if c=='/' and nx=='/': state='line'; i+=2; continue
        if c=='/' and nx=='*': state='block'; i+=2; continue
        if s[i:i+3]=='"""': state='triple'; i+=3; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append(c)
        elif c in ')]}':
            pairs={')':'(',']':'[','}':'{'}
            assert stack and stack[-1]==pairs[c], (c,i,stack[-1:] if stack else [])
            stack.pop()
        i+=1; continue
    if state=='line':
        if c=='\n': state='code'
        i+=1; continue
    if state=='block':
        if c=='*' and nx=='/': state='code'; i+=2; continue
        i+=1; continue
    if state=='string':
        if c=='\\': i+=2; continue
        if c=='"': state='code'
        i+=1; continue
    if state=='char':
        if c=='\\': i+=2; continue
        if c=="'": state='code'
        i+=1; continue
    if state=='triple':
        if s[i:i+3]=='"""': state='code'; i+=3; continue
        i+=1
assert state=='code' and not stack, (state, stack[-10:])
print('V7449_KOTLIN_SHAPE_OK')
PY

echo V7449_WATCH_PARTY_READY_STABLE_ROLLBACK_VERIFY_OK
