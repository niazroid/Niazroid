#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
POLICY='server-required/includes/app_archive_policy.php'
CONFIG='server-required/app_config.php'
ADMIN='server-required/bm_admin.php'

grep -Fq '"top_250_movies", "imdb_movies", "best_movies" -> "top_movies"' "$MAIN"
grep -Fq '"top_250_series", "imdb_series", "best_series" -> "top_series"' "$MAIN"
grep -Fq 'if (safe == 1 && (key == "top_movies" || key == "top_series")) return true' "$MAIN"
grep -Fq 'val listStateHost = FrameLayout(this).apply { visibility = View.GONE }' "$MAIN"
grep -Fq 'if (p == 1 && arr.length() == 0)' "$MAIN"
grep -Fq "in_array(\$section, ['top_movies','top_series'], true)" "$POLICY"
grep -Fq "'top_movies'=>'۲۵۰ فیلم برتر IMDb'" "$ADMIN"
grep -Fq "'top_series'=>'۲۵۰ سریال برتر IMDb'" "$ADMIN"
grep -Fq "'top_movies','top_series'" "$CONFIG"
php -l "$POLICY" >/dev/null
php -l "$CONFIG" >/dev/null
php -l "$ADMIN" >/dev/null
echo V7455_IMDB_TOP250_BRIDGE_VERIFY_OK
