#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
draw='app/src/main/res/drawable'

# Preserve archive/section behavior through V7.43.1, then assert the
# V7.44.1 unified VIP action-gate invariants without inheriting its old icon checks.
bash verify_v7431_section_hard_hide.sh
grep -Fq 'val playActionable = vipStreamGate || allPlayersGate || directPlayable' "$main"
grep -Fq 'vipStreamGate -> showArchiveVipGate(item, "stream")' "$main"
grep -Fq 'val actionable = playable || watchPartyGate || streamGate' "$main"
grep -Fq 'if (actionable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }' "$main"
grep -Fq 'val protectedMetadataOnly = archiveVipGateRequired(item, "stream") ||' "$main"
if grep -Fq 'bypassArchivePlaybackGates = true' "$main"; then
  echo 'V7443_ERROR: ordinary playback still bypasses VIP gates' >&2
  exit 1
fi

grep -Fq 'sourceMainUpdateThirtyFirstHotfixTag=BANKMOVIE-2.3-V7443-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Exact player icons restored from the pre-V7.44 baseline.
grep -Fq 'setImageResource(R.drawable.ic_player_cc)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_audio)' "$player"
if grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"; then
  echo 'V7443_ERROR: language globe must not be used inside PlayerActivity' >&2
  exit 1
fi
grep -Fq 'R.drawable.ic_repo_language) { showLanguageThemeDialog() }' "$main"

# Reversed gesture direction and direct finger tracking.
grep -Fq 'val deltaRatio = ((e.y - touchStartY) / root.height) * 1.45f' "$player"
grep -Fq 'val deltaRatio = ((e.y - touchStartY) / root.height) * 1.55f' "$player"
grep -Fq 'private fun showVolumeGestureHud(ratioValue: Float)' "$player"
grep -Fq 'volumeGestureLevel.scaleY = ratio' "$player"
grep -Fq 'brightnessGestureLevel.scaleY = ratio' "$player"
if grep -Fq 'volumeGestureLevel.animate().scaleY' "$player"; then
  echo 'V7443_ERROR: volume level still trails the finger with a scale animation' >&2
  exit 1
fi
if grep -Fq 'brightnessGestureLevel.animate().scaleY' "$player"; then
  echo 'V7443_ERROR: brightness level still trails the finger with a scale animation' >&2
  exit 1
fi

# Compact new gesture glyphs.
grep -Fq 'setImageResource(R.drawable.ic_player_volume_gesture)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_brightness_gesture)' "$player"
test -s "$draw/ic_player_volume_gesture.xml"
test -s "$draw/ic_player_brightness_gesture.xml"
test -s "$draw/ic_player_cc.xml"
test -s "$draw/ic_player_audio.xml"

python3 - <<'PY'
import xml.etree.ElementTree as ET
for path in [
    'app/src/main/res/drawable/ic_player_volume_gesture.xml',
    'app/src/main/res/drawable/ic_player_brightness_gesture.xml',
    'app/src/main/res/drawable/ic_player_cc.xml',
    'app/src/main/res/drawable/ic_player_audio.xml',
]:
    ET.parse(path)
print('V7443_VECTOR_XML_OK')
PY

echo V7443_PLAYER_CC_GESTURE_VERIFY_OK
