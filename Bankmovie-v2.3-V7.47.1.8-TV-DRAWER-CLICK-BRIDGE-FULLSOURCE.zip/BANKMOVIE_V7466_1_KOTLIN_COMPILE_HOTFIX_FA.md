# BankMovie V7.46.6.1 — Kotlin compile hotfix

این هات‌فیکس فقط خطای کامپایل V7.46.6 در `DownloadsActivity.kt` را اصلاح می‌کند و هیچ تغییر جدیدی در رفتار سرور یا طراحی ایجاد نمی‌کند.

علت خطا در `emptyState()` این بود که متغیر محلی `val text` وجود داشت و داخل `TextView.apply { ... }` عبارت بدون qualifier یعنی `text = "گالری آفلاین"` به همان متغیر محلی resolve می‌شد؛ بنابراین Kotlin خطای `val cannot be reassigned` می‌داد.

اصلاح:

```kotlin
this.text = "گالری آفلاین"
```

تمام تغییرات ظاهری V7.46.6، نام «گالری آفلاین»، SVG گالری و اصلاحات V7.46.5 بدون تغییر حفظ شده‌اند.
