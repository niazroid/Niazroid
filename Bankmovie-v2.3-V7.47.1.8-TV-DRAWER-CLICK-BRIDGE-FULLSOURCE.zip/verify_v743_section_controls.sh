#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
admin='server-required/bm_admin.php'
appcfg='server-required/app_config.php'
appapi='server-required/app_api.php'
api4='server-required/api4.php'
policy='server-required/includes/app_archive_policy.php'

# V7.43 section-control contract.
grep -Fq 'function bm_app_home_section_catalog(): array' "$admin"
grep -Fq "'turkish'=>'سریال‌های ترکی'" "$admin"
grep -Fq "'turkish_series'=>'سریال‌های ترکی'" "$admin"
grep -Fq "'home_section_policy'=>\$homeSectionPolicy" "$admin"
grep -Fq 'id="section-controls"' "$admin"
grep -Fq 'home_archive3_sections' "$admin"
grep -Fq 'home_archive4_sections' "$admin"
grep -Fq "'home_section_policy' => []" "$appcfg"
grep -Fq "'archive1'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections']" "$appcfg"
grep -Fq "\$default['home_section_policy'] = \$publicSectionPolicy;" "$appcfg"
grep -Fq 'bm_app_archive_section_user_can_access' "$appapi"
grep -Fq 'bm_app_archive_section_state_payload' "$appapi"
grep -Fq "elseif (\$action === 'collections' || \$action === 'collection') \$managedSection = 'collections';" "$appapi"
grep -Fq 'function bm_app_archive_section_key' "$policy"
grep -Fq "'turkey'=>'turkish','turkish_series'=>'turkish'" "$policy"
grep -Fq "bm_app_archive_section_user_can_access('archive4'" "$api4"

grep -Fq 'private fun homeSectionPolicyKey(archive: Int, section: String): String' "$main"
grep -Fq 'val visibleTabs = tabs.filter { homeSectionEnabled(it.second, it.third) }' "$main"
grep -Fq 'hasVisibilityPolicy && remoteHomeSectionsConfigured[selectedArchive] == true' "$main"
grep -Fq 'Toast.makeText(this, t("این بخش از BM Admin غیرفعال شده است"' "$main"
grep -Fq 'action=collections&archive=$selectedArchive' "$main"
grep -Fq '"turkish" -> addRail(page, "سریال‌های ترکی", 1, "turkish", false)' "$main"
grep -Fq 'sourceMainUpdateTwentySixthHotfixTag=BANKMOVIE-2.3-V743-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Preserve the important V7.42 Android UX/security regressions.  The older
# verifier chain intentionally pins the pre-assets15 server-required copy, so
# V7.43 checks these Android invariants directly and lints the rebased server.
grep -Fq 'page.gravity = Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$main"
grep -Fq 'private val playableLinksCache = java.util.WeakHashMap' "$main"
grep -Fq 'Open the sheet first, then build the heavier quality/episode views' "$main"
grep -Fq 'sourceMainUpdateTwentyFifthHotfixTag=BANKMOVIE-2.3-V742-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

test -s app/src/main/res/drawable/ic_status_update_arrow.xml
php -l "$admin" >/dev/null
php -l "$appcfg" >/dev/null
php -l "$appapi" >/dev/null
php -l "$api4" >/dev/null
php -l "$policy" >/dev/null

echo V743_SECTION_CONTROLS_VERIFY_OK
