#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
source_marker='BANKMOVIE_BUILD_SOURCE_2_3.txt'
report='BANKMOVIE_V7451_WATCH_PARTY_READY_FRESH_ACTIVITY_FIX_FA.md'
test -s "$player"
test -s "$source_marker"
test -s "$report"
grep -Fq 'sourceMainUpdateThirtySixthHotfixTag=BANKMOVIE-2.3-V7451-20260914' "$source_marker"
grep -Fq 'private const val EXTRA_WATCH_PARTY_READY_ENTRY = "watch_party_ready_entry"' "$player"
grep -Fq 'partyReadyRecreateRequested = true' "$player"
grep -Fq 'intent.putExtra(EXTRA_WATCH_PARTY_READY_ENTRY, true)' "$player"
grep -Fq 'recreate()' "$player"
grep -Fq 'if (partyActive && partyReadyConfirmed)' "$player"
grep -Fq 'partyPlayerStable = true' "$player"
grep -Fq 'handler.postDelayed(partyPollRunnable, 700L)' "$player"
grep -Fq '!partyReadyConfirmed || partyPlayerStable' "$player"
grep -Fq '!partyReadyConfirmed || !partyPlayerStable || player == null' "$player"
! grep -Fq 'private var partyPrewarming = true' "$player"
echo V7451_WATCH_PARTY_READY_ACTIVITY_VERIFY_OK
