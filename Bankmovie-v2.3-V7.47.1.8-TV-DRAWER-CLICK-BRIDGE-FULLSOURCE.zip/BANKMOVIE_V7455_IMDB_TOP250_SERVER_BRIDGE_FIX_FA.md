# BankMovie V7.45.5 — اتصال مجدد IMDb Top 250 سایت به اپ

## مشکل
صفحه‌های «۲۵۰ فیلم برتر IMDb» و «۲۵۰ سریال برتر IMDb» در سایت سالم بودند، اما در اپ فقط عنوان و صفحه سیاه دیده می‌شد.

علت اصلی این بود که Top 250 در اپ از `app_api.php?action=section&archive=1` خوانده می‌شود و policy اندروید، نبودن `top_movies` / `top_series` در لیست Home آرشیو ۱ را به‌اشتباه به معنی Disabled می‌گرفت. این دو صفحه در واقع Catalogue هستند، نه Home rail.

## فیکس سمت سرور
- `includes/app_archive_policy.php`
  - aliasهای Top 250 نرمال شدند.
  - برای Remote Configهای قدیمی، `top_movies` و `top_series` تا وقتی policy صریح ندارند Public/Enabled هستند.
  - اگر BM Admin policy صریح Disabled/VIP/Member/Admin ثبت کند، همان policy همچنان اولویت دارد.
- `app_config.php`
  - `top_movies` و `top_series` وارد catalogue سیاست بخش‌های Archive 1 شدند.
  - برای کانفیگ‌های قدیمی، این دو policy به‌صورت migration-safe فعال منتشر می‌شوند.
- `bm_admin.php`
  - کنترل مستقل «۲۵۰ فیلم برتر IMDb» و «۲۵۰ سریال برتر IMDb» اضافه شد.
  - این دو به Home rail list اضافه نشده‌اند؛ فقط به‌عنوان Catalogue قابل کنترل‌اند.

## فیکس سمت Android
- Top 250 حالا کلید policy مستقل `top_movies` / `top_series` دارد.
- Remote Config قدیمی که این دو کلید را ندارد دیگر باعث Hide شدن Catalogue نمی‌شود.
- اگر API با HTTP 200 ولی `items=[]` برگرداند، Skeleton پاک شده و به‌جای صفحه سیاه Empty/Disabled/Locked state نمایش داده می‌شود.

## نکته نصب
برای اینکه نسخه‌های قدیمی اپ هم دوباره Top 250 را بگیرند، حداقل فایل زیر روی هاست باید جایگزین شود:

`includes/app_archive_policy.php`

برای اینکه کنترل Top 250 در BM Admin هم اضافه شود، این دو فایل را هم آپلود کنید:

- `app_config.php`
- `bm_admin.php`

فایل `bankmovie_remote_config.json` داخل Patch نیست و نباید overwrite شود.
