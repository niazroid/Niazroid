#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
admin='app/src/main/res/drawable/ic_admin_verified.xml'
vip='app/src/main/res/drawable/ic_vip_verified_green.xml'

grep -Fq 'V7.45.4 — Bubble width is derived from the drawer width' "$player"
grep -Fq 'R.drawable.ic_vip_verified_green' "$player"
grep -Fq 'R.drawable.ic_admin_verified' "$player"
grep -Fq 'availableBubbleWidth' "$player"
grep -Fq 'minimumWidth = minBubbleWidth' "$player"
grep -Fq 'R.drawable.ic_vip_verified_green' "$main"
grep -Fq 'Verified administrator' "$main"
grep -Fq 'Verified VIP member' "$main"
grep -Fq 'isAdminUser' "$main"
grep -Fq 'isVipUser' "$main"
grep -Fq '#FF1D9BF0' "$admin"
grep -Fq '#FF8BC34A' "$vip"
python - <<'PY'
import xml.etree.ElementTree as ET
for f in [
    'app/src/main/res/drawable/ic_admin_verified.xml',
    'app/src/main/res/drawable/ic_vip_verified_green.xml',
]:
    ET.parse(f)
print('XML_OK')
PY
echo VERIFY_V7454_OK
