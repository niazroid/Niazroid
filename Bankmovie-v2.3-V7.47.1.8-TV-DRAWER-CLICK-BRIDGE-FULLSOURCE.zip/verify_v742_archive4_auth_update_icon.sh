#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
api4='server-required/api4.php'
admin='server-required/bm_admin.php'
appcfg='server-required/app_config.php'
policy='server-required/includes/app_archive_policy.php'

# Archive 4 is exposed in exactly the same BM Admin policy loop as archives 1..3.
grep -Fq "[1=>'آرشیو ۱',2=>'آرشیو ۲',3=>'آرشیو ۳',4=>'آرشیو ۴']" "$admin"
grep -Fq 'foreach ([1,2,3,4] as $archiveNumber)' "$admin"
grep -Fq "'archive4'=>['enabled'=>" "$admin"
grep -Fq "4=>'archive4'" "$appcfg"
grep -Fq "^archive([1-4])$" "$policy"

# api4 must load the managed download layer directly, wrap first and gate last.
grep -Fq "require_once __DIR__ . '/includes/download_redirect.php';" "$api4"
python3 - <<'PY'
from pathlib import Path
s=Path('server-required/api4.php').read_text()
a=s.index("bm_dl_wrap_payload($payload, false, 'archive4', $appClient)")
b=s.index("bm_app_archive_apply_payload_policy('archive4'", a)
assert a < b, 'Archive4 download wrapping must happen before app policy stripping'
PY

# Auth is centered a bit lower and the thin visual handle has a larger touch target.
grep -Fq 'setPadding(dp(18), dp(18), dp(18), dp(18))' "$auth"
grep -Fq 'LinearLayout.LayoutParams(dp(86), dp(29))' "$auth"
grep -Fq 'topMargin = dp(if (isTvLike()) 30 else 18)' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"

# Same exact update drawable is used in auth challenge and detail latest-status pill.
count=$(grep -c 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth" "$main" | awk -F: '{s+=$2} END{print s+0}')
[[ "$count" -ge 2 ]]
grep -Fq 'Content update' "$main"

grep -Fq 'sourceMainUpdateTwentyFifthHotfixTag=BANKMOVIE-2.3-V742-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Full previous behavior chain should still pass with the intentional V7.42 override.
bash verify_v7411_exact_security_refresh_icon.sh

echo V742_ARCHIVE4_AUTH_UPDATE_ICON_VERIFY_OK
