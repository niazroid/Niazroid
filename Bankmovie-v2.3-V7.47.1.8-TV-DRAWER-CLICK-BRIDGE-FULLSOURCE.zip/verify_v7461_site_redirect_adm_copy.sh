#!/usr/bin/env bash
set -euo pipefail

ARCHIVE='server-required/includes/archive_control.php'
REDIRECT='server-required/includes/download_redirect.php'
POLICY='server-required/includes/app_archive_policy.php'
ADMIN='server-required/bm_admin.php'
CONFIG='server-required/app_config.php'
GATEWAY='server-required/download_gateway.php'
ROUTE='server-required/download-route.htaccess.sample'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

for f in "$ARCHIVE" "$REDIRECT" "$POLICY" "$ADMIN" "$CONFIG" "$GATEWAY" "$ROUTE" "$MAIN"; do
  [[ -s "$f" ]] || { echo "Missing $f" >&2; exit 1; }
done

# Android delivery policy remains ADM + protected clipboard only.
grep -Fq "'download_client_mode' => 'adm_copy'" "$ARCHIVE"
grep -Fq "['adm_copy','all','disabled']" "$ARCHIVE"
grep -Fq 'download_client_mode' "$POLICY"
grep -Fq 'archive<?= (int)$bmArchiveNumber ?>_download_client_mode' "$ADMIN"
grep -Fq 'فقط ADM + کپی لینک محافظت‌شده' "$ADMIN"
grep -Fq 'private fun openAdmOnly(url: String)' "$MAIN"
grep -Fq 'Only the BankMovie redirect URL is copied' "$MAIN"

# Same website redirect system: one shared key/gateway and panel-managed bases.
grep -Fq "bm_security_private_path('download_redirect.key')" "$REDIRECT"
! grep -Fq 'download_redirect.archive1.key' "$REDIRECT"
! grep -Fq 'token_version' "$REDIRECT"
grep -Fq 'bm_archive_pick_download_base_url($archiveId, $seed)' "$REDIRECT"
grep -Fq 'archive<?= (int)$bmArchiveNumber ?>_download_base_urls' "$ADMIN"
grep -Fq 'app_api و خود سایت از همین تنظیم مشترک لینک امضاشده را می‌سازند' "$ADMIN"
grep -Fq "require_once __DIR__ . '/includes/download_redirect.php';" "$GATEWAY"
[[ ! -d server-required/download-edges ]]
[[ ! -e server-required/tools/export_download_edge_key.php ]]

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=s.index('private fun openAdmOnly(url: String)')
b=s.index('\n    private fun ', a+10)
block=s[a:b]
assert 'setPackage("com.dv.adm")' in block
assert 'openExternal(' not in block
assert 'Intent.createChooser' not in block
assert 'setPrimaryClip' in block
PY

for f in "$ARCHIVE" "$REDIRECT" "$POLICY" "$ADMIN" "$CONFIG" "$GATEWAY"; do
  php -l "$f" >/dev/null
done

TMP_PRIVATE="$(mktemp -d)"
trap 'rm -rf "$TMP_PRIVATE"' EXIT
BANKMOVIE_PRIVATE_DIR="$TMP_PRIVATE" php -d display_errors=1 <<'PHP'
<?php
require 'server-required/includes/archive_control.php';
require 'server-required/includes/download_redirect.php';

$settings = bm_archive_control_defaults();
for ($i=1; $i<=4; $i++) {
    $aid = 'archive'.$i;
    $settings['archives'][$aid]['download_link_mode'] = 'redirect';
    $settings['archives'][$aid]['download_client_mode'] = 'adm_copy';
    $settings['archives'][$aid]['download_base_urls'] = ['https://site-dl'.$i.'.example.com'];
}
if (!bm_archive_save_settings($settings)) exit(20);

for ($i=1; $i<=4; $i++) {
    $aid = 'archive'.$i;
    $raw = 'https://origin'.$i.'.example.net/media/Test.S01E0'.$i.'.1080p.mkv';
    $wrapped = bm_dl_wrap_url($raw, 21600, $aid, true);
    if (!str_starts_with($wrapped, 'https://site-dl'.$i.'.example.com/')) exit(30+$i);
    parse_str((string)parse_url($wrapped, PHP_URL_QUERY), $q);
    $decoded = bm_dl_decode_token((string)($q['sig'] ?? ''));
    if (!is_array($decoded) || ($decoded['url'] ?? '') !== $raw || ($decoded['archive_id'] ?? '') !== $aid) exit(40+$i);
}

$keyPath = rtrim(getenv('BANKMOVIE_PRIVATE_DIR'), '/').'/download_redirect.key';
if (!is_file($keyPath) || trim((string)file_get_contents($keyPath)) === '') exit(60);
foreach (glob(rtrim(getenv('BANKMOVIE_PRIVATE_DIR'), '/').'/download_redirect.archive*.key') ?: [] as $bad) exit(61);

// Admin/client privacy invariant still forces protected redirect in adm_copy mode.
$settings = bm_archive_get_settings();
$settings['archives']['archive1']['download_link_mode'] = 'original';
$settings['archives']['archive1']['download_client_mode'] = 'adm_copy';
if (!bm_archive_save_settings($settings)) exit(70);
$normalized = bm_archive_get_settings();
if (($normalized['archives']['archive1']['download_link_mode'] ?? '') !== 'redirect') exit(71);

echo "V7461_SITE_REDIRECT_TEST_OK\n";
PHP

echo VERIFY_V7461_SITE_REDIRECT_ADM_COPY_OK
