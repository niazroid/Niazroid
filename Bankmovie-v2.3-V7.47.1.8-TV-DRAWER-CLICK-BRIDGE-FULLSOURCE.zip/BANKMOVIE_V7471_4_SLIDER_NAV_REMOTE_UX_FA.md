# BankMovie 2.3 — V7.47.1.4

این هات‌فیکس روی V7.47.1.3 ساخته شده و اصلاحات قبلی را حفظ می‌کند.

- اسلایدر Home پس از رسیدن `app_home_feed` در همان ورود اول با ترتیب authoritative بازسازی می‌شود و از آیتم صفر شروع می‌کند.
- انتخاب مدل ناوبری موبایل به Quick Setup اضافه شده و همان `KEY_MOBILE_NAV_STYLE` تنظیمات اصلی را ذخیره می‌کند.
- Remote Config / secondary controller به `bankmoviez.top` منتقل شده است. دامنه محتوای `bankmovie.top` و application id `ir.bankmoviee.app` تغییر نکرده‌اند.
- انیمیشن Back نرم‌تر و جهت‌دار شده است.
- گزینه Copy Link برای فیلم حذف شده و fallback کلیپ‌بورد ADM نیز برای فیلم غیرفعال است؛ سریال همچنان قابلیت کپی دارد.
- Bulk Copy سریال تمام فصل‌ها را جمع می‌کند و انتخاب «همه فصل‌ها / فصل N» دارد؛ dedupe روی URL واقعی انجام می‌شود.
- Bottom sheetها دیگر در نیمه راه متوقف نمی‌شوند؛ drag رو به پایین به dismiss کامل ختم می‌شود.
- Workflow نسخه V7.47.1.4 verifier جدید را اجرا می‌کند و همان کلید امضای پایدار را حفظ می‌کند.

## CI verifier compatibility hotfix

- `verify_v7464_internal_offline_home500_legacy_safe.sh` و `verify_v7465_offline_adm_location_playback.sh` برای امضای جدید `openAdmOnly(url, allowClipboardFallback)` backward-compatible شدند.
- خطای `VERIFY_V7465_BLOCK_MISSING` ناشی از regex قدیمی verifier بود، نه خرابی ADM.
- زنجیره verify واقعی workflow تا `WORKFLOW_VERIFY_V7471_4_OK` به صورت مرحله‌ای بررسی شد؛ verifierهای V7464/V7465 و تمام verifierهای V7471.0 تا V7471.4 پاس شدند.
