#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
DOWNLOADS="$ROOT/app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt"
DRAW="$ROOT/app/src/main/res/drawable"

need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7466_MISSING: $2 in $1" >&2; exit 1; }; }
forbid() { ! grep -Fq -- "$2" "$1" || { echo "VERIFY_V7466_FORBIDDEN: $2 in $1" >&2; exit 1; }; }

# Product naming: user-facing offline destination is now Gallery everywhere.
need "$OFFLINE" 'text = "گالری آفلاین"'
need "$MAIN" 't("گالری آفلاین", "Offline gallery")'
forbid "$MAIN" 'کتابخانه آفلاین'
forbid "$OFFLINE" 'کتابخانه آفلاین'
forbid "$DOWNLOADS" 'کتابخانه آفلاین'

# Exact user-provided gallery SVG geometry must drive offline + download/nav icons.
for icon in ic_offline_gallery.xml ic_download.xml ic_nav_collection.xml ic_tv_nav_download_preview.xml ic_bm_library.xml ic_bm_download.xml; do
  need "$DRAW/$icon" 'M22,12C22,16.714 22,19.0711 20.5355,20.5355'
  need "$DRAW/$icon" 'M2,12.5001L3.75159,10.9675'
  need "$DRAW/$icon" 'M17,11V2M17,11L20,8M17,11L14,8'
done

# Supplied SVG family is represented as Android vectors and used by redesigned screens.
for icon in \
  ic_bm_settings.xml ic_bm_series.xml ic_bm_send_to_device.xml ic_bm_play_offline.xml \
  ic_bm_more.xml ic_bm_file.xml ic_bm_headphones.xml ic_bm_film.xml ic_bm_check.xml \
  ic_bm_back.xml ic_bm_empty_download.xml ic_bm_share.xml ic_bm_storage.xml ic_bm_trash.xml; do
  test -s "$DRAW/$icon" || { echo "VERIFY_V7466_ICON_MISSING: $icon" >&2; exit 1; }
done

# Offline gallery visual hierarchy.
need "$OFFLINE" 'buildStorageCard()'
need "$OFFLINE" 'text = "فضای مصرفی"'
need "$OFFLINE" 'filterTab("همه", FILTER_ALL, R.drawable.ic_offline_gallery)'
need "$OFFLINE" 'filterTab("فیلم‌ها", FILTER_MOVIES, R.drawable.ic_bm_film)'
need "$OFFLINE" 'filterTab("سریال‌ها", FILTER_SERIES, R.drawable.ic_bm_series)'
need "$OFFLINE" 'wideActionButton("پخش آفلاین", R.drawable.ic_bm_play_offline'
need "$OFFLINE" 'wideActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device'
need "$OFFLINE" 'wideActionButton("اشتراک‌گذاری", R.drawable.ic_bm_share'
need "$OFFLINE" 'wideActionButton("حذف", R.drawable.ic_bm_trash'

# Downloader visual hierarchy and new media filters.
need "$DOWNLOADS" 'downloadStorageCard()'
need "$DOWNLOADS" 'filterButton("فیلم‌ها", FILTER_MOVIES, R.drawable.ic_bm_film)'
need "$DOWNLOADS" 'filterButton("سریال‌ها", FILTER_SERIES, R.drawable.ic_bm_series)'
need "$DOWNLOADS" 'filterButton("کامل شده", FILTER_COMPLETED, R.drawable.ic_bm_check)'
need "$DOWNLOADS" 'completedActionButton("پخش آفلاین", R.drawable.ic_bm_play_offline'
need "$DOWNLOADS" 'completedActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device'
need "$DOWNLOADS" 'completedActionButton("اشتراک‌گذاری", R.drawable.ic_bm_share'
need "$DOWNLOADS" 'completedActionButton("حذف", R.drawable.ic_bm_trash'
need "$DOWNLOADS" 'setImageResource(R.drawable.ic_bm_more)'
need "$DOWNLOADS" 'setImageResource(R.drawable.ic_bm_empty_download)'

# Preserve V7.46.5 behavior fixes and server/homepage safety chain.
bash "$ROOT/verify_v7465_offline_adm_location_playback.sh"

echo VERIFY_V7466_OFFLINE_GALLERY_DOWNLOADER_VISUAL_REFRESH_OK
