# BankMovie V7.45.6 — Download Redirect / Original / Disabled per Archive

این نسخه مسیر دانلود اپ را به تنظیم مشترک سایت و BM Admin متصل می‌کند، بدون اینکه مسیر پخش تغییر کند.

## کنترل جدید BM Admin
برای هر آرشیو ۱ تا ۴ دو تنظیم اضافه شده است:

- **حالت لینک دانلود خروجی اپ**
  - `redirect`: لینک دانلود امضاشده و مخفی BankMovie
  - `original`: لینک اصلی منبع
  - `disabled`: بدون لینک دانلود
- **دامنه‌های ریدایرکت دانلود همان آرشیو**
  - یک یا چند دامنه HTTPS، هر دامنه در یک خط
  - انتخاب دامنه توسط زیرساخت مشترک سایت انجام می‌شود و Android چیزی را Hardcode نمی‌کند.

تنظیمات در `archive_api_settings.json` مشترک ذخیره می‌شوند، بنابراین `app_api.php` و `api4.php` همان سیاست سایت را برای `download_url` اجرا می‌کنند. نصب‌های قبلی به‌صورت مهاجرتی روی `redirect` باقی می‌مانند تا رفتار جاری عوض نشود.

## جداسازی پخش از دانلود

- `stream_url` / `url` برای Player باقی می‌مانند.
- `download_url` بر اساس BM Admin می‌تواند Redirect، Original یا خالی باشد.
- در Android جدید، `downloadBoxPlayerUrl()` دیگر هرگز به `download_url` fallback نمی‌کند؛ پس تغییر حالت دانلود نباید وارد Player داخلی، پلیر خارجی یا Watch Party شود.

## سازگاری نسخه‌های قبلی

نسخه‌های قبلی که `download_url` را از `app_api.php` می‌خوانند، بعد از تعویض فایل‌های سرور بدون نصب APK جدید حالت تازه را دریافت می‌کنند. حالت دامنه هم کاملاً سروری است.

## فایل‌های سرور تغییرکرده

- `server-required/includes/archive_control.php`
- `server-required/includes/download_redirect.php`
- `server-required/includes/app_archive_policy.php`
- `server-required/bm_admin.php`
- `server-required/app_config.php`

## فایل Android تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`

## نکته نصب

فایل تنظیم واقعی `archive_api_settings.json` داخل Patch قرار نمی‌گیرد و نباید با فایل نمونه جایگزین شود. تنظیمات فعلی دامنه‌ها هنگام migration حفظ می‌شوند.
