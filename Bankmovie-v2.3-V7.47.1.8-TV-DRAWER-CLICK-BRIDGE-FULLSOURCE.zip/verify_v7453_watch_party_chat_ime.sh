#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
test -f "$player"
grep -Fq 'V7.45.3 — Side-drawer chat' "$player"
grep -Fq 'IME_FLAG_NO_FULLSCREEN' "$player"
grep -Fq 'IME_FLAG_NO_EXTRACT_UI' "$player"
grep -Fq 'SOFT_INPUT_ADJUST_RESIZE' "$player"
grep -Fq 'FLAG_ALT_FOCUSABLE_IM' "$player"
grep -Fq 'WindowManager.LayoutParams.MATCH_PARENT' "$player"
grep -Fq 'R.drawable.ic_party_emoji' "$player"
grep -Fq 'R.drawable.ic_profile_vip' "$player"
grep -Fq 'R.drawable.ic_admin_verified' "$player"
grep -Fq 'setOnEditorActionListener' "$player"
if grep -Fq 'isHorizontallyScrolling = false' "$player"; then
  echo 'bad Kotlin property remains' >&2
  exit 1
fi
echo VERIFY_V7453_OK
