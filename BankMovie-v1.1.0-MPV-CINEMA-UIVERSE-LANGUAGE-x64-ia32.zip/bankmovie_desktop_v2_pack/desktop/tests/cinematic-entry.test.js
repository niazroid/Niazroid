'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const root=path.resolve(__dirname,'..'),read=p=>fs.readFileSync(path.join(root,p),'utf8');
const js=read('src/cinematic-entry.js'),css=read('src/cinematic-entry.css'),app=read('src/app.js'),html=read('src/index.html'),profile=read('src/profile-dashboard.js');
function fake(saved,reduced=false){
 const data=new Map(saved===null?[]:[['bm_entry_motion_v1',saved]]),element=()=>({dataset:{},textContent:'',attrs:{},style:{setProperty(k,v){this[k]=v}},setAttribute(k,v){this.attrs[k]=v},appendChild(el){this.child=el}});
 const status=element(),bar=element(),step=element(),inner=element(),screen=element(),root=element();root.lang='fa';screen.querySelector=s=>({'.startup-status':status,'.startup-progress':bar,'.startup-step':step,'.startup-loading-inner':inner})[s];
 let current=screen,reloads=0;const media={matches:reduced,addEventListener(n,f){this.change=f}};
 const doc={documentElement:root,querySelector:()=>current,createElement:element,addEventListener(){},getElementById:()=>null};
 const win={matchMedia:()=>media,location:{reload(){reloads++}}};
 vm.runInNewContext(js,{window:win,document:doc,localStorage:{getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v)},setTimeout:()=>{}});
 return {api:win.BMEntry,data,root,media,status,bar,step,inner,remove(){current=null},reloads:()=>reloads};
}
const a=fake(null);assert.equal(a.api.enabled(),true);assert.equal(a.root.dataset.bmEntryMotion,'on');a.api.stage(1,'اتصال','Connecting');assert.equal(a.status.textContent,'اتصال');assert.equal(a.bar.attrs['aria-valuenow'],'1');assert.equal(a.bar.style['--entry-progress'],'25%');a.api.loading('آرشیو');assert.equal(a.bar.attrs['aria-valuenow'],'3');assert.equal(a.api.ready(),true);assert.equal(a.bar.attrs['aria-valuenow'],'4');a.remove();assert.equal(a.api.loading('other'),false);
a.api.setEnabled(false);assert.equal(a.data.get('bm_entry_motion_v1'),'0');assert.equal(a.root.dataset.bmEntryMotion,'off');assert.equal(fake('0').api.enabled(),false);assert.equal(fake(null,true).api.enabled(),false);
const b=fake(null);b.api.fail();assert.match(b.status.textContent,/ناموفق/);b.inner.child.onclick();assert.equal(b.reloads(),1);assert.equal(b.api.ready(),false);
for(const asset of ['bm_splash_wall_tv.webp','bm_splash_wall_phone.webp']){const bytes=fs.readFileSync(path.join(root,'src/assets',asset));assert.equal(bytes.subarray(8,12).toString(),'WEBP');assert(bytes.length>1000000);assert(css.includes(asset));}
assert.match(html,/cinematic-entry\.css/);assert.match(html,/cinematic-entry\.js/);assert.match(html,/role="progressbar"/);assert.match(app,/BMEntry\?\.stage\(1,[\s\S]*?await bridge\.bootstrap\(\)/);assert.match(app,/BMEntry\?\.stage\(3,[\s\S]*?await showHome\(\)/);assert.match(app,/BMEntry\?\.ready\(\);\s*renderHome\(result\.data\)/);assert.match(app,/id="bmEntryMotion"/);assert.match(app,/motion\.onchange=\(\)=>globalThis\.BMEntry\?\.setEnabled/);assert.match(profile,/pd-android-wall/);assert.match(css,/pd-custom-wall\{background:none\}/);assert.match(css,/auth-site-panel\.brand-side::before/);assert.match(css,/transform:scale\(1\.09\) translate3d/);
console.log('PASS: bundled Android walls, real startup stages, retry, persistent reduced motion, login/register/profile styling and unchanged custom covers');
