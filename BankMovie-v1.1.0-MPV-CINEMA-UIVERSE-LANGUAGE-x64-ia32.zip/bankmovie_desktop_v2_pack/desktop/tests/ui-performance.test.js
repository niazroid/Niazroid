'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const read=f=>fs.readFileSync(f,'utf8');
const app=read('src/app.js'),scroll=read('src/smooth-scroll.js');
assert.equal(scroll,read('src/discover/assets/js/bm-desktop-smooth-scroll.js'));
assert.match(app,/id="bmSmoothScroll"/);assert.match(app,/smooth\.onchange=\(\)=>globalThis\.BMScroll\?\.setEnabled/);
assert.match(read('src/native-discover.js'),/smoothScroll:window\.BMScroll/);
assert.match(read('src/discover/desktop-adapter.js'),/setEnabled\(info\.smoothScroll,false\)/);
assert.match(read('src/performance.css'),/data-bm-smooth-scroll="off"/);
function wheelHarness(saved){
  let time=0,seq=0;const frames=new Map(),events=new Map(),storage=new Map(saved==null?[]:[['bm_smooth_scroll_v1',saved]]);
  class El{constructor(parent=null){this.nodeType=1;this.parentElement=parent;this.scrollHeight=1000;this.clientHeight=200;this.scrollTop=0;this.isConnected=true;this.dataset={};this.classList={add(){},remove(){}}}closest(){return null}}
  const root=new El(),outer=new El(root),inner=new El(outer);root.scrollHeight=200;
  const document={documentElement:root,scrollingElement:root,addEventListener(k,f){events.set(k,f)},removeEventListener(k,f){if(events.get(k)===f)events.delete(k)}};
  const window={matchMedia:()=>({matches:false}),dispatchEvent(){}};
  const ctx={window,document,Element:El,CustomEvent:class{},localStorage:{getItem:k=>storage.get(k)??null,setItem:(k,v)=>storage.set(k,v)},getComputedStyle:()=>({overflowY:'auto',overscrollBehaviorY:'contain'}),performance:{now:()=>time},requestAnimationFrame:f=>{frames.set(++seq,f);return seq},cancelAnimationFrame:id=>frames.delete(id)};
  vm.runInNewContext(scroll,ctx);
  const wheel=(dy,extra={})=>{let consumed=false;events.get('wheel')?.({target:inner,deltaY:dy,deltaX:0,deltaMode:0,cancelable:true,preventDefault(){consumed=true},...extra});return consumed};
  const run=n=>{for(let i=0;i<n;i++){time+=16;const batch=[...frames.values()];frames.clear();batch.forEach(f=>f(time))}};
  return {window,root,outer,inner,storage,wheel,run,events};
}
const h=wheelHarness();assert.equal(h.window.BMScroll.enabled(),true);assert.equal(h.wheel(120),true);h.run(2);assert.ok(h.inner.scrollTop>0&&h.inner.scrollTop<120);h.wheel(120);h.run(80);assert.equal(h.inner.scrollTop,240);assert.equal(h.outer.scrollTop,0);assert.equal(h.wheel(4),false);assert.equal(h.wheel(120,{ctrlKey:true}),false);h.wheel(120);h.run(1);h.window.BMScroll.setEnabled(false);const pos=h.inner.scrollTop;h.run(80);assert.equal(h.inner.scrollTop,pos);assert.equal(h.events.has('wheel'),false);assert.equal(h.storage.get('bm_smooth_scroll_v1'),'0');assert.equal(wheelHarness('0').window.BMScroll.enabled(),false);
(async()=>{
  const calls=[],pending=[];const state={lastView:'home',user:{id:3}};
  const ctx=vm.createContext({state,sliderMediaItem:x=>x,enabledArchives:()=>[1,2],isVip:()=>false,archiveActionNeedsVip:()=>false,bm1124SectionEnabled:()=>true,itemId:x=>x.id,itemRating:x=>x.rating,cleanUrl:x=>x,bmContent:(action,p)=>{calls.push(p.id);return new Promise(r=>pending.push(()=>r({item:{id:p.id,description:'plot '+p.id,rating:7}})))}});
  vm.runInContext(app.slice(app.indexOf('const bmHeroMetaCache=new Map()'),app.indexOf('function bmHeroStartTimer')),ctx);
  const slides=[1,2,3,4].map(id=>({id,archive:1,type:'movie'}));ctx.bmHeroWarm(slides);assert.deepEqual(calls,['1','2']);const duplicate=ctx.bmHeroRequest(slides[0]);const priority=ctx.bmHeroRequest(slides[3],true);assert.equal(calls.length,2);pending.shift()();await duplicate;assert.deepEqual(calls,['1','2','4']);pending.shift()();await new Promise(r=>setImmediate(r));assert.deepEqual(calls,['1','2','4','3']);pending.shift()();await priority;pending.shift()();await new Promise(r=>setImmediate(r));assert.equal(ctx.bmHeroCachedMetadata(slides[0]).description,'plot 1');assert.equal((await ctx.bmHeroRequest(slides[0])).rating,7);assert.equal(calls.length,4);state.user={id:4};assert.equal(ctx.bmHeroCachedMetadata(slides[0]),null);
  console.log('PASS: bounded early hero metadata, deduplication, priority, scoped cache, global wheel easing, nested scroll and persisted opt-out');
})().catch(e=>{console.error(e);process.exitCode=1});
