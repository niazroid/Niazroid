'use strict';
const {ipcRenderer}=require('electron');
window.addEventListener('DOMContentLoaded',()=>{
 const bar=document.querySelector('progress'),label=document.getElementById('stage');
 ipcRenderer.on('bm-player-splash:stage',(_event,value)=>{if(!Array.isArray(value)||!Number.isFinite(value[0])||typeof value[1]!=='string')return;bar.value=value[0];label.textContent=value[1];const en=value[2]==='en';document.documentElement.lang=en?'en':'fa';document.documentElement.dir=en?'ltr':'rtl';bar.setAttribute('aria-label',en?'Player startup stages':'مراحل آماده‌سازی پلیر');document.getElementById('cancel').textContent=en?'Cancel (Esc)':'انصراف (Esc)';});
 document.getElementById('cancel').addEventListener('click',()=>window.close());
});
