/* BankMovie Film Radar v4.4 — accessible, motion-aware UI. All film data originates from BankMovie API. */
(()=>{'use strict';
const boot=window.BM4_BOOT;if(!boot)return;
const $=(q,r=document)=>r.querySelector(q), $$=(q,r=document)=>Array.from(r.querySelectorAll(q));
const el=id=>document.getElementById('bm4-'+id);
const make=(tag,cls='',text)=>{const x=document.createElement(tag);if(cls)x.className=cls;if(text!==undefined)x.textContent=String(text);return x;};
const num=n=>Number(n||0).toLocaleString('fa-IR');
const set=(id,v)=>{const n=el(id);if(n)n.textContent=String(v);};
const readEra=()=>{const p=new URLSearchParams(location.search),from=p.get('year_min'),to=p.get('year_max');if(!/^\d{4}$/.test(from||'')||!/^\d{4}$/.test(to||''))return null;const a=Number(from),b=Number(to);return a>=1900&&b<=new Date().getFullYear()+1&&a<=b?{from:a,to:b}:null;};
const state={mood:'excited',mode:'mood',seed:seed(),items:[],active:0,seen:[],lastMode:'mood',request:0,abort:null,liked:[],taste:[],tastePos:0,tasteDone:false,seeds:[null,null],mixItems:[],mixPreset:'custom',categoryKey:'',page:1,perPage:12,hasMore:false,totalItems:0,lastShift:0,shiftLock:false,decade:readEra(),carouselPage:1,carouselHasMore:false,carouselLoading:false,carouselExhausted:false,carouselBase:null,carouselSeen:[],carouselAdvancePending:false,carouselNeedsPaint:false,carouselAbort:null,carouselToken:0,carouselBaseIndex:0,carouselMode:'mood'};
const labels={excited:'آدرنالین',fun:'خوش‌حال‌و‌هوا',romantic:'دل‌نشین',mystery:'پر از راز',scary:'دلهره',calm:'حال خوب',dream:'بی‌مرز',deep:'تأثیرگذار'};
const randomValues=()=>Math.floor(Math.random()*0x7fffffff);
function seed(){if(window.crypto?.getRandomValues){const v=new Uint32Array(1);window.crypto.getRandomValues(v);return v[0] & 0x7fffffff;}return Math.floor(Math.random()*1e9);}
const safePath=p=>typeof p==='string'&&p.startsWith('/')&&!p.startsWith('//')&&!p.includes('..')&&!/[\x00-\x1f]/.test(p)?p:'';
const safeImage=u=>{if(safePath(u))return window.BMDesktopDiscover.asset(u);if(typeof u==='string'&&/^https?:\/\/[^\s]+$/i.test(u))return u;return '';};
const safeLink=u=>{const path=safePath(u);if(!path)return '/search';try{const v=new URL(path,'https://bankmovie.top');return v.origin==='https://bankmovie.top'&&v.pathname.startsWith('/')?v.pathname+v.search:'/search';}catch(_){return '/search';}};
const errorMsg=e=>({too_many_requests:'درخواست‌ها زیاد شده؛ کمی بعد دوباره امتحان کن.',archive_unavailable:'این بخش برای حساب شما فعال نیست.',feature_disabled:'رادار از مدیریت سایت غیرفعال شده.'}[e?.message]||'دریافت پیشنهادها ناموفق بود؛ دوباره امتحان کن.');
async function request(params,signal){const resp=await fetch((boot.api||'/api_discover.php')+'?'+params.toString(),{credentials:'same-origin',headers:{Accept:'application/json'},signal});let json;try{json=await resp.json();}catch{throw Error('invalid_response');}if(!resp.ok||!json?.ok)throw Error(json?.error||'request_failed');return json.data||{};}
function image(m,css='',loading='lazy'){const wrap=make('span','bm4-poster-image '+css);const src=safeImage(m?.poster);if(src){const img=make('img');img.src=src;img.alt=m?.title?'پوستر '+m.title:'پوستر';img.loading=loading;img.decoding='async';img.addEventListener('error',()=>wrap.classList.add('is-missing'));wrap.append(img);}else wrap.classList.add('is-missing');return wrap;}
function posterCard(m,i=0){const a=make('a','bm4-poster-card');a.href=safeLink(m.url);a.style.setProperty('--card-delay',Math.min(i,11)*18+'ms');const art=image(m);if(Number(m.rating)>0){const pill=make('span','bm4-imdb-pill',Number(m.rating).toFixed(1)+' IMDb');art.append(pill);}a.append(art);const info=make('span','bm4-poster-info');const top=make('span','bm4-poster-top');top.append(make('strong','',m.title||m.title_en||'بدون عنوان'),make('small','',m.type==='series'?'سریال':'فیلم'));const meta=make('span','bm4-poster-meta');const yr=make('span','bm4-meta-chip',m.year||'');if(!(m.year||''))yr.hidden=true;meta.append(yr);info.append(top,meta);a.append(info);return a;}
function placeholder(root,howMany=6){root.replaceChildren(...Array.from({length:howMany},()=>make('div','bm4-skeleton')));}
function filters(){return {type:el('type').value,genre:el('genre').value,country:el('country').value,year_min:el('year').value,rating_min:el('rating').value};}
function query(mode,ignoreSeen=false,pageOverride=state.page,seedOverride=state.seed,skipOverride=null){const page=Math.max(1,Number(pageOverride)||1);if(mode==='decade'){const d=state.decade;if(!d)throw Error('invalid_decade');return new URLSearchParams({mode:'decade',year_min:d.from,year_max:d.to,page,per_page:state.perPage});}const p=new URLSearchParams({...filters(),mode,mood:state.mood,seed:seedOverride,page,per_page:state.perPage});if(Array.isArray(skipOverride))skipOverride.slice(-36).forEach(n=>p.append('skip_ids[]',String(n)));else if(page===1&&!ignoreSeen)state.seen.slice(-30).forEach(n=>p.append('skip_ids[]',n));if(mode==='category')p.set('category_key',state.categoryKey);if(mode==='mixer')$$('[data-mix]').forEach(x=>p.set('mix_'+x.dataset.mix,x.value));if(mode==='similar'){p.set('seed_id',state.seeds[0]?.id||0);p.set('seed_id2',state.seeds[1]?.id||0);}if(mode==='taste')state.liked.forEach(n=>p.append('likes[]',n));return p;}
const scrollResults=()=>el('results').scrollIntoView({behavior:window.BMScroll?.behavior()||(window.matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth'),block:'start'});
function updating(on,mode='mood'){
 const layer=el('results-loader'),stage=el('stage-loader');
 if(layer)layer.hidden=!on;
 if(stage)stage.hidden=!on;
 if(el('grid'))el('grid').setAttribute('aria-busy',String(on));
 if(on)set('loading-label',mode==='surprise'?'داریم بلیت امشبت رو آماده می‌کنیم…':mode==='mixer'?'در حال ترکیب سلیقه‌ات…':mode==='decade'?'در حال آوردن فیلم‌های این دهه…':'در حال پیدا کردن پیشنهادها…');
 el('grid')?.classList.toggle('is-loading',on);
 ['fresh','more','surprise-run','surprise-run-2','mix-run','filter-run','similar-run','personal-run'].forEach(id=>el(id)?.toggleAttribute('disabled',on));
 if(el('page-prev'))el('page-prev').disabled=on||state.page<=1;
 if(el('page-next'))el('page-next').disabled=on||!state.hasMore;
 el('stack')?.classList.toggle('is-loading',on);
}
function setInlineLoader(button,on){
 if(!button)return;
 button.classList.toggle('bm4-inline-loading',on);
 const existing=button.querySelector(':scope > .bm4-loading-bars');
 if(!on){existing?.remove();return;}
 if(existing)return;
 const bars=make('span','bm4-loading-bars');bars.setAttribute('aria-hidden','true');
 for(let i=0;i<3;i++)bars.append(make('i','bm4-loading-bar'));
 button.prepend(bars);
}
function setMood(key,refresh=true){if(!labels[key])return;state.mood=key;$$('[data-mood]').forEach(b=>{const active=b.dataset.mood===key;b.classList.toggle('is-active',active);b.setAttribute('aria-pressed',String(active));});if(refresh){state.seed=seed();run('mood',true,1);}}
function recordSeen(items){for(const m of items)if(m?.id&&!state.seen.includes(m.id))state.seen.push(m.id);if(state.seen.length>240)state.seen.splice(0,state.seen.length-240);}
// Lightweight compositor carousel: keep the same three poster nodes across swipes.
// Two side cards are actual previous/next choices, so both directions feel continuous.
const prefersReduced=window.matchMedia('(prefers-reduced-motion: reduce)');
const liteMotion=!!(navigator.connection?.saveData || (navigator.deviceMemory&&navigator.deviceMemory<=2));
if(liteMotion)document.documentElement.classList.add('bm4-motion-lite');
const motionOff=()=>prefersReduced.matches;
let stackTimer=0,pendingShift=0;
const imageWarmCache=new Map();
function warmPoster(m){
 const src=safeImage(m?.poster);if(!src||imageWarmCache.has(src))return;
 const img=new Image();img.decoding='async';imageWarmCache.set(src,img);
 if(imageWarmCache.size>9)imageWarmCache.delete(imageWarmCache.keys().next().value);
 img.src=src; // browser cache is shared with the visible <img>
 if(img.decode)img.decode().catch(()=>{});
}
function warmNearby(){
 if(!state.items.length)return;
 const indexes=[state.active-1,state.active,state.active+1,state.active+2];
 if(state.active===0&&state.items.length>1)indexes[0]=state.items.length-1;
 for(const index of indexes)if(index>=0&&index<state.items.length)warmPoster(state.items[index]);
}
function stackCard(role){const a=make('a','bm4-stack-card '+role);a.append(image({}));return a;}
function fillStackCard(a,m){
 if(!a)return;
 let wrap=a.querySelector('.bm4-poster-image');if(!wrap){wrap=image({});a.append(wrap);}
 let img=wrap.querySelector('img');
 if(!m){a.removeAttribute('href');a.setAttribute('aria-hidden','true');a.classList.add('is-empty');img?.remove();wrap.classList.add('is-missing');return;}
 a.classList.remove('is-empty');a.removeAttribute('aria-hidden');
 const href=safeLink(m.url),src=safeImage(m.poster);
 if(a.getAttribute('href')!==href)a.setAttribute('href',href);
 a.setAttribute('aria-label','مشاهده '+(m.title||'فیلم'));
 if(src){
   if(!img){img=make('img');img.decoding='async';img.alt='';wrap.append(img);}
   if(img.getAttribute('src')!==src)img.src=src;
   wrap.classList.remove('is-missing');
 }else{img?.remove();wrap.classList.add('is-missing');}
}
function stackNodes(){
 const target=el('stack');if(!target)return null;
 let front=target.querySelector('.bm4-stack-card.front');
 let middle=target.querySelector('.bm4-stack-card.middle');
 let rear=target.querySelector('.bm4-stack-card.rear');
 if(!front||!middle||!rear){
   target.replaceChildren();rear=stackCard('rear');middle=stackCard('middle');front=stackCard('front');
   target.append(rear,middle,front);
 }
 return {target,front,middle,rear};
}
function paintStackMeta(){
 const items=state.items;if(!items.length)return;
 const i=state.active%items.length,m=items[i];
 set('feature-name',m.title||m.title_en||'');
 set('feature-label',labels[state.mood]+' / پیشنهاد '+num(state.carouselBaseIndex+i+1));
 set('feature-meta',[(m.year||''),m.type==='series'?'سریال':'فیلم',Number(m.rating)>0?'IMDb '+m.rating:''].filter(Boolean).join(' · '));
 const pips=el('pips');if(!pips)return;
 pips.replaceChildren();
 const dotCount=Math.min(7,items.length),dotStart=Math.max(0,Math.min(i-3,items.length-dotCount));
 items.slice(dotStart,dotStart+dotCount).forEach((_,j)=>{
   const index=dotStart+j;
   const b=make('button','bm4-pip'+(index===i?' is-active':''));b.type='button';
   b.setAttribute('aria-label','پیشنهاد '+num(state.carouselBaseIndex+index+1));
   b.addEventListener('click',()=>{
     if(index===state.active)return;
     const diff=index-state.active;
     if(Math.abs(diff)===1)shift(Math.sign(diff));
     else{state.active=index;paintStack();maybeLoadCarousel();}
   });pips.append(b);
 });
}
function paintStack(){
 clearTimeout(stackTimer);state.shiftLock=false;pendingShift=0;
 const target=el('stack'),items=state.items;if(!target)return;
 if(!items.length){target.replaceChildren(make('div','bm4-stage-empty','پیشنهادی با این شرایط پیدا نشد'));set('feature-name','ترکیب دیگه‌ای امتحان کن');set('feature-meta','فیلترها را سبک‌تر کن');el('pips')?.replaceChildren();return;}
 const n=stackNodes(),i=state.active;
 const rearItem=items[i-1]||(i===0&&items.length>1?items[items.length-1]:null);
 for(const [node,item] of [[n.front,items[i]||null],[n.middle,items[i+1]||null],[n.rear,rearItem]]){
   node.classList.add('bm4-instant');node.style.removeProperty('transform');
   fillStackCard(node,item);
 }
 // Remove transition suppression on the following frame, without forcing layout.
 requestAnimationFrame(()=>{for(const node of [n.front,n.middle,n.rear])node.classList.remove('bm4-instant');});
 paintStackMeta();warmNearby();
}
function canRenewCarousel(){return !!state.carouselBase&&!['decade','category'].includes(state.carouselMode);}
function maybeLoadCarousel(){
 if(!state.items.length||state.carouselLoading||state.carouselExhausted)return;
 const threshold=Math.max(0,state.items.length-5);
 if(state.active>=threshold&&(state.carouselHasMore||canRenewCarousel()))loadMoreCarousel();
}
async function loadMoreCarousel(){
 if(state.carouselLoading||state.carouselExhausted||!state.carouselBase)return;
 let renewing=!state.carouselHasMore;
 if(renewing&&!canRenewCarousel()){state.carouselExhausted=true;set('feature-meta','به پایان پیشنهادهای این بخش رسیدی.');return;}
 state.carouselLoading=true;
 const token=++state.carouselToken,controller=new AbortController();state.carouselAbort=controller;
 let added=0,attempts=0;
 try{
  while(attempts<5&&!added){
   let params=new URLSearchParams(state.carouselBase),nextSeed=null;
   if(renewing){
    nextSeed=seed();params.set('seed',String(nextSeed));params.set('page','1');params.delete('skip_ids[]');
    state.carouselSeen.slice(-36).forEach(id=>params.append('skip_ids[]',String(id)));
   }else params.set('page',String(state.carouselPage+1));
   const data=await request(params,controller.signal);
   if(token!==state.carouselToken)return;
   if(renewing){
    state.carouselBase=new URLSearchParams(params);state.carouselBase.delete('page');state.carouselBase.delete('skip_ids[]');
    if(nextSeed!==null)state.seed=nextSeed;
    state.carouselPage=0;renewing=false;
   }
   state.carouselPage=Number(data?.page||params.get('page')||1);
   state.carouselHasMore=!!data?.has_more;
   const seenSet=new Set(state.carouselSeen.map(String));
   const freshItems=(Array.isArray(data?.items)?data.items:[]).filter(m=>m&&m.id&&!seenSet.has(String(m.id)));
   if(freshItems.length){
    state.items.push(...freshItems);
    for(const item of freshItems){const id=String(item.id);state.carouselSeen.push(id);if(!state.seen.includes(item.id))state.seen.push(item.id);}
    if(state.carouselSeen.length>360)state.carouselSeen.splice(0,state.carouselSeen.length-360);
    if(state.seen.length>240)state.seen.splice(0,state.seen.length-240);
    if(state.items.length>96){const drop=Math.max(0,state.active-24);if(drop>0){state.items.splice(0,drop);state.active-=drop;state.carouselBaseIndex+=drop;}}
    added=freshItems.length;state.carouselExhausted=false;
    if(state.shiftLock)state.carouselNeedsPaint=true;else paintStack();
    paintStackMeta();warmNearby();
    if(state.carouselAdvancePending){state.carouselAdvancePending=false;requestAnimationFrame(()=>shift(1));}
    break;
   }
   attempts++;
   if(!state.carouselHasMore){
    if(canRenewCarousel())renewing=true;
    else{state.carouselExhausted=true;break;}
   }
  }
  if(!added){
   state.carouselExhausted=true;
   set('feature-meta','پیشنهادهای بیشتری با این شرایط پیدا نشد؛ حال‌وهوا یا فیلترها رو تغییر بده.');
   if(state.carouselAdvancePending)state.carouselAdvancePending=false;
  }
 }catch(error){
  if(error?.name!=='AbortError'&&token===state.carouselToken){if(state.carouselAdvancePending){state.carouselAdvancePending=false;set('feature-meta','دریافت پیشنهادهای بیشتر ناموفق بود؛ دوباره کمی بعد امتحان کن.');}}
 }finally{
  if(token===state.carouselToken){state.carouselLoading=false;state.carouselAbort=null;}
 }
}
function shift(direction){
 const items=state.items,dir=Math.sign(direction);if(!dir||!items.length)return;
 if(state.shiftLock){pendingShift=dir;return;}
 let nextIndex=state.active+dir;
 if(dir>0&&nextIndex>=items.length){
  if(state.carouselHasMore||canRenewCarousel()){state.carouselAdvancePending=true;loadMoreCarousel();}
  else set('feature-meta','به آخر پیشنهادهای این ترکیب رسیدی؛ «پیشنهاد جدید» رو بزن.');
  return;
 }
 if(dir<0&&nextIndex<0)nextIndex=items.length-1;
 const n=stackNodes();if(!n)return;
 if(motionOff()||items.length<2){state.active=nextIndex;paintStack();maybeLoadCarousel();return;}
 state.shiftLock=true;
 const oldFront=n.front,arrival=dir>0?n.middle:n.rear,unused=dir>0?n.rear:n.middle;
 const recycleIndex=dir>0?nextIndex+1:(nextIndex-1>=0?nextIndex-1:items.length-1);
 if(items[recycleIndex])warmPoster(items[recycleIndex]);
 n.target.classList.add('bm4-turning');
 oldFront.className='bm4-stack-card '+(dir>0?'rear':'middle');
 arrival.className='bm4-stack-card front';
 unused.className='bm4-stack-card '+(dir>0?'middle':'rear')+' bm4-parked';
 requestAnimationFrame(()=>oldFront.style.removeProperty('transform'));
 state.active=nextIndex;
 const duration=liteMotion?230:355;
 const finish=()=>{
  if(!state.shiftLock)return;
  n.target.classList.remove('bm4-turning');
  const side=dir>0?'middle':'rear';
  unused.className='bm4-stack-card '+side+' bm4-instant';
  fillStackCard(unused,items[recycleIndex]||null);
  requestAnimationFrame(()=>unused.classList.remove('bm4-instant'));
  state.shiftLock=false;
  if(state.carouselNeedsPaint){state.carouselNeedsPaint=false;paintStack();}else{paintStackMeta();warmNearby();}
  maybeLoadCarousel();
  const queued=pendingShift;pendingShift=0;if(queued)shift(queued);
 };
 stackTimer=setTimeout(finish,duration+45);
}
function updatePager(data,list){state.page=Number(data?.page||1);state.hasMore=!!data?.has_more;state.totalItems=Number(data?.total_items||list.length||0);const start=state.totalItems?((state.page-1)*state.perPage)+1:0;const end=Math.min(state.totalItems,start+Math.max(0,list.length-1));set('page-summary',state.totalItems?('نمایش '+num(start)+' تا '+num(end)+' از '+num(state.totalItems)):'بدون نتیجه');if(el('page-prev'))el('page-prev').disabled=state.page<=1;if(el('page-next'))el('page-next').disabled=!state.hasMore;}
function goPage(page){const next=Math.max(1,page|0);if(next===state.page&&next!==1)return;run(state.lastMode,true,next);} 
function render(items,mode,data,shouldScroll,requestParams=null){const grid=el('grid');grid.replaceChildren();const list=items||[];state.items=list;state.active=0;state.mode=mode;state.carouselPage=Number(data?.page||state.page||1);state.carouselHasMore=!!data?.has_more;state.carouselLoading=false;state.carouselExhausted=false;state.carouselAdvancePending=false;state.carouselNeedsPaint=false;state.carouselBaseIndex=0;state.carouselMode=mode;state.carouselSeen=list.filter(m=>m?.id).map(m=>String(m.id));state.carouselBase=requestParams?new URLSearchParams(requestParams):null;if(state.carouselBase){state.carouselBase.delete('page');state.carouselBase.delete('skip_ids[]');}set('result-title',({mood:'انتخاب‌های مناسب حال‌وهوایت',sentence:'نتیجه‌های فیلترشده',mixer:'پیشنهادهای ترکیب تو',taste:'پیشنهادهای نزدیک به انتخاب‌هایت',similar:'آثار مشابه',personal:'پیشنهادهای نزدیک به سابقه تو',surprise:'فیلم شانسی امشب',popular:'فیلم‌های پررأی',category:'نتایج این مجموعه',daily:'انتخاب‌های امروز'}[mode]||'پیشنهادهای بانک‌مووی'));updatePager(data,list);if(mode==='category'&&data?.category_title)set('result-title',data.category_title);if(mode==='decade')set('result-title','فیلم‌ها و سریال‌های '+num(data?.year_min||state.decade?.from)+' تا '+num(data?.year_max||state.decade?.to));
 if(list.length){list.forEach((m,i)=>grid.append(posterCard(m,i)));set('result-meta',`${num(list.length)} عنوان در این صفحه · از ${num(data?.total_items||list.length)} خروجی مرتب‌شده`);recordSeen(list);el('results-footer').textContent='می‌تونی روی هر پوستر بزنی یا با صفحه بعدی/قبلی نتیجه‌های بیشتری ببینی.';}
 else{const empty=make('div','bm4-empty');empty.append(make('strong','',mode==='personal'?'هنوز سلیقه کافی نداریم':'با این فیلترها عنوانی پیدا نشد'),make('p','',mode==='personal'?'بعد از ثبت علاقه‌مندی یا تماشا، پیشنهاد شخصی دقیق‌تر می‌شود.':'سال، امتیاز یا کشور رو بازتر کن؛ ژانر انتخابی رو خودسرانه عوض نمی‌کنیم.'));grid.append(empty);set('result-meta','فیلمی با این فیلترها پیدا نشد.');el('results-footer').textContent='فعلاً نتیجه‌ای پیدا نشد؛ فیلترها را سبک‌تر کن.';}
 paintStack();maybeLoadCarousel();if(!state.tasteDone && !state.taste.length && list.length>=5)prepareTaste(list);
 if(mode==='mixer'){state.mixItems=list.slice(0,4);drawMix();}
 if(shouldScroll)scrollResults();
}
async function run(mode='mood',shouldScroll=false,page=1){if(mode==='similar'&&!state.seeds[0]){el('seed1').focus();return;} if(mode!=='decade'&&state.decade){state.decade=null;const u=new URL(location.href);u.searchParams.delete('year_min');u.searchParams.delete('year_max');history.replaceState(null,'',u.pathname+u.search+u.hash);} state.page=Math.max(1,page|0);
 if(mode==='taste'&&!state.liked.length){set('taste-meta','حداقل یک پوستر رو بپسند تا پیشنهاد مرتبط بسازیم.');return;}
 state.lastMode=mode;state.carouselAbort?.abort();state.carouselAbort=null;state.carouselToken++;state.carouselLoading=false;state.carouselBase=null;state.carouselHasMore=false;state.carouselAdvancePending=false;state.carouselExhausted=false;const ticket=++state.request;state.abort?.abort();state.abort=new AbortController();
 updating(true,mode);
 // Move to the results at request start; the user sees the loading animation during scroll.
 if(shouldScroll)scrollResults();
 try{
   let requestParams=query(mode),res=await request(requestParams,state.abort.signal);
   if(ticket!==state.request)return null;
   if(res.error&&mode==='category')throw Error(res.error);
   if(!(res.items||[]).length && state.seen.length>0){
     requestParams=query(mode,true);res=await request(requestParams,state.abort.signal);
     if(ticket!==state.request)return null;
   }
   if(ticket!==state.request)return null;
   render(res.items||[],mode,res,false,requestParams);
   if(mode!=='decade')set('hero-hint',`انتخاب ${labels[state.mood]} · هر بار ترکیب تازه از ژانرهای مرتبط`);
   return res.items||[];
 }catch(e){
   if(ticket!==state.request||e.name==='AbortError')return null;
   el('grid').replaceChildren(make('p','bm4-empty',errorMsg(e)));
   set('result-meta',errorMsg(e));set('hero-hint',errorMsg(e));
   return null;
 }finally{if(ticket===state.request)updating(false);}
}
function fresh(){state.seed=seed();state.page=1;state.lastShift=1;run(state.lastMode==='category'?'mood':state.lastMode,false,1);}
function dialogOpen(m){if(!m)return;const modal=el('dialog');el('dialog-poster').replaceChildren(image(m,'','eager'));set('dialog-title',m.title||m.title_en||'');set('dialog-subtitle',m.title_en&&m.title_en!==m.title?m.title_en:'پیشنهاد بانک‌مووی');const tags=el('dialog-tags');tags.replaceChildren();for(const str of [m.type==='series'?'سریال':'فیلم',m.year,Number(m.rating)>0?'IMDb '+m.rating:'',...(m.genres||[]).slice(0,2)])if(str)tags.append(make('span','',str));el('dialog-url').href=safeLink(m.url);modal.showModal?.();}
$$('[data-mood]').forEach(b=>b.addEventListener('click',()=>setMood(b.dataset.mood)));
el('fresh').addEventListener('click',fresh);el('more').addEventListener('click',()=>{state.seed=seed();state.page=1;run(state.lastMode==='category'?'mood':state.lastMode,true,1);});el('page-next')?.addEventListener('click',()=>goPage(state.page+1));el('page-prev')?.addEventListener('click',()=>goPage(state.page-1));if(el('next'))el('next').addEventListener('click',()=>shift(1));if(el('prev'))el('prev').addEventListener('click',()=>shift(-1));document.addEventListener('keydown',e=>{if(document.body.classList.contains('reels-open')||(e.target&&/INPUT|TEXTAREA|SELECT/.test(e.target.tagName)))return;if(e.key==='ArrowRight')shift(1);if(e.key==='ArrowLeft')shift(-1);});el('open').addEventListener('click',()=>dialogOpen(state.items[state.active]));const openSurprise=async()=>{state.seed=seed();state.page=1;const items=await run('surprise',true,1);if(items?.length)dialogOpen(items[0]);};if(el('surprise-run'))el('surprise-run').addEventListener('click',openSurprise);if(el('surprise-run-2'))el('surprise-run-2').addEventListener('click',openSurprise);el('dialog-close').addEventListener('click',()=>el('dialog').close());el('dialog').addEventListener('click',e=>{if(e.target===el('dialog'))el('dialog').close();});el('dialog-another').addEventListener('click',()=>{el('dialog').close();shift(1);setTimeout(()=>dialogOpen(state.items[state.active]),120);});
// Brand-native filtered exploration, without large line-wrapping select controls.
function fieldSummary(){const f=filters();const parts=[f.type==='movie'?'فقط فیلم':f.type==='series'?'فقط سریال':'فیلم و سریال',f.genre||('ژانر: '+labels[state.mood]),f.country?('کشور: '+f.country):'بدون محدودیت کشور',+f.year_min>1900?('از '+f.year_min+' به بعد'):'همه سال‌ها',+f.rating_min>0?('IMDb '+f.rating_min+'+'):'بدون محدودیت امتیاز'];set('active-filters',parts.join('  /  '));}
$$('.bm4-fields select').forEach(s=>s.addEventListener('change',fieldSummary));fieldSummary();
el('filter-run').addEventListener('click',()=>{state.seed=seed();run('sentence',true,1);});el('reset').addEventListener('click',()=>{$$('.bm4-fields select').forEach(s=>s.selectedIndex=0);fieldSummary();state.seed=seed();run('mood',true,1);});
// Horizontal metal-slider mixer; track values are the actual model weights.
const presets={pulse:{excited:95,mystery:50,scary:35},light:{fun:95,calm:55,romantic:25},mind:{mystery:90,deep:70,scary:20},reset:{}};
function updateMixer(){const vals=$$('[data-mix]').map(input=>{const value=Number(input.value);input.style.setProperty('--fill',value+'%');const output=$(`[data-mix-value="${input.dataset.mix}"]`);if(output)output.textContent=num(value)+'٪';return [input.dataset.mix,value];}).sort((a,b)=>b[1]-a[1]);const top=vals.filter(x=>x[1]>0).slice(0,3).map(x=>labels[x[0]]).join(' + ');set('mix-description',top||'برای شروع یکی دو اسلایدر را کمی بالا ببر.');}
$$('[data-mix]').forEach(input=>input.addEventListener('input',()=>{state.mixPreset='custom';updateMixer();}));
$$('[data-preset]').forEach(b=>b.addEventListener('click',()=>{state.mixPreset=b.dataset.preset;$$('[data-mix]').forEach(input=>{input.value=presets[state.mixPreset]?.[input.dataset.mix]||0;});updateMixer();}));updateMixer();
function drawMix(){const wrap=el('mix-covers');wrap.replaceChildren();if(!state.mixItems.length){wrap.append(make('div','bm4-empty','با این ترکیب عنوانی پیدا نشد.'));return;}for(const m of state.mixItems){const a=make('a','bm4-mix-cover');a.href=safeLink(m.url);a.title=m.title;a.append(image(m));wrap.append(a);}}
el('mix-run').addEventListener('click',()=>{state.seed=seed();run('mixer',true,1);});el('mix-show').addEventListener('click',()=>scrollResults());
// User-based poster selection: real candidate posters, real genres; no invented genre labels.
function prepareTaste(cards){state.taste=cards.slice(0,5);state.tastePos=0;state.liked=[];state.tasteDone=false;renderTaste();}
function renderTaste(){const idx=state.tastePos,m=state.taste[idx],done=idx>=state.taste.length;const v=el('taste-poster');v.replaceChildren();el('taste-no').disabled=done||!m;el('taste-yes').disabled=done||!m;el('taste-progress').style.width=Math.min(idx,5)*20+'%';set('taste-count',num(Math.min(idx+1,5))+' از '+num(5));if(done){state.tasteDone=true;v.append(make('div','bm4-taste-finish','پروفایل سلیقه آماده است'));set('taste-title','سلیقه‌ات ثبت شد');set('taste-meta',state.liked.length?'پیشنهادها بر پایه '+num(state.liked.length)+' فیلم پسندیده‌شده محاسبه می‌شن.':'هیچ عنوانی انتخاب نشد؛ می‌تونی دوباره شروع کنی.');return;}v.append(image(m,'','eager'));set('taste-title',m.title||m.title_en||'');set('taste-meta',[(m.year||''),...(m.genres||[]).slice(0,2)].filter(Boolean).join(' · '));}
function vote(yes){const m=state.taste[state.tastePos];if(!m)return;if(yes)state.liked.push(m.id);state.tastePos++;const visual=el('taste-poster');visual.classList.remove('is-voted');void visual.offsetWidth;visual.classList.add('is-voted');renderTaste();if(state.tastePos>=5&&state.liked.length){state.seed=seed();run('taste',true,1);}}
el('taste-no').addEventListener('click',()=>vote(false));el('taste-yes').addEventListener('click',()=>vote(true));el('taste-reset').addEventListener('click',async()=>{
 const button=el('taste-reset');if(button.disabled)return;
 state.taste=[];state.tasteDone=false;state.seed=seed();button.disabled=true;
 setInlineLoader(button,true);
 try{const x=await request(new URLSearchParams({mode:'surprise',seed:state.seed,type:'all'}));if(x.items?.length)prepareTaste(x.items);}
 catch{set('taste-meta','دریافت پوسترهای تازه ممکن نشد.');}
 finally{button.disabled=false;setInlineLoader(button,false);}
});
// Native title autocomplete, with AbortController and explicit selection.
function lookup(input,holder,index){let controller=null,serial=0,timer;const reset=()=>{state.seeds[index]=null;};input.addEventListener('input',()=>{reset();holder.hidden=true;clearTimeout(timer);controller?.abort();const q=input.value.trim();if(q.length<2)return;const ticket=++serial;timer=setTimeout(async()=>{controller=new AbortController();try{const data=await request(new URLSearchParams({mode:'lookup',q}),controller.signal);if(ticket!==serial)return;holder.replaceChildren();if(!data.items?.length)holder.append(make('div','bm4-search-empty','عنوانی پیدا نشد.'));else for(const m of data.items){const b=make('button','bm4-search-option');b.type='button';b.append(image(m),make('span','',m.title+' · '+(m.year||'')));b.addEventListener('click',()=>{state.seeds[index]=m;input.value=m.title;holder.hidden=true;});holder.append(b);}holder.hidden=false;}catch(e){if(e.name!=='AbortError')holder.hidden=true;}},320);});document.addEventListener('click',e=>{if(!input.contains(e.target)&&!holder.contains(e.target))holder.hidden=true;});input.addEventListener('keydown',e=>{if(e.key==='Escape')holder.hidden=true;});}
lookup(el('seed1'),el('seed1-list'),0);lookup(el('seed2'),el('seed2-list'),1);el('similar-run').addEventListener('click',()=>{state.seed=seed();run('similar',true,1);});
el('personal-run').addEventListener('click',()=>{state.seed=seed();run('personal',true,1);});
// Curated collection showcase: every number and poster belongs to a real DB collection.
function featuredCollectionCard(c,idx){
  const card=make('a','bm4-coll-card'+(idx===0?' bm4-coll-card--lead':''));
  card.href=safeLink(c.url);
  card.setAttribute('aria-label','مشاهده کالکشن '+c.title);
  const back=make('span','bm4-coll-background');
  if(safeImage(c.cover)){
    const backdrop=make('img','bm4-coll-backdrop');
    backdrop.src=safeImage(c.cover);backdrop.loading='lazy';backdrop.alt='';backdrop.decoding='async';
    back.append(backdrop);
  }
  card.append(back);
  const tri=make('span','bm4-coll-trio');
  const posters=(Array.isArray(c.posters)?c.posters:[]).filter(p=>safeImage(p.poster)).slice(0,3);
  posters.forEach((p,i)=>{const box=make('span','bm4-coll-poster bm4-coll-poster-'+i);const img=make('img');img.src=safeImage(p.poster);img.loading='lazy';img.alt='پوستر '+(p.title||c.title);img.decoding='async';img.addEventListener('error',()=>box.classList.add('is-broken'));box.append(img);tri.append(box);});
  card.append(tri);
  const info=make('span','bm4-coll-info');
  const badge=make('span','bm4-coll-eyebrow',idx===0?'انتخاب ویژه بانک‌مووی':'مجموعه سینمایی');
  const title=make('strong','bm4-coll-name',c.title||'کالکشن');
  const parts=[num(c.count)+' عنوان'];
  if(Number(c.first_year)>1900 && Number(c.last_year)>1900)parts.push(c.first_year===c.last_year?String(c.first_year):c.first_year+'–'+c.last_year);
  const meta=make('span','bm4-coll-meta',parts.join('  ·  '));
  info.append(badge,title,meta);
  const average=Number(c.avg_rating);
  if(c.avg_rating!==null&&Number.isFinite(average)&&average>0){
    const imdb=make('span','bm4-coll-imdb');imdb.dir='ltr';
    imdb.title='میانگین امتیاز مجموعه در IMDb';
    imdb.setAttribute('aria-label','میانگین IMDb '+average.toFixed(1));
    const score=make('b','bm4-coll-imdb-score',average.toFixed(1));
    const logo=make('img');logo.src='/assets/brand/imdb-logo.svg';logo.alt='IMDb';
    logo.width=28;logo.height=14;logo.loading='lazy';logo.decoding='async';
    imdb.append(score,logo);info.append(imdb);
  }
  const more=make('span','bm4-coll-action','مشاهده کالکشن');
  const icon=document.createElementNS('http://www.w3.org/2000/svg','svg');icon.setAttribute('viewBox','0 0 24 24');icon.setAttribute('width','16');icon.setAttribute('height','16');icon.setAttribute('fill','none');icon.setAttribute('stroke','currentColor');icon.setAttribute('stroke-width','1.9');icon.innerHTML='<path d="m14 6-6 6 6 6" stroke-linecap="round" stroke-linejoin="round" />';
  more.append(icon);info.append(more);card.append(info);
  return card;
}
// Featured cards are server-rendered. Fetch *only* when the user requests
// additional collections: a failed API call cannot blank the initial showcase.
function initFeaturedCollections(){
  const root=el('collection-showcase'),extra=el('collection-extra'),toggle=el('collections-toggle');
  if(!root||!extra||!toggle)return;
  let loaded=false,busy=false;
  const showExtra=()=>{
    const opening=extra.hidden;
    extra.hidden=!opening;
    toggle.setAttribute('aria-expanded',String(opening));
    toggle.textContent=opening?'نمایش کالکشن‌های کمتر':'نمایش کالکشن‌های بیشتر';
    if(opening)extra.scrollIntoView({behavior:window.BMScroll?.behavior()||(window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth'),block:'nearest'});
  };
  toggle.addEventListener('click',async()=>{
    if(busy)return;
    if(loaded){showExtra();return;}
    busy=true;toggle.disabled=true;toggle.textContent='در حال دریافت کالکشن‌های بیشتر…';setInlineLoader(toggle,true);
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),9000);
    try{
      const data=await request(new URLSearchParams({mode:'featured_collections'}),controller.signal);
      if(!Array.isArray(data.items))throw Error('outdated_api');
      const existing=new Set($$('.bm4-coll-card',root).map(a=>a.getAttribute('href')));
      const rows=data.items.filter(c=>c&&c.url&&c.title&&Number(c.count)>0&&!existing.has(c.url));
      extra.replaceChildren(...rows.map((c,i)=>featuredCollectionCard(c,i+5)));
      if(!rows.length){
        // The first five were already rendered on the server.
        toggle.textContent='همه کالکشن‌های منتخب نمایش داده شدند';
        toggle.disabled=true;return;
      }
      loaded=true;
      toggle.disabled=false;
      showExtra();
    }catch(err){
      // Never touch SSR cards. This is only the optional extra batch.
      toggle.textContent=err?.message==='outdated_api'?'API کالکشن‌ها نیاز به به‌روزرسانی دارد':'دریافت کالکشن‌ها ناموفق بود؛ تلاش دوباره';
      toggle.disabled=false;
    }finally{busy=false;setInlineLoader(toggle,false);clearTimeout(timer);}
  });
}
if(Array.isArray(window.BMDesktopDiscover.initialCollections)){
 const initial=window.BMDesktopDiscover.initialCollections.slice(0,5);
 if(initial.length){el('collection-showcase').replaceChildren(...initial.map((c,i)=>featuredCollectionCard(c,i)));el('collections-toggle').hidden=false;}
}
initFeaturedCollections();

// Eight discovery routes: real archive counts, live posters and SQL-backed result filters.
// Explorer enhancement is progressive: PHP provides meaningful cards and taxonomy.
// Each poster/count request is independent. A slow category cannot block the map or other categories.
function applyExplorerItem(c){
 const key=String(c?.key||'');const card=$$('.bm4-path-card').find(n=>n.dataset.cat===key);
 if(!card)return;
 const badge=$('.bm4-path-count',card),art=$('.bm4-path-posters',card);
 card.classList.remove('bm4-path-card--pending','bm4-path-card--loading');
 if(c.available===true){
   if(badge)badge.textContent=Number.isFinite(Number(c.count))&&c.count!==null?num(c.count)+' عنوان':'تعداد نامشخص';
   if(art){art.replaceChildren();const posters=(Array.isArray(c.posters)?c.posters:[]).filter(p=>safeImage(p.poster)).slice(0,3);
      if(posters.length)for(const poster of posters){const wrap=image(poster);wrap.classList.add('bm4-path-poster');art.append(wrap);}else art.append(make('span','bm4-path-no-poster','پوستر موجود نیست'));}
 }else{
   card.classList.add('bm4-path-card--unavailable');
   if(badge)badge.textContent='اطلاعات دسته در دسترس نیست';
 }
}
function explorerItemError(key,msg){const card=$$('.bm4-path-card').find(n=>n.dataset.cat===key);if(!card)return;
 card.classList.remove('bm4-path-card--loading','bm4-path-card--pending');card.classList.add('bm4-path-card--error');
 const badge=$('.bm4-path-count',card);if(badge)badge.textContent=msg||'اطلاعات بارگذاری نشد';
 const art=$('.bm4-path-posters',card);if(art&&!art.querySelector('.bm4-path-no-poster'))art.replaceChildren(make('span','bm4-path-no-poster','برای مرور کلیک کن'));
}
function explorerRequest(key,timeoutMs=7500){const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
 return request(new URLSearchParams({mode:'explorer_item',key}),controller.signal).finally(()=>clearTimeout(timer));
}
function enhancePathClicks(){const root=el('path-grid');if(!root)return;
 root.addEventListener('click',e=>{const card=e.target.closest('.bm4-path-card');if(!card||!root.contains(card))return;
 const key=card.dataset.cat;if(!key||key==='collections'||card.classList.contains('bm4-path-card--unavailable'))return;
 // Native link is still available if JavaScript/API is unavailable; normal clicks use exact category filter.
 if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0)return;
 e.preventDefault();state.categoryKey=key;state.seed=seed();state.page=1;
 $$('.bm4-path-card').forEach(item=>item.classList.toggle('is-active',item.dataset.cat===key));run('category',true,1);
 });
}
function enhanceTaxonomy(){for(const kind of ['genre','country']){const root=el(kind==='genre'?'map-genres':'map-countries');if(!root)return;
 root.addEventListener('click',e=>{const link=e.target.closest('[data-bm-taxonomy]');if(!link||!root.contains(link))return;
 if(e.metaKey||e.ctrlKey||e.shiftKey||e.altKey||e.button!==0)return;e.preventDefault();
 const name=link.dataset.name;if(!name)return;state.categoryKey='';$$('.bm4-fields select').forEach(sel=>sel.selectedIndex=0);
 const target=el(kind);if(!target)return;let option=Array.from(target.options).find(o=>o.value===name);
 if(!option){option=new Option(name,name);target.append(option);}target.value=name;fieldSummary();
 $$('.bm4-taxonomy-row').forEach(t=>t.classList.remove('is-active'));link.classList.add('is-active');state.seed=seed();run('sentence',true,1);
 });
 }}
// At most 2 concurrent metadata queries to keep the database responsive.
function loadExplorerIndividually(){const all=$$('.bm4-path-card');const priority=['topmovies','topseries','collections','dubbed','hidden','family','completed','continuing'];const keys=priority.filter(k=>all.some(c=>c.dataset.cat===k));
 let next=0;async function worker(){while(next<keys.length){const key=keys[next++];const card=all.find(c=>c.dataset.cat===key);card?.classList.add('bm4-path-card--loading');
   try{const data=await explorerRequest(key);if(!data||data.key!==key||!('available' in data))throw Error('outdated_api');applyExplorerItem(data);}catch(e){explorerItemError(key,e?.message==='outdated_api'?'API به‌روز نشده؛ نسخه جدید را نصب کن':e?.name==='AbortError'?'پاسخ سرور دیر رسید':'آمار در دسترس نیست');}
 }}Promise.all([worker(),worker()]).catch(()=>{});
}
enhancePathClicks();enhanceTaxonomy();
if('IntersectionObserver'in window){const lazy=new IntersectionObserver(entries=>{if(entries.some(x=>x.isIntersecting)){lazy.disconnect();loadExplorerIndividually();}},{rootMargin:'400px'});
 const target=el('explorer');if(target)lazy.observe(target);else loadExplorerIndividually();
}else loadExplorerIndividually();
if('IntersectionObserver'in window){const reveals=new IntersectionObserver(entries=>{for(const e of entries)if(e.isIntersecting){e.target.classList.add('is-visible');reveals.unobserve(e.target);}},{threshold:.08});$$('.bm4-reveal').forEach(x=>reveals.observe(x));}else{$$('.bm4-reveal').forEach(x=>x.classList.add('is-visible'));}
function attachStageDrag(){
 const stack=el('stack');if(!stack)return;
 let pointer=null,dragging=false,startX=0,startY=0,lastX=0,raf=0,from=0;
 let suppressClick=false;
 stack.addEventListener('click',e=>{
   if(!suppressClick)return;
   e.preventDefault();e.stopImmediatePropagation();suppressClick=false;
 },true);
 const apply=()=>{
   raf=0;if(!dragging)return;
   const front=stack.querySelector('.bm4-stack-card.front');if(!front)return;
   const dx=Math.max(-140,Math.min(140,lastX-startX));
   front.style.transform=`translate3d(calc(-50% + ${dx}px),-2px,0) rotate(${dx/24}deg) scale(1)`;
 };
 stack.addEventListener('pointerdown',e=>{
   if(e.button!==0||state.shiftLock||!state.items.length||!e.isPrimary)return;
   pointer=e.pointerId;dragging=false;startX=lastX=e.clientX;startY=e.clientY;from=performance.now();
 });
 stack.addEventListener('pointermove',e=>{
   if(pointer!==e.pointerId||state.shiftLock)return;
   lastX=e.clientX;const dx=lastX-startX,dy=e.clientY-startY;
   if(!dragging){
     if(Math.abs(dy)>Math.abs(dx)+8)return;
     if(Math.abs(dx)<9)return;
     dragging=true;stack.classList.add('is-dragging');
     try{stack.setPointerCapture(e.pointerId);}catch(_){}
   }
   if(!raf)raf=requestAnimationFrame(apply);
 },{passive:true});
 const end=e=>{
   if(pointer!==e.pointerId)return;
   pointer=null;cancelAnimationFrame(raf);raf=0;
   const dx=lastX-startX,elapsed=Math.max(1,performance.now()-from);
   const didDrag=dragging;dragging=false;
   stack.classList.remove('is-dragging');
   if(!didDrag)return;
   suppressClick=true;
   const accepted=Math.abs(dx)>52||(Math.abs(dx)>25&&Math.abs(dx)/elapsed>.38);
   if(accepted)shift(dx<0?1:-1);
   else{
     const front=stack.querySelector('.bm4-stack-card.front');
     if(front){front.style.removeProperty('transform');}
   }
   // A prevented click might never be dispatched following pointer capture.
   setTimeout(()=>{suppressClick=false;},350);
 };
 stack.addEventListener('pointerup',end);
 stack.addEventListener('pointercancel',e=>{
   if(pointer!==e.pointerId)return;
   pointer=null;cancelAnimationFrame(raf);raf=0;dragging=false;stack.classList.remove('is-dragging');
   stack.querySelector('.bm4-stack-card.front')?.style.removeProperty('transform');
 });
}
attachStageDrag();
// The native menu always returns to the Discover landing view, never the Explorer section.
document.addEventListener('click',event=>{
 const link=event.target.closest('a[data-bm-discover-home="1"]');
 if(!link||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
 if(!/^\/(?:discover|explore|exploare)(?:\.php)?\/?$/i.test(location.pathname))return;
 event.preventDefault();
 try{history.replaceState(null,'','/discover');}catch(_e){}
 state.decade=null;state.seed=seed();state.page=1;
 run('mood',false,1);
 const root=document.documentElement,previous=root.style.scrollBehavior;
 root.style.scrollBehavior='auto';
 window.scrollTo(0,0);
 root.scrollTop=0;
 if(document.body)document.body.scrollTop=0;
 if(previous)root.style.scrollBehavior=previous;else root.style.removeProperty('scroll-behavior');
});
// Browse decades in archive 2 through the same secure API as Discover.
document.getElementById('time-travel')?.addEventListener('click',event=>{
  const link=event.target.closest('a[data-era-from][data-era-to]');
  if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  const from=Number(link.dataset.eraFrom),to=Number(link.dataset.eraTo);
  if(!Number.isInteger(from)||!Number.isInteger(to)||from>to)return;
  event.preventDefault();state.decade={from,to};state.seed=seed();
  // Never navigate to discover_decade.php; update the current Discover URL only.
  const route=new URL(location.href);
  route.searchParams.set('year_min',String(from));
  route.searchParams.set('year_max',String(to));
  route.searchParams.delete('page');
  history.pushState({bmEra:true},'',route.pathname+route.search);
  run('decade',true,1);
});
window.addEventListener('popstate',()=>{
  state.decade=readEra();
  if(state.decade)run('decade',true,1);
  else run('mood',false,1);
});
setMood('excited',false);
if(state.decade)run('decade',true,1);else run('mood',false,1);
})();
