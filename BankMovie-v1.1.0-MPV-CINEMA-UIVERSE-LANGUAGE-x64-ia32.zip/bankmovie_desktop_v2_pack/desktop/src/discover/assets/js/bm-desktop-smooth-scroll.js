/* Local, optional mouse-wheel easing. Native trackpad, horizontal wheels, zoom,
   form controls, scrollbar dragging and touch remain untouched. */
(function(){
  'use strict';
  const KEY='bm_smooth_scroll_v1', root=document.documentElement;
  let on=true;try{const saved=localStorage.getItem(KEY);on=saved===null?!window.matchMedia('(prefers-reduced-motion: reduce)').matches:saved==='1'}catch{}
  let job=null, frame=0;
  function stop(){if(frame)cancelAnimationFrame(frame);frame=0;if(job)job.el.classList.remove('bm-wheel-active');job=null;}
  function apply(value,persist=true){on=value===true;root.dataset.bmSmoothScroll=on?'on':'off';document.removeEventListener('wheel',wheel);if(on)document.addEventListener('wheel',wheel,{passive:false});else stop();if(persist)try{localStorage.setItem(KEY,on?'1':'0')}catch{};window.dispatchEvent(new CustomEvent('bm-smooth-scroll-change',{detail:on}));}
  function scrollable(start,delta){
    const doc=document.scrollingElement;
    for(let el=start;el&&el.nodeType===1;el=el.parentElement){
      const style=getComputedStyle(el),max=el.scrollHeight-el.clientHeight;
      if(max>1&&(/^(auto|scroll|overlay)$/.test(style.overflowY)||el===doc)){
        const pos=el.scrollTop;
        if(delta>0?pos<max-1:pos>1)return el;
        if(/^(contain|none)$/.test(style.overscrollBehaviorY))return null;
      }
    }
    if(doc&&doc.scrollHeight>doc.clientHeight+1&& (delta>0?doc.scrollTop<doc.scrollHeight-doc.clientHeight-1:doc.scrollTop>1))return doc;
    return null;
  }
  function tick(now){
    frame=0;const j=job;if(!on||!j||!j.el.isConnected){stop();return}
    if(Math.abs(j.el.scrollTop-j.lastWritten)>3){stop();return} // other scrolling wins
    const max=Math.max(0,j.el.scrollHeight-j.el.clientHeight);j.target=Math.max(0,Math.min(max,j.target));
    const dt=Math.min(48,Math.max(1,now-j.time));j.time=now;
    const diff=j.target-j.el.scrollTop;
    if(Math.abs(diff)<1){j.el.scrollTop=j.target;stop();return}
    j.position+=(j.target-j.position)*(1-Math.exp(-dt/75));
    if(Math.abs(j.target-j.position)<1)j.position=j.target;
    j.el.scrollTop=j.position;j.lastWritten=j.el.scrollTop;frame=requestAnimationFrame(tick);
  }
  function wheel(e){
    if(!on||e.defaultPrevented||!e.cancelable||e.ctrlKey||e.metaKey||e.shiftKey||Math.abs(e.deltaX)>0||!e.deltaY)return;
    const start=e.target instanceof Element?e.target:e.target?.parentElement;
    if(!start||start.closest('input,textarea,select,[contenteditable],video,audio,[role="slider"],.bm-poster-dragging'))return;
    // Precision touchpads already provide small pixel deltas and momentum.
    if(e.deltaMode===0&&(Math.abs(e.deltaY)<48||!Number.isInteger(e.deltaY))){if(job)stop();return;}
    let delta=e.deltaY;if(e.deltaMode===1)delta*=40;
    const el=scrollable(start,delta);if(!el)return;
    if(e.deltaMode===2)delta*=el.clientHeight;
    e.preventDefault();
    if(job?.el!==el){stop();el.classList.add('bm-wheel-active');job={el,target:el.scrollTop,position:el.scrollTop,lastWritten:el.scrollTop,time:performance.now()};}
    job.target=Math.max(0,Math.min(el.scrollHeight-el.clientHeight,job.target+delta));
    if(!frame)frame=requestAnimationFrame(tick);
  }
  for(const name of ['pointerdown','touchstart','keydown'])document.addEventListener(name,stop,{capture:true,passive:true});
  document.addEventListener('visibilitychange',()=>{if(document.hidden)stop()});
  window.BMScroll={enabled:()=>on,setEnabled:apply,behavior:()=>on?'smooth':'auto',cancel:stop};
  apply(on,false);
})();
