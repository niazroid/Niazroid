/* From Uiverse.io by kennyotsu - https://uiverse.io/kennyotsu/fresh-lizard-20
 * MIT License, Copyright (c) kennyotsu (kotsu) */
/* Local UI only. Stage progress is driven by real startup operations, never a timer. */
(function(){
  'use strict';
  const key='bm_entry_motion_v1',root=document.documentElement;
  const preference=window.matchMedia('(prefers-reduced-motion: reduce)');
  let choice=null;
  try{const saved=localStorage.getItem(key);if(saved==='0'||saved==='1')choice=saved==='1'}catch{}
  const enabled=()=>choice===null?!preference.matches:choice;
  function sync(){root.dataset.bmEntryMotion=enabled()?'on':'off'}
  function setEnabled(value){choice=value===true;try{localStorage.setItem(key,choice?'1':'0')}catch{}sync()}
  preference.addEventListener?.('change',sync);sync();
  document.addEventListener('visibilitychange',()=>{root.dataset.bmEntryHidden=document.hidden?'1':'0'});
  const find=()=>document.querySelector('.startup-loading');
  const en=()=>root.lang==='en';
  function stage(n,fa,english){
    const screen=find();if(!screen||screen.dataset.failed==='1')return false;
    const count=Math.max(0,Math.min(4,n));
    screen.querySelector('.startup-status').textContent=en()?english:fa;
    const track=screen.querySelector('.bm-uiv-track');
    if(track){const previous=Number(track.dataset.stage||0);track.style.setProperty('--bm-uiv-prev',String(previous));track.style.setProperty('--bm-uiv-stage',String(count));track.dataset.stage=String(count);if(previous!==count){track.classList.remove('bm-uiv-spin');void track.offsetHeight;track.classList.add('bm-uiv-spin')}}
    const bar=screen.querySelector('.startup-progress');bar.setAttribute('aria-valuenow',String(count));
    bar.style.setProperty('--entry-progress',`${count*25}%`);
    screen.querySelector('.startup-step').textContent=en()?`${count} / 4`: `${count.toLocaleString('fa-IR')} / ۴`;
    return true;
  }
  function loading(text){return !!find()&&stage(3,text,text)}
  function ready(){return stage(4,'آماده نمایش','Ready')}
  function reveal(){const view=document.getElementById('view');if(!view||!enabled())return;view.classList.add('bm-entry-reveal');setTimeout(()=>view.classList.remove('bm-entry-reveal'),500)}
  function fail(){const screen=find();if(!screen)return false;screen.dataset.failed='1';screen.querySelector('.startup-status').textContent=en()?'Could not start. Try again.':'راه‌اندازی ناموفق بود. دوباره تلاش کنید.';
    const button=document.createElement('button');button.className='startup-retry';button.type='button';button.textContent=en()?'Try again':'تلاش دوباره';button.onclick=()=>window.location.reload();screen.querySelector('.startup-loading-inner').appendChild(button);return true;}
  window.BMEntry={enabled,setEnabled,stage,loading,ready,reveal,fail};
})();
