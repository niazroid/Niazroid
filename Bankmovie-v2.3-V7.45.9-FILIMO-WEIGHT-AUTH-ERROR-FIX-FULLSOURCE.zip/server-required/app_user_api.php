<?php
/**
 * app_user_api.php — API حساب کاربری و واچ‌لیست اپ BankMovie
 *
 * POST actions:
 *   login, register, logout, watchlist_sync
 * GET/POST actions:
 *   config, me, watchlist_list
 */

declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-BM-App-Key, X-BM-Ts, X-BM-Sign, X-BM-User-Token');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const BM_USER_APP_KEY = 'bm_android_v1_7c2f40';
const BM_USER_APP_SECRET = '9e1d4a7b3167f4c9b2d83f0a64e597f3d7f4b1a72638f90c6e2f2bd29d6aa8c1';

function bm_user_api_json(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_user_api_error(string $message, int $status = 400, array $extra = []): never {
    bm_user_api_json(array_merge([
        'status' => 'error',
        'success' => false,
        'message' => $message,
    ], $extra), $status);
}

/**
 * Authentication and registration validation errors intentionally travel with
 * HTTP 200. Some shared-host/edge stacks replace PHP 4xx response bodies with
 * their own HTML ErrorDocument, which made Android lose the real Persian API
 * message and show a fake connection error. `success=false` remains the API
 * contract; `http_status` preserves the semantic status for native clients.
 * Signature/protocol failures still use bm_user_api_error() and real 401s.
 */
function bm_user_api_auth_error(string $message, int $status = 400, array $extra = []): never {
    bm_user_api_json(array_merge([
        'status' => 'error',
        'success' => false,
        'message' => $message,
        'http_status' => $status,
    ], $extra), 200);
}

function bm_user_api_header(string $name): string {
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return trim((string)($_SERVER[$serverKey] ?? ''));
}

function bm_user_api_require_app_signature(): void {
    $key = bm_user_api_header('X-BM-App-Key');
    $ts = bm_user_api_header('X-BM-Ts');
    $signature = bm_user_api_header('X-BM-Sign');

    if (!hash_equals(BM_USER_APP_KEY, $key) || $ts === '' || $signature === '') {
        bm_user_api_error('Unauthorized', 401);
    }

    $timestamp = (int)$ts;
    if ($timestamp < time() - 900 || $timestamp > time() + 900) {
        bm_user_api_error('Expired request', 401);
    }

    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($requestUri, PHP_URL_PATH) ?: '');
    $query = (string)(parse_url($requestUri, PHP_URL_QUERY) ?: '');
    $pathQuery = $path . ($query !== '' ? ('?' . $query) : '');
    $expected = hash_hmac('sha256', $ts . '|' . $pathQuery, BM_USER_APP_SECRET);

    if (!hash_equals($expected, $signature)) {
        bm_user_api_error('Bad signature', 401);
    }
}

bm_user_api_require_app_signature();
require_once __DIR__ . '/config.php';
// Use the exact sticker/GIF registry already used by the website comments.
foreach (array(__DIR__ . '/includes/sticker_packs.php', __DIR__ . '/sticker_packs.php') as $bmStickerLib) {
    if (is_file($bmStickerLib)) { require_once $bmStickerLib; break; }
}

// PASS 4: Native Android Watch Party bridge. These are the exact website
// libraries, so Android and web share rooms, state, chat, stickers and voice.
foreach (array(
    __DIR__ . '/includes/vip_features.php',
    __DIR__ . '/includes/vip_sales.php',
    __DIR__ . '/includes/watch_party.php',
    __DIR__ . '/includes/watch_party_voice.php',
) as $bmWatchPartyLib) {
    if (is_file($bmWatchPartyLib)) require_once $bmWatchPartyLib;
}
bm_user_api_ensure_profile_schema($pdo);

function bm_user_api_body(): array {
    static $body = null;
    if (is_array($body)) return $body;

    $raw = file_get_contents('php://input');
    $decoded = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
    $body = is_array($decoded) ? $decoded : $_POST;
    return $body;
}

function bm_user_api_param(string $key, mixed $default = ''): mixed {
    $body = bm_user_api_body();
    if (array_key_exists($key, $body)) return $body[$key];
    if (array_key_exists($key, $_GET)) return $_GET[$key];
    return $default;
}

function bm_user_api_action(): string {
    return strtolower(trim((string)bm_user_api_param('action', $_GET['action'] ?? '')));
}

function bm_user_api_require_post(): void {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
        bm_user_api_error('POST required', 405);
    }
}

/**
 * V7.39 app login/register security challenge.
 * The answer itself is never stored server-side: the token contains a nonce,
 * expiry and HMAC generated from the displayed four-digit code. New Android
 * clients submit the token + code for validation. Legacy clients remain
 * compatible when no challenge fields are present.
 */
function bm_user_api_auth_challenge(): array {
    $code = str_pad((string)random_int(0, 9999), 4, '0', STR_PAD_LEFT);
    $nonce = bin2hex(random_bytes(12));
    $expires = time() + 300;
    $signature = hash_hmac('sha256', $nonce . '|' . $expires . '|' . $code, BM_USER_APP_SECRET);
    $payload = json_encode(['n' => $nonce, 'e' => $expires, 's' => $signature], JSON_UNESCAPED_SLASHES);
    $token = rtrim(strtr(base64_encode((string)$payload), '+/', '-_'), '=');
    return [
        'challenge_token' => $token,
        'display_code' => $code,
        'expires_in' => 300,
    ];
}

function bm_user_api_validate_auth_challenge(): void {
    $token = trim((string)bm_user_api_param('challenge_token', ''));
    $answer = trim((string)bm_user_api_param('security_code', ''));

    // Backward compatibility for already released Android builds. V7.39+
    // always sends both fields and is validated here.
    if ($token === '' && $answer === '') return;
    if ($token === '' || !preg_match('/^\d{4}$/', $answer)) {
        bm_user_api_auth_error('کد تأیید امنیتی را کامل وارد کنید', 422, ['challenge_required' => true, 'error_code' => 'SECURITY_CODE_REQUIRED']);
    }

    $padding = strlen($token) % 4;
    if ($padding) $token .= str_repeat('=', 4 - $padding);
    $decoded = base64_decode(strtr($token, '-_', '+/'), true);
    $payload = is_string($decoded) ? json_decode($decoded, true) : null;
    if (!is_array($payload)) {
        bm_user_api_auth_error('کد امنیتی معتبر نیست؛ دوباره تلاش کنید', 422, ['challenge_required' => true, 'error_code' => 'SECURITY_CODE_INVALID']);
    }
    $nonce = trim((string)($payload['n'] ?? ''));
    $expires = (int)($payload['e'] ?? 0);
    $signature = trim((string)($payload['s'] ?? ''));
    if ($nonce === '' || $signature === '' || $expires < time()) {
        bm_user_api_auth_error('کد امنیتی منقضی شده است؛ کد جدید بگیرید', 422, ['challenge_required' => true, 'challenge_expired' => true, 'error_code' => 'SECURITY_CODE_EXPIRED']);
    }
    $expected = hash_hmac('sha256', $nonce . '|' . $expires . '|' . $answer, BM_USER_APP_SECRET);
    if (!hash_equals($signature, $expected)) {
        bm_user_api_auth_error('کد تأیید امنیتی اشتباه است', 422, ['challenge_required' => true, 'error_code' => 'SECURITY_CODE_WRONG']);
    }
}

function bm_user_api_bearer(): string {
    $direct = bm_user_api_header('X-BM-User-Token');
    if ($direct !== '') return $direct;
    $authorization = bm_user_api_header('Authorization');
    if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) {
        return trim((string)$m[1]);
    }
    return trim((string)bm_user_api_param('token', ''));
}

function bm_user_api_current_user(PDO $pdo, bool $required = true): array|false {
    $token = bm_user_api_bearer();
    $user = (new User($pdo))->checkSession($token);
    if (!$user && $required) bm_user_api_error('Please login', 401);
    return $user ?: false;
}

function bm_user_api_avatar_catalog(): array {
    $rows = [
        ['male_01','کای','male'], ['male_02','رن','male'], ['male_03','آکیرا','male'],
        ['male_04','هارو','male'], ['male_05','ریو','male'], ['male_06','کِن','male'],
        ['female_01','یونا','female'], ['female_02','میکا','female'], ['female_03','آی','female'],
        ['female_04','رین','female'], ['female_05','سورا','female'], ['female_06','هانا','female'],
        ['neon_01','نئون بنفش','special'], ['neon_02','نئون آبی','special'],
        ['neon_03','نئون قرمز','special'], ['neon_04','سایبر طلایی','special'],
    ];
    $items = [];
    foreach ($rows as $row) {
        $items[] = [
            'key' => $row[0],
            'label' => $row[1],
            'gender' => $row[2],
            'url' => rtrim((string)SITE_URL, '/') . '/assets/avatars/' . $row[0] . '.webp',
        ];
    }
    return $items;
}

function bm_user_api_remote_config(): array {
    static $config = null;
    if (is_array($config)) return $config;
    $file = __DIR__ . '/bankmovie_remote_config.json';
    $raw = is_file($file) ? @file_get_contents($file) : '';
    $decoded = is_string($raw) && $raw !== '' ? json_decode($raw, true) : null;
    return $config = is_array($decoded) ? $decoded : [];
}

function bm_user_api_features(): array {
    $config = bm_user_api_remote_config();
    $features = is_array($config['features'] ?? null) ? $config['features'] : [];
    $archives = is_array($features['archives'] ?? null) ? $features['archives'] : [];
    $downloads = is_array($config['downloads'] ?? null) ? $config['downloads'] : [];
    $comments = is_array($config['comments'] ?? null) ? $config['comments'] : [];
    return [
        'registration_enabled' => array_key_exists('registration_enabled', $features) ? (bool)$features['registration_enabled'] : true,
        'login_enabled' => array_key_exists('login_enabled', $features) ? (bool)$features['login_enabled'] : true,
        'comments_enabled' => array_key_exists('comments_enabled', $features) ? (bool)$features['comments_enabled'] : true,
        'comment_replies_enabled' => array_key_exists('comment_replies_enabled', $features) ? (bool)$features['comment_replies_enabled'] : true,
        'comment_votes_enabled' => array_key_exists('comment_votes_enabled', $features) ? (bool)$features['comment_votes_enabled'] : true,
        'comment_reports_enabled' => array_key_exists('comment_reports_enabled', $features) ? (bool)$features['comment_reports_enabled'] : true,
        'comment_spoiler_enabled' => array_key_exists('comment_spoiler_enabled', $features) ? (bool)$features['comment_spoiler_enabled'] : true,
        'comment_edit_minutes' => max(0, min(1440, (int)($comments['edit_minutes'] ?? $features['comment_edit_minutes'] ?? 10))),
        'comment_rate_count' => max(1, min(30, (int)($comments['rate_count'] ?? 3))),
        'comment_rate_minutes' => max(1, min(1440, (int)($comments['rate_minutes'] ?? 10))),
        'comment_auto_approve_admin' => array_key_exists('auto_approve_admin',$comments) ? (bool)$comments['auto_approve_admin'] : true,
        'comment_auto_approve_vip' => array_key_exists('auto_approve_vip',$comments) ? (bool)$comments['auto_approve_vip'] : true,
        'login_poster_url' => trim((string)($features['login_poster_url'] ?? '')),
        'download_limit' => max(1, min(4, (int)($downloads['concurrent_limit'] ?? $features['download_limit'] ?? 2))),
        'download_retry_count' => max(0, min(12, (int)($downloads['retry_count'] ?? 4))),
        'download_retry_delay_seconds' => max(2, min(300, (int)($downloads['retry_delay_seconds'] ?? 8))),
        'download_min_free_mb' => max(32, min(8192, (int)($downloads['min_free_mb'] ?? 256))),
        'multipart_parts' => max(2, min(6, (int)($downloads['multipart_parts'] ?? 4))),
        'internal_downloader_enabled' => array_key_exists('internal_downloader_enabled', $features) ? (bool)$features['internal_downloader_enabled'] : true,
        'multipart_download_enabled' => array_key_exists('multipart_download_enabled', $features) ? (bool)$features['multipart_download_enabled'] : true,
        'download_path_selection_enabled' => array_key_exists('download_path_selection_enabled', $features) ? (bool)$features['download_path_selection_enabled'] : true,
        'advanced_search_enabled' => array_key_exists('advanced_search_enabled', $features) ? (bool)$features['advanced_search_enabled'] : true,
        'categories_enabled' => array_key_exists('categories_enabled', $features) ? (bool)$features['categories_enabled'] : true,
        'watchlist_enabled' => array_key_exists('watchlist_enabled', $features) ? (bool)$features['watchlist_enabled'] : true,
        'continue_watching_enabled' => array_key_exists('continue_watching_enabled', $features) ? (bool)$features['continue_watching_enabled'] : true,
        'tv_quick_menu_enabled' => array_key_exists('tv_quick_menu_enabled', $features) ? (bool)$features['tv_quick_menu_enabled'] : true,
        'profile_cleanup_enabled' => array_key_exists('profile_cleanup_enabled', $features) ? (bool)$features['profile_cleanup_enabled'] : true,
        'tv_detail_story_enabled' => array_key_exists('tv_detail_story_enabled', $features) ? (bool)$features['tv_detail_story_enabled'] : true,
        'tv_detail_more_info_enabled' => array_key_exists('tv_detail_more_info_enabled', $features) ? (bool)$features['tv_detail_more_info_enabled'] : true,
        'external_player_fallback_enabled' => array_key_exists('external_player_fallback_enabled', $features) ? (bool)$features['external_player_fallback_enabled'] : true,
        'search_auto_page_limit' => max(1, min(10, (int)($features['search_auto_page_limit'] ?? 10))),
        'notification_center_enabled' => array_key_exists('notification_center_enabled', $features) ? (bool)$features['notification_center_enabled'] : true,
        'archive1_enabled' => array_key_exists('archive1_enabled', $archives) ? (bool)$archives['archive1_enabled'] : true,
        'archive2_enabled' => array_key_exists('archive2_enabled', $archives) ? (bool)$archives['archive2_enabled'] : true,
        'archive3_enabled' => array_key_exists('archive3_enabled', $archives) ? (bool)$archives['archive3_enabled'] : true,
        'archive1_hidden' => array_key_exists('archive1_hidden', $archives) ? (bool)$archives['archive1_hidden'] : false,
        'archive2_hidden' => array_key_exists('archive2_hidden', $archives) ? (bool)$archives['archive2_hidden'] : false,
        'archive3_hidden' => array_key_exists('archive3_hidden', $archives) ? (bool)$archives['archive3_hidden'] : false,
        'archive1_download_vip' => !empty($archives['archive1_download_vip']),
        'archive1_stream_vip' => !empty($archives['archive1_stream_vip']),
        'archive2_download_vip' => !empty($archives['archive2_download_vip']),
        'archive2_stream_vip' => !empty($archives['archive2_stream_vip']),
        'archive3_download_vip' => !empty($archives['archive3_download_vip']),
        'archive3_stream_vip' => !empty($archives['archive3_stream_vip']),
    ];
}

function bm_user_api_feature_enabled(string $key, bool $default = true): bool {
    $features = bm_user_api_features();
    return array_key_exists($key, $features) ? (bool)$features[$key] : $default;
}

function bm_user_api_ensure_notification_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_notifications (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(32) NOT NULL DEFAULT 'system',
        title VARCHAR(220) NOT NULL DEFAULT '',
        message TEXT NOT NULL,
        target_json MEDIUMTEXT NULL,
        dedupe_key VARCHAR(190) NULL,
        read_at DATETIME NULL,
        is_read TINYINT(1) NOT NULL DEFAULT 0,
        dismissed_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_dedupe (user_id, dedupe_key),
        KEY idx_user_read_created (user_id, read_at, created_at),
        KEY idx_type_created (type, created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // Compatibility upgrade for installations where an older helper created this table.
    $notificationColumns = bm_user_api_table_columns($pdo, 'app_notifications');
    $notificationAlter = [];
    if (!in_array('dedupe_key', $notificationColumns, true)) $notificationAlter[] = "ADD COLUMN dedupe_key VARCHAR(190) NULL AFTER target_json";
    if (!in_array('read_at', $notificationColumns, true)) $notificationAlter[] = "ADD COLUMN read_at DATETIME NULL AFTER dedupe_key";
    if (!in_array('is_read', $notificationColumns, true)) $notificationAlter[] = "ADD COLUMN is_read TINYINT(1) NOT NULL DEFAULT 0 AFTER read_at";
    if (!in_array('dismissed_at', $notificationColumns, true)) $notificationAlter[] = "ADD COLUMN dismissed_at DATETIME NULL AFTER is_read";
    if ($notificationAlter) {
        try { $pdo->exec("ALTER TABLE app_notifications " . implode(', ', $notificationAlter)); }
        catch (Throwable $e) { error_log('app_notifications alter: ' . $e->getMessage()); }
    }
    try { $pdo->exec("CREATE UNIQUE INDEX uq_user_dedupe ON app_notifications (user_id,dedupe_key)"); } catch (Throwable $e) {}
    try { $pdo->exec("CREATE INDEX idx_user_read_created ON app_notifications (user_id,read_at,created_at)"); } catch (Throwable $e) {}
    try { $pdo->exec("CREATE INDEX idx_user_dismissed_created ON app_notifications (user_id,dismissed_at,created_at)"); } catch (Throwable $e) {}
    try { $pdo->exec("UPDATE app_notifications SET read_at=COALESCE(read_at,IF(is_read=1,created_at,NULL)) WHERE is_read=1"); } catch (Throwable $e) {}

    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_reports (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        movie_id BIGINT UNSIGNED NOT NULL,
        comment_id BIGINT UNSIGNED NOT NULL,
        reporter_user_id INT UNSIGNED NOT NULL,
        reason VARCHAR(60) NOT NULL,
        details VARCHAR(500) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_reporter (archive_no, comment_id, reporter_user_id),
        KEY idx_status_created (status, created_at),
        KEY idx_movie_comment (movie_id, comment_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bm_user_api_notify(PDO $pdo, int $userId, string $type, string $title, string $message, array $target = [], string $dedupe = ''): void {
    if ($userId <= 0 || trim($message) === '') return;
    bm_user_api_ensure_notification_schema($pdo);
    $stmt = $pdo->prepare("INSERT INTO app_notifications(user_id,type,title,message,target_json,dedupe_key,created_at)
        VALUES(?,?,?,?,?,?,NOW()) ON DUPLICATE KEY UPDATE title=VALUES(title),message=VALUES(message),target_json=VALUES(target_json)");
    $stmt->execute([$userId, substr($type,0,32), substr($title,0,220), $message, json_encode($target, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), $dedupe !== '' ? substr($dedupe,0,190) : null]);
}

function bm_user_api_sync_remote_notifications(PDO $pdo, int $userId): void {
    $config = bm_user_api_remote_config();
    $notice = is_array($config['notice'] ?? null) ? $config['notice'] : [];
    if (!empty($notice['enabled']) && trim((string)($notice['message'] ?? '')) !== '') {
        $id = trim((string)($notice['id'] ?? ''));
        if ($id === '') $id = sha1((string)$notice['message']);
        bm_user_api_notify($pdo, $userId, (string)($notice['type'] ?? 'admin'), trim((string)($notice['title'] ?? 'پیام مدیریت')), trim((string)$notice['message']), is_array($notice['target'] ?? null) ? $notice['target'] : [], 'notice:' . $id);
    }
    $update = is_array($config['update'] ?? null) ? $config['update'] : [];
    if (!empty($update['enabled']) && trim((string)($update['version_name'] ?? '')) !== '') {
        $version = trim((string)$update['version_name']);
        bm_user_api_notify($pdo, $userId, 'update', trim((string)($update['title'] ?? 'آپدیت جدید')), trim((string)($update['message'] ?? 'نسخه جدید آماده است')), ['version_name'=>$version,'apk_url'=>(string)($update['apk_url'] ?? '')], 'update:' . $version);
    }
}

function bm_user_api_sync_global_admin_notifications(PDO $pdo, int $userId): void {
    if ($userId <= 0) return;
    try {
        $exists = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
        $exists->execute(['notifications']);
        if (!$exists->fetchColumn()) return;
        $columns = bm_user_api_table_columns($pdo, 'notifications');
        $select = ['id', 'message', 'created_at'];
        foreach (['title','link','image','expires_at','is_active'] as $column) {
            if (in_array($column, $columns, true)) $select[] = $column;
        }
        $where = [];
        if (in_array('is_active', $columns, true)) $where[] = 'is_active=1';
        if (in_array('expires_at', $columns, true)) $where[] = '(expires_at IS NULL OR expires_at>NOW())';
        $sql = 'SELECT ' . implode(',', array_unique($select)) . ' FROM notifications';
        if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
        $sql .= ' ORDER BY id DESC LIMIT 30';
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as $row) {
            $id = (int)($row['id'] ?? 0);
            $message = trim((string)($row['message'] ?? ''));
            if ($id <= 0 || $message === '') continue;
            $target = [];
            $link = trim((string)($row['link'] ?? ''));
            if ($link !== '') $target['url'] = $link;
            $image = trim((string)($row['image'] ?? ''));
            if ($image !== '') $target['image'] = $image;
            bm_user_api_notify(
                $pdo,
                $userId,
                'admin',
                trim((string)($row['title'] ?? '')) ?: 'پیام مدیریت بانک مووی',
                $message,
                $target,
                'global-admin:' . $id
            );
        }
    } catch (Throwable $e) {
        error_log('sync global notifications: ' . $e->getMessage());
    }
}

function bm_user_api_ensure_profile_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM users")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $cols = array_values(array_filter(array_map(static fn($row) => (string)($row['Field'] ?? ''), $rows)));
        if (!in_array('avatar', $cols, true)) {
            $pdo->exec("ALTER TABLE users ADD COLUMN avatar VARCHAR(500) NULL");
            $cols[] = 'avatar';
        }
        if (!in_array('avatar_key', $cols, true)) $pdo->exec("ALTER TABLE users ADD COLUMN avatar_key VARCHAR(40) NULL AFTER avatar");
    } catch (Throwable $e) {
        error_log('app_user_api profile schema: ' . $e->getMessage());
    }
}

function bm_user_api_is_vip(array $user): bool {
    $role = strtolower(trim((string)($user['role'] ?? 'user')));
    if (in_array($role, ['admin','administrator'], true)) return true;
    if (!in_array($role, ['vip','premium','special'], true)) return false;
    $expiry = trim((string)($user['vip_expires_at'] ?? ''));
    if ($expiry === '') return true;
    $ts = strtotime($expiry);
    return $ts !== false && $ts > time();
}

function bm_user_api_is_custom_avatar(string $value): bool {
    $value = ltrim(str_replace('\\', '/', trim($value)), '/');
    return $value !== '' && !str_contains($value, '..') &&
        (bool)preg_match('~^uploads/avatars/[A-Za-z0-9._/-]+\.(?:webp|png|jpe?g|gif)$~i', $value);
}

function bm_user_api_avatar_url(string $key, string $fallback = ''): string {
    $fallback = trim($fallback);
    // A custom VIP upload from the website/app is authoritative even when an
    // older avatar_key is still present in the row. This keeps Android and web in sync.
    if ($fallback !== '' && (bm_user_api_is_custom_avatar($fallback) || preg_match('~^https?://.+/uploads/avatars/~i', $fallback))) {
        return preg_match('~^https?://~i', $fallback) ? $fallback : rtrim((string)SITE_URL, '/') . '/' . ltrim($fallback, '/');
    }
    $allowed = array_column(bm_user_api_avatar_catalog(), 'key');
    if ($key !== '' && in_array($key, $allowed, true)) {
        return rtrim((string)SITE_URL, '/') . '/assets/avatars/' . $key . '.webp';
    }
    if ($fallback !== '' && !preg_match('~^https?://~i', $fallback)) $fallback = rtrim((string)SITE_URL, '/') . '/' . ltrim($fallback, '/');
    return $fallback;
}

function bm_user_api_public_user(array $user): array {
    $avatarKey = trim((string)($user['avatar_key'] ?? ''));
    $isVip = bm_user_api_is_vip($user);
    $role = strtolower(trim((string)($user['role'] ?? 'user')));
    $vipExpiry = trim((string)($user['vip_expires_at'] ?? ''));
    $vipLifetime = $isVip && ($vipExpiry === '' || in_array($role, ['admin','administrator'], true));
    $vipRemainingDays = null;
    if ($isVip && !$vipLifetime && $vipExpiry !== '') {
        $vipTs = strtotime($vipExpiry);
        if ($vipTs !== false && $vipTs > time()) {
            $vipRemainingDays = max(1, (int)ceil(($vipTs - time()) / 86400));
        }
    }
    $avatarFallback = (string)($user['avatar'] ?? '');
    // Match website behavior: retain an expired member's uploaded file for a
    // later renewal, but do not expose it as active while VIP is inactive.
    if (!$isVip && bm_user_api_is_custom_avatar($avatarFallback)) $avatarFallback = '';
    $avatar = bm_user_api_avatar_url($avatarKey, $avatarFallback);
    return [
        'id' => (int)($user['id'] ?? 0),
        'username' => (string)($user['username'] ?? ''),
        'email' => (string)($user['email'] ?? ''),
        'full_name' => (string)($user['full_name'] ?? ''),
        'avatar' => $avatar,
        'avatar_key' => $avatarKey,
        'role' => (string)($user['role'] ?? 'user'),
        'is_vip' => $isVip,
        'vip_expires_at' => $vipExpiry !== '' ? $vipExpiry : null,
        'vip_lifetime' => $vipLifetime,
        'vip_remaining_days' => $vipRemainingDays,
        'can_upload_avatar' => $isVip,
        'status' => (string)($user['status'] ?? 'active'),
        'theme' => (string)($user['theme'] ?? 'dark-green'),
        'language' => (string)($user['language'] ?? 'fa'),
        'created_at' => (string)($user['created_at'] ?? ''),
    ];
}

function bm_user_api_issue_token(PDO $pdo, int $userId): string {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 30 * 86400);
    $stmt = $pdo->prepare('INSERT INTO user_sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $token, $expires]);
    return $token;
}

function bm_user_api_ensure_watchlist(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        storage_key VARCHAR(190) NOT NULL,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        item_type VARCHAR(24) NOT NULL DEFAULT 'movie',
        item_id VARCHAR(190) NOT NULL DEFAULT '',
        db_movie_id INT UNSIGNED NULL,
        imdb_code VARCHAR(32) NULL,
        title VARCHAR(300) NOT NULL DEFAULT '',
        title_fa VARCHAR(300) NOT NULL DEFAULT '',
        poster VARCHAR(700) NULL,
        year_value VARCHAR(16) NULL,
        rating_value DECIMAL(4,1) NULL,
        source_url VARCHAR(700) NULL,
        payload_json MEDIUMTEXT NULL,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_app_watchlist_user_key (user_id, storage_key),
        KEY idx_app_watchlist_user_added (user_id, added_at),
        KEY idx_app_watchlist_db_movie (db_movie_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        item_link VARCHAR(500) NOT NULL,
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_link (user_id, item_link(200)),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function bm_user_api_normalize_type(string $type): string {
    $type = strtolower(trim($type));
    if (in_array($type, ['tv', 'tvseries'], true)) return 'series';
    if ($type === '') return 'movie';
    return substr($type, 0, 24);
}

function bm_user_api_abs_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';
    if (str_starts_with($value, '//')) return 'https:' . $value;
    if (preg_match('~^https?://~i', $value)) return $value;
    return rtrim((string)SITE_URL, '/') . '/' . ltrim($value, '/');
}

function bm_user_api_item_source(array $item): string {
    return strtolower(trim((string)($item['source'] ?? $item['source_type'] ?? '')));
}

function bm_user_api_is_database_item(array $item): bool {
    $source = bm_user_api_item_source($item);
    if (in_array($source, ['db_movies','database','local_db','collection','website_db'], true)) return true;
    if ((int)($item['db_id'] ?? 0) > 0) return true;
    $apiDetail = strtolower((string)($item['api_detail'] ?? ''));
    return str_contains($apiDetail, 'app_api.php') && str_contains($apiDetail, 'archive=2');
}

function bm_user_api_is_serialblog_item(array $item): bool {
    $source = bm_user_api_item_source($item);
    return in_array($source, ['serialblog','archive2','sb'], true) || ((int)($item['archive'] ?? 0) === 2 && !bm_user_api_is_database_item($item));
}

function bm_user_api_storage_key(array $item): string {
    $key = trim((string)($item['_key'] ?? $item['storage_key'] ?? ''));
    if ($key !== '') return substr($key, 0, 190);

    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $id = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? $item['imdb_code'] ?? ''));
    if ($id === '') {
        $id = substr(hash('sha256', (string)($item['title_fa'] ?? '') . '|' . (string)($item['title'] ?? '') . '|' . (string)($item['poster'] ?? '')), 0, 40);
    }
    return substr($archive . '|' . $type . '|' . $id, 0, 190);
}

function bm_user_api_legacy_archive1_link(array $item): string {
    foreach (['web_url_abs', 'source_url', 'item_link', 'web_url'] as $field) {
        $value = trim((string)($item[$field] ?? ''));
        if ($value !== '') return bm_user_api_abs_url($value);
    }
    $id = trim((string)($item['id'] ?? $item['slug'] ?? ''));
    if ($id === '') return '';
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    return rtrim((string)SITE_URL, '/') . '/movie.php?arc=1&slug=' . rawurlencode($id) . '&type=' . rawurlencode($type);
}

function bm_user_api_upsert_app_item(PDO $pdo, int $userId, array $item): void {
    $storageKey = bm_user_api_storage_key($item);
    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $itemId = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? ''));
    $isDatabaseItem = bm_user_api_is_database_item($item);
    $dbMovieId = $isDatabaseItem ? (int)($item['db_id'] ?? (ctype_digit($itemId) ? $itemId : 0)) : 0;
    $imdb = trim((string)($item['imdb_code'] ?? ''));
    $title = trim((string)($item['title'] ?? ''));
    $titleFa = trim((string)($item['title_fa'] ?? $title));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $poster = bm_user_api_abs_url((string)($item['poster'] ?? ''));
    $year = trim((string)($item['year'] ?? ''));
    $ratingRaw = $item['rating'] ?? null;
    $rating = is_numeric($ratingRaw) ? (float)$ratingRaw : null;
    $sourceUrl = bm_user_api_abs_url((string)($item['source_url'] ?? $item['web_url_abs'] ?? $item['web_url'] ?? ''));
    $payload = $item;
    $payload['_key'] = $storageKey;
    $payload['archive'] = $archive;
    $payload['type'] = $type;
    $payload['id'] = $itemId;
    $payload['poster'] = $poster;
    if ($sourceUrl !== '') $payload['source_url'] = $sourceUrl;

    $stmt = $pdo->prepare("INSERT INTO app_watchlist
        (user_id, storage_key, archive_no, item_type, item_id, db_movie_id, imdb_code, title, title_fa, poster, year_value, rating_value, source_url, payload_json, added_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NULLIF(?,0), NULLIF(?,''), ?, ?, NULLIF(?,''), NULLIF(?,''), ?, NULLIF(?,''), ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            archive_no=VALUES(archive_no), item_type=VALUES(item_type), item_id=VALUES(item_id),
            db_movie_id=VALUES(db_movie_id), imdb_code=VALUES(imdb_code), title=VALUES(title), title_fa=VALUES(title_fa),
            poster=VALUES(poster), year_value=VALUES(year_value), rating_value=VALUES(rating_value),
            source_url=VALUES(source_url), payload_json=VALUES(payload_json), updated_at=NOW()");
    $stmt->execute([
        $userId, $storageKey, $archive, $type, $itemId, $dbMovieId, $imdb, $title, $titleFa,
        $poster, $year, $rating, $sourceUrl,
        json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);

    // Mirror app changes to the website's existing watchlist tables.
    if ($isDatabaseItem && $dbMovieId > 0) {
        $check = $pdo->prepare('SELECT id FROM movies WHERE id = ? LIMIT 1');
        $check->execute([$dbMovieId]);
        if ($check->fetchColumn()) {
            $mirror = $pdo->prepare('INSERT IGNORE INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, NOW())');
            $mirror->execute([$userId, $dbMovieId]);
        }
    } elseif ($archive === 1) {
        $link = bm_user_api_legacy_archive1_link($item);
        if ($link !== '') {
            $mirror = $pdo->prepare("INSERT INTO archive1_watchlist
                (user_id, item_link, item_title, item_title_fa, item_year, item_poster, item_imdb_rate, item_type, added_at)
                VALUES (?, ?, ?, ?, NULLIF(?,''), NULLIF(?,''), ?, ?, NOW())
                ON DUPLICATE KEY UPDATE item_title=VALUES(item_title), item_title_fa=VALUES(item_title_fa),
                    item_year=VALUES(item_year), item_poster=VALUES(item_poster), item_imdb_rate=VALUES(item_imdb_rate), item_type=VALUES(item_type)");
            $mirror->execute([$userId, $link, $title, $titleFa, $year, $poster, $rating, $type]);
        }
    }
}

function bm_user_api_remove_app_item(PDO $pdo, int $userId, string $storageKey): void {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? AND storage_key = ? LIMIT 1');
    $stmt->execute([$userId, $storageKey]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $delete = $pdo->prepare('DELETE FROM app_watchlist WHERE user_id = ? AND storage_key = ?');
    $delete->execute([$userId, $storageKey]);

    if (!$row) return;
    $archive = (int)($row['archive_no'] ?? 0);
    if ($archive === 2 && (int)($row['db_movie_id'] ?? 0) > 0) {
        $mirror = $pdo->prepare('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?');
        $mirror->execute([$userId, (int)$row['db_movie_id']]);
    } elseif ($archive === 1) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        $link = is_array($payload) ? bm_user_api_legacy_archive1_link($payload) : trim((string)($row['source_url'] ?? ''));
        if ($link !== '') {
            $mirror = $pdo->prepare('DELETE FROM archive1_watchlist WHERE user_id = ? AND item_link = ?');
            $mirror->execute([$userId, $link]);
        }
    }
}

function bm_user_api_import_legacy(PDO $pdo, int $userId): void {
    // Database/archive 2 watchlist.
    try {
        $stmt = $pdo->prepare('SELECT m.* FROM watchlist w JOIN movies m ON w.movie_id = m.id WHERE w.user_id = ? ORDER BY w.added_at ASC');
        $stmt->execute([$userId]);
        while ($movie = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $id = (string)(int)($movie['id'] ?? 0);
            if ($id === '0') continue;
            $imdb = trim((string)($movie['imdb_code'] ?? ''));
            $poster = trim((string)($movie['poster'] ?? ''));
            if ($poster === '' && $imdb !== '') $poster = 'posters/' . $imdb . '.webp';
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '2|' . bm_user_api_normalize_type((string)($movie['type'] ?? 'movie')) . '|' . $id,
                'archive' => 2,
                'source' => 'db_movies',
                'id' => $id,
                'db_id' => (int)$id,
                'imdb_code' => $imdb,
                'type' => (string)($movie['type'] ?? 'movie'),
                'title' => (string)($movie['title'] ?? ''),
                'title_fa' => (string)($movie['title_fa'] ?? $movie['title'] ?? ''),
                'poster' => $poster,
                'year' => (string)($movie['year'] ?? ''),
                'rating' => $movie['imdb_rate'] ?? null,
                'source_url' => (string)($movie['source_url'] ?? ''),
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy db watchlist import: ' . $e->getMessage());
    }

    // Archive 1 website watchlist.
    try {
        $stmt = $pdo->prepare('SELECT * FROM archive1_watchlist WHERE user_id = ? ORDER BY added_at ASC');
        $stmt->execute([$userId]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $link = trim((string)($row['item_link'] ?? ''));
            if ($link === '') continue;
            $id = '';
            $parts = parse_url($link);
            if (!empty($parts['query'])) {
                parse_str((string)$parts['query'], $query);
                $id = trim((string)($query['slug'] ?? $query['id'] ?? ''));
            }
            if ($id === '' && preg_match('~/movie/arc1-([^/?#]+)~i', $link, $m)) $id = rawurldecode($m[1]);
            if ($id === '') {
                $path = trim((string)($parts['path'] ?? ''), '/');
                if ($path !== '') $id = rawurldecode((string)basename($path));
            }
            if ($id === '') $id = substr(hash('sha256', $link), 0, 32);
            $type = bm_user_api_normalize_type((string)($row['item_type'] ?? 'movie'));
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '1|' . $type . '|' . $id,
                'archive' => 1,
                'id' => $id,
                'type' => $type,
                'title' => (string)($row['item_title'] ?? ''),
                'title_fa' => (string)($row['item_title_fa'] ?? $row['item_title'] ?? ''),
                'poster' => (string)($row['item_poster'] ?? ''),
                'year' => (string)($row['item_year'] ?? ''),
                'rating' => $row['item_imdb_rate'] ?? null,
                'source_url' => $link,
                'web_url_abs' => $link,
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy archive1 watchlist import: ' . $e->getMessage());
    }
}

function bm_user_api_watchlist_items(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 500');
    $stmt->execute([$userId]);
    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        if (!is_array($payload)) $payload = [];
        $payload['_key'] = (string)$row['storage_key'];
        $payload['archive'] = (int)$row['archive_no'];
        $payload['type'] = (string)$row['item_type'];
        $payload['id'] = (string)$row['item_id'];
        if (!empty($row['db_movie_id'])) {
            $payload['db_id'] = (int)$row['db_movie_id'];
            $payload['source'] = 'db_movies';
        }
        if (!empty($row['imdb_code'])) $payload['imdb_code'] = (string)$row['imdb_code'];
        $payload['title'] = (string)$row['title'];
        $payload['title_fa'] = (string)$row['title_fa'];
        $payload['poster'] = (string)($row['poster'] ?? '');
        $payload['year'] = (string)($row['year_value'] ?? '');
        if ($row['rating_value'] !== null) $payload['rating'] = (float)$row['rating_value'];
        if (!empty($row['source_url'])) $payload['source_url'] = (string)$row['source_url'];
        $payload['_saved_at'] = strtotime((string)$row['updated_at']) * 1000;
        $items[] = $payload;
    }
    return $items;
}

function bm_user_api_table_columns(PDO $pdo, string $table): array {
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($safe === '') return [];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `{$safe}`")->fetchAll(PDO::FETCH_ASSOC) ?: [];
        return $cache[$table] = array_values(array_filter(array_map(static fn($r) => (string)($r['Field'] ?? ''), $rows)));
    } catch (Throwable $e) {
        return $cache[$table] = [];
    }
}

function bm_user_api_first_column(array $columns, array $candidates): string {
    foreach ($candidates as $candidate) if (in_array($candidate, $columns, true)) return $candidate;
    return '';
}

function bm_user_api_ensure_comment_schema(PDO $pdo): void {
    static $done = false;
    if ($done) return;
    $done = true;
    bm_user_api_ensure_profile_schema($pdo);
    bm_user_api_ensure_notification_schema($pdo);
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        comment TEXT NOT NULL,
        rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
        spoiler TINYINT(1) NOT NULL DEFAULT 0,
        parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        is_pinned TINYINT(1) NOT NULL DEFAULT 0,
        pinned_at DATETIME NULL,
        edited_at DATETIME NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_movie_parent_status (movie_id, parent_id, status),
        KEY idx_movie_pin_created (movie_id, is_pinned, created_at),
        KEY idx_user_status (user_id, status), KEY idx_parent (parent_id), KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id), KEY idx_comment_type (comment_id, type), KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id), KEY idx_comment_type (comment_id, type), KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_edit_history (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        comment_id BIGINT UNSIGNED NOT NULL,
        editor_user_id INT UNSIGNED NOT NULL,
        old_comment TEXT NOT NULL,
        old_spoiler TINYINT(1) NOT NULL DEFAULT 0,
        edited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_comment (archive_no, comment_id, edited_at),
        KEY idx_editor (editor_user_id, edited_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    // Upgrade both old and new installations without deleting existing comments.
    foreach (['comments','archive1_comments'] as $table) {
        if (!bm_user_api_table_columns($pdo, $table)) continue;
        $columns = bm_user_api_table_columns($pdo, $table);
        $alter = [];
        if (!in_array('is_pinned', $columns, true)) $alter[] = "ADD COLUMN is_pinned TINYINT(1) NOT NULL DEFAULT 0 AFTER status";
        if (!in_array('pinned_at', $columns, true)) $alter[] = "ADD COLUMN pinned_at DATETIME NULL AFTER is_pinned";
        if (!in_array('edited_at', $columns, true)) $alter[] = "ADD COLUMN edited_at DATETIME NULL AFTER pinned_at";
        if ($alter) {
            try { $pdo->exec("ALTER TABLE `{$table}` " . implode(', ', $alter)); }
            catch (Throwable $e) { error_log('comment schema alter ' . $table . ': ' . $e->getMessage()); }
        }
        try { $pdo->exec("CREATE INDEX idx_{$table}_movie_pin_created ON `{$table}` (movie_id,is_pinned,created_at)"); } catch (Throwable $e) {}
    }
}

function bm_user_api_comment_item(): array {
    $item = bm_user_api_param('item', []);
    return is_array($item) ? $item : [];
}

function bm_user_api_resolve_db_movie_id(PDO $pdo, array $item): int {
    $cols = bm_user_api_table_columns($pdo, 'movies');
    if (!$cols) return 0;
    $idCol = bm_user_api_first_column($cols, ['id','movie_id']);
    if ($idCol === '') return 0;

    foreach (['db_id','movie_id','id'] as $key) {
        $value = trim((string)($item[$key] ?? ''));
        if ($value !== '' && ctype_digit($value)) {
            try {
                $stmt = $pdo->prepare("SELECT `{$idCol}` FROM movies WHERE `{$idCol}` = ? LIMIT 1");
                $stmt->execute([(int)$value]);
                $id = (int)($stmt->fetchColumn() ?: 0);
                if ($id > 0) return $id;
            } catch (Throwable $e) {}
        }
    }

    $where = []; $params = [];
    $imdb = trim((string)($item['imdb_code'] ?? $item['imdb'] ?? $item['imdb_id'] ?? ''));
    if ($imdb !== '') {
        foreach (['imdb_code','imdb','imdb_id'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$imdb; }
    }
    $slug = trim((string)($item['slug'] ?? $item['source_slug'] ?? ''));
    if ($slug !== '') {
        foreach (['slug','source_slug','detail_id'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$slug; }
    }
    $title = trim((string)($item['title'] ?? ''));
    if ($title !== '') {
        foreach (['title','title_en','original_title','name','english_title'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$title; }
    }
    $titleFa = trim((string)($item['title_fa'] ?? ''));
    if ($titleFa !== '') {
        foreach (['title_fa','fa_title','persian_title'] as $col) if (in_array($col,$cols,true)) { $where[]="`{$col}` = ?"; $params[]=$titleFa; }
    }
    if (!$where) return 0;
    try {
        $stmt = $pdo->prepare("SELECT `{$idCol}` FROM movies WHERE " . implode(' OR ', $where) . " ORDER BY `{$idCol}` ASC LIMIT 1");
        $stmt->execute($params);
        return (int)($stmt->fetchColumn() ?: 0);
    } catch (Throwable $e) {
        error_log('app_user_api resolve movie: ' . $e->getMessage());
        return 0;
    }
}

function bm_user_api_external_comment_identity(array $item): string {
    foreach (['source_slug','slug','detail_id'] as $key) {
        $value = trim((string)($item[$key] ?? ''));
        if ($value !== '') {
            $value = rawurldecode(trim($value, "/ \t"));
            $value = preg_replace('~^arc[134]-~i', '', $value);
            if ($value !== '') return $value;
        }
    }
    foreach (['api_detail','web_url_abs','web_url','source_url','url'] as $key) {
        $value = trim((string)($item[$key] ?? ''));
        if ($value === '') continue;
        $parts = @parse_url($value);
        if (!empty($parts['query'])) {
            parse_str((string)$parts['query'], $query);
            foreach (['slug','id'] as $param) {
                $candidate = trim((string)($query[$param] ?? ''));
                if ($candidate !== '') return rawurldecode(preg_replace('~^arc[134]-~i', '', trim($candidate, "/ \t")));
            }
        }
        $path = rawurldecode(trim((string)($parts['path'] ?? $value), "/ \t"));
        if (preg_match('~(?:^|/)movie/arc[134]-([^/?#]+)~i', '/' . $path, $m)) return trim((string)$m[1]);
        $last = preg_replace('~^arc[134]-~i', '', trim((string)basename($path)));
        if ($last !== '' && !str_ends_with(strtolower($last), '.php')) return $last;
    }
    $fallback = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['title_fa'] ?? $item['title'] ?? ''));
    return rawurldecode(preg_replace('~^arc[134]-~i', '', trim($fallback, "/ \t")));
}

function bm_user_api_comment_context(PDO $pdo, array $item): array {
    $explicitArchive = (int)($item['comment_archive'] ?? 0);
    $source = strtolower(trim((string)($item['source'] ?? '')));
    $rawArchive = (int)($item['_origin_archive'] ?? $item['archive'] ?? 0);

    // Critical rule: an explicit external archive always wins over db_id/api_detail.
    // Some Archive 1 payloads contain numeric helper ids, which must never route
    // their comments into the website database movie comments table.
    $forcedExternalArchive = 0;
    if ($explicitArchive === 1 || $source === 'archive1' || $rawArchive === 1) {
        $forcedExternalArchive = 1;
    } elseif ($explicitArchive === 3 || $source === 'archive3' || str_contains($source, 'arc3') || $rawArchive === 3) {
        $forcedExternalArchive = 3;
    } elseif ($explicitArchive === 4 || in_array($source, ['serialblog','archive2','sb'], true)) {
        $forcedExternalArchive = 4;
    }

    if ($forcedExternalArchive === 0 && bm_user_api_is_database_item($item)) {
        $movieId = bm_user_api_resolve_db_movie_id($pdo, $item);
        if ($movieId <= 0) bm_user_api_error('شناسه فیلم در دیتابیس پیدا نشد', 404);
        return ['archive'=>2,'movie_id'=>$movieId,'comments'=>'comments','likes'=>'comment_likes','identity'=>(string)$movieId];
    }

    $archive = $forcedExternalArchive > 0 ? $forcedExternalArchive : 1;
    $identity = trim((string)($item['comment_identity'] ?? ''));
    if ($identity === '') $identity = bm_user_api_external_comment_identity($item);
    $identity = rawurldecode(trim((string)preg_replace('~^arc[134]-~i', '', $identity), "/ \t"));
    if ($identity === '') bm_user_api_error('شناسه عنوان برای دیدگاه نامعتبر است', 422);

    $prefix = $archive === 4 ? 'arc4:' : ($archive === 3 ? 'arc3:' : 'arc1:');
    $movieId = 1000000000 + (abs(crc32($prefix . $identity)) % 1000000000);
    return ['archive'=>$archive,'movie_id'=>$movieId,'comments'=>'archive1_comments','likes'=>'archive1_comment_likes','identity'=>$identity];
}

function bm_user_api_ensure_external_comment_item_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_items (
        virtual_movie_id INT UNSIGNED NOT NULL PRIMARY KEY,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        slug VARCHAR(220) NOT NULL DEFAULT '',
        item_link VARCHAR(500) NOT NULL DEFAULT '',
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_archive_slug (archive_no, slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $cols = bm_user_api_table_columns($pdo, 'archive1_items');
    if ($cols && !in_array('archive_no', $cols, true)) {
        try { $pdo->exec("ALTER TABLE archive1_items ADD COLUMN archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER virtual_movie_id"); } catch (Throwable $e) {}
    }
}

function bm_user_api_upsert_external_comment_item(PDO $pdo, array &$ctx, array $item): void {
    if ((int)($ctx['archive'] ?? 2) === 2) return;
    bm_user_api_ensure_external_comment_item_schema($pdo);
    $title = trim((string)($item['title'] ?? ''));
    $titleFa = trim((string)($item['title_fa'] ?? $title));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $link = '';
    foreach (['web_url_abs','source_url','web_url','url'] as $key) {
        $value = trim((string)($item[$key] ?? ''));
        if ($value !== '') { $link = bm_user_api_abs_url($value); break; }
    }
    $poster = bm_user_api_abs_url((string)($item['poster'] ?? $item['image'] ?? ''));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $identity = trim((string)($ctx['identity'] ?? ''));
    $identityNorm = mb_strtolower(rawurldecode(trim((string)preg_replace('~^arc[134]-~i', '', $identity), "/ \t")), 'UTF-8');
    $year = trim((string)($item['year'] ?? ''));
    $archiveNo = (int)($ctx['archive'] ?? 1);
    $computedId = (int)($ctx['movie_id'] ?? 0);

    // Resolve aliases created by older app/site builds. Prefer the mapped id that
    // already owns comments, then merge strong aliases so both app and website
    // keep using one conversation thread.
    try {
        $where = ['ai.virtual_movie_id = ?'];
        $params = [$computedId];
        if ($identityNorm !== '') {
            $where[] = "(ai.archive_no = ? AND (LOWER(TRIM(BOTH '/' FROM ai.slug)) = ? OR LOWER(TRIM(BOTH '/' FROM ai.slug)) = ?))";
            $params[] = $archiveNo;
            $params[] = $identityNorm;
            $params[] = 'arc' . $archiveNo . '-' . $identityNorm;
        }
        if ($link !== '') {
            $where[] = '(ai.archive_no = ? AND ai.item_link = ?)';
            $params[] = $archiveNo;
            $params[] = $link;
        }
        if ($year !== '' && ($title !== '' || $titleFa !== '')) {
            $where[] = '(ai.archive_no = ? AND (ai.item_title = ? OR ai.item_title_fa = ? OR ai.item_title = ? OR ai.item_title_fa = ?) AND ai.item_year = ?)';
            $params[] = $archiveNo;
            $params[] = $title;
            $params[] = $title;
            $params[] = $titleFa;
            $params[] = $titleFa;
            $params[] = $year;
        }
        $q = $pdo->prepare("SELECT ai.virtual_movie_id, ai.slug, ai.item_link, ai.item_title, ai.item_title_fa, ai.item_year,
                                  (SELECT COUNT(*) FROM archive1_comments c WHERE c.movie_id=ai.virtual_movie_id) comment_count
                           FROM archive1_items ai
                           WHERE " . implode(' OR ', $where) . " LIMIT 30");
        $q->execute($params);
        $rows = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $scored = [];
        foreach ($rows as $row) {
            $id = (int)($row['virtual_movie_id'] ?? 0);
            if ($id <= 0) continue;
            $score = $id === $computedId ? 40 : 0;
            $rowSlug = mb_strtolower(rawurldecode(trim((string)preg_replace('~^arc[134]-~i', '', (string)($row['slug'] ?? '')), "/ \t")), 'UTF-8');
            if ($identityNorm !== '' && $rowSlug === $identityNorm) $score += 120;
            if ($link !== '' && trim((string)($row['item_link'] ?? '')) === $link) $score += 110;
            $titleMatch = ($title !== '' || $titleFa !== '') && in_array(trim((string)($row['item_title'] ?? '')), [$title, $titleFa], true)
                || ($title !== '' || $titleFa !== '') && in_array(trim((string)($row['item_title_fa'] ?? '')), [$title, $titleFa], true);
            $yearMatch = $year !== '' && trim((string)($row['item_year'] ?? '')) === $year;
            if ($titleMatch && $yearMatch) $score += 75;
            $scored[] = ['id'=>$id,'score'=>$score,'comments'=>(int)($row['comment_count'] ?? 0)];
        }
        if ($scored) {
            usort($scored, static function(array $a, array $b): int {
                $ar = ($a['comments'] > 0 ? 1000000 : 0) + $a['comments'] * 1000 + $a['score'];
                $br = ($b['comments'] > 0 ? 1000000 : 0) + $b['comments'] * 1000 + $b['score'];
                return $br <=> $ar;
            });
            $targetId = (int)$scored[0]['id'];
            if ($targetId > 0) {
                $ctx['movie_id'] = $targetId;
                $mergeIds = [];
                foreach ($scored as $candidate) {
                    if ((int)$candidate['id'] !== $targetId && (int)$candidate['score'] >= 75) $mergeIds[] = (int)$candidate['id'];
                }
                $mergeIds = array_values(array_unique(array_filter($mergeIds)));
                if ($mergeIds) {
                    $ph = implode(',', array_fill(0, count($mergeIds), '?'));
                    $move = $pdo->prepare("UPDATE archive1_comments SET movie_id=? WHERE movie_id IN ({$ph})");
                    $move->execute(array_merge([$targetId], $mergeIds));
                    error_log('app comment identity bridge merged [' . implode(',', $mergeIds) . '] into ' . $targetId);
                }
            }
        }
    } catch (Throwable $e) {
        error_log('app comment identity bridge: ' . $e->getMessage());
    }

    $stmt = $pdo->prepare("INSERT INTO archive1_items
        (virtual_movie_id,archive_no,slug,item_link,item_title,item_title_fa,item_year,item_poster,item_type)
        VALUES(?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE archive_no=VALUES(archive_no),slug=VALUES(slug),
        item_link=IF(VALUES(item_link)!='',VALUES(item_link),item_link),
        item_title=IF(VALUES(item_title)!='',VALUES(item_title),item_title),
        item_title_fa=IF(VALUES(item_title_fa)!='',VALUES(item_title_fa),item_title_fa),
        item_year=IF(VALUES(item_year)!='',VALUES(item_year),item_year),
        item_poster=IF(VALUES(item_poster)!='',VALUES(item_poster),item_poster),item_type=VALUES(item_type)");
    $stmt->execute([(int)$ctx['movie_id'],$archiveNo,$identity,$link,$title,$titleFa,$year,$poster,$type]);
}

function bm_user_api_privileged_comment_role(string $role): bool {
    return in_array(strtolower(trim($role)), ['admin','administrator','vip','premium','special'], true);
}

function bm_user_api_comment_submit_status(string $role): string {
    $r=strtolower(trim($role));
    $f=bm_user_api_features();
    if (in_array($r,['admin','administrator'],true) && !empty($f['comment_auto_approve_admin'])) return 'approved';
    if (in_array($r,['vip','premium','special'],true) && !empty($f['comment_auto_approve_vip'])) return 'approved';
    return 'pending';
}

function bm_user_api_comment_rate_limit(PDO $pdo, int $userId, string $text = ''): void {
    $features = bm_user_api_features();
    $maxCount = max(1, (int)($features['comment_rate_count'] ?? 3));
    $minutes = max(1, (int)($features['comment_rate_minutes'] ?? 10));
    $windowSeconds = $minutes * 60;
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_rate_limits (
        actor_key VARCHAR(190) NOT NULL PRIMARY KEY,
        window_started_at DATETIME NOT NULL,
        comment_count INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL,
        KEY idx_updated_at (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $ip = trim((string)($_SERVER['REMOTE_ADDR'] ?? ''));
    $actor = 'user:' . $userId . ($ip !== '' ? ':ip:' . substr(hash('sha256', $ip), 0, 16) : '');
    $stmt = $pdo->prepare("INSERT INTO comment_rate_limits(actor_key,window_started_at,comment_count,updated_at)
        VALUES(?,NOW(),1,NOW())
        ON DUPLICATE KEY UPDATE
            comment_count = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE), 1, comment_count + 1),
            window_started_at = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE), NOW(), window_started_at),
            updated_at = NOW()");
    $stmt->execute([$actor]);
    $read = $pdo->prepare("SELECT comment_count, GREATEST(0, ? - TIMESTAMPDIFF(SECOND, window_started_at, NOW())) AS retry_after FROM comment_rate_limits WHERE actor_key=? LIMIT 1");
    $read->execute([$windowSeconds, $actor]);
    $row = $read->fetch(PDO::FETCH_ASSOC) ?: ['comment_count'=>1,'retry_after'=>0];
    if ((int)$row['comment_count'] > $maxCount) {
        $retry = max(1, (int)$row['retry_after']);
        bm_user_api_json(['status'=>'error','success'=>false,'message'=>"برای جلوگیری از اسپم، هر کاربر در هر {$minutes} دقیقه حداکثر {$maxCount} دیدگاه یا پاسخ می‌تواند ثبت کند.",'retry_after'=>$retry], 429);
    }
}

function bm_user_api_relative_time(int $seconds): string {
    $d = max(0, $seconds);
    if ($d < 60) return 'لحظاتی پیش';
    if ($d < 3600) return intdiv($d, 60) . ' دقیقه پیش';
    if ($d < 86400) return intdiv($d, 3600) . ' ساعت پیش';
    if ($d < 604800) return intdiv($d, 86400) . ' روز پیش';
    if ($d < 2592000) return intdiv($d, 604800) . ' هفته پیش';
    if ($d < 31536000) return intdiv($d, 2592000) . ' ماه پیش';
    return intdiv($d, 31536000) . ' سال پیش';
}

function bm_user_api_comment_date(string $date): string {
    $time = strtotime($date);
    return $time ? bm_user_api_relative_time(max(0, time() - $time)) : 'لحظاتی پیش';
}

function bm_user_api_public_status_sql(string $alias = 'c'): string {
    $safeAlias = preg_replace('/[^A-Za-z0-9_]/', '', $alias) ?: 'c';
    return "LOWER(TRIM(CAST({$safeAlias}.status AS CHAR))) IN ('approved','active','1')";
}

function bm_user_api_abs_media_url(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (str_starts_with($url, '//')) return 'https:' . $url;
    if (preg_match('~^https?://~i', $url)) return $url;
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d{1,5})?$/i', $host)) $host = 'bankmovie.top';
    return 'https://' . strtolower($host) . '/' . ltrim($url, '/');
}

function bm_user_api_comment_media_payload(string $value): array {
    $text = function_exists('bm_sticker_comment_text') ? bm_sticker_comment_text($value) : $value;
    $media = null;
    if (function_exists('bm_sticker_resolve_marker')) {
        $resolved = bm_sticker_resolve_marker($value);
        if (is_array($resolved) && is_array($resolved['item'] ?? null)) {
            $item = $resolved['item'];
            $media = [
                'pack'=>(string)($resolved['pack'] ?? ''),
                'label'=>(string)($resolved['label'] ?? ''),
                'id'=>(string)($item['id'] ?? ''),
                'url'=>bm_user_api_abs_media_url((string)($item['url'] ?? '')),
                'media_type'=>(string)($item['media_type'] ?? 'image'),
                'extension'=>(string)($item['extension'] ?? ''),
            ];
        }
    }
    return ['text'=>$text,'media'=>$media];
}

function bm_user_api_comment_media_catalog(): array {
    if (!function_exists('bm_sticker_public_catalog')) return [];
    $out = [];
    foreach (bm_sticker_public_catalog() as $slug => $pack) {
        if (!is_array($pack)) continue;
        $items = [];
        foreach ((array)($pack['items'] ?? []) as $item) {
            if (!is_array($item)) continue;
            $items[] = [
                'id'=>(string)($item['id'] ?? ''),
                'url'=>bm_user_api_abs_media_url((string)($item['url'] ?? '')),
                'media_type'=>(string)($item['media_type'] ?? 'image'),
                'extension'=>(string)($item['extension'] ?? ''),
            ];
        }
        $out[] = ['slug'=>(string)$slug,'label'=>(string)($pack['label'] ?? $slug),'items'=>$items];
    }
    return $out;
}

function bm_user_api_comment_row(array $row, int $currentUserId, bool $currentIsAdmin = false): array {
    $avatarKey = trim((string)($row['avatar_key'] ?? ''));
    $role = strtolower(trim((string)($row['role'] ?? 'user')));
    $createdTs = strtotime((string)($row['created_at'] ?? '')) ?: 0;
    $editMinutes = (int)(bm_user_api_features()['comment_edit_minutes'] ?? 10);
    $canEdit = $currentUserId > 0 && ($currentIsAdmin || ((int)($row['user_id'] ?? 0) === $currentUserId && $editMinutes > 0 && $createdTs > 0 && time() <= $createdTs + $editMinutes * 60));
    $status = strtolower(trim((string)($row['status'] ?? 'approved')));
    $mediaPayload = bm_user_api_comment_media_payload((string)($row['comment'] ?? ''));
    return [
        'id'=>(int)$row['id'], 'parent_id'=>(int)($row['parent_id'] ?? 0), 'user_id'=>(int)($row['user_id'] ?? 0),
        'username'=>(string)($row['username'] ?? 'کاربر'), 'comment'=>(string)$mediaPayload['text'], 'comment_raw'=>(string)($row['comment'] ?? ''),
        'media'=>$mediaPayload['media'],
        'rating'=>(int)($row['rating'] ?? 0), 'spoiler'=>(int)($row['spoiler'] ?? 0) === 1,
        'role'=>$role, 'avatar_key'=>$avatarKey,
        'avatar'=>bm_user_api_avatar_url($avatarKey, (string)($row['avatar'] ?? '')),
        'like_count'=>(int)($row['like_count'] ?? 0), 'dislike_count'=>(int)($row['dislike_count'] ?? 0),
        'user_vote'=>(string)($row['user_vote'] ?? ''), 'reply_count'=>(int)($row['reply_count'] ?? 0),
        'created_at'=>(string)($row['created_at'] ?? ''), 'date_text'=>bm_user_api_relative_time((int)($row['age_seconds'] ?? 0)), 'age_seconds'=>(int)($row['age_seconds'] ?? 0),
        'edited'=>!empty($row['edited_at']), 'edited_at'=>(string)($row['edited_at'] ?? ''),
        'is_pinned'=>(int)($row['is_pinned'] ?? 0) === 1,
        'status'=>$status, 'is_pending'=>$status === 'pending',
        'badge'=>in_array($role, ['admin','administrator'], true) ? 'مدیر' : (in_array($role, ['vip','premium','special'], true) ? 'عضو ویژه' : ''),
        'verified'=>in_array($role, ['admin','administrator'], true),
        'can_delete'=>$currentUserId > 0 && $currentIsAdmin,
        'can_edit'=>$canEdit,
        'can_pin'=>$currentUserId > 0 && $currentIsAdmin,
        'can_report'=>$currentUserId > 0 && (int)($row['user_id'] ?? 0) !== $currentUserId,
    ];
}

function bm_user_api_comment_sort_sql(string $sort): string {
    return match ($sort) {
        'oldest' => "c.is_pinned DESC, (c.status='pending') DESC, c.created_at ASC, c.id ASC",
        'popular' => "c.is_pinned DESC, (like_count-dislike_count) DESC, like_count DESC, reply_count DESC, c.created_at DESC",
        'controversial' => "c.is_pinned DESC, LEAST(like_count,dislike_count) DESC, (like_count+dislike_count) DESC, reply_count DESC, c.created_at DESC",
        'replies' => "c.is_pinned DESC, reply_count DESC, like_count DESC, c.created_at DESC",
        default => "c.is_pinned DESC, (c.status='pending') DESC, c.created_at DESC, c.id DESC",
    };
}

function bm_user_api_comment_list(PDO $pdo, array $ctx, int $currentUserId, int $page, int $limit, bool $currentIsAdmin = false, string $sort = 'latest'): array {
    $c = $ctx['comments']; $l = $ctx['likes']; $movieId = (int)$ctx['movie_id'];
    $page=max(1,$page); $limit=max(1,min(30,$limit)); $offset=($page-1)*$limit;
    $sort = in_array($sort, ['latest','oldest','popular','controversial','replies'], true) ? $sort : 'latest';
    $approvedC = bm_user_api_public_status_sql('c');
    $approvedR = bm_user_api_public_status_sql('r');
    $approvedBase = bm_user_api_public_status_sql($c);
    $visible = $currentUserId > 0 ? "({$approvedC} OR (c.status='pending' AND c.user_id=?))" : $approvedC;
    $sql = "SELECT c.*, u.role, u.avatar, u.avatar_key,
        GREATEST(0, TIMESTAMPDIFF(SECOND, c.created_at, NOW())) age_seconds,
        COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=c.id AND x.type='like'),0) like_count,
        COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=c.id AND x.type='dislike'),0) dislike_count,
        COALESCE((SELECT type FROM `$l` x WHERE x.comment_id=c.id AND x.user_id=? LIMIT 1),'') user_vote,
        (SELECT COUNT(*) FROM `$c` r WHERE r.parent_id=c.id AND ({$approvedR}" . ($currentUserId > 0 ? " OR (r.status='pending' AND r.user_id=?)" : "") . ")) reply_count
        FROM `$c` c LEFT JOIN users u ON u.id=c.user_id
        WHERE c.movie_id=? AND (c.parent_id IS NULL OR c.parent_id=0) AND $visible
        ORDER BY " . bm_user_api_comment_sort_sql($sort) . " LIMIT $limit OFFSET $offset";
    $params=[$currentUserId];
    if($currentUserId>0) $params[]=$currentUserId;
    $params[]=$movieId;
    if($currentUserId>0) $params[]=$currentUserId;
    $stmt=$pdo->prepare($sql); $stmt->execute($params);
    $roots = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    $rootIds = array_values(array_map(static fn($r)=>(int)$r['id'], $roots));

    $childrenByParent = [];
    if ($rootIds) {
        // Load every visible descendant once, then assemble a real nested tree in PHP.
        $replyVisible = $currentUserId > 0 ? "({$approvedR} OR (r.status='pending' AND r.user_id=?))" : $approvedR;
        $rs=$pdo->prepare("SELECT r.*,u.role,u.avatar,u.avatar_key,
            GREATEST(0, TIMESTAMPDIFF(SECOND, r.created_at, NOW())) age_seconds,
            COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=r.id AND x.type='like'),0) like_count,
            COALESCE((SELECT COUNT(*) FROM `$l` x WHERE x.comment_id=r.id AND x.type='dislike'),0) dislike_count,
            COALESCE((SELECT type FROM `$l` x WHERE x.comment_id=r.id AND x.user_id=? LIMIT 1),'') user_vote,
            (SELECT COUNT(*) FROM `$c` z WHERE z.parent_id=r.id AND " . bm_user_api_public_status_sql('z') . ") reply_count
            FROM `$c` r LEFT JOIN users u ON u.id=r.user_id
            WHERE r.movie_id=? AND r.parent_id IS NOT NULL AND r.parent_id<>0 AND $replyVisible
            ORDER BY r.created_at ASC,r.id ASC LIMIT 500");
        $rp=[$currentUserId,$movieId]; if($currentUserId>0)$rp[]=$currentUserId; $rs->execute($rp);
        foreach ($rs->fetchAll(PDO::FETCH_ASSOC) ?: [] as $rr) {
            $parent=(int)($rr['parent_id'] ?? 0);
            if($parent>0) $childrenByParent[$parent][]=$rr;
        }
    }
    $build = function(int $parentId, int $depth = 1) use (&$build, &$childrenByParent, $currentUserId, $currentIsAdmin): array {
        if ($depth > 4) return [];
        $out=[];
        foreach ($childrenByParent[$parentId] ?? [] as $rr) {
            $node=bm_user_api_comment_row($rr,$currentUserId,$currentIsAdmin);
            $node['replies']=$build((int)$rr['id'],$depth+1);
            $out[]=$node;
        }
        return $out;
    };
    $items=[];
    foreach ($roots as $row) {
        $comment=bm_user_api_comment_row($row,$currentUserId,$currentIsAdmin);
        $comment['replies']=$build((int)$row['id']);
        $items[]=$comment;
    }
    $visibleCount = $currentUserId > 0 ? "({$approvedBase} OR (status='pending' AND user_id=?))" : $approvedBase;
    $t=$pdo->prepare("SELECT COUNT(*) FROM `$c` WHERE movie_id=? AND (parent_id IS NULL OR parent_id=0) AND {$visibleCount}");
    $tp=[$movieId]; if($currentUserId>0)$tp[]=$currentUserId; $t->execute($tp); $total=(int)$t->fetchColumn();
    $r=$pdo->prepare("SELECT AVG(rating),COUNT(*) FROM `$c` WHERE movie_id=? AND (parent_id IS NULL OR parent_id=0) AND {$approvedBase} AND rating>0"); $r->execute([$movieId]); $rating=$r->fetch(PDO::FETCH_NUM) ?: [0,0];
    return ['items'=>$items,'page'=>$page,'limit'=>$limit,'total'=>$total,'has_more'=>$offset+count($items)<$total,'rating_avg'=>round((float)$rating[0],1),'rating_count'=>(int)$rating[1],'sort'=>$sort];
}

function bm_user_api_update_movie_rating(PDO $pdo, int $movieId): void {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS movie_ratings (movie_id INT UNSIGNED PRIMARY KEY, avg_rating DECIMAL(4,2) NOT NULL DEFAULT 0, total_votes INT UNSIGNED NOT NULL DEFAULT 0)");
        $approvedStatus = bm_user_api_public_status_sql('comments');
        $s=$pdo->prepare("SELECT AVG(rating),COUNT(*) FROM comments WHERE movie_id=? AND (parent_id IS NULL OR parent_id=0) AND {$approvedStatus} AND rating>0"); $s->execute([$movieId]); $v=$s->fetch(PDO::FETCH_NUM) ?: [0,0];
        $u=$pdo->prepare("INSERT INTO movie_ratings(movie_id,avg_rating,total_votes) VALUES(?,?,?) ON DUPLICATE KEY UPDATE avg_rating=VALUES(avg_rating),total_votes=VALUES(total_votes)");
        $u->execute([$movieId,(float)$v[0],(int)$v[1]]);
    } catch (Throwable $e) { error_log('app user rating: '.$e->getMessage()); }
}

function bm_user_api_stats(PDO $pdo, int $userId): array {
    bm_user_api_ensure_watchlist($pdo);
    bm_user_api_ensure_notification_schema($pdo);
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_watchlist WHERE user_id = ?');
    $stmt->execute([$userId]);
    $watchlist = (int)$stmt->fetchColumn();
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id = ? AND read_at IS NULL AND dismissed_at IS NULL');
    $stmt->execute([$userId]);
    return ['watchlist' => $watchlist, 'notifications_unread' => (int)$stmt->fetchColumn()];
}

$action = bm_user_api_action();

// ---------------- PASS 4: Watch Party bridge ----------------
function bm_user_api_wp_ready(): bool {
    return function_exists('bm_watch_party_schema')
        && function_exists('bm_watch_party_start_or_reuse_room')
        && function_exists('bm_watch_party_poll');
}

function bm_user_api_wp_guest_actor(): array|false {
    $token = trim((string)bm_user_api_param('guest_token', bm_user_api_header('X-BM-WP-Guest')));
    if (!preg_match('/^[A-Za-z0-9_-]{40,120}$/', $token)) return false;
    $suffix = strtoupper(substr(hash('sha256', $token), 0, 4));
    return [
        'id' => 0,
        'username' => 'همراه مهمان ' . $suffix,
        'role' => 'guest',
        'avatar' => '',
        'vip_expires_at' => null,
        'is_watch_party_guest' => true,
        'watch_party_guest_token' => $token,
    ];
}

function bm_user_api_wp_actor(PDO $pdo, bool $required = true): array|false {
    $user = bm_user_api_current_user($pdo, false);
    if ($user) return $user;
    $guest = bm_user_api_wp_guest_actor();
    if ($guest) return $guest;
    if ($required) bm_user_api_error('ابتدا وارد حساب شوید یا از لینک دعوت معتبر استفاده کنید', 401, ['error'=>'watch_party_auth_required']);
    return false;
}

function bm_user_api_wp_exception(Throwable $e): never {
    $status = (int)$e->getCode();
    if ($status < 400 || $status > 599) $status = 500;
    $key = trim($e->getMessage());
    $messages = [
        'not_room_member' => 'عضو این اتاق نیستید.',
        'room_not_found_or_expired' => 'اتاق در دسترس نیست.',
        'room_not_found' => 'اتاق پیدا نشد؛ لینک دعوت را بررسی کنید.',
        'room_expired' => 'زمان اتاق به پایان رسیده است.',
        'room_is_full' => 'ظرفیت اتاق تکمیل است.',
        'host_control_only' => 'کنترل پخش فقط در اختیار میزبان است.',
        'invalid_event' => 'رویداد پخش معتبر نیست.',
        'invalid_source_url' => 'این لینک برای Watch Party قابل استفاده نیست.',
        'invalid_subtitle_url' => 'لینک زیرنویس معتبر نیست.',
        'chat_disabled' => 'گفت‌وگوی اتاق غیرفعال است.',
        'empty_message' => 'پیام خالی است.',
        'message_rate_limited' => 'پیام‌ها خیلی سریع ارسال می‌شوند؛ کمی صبر کنید.',
        'too_many_active_rooms' => 'دو اتاق فعال دارید؛ یکی را ببندید و دوباره امتحان کنید.',
        'watch_party_schema_unavailable' => 'دیتابیس Watch Party روی سایت کامل آماده نشده است.',
        'voice_test_forbidden' => 'Voice Call برای این حساب یا اتاق فعال نیست.',
        'voice_peer_unavailable' => 'همراه شما هنوز برای تماس صوتی آماده نیست.',
        'voice_busy' => 'یک تماس دیگر در این اتاق فعال است.',
        'voice_call_not_found' => 'تماس صوتی پیدا نشد یا پایان یافته است.',
        'voice_action_invalid' => 'این عملیات برای وضعیت فعلی تماس قابل انجام نیست.',
        'voice_invalid_signal' => 'داده اتصال صوتی معتبر نیست.',
        'voice_rate_limited' => 'درخواست‌های تماس زیاد است؛ چند لحظه صبر کنید.',
        'voice_schema_unavailable' => 'زیرساخت تماس صوتی روی سایت آماده نشده است.',
    ];
    if ($status >= 500) error_log('Android Watch Party: ' . $e->getMessage());
    bm_user_api_error($messages[$key] ?? ($status >= 500 ? 'خطای موقت Watch Party' : 'درخواست Watch Party قابل انجام نیست'), $status, ['error'=>$key]);
}

function bm_user_api_wp_room(PDO $pdo, array $actor): array {
    $code = trim((string)bm_user_api_param('room_code', ''));
    $room = bm_watch_party_find_room($pdo, $code);
    if (!$room) {
        $reason = (string)($GLOBALS['bm_watch_party_room_lookup_reason'] ?? 'not_found');
        throw new RuntimeException($reason === 'expired' ? 'room_expired' : 'room_not_found', 404);
    }
    bm_watch_party_require_member($pdo, $room, $actor);
    return $room;
}

function bm_user_api_wp_invite_url(string $code): string {
    return rtrim((string)SITE_URL, '/') . '/watch-party?room=' . rawurlencode($code);
}

function bm_user_api_wp_themes(): array {
    return [
        ['key'=>'simple','label'=>'ساده'],
        ['key'=>'purple_dream','label'=>'رویای بنفش'],
        ['key'=>'teal_mist','label'=>'مه آبی'],
        ['key'=>'golden','label'=>'طلایی'],
        ['key'=>'forest','label'=>'جنگل'],
        ['key'=>'pink_cloud','label'=>'رویای پونی'],
        ['key'=>'interstellar','label'=>'میان ستاره‌ای'],
        ['key'=>'pony','label'=>'پونی'],
        ['key'=>'pizza','label'=>'پیتزا'],
        ['key'=>'darkness','label'=>'تاریکی'],
        ['key'=>'romantic_hearts','label'=>'عاشقانه'],
        ['key'=>'galaxy_nova','label'=>'کهکشانی'],
        ['key'=>'starlight','label'=>'ستاره‌ای'],
        ['key'=>'aurora','label'=>'شفق قطبی'],
    ];
}

function bm_user_api_wp_sales(): array {
    if (!function_exists('bm_vip_sales_settings')) return ['plans'=>[], 'telegram_username'=>'bankmovie_supp'];
    $s = bm_vip_sales_settings();
    $plans = [];
    foreach ((array)($s['plans'] ?? []) as $plan) {
        if (!is_array($plan) || empty($plan['enabled'])) continue;
        $plans[] = [
            'name'=>(string)($plan['name'] ?? ''), 'latin'=>(string)($plan['latin'] ?? ''),
            'price'=>(string)($plan['price'] ?? ''), 'period'=>(string)($plan['period'] ?? ''),
            'badge'=>(string)($plan['badge'] ?? ''), 'saving'=>(string)($plan['saving'] ?? ''),
            'featured'=>!empty($plan['featured']), 'tone'=>(string)($plan['tone'] ?? 'blue'),
        ];
    }
    return [
        'plans'=>$plans,
        'telegram_username'=>(string)($s['telegram_username'] ?? 'bankmovie_supp'),
        'purchase_enabled'=>!empty($s['purchase_enabled']),
        'purchase_message_template'=>(string)($s['purchase_message_template'] ?? ''),
        'section_title'=>(string)($s['section_title'] ?? 'BankMovie VIP'),
        'section_description'=>(string)($s['section_description'] ?? ''),
        'features'=>array_values(array_filter(array_map(static fn($f) => is_array($f) && !empty($f['enabled']) ? (string)($f['label'] ?? '') : '', (array)($s['features'] ?? [])))),
    ];
}

try {
    if (str_starts_with($action, 'watch_party_')) {
        if (!bm_user_api_wp_ready()) bm_user_api_error('فایل‌های Watch Party سایت روی سرور نصب نشده‌اند', 503, ['error'=>'watch_party_bridge_missing']);
        if (!bm_watch_party_is_enabled()) bm_user_api_error('Watch Party موقتاً غیرفعال است', 503, ['error'=>'watch_party_disabled']);
        if (!bm_watch_party_schema($pdo)) bm_user_api_error('دیتابیس Watch Party آماده نیست', 503, ['error'=>'watch_party_schema_unavailable']);
        bm_watch_party_cleanup_expired($pdo, 300);

        if ($action === 'watch_party_status') {
            $user = bm_user_api_current_user($pdo, false);
            $sales = bm_user_api_wp_sales();
            bm_user_api_json(['status'=>'ok','success'=>true,'enabled'=>true,'is_logged_in'=>(bool)$user,'is_vip'=>$user ? bm_watch_party_is_vip($user) : false,'room_hours'=>bm_watch_party_max_hours(),'max_members'=>bm_watch_party_max_members(),'chat_enabled'=>bm_watch_party_chat_enabled(),'voice_enabled'=>$user ? bm_watch_party_voice_test_allowed($user) : bm_watch_party_voice_guests_enabled(),'themes'=>bm_user_api_wp_themes(),'vip'=>$sales]);
        }

        if ($action === 'watch_party_create') {
            bm_user_api_require_post();
            $user = bm_user_api_current_user($pdo, true);
            if (!bm_watch_party_is_vip($user)) bm_user_api_error('ساخت اتاق فقط برای کاربران VIP فعال است', 403, ['error'=>'vip_required','vip'=>bm_user_api_wp_sales()]);
            $input = [
                'movie_id'=>(int)bm_user_api_param('movie_id',0), 'archive_no'=>(int)bm_user_api_param('archive_no',1),
                'media_type'=>(string)bm_user_api_param('media_type','movie'), 'source_ref'=>(string)bm_user_api_param('source_ref','android'),
                'room_code'=>(string)bm_user_api_param('room_code',''),
                'source_url'=>(string)bm_user_api_param('source_url',''), 'subtitle_url'=>(string)bm_user_api_param('subtitle_url',''),
                'content_title'=>(string)bm_user_api_param('content_title',''), 'poster_url'=>(string)bm_user_api_param('poster_url',''),
            ];
            $room = bm_watch_party_start_or_reuse_room($pdo, $user, $input);
            $code = (string)($room['invite_code'] ?? '');
            $room['invite_url'] = bm_user_api_wp_invite_url($code);
            $room['member_role'] = 'host';
            bm_user_api_json(['status'=>'ok','success'=>true,'room'=>$room], 201);
        }

        if ($action === 'watch_party_join') {
            bm_user_api_require_post();
            $actor = bm_user_api_wp_actor($pdo, true);
            $membership = bm_watch_party_join_room($pdo, $actor, (string)bm_user_api_param('room_code',''));
            bm_user_api_json(['status'=>'ok','success'=>true,'membership'=>$membership]);
        }

        $actor = bm_user_api_wp_actor($pdo, true);
        $room = bm_user_api_wp_room($pdo, $actor);
        $member = bm_watch_party_require_member($pdo, $room, $actor);

        if ($action === 'watch_party_poll') {
            $result = bm_watch_party_poll($pdo,$room,$actor,max(0,(int)bm_user_api_param('after_event_id',0)),max(0,(int)bm_user_api_param('after_message_id',0)));
            if (is_array($result['messages'] ?? null)) {
                foreach ($result['messages'] as &$bmWpMsg) {
                    if (!is_array($bmWpMsg)) continue;
                    $mediaPayload = bm_user_api_comment_media_payload((string)($bmWpMsg['message'] ?? ''));
                    $bmWpMsg['text'] = (string)($mediaPayload['text'] ?? '');
                    $bmWpMsg['media'] = $mediaPayload['media'] ?? null;
                }
                unset($bmWpMsg);
            }
            $result['chat_enabled'] = bm_watch_party_chat_enabled();
            $result['voice'] = bm_watch_party_voice_poll($pdo,$room,$actor,max(0,(int)bm_user_api_param('after_voice_signal_id',0)));
            $result['member_role'] = (string)($member['member_role'] ?? 'guest');
            bm_user_api_json(array_merge(['status'=>'ok','success'=>true],$result));
        }

        if ($action === 'watch_party_control') {
            bm_user_api_require_post();
            $result=bm_watch_party_update_state($pdo,$room,$actor,$member,bm_user_api_body());
            bm_user_api_json(['status'=>'ok','success'=>true,'state'=>$result]);
        }
        if ($action === 'watch_party_room_settings') {
            bm_user_api_require_post();
            $result=bm_watch_party_update_room_settings($pdo,$room,$actor,$member,bm_user_api_body());
            bm_user_api_json(['status'=>'ok','success'=>true,'settings'=>$result]);
        }
        if ($action === 'watch_party_message') {
            bm_user_api_require_post();
            $result=bm_watch_party_add_message($pdo,$room,$actor,(string)bm_user_api_param('message',''),(string)bm_user_api_param('client_message_id',''));
            bm_user_api_json(['status'=>'ok','success'=>true,'chat'=>$result],201);
        }
        if ($action === 'watch_party_voice_start') {
            bm_user_api_require_post();
            bm_user_api_json(array_merge(['status'=>'ok','success'=>true],bm_watch_party_voice_start_call($pdo,$room,$actor)),201);
        }
        if ($action === 'watch_party_voice_action') {
            bm_user_api_require_post();
            bm_user_api_json(array_merge(['status'=>'ok','success'=>true],bm_watch_party_voice_action($pdo,$room,$actor,(string)bm_user_api_param('call_token',''),(string)bm_user_api_param('voice_action',''),bm_user_api_body())));
        }
        if ($action === 'watch_party_voice_signal') {
            bm_user_api_require_post();
            $payload=bm_user_api_param('payload',null);
            if (is_string($payload)) { $j=json_decode($payload,true); if (json_last_error()===JSON_ERROR_NONE) $payload=$j; }
            bm_user_api_json(array_merge(['status'=>'ok','success'=>true],bm_watch_party_voice_signal($pdo,$room,$actor,(string)bm_user_api_param('call_token',''),(string)bm_user_api_param('signal_type',''),(string)bm_user_api_param('client_signal_id',''),$payload)),201);
        }
        if ($action === 'watch_party_leave') {
            bm_user_api_require_post();
            bm_user_api_json(array_merge(['status'=>'ok','success'=>true],bm_watch_party_leave_room($pdo,$room,$actor,$member)));
        }
        if ($action === 'watch_party_close') {
            bm_user_api_require_post();
            bm_watch_party_close_room($pdo,$room,$actor,$member);
            bm_user_api_json(['status'=>'ok','success'=>true,'room_closed'=>true]);
        }
        bm_user_api_error('Unknown Watch Party action',404);
    }
    if ($action === 'config') {
        $features = bm_user_api_features();
        $configuredBg = trim((string)($features['login_poster_url'] ?? ''));
        $bgRelative = is_file(__DIR__ . '/uploads/poste.webp') ? 'uploads/poste.webp' : (is_file(__DIR__ . '/poste.webp') ? 'poste.webp' : '');
        $background = $configuredBg !== '' ? bm_user_api_abs_url($configuredBg) : ($bgRelative !== '' ? rtrim((string)SITE_URL, '/') . '/' . $bgRelative : '');
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'background_url' => $background,
            'features' => $features,
            'login_identifier' => 'username_or_email',
            'registration_email_required' => true,
            'forgot_password_enabled' => true,
            'auth_security_challenge' => true,
            'avatars' => bm_user_api_avatar_catalog(),
            'vip' => bm_user_api_wp_sales(),
        ]);
    }

    if ($action === 'auth_challenge') {
        bm_user_api_json(array_merge([
            'status' => 'ok',
            'success' => true,
            'label' => 'تأیید امنیتی',
        ], bm_user_api_auth_challenge()));
    }

    if ($action === 'login') {
        bm_user_api_require_post();
        bm_user_api_validate_auth_challenge();
        if (!bm_user_api_feature_enabled('login_enabled', true)) bm_user_api_auth_error('ورود موقتاً از پنل مدیریت غیرفعال است', 503, ['error_code' => 'LOGIN_DISABLED']);
        $identity = trim((string)bm_user_api_param('identity', bm_user_api_param('username', '')));
        $password = (string)bm_user_api_param('password', '');
        if ($identity === '' || $password === '') bm_user_api_auth_error('نام کاربری یا ایمیل و رمز عبور را وارد کنید', 400, ['error_code' => 'LOGIN_FIELDS_REQUIRED']);

        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$identity, $identity]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$userRow || !password_verify($password, (string)$userRow['password'])) {
            bm_user_api_auth_error('نام کاربری یا رمز عبور اشتباه است', 401, ['error_code' => 'INVALID_CREDENTIALS']);
        }
        if ((string)($userRow['status'] ?? 'active') !== 'active') {
            bm_user_api_auth_error('حساب کاربری شما فعال نیست', 403, ['error_code' => 'ACCOUNT_INACTIVE']);
        }

        $token = bm_user_api_issue_token($pdo, (int)$userRow['id']);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
        ]);
    }

    if ($action === 'register') {
        bm_user_api_require_post();
        bm_user_api_validate_auth_challenge();
        if (!bm_user_api_feature_enabled('registration_enabled', true)) bm_user_api_auth_error('ثبت‌نام موقتاً از پنل مدیریت غیرفعال شده است', 403, ['error_code' => 'REGISTRATION_DISABLED']);
        $username = trim((string)bm_user_api_param('username', ''));
        $email = strtolower(trim((string)bm_user_api_param('email', '')));
        $password = (string)bm_user_api_param('password', '');
        $confirm = (string)bm_user_api_param('confirm_password', '');

        if (mb_strlen($username, 'UTF-8') < 3 || mb_strlen($username, 'UTF-8') > 40) {
            bm_user_api_auth_error('نام کاربری باید بین ۳ تا ۴۰ کاراکتر باشد', 400, ['error_code' => 'USERNAME_LENGTH']);
        }
        if (!preg_match('/^[\p{L}\p{N}_.-]+$/u', $username)) {
            bm_user_api_auth_error('نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه، خط تیره و زیرخط باشد', 400, ['error_code' => 'USERNAME_FORMAT']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            bm_user_api_auth_error('ایمیل معتبر وارد کنید', 400, ['error_code' => 'EMAIL_INVALID']);
        }
        if (strlen($password) < 8) bm_user_api_auth_error('رمز عبور باید حداقل ۸ کاراکتر باشد', 400, ['error_code' => 'PASSWORD_TOO_SHORT']);
        if (!hash_equals($password, $confirm)) bm_user_api_auth_error('رمز عبور و تکرار آن یکسان نیست', 400, ['error_code' => 'PASSWORD_MISMATCH']);

        $stmt = $pdo->prepare('SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $email]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            if (strcasecmp((string)$existing['email'], $email) === 0) bm_user_api_auth_error('این ایمیل قبلاً ثبت شده است', 409, ['error_code' => 'EMAIL_EXISTS']);
            bm_user_api_auth_error('این نام کاربری قبلاً ثبت شده است', 409, ['error_code' => 'USERNAME_EXISTS']);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())");
        $stmt->execute([$username, $email, $hash]);
        $userId = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['id' => $userId, 'username' => $username, 'email' => $email, 'status' => 'active', 'role' => 'user'];
        $token = bm_user_api_issue_token($pdo, $userId);
        bm_user_api_ensure_watchlist($pdo);

        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'message' => 'ثبت‌نام با موفقیت انجام شد',
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => ['watchlist' => 0],
        ], 201);
    }

    if ($action === 'me') {
        $userRow = bm_user_api_current_user($pdo, true);
        $token = bm_user_api_bearer();
        $extend = $pdo->prepare('UPDATE user_sessions SET expires_at = ? WHERE session_token = ?');
        $extend->execute([date('Y-m-d H:i:s', time() + 30 * 86400), $token]);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
            'features' => bm_user_api_features(),
            'vip' => bm_user_api_wp_sales(),
        ]);
    }

    if ($action === 'logout') {
        bm_user_api_require_post();
        $token = bm_user_api_bearer();
        if ($token !== '') {
            $stmt = $pdo->prepare('DELETE FROM user_sessions WHERE session_token = ?');
            $stmt->execute([$token]);
        }
        bm_user_api_json(['status' => 'ok', 'success' => true]);
    }

    if ($action === 'avatar_update') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        $key = trim((string)bm_user_api_param('avatar_key', ''));
        $allowed = array_column(bm_user_api_avatar_catalog(), 'key');
        if (!in_array($key, $allowed, true)) bm_user_api_error('آواتار انتخاب‌شده معتبر نیست');
        $oldAvatar = trim((string)($userRow['avatar'] ?? ''));
        if (bm_user_api_is_custom_avatar($oldAvatar)) {
            $oldFile = __DIR__ . '/' . ltrim($oldAvatar, '/');
            if (is_file($oldFile)) @unlink($oldFile);
        }
        $relative = 'assets/avatars/' . $key . '.webp';
        $stmt = $pdo->prepare('UPDATE users SET avatar_key = ?, avatar = ? WHERE id = ?');
        $stmt->execute([$key, $relative, (int)$userRow['id']]);
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1'); $stmt->execute([(int)$userRow['id']]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'آواتار ذخیره شد','user'=>bm_user_api_public_user($stmt->fetch(PDO::FETCH_ASSOC) ?: $userRow)]);
    }

    if ($action === 'avatar_upload') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        if (!bm_user_api_is_vip($userRow)) bm_user_api_error('آپلود آواتار اختصاصی فقط برای اعضای VIP فعال است', 403);
        $encoded = preg_replace('~^data:image/[A-Za-z0-9.+-]+;base64,~i', '', trim((string)bm_user_api_param('image_base64', ''))) ?? '';
        if ($encoded === '' || strlen($encoded) > 6 * 1024 * 1024) bm_user_api_error('فایل آواتار معتبر نیست یا بیش از حد بزرگ است');
        $bytes = base64_decode($encoded, true);
        if (!is_string($bytes) || $bytes === '' || strlen($bytes) > 4 * 1024 * 1024) bm_user_api_error('حجم آواتار باید کمتر از ۴ مگابایت باشد');
        $info = @getimagesizefromstring($bytes);
        if (!is_array($info)) bm_user_api_error('فایل انتخاب‌شده تصویر معتبر نیست');
        $width = (int)($info[0] ?? 0);
        $height = (int)($info[1] ?? 0);
        if ($width < 64 || $height < 64 || $width > 4096 || $height > 4096) bm_user_api_error('ابعاد آواتار باید بین ۶۴ تا ۴۰۹۶ پیکسل باشد');
        $mime = strtolower((string)($info['mime'] ?? ''));
        $ext = match ($mime) {
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
            'image/gif' => 'gif',
            default => '',
        };
        if ($ext === '') bm_user_api_error('فرمت تصویر پشتیبانی نمی‌شود');
        $dir = __DIR__ . '/uploads/avatars';
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) bm_user_api_error('پوشه آواتار قابل ساخت نیست', 500);
        $name = 'app_' . (int)$userRow['id'] . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $relative = 'uploads/avatars/' . $name;
        $target = $dir . '/' . $name;
        if (@file_put_contents($target, $bytes, LOCK_EX) === false) bm_user_api_error('ذخیره آواتار روی سرور انجام نشد', 500);
        @chmod($target, 0644);
        $oldAvatar = trim((string)($userRow['avatar'] ?? ''));
        $stmt = $pdo->prepare('UPDATE users SET avatar_key = NULL, avatar = ? WHERE id = ?');
        $stmt->execute([$relative, (int)$userRow['id']]);
        if (bm_user_api_is_custom_avatar($oldAvatar) && $oldAvatar !== $relative) {
            $oldFile = __DIR__ . '/' . ltrim($oldAvatar, '/');
            if (is_file($oldFile)) @unlink($oldFile);
        }
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1'); $stmt->execute([(int)$userRow['id']]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'آواتار اختصاصی ذخیره شد','user'=>bm_user_api_public_user($stmt->fetch(PDO::FETCH_ASSOC) ?: $userRow)]);
    }

    if ($action === 'comment_media_catalog') {
        bm_user_api_json(['status'=>'ok','success'=>true,'packs'=>bm_user_api_comment_media_catalog()]);
    }

    if ($action === 'comments_list') {
        bm_user_api_require_post();
        if (!bm_user_api_feature_enabled('comments_enabled', true)) bm_user_api_error('بخش دیدگاه‌ها موقتاً غیرفعال است', 403);
        bm_user_api_ensure_comment_schema($pdo);
        $userRow = bm_user_api_current_user($pdo, false);
        $commentItem = bm_user_api_comment_item();
        $ctx = bm_user_api_comment_context($pdo, $commentItem);
        try { bm_user_api_upsert_external_comment_item($pdo, $ctx, $commentItem); }
        catch (Throwable $metaError) { error_log('app comment metadata: ' . $metaError->getMessage()); }
        $data = bm_user_api_comment_list($pdo, $ctx, $userRow ? (int)$userRow['id'] : 0, (int)bm_user_api_param('page',1), (int)bm_user_api_param('limit',10), $userRow && in_array(strtolower((string)($userRow['role'] ?? '')), ['admin','administrator'], true), strtolower(trim((string)bm_user_api_param('sort','latest'))));
        bm_user_api_json(array_merge(['status'=>'ok','success'=>true,'context'=>['archive'=>$ctx['archive'],'movie_id'=>$ctx['movie_id']]],$data));
    }

    if ($action === 'comment_add' || $action === 'comment_reply') {
        bm_user_api_require_post();
        if (!bm_user_api_feature_enabled('comments_enabled', true)) bm_user_api_error('ثبت دیدگاه موقتاً غیرفعال است', 403);
        if ($action === 'comment_reply' && !bm_user_api_feature_enabled('comment_replies_enabled', true)) bm_user_api_error('پاسخ به دیدگاه موقتاً غیرفعال است', 503);
        bm_user_api_ensure_comment_schema($pdo);
        $commentItem = bm_user_api_comment_item();
        $userRow = bm_user_api_current_user($pdo, true); $ctx = bm_user_api_comment_context($pdo, $commentItem);
        try { bm_user_api_upsert_external_comment_item($pdo, $ctx, $commentItem); }
        catch (Throwable $metaError) { error_log('app comment metadata: ' . $metaError->getMessage()); }
        $text = trim((string)bm_user_api_param('comment','')); $rating=(int)bm_user_api_param('rating',0); $spoiler=(int)bm_user_api_param('spoiler',0)===1?1:0;
        if (!bm_user_api_feature_enabled('comment_spoiler_enabled', true)) $spoiler = 0;
        $mediaCount = function_exists('bm_sticker_marker_count') ? bm_sticker_marker_count($text) : 0;
        if ($mediaCount > 1) bm_user_api_error('در هر دیدگاه فقط یک گیف یا استیکر می‌توانید ارسال کنید');
        $media = $mediaCount === 1 && function_exists('bm_sticker_resolve_marker') ? bm_sticker_resolve_marker($text) : null;
        if ($mediaCount === 1 && !$media) bm_user_api_error('گیف یا استیکر انتخاب‌شده معتبر نیست');
        $humanText = function_exists('bm_sticker_comment_text') ? bm_sticker_comment_text($text) : $text;
        if (mb_strlen($humanText,'UTF-8') < 3 && !$media) bm_user_api_error('متن دیدگاه باید حداقل ۳ کاراکتر باشد');
        if (mb_strlen($humanText,'UTF-8') > 500) bm_user_api_error('متن دیدگاه نباید بیشتر از ۵۰۰ کاراکتر باشد');
        if ($rating<0 || $rating>5) bm_user_api_error('امتیاز باید بین ۰ تا ۵ باشد');
        $parent = $action === 'comment_reply' ? (int)bm_user_api_param('parent_id',0) : 0;
        $parentRow = null;
        if ($parent>0) { $q=$pdo->prepare("SELECT id,user_id,username FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status!='deleted' LIMIT 1"); $q->execute([$parent,$ctx['movie_id']]); $parentRow=$q->fetch(PDO::FETCH_ASSOC); if(!$parentRow) bm_user_api_error('دیدگاه اصلی پیدا نشد',404); }
        if (!bm_user_api_privileged_comment_role((string)($userRow['role'] ?? ''))) {
            bm_user_api_comment_rate_limit($pdo, (int)$userRow['id'], $text);
            $dupe=$pdo->prepare("SELECT id FROM `{$ctx['comments']}` WHERE user_id=? AND LOWER(TRIM(comment))=LOWER(TRIM(?)) AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE) AND status!='deleted' LIMIT 1");
            $dupe->execute([(int)$userRow['id'],$text]);
            if($dupe->fetchColumn()) bm_user_api_error('این متن را اخیراً ارسال کرده‌اید؛ لطفاً دیدگاه تکراری نفرستید',429);
        }
        $status = bm_user_api_comment_submit_status((string)($userRow['role'] ?? ''));
        $stmt=$pdo->prepare("INSERT INTO `{$ctx['comments']}`(movie_id,user_id,username,comment,rating,spoiler,parent_id,status,created_at) VALUES(?,?,?,?,?,?,?,?,NOW())");
        $stmt->execute([$ctx['movie_id'],(int)$userRow['id'],(string)$userRow['username'],$text,$parent>0?0:$rating,$spoiler,$parent>0?$parent:null,$status]);
        $newCommentId = (int)$pdo->lastInsertId();
        if ($parentRow && (int)($parentRow['user_id'] ?? 0) > 0 && (int)$parentRow['user_id'] !== (int)$userRow['id']) {
            bm_user_api_notify($pdo, (int)$parentRow['user_id'], 'comment_reply', 'پاسخ جدید به دیدگاه شما', (string)$userRow['username'] . ' به دیدگاه شما پاسخ داد', ['item'=>$commentItem,'comment_id'=>$newCommentId,'parent_id'=>$parent], 'reply:' . $newCommentId);
        }
        if ($ctx['archive']===2 && $status==='approved' && $parent===0) bm_user_api_update_movie_rating($pdo,(int)$ctx['movie_id']);
        bm_user_api_json(['status'=>'ok','success'=>true,'approved'=>$status==='approved','message'=>$status==='approved'?'دیدگاه با موفقیت ثبت شد':'دیدگاه پس از تأیید مدیر نمایش داده می‌شود']);
    }

    if ($action === 'comment_vote') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        if (!bm_user_api_feature_enabled('comment_votes_enabled', true)) bm_user_api_error('رأی‌دهی موقتاً غیرفعال است',503);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item());
        $commentId=(int)bm_user_api_param('comment_id',0); $type=strtolower(trim((string)bm_user_api_param('type','like')));
        if(!in_array($type,['like','dislike'],true)) bm_user_api_error('نوع رأی نامعتبر است');
        $approvedVoteStatus = bm_user_api_public_status_sql($ctx['comments']);
        $q=$pdo->prepare("SELECT id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND {$approvedVoteStatus} LIMIT 1"); $q->execute([$commentId,$ctx['movie_id']]); if(!$q->fetchColumn()) bm_user_api_error('دیدگاه پیدا نشد',404);
        $q=$pdo->prepare("SELECT type FROM `{$ctx['likes']}` WHERE comment_id=? AND user_id=? LIMIT 1"); $q->execute([$commentId,(int)$userRow['id']]); $old=(string)($q->fetchColumn()?:'');
        if($old===$type){$d=$pdo->prepare("DELETE FROM `{$ctx['likes']}` WHERE comment_id=? AND user_id=?");$d->execute([$commentId,(int)$userRow['id']]);$new='';}
        else{$u=$pdo->prepare("INSERT INTO `{$ctx['likes']}`(comment_id,user_id,type,created_at) VALUES(?,?,?,NOW()) ON DUPLICATE KEY UPDATE type=VALUES(type)");$u->execute([$commentId,(int)$userRow['id'],$type]);$new=$type;}
        $c=$pdo->prepare("SELECT SUM(type='like'),SUM(type='dislike') FROM `{$ctx['likes']}` WHERE comment_id=?");$c->execute([$commentId]);$v=$c->fetch(PDO::FETCH_NUM)?:[0,0];
        bm_user_api_json(['status'=>'ok','success'=>true,'user_vote'=>$new,'like_count'=>(int)$v[0],'dislike_count'=>(int)$v[1]]);
    }

    if ($action === 'comment_report') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        if (!bm_user_api_feature_enabled('comment_reports_enabled', true)) bm_user_api_error('گزارش دیدگاه موقتاً غیرفعال است',503);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item());
        $commentId=(int)bm_user_api_param('comment_id',0);
        $reason=trim((string)bm_user_api_param('reason','other'));
        $details=trim((string)bm_user_api_param('details',''));
        $allowed=['spoiler','insult','spam','illegal','other']; if(!in_array($reason,$allowed,true)) $reason='other';
        $q=$pdo->prepare("SELECT user_id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status!='deleted' LIMIT 1"); $q->execute([$commentId,$ctx['movie_id']]); $owner=(int)($q->fetchColumn()?:0);
        if($owner<=0) bm_user_api_error('دیدگاه پیدا نشد',404);
        if($owner===(int)$userRow['id']) bm_user_api_error('امکان گزارش دیدگاه خودتان وجود ندارد',422);
        $stmt=$pdo->prepare("INSERT INTO comment_reports(archive_no,movie_id,comment_id,reporter_user_id,reason,details,status,created_at) VALUES(?,?,?,?,?,?,'open',NOW()) ON DUPLICATE KEY UPDATE reason=VALUES(reason),details=VALUES(details),status='open'");
        $stmt->execute([(int)$ctx['archive'],(int)$ctx['movie_id'],$commentId,(int)$userRow['id'],$reason,mb_substr($details,0,500,'UTF-8')]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'گزارش شما ثبت شد و توسط مدیریت بررسی می‌شود']);
    }

    if ($action === 'comment_edit') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item());
        $id=(int)bm_user_api_param('comment_id',0); $text=trim((string)bm_user_api_param('comment',''));
        $spoiler=(int)bm_user_api_param('spoiler',0)===1?1:0;
        if (!bm_user_api_feature_enabled('comment_spoiler_enabled', true)) $spoiler=0;
        $mediaCount=function_exists('bm_sticker_marker_count')?bm_sticker_marker_count($text):0;
        $media=$mediaCount===1&&function_exists('bm_sticker_resolve_marker')?bm_sticker_resolve_marker($text):null;
        $humanText=function_exists('bm_sticker_comment_text')?bm_sticker_comment_text($text):$text;
        if($mediaCount>1||($mediaCount===1&&!$media)) bm_user_api_error('گیف یا استیکر انتخاب‌شده معتبر نیست',422);
        if((mb_strlen($humanText,'UTF-8')<3&&!$media)||mb_strlen($humanText,'UTF-8')>500) bm_user_api_error('متن دیدگاه باید بین ۳ تا ۵۰۰ کاراکتر باشد',422);
        $q=$pdo->prepare("SELECT * FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? AND status!='deleted' LIMIT 1");$q->execute([$id,$ctx['movie_id']]);$row=$q->fetch(PDO::FETCH_ASSOC);
        if(!$row) bm_user_api_error('دیدگاه پیدا نشد',404);
        $isAdmin=in_array(strtolower((string)($userRow['role']??'')),['admin','administrator'],true);
        $minutes=(int)(bm_user_api_features()['comment_edit_minutes']??10);
        $created=strtotime((string)($row['created_at']??''))?:0;
        $allowed=$isAdmin || ((int)($row['user_id']??0)===(int)$userRow['id'] && $minutes>0 && $created>0 && time()<=$created+$minutes*60);
        if(!$allowed) bm_user_api_error('زمان مجاز ویرایش این دیدگاه به پایان رسیده است',403);
        $h=$pdo->prepare('INSERT INTO comment_edit_history(archive_no,comment_id,editor_user_id,old_comment,old_spoiler,edited_at) VALUES(?,?,?,?,?,NOW())');
        $h->execute([(int)$ctx['archive'],$id,(int)$userRow['id'],(string)$row['comment'],(int)($row['spoiler']??0)]);
        $u=$pdo->prepare("UPDATE `{$ctx['comments']}` SET comment=?,spoiler=?,edited_at=NOW() WHERE id=? AND movie_id=?");$u->execute([$text,$spoiler,$id,$ctx['movie_id']]);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'دیدگاه ویرایش شد']);
    }

    if ($action === 'comment_pin') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true);
        if(!in_array(strtolower((string)($userRow['role']??'')),['admin','administrator'],true)) bm_user_api_error('پین‌کردن فقط برای مدیر فعال است',403);
        $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item()); $id=(int)bm_user_api_param('comment_id',0); $pinned=(int)bm_user_api_param('pinned',1)===1?1:0;
        $u=$pdo->prepare("UPDATE `{$ctx['comments']}` SET is_pinned=?,pinned_at=IF(?=1,NOW(),NULL) WHERE id=? AND movie_id=? AND status!='deleted'");
        $u->execute([$pinned,$pinned,$id,$ctx['movie_id']]);
        if($u->rowCount()<1) bm_user_api_error('دیدگاه پیدا نشد',404);
        bm_user_api_json(['status'=>'ok','success'=>true,'is_pinned'=>$pinned===1,'message'=>$pinned?'دیدگاه پین شد':'پین دیدگاه برداشته شد']);
    }

    if ($action === 'notifications_list') {
        bm_user_api_require_post(); $userRow=bm_user_api_current_user($pdo,true); bm_user_api_ensure_notification_schema($pdo);
        $uid=(int)$userRow['id']; bm_user_api_sync_remote_notifications($pdo,$uid); bm_user_api_sync_global_admin_notifications($pdo,$uid);
        $page=max(1,(int)bm_user_api_param('page',1)); $limit=max(1,min(50,(int)bm_user_api_param('limit',30))); $offset=($page-1)*$limit;
        $stmt=$pdo->prepare("SELECT n.*, GREATEST(0, TIMESTAMPDIFF(SECOND, n.created_at, NOW())) AS age_seconds FROM app_notifications n WHERE n.user_id=? AND n.dismissed_at IS NULL ORDER BY n.created_at DESC,n.id DESC LIMIT $limit OFFSET $offset"); $stmt->execute([$uid]);
        $items=[]; foreach($stmt->fetchAll(PDO::FETCH_ASSOC)?:[] as $row){$target=json_decode((string)($row['target_json']??''),true);$age=(int)($row['age_seconds']??0);$items[]=['id'=>(int)$row['id'],'type'=>(string)$row['type'],'title'=>(string)$row['title'],'message'=>(string)$row['message'],'target'=>is_array($target)?$target:[],'is_read'=>!empty($row['read_at']),'date_text'=>bm_user_api_relative_time($age),'age_seconds'=>$age,'created_at'=>(string)$row['created_at']];}
        $count=$pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=? AND dismissed_at IS NULL');$count->execute([$uid]);
        bm_user_api_json(['status'=>'ok','success'=>true,'items'=>$items,'total'=>(int)$count->fetchColumn(),'stats'=>bm_user_api_stats($pdo,$uid)]);
    }

    if ($action === 'notification_delete' || $action === 'notifications_clear') {
        bm_user_api_require_post(); $userRow=bm_user_api_current_user($pdo,true); bm_user_api_ensure_notification_schema($pdo); $uid=(int)$userRow['id'];
        if($action==='notification_delete'){
            $id=(int)bm_user_api_param('notification_id',0);
            if($id<=0) bm_user_api_error('شناسه اعلان معتبر نیست',422);
            $d=$pdo->prepare('UPDATE app_notifications SET dismissed_at=NOW(),read_at=COALESCE(read_at,NOW()),is_read=1 WHERE id=? AND user_id=?');
            $d->execute([$id,$uid]);
        } else {
            $d=$pdo->prepare('UPDATE app_notifications SET dismissed_at=NOW(),read_at=COALESCE(read_at,NOW()),is_read=1 WHERE user_id=? AND dismissed_at IS NULL');
            $d->execute([$uid]);
        }
        bm_user_api_json(['status'=>'ok','success'=>true,'deleted'=>(int)$d->rowCount(),'stats'=>bm_user_api_stats($pdo,$uid)]);
    }

    if ($action === 'notification_read' || $action === 'notifications_read_all') {
        bm_user_api_require_post(); $userRow=bm_user_api_current_user($pdo,true); bm_user_api_ensure_notification_schema($pdo); $uid=(int)$userRow['id'];
        if($action==='notification_read'){ $id=(int)bm_user_api_param('notification_id',0); $stmt=$pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()),is_read=1 WHERE id=? AND user_id=?');$stmt->execute([$id,$uid]); }
        else { $stmt=$pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()),is_read=1 WHERE user_id=?');$stmt->execute([$uid]); }
        bm_user_api_json(['status'=>'ok','success'=>true,'stats'=>bm_user_api_stats($pdo,$uid)]);
    }

    if ($action === 'comment_delete') {
        bm_user_api_require_post(); bm_user_api_ensure_comment_schema($pdo);
        $userRow=bm_user_api_current_user($pdo,true); $ctx=bm_user_api_comment_context($pdo,bm_user_api_comment_item()); $id=(int)bm_user_api_param('comment_id',0);
        $q=$pdo->prepare("SELECT user_id,parent_id FROM `{$ctx['comments']}` WHERE id=? AND movie_id=? LIMIT 1");$q->execute([$id,$ctx['movie_id']]);$row=$q->fetch(PDO::FETCH_ASSOC);
        if(!$row) bm_user_api_error('دیدگاه پیدا نشد',404);
        if(!in_array((string)$userRow['role'], ['admin','administrator'], true)) bm_user_api_error('حذف دیدگاه فقط برای مدیر فعال است',403);
        $u=$pdo->prepare("UPDATE `{$ctx['comments']}` SET status='deleted' WHERE id=? OR parent_id=?");$u->execute([$id,$id]);
        if($ctx['archive']===2 && empty($row['parent_id'])) bm_user_api_update_movie_rating($pdo,(int)$ctx['movie_id']);
        bm_user_api_json(['status'=>'ok','success'=>true,'message'=>'دیدگاه حذف شد']);
    }

    if ($action === 'watchlist_list') {
        $userRow = bm_user_api_current_user($pdo, true);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        $items = bm_user_api_watchlist_items($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $items,
            'count' => count($items),
        ]);
    }

    if ($action === 'watchlist_sync') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        $userId = (int)$userRow['id'];
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, $userId);

        $body = bm_user_api_body();
        $removed = is_array($body['removed_keys'] ?? null) ? $body['removed_keys'] : [];
        $items = is_array($body['items'] ?? null) ? $body['items'] : [];

        $pdo->beginTransaction();
        try {
            foreach (array_slice($removed, 0, 500) as $key) {
                $key = substr(trim((string)$key), 0, 190);
                if ($key !== '') bm_user_api_remove_app_item($pdo, $userId, $key);
            }
            foreach (array_slice($items, 0, 500) as $item) {
                if (is_array($item)) bm_user_api_upsert_app_item($pdo, $userId, $item);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        $merged = bm_user_api_watchlist_items($pdo, $userId);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $merged,
            'count' => count($merged),
        ]);
    }

    bm_user_api_error('Unknown action', 404);
} catch (PDOException $e) {
    error_log('app_user_api database error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت پایگاه داده', 500);
} catch (Throwable $e) {
    if (isset($action) && is_string($action) && str_starts_with($action, 'watch_party_') && function_exists('bm_user_api_wp_exception')) {
        bm_user_api_wp_exception($e);
    }
    error_log('app_user_api error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت سرور', 500);
}
