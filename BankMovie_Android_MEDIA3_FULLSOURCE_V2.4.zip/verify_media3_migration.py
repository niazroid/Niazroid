#!/usr/bin/env python3
"""Static gate only. A real release build + device playback regression is still required."""
from pathlib import Path
root = Path(__file__).resolve().parent
b = (root/'app/build.gradle').read_text()
p = (root/'app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
bridge = (root/'app/src/main/java/ir/bankmoviee/app/Media3PlaybackBridge.kt').read_text()
layout = (root/'app/src/main/res/layout/activity_player.xml').read_text()
assert "org.videolan.android:libvlc" not in b
assert all(f'media3-{component}' in b for component in ('exoplayer', 'ui'))
assert 'import org.videolan.' not in p
assert 'Media3VideoLayout(this)' in p
assert 'val mp = Media3Player(lib)' in p
assert 'Media3Player.Event.Playing' in p
assert 'SubtitleTrackType.Subtitle' in p
assert 'getAudioTracks()' in bridge and 'getSpuTracks()' in bridge
assert 'setSpuDelay(' in bridge and 'addSlave(' in bridge
assert 'TrackSelectionOverride' in bridge and 'onCues(' in bridge
assert 'org.videolan.libvlc.util.VLCVideoLayout' not in layout
print('MEDIA3_SOURCE_STATIC_CHECKS_OK (not a compile or playback test)')
