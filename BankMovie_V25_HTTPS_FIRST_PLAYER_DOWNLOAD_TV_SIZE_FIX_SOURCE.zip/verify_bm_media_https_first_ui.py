#!/usr/bin/env python3
"""Static regression guard: NOT a device/real URL playback test."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).parent
src=root/'app/src/main/java/ir/bankmoviee/app'
main=(src/'MainActivity.kt').read_text()
player=(src/'PlayerActivity.kt').read_text()
bridge=(src/'Media3PlaybackBridge.kt').read_text()
down=(src/'InternalDownloadService.kt').read_text()
policy=(src/'MediaOnlyTransportPolicy.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
xml=(root/'app/src/main/res/xml/network_security_config.xml')
ET.parse(xml)
assert 'cleartextTrafficPermitted="true"' in xml.read_text()
assert 'usesCleartextTraffic="true"' in manifest
assert 'app_api.php' in policy and 'auth' in policy and 'account' in policy
assert 'fun httpsFirst(raw: String)' in policy
assert 'fun httpForPlayer(' in policy
assert 'signed HTTPS playback URLs' in policy
assert 'SSLException' in policy and 'CertificateException' in policy
assert 'httpMediaFallbackApplied' in player
assert 'MediaOnlyTransportPolicy.httpsFirst(clean)' in player
assert 'MediaOnlyTransportPolicy.isTlsFailure(event.error)' in player
assert 'verifySslBeforeMediaHttp(videoUrl, fallback)' in player
assert 'MediaOnlyTransportPolicy.httpForPlayer(' in player
assert 'httpMediaFallbackApplied = false' in player
assert 'onPlayerError(error: PlaybackException)' in bridge
assert 'error = error' in bridge
assert 'httpsFirstDownloadConnection(source)' in down
assert 'canUseOriginalHttpDownload(source)' in down
assert 'if (!MediaOnlyTransportPolicy.canUseOriginalHttpDownload(source)) return connect(source)' in down
assert 'HTTPS redirect attempted a cleartext downgrade' in down
assert 'normalizedDownloadSize(link.optString("size"))' in main
assert 'val resolution = Regex(' in main
block=main.split('private fun downloadQualityRow(',1)[1].split('private fun movieVersionPanel(',1)[0]
assert 'فصل' not in block and 'قسمت' not in block
assert 'optString("label").takeIf' not in block
assert 'fileSize.isNotBlank()' in block and 'isTvLike()' in block
print('BANKMOVIE_MEDIA_HTTPS_FIRST_UI_STATIC_OK')
