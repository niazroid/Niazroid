#!/usr/bin/env python3
"""Verify the public ad image route and UI fallback without Android SDK."""
import base64, json, re, subprocess, tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parent
ADMIN=(ROOT/'server-required/bm_admin.php').read_text()
APP=(ROOT/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
CONFIG=(ROOT/'server-required/app_config.php').read_text()
IMAGE=(ROOT/'server-required/app_ad_image.php').read_bytes()
assert 'private fun appAdArtworkUrl(' in APP
assert 'bm_home_ad_image_fallback' in APP
assert 'loadImage(artworkUrl, image)' in APP
assert 'bankGlassDrawable(26, 208, 103, true)' in APP
assert '@mkdir($uploadDir, 0755, true)' in ADMIN
assert '@chmod($uploadDir, 0755)' in ADMIN
assert 'bmAdPreviewImageError' in ADMIN and 'URL.createObjectURL(file)' in ADMIN
assert "'/app_ad_image.php?v='" in CONFIG
with tempfile.TemporaryDirectory() as tmp:
    root=Path(tmp)
    path=root/'uploads'/'bm-app-ads';path.mkdir(parents=True)
    (root/'app_ad_image.php').write_bytes(IMAGE)
    name='1234567890abcdef1234567890ab.png'
    picture=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAMAAAADCAIAAADZSiLoAAAAF0lEQVR4nGP0nf2KgYGBgYGBiQEGECwAMtMB2DIloQUAAAAASUVORK5CYII=')
    (path/name).write_bytes(picture)
    path.chmod(0o750)
    config=root/'bankmovie_remote_config.json'
    config.write_text(json.dumps({'home_ad':{'image_url':'/uploads/bm-app-ads/'+name}}))
    result=subprocess.run(['php',str(root/'app_ad_image.php')],capture_output=True,check=True)
    assert result.stdout==picture, 'Public endpoint failed to stream actual image'
    config.write_text(json.dumps({'home_ad':{'image_url':'/uploads/bm-app-ads/../../etc/passwd'}}))
    result=subprocess.run(['php',str(root/'app_ad_image.php')],capture_output=True)
    assert result.stdout == b'', 'Image endpoint allows an arbitrary file path'
    config.write_text(json.dumps({'home_ad':{'image_url':'https://othersite.example/image.png'}}))
    result=subprocess.run(['php',str(root/'app_ad_image.php')],capture_output=True)
    assert result.stdout == b'', 'Public endpoint served a file outside the configured ad'
print('BANKMOVIE_V24_AD_GLASS_IMAGE_ENDPOINT_OK')
