#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
src=Path('app/src/main/java/ir/bankmoviee/app')
notice=(src/'BmNotice.kt').read_text()
limit=(src/'BmApiRateLimit.kt').read_text()
main=(src/'MainActivity.kt').read_text()
client=(src/'BmV22Client.kt').read_text()
account=(src/'AccountApi.kt').read_text()
server=Path('server-required/v2/api/bm_security.php').read_text()
workflow=Path('.github/workflows/build-bankmovie.yml').read_text()
assert 'fun showRateLimited(' in notice
assert 'if (BmApiRateLimit.isLimitMessage(message)) return' in notice
for needle in ('لطفاً کمی آرام‌تر!', 'تا تلاش بعدی', 'setTextColor(accent)',
               '7_000L', 'remainingSeconds().coerceAtLeast(0)', 'BankmovieFonts.bold(activity)'):
    assert needle in notice, needle
for needle in ('Retry-After', 'retry_after', '60', 'remainingSeconds()',
               'NOTICE_INTERVAL_MS', 'SystemClock.elapsedRealtime()', 'BmNotice.showRateLimited(context)'):
    assert needle in limit, needle
assert 'if (code == 429)' in main
assert 'BmApiRateLimit.report(this@MainActivity, c.getHeaderField("Retry-After"), body)' in main
assert 'BmApiRateLimit.isLimitMessage(err)' in main
assert 'if (!BmApiRateLimit.isLimitMessage(message)) updateArchiveHealth' in main
assert 'BmApiRateLimit.report(this@MainActivity, connection.getHeaderField("Retry-After"), body)' in main
assert 'BmApiRateLimit.isSecurityLimitResponse(' in account
assert 'BmApiRateLimit.isLimitMessage(error.message)' in account
assert 'BmApiRateLimit.report(context, conn.getHeaderField("Retry-After"), response)' in client
# Enforced 429 and time-to-retry survive; client does not disable these guards.
# V22.5 meters real signed user-intended requests; no synthetic click events.
assert "bm22_fail(429,'user_action_rate_limited',$retry)" in server
assert 'bm22_billable_request_key($endpoint)' in server
assert 'bm22_limit_content_open(' in server
assert "header('Retry-After: ' . $retryAfter)" in server
assert 'bm22_guard(' in server
assert 'verify_v22_2_rate_limit_toast.sh' in workflow
assert 'SOURCE_ZIP: BankMovie_Android_FULLSOURCE_V2.4_REAL_API_QUOTA_V22_5.zip' in workflow
print('PASS: friendly server-timed 429 toast, no mirror failover or archive retry, device auth retained')
PY
bash verify_v22_1_tv_tls_compat.sh
