#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
TEMP=$(mktemp -d)
trap 'rm -rf "$TEMP"' EXIT
cp server-required/v2/api/bm_security.php "$TEMP/bm_security.php"
mkdir -p "$TEMP/.private"
cat > "$TEMP/test_click_quota.php" <<'PHP'
<?php
error_reporting(E_ALL);
require __DIR__.'/bm_security.php';
$_SERVER['REMOTE_ADDR']='192.0.2.10';
$_SERVER['HTTPS']='on';
$_SERVER['REQUEST_METHOD']='GET';
function checkRequest(string $endpoint,array $query, bool $billable): void {
    $_GET=$query;
    $key=bm22_content_open_key($endpoint);
    assert(($key!==null)===$billable, "Incorrect classification: ".$endpoint.' '.json_encode($query));
}
// Nothing fetched automatically, in navigation or during search is billable.
foreach (['app_user_api','app_home_feed','app_config','api_discover','api_explorer','api_boxoffice'] as $endpoint) {
    checkRequest($endpoint,['action'=>'detail','id'=>'tt100'],false);
}
foreach (['home','section','search','live_search','search_suggest','play','collections','actor','ping'] as $action) {
    checkRequest('app_api',['action'=>$action,'archive'=>'1','id'=>'tt100'],false);
}
checkRequest('app_api',['action'=>'detail','archive'=>'1'],false);
checkRequest('app_api',['action'=>'detail','archive'=>'1','id'=>'tt100'],true);
foreach (['api4','api5','api6','api2','archive1_live'] as $endpoint) {
    checkRequest($endpoint,['section'=>'new_movies','page'=>'1'],false);
    checkRequest($endpoint,['s'=>'avengers','page'=>'1'],false);
    checkRequest($endpoint,['id'=>'tt100'],true);
}
checkRequest('api5',['archive5'=>'1','id'=>'tt100'],true);
checkRequest('api4',['subtitle_url'=>'https://x.example/srt','id'=>'tt100'],false);
$_SERVER['REQUEST_METHOD']='POST';
$_POST=['action'=>'detail','id'=>'tt100'];
checkRequest('app_api',[],true); // POST details cannot escape charging.
$_POST=[];
checkRequest('api5',['id'=>'tt100'],false); // dedicated APIs have no POST detail.
$_SERVER['REQUEST_METHOD']='GET';
checkRequest('app_api',['fn'=>'detail','id'=>'tt100'],true);
$policy=bm22_policy();
assert($policy['limit_per_minute']===50);
assert(bm22_save_policy(array_merge($policy,['limit_per_minute'=>10])));
assert(bm22_policy()['limit_per_minute']===10);
$install='abc-unique-installation-for-tests';
// Simulate 400 initial browse / search / config requests and ensure none are
// charged to the user's detail quota; this is the exact V22 regression.
for($i=0;$i<400;$i++) {
    $_GET=['action'=>'section','archive'=>'1','page'=>(string)$i];
    assert(bm22_content_open_key('app_api')===null);
}
// Ten DIFFERENT movie detail taps are allowed at the configured threshold.
for($i=1;$i<=10;$i++) {
    $_GET=['action'=>'detail','archive'=>'1','id'=>'tt'.(30000+$i)];
    $key=bm22_content_open_key('app_api');
    assert(is_string($key));
    assert(bm22_limit_content_open($install,$key,10,60)===0);
    // Technical retry for same movie never consumes a second slot.
    assert(bm22_limit_content_open($install,$key,10,60)===0);
}
$_GET=['action'=>'detail','archive'=>'1','id'=>'tt30011'];
$extra=bm22_limit_content_open($install,bm22_content_open_key('app_api'),10,60);
assert($extra>0 && $extra<=60);
// Another request for a title that just loaded is still allowed.
$_GET=['action'=>'detail','archive'=>'1','id'=>'tt30010'];
assert(bm22_limit_content_open($install,bm22_content_open_key('app_api'),10,60)===0);
// No user identifier is stored in plain text.
$path=__DIR__.'/.private/open_'.hash('sha256',$install).'.php';
$body=file_get_contents($path);
assert(!str_contains($body,'tt30010') && str_starts_with($body,'<?php http_response_code(404);'));
echo "PASS: only content detail opens charged; retries deduped; 10/min 11th=429; no DB\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$TEMP/test_click_quota.php"
php -l server-required/v2/api/bm_security.php >/dev/null
python3 - <<'PY'
from pathlib import Path
r=Path('app/src/main/java/ir/bankmoviee/app')
code=(r/'BmApiRateLimit.kt').read_text()
assert 'content_open_rate_limited' in code
assert 'fun isContentOpen(url: URL)' in code
assert 'fun requireContentOpenAllowed(url: URL)' in code
main=(r/'MainActivity.kt').read_text()
assert 'BmApiRateLimit.requireContentOpenAllowed(u)' in main
assert 'BmApiRateLimit.report(this@MainActivity' in main
assert 'BmNotice.showRateLimited' in code
admin=Path('server-required/bm_admin.php').read_text()
assert 'سقف اقدام کاربر برای هر نصب' in admin
assert 'چی ببینیم؟' in admin
print('PASS: app native 429 notice and admin quota semantics')
PY
