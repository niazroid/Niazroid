#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
T=$(mktemp -d)
trap 'rm -rf "$T"' EXIT
cp server-required/v2/api/bm_security.php "$T/bm_security.php"
mkdir "$T/.private"
cat > "$T/test.php" <<'PHP'
<?php
require __DIR__.'/bm_security.php';
$policy=bm22_policy();
assert($policy['limit_per_minute'] === 50);
assert(bm22_save_policy(array_merge($policy,['limit_per_minute'=>10])));
assert(bm22_policy()['limit_per_minute']===10);
$installation='test-install-one';
$_SERVER['REQUEST_METHOD']='GET';
// Automatic requests may come in large volumes and still cost zero slots.
for ($i=0;$i<200;$i++) {
    $_GET=['action'=>'section','page'=>(string)$i,'archive'=>'1'];
    assert(bm22_content_open_key('app_api') === null);
}
// The new app signs its own detail tap id; automatic detail reads remain free.
$_GET=['action'=>'detail','id'=>'tt7777','bm_v224_click_reported'=>'1'];
assert(bm22_content_open_key('app_api') === null);
$tapId='00000000-0000-4000-8000-000000000007';
$_GET=['action'=>'detail','id'=>'tt7777','bm_v224_click_reported'=>'1','bm_v224_click_id'=>$tapId];
assert(is_string(bm22_content_open_key('app_api')));
// Six explicit UI taps, each with a unique UUID receipt (same atomic ledger).
for ($i=0;$i<6;$i++) {
    $receipt=hash('sha256','ui|archive|'.sprintf('00000000-0000-4000-8000-%012d',$i));
    assert(bm22_limit_content_open($installation,$receipt,10,60)===0);
    assert(bm22_limit_content_open($installation,$receipt,10,60)===0); // retry idem
}
// Four different films occupy the remaining slots.
for ($i=0;$i<4;$i++) {
    $_GET=['action'=>'detail','id'=>'tt'.(8000+$i),'bm_v224_click_reported'=>'1',
           'bm_v224_click_id'=>sprintf('00000000-0000-4000-8000-%012d',100+$i)];
    $key=bm22_content_open_key('app_api');
    assert(is_string($key));
    assert(bm22_limit_content_open($installation,$key,10,60)===0);
}
$extra=hash('sha256','ui|avatar|unique-11th-click');
$retry=bm22_limit_content_open($installation,$extra,10,60);
assert($retry > 0 && $retry <= 60);
$_GET=['action'=>'home'];
assert(bm22_content_open_key('app_api')===null);
$_GET=['action'=>'detail','id'=>'tt8001','bm_v224_click_reported'=>'1'];
assert(bm22_content_open_key('app_api')===null);
// No raw user identifier, movie identifier or untrusted event body persisted.
$file=__DIR__.'/.private/open_'.hash('sha256',$installation).'.php';
$data=file_get_contents($file);
assert(str_starts_with($data,'<?php http_response_code(404);'));
assert(!str_contains($data,'tt8000') && !str_contains($data,'archive'));
echo "PASS: 6 UI taps + 4 content opens = 10; next denied; background free; no DB\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$T/test.php"
php -l server-required/v2/api/action.php >/dev/null
php -l server-required/v2/api/bm_security.php >/dev/null
php -l server-required/bm_admin.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
r=Path('app/src/main/java/ir/bankmoviee/app')
main=(r/'MainActivity.kt').read_text()
client=(r/'BmV22Client.kt').read_text()
tracker=(r/'BmUserActions.kt').read_text()
security=Path('server-required/v2/api/bm_security.php').read_text()
action=Path('server-required/v2/api/action.php').read_text()
admin=Path('server-required/bm_admin.php').read_text()
workflow=Path('.github/workflows/build-bankmovie.yml').read_text()
assert 'action.php' in client
assert 'BmV22Client.attach(appContext, conn, address, "POST", payload)' in tracker
assert 'UUID.randomUUID()' in tracker
assert 'bm_v224_click_reported=1' in main
assert 'bm_v224_click_id=' in main
assert 'countUserTap = false' in main
assert 'params["bm_v224_click_reported"] == "1"' in (r/'BmApiRateLimit.kt').read_text()
assert "bm22_guard('action')" in action
assert 'bm22_limit_content_open' in action
assert "bm22_fail(429,'user_action_rate_limited',$retry)" in security
for kind in ['discover','discover_section','category','category_item','collection','collection_item',
             'archive','avatar','watchlist','watchlist_change','comment','filter','filter_apply','section','more']:
    assert f'recordQuotaAction("{kind}")' in main,kind
assert 'سقف اقدام کاربر برای هر نصب' in admin
assert 'SOURCE_ZIP: BankMovie_Android_FULLSOURCE_V2.4_USER_ACTION_QUOTA_V22_4.zip' in workflow
assert 'verify_v22_4_user_actions.sh' in workflow
assert not (Path('server-required/v2/api/.private/signing.php')).exists()
print('PASS: signed action events, app click hooks, panel wording, 429, workflow')
PYTEST
