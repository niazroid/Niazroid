package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.Manifest
import android.content.Intent
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.AnimatedImageDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.util.Base64
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private data class ServerEndpoint(
        val name: String,
        val apiUrl: String,
        val contentDomain: String
    )

    private data class UrlRewriteRule(
        val from: String,
        val to: String,
        val mode: String,
        val enabled: Boolean
    )


    private data class AdvancedOption(
        val value: String,
        val label: String
    )

    private data class ArchiveHealthState(
        var consecutiveFailures: Int = 0,
        var lastSuccessAt: Long = 0L,
        var lastFailureAt: Long = 0L,
        var lastMessage: String = ""
    )

    private data class GenreCategory(
        val key: String,
        val label: String,
        val query: String,
        val hint: String = ""
    )

    private data class AdvancedSearchState(
        val archive: Int,
        var query: String = "",
        var type: String = "all",
        var genreValue: String = "",
        var genreLabel: String = "",
        var yearFrom: String = "",
        var yearTo: String = "",
        var countryValue: String = "",
        var countryLabel: String = "",
        var sortValue: String = "",
        var sortLabel: String = "",
        var ratingValue: String = "",
        var ratingLabel: String = "",
        var exactYear: String = "",
        var director: String = "",
        var actor: String = "",
        var language: String = "",
        var playOnline: Boolean = false,
        var dubbed: Boolean = false,
        var subtitle: Boolean = false
    )

    private var apiBase = AppConfig.APP_API_URL
    private val apiServers = mutableListOf<ServerEndpoint>()
    private val urlRewriteRules = mutableListOf<UrlRewriteRule>()
    private var activeServerName = "main"
    private val appConfigUrl = AppConfig.CONFIG_URL_PRIMARY
    private fun appConfigCandidates(): List<String> {
        val cachedDomain = appPrefs().getString("active_domain", "").orEmpty().trimEnd('/')
        val cachedAccount = appPrefs().getString("account_api_url", "").orEmpty()
        val fromAccount = runCatching {
            val u = URL(cachedAccount)
            "${u.protocol}://${u.host}${if (u.port > 0 && u.port != u.defaultPort) ":${u.port}" else ""}/app_config.php"
        }.getOrDefault("")
        return listOf(
            if (cachedDomain.isNotBlank()) "$cachedDomain/app_config.php" else "",
            fromAccount,
            appConfigUrl,
            AppConfig.CONFIG_URL_SECONDARY
        ).filter { it.startsWith("http", true) }.distinct()
    }
    private var activeDomain = AppConfig.BASE_DOMAIN
    private var remoteNoticeTitle = ""
    private var remoteNoticeMessage = ""
    private var remoteNoticeId = ""
    private var remoteNoticeEnabled = false
    private var remoteNoticeDismissible = true
    private var remoteNoticeTargetUrl = ""
    private var maintenanceMode = false
    private var maintenanceMessage = "اپ موقتاً در دسترس نیست."
    private var remoteVersionCode = 0
    private var remoteVersionName = ""
    private var remoteApkUrl = ""
    private var remoteForceUpdate = false
    private var remoteUpdateEnabled = true
    private var remoteUpdateTitle = "آپدیت جدید آماده است"
    private var remoteUpdateMessage = "برای تجربه بهتر نسخه جدید را نصب کنید."
    private var remoteUpdateChanges = mutableListOf<String>()
    private var remoteApkUrlUniversal = ""
    private var remoteApkUrlArm64 = ""
    private var remoteApkUrlV7a = ""
    private var versionPolicyEnabled = false
    private var minimumSupportedVersionCode = 0
    private var minimumSupportedVersionName = ""
    private val blockedVersionNames = linkedSetOf<String>()
    private val blockedVersionCodes = linkedSetOf<Int>()
    private var blockedVersionMessage = "این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید."
    private var forceUpdateBlockedVersions = true
    private var remoteRegistrationEnabled = true
    private var remoteLoginEnabled = true
    private var remoteCommentsEnabled = true
    private var remoteCommentRepliesEnabled = true
    private var remoteCommentVotesEnabled = true
    private var remoteCommentReportsEnabled = true
    private var remoteCommentSpoilerEnabled = true
    private var remoteCommentEditMinutes = 10
    private var remoteNotificationCenterEnabled = true
    private var remoteInternalDownloaderEnabled = true
    private var remoteMultipartDownloadEnabled = true
    private var remoteDownloadPathSelectionEnabled = true
    private var remoteAdvancedSearchEnabled = true
    private var remoteCategoriesEnabled = true
    private var remoteWatchlistEnabled = true
    private var remoteContinueWatchingEnabled = true
    private var remoteTvQuickMenuEnabled = true
    private var remoteArchive1Enabled = true
    private var remoteArchive2Enabled = true
    private var remoteArchive3Enabled = true
    private var remoteArchive1Hidden = false
    private var remoteArchive2Hidden = false
    private var remoteArchive3Hidden = false
    private var remoteDownloadLimit = 2
    private var remoteDownloadRetryCount = 4
    private var remoteDownloadRetryDelaySeconds = 8
    private var remoteDownloadMinFreeMb = 256
    private var remoteMultipartParts = 4
    private var latestVersionOnly = false
    private val remoteHomeSectionsArchive1 = mutableListOf<String>()
    private val remoteHomeSectionsArchive2 = mutableListOf<String>()
    private val remoteHomeSectionsArchive3 = mutableListOf<String>()
    private val tvFocusIndexByScreen = mutableMapOf<String, Int>()
    private var tvQuickMenuShowing = false
    private var activePlayableSheet: AlertDialog? = null
    private var tvFocusGraphGeneration = 0
    private val bmAppKey: String get() = AppConfig.APP_KEY
    private val bmAppSecret: String get() = AppConfig.APP_SECRET
    private val defaultArchive = 1
    private var selectedArchive = 1
    private var archive3ApiBase = AppConfig.ARCHIVE3_API_URL
    private var archive1LiveApiBase = AppConfig.ARCHIVE1_LIVE_URL
    private var archive3SearchOptions: JSONObject? = null
    private var archive3OptionsFetchRunning = false
    private var serverClockOffsetSec = 0L
    private val archiveHealth = mutableMapOf(
        1 to ArchiveHealthState(),
        2 to ArchiveHealthState(),
        3 to ArchiveHealthState()
    )

    private var bg = Color.rgb(3, 7, 14)
    private var bg2 = Color.rgb(7, 13, 24)
    private var panel = Color.rgb(9, 17, 31)
    private var panel2 = Color.rgb(13, 24, 42)
    private var card = Color.rgb(12, 22, 38)
    private var stroke = Color.rgb(39, 63, 96)
    private var blue = Color.rgb(28, 32, 40)
    private var blue2 = Color.rgb(245, 245, 245)
    private var gold = Color.rgb(235, 235, 235)
    private var white = Color.WHITE
    private var muted = Color.rgb(166, 180, 203)
    private var faint = Color.rgb(105, 123, 150)

    private lateinit var root: FrameLayout
    private lateinit var content: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomNav: LinearLayout
    private var isMainHomePage = false
    private val uiHandler = Handler(Looper.getMainLooper())
    private var currentScreen = "home"
    private val navigationHistory = mutableListOf<() -> Unit>()
    private var currentScreenRestorer: (() -> Unit)? = null
    private var restoringNavigation = false
    private var resumedOnce = false
    private var searchRestoreQuery = ""
    private var searchRestoreFilter = "all"
    private var searchRestoreShowAll = false
    private val lowEndDevice: Boolean by lazy { DeviceProfile.isLowEnd(this) }
    private val imageCache: LruCache<String, Bitmap> by lazy {
        object : LruCache<String, Bitmap>(DeviceProfile.imageCacheKb(this)) {
            override fun sizeOf(key: String, value: Bitmap): Int =
                (value.allocationByteCount / 1024).coerceAtLeast(1)
        }
    }
    private val imageExecutor by lazy { Executors.newFixedThreadPool(DeviceProfile.imageThreads(this)) }
    private val heroItems = mutableListOf<JSONObject>()
    private var bootJson: JSONObject? = null
    private val downloadFolderRequestCode = 19081
    private val onboardingRequestCode = 19082
    private val avatarImageRequestCode = 19083
    private var lastAccountIdentityRefreshAt = 0L
    private val setupNotificationRequestCode = 1819
    private var startupStarted = false
    private var pendingDownloadItemJson = ""
    private var pendingDownloadLinkJson = ""
    private var pendingBulkDownloadItemJson = ""
    private var pendingBulkDownloadLinksJson = ""
    private val detailMemoryCache = object : LruCache<String, JSONObject>(20) {}
    private val detailMemoryCacheAt = mutableMapOf<String, Long>()
    private val detailCacheTtlMs = 60L * 60L * 1000L
    private val detailScrollPositions = mutableMapOf<String, Pair<Int, Long>>()
    private val detailScrollPersistAt = mutableMapOf<String, Long>()
    private var activeDetailRequestKey = ""
    private var activeDetailScrollView: ScrollView? = null
    private var activeDetailScrollKey = ""
    private var notificationRemoteMaxSeen = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        selectedArchive = sanitizeArchive(appPrefs().getInt("selected_archive", defaultArchive))
        if (!appPrefs().contains(UiPreferences.KEY_ACCENT)) appPrefs().edit().putString(UiPreferences.KEY_ACCENT, "blue").apply()
        applyThemeColors()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        showSplashOnly()
        if (UiPreferences.setupRequired(this)) beginRequiredSetup() else continueAppStartup()
    }

    private fun continueAppStartup() {
        if (startupStarted) return
        startupStarted = true
        applyThemeColors()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        boot()
        AdminPushScheduler.ensureScheduled(this)
        AdminPushScheduler.runNow(this)
        uiHandler.postDelayed({ requestDownloadNotificationPermission() }, 1400L)
        if (AccountSession.isLoggedIn(this)) {
            AccountApi.refreshMe(this) { result ->
                if (result.success) AccountApi.syncWatchlist(this, force = true) {}
            }
        }
        if (intent.getBooleanExtra("open_downloads", false)) {
            uiHandler.postDelayed({ startActivity(Intent(this, DownloadsActivity::class.java)) }, 750L)
        }
        if (intent.getBooleanExtra("open_help", false)) {
            uiHandler.postDelayed({ showHelpCenter() }, 950L)
        }
        if (intent.getBooleanExtra("open_notifications", false)) {
            val pushUrl = intent?.getStringExtra("admin_push_url").orEmpty()
            uiHandler.postDelayed({
                if (pushUrl.startsWith("http", true)) openExternal(pushUrl, null) else showNotificationCenter()
            }, 900L)
        }
    }

    private fun beginRequiredSetup() {
        val needsPermission = Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        if (needsPermission && !appPrefs().getBoolean("setup_notification_permission_prompted_v1", false)) {
            appPrefs().edit()
                .putBoolean("setup_notification_permission_prompted_v1", true)
                .putBoolean("notification_permission_requested", true)
                .apply()
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), setupNotificationRequestCode)
        } else {
            launchQuickSetup(required = true)
        }
    }

    private fun launchQuickSetup(required: Boolean = false) {
        startActivityForResult(Intent(this, OnboardingActivity::class.java).apply {
            putExtra("required", required)
        }, onboardingRequestCode)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == setupNotificationRequestCode) {
            launchQuickSetup(required = true)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("open_downloads", false) == true) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }
        if (intent?.getBooleanExtra("open_help", false) == true) {
            uiHandler.postDelayed({ showHelpCenter() }, 180L)
        }
        if (intent?.getBooleanExtra("open_notifications", false) == true) {
            val pushUrl = intent?.getStringExtra("admin_push_url").orEmpty()
            uiHandler.postDelayed({
                if (pushUrl.startsWith("http", true)) openExternal(pushUrl, null) else showNotificationCenter()
            }, 180L)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == onboardingRequestCode) {
            if (UiPreferences.setupRequired(this) && !startupStarted) {
                launchQuickSetup(required = true)
                return
            }
            applyThemeColors()
            if (!startupStarted) {
                showSplashOnly()
                continueAppStartup()
            } else if (::root.isInitialized) {
                buildShell()
                if (currentScreen == "profile") showSettingsPage() else showHome()
            }
            return
        }
        if (requestCode == avatarImageRequestCode) {
            if (resultCode != RESULT_OK) return
            val imageUri = data?.data ?: return
            val mime = contentResolver.getType(imageUri).orEmpty().lowercase(Locale.US)
            val bytes = try {
                contentResolver.openInputStream(imageUri)?.use { input ->
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        total += read
                        if (total > 4 * 1024 * 1024) throw IllegalArgumentException("avatar_too_large")
                        out.write(buffer, 0, read)
                    }
                    out.toByteArray()
                } ?: throw IllegalStateException("empty_avatar")
            } catch (e: Throwable) {
                BmNotice.show(this, t("حجم عکس باید کمتر از ۴ مگابایت باشد", "Avatar must be under 4 MB"), BmNotice.Kind.WARNING)
                return
            }
            val encoded = Base64.encodeToString(bytes, Base64.NO_WRAP)
            BmNotice.show(this, t("در حال آپلود آواتار...", "Uploading avatar..."), BmNotice.Kind.INFO)
            AccountApi.uploadAvatar(this, encoded, mime) { result ->
                if (result.success) {
                    BmNotice.show(this, t("آواتار اختصاصی ذخیره شد", "Custom avatar saved"), BmNotice.Kind.SUCCESS)
                    if (currentScreen == "profile") showProfile()
                } else {
                    BmNotice.show(this, result.message.ifBlank { t("آپلود آواتار انجام نشد", "Avatar upload failed") }, BmNotice.Kind.ERROR)
                }
            }
            return
        }
        if (requestCode != downloadFolderRequestCode || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Throwable) {
        }
        DownloadLocationPrefs.setTree(this, treeUri)
        val itemRaw = pendingDownloadItemJson
        val linkRaw = pendingDownloadLinkJson
        val bulkItemRaw = pendingBulkDownloadItemJson
        val bulkLinksRaw = pendingBulkDownloadLinksJson
        pendingDownloadItemJson = ""
        pendingDownloadLinkJson = ""
        pendingBulkDownloadItemJson = ""
        pendingBulkDownloadLinksJson = ""
        if (bulkItemRaw.isNotBlank() && bulkLinksRaw.isNotBlank()) {
            val restored = mutableListOf<JSONObject>()
            runCatching {
                val arr = JSONArray(bulkLinksRaw)
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { restored.add(it) }
            }
            if (restored.isNotEmpty()) enqueueSeriesBulkInternal(JSONObject(bulkItemRaw), restored, locationAlreadyChosen = true)
        } else if (itemRaw.isNotBlank() && linkRaw.isNotBlank()) {
            launchInternalDownload(JSONObject(itemRaw), JSONObject(linkRaw))
        }
    }

    override fun onResume() {
        super.onResume()
        if (!resumedOnce) {
            resumedOnce = true
            return
        }
        if (::root.isInitialized && currentScreen == "profile") {
            val restore = currentScreenRestorer
            if (restore != null) {
                root.postDelayed({
                    restoringNavigation = true
                    try { restore() } finally { restoringNavigation = false }
                }, 120L)
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleSmartBack()
    }

    private fun rememberCurrentScreen(restorer: () -> Unit) {
        currentScreenRestorer = restorer
    }

    private fun findPrimaryVerticalScroll(view: View?): ScrollView? {
        if (view == null) return null
        if (view is ScrollView) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val found = findPrimaryVerticalScroll(view.getChildAt(i))
                if (found != null) return found
            }
        }
        return null
    }

    private fun currentScreenScrollY(): Int = findPrimaryVerticalScroll(content)?.scrollY?.coerceAtLeast(0) ?: 0

    private fun restoreBackScrollPosition(targetScreen: String, y: Int, savedAt: Long) {
        if (isTvLike() || y <= 0 || System.currentTimeMillis() - savedAt >= detailCacheTtlMs) return

        // PASS 4.7 — smart return position:
        // Restore only until the page is measured enough for the saved position.
        // The moment the user touches/scrolls, restoration is cancelled permanently.
        // This prevents the old "I scroll up and the app drags me down again" behavior.
        val deadline = System.currentTimeMillis() + 1_600L
        val cancelled = booleanArrayOf(false)
        var attachedScroll: ScrollView? = null

        fun clearTouchGuard() {
            attachedScroll?.setOnTouchListener(null)
            attachedScroll = null
        }

        fun attempt() {
            if (cancelled[0] || currentScreen != targetScreen || System.currentTimeMillis() > deadline) {
                clearTouchGuard()
                return
            }
            val scroll = findPrimaryVerticalScroll(content)
            if (scroll == null || scroll.height <= 0 || scroll.getChildAt(0) == null) {
                uiHandler.postDelayed({ attempt() }, 70L)
                return
            }

            if (attachedScroll !== scroll) {
                clearTouchGuard()
                attachedScroll = scroll
                scroll.setOnTouchListener { _, event ->
                    if (event.actionMasked == MotionEvent.ACTION_DOWN || event.actionMasked == MotionEvent.ACTION_MOVE) {
                        cancelled[0] = true
                    }
                    false
                }
            }

            val maxY = ((scroll.getChildAt(0)?.height ?: 0) - scroll.height).coerceAtLeast(0)
            if (maxY >= y - dp(8)) {
                if (!cancelled[0]) scroll.scrollTo(0, y.coerceAtMost(maxY))
                // One successful restore is enough. Never keep forcing the viewport.
                uiHandler.postDelayed({ clearTouchGuard() }, 120L)
            } else {
                uiHandler.postDelayed({ attempt() }, 90L)
            }
        }

        uiHandler.post { attempt() }
    }

    private fun pushCurrentScreenForBack() {
        if (restoringNavigation) return
        currentScreenRestorer?.let { restorer ->
            val savedY = currentScreenScrollY()
            val savedAt = System.currentTimeMillis()
            val savedScreen = currentScreen
            navigationHistory.add {
                restorer()
                restoreBackScrollPosition(savedScreen, savedY, savedAt)
            }
            if (navigationHistory.size > 24) navigationHistory.removeAt(0)
        }
    }

    private fun runBackNavigationMotion(action: () -> Unit) {
        if (!::content.isInitialized || isTvLike() || lowEndDevice || !content.isShown) {
            action()
            return
        }
        content.animate().cancel()
        content.animate()
            .alpha(0f)
            .translationX(dp(14).toFloat())
            .setDuration(85L)
            .setInterpolator(android.view.animation.AccelerateInterpolator())
            .withEndAction {
                action()
                content.animate().cancel()
                content.alpha = 0f
                content.translationX = -dp(12).toFloat()
                content.animate()
                    .alpha(1f)
                    .translationX(0f)
                    .setDuration(155L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .start()
            }
            .start()
    }

    private fun handleSmartBack() {
        if (navigationHistory.isNotEmpty()) {
            val restore = navigationHistory.removeAt(navigationHistory.lastIndex)
            runBackNavigationMotion {
                restoringNavigation = true
                try {
                    restore()
                } finally {
                    restoringNavigation = false
                }
            }
            return
        }
        if (::root.isInitialized && currentScreen != "home") {
            runBackNavigationMotion {
                restoringNavigation = true
                try {
                    showHome()
                } finally {
                    restoringNavigation = false
                }
            }
            return
        }
        super.onBackPressed()
    }

    private fun updateSearchRestorer() {
        val query = searchRestoreQuery
        val filter = searchRestoreFilter
        val showAll = searchRestoreShowAll
        rememberCurrentScreen { showSearch(query, filter, showAll) }
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (isTvLike()) {
            val isOkKey = event.keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                event.keyCode == android.view.KeyEvent.KEYCODE_ENTER ||
                event.keyCode == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER

            // TV stable mode: long-press OK always opens the proven global quick menu.
            // Item-specific long-press interception was removed because it trapped focus.
            if (isOkKey && event.action == android.view.KeyEvent.ACTION_DOWN && event.repeatCount >= 1 && !tvQuickMenuShowing) {
                showTvQuickMenu()
                return true
            }

            if (event.action == android.view.KeyEvent.ACTION_DOWN && ::bottomNav.isInitialized) {
                when (event.keyCode) {
                    android.view.KeyEvent.KEYCODE_DPAD_UP,
                    android.view.KeyEvent.KEYCODE_DPAD_DOWN,
                    android.view.KeyEvent.KEYCODE_DPAD_LEFT,
                    android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        if (bottomNav.visibility != View.VISIBLE || bottomNav.translationY > 0f) {
                            bottomNav.visibility = View.VISIBLE
                            bottomNav.animate().translationY(0f).alpha(1f).setDuration(120).start()
                        }
                    }
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun showSplashOnly() {
        val accent = UiPreferences.accentColor(this)
        val splash = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        splash.addView(ImageView(this).apply {
            setImageResource(R.drawable.bm_loading_auth_bg)
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = if (isTvLike()) 0.26f else 0.32f
        }, FrameLayout.LayoutParams(-1, -1))
        splash.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(90, 0, 0, 0),
                    Color.argb(150, 0, 0, 0),
                    Color.argb(228, 0, 0, 0),
                    Color.rgb(0, 0, 0)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        val glow = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(35, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            alpha = 0.65f
        }
        splash.addView(glow, FrameLayout.LayoutParams(dp(360), dp(360), Gravity.CENTER).apply {
            topMargin = dp(10)
        })

        val center = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            alpha = 0f
            scaleX = 0.96f
            scaleY = 0.96f
        }
        center.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(300), dp(138)).apply { bottomMargin = dp(12) })
        center.addView(TextView(this).apply {
            text = "تجربه تماشای حرفه‌ای"
            setTextColor(Color.argb(205, 255, 255, 255))
            textSize = 13f
            gravity = Gravity.CENTER
        })
        splash.addView(center, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER).apply {
            bottomMargin = dp(110)
        })

        val loading = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        loading.addView(PremiumLoaderView(this@MainActivity), LinearLayout.LayoutParams(dp(86), dp(86)).apply {
            bottomMargin = dp(14)
        })
        loading.addView(TextView(this).apply {
            text = "در حال آماده‌سازی..."
            setTextColor(white)
            textSize = 15f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        loading.addView(TextView(this).apply {
            text = "نسخه ${appVersionName()}"
            setTextColor(Color.argb(132, 255, 255, 255))
            textSize = 10.8f
            gravity = Gravity.CENTER
            setPadding(0, dp(7), 0, 0)
        })
        splash.addView(loading, FrameLayout.LayoutParams(-1, dp(180), Gravity.BOTTOM).apply {
            bottomMargin = dp(50)
        })

        setContentView(splash)
        center.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(520).start()
        glow.animate().alpha(0.22f).scaleX(1.12f).scaleY(1.12f).setDuration(1150).withEndAction {
            glow.animate().alpha(0.62f).scaleX(1f).scaleY(1f).setDuration(1150).start()
        }.start()
    }

    private fun showNetworkError(message: String) {
        val disabled = maintenanceMode
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(dp(22), dp(22), dp(22), dp(22))
        }
        page.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(320), dp(145)).apply { bottomMargin = dp(18) })
        page.addView(TextView(this).apply {
            text = if (disabled) t("اپ موقتاً غیرفعال است", "App is temporarily disabled") else t("اتصال برقرار نشد", "Connection failed")
            setTextColor(white)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = if (disabled) t("بعداً دوباره امتحان کن.", "Please try again later.") else friendlyError(message)
            setTextColor(muted)
            textSize = 13.5f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(18))
        })
        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        if (!disabled) {
            page.addView(TextView(this).apply {
                text = t("تلاش دوباره", "Retry")
                setTextColor(white)
                textSize = 14f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.rgb(24, 37, 57), dp(17), Color.argb(110, 255, 255, 255))
                applyTvFocusHalo(this, 18, 1.045f, 0f)
                setOnClickListener { showSplashOnly(); boot() }
            }, LinearLayout.LayoutParams(-1, dp(50)))
        }
        setContentView(page)
    }

    private fun normalizeDomain(raw: String): String {
        var d = raw.trim()
        if (d.isBlank()) return ""
        if (!d.startsWith("http://", true) && !d.startsWith("https://", true)) d = "https://$d"
        while (d.endsWith("/")) d = d.dropLast(1)
        return d
    }

    private fun normalizeApiUrl(raw: String, domain: String): String {
        val value = raw.trim()
        if (value.isBlank()) return if (domain.isNotBlank()) "${domain.trimEnd('/')}/app_api.php" else ""
        if (value.startsWith("http://", true) || value.startsWith("https://", true)) return value
        return "${domain.trimEnd('/')}/${value.trimStart('/')}"
    }

    private fun hostToken(raw: String): String {
        val value = raw.trim()
        if (value.isBlank()) return ""
        return try {
            val withScheme = if (value.startsWith("http://", true) || value.startsWith("https://", true)) value else "https://$value"
            Uri.parse(withScheme).host.orEmpty().lowercase(Locale.US)
        } catch (_: Throwable) {
            value.lowercase(Locale.US).substringBefore('/').substringBefore(':')
        }
    }

    private fun rewriteConfiguredUrl(raw: String): String {
        var value = raw.trim()
        if (value.isBlank() || value == "null") return ""
        if (value.startsWith("//")) value = "https:$value"

        for (rule in urlRewriteRules) {
            if (!rule.enabled) continue
            val token = hostToken(rule.from)
            if (token.isBlank()) continue
            val uri = try { Uri.parse(value) } catch (_: Throwable) { null } ?: continue
            val host = uri.host.orEmpty().lowercase(Locale.US)
            if (host.isBlank()) continue
            if (host != token && !host.contains(token)) continue

            val targetBase = when {
                rule.mode.equals("active", true) -> activeDomain
                rule.to.equals("ACTIVE", true) -> activeDomain
                rule.to.isBlank() -> activeDomain
                else -> normalizeDomain(rule.to)
            }.trimEnd('/')

            if (targetBase.isBlank()) continue
            val path = uri.encodedPath.orEmpty()
            val query = uri.encodedQuery?.let { "?$it" }.orEmpty()
            val fragment = uri.encodedFragment?.let { "#$it" }.orEmpty()
            value = "$targetBase$path$query$fragment"
        }

        val currentUri = try { Uri.parse(value) } catch (_: Throwable) { null }
        val currentHost = currentUri?.host.orEmpty().lowercase(Locale.US)
        val activeHost = try { Uri.parse(activeDomain).host.orEmpty().lowercase(Locale.US) } catch (_: Throwable) { "" }
        if (currentHost.isNotBlank() && activeHost.isNotBlank() && currentHost != activeHost) {
            val belongsToKnownServer = apiServers.any { endpoint ->
                try { Uri.parse(endpoint.contentDomain).host.orEmpty().equals(currentHost, true) } catch (_: Throwable) { false }
            }
            if (belongsToKnownServer) {
                val path = currentUri?.encodedPath.orEmpty()
                val query = currentUri?.encodedQuery?.let { "?$it" }.orEmpty()
                val fragment = currentUri?.encodedFragment?.let { "#$it" }.orEmpty()
                value = "${activeDomain.trimEnd('/')}$path$query$fragment"
            }
        }
        return value
    }

    /**
     * Rewrites control/API/image URLs when a server failover changes the active
     * BankMovie host, but deliberately leaves download/media URLs untouched.
     * Download hosts are data: old dl hosts, the current dl host and any future
     * subdomains returned by the database must reach the player/downloader exactly
     * as the server returned them. No download-host allowlist is baked into the APK.
     */
    private fun rewriteJsonUrls(node: Any?, insideDownloadNode: Boolean = false) {
        fun looksLikeDownloadObject(obj: JSONObject): Boolean {
            if (obj.optBoolean("is_download", false) || obj.optBoolean("is_direct", false) || obj.optBoolean("is_playable", false)) return true
            if (obj.has("quality") && (obj.has("url") || obj.has("download_url") || obj.has("file_url") || obj.has("href"))) return true
            if ((obj.has("season") || obj.has("episode")) && obj.has("url")) return true
            val sourceTable = obj.optString("source_table").lowercase(Locale.US)
            return sourceTable.endsWith("_links") || sourceTable.contains("download")
        }

        when (node) {
            is JSONObject -> {
                val preserveDownloadUrls = insideDownloadNode || looksLikeDownloadObject(node)
                val keys = node.keys()
                val names = mutableListOf<String>()
                while (keys.hasNext()) names.add(keys.next())
                names.forEach { key ->
                    val value = node.opt(key)
                    val childDownloadContext = preserveDownloadUrls || key.equals("downloads", true) || key.equals("links", true) || key.equals("movie_links", true)
                    when (value) {
                        is JSONObject, is JSONArray -> rewriteJsonUrls(value, childDownloadContext)
                        is String -> {
                            val trimmed = value.trim()
                            val absolute = trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) || trimmed.startsWith("//")
                            val isDownloadUrlField = preserveDownloadUrls && key.lowercase(Locale.US) in setOf("url", "link", "download_url", "file_url", "src", "href")
                            if (absolute && !isDownloadUrlField) node.put(key, rewriteConfiguredUrl(value))
                        }
                    }
                }
            }
            is JSONArray -> {
                for (i in 0 until node.length()) {
                    val value = node.opt(i)
                    when (value) {
                        is JSONObject, is JSONArray -> rewriteJsonUrls(value, insideDownloadNode)
                        is String -> {
                            val trimmed = value.trim()
                            if (!insideDownloadNode && (trimmed.startsWith("http://", true) || trimmed.startsWith("https://", true) || trimmed.startsWith("//"))) {
                                node.put(i, rewriteConfiguredUrl(value))
                            }
                        }
                    }
                }
            }
        }
    }

    private fun ensureDefaultServerPool() {
        if (apiServers.isNotEmpty()) return
        val domain = normalizeDomain(activeDomain).ifBlank { AppConfig.BASE_DOMAIN }
        val api = normalizeApiUrl(apiBase, domain).ifBlank { "$domain/app_api.php" }
        apiServers.add(ServerEndpoint("main", api, domain))
        apiBase = api
        activeDomain = domain
        activeServerName = "main"
    }

    private fun loadAppConfig(done: () -> Unit) {
        Thread {
            var loaded = false
            for (candidate in appConfigCandidates()) {
                if (loaded) break
                var c: HttpURLConnection? = null
                try {
                    c = (URL(candidate).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 6500
                        readTimeout = 9000
                        instanceFollowRedirects = true
                        setRequestProperty("Accept", "application/json")
                        setRequestProperty("User-Agent", "BankmovieAndroidNative/2.1-Resilient")
                        setRequestProperty("Cache-Control", "no-cache")
                    }
                    val code = c.responseCode
                    c.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let {
                        serverClockOffsetSec = it / 1000L - System.currentTimeMillis() / 1000L
                    }
                    val body = (if (code in 200..299) c.inputStream else c.errorStream)
                        ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    if (code in 200..299 && body.isNotBlank()) {
                        applyAppConfig(JSONObject(body))
                        appPrefs().edit()
                            .putString("cached_remote_config_v4", body)
                            .putString("last_good_config_url", candidate)
                            .apply()
                        loaded = true
                    }
                } catch (_: Throwable) {
                } finally {
                    runCatching { c?.disconnect() }
                }
            }

            if (!loaded) {
                val cached = appPrefs().getString("cached_remote_config_v4", "").orEmpty()
                if (cached.isNotBlank()) {
                    try {
                        applyAppConfig(JSONObject(cached))
                        loaded = true
                    } catch (_: Throwable) {
                    }
                }
            }

            ensureDefaultServerPool()
            done()
        }.start()
    }

    private fun applyAppConfig(json: JSONObject) {
        maintenanceMode = false
        if (!json.optBoolean("ready", true)) {
            maintenanceMode = true
            maintenanceMessage = json.optString("message").ifBlank { maintenanceMessage }
            return
        }

        val d = normalizeDomain(
            json.optString("active_domain")
                .ifBlank { json.optString("domain") }
                .ifBlank { json.optString("base_url") }
        )
        if (d.isNotBlank()) activeDomain = d

        val configuredAccountApi = json.optString("account_api_url")
            .ifBlank { json.optString("user_api_url") }
            .trim()
        val normalizedConfiguredAccountApi = if (configuredAccountApi.isBlank()) "" else normalizeApiUrl(configuredAccountApi, activeDomain)
        // An explicit account_api_url is the canonical user/comment database endpoint.
        // Only derive it from the content domain when the remote config omitted it.
        val accountApiFollowsActiveDomain = configuredAccountApi.isBlank()
        val accountApiUrl = if (accountApiFollowsActiveDomain) {
            "${activeDomain.trimEnd('/')}/app_user_api.php"
        } else {
            normalizedConfiguredAccountApi
        }
        appPrefs().edit()
            .putString("account_api_url", accountApiUrl)
            .putBoolean("account_api_follows_active_domain", accountApiFollowsActiveDomain)
            .apply()

        val remoteApi = json.optString("api_url")
            .ifBlank { json.optString("api") }
            .ifBlank { json.optString("api_base") }

        apiBase = when {
            remoteApi.isNotBlank() && remoteApi.startsWith("http", true) -> remoteApi
            remoteApi.isNotBlank() -> activeDomain + "/" + remoteApi.trimStart('/')
            activeDomain.isNotBlank() -> "$activeDomain/app_api.php"
            else -> AppConfig.APP_API_URL
        }

        apiServers.clear()
        val configuredServers = json.optJSONArray("servers")
        if (configuredServers != null) {
            val pending = mutableListOf<Pair<Int, ServerEndpoint>>()
            for (i in 0 until configuredServers.length()) {
                val server = configuredServers.optJSONObject(i) ?: continue
                if (!server.optBoolean("enabled", true)) continue
                val domain = normalizeDomain(
                    server.optString("domain")
                        .ifBlank { server.optString("content_domain") }
                        .ifBlank { activeDomain }
                )
                val api = normalizeApiUrl(
                    server.optString("api_url").ifBlank { server.optString("api") },
                    domain
                )
                if (domain.isBlank() || api.isBlank()) continue
                val name = server.optString("name").ifBlank { "server-${i + 1}" }
                val priority = server.optInt("priority", i + 1)
                pending.add(priority to ServerEndpoint(name, api, domain))
            }
            pending.sortedBy { it.first }.forEach { (_, endpoint) ->
                if (apiServers.none { it.apiUrl.equals(endpoint.apiUrl, true) }) apiServers.add(endpoint)
            }
        }

        if (apiServers.isEmpty()) {
            apiServers.add(ServerEndpoint("main", apiBase, activeDomain))
        }

        val preferred = apiServers.first()
        apiBase = preferred.apiUrl
        activeDomain = preferred.contentDomain
        activeServerName = preferred.name

        val accountFallbacks = linkedSetOf<String>()
        if (accountApiUrl.isNotBlank()) accountFallbacks.add(accountApiUrl)
        json.optJSONArray("account_api_urls")?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.startsWith("http", true) }?.let(accountFallbacks::add)
        }
        if (accountApiFollowsActiveDomain || accountFallbacks.size <= 1) {
            apiServers.forEach { endpoint -> accountFallbacks.add("${endpoint.contentDomain.trimEnd('/')}/app_user_api.php") }
        }
        appPrefs().edit().putString("account_api_fallback_urls", JSONArray(accountFallbacks.toList()).toString()).apply()

        val archivesConfig = json.optJSONObject("archives")
        val archive1Config = archivesConfig?.optJSONObject("1")
        val archive2Config = archivesConfig?.optJSONObject("2")
        val archive3Config = archivesConfig?.optJSONObject("3")
        archive1LiveApiBase = normalizeApiUrl(
            json.optString("archive1_live_api_url")
                .ifBlank { archive1Config?.optString("api_url").orEmpty() }
                .ifBlank { "archive1_live.php" },
            activeDomain
        ).ifBlank { "$activeDomain/archive1_live.php" }
        // Phase 6: Archive 2 is database-backed through the signed app_api.php.
        archive3ApiBase = normalizeApiUrl(
            json.optString("archive3_api_url")
                .ifBlank { archive3Config?.optString("api_url").orEmpty() }
                .ifBlank { "api6.php" },
            activeDomain
        ).ifBlank { "$activeDomain/api6.php" }

        urlRewriteRules.clear()
        json.optJSONArray("url_rewrites")?.let { rules ->
            for (i in 0 until rules.length()) {
                val rule = rules.optJSONObject(i) ?: continue
                val from = rule.optString("from").trim()
                if (from.isBlank()) continue
                urlRewriteRules.add(
                    UrlRewriteRule(
                        from = from,
                        to = rule.optString("to").trim(),
                        mode = rule.optString("mode").ifBlank { "replace" },
                        enabled = rule.optBoolean("enabled", true)
                    )
                )
            }
        }

        val features = json.optJSONObject("features")
        remoteRegistrationEnabled = features?.optBoolean("registration_enabled", true) ?: true
        remoteLoginEnabled = features?.optBoolean("login_enabled", true) ?: true
        remoteCommentsEnabled = features?.optBoolean("comments_enabled", true) ?: true
        remoteCommentRepliesEnabled = features?.optBoolean("comment_replies_enabled", true) ?: true
        remoteCommentVotesEnabled = features?.optBoolean("comment_votes_enabled", true) ?: true
        remoteCommentReportsEnabled = features?.optBoolean("comment_reports_enabled", true) ?: true
        remoteCommentSpoilerEnabled = features?.optBoolean("comment_spoiler_enabled", true) ?: true
        val commentConfig = json.optJSONObject("comments")
        val downloadConfig = json.optJSONObject("downloads")
        remoteCommentEditMinutes = (commentConfig?.optInt("edit_minutes", features?.optInt("comment_edit_minutes", 10) ?: 10) ?: 10).coerceIn(0, 1440)
        remoteNotificationCenterEnabled = features?.optBoolean("notification_center_enabled", true) ?: true
        remoteInternalDownloaderEnabled = features?.optBoolean("internal_downloader_enabled", true) ?: true
        remoteMultipartDownloadEnabled = features?.optBoolean("multipart_download_enabled", true) ?: true
        remoteDownloadPathSelectionEnabled = features?.optBoolean("download_path_selection_enabled", true) ?: true
        remoteAdvancedSearchEnabled = features?.optBoolean("advanced_search_enabled", true) ?: true
        remoteCategoriesEnabled = features?.optBoolean("categories_enabled", true) ?: true
        remoteWatchlistEnabled = features?.optBoolean("watchlist_enabled", true) ?: true
        remoteContinueWatchingEnabled = features?.optBoolean("continue_watching_enabled", true) ?: true
        remoteTvQuickMenuEnabled = features?.optBoolean("tv_quick_menu_enabled", true) ?: true
        remoteDownloadLimit = (downloadConfig?.optInt("concurrent_limit", features?.optInt("download_limit", 2) ?: 2) ?: 2).coerceIn(1, 4)
        remoteDownloadRetryCount = (downloadConfig?.optInt("retry_count", features?.optInt("download_retry_count", 4) ?: 4) ?: 4).coerceIn(0, 12)
        remoteDownloadRetryDelaySeconds = (downloadConfig?.optInt("retry_delay_seconds", features?.optInt("download_retry_delay_seconds", 8) ?: 8) ?: 8).coerceIn(2, 300)
        remoteDownloadMinFreeMb = (downloadConfig?.optInt("min_free_mb", features?.optInt("download_min_free_mb", 256) ?: 256) ?: 256).coerceIn(32, 8192)
        remoteMultipartParts = (downloadConfig?.optInt("multipart_parts", features?.optInt("multipart_parts", 4) ?: 4) ?: 4).coerceIn(2, 6)
        val featureArchives = features?.optJSONObject("archives")
        remoteArchive1Enabled = featureArchives?.optBoolean("archive1_enabled", true) ?: true
        remoteArchive2Enabled = featureArchives?.optBoolean("archive2_enabled", true) ?: true
        remoteArchive3Enabled = featureArchives?.optBoolean("archive3_enabled", true) ?: true
        remoteArchive1Hidden = featureArchives?.optBoolean("archive1_hidden", false) ?: false
        remoteArchive2Hidden = featureArchives?.optBoolean("archive2_hidden", false) ?: false
        remoteArchive3Hidden = featureArchives?.optBoolean("archive3_hidden", false) ?: false
        val accountFeatures = JSONObject().apply {
            put("registration_enabled", remoteRegistrationEnabled)
            put("login_enabled", remoteLoginEnabled)
            put("comments_enabled", remoteCommentsEnabled)
            put("comment_replies_enabled", remoteCommentRepliesEnabled)
            put("comment_votes_enabled", remoteCommentVotesEnabled)
            put("comment_reports_enabled", remoteCommentReportsEnabled)
            put("comment_spoiler_enabled", remoteCommentSpoilerEnabled)
            put("comment_edit_minutes", remoteCommentEditMinutes)
            put("notification_center_enabled", remoteNotificationCenterEnabled)
            put("internal_downloader_enabled", remoteInternalDownloaderEnabled)
            put("multipart_download_enabled", remoteMultipartDownloadEnabled)
            put("download_path_selection_enabled", remoteDownloadPathSelectionEnabled)
            put("advanced_search_enabled", remoteAdvancedSearchEnabled)
            put("categories_enabled", remoteCategoriesEnabled)
            put("watchlist_enabled", remoteWatchlistEnabled)
            put("continue_watching_enabled", remoteContinueWatchingEnabled)
            put("tv_quick_menu_enabled", remoteTvQuickMenuEnabled)
            put("download_limit", remoteDownloadLimit)
            put("download_retry_count", remoteDownloadRetryCount)
            put("download_retry_delay_seconds", remoteDownloadRetryDelaySeconds)
            put("download_min_free_mb", remoteDownloadMinFreeMb)
            put("multipart_parts", remoteMultipartParts)
            put("archive1_enabled", remoteArchive1Enabled)
            put("archive2_enabled", remoteArchive2Enabled)
            put("archive3_enabled", remoteArchive3Enabled)
            put("archive1_hidden", remoteArchive1Hidden)
            put("archive2_hidden", remoteArchive2Hidden)
            put("archive3_hidden", remoteArchive3Hidden)
        }
        AccountSession.updateFeatures(this, accountFeatures)
        appPrefs().edit()
            .putInt("remote_download_limit", remoteDownloadLimit)
            .putInt("remote_download_retry_count", remoteDownloadRetryCount)
            .putInt("remote_download_retry_delay_seconds", remoteDownloadRetryDelaySeconds)
            .putInt("remote_download_min_free_mb", remoteDownloadMinFreeMb)
            .putInt("remote_multipart_parts", remoteMultipartParts)
            .putBoolean("remote_multipart_enabled", remoteMultipartDownloadEnabled)
            .apply()

        remoteHomeSectionsArchive1.clear()
        remoteHomeSectionsArchive2.clear()
        remoteHomeSectionsArchive3.clear()
        val home = json.optJSONObject("home")
        home?.optJSONArray("archive1_sections")?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.isNotBlank() }?.let(remoteHomeSectionsArchive1::add)
        }
        home?.optJSONArray("archive2_sections")?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.isNotBlank() }?.let(remoteHomeSectionsArchive2::add)
        }
        home?.optJSONArray("archive3_sections")?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.isNotBlank() }?.let(remoteHomeSectionsArchive3::add)
        }
        if (!archiveEnabled(selectedArchive)) {
            selectedArchive = listOf(1, 2, 3).firstOrNull { archiveEnabled(it) }
                ?: listOf(1, 2, 3).firstOrNull { archiveVisible(it) }
                ?: 1
            appPrefs().edit().putInt("selected_archive", selectedArchive).apply()
        }
        if (archiveEnabled(3)) prefetchArchive3SearchOptions()

        val notice = json.optJSONObject("notice")
        remoteNoticeEnabled = notice?.optBoolean("enabled", false) ?: json.optBoolean("notice_enabled", false)
        remoteNoticeTitle = notice?.optString("title").orEmpty().ifBlank { json.optString("notice_title") }
        remoteNoticeMessage = notice?.optString("message").orEmpty()
            .ifBlank { json.optString("notice_message") }
            .ifBlank { if (remoteNoticeEnabled) json.optString("notice") else "" }
            .ifBlank { if (remoteNoticeEnabled) json.optString("message") else "" }
        remoteNoticeId = notice?.optString("id").orEmpty().ifBlank { json.optString("notice_id") }
        remoteNoticeDismissible = notice?.optBoolean("dismissible", true) ?: true
        remoteNoticeTargetUrl = notice?.optJSONObject("target")?.optString("url").orEmpty().trim()
        features?.optString("login_poster_url").orEmpty().trim().takeIf { it.startsWith("http", true) }?.let { AccountSession.setAuthBackground(this, it) }

        val update = json.optJSONObject("update")
        remoteVersionCode = update?.optInt("version_code", 0) ?: json.optInt("version_code", json.optInt("latest_version_code", 0))
        remoteVersionName = update?.optString("version_name").orEmpty()
            .ifBlank { json.optString("version_name") }
            .ifBlank { json.optString("latest_version_name") }
        val apkUrls = update?.optJSONObject("apk_urls")
        remoteApkUrlUniversal = apkUrls?.optString("universal").orEmpty()
            .ifBlank { update?.optString("apk_url").orEmpty() }
            .ifBlank { update?.optString("download_url").orEmpty() }
            .ifBlank { json.optString("apk_url") }
            .ifBlank { json.optString("download_url") }
        remoteApkUrlArm64 = apkUrls?.optString("arm64_v8a").orEmpty()
            .ifBlank { apkUrls?.optString("arm64").orEmpty() }
        remoteApkUrlV7a = apkUrls?.optString("armeabi_v7a").orEmpty()
            .ifBlank { apkUrls?.optString("v7a").orEmpty() }
        remoteApkUrl = remoteApkUrlUniversal
        remoteUpdateEnabled = update?.optBoolean("enabled", true) ?: json.optBoolean("update_enabled", true)
        remoteForceUpdate = update?.optBoolean("force", false) ?: json.optBoolean("force_update", false)
        remoteUpdateTitle = update?.optString("title").orEmpty().ifBlank { json.optString("update_title") }.ifBlank { remoteUpdateTitle }
        remoteUpdateMessage = update?.optString("message").orEmpty().ifBlank { json.optString("update_message") }.ifBlank { remoteUpdateMessage }
        remoteUpdateChanges.clear()
        val changesArr = update?.optJSONArray("changes") ?: json.optJSONArray("changes") ?: json.optJSONArray("what_new")
        if (changesArr != null) {
            for (i in 0 until changesArr.length()) {
                val s = changesArr.optString(i).trim()
                if (s.isNotBlank()) remoteUpdateChanges.add(s)
            }
        }
        val changeText = update?.optString("changelog").orEmpty().ifBlank { json.optString("changelog") }
        if (remoteUpdateChanges.isEmpty() && changeText.isNotBlank()) {
            changeText.split("\n", "•", "-", "،").map { it.trim() }.filter { it.isNotBlank() }.take(8).forEach { remoteUpdateChanges.add(it) }
        }

        val policy = json.optJSONObject("version_policy")
        versionPolicyEnabled = policy?.optBoolean("enabled", false) ?: false
        latestVersionOnly = policy?.optBoolean("latest_version_only", false) ?: false
        minimumSupportedVersionCode = policy?.optInt("minimum_version_code", 0) ?: 0
        minimumSupportedVersionName = policy?.optString("minimum_version_name").orEmpty().trim()
        blockedVersionMessage = policy?.optString("block_message").orEmpty().ifBlank { blockedVersionMessage }
        forceUpdateBlockedVersions = policy?.optBoolean("force_update_blocked", true) ?: true
        blockedVersionNames.clear()
        blockedVersionCodes.clear()
        policy?.optJSONArray("blocked_version_names")?.let { arr ->
            for (i in 0 until arr.length()) {
                normalizeVersionLabel(arr.optString(i)).takeIf { it.isNotBlank() }?.let { blockedVersionNames.add(it) }
            }
        }
        policy?.optJSONArray("blocked_version_codes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val value = arr.optInt(i, 0)
                if (value > 0) blockedVersionCodes.add(value)
            }
        }

        appPrefs().edit()
            .putString("active_domain", activeDomain)
            .putString("api_base", apiBase)
            .putString("active_server_name", activeServerName)
            .apply()
    }

    private fun showRemoteNoticeIfNeeded() {
        val msg = remoteNoticeMessage.trim()
        if (!remoteNoticeEnabled || msg.isBlank()) return
        val id = remoteNoticeId.ifBlank { msg.hashCode().toString() }
        val lastSeen = appPrefs().getString("remote_notice_seen_id", "") ?: ""
        if (lastSeen == id) return

        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(18, 19, 28), Color.rgb(8, 10, 17))).apply {
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), Color.argb(95, 155, 98, 255))
            }
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply {
            text = remoteNoticeTitle.ifBlank { t("پیام مدیریت", "Admin message") }
            setTextColor(white)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (remoteNoticeDismissible) head.addView(TextView(this).apply {
            text = "×"
            setTextColor(Color.rgb(220, 224, 238))
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(58, 255, 255, 255), dp(17), Color.argb(45, 255, 255, 255))
            setOnClickListener {
                appPrefs().edit().putString("remote_notice_seen_id", id).apply()
                dialog.dismiss()
            }
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(TextView(this).apply {
            text = msg
            setTextColor(Color.rgb(230, 233, 242))
            textSize = 14f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(4).toFloat(), 1.0f)
        })
        box.addView(TextView(this).apply {
            text = if (remoteNoticeTargetUrl.startsWith("http", true)) t("مشاهده", "Open") else t("متوجه شدم", "Got it")
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(UiPreferences.blend(blue, Color.WHITE, 0.10f), UiPreferences.blend(blue, Color.BLACK, 0.22f))).apply { cornerRadius = dp(21).toFloat() }
            setOnClickListener {
                appPrefs().edit().putString("remote_notice_seen_id", id).apply()
                val targetUrl = remoteNoticeTargetUrl
                dialog.dismiss()
                if (targetUrl.startsWith("http", true)) openExternal(targetUrl, null)
            }
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(18) })
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.setCancelable(remoteNoticeDismissible)
        dialog.setCanceledOnTouchOutside(remoteNoticeDismissible)
        dialog.show()
        styleShownDialog(dialog, box)
    }

    private fun normalizeVersionLabel(value: String): String {
        return value.trim().lowercase(Locale.ROOT)
            .removePrefix("version")
            .removePrefix("ver")
            .removePrefix("v")
            .trim()
            .replace('۰', '0').replace('۱', '1').replace('۲', '2').replace('۳', '3').replace('۴', '4')
            .replace('۵', '5').replace('۶', '6').replace('۷', '7').replace('۸', '8').replace('۹', '9')
            .replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
            .replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
    }

    private fun versionNumberParts(value: String): List<Int> {
        return Regex("""\d+""").findAll(normalizeVersionLabel(value)).mapNotNull { it.value.toIntOrNull() }.toList()
    }

    private fun compareReleaseVersions(left: String, right: String): Int {
        val a = versionNumberParts(left)
        val b = versionNumberParts(right)
        val size = maxOf(a.size, b.size)
        for (i in 0 until size) {
            val av = a.getOrElse(i) { 0 }
            val bv = b.getOrElse(i) { 0 }
            if (av != bv) return av.compareTo(bv)
        }
        return 0
    }

    private fun selectedRemoteApkUrl(): String {
        val abis = android.os.Build.SUPPORTED_ABIS?.map { it.lowercase(Locale.ROOT) }.orEmpty()
        return when {
            abis.any { it == "arm64-v8a" } && remoteApkUrlArm64.isNotBlank() -> remoteApkUrlArm64
            abis.any { it == "armeabi-v7a" } && remoteApkUrlV7a.isNotBlank() -> remoteApkUrlV7a
            remoteApkUrlUniversal.isNotBlank() -> remoteApkUrlUniversal
            remoteApkUrl.isNotBlank() -> remoteApkUrl
            else -> ""
        }
    }

    private fun currentVersionBlockReason(): String? {
        if (!versionPolicyEnabled) return null
        val currentCode = appVersionCode()
        val currentName = normalizeVersionLabel(appVersionName())
        val blockedByName = currentName.isNotBlank() && blockedVersionNames.contains(currentName)
        val blockedByCode = currentCode > 0 && blockedVersionCodes.contains(currentCode)
        val belowMinimumCode = minimumSupportedVersionCode > 0 && currentCode < minimumSupportedVersionCode
        val belowMinimumName = minimumSupportedVersionName.isNotBlank() && compareReleaseVersions(appVersionName(), minimumSupportedVersionName) < 0
        val notLatest = latestVersionOnly && remoteVersionCode > 0 && currentCode != remoteVersionCode
        return if (blockedByName || blockedByCode || belowMinimumCode || belowMinimumName || notLatest) blockedVersionMessage else null
    }

    private fun showBlockedVersionScreen(message: String) {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        page.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(280), dp(126)).apply { bottomMargin = dp(22) })
        page.addView(TextView(this).apply {
            text = t("این نسخه غیرفعال شده است", "This version is disabled")
            setTextColor(white)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        })
        page.addView(TextView(this).apply {
            text = message
            setTextColor(Color.rgb(180, 190, 208))
            textSize = 14f
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(18))
        })
        val apkUrl = selectedRemoteApkUrl()
        if (apkUrl.isNotBlank()) {
            page.addView(TextView(this).apply {
                text = t("نصب نسخه جدید", "Install latest version")
                setTextColor(white)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(UiPreferences.blend(blue, Color.WHITE, 0.10f), UiPreferences.blend(blue, Color.BLACK, 0.22f))).apply { cornerRadius = dp(24).toFloat() }
                setOnClickListener { openExternal(apkUrl, null) }
            }, LinearLayout.LayoutParams(-1, dp(56)))
        }
        setContentView(page)
    }

    private fun showConfigUpdateIfNeeded(showToastIfLatest: Boolean): Boolean {
        val blockReason = currentVersionBlockReason()
        if (blockReason != null) {
            val apkUrl = selectedRemoteApkUrl()
            if (apkUrl.isBlank() || !forceUpdateBlockedVersions) {
                showBlockedVersionScreen(blockReason)
            } else {
                showUpdateDialog(
                    remoteUpdateTitle.ifBlank { t("این نسخه غیرفعال شده است", "This version is disabled") },
                    blockReason,
                    apkUrl,
                    true,
                    remoteVersionName.ifBlank { t("نسخه جدید", "Latest version") },
                    appVersionName(),
                    remoteUpdateChanges
                )
            }
            return true
        }

        if (!remoteUpdateEnabled) return false
        val currentCode = appVersionCode()
        val currentName = appVersionName().trim()
        val targetName = remoteVersionName.trim()
        val hasNamedVersion = versionNumberParts(targetName).isNotEmpty()
        val hasUpdate = selectedRemoteApkUrl().isNotBlank() && when {
            hasNamedVersion -> compareReleaseVersions(targetName, currentName) > 0
            remoteVersionCode > 0 -> remoteVersionCode > currentCode
            else -> false
        }
        if (!hasUpdate) return false

        val latestName = targetName.ifBlank { if (remoteVersionCode > 0) remoteVersionCode.toString() else t("جدید", "New") }
        showUpdateDialog(
            remoteUpdateTitle,
            remoteUpdateMessage,
            selectedRemoteApkUrl(),
            remoteForceUpdate,
            latestName,
            currentName,
            remoteUpdateChanges
        )
        return true
    }

    private fun loadHomeFeed(base: JSONObject, done: (JSONObject) -> Unit) {
        Thread {
            var extras: JSONObject? = null
            var connection: HttpURLConnection? = null
            try {
                val feedBucket = System.currentTimeMillis() / 30_000L
                val endpoint = activeDomain.trimEnd('/') + "/app_home_feed.php?limit=12&v=$feedBucket"
                connection = (URL(rewriteConfiguredUrl(endpoint)).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 4500
                    instanceFollowRedirects = true
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("User-Agent", "BankmovieAndroidNative/2.1-HomeFeed")
                    setRequestProperty("Cache-Control", "no-cache")
                }
                val code = connection.responseCode
                val body = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                if (code in 200..299 && body.isNotBlank()) {
                    val parsed = JSONObject(body)
                    if (parsed.optString("status").equals("success", true)) {
                        rewriteJsonUrls(parsed)
                        extras = parsed
                        appPrefs().edit()
                            .putString("home_feed_cache_v1", parsed.toString())
                            .putLong("home_feed_cache_at_v1", System.currentTimeMillis())
                            .apply()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { connection?.disconnect() }
            }

            if (extras == null) {
                val prefs = appPrefs()
                val cachedAt = prefs.getLong("home_feed_cache_at_v1", 0L)
                val raw = prefs.getString("home_feed_cache_v1", "").orEmpty()
                if (raw.isNotBlank() && System.currentTimeMillis() - cachedAt < 60L * 60L * 1000L) {
                    extras = runCatching { JSONObject(raw) }.getOrNull()
                }
            }

            extras?.optJSONArray("sliders")?.let { base.put("sliders", it) }
            extras?.optJSONObject("weekly_schedule")?.let { base.put("weekly_schedule", it) }
            runOnUiThread { done(base) }
        }.start()
    }

    private fun boot() {
        loadAppConfig {
            if (maintenanceMode) {
                runOnUiThread { showNetworkError(maintenanceMessage) }
                return@loadAppConfig
            }
            val versionBlockReason = currentVersionBlockReason()
            if (versionBlockReason != null) {
                runOnUiThread {
                    val apkUrl = selectedRemoteApkUrl()
                    if (apkUrl.isNotBlank() && forceUpdateBlockedVersions) {
                        showUpdateDialog(
                            remoteUpdateTitle.ifBlank { t("این نسخه غیرفعال شده است", "This version is disabled") },
                            versionBlockReason,
                            apkUrl,
                            true,
                            remoteVersionName.ifBlank { t("نسخه جدید", "Latest version") },
                            appVersionName(),
                            remoteUpdateChanges
                        )
                    } else {
                        showBlockedVersionScreen(versionBlockReason)
                    }
                }
                return@loadAppConfig
            }

            fetch("$apiBase?action=boot") { ok, json, err ->
                runOnUiThread {
                    if (ok && json != null && json.optBoolean("ready", false)) {
                        loadHomeFeed(json) { mergedBoot ->
                            bootJson = mergedBoot
                            appPrefs().edit()
                                .putString("theme_mode", "black")
                                .putBoolean("setup_done_v15_bw", true)
                                .apply()
                            buildShell()
                            showHome()
                            showRemoteNoticeIfNeeded()
                            showConfigUpdateIfNeeded(false)
                        }
                    } else {
                        showNetworkError(err ?: t("خطا در اتصال به Bankmovie", "Could not connect to Bankmovie"))
                    }
                }
            }
        }
    }

    private fun attachSmartHeader(scroll: ScrollView) {
        val headerAllowed = false
        if (::topBar.isInitialized) {
            topBar.visibility = View.GONE
            topBar.translationY = 0f
            topBar.alpha = 0f
        }

        val footerAllowed = currentScreen != "detail" && currentScreen != "player" && currentScreen != "search"
        val footerHeight = dp(if (isTvLike()) 66 else 92) + dp(22)

        fun showFooterNow(animated: Boolean = true) {
            if (!::bottomNav.isInitialized || !footerAllowed) return
            bottomNav.visibility = View.VISIBLE
            if (animated && !isTvLike()) {
                bottomNav.animate().translationY(0f).alpha(1f).setDuration(165).start()
            } else {
                bottomNav.animate().cancel()
                bottomNav.translationY = 0f
                bottomNav.alpha = 1f
            }
        }

        fun hideFooterNow() {
            if (!::bottomNav.isInitialized || !footerAllowed || isTvLike()) return
            if (bottomNav.visibility != View.VISIBLE) return
            bottomNav.animate()
                .translationY(footerHeight.toFloat())
                .alpha(0f)
                .setDuration(175)
                .withEndAction {
                    if (bottomNav.translationY > 0f) bottomNav.visibility = View.GONE
                }
                .start()
        }

        if (::bottomNav.isInitialized) {
            if (footerAllowed) showFooterNow(false) else bottomNav.visibility = View.GONE
        }

        if (isTvLike()) {
            scroll.layoutDirection = View.LAYOUT_DIRECTION_LTR
            scroll.isFocusable = false
            scroll.isFocusableInTouchMode = false
            scroll.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            scroll.isSmoothScrollingEnabled = false
            scroll.overScrollMode = View.OVER_SCROLL_NEVER
            scroll.post {
                applyTvFocusToClickableTree(scroll)
            }
        }

        // Detail/player/search do not use the floating bars. Do not install a second
        // scroll listener there: it would replace the detail-position listener and
        // adds work on every frame for no visual benefit.
        if (!headerAllowed && !footerAllowed) return

        var footerHiddenForScroll = false
        var lastY = 0
        scroll.setOnScrollChangeListener { _, _, sy, _, oldSy ->
            if (footerAllowed && !isTvLike()) {
                val goingDown = sy > oldSy && sy > dp(46)
                val goingUp = sy < oldSy || sy < dp(14)
                if (goingDown && !footerHiddenForScroll) {
                    footerHiddenForScroll = true
                    hideFooterNow()
                } else if (goingUp && footerHiddenForScroll) {
                    footerHiddenForScroll = false
                    showFooterNow(true)
                }
            } else if (footerAllowed && isTvLike()) {
                showFooterNow(false)
            }

            if (::topBar.isInitialized && headerAllowed) {
                val goingDown = sy > oldSy && sy > dp(40)
                if (goingDown && topBar.visibility == View.VISIBLE) {
                    topBar.animate().translationY(-dp(76).toFloat()).alpha(0f).setDuration(170).withEndAction { topBar.visibility = View.GONE }.start()
                } else if (!goingDown && sy < lastY) {
                    topBar.visibility = View.VISIBLE
                    topBar.animate().translationY(0f).alpha(1f).setDuration(170).start()
                }
            }
            lastY = sy
        }
    }

    private fun ui(raw: String): String {
        if (isFa()) return raw
        var s = raw.trim()
        val exact = mapOf(
            "خانه" to "Home",
            "جستجو" to "Search",
            "کالکشن‌ها" to "Collections",
            "پروفایل" to "Profile",
            "فیلم" to "Movie",
            "فیلم‌ها" to "Movies",
            "سریال" to "Series",
            "سریال‌ها" to "Series",
            "همه" to "All",
            "مشاهده همه ‹" to "View all ‹",
            "مشاهده همه" to "View all",
            "مشاهده همه نتایج" to "View all results",
            "مشاهده بیشتر" to "Load more",
            "مشاهده نتایج بیشتر" to "Load more results",
            "صفحه بعد" to "Next page",
            "در حال بارگذاری..." to "Loading...",
            "در حال جستجو..." to "Searching...",
            "نتایج در حال آماده‌سازی است" to "Preparing results",
            "در حال دریافت صفحه بازیگر" to "Loading actor page",
            "تلاش مجدد" to "Retry",
            "بارگذاری دوباره" to "Reload",
            "فیلم‌های بروز شده" to "Updated Movies",
            "سریال‌های بروز شده" to "Updated Series",
            "فیلم‌های به‌روز شده" to "Updated Movies",
            "سریال‌های به‌روز شده" to "Updated Series",
            "فیلم‌های جدید" to "New Movies",
            "سریال‌های جدید" to "New Series",
            "سریال‌های کره‌ای" to "Korean Series",
            "سریال‌های چینی" to "Chinese Series",
            "اکران 2025 و 2026" to "2025 and 2026 Releases",
            "سریال‌های آپدیت‌شده" to "Updated Series",
            "آرشیو ۱" to "Archive 1",
            "آرشیو ۲" to "Archive 2",
            "دوبله فارسی" to "Persian Dubbed",
            "برترین‌های 2026" to "Best of 2026",
            "پیشنهاد فیلم" to "Recommended",
            "انیمه" to "Anime",
            "ترکی" to "Turkish",
            "ادامه تماشا" to "Continue Watching",
            "واچ‌لیست" to "Watchlist",
            "آخرین بازدیدها" to "History",
            "هنوز چیزی برای ادامه تماشا نداری" to "Nothing to continue yet",
            "واچ‌لیست خالی است" to "Your watchlist is empty",
            "هنوز فیلمی باز نکردی" to "No recent titles yet",
            "هنوز چیزی ذخیره نشده" to "Nothing saved yet",
            "بروزرسانی" to "Updated",
            "محبوب" to "Popular",
            "لینک پخش مستقیم پیدا نشد" to "No direct playback link found",
            "انتخاب نسخه پخش" to "Choose playback version",
            "انتخاب فصل و قسمت" to "Choose season and episode",
            "فصل‌ها و قسمت‌ها / دانلود" to "Seasons, Episodes and Downloads",
            "دوبله" to "Dubbed",
            "زیرنویس" to "Subtitle",
            "سافت ساب" to "Soft-sub",
            "هاردساب" to "Hard-sub",
            "صوت دوبله" to "Dubbed Audio",
            "نسخه زیرنویس فارسی" to "Persian Subtitle Version",
            "لینک‌ها" to "Links",
            "لینک‌های دانلود" to "Download Links",
            "لینک‌های دانلود آماده است" to "Download links are ready",
            "سایر لینک‌ها" to "Other links",
            "فصل" to "Season",
            "قسمت" to "Episode",
            "قسمت‌ها" to "Episodes",
            "فیلم‌ها و سریال‌ها" to "Movies and Series",
            "فیلمی پیدا نشد" to "No title found",
            "برای این بازیگر هنوز اثری ثبت نشده است." to "No title is registered for this actor yet.",
            "خطا در دریافت کالکشن" to "Collection loading error",
            "خطا در دریافت بازیگر" to "Actor loading error",
            "خطا در جستجو" to "Search error",
            "نتیجه‌ای پیدا نشد" to "No results found",
            "با کلمه کوتاه‌تر یا تب همه امتحان کن" to "Try a shorter keyword or All tab",
            "برای دانلود VPN را خاموش کنید و از IP ایران استفاده نمایید." to "For downloads, turn off VPN and use an Iran IP.",
            "برای پخش روی دکمه سبز بزن. برای دانلود روی آیکن دانلود کنار هر نسخه بزن." to "Tap the green button to play. Tap the download icon next to each version to download.",
            ("کانال تلگرام @" + AppConfig.TELEGRAM_HANDLE) to ("Telegram Channel @" + AppConfig.TELEGRAM_HANDLE),
            "اطلاعات این بخش لود نشد" to "This section could not be loaded",
            "نامشخص" to "Unknown",
            "اپ فعال نیست" to "App is disabled",
            "متوجه شدم" to "Got it",
            "آپدیت جدید آماده است" to "Update available",
            "آپدیت الان" to "Update now",
            "بعداً" to "Later",
            "تغییرات نسخه" to "What is new",
            "آخرین نسخه" to "Latest",
            "نصب‌شده" to "Installed",
            "زبان برنامه" to "App language",
            "بررسی آپدیت داخلی" to "Check update",
            "پخش" to "Play",
            "دانلود" to "Download",
            "ادامه مطلب" to "Read more",
            "جعبه دانلود" to "Download Box",
            "پخش آنلاین" to "Watch Online",
            "تریلر" to "Trailer",
            "سال" to "Year",
            "بازیگر" to "Actor",
            "بازیگران" to "Cast",
            "اطلاعات فیلم" to "Movie Info",
            "اطلاعات سریال" to "Series Info",
            "دانلود فیلم" to "Download Movie",
            "دانلود سریال" to "Download Series",
            "مشاهده" to "View",
            "تلاش دوباره" to "Try again",
            "چیزی پیدا نشد" to "Nothing found",
            "تب همه یا کلمه کوتاه‌تر را امتحان کن" to "Try All tab or a shorter keyword",
            "نتیجه جدیدی باقی نمانده" to "No more results",
            "در حال آوردن همه نتایج..." to "Loading all results...",
            "صفحه بازیگر" to "Actor Page",
            "فیلم‌های این مجموعه" to "Titles in this collection",
            "فیلم‌های این بازیگر" to "Titles with this actor",
            "بازگشت" to "Back",
            "بستن" to "Close",
            "لغو" to "Cancel",
            "انتخاب لینک" to "Choose link",
            "دانلود با مرورگر" to "Download with browser",
            "کپی لینک" to "Copy link",
            "لینک کپی شد" to "Link copied",
            "بروزرسانی" to "Updated",
            "محبوب" to "Popular",
            "نامشخص" to "Unknown",
            "فصل" to "Season",
            "قسمت" to "Episode",
            "دانلود فایل" to "Download file",
            "نسخه انتخاب‌شده" to "Selected version",
            "دانلود مستقیم" to "Direct download",
            "لینک دانلود نامعتبر است" to "Invalid download link",
            "لینک مستقیم دانلود پیدا نشد" to "No direct download link found",
            "پیشنهاد فیلم" to "Recommended titles",
            "بازیگران" to "Cast",
            "کمتر" to "Less",
            "ادامه مطلب ⌄" to "Read more ⌄",
            "کمتر ⌃" to "Less ⌃"
        )
        exact[s]?.let { return it }
        s = s.replace("عنوان", "titles")
            .replace("فصل", "Season")
            .replace("قسمت", "Episode")
            .replace("خطا", "Error")
            .replace("در حال جستجو...", "Searching...")
            .replace("نتایج در حال آماده‌سازی است", "Preparing results")
            .replace("در حال بارگذاری...", "Loading...")
            .replace("مشاهده همه", "View all")
            .replace("دوبله فارسی", "Persian Dubbed")
            .replace("زیرنویس فارسی", "Persian Subtitle")
            .replace("صوت دوبله", "Dubbed Audio")
            .replace("هاردساب", "Hard-sub")
            .replace("سافت ساب", "Soft-sub")
            .replace("دوبله", "Dubbed")
            .replace("زیرنویس", "Subtitle")
            .replace("فیلم", "Movie")
            .replace("سریال", "Series")
            .replace("کالکشن", "Collection")
        return s
    }

    private fun tvFocusHaloDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val glow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(42, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val inner = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radiusDp - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(165, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, inner)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyMobileTouchHalo(view: View, radiusDp: Int = 18) {
        if (isTvLike() || Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return
        val accent = UiPreferences.palette(this).primary
        val mask = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.WHITE)
        }
        view.foreground = android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(Color.argb(92, Color.red(accent), Color.green(accent), Color.blue(accent))),
            null,
            mask
        )
    }

    private fun drawerItem(title: String, iconRes: Int, action: () -> Unit): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(17), 0, dp(17), 0)
            background = bankGlassDrawable(16, 190, 38, false)
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 16)
            applyTvFocusHalo(this, 14, 1.025f, 0f)

            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.rgb(240, 240, 243))
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(18) })
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(Color.rgb(242, 242, 245))
                textSize = 16.2f
                typeface = BankmovieFonts.medium(this@MainActivity)
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -1, 1f))
            setOnClickListener { action() }
        }
    }

    private fun showAppDrawer(menuIcon: MorphHamburgerView? = null) {
        if (isTvLike()) {
            showTvQuickMenu()
            return
        }
        val decor = window.decorView as? ViewGroup ?: return
        val existing = decor.findViewWithTag<View>("bm_fast_drawer")
        if (existing != null) {
            menuIcon?.setOpened(false, animate = true)
            existing.animate().alpha(0f).setDuration(110L).withEndAction {
                (existing.parent as? ViewGroup)?.removeView(existing)
            }.start()
            return
        }

        val p = UiPreferences.palette(this)
        val screenW = resources.displayMetrics.widthPixels
        val drawerWidth = (screenW * 0.82f).toInt().coerceAtMost(dp(390)).coerceAtLeast(dp(286))
        var closing = false
        val overlay = FrameLayout(this).apply {
            tag = "bm_fast_drawer"
            isClickable = true
            isFocusable = true
            setBackgroundColor(Color.argb(145, 0, 0, 0))
            alpha = 0f
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(24), dp(18), dp(20))
            background = bankGlassDrawable(0, 250, 56, true)
            elevation = dp(14).toFloat()
            isClickable = true
            translationX = (drawerWidth + dp(24)).toFloat()
        }

        fun close(after: (() -> Unit)? = null) {
            if (closing) return
            closing = true
            menuIcon?.setOpened(false, animate = true)
            panel.animate().translationX((drawerWidth + dp(24)).toFloat()).setDuration(150L)
                .setInterpolator(android.view.animation.AccelerateInterpolator(1.2f)).start()
            overlay.animate().alpha(0f).setDuration(130L).withEndAction {
                (overlay.parent as? ViewGroup)?.removeView(overlay)
                after?.invoke()
            }.start()
        }
        overlay.setOnClickListener { close() }
        panel.setOnClickListener { }

        val logged = AccountSession.isLoggedIn(this)
        val user = AccountSession.user(this)
        val displayName = user.optString("username").ifBlank { user.optString("email") }.ifBlank { t("کاربر مهمان", "Guest") }
        val vip = logged && accountUserIsVip(user)

        val profileTop = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        }
        val avatarShell = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(24, 24, 26))
                setStroke(dp(2), if (vip) Color.rgb(183, 134, 255) else Color.rgb(82, 82, 88))
            }
            clipToOutline = true
            addView(ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                if (logged) bindAccountAvatar(this, user) else setImageResource(R.drawable.avatar_default)
            }, FrameLayout.LayoutParams(-1, -1))
        }
        profileTop.addView(avatarShell, LinearLayout.LayoutParams(dp(88), dp(88)).apply { bottomMargin = dp(10) })
        profileTop.addView(TextView(this).apply {
            text = displayName
            setTextColor(if (vip) Color.rgb(207, 166, 255) else Color.WHITE)
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-1, -2))
        if (vip) profileTop.addView(TextView(this).apply {
            text = t("VIP", "VIP")
            setTextColor(Color.rgb(208, 171, 255))
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(9), dp(3), dp(9), dp(3))
            background = rounded(Color.argb(40, 183, 134, 255), dp(999), Color.argb(100, 183, 134, 255))
        }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(6) })
        panel.addView(profileTop, LinearLayout.LayoutParams(-1, -2))

        panel.addView(View(this).apply { setBackgroundColor(Color.rgb(35,35,38)) }, LinearLayout.LayoutParams(-1, dp(1)).apply { bottomMargin = dp(8) })

        val scroll = BankmovieSmoothScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
        }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(3), 0, dp(18)) }
        scroll.addView(box)
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun add(title: String, icon: Int, action: () -> Unit) {
            box.addView(drawerItem(title, icon) { close(action) }, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(5) })
        }
        add(if (logged) t("پروفایل", "Profile") else t("ورود / ثبت‌نام", "Sign in"), R.drawable.ic_nav_profile) { if (logged) showProfile() else startActivity(Intent(this, AuthActivity::class.java)) }
        add(t("خانه", "Home"), R.drawable.ic_nav_home) { showHome() }
        add(t("جستجو", "Search"), R.drawable.ic_search_clean) { showSearch() }
        add(t("دسته‌بندی‌ها", "Categories"), R.drawable.ic_nav_grid) { showCategories() }
        add(t("کالکشن‌ها", "Collections"), R.drawable.ic_nav_movie) { showCollections() }
        add(t("باکس آفیس", "Box Office"), R.drawable.ic_imdb) { showBoxOffice() }
        add(t("واچ‌لیست", "Watchlist"), R.drawable.ic_nav_heart) { showFavorites() }
        add(t("دانلودها", "Downloads"), R.drawable.ic_download) { startActivity(Intent(this, DownloadsActivity::class.java)) }
        add(t("ورود به Watch Party", "Join Watch Party"), R.drawable.ic_watch_party) { showWatchPartyJoinDialog() }
        add(t("اعلان‌ها", "Notifications"), R.drawable.ic_notifications) { showNotificationCenter() }
        add(t("راهنما", "Help"), R.drawable.ic_info_archive) { showHelpCenter() }
        add(t("تنظیمات", "Settings"), R.drawable.ic_player_settings) { showSettingsPage() }
        BankmovieFonts.applyToTree(this, panel)

        overlay.addView(panel, FrameLayout.LayoutParams(drawerWidth, -1, Gravity.RIGHT))
        decor.addView(overlay, ViewGroup.LayoutParams(-1, -1))
        overlay.animate().alpha(1f).setDuration(120L).start()
        panel.animate().translationX(0f).setDuration(190L)
            .setInterpolator(android.view.animation.PathInterpolator(0.16f, 0.96f, 0.28f, 1f)).start()

        if (logged) {
            val now = System.currentTimeMillis()
            if (now - lastAccountIdentityRefreshAt > 15_000L) {
                lastAccountIdentityRefreshAt = now
                // PASS 4.7: refresh account identity silently. The old implementation
                // closed and rebuilt the drawer after refresh, causing the logged-in
                // menu to appear -> disappear -> appear on every open.
                AccountApi.refreshMe(this) { }
            }
        }
    }

    private fun unclampFocusGlow(view: View) {
        var parent = view.parent
        while (parent is ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun collectTvFocusables(view: View, out: MutableList<View>) {
        if (view.visibility != View.VISIBLE || !view.isEnabled) return
        if (view.isFocusable && (view.hasOnClickListeners() || view is EditText)) out.add(view)
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) collectTvFocusables(view.getChildAt(i), out)
        }
    }

    private fun rememberTvFocusPosition(view: View) {
        if (!isTvLike() || !::content.isInitialized) return
        val focusables = mutableListOf<View>()
        collectTvFocusables(content, focusables)
        val index = focusables.indexOf(view)
        if (index >= 0) tvFocusIndexByScreen[currentScreen] = index
    }

    private fun scrollTvFocusedIntoView(view: View) {
        // Android TV's native focus engine already reveals focused descendants of
        // ScrollView/HorizontalScrollView. Explicit smoothScroll calls caused the
        // whole page to jump vertically and horizontally on every D-pad press.
        // Keep this intentionally empty.
    }

    private fun isDescendantOf(view: View?, rootView: View): Boolean {
        var node = view ?: return false
        while (true) {
            if (node === rootView) return true
            val parent = node.parent
            if (parent !is View) return false
            node = parent
        }
    }

    private fun tvQuickMenuItem(title: String, iconRes: Int, onClick: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), 0, dp(18), 0)
            background = bankGlassDrawable(19, 226, 62, false)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.rgb(188, 130, 255))
            }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginEnd = dp(14) })
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, -1, 1f))
            applyTvFocusHalo(this, 20, 1.035f, dp(2).toFloat())
            setOnClickListener { onClick() }
        }
    }

    private fun showTvQuickMenu() {
        if (!isTvLike() || tvQuickMenuShowing) return
        val previousFocus = currentFocus
        tvQuickMenuShowing = true
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            setPadding(dp(18), dp(22), dp(18), dp(18))
            background = rounded(Color.rgb(14, 13, 20), dp(26), Color.argb(180, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(TextView(this).apply {
            text = "منوی سریع بانک مووی"
            setTextColor(white)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val entries = listOf(
            Triple(t("خانه", "Home"), R.drawable.ic_nav_home, { dialog.dismiss(); showHome() }),
            Triple(t("جستجو", "Search"), R.drawable.ic_search_clean, { dialog.dismiss(); showSearch() }),
            Triple(t("دسته‌بندی", "Categories"), R.drawable.ic_nav_grid, { dialog.dismiss(); showCategories() }),
            Triple(t("علاقه‌مندی‌ها", "Watchlist"), R.drawable.ic_nav_heart, { dialog.dismiss(); showFavorites() }),
            Triple(t("پروفایل", "Profile"), R.drawable.ic_nav_profile, { dialog.dismiss(); showProfile() }),
            Triple(t("دانلودها", "Downloads"), R.drawable.ic_download, { dialog.dismiss(); startActivity(Intent(this, DownloadsActivity::class.java)) }),
            Triple(t("Watch Party", "Watch Party"), R.drawable.ic_watch_party, { dialog.dismiss(); showWatchPartyJoinDialog() }),
            Triple(t("تنظیمات", "Settings"), R.drawable.ic_player_settings, { dialog.dismiss(); showSettingsPage() })
        )
        val rows = mutableListOf<View>()
        entries.forEach { entry ->
            val row = tvQuickMenuItem(entry.first, entry.second, entry.third).apply {
                id = View.generateViewId()
                isFocusable = true
                isFocusableInTouchMode = false
            }
            rows += row
            box.addView(row, LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(9) })
        }
        rows.forEachIndexed { index, row ->
            val previous = rows[(index - 1 + rows.size) % rows.size]
            val next = rows[(index + 1) % rows.size]
            row.nextFocusUpId = previous.id
            row.nextFocusLeftId = previous.id
            row.nextFocusDownId = next.id
            row.nextFocusRightId = next.id
            row.setOnKeyListener { _, keyCode, event ->
                if (event.action != android.view.KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                when (keyCode) {
                    android.view.KeyEvent.KEYCODE_DPAD_UP,
                    android.view.KeyEvent.KEYCODE_DPAD_LEFT -> previous.requestFocus()
                    android.view.KeyEvent.KEYCODE_DPAD_DOWN,
                    android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> next.requestFocus()
                    else -> return@setOnKeyListener false
                }
                true
            }
        }

        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.setOnDismissListener {
            tvQuickMenuShowing = false
            previousFocus?.postDelayed({ if (previousFocus.isShown) previousFocus.requestFocus() }, 80)
        }
        dialog.show()
        dialog.window?.apply {
            setBackgroundDrawableResource(android.R.color.transparent)
            setDimAmount(0.64f)
            attributes = attributes.apply {
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                width = dp(420).coerceAtMost((resources.displayMetrics.widthPixels * 0.48f).toInt())
                height = ViewGroup.LayoutParams.WRAP_CONTENT
            }
        }
        applyTvFocusToClickableTree(box)
        focusFirstTvClickable(box, rows.firstOrNull())
    }

    private fun applyTvFocusHalo(
        view: View,
        radiusDp: Int = 24,
        scale: Float = 1.055f,
        normalElevation: Float = 0f,
        onFocusUi: ((View, Boolean) -> Unit)? = null
    ) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        unclampFocusGlow(view)
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            if (has) {
                unclampFocusGlow(v)
                rememberTvFocusPosition(v)
            }
            v.foreground = if (has) tvFocusHaloDrawable(radiusDp) else originalForeground
            val lowPower = lowEndDevice
            v.elevation = if (has && !lowPower) dp(22).toFloat() else normalElevation
            v.translationZ = if (has && !lowPower) dp(8).toFloat() else 0f
            onFocusUi?.invoke(v, has)
            val appliedScale = if (lowPower) minOf(scale, 1.025f) else scale
            v.animate()
                .scaleX(if (has) appliedScale else 1f)
                .scaleY(if (has) appliedScale else 1f)
                .alpha(1f)
                .setDuration(if (lowPower) 55L else if (has) 120L else 90L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        val pm = packageManager
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
            pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK) ||
            pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEVISION) ||
            resources.configuration.smallestScreenWidthDp >= 600
    }


    private data class TvFocusNode(
        val view: View,
        val centerX: Int,
        val centerY: Int,
        val width: Int,
        val height: Int
    )

    private fun hasClickableTvAncestor(view: View, stopAt: View): Boolean {
        var parent = view.parent
        while (parent is View) {
            if (parent === stopAt) return false
            if (parent.isFocusable && parent.hasOnClickListeners()) return true
            parent = parent.parent
        }
        return false
    }

    private fun collectTvFocusNodes(scope: View): List<TvFocusNode> {
        val result = mutableListOf<TvFocusNode>()
        fun walk(v: View) {
            if (v.visibility != View.VISIBLE || !v.isEnabled) return
            if (v.isFocusable && v.hasOnClickListeners() && !hasClickableTvAncestor(v, scope)) {
                if (v.id == View.NO_ID) v.id = View.generateViewId()
                val location = IntArray(2)
                v.getLocationOnScreen(location)
                result += TvFocusNode(
                    v,
                    location[0] + v.width / 2,
                    location[1] + v.height / 2,
                    v.width.coerceAtLeast(1),
                    v.height.coerceAtLeast(1)
                )
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(scope)
        return result
    }

    private fun wireTvFocusGraph(scope: View) {
        if (!isTvLike() || !scope.isShown || currentScreen == "detail" || currentScreen == "player") return
        val nodes = collectTvFocusNodes(scope)
        if (nodes.size < 2) return

        fun horizontalNeighbor(node: TvFocusNode, direction: Int): TvFocusNode? {
            val sameBand = nodes.filter { other ->
                other !== node && kotlin.math.abs(other.centerY - node.centerY) <= maxOf(node.height, other.height) * 0.55f
            }
            return sameBand
                .filter { if (direction < 0) it.centerX < node.centerX else it.centerX > node.centerX }
                .minByOrNull { kotlin.math.abs(it.centerX - node.centerX) + kotlin.math.abs(it.centerY - node.centerY) * 3 }
        }

        fun verticalNeighbor(node: TvFocusNode, direction: Int): TvFocusNode? {
            return nodes
                .filter { other ->
                    other !== node &&
                        if (direction < 0) other.centerY < node.centerY - dp(8)
                        else other.centerY > node.centerY + dp(8)
                }
                .minByOrNull { other ->
                    val dy = kotlin.math.abs(other.centerY - node.centerY)
                    val dx = kotlin.math.abs(other.centerX - node.centerX)
                    dy * 4 + dx
                }
        }

        nodes.forEach { node ->
            if (node.view.nextFocusLeftId == View.NO_ID) {
                horizontalNeighbor(node, -1)?.let { node.view.nextFocusLeftId = it.view.id }
            }
            if (node.view.nextFocusRightId == View.NO_ID) {
                horizontalNeighbor(node, 1)?.let { node.view.nextFocusRightId = it.view.id }
            }
            if (node.view.nextFocusUpId == View.NO_ID) {
                verticalNeighbor(node, -1)?.let { node.view.nextFocusUpId = it.view.id }
            }
            if (node.view.nextFocusDownId == View.NO_ID) {
                verticalNeighbor(node, 1)?.let { node.view.nextFocusDownId = it.view.id }
            }
        }
    }

    private fun scheduleTvFocusGraph(scope: View) {
        if (!isTvLike() || currentScreen == "detail" || currentScreen == "player") return
        val generation = ++tvFocusGraphGeneration
        val graphScope = scope
        uiHandler.postDelayed({
            if (generation == tvFocusGraphGeneration && graphScope.isShown) {
                wireTvFocusGraph(graphScope)
            }
        }, 480L)
    }

    private fun applyTvFocusToClickableTree(view: View) {
        BankmovieFonts.applyToTree(this, view)
        if (!isTvLike()) return
        view.post {
            fun walk(v: View) {
                if (v is ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                    v.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
                }
                val isContainer = v is ScrollView || v is HorizontalScrollView || v is GridLayout
                if (isContainer) {
                    v.isFocusable = false
                    v.isFocusableInTouchMode = false
                }
                val focusTarget = v.hasOnClickListeners() || v is EditText
                if (!isContainer && focusTarget && v.visibility == View.VISIBLE && v.isEnabled) {
                    applyTvFocusHalo(v, if (v is EditText) 16 else 22, if (v is EditText) 1.015f else 1.045f, v.elevation)
                }
                if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
            }
            walk(view)
            // Never steal focus from the footer or another visible control when
            // asynchronous rails finish loading. That was the source of the
            // random page jumps visible in the TV recording.
            scheduleTvFocusGraph(view)
        }
    }

    private fun focusFirstTvClickable(view: View, preferred: View? = null) {
        if (!isTvLike()) return
        view.postDelayed({
            if (preferred != null && preferred.visibility == View.VISIBLE && preferred.isFocusable && preferred.requestFocus()) return@postDelayed
            fun walk(v: View): Boolean {
                if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && (v.hasOnClickListeners() || v is EditText)) {
                    v.requestFocus()
                    return true
                }
                if (v is ViewGroup) {
                    for (i in 0 until v.childCount) {
                        if (walk(v.getChildAt(i))) return true
                    }
                }
                return false
            }
            walk(view)
        }, 95)
    }

    private fun styleShownDialog(
        dialog: AlertDialog,
        body: View,
        preferredFocus: View? = null,
        maxWidthDp: Int = 500,
        fullScreen: Boolean = false,
        dimAmount: Float = 0.58f
    ) {
        val win = dialog.window ?: return
        win.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        win.setDimAmount(dimAmount)
        win.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        if (fullScreen) {
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        } else {
            val side = if (isTvLike()) dp(48) else dp(24)
            val width = (resources.displayMetrics.widthPixels - side).coerceAtMost(dp(if (isTvLike()) maxWidthDp.coerceAtLeast(620) else maxWidthDp))
            win.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
        val decor = win.decorView
        decor.animate().cancel()
        decor.alpha = 0f
        decor.scaleX = 0.97f
        decor.scaleY = 0.97f
        decor.translationY = dp(10).toFloat()
        decor.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .translationY(0f)
            .setDuration(180L)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
        if (isTvLike()) {
            applyTvFocusToClickableTree(body)
            focusFirstTvClickable(body, preferredFocus)
        }
    }


    private fun tvGridColumns(): Int = 8

    private fun tvGridCardWidth(): Int {
        val columns = tvGridColumns()
        val available = resources.displayMetrics.widthPixels - dp(36)
        return (available / columns - dp(14)).coerceAtLeast(dp(118))
    }

    private fun tvGridCardHeight(width: Int): Int {
        return (width * 1.88f).toInt().coerceAtLeast(dp(235))
    }

    private fun mobileGridSideMarginDp(): Int {
        val widthDp = resources.configuration.screenWidthDp
        return if (widthDp in 1..380) 4 else 6
    }

    private fun mobileGridCardWidth(columns: Int = 3): Int {
        val density = resources.displayMetrics.density.coerceAtLeast(1f)
        val widthDp = resources.configuration.screenWidthDp
            .takeIf { it > 0 }
            ?: (resources.displayMetrics.widthPixels / density).roundToInt()

        val pagePaddingDp = 24
        val perCardMarginsDp = mobileGridSideMarginDp() * 2
        val safetyDp = 12
        val availableDp = widthDp - pagePaddingDp - (columns * perCardMarginsDp) - safetyDp
        val cardDp = (availableDp / columns).coerceIn(84, 116)
        return dp(cardDp)
    }

    private fun mobileGridCardHeight(width: Int, tall: Boolean = false): Int {
        val ratio = if (tall) 2.17f else 1.91f
        val minimum = if (tall) dp(196) else dp(176)
        return (width * ratio).roundToInt().coerceAtLeast(minimum)
    }

    private fun buildShell() {
        applyThemeColors()
        val tv = isTvLike()
        root = FrameLayout(this).apply {
            setBackgroundColor(bg)
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            clipChildren = false
            clipToPadding = false
        }

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }

        content = FrameLayout(this).apply {
            setBackgroundColor(bg)
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            clipChildren = false
            clipToPadding = false
            setOnHierarchyChangeListener(object : ViewGroup.OnHierarchyChangeListener {
                override fun onChildViewAdded(parent: View?, child: View?) {
                    child ?: return
                    child.post { BankmovieFonts.applyToTree(this@MainActivity, child) }
                    child.animate().cancel()
                    child.alpha = 0f
                    child.translationY = dp(if (tv) 4 else 7).toFloat()
                    child.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(if (tv) 135L else 175L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                override fun onChildViewRemoved(parent: View?, child: View?) = Unit
            })
        }

        bottomNav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            setPadding(dp(if (tv) 8 else 8), dp(if (tv) 5 else 6), dp(if (tv) 8 else 8), dp(if (tv) 5 else 6))
            val p = UiPreferences.palette(this@MainActivity)
            background = bankGlassDrawable(
                if (tv) 36 else 999,
                if (tv) 242 else 230,
                if (tv) 94 else 72,
                true
            )
            elevation = dp(if (tv) 18 else 22).toFloat()
            alpha = 1f
            translationY = 0f
        }

        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        root.addView(bottomNav, FrameLayout.LayoutParams(if (tv) dp(760) else -1, dp(if (tv) 70 else 78), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = dp(if (tv) 120 else 18)
            rightMargin = dp(if (tv) 120 else 18)
            bottomMargin = dp(if (tv) 12 else 10)
        })
        setContentView(root)
        buildBottomNav()
        root.post { BankmovieFonts.applyToTree(this, root) }
    }

    private fun buildBottomNav() {
        bottomNav.removeAllViews()
        navSvg(t("خانه", "Home"), "home", R.drawable.ic_nav_home) { showHome() }
        navSvg(t("جستجو", "Search"), "search", R.drawable.ic_search_clean) { showSearch() }
        navSvg(t("دسته‌بندی", "Categories"), "categories", R.drawable.ic_nav_grid) { showCategories() }
        navSvg(t("پروفایل", "Profile"), "profile", R.drawable.ic_nav_profile) { showProfile() }
        navSvg(t("علاقه‌مندی‌ها", "Favorites"), "favorites", R.drawable.ic_nav_heart) { showFavorites() }
    }

    private fun navSvg(label: String, key: String, iconRes: Int, action: () -> Unit) {
        val active = currentScreen == key
        val tv = isTvLike()
        val p = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = if (active) {
                bankPrimaryGlassDrawable(999)
            } else {
                rounded(Color.TRANSPARENT, dp(999), Color.TRANSPARENT)
            }
            setPadding(dp(if (tv) 3 else 4), dp(if (tv) 4 else 6), dp(if (tv) 3 else 4), dp(if (tv) 3 else 5))
            applyTvFocusHalo(this, if (tv) 26 else 32, if (tv) 1.045f else 1.035f, 0f)
            applyMobileTouchHalo(this, 999)
            setOnClickListener {
                animate().cancel()
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(170)
                        .setInterpolator(android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f))
                        .start()
                    action()
                }.start()
            }
        }
        val activeColor = p.primary
        val inactiveColor = Color.argb(238, 255, 255, 255)
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(if (active) activeColor else inactiveColor)
            alpha = if (active) 1f else 0.92f
        }, LinearLayout.LayoutParams(dp(if (tv) 22 else 25), dp(if (tv) 22 else 25)).apply {
            bottomMargin = dp(if (tv) 2 else 3)
        })
        box.addView(TextView(this).apply {
            text = label
            setTextColor(if (active) activeColor else inactiveColor)
            textSize = if (tv) 9.4f else if (active) 11.2f else 10.3f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
        })
        bottomNav.addView(box, LinearLayout.LayoutParams(0, -1, 1f).apply {
            marginStart = dp(if (tv) 4 else 4)
            marginEnd = dp(if (tv) 4 else 4)
        })
        if (tv && active) box.post { scheduleTvFocusGraph(root) }
    }

    private fun nav(label: String, key: String, icon: String, action: () -> Unit) {
        val active = currentScreen == key
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = if (active) blueGradient(dp(22)) else rounded(Color.TRANSPARENT, dp(22), Color.TRANSPARENT)
            setPadding(dp(4), dp(6), dp(4), dp(4))
            setOnClickListener { action() }
        }
        box.addView(TextView(this).apply {
            text = icon
            setTextColor(if (active) white else Color.argb(210, 190, 205, 225))
            textSize = 18f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) rounded(Color.argb(35, 255, 255, 255), dp(14), Color.TRANSPARENT) else null
            setPadding(dp(10), dp(4), dp(10), dp(4))
        })
        box.addView(TextView(this).apply { text = label; setTextColor(if (active) white else muted); textSize = 10.5f; gravity = Gravity.CENTER; maxLines = 1; setPadding(0, dp(3), 0, 0) })
        bottomNav.addView(box, LinearLayout.LayoutParams(0, dp(60), 1f).apply { marginStart = dp(3); marginEnd = dp(3) })
    }

    private fun clear() {
        captureActiveDetailScroll()
        if (currentScreen != "detail") {
            applyThemeColors()
        }
        topBar.visibility = View.GONE
        isMainHomePage = false
        content.removeAllViews()
        activeDetailScrollView = null
        activeDetailScrollKey = ""
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = if (currentScreen == "detail" || currentScreen == "player" || currentScreen == "search") View.GONE else View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }
    }

    private fun movieDetailLoading(seed: JSONObject): View {
        val tv = isTvLike()

        fun skeletonBox(width: Int, height: Int, radius: Int = 14): FrameLayout {
            return FrameLayout(this).apply {
                background = rounded(Color.rgb(15, 18, 23), dp(radius), Color.argb(44, 255, 255, 255))
                clipToOutline = true
                addView(View(this@MainActivity).apply {
                    background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                }, FrameLayout.LayoutParams(-1, -1))
                layoutParams = LinearLayout.LayoutParams(width, height)
            }
        }

        val root = FrameLayout(this).apply { setBackgroundColor(bg) }
        val scroll = BankmovieSmoothScrollView(this).apply {
            isEnabled = false
            isFocusable = false
            isClickable = false
            setPadding(0, 0, 0, dp(24))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(28))
        }

        // Social-feed style skeleton: the actual detail geometry is visible from
        // the first frame, so loading no longer feels like a blank blocking screen.
        val heroHeight = if (tv) dp(400) else dp(500)
        val hero = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            clipToOutline = true
        }
        hero.addView(skeletonBox(-1, -1, 0), FrameLayout.LayoutParams(-1, -1))
        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.rgb(7, 9, 12))
            )
        }, FrameLayout.LayoutParams(-1, -1))

        if (!tv) {
            hero.addView(skeletonBox(dp(104), dp(156), 17), FrameLayout.LayoutParams(dp(104), dp(156), Gravity.RIGHT or Gravity.BOTTOM).apply {
                rightMargin = dp(18)
                bottomMargin = dp(72)
            })
        }

        val textStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            setPadding(dp(20), 0, if (!tv) dp(140) else dp(20), dp(76))
        }
        textStack.addView(skeletonBox(if (tv) dp(360) else dp(210), dp(34), 9), LinearLayout.LayoutParams(if (tv) dp(360) else dp(210), dp(34)).apply {
            gravity = Gravity.RIGHT; bottomMargin = dp(10)
        })
        textStack.addView(skeletonBox(if (tv) dp(260) else dp(150), dp(15), 7), LinearLayout.LayoutParams(if (tv) dp(260) else dp(150), dp(15)).apply {
            gravity = Gravity.RIGHT; bottomMargin = dp(9)
        })
        textStack.addView(skeletonBox(if (tv) dp(310) else dp(180), dp(13), 7), LinearLayout.LayoutParams(if (tv) dp(310) else dp(180), dp(13)).apply {
            gravity = Gravity.RIGHT; bottomMargin = dp(8)
        })
        textStack.addView(skeletonBox(if (tv) dp(470) else dp(220), dp(12), 6), LinearLayout.LayoutParams(if (tv) dp(470) else dp(220), dp(12)).apply {
            gravity = Gravity.RIGHT; bottomMargin = dp(7)
        })
        textStack.addView(skeletonBox(if (tv) dp(420) else dp(190), dp(12), 6), LinearLayout.LayoutParams(if (tv) dp(420) else dp(190), dp(12)).apply {
            gravity = Gravity.RIGHT
        })
        hero.addView(textStack, FrameLayout.LayoutParams(-1, -1))

        val actionSkeleton = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), 0, dp(18), dp(14))
            addView(skeletonBox(0, dp(52), 999), LinearLayout.LayoutParams(0, dp(52), 1.25f).apply { marginEnd = dp(4) })
            addView(skeletonBox(0, dp(52), 999), LinearLayout.LayoutParams(0, dp(52), 0.92f).apply { marginStart = dp(4) })
        }
        hero.addView(actionSkeleton, FrameLayout.LayoutParams(-1, dp(68), Gravity.BOTTOM))
        page.addView(hero, LinearLayout.LayoutParams(-1, heroHeight).apply { bottomMargin = dp(18) })

        fun sectionTitleSkeleton() = skeletonBox(if (tv) dp(220) else dp(145), dp(24), 8).apply {
            layoutParams = LinearLayout.LayoutParams(if (tv) dp(220) else dp(145), dp(24)).apply {
                gravity = Gravity.RIGHT; bottomMargin = dp(12)
            }
        }

        page.addView(sectionTitleSkeleton())
        val actors = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            repeat(if (tv) 6 else 4) {
                val person = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    addView(skeletonBox(dp(if (tv) 76 else 62), dp(if (tv) 76 else 62), 999))
                    addView(skeletonBox(dp(if (tv) 82 else 66), dp(10), 5), LinearLayout.LayoutParams(dp(if (tv) 82 else 66), dp(10)).apply { topMargin = dp(7) })
                }
                addView(person, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(12) })
            }
        }
        page.addView(actors, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) })

        page.addView(sectionTitleSkeleton())
        val downloadSkeleton = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(8, 12, 18), dp(22), Color.argb(54, 255, 255, 255))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            repeat(3) {
                addView(skeletonBox(-1, dp(58), 16), LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = if (it < 2) dp(9) else 0 })
            }
        }
        page.addView(downloadSkeleton, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })

        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        return root
    }


    private fun skeletonPosterCard(width: Int, height: Int): View {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))
            alpha = 0.88f
            layoutParams = ViewGroup.MarginLayoutParams(width, height).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
                bottomMargin = dp(12)
            }
        }
        wrap.addView(FrameLayout(this).apply {
            background = rounded(Color.rgb(15, 22, 34), dp(18), Color.rgb(28, 40, 60))
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(18, 28, 42), Color.rgb(36, 48, 68), Color.rgb(18, 28, 42))).apply {
                    cornerRadius = dp(18).toFloat()
                }
            }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(-1, (height * 0.72f).roundToInt()))
        wrap.addView(View(this).apply { background = rounded(Color.rgb(22, 32, 48), dp(6), Color.TRANSPARENT) }, LinearLayout.LayoutParams(-1, dp(13)).apply { topMargin = dp(8); marginStart = dp(4); marginEnd = dp(4) })
        wrap.addView(View(this).apply { background = rounded(Color.rgb(16, 24, 38), dp(5), Color.TRANSPARENT) }, LinearLayout.LayoutParams((width * 0.62f).roundToInt(), dp(10)).apply { topMargin = dp(6); marginStart = dp(4); marginEnd = dp(4) })
        return wrap
    }

    private fun contentSkeletonRows(rows: Int = 4): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            repeat(rows.coerceIn(1, 10)) { index ->
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                    background = bankGlassDrawable(19, 226, 62, false)
                    addView(FrameLayout(this@MainActivity).apply {
                        background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                        clipToOutline = true
                    }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
                    addView(LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        repeat(3) { line ->
                            addView(FrameLayout(this@MainActivity).apply { background = PosterShimmerDrawable(lowEndDevice).also { it.start() } }, LinearLayout.LayoutParams(if(line==0) dp(190) else dp(if(line==1)145 else 105), dp(if(line==0)14 else 10)).apply { bottomMargin=dp(if(line<2)8 else 0) })
                        }
                    }, LinearLayout.LayoutParams(0,-2,1f))
                }, LinearLayout.LayoutParams(-1, dp(82)).apply { bottomMargin=dp(if(index==rows-1)0 else 7) })
            }
        }
    }

    private fun actorPageLoadingSkeleton(): View {
        val tv = isTvLike()
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(24))

            if (tv) {
                addView(contentSkeletonRows(4), LinearLayout.LayoutParams(-1, -2))
                return@apply
            }

            addView(FrameLayout(this@MainActivity).apply {
                setBackgroundColor(Color.rgb(4, 4, 6))
                addView(View(this@MainActivity).apply {
                    background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                }, FrameLayout.LayoutParams(-1, -1))
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                    setPadding(dp(18), dp(70), dp(18), dp(25))
                    addView(FrameLayout(this@MainActivity).apply {
                        background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                        clipToOutline = true
                    }, LinearLayout.LayoutParams(dp(112), dp(112)).apply { bottomMargin = dp(12) })
                    addView(FrameLayout(this@MainActivity).apply {
                        background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                    }, LinearLayout.LayoutParams(dp(105), dp(27)).apply { bottomMargin = dp(12) })
                    addView(FrameLayout(this@MainActivity).apply {
                        background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                    }, LinearLayout.LayoutParams(dp(230), dp(28)))
                }, FrameLayout.LayoutParams(-1, -1))
            }, LinearLayout.LayoutParams(-1, dp(360)))

            val body = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(18), dp(12), dp(28))
                addView(FrameLayout(this@MainActivity).apply {
                    background = PosterShimmerDrawable(lowEndDevice).also { it.start() }
                }, LinearLayout.LayoutParams(dp(120), dp(13)).apply {
                    gravity = Gravity.LEFT
                    bottomMargin = dp(16)
                })

                val grid = GridLayout(this@MainActivity).apply {
                    columnCount = 3
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    alignmentMode = GridLayout.ALIGN_BOUNDS
                    useDefaultMargins = false
                }
                val w = mobileGridCardWidth()
                val h = mobileGridCardHeight(w)
                repeat(6) { index ->
                    grid.addView(skeletonPosterCard(w, h), GridLayout.LayoutParams().apply {
                        width = 0
                        height = h
                        columnSpec = GridLayout.spec(index % 3, 1f)
                        setMargins(dp(3), dp(3), dp(3), dp(9))
                    })
                }
                addView(grid, LinearLayout.LayoutParams(-1, -2))
            }
            addView(body, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun movieSpecChip(label: String, strong: Boolean = false): TextView {
        return TextView(this).apply {
            text = label.ifBlank { "-" }
            setTextColor(if (strong) Color.rgb(255, 230, 150) else white)
            textSize = 10.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            background = rounded(Color.argb(185, 10, 14, 22), dp(12), Color.argb(100, 255, 255, 255))
            setPadding(dp(8), dp(5), dp(8), dp(5))
        }
    }

    private fun posterSpecsOverlay(item: JSONObject): FrameLayout {
        val frame = FrameLayout(this)
        val rating = cleanRating(item.optString("rating"))
        val year = item.optString("year").trim()
        val bottomSpecs = mutableListOf<String>()
        item.optString("runtime").takeIf { it.isNotBlank() }?.let { bottomSpecs.add(it) }
        if (item.optBoolean("has_dubbed")) bottomSpecs.add("دوبله")
        if (item.optBoolean("has_subtitle")) bottomSpecs.add("زیرنویس")
        detailListText(item, "country").ifBlank { detailListText(item, "countries") }
            .takeIf { it.isNotBlank() }?.let { bottomSpecs.add(it) }

        if (rating.isNotBlank() && rating != "-") {
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(7), 0, dp(7), 0)
                addView(imdbCompactBadge(rating), LinearLayout.LayoutParams(-2, dp(27)).apply {
                    marginStart = dp(5)
                })
                if (year.isNotBlank()) {
                    addView(TextView(this@MainActivity).apply {
                        text = year
                        setTextColor(Color.WHITE)
                        textSize = 10.2f
                        typeface = BankmovieFonts.medium(this@MainActivity)
                        gravity = Gravity.CENTER
                        background = rounded(Color.argb(170, 8, 11, 17), dp(12), Color.argb(85, 255, 255, 255))
                        setPadding(dp(8), 0, dp(8), 0)
                    }, LinearLayout.LayoutParams(-2, dp(27)))
                }
            }
            frame.addView(top, FrameLayout.LayoutParams(-1, dp(35), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
                topMargin = dp(7)
            })
        } else if (year.isNotBlank()) {
            frame.addView(TextView(this).apply {
                text = year
                setTextColor(Color.WHITE)
                textSize = 10.2f
                typeface = BankmovieFonts.medium(this@MainActivity)
                gravity = Gravity.CENTER
                background = rounded(Color.argb(170, 8, 11, 17), dp(12), Color.argb(85, 255, 255, 255))
                setPadding(dp(8), 0, dp(8), 0)
            }, FrameLayout.LayoutParams(-2, dp(27), Gravity.TOP or Gravity.RIGHT).apply {
                topMargin = dp(7); rightMargin = dp(7)
            })
        }

        if (bottomSpecs.isNotEmpty()) {
            val scroll = HorizontalBankmovieSmoothScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                clipToPadding = false
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(6), 0, dp(6), 0)
            }
            bottomSpecs.forEach { spec ->
                row.addView(movieSpecChip(spec, false), LinearLayout.LayoutParams(-2, -2).apply {
                    marginStart = dp(4); marginEnd = dp(4)
                })
            }
            scroll.addView(row)
            frame.addView(scroll, FrameLayout.LayoutParams(-1, dp(34), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(8)
            })
        }
        return frame
    }

    private fun appPrefs() = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)

    private fun isLightTheme(): Boolean = UiPreferences.palette(this).light

        private fun isFa(): Boolean = (appPrefs().getString("lang_code", "fa") ?: "fa") != "en"

    private fun t(fa: String, en: String): String {
        return if ((appPrefs().getString("lang_code", "fa") ?: "fa") == "en") en else fa
    }

    private fun applyThemeColors() {
        val p = UiPreferences.palette(this)
        bg = p.background
        bg2 = p.background2
        panel = p.panel
        panel2 = p.panel2
        card = p.card
        stroke = p.stroke
        blue = p.primary
        blue2 = p.primary2
        gold = p.primary
        white = p.text
        muted = p.muted
        faint = p.faint
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            var flags = window.decorView.systemUiVisibility
            flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
            window.decorView.systemUiVisibility = flags
        }
    }

    private fun setupChoice(label: String, active: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(if (active) Color.WHITE else white)
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) {
                GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(20, 22, 26), Color.rgb(80, 84, 92))).apply { cornerRadius = dp(16).toFloat() }
            } else rounded(panel2, dp(16), stroke)
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun showLanguageThemeDialog() {
        var lang = appPrefs().getString("lang_code", "fa") ?: "fa"
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(18))
            background = bankGlassDrawable(26, 242, 76, true)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply { text = t("زبان برنامه", "App language"); setTextColor(white); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply { text = "×"; setTextColor(white); textSize = 25f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD; background = rounded(Color.argb(58,255,255,255), dp(17), Color.argb(45,255,255,255)); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        box.addView(TextView(this).apply { text = t("فارسی به صورت پیش‌فرض فعال است. می‌توانی زبان انگلیسی را هم انتخاب کنی.", "Persian is enabled by default. You can switch to English."); setTextColor(muted); textSize = 12.8f; gravity = Gravity.RIGHT; setPadding(0, 0, 0, dp(14)) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        row.addView(setupChoice("فارسی", lang == "fa") { lang = "fa"; Toast.makeText(this, "فارسی", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        row.addView(setupChoice("English", lang == "en") { lang = "en"; Toast.makeText(this, "English", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        box.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        box.addView(TextView(this).apply {
            text = t("ذخیره", "Save")
            setTextColor(white); textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(UiPreferences.blend(blue, Color.WHITE, 0.10f), UiPreferences.blend(blue, Color.BLACK, 0.22f))).apply { cornerRadius = dp(20).toFloat() }
            setOnClickListener { appPrefs().edit().putString("lang_code", lang).putString("theme_mode", "black").apply(); dialog.dismiss(); buildShell(); showHome() }
        }, LinearLayout.LayoutParams(-1, dp(52)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box)
    }

    private fun stableHash(value: String): String {
        return try {
            MessageDigest.getInstance("SHA-256")
                .digest(value.toByteArray(Charsets.UTF_8))
                .take(16)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
        } catch (_: Throwable) {
            value.hashCode().toUInt().toString(16)
        }
    }

    private fun playbackProgressKey(item: JSONObject, link: JSONObject): String {
        val source = buildString {
            append(storageKey(item))
            append('|').append(link.optInt("season", 0))
            append('|').append(link.optInt("episode", 0))
            append('|').append(link.optString("quality"))
            append('|').append(link.optString("type"))
            append('|').append(link.optString("display_label"))
        }
        return "progress_v2_${stableHash(source)}"
    }

    private fun isWatched(item: JSONObject): Boolean {
        return appPrefs().getBoolean("watched_${stableHash(storageKey(item))}", false)
    }

    private fun markPlayed(item: JSONObject, link: JSONObject) {
        if (item.length() == 0) return
        appPrefs().edit()
            .putBoolean("watched_${stableHash(storageKey(item))}", true)
            .putLong("watched_at_${stableHash(storageKey(item))}", System.currentTimeMillis())
            .apply()
        recordContinue(item, link)
    }

    private fun savedProgressFor(item: JSONObject, link: JSONObject): Long {
        val prefs = appPrefs()
        val stable = prefs.getLong(playbackProgressKey(item, link), 0L)
        if (stable > 0L) return stable
        val url = link.optString("url")
        return if (url.isNotBlank()) prefs.getLong("progress_$url", 0L) else 0L
    }

    private fun formatResumeTime(ms: Long): String {
        if (ms <= 0L) return ""
        val total = ms / 1000L
        val h = total / 3600L
        val m = (total % 3600L) / 60L
        val s = total % 60L
        return if (h > 0L) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun storageKey(item: JSONObject): String {
        val id = item.optString("id").ifBlank { item.optString("movie_id") }.ifBlank { item.optString("slug") }
        val type = item.optString("type", "movie")
        val archive = item.optInt("archive", defaultArchive)
        return "$archive|$type|${id.ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }}"
    }

    private fun compactItem(item: JSONObject): JSONObject {
        val out = JSONObject()
        listOf(
            "id", "db_id", "imdb_code", "slug", "source_slug", "archive", "type",
            "title", "title_fa", "poster", "backdrop", "rating", "year", "runtime",
            "description", "long_description", "has_dubbed", "has_subtitle",
            "source_url", "web_url", "web_url_abs"
        ).forEach { key ->
            if (item.has(key)) out.put(key, item.opt(key))
        }
        out.put("_key", storageKey(item))
        out.put("_saved_at", System.currentTimeMillis())
        return out
    }

    private fun storeItems(key: String): MutableList<JSONObject> {
        val arr = JSONArray(appPrefs().getString(key, "[]") ?: "[]")
        val list = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { list.add(it) }
        return list
    }

    private fun saveStoreItems(key: String, list: List<JSONObject>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        appPrefs().edit().putString(key, arr.toString()).apply()
    }

    private fun upsertStoreItem(key: String, item: JSONObject, limit: Int = 30) {
        val c = compactItem(item)
        val id = c.optString("_key")
        val list = storeItems(key).filter { it.optString("_key") != id }.toMutableList()
        list.add(0, c)
        saveStoreItems(key, list.take(limit))
    }

    private fun isFavorite(item: JSONObject): Boolean {
        val id = storageKey(item)
        return storeItems("favorites").any { it.optString("_key") == id }
    }

    private fun toggleFavorite(item: JSONObject) {
        if (!AccountSession.isLoggedIn(this)) {
            BmNotice.show(this, "برای ذخیره دائمی واچ‌لیست، ابتدا وارد حساب بانک مووی شوید", BmNotice.Kind.WARNING, 3200L)
            startActivity(Intent(this, AuthActivity::class.java))
            return
        }

        val id = storageKey(item)
        val list = storeItems("favorites").toMutableList()
        val oldSize = list.size
        val filtered = list.filter { it.optString("_key") != id }.toMutableList()
        val added = filtered.size == oldSize
        if (added) {
            filtered.add(0, compactItem(item))
            AccountSession.markWatchlistAdded(this, id)
            BmNotice.show(this, "به واچ‌لیست اضافه شد", BmNotice.Kind.SUCCESS)
        } else {
            AccountSession.markWatchlistRemoved(this, id)
            BmNotice.show(this, "از واچ‌لیست حذف شد", BmNotice.Kind.INFO)
        }
        saveStoreItems("favorites", filtered.take(60))
        AccountApi.syncWatchlist(this, force = true) { result ->
            if (!result.success && result.statusCode != 401) {
                BmNotice.show(this, "تغییر روی گوشی ذخیره شد و بعداً با حساب همگام می‌شود", BmNotice.Kind.WARNING, 3000L)
            }
            if (currentScreen == "favorites") showFavorites()
        }
    }

    private fun recordHistory(item: JSONObject) {
        if (item.optString("id").isNotBlank() || item.optString("title_fa").isNotBlank() || item.optString("title").isNotBlank()) {
            // حداکثر ۱۰۰ بازدید: جدید می‌آید بالا، قدیمی‌ترین حذف می‌شود.
            upsertStoreItem("history", item, 100)
        }
    }

    private fun recordContinue(item: JSONObject, link: JSONObject) {
        if (item.length() == 0) return
        val c = compactItem(item)
        c.put("quality", link.optString("quality"))
        c.put("display_label", link.optString("display_label"))
        c.put("url", link.optString("url"))
        c.put("type_fa", linkTypeFa(link))
        c.put("season", link.optInt("season", 0))
        c.put("episode", link.optInt("episode", 0))
        c.put("progress_key", playbackProgressKey(item, link))
        val id = c.optString("_key")
        val list = storeItems("continue").filter { it.optString("_key") != id }.toMutableList()
        list.add(0, c)
        // حداکثر ۱۰۰ ادامه تماشا: نسخه جدید جایگزین نسخه قدیمی همان فیلم می‌شود.
        saveStoreItems("continue", list.take(100))
    }

    private fun clearWatchHistory() {
        if (storeItems("history").isEmpty()) {
            Toast.makeText(this, ui("تاریخچه‌ای برای پاک کردن نیست"), Toast.LENGTH_SHORT).show()
            return
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = rounded(Color.rgb(10, 14, 23), dp(24), Color.argb(100, 255, 255, 255))
        }
        box.addView(TextView(this).apply {
            text = ui("پاک کردن تاریخچه مشاهده")
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        box.addView(TextView(this).apply {
            text = ui("همه آخرین بازدیدها حذف می‌شوند. ادامه تماشا دست‌نخورده می‌ماند.")
            setTextColor(muted)
            textSize = 12.8f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        row.addView(modalButton(ui("پاک کن"), R.drawable.ic_close_clean, true) {
            saveStoreItems("history", emptyList())
            dialog.dismiss()
            Toast.makeText(this, ui("تاریخچه پاک شد"), Toast.LENGTH_SHORT).show()
            showProfile()
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(8) })
        row.addView(modalButton(ui("انصراف"), R.drawable.ic_more_lines, false) {
            dialog.dismiss()
        }, LinearLayout.LayoutParams(0, dp(46), 1f))
        box.addView(row)
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box)
    }

    private fun positionRailAtNewest(
        scroller: HorizontalScrollView,
        row: LinearLayout,
        focusFirstOnTv: Boolean = false
    ) {
        BankmovieFonts.applyToTree(this, row)
        val rtl = isFa()
        val direction = if (rtl) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        scroller.layoutDirection = direction
        row.layoutDirection = direction

        // On TV no rail is allowed to move or steal focus after asynchronous
        // loading. The user controls every horizontal/vertical movement.
        if (isTvLike()) return

        scroller.post {
            if (rtl) scroller.fullScroll(View.FOCUS_RIGHT) else scroller.fullScroll(View.FOCUS_LEFT)
        }
    }

    private fun addLocalRail(page: LinearLayout, title: String, storeKey: String, emptyText: String) {
        val items = storeItems(storeKey)
        if (items.isEmpty()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(22) }
        }
        val header = sectionHeader(title, more = { showLocalList(title, storeKey, emptyText) })
        box.addView(header)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        items.take(12).forEach { saved ->
            row.addView(
                if (storeKey == "continue") profileStoredCard(storeKey, saved)
                else posterCard(saved, dp(122), dp(223))
            )
        }
        positionRailAtNewest(scroller, row, focusFirstOnTv = storeKey == "continue")
        wireTvSectionDown(header, row.getChildAtOrNull(0))
        page.addView(box)
    }

    private fun profileCountPill(label: String, value: Int): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bankGlassDrawable(20, 224, 60, true)
            elevation = dp(2).toFloat()
            setPadding(dp(8), dp(9), dp(8), dp(9))
            addView(TextView(this@MainActivity).apply {
                text = value.toString()
                setTextColor(p.text)
                textSize = 20f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(p.muted)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(3), 0, 0)
            })
        }
    }

    private fun appVersionCode(): Int {
        return try {
            val p = packageManager.getPackageInfo(packageName, 0)
            if (android.os.Build.VERSION.SDK_INT >= 28) p.longVersionCode.toInt() else p.versionCode
        } catch (_: Throwable) { 1 }
    }

    private fun appVersionName(): String {
        return try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: "1.1"
        } catch (_: Throwable) { "1.1" }
    }

        private fun checkInternalUpdate(showToastIfLatest: Boolean = true) {
        if (showConfigUpdateIfNeeded(showToastIfLatest)) return
        if (showToastIfLatest) {
            val msg = if (!remoteUpdateEnabled) t("آپدیت از پنل غیرفعال است", "Update is disabled from the panel") else t("آپدیت جدیدی ثبت نشده است", "No update is registered")
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    private fun updatePill(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.rgb(255, 210, 120))
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(65, 255, 170, 20), dp(16), Color.argb(80, 255, 190, 80))
            setPadding(dp(12), 0, dp(12), 0)
        }
    }

    private fun showUpdateDialog(
        title: String,
        message: String,
        apkUrl: String,
        force: Boolean,
        latestVersion: String = "",
        installedVersion: String = appVersionName(),
        changes: List<String> = emptyList()
    ) {
        lateinit var dialog: AlertDialog
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(17, 18, 24), Color.rgb(8, 9, 14))).apply {
                cornerRadius = dp(34).toFloat()
                setStroke(dp(1), Color.argb(115, 155, 98, 255))
            }
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val icon = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(126, 70, 255), Color.rgb(88, 35, 210))).apply {
                cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(120, 255, 255, 255))
            }
            elevation = dp(10).toFloat()
        }
        icon.addView(TextView(this).apply { text = "✦"; setTextColor(white); textSize = 27f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER }, FrameLayout.LayoutParams(-1, -1))
        head.addView(icon, LinearLayout.LayoutParams(dp(60), dp(60)).apply { marginStart = dp(14) })
        val titleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titleBox.addView(TextView(this).apply { text = title.ifBlank { t("آپدیت جدید آماده است", "Update available") }; setTextColor(white); textSize = 21f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        titleBox.addView(TextView(this).apply { text = if (force) t("برای ادامه باید نسخه جدید نصب شود.", "Install the latest version to continue.") else t("می‌توانید الان آپدیت کنید یا بعداً نصب کنید.", "You can update now or later."); setTextColor(Color.rgb(172, 178, 194)); textSize = 12.7f; gravity = Gravity.RIGHT; setPadding(0, dp(5), 0, 0) })
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        if (!force) {
            head.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.rgb(220, 224, 238))
                textSize = 25f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.argb(58, 255, 255, 255), dp(17), Color.argb(45, 255, 255, 255))
                setOnClickListener { dialog.dismiss() }
            }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        }
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })

        box.addView(TextView(this).apply { text = message.ifBlank { t("نسخه جدید Bankmovie آماده دانلود است.", "A new Bankmovie version is ready to download.") }; setTextColor(Color.rgb(232, 234, 242)); textSize = 14.2f; gravity = Gravity.RIGHT; setLineSpacing(dp(3).toFloat(), 1.0f) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        val versions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.RIGHT }
        versions.addView(updatePill(t("آخرین نسخه  $latestVersion", "Latest  $latestVersion")), LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(8) })
        versions.addView(updatePill(t("نصب‌شده  $installedVersion", "Installed  $installedVersion")), LinearLayout.LayoutParams(-2, dp(38)))
        box.addView(versions, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(18) })
        box.addView(TextView(this).apply { text = t("تغییرات نسخه", "What is new"); setTextColor(white); textSize = 14.8f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        val finalChanges = if (changes.isNotEmpty()) changes else listOf(t("بهبود پایداری و رفع خطاها", "Stability improvements"), t("بهبود ظاهر اپ و پلیر", "Better app and player design"), t("بهبود اتصال به سرور و مدیریت دامنه", "Improved connection and domain management"))
        val changeBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = rounded(Color.argb(72, 255, 255, 255), dp(18), Color.argb(60, 255, 255, 255)); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        finalChanges.take(7).forEach { item -> changeBox.addView(TextView(this).apply { text = "●  $item"; setTextColor(Color.rgb(226, 229, 238)); textSize = 13.2f; gravity = Gravity.RIGHT; setPadding(0, dp(4), 0, dp(4)) }) }
        box.addView(changeBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })
        box.addView(TextView(this).apply { text = t("آپدیت الان", "Update now"); setTextColor(white); textSize = 15.2f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(UiPreferences.blend(blue, Color.WHITE, 0.10f), UiPreferences.blend(blue, Color.BLACK, 0.22f))).apply { cornerRadius = dp(24).toFloat() }; setOnClickListener { openExternal(apkUrl, null) } }, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(10) })
        if (!force) box.addView(TextView(this).apply { text = t("بعداً", "Later"); setTextColor(Color.rgb(185, 150, 255)); textSize = 14.4f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; setPadding(0, dp(5), 0, 0); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(-1, dp(44)))
        dialog = AlertDialog.Builder(this).setView(scroll).setCancelable(!force).create()
        dialog.show()
        styleShownDialog(dialog, box, maxWidthDp = 560)
    }

    private fun telegramProCard(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(9, 28, 48), Color.rgb(5, 14, 28))).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(150, 42, 171, 238))
            }
            setPadding(dp(16), dp(16), dp(16), dp(16))
            val head = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            head.addView(FrameLayout(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(42,171,238), Color.rgb(28,105,190))).apply { shape = GradientDrawable.OVAL }
                clipToOutline = true
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_telegram_plane)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(12) })
            val txt = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            txt.addView(TextView(this@MainActivity).apply {
                text = "کانال رسمی Bankmovie"
                setTextColor(white)
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            txt.addView(TextView(this@MainActivity).apply {
                text = "@" + AppConfig.TELEGRAM_HANDLE
                setTextColor(Color.rgb(150, 220, 255))
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(4), 0, 0)
            })
            head.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            addView(head)
            addView(TextView(this@MainActivity).apply {
                text = "اطلاعیه‌ها، لینک آپدیت و اخبار رفع مشکل اینترنت اینجا قرار می‌گیرد."
                setTextColor(muted)
                textSize = 12.6f
                gravity = Gravity.RIGHT
                setPadding(0, dp(12), 0, dp(12))
            })
            addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(50)))
        }
    }

    private fun showTelegramCardDialog() {
        val card = telegramProCard()
        val telegramDialog = AlertDialog.Builder(this).setView(card).create()
        telegramDialog.show()
        styleShownDialog(telegramDialog, card)
    }

    private fun premiumPageHeader(title: String, subtitle: String, iconRes: Int): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.blend(p.panel, p.primary, if (p.light) 0.05f else 0.14f),
                p.panel2
            )).apply {
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), Color.argb(150, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(p.primary)
                setPadding(dp(7), dp(7), dp(7), dp(7))
                background = rounded(Color.argb(30, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)), dp(18), Color.argb(110, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(16) })
            val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            texts.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            texts.addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun premiumSectionTitle(title: String): TextView {
        return TextView(this).apply {
            text = title
            setTextColor(blue)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(dp(5), dp(16), dp(5), dp(8))
        }
    }

    private fun premiumSettingsRow(
        title: String,
        subtitle: String,
        value: String,
        iconRes: Int,
        danger: Boolean = false,
        click: () -> Unit
    ): LinearLayout {
        val p = UiPreferences.palette(this)
        val accent = if (danger) Color.rgb(225, 55, 70) else p.primary
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = if (danger) {
                rounded(Color.argb(36, 225, 55, 70), dp(20), Color.argb(120, 225, 55, 70))
            } else {
                bankGlassDrawable(20, 228, 58, true)
            }
            applyTvFocusHalo(this, 22, 1.025f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                if (iconRes != R.drawable.ic_telegram) setColorFilter(accent)
                setPadding(dp(4), dp(4), dp(4), dp(4))
                background = rounded(Color.argb(28, Color.red(accent), Color.green(accent), Color.blue(accent)), dp(14), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(dp(42), dp(42)))
            addView(View(this@MainActivity), LinearLayout.LayoutParams(dp(14), 1))
            val textBox = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            textBox.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(if (danger) accent else white)
                textSize = 14.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            textBox.addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(muted)
                textSize = 11.5f
                gravity = Gravity.RIGHT
                maxLines = 2
                setPadding(0, dp(4), 0, 0)
            })
            addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
            if (value.isNotBlank()) {
                addView(TextView(this@MainActivity).apply {
                    text = value
                    setTextColor(if (danger) accent else blue)
                    textSize = 12f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    maxLines = 1
                    setPadding(dp(8), 0, dp(8), 0)
                }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
            }
        }
    }

    private fun premiumChoice(label: String, active: Boolean, click: () -> Unit): TextView {
        val p = UiPreferences.palette(this)
        return TextView(this).apply {
            text = if (active) "✓  $label" else label
            setTextColor(if (active) p.onPrimary else white)
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = if (active) blueGradient(dp(17)) else rounded(p.panel2, dp(17), p.stroke)
            applyTvFocusHalo(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun accentSwatch(name: String, selected: String, click: () -> Unit): TextView {
        val color = UiPreferences.accentColor(name)
        return TextView(this).apply {
            text = if (name == selected) "✓" else ""
            setTextColor(if (name == "gold") Color.BLACK else Color.WHITE)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(color, dp(999), if (name == selected) Color.WHITE else Color.argb(80, 255, 255, 255))
            applyTvFocusHalo(this, 999, 1.08f, dp(2).toFloat())
            setOnClickListener { click() }
        }
    }

    private fun enabledSwitchRow(title: String, subtitle: String, checked: Boolean, onChanged: (Boolean) -> Unit): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = bankGlassDrawable(19, 226, 62, false)
            addView(BmToggleView(this@MainActivity).apply {
                setChecked(checked, animate = false)
                setOnCheckedChangeListener(onChanged)
            }, LinearLayout.LayoutParams(dp(120), dp(38)).apply { marginEnd = dp(12) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@MainActivity).apply {
                    text = title
                    setTextColor(p.text)
                    textSize = 13.6f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                addView(TextView(this@MainActivity).apply {
                    text = subtitle
                    setTextColor(p.muted)
                    textSize = 10.6f
                    gravity = Gravity.RIGHT
                    setPadding(0, dp(3), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun showSettingsPage() {
        currentScreen = "profile"
        rememberCurrentScreen { showSettingsPage() }
        buildBottomNav()
        clear()
        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(105)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(30))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(premiumPageHeader("تنظیمات", "ظاهر، پخش و تجربه کاربری بانک مووی", R.drawable.ic_player_settings), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        page.addView(premiumSectionTitle("ظاهر برنامه"))
        val appearance = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = bankGlassDrawable(24, 236, 70, true)
        }
        appearance.addView(TextView(this).apply { text = "فونت برنامه"; setTextColor(white); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val appFontMode = UiPreferences.appFontMode(this)
        val appFontRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(2), 0, dp(2), 0) }
        BankmovieFonts.options.forEachIndexed { index, option ->
            appFontRow.addView(premiumChoice(option.faLabel, appFontMode == option.key) {
                appPrefs().edit().putString(UiPreferences.KEY_APP_FONT, option.key).apply()
                buildShell(); showSettingsPage()
            }.apply { typeface = BankmovieFonts.forMode(this@MainActivity, option.key, true) }, LinearLayout.LayoutParams(dp(116), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        appearance.addView(HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(appFontRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(16) })
        appearance.addView(TextView(this).apply { text = "رنگ اصلی"; setTextColor(white); textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val accentScroll = HorizontalBankmovieSmoothScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val accentRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(2), dp(9), dp(2), dp(8)) }
        val selectedAccent = UiPreferences.accentName(this)
        listOf("gold", "blue", "orange", "red", "purple", "teal", "green").forEach { name ->
            accentRow.addView(accentSwatch(name, selectedAccent) {
                appPrefs().edit().putString(UiPreferences.KEY_ACCENT, name).apply()
                applyThemeColors(); buildShell(); showSettingsPage()
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(7); marginEnd = dp(2) })
        }
        accentScroll.addView(accentRow)
        appearance.addView(accentScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        page.addView(appearance, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        page.addView(premiumSectionTitle("پخش"))
        val playback = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = bankGlassDrawable(24, 236, 70, true)
        }
        playback.addView(premiumSettingsRow("تنظیمات زیرنویس", "رنگ، پس‌زمینه و اندازه", "${UiPreferences.subtitleScale(this)}%", R.drawable.ic_player_cc) { showGlobalSubtitleSettings() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val seekValue = UiPreferences.seekSeconds(this)
        listOf(5, 10, 30, 60).forEachIndexed { index, seconds ->
            seekRow.addView(premiumChoice("${seconds} ثانیه", seekValue == seconds) {
                appPrefs().edit().putInt(UiPreferences.KEY_SEEK_SECONDS, seconds).apply(); showSettingsPage()
            }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        playback.addView(TextView(this).apply { text = "زمان پرش در پلیر"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT; setPadding(dp(4), dp(4), dp(4), dp(8)) })
        playback.addView(seekRow)
        playback.addView(enabledSwitchRow(
            "قسمت بعدی",
            "در ۹۵٪ پخش، قبل از رفتن به قسمت بعد از شما سؤال شود",
            UiPreferences.autoNext(this)
        ) { next ->
            appPrefs().edit().putBoolean(UiPreferences.KEY_AUTO_NEXT, next).apply()
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        page.addView(playback, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        page.addView(premiumSectionTitle("برنامه"))
        page.addView(premiumSettingsRow("راه‌اندازی سریع", "ظاهر، فونت، زیرنویس، زبان و دانلود", "", R.drawable.ic_player_settings) { launchQuickSetup(required = false) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("روش پیش‌فرض دانلود", "هر بار بپرس، دانلودر داخلی یا مرورگر", downloadBehaviorLabel(), R.drawable.ic_download) { showDownloadBehaviorDialog() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("زبان برنامه", "فارسی یا English", if (isFa()) "فارسی" else "English", R.drawable.ic_info_globe) { showLanguageThemeDialog() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("درباره بانک مووی", "توسعه‌دهنده و راه‌های ارتباطی", "", R.drawable.ic_info_badge) { showAboutPage() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("بازنشانی تنظیمات", "ظاهر و تنظیمات پخش به حالت پیش‌فرض برمی‌گردد", "", R.drawable.ic_close_clean, true) {
            UiPreferences.reset(this)
            applyThemeColors(); buildShell(); showSettingsPage()
            Toast.makeText(this, "تنظیمات بازنشانی شد", Toast.LENGTH_SHORT).show()
        })
    }

    private fun downloadBehaviorLabel(): String = when (UiPreferences.downloadBehavior(this)) {
        "internal" -> t("دانلودر داخلی", "Internal downloader")
        "browser" -> t("مرورگر / برنامه خارجی", "Browser / external app")
        else -> t("هر بار سؤال شود", "Ask every time")
    }

    private fun showDownloadBehaviorDialog() {
        val labels = arrayOf(
            t("هر بار سؤال شود", "Ask every time"),
            t("دانلودر داخلی بانک مووی", "Bankmovie internal downloader"),
            t("مرورگر یا برنامه خارجی", "Browser or external app")
        )
        val values = arrayOf("ask", "internal", "browser")
        val selected = values.indexOf(UiPreferences.downloadBehavior(this)).coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(t("روش پیش‌فرض دانلود", "Default download method"))
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                appPrefs().edit().putString(UiPreferences.KEY_DOWNLOAD_BEHAVIOR, values[which]).apply()
                dialog.dismiss()
                showSettingsPage()
            }
            .setNegativeButton(t("لغو", "Cancel"), null)
            .show()
    }

    private fun showGlobalSubtitleSettings() {
        var enabled = UiPreferences.subtitleEnabled(this)
        var textColor = UiPreferences.subtitleTextColor(this)
        var bgMode = UiPreferences.subtitleBackgroundMode(this)
        var fontMode = UiPreferences.subtitleFontMode(this)
        var bold = UiPreferences.subtitleBold(this)
        var scale = UiPreferences.subtitleScale(this)
        lateinit var dialog: AlertDialog
        val p = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(17), dp(18), dp(18))
            background = rounded(p.panel, dp(28), Color.argb(155, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply { text = "تنظیمات زیرنویس"; setTextColor(white); textSize = 21f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply { text = "×"; setTextColor(white); textSize = 23f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; background = bankGlassDrawable(16, 226, 62, false); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(dp(38), dp(38)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        box.addView(TextView(this).apply { text = "نمایش زیرنویس"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        box.addView(BmToggleView(this).apply {
            setChecked(enabled, animate = false)
            setOnCheckedChangeListener { value -> enabled = value }
        }, LinearLayout.LayoutParams(dp(120), dp(38)).apply {
            gravity = Gravity.RIGHT
            bottomMargin = dp(16)
        })

        box.addView(TextView(this).apply { text = "رنگ متن"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val textColors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = HorizontalBankmovieSmoothScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val colorInner = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(8), 0, dp(8)) }
        fun refreshColors() {
            colorViews.forEachIndexed { index, v -> v.background = rounded(textColors[index], dp(999), if (textColors[index] == textColor) blue else Color.argb(95, 255, 255, 255)) }
        }
        textColors.forEachIndexed { index, color ->
            val v = TextView(this).apply { text = if (color == textColor) "✓" else ""; setTextColor(if (color == Color.BLACK) Color.WHITE else Color.BLACK); textSize = 15f; gravity = Gravity.CENTER; setOnClickListener { textColor = color; colorViews.forEach { it.text = "" }; text = "✓"; refreshColors() }; applyTvFocusHalo(this, 999, 1.08f, 0f) }
            colorViews.add(v); colorInner.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColors(); colorRow.addView(colorInner); box.addView(colorRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(TextView(this).apply { text = "پس‌زمینه زیرنویس"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        fun refreshBg() { bgButtons.forEach { (key, view) -> view.background = if (key == bgMode) blueGradient(dp(15)) else rounded(p.panel2, dp(15), p.stroke); view.setTextColor(if (key == bgMode) p.onPrimary else white) } }
        listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی").forEachIndexed { index, pair ->
            val v = premiumChoice(pair.second, bgMode == pair.first) { bgMode = pair.first; refreshBg() }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBg()
        box.addView(HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(14) })

        box.addView(TextView(this).apply { text = "فونت زیرنویس"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val subtitleFontButtons = mutableListOf<Pair<String, TextView>>()
        val subtitleFontRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        fun refreshSubtitleFonts() {
            subtitleFontButtons.forEach { (key, view) ->
                view.background = if (key == fontMode) blueGradient(dp(16)) else rounded(p.panel2, dp(16), p.stroke)
                view.setTextColor(if (key == fontMode) p.onPrimary else white)
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val view = premiumChoice(option.faLabel, fontMode == option.key) {
                fontMode = option.key
                refreshSubtitleFonts()
            }.apply { typeface = BankmovieFonts.forMode(this@MainActivity, option.key, true) }
            subtitleFontButtons += option.key to view
            subtitleFontRow.addView(view, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshSubtitleFonts()
        box.addView(HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(subtitleFontRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(14) })

        box.addView(TextView(this).apply { text = "ضخامت زیرنویس"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
        val boldRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        lateinit var boldOn: TextView
        lateinit var boldOff: TextView
        fun refreshBold() {
            boldOn.background = if (bold) blueGradient(dp(16)) else rounded(p.panel2, dp(16), p.stroke)
            boldOff.background = if (!bold) blueGradient(dp(16)) else rounded(p.panel2, dp(16), p.stroke)
            boldOn.setTextColor(if (bold) p.onPrimary else white)
            boldOff.setTextColor(if (!bold) p.onPrimary else white)
        }
        boldOn = premiumChoice("پررنگ", bold) { bold = true; refreshBold() }
        boldOff = premiumChoice("معمولی", !bold) { bold = false; refreshBold() }
        boldRow.addView(boldOn, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(7) })
        boldRow.addView(boldOff, LinearLayout.LayoutParams(0, dp(46), 1f))
        refreshBold()
        box.addView(boldRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(14) })

        val sizeLabel = TextView(this).apply { text = "اندازه متن: $scale%"; setTextColor(white); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeLabel)
        val sizeSeek = SeekBar(this).apply {
            max = 90; progress = (scale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) { scale = 80 + progress; sizeLabel.text = "اندازه متن: $scale%" } }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(10) })

        box.addView(TextView(this).apply {
            text = "ذخیره تنظیمات"
            setTextColor(p.onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = blueGradient(dp(21))
            setOnClickListener {
                appPrefs().edit()
                    .putBoolean(UiPreferences.KEY_SUB_ENABLED, enabled)
                    .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, textColor)
                    .putString(UiPreferences.KEY_SUB_BG_MODE, bgMode)
                    .putString(UiPreferences.KEY_SUB_FONT, fontMode)
                    .putBoolean(UiPreferences.KEY_SUB_BOLD, bold)
                    .putInt(UiPreferences.KEY_SUB_SCALE, scale)
                    .apply()
                dialog.dismiss()
                BmNotice.show(this@MainActivity, "تنظیمات زیرنویس ذخیره شد", BmNotice.Kind.SUCCESS)
                showSettingsPage()
            }
        }, LinearLayout.LayoutParams(-1, dp(52)))
        val settingsScroll = BankmovieSmoothScrollView(this).apply { addView(box) }
        dialog = AlertDialog.Builder(this).setView(settingsScroll).create()
        dialog.show()
        styleShownDialog(dialog, box, maxWidthDp = 540)
    }

    private fun openTelegramHandle(handle: String) {
        val clean = handle.trim().trimStart('@')
        val appUri = Uri.parse("tg://resolve?domain=$clean")
        val webUri = Uri.parse(AppConfig.TELEGRAM_URL.substringBeforeLast("/") + "/" + clean)
        try { startActivity(Intent(Intent.ACTION_VIEW, appUri)) } catch (_: Throwable) { startActivity(Intent(Intent.ACTION_VIEW, webUri)) }
    }

    private fun showAboutPage() {
        currentScreen = "profile"
        rememberCurrentScreen { showAboutPage() }
        buildBottomNav(); clear()
        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(105)) }
        val page = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(30)) }
        scroll.addView(page); content.addView(scroll); attachSmartHeader(scroll)

        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(22), dp(18), dp(22))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(UiPreferences.blend(p.panel, p.primary, 0.10f), p.panel)).apply {
                cornerRadius = dp(28).toFloat(); setStroke(dp(1), Color.argb(170, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
            }
        }
        val halo = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
        val ring = ProgressBar(this, null, android.R.attr.progressBarStyleLarge).apply {
            isIndeterminate = true
            indeterminateTintList = android.content.res.ColorStateList.valueOf(p.primary)
            alpha = 0.95f
        }
        halo.addView(ring, FrameLayout.LayoutParams(dp(150), dp(150), Gravity.CENTER))
        halo.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }, FrameLayout.LayoutParams(dp(138), dp(138), Gravity.CENTER))
        hero.addView(halo, LinearLayout.LayoutParams(dp(170), dp(170)).apply { bottomMargin = dp(4) })
        hero.addView(TextView(this).apply { text = "Bankmovie"; setTextColor(white); textSize = 26f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        hero.addView(TextView(this).apply { text = "نسخه ${appVersionName()}  •  Android"; setTextColor(muted); textSize = 12.5f; gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        page.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        page.addView(premiumSectionTitle("اطلاعات برنامه"))
        page.addView(premiumSettingsRow("برنامه‌نویس", "توسعه و نگهداری برنامه", "Manuel", R.drawable.ic_nav_profile) {}, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("کانال تلگرام", "خبرها و اطلاعیه‌ها", "@bankmovie_org", R.drawable.ic_telegram) { openTelegramHandle("bankmovie_org") }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("ربات بانک مووی", "جستجو و دسترسی سریع", "@bankmovieROBOT", R.drawable.ic_telegram) { openTelegramHandle("bankmovieROBOT") }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("بررسی به‌روزرسانی", "دریافت آخرین نسخه بانک مووی", appVersionName(), R.drawable.ic_download) { checkInternalUpdate(true) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("نسخه برنامه", "Bankmovie Android", appVersionName(), R.drawable.ic_info_badge) {})
    }

    private fun addProfileContinueSection(page: LinearLayout) {
        if (!AccountSession.continueWatchingEnabled(this)) return
        val items = storeItems("continue")
        val title = ui("ادامه تماشا")
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(sectionHeader(title, more = { showLocalList(title, "continue", ui("هنوز چیزی برای ادامه تماشا نداری")) }))
        if (items.isEmpty()) {
            box.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(20), dp(16), dp(20))
                background = bankGlassDrawable(22, 236, 70, true)
                addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_play_fill); setColorFilter(blue) }, LinearLayout.LayoutParams(dp(34), dp(34)).apply { bottomMargin = dp(8) })
                addView(TextView(this@MainActivity).apply { text = "هنوز پخشی برای ادامه ذخیره نشده"; setTextColor(white); textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
                addView(TextView(this@MainActivity).apply { text = "بعد از شروع یک فیلم یا قسمت، زمان و کیفیت آن اینجا نمایش داده می‌شود"; setTextColor(muted); textSize = 11.5f; gravity = Gravity.CENTER; setPadding(dp(6), dp(5), dp(6), 0) })
            }, LinearLayout.LayoutParams(-1, -2))
        } else if (isTvLike()) {
            val scroll = HorizontalBankmovieSmoothScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
            items.take(8).forEach { item -> row.addView(profileStoredCard("continue", item), LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8); marginEnd = dp(8) }) }
            scroll.addView(row)
            positionRailAtNewest(scroll, row, focusFirstOnTv = true)
            box.addView(scroll)
        } else {
            val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
            items.take(3).forEach { item -> list.addView(profileStoredCard("continue", item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }) }
            box.addView(list)
        }
        page.addView(box, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
    }

    private fun syncAccountWatchlistAndRefresh(force: Boolean = false) {
        if (!AccountSession.watchlistEnabled(this) || !AccountSession.isLoggedIn(this)) return
        val before = appPrefs().getString("favorites", "[]") ?: "[]"
        AccountApi.syncWatchlist(this, force = force) { result ->
            if (!result.success) return@syncWatchlist
            val after = appPrefs().getString("favorites", "[]") ?: "[]"
            if (before != after && (currentScreen == "profile" || currentScreen == "favorites")) {
                val restore = currentScreenRestorer
                if (restore != null) {
                    restoringNavigation = true
                    try { restore() } finally { restoringNavigation = false }
                }
            }
        }
    }

    private fun avatarDrawableForKey(key: String): Int = when (key) {
        "male_01" -> R.drawable.avatar_male_01
        "male_02" -> R.drawable.avatar_male_02
        "male_03" -> R.drawable.avatar_male_03
        "male_04" -> R.drawable.avatar_male_04
        "male_05" -> R.drawable.avatar_male_05
        "male_06" -> R.drawable.avatar_male_06
        "female_01" -> R.drawable.avatar_female_01
        "female_02" -> R.drawable.avatar_female_02
        "female_03" -> R.drawable.avatar_female_03
        "female_04" -> R.drawable.avatar_female_04
        "female_05" -> R.drawable.avatar_female_05
        "female_06" -> R.drawable.avatar_female_06
        "neon_01" -> R.drawable.avatar_neon_01
        "neon_02" -> R.drawable.avatar_neon_02
        "neon_03" -> R.drawable.avatar_neon_03
        "neon_04" -> R.drawable.avatar_neon_04
        else -> 0
    }

    private fun accountUserIsVip(user: JSONObject = AccountSession.user(this)): Boolean {
        if (user.has("is_vip")) return user.optBoolean("is_vip", false)
        if (user.has("can_upload_avatar")) return user.optBoolean("can_upload_avatar", false)
        // Compatibility fallback for older account APIs that did not expose
        // explicit VIP state. New servers are authoritative via is_vip.
        val role = user.optString("role").trim().lowercase(Locale.US)
        return role in setOf("admin", "administrator", "vip", "premium", "special")
    }

    private fun bindAccountAvatar(target: ImageView, user: JSONObject) {
        val remote = user.optString("avatar").trim()
        val customRemote = remote.contains("/uploads/avatars/", true) ||
            remote.startsWith("uploads/avatars/", true)
        if (customRemote) {
            loadImage(remote, target)
            return
        }
        val key = user.optString("avatar_key")
        val local = avatarDrawableForKey(key)
        if (local != 0) {
            target.setImageResource(local)
        } else if (remote.isNotBlank()) {
            loadImage(remote, target)
        } else {
            target.setImageResource(R.drawable.avatar_default)
        }
    }

    private fun launchVipAvatarPicker() {
        startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, avatarImageRequestCode)
    }

    private fun showAvatarPicker() {
        val user = AccountSession.user(this)
        val current = user.optString("avatar_key")
        val vip = accountUserIsVip(user)
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(18))
            background = rounded(panel, dp(26), Color.argb(115, Color.red(blue), Color.green(blue), Color.blue(blue)))
            clipChildren = false
            clipToPadding = false
        }
        box.addView(TextView(this).apply {
            text = "انتخاب آواتار"
            setTextColor(white)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(5) })
        box.addView(TextView(this).apply {
            text = if (vip)
                t("عضو VIP هستید؛ می‌توانید عکس اختصاصی خودتان را آپلود کنید یا یکی از آواتارهای بانک مووی را انتخاب کنید.", "VIP members can upload a custom image or choose a Bankmovie avatar.")
            else
                t("یکی از آواتارهای بانک مووی را انتخاب کنید. آپلود عکس اختصاصی برای اعضای VIP فعال است.", "Choose a Bankmovie avatar. Custom uploads are available to VIP members.")
            setTextColor(muted)
            textSize = 11.8f
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(12))
        })
        if (vip) {
            box.addView(TextView(this).apply {
                text = t("＋  آپلود عکس اختصاصی", "＋  Upload custom avatar")
                setTextColor(white)
                textSize = 13.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(blue, Color.rgb(153, 92, 246))).apply {
                    cornerRadius = dp(16).toFloat()
                }
                isClickable = true
                isFocusable = true
                applyMobileTouchHalo(this, 16)
                applyTvFocusHalo(this, 16, 1.035f, 0f)
                setOnClickListener { dialog.dismiss(); launchVipAvatarPicker() }
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })
        }
        val grid = GridLayout(this).apply {
            columnCount = if (isTvLike()) 4 else 4
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            alignmentMode = GridLayout.ALIGN_BOUNDS
            clipChildren = false
        }
        val avatars = listOf(
            "male_01","male_02","male_03","male_04","male_05","male_06",
            "female_01","female_02","female_03","female_04","female_05","female_06",
            "neon_01","neon_02","neon_03","neon_04"
        )
        avatars.forEach { key ->
            val wrap = FrameLayout(this).apply {
                background = rounded(
                    if (key == current) Color.argb(70, Color.red(blue), Color.green(blue), Color.blue(blue)) else panel2,
                    dp(22),
                    if (key == current) blue else stroke
                )
                setPadding(dp(7), dp(7), dp(7), dp(7))
                applyTvFocusHalo(this, 23, 1.06f, 0f)
                setOnClickListener {
                    isEnabled = false
                    AccountApi.updateAvatar(this@MainActivity, key) { result ->
                        if (result.success) {
                            dialog.dismiss()
                            Toast.makeText(this@MainActivity, "آواتار ذخیره شد", Toast.LENGTH_SHORT).show()
                            showProfile()
                        } else {
                            isEnabled = true
                            Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                }
            }
            wrap.addView(ImageView(this).apply {
                setImageResource(avatarDrawableForKey(key))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(-1, -1))
            grid.addView(wrap, GridLayout.LayoutParams().apply {
                width = dp(if (isTvLike()) 112 else 76)
                height = dp(if (isTvLike()) 112 else 76)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            })
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box, maxWidthDp = 520)
    }

    private fun accountProfileCard(): LinearLayout {
        val loggedIn = AccountSession.isLoggedIn(this)
        val user = AccountSession.user(this)
        val username = user.optString("username").ifBlank { t("کاربر بانک مووی", "Bankmovie user") }
        val email = user.optString("email")
        val p = UiPreferences.palette(this)
        val tv = isTvLike()
        val isVip = loggedIn && accountUserIsVip(user)

        fun actionPill(label: String, iconRes: Int, accent: Int, filled: Boolean, action: () -> Unit): View {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                setPadding(dp(14), 0, dp(14), 0)
                background = if (filled) {
                    bankTintGlassDrawable(accent, 16, 232, 0.26f)
                } else {
                    bankGlassDrawable(16, 214, 54, true)
                }
                isClickable = true
                isFocusable = true
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(iconRes)
                    setColorFilter(if (filled) Color.WHITE else accent)
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(8) })
                addView(TextView(this@MainActivity).apply {
                    text = label
                    setTextColor(if (filled) Color.WHITE else accent)
                    textSize = 12.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                })
                applyMobileTouchHalo(this, 16)
                setOnClickListener {
                    animate().cancel()
                    animate().scaleX(0.95f).scaleY(0.95f).setDuration(55L).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                        action()
                    }.start()
                }
            }
        }


        fun logoutButton(action: () -> Unit): View {
            val red = Color.rgb(238, 67, 81)
            val outer = FrameLayout(this).apply {
                isClickable = true
                isFocusable = true
                contentDescription = t("خروج از حساب", "Sign out")
            }
            val label = TextView(this).apply {
                text = t("خروج", "Sign out")
                setTextColor(Color.WHITE)
                textSize = 12.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                alpha = 0f
            }
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_close_clean)
                setColorFilter(Color.WHITE)
                setPadding(dp(13), dp(13), dp(13), dp(13))
            }
            val capsule = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                background = GradientDrawable().apply {
                    cornerRadius = dp(999).toFloat()
                    setColor(red)
                    setStroke(dp(1), Color.argb(145, 255, 135, 145))
                }
                elevation = dp(4).toFloat()
                addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
                addView(label, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(2) })
            }
            outer.addView(capsule, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.END or Gravity.CENTER_VERTICAL))

            fun expand(open: Boolean) {
                val params = capsule.layoutParams as FrameLayout.LayoutParams
                val from = params.width.coerceAtLeast(dp(46))
                val to = if (open) dp(132) else dp(46)
                ValueAnimator.ofInt(from, to).apply {
                    duration = if (open) 105L else 90L
                    interpolator = android.view.animation.DecelerateInterpolator()
                    addUpdateListener {
                        params.width = it.animatedValue as Int
                        capsule.layoutParams = params
                    }
                    start()
                }
                label.animate().cancel()
                label.animate().alpha(if (open) 1f else 0f).setDuration(if (open) 90L else 55L).start()
                capsule.animate().cancel()
                capsule.animate().scaleX(if (open) 1.02f else 1f).scaleY(if (open) 1.02f else 1f)
                    .setDuration(if (open) 90L else 70L).start()
            }
            outer.setOnClickListener { action() }
            outer.setOnTouchListener { view, event ->
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { expand(true); true }
                    MotionEvent.ACTION_UP -> { expand(false); view.performClick(); true }
                    MotionEvent.ACTION_CANCEL -> { expand(false); true }
                    else -> true
                }
            }
            return outer
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(if (tv) 26 else 16), dp(if (tv) 22 else 17), dp(if (tv) 26 else 16), dp(if (tv) 22 else 17))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                if (p.light) Color.argb(246, 250, 251, 254) else Color.rgb(20, 23, 31),
                if (p.light) UiPreferences.blend(Color.WHITE, p.primary, 0.055f) else UiPreferences.blend(Color.rgb(12, 15, 22), p.primary, 0.13f),
                if (p.light) Color.argb(242, 244, 247, 252) else Color.rgb(7, 9, 14)
            )).apply {
                cornerRadius = dp(if (tv) 31 else 27).toFloat()
                val edge = if (isVip) Color.rgb(245, 188, 67) else p.primary
                setStroke(dp(1), Color.argb(if (p.light) 115 else 145, Color.red(edge), Color.green(edge), Color.blue(edge)))
            }
            elevation = dp(4).toFloat()

            val header = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            val avatarWrap = FrameLayout(this@MainActivity).apply {
                clipChildren = false
                clipToPadding = false
            }
            val avatarSize = dp(if (tv) 112 else 82)
            val avatarFrame = FrameLayout(this@MainActivity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(p.panel2)
                    setStroke(dp(2), Color.argb(165, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
                }
                clipToOutline = true
                elevation = dp(6).toFloat()
                addView(ImageView(this@MainActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    if (loggedIn) bindAccountAvatar(this, user) else setImageResource(R.drawable.avatar_default)
                }, FrameLayout.LayoutParams(-1, -1))
            }
            avatarWrap.addView(avatarFrame, FrameLayout.LayoutParams(avatarSize, avatarSize, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            if (loggedIn) avatarWrap.addView(FrameLayout(this@MainActivity).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.primary); setStroke(dp(2), p.panel) }
                isClickable = true
                isFocusable = true
                contentDescription = t("ویرایش آواتار", "Edit avatar")
                setOnClickListener { showAvatarPicker() }
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_edit_avatar)
                    setPadding(dp(if (tv) 8 else 7), dp(if (tv) 8 else 7), dp(if (tv) 8 else 7), dp(if (tv) 8 else 7))
                }, FrameLayout.LayoutParams(-1, -1))
            }, FrameLayout.LayoutParams(dp(if (tv) 36 else 32), dp(if (tv) 36 else 32), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            header.addView(
                avatarWrap,
                LinearLayout.LayoutParams(dp(if (tv) 128 else 98), dp(if (tv) 154 else 118)).apply {
                    marginEnd = dp(if (tv) 24 else 15)
                }
            )

            val info = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                    addView(TextView(this@MainActivity).apply {
                        text = if (loggedIn) username else t("ورود یا ساخت حساب", "Sign in or create account")
                        setTextColor(p.text)
                        textSize = if (tv) 26f else 20f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    if (loggedIn && listOf("admin", "administrator").contains(user.optString("role").lowercase())) addView(TextView(this@MainActivity).apply {
                        text = "✓"
                        setTextColor(Color.WHITE)
                        textSize = 10.5f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.CENTER
                        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(29, 120, 255)) }
                    }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(7) })
                }, LinearLayout.LayoutParams(-1, -2))
                addView(TextView(this@MainActivity).apply {
                    text = if (loggedIn) email.ifBlank { t("حساب متصل به بانک مووی", "Connected Bankmovie account") } else t("واچ‌لیست و دیدگاه‌ها را روی حساب ذخیره کنید", "Save watchlist and comments to your account")
                    setTextColor(p.muted)
                    textSize = if (tv) 14f else 12.3f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(7), 0, 0)
                })
                if (isVip) {
                    addView(TextView(this@MainActivity).apply {
                        text = t("♛  BANKMOVIE VIP", "♛  BANKMOVIE VIP")
                        setTextColor(Color.rgb(255, 211, 112))
                        textSize = if (tv) 12.5f else 10.8f
                        typeface = BankmovieFonts.bold(this@MainActivity)
                        gravity = Gravity.CENTER
                        background = rounded(Color.argb(38, 255, 184, 45), dp(999), Color.argb(120, 255, 196, 72))
                        setPadding(dp(10), dp(4), dp(10), dp(4))
                    }, LinearLayout.LayoutParams(-2, -2).apply {
                        gravity = Gravity.RIGHT
                        topMargin = dp(8)
                    })
                }
            }
            header.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            addView(header, LinearLayout.LayoutParams(-1, -2))

            val divider = View(this@MainActivity).apply { setBackgroundColor(Color.argb(48, Color.red(p.stroke), Color.green(p.stroke), Color.blue(p.stroke))) }
            addView(divider, LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(15); bottomMargin = dp(13) })

            val actions = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            if (loggedIn) {
                actions.addView(actionPill(t("ویرایش آواتار", "Edit avatar"), R.drawable.ic_edit_avatar, p.primary, false) { showAvatarPicker() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(6) })
                actions.addView(logoutButton {
                    AccountApi.logout(this@MainActivity) {
                        appPrefs().edit().putString("favorites", "[]").apply()
                        BmNotice.show(this@MainActivity, t("از حساب خارج شدید", "Signed out"), BmNotice.Kind.INFO)
                        showProfile()
                    }
                }, LinearLayout.LayoutParams(dp(132), dp(46)).apply { marginEnd = dp(6) })
            } else {
                actions.addView(actionPill(t("ورود / ثبت‌نام", "Sign in / Register"), R.drawable.ic_nav_profile, p.primary, true) {
                    startActivity(Intent(this@MainActivity, AuthActivity::class.java))
                }, LinearLayout.LayoutParams(-1, dp(48)))
            }
            addView(actions, LinearLayout.LayoutParams(-1, dp(48)))
            BankmovieFonts.applyToTree(this@MainActivity, this)
        }
    }


    private fun notificationIconForType(type: String): Int = when (type.lowercase()) {
        "comment_reply", "comment_status" -> R.drawable.ic_nav_profile
        "update", "download_completed", "download_failed" -> R.drawable.ic_download
        "admin", "maintenance" -> R.drawable.ic_info_badge
        else -> R.drawable.ic_notifications
    }

    private fun showNotificationCenter() {
        if (!AccountSession.notificationCenterEnabled(this)) {
            Toast.makeText(this, "مرکز اعلان‌ها از پنل مدیریت غیرفعال شده است", Toast.LENGTH_SHORT).show()
            showProfile()
            return
        }
        currentScreen = "notifications"
        rememberCurrentScreen { showNotificationCenter() }
        buildBottomNav()
        clear()
        val notificationPalette = UiPreferences.palette(this)
        if (::bottomNav.isInitialized) bottomNav.visibility = View.VISIBLE

        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(104)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(18), dp(14), dp(30))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "مرکز اعلان‌ها"
            setTextColor(white)
            textSize = if (isTvLike()) 26f else 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        val notificationActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        notificationActions.addView(TextView(this).apply {
            text = "خواندن همه"
            setTextColor(notificationPalette.text)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bankTintGlassDrawable(notificationPalette.primary, 15, 220, 0.15f)
            applyTvFocusHalo(this, 16, 1.04f, 0f)
            setOnClickListener {
                LocalNotificationStore.markAllRead(this@MainActivity)
                if (AccountSession.isLoggedIn(this@MainActivity)) {
                    AccountApi.markAllNotificationsRead(this@MainActivity) { result ->
                        if (result.success) showNotificationCenter() else Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                    }
                } else showNotificationCenter()
            }
        }, LinearLayout.LayoutParams(dp(100), dp(42)).apply { marginStart = dp(7) })
        notificationActions.addView(TextView(this).apply {
            text = "پاک‌کردن همه"
            setTextColor(Color.rgb(255, 130, 140))
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bankTintGlassDrawable(Color.rgb(235, 35, 55), 15, 215, 0.13f)
            applyTvFocusHalo(this, 16, 1.04f, 0f)
            setOnClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle("پاک‌کردن اعلان‌ها")
                    .setMessage("همه اعلان‌ها حذف شوند؟")
                    .setNegativeButton("انصراف", null)
                    .setPositiveButton("حذف") { _, _ ->
                        LocalNotificationStore.clear(this@MainActivity)
                        NotificationDismissStore.clearRemoteThrough(this@MainActivity, notificationRemoteMaxSeen)
                        if (AccountSession.isLoggedIn(this@MainActivity)) {
                            AccountApi.clearNotifications(this@MainActivity) { result ->
                                if (result.success) showNotificationCenter() else Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                            }
                        } else showNotificationCenter()
                    }.show()
            }
        }, LinearLayout.LayoutParams(dp(104), dp(42)))
        header.addView(notificationActions, LinearLayout.LayoutParams(-2, dp(42)))
        page.addView(header, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(10) })

        val loading = contentSkeletonRows(4)
        page.addView(loading, LinearLayout.LayoutParams(-1, -2))

        fun renderNotificationItems(remoteItems: JSONArray?, remoteError: String = "") {
            if (loading.parent === page) page.removeView(loading)
            buildBottomNav()
            val merged = mutableListOf<JSONObject>()
            merged.addAll(LocalNotificationStore.all(this@MainActivity))
            if (remoteItems != null) {
                for (i in 0 until remoteItems.length()) remoteItems.optJSONObject(i)?.let { raw ->
                    val id = raw.optLong("id", 0L)
                    if (id > notificationRemoteMaxSeen) notificationRemoteMaxSeen = id
                    if (!NotificationDismissStore.isRemoteDismissed(this@MainActivity, id)) merged.add(JSONObject(raw.toString()))
                }
            }
            merged.sortBy { it.optLong("age_seconds", Long.MAX_VALUE) }
            if (merged.isEmpty()) {
                val title = if (remoteError.isNotBlank()) "اعلان‌ها دریافت نشد" else "اعلان جدیدی نداری"
                val message = remoteError.ifBlank { "پاسخ دیدگاه‌ها، وضعیت دانلود، آپدیت و پیام مدیریت اینجا نمایش داده می‌شود" }
                page.addView(emptyStateBox(title, message), LinearLayout.LayoutParams(-1, -2))
                return
            }
            merged.forEach { n ->
                val unread = !n.optBoolean("is_read")
                val local = n.optBoolean("local", false)
                val target = n.optJSONObject("target") ?: JSONObject()
                val cardView = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(14), dp(14), dp(14), dp(14))
                    background = if (unread) bankTintGlassDrawable(notificationPalette.primary, 22, 226, 0.12f)
                    else bankGlassDrawable(22, 220, 58, true)
                    elevation = if (unread) dp(4).toFloat() else 0f
                    applyTvFocusHalo(this, 23, 1.035f, elevation)
                }
                cardView.addView(FrameLayout(this).apply {
                    background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(UiPreferences.blend(blue, Color.BLACK, 0.14f), UiPreferences.blend(blue, Color.WHITE, 0.14f))).apply { cornerRadius = dp(18).toFloat() }
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(notificationIconForType(n.optString("type")))
                        setColorFilter(Color.WHITE)
                        setPadding(dp(12), dp(12), dp(12), dp(12))
                    }, FrameLayout.LayoutParams(-1, -1))
                }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(16) })
                val textBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
                val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL }
                titleRow.addView(TextView(this).apply {
                    text = n.optString("title").ifBlank { "اعلان بانک مووی" }
                    setTextColor(white)
                    textSize = 14.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, -2, 1f))
                if (unread) titleRow.addView(View(this).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.rgb(239, 52, 82)) } }, LinearLayout.LayoutParams(dp(9), dp(9)).apply { marginEnd = dp(8) })
                textBox.addView(titleRow)
                textBox.addView(TextView(this).apply {
                    text = n.optString("message")
                    setTextColor(Color.rgb(204, 207, 218))
                    textSize = 12.5f
                    gravity = Gravity.RIGHT
                    maxLines = 3
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(5), 0, dp(5))
                })
                val footerRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                }
                footerRow.addView(TextView(this).apply {
                    text = n.optString("date_text")
                    setTextColor(faint)
                    textSize = 10.8f
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(0, -2, 1f))
                footerRow.addView(TextView(this).apply {
                    text = "حذف"
                    setTextColor(Color.rgb(255, 130, 140))
                    textSize = 10.8f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    isFocusable = true
                    isClickable = true
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                    background = rounded(Color.argb(35, 235, 35, 55), dp(10), Color.argb(95, 235, 35, 55))
                    applyTvFocusHalo(this, 11, 1.05f, 0f)
                    setOnClickListener { v ->
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        val id = n.optLong("id")
                        if (local) {
                            LocalNotificationStore.delete(this@MainActivity, id)
                            showNotificationCenter()
                        } else if (id > 0L) {
                            NotificationDismissStore.dismissRemote(this@MainActivity, id)
                            LocalNotificationStore.deleteByDedupeKey(this@MainActivity, "admin-push:$id")
                            showNotificationCenter()
                            AccountApi.deleteNotification(this@MainActivity, id) { result ->
                                if (!result.success && result.message.isNotBlank()) {
                                    Toast.makeText(this@MainActivity, "اعلان از این دستگاه حذف شد", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }, LinearLayout.LayoutParams(-2, dp(28)))
                textBox.addView(footerRow)
                cardView.addView(textBox, LinearLayout.LayoutParams(0, -2, 1f))
                cardView.setOnClickListener {
                    val id = n.optLong("id")
                    if (unread) {
                        if (local) LocalNotificationStore.markRead(this@MainActivity, id)
                        else if (id > 0L) AccountApi.markNotificationRead(this@MainActivity, id) {}
                    }
                    val item = target.optJSONObject("item")
                    val url = target.optString("url").ifBlank { target.optString("apk_url") }
                    when {
                        target.optString("screen") == "downloads" -> startActivity(Intent(this@MainActivity, DownloadsActivity::class.java))
                        item != null && item.length() > 0 -> showDetail(item)
                        url.startsWith("http", true) -> openExternal(url, null)
                        else -> showNotificationCenter()
                    }
                }
                page.addView(cardView, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
            applyTvFocusToClickableTree(page)
        }

        if (AccountSession.isLoggedIn(this)) {
            AccountApi.listNotifications(this, 1, 50) { result ->
                if (result.success && result.json != null) renderNotificationItems(result.json.optJSONArray("items"))
                else renderNotificationItems(null, result.message.ifBlank { "اتصال به مرکز اعلان برقرار نشد؛ اعلان‌های آفلاین دستگاه همچنان نمایش داده می‌شوند." })
            }
        } else {
            renderNotificationItems(null)
        }
    }


    private fun showProfile() {
        currentScreen = "profile"
        if (AccountSession.isLoggedIn(this)) {
            val now = System.currentTimeMillis()
            if (now - lastAccountIdentityRefreshAt > 15_000L) {
                lastAccountIdentityRefreshAt = now
                AccountApi.refreshMe(this) { result ->
                    if (result.success && currentScreen == "profile") {
                        restoringNavigation = true
                        try { showProfile() } finally { restoringNavigation = false }
                    }
                }
            }
        }
        syncAccountWatchlistAndRefresh(false)
        rememberCurrentScreen { showProfile() }
        buildBottomNav()
        clear()
        isMainHomePage = true
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }

        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(104))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(30))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(accountProfileCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val stats = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        stats.addView(profileCountPill(t("علاقه‌مندی‌ها", "Favorites"), storeItems("favorites").size), LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginStart = dp(6) })
        stats.addView(profileCountPill(t("ادامه", "Continue"), storeItems("continue").size), LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginStart = dp(6); marginEnd = dp(6) })
        stats.addView(profileCountPill(t("بازدید", "History"), storeItems("history").size), LinearLayout.LayoutParams(0, dp(92), 1f).apply { marginEnd = dp(6) })
        page.addView(stats, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        page.addView(
            premiumSettingsRow(
                "تنظیمات",
                "تم، رنگ، زیرنویس و تنظیمات پلیر",
                UiPreferences.themeMode(this),
                R.drawable.ic_player_settings
            ) { showSettingsPage() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        )

        page.addView(
            premiumSettingsRow(
                "دانلودهای من",
                "دانلودر اختصاصی، توقف و ادامه، سرعت و فایل‌های کامل‌شده",
                InternalDownloadStore.all(this).size.toString(),
                R.drawable.ic_download
            ) { startActivity(Intent(this, DownloadsActivity::class.java)) },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        )

        page.addView(
            premiumSettingsRow(
                t("Watch Party / تماشای دونفره", "Watch Party"),
                t("ورود به سینمای خصوصی با کد یا لینک دعوت", "Join a private cinema with a room code or invite link"),
                "VIP",
                R.drawable.ic_watch_party
            ) { showWatchPartyJoinDialog() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
        )


        page.addView(
            premiumSettingsRow(
                "پاک کردن تاریخچه ادامه تماشا",
                "حذف تمام موقعیت‌های ذخیره‌شده پخش و فهرست ادامه تماشا",
                "",
                R.drawable.ic_close_clean,
                true
            ) { clearContinueWatching() },
            LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }
        )

        addProfileContinueSection(page)
        addLocalRail(page, ui("آخرین بازدیدها"), "history", ui("هنوز فیلمی باز نکردی"))

        page.addView(premiumSectionTitle(t("راهنما", "Help")))
        page.addView(premiumSettingsRow(t("راهنما و سوالات متداول", "Help center & FAQ"), t("آرشیوها، هاردساب و سافت‌ساب، اتصال و مشکلات رایج", "Archives, subtitles, connection and common issues"), "", R.drawable.ic_info_archive) { showHelpCenter() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        page.addView(premiumSectionTitle("ارتباط با بانک مووی"))
        page.addView(telegramProCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        page.addView(premiumSettingsRow("درباره برنامه", "برنامه‌نویس و راه‌های ارتباطی", appVersionName(), R.drawable.ic_info_badge) { showAboutPage() }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(premiumSettingsRow("پاک کردن آخرین بازدیدها", "فقط فهرست آخرین بازدیدها حذف می‌شود", "", R.drawable.ic_close_clean, true) { clearWatchHistory() })
    }


    private fun clearContinueWatching() {
        if (storeItems("continue").isEmpty()) {
            Toast.makeText(this, ui("ادامه تماشایی برای پاک کردن نیست"), Toast.LENGTH_SHORT).show()
            return
        }
        val p = UiPreferences.palette(this)
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = bankGlassDrawable(24, 236, 70, true)
        }
        box.addView(TextView(this).apply {
            text = ui("پاک کردن تاریخچه ادامه تماشا")
            setTextColor(p.text); textSize = 18f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        box.addView(TextView(this).apply {
            text = ui("تمام موقعیت‌های ذخیره‌شده پخش و فهرست ادامه تماشا حذف می‌شوند.")
            setTextColor(p.muted); textSize = 12.8f; gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })
        box.addView(modalButton(ui("پاک کردن"), R.drawable.ic_close_clean, true) {
            val items = storeItems("continue")
            val edit = appPrefs().edit().putString("continue", "[]")
            items.forEach { item ->
                val url = item.optString("url")
                val key = item.optString("progress_key").ifBlank { if (url.isBlank()) "" else "progress_$url" }
                if (key.isNotBlank()) { edit.remove(key); edit.remove("${key}_duration") }
                if (url.isNotBlank()) { edit.remove("progress_$url"); edit.remove("progress_${url}_duration") }
            }
            edit.apply()
            dialog.dismiss()
            Toast.makeText(this, ui("تاریخچه ادامه تماشا پاک شد"), Toast.LENGTH_SHORT).show()
            showProfile()
        }, LinearLayout.LayoutParams(-1, dp(50)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show(); styleShownDialog(dialog, box)
    }

    private fun removeStoreItem(storeKey: String, item: JSONObject) {
        val id = item.optString("_key").ifBlank { storageKey(item) }
        val list = storeItems(storeKey).filter { it.optString("_key") != id }
        saveStoreItems(storeKey, list)
        if (storeKey == "favorites" && AccountSession.isLoggedIn(this)) {
            AccountSession.markWatchlistRemoved(this, id)
            AccountApi.syncWatchlist(this, force = true) {}
        }
        BmNotice.show(this, "حذف شد", BmNotice.Kind.INFO)
    }

    private fun openStoredContinue(item: JSONObject) {
        val url = item.optString("url")
        if (url.isBlank()) {
            showDetail(item)
            return
        }
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "Bankmovie" }
        val arr = JSONArray().put(JSONObject().apply {
            put("url", url)
            put("title", title)
            put("quality", item.optString("quality"))
            put("display_label", item.optString("display_label"))
            put("type_fa", item.optString("type_fa"))
            put("type", item.optString("type"))
            put("season", item.optInt("season", 0))
            put("episode", item.optInt("episode", 0))
            put("progress_key", item.optString("progress_key").ifBlank { "progress_${url}" })
        })
        val payload = JSONObject().apply {
            put("video", url)
            put("title", title)
            put("selectedIndex", 0)
            put("tracks", arr)
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, url)
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, payload.toString())
            putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, item.optString("progress_key").ifBlank { "progress_${url}" })
            putExtra(PlayerActivity.EXTRA_RESUME_POSITION, continueProgressValues(item).first)
        })
    }

    private fun progressTextFor(item: JSONObject): String {
        val url = item.optString("url")
        val key = item.optString("progress_key").ifBlank {
            if (url.isBlank()) "" else "progress_$url"
        }
        if (key.isBlank()) return ""
        val ms = appPrefs().getLong(key, if (url.isNotBlank()) appPrefs().getLong("progress_$url", 0L) else 0L)
        return formatResumeTime(ms)
    }

    private fun continueProgressValues(item: JSONObject): Pair<Long, Long> {
        val url = item.optString("url")
        val key = item.optString("progress_key").ifBlank { if (url.isBlank()) "" else "progress_$url" }
        if (key.isBlank()) return 0L to 0L
        val prefs = appPrefs()
        val position = prefs.getLong(key, if (url.isNotBlank()) prefs.getLong("progress_$url", 0L) else 0L)
        val duration = prefs.getLong("${key}_duration", if (url.isNotBlank()) prefs.getLong("progress_${url}_duration", 0L) else 0L)
        return position.coerceAtLeast(0L) to duration.coerceAtLeast(0L)
    }

    private fun profileStoredCard(storeKey: String, item: JSONObject, targetPosterWidth: Int = dp(116)): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(3), dp(3), dp(3), dp(3))

            if (storeKey == "continue") {
                val cardBox = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    gravity = Gravity.CENTER_VERTICAL
                    background = rounded(panel, dp(22), Color.argb(105, Color.red(blue), Color.green(blue), Color.blue(blue)))
                    clipToOutline = false
                    setOnClickListener { openStoredContinue(item) }
                    applyTvFocusHalo(this, 24, 1.075f, dp(2).toFloat())
                }

                val cardWidth = (resources.displayMetrics.widthPixels - dp(48))
                    .coerceAtLeast(dp(300))
                    .coerceAtMost(dp(560))
                val imageWidth = (cardWidth * 0.38f).toInt()
                    .coerceAtLeast(dp(108))
                    .coerceAtMost(dp(178))

                val imageFrame = FrameLayout(this@MainActivity).apply {
                    background = bankGlassDrawable(20, 226, 62, false)
                    clipToOutline = true
                }
                val image = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                imageFrame.addView(image, FrameLayout.LayoutParams(-1, -1))
                loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, image)
                cardBox.addView(imageFrame, LinearLayout.LayoutParams(imageWidth, -1))

                val details = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                    setPadding(dp(18), dp(13), dp(16), dp(13))
                }
                val titleValue = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "Bankmovie" }
                val season = item.optInt("season", 0)
                val episode = item.optInt("episode", 0)
                val episodeLabel = when {
                    season > 0 && episode > 0 -> "S%02d • E%02d".format(season, episode)
                    episode > 0 -> "قسمت $episode"
                    else -> item.optString("type_fa")
                }
                val quality = item.optString("quality").ifBlank { item.optString("display_label") }
                val (position, duration) = continueProgressValues(item)
                val remaining = if (duration > position && duration > 0L) duration - position else 0L

                val titleRow = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    gravity = Gravity.CENTER_VERTICAL
                }
                titleRow.addView(TextView(this@MainActivity).apply {
                    text = titleValue
                    setTextColor(white)
                    textSize = 16.5f
                    typeface = Typeface.DEFAULT_BOLD
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.LEFT
                }, LinearLayout.LayoutParams(0, -2, 1f))
                titleRow.addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_seen_eye)
                    setColorFilter(Color.rgb(205, 214, 228))
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(28), dp(28)).apply { marginStart = dp(8) })
                details.addView(titleRow, LinearLayout.LayoutParams(-1, -2))

                details.addView(TextView(this@MainActivity).apply {
                    text = listOf(episodeLabel, quality).filter { it.isNotBlank() }.joinToString("  •  ")
                    setTextColor(Color.rgb(151, 158, 171))
                    textSize = 12f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.LEFT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

                val progressTrack = FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.rgb(48, 53, 61), dp(3), Color.TRANSPARENT)
                }
                val fraction = when {
                    duration > 0L -> (position.toFloat() / duration.toFloat()).coerceIn(0.03f, 1f)
                    position > 0L -> 0.35f
                    else -> 0.03f
                }
                val progressFill = View(this@MainActivity).apply {
                    background = rounded(blue, dp(3), Color.TRANSPARENT)
                }
                progressTrack.addView(progressFill, FrameLayout.LayoutParams(dp(8), -1, Gravity.LEFT))
                progressTrack.post {
                    val target = (progressTrack.width * fraction).roundToInt().coerceAtLeast(dp(8))
                    progressFill.layoutParams = FrameLayout.LayoutParams(target, -1, Gravity.LEFT)
                }
                details.addView(progressTrack, LinearLayout.LayoutParams(-1, dp(6)).apply { topMargin = dp(10) })

                details.addView(TextView(this@MainActivity).apply {
                    text = when {
                        remaining > 0L -> "${formatResumeTime(remaining)} باقی‌مانده"
                        position > 0L -> "ادامه از ${formatResumeTime(position)}"
                        else -> "ادامه تماشا"
                    }
                    setTextColor(Color.rgb(164, 169, 180))
                    textSize = 11.5f
                    gravity = Gravity.LEFT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })

                cardBox.addView(details, LinearLayout.LayoutParams(0, -1, 1f))
                addView(cardBox, LinearLayout.LayoutParams(cardWidth, dp(132)))
                return@apply
            }

            val posterWidth = targetPosterWidth.coerceAtLeast(dp(92))
            addView(posterCard(item, posterWidth, (posterWidth * 1.78f).roundToInt()))
            if (storeKey == "favorites") {
                addView(TextView(this@MainActivity).apply {
                    text = "حذف از واچ‌لیست"
                    setTextColor(white)
                    textSize = 10.5f
                    gravity = Gravity.CENTER
                    background = rounded(Color.rgb(120, 24, 35), dp(10), Color.TRANSPARENT)
                    setOnClickListener {
                        removeStoreItem(storeKey, item)
                        showFavorites()
                    }
                }, LinearLayout.LayoutParams(-1, dp(28)).apply { topMargin = dp(3) })
            }
        }
    }

    private fun showFavorites() {
        if (!AccountSession.watchlistEnabled(this)) {
            BmNotice.show(this, "علاقه‌مندی‌ها موقتاً از پنل غیرفعال شده‌اند", BmNotice.Kind.WARNING)
            showHome()
            return
        }
        syncAccountWatchlistAndRefresh(false)
        showLocalList(t("واچ‌لیست", "Watchlist"), "favorites", t("هنوز چیزی به واچ‌لیست اضافه نکرده‌ای", "You have not added anything to your watchlist yet"))
    }

    private fun showLocalList(title: String, storeKey: String, emptyText: String) {
        currentScreen = if (storeKey == "favorites") "favorites" else "profile"
        val savedTitle = title
        val savedStoreKey = storeKey
        val savedEmptyText = emptyText
        rememberCurrentScreen { showLocalList(savedTitle, savedStoreKey, savedEmptyText) }
        buildBottomNav()
        clear()
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(100)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (storeKey == "favorites") dp(14) else dp(12), dp(if (storeKey == "favorites") 22 else 8), if (storeKey == "favorites") dp(14) else dp(12), dp(28))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(title))
        val items = storeItems(storeKey)
        if (items.isEmpty()) {
            page.addView(emptyStateBox(emptyText, "برای ذخیره، از صفحه فیلم استفاده کن"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(30) })
            return
        }
        if (storeKey == "continue") {
            val list = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            page.addView(list, LinearLayout.LayoutParams(-1, -2))
            items.forEach { saved ->
                list.addView(
                    profileStoredCard(storeKey, saved),
                    LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }
                )
            }
        } else {
            val columns = if (resources.displayMetrics.widthPixels >= dp(600)) 4 else 3
            val grid = GridLayout(this).apply {
                columnCount = columns
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                useDefaultMargins = false
                alignmentMode = GridLayout.ALIGN_BOUNDS
            }
            page.addView(grid, LinearLayout.LayoutParams(-1, -2))
            val screenWidth = resources.displayMetrics.widthPixels
            val availableWidth = screenWidth - dp(if (storeKey == "favorites") 28 else 24)
            val cellWidth = (availableWidth / columns).coerceAtLeast(dp(96))
            items.forEachIndexed { index, saved ->
                val card = profileStoredCard(storeKey, saved, cellWidth - dp(12)).apply {
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }
                grid.addView(card, GridLayout.LayoutParams().apply {
                    width = cellWidth
                    height = -2
                    rowSpec = GridLayout.spec(index / columns)
                    columnSpec = GridLayout.spec(index % columns)
                    bottomMargin = dp(12)
                })
            }
        }
    }

    private fun copyLink(url: String) {
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(android.content.ClipData.newPlainText("download_link", url))
        BmNotice.show(this, "لینک کپی شد", BmNotice.Kind.SUCCESS)
    }

    private fun seriesBulkCopyButton(item: JSONObject, links: List<JSONObject>): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            val accent = blue
            val accent2 = blue2
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(
                    Color.argb(185, Color.red(alphaSurface2()), Color.green(alphaSurface2()), Color.blue(alphaSurface2())),
                    Color.argb(85, Color.red(accent2), Color.green(accent2), Color.blue(accent2))
                )
            ).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(165, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            elevation = dp(4).toFloat()
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 999, 1.035f, dp(2).toFloat())
            applyMobileTouchHalo(this, 999)
            setOnClickListener { showSeriesBulkCopyDialog(item, links) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_copy_link)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(9) })
            addView(TextView(this@MainActivity).apply {
                text = t("کپی لینک همه قسمت‌ها", "Copy all episode links")
                setTextColor(Color.WHITE)
                textSize = 12.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun showSeriesBulkCopyDialog(item: JSONObject, links: List<JSONObject>) {
        val normalized = qualityOnlyLinks(sortedArchive1Links(links)).map { enrichEpisodeIdentity(JSONObject(it.toString())) }
        val withEpisodes = normalized.filter {
            it.optString("url").isNotBlank() && (it.optInt("episode", 0) > 0 || it.optInt("season", 0) > 0)
        }
        val seriesLinks = (if (withEpisodes.isNotEmpty()) withEpisodes else normalized)
            .filter { it.optString("url").isNotBlank() }
        if (seriesLinks.isEmpty()) {
            BmNotice.show(this, t("لینکی برای کپی پیدا نشد", "No links found"), BmNotice.Kind.WARNING)
            return
        }

        val qualityKeys = seriesLinks
            .sortedBy { qualitySortRank(it) }
            .map { normalizedQualityKey(it).ifBlank { "auto" } }
            .distinct()
        val kindKeys = seriesLinks
            .map { linkKindKey(it) }
            .filter { it.isNotBlank() }
            .distinct()
            .sortedBy { linkKindOrder(it) }

        val selectedQuality = arrayOf("all")
        val selectedKind = arrayOf("all")
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(17))
            background = bankGlassDrawable(27, 250, 78, true)
            elevation = dp(14).toFloat()
        }

        val titleRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        titleRow.addView(TextView(this).apply {
            text = t("کپی لینک همه قسمت‌ها", "Copy all episode links")
            setTextColor(Color.WHITE)
            textSize = 18.5f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(40), 1f))
        val close = TextView(this).apply {
            text = "×"
            setTextColor(Color.rgb(210, 212, 220))
            textSize = 24f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(70, 255, 255, 255), dp(999), Color.argb(70, 255, 255, 255))
            isClickable = true
            isFocusable = true
        }
        titleRow.addView(close, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(8) })
        shell.addView(titleRow)
        shell.addView(TextView(this).apply {
            text = t("کیفیت و نوع نسخه را انتخاب کن؛ فقط همان لینک‌ها کپی می‌شوند.", "Choose quality and release type; only matching links will be copied.")
            setTextColor(Color.rgb(154, 158, 170))
            textSize = 11.2f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(0, dp(3), 0, dp(12))
        })

        fun qualityLabel(key: String): String = when (key) {
            "all" -> t("همه کیفیت‌ها", "All qualities")
            "2160p" -> "4K / 2160P"
            else -> key.uppercase(Locale.US)
        }
        fun kindLabel(key: String): String = when (key) {
            "all" -> t("همه نسخه‌ها", "All versions")
            "dub" -> t("دوبله فارسی", "Persian dub")
            "sub" -> t("زیرنویس فارسی", "Persian subtitle")
            "hard" -> t("هاردساب", "Hardsub")
            "audio" -> t("صوت دوبله", "Dub audio")
            else -> t("نسخه اصلی", "Original")
        }

        shell.addView(TextView(this).apply {
            text = t("کیفیت", "Quality")
            setTextColor(Color.rgb(225, 226, 232))
            textSize = 12.3f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(7))
        })
        val qualityScroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val qualityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        qualityScroll.addView(qualityRow)
        shell.addView(qualityScroll, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(10) })

        shell.addView(TextView(this).apply {
            text = t("نسخه", "Release")
            setTextColor(Color.rgb(225, 226, 232))
            textSize = 12.3f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(7))
        })
        val kindScroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val kindRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        kindScroll.addView(kindRow)
        shell.addView(kindScroll, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(9) })

        val countText = TextView(this).apply {
            setTextColor(Color.rgb(135, 140, 153))
            textSize = 10.7f
            gravity = Gravity.RIGHT
            setPadding(dp(2), dp(2), dp(2), dp(9))
        }
        shell.addView(countText)

        val qualityViews = linkedMapOf<String, TextView>()
        val kindViews = linkedMapOf<String, TextView>()
        fun styleChoice(view: TextView, selected: Boolean, strong: Boolean) {
            val palette = UiPreferences.palette(this@MainActivity)
            view.setTextColor(if (selected) Color.WHITE else palette.muted)
            view.background = if (selected) bankTintGlassDrawable(palette.primary, 15, 228, if (strong) 0.22f else 0.14f)
            else bankGlassDrawable(15, 205, 48, false)
        }
        fun filtered(): List<JSONObject> = seriesLinks.filter { link ->
            val q = normalizedQualityKey(link).ifBlank { "auto" }
            val k = linkKindKey(link)
            (selectedQuality[0] == "all" || selectedQuality[0] == q) &&
                (selectedKind[0] == "all" || selectedKind[0] == k)
        }.sortedWith(compareBy<JSONObject> { it.optInt("season", 0).let { s -> if (s > 0) s else 999 } }
            .thenBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 999 } }
            .thenBy { qualitySortRank(it) }
            .thenBy { linkKindOrder(linkKindKey(it)) })

        fun refreshChoices() {
            qualityViews.forEach { (key, v) -> styleChoice(v, selectedQuality[0] == key, true) }
            kindViews.forEach { (key, v) -> styleChoice(v, selectedKind[0] == key, false) }
            val chosen = filtered()
            val episodes = chosen.map { "${it.optInt("season", 0)}:${it.optInt("episode", 0)}" }.distinct().size
            countText.text = t("${chosen.size} لینک • $episodes قسمت", "${chosen.size} links • $episodes episodes")
        }
        fun addChoice(row: LinearLayout, key: String, label: String, quality: Boolean) {
            val view = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11.4f
                typeface = BankmovieFonts.medium(this@MainActivity)
                setPadding(dp(14), 0, dp(14), 0)
                minWidth = dp(78)
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 15, 1.035f, 0f)
                setOnClickListener {
                    if (quality) selectedQuality[0] = key else selectedKind[0] = key
                    refreshChoices()
                }
            }
            if (quality) qualityViews[key] = view else kindViews[key] = view
            row.addView(view, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(4); marginEnd = dp(4) })
        }
        addChoice(qualityRow, "all", qualityLabel("all"), true)
        qualityKeys.forEach { addChoice(qualityRow, it, qualityLabel(it), true) }
        addChoice(kindRow, "all", kindLabel("all"), false)
        kindKeys.forEach { addChoice(kindRow, it, kindLabel(it), false) }

        val copyAction = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bankPrimaryGlassDrawable(18)
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 18, 1.035f, dp(1).toFloat())
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_copy_link)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(9) })
            addView(TextView(this@MainActivity).apply {
                text = t("کپی لینک", "Copy links")
                setTextColor(Color.WHITE)
                textSize = 13.2f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.CENTER
            })
        }
        shell.addView(copyAction, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(3) })

        val downloadAll = TextView(this).apply {
            text = t("افزودن همین انتخاب به دانلودر داخلی", "Add this selection to internal downloader")
            setTextColor(Color.rgb(202, 204, 214))
            textSize = 10.8f
            gravity = Gravity.CENTER
            background = bankGlassDrawable(15, 210, 52, false)
            isClickable = true
            isFocusable = true
            setPadding(dp(8), 0, dp(8), 0)
        }
        shell.addView(downloadAll, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(8) })

        val title = item.optString("title_fa").ifBlank { item.optString("title") }
        val dialog = AlertDialog.Builder(this).setView(shell).create()
        close.setOnClickListener { dialog.dismiss() }
        copyAction.setOnClickListener {
            val chosen = filtered()
            val urls = chosen.map { it.optString("url").trim() }.filter { it.isNotBlank() }.distinct()
            if (urls.isEmpty()) {
                BmNotice.show(this, t("برای این انتخاب لینکی پیدا نشد", "No links match this selection"), BmNotice.Kind.WARNING)
                return@setOnClickListener
            }
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText(title.ifBlank { "BankMovie" }, urls.joinToString("\n")))
            BmNotice.show(this, t("${urls.size} لینک کپی شد", "${urls.size} links copied"), BmNotice.Kind.SUCCESS)
        }
        downloadAll.setOnClickListener {
            val chosen = filtered()
            if (chosen.isEmpty()) {
                BmNotice.show(this, t("برای این انتخاب لینکی پیدا نشد", "No links match this selection"), BmNotice.Kind.WARNING)
                return@setOnClickListener
            }
            enqueueSeriesBulkInternal(item, chosen)
        }
        refreshChoices()
        dialog.show()
        styleShownDialog(dialog, shell, maxWidthDp = 520)
    }

    private fun modalButton(label: String, iconRes: Int, red: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (red) bankTintGlassDrawable(Color.rgb(235, 35, 45), 17, 238, 0.30f)
            else bankGlassDrawable(17, 236, 72, true)
            setPadding(dp(10), 0, dp(10), 0)
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                if (iconRes != R.drawable.adm_logo_transparent && iconRes != R.drawable.ic_chrome) setColorFilter(white)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(9) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(white)
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun requestDownloadNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) return
        val prefs = appPrefs()
        if (prefs.getBoolean("notification_permission_requested", false)) return
        prefs.edit().putBoolean("notification_permission_requested", true).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1818)
    }

    private fun preferredDownloadFileName(item: JSONObject, link: JSONObject): String {
        val explicit = listOf("file_name", "filename", "original_name", "download_name")
            .asSequence().map { link.optString(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
        if (explicit.isNotBlank()) return InternalDownloadStore.normalizeRequestedFileName(explicit)

        val url = link.optString("url").trim()
        InternalDownloadStore.originalFileNameFromUrl(url)?.let { return it }

        val originalTitle = item.optString("title")
            .ifBlank { item.optString("original_title") }
            .ifBlank { item.optString("title_en") }
            .ifBlank { "Bankmovie" }
        val season = link.optInt("season", 0)
        val episode = link.optInt("episode", 0)
        val episodeToken = when {
            season > 0 && episode > 0 -> "S%02dE%02d".format(season, episode)
            episode > 0 -> "E%02d".format(episode)
            else -> ""
        }
        val quality = link.optString("quality").ifBlank { link.optString("display_label") }
        // If the server URL does not expose a real filename, keep the fallback
        // fully readable and episode-safe. Do not append localized/Persian kind
        // labels to the actual saved filename.
        return InternalDownloadStore.safeFileName(
            listOf(originalTitle, episodeToken).filter { it.isNotBlank() }.joinToString(" "),
            quality,
            "",
            url
        )
    }

    private fun enqueueSeriesBulkInternal(item: JSONObject, links: List<JSONObject>, locationAlreadyChosen: Boolean = false) {
        if (!AccountSession.internalDownloaderEnabled(this)) {
            BmNotice.show(this, t("دانلودر داخلی موقتاً غیرفعال است", "Internal downloader is disabled"), BmNotice.Kind.WARNING)
            return
        }
        val clean = links.filter { it.optString("url").startsWith("http", true) }
            .distinctBy { it.optString("url").trim() }
        if (clean.isEmpty()) return
        if (!locationAlreadyChosen && AccountSession.downloadPathSelectionEnabled(this) && !DownloadLocationPrefs.hasChoice(this)) {
            val p = UiPreferences.palette(this)
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(18), dp(18), dp(18), dp(18))
                background = bankGlassDrawable(26, 236, 70, true)
            }
            box.addView(TextView(this).apply {
                text = t("مسیر ذخیره لیست دانلود", "Bulk download location")
                setTextColor(p.text); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
            })
            box.addView(TextView(this).apply {
                text = t("این مسیر یک‌بار انتخاب می‌شود و همه فایل‌های این لیست در همان‌جا ذخیره می‌شوند.", "Choose once; every file in this list will use the same folder.")
                setTextColor(p.muted); textSize = 12.2f; gravity = Gravity.RIGHT; setPadding(0, dp(6), 0, dp(14))
            })
            lateinit var dialog: AlertDialog
            box.addView(modalButton(t("انتخاب پوشه دلخواه", "Choose folder"), R.drawable.ic_download, false) {
                pendingBulkDownloadItemJson = item.toString()
                pendingBulkDownloadLinksJson = JSONArray().apply { clean.forEach { put(JSONObject(it.toString())) } }.toString()
                dialog.dismiss()
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                }, downloadFolderRequestCode)
            }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(9) })
            box.addView(modalButton(t("حافظه اختصاصی برنامه", "App storage"), R.drawable.ic_download, false) {
                DownloadLocationPrefs.setAppFolder(this)
                dialog.dismiss()
                enqueueSeriesBulkInternal(item, clean, locationAlreadyChosen = true)
            }, LinearLayout.LayoutParams(-1, dp(52)))
            dialog = AlertDialog.Builder(this).setView(box).create()
            dialog.show(); styleShownDialog(dialog, box)
            return
        }
        clean.forEach { launchInternalDownload(item, it, showNotice = false) }
        BmNotice.show(this, t("${clean.size} فایل به صف دانلود اضافه شد", "${clean.size} files added to the download queue"), BmNotice.Kind.SUCCESS, 3200L)
    }

    private fun launchInternalDownload(item: JSONObject, link: JSONObject, showNotice: Boolean = true) {
        if (!AccountSession.internalDownloaderEnabled(this)) {
            Toast.makeText(this, "دانلودر داخلی موقتاً از پنل غیرفعال شده است", Toast.LENGTH_SHORT).show()
            return
        }
        val url = link.optString("url")
        if (url.isBlank()) return
        val existingDownload = InternalDownloadStore.get(this, InternalDownloadStore.idFor(url))
        if (existingDownload != null) {
            val existingStatus = existingDownload.optString("status")
            if (existingStatus == InternalDownloadStore.STATUS_COMPLETED && InternalDownloadStore.exists(this, existingDownload)) {
                Toast.makeText(this, "این فایل قبلاً کامل دانلود شده است", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, DownloadsActivity::class.java))
                return
            }
            if (InternalDownloadStore.isActiveStatus(existingStatus) || existingStatus == InternalDownloadStore.STATUS_PAUSED) {
                Toast.makeText(this, "این فایل از قبل در صف دانلود قرار دارد", Toast.LENGTH_LONG).show()
                startActivity(Intent(this, DownloadsActivity::class.java))
                return
            }
        }
        requestDownloadNotificationPermission()
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "Bankmovie" }
        val quality = link.optString("quality").ifBlank { link.optString("display_label") }
        val kind = linkKindLabel(link)
        val label = listOf(quality, kind, link.optString("size")).filter { it.isNotBlank() }.joinToString(" • ")
        val poster = item.optString("poster")
            .ifBlank { item.optString("image") }
            .ifBlank { item.optString("cover_image") }
            .ifBlank { item.optString("backdrop") }
        val fileName = preferredDownloadFileName(item, link)
        InternalDownloadService.start(this, url, title, quality, kind, label, poster, fileName)
        if (showNotice) BmNotice.show(this, "دانلود در ${DownloadLocationPrefs.displayName(this)} ذخیره می‌شود", BmNotice.Kind.SUCCESS, 3000L)
    }

    private fun startInternalDownload(item: JSONObject, link: JSONObject) {
        if (!AccountSession.internalDownloaderEnabled(this)) {
            openExternal(link.optString("url"), null)
            return
        }
        if (!AccountSession.downloadPathSelectionEnabled(this)) {
            DownloadLocationPrefs.setAppFolder(this)
            launchInternalDownload(item, link)
            return
        }
        if (DownloadLocationPrefs.hasChoice(this)) {
            launchInternalDownload(item, link)
            return
        }
        val p = UiPreferences.palette(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = bankGlassDrawable(26, 236, 70, true)
        }
        box.addView(TextView(this).apply {
            text = "مسیر ذخیره دانلود"
            setTextColor(p.text)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        box.addView(TextView(this).apply {
            text = "یک‌بار محل ذخیره را انتخاب کن. بعداً از بخش دانلودهای من قابل تغییر است."
            setTextColor(p.muted)
            textSize = 12.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, dp(14))
        })
        lateinit var dialog: AlertDialog
        box.addView(modalButton("انتخاب پوشه دلخواه", R.drawable.ic_download, false) {
            pendingDownloadItemJson = item.toString()
            pendingDownloadLinkJson = link.toString()
            dialog.dismiss()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, downloadFolderRequestCode)
        }, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(9) })
        box.addView(modalButton("حافظه اختصاصی برنامه", R.drawable.ic_download, false) {
            DownloadLocationPrefs.setAppFolder(this)
            dialog.dismiss()
            launchInternalDownload(item, link)
        }, LinearLayout.LayoutParams(-1, dp(52)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box)
    }

    private fun showDownloadChoiceModal(item: JSONObject, link: JSONObject) {
        val url = link.optString("url")
        if (url.isBlank()) {
            Toast.makeText(this, "لینک دانلود نامعتبر است", Toast.LENGTH_SHORT).show()
            return
        }
        when (UiPreferences.downloadBehavior(this)) {
            "internal" -> { startInternalDownload(item, link); return }
            "browser" -> { openExternal(url, null); return }
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = bankGlassDrawable(26, 228, 62, true)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, dp(12))
        }
        head.addView(FrameLayout(this).apply {
            background = rounded(Color.argb(60, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(18), Color.argb(130, Color.red(blue), Color.green(blue), Color.blue(blue)))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_download)
                setColorFilter(blue)
            }, FrameLayout.LayoutParams(dp(29), dp(29), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(12) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titles.addView(TextView(this).apply {
            text = "دانلود فایل"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = listOf(
                link.optString("quality").ifBlank { link.optString("display_label") },
                linkKindLabel(link),
                link.optString("size")
            ).filter { it.isNotBlank() }.joinToString(" • ")
            setTextColor(muted)
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        box.addView(head)
        if (AccountSession.internalDownloaderEnabled(this)) {
            box.addView(modalButton("دانلودر داخلی بانک مووی", R.drawable.ic_download, false) {
                startInternalDownload(item, link)
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
        }
        box.addView(modalButton("ADM", R.drawable.adm_logo_transparent, true) {
            openExternal(url, "com.dv.adm")
        }, LinearLayout.LayoutParams(-1, dp(50)))
        val downloadDialog = AlertDialog.Builder(this).setView(box).create()
        downloadDialog.show()
        styleShownDialog(downloadDialog, box)
    }

    private fun prefetchArchive3SearchOptions(force: Boolean = false, onLoaded: (() -> Unit)? = null) {
        val prefs = appPrefs()
        val now = System.currentTimeMillis()
        if (!force && archive3SearchOptions != null) {
            onLoaded?.invoke()
            return
        }
        if (!force) {
            val cachedAt = prefs.getLong("archive3_search_options_at", 0L)
            val cachedRaw = prefs.getString("archive3_search_options_json", "").orEmpty()
            if (cachedRaw.isNotBlank() && now - cachedAt < 6L * 60L * 60L * 1000L) {
                runCatching { JSONObject(cachedRaw) }.getOrNull()?.let {
                    archive3SearchOptions = it
                    onLoaded?.invoke()
                    return
                }
            }
        }
        if (archive3OptionsFetchRunning) return
        archive3OptionsFetchRunning = true
        fetch("$archive3ApiBase?search_options=1") { ok, json, _ ->
            archive3OptionsFetchRunning = false
            if (ok && json != null && json.optString("status").equals("success", true)) {
                archive3SearchOptions = json
                prefs.edit()
                    .putString("archive3_search_options_json", json.toString())
                    .putLong("archive3_search_options_at", System.currentTimeMillis())
                    .apply()
            }
            onLoaded?.let { cb -> runOnUiThread { cb() } }
        }
    }

    private fun archive3Options(key: String, includeAll: Boolean): List<AdvancedOption> {
        if (archive3SearchOptions == null) {
            val cachedRaw = appPrefs().getString("archive3_search_options_json", "").orEmpty()
            archive3SearchOptions = runCatching { JSONObject(cachedRaw) }.getOrNull()
        }
        val out = mutableListOf<AdvancedOption>()
        val seen = linkedSetOf<String>()
        val arr = archive3SearchOptions?.optJSONArray(key)
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val raw = arr.opt(i)
                val option = when (raw) {
                    is JSONObject -> {
                        val value = raw.optString("value")
                            .ifBlank { raw.optString("key") }
                            .ifBlank { raw.optString("id") }
                            .ifBlank { raw.optString("label") }
                        val label = raw.optString("label")
                            .ifBlank { raw.optString("title") }
                            .ifBlank { value }
                        if (value.isBlank()) null else AdvancedOption(value, label)
                    }
                    is String -> raw.trim().takeIf { it.isNotBlank() }?.let { AdvancedOption(it, it) }
                    is Number -> AdvancedOption(raw.toString(), raw.toString())
                    else -> null
                }
                if (option != null && seen.add(option.value.lowercase(Locale.ROOT))) out.add(option)
            }
        }
        if (key == "years") {
            out.sortByDescending { it.value.toIntOrNull() ?: 0 }
        }
        if (includeAll && out.none { it.value.isBlank() || it.value.equals("all", true) }) {
            out.add(0, AdvancedOption(if (key == "types") "all" else "", t("همه", "All")))
        }
        return out
    }

    private fun sanitizeArchive(archive: Int): Int = when (archive) {
        2 -> 2
        3 -> 3
        else -> 1
    }

    private fun archiveRawEnabled(archive: Int): Boolean = when (sanitizeArchive(archive)) {
        2 -> remoteArchive2Enabled
        3 -> remoteArchive3Enabled
        else -> remoteArchive1Enabled
    }

    private fun archiveHidden(archive: Int): Boolean = when (sanitizeArchive(archive)) {
        2 -> remoteArchive2Hidden
        3 -> remoteArchive3Hidden
        else -> remoteArchive1Hidden
    }

    private fun archiveVisible(archive: Int): Boolean = !archiveHidden(archive)

    private fun archiveEnabled(archive: Int): Boolean = archiveVisible(archive) && archiveRawEnabled(archive)

    private fun anyArchiveVisible(): Boolean = listOf(1, 2, 3).any { archiveVisible(it) }

    private fun anyArchiveEnabled(): Boolean = listOf(1, 2, 3).any { archiveEnabled(it) }

    private fun archiveLabel(archive: Int): String = when (sanitizeArchive(archive)) {
        2 -> t("آرشیو ۲", "Archive 2")
        3 -> t("آرشیو ۳", "Archive 3")
        else -> t("آرشیو ۱", "Archive 1")
    }


    private fun updateArchiveHealth(archive: Int, success: Boolean, message: String = "") {
        val state = archiveHealth.getOrPut(sanitizeArchive(archive)) { ArchiveHealthState() }
        val now = System.currentTimeMillis()
        if (success) {
            state.consecutiveFailures = 0
            state.lastSuccessAt = now
            state.lastMessage = ""
        } else {
            state.consecutiveFailures = (state.consecutiveFailures + 1).coerceAtMost(9)
            state.lastFailureAt = now
            state.lastMessage = message
        }
    }

    private fun archiveHealthText(archive: Int): String {
        if (!archiveRawEnabled(archive)) return t("غیرفعال از پنل", "Disabled")
        val state = archiveHealth[sanitizeArchive(archive)] ?: return t("در حال بررسی", "Checking")
        val now = System.currentTimeMillis()
        return when {
            state.lastSuccessAt > 0L && now - state.lastSuccessAt < 10 * 60_000L -> t("متصل", "Connected")
            state.consecutiveFailures >= 2 && now - state.lastFailureAt < 4 * 60_000L -> t("اختلال موقت", "Temporary issue")
            else -> t("در حال بررسی", "Checking")
        }
    }

    private fun archiveHealthColor(archive: Int, palette: UiPreferences.Palette): Int {
        if (!archiveRawEnabled(archive)) return Color.rgb(230, 72, 82)
        val state = archiveHealth[sanitizeArchive(archive)] ?: return palette.primary
        val now = System.currentTimeMillis()
        return when {
            state.lastSuccessAt > 0L && now - state.lastSuccessAt < 10 * 60_000L -> Color.rgb(48, 190, 112)
            state.consecutiveFailures >= 2 && now - state.lastFailureAt < 4 * 60_000L -> Color.rgb(255, 170, 45)
            else -> palette.primary
        }
    }

    private fun setSelectedArchive(archive: Int) {
        val safe = sanitizeArchive(archive)
        if (!archiveEnabled(safe)) {
            BmNotice.show(this, "این آرشیو موقتاً از پنل مدیریت غیرفعال شده است", BmNotice.Kind.WARNING)
            return
        }
        if (selectedArchive == safe) return
        selectedArchive = safe
        appPrefs().edit().putInt("selected_archive", safe).apply()
        if (safe == 3) prefetchArchive3SearchOptions()
        navigationHistory.clear()
        showHome()
    }

    private fun archiveSectionUrl(archive: Int, section: String, page: Int, limit: Int): String {
        return when (sanitizeArchive(archive)) {
            2 -> {
                val mapped = when (section) {
                    // Archive 2 follows the real site DB update order. Do not
                    // narrow "updated_movies" to a release-year bucket.
                    "updated_series" -> "new_series"
                    "anime", "updated_anime", "updated_animations" -> "animation"
                    else -> section
                }
                "$apiBase?action=section&archive=2&section=${enc(mapped)}&page=$page&limit=$limit"
            }
            3 -> {
                val mapped = when (section) {
                    "updated_movies", "movies", "movie" -> "new_movies"
                    "updated_series", "series" -> "new_series"
                    "animation", "animations" -> "updated_animations"
                    "anime" -> "updated_anime"
                    else -> section
                }
                "$archive3ApiBase?section=${enc(mapped)}&page=$page&limit=$limit"
            }
            else -> {
                if (section == "dubbed" || section == "chinese_series") {
                    "$archive1LiveApiBase?section=${enc(section)}&page=$page&limit=$limit"
                } else {
                    "$apiBase?action=section&archive=1&section=${enc(section)}&page=$page&limit=$limit"
                }
            }
        }
    }

    private fun archiveSearchUrl(archive: Int, query: String, page: Int, limit: Int, typeFilter: String = "all", live: Boolean = false): String {
        val safe = sanitizeArchive(archive)
        val typeParam = if (typeFilter == "all") "" else "&type=${enc(typeFilter)}"
        return when (safe) {
            2 -> "$apiBase?action=search&archive=2&q=${enc(query)}&page=$page&limit=$limit$typeParam"
            3 -> "$archive3ApiBase?q=${enc(query)}&page=$page&limit=$limit$typeParam"
            else -> {
                val action = if (live) "live_search" else "search"
                val searchOnly = if (live) "" else "&search_only=1"
                "$apiBase?action=$action&archive=1&q=${enc(query)}&page=$page&limit=$limit$typeParam$searchOnly"
            }
        }
    }

    private fun isDatabaseBackedItem(seed: JSONObject?): Boolean {
        if (seed == null) return false
        val source = seed.optString("source").lowercase()
        if (source in setOf("db_movies", "database", "local_db", "collection", "website_db")) return true
        if (seed.optInt("db_id", 0) > 0) return true
        val apiDetail = seed.optString("api_detail")
        return apiDetail.contains("app_api.php", true) && apiDetail.contains("archive=2", true)
    }

    private fun archiveDetailUrl(archive: Int, id: String, type: String, sourceUrl: String = "", seed: JSONObject? = null): String {
        return when (sanitizeArchive(archive)) {
            2 -> {
                // Database is authoritative for Archive 2. Prefer the numeric DB id,
                // then stable id/imdb metadata; never fall back to api5 in this APK.
                val dbId = seed?.optInt("db_id", 0)?.takeIf { it > 0 }
                    ?: seed?.optInt("movie_id", 0)?.takeIf { it > 0 }
                val resolvedId = dbId?.toString() ?: id
                val params = mutableListOf(
                    "action=detail",
                    "archive=2",
                    "id=${enc(resolvedId)}",
                    "type=${enc(type)}"
                )
                seed?.optString("imdb_code")?.takeIf { it.isNotBlank() }?.let { params.add("imdb_code=${enc(it)}") }
                seed?.optString("title")?.takeIf { it.isNotBlank() }?.let { params.add("title=${enc(it)}") }
                seed?.optString("title_fa")?.takeIf { it.isNotBlank() }?.let { params.add("title_fa=${enc(it)}") }
                seed?.optString("year")?.takeIf { it.isNotBlank() }?.let { params.add("year=${enc(it)}") }
                "$apiBase?${params.joinToString("&")}"
            }
            3 -> if (sourceUrl.startsWith("http", true)) {
                "$archive3ApiBase?url=${enc(sourceUrl)}"
            } else {
                "$archive3ApiBase?id=${enc(id)}"
            }
            else -> {
                val sourceParam = if (sourceUrl.startsWith("http", true)) "&url=${enc(sourceUrl)}" else ""
                "$apiBase?action=detail&archive=1&id=${enc(id)}&type=${enc(type)}$sourceParam"
            }
        }
    }


    private fun cleanArchive2DisplayTitle(value: String): String {
        var text = value
            .replace("&#8211;", "–")
            .replace("&ndash;", "–")
            .replace("&mdash;", "—")
            .replace(Regex("""^\s*دانلود\s+(?:فیلم|سریال)\s*"""), "")
            .replace(Regex("""\(\s*\*?کیفیت[^)]*\)"""), "")
            .replace(
                Regex("""[،,]?\s*(?:بدون سانسور|با دوبله(?: فارسی)?|دوبله(?: فارسی)?|با زیرنویس(?: فارسی)?|زیرنویس(?: فارسی)?|کاملاً? رایگان|کاملا رایگان|رایگان|کامل|با همه کیفیت(?:‌|\s)?ها|کیفیت پرده|با لینک مستقیم)"""),
                " "
            )
            .replace(Regex("""\s+"""), " ")
            .trim(' ', '،', ',', '-', '–', '—', '|')
        text = text
            .replace(Regex("""(?:\s+و)+\s*(?=–|—|$)"""), " ")
            .replace(Regex("""\s*[،,]\s*(?=–|—|$)"""), " ")
            .trim()
        return text.ifBlank { value.trim() }
    }

    private fun canonicalBankmovieAssetUrl(value: String): String {
        val original = value.trim()
        if (original.isBlank()) return ""
        val canonical = "https://bankmovie.top"

        fun cleanPath(input: String): String {
            var path = input.trim().replace('\\', '/')
            // Older DB rows may contain absolute server filesystem paths. Keep only
            // the public part that can actually be served by bankmovie.top.
            listOf("/public_html/", "/htdocs/", "/www/").forEach { marker ->
                val index = path.indexOf(marker, ignoreCase = true)
                if (index >= 0) path = path.substring(index + marker.length)
            }
            path = path.replace(Regex("/{2,}"), "/")
            return path.trimStart('/')
        }

        val raw = if (original.startsWith("//")) "https:$original" else original
        if (!raw.startsWith("http://", true) && !raw.startsWith("https://", true)) {
            return canonical + "/" + cleanPath(raw)
        }
        return try {
            val uri = Uri.parse(raw)
            val host = uri.host.orEmpty().lowercase(Locale.US)
            if (host in setOf("bankmoviee.ir", "www.bankmoviee.ir", "bankmovie.top", "www.bankmovie.top")) {
                val query = uri.encodedQuery?.let { "?$it" }.orEmpty()
                val fragment = uri.encodedFragment?.let { "#$it" }.orEmpty()
                canonical + "/" + cleanPath(uri.encodedPath.orEmpty()) + query + fragment
            } else raw
        } catch (_: Throwable) {
            canonical + "/" + cleanPath(raw)
        }
    }

    private fun normalizeArchiveItem(raw: JSONObject, archive: Int): JSONObject {
        val item = JSONObject(raw.toString())
        item.put("archive", archive)
        if (item.optString("source_url").isBlank() && item.optString("url").startsWith("http", true)) item.put("source_url", item.optString("url"))
        if (item.optString("id").isBlank()) item.put("id", item.optString("slug"))
        if (item.optString("id").isBlank()) {
            val source = item.optString("source_url").ifBlank { item.optString("url") }
            val derived = try { Uri.parse(source).pathSegments.lastOrNull().orEmpty() } catch (_: Throwable) { "" }
            if (derived.isNotBlank()) item.put("id", derived)
        }
        if (item.optString("slug").isBlank()) item.put("slug", item.optString("id"))
        if (item.optString("source_slug").isBlank()) item.put("source_slug", item.optString("slug"))
        if (item.optInt("comment_archive", 0) <= 0) item.put("comment_archive", archive)
        if (item.optString("comment_identity").isBlank()) item.put("comment_identity", item.optString("source_slug").ifBlank { item.optString("id") })
        if (item.optString("title_fa").isBlank()) item.put("title_fa", item.optString("title"))
        if (archive == 3) {
            if (item.optString("id").isBlank()) item.put("id", item.optString("detail_id"))
            if (item.optString("id").isBlank() && item.optLong("source_post_id", 0L) > 0L) {
                item.put("id", item.optLong("source_post_id").toString())
            }
            val preferredTitle = item.optString("title_fa")
                .ifBlank { item.optString("full_title") }
                .ifBlank { item.optString("title") }
            item.put("title_fa", preferredTitle)
            if (item.optString("title").isBlank()) item.put("title", preferredTitle)
            val mediaKind = item.optString("media_kind").lowercase(Locale.US)
            when (mediaKind) {
                "anime" -> item.put("type", "anime")
                "animation" -> item.put("type", "animation")
            }
        }
        if (archive == 2) {
            val cleanFa = cleanArchive2DisplayTitle(item.optString("title_fa").ifBlank { item.optString("title") })
            val cleanTitle = cleanArchive2DisplayTitle(item.optString("title").ifBlank { cleanFa })
            item.put("title_fa", cleanFa)
            item.put("title", cleanTitle)
            listOf("poster", "image", "cover_image", "backdrop", "background").forEach { key ->
                val value = item.optString(key)
                if (value.isNotBlank()) item.put(key, canonicalBankmovieAssetUrl(value))
            }
        }
        if (item.optString("poster").isBlank()) {
            item.put("poster", item.optString("image").ifBlank { item.optString("cover_image") })
        }
        if (item.optString("runtime").isBlank()) item.put("runtime", item.optString("duration"))
        return item
    }

    private fun normalizeArchiveResponse(raw: JSONObject, archive: Int): JSONObject {
        val json = JSONObject(raw.toString())
        var items = json.optJSONArray("items")
        if (items == null) items = json.optJSONArray("movies")
        if (items != null) {
            val normalized = JSONArray()
            for (i in 0 until items.length()) {
                items.optJSONObject(i)?.let { normalized.put(normalizeArchiveItem(it, archive)) }
            }
            json.put("items", normalized)
            json.put("movies", normalized)
        }

        val detail = json.optJSONObject("item") ?: json.optJSONObject("movie") ?: run {
            if (archive == 3 && json.optString("id").isNotBlank()) JSONObject(json.toString()) else null
        }
        if (detail != null) {
            val item = normalizeArchiveItem(detail, archive)
            val downloads = json.optJSONArray("downloads")
                ?: item.optJSONArray("downloads")
                ?: item.optJSONArray("links")
                ?: item.optJSONObject("play")?.optJSONArray("links")
                ?: json.optJSONObject("play")?.optJSONArray("links")
                ?: JSONArray()
            val normalizedLinks = JSONArray()
            for (i in 0 until downloads.length()) {
                val link = downloads.optJSONObject(i) ?: continue
                val copy = JSONObject(link.toString())
                if (archive == 3) {
                    when (copy.optString("type").lowercase(Locale.US)) {
                        "dubbed" -> copy.put("type", "dub")
                        "hard-sub" -> copy.put("type", "hardsub")
                        "soft-sub" -> copy.put("type", "softsub")
                    }
                    if (copy.optString("type_fa").isBlank()) {
                        copy.put("type_fa", when (copy.optString("type").lowercase(Locale.US)) {
                            "dub" -> "دوبله"
                            "hardsub" -> "هاردساب"
                            "softsub" -> "سافت‌ساب"
                            "subtitle" -> "زیرنویس"
                            "audio" -> "صوت دوبله"
                            else -> "دانلود"
                        })
                    }
                }
                if (copy.optString("display_label").isBlank()) {
                    val label = listOf(
                        copy.optString("quality"),
                        copy.optString("type_fa"),
                        copy.optString("size")
                    ).filter { it.isNotBlank() }.joinToString(" • ")
                    copy.put("display_label", label.ifBlank { copy.optString("label").ifBlank { ui("نسخه پخش") } })
                }
                if (item.optString("type").equals("movie", true)) {
                    copy.remove("season")
                    copy.remove("episode")
                }
                if (!copy.has("is_direct")) copy.put("is_direct", true)
                normalizedLinks.put(copy)
            }
            listOf("related", "related_movies").forEach { key ->
                val sourceRelated = item.optJSONArray(key) ?: json.optJSONArray(key)
                if (sourceRelated != null) {
                    val normalizedRelated = JSONArray()
                    for (i in 0 until sourceRelated.length()) {
                        sourceRelated.optJSONObject(i)?.let { normalizedRelated.put(normalizeArchiveItem(it, archive)) }
                    }
                    item.put(key, normalizedRelated)
                    if (key == "related") json.put("related", normalizedRelated)
                }
            }
            item.put("downloads", normalizedLinks)
            item.put("links", normalizedLinks)
            item.put("play", JSONObject().put("links", normalizedLinks))
            if (item.optString("long_description").isBlank()) item.put("long_description", item.optString("description"))
            json.put("item", item)
            json.put("movie", item)
        }
        return json
    }

    private fun fetchArchive(url: String, archive: Int, cb: (Boolean, JSONObject?, String?) -> Unit) {
        val safe = sanitizeArchive(archive)
        if (!archiveRawEnabled(safe)) {
            cb(false, null, t("این آرشیو از پنل مدیریت غیرفعال شده است", "This archive is disabled"))
            return
        }

        fun attempt(targetUrl: String, number: Int) {
            fetch(targetUrl) { ok, json, err ->
                if (ok && json != null) {
                    updateArchiveHealth(safe, true)
                    cb(true, normalizeArchiveResponse(json, safe), null)
                    return@fetch
                }
                if (number == 0) {
                    val separator = if (targetUrl.contains('?')) "&" else "?"
                    val retryUrl = "$targetUrl${separator}_bm_retry=${System.currentTimeMillis()}"
                    uiHandler.postDelayed({ attempt(retryUrl, 1) }, 260L)
                } else {
                    val message = err ?: t("خطای موقت ارتباطی", "Temporary connection error")
                    updateArchiveHealth(safe, false, message)
                    cb(false, null, message)
                }
            }
        }
        attempt(url, 0)
    }

    private fun archiveSegment(archive: Int, iconRes: Int, onSelected: ((Int) -> Unit)? = null): View {
        val p = UiPreferences.palette(this)
        val active = selectedArchive == archive
        return LinearLayout(this).apply {
            tag = "bm_archive_segment_$archive"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            // PASS 3.2: use the exact same archive selector language as Categories.
            // Active = compact accent glass, inactive = transparent inside the shared charcoal shell.
            background = if (active) blueGradient(dp(19)) else rounded(Color.TRANSPARENT, dp(19), Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 19, 1.04f, 0f)
            setPadding(dp(11), 0, dp(11), 0)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (active) p.onPrimary else p.muted)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = archiveLabel(archive)
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(7) })
            addView(TextView(this@MainActivity).apply {
                text = archiveLabel(archive)
                setTextColor(if (active) p.onPrimary else p.text)
                textSize = if (isTvLike()) 15f else 13.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            alpha = if (archiveRawEnabled(archive)) 1f else 0.42f
            setOnClickListener {
                val safe = sanitizeArchive(archive)
                if (!archiveEnabled(safe)) {
                    Toast.makeText(this@MainActivity, t("این آرشیو از پنل مدیریت غیرفعال شده است", "This archive is disabled by admin"), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                val changed = selectedArchive != safe
                selectedArchive = safe
                appPrefs().edit().putInt("selected_archive", safe).apply()
                if (safe == 3) prefetchArchive3SearchOptions()
                if (onSelected != null) {
                    onSelected(safe)
                } else if (changed) {
                    navigationHistory.clear()
                    showHome()
                }
            }
        }
    }

    private fun archiveSwitchBar(onSelected: ((Int) -> Unit)? = null): View {
        return LinearLayout(this).apply {
            tag = "bm_archive_switch_bar"
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            // Same container used by Categories: one charcoal glass rail across Home/TV/Search.
            background = bankGlassDrawable(24, 236, 70, true)
            setPadding(dp(5), dp(5), dp(5), dp(5))
            elevation = dp(4).toFloat()

            val visibleArchives = listOf(1, 2, 3).filter { archiveVisible(it) }
            visibleArchives.forEachIndexed { index, archive ->
                val icon = when (archive) {
                    2 -> R.drawable.ic_archive_globe
                    3 -> R.drawable.ic_archive_spark
                    else -> R.drawable.ic_archive_database
                }
                addView(archiveSegment(archive, icon, onSelected), LinearLayout.LayoutParams(0, dp(50), 1f).apply {
                    if (index > 0) marginStart = dp(2)
                    if (index < visibleArchives.lastIndex) marginEnd = dp(2)
                })
            }
        }
    }

    private fun playlistSummary(playlist: Int): String {
        return when (sanitizeArchive(playlist)) {
            2 -> t(
                "آرشیو ۲ مستقیماً از دیتابیس سایت خوانده می‌شود و لینک‌های دانلود همان‌طور که در دیتابیس ثبت شده‌اند استفاده می‌شوند.",
                "Archive 2 is read directly from the site database and uses download URLs exactly as stored."
            )
            3 -> t(
                "آرشیو ۳ سرور مستقل خود را دارد و ممکن است بعضی عنوان‌ها فقط در همین آرشیو یا فقط در آرشیوهای دیگر موجود باشند.",
                "Archive 3 includes movies, series, animation and anime with advanced search and precise link types."
            )
            else -> t(
                "آرشیو ۱ سرور مستقل خود را دارد و معمولاً تازه‌ترین فیلم‌ها و سریال‌ها ابتدا اینجا قرار می‌گیرند.",
                "Archive 1 is Bankmovie's main, frequently updated database. New titles usually appear here first."
            )
        }
    }


    private fun playlistGuideCard(compact: Boolean = false): View {
        val p = UiPreferences.palette(this)

        if (compact) {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(11), dp(6), dp(11), dp(6))
                background = bankGlassDrawable(15, 224, 58, false)
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 15, 1.02f, 0f)
                setOnClickListener { showPlaylistGuide() }

                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_info_archive)
                    setColorFilter(p.primary)
                }, LinearLayout.LayoutParams(dp(21), dp(21)).apply {
                    marginStart = dp(8)
                })

                addView(TextView(this@MainActivity).apply {
                    text = t(
                        "راهنمای آرشیوها  •  هر آرشیو سرور جدا دارد",
                        "Archive guide  •  Each archive has a separate database"
                    )
                    setTextColor(p.muted)
                    textSize = 10.8f
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(0, dp(32), 1f))

                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_chevron_left)
                    setColorFilter(p.primary)
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(22), dp(32)))
            }
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(
                p.panel,
                dp(18),
                Color.argb(
                    105,
                    Color.red(p.primary),
                    Color.green(p.primary),
                    Color.blue(p.primary)
                )
            )
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 18, 1.025f, 0f)
            setOnClickListener { showPlaylistGuide() }

            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_info_archive)
                setColorFilter(p.primary)
            }, LinearLayout.LayoutParams(dp(28), dp(28)).apply {
                marginStart = dp(10)
            })

            val labels = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            labels.addView(TextView(this@MainActivity).apply {
                text = t("راهنمای استفاده از آرشیوها", "Archive guide")
                setTextColor(p.text)
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            labels.addView(TextView(this@MainActivity).apply {
                text = playlistSummary(selectedArchive)
                setTextColor(p.muted)
                textSize = 11f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                setPadding(0, dp(3), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_chevron_left)
                setColorFilter(p.primary)
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }, LinearLayout.LayoutParams(dp(26), dp(36)))
        }
    }

    private fun showPlaylistGuide() = showHelpCenter()

    private fun showHelpCenter() {
        pushCurrentScreenForBack()
        currentScreen = "help"
        rememberCurrentScreen { showHelpCenter() }
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.VISIBLE

        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(108))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(10), dp(14), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(t("راهنما و سوالات متداول", "Help center & FAQ")), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        fun infoCard(title: String, body: String, icon: Int, accent: Int = p.primary): View {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(13), dp(12), dp(13), dp(12))
                background = rounded(p.panel, dp(21), Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)))
                addView(FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.argb(32, Color.red(accent), Color.green(accent), Color.blue(accent)), dp(14), Color.argb(82, Color.red(accent), Color.green(accent), Color.blue(accent)))
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(icon)
                        setColorFilter(accent)
                        setPadding(dp(9), dp(9), dp(9), dp(9))
                    }, FrameLayout.LayoutParams(-1, -1))
                }, LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginEnd = dp(12) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.RIGHT
                    addView(TextView(this@MainActivity).apply {
                        text = title
                        setTextColor(p.text)
                        textSize = 14.2f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = body
                        setTextColor(p.muted)
                        textSize = 11.4f
                        gravity = Gravity.RIGHT
                        setLineSpacing(dp(3).toFloat(), 1f)
                        setPadding(0, dp(5), 0, 0)
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }
        }

        fun faqCard(question: String, answer: String): View {
            val body = TextView(this).apply {
                text = answer
                setTextColor(p.muted)
                textSize = 11.5f
                gravity = Gravity.RIGHT
                setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(dp(12), dp(3), dp(12), dp(13))
                visibility = View.GONE
            }
            val arrow = ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_down)
                setColorFilter(p.primary)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bankGlassDrawable(18, 226, 62, false)
                val head = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(13), dp(11), dp(13), dp(11))
                    addView(TextView(this@MainActivity).apply {
                        text = question
                        setTextColor(p.text)
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    addView(arrow, LinearLayout.LayoutParams(dp(30), dp(30)))
                    isClickable = true
                    isFocusable = true
                    applyMobileTouchHalo(this, 18)
                    setOnClickListener {
                        val open = body.visibility != View.VISIBLE
                        animateExpandable(body, open)
                        arrow.animate().rotation(if (open) 180f else 0f).setDuration(180L).start()
                    }
                }
                addView(head, LinearLayout.LayoutParams(-1, -2))
                addView(body, LinearLayout.LayoutParams(-1, -2))
            }
        }

        page.addView(premiumSectionTitle(t("آرشیوها", "Archives")))
        page.addView(infoCard(
            t("سه آرشیو، سه سرور مستقل", "Three independent archives"),
            t("ممکن است یک فیلم فقط در آرشیو ۱ باشد و در آرشیو ۳ نباشد. نتیجه جستجو، لینک‌ها و زمان به‌روزرسانی هر آرشیو متفاوت است؛ هر سه را بررسی کنید.", "A title may exist in one archive but not another. Search results, links and update times differ, so check all three."),
            R.drawable.ic_info_archive
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

        listOf(1, 2, 3).forEach { archive ->
            val description = when (archive) {
                1 -> t("فیلم، سریال، دوبله و کالکشن‌های اصلی؛ معمولاً سریع‌تر به‌روزرسانی می‌شود.", "Primary movies, series, dubbed titles and collections; usually updated sooner.")
                2 -> t("سرور دوم با فهرست مستقل؛ بعضی عنوان‌ها و لینک‌ها فقط اینجا هستند.", "A separate catalog; some titles and links are available only here.")
                else -> t("فیلم، سریال، انیمیشن و انیمه با ساختار مستقل و لینک‌های متفاوت.", "Independent movies, series, animation and anime catalog with different links.")
            }
            page.addView(infoCard(
                "${archiveLabel(archive)}  •  ${archiveHealthText(archive)}",
                description,
                when (archive) { 1 -> R.drawable.ic_archive_database; 2 -> R.drawable.ic_archive_globe; else -> R.drawable.ic_archive_spark },
                archiveHealthColor(archive, p)
            ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        page.addView(premiumSectionTitle(t("زیرنویس و دوبله", "Subtitles & audio")))
        page.addView(infoCard(
            t("هاردساب چیست؟", "What is hardsub?"),
            t("زیرنویس روی خود تصویر چسبیده است؛ خاموش‌کردن، تغییر فونت، رنگ یا اندازه آن ممکن نیست.", "The subtitle is burned into the video and cannot be disabled or restyled."),
            R.drawable.ic_player_cc
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(infoCard(
            t("سافت‌ساب چیست؟", "What is softsub?"),
            t("زیرنویس به‌صورت ترک جداست؛ می‌توانید آن را روشن یا خاموش کنید و فونت، رنگ، اندازه و پس‌زمینه را تغییر دهید.", "The subtitle is a separate track that can be enabled, disabled and customized."),
            R.drawable.ic_setup_subtitle
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(infoCard(
            t("دوبله فارسی", "Persian dub"),
            t("در بعضی نسخه‌ها صدای فارسی ترک جداگانه است. داخل پلیر از بخش صدا، ترک مناسب را انتخاب کنید.", "Some releases contain a separate Persian audio track. Select it from the player's audio menu."),
            R.drawable.ic_player_audio
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        page.addView(premiumSectionTitle(t("اتصال و بارگذاری", "Connection & loading")))
        page.addView(infoCard(
            t("اطلاعات بالا نمی‌آید؟", "Content is not loading?"),
            t("یک‌بار حالت پرواز را روشن و خاموش کنید، برنامه را کامل ببندید و دوباره باز کنید. اگر حل نشد Clear data انجام دهید. ممکن است اختلال از سرور یا اینترنت باشد؛ وضعیت را در کانال تلگرام بررسی کنید.", "Toggle airplane mode, fully close and reopen the app, then clear app data if needed. The server or internet may be temporarily unavailable; check Telegram for updates."),
            R.drawable.ic_info_globe,
            Color.rgb(255, 180, 45)
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(12) })

        page.addView(premiumSectionTitle(t("سوالات متداول", "Frequently asked questions")))
        val faqs = listOf(
            t("چرا یک فیلم در یک آرشیو هست ولی در دیگری نیست؟", "Why is a title missing from one archive?") to t("هر آرشیو دیتابیس و سرور جدا دارد. نام فارسی و انگلیسی فیلم را در هر سه آرشیو جستجو کنید.", "Each archive has a separate database. Search both Persian and English titles in all three."),
            t("چرا لینک پخش یا دانلود باز نمی‌شود؟", "Why does a play or download link fail?") to t("نسخه دیگری از همان کیفیت یا آرشیو دیگری را امتحان کنید. بعضی میزبان‌ها موقتاً محدود یا غیرفعال می‌شوند.", "Try another quality, mirror or archive. Some hosts may be temporarily limited."),
            t("چرا فونت زیرنویس تغییر نمی‌کند؟", "Why does the subtitle font not change?") to t("احتمالاً نسخه هاردساب است. تغییر فونت فقط روی زیرنویس سافت‌ساب و ترک‌های جدا اعمال می‌شود.", "It is probably hardsub. Font changes apply only to soft subtitle tracks."),
            t("چرا حساب وارد نمی‌شود؟", "Why can’t I sign in?") to t("نام کاربری یا ایمیل و رمز را دوباره بررسی کنید. ساعت گوشی روی حالت خودکار باشد و VPN یا اینترنت دیگری را هم امتحان کنید.", "Check your username/email and password, enable automatic date and time, and try another network if needed."),
            t("لایک و دیس‌لایک دیدگاه چگونه کار می‌کند؟", "How do comment votes work?") to t("باید وارد حساب باشید. با لمس دوباره همان رأی حذف می‌شود و با انتخاب گزینه دیگر رأی تغییر می‌کند.", "You must be signed in. Tapping the same vote removes it; tapping the other one switches it."),
            t("فایل دانلودشده کجاست؟", "Where are downloaded files?") to t("از صفحه دانلودها مسیر ذخیره، وضعیت، سرعت و فایل‌های کامل‌شده را ببینید. در اندرویدهای جدید ممکن است دسترسی پوشه محدود باشد.", "Open Downloads to see the save path, progress, speed and completed files. New Android versions may restrict folder access.")
        )
        faqs.forEach { (q, a) ->
            page.addView(faqCard(q, a), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        }
        BankmovieFonts.applyToTree(this, page)
        applyTvFocusToClickableTree(page)
    }

    private fun renderRemoteHomeSection(page: LinearLayout, archive: Int, keyRaw: String) {
        val key = keyRaw.trim().lowercase(Locale.US)
        when (sanitizeArchive(archive)) {
            1 -> when (key) {
                "updated_movies" -> addRail(page, "فیلم‌های بروز شده", 1, "updated_movies", false)
                "updated_series" -> addRail(page, "سریال‌های بروز شده", 1, "updated_series", false)
                "korean_series" -> addSearchRail(page, "سریال‌های کره‌ای", "سریال کره ای", "series", 1)
                "dubbed" -> addRail(page, "دوبله فارسی", 1, "dubbed", false)
                "chinese_series" -> addRail(page, "سریال‌های چینی", 1, "chinese_series", false)
                "top_2026" -> addSearchRail(page, "برترین‌های 2026", "2026", "all", 1)
                "anime" -> addRail(page, "انیمه", 1, "anime", false)
                "turkish" -> addRail(page, "ترکی", 1, "turkish", false)
                "collections" -> addCollectionsRail(page)
            }
            2 -> when (key) {
                "updated_movies" -> addRail(page, "اکران 2025 و 2026", 2, "updated_movies", false)
                "updated_series" -> addRail(page, "سریال‌های آپدیت‌شده", 2, "updated_series", false)
                "dubbed" -> addRail(page, "دوبله فارسی", 2, "dubbed", false)
                "animation" -> addRail(page, "انیمیشن", 2, "anime", false)
                "action" -> addRail(page, "اکشن", 2, "genre_movie_action", false)
                "drama" -> addRail(page, "درام", 2, "genre_movie_drama", false)
            }
            3 -> when (key) {
                "new_movies", "updated_movies" -> addRail(page, "جدیدترین فیلم‌ها", 3, "new_movies", false)
                "new_series", "updated_series" -> addRail(page, "جدیدترین سریال‌ها", 3, "new_series", false)
                "updated_animations", "animation" -> addRail(page, "انیمیشن‌های به‌روزشده", 3, "updated_animations", false)
                "updated_anime", "anime" -> addRail(page, "انیمه‌های به‌روزشده", 3, "updated_anime", false)
                "dubbed_movies", "dubbed" -> addRail(page, "فیلم‌های دوبله", 3, "dubbed_movies", false)
                "subtitled_movies" -> addRail(page, "فیلم‌های زیرنویس‌دار", 3, "subtitled_movies", false)
                "dubbed_series" -> addRail(page, "سریال‌های دوبله", 3, "dubbed_series", false)
                "subtitled_series" -> addRail(page, "سریال‌های زیرنویس‌دار", 3, "subtitled_series", false)
                "mini_series" -> addRail(page, "مینی‌سریال‌ها", 3, "mini_series", false)
                "korean_series" -> addRail(page, "سریال‌های کره‌ای", 3, "korean_series", false)
                "turkish_series" -> addRail(page, "سریال‌های ترکی", 3, "turkish_series", false)
                "collection", "collections" -> addCollectionsRail(page)
            }
        }
    }


    private fun showHome() {
        if (!restoringNavigation) navigationHistory.clear()
        currentScreen = "home"
        rememberCurrentScreen { showHome() }
        buildBottomNav()
        clear()
        isMainHomePage = true
        if (::bottomNav.isInitialized) {
            bottomNav.visibility = View.VISIBLE
            bottomNav.translationY = 0f
            bottomNav.alpha = 1f
        }

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(if (tv) 96 else 120))
            if (tv) {
                isSmoothScrollingEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                isFocusable = false
                isFocusableInTouchMode = false
                descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            }
        }

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(12), dp(if (tv) 24 else 34))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        val sliderView = siteSlider(bootJson?.optJSONArray("sliders") ?: JSONArray())
        page.addView(sliderView)

        if (tv) {
            // TV controls are a separate themed surface below the hero. They must
            // never be drawn on top of the slider artwork.
            val palette = UiPreferences.palette(this)
            val controlsSection = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(palette.background)
                setPadding(dp(18), dp(14), dp(18), dp(4))
            }

            if (anyArchiveVisible()) {
                val archiveBar = archiveSwitchBar()
                controlsSection.addView(archiveBar, LinearLayout.LayoutParams(-1, dp(62)).apply {
                    bottomMargin = dp(10)
                })

            }

            page.addView(controlsSection, LinearLayout.LayoutParams(-1, -2).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = dp(4)
            })
        } else {
            if (anyArchiveVisible()) {
                val archiveBar = archiveSwitchBar()
                page.addView(archiveBar, LinearLayout.LayoutParams(-1, dp(62)).apply {
                    topMargin = dp(5)
                    bottomMargin = dp(5)
                })
            }
        }

        val defaultSections = when (selectedArchive) {
            2 -> listOf("updated_movies","updated_series","dubbed","animation","action","drama","collections")
            3 -> listOf("new_movies","new_series","updated_animations","updated_anime","dubbed_movies","subtitled_movies","collections")
            else -> listOf("updated_movies","updated_series","korean_series","dubbed","chinese_series","top_2026","anime","turkish","collections")
        }
        val remoteSections = when (selectedArchive) {
            2 -> remoteHomeSectionsArchive2
            3 -> remoteHomeSectionsArchive3
            else -> remoteHomeSectionsArchive1
        }
        val sectionsToRender = if (tv) defaultSections else if (remoteSections.isNotEmpty()) remoteSections else defaultSections
        if (archiveEnabled(selectedArchive)) {
            val contentSections = sectionsToRender.filterNot {
                it.equals("collections", true) || it.equals("collection", true)
            }
            var collectionsInserted = false
            contentSections.forEach { section ->
                renderRemoteHomeSection(page, selectedArchive, section)
                val normalized = section.lowercase(Locale.US).replace('-', '_')
                if (!collectionsInserted && normalized in setOf("updated_series", "new_series", "series_updated")) {
                    addCollectionsRail(page)
                    collectionsInserted = true
                }
            }
            if (!collectionsInserted) addCollectionsRail(page)
        } else {
            page.addView(
                emptyStateBox(
                    t("آرشیوها موقتاً غیرفعال‌اند", "Archives are temporarily disabled"),
                    t("وضعیت آرشیوها از پنل مدیریت قابل تغییر است.", "Archive availability can be changed from the admin panel.")
                ),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18); bottomMargin = dp(18) }
            )
        }

        // Weekly schedule must be above the Telegram channel on the Android home.
        // Keep both at the end of the content, matching the requested mobile order.
        addWeeklyScheduleSection(page, bootJson?.optJSONObject("weekly_schedule"))
        page.addView(telegramJoinButton(), LinearLayout.LayoutParams(-1, dp(54)).apply {
            topMargin = dp(12)
            bottomMargin = dp(12)
        })

        if (tv) {
            // Only initialize the home screen once at the top. No focus change is allowed
            // to smooth-scroll the page afterwards.
            page.post {
                scroll.scrollTo(0, 0)
                applyTvFocusToClickableTree(page)
                val watch = page.findViewWithTag<View>("bm_tv_slider_primary")
                val archive1 = page.findViewWithTag<View>("bm_archive_segment_1")
                val archive2 = page.findViewWithTag<View>("bm_archive_segment_2")
                val archive3 = page.findViewWithTag<View>("bm_archive_segment_3")
                val firstQuickTab = page.findViewWithTag<View>("bm_home_quick_tab_0")
                if (watch != null) {
                    if (watch.id == View.NO_ID) watch.id = View.generateViewId()
                    val preferredArchive = when (selectedArchive) { 2 -> archive2; 3 -> archive3; else -> archive1 }
                    preferredArchive?.let {
                        if (it.id == View.NO_ID) it.id = View.generateViewId()
                        watch.nextFocusDownId = it.id
                        it.nextFocusUpId = watch.id
                    }

                    watch.requestFocus()
                }
            }
        } else {
            BankmovieFonts.applyToTree(this, page)
        }
    }

    private fun openTelegramChannel() {
        openExternal(AppConfig.TELEGRAM_URL, "org.telegram.messenger")
    }

        private fun fancySpinnerText(textValue: String, subValue: String = ""): LinearLayout {
        val localizedTitle = ui(textValue)
        val searchLoader = localizedTitle.contains("جستجو", ignoreCase = true) ||
            localizedTitle.contains("search", ignoreCase = true)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(20), dp(18), dp(20))
            if (searchLoader) {
                addView(
                    ModernSearchLoaderView(this@MainActivity, "Searching"),
                    LinearLayout.LayoutParams(-2, dp(48)).apply { bottomMargin = dp(8) }
                )
            } else {
                addView(
                    PremiumLoaderView(this@MainActivity),
                    LinearLayout.LayoutParams(dp(58), dp(58)).apply { bottomMargin = dp(10) }
                )
                addView(TextView(this@MainActivity).apply {
                    text = localizedTitle
                    setTextColor(white)
                    textSize = 14.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                })
            }
            if (subValue.isNotBlank()) addView(TextView(this@MainActivity).apply {
                text = ui(subValue)
                setTextColor(muted)
                textSize = 11.7f
                gravity = Gravity.CENTER
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(if (searchLoader) 2 else 6), 0, 0)
            })
            BankmovieFonts.applyToTree(this@MainActivity, this)
        }
    }

    private fun friendlyError(raw: String?): String {
        return t(
            "ارتباط با سرور برقرار نشد. ابتدا یک‌بار حالت پرواز را روشن و خاموش کنید، برنامه را کامل ببندید و دوباره وارد شوید. اگر مشکل حل نشد، یک‌بار داده‌های برنامه (Clear data) را پاک کنید. ممکن است اختلال از سمت سرور باشد؛ برای اطلاع‌رسانی‌ها در کانال تلگرام بانک مووی عضو باشید.",
            "Could not connect to the server. Toggle airplane mode once, fully close the app and reopen it. If the issue remains, clear the app data once. The server may also be temporarily unavailable; follow the Bankmovie Telegram channel for status updates."
        )
    }

    private fun errorView(message: String): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            minimumWidth = (resources.displayMetrics.widthPixels - dp(48)).coerceAtLeast(dp(280))
            background = rounded(p.panel, dp(22), Color.argb(92, 255, 170, 45))
            setPadding(dp(16), dp(16), dp(16), dp(15))
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                addView(FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.argb(34, 255, 170, 45), dp(999), Color.argb(100, 255, 170, 45))
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_info_globe)
                        setColorFilter(Color.rgb(255, 184, 52))
                        setPadding(dp(10), dp(10), dp(10), dp(10))
                    }, FrameLayout.LayoutParams(-1, -1))
                }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(12) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.RIGHT
                    addView(TextView(this@MainActivity).apply {
                        text = t("این بخش فعلاً بارگذاری نشد", "This section did not load")
                        setTextColor(p.text)
                        textSize = 14f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = t("ممکن است اینترنت یا همان آرشیو موقتاً اختلال داشته باشد.", "Your connection or this archive may be temporarily unavailable.")
                        setTextColor(p.muted)
                        textSize = 11.2f
                        gravity = Gravity.RIGHT
                        setPadding(0, dp(4), 0, 0)
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
            addView(TextView(this@MainActivity).apply {
                text = friendlyError(message)
                setTextColor(p.muted)
                textSize = 11.2f
                gravity = Gravity.RIGHT
                setLineSpacing(dp(3).toFloat(), 1f)
                maxLines = 5
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-1, -2))
            val actions = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
            }
            actions.addView(TextView(this@MainActivity).apply {
                text = t("راهنما", "Help")
                setTextColor(p.primary)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(25, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)), dp(15), Color.argb(90, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
                applyMobileTouchHalo(this, 15)
                setOnClickListener { showHelpCenter() }
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
            actions.addView(TextView(this@MainActivity).apply {
                text = t("کانال تلگرام", "Telegram")
                setTextColor(p.onPrimary)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(p.primary, dp(15), p.primary2)
                applyMobileTouchHalo(this, 15)
                setOnClickListener { openTelegramChannel() }
            }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
            addView(actions, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(13) })
            BankmovieFonts.applyToTree(this@MainActivity, this)
        }
    }

    private fun railErrorCard(message: String, retry: () -> Unit): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            val width = (resources.displayMetrics.widthPixels - dp(44)).coerceAtLeast(dp(280))
            layoutParams = ViewGroup.LayoutParams(width, dp(116))
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(p.panel, dp(21), Color.argb(92, 255, 170, 45))
            addView(FrameLayout(this@MainActivity).apply {
                background = rounded(Color.argb(34, 255, 170, 45), dp(999), Color.argb(95, 255, 170, 45))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_info_globe)
                    setColorFilter(Color.rgb(255, 184, 52))
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                }, FrameLayout.LayoutParams(-1, -1))
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(12) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                addView(TextView(this@MainActivity).apply {
                    text = t("این ردیف بارگذاری نشد", "This row did not load")
                    setTextColor(p.text)
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                addView(TextView(this@MainActivity).apply {
                    text = message.ifBlank { t("اختلال موقت ارتباطی", "Temporary connection issue") }
                    setTextColor(p.muted)
                    textSize = 10.7f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setPadding(0, dp(3), 0, dp(7))
                })
                val buttons = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.RIGHT
                }
                buttons.addView(TextView(this@MainActivity).apply {
                    text = t("تلاش دوباره", "Retry")
                    setTextColor(p.onPrimary)
                    textSize = 11.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = rounded(p.primary, dp(13), p.primary2)
                    applyMobileTouchHalo(this, 13)
                    setOnClickListener { retry() }
                }, LinearLayout.LayoutParams(dp(102), dp(34)).apply { marginStart = dp(7) })
                buttons.addView(TextView(this@MainActivity).apply {
                    text = t("راهنما", "Help")
                    setTextColor(p.primary)
                    textSize = 11.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = rounded(Color.TRANSPARENT, dp(13), Color.argb(85, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)))
                    setOnClickListener { showHelpCenter() }
                }, LinearLayout.LayoutParams(dp(72), dp(34)))
                addView(buttons, LinearLayout.LayoutParams(-1, dp(34)))
            }, LinearLayout.LayoutParams(0, -1, 1f))
        }
    }

    private fun emptyStateBox(title: String, sub: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(9, 16, 29), dp(22), Color.argb(90, 95, 120, 160))
            setPadding(dp(18), dp(30), dp(18), dp(30))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.bankmovie_logo_transparent)
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
            }, LinearLayout.LayoutParams(dp(126), dp(54)).apply { bottomMargin = dp(14) })
            addView(TextView(this@MainActivity).apply { text = ui(title); setTextColor(white); textSize = 17f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
            addView(TextView(this@MainActivity).apply {
                text = if (title.contains("خطا")) friendlyError(sub) else ui(sub)
                setTextColor(muted)
                textSize = 12.2f
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            })
            if (title.contains("خطا")) {
                addView(TextView(this@MainActivity).apply {
                    text = ui("بارگذاری دوباره")
                    setTextColor(white)
                    textSize = 13.5f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = blueGradient(dp(18))
                    setPadding(dp(20), 0, dp(20), 0)
                    applyTvFocusHalo(this, 18, 1.04f, 0f)
                    setOnClickListener { recreate() }
                }, LinearLayout.LayoutParams(-2, dp(42)).apply { topMargin = dp(16) })
            }
        }
    }

    private fun commentEmptyStateBox(title: String, sub: String): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bankGlassDrawable(22, 236, 70, true)
            setPadding(dp(18), dp(28), dp(18), dp(28))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_comment_messenger)
                setColorFilter(p.primary)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { bottomMargin = dp(12) })
            addView(TextView(this@MainActivity).apply {
                text = ui(title)
                setTextColor(p.text)
                textSize = 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            addView(TextView(this@MainActivity).apply {
                text = if (title.contains("خطا")) friendlyError(sub) else ui(sub)
                setTextColor(p.muted)
                textSize = 12.2f
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            })
        }
    }

        private fun telegramJoinButton(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(20, 162, 229), Color.rgb(34, 143, 222))).apply { cornerRadius = dp(18).toFloat() }
            setPadding(dp(16), dp(10), dp(16), dp(10))
            minimumHeight = dp(54)
            isClickable = true
            isFocusable = true
            setOnClickListener { openTelegramChannel() }
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_telegram_plane); alpha = 0.98f; scaleType = ImageView.ScaleType.FIT_CENTER }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = ui("کانال تلگرام @" + AppConfig.TELEGRAM_HANDLE)
                setTextColor(white)
                textSize = 13.4f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun homeSearchHeader(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(14), 0, dp(12))
        }
        row.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, LinearLayout.LayoutParams(dp(104), dp(44)).apply { marginStart = dp(9) })

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 20, 34), dp(23), Color.argb(135, 235, 35, 45))
            setPadding(dp(13), 0, dp(13), 0)
            setOnClickListener { showSearch() }
        }
        pill.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_search_clean)
            setColorFilter(Color.rgb(160, 170, 188))
        }, LinearLayout.LayoutParams(dp(23), dp(23)).apply { marginStart = dp(9) })
        pill.addView(TextView(this).apply {
            text = "جستجو..."
            setTextColor(Color.rgb(160, 170, 188))
            textSize = 14.5f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 1
        }, LinearLayout.LayoutParams(0, -1, 1f))
        row.addView(pill, LinearLayout.LayoutParams(0, dp(48), 1f))
        return row
    }

    private fun searchResultRow(item: JSONObject): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(Color.TRANSPARENT, dp(0), Color.TRANSPARENT)
            applyTvFocusHalo(this, 18, 1.03f, 0f)
            isFocusable = true
            isFocusableInTouchMode = false
            setOnClickListener { showDetail(item) }
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.rgb(20, 30, 45), dp(8), Color.TRANSPARENT)
            clipToOutline = true
        }
        loadImage(item.optString("poster").ifBlank { item.optString("image") }, poster)
        row.addView(poster, LinearLayout.LayoutParams(dp(58), dp(82)).apply { marginStart = dp(14) })
        row.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = 15.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -1, 1f))
        return row
    }

    private fun tvSiteSlider(items: JSONArray): View {
        val count = items.length().coerceAtMost(8)
        val currentIndex = intArrayOf(0)

        val hero = FrameLayout(this).apply {
            // Keep every slider layer inside the 360dp hero. This prevents the
            // artwork from bleeding behind the archive controls below it.
            clipChildren = true
            clipToPadding = true
            setBackgroundColor(Color.BLACK)
            layoutParams = LinearLayout.LayoutParams(-1, dp(360)).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = 0
            }
        }

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
        }
        hero.addView(image, FrameLayout.LayoutParams(-1, -1))

        // One uniform black scrim over the entire artwork. The previous gradient
        // made one half of the slider look darker than the other.
        hero.addView(View(this).apply {
            setBackgroundColor(Color.argb(92, 0, 0, 0))
        }, FrameLayout.LayoutParams(-1, -1))

        val header = FrameLayout(this).apply { setPadding(dp(18), dp(10), dp(18), 0) }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, FrameLayout.LayoutParams(dp(106), dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(4)
        })
        header.addView(
            svgIconButton(R.drawable.ic_search_clean) { showSearch() },
            FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(4) }
        )
        hero.addView(header, FrameLayout.LayoutParams(-1, dp(64), Gravity.TOP))

        // Title and description remain on the far right, above the bottom actions.
        val contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(56), dp(28), dp(92))
        }
        val genre = TextView(this).apply {
            setTextColor(white)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(105, 0, 0, 0), dp(15), Color.argb(75, 255, 255, 255))
            setPadding(dp(11), dp(5), dp(11), dp(5))
        }
        val title = TextView(this).apply {
            setTextColor(white)
            textSize = 28f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(7f, 0f, 2f, Color.argb(190, 0, 0, 0))
        }
        val desc = TextView(this).apply {
            setTextColor(Color.argb(228, 238, 240, 246))
            textSize = 12.5f
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
        }
        contentBox.addView(genre, LinearLayout.LayoutParams(-2, dp(32)).apply {
            gravity = Gravity.RIGHT
            bottomMargin = dp(7)
        })
        contentBox.addView(title, LinearLayout.LayoutParams(-1, -2))
        contentBox.addView(desc, LinearLayout.LayoutParams(-1, -2))
        hero.addView(
            contentBox,
            FrameLayout.LayoutParams((resources.displayMetrics.widthPixels * 0.48f).toInt(), -1, Gravity.RIGHT or Gravity.BOTTOM)
        )

        val watchButton = iconActionButton(t("تماشا کنید", "Watch Now"), R.drawable.ic_play_fill, true) {
            val item = items.optJSONObject(currentIndex[0]) ?: return@iconActionButton
            seedFromSlider(item)?.let { showDetail(it) } ?: item.optString("link_abs").ifBlank { item.optString("link") }.takeIf { it.isNotBlank() }?.let { openExternal(it, null) }
        }.apply { tag = "bm_tv_slider_primary" }

        val ratingPill = TextView(this).apply {
            setTextColor(Color.rgb(35, 28, 6))
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(242, 190, 24), dp(18), Color.argb(135, 255, 224, 100))
            setPadding(dp(14), 0, dp(14), 0)
        }

        val bottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            addView(watchButton, LinearLayout.LayoutParams(dp(220), dp(54)).apply { marginStart = dp(10) })
            addView(ratingPill, LinearLayout.LayoutParams(-2, dp(40)))
        }
        hero.addView(bottomActions, FrameLayout.LayoutParams(-2, dp(58), Gravity.BOTTOM or Gravity.RIGHT).apply {
            rightMargin = dp(28)
            bottomMargin = dp(18)
        })

        val dots = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        hero.addView(dots, FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM or Gravity.LEFT).apply {
            leftMargin = dp(28)
            bottomMargin = dp(28)
        })

        fun sliderBackdrop(item: JSONObject): String {
            return item.optString("backdrop")
                .ifBlank { item.optString("background") }
                .ifBlank { item.optString("backdrop_url") }
                .ifBlank { item.optString("image") }
                .ifBlank { item.optString("poster") }
        }

        fun bind(idx: Int, animate: Boolean) {
            val item = items.optJSONObject(idx) ?: return
            image.scaleType = ImageView.ScaleType.CENTER_CROP
            loadImage(sliderBackdrop(item), image)

            val genreText = item.optJSONArray("genres")?.let { arr ->
                (0 until arr.length()).mapNotNull { i ->
                    arr.optString(i).takeIf { value -> value.isNotBlank() }
                }.joinToString(" • ")
            }.orEmpty().ifBlank { item.optString("type") }
            val year = item.optString("year").trim()
            val compactMeta = listOf(genreText, year).filter { it.isNotBlank() }.joinToString(" • ")
            genre.visibility = if (compactMeta.isBlank()) View.GONE else View.VISIBLE
            genre.text = compactMeta
            title.text = item.optString("title_fa").ifBlank { item.optString("title") }

            val sliderDesc = item.optString("subtitle_fa")
                .ifBlank { item.optString("subtitle") }
                .ifBlank { item.optString("description") }
                .trim()
            desc.text = sliderDesc
            desc.visibility = if (sliderDesc.isBlank() || sliderDesc.equals("null", true)) View.GONE else View.VISIBLE

            val rating = item.optDouble("rating", 0.0)
            ratingPill.visibility = if (rating > 0) View.VISIBLE else View.GONE
            ratingPill.text = if (rating > 0) "IMDb ${String.format(Locale.US, "%.1f", rating)}" else ""

            dots.removeAllViews()
            repeat(count.coerceAtLeast(1)) { i ->
                dots.addView(View(this).apply {
                    background = rounded(
                        if (i == idx) Color.WHITE else Color.argb(100, 255, 255, 255),
                        dp(4),
                        Color.TRANSPARENT
                    )
                }, LinearLayout.LayoutParams(if (i == idx) dp(26) else dp(8), dp(8)).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                })
            }

            if (animate) {
                contentBox.alpha = 0f
                contentBox.translationX = dp(12).toFloat()
                contentBox.animate().alpha(1f).translationX(0f).setDuration(180).start()
            }
        }

        if (count > 0) {
            bind(0, false)
            val auto = object : Runnable {
                override fun run() {
                    if (count > 1 && hero.isShown && currentScreen == "home") {
                        currentIndex[0] = (currentIndex[0] + 1) % count
                        bind(currentIndex[0], true)
                        hero.postDelayed(this, 4200L)
                    }
                }
            }
            hero.postDelayed(auto, 4200L)
        }

        BankmovieFonts.applyToTree(this, hero)
        return hero
    }

    private fun applyBottomCornerClip(view: View, radiusDp: Int) {
        val radius = dp(radiusDp).toFloat()
        view.outlineProvider = object : android.view.ViewOutlineProvider() {
            override fun getOutline(v: View, outline: android.graphics.Outline) {
                val w = v.width.toFloat()
                val h = v.height.toFloat()
                if (w <= 0f || h <= 0f) return
                val r = radius.coerceAtMost(minOf(w, h) / 2f)
                val path = android.graphics.Path().apply {
                    moveTo(0f, 0f)
                    lineTo(w, 0f)
                    lineTo(w, h - r)
                    quadTo(w, h, w - r, h)
                    lineTo(r, h)
                    quadTo(0f, h, 0f, h - r)
                    close()
                }
                @Suppress("DEPRECATION")
                outline.setConvexPath(path)
            }
        }
        view.clipToOutline = true
    }

    private fun siteSlider(items: JSONArray): View {
        if (isTvLike()) return tvSiteSlider(items)

        // PASS 4.8: clean cinematic Home hero. Mobile follows a poster-first
        // composition: artwork -> title -> indicators -> compact archive context.
        // There is deliberately no large CTA on the artwork; tapping the artwork
        // or its title opens the detail page directly.
        val count = items.length().coerceAtMost(8)
        val p = UiPreferences.palette(this)
        val frame = FrameLayout(this).apply {
            tag = "bm_home_cinematic_slider"
            layoutParams = LinearLayout.LayoutParams(-1, dp(505)).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = 0
            }
            elevation = dp(10).toFloat()
            clipToPadding = false
            clipChildren = false
        }
        applyBottomCornerClip(frame, 18)

        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.BLACK)
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))

        val previewImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0f
            visibility = View.GONE
            setBackgroundColor(Color.BLACK)
        }
        frame.addView(previewImage, FrameLayout.LayoutParams(-1, -1))

        // Keep the face/artwork readable while closing the hero into the app's
        // charcoal background, similar to a native streaming landing page.
        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(4, 0, 0, 0),
                    Color.argb(10, 0, 0, 0),
                    Color.argb(24, 0, 0, 0),
                    Color.argb(92, 0, 0, 0),
                    Color.argb(214, 0, 0, 0),
                    Color.argb(250, 2, 4, 8)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        // A very soft edge vignette gives white titles enough contrast without
        // putting another card on the artwork.
        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(Color.argb(48, 0, 0, 0), Color.TRANSPARENT, Color.argb(30, 0, 0, 0))
            )
        }, FrameLayout.LayoutParams(-1, -1))

        val header = FrameLayout(this).apply {
            setPadding(dp(18), dp(12), dp(18), 0)
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_logo_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
        }, FrameLayout.LayoutParams(dp(108), dp(42), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(8)
        })
        header.addView(
            svgIconButton(R.drawable.ic_search_clean) { showSearch() },
            FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(6) }
        )
        header.addView(
            hamburgerHeaderButton { icon -> showAppDrawer(icon) },
            FrameLayout.LayoutParams(dp(46), dp(46), Gravity.TOP or Gravity.RIGHT).apply { topMargin = dp(6) }
        )
        frame.addView(header, FrameLayout.LayoutParams(-1, dp(78), Gravity.TOP))

        val title = TextView(this).apply {
            tag = "bm_home_slider_title"
            setTextColor(Color.WHITE)
            textSize = 24.5f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(8f, 0f, 2f, Color.argb(220, 0, 0, 0))
            setPadding(dp(20), 0, dp(20), 0)
        }
        frame.addView(title, FrameLayout.LayoutParams(-1, dp(64), Gravity.BOTTOM).apply {
            leftMargin = dp(14)
            rightMargin = dp(14)
            bottomMargin = dp(48)
        })

        val dots = LinearLayout(this).apply {
            tag = "bm_home_slider_dots"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        frame.addView(dots, FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(22)
        })

        val currentIndex = intArrayOf(0)

        fun sliderImage(item: JSONObject): String {
            return item.optString("image")
                .ifBlank { item.optString("backdrop") }
                .ifBlank { item.optString("poster") }
        }

        fun openCurrent() {
            val item = items.optJSONObject(currentIndex[0]) ?: return
            val seed = seedFromSlider(item)
            if (seed != null) {
                showDetail(seed)
            } else {
                item.optString("link_abs").ifBlank { item.optString("link") }
                    .takeIf { it.isNotBlank() }
                    ?.let { openExternal(it, null) }
            }
        }

        fun bind(idx: Int, animate: Boolean) {
            val item = items.optJSONObject(idx) ?: return
            if (animate && !lowEndDevice) {
                image.animate().cancel()
                image.alpha = 0.48f
                image.scaleX = 1.018f
                image.scaleY = 1.018f
            }
            loadImage(sliderImage(item), image)
            if (animate && !lowEndDevice) {
                image.animate()
                    .alpha(1f)
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(260L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .start()
            }

            title.text = item.optString("title_fa")
                .ifBlank { item.optString("title") }
                .ifBlank { t("بدون عنوان", "Untitled") }

            dots.removeAllViews()
            repeat(count.coerceAtLeast(1)) { i ->
                val selected = i == idx
                dots.addView(View(this).apply {
                    background = rounded(
                        if (selected) p.primary else Color.argb(122, 255, 255, 255),
                        dp(999),
                        Color.TRANSPARENT
                    )
                }, LinearLayout.LayoutParams(if (selected) dp(28) else dp(8), dp(8)).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                })
            }

            if (animate) {
                title.animate().cancel()
                title.alpha = 0f
                title.translationY = dp(8).toFloat()
                title.animate().alpha(1f).translationY(0f).setDuration(180L).start()
                dots.alpha = 0.55f
                dots.animate().alpha(1f).setDuration(180L).start()
            }
        }

        if (count > 0) {
            bind(0, false)

            val auto = object : Runnable {
                override fun run() {
                    if (count > 1 && frame.isAttachedToWindow && currentScreen == "home") {
                        currentIndex[0] = (currentIndex[0] + 1) % count
                        bind(currentIndex[0], true)
                        frame.postDelayed(this, 3900L)
                    }
                }
            }

            fun scheduleAuto(delay: Long = 3900L) {
                frame.removeCallbacks(auto)
                if (count > 1) frame.postDelayed(auto, delay)
            }

            fun clearDragVisuals(animated: Boolean) {
                val duration = if (animated) 135L else 0L
                image.animate().cancel()
                previewImage.animate().cancel()
                title.animate().cancel()
                dots.animate().cancel()
                if (animated) {
                    image.animate().translationX(0f).alpha(1f).scaleX(1f).scaleY(1f)
                        .setDuration(duration).setInterpolator(android.view.animation.DecelerateInterpolator()).start()
                    previewImage.animate().alpha(0f).setDuration(90L).withEndAction {
                        previewImage.visibility = View.GONE
                        previewImage.translationX = 0f
                        previewImage.scaleX = 1f
                        previewImage.scaleY = 1f
                    }.start()
                    title.animate().translationX(0f).alpha(1f).setDuration(duration).start()
                    dots.animate().translationX(0f).alpha(1f).setDuration(duration).start()
                } else {
                    image.translationX = 0f
                    image.alpha = 1f
                    image.scaleX = 1f
                    image.scaleY = 1f
                    previewImage.visibility = View.GONE
                    previewImage.translationX = 0f
                    previewImage.alpha = 0f
                    previewImage.scaleX = 1f
                    previewImage.scaleY = 1f
                    title.translationX = 0f
                    title.alpha = 1f
                    dots.translationX = 0f
                    dots.alpha = 1f
                }
            }

            fun finishDrag(target: Int, direction: Int) {
                val width = frame.width.coerceAtLeast(resources.displayMetrics.widthPixels).toFloat()
                image.animate().cancel()
                previewImage.animate().cancel()
                title.animate().cancel()
                image.animate()
                    .translationX((-direction * width * 0.22f))
                    .alpha(0f)
                    .scaleX(0.975f).scaleY(0.975f)
                    .setDuration(125L)
                    .setInterpolator(android.view.animation.AccelerateDecelerateInterpolator())
                    .start()
                previewImage.animate()
                    .translationX(0f)
                    .alpha(1f)
                    .scaleX(1f).scaleY(1f)
                    .setDuration(125L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .withEndAction {
                        currentIndex[0] = target
                        previewImage.drawable?.let { image.setImageDrawable(it) }
                        clearDragVisuals(false)
                        bind(currentIndex[0], false)
                        title.alpha = 0f
                        title.translationY = dp(7).toFloat()
                        title.animate().alpha(1f).translationY(0f).setDuration(145L).start()
                        scheduleAuto()
                    }.start()
            }

            scheduleAuto()

            var downX = 0f
            var downY = 0f
            var dragTarget = -1
            var dragDirection = 0
            var dragged = false
            frame.setOnTouchListener { _, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = ev.x
                        downY = ev.y
                        dragTarget = -1
                        dragDirection = 0
                        dragged = false
                        frame.removeCallbacks(auto)
                        image.animate().cancel()
                        previewImage.animate().cancel()
                        title.animate().cancel()
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (count <= 1) return@setOnTouchListener true
                        val dx = ev.x - downX
                        val dy = ev.y - downY
                        // Do not steal a vertical Home scroll. Horizontal intent must
                        // be clear before the hero starts dragging.
                        if (!dragged && kotlin.math.abs(dy) > kotlin.math.abs(dx) && kotlin.math.abs(dy) > dp(7)) {
                            frame.parent?.requestDisallowInterceptTouchEvent(false)
                            return@setOnTouchListener false
                        }
                        if (kotlin.math.abs(dx) > dp(7) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.15f) {
                            dragged = true
                            frame.parent?.requestDisallowInterceptTouchEvent(true)
                            val direction = if (dx < 0f) 1 else -1
                            val target = if (direction > 0) {
                                (currentIndex[0] + 1) % count
                            } else {
                                (currentIndex[0] - 1 + count) % count
                            }
                            val width = frame.width.coerceAtLeast(resources.displayMetrics.widthPixels).toFloat()
                            if (target != dragTarget || direction != dragDirection) {
                                dragTarget = target
                                dragDirection = direction
                                val next = items.optJSONObject(target)
                                previewImage.visibility = View.VISIBLE
                                previewImage.alpha = 0f
                                previewImage.translationX = direction * width * 0.38f
                                previewImage.scaleX = 1.025f
                                previewImage.scaleY = 1.025f
                                if (next != null) loadImage(sliderImage(next), previewImage)
                            }
                            val progress = (kotlin.math.abs(dx) / (width * 0.68f)).coerceIn(0f, 1f)
                            image.translationX = dx * 0.30f
                            image.alpha = 1f - (0.52f * progress)
                            image.scaleX = 1f - (0.025f * progress)
                            image.scaleY = image.scaleX
                            previewImage.translationX = direction * width * 0.38f + dx * 0.38f
                            previewImage.alpha = (0.18f + 0.82f * progress).coerceAtMost(1f)
                            previewImage.scaleX = 1.025f - (0.025f * progress)
                            previewImage.scaleY = previewImage.scaleX
                            title.translationX = dx * 0.08f
                            title.alpha = 1f - (0.34f * progress)
                            dots.translationX = dx * 0.035f
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        frame.parent?.requestDisallowInterceptTouchEvent(false)
                        clearDragVisuals(true)
                        scheduleAuto(2200L)
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        frame.parent?.requestDisallowInterceptTouchEvent(false)
                        val dx = ev.x - downX
                        val width = frame.width.coerceAtLeast(resources.displayMetrics.widthPixels).toFloat()
                        val progress = kotlin.math.abs(dx) / width
                        if (dragged && dragTarget >= 0 && (progress >= 0.14f || kotlin.math.abs(dx) >= dp(46))) {
                            finishDrag(dragTarget, dragDirection)
                        } else if (dragged) {
                            clearDragVisuals(true)
                            scheduleAuto(2200L)
                        } else {
                            clearDragVisuals(true)
                            scheduleAuto()
                            openCurrent()
                        }
                        true
                    }
                    else -> true
                }
            }
        } else {
            // Keep the hero surface stable if the server temporarily has no slides.
            image.setBackgroundColor(p.background2)
            title.text = "Bankmovie"
            dots.visibility = View.GONE
        }
        return frame
    }

    private fun addCollectionsRail(page: LinearLayout) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader("کالکشن‌ها", more = { showCollections() }))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        fetch("$apiBase?action=collections&page=1&limit=12") { ok, json, err ->
            runOnUiThread {
                if (!ok || json == null) {
                    row.addView(errorView(err ?: "خطا در دریافت کالکشن‌ها"))
                    return@runOnUiThread
                }
                val items = json.optJSONArray("items") ?: JSONArray()
                for (i in 0 until minOf(items.length(), 12)) items.optJSONObject(i)?.let {
                    val card = collectionCard(it)
                    if (!isTvLike() && !lowEndDevice) {
                        card.alpha = 0f
                        card.translationY = dp(10).toFloat()
                        card.animate()
                            .alpha(1f)
                            .translationY(0f)
                            .setStartDelay((i % 5) * 24L)
                            .setDuration(180L)
                            .setInterpolator(android.view.animation.DecelerateInterpolator())
                            .start()
                    }
                    row.addView(card)
                }
                positionRailAtNewest(scroller, row)
            }
        }
    }

    private fun weeklyArchiveLabel(item: JSONObject): String {
        return when (item.optString("source_archive").lowercase(Locale.US)) {
            "archive1" -> t("آرشیو ۱", "Archive 1")
            "archive2", "database", "db" -> t("دیتابیس", "Database")
            "archive3" -> t("آرشیو ۳", "Archive 3")
            "archive4" -> t("آرشیو ۴", "Archive 4")
            else -> t("سایت", "Website")
        }
    }

    private fun openWeeklyScheduleItem(item: JSONObject) {
        val source = item.optString("source_archive").lowercase(Locale.US)
        val archive = when (source) {
            "archive1" -> 1
            "archive2", "database", "db" -> 2
            "archive3" -> 3
            else -> 0
        }
        val id = item.optString("target_id").ifBlank { item.optString("source_id") }.trim()
        val type = item.optString("media_type").ifBlank { "series" }
        val target = item.optString("target_url").trim()
        if (archive in 1..3 && id.isNotBlank()) {
            showDetail(JSONObject().apply {
                put("id", id)
                put("archive", archive)
                put("type", type)
                put("title", item.optString("title"))
                put("title_fa", item.optString("title_fa"))
                put("poster", item.optString("poster_url"))
                put("image", item.optString("poster_url"))
                put("year", item.optString("release_year"))
                if (archive == 2) {
                    put("source", "website_db")
                    id.toIntOrNull()?.takeIf { it > 0 }?.let { dbId ->
                        put("db_id", dbId)
                        put("movie_id", dbId)
                    }
                }
                if (target.isNotBlank()) put("source_url", if (target.startsWith("http", true)) target else activeDomain.trimEnd('/') + "/" + target.trimStart('/'))
            })
            return
        }
        if (target.isNotBlank()) {
            openExternal(if (target.startsWith("http", true)) target else activeDomain.trimEnd('/') + "/" + target.trimStart('/'), null)
        }
    }

    private fun weeklyScheduleCard(item: JSONObject): View {
        val tv = isTvLike()
        val width = if (tv) dp(190) else dp(154)
        val posterHeight = if (tv) dp(268) else dp(216)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface(), dp(20), alphaLine(70))
            setPadding(dp(7), dp(7), dp(7), dp(10))
            isClickable = true
            isFocusable = true
            elevation = dp(3).toFloat()
            applyTvFocusHalo(this, 20, 1.045f, dp(2).toFloat())
            applyMobileTouchHalo(this, 20)
            setOnClickListener { openWeeklyScheduleItem(item) }
        }
        val posterFrame = FrameLayout(this).apply {
            clipToOutline = true
            background = rounded(Color.rgb(10, 16, 27), dp(16), Color.TRANSPARENT)
        }
        val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        posterFrame.addView(poster, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster_url"), poster)
        posterFrame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(18, 0, 0, 0), Color.argb(210, 0, 0, 0))
            )
        }, FrameLayout.LayoutParams(-1, -1))
        posterFrame.addView(TextView(this).apply {
            text = weeklyArchiveLabel(item)
            setTextColor(Color.WHITE)
            textSize = 9.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(180, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(12), Color.argb(150, 255, 255, 255))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply { topMargin = dp(8); rightMargin = dp(8) })
        val episode = item.optString("episode_label").trim()
        if (episode.isNotBlank()) {
            posterFrame.addView(TextView(this).apply {
                text = episode
                setTextColor(Color.WHITE)
                textSize = 10.2f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                background = rounded(Color.argb(205, 4, 8, 15), dp(12), Color.argb(72, 255, 255, 255))
                setPadding(dp(8), dp(5), dp(8), dp(5))
            }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { leftMargin = dp(7); rightMargin = dp(7); bottomMargin = dp(7) })
        }
        card.addView(posterFrame, LinearLayout.LayoutParams(-1, posterHeight))
        card.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = if (tv) 13f else 12.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(3), dp(8), dp(3), 0)
        }, LinearLayout.LayoutParams(-1, -2))
        val meta = listOf(item.optString("release_year"), if (item.optString("media_type").contains("series", true)) t("سریال", "Series") else t("فیلم", "Movie"))
            .filter { it.isNotBlank() }.joinToString(" • ")
        if (meta.isNotBlank()) card.addView(TextView(this).apply {
            text = meta
            setTextColor(alphaSecondaryText())
            textSize = 9.8f
            gravity = Gravity.RIGHT
            setPadding(dp(3), dp(4), dp(3), 0)
        })
        card.layoutParams = LinearLayout.LayoutParams(width, -2).apply { marginStart = dp(6); marginEnd = dp(6) }
        return card
    }

    private fun weeklyScheduleCompactCell(item: JSONObject): View {
        val palette = UiPreferences.palette(this)
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), dp(4), dp(5), dp(4))
            background = rounded(Color.argb(if (palette.light) 70 else 12, 255, 255, 255), dp(15), Color.argb(18, 255, 255, 255))
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 15)
            setOnClickListener { openWeeklyScheduleItem(item) }
        }
        val imageBox = FrameLayout(this).apply {
            clipToOutline = true
            background = rounded(Color.rgb(15, 20, 30), dp(13), Color.TRANSPARENT)
        }
        val poster = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        imageBox.addView(poster, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster_url"), poster)
        cell.addView(imageBox, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(8) })

        val textBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        textBox.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(alphaPrimary())
            textSize = 11.7f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        val meta = listOf(item.optString("episode_label"), item.optString("release_year"))
            .filter { it.isNotBlank() }.joinToString(" • ")
        if (meta.isNotBlank()) textBox.addView(TextView(this).apply {
            text = meta
            setTextColor(alphaSecondaryText())
            textSize = 9.1f
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(3), 0, 0)
        })
        cell.addView(textBox, LinearLayout.LayoutParams(0, dp(54), 1f))
        return cell
    }

    private fun addWeeklyScheduleSection(page: LinearLayout, weekly: JSONObject?) {
        if (weekly == null || !weekly.optBoolean("enabled", false)) return
        val days = weekly.optJSONArray("days") ?: return
        if (days.length() == 0) return

        val available = mutableListOf<JSONObject>()
        for (i in 0 until days.length()) {
            val day = days.optJSONObject(i) ?: continue
            val items = day.optJSONArray("items") ?: JSONArray()
            if (items.length() > 0 || weekly.optBoolean("show_empty_days", false)) available.add(day)
        }
        if (available.isEmpty()) return

        val defaultKey = weekly.optString("default_day_key")
        var selectedIndex = available.indexOfFirst { it.optString("key") == defaultKey }.let { if (it >= 0) it else 0 }
        val tv = isTvLike()
        val section = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface2(), dp(if (tv) 24 else 22), alphaLine(if (tv) 72 else 58))
            setPadding(dp(if (tv) 16 else 10), dp(if (tv) 16 else 15), dp(if (tv) 16 else 10), dp(if (tv) 16 else 12))
        }

        section.addView(TextView(this).apply {
            text = if (tv) {
                if (isFa()) weekly.optString("title_fa").ifBlank { "پخش هفتگی" } else weekly.optString("title_en").ifBlank { "Weekly Schedule" }
            } else {
                t("جدول پخش هفتگی", "Weekly Schedule")
            }
            setTextColor(alphaPrimary())
            textSize = if (tv) 23f else 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))

        if (tv) {
            val subtitle = if (isFa()) weekly.optString("subtitle_fa") else weekly.optString("subtitle_en")
            if (subtitle.isNotBlank()) section.addView(TextView(this).apply {
                text = subtitle
                setTextColor(alphaSecondaryText())
                textSize = 10.8f
                gravity = Gravity.CENTER
                setPadding(0, dp(4), 0, 0)
            })
        }

        val tabsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tabsScroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipToPadding = false
            addView(tabsRow)
        }
        section.addView(tabsScroll, LinearLayout.LayoutParams(-1, dp(if (tv) 50 else 48)).apply {
            topMargin = dp(12)
            bottomMargin = dp(if (tv) 10 else 8)
        })

        val mobileGrid = GridLayout(this).apply {
            columnCount = 2
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        val tvItemsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        val tvItemsScroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(tvItemsRow)
        }
        if (tv) section.addView(tvItemsScroll, LinearLayout.LayoutParams(-1, -2))
        else section.addView(mobileGrid, LinearLayout.LayoutParams(-1, -2))

        fun renderSelected() {
            tabsRow.removeAllViews()
            available.forEachIndexed { index, day ->
                val active = index == selectedIndex
                val label = if (isFa()) day.optString("label_fa").ifBlank { day.optString("key") } else day.optString("label_en").ifBlank { day.optString("key") }
                tabsRow.addView(TextView(this).apply {
                    text = label
                    setTextColor(if (active) Color.WHITE else alphaSecondaryText())
                    textSize = if (tv) 11.5f else 11.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = if (active) {
                        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(231, 29, 139), Color.rgb(183, 55, 225))).apply { cornerRadius = dp(15).toFloat() }
                    } else rounded(alphaSurface(), dp(15), alphaLine(72))
                    setPadding(dp(if (tv) 14 else 12), 0, dp(if (tv) 14 else 12), 0)
                    isClickable = true
                    isFocusable = true
                    applyTvFocusHalo(this, 15, 1.035f, 0f)
                    setOnClickListener { selectedIndex = index; renderSelected() }
                }, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(4); marginEnd = dp(4) })
            }

            val selected = available[selectedIndex]
            val arr = selected.optJSONArray("items") ?: JSONArray()
            if (tv) tvItemsRow.removeAllViews() else mobileGrid.removeAllViews()
            if (arr.length() == 0) {
                val empty = TextView(this).apply {
                    text = t("برای این روز عنوانی ثبت نشده است", "No titles scheduled for this day")
                    setTextColor(alphaSecondaryText())
                    textSize = 11.5f
                    gravity = Gravity.CENTER
                    setPadding(dp(26), dp(26), dp(26), dp(26))
                }
                if (tv) tvItemsRow.addView(empty) else mobileGrid.addView(empty, GridLayout.LayoutParams().apply {
                    width = 0; height = -2; columnSpec = GridLayout.spec(0, 2, 1f)
                })
            } else if (tv) {
                for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { tvItemsRow.addView(weeklyScheduleCard(it)) }
                tvItemsScroll.post { tvItemsScroll.fullScroll(View.FOCUS_RIGHT) }
            } else {
                // The compact two-column layout intentionally mirrors the clean app mockup:
                // tiny poster on the right, readable title, no giant website-style cards.
                val limit = minOf(arr.length(), 8)
                for (i in 0 until limit) {
                    val item = arr.optJSONObject(i) ?: continue
                    mobileGrid.addView(weeklyScheduleCompactCell(item), GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(64)
                        columnSpec = GridLayout.spec(i % 2, 1f)
                        setMargins(dp(3), dp(3), dp(3), dp(3))
                    })
                }
            }
            if (isTvLike()) applyTvFocusToClickableTree(section)
        }
        renderSelected()
        page.addView(section, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8); bottomMargin = dp(18) })
    }

    private fun collectionCard(item: JSONObject, compact: Boolean = false): View {
        val tv = isTvLike()
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { item.optString("name") }
        val subtitle = item.optString("description_fa")
            .ifBlank { item.optString("subtitle_fa") }
            .ifBlank { item.optString("description") }
            .ifBlank { item.optString("subtitle") }
        val cover = canonicalBankmovieAssetUrl(
            item.optString("cover_image")
                .ifBlank { item.optString("poster") }
                .ifBlank { item.optString("image") }
                .ifBlank { item.optString("backdrop") }
        )
        val count = item.optInt("movie_count", item.optInt("count", 0))
        val cardWidth = when {
            tv && compact -> ((resources.displayMetrics.widthPixels - dp(24) - (dp(12) * 5)) / 5)
                .coerceIn(dp(168), dp(230))
            tv -> dp(255)
            compact -> ((resources.displayMetrics.widthPixels - dp(64)) / 2).coerceIn(dp(118), dp(154))
            else -> dp(214)
        }
        val cardHeight = when {
            tv && compact -> (cardWidth * 1.31f).roundToInt().coerceAtLeast(dp(224))
            tv -> dp(332)
            compact -> (cardWidth * 1.38f).roundToInt()
            else -> dp(292)
        }

        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(8, 12, 22), dp(28), Color.argb(95, 155, 119, 255))
            layoutParams = ViewGroup.MarginLayoutParams(cardWidth, cardHeight).apply {
                marginStart = dp(if (compact) 4 else 8)
                marginEnd = dp(if (compact) 4 else 8)
                bottomMargin = dp(14)
            }
            elevation = dp(if (tv) 9 else 7).toFloat()
            clipToOutline = true
            applyTvFocusHalo(this, 28, 1.055f, dp(3).toFloat())
            applyMobileTouchHalo(this, 28)
            setOnClickListener {
                if (!tv && !lowEndDevice) {
                    animate().cancel()
                    animate().scaleX(0.975f).scaleY(0.975f).setDuration(65L).withEndAction {
                        animate().scaleX(1f).scaleY(1f).setDuration(105L).start()
                        showCollectionItems(item.optString("slug"), title)
                    }.start()
                } else {
                    showCollectionItems(item.optString("slug"), title)
                }
            }
        }

        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(8, 12, 22))
        }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(cover, img)

        frame.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(35, 0, 0, 0),
                    Color.argb(10, 0, 0, 0),
                    Color.argb(105, 0, 0, 0),
                    Color.argb(242, 2, 4, 10)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        val typeLabel = item.optString("type_label")
            .ifBlank { item.optString("type_fa") }
            .ifBlank { t("فیلم‌ها", "Movies") }
        frame.addView(TextView(this).apply {
            text = typeLabel
            setTextColor(Color.WHITE)
            textSize = if (compact) 10.2f else 11.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(118, 255, 255, 255), dp(18), Color.argb(90, 255, 255, 255))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            maxLines = 1
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply {
            topMargin = dp(14)
            leftMargin = dp(14)
        })

        if (count > 0) frame.addView(TextView(this).apply {
            text = if (isFa()) "$count فیلم" else "$count titles"
            setTextColor(Color.rgb(211, 159, 255))
            textSize = if (compact) 10.2f else 11.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(125, 72, 30, 105), dp(18), Color.argb(140, 184, 96, 255))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            maxLines = 1
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply {
            topMargin = dp(14)
            rightMargin = dp(14)
        })

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(dp(16), dp(8), dp(16), dp(14))
        }
        info.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = if (compact) 17f else if (tv) 22f else 20f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
            setShadowLayer(9f, 0f, 2f, Color.BLACK)
        }, LinearLayout.LayoutParams(-1, -2))

        if (subtitle.isNotBlank()) info.addView(TextView(this).apply {
            text = subtitle
            setTextColor(Color.argb(218, 238, 240, 247))
            textSize = if (compact) 10.2f else 11.5f
            maxLines = if (compact) 1 else 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
            setPadding(0, dp(5), 0, 0)
        }, LinearLayout.LayoutParams(-1, -2))

        val openRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, 0)
        }
        openRow.addView(TextView(this).apply {
            text = t("باز کردن", "Open")
            setTextColor(Color.rgb(203, 116, 255))
            textSize = if (compact) 12.2f else 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(-2, dp(38)))
        openRow.addView(TextView(this).apply {
            text = if (isFa()) "←" else "→"
            setTextColor(Color.rgb(218, 169, 255))
            textSize = if (compact) 15f else 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(3), 0, dp(3), 0)
        }, LinearLayout.LayoutParams(dp(24), dp(32)).apply { marginStart = dp(5) })
        info.addView(openRow, LinearLayout.LayoutParams(-1, -2))

        frame.addView(info, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        return frame
    }

    private fun boxOfficeLoadingSkeleton(): LinearLayout {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            repeat(6) { index ->
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    background = bankGlassDrawable(20, 226, 62, false)
                    addView(View(this@MainActivity).apply { background = PosterShimmerDrawable(lowEndDevice).also { it.start() } }, LinearLayout.LayoutParams(dp(64), dp(88)))
                    addView(LinearLayout(this@MainActivity).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(12),0,0,0)
                        repeat(3) { line ->
                            addView(View(this@MainActivity).apply { background = PosterShimmerDrawable(lowEndDevice).also { it.start() } }, LinearLayout.LayoutParams(if(line==0) dp(170) else dp(115), dp(if(line==0) 14 else 10)).apply { bottomMargin=dp(9) })
                        }
                    }, LinearLayout.LayoutParams(0,-2,1f))
                }, LinearLayout.LayoutParams(-1, dp(110)).apply { bottomMargin=dp(if(index==5)0 else 8) })
            }
        }
    }

    private fun showBoxOffice() {
        pushCurrentScreenForBack()
        currentScreen = "boxoffice"
        rememberCurrentScreen { showBoxOffice() }
        buildBottomNav(); clear()
        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding=false; setPadding(0,0,0,dp(108)) }
        val page = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(14),dp(10),dp(14),dp(30)) }
        scroll.addView(page); content.addView(scroll); attachSmartHeader(scroll)
        page.addView(listTop(t("باکس آفیس", "Box Office")))
        val hero = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT
            setPadding(dp(16),dp(15),dp(16),dp(15))
            background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(Color.rgb(20,13,37),Color.rgb(7,9,18))).apply {
                cornerRadius=dp(24).toFloat(); setStroke(dp(1),Color.argb(105,181,140,255))
            }
            addView(TextView(this@MainActivity).apply { text="WEEKEND BOX OFFICE"; setTextColor(Color.rgb(181,140,255)); textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT })
            addView(TextView(this@MainActivity).apply { text="جدول فروش هفتگی سینما"; setTextColor(p.text); textSize=23f; typeface=BankmovieFonts.bold(this@MainActivity); gravity=Gravity.RIGHT; setPadding(0,dp(4),0,0) })
            addView(TextView(this@MainActivity).apply { text="پرفروش‌ترین فیلم‌های هفته، رتبه‌بندی گیشه، فروش آخر هفته و مجموع فروش؛ یک‌جا و مرتب."; setTextColor(p.muted); textSize=11f; gravity=Gravity.RIGHT; setPadding(0,dp(5),0,0) })
        }
        page.addView(hero,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(12) })
        val body=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        page.addView(body,LinearLayout.LayoutParams(-1,-2))
        val loading=boxOfficeLoadingSkeleton(); body.addView(loading)

        fetch(activeDomain.trimEnd('/') + "/api_boxoffice.php") { ok, json, err ->
            runOnUiThread {
                if (currentScreen != "boxoffice") return@runOnUiThread
                body.removeAllViews()
                if (!ok || json == null || !json.optBoolean("success", false)) {
                    body.addView(emptyStateBox("باکس آفیس دریافت نشد", json?.optString("message").orEmpty().ifBlank { err ?: "اتصال به داده باکس آفیس برقرار نشد" }))
                    body.addView(commentActionButton("تلاش مجدد") { showBoxOffice() },LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(8) })
                    return@runOnUiThread
                }
                val items=json.optJSONArray("items") ?: JSONArray()
                val stats=json.optJSONObject("stats") ?: JSONObject()
                fun compactUsd(value: Double): String = when {
                    value >= 1_000_000_000.0 -> "$" + String.format(Locale.US, "%.1fB", value / 1_000_000_000.0)
                    value >= 1_000_000.0 -> "$" + String.format(Locale.US, "%.1fM", value / 1_000_000.0)
                    value >= 1_000.0 -> "$" + String.format(Locale.US, "%.1fK", value / 1_000.0)
                    value > 0.0 -> "$" + String.format(Locale.US, "%.0f", value)
                    else -> "—"
                }
                val leaderItem=items.optJSONObject(0)
                val summary=LinearLayout(this).apply {
                    orientation=LinearLayout.HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; gravity=Gravity.CENTER
                    background = bankGlassDrawable(18, 236, 70, true); setPadding(dp(8),dp(8),dp(8),dp(8))
                }
                listOf(
                    (stats.optString("leader_title").ifBlank { leaderItem?.optString("title").orEmpty() }.ifBlank { "—" }) to "صدرنشین هفته",
                    (leaderItem?.optString("weekend").orEmpty().ifBlank { compactUsd(stats.optDouble("leader_value",0.0)) }) to "فروش آخر هفته",
                    compactUsd(stats.optDouble("weekend_total_value",0.0)) to "جمع فروش آخر هفته"
                ).forEach { pair -> summary.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; addView(TextView(this@MainActivity).apply { text=pair.first; setTextColor(p.text); textSize=12f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; maxLines=1; ellipsize=TextUtils.TruncateAt.END }); addView(TextView(this@MainActivity).apply { text=pair.second; setTextColor(p.muted); textSize=9.5f; gravity=Gravity.CENTER }) },LinearLayout.LayoutParams(0,dp(58),1f)) }
                body.addView(summary,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
                for(i in 0 until items.length()) {
                    val item=items.optJSONObject(i) ?: continue
                    val rank=item.optInt("rank",i+1)
                    val poster=item.optString("local_poster").ifBlank { item.optString("image") }
                    val title=item.optString("title_fa").ifBlank { item.optString("title") }
                    val row=LinearLayout(this).apply {
                        orientation=LinearLayout.HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; gravity=Gravity.CENTER_VERTICAL
                        setPadding(dp(10),dp(10),dp(10),dp(10)); background=rounded(if(rank<=3) UiPreferences.blend(p.panel2,Color.rgb(124,58,237),0.10f) else p.panel2,dp(20),if(rank<=3) Color.argb(125,181,140,255) else p.stroke)
                        isClickable=true; isFocusable=true; applyTvFocusHalo(this,20,1.025f,0f); applyMobileTouchHalo(this,20)
                        val image=ImageView(this@MainActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP; background=rounded(Color.rgb(16,20,29),dp(14),Color.TRANSPARENT); clipToOutline=true }
                        addView(image,LinearLayout.LayoutParams(dp(66),dp(94)).apply { marginStart=dp(11) }); loadImage(poster,image)
                        addView(TextView(this@MainActivity).apply { text="#${rank}"; setTextColor(if(rank<=3) Color.rgb(214,180,255) else p.muted); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER },LinearLayout.LayoutParams(dp(48),dp(52)).apply { marginStart=dp(6) })
                        addView(LinearLayout(this@MainActivity).apply {
                            orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT
                            addView(TextView(this@MainActivity).apply { text=title; setTextColor(p.text); textSize=14f; typeface=BankmovieFonts.bold(this@MainActivity); gravity=Gravity.RIGHT; maxLines=2; ellipsize=TextUtils.TruncateAt.END })
                            addView(TextView(this@MainActivity).apply { text="فروش آخر هفته: ${item.optString("weekend").ifBlank { "—" }}"; setTextColor(Color.rgb(181,140,255)); textSize=10.5f; gravity=Gravity.RIGHT; setPadding(0,dp(5),0,0) })
                            addView(TextView(this@MainActivity).apply { text="فروش کل: ${item.optString("gross").ifBlank { "—" }}   •   ${item.optInt("weeks",0)} هفته اکران"; setTextColor(p.muted); textSize=10f; gravity=Gravity.RIGHT; setPadding(0,dp(3),0,0) })
                        },LinearLayout.LayoutParams(0,-2,1f))
                        setOnClickListener {
                            val local=item.optString("local_url")
                            val imdb=item.optString("id")
                            when {
                                local.isNotBlank() -> openExternal(normalizeImageUrl(local), null)
                                imdb.startsWith("tt") -> showDetail(JSONObject().apply { put("archive",2); put("id",imdb); put("imdb_code",imdb); put("type","movie"); put("title",title) })
                            }
                        }
                    }
                    body.addView(row,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
                }
                applyTvFocusToClickableTree(page)
            }
        }
    }

    private fun showCollections() {
        currentScreen = "collections"
        rememberCurrentScreen { showCollections() }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(108))
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        val collectionLoading = movieDetailLoading(JSONObject())
        content.addView(collectionLoading, FrameLayout.LayoutParams(-1, -1))

        page.addView(listTop(t("کالکشن‌ها", "Collections")))
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 5 else 2
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -1 else -2, -2).apply {
            if (!tv) gravity = Gravity.CENTER_HORIZONTAL
        })
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(110) })

        fun loadCollections(p: Int) {
            if (p == 1 && grid.childCount == 0) collectionLoading.visibility = View.VISIBLE
            more.text = t("در حال بارگذاری...", "Loading...")
            more.isEnabled = false
            fetch("$apiBase?action=collections&page=$p&limit=24") { ok, json, err ->
                runOnUiThread {
                    if (p == 1) collectionLoading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        more.text = t("تلاش مجدد", "Retry")
                        Toast.makeText(this, friendlyError(err), Toast.LENGTH_SHORT).show()
                        return@runOnUiThread
                    }
                    val items = json.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until items.length()) items.optJSONObject(i)?.let {
                        val card = collectionCard(it, compact = true)
                        if (!tv && !lowEndDevice) {
                            card.alpha = 0f
                            card.translationY = dp(12).toFloat()
                            card.animate()
                                .alpha(1f)
                                .translationY(0f)
                                .setStartDelay((i % 6) * 22L)
                                .setDuration(175L)
                                .setInterpolator(android.view.animation.DecelerateInterpolator())
                                .start()
                        }
                        if (tv) {
                            grid.addView(card)
                        } else {
                            val screenWidth = resources.displayMetrics.widthPixels
                            val available = (screenWidth - dp(48)).coerceAtLeast(dp(250))
                            val gap = dp(8)
                            val cellWidth = ((available - gap) / 2).coerceIn(dp(118), dp(154))
                            val cellHeight = (cellWidth * 1.38f).roundToInt()
                            grid.addView(card, GridLayout.LayoutParams().apply {
                                width = cellWidth
                                height = cellHeight
                                columnSpec = GridLayout.spec(grid.childCount % 2)
                                setMargins(dp(4), dp(4), dp(4), dp(8))
                            })
                        }
                    }
                    if (json.optBoolean("has_more", false)) {
                        val next = json.optInt("next_page", p + 1)
                        more.visibility = View.VISIBLE
                        more.text = t("مشاهده بیشتر", "Load more")
                        more.setOnClickListener { loadCollections(next) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadCollections(1)
    }

        private fun showCollectionItems(slug: String, title: String) {
        pushCurrentScreenForBack()
        currentScreen = "collections"
        val savedSlug = slug
        val savedTitle = title
        rememberCurrentScreen { showCollectionItems(savedSlug, savedTitle) }
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.VISIBLE
        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply { layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL; setPadding(0, 0, 0, dp(108)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) { gravity = Gravity.LEFT; layoutDirection = View.LAYOUT_DIRECTION_LTR }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        val collectionItemsLoading = movieDetailLoading(JSONObject())
        content.addView(collectionItemsLoading, FrameLayout.LayoutParams(-1, -1))
        page.addView(listTop(title))
        val grid = GridLayout(this).apply { columnCount = if (tv) 8 else 3; layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        val more = moreButton(ui("صفحه بعد")) { }
        page.addView(more)
        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW, tall = true)
        val limit = if (tv) 24 else 24
        fun loadItems(p: Int) {
            if (p == 1 && grid.childCount == 0) collectionItemsLoading.visibility = View.VISIBLE
            more.text = ui("در حال بارگذاری...")
            more.isEnabled = false
            fetch("$apiBase?action=collection&slug=${enc(slug)}&page=$p&limit=$limit") { ok, json, err ->
                runOnUiThread {
                    if (p == 1) collectionItemsLoading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت کالکشن", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = ui("تلاش مجدد")
                        more.setOnClickListener { loadItems(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }
                    val items = json.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until items.length()) items.optJSONObject(i)?.let { grid.addView(posterCard(it, cardW, cardH)) }
                    if (json.optBoolean("has_more", false) || items.length() >= limit) {
                        val next = json.optInt("next_page", p + 1)
                        more.visibility = View.VISIBLE
                        more.text = ui("صفحه بعد")
                        more.setOnClickListener { loadItems(next) }
                    } else more.visibility = View.GONE
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadItems(1)
    }

    private fun addQuickTabs(page: LinearLayout) {
        val hsv = HorizontalBankmovieSmoothScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, dp(2))
        }
        hsv.addView(row)
        val tabs = when (selectedArchive) {
            2 -> listOf(
                Triple("✓ ${t("جدیدترین", "Newest")}", 2, "updated_movies"),
                Triple(ui("اکران 2025 و 2026"), 2, "updated_movies"),
                Triple(ui("سریال‌های آپدیت‌شده"), 2, "updated_series"),
                Triple(t("دوبله", "Dubbed"), 2, "dubbed"),
                Triple(ui("انیمیشن"), 2, "anime"),
                Triple(ui("اکشن"), 2, "genre_movie_action"),
                Triple(t("کالکشن", "Collections"), 2, "collections")
            )
            3 -> listOf(
                Triple("✓ ${t("جدیدترین", "Newest")}", 3, "new_movies"),
                Triple(t("فیلم", "Movies"), 3, "new_movies"),
                Triple(t("سریال", "Series"), 3, "new_series"),
                Triple(ui("انیمیشن"), 3, "updated_animations"),
                Triple(ui("انیمه"), 3, "updated_anime"),
                Triple(t("دوبله", "Dubbed"), 3, "dubbed_movies"),
                Triple(t("کالکشن", "Collections"), 3, "collections")
            )
            else -> listOf(
                Triple("✓ ${t("جدیدترین", "Newest")}", 1, "updated_movies"),
                Triple(t("فیلم", "Movies"), 1, "updated_movies"),
                Triple(t("سریال", "Series"), 1, "updated_series"),
                Triple(t("دوبله", "Dubbed"), 1, "dubbed"),
                Triple(ui("چینی"), 1, "chinese_series"),
                Triple(t("کالکشن", "Collections"), 1, "collections")
            )
        }
        tabs.forEachIndexed { idx, tab ->
            val v = chip(tab.first, idx == 0).apply {
                tag = "bm_home_quick_tab_$idx"
            }
            v.setOnClickListener {
                when (tab.third) {
                    "collections" -> showCollections()
                    else -> showList(tab.first.replace("✓ ", ""), tab.second, tab.third)
                }
            }
            row.addView(v, LinearLayout.LayoutParams(-2, dp(44)).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        page.addView(hsv, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(12) })
    }

    private fun archive2GenreUrl(genre: String, type: String, page: Int, limit: Int = 24): String {
        val safeType = if (type.equals("series", true)) "series" else "movie"
        return "$apiBase?action=search&archive=2&genre=${enc(genre)}&type=${enc(safeType)}&page=$page&limit=$limit"
    }

    private fun showArchive2GenreList(title: String, genre: String, type: String) {
        pushCurrentScreenForBack()
        currentScreen = "list"
        val savedTitle = title
        val savedGenre = genre
        val savedType = type
        rememberCurrentScreen { showArchive2GenreList(savedTitle, savedGenre, savedType) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(110)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(title))

        val grid = GridLayout(this).apply {
            columnCount = if (tv) tvGridColumns() else 3
            alignmentMode = GridLayout.ALIGN_MARGINS
            useDefaultMargins = false
        }
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW)
        val seen = mutableSetOf<String>()
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(100) })

        fun keyOf(item: JSONObject): String = item.optString("id")
            .ifBlank { item.optString("slug") }
            .ifBlank { item.optString("title_fa") + item.optString("poster") }

        fun loadPage(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.isEnabled = false
            fetchArchive(archive2GenreUrl(genre, type, p), 2) { ok, json, err ->
                runOnUiThread {
                    more.isEnabled = true
                    if (!ok || json == null) {
                        more.text = ui("تلاش دوباره")
                        more.setOnClickListener { loadPage(p) }
                        if (grid.childCount == 0) page.addView(errorView(friendlyError(err)))
                        return@runOnUiThread
                    }
                    val arr = json.optJSONArray("items") ?: JSONArray()
                    if (p == 1) grid.removeAllViews()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }
                    val next = json.optInt("next_page", p + 1)
                    val hasMore = json.optBoolean("has_more", false) || arr.length() >= 24
                    if (hasMore && added > 0) {
                        more.visibility = View.VISIBLE
                        more.text = ui("مشاهده بیشتر")
                        more.setOnClickListener { loadPage(if (next > p) next else p + 1) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        repeat(if (tv) 16 else 9) { grid.addView(skeletonPosterCard(cardW, cardH)) }
        loadPage(1)
    }

    private fun addArchive2GenreRail(
        page: LinearLayout,
        title: String,
        genre: String,
        type: String,
        excludeId: String,
        showMore: Boolean = true
    ) {
        if (genre.isBlank()) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        box.addView(sectionHeader(title, { showArchive2GenreList(title, genre, type) }, showMore))
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        repeat(6) { row.addView(skeletonPosterCard(dp(122), dp(223))) }

        fetchArchive(archive2GenreUrl(genre, type, 1, 18), 2) { ok, json, err ->
            runOnUiThread {
                row.removeAllViews()
                if (!ok || json == null) {
                    row.addView(errorView(friendlyError(err)))
                    return@runOnUiThread
                }
                val arr = json.optJSONArray("items") ?: JSONArray()
                var added = 0
                for (i in 0 until arr.length()) {
                    val candidate = arr.optJSONObject(i) ?: continue
                    val candidateId = candidate.optString("id").ifBlank { candidate.optString("slug") }
                    if (candidateId.isNotBlank() && candidateId == excludeId) continue
                    row.addView(posterCard(candidate, dp(134), dp(244)))
                    added++
                    if (added >= 14) break
                }
                if (added == 0) box.visibility = View.GONE
                positionRailAtNewest(scroller, row)
            }
        }
    }

    private fun addSearchRail(page: LinearLayout, title: String, query: String, typeFilter: String = "all", archive: Int = selectedArchive, showMore: Boolean = true) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        val header = sectionHeader(title, { showKeywordList(title, query, typeFilter, archive) }, showMore)
        box.addView(header)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        repeat(6) { row.addView(skeletonPosterCard(dp(122), dp(223))) }

        fetchArchive(archiveSearchUrl(archive, query, 1, 24, typeFilter, true), archive) { ok, json, err ->
            runOnUiThread {
                row.removeAllViews()
                if (!ok || json == null) {
                    row.addView(errorView(err ?: "خطا در دریافت اطلاعات"))
                    return@runOnUiThread
                }
                val items = json.optJSONArray("items") ?: JSONArray()
                var added = 0
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i) ?: continue
                    if (!searchAcceptsType(item, typeFilter)) continue
                    row.addView(posterCard(item, dp(134), dp(244)))
                    added++
                    if (added >= 12) break
                }
                if (added == 0) row.addView(emptyStateBox("چیزی پیدا نشد", title))
                positionRailAtNewest(scroller, row)
                wireTvSectionDown(header, row.getChildAtOrNull(0))
            }
        }
    }

    private fun showKeywordList(title: String, query: String, typeFilter: String = "all", archive: Int = selectedArchive) {
        currentScreen = "archive$archive"
        val savedTitle = title
        val savedQuery = query
        val savedTypeFilter = typeFilter
        val savedArchive = archive
        rememberCurrentScreen { showKeywordList(savedTitle, savedQuery, savedTypeFilter, savedArchive) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(if (tv) 82 else 100))
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(title))
        val loading = contentSkeletonRows(5)
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        val seen = mutableSetOf<String>()
        val perPage = if (tv) 24 else 24
        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW)

        page.addView(loading, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "${ui("مشاهده نتایج بیشتر")}  ${seen.size}" else ui("مشاهده نتایج بیشتر")
        }

        fun loadPage(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false
            fetchArchive(archiveSearchUrl(archive, query, p, perPage, typeFilter, true), archive) { ok, json, err ->
                runOnUiThread {
                    loading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت اطلاعات", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = ui("تلاش دوباره")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (!searchAcceptsType(item, typeFilter)) continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    if (grid.childCount == 0) {
                        page.addView(emptyStateBox("چیزی پیدا نشد", "بعداً دوباره امتحان کن"), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        more.visibility = View.GONE
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val next = json.optInt("next_page", p + 1)
                    val total = json.optInt("total", json.optInt("total_count", json.optInt("all_count", 0)))
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p || (total > 0 && seen.size < total)
                    val guessedMore = arr.length() >= perPage
                    val canLoadMore = serverHasMore || guessedMore

                    if (canLoadMore && added > 0) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(if (next > p) next else p + 1) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

    private fun addRail(page: LinearLayout, title: String, archive: Int, section: String, progressCards: Boolean) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        val header = sectionHeader(title, more = { showList(title, archive, section) })
        box.addView(header)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)

        fun showSkeletons() {
            row.removeAllViews()
            repeat(6) { row.addView(skeletonPosterCard(dp(122), dp(223))) }
            positionRailAtNewest(scroller, row)
        }

        fun loadRail() {
            showSkeletons()
            fetchArchive(archiveSectionUrl(archive, section, 1, 24), archive) { ok, json, err ->
                runOnUiThread {
                    row.removeAllViews()
                    if (!ok || json == null) {
                        row.addView(railErrorCard(err ?: t("خطا در دریافت اطلاعات", "Could not load data")) { loadRail() })
                        positionRailAtNewest(scroller, row)
                        return@runOnUiThread
                    }
                    val items = json.optJSONArray("items") ?: JSONArray()
                    for (i in 0 until minOf(items.length(), if (progressCards) 8 else 12)) {
                        val item = items.optJSONObject(i) ?: continue
                        row.addView(if (progressCards) continueCard(item) else posterCard(item, dp(134), dp(244)))
                    }
                    if (row.childCount == 0) {
                        row.addView(railErrorCard(t("فعلاً عنوانی برای این بخش ثبت نشده است", "No titles are available in this section yet")) { loadRail() })
                    }
                    positionRailAtNewest(scroller, row, focusFirstOnTv = progressCards)
                    wireTvSectionDown(header, row.getChildAtOrNull(0))
                }
            }
        }
        loadRail()
    }

    private fun paperSlider(items: List<JSONObject>): View {
        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(5, 10, 18), dp(28), Color.TRANSPARENT)
        }

        fun backCard(item: JSONObject?, w: Int, h: Int, gravity: Int, margin: Int, alphaValue: Float) {
            val card = heroMiniCard(item, false).apply { alpha = alphaValue }
            val lp = FrameLayout.LayoutParams(dp(w), dp(h), gravity).apply {
                leftMargin = dp(margin)
                rightMargin = dp(margin)
                topMargin = dp(22)
            }
            frame.addView(card, lp)
        }

        backCard(items.getOrNull(2), 120, 162, Gravity.LEFT or Gravity.TOP, 12, 0.36f)
        backCard(items.getOrNull(1), 138, 176, Gravity.LEFT or Gravity.TOP, 42, 0.55f)
        backCard(items.getOrNull(4), 120, 162, Gravity.RIGHT or Gravity.TOP, 12, 0.36f)
        backCard(items.getOrNull(3), 138, 176, Gravity.RIGHT or Gravity.TOP, 42, 0.55f)

        frame.addView(heroMiniCard(items.getOrNull(0), true), FrameLayout.LayoutParams(dp(190), dp(210), Gravity.CENTER))

        val dots = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        repeat(6) { i ->
            dots.addView(View(this).apply {
                background = rounded(if (i == 0) blue else Color.rgb(80, 92, 112), dp(4), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(if (i == 0) dp(18) else dp(7), dp(7)).apply {
                marginStart = dp(4)
                marginEnd = dp(4)
            })
        }
        frame.addView(dots, FrameLayout.LayoutParams(-2, dp(18), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(4) })
        return frame
    }

    private fun heroMiniCard(item: JSONObject?, main: Boolean): View {
        val frame = FrameLayout(this).apply {
            background = rounded(Color.rgb(10, 18, 32), dp(if (main) 18 else 16), Color.rgb(72, 89, 112))
            setOnClickListener { item?.let { showDetail(it) } }
        }

        val img = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = if (main) 0.90f else 0.72f
        }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        item?.optString("poster")?.let { loadImage(it, img) }

        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(230, 0, 0, 0)))
        }, FrameLayout.LayoutParams(-1, -1))

        if (main) {
            val info = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setPadding(dp(10), dp(8), dp(10), dp(13))
            }
            info.addView(TextView(this).apply {
                text = item?.optString("title_fa")?.ifBlank { item.optString("title") } ?: "BANK MOVIE"
                setTextColor(white)
                textSize = 23f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                letterSpacing = 0.06f
            })
            info.addView(TextView(this).apply {
                text = if (item != null) "Bankmovie • ${item.optString("year")}" else t("آرشیو ۱ به‌صورت پیش‌فرض", "Archive 1 is selected by default")
                setTextColor(muted)
                textSize = 11f
                gravity = Gravity.CENTER
                maxLines = 1
            })
            info.addView(TextView(this).apply {
                text = "مشاهده"
                setTextColor(white)
                textSize = 12f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = blueGradient(dp(13))
                setPadding(dp(18), dp(4), dp(18), dp(4))
            }, LinearLayout.LayoutParams(dp(104), dp(30)).apply { topMargin = dp(8) })
            frame.addView(info, FrameLayout.LayoutParams(-1, -1))
        }

        return frame
    }

    private fun continueCard(item: JSONObject): View {
        val frame = FrameLayout(this).apply {
            background = bankGlassDrawable(15, 224, 58, false)
            layoutParams = ViewGroup.MarginLayoutParams(dp(104), dp(148)).apply {
                marginStart = dp(6)
                marginEnd = dp(6)
            }
            setOnClickListener { showDetail(item) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.BLACK); adjustViewBounds = false }
        frame.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, img)

        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(230, 0, 0, 0)))
        }, FrameLayout.LayoutParams(-1, -1))

        frame.addView(TextView(this).apply {
            text = "▶"
            setTextColor(white)
            textSize = 19f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(135, 0, 0, 0), dp(20), Color.argb(180, 255, 255, 255))
        }, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.RIGHT
            setPadding(dp(7), dp(7), dp(7), dp(8))
        }
        info.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = item.optString("update_note").ifBlank { item.optString("type") }
            setTextColor(muted)
            textSize = 10f
            maxLines = 1
        })
        info.addView(View(this).apply { background = blueGradient(dp(2)) }, LinearLayout.LayoutParams(dp(52), dp(3)).apply { topMargin = dp(5) })
        frame.addView(info, FrameLayout.LayoutParams(-1, -1))
        return frame
    }

        private fun moreButton(textValue: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = ui(textValue)
            setTextColor(alphaPrimary())
            textSize = 13.6f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(alphaSurface2(), dp(20), alphaLine(95))
            setPadding(dp(16), 0, dp(16), 0)
            applyTvFocusHalo(this, 22, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun sectionHeader(title: String, more: () -> Unit, showMore: Boolean = true): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(2), dp(8), dp(2), dp(14))
        }
        if (showMore) {
            row.addView(TextView(this).apply {
                tag = "bm_section_more"
                text = ui("مشاهده همه ‹")
                setTextColor(alphaPrimary())
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(alphaSurface2(), dp(18), alphaLine(72))
                setPadding(dp(12), 0, dp(12), 0)
                applyTvFocusHalo(this, 18, 1.04f, 0f)
                setOnClickListener { more() }
            }, LinearLayout.LayoutParams(dp(112), dp(40)).apply { marginEnd = dp(14) })
        }
        row.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, blue)).apply { cornerRadius = dp(2).toFloat() }
        }, LinearLayout.LayoutParams(0, dp(4), 1f).apply { marginEnd = dp(14) })
        row.addView(TextView(this).apply {
            text = ui(title)
            setTextColor(alphaPrimary())
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(-2, dp(46)))
        return row
    }


    private fun ViewGroup.getChildAtOrNull(index: Int): View? = if (index in 0 until childCount) getChildAt(index) else null

    private fun wireTvSectionDown(header: View, firstCard: View?) {
        if (!isTvLike() || firstCard == null) return
        val more = header.findViewWithTag<View>("bm_section_more") ?: return
        if (more.id == View.NO_ID) more.id = View.generateViewId()
        if (firstCard.id == View.NO_ID) firstCard.id = View.generateViewId()
        more.nextFocusDownId = firstCard.id
        firstCard.nextFocusUpId = more.id
        more.setOnKeyListener { _, keyCode, event ->
            if (event.action == android.view.KeyEvent.ACTION_DOWN && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                firstCard.requestFocus()
                true
            } else false
        }
    }

    private fun showList(title: String, archive: Int, section: String) {
        currentScreen = "archive$archive"
        val savedTitle = title
        val savedArchive = archive
        val savedSection = section
        rememberCurrentScreen { showList(savedTitle, savedArchive, savedSection) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply { layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(title))
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        val perPage = if (tv) 24 else 24
        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW)
        val seen = mutableSetOf<String>()

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "مشاهده بیشتر  ${seen.size}" else "مشاهده بیشتر"
        }

        repeat(if (tv) 16 else 9) { grid.addView(skeletonPosterCard(cardW, cardH)) }

        fun loadPage(p: Int) {
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false
            fetchArchive(archiveSectionUrl(archive, section, p, perPage), archive) { ok, json, err ->
                runOnUiThread {
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) page.addView(emptyStateBox("خطا در دریافت اطلاعات", friendlyError(err)), LinearLayout.LayoutParams(-1, -2))
                        more.text = t("تلاش مجدد", "Retry")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    if (p == 1) grid.removeAllViews()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    val next = json.optInt("next_page", p + 1)
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p
                    val guessedMore = arr.length() >= perPage
                    val canLoadMore = serverHasMore || guessedMore

                    if (canLoadMore && added > 0) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(if (next > p) next else p + 1) }
                    } else {
                        more.visibility = View.GONE
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

        private fun listTop(title: String): View {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(14))
            addView(TextView(this@MainActivity).apply {
                text = ui(title)
                setTextColor(white)
                textSize = 24f
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(2), dp(4), dp(2), dp(8))
            })
        }
    }

    private fun archive1GenreCatalog(): List<GenreCategory> = listOf(
        GenreCategory("romance", "عاشقانه", "49167", "Romance"),
        GenreCategory("science", "علمی", "220319", "Science"),
        GenreCategory("fantasy", "فانتزی", "49182", "Fantasy"),
        GenreCategory("sci_fi", "علمی تخیلی", "49162", "Sci-Fi"),
        GenreCategory("comedy", "کمدی", "49159", "Comedy"),
        GenreCategory("supernatural", "قدرت‌های فوق‌العاده", "220441", "Superpowers"),
        GenreCategory("adventure", "ماجراجویی", "49170", "Adventure"),
        GenreCategory("short", "کوتاه", "49238", "Short"),
        GenreCategory("documentary", "مستند", "49342", "Documentary"),
        GenreCategory("school", "مدرسه‌ای", "221019", "School"),
        GenreCategory("music", "موزیک", "49243", "Music"),
        GenreCategory("mystery", "معمایی", "49161", "Mystery"),
        GenreCategory("action", "اکشن", "49166", "Action"),
        GenreCategory("drama", "درام", "49160", "Drama"),
        GenreCategory("crime", "جنایی", "49179", "Crime"),
        GenreCategory("thriller", "هیجان‌انگیز", "49165", "Thriller"),
        GenreCategory("horror", "ترسناک", "49174", "Horror"),
        GenreCategory("family", "خانوادگی", "49199", "Family"),
        GenreCategory("animation", "انیمیشن", "49173", "Animation"),
        GenreCategory("anime", "انیمه", "220320", "Anime"),
        GenreCategory("war", "جنگی", "49176", "War"),
        GenreCategory("history", "تاریخی", "49181", "History"),
        GenreCategory("biography", "بیوگرافی", "49190", "Biography"),
        GenreCategory("sport", "ورزشی", "49183", "Sport")
    )

    private fun archive2GenreCatalog(): List<GenreCategory> = listOf(
        GenreCategory("romance", "عاشقانه", "عاشقانه", "Romance"),
        GenreCategory("science", "علمی", "علمی-تخیلی", "Science"),
        GenreCategory("fantasy", "فانتزی", "فانتزی", "Fantasy"),
        GenreCategory("sci_fi", "علمی تخیلی", "علمی-تخیلی", "Sci-Fi"),
        GenreCategory("comedy", "کمدی", "کمدی", "Comedy"),
        GenreCategory("supernatural", "قدرت‌های فوق‌العاده", "فانتزی", "Superpowers"),
        GenreCategory("adventure", "ماجراجویی", "ماجراجویی", "Adventure"),
        GenreCategory("short", "کوتاه", "کوتاه", "Short"),
        GenreCategory("documentary", "مستند", "مستند", "Documentary"),
        GenreCategory("school", "مدرسه‌ای", "خانوادگی", "School"),
        GenreCategory("music", "موزیک", "موزیک", "Music"),
        GenreCategory("mystery", "معمایی", "معمایی", "Mystery"),
        GenreCategory("action", "اکشن", "اکشن", "Action"),
        GenreCategory("drama", "درام", "درام", "Drama"),
        GenreCategory("crime", "جنایی", "جنایی", "Crime"),
        GenreCategory("thriller", "هیجان‌انگیز", "هیجان‌انگیز", "Thriller"),
        GenreCategory("horror", "ترسناک", "ترسناک", "Horror"),
        GenreCategory("family", "خانوادگی", "خانوادگی", "Family"),
        GenreCategory("animation", "انیمیشن", "انیمیشن", "Animation"),
        GenreCategory("war", "جنگی", "جنگی", "War"),
        GenreCategory("history", "تاریخی", "تاریخی", "History"),
        GenreCategory("biography", "زندگی‌نامه", "زندگی نامه", "Biography"),
        GenreCategory("sport", "ورزشی", "ورزشی", "Sport"),
        GenreCategory("western", "وسترن", "وسترن", "Western")
    )

    private fun archive3GenreCatalog(): List<GenreCategory> = listOf(
        GenreCategory("action", "اکشن", "اکشن", "Action"),
        GenreCategory("biography", "بیوگرافی", "بیوگرافی", "Biography"),
        GenreCategory("history", "تاریخی", "تاریخی", "History"),
        GenreCategory("horror", "ترسناک", "ترسناک", "Horror"),
        GenreCategory("crime", "جنایی", "جنایی", "Crime"),
        GenreCategory("war", "جنگی", "جنگی", "War"),
        GenreCategory("family", "خانوادگی", "خانوادگی", "Family"),
        GenreCategory("animation", "انیمیشن", "انیمیشن", "Animation"),
        GenreCategory("drama", "درام", "درام", "Drama"),
        GenreCategory("mystery", "رازآلود", "رازآلود", "Mystery"),
        GenreCategory("romance", "عاشقانه", "عاشقانه", "Romance"),
        GenreCategory("sci_fi", "علمی تخیلی", "علمی تخیلی", "Sci-Fi"),
        GenreCategory("fantasy", "فانتزی", "فانتزی", "Fantasy"),
        GenreCategory("comedy", "کمدی", "کمدی", "Comedy"),
        GenreCategory("short", "کوتاه", "کوتاه", "Short"),
        GenreCategory("adventure", "ماجراجویی", "ماجراجویی", "Adventure"),
        GenreCategory("documentary", "مستند", "مستند", "Documentary"),
        GenreCategory("music", "موزیک", "موزیک ویدیو", "Music video"),
        GenreCategory("musical", "موزیکال", "موزیکال", "Musical"),
        GenreCategory("mini_series", "مینی سریال", "مینی سریال", "Mini-series"),
        GenreCategory("noir", "نوآر", "نوآر", "Noir"),
        GenreCategory("thriller", "هیجان انگیز", "هیجان انگیز", "Thriller"),
        GenreCategory("sport", "ورزشی", "ورزشی", "Sport"),
        GenreCategory("western", "وسترن", "وسترن", "Western")
    )

    private fun genreImageUrl(archive: Int, key: String): String {
        val assetArchive = if (sanitizeArchive(archive) == 3) 2 else sanitizeArchive(archive)
        return AppConfig.GENRE_ASSET_BASE_URL.trimEnd('/') + "/archive$assetArchive/${key}.webp"
    }

    private fun genreCard(category: GenreCategory, archive: Int, contentType: String): FrameLayout {
        val p = UiPreferences.palette(this)
        val tv = isTvLike()
        return FrameLayout(this).apply {
            clipToOutline = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.blend(p.panel2, p.primary, 0.12f),
                UiPreferences.blend(p.panel, Color.BLACK, 0.10f)
            )).apply {
                cornerRadius = dp(if (tv) 24 else 20).toFloat()
                setStroke(dp(1), p.stroke)
            }
            elevation = dp(3).toFloat()
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, if (tv) 24 else 20, if (tv) 1.055f else 1.025f, 0f)
            setOnClickListener { showGenreItems(category.label, archive, category.query, contentType) }

            addView(ImageView(this@MainActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                alpha = 0.82f
                loadImage(genreImageUrl(archive, category.key), this)
            }, FrameLayout.LayoutParams(-1, -1))

            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                    Color.argb(20, 0, 0, 0),
                    Color.argb(210, 5, 7, 13)
                ))
            }, FrameLayout.LayoutParams(-1, -1))

            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.BOTTOM
                setPadding(dp(14), dp(12), dp(14), dp(13))
                addView(TextView(this@MainActivity).apply {
                    text = category.label
                    setTextColor(Color.WHITE)
                    textSize = if (tv) 18f else 16.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setShadowLayer(8f, 0f, 2f, Color.BLACK)
                })
                addView(TextView(this@MainActivity).apply {
                    text = category.hint
                    setTextColor(Color.argb(145, 255, 255, 255))
                    textSize = if (tv) 10.8f else 10f
                    gravity = Gravity.RIGHT
                    maxLines = 1
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
                addView(View(this@MainActivity).apply {
                    background = rounded(p.primary, dp(999), Color.TRANSPARENT)
                }, LinearLayout.LayoutParams(dp(42), dp(3)).apply { topMargin = dp(8); gravity = Gravity.RIGHT })
            }, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun categoryHubCard(
        title: String,
        subtitle: String,
        iconRes: Int,
        accent: Int,
        onClick: () -> Unit
    ): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(13), dp(12), dp(13), dp(11))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(
                    Color.argb(225, Color.red(p.panel), Color.green(p.panel), Color.blue(p.panel)),
                    Color.argb(78, Color.red(accent), Color.green(accent), Color.blue(accent))
                )
            ).apply {
                cornerRadius = dp(20).toFloat()
                setStroke(dp(1), Color.argb(95, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 20, 1.035f, dp(1).toFloat())
            applyMobileTouchHalo(this, 20)
            setOnClickListener { onClick() }

            val head = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            head.addView(FrameLayout(this@MainActivity).apply {
                background = rounded(Color.argb(45, 255, 255, 255), dp(14), Color.argb(55, 255, 255, 255))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(iconRes)
                    setColorFilter(Color.WHITE)
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }, FrameLayout.LayoutParams(-1, -1))
            }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(9) })
            head.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(p.text)
                textSize = 14.2f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, dp(40), 1f))
            addView(head)
            addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(p.muted)
                textSize = 9.7f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun openCategoryTop(archive: Int, type: String, title: String) {
        val safe = sanitizeArchive(archive)
        val sort = when (safe) {
            1 -> "imdb_rate"
            else -> "rating"
        }
        showAdvancedSearchResults(
            AdvancedSearchState(
                archive = safe,
                type = type,
                sortValue = sort,
                sortLabel = t("امتیاز IMDb", "IMDb rating")
            )
        )
    }

    private fun siteCategoryCard(
        title: String,
        kicker: String,
        meta: String,
        description: String,
        imageRes: Int,
        onClick: () -> Unit
    ): View {
        val p = UiPreferences.palette(this)
        return FrameLayout(this).apply {
            background = rounded(Color.rgb(9, 9, 18), dp(26), Color.argb(92, 181, 140, 255))
            clipToOutline = true
            elevation = dp(5).toFloat()
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 26, 1.025f, elevation)
            applyMobileTouchHalo(this, 26)
            setOnClickListener { onClick() }

            addView(ImageView(this@MainActivity).apply {
                setImageResource(imageRes)
                // Collections uses a wider 16:9 composition; keep both poster groups visible.
                scaleType = if (imageRes == R.drawable.bm_category_collections) ImageView.ScaleType.FIT_CENTER else ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.rgb(3, 2, 10))
                alpha = 0.96f
            }, FrameLayout.LayoutParams(-1, -1))
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                    Color.argb(8, 1, 2, 8),
                    Color.argb(65, 2, 3, 10),
                    Color.argb(245, 2, 3, 10)
                ))
            }, FrameLayout.LayoutParams(-1, -1))
            addView(TextView(this@MainActivity).apply {
                text = "●  $meta"
                setTextColor(Color.rgb(216, 199, 255)); textSize = 9.5f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(9), dp(5), dp(9), dp(5))
                background = rounded(Color.argb(150, 3, 4, 12), dp(999), Color.argb(55, 255, 255, 255))
            }, FrameLayout.LayoutParams(-2, dp(31), Gravity.TOP or Gravity.RIGHT).apply { topMargin=dp(13); marginEnd=dp(13) })

            val bottom = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.BOTTOM
                setPadding(dp(17), dp(12), dp(17), dp(16))
                addView(TextView(this@MainActivity).apply {
                    text = kicker
                    setTextColor(Color.rgb(216, 199, 255)); textSize = 9.8f; typeface = Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT
                })
                addView(TextView(this@MainActivity).apply {
                    text = title
                    setTextColor(Color.WHITE); textSize = if (isTvLike()) 24f else 21f; typeface = BankmovieFonts.bold(this@MainActivity); gravity=Gravity.RIGHT
                    setPadding(0, dp(3), 0, 0)
                })
                addView(TextView(this@MainActivity).apply {
                    text = description
                    setTextColor(Color.argb(178,255,255,255)); textSize = 10.5f; gravity=Gravity.RIGHT; maxLines=2
                    setPadding(0, dp(4), dp(0), 0)
                })
            }
            addView(bottom, FrameLayout.LayoutParams(-1, -1, Gravity.BOTTOM))
        }
    }

    /** Exact four-entry Categories hub from the live website. */
    private fun showCategories() {
        if (!AccountSession.categoriesEnabled(this)) {
            Toast.makeText(this, "دسته‌بندی‌ها موقتاً از پنل غیرفعال شده‌اند", Toast.LENGTH_SHORT).show()
            showHome(); return
        }
        currentScreen = "categories"
        rememberCurrentScreen { showCategories() }
        buildBottomNav(); clear()
        val tv = isTvLike()
        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding=false; setPadding(0,0,0,dp(108)) }
        val page = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(if(tv)22 else 14), dp(14), dp(if(tv)22 else 14), dp(30))
        }
        scroll.addView(page); content.addView(scroll); attachSmartHeader(scroll)
        page.addView(listTop(t("دسته‌بندی", "Categories")))
        page.addView(TextView(this).apply {
            text = t("ژانرها، کالکشن‌ها و فهرست‌های ۲۵۰ برتر IMDb را مثل سایت یک‌جا ببین.", "Browse genres, collections and IMDb Top 250 lists just like the website.")
            setTextColor(p.muted); textSize=11.5f; gravity=Gravity.RIGHT; setLineSpacing(dp(2).toFloat(),1f)
        }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(13) })
        val grid=GridLayout(this).apply {
            columnCount=if(tv)2 else 1
            layoutDirection=if(tv)View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            alignmentMode=GridLayout.ALIGN_BOUNDS
        }
        val cards=listOf(
            siteCategoryCard("ژانرها","GENRES","کشف بر اساس موضوع","اکشن، عاشقانه، ترسناک، علمی‌تخیلی و همه ژانرهای واقعی آرشیوها.",R.drawable.bm_category_genres){ showGenreDirectory() },
            siteCategoryCard("کالکشن‌ها","COLLECTIONS","مجموعه‌های دنباله‌دار","تمام قسمت‌های هر فرنچایز و مجموعه فیلم، مرتب و یکجا.",R.drawable.bm_category_collections){ showCollections() },
            siteCategoryCard("۲۵۰ فیلم برتر IMDb","TOP 250 MOVIES","۲۵۰ برتر IMDb","فهرست ۲۵۰ فیلم برتر IMDb از منبع اصلی سایت.",R.drawable.bm_category_top_movies){ showList("۲۵۰ فیلم برتر IMDb",1,"top-movies") },
            siteCategoryCard("۲۵۰ سریال برتر IMDb","TOP 250 SERIES","۲۵۰ برتر IMDb","فهرست ۲۵۰ سریال برتر IMDb از منبع اصلی سایت.",R.drawable.bm_category_top_series){ showList("۲۵۰ سریال برتر IMDb",1,"top-series") }
        )
        cards.forEach { card -> grid.addView(card, GridLayout.LayoutParams().apply {
            width=0; height=dp(if(tv)310 else 245); columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f)
            setMargins(dp(5),dp(5),dp(5),dp(7))
        }) }
        page.addView(grid,LinearLayout.LayoutParams(-1,-2))
        applyTvFocusToClickableTree(page)
    }

    private fun showGenreDirectory(
        archive: Int = sanitizeArchive(appPrefs().getInt("genre_archive", selectedArchive)),
        contentType: String = "all"
    ) {
        if (!AccountSession.categoriesEnabled(this)) {
            Toast.makeText(this, "دسته‌بندی‌ها موقتاً از پنل غیرفعال شده‌اند", Toast.LENGTH_SHORT).show()
            showHome()
            return
        }
        currentScreen = "categories"
        val requestedGenreArchive = sanitizeArchive(archive)
        val selectedGenreArchive = if (archiveEnabled(requestedGenreArchive)) {
            requestedGenreArchive
        } else {
            listOf(1, 2, 3).firstOrNull { archiveEnabled(it) } ?: requestedGenreArchive
        }
        rememberCurrentScreen { showGenreDirectory(selectedGenreArchive) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val p = UiPreferences.palette(this)
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(108)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (tv) 22 else 14), dp(12), dp(if (tv) 22 else 14), dp(30))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        page.addView(listTop(t("دسته‌بندی‌ها", "Categories")))

        val archiveToggle = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = bankGlassDrawable(24, 236, 70, true)
        }
        listOf(
            1 to t("آرشیو ۱", "Archive 1"),
            2 to t("آرشیو ۲", "Archive 2"),
            3 to t("آرشیو ۳", "Archive 3")
        ).filter { archiveVisible(it.first) }.forEachIndexed { index, pair ->
            val selected = selectedGenreArchive == pair.first
            archiveToggle.addView(TextView(this).apply {
                text = pair.second
                gravity = Gravity.CENTER
                setTextColor(if (selected) p.onPrimary else p.text)
                textSize = if (tv) 15f else 13.5f
                typeface = Typeface.DEFAULT_BOLD
                background = if (selected) blueGradient(dp(19)) else rounded(Color.TRANSPARENT, dp(19), Color.TRANSPARENT)
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 19, 1.04f, 0f)
                alpha = if (archiveRawEnabled(pair.first)) 1f else 0.42f
                setOnClickListener {
                    if (!archiveEnabled(pair.first)) {
                        Toast.makeText(this@MainActivity, t("این آرشیو از پنل مدیریت غیرفعال شده است", "This archive is disabled by admin"), Toast.LENGTH_SHORT).show()
                        return@setOnClickListener
                    }
                    appPrefs().edit().putInt("genre_archive", pair.first).apply()
                    showGenreDirectory(pair.first)
                }
            }, LinearLayout.LayoutParams(0, dp(if (tv) 52 else 48), 1f).apply {
                if (index > 0) marginStart = dp(5)
            })
        }
        page.addView(archiveToggle, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        if (!anyArchiveEnabled()) {
            page.addView(
                emptyStateBox(
                    t("همه آرشیوها غیرفعال‌اند", "All archives are disabled"),
                    t("از پنل مدیریت حداقل یک آرشیو را فعال کن.", "Enable at least one archive from the admin panel.")
                ),
                LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) }
            )
            BankmovieFonts.applyToTree(this, page)
            return
        }

        page.addView(TextView(this).apply {
            text = t("ژانرها", "Genres")
            setTextColor(p.text)
            textSize = if (tv) 20f else 17.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(dp(2), dp(4), dp(2), dp(10))
        })

        val visibleCatalog = when (selectedGenreArchive) {
            2 -> archive2GenreCatalog()
            3 -> archive3GenreCatalog()
            else -> archive1GenreCatalog()
        }
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 4 else 2
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            alignmentMode = GridLayout.ALIGN_BOUNDS
            useDefaultMargins = false
            clipChildren = false
            clipToPadding = false
        }
        page.addView(grid, LinearLayout.LayoutParams(-1, -2))
        val cardHeight = dp(if (tv) 150 else 142)
        visibleCatalog.forEach { category ->
            grid.addView(genreCard(category, selectedGenreArchive, "all"), GridLayout.LayoutParams().apply {
                width = 0
                height = cardHeight
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(7))
            })
        }
        applyTvFocusToClickableTree(page)
    }

    private fun showGenreItems(title: String, archive: Int, genreValue: String, contentType: String) {
        pushCurrentScreenForBack()
        currentScreen = "categories"
        val safeArchive = sanitizeArchive(archive)
        val safeType = if (contentType in setOf("movie", "series", "animation", "anime")) contentType else "all"
        rememberCurrentScreen { showGenreItems(title, safeArchive, genreValue, contentType) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(110)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(listTop(title))

        val grid = GridLayout(this).apply {
            columnCount = if (tv) tvGridColumns() else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            alignmentMode = GridLayout.ALIGN_MARGINS
            useDefaultMargins = false
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        val more = moreButton(t("مشاهده بیشتر", "Load more")) { }
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(100) })

        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW)
        val limit = 24
        val seen = mutableSetOf<String>()
        repeat(if (tv) 16 else 9) { grid.addView(skeletonPosterCard(cardW, cardH)) }

        fun keyOf(item: JSONObject): String = item.optString("id")
            .ifBlank { item.optString("slug") }
            .ifBlank { item.optString("title_fa") + item.optString("poster") }

        lateinit var loadPage: (Int) -> Unit

        fun renderPage(pageNumber: Int, json: JSONObject?) {
            if (pageNumber == 1) grid.removeAllViews()
            val arr = json?.optJSONArray("items") ?: JSONArray()
            var added = 0
            for (i in 0 until arr.length()) {
                val item = arr.optJSONObject(i) ?: continue
                val key = keyOf(item)
                if (key.isBlank() || seen.add(key)) {
                    grid.addView(posterCard(item, cardW, cardH))
                    added++
                }
            }
            val hasMore = json?.optBoolean("has_more", false) == true || arr.length() >= limit
            if (hasMore && added > 0) {
                val next = json?.optInt("next_page", pageNumber + 1) ?: (pageNumber + 1)
                more.visibility = View.VISIBLE
                more.text = t("مشاهده بیشتر", "Load more")
                more.isEnabled = true
                more.setOnClickListener { loadPage(if (next > pageNumber) next else pageNumber + 1) }
            } else {
                more.visibility = View.GONE
            }
            if (grid.childCount == 0) {
                page.addView(emptyStateBox(t("موردی پیدا نشد", "Nothing found"), t("برای این ژانر هنوز عنوانی در دسترس نیست.", "No titles are available for this genre yet.")), LinearLayout.LayoutParams(-1, -2))
            }
            applyTvFocusToClickableTree(page)
        }

        fun mergeArchive2(movieJson: JSONObject?, seriesJson: JSONObject?): JSONObject {
            val merged = JSONObject()
            val out = JSONArray()
            val localSeen = mutableSetOf<String>()
            listOf(movieJson, seriesJson).forEach { source ->
                val items = source?.optJSONArray("items") ?: JSONArray()
                for (i in 0 until items.length()) {
                    val item = items.optJSONObject(i) ?: continue
                    val key = keyOf(item)
                    if (key.isBlank() || localSeen.add(key)) out.put(item)
                }
            }
            merged.put("items", out)
            val hasMore = (movieJson?.optBoolean("has_more", false) == true) ||
                (seriesJson?.optBoolean("has_more", false) == true) || out.length() >= limit
            merged.put("has_more", hasMore)
            return merged
        }

        fun loadArchive2All(pageNumber: Int) {
            val eachLimit = 12
            fetchArchive(archive2GenreUrl(genreValue, "movie", pageNumber, eachLimit), 2) { movieOk, movieJson, movieErr ->
                fetchArchive(archive2GenreUrl(genreValue, "series", pageNumber, eachLimit), 2) { seriesOk, seriesJson, seriesErr ->
                    runOnUiThread {
                        more.isEnabled = true
                        if (!movieOk && !seriesOk) {
                            if (pageNumber == 1) grid.removeAllViews()
                            more.visibility = View.VISIBLE
                            more.text = t("تلاش مجدد", "Retry")
                            more.setOnClickListener { loadPage(pageNumber) }
                            if (grid.childCount == 0) page.addView(errorView(friendlyError(movieErr ?: seriesErr)))
                            applyTvFocusToClickableTree(page)
                        } else renderPage(pageNumber, mergeArchive2(movieJson, seriesJson))
                    }
                }
            }
        }

        loadPage = { pageNumber ->
            more.visibility = View.VISIBLE
            more.text = t("در حال بارگذاری...", "Loading...")
            more.isEnabled = false
            if (safeArchive == 2 && safeType == "all") {
                loadArchive2All(pageNumber)
            } else {
                val url = if (safeArchive == 2) {
                    archive2GenreUrl(genreValue, if (safeType == "series") "series" else "movie", pageNumber, limit)
                } else {
                    advancedSearchUrl(AdvancedSearchState(
                        archive = safeArchive,
                        type = safeType,
                        genreValue = genreValue,
                        genreLabel = title,
                        sortValue = if (safeArchive == 3) "newest" else "modified"
                    ), pageNumber, limit)
                }
                fetchArchive(url, safeArchive) { ok, json, err ->
                    runOnUiThread {
                        more.isEnabled = true
                        if (!ok || json == null) {
                            if (pageNumber == 1) grid.removeAllViews()
                            more.visibility = View.VISIBLE
                            more.text = t("تلاش مجدد", "Retry")
                            more.setOnClickListener { loadPage(pageNumber) }
                            if (grid.childCount == 0) page.addView(errorView(friendlyError(err)))
                            applyTvFocusToClickableTree(page)
                        } else renderPage(pageNumber, json)
                    }
                }
            }
        }
        loadPage(1)
    }

    private fun searchAcceptsType(item: JSONObject, filter: String): Boolean {
        if (filter == "all") return true
        val normalized = itemContentType(item)
        return when (filter.lowercase(Locale.US)) {
            "series" -> normalized == "series"
            "animation" -> normalized == "animation"
            "anime" -> normalized == "anime"
            "movie" -> normalized == "movie"
            else -> true
        }
    }


    private fun archive3GenreOptions(): List<AdvancedOption> {
        val remote = archive3Options("genres", includeAll = true)
        if (remote.size > 1) return remote
        return listOf(
            AdvancedOption("", t("همه", "All")),
            AdvancedOption("اکشن", "اکشن"),
            AdvancedOption("بیوگرافی", "بیوگرافی"),
            AdvancedOption("تاریخی", "تاریخی"),
            AdvancedOption("ترسناک", "ترسناک"),
            AdvancedOption("جنایی", "جنایی"),
            AdvancedOption("جنگی", "جنگی"),
            AdvancedOption("خانوادگی", "خانوادگی"),
            AdvancedOption("انیمیشن", "انیمیشن"),
            AdvancedOption("درام", "درام"),
            AdvancedOption("رازآلود", "رازآلود"),
            AdvancedOption("عاشقانه", "عاشقانه"),
            AdvancedOption("علمی تخیلی", "علمی تخیلی"),
            AdvancedOption("فانتزی", "فانتزی"),
            AdvancedOption("کمدی", "کمدی"),
            AdvancedOption("کوتاه", "کوتاه"),
            AdvancedOption("ماجراجویی", "ماجراجویی"),
            AdvancedOption("مستند", "مستند"),
            AdvancedOption("موزیک ویدیو", "موزیک ویدیو"),
            AdvancedOption("موزیکال", "موزیکال"),
            AdvancedOption("مینی سریال", "مینی سریال"),
            AdvancedOption("نوآر", "نوآر"),
            AdvancedOption("هیجان انگیز", "هیجان انگیز"),
            AdvancedOption("ورزشی", "ورزشی"),
            AdvancedOption("وسترن", "وسترن")
        )
    }

    private fun archive3YearOptions(): List<AdvancedOption> {
        val remote = archive3Options("years", includeAll = true)
        if (remote.size > 1) return remote
        val out = mutableListOf(AdvancedOption("", t("همه سال‌ها", "Any year")))
        for (year in 2026 downTo 2000) out.add(AdvancedOption(year.toString(), year.toString()))
        return out
    }

    private fun archive2GenreOptions(): List<AdvancedOption> = listOf(
        AdvancedOption("", t("همه", "All")),
        AdvancedOption("اکشن", "اکشن"),
        AdvancedOption("انیمیشن", "انیمیشن"),
        AdvancedOption("بیوگرافی", "بیوگرافی"),
        AdvancedOption("تاریخی", "تاریخی"),
        AdvancedOption("تاک-شو", "تاک-شو"),
        AdvancedOption("تالک-شو", "تالک-شو"),
        AdvancedOption("ترسناک", "ترسناک"),
        AdvancedOption("جنایی", "جنایی"),
        AdvancedOption("جنگی", "جنگی"),
        AdvancedOption("خانوادگی", "خانوادگی"),
        AdvancedOption("خبری", "خبری"),
        AdvancedOption("درام", "درام"),
        AdvancedOption("ریئلیتی-تیوی", "ریئلیتی-تیوی"),
        AdvancedOption("زندگی نامه", "زندگی نامه"),
        AdvancedOption("شوی تلویزیونی", "شوی تلویزیونی"),
        AdvancedOption("عاشقانه", "عاشقانه"),
        AdvancedOption("علمی-تخیلی", "علمی-تخیلی"),
        AdvancedOption("فانتزی", "فانتزی"),
        AdvancedOption("فیلم-نوآر", "فیلم-نوآر"),
        AdvancedOption("کمدی", "کمدی"),
        AdvancedOption("کوتاه", "کوتاه"),
        AdvancedOption("گیم-شو", "گیم-شو"),
        AdvancedOption("ماجراجویی", "ماجراجویی"),
        AdvancedOption("مستند", "مستند"),
        AdvancedOption("معمایی", "معمایی"),
        AdvancedOption("موزیک", "موزیک"),
        AdvancedOption("موزیکال", "موزیکال"),
        AdvancedOption("موسیقی", "موسیقی"),
        AdvancedOption("هیجان انگیز", "هیجان انگیز"),
        AdvancedOption("هیجان‌انگیز", "هیجان‌انگیز"),
        AdvancedOption("ورزشی", "ورزشی"),
        AdvancedOption("وسترن", "وسترن"),
    )

    private fun countryFlagEmoji(label: String): String {
        val key = label
            .trim()
            .lowercase(Locale.ROOT)
            .replace('’', '\'')
            .replace(Regex("\\s+"), " ")

        val code = when (key) {
            "argantina", "argentina" -> "AR"
            "australia", "استرالیا" -> "AU"
            "austria" -> "AT"
            "bahamas" -> "BS"
            "bangladesh" -> "BD"
            "belarus" -> "BY"
            "belgium" -> "BE"
            "benin" -> "BJ"
            "bhutan" -> "BT"
            "bolivia" -> "BO"
            "bosnia and herzegovina" -> "BA"
            "brazil" -> "BR"
            "bulgaria" -> "BG"
            "cambodia" -> "KH"
            "canada", "کانادا" -> "CA"
            "chile" -> "CL"
            "china", "چین" -> "CN"
            "colombia" -> "CO"
            "costa rica" -> "CR"
            "côte d'ivoire", "cote d'ivoire" -> "CI"
            "croatia", "کرواسی" -> "HR"
            "cuba" -> "CU"
            "cyprus" -> "CY"
            "czech republic", "czechoslovakia" -> "CZ"
            "denmark" -> "DK"
            "dominican republic" -> "DO"
            "ecuador" -> "EC"
            "egypt" -> "EG"
            "estonia" -> "EE"
            "finland" -> "FI"
            "france" -> "FR"
            "french polynesia" -> "PF"
            "gambia" -> "GM"
            "georgia" -> "GE"
            "germany", "west germany", "آلمان" -> "DE"
            "greece" -> "GR"
            "guadeloupe" -> "GP"
            "haiti" -> "HT"
            "hong kong", "هنگ کنگ" -> "HK"
            "hungary" -> "HU"
            "iceland" -> "IS"
            "india" -> "IN"
            "indonesia" -> "ID"
            "iran", "ایران" -> "IR"
            "ireland", "ایرلند" -> "IE"
            "israel" -> "IL"
            "italy" -> "IT"
            "japan" -> "JP"
            "jordan" -> "JO"
            "kazakhstan" -> "KZ"
            "kenya" -> "KE"
            "korea", "south korea" -> "KR"
            "north korea" -> "KP"
            "kosovo" -> "XK"
            "latvia" -> "LV"
            "lebanon" -> "LB"
            "libya" -> "LY"
            "liechtenstein" -> "LI"
            "lithuania" -> "LT"
            "luxembourg" -> "LU"
            "macao" -> "MO"
            "madagascar" -> "MG"
            "malaysia" -> "MY"
            "mali" -> "ML"
            "malta" -> "MT"
            "mexico" -> "MX"
            "moldova" -> "MD"
            "monaco" -> "MC"
            "mongolia" -> "MN"
            "morocco" -> "MA"
            "namibia" -> "NA"
            "nepal" -> "NP"
            "netherlands" -> "NL"
            "new zealand", "نیوزلند" -> "NZ"
            "nigeria" -> "NG"
            "north macedonia", "republic of macedonia" -> "MK"
            "norway" -> "NO"
            "occupied palestinian territory", "palestine" -> "PS"
            "pakistan" -> "PK"
            "panama" -> "PA"
            "paraguay" -> "PY"
            "peru" -> "PE"
            "philippines" -> "PH"
            "poland" -> "PL"
            "portugal" -> "PT"
            "puerto rico" -> "PR"
            "qatar" -> "QA"
            "romania" -> "RO"
            "russia", "soviet union" -> "RU"
            "saint helena" -> "SH"
            "saint kitts and nevis" -> "KN"
            "saudi arabia" -> "SA"
            "senegal" -> "SN"
            "serbia", "yugoslavia", "federal republic of yugoslavia" -> "RS"
            "singapore" -> "SG"
            "slovakia" -> "SK"
            "slovenia" -> "SI"
            "south africa", "آفریقای جنوبی" -> "ZA"
            "spain" -> "ES"
            "sri lanka" -> "LK"
            "sudan" -> "SD"
            "sweden" -> "SE"
            "switzerland" -> "CH"
            "syria" -> "SY"
            "taiwan" -> "TW"
            "thailand" -> "TH"
            "tunisia" -> "TN"
            "turkey" -> "TR"
            "uk", "united kingdom", "england", "انگلستان" -> "GB"
            "ukraine" -> "UA"
            "united arab emirates" -> "AE"
            "united states", "united states of america", "آمریکا" -> "US"
            "uruguay" -> "UY"
            "venezuela" -> "VE"
            "vietnam" -> "VN"
            "zambia" -> "ZM"
            else -> null
        } ?: return "🌍"

        return code.map { character ->
            String(Character.toChars(0x1F1E6 + (character - 'A')))
        }.joinToString("")
    }

    private fun decorateCountryOptions(options: List<AdvancedOption>): List<AdvancedOption> {
        return options.map { option ->
            if (option.value.isBlank()) {
                option.copy(label = t("🌍 همه کشورها", "🌍 All countries"))
            } else {
                option.copy(label = "${countryFlagEmoji(option.label)} ${option.label}")
            }
        }
    }

    private fun archive2CountryOptions(): List<AdvancedOption> = listOf(
        AdvancedOption("", t("همه", "All")),
        AdvancedOption("Argantina", "Argantina"),
        AdvancedOption("Argentina", "Argentina"),
        AdvancedOption("Australia", "Australia"),
        AdvancedOption("Austria", "Austria"),
        AdvancedOption("Belgium", "Belgium"),
        AdvancedOption("Bosnia and Herzegovina", "Bosnia and Herzegovina"),
        AdvancedOption("Brazil", "Brazil"),
        AdvancedOption("Bulgaria", "Bulgaria"),
        AdvancedOption("Canada", "Canada"),
        AdvancedOption("Chile", "Chile"),
        AdvancedOption("China", "China"),
        AdvancedOption("Colombia", "Colombia"),
        AdvancedOption("Croatia", "Croatia"),
        AdvancedOption("Czech Republic", "Czech Republic"),
        AdvancedOption("Denmark", "Denmark"),
        AdvancedOption("Egypt", "Egypt"),
        AdvancedOption("Finland", "Finland"),
        AdvancedOption("France", "France"),
        AdvancedOption("Germany", "Germany"),
        AdvancedOption("Greece", "Greece"),
        AdvancedOption("Hong Kong", "Hong Kong"),
        AdvancedOption("Hungary", "Hungary"),
        AdvancedOption("Iceland", "Iceland"),
        AdvancedOption("India", "India"),
        AdvancedOption("Indonesia", "Indonesia"),
        AdvancedOption("Iran", "Iran"),
        AdvancedOption("Ireland", "Ireland"),
        AdvancedOption("Israel", "Israel"),
        AdvancedOption("Italy", "Italy"),
        AdvancedOption("Japan", "Japan"),
        AdvancedOption("Korea", "Korea"),
        AdvancedOption("Latvia", "Latvia"),
        AdvancedOption("Lithuania", "Lithuania"),
        AdvancedOption("Luxembourg", "Luxembourg"),
        AdvancedOption("Malta", "Malta"),
        AdvancedOption("Mexico", "Mexico"),
        AdvancedOption("Morocco", "Morocco"),
        AdvancedOption("Netherlands", "Netherlands"),
        AdvancedOption("New Zealand", "New Zealand"),
        AdvancedOption("Norway", "Norway"),
        AdvancedOption("Philippines", "Philippines"),
        AdvancedOption("Poland", "Poland"),
        AdvancedOption("Portugal", "Portugal"),
        AdvancedOption("Republic of Macedonia", "Republic of Macedonia"),
        AdvancedOption("Romania", "Romania"),
        AdvancedOption("Russia", "Russia"),
        AdvancedOption("Serbia", "Serbia"),
        AdvancedOption("Singapore", "Singapore"),
        AdvancedOption("South Africa", "South Africa"),
        AdvancedOption("South Korea", "South Korea"),
        AdvancedOption("Spain", "Spain"),
        AdvancedOption("Sweden", "Sweden"),
        AdvancedOption("Switzerland", "Switzerland"),
        AdvancedOption("Taiwan", "Taiwan"),
        AdvancedOption("Thailand", "Thailand"),
        AdvancedOption("Turkey", "Turkey"),
        AdvancedOption("UK", "UK"),
        AdvancedOption("Ukraine", "Ukraine"),
        AdvancedOption("United Arab Emirates", "United Arab Emirates"),
        AdvancedOption("United Kingdom", "United Kingdom"),
        AdvancedOption("United States", "United States"),
        AdvancedOption("آفریقای جنوبی", "آفریقای جنوبی"),
        AdvancedOption("آلمان", "آلمان"),
        AdvancedOption("آمریکا", "آمریکا"),
        AdvancedOption("استرالیا", "استرالیا"),
        AdvancedOption("انگلستان", "انگلستان"),
        AdvancedOption("ایرلند", "ایرلند"),
        AdvancedOption("چین", "چین"),
        AdvancedOption("کانادا", "کانادا"),
        AdvancedOption("کرواسی", "کرواسی"),
        AdvancedOption("نیوزلند", "نیوزلند"),
        AdvancedOption("هنگ کنگ", "هنگ کنگ"),
    )

    private fun archive1GenreOptions(): List<AdvancedOption> = listOf(
        AdvancedOption("", t("همه", "All")),
        AdvancedOption("49159", "کمدی"),
        AdvancedOption("49160", "درام"),
        AdvancedOption("49161", "معمایی"),
        AdvancedOption("49162", "علمی تخیلی"),
        AdvancedOption("49165", "هیجان انگیز"),
        AdvancedOption("49166", "اکشن"),
        AdvancedOption("49167", "عاشقانه"),
        AdvancedOption("49170", "ماجراجویی"),
        AdvancedOption("49173", "انیمیشن"),
        AdvancedOption("49174", "ترسناک"),
        AdvancedOption("49176", "جنگی"),
        AdvancedOption("49179", "جنایی"),
        AdvancedOption("49181", "تاریخی"),
        AdvancedOption("49182", "فانتزی"),
        AdvancedOption("49183", "ورزشی"),
        AdvancedOption("49190", "بیوگرافی"),
        AdvancedOption("49199", "خانوادگی"),
        AdvancedOption("49215", "وسترن"),
        AdvancedOption("49237", "موزیکال"),
        AdvancedOption("49238", "کوتاه"),
        AdvancedOption("49240", "تاک شو"),
        AdvancedOption("49243", "موزیک"),
        AdvancedOption("49336", "فیلم-نوآر"),
        AdvancedOption("49342", "مستند"),
        AdvancedOption("49343", "برنامه‌ تلویزیونی‌"),
        AdvancedOption("49455", "نامشخص"),
        AdvancedOption("49456", "مسابقه‌ ها"),
        AdvancedOption("49482", "ملودرام"),
        AdvancedOption("220319", "science-fiction"),
        AdvancedOption("220320", "انیمه"),
        AdvancedOption("220441", "فراطبیعی"),
        AdvancedOption("220513", "پزشکی"),
        AdvancedOption("220525", "جاسوسی"),
        AdvancedOption("220881", "حقوقی"),
        AdvancedOption("220947", "طبیعت"),
        AdvancedOption("221019", "کودک و نوجوان"),
        AdvancedOption("221596", "sports"),
        AdvancedOption("223786", "سفر"),
        AdvancedOption("224625", "diy"),
        AdvancedOption("224666", "غذا"),
        AdvancedOption("224680", "adult"),
    )

    private fun archive1CountryOptions(): List<AdvancedOption> = listOf(
        AdvancedOption("", t("همه", "All")),
        AdvancedOption("74922", "India"),
        AdvancedOption("74923", "United Kingdom"),
        AdvancedOption("74924", "United States"),
        AdvancedOption("74925", "Turkey"),
        AdvancedOption("74926", "France"),
        AdvancedOption("74927", "Belgium"),
        AdvancedOption("74928", "Japan"),
        AdvancedOption("74929", "Canada"),
        AdvancedOption("74930", "Argentina"),
        AdvancedOption("74931", "Spain"),
        AdvancedOption("74932", "Chile"),
        AdvancedOption("74933", "Germany"),
        AdvancedOption("74934", "Hungary"),
        AdvancedOption("74935", "China"),
        AdvancedOption("74936", "Norway"),
        AdvancedOption("74937", "Lithuania"),
        AdvancedOption("74938", "South Korea"),
        AdvancedOption("74939", "Finland"),
        AdvancedOption("74940", "Netherlands"),
        AdvancedOption("74941", "Sweden"),
        AdvancedOption("74942", "Poland"),
        AdvancedOption("74943", "Denmark"),
        AdvancedOption("74944", "Mongolia"),
        AdvancedOption("74945", "Kazakhstan"),
        AdvancedOption("74946", "Bulgaria"),
        AdvancedOption("74947", "Australia"),
        AdvancedOption("74948", "Ireland"),
        AdvancedOption("74949", "New Zealand"),
        AdvancedOption("74950", "Russia"),
        AdvancedOption("74951", "Italy"),
        AdvancedOption("74952", "Croatia"),
        AdvancedOption("74953", "Indonesia"),
        AdvancedOption("74954", "Switzerland"),
        AdvancedOption("74955", "Tunisia"),
        AdvancedOption("74956", "Singapore"),
        AdvancedOption("74957", "Hong Kong"),
        AdvancedOption("74958", "Taiwan"),
        AdvancedOption("74959", "Iran"),
        AdvancedOption("74960", "Malaysia"),
        AdvancedOption("74961", "Colombia"),
        AdvancedOption("74962", "Egypt"),
        AdvancedOption("74963", "Malta"),
        AdvancedOption("74964", "Nigeria"),
        AdvancedOption("74965", "Estonia"),
        AdvancedOption("74966", "Slovakia"),
        AdvancedOption("74967", "Brazil"),
        AdvancedOption("74968", "Mexico"),
        AdvancedOption("74969", "Korea"),
        AdvancedOption("74970", "Thailand"),
        AdvancedOption("74971", "Serbia"),
        AdvancedOption("74972", "Luxembourg"),
        AdvancedOption("74973", "Cuba"),
        AdvancedOption("74974", "Yugoslavia"),
        AdvancedOption("74975", "Czech Republic"),
        AdvancedOption("74976", "Ukraine"),
        AdvancedOption("74977", "Romania"),
        AdvancedOption("74978", "Georgia"),
        AdvancedOption("74979", "Greece"),
        AdvancedOption("74980", "Iceland"),
        AdvancedOption("74981", "Haiti"),
        AdvancedOption("74982", "Austria"),
        AdvancedOption("74983", "Soviet Union"),
        AdvancedOption("74984", "Morocco"),
        AdvancedOption("74985", "Slovenia"),
        AdvancedOption("74986", "Pakistan"),
        AdvancedOption("74987", "Zambia"),
        AdvancedOption("74988", "West Germany"),
        AdvancedOption("74989", "United Arab Emirates"),
        AdvancedOption("74990", "Jordan"),
        AdvancedOption("74991", "Gambia"),
        AdvancedOption("74992", "Bangladesh"),
        AdvancedOption("74993", "Dominican Republic"),
        AdvancedOption("74994", "Portugal"),
        AdvancedOption("74995", "South Africa"),
        AdvancedOption("74996", "Bosnia and Herzegovina"),
        AdvancedOption("74997", "North Macedonia"),
        AdvancedOption("74998", "Qatar"),
        AdvancedOption("74999", "Bhutan"),
        AdvancedOption("75000", "Vietnam"),
        AdvancedOption("75001", "Philippines"),
        AdvancedOption("75002", "Saudi Arabia"),
        AdvancedOption("75003", "Uruguay"),
        AdvancedOption("75004", "Latvia"),
        AdvancedOption("75005", "Kenya"),
        AdvancedOption("75006", "Algeria"),
        AdvancedOption("75007", "Cyprus"),
        AdvancedOption("75008", "Belarus"),
        AdvancedOption("75009", "Kosovo"),
        AdvancedOption("75010", "Federal Republic of Yugoslavia"),
        AdvancedOption("75011", "Saint Kitts and Nevis"),
        AdvancedOption("75012", "Peru"),
        AdvancedOption("75013", "Cambodia"),
        AdvancedOption("75014", "Bolivia"),
        AdvancedOption("75015", "Panama"),
        AdvancedOption("97951", "Israel"),
        AdvancedOption("97952", "Libya"),
        AdvancedOption("97953", "North Korea"),
        AdvancedOption("97954", "Côte d'Ivoire"),
        AdvancedOption("97955", "Senegal"),
        AdvancedOption("97956", "Bahamas"),
        AdvancedOption("97957", "Puerto Rico"),
        AdvancedOption("97958", "Paraguay"),
        AdvancedOption("97959", "Occupied Palestinian Territory"),
        AdvancedOption("97960", "Guadeloupe"),
        AdvancedOption("98947", "Monaco"),
        AdvancedOption("200445", "Moldova"),
        AdvancedOption("200474", "Benin"),
        AdvancedOption("200478", "Mali"),
        AdvancedOption("203181", "Lebanon"),
        AdvancedOption("203845", "Madagascar"),
        AdvancedOption("206308", "Syria"),
        AdvancedOption("214442", "Costa Rica"),
        AdvancedOption("215645", "Nepal"),
        AdvancedOption("215646", "Sri Lanka"),
        AdvancedOption("215724", "Saint Helena"),
        AdvancedOption("216362", "Ecuador"),
        AdvancedOption("217249", "Namibia"),
        AdvancedOption("222408", "Macao"),
        AdvancedOption("223636", "French Polynesia"),
        AdvancedOption("228125", "Venezuela"),
        AdvancedOption("235644", "Czechoslovakia"),
        AdvancedOption("235771", "Palestine"),
        AdvancedOption("236597", "Liechtenstein"),
        AdvancedOption("237147", "Sudan"),
    )

    private fun advancedTypeOptions(archive: Int = selectedArchive): List<AdvancedOption> {
        if (sanitizeArchive(archive) == 3) {
            val remote = archive3Options("types", includeAll = true)
            if (remote.size > 1) return remote
            return listOf(
                AdvancedOption("all", t("همه", "All")),
                AdvancedOption("movie", t("فیلم", "Movie")),
                AdvancedOption("series", t("سریال", "Series")),
                AdvancedOption("animation", t("انیمیشن", "Animation")),
                AdvancedOption("anime", t("انیمه", "Anime"))
            )
        }
        return listOf(
            AdvancedOption("all", t("همه", "All")),
            AdvancedOption("movie", t("فیلم", "Movie")),
            AdvancedOption("series", t("سریال", "Series"))
        )
    }

    private fun advancedSortOptions(archive: Int): List<AdvancedOption> {
        return if (archive == 2) {
            listOf(
                AdvancedOption("", t("پیش‌فرض", "Default")),
                AdvancedOption("newest", t("جدیدترین", "Newest")),
                AdvancedOption("oldest", t("قدیمی‌ترین", "Oldest")),
                AdvancedOption("rating", t("امتیاز IMDb", "IMDb rating"))
            )
        } else if (archive == 3) {
            val remote = archive3Options("sorts", includeAll = false)
            if (remote.isNotEmpty()) remote else listOf(
                AdvancedOption("newest", t("جدیدترین", "Newest")),
                AdvancedOption("rating", t("امتیاز IMDb", "IMDb rating")),
                AdvancedOption("year_desc", t("سال انتشار", "Release year")),
                AdvancedOption("title", t("عنوان", "Title"))
            )
        } else {
            listOf(
                AdvancedOption("newest", t("جدیدترین", "Newest")),
                AdvancedOption("modified", t("به‌روزترین", "Recently updated")),
                AdvancedOption("popular", t("محبوب‌ترین", "Most popular")),
                AdvancedOption("imdb_rate", t("امتیاز IMDb", "IMDb rating")),
                AdvancedOption("release", t("سال انتشار", "Release year"))
            )
        }
    }

    private fun advancedRatingOptions(archive: Int): List<AdvancedOption> {
        if (sanitizeArchive(archive) == 3) {
            val remote = archive3Options("imdb_scores", includeAll = true)
            if (remote.size > 1) return remote
        }
        val out = mutableListOf(AdvancedOption("", t("همه امتیازها", "Any rating")))
        for (score in 9 downTo 5) {
            out.add(AdvancedOption(score.toString(), t("بالاتر از $score", "Above $score")))
        }
        if (archive == 1) out.add(AdvancedOption("4", t("کمتر از ۵", "Below 5")))
        return out
    }

    private fun advancedLanguageOptions(archive: Int): List<AdvancedOption> {
        if (sanitizeArchive(archive) == 3) {
            val remote = archive3Options("languages", includeAll = false)
            if (remote.isNotEmpty()) return remote
        }
        return listOf(
            AdvancedOption("", t("همه زبان‌ها", "Any language")),
            AdvancedOption("دوبله", t("دوبله", "Dubbed")),
            AdvancedOption("زیرنویس", t("زیرنویس", "Subtitled"))
        )
    }

    private fun advancedOptionLabel(options: List<AdvancedOption>, value: String): String {
        return options.firstOrNull { it.value == value }?.label ?: t("همه", "All")
    }

    private fun pickAdvancedOption(
        title: String,
        options: List<AdvancedOption>,
        currentValue: String,
        onSelected: (AdvancedOption) -> Unit
    ) {
        val labels = options.map { it.label }.toTypedArray()
        val selected = options.indexOfFirst { it.value == currentValue }.coerceAtLeast(0)
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels, selected) { dialog, which ->
                options.getOrNull(which)?.let(onSelected)
                dialog.dismiss()
            }
            .setNegativeButton(t("انصراف", "Cancel"), null)
            .show()
    }

    private fun advancedSearchUrl(state: AdvancedSearchState, page: Int, limit: Int): String {
        val params = mutableListOf<String>()
        fun add(name: String, value: String) {
            if (value.isNotBlank()) params.add("${enc(name)}=${enc(value)}")
        }

        add("page", page.toString())
        add("limit", limit.toString())
        add("s", state.query)
        add("type", state.type)

        if (state.archive == 2) {
            add("action", "search")
            add("archive", "2")
            add("q", state.query)
            add("genre", state.genreValue)
            add("year_from", state.yearFrom)
            add("year_to", state.yearTo)
            add("country", state.countryValue)
            add("sort", state.sortValue)
            add("rating", state.ratingValue)
            if (state.dubbed) add("dubbed", "1")
            if (state.subtitle) add("subtitle", "1")
            return "$apiBase?${params.joinToString("&")}"
        }

        if (state.archive == 3) {
            add("genre", state.genreValue)
            add("year", state.exactYear)
            add("fromYear", state.yearFrom)
            add("toYear", state.yearTo)
            add("imdbScore", state.ratingValue)
            add("sort", state.sortValue.ifBlank { "newest" })
            add("lang", state.language)
            if (state.dubbed) add("dubbed", "1")
            if (state.subtitle) add("subtitle", "1")
            return "$archive3ApiBase?${params.joinToString("&")}"
        }

        add("advanced", "1")
        add("genre_id", state.genreValue)
        add("year_from", state.yearFrom)
        add("year_to", state.yearTo)
        add("country_id", state.countryValue)
        add("sortby", state.sortValue)
        add("rating", state.ratingValue)
        if (state.dubbed) add("dubbed", "1")
        if (state.subtitle) add("subtitle", "1")
        return "$archive1LiveApiBase?${params.joinToString("&")}"
    }


    private fun advancedFilterCount(state: AdvancedSearchState): Int {
        var count = 0
        if (state.type != "all") count++
        if (state.genreValue.isNotBlank()) count++
        if (state.archive != 3 && state.countryValue.isNotBlank()) count++
        if (state.yearFrom.isNotBlank() || state.yearTo.isNotBlank()) count++
        if (state.ratingValue.isNotBlank()) count++
        if (state.sortValue.isNotBlank()) count++
        if (state.exactYear.isNotBlank()) count++
        if (state.language.isNotBlank()) count++
        if (state.dubbed) count++
        if (state.subtitle) count++
        return count
    }

    private fun showAdvancedFiltersDialog(
        input: EditText,
        preset: AdvancedSearchState?,
        onSubmit: (AdvancedSearchState) -> Unit
    ) {
        val p = UiPreferences.palette(this)
        val archive = selectedArchive
        val state = if (preset != null && preset.archive == archive) {
            preset.copy()
        } else {
            AdvancedSearchState(
                archive = archive,
                query = input.text?.toString()?.trim().orEmpty(),
                type = searchRestoreFilter
            )
        }

        lateinit var dialog: AlertDialog
        val rootView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.background)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(12), dp(18), dp(10))
            background = rounded(p.panel, 0, p.stroke)

            addView(TextView(this@MainActivity).apply {
                text = t("فیلترها", "Filters")
                setTextColor(p.text)
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, dp(50), 1f))

            addView(svgIconButton(R.drawable.ic_player_back) {
                dialog.dismiss()
            }, LinearLayout.LayoutParams(dp(48), dp(48)))
        }
        rootView.addView(header, LinearLayout.LayoutParams(-1, dp(70)))

        val scroll = BankmovieSmoothScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(24))
        }
        scroll.addView(body, FrameLayout.LayoutParams(-1, -2))
        rootView.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        fun sectionTitle(title: String, subtitle: String = "") {
            body.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(3), dp(9), dp(3), dp(8))
                addView(TextView(this@MainActivity).apply {
                    text = title
                    setTextColor(p.text)
                    textSize = 14f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                if (subtitle.isNotBlank()) {
                    addView(TextView(this@MainActivity).apply {
                        text = subtitle
                        setTextColor(p.muted)
                        textSize = 10.8f
                        gravity = Gravity.RIGHT
                        setPadding(0, dp(3), 0, 0)
                    })
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        body.addView(TextView(this).apply {
            text = t(
                "نتایج از آرشیو $archive نمایش داده می‌شوند",
                "Results will be loaded from Archive $archive"
            )
            setTextColor(p.primary)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            background = rounded(
                Color.argb(
                    if (p.light) 24 else 42,
                    Color.red(p.primary),
                    Color.green(p.primary),
                    Color.blue(p.primary)
                ),
                dp(14),
                Color.argb(
                    90,
                    Color.red(p.primary),
                    Color.green(p.primary),
                    Color.blue(p.primary)
                )
            )
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        sectionTitle(
            t("دسته‌بندی", "Category"),
            t("نوع محتوای موردنظر را انتخاب کنید", "Choose the content type")
        )

        val typeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        val typeChips = mutableMapOf<String, TextView>()

        fun renderTypes() {
            typeChips.forEach { (key, view) ->
                val active = state.type == key
                view.setTextColor(if (active) p.onPrimary else p.muted)
                view.background = if (active) {
                    rounded(p.primary, dp(18), p.primary2)
                } else {
                    rounded(p.card, dp(18), p.stroke)
                }
            }
        }

        advancedTypeOptions(archive).forEach { option ->
            val chip = TextView(this).apply {
                text = option.label
                gravity = Gravity.CENTER
                textSize = 12.4f
                typeface = Typeface.DEFAULT_BOLD
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 18, 1.025f, 0f)
                setOnClickListener {
                    state.type = option.value
                    renderTypes()
                }
            }
            typeChips[option.value] = chip
            typeRow.addView(
                chip,
                LinearLayout.LayoutParams(0, dp(46), 1f).apply {
                    marginStart = dp(4)
                    marginEnd = dp(4)
                }
            )
        }
        renderTypes()
        body.addView(typeRow, LinearLayout.LayoutParams(-1, dp(46)).apply {
            bottomMargin = dp(12)
        })

        sectionTitle(
            t("فیلترهای اصلی", "Main filters"),
            t("برای انتخاب هر مورد روی آن بزنید", "Tap each row to choose")
        )

        fun selectorRow(
            title: String,
            icon: Int,
            options: List<AdvancedOption>,
            valueProvider: () -> String,
            onSelected: (AdvancedOption) -> Unit
        ): View {
            val valueText = TextView(this).apply {
                text = advancedOptionLabel(options, valueProvider())
                setTextColor(p.muted)
                textSize = 11.8f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }

            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(13), dp(8), dp(13), dp(8))
                background = bankGlassDrawable(16, 224, 58, false)
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 16, 1.02f, 0f)
                setOnClickListener {
                    pickAdvancedOption(
                        title,
                        options,
                        valueProvider()
                    ) { option ->
                        onSelected(option)
                        valueText.text = option.label
                    }
                }

                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon)
                    setColorFilter(p.primary)
                }, LinearLayout.LayoutParams(dp(23), dp(23)).apply {
                    marginStart = dp(10)
                })

                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.RIGHT
                    addView(TextView(this@MainActivity).apply {
                        text = title
                        setTextColor(p.text)
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                    })
                    addView(valueText, LinearLayout.LayoutParams(-1, -2).apply {
                        topMargin = dp(2)
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))

                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_chevron_left)
                    setColorFilter(p.faint)
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(24), dp(40)))
            }
        }

        val genreOptions = when (archive) {
            2 -> archive2GenreOptions()
            3 -> archive3GenreOptions()
            else -> archive1GenreOptions()
        }
        val countryOptions = decorateCountryOptions(
            if (archive == 2) archive2CountryOptions() else archive1CountryOptions()
        )
        val ratingOptions = advancedRatingOptions(archive)
        val sortOptions = advancedSortOptions(archive)

        body.addView(
            selectorRow(
                t("ژانر", "Genre"),
                R.drawable.ic_nav_filter,
                genreOptions,
                { state.genreValue }
            ) { option ->
                state.genreValue = option.value
                state.genreLabel = option.label
            },
            LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) }
        )

        if (archive != 3) {
            body.addView(
                selectorRow(
                    t("کشور", "Country"),
                    R.drawable.ic_archive_globe,
                    countryOptions,
                    { state.countryValue }
                ) { option ->
                    state.countryValue = option.value
                    state.countryLabel = option.label
                },
                LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) }
            )
        } else {
            state.countryValue = ""
            state.countryLabel = ""
            state.director = ""
            state.actor = ""
        }

        body.addView(
            selectorRow(
                t("امتیاز IMDb", "IMDb rating"),
                R.drawable.ic_info_badge,
                ratingOptions,
                { state.ratingValue }
            ) { option ->
                state.ratingValue = option.value
                state.ratingLabel = option.label
            },
            LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(8) }
        )

        body.addView(
            selectorRow(
                t("مرتب‌سازی", "Sort by"),
                R.drawable.ic_player_list,
                sortOptions,
                { state.sortValue }
            ) { option ->
                state.sortValue = option.value
                state.sortLabel = option.label
            },
            LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(14) }
        )

        if (archive == 3) {
            val yearOptions = archive3YearOptions()
            body.addView(
                selectorRow(
                    t("سال دقیق انتشار", "Exact release year"),
                    R.drawable.ic_info_badge,
                    yearOptions,
                    { state.exactYear }
                ) { option ->
                    state.exactYear = option.value
                },
                LinearLayout.LayoutParams(-1, dp(64)).apply { bottomMargin = dp(12) }
            )
        }

        sectionTitle(
            t("محدوده سال ساخت", "Release year range"),
            t("یک یا هر دو مقدار را می‌توانید وارد کنید", "You may enter one or both values")
        )

        fun yearInput(hintText: String, initial: String): EditText {
            return EditText(this).apply {
                hint = hintText
                setText(initial)
                inputType = InputType.TYPE_CLASS_NUMBER
                setTextColor(p.text)
                setHintTextColor(p.faint)
                textSize = 13f
                gravity = Gravity.CENTER
                setSingleLine(true)
                background = bankGlassDrawable(16, 224, 58, false)
                setPadding(dp(8), 0, dp(8), 0)
            }
        }

        val years = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val yearFromInput = yearInput(t("از سال", "From year"), state.yearFrom)
        val yearToInput = yearInput(t("تا سال", "To year"), state.yearTo)
        years.addView(
            yearFromInput,
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginEnd = dp(4) }
        )
        years.addView(
            yearToInput,
            LinearLayout.LayoutParams(0, dp(58), 1f).apply { marginStart = dp(4) }
        )
        body.addView(years, LinearLayout.LayoutParams(-1, dp(58)).apply {
            bottomMargin = dp(14)
        })

        sectionTitle(t("دوبله و زیرنویس", "Dubbed and subtitles"))

        val flags = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }

        fun flagChip(
            label: String,
            initial: Boolean,
            onChange: (Boolean) -> Unit
        ): TextView {
            var active = initial
            fun render(view: TextView) {
                view.text = (if (active) "✓  " else "") + label
                view.setTextColor(if (active) p.onPrimary else p.text)
                view.background = if (active) {
                    rounded(p.primary, dp(17), p.primary2)
                } else {
                    rounded(p.card, dp(17), p.stroke)
                }
            }
            return TextView(this).apply {
                gravity = Gravity.CENTER
                textSize = 12.3f
                typeface = Typeface.DEFAULT_BOLD
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 17, 1.025f, 0f)
                render(this)
                setOnClickListener {
                    active = !active
                    onChange(active)
                    render(this)
                }
            }
        }

        flags.addView(
            flagChip(t("دوبله فارسی", "Persian dub"), state.dubbed) {
                state.dubbed = it
                state.language = when {
                    state.dubbed && !state.subtitle -> "دوبله"
                    state.subtitle && !state.dubbed -> "زیرنویس"
                    else -> ""
                }
            },
            LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(4) }
        )
        flags.addView(
            flagChip(t("زیرنویس فارسی", "Persian subtitle"), state.subtitle) {
                state.subtitle = it
                state.language = when {
                    state.dubbed && !state.subtitle -> "دوبله"
                    state.subtitle && !state.dubbed -> "زیرنویس"
                    else -> ""
                }
            },
            LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(4) }
        )
        body.addView(flags, LinearLayout.LayoutParams(-1, dp(50)))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(10), dp(16), dp(14))
            background = rounded(p.panel, 0, p.stroke)
        }

        val applyButton = TextView(this).apply {
            text = t("اعمال فیلتر", "Apply filters")
            gravity = Gravity.CENTER
            setTextColor(p.onPrimary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(p.primary, dp(17), p.primary2)
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 17, 1.03f, 0f)
            setOnClickListener {
                state.query = input.text?.toString()?.trim().orEmpty()
                state.yearFrom = yearFromInput.text?.toString()?.trim().orEmpty()
                state.yearTo = yearToInput.text?.toString()?.trim().orEmpty()
                if (archive == 3) {
                    state.countryValue = ""
                    state.countryLabel = ""
                    state.director = ""
                    state.actor = ""
                    if (state.language.isBlank()) {
                        state.language = when {
                            state.dubbed && !state.subtitle -> "دوبله"
                            state.subtitle && !state.dubbed -> "زیرنویس"
                            else -> ""
                        }
                    }
                }

                val from = state.yearFrom.toIntOrNull()
                val to = state.yearTo.toIntOrNull()
                if (from != null && to != null && from > to) {
                    Toast.makeText(
                        this@MainActivity,
                        t(
                            "سال شروع نباید از سال پایان بزرگ‌تر باشد",
                            "Start year cannot be greater than end year"
                        ),
                        Toast.LENGTH_SHORT
                    ).show()
                } else {
                    dialog.dismiss()
                    onSubmit(state.copy())
                }
            }
        }

        val resetButton = TextView(this).apply {
            text = t("پاک‌کردن", "Reset")
            gravity = Gravity.CENTER
            setTextColor(p.text)
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            background = bankGlassDrawable(17, 224, 58, false)
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 17, 1.025f, 0f)
            setOnClickListener {
                dialog.dismiss()
                showAdvancedFiltersDialog(
                    input,
                    AdvancedSearchState(archive = archive),
                    onSubmit
                )
            }
        }

        actions.addView(
            applyButton,
            LinearLayout.LayoutParams(0, dp(54), 1.55f).apply { marginEnd = dp(4) }
        )
        actions.addView(
            resetButton,
            LinearLayout.LayoutParams(0, dp(54), 1f).apply { marginStart = dp(4) }
        )
        rootView.addView(actions, LinearLayout.LayoutParams(-1, dp(78)))

        dialog = AlertDialog.Builder(this)
            .setView(rootView)
            .create()

        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(-1, -1)
            dialog.window?.setDimAmount(0.35f)
        }
        dialog.show()
        styleShownDialog(dialog, rootView, preferredFocus = input, fullScreen = true, dimAmount = 0.35f)
    }

    private fun advancedSearchAccordion(
        input: EditText,
        preset: AdvancedSearchState?,
        initiallyOpen: Boolean,
        onSubmit: (AdvancedSearchState) -> Unit
    ): View {
        val p = UiPreferences.palette(this)
        val archive = selectedArchive
        val state = if (preset != null && preset.archive == archive) {
            preset.copy()
        } else {
            AdvancedSearchState(
                archive = archive,
                query = input.text?.toString()?.trim().orEmpty(),
                type = searchRestoreFilter
            )
        }
        val count = advancedFilterCount(state)

        val wrapper = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.TRANSPARENT)
        }

        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }

        val advancedLabel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(dp(10), dp(7), dp(10), dp(7))

            addView(TextView(this@MainActivity).apply {
                text = t("جستجوی پیشرفته", "Advanced search")
                setTextColor(p.text)
                textSize = 13.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })

            addView(View(this@MainActivity).apply {
                setBackgroundColor(p.primary)
            }, LinearLayout.LayoutParams(-1, dp(2)).apply {
                topMargin = dp(5)
            })
        }
        tabs.addView(advancedLabel, LinearLayout.LayoutParams(0, dp(48), 1f))

        val filterButton = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            background = bankGlassDrawable(16, 224, 58, false)
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 16, 1.025f, 0f)
            setOnClickListener {
                showAdvancedFiltersDialog(input, state.copy(), onSubmit)
            }

            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_nav_filter)
                setColorFilter(p.primary)
            }, LinearLayout.LayoutParams(dp(21), dp(21)).apply {
                marginStart = dp(7)
            })

            addView(TextView(this@MainActivity).apply {
                text = if (count > 0) {
                    t("فیلترها  ($count)", "Filters  ($count)")
                } else {
                    t("فیلترها", "Filters")
                }
                setTextColor(p.text)
                textSize = 12.6f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
        tabs.addView(
            filterButton,
            LinearLayout.LayoutParams(0, dp(44), 0.82f).apply {
                marginStart = dp(6)
            }
        )

        wrapper.addView(tabs, LinearLayout.LayoutParams(-1, dp(50)))

        if (count > 0) {
            wrapper.addView(TextView(this).apply {
                text = advancedSearchSummary(state)
                setTextColor(p.muted)
                textSize = 10.6f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                background = bankGlassDrawable(13, 236, 70, true)
                setPadding(dp(11), dp(7), dp(11), dp(7))
            }, LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(5)
            })
        }

        if (initiallyOpen) {
            wrapper.post {
                showAdvancedFiltersDialog(input, state.copy(), onSubmit)
            }
        }

        return wrapper
    }

    private fun advancedSearchSummary(state: AdvancedSearchState): String {
        val values = mutableListOf<String>()
        values.add(archiveLabel(state.archive))
        advancedTypeOptions(state.archive).firstOrNull { it.value == state.type }?.label?.let { values.add(it) }
        if (state.genreValue.isNotBlank()) values.add(state.genreLabel.ifBlank { state.genreValue })
        if (state.archive != 3 && state.countryValue.isNotBlank()) values.add(state.countryLabel.ifBlank { state.countryValue })
        if (state.yearFrom.isNotBlank() || state.yearTo.isNotBlank()) {
            values.add("${state.yearFrom.ifBlank { "…" }}–${state.yearTo.ifBlank { "…" }}")
        }
        if (state.exactYear.isNotBlank()) values.add(state.exactYear)
        if (state.ratingValue.isNotBlank()) values.add("IMDb ${state.ratingValue}+")
        if (state.dubbed) values.add(t("دوبله", "Dubbed"))
        if (state.subtitle) values.add(t("زیرنویس", "Subtitle"))
        return values.joinToString("  •  ")
    }

    private fun showAdvancedSearchResults(state: AdvancedSearchState) {
        // PASS 4.10: advanced search uses the same catalogue grid and infinite paging.
        currentScreen = "search"
        rememberCurrentScreen { showAdvancedSearchResults(state.copy()) }
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE
        topBar.visibility = View.GONE

        val p = UiPreferences.palette(this)
        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            setBackgroundColor(p.background)
            setPadding(0, 0, 0, dp(24))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (tv) 16 else 10), dp(if (tv) 16 else 10), dp(if (tv) 16 else 10), dp(28))
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        attachSmartHeader(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@MainActivity).apply {
                text = t("نتایج جستجوی پیشرفته", "Advanced search results")
                setTextColor(p.text)
                textSize = 18f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, dp(46), 1f))
            addView(svgIconButton(R.drawable.ic_player_back) {
                showSearch(initialQuery = state.query, initialFilter = state.type, advancedPreset = state.copy(), openAdvanced = true)
            }, LinearLayout.LayoutParams(dp(44), dp(44)))
        }
        page.addView(header, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })

        val summaryRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = bankGlassDrawable(17, 222, 50, true)
            setPadding(dp(11), dp(7), dp(11), dp(7))
            addView(TextView(this@MainActivity).apply {
                text = advancedSearchSummary(state)
                setTextColor(p.muted)
                textSize = 10.8f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@MainActivity).apply {
                text = t("ویرایش", "Edit")
                setTextColor(p.primary)
                textSize = 11.2f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.CENTER
                background = bankTintGlassDrawable(p.primary, 14, 180, 0.12f)
                isClickable = true
                setOnClickListener {
                    showSearch(initialQuery = state.query, initialFilter = state.type, advancedPreset = state.copy(), openAdvanced = true)
                }
            }, LinearLayout.LayoutParams(dp(62), dp(34)).apply { marginStart = dp(8) })
        }
        page.addView(summaryRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW, tall = true)
        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            useDefaultMargins = false
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))

        val loadingMore = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleSmall).apply {
                isIndeterminate = true
                indeterminateTintList = android.content.res.ColorStateList.valueOf(p.primary)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = t("در حال بارگذاری نتایج...", "Loading results...")
                setTextColor(p.muted)
                textSize = 11.2f
            })
        }
        page.addView(loadingMore, LinearLayout.LayoutParams(-1, dp(50)))

        val seen = mutableSetOf<String>()
        var loading = false
        var hasMore = true
        var nextPage = 1
        val perPage = if (tv) 48 else 30
        val maxPages = 20

        fun keyOf(item: JSONObject): String = item.optString("id")
            .ifBlank { item.optString("slug") }
            .ifBlank { item.optString("source_url") }
            .ifBlank { item.optString("title_fa") + item.optString("poster") }

        fun loadPage(pageNumber: Int) {
            if (loading || !hasMore || pageNumber > maxPages) return
            loading = true
            loadingMore.visibility = View.VISIBLE
            fetchArchive(advancedSearchUrl(state, pageNumber, perPage), state.archive) { ok, json, err ->
                runOnUiThread {
                    loading = false
                    loadingMore.visibility = View.GONE
                    if (!ok || json == null) {
                        if (grid.childCount == 0) {
                            page.addView(emptyStateBox(t("جستجو انجام نشد", "Search failed"), friendlyError(err)), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
                        }
                        return@runOnUiThread
                    }
                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(searchCatalogueCard(item, cardW, cardH))
                            added++
                        }
                    }
                    if (grid.childCount == 0 && arr.length() == 0) {
                        page.addView(emptyStateBox(t("نتیجه‌ای پیدا نشد", "No results"), t("فیلترها را کمی بازتر انتخاب کنید", "Try broader filters")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
                        hasMore = false
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }
                    val serverNext = json.optInt("next_page", pageNumber + 1)
                    nextPage = if (serverNext > pageNumber) serverNext else pageNumber + 1
                    hasMore = pageNumber < maxPages && added > 0 && (
                        json.optBoolean("has_more", false) ||
                        json.optBoolean("has_next_page", false) ||
                        json.optInt("next_page", 0) > pageNumber ||
                        arr.length() >= perPage
                    )
                    applyTvFocusToClickableTree(grid)
                    if (!tv && hasMore) scroll.post {
                        if (page.height - (scroll.scrollY + scroll.height) < dp(500)) loadPage(nextPage)
                    }
                }
            }
        }

        scroll.setOnScrollChangeListener { _, _, sy, _, _ ->
            if (!loading && hasMore && page.height - (sy + scroll.height) < dp(if (tv) 900 else 720)) loadPage(nextPage)
        }
        loadPage(1)
        BankmovieFonts.applyToTree(this, page)
    }


    private fun showSearch(
        initialQuery: String = "",
        initialFilter: String = "all",
        showAllResults: Boolean = false,
        advancedPreset: AdvancedSearchState? = null,
        openAdvanced: Boolean = false
    ) {
        // PASS 4.10: search is now a direct catalogue grid. No legacy suggestion list,
        // no "load more" button; the next page is fetched automatically near the end.
        currentScreen = "search"
        searchRestoreQuery = initialQuery
        searchRestoreFilter = if (initialFilter in listOf("all", "movie", "series", "animation", "anime")) initialFilter else "all"
        searchRestoreShowAll = true
        updateSearchRestorer()
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE
        topBar.visibility = View.GONE

        val tv = isTvLike()
        val p = UiPreferences.palette(this)
        val rootFrame = FrameLayout(this).apply { setBackgroundColor(bg) }
        content.addView(rootFrame)

        val scroll = BankmovieSmoothScrollView(this).apply {
            isFillViewport = false
            clipToPadding = false
            setPadding(0, 0, 0, dp(if (tv) 42 else 28))
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // Keep the search controls clear of centered punch-hole cameras/status icons.
            setPadding(dp(if (tv) 18 else 7), dp(if (tv) 16 else 30), dp(if (tv) 18 else 7), dp(24))
            if (tv) {
                gravity = Gravity.LEFT
                layoutDirection = View.LAYOUT_DIRECTION_LTR
            }
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        rootFrame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        attachSmartHeader(scroll)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        val searchBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = bankGlassDrawable(22, 232, 58, true)
            setPadding(dp(12), 0, dp(12), 0)
        }
        searchBox.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_search_clean)
            setColorFilter(p.text)
        }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginStart = dp(8) })
        val input = EditText(this).apply {
            hint = t("نام فیلم، سریال یا انیمه...", "Movie, series or anime...")
            setHintTextColor(p.muted)
            setTextColor(p.text)
            textSize = if (tv) 15.5f else 14.4f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setSingleLine(true)
            background = null
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_AUTO_CORRECT
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH
            if (Build.VERSION.SDK_INT >= 21) showSoftInputOnFocus = true
        }
        searchBox.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        val clearBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_close_clean)
            setColorFilter(p.muted)
            setPadding(dp(3), dp(3), dp(3), dp(3))
            visibility = View.GONE
        }
        searchBox.addView(clearBtn, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(5) })
        header.addView(searchBox, LinearLayout.LayoutParams(0, dp(50), 1f))
        header.addView(FrameLayout(this).apply {
            background = bankGlassDrawable(999, 220, 54, false)
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 999)
            setOnClickListener { showHome() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_player_back)
                setColorFilter(p.text)
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(8) })
        page.addView(header, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })

        // Search is archive-driven. Media-type tabs duplicated advanced filters.
        val filterState = arrayOf("all")
        page.addView(TextView(this).apply {
            text = t("از آرشیوهای مختلف تست کنید تا نتیجه موردنظر پیدا شود.", "Try different archives to find the result you want.")
            setTextColor(p.muted)
            textSize = 11.7f
            gravity = Gravity.RIGHT
            setPadding(dp(4), dp(3), dp(4), dp(9))
        }, LinearLayout.LayoutParams(-1, -2))

        if (anyArchiveVisible()) {
            page.addView(archiveSwitchBar { _ ->
                searchRestoreQuery = input.text?.toString()?.trim().orEmpty()
                searchRestoreFilter = filterState[0]
                searchRestoreShowAll = true
                showSearch(searchRestoreQuery, searchRestoreFilter, true, advancedPreset, false)
            }, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(7) })
        }

        if (!archiveEnabled(selectedArchive)) {
            page.addView(emptyStateBox(
                t("آرشیو فعالی وجود ندارد", "No active archive"),
                t("از پنل مدیریت حداقل یک آرشیو را فعال کن.", "Enable at least one archive from the admin panel.")
            ), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
            BankmovieFonts.applyToTree(this, page)
            return
        }

        if (AccountSession.advancedSearchEnabled(this)) {
            val filterButton = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                background = bankGlassDrawable(18, 210, 46, false)
                setPadding(dp(12), 0, dp(12), 0)
                isClickable = true
                isFocusable = true
                applyMobileTouchHalo(this, 18)
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_nav_filter)
                    setColorFilter(p.primary)
                }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(7) })
                addView(TextView(this@MainActivity).apply {
                    text = if (openAdvanced) t("بستن فیلترها", "Close filters") else t("فیلترهای بیشتر", "More filters")
                    setTextColor(p.text)
                    textSize = 12.7f
                    typeface = BankmovieFonts.medium(this@MainActivity)
                })
                setOnClickListener {
                    showSearch(input.text?.toString()?.trim().orEmpty(), filterState[0], true, advancedPreset, !openAdvanced)
                }
            }
            page.addView(filterButton, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(if (openAdvanced) 7 else 10) })
            if (openAdvanced) {
                page.addView(advancedSearchAccordion(input, advancedPreset, true) { state ->
                    showAdvancedSearchResults(state)
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
            }
        }

        val resultHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE
        }
        val resultTitle = TextView(this).apply {
            setTextColor(p.text)
            textSize = 15.2f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        resultHeader.addView(resultTitle, LinearLayout.LayoutParams(0, dp(36), 1f))
        val resultCount = TextView(this).apply {
            setTextColor(p.muted)
            textSize = 10.8f
            gravity = Gravity.CENTER
            background = bankGlassDrawable(999, 176, 34, false)
            setPadding(dp(9), 0, dp(9), 0)
        }
        resultHeader.addView(resultCount, LinearLayout.LayoutParams(-2, dp(28)).apply { marginStart = dp(8) })
        page.addView(resultHeader, LinearLayout.LayoutParams(-1, dp(36)).apply { bottomMargin = dp(5) })

        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            useDefaultMargins = false
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))

        val loadingMore = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(0, dp(9), 0, dp(9))
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleSmall).apply {
                isIndeterminate = true
                indeterminateTintList = android.content.res.ColorStateList.valueOf(p.primary)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = t("در حال آوردن نتایج بعدی...", "Loading more results...")
                setTextColor(p.muted)
                textSize = 11.3f
            })
        }
        page.addView(loadingMore, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4) })

        val emptyHint = TextView(this).apply {
            text = t("نام فیلم یا سریال را بنویس؛ نتایج مستقیم همین‌جا ظاهر می‌شوند.", "Type a movie or series name; results appear here instantly.")
            setTextColor(p.muted)
            textSize = 12.6f
            gravity = Gravity.CENTER
            background = bankGlassDrawable(20, 188, 42, false)
            setPadding(dp(18), dp(18), dp(18), dp(18))
        }
        page.addView(emptyHint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        val seen = mutableSetOf<String>()
        var generation = 0
        var nextPage = 1
        var hasMore = false
        var loading = false
        var activeQuery = ""
        val perPage = if (tv) 48 else 30
        val maxPages = 20
        val cardW = if (tv) tvGridCardWidth() else {
            val maximum = ((resources.displayMetrics.widthPixels - dp(14)) / 3) - dp(6)
            (mobileGridCardWidth() + dp(4)).coerceAtMost(maximum)
        }
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW, tall = true)
        val debounce = Handler(Looper.getMainLooper())
        var pendingSearch: Runnable? = null

        fun keyOf(item: JSONObject): String = item.optString("id")
            .ifBlank { item.optString("movie_id") }
            .ifBlank { item.optString("slug") }
            .ifBlank { item.optString("source_url") }
            .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }

        fun loadPage(pageNumber: Int, token: Int) {
            if (loading || pageNumber > maxPages || activeQuery.length < 2) return
            loading = true
            loadingMore.visibility = View.VISIBLE
            val archive = selectedArchive
            val query = activeQuery
            val type = filterState[0]
            fetchArchive(archiveSearchUrl(archive, query, pageNumber, perPage, type, false), archive) { ok, json, err ->
                runOnUiThread {
                    if (token != generation || query != activeQuery || type != filterState[0]) return@runOnUiThread
                    loading = false
                    loadingMore.visibility = View.GONE
                    if (!ok || json == null) {
                        if (grid.childCount == 0) {
                            emptyHint.visibility = View.VISIBLE
                            emptyHint.text = friendlyError(err)
                        }
                        return@runOnUiThread
                    }
                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (!searchAcceptsType(item, type)) continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(searchCatalogueCard(item, cardW, cardH))
                            added++
                        }
                    }
                    resultCount.text = if (isFa()) persianDigits(seen.size.toString()) else seen.size.toString()
                    if (grid.childCount == 0) {
                        emptyHint.visibility = View.VISIBLE
                        emptyHint.text = t("نتیجه‌ای پیدا نشد؛ عبارت کوتاه‌تر یا تب دیگری را امتحان کن.", "No results. Try a shorter query or another tab.")
                    } else {
                        emptyHint.visibility = View.GONE
                    }
                    val serverNext = json.optInt("next_page", pageNumber + 1)
                    nextPage = if (serverNext > pageNumber) serverNext else pageNumber + 1
                    hasMore = pageNumber < maxPages && (
                        json.optBoolean("has_more", false) ||
                        json.optBoolean("has_next_page", false) ||
                        json.optInt("next_page", 0) > pageNumber ||
                        arr.length() >= perPage
                    )
                    applyTvFocusToClickableTree(grid)
                    if (!tv && hasMore) {
                        scroll.post {
                            val remain = page.height - (scroll.scrollY + scroll.height)
                            if (remain < dp(500)) loadPage(nextPage, token)
                        }
                    }
                }
            }
        }

        fun restartSearch(raw: String) {
            val query = raw.trim()
            searchRestoreQuery = query
            searchRestoreFilter = filterState[0]
            searchRestoreShowAll = true
            updateSearchRestorer()
            clearBtn.visibility = if (query.isBlank()) View.GONE else View.VISIBLE
            generation++
            activeQuery = query
            nextPage = 1
            hasMore = false
            loading = false
            seen.clear()
            grid.removeAllViews()
            loadingMore.visibility = View.GONE
            if (query.length < 2) {
                resultHeader.visibility = View.GONE
                emptyHint.visibility = View.VISIBLE
                emptyHint.text = t("نام فیلم یا سریال را بنویس؛ نتایج مستقیم همین‌جا ظاهر می‌شوند.", "Type a movie or series name; results appear here instantly.")
                return
            }
            resultHeader.visibility = View.VISIBLE
            resultTitle.text = if (isFa()) "نتایج «$query»" else "Results for “$query”"
            resultCount.text = "0"
            emptyHint.visibility = View.GONE
            loadPage(1, generation)
        }

        clearBtn.setOnClickListener {
            input.setText("")
            input.requestFocus()
        }
        input.setOnEditorActionListener { _, actionId, event ->
            val enterPressed = event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH || enterPressed) {
                pendingSearch?.let { debounce.removeCallbacks(it) }
                restartSearch(input.text?.toString().orEmpty())
                true
            } else false
        }
        var suppressWatcher = true
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                if (suppressWatcher) return
                pendingSearch?.let { debounce.removeCallbacks(it) }
                val value = s?.toString().orEmpty()
                pendingSearch = Runnable { restartSearch(value) }
                debounce.postDelayed(pendingSearch!!, 320L)
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        input.setText(initialQuery)
        input.setSelection(input.text?.length ?: 0)
        suppressWatcher = false
        if (initialQuery.trim().length >= 2) restartSearch(initialQuery) else if (!openAdvanced) input.requestFocus()

        scroll.setOnScrollChangeListener { _, _, sy, _, _ ->
            if (loading || !hasMore || activeQuery.length < 2) return@setOnScrollChangeListener
            val remaining = page.height - (sy + scroll.height)
            if (remaining < dp(if (tv) 900 else 720)) loadPage(nextPage, generation)
        }
        BankmovieFonts.applyToTree(this, page)
    }

    private fun liveSearch(page: LinearLayout, input: EditText, filter: String) {
        val q = input.text?.toString()?.trim() ?: ""
        if (q.length >= 2) doSearch(page, q, filter)
    }

    private fun doSearch(page: LinearLayout, q: String, typeFilter: String = "all") {
        searchRestoreQuery = q.trim()
        searchRestoreFilter = typeFilter
        searchRestoreShowAll = true
        updateSearchRestorer()
        while (page.childCount > 2) page.removeViewAt(2)
        val tv = isTvLike()
        if (tv) {
            page.gravity = Gravity.LEFT
            page.layoutDirection = View.LAYOUT_DIRECTION_LTR
        }

        // فقط سرچ واقعی: وقتی کاربر «مشاهده همه نتایج» می‌زند، دیگر سراغ سکشن‌های خانه/فیلم جدید/سریال جدید نمی‌رویم.
        // برای اینکه نتیجه‌ها گم نشوند، هر صفحه را بزرگ‌تر گرفتیم و تا ۱۰ صفحه اجازه ادامه می‌دهیم.
        val perPage = 100
        val maxSearchPages = 10
        val cardW = if (tv) tvGridCardWidth() else mobileGridCardWidth()
        val cardH = if (tv) tvGridCardHeight(cardW) else mobileGridCardHeight(cardW)

        val grid = GridLayout(this).apply {
            columnCount = if (tv) 8 else 3
            layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
            useDefaultMargins = false
        }
        val more = moreButton(ui("مشاهده نتایج بیشتر")) { }
        val loading = fancySpinnerText("در حال آوردن همه نتایج...", q)
        page.addView(loading, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(12) })
        page.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
        page.addView(more, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(if (tv) 86 else 110) })

        val seen = mutableSetOf<String>()
        var lastLoadedPage = 0

        fun keyOf(item: JSONObject): String {
            return item.optString("id")
                .ifBlank { item.optString("movie_id") }
                .ifBlank { item.optString("slug") }
                .ifBlank { item.optString("source_url") }
                .ifBlank { item.optString("title_fa") + item.optString("title") + item.optString("poster") }
        }

        fun moreLabel(): String {
            return if (tv) "${ui("مشاهده نتایج بیشتر")}  ${seen.size}" else ui("مشاهده نتایج بیشتر")
        }

        fun loadPage(p: Int) {
            if (p > maxSearchPages) {
                more.visibility = View.GONE
                return
            }
            lastLoadedPage = maxOf(lastLoadedPage, p)
            more.text = t("در حال بارگذاری...", "Loading...")
            more.visibility = View.VISIBLE
            more.isEnabled = false

            val archive = selectedArchive
            fetchArchive(archiveSearchUrl(archive, q, p, perPage, typeFilter, false), archive) { ok, json, err ->
                runOnUiThread {
                    loading.visibility = View.GONE
                    more.isEnabled = true
                    if (!ok || json == null) {
                        if (grid.childCount == 0) {
                            page.addView(emptyStateBox(ui("خطا در جستجو"), friendlyError(err)), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        }
                        more.text = ui("تلاش دوباره")
                        more.visibility = View.VISIBLE
                        more.setOnClickListener { loadPage(p) }
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val arr = json.optJSONArray("items") ?: JSONArray()
                    var added = 0
                    for (i in 0 until arr.length()) {
                        val item = arr.optJSONObject(i) ?: continue
                        if (!searchAcceptsType(item, typeFilter)) continue
                        val key = keyOf(item)
                        if (key.isBlank() || seen.add(key)) {
                            grid.addView(posterCard(item, cardW, cardH))
                            added++
                        }
                    }

                    if (arr.length() == 0 && grid.childCount == 0) {
                        page.addView(emptyStateBox(ui("چیزی پیدا نشد"), ui("تب همه یا کلمه کوتاه‌تر را امتحان کن")), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
                        more.visibility = View.GONE
                        applyTvFocusToClickableTree(page)
                        return@runOnUiThread
                    }

                    val next = json.optInt("next_page", p + 1).let { if (it > p) it else p + 1 }
                    val serverHasMore = json.optBoolean("has_more", false) || json.optInt("next_page", 0) > p
                    val guessedMore = arr.length() >= perPage
                    val safeMore = p < maxSearchPages && arr.length() > 0 && added > 0
                    val canLoadMore = serverHasMore || guessedMore || safeMore

                    if (canLoadMore && p < maxSearchPages) {
                        more.visibility = View.VISIBLE
                        more.text = moreLabel()
                        more.setOnClickListener { loadPage(next) }
                    } else {
                        more.visibility = View.GONE
                        if (added == 0 && p > 1) Toast.makeText(this, ui("نتیجه جدیدی باقی نمانده"), Toast.LENGTH_SHORT).show()
                    }
                    applyTvFocusToClickableTree(page)
                }
            }
        }
        loadPage(1)
    }

    private fun itemHasDubbedBadge(item: JSONObject): Boolean {
        if (item.optBoolean("has_dubbed", false)) return true
        val hay = listOf(
            item.optString("title"), item.optString("title_fa"), item.optString("update_note"),
            item.optString("quality"), item.optString("type_fa"), item.optString("display_label")
        ).joinToString(" ").lowercase(Locale.US)
        return hay.contains("دوبله") || hay.contains("dubbed") || hay.contains("dual audio") || hay.contains("چندصدا")
    }


    private fun isRenderableMediaItem(item: JSONObject): Boolean {
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { item.optString("name") }.trim()
        if (title.isBlank()) return false
        val normalized = title.lowercase(Locale.US).replace("ـ", "").trim()
        val invalid = setOf(
            "ارتباط", "عرض", "عض", "تماس", "منو", "خانه", "display", "width", "height",
            "contact", "none", "block", "flex", "grid", "auto", "hidden", "visible"
        )
        if (normalized in invalid) return false
        if (normalized.length <= 1) return false
        return true
    }

    private fun searchCatalogueCard(item: JSONObject, width: Int, height: Int): View {
        if (!isRenderableMediaItem(item)) return View(this).apply { visibility = View.GONE }
        val tv = isTvLike()
        val p = UiPreferences.palette(this)
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(2), dp(2), dp(2), dp(2))
            setTag(R.id.bm_tv_item_json, item.toString())
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 18)
            applyTvFocusHalo(this, 18, 1.045f, 0f)
            setOnClickListener { showDetail(item) }
            val side = if (tv) dp(6) else dp(3)
            layoutParams = ViewGroup.MarginLayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = side
                marginEnd = side
                bottomMargin = dp(if (tv) 15 else 9)
            }
        }
        val posterHeight = (height * if (tv) 0.78f else 0.80f).roundToInt()
        val frame = FrameLayout(this).apply {
            background = rounded(Color.BLACK, dp(15), Color.argb(62, 255,255,255))
            clipToOutline = true
        }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.rgb(8, 9, 12))
        }
        frame.addView(image, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, image)
        frame.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(12,0,0,0), Color.argb(125,0,0,0)))
        }, FrameLayout.LayoutParams(-1, -1))

        val year = item.optString("year").trim()
        if (year.isNotBlank() && year != "0" && !year.equals("null", true)) {
            frame.addView(TextView(this).apply {
                text = year
                setTextColor(Color.WHITE)
                textSize = if (tv) 9.4f else 9.7f
                typeface = BankmovieFonts.medium(this@MainActivity)
                gravity = Gravity.CENTER
                background = rounded(Color.argb(160, 4, 6, 10), dp(9), Color.argb(48,255,255,255))
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(6); leftMargin = dp(6) })
        }

        val rating = cleanRating(item.optString("rating"))
        if (rating.isNotBlank() && rating != "-") {
            frame.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                background = rounded(Color.rgb(247, 194, 24), dp(8), Color.argb(80,255,255,255))
                setPadding(dp(5), dp(2), dp(5), dp(2))
                addView(TextView(this@MainActivity).apply {
                    text = "IMDb"
                    setTextColor(Color.BLACK)
                    textSize = 8.3f
                    typeface = Typeface.DEFAULT_BOLD
                })
                addView(TextView(this@MainActivity).apply {
                    text = " $rating"
                    setTextColor(Color.BLACK)
                    textSize = 8.8f
                    typeface = Typeface.DEFAULT_BOLD
                })
            }, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.RIGHT).apply { bottomMargin = dp(6); rightMargin = dp(6) })
        }

        val hasDub = itemHasDubbedBadge(item)
        val hasSub = item.optBoolean("has_subtitle", false) || item.optBoolean("subtitle", false)
        if (hasDub || hasSub) {
            val badges = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM
                if (hasSub) addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_player_cc)
                    setColorFilter(Color.WHITE)
                    background = rounded(Color.argb(185, 5, 7, 10), dp(6), Color.argb(50,255,255,255))
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { bottomMargin = dp(3) })
                if (hasDub) addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_dubbed_mic_green)
                    background = rounded(Color.argb(185, 5, 10, 7), dp(6), Color.argb(50,255,255,255))
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(22), dp(22)))
            }
            frame.addView(badges, FrameLayout.LayoutParams(dp(24), -2, Gravity.BOTTOM or Gravity.LEFT).apply { bottomMargin = dp(6); leftMargin = dp(6) })
        }
        shell.addView(frame, LinearLayout.LayoutParams(-1, posterHeight))
        shell.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(p.text)
            textSize = if (tv) 11.6f else 11.8f
            typeface = BankmovieFonts.medium(this@MainActivity)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = if (tv) Gravity.CENTER else Gravity.LEFT
            setPadding(dp(2), dp(5), dp(2), 0)
        }, LinearLayout.LayoutParams(-1, dp(if (tv) 29 else 27)))
        return shell
    }

    private fun posterCard(item: JSONObject, width: Int, height: Int): View {
        if (!isRenderableMediaItem(item)) return View(this).apply { visibility = View.GONE }
        val tv = isTvLike()
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = bankGlassDrawable(24, 224, 58, false)
            setTag(R.id.bm_tv_item_json, item.toString())
            applyTvFocusHalo(this, if (tv) 24 else 26, if (tv) 1.055f else 1.065f, 0f)
            applyMobileTouchHalo(this, if (tv) 24 else 22)
            setOnClickListener {
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    showDetail(item)
                }.start()
            }
            val sideMargin = when {
                tv -> dp(7)
                currentScreen == "favorites" -> dp(1)
                else -> dp(mobileGridSideMarginDp())
            }
            layoutParams = ViewGroup.MarginLayoutParams(width, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                marginStart = sideMargin
                marginEnd = sideMargin
                bottomMargin = dp(if (tv) 18 else 14)
            }
        }

        val pf = FrameLayout(this).apply {
            background = rounded(Color.BLACK, dp(22), stroke)
            elevation = dp(10).toFloat()
            clipToOutline = true
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(Color.BLACK); adjustViewBounds = false }
        pf.addView(img, FrameLayout.LayoutParams(-1, -1))
        loadImage(item.optString("poster").ifBlank { item.optString("image") }.ifBlank { item.optString("cover_image") }.ifBlank { item.optString("backdrop") }, img)

        pf.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.argb(12,0,0,0), Color.argb(130,0,0,0)))
        }, FrameLayout.LayoutParams(-1, -1))

        fun yearChip(textValue: String): TextView {
            return TextView(this).apply {
                text = textValue
                setTextColor(white)
                textSize = if (tv) 9.2f else 9.7f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(155, 0, 0, 0), dp(13), Color.argb(55, 255, 255, 255))
                setPadding(dp(8), dp(3), dp(8), dp(3))
                maxLines = 1
            }
        }

        item.optString("year").trim().takeIf {
            it.isNotBlank() && !it.equals("null", true) && !it.equals("false", true) && it != "0"
        }?.let { year ->
            pf.addView(yearChip(year), FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.RIGHT).apply {
                topMargin = dp(9)
                rightMargin = dp(9)
            })
        }

        if (isWatched(item)) {
            val seenChip = FrameLayout(this).apply {
                background = rounded(Color.argb(205, 3, 8, 16), dp(15), Color.argb(130, 255, 255, 255))
                contentDescription = t("این عنوان را دیده‌اید", "You watched this title")
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_seen_eye)
                    setColorFilter(Color.WHITE)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(5), dp(5), dp(5), dp(5))
                }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            }
            pf.addView(seenChip, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.TOP or Gravity.LEFT).apply {
                topMargin = dp(8)
                leftMargin = dp(8)
            })
        }

        if (itemHasDubbedBadge(item)) {
            val dubbedChip = FrameLayout(this).apply {
                background = rounded(Color.argb(215, 2, 12, 7), dp(10), Color.argb(120, 33, 192, 64))
                contentDescription = "دارای دوبله فارسی"
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_dubbed_mic_green)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(4), dp(4), dp(4), dp(4))
                }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            }
            pf.addView(dubbedChip, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.BOTTOM or Gravity.LEFT).apply {
                bottomMargin = dp(7)
                leftMargin = dp(7)
            })
        }

        val posterHeight = (height * if (tv) 0.70f else 0.71f).toInt()
        wrap.addView(pf, LinearLayout.LayoutParams(-1, posterHeight))
        wrap.minimumHeight = posterHeight + dp(if (tv) 38 else 42)
        wrap.addView(TextView(this).apply {
            text = item.optString("title_fa").ifBlank { item.optString("title") }
            setTextColor(white)
            textSize = if (tv) 11.6f else 12.7f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            gravity = if (tv) Gravity.CENTER else Gravity.RIGHT
            includeFontPadding = true
            setLineSpacing(dp(2).toFloat(), 1.0f)
            setPadding(dp(3), dp(if (tv) 6 else 8), dp(3), dp(6))
        }, LinearLayout.LayoutParams(-1, -2))
        return wrap
    }

    private fun detailRequestKey(archive: Int, id: String, type: String, seed: JSONObject): String {
        // Stable across Home/Search/Collections/Weekly Schedule so the same title
        // reuses one device-local detail snapshot regardless of where it was opened from.
        val stableId = id.trim().ifBlank {
            seed.optString("imdb_code")
                .ifBlank { seed.optString("slug") }
                .ifBlank { seed.optString("source_url").ifBlank { seed.optString("url") } }
                .trim()
        }
        return "$archive|${type.lowercase(Locale.US)}|$stableId"
    }

    private fun detailCacheFile(key: String): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return File(File(cacheDir, "movie_detail_cache"), "$digest.json")
    }

    private fun readCachedDetail(key: String): JSONObject? {
        val now = System.currentTimeMillis()
        detailMemoryCache.get(key)?.let { memory ->
            val cachedAt = detailMemoryCacheAt[key] ?: 0L
            if (cachedAt > 0L && now - cachedAt < detailCacheTtlMs) {
                return JSONObject(memory.toString())
            }
            detailMemoryCache.remove(key)
            detailMemoryCacheAt.remove(key)
        }
        return runCatching {
            val file = detailCacheFile(key)
            if (!file.isFile || file.length() !in 2..2_500_000L) return@runCatching null
            if (System.currentTimeMillis() - file.lastModified() > detailCacheTtlMs) {
                file.delete()
                return@runCatching null
            }
            val obj = JSONObject(file.readText(Charsets.UTF_8))
            detailMemoryCache.put(key, JSONObject(obj.toString()))
            detailMemoryCacheAt[key] = file.lastModified().takeIf { it > 0L } ?: now
            obj
        }.getOrNull()
    }

    private fun writeCachedDetail(key: String, item: JSONObject) {
        runCatching {
            detailMemoryCache.put(key, JSONObject(item.toString()))
            detailMemoryCacheAt[key] = System.currentTimeMillis()
            val file = detailCacheFile(key)
            file.parentFile?.mkdirs()
            val temp = File(file.parentFile, file.name + ".tmp")
            temp.writeText(item.toString(), Charsets.UTF_8)
            if (!temp.renameTo(file)) {
                file.writeText(item.toString(), Charsets.UTF_8)
                temp.delete()
            }
            val cutoff = System.currentTimeMillis() - detailCacheTtlMs
            val cachedFiles = file.parentFile?.listFiles()?.filter { it.isFile && !it.name.endsWith(".tmp") }.orEmpty()
            cachedFiles.filter { it.lastModified() > 0L && it.lastModified() < cutoff }.forEach { it.delete() }
            cachedFiles.filter { it.exists() }.sortedByDescending { it.lastModified() }.drop(80).forEach { it.delete() }
        }
    }

    private fun detailScrollPrefsKey(key: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(key.toByteArray(Charsets.UTF_8))
            .take(10)
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
        return "detail_scroll_$digest"
    }

    private fun persistDetailScrollPosition(key: String, y: Int, force: Boolean = false) {
        if (key.isBlank()) return
        val now = System.currentTimeMillis()
        val safeY = y.coerceAtLeast(0)
        detailScrollPositions[key] = safeY to now
        val previous = detailScrollPersistAt[key] ?: 0L
        if (!force && now - previous < 700L) return
        detailScrollPersistAt[key] = now
        val prefKey = detailScrollPrefsKey(key)
        appPrefs().edit()
            .putInt("${prefKey}_y", safeY)
            .putLong("${prefKey}_at", now)
            .apply()
    }

    private fun readDetailScrollPosition(key: String): Int {
        val now = System.currentTimeMillis()
        detailScrollPositions[key]?.let { (y, at) ->
            if (now - at < detailCacheTtlMs) return y.coerceAtLeast(0)
        }
        val prefKey = detailScrollPrefsKey(key)
        val at = appPrefs().getLong("${prefKey}_at", 0L)
        if (at <= 0L || now - at >= detailCacheTtlMs) {
            appPrefs().edit().remove("${prefKey}_y").remove("${prefKey}_at").apply()
            return 0
        }
        val y = appPrefs().getInt("${prefKey}_y", 0).coerceAtLeast(0)
        detailScrollPositions[key] = y to at
        return y
    }

    private fun captureActiveDetailScroll() {
        val scroll = activeDetailScrollView ?: return
        val key = activeDetailScrollKey.ifBlank { activeDetailRequestKey }
        if (key.isBlank()) return
        if (scroll.parent != null) persistDetailScrollPosition(key, scroll.scrollY, force = true)
    }

    private fun detailSeedCanRender(seed: JSONObject): Boolean {
        val title = seed.optString("title_fa").ifBlank { seed.optString("title") }
        val poster = seed.optString("poster").ifBlank { seed.optString("image") }.ifBlank { seed.optString("cover_image") }
        return title.isNotBlank() || poster.isNotBlank()
    }

    private fun mergeSeedVisuals(seed: JSONObject, detail: JSONObject): JSONObject {
        val out = JSONObject(detail.toString())
        fun emptyValue(v: String): Boolean {
            val s = v.trim()
            return s.isBlank() || s.equals("null", true) || s.equals("false", true) || s.equals("undefined", true)
        }
        fun fill(key: String, vararg alternatives: String) {
            if (emptyValue(out.optString(key))) {
                for (k in alternatives) {
                    val v = seed.optString(k)
                    if (!emptyValue(v)) { out.put(key, v); return }
                }
            }
        }
        fill("poster", "poster", "image", "cover_image", "backdrop")
        fill("image", "image", "poster", "cover_image", "backdrop")
        fill("cover_image", "cover_image", "poster", "image", "backdrop")
        fill("backdrop", "backdrop", "poster", "image", "cover_image")
        fill("title_fa", "title_fa", "full_title", "title")
        fill("title", "title", "original_title", "title_fa")
        if (emptyValue(out.optString("imdb_code"))) fill("imdb_code", "imdb_code", "imdb", "imdb_id")
        if (emptyValue(out.optString("backdrop")) && !emptyValue(out.optString("poster"))) out.put("backdrop", out.optString("poster"))
        if (emptyValue(out.optString("image")) && !emptyValue(out.optString("poster"))) out.put("image", out.optString("poster"))
        if (emptyValue(out.optString("cover_image")) && !emptyValue(out.optString("poster"))) out.put("cover_image", out.optString("poster"))

        // Keep the original archive routing metadata. Some detail endpoints return
        // a generic archive value; comments must still target the exact website archive.
        val originArchive = seed.optInt("comment_archive",
            seed.optInt("_origin_archive", seed.optInt("archive", 0)))
        if (originArchive > 0) out.put("_origin_archive", originArchive)
        listOf("source", "source_slug", "slug", "detail_id", "api_detail", "web_url_abs", "web_url", "source_url", "url", "comment_identity", "comment_archive").forEach { key ->
            if (emptyValue(out.optString(key)) && !emptyValue(seed.optString(key))) out.put(key, seed.optString(key))
        }
        if (out.optInt("db_id", 0) <= 0 && seed.optInt("db_id", 0) > 0) out.put("db_id", seed.optInt("db_id"))
        if (out.optInt("movie_id", 0) <= 0 && seed.optInt("movie_id", 0) > 0) out.put("movie_id", seed.optInt("movie_id"))
        return out
    }

    private fun detailPayloadResolved(item: JSONObject): Boolean {
        if (item.has("links") || item.has("downloads")) return true
        return item.optJSONObject("play")?.has("links") == true
    }

    private fun normalizedGenreLabel(value: String): String = value
        .trim()
        .replace('‌', ' ')
        .replace('-', ' ')
        .replace(Regex("\\s+"), " ")
        .lowercase(Locale.ROOT)

    private fun genreRouteValue(archive: Int, label: String): String {
        val normalized = normalizedGenreLabel(label)
        val options = when (sanitizeArchive(archive)) {
            2 -> archive2GenreOptions()
            3 -> archive3GenreOptions()
            else -> archive1GenreOptions()
        }
        return options.firstOrNull {
            normalizedGenreLabel(it.label) == normalized || normalizedGenreLabel(it.value) == normalized
        }?.value?.ifBlank { label } ?: label
    }

    private fun itemContentType(item: JSONObject): String {
        val type = item.optString("type").lowercase(Locale.ROOT)
        val mediaKind = item.optString("media_kind").lowercase(Locale.ROOT)
        val raw = item.optString("type_fa").ifBlank { type }.lowercase(Locale.ROOT)
        return when {
            mediaKind == "anime" || type == "anime" || raw.contains("انیمه") -> "anime"
            mediaKind == "animation" || type == "animation" || raw.contains("انیمیشن") -> "animation"
            type.contains("series") || type.contains("serial") || raw.contains("series") || raw.contains("serial") || raw.contains("tv") || raw.contains("سریال") -> "series"
            else -> "movie"
        }
    }

    private fun clickableGenreChip(label: String, item: JSONObject): TextView {
        val clean = label.trim()
        val archive = sanitizeArchive(item.optInt("archive", selectedArchive))
        val value = genreRouteValue(archive, clean)
        return alphaPill(clean, false).apply {
            maxLines = 1
            ellipsize = null
            isClickable = true
            isFocusable = true
            contentDescription = t("نمایش ژانر $clean", "Open $clean genre")
            setOnClickListener {
                showGenreItems(clean, archive, value, itemContentType(item))
            }
            applyTvFocusHalo(this, 17, 1.035f, 0f)
        }
    }

    private fun genreFlow(item: JSONObject, genres: List<String>, limit: Int): GenreFlowLayout {
        return GenreFlowLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            horizontalSpacing = dp(6)
            verticalSpacing = dp(6)
            genres.distinct().take(limit).forEach { genre ->
                addView(clickableGenreChip(genre, item), ViewGroup.MarginLayoutParams(-2, dp(33)))
            }
        }
    }

    // PHASE 5.1: poster-derived dynamic palette was removed completely.
    // Detail uses the stable app background; the compact poster/metadata layout remains.


    // BANKMOVIE GLASS DESIGN SYSTEM — PASS 2: charcoal glass family shared by detail, modals and TV.
    // PASS 3: global charcoal glass family + Archive 1 satisfaction/IMDb cleanup.
    private fun bankGlassDrawable(
        radiusDp: Int = 22,
        fillAlpha: Int = 224,
        strokeAlpha: Int = 72,
        elevated: Boolean = false
    ): GradientDrawable {
        val p = UiPreferences.palette(this)
        // PASS 2: anchor every glass surface to the same charcoal used by the
        // "More information" card.  The old blue-black fill made each block
        // look like a different theme.  A very small vertical luminance shift
        // gives us the glass sheen without sacrificing text contrast.
        val base = if (p.light) Color.rgb(250, 252, 255) else p.panel2
        val topBase = UiPreferences.blend(base, Color.WHITE, if (p.light) 0.18f else 0.075f)
        val bottomBase = UiPreferences.blend(base, if (p.light) Color.rgb(219, 227, 240) else Color.BLACK, if (p.light) 0.12f else 0.055f)
        val effectiveAlpha = if (p.light) fillAlpha.coerceAtMost(205) else fillAlpha
        val top = Color.argb(effectiveAlpha.coerceIn(0, 255), Color.red(topBase), Color.green(topBase), Color.blue(topBase))
        val bottomAlpha = (effectiveAlpha - if (elevated) 10 else 18).coerceIn(0, 255)
        val bottom = Color.argb(bottomAlpha, Color.red(bottomBase), Color.green(bottomBase), Color.blue(bottomBase))
        val border = if (p.light) {
            Color.argb((strokeAlpha + 22).coerceIn(0,255), 160, 174, 196)
        } else {
            Color.argb(strokeAlpha.coerceIn(0, 255), 255, 255, 255)
        }
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), border)
        }
    }

    private fun bankPrimaryGlassDrawable(radiusDp: Int = 22): GradientDrawable {
        val p = UiPreferences.palette(this)
        // Accent is now a tint inside the same charcoal family instead of a
        // flat purple/blue pill. This is closer to a native frosted control.
        val base = if (p.light) p.panel else p.panel2
        val c1Base = UiPreferences.blend(base, p.primary, if (p.light) 0.16f else 0.34f)
        val c2Base = UiPreferences.blend(base, p.primary2, if (p.light) 0.10f else 0.20f)
        val c1 = Color.argb(if (p.light) 248 else 238, Color.red(c1Base), Color.green(c1Base), Color.blue(c1Base))
        val c2 = Color.argb(if (p.light) 248 else 228, Color.red(c2Base), Color.green(c2Base), Color.blue(c2Base))
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(c1, c2)).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), Color.argb(if (p.light) 105 else 135, Color.red(p.primary2), Color.green(p.primary2), Color.blue(p.primary2)))
        }
    }


    private fun bankTintGlassDrawable(
        accent: Int,
        radiusDp: Int = 18,
        fillAlpha: Int = 232,
        strength: Float = 0.22f
    ): GradientDrawable {
        val p = UiPreferences.palette(this)
        val base = if (p.light) p.panel else p.panel2
        val topBase = UiPreferences.blend(base, accent, if (p.light) strength * 0.72f else strength)
        val bottomBase = UiPreferences.blend(base, Color.BLACK, if (p.light) 0.02f else 0.055f)
        val top = Color.argb(fillAlpha.coerceIn(0, 255), Color.red(topBase), Color.green(topBase), Color.blue(topBase))
        val bottom = Color.argb((fillAlpha - 14).coerceIn(0, 255), Color.red(bottomBase), Color.green(bottomBase), Color.blue(bottomBase))
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radiusDp).toFloat()
            setStroke(dp(1), Color.argb(if (p.light) 88 else 118, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
    }

    private fun bankGlassSection(title: String): Pair<LinearLayout, LinearLayout> {
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bankGlassDrawable(24, 236, 74, true)
            elevation = dp(2).toFloat()
            setPadding(dp(15), dp(14), dp(15), dp(15))
        }
        val header = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 15.5f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        shell.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        shell.addView(body, LinearLayout.LayoutParams(-1, -2))
        return shell to body
    }

    private fun bankGlassMiniAction(label: String, iconRes: Int, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = bankGlassDrawable(20, 230, 66, true)
            setPadding(dp(8), dp(11), dp(8), dp(10))
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 20)
            applyTvFocusHalo(this, 20, 1.045f, dp(2).toFloat())
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(23), dp(23)).apply { bottomMargin = dp(7) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(Color.rgb(239, 241, 246))
                textSize = 11.8f
                typeface = BankmovieFonts.medium(this@MainActivity)
                gravity = Gravity.CENTER
                maxLines = 1
            })
            setOnClickListener {
                animate().cancel()
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(60L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(120L).start(); click()
                }.start()
            }
        }
    }

    private fun detailSatisfactionText(item: JSONObject): String {
        fun normalize(raw: String): String {
            val clean = raw.trim()
                .removePrefix("\"").removeSuffix("\"")
                .replace("٪", "%")
            if (clean.isBlank() || clean.equals("null", true) || clean.equals("false", true) || clean == "-") return ""
            val n = Regex("""\d+(?:[.,]\d+)?""").find(clean)?.value?.replace(',', '.')?.toDoubleOrNull()
            if (n != null && n <= 0.0) return "0%"
            return if (n != null && !clean.contains("%")) "${n.toInt()}%" else clean
        }

        val directKeys = arrayOf(
            "feedback_satisfaction", "satisfaction", "likes", "like_count",
            "likes_count", "approval", "approval_rate"
        )
        directKeys.forEach { key ->
            normalize(item.optString(key)).takeIf { it.isNotBlank() }?.let { return it }
        }
        item.optJSONObject("rating")?.let { ratingObj ->
            directKeys.forEach { key ->
                normalize(ratingObj.optString(key)).takeIf { it.isNotBlank() }?.let { return it }
            }
        }
        return "0%"
    }

    private fun bankRatingStrip(item: JSONObject): View? {
        val rawRating = cleanRating(item.optString("rating"))
        val hasRating = rawRating.replace(',', '.').toDoubleOrNull()?.let { it > 0.0 } == true
        val rating = if (hasRating) rawRating else "N/A"
        val satisfaction = detailSatisfactionText(item).ifBlank { "0%" }
        val hasSatisfaction = true

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = bankGlassDrawable(22, 238, 76, true)
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }

        fun divider() = View(this).apply {
            setBackgroundColor(Color.argb(42, 255, 255, 255))
        }

        run {
            val imdbCell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                addView(imdbCompactBadge(rating), LinearLayout.LayoutParams(-2, dp(30)))
            }
            shell.addView(imdbCell, LinearLayout.LayoutParams(0, dp(40), 1f))
        }

        if (hasSatisfaction) {
            shell.addView(divider(), LinearLayout.LayoutParams(dp(1), dp(31)).apply {
                marginStart = dp(8); marginEnd = dp(8)
            })
        }

        if (hasSatisfaction) {
            val likeCell = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_comment_like)
                    setColorFilter(Color.rgb(90, 213, 139))
                }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(8) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                    addView(TextView(this@MainActivity).apply {
                        text = satisfaction
                        setTextColor(Color.rgb(238, 241, 246))
                        textSize = 14.2f
                        typeface = BankmovieFonts.bold(this@MainActivity)
                        gravity = Gravity.RIGHT
                        maxLines = 1
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = t("پسند کاربران", "User likes")
                        setTextColor(Color.rgb(158, 163, 173))
                        textSize = 9.8f
                        typeface = BankmovieFonts.medium(this@MainActivity)
                        gravity = Gravity.RIGHT
                        maxLines = 1
                    })
                })
            }
            shell.addView(likeCell, LinearLayout.LayoutParams(0, dp(42), 1f))
        }
        return shell
    }

    private fun detailGlassIconButton(iconRes: Int, description: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            contentDescription = description
            background = bankGlassDrawable(999, 196, 88, true)
            elevation = dp(4).toFloat()
            isClickable = true; isFocusable = true
            applyMobileTouchHalo(this, 999)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                setPadding(dp(4), dp(4), dp(4), dp(4))
            }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            setOnClickListener {
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(55L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110L).start(); click()
                }.start()
            }
        }
    }

    private fun detailGlassPill(label: String, iconRes: Int, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = bankGlassDrawable(999, 214, 82, true)
            elevation = dp(3).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            isClickable = true; isFocusable = true
            applyMobileTouchHalo(this, 999)
            addView(ImageView(this@MainActivity).apply { setImageResource(iconRes); setColorFilter(Color.WHITE) }, LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label; setTextColor(Color.WHITE); textSize = 13.1f
                typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.CENTER
            })
            setOnClickListener {
                animate().scaleX(0.975f).scaleY(0.975f).setDuration(55L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(105L).start(); click()
                }.start()
            }
        }
    }

    private fun detailPremiumPlayButton(label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(12, 164, 104), Color.rgb(30, 202, 132))).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(185, 118, 255, 194))
            }
            elevation = dp(10).toFloat()
            setPadding(dp(16), 0, dp(16), 0)
            isClickable = true; isFocusable = true
            applyMobileTouchHalo(this, 999)
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_play_fill); setColorFilter(Color.WHITE) }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(9) })
            addView(TextView(this@MainActivity).apply {
                text = label; setTextColor(Color.WHITE); textSize = 14.1f
                typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.CENTER
            })
            setOnClickListener {
                animate().scaleX(0.972f).scaleY(0.972f).setDuration(60L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(115L).start(); click()
                }.start()
            }
        }
    }

    private fun showDetail(seed: JSONObject) {
        val archive = when (seed.optInt("archive", defaultArchive)) {
            2 -> 2
            3 -> 3
            else -> 1
        }
        val id = seed.optString("id")
        val type = seed.optString("type", "movie")
        if (id.isBlank()) return

        pushCurrentScreenForBack()
        currentScreen = "detail"
        val savedSeed = seed.toString()
        rememberCurrentScreen { showDetail(JSONObject(savedSeed)) }
        buildBottomNav()
        clear()
        if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE

        val requestKey = detailRequestKey(archive, id, type, seed)
        activeDetailRequestKey = requestKey
        var rendered = false
        var initialRenderPosted = false
        var pendingInitialDetail: JSONObject? = null
        val detailLoadStartedAt = System.currentTimeMillis()

        fun currentScrollY(): Int = (content.getChildAt(0) as? ScrollView)?.scrollY ?: 0

        fun showLoadedDetail(detailItem: JSONObject, restoreY: Int = 0) {
            if (currentScreen != "detail" || activeDetailRequestKey != requestKey) return
            content.removeAllViews()
            val scroll = BankmovieSmoothScrollView(this).apply {
                clipToPadding = false
                setPadding(0, 0, 0, if (currentScreen == "detail") dp(24) else dp(100))
                setOnScrollChangeListener { _, _, scrollY, _, _ ->
                    persistDetailScrollPosition(requestKey, scrollY)
                }
            }
            activeDetailScrollView = scroll
            activeDetailScrollKey = requestKey
            val page = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(0), dp(12), dp(30))
            }
            scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
            content.addView(scroll)
            attachSmartHeader(scroll)
            try {
                renderDetail(page, mergeSeedVisuals(seed, detailItem))
                if (isTvLike()) {
                    fun restoreTopFocus() {
                        val preferred = page.findViewWithTag<View>("bm_tv_detail_primary")
                            ?: page.findViewWithTag<View>("bm_tv_detail_back")
                        scroll.scrollTo(0, 0)
                        preferred?.requestFocus()
                    }
                    scroll.post { restoreTopFocus() }
                    scroll.postDelayed({ if (currentScreen == "detail" && activeDetailRequestKey == requestKey) restoreTopFocus() }, 260L)
                    scroll.postDelayed({ if (currentScreen == "detail" && activeDetailRequestKey == requestKey) restoreTopFocus() }, 820L)
                } else if (restoreY > 0) {
                    // PASS 4.7: use the same one-shot smart restore as Back navigation.
                    // Any user gesture cancels it, so late layout work can never fight
                    // against an intentional scroll toward the top.
                    restoreBackScrollPosition("detail", restoreY, System.currentTimeMillis())
                }
                if (!isTvLike() && !lowEndDevice && restoreY <= 0) {
                    scroll.alpha = 0f
                    scroll.translationY = dp(6).toFloat()
                    scroll.animate()
                        .alpha(1f)
                        .translationY(0f)
                        .setDuration(145L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
            } catch (e: Throwable) {
                page.removeAllViews()
                page.addView(emptyStateBox(t("خطا در نمایش اطلاعات", "Display error"), e.message ?: "Unknown error"), LinearLayout.LayoutParams(-1, -2))
            }
            rendered = true
        }

        fun scheduleInitialDetail(item: JSONObject, minimumLoaderMs: Long) {
            pendingInitialDetail = item
            if (initialRenderPosted) return
            initialRenderPosted = true
            val elapsed = System.currentTimeMillis() - detailLoadStartedAt
            val wait = (minimumLoaderMs - elapsed).coerceAtLeast(0L)
            content.postDelayed({
                if (currentScreen != "detail" || activeDetailRequestKey != requestKey || rendered) return@postDelayed
                showLoadedDetail(pendingInitialDetail ?: item)
            }, wait)
        }

        val cached = readCachedDetail(requestKey)
        if (cached != null && detailPayloadResolved(cached)) {
            // A valid one-hour device cache is authoritative. Do not show the loader
            // and do not immediately refetch/re-render when the user returns from
            // Player, Search, Collections or another app screen.
            val savedY = readDetailScrollPosition(requestKey)
            showLoadedDetail(cached, savedY)
            return
        }

        content.addView(movieDetailLoading(seed), FrameLayout.LayoutParams(-1, -1))
        if (detailPayloadResolved(seed)) {
            scheduleInitialDetail(seed, if (lowEndDevice) 135L else 210L)
        }

        val url = archiveDetailUrl(archive, id, type, seed.optString("source_url").ifBlank { seed.optString("url") }, seed)
        fetchArchive(url, archive) { ok, json, err ->
            runOnUiThread {
                if (currentScreen != "detail" || activeDetailRequestKey != requestKey) return@runOnUiThread
                if (!ok || json == null) {
                    if (!rendered && !initialRenderPosted) {
                        scheduleInitialDetail(seed, if (lowEndDevice) 160L else 260L)
                    }
                    if (!rendered || cached == null) Toast.makeText(this, friendlyError(err), Toast.LENGTH_SHORT).show()
                } else {
                    val fresh = json.optJSONObject("item") ?: seed
                    writeCachedDetail(requestKey, fresh)
                    if (!rendered) {
                        pendingInitialDetail = fresh
                        scheduleInitialDetail(fresh, if (lowEndDevice) 135L else 210L)
                    } else {
                        val previousY = currentScrollY()
                        showLoadedDetail(fresh, previousY)
                    }
                }
            }
        }
    }



    private fun renderDetailTv(page: LinearLayout, item: JSONObject) {
        val title = item.optString("title_fa").ifBlank { item.optString("title") }
        val originalTitle = item.optString("title").ifBlank { item.optString("original_title") }

        fun mediaCandidate(vararg values: String): String {
            for (value in values) {
                val clean = value.trim()
                if (clean.isNotBlank() &&
                    !clean.equals("null", true) &&
                    !clean.equals("false", true) &&
                    !clean.equals("undefined", true)
                ) return clean
            }
            return ""
        }

        val poster = mediaCandidate(
            item.optString("poster"),
            item.optString("poster_url"),
            item.optString("image"),
            item.optString("cover_image"),
            item.optString("thumbnail"),
            item.optString("thumb")
        )
        val rawBackdrop = mediaCandidate(
            item.optString("backdrop"),
            item.optString("background"),
            item.optString("backdrop_url"),
            item.optString("cover")
        )
        val hasRealBackdrop = rawBackdrop.isNotBlank() &&
            poster.isNotBlank() &&
            rawBackdrop.trim() != poster.trim()

        val desc = item.optString("long_description").ifBlank { item.optString("description") }
        val genres = genresText(item)
            .split("،", ",", "•")
            .map { it.trim() }
            .filter { it.isNotBlank() }

        recordHistory(item)

        // TV detail is restored to the old integrated layout, but the cover is
        // capped at the information area. Download/comments start on the normal
        // page background and never inherit a stretched poster.
        val heroHeight = if (hasRealBackdrop) dp(430) else dp(320)
        val hero = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, heroHeight).apply {
                leftMargin = -dp(12)
                rightMargin = -dp(12)
                bottomMargin = dp(12)
            }
            setBackgroundColor(Color.rgb(3, 7, 14))
            clipChildren = false
            clipToPadding = false
        }

        if (hasRealBackdrop) {
            val backdropImage = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(Color.BLACK)
                alpha = 0.94f
            }
            loadImage(rawBackdrop, backdropImage)
            hero.addView(backdropImage, FrameLayout.LayoutParams(-1, -1))
        }

        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(6, 0, 0, 0),
                    Color.argb(18, 0, 0, 0),
                    Color.argb(92, 0, 0, 0),
                    Color.argb(245, 4, 4, 6)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(
                    Color.argb(115, 0, 0, 0),
                    Color.argb(28, 0, 0, 0),
                    Color.TRANSPARENT
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))

        hero.addView(
            svgIconButton(R.drawable.ic_player_back) { handleSmartBack() }.apply { tag = "bm_tv_detail_back" },
            FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.LEFT).apply {
                topMargin = dp(16)
                leftMargin = dp(16)
            }
        )

        val contentBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            setPadding(dp(26), dp(62), dp(26), dp(18))
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.BOTTOM
        }

        val posterFrame = FrameLayout(this).apply {
            background = bankGlassDrawable(20, 236, 84, true)
            clipToOutline = true
            elevation = dp(10).toFloat()
            setPadding(dp(3), dp(3), dp(3), dp(3))
        }
        val posterImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.BLACK)
            adjustViewBounds = true
        }
        loadImage(poster, posterImage)
        posterFrame.addView(posterImage, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        topRow.addView(
            posterFrame,
            LinearLayout.LayoutParams(dp(120), dp(176)).apply { marginStart = dp(16) }
        )

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
        }
        info.addView(TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(7f, 0f, 2f, Color.argb(190, 0, 0, 0))
        })
        if (originalTitle.isNotBlank() && originalTitle != title) {
            info.addView(TextView(this).apply {
                text = originalTitle
                setTextColor(Color.argb(215, 230, 233, 240))
                textSize = 12f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(4), 0, dp(5))
            })
        }

        val metaPrimary = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
        }
        val ratingText = cleanRating(item.optString("rating")).let { raw -> if (raw.replace(',', '.').toDoubleOrNull()?.let { it > 0.0 } == true) raw else "N/A" }
        run {
            metaPrimary.addView(
                imdbCompactBadge(ratingText),
                LinearLayout.LayoutParams(-2, dp(30)).apply { marginStart = dp(7) }
            )
        }
        item.optString("year").takeIf { it.isNotBlank() }?.let { year ->
            metaPrimary.addView(
                alphaPill(year, false),
                LinearLayout.LayoutParams(-2, dp(32)).apply { marginStart = dp(7) }
            )
        }
        val rawType = item.optString("type_fa").ifBlank { item.optString("type") }
        val typeLabel = when {
            rawType.contains("series", true) ||
                rawType.contains("serial", true) ||
                rawType.contains("tv", true) ||
                rawType.contains("سریال") -> "سریال"
            rawType.contains("movie", true) ||
                rawType.contains("film", true) ||
                rawType.contains("فیلم") -> "فیلم"
            else -> rawType
        }
        if (typeLabel.isNotBlank()) {
            metaPrimary.addView(
                alphaPill(typeLabel, false),
                LinearLayout.LayoutParams(-2, dp(32)).apply { marginStart = dp(7) }
            )
        }
        info.addView(metaPrimary, LinearLayout.LayoutParams(-1, dp(36)).apply {
            topMargin = dp(7)
        })

        if (genres.isNotEmpty()) {
            info.addView(genreFlow(item, genres, 6), LinearLayout.LayoutParams(-1, -2).apply {
                topMargin = dp(6)
            })
        }

        topRow.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        contentBox.addView(topRow, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(
            detailActionButton("پخش آنلاین", R.drawable.ic_play_fill, true) {
                showPlayableSheet(item)
            }.apply { tag = "bm_tv_detail_primary" },
            LinearLayout.LayoutParams(0, dp(52), 1.2f).apply { marginStart = dp(10) }
        )
        if (item.optInt("archive", selectedArchive) != 2) {
            actions.addView(
                purpleTrailerButton { playTrailer(item) },
                LinearLayout.LayoutParams(0, dp(52), 1f).apply { marginStart = dp(10) }
            )
        }
        actions.addView(
            favoriteHeartButton(item) {
                toggleFavorite(item)
                page.removeAllViews()
                renderDetailTv(page, item)
            },
            LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(10) }
        )
        contentBox.addView(actions, LinearLayout.LayoutParams(-1, dp(56)).apply {
            bottomMargin = dp(9)
        })

        // TV detail stays compact here. The long synopsis strip caused an
        // extra block under the actions and looked like a redundant section in
        // the user recording, so it is hidden on TV.
        hero.addView(contentBox, FrameLayout.LayoutParams(-1, -1))
        page.addView(hero)

        renderActors(page, item)
        renderEpisodeBlocks(page, item)

        val detailArchive = item.optInt("archive", selectedArchive)
        val related = item.optJSONArray("related") ?: item.optJSONArray("related_movies") ?: JSONArray()
        if (related.length() > 0) {
            addJsonRail(page, "پیشنهاد فیلم", related, showMore = false)
        } else if (detailArchive == 2) {
            val relatedGenre = genres.firstOrNull().orEmpty()
            val relatedType = if (item.optString("type").equals("series", true)) "series" else "movie"
            addArchive2GenreRail(
                page,
                "پیشنهاد فیلم",
                relatedGenre,
                relatedType,
                item.optString("id").ifBlank { item.optString("slug") },
                showMore = false
            )
        } else {
            val similarQuery = genres.firstOrNull().orEmpty().ifBlank { title }
            addSearchRail(page, "پیشنهاد فیلم", similarQuery, "all", detailArchive, showMore = false)
        }
        renderCommentsSection(page, item)

        // Only make controls focusable. Do not request focus and do not move the
        // ScrollView. Native TV navigation keeps the current viewport stable.
        page.post { applyTvFocusToClickableTree(page) }
    }

    private fun persianDigits(value: String): String = buildString(value.length) {
        value.forEach { ch ->
            append(
                when (ch) {
                    '0' -> '۰'; '1' -> '۱'; '2' -> '۲'; '3' -> '۳'; '4' -> '۴'
                    '5' -> '۵'; '6' -> '۶'; '7' -> '۷'; '8' -> '۸'; '9' -> '۹'
                    else -> ch
                }
            )
        }
    }

    private fun detailLatestUpdateText(item: JSONObject): String {
        var raw = item.optString("latest_status")
            .ifBlank { item.optString("update_note") }
            .ifBlank { item.optString("episode_note") }
            .trim()
        if (raw.isBlank() || raw.equals("null", true)) return ""

        // Match the site's compact update badge wording: «قسمت ۸ فصل ۱ اضافه شد».
        val seasonEpisode = Regex("""فصل\s*(\d+)\s*قسمت\s*(\d+)""").find(raw)
        if (seasonEpisode != null) {
            val season = seasonEpisode.groupValues[1]
            val episode = seasonEpisode.groupValues[2]
            raw = "قسمت $episode فصل $season اضافه شد"
        } else if (!raw.contains("اضافه شد") && Regex("""قسمت\s*\d+""").containsMatchIn(raw)) {
            raw = "$raw اضافه شد"
        }
        val cleaned = raw.replace(Regex("""^\s*(?:بروزرسانی|به.?روزرسانی|وضعیت)\s*[:：-]?\s*"""), "").trim()
        return if (isFa()) persianDigits(cleaned) else cleaned
    }

    private fun detailLatestUpdatePill(item: JSONObject): View? {
        val textValue = detailLatestUpdateText(item)
        if (textValue.isBlank()) return null
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11), dp(5), dp(11), dp(5))
            background = bankGlassDrawable(17, 222, 62, true)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_detail_update_sync)
                setColorFilter(Color.rgb(255, 74, 79))
            }, LinearLayout.LayoutParams(dp(23), dp(23)).apply { marginEnd = dp(7) })
            addView(TextView(this@MainActivity).apply {
                text = textValue
                setTextColor(Color.rgb(235, 236, 240))
                textSize = 12.6f
                typeface = BankmovieFonts.medium(this@MainActivity)
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(-2, dp(28)))
        }
    }


    private fun detailListText(item: JSONObject, key: String): String {
        val raw = item.opt(key)
        if (raw == null || raw === JSONObject.NULL) return ""

        fun cleanPart(value: String): String = value.trim()
            .removePrefix("\"").removeSuffix("\"")
            .trim()
            .takeUnless { it.equals("null", true) || it.equals("undefined", true) } ?: ""

        return when (raw) {
            is JSONArray -> (0 until raw.length())
                .mapNotNull { cleanPart(raw.optString(it)).takeIf(String::isNotBlank) }
                .distinct()
                .joinToString("، ")
            else -> {
                val s = cleanPart(raw.toString())
                if (s.startsWith("[") && s.endsWith("]")) {
                    runCatching {
                        val arr = JSONArray(s)
                        (0 until arr.length())
                            .mapNotNull { cleanPart(arr.optString(it)).takeIf(String::isNotBlank) }
                            .distinct()
                            .joinToString("، ")
                    }.getOrElse {
                        s.removePrefix("[").removeSuffix("]")
                            .replace("\"", "")
                            .replace("'", "")
                            .split(",")
                            .map(String::trim)
                            .filter(String::isNotBlank)
                            .joinToString("، ")
                    }
                } else s
            }
        }
    }

    private fun detailMoreInfoCard(item: JSONObject): View {
        val p = UiPreferences.palette(this)
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(15), 0, dp(15), dp(14))
        }
        val arrow = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_down)
            setColorFilter(p.primary)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        fun addInfoRow(label: String, value: String) {
            val clean = value.trim()
            if (clean.isBlank() || clean.equals("null", true)) return
            body.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(9), 0, dp(9))
                addView(TextView(this@MainActivity).apply {
                    text = label
                    setTextColor(p.muted)
                    textSize = 11.6f
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(0, -2, 0.42f))
                addView(TextView(this@MainActivity).apply {
                    text = clean
                    setTextColor(p.text)
                    textSize = 11.8f
                    typeface = BankmovieFonts.medium(this@MainActivity)
                    gravity = Gravity.LEFT
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                }, LinearLayout.LayoutParams(0, -2, 0.58f))
            }, LinearLayout.LayoutParams(-1, -2))
            body.addView(View(this).apply {
                setBackgroundColor(Color.argb(30, 255, 255, 255))
            }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        addInfoRow(t("مدت زمان", "Runtime"), item.optString("runtime").ifBlank { item.optString("duration") })
        addInfoRow(t("کشور", "Country"), detailListText(item, "country").ifBlank { detailListText(item, "countries") })
        addInfoRow(t("سال انتشار", "Release year"), item.optString("year"))
        addInfoRow(t("وضعیت", "Status"), item.optString("status_text").ifBlank { item.optString("status") })
        addInfoRow(t("شبکه", "Network"), item.optString("network"))
        addInfoRow(t("زبان", "Language"), detailListText(item, "language").ifBlank { detailListText(item, "languages") })
        addInfoRow(t("رده سنی", "Age rating"), item.optString("age_rate").ifBlank { item.optString("age_rating") })
        addInfoRow(t("دوبله فارسی", "Persian dub"), if (item.optBoolean("has_dubbed", false)) t("دارد", "Available") else t("ندارد", "Not available"))
        addInfoRow(t("زیرنویس", "Subtitles"), if (item.optBoolean("has_subtitle", false)) t("دارد", "Available") else t("ندارد", "Not available"))
        addInfoRow(t("استودیو", "Studio"), detailListText(item, "production_companies").ifBlank { item.optString("studio") })

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(11), dp(14), dp(11))
            isClickable = true
            isFocusable = true
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_info_archive)
                setColorFilter(p.text)
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = t("اطلاعات بیشتر", "More information")
                setTextColor(p.text)
                textSize = 13.2f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(arrow, LinearLayout.LayoutParams(dp(34), dp(34)))
            applyMobileTouchHalo(this, 20)
            setOnClickListener {
                val open = body.visibility != View.VISIBLE
                animateExpandable(body, open, 260L)
                arrow.animate()
                    .rotation(if (open) 180f else 0f)
                    .setDuration(220L)
                    .setInterpolator(android.view.animation.DecelerateInterpolator())
                    .start()
            }
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bankGlassDrawable(24, 244, 78, true)
            elevation = dp(2).toFloat()
            addView(head, LinearLayout.LayoutParams(-1, -2))
            addView(body, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun renderDetail(page: LinearLayout, item: JSONObject) {
        if (isTvLike()) {
            renderDetailTv(page, item)
            return
        }

        val title = item.optString("title_fa").ifBlank { item.optString("title") }
        val originalTitle = item.optString("title").ifBlank { item.optString("original_title") }
        fun mediaCandidate(vararg values: String): String {
            for (v in values) {
                val clean = v.trim()
                if (clean.isNotBlank() && !clean.equals("null", true) && !clean.equals("false", true) && !clean.equals("undefined", true)) return clean
            }
            return ""
        }

        val poster = mediaCandidate(
            item.optString("poster"), item.optString("poster_url"), item.optString("image"),
            item.optString("cover_image"), item.optString("thumbnail"), item.optString("thumb")
        )
        val rawBackdrop = mediaCandidate(
            item.optString("backdrop"), item.optString("background"), item.optString("backdrop_url"), item.optString("cover")
        )
        val hasRealBackdrop = rawBackdrop.isNotBlank() && rawBackdrop.trim() != poster.trim()
        val artwork = if (hasRealBackdrop) rawBackdrop else poster
        val desc = item.optString("long_description").ifBlank { item.optString("description") }
        val genres = genresText(item).split("،", ",", "•").map { it.trim() }.filter { it.isNotBlank() }
        recordHistory(item)

        page.setBackgroundColor(Color.rgb(4, 4, 6))
        window.statusBarColor = Color.rgb(4, 4, 6)
        window.navigationBarColor = Color.rgb(4, 4, 6)

        // Concept 1: artwork-led hero, no duplicated floating poster. The content
        // hierarchy stays calm: artwork -> title/meta -> play -> ratings -> actions.
        val hero = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(-1, dp(472)).apply {
                leftMargin = -dp(12); rightMargin = -dp(12); bottomMargin = dp(10)
            }
            setBackgroundColor(Color.BLACK)
            clipChildren = false
        }
        val heroImg = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = if (hasRealBackdrop) 0.96f else 0.72f
            setBackgroundColor(Color.BLACK)
        }
        hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1))
        if (artwork.isNotBlank()) loadImage(artwork, heroImg)

        // Filmic fade: the lower part melts into the app background instead of
        // ending as a hard rectangle.
        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(
                    Color.argb(12, 0, 0, 0),
                    Color.argb(20, 0, 0, 0),
                    Color.argb(80, 0, 0, 0),
                    Color.argb(205, 5, 5, 7),
                    Color.rgb(4, 4, 6)
                )
            )
        }, FrameLayout.LayoutParams(-1, -1))
        hero.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.RIGHT_LEFT,
                intArrayOf(Color.argb(64, 0, 0, 0), Color.TRANSPARENT, Color.argb(50, 0, 0, 0))
            )
        }, FrameLayout.LayoutParams(-1, -1))

        hero.addView(
            detailGlassIconButton(R.drawable.ic_player_back, t("بازگشت", "Back")) { handleSmartBack() }.apply { tag = "bm_detail_back" },
            FrameLayout.LayoutParams(dp(45), dp(45), Gravity.TOP or Gravity.LEFT).apply { topMargin = dp(15); leftMargin = dp(14) }
        )
        if (AccountSession.watchlistEnabled(this)) {
            val active = isFavorite(item)
            hero.addView(
                detailGlassIconButton(
                    if (active) R.drawable.ic_watchlist_filled else R.drawable.ic_watchlist_outline,
                    if (active) t("حذف از لیست من", "Remove from my list") else t("افزودن به لیست من", "Add to my list")
                ) {
                    toggleFavorite(item); page.removeAllViews(); renderDetail(page, item)
                },
                FrameLayout.LayoutParams(dp(45), dp(45), Gravity.TOP or Gravity.RIGHT).apply { topMargin = dp(15); rightMargin = dp(14) }
            )
        }

        val playOrb = FrameLayout(this).apply {
            background = bankPrimaryGlassDrawable(999)
            elevation = dp(10).toFloat()
            isClickable = true; isFocusable = true
            contentDescription = t("پخش فیلم", "Play")
            applyMobileTouchHalo(this, 999)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(Color.WHITE)
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }, FrameLayout.LayoutParams(dp(31), dp(31), Gravity.CENTER))
            setOnClickListener { showPlayableSheet(item) }
        }
        hero.addView(playOrb, FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER).apply { topMargin = -dp(18) })

        val titleStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT or Gravity.BOTTOM
            setPadding(dp(22), 0, dp(22), dp(23))
        }
        titleStack.addView(TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 27f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setShadowLayer(10f, 0f, 2f, Color.argb(210, 0, 0, 0))
        }, LinearLayout.LayoutParams(-1, -2))
        if (originalTitle.isNotBlank() && originalTitle != title) {
            titleStack.addView(TextView(this).apply {
                text = originalTitle
                setTextColor(Color.argb(205, 235, 238, 244))
                textSize = 12f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(3), 0, 0)
            })
        }
        // PASS 4.7: keep release metadata and genres on separate visual lines.
        // Long genre lists stay horizontally scrollable instead of being crushed
        // into the year/country line.
        val metaLine = mutableListOf<String>()
        item.optString("year").trim().takeIf { it.isNotBlank() }?.let(metaLine::add)
        detailListText(item, "country").ifBlank { detailListText(item, "countries") }
            .takeIf { it.isNotBlank() }?.let(metaLine::add)
        if (metaLine.isNotEmpty()) {
            titleStack.addView(TextView(this).apply {
                text = metaLine.joinToString("   •   ")
                setTextColor(Color.argb(220, 230, 233, 239))
                textSize = 11.4f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(7), 0, 0)
            })
        }
        if (genres.isNotEmpty()) {
            val genreScroll = HorizontalBankmovieSmoothScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                clipToPadding = false
            }
            val genreRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                setPadding(0, dp(7), 0, 0)
            }
            genres.distinct().forEach { genre ->
                genreRow.addView(TextView(this).apply {
                    text = genre
                    setTextColor(Color.argb(232, 239, 241, 246))
                    textSize = 10.8f
                    typeface = BankmovieFonts.medium(this@MainActivity)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    background = bankGlassDrawable(999, 165, 34, false)
                    setPadding(dp(9), dp(4), dp(9), dp(4))
                    isClickable = true
                    isFocusable = true
                    applyMobileTouchHalo(this, 999)
                    setOnClickListener {
                        showGenreItems(
                            genre,
                            sanitizeArchive(item.optInt("archive", selectedArchive)),
                            genreRouteValue(sanitizeArchive(item.optInt("archive", selectedArchive)), genre),
                            itemContentType(item)
                        )
                    }
                }, LinearLayout.LayoutParams(-2, dp(28)).apply {
                    marginStart = dp(5)
                })
            }
            genreScroll.addView(genreRow)
            titleStack.addView(genreScroll, LinearLayout.LayoutParams(-1, dp(35)))
        }
        hero.addView(titleStack, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        page.addView(hero)

        // Update status belongs directly under the artwork. Rating/likes follow it.
        detailLatestUpdatePill(item)?.let { updatePill ->
            page.addView(updatePill, LinearLayout.LayoutParams(-2, dp(42)).apply {
                gravity = Gravity.RIGHT; rightMargin = dp(10); bottomMargin = dp(10)
            })
        }

        bankRatingStrip(item)?.let { ratingStrip ->
            page.addView(ratingStrip, LinearLayout.LayoutParams(-1, dp(62)).apply {
                leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(11)
            })
        }

        // Three secondary actions from Concept 1. They share the same glass surface,
        // icon scale and focus behavior on touch/keyboard/TV-like devices.
        val quickActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        quickActions.addView(bankGlassMiniAction(t("دانلود", "Download"), R.drawable.ic_download) {
            showDownloadOptions(item)
        }, LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginStart = dp(4) })
        val trailerAvailable = item.optInt("archive", selectedArchive) != 2
        quickActions.addView(bankGlassMiniAction(
            if (trailerAvailable) t("تریلر", "Trailer") else t("پخش", "Play"),
            if (trailerAvailable) R.drawable.ic_trailer else R.drawable.ic_play_fill
        ) {
            if (trailerAvailable) playTrailer(item) else showPlayableSheet(item)
        }, LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        val watchlistAvailable = AccountSession.watchlistEnabled(this)
        quickActions.addView(bankGlassMiniAction(
            if (watchlistAvailable && isFavorite(item)) t("ذخیره شده", "Saved") else if (watchlistAvailable) t("لیست من", "My list") else t("پخش", "Play"),
            if (watchlistAvailable && isFavorite(item)) R.drawable.ic_watchlist_filled else if (watchlistAvailable) R.drawable.ic_watchlist_outline else R.drawable.ic_play_fill
        ) {
            if (watchlistAvailable) { toggleFavorite(item); page.removeAllViews(); renderDetail(page, item) } else showPlayableSheet(item)
        }, LinearLayout.LayoutParams(0, dp(86), 1f).apply { marginEnd = dp(4) })
        page.addView(quickActions, LinearLayout.LayoutParams(-1, dp(86)).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(12)
        })

        // Synopsis gets its own calm card. This fixes the old hero overload and keeps
        // long Persian descriptions readable without competing with artwork.
        val (synopsisCard, synopsisBody) = bankGlassSection(t("خلاصه داستان", "Synopsis"))
        val synopsisText = TextView(this).apply {
            text = desc.ifBlank { t("توضیحی برای این عنوان ثبت نشده است.", "No synopsis is available for this title.") }
            setTextColor(Color.rgb(231, 231, 235))
            textSize = 13.1f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(4).toFloat(), 1.02f)
            maxLines = 4
            ellipsize = TextUtils.TruncateAt.END
        }
        synopsisBody.addView(synopsisText, LinearLayout.LayoutParams(-1, -2))
        if (desc.length > 185) {
            val expanded = booleanArrayOf(false)
            synopsisBody.addView(TextView(this).apply {
                text = t("بیشتر  ⌄", "More  ⌄")
                setTextColor(UiPreferences.palette(this@MainActivity).primary)
                textSize = 11.6f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.RIGHT
                setPadding(0, dp(7), 0, 0)
                isClickable = true
                setOnClickListener {
                    expanded[0] = !expanded[0]
                    if (expanded[0]) {
                        synopsisText.maxLines = Int.MAX_VALUE; synopsisText.ellipsize = null; text = t("کمتر  ⌃", "Less  ⌃")
                    } else {
                        synopsisText.maxLines = 4; synopsisText.ellipsize = TextUtils.TruncateAt.END; text = t("بیشتر  ⌄", "More  ⌄")
                    }
                }
            })
        }
        page.addView(synopsisCard, LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(11)
        })

        page.addView(detailMoreInfoCard(item), LinearLayout.LayoutParams(-1, -2).apply {
            leftMargin = dp(10); rightMargin = dp(10); bottomMargin = dp(16)
        })

        renderActors(page, item)
        renderEpisodeBlocks(page, item)

        val detailArchive = item.optInt("archive", selectedArchive)
        val related = item.optJSONArray("related") ?: item.optJSONArray("related_movies") ?: JSONArray()
        if (related.length() > 0) {
            addJsonRail(page, t("پیشنهاد فیلم", "Recommended"), related, showMore = false)
        } else if (detailArchive == 2) {
            val relatedGenre = genres.firstOrNull().orEmpty()
            val relatedType = if (item.optString("type").equals("series", true)) "series" else "movie"
            addArchive2GenreRail(page, t("پیشنهاد فیلم", "Recommended"), relatedGenre, relatedType, item.optString("id").ifBlank { item.optString("slug") }, showMore = false)
        } else {
            val similarQuery = genres.firstOrNull().orEmpty().ifBlank { title }
            addSearchRail(page, t("پیشنهاد فیلم", "Recommended"), similarQuery, "all", detailArchive, showMore = false)
        }
        renderCommentsSection(page, item)
    }

    private fun commentAvatarView(comment: JSONObject, sizeDp: Int): ImageView {
        return ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(27, 26, 34))
                setStroke(dp(1), Color.argb(78, 255, 255, 255))
            }
            clipToOutline = true
            scaleX = 1.06f
            scaleY = 1.06f
            val local = avatarDrawableForKey(comment.optString("avatar_key"))
            if (local != 0) setImageResource(local)
            else {
                val remote = comment.optString("avatar")
                if (remote.isNotBlank()) loadImage(remote, this) else setImageResource(R.drawable.avatar_default)
            }
            setPadding(dp(2), dp(2), dp(2), dp(2))
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        }
    }

    private fun animatedActionButton(
        label: String,
        iconRes: Int,
        accentColor: Int = UiPreferences.palette(this).primary,
        onClick: (LinearLayout) -> Unit
    ): LinearLayout {
        val p = UiPreferences.palette(this)
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(if (p.light) accentColor else p.text)
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = bankTintGlassDrawable(accentColor, 18, 238, 0.24f)
            elevation = dp(4).toFloat()
            val inner = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                setPadding(dp(15), 0, dp(15), 0)
                background = bankGlassDrawable(15, if (p.light) 238 else 205, 42, false)
                addView(icon, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(11) })
                addView(TextView(this@MainActivity).apply {
                    text = label
                    setTextColor(if (p.light) Color.rgb(28, 30, 36) else p.text)
                    textSize = 14f
                    typeface = BankmovieFonts.bold(this@MainActivity)
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(-2, -1))
            }
            addView(inner, LinearLayout.LayoutParams(-1, -1))
            isClickable = true
            isFocusable = true
            applyMobileTouchHalo(this, 17)
            applyTvFocusHalo(this, 18, 1.035f, elevation)
            setOnClickListener {
                if (!isEnabled) return@setOnClickListener
                animate().cancel()
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(55L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(95L).start()
                }.start()
                icon.animate().cancel()
                icon.animate().translationX(dp(7).toFloat()).rotation(16f).setDuration(90L).withEndAction {
                    icon.animate().translationX(0f).rotation(0f).setDuration(130L).start()
                }.start()
                onClick(this)
            }
        }
    }

    private fun commentMediaMarker(media: JSONObject): String {
        val pack = media.optString("pack")
        val id = media.optString("id")
        return if (pack.isNotBlank() && id.matches(Regex("[a-fA-F0-9]{24}"))) "[bm-sticker:$pack:$id]" else ""
    }

    private fun commentLoadingSpinner(): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleSmall).apply {
                isIndeterminate = true
                indeterminateTintList = android.content.res.ColorStateList.valueOf(p.primary)
            }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = t("در حال دریافت دیدگاه‌ها...", "Loading comments...")
                setTextColor(p.muted)
                textSize = 11.8f
                gravity = Gravity.CENTER
            })
        }
    }

    private fun commentMediaRecent(): MutableList<JSONObject> {
        val raw = appPrefs().getString("comment_media_recent_v2", "[]").orEmpty()
        val arr = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) arr.optJSONObject(i)?.let { out.add(JSONObject(it.toString())) }
        return out
    }

    private fun rememberCommentMedia(item: JSONObject) {
        val id = item.optString("id")
        val pack = item.optString("pack")
        val url = item.optString("url")
        val recent = commentMediaRecent().filterNot { old ->
            (id.isNotBlank() && old.optString("id") == id && old.optString("pack") == pack) ||
                (url.isNotBlank() && old.optString("url") == url)
        }.toMutableList()
        recent.add(0, JSONObject(item.toString()))
        val arr = JSONArray()
        recent.take(32).forEach(arr::put)
        appPrefs().edit().putString("comment_media_recent_v2", arr.toString()).apply()
    }

    private fun showCommentMediaPicker(onPick: (JSONObject) -> Unit) {
        val p = UiPreferences.palette(this)
        val loading = AlertDialog.Builder(this).setView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            background = bankGlassDrawable(24, 240, 72, true)
            addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyleSmall).apply {
                indeterminateTintList = android.content.res.ColorStateList.valueOf(p.primary)
            }, LinearLayout.LayoutParams(dp(32), dp(32)).apply { marginEnd = dp(12) })
            addView(TextView(this@MainActivity).apply { text=t("در حال دریافت گیف‌ها...","Loading GIFs..."); setTextColor(Color.WHITE); textSize=12.5f })
        }).create()
        loading.show()
        loading.window?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))

        AccountApi.commentMediaCatalog(this) { result ->
            loading.dismiss()
            if (!result.success || result.json == null) {
                BmNotice.show(this, result.message.ifBlank { t("گیف‌ها دریافت نشد", "Could not load GIFs") }, BmNotice.Kind.ERROR)
                return@commentMediaCatalog
            }
            val packsArray = result.json.optJSONArray("packs") ?: JSONArray()
            val packs = mutableListOf<JSONObject>()
            val all = mutableListOf<JSONObject>()
            for (i in 0 until packsArray.length()) {
                val pack = packsArray.optJSONObject(i) ?: continue
                val slug = pack.optString("slug")
                val label = pack.optString("label").ifBlank { slug }
                val items = pack.optJSONArray("items") ?: JSONArray()
                val copyItems = JSONArray()
                for (j in 0 until items.length()) {
                    val raw = items.optJSONObject(j) ?: continue
                    val item = JSONObject(raw.toString()).apply { put("pack", slug); put("pack_label", label) }
                    copyItems.put(item); all.add(item)
                }
                packs.add(JSONObject().apply { put("slug", slug); put("label", label); put("items", copyItems) })
            }
            if (all.isEmpty()) {
                BmNotice.show(this, t("هیچ گیف یا استیکری روی سایت فعال نیست", "No GIFs or stickers are enabled"), BmNotice.Kind.WARNING)
                return@commentMediaCatalog
            }

            lateinit var dialog: AlertDialog
            val shell = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(10), dp(10), dp(10), dp(14))
                background = bankGlassDrawable(26, 242, 76, true)
            }
            val tabScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            val tabs = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(3), dp(4), dp(7))
            }
            tabScroll.addView(tabs)
            shell.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(72)))

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(5), dp(8), dp(7))
            }
            val title = TextView(this).apply {
                text = t("اخیراً استفاده‌شده", "Recently Used")
                setTextColor(Color.rgb(222, 222, 226))
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            header.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))
            header.addView(TextView(this).apply {
                text = "×"
                setTextColor(Color.rgb(205,205,210))
                textSize = 32f
                gravity = Gravity.CENTER
                isClickable = true
                setOnClickListener { dialog.dismiss() }
            }, LinearLayout.LayoutParams(dp(52), dp(44)))
            shell.addView(header, LinearLayout.LayoutParams(-1, dp(52)))

            val scroll = BankmovieSmoothScrollView(this).apply {
                isFillViewport = false
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            val grid = GridLayout(this).apply {
                columnCount = if (isTvLike()) 5 else 4
                alignmentMode = GridLayout.ALIGN_BOUNDS
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(2), dp(2), dp(2), dp(14))
            }
            scroll.addView(
                grid,
                android.view.ViewGroup.LayoutParams(
                    android.view.ViewGroup.LayoutParams.MATCH_PARENT,
                    android.view.ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            shell.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

            fun mediaCell(item: JSONObject): View {
                return FrameLayout(this).apply {
                    background = rounded(Color.rgb(34,34,37), dp(13), Color.argb(55,255,255,255))
                    clipToOutline = true
                    isClickable = true
                    isFocusable = true
                    applyMobileTouchHalo(this, 13)
                    applyTvFocusHalo(this, 13, 1.045f, 0f)
                    val kind = item.optString("media_type", "image")
                    if (kind == "video") {
                        addView(LinearLayout(this@MainActivity).apply {
                            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                            addView(TextView(this@MainActivity).apply { text="GIF"; setTextColor(Color.WHITE); textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER })
                            addView(TextView(this@MainActivity).apply { text="▶"; setTextColor(p.primary); textSize=18f; gravity=Gravity.CENTER })
                        }, FrameLayout.LayoutParams(-1,-1))
                    } else {
                        val mediaView = commentMediaView(item)
                        addView(mediaView, FrameLayout.LayoutParams(-1,-1))
                    }
                    setOnClickListener { rememberCommentMedia(item); dialog.dismiss(); onPick(item) }
                }
            }

            fun render(items: List<JSONObject>, label: String) {
                title.text = label
                grid.removeAllViews()
                val source = if (items.isEmpty()) all else items
                source.take(180).forEach { item ->
                    grid.addView(mediaCell(item), GridLayout.LayoutParams().apply {
                        width = 0
                        height = dp(if (isTvLike()) 112 else 92)
                        columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                        setMargins(dp(4), dp(4), dp(4), dp(4))
                    })
                }
                scroll.scrollTo(0, 0)
            }

            val recent = commentMediaRecent()
            var selectedTabKey = if (recent.isNotEmpty()) "recent" else "all"
            val tabViews = linkedMapOf<String, FrameLayout>()

            fun refreshTabStyles() {
                tabViews.forEach { (key, view) ->
                    val selected = key == selectedTabKey
                    view.background = rounded(
                        if (selected) Color.rgb(62, 62, 66) else Color.rgb(38, 38, 41),
                        dp(17),
                        if (selected) Color.argb(185, 255, 255, 255) else Color.argb(35, 255, 255, 255)
                    )
                    view.alpha = if (selected) 1f else 0.84f
                    view.scaleX = if (selected) 1.035f else 1f
                    view.scaleY = if (selected) 1.035f else 1f
                }
            }

            fun tab(key: String, label: String, thumb: JSONObject? = null, click: () -> Unit): View {
                val wrap = FrameLayout(this).apply {
                    clipToOutline = true
                    isClickable = true
                    isFocusable = true
                    applyMobileTouchHalo(this, 17)
                    applyTvFocusHalo(this, 17, 1.045f, 0f)
                }
                if (thumb != null && thumb.optString("media_type") != "video") {
                    val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                    wrap.addView(iv, FrameLayout.LayoutParams(-1, -1))
                    loadImage(thumb.optString("url"), iv)
                } else {
                    wrap.addView(TextView(this).apply {
                        text = label
                        setTextColor(Color.rgb(226, 226, 230))
                        textSize = if (label.length <= 2) 23f else 10f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.CENTER
                        maxLines = 2
                    }, FrameLayout.LayoutParams(-1, -1))
                }
                tabViews[key] = wrap
                wrap.setOnClickListener {
                    selectedTabKey = key
                    refreshTabStyles()
                    click()
                }
                return wrap
            }

            tabs.addView(tab("all", "★") { render(all, t("همه گیف‌ها", "All GIFs")) }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginEnd = dp(5) })
            tabs.addView(tab("recent", "◷") { render(recent, t("اخیراً استفاده‌شده", "Recently Used")) }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginEnd = dp(5) })
            packs.forEachIndexed { index, pack ->
                val items = pack.optJSONArray("items") ?: JSONArray()
                val first = items.optJSONObject(0)
                val list = mutableListOf<JSONObject>()
                for (i in 0 until items.length()) items.optJSONObject(i)?.let { list.add(it) }
                val key = "pack:${pack.optString("slug").ifBlank { index.toString() }}"
                tabs.addView(tab(key, pack.optString("label").take(2), thumb = first) {
                    render(list, pack.optString("label"))
                }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginEnd = dp(5) })
            }
            refreshTabStyles()
            render(if (recent.isNotEmpty()) recent else all, if (recent.isNotEmpty()) t("اخیراً استفاده‌شده", "Recently Used") else t("همه گیف‌ها", "All GIFs"))

            dialog = AlertDialog.Builder(this).setView(shell).create()
            dialog.show()
            dialog.window?.apply {
                setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
                setDimAmount(0.52f)
                addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                setGravity(Gravity.BOTTOM)
                setLayout(android.view.WindowManager.LayoutParams.MATCH_PARENT, (resources.displayMetrics.heightPixels * 0.76f).toInt())
            }
        }
    }

    private fun commentMediaView(media: JSONObject): View {
        val p=UiPreferences.palette(this)
        val url=media.optString("url")
        val kind=media.optString("media_type","image")
        if(kind=="video") {
            return VideoView(this).apply {
                background = bankGlassDrawable(16, 226, 62, false)
                setVideoURI(Uri.parse(url))
                setOnPreparedListener { player -> player.isLooping=true; player.setVolume(0f,0f); start() }
                setOnErrorListener { _,_,_ -> true }
            }
        }
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.FIT_CENTER; background = bankGlassDrawable(16, 226, 62, false); clipToOutline=true }
        val ext=media.optString("extension").lowercase(Locale.US)
        if(Build.VERSION.SDK_INT>=28 && ext in setOf("gif","webp")) {
            val finalUrl=normalizeImageUrl(url)
            imageExecutor.execute {
                try {
                    val conn=URL(finalUrl).openConnection() as HttpURLConnection
                    conn.connectTimeout=5000; conn.readTimeout=7000
                    val bytes=conn.inputStream.use { it.readBytes() }; conn.disconnect()
                    val drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(bytes)))
                    runOnUiThread {
                        image.setImageDrawable(drawable)
                        (drawable as? AnimatedImageDrawable)?.apply { repeatCount=AnimatedImageDrawable.REPEAT_INFINITE; start() }
                    }
                } catch (_:Throwable) { runOnUiThread { loadImage(url,image) } }
            }
        } else loadImage(url,image)
        return image
    }

    private fun showCommentComposer(
        item: JSONObject,
        parentId: Long? = null,
        parentName: String = "",
        onDone: () -> Unit
    ) {
        if (!remoteCommentsEnabled || !AccountSession.commentsEnabled(this)) {
            Toast.makeText(this, "بخش دیدگاه‌ها موقتاً از پنل مدیریت غیرفعال است", Toast.LENGTH_SHORT).show()
            return
        }
        if (parentId != null && !AccountSession.commentRepliesEnabled(this)) {
            Toast.makeText(this, "پاسخ به دیدگاه موقتاً غیرفعال است", Toast.LENGTH_SHORT).show()
            return
        }
        if (!AccountSession.isLoggedIn(this)) {
            Toast.makeText(this, "برای ثبت دیدگاه وارد حساب شوید", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, AuthActivity::class.java))
            return
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = rounded(panel, dp(25), Color.argb(110, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(TextView(this).apply {
            text = if (parentId != null) "پاسخ به $parentName" else "ثبت دیدگاه"
            setTextColor(white)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        var rating = 0
        if (parentId == null) {
            box.addView(TextView(this).apply {
                text = "امتیاز شما"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
            })
            val stars = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.RIGHT
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            val starViews = mutableListOf<TextView>()
            fun refreshStars() {
                starViews.forEachIndexed { index, view ->
                    view.text = if (index < rating) "★" else "☆"
                    view.setTextColor(if (index < rating) Color.rgb(255, 195, 45) else muted)
                }
            }
            repeat(5) { index ->
                val star = TextView(this).apply {
                    text = "☆"
                    textSize = 29f
                    gravity = Gravity.CENTER
                    applyTvFocusHalo(this, 999, 1.08f, 0f)
                    setOnClickListener { rating = index + 1; refreshStars() }
                }
                starViews.add(star)
                stars.addView(star, LinearLayout.LayoutParams(dp(48), dp(48)))
            }
            refreshStars()
            box.addView(stars, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(8) })
        }

        val input = EditText(this).apply {
            hint = if (parentId != null) "پاسخ خود را بنویسید..." else "نظر خود را درباره این عنوان بنویسید..."
            setHintTextColor(Color.rgb(116, 116, 128))
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.TOP or Gravity.RIGHT
            minLines = 4
            maxLines = 7
            background = bankGlassDrawable(17, 226, 62, false)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(145)).apply { bottomMargin = dp(8) })

        var selectedMedia: JSONObject? = null
        val mediaButton = TextView(this).apply {
            text = "GIF  •  افزودن گیف یا استیکر"
            setTextColor(blue); textSize=12.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            background = bankGlassDrawable(14, 226, 62, false); applyTvFocusHalo(this,15,1.03f,0f)
            setOnClickListener { showCommentMediaPicker { picked -> selectedMedia=picked; text="✓ گیف/استیکر انتخاب شد  •  تغییر" } }
        }
        box.addView(mediaButton,LinearLayout.LayoutParams(-1,dp(44)).apply { bottomMargin=dp(10) })

        var spoiler = false
        val spoilerToggle = TextView(this).apply {
            text = "□ این دیدگاه اسپویل دارد"
            setTextColor(muted)
            textSize = 12.5f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(10), 0)
            background = bankGlassDrawable(14, 226, 62, false)
            applyTvFocusHalo(this, 15, 1.03f, 0f)
            setOnClickListener {
                spoiler = !spoiler
                text = if (spoiler) "☑ این دیدگاه اسپویل دارد" else "□ این دیدگاه اسپویل دارد"
                setTextColor(if (spoiler) blue else muted)
            }
        }
        if (AccountSession.commentSpoilerEnabled(this)) {
            box.addView(spoilerToggle, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })
        }

        val submit = animatedActionButton(
            if (parentId != null) "ارسال پاسخ" else "ارسال دیدگاه",
            R.drawable.ic_send_round,
            blue
        ) { button ->
            val humanText = input.text.toString().trim()
            val marker = selectedMedia?.let { commentMediaMarker(it) }.orEmpty()
            if (humanText.length < 3 && marker.isBlank()) {
                BmNotice.show(this@MainActivity, "متن دیدگاه خیلی کوتاه است", BmNotice.Kind.WARNING)
                return@animatedActionButton
            }
            val textValue = listOf(marker, humanText).filter { it.isNotBlank() }.joinToString("\n")
            button.isEnabled = false
            button.alpha = 0.65f
            AccountApi.addComment(this@MainActivity, item, textValue, rating, spoiler, parentId) { result ->
                button.isEnabled = true
                button.alpha = 1f
                BmNotice.show(
                    this@MainActivity,
                    result.message.ifBlank { if (result.success) "دیدگاه ثبت شد" else "خطا در ثبت دیدگاه" },
                    if (result.success) BmNotice.Kind.SUCCESS else BmNotice.Kind.ERROR
                )
                if (result.success) {
                    dialog.dismiss()
                    onDone()
                }
            }
        }
        box.addView(submit, LinearLayout.LayoutParams(-1, dp(56)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box, maxWidthDp = 560)
        if (isTvLike()) input.requestFocus()
    }

    private fun showCommentEditDialog(item: JSONObject, comment: JSONObject, onDone: () -> Unit) {
        if (!comment.optBoolean("can_edit")) {
            Toast.makeText(this, "زمان مجاز ویرایش این دیدگاه به پایان رسیده است", Toast.LENGTH_SHORT).show()
            return
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = rounded(panel, dp(24), Color.argb(110, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(TextView(this).apply {
            text = "ویرایش دیدگاه"
            setTextColor(white); textSize = 19f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val input = EditText(this).apply {
            setText(comment.optString("comment"))
            setSelection(text.length)
            setTextColor(white); setHintTextColor(muted); textSize = 14f
            gravity = Gravity.TOP or Gravity.RIGHT; minLines = 4; maxLines = 7
            background = bankGlassDrawable(17, 226, 62, false); setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        box.addView(input, LinearLayout.LayoutParams(-1, dp(145)).apply { bottomMargin = dp(10) })
        var spoiler = comment.optBoolean("spoiler")
        if (AccountSession.commentSpoilerEnabled(this)) {
            box.addView(TextView(this).apply {
                fun bind() { text = if (spoiler) "☑ این دیدگاه اسپویل دارد" else "□ این دیدگاه اسپویل دارد"; setTextColor(if (spoiler) blue else muted) }
                textSize = 12.5f; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(10), 0); background = bankGlassDrawable(14, 226, 62, false)
                applyTvFocusHalo(this, 15, 1.03f, 0f); bind()
                setOnClickListener { spoiler = !spoiler; bind() }
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(12) })
        }
        box.addView(TextView(this).apply {
            text = "ذخیره تغییرات"; setTextColor(Color.WHITE); textSize = 14.5f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(blue, blue2)).apply { cornerRadius = dp(17).toFloat() }
            applyTvFocusHalo(this, 18, 1.035f, 0f)
            setOnClickListener {
                val value = input.text.toString().trim()
                if (value.length < 3) { Toast.makeText(this@MainActivity, "متن دیدگاه خیلی کوتاه است", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                isEnabled = false; alpha = 0.65f
                AccountApi.editComment(this@MainActivity, item, comment.optLong("id"), value, spoiler) { result ->
                    isEnabled = true; alpha = 1f
                    Toast.makeText(this@MainActivity, result.message.ifBlank { if (result.success) "ویرایش شد" else "ویرایش ناموفق بود" }, Toast.LENGTH_SHORT).show()
                    if (result.success) { dialog.dismiss(); onDone() }
                }
            }
        }, LinearLayout.LayoutParams(-1, dp(54)))
        dialog = AlertDialog.Builder(this).setView(box).create(); dialog.show()
        styleShownDialog(dialog, box, input, maxWidthDp = 560)
    }

    private fun commentActionButton(label: String, active: Boolean = false, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(if (active) blue else muted)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(
                if (active) Color.argb(58, Color.red(blue), Color.green(blue), Color.blue(blue)) else Color.argb(118, 38, 38, 40),
                dp(999),
                if (active) Color.argb(145, Color.red(blue), Color.green(blue), Color.blue(blue)) else Color.argb(92, 255, 255, 255)
            )
            applyTvFocusHalo(this, 14, 1.04f, 0f)
            setOnClickListener { onClick() }
        }
    }

    private fun commentIconActionButton(
        iconRes: Int,
        label: String,
        active: Boolean,
        activeColor: Int,
        onClick: () -> Unit
    ): LinearLayout {
        val tint = if (active) activeColor else Color.argb(230, 235, 235, 239)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            background = rounded(
                if (active) Color.argb(58, Color.red(activeColor), Color.green(activeColor), Color.blue(activeColor)) else Color.argb(118, 38, 38, 40),
                dp(999),
                if (active) Color.argb(145, Color.red(activeColor), Color.green(activeColor), Color.blue(activeColor)) else Color.argb(92, 255, 255, 255)
            )
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes); setColorFilter(tint); contentDescription = label
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(6) })
            addView(TextView(this@MainActivity).apply {
                text = label; setTextColor(tint); textSize = 11.2f
                typeface = BankmovieFonts.medium(this@MainActivity); gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-2, -1))
            applyMobileTouchHalo(this, 999)
            applyTvFocusHalo(this, 999, 1.04f, 0f)
            setOnClickListener { onClick() }
        }
    }

    private fun commentVoteGroup(comment: JSONObject, vote: String, performVote: (String) -> Unit): LinearLayout {
        val group = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.argb(118, 38, 38, 40), dp(999), Color.argb(92, 255, 255, 255))
            clipToOutline = true
        }
        fun segment(iconRes: Int, count: Int, code: String, activeColor: Int): LinearLayout {
            val active = vote == code
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(dp(10), 0, dp(10), 0)
                if (active) background = rounded(Color.argb(48, Color.red(activeColor), Color.green(activeColor), Color.blue(activeColor)), dp(999), Color.TRANSPARENT)
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(iconRes); setColorFilter(if (active) activeColor else Color.argb(235, 238, 238, 242))
                }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
                addView(TextView(this@MainActivity).apply {
                    text = count.toString(); setTextColor(if (active) activeColor else Color.argb(235, 238, 238, 242)); textSize = 11f
                    typeface = BankmovieFonts.medium(this@MainActivity); gravity = Gravity.CENTER
                })
                isClickable = true; isFocusable = true; applyMobileTouchHalo(this, 999)
                setOnClickListener { performVote(code) }
            }
        }
        group.addView(segment(R.drawable.ic_comment_like, comment.optInt("like_count"), "like", Color.rgb(49, 196, 108)), LinearLayout.LayoutParams(0, -1, 1f))
        group.addView(View(this).apply { setBackgroundColor(Color.argb(70, 255, 255, 255)) }, LinearLayout.LayoutParams(dp(1), dp(20)))
        group.addView(segment(R.drawable.ic_comment_dislike, comment.optInt("dislike_count"), "dislike", Color.rgb(239, 88, 88)), LinearLayout.LayoutParams(0, -1, 1f))
        return group
    }

    private fun showCommentReportDialog(item: JSONObject, commentId: Long) {
        if (!AccountSession.isLoggedIn(this)) {
            Toast.makeText(this, "برای گزارش دیدگاه وارد حساب شوید", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, AuthActivity::class.java))
            return
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(17), dp(17), dp(17), dp(17))
            background = rounded(panel, dp(24), Color.argb(120, 239, 68, 68))
        }
        box.addView(TextView(this).apply {
            text = "گزارش دیدگاه"
            setTextColor(white)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        box.addView(TextView(this).apply {
            text = "دلیل گزارش را انتخاب کنید. هر کاربر برای هر دیدگاه فقط یک گزارش فعال دارد."
            setTextColor(muted)
            textSize = 12.2f
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        var selectedReason = "spam"
        val reasons = listOf(
            "spam" to "اسپم یا تبلیغ",
            "insult" to "توهین یا آزار",
            "spoiler" to "افشای اسپویل بدون هشدار",
            "illegal" to "محتوای غیرمجاز یا نامناسب",
            "other" to "سایر"
        )
        val reasonViews = mutableListOf<Pair<String, TextView>>()
        fun refreshReasons() {
            reasonViews.forEach { (code, view) ->
                val active = code == selectedReason
                view.text = (if (active) "● " else "○ ") + view.text.toString().removePrefix("● ").removePrefix("○ ")
                view.setTextColor(if (active) Color.rgb(255, 155, 155) else Color.rgb(215, 215, 224))
                view.background = rounded(if (active) Color.argb(45, 239, 68, 68) else panel2, dp(14), if (active) Color.argb(110, 239, 68, 68) else stroke)
            }
        }
        reasons.forEach { (code, label) ->
            val row = TextView(this).apply {
                text = label
                setTextColor(white)
                textSize = 13f
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                setPadding(dp(13), 0, dp(13), 0)
                applyTvFocusHalo(this, 15, 1.035f, 0f)
                setOnClickListener { selectedReason = code; refreshReasons() }
            }
            reasonViews.add(code to row)
            box.addView(row, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(7) })
        }
        refreshReasons()
        val details = EditText(this).apply {
            hint = "توضیح تکمیلی (اختیاری)"
            setHintTextColor(Color.rgb(120, 120, 132))
            setTextColor(white)
            textSize = 13f
            gravity = Gravity.TOP or Gravity.RIGHT
            minLines = 2
            maxLines = 4
            background = bankGlassDrawable(16, 226, 62, false)
            setPadding(dp(12), dp(11), dp(12), dp(11))
        }
        box.addView(details, LinearLayout.LayoutParams(-1, dp(90)).apply { bottomMargin = dp(11) })
        val submit = TextView(this).apply {
            text = "ارسال گزارش"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(174, 43, 62), dp(17), Color.argb(150, 239, 68, 68))
            applyTvFocusHalo(this, 18, 1.04f, 0f)
            setOnClickListener {
                isEnabled = false
                alpha = 0.65f
                AccountApi.reportComment(this@MainActivity, item, commentId, selectedReason, details.text.toString()) { result ->
                    isEnabled = true
                    alpha = 1f
                    Toast.makeText(this@MainActivity, result.message.ifBlank { if (result.success) "گزارش ثبت شد" else "ثبت گزارش ناموفق بود" }, Toast.LENGTH_SHORT).show()
                    if (result.success) dialog.dismiss()
                }
            }
        }
        box.addView(submit, LinearLayout.LayoutParams(-1, dp(52)))
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box, reasonViews.firstOrNull()?.second, maxWidthDp = 560)
    }

    private fun inlineCommentComposer(item: JSONObject, reload: () -> Unit): LinearLayout {
        val p = UiPreferences.palette(this)
        val logged = AccountSession.isLoggedIn(this)
        var selectedMedia: JSONObject? = null
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8)); background = bankGlassDrawable(22, 226, 62, false)
        }
        val input = EditText(this).apply {
            hint = if (logged) t("دیدگاهت را بنویس...", "Add a comment...") else t("برای ثبت دیدگاه وارد شوید", "Sign in to comment")
            setHintTextColor(p.faint); setTextColor(p.text); textSize = 13.5f; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 4; minLines = 1; background = null; isFocusable = logged; isFocusableInTouchMode = logged; setPadding(dp(10),0,dp(10),0)
            if (!logged) setOnClickListener { startActivity(Intent(this@MainActivity, AuthActivity::class.java)) }
        }
        val gif = TextView(this).apply {
            text="GIF"; setTextColor(p.primary); textSize=11f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER
            background=rounded(Color.argb(35,Color.red(p.primary),Color.green(p.primary),Color.blue(p.primary)),dp(14),Color.argb(90,Color.red(p.primary),Color.green(p.primary),Color.blue(p.primary)))
            isClickable=true; isFocusable=true; applyTvFocusHalo(this,14,1.04f,0f)
            setOnClickListener { if(!logged) startActivity(Intent(this@MainActivity,AuthActivity::class.java)) else showCommentMediaPicker { picked -> selectedMedia=picked; text="✓GIF" } }
        }
        val send = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.primary) }; isClickable=true; isFocusable=true; applyMobileTouchHalo(this,999)
            addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_send_round); setColorFilter(p.onPrimary); setPadding(dp(13),dp(13),dp(13),dp(13)) },FrameLayout.LayoutParams(-1,-1))
            setOnClickListener {
                if(!logged){ startActivity(Intent(this@MainActivity,AuthActivity::class.java)); return@setOnClickListener }
                val human=input.text.toString().trim(); val marker=selectedMedia?.let { commentMediaMarker(it) }.orEmpty()
                if(human.length<3 && marker.isBlank()){ BmNotice.show(this@MainActivity,t("دیدگاه خیلی کوتاه است","Comment is too short"),BmNotice.Kind.WARNING); return@setOnClickListener }
                val value=listOf(marker,human).filter{it.isNotBlank()}.joinToString("\n")
                isEnabled=false; alpha=.55f
                AccountApi.addComment(this@MainActivity,item,value,0,false,null){ result ->
                    isEnabled=true; alpha=1f
                    BmNotice.show(this@MainActivity,result.message.ifBlank{if(result.success)t("دیدگاه ثبت شد","Comment submitted") else t("ثبت دیدگاه ناموفق بود","Could not submit comment")},if(result.success)BmNotice.Kind.SUCCESS else BmNotice.Kind.ERROR)
                    if(result.success){ input.setText(""); selectedMedia=null; gif.text="GIF"; reload() }
                }
            }
        }
        row.addView(input,LinearLayout.LayoutParams(0,dp(54),1f))
        row.addView(gif,LinearLayout.LayoutParams(dp(48),dp(42)).apply { marginStart=dp(6) })
        row.addView(send,LinearLayout.LayoutParams(dp(50),dp(50)).apply { marginStart=dp(7) })
        BankmovieFonts.applyToTree(this,row); return row
    }

    private fun commentCard(item: JSONObject, comment: JSONObject, isReply: Boolean, reload: () -> Unit): LinearLayout {
        val id = comment.optLong("id", comment.optLong("comment_id", comment.optLong("commentId", 0L)))
        val username = comment.optString("username").ifBlank { "کاربر" }
        val spoiler = comment.optBoolean("spoiler")
        val canDelete = comment.optBoolean("can_delete")
        val canReport = comment.optBoolean("can_report")
        val canEdit = comment.optBoolean("can_edit")
        val canPin = comment.optBoolean("can_pin")
        val isPinned = comment.optBoolean("is_pinned")
        val edited = comment.optBoolean("edited")
        val isPending = comment.optBoolean("is_pending")
        val badge = comment.optString("badge")
        val vote = comment.optString("user_vote")
        var voteInFlight = false
        fun performVote(type: String) {
            if (id <= 0L) {
                BmNotice.show(this, t("شناسه دیدگاه معتبر نیست؛ دیدگاه‌ها را دوباره بارگذاری کنید", "Invalid comment id; reload comments"), BmNotice.Kind.WARNING)
                return
            }
            if (voteInFlight) return
            voteInFlight = true
            AccountApi.voteComment(this, item, id, type) { result ->
                voteInFlight = false
                if (!result.success) {
                    BmNotice.show(this, result.message.ifBlank { t("ثبت رأی انجام نشد", "Could not save vote") }, BmNotice.Kind.ERROR)
                    return@voteComment
                }
                result.json?.let { json ->
                    comment.put("like_count", json.optInt("like_count", comment.optInt("like_count")))
                    comment.put("dislike_count", json.optInt("dislike_count", comment.optInt("dislike_count")))
                    comment.put("user_vote", json.optString("user_vote", type))
                }
                BmNotice.show(this, t("رأی شما ثبت شد", "Your vote was saved"), BmNotice.Kind.SUCCESS)
                reload()
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isReply) 12 else 16), dp(if (isReply) 12 else 16), dp(if (isReply) 12 else 16), dp(if (isReply) 12 else 15))
            val cardColor = when {
                isPending -> Color.argb(55, 245, 158, 11)
                isReply -> Color.argb(72, 255, 255, 255)
                else -> if (currentScreen == "detail") alphaSurface2() else UiPreferences.blend(panel2, Color.WHITE, if (isLightTheme()) 0.03f else 0.018f)
            }
            val cardStroke = when {
                isPinned -> Color.argb(185, Color.red(blue), Color.green(blue), Color.blue(blue))
                isPending -> Color.argb(135, 245, 158, 11)
                isReply -> Color.argb(45, 255, 255, 255)
                else -> if (currentScreen == "detail") alphaLine(68) else stroke
            }
            background = rounded(cardColor, dp(if (isReply) 18 else 22), cardStroke)
            val top = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            top.addView(commentAvatarView(comment, if (isReply) 38 else 46), LinearLayout.LayoutParams(dp(if (isReply) 38 else 46), dp(if (isReply) 38 else 46)).apply { marginStart = dp(10) })
            val info = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            val nameLine = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            nameLine.addView(TextView(this@MainActivity).apply {
                text = username
                setTextColor(white)
                textSize = if (isReply) 12.5f else 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-2, -2))
            if (badge.isNotBlank()) nameLine.addView(TextView(this@MainActivity).apply {
                text = if (badge == "مدیر") "✓" else "◆ $badge"
                setTextColor(Color.WHITE)
                textSize = if (badge == "مدیر") 10.5f else 9.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = if (badge == "مدیر") GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.rgb(29, 120, 255))
                } else rounded(Color.argb(42, 255, 180, 20), dp(10), Color.argb(90, 255, 188, 55))
                if (badge != "مدیر") setPadding(dp(8), dp(3), dp(8), dp(3))
            }, if (badge == "مدیر") LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginEnd = dp(7) } else LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(7) })
            info.addView(nameLine, LinearLayout.LayoutParams(-1, -2))
            info.addView(TextView(this@MainActivity).apply {
                text = buildString {
                    if (isPending) append("در انتظار تأیید • ")
                    append(comment.optString("date_text"))
                    if (edited) append(" • ویرایش‌شده")
                    if (isPinned) append(" • پین‌شده")
                }
                setTextColor(if (isPending) Color.rgb(255, 184, 81) else muted)
                textSize = 10.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(3), 0, 0)
            })
            top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val rating = comment.optInt("rating")
            if (rating > 0) top.addView(TextView(this@MainActivity).apply {
                text = "$rating ★"
                setTextColor(Color.rgb(255, 195, 45))
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(38, 255, 195, 45), dp(12), Color.argb(75, 255, 195, 45))
                setPadding(dp(9), dp(5), dp(9), dp(5))
            })
            if (isPinned) top.addView(TextView(this@MainActivity).apply {
                text = "📌"; textSize = 14f; gravity = Gravity.CENTER; contentDescription = "دیدگاه پین‌شده"
            }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(5) })
            addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

            val body = TextView(this@MainActivity).apply {
                text = if (spoiler) "این دیدگاه دارای اسپویل است — برای نمایش بزنید" else comment.optString("comment")
                setTextColor(if (spoiler) blue else if (isLightTheme() && currentScreen != "detail") Color.rgb(35, 39, 48) else Color.rgb(232, 234, 241))
                textSize = if (isReply) 13f else 14.2f
                gravity = Gravity.RIGHT
                setLineSpacing(dp(3).toFloat(), 1f)
                if (spoiler) {
                    background = rounded(Color.argb(34, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(13), Color.argb(95, Color.red(blue), Color.green(blue), Color.blue(blue)))
                    setPadding(dp(10), dp(9), dp(10), dp(9))
                    setOnClickListener {
                        text = comment.optString("comment")
                        setTextColor(Color.rgb(225, 226, 232))
                        background = null
                        setPadding(0, 0, 0, 0)
                        setOnClickListener(null)
                    }
                }
            }
            addView(body, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            val media = comment.optJSONObject("media")
            if (media != null && media.optString("url").isNotBlank()) {
                val mediaView = commentMediaView(media).apply { visibility = if (spoiler) View.GONE else View.VISIBLE }
                addView(mediaView, LinearLayout.LayoutParams(dp(if(isReply)150 else 190), dp(if(isReply)150 else 190)).apply { gravity=Gravity.RIGHT; bottomMargin=dp(10) })
                if (spoiler) body.setOnClickListener {
                    body.text = comment.optString("comment").ifBlank { "گیف / استیکر" }
                    body.setTextColor(Color.rgb(225,226,232)); body.background=null; body.setPadding(0,0,0,0); body.setOnClickListener(null)
                    mediaView.visibility=View.VISIBLE
                }
            }

            val actions = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT
            }
            if (!isPending && AccountSession.commentVotesEnabled(this@MainActivity)) {
                actions.addView(commentVoteGroup(comment, vote) { performVote(it) }, LinearLayout.LayoutParams(dp(132), dp(38)).apply { marginStart = dp(7) })
                if (AccountSession.commentRepliesEnabled(this@MainActivity)) actions.addView(commentIconActionButton(
                    R.drawable.ic_comment_reply,
                    "پاسخ",
                    false,
                    blue
                ) {
                    showCommentComposer(item, id, username, reload)
                }, LinearLayout.LayoutParams(dp(82), dp(38)).apply { marginStart = dp(6) })
            }
            if (canReport && !isPending && AccountSession.commentReportsEnabled(this@MainActivity)) actions.addView(commentActionButton("گزارش") {
                showCommentReportDialog(item, id)
            }, LinearLayout.LayoutParams(dp(70), dp(38)).apply { marginStart = dp(6) })
            if (canEdit) actions.addView(commentActionButton("ویرایش") {
                showCommentEditDialog(item, comment, reload)
            }, LinearLayout.LayoutParams(dp(72), dp(38)).apply { marginStart = dp(6) })
            if (canPin && !isPending) actions.addView(commentActionButton(if (isPinned) "برداشتن پین" else "پین", isPinned) {
                AccountApi.pinComment(this@MainActivity, item, id, !isPinned) { result ->
                    Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                    if (result.success) reload()
                }
            }, LinearLayout.LayoutParams(if (isPinned) dp(100) else dp(62), dp(38)).apply { marginStart = dp(6) })
            if (canDelete) actions.addView(commentActionButton("حذف") {
                AccountApi.deleteComment(this@MainActivity, item, id) { result ->
                    Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_SHORT).show()
                    if (result.success) reload()
                }
            }, LinearLayout.LayoutParams(dp(62), dp(38)))
            if (actions.childCount > 0) {
                val actionScroll = HorizontalBankmovieSmoothScrollView(this@MainActivity).apply {
                    isHorizontalScrollBarEnabled = false
                    clipToPadding = false
                    addView(actions, ViewGroup.LayoutParams(-2, dp(40)))
                }
                addView(actionScroll, LinearLayout.LayoutParams(-1, dp(42)))
            }

            val replies = comment.optJSONArray("replies") ?: JSONArray()
            if (replies.length() > 0) {
                val replyBox = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(0, dp(10), dp(if (isReply) 10 else 16), 0)
                }
                for (i in 0 until replies.length()) {
                    replies.optJSONObject(i)?.let { reply ->
                        replyBox.addView(commentCard(item, reply, true, reload), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
                    }
                }
                addView(replyBox, LinearLayout.LayoutParams(-1, -2))
            }
        }
    }


    private fun renderCommentsSection(page: LinearLayout, item: JSONObject) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(10), 0, dp(6))
        }
        page.addView(root, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(18) })
        if (!remoteCommentsEnabled || !AccountSession.commentsEnabled(this)) {
            root.addView(commentEmptyStateBox("دیدگاه‌ها موقتاً غیرفعال است", "مدیریت بانک مووی این بخش را موقتاً از پنل غیرفعال کرده است"), LinearLayout.LayoutParams(-1, -2))
            return
        }
        var selectedSort = "all"
        lateinit var reload: () -> Unit
        reload = {
            root.removeAllViews()
            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            val title = TextView(this).apply {
                text = "دیدگاه‌های کاربران"
                setTextColor(white)
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }
            header.addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
            header.addView(TextView(this).apply {
                text = if (AccountSession.isLoggedIn(this@MainActivity)) t("نظر شما مهم است", "Your opinion matters") else t("برای گفتگو وارد شوید", "Sign in to join")
                setTextColor(muted)
                textSize = 11.5f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-2, dp(42)))
            root.addView(header, LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(7) })
            root.addView(inlineCommentComposer(item, reload), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
            val sortOptions = listOf(
                "all" to "همه دیدگاه‌ها",
                "latest" to "جدیدترین",
                "popular" to "محبوب‌ترین",
                "controversial" to "بحث‌برانگیز",
                "replies" to "بیشترین پاسخ",
                "oldest" to "قدیمی‌ترین"
            )
            val selectedSortLabel = sortOptions.firstOrNull { it.first == selectedSort }?.second ?: "همه دیدگاه‌ها"
            val sortMenu = TextView(this).apply {
                text = "$selectedSortLabel  ▾"
                setTextColor(white)
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                setPadding(dp(14), 0, dp(14), 0)
                background = rounded(panel2, dp(16), if (selectedSort == "all") stroke else Color.argb(150, Color.red(blue), Color.green(blue), Color.blue(blue)))
                setOnClickListener {
                    val labels = sortOptions.map { it.second }.toTypedArray()
                    val checked = sortOptions.indexOfFirst { it.first == selectedSort }.coerceAtLeast(0)
                    val dialog = AlertDialog.Builder(this@MainActivity)
                        .setTitle("مرتب‌سازی دیدگاه‌ها")
                        .setSingleChoiceItems(labels, checked) { d, which ->
                            val code = sortOptions.getOrNull(which)?.first ?: "all"
                            d.dismiss()
                            if (selectedSort != code) {
                                selectedSort = code
                                reload()
                            }
                        }
                        .create()
                    dialog.show()
                    dialog.listView?.let { applyTvFocusToClickableTree(it) }
                }
                applyTvFocusHalo(this, 17, 1.035f, 0f)
            }
            root.addView(sortMenu, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(9) })
            val loading = commentLoadingSpinner()
            root.addView(loading, LinearLayout.LayoutParams(-1, dp(72)))
            val apiSort = if (selectedSort == "all") "latest" else selectedSort
            AccountApi.listComments(this, item, 1, 20, apiSort) { result ->
                root.removeView(loading)
                if (!result.success || result.json == null) {
                    root.addView(commentEmptyStateBox("دیدگاه‌ها دریافت نشد", result.message.ifBlank { "اتصال به بخش دیدگاه‌ها برقرار نشد" }), LinearLayout.LayoutParams(-1, -2))
                    root.addView(commentActionButton("تلاش مجدد") { reload() }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(8) })
                    applyTvFocusToClickableTree(root)
                    return@listComments
                }
                val total = result.json.optInt("total")
                val avg = result.json.optDouble("rating_avg", 0.0)
                title.text = if (total > 0) "دیدگاه‌های کاربران  •  $total" else "دیدگاه‌های کاربران"
                if (avg > 0) {
                    root.addView(TextView(this).apply {
                        text = "میانگین امتیاز کاربران: ${String.format(Locale.US, "%.1f", avg)} از ۵"
                        setTextColor(Color.rgb(255, 195, 45))
                        textSize = 12.2f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                        background = rounded(Color.argb(36, 255, 195, 45), dp(14), Color.argb(65, 255, 195, 45))
                        setPadding(dp(12), dp(9), dp(12), dp(9))
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
                }
                val items = result.json.optJSONArray("items") ?: JSONArray()
                if (items.length() == 0) {
                    root.addView(commentEmptyStateBox("هنوز دیدگاهی ثبت نشده", "اولین نفری باشید که درباره این عنوان نظر می‌دهد"), LinearLayout.LayoutParams(-1, -2))
                } else {
                    for (i in 0 until items.length()) items.optJSONObject(i)?.let { comment ->
                        root.addView(commentCard(item, comment, false, reload), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
                    }
                }
                applyTvFocusToClickableTree(root)
            }
        }
        reload()
    }

    private fun playTrailer(item: JSONObject) {
        val trailer = item.optString("trailer_url").ifBlank { item.optString("trailer") }
        if (trailer.isBlank()) {
            Toast.makeText(this, "تریلر برای این عنوان ثبت نشده", Toast.LENGTH_SHORT).show()
            return
        }
        val arr = JSONArray().put(JSONObject().apply {
            put("url", trailer)
            put("title", item.optString("title_fa").ifBlank { item.optString("title") })
            put("quality", "Trailer")
            put("type", "trailer")
            put("type_fa", "تریلر")
            put("display_label", "تریلر")
        })
        val payload = JSONObject().apply {
            put("video", trailer)
            put("title", item.optString("title_fa").ifBlank { item.optString("title") })
            put("selectedIndex", 0)
            put("tracks", arr)
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, trailer)
            putExtra(PlayerActivity.EXTRA_TITLE, item.optString("title_fa").ifBlank { item.optString("title") })
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, payload.toString())
        })
    }

    private fun showDownloadOptions(item: JSONObject) {
        val links = sortedArchive1Links(playableLinks(item))
        if (links.isEmpty()) {
            Toast.makeText(this, "لینک مستقیم دانلود پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        showDownloadForLinks(item, links)
    }

    private fun openExternal(url: String, packageName: String?) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (packageName != null) intent.setPackage(packageName)
        try { startActivity(intent) } catch (_: Throwable) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    private fun seedFromSlider(item: JSONObject): JSONObject? {
        val directArchive = item.optInt("target_archive", 0)
        val directId = item.optString("target_id").trim()
        if (directArchive in 1..3 && directId.isNotBlank()) {
            return JSONObject().apply {
                put("id", directId)
                put("archive", directArchive)
                put("type", item.optString("target_type").ifBlank { "movie" })
                put("title", item.optString("title"))
                put("title_fa", item.optString("title_fa"))
                put("poster", item.optString("image"))
                put("image", item.optString("image"))
                if (directArchive == 2) {
                    put("source", "website_db")
                    directId.toIntOrNull()?.takeIf { it > 0 }?.let { dbId ->
                        put("db_id", dbId)
                        put("movie_id", dbId)
                    }
                }
                item.optString("link_abs").ifBlank { item.optString("link") }.takeIf { it.isNotBlank() }?.let { put("source_url", it) }
            }
        }

        val link = item.optString("link_abs").ifBlank { item.optString("link") }
        if (link.isBlank()) return null
        return try {
            val uri = Uri.parse(link)
            uri.getQueryParameter("imdb")?.takeIf { it.isNotBlank() }?.let { imdb ->
                return JSONObject().put("id", imdb).put("archive", 2).put("type", "movie").put("source", "website_db")
            }
            val slug = uri.getQueryParameter("slug")
            val arc = uri.getQueryParameter("arc")?.toIntOrNull() ?: 2
            val type = uri.getQueryParameter("type") ?: "movie"
            if (!slug.isNullOrBlank() && arc in 1..3) {
                return JSONObject().put("id", slug).put("archive", arc).put("type", type).apply {
                    if (arc == 2) put("source", "website_db")
                }
            }
            val segments = uri.pathSegments
            val path = segments.lastOrNull().orEmpty()
            val inferredArchive = when {
                path.startsWith("arc1-", true) -> 1
                path.startsWith("arc3-", true) -> 3
                else -> 2
            }
            val inferredId = path.removePrefix("arc1-").removePrefix("arc3-")
            if (inferredId.isNotBlank()) JSONObject().put("id", inferredId).put("archive", inferredArchive).put("type", type).apply {
                if (inferredArchive == 2) put("source", "website_db")
            } else null
        } catch (_: Throwable) { null }
    }

    private fun detailSectionTitle(title: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(16), 0, dp(10))
            addView(View(this@MainActivity).apply {
                background = rounded(Color.rgb(235, 35, 45), dp(3), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(dp(5), dp(27)).apply { marginStart = dp(10) })
            addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
            })
        }
    }

    private fun detailMetaPill(iconRes: Int, label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bankGlassDrawable(17, 226, 64, false)
            setPadding(dp(10), dp(7), dp(10), dp(7))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                if (iconRes != R.drawable.ic_imdb) setColorFilter(Color.rgb(235, 35, 45))
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(if (iconRes == R.drawable.ic_imdb) dp(38) else dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = if (label.isBlank()) value.ifBlank { "-" } else "$label: ${value.ifBlank { "-" }}"
                setTextColor(white)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
    }

    private fun detailGenreChip(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.rgb(225, 232, 244))
            textSize = 12f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = bankGlassDrawable(19, 220, 62, false)
            setPadding(dp(16), 0, dp(16), 0)
        }
    }

    private fun trailerPurpleButton(click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bankPrimaryGlassDrawable(18)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_trailer)
                setColorFilter(white)
            }, LinearLayout.LayoutParams(dp(19), dp(19)))
            addView(View(this@MainActivity), LinearLayout.LayoutParams(dp(9), 1))
            addView(TextView(this@MainActivity).apply {
                text = "تماشای تریلر"
                setTextColor(white)
                textSize = 12.3f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }


    private fun favoriteHeartButton(item: JSONObject, click: () -> Unit): FrameLayout {
        val active = isFavorite(item)
        val p = UiPreferences.palette(this)
        return FrameLayout(this).apply {
            visibility = if (AccountSession.watchlistEnabled(this@MainActivity)) View.VISIBLE else View.GONE
            clipToOutline = true
            contentDescription = if (active) t("حذف از واچ‌لیست", "Remove from watchlist") else t("افزودن به واچ‌لیست", "Add to watchlist")
            background = rounded(
                if (active) p.primary else Color.argb(if (p.light) 236 else 168, Color.red(p.panel2), Color.green(p.panel2), Color.blue(p.panel2)),
                dp(999),
                if (active) p.primary2 else Color.argb(145, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary))
            )
            elevation = dp(6).toFloat()
            applyTvFocusHalo(this, 999, 1.055f, dp(6).toFloat())
            applyMobileTouchHalo(this, 999)
            val icon = ImageView(this@MainActivity).apply {
                setImageResource(if (active) R.drawable.ic_watchlist_filled else R.drawable.ic_watchlist_outline)
                setColorFilter(if (active) p.onPrimary else p.primary)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }
            addView(icon, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
            setOnClickListener {
                animate().cancel()
                icon.animate().cancel()
                animate().scaleX(0.88f).scaleY(0.88f).setDuration(70L).withEndAction {
                    icon.animate().scaleX(1.28f).scaleY(1.28f).rotation(8f).setDuration(115L).withEndAction {
                        icon.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(170L)
                            .setInterpolator(android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)).start()
                    }.start()
                    animate().scaleX(1f).scaleY(1f).setDuration(175L)
                        .setInterpolator(android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f))
                        .withEndAction { click() }.start()
                }.start()
            }
        }
    }

    private fun purpleTrailerButton(click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(235, 35, 45), Color.rgb(155, 16, 32))
            ).apply {
                cornerRadius = dp(23).toFloat()
                setStroke(dp(1), Color.argb(145, 255, 145, 150))
            }
            elevation = dp(10).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            applyTvFocusHalo(this, 24, 1.045f, dp(10).toFloat())
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(105).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_trailer)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(20), dp(20)))
            addView(View(this@MainActivity), LinearLayout.LayoutParams(dp(10), 1))
            addView(TextView(this@MainActivity).apply {
                text = "تریلر"
                setTextColor(white)
                textSize = 12.9f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun detailActionButton(label: String, iconRes: Int, red: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (red) bankPrimaryGlassDrawable(23) else bankGlassDrawable(23, 232, 74, true)
            elevation = if (red) dp(7).toFloat() else dp(3).toFloat()
            setPadding(dp(14), 0, dp(14), 0)
            applyTvFocusHalo(this, 24, 1.045f, elevation)
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(105).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply { setImageResource(iconRes); setColorFilter(if (red) alphaTextOnPrimary() else white) }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(if (red) alphaTextOnPrimary() else white)
                textSize = 12.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun expandableDescription(desc: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bankGlassDrawable(20, 238, 70, true)
            setPadding(dp(14), dp(14), dp(14), dp(12))
        }
        val body = TextView(this).apply {
            text = desc.ifBlank { "توضیحاتی برای این عنوان ثبت نشده است." }
            setTextColor(Color.rgb(218, 226, 240))
            textSize = 14.2f
            setLineSpacing(dp(5).toFloat(), 1f)
            maxLines = 3
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.RIGHT
        }
        val more = TextView(this).apply {
            text = "ادامه بیشتر"
            setTextColor(Color.rgb(235, 35, 45))
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(10), 0, 0)
            setOnClickListener {
                if (body.maxLines == 3) {
                    body.maxLines = 100
                    body.ellipsize = null
                    text = "بستن توضیحات"
                } else {
                    body.maxLines = 3
                    body.ellipsize = TextUtils.TruncateAt.END
                    text = "ادامه بیشتر"
                }
            }
        }
        box.addView(body)
        if ((desc.length) > 160) box.addView(more)
        return box
    }

    private fun addJsonRail(page: LinearLayout, title: String, items: JSONArray, showMore: Boolean = true) {
        if (items.length() == 0) return
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(23) }
        }
        val header = sectionHeader(title, { }, showMore)
        box.addView(header)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroller = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        box.addView(scroller)
        page.addView(box)
        for (i in 0 until minOf(items.length(), 14)) {
            items.optJSONObject(i)?.let { row.addView(posterCard(it, dp(134), dp(244))) }
        }
        wireTvSectionDown(header, row.getChildAtOrNull(0))
    }

    private fun showActorPage(actor: JSONObject) {
        pushCurrentScreenForBack()
        val savedActor = actor.toString()
        val slug = actor.optString("slug").ifBlank {
            val url = actor.optString("url").ifBlank { actor.optString("bankmovie_url") }
            Uri.parse(url).pathSegments.let { segs ->
                val idx = segs.indexOf("actors")
                if (idx >= 0 && idx + 1 < segs.size) segs[idx + 1] else ""
            }
        }
        val actorUrl = actor.optString("url").ifBlank { actor.optString("bankmovie_url") }
        val nameFallback = actor.optString("name")
        currentScreen = "actor"
        rememberCurrentScreen { showActorPage(JSONObject(savedActor)) }
        buildBottomNav()
        clear()

        val tv = isTvLike()
        val scroll = BankmovieSmoothScrollView(this).apply { clipToPadding = false; setPadding(0, 0, 0, dp(108)) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(if (tv) dp(12) else 0, dp(8), if (tv) dp(12) else 0, dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)
        page.addView(actorPageLoadingSkeleton(), LinearLayout.LayoutParams(-1, -2))

        val url = when {
            slug.isNotBlank() -> "$apiBase?action=actor&slug=${enc(slug)}&name=${enc(nameFallback)}"
            actorUrl.isNotBlank() -> "$apiBase?action=actor&url=${enc(actorUrl)}&name=${enc(nameFallback)}"
            else -> "$apiBase?action=actor&name=${enc(nameFallback)}"
        }

        fetch(url) { ok, json, err ->
            runOnUiThread {
                page.removeAllViews()
                if (!ok || json == null) {
                    page.setPadding(dp(12), dp(8), dp(12), dp(28))
                    page.addView(errorView(err ?: t("صفحه بازیگر بارگذاری نشد", "Actor page did not load")), LinearLayout.LayoutParams(-1, -2))
                    return@runOnUiThread
                }
                val obj = json.optJSONObject("actor") ?: JSONObject()
                val name = obj.optString("name").ifBlank { nameFallback.ifBlank { t("بازیگر", "Actor") } }
                val photo = obj.optString("image").ifBlank { obj.optString("photo") }.ifBlank { actor.optString("image") }
                val role = obj.optString("role")
                    .ifBlank { obj.optString("character") }
                    .ifBlank { actor.optString("role") }
                val items = json.optJSONArray("items") ?: json.optJSONArray("movies") ?: JSONArray()
                page.addView(actorHeroCard(name, photo, role, items.length()), LinearLayout.LayoutParams(-1, -2))

                val body = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(12), dp(18), dp(12), dp(28))
                    addView(TextView(this@MainActivity).apply {
                        text = t("${items.length()} عنوان پیدا شد", "${items.length()} titles found")
                        setTextColor(UiPreferences.palette(this@MainActivity).muted)
                        textSize = 12.5f
                        gravity = Gravity.LEFT
                        layoutDirection = View.LAYOUT_DIRECTION_LTR
                    }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
                }
                val grid = GridLayout(this).apply {
                    columnCount = if (tv) 8 else 3
                    layoutDirection = if (tv) View.LAYOUT_DIRECTION_LTR else View.LAYOUT_DIRECTION_RTL
                    alignmentMode = GridLayout.ALIGN_MARGINS
                    useDefaultMargins = false
                }
                body.addView(grid, LinearLayout.LayoutParams(if (tv) -2 else -1, -2))
                val w = if (tv) tvGridCardWidth() else mobileGridCardWidth()
                val h = if (tv) tvGridCardHeight(w) else mobileGridCardHeight(w)
                for (i in 0 until items.length()) items.optJSONObject(i)?.let { grid.addView(posterCard(it, w, h)) }
                if (items.length() == 0) body.addView(emptyStateBox(t("فیلمی پیدا نشد", "No titles found"), t("برای این بازیگر هنوز اثری ثبت نشده است.", "No movies or series are linked to this actor yet.")), LinearLayout.LayoutParams(-1, -2))
                page.addView(body, LinearLayout.LayoutParams(-1, -2))
                BankmovieFonts.applyToTree(this@MainActivity, page)
                applyTvFocusToClickableTree(page)
            }
        }
    }

    private fun actorHeroCard(name: String, photo: String, role: String, count: Int): View {
        val p = UiPreferences.palette(this)
        if (isTvLike()) {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = bankGlassDrawable(28, 236, 70, true)
                setPadding(dp(18), dp(18), dp(18), dp(18))
                val avatar = FrameLayout(this@MainActivity).apply { background = bankGlassDrawable(24, 226, 62, false); clipToOutline = true }
                if (photo.isNotBlank()) {
                    val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                    avatar.addView(img, FrameLayout.LayoutParams(-1, -1)); loadImage(photo, img)
                }
                addView(avatar, LinearLayout.LayoutParams(dp(132), dp(176)).apply { marginStart = dp(20) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                    addView(TextView(this@MainActivity).apply { text = name; setTextColor(p.text); textSize = 27f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT })
                    if (role.isNotBlank()) addView(TextView(this@MainActivity).apply { text = role; setTextColor(p.primary); textSize = 13f; gravity = Gravity.RIGHT; setPadding(0, dp(8), 0, 0) })
                    addView(TextView(this@MainActivity).apply { text = t("$count عنوان", "$count titles"); setTextColor(p.muted); textSize = 12.5f; gravity = Gravity.RIGHT; setPadding(0, dp(8), 0, 0) })
                }, LinearLayout.LayoutParams(0, -1, 1f))
            }
        }

        return FrameLayout(this).apply {
            val heroHeight = dp(360)
            layoutParams = LinearLayout.LayoutParams(-1, heroHeight)
            setBackgroundColor(Color.BLACK)
            clipToOutline = true

            if (photo.isNotBlank()) {
                val backdrop = ImageView(this@MainActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    alpha = 0.52f
                    scaleX = 1.18f
                    scaleY = 1.18f
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        setRenderEffect(android.graphics.RenderEffect.createBlurEffect(18f, 18f, android.graphics.Shader.TileMode.CLAMP))
                    }
                }
                addView(backdrop, FrameLayout.LayoutParams(-1, -1))
                loadImage(photo, backdrop)
            }
            addView(View(this@MainActivity).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(45, 0, 0, 0), Color.argb(145, 0, 0, 0), Color.rgb(3, 7, 14)))
            }, FrameLayout.LayoutParams(-1, -1))

            addView(svgHeaderIcon(R.drawable.ic_player_back) { handleSmartBack() }, FrameLayout.LayoutParams(dp(48), dp(48), Gravity.TOP or Gravity.LEFT).apply {
                topMargin = dp(12); leftMargin = dp(12)
            })

            val center = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
                setPadding(dp(18), dp(58), dp(18), dp(20))
                val avatar = FrameLayout(this@MainActivity).apply {
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(p.panel2); setStroke(dp(2), Color.argb(160, 255, 255, 255)) }
                    clipToOutline = true
                    elevation = dp(8).toFloat()
                    if (photo.isNotBlank()) {
                        val img = ImageView(this@MainActivity).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
                        addView(img, FrameLayout.LayoutParams(-1, -1)); loadImage(photo, img)
                    } else {
                        addView(ImageView(this@MainActivity).apply { setImageResource(R.drawable.ic_avatar_circle); setColorFilter(p.primary); setPadding(dp(28), dp(28), dp(28), dp(28)) }, FrameLayout.LayoutParams(-1, -1))
                    }
                }
                addView(avatar, LinearLayout.LayoutParams(dp(112), dp(112)).apply { bottomMargin = dp(11) })
                if (role.isNotBlank()) addView(TextView(this@MainActivity).apply {
                    text = role
                    setTextColor(Color.rgb(225, 228, 235))
                    textSize = 11.7f
                    gravity = Gravity.CENTER
                    background = rounded(Color.argb(100, 0, 0, 0), dp(12), Color.argb(55, 255, 255, 255))
                    setPadding(dp(12), dp(5), dp(12), dp(5))
                }, LinearLayout.LayoutParams(-2, -2).apply { bottomMargin = dp(8) })
                addView(TextView(this@MainActivity).apply {
                    text = name
                    setTextColor(Color.WHITE)
                    textSize = 25f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = TextUtils.TruncateAt.END
                    setShadowLayer(5f, 0f, 2f, Color.BLACK)
                }, LinearLayout.LayoutParams(-1, -2))
            }
            addView(center, FrameLayout.LayoutParams(-1, -1))
        }
    }

    private fun renderActors(page: LinearLayout, item: JSONObject) {
        val actors = item.optJSONArray("actors") ?: return
        if (actors.length() == 0) return
        val tv = isTvLike()
        val host = page
        val header = sectionHeader("بازیگران", more = { })
        host.addView(header)
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            if (tv) {
                setPadding(dp(2), 0, dp(2), 0)
            }
        }
        val scroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(row)
        }
        for (i in 0 until minOf(actors.length(), 14)) {
            val obj = actors.optJSONObject(i) ?: JSONObject().put("name", actors.optString(i))
            val name = obj.optString("name").takeIf { it.isNotBlank() } ?: actors.optString(i)
            val role = obj.optString("role")
            val image = obj.optString("image").ifBlank { obj.optString("photo") }
            if (name.isBlank() || name.startsWith("{")) continue
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = rounded(alphaSurface2(), dp(22), alphaLine(64))
                setPadding(dp(8), dp(8), dp(8), dp(8))
                layoutParams = ViewGroup.MarginLayoutParams(dp(if (tv) 104 else 96), dp(if (tv) 142 else 136)).apply { marginStart = dp(5); marginEnd = dp(5) }
                applyTvFocusHalo(this, 20, 1.06f, 0f)
                setOnClickListener { showActorPage(obj) }
            }
            val avatarWrap = FrameLayout(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(alphaSurface()); setStroke(dp(1), alphaLine(125)) }
                clipToOutline = true
            }
            if (image.isNotBlank()) {
                val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; clipToOutline = true }
                loadImage(image, img)
                avatarWrap.addView(img, FrameLayout.LayoutParams(-1,-1))
            } else {
                avatarWrap.addView(ImageView(this).apply { setImageResource(R.drawable.ic_avatar_circle); setColorFilter(blue) }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
            }
            card.addView(avatarWrap, LinearLayout.LayoutParams(dp(if (tv) 60 else 56), dp(if (tv) 60 else 56)))
            card.addView(TextView(this).apply { text = name; setTextColor(white); textSize = 10.8f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; maxLines = 2; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(8), 0, 0) }, LinearLayout.LayoutParams(-1,-2))
            if (role.isNotBlank()) card.addView(TextView(this).apply { text = role; setTextColor(muted); textSize = 9.2f; gravity = Gravity.CENTER; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(4), 0, 0) }, LinearLayout.LayoutParams(-1,-2))
            row.addView(card)
        }
        host.addView(scroll, LinearLayout.LayoutParams(-1, dp(if (tv) 154 else 148)).apply {
            leftMargin = if (tv) dp(2) else 0
            rightMargin = if (tv) dp(2) else 0
            topMargin = if (tv) dp(2) else 0
            bottomMargin = dp(if (tv) 18 else 14)
        })
        wireTvSectionDown(header, row.getChildAtOrNull(0))
    }

    private fun infoGrid(item: JSONObject): View {
        val grid = GridLayout(this).apply {
            columnCount = 2
            background = bankGlassDrawable(18, 232, 68, true)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val country = detailListText(item, "country").ifBlank { detailListText(item, "countries") }
        val cells: List<Triple<Int, String, String>> = listOf(
            Triple(R.drawable.ic_imdb, "امتیاز", cleanRating(item.optString("rating"))),
            Triple(R.drawable.ic_info_globe, "کشور", country.ifBlank { "نامشخص" }),
            Triple(R.drawable.ic_info_calendar, "سال", item.optString("year")),
            Triple(R.drawable.ic_info_runtime, "زمان", item.optString("runtime")),
            Triple(R.drawable.ic_info_badge, "رده سنی", item.optString("age_rate").ifBlank { "+16" }),
            Triple(R.drawable.ic_info_archive, t("آرشیو", "Archive"), item.optInt("archive", selectedArchive).toString())
        )
        cells.forEach { cell: Triple<Int, String, String> ->
            grid.addView(infoCell(cell.first, cell.second, cell.third), ViewGroup.MarginLayoutParams(0, -2).apply {
                width = dp(160)
                marginStart = dp(4)
                marginEnd = dp(4)
                bottomMargin = dp(8)
            })
        }
        return grid
    }

        private fun downloadNotice(): TextView {
        return TextView(this).apply {
            text = ui("برای پخش روی دکمه سبز بزن. برای دانلود روی آیکن دانلود کنار هر نسخه بزن.")
            setTextColor(alphaPrimary())
            textSize = 12.1f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.0f)
            background = rounded(alphaSurface2(), dp(14), alphaLine(72))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
    }


    private fun downloadSeasonCard(item: JSONObject, allLinks: List<JSONObject>, season: Int, seasonLinks: List<JSONObject>): LinearLayout {
        val seasonTitle = if (season > 0) "${ui("فصل")} $season" else ui("قسمت‌ها")
        val sortedSeasonLinks = qualityOnlyLinks(sortedArchive1Links(seasonLinks))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface(), dp(20), alphaLine(78))
            elevation = dp(3).toFloat()
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val seasonContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(9), 0, 0)
        }

        val seasonArrow = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_down)
            setColorFilter(alphaPrimary())
            rotation = 0f
        }

        val header = LinearLayout(this).apply {
            id = View.generateViewId()
            tag = "bm_download_season_header"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (isLightTheme()) {
                GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.rgb(224, 235, 252), Color.rgb(248, 250, 253))
                ).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), Color.argb(145, Color.red(blue), Color.green(blue), Color.blue(blue)))
                }
            } else {
                GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(Color.argb(105, Color.red(blue), Color.green(blue), Color.blue(blue)), Color.argb(58, 30, 36, 58))
                ).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), Color.argb(70, 255, 255, 255))
                }
            }
            setPadding(dp(12), 0, dp(12), 0)
            applyTvFocusHalo(this, 18, 1.025f, 0f)
        }

        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_download)
            setColorFilter(alphaPrimary())
        }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(8) })

        header.addView(TextView(this).apply {
            text = seasonTitle
            setTextColor(alphaPrimary())
            textSize = 15.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(52), 1f))

        val epCount = sortedSeasonLinks.map { it.optInt("episode", 0) }.filter { it > 0 }.distinct().size
        header.addView(TextView(this).apply {
            text = if (epCount > 0) "$epCount ${ui("قسمت")}" else "${sortedSeasonLinks.size} ${ui("لینک‌ها")}"
            setTextColor(alphaSecondaryText())
            textSize = 11.2f
            gravity = Gravity.CENTER
            background = rounded(alphaSurface(), dp(12), alphaLine(62))
            setPadding(dp(9), dp(4), dp(9), dp(4))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })

        header.addView(seasonArrow, LinearLayout.LayoutParams(dp(30), dp(52)))

        val episodeHeaders = mutableListOf<View>()
        header.setOnClickListener {
            val open = seasonContent.visibility != View.VISIBLE
            animateExpandable(seasonContent, open)
            seasonArrow.animate().rotation(if (open) 180f else 0f).setDuration(190L).start()
            if (isTvLike()) {
                header.nextFocusDownId = if (open) episodeHeaders.firstOrNull()?.id ?: View.NO_ID else View.NO_ID
            }
            if (open && isTvLike()) {
                seasonContent.post { applyTvFocusToClickableTree(seasonContent) }
            }
        }

        box.addView(header, LinearLayout.LayoutParams(-1, dp(52)))
        val episodeGroups = sortedSeasonLinks.groupBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 0 } }
            .toSortedMap(compareBy<Int> { if (it == 0) 9999 else it })

        episodeGroups.forEach { (episode, epLinksRaw) ->
            val epLinks = qualityOnlyLinks(sortedArchive1Links(epLinksRaw)).sortedWith(
                compareBy<JSONObject> { qualitySortRank(it) }
                    .thenBy { it.optString("display_label").ifBlank { it.optString("quality") } }
            )

            val epBox = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = if (isLightTheme()) rounded(alphaSurface2(), dp(16), alphaLine(68))
                else rounded(Color.rgb(8, 15, 28), dp(16), Color.argb(58, 255, 255, 255))
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }

            val epContent = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
                setPadding(0, dp(7), 0, 0)
            }

            val epArrow = ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron_down)
                setColorFilter(alphaPrimary())
                rotation = 0f
            }

            val epHeader = LinearLayout(this).apply {
                id = View.generateViewId()
                tag = "bm_download_episode_header"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                background = if (isLightTheme()) rounded(alphaSurface(), dp(14), Color.argb(135, Color.red(blue), Color.green(blue), Color.blue(blue)))
                else rounded(Color.rgb(15, 25, 43), dp(14), Color.argb(70, Color.red(blue), Color.green(blue), Color.blue(blue)))
                setPadding(dp(10), 0, dp(10), 0)
                applyTvFocusHalo(this, 16, 1.025f, 0f)
            }

            epHeader.addView(TextView(this).apply {
                text = if (episode > 0) "${ui("قسمت")} $episode" else ui("لینک‌های فصل")
                setTextColor(alphaPrimary())
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }, LinearLayout.LayoutParams(0, dp(46), 1f))

            epHeader.addView(TextView(this).apply {
                text = "${epLinks.size} ${ui("کیفیت")}"
                setTextColor(alphaSecondaryText())
                textSize = 10.4f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                background = rounded(alphaSurface(), dp(10), Color.TRANSPARENT)
                setPadding(dp(8), dp(3), dp(8), dp(3))
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(7) })

            epHeader.addView(epArrow, LinearLayout.LayoutParams(dp(28), dp(46)))

            val episodeFocusRows = mutableListOf<Pair<View, View>>()
            epHeader.setOnClickListener {
                val open = epContent.visibility != View.VISIBLE
                animateExpandable(epContent, open)
                epArrow.animate().rotation(if (open) 180f else 0f).setDuration(190L).start()
                if (isTvLike()) {
                    epHeader.nextFocusDownId = if (open) episodeFocusRows.firstOrNull()?.first?.id ?: View.NO_ID else View.NO_ID
                }
                if (open && isTvLike()) {
                    epContent.post { applyTvFocusToClickableTree(epContent) }
                }
            }

            episodeHeaders += epHeader
            epBox.addView(epHeader, LinearLayout.LayoutParams(-1, dp(46)))

            // کیفیت و نوع نسخه (دوبله، هاردساب، سافت‌ساب و صوت) کنار هم نمایش داده می‌شوند.
            epLinks.forEach { link ->
                val idx = allLinks.indexOf(link).coerceAtLeast(0)
                val row = downloadQualityRow(item, allLinks, idx, link)
                epContent.addView(row, LinearLayout.LayoutParams(-1, dp(62)).apply {
                    bottomMargin = dp(7)
                })
                val play = row.findViewWithTag<View>("bm_download_play")
                val save = row.findViewWithTag<View>("bm_download_save")
                if (play != null && save != null) episodeFocusRows += play to save
            }

            if (isTvLike() && episodeFocusRows.isNotEmpty()) {
                // Closed episode rows stay closed until the user presses OK on the episode header.
                episodeFocusRows.forEachIndexed { index, pair ->
                    val previous = episodeFocusRows.getOrNull(index - 1)
                    val next = episodeFocusRows.getOrNull(index + 1)
                    pair.first.nextFocusUpId = previous?.first?.id ?: epHeader.id
                    pair.second.nextFocusUpId = previous?.second?.id ?: epHeader.id
                    next?.let {
                        pair.first.nextFocusDownId = it.first.id
                        pair.second.nextFocusDownId = it.second.id
                    }
                }
            }

            epBox.addView(epContent, LinearLayout.LayoutParams(-1, -2))
            seasonContent.addView(epBox, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }

        if (isTvLike() && episodeHeaders.isNotEmpty()) {
            // Closed seasons stay closed until the user presses OK on the season header.
            episodeHeaders.forEachIndexed { index, episodeHeader ->
                episodeHeader.nextFocusUpId = episodeHeaders.getOrNull(index - 1)?.id ?: header.id
                episodeHeaders.getOrNull(index + 1)?.let { episodeHeader.nextFocusDownId = it.id }
            }
        }

        box.addView(seasonContent, LinearLayout.LayoutParams(-1, -2))
        return box
    }

    private fun normalizedQualityKey(link: JSONObject): String {
        val raw = link.optString("quality").ifBlank { link.optString("display_label") }.lowercase(Locale.US)
        return when {
            raw.contains("2160") || raw.contains("4k") -> "2160p"
            raw.contains("1080") -> "1080p"
            raw.contains("720") -> "720p"
            raw.contains("480") -> "480p"
            raw.contains("360") -> "360p"
            raw.isNotBlank() -> raw.replace(Regex("[^a-z0-9]+"), "-").trim('-')
            else -> "auto"
        }
    }

    private fun preferredQualityVariantScore(link: JSONObject): Int {
        val raw = listOf(
            link.optString("type"),
            link.optString("type_fa"),
            link.optString("label"),
            link.optString("display_label"),
            link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)
        var score = 0
        if (raw.contains(".mkv")) score += 90
        if (raw.contains("multi") || raw.contains("dual") || raw.contains("چندصدا") || raw.contains("دو زبانه") || raw.contains("softsub") || raw.contains("internal")) score += 120
        when (linkKindKey(link)) {
            "dub" -> score += 45
            "sub" -> score += 35
            "hard" -> score += 20
            "audio" -> score += 10
        }
        if (link.optString("size").isNotBlank()) score += 2
        return score
    }

    private fun qualityOnlyLinks(links: List<JSONObject>): List<JSONObject> {
        val selected = linkedMapOf<String, JSONObject>()
        links.forEach { link ->
            val key = listOf(
                link.optInt("season", 0),
                link.optInt("episode", 0),
                linkKindKey(link),
                normalizedQualityKey(link)
            ).joinToString("|")
            val current = selected[key]
            if (current == null || preferredQualityVariantScore(link) > preferredQualityVariantScore(current)) {
                selected[key] = link
            }
        }
        return selected.values.sortedWith(
            compareBy<JSONObject> { it.optInt("season", 0).let { s -> if (s > 0) s else 999 } }
                .thenBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 999 } }
                .thenBy { qualitySortRank(it) }
        )
    }

    private fun linkKindOrder(kind: String): Int {
        return when (kind) {
            "dub" -> 0
            "hard" -> 1
            "sub" -> 2
            "audio" -> 3
            else -> 4
        }
    }

    private fun qualitySortRank(link: JSONObject): Int {
        val q = link.optString("quality").ifBlank { link.optString("display_label") }.lowercase(Locale.US)
        return when {
            q.contains("2160") || q.contains("4k") -> 0
            q.contains("1080") -> 1
            q.contains("720") -> 2
            q.contains("480") -> 3
            q.contains("360") -> 4
            else -> 8
        }
    }

    private fun archive1LinkSortWeight(link: JSONObject): Int {
        val season = link.optInt("season", 0).let { if (it > 0) it else 999 }
        val episode = link.optInt("episode", 0).let { if (it > 0) it else 999 }
        val kind = linkKindKey(link)
        val group = when (kind) {
            "dub" -> 0
            "hard" -> 1
            "sub" -> 2
            "audio" -> 3
            else -> 4
        }
        val q = link.optString("quality").ifBlank { link.optString("display_label") }.lowercase(Locale.US)
        val qRank = when {
            q.contains("2160") || q.contains("4k") -> 0
            q.contains("1080") -> 1
            q.contains("720") -> 2
            q.contains("480") -> 3
            q.contains("360") -> 4
            else -> 8
        }
        return season * 1000000 + episode * 10000 + group * 100 + qRank
    }

    private fun sortedArchive1Links(links: List<JSONObject>): List<JSONObject> {
        return links.sortedWith(compareBy<JSONObject> { archive1LinkSortWeight(it) }
            .thenBy { it.optString("display_label").ifBlank { it.optString("quality") } })
    }

    private fun groupedDownloadBlocks(item: JSONObject, links: List<JSONObject>): List<View> {
        val all = qualityOnlyLinks(sortedArchive1Links(links))
        if (isSeriesLinks(all)) {
            val bySeason = all.groupBy { it.optInt("season", 0).let { s -> if (s > 0) s else 0 } }
                .toSortedMap(compareBy<Int> { if (it == 0) 9999 else it })
            return bySeason.map { (season, arr) ->
                // Reuse the movie download card system for series seasons too.
                val title = if (season > 0) "${ui("فصل")} $season" else ui("قسمت‌ها")
                downloadGroupCard(item, all, title, arr, false)
            }
        }
        return if (all.isEmpty()) emptyList() else listOf(
            downloadGroupCard(item, all, ui("کیفیت‌های پخش"), all, false)
        )
    }

    private fun groupedDownloadBlocks(item: JSONObject, links: List<JSONObject>, render: (String, List<JSONObject>) -> View): List<View> {
        val sorted = sortedArchive1Links(links)
        val groups = linkedMapOf<String, MutableList<JSONObject>>()
        for (l in sorted) {
            val title = when (linkKindKey(l)) {
                "dub" -> ui("دوبله فارسی")
                "hard" -> ui("هاردساب")
                "sub" -> ui("زیرنویس")
                "audio" -> ui("صوت دوبله")
                else -> ui("سایر لینک‌ها")
            }
            groups.getOrPut(title) { mutableListOf() }.add(l)
        }
        val out = mutableListOf<View>()
        groups.forEach { (title, arr) ->
            if (arr.isNotEmpty()) out.add(render(title, arr))
        }
        return out
    }

    private fun linkKindKey(link: JSONObject): String {
        val raw = listOf(
            link.optString("type"),
            link.optString("type_fa"),
            link.optString("label"),
            link.optString("display_label"),
            link.optString("quality"),
            link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)

        return when {
            raw.contains("hard") || raw.contains("هارد") -> "hard"
            raw.contains("softsub") || raw.contains("soft sub") || raw.contains("سافت") -> "sub"
            raw.contains("audio") || raw.contains("voice") || raw.contains("صوت") -> "audio"
            raw.contains("dub") || raw.contains("دوبله") -> "dub"
            raw.contains("sub") || raw.contains("subtitle") || raw.contains("زیرنویس") -> "sub"
            else -> "other"
        }
    }

    private fun linkKindLabel(link: JSONObject): String {
        val raw = listOf(
            link.optString("type"), link.optString("type_fa"), link.optString("label"),
            link.optString("display_label"), link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)
        return when {
            raw.contains("softsub") || raw.contains("soft sub") || raw.contains("سافت") -> ui("سافت‌ساب فارسی")
            raw.contains("hard") || raw.contains("هارد") -> ui("هاردساب فارسی")
            raw.contains("multi") || raw.contains("dual") || raw.contains("چندصدا") || raw.contains("دو زبانه") -> ui("چندصدا")
            raw.contains("audio") || raw.contains("voice") || raw.contains("صوت") -> ui("صوت دوبله")
            raw.contains("dub") || raw.contains("دوبله") -> ui("دوبله فارسی")
            raw.contains("sub") || raw.contains("subtitle") || raw.contains("زیرنویس") -> ui("زیرنویس فارسی")
            else -> link.optString("type_fa").ifBlank { ui("نسخه اصلی") }
        }
    }

    private fun linkKindColor(link: JSONObject): Int = when (linkKindKey(link)) {
        "dub" -> Color.rgb(36, 150, 95)
        "hard" -> Color.rgb(228, 142, 35)
        "sub" -> Color.rgb(56, 118, 220)
        "audio" -> Color.rgb(151, 82, 220)
        else -> Color.rgb(90, 98, 112)
    }

    private fun renderEpisodeBlocks(page: LinearLayout, item: JSONObject) {
        val links = playableLinks(item)
        if (links.isEmpty()) return
        val series = itemContentType(item) == "series" || isSeriesLinks(links)
        val section: View? = if (series) {
            sectionHeader("فصل‌ها و قسمت‌ها / دانلود", { }, showMore = false).also { page.addView(it) }
        } else null
        page.addView(downloadNotice())
        if (series) {
            page.addView(seriesBulkCopyButton(item, links), LinearLayout.LayoutParams(-1, dp(52)).apply {
                topMargin = dp(10)
                bottomMargin = dp(12)
            })
        }
        val blocks = groupedDownloadBlocks(item, links)
        blocks.forEach { block ->
            page.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        if (isTvLike()) {
            page.post {
                applyTvFocusToClickableTree(page)
                val more = section?.findViewWithTag<View>("bm_section_more")
                val headers = blocks.mapNotNull { block ->
                    block.findViewWithTag<View>("bm_download_season_header")
                        ?: block.findViewWithTag<View>("bm_download_group_header")
                }
                if (more != null && headers.isNotEmpty()) {
                    if (more.id == View.NO_ID) more.id = View.generateViewId()
                    headers.forEach { if (it.id == View.NO_ID) it.id = View.generateViewId() }
                    more.nextFocusDownId = headers.first().id
                    headers.first().nextFocusUpId = more.id
                    more.setOnKeyListener { _, keyCode, event ->
                        if (event.action == android.view.KeyEvent.ACTION_DOWN && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN) {
                            headers.first().requestFocus()
                            true
                        } else false
                    }
                    headers.forEachIndexed { index, header ->
                        headers.getOrNull(index - 1)?.let { previous ->
                            if (header.nextFocusUpId == View.NO_ID) header.nextFocusUpId = previous.id
                        }
                        headers.getOrNull(index + 1)?.let { next ->
                            if (header.nextFocusDownId == View.NO_ID) header.nextFocusDownId = next.id
                        }
                    }
                }
            }
        }
    }

    private fun downloadGroupCard(item: JSONObject, allLinks: List<JSONObject>, title: String, links: List<JSONObject>, openDefault: Boolean): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(alphaSurface(), dp(18), alphaLine(75))
            elevation = dp(3).toFloat()
        }
        val header = LinearLayout(this).apply {
            id = View.generateViewId()
            tag = "bm_download_group_header"
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(alphaSurface2(), dp(18), alphaLine(65))
            setPadding(dp(12), 0, dp(12), 0)
        }
        val arrow = ImageView(this).apply {
            setImageResource(if (openDefault) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down)
            setColorFilter(alphaPrimary())
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_download)
            setColorFilter(alphaPrimary())
        }, LinearLayout.LayoutParams(dp(21), dp(21)).apply { marginStart = dp(8) })
        header.addView(TextView(this).apply {
            text = title
            setTextColor(alphaPrimary())
            textSize = 14.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, dp(54), 1f))
        header.addView(TextView(this).apply {
            text = "${links.size}"
            setTextColor(alphaSecondaryText())
            textSize = 11f
            gravity = Gravity.CENTER
            background = rounded(alphaSurface(), dp(11), Color.TRANSPARENT)
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(8) })
        header.addView(arrow, LinearLayout.LayoutParams(dp(30), dp(54)))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (openDefault) View.VISIBLE else View.GONE
            setPadding(dp(8), dp(10), dp(8), dp(8))
        }

        val focusRows = mutableListOf<Pair<View, View>>()
        links.sortedWith(
            compareByDescending<JSONObject> { qualityScore(it.optString("quality")) }
                .thenBy { it.optString("display_label") }
        ).forEach { link ->
            val idx = allLinks.indexOf(link).coerceAtLeast(0)
            val row = downloadQualityRow(item, allLinks, idx, link)
            content.addView(row, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(7) })
            val play = row.findViewWithTag<View>("bm_download_play")
            val save = row.findViewWithTag<View>("bm_download_save")
            if (play != null && save != null) focusRows += play to save
        }

        if (isTvLike() && focusRows.isNotEmpty()) {
            // Quality links stay collapsed until the user presses OK on the header.
            focusRows.forEachIndexed { index, pair ->
                val previous = focusRows.getOrNull(index - 1)
                val next = focusRows.getOrNull(index + 1)
                pair.first.nextFocusUpId = previous?.first?.id ?: header.id
                pair.second.nextFocusUpId = previous?.second?.id ?: header.id
                next?.let {
                    pair.first.nextFocusDownId = it.first.id
                    pair.second.nextFocusDownId = it.second.id
                }
            }
        }

        applyTvFocusHalo(header, 18, 1.025f, header.elevation)
        header.setOnClickListener {
            val open = content.visibility != View.VISIBLE
            animateExpandable(content, open)
            arrow.setImageResource(if (open) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down)
            if (isTvLike()) {
                header.nextFocusDownId = if (open) focusRows.firstOrNull()?.first?.id ?: View.NO_ID else View.NO_ID
            }
            if (open && isTvLike()) {
                content.post { applyTvFocusToClickableTree(content) }
            }
        }
        box.addView(header)
        box.addView(content)
        return box
    }


    private fun normalizeWatchPartyCode(raw: String): String {
        val value = raw.trim()
        if (value.matches(Regex("[A-Za-z0-9_-]{24,96}"))) return value
        val fromQuery = runCatching { Uri.parse(value).getQueryParameter("room").orEmpty() }.getOrDefault("")
        if (fromQuery.matches(Regex("[A-Za-z0-9_-]{24,96}"))) return fromQuery
        return Regex("(?:room=)?([A-Za-z0-9_-]{24,96})").find(value)?.groupValues?.getOrNull(1).orEmpty()
    }

    private fun showWatchPartyJoinDialog() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = bankGlassDrawable(26, 246, 82, true)
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_watch_party); setColorFilter(Color.rgb(170, 132, 255))
        }, LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginStart = dp(10) })
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT
            addView(TextView(this@MainActivity).apply {
                text = t("ورود به Watch Party", "Join Watch Party"); setTextColor(Color.WHITE); textSize = 19f
                typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.RIGHT
            })
            addView(TextView(this@MainActivity).apply {
                text = t("کد اتاق یا لینک دعوت سایت را وارد کن.", "Enter the room code or website invite link.")
                setTextColor(muted); textSize = 11f; gravity = Gravity.RIGHT
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(head)

        val input = EditText(this).apply {
            hint = t("کد یا لینک دعوت", "Room code or invite link")
            setHintTextColor(Color.rgb(125, 129, 140)); setTextColor(Color.WHITE); textSize = 12.5f
            setSingleLine(true); gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            background = bankGlassDrawable(18, 220, 58, false); setPadding(dp(13), 0, dp(13), 0)
        }
        shell.addView(input, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(14) })

        val join = TextView(this).apply {
            text = t("ورود به اتاق", "Join room"); setTextColor(Color.WHITE); textSize = 14f
            typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(111,47,210), Color.rgb(75,87,235), Color.rgb(42,124,247))).apply {
                cornerRadius = dp(18).toFloat(); setStroke(dp(1), Color.argb(150,210,195,255))
            }
            isFocusable = true; isClickable = true; applyTvFocusHalo(this, 18, 1.05f, dp(3).toFloat())
            setOnClickListener {
                val code = normalizeWatchPartyCode(input.text?.toString().orEmpty())
                if (code.isBlank()) { BmNotice.show(this@MainActivity, t("کد اتاق معتبر نیست", "Invalid room code"), BmNotice.Kind.WARNING); return@setOnClickListener }
                dialog.dismiss(); joinWatchPartyRoom(code)
            }
        }
        shell.addView(join, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(12) })
        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if (isTvLike()) dp(560) else (resources.displayMetrics.widthPixels * 0.90f).toInt(), -2)
        input.requestFocus()
    }

    private fun joinWatchPartyRoom(roomCode: String) {
        BmNotice.show(this, t("در حال ورود به اتاق...", "Joining room..."), BmNotice.Kind.INFO)
        AccountApi.watchPartyJoin(this, roomCode) { joined ->
            if (!joined.success) {
                BmNotice.show(this, joined.message.ifBlank { t("ورود به اتاق انجام نشد", "Could not join room") }, BmNotice.Kind.ERROR)
                return@watchPartyJoin
            }
            AccountApi.watchPartyPoll(this, roomCode, 0L, 0L, 0L) { polled ->
                if (!polled.success || polled.json == null) {
                    BmNotice.show(this, polled.message.ifBlank { t("اطلاعات اتاق دریافت نشد", "Could not load room") }, BmNotice.Kind.ERROR)
                    return@watchPartyPoll
                }
                val room = polled.json.optJSONObject("room") ?: JSONObject()
                val source = room.optString("shared_source_url").trim()
                if (source.isBlank()) {
                    BmNotice.show(this, t("منبع پخش اتاق هنوز آماده نیست", "Room source is not ready"), BmNotice.Kind.WARNING)
                    return@watchPartyPoll
                }
                val title = room.optString("content_title").ifBlank { t("Watch Party بانک مووی", "Bankmovie Watch Party") }
                val role = polled.json.optString("member_role", "guest")
                val invite = room.optString("invite_url").ifBlank { "" }
                val intent = Intent(this, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_VIDEO_URL, source)
                    putExtra(PlayerActivity.EXTRA_TITLE, title)
                    putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, "watch_party_${roomCode}")
                    putExtra(PlayerActivity.EXTRA_WATCH_PARTY_ROOM_CODE, roomCode)
                    putExtra(PlayerActivity.EXTRA_WATCH_PARTY_ROLE, role)
                    putExtra(PlayerActivity.EXTRA_WATCH_PARTY_INVITE_URL, invite)
                }
                startActivity(intent)
            }
        }
    }

    // PASS 4 — Native Watch Party entry point. The button deliberately lives next
    // to each playable quality, exactly like the website, because a room must share
    // the exact source/quality the host chose.
    private fun watchPartyQualityButton(item: JSONObject, link: JSONObject): View {
        val playable = isVideo(link.optString("url")) && !isAudioOnly(link)
        return FrameLayout(this).apply {
            contentDescription = t("Watch Party VIP", "VIP Watch Party")
            isEnabled = playable
            alpha = if (playable) 1f else 0.42f
            background = if (playable) {
                bankTintGlassDrawable(Color.rgb(111,72,238), 999, 236, 0.34f)
            } else {
                bankGlassDrawable(999, 190, 52, false)
            }
            elevation = if (playable) dp(4).toFloat() else 0f
            isClickable = playable
            isFocusable = playable
            applyMobileTouchHalo(this,999)
            applyTvFocusHalo(this,999,1.07f,elevation)

            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_watch_party)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(21),dp(21),Gravity.CENTER).apply {
                topMargin = -dp(4)
            })

            addView(TextView(this@MainActivity).apply {
                text = "VIP"
                setTextColor(Color.rgb(70,43,6))
                textSize = 6.6f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(255,232,126),Color.rgb(255,177,31))).apply {
                    cornerRadius = dp(999).toFloat()
                    setStroke(dp(1), Color.argb(150,255,246,199))
                }
                setPadding(dp(4),0,dp(4),0)
            }, FrameLayout.LayoutParams(-2,dp(13),Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(3)
            })

            if (playable) setOnClickListener { showWatchPartyGateOrCreate(item,link) }
        }
    }

    private fun showWatchPartyGateOrCreate(item: JSONObject, link: JSONObject) {
        if (link.optString("url").isBlank()) return
        BmNotice.show(this, t("در حال بررسی Watch Party...", "Checking Watch Party..."), BmNotice.Kind.INFO)
        AccountApi.watchPartyStatus(this) { result ->
            if (!result.success || result.json == null) {
                BmNotice.show(this, result.message.ifBlank { t("Watch Party در دسترس نیست", "Watch Party is unavailable") }, BmNotice.Kind.ERROR)
                return@watchPartyStatus
            }
            val json = result.json
            val loggedIn = json.optBoolean("is_logged_in", AccountSession.isLoggedIn(this))
            val vip = json.optBoolean("is_vip", false)
            if (!loggedIn || !vip) {
                showWatchPartyVipGate(json.optJSONObject("vip") ?: JSONObject(), loggedIn)
            } else {
                createWatchPartyForLink(item, link)
            }
        }
    }

    private fun showWatchPartyVipGate(vip: JSONObject, loggedIn: Boolean) {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(18))
            background = bankGlassDrawable(28, 246, 84, true)
        }

        val closeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        closeRow.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_vip_crown)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(15), dp(15), dp(15), dp(15))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(255, 225, 105), Color.rgb(255, 166, 18))).apply {
                cornerRadius = dp(20).toFloat(); setStroke(dp(1), Color.rgb(255, 240, 185))
            }
        }, LinearLayout.LayoutParams(dp(68), dp(68)).apply { marginStart = dp(16) })
        closeRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@MainActivity).apply {
                text = t("تماشای دونفره ویژه اعضای VIP", "Watch Party for VIP members")
                setTextColor(Color.WHITE); textSize = 19f; typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.RIGHT
            })
            addView(TextView(this@MainActivity).apply {
                text = t("پارتنر یا دوستت را رایگان دعوت کن؛ فیلم، چت و استیکر داخل یک اتاق کاملاً هماهنگ.", "Invite a friend free; synchronized playback, chat and stickers in one room.")
                setTextColor(muted); textSize = 11.8f; gravity = Gravity.RIGHT; setLineSpacing(dp(3).toFloat(), 1.05f)
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(closeRow)

        val hint = TextView(this).apply {
            text = if (!loggedIn) t("اول وارد حساب شوید یا رایگان ثبت‌نام کنید؛ سپس یک پلن VIP فعال کنید.", "Sign in or register first, then activate a VIP plan.") else t("حساب شما VIP فعال ندارد. یکی از پلن‌های سایت را انتخاب کنید.", "Your account has no active VIP plan. Choose a site plan.")
            setTextColor(Color.rgb(195, 199, 211)); textSize = 11.6f; gravity = Gravity.RIGHT
            background = bankGlassDrawable(18, 212, 52, false); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        shell.addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) })

        val scroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false; layoutDirection = View.LAYOUT_DIRECTION_RTL; clipToPadding = false
        }
        val plansRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(dp(2), dp(14), dp(2), dp(10))
        }
        val plans = vip.optJSONArray("plans") ?: JSONArray()
        for (i in 0 until plans.length()) {
            val plan = plans.optJSONObject(i) ?: continue
            val featured = plan.optBoolean("featured", false)
            plansRow.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(12), dp(12), dp(12))
                background = if (featured) bankTintGlassDrawable(Color.rgb(139, 92, 246), 20, 232, 0.22f) else bankGlassDrawable(20, 226, 60, true)
                addView(TextView(this@MainActivity).apply {
                    text = plan.optString("name"); setTextColor(Color.WHITE); textSize = 15f; typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.RIGHT
                })
                addView(TextView(this@MainActivity).apply {
                    text = plan.optString("latin"); setTextColor(if (featured) Color.rgb(196, 171, 255) else muted); textSize = 9.3f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
                addView(TextView(this@MainActivity).apply {
                    text = "${plan.optString("price")} هزار تومان"; setTextColor(Color.WHITE); textSize = 19f; typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
                addView(TextView(this@MainActivity).apply {
                    text = plan.optString("period"); setTextColor(muted); textSize = 10f; gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
                plan.optString("saving").takeIf { it.isNotBlank() }?.let { saving ->
                    addView(TextView(this@MainActivity).apply { text=saving; setTextColor(Color.rgb(109, 220, 255)); textSize=9.6f; gravity=Gravity.RIGHT }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(4) })
                }
                addView(TextView(this@MainActivity).apply {
                    text = t("خرید و پیام در تلگرام", "Buy via Telegram")
                    setTextColor(Color.WHITE); textSize = 11.2f; typeface = BankmovieFonts.bold(this@MainActivity); gravity = Gravity.CENTER
                    background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(45, 128, 255), Color.rgb(141, 78, 238))).apply { cornerRadius = dp(14).toFloat() }
                    setOnClickListener { openVipPlanTelegram(vip, plan) }
                }, LinearLayout.LayoutParams(-1, dp(39)).apply { topMargin = dp(11) })
            }, LinearLayout.LayoutParams(if(isTvLike())dp(240) else (resources.displayMetrics.widthPixels-dp(76)).coerceAtLeast(dp(260)), -2).apply { marginStart = dp(6); marginEnd = dp(6) })
        }
        scroll.addView(plansRow)
        shell.addView(scroll, LinearLayout.LayoutParams(-1, -2))

        if (!loggedIn) {
            shell.addView(TextView(this).apply {
                text = t("ورود به حساب / ثبت‌نام رایگان", "Sign in / Register")
                setTextColor(Color.WHITE); textSize=13.5f; typeface=BankmovieFonts.bold(this@MainActivity); gravity=Gravity.CENTER
                background=bankPrimaryGlassDrawable(18); isClickable=true; isFocusable=true; applyMobileTouchHalo(this,18); applyTvFocusHalo(this,18,1.035f,0f)
                setOnClickListener { dialog.dismiss(); startActivity(Intent(this@MainActivity, AuthActivity::class.java)) }
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin=dp(7) })
        }
        shell.addView(TextView(this).apply {
            text = "×"; setTextColor(Color.WHITE); textSize=22f; gravity=Gravity.CENTER; background=bankGlassDrawable(16,210,55,false)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin=dp(8) })

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        styleShownDialog(dialog, shell, maxWidthDp = 760)
    }

    private fun openVipPlanTelegram(vip: JSONObject, plan: JSONObject) {
        val username = vip.optString("telegram_username").ifBlank { "bankmovie_supp" }.removePrefix("@")
        var message = vip.optString("purchase_message_template").ifBlank { "سلام، برای خرید اشتراک {plan} بانک‌مووی به مبلغ {price} هزار تومان پیام می‌دهم." }
        message = message.replace("{plan}", plan.optString("name")).replace("{price}", plan.optString("price"))
        val clip = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
        clip.setPrimaryClip(android.content.ClipData.newPlainText("BankMovie VIP", message))
        val url = "https://t.me/$username?text=${URLEncoder.encode(message, "UTF-8")}".replace("+", "%20")
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
        catch (_: Throwable) { Toast.makeText(this, t("متن سفارش کپی شد", "Order text copied"), Toast.LENGTH_LONG).show() }
    }

    private fun createWatchPartyForLink(item: JSONObject, link: JSONObject) {
        BmNotice.show(this, t("در حال ساخت سینمای خصوصی...", "Creating private cinema..."), BmNotice.Kind.INFO)
        AccountApi.watchPartyCreate(this, item, link) { result ->
            if (!result.success) {
                if (result.json?.optString("error") == "vip_required" || result.statusCode == 403) {
                    showWatchPartyVipGate(result.json?.optJSONObject("vip") ?: JSONObject(), AccountSession.isLoggedIn(this))
                } else {
                    BmNotice.show(this, result.message.ifBlank { t("ساخت اتاق انجام نشد", "Could not create room") }, BmNotice.Kind.ERROR)
                }
                return@watchPartyCreate
            }
            val room = result.json?.optJSONObject("room")
            if (room == null || room.optString("invite_code").isBlank()) {
                BmNotice.show(this, t("پاسخ اتاق کامل نیست", "Room response is incomplete"), BmNotice.Kind.ERROR); return@watchPartyCreate
            }
            launchWatchPartyRoom(item, link, room)
        }
    }

    private fun launchWatchPartyRoom(item: JSONObject, link: JSONObject, room: JSONObject) {
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "BankMovie Watch Party" }
        val payload = minimalPlayerPayload(JSONObject(link.toString()).apply { put("progress_key", playbackProgressKey(item, link)) }, title)
        val payloadPath = cachePlayerPayload(payload)
        val fallbackPayload = payload.toString()
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, link.optString("url"))
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, fallbackPayload)
            if (payloadPath.isNotBlank()) putExtra(PlayerActivity.EXTRA_PLAYLIST_FILE, payloadPath)
            putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, playbackProgressKey(item, link))
            putExtra(PlayerActivity.EXTRA_RESUME_POSITION, 0L)
            putExtra(PlayerActivity.EXTRA_WATCH_PARTY_ROOM_CODE, room.optString("invite_code"))
            putExtra(PlayerActivity.EXTRA_WATCH_PARTY_ROLE, "host")
            putExtra(PlayerActivity.EXTRA_WATCH_PARTY_INVITE_URL, room.optString("invite_url"))
        }
        startActivity(intent)
    }

    private fun downloadQualityRow(item: JSONObject, allLinks: List<JSONObject>, index: Int, link: JSONObject): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(alphaSurface2(), dp(16), alphaLine(65))
            setPadding(dp(7), dp(6), dp(7), dp(6))

            val canPlay = isVideo(link.optString("url")) || isAudioOnly(link)
            val playButton = FrameLayout(this@MainActivity).apply {
                id = View.generateViewId()
                tag = "bm_download_play"
                background = if (canPlay) {
                    GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(12, 164, 104), Color.rgb(30, 202, 132))).apply {
                        cornerRadius = dp(999).toFloat()
                        setStroke(dp(1), Color.argb(165, 118, 255, 194))
                    }
                } else {
                    rounded(Color.argb(125, 38, 38, 42), dp(999), Color.argb(90, 255, 255, 255))
                }
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(if (canPlay) R.drawable.ic_play_fill else R.drawable.ic_download)
                    setColorFilter(Color.WHITE)
                }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER))
                applyTvFocusHalo(this, 14, 1.075f, 0f)
                setOnClickListener {
                    if (canPlay) {
                        if (item.length() > 0) recordContinue(item, link)
                        openPlayer(item, allLinks, index)
                    } else {
                        showDownloadChoiceModal(item, link)
                    }
                }
            }
            addView(playButton, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })

            val info = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(8), 0, dp(8), 0)
            }
            val titleRow = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            titleRow.addView(TextView(this@MainActivity).apply {
                text = link.optString("quality").ifBlank {
                    link.optString("display_label").ifBlank { ui("نامشخص") }
                }
                setTextColor(alphaPrimary())
                textSize = 13.2f
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-2, -2))
            titleRow.addView(TextView(this@MainActivity).apply {
                text = linkKindLabel(link)
                setTextColor(Color.WHITE)
                textSize = 9.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                maxLines = 1
                background = rounded(linkKindColor(link), dp(9), Color.argb(70, 255, 255, 255))
                setPadding(dp(7), dp(2), dp(7), dp(2))
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(7) })
            info.addView(titleRow)
            info.addView(TextView(this@MainActivity).apply {
                text = listOf(
                    if (link.optInt("season", 0) > 0) "${ui("فصل")} ${link.optInt("season", 0)}" else "",
                    if (link.optInt("episode", 0) > 0) "${ui("قسمت")} ${link.optInt("episode", 0)}" else "",
                    link.optString("size"),
                    link.optString("label").takeIf {
                        it.isNotBlank() && !it.contains(linkKindLabel(link), true)
                    } ?: ""
                ).filter { it.isNotBlank() }.distinct().joinToString(" • ")
                setTextColor(alphaSecondaryText())
                textSize = 10.5f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
            })
            addView(info, LinearLayout.LayoutParams(0, -1, 1f).apply { marginStart = dp(7) })

            val partyButton = watchPartyQualityButton(item, link).apply { id = View.generateViewId(); tag = "bm_watch_party" }
            addView(partyButton, LinearLayout.LayoutParams(dp(42), dp(42)).apply {
                marginStart = dp(10)
                marginEnd = dp(5)
            })

            val downloadButton = FrameLayout(this@MainActivity).apply {
                id = View.generateViewId()
                tag = "bm_download_save"
                background = bankGlassDrawable(999, 218, 92, true)
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(Color.WHITE)
                }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
                applyTvFocusHalo(this, 14, 1.075f, 0f)
                setOnClickListener { showDownloadChoiceModal(item, link) }
            }
            addView(downloadButton, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(5) })

            if (isTvLike()) {
                playButton.nextFocusLeftId = partyButton.id
                partyButton.nextFocusRightId = playButton.id
                partyButton.nextFocusLeftId = downloadButton.id
                downloadButton.nextFocusRightId = partyButton.id
            }
        }
    }

    private fun movieVersionPanel(item: JSONObject, links: List<JSONObject>): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(7, 13, 25), dp(24), Color.argb(135, 65, 105, 170))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }
        box.addView(TextView(this).apply {
            text = "انتخاب نسخه پخش"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 0, 0, dp(10))
        })
        links.forEachIndexed { idx, link ->
            box.addView(movieVersionCard(item, links, idx, link), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
        return box
    }

    private fun movieVersionCard(item: JSONObject, links: List<JSONObject>, idx: Int, link: JSONObject): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(10, 19, 35), dp(20), Color.argb(115, 58, 96, 155))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        top.addView(TextView(this).apply {
            text = link.optString("display_label").ifBlank { linkLabel(link) }
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(premiumQualityChip(link, true) { openPlayer(item, links, idx) }, LinearLayout.LayoutParams(-2, dp(34)))
        card.addView(top)
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(10), 0, 0)
        }
        buttons.addView(premiumMiniButton("▶ پخش") { openPlayer(item, links, idx) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        buttons.addView(premiumMiniButton("⇩ دانلود") { showDownloadForLinks(item, listOf(link)) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        card.addView(buttons)
        return card
    }

    private fun seasonPremiumCard(item: JSONObject, allLinks: List<JSONObject>, seasonNumber: Int, seasonLinks: List<JSONObject>, initiallyOpen: Boolean): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(7, 13, 25), dp(24), Color.argb(145, 65, 105, 170))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) }
        }

        val episodes = seasonLinks.groupBy { it.optInt("episode", 0) }.toSortedMap()
        val header = LinearLayout(this).apply {
            id = View.generateViewId()
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bankGlassDrawable(20, 240, 74, true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val arrow = ImageView(this).apply {
            setImageResource(R.drawable.ic_chevron_down)
            setColorFilter(blue2)
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titleBox.addView(TextView(this).apply {
            text = if (seasonNumber > 0) "فصل ${seasonNumber}" else "قسمت‌ها"
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
        })
        titleBox.addView(TextView(this).apply {
            text = "${episodes.size} قسمت • ${seasonLinks.size} نسخه قابل پخش"
            setTextColor(muted)
            textSize = 11.5f
            setPadding(0, dp(3), 0, 0)
        })
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(arrow, LinearLayout.LayoutParams(dp(38), dp(38)))

        val episodeContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(12), 0, 0)
        }
        episodes.forEach { ep ->
            episodeContainer.addView(episodePremiumCard(item, allLinks, ep.key, ep.value), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        applyTvFocusHalo(header, 18, 1.025f, header.elevation)
        header.setOnClickListener {
            val open = episodeContainer.visibility != View.VISIBLE
            animateExpandable(episodeContainer, open)
            arrow.setImageResource(if (open) R.drawable.ic_chevron_up else R.drawable.ic_chevron_down)
        }

        outer.addView(header)
        outer.addView(episodeContainer)
        return outer
    }

    private fun episodePremiumCard(item: JSONObject, allLinks: List<JSONObject>, episodeNumber: Int, epLinks: List<JSONObject>): View {
        val best = bestEpisodeLink(epLinks)
        val bestIndex = allLinks.indexOf(best).coerceAtLeast(0)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bankGlassDrawable(22, 236, 68, true)
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        info.addView(TextView(this).apply {
            text = if (episodeNumber > 0) "قسمت ${episodeNumber}" else "لینک‌ها"
            setTextColor(white)
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
        })
        info.addView(TextView(this).apply {
            text = episodeSubtitle(best, epLinks)
            setTextColor(muted)
            textSize = 11.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(4), 0, 0)
        })
        top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(TextView(this).apply {
            text = runtimeText(best)
            setTextColor(blue2)
            textSize = 11f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(80, 0, 108, 255), dp(13), Color.argb(95, 70, 120, 200))
            setPadding(dp(9), dp(5), dp(9), dp(5))
        })
        card.addView(top)

        val chipScroll = HorizontalBankmovieSmoothScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val chips = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(10), 0, dp(8))
        }
        epLinks.sortedByDescending { qualityScore(it.optString("quality")) }.forEach { link ->
            val idx = allLinks.indexOf(link)
            chips.addView(premiumQualityChip(link, idx == bestIndex) { openPlayer(item, allLinks, idx) }, LinearLayout.LayoutParams(-2, dp(34)).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
            })
        }
        chipScroll.addView(chips)
        card.addView(chipScroll, LinearLayout.LayoutParams(-1, -2))

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(premiumMiniButton("▶ پخش") { openPlayer(item, allLinks, bestIndex) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        actions.addView(premiumMiniButton("⇩ دانلود") { showDownloadForLinks(item, epLinks) }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        card.addView(actions)
        return card
    }

    private fun bestEpisodeLink(epLinks: List<JSONObject>): JSONObject {
        return epLinks.sortedWith(
            compareByDescending<JSONObject> { qualityScore(it.optString("quality")) }
                .thenBy { if (it.optString("type") == "dub") 0 else 1 }
        ).firstOrNull() ?: JSONObject()
    }

    private fun episodeSubtitle(first: JSONObject, epLinks: List<JSONObject>): String {
        val name = first.optString("episode_name").ifBlank { first.optString("name") }
        val versions = epLinks.map { linkTypeFa(it) }.distinct().joinToString(" / ")
        val quality = epLinks.map { it.optString("quality") }.filter { it.isNotBlank() }.distinct().joinToString("، ")
        return listOf(name, versions, quality).filter { it.isNotBlank() }.joinToString(" • ").ifBlank { "نسخه‌های قابل پخش" }
    }

    private fun runtimeText(link: JSONObject): String {
        return link.optString("runtime").ifBlank { link.optString("duration").ifBlank { "--" } }
    }


    private fun isAudioOnly(link: JSONObject): Boolean {
        val raw = listOf(
            link.optString("type"),
            link.optString("type_fa"),
            link.optString("label"),
            link.optString("display_label"),
            link.optString("title"),
            link.optString("url")
        ).joinToString(" ").lowercase(Locale.US)

        return raw.contains("audio") ||
                raw.contains("voice") ||
                raw.contains("dubbed_audio") ||
                raw.contains("sound") ||
                raw.contains("صوت") ||
                raw.contains("صدا") ||
                raw.contains("دوبله جدا") ||
                raw.contains("صوت دوبله")
    }

        private fun linkTypeFa(link: JSONObject): String {
        if (isAudioOnly(link)) return ui("صوت دوبله")
        val t = (link.optString("type") + " " + link.optString("type_fa") + " " + link.optString("label") + " " + link.optString("display_label")).lowercase(Locale.US)
        return when {
            t.contains("dub") || t.contains("دوبله") -> ui("دوبله")
            t.contains("hard") || t.contains("هارد") -> ui("هاردساب")
            t.contains("sub") || t.contains("زیرنویس") -> ui("زیرنویس")
            else -> ui("زیرنویس")
        }
    }

    private fun premiumQualityChip(link: JSONObject, active: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = qualityChipText(link)
            setTextColor(white)
            textSize = 10.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = qualityGradient(link, active)
            applyTvFocusHalo(this, 16, 1.04f, 0f)
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { click() }
            minWidth = dp(70)
        }
    }

    private fun qualityChipText(link: JSONObject): String {
        val q = link.optString("quality").ifBlank { "نامشخص" }.uppercase(Locale.US)
        val kind = linkTypeFa(link)
        val label = (link.optString("display_label") + " " + link.optString("label")).uppercase(Locale.US)
        val tags = mutableListOf<String>()
        if (label.contains("4K") || q.contains("2160")) tags.add("4K")
        if (label.contains("HDR")) tags.add("HDR")
        if (label.contains("DOLBY")) tags.add("DV")
        if (label.contains("HEVC") || label.contains("H265")) tags.add("HEVC")
        return (listOf(q, kind) + tags).joinToString(" • ")
    }

    private fun qualityGradient(link: JSONObject, active: Boolean): GradientDrawable {
        val label = qualityChipText(link).uppercase(Locale.US)
        val colors = when {
            label.contains("4K") -> intArrayOf(Color.rgb(120, 70, 255), Color.rgb(30, 170, 255))
            label.contains("1080") -> intArrayOf(Color.rgb(0, 105, 255), Color.rgb(30, 175, 255))
            label.contains("720") -> intArrayOf(Color.rgb(0, 145, 130), Color.rgb(0, 205, 175))
            label.contains("480") -> intArrayOf(Color.rgb(85, 95, 125), Color.rgb(125, 140, 175))
            label.contains("دوبله") -> intArrayOf(Color.rgb(30, 90, 215), Color.rgb(90, 70, 245))
            label.contains("زیرنویس") -> intArrayOf(Color.rgb(180, 115, 20), Color.rgb(225, 170, 45))
            else -> intArrayOf(Color.rgb(42, 55, 82), Color.rgb(70, 88, 125))
        }
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = dp(16).toFloat()
            setStroke(dp(if (active) 2 else 1), if (active) Color.argb(230, 230, 245, 255) else Color.argb(105, 150, 180, 230))
        }
    }

    private fun premiumMiniButton(label: String, click: () -> Unit): View {
        if (!label.contains("دانلود") && !label.contains("Download", true)) {
            return TextView(this).apply {
                text = label
                setTextColor(white)
                textSize = 12.5f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                background = rounded(Color.rgb(14, 27, 50), dp(16), Color.argb(125, 65, 105, 170))
                applyTvFocusHalo(this, 16, 1.04f, 0f)
                applyMobileTouchHalo(this, 16)
                setOnClickListener { click() }
            }
        }
        val frame = FrameLayout(this).apply {
            clipToOutline = true
            background = rounded(Color.rgb(255, 19, 90), dp(999), Color.WHITE)
            elevation = dp(4).toFloat()
            isClickable = true
            isFocusable = true
            applyTvFocusHalo(this, 999, 1.04f, 0f)
        }
        val fill = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(15, 216, 80), Color.rgb(249, 240, 71))
            ).apply { cornerRadius = dp(999).toFloat() }
        }
        frame.addView(fill, FrameLayout.LayoutParams(0, -1, Gravity.LEFT))
        val labelView = TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 12.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        frame.addView(labelView, FrameLayout.LayoutParams(-1, -1))
        frame.setOnClickListener {
            if (!frame.isEnabled) return@setOnClickListener
            frame.isEnabled = false
            fill.layoutParams = fill.layoutParams.apply { width = 1 }
            fill.requestLayout()
            fill.post {
                val target = frame.width.coerceAtLeast(dp(120))
                fill.animate().cancel()
                fill.animate()
                    .setDuration(520L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f))
                    .withStartAction {
                        labelView.animate().alpha(0.78f).setDuration(120L).start()
                    }
                    .withEndAction {
                        labelView.alpha = 1f
                        click()
                        frame.postDelayed({
                            fill.layoutParams = fill.layoutParams.apply { width = 0 }
                            fill.requestLayout()
                            frame.isEnabled = true
                        }, 280L)
                    }
                    .translationX(0f)
                    .start()
                ValueAnimator.ofInt(1, target).apply {
                    duration = 520L
                    interpolator = android.view.animation.PathInterpolator(0.16f, 1f, 0.3f, 1f)
                    addUpdateListener { animator ->
                        fill.layoutParams = fill.layoutParams.apply { width = animator.animatedValue as Int }
                        fill.requestLayout()
                    }
                    start()
                }
            }
        }
        return frame
    }

    private fun showDownloadForLinks(item: JSONObject, links: List<JSONObject>) {
        if (links.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = bankGlassDrawable(26, 246, 82, true)
        }
        scroll.addView(box)
        box.addView(downloadNotice())
        if (itemContentType(item) == "series" || isSeriesLinks(links)) {
            box.addView(seriesBulkCopyButton(item, links), LinearLayout.LayoutParams(-1, dp(52)).apply {
                topMargin = dp(10)
                bottomMargin = dp(12)
            })
        }
        groupedDownloadBlocks(item, links).forEach { block ->
            box.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }
        val downloadBoxDialog = AlertDialog.Builder(this)
            .setView(scroll)
            .create()
        downloadBoxDialog.show()
        styleShownDialog(downloadBoxDialog, box, maxWidthDp = 620)
    }

    private fun showPlayablePage(item: JSONObject, links: List<JSONObject>) {
        pushCurrentScreenForBack()
        currentScreen = "player"
        val savedItem = item.toString()
        val savedLinks = JSONArray().apply { links.forEach { put(JSONObject(it.toString())) } }.toString()
        rememberCurrentScreen {
            val restoredArray = JSONArray(savedLinks)
            val restoredLinks = mutableListOf<JSONObject>()
            for (i in 0 until restoredArray.length()) restoredArray.optJSONObject(i)?.let { restoredLinks.add(it) }
            showPlayablePage(JSONObject(savedItem), restoredLinks)
        }
        buildBottomNav()
        clear()

        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { "پخش آنلاین" }
        val scroll = BankmovieSmoothScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(82))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(28))
        }
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = bankGlassDrawable(24, 240, 72, true)
            setPadding(dp(16), dp(12), dp(16), dp(12))
        }
        head.addView(svgIconButton(R.drawable.ic_player_back) { handleSmartBack() }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(14) })
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titleBox.addView(TextView(this).apply {
            text = if (isSeriesLinks(links)) "انتخاب فصل و قسمت" else "انتخاب نسخه پخش"
            setTextColor(white)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titleBox.addView(TextView(this).apply {
            text = title
            setTextColor(Color.rgb(178, 188, 205))
            textSize = 13.5f
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(5), 0, 0)
        })
        head.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        page.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        page.addView(TextView(this).apply {
            text = "کیفیت را انتخاب کن؛ ترک صدا، زیرنویس و ظاهر زیرنویس داخل پلیر قابل تغییر است."
            setTextColor(Color.rgb(205, 214, 230))
            textSize = 12.6f
            gravity = Gravity.RIGHT
            background = rounded(Color.argb(90, 255, 176, 30), dp(13), Color.argb(75, 255, 214, 90))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        page.addView(downloadNotice(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        if (itemContentType(item) == "series" || isSeriesLinks(links)) {
            page.addView(seriesBulkCopyButton(item, links), LinearLayout.LayoutParams(-1, dp(52)).apply { bottomMargin = dp(12) })
        }
        groupedDownloadBlocks(item, links).forEach { block ->
            page.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
        }

        applyTvFocusToClickableTree(page)
    }

        private fun showPlayableSheet(item: JSONObject) {
        val links = playableLinks(item)
        if (links.isEmpty()) {
            Toast.makeText(this, ui("لینک پخش مستقیم پیدا نشد"), Toast.LENGTH_SHORT).show()
            return
        }
        if (isTvLike()) { showPlayablePage(item, links); return }

        lateinit var dialog: AlertDialog
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { ui("انتخاب نسخه پخش") }
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(16))
            background = bankGlassDrawable(26, 246, 82, true)
        }
        shell.addView(View(this).apply {
            background = rounded(Color.argb(88, 255, 255, 255), dp(999), Color.TRANSPARENT)
        }, LinearLayout.LayoutParams(dp(44), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(11)
        })
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        head.addView(TextView(this).apply {
            text = if (isSeriesLinks(links)) ui("انتخاب فصل و قسمت") else ui("انتخاب نسخه پخش")
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(white)
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(58,255,255,255), dp(17), Color.argb(45,255,255,255))
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(10) })
        shell.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) })
        shell.addView(TextView(this).apply { text = title; setTextColor(Color.rgb(178, 188, 205)); textSize = 12f; gravity = Gravity.RIGHT; maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(0, dp(5), 0, dp(10)) })
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, 0) }
        scroll.addView(box)
        box.addView(downloadNotice(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        groupedDownloadBlocks(item, links).forEach { block -> box.addView(block, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) }) }
        shell.addView(scroll)
        dialog = AlertDialog.Builder(this).setView(shell).create()
        activePlayableSheet = dialog
        dialog.setOnDismissListener { if (activePlayableSheet === dialog) activePlayableSheet = null }
        dialog.show()
        styleShownDialog(dialog, shell, maxWidthDp = 560, dimAmount = 0.72f)
        dialog.window?.let { win ->
            val attrs = win.attributes
            attrs.gravity = Gravity.BOTTOM
            win.attributes = attrs
            win.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun svgHeaderIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(Color.TRANSPARENT, dp(20), Color.TRANSPARENT)
            applyTvFocusHalo(this, 999, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (isLightTheme()) Color.rgb(25, 28, 34) else Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(27), dp(27), Gravity.CENTER))
        }
    }

    private fun hamburgerHeaderButton(click: (MorphHamburgerView) -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(if (isLightTheme()) Color.argb(225,255,255,255) else Color.argb(150,0,0,0), dp(999), alphaLine(80))
            elevation = dp(8).toFloat()
            applyTvFocusHalo(this, 999, 1.06f, dp(8).toFloat())
            applyMobileTouchHalo(this, 999)
            val icon = MorphHamburgerView(this@MainActivity).apply {
                lineColor = if (isLightTheme()) Color.rgb(18, 20, 24) else Color.WHITE
                setOpened(false, animate = false)
            }
            addView(icon, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
            setOnClickListener {
                icon.setOpened(true, animate = true)
                click(icon)
                animate().cancel()
                animate().scaleX(0.96f).scaleY(0.96f).setDuration(45L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(70L).start()
                }.start()
            }
        }
    }

    private fun svgIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(if (isLightTheme()) Color.argb(225,255,255,255) else Color.argb(150,0,0,0), dp(999), alphaLine(80))
            elevation = dp(8).toFloat()
            applyTvFocusHalo(this, 999, 1.08f, dp(8).toFloat())
            setOnClickListener {
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(90).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (isLightTheme()) Color.rgb(18,20,24) else Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
    }

    private fun iconActionButton(label: String, iconRes: Int, primary: Boolean, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = if (primary) blueGradient(dp(22)) else rounded(Color.argb(if (isLightTheme()) 210 else 130, if (isLightTheme()) 255 else 0, if (isLightTheme()) 255 else 0, if (isLightTheme()) 255 else 0), dp(22), alphaLine(110))
            setPadding(dp(14), 0, dp(14), 0)
            elevation = if (primary) dp(10).toFloat() else dp(4).toFloat()
            applyTvFocusHalo(this, 24, 1.045f, elevation)
            setOnClickListener {
                animate().scaleX(0.965f).scaleY(0.965f).setDuration(70).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(110).start()
                    click()
                }.start()
            }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (primary) alphaTextOnPrimary() else white)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(if (primary) alphaTextOnPrimary() else white)
                textSize = 13.1f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun downloadBrandButton(label: String, iconRes: Int, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(12, 24, 42), dp(16), Color.argb(160, 74, 115, 180))
            setPadding(dp(12), 0, dp(12), 0)
            setOnClickListener { click() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { marginEnd = dp(9) })
            addView(TextView(this@MainActivity).apply {
                text = label
                setTextColor(white)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
    }

    private fun infoCell(iconRes: Int, label: String, value: String): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.rgb(11, 19, 34), dp(14), Color.rgb(23, 39, 64))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                setColorFilter(blue2)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(8) })
            val texts = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            texts.addView(TextView(this@MainActivity).apply { text = label; setTextColor(faint); textSize = 10.5f })
            texts.addView(TextView(this@MainActivity).apply { text = value.ifBlank { "-" }; setTextColor(white); textSize = 12f; typeface = Typeface.DEFAULT_BOLD; maxLines = 1 })
            addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun linkButton(label: String, primary: Boolean, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = if (primary) 14f else 11.5f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (primary) blueGradient(dp(16)) else rounded(Color.rgb(6, 11, 20), dp(14), Color.rgb(39, 62, 96))
            setOnClickListener { click() }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = blueGradient(dp(18))
            setOnClickListener { click() }
        }
    }

    private fun playbackChoiceButton(
        iconRes: Int,
        title: String,
        subtitle: String,
        accent: Int,
        transparentIcon: Boolean = false,
        tintIcon: Boolean = false,
        click: () -> Unit
    ): LinearLayout {
        fun rowBackground(focused: Boolean): GradientDrawable {
            return rounded(
                if (focused) Color.rgb(17, 29, 48) else Color.rgb(10, 18, 31),
                dp(15),
                if (focused) accent else Color.argb(95, Color.red(accent), Color.green(accent), Color.blue(accent))
            )
        }

        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rowBackground(false)
            setPadding(dp(11), dp(7), dp(11), dp(7))
            isClickable = true
            isFocusable = isTvLike()
            setOnClickListener { click() }
            if (isTvLike()) {
                applyTvFocusHalo(this, 16, 1.035f, 0f) { view, focused ->
                    view.background = rowBackground(focused)
                }
            }

            val iconShell = FrameLayout(this@MainActivity).apply {
                background = if (transparentIcon) null else rounded(Color.argb(42, 255, 255, 255), dp(12), Color.argb(45, 255, 255, 255))
            }
            iconShell.addView(ImageView(this@MainActivity).apply {
                setImageResource(iconRes)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = title
                if (tintIcon) setColorFilter(accent)
                val pad = if (transparentIcon) dp(2) else dp(7)
                setPadding(pad, pad, pad, pad)
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addView(iconShell, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(10) })

            val labels = LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            }
            labels.addView(TextView(this@MainActivity).apply {
                text = title
                setTextColor(white)
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            labels.addView(TextView(this@MainActivity).apply {
                text = subtitle
                setTextColor(Color.rgb(156, 171, 194))
                textSize = 10.6f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(3), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))

            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_chevron_left)
                setColorFilter(accent)
                setPadding(dp(3), dp(3), dp(3), dp(3))
            }, LinearLayout.LayoutParams(dp(24), dp(38)))
        }
    }

    private fun playbackMime(link: JSONObject): String {
        return if (isAudioOnly(link)) "audio/*" else "video/*"
    }

    private fun firstInstalledPackage(vararg candidates: String): String? {
        for (pkg in candidates) {
            try {
                packageManager.getPackageInfo(pkg, 0)
                return pkg
            } catch (_: Throwable) {
            }
        }
        return null
    }

    private fun installedPlayerIcon(packageName: String?): android.graphics.drawable.Drawable? {
        if (packageName.isNullOrBlank()) return null
        return try { packageManager.getApplicationIcon(packageName) } catch (_: Throwable) { null }
    }

    private fun launchPackagePlayer(link: JSONObject, title: String, packageName: String): Boolean {
        val url = link.optString("url").trim()
        if (url.isBlank()) return false
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), playbackMime(link))
            setPackage(packageName)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("title", title)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        return try {
            startActivity(intent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    private fun launchMxPlayer(link: JSONObject, title: String): Boolean {
        val pkg = firstInstalledPackage("com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro") ?: return false
        return launchPackagePlayer(link, title, pkg)
    }

    private fun launchVlcPlayer(link: JSONObject, title: String): Boolean {
        val url = link.optString("url").trim()
        if (url.isBlank()) {
            Toast.makeText(this, t("لینک پخش معتبر نیست", "Playback link is invalid"), Toast.LENGTH_SHORT).show()
            return false
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), playbackMime(link))
            setPackage("org.videolan.vlc")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra("title", title)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        return try {
            startActivity(intent)
            true
        } catch (_: Throwable) {
            Toast.makeText(this, t("VLC نصب نیست؛ پلیرهای دیگر نمایش داده شدند", "VLC is not installed; showing other players"), Toast.LENGTH_LONG).show()
            launchOtherPlayers(link, title)
        }
    }

    private fun launchOtherPlayers(link: JSONObject, title: String): Boolean {
        val url = link.optString("url").trim()
        if (url.isBlank()) {
            Toast.makeText(this, t("لینک پخش معتبر نیست", "Playback link is invalid"), Toast.LENGTH_SHORT).show()
            return false
        }
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(Uri.parse(url), playbackMime(link))
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            putExtra(Intent.EXTRA_TITLE, title)
        }
        return try {
            startActivity(Intent.createChooser(intent, t("انتخاب پلیر خارجی", "Choose an external player")))
            true
        } catch (_: Throwable) {
            Toast.makeText(this, t("پلیر سازگاری روی دستگاه پیدا نشد", "No compatible player was found"), Toast.LENGTH_LONG).show()
            false
        }
    }

    private fun cachePlayerPayload(payload: JSONObject): String {
        return try {
            val directory = File(cacheDir, "player_payloads").apply { mkdirs() }
            directory.listFiles()?.filter { System.currentTimeMillis() - it.lastModified() > 24L * 60L * 60L * 1000L }?.forEach { runCatching { it.delete() } }
            val file = File(directory, "playlist_${System.currentTimeMillis()}_${stableHash(payload.optString("video"))}.json")
            file.writeText(payload.toString(), Charsets.UTF_8)
            file.absolutePath
        } catch (_: Throwable) {
            ""
        }
    }

    private fun minimalPlayerPayload(selectedLink: JSONObject, title: String): JSONObject {
        val track = JSONObject().apply {
            put("url", selectedLink.optString("url"))
            put("title", title)
            put("quality", selectedLink.optString("quality"))
            put("type", selectedLink.optString("type"))
            put("label", selectedLink.optString("label"))
            put("display_label", selectedLink.optString("display_label"))
            put("type_fa", selectedLink.optString("type_fa"))
            put("is_audio", selectedLink.optBoolean("is_audio", false))
            put("season", selectedLink.optInt("season", 0))
            put("episode", selectedLink.optInt("episode", 0))
            put("progress_key", selectedLink.optString("progress_key").ifBlank { "progress_${selectedLink.optString("url")}" })
        }
        return JSONObject().put("video", selectedLink.optString("url")).put("title", title).put("selectedIndex", 0).put("tracks", JSONArray().put(track))
    }

    private fun launchInternalPlayer(item: JSONObject, selectedLink: JSONObject, title: String, payload: JSONObject) {
        val url = selectedLink.optString("url").trim()
        if (url.isBlank()) {
            Toast.makeText(this, t("لینک پخش معتبر نیست", "Playback link is invalid"), Toast.LENGTH_SHORT).show()
            return
        }
        val payloadPath = cachePlayerPayload(payload)
        val fallbackPayload = minimalPlayerPayload(selectedLink, title).toString()
        val intent = Intent(this, PlayerActivity::class.java).apply {
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, url)
            putExtra(PlayerActivity.EXTRA_TITLE, title)
            putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, fallbackPayload)
            if (payloadPath.isNotBlank()) putExtra(PlayerActivity.EXTRA_PLAYLIST_FILE, payloadPath)
            putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, playbackProgressKey(item, selectedLink))
            putExtra(PlayerActivity.EXTRA_RESUME_POSITION, savedProgressFor(item, selectedLink))
        }
        try {
            startActivity(intent)
        } catch (_: android.os.TransactionTooLargeException) {
            intent.removeExtra(PlayerActivity.EXTRA_PLAYLIST_FILE)
            intent.putExtra(PlayerActivity.EXTRA_PLAYLIST_JSON, fallbackPayload)
            startActivity(intent)
        } catch (error: Throwable) {
            Toast.makeText(this, t("پلیر داخلی باز نشد؛ دوباره تلاش کنید", "The built-in player could not open. Please try again."), Toast.LENGTH_LONG).show()
        }
    }

    private fun showPlaybackMethodDialog(
        item: JSONObject,
        selectedLink: JSONObject,
        title: String,
        payload: JSONObject
    ) {
        // PASS 4.10: real compact playback chooser. External players are compact
        // horizontal tiles and the dialog keeps side margins instead of stretching edge-to-edge.
        lateinit var dialog: AlertDialog
        val p = UiPreferences.palette(this)
        val selectedLabel = selectedLink.optString("display_label")
            .ifBlank { selectedLink.optString("quality") }
            .ifBlank { selectedLink.optString("label") }
            .ifBlank { t("نسخه انتخاب‌شده", "Selected version") }
        val resumeLabel = formatResumeTime(savedProgressFor(item, selectedLink))
        val vlcPkg = firstInstalledPackage("org.videolan.vlc")
        val mxPkg = firstInstalledPackage("com.mxtech.videoplayer.ad", "com.mxtech.videoplayer.pro")

        fun compactExternalTile(
            titleText: String,
            packageName: String?,
            fallbackIcon: Int,
            accent: Int,
            click: () -> Unit
        ): LinearLayout {
            val installed = !packageName.isNullOrBlank()
            return LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(12), dp(12), dp(10))
                background = bankGlassDrawable(18, if (installed) 220 else 160, if (installed) 52 else 28, true)
                alpha = if (installed) 1f else 0.52f
                isClickable = installed
                isFocusable = installed
                if (installed) {
                    applyMobileTouchHalo(this, 18)
                    applyTvFocusHalo(this, 18, 1.03f, 0f)
                    setOnClickListener { click() }
                }
                val iconBox = FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.argb(36, Color.red(accent), Color.green(accent), Color.blue(accent)), dp(12), Color.argb(62, Color.red(accent), Color.green(accent), Color.blue(accent)))
                    addView(ImageView(this@MainActivity).apply {
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        installedPlayerIcon(packageName)?.let { setImageDrawable(it) } ?: run {
                            setImageResource(fallbackIcon)
                            if (fallbackIcon == R.drawable.ic_external_player) setColorFilter(accent)
                        }
                        setPadding(dp(5), dp(5), dp(5), dp(5))
                    }, FrameLayout.LayoutParams(-1, -1))
                }
                addView(iconBox, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(9) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    addView(TextView(this@MainActivity).apply {
                        text = titleText
                        setTextColor(p.text)
                        textSize = 13.2f
                        typeface = BankmovieFonts.bold(this@MainActivity)
                        gravity = Gravity.CENTER
                        maxLines = 1
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = if (installed) t("نصب شده", "Installed") else t("نصب نیست", "Not installed")
                        setTextColor(p.muted)
                        textSize = 9.8f
                        gravity = Gravity.CENTER
                        setPadding(0, dp(4), 0, 0)
                    })
                }, LinearLayout.LayoutParams(-1, -2))
            }
        }

        fun compactWideRow(
            iconRes: Int,
            titleText: String,
            subtitleText: String,
            primary: Boolean,
            click: () -> Unit
        ): LinearLayout {
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(5), dp(10), dp(5))
                background = if (primary) bankTintGlassDrawable(p.primary, 18, 205, 0.14f) else bankGlassDrawable(18, 214, 48, true)
                isClickable = true
                isFocusable = true
                applyMobileTouchHalo(this, 18)
                applyTvFocusHalo(this, 18, 1.03f, 0f)
                setOnClickListener { click() }
                addView(FrameLayout(this@MainActivity).apply {
                    background = rounded(Color.argb(34, Color.red(p.primary), Color.green(p.primary), Color.blue(p.primary)), dp(12), Color.argb(58,255,255,255))
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(iconRes)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        if (iconRes != R.drawable.bankmovie_mark_transparent) setColorFilter(p.primary)
                        setPadding(dp(5), dp(5), dp(5), dp(5))
                    }, FrameLayout.LayoutParams(-1, -1))
                }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(12) })
                addView(LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                    addView(TextView(this@MainActivity).apply {
                        text = titleText
                        setTextColor(p.text)
                        textSize = 12.5f
                        typeface = BankmovieFonts.bold(this@MainActivity)
                        gravity = Gravity.RIGHT
                        maxLines = 1
                    })
                    addView(TextView(this@MainActivity).apply {
                        text = subtitleText
                        setTextColor(p.muted)
                        textSize = 9.2f
                        gravity = Gravity.RIGHT
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    })
                }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_chevron_left)
                    setColorFilter(p.primary)
                    setPadding(dp(3), dp(3), dp(3), dp(3))
                }, LinearLayout.LayoutParams(dp(24), dp(32)))
            }
        }

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(9), dp(20), dp(20))
            background = bankGlassDrawable(28, 250, 74, true)
        }
        shell.addView(View(this).apply {
            background = rounded(Color.argb(90,255,255,255), dp(999), Color.TRANSPARENT)
        }, LinearLayout.LayoutParams(dp(40), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(5) })

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@MainActivity).apply {
                text = t("پخش آنلاین", "Online playback")
                setTextColor(p.text)
                textSize = 17.2f
                typeface = BankmovieFonts.bold(this@MainActivity)
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@MainActivity).apply {
                text = t("روش پخش را انتخاب کنید", "Choose how to play")
                setTextColor(p.muted)
                textSize = 9.7f
                gravity = Gravity.RIGHT
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(p.text)
            textSize = 21f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = bankGlassDrawable(999, 178, 38, false)
            isClickable = true
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(7) })
        shell.addView(head, LinearLayout.LayoutParams(-1, dp(60)).apply { bottomMargin = dp(18) })

        shell.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(10), dp(4))
            background = bankGlassDrawable(17, 205, 44, true)
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(p.primary)
                setPadding(dp(5), dp(5), dp(5), dp(5))
                background = bankTintGlassDrawable(p.primary, 11, 170, 0.13f)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(12) })
            addView(LinearLayout(this@MainActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@MainActivity).apply {
                    text = selectedLabel
                    setTextColor(p.text)
                    textSize = 12.3f
                    typeface = BankmovieFonts.bold(this@MainActivity)
                    gravity = Gravity.RIGHT
                    maxLines = 1
                })
                addView(TextView(this@MainActivity).apply {
                    text = title
                    setTextColor(p.muted)
                    textSize = 9.1f
                    gravity = Gravity.RIGHT
                    maxLines = 1
                    ellipsize = TextUtils.TruncateAt.END
                })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }, LinearLayout.LayoutParams(-1, dp(76)).apply { bottomMargin = dp(18) })

        val bankmovieSubtitle = if (resumeLabel.isNotBlank()) {
            t("ادامه از $resumeLabel • پلیر داخلی", "Resume from $resumeLabel • Built-in player")
        } else {
            t("پلیر داخلی • ادامه تماشا و زیرنویس", "Built-in player • progress and subtitles")
        }
        shell.addView(TextView(this).apply {
            text = t("انتخاب برنامه…", "Choose an app…")
            setTextColor(p.text)
            textSize = 14.2f
            typeface = BankmovieFonts.bold(this@MainActivity)
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(2)
            bottomMargin = dp(14)
        })

        shell.addView(compactWideRow(
            R.drawable.bankmovie_mark_transparent,
            t("پخش با بانک مووی", "Play with Bankmovie"),
            bankmovieSubtitle,
            true
        ) {
            dialog.dismiss()
            markPlayed(item, selectedLink)
            launchInternalPlayer(item, selectedLink, title, payload)
        }, LinearLayout.LayoutParams(-1, dp(90)).apply { bottomMargin = dp(16) })

        val externalRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        externalRow.addView(compactExternalTile("VLC", vlcPkg, R.drawable.ic_vlc_logo, Color.rgb(247,144,30)) {
            dialog.dismiss()
            if (vlcPkg != null && launchPackagePlayer(selectedLink, title, vlcPkg)) markPlayed(item, selectedLink)
        }, LinearLayout.LayoutParams(0, dp(148), 1f).apply { marginStart = dp(5) })
        externalRow.addView(compactExternalTile("MX Player", mxPkg, R.drawable.ic_external_player, Color.rgb(55,145,245)) {
            dialog.dismiss()
            if (mxPkg != null && launchPackagePlayer(selectedLink, title, mxPkg)) markPlayed(item, selectedLink)
        }, LinearLayout.LayoutParams(0, dp(148), 1f).apply { marginEnd = dp(5) })
        shell.addView(externalRow, LinearLayout.LayoutParams(-1, dp(148)).apply { bottomMargin = dp(16) })

        shell.addView(compactWideRow(
            R.drawable.ic_external_player,
            t("سایر پلیرهای نصب‌شده", "Other installed players"),
            t("انتخاب از برنامه‌های سازگار دستگاه", "Choose from compatible apps"),
            false
        ) {
            dialog.dismiss()
            if (launchOtherPlayers(selectedLink, title)) markPlayed(item, selectedLink)
        }, LinearLayout.LayoutParams(-1, dp(76)))

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        styleShownDialog(dialog, shell, preferredFocus = shell.getChildAt(4), maxWidthDp = 560, dimAmount = 0.72f)
        if (!isTvLike()) {
            dialog.window?.let { win ->
                val attrs = win.attributes
                attrs.gravity = Gravity.BOTTOM
                win.attributes = attrs
                val targetWidth = (resources.displayMetrics.widthPixels - dp(14)).coerceAtMost(dp(560))
                win.setLayout(targetWidth, ViewGroup.LayoutParams.WRAP_CONTENT)
            }
        }
    }


    private fun openPlayer(item: JSONObject, links: List<JSONObject>, selected: Int) {
        if (links.isEmpty()) return
        activePlayableSheet?.dismiss()
        activePlayableSheet = null
        val originalIndex = selected.coerceIn(0, links.size - 1)
        val originalSelected = links[originalIndex]
        val selectedSeason = originalSelected.optInt("season", 0)
        val selectedEpisode = originalSelected.optInt("episode", 0)
        val preparedLinks = when {
            links.size <= 120 -> links
            selectedEpisode > 0 -> links.filter { link ->
                val season = link.optInt("season", 0)
                val episode = link.optInt("episode", 0)
                season == selectedSeason && episode in (selectedEpisode - 1).coerceAtLeast(1)..(selectedEpisode + 14)
            }.let { filtered ->
                val result = filtered.take(120).toMutableList()
                if (result.none { it.optString("url") == originalSelected.optString("url") }) result.add(0, originalSelected)
                result
            }
            else -> links.subList((originalIndex - 40).coerceAtLeast(0), (originalIndex + 80).coerceAtMost(links.size))
        }
        val safeIndex = preparedLinks.indexOfFirst { it.optString("url") == originalSelected.optString("url") }.let { if (it >= 0) it else 0 }
        val selectedLink = preparedLinks[safeIndex]
        val title = item.optString("title_fa").ifBlank { item.optString("title") }.ifBlank { t("پخش آنلاین", "Online playback") }
        val arr = JSONArray()
        preparedLinks.forEach { l ->
            arr.put(JSONObject().apply {
                put("url", l.optString("url"))
                put("title", title)
                put("quality", l.optString("quality"))
                put("type", l.optString("type"))
                put("label", l.optString("label"))
                put("display_label", l.optString("display_label"))
                put("type_fa", l.optString("type_fa"))
                put("is_audio", l.optBoolean("is_audio", false))
                put("season", l.optString("season"))
                put("episode", l.optString("episode"))
                put("progress_key", playbackProgressKey(item, l))
            })
        }
        val payload = JSONObject().apply {
            put("video", selectedLink.optString("url"))
            put("title", title)
            put("selectedIndex", safeIndex)
            put("tracks", arr)
        }
        showPlaybackMethodDialog(item, selectedLink, title, payload)
    }

    private fun enrichEpisodeIdentity(link: JSONObject): JSONObject {
        var season = link.optInt("season", 0)
        var episode = link.optInt("episode", 0)
        if (season > 0 && episode > 0) return link
        val raw = listOf(
            link.optString("file_name"), link.optString("filename"), link.optString("name"),
            link.optString("display_label"), link.optString("label"), link.optString("url")
        ).joinToString(" ")

        Regex("(?i)S(\\d{1,2})[ ._-]*E(\\d{1,3})").find(raw)?.let { m ->
            if (season <= 0) season = m.groupValues[1].toIntOrNull() ?: 0
            if (episode <= 0) episode = m.groupValues[2].toIntOrNull() ?: 0
        }
        if (season <= 0 || episode <= 0) {
            Regex("(?i)(?:season|فصل)[ ._:-]*(\\d{1,2}).{0,18}?(?:episode|ep|قسمت)[ ._:-]*(\\d{1,3})").find(raw)?.let { m ->
                if (season <= 0) season = m.groupValues[1].toIntOrNull() ?: 0
                if (episode <= 0) episode = m.groupValues[2].toIntOrNull() ?: 0
            }
        }
        if (season <= 0) {
            Regex("(?i)(?:season|فصل)[ ._:-]*(\\d{1,2})").find(raw)?.let { m -> season = m.groupValues[1].toIntOrNull() ?: 0 }
        }
        if (episode <= 0) {
            Regex("(?i)(?:episode|ep|قسمت)[ ._:-]*(\\d{1,3})").find(raw)?.let { m -> episode = m.groupValues[1].toIntOrNull() ?: 0 }
        }
        if (season > 0) link.put("season", season)
        if (episode > 0) link.put("episode", episode)
        return link
    }

    private fun playableLinks(item: JSONObject): List<JSONObject> {
        val play = item.optJSONObject("play")
        val arr = play?.optJSONArray("links") ?: item.optJSONArray("links") ?: item.optJSONArray("downloads") ?: JSONArray()
        val out = mutableListOf<JSONObject>()
        for (i in 0 until arr.length()) {
            val l = arr.optJSONObject(i) ?: continue
            // Download/media URLs are authoritative data from app_api.php. Keep
            // their host untouched so old, current and future download subdomains
            // can coexist without shipping a new APK.
            val url = l.optString("url").trim()
            if (url.isBlank()) continue
            val copy = enrichEpisodeIdentity(JSONObject(l.toString()).apply { put("url", url) })
            val http = url.startsWith("http://", true) || url.startsWith("https://", true)
            val direct = copy.optBoolean("is_direct", true)
            if (http || direct || isVideo(url) || isAudioOnly(copy)) out.add(copy)
        }
        return out.sortedWith(
            compareBy<JSONObject> { it.optInt("season", 0) }
                .thenBy { it.optInt("episode", 0) }
                .thenBy { linkKindKey(it) }
                .thenByDescending { qualityScore(it.optString("quality")) }
                .thenBy { it.optString("display_label") }
        )
    }

    private fun isSeriesLinks(links: List<JSONObject>) = links.any { it.optInt("season", 0) > 0 || it.optInt("episode", 0) > 0 }

    private fun isVideo(url: String): Boolean {
        val u = url.lowercase(Locale.US)
        return u.startsWith("http") && (
            u.contains(".mkv") || u.contains(".mp4") || u.contains(".m3u8") || u.contains(".mpd") ||
            u.contains("format=mpd") || u.contains("dash") || u.contains("hls") ||
            u.contains(".avi") || u.contains(".webm") || u.contains(".mov")
        )
    }

    private fun qualityScore(q: String) = Regex("(\\d+)").find(q)?.value?.toIntOrNull() ?: 0

    private fun linkLabel(link: JSONObject): String {
        val ep = if (link.optInt("season", 0) > 0 || link.optInt("episode", 0) > 0) "فصل ${link.optInt("season", 0)} قسمت ${link.optInt("episode", 0)} • " else ""
        return ep + link.optString("display_label").ifBlank { shortLinkLabel(link) }
    }

    private fun shortLinkLabel(link: JSONObject): String {
        val display = link.optString("display_label").trim()
        if (display.isNotBlank() && !display.equals("unknown", true) && display != "نامشخص") return display
        val kind = linkTypeFa(link)
        val q = link.optString("quality").ifBlank { "کیفیت نامشخص" }
        return "$q • $kind"
    }

    private fun genresText(item: JSONObject): String {
        val arr = item.optJSONArray("genres") ?: return ""
        val out = mutableListOf<String>()
        for (i in 0 until arr.length()) out.add(arr.optString(i))
        return out.joinToString("   ")
    }

    private fun cleanRating(v: String): String {
        if (v.isBlank() || v == "null") return "N/A"
        return try { String.format(Locale.US, "%.1f", v.toDouble()) } catch (_: Throwable) { v.take(3) }
    }

    private fun iconText(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 25f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(60, 15, 25, 42), dp(17), Color.TRANSPARENT)
        }
    }

        private fun chip(label: String, active: Boolean): TextView {
        return TextView(this).apply {
            text = ui(label)
            setTextColor(if (active) alphaTextOnPrimary() else white)
            textSize = 12.6f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = if (active) blueGradient(dp(18)) else rounded(Color.argb(if (isLightTheme()) 34 else 28, 255, 255, 255), dp(18), Color.TRANSPARENT)
            setPadding(dp(18), 0, dp(18), 0)
            applyTvFocusHalo(this, 20, 1.05f, 0f)
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")


    private fun showMenuDialog() {
        val archive = selectedArchive
        val items = when (archive) {
            2 -> arrayOf("خانه", "اکران 2025 و 2026", "سریال‌های آپدیت‌شده", "دوبله فارسی", "انیمیشن", "اکشن", "جستجو")
            3 -> arrayOf("خانه", "جدیدترین فیلم‌ها", "جدیدترین سریال‌ها", "انیمیشن‌های به‌روزشده", "انیمه‌های به‌روزشده", "دوبله فارسی", "جستجو")
            else -> arrayOf("خانه", "فیلم‌های بروز شده", "سریال‌های بروز شده", "دوبله فارسی", "سریال‌های چینی", "کالکشن‌ها", "جستجو")
        }
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = bankGlassDrawable(24, 236, 70, true)
            clipChildren = false
            clipToPadding = false
        }
        box.addView(TextView(this).apply {
            text = archiveLabel(archive)
            setTextColor(white)
            textSize = 18f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(dp(6), 0, dp(6), dp(12))
        })
        items.forEachIndexed { index, label ->
            box.addView(TextView(this).apply {
                text = label
                setTextColor(white)
                textSize = 13.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                setPadding(dp(16), 0, dp(16), 0)
                background = bankGlassDrawable(16, 226, 62, false)
                applyTvFocusHalo(this, 17, 1.035f, 0f)
                setOnClickListener {
                    dialog.dismiss()
                    when (archive) {
                        3 -> when (index) {
                            0 -> showHome()
                            1 -> showList(items[1], 3, "new_movies")
                            2 -> showList(items[2], 3, "new_series")
                            3 -> showList(items[3], 3, "updated_animations")
                            4 -> showList(items[4], 3, "updated_anime")
                            5 -> showList(items[5], 3, "dubbed_movies")
                            6 -> showSearch()
                        }
                        else -> when (index) {
                            0 -> showHome()
                            1 -> showList(items[1], archive, "updated_movies")
                            2 -> showList(items[2], archive, "updated_series")
                            3 -> showList(items[3], archive, "dubbed")
                            4 -> showList(items[4], archive, if (archive == 1) "chinese_series" else "anime")
                            5 -> if (archive == 1) showCollections() else showList(items[5], 2, "genre_movie_action")
                            6 -> showSearch()
                        }
                    }
                }
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = if (index == items.lastIndex) 0 else dp(7) })
        }
        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        styleShownDialog(dialog, box, maxWidthDp = 480)
    }


    private fun hmacSha256Hex(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun fetch(url: String, cb: (Boolean, JSONObject?, String?) -> Unit) {
        Thread {
            ensureDefaultServerPool()
            val rewrittenOriginal = rewriteConfiguredUrl(url)
            val original = try { URL(rewrittenOriginal) } catch (_: Throwable) {
                cb(false, null, "خطای اتصال")
                return@Thread
            }

            val candidates = mutableListOf<Pair<ServerEndpoint?, String>>()
            val query = original.query?.let { "?$it" }.orEmpty()
            val isApiRequest = original.path.endsWith("app_api.php", true)

            if (isApiRequest) {
                apiServers.forEach { endpoint ->
                    candidates.add(endpoint to (endpoint.apiUrl.substringBefore('?') + query))
                }
            } else {
                candidates.add(null to rewrittenOriginal)
            }

            if (candidates.none { it.second.equals(rewrittenOriginal, true) }) {
                candidates.add(0, null to rewrittenOriginal)
            }

            val uniqueCandidates = candidates.distinctBy { it.second.lowercase(Locale.US) }
            var lastError = "خطای اتصال"

            for (candidate in uniqueCandidates) {
                var authAttempt = 0
                while (authAttempt < 2) {
                    var c: HttpURLConnection? = null
                    try {
                        val u = URL(candidate.second)
                        c = (u.openConnection() as HttpURLConnection).apply {
                            connectTimeout = 10000
                            readTimeout = 16000
                            instanceFollowRedirects = true
                            setRequestProperty("Accept", "application/json")
                            setRequestProperty("User-Agent", "BankmovieAndroidNative/2.0-V2")
                            setRequestProperty("Cache-Control", "no-cache")
                        }
                        if (u.path.endsWith("app_api.php", true)) {
                            val ts = (System.currentTimeMillis() / 1000L + serverClockOffsetSec).toString()
                            val pathQuery = u.path + if (u.query.isNullOrBlank()) "" else "?${u.query}"
                            c.setRequestProperty("X-BM-App-Key", bmAppKey)
                            c.setRequestProperty("X-BM-Ts", ts)
                            c.setRequestProperty("X-BM-Sign", hmacSha256Hex("$ts|$pathQuery", bmAppSecret))
                        }

                        val code = c.responseCode
                        c.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let {
                            serverClockOffsetSec = it / 1000L - System.currentTimeMillis() / 1000L
                        }

                        if (code == 401 && authAttempt == 0) {
                            authAttempt++
                            c.disconnect()
                            continue
                        }

                        val stream = if (code in 200..299) c.inputStream else c.errorStream
                        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()

                        if (code in 200..299 && body.isNotBlank()) {
                            candidate.first?.let { endpoint ->
                                apiBase = endpoint.apiUrl
                                activeDomain = endpoint.contentDomain
                                activeServerName = endpoint.name
                                val prefsEditor = appPrefs().edit()
                                    .putString("api_base", apiBase)
                                    .putString("active_domain", activeDomain)
                                    .putString("active_server_name", activeServerName)
                                if (appPrefs().getBoolean("account_api_follows_active_domain", true)) {
                                    prefsEditor.putString("account_api_url", "${activeDomain.trimEnd('/')}/app_user_api.php")
                                }
                                prefsEditor.apply()
                            }
                            val parsed = JSONObject(body)
                            rewriteJsonUrls(parsed)
                            c.disconnect()
                            cb(true, parsed, null)
                            return@Thread
                        }

                        lastError = if (code == 401) {
                            "اعتبارسنجی ارتباط انجام نشد. ساعت گوشی را روی حالت خودکار بگذارید و دوباره تلاش کنید."
                        } else {
                            "خطای موقت ارتباطی"
                        }
                        c.disconnect()
                        break
                    } catch (_: Throwable) {
                        lastError = "خطای اتصال"
                        try { c?.disconnect() } catch (_: Throwable) {}
                        break
                    }
                }
            }

            cb(false, null, lastError)
        }.start()
    }

    private fun normalizeImageUrl(raw: String): String {
        val original = raw.trim()
        if (original.startsWith(AppConfig.GENRE_ASSET_BASE_URL, ignoreCase = true)) return original
        var u = rewriteConfiguredUrl(original)
        if (u.isBlank() || u == "null") return ""
        if (u.startsWith("//")) return "https:$u"
        if (u.startsWith("http://") || u.startsWith("https://")) return u
        if (u.startsWith("/")) return activeDomain.trimEnd('/') + u
        if (u.startsWith("posters/") || u.startsWith("uploads/") || u.startsWith("assets/") || u.startsWith("storage/")) {
            return activeDomain.trimEnd('/') + "/" + u.trimStart('/')
        }
        return activeDomain.trimEnd('/') + "/" + u.trimStart('/')
    }

    private fun stopPosterShimmer(target: ImageView, keepPlaceholder: Boolean = false) {
        (target.getTag(R.id.bm_image_shimmer) as? PosterShimmerDrawable)?.stop()
        target.setTag(R.id.bm_image_shimmer, null)
        if (!keepPlaceholder) target.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun startPosterShimmer(target: ImageView) {
        (target.getTag(R.id.bm_image_shimmer) as? PosterShimmerDrawable)?.stop()
        val shimmer = PosterShimmerDrawable(lowEndDevice)
        target.setTag(R.id.bm_image_shimmer, shimmer)
        target.setImageDrawable(null)
        target.background = shimmer
        shimmer.start()
    }

    private fun loadImage(url: String, target: ImageView, onBitmap: ((Bitmap) -> Unit)? = null) {
        val finalUrl = normalizeImageUrl(url)
        if (finalUrl.isBlank()) {
            stopPosterShimmer(target, keepPlaceholder = true)
            target.setBackgroundColor(Color.rgb(16, 23, 34))
            return
        }
        if (target.tag == finalUrl && target.drawable != null) {
            target.alpha = 1f
            return
        }
        target.tag = finalUrl
        imageCache.get(finalUrl)?.takeIf { !it.isRecycled }?.let { cached ->
            stopPosterShimmer(target)
            target.setImageBitmap(cached)
            target.alpha = 1f
            onBitmap?.invoke(cached)
            return
        }

        startPosterShimmer(target)
        imageExecutor.execute {
            var conn: HttpURLConnection? = null
            var delivered = false
            try {
                conn = URL(finalUrl).openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout = 7000
                conn.instanceFollowRedirects = true
                conn.useCaches = true
                conn.setRequestProperty("User-Agent", "Bankmovie Android")
                conn.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8")

                val expected = conn.contentLengthLong
                if (expected > 16L * 1024L * 1024L) return@execute
                val bytes = conn.inputStream.buffered(64 * 1024).use { input ->
                    val output = ByteArrayOutputStream(
                        when {
                            expected in 1..(4L * 1024L * 1024L) -> expected.toInt()
                            else -> 256 * 1024
                        }
                    )
                    val buffer = ByteArray(64 * 1024)
                    var total = 0
                    while (true) {
                        val read = input.read(buffer)
                        if (read <= 0) break
                        total += read
                        if (total > 16 * 1024 * 1024) return@execute
                        output.write(buffer, 0, read)
                    }
                    output.toByteArray()
                }
                if (bytes.isEmpty()) return@execute

                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                val maxSide = DeviceProfile.imageMaxSide(this)
                var sample = 1
                val side = maxOf(bounds.outWidth, bounds.outHeight)
                while (side / (sample * 2) >= maxSide) sample *= 2

                val opts = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565
                    inDither = true
                    inSampleSize = sample.coerceAtLeast(1)
                }
                var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return@execute
                val bigger = maxOf(bmp.width, bmp.height)
                if (bigger > maxSide) {
                    val ratio = maxSide.toFloat() / bigger.toFloat()
                    val scaled = Bitmap.createScaledBitmap(
                        bmp,
                        (bmp.width * ratio).toInt().coerceAtLeast(1),
                        (bmp.height * ratio).toInt().coerceAtLeast(1),
                        !lowEndDevice
                    )
                    if (scaled !== bmp) bmp = scaled
                }
                imageCache.put(finalUrl, bmp)
                delivered = true
                runOnUiThread {
                    if (target.tag == finalUrl && !bmp.isRecycled) {
                        stopPosterShimmer(target)
                        target.setImageBitmap(bmp)
                        onBitmap?.invoke(bmp)
                        if (!lowEndDevice && !isTvLike()) {
                            target.alpha = 0.82f
                            target.animate().cancel()
                            target.animate().alpha(1f).setDuration(135L).start()
                        } else {
                            target.alpha = 1f
                        }
                    }
                }
            } catch (_: OutOfMemoryError) {
                imageCache.evictAll()
            } catch (_: Throwable) {
            } finally {
                runCatching { conn?.disconnect() }
                if (!delivered) {
                    runOnUiThread {
                        if (target.tag == finalUrl) {
                            stopPosterShimmer(target, keepPlaceholder = true)
                            target.setBackgroundColor(Color.rgb(16, 23, 34))
                        }
                    }
                }
            }
        }
    }

    private fun animateExpandable(target: View, expand: Boolean, duration: Long = 230L) {
        target.animate().cancel()
        val lp = target.layoutParams ?: return
        if (lowEndDevice) {
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            target.layoutParams = lp
            target.alpha = 1f
            target.translationY = 0f
            target.visibility = if (expand) View.VISIBLE else View.GONE
            return
        }

        if (expand) {
            if (target.visibility == View.VISIBLE && target.height > 0) return
            lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
            target.layoutParams = lp
            target.visibility = View.INVISIBLE
            val parentWidth = ((target.parent as? View)?.width ?: resources.displayMetrics.widthPixels)
                .coerceAtLeast(dp(120))
            target.measure(
                View.MeasureSpec.makeMeasureSpec(parentWidth, View.MeasureSpec.AT_MOST),
                View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
            )
            val targetHeight = target.measuredHeight.coerceAtLeast(dp(1))
            lp.height = 0
            target.layoutParams = lp
            target.visibility = View.VISIBLE
            target.alpha = 0f
            target.translationY = -dp(5).toFloat()

            ValueAnimator.ofInt(0, targetHeight).apply {
                this.duration = duration
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener { animation ->
                    lp.height = animation.animatedValue as Int
                    target.layoutParams = lp
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        target.layoutParams = lp
                    }
                })
                start()
            }
            target.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration((duration * 0.82f).roundToInt().toLong())
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        } else {
            if (target.visibility != View.VISIBLE) return
            val startHeight = target.height.coerceAtLeast(dp(1))
            ValueAnimator.ofInt(startHeight, 0).apply {
                this.duration = (duration * 0.82f).roundToInt().toLong()
                interpolator = android.view.animation.AccelerateDecelerateInterpolator()
                addUpdateListener { animation ->
                    lp.height = animation.animatedValue as Int
                    target.layoutParams = lp
                }
                addListener(object : android.animation.AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: android.animation.Animator) {
                        target.visibility = View.GONE
                        target.alpha = 1f
                        target.translationY = 0f
                        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
                        target.layoutParams = lp
                    }
                })
                start()
            }
            target.animate()
                .alpha(0f)
                .translationY(-dp(3).toFloat())
                .setDuration((duration * 0.68f).roundToInt().toLong())
                .start()
        }
    }

    private fun alphaSurface(): Int = if (isLightTheme()) Color.rgb(255,255,255) else Color.rgb(13,13,15)
    private fun alphaSurface2(): Int = if (isLightTheme()) Color.rgb(245,246,249) else Color.rgb(22,22,25)
    private fun alphaLine(a: Int = 90): Int = if (isLightTheme()) Color.argb(a, 10, 12, 16) else Color.argb(a, 255, 255, 255)
    private fun alphaTextOnPrimary(): Int = if (currentScreen == "detail") Color.WHITE else if (isLightTheme()) Color.WHITE else Color.rgb(12, 12, 14)
    private fun alphaPrimary(): Int = if (currentScreen == "detail") Color.WHITE else if (isLightTheme()) Color.rgb(18, 20, 24) else Color.WHITE
    private fun alphaSecondaryText(): Int = if (currentScreen == "detail") Color.rgb(190, 194, 204) else if (isLightTheme()) Color.rgb(94, 96, 104) else Color.rgb(190, 194, 204)

    private fun imdbCompactBadge(score: String): View {
        val clean = cleanRating(score)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(255, 205, 35), Color.rgb(255, 190, 26))
            ).apply {
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.argb(150, 255, 224, 92))
            }
            setPadding(dp(9), 0, dp(9), 0)
            addView(TextView(this@MainActivity).apply {
                text = clean
                setTextColor(Color.rgb(18, 18, 18))
                textSize = 11.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-2, -1).apply { marginEnd = dp(8) })
            addView(TextView(this@MainActivity).apply {
                text = "IMDb"
                setTextColor(Color.BLACK)
                textSize = 12.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(2), 0, dp(2), 0)
            }, LinearLayout.LayoutParams(-2, -1))
        }
    }

    private fun alphaPill(label: String, active: Boolean = false): TextView {
        val clean = label.trim().ifBlank { return TextView(this) }
        val imdb = clean.startsWith("IMDb", ignoreCase = true)
        return TextView(this).apply {
            text = clean
            setTextColor(
                when {
                    imdb -> Color.rgb(20, 20, 20)
                    active -> alphaTextOnPrimary()
                    else -> if (isLightTheme() && currentScreen != "detail") Color.rgb(36, 38, 44) else Color.WHITE
                }
            )
            textSize = 12.0f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            minWidth = dp(48)
            background = when {
                imdb -> GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(255, 215, 72), Color.rgb(255, 184, 28))).apply {
                    cornerRadius = dp(17).toFloat()
                    setStroke(dp(1), Color.argb(150, 255, 235, 120))
                }
                active -> blueGradient(dp(17))
                else -> rounded(if (isLightTheme() && currentScreen != "detail") Color.rgb(246,247,250) else Color.argb(92, 18, 18, 22), dp(17), alphaLine(78))
            }
            setPadding(dp(13), 0, dp(13), 0)
        }
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun blueGradient(radius: Int): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(blue, blue2)
        ).apply {
            cornerRadius = radius.toFloat()
            setStroke(dp(1), UiPreferences.blend(blue2, Color.WHITE, 0.28f))
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        runCatching { imageExecutor.shutdownNow() }
        super.onDestroy()
    }

}
