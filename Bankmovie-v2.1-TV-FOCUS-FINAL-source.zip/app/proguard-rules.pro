-keep class org.videolan.** { *; }
-dontwarn org.videolan.**

-keep class ir.bankmoviee.app.InternalDownloadService { *; }
-keep class ir.bankmoviee.app.DownloadsActivity { *; }
