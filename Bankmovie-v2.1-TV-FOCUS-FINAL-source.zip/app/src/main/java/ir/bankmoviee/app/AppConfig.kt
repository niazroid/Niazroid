package ir.bankmoviee.app

object AppConfig {
    const val BASE_URL = "https://bankmoviee.ir/"
    const val ACCOUNT_API_URL = "https://bankmovie.top/app_user_api.php"
    const val GENRE_ASSET_BASE_URL = "https://bankmovie.top/assets/genres/"
    const val APP_SCHEME = "bankmoviee"
    const val PLAY_HOST = "play"
    const val USER_AGENT_SUFFIX = " BankMovieeAndroid/1.0"

    val TRUSTED_HOSTS = setOf(
        "bankmoviee.ir",
        "www.bankmoviee.ir",
        "bankmovie.top",
        "www.bankmovie.top"
    )

    val DIRECT_VIDEO_EXTENSIONS = listOf(
        ".mp4", ".mkv", ".m3u8", ".avi", ".mov", ".webm", ".ts"
    )

    val SUBTITLE_EXTENSIONS = listOf(
        ".srt", ".ass", ".ssa", ".vtt"
    )
}
