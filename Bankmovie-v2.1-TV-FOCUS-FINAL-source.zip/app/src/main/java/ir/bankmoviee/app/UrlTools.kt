package ir.bankmoviee.app

import android.net.Uri
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.Locale

object UrlTools {
    fun isHttpUrl(value: String?): Boolean {
        if (value.isNullOrBlank()) return false
        val lower = value.trim().lowercase(Locale.US)
        return lower.startsWith("http://") || lower.startsWith("https://")
    }

    fun isTrustedBankMovieeUrl(uri: Uri?): Boolean {
        val host = uri?.host?.lowercase(Locale.US) ?: return false
        return AppConfig.TRUSTED_HOSTS.contains(host)
    }

    fun isDirectVideoUrl(value: String?): Boolean {
        if (!isHttpUrl(value)) return false
        val clean = value!!.substringBefore('?').substringBefore('#').lowercase(Locale.US)
        return AppConfig.DIRECT_VIDEO_EXTENSIONS.any { clean.endsWith(it) }
    }

    fun isSubtitleUrl(value: String?): Boolean {
        if (!isHttpUrl(value)) return false
        val clean = value!!.substringBefore('?').substringBefore('#').lowercase(Locale.US)
        return AppConfig.SUBTITLE_EXTENSIONS.any { clean.endsWith(it) }
    }

    fun encode(value: String?): String = URLEncoder.encode(value.orEmpty(), StandardCharsets.UTF_8.name())

    fun buildPlayUri(videoUrl: String, title: String? = null, subtitleUrl: String? = null, referer: String? = null): Uri {
        val builder = Uri.Builder()
            .scheme(AppConfig.APP_SCHEME)
            .authority(AppConfig.PLAY_HOST)
            .appendQueryParameter("video", videoUrl)
        if (!title.isNullOrBlank()) builder.appendQueryParameter("title", title)
        if (!subtitleUrl.isNullOrBlank()) builder.appendQueryParameter("subtitle", subtitleUrl)
        if (!referer.isNullOrBlank()) builder.appendQueryParameter("referer", referer)
        return builder.build()
    }
}
