package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class PremiumLoaderView(context: Context) : View(context) {
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.argb(48, 255, 255, 255)
    }
    private val sparkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var rotation = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1350L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                rotation = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val stroke = size * 0.075f
        val radius = size * 0.34f
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)
        trackPaint.strokeWidth = stroke
        ringPaint.strokeWidth = stroke
        val accent = UiPreferences.accentColor(context)
        val accent2 = UiPreferences.blend(accent, Color.WHITE, 0.35f)
        ringPaint.shader = SweepGradient(cx, cy, intArrayOf(Color.TRANSPARENT, accent, accent2, Color.TRANSPARENT), floatArrayOf(0f, 0.30f, 0.72f, 1f))
        canvas.drawArc(rect, 0f, 360f, false, trackPaint)
        canvas.save()
        canvas.rotate(rotation, cx, cy)
        canvas.drawArc(rect, 20f, 285f, false, ringPaint)
        canvas.restore()

        sparkPaint.color = accent2
        for (i in 0 until 4) {
            val angle = Math.toRadians((rotation + i * 90f).toDouble())
            val rr = radius + stroke * (0.85f + i * 0.12f)
            val x = cx + cos(angle).toFloat() * rr
            val y = cy + sin(angle).toFloat() * rr
            sparkPaint.alpha = 150 - i * 24
            canvas.drawCircle(x, y, size * (0.018f + i * 0.002f), sparkPaint)
        }
        ringPaint.shader = null
    }
}
