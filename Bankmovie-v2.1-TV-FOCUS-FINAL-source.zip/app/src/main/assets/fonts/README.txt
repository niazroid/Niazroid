The optional Irancell subtitle font is injected at build time from the user's own password-protected archive.
Without it, the app safely falls back to the system subtitle font.
