#!/usr/bin/env bash
set -euo pipefail
FONT_ZIP="${1:-../irancell [@fontbazi].zip}"
TARGET="app/src/main/assets/fonts/irancell_regular.ttf"
mkdir -p "$(dirname "$TARGET")"
if [[ ! -f "$FONT_ZIP" ]]; then
  echo "Irancell font archive not found: $FONT_ZIP"
  echo "Build continues with system subtitle font fallback."
  exit 0
fi
unzip -P fontbazi -p "$FONT_ZIP" 'Irancell2*ttf' > "$TARGET"
if [[ ! -s "$TARGET" ]]; then
  rm -f "$TARGET"
  echo "Could not extract Irancell Regular; system font fallback will be used."
  exit 0
fi
echo "Irancell subtitle font prepared: $TARGET"
