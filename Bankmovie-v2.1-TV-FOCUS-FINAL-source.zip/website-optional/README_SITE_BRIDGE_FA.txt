این پوشه اختیاری است.

خود اپ اندروید بعد از باز شدن سایت، به صورت خودکار دکمه‌های پخش با کلاس arc1-play-btn را می‌گیرد و با پلیر Native VLC باز می‌کند.

اگر خواستی خود سایت هم برای مرورگر اندروید آماده باشد، فایل bankmoviee-native-bridge.js را داخل سایت آپلود کن و این خط را قبل از </body> بگذار:

<script src="/bankmoviee-native-bridge.js"></script>

برای لینک دستی هم می‌توانی این مدل بسازی:

<a href="bankmoviee://play?video=https%3A%2F%2Fexample.com%2Fmovie.mkv&subtitle=https%3A%2F%2Fexample.com%2Fsub.srt">پخش در اپ</a>
