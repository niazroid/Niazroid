/*
 * Optional site-side bridge for BankMoviee Android app.
 * The Android app already injects a bridge automatically, so this file is optional.
 * Add it to your site only if you want browser links to be ready for the APK too.
 */
(function () {
  if (window.__BankMovieeSiteNativeBridge) return;
  window.__BankMovieeSiteNativeBridge = true;

  function abs(url) {
    try { return new URL(url || '', location.href).href; } catch (e) { return url || ''; }
  }
  function enc(v) { return encodeURIComponent(v || ''); }
  function title() {
    var el = document.querySelector('.movie-title-fa,.movie-title-en,.movie-title,h1');
    return (el && el.textContent && el.textContent.trim()) || document.title || 'BankMoviee';
  }
  function isAndroid() { return /Android/i.test(navigator.userAgent || ''); }
  function isVideo(url) { return /^https?:\/\//i.test(url || '') && /\.(mp4|mkv|m3u8|avi|mov|webm|ts)(\?|#|$)/i.test(url); }

  document.addEventListener('click', function (e) {
    var btn = e.target && e.target.closest ? e.target.closest('.arc1-play-btn,[data-bm-native-play]') : null;
    if (!btn || !isAndroid()) return;
    var url = abs(btn.getAttribute('data-url') || btn.getAttribute('data-video') || btn.getAttribute('href') || '');
    if (!isVideo(url)) return;
    var subtitle = abs(btn.getAttribute('data-subtitle') || btn.getAttribute('data-sub') || btn.getAttribute('data-srt') || '');
    var deep = 'bankmoviee://play?video=' + enc(url)
      + '&title=' + enc(title())
      + '&subtitle=' + enc(subtitle)
      + '&referer=' + enc(location.href);
    location.href = deep;
    e.preventDefault();
    e.stopPropagation();
  }, true);
})();
