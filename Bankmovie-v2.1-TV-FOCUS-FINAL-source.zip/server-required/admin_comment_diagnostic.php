<?php
declare(strict_types=1);
@ini_set('display_errors','0');
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$u = $currentUser ?? null;
if (!$u && !empty($_COOKIE['session_token']) && isset($user) && is_object($user) && method_exists($user,'checkSession')) {
    try { $u = $user->checkSession((string)$_COOKIE['session_token']); } catch(Throwable $e) { $u = null; }
}
if (!is_array($u) || strtolower((string)($u['role'] ?? '')) !== 'admin') {
    http_response_code(403); exit('Admin only');
}
header('Content-Type: text/html; charset=utf-8');
function e($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function table_state(PDO $pdo,string $t):array{
    if(!preg_match('/^[A-Za-z0-9_]+$/',$t)) return ['exists'=>false,'error'=>'نام جدول نامعتبر است'];
    try{
        $s=$pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
        $s->execute([$t]);
        return ['exists'=>(bool)$s->fetchColumn(),'error'=>''];
    }catch(Throwable $e){
        return ['exists'=>false,'error'=>$e->getMessage()];
    }
}
function table_exists(PDO $pdo,string $t):bool{return (bool)(table_state($pdo,$t)['exists']??false);}
$tables=['comments','archive1_comments','comment_likes','archive1_comment_likes','archive1_items','comment_rate_limits'];
$databaseName='';
try { $databaseName=(string)$pdo->query('SELECT DATABASE()')->fetchColumn(); } catch(Throwable $e) {}
$currentHost=(string)($_SERVER['HTTP_HOST'] ?? '');
$remoteAccountApi='';
try {
    $cfgFile=__DIR__ . '/bankmovie_remote_config.json';
    if(is_file($cfgFile)) {
        $cfg=json_decode((string)file_get_contents($cfgFile),true);
        if(is_array($cfg)) $remoteAccountApi=(string)($cfg['account_api_url'] ?? '');
    }
} catch(Throwable $e) {}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>تشخیص کامنت اپ</title>
<style>body{background:#0b0d12;color:#eee;font-family:tahoma;padding:24px}.c{background:#151923;border:1px solid #2b3342;border-radius:16px;padding:18px;margin:12px 0}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #333;text-align:right}.ok{color:#51d88a}.bad{color:#ff6b6b}</style>
<h1>تشخیص کامنت‌های اپ و آرشیو ۱</h1>
<div class="c"><b>دامنه فعلی:</b> <?=e($currentHost)?> — <b>دیتابیس:</b> <?=e($databaseName ?: 'نامشخص')?> — <b>Account API:</b> <?=e($remoteAccountApi ?: 'بر اساس دامنه فعال')?></div>
<?php foreach($tables as $t): $state=table_state($pdo,$t); $exists=(bool)$state['exists']; ?>
<div class="c"><b><?=e($t)?></b> — <span class="<?=$exists?'ok':'bad'?>"><?=$exists?'موجود':'پیدا نشد'?></span>
<?php if($exists): try{$n=(int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();echo ' — تعداد: '.number_format($n);}catch(Throwable $x){echo ' — خطای شمارش: '.e($x->getMessage());}
elseif(!empty($state['error'])): echo ' — خطای تشخیص: '.e($state['error']); endif; ?></div>
<?php endforeach; ?>
<?php if(table_exists($pdo,'archive1_comments')):
$hasItems=table_exists($pdo,'archive1_items');
$join=$hasItems?' LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id ':'';
$select=$hasItems?",ai.archive_no,ai.slug,ai.item_link,ai.item_title_fa,ai.item_title,ai.item_year":"";
$rows=$pdo->query("SELECT c.id,c.movie_id,c.user_id,c.username,c.status,c.parent_id,c.created_at,LEFT(c.comment,120) comment{$select} FROM archive1_comments c {$join} ORDER BY c.id DESC LIMIT 80")->fetchAll(PDO::FETCH_ASSOC)?:[];
$statusRows=$pdo->query("SELECT CAST(status AS CHAR) status_value,COUNT(*) total FROM archive1_comments GROUP BY CAST(status AS CHAR) ORDER BY total DESC")->fetchAll(PDO::FETCH_ASSOC)?:[]; ?>
<div class="c"><h2>وضعیت‌های واقعی archive1_comments</h2><table><tr><th>مقدار status</th><th>تعداد</th><th>در سایت عمومی نمایش داده می‌شود؟</th></tr>
<?php foreach($statusRows as $sr): $sv=strtolower(trim((string)$sr['status_value'])); $public=in_array($sv,['approved','active','1'],true); ?><tr><td><?=e($sr['status_value'])?></td><td><?=number_format((int)$sr['total'])?></td><td class="<?=$public?'ok':'bad'?>"><?=$public?'بله':'خیر'?></td></tr><?php endforeach;?></table></div>
<div class="c"><h2>۸۰ کامنت آخر آرشیوهای خارجی و نگاشت صفحه</h2><table><tr><th>ID</th><th>movie_id</th><th>آرشیو/slug</th><th>عنوان/سال</th><th>کاربر</th><th>وضعیت</th><th>والد</th><th>زمان</th><th>متن</th></tr>
<?php foreach($rows as $r): $sv=strtolower(trim((string)$r['status'])); $public=in_array($sv,['approved','active','1'],true); ?><tr><td><?=e($r['id'])?></td><td><?=e($r['movie_id'])?></td><td><?=e(($r['archive_no']??'?').' / '.($r['slug']??'بدون نگاشت'))?><br><small><?=e($r['item_link']??'')?></small></td><td><?=e(($r['item_title_fa']??$r['item_title']??'').' '.($r['item_year']??''))?></td><td><?=e($r['username'])?></td><td class="<?=$public?'ok':'bad'?>"><?=e($r['status'])?></td><td><?=e($r['parent_id']??'NULL')?></td><td><?=e($r['created_at'])?></td><td><?=e($r['comment'])?></td></tr><?php endforeach;?></table></div>
<?php endif; ?></html>