Bankmovie V21 — Server Advanced Search
======================================

چهار فایل زیر را کنار bankmovie_remote_config.json روی سرور قرار بده:
- api5.php
- api5_lib.php
- archive1_live.php
- archive1_live_lib.php

آرشیو ۲ / SerialBlog:
api5.php?advanced=1&type=movie|series|all&s=&genre=درام&rating=7&order=newest&yearFrom=2020&yearTo=2026&country=United%20States&double=1&subtitle=1&page=1&limit=30

آرشیو ۱ / Oldtowns:
archive1_live.php?advanced=1&type=both|movie|series&s=&genre_id=49166&sortby=newest&rating=7&country_id=74924&dubbed=1&subtitle=1&year_from=2020&year_to=2026&page=1&limit=30

سرور از دامنه‌های تعریف‌شده در تنظیمات فعلی استفاده می‌کند و ساختار قبلی بخش دوبله و سریال چینی تغییر نکرده است.
