<?php
/**
 * app_api.php — API سبک مخصوص اپ اندروید BankMoviee
 * نسخه ۲.۱: تمرکز اصلی روی آرشیو ۱ + Boot/Slider/Collections/Pagination/Live Search
 *
 * Examples:
 *   app_api.php?action=ping
 *   app_api.php?action=home&archive=all
 *   app_api.php?action=section&archive=1&section=new_movies&page=1
 *   app_api.php?action=section&archive=3&section=new_series&page=1
 *   app_api.php?action=search&archive=all&q=from&type=series&page=1
 *   app_api.php?action=detail&archive=1&id=SERIES_OR_MOVIE_SLUG&type=series
 *   app_api.php?action=detail&archive=3&id=tt9813792
 *   app_api.php?action=play&archive=3&id=tt9813792
 */

@ini_set('display_errors', 0);
@ini_set('log_errors', 1);

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-BM-App-Key, X-BM-Ts, X-BM-Sign');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}


const BM_APP_AUTH_KEY = 'bm_android_v1_7c2f40';
const BM_APP_AUTH_SECRET = '9e1d4a7b3167f4c9b2d83f0a64e597f3d7f4b1a72638f90c6e2f2bd29d6aa8c1';
const BM_TEST_KEY = 'bm_test_archive2_fix29_2026';

function bm_app_header_value($name) {
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return isset($_SERVER[$key]) ? trim((string)$_SERVER[$key]) : '';
}

function bm_app_require_auth() {
    if (isset($_GET['bm_test_key']) && hash_equals(BM_TEST_KEY, (string)$_GET['bm_test_key'])) return;

    $key = bm_app_header_value('X-BM-App-Key');
    $ts = bm_app_header_value('X-BM-Ts');
    $sign = bm_app_header_value('X-BM-Sign');

    if (!hash_equals(BM_APP_AUTH_KEY, $key) || $ts === '' || $sign === '') {
        bm_app_json(array('status' => 'error', 'message' => 'Unauthorized'), 401);
    }

    $tsi = (int)$ts;
    if ($tsi < time() - 900 || $tsi > time() + 900) {
        bm_app_json(array('status' => 'error', 'message' => 'Expired request'), 401);
    }

    $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    $query = parse_url($uri, PHP_URL_QUERY);
    $pathQuery = $path . ($query ? ('?' . $query) : '');
    $expected = hash_hmac('sha256', $ts . '|' . $pathQuery, BM_APP_AUTH_SECRET);

    if (!hash_equals($expected, $sign)) {
        bm_app_json(array('status' => 'error', 'message' => 'Bad signature'), 401);
    }
}

bm_app_require_auth();

require_once __DIR__ . '/api2_lib.php';
require_once __DIR__ . '/api3_lib.php';
if (file_exists(__DIR__ . '/api5_lib.php')) require_once __DIR__ . '/api5_lib.php';

function bm_app_param($key, $default = '') {
    if (isset($_GET[$key])) return trim((string)$_GET[$key]);
    if (isset($_POST[$key])) return trim((string)$_POST[$key]);
    return $default;
}

function bm_app_int($key, $default = 1, $min = 1, $max = 1000) {
    $v = (int)bm_app_param($key, $default);
    if ($v < $min) $v = $min;
    if ($v > $max) $v = $max;
    return $v;
}

function bm_app_json($data, $code = 200) {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function bm_app_fail($message, $code = 400, $extra = array()) {
    bm_app_json(array_merge(array(
        'status' => 'error',
        'message' => $message
    ), $extra), $code);
}

function bm_app_base_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443);
    $scheme = $https ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '';
    $dir = rtrim(str_replace('\\', '/', dirname(isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '')), '/');
    if ($dir === '' || $dir === '.') $dir = '';
    return $host ? ($scheme . '://' . $host . $dir) : '';
}

function bm_app_poster($poster) {
    if (is_array($poster)) {
        if (!empty($poster['full'])) return bm_app_abs_asset($poster['full']);
        if (!empty($poster['medium'])) return bm_app_abs_asset($poster['medium']);
        if (!empty($poster['url'])) return bm_app_abs_asset($poster['url']);
        return '';
    }
    return bm_app_abs_asset((string)$poster);
}

function bm_app_rating_value($rating) {
    if (is_array($rating)) {
        if (isset($rating['imdb']) && is_numeric($rating['imdb'])) return (float)$rating['imdb'];
        if (isset($rating['value']) && is_numeric($rating['value'])) return (float)$rating['value'];
        return null;
    }
    return is_numeric($rating) ? (float)$rating : null;
}

function bm_app_norm_type($type) {
    $t = strtolower(trim((string)$type));
    if ($t === 'tv' || $t === 'tvseries') return 'series';
    if ($t === 'animation' || $t === 'animations') return 'anime';
    if ($t === '') return 'movie';
    return $t;
}

function bm_app_norm_audio_type($type, $label = '', $url = '') {
    // ترتیب تشخیص مهم است: لینک‌های SUB معمولاً عبارت Farsi.Sub دارند؛
    // پس اگر اول Farsi را دوبله حساب کنیم، همه زیرنویس‌ها اشتباه dub می‌شوند.
    $raw = trim((string)$type . ' ' . (string)$label . ' ' . (string)$url);
    $s = mb_strtolower(rawurldecode($raw), 'UTF-8');

    // مسیرهای رایج آرشیو ۱
    if (preg_match('~/(sub|subtitle|softsub|hardsub)/~i', $url)) return 'subtitle';
    if (preg_match('~/(dub|dubbed|farsi\.dubbed)/~i', $url)) return 'dub';

    // نام فایل‌ها و لیبل‌ها
    if (strpos($s, 'hard') !== false || strpos($s, 'hardsub') !== false || strpos($s, 'hard sub') !== false) return 'hardsub';
    if (strpos($s, 'softsub') !== false || strpos($s, 'soft sub') !== false) return 'subtitle';
    if (strpos($s, 'subtitle') !== false || strpos($s, '.sub.') !== false || strpos($s, ' sub.') !== false || strpos($s, 'زیرنویس') !== false) return 'subtitle';
    if (strpos($s, 'dubbed') !== false || strpos($s, '.dub.') !== false || strpos($s, ' dub.') !== false || strpos($s, 'دوبله') !== false) return 'dub';

    // Farsi به تنهایی معیار دوبله نیست؛ چون Farsi.Sub هم داریم.
    return 'subtitle';
}

function bm_app_quality_rank($q) {
    $q = strtolower((string)$q);
    if (strpos($q, '4k') !== false || strpos($q, '2160') !== false) return 60;
    if (strpos($q, '1080') !== false) return 50;
    if (strpos($q, '720') !== false) return 40;
    if (strpos($q, '480') !== false) return 30;
    if (strpos($q, '360') !== false) return 20;
    return 1;
}

function bm_app_local_url($archive, $id, $type = '') {
    $archive = (string)$archive;
    $id = (string)$id;
    if ($id === '') return '';
    $url = 'movie.php?arc=' . rawurlencode($archive) . '&slug=' . rawurlencode($id);
    if ($type !== '') $url .= '&type=' . rawurlencode($type);
    return $url;
}


function bm_app_first_nonempty($arr, $keys) {
    if (!is_array($arr)) return '';
    foreach ($keys as $k) {
        if (isset($arr[$k]) && trim((string)$arr[$k]) !== '') return trim((string)$arr[$k]);
    }
    return '';
}

function bm_app_archive1_page_base() {
    return defined('BASE_URL') ? rtrim((string)BASE_URL, '/') : 'https://www.oldtowns.top';
}

function bm_app_web_abs_url($url) {
    $url = trim(html_entity_decode((string)$url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($url === '') return '';
    if (strpos($url, '//') === 0) return 'https:' . $url;
    if (preg_match('~^https?://~i', $url)) return $url;
    if ($url[0] === '/') return bm_app_archive1_page_base() . $url;
    return bm_app_archive1_page_base() . '/' . ltrim($url, '/');
}

function bm_app_extract_backdrop_from_html($html) {
    $html = (string)$html;
    if ($html === '') return '';
    $candidates = array();

    if (preg_match_all('~<img\b[^>]*>~is', $html, $tags)) {
        foreach ($tags[0] as $tag) {
            if (!preg_match('~class=["\'][^"\']*(?:mb-coverimg|coverimg)[^"\']*["\']~i', $tag)) continue;
            if (preg_match('~\bsrc=["\']([^"\']+)["\']~i', $tag, $m)) $candidates[] = $m[1];
            if (preg_match('~\bdata-src=["\']([^"\']+)["\']~i', $tag, $m)) $candidates[] = $m[1];
        }
    }

    if (preg_match_all('~background(?:-image)?\s*:\s*url\((["\']?)([^)"\']+)\1\)~i', $html, $bg)) {
        foreach ($bg[2] as $u) {
            if (preg_match('~\.(webp|jpe?g|png)(?:[?#]|$)~i', $u)) $candidates[] = $u;
        }
    }

    foreach ($candidates as $u) {
        $abs = bm_app_web_abs_url($u);
        if ($abs !== '' && preg_match('~\.(webp|jpe?g|png)(?:[?#]|$)~i', $abs)) return $abs;
    }
    return '';
}

function bm_app_fill_archive1_backdrop($raw, $identifier = '', $type = '') {
    if (!is_array($raw)) return $raw;
    $existing = bm_app_first_nonempty($raw, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($existing !== '') return $raw;

    $urls = array();
    foreach (array('source_url','web_url','url','detail_url','canonical','page_url') as $k) {
        if (!empty($raw[$k])) $urls[] = (string)$raw[$k];
    }
    $identifier = trim((string)$identifier);
    if ($identifier !== '') {
        if (preg_match('~^https?://~i', $identifier)) {
            $urls[] = $identifier;
        } else {
            $clean = trim($identifier, '/');
            if ($clean !== '') {
                if (strpos($clean, '/') !== false) $urls[] = bm_app_archive1_page_base() . '/' . $clean . '/';
                if ($type === 'series') $urls[] = bm_app_archive1_page_base() . '/series/' . $clean . '/';
                $urls[] = bm_app_archive1_page_base() . '/' . $clean . '/';
            }
        }
    }

    $seen = array();
    foreach ($urls as $u) {
        $u = bm_app_web_abs_url($u);
        if ($u === '' || isset($seen[$u])) continue;
        $seen[$u] = true;
        try {
            $html = function_exists('getHtml') ? getHtml($u, 0) : @file_get_contents($u);
            $bg = bm_app_extract_backdrop_from_html($html);
            if ($bg !== '') {
                $raw['backdrop'] = $bg;
                $raw['backdrop_path'] = $bg;
                $raw['background'] = $bg;
                return $raw;
            }
        } catch (Throwable $e) {}
    }
    return $raw;
}


function bm_app_normalize_card($item, $archive) {
    $archive = (string)$archive;
    $id = (string)(isset($item['detail_id']) ? $item['detail_id'] : (isset($item['slug']) ? $item['slug'] : (isset($item['id']) ? $item['id'] : '')));
    $type = bm_app_norm_type(isset($item['type']) ? $item['type'] : 'movie');
    $title = (string)(isset($item['title']) ? $item['title'] : '');
    $titleFa = (string)(isset($item['title_fa']) ? $item['title_fa'] : (isset($item['full_title']) ? $item['full_title'] : ''));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $base = bm_app_base_url();
    $local = bm_app_local_url($archive, $id, $type);
    $backdropCandidate = bm_app_first_nonempty($item, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($backdropCandidate === '') $backdropCandidate = isset($item['image']) ? $item['image'] : (isset($item['poster']) ? bm_app_poster($item['poster']) : '');

    return array(
        'archive' => (int)$archive,
        'source' => $archive === '3' ? 'archive3' : ((string)$archive === '2' ? 'db_movies' : 'archive1'),
        'id' => $id,
        'slug' => $id,
        'source_slug' => $id,
        'comment_archive' => (int)$archive,
        'comment_identity' => $id,
        'imdb_code' => isset($item['imdb_code']) ? $item['imdb_code'] : null,
        'title' => $title,
        'title_fa' => $titleFa,
        'year' => isset($item['year']) ? $item['year'] : null,
        'type' => $type,
        'poster' => bm_app_poster(isset($item['poster']) ? $item['poster'] : (isset($item['image']) ? $item['image'] : (isset($item['cover_image']) ? $item['cover_image'] : ''))),
        'backdrop' => bm_app_abs_asset($backdropCandidate),
        'backdrop_path' => bm_app_abs_asset($backdropCandidate),
        'background' => bm_app_abs_asset($backdropCandidate),
        'rating' => bm_app_rating_value(isset($item['rating']) ? $item['rating'] : null),
        'genres' => isset($item['genres']) && is_array($item['genres']) ? array_values($item['genres']) : array(),
        'description' => isset($item['description']) ? $item['description'] : '',
        'update_note' => isset($item['update_note']) ? $item['update_note'] : (isset($item['note']) ? $item['note'] : ''),
        'has_dubbed' => bm_app_detect_dub_card($item),
        'has_subtitle' => bm_app_detect_sub_card($item),
        'has_online' => !empty($item['has_online']),
        'source_url' => isset($item['source_url']) ? $item['source_url'] : (isset($item['url']) ? $item['url'] : ''),
        'web_url' => $local,
        'web_url_abs' => $base ? ($base . '/' . $local) : $local,
        'api_detail' => 'app_api.php?action=detail&archive=' . rawurlencode($archive) . '&id=' . rawurlencode($id) . ($type ? '&type=' . rawurlencode($type) : ''),
        'api_play' => 'app_api.php?action=play&archive=' . rawurlencode($archive) . '&id=' . rawurlencode($id) . ($type ? '&type=' . rawurlencode($type) : '')
    );
}

function bm_app_normalize_download($dl) {
    $url = (string)(isset($dl['url']) ? $dl['url'] : bm_app_db_link_url($dl));
    $quality = (string)(isset($dl['quality']) ? $dl['quality'] : '');
    if ($quality === '' && preg_match('/(2160p|4K|1080p|720p|480p|360p)/i', $url, $m)) $quality = strtoupper($m[1]);
    $label = (string)(isset($dl['label']) ? $dl['label'] : '');
    $audioType = bm_app_norm_audio_type(isset($dl['type']) ? $dl['type'] : '', $label, $url);
    $looksPlayable = (bool)preg_match('~\.(mkv|mp4|avi|m3u8|mpd|mov|webm|ts)(?:[?#]|$)~i', $url);
    $isAudio = (bool)preg_match('~\.(mka|mp3|aac|m4a|ogg|wav|flac)(?:[?#]|$)~i', $url);
    $isHttp = (bool)preg_match('~^https?://~i', $url);
    $isFolder = !empty($dl['is_folder']) && (string)$dl['is_folder'] !== '0';
    $qualityOut = $quality !== '' ? strtoupper($quality) : 'Unknown';
    $typeFa = $audioType === 'dub' ? 'دوبله' : ($audioType === 'hardsub' ? 'هاردساب' : ($audioType === 'audio' ? 'صوت دوبله' : 'زیرنویس'));
    if ($isAudio) $typeFa = 'صوت دوبله';
    $season = isset($dl['season']) && $dl['season'] !== '' && $dl['season'] !== null ? (int)$dl['season'] : null;
    $episode = isset($dl['episode']) && $dl['episode'] !== '' && $dl['episode'] !== null ? (int)$dl['episode'] : null;
    $displayParts = array();
    if ($season !== null && $season > 0) $displayParts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $displayParts[] = 'قسمت ' . $episode;
    if ($qualityOut !== '') $displayParts[] = $qualityOut;
    $displayParts[] = $typeFa;
    return array(
        'label' => $label,
        'url' => $url,
        'quality' => $qualityOut,
        'type' => $audioType,
        'type_fa' => $typeFa,
        'display_label' => isset($dl['display_label']) && $dl['display_label'] !== '' ? (string)$dl['display_label'] : trim(implode(' • ', array_filter($displayParts))),
        'season' => $season,
        'episode' => $episode,
        'size' => isset($dl['size']) ? $dl['size'] : '',
        'is_direct' => $isHttp || $looksPlayable || $isAudio,
        'is_download' => $isHttp,
        'is_folder' => $isFolder,
        'is_playable' => $looksPlayable || $isAudio,
        'is_audio' => $isAudio || $audioType === 'audio'
    );
}


function bm_app_build_play_data($downloads) {
    $items = array();
    foreach ($downloads as $dl) {
        $n = bm_app_normalize_download($dl);
        if ($n['url'] === '') continue;
        $items[] = $n;
    }
    usort($items, function($a, $b) {
        $sa = $a['season'] === null ? 0 : (int)$a['season'];
        $sb = $b['season'] === null ? 0 : (int)$b['season'];
        if ($sa !== $sb) return $sa - $sb;
        $ea = $a['episode'] === null ? 0 : (int)$a['episode'];
        $eb = $b['episode'] === null ? 0 : (int)$b['episode'];
        if ($ea !== $eb) return $ea - $eb;
        return bm_app_quality_rank($b['quality']) - bm_app_quality_rank($a['quality']);
    });

    $seasonsMap = array();
    $movieLinks = array();
    foreach ($items as $n) {
        if ($n['season'] !== null || $n['episode'] !== null) {
            $s = $n['season'] !== null ? (string)$n['season'] : '1';
            $e = $n['episode'] !== null ? (string)$n['episode'] : '0';
            if (!isset($seasonsMap[$s])) $seasonsMap[$s] = array('season' => (int)$s, 'episodes' => array());
            if (!isset($seasonsMap[$s]['episodes'][$e])) $seasonsMap[$s]['episodes'][$e] = array('episode' => (int)$e, 'links' => array());
            $seasonsMap[$s]['episodes'][$e]['links'][] = $n;
        } else {
            $movieLinks[] = $n;
        }
    }

    $seasons = array_values($seasonsMap);
    foreach ($seasons as &$season) {
        ksort($season['episodes'], SORT_NATURAL);
        $season['episodes'] = array_values($season['episodes']);
    }
    unset($season);

    return array(
        'links' => $items,
        'movie_links' => $movieLinks,
        'seasons' => $seasons,
        'has_series_structure' => count($seasons) > 0
    );
}


function bm_app_abs_asset($path) {
    $path = trim((string)$path);
    if ($path === '') return '';
    if (preg_match('~^https?://~i', $path)) return $path;
    $base = bm_app_base_url();
    if ($base === '') return ltrim($path, '/');
    return $base . '/' . ltrim($path, '/');
}

function bm_app_existing_local_poster($imdb) {
    $imdb = trim((string)$imdb);
    if ($imdb === '') return '';
    $file = __DIR__ . '/posters/' . basename($imdb) . '.webp';
    return is_file($file) ? ('posters/' . basename($imdb) . '.webp') : '';
}

function bm_app_text_has($text, $needles) {
    $text = mb_strtolower((string)$text, 'UTF-8');
    foreach ($needles as $n) {
        if ($n !== '' && mb_strpos($text, mb_strtolower($n, 'UTF-8')) !== false) return true;
    }
    return false;
}

function bm_app_boolish($value) {
    if (is_bool($value)) return $value;
    $v = mb_strtolower(trim((string)$value), 'UTF-8');
    return in_array($v, array('1','true','yes','on','active','dubbed','subbed','دوبله','زیرنویس','زیرنویس فارسی'), true);
}

function bm_app_detect_dub_card($item) {
    $text = '';
    foreach (array('title','title_fa','full_title','update_note','note','source_url','url') as $k) {
        if (isset($item[$k])) $text .= ' ' . rawurldecode((string)$item[$k]);
    }
    if (!empty($item['has_dubbed']) || !empty($item['is_dubbed']) || !empty($item['dubbed'])) return true;
    return bm_app_text_has($text, array('farsi-dubbed','farsi.dubbed','dubbed','دوبله'));
}

function bm_app_detect_sub_card($item) {
    $text = '';
    foreach (array('title','title_fa','full_title','update_note','note','source_url','url') as $k) {
        if (isset($item[$k])) $text .= ' ' . rawurldecode((string)$item[$k]);
    }
    if (!empty($item['has_subtitle']) || !empty($item['has_sub']) || !empty($item['subtitle'])) return true;
    return bm_app_text_has($text, array('subtitle','softsub','hardsub','subbed','زیرنویس'));
}

function bm_app_normalize_actor($actor) {
    if (is_array($actor)) {
        $name = trim((string)($actor['name'] ?? $actor['title'] ?? $actor['full_name'] ?? ''));
        if ($name === '' || $name[0] === '{') return null;
        return array(
            'name' => $name,
            'role' => trim((string)($actor['role'] ?? $actor['character'] ?? '')),
            'image' => bm_app_abs_asset($actor['image'] ?? $actor['poster'] ?? $actor['avatar'] ?? ''),
            'url' => bm_app_abs_asset($actor['url'] ?? ''),
            'slug' => trim((string)($actor['slug'] ?? '')),
            'bankmovie_url' => isset($actor['bankmovie_url']) ? (string)$actor['bankmovie_url'] : ''
        );
    }
    $name = trim((string)$actor);
    if ($name === '' || $name[0] === '{') return null;
    return array('name' => $name, 'role' => '', 'image' => '', 'url' => '', 'slug' => '', 'bankmovie_url' => '');
}

function bm_app_normalize_actors($actors) {
    if (!is_array($actors)) return array();
    $out = array();
    $seen = array();
    foreach ($actors as $a) {
        $n = bm_app_normalize_actor($a);
        if (!$n) continue;
        $key = mb_strtolower($n['name'], 'UTF-8');
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $n;
    }
    return $out;
}

function bm_app_pdo() {
    static $loaded = false;
    static $selected = false;
    global $pdo;
    if (!$loaded) {
        $loaded = true;
        $cfg = __DIR__ . '/config.php';
        if (file_exists($cfg)) @require_once $cfg;
    }
    if (!(isset($pdo) && $pdo instanceof PDO)) return null;

    // ریشه مشکل لینک‌ها: app_api گاهی با دیتابیس اشتباه بالا می‌آید؛
    // سایت movie.php با دیتابیس آرشیو ۲ کار می‌کند که جدول‌های movies/softsub_links/dubbed_links دارد.
    // اینجا همان دیتابیس محتوا را خودکار پیدا می‌کنیم و برای کل request روی همان USE می‌زنیم.
    if (!$selected) {
        $selected = true;
        $preferred = defined('BM_CONTENT_DATABASE') ? (string)BM_CONTENT_DATABASE : 'niazroid_bankmovie1';
        try { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); } catch (Throwable $e) {}
        try { $pdo->exec("SET NAMES utf8mb4"); } catch (Throwable $e) {}

        $currentOk = false;
        try {
            $stmt = $pdo->query("SELECT DATABASE()");
            $currentDb = (string)$stmt->fetchColumn();
            if ($currentDb !== '') {
                $q = $pdo->prepare("SELECT COUNT(DISTINCT TABLE_NAME) FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME IN ('movies','softsub_links','dubbed_links','collection_movies')");
                $q->execute(array($currentDb));
                $currentOk = ((int)$q->fetchColumn() >= 3);
            }
        } catch (Throwable $e) { $currentOk = false; }

        if (!$currentOk) {
            $target = '';
            try {
                $q = $pdo->prepare("SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ? LIMIT 1");
                $q->execute(array($preferred));
                if ($q->fetchColumn()) $target = $preferred;
            } catch (Throwable $e) {}

            if ($target === '') {
                try {
                    $sql = "SELECT TABLE_SCHEMA,
                                   SUM(TABLE_NAME='movies') AS has_movies,
                                   SUM(TABLE_NAME='softsub_links') AS has_soft,
                                   SUM(TABLE_NAME='dubbed_links') AS has_dub,
                                   SUM(TABLE_NAME='collection_movies') AS has_col
                            FROM information_schema.TABLES
                            WHERE TABLE_NAME IN ('movies','softsub_links','dubbed_links','collection_movies')
                            GROUP BY TABLE_SCHEMA
                            HAVING has_movies > 0 AND (has_soft > 0 OR has_dub > 0 OR has_col > 0)
                            ORDER BY (TABLE_SCHEMA = 'niazroid_bankmovie1') DESC,
                                     (TABLE_SCHEMA LIKE '%bankmovie%') DESC,
                                     (has_soft + has_dub + has_col) DESC
                            LIMIT 1";
                    $row = $pdo->query($sql)->fetch(PDO::FETCH_ASSOC);
                    if ($row && !empty($row['TABLE_SCHEMA'])) $target = (string)$row['TABLE_SCHEMA'];
                } catch (Throwable $e) {}
            }

            if ($target !== '') {
                try { $pdo->exec('USE `' . str_replace('`','``',$target) . '`'); } catch (Throwable $e) {}
            }
        }
    }
    return $pdo;
}


function bm_app_is_serialblog_archive($archive) {
    return in_array((string)$archive, array('4','serialblog','archive2','sb'), true);
}

function bm_app_serialblog_section_name($section) {
    $s = trim((string)$section);
    $map = array(
        'updated_movies' => 'new_movies',
        'new_movies' => 'new_movies',
        'movies' => 'new_movies',
        'movie' => 'new_movies',
        'updated_series' => 'new_series',
        'new_series' => 'new_series',
        'series' => 'new_series',
        'home' => 'home',
        'dubbed' => 'dubbed',
        'subtitled' => 'subtitled'
    );
    return isset($map[$s]) ? $map[$s] : $s;
}

function bm_app_serialblog_norm_item($m) {
    if (!is_array($m)) return null;
    $id = '';
    foreach (array('id','slug') as $k) {
        if (!empty($m[$k])) { $id = (string)$m[$k]; break; }
    }
    if ($id === '' && !empty($m['url']) && function_exists('serialblog_slug_from_url')) $id = serialblog_slug_from_url($m['url']);
    $title = (string)($m['title_fa'] ?? ($m['title'] ?? ($m['title_en'] ?? '')));
    if ($id === '' && $title === '') return null;
    $type = bm_app_norm_type((string)($m['type'] ?? 'movie'));
    if ($type !== 'series') $type = 'movie';
    $rating = $m['rating'] ?? ($m['imdb'] ?? '');
    $poster = bm_app_abs_asset((string)($m['poster'] ?? ($m['image'] ?? '')));
    $bg = bm_app_abs_asset((string)($m['backdrop'] ?? ($m['background'] ?? $poster)));
    return array(
        'archive' => 4,
        'source' => 'serialblog',
        'id' => $id,
        'slug' => $id,
        'movie_id' => $id,
        'type' => $type,
        'title' => (string)($m['title_en'] ?? ($m['title'] ?? $title)),
        'title_fa' => $title,
        'year' => (string)($m['year'] ?? ($m['release_year'] ?? '')),
        'poster' => $poster,
        'image' => $poster,
        'cover_image' => $poster,
        'backdrop' => $bg,
        'backdrop_path' => $bg,
        'background' => $bg,
        'imdb' => is_numeric($rating) ? (string)$rating : '',
        'rating' => $rating,
        'imdb_id' => (string)($m['imdb_id'] ?? ''),
        'genres' => isset($m['genres']) && is_array($m['genres']) ? array_values($m['genres']) : array(),
        'description' => (string)($m['description'] ?? ($m['plot'] ?? '')),
        'plot' => (string)($m['description'] ?? ($m['plot'] ?? '')),
        'url' => (string)($m['url'] ?? ($m['source_url'] ?? '')),
        'source_url' => (string)($m['source_url'] ?? ($m['url'] ?? '')),
        'has_dubbed' => !empty($m['has_dubbed']),
        'has_subtitle' => !empty($m['has_subtitle'])
    );
}

function bm_app_serialblog_norm_listing($raw, $page, $limit) {
    $items = array();
    $sourceItems = array();
    if (isset($raw['items']) && is_array($raw['items'])) $sourceItems = $raw['items'];
    elseif (isset($raw['movies']) && is_array($raw['movies'])) $sourceItems = $raw['movies'];
    foreach ($sourceItems as $m) {
        $n = bm_app_serialblog_norm_item($m);
        if ($n) $items[] = $n;
    }
    $hasMore = !empty($raw['has_more']) || !empty($raw['has_next_page']) || ((int)($raw['next_page'] ?? 0) > (int)$page);
    $next = isset($raw['next_page']) && (int)$raw['next_page'] > (int)$page ? (int)$raw['next_page'] : ($hasMore ? ((int)$page + 1) : null);
    return array(
        'archive' => 4,
        'source' => 'serialblog',
        'page' => (int)$page,
        'count' => count($items),
        'total' => (int)($raw['total'] ?? ($raw['total_count'] ?? count($items))),
        'total_count' => (int)($raw['total_count'] ?? ($raw['total'] ?? count($items))),
        'has_more' => $hasMore,
        'next_page' => $next,
        'items' => $items,
        'movies' => $items,
        'request_url' => (string)($raw['request_url'] ?? '')
    );
}

function bm_app_serialblog_link($d) {
    if (!is_array($d)) return null;
    $url = (string)($d['url'] ?? ($d['href'] ?? ''));
    if ($url === '') return null;
    $quality = (string)($d['quality'] ?? '');
    $label = (string)($d['label'] ?? ($d['title'] ?? ($d['text'] ?? '')));
    $type = (string)($d['type'] ?? '');
    $typeFa = (string)($d['type_fa'] ?? '');
    if ($typeFa === '') {
        if ($type === 'dubbed') $typeFa = 'دوبله فارسی';
        elseif (in_array($type, array('softsub','hardsub','subtitle'), true)) $typeFa = 'زیرنویس فارسی';
        else $typeFa = 'لینک دانلود';
    }
    return array(
        'url' => $url,
        'quality' => $quality,
        'label' => $label,
        'display_label' => trim(($quality !== '' ? $quality : $label) . ' • ' . $typeFa),
        'type' => $type,
        'type_fa' => $typeFa,
        'version' => (string)($d['version'] ?? ''),
        'size' => (string)($d['size'] ?? ''),
        'season' => isset($d['season']) && $d['season'] !== null ? (int)$d['season'] : 0,
        'episode' => isset($d['episode']) && $d['episode'] !== null ? (int)$d['episode'] : 0,
        'is_direct' => true,
        'source' => 'serialblog'
    );
}

function bm_app_serialblog_detail($identifier, $type = '') {
    if (!function_exists('serialblog_get_details')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_get_details($identifier, $type);
    $movie = bm_app_serialblog_norm_item($raw['item'] ?? ($raw['movie'] ?? array()));
    if (!$movie) bm_app_fail('جزئیات آرشیو ۲ پیدا نشد', 404);
    $links = array();
    foreach (($raw['downloads'] ?? array()) as $d) {
        $l = bm_app_serialblog_link($d);
        if ($l) $links[] = $l;
    }
    $movie['downloads'] = $links;
    $movie['links'] = $links;
    $movie['play'] = array('links' => $links);
    return $movie;
}

function bm_app_serialblog_section($section, $page, $limit) {
    if (!function_exists('serialblog_get_section')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_get_section(bm_app_serialblog_section_name($section), $page);
    return bm_app_serialblog_norm_listing($raw, $page, $limit);
}

function bm_app_serialblog_search($q, $type, $page, $limit) {
    if (!function_exists('serialblog_search')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_search(array('s' => $q, 'type' => $type, 'page' => $page));
    $res = bm_app_serialblog_norm_listing($raw, $page, $limit);
    if ($type === 'movie' || $type === 'series') {
        $filtered = array();
        foreach ($res['items'] as $it) {
            if (($type === 'series' && $it['type'] === 'series') || ($type === 'movie' && $it['type'] !== 'series')) $filtered[] = $it;
        }
        $res['items'] = $filtered;
        $res['movies'] = $filtered;
        $res['count'] = count($filtered);
    }
    return $res;
}

function bm_app_current_database_name() {
    $pdo = bm_app_pdo();
    if (!$pdo) return '';
    try { return (string)$pdo->query("SELECT DATABASE()")->fetchColumn(); } catch (Throwable $e) { return ''; }
}

function bm_app_slider_target($link) {
    $link = trim((string)$link);
    $out = array('target_archive'=>1, 'target_id'=>'', 'target_type'=>'movie', 'api_detail'=>'', 'api_play'=>'');
    if ($link === '') return $out;
    $parts = @parse_url($link);
    $query = array();
    if (!empty($parts['query'])) parse_str($parts['query'], $query);
    if (!empty($query['arc'])) $out['target_archive'] = (int)$query['arc'];
    if (!empty($query['type'])) $out['target_type'] = bm_app_norm_type($query['type']);
    if (!empty($query['slug'])) $out['target_id'] = (string)$query['slug'];
    if (!empty($query['imdb'])) $out['target_id'] = (string)$query['imdb'];

    $path = rawurldecode((string)($parts['path'] ?? $link));
    if ($out['target_id'] === '') {
        if (preg_match('~/movie/arc1-([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 1;
            $out['target_id'] = $m[1];
        } elseif (preg_match('~/movie/([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 1;
            $out['target_id'] = $m[1];
        }
    }
    if ($out['target_id'] !== '') {
        $out['api_detail'] = 'app_api.php?action=detail&archive=' . rawurlencode((string)$out['target_archive']) . '&id=' . rawurlencode($out['target_id']) . '&type=' . rawurlencode($out['target_type']);
        $out['api_play'] = 'app_api.php?action=play&archive=' . rawurlencode((string)$out['target_archive']) . '&id=' . rawurlencode($out['target_id']) . '&type=' . rawurlencode($out['target_type']);
    }
    return $out;
}

function bm_app_normalize_slider($row) {
    $link = (string)($row['link'] ?? '');
    $target = bm_app_slider_target($link);
    return array_merge(array(
        'id' => (int)($row['id'] ?? 0),
        'title_fa' => (string)($row['title_fa'] ?? ''),
        'title' => (string)($row['title_en'] ?? ($row['title_fa'] ?? '')),
        'subtitle_fa' => (string)($row['subtitle_fa'] ?? ''),
        'subtitle' => (string)($row['subtitle_en'] ?? ''),
        'image' => bm_app_abs_asset($row['image_path'] ?? $row['image'] ?? ''),
        'link' => $link,
        'link_abs' => bm_app_abs_asset($link),
        'rating' => isset($row['rating']) ? round((float)$row['rating'], 1) : null,
        'votes' => (string)($row['votes'] ?? ''),
        'order' => (int)($row['slide_order'] ?? 0)
    ), $target);
}

function bm_app_sliders($limit = 12) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    try {
        $limit = max(1, min(30, (int)$limit));
        $sql = "SELECT * FROM slider_slides WHERE is_active = 1 ORDER BY slide_order DESC, id DESC LIMIT " . $limit;
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        return array_map('bm_app_normalize_slider', $rows ?: array());
    } catch (Throwable $e) {
        return array();
    }
}

function bm_app_normalize_collection($row) {
    $slug = (string)($row['slug'] ?? '');
    return array(
        'id' => (int)($row['id'] ?? 0),
        'slug' => $slug,
        'title_fa' => (string)($row['title_fa'] ?? ($row['title'] ?? '')),
        'title' => (string)($row['title'] ?? ($row['title_fa'] ?? '')),
        'description' => (string)($row['description'] ?? ''),
        'cover_image' => bm_app_abs_asset($row['cover_image'] ?? ''),
        'movie_count' => (int)($row['movie_count'] ?? 0),
        'first_year' => $row['first_year'] ?? null,
        'last_year' => $row['last_year'] ?? null,
        'web_url' => '/collection?slug=' . rawurlencode($slug),
        'api_items' => 'app_api.php?action=collection&slug=' . rawurlencode($slug)
    );
}

function bm_app_collections($page = 1, $limit = 12) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array('page'=>(int)$page,'limit'=>(int)$limit,'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array());
    $page = max(1, (int)$page); $limit = max(1, min(40, (int)$limit)); $offset = ($page - 1) * $limit;
    try {
        $sql = "SELECT c.*, COUNT(cm.id) AS movie_count, MIN(m.year) AS first_year, MAX(m.year) AS last_year
                FROM collections c
                LEFT JOIN collection_movies cm ON c.id = cm.collection_id
                LEFT JOIN movies m ON cm.movie_id = m.id
                WHERE c.status = 1
                GROUP BY c.id
                ORDER BY c.id DESC
                LIMIT $limit OFFSET $offset";
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $items = array_map('bm_app_normalize_collection', $rows ?: array());
        return array('page'=>$page,'limit'=>$limit,'count'=>count($items),'has_more'=>count($items)===$limit,'next_page'=>count($items)===$limit?$page+1:null,'items'=>$items);
    } catch (Throwable $e) {
        return array('page'=>$page,'limit'=>$limit,'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array(),'debug_error'=>$e->getMessage());
    }
}

function bm_app_extract_slug_from_url($url) {
    $url = trim((string)$url);
    if ($url === '') return '';
    $path = trim((string)(parse_url($url, PHP_URL_PATH) ?: ''), '/');
    if ($path === '') return '';
    $parts = array_values(array_filter(explode('/', $path), 'strlen'));
    if (empty($parts)) return '';
    if ($parts[0] === 'series' && !empty($parts[1])) return 'series/' . end($parts);
    if (ctype_digit($parts[0]) && count($parts) >= 2) return $parts[0] . '/' . end($parts);
    return end($parts);
}

function bm_app_normalize_db_movie($m) {
    $dbId = (int)($m['id'] ?? 0);
    $imdb = trim((string)($m['imdb_code'] ?? $m['imdb'] ?? ''));
    $sourceUrl = trim((string)($m['source_url'] ?? $m['url'] ?? $m['detail_url'] ?? $m['page_url'] ?? ''));
    $slug = trim((string)($m['detail_id'] ?? $m['source_slug'] ?? $m['slug'] ?? ''));
    if ($slug === '') $slug = bm_app_extract_slug_from_url($sourceUrl);
    $poster = (string)($m['poster'] ?? $m['image'] ?? '');
    if ($poster === '' && $imdb !== '') $poster = 'posters/' . $imdb . '.webp';
    $type = bm_app_norm_type($m['type'] ?? 'movie');
    $id = $dbId > 0 ? (string)$dbId : ($slug !== '' ? $slug : ($imdb !== '' ? $imdb : ''));
    $titleFa = (string)($m['title_fa'] ?? $m['title'] ?? '');
    $title = (string)($m['title'] ?? $titleFa);
    $text = implode(' ', array_map('strval', $m));
    return array(
        'archive' => 2,
        'source' => 'db_movies',
        'id' => $id,
        'db_id' => $dbId,
        'slug' => $slug,
        'source_slug' => $slug,
        'imdb_code' => $imdb ?: null,
        'title' => $title,
        'title_fa' => $titleFa,
        'year' => $m['year'] ?? null,
        'type' => $type,
        'poster' => bm_app_abs_asset($poster),
        'backdrop' => bm_app_abs_asset($m['backdrop'] ?? ''),
        'rating' => isset($m['imdb_rate']) && is_numeric($m['imdb_rate']) ? (float)$m['imdb_rate'] : (isset($m['rating']) && is_numeric($m['rating']) ? (float)$m['rating'] : null),
        'genres' => !empty($m['genres']) ? array_values(array_filter(array_map('trim', preg_split('/[,،]+/u', (string)$m['genres'])))) : array(),
        'description' => (string)($m['description_fa'] ?? $m['description'] ?? ''),
        'update_note' => (string)($m['update_note'] ?? ''),
        'has_dubbed' => bm_app_detect_dub_card($m) || bm_app_text_has($text, array('دوبله','dubbed')),
        'has_subtitle' => bm_app_detect_sub_card($m) || bm_app_text_has($text, array('زیرنویس','subtitle','subbed')),
        'source_url' => $sourceUrl,
        'web_url' => bm_app_local_url(2, $id, $type),
        'web_url_abs' => bm_app_abs_asset(bm_app_local_url(2, $id, $type)),
        'api_detail' => 'app_api.php?action=detail&archive=2&id=' . rawurlencode($id) . '&type=' . rawurlencode($type)
    );
}

function bm_app_collection_items($slugOrId, $page = 1, $limit = 24, $sort = 'default') {
    $pdo = bm_app_pdo();
    if (!$pdo) bm_app_fail('اتصال دیتابیس برای کالکشن آماده نیست', 500);
    $page = max(1, (int)$page); $limit = max(1, min(60, (int)$limit)); $offset = ($page - 1) * $limit;
    $where = ctype_digit((string)$slugOrId) ? 'id = ?' : 'slug = ?';
    $stmt = $pdo->prepare("SELECT * FROM collections WHERE $where AND status = 1 LIMIT 1");
    $stmt->execute(array($slugOrId));
    $collection = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$collection) bm_app_fail('کالکشن پیدا نشد', 404);
    $orderSql = 'ORDER BY cm.sort_order ASC, m.year ASC, m.id ASC';
    if ($sort === 'newest') $orderSql = 'ORDER BY m.year DESC, m.id DESC';
    if ($sort === 'oldest') $orderSql = 'ORDER BY m.year ASC, m.id ASC';
    $sql = "SELECT m.*, cm.sort_order, cm.movie_id AS collection_movie_id
            FROM collection_movies cm
            JOIN movies m ON cm.movie_id = m.id
            WHERE cm.collection_id = ?
            $orderSql
            LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array((int)$collection['id']));
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    $items = array();
    foreach ($rows as $r) {
        $card = bm_app_normalize_db_movie($r);
        $dbId = (int)($r['id'] ?? $r['collection_movie_id'] ?? 0);
        if ($dbId > 0) {
            $card['id'] = (string)$dbId;
            $card['db_id'] = $dbId;
            $card['movie_id'] = $dbId;
            $card['archive'] = 2;
            $card['source'] = 'db_movies';
            $card['api_detail'] = 'app_api.php?action=detail&archive=2&id=' . rawurlencode((string)$dbId) . '&type=' . rawurlencode($card['type']);
        }
        $items[] = $card;
    }
    return array('collection'=>bm_app_normalize_collection($collection),'page'=>$page,'limit'=>$limit,'count'=>count($items),'has_more'=>count($items)===$limit,'next_page'=>count($items)===$limit?$page+1:null,'items'=>$items);
}


function bm_app_normalize_detail($data, $archive) {
    $archive = (string)$archive;
    $id = (string)(isset($data['id']) ? $data['id'] : (isset($data['slug']) ? $data['slug'] : ''));
    $type = bm_app_norm_type(isset($data['type']) ? $data['type'] : 'movie');
    $title = (string)(isset($data['title']) ? $data['title'] : '');
    $titleFa = (string)(isset($data['title_fa']) ? $data['title_fa'] : (isset($data['full_title']) ? $data['full_title'] : ''));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $downloads = array();
    foreach (array('downloads','links','download_links','downloadLinks','dubbed_links','softsub_links','hardsub_links','audio_links','play_links') as $dk) {
        if (isset($data[$dk]) && is_array($data[$dk])) {
            foreach ($data[$dk] as $dl) if (is_array($dl)) $downloads[] = $dl;
        }
    }
    $play = bm_app_build_play_data($downloads);
    $base = bm_app_base_url();
    $local = bm_app_local_url($archive, $id, $type);
    $backdropCandidate = bm_app_first_nonempty($data, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($backdropCandidate === '') $backdropCandidate = isset($data['image']) && $data['image'] !== '' ? $data['image'] : (isset($data['poster']) ? $data['poster'] : ((isset($data['imdb_code']) && $data['imdb_code'] !== '') ? bm_app_existing_local_poster($data['imdb_code']) : ''));

    return array(
        'archive' => (int)$archive,
        'source' => $archive === '3' ? 'archive3' : ((string)$archive === '2' ? 'db_movies' : 'archive1'),
        'id' => $id,
        'slug' => $id,
        'source_slug' => $id,
        'comment_archive' => (int)$archive,
        'comment_identity' => $id,
        'imdb_code' => isset($data['imdb_code']) ? $data['imdb_code'] : null,
        'title' => $title,
        'title_fa' => $titleFa,
        'full_title' => isset($data['full_title']) ? $data['full_title'] : $titleFa,
        'year' => isset($data['year']) ? $data['year'] : null,
        'type' => $type,
        'poster' => bm_app_poster(isset($data['poster']) && $data['poster'] !== '' ? $data['poster'] : (isset($data['image']) && $data['image'] !== '' ? $data['image'] : ((isset($data['imdb_code']) && $data['imdb_code'] !== '') ? bm_app_existing_local_poster($data['imdb_code']) : ''))),
        'backdrop' => bm_app_abs_asset($backdropCandidate),
        'backdrop_path' => bm_app_abs_asset($backdropCandidate),
        'background' => bm_app_abs_asset($backdropCandidate),
        'rating' => bm_app_rating_value(isset($data['rating']) ? $data['rating'] : null),
        'score' => isset($data['score']) ? $data['score'] : null,
        'runtime' => isset($data['runtime']) ? $data['runtime'] : (isset($data['duration']) ? $data['duration'] : ''),
        'age_rate' => isset($data['age_rate']) ? $data['age_rate'] : (isset($data['rated']) ? $data['rated'] : ''),
        'country' => isset($data['country']) ? $data['country'] : (isset($data['countries']) ? $data['countries'] : array()),
        'genres' => isset($data['genres']) && is_array($data['genres']) ? array_values($data['genres']) : array(),
        'description' => isset($data['description']) ? $data['description'] : '',
        'long_description' => isset($data['long_description']) ? $data['long_description'] : '',
        'actors' => bm_app_normalize_actors(isset($data['actors']) ? $data['actors'] : (isset($data['cast']) ? $data['cast'] : array())),
        'directors' => bm_app_normalize_actors(isset($data['directors']) ? $data['directors'] : array()),
        'trailer' => isset($data['trailer']) ? $data['trailer'] : (isset($data['trailer_url']) ? $data['trailer_url'] : ''),
        'trailer_url' => isset($data['trailer']) ? $data['trailer'] : (isset($data['trailer_url']) ? $data['trailer_url'] : ''),
        'has_dubbed' => !empty($data['has_dubbed']) || bm_app_play_has_type($play, 'dub'),
        'has_subtitle' => !empty($data['has_subtitle']) || bm_app_play_has_sub($play),
        'has_online' => !empty($data['has_online']) || count($play['links']) > 0,
        'source_url' => isset($data['source_url']) ? $data['source_url'] : (isset($data['url']) ? $data['url'] : ''),
        'web_url' => $local,
        'web_url_abs' => $base ? ($base . '/' . $local) : $local,
        'downloads_count' => count($play['links']),
        'links' => $play['links'],
        'downloads' => $play['links'],
        'play' => $play,
        'related' => bm_app_normalize_related(isset($data['related_movies']) ? $data['related_movies'] : (isset($data['related']) ? $data['related'] : array()), $archive)
    );
}

function bm_app_play_has_type($play, $type) {
    foreach ($play['links'] as $l) if ($l['type'] === $type) return true;
    return false;
}

function bm_app_play_has_sub($play) {
    foreach ($play['links'] as $l) if ($l['type'] === 'subtitle' || $l['type'] === 'hardsub') return true;
    return false;
}

function bm_app_normalize_related($items, $archive) {
    if (!is_array($items)) return array();
    $out = array();
    foreach ($items as $it) {
        if (is_array($it)) $out[] = bm_app_normalize_card($it, $archive);
    }
    return $out;
}

function bm_app_archive1_section($section, $page) {
    $section = strtolower(trim((string)$section));
    $mapUpdatedMovies = array('updated_movies','new_movies','movie','movies','films_updated','updated-movies');
    $mapUpdatedSeries = array('updated_series','new_series','series','tv','series_updated','updated-series');
    if (in_array($section, $mapUpdatedMovies, true)) return getUpdatedList('movie', $page);
    if (in_array($section, $mapUpdatedSeries, true)) return getUpdatedList('series', $page);
    if ($section === 'anime' || $section === 'animation' || $section === 'animations') return getCategoryList('anime', $page);
    if ($section === 'turkish' || $section === 'turkey' || $section === 'turkish_series') return getCategoryList('turkish', $page);
    // Server-side fix only: existing app versions keep using the same endpoint.
    // All common dubbed aliases are routed to the corrected Archive 1 carousel.
    if (in_array($section, array('dubbed','dubbed-fa','persian_dubbed','persian-dubbed','dubbed_movies','dubbed-movies'), true)) return getDubbedMoviesList($page);
    if ($section === 'top_2026' || $section === 'top-2026') return getTop2026MoviesList($page);
    if ($section === 'archive_movies') return getArchiveList('movie', $page);
    if ($section === 'archive_series') return getArchiveList('series', $page);
    return getUpdatedList('movie', $page);
}

function bm_app_archive3_section($section, $page) {
    $section = trim((string)$section);
    if ($section === 'series' || $section === 'updated_series') $section = 'new_series';
    if ($section === 'movie' || $section === 'movies') $section = 'new_movies';
    if ($section === 'anime' || $section === 'animation') $section = 'animations';
    $params = punk_section_params($section, $page);
    return punk_search($params);
}

function bm_app_section($archive, $section, $page, $limit = 24) {
    $archive = (string)$archive;
    if ($archive === '3') $raw = bm_app_archive3_section($section, $page);
    else $raw = bm_app_archive1_section($section, $page);
    $movies = isset($raw['movies']) && is_array($raw['movies']) ? $raw['movies'] : array();
    $items = array();
    foreach ($movies as $it) {
        $items[] = bm_app_normalize_card($it, $archive);
        if ($limit > 0 && count($items) >= $limit) break;
    }
    return array(
        'archive' => (int)$archive,
        'section' => $section,
        'page' => isset($raw['page']) ? $raw['page'] : $page,
        'count' => count($items),
        'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']) || count($items) >= $limit,
        'next_page' => isset($raw['next_page']) ? $raw['next_page'] : (count($items) >= $limit ? ($page + 1) : null),
        'items' => $items,
        'pagination' => array(
            'page' => isset($raw['page']) ? (int)$raw['page'] : (int)$page,
            'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']),
            'next_page' => isset($raw['next_page']) ? $raw['next_page'] : null
        )
    );
}


function bm_app_db_search_movies($q, $type = '', $page = 1, $limit = 24) {
    $pdo = bm_app_pdo();
    if (!$pdo || !bm_app_table_exists('movies')) return null;

    $page = max(1, (int)$page);
    $limit = max(1, min(80, (int)$limit));
    $offset = ($page - 1) * $limit;

    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    $where = array();
    $params = array();

    $q = trim((string)$q);
    if ($q !== '') {
        $searchCols = array();
        foreach (array('title','title_fa','original_title','title_en','imdb_code','imdb','slug','source_slug','detail_id') as $c) {
            if (in_array($c, $cols, true)) $searchCols[] = $c;
        }
        if ($searchCols) {
            $likeParts = array();
            foreach ($searchCols as $c) {
                $likeParts[] = "$c LIKE ?";
                $params[] = '%' . $q . '%';
            }
            $where[] = '(' . implode(' OR ', $likeParts) . ')';
        }
    }

    $type = strtolower(trim((string)$type));
    if ($type !== '' && $type !== 'all' && in_array('type', $cols, true)) {
        if ($type === 'series' || $type === 'serial' || $type === 'tv') {
            $where[] = "(type IN ('series','serial','tv','tvseries'))";
        } elseif ($type === 'movie' || $type === 'film') {
            $where[] = "(type IN ('movie','film') OR type IS NULL OR type = '')";
        } else {
            $where[] = "type = ?";
            $params[] = $type;
        }
    }

    if (!$where) $where[] = '1=1';
    $whereSql = implode(' AND ', $where);

    $order = in_array('updated_at', $cols, true) ? 'updated_at DESC, id DESC' : (in_array('created_at', $cols, true) ? 'created_at DESC, id DESC' : 'id DESC');

    try {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM movies WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT * FROM movies WHERE $whereSql ORDER BY $order LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

        $items = array();
        foreach ($rows as $r) $items[] = bm_app_normalize_db_movie($r);

        $hasMore = ($offset + count($items)) < $total;
        return array(
            'archive' => 2,
            'source' => 'db_movies',
            'page' => $page,
            'limit' => $limit,
            'query' => $q,
            'type' => $type,
            'total' => $total,
            'total_count' => $total,
            'count' => count($items),
            'has_more' => (count($items) >= $limit),
            'next_page' => (count($items) >= $limit) ? ($page + 1) : null,
            'items' => $items,
            'pagination' => array(
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'has_more' => $hasMore,
                'next_page' => $hasMore ? ($page + 1) : null
            )
        );
    } catch (Throwable $e) {
        return null;
    }
}


function bm_app_search_archive($archive, $q, $type, $page, $limit = 30) {
    $archive = (string)$archive;
    // دیتابیس niazroid_bankmovie1 مربوط به آرشیو محلی/کالکشن است؛
    // نباید برای آرشیو ۱ استفاده شود، چون لینک‌های DonyayeSerial را وارد آرشیو ۱ می‌کند.
    if ($archive === '2' || $archive === 'local' || $archive === 'db') {
        $dbSearch = bm_app_db_search_movies($q, $type, $page, $limit);
        if (is_array($dbSearch)) return $dbSearch;
    }
    if ($archive === '3') {
        $params = array(
            's' => $q,
            'type' => $type !== '' ? $type : 'all',
            'genre' => bm_app_param('genre', ''),
            'sort' => bm_app_param('sort', bm_app_param('sortby', 'newest')),
            'country' => bm_app_param('country', ''),
            'fromYear' => bm_app_param('fromYear', bm_app_param('min_year', '')),
            'toYear' => bm_app_param('toYear', bm_app_param('max_year', '')),
            'rates' => bm_app_param('rates', ''),
            'score' => bm_app_param('score', ''),
            'dubbed' => bm_app_param('dubbed', '') !== '',
            'subtitle' => bm_app_param('subtitle', '') !== '',
            'playonline' => bm_app_param('playonline', '') !== '',
            'page' => $page
        );
        $raw = punk_search($params);
    } else {
        $params = array(
            's' => $q,
            'type' => $type !== '' ? $type : 'both',
            'genre' => (int)bm_app_param('genre', 0),
            'sortby' => bm_app_param('sortby', 'newest'),
            'imdbrate' => (int)bm_app_param('imdbrate', 0),
            'country' => (int)bm_app_param('country', 0),
            'min_year' => (int)bm_app_param('min_year', 1800),
            'max_year' => (int)bm_app_param('max_year', date('Y')),
            'page' => $page,
            'dubbed' => (int)bm_app_param('dubbed', 0),
            'subtitle' => (int)bm_app_param('subtitle', 0)
        );
        $movies = advancedSearch($params);
        $raw = array('page' => $page, 'movies' => $movies);
    }

    $items = array();
    foreach ((isset($raw['movies']) ? $raw['movies'] : array()) as $it) {
        $items[] = bm_app_normalize_card($it, $archive);
        if ($limit > 0 && count($items) >= $limit) break;
    }
    return array(
        'archive' => (int)$archive,
        'page' => $page,
        'query' => $q,
        'type' => $type,
        'count' => count($items),
        'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']) || (count($items) > 0 && $page < 10),
        'next_page' => isset($raw['next_page']) ? $raw['next_page'] : ((count($items) > 0 && $page < 10) ? ($page + 1) : null),
        'items' => $items
    );
}


function bm_app_table_exists($table) {
    $pdo = bm_app_pdo();
    if (!$pdo) return false;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $stmt->execute(array($table));
        return ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        try {
            $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
            $stmt->execute(array($table));
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e2) { return false; }
    }
}

function bm_app_table_columns($table) {
    static $cache = array();
    if (isset($cache[$table])) return $cache[$table];
    $pdo = bm_app_pdo();
    $cols = array();
    if ($pdo) {
        try {
            $stmt = $pdo->prepare("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION");
            $stmt->execute(array($table));
            foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $r) {
                if (!empty($r['COLUMN_NAME'])) $cols[] = $r['COLUMN_NAME'];
            }
        } catch (Throwable $e) {
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
                foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $r) {
                    if (!empty($r['Field'])) $cols[] = $r['Field'];
                }
            } catch (Throwable $e2) {}
        }
    }
    $cache[$table] = $cols;
    return $cols;
}

function bm_app_col_exists($table, $col) {
    return in_array($col, bm_app_table_columns($table), true);
}

function bm_app_db_link_url($row) {
    foreach (array('url','link','download_url','file_url','src','href') as $k) {
        if (!empty($row[$k])) return trim((string)$row[$k]);
    }
    return '';
}

function bm_app_db_link_quality($row, $url) {
    foreach (array('quality','resolution','label','title') as $k) {
        if (!empty($row[$k])) return trim((string)$row[$k]);
    }
    if (preg_match('/(2160p|4K|1080p|720p|480p|360p)/i', $url, $m)) return strtoupper($m[1]);
    return 'Unknown';
}

function bm_app_link_tables_meta() {
    return array(
        'dubbed_links' => array('type'=>'dub', 'label'=>'دوبله فارسی'),
        'softsub_links' => array('type'=>'subtitle', 'label'=>'سافت ساب'),
        'hardsub_links' => array('type'=>'hardsub', 'label'=>'هاردساب'),
        'audio_links' => array('type'=>'audio', 'label'=>'صوت دوبله'),
        'dubbed_audio_links' => array('type'=>'audio', 'label'=>'صوت دوبله')
    );
}

function bm_app_make_download_link_from_row($table, $meta, $row, $movieIdForOutput) {
    $url = bm_app_db_link_url($row);
    if ($url === '') return null;
    $season = (isset($row['season']) && $row['season'] !== '' && $row['season'] !== null) ? (int)$row['season'] : null;
    $episode = (isset($row['episode']) && $row['episode'] !== '' && $row['episode'] !== null) ? (int)$row['episode'] : null;
    $isFolder = !empty($row['is_folder']) && (string)$row['is_folder'] !== '0';
    $quality = bm_app_db_link_quality($row, $url);
    $label = $meta['label'];
    $displayParts = array();
    if ($season !== null && $season > 0) $displayParts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $displayParts[] = 'قسمت ' . $episode;
    if ($quality !== '') $displayParts[] = $quality;
    $displayParts[] = $label;
    return array(
        'id' => isset($row['id']) ? (int)$row['id'] : 0,
        'movie_id' => $movieIdForOutput,
        'source_table' => $table,
        'source_movie_id' => isset($row['movie_id']) ? (int)$row['movie_id'] : $movieIdForOutput,
        'season' => $season,
        'episode' => $episode,
        'quality' => $quality,
        'type' => $meta['type'],
        'type_fa' => $label,
        'label' => $label,
        'display_label' => implode(' • ', array_filter($displayParts)),
        'size' => (string)($row['size'] ?? ''),
        'url' => bm_app_abs_asset($url),
        'is_folder' => $isFolder,
        'is_direct' => true,
        'is_download' => true,
        'is_audio' => $meta['type'] === 'audio'
    );
}

function bm_app_downloads_query_links($whereSql, $params, $movieIdForOutput) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    $out = array();
    foreach (bm_app_link_tables_meta() as $table => $meta) {
        if (!bm_app_table_exists($table)) continue;
        $cols = bm_app_table_columns($table);
        if (!in_array('url', $cols, true) && !in_array('link', $cols, true) && !in_array('download_url', $cols, true)) continue;
        try {
            $order = array();
            foreach (array('season','episode','id') as $c) if (in_array($c, $cols, true)) $order[] = "$c ASC";
            $orderSql = $order ? (' ORDER BY ' . implode(', ', $order)) : '';
            $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE " . $whereSql . $orderSql);
            $stmt->execute($params);
            foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $row) {
                $link = bm_app_make_download_link_from_row($table, $meta, $row, (int)$movieIdForOutput);
                if ($link) $out[] = $link;
            }
        } catch (Throwable $e) {}
    }
    return $out;
}

function bm_app_db_movie_row_by_id($movieId) {
    $pdo = bm_app_pdo();
    $movieId = (int)$movieId;
    if (!$pdo || $movieId <= 0 || !bm_app_table_exists('movies') || !bm_app_col_exists('movies', 'id')) return null;
    try {
        $stmt = $pdo->prepare('SELECT * FROM movies WHERE id = ? LIMIT 1');
        $stmt->execute(array($movieId));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) { return null; }
}

function bm_app_downloads_from_db_imdb($imdbCode, $movieIdForOutput = 0) {
    $imdbCode = trim((string)$imdbCode);
    if ($imdbCode === '') return array();
    return bm_app_downloads_query_links('url LIKE ?', array('%' . $imdbCode . '%'), (int)$movieIdForOutput);
}

function bm_app_movie_identity_values($row) {
    $ids = array('imdb'=>array(), 'title'=>array(), 'title_fa'=>array(), 'year'=>'');
    if (!is_array($row)) return $ids;
    foreach (array('imdb_code','imdb','imdb_id') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['imdb'][$v] = $v;
        }
    }
    foreach (array('title','title_en','original_title','name','english_title') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['title'][$v] = $v;
        }
    }
    foreach (array('title_fa','fa_title','persian_title') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['title_fa'][$v] = $v;
        }
    }
    if (!empty($row['year'])) $ids['year'] = trim((string)$row['year']);
    return $ids;
}

function bm_app_find_same_movie_rows($row) {
    $pdo = bm_app_pdo();
    if (!$pdo || !is_array($row) || !bm_app_table_exists('movies')) return array();
    $cols = bm_app_table_columns('movies');
    if (!$cols) return array();
    $currentId = isset($row['id']) ? (int)$row['id'] : 0;
    $idv = bm_app_movie_identity_values($row);
    $where = array();
    $params = array();

    foreach ($idv['imdb'] as $imdb) {
        foreach (array('imdb_code','imdb','imdb_id') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $imdb; }
        }
    }
    foreach ($idv['title'] as $title) {
        foreach (array('title','title_en','original_title','name','english_title') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $title; }
        }
    }
    foreach ($idv['title_fa'] as $titleFa) {
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $titleFa; }
        }
    }
    if (!$where) return array();

    try {
        $score = array();
        if (in_array('id', $cols, true)) $score[] = "CASE WHEN id = " . (int)$currentId . " THEN 100 ELSE 0 END";
        $order = $score ? (" ORDER BY (" . implode(' + ', $score) . ") ASC, id ASC") : " ORDER BY id ASC";
        $stmt = $pdo->prepare('SELECT * FROM movies WHERE (' . implode(' OR ', $where) . ')' . $order . ' LIMIT 40');
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $e) { return array(); }
}

function bm_app_downloads_from_same_movie_rows($row, $movieIdForOutput = 0, &$sourceIds = null) {
    $out = array();
    $seen = array();
    $sourceIdsLocal = array();
    foreach (bm_app_find_same_movie_rows($row) as $r) {
        if (empty($r['id'])) continue;
        $rid = (int)$r['id'];
        $links = bm_app_downloads_query_links('movie_id = ?', array($rid), (int)$movieIdForOutput);
        if (!$links) continue;
        $sourceIdsLocal[$rid] = $rid;
        foreach ($links as $l) {
            $u = isset($l['url']) ? (string)$l['url'] : '';
            if ($u !== '' && isset($seen[$u])) continue;
            if ($u !== '') $seen[$u] = true;
            $l['source_movie_id'] = $rid;
            $l['resolved_by'] = 'same_movie_identity';
            $out[] = $l;
        }
    }
    if (is_array($sourceIds)) $sourceIds = array_values($sourceIdsLocal);
    return $out;
}

function bm_app_link_table_debug_counts($row, $movieId = 0) {
    $pdo = bm_app_pdo();
    $diag = array();
    if (!$pdo) return array('pdo'=>false);
    $imdbs = array_values(bm_app_movie_identity_values($row)['imdb']);
    foreach (bm_app_link_tables_meta() as $table => $meta) {
        $info = array('exists'=>bm_app_table_exists($table));
        if (!$info['exists']) { $diag[$table] = $info; continue; }
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE movie_id = ?");
            $stmt->execute(array((int)$movieId));
            $info['by_movie_id'] = (int)$stmt->fetchColumn();
        } catch (Throwable $e) { $info['by_movie_id_error'] = $e->getMessage(); }
        foreach ($imdbs as $imdb) {
            try {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE url LIKE ?");
                $stmt->execute(array('%' . $imdb . '%'));
                $info['by_url_imdb'][$imdb] = (int)$stmt->fetchColumn();
            } catch (Throwable $e) { $info['by_url_imdb_error'] = $e->getMessage(); }
        }
        $diag[$table] = $info;
    }
    $same = array();
    foreach (bm_app_find_same_movie_rows($row) as $r) {
        $same[] = array('id'=>(int)($r['id'] ?? 0), 'imdb'=>$r['imdb_code'] ?? ($r['imdb'] ?? null), 'title'=>$r['title'] ?? ($r['title_en'] ?? null), 'title_fa'=>$r['title_fa'] ?? null);
    }
    $diag['same_movie_rows'] = $same;
    return $diag;
}


function bm_app_origin_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443');
    $scheme = $https ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] !== '' ? $_SERVER['HTTP_HOST'] : 'bankmovie.top';
    return $scheme . '://' . $host;
}

function bm_app_slugify_ascii($text) {
    $text = trim((string)$text);
    if ($text === '') return '';
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strtolower($text);
    $text = preg_replace('~[^a-z0-9]+~i', '-', $text);
    $text = trim($text, '-');
    return $text ?: '';
}

function bm_app_page_candidates_for_movie_row($row, $identifier = '') {
    $out = array();
    $base = rtrim(bm_app_origin_url(), '/');
    $publicId = bm_app_public_id_from_identifier($identifier);
    if ($publicId === '' && !empty($row['id'])) $publicId = (string)(int)$row['id'];

    foreach (array('source_url','url','detail_url','page_url','permalink','web_url') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v === '') continue;
            if (preg_match('~^https?://~i', $v)) $out[] = $v;
            elseif (strpos($v, '/') === 0) $out[] = $base . $v;
            elseif (strpos($v, 'movie/') === 0) $out[] = $base . '/' . $v;
        }
    }

    foreach (array('slug','source_slug','detail_id') as $c) {
        if (!empty($row[$c])) {
            $s = trim((string)$row[$c]);
            if ($s === '') continue;
            if (preg_match('~^https?://~i', $s)) $out[] = $s;
            elseif (strpos($s, 'movie/') === 0) $out[] = $base . '/' . ltrim($s, '/');
            else $out[] = $base . '/movie/' . trim($s, '/');
        }
    }

    // آرشیو ۲ روی سایت خودش slug انگلیسی + public id می‌سازد، مثل vikings-277 یا toy-story-5-14500
    if ($publicId !== '') {
        foreach (array('title_en','original_title','title','name','english_title') as $c) {
            if (!empty($row[$c])) {
                $slug = bm_app_slugify_ascii($row[$c]);
                if ($slug !== '') $out[] = $base . '/movie/' . $slug . '-' . $publicId;
            }
        }
        // اگر title_fa شامل عنوان انگلیسی کنار فارسی بود، بخش لاتین را هم امتحان کن
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (!empty($row[$c]) && preg_match_all('~[A-Za-z0-9][A-Za-z0-9\s\-\:\.]+~u', (string)$row[$c], $mm)) {
                foreach ($mm[0] as $piece) {
                    $slug = bm_app_slugify_ascii($piece);
                    if ($slug !== '') $out[] = $base . '/movie/' . $slug . '-' . $publicId;
                }
            }
        }
    }

    $clean = array();
    foreach ($out as $u) {
        $u = trim((string)$u);
        if ($u !== '' && !isset($clean[$u])) $clean[$u] = $u;
    }
    return array_values($clean);
}

function bm_app_fetch_public_html($url) {
    $url = trim((string)$url);
    if ($url === '') return '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'BankMovieAndroidNative/HTMLFallback'
        ));
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($body !== false && $code >= 200 && $code < 400) return (string)$body;
    }
    try {
        $ctx = stream_context_create(array('http'=>array('timeout'=>12,'header'=>"User-Agent: BankMovieAndroidNative/HTMLFallback\r\n"), 'ssl'=>array('verify_peer'=>false,'verify_peer_name'=>false)));
        $body = @file_get_contents($url, false, $ctx);
        return is_string($body) ? $body : '';
    } catch (Throwable $e) { return ''; }
}

function bm_app_download_type_from_context($url, $ctx) {
    $s = strtolower($url . ' ' . $ctx);
    if (strpos($s, 'softsub') !== false || strpos($s, 'soft-sub') !== false || strpos($s, 'سافت') !== false) return array('type'=>'subtitle', 'label'=>'سافت ساب');
    if (strpos($s, 'hardsub') !== false || strpos($s, 'hard-sub') !== false || strpos($s, 'هارد') !== false) return array('type'=>'hardsub', 'label'=>'هاردساب');
    if (strpos($s, 'dubbed') !== false || strpos($s, 'dub') !== false || strpos($s, 'دوبله') !== false) return array('type'=>'dub', 'label'=>'دوبله فارسی');
    if (strpos($s, 'audio') !== false || strpos($s, 'voice') !== false || strpos($s, 'صوت') !== false) return array('type'=>'audio', 'label'=>'صوت دوبله');
    return array('type'=>'download', 'label'=>'دانلود');
}

function bm_app_quality_from_text($text) {
    if (preg_match('~(2160p|4k|1080p|720p|480p|360p)[^\s<\"\']{0,40}~i', (string)$text, $m)) return trim($m[0]);
    return 'Unknown';
}

function bm_app_make_html_link($url, $ctx, $movieIdForOutput, $idx) {
    $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '' || !preg_match('~^https?://~i', $url)) return null;
    $ctx = html_entity_decode((string)$ctx, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $meta = bm_app_download_type_from_context($url, $ctx);
    $quality = bm_app_quality_from_text($ctx . ' ' . $url);
    $season = null; $episode = null;
    if (preg_match('~(?:data-season=[\"\']?S?)(\d+)~i', $ctx, $m)) $season = (int)$m[1];
    elseif (preg_match('~[\\/_\.-]S(\d{1,2})[\\/_\.-]?~i', $url, $m)) $season = (int)$m[1];
    if (preg_match('~(?:data-episode=[\"\']?E?)(\d+)~i', $ctx, $m)) $episode = (int)$m[1];
    elseif (preg_match('~S\d{1,2}E(\d{1,3})~i', $url, $m)) $episode = (int)$m[1];
    elseif (preg_match('~قسمت\s*(\d+)~u', $ctx, $m)) $episode = (int)$m[1];
    $parts = array();
    if ($season !== null && $season > 0) $parts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $parts[] = 'قسمت ' . $episode;
    if ($quality !== '') $parts[] = $quality;
    $parts[] = $meta['label'];
    return array(
        'id' => $idx,
        'movie_id' => (int)$movieIdForOutput,
        'source_table' => 'html_page',
        'source_movie_id' => (int)$movieIdForOutput,
        'season' => $season,
        'episode' => $episode,
        'quality' => $quality,
        'type' => $meta['type'],
        'type_fa' => $meta['label'],
        'label' => $meta['label'],
        'display_label' => implode(' • ', array_filter($parts)),
        'size' => '',
        'url' => $url,
        'is_folder' => false,
        'is_direct' => true,
        'is_download' => true,
        'is_audio' => $meta['type'] === 'audio'
    );
}

function bm_app_parse_downloads_from_movie_html($html, $movieIdForOutput = 0) {
    $html = (string)$html;
    if ($html === '') return array();
    $out = array();
    $seen = array();
    $idx = 1;
    $add = function($url, $ctx) use (&$out, &$seen, &$idx, $movieIdForOutput) {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '' || !preg_match('~^https?://~i', $url)) return;
        if (isset($seen[$url])) return;
        // لینک‌های سایت/تبلیغ/عکس را حذف کن؛ لینک فایل/دانلود/پخش را نگه دار
        $u = strtolower($url);
        $looksDownload = preg_match('~\.(mkv|mp4|avi|m3u8|mpd|mov|webm|zip|rar)(?:[?#]|$)~i', $url) ||
            strpos($u, 'dls') !== false || strpos($u, 'dlcenter') !== false || strpos($u, 'download') !== false || strpos($u, 'playit=') !== false || strpos($u, 'softsub') !== false || strpos($u, 'hardsub') !== false;
        if (!$looksDownload) return;
        $link = bm_app_make_html_link($url, $ctx, $movieIdForOutput, $idx++);
        if ($link) { $seen[$url] = true; $out[] = $link; }
    };

    if (preg_match_all('~<button[^>]+class=[\"\'][^\"\']*bm-local-play-choice[^\"\']*[\"\'][^>]*>~is', $html, $m)) {
        foreach ($m[0] as $tag) {
            if (preg_match('~data-url=[\"\']([^\"\']+)[\"\']~i', $tag, $u)) $add($u[1], $tag);
        }
    }
    if (preg_match_all('~data-url=[\"\']([^\"\']+)[\"\']~i', $html, $m)) {
        foreach ($m[1] as $u) $add($u, substr($html, max(0, strpos($html, $u) - 500), 1200));
    }
    if (preg_match_all('~handleDownloadClick\([\"\']([^\"\']+)[\"\']\)~i', $html, $m)) {
        foreach ($m[1] as $u) $add($u, substr($html, max(0, strpos($html, $u) - 500), 1200));
    }
    if (preg_match_all('~<a\b[^>]+href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>~is', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $a) $add($a[1], $a[0]);
    }
    return $out;
}

function bm_app_downloads_from_html_page_for_movie($row, $identifier = '', $movieIdForOutput = 0) {
    if (!is_array($row)) return array();
    $candidates = bm_app_page_candidates_for_movie_row($row, $identifier);
    foreach ($candidates as $url) {
        $html = bm_app_fetch_public_html($url);
        if ($html === '') continue;
        $links = bm_app_parse_downloads_from_movie_html($html, $movieIdForOutput);
        if ($links) {
            foreach ($links as &$l) $l['html_source_url'] = $url;
            unset($l);
            return $links;
        }
    }
    return array();
}


function bm_app_downloads_from_db_movie($movieId) {
    $movieId = (int)$movieId;
    if ($movieId <= 0) return array();

    // ۱) اتصال مستقیم جدول لینک‌ها با movies.id
    $out = bm_app_downloads_query_links('movie_id = ?', array($movieId), $movieId);
    if ($out) return $out;

    $row = bm_app_db_movie_row_by_id($movieId);
    if ($row) {
        // ۲) اگر این id عمومی/کپی است، ردیف اصلی همان فیلم را از روی imdb/title پیدا کن و لینک‌های آن id را بگیر.
        $sameIds = array();
        $same = bm_app_downloads_from_same_movie_rows($row, $movieId, $sameIds);
        if ($same) return $same;

        // ۳) بعضی لینک‌ها در URL شناسه IMDb دارند.
        foreach (array('imdb_code','imdb','imdb_id') as $c) {
            if (!empty($row[$c])) {
                $byImdb = bm_app_downloads_from_db_imdb((string)$row[$c], $movieId);
                if ($byImdb) return $byImdb;
            }
        }

        // ۴) fallback HTML فقط اگر هاست اجازه fetch بدهد.
        $fromHtml = bm_app_downloads_from_html_page_for_movie($row, (string)$movieId, $movieId);
        if ($fromHtml) return $fromHtml;
    }

    return array();
}

function bm_app_public_id_from_identifier($identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') return '';
    $path = (string)(parse_url($identifier, PHP_URL_PATH) ?: $identifier);
    $base = trim(basename(trim($path, '/')));
    if (ctype_digit($identifier)) return $identifier;
    if (preg_match('~-(\d+)$~', $base, $m)) return $m[1];
    if (preg_match('~/movie/[^/?#]*-(\d+)(?:[/?#]|$)~i', $identifier, $m)) return $m[1];
    return '';
}

function bm_app_lookup_movie_by_fields($fields) {
    $pdo = bm_app_pdo();
    if (!$pdo || !is_array($fields)) return null;
    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    $where = array();
    $params = array();

    foreach (array('imdb_code','imdb') as $c) {
        if (in_array($c, $cols, true) && !empty($fields[$c])) {
            $where[] = "$c = ?";
            $params[] = trim((string)$fields[$c]);
        }
    }

    $title = trim((string)($fields['title'] ?? ''));
    $titleFa = trim((string)($fields['title_fa'] ?? ''));
    $year = trim((string)($fields['year'] ?? ''));

    if ($title !== '') {
        foreach (array('title','title_en','name','english_title') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $title;
            }
        }
    }
    if ($titleFa !== '') {
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $titleFa;
            }
        }
    }

    if (!$where) return null;
    try {
        $sql = 'SELECT * FROM movies WHERE (' . implode(' OR ', $where) . ')';
        if ($year !== '' && in_array('year', $cols, true)) {
            $sql .= ' ORDER BY CASE WHEN year = ? THEN 0 ELSE 1 END, id ASC';
            $params[] = $year;
        } else {
            $sql .= ' ORDER BY id ASC';
        }
        $sql .= ' LIMIT 1';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) return $row;
    } catch (Throwable $e) {}
    return null;
}

function bm_app_find_db_movie_row($identifier) {
    $pdo = bm_app_pdo();
    if (!$pdo) return null;
    $identifier = trim((string)$identifier);
    if ($identifier === '') return null;

    $slug = bm_app_extract_slug_from_url($identifier);
    $publicId = bm_app_public_id_from_identifier($identifier);
    $base = trim((string)basename(trim((string)(parse_url($identifier, PHP_URL_PATH) ?: $identifier), '/')));
    $slugNoId = $base !== '' ? preg_replace('~-\d+$~', '', $base) : '';

    $candidates = array_values(array_unique(array_filter(array($identifier, $slug, $base, $slugNoId, $publicId))));
    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    foreach ($candidates as $cand) {
        $where = array();
        $params = array();

        if (ctype_digit((string)$cand) && in_array('id', $cols, true)) {
            $where[] = 'id = ?';
            $params[] = (int)$cand;
        }

        foreach (array('slug','source_slug','detail_id','imdb_code','imdb','tmdb_id') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $cand;
            }
        }

        foreach (array('source_url','url','detail_url','page_url','permalink') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c LIKE ?";
                $params[] = '%' . $cand . '%';
            }
        }

        if ($publicId !== '') {
            foreach (array('slug','source_slug','detail_id') as $c) {
                if (in_array($c, $cols, true)) {
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId;
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId . '/%';
                }
            }
            foreach (array('source_url','url','detail_url','page_url','permalink') as $c) {
                if (in_array($c, $cols, true)) {
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId . '%';
                    $where[] = "$c LIKE ?";
                    $params[] = '%/movie/%' . $publicId . '%';
                }
            }
        }

        if (!$where) continue;
        try {
            $stmt = $pdo->prepare('SELECT * FROM movies WHERE ' . implode(' OR ', $where) . ' ORDER BY id ASC LIMIT 1');
            $stmt->execute($params);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) return $row;
        } catch (Throwable $e) {}
    }

    // آخرین راه‌حل: از صفحه/کتابخانه جزئیات imdb و عنوان را بگیر، بعد با آن دیتابیس را پیدا کن.
    try {
        $raw = getMovieDetails($identifier, null);
        if (is_array($raw)) {
            $fields = array(
                'imdb_code' => $raw['imdb_code'] ?? ($raw['imdb'] ?? ''),
                'imdb' => $raw['imdb_code'] ?? ($raw['imdb'] ?? ''),
                'title' => $raw['title'] ?? ($raw['title_en'] ?? ''),
                'title_fa' => $raw['title_fa'] ?? ($raw['fa_title'] ?? ''),
                'year' => $raw['year'] ?? ''
            );
            $row = bm_app_lookup_movie_by_fields($fields);
            if ($row) return $row;
        }
    } catch (Throwable $e) {}

    return null;
}

function bm_app_merge_db_downloads_into_detail($detail, $identifier = '') {
    if (!is_array($detail)) return $detail;
    $movieId = 0;
    foreach (array('db_id','movie_id','local_id','id') as $k) {
        if (!empty($detail[$k]) && ctype_digit((string)$detail[$k])) { $movieId = (int)$detail[$k]; break; }
    }
    $rowForVisuals = null;
    if ($movieId <= 0 && $identifier !== '') {
        $row = bm_app_find_db_movie_row($identifier);
        if ($row && !empty($row['id'])) { $movieId = (int)$row['id']; $rowForVisuals = $row; }
    } else if ($identifier !== '') {
        $rowForVisuals = bm_app_find_db_movie_row($identifier);
    }
    if ($movieId <= 0 && !empty($detail['source_url'])) {
        $row = bm_app_find_db_movie_row($detail['source_url']);
        if ($row && !empty($row['id'])) $movieId = (int)$row['id'];
    }
    if ($rowForVisuals && is_array($rowForVisuals)) {
        foreach (array('poster','image','cover_image','backdrop','imdb_code') as $vk) {
            if (empty($detail[$vk]) && !empty($rowForVisuals[$vk])) $detail[$vk] = $rowForVisuals[$vk];
        }
        if (empty($detail['poster']) && !empty($rowForVisuals['imdb_code'])) $detail['poster'] = bm_app_existing_local_poster($rowForVisuals['imdb_code']);
        if (empty($detail['image']) && !empty($detail['poster'])) $detail['image'] = $detail['poster'];
        if (empty($detail['backdrop']) && !empty($detail['poster'])) $detail['backdrop'] = $detail['poster'];
    }
    if ($movieId <= 0) return $detail;
    $dbLinks = bm_app_downloads_from_db_movie($movieId);
    if (!$dbLinks) return $detail;

    $old = array();
    if (isset($detail['downloads']) && is_array($detail['downloads'])) $old = $detail['downloads'];
    elseif (isset($detail['links']) && is_array($detail['links'])) $old = $detail['links'];
    $seen = array();
    $merged = array();
    foreach (array_merge($old, $dbLinks) as $l) {
        if (!is_array($l)) continue;
        $u = bm_app_db_link_url($l);
        if ($u === '') continue;
        $key = md5($u . '|' . ($l['quality'] ?? '') . '|' . ($l['season'] ?? '') . '|' . ($l['episode'] ?? '') . '|' . ($l['type'] ?? ''));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $merged[] = $l;
    }
    $detail['db_id'] = $movieId;
    $detail['movie_id'] = $movieId;
    $detail['downloads'] = $merged;
    $detail['links'] = $merged;
    return $detail;
}

function bm_app_db_detail($identifier, $typeHint = '', $archiveOut = 2) {
    $row = bm_app_find_db_movie_row($identifier);
    if (!$row) return null;
    $movieId = (int)($row['id'] ?? 0);
    $downloads = bm_app_downloads_from_db_movie($movieId);
    $row['db_id'] = $movieId;
    $row['movie_id'] = $movieId;
    if (empty($row['poster']) && !empty($row['imdb_code'])) $row['poster'] = bm_app_existing_local_poster($row['imdb_code']);
    if (empty($row['image']) && !empty($row['poster'])) $row['image'] = $row['poster'];
    if (empty($row['backdrop']) && !empty($row['poster'])) $row['backdrop'] = $row['poster'];
    $row['downloads'] = $downloads;
    $row['links'] = $downloads;
    $row['type'] = $typeHint ?: ($row['type'] ?? 'movie');
    $row['rating'] = $row['imdb_rate'] ?? ($row['rating'] ?? null);
    $detail = bm_app_normalize_detail($row, (int)$archiveOut === 2 ? 2 : $archiveOut);
    $detail['source'] = 'db_movies';
    $detail['archive'] = 2;
    return $detail;
}
function bm_app_actor_db_fallback($name) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    $name = trim((string)$name);
    if ($name === '') return array();
    try {
        $stmt = $pdo->prepare("SELECT * FROM movies WHERE actors LIKE ? ORDER BY year DESC, id DESC LIMIT 80");
        $stmt->execute(array('%' . $name . '%'));
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
        return array_map('bm_app_normalize_db_movie', $rows);
    } catch (Throwable $e) { return array(); }
}

function bm_app_detail($archive, $identifier, $type) {
    $archive = (string)$archive;
    if ($identifier === '') bm_app_fail('شناسه خالی است', 422);
    $isLocalArchive = in_array($archive, array('2','local','db','collection'), true);

    if ($archive === '3') {
        $raw = punk_get_details($identifier);
        return bm_app_normalize_detail($raw, 3);
    }

    if ($isLocalArchive && ctype_digit((string)$identifier)) {
        $dbFirst = bm_app_db_detail($identifier, $type, 2);
        if ($dbFirst && (int)($dbFirst['downloads_count'] ?? 0) > 0) return $dbFirst;
    }

    try {
        $raw = getMovieDetails($identifier, $type !== '' ? $type : null);
        if (!$isLocalArchive && is_array($raw)) $raw = bm_app_fill_archive1_backdrop($raw, $identifier, $type);

        // بسیار مهم: آرشیو ۱ نباید هیچ‌وقت با دیتابیس محلی/کالکشن merge شود.
        // همین merge باعث شده بود لینک‌های DonyayeSerial/فصل‌بندی آرشیو محلی وارد صفحه اطلاعات آرشیو ۱ شود.
        if ($isLocalArchive && is_array($raw)) $raw = bm_app_merge_db_downloads_into_detail($raw, $identifier);

        $detail = bm_app_normalize_detail($raw, $isLocalArchive ? 2 : 1);

        if ($isLocalArchive && (int)($detail['downloads_count'] ?? 0) <= 0) {
            $db = bm_app_db_detail($identifier, $type, 2);
            if ($db && (int)($db['downloads_count'] ?? 0) > 0) {
                $detail['play'] = $db['play'];
                $detail['links'] = $db['links'];
                $detail['downloads'] = $db['downloads'];
                $detail['downloads_count'] = $db['downloads_count'];
                $detail['has_dubbed'] = $db['has_dubbed'];
                $detail['has_subtitle'] = $db['has_subtitle'];
                $detail['has_online'] = $db['has_online'];
                $detail['db_id'] = $db['db_id'] ?? null;
                $detail['movie_id'] = $db['movie_id'] ?? null;
                $detail['source'] = 'db_movies';
                $detail['archive'] = 2;
            }
        }
        return $detail;
    } catch (Throwable $e) {
        if ($isLocalArchive) {
            $db = bm_app_db_detail($identifier, $type, 2);
            if ($db) return $db;
        }
        throw $e;
    }
}


function bm_app_normalize_actor_page_movie($item) {
    if (!is_array($item)) return null;
    return bm_app_normalize_card($item, 1);
}

function bm_app_actor_details($identifier) {
    $identifier = trim((string)$identifier);
    $fallbackName = trim((string)bm_app_param('name', ''));
    if ($identifier === '') $identifier = $fallbackName;
    if ($identifier === '') bm_app_fail('شناسه بازیگر خالی است', 422);

    $raw = null;
    try { $raw = getActorDetails($identifier); } catch (Throwable $e) { $raw = null; }
    $actorName = (string)($raw['name'] ?? $fallbackName ?? $identifier);
    $actor = array(
        'name' => $actorName,
        'slug' => (string)($raw['slug'] ?? ''),
        'image' => bm_app_abs_asset((string)($raw['photo'] ?? '')),
        'photo' => bm_app_abs_asset((string)($raw['photo'] ?? '')),
        'count' => (int)($raw['count'] ?? 0)
    );
    $items = array();
    foreach (($raw['movies'] ?? array()) as $m) {
        $n = bm_app_normalize_actor_page_movie($m);
        if ($n) $items[] = $n;
    }
    if (empty($items) && $actorName !== '') $items = bm_app_actor_db_fallback($actorName);
    $actor['count'] = count($items);
    return array('actor' => $actor, 'count' => count($items), 'items' => $items, 'movies' => $items);
}

try {
    $action = strtolower(bm_app_param('action', bm_app_param('fn', 'home')));
    $archive = bm_app_param('archive', '1');
    $page = bm_app_int('page', 1, 1, 500);
    $limit = bm_app_int('limit', 24, 1, 60);

    if ($action === 'ping') {
        bm_app_json(array(
            'status' => 'success',
            'message' => 'BankMoviee app API is ready',
            'version' => '2.1.0',
            'archives' => array(1),
            'optional_archives' => array(3),
            'default_archive' => 1
        ));
    }

    if ($action === 'boot' || $action === 'init') {
        $bootLimit = bm_app_int('limit', 12, 4, 30);
        bm_app_json(array(
            'status' => 'success',
            'action' => 'boot',
            'ready' => true,
            'version' => '2.1.0',
            'default_archive' => 1,
            'archives' => array(1),
            'loading' => array(
                'ping_ok' => true,
                'wait_for' => array('sliders','sections','collections'),
                'message' => 'BankMoviee API boot is ready'
            ),
            'sliders' => bm_app_sliders(10),
            'collections' => bm_app_collections(1, 8),
            'sections' => array(
                bm_app_section('1', 'updated_movies', 1, $bootLimit),
                bm_app_section('1', 'updated_series', 1, $bootLimit),
                bm_app_section('1', 'anime', 1, $bootLimit),
                bm_app_section('1', 'turkish', 1, $bootLimit)
            )
        ));
    }

    if ($action === 'sliders' || $action === 'slider') {
        bm_app_json(array('status'=>'success','action'=>'sliders','items'=>bm_app_sliders($limit)));
    }

    if ($action === 'collections') {
        bm_app_json(array_merge(array('status'=>'success','action'=>'collections'), bm_app_collections($page, $limit)));
    }

    if ($action === 'collection') {
        $slug = bm_app_param('slug', bm_app_param('id', ''));
        $sort = bm_app_param('sort', 'default');
        bm_app_json(array_merge(array('status'=>'success','action'=>'collection'), bm_app_collection_items($slug, $page, $limit, $sort)));
    }

    if ($action === 'home') {
        $sections = array(
            bm_app_section('1', 'updated_movies', 1, 12),
            bm_app_section('1', 'updated_series', 1, 12),
            bm_app_section('1', 'anime', 1, 12),
            bm_app_section('1', 'turkish', 1, 12)
        );
        bm_app_json(array(
            'status' => 'success',
            'action' => 'home',
            'archive' => 1,
            'default_archive' => 1,
            'sliders' => bm_app_sliders(10),
            'collections' => bm_app_collections(1, 8),
            'sections' => $sections
        ));
    }

    if ($action === 'section') {
        $section = bm_app_param('section', 'new_movies');
        if (bm_app_is_serialblog_archive($archive)) {
            bm_app_json(array_merge(array('status' => 'success', 'action' => 'section'), bm_app_serialblog_section($section, $page, $limit)));
        }
        if ($archive === 'all') {
            $one = bm_app_section('1', $section, $page, $limit);
            $three = bm_app_section('3', $section, $page, $limit);
            bm_app_json(array(
                'status' => 'success',
                'action' => 'section',
                'archive' => 'all',
                'section' => $section,
                'page' => $page,
                'items' => array_merge($one['items'], $three['items']),
                'sources' => array($one, $three)
            ));
        }
        bm_app_json(array_merge(array('status' => 'success', 'action' => 'section'), bm_app_section($archive === '3' ? '3' : '1', $section, $page, $limit)));
    }

    if ($action === 'search' || $action === 'live_search') {
        $q = bm_app_param('q', bm_app_param('s', ''));
        $type = bm_app_param('type', '');
        if ($action === 'live_search') $limit = min($limit, 12);
        if (bm_app_is_serialblog_archive($archive)) {
            bm_app_json(array_merge(array('status' => 'success', 'action' => $action), bm_app_serialblog_search($q, $type, $page, $limit)));
        }
        if ($archive === 'all') {
            $one = bm_app_search_archive('1', $q, $type, $page, $limit);
            $three = bm_app_search_archive('3', $q, $type, $page, $limit);
            $items = array_merge($one['items'], $three['items']);
            $hasMore = !empty($one['has_more']) || !empty($three['has_more']);
            bm_app_json(array(
                'status' => 'success',
                'action' => 'search',
                'archive' => 'all',
                'query' => $q,
                'page' => $page,
                'count' => count($items),
                'total' => (int)($one['total'] ?? count($one['items'])) + (int)($three['total'] ?? count($three['items'])),
                'total_count' => (int)($one['total_count'] ?? ($one['total'] ?? count($one['items']))) + (int)($three['total_count'] ?? ($three['total'] ?? count($three['items']))),
                'has_more' => $hasMore,
                'next_page' => $hasMore ? ($page + 1) : null,
                'items' => $items,
                'sources' => array($one, $three)
            ));
        }
        $searchArchive = in_array((string)$archive, array('2','local','db','collection'), true) ? '2' : ((string)$archive === '3' ? '3' : '1');
        bm_app_json(array_merge(array('status' => 'success', 'action' => 'search'), bm_app_search_archive($searchArchive, $q, $type, $page, $limit)));
    }


    if ($action === 'debug_links') {
        $identifier = bm_app_param('id', bm_app_param('slug', bm_app_param('url', '')));
        $row = bm_app_find_db_movie_row($identifier);
        $movieId = $row && !empty($row['id']) ? (int)$row['id'] : 0;
        $links = $movieId > 0 ? bm_app_downloads_from_db_movie($movieId) : array();
        $imdb = $row['imdb_code'] ?? ($row['imdb'] ?? ($row['imdb_id'] ?? null));
        $sourceMovieIds = array();
        $htmlSources = array();
        foreach ($links as $l) {
            if (isset($l['source_movie_id'])) $sourceMovieIds[] = (int)$l['source_movie_id'];
            if (!empty($l['html_source_url'])) $htmlSources[] = (string)$l['html_source_url'];
        }
        $sourceMovieIds = array_values(array_unique(array_filter($sourceMovieIds)));
        $htmlSources = array_values(array_unique(array_filter($htmlSources)));
        bm_app_json(array(
            'status'=>'success',
            'action'=>'debug_links',
            'input'=>$identifier,
            'public_id'=>bm_app_public_id_from_identifier($identifier),
            'database'=>bm_app_current_database_name(),
            'resolved_movie_id'=>$movieId,
            'resolved_slug'=>$row['slug'] ?? ($row['source_slug'] ?? ($row['detail_id'] ?? null)),
            'resolved_imdb'=>$imdb,
            'html_candidates'=>$row ? bm_app_page_candidates_for_movie_row($row, $identifier) : array(),
            'html_sources'=>$htmlSources,
            'source_link_movie_ids'=>$sourceMovieIds,
            'diagnostics'=>$row ? bm_app_link_table_debug_counts($row, $movieId) : array(),
            'count'=>count($links),
            'links'=>$links
        ));
    }

    if ($action === 'actor') {
        $identifier = bm_app_param('slug', bm_app_param('actor', bm_app_param('url', '')));
        bm_app_json(array_merge(array('status'=>'success','action'=>'actor'), bm_app_actor_details($identifier)));
    }

    if ($action === 'detail' || $action === 'play') {
        $identifier = bm_app_param('id', bm_app_param('slug', bm_app_param('url', '')));
        $type = bm_app_param('type', '');
        if (bm_app_is_serialblog_archive($archive)) {
            $detail = bm_app_serialblog_detail($identifier, $type);
        } else {
            $detailArchive = in_array((string)$archive, array('2','local','db','collection'), true) ? '2' : ((string)$archive === '3' ? '3' : '1');
            $detail = bm_app_detail($detailArchive, $identifier, $type);
        }
        if ($action === 'play') {
            bm_app_json(array(
                'status' => 'success',
                'action' => 'play',
                'archive' => $detail['archive'],
                'id' => $detail['id'],
                'title' => $detail['title'],
                'title_fa' => $detail['title_fa'],
                'type' => $detail['type'],
                'poster' => $detail['poster'],
                'play' => $detail['play']
            ));
        }
        bm_app_json(array('status' => 'success', 'action' => 'detail', 'item' => $detail));
    }

    if ($action === 'notifications') {
        $items = array();
        $error = '';
        try {
            require_once __DIR__ . '/config.php';
            if (isset($pdo) && $pdo instanceof PDO) {
                $stmt = $pdo->prepare("SELECT id, title, message, link, image, created_at, expires_at FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
                $stmt->execute();
                $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
        bm_app_json(array('status' => 'success', 'action' => 'notifications', 'count' => count($items), 'items' => $items, 'debug_error' => $error));
    }

    bm_app_fail('اکشن نامعتبر است', 404, array('action' => $action));

} catch (Throwable $e) {
    bm_app_json(array(
        'status' => 'error',
        'message' => $e->getMessage(),
        'action' => isset($action) ? $action : '',
        'archive' => isset($archive) ? $archive : ''
    ), 500);
}
