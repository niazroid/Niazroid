SELECT DATABASE() AS active_database;

SELECT TABLE_NAME, TABLE_ROWS
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = DATABASE()
  AND TABLE_NAME IN (
    'comments',
    'archive1_comments',
    'comment_likes',
    'archive1_comment_likes',
    'archive1_items',
    'comment_rate_limits'
  )
ORDER BY TABLE_NAME;

SELECT 'comments' AS source, status, COUNT(*) AS total
FROM comments
GROUP BY status
UNION ALL
SELECT 'archive1_comments' AS source, status, COUNT(*) AS total
FROM archive1_comments
GROUP BY status
ORDER BY source, status;
