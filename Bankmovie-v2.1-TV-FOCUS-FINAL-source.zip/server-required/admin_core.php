<?php
// admin_core.php - هسته امن پنل مدیریت BankMovie Pro
// این فایل را کنار admin.php و config.php قرار بدهید.

declare(strict_types=1);

require_once __DIR__ . '/config.php';

ini_set('display_errors', '0');
ini_set('log_errors', '1');
if (!is_dir(__DIR__ . '/logs')) {
    @mkdir(__DIR__ . '/logs', 0755, true);
}
ini_set('error_log', __DIR__ . '/logs/admin-error.log');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const BM_JSON_FLAGS = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP;

function bm_e($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function bm_json($value): string {
    return json_encode($value, BM_JSON_FLAGS);
}

function bm_json_out(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo bm_json($payload);
    exit;
}

function bm_current_admin(): ?array {
    global $currentUser, $pdo;
    if (isset($currentUser) && is_array($currentUser) && ($currentUser['role'] ?? '') === 'admin') {
        return $currentUser;
    }
    if (!empty($_COOKIE['session_token']) && class_exists('User')) {
        try {
            $user = new User($pdo);
            $checked = $user->checkSession($_COOKIE['session_token']);
            if ($checked && ($checked['role'] ?? '') === 'admin') {
                $GLOBALS['currentUser'] = $checked;
                return $checked;
            }
        } catch (Throwable $e) {
            error_log('Admin session check error: ' . $e->getMessage());
        }
    }
    return null;
}

function bm_require_admin(bool $json = false): array {
    $admin = bm_current_admin();
    if (!$admin) {
        if ($json) bm_json_out(['success' => false, 'error' => 'دسترسی غیرمجاز'], 403);
        header('Location: /login');
        exit;
    }
    return $admin;
}

function bm_csrf_token(): string {
    if (empty($_SESSION['admin_csrf_token'])) {
        $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['admin_csrf_token'];
}

function bm_csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . bm_e(bm_csrf_token()) . '">';
}

function bm_verify_csrf(?string $token): bool {
    return is_string($token) && isset($_SESSION['admin_csrf_token']) && hash_equals($_SESSION['admin_csrf_token'], $token);
}

function bm_require_post_csrf(bool $json = false): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        if ($json) bm_json_out(['success' => false, 'error' => 'Method not allowed'], 405);
        http_response_code(405);
        exit('Method not allowed');
    }
    if (!bm_verify_csrf($_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? null)) {
        if ($json) bm_json_out(['success' => false, 'error' => 'توکن امنیتی نامعتبر است'], 419);
        http_response_code(419);
        exit('CSRF token mismatch');
    }
}

function bm_admin_url(string $path = 'admin.php', array $params = []): string {
    $path = preg_replace('/[^a-zA-Z0-9_\.\-\/]/', '', $path) ?: 'admin.php';
    if (!$params) return $path;
    return $path . '?' . http_build_query($params);
}

function bm_redirect(string $msg, string $type = 'success', string $target = 'admin.php'): never {
    $target = trim($target);
    if ($target === '' || preg_match('~^https?://~i', $target) || str_starts_with($target, '//')) {
        $target = 'admin.php';
    }
    $separator = str_contains($target, '?') ? '&' : '?';
    header('Location: ' . $target . $separator . http_build_query(['msg' => $msg, 'type' => $type]));
    exit;
}

function bm_table_exists(PDO $pdo, string $table): bool {
    static $cache = [];
    $key = strtolower($table);
    if (array_key_exists($key, $cache)) return $cache[$key];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return $cache[$key] = false;
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
        $stmt->execute([$table]);
        return $cache[$key] = (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        error_log('bm_table_exists('.$table.'): '.$e->getMessage());
        return $cache[$key] = false;
    }
}

function bm_column_exists(PDO $pdo, string $table, string $column): bool {
    static $cache = [];
    $key = strtolower($table . '.' . $column);
    if (array_key_exists($key, $cache)) return $cache[$key];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return $cache[$key] = false;
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
        $stmt->execute([$table, $column]);
        return $cache[$key] = (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        error_log('bm_column_exists('.$table.'.'.$column.'): '.$e->getMessage());
        return $cache[$key] = false;
    }
}

function bm_count(PDO $pdo, string $sql, array $params = []): int {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        error_log('Admin count error: ' . $e->getMessage());
        return 0;
    }
}

function bm_countries(): array {
    $countries = [
        'Afghanistan','Albania','Algeria','Andorra','Angola','Argentina','Armenia','Australia','Austria','Azerbaijan','Bahamas','Bahrain','Bangladesh','Barbados','Belarus','Belgium','Belize','Benin','Bhutan','Bolivia','Bosnia and Herzegovina','Botswana','Brazil','Brunei','Bulgaria','Burkina Faso','Burundi','Cabo Verde','Cambodia','Cameroon','Canada','Central African Republic','Chad','Chile','China','Colombia','Comoros','Congo','Costa Rica','Croatia','Cuba','Cyprus','Czech Republic','Czechia','Denmark','Djibouti','Dominica','Dominican Republic','Ecuador','Egypt','El Salvador','Equatorial Guinea','Eritrea','Estonia','Eswatini','Ethiopia','Fiji','Finland','France','Gabon','Gambia','Georgia','Germany','Ghana','Greece','Grenada','Guatemala','Guinea','Guinea-Bissau','Guyana','Haiti','Honduras','Hong Kong','Hungary','Iceland','India','Indonesia','Iran','Iraq','Ireland','Israel','Italy','Jamaica','Japan','Jordan','Kazakhstan','Kenya','Kiribati','Korea, North','Korea, South','Kosovo','Kuwait','Kyrgyzstan','Laos','Latvia','Lebanon','Lesotho','Liberia','Libya','Liechtenstein','Lithuania','Luxembourg','Madagascar','Malawi','Malaysia','Maldives','Mali','Malta','Marshall Islands','Mauritania','Mauritius','Mexico','Micronesia','Moldova','Monaco','Mongolia','Montenegro','Morocco','Mozambique','Myanmar','Namibia','Nauru','Nepal','Netherlands','New Zealand','Nicaragua','Niger','Nigeria','North Korea','North Macedonia','Norway','Oman','Pakistan','Palau','Palestine','Panama','Papua New Guinea','Paraguay','Peru','Philippines','Poland','Portugal','Qatar','Romania','Russia','Rwanda','Saint Kitts and Nevis','Saint Lucia','Saint Vincent and the Grenadines','Samoa','San Marino','Sao Tome and Principe','Saudi Arabia','Senegal','Serbia','Seychelles','Sierra Leone','Singapore','Slovakia','Slovenia','Solomon Islands','Somalia','South Africa','South Korea','South Sudan','Soviet Union','Spain','Sri Lanka','Sudan','Suriname','Sweden','Switzerland','Syria','Taiwan','Tajikistan','Tanzania','Thailand','Timor-Leste','Togo','Tonga','Trinidad and Tobago','Tunisia','Turkey','Turkmenistan','Tuvalu','Uganda','Ukraine','United Arab Emirates','United Kingdom','United States','United States of America','Uruguay','Uzbekistan','Vanuatu','Vatican City','Venezuela','Vietnam','Yemen','Zambia','Zimbabwe'
    ];
    $countries = array_values(array_unique($countries));
    sort($countries, SORT_NATURAL | SORT_FLAG_CASE);
    return $countries;
}

function bm_languages(): array {
    $languages = ['English','Persian (Farsi)','Spanish','French','German','Italian','Portuguese','Russian','Arabic','Turkish','Dutch','Polish','Ukrainian','Romanian','Czech','Swedish','Greek','Hungarian','Hebrew','Thai','Vietnamese','Korean','Japanese','Chinese (Mandarin)','Hindi','Bengali','Urdu','Malay','Indonesian','Filipino','Swahili','Afrikaans','Serbian','Croatian','Bulgarian','Slovak','Slovenian','Estonian','Latvian','Lithuanian','Georgian','Armenian','Azerbaijani','Kazakh','Uzbek','Turkmen','Tajik','Pashto','Nepali','Sinhala','Burmese','Khmer','Lao','Mongolian'];
    sort($languages, SORT_NATURAL | SORT_FLAG_CASE);
    return $languages;
}

function bm_rated_list(): array {
    return ['G','PG','PG-13','R','NC-17','TV-Y','TV-Y7','TV-G','TV-PG','TV-14','TV-MA'];
}

function bm_status_list(): array {
    return ['Returning Series','Ended','Canceled','In Production','Planned'];
}

function bm_genres(PDO $pdo): array {
    if (function_exists('getCachedGenres')) {
        try { return getCachedGenres($pdo); } catch (Throwable $e) {}
    }
    try {
        return $pdo->query("SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) as genre FROM movies CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 UNION SELECT 6 UNION SELECT 7 UNION SELECT 8) numbers WHERE genres IS NOT NULL AND genres != '' HAVING genre != '' AND genre IS NOT NULL ORDER BY genre")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        return ['Action','Adventure','Animation','Comedy','Crime','Drama','Family','Fantasy','History','Horror','Mystery','Romance','Sci-Fi','Thriller','War','Western','Biography','Sport','Documentary'];
    }
}

function bm_allowed_movie_type(string $type): string {
    $allowed = ['movie', 'tvSeries', 'tvMiniSeries', 'animation'];
    return in_array($type, $allowed, true) ? $type : 'movie';
}

function bm_clean_imdb(string $code): string {
    $code = trim($code);
    if ($code === '') return '';
    if (preg_match('/tt\d{5,12}/', $code, $m)) return $m[0];
    return preg_replace('/[^a-zA-Z0-9_\-]/', '', $code);
}

function bm_join_checked(?array $values): string {
    if (!$values) return '';
    $clean = [];
    foreach ($values as $v) {
        $v = trim((string)$v);
        if ($v !== '') $clean[] = $v;
    }
    return implode(', ', array_values(array_unique($clean)));
}

function bm_safe_int($value, int $min = 0, int $max = PHP_INT_MAX): int {
    $n = (int)$value;
    return max($min, min($max, $n));
}

function bm_safe_float($value, float $min = 0.0, float $max = 10.0): float {
    $n = (float)$value;
    return max($min, min($max, $n));
}

function bm_ensure_admin_logs(PDO $pdo): void {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS admin_logs (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            admin_id BIGINT NULL,
            action VARCHAR(80) NOT NULL,
            target_type VARCHAR(80) NULL,
            target_id VARCHAR(80) NULL,
            details TEXT NULL,
            ip_address VARCHAR(64) NULL,
            user_agent VARCHAR(255) NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_action_created (action, created_at),
            INDEX idx_target (target_type, target_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    } catch (Throwable $e) {
        error_log('Admin logs table error: ' . $e->getMessage());
    }
}

function bm_admin_log(PDO $pdo, string $action, ?string $targetType = null, $targetId = null, $details = null): void {
    try {
        bm_ensure_admin_logs($pdo);
        $admin = bm_current_admin();
        $stmt = $pdo->prepare("INSERT INTO admin_logs (admin_id, action, target_type, target_id, details, ip_address, user_agent) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $admin['id'] ?? null,
            $action,
            $targetType,
            $targetId !== null ? (string)$targetId : null,
            $details !== null ? (is_string($details) ? $details : bm_json($details)) : null,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 250),
        ]);
    } catch (Throwable $e) {
        error_log('Admin log insert error: ' . $e->getMessage());
    }
}

function bm_safe_unlink_inside(string $baseDir, string $relativePath): bool {
    $base = realpath(__DIR__ . '/' . trim($baseDir, '/'));
    $target = realpath(__DIR__ . '/' . ltrim($relativePath, '/'));
    if (!$base || !$target) return false;
    if (!str_starts_with($target, $base . DIRECTORY_SEPARATOR)) return false;
    return is_file($target) ? @unlink($target) : false;
}

function bm_upload_poster_to_webp(array $file, string $nameBase): array {
    $maxBytes = 8 * 1024 * 1024;
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'فایل آپلود نشد'];
    }
    if (($file['size'] ?? 0) <= 0 || ($file['size'] ?? 0) > $maxBytes) {
        return ['success' => false, 'error' => 'حجم کاور باید کمتر از ۸ مگابایت باشد'];
    }
    $tmp = $file['tmp_name'] ?? '';
    $info = @getimagesize($tmp);
    if (!$info || empty($info['mime'])) {
        return ['success' => false, 'error' => 'فایل تصویر معتبر نیست'];
    }
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($info['mime'], $allowed, true)) {
        return ['success' => false, 'error' => 'فرمت کاور مجاز نیست'];
    }
    $safeName = preg_replace('/[^a-zA-Z0-9_\-]/', '', $nameBase) ?: uniqid('poster_', true);
    $dir = __DIR__ . '/posters';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $target = $dir . '/' . $safeName . '.webp';

    try {
        $image = null;
        if ($info['mime'] === 'image/jpeg') $image = @imagecreatefromjpeg($tmp);
        if ($info['mime'] === 'image/png') $image = @imagecreatefrompng($tmp);
        if ($info['mime'] === 'image/webp') $image = @imagecreatefromwebp($tmp);
        if (!$image) return ['success' => false, 'error' => 'پردازش تصویر ناموفق بود'];
        imagepalettetotruecolor($image);
        imagealphablending($image, true);
        imagesavealpha($image, true);
        $ok = imagewebp($image, $target, 82);
        imagedestroy($image);
        if (!$ok) return ['success' => false, 'error' => 'ذخیره کاور ناموفق بود'];
        @chmod($target, 0644);
        return ['success' => true, 'path' => 'posters/' . $safeName . '.webp'];
    } catch (Throwable $e) {
        error_log('Poster upload error: ' . $e->getMessage());
        return ['success' => false, 'error' => 'خطای داخلی هنگام آپلود کاور'];
    }
}

function bm_upload_story_file(array $file): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        return ['success' => false, 'error' => 'فایل استوری آپلود نشد'];
    }
    $tmp = $file['tmp_name'] ?? '';
    $name = (string)($file['name'] ?? '');
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $imageExt = ['jpg', 'jpeg', 'png', 'webp'];
    $videoExt = ['mp4', 'webm'];
    $isImage = in_array($ext, $imageExt, true);
    $isVideo = in_array($ext, $videoExt, true);
    if (!$isImage && !$isVideo) {
        return ['success' => false, 'error' => 'فرمت استوری مجاز نیست'];
    }
    $maxBytes = $isVideo ? 60 * 1024 * 1024 : 10 * 1024 * 1024;
    if (($file['size'] ?? 0) <= 0 || ($file['size'] ?? 0) > $maxBytes) {
        return ['success' => false, 'error' => $isVideo ? 'حجم ویدیو باید کمتر از ۶۰ مگابایت باشد' : 'حجم تصویر باید کمتر از ۱۰ مگابایت باشد'];
    }
    if ($isImage && !@getimagesize($tmp)) {
        return ['success' => false, 'error' => 'تصویر استوری معتبر نیست'];
    }
    $dir = __DIR__ . '/uploads/stories';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $filename = bin2hex(random_bytes(16)) . '.' . $ext;
    $target = $dir . '/' . $filename;
    if (!move_uploaded_file($tmp, $target)) {
        return ['success' => false, 'error' => 'ذخیره استوری ناموفق بود'];
    }
    @chmod($target, 0644);
    return ['success' => true, 'type' => $isVideo ? 'video' : 'image', 'path' => 'uploads/stories/' . $filename];
}

function bm_insert_links(PDO $pdo, int $movieId, string $kind, array $qualities, array $urls, array $sizes, array $seasons = [], bool $isSeries = false): void {
    $table = $kind === 'dub' ? 'dubbed_links' : 'softsub_links';
    $hasSeason = bm_column_exists($pdo, $table, 'season');
    $sql = $hasSeason ? "INSERT INTO `$table` (movie_id, quality, url, size, season) VALUES (?, ?, ?, ?, ?)" : "INSERT INTO `$table` (movie_id, quality, url, size) VALUES (?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $count = max(count($qualities), count($urls), count($sizes));
    for ($i = 0; $i < $count; $i++) {
        $url = trim((string)($urls[$i] ?? ''));
        if ($url === '') continue;
        $quality = trim((string)($qualities[$i] ?? 'Unknown')) ?: 'Unknown';
        $size = trim((string)($sizes[$i] ?? ''));
        if ($hasSeason) {
            $season = $isSeries ? max(1, (int)($seasons[$i] ?? 1)) : null;
            $stmt->execute([$movieId, $quality, $url, $size, $season]);
        } else {
            $stmt->execute([$movieId, $quality, $url, $size]);
        }
    }
}

function bm_recalculate_movie_rating(PDO $pdo, int $movieId): void {
    if (!bm_table_exists($pdo, 'movie_ratings') || !bm_table_exists($pdo, 'comments')) return;
    try {
        $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM comments WHERE movie_id = ? AND rating > 0 AND status = 'approved' AND (parent_id IS NULL OR parent_id = 0)");
        $stmt->execute([$movieId]);
        $data = $stmt->fetch() ?: ['avg_rating' => 0, 'total_votes' => 0];
        $avg = round((float)($data['avg_rating'] ?? 0), 2);
        $total = (int)($data['total_votes'] ?? 0);
        $ratingStmt = $pdo->prepare("UPDATE movie_ratings SET avg_rating = ?, total_votes = ? WHERE movie_id = ?");
        $ratingStmt->execute([$avg, $total, $movieId]);
        $check = $pdo->prepare("SELECT COUNT(*) FROM movie_ratings WHERE movie_id = ?");
        $check->execute([$movieId]);
        if ((int)$check->fetchColumn() < 1) {
            $pdo->prepare("INSERT INTO movie_ratings (movie_id, avg_rating, total_votes) VALUES (?, ?, ?)")->execute([$movieId, $avg, $total]);
        }
    } catch (Throwable $e) {
        error_log('Rating recalc error: ' . $e->getMessage());
    }
}

function bm_get_dashboard_stats(PDO $pdo): array {
    return [
        'movies_total' => bm_count($pdo, "SELECT COUNT(*) FROM movies"),
        'movies' => bm_count($pdo, "SELECT COUNT(*) FROM movies WHERE type = 'movie'"),
        'series' => bm_count($pdo, "SELECT COUNT(*) FROM movies WHERE type LIKE '%Series%' OR type IN ('tvSeries','tvMiniSeries')"),
        'links' => bm_count($pdo, "SELECT (SELECT COUNT(*) FROM softsub_links) + (SELECT COUNT(*) FROM dubbed_links)"),
        'comments_approved' => bm_table_exists($pdo, 'comments') ? bm_count($pdo, "SELECT COUNT(*) FROM comments WHERE status = 'approved'") : 0,
        'comments_pending' => bm_table_exists($pdo, 'comments') ? bm_count($pdo, "SELECT COUNT(*) FROM comments WHERE status = 'pending'") : 0,
        'users' => bm_table_exists($pdo, 'users') ? bm_count($pdo, "SELECT COUNT(*) FROM users") : 0,
        'admin_picks' => bm_table_exists($pdo, 'admin_picks') ? bm_count($pdo, "SELECT COUNT(*) FROM admin_picks") : 0,
        'stories' => bm_table_exists($pdo, 'stories') ? bm_count($pdo, "SELECT COUNT(*) FROM stories") : 0,
        'requests' => bm_table_exists($pdo, 'movie_requests') ? bm_count($pdo, "SELECT COUNT(*) FROM movie_requests") : 0,
        'reports' => bm_table_exists($pdo, 'link_reports') ? bm_count($pdo, "SELECT COUNT(*) FROM link_reports WHERE status IN ('new','pending')") : (bm_table_exists($pdo, 'broken_link_reports') ? bm_count($pdo, "SELECT COUNT(*) FROM broken_link_reports WHERE status IN ('new','pending')") : 0),
    ];
}
?>