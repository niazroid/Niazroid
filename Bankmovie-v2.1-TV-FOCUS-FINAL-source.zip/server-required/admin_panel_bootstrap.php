<?php
/**
 * BankMovie admin panel compatibility/bootstrap layer.
 * Repairs non-destructive schema differences after host/domain migrations.
 */
declare(strict_types=1);

if (!function_exists('admin_panel_table_exists')) {
    function admin_panel_table_exists(PDO $pdo, string $table): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            error_log('admin_panel_table_exists('.$table.'): '.$e->getMessage());
            return false;
        }
    }
}

if (!function_exists('admin_panel_column_exists')) {
    function admin_panel_column_exists(PDO $pdo, string $table, string $column): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
            $stmt->execute([$table, $column]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            error_log('admin_panel_column_exists('.$table.'.'.$column.'): '.$e->getMessage());
            return false;
        }
    }
}

if (!function_exists('admin_panel_index_exists')) {
    function admin_panel_index_exists(PDO $pdo, string $table, string $index): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $index)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ? LIMIT 1');
            $stmt->execute([$table, $index]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            error_log('admin_panel_index_exists('.$table.'.'.$index.'): '.$e->getMessage());
            return false;
        }
    }
}

if (!function_exists('admin_panel_add_column')) {
    function admin_panel_add_column(PDO $pdo, string $table, string $column, string $definition, array &$changes, array &$errors): void
    {
        if (!admin_panel_table_exists($pdo, $table) || admin_panel_column_exists($pdo, $table, $column)) return;
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return;
        try {
            $pdo->exec("ALTER TABLE `{$table}` ADD COLUMN `{$column}` {$definition}");
            $changes[] = "{$table}.{$column}";
        } catch (Throwable $e) {
            $errors[] = "افزودن ستون {$table}.{$column} انجام نشد: " . $e->getMessage();
        }
    }
}

if (!function_exists('admin_panel_ensure_dir')) {
    function admin_panel_ensure_dir(string $relative, array &$changes, array &$errors): bool
    {
        $relative = trim(str_replace('\\', '/', $relative), '/');
        if ($relative === '' || str_contains($relative, '..')) return false;
        $full = __DIR__ . '/' . $relative;
        if (!is_dir($full)) {
            if (!@mkdir($full, 0755, true) && !is_dir($full)) {
                $errors[] = "پوشه {$relative} ساخته نشد.";
                return false;
            }
            $changes[] = "پوشه {$relative}";
        }
        @chmod($full, 0755);
        if (!is_writable($full)) {
            $errors[] = "پوشه {$relative} قابل نوشتن نیست (Permission را روی 755 یا 775 بررسی کنید).";
            return false;
        }
        return true;
    }
}

if (!function_exists('admin_panel_bootstrap')) {
    function admin_panel_bootstrap(PDO $pdo, bool $force = false): array
    {
        static $cached = null;
        if (!$force && is_array($cached)) return $cached;

        $changes = [];
        $errors = [];

        foreach ([
            'posters', 'uploads', 'uploads/stories', 'uploads/slider',
            'uploads/collections', 'uploads/banners', 'logs', 'cache'
        ] as $dir) {
            admin_panel_ensure_dir($dir, $changes, $errors);
        }

        $createStatements = [
            'stories' => "CREATE TABLE IF NOT EXISTS stories (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                type VARCHAR(20) NOT NULL DEFAULT 'image',
                file_path VARCHAR(255) NOT NULL,
                caption TEXT NULL,
                link VARCHAR(500) NULL,
                story_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_story_order (story_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'story_views' => "CREATE TABLE IF NOT EXISTS story_views (
                story_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                viewed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (story_id, user_id),
                INDEX idx_story_views_user (user_id),
                INDEX idx_story_views_date (viewed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'slider_slides' => "CREATE TABLE IF NOT EXISTS slider_slides (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                image_path VARCHAR(255) NOT NULL,
                title_fa VARCHAR(255) NULL,
                title_en VARCHAR(255) NULL,
                subtitle_fa TEXT NULL,
                subtitle_en TEXT NULL,
                link VARCHAR(500) NULL,
                slide_order INT NOT NULL DEFAULT 0,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                rating DECIMAL(3,1) NOT NULL DEFAULT 0.0,
                votes VARCHAR(50) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NULL,
                PRIMARY KEY (id),
                INDEX idx_slider_order (slide_order),
                INDEX idx_slider_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'admin_picks' => "CREATE TABLE IF NOT EXISTS admin_picks (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                movie_id INT UNSIGNED NOT NULL,
                pick_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_admin_pick_movie (movie_id),
                INDEX idx_admin_pick_order (pick_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'collections' => "CREATE TABLE IF NOT EXISTS collections (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(255) NOT NULL,
                title_fa VARCHAR(255) NULL,
                slug VARCHAR(190) NOT NULL,
                description TEXT NULL,
                cover_image VARCHAR(255) NULL,
                status TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_collections_slug (slug),
                INDEX idx_collections_status (status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'collection_movies' => "CREATE TABLE IF NOT EXISTS collection_movies (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                collection_id INT UNSIGNED NOT NULL,
                movie_id INT UNSIGNED NOT NULL,
                sort_order INT NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY uq_collection_movie (collection_id, movie_id),
                INDEX idx_collection_sort (collection_id, sort_order),
                INDEX idx_collection_movie_id (movie_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'notifications' => "CREATE TABLE IF NOT EXISTS notifications (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                message TEXT NOT NULL,
                expires_at DATETIME NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_notifications_active (is_active, expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'movie_extra_info' => "CREATE TABLE IF NOT EXISTS movie_extra_info (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                imdb_code VARCHAR(32) NOT NULL,
                language TEXT NULL,
                production_companies TEXT NULL,
                status VARCHAR(100) NULL,
                rated VARCHAR(30) NULL,
                seasons INT NULL,
                episodes INT NULL,
                updated_at DATETIME NULL,
                PRIMARY KEY (id),
                UNIQUE KEY uq_movie_extra_imdb (imdb_code)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'movie_ratings' => "CREATE TABLE IF NOT EXISTS movie_ratings (
                movie_id INT UNSIGNED NOT NULL,
                avg_rating DECIMAL(4,2) NOT NULL DEFAULT 0,
                total_votes INT UNSIGNED NOT NULL DEFAULT 0,
                updated_at DATETIME NULL,
                PRIMARY KEY (movie_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'admin_banners' => "CREATE TABLE IF NOT EXISTS admin_banners (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(190) NOT NULL,
                position VARCHAR(80) NOT NULL DEFAULT 'home_top',
                image_path VARCHAR(255) NULL,
                link_url VARCHAR(500) NULL,
                starts_at DATETIME NULL,
                ends_at DATETIME NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NULL,
                PRIMARY KEY (id),
                INDEX idx_admin_banner_position (position),
                INDEX idx_admin_banner_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'admin_quick_replies' => "CREATE TABLE IF NOT EXISTS admin_quick_replies (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                title VARCHAR(120) NOT NULL,
                message TEXT NOT NULL,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NULL,
                PRIMARY KEY (id),
                INDEX idx_admin_qr_active (is_active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'admin_recycle_bin' => "CREATE TABLE IF NOT EXISTS admin_recycle_bin (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                item_type VARCHAR(40) NOT NULL,
                item_id INT UNSIGNED NOT NULL,
                title VARCHAR(255) NULL,
                payload LONGTEXT NOT NULL,
                deleted_by VARCHAR(120) NULL,
                restored_at DATETIME NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_admin_trash_item (item_type, item_id),
                INDEX idx_admin_trash_date (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
            'admin_activity_logs' => "CREATE TABLE IF NOT EXISTS admin_activity_logs (
                id INT UNSIGNED NOT NULL AUTO_INCREMENT,
                admin_name VARCHAR(120) NULL,
                action VARCHAR(120) NOT NULL,
                target_type VARCHAR(80) NULL,
                target_id INT NULL,
                details TEXT NULL,
                ip_address VARCHAR(64) NULL,
                user_agent VARCHAR(255) NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                INDEX idx_admin_log_date (created_at),
                INDEX idx_admin_log_action (action)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
        ];

        foreach ($createStatements as $table => $sql) {
            $before = admin_panel_table_exists($pdo, $table);
            try {
                $pdo->exec($sql);
                if (!$before && admin_panel_table_exists($pdo, $table)) $changes[] = "جدول {$table}";
            } catch (Throwable $e) {
                $errors[] = "ساخت/بررسی جدول {$table} انجام نشد: " . $e->getMessage();
            }
        }

        $columns = [
            'stories' => [
                'type' => "VARCHAR(20) NOT NULL DEFAULT 'image'",
                'file_path' => "VARCHAR(255) NULL",
                'caption' => "TEXT NULL",
                'link' => "VARCHAR(500) NULL",
                'story_order' => "INT NOT NULL DEFAULT 0",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP"
            ],
            'slider_slides' => [
                'image_path' => "VARCHAR(255) NULL",
                'title_fa' => "VARCHAR(255) NULL",
                'title_en' => "VARCHAR(255) NULL",
                'subtitle_fa' => "TEXT NULL",
                'subtitle_en' => "TEXT NULL",
                'link' => "VARCHAR(500) NULL",
                'slide_order' => "INT NOT NULL DEFAULT 0",
                'is_active' => "TINYINT(1) NOT NULL DEFAULT 1",
                'rating' => "DECIMAL(3,1) NOT NULL DEFAULT 0.0",
                'votes' => "VARCHAR(50) NULL",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP",
                'updated_at' => "DATETIME NULL"
            ],
            'admin_picks' => [
                'pick_order' => "INT NOT NULL DEFAULT 0",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP"
            ],
            'collections' => [
                'title_fa' => "VARCHAR(255) NULL",
                'slug' => "VARCHAR(190) NULL",
                'description' => "TEXT NULL",
                'cover_image' => "VARCHAR(255) NULL",
                'status' => "TINYINT(1) NOT NULL DEFAULT 1",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP",
                'updated_at' => "DATETIME NULL"
            ],
            'collection_movies' => [
                'sort_order' => "INT NOT NULL DEFAULT 0",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP"
            ],
            'notifications' => [
                'expires_at' => "DATETIME NULL",
                'is_active' => "TINYINT(1) NOT NULL DEFAULT 1",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP"
            ],
            'movie_extra_info' => [
                'language' => "TEXT NULL",
                'production_companies' => "TEXT NULL",
                'status' => "VARCHAR(100) NULL",
                'rated' => "VARCHAR(30) NULL",
                'seasons' => "INT NULL",
                'episodes' => "INT NULL",
                'updated_at' => "DATETIME NULL"
            ],
            'admin_banners' => [
                'title' => "VARCHAR(190) NOT NULL DEFAULT 'بنر تبلیغاتی'",
                'position' => "VARCHAR(80) NOT NULL DEFAULT 'home_top'",
                'image_path' => "VARCHAR(255) NULL",
                'link_url' => "VARCHAR(500) NULL",
                'starts_at' => "DATETIME NULL",
                'ends_at' => "DATETIME NULL",
                'is_active' => "TINYINT(1) NOT NULL DEFAULT 1",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP",
                'updated_at' => "DATETIME NULL"
            ],
            'admin_quick_replies' => [
                'title' => "VARCHAR(120) NULL",
                'message' => "TEXT NULL",
                'is_active' => "TINYINT(1) NOT NULL DEFAULT 1",
                'created_at' => "DATETIME NULL DEFAULT CURRENT_TIMESTAMP",
                'updated_at' => "DATETIME NULL"
            ],
            'movie_requests' => [
                'admin_response' => "TEXT NULL",
                'updated_at' => "DATETIME NULL"
            ],
            'softsub_links' => ['season' => "INT NULL"],
            'dubbed_links' => ['season' => "INT NULL"],
            'users' => ['first_comment_approved' => "TINYINT(1) NOT NULL DEFAULT 0"]
        ];

        foreach ($columns as $table => $defs) {
            foreach ($defs as $column => $definition) {
                admin_panel_add_column($pdo, $table, $column, $definition, $changes, $errors);
            }
        }

        // Normalize common legacy status values after host migrations.
        if (admin_panel_table_exists($pdo, 'collections') && admin_panel_column_exists($pdo, 'collections', 'status')) {
            try {
                $pdo->exec("UPDATE collections SET status = 1 WHERE LOWER(CAST(status AS CHAR)) <> '1' AND LOWER(CAST(status AS CHAR)) IN ('active','published','public','true','yes','on')");
                $pdo->exec("UPDATE collections SET status = 0 WHERE status IS NULL OR (LOWER(CAST(status AS CHAR)) <> '0' AND LOWER(CAST(status AS CHAR)) IN ('inactive','draft','private','false','no','off'))");
            } catch (Throwable $e) {
                $errors[] = 'یکسان‌سازی وضعیت کالکشن‌ها انجام نشد: ' . $e->getMessage();
            }
        }
        if (admin_panel_table_exists($pdo, 'slider_slides') && admin_panel_column_exists($pdo, 'slider_slides', 'is_active')) {
            try {
                $pdo->exec("UPDATE slider_slides SET is_active = 1 WHERE LOWER(CAST(is_active AS CHAR)) <> '1' AND LOWER(CAST(is_active AS CHAR)) IN ('active','published','true','yes','on')");
                $pdo->exec("UPDATE slider_slides SET is_active = 0 WHERE is_active IS NULL OR (LOWER(CAST(is_active AS CHAR)) <> '0' AND LOWER(CAST(is_active AS CHAR)) IN ('inactive','draft','false','no','off'))");
            } catch (Throwable $e) {
                $errors[] = 'یکسان‌سازی وضعیت اسلایدر انجام نشد: ' . $e->getMessage();
            }
        }

        // Normalize ordering after migration without deleting any content.
        foreach ([['stories', 'story_order'], ['slider_slides', 'slide_order'], ['admin_picks', 'pick_order']] as [$table, $column]) {
            if (!admin_panel_table_exists($pdo, $table) || !admin_panel_column_exists($pdo, $table, $column)) continue;
            try {
                $rows = $pdo->query("SELECT id, `{$column}` AS current_order FROM `{$table}` ORDER BY `{$column}` ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
                $stmt = $pdo->prepare("UPDATE `{$table}` SET `{$column}` = ? WHERE id = ?");
                foreach ($rows as $order => $row) {
                    if ((int)($row['current_order'] ?? -1) !== (int)$order) {
                        $stmt->execute([(int)$order, (int)$row['id']]);
                    }
                }
            } catch (Throwable $e) {
                $errors[] = "مرتب‌سازی اولیه {$table} انجام نشد: " . $e->getMessage();
            }
        }

        $cached = [
            'ok' => count($errors) === 0,
            'changes' => array_values(array_unique($changes)),
            'errors' => array_values(array_unique($errors)),
            'checked_at' => date('c')
        ];

        if ($errors) {
            error_log('[BankMovie admin bootstrap] ' . implode(' | ', $errors));
        }
        return $cached;
    }
}

if (!function_exists('admin_panel_upload_error_message')) {
    function admin_panel_upload_error_message(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_OK => '',
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'حجم فایل بیشتر از محدودیت آپلود سرور است.',
            UPLOAD_ERR_PARTIAL => 'فایل ناقص آپلود شد. دوباره تلاش کنید.',
            UPLOAD_ERR_NO_FILE => 'هیچ فایلی انتخاب نشده است.',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت آپلود روی هاست موجود نیست.',
            UPLOAD_ERR_CANT_WRITE => 'هاست اجازه نوشتن فایل را نمی‌دهد.',
            UPLOAD_ERR_EXTENSION => 'آپلود توسط یکی از افزونه‌های PHP متوقف شد.',
            default => 'آپلود فایل با خطای ناشناخته متوقف شد.'
        };
    }
}
