-- BankMovie comment public display verification
SELECT DATABASE() AS current_database;

SELECT CAST(status AS CHAR) AS status_value, COUNT(*) AS total
FROM archive1_comments
GROUP BY CAST(status AS CHAR)
ORDER BY total DESC;

SELECT
  c.id,
  c.movie_id,
  c.username,
  CAST(c.status AS CHAR) AS status_value,
  c.parent_id,
  c.created_at,
  ai.archive_no,
  ai.slug,
  ai.item_title_fa,
  ai.item_title,
  ai.item_year,
  ai.item_link
FROM archive1_comments c
LEFT JOIN archive1_items ai ON ai.virtual_movie_id = c.movie_id
WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')
ORDER BY c.id DESC
LIMIT 100;

SELECT c.movie_id, COUNT(*) AS public_comments, ai.archive_no, ai.slug, ai.item_title_fa, ai.item_year
FROM archive1_comments c
LEFT JOIN archive1_items ai ON ai.virtual_movie_id = c.movie_id
WHERE LOWER(TRIM(CAST(c.status AS CHAR))) IN ('approved','active','1')
  AND (c.parent_id IS NULL OR c.parent_id = 0)
GROUP BY c.movie_id, ai.archive_no, ai.slug, ai.item_title_fa, ai.item_year
ORDER BY public_comments DESC;
