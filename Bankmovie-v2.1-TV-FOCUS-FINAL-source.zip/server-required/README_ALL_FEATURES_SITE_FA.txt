نصب پچ یکپارچه بانک مووی ۲.۱

۱) قبل از هر کار از دیتابیس و public_html بکاپ بگیرید.
۲) محتویات این بسته را در ریشه سایت Extract و Overwrite کنید.
۳) این بسته config.php، رمز دیتابیس و bankmovie_remote_config.json فعال شما را ندارد.
۴) با حساب مدیر وارد شوید و /bm_admin.php را باز کنید.
۵) تنظیمات را ذخیره کنید تا bankmovie_remote_config.json به‌صورت اتمیک ساخته/به‌روزرسانی شود.
۶) /admin_comment_diagnostic.php را برای بررسی جداول کامنت و اعلان باز کنید.
۷) اگر هاست اجازه ALTER TABLE از PHP نمی‌دهد، فایل bankmovie_v2_1_all_features_migration.sql را یک‌بار در phpMyAdmin اجرا کنید.

نکته: گزارش خرابی لینک دانلود در این نسخه اضافه نشده است. گزارش تخلف کامنت فعال و مستقل است.
