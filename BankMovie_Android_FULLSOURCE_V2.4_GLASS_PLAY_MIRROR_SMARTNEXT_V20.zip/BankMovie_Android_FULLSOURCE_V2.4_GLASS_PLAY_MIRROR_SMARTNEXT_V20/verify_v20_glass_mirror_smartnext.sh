#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYVERIFY'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
p=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
assert 'detailWatchlistButton' not in m, 'floating watchlist on hero was not removed'
assert 'topMargin = dp(262)' in m and 'Color.argb(192, 45, 54, 67)' in m
assert 'mirroredArchiveRequest' in m and 'api5.php' in m and 'api4.php' in m
assert 'sourceDown && (mirroredArchiveRequest || isApiRequest)' in m
assert 'code == 401 || code == 403 || code == 429' in m
assert 'workingArchiveMirrorHosts' in m and 'absolutizeMirrorArtwork' in m
assert 'maybePromptNextEpisode(time: Long, length: Long, atEnd: Boolean = false)' in p
assert 'atEnd = true' in p and 'nextPromptShownKey == key' in p
assert 'time.toDouble() / length.toDouble() < 0.98' in p
assert 'player?.isPlaying != true' in p
# 95% of a long episode used to interrupt 3+ minutes early.
def prompt_at(length_seconds, played_seconds):
    length=length_seconds*1000
    played=played_seconds*1000
    remaining=max(0, length-played)
    threshold=min(20000,max(6000,length//100))
    return remaining<=threshold and played/length >=.98
assert not prompt_at(3600,3420)
assert not prompt_at(3600,3570)
assert prompt_at(3600,3585)
assert not prompt_at(1200,1170)
assert prompt_at(1200,1190)
print('V20_STATIC_CONTRACTS_AND_NEXT_EPISODE_BOUNDARIES_OK')
PYVERIFY
