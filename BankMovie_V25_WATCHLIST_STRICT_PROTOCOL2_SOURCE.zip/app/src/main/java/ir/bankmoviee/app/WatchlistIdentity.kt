package ir.bankmoviee.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * Watchlist wire/storage format V2: identities only.
 * Never persist titles, posters, playback links or detail JSON with favorites.
 * In-memory visuals are optional; they disappear when the process terminates.
 */
object WatchlistIdentity {
    private const val MAX_VISUALS = 300
    private val visuals = LinkedHashMap<String, JSONObject>(MAX_VISUALS, 0.75f, true)
    private val visualKeys = listOf(
        "title", "title_fa", "poster", "image", "cover_image", "backdrop",
        "rating", "year", "imdb_code", "source_url", "web_url_abs", "source", "slug"
    )

    fun onlyId(item: JSONObject): JSONObject {
        val oldKey = item.optString("_key").ifBlank { item.optString("storage_key") }.trim()
        val parts = oldKey.split('|', limit = 3)
        val rawArchive = item.optInt("archive", parts.getOrNull(0)?.toIntOrNull() ?: 1)
        var archive = rawArchive.coerceIn(1, 9)
        val type = item.optString("type").ifBlank { parts.getOrNull(1).orEmpty() }.ifBlank { "movie" }
        var id = item.optString("id")
            .ifBlank { item.optString("movie_id") }
            .ifBlank { item.optString("detail_id") }
            .ifBlank { item.optString("db_id") }
            .ifBlank { item.optString("slug") }
            .ifBlank { parts.getOrNull(2).orEmpty() }
        if (archive == 4 && item.optString("detail_id").isNotBlank()) {
            id = item.optString("detail_id")
        }
        // A genuinely unidentifiable old row must never be silently destroyed.
        if (id.isBlank()) return JSONObject().apply { put("_key", oldKey); put("archive", archive); put("type", type); put("id", "") }
        // Older APKs used archive=2 for SerialBlog. Numeric archive-2 IDs are
        // from the local movies DB; old text slugs are archive 4 instead.
        val legacySource = item.optString("source").lowercase()
        val legacySerialBlog = archive == 2 && (
            legacySource in setOf("serialblog", "sb", "archive4") ||
            (item.optInt("db_id", 0) <= 0 && id.any { !it.isDigit() } &&
                legacySource !in setOf("db_movies", "database", "local_db", "collection", "website_db"))
        )
        if (legacySerialBlog) archive = 4
        // If a stale _key disagrees with the resolved archive, canonicalize it.
        val oldArchive = oldKey.substringBefore('|').toIntOrNull()
        val key = if (legacySerialBlog || (oldArchive != null && oldArchive != archive))
            "$archive|$type|$id" else oldKey.ifBlank { "$archive|$type|$id" }
        return JSONObject().apply {
            put("_key", key)
            put("archive", archive)
            put("type", type)
            put("id", id)
            // Database numeric ID is an identity, not descriptive metadata.
            val dbId = item.optInt("db_id", 0)
            if (archive == 2 && dbId > 0 && dbId.toString() != id) put("db_id", dbId)
        }
    }

    fun clearVisuals() { synchronized(visuals) { visuals.clear() } }

    /** Strict wire format: a protocol-2 response cannot contain legacy cards. */
    fun acceptsServerItems(json: JSONObject?): Boolean {
        if (json?.optInt("watchlist_protocol", 0) != 2) return false
        val items = json.optJSONArray("items") ?: return false
        val fields = setOf("_key", "archive", "type", "id")
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: return false
            val key = item.optString("_key")
            val id = item.optString("id")
            val type = item.optString("type")
            val archive = item.optInt("archive", 0)
            if (archive !in 1..5 || id.isBlank() || type.isBlank() || key != "$archive|$type|$id" || key.length > 190) return false
            if (item.keys().asSequence().toSet() != fields) return false
        }
        return true
    }

    fun remember(item: JSONObject, requestedKey: String? = null) {
        val key = requestedKey ?: onlyId(item).optString("_key")
        if (key.isBlank()) return
        val data = JSONObject()
        visualKeys.forEach { field ->
            if (item.has(field) && !item.isNull(field)) data.put(field, item.opt(field))
        }
        val placeholder = "#${onlyId(item).optString("id")}"
        if (data.optString("title_fa") == placeholder || data.optString("title") == placeholder) return
        if (data.optString("title").isBlank() &&
            data.optString("title_fa").isBlank() &&
            data.optString("poster").isBlank()) return
        synchronized(visuals) {
            visuals[key] = data
            if (visuals.size > MAX_VISUALS) visuals.remove(visuals.keys.first())
        }
    }

    fun hasVisual(item: JSONObject): Boolean {
        val key = onlyId(item).optString("_key")
        return synchronized(visuals) { visuals.containsKey(key) }
    }

    fun withVisual(item: JSONObject): JSONObject {
        val identity = onlyId(item)
        val key = identity.optString("_key")
        val metadata = synchronized(visuals) { visuals[key]?.let { JSONObject(it.toString()) } }
        metadata?.let { src ->
            visualKeys.forEach { field -> if (src.has(field)) identity.put(field, src.opt(field)) }
        }
        if (identity.optString("title_fa").isBlank() && identity.optString("title").isBlank()) {
            identity.put("title_fa", "#${identity.optString("id")}")
        }
        return identity
    }

    fun compactArray(array: JSONArray): JSONArray {
        val output = JSONArray()
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { item ->
                output.put(onlyId(item))
            }
        }
        return output
    }
}
