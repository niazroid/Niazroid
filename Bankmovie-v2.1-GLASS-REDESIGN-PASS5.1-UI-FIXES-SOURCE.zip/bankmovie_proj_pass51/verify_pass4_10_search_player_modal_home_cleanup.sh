#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$MAIN"

grep -F 'PASS 4.10: search is now a direct catalogue grid.' "$MAIN"
grep -F 'private fun searchCatalogueCard(item: JSONObject, width: Int, height: Int): View' "$MAIN"
grep -F 'remaining < dp(if (tv) 900 else 720)' "$MAIN"
grep -F 'loadPage(nextPage, generation)' "$MAIN"
grep -F 'debounce.postDelayed(pendingSearch!!, 320L)' "$MAIN"

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
home=s[s.index('    private fun showHome()'):s.index('    private fun openTelegramChannel()', s.index('    private fun showHome()'))]
assert 'playlistGuideCard(compact = true)' not in home, 'archive guide still exists on Home'
advanced=s[s.index('    private fun showAdvancedSearchResults('):s.index('    private fun showSearch(', s.index('    private fun showAdvancedSearchResults('))]
assert 'moreButton(' not in advanced, 'Advanced search still has a Load More button'
assert 'setOnScrollChangeListener' in advanced
search=s[s.index('    private fun showSearch('):s.index('    private fun liveSearch(', s.index('    private fun showSearch('))]
assert 'moreButton(' not in search, 'Search still has a Load More button'
assert 'searchResultRow(' not in search, 'legacy search suggestion rows still active'
assert 'searchCatalogueCard(' in search
assert 'setOnScrollChangeListener' in search
assert 'از آرشیوهای مختلف تست کنید تا نتیجه موردنظر پیدا شود.' in search
assert 'val typeTabs' not in search
assert 'val filterState = arrayOf("all")' in search
player=s[s.index('    private fun showPlaybackMethodDialog('):s.index('    private fun openPlayer(', s.index('    private fun showPlaybackMethodDialog('))]
for marker in ['انتخاب برنامه…', 'dp(54)', 'dp(64)', 'dp(88)', 'dp(58)', 'resources.displayMetrics.widthPixels - dp(14)']:
    assert marker in player, marker
assert 'ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT' not in player, 'player modal still forces full width'
assert 'showWatchPartyStartConfirmation(title) { startActivity(intent) }' in s
assert 'آماده‌ام شروع کن' in s
assert 'downloadGroupCard(item, all, title, arr, false)' in s
print('PASS4_10_SEARCH_PLAYER_MODAL_HOME_CLEANUP_OK')
PY
