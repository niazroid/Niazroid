package ir.bankmoviee.app

// From Uiverse.io by KSAplay - https://uiverse.io/KSAplay/shy-rat-62
// MIT License, Copyright (c) KSAplay (Kenny)
// Native Android adaptation: preserve the rounded dark track, orange/yellow
// striped fill and blinking dots. The width is driven ONLY by actual APK bytes.

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.min

/** Completely isolated from MainActivity's fragile TV Home DPAD/focus handling. */
class TvAppUpdateActivity : Activity() {
    companion object {
        const val EXTRA_APK_URL = "tv_update_apk_url"
        const val EXTRA_EXPECTED_SHA256 = "tv_update_sha256"
        const val EXTRA_VERSION_CODE = "tv_update_version_code"
        const val EXTRA_VERSION_NAME = "tv_update_version_name"
        private const val MAX_APK_BYTES = 600L * 1024L * 1024L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val cancelled = AtomicBoolean(false)
    private var working = false
    @Volatile private var activeConnection: HttpURLConnection? = null
    private var verifiedFile: File? = null
    private lateinit var apkUrl: String
    private var expectedHash = ""
    private var targetCode = 0
    private var targetName = ""
    private lateinit var status: TextView
    private lateinit var errorDetails: TextView
    private lateinit var percentage: TextView
    private lateinit var byteCount: TextView
    private lateinit var speed: TextView
    private lateinit var eta: TextView
    private lateinit var startButton: TextView
    private lateinit var installButton: TextView
    private lateinit var cancelButton: TextView
    private lateinit var bar: TvUiverseProgressView
    private var dotFrame = 0
    private val dotTicker = object : Runnable {
        override fun run() {
            if (!isFinishing && working) {
                dotFrame = (dotFrame + 1) % 4
                status.text = "در حال دریافت نسخه جدید" + ".".repeat(dotFrame)
                mainHandler.postDelayed(this, 450L)
            }
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density + .5f).toInt()
    private fun bg(start: Int, end: Int, stroke: Int, radius: Int = 20) =
        GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(start, end)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = value
            textSize = size
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
            includeFontPadding = false
        }

    private fun action(label: String, colors: IntArray, onClick: () -> Unit): TextView =
        text(label, 17f, Color.WHITE, true).apply {
            isFocusable = true
            isClickable = true
            minHeight = dp(58)
            setPadding(dp(20), dp(10), dp(20), dp(10))
            val first = colors[0]
            val second = colors[1]
            fun paintFocus(focused: Boolean) {
                background = bg(
                    if (focused) first else Color.rgb(13, 33, 59),
                    if (focused) second else Color.rgb(8, 22, 43),
                    if (focused) Color.rgb(238, 249, 255) else Color.rgb(47, 98, 151), 16
                )
                elevation = if (focused) dp(8).toFloat() else 0f
                animate().cancel()
                animate().scaleX(if (focused) 1.035f else 1f)
                    .scaleY(if (focused) 1.035f else 1f).setDuration(125).start()
            }
            setOnFocusChangeListener { _, focused -> paintFocus(focused) }
            paintFocus(false)
            setOnClickListener { if (isEnabled) onClick() }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        apkUrl = intent.getStringExtra(EXTRA_APK_URL).orEmpty().trim()
        expectedHash = intent.getStringExtra(EXTRA_EXPECTED_SHA256).orEmpty().lowercase(Locale.ROOT)
        targetCode = intent.getIntExtra(EXTRA_VERSION_CODE, 0)
        targetName = intent.getStringExtra(EXTRA_VERSION_NAME).orEmpty()
        window.statusBarColor = Color.rgb(3, 12, 28)
        window.navigationBarColor = Color.rgb(3, 12, 28)
        buildUi()
        if (!apkUrl.startsWith("https://", true) || (expectedHash.isNotEmpty() &&
                    !expectedHash.matches(Regex("[a-f0-9]{64}")))) {
            setError("لینک HTTPS یا شناسه امنیتی فایل APK معتبر نیست.")
            startButton.isEnabled = false
            return
        }
        // A successfully downloaded file can be reopened without downloading twice.
        val completed = finalFile()
        if (completed.isFile) {
            status.text = "در حال بررسی فایل ذخیره‌شده..."
            Thread {
                try {
                    verifyDownloadedApk(completed)
                    onUi { showReady(completed) }
                } catch (_: Exception) {
                    completed.delete()
                    onUi { status.text = "آماده دانلود آپدیت" }
                }
            }.start()
        }
    }

    private fun buildUi() {
        val dark = Color.rgb(3, 12, 28)
        val white = Color.rgb(247, 251, 255)
        val muted = Color.rgb(169, 193, 222)
        val root = ScrollView(this).apply {
            isFillViewport = true
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                dark, Color.rgb(4, 26, 53), Color.rgb(3, 12, 28)
            ))
            clipToPadding = false
        }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(24), dp(22), dp(24))
        }
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(26), dp(28), dp(27))
            background = bg(Color.rgb(12, 39, 76), Color.rgb(4, 16, 35), Color.rgb(44, 122, 204), 26)
        }
        panel.addView(ImageView(this).apply {
            setImageResource(R.drawable.bm_ic_update_download_user)
            clearColorFilter()
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = bg(Color.rgb(18, 123, 226), Color.rgb(5, 77, 168), Color.rgb(86, 203, 255), 19)
        }, LinearLayout.LayoutParams(dp(72), dp(72)).apply { bottomMargin = dp(12) })
        panel.addView(text("BANKMOVIE  /  TV UPDATE", 12f, Color.rgb(104, 206, 255), true))
        panel.addView(text("به‌روزرسانی بانک‌مووی", 26f, white, true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        panel.addView(text("دانلود مستقیم و امن • بررسی امضا • نصب با کنترل تلویزیون", 13f, muted),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        val ver = if (targetName.isBlank()) "نسخه جدید" else "نسخه $targetName"
        panel.addView(text(ver, 14f, Color.rgb(253, 204, 93), true),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(13) })

        status = text("آماده دانلود آپدیت", 17f, white, true).apply {
            maxLines = 2
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        panel.addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) })
        // Keep long HTML/CDN messages out of the headline and action row.
        errorDetails = text("", 12f, Color.rgb(255, 189, 180)).apply {
            maxLines = 5
            visibility = View.GONE
            setLineSpacing(dp(3).toFloat(), 1.04f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            background = bg(Color.rgb(54, 20, 35), Color.rgb(29, 16, 30), Color.rgb(148, 69, 83), 12)
        }
        panel.addView(errorDetails, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        bar = TvUiverseProgressView(this)
        panel.addView(bar, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(14) })
        percentage = text("—", 24f, Color.rgb(255, 209, 111), true)
        panel.addView(percentage, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        byteCount = text("۰ مگابایت دریافت‌شده", 13f, muted)
        panel.addView(byteCount, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        speed = text("سرعت: —", 13f, muted)
        eta = text("زمان باقی‌مانده: —", 13f, muted)
        val metrics = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(speed, LinearLayout.LayoutParams(0, -2, 1f))
            addView(eta, LinearLayout.LayoutParams(0, -2, 1f))
        }
        panel.addView(metrics, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            weightSum = 3f
        }
        startButton = action("شروع دانلود", intArrayOf(Color.rgb(242, 151, 20), Color.rgb(249, 197, 79))) { startDownload() }
        installButton = action("آماده نصب", intArrayOf(Color.rgb(15, 126, 228), Color.rgb(42, 187, 244))) { beginInstall() }
        cancelButton = action("خروج از برنامه", intArrayOf(Color.rgb(68, 94, 128), Color.rgb(33, 56, 83))) {
            exitUpdater()
        }
        installButton.isEnabled = false
        installButton.alpha = .48f
        for (btn in arrayOf(startButton, installButton, cancelButton)) {
            controls.addView(btn, LinearLayout.LayoutParams(0, dp(62), 1f).apply {
                marginStart = dp(5); marginEnd = dp(5)
            })
        }
        panel.addView(controls, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(24) })
        panel.addView(text("نصب نسخه جدید فقط با تأیید خود شما و پنجره نصب اندروید انجام می‌شود.", 11f, muted),
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        val width = min(dp(840), resources.displayMetrics.widthPixels - dp(36)).coerceAtLeast(dp(290))
        outer.addView(panel, LinearLayout.LayoutParams(width, -2))
        root.addView(outer, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)
        // Native DPAD focus, no custom MainActivity TV rail focus handler.
        startButton.requestFocus()
    }

    /** Back and the visible exit control both leave the entire TV task, including the update gate. */
    private fun exitUpdater() {
        cancelled.set(true)
        activeConnection?.disconnect()
        mainHandler.removeCallbacks(dotTicker)
        finishAffinity()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { exitUpdater() }

    private fun workFolder(): File = File(filesDir, "updates").also { it.mkdirs() }
    private fun fileTag(): String = if (targetCode > 0) targetCode.toString() else "latest"
    private fun finalFile(): File = File(workFolder(), "bankmovie-tv-${fileTag()}.apk")
    private fun partialFile(): File = File(workFolder(), "bankmovie-tv-${fileTag()}.part")
    private fun onUi(block: () -> Unit) = runOnUiThread { if (!isFinishing && !isDestroyed) block() }
    private fun size(value: Long): String = String.format(Locale.US, "%.1f MB", value.toDouble() / 1_048_576.0)
    private fun setError(message: String) {
        status.text = "خطا در دریافت آپدیت"
        status.setTextColor(Color.rgb(255, 218, 208))
        errorDetails.text = message
        errorDetails.visibility = View.VISIBLE
        speed.text = "وضعیت: ناموفق"
    }

    private fun startDownload() {
        if (working) return
        working = true
        cancelled.set(false)
        verifiedFile = null
        status.setTextColor(Color.rgb(247, 251, 255))
        errorDetails.visibility = View.GONE
        status.text = "در حال اتصال به سرور..."
        installButton.isEnabled = false
        installButton.alpha = .48f
        startButton.isEnabled = false
        startButton.alpha = .48f
        startButton.text = "در حال دریافت"
        cancelButton.text = "خروج از برنامه"
        bar.isActive = true
        mainHandler.removeCallbacks(dotTicker)
        mainHandler.post(dotTicker)
        Thread {
            try {
                downloadApk()
                if (cancelled.get()) throw InterruptedException("Download stopped")
                onUi { status.text = "در حال بررسی امضا و سلامت APK..." }
                val saved = finalFile()
                verifyDownloadedApk(saved)
                onUi { showReady(saved) }
            } catch (e: Exception) {
                val msg = when (e) {
                    is InterruptedException -> "دانلود متوقف شد؛ برای ادامه، دوباره شروع دانلود را بزنید."
                    else -> "خطای دانلود: " + (e.message ?: "نامشخص")
                }
                onUi {
                    setError(msg.take(240))
                    bar.isActive = false
                    startButton.isEnabled = true
                    startButton.alpha = 1f
                    startButton.text = "تلاش مجدد / ادامه"
                    cancelButton.text = "خروج از برنامه"
                }
            } finally {
                onUi { working = false; mainHandler.removeCallbacks(dotTicker) }
            }
        }.start()
    }

    private fun connect(initial: URL, start: Long): Pair<HttpURLConnection, URL> {
        var u = initial
        repeat(6) { redirects ->
            if (u.protocol != "https" || u.userInfo != null) throw IllegalStateException("لینک دانلود باید HTTPS امن باشد")
            val con = (u.openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 15000
                readTimeout = 30000
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Accept", "application/vnd.android.package-archive,application/octet-stream,*/*")
                // PHP download gateways and CDNs often give custom-bot user agents an HTML challenge.
                // A normal browser UA is compatible with public APK downloads on Android TV.
                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 11; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
                if (start > 0L) setRequestProperty("Range", "bytes=$start-")
            }
            val code = con.responseCode
            if (code in 300..399) {
                val location = con.getHeaderField("Location") ?: throw IllegalStateException("آدرس انتقال دانلود خالی است")
                val redirected = URL(u, location)
                con.disconnect()
                if (redirected.protocol != "https") throw IllegalStateException("انتقال به آدرس ناامن مسدود شد")
                u = redirected
            } else {
                return Pair(con, u)
            }
            if (redirects == 5) throw IllegalStateException("تعداد انتقال دانلود بیش از حد است")
        }
        throw IllegalStateException("خطا در اتصال دانلود")
    }

    private fun downloadApk() {
        val part = partialFile()
        val finished = finalFile()
        finished.delete()
        val oldBytes = if (part.isFile) part.length() else 0L
        if (oldBytes > MAX_APK_BYTES) { part.delete(); throw IllegalStateException("اندازه فایل موقت غیرمجاز است") }
        val (connection, finalUrl) = connect(URL(apkUrl), oldBytes)
        activeConnection = connection
        try {
            val code = connection.responseCode
            if (code != 200 && code != 206) throw IllegalStateException("HTTP $code")
            val type = connection.contentType.orEmpty().lowercase(Locale.ROOT)
            if (type.contains("html") || type.contains("json") || type.contains("text/plain")) {
                // Never install HTML, including CDN/security challenge responses.
                throw IllegalStateException("پاسخ سرور فایل APK نیست (HTTP $code، $type). سرور: ${finalUrl.host}")
            }
            val encoding = connection.contentEncoding.orEmpty()
            if (encoding.isNotBlank() && !encoding.equals("identity", true)) {
                throw IllegalStateException("سرور فایل APK را فشرده فرستاده؛ محاسبه حجم مطمئن نیست")
            }
            val range = connection.getHeaderField("Content-Range").orEmpty()
            val resume = oldBytes > 0L && code == 206 && range.startsWith("bytes $oldBytes-")
            if (code == 206 && !resume && oldBytes > 0L) throw IllegalStateException("سرور ادامه دانلود را اشتباه پاسخ داده")
            val offset = if (resume) oldBytes else 0L
            var total = -1L
            if (resume) {
                val m = Regex("bytes [0-9]+-[0-9]+/([0-9]+)").find(range)
                total = m?.groupValues?.getOrNull(1)?.toLongOrNull() ?: -1L
            }
            if (total < 0L && connection.contentLengthLong >= 0L) total = offset + connection.contentLengthLong
            if (total > MAX_APK_BYTES) throw IllegalStateException("فایل از حد مجاز ۶۰۰ مگابایت بزرگ‌تر است")
            val stat = StatFs(workFolder().absolutePath)
            val remaining = if (total > 0) max(0L, total - offset) else 120L * 1024L * 1024L
            if (stat.availableBytes < remaining + 30L * 1024L * 1024L) throw IllegalStateException("فضای خالی تلویزیون برای نصب کافی نیست")
            var received = offset
            var previousBytes = offset
            var previousTime = SystemClock.elapsedRealtime()
            var avgSpeed = 0.0
            if (!resume) part.delete()
            connection.inputStream.use { input ->
                FileOutputStream(part, resume).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        if (cancelled.get()) throw InterruptedException("Cancelled")
                        val count = input.read(buffer)
                        if (count < 0) break
                        if (count == 0) continue
                        output.write(buffer, 0, count)
                        received += count
                        if (received > MAX_APK_BYTES) throw IllegalStateException("فایل بیش از حد مجاز است")
                        val now = SystemClock.elapsedRealtime()
                        if (now - previousTime >= 480L) {
                            val instant = (received - previousBytes).toDouble() * 1000 / max(1L, now - previousTime)
                            avgSpeed = if (avgSpeed <= 0) instant else avgSpeed * .6 + instant * .4
                            previousTime = now; previousBytes = received
                            updateDownloadUi(received, total, avgSpeed)
                        }
                    }
                    output.fd.sync()
                }
            }
            if (total > 0 && received != total) throw IllegalStateException("فایل ناقص دریافت شد ($received / $total)")
            if (received < 64_000) throw IllegalStateException("فایل APK معتبر یا کامل نیست")
            FileInputStream(part).use { stream ->
                val magic = ByteArray(4)
                if (stream.read(magic) != 4 || magic[0] != 0x50.toByte() || magic[1] != 0x4b.toByte()) {
                    part.delete()
                    throw IllegalStateException("پاسخ سرور APK نیست (احتمالاً صفحه خطای CDN)")
                }
            }
            if (!part.renameTo(finished)) throw IllegalStateException("ذخیره فایل نهایی ناموفق بود")
            updateDownloadUi(received, received, 0.0)
        } finally {
            connection.disconnect()
            if (activeConnection === connection) activeConnection = null
        }
    }

    private fun updateDownloadUi(done: Long, total: Long, speedBytesPerSec: Double) {
        onUi {
            val progress = if (total > 0) (done.toDouble() / total).coerceIn(0.0, 1.0).toFloat() else -1f
            bar.progress = progress
            percentage.text = if (progress >= 0) "${(progress * 100).toInt()}٪" else "حجم نامشخص"
            byteCount.text = if (total > 0) "${size(done)} از ${size(total)}" else "${size(done)} دریافت‌شده"
            speed.text = if (speedBytesPerSec > 0) "سرعت: ${size(speedBytesPerSec.toLong())}/s" else "سرعت: —"
            eta.text = if (total > 0 && speedBytesPerSec > 1) {
                "باقی‌مانده: ${((total - done) / speedBytesPerSec).toLong().coerceAtLeast(0L)} ثانیه"
            } else "باقی‌مانده: —"
        }
    }

    @Suppress("DEPRECATION")
    private fun verifyDownloadedApk(file: File) {
        if (!file.isFile || file.length() < 64_000) throw IllegalStateException("فایل APK یافت نشد")
        if (expectedHash.isNotBlank()) {
            val digest = MessageDigest.getInstance("SHA-256")
            FileInputStream(file).use { input ->
                val b = ByteArray(128 * 1024)
                while (true) {
                    val n = input.read(b)
                    if (n < 0) break
                    digest.update(b, 0, n)
                }
            }
            val got = digest.digest().joinToString("") { "%02x".format(it) }
            if (!got.equals(expectedHash, true)) { file.delete(); throw IllegalStateException("SHA-256 فایل با نسخه ثبت‌شده در پنل یکی نیست") }
        }
        val flags = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else PackageManager.GET_SIGNATURES
        val incoming = packageManager.getPackageArchiveInfo(file.absolutePath, flags)
            ?: throw IllegalStateException("فایل دریافت‌شده APK اندروید نیست")
        if (incoming.packageName != packageName) { file.delete(); throw IllegalStateException("شناسه APK با بانک‌مووی سازگار نیست") }
        val installed = packageManager.getPackageInfo(packageName, flags)
        val oldCode = if (Build.VERSION.SDK_INT >= 28) installed.longVersionCode else installed.versionCode.toLong()
        val newCode = if (Build.VERSION.SDK_INT >= 28) incoming.longVersionCode else incoming.versionCode.toLong()
        if (newCode <= oldCode) throw IllegalStateException("این APK جدیدتر از نسخه نصب‌شده نیست")
        if (targetCode > 0 && newCode != targetCode.toLong()) throw IllegalStateException("Version Code فایل با نسخه اعلام‌شده در پنل تطابق ندارد")
        fun certs(info: android.content.pm.PackageInfo): List<ByteArray> {
            val arr = if (Build.VERSION.SDK_INT >= 28) info.signingInfo?.apkContentsSigners else info.signatures
            return arr?.map { it.toByteArray() }.orEmpty()
        }
        val installedCerts = certs(installed)
        val incomingCerts = certs(incoming)
        if (installedCerts.isEmpty() || incomingCerts.isEmpty() ||
            installedCerts.size != incomingCerts.size || incomingCerts.any { newer -> installedCerts.none { it.contentEquals(newer) } }) {
            file.delete()
            throw IllegalStateException("امضای APK با امضای نسخه نصب‌شده بانک‌مووی یکسان نیست")
        }
    }

    private fun showReady(file: File) {
        errorDetails.visibility = View.GONE
        status.setTextColor(Color.rgb(247, 251, 255))
        verifiedFile = file
        bar.progress = 1f
        bar.isActive = false
        percentage.text = "۱۰۰٪"
        byteCount.text = "${size(file.length())} دریافت و تأیید شد"
        speed.text = "شناسه و امضا: تأیید شد"
        eta.text = "آماده نصب"
        status.text = "دانلود کامل؛ نسخه آماده نصب است"
        startButton.isEnabled = false
        startButton.alpha = .48f
        startButton.text = "دانلود کامل"
        cancelButton.text = "خروج از برنامه"
        installButton.isEnabled = true
        installButton.alpha = 1f
        installButton.requestFocus()
    }

    private fun beginInstall() {
        val file = verifiedFile ?: return
        if (!file.isFile) { setError("فایل APK دیگر موجود نیست"); return }
        if (Build.VERSION.SDK_INT >= 26 && !packageManager.canRequestPackageInstalls()) {
            try {
                val settings = Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName"))
                startActivity(settings)
                Toast.makeText(this, "اجازه نصب از بانک‌مووی را فعال کن و برگرد", Toast.LENGTH_LONG).show()
            } catch (_: Exception) { setError("مجوز نصب برنامه‌های خارج از فروشگاه را از تنظیمات تلویزیون فعال کن") }
            return
        }
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val install = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            startActivity(install)
        } catch (_: ActivityNotFoundException) {
            setError("نصب‌کننده APK روی این تلویزیون پیدا نشد")
        } catch (e: Exception) {
            setError("اجرای نصب ناموفق بود: ${e.message.orEmpty().take(80)}")
        }
    }

    override fun onDestroy() {
        cancelled.set(true)
        activeConnection?.disconnect()
        mainHandler.removeCallbacks(dotTicker)
        super.onDestroy()
    }
}

/** Uiverse's 200px dark 30px pill and diagonal translucent stripes, native Canvas. */
private class TvUiverseProgressView(context: Context) : View(context) {
    var progress = 0f
        set(value) { field = value; invalidate() }
    var isActive = false
        set(value) { field = value; invalidate() }
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stripePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bounds = RectF()
    private val fillBounds = RectF()
    private val clip = Path()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val d = resources.displayMetrics.density
        val padding = 5f * d
        bounds.set(0f, 0f, width.toFloat(), height.toFloat())
        trackPaint.color = Color.rgb(29, 33, 39)
        canvas.drawRoundRect(bounds, height / 2f, height / 2f, trackPaint)
        val innerHeight = height - padding * 2f
        val left = padding
        val right = width - padding
        if (right <= left) return
        if (progress < 0f) {
            // No Content-Length: no manufactured percentage; only a moving activity segment.
            val start = if (isActive) ((SystemClock.uptimeMillis() / 2600f) % 1f) else 0f
            val segment = (right - left) * .28f
            val segmentLeft = left + start * (right - left - segment)
            fillBounds.set(segmentLeft, padding, segmentLeft + segment, height - padding)
        } else {
            val fraction = progress.coerceIn(0f, 1f)
            fillBounds.set(left, padding, left + (right - left) * fraction, height - padding)
        }
        if (fillBounds.width() <= 0f) return
        val r = min(innerHeight / 2f, fillBounds.width() / 2f)
        fillPaint.shader = LinearGradient(
            0f, padding, 0f, height - padding,
            Color.rgb(51, 209, 249), Color.rgb(12, 91, 226), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(fillBounds, r, r, fillPaint)
        clip.reset(); clip.addRoundRect(fillBounds, r, r, Path.Direction.CW)
        canvas.save(); canvas.clipPath(clip)
        stripePaint.shader = LinearGradient(
            0f, 0f, 12f * d, 25f * d,
            Color.argb(66, 255, 255, 255), Color.TRANSPARENT, Shader.TileMode.CLAMP
        )
        val step = 25f * d
        val motion = if (isActive) ((SystemClock.uptimeMillis() % 2500L) / 2500f * step) else 0f
        var x = left - step * 2f + motion
        while (x < right + step) {
            val stripe = Path().apply {
                moveTo(x, padding)
                lineTo(x + 7f * d, padding)
                lineTo(x + 27f * d, height - padding)
                lineTo(x + 20f * d, height - padding)
                close()
            }
            canvas.drawPath(stripe, stripePaint)
            x += step
        }
        canvas.restore()
        fillPaint.shader = null
        stripePaint.shader = null
        if (isActive) postInvalidateDelayed(90L)  // Low-GPU-cost animation for older TVs.
    }
}
