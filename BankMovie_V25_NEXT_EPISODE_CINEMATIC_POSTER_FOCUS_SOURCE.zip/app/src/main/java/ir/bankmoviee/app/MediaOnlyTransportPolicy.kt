package ir.bankmoviee.app

import android.net.Uri
import java.net.URL
import java.security.cert.CertificateException
import javax.net.ssl.SSLException

/**
 * Only PlayerActivity / InternalDownloadService call these helpers.
 * Always attempt each media link using its published protocol first.
 * Never disable certificate/hostname verification or downgrade app API, login,
 * account or update routes. Only validated video errors can trigger a second scheme.
 */
internal object MediaOnlyTransportPolicy {
    private val sensitiveQuery = Regex(
        "(?i)(?:^|&)(?:token|api[_-]?key|access[_-]?token|auth|authorization|signature|sig|jwt|session|expires|policy|x-amz-[^=]*|x-goog-[^=]*)="
    )

    fun isSafeMediaAddress(raw: String): Boolean {
        val uri = runCatching { Uri.parse(raw.trim()) }.getOrNull() ?: return false
        if (uri.scheme?.lowercase() !in setOf("https", "http")) return false
        if (!uri.encodedUserInfo.isNullOrBlank()) return false
        val host = uri.host.orEmpty().lowercase()
        if (host.isBlank() || host == "localhost" || host == "127.0.0.1" || host == "::1" ||
            host.startsWith("127.") || host.startsWith("10.") || host.startsWith("192.168.") ||
            host.startsWith("169.254.") || host.endsWith(".local") ||
            host.matches(Regex("172\\.(?:1[6-9]|2[0-9]|3[01])\\..*"))
        ) return false
        if (uri.port !in listOf(-1, 80, 443)) return false
        val path = uri.path.orEmpty().lowercase()
        if (path.contains("/api/") || path.contains("/login") || path.contains("/auth") ||
            path.contains("/account") || path.contains("/admin") || path.contains("app_api.php") ||
            path.contains("update.php") || path.contains("config.php")) return false
        return true
    }

    fun httpsFirst(raw: String): String {
        if (!isSafeMediaAddress(raw)) return raw
        val uri = Uri.parse(raw.trim())
        return if (uri.scheme.equals("http", true)) uri.buildUpon().scheme("https").build().toString() else raw
    }

    /** Only media data can cross HTTP, and only after an actual TLS error. */
    fun httpForPlayer(https: String, cameFromHttp: Boolean): String? {
        if (!isSafeMediaAddress(https)) return null
        val uri = Uri.parse(https)
        if (!uri.scheme.equals("https", true)) return null
        // Never expose signed HTTPS playback URLs as plaintext.
        if (!cameFromHttp && sensitiveQuery.containsMatchIn(uri.encodedQuery.orEmpty())) return null
        val path = uri.path.orEmpty().lowercase()
        val mediaLike = listOf(".mp4", ".mkv", ".m3u8", ".mpd", ".avi", ".webm", ".ts", ".mov", ".m4v")
            .any { path.endsWith(it) } || listOf("/stream/", "/video/", "/play/", "/media/", "/download/")
            .any { path.contains(it) }
        if (!mediaLike && !cameFromHttp) return null
        return uri.buildUpon().scheme("http").build().toString()
    }

    /** Do NOT reinterpret an HTTP status, a decoder error or a timeout as an SSL failure. */
    fun isTlsFailure(error: Throwable?): Boolean {
        var current = error
        var depth = 0
        while (current != null && depth++ < 16) {
            if (current is SSLException || current is CertificateException) return true
            current = current.cause
        }
        return false
    }

    fun canUseOriginalHttpDownload(raw: String): Boolean =
        isSafeMediaAddress(raw) && runCatching { URL(raw).protocol.equals("http", true) }.getOrDefault(false)
}
