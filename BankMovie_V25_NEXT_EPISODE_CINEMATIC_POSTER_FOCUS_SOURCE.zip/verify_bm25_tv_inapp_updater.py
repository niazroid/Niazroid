#!/usr/bin/env python3
"""Source-level guard for TV in-app updater; no Android emulator/real APK is implied."""
from pathlib import Path
from hashlib import sha256
from xml.etree import ElementTree as ET
root=Path(__file__).parent
src=root/'app/src/main/java/ir/bankmoviee/app'
main=(src/'MainActivity.kt').read_text()
tv=(src/'TvAppUpdateActivity.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
fp=(root/'app/src/main/res/xml/file_paths.xml').read_text()
svg=(root/'app/src/main/res/drawable/bm_ic_telegram_update.xml').read_text()
checks={
    'TV detection excludes tablet-size fallback': 'private fun isTelevisionForUpdate(): Boolean' in main and 'smallestScreenWidthDp' not in main.split('private fun isTelevisionForUpdate(): Boolean')[1].split('private fun startTvApkUpdate(',1)[0],
    'TV uses its own Activity and URL': 'Intent(this, TvAppUpdateActivity::class.java)' in main and 'remoteTvDirectApkUrl' in main,
    'mobile website route exists': 'remoteUpdateWebsiteUrl.ifBlank { "https://bankmovie.top/application" }' in main,
    'mobile Telegram route with native icon': 'remoteUpdateTelegramUrl.ifBlank { AppConfig.TELEGRAM_URL }' in main and 'R.drawable.bm_ic_telegram_update' in main,
    'real progress ratio': '(done.toDouble() / total)' in tv and 'downloaded' not in tv.split('private fun updateDownloadUi',1)[1].split('private fun verifyDownloadedApk',1)[0].lower(),
    'unknown content length honest': 'if (progress >= 0)' in tv and 'حجم نامشخص' in tv,
    'safe TLS redirects': 'redirected.protocol != "https"' in tv and 'u.protocol != "https"' in tv,
    'CDN/error HTML rejected': 'type.contains("html")' in tv and 'magic[0] != 0x50.toByte()' in tv,
    'resume over HTTP Range': 'setRequestProperty("Range", "bytes=$start-")' in tv and 'FileOutputStream(part, resume)' in tv,
    'optional SHA256 + APK signer checks': 'MessageDigest.getInstance("SHA-256")' in tv and 'installedCerts' in tv and 'incomingCerts' in tv,
    'no silent install': 'Intent(Intent.ACTION_VIEW)' in tv and 'startActivity(install)' in tv,
    'unknown app sources handled': 'Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES' in tv,
    'real Uiverse credit included': 'From Uiverse.io by KSAplay' in tv and 'MIT License' in tv,
    'installer not exported': 'android:name=".TvAppUpdateActivity"' in manifest and 'android:exported="false"' in manifest,
    'manifest has install permission': 'android.permission.REQUEST_INSTALL_PACKAGES' in manifest,
    'file provider restricted to app updates': 'name="bankmovie_tv_updates" path="updates/"' in fp,
    'native Telegram drawable': 'pathData=' in svg and 'viewportWidth="240"' in svg,
}
for label,ok in checks.items():
    assert ok,label
    print('PASS',label)
# Ensure pre-Claude HOME DPAD methods are unchanged despite app-update additions
remember=main.split('private fun rememberHomeForSession()',1)[1].split('private fun tryRestoreHomeSession()',1)[0]
restore=main.split('private fun tryRestoreHomeSession()',1)[1].split('private fun restoreRetainedNavigationScreen(',1)[0]
assert sha256(remember.encode()).hexdigest() == '6c4d642c9d9834893a232ed18dd3cfcea2e42b6ed1b6e1fbc0a3628b32577a9f'
assert sha256(restore.encode()).hexdigest() == '13394d7b9dc92ee81f5c9ec274ddbb8e33a20384ab486b9bc2c124935e6734cc'
print('PASS PRE_CLAUDE_TV_HOME_DPAD_BIT_IDENTICAL')
ET.fromstring(svg)
ET.parse(root/'app/src/main/AndroidManifest.xml')
ET.parse(root/'app/src/main/res/xml/file_paths.xml')
print('BM25_TV_APP_UPDATE_STATIC_OK')
