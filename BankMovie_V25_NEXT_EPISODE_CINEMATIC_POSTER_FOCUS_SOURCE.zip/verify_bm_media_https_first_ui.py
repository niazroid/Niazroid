#!/usr/bin/env python3
"""Static regression guard: NOT a device/real URL playback test."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).parent
src=root/'app/src/main/java/ir/bankmoviee/app'
main=(src/'MainActivity.kt').read_text()
player=(src/'PlayerActivity.kt').read_text()
bridge=(src/'Media3PlaybackBridge.kt').read_text()
down=(src/'InternalDownloadService.kt').read_text()
policy=(src/'MediaOnlyTransportPolicy.kt').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
xml=(root/'app/src/main/res/xml/network_security_config.xml')
ET.parse(xml)
assert 'cleartextTrafficPermitted="true"' in xml.read_text()
assert 'usesCleartextTraffic="true"' in manifest
assert 'app_api.php' in policy and 'auth' in policy and 'account' in policy
assert 'fun httpsFirst(raw: String)' in policy
assert 'fun httpForPlayer(' in policy
assert 'signed HTTPS playback URLs' in policy
assert 'SSLException' in policy and 'CertificateException' in policy
assert 'httpMediaFallbackApplied' in player
assert 'MediaOnlyTransportPolicy.httpsFirst(source).takeIf { it != source }' in player
assert 'MediaOnlyTransportPolicy.isTlsFailure(failure)' in player
assert 'schedulePlaybackRetry(videoUrl, "خطا در پخش", event.error)' in player
assert 'MediaOnlyTransportPolicy.httpForPlayer(' in player
assert 'httpMediaFallbackApplied = false' in player
assert 'onPlayerError(error: PlaybackException)' in bridge
assert 'error = error' in bridge
assert 'originalFirstDownloadConnection(source)' in down
assert 'canUseOriginalHttpDownload(source)' in down
assert 'if (!MediaOnlyTransportPolicy.canUseOriginalHttpDownload(source)) return connect(source)' in down
assert 'HTTPS redirect attempted a cleartext downgrade' in down
assert 'normalizedDownloadSize(link.optString("size"))' in main
assert 'val resolution = Regex(' in main
block=main.split('private fun downloadQualityRow(',1)[1].split('private fun movieVersionPanel(',1)[0]
assert 'فصل' not in block and 'قسمت' not in block
assert 'optString("label").takeIf' not in block
assert 'fileSize.isNotBlank()' in block and 'isTvLike()' in block
assert 'این پخش نشد؛ دارم روش دیگری رو امتحان می‌کنم' in player
assert 'HTTPS این فایل پخش نشد' not in player
assert 'تلاش مجدد ${playbackRetryCount}' not in player
assert 'clean = MediaOnlyTransportPolicy.httpsFirst(clean)' not in player
assert 'val connection = connect(source)' in down
assert 'return connect(MediaOnlyTransportPolicy.httpsFirst(source))' in down
assert 'httpMediaFallbackApplied = true' in player
print('BANKMOVIE_MEDIA_ORIGINAL_FIRST_UI_STATIC_OK')
