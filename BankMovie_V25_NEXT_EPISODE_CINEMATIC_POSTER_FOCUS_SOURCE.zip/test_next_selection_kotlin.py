#!/usr/bin/env python3
"""Compiles and executes actual next episode methods extracted from PlayerActivity.
Does not need Android SDK and does not claim an APK compile.
"""
from pathlib import Path
from subprocess import run
from tempfile import TemporaryDirectory
src=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
section=src.split('    private fun nextEpisodeResolution(track: Track): Int {',1)[1].split('    private fun nextEpisodeTitle(index: Int): String {',1)[0]
section='    fun nextEpisodeResolution(track: Track): Int {'+section
section=section.replace('    private fun nextEpisodeVariant(', '    fun nextEpisodeVariant(').replace('    private fun nextEpisodeIndex(', '    fun nextEpisodeIndex(')
src='''import java.util.Locale

class Selector(val tracks: List<Track>, val currentIndex: Int) {
    data class Track(val quality: String, val displayLabel: String="", val label: String="", val url: String="https://video.test/e", val type: String="", val typeFa: String="", val isAudio: Boolean=false, val season: Int=1, val episode: Int=1)
    fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.endsWith(".mka")
    fun isSubtitle(t: Track): Boolean = (t.type + t.typeFa).contains("sub", ignoreCase=true)
'''+section+'''
}

fun main() {
    fun t(quality: String, type: String, ep: Int=1, season: Int=1) = Selector.Track(quality=quality,typeFa=type,episode=ep,season=season)
    val cases = listOf(
        Pair(listOf(t("720P", "دوبله فارسی"),t("1080P", "سافت ساب فارسی",2),t("720p WEB-DL", "دوبله فارسی",2),t("1080P", "دوبله فارسی",2)), 2),
        Pair(listOf(t("720p", "دوبله فارسی"), t("1080P", "دوبله فارسی", 2), t("480P", "دوبله فارسی", 2), t("720P", "زیرنویس فارسی",2)),2),
        Pair(listOf(t("720P", "سافت ساب فارسی"),t("720p", "دوبله فارسی",2),t("720P", "زیرنویس فارسی",2)),2),
        Pair(listOf(t("1080P", "دوبله فارسی"),t("720P", "دوبله فارسی",2),t("1080P", "دوبله فارسی",3)),1),
        Pair(listOf(t("720P", "دوبله فارسی"),t("720P", "سافت ساب فارسی",2)),1)
    )
    for ((i,case) in cases.withIndex()) {
        val got=Selector(case.first,0).nextEpisodeIndex()
        check(got==case.second) { "Case ${i+1}: expected ${case.second}, got $got" }
    }
    check(Selector(listOf(t("720P", "دوبله فارسی")),0).nextEpisodeIndex() == -1)
    check(Selector(listOf(t("720p WEB-DL", "دوبله فارسی")),0).nextEpisodeResolution(t("720p WEB-DL", "دوبله فارسی")) == 720)
    check(Selector(listOf(t("4K", "دوبله فارسی")),0).nextEpisodeResolution(t("4K", "دوبله فارسی")) == 2160)
    println("NEXT_SELECTION_KOTLIN_EXECUTED_OK_7_CHECKS")
}
'''
with TemporaryDirectory() as d:
    path=Path(d)/'Test.kt';path.write_text(src)
    compiled=run(['kotlinc',str(path),'-include-runtime','-d',str(Path(d)/'test.jar')],capture_output=True,text=True,timeout=70)
    if compiled.returncode:
        raise SystemExit(compiled.stderr)
    tested=run(['java','-jar',str(Path(d)/'test.jar')],capture_output=True,text=True,timeout=20)
    if tested.returncode: raise SystemExit(tested.stderr)
    print(tested.stdout.strip())
