#!/usr/bin/env python3
"""Static regression guard for BankMovie next-episode TV dialog.

Does not substitute for a Gradle compile / Android TV device test.
"""
from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).parent
java = root/'app/src/main/java/ir/bankmoviee/app'
main = (java/'MainActivity.kt').read_text(encoding='utf-8')
player = (java/'PlayerActivity.kt').read_text(encoding='utf-8')
policy = (java/'MediaOnlyTransportPolicy.kt').read_text(encoding='utf-8')

checks = {
    'TV glass border gradient': 'val border = FrameLayout(this).apply {' in player and 'brightPurple, Color.rgb(93, 47, 219), cyan' in player,
    'original media poster bound from detail': 'playerPosterFromItem(item)' in main and 'EXTRA_POSTER_URL' in main and player.count('EXTRA_POSTER_URL') >= 2,
    'fallback poster JSON parsed': 'obj.optString("poster_url").ifBlank' in player,
    'poster cache': 'PosterDiskCache.read(this, resolved)' in player and 'PosterDiskCache.write(this, resolved, it)' in player,
    'poster loader off UI thread': 'private fun loadNextEpisodePoster(' in player and 'Thread {' in player,
    'poster remains optional': 'if (supplied.isBlank()) return' in player,
    'poster HTTPS validation': 'MediaOnlyTransportPolicy.isSafeMediaAddress(resolved)' in player and 'connection.responseCode !in 200..299' in player,
    'poster content type guard': 'if (!mime.startsWith("image/")) return@Thread' in player,
    'visual hero left and text right': 'View.LAYOUT_DIRECTION_LTR' in player[player.index('private fun maybePromptNextEpisode'):player.index('private fun playNext()')],
    'next-episode user SVG used': 'setImageResource(R.drawable.bm_ic_next_episode_user)' in player,
    'native vector icons': all(('R.drawable.' + r) in player for r in ('bm_ic_next_layers','bm_ic_next_clapper','bm_ic_next_close','bm_ic_next_play_triangle')),
    'dialog 98 percent': 'time.toDouble() / length.toDouble() < 0.98' in player,
    'same kind before closest quality': 'if (nextEpisodeVariant(it.value) == wantedVariant) 0' in player and 'abs(found - wantedResolution)' in player,
    'TV initial focus and navigation': 'playNextButton.post { if (dialog.isShowing) playNextButton.requestFocus() }' in player and 'cancelButton.nextFocusRightId = playNextButton.id' in player,
    'focus glow': 'setStroke(dp(3), Color.rgb(210, 230, 255))' in player,
    'no trust-all network override': 'HostnameVerifier {' not in player and 'X509TrustManager' not in player and 'X509TrustManager' not in policy,
    'app version unchanged': 'versionName "2.5"' in (root/'app/build.gradle').read_text(),
}
for title, good in checks.items():
    if not good:
        raise SystemExit('FAIL next-episode check: '+title)
    print('PASS',title)
for name in ['bm_ic_next_episode_user','bm_ic_next_layers','bm_ic_next_clapper','bm_ic_next_close','bm_ic_next_play_triangle']:
    ET.parse(root/'app/src/main/res/drawable'/f'{name}.xml')
print('NEXT_EPISODE_GLASS_POSTER_AND_FOCUS_STATIC_OK')
