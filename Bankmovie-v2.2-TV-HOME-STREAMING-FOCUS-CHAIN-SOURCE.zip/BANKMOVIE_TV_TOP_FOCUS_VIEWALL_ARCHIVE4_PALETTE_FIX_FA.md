# BankMovie TV — Top Focus / View All / Archive 4 Palette Fix

این پاس روی سه باگ گزارش‌شده در نسخه TV تمرکز دارد:

- ScrollView دیگر در صفحات TV که با D-pad Router کنترل می‌شوند، با گرفتن Focus به‌صورت خودکار صفحه را به وسط نمی‌کشد. اسکرول فقط بعد از حرکت واقعی D-pad و فقط به اندازه‌ای انجام می‌شود که مقصد داخل Viewport دیده شود. Detail/Player از این رفتار مستثنی‌اند تا Focus اختصاصی آن‌ها دست‌نخورده بماند.
- ورود Home روی CTA اسلایدر می‌ماند و چند پاس دیرهنگام Layout/Focus نمی‌توانند صفحه را از ابتدای Hero پایین ببرند.
- مسیر عمودی Home قبل از Router هندسی، `nextFocusUpId/nextFocusDownId` صریح خود سکشن‌ها را رعایت می‌کند؛ بنابراین ترتیب `مشاهده همه → پوسترها → مشاهده همه سکشن بعد → پوسترهای سکشن بعد` حفظ می‌شود و «مشاهده همه»های دوم به بعد دیگر Skip نمی‌شوند.
- Archive 4 به‌صورت صریح در همان مسیر Poster Palette Wash آرشیوهای 2 و 3 قرار دارد؛ در نبود Backdrop مستقل، پوستر به Color Wash سینمایی تبدیل می‌شود.

## فایل‌های تغییرکرده

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt`

## بررسی‌ها

- `verify_release.sh`
- `verify_tv_site_archive4_home_downloader_clip_fix.sh`
- `verify_tv_right_sidenav_focus_fix.sh`
- `verify_tv_home_focus_menu_collection_episode_fix.sh`
