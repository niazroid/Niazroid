#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
DL='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$MAIN" 'private var archive4SiteApiBase = AppConfig.BASE_DOMAIN.trimEnd'
need "$MAIN" '+ "/api4.php"'
need "$MAIN" '"$archive4SiteApiBase?section=${enc(mapped)}&page=$page"'
need "$MAIN" '"$archive4SiteApiBase?s=${enc(query)}&page=$page$directType&sort=newest"'
need "$MAIN" 'val websiteDetailId = item.optString("detail_id").trim().ifBlank'
need "$MAIN" '4 -> 4'
need "$MAIN" 'private fun wireHomePosterRows()'
need "$MAIN" 'tag = "bm_section_header"'
need "$MAIN" 'Watch Now -> newest poster -> older posters -> View all'
need "$MAIN" 'tag = "bm_tv_hard_artwork_clip"'
need "$MAIN" 'val tiny = Bitmap.createScaledBitmap(bitmap, 2, 2, true)'
if grep -n 'createBlurEffect' "$MAIN" | grep -q '82f'; then
  echo 'Old detail RenderEffect blur marker is still present' >&2
  exit 1
fi
need "$DL" 'override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean'
need "$DL" 'private fun routeDownloadsTvVerticalFocus(focused: View, keyCode: Int): Boolean'
need "$DL" 'val rows = visibleDownloadActionRows().filter { it.isShown && it.isEnabled && it.childCount > 0 }'
need "$DL" 'if (event.repeatCount != 0) return true'
echo 'TV_SITE_ARCHIVE4_HOME_DOWNLOADER_CLIP_FIX_OK'
