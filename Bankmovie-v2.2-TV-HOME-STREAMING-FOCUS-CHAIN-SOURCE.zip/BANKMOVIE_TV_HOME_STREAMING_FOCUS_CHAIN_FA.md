# Bankmovie TV Home Streaming Focus Chain

## تغییر انجام‌شده
مسیر فوکوس صفحه Home تلویزیون به مدل طبیعی سرویس‌های استریم تغییر کرد:

1. فوکوس اولیه روی دکمه «تماشا کنید» اسلایدر است.
2. با `DPAD_DOWN` مستقیماً جدیدترین فیلمِ اولین ریل فوکوس می‌شود.
3. در رابط فارسی/RTL، جدیدترین آیتم در سمت راست است و با `DPAD_LEFT` به ترتیب به فیلم‌های قدیمی‌تر می‌رویم.
4. بعد از آخرین پوستر، `DPAD_LEFT` روی «مشاهده همه» همان سکشن می‌رود.
5. از «مشاهده همه» با `DPAD_DOWN` وارد جدیدترین آیتم سکشن بعدی می‌شویم.
6. حرکت عمودی بین ریل‌ها poster-to-poster باقی مانده تا پرش فوکوس ایجاد نشود.
7. انتخاب آرشیو حذف نشده؛ از ردیف اول با `DPAD_UP` قابل دسترسی است و از آرشیو با `DPAD_DOWN` دوباره به جدیدترین فیلم برمی‌گردیم.
8. تا قبل از لود شدن اولین ریل، `DPAD_DOWN` روی اسلایدر مصرف می‌شود تا فوکوس تصادفی روی آرشیو یا بخش دیگری نیفتد.

## فایل اصلی تغییرکرده
- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`

## تست جدید
- `verify_tv_home_streaming_focus_chain.sh`

## تست‌های پاس‌شده
- `verify_tv_home_streaming_focus_chain.sh`
- `verify_tv_top_focus_viewall_archive4_palette_fix.sh`
- `verify_tv_home_focus_menu_collection_episode_fix.sh`
- `verify_tv_right_sidenav_focus_fix.sh`
- `verify_tv_site_archive4_home_downloader_clip_fix.sh`
- `verify_tv_filmio_glass_polish.sh`
- `verify_tv_minimal_rail_content_inset.sh`
- `verify_release.sh`

نکته: پروژه Gradle Wrapper ندارد؛ بنابراین در این محیط Build کامل Gradle اجرا نشد و اعتبارسنجی با تست‌های استاتیک خود پروژه انجام شد.
