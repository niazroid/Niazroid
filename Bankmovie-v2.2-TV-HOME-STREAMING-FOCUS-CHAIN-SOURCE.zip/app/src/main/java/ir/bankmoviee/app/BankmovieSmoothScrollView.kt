package ir.bankmoviee.app

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.view.ViewGroup
import android.widget.ScrollView
import kotlin.math.roundToInt

/**
 * Drop-in vertical scroller tuned for the native BankMovie screens.
 *
 * It intentionally stays a platform ScrollView (instead of adding another UI
 * dependency), so all existing focus/restore code keeps working. Phone flings
 * are only lightly damped to remove the abrupt "throw" feeling while keeping
 * Android's native physics and 60/90/120 Hz frame pacing. TV is left untouched
 * because D-pad focus, not touch inertia, owns navigation there.
 */
internal class BankmovieSmoothScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.scrollViewStyle
) : ScrollView(context, attrs, defStyleAttr) {

    private val tvLike = DeviceProfile.isTv(context)

    /**
     * Android ScrollView normally scrolls as soon as a descendant receives focus.
     * On TV that can yank a newly opened screen toward the middle before the user
     * presses anything. MainActivity enables this guard on D-pad routed screens
     * and performs a small, explicit reveal only after an actual navigation key.
     */
    var suppressTvAutomaticFocusScroll: Boolean = false

    init {
        isVerticalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isSmoothScrollingEnabled = !tvLike
        clipToPadding = false
        isFillViewport = false
        if (android.os.Build.VERSION.SDK_INT >= 26) defaultFocusHighlightEnabled = false
    }

    override fun requestChildFocus(child: View, focused: View) {
        if (tvLike && suppressTvAutomaticFocusScroll) {
            // Skip ScrollView.scrollToChild(), but still propagate the focus change
            // to ancestors so accessibility/focus ownership remains correct.
            (parent as? ViewGroup)?.requestChildFocus(this, focused)
            return
        }
        super.requestChildFocus(child, focused)
    }

    override fun fling(velocityY: Int) {
        if (tvLike) {
            super.fling(velocityY)
            return
        }
        // Small damping keeps long pages readable and makes the deceleration feel
        // closer to modern social/streaming feeds without fighting native touch.
        val tuned = (velocityY * 0.90f).roundToInt()
        super.fling(tuned)
    }
}

/**
 * Matching lightweight horizontal scroller for poster rails/chips. It keeps the
 * platform implementation and only removes overscroll/scrollbar noise.
 */
internal class HorizontalBankmovieSmoothScrollView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.scrollViewStyle
) : android.widget.HorizontalScrollView(context, attrs, defStyleAttr) {
    init {
        isHorizontalScrollBarEnabled = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isSmoothScrollingEnabled = !DeviceProfile.isTv(context)
        clipToPadding = false
        if (android.os.Build.VERSION.SDK_INT >= 26) defaultFocusHighlightEnabled = false
    }
}
