#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
SCROLL='app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$SCROLL" 'var suppressTvAutomaticFocusScroll: Boolean = false'
need "$SCROLL" 'override fun requestChildFocus(child: View, focused: View)'
need "$MAIN" 'private fun revealTvFocusTarget(target: View)'
need "$MAIN" 'private fun explicitHomeTvVerticalTarget(focused: View, keyCode: Int): View?'
need "$MAIN" 'val explicitHomeTarget = explicitHomeTvVerticalTarget(focused, keyCode)'
need "$MAIN" 'listOf(140L, 420L, 900L).forEach'
need "$MAIN" 'val archiveUsesPosterPaletteWash = detailArchiveForArtwork in setOf(2, 3, 4)'
echo 'TV_TOP_FOCUS_VIEWALL_ARCHIVE4_PALETTE_FIX_OK'
