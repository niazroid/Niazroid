#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq -- "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$MAIN" 'private fun explicitHomeTvVerticalTarget(focused: View, keyCode: Int): View?'
need "$MAIN" 'private fun explicitHomeTvHorizontalEndTarget(focused: View, keyCode: Int): View?'
need "$MAIN" 'watch.nextFocusDownId = firstMovie.id'
need "$MAIN" 'last.nextFocusLeftId = section.more.id'
need "$MAIN" 'section.more.nextFocusRightId = last.id'
need "$MAIN" 'Vertical navigation between poster rows stays poster-to-poster.'
# Regression guard: the bad version swallowed DOWN while async rails were not ready.
if grep -Fq 'val firstMovie = firstHomeTvMediaCard()' "$MAIN"; then
  echo 'Broken async hero focus interceptor is still present' >&2
  exit 1
fi
if grep -Fq 'focused.tag == "bm_tv_slider_primary"' "$MAIN"; then
  echo 'Hero D-pad DOWN is still globally intercepted; this can freeze focus while loading' >&2
  exit 1
fi
# Regression guard: ordinary LEFT/RIGHT must not be globally replaced by explicit IDs.
if grep -Fq 'private fun explicitHomeTvDirectionalTarget' "$MAIN"; then
  echo 'Unsafe all-axis Home explicit router is still present' >&2
  exit 1
fi
echo 'TV_HOME_STREAMING_FOCUS_CHAIN_REPAIR_OK'
