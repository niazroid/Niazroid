#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$MAIN" 'private fun firstHomeTvMediaCard(): View?'
need "$MAIN" 'focused.tag == "bm_tv_slider_primary"'
need "$MAIN" 'val firstMovie = firstHomeTvMediaCard()'
need "$MAIN" 'card.nextFocusLeftId = older?.id ?: section.more.id'
need "$MAIN" 'section.more.nextFocusRightId = lastCard.id'
need "$MAIN" 'watch.nextFocusDownId = firstMovie.id'
need "$MAIN" 'archiveSegments.forEach { segment -> segment.nextFocusDownId = firstMovie.id }'
need "$MAIN" 'val rtl = isFa()'
need "$MAIN" 'View all is reached after the oldest poster'
if grep -Fq 'watch.nextFocusDownId = it.id' "$MAIN"; then
  echo 'Old hero -> archive DOWN path is still present' >&2
  exit 1
fi
echo 'TV_HOME_STREAMING_FOCUS_CHAIN_OK'
