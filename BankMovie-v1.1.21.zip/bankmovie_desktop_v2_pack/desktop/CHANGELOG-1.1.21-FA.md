# BankMovie Desktop 1.1.21

- Detail سریال‌های خیلی بلند timeout اختصاصی 90 ثانیه گرفت؛ درخواست‌های عادی همچنان timeout کوتاه دارند.
- کش Detail از 5 دقیقه به 1 ساعت افزایش یافت تا بازگشت به سریال‌های سنگین دوباره به سرور فشار نیاورد.
- نمایش Source / Codec / Bit-depth / Encoder برای کیفیت‌ها با Badgeهای مستقل.
- تشخیص BluRay / WEB-DL / WEBRip / REMUX، x265/x264/AV1، 10Bit/12Bit و Encoderهای ارسالی API.
- Encoder فقط از فیلدهای API یا Release metadata قابل تشخیص نمایش داده می‌شود.
- رده سنی از فیلدهای مشترک سایت/اپ و movie_extra_info خوانده می‌شود و در Hero + اطلاعات نمایش داده می‌شود.
