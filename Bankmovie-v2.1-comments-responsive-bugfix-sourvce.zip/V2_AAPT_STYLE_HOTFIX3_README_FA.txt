Bankmovie V2.0 — AAPT Style Hotfix 3

خطای resource style/BankMovie not found به‌صورت ریشه‌ای رفع شد.
نام استایل‌های غیر Theme از حالت نقطه‌دار به نام تخت تغییر کرد تا AAPT
والد ضمنی BankMovie نسازد:

BankMovie.DialogAnimation -> BankMovieDialogAnimation
BankMovie.AlertDialog     -> BankMovieAlertDialog

این اصلاح داخل خود سورس است و Workflow دیگر برای آن پچ شمارشی اجرا نمی‌کند.
WORKFLOW_REVISION=V2-HOTFIX-20260716-3
