package ir.bankmoviee.app

object AppConfig {
    const val BASE_URL = "https://bankmoviee.ir/"
    const val APP_SCHEME = "bankmoviee"
    const val PLAY_HOST = "play"
    const val USER_AGENT_SUFFIX = " BankMovieeAndroid/1.0"

    val TRUSTED_HOSTS = setOf(
        "bankmoviee.ir",
        "www.bankmoviee.ir"
    )

    val DIRECT_VIDEO_EXTENSIONS = listOf(
        ".mp4", ".mkv", ".m3u8", ".avi", ".mov", ".webm", ".ts"
    )

    val SUBTITLE_EXTENSIONS = listOf(
        ".srt", ".ass", ".ssa", ".vtt"
    )
}
