package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.max

class DownloadsActivity : Activity() {
    companion object {
        private const val FILTER_ALL = "all"
        private const val FILTER_ACTIVE = "active"
        private const val FILTER_COMPLETED = "completed"
    }

    private data class CardRefs(
        val progress: ProgressBar,
        val status: TextView,
        val bytes: TextView,
        val remaining: TextView,
        val fileInfo: TextView
    )

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var downloadsBox: LinearLayout
    private lateinit var allTab: TextView
    private lateinit var activeTab: TextView
    private lateinit var completedTab: TextView
    private var selectedFilter = FILTER_ALL
    private var lastStructure = ""
    private val cardRefs = linkedMapOf<String, CardRefs>()
    private val folderRequestCode = 19082
    private val imageExecutor = Executors.newFixedThreadPool(2)
    private val posterCache = object : LruCache<String, Bitmap>(16 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    private val refresh = object : Runnable {
        override fun run() {
            refreshDownloads(false)
            handler.postDelayed(this, 850L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val palette = UiPreferences.palette(this)
        window.statusBarColor = palette.background
        window.navigationBarColor = palette.background
        buildShell()
        refreshDownloads(true)
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refresh)
        refreshDownloads(false)
        handler.postDelayed(refresh, 250L)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    override fun onDestroy() {
        handler.removeCallbacks(refresh)
        imageExecutor.shutdownNow()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != folderRequestCode || resultCode != RESULT_OK) return
        val treeUri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(
                treeUri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Throwable) {
        }
        DownloadLocationPrefs.setTree(this, treeUri)
        lastStructure = ""
        refreshDownloads(true)
        Toast.makeText(this, "مسیر دانلود تغییر کرد", Toast.LENGTH_SHORT).show()
    }

    private fun buildShell() {
        val palette = UiPreferences.palette(this)
        root = FrameLayout(this).apply {
            setBackgroundColor(palette.background)
            clipChildren = false
            clipToPadding = false
        }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            clipChildren = false
            isFillViewport = true
            setPadding(0, 0, 0, dp(30))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(if (isTvLike()) 28 else 14), dp(14), dp(if (isTvLike()) 28 else 14), dp(24))
            clipChildren = false
            clipToPadding = false
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        buildHeader()
        buildFilters()
        content.addView(downloadLocationCard(), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        downloadsBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        content.addView(downloadsBox, LinearLayout.LayoutParams(-1, -2))
    }

    private fun buildHeader() {
        val palette = UiPreferences.palette(this)
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(palette.panel, 24, palette.stroke)
            clipChildren = false
            clipToPadding = false
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_back)
            setColorFilter(palette.text)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            focusKey(this, "header:back")
            premiumFocus(this, 999)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(10) })

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        titles.addView(TextView(this).apply {
            text = "دانلودها"
            setTextColor(palette.text)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = "مدیریت حرفه‌ای، توقف و ادامه واقعی"
            setTextColor(palette.muted)
            textSize = 11.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun buildFilters() {
        // Equal-width compact tabs prevent clipping on small phones while still
        // remaining large enough for TV focus navigation.
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
        }
        allTab = filterButton("همه", FILTER_ALL)
        activeTab = filterButton("در حال دانلود", FILTER_ACTIVE)
        completedTab = filterButton("دانلود شده", FILTER_COMPLETED)
        val tabHeight = dp(if (isTvLike()) 48 else 42)
        row.addView(allTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(4) })
        row.addView(activeTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        row.addView(completedTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginEnd = dp(4) })
        content.addView(row, LinearLayout.LayoutParams(-1, tabHeight + dp(8)).apply { bottomMargin = dp(6) })
    }

    private fun filterButton(label: String, key: String): TextView = TextView(this).apply {
        text = label
        textSize = if (isTvLike()) 12f else 10.4f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        includeFontPadding = false
        setPadding(dp(5), 0, dp(5), 0)
        focusKey(this, "filter:$key")
        premiumFocus(this, 16)
        setOnClickListener {
            if (selectedFilter == key) return@setOnClickListener
            selectedFilter = key
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun updateFilterUi(items: List<JSONObject>) {
        val active = items.count { isActive(it.optString("status")) }
        val completed = items.count { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }
        allTab.text = "همه ${items.size}"
        activeTab.text = "در حال دانلود $active"
        completedTab.text = "دانلود شده $completed"
        bindFilterStyle(allTab, selectedFilter == FILTER_ALL)
        bindFilterStyle(activeTab, selectedFilter == FILTER_ACTIVE)
        bindFilterStyle(completedTab, selectedFilter == FILTER_COMPLETED)
    }

    private fun bindFilterStyle(view: TextView, active: Boolean) {
        val palette = UiPreferences.palette(this)
        view.setTextColor(if (active) palette.onPrimary else palette.text)
        view.background = if (active) {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(palette.primary, palette.primary2)).apply {
                cornerRadius = dp(15).toFloat()
            }
        } else {
            rounded(palette.panel, 15, palette.stroke)
        }
    }

    private fun refreshDownloads(force: Boolean) {
        if (!::downloadsBox.isInitialized) return
        val all = InternalDownloadStore.all(this)
        updateFilterUi(all)
        val visible = all.filter { item ->
            when (selectedFilter) {
                FILTER_ACTIVE -> isActive(item.optString("status"))
                FILTER_COMPLETED -> item.optString("status") == InternalDownloadStore.STATUS_COMPLETED
                else -> true
            }
        }
        val structure = buildString {
            append(selectedFilter).append('|').append(DownloadLocationPrefs.displayName(this@DownloadsActivity))
            visible.forEach {
                append('|').append(it.optString("id"))
                    .append(':').append(it.optString("status"))
                    .append(':').append(it.optString("poster"))
                    .append(':').append(it.optString("error"))
                    .append(':').append(it.optBoolean("resume_checked", false))
            }
        }
        if (force || structure != lastStructure) {
            lastStructure = structure
            rebuildDownloadList(visible)
        } else {
            updateProgressOnly(visible)
        }
    }

    private fun rebuildDownloadList(items: List<JSONObject>) {
        val focusKey = currentFocus?.getTag(R.id.bm_focus_restore_key) as? String
        downloadsBox.animate().cancel()
        downloadsBox.removeAllViews()
        cardRefs.clear()

        if (items.isEmpty()) {
            downloadsBox.addView(emptyState(), LinearLayout.LayoutParams(-1, -2))
        } else {
            items.forEach { item ->
                downloadsBox.addView(downloadCard(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
            }
            if (selectedFilter != FILTER_ACTIVE && items.any { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }) {
                downloadsBox.addView(clearCompletedButton(), LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(4) })
            }
        }

        downloadsBox.alpha = 0f
        downloadsBox.translationY = dp(7).toFloat()
        downloadsBox.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(165L)
            .setInterpolator(DecelerateInterpolator())
            .start()

        if (isTvLike()) {
            downloadsBox.postDelayed({
                val restored = focusKey?.let { findFocusKey(content, it) }
                if (restored != null) restored.requestFocus() else if (currentFocus == null) focusFirst(content)
            }, 90L)
        }
    }

    private fun emptyState(): View {
        val palette = UiPreferences.palette(this)
        val text = when (selectedFilter) {
            FILTER_ACTIVE -> "دانلود فعالی وجود ندارد"
            FILTER_COMPLETED -> "هنوز دانلود کاملی نداری"
            else -> "هنوز دانلودی نداری"
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(20), dp(44), dp(20), dp(44))
            background = rounded(palette.panel, 24, palette.stroke)
            addView(ImageView(this@DownloadsActivity).apply {
                setImageResource(R.drawable.ic_download)
                setColorFilter(palette.primary)
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(12) })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = text
                setTextColor(palette.text)
                textSize = 16f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
            addView(TextView(this@DownloadsActivity).apply {
                this.text = "از باکس دانلود هر فیلم یا قسمت، دانلودر داخلی را انتخاب کن."
                setTextColor(palette.muted)
                textSize = 12f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(7), dp(12), 0)
            })
        }
    }

    private fun clearCompletedButton(): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = "پاک‌کردن سوابق دانلودهای کامل‌شده"
        setTextColor(Color.rgb(255, 125, 135))
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = rounded(Color.argb(45, 235, 35, 55), 18, Color.argb(130, 235, 35, 55))
        focusKey(this, "downloads:clear-completed")
        premiumFocus(this, 18)
        setOnClickListener {
            InternalDownloadStore.clearCompleted(this@DownloadsActivity)
            lastStructure = ""
            refreshDownloads(true)
        }
    }

    private fun downloadLocationCard(): LinearLayout {
        val palette = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(palette.panel, 22, palette.stroke)
            focusKey(this, "downloads:folder")
            premiumFocus(this, 22)
            setOnClickListener { showLocationDialog() }

            addView(FrameLayout(this@DownloadsActivity).apply {
                background = rounded(
                    Color.argb(55, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)),
                    16,
                    Color.argb(145, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary))
                )
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(palette.primary)
                }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(11) })

            val labels = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = "محل ذخیره دانلودها"
                setTextColor(palette.text)
                textSize = 13.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            labels.addView(TextView(this@DownloadsActivity).apply {
                text = DownloadLocationPrefs.displayName(this@DownloadsActivity)
                setTextColor(palette.muted)
                textSize = 11.2f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(4), 0, 0)
            })
            addView(labels, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@DownloadsActivity).apply {
                text = "تغییر"
                setTextColor(palette.primary)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(60), dp(38)))
        }
    }

    private fun showLocationDialog() {
        val palette = UiPreferences.palette(this)
        lateinit var dialog: AlertDialog
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(palette.panel, 25, palette.stroke)
            clipChildren = false
            clipToPadding = false
        }
        box.addView(TextView(this).apply {
            text = "انتخاب محل ذخیره"
            setTextColor(palette.text)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        box.addView(TextView(this).apply {
            text = "می‌توانی پوشه دلخواه را انتخاب کنی یا از حافظه اختصاصی برنامه استفاده کنی."
            setTextColor(palette.muted)
            textSize = 12.2f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val custom = dialogButton("انتخاب پوشه دلخواه", false, "location:custom") {
            dialog.dismiss()
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, folderRequestCode)
        }
        val appFolder = dialogButton("حافظه اختصاصی برنامه", false, "location:app") {
            DownloadLocationPrefs.setAppFolder(this)
            dialog.dismiss()
            lastStructure = ""
            refreshDownloads(true)
            Toast.makeText(this, "حافظه اختصاصی برنامه انتخاب شد", Toast.LENGTH_SHORT).show()
        }
        box.addView(custom, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(9) })
        box.addView(appFolder, LinearLayout.LayoutParams(-1, dp(50)))

        dialog = AlertDialog.Builder(this).setView(box).create()
        dialog.show()
        val win = dialog.window
        win?.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        win?.setDimAmount(0.58f)
        win?.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        val maxWidth = if (isTvLike()) dp(620) else dp(500)
        win?.setLayout((resources.displayMetrics.widthPixels - dp(24)).coerceAtMost(maxWidth), ViewGroup.LayoutParams.WRAP_CONTENT)
        val decor = win?.decorView
        if (decor != null) {
            decor.alpha = 0f
            decor.scaleX = 0.97f
            decor.scaleY = 0.97f
            decor.translationY = dp(10).toFloat()
            decor.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(180L).setInterpolator(DecelerateInterpolator()).start()
        }
        if (isTvLike()) box.postDelayed({ custom.requestFocus() }, 90L)
    }

    private fun dialogButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 125, 135) else palette.text)
        textSize = 13f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) rounded(Color.argb(45, 235, 35, 55), 16, Color.argb(125, 235, 35, 55)) else rounded(palette.panel2, 16, palette.stroke)
        focusKey(this, key)
        premiumFocus(this, 16)
        setOnClickListener { click() }
    }

    private fun downloadCard(item: JSONObject): LinearLayout {
        val palette = UiPreferences.palette(this)
        val id = item.optString("id")
        val status = item.optString("status")
        val downloaded = item.optLong("downloaded", 0L)
        val total = item.optLong("total", 0L)
        val speed = item.optLong("speed", 0L)
        val percent = percent(downloaded, total)

        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(palette.card, 22, palette.stroke)
            clipChildren = false
            clipToPadding = false

            val top = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.TOP
                clipChildren = false
                clipToPadding = false
            }

            val posterShell = FrameLayout(this@DownloadsActivity).apply {
                background = rounded(palette.panel2, 16, palette.stroke)
                clipToOutline = true
            }
            val poster = ImageView(this@DownloadsActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageResource(R.drawable.bankmovie_mark_transparent)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            posterShell.addView(poster, FrameLayout.LayoutParams(-1, -1))
            top.addView(posterShell, LinearLayout.LayoutParams(dp(78), dp(108)).apply { marginStart = dp(12) })
            loadPoster(item.optString("poster"), poster)

            val info = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
            }
            info.addView(TextView(this@DownloadsActivity).apply {
                text = item.optString("title").ifBlank { item.optString("file_name") }
                setTextColor(palette.text)
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            info.addView(TextView(this@DownloadsActivity).apply {
                text = listOf(item.optString("quality"), item.optString("kind"), item.optString("display_label"))
                    .filter { it.isNotBlank() }
                    .distinct()
                    .joinToString(" • ")
                setTextColor(palette.muted)
                textSize = 11f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(5), 0, 0)
            })
            info.addView(TextView(this@DownloadsActivity).apply {
                text = statusChipText(status)
                setTextColor(statusColor(status, palette.primary))
                textSize = 10.8f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                setPadding(0, dp(8), 0, 0)
            })
            val fileInfoText = TextView(this@DownloadsActivity).apply {
                text = fileInfoLabel(item)
                setTextColor(palette.faint)
                textSize = 10.2f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setPadding(0, dp(6), 0, 0)
            }
            info.addView(fileInfoText)
            info.addView(TextView(this@DownloadsActivity).apply {
                text = "ذخیره در: " + item.optString("location_label").ifBlank { DownloadLocationPrefs.displayName(this@DownloadsActivity) }
                setTextColor(palette.faint)
                textSize = 9.8f
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
                setPadding(0, dp(7), 0, 0)
            })
            top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            addView(top)

            val progress = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                this.max = 100
                this.progress = percent
                isIndeterminate = total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING
                progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(palette.panel2)
            }
            addView(progress, LinearLayout.LayoutParams(-1, dp(7)).apply { topMargin = dp(13) })

            val statRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, dp(8), 0, 0)
            }
            val statusText = TextView(this@DownloadsActivity).apply {
                text = statusLabel(status, percent, speed)
                setTextColor(if (status == InternalDownloadStore.STATUS_FAILED) Color.rgb(255, 115, 125) else palette.muted)
                textSize = 11.3f
                gravity = Gravity.RIGHT
            }
            val bytesText = TextView(this@DownloadsActivity).apply {
                text = bytesLabel(downloaded, total)
                setTextColor(palette.faint)
                textSize = 10.8f
                gravity = Gravity.CENTER
            }
            val remainingText = TextView(this@DownloadsActivity).apply {
                text = remainingLabel(downloaded, total, speed, status)
                setTextColor(palette.faint)
                textSize = 10.8f
                gravity = Gravity.LEFT
            }
            statRow.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
            statRow.addView(bytesText, LinearLayout.LayoutParams(0, -2, 1f))
            statRow.addView(remainingText, LinearLayout.LayoutParams(0, -2, 1f))
            addView(statRow)

            val actions = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.RIGHT
                setPadding(0, dp(10), 0, 0)
                clipChildren = false
                clipToPadding = false
            }
            when (status) {
                InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_QUEUED -> {
                    actions.addView(actionButton("توقف", false, "$id:pause") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    actions.addView(actionButton("لغو", true, "$id:cancel") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_FAILED -> {
                    actions.addView(actionButton("ادامه", false, "$id:resume") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_RESUME, id) })
                    actions.addView(actionButton("حذف", true, "$id:delete") { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, buttonParams())
                }
                InternalDownloadStore.STATUS_COMPLETED -> {
                    actions.addView(actionButton("بازکردن", false, "$id:open") { openDownloaded(item) })
                    actions.addView(actionButton("حذف", true, "$id:delete") {
                        InternalDownloadStore.remove(this@DownloadsActivity, id, true)
                        lastStructure = ""
                        refreshDownloads(true)
                    }, buttonParams())
                }
            }
            addView(actions)

            val error = item.optString("error")
            if (error.isNotBlank() && status == InternalDownloadStore.STATUS_FAILED) {
                addView(TextView(this@DownloadsActivity).apply {
                    text = error
                    setTextColor(Color.rgb(230, 130, 140))
                    textSize = 10.5f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(7), 0, 0)
                })
            }

            cardRefs[id] = CardRefs(progress, statusText, bytesText, remainingText, fileInfoText)
        }
    }

    private fun buttonParams(): LinearLayout.LayoutParams = LinearLayout.LayoutParams(dp(78), dp(40)).apply { marginStart = dp(7) }

    private fun actionButton(label: String, danger: Boolean, key: String, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 130, 140) else palette.onPrimary)
        textSize = 11.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) {
            rounded(Color.argb(45, 235, 35, 55), 14, Color.argb(130, 235, 35, 55))
        } else {
            GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(palette.primary, palette.primary2)).apply { cornerRadius = dp(14).toFloat() }
        }
        focusKey(this, "download:$key")
        premiumFocus(this, 14)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(78), dp(40))
    }

    private fun updateProgressOnly(items: List<JSONObject>) {
        items.forEach { item ->
            val id = item.optString("id")
            val refs = cardRefs[id] ?: return@forEach
            val downloaded = item.optLong("downloaded", 0L)
            val total = item.optLong("total", 0L)
            val speed = item.optLong("speed", 0L)
            val status = item.optString("status")
            val percent = percent(downloaded, total)
            refs.progress.isIndeterminate = total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING
            if (!refs.progress.isIndeterminate) refs.progress.progress = percent
            refs.status.text = statusLabel(status, percent, speed)
            refs.bytes.text = bytesLabel(downloaded, total)
            refs.remaining.text = remainingLabel(downloaded, total, speed, status)
            refs.fileInfo.text = fileInfoLabel(item)
        }
    }

    private fun openDownloaded(item: JSONObject) {
        try {
            val documentRaw = item.optString("document_uri")
            val uri: Uri
            val mime = InternalDownloadStore.mimeForName(item.optString("file_name"))
            if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE && documentRaw.isNotBlank()) {
                uri = Uri.parse(documentRaw)
                if (!InternalDownloadStore.exists(this, item)) {
                    Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
                    return
                }
            } else {
                val file = File(item.optString("path"))
                if (!file.exists()) {
                    Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
                    return
                }
                uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            }
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Throwable) {
            Toast.makeText(this, "برنامه‌ای برای بازکردن فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun percent(downloaded: Long, total: Long): Int = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0

    private fun isActive(status: String): Boolean = status in setOf(
        InternalDownloadStore.STATUS_QUEUED,
        InternalDownloadStore.STATUS_DOWNLOADING,
        InternalDownloadStore.STATUS_PAUSED,
        InternalDownloadStore.STATUS_FAILED
    )

    private fun statusChipText(status: String): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف"
        InternalDownloadStore.STATUS_DOWNLOADING -> "در حال دانلود"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده"
        InternalDownloadStore.STATUS_COMPLETED -> "کامل شده"
        InternalDownloadStore.STATUS_FAILED -> "خطا"
        else -> "لغو شده"
    }

    private fun statusColor(status: String, primary: Int): Int = when (status) {
        InternalDownloadStore.STATUS_COMPLETED -> Color.rgb(75, 210, 135)
        InternalDownloadStore.STATUS_FAILED -> Color.rgb(255, 110, 120)
        InternalDownloadStore.STATUS_PAUSED -> Color.rgb(255, 169, 78)
        else -> primary
    }

    private fun fileInfoLabel(item: JSONObject): String {
        val total = item.optLong("total", 0L)
        val checked = item.optBoolean("resume_checked", false)
        val resume = item.optBoolean("resume_supported", false)
        return when {
            total > 0L && checked -> "حجم فایل: ${humanSize(total)}  •  ${if (resume) "قابل ادامه" else "ادامه در صورت پشتیبانی سرور"}"
            total > 0L -> "حجم فایل: ${humanSize(total)}"
            !checked -> "در حال بررسی حجم فایل و امکان ادامه..."
            else -> "حجم فایل توسط سرور اعلام نشد"
        }
    }

    private fun statusLabel(status: String, percent: Int, speed: Long): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف دانلود"
        InternalDownloadStore.STATUS_DOWNLOADING -> "$percent٪  •  ${humanSize(speed)}/s"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده • $percent٪"
        InternalDownloadStore.STATUS_COMPLETED -> "دانلود کامل شد"
        InternalDownloadStore.STATUS_FAILED -> "خطا در دانلود"
        else -> "لغو شده"
    }

    private fun bytesLabel(downloaded: Long, total: Long): String {
        return if (total > 0L) "${humanSize(downloaded)} / ${humanSize(total)}" else humanSize(downloaded)
    }

    private fun remainingLabel(downloaded: Long, total: Long, speed: Long, status: String): String {
        if (status == InternalDownloadStore.STATUS_COMPLETED) return "آماده پخش"
        if (status != InternalDownloadStore.STATUS_DOWNLOADING || speed <= 0L || total <= downloaded) return ""
        val seconds = ((total - downloaded) / speed).coerceAtLeast(0L)
        val hours = seconds / 3600L
        val minutes = (seconds % 3600L) / 60L
        val secs = seconds % 60L
        return if (hours > 0) String.format(Locale.US, "%02d:%02d:%02d مانده", hours, minutes, secs)
        else String.format(Locale.US, "%02d:%02d مانده", minutes, secs)
    }

    private fun humanSize(bytes: Long): String {
        if (bytes <= 0L) return "0 B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.0f KB", kb)
        val mb = kb / 1024.0
        return if (mb >= 1024.0) String.format(Locale.US, "%.2f GB", mb / 1024.0) else String.format(Locale.US, "%.1f MB", mb)
    }

    private fun normalizePoster(raw: String): String {
        val value = raw.trim()
        if (value.isBlank() || value == "null") return ""
        if (value.startsWith("//")) return "https:$value"
        if (value.startsWith("http://") || value.startsWith("https://")) return value
        return AppConfig.BASE_URL.trimEnd('/') + "/" + value.trimStart('/')
    }

    private fun loadPoster(raw: String, target: ImageView) {
        val url = normalizePoster(raw)
        if (url.isBlank()) return
        target.tag = url
        val cached = posterCache.get(url)
        if (cached != null && !cached.isRecycled) {
            target.setPadding(0, 0, 0, 0)
            target.setImageBitmap(cached)
            return
        }
        imageExecutor.execute {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 6500
                connection.readTimeout = 8500
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "Bankmovie Android")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                var bitmap = BitmapFactory.decodeStream(connection.inputStream, null, options) ?: return@execute
                val bigger = max(bitmap.width, bitmap.height)
                if (bigger > 520) {
                    val ratio = 520f / bigger.toFloat()
                    val scaled = Bitmap.createScaledBitmap(bitmap, (bitmap.width * ratio).toInt().coerceAtLeast(1), (bitmap.height * ratio).toInt().coerceAtLeast(1), true)
                    if (scaled !== bitmap) {
                        bitmap.recycle()
                        bitmap = scaled
                    }
                }
                posterCache.put(url, bitmap)
                runOnUiThread {
                    if (!isFinishing && target.tag == url && !bitmap.isRecycled) {
                        target.setPadding(0, 0, 0, 0)
                        target.alpha = 0.35f
                        target.setImageBitmap(bitmap)
                        target.animate().alpha(1f).setDuration(180L).start()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { connection?.disconnect() }
            }
        }
    }

    private fun focusKey(view: View, key: String) {
        view.setTag(R.id.bm_focus_restore_key, key)
    }

    private fun findFocusKey(view: View, key: String): View? {
        if (view.getTag(R.id.bm_focus_restore_key) == key && view.visibility == View.VISIBLE) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val found = findFocusKey(view.getChildAt(i), key)
                if (found != null) return found
            }
        }
        return null
    }

    private fun focusFirst(view: View): Boolean {
        if (view.isFocusable && view.isEnabled && view.visibility == View.VISIBLE && view.hasOnClickListeners()) {
            view.requestFocus()
            return true
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) if (focusFirst(view.getChildAt(i))) return true
        }
        return false
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun focusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val glow = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.argb(42, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val ring = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(160, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclamp(view: View) {
        var parent = view.parent
        while (parent is ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun premiumFocus(view: View, radius: Int = 16) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val normalElevation = view.elevation
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        view.setOnFocusChangeListener { target, focused ->
            target.animate().cancel()
            if (focused) {
                unclamp(target)
                target.bringToFront()
            }
            target.foreground = if (focused) focusDrawable(radius) else originalForeground
            target.elevation = if (focused) dp(20).toFloat() else normalElevation
            target.translationZ = if (focused) dp(7).toFloat() else 0f
            target.animate()
                .scaleX(if (focused) 1.05f else 1f)
                .scaleY(if (focused) 1.05f else 1f)
                .setDuration(if (focused) 145L else 105L)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
