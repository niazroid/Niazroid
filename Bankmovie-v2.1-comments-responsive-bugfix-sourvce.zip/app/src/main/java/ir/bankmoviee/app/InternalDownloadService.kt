package ir.bankmoviee.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max

class InternalDownloadService : Service() {

    companion object {
        const val ACTION_START = "ir.bankmoviee.app.download.START"
        const val ACTION_PAUSE = "ir.bankmoviee.app.download.PAUSE"
        const val ACTION_RESUME = "ir.bankmoviee.app.download.RESUME"
        const val ACTION_CANCEL = "ir.bankmoviee.app.download.CANCEL"
        const val ACTION_CHANGED = "ir.bankmoviee.app.download.CHANGED"

        const val EXTRA_ID = "download_id"
        const val EXTRA_URL = "download_url"
        const val EXTRA_TITLE = "download_title"
        const val EXTRA_QUALITY = "download_quality"
        const val EXTRA_KIND = "download_kind"
        const val EXTRA_LABEL = "download_label"
        const val EXTRA_POSTER = "download_poster"

        private const val CHANNEL_ID = "bankmovie_downloads"
        private const val FOREGROUND_ID = 18100

        fun start(
            context: Context,
            url: String,
            title: String,
            quality: String,
            kind: String,
            displayLabel: String,
            poster: String = ""
        ) {
            val intent = Intent(context, InternalDownloadService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_URL, url)
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_QUALITY, quality)
                putExtra(EXTRA_KIND, kind)
                putExtra(EXTRA_LABEL, displayLabel)
                putExtra(EXTRA_POSTER, poster)
            }
            ContextCompat.startForegroundService(context, intent)
        }

        fun command(context: Context, actionName: String, id: String) {
            val intent = Intent(context, InternalDownloadService::class.java).apply {
                action = actionName
                putExtra(EXTRA_ID, id)
            }
            ContextCompat.startForegroundService(context, intent)
        }
    }

    private data class Control(
        val pause: AtomicBoolean = AtomicBoolean(false),
        val cancel: AtomicBoolean = AtomicBoolean(false)
    )

    private interface DownloadTarget {
        var existing: Long
        fun reset()
        fun seek(position: Long)
        fun write(buffer: ByteArray, count: Int)
        fun sync()
        fun close()
    }

    private class FileTarget(private val file: File) : DownloadTarget {
        private val raf = RandomAccessFile(file, "rw")
        override var existing: Long = file.length()
        override fun reset() {
            raf.setLength(0L)
            existing = 0L
        }
        override fun seek(position: Long) = raf.seek(position)
        override fun write(buffer: ByteArray, count: Int) = raf.write(buffer, 0, count)
        override fun sync() = raf.fd.sync()
        override fun close() = raf.close()
    }

    private class TreeTarget(
        private val descriptor: ParcelFileDescriptor,
        private val stream: FileOutputStream
    ) : DownloadTarget {
        override var existing: Long = descriptor.statSize.coerceAtLeast(0L)
        override fun reset() {
            stream.channel.truncate(0L)
            stream.channel.position(0L)
            existing = 0L
        }
        override fun seek(position: Long) {
            stream.channel.position(position)
        }
        override fun write(buffer: ByteArray, count: Int) = stream.write(buffer, 0, count)
        override fun sync() = stream.fd.sync()
        override fun close() {
            runCatching { stream.close() }
            runCatching { descriptor.close() }
        }
    }

    private val executor = Executors.newFixedThreadPool(4)
    private val controls = ConcurrentHashMap<String, Control>()
    private val slotLock = Object()
    @Volatile private var activeDownloadSlots = 0

    private fun configuredDownloadLimit(): Int {
        return getSharedPreferences("bm_smart_cinema", Context.MODE_PRIVATE)
            .getInt("remote_download_limit", AccountSession.downloadLimit(this))
            .coerceIn(1, 4)
    }

    private fun acquireDownloadSlot(control: Control): Boolean {
        while (!control.cancel.get() && !control.pause.get()) {
            synchronized(slotLock) {
                if (activeDownloadSlots < configuredDownloadLimit()) {
                    activeDownloadSlots += 1
                    return true
                }
                runCatching { slotLock.wait(350L) }
            }
        }
        return false
    }

    private fun releaseDownloadSlot() {
        synchronized(slotLock) {
            activeDownloadSlots = (activeDownloadSlots - 1).coerceAtLeast(0)
            slotLock.notifyAll()
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(FOREGROUND_ID, summaryNotification("دانلودر بانک مووی آماده است"))
        when (intent?.action) {
            ACTION_START -> createAndStart(intent)
            ACTION_RESUME -> intent.getStringExtra(EXTRA_ID)?.let { resumeDownload(it) }
            ACTION_PAUSE -> intent.getStringExtra(EXTRA_ID)?.let {
                controls[it]?.pause?.set(true)
                    ?: InternalDownloadStore.update(this, it) { item -> item.put("status", InternalDownloadStore.STATUS_PAUSED) }
            }
            ACTION_CANCEL -> intent.getStringExtra(EXTRA_ID)?.let { cancelDownload(it) }
        }
        return START_STICKY
    }

    private fun createAndStart(intent: Intent) {
        val url = intent.getStringExtra(EXTRA_URL).orEmpty()
        if (!url.startsWith("http", true)) return
        val title = intent.getStringExtra(EXTRA_TITLE).orEmpty().ifBlank { "Bankmovie" }
        val quality = intent.getStringExtra(EXTRA_QUALITY).orEmpty()
        val kind = intent.getStringExtra(EXTRA_KIND).orEmpty()
        val label = intent.getStringExtra(EXTRA_LABEL).orEmpty()
        val poster = intent.getStringExtra(EXTRA_POSTER).orEmpty()
        val id = InternalDownloadStore.idFor(url)
        val existing = InternalDownloadStore.get(this, id)

        if (existing?.optString("status") == InternalDownloadStore.STATUS_COMPLETED && InternalDownloadStore.exists(this, existing)) {
            notifyChanged(id)
            return
        }

        val fileName = existing?.optString("file_name").orEmpty().ifBlank {
            InternalDownloadStore.safeFileName(title, quality, kind, url)
        }
        val item = existing ?: InternalDownloadStore.create(url, title, quality, kind, label, fileName, "", poster)
        if (item.optString("poster").isBlank() && poster.isNotBlank()) item.put("poster", poster)

        if (existing == null || item.optString("storage_mode").isBlank()) {
            runCatching { configureTarget(item, fileName) }.getOrElse {
                DownloadLocationPrefs.setAppFolder(this)
                configureTarget(item, fileName)
            }
        }

        item.put("status", InternalDownloadStore.STATUS_QUEUED)
        item.put("error", "")
        item.put("updated_at", System.currentTimeMillis())
        InternalDownloadStore.upsert(this, item)
        startDownload(id)
    }

    private fun configureTarget(item: JSONObject, fileName: String) {
        val tree = DownloadLocationPrefs.treeUri(this)
        if (DownloadLocationPrefs.mode(this) == DownloadLocationPrefs.MODE_TREE && tree != null) {
            val root = DocumentFile.fromTreeUri(this, tree)
                ?: throw IllegalStateException("پوشه انتخاب‌شده در دسترس نیست")
            val document = root.findFile(fileName)
                ?: root.createFile(InternalDownloadStore.mimeForName(fileName), fileName)
                ?: throw IllegalStateException("ساخت فایل در پوشه انتخاب‌شده ممکن نیست")
            item.put("storage_mode", InternalDownloadStore.STORAGE_TREE)
            item.put("tree_uri", tree.toString())
            item.put("document_uri", document.uri.toString())
            item.put("path", "")
            item.put("location_label", DownloadLocationPrefs.displayName(this))
        } else {
            val target = File(DownloadLocationPrefs.appFolder(this), fileName)
            item.put("storage_mode", InternalDownloadStore.STORAGE_FILE)
            item.put("tree_uri", "")
            item.put("document_uri", "")
            item.put("path", target.absolutePath)
            item.put("location_label", DownloadLocationPrefs.displayName(this))
        }
    }

    private fun resumeDownload(id: String) {
        val item = InternalDownloadStore.get(this, id) ?: return
        item.put("status", InternalDownloadStore.STATUS_QUEUED)
        item.put("error", "")
        InternalDownloadStore.upsert(this, item)
        startDownload(id)
    }

    private fun startDownload(id: String) {
        if (controls.containsKey(id)) return
        val control = Control()
        controls[id] = control
        executor.execute {
            var slotAcquired = false
            try {
                probeRemoteMetadata(id, control)
                slotAcquired = acquireDownloadSlot(control)
                if (slotAcquired) {
                    runDownload(id, control)
                } else if (control.pause.get()) {
                    InternalDownloadStore.update(this, id) { item -> item.put("status", InternalDownloadStore.STATUS_PAUSED) }
                    notifyChanged(id)
                }
            } finally {
                if (slotAcquired) releaseDownloadSlot()
                controls.remove(id)
                stopIfIdle()
            }
        }
    }

    private fun cancelDownload(id: String) {
        val active = controls[id]
        if (active != null) {
            active.cancel.set(true)
        } else {
            InternalDownloadStore.remove(this, id, true)
            notificationManager().cancel(notificationId(id))
            notifyChanged(id)
        }
    }

    private fun openTarget(item: JSONObject): DownloadTarget {
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val uri = Uri.parse(item.optString("document_uri"))
            val descriptor = contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IllegalStateException("مسیر ذخیره‌سازی در دسترس نیست")
            val stream = FileOutputStream(descriptor.fileDescriptor)
            TreeTarget(descriptor, stream)
        } else {
            val file = File(item.optString("path"))
            file.parentFile?.mkdirs()
            FileTarget(file)
        }
    }

    private fun runDownload(id: String, control: Control) {
        val item = InternalDownloadStore.get(this, id) ?: return
        val url = item.optString("url")
        var target: DownloadTarget? = null
        var connection: HttpURLConnection? = null
        var lastUpdate = 0L
        var lastBytes = item.optLong("downloaded", 0L)
        var lastSpeedAt = System.currentTimeMillis()
        var smoothedSpeed = item.optLong("speed", 0L).coerceAtLeast(0L)

        try {
            target = openTarget(item)
            var existing = target.existing.coerceAtLeast(0L)
            connection = openConnection(url, existing)
            var code = connection.responseCode
            if (code == 416 && existing > 0L) {
                val remoteTotal = contentRangeTotal(connection)
                if (remoteTotal > 0L && existing >= remoteTotal) {
                    updateDownloadMetadata(id, remoteTotal, true, true, connection.contentType.orEmpty())
                    updateItem(id, InternalDownloadStore.STATUS_COMPLETED, existing, remoteTotal, 0L, "")
                    notifyDownload(id, item, existing, remoteTotal, InternalDownloadStore.STATUS_COMPLETED)
                    return
                }
                connection.disconnect()
                target.reset()
                existing = 0L
                connection = openConnection(url, 0L)
                code = connection.responseCode
            }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            if (code == HttpURLConnection.HTTP_OK && existing > 0L) {
                target.reset()
                existing = 0L
            }
            target.seek(existing)
            val reported = connection.contentLengthLong.coerceAtLeast(0L)
            val rangeTotal = contentRangeTotal(connection)
            val previousTotal = item.optLong("total", 0L)
            val total = when {
                rangeTotal > 0L -> rangeTotal
                code == HttpURLConnection.HTTP_PARTIAL && reported > 0L -> existing + reported
                code == HttpURLConnection.HTTP_OK && reported > 0L -> reported
                previousTotal > 0L -> previousTotal
                else -> 0L
            }
            val resumeSupported = code == HttpURLConnection.HTTP_PARTIAL || connection.getHeaderField("Accept-Ranges").orEmpty().contains("bytes", true)
            updateDownloadMetadata(id, total, true, resumeSupported, connection.contentType.orEmpty())
            val input = connection.inputStream.buffered(128 * 1024)
            val buffer = ByteArray(128 * 1024)
            var downloaded = existing
            updateItem(id, InternalDownloadStore.STATUS_DOWNLOADING, downloaded, total, 0L, "")

            while (true) {
                if (control.cancel.get()) {
                    runCatching { input.close() }
                    target.close()
                    InternalDownloadStore.deleteDownloadedFile(this, item)
                    InternalDownloadStore.remove(this, id, false)
                    notificationManager().cancel(notificationId(id))
                    notifyChanged(id)
                    return
                }
                if (control.pause.get()) {
                    updateItem(id, InternalDownloadStore.STATUS_PAUSED, downloaded, total, 0L, "")
                    notifyDownload(id, item, downloaded, total, InternalDownloadStore.STATUS_PAUSED)
                    return
                }
                val read = input.read(buffer)
                if (read < 0) break
                target.write(buffer, read)
                downloaded += read
                val now = System.currentTimeMillis()
                if (now - lastUpdate >= 700L) {
                    val elapsed = max(1L, now - lastSpeedAt)
                    val instantSpeed = ((downloaded - lastBytes) * 1000L) / elapsed
                    smoothedSpeed = if (smoothedSpeed <= 0L) instantSpeed else ((smoothedSpeed * 3L) + instantSpeed) / 4L
                    lastBytes = downloaded
                    lastSpeedAt = now
                    lastUpdate = now
                    updateItem(id, InternalDownloadStore.STATUS_DOWNLOADING, downloaded, total, smoothedSpeed, "")
                    notifyDownload(id, item, downloaded, total, InternalDownloadStore.STATUS_DOWNLOADING)
                }
            }

            target.sync()
            if (total > 0L && downloaded < total) {
                throw IllegalStateException("دانلود ناقص ماند: ${downloaded}/${total} بایت")
            }
            val completedTotal = if (total > 0L) total else downloaded
            updateDownloadMetadata(id, completedTotal, true, resumeSupported, connection.contentType.orEmpty())
            updateItem(id, InternalDownloadStore.STATUS_COMPLETED, downloaded, completedTotal, 0L, "")
            notifyDownload(id, item, downloaded, completedTotal, InternalDownloadStore.STATUS_COMPLETED)
        } catch (error: Throwable) {
            val current = InternalDownloadStore.get(this, id) ?: item
            val downloaded = current.optLong("downloaded", 0L)
            val knownTotal = current.optLong("total", 0L)
            updateItem(id, InternalDownloadStore.STATUS_FAILED, downloaded, knownTotal, 0L, error.message ?: "خطای دانلود")
            notifyDownload(id, current, downloaded, knownTotal, InternalDownloadStore.STATUS_FAILED)
        } finally {
            runCatching { target?.close() }
            connection?.disconnect()
        }
    }

    private fun contentRangeTotal(connection: HttpURLConnection): Long {
        val raw = connection.getHeaderField("Content-Range").orEmpty().substringAfterLast('/', "").trim()
        return raw.toLongOrNull()?.coerceAtLeast(0L) ?: 0L
    }

    private fun updateDownloadMetadata(id: String, total: Long, checked: Boolean, resumeSupported: Boolean, contentType: String) {
        InternalDownloadStore.update(this, id) { item ->
            if (total > 0L) item.put("total", total)
            item.put("resume_checked", checked)
            item.put("resume_supported", resumeSupported)
            if (contentType.isNotBlank()) item.put("content_type", contentType)
            item.put("updated_at", System.currentTimeMillis())
        }
        notifyChanged(id)
    }

    private fun probeRemoteMetadata(id: String, control: Control) {
        val item = InternalDownloadStore.get(this, id) ?: return
        if (item.optBoolean("resume_checked", false) && item.optLong("total", 0L) > 0L) return
        if (control.cancel.get() || control.pause.get()) return
        var connection: HttpURLConnection? = null
        try {
            connection = openProbeConnection(item.optString("url"), false)
            var code = connection.responseCode
            var total = contentRangeTotal(connection).takeIf { it > 0L } ?: connection.contentLengthLong.coerceAtLeast(0L)
            var resume = connection.getHeaderField("Accept-Ranges").orEmpty().contains("bytes", true)
            var contentType = connection.contentType.orEmpty()
            if (code == HttpURLConnection.HTTP_BAD_METHOD || code == HttpURLConnection.HTTP_FORBIDDEN || total <= 0L) {
                connection.disconnect()
                connection = openProbeConnection(item.optString("url"), true)
                code = connection.responseCode
                if (code in 200..299 || code == 416) {
                    total = contentRangeTotal(connection).takeIf { it > 0L } ?: connection.contentLengthLong.coerceAtLeast(0L)
                    resume = code == HttpURLConnection.HTTP_PARTIAL || connection.getHeaderField("Accept-Ranges").orEmpty().contains("bytes", true)
                    contentType = connection.contentType.orEmpty()
                }
                runCatching { connection.inputStream.close() }
            }
            if (code in 200..299 || code == 416) {
                updateDownloadMetadata(id, total, true, resume, contentType)
            }
        } catch (_: Throwable) {
            InternalDownloadStore.update(this, id) { current ->
                current.put("resume_checked", true)
                current.put("updated_at", System.currentTimeMillis())
            }
            notifyChanged(id)
        } finally {
            connection?.disconnect()
        }
    }

    private fun openProbeConnection(source: String, rangeProbe: Boolean): HttpURLConnection {
        var current = source
        repeat(6) {
            val connection = URL(current).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 12000
            connection.readTimeout = 12000
            connection.requestMethod = if (rangeProbe) "GET" else "HEAD"
            connection.setRequestProperty("User-Agent", "BankmovieDownloader/2.1 Android")
            connection.setRequestProperty("Accept", "*/*")
            connection.setRequestProperty("Accept-Encoding", "identity")
            if (rangeProbe) connection.setRequestProperty("Range", "bytes=0-0")
            connection.connect()
            if (connection.responseCode in listOf(301, 302, 303, 307, 308)) {
                val location = connection.getHeaderField("Location") ?: return connection
                current = URL(URL(current), location).toString()
                connection.disconnect()
            } else return connection
        }
        throw IllegalStateException("Too many redirects")
    }

    private fun openConnection(source: String, start: Long): HttpURLConnection {
        var current = source
        repeat(6) {
            val connection = URL(current).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = false
            connection.connectTimeout = 20000
            connection.readTimeout = 30000
            connection.setRequestProperty("User-Agent", "BankmovieDownloader/2.1 Android")
            connection.setRequestProperty("Accept", "*/*")
            connection.setRequestProperty("Accept-Encoding", "identity")
            if (start > 0L) connection.setRequestProperty("Range", "bytes=$start-")
            connection.connect()
            if (connection.responseCode in listOf(301, 302, 303, 307, 308)) {
                val location = connection.getHeaderField("Location") ?: return connection
                current = URL(URL(current), location).toString()
                connection.disconnect()
            } else {
                return connection
            }
        }
        throw IllegalStateException("Too many redirects")
    }

    private fun updateItem(id: String, status: String, downloaded: Long, total: Long, speed: Long, error: String) {
        InternalDownloadStore.update(this, id) { item ->
            item.put("status", status)
            item.put("downloaded", downloaded)
            item.put("total", total)
            item.put("speed", speed)
            item.put("error", error)
            item.put("updated_at", System.currentTimeMillis())
        }
        notifyChanged(id)
    }

    private fun notifyChanged(id: String) {
        sendBroadcast(Intent(ACTION_CHANGED).setPackage(packageName).putExtra(EXTRA_ID, id))
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "دانلودهای بانک مووی", NotificationManager.IMPORTANCE_LOW).apply {
                description = "وضعیت دانلود فیلم و سریال"
                setSound(null, null)
            }
            notificationManager().createNotificationChannel(channel)
        }
    }

    private fun notificationManager(): NotificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun summaryNotification(text: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle("Bankmovie Downloader")
            .setContentText(text)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun notifyDownload(id: String, source: JSONObject, downloaded: Long, total: Long, status: String) {
        val title = source.optString("title").ifBlank { "Bankmovie" }
        val percent = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0
        val openIntent = Intent(this, MainActivity::class.java).apply {
            putExtra("open_downloads", true)
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val contentPending = PendingIntent.getActivity(this, notificationId(id), openIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_download)
            .setContentTitle(title)
            .setContentIntent(contentPending)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)

        when (status) {
            InternalDownloadStore.STATUS_COMPLETED -> builder
                .setContentText("دانلود کامل شد")
                .setProgress(0, 0, false)
                .setOngoing(false)
                .setAutoCancel(true)
            InternalDownloadStore.STATUS_PAUSED -> builder
                .setContentText("متوقف شده • $percent٪")
                .setProgress(100, percent, false)
                .setOngoing(false)
                .addAction(R.drawable.ic_play_fill, "ادامه", commandPending(ACTION_RESUME, id, 1))
            InternalDownloadStore.STATUS_FAILED -> builder
                .setContentText("خطا در دانلود • برای تلاش مجدد بزن")
                .setProgress(0, 0, false)
                .setOngoing(false)
                .addAction(R.drawable.ic_play_fill, "تلاش مجدد", commandPending(ACTION_RESUME, id, 2))
            else -> builder
                .setContentText(if (total > 0L) "$percent٪" else "در حال دانلود")
                .setProgress(100, percent, total <= 0L)
                .setOngoing(true)
                .addAction(R.drawable.ic_player_pause, "توقف", commandPending(ACTION_PAUSE, id, 3))
                .addAction(R.drawable.ic_close_clean, "لغو", commandPending(ACTION_CANCEL, id, 4))
        }
        notificationManager().notify(notificationId(id), builder.build())
    }

    private fun commandPending(actionName: String, id: String, salt: Int): PendingIntent {
        val intent = Intent(this, InternalDownloadService::class.java).apply {
            action = actionName
            putExtra(EXTRA_ID, id)
        }
        return PendingIntent.getService(this, notificationId(id) + salt, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun notificationId(id: String): Int = 18200 + (id.hashCode() and 0x3fff)

    private fun stopIfIdle() {
        if (controls.isEmpty()) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
