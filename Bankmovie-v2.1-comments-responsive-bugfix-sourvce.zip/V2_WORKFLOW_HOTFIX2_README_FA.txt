Bankmovie V2.0 — Workflow Hotfix 2

شناسه Workflow صحیح:
V2-HOTFIX-20260716-2

در این نسخه مرحله Patch شمارشیِ پس‌زمینه شفاف به‌طور کامل حذف شده است.
سورس از قبل اصلاح شده و Workflow فقط بررسی می‌کند عبارت نامعتبر
background = Color.TRANSPARENT
در MainActivity.kt وجود نداشته باشد.

در لاگ GitHub Actions باید مرحله «Show workflow revision» و عبارت زیر دیده شود:
WORKFLOW_REVISION=V2-HOTFIX-20260716-2
