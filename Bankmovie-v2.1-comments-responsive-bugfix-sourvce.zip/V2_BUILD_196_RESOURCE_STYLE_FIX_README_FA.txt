Bankmovie V2.0 — اصلاح خطای Build شماره 196

خطای گزارش‌شده:
AAPT: resource style/BankMovie not found

علت:
نام استایل BankMovie.DialogAnimation دارای نقطه بود و چون parent مشخص نشده بود،
Android به‌صورت خودکار دنبال استایل والد با نام BankMovie می‌گشت.

اصلاح انجام‌شده:
برای BankMovie.DialogAnimation مقدار parent خالی به‌صورت صریح ثبت شد تا Android
دیگر والد BankMovie را استنتاج نکند:

<style name="BankMovie.DialogAnimation" parent="">

نسخه نمایشی برنامه همچنان 2.0 است و همه تغییرات قبلی حفظ شده‌اند.
