Bankmovie V1.9 — V21 Advanced Search
========================================

این نسخه جستجوی پیشرفته را به صفحه جستجوی برنامه اضافه می‌کند.

امکانات رابط کاربری
-------------------
- پنل باز و بسته‌شونده شبیه باکس دانلود
- سوییچ آرشیو ۱ و آرشیو ۲ در همان صفحه
- فیلتر نوع محتوا: همه، فیلم، سریال
- فیلتر ژانر
- بازه سال ساخت
- کشور
- مرتب‌سازی
- حداقل امتیاز IMDb
- فقط دوبله
- فقط زیرنویس
- امکان جستجو با نام همراه با فیلترها یا فقط با فیلترها
- صفحه نتایج جدا با صفحه‌بندی و دکمه ویرایش فیلترها
- سازگار با موبایل و کنترل تلویزیون

منابع جستجو
-----------
آرشیو ۱:
- به archive1_live.php متصل می‌شود.
- فیلترها مطابق فرم Oldtowns / Film2Media ارسال می‌شوند.
- type, genre[], sortby, imdbrate, madeby[], min_year, max_year, dubbed, subtitle

آرشیو ۲:
- به api5.php متصل می‌شود.
- فیلترها مطابق فرم SerialBlog ارسال می‌شوند.
- search_type=advanced, post_type, genre, rating, order, yearFrom, yearTo, country, double, subtitle

نصب
----
1. فایل ZIP سورس را با نام خودش در ریشه مخزن GitHub قرار بده.
2. Workflow را با نام .github/workflows/build-apk.yml جایگزین کن.
3. فایل‌های داخل بسته Server را در سرور جایگزین کن:
   - api5.php
   - api5_lib.php
   - archive1_live.php
   - archive1_live_lib.php

تست سرور
---------
آرشیو ۲:
api5.php?advanced=1&type=series&genre=درام&yearFrom=2020&yearTo=2026&order=newest&page=1

آرشیو ۱:
archive1_live.php?advanced=1&type=movie&genre_id=49166&sortby=newest&year_from=2020&year_to=2026&page=1

نکته
-----
نسخه نمایشی برنامه همچنان 1.9 است و فقط versionCode افزایش یافته تا روی نسخه قبلی نصب شود.
