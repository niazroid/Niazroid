# BankMoviee Android WebView + Native VLC Player

این پروژه برای سایت BankMoviee ساخته شده و دو بخش اصلی دارد:

1. `MainActivity` سایت `https://bankmoviee.ir/` را داخل WebView باز می‌کند.
2. وقتی کاربر روی دکمه‌های پخش سایت با کلاس `.arc1-play-btn` بزند، اپ لینک ویدیو را می‌گیرد و آن را در `PlayerActivity` با موتور VLC/libVLC پخش می‌کند.

## قابلیت‌ها

- WebView کامل برای سایت
- حفظ لاگین و کوکی‌ها داخل WebView
- پشتیبانی از آپلود فایل داخل WebView
- گرفتن خودکار دکمه‌های پخش `movie.php`
- پلیر Native با `libVLC`
- پشتیبانی بهتر از MKV، MP4، M3U8/HLS، AVI، WEBM و TS
- پشتیبانی از زیرنویس داخلی soft-sub داخل MKV
- انتخاب ترک صوتی
- انتخاب ترک زیرنویس
- اضافه کردن فایل زیرنویس خارجی SRT/ASS/VTT از گوشی
- پشتیبانی از لینک خارجی زیرنویس اگر سایت آن را با `data-subtitle` یا `data-sub` بدهد
- دکمه عقب/جلو ۱۰ ثانیه
- کنترل چرخش صفحه
- امکان باز شدن مستقیم لینک‌های `bankmoviee://play`

## ساخت APK در Android Studio

1. پوشه پروژه را در Android Studio باز کن.
2. صبر کن Gradle Sync کامل شود.
3. از مسیر زیر APK بگیر:

`Build > Build Bundle(s) / APK(s) > Build APK(s)`

خروجی معمولاً اینجا ساخته می‌شود:

`app/build/outputs/apk/debug/app-debug.apk`

برای نسخه قابل انتشار:

`Build > Generate Signed Bundle / APK`

## تنظیم آدرس سایت

اگر دامنه تغییر کرد، این فایل را ویرایش کن:

`app/src/main/java/ir/bankmoviee/app/AppConfig.kt`

```kotlin
const val BASE_URL = "https://bankmoviee.ir/"
```

## روش اتصال سایت به پلیر اپ

اپ به صورت خودکار دکمه‌های زیر را از سایت می‌گیرد:

```html
<button class="arc1-play-btn" data-url="https://example.com/movie.mkv">پخش</button>
```

برای لینک دستی هم این مدل پشتیبانی می‌شود:

```html
<a href="bankmoviee://play?video=https%3A%2F%2Fexample.com%2Fmovie.mkv">پخش در اپ</a>
```

برای زیرنویس جدا:

```html
<button
  class="arc1-play-btn"
  data-url="https://example.com/movie.mkv"
  data-subtitle="https://example.com/subtitle.srt">
  پخش
</button>
```

## نکته مهم درباره زیرنویس Soft-sub

اگر زیرنویس داخل فایل MKV باشد، libVLC معمولاً خودش ترک‌های زیرنویس را می‌شناسد و از دکمه CC می‌توانی انتخابش کنی.

اگر زیرنویس جدا باشد، سایت باید لینک زیرنویس را با `data-subtitle` بدهد یا کاربر از داخل پلیر فایل زیرنویس را دستی انتخاب کند.

## نکته مهم درباره لینک‌های فیلم

برای نتیجه حرفه‌ای، لینک پخش باید مستقیم باشد:

- `.mkv`
- `.mp4`
- `.m3u8`
- `.avi`
- `.webm`
- `.ts`

اگر پخش داخل iframe سایت‌های خارجی باشد و لینک واقعی ویدیو مخفی باشد، پلیر Native نمی‌تواند همیشه آن را استخراج کند.

## فایل اختیاری سایت

داخل پوشه `website-optional` یک فایل JS گذاشته شده. لازم نیست حتماً نصب شود، چون اپ خودش Bridge را inject می‌کند. ولی اگر خواستی خود سایت هم آماده‌ی deep link باشد، می‌توانی آن را به سایت اضافه کنی.
