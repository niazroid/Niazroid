Bankmovie V1.4 V2

تغییرات این نسخه:
- حذف متن نسخه از زیر اسپینر لودینگ جزئیات فیلم
- دریافت لینک APK مناسب معماری دستگاه: ARM64 / V7A / Universal
- عدم نمایش پیام آپدیت وقتی نسخه نصب‌شده و نسخه پنل یکسان است
- پشتیبانی از version_policy برای غیرفعال‌کردن نسخه مشخص مثل 1.3
- پشتیبانی از حداقل Version Name و Version Code مجاز
- نسخه غیرفعال قبل از دریافت صفحه اصلی متوقف می‌شود

ساختار جدید app_config.php:
update.apk_urls.universal
update.apk_urls.arm64_v8a
update.apk_urls.armeabi_v7a
version_policy.blocked_version_names
version_policy.blocked_version_codes
version_policy.minimum_version_name
version_policy.minimum_version_code
