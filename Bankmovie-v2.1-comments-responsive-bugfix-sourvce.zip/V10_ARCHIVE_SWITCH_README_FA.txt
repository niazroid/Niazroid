Bankmovie V1.5 V10 — Archive Switch
===================================

تغییرات اصلی برنامه:
- سوییچ دوحالته «آرشیو ۱ / آرشیو ۲» روی همان صفحه اصلی، بدون صفحه جدا
- طراحی سوییچ با SVG و حالت فعال آبی؛ بدون ایموجی
- ذخیره آخرین آرشیو انتخاب‌شده روی دستگاه
- صفحه اصلی، جستجو، لیست‌ها، جزئیات و پیشنهادها براساس آرشیو انتخاب‌شده کار می‌کنند
- آرشیو ۲ از API مستقل api5.php استفاده می‌کند
- بخش دوبله آرشیو ۱ از منبع زنده archive1_live.php دریافت می‌شود تا فهرست قدیمی نمایش داده نشود
- بخش جدید «سریال‌های چینی» به آرشیو ۱ اضافه شده است
- مسیر هوشمند برگشت، ادامه تماشا، نشان دیده‌شده، انتخاب پلیر و سایر قابلیت‌های قبلی حفظ شده‌اند
- نسخه نمایشی: 1.5
- versionCode: 1150000 + شماره اجرای GitHub Actions
- امضای برنامه همان امضای نسخه‌های قبلی Bankmovie است

فایل‌های لازم روی سرور:
- archive1_live.php
- archive1_live_lib.php
- api5.php
- api5_lib.php

این چهار فایل را کنار app_api.php و app_config.php در دامنه فعال قرار دهید.
اپ به‌صورت پیش‌فرض مسیرهای زیر را می‌خواند:
- https://YOUR-DOMAIN/archive1_live.php
- https://YOUR-DOMAIN/api5.php

کلیدهای اختیاری تنظیمات از راه دور:
"archive1_live_api_url": "https://YOUR-DOMAIN/archive1_live.php",
"archive2_api_url": "https://YOUR-DOMAIN/api5.php",
"archive1_source_url": "https://www.oldtowns.top"

نیازمندی سرور PHP:
- curl
- dom
- mbstring

تست مسیرها:
- /archive1_live.php?ping=1
- /archive1_live.php?section=dubbed&page=1
- /archive1_live.php?section=chinese_series&page=1
- /api5.php?ping=1
- /api5.php?section=new_movies&page=1
- /api5.php?section=new_series&page=1
