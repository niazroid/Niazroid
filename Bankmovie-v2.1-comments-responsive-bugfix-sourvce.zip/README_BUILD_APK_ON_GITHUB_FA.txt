روش بی دردسر ساخت APK بدون گیر کردن روی اینترنت ویندوز

مشکل فعلی روی سیستم شما این است که Android Studio نمی‌تواند Android Gradle Plugin را از Google Maven دانلود کند.
این فایل GitHub Actions اضافه شده تا پروژه روی سرورهای GitHub ساخته شود و شما فقط APK را دانلود کنید.

مراحل:

1) داخل GitHub یک Repository جدید بساز.
2) همه فایل‌های داخل پوشه BankMovieeNativeVLCApp را داخل آن آپلود کن.
3) برو به تب Actions.
4) از سمت چپ Build Android APK را انتخاب کن.
5) روی Run workflow بزن.
6) چند دقیقه صبر کن تا Build کامل شود.
7) آخر صفحه اجرای Workflow بخش Artifacts را باز کن.
8) فایل BankMoviee-debug-apk را دانلود کن.
9) داخل فایل دانلودی، app-debug.apk قرار دارد.

نکته:
این روش دیگر به Android Studio و VPN ویندوز وابسته نیست.
GitHub خودش Gradle، Android SDK و dependency ها را دانلود می‌کند.
