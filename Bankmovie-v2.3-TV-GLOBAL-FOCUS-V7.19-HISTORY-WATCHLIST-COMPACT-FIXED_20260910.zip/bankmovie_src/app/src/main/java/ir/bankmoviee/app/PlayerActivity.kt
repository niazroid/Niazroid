package ir.bankmoviee.app

// BANKMOVIE_PASS4_6_2_SOURCE_FINGERPRINT: player-lifecycle-guest-glass-viewgroup-compile-fix

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.UUID
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PLAYLIST_FILE = "playlist_file"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RESUME_POSITION = "resume_position"
        const val EXTRA_WATCH_PARTY_ROOM_CODE = "watch_party_room_code"
        const val EXTRA_WATCH_PARTY_ROLE = "watch_party_role"
        const val EXTRA_WATCH_PARTY_INVITE_URL = "watch_party_invite_url"
        private const val REQ_WATCH_PARTY_AUDIO = 7401
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue: Int get() = UiPreferences.accentColor(this)
    private val blue2: Int get() = UiPreferences.blend(blue, Color.WHITE, 0.28f)
    private val blue3: Int get() = Color.argb(170, Color.red(blue), Color.green(blue), Color.blue(blue))
    private val panel = Color.argb(230, 12, 12, 14)
    private val stroke = Color.argb(115, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 192, 202)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var playerTopActions: LinearLayout
    private lateinit var playerBottomActions: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private var requestedResumePosition = 0L
    private var resumeTarget = 0L
    private var resumeGuardUntil = 0L
    private var seekJumpMs = 10000L
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchStartBrightness = 0.5f
    private var touchStartVolume = 0
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var nextPromptShownKey = ""
    private var skipNextOnce = false
    private var nextPromptDialog: AlertDialog? = null
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var playbackRetryCount = 0
    private val maxPlaybackRetries = 5
    private var playbackRetryScheduled = false
    private var bufferingStartedAt = 0L
    private var recentLongBufferCount = 0
    private var decoderAutoFallbackUsed = false
    private var lifecycleRestorePending = false
    private var lifecycleWasPlaying = false
    private var lifecyclePosition = 0L
    private var lifecyclePausedAt = 0L
    private var pauseAfterLifecycleRestore = false
    private var lifecycleViewsDetached = false
    private var lifecycleRestoreGeneration = 0
    private var lastGuestControlNoticeAt = 0L
    private var subtitleDelayMs = 0
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackgroundMode = "black"
    private var subtitleFontMode = "system"
    private var subtitleBold = true
    private var lastEnabledSpuTrack = 0
    private var preferredAudioTrackId = Int.MIN_VALUE
    private var preferredSubtitleTrackId = Int.MIN_VALUE
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }


    // PASS 4 — Native Watch Party state. The app talks to the exact same tables
    // used by the website through app_user_api.php, so web and Android can share a room.
    private var partyRoomCode = ""
    private var partyRole = ""
    private var partyInviteUrl = ""
    private var partyIsHost = false
    private var partyActive = false
    private var partyApplyingRemote = false
    private var partyLastEventId = 0L
    private var partyLastMessageId = 0L
    private var partyLastSequence = -1L
    private var partyServerOffsetMs = 0L
    private var partyLastPollAt = 0L
    private var partyLastHeartbeatAt = 0L
    private var partyLastHostActionAt = 0L
    private var partyMembers = JSONArray()
    private var partyThemeKey = "simple"
    private var partyRoomTitle = ""
    private var partyRoomPoster = ""
    private var partyChatEnabled = true
    private var partyPollInFlight = false
    private var partyDock: LinearLayout? = null
    private var partyStatusChip: TextView? = null
    private var partyChatScroll: ScrollView? = null
    private var partyChatList: LinearLayout? = null
    private var partyChatDialog: AlertDialog? = null
    private var partyLobbyDialog: AlertDialog? = null
    private val partyMessageIdsShown = linkedSetOf<Long>()
    private var partyUnreadChat = 0
    private var partyChatButton: View? = null
    private var partyPlaybackStarted = false
    // A joined guest must explicitly confirm inside the player lobby before any
    // host state is allowed to create/start the local decoder.
    private var partyReadyConfirmed = false
    private var partyGuestAutoStarting = false
    private var partyLastExplicitPlaySentAt = 0L
    private val partyChromeHideRunnable = Runnable {
        if (partyActive && partyChatDialog?.isShowing != true) setPartyChromeVisible(false)
    }

    private val partyPollRunnable = object : Runnable {
        override fun run() {
            if (partyActive && !isFinishing && !isDestroyed) {
                pollWatchParty()
                if (partyIsHost) sendWatchPartyHeartbeatIfNeeded()
                handler.postDelayed(this, if (partyIsHost) 420L else 360L)
            }
        }
    }

    // PASS 4.3 — Voice Call/WebRTC intentionally removed. Watch Party is chat + synchronized playback only.

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        try {
            parseIncoming()
            loadUiPreferences()
            if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
            if (currentIndex !in tracks.indices) currentIndex = 0
            videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
            title = tracks.getOrNull(currentIndex)?.title ?: title
            progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
            if (videoUrl.isBlank()) throw IllegalArgumentException("Empty playback URL")
            currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
            buildUi()
            if (partyRoomCode.isNotBlank()) {
                partyActive = true
                partyIsHost = partyRole.equals("host", true)
                buildWatchPartyOverlay()
                updateGuestPlaybackLockUi()
                showWatchPartyLobby()
                handler.removeCallbacks(partyPollRunnable)
                handler.postDelayed(partyPollRunnable, 350L)
            } else {
                switchTo(currentIndex)
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "این نسخه پخش معتبر نیست؛ نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private var currentBrightness = 0.55f

    private fun loadUiPreferences() {
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackgroundMode = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleDelayMs = UiPreferences.subtitleDelayMs(this)
        subtitleFontMode = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePositionIndex = UiPreferences.subtitlePosition(this)
        seekJumpMs = UiPreferences.seekSeconds(this).toLong() * 1000L
        autoPlayNext = UiPreferences.autoNext(this)
    }

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        requestedResumePosition = intent.getLongExtra(EXTRA_RESUME_POSITION, 0L).coerceAtLeast(0L)
        partyRoomCode = intent.getStringExtra(EXTRA_WATCH_PARTY_ROOM_CODE).orEmpty().trim()
        partyRole = intent.getStringExtra(EXTRA_WATCH_PARTY_ROLE).orEmpty().trim()
        partyInviteUrl = intent.getStringExtra(EXTRA_WATCH_PARTY_INVITE_URL).orEmpty().trim()
        val payloadFile = intent.getStringExtra(EXTRA_PLAYLIST_FILE).orEmpty()
        val json = if (payloadFile.isNotBlank()) {
            runCatching {
                File(payloadFile).takeIf { it.isFile && it.length() in 1..2_500_000L }?.readText(Charsets.UTF_8).orEmpty()
            }.getOrDefault("").ifBlank { intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty() }
        } else {
            intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty()
        }
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until min(arr.length(), 160)) {
                    val it = arr.optJSONObject(i) ?: continue
                    if (it.optString("url").isBlank()) continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, Color.red(blue), Color.green(blue), Color.blue(blue)))
            setStroke(dp(2), Color.argb(205, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), blue2)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            v.foreground = if (has) playerFocusDrawable(radiusDp) else originalForeground
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.translationZ = if (has) dp(8).toFloat() else 0f
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(if (has) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun focusPlayButton() {
        if (partyGuestPlaybackLocked()) {
            partyChatButton?.takeIf { it.isShown && it.isFocusable }?.requestFocus() ?: root.requestFocus()
            return
        }
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                if (v is android.view.ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                }
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 55)
    }

    private fun ccAudioSubtitleButton(click: () -> Unit): View {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            contentDescription = "صدا و زیرنویس"
            applyPlayerFocus(this, 20, 1.08f, 0f)
            setOnClickListener { click() }
            addView(TextView(this@PlayerActivity).apply {
                text = "CC"
                setTextColor(Color.BLACK)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                includeFontPadding = false
                letterSpacing = -0.03f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    setColor(Color.WHITE)
                    cornerRadius = dp(3).toFloat()
                }
            }, FrameLayout.LayoutParams(dp(29), dp(21), Gravity.CENTER))
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = VLCVideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(58, 0, 0, 0), Color.TRANSPARENT)
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { if (partyActive) showPartyRoomSheet() else finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        subText = TextView(this).apply {
            text = currentLabel()
            setTextColor(muted)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        info.addView(titleText)
        info.addView(subText)
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })

        playerTopActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        playerTopActions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(58), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(ccAudioSubtitleButton { showAudioSubtitleSettingsSheet() }, LinearLayout.LayoutParams(dp(50), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(simplePlayerIcon(R.drawable.ic_player_pip) { enterPipMode() }, LinearLayout.LayoutParams(dp(50), dp(48)))
        topBar.addView(playerTopActions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(74), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        val jumpLabel = (seekJumpMs / 1000L).toString()
        val rewind = circleAction(R.drawable.ic_player_replay, jumpLabel) { seekBy(-seekJumpMs) }.apply { id = View.generateViewId() }
        val play = FrameLayout(this).apply {
            id = View.generateViewId()
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, jumpLabel) { seekBy(seekJumpMs) }.apply { id = View.generateViewId() }
        rewind.nextFocusRightId = play.id
        play.nextFocusLeftId = rewind.id
        play.nextFocusRightId = forward.id
        forward.nextFocusLeftId = play.id
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(22) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(82), dp(82)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginStart = dp(22) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(104), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(4), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(225, 0, 0, 0))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        playerBottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            // Utility controls live on the opposite/right edge, away from the
            // timeline start and closer to the top-right playback tools.
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        val settingsButton = glassIconButton(R.drawable.ic_player_settings) { showSettingsSheet() }
        playerBottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(58), dp(32)).apply { marginEnd = dp(8) })
        playerBottomActions.addView(settingsButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        bottomBar.addView(playerBottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); gravity = Gravity.RIGHT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(116), Gravity.BOTTOM))

        // Use the same state transition as the normal lock button. The previous
        // direct boolean assignment left this unlock icon visible after unlocking.
        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { toggleLock() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(18) })

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (partyGuestPlaybackLocked()) {
                    showGuestPlaybackLockedNotice()
                    updateProgress()
                    hideBarsLater()
                    return
                }
                val progress = s?.progress ?: 0
                val p = player ?: return
                if (p.length > 0) p.time = (progress.toLong() * p.length) / 1000L
                if (partyActive && partyIsHost) sendWatchPartyControl("seek")
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    // ---------------------------------------------------------------------
    // PASS 4.3 — Native Watch Party room UI + sync + site-style chat + sticker packs
    // ---------------------------------------------------------------------
    private fun partyGlass(radius: Int = 22, alpha: Int = 224, strokeAlpha: Int = 72): GradientDrawable {
        val base = Color.rgb(24, 25, 29)
        val top = Color.argb(alpha.coerceIn(0,255), 38, 39, 44)
        val bottom = Color.argb((alpha - 18).coerceIn(0,255), Color.red(base), Color.green(base), Color.blue(base))
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0,255), 255,255,255))
        }
    }

    private fun partyAccent(radius: Int = 20): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(91, 74, 230), Color.rgb(48, 128, 249))).apply {
            cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.argb(180, 181, 199, 255))
        }

    // PASS 4.6 — player chrome uses the same charcoal glass language as the app.
    private fun playerGlassSurface(radius: Int = 24, alpha: Int = 238, strokeAlpha: Int = 72): GradientDrawable {
        val top = Color.argb(alpha.coerceIn(0, 255), 38, 39, 44)
        val bottom = Color.argb((alpha - 18).coerceIn(0, 255), 21, 22, 26)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0, 255), 255, 255, 255))
        }
    }

    private fun playerGlassAccent(radius: Int = 20): GradientDrawable {
        val p = UiPreferences.palette(this)
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            UiPreferences.blend(p.primary, Color.WHITE, 0.12f),
            p.primary
        )).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
    }

    private fun partyGuestPlaybackLocked(): Boolean = partyActive && !partyIsHost

    private fun showGuestPlaybackLockedNotice() {
        val now = System.currentTimeMillis()
        if (now - lastGuestControlNoticeAt < 900L) return
        lastGuestControlNoticeAt = now
        showHud("کنترل پخش دست میزبان است · فقط صدا برای شما آزاد است")
    }

    private fun setPlaybackControlTreeEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        view.isFocusable = enabled
        view.alpha = if (enabled) 1f else 0.38f
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) setPlaybackControlTreeEnabled(view.getChildAt(i), enabled)
        }
    }

    private fun updateGuestPlaybackLockUi() {
        if (!::seek.isInitialized || !::centerControls.isInitialized) return
        val enabled = !partyGuestPlaybackLocked()
        seek.isEnabled = enabled
        seek.isFocusable = enabled
        seek.alpha = if (enabled) 1f else 0.42f
        setPlaybackControlTreeEnabled(centerControls, enabled)
        if (::playerTopActions.isInitialized) setPlaybackControlTreeEnabled(playerTopActions, enabled)
        if (::playerBottomActions.isInitialized) setPlaybackControlTreeEnabled(playerBottomActions, enabled)
        // Room/chat controls are intentionally separate and stay available to guests.
    }

    private fun partyIcon(icon: Int, description: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            contentDescription = description
            background = partyGlass(18, 232, 76)
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 18, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon); setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }
    }

    private fun buildWatchPartyOverlay() {
        partyStatusChip = TextView(this).apply {
            text = if (partyIsHost) "●  میزبان · همگام" else "●  همراه · همگام"
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyGlass(999, 218, 68)
            setPadding(dp(13), dp(7), dp(13), dp(7))
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 999, 1.04f, 0f)
            setOnClickListener { showPartyChrome(); showPartyRoomSheet() }
        }
        root.addView(partyStatusChip, FrameLayout.LayoutParams(-2, dp(38), Gravity.TOP or Gravity.RIGHT).apply {
            topMargin = dp(80); rightMargin = dp(18)
        })

        partyDock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = partyGlass(24, 218, 64)
        }
        val chat = partyIcon(R.drawable.ic_party_chat, "گفت‌وگو") { showPartyChrome(); showWatchPartyChat() }
        partyChatButton = chat
        val settings = partyIcon(R.drawable.ic_player_settings, "تنظیمات اتاق") { showPartyChrome(); showPartyRoomSheet() }
        partyDock?.addView(chat, LinearLayout.LayoutParams(dp(52), dp(52)).apply { bottomMargin = dp(8) })
        partyDock?.addView(settings, LinearLayout.LayoutParams(dp(52), dp(52)))
        root.addView(partyDock, FrameLayout.LayoutParams(dp(64), -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        applyPartyTheme("simple")
        showPartyChrome()
    }

    private fun setPartyChromeVisible(visible: Boolean) {
        val value = if (visible) View.VISIBLE else View.GONE
        partyDock?.visibility = value
        partyStatusChip?.visibility = value
        if (visible) {
            partyDock?.alpha = 1f
            partyStatusChip?.alpha = 1f
        }
    }

    private fun showPartyChrome() {
        if (!partyActive) return
        setPartyChromeVisible(true)
        handler.removeCallbacks(partyChromeHideRunnable)
        handler.postDelayed(partyChromeHideRunnable, 5000L)
    }

    private fun updatePartyStatusChip() {
        val count = partyMembers.length()
        val label = if (partyIsHost) "میزبان" else "همراه"
        partyStatusChip?.text = "●  $label · ${if (count > 0) "$count نفر" else "همگام"}"
        partyStatusChip?.setTextColor(if (partyPollInFlight) Color.rgb(220,224,232) else Color.WHITE)
        updateChatBadge()
    }

    private fun showWatchPartyLobby() {
        if (!partyActive || partyRoomCode.isBlank()) return
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16),dp(16),dp(16),dp(16))
            background = partyGlass(28,246,86)
        }
        shell.addView(TextView(this).apply {
            text = "سینمای خصوصی BankMovie"
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        shell.addView(TextView(this).apply {
            text = if (partyIsHost)
                "این اتاق تا ۴ ساعت برایت می‌ماند؛ فیلم یا کیفیت بعدی هم داخل همین اتاق عوض می‌شود."
            else
                "به اتاق وارد شدی؛ پس از آماده‌شدن، پخش با میزبان همگام می‌شود."
            setTextColor(muted)
            textSize = 11f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.04f)
        }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(5) })
        shell.addView(TextView(this).apply {
            text = partyRoomCode
            setTextColor(Color.rgb(134,178,255))
            textSize = 18f
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            background = partyGlass(18,214,62)
        }, LinearLayout.LayoutParams(-1,dp(52)).apply { topMargin = dp(14) })

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun btn(label:String,primary:Boolean=false,click:()->Unit)=TextView(this).apply {
            text=label
            setTextColor(Color.WHITE)
            textSize=12f
            typeface=Typeface.DEFAULT_BOLD
            gravity=Gravity.CENTER
            background=if(primary) partyAccent(18) else partyGlass(18,218,60)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this,18,1.04f,0f)
            setOnClickListener { click() }
        }
        row.addView(btn("کپی دعوت") {
            copyPartyInvite()
            Toast.makeText(this,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(0,dp(48),1f).apply { marginStart=dp(5) })
        row.addView(btn("اعضای اتاق") {
            dialog.dismiss()
            showPartyMembers()
        }, LinearLayout.LayoutParams(0,dp(48),1f).apply { marginEnd=dp(5) })
        shell.addView(row,LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(10) })

        shell.addView(btn("آماده‌ام شروع کن",true) {
            dialog.dismiss()
            partyReadyConfirmed = true
            if (!partyPlaybackStarted) {
                partyPlaybackStarted = true
                requestedResumePosition = 0L
                // Guests prepare the decoder but wait for the host state. Hosts start
                // immediately and publish an explicit PLAY as soon as VLC confirms it.
                pauseAfterLifecycleRestore = !partyIsHost
                launchPlayerSafely(videoUrl)
                handler.postDelayed({
                    showControls()
                    showPartyChrome()
                    enterImmersive()
                    pollWatchParty()
                }, 220L)
            } else {
                showControls()
                showPartyChrome()
            }
        }, LinearLayout.LayoutParams(-1,dp(56)).apply { topMargin=dp(10) })

        dialog = AlertDialog.Builder(this).setView(shell).setCancelable(true).create()
        partyLobbyDialog = dialog
        dialog.setOnDismissListener { if (partyLobbyDialog === dialog) partyLobbyDialog = null }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if(isTvLike())dp(620) else (resources.displayMetrics.widthPixels*0.92f).toInt(), -2)
    }

    private fun updateChatBadge() {
        val button = partyChatButton as? FrameLayout ?: return
        val old = button.findViewWithTag<View>("party_unread")
        if (partyUnreadChat <= 0) { old?.let { button.removeView(it) }; return }
        val badge = (old as? TextView) ?: TextView(this).apply {
            tag = "party_unread"; setTextColor(Color.WHITE); textSize = 8f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; background = rounded(Color.rgb(239,68,68), 999, Color.WHITE)
            button.addView(this, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.RIGHT).apply { topMargin = -dp(3); rightMargin = -dp(3) })
        }
        badge.text = partyUnreadChat.coerceAtMost(99).toString()
    }

    private fun pollWatchParty() {
        if (!partyActive || partyRoomCode.isBlank() || partyPollInFlight) return
        partyPollInFlight = true
        val requestStart = System.currentTimeMillis()
        AccountApi.watchPartyPoll(this, partyRoomCode, partyLastEventId, partyLastMessageId, 0L) { result ->
            val requestEnd = System.currentTimeMillis()
            partyPollInFlight = false
            partyLastPollAt = requestEnd
            if (!result.success || result.json == null) {
                if (result.statusCode == 404 || result.json?.optString("error") == "room_expired") {
                    partyActive = false
                    handler.removeCallbacks(partyPollRunnable)
                    Toast.makeText(this, result.message.ifBlank { "اتاق Watch Party پایان یافت" }, Toast.LENGTH_LONG).show()
                }
                updatePartyStatusChip()
                return@watchPartyPoll
            }
            val json = result.json
            json.optLong("server_time_ms", 0L).takeIf { it > 0L }?.let { server ->
                val midpoint = requestStart + (requestEnd - requestStart) / 2L
                val candidate = server - midpoint
                partyServerOffsetMs = if (partyServerOffsetMs == 0L) candidate else ((partyServerOffsetMs * 3L + candidate) / 4L)
            }
            partyRole = json.optString("member_role", partyRole)
            partyIsHost = partyRole.equals("host", true)
            updateGuestPlaybackLockUi()
            partyChatEnabled = json.optBoolean("chat_enabled", true)

            var sharedSource = ""
            json.optJSONObject("room")?.let { room ->
                partyThemeKey = room.optString("background_key", partyThemeKey)
                partyRoomTitle = room.optString("content_title", partyRoomTitle)
                partyRoomPoster = room.optString("poster_url", partyRoomPoster)
                applyPartyTheme(partyThemeKey)
                sharedSource = room.optString("shared_source_url").trim()
                if (partyReadyConfirmed && !partyIsHost && sharedSource.isNotBlank() && sharedSource != videoUrl && partyPlaybackStarted) {
                    partyApplyingRemote = true
                    videoUrl = sharedSource
                    requestedResumePosition = 0L
                    handler.postDelayed({
                        launchPlayerSafely(sharedSource)
                        handler.postDelayed({ partyApplyingRemote = false }, 180L)
                    }, 60L)
                }
            }

            val events = json.optJSONArray("events") ?: JSONArray()
            for (i in 0 until events.length()) partyLastEventId = max(partyLastEventId, events.optJSONObject(i)?.optLong("id", 0L) ?: 0L)
            val messages = json.optJSONArray("messages") ?: JSONArray()
            handlePartyMessages(messages)
            partyMembers = json.optJSONArray("members") ?: partyMembers
            if (!partyIsHost) {
                val state = json.optJSONObject("state")
                val serverNow = json.optLong("server_time_ms", requestEnd + partyServerOffsetMs)
                if (partyReadyConfirmed && state != null && !state.optBoolean("paused", true) && sharedSource.isNotBlank() && (!partyPlaybackStarted || player == null)) {
                    // Android-to-Android: when the host starts, a guest that is still in
                    // the room lobby must create its local VLC player automatically.
                    // Previously only the timeline state moved while player==null.
                    partyPlaybackStarted = true
                    partyGuestAutoStarting = true
                    partyApplyingRemote = true
                    partyLobbyDialog?.dismiss()
                    videoUrl = sharedSource
                    val targetMs = (state.optDouble("current_time", 0.0).coerceAtLeast(0.0) * 1000.0).toLong()
                    requestedResumePosition = targetMs
                    pauseAfterLifecycleRestore = false
                    launchPlayerSafely(sharedSource)
                    handler.postDelayed({
                        partyApplyingRemote = false
                        partyGuestAutoStarting = false
                        applyWatchPartyState(state, serverNow)
                        showPartyChrome()
                    }, 320L)
                } else {
                    state?.let { applyWatchPartyState(it, serverNow) }
                }
            }
            updatePartyStatusChip()
        }
    }

    private fun applyWatchPartyState(state: JSONObject, serverTimeMs: Long) {
        val seq = state.optLong("sequence_no", -1L)
        if (seq < partyLastSequence) return
        partyLastSequence = seq
        val paused = state.optBoolean("paused", true)
        val rate = state.optDouble("playback_rate", 1.0).toFloat().coerceIn(0.5f, 2f)
        var target = state.optDouble("current_time", 0.0).coerceAtLeast(0.0)
        val updatedAt = state.optLong("updated_at_ms", 0L)
        if (!paused && updatedAt > 0L) {
            val effectiveServerNow = if (serverTimeMs > 0L) serverTimeMs else System.currentTimeMillis() + partyServerOffsetMs
            target += ((effectiveServerNow - updatedAt).coerceAtLeast(0L) / 1000.0) * rate
        }
        val p = player ?: return
        val local = p.time.coerceAtLeast(0L) / 1000.0
        val drift = target - local
        partyApplyingRemote = true
        try {
            if (paused && p.isPlaying) p.pause()
            if (!paused && !p.isPlaying) p.play()
            when {
                kotlin.math.abs(drift) > 0.55 -> {
                    p.time = (target * 1000.0).toLong().coerceAtLeast(0L)
                    p.setRate(rate)
                }
                !paused && kotlin.math.abs(drift) > 0.12 -> {
                    val correction = if (drift > 0) 0.055f else -0.055f
                    p.setRate((rate + correction).coerceIn(0.90f, 1.10f))
                }
                else -> p.setRate(rate)
            }
            currentSpeed = rate
            playIcon.setImageResource(if (paused) R.drawable.ic_player_play else R.drawable.ic_player_pause)
        } catch (_: Throwable) {
        } finally {
            handler.postDelayed({ partyApplyingRemote = false }, 90L)
        }
    }

    private fun currentPartyPositionSeconds(): Double {
        return (player?.time ?: 0L).coerceAtLeast(0L) / 1000.0
    }

    private fun currentPartyPaused(): Boolean {
        return player?.isPlaying != true
    }

    private fun sendWatchPartyControl(event: String, retryAttempt: Int = 0) {
        if (!partyActive || !partyIsHost || partyApplyingRemote || partyRoomCode.isBlank()) return
        partyLastHostActionAt = System.currentTimeMillis()
        AccountApi.watchPartyControl(
            this, partyRoomCode, event, currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed,
            buffering = false, sourceUrl = if (event == "source_change") videoUrl else ""
        ) { result ->
            if (result.success) {
                result.json?.optJSONObject("state")?.optLong("sequence_no", -1L)?.let { if (it >= 0) partyLastSequence = max(partyLastSequence, it) }
            } else if (event != "state" && retryAttempt < 1 && partyActive && partyIsHost) {
                // User actions are important for Android-to-Android rooms. One short
                // retry prevents a dropped PLAY/PAUSE/SEEK request from leaving the
                // other phone with only a moving timestamp and no playback.
                handler.postDelayed({ sendWatchPartyControl(event, retryAttempt + 1) }, 260L)
            }
        }
    }

    private fun sendWatchPartyHeartbeatIfNeeded() {
        val now = System.currentTimeMillis()
        if (!partyActive || !partyIsHost || partyApplyingRemote || now - partyLastHeartbeatAt < 900L || now - partyLastHostActionAt < 650L) return
        partyLastHeartbeatAt = now
        AccountApi.watchPartyControl(this, partyRoomCode, "state", currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed) {}
    }

    private fun handlePartyMessages(messages: JSONArray) {
        for (i in 0 until messages.length()) {
            val message = messages.optJSONObject(i) ?: continue
            val id = message.optLong("id", 0L)
            if (id <= 0L) continue
            partyLastMessageId = max(partyLastMessageId, id)
            if (!partyMessageIdsShown.add(id)) continue
            appendPartyMessage(message)
            showPartyMessageOverlay(message)
            val media = message.optJSONObject("media")
            if (media != null && media.optString("url").isNotBlank()) showPartyReaction(media)
            if (partyChatDialog?.isShowing != true) partyUnreadChat++
        }
        while (partyMessageIdsShown.size > 220) partyMessageIdsShown.remove(partyMessageIdsShown.first())
        updateChatBadge()
    }

    private fun showPartyMessageOverlay(message: JSONObject) {
        if (!partyActive || message.optBoolean("is_mine", false)) return
        val username = message.optString("username").ifBlank { "همراه" }
        val textValue = message.optString("text").ifBlank { message.optString("message") }
        val media = message.optJSONObject("media")
        if (textValue.isBlank() && (media == null || media.optString("url").isBlank())) return

        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(9), dp(10), dp(9))
            background = playerGlassSurface(20, 236, 82)
            elevation = dp(8).toFloat()
            alpha = 0f
            translationY = -dp(10).toFloat()
        }
        bubble.addView(partyAvatarView(message, 36), LinearLayout.LayoutParams(dp(36), dp(36)).apply { marginStart = dp(9) })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = username
            setTextColor(if (message.optBoolean("is_vip", false) || message.optBoolean("is_admin", false)) Color.rgb(255, 203, 76) else Color.WHITE)
            textSize = 10.7f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, -2, 1f))
        if (message.optBoolean("is_vip", false) || message.optBoolean("is_admin", false)) {
            header.addView(TextView(this).apply {
                text = if (message.optBoolean("is_admin", false)) "ADMIN" else "VIP"
                setTextColor(Color.rgb(255, 206, 78))
                textSize = 8.4f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(40, 255, 193, 52), dp(999), Color.argb(105, 255, 207, 90))
                setPadding(dp(6), dp(2), dp(6), dp(2))
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(6) })
        }
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(3) })

        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            content.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.rgb(242, 244, 248))
                textSize = 12.2f
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                setLineSpacing(dp(1).toFloat(), 1f)
            })
        } else if (media != null) {
            content.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                media.optString("url").takeIf { it.isNotBlank() }?.let { loadPartyImage(it, this) }
            }, LinearLayout.LayoutParams(dp(92), dp(58)))
        }
        bubble.addView(content, LinearLayout.LayoutParams(0, -2, 1f))

        val width = if (isTvLike()) dp(460) else min(dp(340), resources.displayMetrics.widthPixels - dp(28))
        root.addView(bubble, FrameLayout.LayoutParams(width, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(if (isTvLike()) 90 else 58)
        })
        bubble.animate().alpha(1f).translationY(0f).setDuration(170L).withEndAction {
            bubble.postDelayed({
                bubble.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(220L).withEndAction {
                    runCatching { root.removeView(bubble) }
                }.start()
            }, 3300L)
        }.start()
    }

    private fun partyAvatarView(payload: JSONObject, sizeDp: Int = 38): FrameLayout {
        val username = payload.optString("username").ifBlank { "همراه" }
        val vip = payload.optBoolean("is_vip", false)
        val admin = payload.optBoolean("is_admin", false)
        val avatarUrl = payload.optString("avatar_url").trim()
        val border = if (vip || admin) Color.rgb(255, 196, 60) else Color.argb(95,255,255,255)
        return FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(27, 43, 53))
                setStroke(dp(1), border)
            }
            clipToOutline = true
            addView(TextView(this@PlayerActivity).apply {
                text = username.take(1).uppercase()
                setTextColor(Color.WHITE)
                textSize = if (sizeDp >= 42) 12f else 10.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(34,122,118), Color.rgb(46,75,143))).apply {
                    shape = GradientDrawable.OVAL
                }
            }, FrameLayout.LayoutParams(-1,-1))
            if (avatarUrl.isNotBlank()) {
                addView(ImageView(this@PlayerActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
                    clipToOutline = true
                    loadPartyImage(avatarUrl, this)
                }, FrameLayout.LayoutParams(-1,-1).apply { setMargins(dp(2),dp(2),dp(2),dp(2)) })
            }
            addView(View(this@PlayerActivity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.rgb(42, 214, 132))
                    setStroke(dp(1), Color.rgb(5,42,35))
                }
            }, FrameLayout.LayoutParams(dp(9),dp(9),Gravity.BOTTOM or Gravity.RIGHT).apply {
                rightMargin = dp(1); bottomMargin = dp(1)
            })
        }
    }

    private fun partyMessageTime(raw: String): String {
        val clean = raw.trim()
        val match = Regex("(?:T|\\s)(\\d{2}):(\\d{2})").find(clean)
        return if (match != null) "${match.groupValues[1]}:${match.groupValues[2]}" else ""
    }

    private fun showWatchPartyChat() {
        if (!partyChatEnabled) {
            Toast.makeText(this, "گفت‌وگوی اتاق غیرفعال است", Toast.LENGTH_SHORT).show()
            return
        }
        partyUnreadChat = 0
        updateChatBadge()
        handler.removeCallbacks(partyChromeHideRunnable)
        lateinit var dialog: AlertDialog

        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0,0,0,0)
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(7,61,50), Color.rgb(4,34,31))).apply {
                cornerRadius = dp(27).toFloat()
                setStroke(dp(1), Color.argb(145,60,151,132))
            }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(11),dp(12),dp(11))
            background = GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, intArrayOf(Color.rgb(13,96,86), Color.rgb(9,72,65))).apply {
                setCornerRadii(floatArrayOf(dp(27).toFloat(),dp(27).toFloat(),dp(27).toFloat(),dp(27).toFloat(),0f,0f,0f,0f))
            }
        }
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "گفت‌وگوی خصوصی"
                setTextColor(Color.WHITE)
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "پیام‌ها با پایان اتاق پاک می‌شوند"
                setTextColor(Color.argb(190,225,245,240))
                textSize = 9.8f
                gravity = Gravity.RIGHT
            })
        }, LinearLayout.LayoutParams(0,-2,1f))
        head.addView(TextView(this).apply {
            text = "×"
            setTextColor(Color.WHITE)
            textSize = 23f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(55,255,255,255),999,Color.argb(80,255,255,255))
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(dp(44),dp(44)).apply { marginStart=dp(8) })
        shell.addView(head, LinearLayout.LayoutParams(-1,-2))

        partyChatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12),dp(12),dp(12),dp(12))
            minimumHeight = dp(if (isTvLike()) 330 else 260)
            background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(Color.rgb(6,50,42),Color.rgb(5,39,34),Color.rgb(7,57,45)))
        }
        partyChatScroll = ScrollView(this).apply {
            addView(partyChatList)
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        shell.addView(partyChatScroll, LinearLayout.LayoutParams(-1,0,1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10),dp(9),dp(10),dp(10))
            setBackgroundColor(Color.rgb(5,27,28))
        }
        val send = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(42,141,255),Color.rgb(36,104,231))).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(150,165,207,255))
            }
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this,999,1.06f,0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_send_round)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23),dp(23),Gravity.CENTER))
        }

        val inputShell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Color.rgb(4,20,25),999,Color.rgb(40,111,186))
            setPadding(dp(8),dp(3),dp(8),dp(3))
        }
        val input = EditText(this).apply {
            hint = "پیام بنویسید..."
            setHintTextColor(Color.rgb(139,150,154))
            setTextColor(Color.WHITE)
            textSize = 12.8f
            maxLines = 3
            minLines = 1
            background = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(7),0,dp(7),0)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        val sticker = FrameLayout(this).apply {
            background = rounded(Color.rgb(8,38,42),dp(15),Color.rgb(52,124,190))
            isClickable = true
            isFocusable = true
            contentDescription = "استیکر و ایموجی"
            applyPlayerFocus(this,999,1.08f,0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_sticker_smile_square)
                setColorFilter(Color.rgb(225,232,236))
            }, FrameLayout.LayoutParams(dp(24),dp(24),Gravity.CENTER))
            setOnClickListener { showPartyStickerPicker() }
        }
        inputShell.addView(input, LinearLayout.LayoutParams(0,dp(48),1f))
        // Input, sticker and send are independent boxes. In RTL, marginStart
        // on the second/third child is the physical gap to its right-hand peer.
        composer.addView(inputShell, LinearLayout.LayoutParams(0,dp(52),1f))
        composer.addView(sticker, LinearLayout.LayoutParams(dp(48),dp(48)).apply { marginStart=dp(12) })
        composer.addView(send, LinearLayout.LayoutParams(dp(52),dp(52)).apply { marginStart=dp(10) })
        send.setOnClickListener {
            val value = input.text?.toString()?.trim().orEmpty()
            if (value.isNotBlank()) {
                sendPartyMessage(value)
                input.setText("")
            }
        }
        shell.addView(composer)

        dialog = AlertDialog.Builder(this).setView(shell).create()
        partyChatDialog = dialog
        dialog.setOnDismissListener {
            partyChatDialog = null
            partyChatList = null
            partyChatScroll = null
            showPartyChrome()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        val dialogWidth = if (isTvLike()) (w * .40f).toInt() else (w * .46f).toInt()
        val dialogHeight = if (isTvLike()) (h * .84f).toInt() else (h * .90f).toInt()
        dialog.window?.setLayout(dialogWidth, dialogHeight)
        dialog.window?.attributes = dialog.window?.attributes?.apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        partyMessageIdsShown.clear()
        partyLastMessageId = 0L
        pollWatchParty()
    }

    private fun appendPartyMessage(message: JSONObject) {
        val list = partyChatList ?: return
        val mine = message.optBoolean("is_mine", false)
        val username = message.optString("username").ifBlank { "همراه" }
        val vip = message.optBoolean("is_vip", false)
        val admin = message.optBoolean("is_admin", false)
        val maxBubbleWidth = (resources.displayMetrics.widthPixels * if (isTvLike()) 0.28f else 0.34f).toInt().coerceAtLeast(dp(190))

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.RIGHT or Gravity.BOTTOM else Gravity.LEFT or Gravity.BOTTOM
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        val avatar = partyAvatarView(message, 38)
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11),dp(8),dp(11),dp(7))
            background = if (mine) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(20,95,151),Color.rgb(10,68,115))).apply {
                    setCornerRadii(floatArrayOf(dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(5).toFloat(),dp(5).toFloat(),dp(17).toFloat(),dp(17).toFloat()))
                    setStroke(dp(1),Color.argb(95,92,176,255))
                }
            } else {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(16,54,50),Color.rgb(9,40,37))).apply {
                    setCornerRadii(floatArrayOf(dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(17).toFloat(),dp(5).toFloat(),dp(5).toFloat()))
                    setStroke(dp(1),Color.argb(80,135,190,176))
                }
            }
        }
        bubble.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = if (mine) "شما" else username
                setTextColor(if (vip || admin) Color.rgb(255,199,64) else Color.rgb(129,188,255))
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxWidth = maxBubbleWidth - dp(70)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            if (admin || vip) {
                addView(TextView(this@PlayerActivity).apply {
                    text = if (admin) "ADMIN" else "VIP"
                    setTextColor(if (admin) Color.rgb(255,204,72) else Color.rgb(65,42,8))
                    textSize = 7.2f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    background = if (admin) rounded(Color.argb(55,255,190,30),999,Color.argb(120,255,196,60)) else GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.rgb(255,232,126),Color.rgb(255,177,31))).apply { cornerRadius=dp(999).toFloat() }
                    setPadding(dp(5),dp(1),dp(5),dp(1))
                }, LinearLayout.LayoutParams(-2,dp(16)).apply { marginEnd = dp(6) })
            }
        })

        val textValue = message.optString("text").ifBlank { message.optString("message") }
        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            bubble.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.WHITE)
                textSize = 12.8f
                gravity = Gravity.RIGHT
                setLineSpacing(dp(2).toFloat(),1f)
                maxWidth = maxBubbleWidth
                setTextIsSelectable(false)
            }, LinearLayout.LayoutParams(-2,-2).apply { topMargin=dp(4) })
        }
        message.optJSONObject("media")?.optString("url")?.takeIf { it.isNotBlank() }?.let { url ->
            val mediaSize = dp(if (isTvLike()) 210 else 170)
            bubble.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                adjustViewBounds = true
                setBackgroundColor(Color.TRANSPARENT)
                loadPartyImage(url,this)
            }, LinearLayout.LayoutParams(mediaSize,mediaSize).apply { gravity=Gravity.RIGHT;topMargin=dp(7) })
        }
        val time = partyMessageTime(message.optString("created_at"))
        if (time.isNotBlank()) {
            bubble.addView(TextView(this).apply {
                text = if (mine && message.optString("delivered_at").isNotBlank()) "$time  ✓✓" else time
                setTextColor(Color.argb(165,226,236,238))
                textSize = 8.2f
                gravity = Gravity.LEFT
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(4) })
        }

        if (mine) {
            wrap.addView(bubble,LinearLayout.LayoutParams(-2,-2).apply { marginEnd=dp(7) })
            wrap.addView(avatar,LinearLayout.LayoutParams(dp(38),dp(38)))
        } else {
            wrap.addView(avatar,LinearLayout.LayoutParams(dp(38),dp(38)))
            wrap.addView(bubble,LinearLayout.LayoutParams(-2,-2).apply { marginStart=dp(7) })
        }
        list.addView(wrap,LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(10) })
        partyChatScroll?.post { partyChatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendPartyMessage(message: String) {
        if (!partyActive || partyRoomCode.isBlank()) return
        val clientId = "android_${UUID.randomUUID().toString().replace("-","").take(40)}"
        AccountApi.watchPartyMessage(this, partyRoomCode, message, clientId) { result ->
            if (!result.success) Toast.makeText(this, result.message.ifBlank { "پیام ارسال نشد" }, Toast.LENGTH_SHORT).show()
            else handler.postDelayed({ pollWatchParty() }, 120L)
        }
    }

    private fun showPartyStickerPicker() {
        AccountApi.commentMediaCatalog(this) { result ->
            val packs=result.json?.optJSONArray("packs") ?: JSONArray()
            if (!result.success || packs.length()==0) {
                Toast.makeText(this,result.message.ifBlank { "استیکرها دریافت نشد" },Toast.LENGTH_SHORT).show()
                return@commentMediaCatalog
            }
            lateinit var dialog: AlertDialog
            val landscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
            val shell=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
                setPadding(dp(10),dp(10),dp(10),dp(10)); background=partyGlass(26,246,86)
            }
            val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;gravity=Gravity.CENTER_VERTICAL }
            header.addView(LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL;gravity=Gravity.RIGHT
                addView(TextView(this@PlayerActivity).apply { text="استیکر و GIF";setTextColor(Color.WHITE);textSize=17f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT })
                addView(TextView(this@PlayerActivity).apply { text="همان بسته‌های گفت‌وگو و کامنت بانک‌مووی";setTextColor(muted);textSize=9.8f;gravity=Gravity.RIGHT })
            },LinearLayout.LayoutParams(0,-2,1f))
            header.addView(TextView(this).apply { text="×";setTextColor(Color.WHITE);textSize=22f;gravity=Gravity.CENTER;background=partyGlass(999,214,60);setOnClickListener{dialog.dismiss()} },LinearLayout.LayoutParams(dp(42),dp(42)).apply{marginStart=dp(6)})
            shell.addView(header,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})

            val tabScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER;layoutDirection=View.LAYOUT_DIRECTION_RTL }
            val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(2),dp(3),dp(2),dp(6)) }
            tabScroll.addView(tabs)
            shell.addView(tabScroll,LinearLayout.LayoutParams(-1,dp(48)))

            val contentScroll=ScrollView(this).apply { isFillViewport=true }
            val grid=GridLayout(this).apply { columnCount=if(isTvLike())5 else if(landscape)4 else 3;alignmentMode=GridLayout.ALIGN_BOUNDS;useDefaultMargins=false }
            contentScroll.addView(grid)
            shell.addView(contentScroll,LinearLayout.LayoutParams(-1,0,1f))

            fun renderPack(pack:JSONObject) {
                grid.removeAllViews()
                val slug=pack.optString("slug").ifBlank { pack.optString("key") }
                val items=pack.optJSONArray("items") ?: JSONArray()
                for(j in 0 until items.length()) {
                    val it=items.optJSONObject(j)?:continue
                    val id=it.optString("id");val url=it.optString("url")
                    if(slug.isBlank()||id.isBlank()||url.isBlank())continue
                    val card=FrameLayout(this).apply {
                        background=partyGlass(16,208,54);isClickable=true;isFocusable=true;applyPlayerFocus(this,16,1.06f,0f)
                        addView(ImageView(this@PlayerActivity).apply { scaleType=ImageView.ScaleType.FIT_CENTER;adjustViewBounds=true;loadPartyImage(url,this) },FrameLayout.LayoutParams(-1,-1).apply{setMargins(dp(5),dp(5),dp(5),dp(5))})
                        setOnClickListener{sendPartyMessage("[bm-sticker:$slug:$id]");dialog.dismiss()}
                    }
                    val spec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    grid.addView(card,GridLayout.LayoutParams(spec,spec).apply { width=dp(if(isTvLike())112 else if(landscape)96 else 102);height=dp(if(isTvLike())94 else if(landscape)78 else 90);setMargins(dp(4),dp(4),dp(4),dp(4)) })
                }
                contentScroll.post{contentScroll.scrollTo(0,0)}
            }

            val tabViews=mutableListOf<TextView>()
            for(i in 0 until packs.length()) {
                val pack=packs.optJSONObject(i)?:continue
                val label=pack.optString("label").ifBlank{pack.optString("name").ifBlank{"بسته ${i+1}"}}
                val tab=TextView(this).apply {
                    text=label;setTextColor(Color.WHITE);textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
                    setPadding(dp(12),0,dp(12),0);isClickable=true;isFocusable=true
                    background=if(i==0)partyAccent(999)else partyGlass(999,210,52)
                    setOnClickListener{
                        tabViews.forEach{v->v.background=partyGlass(999,210,52)};background=partyAccent(999);renderPack(pack)
                    }
                }
                tabViews.add(tab);tabs.addView(tab,LinearLayout.LayoutParams(-2,dp(38)).apply{marginStart=dp(4);marginEnd=dp(4)})
            }
            if(packs.length()>0)packs.optJSONObject(0)?.let(::renderPack)
            dialog=AlertDialog.Builder(this).setView(shell).create();dialog.show();dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val w=if(isTvLike())dp(690) else (resources.displayMetrics.widthPixels*(if(landscape)0.78f else 0.95f)).toInt()
            val h=(resources.displayMetrics.heightPixels*(if(landscape)0.82f else 0.68f)).toInt()
            dialog.window?.setLayout(w,h)
        }
    }

    private fun partyAbsoluteUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isBlank()) return ""
        if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) return clean
        return AppConfig.BASE_DOMAIN.trimEnd('/') + "/" + clean.trimStart('/')
    }

    private fun loadPartyImage(url: String, target: ImageView) {
        val resolved = partyAbsoluteUrl(url)
        if (resolved.isBlank()) return
        Thread {
            try {
                val conn=(URL(resolved).openConnection() as HttpURLConnection).apply { connectTimeout=8000; readTimeout=10000; useCaches=true; setRequestProperty("User-Agent","BankmovieAndroidNative/2.3-WatchParty") }
                val bytes=conn.inputStream.use { input -> input.readBytes().let { if(it.size>5_000_000) ByteArray(0) else it } }
                conn.disconnect(); if(bytes.isEmpty()) return@Thread
                if(Build.VERSION.SDK_INT>=28) {
                    val drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(bytes)))
                    runOnUiThread { if(!isFinishing){ target.setImageDrawable(drawable); if(drawable is AnimatedImageDrawable) drawable.start() } }
                } else {
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                    runOnUiThread { if(!isFinishing) target.setImageBitmap(bitmap) }
                }
            } catch (_:Throwable) {}
        }.start()
    }

    private fun showPartyReaction(media: JSONObject) {
        val url=media.optString("url"); if(url.isBlank()||!partyActive) return
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; alpha=0f; scaleX=0.75f; scaleY=0.75f; background=partyGlass(24,170,42); loadPartyImage(url,this) }
        root.addView(image,FrameLayout.LayoutParams(dp(150),dp(150),Gravity.CENTER).apply { leftMargin=dp(220) })
        image.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).withEndAction {
            image.postDelayed({ image.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(240L).withEndAction { runCatching { root.removeView(image) } }.start() },2200L)
        }.start()
    }

    private fun showPartyMembers() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            background = partyGlass(24,246,82)
        }
        shell.addView(TextView(this).apply {
            text = "اعضای اتاق  ${partyMembers.length()}/2"
            setTextColor(Color.WHITE)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        for (i in 0 until partyMembers.length()) {
            val m = partyMembers.optJSONObject(i) ?: continue
            shell.addView(LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(dp(10),dp(8),dp(10),dp(8))
                background = partyGlass(16,206,44)
                addView(partyAvatarView(m,44), LinearLayout.LayoutParams(dp(44),dp(44)).apply { marginStart=dp(10) })
                addView(LinearLayout(this@PlayerActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.RIGHT
                    addView(TextView(this@PlayerActivity).apply {
                        text = m.optString("username").ifBlank { "همراه" }
                        setTextColor(Color.WHITE)
                        textSize = 13f
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.RIGHT
                    })
                    addView(TextView(this@PlayerActivity).apply {
                        text = if (m.optString("member_role") == "host") "میزبان · کنترل پخش" else "همراه · آنلاین"
                        setTextColor(muted)
                        textSize = 9.5f
                        gravity = Gravity.RIGHT
                    })
                }, LinearLayout.LayoutParams(0,-2,1f))
                addView(TextView(this@PlayerActivity).apply {
                    text = "●"
                    setTextColor(Color.rgb(46,213,132))
                    textSize = 11f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(24),-2))
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(8) })
        }
        shell.addView(TextView(this).apply {
            text = "کپی لینک دعوت"
            setTextColor(Color.WHITE)
            textSize = 12.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyAccent(18)
            setOnClickListener {
                copyPartyInvite()
                Toast.makeText(this@PlayerActivity,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(12) })
        shell.addView(TextView(this).apply {
            text = "بستن"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = partyGlass(16,210,55)
            setOnClickListener { dialog.dismiss() }
        }, LinearLayout.LayoutParams(-1,dp(42)).apply { topMargin=dp(8) })
        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if(isTvLike())dp(520) else (resources.displayMetrics.widthPixels*0.82f).toInt(),-2)
    }

    private fun copyPartyInvite() {
        val url=partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val cb=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("BankMovie Watch Party",url))
    }

    private fun showPartyRoomSheet() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            background = partyGlass(26,246,82)
        }
        shell.addView(TextView(this).apply {
            text = "تنظیمات اتاق"
            setTextColor(Color.WHITE)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        shell.addView(TextView(this).apply {
            text = "سینمای خصوصی BankMovie  •  $partyRoomCode"
            setTextColor(muted)
            textSize = 10.5f
            gravity = Gravity.RIGHT
            setPadding(0,dp(5),0,dp(10))
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0,0,dp(2),dp(3))
        }
        fun row(label:String, sub:String, click:()->Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(dp(13),dp(10),dp(13),dp(10))
            background = partyGlass(17,212,52)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this,17,1.035f,0f)
            setOnClickListener { click() }
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 9.6f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(2) })
        }
        body.addView(row("اعضای اتاق","${partyMembers.length()}/2 نفر در اتاق") { dialog.dismiss(); showPartyMembers() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("تم و پس‌زمینه", if (partyIsHost) "انتخاب تم اتاق" else "فقط میزبان می‌تواند تغییر دهد") { dialog.dismiss(); showPartyThemes() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("کپی لینک دعوت","ارسال لینک واقعی همین اتاق") { copyPartyInvite(); Toast.makeText(this,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("گفت‌وگوی خصوصی","باز کردن چت اتاق") { dialog.dismiss(); showWatchPartyChat() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("وضعیت همگام‌سازی", if (partyIsHost) "میزبان · کنترل پخش و تغییر منبع" else "همراه · دریافت زمان و منبع از میزبان") { showPartyChrome() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(TextView(this).apply {
            text = if (partyIsHost) "بستن اتاق و خروج" else "خروج از اتاق"
            setTextColor(Color.rgb(255,138,154))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyGlass(17,214,58)
            setOnClickListener { dialog.dismiss(); leaveWatchPartyAndFinish() }
        }, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(3) })
        scroll.addView(body)
        shell.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val width = if (isTvLike()) dp(560) else (resources.displayMetrics.widthPixels*.86f).toInt()
        val maxHeight = (resources.displayMetrics.heightPixels * if (isTvLike()) .82f else .78f).toInt()
        dialog.window?.setLayout(width, maxHeight)
    }

    private fun showPartyThemes() {
        val themes=listOf(
            "simple" to "ساده", "purple_dream" to "رویای بنفش", "teal_mist" to "مه آبی", "golden" to "طلایی",
            "forest" to "جنگل", "pink_cloud" to "رویای پونی", "interstellar" to "میان ستاره‌ای", "pony" to "پونی", "pizza" to "پیتزا",
            "darkness" to "تاریکی", "romantic_hearts" to "عاشقانه", "galaxy_nova" to "کهکشانی", "starlight" to "ستاره‌ای", "aurora" to "شفق قطبی"
        )
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="تم و پس‌زمینه اتاق"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT; setPadding(0,0,0,dp(8)) })
        val scroll=ScrollView(this); val grid=GridLayout(this).apply { columnCount=3; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
        themes.forEach { (key,label) ->
            val color=partyThemeColor(key)
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(5),dp(5),dp(5)); background=if(key==partyThemeKey) rounded(Color.argb(72,Color.red(blue),Color.green(blue),Color.blue(blue)),16,blue2) else partyGlass(16,205,45); isClickable=partyIsHost; isFocusable=partyIsHost; applyPlayerFocus(this,16,1.05f,0f)
                addView(View(this@PlayerActivity).apply { background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(color,Color.rgb(20,21,26))).apply { cornerRadius=dp(12).toFloat() } },LinearLayout.LayoutParams(-1,dp(55)))
                addView(TextView(this@PlayerActivity).apply { text=label; setTextColor(Color.WHITE); textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,dp(28)))
                setOnClickListener { if(partyIsHost) AccountApi.watchPartyRoomSettings(this@PlayerActivity,partyRoomCode,key){r->if(r.success){partyThemeKey=key;applyPartyTheme(key);dialog.dismiss()}else Toast.makeText(this@PlayerActivity,r.message,Toast.LENGTH_SHORT).show()} }
            }
            grid.addView(card,GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f)).apply { width=dp(if(isTvLike())160 else 105); height=dp(96); setMargins(dp(4),dp(4),dp(4),dp(4)) })
        }
        scroll.addView(grid); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(!partyIsHost) shell.addView(TextView(this).apply { text="انتخاب تم فقط در اختیار میزبان VIP است"; setTextColor(muted); textSize=10f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(6) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(590) else (resources.displayMetrics.widthPixels*0.9f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
    }

    private fun partyThemeColor(key:String):Int=when(key){
        "purple_dream"->Color.rgb(126,53,210); "teal_mist"->Color.rgb(20,150,153); "golden"->Color.rgb(204,146,24); "forest"->Color.rgb(22,116,67);
        "pink_cloud"->Color.rgb(182,72,130); "interstellar"->Color.rgb(60,43,127); "pony"->Color.rgb(178,92,136); "pizza"->Color.rgb(142,74,35); "darkness"->Color.rgb(24,27,34);
        "romantic_hearts"->Color.rgb(171,46,93); "galaxy_nova"->Color.rgb(91,34,130); "starlight"->Color.rgb(38,68,137); "aurora"->Color.rgb(19,135,111);
        else->Color.rgb(45,49,58)
    }

    private fun applyPartyTheme(key:String) {
        val c=partyThemeColor(key)
        partyDock?.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(Color.argb(205,Color.red(c),Color.green(c),Color.blue(c)),Color.argb(232,18,19,24))).apply { cornerRadius=dp(24).toFloat(); setStroke(dp(1),Color.argb(100,255,255,255)) }
        partyStatusChip?.background=GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,intArrayOf(Color.argb(220,18,19,24),Color.argb(165,Color.red(c),Color.green(c),Color.blue(c)))).apply { cornerRadius=dp(999).toFloat(); setStroke(dp(1),Color.argb(90,255,255,255)) }
        partyChatDialog?.window?.decorView?.background = ColorDrawable(Color.TRANSPARENT)
        val chatBase = if (key == "simple") Color.rgb(6,50,42) else UiPreferences.blend(Color.rgb(5,34,31), c, 0.32f)
        partyChatList?.background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(chatBase, UiPreferences.blend(chatBase, Color.BLACK, 0.22f)))
    }

    private fun leaveWatchPartyAndFinish() {
        if (!partyActive) { finish(); return }
        partyActive=false; handler.removeCallbacks(partyPollRunnable)
        AccountApi.watchPartyLeave(this,partyRoomCode,partyIsHost) { finish() }
        handler.postDelayed({ if(!isFinishing) finish() },700L)
    }

    // PASS 4.3 — WebRTC/voice call removed to keep APK compact and stable.

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER).apply { rightMargin = dp(8) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.045f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(28), dp(28)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 11.2f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    private fun schedulePlaybackRetry(url: String, reason: String = "خطا در پخش") {
        if (playbackRetryScheduled || isFinishing || isDestroyed) return
        val clean = url.trim()
        if (clean.isBlank()) return
        if (playbackRetryCount >= maxPlaybackRetries) {
            playbackRetryScheduled = false
            Toast.makeText(this, "این لینک بعد از $maxPlaybackRetries تلاش پخش نشد؛ کیفیت یا نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            releasePlayerAsyncForRebuild()
            return
        }
        playbackRetryCount += 1
        if (playbackRetryCount == 1) hardwareDecoder = false
        val keep = runCatching { player?.time?.coerceAtLeast(0L) ?: 0L }.getOrDefault(0L)
        if (keep > 0L) requestedResumePosition = max(requestedResumePosition, keep)
        playbackRetryScheduled = true
        Toast.makeText(this, "$reason؛ تلاش مجدد ${playbackRetryCount}/$maxPlaybackRetries", Toast.LENGTH_SHORT).show()
        val delayMs = (650L + playbackRetryCount * 250L).coerceAtMost(1700L)
        handler.postDelayed({
            playbackRetryScheduled = false
            if (!isFinishing && !isDestroyed) launchPlayerSafely(clean)
        }, delayMs)
    }

    private fun launchPlayerSafely(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) {
            Toast.makeText(this, "لینک پخش خالی است", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startPlayer(clean)
        } catch (_: Throwable) {
            releasePlayerAsyncForRebuild()
            schedulePlaybackRetry(clean, "پلیر نتوانست منبع را باز کند")
        }
    }

    private fun irancellSubtitleFontPath(): String? {
        val assetName = BankmovieFonts.assetFileName(subtitleFontMode) ?: return null
        val dir = File(filesDir, "subtitle_fonts")
        val out = File(dir, assetName)
        if (out.isFile && out.length() > 4096L) return out.absolutePath
        return runCatching {
            dir.mkdirs()
            assets.open("fonts/$assetName").use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.takeIf { it.isFile && it.length() > 4096L }?.absolutePath
        }.getOrNull()
    }

    private fun isMeteredOrMobileNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching {
            val network = cm.activeNetwork ?: return@runCatching true
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching true
            cm.isActiveNetworkMetered || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        }.getOrDefault(true)
    }

    private fun stableCacheMs(isAdaptive: Boolean): Int {
        if (!isAdaptive) return if (DeviceProfile.isLowEnd(this)) 2200 else 1700
        return when {
            isMeteredOrMobileNetwork() -> 6500
            DeviceProfile.isLowEnd(this) -> 5200
            else -> 4200
        }
    }

    private fun startPlayer(url: String) {
        releasePlayerAsyncForRebuild()
        resumeApplied = false
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        // Restore the previously stable player buffering. The aggressive TV
        // adaptive/caching patch caused decoder artifacts on some televisions.
        val cacheMs = stableCacheMs(isDash || isHls)
        val subtitleBgColor = UiPreferences.subtitleBackgroundColor(this) and 0xFFFFFF
        val subtitleBgOpacity = UiPreferences.subtitleBackgroundOpacity(this)
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--drop-late-frames",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-color=${subtitleTextColor and 0xFFFFFF}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-color=$subtitleBgColor",
            "--freetype-background-opacity=$subtitleBgOpacity"
        )
        if (subtitleBold) libOptions.add("--freetype-bold")
        irancellSubtitleFontPath()?.let { fontPath ->
            libOptions.add("--freetype-font=$fontPath")
        }
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=rate")
            libOptions.add("--adaptive-use-access")
        }
        val lib = LibVLC(this, libOptions)
        vlc = lib
        val mp = MediaPlayer(lib)
        player = mp
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Buffering -> {
                        val percent = event.buffering
                        if (percent < 1f && bufferingStartedAt == 0L) bufferingStartedAt = System.currentTimeMillis()
                        if (percent >= 99f && bufferingStartedAt > 0L) {
                            val stalledFor = System.currentTimeMillis() - bufferingStartedAt
                            bufferingStartedAt = 0L
                            if (stalledFor >= 4500L) recentLongBufferCount += 1
                            if (recentLongBufferCount >= 3 && hardwareDecoder && !decoderAutoFallbackUsed) {
                                decoderAutoFallbackUsed = true
                                val keep = player?.time?.coerceAtLeast(0L) ?: 0L
                                hardwareDecoder = false
                                requestedResumePosition = keep
                                showHud("حالت پایدار تصویر فعال شد")
                                handler.postDelayed({ launchPlayerSafely(videoUrl) }, 180L)
                            }
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        playbackRetryCount = 0
                        playbackRetryScheduled = false
                        bufferingStartedAt = 0L
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        if (partyActive && partyIsHost && !partyApplyingRemote) {
                            val now = System.currentTimeMillis()
                            if (now - partyLastExplicitPlaySentAt > 450L) {
                                partyLastExplicitPlaySentAt = now
                                sendWatchPartyControl("play")
                            }
                        }
                        if (pauseAfterLifecycleRestore) {
                            pauseAfterLifecycleRestore = false
                            handler.postDelayed({ runCatching { player?.pause() } }, 180L)
                        }
                        applyMode()
                        applySubtitleDelay()
                        handler.postDelayed({ applySubtitleVisibility() }, 350L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 500L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 1300L)
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val stored = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            val saved = max(stored, requestedResumePosition)
                            if (saved > 15000L) {
                                fun applyResumeSeek() {
                                    try {
                                        val current = player?.time ?: 0L
                                        if (current < saved - 5000L) player?.time = saved
                                    } catch (_: Throwable) {}
                                }
                                applyResumeSeek()
                                listOf(300L, 800L, 1600L, 3000L, 5000L, 8000L, 11000L).forEach { delayMs ->
                                    handler.postDelayed({ applyResumeSeek() }, delayMs)
                                }
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    MediaPlayer.Event.Paused -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.Stopped -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.EndReached -> playNext()
                    MediaPlayer.Event.EncounteredError -> {
                        schedulePlaybackRetry(videoUrl, "خطا در پخش")
                    }
                }
            }
        }
        val media = Media(lib, Uri.parse(url))
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        if (subtitleBold) media.addOption(":freetype-bold")
        irancellSubtitleFontPath()?.let { media.addOption(":freetype-font=$it") }
        media.addOption(":freetype-color=${subtitleTextColor and 0xFFFFFF}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-color=$subtitleBgColor")
        media.addOption(":freetype-background-opacity=$subtitleBgOpacity")
        val resumePrefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val resumeStableKey = progressKey.ifBlank { "progress_$videoUrl" }
        val resumeBeforePlay = max(
            resumePrefs.getLong(
                resumeStableKey,
                resumePrefs.getLong("progress_$videoUrl", 0L)
            ),
            requestedResumePosition
        )
        resumeTarget = resumeBeforePlay
        resumeGuardUntil = System.currentTimeMillis() + 12000L
        if (resumeBeforePlay > 15000L) {
            media.addOption(":start-time=${resumeBeforePlay / 1000L}")
        }
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=rate")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        nextPromptShownKey = ""
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        title = tracks[index].title
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        requestedResumePosition = UiPreferences.prefs(this).getLong(progressKey, UiPreferences.prefs(this).getLong("progress_$videoUrl", 0L))
        updateLabels()
        refreshTopActions()
        launchPlayerSafely(videoUrl)
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }.trim()
        val normalized = base.lowercase(Locale.US).replace("‌", " ")
        val alreadyHasEpisode = normalized.contains("قسمت ${t.episode}") || normalized.contains("episode ${t.episode}") || normalized.contains("e${t.episode}")
        val alreadyHasSeason = normalized.contains("فصل ${t.season}") || normalized.contains("season ${t.season}") || normalized.contains("s${t.season}")
        val episodeHead = when {
            t.season > 0 && t.episode > 0 && !(alreadyHasSeason || alreadyHasEpisode) -> "فصل ${t.season} • قسمت ${t.episode}"
            t.episode > 0 && !alreadyHasEpisode -> "قسمت ${t.episode}"
            t.season > 0 && !alreadyHasSeason -> "فصل ${t.season}"
            else -> ""
        }
        val standard = streamStandard(t.url)
        return listOf(episodeHead, base, standard).filter { it.isNotBlank() }.distinct().joinToString(" • ")
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(muted)
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private data class NativeTrackOption(val id: Int, val name: String)

    private fun nativeTrackOptions(methodName: String): List<NativeTrackOption> {
        val mp = player ?: return emptyList()
        return try {
            val raw = mp.javaClass.getMethod(methodName).invoke(mp)
            val values: List<Any?> = when (raw) {
                is Array<*> -> raw.toList()
                is Iterable<*> -> raw.toList()
                else -> emptyList()
            }
            values.mapNotNull { item ->
                if (item == null) return@mapNotNull null
                val id = try {
                    item.javaClass.getMethod("getId").invoke(item) as? Int
                } catch (_: Throwable) {
                    try { item.javaClass.getField("id").getInt(item) } catch (_: Throwable) { null }
                } ?: return@mapNotNull null
                val name = try {
                    item.javaClass.getMethod("getName").invoke(item)?.toString()
                } catch (_: Throwable) {
                    try { item.javaClass.getField("name").get(item)?.toString() } catch (_: Throwable) { null }
                }.orEmpty().ifBlank { "Track $id" }
                NativeTrackOption(id, name)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun currentNativeTrack(methodName: String): Int {
        val mp = player ?: return -1
        return try { (mp.javaClass.getMethod(methodName).invoke(mp) as? Int) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun setNativeTrack(methodName: String, id: Int): Boolean {
        val mp = player ?: return false
        return try {
            val result = mp.javaClass.getMethod(methodName, Integer.TYPE).invoke(mp, id)
            result !is Boolean || result
        } catch (_: Throwable) {
            false
        }
    }

    private fun applySubtitleVisibility() {
        if (!subtitleEnabled) {
            val current = currentNativeTrack("getSpuTrack")
            if (current >= 0) lastEnabledSpuTrack = current
            setNativeTrack("setSpuTrack", -1)
            return
        }
        val current = currentNativeTrack("getSpuTrack")
        if (current >= 0) return
        val available = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        val target = available.firstOrNull { it.id == lastEnabledSpuTrack } ?: available.firstOrNull()
        if (target != null) setNativeTrack("setSpuTrack", target.id)
    }

    private fun applyPreferredNativeTracks() {
        if (preferredAudioTrackId != Int.MIN_VALUE && preferredAudioTrackId >= 0) {
            setNativeTrack("setAudioTrack", preferredAudioTrackId)
        }
        if (!subtitleEnabled || preferredSubtitleTrackId == -1) {
            setNativeTrack("setSpuTrack", -1)
            return
        }
        if (preferredSubtitleTrackId != Int.MIN_VALUE && preferredSubtitleTrackId >= 0) {
            lastEnabledSpuTrack = preferredSubtitleTrackId
            setNativeTrack("setSpuTrack", preferredSubtitleTrackId)
        }
    }

    private fun showNativeTrackDialog(titleValue: String, audio: Boolean) {
        val options = nativeTrackOptions(if (audio) "getAudioTracks" else "getSpuTracks")
        val current = currentNativeTrack(if (audio) "getAudioTrack" else "getSpuTrack")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(248, 18, 18, 21), dp(28), Color.argb(150, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(sectionTitle(titleValue))
        var dialog: AlertDialog? = null
        if (!audio) {
            box.addView(sheetButton("خاموش${if (current < 0) "  ✓" else ""}") {
                subtitleEnabled = false
                UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, false).apply()
                applySubtitleVisibility()
                dialog?.dismiss()
                showHud("زیرنویس غیرفعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        options.filter { audio || it.id >= 0 }.forEach { option ->
            box.addView(sheetButton("${option.name}${if (option.id == current) "  ✓" else ""}") {
                if (audio) setNativeTrack("setAudioTrack", option.id)
                else {
                    subtitleEnabled = true
                    lastEnabledSpuTrack = option.id
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    setNativeTrack("setSpuTrack", option.id)
                }
                dialog?.dismiss()
                showHud(if (audio) "ترک صدا تغییر کرد" else "زیرنویس فعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        if (options.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "ترکی برای انتخاب پیدا نشد"
                setTextColor(muted)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = playerGlassSurface(30, 248, 88)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات پخش"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_settings)
            setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("صدا و زیرنویس"))
        box.addView(settingButton("صدا، زیرنویس و ظاهر", subtitleStyleLabel(), "انتخاب ترک صدا و زیرنویس، خاموش‌کردن، رنگ، پس‌زمینه، اندازه و فونت") { showAudioSubtitleSettingsSheet() })

        box.addView(settingsMiniLabel("پخش"))
        box.addView(settingButton("سرعت پخش", speedLabel(), "تنظیم از 0.5x تا 2x") { showSpeedSheet() })
        box.addView(settingButton("زمان پرش", "${seekJumpMs / 1000L} ثانیه", "مقدار عقب و جلو رفتن") {
            val values = listOf(5L, 10L, 30L, 60L)
            val currentIndex = values.indexOf(seekJumpMs / 1000L).let { if (it < 0) 1 else it }
            val next = values[(currentIndex + 1) % values.size]
            seekJumpMs = next * 1000L
            UiPreferences.prefs(this).edit().putInt(UiPreferences.KEY_SEEK_SECONDS, next.toInt()).apply()
            showHud("زمان پرش: $next ثانیه")
        })
        box.addView(settingButton("پخش خودکار قسمت بعد", if (autoPlayNext) "روشن" else "خاموش", "پس از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("پخش خودکار: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری", "برای دستگاه‌های ضعیف حالت سخت‌افزاری بهتر است") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("دیکودر: ${if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری"}")
        })
        box.addView(settingButton("تصویر در تصویر", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("تایمر خواب", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("قفل کنترل‌ها", if (controlsLocked) "قفل" else "باز", "قفل‌کردن دکمه‌ها و ژست‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(UiPreferences.palette(this@PlayerActivity).primary2)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = playerGlassSurface(18, 232, 58)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(UiPreferences.palette(this@PlayerActivity).primary2)
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerGlassSurface(28, 246, 82)
            elevation = dp(9).toFloat()
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary)
            thumbTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showAudioSubtitleSettingsSheet() {
        var localEnabled = subtitleEnabled
        var localTextColor = subtitleTextColor
        var localBgMode = subtitleBackgroundMode
        var localFontMode = subtitleFontMode
        var localScale = subtitleScale
        var localPosition = subtitlePositionIndex
        var localDelay = subtitleDelayMs
        var localAudioTrack = currentNativeTrack("getAudioTrack")
        var localSubtitleTrack = currentNativeTrack("getSpuTrack")

        val audioOptions = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
        val subtitleOptions = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
        if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerGlassSurface(30, 248, 88)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(TextView(this).apply {
            text = "صدا و زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_audio)
            setColorFilter(Color.WHITE)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        fun optionButton(label: String, selected: () -> Boolean, click: () -> Unit): TextView {
            lateinit var view: TextView
            view = TextView(this).apply {
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(13), 0, dp(13), 0)
                maxLines = 2
                setOnClickListener { click() }
                applyPlayerFocus(this, 17, 1.03f, 0f)
            }
            fun refresh() {
                val active = selected()
                view.text = label + if (active) "   ✓" else ""
                view.background = if (active) playerGlassAccent(16) else playerGlassSurface(16, 226, 54)
                view.setTextColor(Color.WHITE)
            }
            view.tag = Runnable { refresh() }
            refresh()
            return view
        }

        fun refreshOptions(container: LinearLayout) {
            for (i in 0 until container.childCount) {
                (container.getChildAt(i).tag as? Runnable)?.run()
            }
        }

        box.addView(settingsMiniLabel("ترک صدا"))
        val audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (audioOptions.isEmpty()) {
            audioBox.addView(TextView(this).apply {
                text = "ترک صدای جداگانه‌ای در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = playerGlassSurface(15, 224, 52)
            })
        } else {
            audioOptions.forEach { option ->
                val button = optionButton(option.name, { localAudioTrack == option.id }) {
                    localAudioTrack = option.id
                    refreshOptions(audioBox)
                }
                audioBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            }
        }
        box.addView(audioBox)

        box.addView(settingsMiniLabel("زیرنویس"))
        val subtitleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        subtitleBox.addView(optionButton("خاموش", { !localEnabled || localSubtitleTrack < 0 }) {
            localEnabled = false
            localSubtitleTrack = -1
            refreshOptions(subtitleBox)
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        subtitleOptions.forEach { option ->
            val button = optionButton(option.name, { localEnabled && localSubtitleTrack == option.id }) {
                localEnabled = true
                localSubtitleTrack = option.id
                refreshOptions(subtitleBox)
            }
            subtitleBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        }
        if (subtitleOptions.isEmpty()) {
            subtitleBox.addView(TextView(this).apply {
                text = "زیرنویس داخلی در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
            })
        }
        box.addView(subtitleBox)

        box.addView(settingsMiniLabel("رنگ متن"))
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, dp(6)) }
        fun refreshColorViews() {
            colorViews.forEachIndexed { i, view ->
                view.text = if (colors[i] == localTextColor) "✓" else ""
                view.background = rounded(colors[i], dp(999), if (colors[i] == localTextColor) blue2 else Color.argb(90, 255, 255, 255))
                view.setTextColor(if (colors[i] == Color.BLACK) Color.WHITE else Color.BLACK)
            }
        }
        colors.forEachIndexed { index, color ->
            val v = TextView(this).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localTextColor = color; refreshColorViews() }
                applyPlayerFocus(this, 999, 1.08f, 0f)
            }
            colorViews.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColorViews()
        box.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("پس‌زمینه زیرنویس"))
        val bgOptions = listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی")
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        fun refreshBgButtons() {
            bgButtons.forEach { (key, view) ->
                val selected = key == localBgMode
                view.background = if (selected) rounded(blue, dp(15), blue2) else rounded(Color.rgb(30, 30, 34), dp(15), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        bgOptions.forEachIndexed { index, pair ->
            val v = TextView(this).apply {
                text = pair.second
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localBgMode = pair.first; refreshBgButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBgButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("فونت زیرنویس"))
        val fontButtons = mutableListOf<Pair<String, TextView>>()
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshFontButtons() {
            fontButtons.forEach { (key, view) ->
                val selected = key == localFontMode
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val v = TextView(this).apply {
                text = option.faLabel
                textSize = 13f
                typeface = BankmovieFonts.forMode(this@PlayerActivity, option.key, true)
                gravity = Gravity.CENTER
                setOnClickListener { localFontMode = option.key; refreshFontButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            fontButtons += option.key to v
            fontRow.addView(v, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshFontButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(fontRow)
        }, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("جای زیرنویس"))
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        val positionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshPositionButtons() {
            positionButtons.forEach { (index, view) ->
                val selected = index == localPosition
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        subtitlePositions.forEachIndexed { index, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localPosition = index; refreshPositionButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            positionButtons += index to v
            positionRow.addView(v, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshPositionButtons()
        box.addView(positionRow, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("اندازه و هماهنگی"))
        val sizeValue = TextView(this).apply { text = "اندازه متن: $localScale%"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeValue)
        val sizeSeek = SeekBar(this).apply {
            max = 90
            progress = (localScale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localScale = 80 + progress; sizeValue.text = "اندازه متن: $localScale%" }
            }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })

        val delayValue = TextView(this).apply { text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(delayValue)
        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localDelay = progress * 100 - 10000; delayValue.text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s" }
            }
        })
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        val applyButton = TextView(this).apply {
            text = "اعمال صدا و زیرنویس"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = playerGlassAccent(22)
            applyPlayerFocus(this, 23, 1.035f, 0f)
        }
        box.addView(applyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val dialog = dialogOf(scroll)
        applyButton.setOnClickListener {
            val styleChanged = localTextColor != subtitleTextColor || localBgMode != subtitleBackgroundMode || localFontMode != subtitleFontMode || localScale != subtitleScale || localPosition != subtitlePositionIndex || localDelay != subtitleDelayMs
            subtitleEnabled = localEnabled
            subtitleTextColor = localTextColor
            subtitleBackgroundMode = localBgMode
            subtitleFontMode = localFontMode
            subtitleScale = localScale
            subtitlePositionIndex = localPosition
            subtitleDelayMs = localDelay
            preferredAudioTrackId = localAudioTrack
            preferredSubtitleTrackId = if (localEnabled) localSubtitleTrack else -1
            UiPreferences.prefs(this).edit()
                .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
                .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
                .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackgroundMode)
                .putString(UiPreferences.KEY_SUB_FONT, subtitleFontMode)
                .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
                .putInt(UiPreferences.KEY_SUB_DELAY, subtitleDelayMs)
                .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePositionIndex)
                .apply()
            dialog.dismiss()
            if (styleChanged) {
                restartKeepingTime("تنظیمات صدا و زیرنویس اعمال شد")
            } else {
                applyPreferredNativeTracks()
                applySubtitleDelay()
                showHud("صدا و زیرنویس اعمال شد")
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        showAudioSubtitleSettingsSheet()
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerGlassSurface(26, 244, 76)
        }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String {
        val colorLabel = when (subtitleTextColor) {
            Color.YELLOW -> "زرد"
            Color.BLACK -> "مشکی"
            Color.RED -> "قرمز"
            Color.BLUE -> "آبی"
            Color.GREEN -> "سبز"
            else -> "سفید"
        }
        val bgLabel = when (subtitleBackgroundMode) {
            "black" -> "پس‌زمینه مشکی"
            "white" -> "پس‌زمینه سفید"
            "yellow" -> "پس‌زمینه زرد"
            "red" -> "پس‌زمینه قرمز"
            "blue" -> "پس‌زمینه آبی"
            "pink" -> "پس‌زمینه صورتی"
            else -> "شفاف"
        }
        val fontLabel = BankmovieFonts.label(subtitleFontMode)
        return "$colorLabel • $bgLabel • $fontLabel • $subtitleScale%"
    }

    private fun applySubtitleDelay() {
        try { player?.javaClass?.getMethod("setSpuDelay", java.lang.Long.TYPE)?.invoke(player, subtitleDelayMs * 1000L) } catch (_: Throwable) {}
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        requestedResumePosition = pos
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode(showError: Boolean = true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val width = videoLayout.width.takeIf { it > 0 } ?: root.width.takeIf { it > 0 } ?: 16
                val height = videoLayout.height.takeIf { it > 0 } ?: root.height.takeIf { it > 0 } ?: 9
                val ratio = android.util.Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
                val builder = PictureInPictureParams.Builder()
                    .setAspectRatio(ratio)
                enterPictureInPictureMode(builder.build())
            } catch (_: Throwable) {
                if (showError) Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else if (showError) {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(white)
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun dialogOf(view: View): AlertDialog {
        return AlertDialog.Builder(this).setView(view).create().also { dialog ->
            dialog.setOnShowListener {
                val win = dialog.window
                win?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win?.setDimAmount(0.62f)
                win?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val screenWidth = resources.displayMetrics.widthPixels
                val preferredWidth = if (isTvLike()) min(screenWidth - dp(80), dp(760)) else min(screenWidth - dp(36), dp(620))
                win?.setLayout(preferredWidth, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
                val decor = win?.decorView
                decor?.animate()?.cancel()
                if (decor != null) {
                    decor.alpha = 0f
                    decor.scaleX = 0.97f
                    decor.scaleY = 0.97f
                    decor.translationY = dp(10).toFloat()
                    decor.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                applyPlayerFocusTree(view)
                view.postDelayed({
                    fun first(v: View): Boolean {
                        if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                            v.requestFocus()
                            return true
                        }
                        if (v is android.view.ViewGroup) {
                            for (i in 0 until v.childCount) if (first(v.getChildAt(i))) return true
                        }
                        return false
                    }
                    first(view)
                }, 95L)
            }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = playerGlassSurface(16, 228, 62)
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun toggle() {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        if (partyActive && partyIsHost) sendWatchPartyControl(if (p.isPlaying) "play" else "pause")
        hideBarsLater()
    }

    private fun seekBy(delta: Long) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        val p = player ?: return
        val len = p.length
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        if (partyActive && partyIsHost) sendWatchPartyControl("seek")
        updateProgress()
        hideBarsLater()
    }

    private fun nextEpisodeIndex(): Int {
        val current = tracks.getOrNull(currentIndex) ?: return -1
        if (current.episode <= 0 && current.season <= 0) return -1
        val candidates = tracks.withIndex().filter { (_, track) ->
            track.episode > 0 && (
                track.season > current.season ||
                    (track.season == current.season && track.episode > current.episode)
                )
        }
        if (candidates.isEmpty()) return -1
        val targetPair = candidates.minWithOrNull(
            compareBy<IndexedValue<Track>> { it.value.season }
                .thenBy { it.value.episode }
        ) ?: return -1
        val sameEpisode = candidates.filter {
            it.value.season == targetPair.value.season && it.value.episode == targetPair.value.episode
        }
        return (sameEpisode.firstOrNull {
            it.value.quality.equals(current.quality, true) && isSubtitle(it.value) == isSubtitle(current)
        } ?: sameEpisode.firstOrNull {
            isSubtitle(it.value) == isSubtitle(current) && isAudioOnly(it.value) == isAudioOnly(current)
        } ?: sameEpisode.first()).index
    }

    private fun nextEpisodeTitle(index: Int): String {
        val target = tracks.getOrNull(index) ?: return "قسمت بعدی"
        return if (target.season > 0) "فصل ${target.season} • قسمت ${target.episode}" else "قسمت ${target.episode}"
    }

    private fun maybePromptNextEpisode(time: Long, length: Long) {
        if (!autoPlayNext || length <= 0L || time <= 0L) return
        val nextIndex = nextEpisodeIndex()
        if (nextIndex < 0) return
        val current = tracks.getOrNull(currentIndex) ?: return
        val key = "${current.season}:${current.episode}:${current.url}"
        if (nextPromptShownKey == key || time.toDouble() / length.toDouble() < 0.95) return
        nextPromptShownKey = key
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        nextPromptDialog = AlertDialog.Builder(this)
            .setTitle("قسمت بعدی آماده است")
            .setMessage("${nextEpisodeTitle(nextIndex)} پخش شود؟")
            .setPositiveButton("بله، پخش کن") { _, _ ->
                skipNextOnce = false
                switchTo(nextIndex)
            }
            .setNegativeButton("نه، همین قسمت") { _, _ ->
                skipNextOnce = true
                showHud("در همین قسمت می‌مانیم")
            }
            .create().also { dialog ->
                dialog.setOnDismissListener { nextPromptDialog = null }
                dialog.show()
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.rgb(18, 18, 22)))
            }
    }

    private fun playNext() {
        if (!autoPlayNext || skipNextOnce) {
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        val next = nextEpisodeIndex()
        if (next >= 0 && nextPromptDialog == null) maybePromptNextEpisode(player?.time ?: 0L, player?.length ?: 0L)
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        val mp = player ?: return
        when (modes[modeIndex]) {
            "FIT" -> { setAspect(mp, null); setScale(mp, 0f) }
            "CROP" -> { setAspect(mp, null); setScale(mp, 1.2f) }
            "STRETCH" -> {
                videoLayout.post {
                    val w = max(root.width, resources.displayMetrics.widthPixels)
                    val h = max(root.height, resources.displayMetrics.heightPixels)
                    setAspect(mp, "$w:$h")
                    setScale(mp, 0f)
                }
            }
        }
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
        if (::unlockOverlay.isInitialized) {
            unlockOverlay.visibility = if (controlsLocked) View.VISIBLE else View.GONE
        }
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        if (partyActive) showPartyChrome()
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        centerControls.visibility = View.GONE
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartY = e.y
                touchStartBrightness = currentBrightness
                touchStartVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                if (!partyGuestPlaybackLocked()) handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val dy = e.y - touchStartY
                if (gestureMode == 0 && abs(dy) > abs(dx) && abs(dy) > dp(18)) {
                    handler.removeCallbacks(longPressRunnable)
                    // Watch Party guests may only change their local volume.
                    gestureMode = if (partyGuestPlaybackLocked()) 2 else if (touchStartX < root.width / 2f) 1 else 2
                }
                if (gestureMode == 1) {
                    val delta = (touchStartY - e.y) / root.height
                    currentBrightness = (touchStartBrightness + delta * 1.6f).coerceIn(0.05f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = currentBrightness
                    window.attributes = lp
                    showHud("روشنایی ${ (currentBrightness * 100).roundToInt() }٪")
                    return true
                } else if (gestureMode == 2) {
                    val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    val delta = ((touchStartY - e.y) / root.height * maxVol).roundToInt()
                    val vol = (touchStartVolume + delta).coerceIn(0, maxVol)
                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vol, 0)
                    val percent = (vol * 100f / maxVol).roundToInt()
                    showHud("صدا ${percent}٪")
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (partyGuestPlaybackLocked()) {
                        showGuestPlaybackLockedNotice()
                    } else {
                        if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    }
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            val partyHidden = partyActive && (partyDock?.visibility != View.VISIBLE || partyStatusChip?.visibility != View.VISIBLE)
                            if (partyHidden) {
                                showControls()
                                showPartyChrome()
                            } else if (controlsVisible) {
                                hideControls()
                                if (partyActive) showPartyChrome()
                            } else {
                                showControls()
                                if (partyActive) showPartyChrome()
                            }
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val p = player
            val savedTime = (p?.time ?: 0L).coerceAtLeast(0L)
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            val duration = (p?.length ?: 0L).coerceAtLeast(0L)
            getSharedPreferences("bm_smart_cinema", MODE_PRIVATE).edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .putLong("${stableKey}_duration", duration)
                .putLong("progress_${videoUrl}_duration", duration)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val p = player ?: return
        val len = p.length
        var time = p.time
        if (resumeTarget > 15000L && System.currentTimeMillis() < resumeGuardUntil) {
            if (time < resumeTarget - 5000L) {
                try { p.time = resumeTarget } catch (_: Throwable) {}
                time = p.time
            } else {
                resumeTarget = 0L
            }
        }
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        if (len > 0L) maybePromptNextEpisode(time, len)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: MediaPlayer, ratio: String?) {
        try { mp.javaClass.getMethod("setAspectRatio", String::class.java).invoke(mp, ratio) } catch (_: Throwable) {}
    }

    private fun setScale(mp: MediaPlayer, scale: Float) {
        try { mp.javaClass.getMethod("setScale", java.lang.Float.TYPE).invoke(mp, scale) } catch (_: Throwable) {}
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        if (partyGuestPlaybackLocked()) {
            val playbackKey = key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_REWIND ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_NEXT ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
                key == android.view.KeyEvent.KEYCODE_MENU ||
                key == android.view.KeyEvent.KEYCODE_SETTINGS ||
                key == android.view.KeyEvent.KEYCODE_CAPTIONS ||
                key == android.view.KeyEvent.KEYCODE_C
            if (playbackKey) {
                showGuestPlaybackLockedNotice()
                return true
            }
            val focus = currentFocus
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_LEFT || key == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_CENTER || key == android.view.KeyEvent.KEYCODE_ENTER ||
                    key == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER || key == android.view.KeyEvent.KEYCODE_SPACE) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek || focus == playButtonBox)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
        }

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    showSubtitleStyleSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        if (!lifecycleRestorePending || videoUrl.isBlank()) return
        val target = lifecyclePosition.coerceAtLeast(0L)
        val shouldPlay = lifecycleWasPlaying
        lifecycleRestorePending = false
        requestedResumePosition = max(requestedResumePosition, target)
        pauseAfterLifecycleRestore = !shouldPlay
        resumeApplied = false
        val generation = ++lifecycleRestoreGeneration

        // PASS 4.6 lifecycle/surface fix: after screen lock, share sheet, app switch or
        // HOME, Android may destroy the old Surface while LibVLC itself still looks alive.
        // Reusing that MediaPlayer gives audio/time with a dead video output. Detach the
        // old surface, release the native player off the UI thread and rebuild against the
        // fresh VLCVideoLayout. This is also safer on low-end phones because stop/release
        // never blocks the main thread.
        releasePlayerAsyncForRebuild()
        lifecycleViewsDetached = false
        val delay = if (DeviceProfile.isLowEnd(this)) 220L else 120L
        videoLayout.postDelayed({
            if (isFinishing || isDestroyed || generation != lifecycleRestoreGeneration) return@postDelayed
            launchPlayerSafely(videoUrl)
        }, delay)
    }

    private fun releasePlayer() {
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        player = null
        vlc = null
        lifecycleViewsDetached = false
    }

    private fun releasePlayerAsyncForRebuild() {
        val oldPlayer = player
        val oldVlc = vlc
        player = null
        vlc = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { if (oldPlayer?.isPlaying == true) oldPlayer.pause() }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
        }, "BM-VLC-RebuildRelease").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    private fun releasePlayerAsyncForExit() {
        val oldPlayer = player
        val oldVlc = vlc
        player = null
        vlc = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
        }, "BM-VLC-Release").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !isFinishing &&
            player?.isPlaying == true &&
            videoUrl.isNotBlank()
        ) {
            enterPipMode(showError = false)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            handler.removeCallbacks(hideRunnable)
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.GONE
            hudBox.visibility = View.GONE
            setPartyChromeVisible(false)
            controlsVisible = false
        } else if (!controlsLocked) {
            showControls()
        }
    }

    override fun onPause() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing) {
            val current = player
            lifecyclePosition = (current?.time ?: 0L).coerceAtLeast(0L)
            lifecycleWasPlaying = current?.isPlaying == true
            lifecyclePausedAt = System.currentTimeMillis()
            lifecycleRestorePending = videoUrl.isNotBlank()
            runCatching { current?.pause() }
            runCatching { current?.detachViews(); lifecycleViewsDetached = current != null }
            if (partyActive && partyIsHost && lifecycleWasPlaying) sendWatchPartyControl("pause")
        }
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onDestroy() {
        savePlaybackProgress(true)
        nextPromptDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        runCatching { partyChatDialog?.dismiss() }
        // Native VLC shutdown can block for seconds on low-end devices. Never make the
        // main thread wait while the user is leaving the player.
        releasePlayerAsyncForExit()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
