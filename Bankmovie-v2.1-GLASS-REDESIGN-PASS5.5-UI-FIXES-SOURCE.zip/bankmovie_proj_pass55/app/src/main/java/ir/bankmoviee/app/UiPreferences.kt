package ir.bankmoviee.app

import android.content.Context
import android.graphics.Color
import kotlin.math.roundToInt

object UiPreferences {
    const val PREFS = "bm_smart_cinema"

    const val KEY_THEME = "ui_theme_mode"
    const val KEY_APP_FONT = "ui_app_font_mode"
    const val KEY_ACCENT = "ui_accent"
    const val KEY_SEEK_SECONDS = "player_seek_seconds"
    const val KEY_SUB_ENABLED = "subtitle_enabled"
    const val KEY_SUB_TEXT_COLOR = "subtitle_text_color"
    const val KEY_SUB_BG_MODE = "subtitle_background_mode"
    const val KEY_SUB_SCALE = "subtitle_scale"
    const val KEY_SUB_DELAY = "subtitle_delay_ms"
    const val KEY_SUB_FONT = "subtitle_font_mode"
    const val KEY_AUTO_NEXT = "player_auto_next"
    const val KEY_SUB_BOLD = "subtitle_bold"
    const val KEY_SUB_POSITION = "subtitle_position"
    const val KEY_DOWNLOAD_BEHAVIOR = "download_behavior"
    const val KEY_SETUP_VERSION = "quick_setup_version"
    const val CURRENT_SETUP_VERSION = 4

    data class Palette(
        val background: Int,
        val background2: Int,
        val panel: Int,
        val panel2: Int,
        val card: Int,
        val stroke: Int,
        val primary: Int,
        val primary2: Int,
        val onPrimary: Int,
        val text: Int,
        val muted: Int,
        val faint: Int,
        val light: Boolean
    )

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Bankmovie 5.1 is dark-only; ignore and overwrite any legacy light preference. */
    fun themeMode(context: Context): String {
        if (prefs(context).getString(KEY_THEME, "black") != "black") {
            prefs(context).edit().putString(KEY_THEME, "black").apply()
        }
        return "black"
    }
    fun appFontMode(context: Context): String = prefs(context).getString(KEY_APP_FONT, "font") ?: "font"
    fun accentName(context: Context): String = prefs(context).getString(KEY_ACCENT, "blue") ?: "blue"

    fun accentColor(name: String): Int = when (name) {
        "gold" -> Color.rgb(245, 184, 46)
        "orange" -> Color.rgb(255, 122, 0)
        "red" -> Color.rgb(229, 57, 53)
        "purple" -> Color.rgb(139, 92, 246)
        "teal" -> Color.rgb(0, 166, 166)
        "green" -> Color.rgb(25, 166, 84)
        else -> Color.rgb(25, 118, 255)
    }

    fun accentColor(context: Context): Int = accentColor(accentName(context))

    fun palette(context: Context): Palette {
        // PASS 3: the old blue-black theme is retired. Pass 5.5 keeps the app dark-only.
        val mode = "black"
        val primary = accentColor(context)
        val primary2 = blend(primary, Color.WHITE, if (mode == "light") 0.10f else 0.24f)
        val onPrimary = if (luminance(primary) > 0.62f) Color.rgb(12, 12, 12) else Color.WHITE

        return when (mode) {
            else -> Palette(
                background = Color.BLACK,
                background2 = Color.rgb(4, 4, 5),
                panel = Color.rgb(13, 13, 15),
                panel2 = Color.rgb(24, 24, 27),
                card = Color.rgb(18, 18, 20),
                stroke = Color.rgb(53, 53, 58),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.WHITE,
                muted = Color.rgb(190, 190, 196),
                faint = Color.rgb(124, 124, 132),
                light = false
            )
        }
    }

    fun seekSeconds(context: Context): Int = prefs(context).getInt(KEY_SEEK_SECONDS, 10).coerceIn(5, 60)
    fun autoNext(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_NEXT, true)
    fun subtitleBold(context: Context): Boolean = prefs(context).getBoolean(KEY_SUB_BOLD, true)
    fun downloadBehavior(context: Context): String = prefs(context).getString(KEY_DOWNLOAD_BEHAVIOR, "ask") ?: "ask"
    fun setupRequired(context: Context): Boolean = prefs(context).getInt(KEY_SETUP_VERSION, 0) < CURRENT_SETUP_VERSION
    fun subtitleEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SUB_ENABLED, true)
    fun subtitleTextColor(context: Context): Int = prefs(context).getInt(KEY_SUB_TEXT_COLOR, Color.YELLOW)
    fun subtitleBackgroundMode(context: Context): String = prefs(context).getString(KEY_SUB_BG_MODE, "black") ?: "black"
    fun subtitleScale(context: Context): Int = prefs(context).getInt(KEY_SUB_SCALE, 112).coerceIn(80, 170)
    fun subtitleDelayMs(context: Context): Int = prefs(context).getInt(KEY_SUB_DELAY, 0).coerceIn(-10000, 10000)
    fun subtitleFontMode(context: Context): String = prefs(context).getString(KEY_SUB_FONT, "font") ?: "font"
    fun subtitlePosition(context: Context): Int = prefs(context).getInt(KEY_SUB_POSITION, 0).coerceIn(0, 2)

    fun subtitleBackgroundColor(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "white" -> Color.WHITE
        "yellow" -> Color.YELLOW
        "red" -> Color.RED
        "blue" -> Color.BLUE
        "pink" -> Color.rgb(236, 64, 122)
        "transparent" -> Color.BLACK
        else -> Color.BLACK
    }

    fun subtitleBackgroundOpacity(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "transparent" -> 0
        "white" -> 225
        else -> 215
    }


    fun reset(context: Context) {
        prefs(context).edit()
            .remove(KEY_THEME)
            .remove(KEY_APP_FONT)
            .remove(KEY_ACCENT)
            .remove(KEY_SEEK_SECONDS)
            .remove(KEY_SUB_ENABLED)
            .remove(KEY_SUB_TEXT_COLOR)
            .remove(KEY_SUB_BG_MODE)
            .remove(KEY_SUB_SCALE)
            .remove(KEY_SUB_DELAY)
            .remove(KEY_SUB_FONT)
            .remove(KEY_AUTO_NEXT)
            .remove(KEY_SUB_BOLD)
            .remove(KEY_SUB_POSITION)
            .remove(KEY_DOWNLOAD_BEHAVIOR)
            .apply()
    }

    fun blend(a: Int, b: Int, fraction: Float): Int {
        val f = fraction.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).roundToInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).roundToInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).roundToInt()
        )
    }

    private fun luminance(color: Int): Float {
        fun channel(v: Int): Float {
            val c = v / 255f
            return if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
        }
        return 0.2126f * channel(Color.red(color)) + 0.7152f * channel(Color.green(color)) + 0.0722f * channel(Color.blue(color))
    }
}
