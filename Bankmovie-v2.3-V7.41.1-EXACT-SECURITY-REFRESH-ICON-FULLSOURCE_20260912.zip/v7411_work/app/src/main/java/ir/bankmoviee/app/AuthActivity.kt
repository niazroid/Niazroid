package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.graphics.Rect
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.net.HttpURLConnection
import java.net.URL

class AuthActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var backgroundImage: ImageView
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var statusText: TextView
    private var registerMode = false
    private var busy = false
    private var securityChallengeToken = ""
    private var securityExpectedCode = ""
    private var securityDisplay: TextView? = null
    private var securityInput: EditText? = null
    private var tvKeyboardDialog: AlertDialog? = null
    // V7.14: after toggling Login/Register, keep DPAD focus on the same stable
    // mode switch instead of jumping to the first field of the rebuilt form.
    private var focusModeSwitchAfterRender = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        registerMode = intent.getBooleanExtra("register", false)
        runCatching { requestWindowFeature(Window.FEATURE_NO_TITLE) }
        runCatching { window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE) }
        runCatching { window.statusBarColor = Color.TRANSPARENT }
        runCatching { window.navigationBarColor = Color.rgb(8, 8, 11) }
        buildShell()
        applyBundledBackground()
        AccountSession.authBackground(this).takeIf { it.isNotBlank() }?.let(::loadBackground)
        renderForm()

        AccountApi.loadConfig(this) { _ ->
            if (isFinishing || isDestroyed) return@loadConfig
            // Do not rebuild a focused TV form after the remote request returns.
            // Several TV IMEs close the Activity when their EditText is detached.
            if (!AccountSession.registrationEnabled(this) && registerMode) {
                registerMode = false
                renderForm()
            }
            AccountSession.authBackground(this).takeIf { it.isNotBlank() }?.let(::loadBackground)
        }
    }

    private fun buildShell() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8, 8, 11))
            clipChildren = false
            clipToPadding = false
        }
        backgroundImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            // Restore the original login composition while keeping the TV
            // lifecycle/keyboard crash safeguards added below.
            alpha = if (isTvLike()) 0.30f else 0.38f
        }
        root.addView(backgroundImage, FrameLayout.LayoutParams(-1, -1))

        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(120, 8, 8, 12), Color.argb(235, 8, 8, 12), Color.rgb(8, 8, 11))
            )
        }, FrameLayout.LayoutParams(-1, -1))

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            clipChildren = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setPadding(0, 0, 0, dp(28))
        }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(18), dp(18), dp(34))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        runCatching {
            ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
                val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
                val navigationBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
                val bottom = dp(28) + maxOf(imeBottom, navigationBottom)
                if (scroll.paddingBottom != bottom) scroll.setPadding(0, 0, 0, bottom)
                insets
            }
            ViewCompat.requestApplyInsets(root)
        }
    }

    private fun applyBundledBackground() {
        backgroundImage.tag = "bundled"
        backgroundImage.setImageResource(R.drawable.bm_loading_auth_bg)
    }

    private fun renderForm() {
        page.removeAllViews()
        val palette = UiPreferences.palette(this)
        val accent = palette.primary
        val accentSoft = UiPreferences.blend(accent, Color.WHITE, 0.16f)
        val panel = Color.rgb(12, 15, 22)

        fun siteTitle(textValue: String): SpannableString {
            val styled = SpannableString(textValue)
            val marker = "بانک مووی"
            val at = textValue.indexOf(marker)
            if (at >= 0) {
                styled.setSpan(ForegroundColorSpan(accent), at, at + marker.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                styled.setSpan(StyleSpan(Typeface.BOLD), at, at + marker.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
            return styled
        }

        // Keep the website-style card visually centered on phones instead of
        // pinning it to the status bar. Register stays scrollable when taller
        // than the viewport, while Login sits around the optical center.
        if (!isTvLike()) {
            page.gravity = Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL
            page.minimumHeight = (resources.displayMetrics.heightPixels - dp(28)).coerceAtLeast(dp(560))
        } else {
            page.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            page.minimumHeight = 0
        }

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(28), dp(12), dp(28), dp(28))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.blend(panel, accent, 0.035f),
                panel,
                Color.rgb(8, 10, 15)
            )).apply {
                cornerRadius = dp(30).toFloat()
                setStroke(dp(1), Color.argb(155, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            elevation = dp(8).toFloat()
        }
        val dragHandle = View(this).apply {
            background = rounded(Color.argb(125, 190, 195, 208), 999, Color.TRANSPARENT)
            contentDescription = "جابجایی فرم ورود"
        }
        card.addView(dragHandle, LinearLayout.LayoutParams(dp(58), dp(5)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(18)
        })

        card.addView(TextView(this).apply {
            text = siteTitle(if (registerMode) "ساخت حساب بانک مووی" else "ورود به بانک مووی")
            setTextColor(Color.WHITE)
            textSize = if (isTvLike()) 30f else 27f
            typeface = BankmovieFonts.bold(this@AuthActivity)
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })

        card.addView(TextView(this).apply {
            text = if (registerMode) {
                "چند ثانیه تا ساخت داشبورد سینمایی شما."
            } else {
                "برای ادامه تماشا و مدیریت حساب وارد شوید."
            }
            setTextColor(Color.rgb(151, 158, 174))
            textSize = 12.6f
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(28) })

        statusText = TextView(this).apply {
            visibility = View.GONE
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1f)
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        card.addView(statusText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val identity: EditText?
        val username: EditText?
        val email: EditText?
        val password: EditText
        val confirm: EditText?

        if (registerMode) {
            username = authField(card, "نام کاربری", "نام کاربری", R.drawable.ic_auth_user, false)
            email = authField(card, "ایمیل معتبر", "ایمیل معتبر", R.drawable.ic_auth_email, false, true)
            identity = null
        } else {
            identity = authField(card, "نام کاربری یا ایمیل", "نام کاربری یا ایمیل", R.drawable.ic_auth_user, false)
            username = null
            email = null
        }
        password = authField(
            card,
            if (registerMode) "رمز عبور (حداقل ۸ کاراکتر)" else "رمز عبور",
            if (registerMode) "رمز عبور (حداقل ۸ کاراکتر)" else "رمز عبور",
            R.drawable.ic_auth_lock,
            true
        )
        confirm = if (registerMode) {
            authField(card, "تکرار رمز عبور", "تکرار رمز عبور", R.drawable.ic_auth_lock, true)
        } else null

        if (!registerMode) {
            card.addView(TextView(this).apply {
                text = "رمز عبور را فراموش کرده‌ام"
                setTextColor(accentSoft)
                textSize = 12.5f
                typeface = BankmovieFonts.bold(this@AuthActivity)
                gravity = Gravity.RIGHT
                setPadding(0, dp(2), 0, dp(12))
                isClickable = true
                isFocusable = true
                applyFocusHalo(this, 12, 1.02f)
                setOnClickListener {
                    val url = AppConfig.BASE_DOMAIN.trimEnd('/') + "/forgot-password"
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                        .onFailure { showStatus("صفحه بازیابی رمز عبور در دسترس نیست", true) }
                }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        // Website-like four-digit security verification card.
        val securityCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(12), dp(12), dp(10))
            background = rounded(Color.argb(176, 11, 14, 20), 18, Color.argb(130, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val securityHead = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        securityHead.addView(FrameLayout(this).apply {
            background = rounded(Color.argb(44, Color.red(accent), Color.green(accent), Color.blue(accent)), 12, Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent)))
            addView(ImageView(this@AuthActivity).apply {
                setImageResource(R.drawable.ic_auth_lock)
                setColorFilter(accent)
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) })
        securityHead.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@AuthActivity).apply {
                text = "تأیید امنیتی"
                setTextColor(Color.WHITE)
                textSize = 13.7f
                typeface = BankmovieFonts.bold(this@AuthActivity)
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@AuthActivity).apply {
                text = "عدد ۴ رقمی تصویر را وارد کنید"
                setTextColor(Color.rgb(137, 145, 160))
                textSize = 10.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(2), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        securityHead.addView(FrameLayout(this).apply {
            background = rounded(
                Color.argb(32, Color.red(accent), Color.green(accent), Color.blue(accent)),
                12,
                Color.argb(125, Color.red(accent), Color.green(accent), Color.blue(accent))
            )
            isClickable = true
            isFocusable = true
            contentDescription = "دریافت کد امنیتی جدید"
            applyFocusHalo(this, 12, 1.04f)
            addView(ImageView(this@AuthActivity).apply {
                setImageResource(R.drawable.ic_status_update_arrow)
                setColorFilter(accentSoft)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(9), dp(9), dp(9), dp(9))
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            setOnClickListener { refreshSecurityChallenge() }
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(8) })
        securityCard.addView(securityHead, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        val securityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
        }
        val securityCodeDisplay = TextView(this).apply {
            text = "••••"
            setTextColor(accentSoft)
            textSize = 31f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            letterSpacing = 0.16f
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(8, 13, 21), 14, Color.argb(120, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        securityDisplay = securityCodeDisplay
        securityRow.addView(securityCodeDisplay, LinearLayout.LayoutParams(0, dp(62), 1.0f).apply { marginEnd = dp(8) })
        val securityCodeInput = EditText(this).apply {
            hint = "کد ۴ رقمی"
            setHintTextColor(Color.rgb(119, 126, 141))
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(18, 21, 28), 14, Color.argb(75, 255, 255, 255))
            isSingleLine = true
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(4))
            if (isTvLike()) showSoftInputOnFocus = false
            setPadding(dp(12), 0, dp(12), 0)
        }
        securityInput = securityCodeInput
        bindTvKeyboard(securityCodeInput)
        securityRow.addView(securityCodeInput, LinearLayout.LayoutParams(0, dp(62), 0.9f))
        securityCard.addView(securityRow, LinearLayout.LayoutParams(-1, -2))
        securityCard.addView(TextView(this).apply {
            text = "کد یک‌بارمصرف است؛ با تازه‌سازی یا ارسال فرم قبلی باطل می‌شود."
            setTextColor(Color.rgb(114, 122, 138))
            textSize = 9.4f
            gravity = Gravity.RIGHT
            setPadding(dp(2), dp(7), dp(2), 0)
        }, LinearLayout.LayoutParams(-1, -2))
        card.addView(securityCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5); bottomMargin = dp(18) })

        val submitLabel = TextView(this).apply {
            text = if (registerMode) "ساخت حساب کاربری" else "ورود به حساب"
            setTextColor(palette.onPrimary)
            textSize = 15.4f
            typeface = BankmovieFonts.bold(this@AuthActivity)
            gravity = Gravity.CENTER
        }
        val submit = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                UiPreferences.blend(accent, Color.WHITE, 0.08f),
                accent,
                UiPreferences.blend(accent, Color.BLACK, 0.38f)
            )).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(185, Color.red(accentSoft), Color.green(accentSoft), Color.blue(accentSoft)))
            }
            elevation = dp(5).toFloat()
            isClickable = true
            isFocusable = true
            applyFocusHalo(this, 999, 1.025f)
            addView(submitLabel, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            setOnClickListener {
                if (busy) return@setOnClickListener
                animate().cancel()
                animate().scaleX(0.98f).scaleY(0.98f).setDuration(50L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                }.start()
                if (registerMode) submitRegister(username!!, email!!, password, confirm!!, submitLabel)
                else submitLogin(identity!!, password, submitLabel)
            }
        }
        card.addView(submit, LinearLayout.LayoutParams(-1, dp(58)).apply { bottomMargin = dp(18) })

        val switch = TextView(this).apply {
            tag = "bm_v714_auth_mode_switch"
            val base = if (!AccountSession.registrationEnabled(this@AuthActivity)) {
                "ثبت‌نام موقتاً غیرفعال است"
            } else if (registerMode) {
                "قبلاً ثبت‌نام کردی؟  ورود به حساب"
            } else {
                "هنوز حساب نداری؟  ثبت‌نام رایگان"
            }
            val styled = SpannableString(base)
            val highlight = when {
                !AccountSession.registrationEnabled(this@AuthActivity) -> "ثبت‌نام موقتاً غیرفعال است"
                registerMode -> "ورود به حساب"
                else -> "ثبت‌نام رایگان"
            }
            val at = base.indexOf(highlight)
            if (at >= 0) styled.setSpan(ForegroundColorSpan(accentSoft), at, at + highlight.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = styled
            setTextColor(Color.rgb(174, 180, 192))
            textSize = 12.3f
            typeface = BankmovieFonts.bold(this@AuthActivity)
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(2), dp(6), dp(8))
            isClickable = true
            isFocusable = true
            applyFocusHalo(this, 14, 1.02f)
            setOnClickListener {
                if (!busy && AccountSession.registrationEnabled(this@AuthActivity)) {
                    focusModeSwitchAfterRender = isTvLike()
                    registerMode = !registerMode
                    renderForm()
                } else if (!AccountSession.registrationEnabled(this@AuthActivity)) {
                    showStatus("ثبت‌نام از پنل مدیریت غیرفعال شده است", true)
                }
            }
        }
        card.addView(switch, LinearLayout.LayoutParams(-1, dp(44)))

        val back = TextView(this).apply {
            text = "‹   بازگشت به بانک مووی"
            setTextColor(Color.rgb(148, 153, 166))
            textSize = 11.7f
            typeface = BankmovieFonts.bold(this@AuthActivity)
            gravity = Gravity.CENTER
            background = rounded(Color.argb(65, 255, 255, 255), 999, Color.argb(44, 255, 255, 255))
            isClickable = true
            isFocusable = true
            applyFocusHalo(this, 999, 1.02f)
            setOnClickListener { finish() }
        }
        card.addView(back, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(14) })

        if (isTvLike()) {
            val focusChain = listOfNotNull<View>(identity, username, email, password, confirm, securityInput, submit, switch, back)
            focusChain.forEach { if (it.id == View.NO_ID) it.id = View.generateViewId() }
            focusChain.forEachIndexed { index, view ->
                view.nextFocusUpId = focusChain.getOrNull(index - 1)?.id ?: view.id
                view.nextFocusDownId = focusChain.getOrNull(index + 1)?.id ?: view.id
            }
        }

        password.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
        confirm?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_NEXT
        securityInput?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        securityInput?.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_UP
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE || enter) {
                submit.performClick(); true
            } else false
        }

        val formWidth = if (isTvLike()) dp(600) else -1
        page.addView(card, LinearLayout.LayoutParams(formWidth, -2).apply {
            topMargin = dp(if (isTvLike()) 30 else 8)
            bottomMargin = dp(if (isTvLike()) 32 else 18)
        })
        if (!isTvLike()) card.post { wireDraggableAuthCard(card, dragHandle) }

        refreshSecurityChallenge()

        page.alpha = 0f
        page.translationY = dp(8).toFloat()
        page.animate().alpha(1f).translationY(0f).setDuration(190L)
            .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        if (isTvLike()) {
            page.postDelayed({
                if (focusModeSwitchAfterRender) {
                    focusModeSwitchAfterRender = false
                    switch.requestFocus()
                } else {
                    (identity ?: username ?: password).requestFocus()
                }
            }, 110L)
        }
    }

    private fun authField(
        parent: LinearLayout,
        label: String,
        hint: String,
        icon: Int,
        password: Boolean,
        email: Boolean = false
    ): EditText {
        val palette = UiPreferences.palette(this)
        val accent = palette.primary
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        row.addView(ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(Color.rgb(166, 171, 184))
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }, LinearLayout.LayoutParams(dp(38), dp(42)).apply { marginStart = dp(6) })

        val edit = EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.rgb(150, 155, 168))
            setTextColor(Color.WHITE)
            textSize = 13.8f
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            background = null
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                email -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (isTvLike()) showSoftInputOnFocus = false
        }
        bindTvKeyboard(edit)
        row.addView(edit, LinearLayout.LayoutParams(0, dp(58), 1f))

        if (password) {
            row.addView(ImageView(this).apply {
                var visible = false
                setImageResource(R.drawable.ic_auth_eye)
                setColorFilter(Color.rgb(132, 138, 152))
                setPadding(dp(7), dp(7), dp(7), dp(7))
                isClickable = !isTvLike()
                isFocusable = !isTvLike()
                contentDescription = "نمایش رمز عبور"
                if (!isTvLike()) applyFocusHalo(this, 999, 1.04f)
                setOnClickListener {
                    val selection = edit.selectionStart.coerceAtLeast(0)
                    visible = !visible
                    edit.inputType = if (visible) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    setImageResource(if (visible) R.drawable.ic_auth_eye_off else R.drawable.ic_auth_eye)
                    edit.setSelection(selection.coerceAtMost(edit.text.length))
                }
            }, LinearLayout.LayoutParams(dp(38), dp(42)).apply { marginEnd = dp(5) })
        }

        val line = View(this).apply {
            setBackgroundColor(Color.rgb(170, 174, 184))
        }
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(row, LinearLayout.LayoutParams(-1, dp(58)))
            addView(line, LinearLayout.LayoutParams(-1, dp(2)))
        }
        edit.setOnFocusChangeListener { _, focused ->
            line.setBackgroundColor(if (focused) accent else Color.rgb(170, 174, 184))
            line.animate().alpha(if (focused) 1f else 0.72f).setDuration(120L).start()
            if (focused) scroll.postDelayed({ scrollToView(edit) }, 80L)
        }
        parent.addView(shell, LinearLayout.LayoutParams(-1, dp(66)).apply { bottomMargin = dp(13) })
        return edit
    }

    private fun refreshSecurityChallenge() {
        val display = securityDisplay ?: return
        val input = securityInput ?: return
        display.text = "••••"
        input.setText("")
        securityChallengeToken = ""
        securityExpectedCode = ""
        AccountApi.authChallenge(this) { result ->
            if (isFinishing || isDestroyed) return@authChallenge
            val json = result.json
            if (result.success && json != null) {
                securityChallengeToken = json.optString("challenge_token")
                securityExpectedCode = json.optString("display_code")
            }
            if (securityExpectedCode.length != 4) {
                securityExpectedCode = (1000 + java.security.SecureRandom().nextInt(9000)).toString()
                securityChallengeToken = ""
            }
            display.text = securityExpectedCode.chunked(1).joinToString("")
            display.alpha = 0f
            display.animate().alpha(1f).setDuration(140L).start()
        }
    }

    private fun validateSecurityCode(): String? {
        val value = securityInput?.text?.toString()?.trim().orEmpty()
        if (!value.matches(Regex("\\d{4}"))) {
            showStatus("کد تأیید امنیتی ۴ رقمی را وارد کنید", true)
            return null
        }
        if (securityChallengeToken.isBlank() && securityExpectedCode.isNotBlank() && value != securityExpectedCode) {
            showStatus("کد تأیید امنیتی اشتباه است", true)
            refreshSecurityChallenge()
            return null
        }
        return value
    }

    private fun submitLogin(identity: EditText, password: EditText, button: TextView) {
        if (!AccountSession.loginEnabled(this)) {
            showStatus("ورود از پنل مدیریت موقتاً غیرفعال شده است", true)
            return
        }
        val identityValue = identity.text.toString().trim()
        val passwordValue = password.text.toString()
        if (identityValue.isBlank() || passwordValue.isBlank()) {
            showStatus("نام کاربری یا ایمیل و رمز عبور را کامل وارد کنید", true)
            return
        }
        val securityValue = validateSecurityCode() ?: return
        setBusy(button, true)
        AccountApi.login(this, identityValue, passwordValue, securityChallengeToken, securityValue) { result ->
            if (!result.success) {
                setBusy(button, false)
                showStatus(result.message.ifBlank { "ورود انجام نشد؛ اطلاعات واردشده را بررسی کنید" }, true)
                if (result.json?.optBoolean("challenge_required", false) == true || result.message.contains("امنیتی")) {
                    refreshSecurityChallenge()
                }
                return@login
            }
            finishAuth(button, "ورود موفق بود")
        }
    }

    private fun submitRegister(
        username: EditText,
        email: EditText,
        password: EditText,
        confirm: EditText,
        button: TextView
    ) {
        if (!AccountSession.registrationEnabled(this)) {
            showStatus("ثبت‌نام از پنل مدیریت غیرفعال شده است", true)
            return
        }
        val usernameValue = username.text.toString().trim()
        val emailValue = email.text.toString().trim()
        val passwordValue = password.text.toString()
        val confirmValue = confirm.text.toString()
        if (usernameValue.length < 3) {
            showStatus("نام کاربری باید حداقل ۳ کاراکتر باشد", true)
            return
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
            showStatus("ایمیل معتبر وارد کنید؛ نمونه: name@example.com", true)
            return
        }
        if (passwordValue.length < 8) {
            showStatus("رمز عبور باید حداقل ۸ کاراکتر باشد", true)
            return
        }
        if (passwordValue != confirmValue) {
            showStatus("رمز عبور و تکرار آن یکسان نیست", true)
            return
        }
        val securityValue = validateSecurityCode() ?: return
        setBusy(button, true)
        AccountApi.register(this, usernameValue, emailValue, passwordValue, confirmValue, securityChallengeToken, securityValue) { result ->
            if (!result.success) {
                setBusy(button, false)
                showStatus(result.message.ifBlank { "ثبت‌نام انجام نشد؛ اطلاعات را دوباره بررسی کنید" }, true)
                if (result.json?.optBoolean("challenge_required", false) == true || result.message.contains("امنیتی")) {
                    refreshSecurityChallenge()
                }
                return@register
            }
            finishAuth(button, "ثبت‌نام با موفقیت انجام شد")
        }
    }

    private fun showStatus(message: String, error: Boolean = false) {
        if (!::statusText.isInitialized) {
            toast(message)
            return
        }
        val accent = if (error) Color.rgb(238, 76, 91) else UiPreferences.accentColor(this)
        statusText.text = message
        statusText.setTextColor(if (error) Color.rgb(255, 214, 218) else Color.WHITE)
        statusText.background = rounded(
            Color.argb(if (error) 82 else 58, Color.red(accent), Color.green(accent), Color.blue(accent)),
            14,
            Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))
        )
        statusText.visibility = View.VISIBLE
        statusText.alpha = 0f
        statusText.translationY = -dp(6).toFloat()
        statusText.animate().alpha(1f).translationY(0f).setDuration(150L).start()
    }

    private fun finishAuth(button: TextView, message: String) {
        button.text = "در حال همگام‌سازی واچ‌لیست..."
        showStatus("ورود انجام شد؛ در حال همگام‌سازی اطلاعات حساب...", false)
        AccountApi.syncWatchlist(this, force = true) {
            toast(message)
            setResult(RESULT_OK)
            finish()
        }
    }

    private fun setBusy(button: TextView, value: Boolean) {
        busy = value
        button.isEnabled = !value
        button.alpha = if (value) 0.72f else 1f
        button.text = if (value) "لطفاً صبر کنید..." else if (registerMode) "ساخت حساب کاربری" else "ورود به حساب"
    }

    private fun loadBackground(url: String) {
        if (url.isBlank()) {
            applyBundledBackground()
            return
        }
        backgroundImage.tag = url
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 9000
                connection.readTimeout = 12000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "Bankmovie Android")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val bitmap = BitmapFactory.decodeStream(connection.inputStream, null, options) ?: return@Thread
                runOnUiThread {
                    if (backgroundImage.tag == url && !isFinishing && !isDestroyed) {
                        backgroundImage.animate().cancel()
                        backgroundImage.alpha = 0.72f
                        backgroundImage.setImageBitmap(bitmap)
                        backgroundImage.animate().alpha(1f).setDuration(240L).start()
                    }
                }
            } catch (_: Throwable) {
                runOnUiThread { if (!isFinishing && !isDestroyed) applyBundledBackground() }
            } finally {
                runCatching { connection?.disconnect() }
            }
        }.start()
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
            resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun focusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val outer = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.argb(38, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val inner = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(155, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclamp(view: View) {
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun applyFocusHalo(view: View, radius: Int, scale: Float) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        val originalElevation = view.elevation
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        view.setOnFocusChangeListener { target, focused ->
            target.animate().cancel()
            if (focused) {
                // V7.15: NEVER call bringToFront() for a focusable child inside a
                // LinearLayout. ViewGroup.bringChildToFront() changes child order,
                // which made Submit / Login-Register physically swap positions.
                unclamp(target)
            }
            target.foreground = if (focused) focusDrawable(radius) else originalForeground
            target.elevation = if (focused) dp(20).toFloat() else originalElevation
            target.translationZ = if (focused) dp(7).toFloat() else 0f
            target.animate()
                .scaleX(if (focused) scale else 1f)
                .scaleY(if (focused) scale else 1f)
                .setDuration(if (focused) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun bindInputFocus(box: View, edit: EditText) {
        val originalForeground = box.foreground
        val originalElevation = box.elevation
        edit.setOnFocusChangeListener { _, focused ->
            box.animate().cancel()
            if (focused) {
                unclamp(box)
                scroll.postDelayed({ scrollToView(edit) }, 90L)
            }
            box.foreground = if (focused) focusDrawable(17) else originalForeground
            box.elevation = if (focused) dp(18).toFloat() else originalElevation
            box.translationZ = if (focused) dp(6).toFloat() else 0f
            box.animate()
                .scaleX(if (focused) 1.018f else 1f)
                .scaleY(if (focused) 1.018f else 1f)
                .setDuration(125L)
                .start()
        }
    }

    private fun bindTvKeyboard(edit: EditText) {
        if (!isTvLike()) return
        edit.setOnClickListener { showTvKeyboard(edit) }
        edit.setOnKeyListener { _, keyCode, event ->
            val okKey = keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_ENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_BUTTON_A
            if (!okKey) return@setOnKeyListener false
            if (event.action == android.view.KeyEvent.ACTION_UP) showTvKeyboard(edit)
            true
        }
    }

    private fun showTvKeyboard(edit: EditText) {
        if (!isTvLike()) return
        runCatching {
            edit.requestFocus()
            edit.setSelection(edit.text.length)
        }
        edit.postDelayed({
            if (isFinishing || isDestroyed || !edit.isAttachedToWindow) return@postDelayed
            val shown = runCatching {
                val input = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                input?.restartInput(edit)
                input?.showSoftInput(edit, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) == true
            }.getOrDefault(false)
            if (!shown) showTvTextEntryFallback(edit)
        }, 80L)
    }

    /**
     * Some Android TV vendors ship an IME that refuses inline EditTexts. Keep
     * the login usable with a focused dialog and never force/restart the IME.
     */
    private fun showTvTextEntryFallback(target: EditText) {
        if (!isTvLike() || isFinishing || isDestroyed || tvKeyboardDialog?.isShowing == true) return
        val editor = EditText(this).apply {
            setText(target.text)
            inputType = target.inputType
            isSingleLine = true
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(140, 140, 152))
            hint = target.hint
            textSize = 17f
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.rgb(39, 38, 46), 16, Color.argb(120, 255, 255, 255))
            setSelection(text.length)
        }
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(20), dp(22), dp(18))
            background = rounded(Color.rgb(21, 20, 27), 24, Color.argb(110, 255, 255, 255))
            addView(TextView(this@AuthActivity).apply {
                text = "ورود متن با کنترل تلویزیون"
                setTextColor(Color.WHITE)
                textSize = 18f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
            addView(editor, LinearLayout.LayoutParams(-1, dp(62)))
        }
        tvKeyboardDialog = AlertDialog.Builder(this)
            .setView(shell)
            .setPositiveButton("تأیید") { _, _ ->
                target.setText(editor.text)
                target.setSelection(target.text.length)
            }
            .setNegativeButton("انصراف", null)
            .create()
            .also { dialog ->
                dialog.setOnDismissListener { tvKeyboardDialog = null }
                runCatching { dialog.show() }.onFailure { tvKeyboardDialog = null }
                editor.postDelayed({
                    if (dialog.isShowing) {
                        editor.requestFocus()
                        runCatching {
                            (getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager)
                                ?.showSoftInput(editor, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
                        }
                    }
                }, 140L)
            }
    }

    override fun onDestroy() {
        runCatching { tvKeyboardDialog?.dismiss() }
        tvKeyboardDialog = null
        super.onDestroy()
    }

    private fun wireDraggableAuthCard(card: View, handle: View) {
        var downY = 0f
        var startY = 0f
        var moved = false
        val slop = dp(6).toFloat()
        val minY = -dp(70).toFloat()
        val maxY = dp(150).toFloat()
        handle.isClickable = true
        handle.isFocusable = true
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    startY = card.translationY
                    moved = false
                    card.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawY - downY
                    if (kotlin.math.abs(delta) > slop) moved = true
                    card.translationY = (startY + delta).coerceIn(minY, maxY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val current = card.translationY
                    val target = when {
                        current > dp(86) -> dp(104).toFloat()
                        current < -dp(42) -> -dp(48).toFloat()
                        else -> 0f
                    }
                    card.animate()
                        .translationY(target)
                        .setDuration(220L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f))
                        .start()
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        card.animate().translationY(0f).setDuration(180L).start()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun scrollToView(view: View) {
        if (!::scroll.isInitialized || !::page.isInitialized) return
        val rect = Rect()
        view.getDrawingRect(rect)
        page.offsetDescendantRectToMyCoords(view, rect)
        val target = (rect.bottom - scroll.height + dp(190)).coerceAtLeast(0)
        scroll.smoothScrollTo(0, target)
    }

    private fun authTintGlass(accent: Int, radius: Int): GradientDrawable {
        val base = Color.rgb(25, 25, 29)
        val top = UiPreferences.blend(base, accent, 0.28f)
        val bottom = UiPreferences.blend(base, Color.BLACK, 0.06f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(118, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (Color.alpha(stroke) > 0) setStroke(dp(1), stroke)
        }
    }

    private fun toast(message: String) {
        val kind = if (message.contains("انجام شد") || message.contains("موفق")) BmNotice.Kind.SUCCESS else BmNotice.Kind.INFO
        BmNotice.show(this, message, kind, 3000L)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
