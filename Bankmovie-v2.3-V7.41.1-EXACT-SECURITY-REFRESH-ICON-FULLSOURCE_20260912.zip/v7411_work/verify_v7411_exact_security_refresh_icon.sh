#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFourthHotfixTag=BANKMOVIE-2.3-V7411-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Exact icon migration requested by owner: the detail/update arrow is now the auth challenge refresh icon.
test -s "$draw/ic_status_update_arrow.xml"
grep -Fq 'setImageResource(R.drawable.ic_status_update_arrow)' "$auth"
! grep -Fq 'setImageResource(R.drawable.ic_auth_refresh)' "$auth"

# Detail status pill remains text-only after moving the icon out of the movie page.
grep -Fq 'the exact update-arrow drawable that used to live here was moved' "$main"

# Keep all V7.41 behavior/regressions intact.
bash verify_v741_auth_player_modal_speed_polish.sh

echo V7411_EXACT_SECURITY_REFRESH_ICON_VERIFY_OK
