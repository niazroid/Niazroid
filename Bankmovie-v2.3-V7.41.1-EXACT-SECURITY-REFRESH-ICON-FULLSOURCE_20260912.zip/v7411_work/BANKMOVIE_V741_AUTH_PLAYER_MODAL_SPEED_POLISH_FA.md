BANKMOVIE V7.41 — AUTH / PLAYER / MODAL / SPEED POLISH
=====================================================

این پاس مستقیماً روی سورس V7.40.1 انجام شده است.

1) صفحه ورود و ثبت‌نام
- فرم موبایل از بالای صفحه جدا شد و در مرکز بصری صفحه قرار گرفت.
- بالای کارت Drag Handle اضافه شد و کارت روی موبایل با دست بالا/پایین کشیده می‌شود.
- آیکن‌های Username / Password / View با SVGهای ارسالی مالک پروژه جایگزین شدند.
- آیکن Settings ارسالی نیز به تنظیمات پروفایل/منو وصل شد.
- تأیید امنیتی و Refresh خود کد امنیتی دست‌نخورده و فعال باقی ماند.

2) صفحه جزئیات فیلم
- آیکن Refresh/Update کنار Badge «قسمت ... اضافه شد» حذف شد و Badge فقط متن تمیز دارد.

3) پیشنهاد قسمت بعدی Player
- آیکن Info قبلی حذف و Play واقعی جایگزین شد.
- پنجره با همان Accent انتخابی کاربر و شیشه/Stroke هماهنگ با پلیر باقی می‌ماند.

4) سرعت دکمه Play روی پوستر
- لیست لینک‌های پردازش‌شده Detail در WeakHashMap cache می‌شود.
- دکمه Play پوستر همان لیست آماده را مصرف می‌کند و دوباره کل لینک‌ها را parse/sort نمی‌کند.
- Bottom Sheet ابتدا فوراً باز می‌شود و ساخت کارت‌های فصل/کیفیت بعد از نمایش و به‌صورت مرحله‌ای انجام می‌شود.
- نتیجه: حس بازشدن باید نزدیک به دکمه‌های کیفیت موجود داخل Detail باشد.

5) یکپارچه‌سازی ظاهر مودال‌ها
- Choice Sheetها (کشور/ژانر/مرتب‌سازی دیدگاه‌ها و موارد مشابه) با زبان Player/Downloader یکسان شدند.
- Close ×، Drag Handle، Glass Background و Accent کاربر دارند.
- ارتفاع لیست براساس تعداد آیتم محاسبه می‌شود؛ لیست ۵ گزینه دیگر فضای خالی بزرگ تا پایین صفحه ندارد.
- Confirm Sheetها هم به همان زبان بصری Player/Downloader منتقل شدند.

فایل‌های اصلی تغییرکرده:
- app/src/main/java/ir/bankmoviee/app/AuthActivity.kt
- app/src/main/java/ir/bankmoviee/app/MainActivity.kt
- app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt
- app/src/main/res/drawable/ic_auth_user.xml
- app/src/main/res/drawable/ic_auth_lock.xml
- app/src/main/res/drawable/ic_auth_eye.xml
- app/src/main/res/drawable/ic_user_settings.xml
