#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyThirdHotfixTag=BANKMOVIE-2.3-V741-20260912' BANKMOVIE_BUILD_SOURCE_2_3.txt

# Website-style auth stays centered and draggable on phones.
grep -Fq 'page.gravity = Gravity.CENTER_HORIZONTAL or Gravity.CENTER_VERTICAL' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"
grep -Fq 'MotionEvent.ACTION_MOVE' "$auth"

# Owner supplied auth/profile vector assets are installed and used.
test -s "$draw/ic_auth_user.xml"
test -s "$draw/ic_auth_lock.xml"
test -s "$draw/ic_auth_eye.xml"
test -s "$draw/ic_user_settings.xml"
grep -Fq 'R.drawable.ic_auth_user' "$auth"
grep -Fq 'R.drawable.ic_auth_lock' "$auth"
grep -Fq 'R.drawable.ic_auth_eye' "$auth"
grep -Fq 'R.drawable.ic_user_settings' "$main"

# Next episode uses a real play glyph instead of an info/home-like badge.
grep -Fq 'text = "قسمت بعدی آماده است"' "$player"
grep -Fq 'setImageResource(R.drawable.ic_play_fill)' "$player"

# Detail update pill has no refresh/status glyph.
grep -Fq 'The security refresh glyph belongs' "$main"

# Hero Play reuses normalized links and opens the sheet before heavy view creation.
grep -Fq 'private val playableLinksCache = java.util.WeakHashMap' "$main"
grep -Fq 'private fun cachedPlayableLinks(item: JSONObject)' "$main"
grep -Fq 'val links = cachedPlayableLinks(item)' "$main"
grep -Fq 'Open the sheet first, then build the heavier quality/episode views' "$main"
grep -Fq 'box.post { addSeason(index + 1) }' "$main"

# Choice/confirm surfaces use the same player/downloader sheet language and compact height.
grep -Fq 'val contentChoicesHeight = dp((labels.size * 61 + 4).coerceAtLeast(64))' "$main"
grep -Fq 'background = bankGlassDrawable(26, 246, 82, true)' "$main"
grep -Fq 'setOnClickListener { dialog.dismiss() }' "$main"

# Regression chain remains intact.
bash verify_v7401_workflow_regression_hotfix.sh

echo V741_AUTH_PLAYER_MODAL_SPEED_POLISH_VERIFY_OK
