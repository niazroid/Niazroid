#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'
draw='app/src/main/res/drawable'

grep -Fq 'sourceMainUpdateTwentyFirstHotfixTag=BANKMOVIE-2.3-V740-20260912' "$source"
test -s "$draw/ic_auth_refresh.xml"
# V7.41.1 moved the exact movie-detail update arrow into the security challenge.
# Accept either the original V7.40 refresh asset or the newer exact migrated asset.
if grep -Fq 'R.drawable.ic_auth_refresh' "$auth"; then
  :
elif grep -Fq 'R.drawable.ic_status_update_arrow' "$auth" && test -s "$draw/ic_status_update_arrow.xml"; then
  :
else
  echo 'Security refresh icon implementation is missing' >&2
  exit 1
fi
! grep -Fq 'text = "↻"' "$auth"
grep -Fq 't("ثبت‌نام / ورود", "Register / Sign in")' "$main"
grep -Fq 'text = "قسمت بعدی آماده است"' "$player"
grep -Fq 'text = "▶  بله، پخش کن"' "$player"
grep -Fq 'UiPreferences.palette(this@PlayerActivity).onPrimary' "$player"
! grep -Fq '.setTitle("قسمت بعدی آماده است")' "$player"
grep -Fq 'val notificationAccent = notificationPalette.primary' "$main"
grep -Fq 'text = t("جدید", "NEW")' "$main"
grep -Fq 'if (::bottomNav.isInitialized) bottomNav.visibility = View.GONE' "$main"
grep -Fq 'showConfirmSheetV731(' "$main"

echo V740_PLAYER_AUTH_NOTIFICATION_POLISH_VERIFY_OK
