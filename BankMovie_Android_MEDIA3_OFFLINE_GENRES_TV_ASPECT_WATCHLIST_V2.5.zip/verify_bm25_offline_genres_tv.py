"""Guard the offline genre artwork, Watchlist split and TV display-mode state.
This is static only. A successful CI compile and device playback still matter.
"""
from pathlib import Path
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/ir/bankmoviee/app'
main=(src/'MainActivity.kt').read_text()
player=(src/'PlayerActivity.kt').read_text()
bridge=(src/'Media3PlaybackBridge.kt').read_text()
gradle=(root/'app/build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
keys=('action','adventure','animation','anime','biography','comedy','crime','documentary','drama','family','fantasy','history','horror','music','musical','mystery','noir','romance','school','sci_fi','science','short','sport','supernatural','thriller','war','western')
assert 'private fun genreImageResource' in main
assert 'setImageResource(genreImageResource(category.key))' in main
assert 'loadImage(genreImageUrl(' not in main
for key in keys:
    assert f'"{key}" -> R.drawable.bm_genre_{key}' in main, key
    image=root/f'app/src/main/res/drawable-nodpi/bm_genre_{key}.webp'
    assert image.is_file() and image.stat().st_size>20000, key
assert 'watchlistCategorySelection' in main and 'watchlistTabs(allItems)' in main
assert 'private fun watchlistIsSeries(' in main
assert 'versionName "2.5"' in gradle
assert '1.10.1' in gradle and 'ffmpeg-decoder' not in gradle.lower()
assert 'minSdk 23' in gradle and 'minSdk 26' not in gradle
assert 'private var requestedDisplayMode = "FIT"' in bridge
assert 'applyRequestedDisplayMode()' in bridge
assert 'videoView.videoSurfaceView?.requestLayout()' in bridge
assert 'box.addView(settingButton("حالت تصویر"' in player
assert 'player?.setDisplayMode(modes[modeIndex])' in player
print('BM25_OFFLINE_GENRES_TV_SOURCE_OK',len(keys),'genre images')
