using System.ComponentModel;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using LibVLCSharp.Shared;
using Microsoft.Win32;

namespace BankMovie.Windows;

public partial class PlayerWindow : Window
{
    private readonly PlaybackRequest _request;
    private readonly PlayerConfig _config;
    private readonly PlaybackHistoryStore _history = new();
    private readonly DispatcherTimer _uiTimer;
    private readonly DispatcherTimer _hideControlsTimer;
    private readonly DispatcherTimer _hudTimer;
    private MediaPlayer? _mediaPlayer;
    private Media? _media;
    private bool _draggingProgress;
    private bool _isFullscreen;
    private bool _restoredPosition;
    private bool _providedSubtitleAdded;
    private long _lastHistorySave;
    private string _lastTrackSignature = "";

    public PlayerWindow(PlaybackRequest request, PlayerConfig config)
    {
        _request = request;
        _config = config;
        InitializeComponent();

        MediaTitle.Text = string.IsNullOrWhiteSpace(request.Title) ? "BankMovie Player" : request.Title;
        VolumeSlider.Value = 90;

        _uiTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(450) };
        _uiTimer.Tick += UiTimer_Tick;
        _hideControlsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3.2) };
        _hideControlsTimer.Tick += (_, _) => HideControls();
        _hudTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(900) };
        _hudTimer.Tick += (_, _) => { _hudTimer.Stop(); CenterHud.Visibility = Visibility.Collapsed; };

        Loaded += PlayerWindow_Loaded;
    }

    private void PlayerWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (App.SharedLibVlc is null)
        {
            StatusText.Text = "موتور پخش در دسترس نیست";
            return;
        }

        _mediaPlayer = new MediaPlayer(App.SharedLibVlc)
        {
            EnableHardwareDecoding = _config.HardwareDecoding,
            NetworkCaching = _config.NetworkCachingMs,
            Volume = 90,
            EnableKeyInput = false,
            EnableMouseInput = false
        };
        VideoView.MediaPlayer = _mediaPlayer;
        _mediaPlayer.EncounteredError += (_, _) => Dispatcher.Invoke(() => StatusText.Text = "خطا در پخش؛ لینک یا اتصال را بررسی کن");
        _mediaPlayer.Buffering += (_, e2) => Dispatcher.Invoke(() => StatusText.Text = e2.Cache >= 100 ? "در حال پخش" : $"در حال بافر… {e2.Cache:0}%");
        _mediaPlayer.EndReached += (_, _) => Dispatcher.Invoke(() =>
        {
            _history.Clear(_request.Url);
            PlayPauseButton.Content = "▶";
            StatusText.Text = "پخش تمام شد";
        });

        _media = new Media(App.SharedLibVlc, new Uri(_request.Url));
        _media.AddOption($":network-caching={_config.NetworkCachingMs}");
        _media.AddOption(":file-caching=1000");
        _media.AddOption(":no-video-title-show");
        if (!string.IsNullOrWhiteSpace(_request.Referer)) _media.AddOption(":http-referrer=" + _request.Referer);
        if (!string.IsNullOrWhiteSpace(_request.UserAgent)) _media.AddOption(":http-user-agent=" + _request.UserAgent);
        if (!string.IsNullOrWhiteSpace(_request.CookieHeader)) _media.AddOption(":http-cookie=" + _request.CookieHeader);

        if (!_mediaPlayer.Play(_media)) StatusText.Text = "پخش شروع نشد";
        else StatusText.Text = "در حال اتصال به ویدیو…";

        _uiTimer.Start();
        ShowControls();
    }

    private void UiTimer_Tick(object? sender, EventArgs e)
    {
        var mp = _mediaPlayer;
        if (mp is null) return;

        var length = Math.Max(0, mp.Length);
        var time = Math.Max(0, mp.Time);
        if (!_draggingProgress)
        {
            ProgressSlider.Maximum = Math.Max(1, length);
            ProgressSlider.Value = Math.Min(time, ProgressSlider.Maximum);
        }
        CurrentTimeText.Text = FormatTime(time);
        DurationText.Text = FormatTime(length);
        PlayPauseButton.Content = mp.IsPlaying ? "❚❚" : "▶";
        MuteButton.Content = mp.Mute || mp.Volume == 0 ? "🔇" : "🔊";
        StatusText.Text = mp.IsPlaying ? "در حال پخش" : (mp.State == VLCState.Paused ? "توقف موقت" : StatusText.Text);

        TryRestorePosition(mp, length);
        TryAddProvidedSubtitle(mp);
        RefreshTracks(mp);
        SaveHistoryIfNeeded(mp, length, time);
    }

    private void TryRestorePosition(MediaPlayer mp, long length)
    {
        if (_restoredPosition || !_config.RememberPosition || length <= 0 || mp.Time < 0) return;
        _restoredPosition = true;
        var saved = _history.Get(_request.Url);
        if (saved > 15_000 && saved < length * 0.95)
        {
            mp.Time = saved;
            ShowHud("ادامه از", FormatTime(saved));
        }
    }

    private void TryAddProvidedSubtitle(MediaPlayer mp)
    {
        if (_providedSubtitleAdded || !_config.AutoLoadProvidedSubtitle || string.IsNullOrWhiteSpace(_request.SubtitleUrl)) return;
        if (mp.State is not (VLCState.Playing or VLCState.Paused)) return;
        _providedSubtitleAdded = true;
        try
        {
            if (mp.AddSlave(MediaSlaveType.Subtitle, _request.SubtitleUrl!, true))
                ShowHud("زیرنویس", "فعال شد");
        }
        catch
        {
            StatusText.Text = "زیرنویس خارجی بارگذاری نشد";
        }
    }

    private void RefreshTracks(MediaPlayer mp)
    {
        try
        {
            var subtitles = mp.SpuDescription ?? [];
            var audio = mp.AudioTrackDescription ?? [];
            var signature = string.Join('|', subtitles.Select(x => $"s{x.Id}:{x.Name}")) + "#" + string.Join('|', audio.Select(x => $"a{x.Id}:{x.Name}"));
            if (signature == _lastTrackSignature) return;
            _lastTrackSignature = signature;

            var selectedSpu = mp.Spu;
            var selectedAudio = mp.AudioTrack;

            SubtitleCombo.ItemsSource = subtitles.Select(x => new TrackChoice(x.Id, NormalizeTrackName(x.Name, x.Id == -1 ? "زیرنویس خاموش" : $"زیرنویس {x.Id}"))).ToList();
            AudioCombo.ItemsSource = audio.Select(x => new TrackChoice(x.Id, NormalizeTrackName(x.Name, $"صدا {x.Id}"))).ToList();
            SubtitleCombo.SelectedItem = ((IEnumerable<TrackChoice>)SubtitleCombo.ItemsSource).FirstOrDefault(x => x.Id == selectedSpu);
            AudioCombo.SelectedItem = ((IEnumerable<TrackChoice>)AudioCombo.ItemsSource).FirstOrDefault(x => x.Id == selectedAudio);
        }
        catch { }
    }

    private void SaveHistoryIfNeeded(MediaPlayer mp, long length, long time)
    {
        if (!_config.RememberPosition || length <= 0 || time <= 0) return;
        if (time - _lastHistorySave < 5_000) return;
        _lastHistorySave = time;
        if (time >= length * 0.95) _history.Clear(_request.Url);
        else _history.Set(_request.Url, time);
    }

    private void PlayPause_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        _mediaPlayer.SetPause(_mediaPlayer.IsPlaying);
        ShowControls();
    }

    private void SeekBack_Click(object sender, RoutedEventArgs e) => SeekBy(-10_000);
    private void SeekForward_Click(object sender, RoutedEventArgs e) => SeekBy(10_000);

    private void SeekBy(long delta)
    {
        if (_mediaPlayer is null) return;
        var target = Math.Clamp(_mediaPlayer.Time + delta, 0, Math.Max(0, _mediaPlayer.Length));
        _mediaPlayer.Time = target;
        ShowHud(delta < 0 ? "عقب" : "جلو", $"{Math.Abs(delta) / 1000} ثانیه");
        ShowControls();
    }

    private void Mute_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        _mediaPlayer.Mute = !_mediaPlayer.Mute;
        ShowHud("صدا", _mediaPlayer.Mute ? "خاموش" : $"{_mediaPlayer.Volume}%");
    }

    private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        VolumeText.Text = $"{(int)e.NewValue}%";
        if (_mediaPlayer is not null) _mediaPlayer.Volume = (int)e.NewValue;
    }

    private void AudioCombo_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (_mediaPlayer is null || AudioCombo.SelectedItem is not TrackChoice item) return;
        _mediaPlayer.SetAudioTrack(item.Id);
    }

    private void SubtitleCombo_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
    {
        if (_mediaPlayer is null || SubtitleCombo.SelectedItem is not TrackChoice item) return;
        _mediaPlayer.SetSpu(item.Id);
    }

    private void AddSubtitle_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        var dialog = new OpenFileDialog
        {
            Title = "انتخاب زیرنویس",
            Filter = "Subtitle files|*.srt;*.ass;*.ssa;*.vtt;*.sub;*.idx|All files|*.*"
        };
        if (dialog.ShowDialog(this) != true) return;
        try
        {
            var uri = new Uri(dialog.FileName).AbsoluteUri;
            if (_mediaPlayer.AddSlave(MediaSlaveType.Subtitle, uri, true))
            {
                _lastTrackSignature = "";
                ShowHud("زیرنویس", "اضافه شد");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("زیرنویس بارگذاری نشد.\n" + ex.Message, "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void ProgressSlider_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e) => _draggingProgress = true;
    private void ProgressSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_mediaPlayer is not null) _mediaPlayer.Time = (long)ProgressSlider.Value;
        _draggingProgress = false;
    }

    private void Fullscreen_Click(object sender, RoutedEventArgs e) => ToggleFullscreen();

    private void ToggleFullscreen()
    {
        _isFullscreen = !_isFullscreen;
        if (_isFullscreen)
        {
            WindowState = WindowState.Maximized;
            TopBar.Visibility = Visibility.Collapsed;
        }
        else
        {
            WindowState = WindowState.Normal;
            TopBar.Visibility = Visibility.Visible;
        }
        ShowControls();
    }

    private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (_mediaPlayer is null) return;
        switch (e.Key)
        {
            case Key.Space: PlayPause_Click(sender, e); e.Handled = true; break;
            case Key.Left: SeekBy(-10_000); e.Handled = true; break;
            case Key.Right: SeekBy(10_000); e.Handled = true; break;
            case Key.Up: VolumeSlider.Value = Math.Min(100, VolumeSlider.Value + 5); ShowHud("صدا", $"{(int)VolumeSlider.Value}%"); e.Handled = true; break;
            case Key.Down: VolumeSlider.Value = Math.Max(0, VolumeSlider.Value - 5); ShowHud("صدا", $"{(int)VolumeSlider.Value}%"); e.Handled = true; break;
            case Key.M: Mute_Click(sender, e); e.Handled = true; break;
            case Key.F: ToggleFullscreen(); e.Handled = true; break;
            case Key.Escape when _isFullscreen: ToggleFullscreen(); e.Handled = true; break;
        }
    }

    private void InteractionLayer_MouseMove(object sender, System.Windows.Input.MouseEventArgs e) => ShowControls();
    private void InteractionLayer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleFullscreen();
        else ShowControls();
    }

    private void ShowControls()
    {
        ControlsRoot.Opacity = 1;
        ControlsRoot.IsHitTestVisible = true;
        if (!_isFullscreen) TopBar.Visibility = Visibility.Visible;
        _hideControlsTimer.Stop();
        if (_mediaPlayer?.IsPlaying == true) _hideControlsTimer.Start();
    }

    private void HideControls()
    {
        _hideControlsTimer.Stop();
        if (!_isFullscreen && IsMouseOver) return;
        ControlsRoot.Opacity = 0;
        ControlsRoot.IsHitTestVisible = false;
        if (_isFullscreen) TopBar.Visibility = Visibility.Collapsed;
    }

    private void ShowHud(string title, string value)
    {
        HudTitle.Text = title;
        HudValue.Text = value;
        CenterHud.Visibility = Visibility.Visible;
        _hudTimer.Stop();
        _hudTimer.Start();
    }

    private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleMaximize();
        else if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void ToggleMaximize() => WindowState = WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        _uiTimer.Stop();
        _hideControlsTimer.Stop();
        if (_mediaPlayer is not null && _config.RememberPosition)
        {
            var length = _mediaPlayer.Length;
            var time = _mediaPlayer.Time;
            if (length > 0 && time > 10_000 && time < length * 0.95) _history.Set(_request.Url, time);
        }
        VideoView.MediaPlayer = null;
        _mediaPlayer?.Stop();
        _mediaPlayer?.Dispose();
        _media?.Dispose();
        _mediaPlayer = null;
        _media = null;
    }

    private static string FormatTime(long milliseconds)
    {
        var span = TimeSpan.FromMilliseconds(Math.Max(0, milliseconds));
        return span.TotalHours >= 1 ? span.ToString(@"hh\:mm\:ss") : span.ToString(@"mm\:ss");
    }

    private static string NormalizeTrackName(string? value, string fallback)
    {
        var text = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
        if (text.Equals("Disable", StringComparison.OrdinalIgnoreCase)) return "زیرنویس خاموش";
        return text;
    }
}
