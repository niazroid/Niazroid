const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cleanUrl = (v='') => /^https?:\/\//i.test(String(v)) ? String(v) : '';
const fmtBytes = n => !n ? '—' : n > 1073741824 ? `${(n/1073741824).toFixed(1)} GB` : n > 1048576 ? `${(n/1048576).toFixed(1)} MB` : `${(n/1024).toFixed(0)} KB`;
const pct = (a,b) => b > 0 ? Math.min(100, Math.round(a/b*100)) : 0;
const sleep = ms => new Promise(r => setTimeout(r,ms));


const ICONS = {
  download:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" fill="currentColor"/><path d="M12.75 7C12.75 6.58579 12.4142 6.25 12 6.25C11.5858 6.25 11.25 6.58579 11.25 7L11.25 12.1893L9.53033 10.4697C9.23744 10.1768 8.76256 10.1768 8.46967 10.4697C8.17678 10.7626 8.17678 11.2374 8.46967 11.5303L11.4697 14.5303C11.6103 14.671 11.8011 14.75 12 14.75C12.1989 14.75 12.3897 14.671 12.5303 14.5303L15.5303 11.5303C15.8232 11.2374 15.8232 10.7626 15.5303 10.4697C15.2374 10.1768 14.7626 10.1768 14.4697 10.4697L12.75 12.1893V7Z" fill="currentColor"/><path d="M8 16.25C7.58579 16.25 7.25 16.5858 7.25 17C7.25 17.4142 7.58579 17.75 8 17.75H16C16.4142 17.75 16.75 17.4142 16.75 17C16.75 16.5858 16.4142 16.25 16 16.25H8Z" fill="currentColor"/></svg>`,
  filter:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path fill-rule="evenodd" clip-rule="evenodd" d="M5 3H19L8.81562 13.1844C8.65593 12.7689 8.39992 12.4122 8.03751 12.0976C7.80967 11.8998 7.49146 11.7206 6.85504 11.3624L3.94202 9.72255C2.99347 9.18858 2.5192 8.9216 2.2596 8.49142C2 8.06124 2 7.54232 2 6.50448V5.81466C2 4.48782 2 3.8244 2.43934 3.4122C2.87868 3 3.58579 3 5 3Z" fill="currentColor"/><path opacity=".5" d="M21.9998 6.50448V5.81466C21.9998 4.48782 21.9998 3.8244 21.5605 3.4122C21.1211 3 20.414 3 18.9998 3L8.81543 13.1844C8.86481 13.3129 8.90498 13.447 8.93625 13.5872C8.99981 13.8722 8.99981 14.2058 8.99981 14.8729L8.99981 17.5424C8.99981 18.452 8.99981 18.9067 9.25173 19.2613C9.50366 19.6158 9.95109 19.7907 10.846 20.1406C12.7246 20.875 13.6639 21.2422 14.3319 20.8244C14.9998 20.4066 14.9998 19.4519 14.9998 17.5424V14.8729C14.9998 14.2058 14.9998 13.8722 15.0634 13.5872C15.1957 12.9935 15.4878 12.5095 15.9623 12.0976C16.1901 11.8998 16.5083 11.7206 17.1448 11.3624L20.0578 9.72255C21.0063 9.18858 21.4806 8.9216 21.7402 8.49142C21.9998 8.06124 21.9998 7.54232 21.9998 6.50448Z" fill="currentColor"/></svg>`,
  play:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity=".4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>`,
  bookmark:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M14.5 9.89996H12.75V8.20996C12.75 7.79996 12.41 7.45996 12 7.45996C11.59 7.45996 11.25 7.79996 11.25 8.20996V9.89996H9.5C9.09 9.89996 8.75 10.24 8.75 10.65C8.75 11.06 9.09 11.4 9.5 11.4H11.25V13.21C11.25 13.62 11.59 13.96 12 13.96C12.41 13.96 12.75 13.62 12.75 13.21V11.4H14.5C14.91 11.4 15.25 11.06 15.25 10.65C15.25 10.24 14.91 9.89996 14.5 9.89996Z" fill="currentColor"/></svg>`,
  settings:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".34" d="M12 15C13.6569 15 15 13.6569 15 12C15 10.3431 13.6569 9 12 9C10.3431 9 9 10.3431 9 12C9 13.6569 10.3431 15 12 15Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M2 12.8799V11.1199C2 10.0799 2.85 9.21994 3.9 9.21994C5.71 9.21994 6.45 7.93994 5.54 6.36994C5.02 5.46994 5.33 4.29994 6.24 3.77994L7.97 2.78994C8.76 2.31994 9.78 2.59994 10.25 3.38994L10.36 3.57994C11.26 5.14994 12.74 5.14994 13.65 3.57994L13.76 3.38994C14.23 2.59994 15.25 2.31994 16.04 2.78994L17.77 3.77994C18.68 4.29994 18.99 5.46994 18.47 6.36994C17.56 7.93994 18.3 9.21994 20.11 9.21994C21.15 9.21994 22.01 10.0699 22.01 11.1199V12.8799C22.01 13.9199 21.16 14.7799 20.11 14.7799C18.3 14.7799 17.56 16.0599 18.47 17.6299C18.99 18.5399 18.68 19.6999 17.77 20.2199L16.04 21.2099C15.25 21.6799 14.23 21.3999 13.76 20.6099L13.65 20.4199C12.75 18.8499 11.27 18.8499 10.36 20.4199L10.25 20.6099C9.78 21.3999 8.76 21.6799 7.97 21.2099L6.24 20.2199C5.33 19.6999 5.02 18.5299 5.54 17.6299C6.45 16.0599 5.71 14.7799 3.9 14.7799C2.85 14.7799 2 13.9199 2 12.8799Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  bell:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".4" d="M20.3992 16.3298C20.1192 17.0798 19.5292 17.6498 18.7592 17.9098C17.6792 18.2698 16.5692 18.5398 15.4492 18.7298C15.3392 18.7498 15.2292 18.7698 15.1192 18.7798C14.9392 18.8098 14.7592 18.8298 14.5792 18.8498C14.3592 18.8798 14.1292 18.8998 13.8992 18.9198C13.2692 18.9698 12.6492 18.9998 12.0192 18.9998C11.3792 18.9998 10.7392 18.9698 10.1092 18.9098C9.83923 18.8898 9.57923 18.8598 9.31923 18.8198C9.16923 18.7998 9.01923 18.7798 8.87923 18.7598C8.76923 18.7398 8.65923 18.7298 8.54923 18.7098C7.43923 18.5298 6.33923 18.2598 5.26923 17.8998C4.46923 17.6298 3.85923 17.0598 3.58923 16.3298C3.31923 15.6098 3.41923 14.7698 3.84923 14.0498L4.97923 12.1698C5.21923 11.7598 5.43923 10.9698 5.43923 10.4898V8.6298C5.43923 4.9998 8.38923 2.0498 12.0192 2.0498C15.6392 2.0498 18.5892 4.9998 18.5892 8.6298V10.4898C18.5892 10.9698 18.8092 11.7598 19.0592 12.1698L20.1892 14.0498C20.5992 14.7498 20.6792 15.5698 20.3992 16.3298Z" fill="currentColor"/><path d="M12.0002 10.7601C11.5802 10.7601 11.2402 10.4201 11.2402 10.0001V6.90014C11.2402 6.48014 11.5802 6.14014 12.0002 6.14014C12.4202 6.14014 12.7602 6.48014 12.7602 6.90014V10.0001C12.7502 10.4201 12.4102 10.7601 12.0002 10.7601Z" fill="currentColor"/><path d="M14.8297 20.01C14.4097 21.17 13.2997 22 11.9997 22C11.2097 22 10.4297 21.68 9.87969 21.11C9.55969 20.81 9.31969 20.41 9.17969 20C9.30969 20.02 9.43969 20.03 9.57969 20.05C9.80969 20.08 10.0497 20.11 10.2897 20.13C10.8597 20.18 11.4397 20.21 12.0197 20.21C12.5897 20.21 13.1597 20.18 13.7197 20.13C13.9297 20.11 14.1397 20.1 14.3397 20.07C14.4997 20.05 14.6597 20.03 14.8297 20.01Z" fill="currentColor"/></svg>`,
  search:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity=".4" d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  user:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><circle opacity=".5" cx="12" cy="9" r="3" stroke="currentColor" stroke-width="1.5"/><circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="1.5"/><path opacity=".5" d="M17.9691 20C17.81 17.1085 16.9247 15 11.9999 15C7.07521 15 6.18991 17.1085 6.03076 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>`,
  back:`<svg viewBox="0 0 100 100" aria-hidden="true"><path fill="currentColor" d="M33.934 54.458l30.822 27.938c.383.348.864.519 1.344.519.545 0 1.087-.222 1.482-.657.741-.818.68-2.083-.139-2.824L37.801 52.564 64.67 22.921c.742-.818.68-2.083-.139-2.824-.817-.742-2.082-.679-2.824.139L33.768 51.059c-.439.485-.59 1.126-.475 1.723-.059.608.153 1.235.641 1.676z"/></svg>`,
  refresh:`<svg viewBox="0 0 20 20" aria-hidden="true"><path fill="currentColor" d="M19.295 12c.389-.003.705.315.705.709v3.204c0 .392-.313.709-.7.709s-.7-.317-.7-.709l.001-1.125C16.778 17.844 13.398 20 9.756 20c-4.409 0-8.106-2.721-9.709-6.915a.708.708 0 0 1 1.305-.512c1.4 3.662 4.589 6.009 8.404 6.009 3.371 0 6.52-2.181 7.987-5.153l-1.472.01a.709.709 0 0 1-.009-1.418L19.295 12zM10.244 0c4.409 0 8.106 2.721 9.709 6.915a.708.708 0 0 1-1.305.512c-1.4-3.662-4.589-6.009-8.404-6.009-3.371 0-6.52 2.181-7.987 5.153l1.472-.01a.709.709 0 0 1 .009 1.418L.705 8A.708.708 0 0 1 0 7.291V4.087c0-.392.313-.709.7-.709s.7.317.7.709l-.001 1.125C3.222 2.156 6.602 0 10.244 0z"/></svg>`,
  imdb:`<svg viewBox="0 0 512 512" aria-label="IMDb"><rect width="512" height="512" rx="15%" fill="#f5c518"/><path fill="#111" d="M104 328V184H64v144zM189 184l-9 67-5-36-5-31h-50v144h34v-95l14 95h25l13-97v97h34V184zM256 328V184h62c15 0 26 11 26 25v94c0 14-11 25-26 25zm47-118l-9-1v94c5 0 9-1 10-3 2-2 2-8 2-18v-56-12l-3-4zM419 220h3c14 0 26 11 26 25v58c0 14-12 25-26 25h-3c-8 0-16-4-21-11l-2 9h-36V184h38v46c5-6 13-10 21-10zm-8 70v-34l-1-11c-1-2-4-3-6-3s-5 1-6 3v57c1 2 4 3 6 3s6-1 6-3l1-12z"/></svg>`,
  mic:`<svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path opacity=".5" fill-rule="evenodd" clip-rule="evenodd" d="M12.0003 2C8.55914 2 5.76953 4.81123 5.76953 8.27907V12.9302C5.76953 16.3981 8.55914 19.2093 12.0003 19.2093C15.4415 19.2093 18.2311 16.3981 18.2311 12.9302V8.27907C18.2311 4.81124 15.4415 2 12.0003 2Z" fill="currentColor"/><path fill-rule="evenodd" clip-rule="evenodd" d="M3.69231 10.3721C4.07466 10.3721 4.38462 10.6844 4.38462 11.0697V12.9302C4.38462 17.1687 7.79414 20.6046 12 20.6046C16.2059 20.6046 19.6154 17.1687 19.6154 12.9302V11.0697C19.6154 10.6844 19.9253 10.3721 20.3077 10.3721C20.69 10.3721 21 10.6844 21 11.0697V12.9302C21 17.9393 16.9706 22 12 22C7.02944 22 3 17.9393 3 12.9302V11.0697C3 10.6844 3.30996 10.3721 3.69231 10.3721Z" fill="currentColor"/></svg>`,
  subtitle:`<svg viewBox="0 0 600 600" aria-hidden="true"><path fill="currentColor" d="M171.557 42.17c-24.469-1.31-49.635 4.99-71.219 18.863C31.27 105.429 0 199.483 0 301.414c0 101.932 31.27 195.983 100.338 240.379 34.534 22.198 78.24 25.005 113.586 8.279 35.346-16.726 62.556-48.726 82.205-90.08a40 40 0 0 0-18.963-53.295 40 40 0 0 0-53.295 18.963c-14.014 29.495-31.214 45.972-44.166 52.101-12.952 6.129-21.434 6.171-36.111-3.264C114.238 455.629 80 384.458 80 301.414c0-83.044 34.238-154.216 63.594-173.086 14.677-9.435 23.159-9.391 36.111-3.262 12.952 6.129 30.152 22.604 44.166 52.1a40 40 0 0 0 53.295 18.963 40 40 0 0 0 18.963-53.295c-19.649-41.354-46.859-73.354-82.205-90.08-13.255-6.272-27.686-9.798-42.367-10.584z"/><path fill="currentColor" d="M471.557 40.756c-24.469-1.31-49.635 4.99-71.219 18.863C331.27 104.015 300 198.069 300 300s31.27 195.985 100.338 240.381c34.534 22.198 78.24 25.005 113.586 8.279 35.346-16.726 62.556-48.726 82.205-90.08a40 40 0 0 0-18.963-53.297 40 40 0 0 0-53.295 18.965c-14.014 29.495-31.214 45.971-44.166 52.1-12.952 6.129-21.434 6.171-36.111-3.264C414.238 454.215 380 383.044 380 300s34.238-154.215 63.594-173.084c14.677-9.435 23.159-9.393 36.111-3.264 12.952 6.129 30.152 22.604 44.166 52.1a40 40 0 0 0 53.295 18.965 40 40 0 0 0 18.963-53.297c-19.649-41.354-46.859-73.354-82.205-90.08-13.255-6.272-27.686-9.798-42.367-10.584z"/></svg>`
};
function icon(name,cls=''){return `<span class="svg-icon ${cls}">${ICONS[name]||''}</span>`}
function hydrateStaticIcons(root=document){$$('[data-svg-icon]',root).forEach(el=>{const name=el.dataset.svgIcon;if(ICONS[name])el.innerHTML=ICONS[name]})}
function searchLoaderHtml(text='در حال جستجو'){return `<div class="search-loader-wrap"><div id="wifi-loader"><svg class="circle-outer" viewBox="0 0 86 86"><circle class="back" cx="43" cy="43" r="40"></circle><circle class="front" cx="43" cy="43" r="40"></circle></svg><svg class="circle-middle" viewBox="0 0 60 60"><circle class="back" cx="30" cy="30" r="27"></circle><circle class="front" cx="30" cy="30" r="27"></circle></svg><svg class="circle-inner" viewBox="0 0 34 34"><circle class="back" cx="17" cy="17" r="14"></circle><circle class="front" cx="17" cy="17" r="14"></circle></svg><div class="text" data-text="${esc(text)}"></div></div></div>`}

const mockItems = Array.from({length:12},(_,i)=>({
  archive:1,id:`demo-${i+1}`,type:i%3===0?'series':'movie',title:`Midnight ${i+1}`,title_fa:`عنوان نمایشی ${i+1}`,
  year:2026-(i%4),rating:(8.7-i*.08).toFixed(1),poster:'',backdrop:'',description:'نسخه مرورگر فقط برای پیش‌نمایش رابط کاربری است.'
}));
const mockBridge = () => ({
  bootstrap: async()=>({config:{_online:false,active_domain:'https://bankmovie.top',features:{},desktop:{enabled:true,features:{}},app_archive_policy:{},home:{archive1_sections:['updated_movies','updated_series']}},settings:{downloadDir:'Downloads',preferredArchive:1,preferredPlayer:'auto'},players:[],hasToken:false,version:'preview'}),
  content: async(action,p={})=> action==='boot'?{status:'success',sliders:mockItems.slice(0,4),collections:[],archives:[1,2,3,4,5]}:action==='detail'?{status:'success',item:{...mockItems[0],description:'این پیش‌نمایش آفلاین است. در Electron داده واقعی از bankmovie.top خوانده می‌شود.',genres:['درام','معمایی'],play:{links:[{quality:'1080P',display_label:'1080P • سافت‌ساب',url:'',is_playable:false,is_download:false}]},related:mockItems.slice(1,7)}}:{status:'success',items:mockItems,page:1,has_more:false},
  user:async(a)=>a==='config'?{success:true,features:{},vip:{plans:[]}}:{success:false,message:'در حالت مرورگر حساب کاربری غیرفعال است'},
  getSettings:async()=>({downloadDir:'Downloads',preferredArchive:1,preferredPlayer:'auto'}), setSettings:async x=>x, chooseDownloadDir:async()=>'Downloads', download:async()=>({id:'demo'}), downloadAction:async()=>true, getPlayers:async()=>[], playExternal:async()=>{throw new Error('پلیر خارجی فقط در نسخه ویندوز فعال است')}, openExternal:async()=>true, showItem:async()=>true, onDownload:()=>{}, logoutLocal:async()=>true,
  window:{minimize(){},maximize(){},close(){}}
});
const bridge = window.bankmovie || mockBridge();

const state = {
  config:null, settings:null, appVersion:'', user:null, stats:null, userConfig:null,
  archive:1, currentDetail:null, watchlist:[], downloads:new Map(), party:null, partyTimer:null, players:[],
  lastView:'home', homeCache:{}, searchPage:1, heroIndex:0, heroTimer:null, detailSeason:null, detailEpisode:null, visibleSources:[]
};

const SECTION_LABELS = {
  updated_movies:'جدیدترین فیلم‌ها',updated_series:'سریال‌های آپدیت‌شده',new_movies:'فیلم‌های جدید',new_series:'سریال‌های جدید',
  korean_series:'سریال‌های کره‌ای',dubbed:'دوبله فارسی',dubbed_fa:'دوبله فارسی',chinese_series:'سریال‌های چینی',top_2026:'برترین‌های ۲۰۲۶',top_movies:'Top 250 فیلم',top_series:'Top 250 سریال',anime:'انیمه',turkish:'فیلم و سریال ترکی',collections:'کالکشن‌ها',
  animation:'انیمیشن و انیمه',animations:'انیمیشن',action:'اکشن',drama:'درام',updated_animations:'انیمیشن‌های به‌روز شده',updated_anime:'انیمه‌های به‌روز شده',dubbed_movies:'فیلم‌های دوبله',subtitled_movies:'فیلم‌های زیرنویس',dubbed_series:'سریال‌های دوبله',subtitled_series:'سریال‌های زیرنویس',mini_series:'مینی‌سریال',turkish_series:'سریال‌های ترکی'
};
const ARCHIVE_NAMES={1:'آرشیو ۱',2:'آرشیو ۲',3:'آرشیو ۳',4:'آرشیو ۴',5:'آرشیو ۵'};
const ARCHIVE_DESCRIPTIONS={
  1:'هاردساب، دوبله، محتوای آسیایی و آپدیت سریع',
  2:'آرشیو بانک‌مووی؛ فیلم، سریال، دوبله و ژانرهای منتخب',
  3:'فیلم و سریال با تفکیک دوبله، زیرنویس و محتوای ویژه',
  4:'فیلم، سریال، انیمه و نسخه‌های دوبله/زیرنویس',
  5:'فیلم و سریال جدید، محتوای ترکی و انیمیشن'
};
const ARCHIVE_FALLBACK_SECTIONS={
  1:['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
  2:['updated_movies','updated_series','dubbed','animation','action','drama','collections'],
  3:['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','dubbed_series','subtitled_series','mini_series','korean_series','turkish_series','collections'],
  4:['new_movies','new_series','updated_animations','updated_anime','dubbed_movies','subtitled_movies','collections'],
  5:['new_movies','new_series','turkish','animation']
};

function toast(message,type=''){
  const el=$('#toast'); el.textContent=message; el.className=`toast show ${type}`; clearTimeout(toast.t); toast.t=setTimeout(()=>el.className='toast',2600);
}
function setLoading(text='در حال دریافت اطلاعات…'){$('#view').innerHTML=`<div class="loading-screen"><div class="spinner"></div><p>${esc(text)}</p></div>`}
function feature(name, fallback=true){
  const desktop=state.config?.desktop?.features || {}; if(Object.prototype.hasOwnProperty.call(desktop,name)) return !!desktop[name];
  const common=state.config?.features || {}; if(Object.prototype.hasOwnProperty.call(common,name)) return !!common[name]; return fallback;
}
function archivePolicy(no){
  const key=`archive${Number(no)}`; const p=state.config?.app_archive_policy?.[key] || state.config?.archive_policy?.[key] || {};
  const d=state.config?.desktop?.archives?.[key] || {}; return {...p,...d};
}
function enabledArchives(){
  return [1,2,3,4,5].filter(n=>{const p=archivePolicy(n);return p.hidden!==true && p.enabled!==false});
}
function setActiveNav(view){$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));if(view!=='home'&&state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}state.lastView=view}
function img(url,alt='',cls=''){return cleanUrl(url)?`<img class="${cls}" src="${esc(url)}" alt="${esc(alt)}" loading="lazy" onerror="this.style.display='none'">`:''}
function itemTitle(it){return it?.title_fa || it?.title || 'بدون عنوان'}
function itemId(it){return it?.target_id || it?.detail_id || it?.id || it?.slug || it?.imdb_code || ''}
function card(it){
  const poster=cleanUrl(it.poster||it.image||''); const type=(it.type==='series'?'سریال':'فیلم');
  return `<article class="media-card" data-card='${encodeURIComponent(JSON.stringify({archive:it.archive||state.archive,id:itemId(it),type:it.type||'movie',title:it.title||'',title_fa:it.title_fa||'',poster:poster,year:it.year||'',rating:it.rating||'',source:it.source||'',imdb_code:it.imdb_code||''}))}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div style="height:100%;display:grid;place-items:center;color:#444;font-size:36px">BM</div>`}<span class="card-badge">${esc(it.rating||type)}</span></div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(it.year||'')} · ${type}</span><span>${it.rating?'★ '+esc(it.rating):''}</span></small></div>
  </article>`;
}
function bindCards(root=document){
  $$('[data-card]',root).forEach(el=>el.addEventListener('click',()=>{try{openDetail(JSON.parse(decodeURIComponent(el.dataset.card)))}catch(e){toast(e.message,'error')}}));
}
function sectionLabel(section){return SECTION_LABELS[section]||String(section||'').replaceAll('_',' ')}
function sectionHtml(title,items,archive,section){
  if(!items?.length)return '';
  return `<section class="section archive-section" data-home-section="${esc(section)}"><div class="section-head"><div><h2>${esc(title)}</h2><small>${esc(ARCHIVE_NAMES[archive]||'')} • ${esc(ARCHIVE_DESCRIPTIONS[archive]||'')}</small></div><button class="link-btn" data-browse-section="${esc(section)}" data-archive="${archive}">مشاهده همه ‹</button></div><div class="rail">${items.map(card).join('')}</div></section>`;
}
function sectionPolicy(archive,section){
  const key=`archive${archive}`;return state.config?.home_section_policy?.[key]?.[section]||{};
}
function homeSectionsFor(archive){
  const key=`archive${archive}_sections`; const configured=state.config?.home?.[key];
  const raw=(Array.isArray(configured)&&configured.length)?configured:(ARCHIVE_FALLBACK_SECTIONS[archive]||[]);
  const aliases={dubbed_fa:'dubbed',animations:'animation'};
  const out=[];
  for(const value of raw){const sec=aliases[String(value)]||String(value);if(!sec||out.includes(sec))continue;const p=sectionPolicy(archive,sec);if(p.enabled===false||p.access_scope==='disabled')continue;out.push(sec)}
  return out;
}
function archiveSwitcherHtml(active=state.archive,context='home'){
  const archives=enabledArchives();
  return `<div class="archive-hub ${context==='search'?'search-archive-hub':''}"><div class="archive-hub-copy"><strong>${esc(ARCHIVE_NAMES[active])}</strong><span>${esc(ARCHIVE_DESCRIPTIONS[active]||'')}</span></div><div class="archive-tabs">${archives.map(n=>`<button class="archive-tab ${n===active?'active':''}" data-archive-switch="${n}" data-context="${context}"><b>${esc(ARCHIVE_NAMES[n])}</b></button>`).join('')}</div></div>`;
}
function archiveCategoryNavHtml(archive){
  const sections=homeSectionsFor(archive).filter(x=>x!=='collections');
  return sections.length?`<div class="archive-category-strip">${sections.map(sec=>`<button data-home-category="${esc(sec)}" data-archive="${archive}">${esc(sectionLabel(sec))}</button>`).join('')}</div>`:'';
}
async function switchArchive(next,context='home'){
  const n=Number(next);if(!enabledArchives().includes(n))return;state.archive=n;
  const sel=$('#archiveSelect');if(sel)sel.value=String(n);await bridge.setSettings({preferredArchive:n});updateSearchPlaceholder();
  if(context==='search'||state.lastView==='search')return showSearch($('#searchQuery')?.value||'');
  if(state.lastView==='movies'||state.lastView==='series')return showBrowse(state.lastView);
  return showHome(false);
}
function bindArchiveSwitcher(root=document){$$('[data-archive-switch]',root).forEach(b=>b.onclick=()=>switchArchive(b.dataset.archiveSwitch,b.dataset.context||'home'))}
function updateSearchPlaceholder(){const q=$('#quickSearch');if(q)q.placeholder=`جستجو در ${ARCHIVE_NAMES[state.archive]}…`}


async function init(){
  hydrateStaticIcons();
  bindWindowButtons();
  try{
    const boot=await bridge.bootstrap(); state.config=boot.config||{}; state.settings=boot.settings||{}; state.players=boot.players||[]; state.appVersion=boot.version||''; state.archive=Number(state.settings.preferredArchive||enabledArchives()[0]||1);
    setupArchiveSelect(); applyRemoteNotice(); updateConnectionBadge(); bridge.onDownload(onDownloadUpdate);
    if(boot.hasToken) await refreshMe(false); await loadUserConfig(); updateProfile(); bindGlobalUI(); await showHome();
  }catch(e){setLoading('خطا در راه‌اندازی');toast(e.message||'خطای راه‌اندازی','error')}
}
function bindWindowButtons(){
  $$('[data-win]').forEach(b=>b.addEventListener('click',()=>{const a=b.dataset.win;if(a==='min')bridge.window.minimize();if(a==='max')bridge.window.maximize();if(a==='close')bridge.window.close()}));
}
function updateConnectionBadge(){const e=$('#connectionBadge');const online=state.config?._online!==false;e.textContent=online?'متصل به bankmovie.top':'حالت fallback';e.className=online?'online':'offline'}
function setupArchiveSelect(){
  const s=$('#archiveSelect');s.innerHTML=enabledArchives().map(n=>`<option value="${n}" ${n===state.archive?'selected':''}>${ARCHIVE_NAMES[n]}</option>`).join('');
  updateSearchPlaceholder();
  s.onchange=()=>switchArchive(Number(s.value),state.lastView==='search'?'search':'home');
}
function applyRemoteNotice(){
  const n=state.config?.desktop?.notice || state.config?.notice || {}; const el=$('#notice');
  if(n.enabled && (n.message||n.title)){el.innerHTML=`<strong>${esc(n.title||'اطلاعیه')}</strong> ${esc(n.message||'')}`;el.classList.remove('hidden')} else el.classList.add('hidden');
}
async function loadUserConfig(){try{state.userConfig=await bridge.user('config',{},'POST')}catch{state.userConfig={features:{}}}}
async function refreshMe(noisy=true){
  try{const r=await bridge.user('me',{},'POST');if(r?.success){state.user=r.user;state.stats=r.stats||null}else state.user=null}catch(e){state.user=null;if(noisy)toast(e.message,'error')}updateProfile();return state.user;
}
function updateProfile(){
  const name=$('#profileName'),hint=$('#profileHint'),av=$('#profileAvatar');
  if(state.user){name.textContent=state.user.full_name||state.user.username||'کاربر';hint.textContent=state.user.is_vip?'VIP فعال':(state.user.email||'حساب کاربری');av.innerHTML=cleanUrl(state.user.avatar)?img(state.user.avatar,'avatar'):esc((state.user.username||'BM').slice(0,2).toUpperCase())}
  else{name.textContent='حساب کاربری';hint.textContent='ورود / ثبت‌نام';av.innerHTML=ICONS.user}
}
function bindGlobalUI(){
  $('#nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(!b)return;route(b.dataset.view)});
  $('#profileNav').onclick=()=>showProfile();
  $('#refreshBtn').onclick=()=>route(state.lastView,true);
  $('#quickSearch').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.currentTarget.value.trim())showSearch(e.currentTarget.value.trim())});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#quickSearch').focus()}});
  $('#modal').addEventListener('click',e=>{if(e.target.matches('[data-close-modal]'))closeModal()});
}
async function route(view,force=false){
  setActiveNav(view); if(state.partyTimer&&view!=='party'){clearInterval(state.partyTimer);state.partyTimer=null}
  if(view==='home')return showHome(force);if(view==='movies'||view==='series')return showBrowse(view);if(view==='search')return showSearch('');
  if(view==='watchlist')return showWatchlist();if(view==='downloads')return showDownloads();if(view==='notifications')return showNotifications();if(view==='party')return showParty();if(view==='settings')return showSettings();
}

async function loadHomeSection(archive,section){
  if(section==='collections'){
    try{const r=await bridge.content('collections',{archive,page:1,limit:14});return {a:archive,sec:section,items:r.items||[]}}catch{return {a:archive,sec:section,items:[]}}
  }
  try{const r=await bridge.content('section',{archive,section,page:1,limit:14});return {a:archive,sec:section,items:r.items||[]}}catch{return {a:archive,sec:section,items:[]}}
}
async function showHome(force=false){
  setActiveNav('home'); setLoading(`در حال بارگذاری ${ARCHIVE_NAMES[state.archive]}…`);
  try{
    const cacheKey=String(state.archive);
    if(force)delete state.homeCache[cacheKey];
    if(!state.homeCache[cacheKey]){
      const boot=await bridge.content('boot',{limit:18});
      const sections=homeSectionsFor(state.archive);
      const rails=(await Promise.all(sections.map(sec=>loadHomeSection(state.archive,sec)))).filter(r=>r.items?.length);
      state.homeCache[cacheKey]={boot,rails,archive:state.archive,sections};
    }
    renderHome(state.homeCache[cacheKey]);
  }catch(e){$('#view').innerHTML=`<div class="empty">${esc(e.message)}</div>`;toast(e.message,'error')}
}
function sliderMediaItem(it){
  const out={...it,archive:Number(it?.target_archive||it?.archive||2)||2,id:it?.target_id||'',type:it?.target_type||it?.type||'movie',poster:it?.poster||it?.image||''};
  const raw=String(it?.link_abs||it?.link||'').trim();
  if(raw){
    try{
      const u=new URL(raw,'https://bankmovie.top');
      const arc=Number(u.searchParams.get('arc')||0);if(arc>=1&&arc<=5)out.archive=arc;
      const type=u.searchParams.get('type');if(type)out.type=/series|serial|tv/i.test(type)?'series':'movie';
      const qid=u.searchParams.get('slug')||u.searchParams.get('imdb');if(qid)out.id=qid;
      const p=decodeURIComponent(u.pathname||'');
      const am=p.match(/\/movie\/arc([1-5])-([^/?#]+)/i);if(am){out.archive=Number(am[1]);out.id=am[2]}
      else {const pm=p.match(/\/movie\/([^/?#]+)/i);if(pm){out.archive=2;out.id=pm[1]}}
    }catch{}
  }
  if(!out.id)out.id=it?.id||'';
  return out;
}
function heroSlide(hero,i){
  const bg=cleanUrl(hero.backdrop||hero.background||hero.image||hero.poster||'');
  const rating=hero.rating?`<span class="hero-rating">${icon('imdb','imdb-mark')}<b>${esc(hero.rating)}</b></span>`:'';
  return `<div class="hero-slide ${i===0?'active':''}" data-hero-slide="${i}">${bg?`<div class="hero-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="hero-center" dir="rtl"><h1>${esc(itemTitle(hero))}</h1>${hero.subtitle_fa?`<p>${esc(hero.subtitle_fa)}</p>`:(hero.title&&hero.title!==itemTitle(hero)?`<p>${esc(hero.title)}</p>`:'')}<button class="btn hero-watch" data-hero-open="${i}">${icon('play')}<span>مشاهده</span></button></div>${rating}</div>`;
}
function activateHero(index,sliders){
  if(!sliders.length)return;state.heroIndex=(index+sliders.length)%sliders.length;
  $$('[data-hero-slide]').forEach((el,i)=>el.classList.toggle('active',i===state.heroIndex));
  $$('[data-hero-dot]').forEach((el,i)=>el.classList.toggle('active',i===state.heroIndex));
}
function bindHeroSlider(sliders){
  if(state.heroTimer){clearInterval(state.heroTimer);state.heroTimer=null}state.heroIndex=0;activateHero(0,sliders);
  $$('[data-hero-open]').forEach(b=>b.onclick=async()=>{
    const raw=sliders[Number(b.dataset.heroOpen)];const target=sliderMediaItem(raw);
    if(target.id)return openDetail(target);
    const link=cleanUrl(raw?.link_abs||raw?.link||'');
    if(link)return bridge.openExternal(link);
    toast('برای این اسلاید مقصدی ثبت نشده است','error');
  });
  $$('[data-hero-dot]').forEach(b=>b.onclick=()=>activateHero(Number(b.dataset.heroDot),sliders));
  const prev=$('#heroPrev'),next=$('#heroNext');if(prev)prev.onclick=()=>activateHero(state.heroIndex-1,sliders);if(next)next.onclick=()=>activateHero(state.heroIndex+1,sliders);
  if(sliders.length>1)state.heroTimer=setInterval(()=>{if(state.lastView==='home')activateHero(state.heroIndex+1,sliders)},6500);
}
function renderHome({boot,rails,archive,sections}){
  const active=Number(archive||state.archive);
  const sliders=(Array.isArray(boot?.sliders)?boot.sliders:[]).slice().sort((a,b)=>Number(a?.order??a?.slide_order??0)-Number(b?.order??b?.slide_order??0)).slice(0,12);
  const hero=sliders.length?`<section class="hero site-hero" dir="ltr"><div class="hero-stage">${sliders.map(heroSlide).join('')}</div>${sliders.length>1?`<button class="hero-arrow prev" id="heroPrev" aria-label="اسلاید قبلی">${icon('back')}</button><button class="hero-arrow next" id="heroNext" aria-label="اسلاید بعدی">${icon('back')}</button><div class="hero-dots">${sliders.map((_,i)=>`<button class="hero-dot ${i===0?'active':''}" data-hero-dot="${i}"></button>`).join('')}</div>`:''}</section>`:'';
  $('#view').innerHTML=`${hero}${archiveSwitcherHtml(active,'home')}${archiveCategoryNavHtml(active)}<div class="archive-only-note"><b>${esc(ARCHIVE_NAMES[active])}</b><span>در این صفحه فقط محتوای همین آرشیو بارگذاری شده است.</span></div>${rails.map(r=>sectionHtml(sectionLabel(r.sec),r.items,active,r.sec)).join('')}`;
  if(sliders.length)bindHeroSlider(sliders);bindCards();bindArchiveSwitcher();
  $$('[data-home-category]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.homeCategory));
  $$('[data-browse-section]').forEach(b=>b.onclick=()=>showBrowseSection(Number(b.dataset.archive),b.dataset.browseSection));
}


async function showBrowse(kind='movies'){
  setActiveNav(kind);setLoading();const type=kind==='series'?'series':'movie';const sec=type==='series'?(state.archive<=2?'updated_series':'new_series'):(state.archive<=2?'updated_movies':'new_movies');
  try{const r=await bridge.content('section',{archive:state.archive,section:sec,page:1,limit:48});renderGridPage(kind==='series'?'سریال‌ها':'فیلم‌ها',`${ARCHIVE_NAMES[state.archive]} • ${sectionLabel(sec)}`,r.items||[])}catch(e){renderError(e)}
}
async function showBrowseSection(archive,section){
  state.archive=archive;$('#archiveSelect').value=String(archive);bridge.setSettings({preferredArchive:archive});updateSearchPlaceholder();setActiveNav(section.includes('series')?'series':'movies');setLoading();
  try{const r=await bridge.content('section',{archive,section,page:1,limit:60});renderGridPage(sectionLabel(section),ARCHIVE_NAMES[archive],r.items||[])}catch(e){renderError(e)}
}
function renderGridPage(title,sub,items){$('#view').innerHTML=`<div class="page-title"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><span class="chip">${items.length} عنوان</span></div>${items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">موردی پیدا نشد.</div>'}`;bindCards()}

async function showSearch(initial=''){
  setActiveNav('search');
  const sections=homeSectionsFor(state.archive).filter(x=>x!=='collections');
  $('#view').innerHTML=`<div class="search-page">${archiveSwitcherHtml(state.archive,'search')}<section class="search-hero-panel"><span class="search-badge">جستجوی سریع</span><h1>فیلم و سریال را در ${esc(ARCHIVE_NAMES[state.archive])} پیدا کن</h1><p>نتایج فقط از همین آرشیو دریافت می‌شوند؛ برای منبع دیگر، آرشیو را از بالا تغییر بده.</p><form id="searchForm" class="site-search-form"><div class="site-search-input">${icon('search','search-field-icon')}<input id="searchQuery" name="q" autocomplete="off" placeholder="جستجو در ${esc(ARCHIVE_NAMES[state.archive])}…" value="${esc(initial)}"><button class="site-search-button">${icon('search')}<span>جستجو</span></button></div><div class="advanced-search-title">${icon('filter')}<span>فیلترهای پیشرفته</span></div><div class="advanced-search-row"><select name="type"><option value="">فیلم و سریال</option><option value="movie">فقط فیلم</option><option value="series">فقط سریال</option></select><input name="genre" placeholder="ژانر (اختیاری)"><input name="country" placeholder="کشور (اختیاری)"></div><input type="hidden" name="archive" value="${state.archive}"></form><div class="search-category-links">${sections.map(sec=>`<button type="button" data-search-category="${esc(sec)}">${esc(sectionLabel(sec))}</button>`).join('')}</div></section><div id="searchResults"><div class="empty search-empty">عبارت جستجو را وارد کن؛ نتیجه‌ها فقط از ${esc(ARCHIVE_NAMES[state.archive])} نمایش داده می‌شوند.</div></div></div>`;
  bindArchiveSwitcher();
  $$('[data-search-category]').forEach(b=>b.onclick=()=>showBrowseSection(state.archive,b.dataset.searchCategory));
  const f=$('#searchForm');f.onsubmit=async e=>{e.preventDefault();await performSearch(new FormData(f))};if(initial)performSearch(new FormData(f));
}
async function performSearch(fd){
  const out=$('#searchResults');out.innerHTML=searchLoaderHtml('در حال جستجو');
  const p=Object.fromEntries(fd.entries());p.archive=state.archive;p.page=1;p.limit=60;
  try{const r=await bridge.content('search',p);const items=r.items||r.results||[];out.innerHTML=items.length?`<div class="search-result-head"><div><strong>نتایج ${esc(ARCHIVE_NAMES[state.archive])}</strong><small>${items.length} عنوان پیدا شد</small></div></div><div class="grid">${items.map(card).join('')}</div>`:`<div class="empty">در ${esc(ARCHIVE_NAMES[state.archive])} نتیجه‌ای پیدا نشد.</div>`;bindCards(out)}catch(e){out.innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}

async function openDetail(item){
  setLoading('در حال دریافت جزئیات…');
  try{
    const r=await bridge.content('detail',{archive:item.target_archive||item.archive||state.archive,id:itemId(item),type:item.target_type||item.type||''});
    state.currentDetail=r.item||r;state.detailSeason=null;state.detailEpisode=null;state.visibleSources=[];
    renderDetail(state.currentDetail);loadComments(state.currentDetail);
  }catch(e){renderError(e)}
}
function sourceTypeLabel(s){
  if(s?.type_fa)return s.type_fa;
  const t=String(s?.type||'').toLowerCase();
  if(t==='dub')return 'دوبله فارسی';if(t==='softsub')return 'سافت‌ساب';if(t==='hardsub')return 'هاردساب';if(t==='subtitle')return 'زیرنویس';if(t==='audio')return 'صوت دوبله';if(t==='nosub')return 'بدون زیرنویس';return 'نسخه رسانه';
}
function subtitleUrlOf(s){return cleanUrl(s?.subtitle_url||s?.subtitleUrl||s?.subtitle||s?.sub_url||s?.subtitle_link||'')}
function seriesStructure(d,links){
  const map=new Map();
  const flat=Array.isArray(links)?links:[];
  if(flat.length){
    for(const l of flat){
      const sn=Number(l.season||1)||1,en=Number(l.episode||0)||0;
      if(!map.has(sn))map.set(sn,new Map());const eps=map.get(sn);if(!eps.has(en))eps.set(en,[]);eps.get(en).push(l);
    }
  }else{
    const apiSeasons=Array.isArray(d?.play?.seasons)?d.play.seasons:[];
    for(const sx of apiSeasons){
      const sn=Number(sx.season||1)||1;if(!map.has(sn))map.set(sn,new Map());const eps=map.get(sn);
      for(const ex of (Array.isArray(sx.episodes)?sx.episodes:[])){const en=Number(ex.episode||0)||0;if(!eps.has(en))eps.set(en,[]);eps.get(en).push(...(Array.isArray(ex.links)?ex.links:[]))}
    }
  }
  const epRank=n=>n===0?999999:n;
  return [...map.entries()].sort((a,b)=>a[0]-b[0]).map(([season,eps])=>({season,episodes:[...eps.entries()].sort((a,b)=>epRank(a[0])-epRank(b[0])).map(([episode,ls])=>({episode,links:ls}))}));
}
function sourceRow(s,i,series=false){
  const sub=subtitleUrlOf(s);const label=sourceTypeLabel(s);const playable=s.is_playable!==false&&!!s.url&&!s.is_folder;const downloadable=s.is_download!==false&&!!s.url;
  const t=String(s?.type||'').toLowerCase();const isDub=/dub|audio/.test(t)||/دوبله|صوت/.test(label);const hasSub=sub||/softsub|hardsub|subtitle/.test(t)||/زیرنویس|ساب/.test(label);
  return `<div class="source-row"><div class="source-main"><span class="quality">${esc(s.quality||'AUTO')}</span><span><strong>${isDub?icon('mic','source-kind-icon'):hasSub?icon('subtitle','source-kind-icon'):''}${esc(label)}</strong><small>${esc(s.size||'')}${sub?' • زیرنویس جداگانه':''}${s.is_folder?' • پوشه':''}</small><span class="source-tags"><em>${isDub?icon('mic','tiny-icon'):''}${esc(label)}</em>${hasSub?`<em class="sub">${icon('subtitle','tiny-icon')} زیرنویس</em>`:''}</span></span></div><div class="source-actions">${playable?`<button class="btn ghost slim" data-${series?'series-':''}source-play="${i}">${icon('play')}<span>پخش</span></button>`:''}${downloadable?`<button class="btn primary slim" data-${series?'series-':''}source-download="${i}">${icon('download')}<span>دانلود</span></button>`:''}</div></div>`;
}
function renderSeriesSources(d,links){
  const seasons=seriesStructure(d,links);if(!seasons.length)return '<div class="empty">قسمتی برای این سریال ثبت نشده است.</div>';
  if(!seasons.some(x=>x.season===Number(state.detailSeason)))state.detailSeason=seasons[0].season;
  const season=seasons.find(x=>x.season===Number(state.detailSeason))||seasons[0];
  if(!season.episodes.some(x=>x.episode===Number(state.detailEpisode)))state.detailEpisode=season.episodes[0]?.episode??0;
  const episode=season.episodes.find(x=>x.episode===Number(state.detailEpisode))||season.episodes[0];
  state.visibleSources=episode?.links||[];
  const seasonTabs=seasons.map(x=>`<button class="season-tab ${x.season===season.season?'active':''}" data-season="${x.season}">فصل ${x.season}</button>`).join('');
  const episodeTabs=season.episodes.map(x=>`<button class="episode-pill ${x.episode===episode?.episode?'active':''}" data-episode="${x.episode}">${x.episode>0?x.episode:'ویژه'}</button>`).join('');
  const rows=state.visibleSources.length?state.visibleSources.map((s,i)=>sourceRow(s,i,true)).join(''):'<div class="empty">برای این قسمت کیفیتی ثبت نشده است.</div>';
  return `<div class="series-sources"><div class="series-picker"><div><span class="picker-label">فصل</span><div class="season-tabs">${seasonTabs}</div></div><div><span class="picker-label">قسمت</span><div class="episode-tabs">${episodeTabs}</div></div></div><div class="episode-heading"><strong>فصل ${season.season} • ${episode?.episode>0?`قسمت ${episode.episode}`:'قسمت ویژه'}</strong><small>کیفیت، دوبله و زیرنویس فقط مربوط به همین قسمت هستند.</small></div><div class="sources">${rows}</div></div>`;
}
function renderDetail(d){
  const bg=cleanUrl(d.backdrop||d.background||d.poster||'');const poster=cleanUrl(d.poster||'');const links=d.play?.links||d.downloads||d.links||[];const related=d.related||[];
  const inList=state.watchlist.some(w=>watchKey(w)===watchKey(d));
  $('#view').innerHTML=`<div class="detail"><section class="detail-hero">${bg?`<div class="detail-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="detail-inner"><div class="detail-copy"><div class="eyebrow">${esc(ARCHIVE_NAMES[d.archive]||'BANKMOVIE')}</div><h1 class="detail-title">${esc(itemTitle(d))}</h1><div class="meta"><span class="chip gold">★ ${esc(d.rating||'—')}</span><span class="chip">${esc(d.year||'')}</span><span class="chip">${d.type==='series'?'سریال':'فیلم'}</span>${(d.genres||[]).slice(0,3).map(g=>`<span class="chip">${esc(typeof g==='string'?g:(g.name||g.title||''))}</span>`).join('')}</div><p class="description">${esc(d.long_description||d.description||'توضیحی ثبت نشده است.')}</p><div class="actions"><button class="btn red" id="playBest">${icon('play')}<span>پخش</span></button><button class="btn ghost" id="watchBtn">${icon('bookmark')}<span>${inList?'حذف از لیست':'افزودن به لیست'}</span></button>${d.trailer_url?'<button class="btn ghost" id="trailerBtn">تریلر</button>':''}</div></div>${poster?`<img class="detail-poster" src="${esc(poster)}">`:''}</div></section><div class="detail-body"><div class="tabs"><button class="tab active" data-detail-tab="sources">پخش و دانلود</button><button class="tab" data-detail-tab="comments">دیدگاه‌ها</button><button class="tab" data-detail-tab="info">اطلاعات</button></div><div id="detailTab">${renderSources(d,links)}</div>${related.length?`<section class="section"><div class="section-head"><h2>پیشنهادهای مشابه</h2></div><div class="rail">${related.map(card).join('')}</div></section>`:''}</div></div>`;
  bindCards();$('#watchBtn').onclick=()=>quickWatchlist(d,true);if($('#trailerBtn'))$('#trailerBtn').onclick=()=>bridge.openExternal(d.trailer_url);
  bindSourceButtons(d,links);
  $('#playBest').onclick=()=>{const pool=state.visibleSources?.length?state.visibleSources:links;const s=pool.find(x=>x.is_playable!==false&&x.url&&!x.is_folder)||pool.find(x=>x.url&&!x.is_folder);s?playSource(s):toast('لینک پخش موجود نیست','error')};
  $$('[data-detail-tab]').forEach(t=>t.onclick=()=>switchDetailTab(t.dataset.detailTab,d,links,t));
}
function renderSources(d,links){
  if(!links.length)return '<div class="empty">برای این عنوان لینک پخش یا دانلودی موجود نیست.</div>';
  if(d.type==='series'||d.type==='tv'||d.play?.has_series_structure)return renderSeriesSources(d,links);
  state.visibleSources=links;
  return `<div class="sources">${links.map((s,i)=>sourceRow(s,i,false)).join('')}</div>`;
}
function rerenderSources(d,links){const box=$('#detailTab');if(!box)return;box.innerHTML=renderSources(d,links);bindSourceButtons(d,links)}
function switchDetailTab(name,d,links,tab){$$('[data-detail-tab]').forEach(x=>x.classList.remove('active'));tab.classList.add('active');const box=$('#detailTab');if(name==='sources'){box.innerHTML=renderSources(d,links);bindSourceButtons(d,links)}if(name==='comments')renderCommentsBox(d);if(name==='info')box.innerHTML=renderInfo(d)}
function bindSourceButtons(d,links){
  $$('[data-source-play]').forEach(b=>b.onclick=()=>playSource(links[Number(b.dataset.sourcePlay)]));
  $$('[data-source-download]').forEach(b=>b.onclick=()=>downloadSource(links[Number(b.dataset.sourceDownload)],d));
  $$('[data-series-source-play]').forEach(b=>b.onclick=()=>playSource(state.visibleSources[Number(b.dataset.seriesSourcePlay)]));
  $$('[data-series-source-download]').forEach(b=>b.onclick=()=>downloadSource(state.visibleSources[Number(b.dataset.seriesSourceDownload)],d));
  $$('[data-season]').forEach(b=>b.onclick=()=>{state.detailSeason=Number(b.dataset.season);state.detailEpisode=null;rerenderSources(d,links)});
  $$('[data-episode]').forEach(b=>b.onclick=()=>{state.detailEpisode=Number(b.dataset.episode);rerenderSources(d,links)});
}
function renderInfo(d){return `<div class="panel"><div class="form-grid"><div class="field"><label>عنوان اصلی</label><div>${esc(d.title||'—')}</div></div><div class="field"><label>سال</label><div>${esc(d.year||'—')}</div></div><div class="field"><label>زبان</label><div>${esc(d.language||'—')}</div></div><div class="field"><label>کشور</label><div>${esc(Array.isArray(d.country)?d.country.join('، '):(d.country||'—'))}</div></div><div class="field"><label>شبکه</label><div>${esc(d.network||'—')}</div></div><div class="field"><label>مدت</label><div>${esc(d.runtime||'—')}</div></div></div></div>`}
async function playSource(s){
  if(!s?.url)return toast('لینک پخش معتبر نیست','error');
  try{
    const result=await bridge.playExternal({url:s.url,subtitleUrl:subtitleUrlOf(s),preferredPlayer:state.settings?.preferredPlayer||'auto',title:itemTitle(state.currentDetail),quality:s.quality||'',season:s.season||null,episode:s.episode||null});
    const suffix=subtitleUrlOf(s)&&!result?.subtitleApplied?' • زیرنویس جداگانه توسط این پلیر تضمین نمی‌شود':'';
    toast(`در ${result?.player?.name||'پلیر خارجی'} باز شد${suffix}`,'ok');
  }catch(e){toast(e.message||String(e),'error')}
}
async function downloadSource(s,d){try{const ext=(()=>{try{const x=new URL(s.url).pathname.split('.').pop().split(/[?#]/)[0];return x&&x.length<6?x:'mp4'}catch{return'mp4'}})();const name=`${itemTitle(d)}${s.season?` - S${s.season}`:''}${s.episode?`E${s.episode}`:''} - ${sourceTypeLabel(s)} - ${s.quality||'video'}.${ext}`;await bridge.download({url:s.url,fileName:name,title:itemTitle(d),quality:`${s.quality||''} ${sourceTypeLabel(s)}`.trim(),poster:d.poster||'',season:s.season||null,episode:s.episode||null});toast('دانلود به صف اضافه شد','ok');$('#downloadCount').textContent=String(Math.max(1,state.downloads.size))}catch(e){toast(e.message,'error')}}

function watchKey(it){return it?.storage_key||it?._key||`${it?.archive||1}|${it?.type||'movie'}|${itemId(it)}`}
async function ensureWatchlist(){if(!state.user)return[];try{const r=await bridge.user('watchlist_list',{},'POST');state.watchlist=r.items||[];return state.watchlist}catch{return[]}}
async function quickWatchlist(item,rerender=false){
  if(!state.user){showAuthModal();return}await ensureWatchlist();const key=watchKey(item);const old=state.watchlist.find(x=>watchKey(x)===key);
  try{const body=old?{removed_keys:[watchKey(old)],items:[]}:{removed_keys:[],items:[item]};const r=await bridge.user('watchlist_sync',body,'POST');state.watchlist=r.items||[];toast(old?'از لیست حذف شد':'به لیست اضافه شد','ok');if(rerender&&state.currentDetail)renderDetail(state.currentDetail)}catch(e){toast(e.message,'error')}
}
async function showWatchlist(){setActiveNav('watchlist');if(!state.user)return showAuthGate('برای دیدن لیست شخصی وارد حساب شو.');setLoading();await ensureWatchlist();renderGridPage('لیست من','همگام با حساب BankMovie',state.watchlist)}

let commentsCache=[];
async function loadComments(d){try{const r=await bridge.user('comments_list',{item:d,page:1,limit:20,sort:'latest'},'POST');commentsCache=r.items||r.comments||[]}catch{commentsCache=[]}}
function renderCommentsBox(d){
  const box=$('#detailTab');box.innerHTML=`${state.user?`<div class="comment-form"><textarea class="form-control" id="commentText" placeholder="دیدگاهت را بنویس…"></textarea><button class="btn primary" id="sendComment">ارسال</button></div>`:'<div class="panel" style="margin-bottom:10px">برای ثبت دیدگاه وارد حساب شو.</div>'}<div id="commentsList" class="comments">${commentsCache.length?commentsCache.map(c=>commentHtml(c,0)).join(''):'<div class="empty">هنوز دیدگاهی ثبت نشده است.</div>'}</div>`;
  if($('#sendComment'))$('#sendComment').onclick=async()=>{const text=$('#commentText').value.trim();if(text.length<3)return toast('متن دیدگاه کوتاه است','error');try{await bridge.user('comment_add',{item:d,comment:text,rating:0,spoiler:0},'POST');$('#commentText').value='';await reloadComments(d,'دیدگاه ثبت شد')}catch(e){toast(e.message,'error')}};
  $$('[data-comment-action]').forEach(b=>b.onclick=()=>commentAction(b.dataset.commentAction,Number(b.dataset.commentId),b.dataset.commentText||'',d));
}
function commentHtml(c,depth=0){
  const buttons=state.user?`<div class="source-actions" style="margin-top:8px;justify-content:flex-start;flex-wrap:wrap"><button class="btn ghost slim" data-comment-action="like" data-comment-id="${c.id}">👍 ${c.like_count||0}</button><button class="btn ghost slim" data-comment-action="dislike" data-comment-id="${c.id}">👎 ${c.dislike_count||0}</button><button class="btn ghost slim" data-comment-action="reply" data-comment-id="${c.id}">پاسخ</button>${c.can_report?`<button class="btn ghost slim" data-comment-action="report" data-comment-id="${c.id}">گزارش</button>`:''}${c.can_edit?`<button class="btn ghost slim" data-comment-action="edit" data-comment-id="${c.id}" data-comment-text="${esc(c.comment_raw||c.comment||'')}">ویرایش</button>`:''}${c.can_pin?`<button class="btn ghost slim" data-comment-action="pin" data-comment-id="${c.id}">${c.is_pinned?'برداشتن پین':'پین'}</button>`:''}${c.can_delete?`<button class="btn ghost slim" data-comment-action="delete" data-comment-id="${c.id}">حذف</button>`:''}</div>`:'';
  return `<div class="comment" style="margin-right:${Math.min(depth,3)*18}px"><div class="comment-head"><strong>${esc(c.username||c.user?.username||'کاربر')} ${c.badge?`• ${esc(c.badge)}`:''}</strong><span>${esc(c.date_text||c.created_at||'')}</span></div><p>${c.spoiler?'⚠️ Spoiler — ':''}${esc(c.comment||c.text||'')}</p>${buttons}${(c.replies||[]).map(r=>commentHtml(r,depth+1)).join('')}</div>`
}
async function reloadComments(d,message=''){await loadComments(d);renderCommentsBox(d);if(message)toast(message,'ok')}
async function commentAction(action,id,text,d){
  if(!state.user)return showAuthModal();
  try{
    if(action==='like'||action==='dislike')await bridge.user('comment_vote',{item:d,comment_id:id,type:action},'POST');
    else if(action==='reply'){const v=prompt('متن پاسخ:');if(!v)return;await bridge.user('comment_reply',{item:d,parent_id:id,comment:v,rating:0,spoiler:0},'POST')}
    else if(action==='report'){const v=prompt('توضیح گزارش (اختیاری):','');if(v===null)return;await bridge.user('comment_report',{item:d,comment_id:id,reason:'other',details:v},'POST')}
    else if(action==='edit'){const v=prompt('ویرایش دیدگاه:',text);if(!v)return;await bridge.user('comment_edit',{item:d,comment_id:id,comment:v,spoiler:0},'POST')}
    else if(action==='pin')await bridge.user('comment_pin',{item:d,comment_id:id},'POST');
    else if(action==='delete'){if(!confirm('دیدگاه حذف شود؟'))return;await bridge.user('comment_delete',{item:d,comment_id:id},'POST')}
    await reloadComments(d,action==='report'?'گزارش ثبت شد':'انجام شد');
  }catch(e){toast(e.message,'error')}
}

function onDownloadUpdate(d){state.downloads.set(d.id,d);$('#downloadCount').textContent=[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length||'';if(state.lastView==='downloads')renderDownloads()}
function showDownloads(){setActiveNav('downloads');renderDownloads()}
function renderDownloads(){
  const arr=[...state.downloads.values()];$('#view').innerHTML=`<div class="page-title"><div><h1>دانلودها</h1><p>${esc(state.settings?.downloadDir||'')}</p></div><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div><div id="downloadRows">${arr.length?arr.map(downloadHtml).join(''):'<div class="empty">هنوز دانلودی در این نشست شروع نشده است.</div>'}</div>`;
  $('#chooseFolder').onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();renderDownloads()};$$('[data-dl-action]').forEach(b=>b.onclick=()=>bridge.downloadAction(b.dataset.id,b.dataset.dlAction));$$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));
}
function downloadHtml(d){const p=pct(d.received,d.total);return `<div class="download-row"><div><strong>${esc(d.title||d.fileName||'دانلود')}</strong><small>${esc(d.quality||'')} • ${fmtBytes(d.received)} / ${fmtBytes(d.total)}</small><div class="progress"><i style="width:${p}%"></i></div></div><div><span class="chip">${esc(d.state||'شروع')}</span></div><div class="source-actions">${d.state==='progressing'&&!d.paused?`<button class="btn ghost slim" data-dl-action="pause" data-id="${d.id}">توقف</button>`:''}${d.paused?`<button class="btn primary slim" data-dl-action="resume" data-id="${d.id}">ادامه</button>`:''}${d.state==='completed'&&d.savePath?`<button class="btn ghost slim" data-show-file="${esc(d.savePath)}">فایل</button>`:`<button class="btn ghost slim" data-dl-action="cancel" data-id="${d.id}">لغو</button>`}</div></div>`}

async function showNotifications(){
  setActiveNav('notifications');if(!state.user)return showAuthGate('اعلان‌ها بعد از ورود به حساب نمایش داده می‌شوند.');setLoading();
  try{const r=await bridge.user('notifications_list',{page:1,limit:40},'POST');const items=r.items||[];state.stats=r.stats||state.stats;$('#notifCount').textContent=state.stats?.unread_notifications||'';$('#view').innerHTML=`<div class="page-title"><div><h1>اعلان‌ها</h1><p>پیام‌های شخصی و مدیریتی</p></div><button class="btn ghost" id="readAll">خواندن همه</button></div>${items.length?`<div class="comments">${items.map(n=>`<div class="comment"><div class="comment-head"><strong>${esc(n.title||'اعلان')}</strong><span>${esc(n.date_text||'')}</span></div><p>${esc(n.message||'')}</p></div>`).join('')}</div>`:'<div class="empty">اعلان جدیدی نداری.</div>'}`;$('#readAll').onclick=async()=>{await bridge.user('notifications_read_all',{},'POST');toast('همه اعلان‌ها خوانده شد','ok');showNotifications()}}catch(e){renderError(e)}
}

async function showParty(){
  setActiveNav('party');setLoading('در حال آماده‌سازی Watch Party…');
  try{const st=await bridge.user('watch_party_status',{},'POST');if(!st.enabled)return renderGridPage('Watch Party','این قابلیت غیرفعال است',[]);renderPartyLobby(st)}catch(e){renderError(e)}
}
function renderPartyLobby(st){
  $('#view').innerHTML=`<div class="page-title"><div><h1>Watch Party</h1><p>تماشای همزمان، چت و کنترل میزبان</p></div><span class="chip ${st.is_vip?'gold':''}">${st.is_vip?'VIP':'حساب عادی'}</span></div><div class="settings-grid"><div class="panel"><h3>ورود به اتاق</h3><div class="field"><label>کد اتاق</label><input id="roomCode" placeholder="مثلاً ABC123"></div><div style="margin-top:10px"><button class="btn primary" id="joinRoom">ورود</button></div></div><div class="panel"><h3>ساخت اتاق</h3><p style="color:#858990;font-size:11px;line-height:1.8">ساخت اتاق برای VIP فعال است. اگر از صفحه جزئیات وارد شوی، عنوان فعلی خودکار به اتاق منتقل می‌شود.</p><button class="btn ghost" id="createRoom" ${st.is_vip?'':'disabled'}>ساخت برای عنوان فعلی</button></div></div>`;
  $('#joinRoom').onclick=()=>joinParty($('#roomCode').value.trim());$('#createRoom').onclick=()=>createParty();
}
async function createParty(){if(!state.currentDetail)return toast('اول یک فیلم یا سریال باز کن','error');try{const d=state.currentDetail;const source=(d.play?.links||[]).find(x=>x.url)||{};const r=await bridge.user('watch_party_create',{movie_id:Number(d.db_id||d.movie_id||0),archive_no:Number(d.archive||1),media_type:d.type||'movie',source_ref:itemId(d),source_url:source.url||'',subtitle_url:'',content_title:itemTitle(d),poster_url:d.poster||''},'POST');const code=r.room?.invite_code||r.room?.room_code;if(code)openPartyRoom(code,r.room)}catch(e){toast(e.message,'error')}}
async function joinParty(code){if(!code)return toast('کد اتاق را وارد کن','error');try{const r=await bridge.user('watch_party_join',{room_code:code},'POST');openPartyRoom(code,r.membership||{})}catch(e){toast(e.message,'error')}}
function openPartyRoom(code,meta={}){state.party={code,afterEvent:0,afterMessage:0};renderPartyRoom(code,meta);pollParty();state.partyTimer=setInterval(pollParty,3500)}
function renderPartyRoom(code,meta){$('#view').innerHTML=`<div class="page-title"><div><h1>اتاق ${esc(code)}</h1><p>${esc(meta.content_title||'Watch Party فعال')}</p></div><button class="btn ghost" id="leaveParty">خروج</button></div><div class="party-shell"><div class="panel"><h3>وضعیت پخش</h3><div id="partyState" class="empty" style="padding:40px">در حال همگام‌سازی…</div></div><div class="panel party-chat"><h3>گفتگو</h3><div class="chat-list" id="chatList"></div><div class="chat-compose"><input class="form-control" id="chatText" placeholder="پیام…"><button class="btn primary" id="sendChat">ارسال</button></div></div></div>`;$('#leaveParty').onclick=async()=>{try{await bridge.user('watch_party_leave',{room_code:code},'POST')}catch{}state.party=null;clearInterval(state.partyTimer);state.partyTimer=null;showParty()};$('#sendChat').onclick=sendPartyMessage}
async function pollParty(){if(!state.party)return;try{const r=await bridge.user('watch_party_poll',{room_code:state.party.code,after_event_id:state.party.afterEvent,after_message_id:state.party.afterMessage},'POST');const ev=r.events||[];const msg=r.messages||[];if(ev.length)state.party.afterEvent=Math.max(state.party.afterEvent,...ev.map(x=>Number(x.id||x.event_id||0)));if(msg.length){state.party.afterMessage=Math.max(state.party.afterMessage,...msg.map(x=>Number(x.id||x.message_id||0)));const list=$('#chatList');if(list){msg.forEach(m=>list.insertAdjacentHTML('beforeend',`<div class="chat-msg"><strong>${esc(m.username||m.display_name||'کاربر')}:</strong> ${esc(m.text||m.message||'')}</div>`));list.scrollTop=list.scrollHeight}}if($('#partyState')){const s=r.state||{};$('#partyState').innerHTML=`<div class="meta"><span class="chip">${s.is_paused?'⏸ توقف':'▶ در حال پخش'}</span><span class="chip">${Math.round(Number(s.position_seconds||0))} ثانیه</span><span class="chip">${esc(r.member_role||'guest')}</span></div>`}}catch(e){console.warn(e)}}
async function sendPartyMessage(){const input=$('#chatText');const m=input?.value.trim();if(!m||!state.party)return;try{await bridge.user('watch_party_message',{room_code:state.party.code,message:m,client_message_id:`win-${Date.now()}`},'POST');input.value='';await pollParty()}catch(e){toast(e.message,'error')}}

function showProfile(){setActiveNav('');if(state.user)return renderProfile();showAuthModal()}
function renderProfile(){
  $('#view').innerHTML=`<div class="page-title"><div><h1>${esc(state.user.full_name||state.user.username)}</h1><p>${esc(state.user.email||'')}</p></div><span class="chip gold">${state.user.is_vip?'VIP فعال':'کاربر BankMovie'}</span></div><div class="settings-grid"><div class="panel"><h3>حساب</h3><p>نام کاربری: ${esc(state.user.username||'')}</p><p>عضویت VIP: ${state.user.is_vip?'فعال':'غیرفعال'}</p><p>انقضا: ${esc(state.user.vip_expires_at||'—')}</p><div class="actions"><button class="btn ghost" id="avatarBtn">تغییر آواتار</button><button class="btn ghost" id="logoutBtn">خروج از حساب</button></div></div><div class="panel"><h3>آمار</h3><div class="meta"><span class="chip">لیست من: ${state.stats?.watchlist_count||0}</span><span class="chip">اعلان خوانده‌نشده: ${state.stats?.unread_notifications||0}</span></div></div></div>`;
  $('#avatarBtn').onclick=showAvatarModal;
  $('#logoutBtn').onclick=async()=>{try{await bridge.user('logout',{},'POST')}catch{}await bridge.logoutLocal();state.user=null;state.watchlist=[];updateProfile();showHome();toast('از حساب خارج شدی','ok')}
}
async function showAvatarModal(){const avatars=state.userConfig?.avatars||[];openModal(`<button class="icon-btn close-modal" data-close-avatar>×</button><h2>انتخاب آواتار</h2><div class="grid" style="grid-template-columns:repeat(4,1fr)">${avatars.map(a=>`<button class="panel" style="cursor:pointer;color:#fff" data-avatar="${esc(a.key)}">${img(a.url,a.label)}<div>${esc(a.label)}</div></button>`).join('')}</div>${state.user?.can_upload_avatar?`<div class="field" style="margin-top:12px"><label>آواتار اختصاصی VIP</label><input type="file" id="avatarFile" accept="image/png,image/jpeg,image/webp,image/gif"></div>`:''}`);$('[data-close-avatar]').onclick=closeModal;$$('[data-avatar]').forEach(b=>b.onclick=async()=>{try{const r=await bridge.user('avatar_update',{avatar_key:b.dataset.avatar},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار ذخیره شد','ok')}catch(e){toast(e.message,'error')}});if($('#avatarFile'))$('#avatarFile').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=async()=>{try{const r=await bridge.user('avatar_upload',{image_base64:rd.result},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار اختصاصی ذخیره شد','ok')}catch(err){toast(err.message,'error')}};rd.readAsDataURL(f)}}
function showAuthGate(text){$('#view').innerHTML=`<div class="empty"><p>${esc(text)}</p><button class="btn primary" id="authGateBtn">ورود / ثبت‌نام</button></div>`;$('#authGateBtn').onclick=showAuthModal}
function showAuthModal(){
  openModal(`<button class="icon-btn close-modal" data-close-auth>×</button><div style="min-width:min(470px,80vw)"><div class="page-title"><div><h1>حساب BankMovie</h1><p>ورود و لیست شخصی روی همه دستگاه‌ها</p></div></div><div class="tabs"><button class="tab active" data-auth-tab="login">ورود</button><button class="tab" data-auth-tab="register">ثبت‌نام</button></div><div id="authBody">${loginForm()}</div></div>`);$('[data-close-auth]').onclick=closeModal;$$('[data-auth-tab]').forEach(t=>t.onclick=()=>{$$('[data-auth-tab]').forEach(x=>x.classList.remove('active'));t.classList.add('active');$('#authBody').innerHTML=t.dataset.authTab==='login'?loginForm():registerForm();bindAuthForms()});bindAuthForms();
}
function loginForm(){return `<form id="loginForm" class="form-grid"><div class="field full"><label>نام کاربری یا ایمیل</label><input name="identity" required></div><div class="field full"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field full"><button class="btn primary">ورود</button></div></form>`}
function registerForm(){return `<form id="registerForm" class="form-grid"><div class="field full"><label>نام کاربری</label><input name="username" required></div><div class="field full"><label>ایمیل</label><input name="email" type="email" required></div><div class="field"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field"><label>تکرار رمز</label><input name="confirm_password" type="password" required></div><div class="field full"><button class="btn primary">ساخت حساب</button></div></form>`}
function bindAuthForms(){
  if($('#loginForm'))$('#loginForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('login',b,'POST');if(!r.success)throw new Error(r.message||'ورود انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('خوش آمدی','ok');route(state.lastView||'home')}catch(err){toast(err.message,'error')}};
  if($('#registerForm'))$('#registerForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('register',b,'POST');if(!r.success)throw new Error(r.message||'ثبت‌نام انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('حساب ساخته شد','ok')}catch(err){toast(err.message,'error')}};
}

async function showSettings(){
  setActiveNav('settings');state.settings=await bridge.getSettings();state.players=await bridge.getPlayers();const cfg=state.config||{};const df=cfg.desktop?.features||{};
  const playerOptions=`<option value="auto">خودکار (پیشنهادی)</option>${state.players.map(p=>`<option value="${esc(p.id)}" ${state.settings.preferredPlayer===p.id?'selected':''}>${esc(p.name)}</option>`).join('')}`;
  const playerStatus=state.players.length?state.players.map((p,i)=>`<span class="chip ${i===0?'gold':''}">${i===0?'پیشنهادی: ':''}${esc(p.name)}</span>`).join(''):'<span class="chip">هیچ پلیر پشتیبانی‌شده‌ای پیدا نشد</span>';
  $('#view').innerHTML=`<div class="page-title"><div><h1>تنظیمات</h1><p>نسخه ${esc(state.appVersion)} • ${esc(cfg.active_domain||'bankmovie.top')}</p></div></div><div class="settings-grid"><div class="panel"><h3>پخش و دانلود</h3><div class="field"><label>پلیر خارجی</label><select id="preferredPlayer">${playerOptions}</select><small style="color:#70757d">برنامه فقط VLC / PotPlayer / KMPlayer نصب‌شده روی ویندوز را استفاده می‌کند؛ پلیر مرورگری حذف شده است.</small></div><div class="meta">${playerStatus}</div><div class="field" style="margin-top:14px"><label>پوشه دانلود</label><input id="downloadDir" value="${esc(state.settings.downloadDir||'')}" readonly></div><div style="margin-top:8px"><button class="btn ghost" id="chooseDir">انتخاب پوشه</button></div></div><div class="panel"><h3>کنترل ریموت</h3><div class="field"><label>Controller</label><input id="controllerUrl" dir="ltr" value="${esc(state.settings.controllerUrl||'https://bankmovie.top/desktop_config.php')}"></div><div class="meta"><span class="chip">API: ${esc(cfg.api_url||'')}</span></div><div class="actions"><button class="btn primary" id="saveSettings">ذخیره و اتصال مجدد</button></div></div><div class="panel"><h3>قابلیت‌های فعال</h3><div class="meta">${Object.entries({...cfg.features,...df}).filter(([,v])=>typeof v==='boolean'&&v).slice(0,18).map(([k])=>`<span class="chip">${esc(k.replaceAll('_',' '))}</span>`).join('')}</div></div><div class="panel"><h3>آرشیوها</h3>${enabledArchives().map(n=>{const p=archivePolicy(n);return `<div class="source-row"><div class="source-main"><span class="quality">${n}</span><span><strong>${ARCHIVE_NAMES[n]}</strong><small>${esc(p.access_scope||'public')} • download: ${esc(p.download_access_scope||'public')}</small></span></div></div>`}).join('')}</div></div>`;
  $('#chooseDir').onclick=async()=>{$('#downloadDir').value=await bridge.chooseDownloadDir()};
  $('#saveSettings').onclick=async()=>{state.settings=await bridge.setSettings({preferredPlayer:$('#preferredPlayer').value,controllerUrl:$('#controllerUrl').value.trim()});toast('تنظیمات ذخیره شد.','ok')};
}

function openModal(html,wide=false){const m=$('#modal'),b=$('#modalBox');b.innerHTML=html;b.style.maxWidth=wide?'min(1150px,94vw)':'';b.style.padding=wide?'10px':'19px';m.classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden');const v=$('#modal video');if(v){v.pause();v.removeAttribute('src')}}
function renderError(e){$('#view').innerHTML=`<div class="empty"><h3>ارتباط با سرور انجام نشد</h3><p>${esc(e.message||e)}</p><button class="btn ghost" id="retryBtn">تلاش دوباره</button></div>`;$('#retryBtn').onclick=()=>route(state.lastView,true);toast(e.message||String(e),'error')}

document.addEventListener('DOMContentLoaded',init);
