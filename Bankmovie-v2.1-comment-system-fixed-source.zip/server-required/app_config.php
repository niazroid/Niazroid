<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$configFile = __DIR__ . '/bankmovie_remote_config.json';
$default = [
    'schema_version' => 3,
    'ready' => true,
    'message' => 'اپ موقتاً در دسترس نیست.',
    'active_domain' => 'https://bankmovie.top',
    'api_url' => 'https://bankmovie.top/app_api.php',
    'account_api_url' => 'https://bankmovie.top/app_user_api.php',
    'servers' => [
        [
            'name' => 'سرور اصلی bankmovie.top',
            'enabled' => true,
            'priority' => 1,
            'domain' => 'https://bankmovie.top',
            'api_url' => 'https://bankmovie.top/app_api.php'
        ],
        [
            'name' => 'سرور دوم bankmoviee.ir',
            'enabled' => true,
            'priority' => 2,
            'domain' => 'https://bankmoviee.ir',
            'api_url' => 'https://bankmoviee.ir/app_api.php'
        ]
    ],
    'url_rewrites' => [],
    'notice' => ['enabled'=>false,'id'=>'','title'=>'','message'=>''],
    'update' => [
        'enabled' => false,
        'version_code' => 1110000,
        'version_name' => '1.4',
        'apk_url' => '',
        'apk_urls' => ['universal'=>'','arm64_v8a'=>'','armeabi_v7a'=>''],
        'force' => false,
        'title' => 'آپدیت جدید آماده است',
        'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
        'changes' => []
    ],
    'version_policy' => [
        'enabled' => true,
        'minimum_version_code' => 0,
        'minimum_version_name' => '',
        'blocked_version_names' => [],
        'blocked_version_codes' => [],
        'force_update_blocked' => true,
        'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
    ],
    'updated_at' => gmdate('c')
];

if (is_file($configFile)) {
    $raw = file_get_contents($configFile);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    if (is_array($saved)) $default = array_replace_recursive($default, $saved);
}

echo json_encode($default, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
