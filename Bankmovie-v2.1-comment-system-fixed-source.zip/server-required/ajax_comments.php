<?php
// ajax_comments.php - مدیریت کامل کامنت (افزودن، پاسخ، لایک، حذف، بارگذاری بیشتر) با رفع خطاها و افزودن CSRF
require_once 'config.php';
header('Content-Type: application/json');

$userLang = $_COOKIE['user_lang'] ?? 'fa';
$currentUser = null;
if (isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

// راه‌اندازی سشن برای CSRF
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$action = '';
foreach (['action', 'bm_action', 'comment_action', 'do', 'task', 'mode'] as $key) {
    if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') { $action = trim((string)$_POST[$key]); break; }
    if (isset($_GET[$key])  && trim((string)$_GET[$key])  !== '') { $action = trim((string)$_GET[$key]);  break; }
}
$action = strtolower($action);

// سازگاری با اسم‌های مختلف اکشن در فرانت‌های قدیمی/جدید
$actionAliases = [
    'submit_comment' => 'add_comment',
    'send_comment'   => 'add_comment',
    'new_comment'    => 'add_comment',
    'comment_add'    => 'add_comment',
    'add'            => 'add_comment',
    'submit_reply'   => 'add_reply',
    'send_reply'     => 'add_reply',
    'reply'          => 'add_reply',
    'reply_add'      => 'add_reply',
    'like'           => 'vote',
    'dislike'        => 'vote',
    'like_comment'   => 'vote',
    'dislike_comment'=> 'vote',
    'comment_vote'   => 'vote',
    'delete'         => 'delete_comment',
    'remove'         => 'delete_comment',
    'remove_comment' => 'delete_comment',
    'load_more'      => 'load_more_comments',
    'more_comments'  => 'load_more_comments',
    'get_reply'      => 'get_replies',
    'replies'        => 'get_replies',
];
if (isset($actionAliases[$action])) $action = $actionAliases[$action];

// اگر action به هر دلیل ارسال نشد، از روی فیلدها حدس بزن تا خطای action not found نگیریم.
if ($action === '') {
    if (isset($_POST['comment']) && isset($_POST['parent_id'])) $action = 'add_reply';
    elseif (isset($_POST['comment']) && isset($_POST['movie_id'])) $action = 'add_comment';
    elseif (isset($_POST['comment_id']) && isset($_POST['type'])) $action = 'vote';
    elseif (isset($_POST['page']) && isset($_POST['movie_id'])) $action = 'load_more_comments';
    elseif (isset($_GET['comment_id'])) $action = 'get_replies';
}
$commentsPerPage = 10;

// آرشیو ۱ از ID مجازی مثبت در بازه بالا استفاده می‌کند.
// این فلگ باعث می‌شود کامنت آرشیو ۱ داخل movie_ratings آرشیو ۲ ثبت نشود.
function bm_is_archive1_comment_movie_id(int $movieId): bool {
    return $movieId >= 1000000000;
}

// آرشیو ۱ جدول جدا دارد تا به foreign key احتمالی comments.movie_id -> movies.id گیر نکند.
function bm_ensure_archive1_comment_tables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        comment TEXT NOT NULL,
        rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
        spoiler TINYINT(1) NOT NULL DEFAULT 0,
        parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_movie_parent_status (movie_id, parent_id, status),
        KEY idx_user_status (user_id, status),
        KEY idx_parent (parent_id),
        KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id),
        KEY idx_comment_type (comment_id, type),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bm_comment_table(bool $isArchive1): string {
    return $isArchive1 ? 'archive1_comments' : 'comments';
}
function bm_like_table(bool $isArchive1): string {
    return $isArchive1 ? 'archive1_comment_likes' : 'comment_likes';
}


function bm_comment_privileged_role(string $role): bool {
    return in_array(strtolower(trim($role)), ['admin','administrator','vip','premium','special'], true);
}

function bm_comment_rate_limit(PDO $pdo, ?int $userId): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_rate_limits (
        actor_key VARCHAR(190) NOT NULL PRIMARY KEY,
        window_started_at DATETIME NOT NULL,
        comment_count INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL,
        KEY idx_updated_at (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $remote = trim((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $actor = ($userId !== null && $userId > 0) ? ('user:' . $userId) : ('ip:' . hash('sha256', $remote));
    $stmt = $pdo->prepare("INSERT INTO comment_rate_limits(actor_key,window_started_at,comment_count,updated_at)
        VALUES(?,NOW(),1,NOW())
        ON DUPLICATE KEY UPDATE
            comment_count = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL 10 MINUTE), 1, comment_count + 1),
            window_started_at = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL 10 MINUTE), NOW(), window_started_at),
            updated_at = NOW()");
    $stmt->execute([$actor]);
    $read = $pdo->prepare("SELECT comment_count, GREATEST(0, 600 - TIMESTAMPDIFF(SECOND, window_started_at, NOW())) AS retry_after FROM comment_rate_limits WHERE actor_key=? LIMIT 1");
    $read->execute([$actor]);
    $row = $read->fetch(PDO::FETCH_ASSOC) ?: ['comment_count'=>1,'retry_after'=>0];
    if ((int)$row['comment_count'] > 3) {
        http_response_code(429);
        echo json_encode([
            'success'=>false,
            'error'=>'برای جلوگیری از اسپم، هر کاربر در هر ۱۰ دقیقه حداکثر ۳ دیدگاه یا پاسخ می‌تواند ثبت کند.',
            'retry_after'=>max(1, (int)$row['retry_after'])
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}

// ========== توابع کمکی ==========
function validateCsrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function formatCommentDate($date, $lang) {
    if (empty($date)) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $timestamp = strtotime($date);
    if ($timestamp === false) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $diff = time() - $timestamp;
    if ($diff < 0) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if ($diff < 60) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ($lang === 'fa' ? ' دقیقه پیش' : ' minutes ago');
    if ($diff < 86400) return floor($diff / 3600) . ($lang === 'fa' ? ' ساعت پیش' : ' hours ago');
    if ($diff < 604800) return floor($diff / 86400) . ($lang === 'fa' ? ' روز پیش' : ' days ago');
    if ($diff < 2592000) return floor($diff / 604800) . ($lang === 'fa' ? ' هفته پیش' : ' weeks ago');
    if ($diff < 31536000) return floor($diff / 2592000) . ($lang === 'fa' ? ' ماه پیش' : ' months ago');
    return floor($diff / 31536000) . ($lang === 'fa' ? ' سال پیش' : ' years ago');
}

function renderStars($rating) {
    $full = (int)$rating;
    $empty = 5 - $full;
    $stars = '';
    for ($i = 0; $i < $full; $i++) {
        $stars .= '<svg class="star star-full" viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    }
    for ($i = 0; $i < $empty; $i++) {
        $stars .= '<svg class="star star-empty" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    }
    return $stars;
}

function getRepliesHTML($commentId, $currentUserId, $userLang, $isArchive1 = false) {
    global $pdo;
    if ($isArchive1) bm_ensure_archive1_comment_tables($pdo);
    $commentTable = bm_comment_table((bool)$isArchive1);
    $likeTable = bm_like_table((bool)$isArchive1);
    $stmt = $pdo->prepare("
        SELECT r.*, 
            COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'like'), 0) as like_count,
            COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'dislike'), 0) as dislike_count,
            COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = r.id AND user_id = ?), '') as user_vote,
            u.username, u.role, u.avatar
        FROM {$commentTable} r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = ? AND r.status = 'approved'
        ORDER BY r.created_at ASC
    ");
    $stmt->execute([$currentUserId, $commentId]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($replies)) return '';

    $html = '<div class="replies-container">';
    foreach ($replies as $reply) {
        $adminTick = ($reply['role'] === 'admin') ? '<svg class="admin-tick" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#36ff9f"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" fill="none"/></svg>' : '';
        $avatarHtml = (!empty($reply['avatar']) && file_exists($reply['avatar'])) ? '<img src="' . htmlspecialchars($reply['avatar']) . '" style="width:100%;height:100%;object-fit:cover;">' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        $replyText = nl2br(htmlspecialchars($reply['comment']));
        if ($reply['spoiler'] == 1) {
            $replyText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">' . $replyText . '</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
        }
        $html .= '<div class="reply-item" data-id="' . $reply['id'] . '">
            <div class="reply-header">
                <div class="reply-user">
                    <div class="reply-avatar">' . $avatarHtml . '</div>
                    <span class="reply-name">' . htmlspecialchars($reply['username']) . ' ' . $adminTick . '</span>
                </div>
                <span class="comment-date">' . formatCommentDate($reply['created_at'], $userLang) . '</span>
            </div>
            <div class="reply-text">' . $replyText . '</div>
            <div class="reply-actions">
                <div class="comment-like ' . ($reply['user_vote'] === 'like' ? 'active' : '') . '" data-id="' . $reply['id'] . '" data-type="like">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                    <span class="like-count">' . number_format($reply['like_count']) . '</span>
                </div>
                <div class="comment-dislike ' . ($reply['user_vote'] === 'dislike' ? 'active' : '') . '" data-id="' . $reply['id'] . '" data-type="dislike">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                    <span class="dislike-count">' . number_format($reply['dislike_count']) . '</span>
                </div>
            </div>
        </div>';
    }
    $html .= '</div>';
    return $html;
}

function renderCommentHTML($comment, $lang, $currentUserId, $isArchive1 = false) {
    global $currentUser; // دسترسی به متغیر سراسری برای نقش
    $adminTick = ($comment['role'] === 'admin') ? '<svg class="admin-tick" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#36ff9f"><path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" stroke="currentColor" stroke-width="2" fill="none"/></svg>' : '';
    $replyText = $lang === 'fa' ? 'پاسخ' : 'Reply';
    $replyCount = $comment['reply_count'] ?? 0;
    $replyCountHtml = $replyCount > 0 ? '<span class="reply-count">(' . $replyCount . ')</span>' : '';
    $avatarHtml = (!empty($comment['avatar']) && file_exists($comment['avatar'])) ? '<img src="' . htmlspecialchars($comment['avatar']) . '" style="width:100%;height:100%;object-fit:cover;">' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    $commentText = nl2br(htmlspecialchars($comment['comment']));
    if ($comment['spoiler'] == 1) {
        $commentText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">' . $commentText . '</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
    }
    $deleteBtn = '';
    if ($currentUserId && ($currentUserId == $comment['user_id'] || ($currentUser && $currentUser['role'] == 'admin'))) {
        $deleteBtn = '<button class="delete-comment-btn" data-id="' . $comment['id'] . '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>';
    }
    $repliesHtml = getRepliesHTML($comment['id'], $currentUserId, $lang, $isArchive1);
    return '<div class="comment-item" data-id="' . $comment['id'] . '" data-reply-count="' . $replyCount . '">
        <div class="comment-header">
            <div class="comment-user">
                <div class="comment-avatar-small">' . $avatarHtml . '</div>
                <div>
                    <div class="comment-name">' . htmlspecialchars($comment['username']) . ' ' . $adminTick . '</div>
                    <div class="comment-date">' . formatCommentDate($comment['created_at'], $lang) . '</div>
                </div>
            </div>
            <div class="comment-rating-stars">' . renderStars($comment['rating']) . '</div>
        </div>
        <div class="comment-text">' . $commentText . '</div>
        <div class="comment-actions">
            <div class="comment-like ' . ($comment['user_vote'] === 'like' ? 'active' : '') . '" data-id="' . $comment['id'] . '" data-type="like">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                <span class="like-count">' . number_format($comment['like_count']) . '</span>
            </div>
            <div class="comment-dislike ' . ($comment['user_vote'] === 'dislike' ? 'active' : '') . '" data-id="' . $comment['id'] . '" data-type="dislike">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                <span class="dislike-count">' . number_format($comment['dislike_count']) . '</span>
            </div>
            <button class="reply-btn" data-id="' . $comment['id'] . '">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <span>' . $replyText . '</span> ' . $replyCountHtml . '
            </button>
            ' . $deleteBtn . '
        </div>
        <div class="reply-form-container" id="reply-form-' . $comment['id'] . '" style="display:none;"></div>
        ' . $repliesHtml . '
    </div>';
}

try {
    switch ($action) {
        // ========== افزودن کامنت اصلی ==========
        case 'add_comment':
            // اعتبارسنجی CSRF
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $commentText = trim($_POST['comment'] ?? '');
            $rating = (int)($_POST['rating'] ?? 0);
            $spoiler = (int)($_POST['spoiler'] ?? 0);

            if (empty($commentText)) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً متن نظر را وارد کنید' : 'Please enter comment']);
                exit;
            }
            if (mb_strlen($commentText, 'UTF-8') < 3) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'نظر باید حداقل ۳ کاراکتر باشد' : 'Comment must be at least 3 characters']);
                exit;
            }
            if (mb_strlen($commentText, 'UTF-8') > 500) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'نظر نمی‌تواند بیشتر از ۵۰۰ کاراکتر باشد' : 'Comment cannot exceed 500 characters']);
                exit;
            }
            if ($rating < 0 || $rating > 5) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'امتیاز باید بین ۰ تا ۵ باشد' : 'Rating must be between 0 and 5']);
                exit;
            }

            $username = $currentUser ? $currentUser['username'] : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest');
            $userId = isset($currentUser['id']) ? (int)$currentUser['id'] : null;
            bm_comment_rate_limit($pdo, $userId);
            $status = ($currentUser && bm_comment_privileged_role((string)($currentUser['role'] ?? ''))) ? 'approved' : 'pending';

            $stmt = $pdo->prepare("INSERT INTO {$commentTable} (movie_id, user_id, username, comment, rating, spoiler, status, created_at, parent_id) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NULL)");
            $stmt->execute([$movieId, $userId, $username, $commentText, $rating, $spoiler, $status]);
            $newCommentId = $pdo->lastInsertId();

            // به‌روزرسانی امتیاز فیلم (فقط برای آرشیو ۲ / movie_id مثبت)
            // آرشیو ۱ از movie_id مجازی جداگانه استفاده می‌کند و نباید داخل جدول movie_ratings آرشیو ۲ ثبت شود.
            if ($movieId > 0 && !$isArchive1Comment) {
                $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM comments WHERE movie_id = ? AND rating > 0 AND status = 'approved' AND parent_id IS NULL");
                $stmt->execute([$movieId]);
                $ratingData = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt = $pdo->prepare("INSERT INTO movie_ratings (movie_id, avg_rating, total_votes) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE avg_rating = ?, total_votes = ?");
                $stmt->execute([$movieId, $ratingData['avg_rating'] ?? 0, $ratingData['total_votes'] ?? 0, $ratingData['avg_rating'] ?? 0, $ratingData['total_votes'] ?? 0]);
            }

            $message = ($status === 'pending')
                ? ($userLang === 'fa' ? 'نظر شما پس از تأیید ادمین نمایش داده می‌شود' : 'Your comment will appear after admin approval')
                : ($userLang === 'fa' ? 'نظر شما با موفقیت ثبت شد' : 'Comment submitted');
            echo json_encode([
                'success' => true,
                'message' => $message,
                'approved' => ($status === 'approved'),
                'comment' => [
                    'id' => $newCommentId,
                    'username' => $username,
                    'comment' => $commentText,
                    'rating' => $rating,
                    'spoiler' => $spoiler,
                    'role' => $currentUser['role'] ?? 'user',
                    'avatar' => $currentUser['avatar'] ?? '',
                    'user_id' => $userId
                ]
            ]);
            break;

        // ========== افزودن پاسخ ==========
        case 'add_reply':
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $parentId = (int)($_POST['parent_id'] ?? 0);
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $commentText = trim($_POST['comment'] ?? '');
            $guestName = trim($_POST['username'] ?? '');

            if (empty($commentText)) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً متن پاسخ را وارد کنید' : 'Please enter reply']);
                exit;
            }
            if (mb_strlen($commentText, 'UTF-8') < 3) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'پاسخ باید حداقل ۳ کاراکتر باشد' : 'Reply must be at least 3 characters']);
                exit;
            }

            $stmt = $pdo->prepare("SELECT id FROM {$commentTable} WHERE id = ? AND status != 'deleted'");
            $stmt->execute([$parentId]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'کامنت اصلی یافت نشد یا حذف شده است' : 'Parent comment not found or deleted']);
                exit;
            }

            if ($currentUser) {
                $userId = (int)$currentUser['id'];
                $displayName = $currentUser['username'];
                $status = bm_comment_privileged_role((string)($currentUser['role'] ?? '')) ? 'approved' : 'pending';
            } else {
                if (empty($guestName)) {
                    echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً نام خود را وارد کنید' : 'Please enter your name']);
                    exit;
                }
                if (mb_strlen($guestName, 'UTF-8') < 2 || mb_strlen($guestName, 'UTF-8') > 50) {
                    echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'نام باید بین ۲ تا ۵۰ کاراکتر باشد' : 'Name must be 2-50 characters']);
                    exit;
                }
                $userId = null;
                $displayName = htmlspecialchars($guestName, ENT_QUOTES, 'UTF-8');
                $status = 'pending';
            }

            bm_comment_rate_limit($pdo, $userId !== null ? (int)$userId : null);
            $stmt = $pdo->prepare("INSERT INTO {$commentTable} (movie_id, user_id, username, comment, parent_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$movieId, $userId, $displayName, $commentText, $parentId, $status]);

            $message = ($status === 'pending')
                ? ($userLang === 'fa' ? 'پاسخ شما پس از تأیید ادمین نمایش داده می‌شود' : 'Your reply will appear after approval')
                : ($userLang === 'fa' ? 'پاسخ شما با موفقیت ثبت شد' : 'Reply posted');
            echo json_encode(['success' => true, 'message' => $message, 'approved' => ($status === 'approved')]);
            break;

        // ========== دریافت پاسخ‌ها ==========
        case 'get_replies':
            $commentId = (int)($_GET['comment_id'] ?? 0);
            $isArchive1Comment = (($_GET['archive'] ?? $_POST['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $likeTable = bm_like_table($isArchive1Comment);
            if (!$commentId) {
                echo json_encode(['success' => false, 'error' => 'Invalid comment ID']);
                exit;
            }
            $stmt = $pdo->prepare("
                SELECT c.*,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                    COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = c.id AND user_id = ?), '') as user_vote,
                    u.role, u.avatar
                FROM {$commentTable} c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.parent_id = ? AND c.status = 'approved'
                ORDER BY c.created_at ASC
            ");
            $stmt->execute([$currentUser['id'] ?? 0, $commentId]);
            $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'replies' => $replies]);
            break;

        // ========== لایک / دیسلایک ==========
        case 'vote':
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            if (!$currentUser) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login']);
                exit;
            }
            $commentId = (int)($_POST['comment_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $likeTable = bm_like_table($isArchive1Comment);
            $voteType = $_POST['type'] ?? '';
            if (!in_array($voteType, ['like', 'dislike'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid vote type']);
                exit;
            }

            $stmt = $pdo->prepare("SELECT type FROM {$likeTable} WHERE comment_id = ? AND user_id = ?");
            $stmt->execute([$commentId, $currentUser['id']]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                if ($existing['type'] === $voteType) {
                    $stmt = $pdo->prepare("DELETE FROM {$likeTable} WHERE comment_id = ? AND user_id = ?");
                    $stmt->execute([$commentId, $currentUser['id']]);
                } else {
                    $stmt = $pdo->prepare("UPDATE {$likeTable} SET type = ? WHERE comment_id = ? AND user_id = ?");
                    $stmt->execute([$voteType, $commentId, $currentUser['id']]);
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO {$likeTable} (comment_id, user_id, type) VALUES (?, ?, ?)");
                $stmt->execute([$commentId, $currentUser['id'], $voteType]);
            }

            $stmt = $pdo->prepare("
                SELECT
                    COUNT(CASE WHEN type = 'like' THEN 1 END) as likes,
                    COUNT(CASE WHEN type = 'dislike' THEN 1 END) as dislikes,
                    (SELECT type FROM {$likeTable} WHERE comment_id = ? AND user_id = ?) as user_vote
                FROM {$likeTable}
                WHERE comment_id = ?
            ");
            $stmt->execute([$commentId, $currentUser['id'], $commentId]);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode([
                'success' => true,
                'likes' => (int)$stats['likes'],
                'dislikes' => (int)$stats['dislikes'],
                'user_vote' => $stats['user_vote'] ?? ''
            ]);
            break;

        // ========== حذف کامنت ==========
        case 'delete_comment':
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            if (!$currentUser) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login']);
                exit;
            }
            $commentId = (int)($_POST['comment_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);

            $stmt = $pdo->prepare("SELECT user_id FROM {$commentTable} WHERE id = ?");
            $stmt->execute([$commentId]);
            $commentOwner = $stmt->fetchColumn();
            if ($currentUser['role'] !== 'admin' && $currentUser['id'] != $commentOwner) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'شما مجاز به حذف این کامنت نیستید' : 'You are not allowed to delete this comment']);
                exit;
            }

            // حذف نرم
            $stmt = $pdo->prepare("UPDATE {$commentTable} SET status = 'deleted' WHERE id = ?");
            $stmt->execute([$commentId]);
            $stmt = $pdo->prepare("UPDATE {$commentTable} SET status = 'deleted' WHERE parent_id = ?");
            $stmt->execute([$commentId]);

            echo json_encode(['success' => true, 'message' => $userLang === 'fa' ? 'کامنت با موفقیت حذف شد' : 'Comment deleted successfully', 'deleted_top_level' => true]);
            break;

        // ========== بارگذاری بیشتر کامنت‌ها ==========
        case 'load_more_comments':
            // CSRF check for POST, but GET is fine for reading
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && !validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $page = (int)($_POST['page'] ?? 1);
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $likeTable = bm_like_table($isArchive1Comment);
            $offset = ($page - 1) * $commentsPerPage;

            $stmt = $pdo->prepare("
                SELECT c.*,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                    COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = c.id AND user_id = ?), '') as user_vote,
                    (SELECT COUNT(*) FROM {$commentTable} WHERE parent_id = c.id AND status = 'approved') as reply_count,
                    u.role, u.avatar
                FROM {$commentTable} c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.movie_id = ? AND c.parent_id IS NULL AND c.status = 'approved'
                ORDER BY c.created_at DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$currentUser['id'] ?? 0, $movieId, $commentsPerPage, $offset]);
            $moreComments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $html = '';
            foreach ($moreComments as $comment) {
                $html .= renderCommentHTML($comment, $userLang, $currentUser['id'] ?? 0, $isArchive1Comment);
            }

            $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM {$commentTable} WHERE movie_id = ? AND parent_id IS NULL AND status = 'approved'");
            $totalStmt->execute([$movieId]);
            $total = (int)$totalStmt->fetchColumn();
            $hasMore = ($page * $commentsPerPage) < $total;

            echo json_encode(['success' => true, 'html' => $html, 'has_more' => $hasMore]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'درخواست نامعتبر است یا اکشن ارسال نشده' : 'Invalid request or missing action', 'received_action' => $action]);
    }
} catch (Exception $e) {
    error_log("ajax_comments error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>