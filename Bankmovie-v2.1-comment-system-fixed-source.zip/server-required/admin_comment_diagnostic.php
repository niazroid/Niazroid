<?php
declare(strict_types=1);
@ini_set('display_errors','0');
require_once __DIR__ . '/config.php';
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$u = $currentUser ?? null;
if (!$u && !empty($_COOKIE['session_token']) && isset($user) && is_object($user) && method_exists($user,'checkSession')) {
    try { $u = $user->checkSession((string)$_COOKIE['session_token']); } catch(Throwable $e) { $u = null; }
}
if (!is_array($u) || strtolower((string)($u['role'] ?? '')) !== 'admin') {
    http_response_code(403); exit('Admin only');
}
header('Content-Type: text/html; charset=utf-8');
function e($v){ return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function table_exists(PDO $pdo,string $t):bool{
    try{$s=$pdo->prepare("SHOW TABLES LIKE ?");$s->execute([$t]);return (bool)$s->fetchColumn();}catch(Throwable $e){return false;}
}
$tables=['comments','archive1_comments','comment_likes','archive1_comment_likes','archive1_items','comment_rate_limits'];
$databaseName='';
try { $databaseName=(string)$pdo->query('SELECT DATABASE()')->fetchColumn(); } catch(Throwable $e) {}
$currentHost=(string)($_SERVER['HTTP_HOST'] ?? '');
$remoteAccountApi='';
try {
    $cfgFile=__DIR__ . '/bankmovie_remote_config.json';
    if(is_file($cfgFile)) {
        $cfg=json_decode((string)file_get_contents($cfgFile),true);
        if(is_array($cfg)) $remoteAccountApi=(string)($cfg['account_api_url'] ?? '');
    }
} catch(Throwable $e) {}
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>تشخیص کامنت اپ</title>
<style>body{background:#0b0d12;color:#eee;font-family:tahoma;padding:24px}.c{background:#151923;border:1px solid #2b3342;border-radius:16px;padding:18px;margin:12px 0}table{width:100%;border-collapse:collapse}td,th{padding:10px;border-bottom:1px solid #333;text-align:right}.ok{color:#51d88a}.bad{color:#ff6b6b}</style>
<h1>تشخیص کامنت‌های اپ و آرشیو ۱</h1>
<div class="c"><b>دامنه فعلی:</b> <?=e($currentHost)?> — <b>دیتابیس:</b> <?=e($databaseName ?: 'نامشخص')?> — <b>Account API:</b> <?=e($remoteAccountApi ?: 'بر اساس دامنه فعال')?></div>
<?php foreach($tables as $t): $exists=table_exists($pdo,$t); ?>
<div class="c"><b><?=e($t)?></b> — <span class="<?=$exists?'ok':'bad'?>"><?=$exists?'موجود':'پیدا نشد'?></span>
<?php if($exists): try{$n=(int)$pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();echo ' — تعداد: '.number_format($n);}catch(Throwable $x){echo ' — خطا: '.e($x->getMessage());} endif; ?></div>
<?php endforeach; ?>
<?php if(table_exists($pdo,'archive1_comments')): 
$rows=$pdo->query("SELECT id,movie_id,user_id,username,status,created_at,LEFT(comment,120) comment FROM archive1_comments ORDER BY id DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC)?:[]; ?>
<div class="c"><h2>۵۰ کامنت آخر آرشیو ۱</h2><table><tr><th>ID</th><th>movie_id</th><th>کاربر</th><th>وضعیت</th><th>زمان</th><th>متن</th></tr>
<?php foreach($rows as $r):?><tr><td><?=e($r['id'])?></td><td><?=e($r['movie_id'])?></td><td><?=e($r['username'])?></td><td><?=e($r['status'])?></td><td><?=e($r['created_at'])?></td><td><?=e($r['comment'])?></td></tr><?php endforeach;?></table></div>
<?php endif; ?></html>