رفع نهایی اتصال کامنت اپ و سایت

فایل‌های سمت سایت که باید با حفظ config.php فعلی جایگزین شوند:
- app_user_api.php
- ajax_comments.php
- admin.php
- movie.php
- app_config.php
- bankmovie_remote_config.json (در صورت استفاده از همین فایل تنظیمات)

اصلاحات:
- اتصال API حساب و کامنت به همان دامنه فعال سایت/پنل
- جدول مشترک archive1_comments بین اپ، سایت و admin.php
- رفع خطای پارامتر SQL هنگام مشاهده کامنت بدون ورود
- وضعیت pending برای کاربران عادی و تأیید خودکار فقط مدیر/ویژه
- محدودیت ۳ کامنت یا پاسخ در ۱۰ دقیقه
- همسان‌سازی شناسه مجازی و archive_no

هشدار: config.php، کلید HMAC، keystore و تنظیمات امضای Gradle را جایگزین یا حذف نکنید.
