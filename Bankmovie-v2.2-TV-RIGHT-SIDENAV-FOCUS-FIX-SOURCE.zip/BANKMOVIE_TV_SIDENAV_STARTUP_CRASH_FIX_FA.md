# BankMovie TV SideNav Startup Crash Fix

علت کرش بعد از Splash/Loading، استفاده از `View.setTag(android.R.id.custom, animator)` در انیمیشن عرض منوی TV بود.
Android برای `setTag(key, value)` کلید application resource می‌خواهد و کلید `android.R.id.*` می‌تواند در Runtime با `IllegalArgumentException` باعث بسته‌شدن Activity شود.

اصلاح:
- Animator منوی TV دیگر داخل View tag ذخیره نمی‌شود.
- یک فیلد داخلی `tvSideNavWidthAnimator` برای cancel/reuse انیمیشن استفاده می‌شود.
- ظاهر منوی کناری، فوکوس اولیه روی Menu و Focus row-aware بدون تغییر باقی مانده‌اند.
