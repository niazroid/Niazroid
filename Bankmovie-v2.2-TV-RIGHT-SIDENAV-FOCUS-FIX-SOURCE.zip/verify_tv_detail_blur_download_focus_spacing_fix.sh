#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
down='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
for marker in \
  'val usePosterBackdrop = !hasRealBackdrop' \
  'detailArchiveForArtwork in setOf(2, 3, 4)' \
  'createBlurEffect(' \
  'marginEnd = dp(26)' \
  'applyTvFocusHalo(this, 24, 1.018f, elevation)' \
  'detailLatestUpdatePill(item)?.let { updatePill ->'
do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
for marker in \
  'tag = "bm_download_action_row"' \
  'private fun bindDownloadActionVerticalFocus(row: LinearLayout)' \
  'KEYCODE_DPAD_DOWN' \
  'KEYCODE_DPAD_UP' \
  'target.requestFocus()'
do
  grep -Fq "$marker" "$down" || { echo "Missing marker: $marker" >&2; exit 1; }
done
printf '%s\n' 'TV_DETAIL_BLUR_DOWNLOAD_FOCUS_SPACING_FIX_OK'
