#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private var tvSideNavDocked = false' \
  'private fun setTvSideNavDocked(docked: Boolean)' \
  'setTvSideNavDocked(sy >= heroExit.coerceAtLeast(dp(220)))' \
  'val homeBody = if (tv) LinearLayout(this).apply {' \
  'setPadding(0, 0, tvHomeRailContentInset(), 0)' \
  'val railInset = if (tvList) tvSideNavCollapsedWidth() + dp(14) else 0' \
  'val links = qualityOnlyLinks(playableLinks(item))' \
  'val downloadable = qualityOnlyLinks(links.filter { downloadUrl(it).isNotBlank() })' \
  'val visibleLinks = qualityOnlyLinks(links)' \
  'val cleanEpisodeLinks = qualityOnlyLinks(epLinks)'
do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
printf '%s\n' 'TV_RAIL_WATCHLIST_DOWNLOAD_DEDUP_FIX_OK'
