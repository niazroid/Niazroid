# BankMovie Android v2.2 — TV Filmio Edge Menu / Profile / VIP Days Fix

این نسخه روی سورس HOME-MENU-COLLECTION-EPISODE-FIX ساخته شده است.

## تغییرات TV
- Home دیگر برای ناوبری TV فضای خالی سمت راست رزرو نمی‌کند؛ Hero تا لبه راست و زیر Rail ادامه دارد.
- Rail جمع‌شده فقط یک Vignette بسیار شفاف روی تصویر است و ستون مشکی مستقل نیست.
- Focus آیتم‌های منو دیگر Halo/Capsule بزرگ ندارد؛ آیکن و متن با رنگ/Scale کوچک مشخص می‌شوند.
- با ورود واقعی کاربر به هر آیتم منو، Drawer باز می‌شود و Label همه دکمه‌ها دیده می‌شود.
- Auto-focus بعد از تعویض صفحه دیگر Drawer را خودکار باز نمی‌کند؛ فوکوس به محتوای صفحه برمی‌گردد.
- روی Home بازگشت از منو اول دکمه Watch Now اسلایدر را می‌گیرد، بعد Archive selector.
- Downloads به منوی TV اضافه شد.
- فاصله IMDb و Watch Now در Hero بیشتر شد.
- صفحات غیر Home یک Safe inset به اندازه Rail جمع‌شده دارند تا محتوای Profile/Search/... زیر منو نرود.

## VIP remaining days — Android + Server
برای نمایش روزهای واقعی باقی‌مانده، endpoint اپ نیز تغییر کرده است:

`server-required/app_user_api.php`

فیلدهای جدید user response:
- `vip_expires_at`
- `vip_lifetime`
- `vip_remaining_days`

Android این مقدار را در:
- Profile card روی Mobile و TV
- Drawer موبایل
- Account summary در TV drawer
- Tile خرید/تمدید VIP
نمایش می‌دهد.

> مهم: برای نمایش عدد واقعی روزهای باقی‌مانده، فایل `server-required/app_user_api.php` همین نسخه باید روی سرور جایگزین endpoint فعلی شود. بدون آپدیت سرور، اپ فقط متن «VIP فعال» را به عنوان fallback نشان می‌دهد.

## Verification
- `php -l server-required/app_user_api.php` PASS
- Kotlin PSI syntax: 33 فایل، 0 خطای Syntax
- `verify_release.sh` PASS
- `verify_tv_right_sidenav_focus_fix.sh` PASS
- `verify_tv_filmio_glass_polish.sh` PASS
- `verify_tv_home_focus_menu_collection_episode_fix.sh` PASS
- `verify_tv_edge_menu_profile_vip_days_fix.sh` PASS
- مقایسه Verifyهای قدیمی: هیچ تستی که در baseline PASS بوده در این نسخه FAIL نشده است.
