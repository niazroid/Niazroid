#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private fun buildTvSideNavigation()' \
  'private fun tvFocusRows(nodes: List<TvFocusNode>)' \
  'private fun handleTvDirectionalFocus(keyCode: Int)' \
  'private fun requestTvSideNavFocus(preferMenu: Boolean = false)' \
  'FrameLayout.LayoutParams(dp(82), -1, Gravity.RIGHT or Gravity.CENTER_VERTICAL)' \
  'tvInitialMenuFocusShown' \
  'setTag(R.id.bm_tv_item_json, item.toString())'; do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
bash verify_release.sh >/dev/null
echo 'TV_RIGHT_SIDENAV_FOCUS_FIX_OK'
