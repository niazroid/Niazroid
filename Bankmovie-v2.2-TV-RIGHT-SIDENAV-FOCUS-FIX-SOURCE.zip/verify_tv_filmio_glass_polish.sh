#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private fun tvSideNavCollapsedWidth(): Int = dp(76)' \
  'private fun tvSideNavExpandedWidth(): Int' \
  'private fun tvSideNavGlassDrawable(expanded: Boolean)' \
  'VIP subscription active' \
  'Focusing ordinary icons must NOT force-open the drawer.' \
  'root.addView(bottomNav, FrameLayout.LayoutParams(tvSideNavCollapsedWidth(), -1, Gravity.RIGHT))' \
  'if (tv) setPadding(0, 0, 0, 0)' \
  'resources.displayMetrics.heightPixels * 0.70f' \
  'leftMargin = -dp(12)' \
  'rightMargin = -dp(12)' \
  'rightMargin = tvSideNavCollapsedWidth() + dp(22)'; do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
if grep -Fq 'if (has) {' "$main" && grep -Fq 'if (key != "__menu__") tvSideNavActiveItem = this' "$main"; then
  echo 'Old auto-open/active-focus behavior still present' >&2
  exit 1
fi
bash verify_tv_right_sidenav_focus_fix.sh >/dev/null
bash verify_release.sh >/dev/null
echo 'TV_FILMIO_GLASS_POLISH_OK'
