#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private fun tvSideNavCollapsedWidth(): Int = dp(76)' \
  'private fun tvSideNavExpandedWidth(): Int' \
  'private fun tvSideNavGlassDrawable(expanded: Boolean)' \
  'Filmio-like navigation: no large focus capsule around every icon.' \
  'root.addView(bottomNav, FrameLayout.LayoutParams(tvSideNavCollapsedWidth(), -1, Gravity.RIGHT))' \
  'resources.displayMetrics.heightPixels * 0.70f' \
  'leftMargin = -dp(12)' \
  'rightMargin = -dp(12)' \
  'rightMargin = tvSideNavCollapsedWidth() + dp(22)'; do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
bash verify_tv_right_sidenav_focus_fix.sh >/dev/null
bash verify_release.sh >/dev/null
echo 'TV_FILMIO_GLASS_POLISH_OK'
