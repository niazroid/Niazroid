#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private val tvSideNavExpandedOnlyItems = mutableListOf<View>()' \
  'private fun tvHomeRailContentInset(): Int = tvSideNavCollapsedWidth() + dp(14)' \
  'val compactKeys = setOf("home", "search", "categories", "profile", "favorites")' \
  'compactVisible = key in compactKeys' \
  'tvSideNavExpandedOnlyItems.forEach { reveal(it, expanded' \
  'val rightInset = if (tv) dp(12) + tvHomeRailContentInset() else dp(12)' \
  'rightMargin = -(dp(12) + tvHomeRailContentInset())'
do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
printf '%s\n' 'TV_MINIMAL_RAIL_CONTENT_INSET_OK'
