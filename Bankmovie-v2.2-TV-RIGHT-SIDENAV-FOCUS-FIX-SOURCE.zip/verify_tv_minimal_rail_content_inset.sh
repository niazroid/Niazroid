#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
for marker in \
  'private val tvSideNavExpandedOnlyItems = mutableListOf<View>()' \
  'private fun tvHomeRailContentInset(): Int = tvSideNavCollapsedWidth() + dp(14)' \
  'val compactKeys = setOf("home", "search", "categories", "profile", "favorites")' \
  'compactVisible = key in compactKeys' \
  'tvSideNavExpandedOnlyItems.forEach { reveal(it, expanded' \
  'val homeBody = if (tv) LinearLayout(this).apply {' \
  'setPadding(0, 0, tvHomeRailContentInset(), 0)' \
  'rightMargin = -dp(12)'
do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
printf '%s\n' 'TV_MINIMAL_RAIL_CONTENT_INSET_OK'
