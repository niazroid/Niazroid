# BankMovie TV — Minimal Rail + Content Inset

این مرحله فقط رابط کاربری و فوکوس ناوبری TV را روی آخرین نسخه پایدار اصلاح می‌کند.

## تغییرات

- Rail بسته فقط آیتم‌های اصلی را نشان می‌دهد: خانه، جستجو، دسته‌بندی، پروفایل و علاقه‌مندی‌ها.
- Box Office، Watch Party و دانلودها حذف نشده‌اند؛ فقط در حالت بازشدۀ منو نمایش داده می‌شوند.
- کارت حساب کاربر و جداکننده نیز فقط در حالت باز دیده می‌شوند.
- Hero صفحه اصلی همچنان Full-Bleed است و زیر Rail ادامه دارد.
- محتوای پایین Hero (آرشیوها، ریل فیلم‌ها، کالکشن‌ها و...) از سمت راست به اندازۀ Rail فاصله می‌گیرد تا آیکن‌های منو روی کاورها نیفتند.
- منطق Focus Fix، Startup Crash Fix، Collection Fix، Episode Fix و VIP Days دست‌نخورده باقی مانده‌اند.

## تست

- verify_release.sh: PASS
- verify_tv_right_sidenav_focus_fix.sh: PASS
- verify_tv_filmio_glass_polish.sh: PASS
- verify_tv_home_focus_menu_collection_episode_fix.sh: PASS
- verify_tv_edge_menu_profile_vip_days_fix.sh: PASS
- verify_tv_minimal_rail_content_inset.sh: PASS
