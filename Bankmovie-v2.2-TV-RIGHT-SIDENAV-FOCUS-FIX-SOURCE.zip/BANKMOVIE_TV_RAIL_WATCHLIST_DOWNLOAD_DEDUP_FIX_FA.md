# BankMovie TV Rail / Watchlist / Download Dedup Fix

این اصلاح روی آخرین سورس TV اعمال شده و سه مورد را هدف می‌گیرد:

- Hero صفحه Home همچنان full-bleed و زیر Rail باقی می‌ماند، اما تمام محتوای بعد از Hero داخل `homeBody` با فضای رزروشده برای Rail رندر می‌شود. هنگام خروج از Hero، Rail به حالت docked glass می‌رود تا روی پوسترها نیفتد.
- Watchlist در TV عرض کارت‌ها را بر اساس viewport واقعی بعد از کسر Rail محاسبه می‌کند؛ بنابراین کارت ستون چپ دیگر از صفحه بیرون نمی‌زند.
- لینک‌های پخش/دانلود قبل از نمایش کیفیت‌ها بر اساس فصل، قسمت، نوع نسخه و کیفیت normalize/dedupe می‌شوند. Softsub و کیفیت‌های تکراری دیگر چند بار در UI ظاهر نمی‌شوند.

Focus Fix، SideNav، VIP Days، Collection Fix و Episode collapse قبلی حفظ شده‌اند.
