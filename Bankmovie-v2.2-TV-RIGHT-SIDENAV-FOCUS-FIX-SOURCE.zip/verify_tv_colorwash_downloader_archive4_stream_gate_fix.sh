#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
down='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
api='server-required/app_api.php'
api4='server-required/includes/api4_lib.php'
for marker in \
  'detailArchiveForArtwork in setOf(2, 3, 4)' \
  'val targetMax = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) 6 else 3' \
  'createBlurEffect(' \
  '82f,' \
  'private fun tvGridOrderedItems(items: JSONArray, columns: Int)' \
  'path.startsWith("arc4-", true) -> 4' \
  'if (vipDownloadGate || item.optBoolean("downloads_locked", false))'
do grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }; done
for marker in \
  'private fun bindDownloadsTvFocusChain()' \
  'private fun visibleDownloadActionRows()' \
  'downloads:bulk-import' \
  'location:close' \
  'bindDownloadsTvFocusChain()'
do grep -Fq "$marker" "$down" || { echo "Missing marker: $marker" >&2; exit 1; }; done
for marker in \
  "bm_app_require_site_lib('api4_lib.php')" \
  'function bm_app_archive4_section' \
  'api4_search($params)' \
  'api4_get_details($identifier)' \
  "(string)\$archive === '4' ? '4'"
do grep -Fq "$marker" "$api" || { echo "Missing marker: $marker" >&2; exit 1; }; done
test -s "$api4"
printf '%s\n' 'TV_COLORWASH_DOWNLOADER_ARCHIVE4_STREAM_GATE_FIX_OK'
