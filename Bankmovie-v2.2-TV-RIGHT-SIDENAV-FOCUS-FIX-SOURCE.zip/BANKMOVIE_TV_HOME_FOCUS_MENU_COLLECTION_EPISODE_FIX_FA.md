# BankMovie TV — Home Focus / Menu / Collection / Episode Fix

این بسته روی نسخه TV Filmio Glass + Startup CrashFix ساخته شده و فقط رفتار TV/DPAD و ظاهر Rail را اصلاح می‌کند.

## تغییرات
- فوکوس اولیه Home روی دکمه پخش اسلایدر است؛ Drawer در شروع برنامه باز نمی‌شود.
- اسکرول Home بعد از فوکوس اولیه روی ابتدای صفحه قفل می‌شود تا به Weekly Schedule نپرد.
- Rail بسته شفاف‌تر شده تا تصویر Hero زیر منو ادامه پیدا کند و نوار مشکی کنار آن دیده نشود.
- آیکن‌های Rail در حالت بسته در مرکز هاله فوکوس قرار می‌گیرند.
- ردیف حساب کاربری در منوی باز فوکوس‌پذیر و قابل انتخاب است؛ مهمان به Login/Register و کاربر لاگین‌شده به Profile می‌رود.
- Box Office و Watch Party به منوی TV اضافه شدند.
- حرکت بالا/پایین داخل Rail فقط بین ردیف‌های واقعاً Visible انجام می‌شود و روی ردیف مخفی Login نمی‌پرد.
- کارت‌های Collection به Focus Group رسانه‌ها اضافه شدند تا حرکت بین Railهای Home از روی کالکشن نپرد.
- هیچ قسمت سریالی، از جمله قسمت ۱، کیفیت‌هایش را خودکار باز نمی‌کند؛ باز شدن فقط با OK کاربر انجام می‌شود.

## مواردی که دست نخورده‌اند
- Mobile navigation
- Player
- API / Account API
- Download engine
- Watch Party backend
- Archive data logic

## Verify
- `verify_release.sh`
- `verify_tv_right_sidenav_focus_fix.sh`
- `verify_tv_filmio_glass_polish.sh`
- `verify_tv_home_focus_menu_collection_episode_fix.sh`
