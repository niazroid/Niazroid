#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
api='server-required/app_user_api.php'
markers=(
  'currentScreen == "home" -> 0'
  'Filmio-like navigation: no large focus capsule around every icon.'
  'if (System.currentTimeMillis() >= tvSideNavSuppressExpandUntil)'
  'Triple(t("دانلودها", "Downloads"), Pair("downloads", R.drawable.ic_download)'
  'accountVipStatusText(user, compact = true)'
  'marginStart = dp(20)'
)
for marker in "${markers[@]}"; do
  grep -Fq "$marker" "$main" || { echo "Missing marker: $marker" >&2; exit 1; }
done
grep -Fq 'vip_remaining_days' "$api" || { echo 'Missing API vip_remaining_days' >&2; exit 1; }
php -l "$api" >/dev/null
bash verify_tv_home_focus_menu_collection_episode_fix.sh >/dev/null
bash verify_release.sh >/dev/null
echo 'TV_EDGE_MENU_PROFILE_VIP_DAYS_FIX_OK'
