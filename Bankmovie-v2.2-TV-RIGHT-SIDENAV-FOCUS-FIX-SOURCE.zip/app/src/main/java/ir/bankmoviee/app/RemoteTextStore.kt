package ir.bankmoviee.app

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.EditText
import android.widget.TextView
import org.json.JSONObject
import java.util.Calendar
import java.util.Collections
import java.util.Locale
import java.util.WeakHashMap

/**
 * Remote, future-proof UI text controller.
 *
 * The public app_config.php can provide:
 * ui: {
 *   display_year: 0,        // 0 = device/current year
 *   search_max_year: 0,     // 0 = device/current year
 *   text_overrides: {
 *     fa: { "متن فعلی": "متن جدید" },
 *     en: { "Current text": "New text" }
 *   }
 * }
 *
 * Values support {{year}}, {{prev_year}} and {{next_year}} placeholders.
 * Exact replacements are also applied to TextView text/hints in every Activity,
 * so legacy hard-coded labels remain remotely controllable without forcing an APK update.
 */
object RemoteTextStore {
    private const val PREFS = "bm_remote_ui_texts_v1"
    private const val KEY_PAYLOAD = "payload"
    private const val MAX_ITEMS = 800
    private const val MAX_TEXT = 1600

    private val lock = Any()
    private val installed = Collections.synchronizedMap(WeakHashMap<Activity, Boolean>())
    @Volatile private var loaded = false
    @Volatile private var faOverrides: Map<String, String> = emptyMap()
    @Volatile private var enOverrides: Map<String, String> = emptyMap()
    @Volatile private var configuredDisplayYear: Int = 0
    @Volatile private var configuredSearchMaxYear: Int = 0

    fun applyConfig(context: Context, root: JSONObject) {
        val ui = root.optJSONObject("ui") ?: JSONObject()
        val textRoot = ui.optJSONObject("text_overrides")
            ?: root.optJSONObject("text_overrides")
            ?: root.optJSONObject("texts")
            ?: JSONObject()
        val packed = JSONObject().apply {
            put("display_year", ui.optInt("display_year", root.optInt("display_year", 0)))
            put("search_max_year", ui.optInt("search_max_year", root.optInt("search_max_year", 0)))
            put("text_overrides", textRoot)
        }
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PAYLOAD, packed.toString()).apply()
        synchronized(lock) {
            loadPayload(packed)
            loaded = true
        }
        Handler(Looper.getMainLooper()).post { refreshInstalledActivities() }
    }

    fun resolve(context: Context, fa: String, en: String): String {
        ensureLoaded(context)
        val lang = currentLanguage(context)
        return resolveDisplayed(context, if (lang == "en") en else fa, lang)
    }

    fun resolveDisplayed(context: Context, raw: String, language: String? = null): String {
        ensureLoaded(context)
        if (raw.isEmpty()) return raw
        val lang = language ?: currentLanguage(context)
        val primary = if (lang == "en") enOverrides else faOverrides
        val secondary = if (lang == "en") faOverrides else enOverrides
        val exact = primary[raw] ?: secondary[raw]
        if (exact != null) return expandYearTokens(context, exact)
        return expandLegacyYearText(context, raw)
    }

    fun displayYear(context: Context): Int {
        ensureLoaded(context)
        val configured = configuredDisplayYear
        return if (configured in 2000..2200) configured else Calendar.getInstance().get(Calendar.YEAR)
    }

    fun searchMaxYear(context: Context): Int {
        ensureLoaded(context)
        val configured = configuredSearchMaxYear
        return if (configured in 2000..2200) configured else displayYear(context)
    }

    fun install(activity: Activity) {
        synchronized(installed) {
            if (installed.containsKey(activity)) return
            installed[activity] = true
        }
        ensureLoaded(activity)
        val decor = activity.window?.decorView ?: return
        var pending = false
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            if (!hasTextOverrides() || pending) return@OnGlobalLayoutListener
            pending = true
            decor.post {
                pending = false
                applyToTree(activity, decor)
            }
        }
        decor.viewTreeObserver.addOnGlobalLayoutListener(listener)
        if (hasTextOverrides()) decor.post { applyToTree(activity, decor) }
    }

    fun applyToTree(context: Context, root: View?) {
        if (root == null || !hasTextOverrides()) return
        if (root is TextView) {
            // Never rewrite text typed by the user in EditText fields; only UI labels.
            if (root !is EditText) {
                val current = root.text?.toString().orEmpty()
                if (current.isNotEmpty()) {
                    val replacement = resolveDisplayed(context, current)
                    if (replacement != current) root.text = replacement
                }
            }
            val hint = root.hint?.toString().orEmpty()
            if (hint.isNotEmpty()) {
                val replacement = resolveDisplayed(context, hint)
                if (replacement != hint) root.hint = replacement
            }
            val description = root.contentDescription?.toString().orEmpty()
            if (description.isNotEmpty()) {
                val replacement = resolveDisplayed(context, description)
                if (replacement != description) root.contentDescription = replacement
            }
        }
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) applyToTree(context, root.getChildAt(i))
        }
    }

    private fun hasTextOverrides(): Boolean = faOverrides.isNotEmpty() || enOverrides.isNotEmpty()

    private fun refreshInstalledActivities() {
        if (!hasTextOverrides()) return
        val snapshot = synchronized(installed) { installed.keys.toList() }
        snapshot.forEach { activity ->
            runCatching { applyToTree(activity, activity.window?.decorView) }
        }
    }

    private fun currentLanguage(context: Context): String {
        val value = context.getSharedPreferences("bm_smart_cinema", Context.MODE_PRIVATE)
            .getString("lang_code", "fa").orEmpty().lowercase(Locale.US)
        return if (value == "en") "en" else "fa"
    }

    private fun ensureLoaded(context: Context) {
        if (loaded) return
        synchronized(lock) {
            if (loaded) return
            val raw = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_PAYLOAD, "").orEmpty()
            val json = runCatching { if (raw.isBlank()) JSONObject() else JSONObject(raw) }.getOrElse { JSONObject() }
            loadPayload(json)
            loaded = true
        }
    }

    private fun loadPayload(payload: JSONObject) {
        configuredDisplayYear = payload.optInt("display_year", 0)
        configuredSearchMaxYear = payload.optInt("search_max_year", 0)
        val textRoot = payload.optJSONObject("text_overrides") ?: JSONObject()
        faOverrides = objectToMap(textRoot.optJSONObject("fa"))
        enOverrides = objectToMap(textRoot.optJSONObject("en"))
    }

    private fun objectToMap(json: JSONObject?): Map<String, String> {
        if (json == null) return emptyMap()
        val out = LinkedHashMap<String, String>()
        val keys = json.keys()
        while (keys.hasNext() && out.size < MAX_ITEMS) {
            val sourceKey = keys.next()
            val key = sourceKey.trim().take(MAX_TEXT)
            if (key.isBlank()) continue
            val value = json.optString(sourceKey, "").take(MAX_TEXT)
            out[key] = value
        }
        return out
    }

    private fun expandYearTokens(context: Context, value: String): String {
        val year = displayYear(context)
        return value
            .replace("{{year}}", year.toString(), ignoreCase = true)
            .replace("{{prev_year}}", (year - 1).toString(), ignoreCase = true)
            .replace("{{next_year}}", (year + 1).toString(), ignoreCase = true)
    }

    private fun expandLegacyYearText(context: Context, raw: String): String {
        val year = displayYear(context)
        return when (raw) {
            "اکران 2025 و 2026" -> "اکران ${year - 1} و $year"
            "2025 and 2026 Releases" -> "${year - 1} and $year Releases"
            "برترین‌های 2026" -> "برترین‌های $year"
            "Best of 2026" -> "Best of $year"
            else -> raw
        }
    }
}
