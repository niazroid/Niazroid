<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/download_redirect.php';

@ini_set('display_errors', '0');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Referrer-Policy: no-referrer');
header('X-Content-Type-Options: nosniff');
header('X-Robots-Tag: noindex, nofollow, noarchive');

if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD');
    http_response_code(405);
    exit;
}

$token = trim((string)($_GET['sig'] ?? ''));
$decoded = $token !== '' ? bm_dl_decode_token($token) : false;
if (!is_array($decoded)) {
    http_response_code(410);
    echo 'Download link is invalid or expired.';
    exit;
}

$queryExpiry = (int)($_GET['expires'] ?? 0);
$tokenExpiry = (int)($decoded['exp'] ?? 0);
if ($queryExpiry <= 0 || $queryExpiry !== $tokenExpiry || $tokenExpiry <= time()) {
    http_response_code(410);
    echo 'Download link has expired.';
    exit;
}

$destination = trim((string)($decoded['url'] ?? ''));
if (!bm_dl_is_http_url($destination)) {
    http_response_code(400);
    echo 'Invalid download destination.';
    exit;
}

// The encrypted token is an expiring capability issued only after the content
// API/website has applied the canonical Member/VIP/Admin archive policy.
header('Location: ' . $destination, true, 302);
exit;
