<?php
/**
 * Archive 4 HTML adapter — Cinamatic template, aligned with Archive 3 flow.
 *
 * The public response intentionally uses neutral Archive 4 identifiers and
 * never exposes the upstream brand in cards, errors, or UI-facing metadata.
 */

if (!defined('API4_BASE_URL')) define('API4_BASE_URL', function_exists('bm_archive_source_base_url')
    ? bm_archive_source_base_url('archive4', 'https://cinamatic.top')
    : 'https://cinamatic.top');
if (!defined('API4_CACHE_TTL_LIST')) define('API4_CACHE_TTL_LIST', 240);
if (!defined('API4_CACHE_TTL_DETAIL')) define('API4_CACHE_TTL_DETAIL', 600);
if (!defined('API4_TIMEOUT')) define('API4_TIMEOUT', 12);
if (!defined('API4_CONNECT_TIMEOUT')) define('API4_CONNECT_TIMEOUT', 5);
if (!defined('API4_CACHE_MAX_BYTES')) define('API4_CACHE_MAX_BYTES', 64 * 1024 * 1024); // سقف کل کش: 64MB
if (!defined('API4_CACHE_MAX_FILES')) define('API4_CACHE_MAX_FILES', 300); // سقف تعداد فایل‌ها
if (!defined('API4_CACHE_MAX_AGE')) define('API4_CACHE_MAX_AGE', 3600); // حذف قطعی فایل‌های قدیمی‌تر از یک ساعت

function api4_cache_dir() {
    if (function_exists('bm_security_private_dir')) {
        $dir = rtrim(bm_security_private_dir(), '/\\') . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'api4';
    } else {
        $dir = dirname(__DIR__) . '/_bankmovie_private/cache/api4';
    }
    if (!is_dir($dir)) @mkdir($dir, 0750, true);
    return $dir;
}

function api4_valid_utf8($text) {
    return preg_match('//u', (string)$text) === 1;
}

function api4_mojibake_score($text) {
    $text = (string)$text;
    if ($text === '' || !api4_valid_utf8($text)) return -100000;
    $score = 0;
    $score += 2 * preg_match_all('/[\x{0600}-\x{06FF}]/u', $text, $m);
    $score += 3 * preg_match_all('/[پچژگکی]/u', $text, $m);
    $score += preg_match_all('/[A-Za-z0-9]/u', $text, $m);
    $score -= 18 * preg_match_all('/[ÃÂØÙÐÑ]/u', $text, $m);
    $score -= 14 * preg_match_all('/[�]/u', $text, $m);
    $noiseCount = preg_match_all('/[طظ]/u', $text, $m);
    if ($noiseCount >= 3) $score -= 5 * $noiseCount;
    $score -= 5 * preg_match_all('/[€‚ƒ„…†‡ˆ‰Š‹ŒŽ‘’“”•–—™š›œžŸ¯®±]/u', $text, $m);
    return $score;
}

function api4_repair_mojibake($text) {
    $text = (string)$text;
    if ($text === '' || !api4_valid_utf8($text) || !function_exists('iconv')) return $text;

    $encodings = array();
    if (preg_match('/[ÃÂØÙÐÑ]/u', $text)) {
        $encodings[] = 'Windows-1252';
        $encodings[] = 'ISO-8859-1';
    }
    $noiseCount = preg_match_all('/[طظ]/u', $text, $m);
    if ($noiseCount >= 3 || preg_match('/(?:[طظ].){2,}/u', $text)) {
        $encodings[] = 'Windows-1256';
    }
    if (!$encodings) return $text;

    $best = $text;
    $bestScore = api4_mojibake_score($text);
    foreach (array_values(array_unique($encodings)) as $legacy) {
        $candidate = @iconv('UTF-8', $legacy . '//IGNORE', $text);
        if (!is_string($candidate) || $candidate === '' || !api4_valid_utf8($candidate)) continue;
        $score = api4_mojibake_score($candidate);
        if ($score > $bestScore + 3) {
            $best = $candidate;
            $bestScore = $score;
        }
    }
    return $best;
}

function api4_clean_text($text) {
    $text = (string)$text;
    if ($text === '') return '';
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = api4_repair_mojibake($text);
    if (!api4_valid_utf8($text) && function_exists('iconv')) {
        $clean = @iconv('UTF-8', 'UTF-8//IGNORE', $text);
        if (is_string($clean)) $text = $clean;
    }
    $text = str_replace(array("\xC2\xA0", "\xE2\x80\x8C", "\xEF\xBF\xBD"), array(' ', '‌', ''), $text);
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text);
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim((string)$text);
}

function api4_contains($haystack, $needle) {
    return $needle !== '' && strpos((string)$haystack, (string)$needle) !== false;
}

function api4_lower($text) {
    return function_exists('mb_strtolower') ? mb_strtolower((string)$text, 'UTF-8') : strtolower((string)$text);
}

function api4_allowed_host($host) {
    $host = strtolower(trim((string)$host));
    $baseHost = strtolower((string)(parse_url(API4_BASE_URL, PHP_URL_HOST) ?: ''));
    $allowed = array('cinamatic.top', 'www.cinamatic.top', $baseHost);
    if (str_starts_with($baseHost, 'www.')) $allowed[] = substr($baseHost, 4);
    elseif ($baseHost !== '') $allowed[] = 'www.' . $baseHost;
    return $host !== '' && in_array($host, array_values(array_unique(array_filter($allowed))), true);
}

function api4_validate_url($url) {
    $url = trim((string)$url);
    if ($url === '') throw new RuntimeException('لینک خالی است.');
    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['scheme']) || empty($parts['host'])) throw new RuntimeException('ساختار لینک معتبر نیست.');
    if (!in_array(strtolower($parts['scheme']), array('http', 'https'), true)) throw new RuntimeException('پروتکل لینک مجاز نیست.');
    if (!api4_allowed_host($parts['host'])) throw new RuntimeException('لینک این آرشیو مجاز نیست.');
    if (function_exists('bm_security_host_resolves_public') && !bm_security_host_resolves_public($parts['host'])) {
        throw new RuntimeException('لینک این آرشیو مجاز نیست.');
    }
    return $url;
}

function api4_abs_url($url, $base = API4_BASE_URL) {
    $url = trim(html_entity_decode((string)$url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($url === '' || $url === '#' || stripos($url, 'javascript:') === 0 || stripos($url, 'data:') === 0) return '';
    if (preg_match('~^https?://~i', $url)) return $url;
    if (strpos($url, '//') === 0) return 'https:' . $url;

    $bp = @parse_url($base);
    $scheme = isset($bp['scheme']) ? $bp['scheme'] : 'https';
    $host = isset($bp['host']) ? $bp['host'] : 'cinamatic.top';
    $port = isset($bp['port']) ? ':' . $bp['port'] : '';
    $root = $scheme . '://' . $host . $port;
    if (strpos($url, '/') === 0) return $root . $url;

    $path = isset($bp['path']) ? $bp['path'] : '/';
    $dir = rtrim(str_replace('\\', '/', dirname($path)), '/');
    if ($dir === '.' || $dir === '') $dir = '';
    return $root . $dir . '/' . $url;
}

function api4_slug_from_url($url) {
    $path = (string)(parse_url((string)$url, PHP_URL_PATH) ?: '');
    $path = trim($path, '/');
    if ($path === '') return substr(sha1((string)$url), 0, 20);
    $parts = explode('/', $path);
    $slug = rawurldecode((string)end($parts));
    $slug = api4_clean_text($slug);
    return $slug !== '' ? $slug : substr(sha1((string)$url), 0, 20);
}

function api4_post_id_from_url($url) {
    $query = (string)(parse_url((string)$url, PHP_URL_QUERY) ?: '');
    if ($query !== '') {
        parse_str($query, $params);
        if (!empty($params['p']) && ctype_digit((string)$params['p'])) return (int)$params['p'];
    }
    return 0;
}

function api4_source_post_id($xpath, $context = null, $url = '') {
    if ($context instanceof DOMElement) {
        foreach (array('data-post','data-postid','data-post-id') as $attr) {
            $value = trim((string)$context->getAttribute($attr));
            if ($value !== '' && ctype_digit($value)) return (int)$value;
        }
    }
    $queries = $context
        ? array('.//*[@data-post]', './/*[@data-postid]', './/*[@data-post-id]')
        : array('//*[@data-post]', '//*[@data-postid]', '//*[@data-post-id]');
    foreach ($queries as $query) {
        $nodes = $xpath->query($query, $context);
        if (!$nodes || !$nodes->length || !($nodes->item(0) instanceof DOMElement)) continue;
        foreach (array('data-post','data-postid','data-post-id') as $attr) {
            $value = trim((string)$nodes->item(0)->getAttribute($attr));
            if ($value !== '' && ctype_digit($value)) return (int)$value;
        }
    }

    if (!$context) {
        $bodyClass = api4_node_attr($xpath, '//body', 'class');
        if (preg_match('/(?:^|\s)postid-(\d+)(?:\s|$)/i', $bodyClass, $m)) return (int)$m[1];
        $short = api4_node_attr($xpath, "//link[contains(concat(' ', normalize-space(@rel), ' '), ' shortlink ')]", 'href');
        $postId = api4_post_id_from_url($short);
        if ($postId > 0) return $postId;
    }
    return api4_post_id_from_url($url);
}

function api4_detail_id($sourcePostId, $slug) {
    $sourcePostId = (int)$sourcePostId;
    return $sourcePostId > 0 ? ('p' . $sourcePostId) : (string)$slug;
}

function api4_http_headers() {
    return array(
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.7,en;q=0.6',
        'Cache-Control: no-cache',
        'Pragma: no-cache',
        'Upgrade-Insecure-Requests: 1',
    );
}

function api4_cache_key($url) {
    $url = trim((string)$url);
    $parts = @parse_url($url);
    if (!is_array($parts)) return sha1($url);

    $scheme = strtolower((string)($parts['scheme'] ?? 'https'));
    $host = strtolower((string)($parts['host'] ?? ''));
    $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
    $path = (string)($parts['path'] ?? '/');
    $query = array();
    if (!empty($parts['query'])) {
        parse_str((string)$parts['query'], $query);
        // پارامترهای تصادفی/ردیابی نباید برای هر درخواست یک فایل کش تازه بسازند.
        foreach (array('_', 'cb', 'cachebust', 'cache_bust', 'timestamp', 'ts', 'nonce', 'rnd', 'random') as $drop) {
            unset($query[$drop]);
        }
        ksort($query);
    }
    $canonical = $scheme . '://' . $host . $port . $path;
    if ($query) $canonical .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
    return sha1($canonical);
}

function api4_cache_paths($url) {
    $base = api4_cache_dir() . '/' . api4_cache_key($url);
    return array(
        'gzip' => $base . '.html.gz',
        'legacy' => $base . '.html',
    );
}

function api4_cache_cleanup($force = false) {
    $dir = api4_cache_dir();
    $stamp = $dir . '/.cleanup.stamp';
    if (!$force && is_file($stamp) && (time() - (int)@filemtime($stamp)) < 20) return;

    $lockPath = $dir . '/.cleanup.lock';
    $lock = @fopen($lockPath, 'c+');
    if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) {
        if (is_resource($lock)) @fclose($lock);
        return;
    }

    @touch($stamp);
    $now = time();
    $files = array();
    $total = 0;

    $it = @new DirectoryIterator($dir);
    if ($it) {
        foreach ($it as $entry) {
            if ($entry->isDot() || !$entry->isFile()) continue;
            $name = $entry->getFilename();
            $path = $entry->getPathname();

            if (preg_match('/\.tmp$/i', $name)) {
                if (($now - (int)$entry->getMTime()) > 120) @unlink($path);
                continue;
            }
            if (!preg_match('/\.html(?:\.gz)?$/i', $name)) continue;

            $mtime = (int)$entry->getMTime();
            $size = max(0, (int)$entry->getSize());
            // TTL واقعی API حداکثر 10 دقیقه است؛ فایل یک‌ساعته قطعاً لازم نیست.
            if (($now - $mtime) > API4_CACHE_MAX_AGE) {
                @unlink($path);
                continue;
            }
            $files[] = array('path' => $path, 'mtime' => $mtime, 'size' => $size);
            $total += $size;
        }
    }

    usort($files, function($a, $b) { return $a['mtime'] <=> $b['mtime']; });
    while (count($files) > API4_CACHE_MAX_FILES || $total > API4_CACHE_MAX_BYTES) {
        $old = array_shift($files);
        if (!$old) break;
        if (@unlink($old['path'])) $total -= $old['size'];
    }

    @flock($lock, LOCK_UN);
    @fclose($lock);
}

function api4_cache_read($url, $ttl) {
    $paths = api4_cache_paths($url);
    foreach (array('gzip', 'legacy') as $kind) {
        $file = $paths[$kind];
        if (!is_file($file) || (time() - (int)@filemtime($file)) > (int)$ttl) continue;
        $raw = @file_get_contents($file);
        if (!is_string($raw) || $raw === '') continue;
        $html = $kind === 'gzip' && function_exists('gzdecode') ? @gzdecode($raw) : $raw;
        if (!is_string($html) || strlen($html) <= 200) continue;

        // مهاجرت خودکار کش قدیمی حجیم به gzip.
        if ($kind === 'legacy' && function_exists('gzencode')) {
            $packed = @gzencode($html, 6);
            if (is_string($packed) && strlen($packed) > 100) {
                $tmp = $paths['gzip'] . '.' . getmypid() . '.tmp';
                if (@file_put_contents($tmp, $packed, LOCK_EX) !== false && @rename($tmp, $paths['gzip'])) {
                    @chmod($paths['gzip'], 0640);
                    @unlink($paths['legacy']);
                }
            }
        }
        return $html;
    }
    return null;
}

function api4_cache_write($url, $html) {
    if (!is_string($html) || strlen($html) < 200) return;
    // از ذخیره پاسخ‌های غیرعادی و بسیار بزرگ جلوگیری می‌کند.
    if (strlen($html) > 3 * 1024 * 1024) return;

    $paths = api4_cache_paths($url);
    $useGzip = function_exists('gzencode');
    $payload = $useGzip ? @gzencode($html, 6) : $html;
    if (!is_string($payload) || strlen($payload) < 100) return;

    $file = $useGzip ? $paths['gzip'] : $paths['legacy'];
    $tmp = $file . '.' . getmypid() . '.' . bin2hex(random_bytes(3)) . '.tmp';
    if (@file_put_contents($tmp, $payload, LOCK_EX) !== false && @rename($tmp, $file)) {
        @chmod($file, 0640);
        // نسخه قدیمی همان کلید باقی نماند.
        if ($useGzip && is_file($paths['legacy'])) @unlink($paths['legacy']);
    } else {
        @unlink($tmp);
    }

    // پاکسازی دوره‌ای + سقف سخت تعداد/حجم، تا کش دیگر چند گیگ نشود.
    api4_cache_cleanup(false);
}

function api4_fetch_once($url) {
    $ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0 Safari/537.36';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_CONNECTTIMEOUT => API4_CONNECT_TIMEOUT,
            CURLOPT_TIMEOUT => API4_TIMEOUT,
            CURLOPT_USERAGENT => $ua,
            CURLOPT_HTTPHEADER => api4_http_headers(),
            CURLOPT_ENCODING => '',
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HEADER => false,
        ));
        $html = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $effective = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        curl_close($ch);
        if ($errno !== 0) throw new RuntimeException('ارتباط با آرشیو برقرار نشد. کد شبکه: ' . $errno);
        if ($status < 200 || $status >= 400) throw new RuntimeException('پاسخ آرشیو نامعتبر بود. کد: ' . $status);
        if (!is_string($html) || strlen($html) < 200) throw new RuntimeException('پاسخ آرشیو خالی یا ناقص بود.');
        if ($effective !== '') {
            $host = (string)(parse_url($effective, PHP_URL_HOST) ?: '');
            if (!api4_allowed_host($host)) throw new RuntimeException('تغییر مسیر نامعتبر بود.');
        }
        return array('html' => $html, 'url' => $effective !== '' ? $effective : $url, 'status' => $status);
    }

    $context = stream_context_create(array(
        'http' => array(
            'method' => 'GET',
            'timeout' => API4_TIMEOUT,
            'ignore_errors' => true,
            'follow_location' => 1,
            'max_redirects' => 5,
            'user_agent' => $ua,
            'header' => implode("\r\n", api4_http_headers()) . "\r\n",
        ),
        'ssl' => array('verify_peer' => true, 'verify_peer_name' => true),
    ));
    $html = @file_get_contents($url, false, $context);
    $status = 0;
    if (isset($http_response_header) && is_array($http_response_header)) {
        foreach ($http_response_header as $line) if (preg_match('~^HTTP/\S+\s+(\d{3})~i', $line, $m)) $status = (int)$m[1];
    }
    if (!is_string($html) || strlen($html) < 200 || ($status && ($status < 200 || $status >= 400))) {
        throw new RuntimeException('ارتباط با آرشیو برقرار نشد.');
    }
    return array('html' => $html, 'url' => $url, 'status' => $status ?: 200);
}

function api4_get_html($url, $ttl = API4_CACHE_TTL_LIST, $retries = 1) {
    $url = api4_validate_url($url);
    $cached = api4_cache_read($url, $ttl);
    if ($cached !== null) return array('html' => $cached, 'url' => $url, 'status' => 200, 'cached' => true);

    $last = null;
    for ($i = 0; $i <= max(0, (int)$retries); $i++) {
        try {
            $result = api4_fetch_once($url);
            api4_cache_write($url, $result['html']);
            $result['cached'] = false;
            return $result;
        } catch (Throwable $e) {
            $last = $e;
            if ($i < $retries) usleep(250000 * ($i + 1));
        }
    }
    throw ($last ?: new RuntimeException('دریافت اطلاعات آرشیو ناموفق بود.'));
}

function api4_xpath_from_html($html) {
    if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) throw new RuntimeException('افزونه DOM روی سرور فعال نیست.');
    $html = (string)$html;
    if ($html === '') throw new RuntimeException('صفحه آرشیو خالی است.');
    if (!api4_valid_utf8($html) && function_exists('iconv')) {
        $fixed = @iconv('UTF-8', 'UTF-8//IGNORE', $html);
        if (is_string($fixed) && $fixed !== '') $html = $fixed;
    }

    // تبدیل کاراکترهای غیر ASCII به entity عددی، جلوی تفسیر UTF-8 به‌عنوان Windows-1256/Latin-1 در libxml را می‌گیرد.
    if (function_exists('mb_encode_numericentity')) {
        $encoded = @mb_encode_numericentity($html, array(0x80, 0x10FFFF, 0, 0xFFFFFF), 'UTF-8');
        if (is_string($encoded) && $encoded !== '') $html = $encoded;
    }
    if (stripos($html, '<meta charset=') === false && stripos($html, 'charset=UTF-8') === false && stripos($html, 'charset=utf-8') === false) {
        $html = preg_replace('/<head([^>]*)>/i', '<head$1><meta charset="UTF-8">', $html, 1);
    }

    $dom = new DOMDocument('1.0', 'UTF-8');
    $old = libxml_use_internal_errors(true);
    $prepared = '<?xml version="1.0" encoding="UTF-8"?>' . $html;
    $ok = $dom->loadHTML($prepared, LIBXML_NOWARNING | LIBXML_NOERROR | LIBXML_NONET | LIBXML_COMPACT);
    libxml_clear_errors();
    libxml_use_internal_errors($old);
    if (!$ok) throw new RuntimeException('ساختار صفحه آرشیو قابل پردازش نیست.');
    return new DOMXPath($dom);
}

function api4_node_text($xpath, $query, $context = null) {
    $nodes = $xpath->query($query, $context);
    return ($nodes && $nodes->length) ? api4_clean_text($nodes->item(0)->textContent) : '';
}

function api4_node_attr($xpath, $query, $attr, $context = null) {
    $nodes = $xpath->query($query, $context);
    if (!$nodes || !$nodes->length || !($nodes->item(0) instanceof DOMElement)) return '';
    return trim((string)$nodes->item(0)->getAttribute($attr));
}

function api4_class_xpath($class) {
    return "contains(concat(' ', normalize-space(@class), ' '), ' " . str_replace("'", '', $class) . " ')";
}

function api4_best_srcset_url($srcset) {
    $best = '';
    $bestWidth = -1;
    foreach (explode(',', (string)$srcset) as $part) {
        $part = trim($part);
        if ($part === '') continue;
        $chunks = preg_split('/\s+/', $part);
        $url = isset($chunks[0]) ? trim($chunks[0]) : '';
        $width = 0;
        if (isset($chunks[1]) && preg_match('/(\d+)(?:w|x)?/i', $chunks[1], $m)) $width = (int)$m[1];
        if ($url !== '' && $width >= $bestWidth) { $best = $url; $bestWidth = $width; }
    }
    return $best;
}

function api4_pick_image($img, $base = API4_BASE_URL) {
    if (!($img instanceof DOMElement)) return '';
    foreach (array('data-src', 'data-lazy-src', 'data-original', 'src') as $attr) {
        $url = trim((string)$img->getAttribute($attr));
        if ($url !== '' && stripos($url, 'data:image') !== 0 && !api4_contains($url, 'placeholder')) return api4_abs_url($url, $base);
    }
    foreach (array('data-srcset', 'srcset') as $attr) {
        $url = api4_best_srcset_url($img->getAttribute($attr));
        if ($url !== '') return api4_abs_url($url, $base);
    }
    return '';
}

function api4_split_list($text) {
    $text = api4_clean_text($text);
    $parts = preg_split('/\s*(?:\||،|,|؛|\/|·)\s*/u', $text, -1, PREG_SPLIT_NO_EMPTY);
    $out = array();
    foreach ((array)$parts as $part) {
        $part = api4_clean_text($part);
        if ($part !== '' && !in_array($part, $out, true)) $out[] = $part;
    }
    return $out;
}

function api4_title_parts($full) {
    $full = api4_clean_text($full);
    $full = preg_replace('/^دانلود\s+(?:فیلم|سریال|انیمه|انیمیشن(?:\s+سریالی)?|مینی\s*سریال)\s*/u', '', $full);
    $full = preg_replace('/\s+(?:دوبله\s+فارسی|با\s+زیرنویس\s+فارسی|زیرنویس\s+فارسی)\s*$/u', '', $full);
    $english = '';
    if (preg_match('/([A-Za-z][A-Za-z0-9\s:&!?.\'’\-+,()]+?)(?:\s+(?:19|20)\d{2})?$/u', $full, $m)) {
        $english = api4_clean_text($m[1]);
    }
    $fa = $full;
    if ($english !== '') {
        $pos = strpos($full, $english);
        if ($pos !== false && $pos > 0) {
            $candidate = api4_clean_text(substr($full, 0, $pos));
            if ($candidate !== '') $fa = $candidate;
        }
    }
    return array('full' => $full, 'fa' => $fa, 'en' => $english !== '' ? $english : $full);
}

function api4_infer_type($title, $url, $forced = '') {
    $forced = strtolower(trim((string)$forced));
    if (in_array($forced, array('movie', 'series', 'anime', 'animation'), true)) return $forced === 'animation' ? 'anime' : $forced;

    $s = api4_lower($title . ' ' . rawurldecode((string)$url));
    $normalized = preg_replace('/[-_]+/u', ' ', $s);

    // Explicit content markers always win over generic words such as "قسمت اول".
    // Some movie collection pages use "قسمت اول/دوم" for sequels, not TV episodes.
    if (api4_contains($normalized, '/series/') || api4_contains($normalized, '/new series/') || api4_contains($normalized, '/seris/')
        || api4_contains($normalized, 'tvseries') || api4_contains($normalized, 'tvepisode') || api4_contains($normalized, 'creativeworkseries')
        || preg_match('/(?:دانلود\s+)?(?:مینی\s*)?سریال/u', $normalized)) return 'series';
    if (preg_match('/انیمیشن\s+سریالی/u', $normalized)) return 'series';
    if (api4_contains($normalized, '/film/') || api4_contains($normalized, '/movie/') || api4_contains($normalized, 'movie')
        || preg_match('/(?:دانلود\s+)?فیلم/u', $normalized)) return 'movie';

    if (api4_contains($normalized, '/animation/') || api4_contains($normalized, '/animiton/') || api4_contains($normalized, 'انیمه') || api4_contains($normalized, 'انیمیشن')) {
        return (api4_contains($normalized, 'فصل ') || api4_contains($normalized, 'قسمت ')) ? 'series' : 'anime';
    }
    if (api4_contains($normalized, 'فصل ') || api4_contains($normalized, 'قسمت ')) return 'series';
    return 'movie';
}

function api4_extract_year($text) {
    return preg_match('/\b((?:19|20)\d{2})\b/u', (string)$text, $m) ? (int)$m[1] : null;
}

function api4_meta_rows($xpath, $context) {
    $result = array();
    $nodes = $xpath->query(".//*[" . api4_class_xpath('rowInfo') . "]//p", $context);
    foreach ($nodes as $p) {
        $label = api4_node_text($xpath, ".//*[" . api4_class_xpath('title') . "]", $p);
        $all = api4_clean_text($p->textContent);
        $value = $label !== '' ? api4_clean_text(preg_replace('/^' . preg_quote($label, '/') . '/u', '', $all)) : $all;
        $label = trim($label, " \t\n\r\0\x0B:");
        if ($label === '' || $value === '') continue;
        $links = array();
        foreach ($xpath->query('.//a', $p) as $a) {
            $v = api4_clean_text($a->textContent);
            if ($v !== '' && !in_array($v, $links, true)) $links[] = $v;
        }
        $result[$label] = array('value' => $value, 'links' => $links);
    }
    return $result;
}

function api4_meta_value($meta, $needles, $default = '') {
    foreach ($meta as $label => $row) {
        foreach ((array)$needles as $needle) {
            if (api4_contains($label, $needle)) return isset($row['value']) ? $row['value'] : $default;
        }
    }
    return $default;
}

function api4_meta_links($meta, $needles) {
    foreach ($meta as $label => $row) {
        foreach ((array)$needles as $needle) {
            if (api4_contains($label, $needle)) return isset($row['links']) ? $row['links'] : array();
        }
    }
    return array();
}

function api4_parse_listing_xpath($xpath, $forcedType = '') {
    $movies = array();
    $seen = array();
    $query = "//main//*[" . api4_class_xpath('contentWrapper') . "]//article[" . api4_class_xpath('postItem') . "]";
    $cards = $xpath->query($query);
    if (!$cards || !$cards->length) $cards = $xpath->query("//article[" . api4_class_xpath('postItem') . "]");

    foreach ($cards as $card) {
        $url = api4_node_attr($xpath, ".//*[" . api4_class_xpath('info') . "]//h2/a", 'href', $card);
        if ($url === '') $url = api4_node_attr($xpath, ".//*[" . api4_class_xpath('sideInfo') . "]/a", 'href', $card);
        $url = api4_abs_url($url);
        if ($url === '') continue;
        $slug = api4_slug_from_url($url);
        $sourcePostId = api4_source_post_id($xpath, $card, $url);
        $detailId = api4_detail_id($sourcePostId, $slug);
        $uniqueKey = $sourcePostId > 0 ? ('p:' . $sourcePostId) : ('s:' . $slug);
        if (isset($seen[$uniqueKey])) continue;
        $seen[$uniqueKey] = true;

        $fullTitle = api4_node_text($xpath, ".//*[" . api4_class_xpath('info') . "]//h2/a", $card);
        if ($fullTitle === '') $fullTitle = api4_node_attr($xpath, ".//*[" . api4_class_xpath('info') . "]//h2/a", 'title', $card);
        if ($fullTitle === '') $fullTitle = api4_node_text($xpath, './/h2/a', $card);
        if ($fullTitle === '') $fullTitle = api4_node_attr($xpath, ".//*[" . api4_class_xpath('sideInfo') . "]/a", 'title', $card);
        $titles = api4_title_parts($fullTitle);

        $poster = '';
        $imgs = $xpath->query(".//*[" . api4_class_xpath('thumbnailWrapper') . "]//img", $card);
        if ($imgs && $imgs->length) $poster = api4_pick_image($imgs->item(0), $url);
        if ($poster === '') {
            $imgs = $xpath->query('.//img[contains(@class,"wp-post-image")]', $card);
            if ($imgs && $imgs->length) $poster = api4_pick_image($imgs->item(0), $url);
        }

        $meta = api4_meta_rows($xpath, $card);
        $genreText = api4_meta_value($meta, array('ژانر'));
        $genres = api4_split_list($genreText);
        $yearText = api4_meta_value($meta, array('سال انتشار', 'سال'));
        $year = api4_extract_year($yearText . ' ' . $fullTitle);
        $country = api4_meta_links($meta, array('محصول', 'کشور'));
        if (!$country) $country = api4_split_list(api4_meta_value($meta, array('محصول', 'کشور')));
        $directors = api4_meta_links($meta, array('کارگردان'));
        $writers = api4_meta_links($meta, array('نویسنده'));
        $actors = api4_meta_links($meta, array('ستارگان', 'بازیگران'));
        $runtimeText = api4_meta_value($meta, array('مدت زمان'));
        $runtime = preg_match('/(\d{1,4})/u', $runtimeText, $rm) ? (int)$rm[1] : null;
        $network = api4_meta_value($meta, array('شبکه'));
        $audience = api4_meta_value($meta, array('مخاطب'));

        $ratingText = api4_node_text($xpath, ".//*[" . api4_class_xpath('floatInfo') . "]//*[" . api4_class_xpath('imdb') . "]//*[" . api4_class_xpath('rate') . "]", $card);
        $rating = preg_match('/(\d+(?:\.\d+)?)/', $ratingText, $rateMatch) ? (float)$rateMatch[1] : null;
        $statusParts = array();
        $statusNodes = $xpath->query(".//*[" . api4_class_xpath('text') . "]//*[" . api4_class_xpath('section') . "]", $card);
        foreach ($statusNodes as $statusNode) {
            $statusPart = api4_clean_text($statusNode->textContent);
            if ($statusPart !== '' && !in_array($statusPart, $statusParts, true)) $statusParts[] = $statusPart;
        }
        $status = '';
        foreach ($statusParts as $statusPart) {
            if (preg_match('/(?:فصل|قسمت|پایان)/u', $statusPart)) { $status = $statusPart; break; }
        }
        if ($status === '' && $statusParts) $status = (string)end($statusParts);
        $award = api4_node_text($xpath, ".//*[" . api4_class_xpath('text') . "]//*[" . api4_class_xpath('oskar') . "]", $card);
        $plot = api4_node_text($xpath, ".//p[" . api4_class_xpath('plot') . "]", $card);
        $plot = preg_replace('/^خلاصه\s*داستان\s*:\s*/u', '', $plot);
        $trailer = api4_abs_url(api4_node_attr($xpath, ".//a[" . api4_class_xpath('toggleTrailerModal') . "]", 'href', $card), $url);
        $badgeText = api4_clean_text(
            api4_node_text($xpath, ".//*[" . api4_class_xpath('floatInfo') . "]", $card) . ' ' .
            api4_node_text($xpath, ".//*[" . api4_class_xpath('info') . "]//*[" . api4_class_xpath('text') . "]", $card)
        );
        $hasDubbed = api4_contains($badgeText, 'دوبله');
        $hasSubtitle = api4_contains($badgeText, 'زیرنویس');
        $hasOnline = (bool)$xpath->query(".//a[contains(@class,'play-grid') or contains(@class,'showChosePlayModal') or contains(@href,'/player?')]", $card)->length;
        $type = api4_infer_type($fullTitle . ' ' . $status, $url, $forcedType);

        $movies[] = array(
            'id' => $slug,
            'slug' => $slug,
            'detail_id' => $detailId,
            'source_post_id' => $sourcePostId > 0 ? $sourcePostId : null,
            'url' => $url,
            'source_url' => $url,
            'title' => $titles['en'],
            'title_fa' => $titles['fa'],
            'full_title' => $titles['full'],
            'year' => $year,
            'type' => $type,
            'poster' => $poster,
            'rating' => $rating,
            'genres' => $genres,
            'country' => $country,
            'countries' => $country,
            'description' => api4_clean_text($plot),
            'status' => $status,
            'status_text' => $status,
            'status_parts' => $statusParts,
            'award_text' => $award,
            'audience' => $audience,
            'age_rate' => $audience,
            'runtime' => $runtime,
            'network' => $network,
            'actors' => $actors,
            'directors' => $directors,
            'writers' => $writers,
            'trailer' => $trailer,
            'has_dubbed' => $hasDubbed,
            'has_subtitle' => $hasSubtitle,
            'has_online' => $hasOnline,
        );
    }
    return $movies;
}

function api4_parse_pagination($xpath, $page) {
    $page = max(1, (int)$page);
    $last = $page;
    $next = null;
    $links = $xpath->query("//*[" . api4_class_xpath('PaginationWrapper') . "]//*[contains(concat(' ', normalize-space(@class), ' '), ' page-numbers ')]");
    foreach ($links as $node) {
        $text = api4_clean_text($node->textContent);
        if (ctype_digit($text)) $last = max($last, (int)$text);
        if ($node instanceof DOMElement) {
            $href = html_entity_decode($node->getAttribute('href'), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if (preg_match('~/page/(\d+)/?~i', $href, $m)) {
                $n = (int)$m[1];
                $last = max($last, $n);
                if ($n === $page + 1) $next = $n;
            }
        }
    }
    if ($next === null && $last > $page) $next = $page + 1;
    return array('has_more' => $next !== null, 'next_page' => $next, 'last_page_hint' => $last);
}

function api4_section_catalog() {
    // Cinamatic uses the same BartarTheme card/detail markup as Archive 3,
    // but its public category slugs are film / series / animation / new-series.
    return array(
        'home' => '/',
        'new_movies' => '/category/film/',
        'updated_movies' => '/category/film/',
        'movies' => '/category/film/',
        'movie' => '/category/film/',
        'new_series' => '/category/new-series/',
        'updated_series' => '/category/series/',
        'series' => '/category/series/',
        'animations' => '/category/animation/',
        'animation' => '/category/animation/',
        'anime' => '/category/animation/',
        'updated_animations' => '/category/animation/',
        'updated_anime' => '/category/animation/',
        // These aliases are kept for API compatibility; advanced-search handles
        // the language filters more reliably than source-specific nested slugs.
        'dubbed_movies' => '/category/dubbed-farsi/',
        'subtitled_movies' => '/category/film/',
        'dubbed_series' => '/category/dubbed-farsi/',
        'subtitled_series' => '/category/series/',
        'korean_series' => '/category/korean/',
        'mini_series' => '/category/series/',
    );
}

function api4_genre_catalog() {
    return array(
        'action' => 'action', 'اکشن' => 'action',
        'biography' => '%d8%a8%db%8c%d9%88%da%af%d8%b1%d8%a7%d9%81%db%8c', 'بیوگرافی' => '%d8%a8%db%8c%d9%88%da%af%d8%b1%d8%a7%d9%81%db%8c',
        'history' => 'tarikhi', 'historical' => 'tarikhi', 'تاریخی' => 'tarikhi',
        'horror' => 'tarsnak', 'ترسناک' => 'tarsnak',
        'crime' => 'jenaei', 'جنایی' => 'jenaei',
        'war' => 'jangi', 'جنگی' => 'jangi',
        'family' => 'khanevadegi', 'خانوادگی' => 'khanevadegi',
        'animation' => '@animation', 'animated' => '@animation', 'انیمیشن' => '@animation', 'دانلود انیمیشن' => '@animation',
        'drama' => 'deram', 'درام' => 'deram',
        'mystery' => 'raz', 'رازآلود' => 'raz', 'معمایی' => 'raz',
        'romance' => 'love', 'عاشقانه' => 'love',
        'sci-fi' => 'elmi', 'science-fiction' => 'elmi', 'علمی تخیلی' => 'elmi', 'علمی‌تخیلی' => 'elmi',
        'fantasy' => 'fantezi', 'فانتزی' => 'fantezi',
        'comedy' => 'comedy', 'کمدی' => 'comedy',
        'short' => '%da%a9%d9%88%d8%aa%d8%a7%d9%87', 'کوتاه' => '%da%a9%d9%88%d8%aa%d8%a7%d9%87',
        'adventure' => 'hos', 'ماجراجویی' => 'hos',
        'documentary' => 'mostanad', 'مستند' => 'mostanad',
        'music-video' => '@music_video', 'music video' => '@music_video', 'موزیک ویدیو' => '@music_video',
        'musical' => '%d9%85%d9%88%d8%b2%db%8c%da%a9%d8%a7%d9%84', 'موزیکال' => '%d9%85%d9%88%d8%b2%db%8c%da%a9%d8%a7%d9%84',
        'mini-series' => '@mini_series', 'miniseries' => '@mini_series', 'مینی سریال' => '@mini_series', 'مینی‌سریال' => '@mini_series',
        'noir' => '%d9%86%d9%88%d8%a2%d8%b1', 'نوآر' => '%d9%86%d9%88%d8%a2%d8%b1',
        'thriller' => 'angiz', 'هیجان انگیز' => 'angiz', 'هیجان‌انگیز' => 'angiz',
        'sport' => '%d9%88%d8%b1%d8%b2%d8%b4%db%8c', 'sports' => '%d9%88%d8%b1%d8%b2%d8%b4%db%8c', 'ورزشی' => '%d9%88%d8%b1%d8%b2%d8%b4%db%8c',
        'western' => '%d9%88%d8%b3%d8%aa%d8%b1%d9%86', 'وسترن' => '%d9%88%d8%b3%d8%aa%d8%b1%d9%86',
    );
}

function api4_genre_options_fallback() {
    // Values mirror the Archive 4 advanced-search form. Counts are intentionally
    // unknown until a live/cached source page supplies them.
    return array(
        array('key' => 'g1', 'value' => 'اکشن', 'label' => 'اکشن', 'sidebar_label' => 'اکشن', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g2', 'value' => 'بیوگرافی', 'label' => 'بیوگرافی', 'sidebar_label' => 'بیوگرافی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g3', 'value' => 'ترسناک', 'label' => 'ترسناک', 'sidebar_label' => 'ترسناک', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g4', 'value' => 'جنایی', 'label' => 'جنایی', 'sidebar_label' => 'جنایی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g5', 'value' => 'جنگی', 'label' => 'جنگی', 'sidebar_label' => 'جنگی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g6', 'value' => 'خانوادگی', 'label' => 'خانوادگی', 'sidebar_label' => 'خانوادگی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g7', 'value' => 'درام', 'label' => 'درام', 'sidebar_label' => 'درام', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g8', 'value' => 'انیمیشن', 'label' => 'انیمیشن', 'sidebar_label' => 'انیمیشن', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g9', 'value' => 'رازآلود', 'label' => 'رازآلود', 'sidebar_label' => 'رازآلود', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g10', 'value' => 'عاشقانه', 'label' => 'عاشقانه', 'sidebar_label' => 'عاشقانه', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g11', 'value' => 'علمی تخیلی', 'label' => 'علمی تخیلی', 'sidebar_label' => 'علمی تخیلی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g12', 'value' => 'فانتزی', 'label' => 'فانتزی', 'sidebar_label' => 'فانتزی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g13', 'value' => 'کمدی', 'label' => 'کمدی', 'sidebar_label' => 'کمدی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g14', 'value' => 'کوتاه', 'label' => 'کوتاه', 'sidebar_label' => 'کوتاه', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g15', 'value' => 'ماجراجویی', 'label' => 'ماجراجویی', 'sidebar_label' => 'ماجراجویی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g16', 'value' => 'مستند', 'label' => 'مستند', 'sidebar_label' => 'مستند', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g17', 'value' => 'موزیک ویدیو', 'label' => 'موزیک ویدیو', 'sidebar_label' => 'موزیک ویدیو', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g18', 'value' => 'موزیکال', 'label' => 'موزیکال', 'sidebar_label' => 'موزیکال', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g19', 'value' => 'مینی سریال', 'label' => 'مینی سریال', 'sidebar_label' => 'مینی سریال', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g20', 'value' => 'نوآر', 'label' => 'نوآر', 'sidebar_label' => 'نوآر', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g21', 'value' => 'هیجان انگیز', 'label' => 'هیجان انگیز', 'sidebar_label' => 'هیجان انگیز', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g22', 'value' => 'ورزشی', 'label' => 'ورزشی', 'sidebar_label' => 'ورزشی', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
        array('key' => 'g23', 'value' => 'وسترن', 'label' => 'وسترن', 'sidebar_label' => 'وسترن', 'count' => null, 'path' => '', 'advanced_form_supported' => true),
    );
}

function api4_year_options_fallback() {
    $rows = array();
    $maxYear = max(2026, (int)date('Y'));
    for ($year = 2000; $year <= $maxYear; $year++) {
        $rows[] = array('value' => $year, 'label' => (string)$year, 'count' => null, 'path' => '/release/' . $year . '/');
    }
    return $rows;
}

function api4_genre_display_name($value) {
    $value = api4_clean_text($value);
    if ($value === '') return '';
    $lower = api4_lower($value);
    $aliases = array(
        'action' => 'اکشن', 'biography' => 'بیوگرافی', 'history' => 'تاریخی', 'historical' => 'تاریخی',
        'horror' => 'ترسناک', 'crime' => 'جنایی', 'war' => 'جنگی', 'family' => 'خانوادگی',
        'animation' => 'انیمیشن', 'animated' => 'انیمیشن', 'دانلود انیمیشن' => 'انیمیشن',
        'drama' => 'درام', 'mystery' => 'رازآلود', 'معمایی' => 'رازآلود', 'romance' => 'عاشقانه',
        'sci-fi' => 'علمی تخیلی', 'science-fiction' => 'علمی تخیلی', 'علمی‌تخیلی' => 'علمی تخیلی',
        'fantasy' => 'فانتزی', 'comedy' => 'کمدی', 'short' => 'کوتاه', 'adventure' => 'ماجراجویی',
        'documentary' => 'مستند', 'music-video' => 'موزیک ویدیو', 'music video' => 'موزیک ویدیو',
        'musical' => 'موزیکال', 'mini-series' => 'مینی سریال', 'miniseries' => 'مینی سریال', 'مینی‌سریال' => 'مینی سریال',
        'noir' => 'نوآر', 'thriller' => 'هیجان انگیز', 'هیجان‌انگیز' => 'هیجان انگیز',
        'sport' => 'ورزشی', 'sports' => 'ورزشی', 'western' => 'وسترن',
    );
    return isset($aliases[$lower]) ? $aliases[$lower] : $value;
}

function api4_sidebar_rows($xpath, $headingNeedle) {
    $out = array();
    $headingNeedle = api4_clean_text($headingNeedle);
    $query = "//div[" . api4_class_xpath('catsList') . "][.//h3[contains(normalize-space(.), '" . $headingNeedle . "')]]//a[" . api4_class_xpath('catlink') . "]";
    $nodes = $xpath->query($query);
    foreach ($nodes as $node) {
        if (!($node instanceof DOMElement)) continue;
        $label = api4_clean_text($node->getAttribute('title'));
        if ($label === '') {
            $label = api4_clean_text($node->textContent);
            $span = api4_node_text($xpath, './/span', $node);
            if ($span !== '') $label = api4_clean_text(str_replace($span, '', $label));
        }
        $countText = api4_node_text($xpath, './/span', $node);
        $count = preg_match('/\d+/', str_replace(',', '', $countText), $m) ? (int)$m[0] : null;
        $url = api4_abs_url($node->getAttribute('href'));
        if ($label !== '') $out[] = array('label' => $label, 'count' => $count, 'url' => $url);
    }
    return $out;
}

function api4_search_options() {
    $genres = api4_genre_options_fallback();
    $years = api4_year_options_fallback();
    $countsSource = 'fallback_snapshot';
    $sourceUrl = API4_BASE_URL . '/advanced-search/';

    try {
        $res = api4_get_html($sourceUrl, API4_CACHE_TTL_LIST, 1);
        $xpath = api4_xpath_from_html($res['html']);
        $liveGenres = api4_sidebar_rows($xpath, 'ژانر');
        $liveYears = api4_sidebar_rows($xpath, 'سال انتشار');

        if ($liveGenres) {
            $byLabel = array();
            foreach ($liveGenres as $row) {
                $canonical = api4_genre_display_name($row['label']);
                $byLabel[$canonical] = $row;
            }
            foreach ($genres as &$genre) {
                $canonical = api4_genre_display_name($genre['value']);
                if (isset($byLabel[$canonical])) {
                    $genre['count'] = $byLabel[$canonical]['count'];
                    $genre['source_url'] = $byLabel[$canonical]['url'];
                }
            }
            unset($genre);
            $countsSource = 'live_cached';
        }

        if ($liveYears) {
            $byYear = array();
            foreach ($liveYears as $row) {
                if (preg_match('/(?:19|20)\d{2}/', $row['label'], $m)) $byYear[(int)$m[0]] = $row;
            }
            foreach ($years as &$year) {
                if (isset($byYear[$year['value']])) {
                    $year['count'] = $byYear[$year['value']]['count'];
                    $year['source_url'] = $byYear[$year['value']]['url'];
                }
            }
            unset($year);
            if ($byYear) $countsSource = 'live_cached';
        }
    } catch (Throwable $e) {
        // Fallback options remain available even if the source page is temporarily unreachable.
    }

    return array(
        'types' => array(
            array('value' => 'all', 'label' => 'همه'),
            array('value' => 'movie', 'label' => 'فیلم'),
            array('value' => 'series', 'label' => 'سریال'),
            array('value' => 'animation', 'label' => 'انیمیشن'),
            array('value' => 'anime', 'label' => 'انیمه'),
        ),
        'genres' => $genres,
        'years' => $years,
        'imdb_scores' => array(
            array('value' => 9, 'label' => 'بالای 9'),
            array('value' => 8, 'label' => 'بالای 8'),
            array('value' => 7, 'label' => 'بالای 7'),
            array('value' => 6, 'label' => 'بالای 6'),
            array('value' => 5, 'label' => 'بالای 5'),
        ),
        'languages' => array(
            array('value' => '', 'label' => 'همه'),
            array('value' => 'دوبله', 'label' => 'دوبله'),
            array('value' => 'زیرنویس', 'label' => 'زیرنویس'),
        ),
        'sorts' => array(
            array('value' => 'newest', 'label' => 'جدیدترین'),
            array('value' => 'rating', 'label' => 'بالاترین امتیاز'),
            array('value' => 'year_desc', 'label' => 'سال انتشار'),
            array('value' => 'title', 'label' => 'عنوان'),
        ),
        'counts_source' => $countsSource,
        'source_url' => $sourceUrl,
    );
}

function api4_section_params($section, $page = 1) {
    $section = trim((string)$section);
    $catalog = api4_section_catalog();
    if (!isset($catalog[$section])) $section = 'new_movies';
    $forced = '';
    if (api4_contains($section, 'series')) $forced = 'series';
    elseif (in_array($section, array('animations', 'animation', 'anime', 'updated_animations', 'updated_anime'), true)) $forced = 'anime';
    elseif (api4_contains($section, 'movie')) $forced = 'movie';
    $mediaKind = '';
    if ($section === 'updated_animations') $mediaKind = 'animation';
    elseif ($section === 'updated_anime') $mediaKind = 'anime';
    return array(
        'section' => $section,
        '_path' => $catalog[$section],
        '_media_kind' => $mediaKind,
        's' => '', 'type' => $forced, 'genre' => '', 'country' => '',
        'director' => '', 'actor' => '', 'yearse' => '', 'year' => '',
        'fromYear' => '', 'toYear' => '', 'rates' => '', 'rating' => '', 'imdbScore' => '', 'score' => '',
        'lang' => '', 'dubbed' => false, 'subtitle' => false, 'playonline' => false,
        'sort' => 'newest', 'page' => max(1, (int)$page),
    );
}

function api4_add_page_to_url($url, $page) {
    $page = max(1, (int)$page);
    if ($page <= 1) return $url;
    $parts = parse_url($url);
    $scheme = isset($parts['scheme']) ? $parts['scheme'] : 'https';
    $host = isset($parts['host']) ? $parts['host'] : 'cinamatic.top';
    $path = isset($parts['path']) ? $parts['path'] : '/';
    $path = preg_replace('~/page/\d+/?$~', '/', $path);
    $path = rtrim($path, '/') . '/page/' . $page . '/';
    $out = $scheme . '://' . $host . $path;
    if (!empty($parts['query'])) $out .= '?' . $parts['query'];
    return $out;
}

function api4_normalize_type($value) {
    $value = api4_lower(api4_clean_text($value));
    if (in_array($value, array('', 'all', 'both', 'همه'), true)) return 'all';
    if (in_array($value, array('movie', 'movies', 'film', 'فیلم'), true)) return 'movie';
    if (in_array($value, array('series', 'serial', 'tv', 'سریال'), true)) return 'series';
    if (in_array($value, array('anime', 'انیمه'), true)) return 'anime';
    if (in_array($value, array('animation', 'animated', 'انیمیشن'), true)) return 'animation';
    return $value;
}

function api4_normalize_lang($value) {
    $value = api4_lower(api4_clean_text($value));
    if ($value === '') return '';
    if (in_array($value, array('dubbed', 'dub', 'doble', 'دوبله'), true)) return 'دوبله';
    if (in_array($value, array('subtitle', 'subtitled', 'sub', 'زیرنویس'), true)) return 'زیرنویس';
    return api4_clean_text($value);
}

function api4_advanced_search_query($params) {
    $query = array();
    $q = trim((string)($params['s'] ?? ($params['q'] ?? '')));
    if ($q !== '') $query['q'] = $q;

    $type = api4_normalize_type($params['type'] ?? 'all');
    $genre = api4_genre_display_name($params['genre'] ?? '');
    if (in_array($type, array('movie', 'series'), true)) $query['type'] = $type;
    elseif (in_array($type, array('anime', 'animation'), true) && $genre === '') $genre = 'انیمیشن';
    if ($genre !== '') $query['genre'] = $genre;

    foreach (array('country', 'director', 'actor') as $field) {
        $value = api4_clean_text($params[$field] ?? '');
        if ($value !== '') $query[$field] = $value;
    }

    $year = trim((string)($params['yearse'] ?? ($params['year'] ?? '')));
    if ($year === '') {
        $from = (int)($params['fromYear'] ?? 0);
        $to = (int)($params['toYear'] ?? 0);
        if ($from > 0 && $from === $to) $year = (string)$from;
    }
    if (preg_match('/^(?:19|20)\d{2}$/', $year)) $query['yearse'] = $year;

    $imdb = trim((string)($params['imdbScore'] ?? ($params['rates'] ?? ($params['rating'] ?? ''))));
    if ($imdb !== '' && is_numeric($imdb) && (float)$imdb > 0) $query['imdbScore'] = rtrim(rtrim(number_format((float)$imdb, 1, '.', ''), '0'), '.');

    $lang = api4_normalize_lang($params['lang'] ?? '');
    if ($lang === '') {
        if (!empty($params['dubbed'])) $lang = 'دوبله';
        elseif (!empty($params['subtitle'])) $lang = 'زیرنویس';
    }
    if ($lang !== '') $query['lang'] = $lang;
    return $query;
}

function api4_should_use_advanced_search($query) {
    foreach (array('q', 'genre', 'country', 'director', 'actor', 'yearse', 'imdbScore', 'lang') as $field) {
        if (isset($query[$field]) && $query[$field] !== '') return true;
    }
    if (!empty($query['type']) && !empty($query['genre'])) return true;
    return count($query) > 1;
}

function api4_genre_path($genre) {
    $genre = api4_clean_text($genre);
    if ($genre === '') return '';
    $genres = api4_genre_catalog();
    $key = isset($genres[$genre]) ? $genre : api4_lower($genre);
    $slug = isset($genres[$key]) ? $genres[$key] : preg_replace('/[^a-z0-9_-]/i', '', $genre);
    if ($slug === '@animation') return '/category/animation/';
    if ($slug === '@music_video') return '/category/video/';
    if ($slug === '@mini_series') return '/category/series/';
    return $slug !== '' ? '/category/jener/' . $slug . '/' : '';
}

function api4_build_list_url($params) {
    $page = max(1, (int)(isset($params['page']) ? $params['page'] : 1));

    if (!empty($params['_path'])) return api4_add_page_to_url(API4_BASE_URL . $params['_path'], $page);

    $advancedQuery = api4_advanced_search_query($params);
    if (api4_should_use_advanced_search($advancedQuery)) {
        $base = API4_BASE_URL . '/advanced-search/';
        if ($advancedQuery) $base .= '?' . http_build_query($advancedQuery, '', '&', PHP_QUERY_RFC3986);
        return api4_add_page_to_url($base, $page);
    }

    $type = api4_normalize_type(isset($params['type']) ? $params['type'] : 'all');
    $genre = trim((string)(isset($params['genre']) ? $params['genre'] : ''));
    $dubbed = !empty($params['dubbed']);
    $subtitle = !empty($params['subtitle']);

    if ($genre !== '') {
        $path = api4_genre_path($genre);
        if ($path !== '') return api4_add_page_to_url(API4_BASE_URL . $path, $page);
    }

    if ($type === 'series') {
        $path = $dubbed ? '/category/dubbed-farsi/' : '/category/series/';
    } elseif ($type === 'anime' || $type === 'animation') {
        $path = '/category/animation/';
    } else {
        $path = $dubbed ? '/category/dubbed-farsi/' : '/category/film/';
    }
    return api4_add_page_to_url(API4_BASE_URL . $path, $page);
}

function api4_filter_movies($movies, $params) {
    $type = api4_normalize_type(isset($params['type']) ? $params['type'] : 'all');
    $genre = api4_lower(api4_genre_display_name(isset($params['genre']) ? $params['genre'] : ''));
    $country = api4_lower(trim((string)(isset($params['country']) ? $params['country'] : '')));
    $director = api4_lower(trim((string)(isset($params['director']) ? $params['director'] : '')));
    $actor = api4_lower(trim((string)(isset($params['actor']) ? $params['actor'] : '')));
    $exactYear = (int)($params['yearse'] ?? ($params['year'] ?? 0));
    $from = (int)(isset($params['fromYear']) ? $params['fromYear'] : 0);
    $to = (int)(isset($params['toYear']) ? $params['toYear'] : 0);
    if ($exactYear > 0) $from = $to = $exactYear;
    $rate = (float)($params['imdbScore'] ?? ($params['rates'] ?? ($params['rating'] ?? 0)));
    $lang = api4_normalize_lang($params['lang'] ?? '');
    $dubbed = !empty($params['dubbed']) || $lang === 'دوبله';
    $subtitle = !empty($params['subtitle']) || $lang === 'زیرنویس';
    $playonline = !empty($params['playonline']);
    $filtered = array();

    foreach ((array)$movies as $movie) {
        if ($type !== '' && !in_array($type, array('all', 'both'), true)) {
            $movieType = (string)($movie['type'] ?? '');
            $mediaKind = (string)($movie['media_kind'] ?? '');
            if ($type === 'animation' && !($movieType === 'anime' || $mediaKind === 'animation')) continue;
            elseif ($type === 'anime' && !($movieType === 'anime' || $mediaKind === 'anime')) continue;
            elseif (!in_array($type, array('anime', 'animation'), true) && $movieType !== $type) continue;
        }
        if ($genre !== '') {
            $joined = api4_lower(implode(' ', (array)($movie['genres'] ?? array())));
            if (!api4_contains($joined, $genre)) {
                $isAnimationGenre = $genre === api4_lower('انیمیشن') && (($movie['type'] ?? '') === 'anime');
                if (!$isAnimationGenre) continue;
            }
        }
        if ($country !== '') {
            $joined = api4_lower(implode(' ', (array)($movie['country'] ?? array())));
            if (!api4_contains($joined, $country)) continue;
        }
        if ($director !== '') {
            $joined = api4_lower(implode(' ', (array)($movie['directors'] ?? array())));
            if (!api4_contains($joined, $director)) continue;
        }
        if ($actor !== '') {
            $joined = api4_lower(implode(' ', (array)($movie['actors'] ?? array())));
            if (!api4_contains($joined, $actor)) continue;
        }
        $year = (int)($movie['year'] ?? 0);
        if ($from > 0 && ($year <= 0 || $year < $from)) continue;
        if ($to > 0 && ($year <= 0 || $year > $to)) continue;
        if ($rate > 0 && (float)($movie['rating'] ?? 0) < $rate) continue;
        if ($dubbed && empty($movie['has_dubbed'])) continue;
        if ($subtitle && empty($movie['has_subtitle'])) continue;
        if ($playonline && empty($movie['has_online'])) continue;
        $filtered[] = $movie;
    }

    $sort = strtolower(trim((string)(isset($params['sort']) ? $params['sort'] : '')));
    if ($sort === 'imdb' || $sort === 'rating') usort($filtered, function($a, $b) { return (float)($b['rating'] ?? 0) <=> (float)($a['rating'] ?? 0); });
    elseif ($sort === 'title') usort($filtered, function($a, $b) { return strcmp((string)($a['title_fa'] ?? ''), (string)($b['title_fa'] ?? '')); });
    elseif ($sort === 'year' || $sort === 'year_desc') usort($filtered, function($a, $b) { return (int)($b['year'] ?? 0) <=> (int)($a['year'] ?? 0); });
    return $filtered;
}

/**
 * Split the general animation category into two user-facing rows.
 *
 * - animation: standalone animated movies ("دانلود انیمیشن")
 * - anime: anime / serialized animation updates ("انیمه", فصل, قسمت)
 *
 * The source type remains `anime` for detail-route compatibility; the new
 * `media_kind` field is only used for the card label and section separation.
 */
function api4_filter_animation_kind($movies, $kind) {
    $kind = strtolower(trim((string)$kind));
    if (!in_array($kind, array('animation', 'anime'), true)) return (array)$movies;

    $out = array();
    foreach ((array)$movies as $movie) {
        $text = api4_lower(api4_clean_text(
            (string)($movie['full_title'] ?? '') . ' ' .
            (string)($movie['title_fa'] ?? '') . ' ' .
            (string)($movie['status'] ?? '') . ' ' .
            rawurldecode((string)($movie['url'] ?? ''))
        ));
        $isAnime = api4_contains($text, 'انیمه')
            || api4_contains($text, 'انیمیشن سریالی')
            || api4_contains($text, 'فصل ')
            || api4_contains($text, 'قسمت ')
            || (($movie['type'] ?? '') === 'series');
        $isStandaloneAnimation = api4_contains($text, 'انیمیشن') && !$isAnime;

        if ($kind === 'animation' && !$isStandaloneAnimation) continue;
        // updated_anime uses the exact serialized-animation category path,
        // and the guard below prevents a standalone animation from leaking in.
        if ($kind === 'anime' && !$isAnime) continue;

        $movie['media_kind'] = $kind;
        $out[] = $movie;
    }
    return $out;
}

function api4_search($params) {
    $page = max(1, (int)(isset($params['page']) ? $params['page'] : 1));
    $url = api4_build_list_url($params);
    $res = api4_get_html($url, API4_CACHE_TTL_LIST, 1);
    $xpath = api4_xpath_from_html($res['html']);
    $forcedType = trim((string)($params['type'] ?? ''));
    $movies = api4_parse_listing_xpath($xpath, $forcedType);
    $movies = api4_filter_movies($movies, $params);
    if (!empty($params['_media_kind'])) {
        $movies = api4_filter_animation_kind($movies, $params['_media_kind']);
    }
    $pg = api4_parse_pagination($xpath, $page);
    return array(
        'page' => $page,
        'count' => count($movies),
        'has_more' => $pg['has_more'],
        'next_page' => $pg['next_page'],
        'last_page_hint' => $pg['last_page_hint'],
        'filters' => $params,
        'movies' => $movies,
    );
}

function api4_jsonld_candidates($xpath) {
    $out = array();
    $nodes = $xpath->query("//script[@type='application/ld+json']");
    foreach ($nodes as $node) {
        $raw = trim((string)$node->textContent);
        if ($raw === '') continue;
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) continue;
        $stack = array($decoded);
        while ($stack) {
            $item = array_pop($stack);
            if (!is_array($item)) continue;
            if (isset($item['@type'])) $out[] = $item;
            foreach ($item as $v) if (is_array($v)) $stack[] = $v;
        }
    }
    return $out;
}

function api4_jsonld_main($xpath) {
    $fallback = array();
    foreach (api4_jsonld_candidates($xpath) as $item) {
        $types = (array)($item['@type'] ?? array());
        foreach ($types as $type) {
            if (in_array($type, array('Movie', 'TVSeries', 'TVEpisode', 'CreativeWorkSeries', 'VideoObject'), true)) return $item;
        }
        if (!$fallback && (!empty($item['name']) || !empty($item['headline']))) $fallback = $item;
    }
    return $fallback;
}

function api4_people_from_jsonld($value) {
    $out = array();
    if (is_array($value) && (isset($value['name']) || isset($value['@type']))) $value = array($value);
    foreach ((array)$value as $person) {
        if (is_string($person)) $name = api4_clean_text($person);
        elseif (is_array($person)) $name = api4_clean_text($person['name'] ?? '');
        else $name = '';
        if ($name !== '' && !in_array($name, $out, true)) $out[] = $name;
    }
    return $out;
}

function api4_quality_from_text($text) {
    $text = api4_lower(api4_clean_text($text));
    if (preg_match('/\b(2160|1440|1080|720|576|540|480|360|240)p?\b/i', $text, $m)) return $m[1] . 'p';
    if (api4_contains($text, '4k')) return '2160p';
    if (api4_contains($text, 'full hd') || api4_contains($text, 'fullhd')) return '1080p';
    if (api4_contains($text, 'hd')) return '720p';
    return 'نامشخص';
}

function api4_download_type($primaryText, $contextText = '') {
    $primary = api4_lower(api4_clean_text($primaryText));
    $context = api4_lower(api4_clean_text($contextText));

    // Filename/row evidence is more reliable than a generic box heading.
    // A single "زیرنویس چسبیده" box may contain both HardSub and SoftSub files.
    if (preg_match('/(?:hard[ ._-]*sub|hardsub|هارد\s*ساب|هاردساب)/iu', $primary)) return 'hardsub';
    if (preg_match('/(?:soft[ ._-]*sub|softsub|سافت\s*ساب|سافتساب)/iu', $primary)) return 'softsub';
    if (api4_contains($primary, 'صوت') || api4_contains($primary, 'audio')) return 'audio';
    if (api4_contains($primary, 'دوبله') || api4_contains($primary, 'dubbed') || preg_match('/(?:^|[._-])duble(?:[._-]|$)/i', $primary)) return 'dubbed';
    if (api4_contains($primary, 'زیرنویس') || api4_contains($primary, 'subtitle') || api4_contains($primary, 'subbed')) return 'subtitle';

    if (preg_match('/(?:hard[ ._-]*sub|hardsub|هارد\s*ساب|هاردساب)/iu', $context)) return 'hardsub';
    if (preg_match('/(?:soft[ ._-]*sub|softsub|سافت\s*ساب|سافتساب)/iu', $context)) return 'softsub';
    if (api4_contains($context, 'صوت') || api4_contains($context, 'audio')) return 'audio';
    if (api4_contains($context, 'دوبله') || api4_contains($context, 'dubbed')) return 'dubbed';
    if (api4_contains($context, 'زیرنویس چسبیده') || api4_contains($context, 'زیرنویس') || api4_contains($context, 'subtitle') || api4_contains($context, 'subbed')) return 'subtitle';
    return 'original';
}

function api4_download_type_label($type) {
    $labels = array(
        'dubbed' => 'دوبله فارسی',
        'audio' => 'صوت دوبله',
        'hardsub' => 'هاردساب فارسی',
        'softsub' => 'سافت‌ساب فارسی',
        'subtitle' => 'زیرنویس فارسی',
        'original' => 'نسخه اصلی',
    );
    return isset($labels[$type]) ? $labels[$type] : (string)$type;
}

function api4_latin_digits($text) {
    return strtr((string)$text, array(
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'
    ));
}

function api4_season_episode($text) {
    $text = api4_clean_text(api4_latin_digits($text));
    $season = null;
    $episode = null;
    if (preg_match('/\bS(?:eason)?[ ._-]?(\d{1,2})\s*E(?:p(?:isode)?)?[ ._-]?(\d{1,3})\b/i', $text, $m)) {
        $season = (int)$m[1];
        $episode = (int)$m[2];
    }
    if ($season === null && preg_match('/(?:فصل|season)\s*(\d{1,2})/iu', $text, $m)) $season = (int)$m[1];
    if ($episode === null && preg_match('/(?:قسمت|episode|ep)\s*(\d{1,3})/iu', $text, $m)) $episode = (int)$m[1];

    if ($season === null && preg_match('/فصل\s*(اول|یکم|دوم|سوم|چهارم|پنجم|ششم|هفتم|هشتم|نهم|دهم)/u', $text, $m)) {
        $ordinals = array('اول'=>1,'یکم'=>1,'دوم'=>2,'سوم'=>3,'چهارم'=>4,'پنجم'=>5,'ششم'=>6,'هفتم'=>7,'هشتم'=>8,'نهم'=>9,'دهم'=>10);
        $season = isset($ordinals[$m[1]]) ? $ordinals[$m[1]] : null;
    }
    return array($season, $episode);
}

function api4_episode_scope_for_type($season, $episode, $contentType) {
    if (strtolower(trim((string)$contentType)) === 'movie') return array(null, null);
    return array($season, $episode);
}

function api4_size_from_text($text) {
    return preg_match('/\b(\d+(?:\.\d+)?\s*(?:GB|MB|KB|گیگ(?:ابایت)?|مگ(?:ابایت)?))\b/iu', (string)$text, $m) ? api4_clean_text($m[1]) : '';
}

function api4_is_media_href($href) {
    $path = strtolower((string)(parse_url($href, PHP_URL_PATH) ?: ''));
    return (bool)preg_match('/\.(?:mkv|mp4|m3u8|avi|webm|mov|ts|zip|rar|srt|vtt|ass|ssa)(?:$|\?)/i', $path . (parse_url($href, PHP_URL_QUERY) ? '?' : ''));
}

function api4_find_ancestor_class($node, $class, $limit = 8) {
    $cur = $node;
    for ($i = 0; $i < (int)$limit && $cur; $i++, $cur = $cur->parentNode) {
        if (!($cur instanceof DOMElement)) continue;
        $classes = ' ' . preg_replace('/\s+/', ' ', trim((string)$cur->getAttribute('class'))) . ' ';
        if (strpos($classes, ' ' . $class . ' ') !== false) return $cur;
    }
    return null;
}

function api4_download_container_text($node) {
    $box = api4_find_ancestor_class($node, 'downloadBox', 8);
    if ($box instanceof DOMElement) return api4_clean_text($box->textContent);
    $row = api4_find_ancestor_class($node, 'serial-link-item', 5);
    return $row instanceof DOMElement ? api4_clean_text($row->textContent) : '';
}

function api4_decode_player_subtitle($href) {
    $query = (string)(parse_url((string)$href, PHP_URL_QUERY) ?: '');
    if ($query === '') return '';
    parse_str($query, $params);
    $encoded = isset($params['sub']) ? trim((string)$params['sub']) : '';
    if ($encoded === '') return '';
    $encoded = strtr($encoded, '-_', '+/');
    $padding = strlen($encoded) % 4;
    if ($padding) $encoded .= str_repeat('=', 4 - $padding);
    $decoded = base64_decode($encoded, true);
    if (!is_string($decoded) || !preg_match('~^https?://~i', $decoded)) return '';
    return $decoded;
}


function api4_is_plain_subtitle_url($url) {
    $url = trim((string)$url);
    if ($url === '' || !preg_match('~^https?://~i', $url)) return false;
    $path = strtolower((string)(parse_url($url, PHP_URL_PATH) ?: ''));
    $query = strtolower((string)(parse_url($url, PHP_URL_QUERY) ?: ''));
    return (bool)preg_match('/\.(?:srt|vtt|ass|ssa)(?:$|[?#])/i', $path . ($query !== '' ? '?' . $query : ''));
}

function api4_find_subtitle_in_context($xpath, $context, $pageUrl) {
    if (!($context instanceof DOMElement)) return '';
    $nodes = $xpath->query(".//a[@href] | .//*[@data-link or @data-url or @data-href]", $context);
    if (!$nodes || !$nodes->length) return '';
    $labelCandidate = '';
    foreach ($nodes as $node) {
        if (!($node instanceof DOMElement)) continue;
        $raw = trim((string)$node->getAttribute('href'));
        if ($raw === '' || $raw === '#') {
            foreach (array('data-link','data-url','data-href') as $attr) {
                $value = trim((string)$node->getAttribute($attr));
                if ($value !== '') { $raw = $value; break; }
            }
        }
        $href = api4_abs_url($raw, $pageUrl);
        if ($href === '') continue;
        $decoded = api4_decode_player_subtitle($href);
        if ($decoded !== '' && api4_is_plain_subtitle_url($decoded)) return $decoded;
        if (api4_is_plain_subtitle_url($href)) return $href;
        $signal = api4_lower(api4_clean_text($node->textContent . ' ' . $node->getAttribute('title') . ' ' . $node->getAttribute('aria-label')));
        if ($labelCandidate === '' && preg_match('/زیر\s*نویس|subtitle|srt|vtt|ass|ssa/ui', $signal)) {
            $labelCandidate = $href;
        }
    }
    return api4_is_plain_subtitle_url($labelCandidate) ? $labelCandidate : '';
}

function api4_validate_subtitle_fetch_url($url) {
    $url = trim((string)$url);
    if (!api4_is_plain_subtitle_url($url)) throw new RuntimeException('لینک زیرنویس معتبر نیست.');
    if (function_exists('bm_security_public_http_url')) {
        $url = bm_security_public_http_url($url);
        if ($url === '') throw new RuntimeException('مقصد زیرنویس مجاز نیست.');
    } else {
        $parts = @parse_url($url);
        $host = strtolower((string)($parts['host'] ?? ''));
        if ($host === '' || (function_exists('bm_security_host_resolves_public') && !bm_security_host_resolves_public($host))) {
            throw new RuntimeException('مقصد زیرنویس مجاز نیست.');
        }
    }
    return $url;
}

function api4_fetch_subtitle_url($url) {
    $url = api4_validate_subtitle_fetch_url($url);
    $limit = 2 * 1024 * 1024;
    $redirects = 0;
    while ($redirects <= 3) {
        $body = '';
        $headers = array();
        $ch = curl_init($url);
        $opts = array(
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_MAXREDIRS => 0,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_ENCODING => '',
            CURLOPT_HEADER => false,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36',
            CURLOPT_HTTPHEADER => array(
                'Accept: text/plain,text/vtt,application/x-subrip,*/*;q=0.5',
                'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.7,en;q=0.6',
                'Referer: ' . API4_BASE_URL . '/',
            ),
            CURLOPT_HEADERFUNCTION => function($ch, $line) use (&$headers) {
                $len = strlen($line);
                $pos = strpos($line, ':');
                if ($pos !== false) {
                    $name = strtolower(trim(substr($line, 0, $pos)));
                    $value = trim(substr($line, $pos + 1));
                    if ($name !== '') $headers[$name] = $value;
                }
                return $len;
            },
            CURLOPT_WRITEFUNCTION => function($ch, $chunk) use (&$body, $limit) {
                $body .= $chunk;
                if (strlen($body) > $limit) return 0;
                return strlen($chunk);
            },
        );
        if (defined('CURLOPT_PROTOCOLS')) $opts[CURLOPT_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        if (defined('CURLOPT_REDIR_PROTOCOLS')) $opts[CURLOPT_REDIR_PROTOCOLS] = CURLPROTO_HTTP | CURLPROTO_HTTPS;
        curl_setopt_array($ch, $opts);
        $ok = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $ctype = strtolower((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE));
        $error = curl_error($ch);
        curl_close($ch);

        if ($status >= 300 && $status < 400 && !empty($headers['location'])) {
            if (++$redirects > 3) throw new RuntimeException('تغییر مسیر زیرنویس بیش از حد بود.');
            $next = function_exists('bm_security_resolve_url') ? bm_security_resolve_url($url, $headers['location']) : api4_abs_url($headers['location'], $url);
            $url = api4_validate_subtitle_fetch_url($next);
            continue;
        }
        if ($ok === false || $status < 200 || $status >= 300) {
            throw new RuntimeException('دریافت زیرنویس انجام نشد: ' . ($error !== '' ? $error : ('HTTP ' . $status)));
        }
        if (strlen($body) > $limit) throw new RuntimeException('فایل زیرنویس بیش از حد بزرگ است.');
        $head = substr($body, 0, 4096);
        if (preg_match('~<\s*(?:html|body|script|iframe)\b~i', $head)) throw new RuntimeException('پاسخ زیرنویس متنی نیست.');
        if (substr($body, 0, 2) === 'PK' || substr($body, 0, 4) === "Rar!") {
            throw new RuntimeException('فایل فشرده باید ابتدا استخراج شود.');
        }
        if (!preg_match('/(?:--> |-->\s*\d|^WEBVTT|^\[Script Info\]|^Dialogue:)/mi', $body)) {
            throw new RuntimeException('ساختار زیرنویس قابل تشخیص نیست.');
        }
        return $body;
    }
    throw new RuntimeException('دریافت زیرنویس انجام نشد.');
}


/**
 * Archive 4 / Cinamatic structured download parser.
 *
 * Cinamatic exposes the authoritative information in a predictable hierarchy:
 *   .downloadBox
 *     .boxHead  -> season / quality / language/type
 *     .boxRows
 *       .row
 *         .links a.download -> direct media URL / filename
 *         .infos .name      -> episode label
 *         .infos .size      -> exact file size
 *
 * Reading those fields directly is safer than scanning the whole row text. It also
 * lets us recognize a series even when the page title/status itself does not say "سریال".
 */
function api4_extract_cinamatic_download_boxes($xpath, $pageUrl, $contentType = '') {
    $downloads = array();
    $seen = array();

    $boxes = $xpath->query("//*[" . api4_class_xpath('downloadBox') . "]");
    if (!$boxes || !$boxes->length) return array();

    foreach ($boxes as $box) {
        if (!($box instanceof DOMElement)) continue;

        $boxHead = api4_first_nonempty(array(
            api4_node_text($xpath, ".//*[" . api4_class_xpath('boxHead') . "]//p", $box),
            api4_node_text($xpath, "./p[1]", $box),
        ));

        list($headerSeason, $headerEpisode) = api4_season_episode($boxHead);
        $headerQuality = api4_quality_from_text($boxHead);
        $headerType = api4_download_type('', $boxHead);

        $rows = $xpath->query(".//*[" . api4_class_xpath('row') . "]", $box);
        if (!$rows || !$rows->length) continue;

        foreach ($rows as $row) {
            if (!($row instanceof DOMElement)) continue;

            $downloadNodes = $xpath->query(
                ".//a[@href and contains(concat(' ', normalize-space(@class), ' '), ' download ')]",
                $row
            );
            if (!$downloadNodes || !$downloadNodes->length) continue;

            $a = null;
            $href = '';
            foreach ($downloadNodes as $candidate) {
                if (!($candidate instanceof DOMElement)) continue;
                $raw = trim((string)$candidate->getAttribute('href'));
                $candidateHref = api4_abs_url($raw, $pageUrl);
                if ($candidateHref === '') continue;

                $host = strtolower((string)(parse_url($candidateHref, PHP_URL_HOST) ?: ''));
                $isExternal = $host !== '' && !api4_allowed_host($host);
                if (!api4_is_media_href($candidateHref) && !$isExternal) continue;

                $a = $candidate;
                $href = $candidateHref;
                break;
            }
            if (!($a instanceof DOMElement) || $href === '') continue;

            $key = sha1($href);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;

            $rowName = api4_first_nonempty(array(
                api4_node_text($xpath, ".//*[" . api4_class_xpath('infos') . "]//*[" . api4_class_xpath('name') . "]", $row),
                api4_node_text($xpath, ".//*[" . api4_class_xpath('name') . "]", $row),
            ));
            $rowSize = api4_first_nonempty(array(
                api4_node_text($xpath, ".//*[" . api4_class_xpath('infos') . "]//*[" . api4_class_xpath('size') . "]", $row),
                api4_node_text($xpath, ".//*[@aria-label='حجم فایل']", $row),
                api4_node_text($xpath, ".//*[" . api4_class_xpath('size') . "]", $row),
            ));

            $label = api4_clean_text($a->textContent);
            $titleAttr = api4_clean_text($a->getAttribute('title') . ' ' . $a->getAttribute('aria-label'));
            $rowText = api4_clean_text($row->textContent);
            $localText = api4_clean_text($href . ' ' . $label . ' ' . $titleAttr);

            // Filename is the strongest signal (S01E02 etc.), then explicit row label,
            // then box header.
            list($season, $episode) = api4_season_episode($localText);
            list($rowSeason, $rowEpisode) = api4_season_episode($rowName . ' ' . $rowText);

            if ($season === null) $season = $rowSeason !== null ? $rowSeason : $headerSeason;
            if ($episode === null) $episode = $rowEpisode !== null ? $rowEpisode : $headerEpisode;

            // Do not erase season/episode merely because the title-level type inference
            // guessed "movie". Explicit SxxExx / فصل / قسمت evidence is authoritative.
            $strongSeriesEvidence = $season !== null || $episode !== null
                || preg_match('/\bS\d{1,2}E\d{1,3}\b/i', api4_latin_digits($href . ' ' . $rowName . ' ' . $boxHead));

            if (!$strongSeriesEvidence) {
                list($season, $episode) = api4_episode_scope_for_type($season, $episode, $contentType);
            }

            // Cinamatic's box heading is authoritative for quality; filename is fallback.
            $quality = $headerQuality !== 'نامشخص'
                ? $headerQuality
                : api4_quality_from_text($localText . ' ' . $rowName . ' ' . $rowText);

            // Filename/row determines HardSub/SoftSub/Dubbed before generic header.
            $type = api4_download_type($localText . ' ' . $rowName, $boxHead);
            if ($type === 'original' && $headerType !== 'original') $type = $headerType;

            $ext = strtolower(pathinfo((string)(parse_url($href, PHP_URL_PATH) ?: ''), PATHINFO_EXTENSION));
            if (in_array($ext, array('srt','vtt','ass','ssa'), true)) $mediaType = 'subtitle';
            elseif (in_array($ext, array('mka','mp3','m4a','aac','ogg','wav','flac'), true)) $mediaType = 'audio';
            elseif ($ext === 'm3u8') $mediaType = 'stream';
            else $mediaType = 'video';
            if ($mediaType === 'audio' && $type === 'dubbed') $type = 'audio';

            $subtitleUrl = '';
            $playNodes = $xpath->query(
                ".//a[contains(@class,'play-grid') or contains(@class,'showChosePlayModal') or contains(@href,'/player?')]",
                $row
            );
            if ($playNodes && $playNodes->length && $playNodes->item(0) instanceof DOMElement) {
                $subtitleUrl = api4_decode_player_subtitle(
                    api4_abs_url($playNodes->item(0)->getAttribute('href'), $pageUrl)
                );
            }
            if ($subtitleUrl === '') $subtitleUrl = api4_find_subtitle_in_context($xpath, $row, $pageUrl);

            // Exact visible size span wins. Regex is fallback only.
            $size = $rowSize !== '' ? $rowSize : api4_size_from_text($rowText);
            $size = api4_clean_text($size);

            $typeFa = array(
                'dubbed'=>'دوبله فارسی',
                'hardsub'=>'هاردساب فارسی',
                'softsub'=>'سافت‌ساب فارسی',
                'subtitle'=>'زیرنویس فارسی',
                'audio'=>'صوت دوبله',
                'original'=>'نسخه اصلی'
            );
            $displayParts = array();
            if ($season !== null) $displayParts[] = 'فصل ' . $season;
            if ($episode !== null) $displayParts[] = 'قسمت ' . $episode;
            if ($quality !== 'نامشخص') $displayParts[] = $quality;
            $displayParts[] = isset($typeFa[$type]) ? $typeFa[$type] : $type;
            $displayLabel = implode(' • ', array_filter($displayParts));

            $downloads[] = array(
                'url' => $href,
                'label' => $displayLabel,
                'display_label' => $displayLabel,
                'quality' => $quality,
                'type' => $type,
                'type_label' => api4_download_type_label($type),
                'subtitle_type' => in_array($type, array('hardsub','softsub','subtitle'), true) ? $type : null,
                'media_type' => $mediaType,
                'season' => $season,
                'episode' => $episode,
                'size' => $size,
                'subtitle_url' => $subtitleUrl,
                'is_direct' => true,
            );
        }
    }

    $rank = array('2160p'=>7,'1440p'=>6,'1080p'=>5,'720p'=>4,'576p'=>3,'540p'=>3,'480p'=>2,'360p'=>1,'240p'=>0,'نامشخص'=>-1);
    usort($downloads, function($a, $b) use ($rank) {
        $sa = $a['season'] === null ? -1 : (int)$a['season'];
        $sb = $b['season'] === null ? -1 : (int)$b['season'];
        if ($sa !== $sb) return $sa <=> $sb;
        $ea = $a['episode'] === null ? -1 : (int)$a['episode'];
        $eb = $b['episode'] === null ? -1 : (int)$b['episode'];
        if ($ea !== $eb) return $ea <=> $eb;
        $ta = (string)($a['type'] ?? '');
        $tb = (string)($b['type'] ?? '');
        if ($ta !== $tb) return strcmp($ta, $tb);
        return ($rank[$b['quality']] ?? -1) <=> ($rank[$a['quality']] ?? -1);
    });

    return $downloads;
}

function api4_extract_downloads($xpath, $pageUrl, $contentType = '') {
    $structured = api4_extract_cinamatic_download_boxes($xpath, $pageUrl, $contentType);
    if ($structured) return $structured;

    $downloads = array();
    $seen = array();
    $links = $xpath->query("//a[@href] | //*[@data-link or @data-url or @data-href]");
    foreach ($links as $a) {
        if (!($a instanceof DOMElement)) continue;
        $hrefRaw = trim((string)$a->getAttribute('href'));
        if ($hrefRaw === '' || $hrefRaw === '#') {
            foreach (array('data-link','data-url','data-href') as $attr) {
                $candidate = trim((string)$a->getAttribute($attr));
                if ($candidate !== '') { $hrefRaw = $candidate; break; }
            }
        }
        $href = api4_abs_url($hrefRaw, $pageUrl);
        if ($href === '') continue;

        $label = api4_clean_text($a->textContent);
        $titleAttr = api4_clean_text($a->getAttribute('title') . ' ' . $a->getAttribute('aria-label'));
        $class = api4_lower($a->getAttribute('class') . ' ' . $a->getAttribute('id'));
        $host = strtolower((string)(parse_url($href, PHP_URL_HOST) ?: ''));
        $path = strtolower((string)(parse_url($href, PHP_URL_PATH) ?: ''));

        $isPlayerLink = api4_contains($class, 'play-grid') || api4_contains($class, 'showchoseplaymodal') ||
            (api4_allowed_host($host) && (api4_contains($path, '/player') || preg_match('/[?&]file=/i', $href)));
        if ($isPlayerLink) continue;
        if (api4_contains($class, 'toggletrailermodal') || api4_contains(api4_lower($label . ' ' . $titleAttr), 'تریلر') || api4_contains(api4_lower($label . ' ' . $titleAttr), 'trailer')) continue;
        if (preg_match('~(?:instagram|telegram|imdb\.com|facebook|twitter|mailto:|tg://)~i', $href)) continue;

        $box = api4_find_ancestor_class($a, 'downloadBox', 8);
        $row = api4_find_ancestor_class($a, 'serial-link-item', 5);
        if (!$row && $box instanceof DOMElement) $row = api4_find_ancestor_class($a, 'row', 5);
        $boxHead = '';
        if ($box instanceof DOMElement) {
            $boxHead = api4_first_nonempty(array(
                api4_node_text($xpath, ".//*[" . api4_class_xpath('boxHead') . "]//p", $box),
                api4_node_text($xpath, './p[1]', $box),
            ));
        }
        $rowText = $row instanceof DOMElement ? api4_clean_text($row->textContent) : '';
        $localText = api4_clean_text($href . ' ' . $label . ' ' . $titleAttr);
        $combined = api4_clean_text($localText . ' ' . $boxHead . ' ' . $rowText . ' ' . $class);

        $isExternal = $host !== '' && !api4_allowed_host($host);
        $isMedia = api4_is_media_href($href);
        $downloadContext = preg_match('/download|quality|episode|season|link|dlbox|boxdl|دریافت|دانلود|کیفیت|قسمت|فصل/iu', $combined);
        $isInternalDownload = api4_allowed_host($host) && $downloadContext && preg_match('~/(?:download|dl|redirect|go)(?:/|\?|$)|[?&](?:download|url)=~i', $href);
        if (!$isMedia && !($isExternal && $downloadContext) && !$isInternalDownload) continue;

        $key = sha1($href);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;

        list($season, $episode) = api4_season_episode($localText);
        list($headerSeason, $headerEpisode) = api4_season_episode($boxHead);
        if ($season === null) $season = $headerSeason;
        if ($episode === null) {
            list($rowSeason, $rowEpisode) = api4_season_episode($rowText);
            if ($season === null) $season = $rowSeason;
            $episode = $rowEpisode !== null ? $rowEpisode : $headerEpisode;
        }
        list($season, $episode) = api4_episode_scope_for_type($season, $episode, $contentType);

        $quality = api4_quality_from_text($localText . ' ' . $rowText . ' ' . $boxHead);
        $type = api4_download_type($localText . ' ' . $rowText, $boxHead);
        $ext = strtolower(pathinfo((string)(parse_url($href, PHP_URL_PATH) ?: ''), PATHINFO_EXTENSION));
        if (in_array($ext, array('srt','vtt','ass','ssa'), true)) $mediaType = 'subtitle';
        elseif (in_array($ext, array('mka','mp3','m4a','aac','ogg','wav','flac'), true)) $mediaType = 'audio';
        elseif ($ext === 'm3u8') $mediaType = 'stream';
        else $mediaType = 'video';
        if ($mediaType === 'audio' && $type === 'dubbed') $type = 'audio';
        $subtitleUrl = '';
        if ($row instanceof DOMElement) {
            $playNodes = $xpath->query(".//a[contains(@class,'play-grid') or contains(@class,'showChosePlayModal') or contains(@href,'/player?')]", $row);
            if ($playNodes && $playNodes->length && $playNodes->item(0) instanceof DOMElement) {
                $subtitleUrl = api4_decode_player_subtitle(api4_abs_url($playNodes->item(0)->getAttribute('href'), $pageUrl));
            }
            if ($subtitleUrl === '') $subtitleUrl = api4_find_subtitle_in_context($xpath, $row, $pageUrl);
        }

        $typeFa = array('dubbed'=>'دوبله فارسی','hardsub'=>'هاردساب فارسی','softsub'=>'سافت‌ساب فارسی','subtitle'=>'زیرنویس فارسی','audio'=>'صوت دوبله','original'=>'نسخه اصلی');
        $displayParts = array();
        if ($season !== null) $displayParts[] = 'فصل ' . $season;
        if ($episode !== null) $displayParts[] = 'قسمت ' . $episode;
        if ($quality !== 'نامشخص') $displayParts[] = $quality;
        $displayParts[] = isset($typeFa[$type]) ? $typeFa[$type] : $type;
        $displayLabel = implode(' • ', array_filter($displayParts));
        $genericLabel = $label === '' || api4_contains($label, 'لینک مستقیم') || api4_contains($label, 'دانلود با لینک');

        $downloads[] = array(
            'url' => $href,
            'label' => $genericLabel ? $displayLabel : $label,
            'display_label' => $displayLabel,
            'quality' => $quality,
            'type' => $type,
            'type_label' => api4_download_type_label($type),
            'subtitle_type' => in_array($type, array('hardsub','softsub','subtitle'), true) ? $type : null,
            'media_type' => $mediaType,
            'season' => $season,
            'episode' => $episode,
            'size' => api4_size_from_text($localText . ' ' . $rowText . ' ' . $boxHead),
            'subtitle_url' => $subtitleUrl,
            'is_direct' => $isMedia || $isExternal,
        );
    }

    $rank = array('2160p'=>7,'1440p'=>6,'1080p'=>5,'720p'=>4,'576p'=>3,'540p'=>3,'480p'=>2,'360p'=>1,'240p'=>0,'نامشخص'=>-1);
    usort($downloads, function($a, $b) use ($rank) {
        $sa = $a['season'] === null ? -1 : (int)$a['season'];
        $sb = $b['season'] === null ? -1 : (int)$b['season'];
        if ($sa !== $sb) return $sa <=> $sb;
        $ea = $a['episode'] === null ? -1 : (int)$a['episode'];
        $eb = $b['episode'] === null ? -1 : (int)$b['episode'];
        if ($ea !== $eb) return $ea <=> $eb;
        return ($rank[$b['quality']] ?? -1) <=> ($rank[$a['quality']] ?? -1);
    });
    return $downloads;
}


function api4_details_url($identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') throw new RuntimeException('شناسه یا لینک خالی است.');
    if (preg_match('~^https?://~i', $identifier)) {
        $parts = @parse_url($identifier);
        $incomingScheme = strtolower((string)($parts['scheme'] ?? ''));
        $incomingHost = strtolower((string)($parts['host'] ?? ''));
        if (!in_array($incomingScheme, ['http','https'], true) || !api4_allowed_host($incomingHost)) {
            throw new RuntimeException('لینک این آرشیو مجاز نیست.');
        }
        $baseHost = strtolower((string)(parse_url(API4_BASE_URL, PHP_URL_HOST) ?: ''));
        if ($baseHost !== '' && $incomingHost !== $baseHost) {
            $identifier = rtrim(API4_BASE_URL, '/') . '/' . ltrim((string)($parts['path'] ?? ''), '/');
            if (!empty($parts['query'])) $identifier .= '?' . $parts['query'];
        }
        return api4_validate_url($identifier);
    }

    $identifier = rawurldecode(trim($identifier, '/'));
    if ($identifier === '') throw new RuntimeException('شناسه معتبر نیست.');
    if (preg_match('/^p(?:ost)?[-_:]?(\d+)$/i', $identifier, $m)) {
        return API4_BASE_URL . '/?p=' . (int)$m[1];
    }
    if (ctype_digit($identifier)) return API4_BASE_URL . '/?p=' . (int)$identifier;

    $segments = array();
    foreach (explode('/', $identifier) as $segment) {
        $segment = trim(rawurldecode($segment));
        if ($segment !== '') $segments[] = rawurlencode($segment);
    }
    if (!$segments) throw new RuntimeException('شناسه معتبر نیست.');
    return API4_BASE_URL . '/' . implode('/', $segments) . '/';
}

function api4_first_nonempty($values) {
    foreach ((array)$values as $value) if (api4_clean_text($value) !== '') return api4_clean_text($value);
    return '';
}

function api4_get_details($identifier) {
    $requestedUrl = api4_details_url($identifier);
    $res = api4_get_html($requestedUrl, API4_CACHE_TTL_DETAIL, 0);
    $xpath = api4_xpath_from_html($res['html']);
    $canonical = api4_node_attr($xpath, "//link[contains(concat(' ', normalize-space(@rel), ' '), ' canonical ')]", 'href');
    $url = $canonical !== '' ? api4_abs_url($canonical, $requestedUrl) : $res['url'];
    api4_validate_url($url);
    $slug = api4_slug_from_url($url);
    $jsonld = api4_jsonld_main($xpath);

    $scope = $xpath->query("//main//article[" . api4_class_xpath('postItem') . "]")->item(0);
    if (!$scope) $scope = $xpath->query("//article[" . api4_class_xpath('postItem') . "]")->item(0);
    if (!$scope) $scope = $xpath->query('//main')->item(0);
    if (!$scope) $scope = $xpath->query('//body')->item(0);

    $sourcePostId = api4_source_post_id($xpath, null, $requestedUrl);
    $detailId = api4_detail_id($sourcePostId, $slug);
    $h1 = api4_first_nonempty(array(
        $scope ? api4_node_text($xpath, './/h1/a', $scope) : '',
        $scope ? api4_node_attr($xpath, './/h1/a', 'title', $scope) : '',
        $scope ? api4_node_text($xpath, './/h1', $scope) : '',
        isset($jsonld['name']) ? $jsonld['name'] : '',
        api4_node_attr($xpath, "//meta[@property='og:title']", 'content'),
        api4_node_text($xpath, '//title'),
    ));
    $h1 = preg_replace('/\s*[–—|-]\s*(?:سینماتیک|Cinamatic).*$/iu', '', $h1);
    $titles = api4_title_parts($h1);

    $poster = '';
    $posterQueries = array(
        ".//*[" . api4_class_xpath('thumbnailWrapper') . "]//img",
        ".//*[contains(@class,'poster') or contains(@class,'thumbnail')]//img",
        ".//img[contains(@class,'wp-post-image')]",
    );
    if ($scope) {
        foreach ($posterQueries as $q) {
            $nodes = $xpath->query($q, $scope);
            if ($nodes && $nodes->length) {
                $poster = api4_pick_image($nodes->item(0), $url);
                if ($poster !== '') break;
            }
        }
    }
    if ($poster === '') $poster = api4_abs_url(api4_node_attr($xpath, "//meta[@property='og:image']", 'content'), $url);
    if ($poster === '' && isset($jsonld['image'])) {
        $image = $jsonld['image'];
        if (is_array($image)) $image = isset($image['url']) ? $image['url'] : (isset($image[0]) ? $image[0] : '');
        $poster = api4_abs_url((string)$image, $url);
    }

    $meta = api4_meta_rows($xpath, $scope ?: null);
    $genreText = api4_meta_value($meta, array('ژانر'));
    $genres = api4_split_list($genreText);
    if (!$genres && isset($jsonld['genre'])) $genres = api4_split_list(is_array($jsonld['genre']) ? implode('|', $jsonld['genre']) : $jsonld['genre']);
    $year = api4_extract_year(api4_meta_value($meta, array('سال انتشار', 'سال')) . ' ' . $h1 . ' ' . ($jsonld['datePublished'] ?? ''));
    $country = api4_meta_links($meta, array('محصول', 'کشور'));
    if (!$country) $country = api4_split_list(api4_meta_value($meta, array('محصول', 'کشور')));
    $directors = api4_meta_links($meta, array('کارگردان'));
    if (!$directors && isset($jsonld['director'])) $directors = api4_people_from_jsonld($jsonld['director']);
    $actors = api4_meta_links($meta, array('ستارگان', 'بازیگران'));
    if (!$actors && isset($jsonld['actor'])) $actors = api4_people_from_jsonld($jsonld['actor']);
    $writers = api4_meta_links($meta, array('نویسنده'));
    if (!$writers && isset($jsonld['creator'])) $writers = api4_people_from_jsonld($jsonld['creator']);

    $description = api4_first_nonempty(array(
        $scope ? api4_node_text($xpath, ".//p[" . api4_class_xpath('plot') . "]", $scope) : '',
        $scope ? api4_node_text($xpath, ".//*[contains(@class,'story') or contains(@class,'description') or contains(@class,'summary')]//p", $scope) : '',
        isset($jsonld['description']) ? $jsonld['description'] : '',
        api4_node_attr($xpath, "//meta[@name='description']", 'content'),
        api4_node_attr($xpath, "//meta[@property='og:description']", 'content'),
    ));
    $description = preg_replace('/^خلاصه\s*داستان\s*:\s*/u', '', $description);
    $longDescription = api4_first_nonempty(array(
        $scope ? api4_node_text($xpath, ".//*[contains(@class,'postContent') or contains(@class,'post-content') or contains(@class,'entry-content')]", $scope) : '',
        $description,
    ));

    $ratingText = api4_first_nonempty(array(
        $scope ? api4_node_text($xpath, ".//*[" . api4_class_xpath('imdb') . "]//*[" . api4_class_xpath('rate') . "]", $scope) : '',
        isset($jsonld['aggregateRating']['ratingValue']) ? $jsonld['aggregateRating']['ratingValue'] : '',
    ));
    $rating = preg_match('/(\d+(?:\.\d+)?)/', $ratingText, $m) ? (float)$m[1] : null;
    $runtimeText = api4_meta_value($meta, array('مدت زمان'));
    $runtime = preg_match('/(\d{1,4})/', $runtimeText, $m) ? (int)$m[1] : null;
    $audience = api4_meta_value($meta, array('مخاطب'));
    $network = api4_meta_value($meta, array('شبکه'));
    $language = api4_meta_value($meta, array('زبان'));
    $statusText = $scope ? api4_first_nonempty(array(
        api4_node_text($xpath, ".//*[" . api4_class_xpath('info') . "]//*[" . api4_class_xpath('text') . "]//*[" . api4_class_xpath('section') . "]", $scope),
        api4_node_text($xpath, ".//*[" . api4_class_xpath('section') . "]", $scope),
    )) : '';
    $awardText = $scope ? api4_node_text($xpath, ".//*[" . api4_class_xpath('oskar') . "]", $scope) : '';
    $trailer = $scope ? api4_abs_url(api4_node_attr($xpath, ".//a[" . api4_class_xpath('toggleTrailerModal') . "]", 'href', $scope), $url) : '';
    if ($trailer === '') $trailer = api4_abs_url(api4_node_attr($xpath, '//video/source', 'src'), $url);
    $jsonType = $jsonld['@type'] ?? '';
    if (is_array($jsonType)) $jsonType = implode(' ', $jsonType);
    $type = api4_infer_type($h1 . ' ' . $statusText . ' ' . $jsonType, $url, '');
    $downloads = api4_extract_downloads($xpath, $url, $type);

    // V78: the source download rows are authoritative for series detection.
    // Some Cinamatic pages (e.g. Banshee) have a neutral h1/status but filenames and
    // box headings contain SxxExx / فصل / قسمت. Do not render those as movies.
    if ($type === 'movie' && is_array($downloads)) {
        foreach ($downloads as $downloadRow) {
            if (!is_array($downloadRow)) continue;
            if (($downloadRow['season'] ?? null) !== null || ($downloadRow['episode'] ?? null) !== null) {
                $type = 'series';
                break;
            }
        }
    }

    $badgeText = $scope ? api4_clean_text(
        api4_node_text($xpath, ".//*[" . api4_class_xpath('info') . "]//*[" . api4_class_xpath('text') . "]", $scope) . ' ' .
        api4_node_text($xpath, ".//*[" . api4_class_xpath('floatInfo') . "]", $scope)
    ) : '';
    $hasDubbed = api4_contains($badgeText, 'دوبله');
    $hasSubtitle = api4_contains($badgeText, 'زیرنویس');
    $hasOnline = $scope ? (bool)$xpath->query(".//a[contains(@class,'play-grid') or contains(@class,'showChosePlayModal') or contains(@class,'online') or contains(@class,'playonline') or contains(@href,'/player?')]", $scope)->length : false;
    $hasSoftsub = false;
    $hasHardsub = false;
    $subtitleTypes = array();
    foreach ($downloads as $download) {
        $downloadType = (string)($download['type'] ?? '');
        if ($downloadType === 'dubbed' || $downloadType === 'audio') $hasDubbed = true;
        if (in_array($downloadType, array('subtitle','softsub','hardsub'), true)) {
            $hasSubtitle = true;
            if (!in_array($downloadType, $subtitleTypes, true)) $subtitleTypes[] = $downloadType;
        }
        if ($downloadType === 'softsub') $hasSoftsub = true;
        if ($downloadType === 'hardsub') $hasHardsub = true;
        if (($download['media_type'] ?? '') === 'stream') $hasOnline = true;
    }

    $imdbCode = null;
    $imdbLink = $scope ? api4_node_attr($xpath, ".//a[contains(@href,'imdb.com/title/')]", 'href', $scope) : '';
    if (preg_match('/title\/(tt\d+)/i', $imdbLink, $m)) $imdbCode = $m[1];
    return array(
        'status' => 'success',
        'id' => $slug,
        'slug' => $slug,
        'detail_id' => $detailId,
        'source_post_id' => $sourcePostId > 0 ? $sourcePostId : null,
        'imdb_code' => $imdbCode,
        'url' => $url,
        'source_url' => $url,
        'title' => $titles['en'],
        'title_fa' => $titles['fa'],
        'full_title' => $titles['full'],
        'year' => $year,
        'type' => $type,
        'poster' => $poster,
        'backdrop' => $poster,
        'rating' => $rating,
        'runtime' => $runtime,
        'duration' => $runtime,
        'age_rate' => $audience,
        'audience' => $audience,
        'country' => $country,
        'countries' => $country,
        'genres' => $genres,
        'description' => api4_clean_text($description),
        'long_description' => api4_clean_text($longDescription),
        'actors' => $actors,
        'directors' => $directors,
        'director' => $directors ? implode('، ', $directors) : '',
        'writers' => $writers,
        'language' => $language,
        'languages' => $language !== '' ? api4_split_list($language) : array(),
        'network' => $network,
        'status_text' => $statusText,
        'update_note' => $statusText,
        'award_text' => $awardText,
        'trailer' => $trailer,
        'trailer_url' => $trailer,
        'has_online' => $hasOnline,
        'has_dubbed' => $hasDubbed,
        'has_subtitle' => $hasSubtitle,
        'has_softsub' => $hasSoftsub,
        'has_hardsub' => $hasHardsub,
        'subtitle_types' => $subtitleTypes,
        'login_required' => false,
        'downloads_locked' => false,
        'downloads_count' => count($downloads),
        'downloads' => $downloads,
    );
}
