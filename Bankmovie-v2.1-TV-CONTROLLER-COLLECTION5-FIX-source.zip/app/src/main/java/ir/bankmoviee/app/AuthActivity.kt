package ir.bankmoviee.app

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.Rect
import android.os.Bundle
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.net.HttpURLConnection
import java.net.URL

class AuthActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var backgroundImage: ImageView
    private lateinit var page: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var statusText: TextView
    private var registerMode = false
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.rgb(8, 8, 11)
        buildShell()
        renderForm()

        val cached = AccountSession.authBackground(this)
            .ifBlank { AppConfig.BASE_URL.trimEnd('/') + "/uploads/poste.webp" }
        loadBackground(cached)
        AccountApi.loadConfig(this) { result ->
            val url = result.json?.optString("background_url").orEmpty()
            if (url.isNotBlank() && url != cached) loadBackground(url)
            if (!AccountSession.registrationEnabled(this) && registerMode) registerMode = false
            renderForm()
        }
    }

    private fun buildShell() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(8, 8, 11))
            clipChildren = false
            clipToPadding = false
        }
        backgroundImage = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.42f
        }
        root.addView(backgroundImage, FrameLayout.LayoutParams(-1, -1))

        root.addView(View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(120, 8, 8, 12), Color.argb(235, 8, 8, 12), Color.rgb(8, 8, 11))
            )
        }, FrameLayout.LayoutParams(-1, -1))

        scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            clipChildren = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            setPadding(0, 0, 0, dp(28))
        }
        page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(18), dp(18), dp(34))
        }
        scroll.addView(page, FrameLayout.LayoutParams(-1, -2))
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { _, insets ->
            val imeBottom = insets.getInsets(WindowInsetsCompat.Type.ime()).bottom
            val navigationBottom = insets.getInsets(WindowInsetsCompat.Type.systemBars()).bottom
            val bottom = dp(28) + maxOf(imeBottom, navigationBottom)
            if (scroll.paddingBottom != bottom) scroll.setPadding(0, 0, 0, bottom)
            insets
        }
        ViewCompat.requestApplyInsets(root)
    }

    private fun renderForm() {
        page.removeAllViews()
        val palette = UiPreferences.palette(this)

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_back)
            setColorFilter(Color.WHITE)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = rounded(Color.argb(65, 255, 255, 255), 18, Color.argb(45, 255, 255, 255))
            applyFocusHalo(this, 999, 1.055f)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(46), dp(46)))
        top.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.bankmovie_mark_transparent)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(dp(56), dp(44)))
        page.addView(top, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(30) })

        page.addView(TextView(this).apply {
            text = if (registerMode) "ثبت‌نام در بانک مووی" else "ورود به حساب کاربری"
            setTextColor(Color.WHITE)
            textSize = 29f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }, LinearLayout.LayoutParams(-1, -2))

        page.addView(TextView(this).apply {
            text = if (registerMode) {
                "برای ساخت حساب، اطلاعات زیر را وارد کنید"
            } else {
                "با نام کاربری یا ایمیل وارد حساب بانک مووی شوید"
            }
            setTextColor(Color.rgb(184, 184, 196))
            textSize = 13.2f
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(24))
        }, LinearLayout.LayoutParams(-1, -2))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(20))
            background = rounded(Color.argb(225, 25, 24, 31), 25, Color.argb(100, 255, 255, 255))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }

        statusText = TextView(this).apply {
            text = if (registerMode) "نام کاربری حداقل ۳ حرف، ایمیل معتبر و رمز عبور حداقل ۸ کاراکتر" else "نام کاربری یا ایمیل و سپس رمز عبور را وارد کنید"
            setTextColor(Color.rgb(190, 194, 207))
            textSize = 11.8f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1f)
            background = rounded(Color.argb(90, 55, 57, 67), 14, Color.argb(75, 255, 255, 255))
            setPadding(dp(12), dp(9), dp(12), dp(9))
        }
        card.addView(statusText, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(15) })

        val identity: EditText?
        val username: EditText?
        val email: EditText?
        val password: EditText
        val confirm: EditText?

        if (registerMode) {
            username = authField(card, "نام کاربری", "نام کاربری را وارد کنید", R.drawable.ic_auth_user, false)
            email = authField(card, "ایمیل", "example@email.com", R.drawable.ic_auth_email, false, true)
            identity = null
        } else {
            identity = authField(card, "نام کاربری یا ایمیل", "نام کاربری یا ایمیل", R.drawable.ic_auth_user, false)
            username = null
            email = null
        }

        password = authField(card, "رمز عبور", "رمز عبور را وارد کنید", R.drawable.ic_auth_lock, true)
        confirm = if (registerMode) {
            authField(card, "تأیید رمز عبور", "رمز عبور را دوباره وارد کنید", R.drawable.ic_auth_lock, true)
        } else null

        val submitLabel = TextView(this).apply {
            text = if (registerMode) "ثبت‌نام" else "ورود"
            setTextColor(Color.WHITE)
            textSize = 15.5f
            typeface = BankmovieFonts.bold(this@AuthActivity)
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        }
        val submit = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.accentColor(this@AuthActivity),
                Color.argb(40, 255, 255, 255)
            )).apply { cornerRadius = dp(17).toFloat() }
            elevation = dp(8).toFloat()
            val inner = LinearLayout(this@AuthActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER
                setPadding(dp(18), 0, dp(18), 0)
                background = rounded(Color.rgb(25, 25, 29), 15, Color.argb(70, 255, 255, 255))
                addView(ImageView(this@AuthActivity).apply {
                    setImageResource(R.drawable.ic_nav_profile)
                    setColorFilter(Color.WHITE)
                }, LinearLayout.LayoutParams(dp(25), dp(25)).apply { marginEnd = dp(13) })
                addView(submitLabel, LinearLayout.LayoutParams(-2, -1))
            }
            addView(inner, LinearLayout.LayoutParams(-1, -1))
            isClickable = true
            isFocusable = true
            applyFocusHalo(this, 17, 1.025f)
            setOnClickListener {
                if (busy) return@setOnClickListener
                animate().cancel()
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(55L).withEndAction {
                    animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                }.start()
                if (registerMode) {
                    submitRegister(username!!, email!!, password, confirm!!, submitLabel)
                } else {
                    submitLogin(identity!!, password, submitLabel)
                }
            }
        }
        card.addView(submit, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })

        password.imeOptions = if (registerMode) android.view.inputmethod.EditorInfo.IME_ACTION_NEXT else android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        confirm?.imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_DONE
        val lastField = confirm ?: password
        lastField.setOnEditorActionListener { _, actionId, event ->
            val enter = event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_UP
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE || enter) {
                submit.performClick()
                true
            } else false
        }
        listOfNotNull(password, confirm).forEach { field ->
            field.setOnClickListener {
                scrollToView(submit)
                showTvKeyboard(field)
            }
        }

        val switch = TextView(this).apply {
            text = if (!AccountSession.registrationEnabled(this@AuthActivity)) "ثبت‌نام موقتاً غیرفعال است" else if (registerMode) "قبلاً ثبت‌نام کرده‌اید؟  ورود" else "حساب ندارید؟  ثبت‌نام"
            setTextColor(Color.rgb(232, 232, 238))
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(20), dp(8), dp(6))
            applyFocusHalo(this, 16, 1.025f)
            setOnClickListener {
                if (!busy && AccountSession.registrationEnabled(this@AuthActivity)) {
                    registerMode = !registerMode
                    renderForm()
                } else if (!AccountSession.registrationEnabled(this@AuthActivity)) {
                    showStatus("ثبت‌نام از پنل مدیریت غیرفعال شده است", true)
                }
            }
        }
        card.addView(switch, LinearLayout.LayoutParams(-1, -2))

        val formWidth = if (isTvLike()) dp(560) else -1
        page.addView(card, LinearLayout.LayoutParams(formWidth, -2).apply { bottomMargin = dp(18) })

        page.addView(TextView(this).apply {
            text = "با ورود یا ثبت‌نام، واچ‌لیست شما روی حساب بانک مووی ذخیره و بین دستگاه‌ها همگام می‌شود."
            setTextColor(Color.rgb(178, 178, 188))
            textSize = 11.7f
            gravity = Gravity.CENTER
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = rounded(Color.argb(155, 25, 24, 31), 18, Color.argb(65, 255, 255, 255))
        }, LinearLayout.LayoutParams(formWidth, -2))
        page.addView(View(this), LinearLayout.LayoutParams(1, dp(if (registerMode) 190 else 120)))

        page.animate().cancel()
        page.alpha = 0f
        page.translationY = dp(8).toFloat()
        page.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(190L)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
        if (isTvLike()) {
            page.postDelayed({ (identity ?: username ?: password).requestFocus() }, 110L)
        }
    }

    private fun authField(
        parent: LinearLayout,
        label: String,
        hint: String,
        icon: Int,
        password: Boolean,
        email: Boolean = false
    ): EditText {
        parent.addView(TextView(this).apply {
            text = label
            setTextColor(Color.rgb(220, 220, 228))
            textSize = 13.3f
            gravity = Gravity.RIGHT
            setPadding(0, 0, dp(4), dp(7))
        }, LinearLayout.LayoutParams(-1, -2))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), 0, dp(12), 0)
            background = rounded(Color.argb(220, 39, 38, 46), 17, Color.argb(105, 255, 255, 255))
        }
        box.addView(ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(Color.rgb(163, 163, 178))
        }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(10) })

        val edit = EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.rgb(116, 116, 128))
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            background = null
            isSingleLine = true
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            inputType = when {
                password -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                email -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
                else -> InputType.TYPE_CLASS_TEXT
            }
            if (isTvLike()) showSoftInputOnFocus = true
        }
        bindTvKeyboard(edit)
        box.addView(edit, LinearLayout.LayoutParams(0, -1, 1f))

        if (password) {
            box.addView(ImageView(this).apply {
                var visible = false
                setImageResource(R.drawable.ic_auth_eye)
                setColorFilter(Color.WHITE)
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = rounded(Color.argb(40, 255, 255, 255), 999, Color.argb(70, 255, 255, 255))
                isClickable = true
                isFocusable = true
                contentDescription = "نمایش رمز عبور"
                if (isTvLike()) {
                    isClickable = false
                    isFocusable = false
                } else {
                    applyFocusHalo(this, 999, 1.06f)
                }
                setOnClickListener {
                    val selection = edit.selectionStart.coerceAtLeast(0)
                    visible = !visible
                    edit.inputType = if (visible) {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    } else {
                        InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                    }
                    setImageResource(if (visible) R.drawable.ic_auth_eye_off else R.drawable.ic_auth_eye)
                    contentDescription = if (visible) "مخفی کردن رمز عبور" else "نمایش رمز عبور"
                    edit.setSelection(selection.coerceAtMost(edit.text.length))
                }
            }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(6) })
        }

        bindInputFocus(box, edit)
        parent.addView(box, LinearLayout.LayoutParams(-1, dp(62)).apply { bottomMargin = dp(15) })
        return edit
    }

    private fun submitLogin(identity: EditText, password: EditText, button: TextView) {
        if (!AccountSession.loginEnabled(this)) {
            showStatus("ورود از پنل مدیریت موقتاً غیرفعال شده است", true)
            return
        }
        val identityValue = identity.text.toString().trim()
        val passwordValue = password.text.toString()
        if (identityValue.isBlank() || passwordValue.isBlank()) {
            showStatus("نام کاربری یا ایمیل و رمز عبور را کامل وارد کنید", true)
            return
        }
        setBusy(button, true)
        AccountApi.login(this, identityValue, passwordValue) { result ->
            if (!result.success) {
                setBusy(button, false)
                showStatus(result.message.ifBlank { "ورود انجام نشد؛ اطلاعات واردشده را بررسی کنید" }, true)
                return@login
            }
            finishAuth(button, "ورود موفق بود")
        }
    }

    private fun submitRegister(
        username: EditText,
        email: EditText,
        password: EditText,
        confirm: EditText,
        button: TextView
    ) {
        if (!AccountSession.registrationEnabled(this)) {
            showStatus("ثبت‌نام از پنل مدیریت غیرفعال شده است", true)
            return
        }
        val usernameValue = username.text.toString().trim()
        val emailValue = email.text.toString().trim()
        val passwordValue = password.text.toString()
        val confirmValue = confirm.text.toString()
        if (usernameValue.length < 3) {
            showStatus("نام کاربری باید حداقل ۳ کاراکتر باشد", true)
            return
        }
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(emailValue).matches()) {
            showStatus("ایمیل معتبر وارد کنید؛ نمونه: name@example.com", true)
            return
        }
        if (passwordValue.length < 8) {
            showStatus("رمز عبور باید حداقل ۸ کاراکتر باشد", true)
            return
        }
        if (passwordValue != confirmValue) {
            showStatus("رمز عبور و تکرار آن یکسان نیست", true)
            return
        }
        setBusy(button, true)
        AccountApi.register(this, usernameValue, emailValue, passwordValue, confirmValue) { result ->
            if (!result.success) {
                setBusy(button, false)
                showStatus(result.message.ifBlank { "ثبت‌نام انجام نشد؛ اطلاعات را دوباره بررسی کنید" }, true)
                return@register
            }
            finishAuth(button, "ثبت‌نام با موفقیت انجام شد")
        }
    }

    private fun showStatus(message: String, error: Boolean = false) {
        if (!::statusText.isInitialized) {
            toast(message)
            return
        }
        val accent = if (error) Color.rgb(238, 76, 91) else UiPreferences.accentColor(this)
        statusText.text = message
        statusText.setTextColor(if (error) Color.rgb(255, 214, 218) else Color.WHITE)
        statusText.background = rounded(
            Color.argb(if (error) 82 else 58, Color.red(accent), Color.green(accent), Color.blue(accent)),
            14,
            Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent))
        )
        statusText.visibility = View.VISIBLE
        statusText.alpha = 0f
        statusText.translationY = -dp(6).toFloat()
        statusText.animate().alpha(1f).translationY(0f).setDuration(150L).start()
    }

    private fun finishAuth(button: TextView, message: String) {
        button.text = "در حال همگام‌سازی واچ‌لیست..."
        showStatus("ورود انجام شد؛ در حال همگام‌سازی اطلاعات حساب...", false)
        AccountApi.syncWatchlist(this, force = true) {
            toast(message)
            setResult(RESULT_OK)
            finish()
        }
    }

    private fun setBusy(button: TextView, value: Boolean) {
        busy = value
        button.isEnabled = !value
        button.alpha = if (value) 0.72f else 1f
        button.text = if (value) "لطفاً صبر کنید..." else if (registerMode) "ثبت‌نام" else "ورود"
    }

    private fun loadBackground(url: String) {
        if (url.isBlank()) return
        backgroundImage.tag = url
        Thread {
            var connection: HttpURLConnection? = null
            try {
                connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 9000
                connection.readTimeout = 12000
                connection.instanceFollowRedirects = true
                connection.setRequestProperty("User-Agent", "Bankmovie Android")
                val options = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.RGB_565 }
                val bitmap = BitmapFactory.decodeStream(connection.inputStream, null, options) ?: return@Thread
                runOnUiThread {
                    if (backgroundImage.tag == url && !isFinishing) {
                        backgroundImage.animate().cancel()
                        backgroundImage.alpha = 0.18f
                        backgroundImage.setImageBitmap(bitmap)
                        backgroundImage.animate().alpha(0.42f).setDuration(240L).start()
                    }
                }
            } catch (_: Throwable) {
            } finally {
                runCatching { connection?.disconnect() }
            }
        }.start()
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
            resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun focusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val accent = UiPreferences.palette(this).primary
        val outer = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.argb(38, Color.red(accent), Color.green(accent), Color.blue(accent)))
            setStroke(dp(2), Color.argb(245, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
        val inner = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(155, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclamp(view: View) {
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun applyFocusHalo(view: View, radius: Int, scale: Float) {
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        val originalElevation = view.elevation
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        view.setOnFocusChangeListener { target, focused ->
            target.animate().cancel()
            if (focused) {
                unclamp(target)
                target.bringToFront()
            }
            target.foreground = if (focused) focusDrawable(radius) else originalForeground
            target.elevation = if (focused) dp(20).toFloat() else originalElevation
            target.translationZ = if (focused) dp(7).toFloat() else 0f
            target.animate()
                .scaleX(if (focused) scale else 1f)
                .scaleY(if (focused) scale else 1f)
                .setDuration(if (focused) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun bindInputFocus(box: View, edit: EditText) {
        val originalForeground = box.foreground
        val originalElevation = box.elevation
        edit.setOnFocusChangeListener { _, focused ->
            box.animate().cancel()
            if (focused) {
                unclamp(box)
                scroll.postDelayed({ scrollToView(edit) }, 90L)
            }
            box.foreground = if (focused) focusDrawable(17) else originalForeground
            box.elevation = if (focused) dp(18).toFloat() else originalElevation
            box.translationZ = if (focused) dp(6).toFloat() else 0f
            box.animate()
                .scaleX(if (focused) 1.018f else 1f)
                .scaleY(if (focused) 1.018f else 1f)
                .setDuration(125L)
                .start()
        }
    }

    private fun bindTvKeyboard(edit: EditText) {
        if (!isTvLike()) return
        edit.setOnClickListener { showTvKeyboard(edit) }
        edit.setOnKeyListener { _, keyCode, event ->
            val okKey = keyCode == android.view.KeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_ENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER ||
                keyCode == android.view.KeyEvent.KEYCODE_BUTTON_A
            if (!okKey) return@setOnKeyListener false
            if (event.action == android.view.KeyEvent.ACTION_UP) showTvKeyboard(edit)
            true
        }
    }

    private fun showTvKeyboard(edit: EditText) {
        if (!isTvLike()) return
        edit.requestFocus()
        edit.setSelection(edit.text.length)
        edit.postDelayed({
            val input = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            input?.restartInput(edit)
            val shown = input?.showSoftInput(edit, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT) == true
            if (!shown) input?.showSoftInput(edit, android.view.inputmethod.InputMethodManager.SHOW_FORCED)
        }, 80L)
    }

    private fun scrollToView(view: View) {
        if (!::scroll.isInitialized || !::page.isInitialized) return
        val rect = Rect()
        view.getDrawingRect(rect)
        page.offsetDescendantRectToMyCoords(view, rect)
        val target = (rect.bottom - scroll.height + dp(190)).coerceAtLeast(0)
        scroll.smoothScrollTo(0, target)
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(fill)
            cornerRadius = dp(radius).toFloat()
            if (Color.alpha(stroke) > 0) setStroke(dp(1), stroke)
        }
    }

    private fun toast(message: String) {
        val kind = if (message.contains("انجام شد") || message.contains("موفق")) BmNotice.Kind.SUCCESS else BmNotice.Kind.INFO
        BmNotice.show(this, message, kind, 3000L)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
