#!/usr/bin/env bash
set -euo pipefail
need(){ local f="$1" p="$2"; grep -Fq "$p" "$f" || { echo "VERIFY_V7471_5_MISSING: $f :: $p"; exit 1; }; }
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
DL='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
need "$PLAYER" 'CC is the single subtitle/audio entry'
need "$PLAYER" 'playerMetaChip("CC", R.drawable.ic_player_cc)'
if grep -Fq 'playerMetaChip("زیرنویس"' "$PLAYER"; then echo VERIFY_V7471_5_DUPLICATE_SUBTITLE_CHIP; exit 1; fi
need "$MAIN" 'private var tvSideNavScroll: BankmovieSmoothScrollView? = null'
need "$MAIN" 'private fun ensureTvSideNavItemVisible(view: View)'
need "$MAIN" 'private fun setBottomNavVisibility(visibility: Int)'
need "$MAIN" 'private fun revealWeeklySurface(registration: HomeTvWeeklyFocusRegistration)'
need "$MAIN" 'private fun handleV74715BoxOfficeBootstrap'
need "$MAIN" 'profile hero uses one design token set on mobile and TV'
need "$DL" 'tag = "bm_download_card:$id"'
need "$DL" 'queue_order'
need "$DL" 'downloadsHeaderFocusViews()'
need "$WF" 'verify_v7471_5_player_tv_focus_unified_ui.sh'
bash verify_v7471_source_zip.sh "$WF"
echo VERIFY_V7471_5_PLAYER_TV_FOCUS_UNIFIED_UI_OK
