#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYCHK'
from pathlib import Path
import struct, zlib
root=Path('app/src/main/res/drawable-nodpi')
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()

def rgba_pixels(path, points):
    data=path.read_bytes()
    assert data[:8] == b'\x89PNG\r\n\x1a\n', path
    offset=8; packed=[]; width=height=color_type=0
    while offset < len(data):
        size=struct.unpack_from('>I',data,offset)[0]
        kind=data[offset+4:offset+8]
        chunk=data[offset+8:offset+8+size]
        offset+=size+12
        if kind == b'IHDR':
            width,height,depth,color_type,_,_,_=struct.unpack('>IIBBBBB',chunk)
            assert (width,height,depth,color_type)==(192,192,8,6),path
        elif kind == b'IDAT':packed.append(chunk)
        elif kind == b'IEND':break
    stride=width*4; raw=zlib.decompress(b''.join(packed))
    last=bytearray(stride); offset=0; found={}
    for y in range(height):
        mode=raw[offset];offset+=1
        row=bytearray(raw[offset:offset+stride]);offset+=stride
        for j in range(stride):
            a=row[j-4] if j>=4 else 0
            b=last[j]
            c=last[j-4] if j>=4 else 0
            if mode==1: row[j]=(row[j]+a)&255
            elif mode==2:row[j]=(row[j]+b)&255
            elif mode==3:row[j]=(row[j]+(a+b)//2)&255
            elif mode==4:
                p=a+b-c
                pa,pb,pc=abs(p-a),abs(p-b),abs(p-c)
                row[j]=(row[j]+(a if pa<=pb and pa<=pc else b if pb<=pc else c))&255
            else: assert mode==0
        for x,py in points:
            if py==y:found[(x,py)]=tuple(row[4*x:4*x+4])
        last=row
    return found

for name in ('bm_site_neon_anime','bm_site_neon_collections','bm_site_neon_china','bm_site_neon_subtitle'):
    pixels=rgba_pixels(root/(name+'.png'),[(0,0),(96,96)])
    assert pixels[(0,0)][3] == 0, 'not round: '+name
    assert pixels[(96,96)][3] > 200, 'empty icon: '+name
    assert f'R.drawable.{name}' in s, 'icon unused: '+name
h=s[s.index('private fun sectionHeader('):s.index('private fun legacyTvSectionHeader(')]
for keyword in ('titleKey.contains("چین")','titleKey.contains("زیرنویس")', 'circularIcon', 'clipToOutline = true'):
    assert keyword in h, 'home icon issue: '+keyword
assert 'if (key == "mini_series") return false' in s
assert '"mini_series" -> addRail' not in s
assert 'GenreCategory("mini_series"' not in s
assert 'AdvancedOption("مینی سریال"' not in s
assert 'loadTopCroppedDetailPoster' in s and 'setScale(scale, scale)' in s
assert 'if (forcePosterHero) dp(308)' in s
assert 'clipChildren = true' in s
for file in ('server-required/app_config.php','server-required/bm_admin.php'):
    assert "'subtitled_series','mini_series'" not in Path(file).read_text()
print('VERIFY_V24_CIRCULAR_HOME_PORTRAIT_CROP_V7_OK')
PYCHK
