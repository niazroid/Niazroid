#!/usr/bin/env bash
# Shared source/Gradle verification for historical V7.47.1 regression scripts.
# IMPORTANT: Do not pin the ZIP basename here. CI hotfixes can rename the ZIP
# without changing the Android app or invalidating old feature regressions.
set -euo pipefail

workflow="${1:-.github/workflows/build-bankmovie.yml}"
gradle_file="${2:-app/build.gradle}"

if [[ ! -s "$workflow" || ! -s "$gradle_file" ]]; then
  echo "VERIFY_SOURCE_ZIP_FILES_MISSING: workflow=$workflow gradle=$gradle_file" >&2
  exit 1
fi

# A single declarative source artifact and a build-verified Android version.
mapfile -t source_decls < <(sed -nE 's/^[[:space:]]*SOURCE_ZIP:[[:space:]]*([^[:space:]#]+)[[:space:]]*(#.*)?$/\1/p' "$workflow")
if [[ ${#source_decls[@]} -ne 1 ]]; then
  echo "VERIFY_SOURCE_ZIP_DECLARATION_INVALID: expected one SOURCE_ZIP, found ${#source_decls[@]}" >&2
  exit 1
fi

source_zip="${source_decls[0]}"
if [[ ! "$source_zip" =~ ^BankMovie_Android_FULLSOURCE_V([0-9]+)\.([0-9]+)_[A-Za-z0-9_.-]+\.zip$ ]]; then
  echo "VERIFY_SOURCE_ZIP_NAME_INVALID: $source_zip" >&2
  exit 1
fi
source_version="${BASH_REMATCH[1]}.${BASH_REMATCH[2]}"

mapfile -t version_names < <(sed -nE 's/^[[:space:]]*versionName[[:space:]]+"([^"]+)".*/\1/p' "$gradle_file")
if [[ ${#version_names[@]} -ne 1 || "${version_names[0]}" != "$source_version" ]]; then
  echo "VERIFY_SOURCE_ZIP_VERSION_MISMATCH: source=${source_version} Android=${version_names[0]:-missing}" >&2
  exit 1
fi

if ! grep -Fq 'source_zip="$workspace/$SOURCE_ZIP"' "$workflow"; then
  echo 'VERIFY_SOURCE_ZIP_WORKFLOW_SELECTION_MISSING' >&2
  exit 1
fi

echo "VERIFY_SOURCE_ZIP_VERSION_OK: $source_zip (Android $source_version)"
