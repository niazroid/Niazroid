# BankMovie Desktop 1.1.14

- Back cache: صفحه قبلی با DOM واقعی، اسکرول، نتایج جستجو و ورودی‌ها بدون درخواست دوباره به سرور برمی‌گردد.
- API memory cache برای boot/section/search/detail/collections/collection/actor.
- ورود و ثبت‌نام: ورودی‌ها قابل تایپ، کد امنیتی ۴ رقمی از auth_challenge سایت/اپ، Refresh و fallback امن رابط.
- حذف «جستجوی مشابه» از اسلایدر.
- حذف ظاهر زرد دکمه‌ها و اتصال Accent به تم انتخابی کاربر؛ IMDb زرد استاندارد باقی می‌ماند.
- تم سفید: Season/Episode/Source و دکمه‌های پخش/دانلود کاملاً روشن و یک‌دست.
- Installer: هدر، سایدبار و رنگ‌های MUI مشکی با لوگوی BankMovie.

- NSIS hotfix: رفع خطای duplicate MUI_BGCOLOR در اینستالر مشکی.
