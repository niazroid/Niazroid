#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
gradle='app/build.gradle'
manifest='app/src/main/AndroidManifest.xml'
proguard='app/proguard-rules.pro'

need() { grep -Fq -- "$1" "$2" || { echo "Missing V7.20 marker: $1 in $2" >&2; exit 1; }; }

need 'V7.20 MAIN — in-memory snapshot for Advanced Search result pages.' "$main"
need 'rememberCurrentScreen { showAdvancedSearchResults(state.copy(), restoreSnapshot = true) }' "$main"
need 'advancedSearchResultSnapshots' "$main"
need 'if (restoredSnapshot == null || grid.childCount == 0)' "$main"
need 'loadPage(1)' "$main"

need "implementation 'androidx.fragment:fragment:1.8.9'" "$gradle"
need "implementation 'androidx.mediarouter:mediarouter:1.8.1'" "$gradle"
need "implementation 'com.google.android.gms:play-services-cast-framework:22.1.0'" "$gradle"
need 'class PlayerActivity : FragmentActivity()' "$player"
need 'private lateinit var castButton: MediaRouteButton' "$player"
need 'CastContext.getSharedInstance(applicationContext, ContextCompat.getMainExecutor(this))' "$player"
need 'context.mergedSelector?.let { castSelector ->' "$player"
need 'selectorBuilder.addSelector(castSelector)' "$player"
need '.addSelector(dlnaSelector)' "$player"
need 'RemoteKind.CHROMECAST' "$player"
need 'RemoteKind.DLNA' "$player"
need 'class BankmovieCastOptionsProvider : OptionsProvider' app/src/main/java/ir/bankmoviee/app/BankmovieCastOptionsProvider.kt
need 'class DlnaRouteProvider(context: Context) : MediaRouteProvider(context)' app/src/main/java/ir/bankmoviee/app/DlnaRouteProvider.kt
need 'M-SEARCH * HTTP/1.1' app/src/main/java/ir/bankmoviee/app/DlnaDiscovery.kt
need 'SetAVTransportURI' app/src/main/java/ir/bankmoviee/app/DlnaController.kt
need 'GetPositionInfo' app/src/main/java/ir/bankmoviee/app/DlnaController.kt
need 'execute<Unit>({' app/src/main/java/ir/bankmoviee/app/DlnaController.kt
need 'result: Result<Unit>' app/src/main/java/ir/bankmoviee/app/DlnaController.kt
need 'com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME' "$manifest"
need 'android.permission.CHANGE_WIFI_MULTICAST_STATE' "$manifest"
need '-keep class ir.bankmoviee.app.BankmovieCastOptionsProvider' "$proguard"
need 'mainUpdatePatch=V7.20 ADVANCED-SEARCH RETURN STATE + REAL CAST/RENDERER' BANKMOVIE_BUILD_SOURCE_2_3.txt
need 'castCompileHotfix=V7.20.1 KOTLIN RESULT LAMBDA + NULL-SAFE CAST SELECTOR' BANKMOVIE_BUILD_SOURCE_2_3.txt

if grep -Fq 'android.permission.NEARBY_WIFI_DEVICES' "$manifest"; then
  echo 'NEARBY_WIFI_DEVICES must not be used as a fake local-network permission for SSDP.' >&2
  exit 1
fi

if grep -Fq '.addSelector(context.mergedSelector)' "$player"; then
  echo 'Nullable CastContext.mergedSelector must not be passed directly to addSelector().' >&2
  exit 1
fi

if grep -Fq '} { result ->' app/src/main/java/ir/bankmoviee/app/DlnaController.kt; then
  echo 'Invalid two trailing-lambda execute() call is still present in DlnaController.' >&2
  exit 1
fi

python3 - <<'PY'
import json
import re
import xml.etree.ElementTree as ET
from pathlib import Path

for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)
json.load(open('server-required/bankmovie_remote_config.json.sample', encoding='utf-8'))

# Lightweight lexer/balance check for edited Kotlin files. Gradle CI remains the
# authoritative compiler, but this catches truncated strings/braces before upload.
paths = [
    Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt'),
    Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'),
    Path('app/src/main/java/ir/bankmoviee/app/BankmovieCastOptionsProvider.kt'),
    Path('app/src/main/java/ir/bankmoviee/app/DlnaDiscovery.kt'),
    Path('app/src/main/java/ir/bankmoviee/app/DlnaRouteProvider.kt'),
    Path('app/src/main/java/ir/bankmoviee/app/DlnaController.kt'),
]

def scrub(src: str) -> str:
    out=[]; i=0; n=len(src); state='code'
    while i<n:
        if state=='code':
            if src.startswith('//', i): state='line'; out.extend('  '); i+=2; continue
            if src.startswith('/*', i): state='block'; out.extend('  '); i+=2; continue
            if src.startswith('"""', i): state='triple'; out.extend('   '); i+=3; continue
            if src[i]=='"': state='string'; out.append(' '); i+=1; continue
            if src[i]=="'": state='char'; out.append(' '); i+=1; continue
            out.append(src[i]); i+=1; continue
        if state=='line':
            if src[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i+=1; continue
        if state=='block':
            if src.startswith('*/', i): state='code'; out.extend('  '); i+=2
            else: out.append('\n' if src[i]=='\n' else ' '); i+=1
            continue
        if state=='triple':
            if src.startswith('"""', i): state='code'; out.extend('   '); i+=3
            else: out.append('\n' if src[i]=='\n' else ' '); i+=1
            continue
        if state in ('string','char'):
            quote='"' if state=='string' else "'"
            if src[i]=='\\':
                out.append(' '); i+=1
                if i<n: out.append('\n' if src[i]=='\n' else ' '); i+=1
            elif src[i]==quote:
                state='code'; out.append(' '); i+=1
            else:
                out.append('\n' if src[i]=='\n' else ' '); i+=1
    if state not in ('code','line'):
        raise SystemExit(f'unterminated Kotlin lexical state: {state}')
    return ''.join(out)

pairs={')':'(',']':'[','}':'{'}
for p in paths:
    stack=[]
    for ch in scrub(p.read_text(encoding='utf-8')):
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop()!=pairs[ch]:
                raise SystemExit(f'unbalanced Kotlin delimiters in {p}')
    if stack: raise SystemExit(f'unbalanced Kotlin delimiters in {p}: {stack[-10:]}')

main=paths[0].read_text(encoding='utf-8')
start=main.index('private fun showAdvancedSearchResults')
end=main.index('\n    private fun showSearch(', start)
fn=main[start:end]
assert 'restoreSnapshot = true' in fn
assert 'restoredSnapshot == null || grid.childCount == 0' in fn
assert 'advancedSearchResultSnapshots[snapshotKey]' in fn
print('V720_STATIC_STRUCTURE_OK')
PY

echo V720_MAIN_UPDATE_OK
