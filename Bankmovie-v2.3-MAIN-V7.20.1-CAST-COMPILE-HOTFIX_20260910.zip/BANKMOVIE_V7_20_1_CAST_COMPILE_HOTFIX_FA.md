# BankMovie V7.20.1 — Cast compile hotfix

این hotfix فقط خطاهای compile گزارش‌شده در V7.20 را اصلاح می‌کند و منطق Search State / Cast / DLNA را تغییر نمی‌دهد.

- `DlnaController.load(...)`: فراخوانی generic `execute` از دو trailing-lambda نامعتبر به `execute<Unit>({ ... }) { ... }` تبدیل شد و `Result<Unit>` صریح شد.
- `PlayerActivity.initCastRenderer()`: `CastContext.mergedSelector` قبل از افزودن به `MediaRouteSelector.Builder` null-safe شده است.
- verifier جدید `verify_v7201_cast_compile_hotfix.sh` از برگشت این دو الگوی compile-error جلوگیری می‌کند.
