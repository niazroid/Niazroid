#!/usr/bin/env python3
"""Static guard for public in-memory navigation caching and private-screen isolation."""
from pathlib import Path
import re
src = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

def body(method):
    token=f'    private fun {method}('
    a=src.index(token)
    b=src.find('    private fun ', a+len(token))
    return src[a:b if b >= 0 else len(src)]

assert 'private val publicPageSnapshots = linkedMapOf<String, RetainedNavigationScreen>()' in src
assert 'private fun publicPageContext()' in src
assert 'private fun rememberVisiblePublicPage()' in src
assert 'private fun restorePublicPage(key: String)' in src
assert 'private fun invalidatePublicPages()' in src
assert 'renderedPublicPageContext != publicPageContext()' in src
assert 'val maxEntries = if (lowEndDevice) 2 else publicPageCacheMaxEntries' in src
assert 'if (currentScreen != "home") rememberVisiblePublicPage()' in body('showHome')
assert 'if (restorePublicPage("discover")) return' in body('showDiscover')
assert 'if (restorePublicPage("collections")) return' in body('showCollections')
assert 'if (restorePublicPage("categories")) return' in body('showCategories')
assert 'if (restorePublicPage("boxoffice")) return' in body('showBoxOffice')
assert 'if (restorePublicPage("boxoffice")) return' in body('showBoxOfficeMobileV736')
assert 'restorePublicPage(publicSearchKey)' in body('showSearch')
assert 'markPublicPage("search")' in body('showSearch')
assert 'restorePublicPage(genreKey)' in body('showGenreDirectory')
assert 'restorePublicPage(collectionKey)' in body('showCollectionItems')
assert 'restorePublicPage(genreItemsKey)' in body('showGenreItems')
assert 'val isPublicList' in body('showList')
assert 'renderedPublicPageKey = pendingPublicPageKey' in body('clear')
assert 'rememberVisiblePublicPage()' in body('clear')
for private in ('showProfile', 'showProfileMobileV736', 'showSettingsPage',
                'showNotificationCenter', 'showCleanupCenter', 'showVipPlansDialog'):
    assert 'markPublicPage(' not in body(private), private
    assert 'restorePublicPage(' not in body(private), private
assert 'if (startupSplashView != null) dismissStartupSplashAfterHomeFrame()' in src
assert 'uiHandler.postDelayed({ renderNext() }, 20L)' in src
assert 'if (startupHomeContentReady' not in body('showHome').split('fun finishHomeLayout()')[0]
assert 'discoverWebView?.destroy()' in body('clear')
print('VERIFY_PUBLIC_SESSION_PAGES_CACHE_OK')
