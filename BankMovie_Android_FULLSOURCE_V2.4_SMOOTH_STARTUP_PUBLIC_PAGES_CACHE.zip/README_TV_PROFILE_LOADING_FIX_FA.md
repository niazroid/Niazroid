# BankMovie Android 2.4 — پچ نهایی TV / Startup / Explore / Archive 5 / Collections

این پچ فقط سورس اندروید را تغییر می‌دهد؛ هیچ فایل سایت، API، ریموت، دامنه محتوا، دیتابیس یا تنظیمات سرور تغییر نکرده است.

## تغییرات

- **ورود TV:** اسپلاش روی Home ساخته‌شده باقی می‌ماند و بعد از اولین فریم واقعی Home با fade کنار می‌رود؛ تعویض صفحه دیگر یک فریم سفید/خالی نشان نمی‌دهد. پس‌زمینه پنجره هم با تم اپ هماهنگ است.
- **چی ببینیم / Explore:** متن لودینگ عرض مشخص دارد و حداکثر در دو خط کامل نمایش داده می‌شود؛ کادر در TV و موبایل از لبه‌ها بریده نمی‌شود.
- **آرشیو ۵:** بک‌گراند جعلی از فیلدهای cover/backdrop نمایش داده نمی‌شود؛ مثل آرشیوهای ۲/۳/۴ فقط wash رنگی سبک از پوستر ساخته می‌شود.
- **کالکشن‌های Home در TV:** کارت‌ها landscape و عریض‌تر شده‌اند تا نسبت‌شان به کالکشن‌های Home موبایل نزدیک شود. گرید فشرده صفحه فهرست کالکشن دست‌نخورده مانده است.
- **فوکوس پروفایل TV:** ورود از هدر به «مدیریت اشتراک»، سپس «دانلودها»، «ادامه تماشا» و «صد بازدید آخر»؛ فوکوس عمودی در صورت آماده‌نبودن لحظه‌ای کارت، چند بار تلاش می‌کند و به «مشاهده همه» نمی‌پرد.
- **لودینگ‌ها:** اسکلت‌های سبک قبلی حفظ شده‌اند. رفتار لودینگ سرچ و سرچ پیشرفته تغییر نکرده است.

## فایل‌ها

- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/res/values/styles.xml`
- `verify_v24_tv_profile_skeleton_spinner_fix.py`
- `verify_v24_tv_startup_explore_archive5_collections.py`
- `.github/workflows/build-bankmovie.yml`

## اجرای بیلد

1. فایل `BankMovie_Android_FULLSOURCE_V2.4_TV_STARTUP_EXPLORE_ARCHIVE5_COLLECTIONS_FIX.zip` را در ریشه مخزن GitHub قرار بده.
2. فایل `build-bankmovie-v2.4-TV-STARTUP-EXPLORE-ARCHIVE5-COLLECTIONS-FIX.yml` را در `.github/workflows/` با نام `build-bankmovie.yml` قرار بده؛ Workflow قدیمی با `SOURCE_ZIP` متفاوت را هم‌زمان فعال نگذار.
3. از GitHub Actions گزینه **Run workflow** را اجرا کن. این Workflow سورس ZIP مشخص‌شده را باز می‌کند، تست‌های رگرسیون را اجرا می‌کند و APKها را به‌صورت Artifact منتشر می‌کند.
4. برای آپدیت روی دستگاه، همان `applicationId` و کلید امضای قبلی و `versionCode` افزایشی باید حفظ شوند. اپ را حذف نکن.

## وضعیت تست

تست‌های ساختاری و رگرسیون داخل پروژه برای مسیرهای تغییرکرده قرار دارند. در این محیط Android SDK/Gradle build اجرا نشده و تست واقعی روی تلویزیون انجام نشده است؛ تأیید نهایی APK و DPAD باید در GitHub Actions و سپس روی TV انجام شود.

**این ZIP مخصوص سورس اندروید است؛ روی `bankmovie.top` یا `bankmoviez.top` نصب نمی‌شود.**
