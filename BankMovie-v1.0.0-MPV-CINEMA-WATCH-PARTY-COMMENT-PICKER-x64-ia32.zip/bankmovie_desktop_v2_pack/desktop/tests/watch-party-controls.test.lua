-- Isolated Lua control logic test; not a real MPV rendering or Windows test.
local bindings,events,commands={}, {}, {}
local props={pause=true,duration=3600,['time-pos']=60,volume=50,speed=1,['media-title']='Movie {unsafe}', aid='1',sid='1',['track-list']={{id=1,type='sub',lang='fas',codec='subrip',title='Film2Media - Namava'},{id=2,type='sub',lang='fas',codec='ass',title='Film2Media - Filimo'},{id=1,type='audio',lang='eng',codec='aac',title='Original'},{id=2,type='audio',lang='fas',codec='aac',title='Persian dub'}}}
local time,xx,yy,ow,oh=0,0,0,1280,720
local ov={update=function()end};local timer;local timers={}
local mp={create_osd_overlay=function()return ov end,get_time=function()return time end,get_osd_size=function()return ow,oh,ow/oh end,get_mouse_pos=function()return xx,yy end,get_property=function(n,d)return props[n] or d end,get_property_number=function(n,d)return props[n] or d end,get_property_bool=function(n,d)if props[n]==nil then return d end return props[n] end,get_property_native=function(n,d)return props[n] or d end,set_property=function(n,v)props[n]=v;return true end,set_property_bool=function(n,v)props[n]=v;return true end,set_property_number=function(n,v)props[n]=v;return true end,commandv=function(...)local a={...};commands[#commands+1]=a;if a[1]=='cycle' then props[a[2]]=not props[a[2]] end;return true end,add_forced_key_binding=function(k,n,f)bindings[k]=f end,register_event=function(k,f)events[k]=f end,observe_property=function()end,add_periodic_timer=function(t,f)timers[t]=f;timer=f end,osd_message=function()end}
local inputRequest
local filePath=os.tmpname();os.remove(filePath)
local prefsData, fileData
local originalOpen,originalGetenv=io.open,os.getenv
os.getenv=function(k)if k=='BM_PARTY_DIR' then return 'party-test' end;if k=='LOCALAPPDATA' then return 'test-local-appdata' end;return originalGetenv(k)end
local snapshot={serial=1,role='guest',connected=true,source='https://example.test/video.mkv',clock={position=120,paused=false,rate=1.25,secondsLeft=100},chatEnabled=true,members={{id=1,name='Host',role='host'}},messages={{id=1,name='Host',text='Hello'}},themes={}}
local writes={};local lastPartyCommand,lastAction
io.open=function(p,mode) if p=='party-test/state.json' then return {read=function()return 'party-state' end,close=function()end} elseif p:find('party-test/',1,true)==1 then return {write=function(_,v)writes[p]=v end,close=function()end} end;if p=='test-local-appdata/BankMovie-player-settings.json' then
  if mode=='wb' then return {write=function(_,v)fileData=v end,close=function()end} end
  if fileData then return {read=function()return fileData end,close=function()end} end
  return nil
end;return originalOpen(p,mode)end
package.loaded['mp.utils']={format_json=function(t)if t.kind or t.at then if t.kind then lastPartyCommand=t.kind;lastAction=t end;return 'party-output' end;prefsData={};for k,v in pairs(t)do prefsData[k]=v end;return 'mock-json' end,parse_json=function(raw)if raw=="party-state" then return snapshot end;return prefsData end,file_info=function(p)if p=='C:\\movie.srt' then return {is_file=true} elseif p=='C:\\' then return {is_dir=true} end end,readdir=function(p,t) if p=='C:\\' and t=='files' then return {'movie.srt','ignore.exe'} end;return {} end}
package.loaded['mp.input']={get=function(o)inputRequest=o end}
mp.remove_key_binding=function(n) if n:find('bm%-chat%-') then local k=n:sub(9);if k=='text' then k='ANY_UNICODE' end;bindings[k]=nil elseif n:find('bm%-key%-') then bindings[n:sub(8)]=nil end end
package.loaded.mp=mp
mp.set_property_native=function(n,v)props[n]=v;return true end

dofile('player/cinema.lua')
assert(ov.data:find('تماشای دونفره',1,true));xx=ow-70;yy=35;bindings.MBTN_LEFT({event='press'});assert(ov.data:find('پیامت رو بنویس',1,true),'chat drawer rendered inside MPV');assert(not lastPartyCommand,'no external panel command');props.fullscreen=true;xx=ow-160;yy=oh-117;bindings.MBTN_LEFT({event='press'});assert(bindings.ANY_UNICODE,'native composer captures unicode');bindings.ANY_UNICODE({event='press',key_text='سلام'});bindings.SPACE();bindings.ANY_UNICODE({event='press',key_text='دنیا'});assert(ov.data:find('سلام دنیا',1,true) or ov.data:find('سلام دنیا│',1,true),'Persian draft rendered');bindings.ENTER();assert(lastAction.kind=='message' and lastAction.text=='سلام دنیا' and lastAction.requestId,'same-window submit');assert(props.fullscreen==true,'chat never exits fullscreen');snapshot.serial=2;snapshot.ack={id=lastAction.requestId,ok=false,error='ارسال ناموفق'};time=.2;timers[0.7]();timers[0.08]();assert(ov.data:find('ارسال ناموفق',1,true),'failed send retained');local req=lastAction.requestId;bindings.ENTER();assert(lastAction.requestId==req,'retry stable id');snapshot.serial=3;snapshot.ack={id=req,ok=true};time=.4;timers[0.7]();timers[0.08]();bindings.ESC();bindings.ESC();assert(props.fullscreen==true,'escape closes composer then drawer, not fullscreen');assert(not ov.data:find('پیامت رو بنویس',1,true));snapshot.serial=4;snapshot.messages[2]={id=2,name='Host',text='new message'};time=.5;timers[0.7]();timers[0.08]();assert(ov.data:find('new message',1,true),'new message preview on video');events['file-loaded']();events['playback-restart']();time=1;timers[0.7]();assert(props.pause==false and props.speed==1.25);assert(commands[#commands][1]=='seek' and commands[#commands][2]>=120)
local n=#commands;bindings.SPACE();bindings.RIGHT();assert(#commands==n and props.pause==false,'guest cannot control transport')
assert(writes['party-test/sample.json']);snapshot.serial=5;snapshot.clock.paused=true;time=4;timers[0.7]();assert(props.pause==true)
snapshot.serial=6;snapshot.role='host';time=5;timers[0.7]();bindings.SPACE();assert(props.pause==false,'host can control')
snapshot.serial=7;snapshot.connected=false;time=6;timers[0.7]();assert(props.pause==true,'disconnected host pauses')
print('PASS: dedicated party overlay, guest sync, guest control guard, host controls, disconnect pause')
