package ir.bankmoviee.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.util.Locale

class DownloadsActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private var lastSnapshot = ""

    private val refresh = object : Runnable {
        override fun run() {
            val snapshot = InternalDownloadStore.all(this@DownloadsActivity).joinToString("|") {
                listOf(it.optString("id"), it.optString("status"), it.optLong("downloaded"), it.optLong("total"), it.optLong("speed")).joinToString(":")
            }
            if (snapshot != lastSnapshot) {
                lastSnapshot = snapshot
                render()
            }
            handler.postDelayed(this, 900L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = UiPreferences.palette(this).background
        window.navigationBarColor = UiPreferences.palette(this).background
        buildShell()
        render()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refresh)
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun buildShell() {
        val palette = UiPreferences.palette(this)
        root = FrameLayout(this).apply { setBackgroundColor(palette.background) }
        val scroll = ScrollView(this).apply {
            clipToPadding = false
            setPadding(0, 0, 0, dp(28))
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
    }

    private fun render() {
        val palette = UiPreferences.palette(this)
        content.removeAllViews()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(palette.panel, 24, palette.stroke)
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_back)
            setColorFilter(palette.text)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            isFocusable = true
            premiumFocus(this, 999)
            setOnClickListener { finish() }
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginStart = dp(10) })
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        titles.addView(TextView(this).apply {
            text = "دانلودهای من"
            setTextColor(palette.text)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        titles.addView(TextView(this).apply {
            text = "دانلودر اختصاصی بانک مووی • توقف و ادامه واقعی"
            setTextColor(palette.muted)
            textSize = 11.5f
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, 0)
        })
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f))
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val items = InternalDownloadStore.all(this)
        if (items.isEmpty()) {
            content.addView(LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(20), dp(42), dp(20), dp(42))
                background = rounded(palette.panel, 24, palette.stroke)
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(R.drawable.ic_download)
                    setColorFilter(palette.primary)
                }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(12) })
                addView(TextView(this@DownloadsActivity).apply {
                    text = "هنوز دانلودی نداری"
                    setTextColor(palette.text)
                    textSize = 16f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                })
                addView(TextView(this@DownloadsActivity).apply {
                    text = "از باکس دانلود هر فیلم یا قسمت، دانلودر داخلی را انتخاب کن."
                    setTextColor(palette.muted)
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setPadding(dp(12), dp(7), dp(12), 0)
                })
            }, LinearLayout.LayoutParams(-1, -2))
            return
        }

        val active = items.count { it.optString("status") in listOf(InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_QUEUED) }
        val completed = items.count { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED }
        content.addView(TextView(this).apply {
            text = "$active فعال  •  $completed کامل‌شده  •  ${items.size} کل"
            setTextColor(palette.muted)
            textSize = 12f
            gravity = Gravity.RIGHT
            setPadding(dp(8), 0, dp(8), dp(10))
        })

        items.forEach { item ->
            content.addView(downloadCard(item), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }

        if (completed > 0) {
            content.addView(TextView(this).apply {
                text = "پاک‌کردن سوابق دانلودهای کامل‌شده"
                setTextColor(Color.rgb(255, 105, 115))
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(Color.argb(45, 235, 35, 55), 18, Color.argb(120, 235, 35, 55))
                isFocusable = true
                premiumFocus(this, 18)
                setOnClickListener {
                    InternalDownloadStore.clearCompleted(this@DownloadsActivity)
                    lastSnapshot = ""
                    render()
                }
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(4) })
        }
    }

    private fun downloadCard(item: JSONObject): LinearLayout {
        val palette = UiPreferences.palette(this)
        val id = item.optString("id")
        val status = item.optString("status")
        val downloaded = item.optLong("downloaded", 0L)
        val total = item.optLong("total", 0L)
        val speed = item.optLong("speed", 0L)
        val percent = if (total > 0L) ((downloaded * 100L) / total).toInt().coerceIn(0, 100) else 0
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = rounded(palette.card, 22, palette.stroke)

            val top = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
            }
            val icon = FrameLayout(this@DownloadsActivity).apply {
                background = rounded(Color.argb(55, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)), 16, Color.argb(150, Color.red(palette.primary), Color.green(palette.primary), Color.blue(palette.primary)))
                addView(ImageView(this@DownloadsActivity).apply {
                    setImageResource(if (status == InternalDownloadStore.STATUS_COMPLETED) R.drawable.ic_seen_eye else R.drawable.ic_download)
                    setColorFilter(palette.primary)
                }, FrameLayout.LayoutParams(dp(25), dp(25), Gravity.CENTER))
            }
            top.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(11) })
            val info = LinearLayout(this@DownloadsActivity).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
            info.addView(TextView(this@DownloadsActivity).apply {
                text = item.optString("title").ifBlank { item.optString("file_name") }
                setTextColor(palette.text)
                textSize = 14.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = android.text.TextUtils.TruncateAt.END
            })
            info.addView(TextView(this@DownloadsActivity).apply {
                text = listOf(item.optString("quality"), item.optString("kind"), humanSize(total.takeIf { it > 0 } ?: downloaded)).filter { it.isNotBlank() }.joinToString(" • ")
                setTextColor(palette.muted)
                textSize = 11f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
            top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            addView(top)

            val progress = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                max = 100
                this.progress = percent
                isIndeterminate = total <= 0L && status == InternalDownloadStore.STATUS_DOWNLOADING
                progressTintList = android.content.res.ColorStateList.valueOf(palette.primary)
                progressBackgroundTintList = android.content.res.ColorStateList.valueOf(palette.panel2)
            }
            addView(progress, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(13) })

            val statusRow = LinearLayout(this@DownloadsActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setPadding(0, dp(8), 0, 0)
            }
            statusRow.addView(TextView(this@DownloadsActivity).apply {
                text = statusLabel(status, percent, speed)
                setTextColor(if (status == InternalDownloadStore.STATUS_FAILED) Color.rgb(255, 110, 120) else palette.muted)
                textSize = 11.5f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))

            when (status) {
                InternalDownloadStore.STATUS_DOWNLOADING, InternalDownloadStore.STATUS_QUEUED -> {
                    statusRow.addView(actionButton("توقف", false) { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_PAUSE, id) })
                    statusRow.addView(actionButton("لغو", true) { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, LinearLayout.LayoutParams(dp(74), dp(38)).apply { marginStart = dp(7) })
                }
                InternalDownloadStore.STATUS_PAUSED, InternalDownloadStore.STATUS_FAILED -> {
                    statusRow.addView(actionButton("ادامه", false) { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_RESUME, id) })
                    statusRow.addView(actionButton("حذف", true) { InternalDownloadService.command(this@DownloadsActivity, InternalDownloadService.ACTION_CANCEL, id) }, LinearLayout.LayoutParams(dp(74), dp(38)).apply { marginStart = dp(7) })
                }
                InternalDownloadStore.STATUS_COMPLETED -> {
                    statusRow.addView(actionButton("بازکردن", false) { openDownloaded(item) })
                    statusRow.addView(actionButton("حذف", true) { InternalDownloadStore.remove(this@DownloadsActivity, id, true); lastSnapshot = ""; render() }, LinearLayout.LayoutParams(dp(74), dp(38)).apply { marginStart = dp(7) })
                }
            }
            addView(statusRow)
            val error = item.optString("error")
            if (error.isNotBlank() && status == InternalDownloadStore.STATUS_FAILED) {
                addView(TextView(this@DownloadsActivity).apply {
                    text = error
                    setTextColor(Color.rgb(230, 130, 140))
                    textSize = 10.5f
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(7), 0, 0)
                })
            }
        }
    }

    private fun actionButton(label: String, danger: Boolean, click: () -> Unit): TextView = TextView(this).apply {
        val palette = UiPreferences.palette(this@DownloadsActivity)
        text = label
        setTextColor(if (danger) Color.rgb(255, 125, 135) else palette.onPrimary)
        textSize = 11.5f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = if (danger) rounded(Color.argb(45, 235, 35, 55), 14, Color.argb(120, 235, 35, 55)) else rounded(palette.primary, 14, palette.primary2)
        isFocusable = true
        premiumFocus(this, 14)
        setOnClickListener { click() }
        layoutParams = LinearLayout.LayoutParams(dp(74), dp(38))
    }

    private fun openDownloaded(item: JSONObject) {
        val file = File(item.optString("path"))
        if (!file.exists()) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val uri: Uri = FileProvider.getUriForFile(this, "$packageName.files", file)
            val ext = file.extension.lowercase(Locale.US)
            val mime = when (ext) {
                "mkv" -> "video/x-matroska"
                "mp3" -> "audio/mpeg"
                "mka" -> "audio/x-matroska"
                "srt" -> "application/x-subrip"
                else -> "video/*"
            }
            startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        } catch (_: Throwable) {
            Toast.makeText(this, "برنامه‌ای برای بازکردن فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun statusLabel(status: String, percent: Int, speed: Long): String = when (status) {
        InternalDownloadStore.STATUS_QUEUED -> "در صف دانلود"
        InternalDownloadStore.STATUS_DOWNLOADING -> "$percent٪  •  ${humanSize(speed)}/s"
        InternalDownloadStore.STATUS_PAUSED -> "متوقف شده • $percent٪"
        InternalDownloadStore.STATUS_COMPLETED -> "دانلود کامل شد"
        InternalDownloadStore.STATUS_FAILED -> "خطا در دانلود"
        else -> "لغو شده"
    }

    private fun humanSize(bytes: Long): String {
        if (bytes <= 0L) return ""
        val mb = bytes / 1048576.0
        return if (mb >= 1024.0) String.format(Locale.US, "%.2f GB", mb / 1024.0) else String.format(Locale.US, "%.1f MB", mb)
    }

    private fun premiumFocus(view: View, radius: Int = 16) {
        val normalElevation = view.elevation
        view.setOnFocusChangeListener { v, focused ->
            v.animate()
                .scaleX(if (focused) 1.055f else 1f)
                .scaleY(if (focused) 1.055f else 1f)
                .setDuration(120L)
                .start()
            v.elevation = if (focused) dp(18).toFloat() else normalElevation
            v.foreground = if (focused) rounded(Color.TRANSPARENT, radius, UiPreferences.palette(this).primary) else null
        }
    }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
