-keep class org.videolan.** { *; }
-dontwarn org.videolan.**

-keep class ir.bankmoviee.app.CastOptionsProvider { *; }
-keep class ir.bankmoviee.app.InternalDownloadService { *; }
-keep class ir.bankmoviee.app.DownloadsActivity { *; }
-dontwarn com.google.android.gms.cast.**
