package ir.bankmoviee.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.widget.TextView
import android.view.ViewGroup
import kotlin.math.cos
import kotlin.math.sin

/**
 * Compact BankMovie action button with an inline ten-spoke pulse loader.
 *
 * The loader starts from performClick(), so it keeps working even when callers
 * replace OnClickListener later (which the catalogue pagination screens do).
 * Existing async code already re-enables the button on completion; setEnabled(true)
 * therefore ends the animation automatically.
 */
class InlineSpinnerButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : TextView(context, attrs, defStyleAttr) {

    private val spinnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    /** Opt-in only for the Load More button; all other buttons remain unchanged. */
    var useUserLoadingStyle: Boolean = false
    private var loaderOverlay: BankmovieCustomLoaderView? = null
    private var overlayHost: ViewGroup? = null
    private var loading = false
    private var savedTextColor = Color.WHITE
    private var loadingStartedAt = 0L
    private val stopRunnable = Runnable { stopInlineLoading() }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    fun isInlineLoading(): Boolean = loading

    fun startInlineLoading() {
        if (loading || !isEnabled) return
        loading = true
        loadingStartedAt = android.os.SystemClock.uptimeMillis()
        savedTextColor = currentTextColor
        setTextColor(Color.TRANSPARENT)
        removeCallbacks(stopRunnable)
        // Safety net for navigation buttons whose destination replaces the screen
        // instead of explicitly re-enabling the source button.
        postDelayed(stopRunnable, 5000L)
        // The button itself keeps focus, size and click behavior. For a custom
        // loading style we paint only a compact non-focusable overlay.
        if (useUserLoadingStyle && LoadingStylePrefs.general(context) != "classic") {
            post { if (loading && isAttachedToWindow) attachCustomOverlay() }
        }
        postInvalidateOnAnimation()
    }

    fun stopInlineLoading() {
        detachCustomOverlay()
        if (!loading) return
        loading = false
        removeCallbacks(stopRunnable)
        setTextColor(savedTextColor)
        invalidate()
    }

    override fun setEnabled(enabled: Boolean) {
        if (enabled && loading) stopInlineLoading()
        super.setEnabled(enabled)
    }

    override fun performClick(): Boolean {
        if (loading) return true
        startInlineLoading()
        return super.performClick()
    }

    override fun onDetachedFromWindow() {
        detachCustomOverlay()
        removeCallbacks(stopRunnable)
        if (loading) {
            loading = false
            setTextColor(savedTextColor)
        }
        super.onDetachedFromWindow()
    }

    private fun attachCustomOverlay() {
        if (!loading || loaderOverlay != null) return
        val host = parent as? ViewGroup ?: return
        val chosen = LoadingStylePrefs.general(context)
        if (chosen == "classic") return
        try {
            val visualWidth = minOf(width, dp(160f).toInt()).coerceAtLeast(dp(40f).toInt())
            val visualHeight = height.coerceAtLeast(dp(36f).toInt())
            val visual = BankmovieCustomLoaderView(context, chosen, compact = true)
            visual.layoutParams = ViewGroup.LayoutParams(visualWidth, visualHeight)
            visual.measure(
                android.view.View.MeasureSpec.makeMeasureSpec(visualWidth, android.view.View.MeasureSpec.EXACTLY),
                android.view.View.MeasureSpec.makeMeasureSpec(visualHeight, android.view.View.MeasureSpec.EXACTLY)
            )
            visual.layout(0, 0, visualWidth, visualHeight)
            visual.x = left.toFloat() + (width - visualWidth) / 2f
            visual.y = top.toFloat() + (height - visualHeight) / 2f
            loaderOverlay = visual
            overlayHost = host
            host.overlay.add(visual)
        } catch (_: Exception) {
            // No WebView/overlay support? Preserve the old native inline spinner.
            detachCustomOverlay()
        }
    }

    private fun detachCustomOverlay() {
        val visual = loaderOverlay ?: return
        loaderOverlay = null
        try { overlayHost?.overlay?.remove(visual) } catch (_: Exception) { }
        overlayHost = null
        try { visual.dispose() } catch (_: Exception) { }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!loading || loaderOverlay != null) return

        val elapsed = (android.os.SystemClock.uptimeMillis() - loadingStartedAt) % 1000L
        val cx = width / 2f
        val cy = height / 2f
        val radius = dp(5.4f)
        val baseLen = dp(4.5f)
        spinnerPaint.strokeWidth = dp(1.9f)
        spinnerPaint.color = if (savedTextColor == Color.TRANSPARENT) Color.WHITE else savedTextColor

        for (i in 0 until 10) {
            val local = ((elapsed / 1000f) - (i * 0.1f) + 1f) % 1f
            // Mirrors the supplied Uiverse loader: a small outward pulse around
            // the middle of each spoke's delayed one-second cycle.
            val pulse = if (local in 0.38f..0.62f) {
                1f + (1f - kotlin.math.abs(local - 0.5f) / 0.12f).coerceIn(0f, 1f) * 0.5f
            } else 1f
            val angle = Math.toRadians((i * 36.0) - 90.0)
            val sx = cx + cos(angle).toFloat() * radius
            val sy = cy + sin(angle).toFloat() * radius
            val ex = cx + cos(angle).toFloat() * (radius + baseLen * pulse)
            val ey = cy + sin(angle).toFloat() * (radius + baseLen * pulse)
            spinnerPaint.alpha = (90 + 165 * (1f - local)).toInt().coerceIn(70, 255)
            canvas.drawLine(sx, sy, ex, ey, spinnerPaint)
        }
        postInvalidateOnAnimation()
    }
}
