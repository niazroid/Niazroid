package ir.bankmoviee.app

import android.content.Context
import android.graphics.Color
import android.view.View
import android.widget.FrameLayout
import android.webkit.WebView

/**
 * Purely local animation renderer for the opt-in Uiverse-inspired loading designs.
 * It never executes JavaScript, reads a remote URL, or changes navigation/TV focus.
 * The existing native loader is still the default and requires no WebView.
 */
class BankmovieCustomLoaderView(context: Context, initialStyle: String, private val compact: Boolean = false) : FrameLayout(context) {
    private val web = WebView(context).apply {
        setBackgroundColor(Color.TRANSPARENT)
        isFocusable = false
        isFocusableInTouchMode = false
        isClickable = false
        isLongClickable = false
        overScrollMode = View.OVER_SCROLL_NEVER
        isVerticalScrollBarEnabled = false
        isHorizontalScrollBarEnabled = false
        settings.javaScriptEnabled = false
        settings.domStorageEnabled = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.blockNetworkLoads = true
        settings.loadsImagesAutomatically = false
        settings.defaultTextEncodingName = "UTF-8"
        // Loading is decorative, including on D-pad devices.
        setOnTouchListener { _, _ -> true }
        importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
    }

    init {
        isFocusable = false
        isClickable = false
        addView(web, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        setStyle(initialStyle)
    }

    fun setStyle(style: String) {
        val accepted = style.takeIf { it in LoadingStylePrefs.ALL_STYLES } ?: "bar"
        val palette = UiPreferences.palette(context)
        val primary = UiPreferences.accentColor(context)
        val bright = UiPreferences.blend(primary, Color.WHITE, 0.43f)
        fun rgb(color: Int) = String.format(java.util.Locale.US, "#%06X", (color and 0xFFFFFF))
        val html = template(context)
            .replace("__LOADER_TYPE__", accepted)
            .replace("__COMPACT__", if (compact) "true" else "false")
            .replace("__ACCENT__", rgb(primary))
            .replace("__BRIGHT__", rgb(bright))
            .replace("__BG__", rgb(palette.background))
            .replace("__FG__", rgb(palette.text))
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
    }

    /** Explicitly reclaim the WebView used by a short-lived pagination spinner. */
    fun dispose() {
        web.stopLoading()
        web.destroy()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        web.onResume()
    }

    override fun onDetachedFromWindow() {
        web.onPause()
        super.onDetachedFromWindow()
    }

    companion object {
        @Volatile private var cachedTemplate: String? = null
        private fun template(context: Context): String {
            cachedTemplate?.let { return it }
            return synchronized(this) {
                cachedTemplate ?: context.assets.open("bm_custom_loaders.html")
                    .bufferedReader(Charsets.UTF_8).use { it.readText() }
                    .also { cachedTemplate = it }
            }
        }
    }
}

/** Persisted per-device, never synced to server or account. */
object LoadingStylePrefs {
    const val KEY_GENERAL = "bm_user_loading_style_v1"
    const val KEY_DETAIL = "bm_user_detail_loader_v1"

    // Eight custom spinner designs + the existing native default.
    val GENERAL_STYLES = listOf("classic", "bar", "hamster", "hourglass", "words", "glass", "cubes", "orb", "glow")
    // The film-detail choice is between two skeletons, not spinner styles.
    val DETAIL_STYLES = listOf("classic", "timeline")
    val ALL_STYLES = (GENERAL_STYLES + DETAIL_STYLES).toSet()

    fun general(context: Context): String {
        val raw = UiPreferences.prefs(context).getString(KEY_GENERAL, "classic") ?: "classic"
        return raw.takeIf { it in GENERAL_STYLES } ?: "classic"
    }
    fun detail(context: Context): String {
        val raw = UiPreferences.prefs(context).getString(KEY_DETAIL, "classic") ?: "classic"
        return raw.takeIf { it in DETAIL_STYLES } ?: "classic"
    }
    fun save(context: Context, isDetail: Boolean, style: String) {
        val valid = if (isDetail) DETAIL_STYLES else GENERAL_STYLES
        require(style in valid) { "Unknown loader style" }
        UiPreferences.prefs(context).edit()
            .putString(if (isDetail) KEY_DETAIL else KEY_GENERAL, style).apply()
    }

    fun label(style: String, fa: Boolean): String = when (style) {
        "classic" -> if (fa) "پیش‌فرض بانک‌مووی" else "BankMovie original"
        "bar" -> if (fa) "نوار کشسان" else "Elastic bar"
        "hamster" -> if (fa) "همستر دونده" else "Running hamster"
        "hourglass" -> if (fa) "ساعت شنی" else "Hourglass"
        "words" -> if (fa) "حلقه سه‌گانه" else "Triple ring & words"
        "glass" -> if (fa) "گوی شیشه‌ای" else "Glass sphere"
        "cubes" -> if (fa) "مکعب‌های درخشان" else "Glowing cubes"
        "orb" -> if (fa) "حلقه سینمایی" else "Cinema orb"
        "timeline" -> if (fa) "تایم‌لاین سینمایی" else "Cinema timeline"
        "glow" -> if (fa) "دایره نورانی" else "Glow ring"
        else -> style
    }
}
