'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
const src=read('src/app.js'),html=read('src/index.html'),main=read('electron/main.js'),preload=read('electron/preload.js'),css=read('src/styles.css');
const ctx=vm.createContext({esc:String,cleanUrl:String,img:()=>'<img>',itemTitle:x=>x.title,bmSiteSectionHeading:()=>'',bmSiteViewAll:()=>'<button data-home-collections>All</button>'});
vm.runInContext(src.slice(src.indexOf('function collectionSectionHtml('),src.indexOf('const _bm18RenderHome')),ctx);
const result=ctx.collectionSectionHtml(Array.from({length:14},(_,i)=>({slug:'c'+i,title:'C'+i,cover:'x'})));
assert.equal((result.match(/data-collection-open=/g)||[]).length,4);assert.match(result,/data-home-collections/);
assert.match(html,/data-header-view="discover"[\s\S]*?چی ببینیم؟/);assert.match(html,/src="poster-drag.js"/);assert.match(preload,/openDiscover: \(\) => ipcRenderer.invoke\('discover:open'\)/);assert.match(css,/background:transparent!important;border:0!important/);
let created=0,opts,requested,downloads,permission,check,openHandler;const listeners={};
const fakeSession={setPermissionRequestHandler(fn){permission=fn},setPermissionCheckHandler(fn){check=fn},on(k,fn){downloads=fn}};
class FakeWindow{constructor(o){created++;opts=o;this.webContents={setWindowOpenHandler(fn){openHandler=fn},on(k,fn){listeners[k]=fn}};this.dead=false}isDestroyed(){return this.dead}setMenuBarVisibility(){}once(k,fn){this[k]=fn}async loadURL(url){requested=url}show(){}focus(){}destroy(){this.dead=true;this.closed?.()}}
const m=vm.createContext({BrowserWindow:FakeWindow,session:{fromPartition:p=>{assert.equal(p,'bm-discover-site');return fakeSession}},win:{},childWindows:new Set(),URL,bmHandle:()=>{}});
vm.runInContext(main.slice(main.indexOf('let bmDiscoverWindow=null;'),main.indexOf("bmHandle('browser:open'")),m);
(async()=>{await m.openDiscoverWindow();await m.openDiscoverWindow();assert.equal(created,1);assert.equal(requested,'https://bankmovie.top/discover?bm_entry=top');assert.equal(opts.webPreferences.sandbox,true);assert.equal(opts.webPreferences.nodeIntegration,false);assert.equal(opts.webPreferences.preload,undefined);assert.equal(opts.webPreferences.contextIsolation,true);assert.equal(check(),false);permission(null,'camera',v=>assert.equal(v,false));assert.equal(openHandler().action,'deny');let blocked=0;const event={preventDefault(){blocked++}};listeners['will-navigate'](event,'https://bankmovie.top/discover');listeners['will-navigate'](event,'https://bankmovie.top.evil.test/');listeners['will-redirect'](event,'file:///tmp/x');downloads(event);assert.equal(blocked,3);console.log('PASS: four homepage collections, original Discover route, sandboxed singleton, fixed HTTPS origin, permissions and drag wiring');})().catch(e=>{console.error(e);process.exitCode=1});
