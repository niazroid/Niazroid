#!/usr/bin/env python3
"""Source-level regression guard: TV profile navigation + mobile/TV loading.
This is not a substitute for an APK compile or hardware DPAD test.
"""
from pathlib import Path
import re

root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
loader=(root/'app/src/main/java/ir/bankmoviee/app/ThemeWindowLoadingView.kt').read_text()
workflow=(root/'.github/workflows/build-bankmovie.yml').read_text()

checks={
 'profile starts at subscription': 'requestTvProfileSequenceFocus(primary ?: downloads)',
 'profile header enters subscription': 'page.findViewWithTag<View>("bm_tv_profile_primary")?.let { return it }',
 'profile focus retry helper': 'private fun requestTvProfileSequenceFocus(target: View?): Boolean',
 'profile initial prefers subscription': '"profile" -> content.findViewWithTag<View>("bm_tv_profile_primary")',
 'profile vertical router': 'private fun handleTvProfileVerticalSequence(focused: View, keyCode: Int): Boolean?',
 'subscription to downloads': 'fromPrimary && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN -> downloads',
 'downloads to subscription': 'fromStats && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> primary',
 'downloads to continue': 'fromStats && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN -> continueFirst ?: historyFirst ?: actionsFirst',
 'continue to downloads': 'fromContinue && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> downloads',
 'continue to history': 'fromContinue && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN -> historyFirst ?: actionsFirst',
 'history back to continue': 'fromHistory && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> continueFirst ?: downloads',
 'grid back to history': 'fromFirstGridRow && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> historyFirst ?: continueFirst ?: downloads',
 'profile return can target empty continue': 'tag = "bm_tv_profile_continue_empty"',
 'history section': 'bm_v71_profile_local_rail_history',
 'poster home skeleton retained': 'private fun skeletonPosterCard(width: Int, height: Int): View',
 'detail skeleton retained': 'private fun movieDetailLoading(seed: JSONObject): View',
 'boxoffice skeleton retained': 'private fun boxOfficeLoadingSkeleton(): LinearLayout',
 'collections skeleton retained': 'private fun collectionGridLoadingSkeleton(columns: Int, rows: Int, collectionStyle: Boolean): View',
 'no TV single skeleton tile': 'repeat(if (tv) tvGridColumns() * 2 else 9) { grid.addView(skeletonPosterCard(cardW, cardH)) }',
 'splash theme loader': 'loading.addView(ThemeWindowLoadingView(this@MainActivity)',
 'comments theme loader': 'private fun commentLoadingSpinner(): View',
 'discover theme loader': 'val discoverWaitingRing = ThemeWindowLoadingView(this)',
 'preview theme loader': 'val explorerPreviewSpinner = ThemeWindowLoadingView(this)',
 'search intentionally preserved': 'val loading = fancySpinnerText("در حال آوردن همه نتایج...", q)',
 'search legacy ring intentionally preserved': 'rings.addView(ProgressBar(this@MainActivity, null, android.R.attr.progressBarStyle).apply',
 'loader pauses if hidden': 'if (!isAttachedToWindow || !isShown || windowVisibility != VISIBLE)',
 'loader visibility callback': 'override fun onVisibilityChanged(changedView: View, visibility: Int)',
 'workflow runs current regression': 'python3 verify_v24_tv_profile_skeleton_spinner_fix.py',
}
for name, fragment in checks.items():
    haystack = loader if name.startswith('loader ') else workflow if name.startswith('workflow ') else src
    assert fragment in haystack, f'FAILED: {name}'
assert 'tvLightLoadingTile(' not in src, 'TV poster skeletons must not be collapsed to one spinner tile'
assert 'loading.addView(OrbitalGlowLoaderView(' not in src, 'Splash must use theme-colored ring'
assert src.index('handleTvProfileVerticalSequence(focused, keyCode)?.let { return it }') < src.index('handleV69WeeklyContinueDirectionalFocus(focused, keyCode)?.let { return it }'), 'Profile router must precede legacy Continue router'
assert src.index('handleTvProfileVerticalSequence(focused, keyCode)?.let { return it }') < src.index('explicitTvDirectionalAction(focused, keyCode)?.let { return it }'), 'Profile router must precede generic actions'
assert 'source' in workflow.lower() and re.search(r'(?m)^\s+SOURCE_ZIP: BankMovie_Android_FULLSOURCE_V2\.4_TV_STARTUP_EXPLORE_ARCHIVE5_COLLECTIONS_FIX\.zip\s*$',workflow), 'YAML source name must match'
print('VERIFY_V24_TV_PROFILE_FOCUS_SKELETON_SPINNER_FIX_OK')
