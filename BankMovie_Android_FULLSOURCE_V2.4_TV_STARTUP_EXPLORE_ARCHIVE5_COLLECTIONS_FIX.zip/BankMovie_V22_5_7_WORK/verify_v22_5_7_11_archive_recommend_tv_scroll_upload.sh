#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PYCHECK'
from pathlib import Path
import re,xml.etree.ElementTree as ET
root=Path.cwd()
m=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
p=(root/'app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
icon=root/'app/src/main/res/drawable/ic_upload_subtitle.xml'
assert m.count('if (detailArchive in 1..2) {') == 2
assert 'if (detailArchive != 5) {' not in m
assert m.count('addJsonRail(page, "پیشنهاد فیلم", related, showMore = false)') == 1
assert m.count('addJsonRail(page, t("پیشنهاد فیلم", "Recommended"), related, showMore = false)') == 1
assert 'private fun revealDiscoverTvFocusedView(target: View?)' in m
assert 'page.offsetDescendantRectToMyCoords(target, bounds)' in m
assert 'if (requestTvFocusVerified(next)) revealDiscoverTvFocusedView(next)' in m
assert 'view is android.widget.Spinner || view is SeekBar' in m
assert 'currentScreen == "discover" && currentFocus is SeekBar' in m
assert 'val revealRequestedResults = tv && !firstDiscoverResults' in m
assert 'if (requestTvFocusVerified(target)) revealDiscoverTvFocusedView(target)' in m
assert 'R.drawable.ic_upload_subtitle' in p and 'importSubtitle.setCompoundDrawablesRelative' in p
assert 'openManualSubtitlePicker()' in p and 'IMedia.Slave.Type.Subtitle' in p
rootNode=ET.parse(icon).getroot()
ns='{http://schemas.android.com/apk/res/android}'
paths=rootNode.findall('path')
assert len(paths)==2
assert 'M12,16 V3' in paths[1].attrib[ns+'pathData']
print('VERIFY_V22_5_7_11_ARCHIVE_RECOMMEND_TV_SCROLL_UPLOAD_OK')
PYCHECK
