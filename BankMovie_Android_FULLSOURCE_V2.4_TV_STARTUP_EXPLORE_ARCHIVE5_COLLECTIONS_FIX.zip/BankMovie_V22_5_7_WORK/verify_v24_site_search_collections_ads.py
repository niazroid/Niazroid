#!/usr/bin/env python3
"""Offline source-contract regression test for site-style search, collection search and ads."""
from pathlib import Path
import subprocess
import re

ROOT = Path(__file__).resolve().parent
MAIN = (ROOT / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
API = (ROOT / 'server-required/app_api.php').read_text(encoding='utf-8')
ADMIN = (ROOT / 'server-required/bm_admin.php').read_text(encoding='utf-8')
CONFIG = (ROOT / 'server-required/app_config.php').read_text(encoding='utf-8')


def must(condition, message):
    if not condition:
        raise AssertionError(message)


def section(src, start, end):
    i = src.index(start)
    return src[i:src.index(end, i + len(start))]

# App calls the live site-backed taxonomy rather than relying on label-only search.
options = section(API, "if ($action === 'search_options')", "if ($action === 'sliders'")
must('api2_search_options()' in options and "'countries'" in options and "'genres'" in options, 'Live source options endpoint missing')
must('advancedSearch($params)' in API, 'Archive 1 search no longer delegates to the source library')
search = section(MAIN, 'private fun advancedSearchUrl(', 'private fun advancedFilterCount(')
archive1 = search[search.index('add("archive", "1")'):]
for key in ('genre_id', 'country_id', 'advanced_mode', 'min_year', 'max_year', 'sortby', 'imdbrate', 'actor', 'director'):
    must(f'add("{key}",' in archive1, f'Archive 1 query is missing {key}')
for key in ('country', 'actor', 'director'):
    must(f'add("{key}",' in search, f'Cross-archive filter is missing {key}')
must('siteArchive1Options("countries", archive1CountryOptions())' in MAIN, 'Source country IDs not selectable')
must('android.widget.AutoCompleteTextView(this)' in MAIN, 'The source-like typed country picker is missing')
must("'آمریکا'=>'United States'" in API, 'Persian source country alias is missing')
must('state.countryValue = ""' not in section(MAIN, 'val applyButton = TextView(this).apply {', 'val resetButton = TextView(this).apply {'), 'Apply clears the selected country')
must('prefetchArchive1SearchOptions()' in MAIN, 'Archive 1 taxonomy is not fetched')
must("'country_id' => max(0, (int)bm_app_param('country_id', 0))" in API, 'Backend is dropping country IDs')
must("'genre_id' => max(0, (int)bm_app_param('genre_id', 0))" in API, 'Backend is dropping genre IDs')
must("'advanced_mode' =>" in API and "'suggest' =>" in API, 'Backend does not mirror site advanced mode')

# Search must restrict the collection rows, use placeholders and maintain pagination.
collections = section(API, 'function bm_app_collections(', 'function bm_app_extract_slug_from_url(')
must('LIKE ?' in collections and '$stmt->execute($searchParams)' in collections, 'SQL collection search unsafe or absent')
must('WHERE ' in collections and 'LIMIT $limit OFFSET $offset' in collections, 'Collection search loses pagination')
must("bm_app_collections($page, $limit, bm_app_param('q', ''))" in API, 'Collection action ignores query')
collections_ui = section(MAIN, 'private fun showCollections(', 'private fun showCollectionItems(')
for token in ('Search collections', 'submitCollectionSearch()', 'collectionsGeneration', 'action=collections', '&q=${enc(collectionSearchQuery)}'):
    must(token in collections_ui, f'Collection search UI is missing {token}')

# Admin ad is independently saved and keeps old config fields intact.
for field in ('home_ad', 'ad_image_upload', 'ad_text', 'ad_title', 'ad_link_url', 'ad_enabled', 'ad_remove_image'):
    must(field in ADMIN, f'Admin is missing {field}')
must('bm_admin_csrf' in section(ADMIN, 'id="bmHomeAdsEditor"', 'id="v22-security"'), 'Ad form has no CSRF protection')
must('is_uploaded_file($tmp)' in ADMIN and 'getimagesize($tmp)' in ADMIN, 'Ad upload is not verified')
must("'home_ad' => is_array($config['home_ad'] ?? null)" in ADMIN, 'Save-all discards ad configuration')
must("'home_ad' => ['enabled'=>false" in CONFIG, 'Remote config has no safe ad defaults')
must("$default['home_ad']['image_url'] = $adOrigin . '/app_ad_image.php?v='" in CONFIG, 'Controller-hosted artwork must use the public image route')
must("@mkdir($uploadDir, 0755, true)" in ADMIN and '@chmod($uploadDir, 0755)' in ADMIN, 'Previously created image directory remains private to nginx')
must('id="bmAdPreviewImageError"' in ADMIN, 'BM Admin preview must show an image loading error')
IMAGE = (ROOT / 'server-required/app_ad_image.php').read_text(encoding='utf-8')
must('realpath($root' in IMAGE and "$config['home_ad']['image_url']" in IMAGE and 'getimagesize($file)' in IMAGE, 'Ad image endpoint must only expose the currently configured image')
must('bm_home_ad_image_fallback' in MAIN and 'image.visibility = View.VISIBLE' in MAIN, 'Native ad image failure fallback is missing')

ad_card = section(MAIN, 'private fun addHomeAdvertisingCard(', 'private fun showHome(')
must('image_url' in ad_card and 'description' in ad_card and 'clipToOutline = true' in ad_card, 'Rounded text/image ad incomplete')
must('resolvedLink' in ad_card and 'openExternal(resolvedLink, null)' in ad_card, 'Relative and external ad links are not supported')
must('addHomeAdvertisingCard(homeBody)' in MAIN, 'Home does not show ad')
must('homeAdvertisingConfig = json.optJSONObject("home_ad")' in MAIN, 'Remote ad settings are not consumed')

for file in ('server-required/app_api.php', 'server-required/app_config.php', 'server-required/bm_admin.php', 'server-required/app_ad_image.php'):
    result = subprocess.run(['php', '-l', str(ROOT / file)], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    must(result.returncode == 0, f'{file}: {result.stdout}')
print('BANKMOVIE_SITE_ADVANCED_SEARCH_COLLECTIONS_ADS_OK')
