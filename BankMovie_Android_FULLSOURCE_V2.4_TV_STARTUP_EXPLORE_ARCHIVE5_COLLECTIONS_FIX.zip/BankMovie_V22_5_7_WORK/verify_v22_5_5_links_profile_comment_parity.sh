#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_api.php >/dev/null
php -l server-required/app_user_api.php >/dev/null
php -l SITE_PATCH_REQUIRED/app_user_api.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
main=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
acc=Path('app/src/main/java/ir/bankmoviee/app/AccountApi.kt').read_text()
api=Path('server-required/app_api.php').read_text()
srv=Path('server-required/app_user_api.php').read_text()
assert 'fun requestRealDetail()' in main
assert 'در حال دریافت لینک قسمت‌ها…' not in main
assert 'bm_detail_connection_retry' in main
assert 'topMargin = dp(204)' in main
for token in ('تغییر نام کاربری', 'تغییر رمز عبور', 'تأیید و ذخیره  ✓', 'انصراف', 'dialog.dismiss()'):
    assert token in main, token
assert 'bm_account_credential_limits' in srv
assert 'bm_app_downloads_from_db_movie($movieId);' in api
assert 'function bm_app_db_link_page' not in api
assert 'arc([1345])-' in acc
assert 'comment_archive' in acc and 'canonicalSiteSlug' in acc
assert "'arc5:'" in srv
assert "bm_user_api_upsert_external_comment_item($pdo, $ctx, $commentItem, false)" in srv
assert Path('SITE_PATCH_REQUIRED/app_user_api.php').read_bytes() == Path('server-required/app_user_api.php').read_bytes()
loader=main[main.index('private fun loadImage('):main.index('private fun animateExpandable(',main.index('private fun loadImage('))]
for guard in ('instanceFollowRedirects = true', 'PosterDiskCache.write', 'ImageDecoder.decodeBitmap'):
    assert guard in loader
print('VERIFY_V22_5_5_LINKS_PROFILE_COMMENT_PARITY_OK')
PYTEST
