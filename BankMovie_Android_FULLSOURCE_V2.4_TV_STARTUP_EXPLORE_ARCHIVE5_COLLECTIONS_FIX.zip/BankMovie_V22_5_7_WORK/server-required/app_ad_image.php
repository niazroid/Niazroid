<?php
/**
 * Public image delivery for the active BankMovie home advertisement.
 * Deliberately accepts NO file/path arguments; only the image in the current
 * admin-controlled configuration can be served.  Fixes nginx 403 on an older
 * 0750 uploads directory without relaxing access to unrelated upload paths.
 */
declare(strict_types=1);
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', ['GET', 'HEAD'], true)) {
    header('Allow: GET, HEAD'); http_response_code(405); exit;
}
$root = __DIR__;
$raw = @file_get_contents($root . '/bankmovie_remote_config.json');
$config = is_string($raw) ? json_decode($raw, true) : null;
$path = is_array($config) ? trim((string)($config['home_ad']['image_url'] ?? '')) : '';
if (!preg_match('~^/uploads/bm-app-ads/([a-f0-9]{28})\.(jpg|png|webp|gif)$~iD', $path, $parts)) {
    http_response_code(404); exit;
}
$dir = realpath($root . '/uploads/bm-app-ads');
if ($dir === false) { http_response_code(404); exit; }
$file = realpath($dir . DIRECTORY_SEPARATOR . $parts[1] . '.' . $parts[2]);
if ($file === false || dirname($file) !== $dir || !is_file($file) || !is_readable($file)) {
    http_response_code(404); exit;
}
// Backfill compact art for advertisements uploaded before this patch.
// Generate only once and only for reasonably sized raster files, never for
// SVG or animated GIF. An absent GD extension gracefully serves the original.
$originalExt = strtolower(pathinfo($file, PATHINFO_EXTENSION));
$compactRoot = $dir . DIRECTORY_SEPARATOR . $parts[1];
if (in_array($originalExt, ['jpg','png','webp'], true) &&
    !is_file($compactRoot.'.optimized.webp') && !is_file($compactRoot.'.optimized.jpg') &&
    function_exists('imagecreatetruecolor') && function_exists('imagecopyresampled')) {
    $meta = @getimagesize($file);
    $width = (int)($meta[0] ?? 0); $height = (int)($meta[1] ?? 0);
    if ($width > 0 && $height > 0 && $width * $height <= 9000000 &&
        max($width, $height) > 1000) {
        $src = match ($originalExt) {
            'jpg' => function_exists('imagecreatefromjpeg') ? @imagecreatefromjpeg($file) : false,
            'png' => function_exists('imagecreatefrompng') ? @imagecreatefrompng($file) : false,
            'webp' => function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($file) : false,
        };
        if ($src !== false) {
            $scale = min(1.0, 1200 / $width, 620 / $height);
            $dw = max(1, (int)round($width * $scale));
            $dh = max(1, (int)round($height * $scale));
            $dst = imagecreatetruecolor($dw, $dh);
            imagealphablending($dst, false); imagesavealpha($dst, true);
            imagecopyresampled($dst, $src, 0, 0, 0, 0, $dw, $dh, $width, $height);
            $target = function_exists('imagewebp') ? $compactRoot.'.optimized.webp' : $compactRoot.'.optimized.jpg';
            $tmp = $target.'.tmp.'.bin2hex(random_bytes(4));
            $ok = str_ends_with($target, 'webp')
                ? @imagewebp($dst, $tmp, 78)
                : (function_exists('imagejpeg') && @imagejpeg($dst, $tmp, 80));
            if ($ok && is_file($tmp) && filesize($tmp) > 0 && filesize($tmp) <= 4*1024*1024) {
                @chmod($tmp, 0644);
                if (!@rename($tmp, $target)) @unlink($tmp);
            } else @unlink($tmp);
            imagedestroy($dst); imagedestroy($src);
        }
    }
}
// Prefer the pre-generated compact derivative if it exists; the public URL
// and config revision stay unchanged. File access remains bound to the one
// currently configured upload (no user-controlled path parameters).
$stem = $dir . DIRECTORY_SEPARATOR . $parts[1];
foreach (['.optimized.webp', '.optimized.jpg'] as $suffix) {
    $variant = realpath($stem . $suffix);
    if ($variant !== false && dirname($variant) === $dir && is_file($variant) && is_readable($variant) && filesize($variant) > 0 && filesize($variant) <= 4 * 1024 * 1024) {
        $file = $variant;
        break;
    }
}
$size = filesize($file);
if ($size === false || $size <= 0 || $size > 4 * 1024 * 1024) {
    http_response_code(404); exit;
}
$info = @getimagesize($file);
$mime = is_array($info) ? ($info['mime'] ?? '') : '';
if (!in_array($mime, ['image/jpeg','image/png','image/webp','image/gif'], true)) {
    http_response_code(404); exit;
}
header('Content-Type: ' . $mime);
header('Content-Length: ' . $size);
header('Cache-Control: public, max-age=86400, must-revalidate');
$etag = '"' . hash('sha256', $parts[1] . ':' . $size . ':' . filemtime($file)) . '"';
header('ETag: ' . $etag);
if (trim($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
    http_response_code(304); exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'HEAD') exit;
readfile($file);
