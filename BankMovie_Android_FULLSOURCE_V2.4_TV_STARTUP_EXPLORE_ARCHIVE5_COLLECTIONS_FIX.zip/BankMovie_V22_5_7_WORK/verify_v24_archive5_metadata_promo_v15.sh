#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
import re, zipfile, xml.etree.ElementTree as ET
p=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt')
s=p.read_text(encoding='utf-8')
resources='app/src/main/res/drawable'
# V14 SVG assets remain in the source as historical assets, but the latest
# user-requested design intentionally rolls back their use in the screen.
assert all((Path(resources, name+'.xml')).is_file() for name in [
 'bm_v14_users_round', 'bm_v14_play', 'bm_v14_copy',
 'bm_v14_clapperboard', 'bm_v14_chevron_down',
 'bm_v14_circle_help', 'bm_v14_download', 'bm_v14_share',
])
# Only Archives 1 and 2 have recommendations; keep Archive 3/4/5 clean.
assert s.count('if (detailArchive in 1..2) {')==2
assert s.count('} // Archives 3, 4 and 5 have no source recommendations section.')==2
# Archive 1 and 2 recommendations must remain available.
assert 'addArchive2GenreRail(page' in s and 'addSearchRail(page' in s
assert 'isArchive5Promo(raw)' in s
assert 'if (archive != 5 || !isArchive5Promo(raw))' in s
assert 'if (json.has("results")) json.put("results", normalized)' in s
assert 'val pattern = Regex("""(?m)' in s
assert 'item.put("archive5_metadata", info)' in s
assert 'item.put("long_description", summary)' in s
assert 'item.optJSONArray("archive5_metadata")' in s
assert 'addInfoRow(fact.optString("label"), fact.optString("value"))' in s
assert 'titleKey.contains("فصل‌ها و قسمت‌ها") || titleKey.contains("seasons, episodes") -> R.drawable.bm_ic_episode_play' in s
assert 'setImageResource(R.drawable.ic_copy_link)' in s
assert 'setColorFilter(if (palette.light) palette.text else Color.WHITE)' in s
assert 'R.drawable.bm_v15_cast_favorite' in s
# V13.1 compile fix remains intact.
assert not re.search(r'(?<!fun )\bdownloadNotice\s*\(',s)
print('BANKMOVIE_V15_ARCHIVE5_METADATA_PROMO_OK')
PY
