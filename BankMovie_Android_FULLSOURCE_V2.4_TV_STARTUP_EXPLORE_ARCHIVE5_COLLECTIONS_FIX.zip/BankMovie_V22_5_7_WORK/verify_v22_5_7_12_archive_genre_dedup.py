#!/usr/bin/env python3
"""Source-contract regression checks; run offline in the Android CI workflow."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent
source = (root / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

def section(name: str, next_name: str) -> str:
    start = source.index(f'private fun {name}(')
    end = source.index(f'private fun {next_name}(', start + 15)
    return source[start:end]

def check(cond: bool, message: str) -> None:
    if not cond:
        raise AssertionError(message)

# The real 'movies.genres' column contains English CSV like 'Action, Crime, Thriller'.
# Never search it with the Persian UI label.
db_genres = 'Action, Crime, Thriller'
check('Action' in db_genres and 'اکشن' not in db_genres, 'DB genre fixture')
converter = section('archive2DbGenreQuery', 'archive2GenreUrl')
check('"اکشن" -> "Action"' in converter, 'Archive 2 Action alias')
check('"جنایی" -> "Crime"' in converter, 'Archive 2 Crime alias')
check('"هیجان‌انگیز" -> "Thriller"' in converter, 'Archive 2 Thriller alias')
check('"علمی-تخیلی" -> "Sci"' in converter, 'Archive 2 science-fiction aliases')
check('archive2DbGenreQuery(genre)' in section('archive2GenreUrl', 'showArchive2GenreList'), 'Genre page uses DB values')
advanced = section('advancedSearchUrl', 'advancedFilterCount')
check('add("genre", archive2DbGenreQuery(state.genreValue))' in advanced, 'Advanced uses DB values')

# Both separately maintained UI taxonomies must store English query tokens.
for name, end in [('archive2GenreOptions', 'countryFlagEmoji'), ('archive2GenreCatalog', 'archive3GenreCatalog')]:
    data = section(name, end)
    for line in data.splitlines():
        m = re.search(r'(?:GenreCategory\("[^"]+", "[^"]+",|AdvancedOption\()\s*"([^"]+)"', line)
        if m and m.group(1):
            check(not re.search('[\u0600-\u06ff]', m.group(1)), f'{name}: Persian DB token: {m.group(1)}')

# Archive 5 has normal search but deliberately no non-existent advanced screen.
check('AccountSession.advancedSearchEnabled(this) && selectedArchive != 5' in source, 'Archive 5 advanced entry still shown')
check('if (archive == 5) return // Archive 5 deliberately has no advanced search API.' in source, 'Archive 5 advanced fallback')
check('5 -> archive5ApiUrl(' in source, 'Archive 5 normal API search must remain')

# Archive 1 advanced URL uses names actually consumed by the app_api.php search branch.
for key in ('"genre"', '"min_year"', '"max_year"', '"country"', '"sortby"', '"imdbrate"'):
    check(f'add({key},' in advanced, f'Missing Archive 1 server parameter {key}')
# Updated server forwards source IDs to the real advancedSearch() helper.
for supported in ('"genre_id"', '"country_id"', '"advanced_mode"'):
    tail = advanced[advanced.index('add("archive", "1")'):]
    check(f'add({supported},' in tail, f'Archive 1 source taxonomy parameter {supported} missing')
for invalid in ('"year_from"', '"year_to"', '"rating"'):
    tail = advanced[advanced.index('add("archive", "1")'):]
    check(f'add({invalid},' not in tail, f'Archive 1 unsupported parameter {invalid}')

# Archive 1 dedups by stable identity across independently serialized endpoints.
helper = section('catalogueIdentityKeys', 'markCatalogueSeen')
for item in ('imdb_code', 'imdb_id', 'source_url', 'detail_id', 'source_slug', 'year'):
    check(item in helper, f'Missing archive 1 identity field {item}')
check('if (archive != 1)' in helper, 'Dedup must not change other archives')
check('if (keys.any { it in seen }) return false' in section('markCatalogueSeen', 'normalizeArchiveItem'), 'Identity collision guard missing')
for name, end in [('showList', 'listTop'), ('showKeywordList', 'sectionResponseRequestsHardHide'),
                  ('showGenreItems', 'searchAcceptsType'), ('showAdvancedSearchResults', 'showSearch')]:
    check('markCatalogueSeen(' in section(name, end), f'{name} does not dedup')
check('markCatalogueSeen(item, originArchive, seen)' in source, 'Live/quick search does not dedup')
check('markCatalogueSeen(item, archive, railSeen)' in source, 'Home rails do not dedup')
check('originArchive != 1 || added > 0' in source, 'Archive 1 repeated pages keep auto-fetching')
print('ARCHIVE_2_ENGLISH_GENRES_ARCHIVE_5_HIDE_ADVANCED_ARCHIVE_1_IDENTITY_AND_FILTERS_OK')
