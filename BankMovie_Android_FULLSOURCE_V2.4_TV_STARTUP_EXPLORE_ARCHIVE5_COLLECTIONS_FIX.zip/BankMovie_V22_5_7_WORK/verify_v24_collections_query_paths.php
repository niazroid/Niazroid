<?php
/**
 * Standalone regression guard for the collections list and filtered-search paths.
 * No database connection is required. Runs on the same PHP CLI as CI.
 */
$source = file_get_contents(__DIR__ . '/server-required/app_api.php');
if ($source === false) throw new RuntimeException('Cannot read server app_api.php');
$start = strpos($source, 'function bm_app_collections(');
$end = strpos($source, 'function bm_app_extract_slug_from_url(', $start);
if ($start === false || $end === false) throw new RuntimeException('Collection function not found');
$body = substr($source, $start, $end - $start);
$body = substr($body, 0, strrpos($body, '}') + 1);

class CollectionStatementMock {
    public function __construct(private array $rows = []) {}
    public function execute(array $params): void { $GLOBALS['collection_params'][] = $params; }
    public function fetchAll($fetchStyle): array { return $this->rows; }
}
class CollectionPdoMock {
    public function query(string $sql): CollectionStatementMock {
        $GLOBALS['collection_query_sql'][] = $sql;
        return new CollectionStatementMock([['id'=>1,'cover_image'=>'', 'fallback_cover_image'=>'poster.webp']]);
    }
    public function prepare(string $sql): CollectionStatementMock {
        $GLOBALS['collection_prepare_sql'][] = $sql;
        return new CollectionStatementMock([['id'=>2,'cover_image'=>'search.webp', 'fallback_cover_image'=>'']]);
    }
}
function bm_app_pdo(): CollectionPdoMock { return new CollectionPdoMock(); }
function bm_app_table_columns(string $table): array {
    return match ($table) {
        'collections' => ['id','title','status','cover_image'],
        'movies' => ['id','poster','imdb_code','year'],
        'collection_movies' => ['collection_id','movie_id','sort_order'],
        default => [],
    };
}
function bm_app_first_existing_column($table, $candidates): string {
    foreach ($candidates as $candidate) {
        if (in_array($candidate, bm_app_table_columns($table), true)) return $candidate;
    }
    return '';
}
function bm_app_normalize_collection(array $row): array { return $row; }
eval($body);
$GLOBALS['collection_query_sql'] = [];
$GLOBALS['collection_prepare_sql'] = [];
$GLOBALS['collection_params'] = [];
$home = bm_app_collections(1, 8);
if (count($GLOBALS['collection_query_sql']) !== 1 || $GLOBALS['collection_prepare_sql'] ||
    count($home['items']) !== 1 || !str_contains($GLOBALS['collection_query_sql'][0], 'WHERE fc.collection_id = c.id')) {
    throw new RuntimeException('Unfiltered collection list must use one query, without N+1');
}
$search = bm_app_collections(2, 12, 'Sci-Fi%');
if (count($GLOBALS['collection_prepare_sql']) !== 1 || count($GLOBALS['collection_params']) !== 1 ||
    $GLOBALS['collection_params'][0] !== ['%Sci-Fi%%'] ||
    !str_contains($GLOBALS['collection_prepare_sql'][0], 'c.`title` LIKE ?') ||
    !str_contains($GLOBALS['collection_prepare_sql'][0], 'LIMIT 12 OFFSET 12') ||
    count($search['items']) !== 1 || $search['items'][0]['id'] !== 2) {
    throw new RuntimeException('Filtered collection search must use one prepared, bound query with pagination');
}
echo "VERIFY_V24_COLLECTIONS_QUERY_PATHS_OK\n";
