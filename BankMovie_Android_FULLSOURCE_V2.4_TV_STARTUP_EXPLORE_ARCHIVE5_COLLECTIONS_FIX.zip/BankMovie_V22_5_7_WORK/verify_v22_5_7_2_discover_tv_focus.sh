#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
s=m[m.index('    private fun showDiscover() {'):m.index('    private fun showCategories() {')]
handler=m[m.index('    private fun handleDiscoverTvDirectionalFocus('):m.index('    private fun handleTvDirectionalFocus(')]
assert 'tag = "bm_tv_discover_page"' in s
assert s.count('applyTvFocusToClickableTree(page, buildDirectionalGraph = false)') == 2
assert 'if (!tv) { // Video Explorer previews/remote network calls are mobile-only.' in s
assert 'handleDiscoverTvDirectionalFocus(focusedOrNull, keyCode)?.let { return it }' in m
assert m.index('handleDiscoverTvDirectionalFocus(focusedOrNull, keyCode)') < m.index('handleV74715BoxOfficeBootstrap(focusedOrNull, keyCode)')
assert 'event.action == android.view.KeyEvent.ACTION_UP' in m and 'currentScreen == "discover"' in m
assert 'tvFocusRows(ready)' in handler
assert 'candidate.centerY < current.centerY' in handler
assert 'candidate.centerY > current.centerY' in handler
assert 'return true' in handler and 'requestTvFocusVerified(next)' in handler
assert 'view is android.widget.Spinner' in handler
assert 'requestTvSideNavFocus(false)' in handler
assert 'else if (!tv)' in s and 'scroll.smoothScrollTo' in s
assert 'focusedResultsBeforeRefresh' in s
assert 'AccountApi.listComments(this, item, requestedPage, 10, selectedSort)' in m
assert 'topMargin = dp(204)' in m
print('VERIFY_V22_5_7_2_DISCOVER_TV_FOCUS_OK')
PYTEST
