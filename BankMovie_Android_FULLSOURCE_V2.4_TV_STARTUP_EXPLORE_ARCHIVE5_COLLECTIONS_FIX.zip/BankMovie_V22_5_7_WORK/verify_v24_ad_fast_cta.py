#!/usr/bin/env python3
from pathlib import Path
import re, subprocess, tempfile, shutil, json, struct, zlib
root=Path(__file__).resolve().parent
main=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
admin=(root/'server-required/bm_admin.php').read_text()
endpoint=(root/'server-required/app_ad_image.php').read_text()
config=(root/'server-required/app_config.php').read_text()
for marker in ['homeAdExecutor.execute', 'PosterDiskCache.read(this@MainActivity, url)', 'PosterDiskCache.write(this@MainActivity, url, bytes)', 'bm_home_ad_last_success_url', 'setOnClickListener { openExternal(resolvedLink, null) }', 'ad.optString("button_icon", "arrow")']:
 assert marker in main,marker
for marker in ["'button_icon'=>", 'name="ad_button_icon"', 'id="bmAdPreviewCta"', 'id="bmAdPreviewIcon"', "'ad_button_text'", 'optimized.webp']:
 assert marker in admin,marker
assert "'button_icon'=>'arrow'" in config
for icon in ['arrow','bag','eye','play','external']:
 p=root/f'app/src/main/res/drawable/bm_ad_svg_{icon}.xml'
 from xml.etree import ElementTree
 assert p.is_file() and ElementTree.parse(p).getroot().tag.endswith('vector')
 assert (root/f'app/src/main/assets/bm_ads_offline_svg/{icon}.svg').is_file()
assert "header('Cache-Control: public, max-age=86400" in endpoint
assert "in_array($originalExt, ['jpg','png','webp']" in endpoint
print('BANKMOVIE_AD_FAST_DISK_CACHE_OFFLINE_SVG_BUTTON_OK')
