package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator

/** One lightweight circular loading indicator. No shimmer bitmaps or WebViews. */
class ThemeWindowLoadingView(context: Context) : View(context) {
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2.5f
        strokeCap = Paint.Cap.ROUND
        color = UiPreferences.palette(context).primary
    }
    private val oval = RectF()
    private var progress = 0f
    private var animator: ValueAnimator? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (minOf(width, height) / 2f - ring.strokeWidth * 2f).coerceAtLeast(1f)
        oval.set(cx - radius, cy - radius, cx + radius, cy + radius)
        val cycle = progress * Math.PI * 2.0
        val sweep = (2f + 178f * ((1.0 - kotlin.math.cos(cycle)) / 2.0).toFloat()).coerceIn(2f, 180f)
        canvas.drawArc(oval, progress * 1080f - 90f, sweep, false, ring)
    }

    /** Never animate a hidden panel: idle app/TV screens must not consume CPU. */
    private fun syncAnimation() {
        if (!isAttachedToWindow || !isShown || windowVisibility != VISIBLE) {
            animator?.cancel()
            animator = null
            return
        }
        if (animator != null) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        syncAnimation()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        syncAnimation()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        syncAnimation()
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }
}
