#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PYTEST'
from pathlib import Path
import re
src = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
wf = Path('.github/workflows/build-bankmovie.yml').read_text()
# V22.5.7.6 used snapshot shell padding in Home. V22.5.7.7 reverts
# it to the V2.3 stable retained-screen implementation and completely avoids
# retaining the Home view tree on TV. Only the focused TV Home is rebuilt.
assert 'contentPaddingLeft: Int' not in src
assert 'tvSideNavWasDocked: Boolean' not in src
assert 'private fun restoreRetainedNavigationScreen' in src
assert 'if (isTvLike() && currentScreen == "home") {' in src
assert 'navigationHistory.add { restorer() }' in src
# Regression: forced rail clip and two-frame scroll reposition from V22.5.7.4
# must not exist. The original focus/scroll path is restored.
assert 'tvHomeRailOffsets' not in src
assert 'restoreRetainedTvHomeViewport' not in src
assert 'captureTvHomeRailOffsets' not in src
assert 'currentScreen == "home" && parent is HorizontalBankmovieSmoothScrollView' not in src
assert 'currentScreen == "home" && v is HorizontalBankmovieSmoothScrollView' not in src
assert 'private fun handleDiscoverTvDirectionalFocus' in src
assert 'R.drawable.bm_site_neon_collections' in src
assert 'R.drawable.ic_auth_user' in src and 'R.drawable.ic_auth_lock' in src
assert 'verify_v22_5_7_6_tv_home_shell_restore.sh' in wf
print('VERIFY_V22_5_7_6_TV_SHELL_REGRESSION_COMPAT_OK')
PYTEST
