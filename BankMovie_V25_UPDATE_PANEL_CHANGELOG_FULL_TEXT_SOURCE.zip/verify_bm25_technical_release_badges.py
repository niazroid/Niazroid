#!/usr/bin/env python3
"""Static safeguards; use CI/Android device for actual compile and visual behavior."""
from pathlib import Path
import re

root = Path(__file__).resolve().parent
main = (root / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
api = (root / 'server-required/app_api.php').read_text(encoding='utf-8')
section = main.split('    private fun linkTechnicalLabels(link: JSONObject)', 1)[1].split('    private fun preferredQualityVariantScore', 1)[0]
row = main.split('    private fun downloadQualityRow(', 1)[1].split('    private fun movieVersionPanel(', 1)[0]
quality = main.split('    private fun qualityOnlyLinks(', 1)[1].split('    private fun linkKindOrder(', 1)[0]
for marker in ('WEB-DL', 'WEBRip', 'BluRay', 'BDRip', 'BRRip', 'HDTV', 'HDRip', 'DVDRip', 'REMUX', 'x265', 'x264', '10Bit', 'encoder'):
    assert marker in section, marker
assert 'android.net.Uri.parse(mediaUrl).lastPathSegment' in section
assert 'link.optString(it)' in section
assert 'linkTechnicalLabels(link)' in row
assert 'val maxVisible = if (tvTags) 6 else technicalTags.size' in row
assert 'android.widget.HorizontalScrollView' in row
assert 'bm_download_play' in row and 'bm_download_save' in row and 'bm_watch_party' in row
assert 'link.optString("download_url")' in quality or '"download_url", "url", "stream_url"' in quality
assert 'normalizedQualityKey(link)' in quality and 'identity' in quality
assert 'bm_app_link_technical_fields' in api
assert "'encoder'" in api and "'release_group'" in api
assert 'source_table' in api
assert 'source_zip=' not in section
print('BM25_TECHNICAL_RELEASE_BADGES_STATIC_OK')
