#!/usr/bin/env python3
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).parent
main=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
tv=(root/'app/src/main/java/ir/bankmoviee/app/TvAppUpdateActivity.kt').read_text()
download_xml=root/'app/src/main/res/drawable/bm_ic_update_download_user.xml'
changes_xml=root/'app/src/main/res/drawable/bm_ic_update_changes_user.xml'
ET.parse(download_xml)
ET.parse(changes_xml)
assert '38CFFF' in download_xml.read_text() and 'L50,64L70,44' in download_xml.read_text()
assert '45D5FF' in changes_xml.read_text() and 'M15,39L69,23V77L15,61V39Z' in changes_xml.read_text()
assert 'R.drawable.bm_ic_update_download_user' in main and 'R.drawable.bm_ic_update_download_user' in tv
assert 'R.drawable.bm_ic_update_changes_user' in main
assert 'text = t("خروج از برنامه", "Exit app")' in main
assert 'if (isTelevisionForUpdate() && event.action == android.view.KeyEvent.ACTION_UP)' in main
assert 'finishAffinity()' in main and 'override fun onBackPressed() { exitUpdater() }' in tv
assert 'activeConnection?.disconnect()' in tv
assert 'type.contains("html")' in tv and 'verifyDownloadedApk(saved)' in tv
assert 'MessageDigest.getInstance("SHA-256")' in tv
assert 'val latestChanges = changes' in main
assert 'text = panelText // Preserve punctuation, emojis and all words.' in main
assert 'releaseSections.firstOrNull {' not in main
assert 'fun readPanelChanges(value: Any?)' in main
assert 'latestHeader.setOnClickListener {' in main
assert 'ValueAnimator.ofInt(startHeight, targetHeight)' in main
assert 'Never split on dashes' in main or 'never split on dashes' in main
assert 'page.addView(changeCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })' in main
print('BM25_TV_UPDATE_FIX_STATIC_OK')
