# هات‌فیکس GitHub Actions بانک‌مووی

این نشانگر تأیید می‌کند سورس صحیح نسخه Remote Controller Player V2 Hotfix انتخاب شده است.

- کنترلر اولیه: `bankmoviee.ir` فقط برای دریافت تنظیمات ریموت
- دامنه پیش‌فرض API و محتوا: `bankmovie.top`
- پخش: لینک اصلی پخش
- دانلود: `download_url` مدیریت‌شده توسط سایت
- Google Cast: حذف‌شده
- خروجی: هشت APK جداگانه به‌همراه فایل SHA256

فایل `Bankmovie-v2.1-REMOTE-CONTROLLER-PLAYER-V2-SOURCE-HOTFIX.zip` و فایل YAML جدید را در ریشه یک ریپازیتوری خالی قرار دهید. Workflow در صورت انتخاب سورس قدیمی، خطای خوانا با نام فایل مشکل‌دار نمایش می‌دهد.
