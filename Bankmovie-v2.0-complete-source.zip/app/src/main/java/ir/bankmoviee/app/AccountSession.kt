package ir.bankmoviee.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AccountSession {
    private const val PREFS = "bankmovie_account"
    private const val KEY_TOKEN = "token"
    private const val KEY_USER = "user"
    private const val KEY_AUTH_BACKGROUND = "auth_background"
    private const val KEY_REMOVED_WATCHLIST = "removed_watchlist_keys"
    private const val KEY_LAST_SYNC = "last_watchlist_sync"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun token(context: Context): String = prefs(context).getString(KEY_TOKEN, "") ?: ""

    fun isLoggedIn(context: Context): Boolean = token(context).isNotBlank()

    fun user(context: Context): JSONObject {
        val raw = prefs(context).getString(KEY_USER, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun saveAuth(context: Context, token: String, user: JSONObject) {
        prefs(context).edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER, user.toString())
            .apply()
    }

    fun updateUser(context: Context, user: JSONObject) {
        prefs(context).edit().putString(KEY_USER, user.toString()).apply()
    }

    fun clear(context: Context) {
        prefs(context).edit()
            .remove(KEY_TOKEN)
            .remove(KEY_USER)
            .remove(KEY_REMOVED_WATCHLIST)
            .remove(KEY_LAST_SYNC)
            .apply()
    }

    fun username(context: Context): String = user(context).optString("username")

    fun email(context: Context): String = user(context).optString("email")

    fun authBackground(context: Context): String = prefs(context).getString(KEY_AUTH_BACKGROUND, "") ?: ""

    fun setAuthBackground(context: Context, url: String) {
        if (url.isNotBlank()) prefs(context).edit().putString(KEY_AUTH_BACKGROUND, url).apply()
    }

    fun removedWatchlistKeys(context: Context): MutableSet<String> {
        val raw = prefs(context).getString(KEY_REMOVED_WATCHLIST, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val result = linkedSetOf<String>()
        for (i in 0 until array.length()) {
            array.optString(i).takeIf { it.isNotBlank() }?.let(result::add)
        }
        return result
    }

    fun markWatchlistAdded(context: Context, storageKey: String) {
        val keys = removedWatchlistKeys(context)
        if (keys.remove(storageKey)) saveRemovedWatchlistKeys(context, keys)
    }

    fun markWatchlistRemoved(context: Context, storageKey: String) {
        val keys = removedWatchlistKeys(context)
        keys.add(storageKey)
        saveRemovedWatchlistKeys(context, keys)
    }

    fun clearRemovedWatchlistKeys(context: Context) {
        prefs(context).edit().remove(KEY_REMOVED_WATCHLIST).apply()
    }

    private fun saveRemovedWatchlistKeys(context: Context, keys: Set<String>) {
        val array = JSONArray()
        keys.forEach(array::put)
        prefs(context).edit().putString(KEY_REMOVED_WATCHLIST, array.toString()).apply()
    }

    fun lastWatchlistSync(context: Context): Long = prefs(context).getLong(KEY_LAST_SYNC, 0L)

    fun markWatchlistSynced(context: Context) {
        prefs(context).edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).apply()
    }
}
