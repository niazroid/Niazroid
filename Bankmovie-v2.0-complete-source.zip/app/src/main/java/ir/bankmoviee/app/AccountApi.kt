package ir.bankmoviee.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object AccountApi {
    data class Result(
        val success: Boolean,
        val json: JSONObject? = null,
        val message: String = "",
        val statusCode: Int = 0
    )

    private const val APP_KEY = "bm_android_v1_7c2f40"
    private val APP_SECRET = listOf(
        "9e1d4a7b3167f4c9",
        "b2d83f0a64e597f3",
        "d7f4b1a72638f90c",
        "6e2f2bd29d6aa8c1"
    ).joinToString("")

    private const val SMART_PREFS = "bm_smart_cinema"
    private const val FAVORITES_KEY = "favorites"
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var clockOffsetSec = 0L
    @Volatile private var syncRunning = false

    private fun domain(context: Context): String {
        val configured = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString("active_domain", "")
            .orEmpty()
            .trim()
        val base = configured.ifBlank { AppConfig.BASE_URL }
        return base.trimEnd('/')
    }

    private fun endpoint(context: Context, action: String): String {
        return "${domain(context)}/app_user_api.php?action=${URLEncoder.encode(action, "UTF-8")}" 
    }

    private fun hmacSha256Hex(value: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(APP_SECRET.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(value.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    }

    private fun parseMessage(json: JSONObject?, fallback: String): String {
        return json?.optString("message")
            ?.takeIf { it.isNotBlank() }
            ?: json?.optString("error")?.takeIf { it.isNotBlank() }
            ?: fallback
    }

    private fun requestBlocking(
        context: Context,
        action: String,
        method: String = "GET",
        body: JSONObject? = null,
        requireToken: Boolean = false
    ): Result {
        val token = AccountSession.token(context)
        if (requireToken && token.isBlank()) return Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401)

        var last = Result(false, message = "خطا در اتصال به سرور")
        repeat(2) { attempt ->
            var connection: HttpURLConnection? = null
            try {
                val url = URL(endpoint(context, action))
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 12000
                    readTimeout = 18000
                    instanceFollowRedirects = true
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("User-Agent", "BankmovieAndroidNative/2.0-Account")
                    setRequestProperty("Cache-Control", "no-cache")
                    val timestamp = (System.currentTimeMillis() / 1000L + clockOffsetSec).toString()
                    val pathQuery = url.path + if (url.query.isNullOrBlank()) "" else "?${url.query}"
                    setRequestProperty("X-BM-App-Key", APP_KEY)
                    setRequestProperty("X-BM-Ts", timestamp)
                    setRequestProperty("X-BM-Sign", hmacSha256Hex("$timestamp|$pathQuery"))
                    if (token.isNotBlank()) {
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("X-BM-User-Token", token)
                    }
                    if (method == "POST") doOutput = true
                }

                if (method == "POST") {
                    val bytes = (body ?: JSONObject()).toString().toByteArray(Charsets.UTF_8)
                    connection.setFixedLengthStreamingMode(bytes.size)
                    connection.outputStream.use { it.write(bytes) }
                }

                val code = connection.responseCode
                connection.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let { serverDate ->
                    clockOffsetSec = serverDate / 1000L - System.currentTimeMillis() / 1000L
                }
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = runCatching { if (text.isBlank()) JSONObject() else JSONObject(text) }.getOrNull()
                val ok = code in 200..299 && (json?.optBoolean("success", true) != false)
                last = Result(
                    success = ok,
                    json = json,
                    message = parseMessage(json, if (ok) "" else "خطای ارتباط با حساب کاربری"),
                    statusCode = code
                )
                if (ok || code != 401 || attempt > 0) return last
            } catch (_: Throwable) {
                last = Result(false, message = "اتصال به سرور برقرار نشد")
            } finally {
                runCatching { connection?.disconnect() }
            }
        }
        return last
    }

    private fun run(callback: (Result) -> Unit, block: () -> Result) {
        Thread {
            val result = runCatching(block).getOrElse { Result(false, message = "خطای غیرمنتظره") }
            mainHandler.post { callback(result) }
        }.start()
    }

    fun loadConfig(context: Context, callback: (Result) -> Unit = {}) {
        run(callback) {
            val result = requestBlocking(context, "config")
            result.json?.optString("background_url")?.takeIf { it.isNotBlank() }?.let {
                AccountSession.setAuthBackground(context, it)
            }
            result
        }
    }

    fun login(context: Context, identity: String, password: String, callback: (Result) -> Unit) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "login",
                method = "POST",
                body = JSONObject().apply {
                    put("identity", identity.trim())
                    put("password", password)
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                if (token.isNotBlank()) AccountSession.saveAuth(context, token, user)
            }
            result
        }
    }

    fun register(
        context: Context,
        username: String,
        email: String,
        password: String,
        confirmPassword: String,
        callback: (Result) -> Unit
    ) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "register",
                method = "POST",
                body = JSONObject().apply {
                    put("username", username.trim())
                    put("email", email.trim())
                    put("password", password)
                    put("confirm_password", confirmPassword)
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                if (token.isNotBlank()) AccountSession.saveAuth(context, token, user)
            }
            result
        }
    }

    fun refreshMe(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "me", requireToken = true)
            if (result.success) {
                result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            } else if (result.statusCode == 401) {
                AccountSession.clear(context)
            }
            result
        }
    }

    fun logout(context: Context, callback: (Result) -> Unit = {}) {
        val hadSession = AccountSession.isLoggedIn(context)
        if (!hadSession) {
            AccountSession.clear(context)
            callback(Result(true))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "logout", method = "POST", body = JSONObject(), requireToken = true)
            AccountSession.clear(context)
            result.copy(success = true)
        }
    }

    private fun localFavorites(context: Context): JSONArray {
        val raw = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString(FAVORITES_KEY, "[]") ?: "[]"
        return runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
    }

    private fun saveFavorites(context: Context, array: JSONArray) {
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(FAVORITES_KEY, array.toString())
            .apply()
    }

    fun syncWatchlist(context: Context, force: Boolean = false, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        if (!force && System.currentTimeMillis() - AccountSession.lastWatchlistSync(context) < 20_000L) {
            callback(Result(true, message = ""))
            return
        }
        synchronized(this) {
            if (syncRunning) {
                callback(Result(true, message = ""))
                return
            }
            syncRunning = true
        }

        run({ result ->
            syncRunning = false
            callback(result)
        }) {
            val removed = JSONArray()
            AccountSession.removedWatchlistKeys(context).forEach(removed::put)
            val result = requestBlocking(
                context = context,
                action = "watchlist_sync",
                method = "POST",
                body = JSONObject().apply {
                    put("items", localFavorites(context))
                    put("removed_keys", removed)
                },
                requireToken = true
            )
            if (result.success) {
                val items = result.json?.optJSONArray("items") ?: JSONArray()
                saveFavorites(context, items)
                AccountSession.clearRemovedWatchlistKeys(context)
                AccountSession.markWatchlistSynced(context)
            } else if (result.statusCode == 401) {
                AccountSession.clear(context)
            }
            result
        }
    }
}
