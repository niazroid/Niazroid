<?php
/**
 * app_user_api.php — API حساب کاربری و واچ‌لیست اپ BankMovie
 *
 * POST actions:
 *   login, register, logout, watchlist_sync
 * GET/POST actions:
 *   config, me, watchlist_list
 */

declare(strict_types=1);

@ini_set('display_errors', '0');
@ini_set('log_errors', '1');

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-BM-App-Key, X-BM-Ts, X-BM-Sign, X-BM-User-Token');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

const BM_USER_APP_KEY = 'bm_android_v1_7c2f40';
const BM_USER_APP_SECRET = '9e1d4a7b3167f4c9b2d83f0a64e597f3d7f4b1a72638f90c6e2f2bd29d6aa8c1';

function bm_user_api_json(array $data, int $status = 200): never {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_user_api_error(string $message, int $status = 400, array $extra = []): never {
    bm_user_api_json(array_merge([
        'status' => 'error',
        'success' => false,
        'message' => $message,
    ], $extra), $status);
}

function bm_user_api_header(string $name): string {
    $serverKey = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return trim((string)($_SERVER[$serverKey] ?? ''));
}

function bm_user_api_require_app_signature(): void {
    $key = bm_user_api_header('X-BM-App-Key');
    $ts = bm_user_api_header('X-BM-Ts');
    $signature = bm_user_api_header('X-BM-Sign');

    if (!hash_equals(BM_USER_APP_KEY, $key) || $ts === '' || $signature === '') {
        bm_user_api_error('Unauthorized', 401);
    }

    $timestamp = (int)$ts;
    if ($timestamp < time() - 900 || $timestamp > time() + 900) {
        bm_user_api_error('Expired request', 401);
    }

    $requestUri = (string)($_SERVER['REQUEST_URI'] ?? '');
    $path = (string)(parse_url($requestUri, PHP_URL_PATH) ?: '');
    $query = (string)(parse_url($requestUri, PHP_URL_QUERY) ?: '');
    $pathQuery = $path . ($query !== '' ? ('?' . $query) : '');
    $expected = hash_hmac('sha256', $ts . '|' . $pathQuery, BM_USER_APP_SECRET);

    if (!hash_equals($expected, $signature)) {
        bm_user_api_error('Bad signature', 401);
    }
}

bm_user_api_require_app_signature();
require_once __DIR__ . '/config.php';

function bm_user_api_body(): array {
    static $body = null;
    if (is_array($body)) return $body;

    $raw = file_get_contents('php://input');
    $decoded = is_string($raw) && trim($raw) !== '' ? json_decode($raw, true) : null;
    $body = is_array($decoded) ? $decoded : $_POST;
    return $body;
}

function bm_user_api_param(string $key, mixed $default = ''): mixed {
    $body = bm_user_api_body();
    if (array_key_exists($key, $body)) return $body[$key];
    if (array_key_exists($key, $_GET)) return $_GET[$key];
    return $default;
}

function bm_user_api_action(): string {
    return strtolower(trim((string)bm_user_api_param('action', $_GET['action'] ?? '')));
}

function bm_user_api_require_post(): void {
    if (strtoupper((string)($_SERVER['REQUEST_METHOD'] ?? 'GET')) !== 'POST') {
        bm_user_api_error('POST required', 405);
    }
}

function bm_user_api_bearer(): string {
    $direct = bm_user_api_header('X-BM-User-Token');
    if ($direct !== '') return $direct;
    $authorization = bm_user_api_header('Authorization');
    if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) {
        return trim((string)$m[1]);
    }
    return trim((string)bm_user_api_param('token', ''));
}

function bm_user_api_current_user(PDO $pdo, bool $required = true): array|false {
    $token = bm_user_api_bearer();
    $user = (new User($pdo))->checkSession($token);
    if (!$user && $required) bm_user_api_error('Please login', 401);
    return $user ?: false;
}

function bm_user_api_public_user(array $user): array {
    $avatar = trim((string)($user['avatar'] ?? ''));
    if ($avatar !== '' && !preg_match('~^https?://~i', $avatar)) {
        $avatar = rtrim((string)SITE_URL, '/') . '/' . ltrim($avatar, '/');
    }
    return [
        'id' => (int)($user['id'] ?? 0),
        'username' => (string)($user['username'] ?? ''),
        'email' => (string)($user['email'] ?? ''),
        'full_name' => (string)($user['full_name'] ?? ''),
        'avatar' => $avatar,
        'role' => (string)($user['role'] ?? 'user'),
        'status' => (string)($user['status'] ?? 'active'),
        'theme' => (string)($user['theme'] ?? 'dark-green'),
        'language' => (string)($user['language'] ?? 'fa'),
        'created_at' => (string)($user['created_at'] ?? ''),
    ];
}

function bm_user_api_issue_token(PDO $pdo, int $userId): string {
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 30 * 86400);
    $stmt = $pdo->prepare('INSERT INTO user_sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)');
    $stmt->execute([$userId, $token, $expires]);
    return $token;
}

function bm_user_api_ensure_watchlist(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS app_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        storage_key VARCHAR(190) NOT NULL,
        archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
        item_type VARCHAR(24) NOT NULL DEFAULT 'movie',
        item_id VARCHAR(190) NOT NULL DEFAULT '',
        db_movie_id INT UNSIGNED NULL,
        imdb_code VARCHAR(32) NULL,
        title VARCHAR(300) NOT NULL DEFAULT '',
        title_fa VARCHAR(300) NOT NULL DEFAULT '',
        poster VARCHAR(700) NULL,
        year_value VARCHAR(16) NULL,
        rating_value DECIMAL(4,1) NULL,
        source_url VARCHAR(700) NULL,
        payload_json MEDIUMTEXT NULL,
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_app_watchlist_user_key (user_id, storage_key),
        KEY idx_app_watchlist_user_added (user_id, added_at),
        KEY idx_app_watchlist_db_movie (db_movie_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        item_link VARCHAR(500) NOT NULL,
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_link (user_id, item_link(200)),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function bm_user_api_normalize_type(string $type): string {
    $type = strtolower(trim($type));
    if (in_array($type, ['tv', 'tvseries'], true)) return 'series';
    if ($type === '') return 'movie';
    return substr($type, 0, 24);
}

function bm_user_api_abs_url(string $value): string {
    $value = trim($value);
    if ($value === '') return '';
    if (str_starts_with($value, '//')) return 'https:' . $value;
    if (preg_match('~^https?://~i', $value)) return $value;
    return rtrim((string)SITE_URL, '/') . '/' . ltrim($value, '/');
}

function bm_user_api_storage_key(array $item): string {
    $key = trim((string)($item['_key'] ?? $item['storage_key'] ?? ''));
    if ($key !== '') return substr($key, 0, 190);

    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $id = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? $item['imdb_code'] ?? ''));
    if ($id === '') {
        $id = substr(hash('sha256', (string)($item['title_fa'] ?? '') . '|' . (string)($item['title'] ?? '') . '|' . (string)($item['poster'] ?? '')), 0, 40);
    }
    return substr($archive . '|' . $type . '|' . $id, 0, 190);
}

function bm_user_api_legacy_archive1_link(array $item): string {
    foreach (['web_url_abs', 'source_url', 'item_link', 'web_url'] as $field) {
        $value = trim((string)($item[$field] ?? ''));
        if ($value !== '') return bm_user_api_abs_url($value);
    }
    $id = trim((string)($item['id'] ?? $item['slug'] ?? ''));
    if ($id === '') return '';
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    return rtrim((string)SITE_URL, '/') . '/movie.php?arc=1&slug=' . rawurlencode($id) . '&type=' . rawurlencode($type);
}

function bm_user_api_upsert_app_item(PDO $pdo, int $userId, array $item): void {
    $storageKey = bm_user_api_storage_key($item);
    $archive = max(1, min(9, (int)($item['archive'] ?? 1)));
    $type = bm_user_api_normalize_type((string)($item['type'] ?? 'movie'));
    $itemId = trim((string)($item['id'] ?? $item['movie_id'] ?? $item['slug'] ?? ''));
    $dbMovieId = (int)($item['db_id'] ?? (($archive === 2 && ctype_digit($itemId)) ? $itemId : 0));
    $imdb = trim((string)($item['imdb_code'] ?? ''));
    $title = trim((string)($item['title'] ?? ''));
    $titleFa = trim((string)($item['title_fa'] ?? $title));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $poster = bm_user_api_abs_url((string)($item['poster'] ?? ''));
    $year = trim((string)($item['year'] ?? ''));
    $ratingRaw = $item['rating'] ?? null;
    $rating = is_numeric($ratingRaw) ? (float)$ratingRaw : null;
    $sourceUrl = bm_user_api_abs_url((string)($item['source_url'] ?? $item['web_url_abs'] ?? $item['web_url'] ?? ''));
    $payload = $item;
    $payload['_key'] = $storageKey;
    $payload['archive'] = $archive;
    $payload['type'] = $type;
    $payload['id'] = $itemId;
    $payload['poster'] = $poster;
    if ($sourceUrl !== '') $payload['source_url'] = $sourceUrl;

    $stmt = $pdo->prepare("INSERT INTO app_watchlist
        (user_id, storage_key, archive_no, item_type, item_id, db_movie_id, imdb_code, title, title_fa, poster, year_value, rating_value, source_url, payload_json, added_at, updated_at)
        VALUES (?, ?, ?, ?, ?, NULLIF(?,0), NULLIF(?,''), ?, ?, NULLIF(?,''), NULLIF(?,''), ?, NULLIF(?,''), ?, NOW(), NOW())
        ON DUPLICATE KEY UPDATE
            archive_no=VALUES(archive_no), item_type=VALUES(item_type), item_id=VALUES(item_id),
            db_movie_id=VALUES(db_movie_id), imdb_code=VALUES(imdb_code), title=VALUES(title), title_fa=VALUES(title_fa),
            poster=VALUES(poster), year_value=VALUES(year_value), rating_value=VALUES(rating_value),
            source_url=VALUES(source_url), payload_json=VALUES(payload_json), updated_at=NOW()");
    $stmt->execute([
        $userId, $storageKey, $archive, $type, $itemId, $dbMovieId, $imdb, $title, $titleFa,
        $poster, $year, $rating, $sourceUrl,
        json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    ]);

    // Mirror app changes to the website's existing watchlist tables.
    if ($archive === 2 && $dbMovieId > 0) {
        $check = $pdo->prepare('SELECT id FROM movies WHERE id = ? LIMIT 1');
        $check->execute([$dbMovieId]);
        if ($check->fetchColumn()) {
            $mirror = $pdo->prepare('INSERT IGNORE INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, NOW())');
            $mirror->execute([$userId, $dbMovieId]);
        }
    } elseif ($archive === 1) {
        $link = bm_user_api_legacy_archive1_link($item);
        if ($link !== '') {
            $mirror = $pdo->prepare("INSERT INTO archive1_watchlist
                (user_id, item_link, item_title, item_title_fa, item_year, item_poster, item_imdb_rate, item_type, added_at)
                VALUES (?, ?, ?, ?, NULLIF(?,''), NULLIF(?,''), ?, ?, NOW())
                ON DUPLICATE KEY UPDATE item_title=VALUES(item_title), item_title_fa=VALUES(item_title_fa),
                    item_year=VALUES(item_year), item_poster=VALUES(item_poster), item_imdb_rate=VALUES(item_imdb_rate), item_type=VALUES(item_type)");
            $mirror->execute([$userId, $link, $title, $titleFa, $year, $poster, $rating, $type]);
        }
    }
}

function bm_user_api_remove_app_item(PDO $pdo, int $userId, string $storageKey): void {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? AND storage_key = ? LIMIT 1');
    $stmt->execute([$userId, $storageKey]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;

    $delete = $pdo->prepare('DELETE FROM app_watchlist WHERE user_id = ? AND storage_key = ?');
    $delete->execute([$userId, $storageKey]);

    if (!$row) return;
    $archive = (int)($row['archive_no'] ?? 0);
    if ($archive === 2 && (int)($row['db_movie_id'] ?? 0) > 0) {
        $mirror = $pdo->prepare('DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?');
        $mirror->execute([$userId, (int)$row['db_movie_id']]);
    } elseif ($archive === 1) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        $link = is_array($payload) ? bm_user_api_legacy_archive1_link($payload) : trim((string)($row['source_url'] ?? ''));
        if ($link !== '') {
            $mirror = $pdo->prepare('DELETE FROM archive1_watchlist WHERE user_id = ? AND item_link = ?');
            $mirror->execute([$userId, $link]);
        }
    }
}

function bm_user_api_import_legacy(PDO $pdo, int $userId): void {
    // Database/archive 2 watchlist.
    try {
        $stmt = $pdo->prepare('SELECT m.* FROM watchlist w JOIN movies m ON w.movie_id = m.id WHERE w.user_id = ? ORDER BY w.added_at ASC');
        $stmt->execute([$userId]);
        while ($movie = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $id = (string)(int)($movie['id'] ?? 0);
            if ($id === '0') continue;
            $imdb = trim((string)($movie['imdb_code'] ?? ''));
            $poster = trim((string)($movie['poster'] ?? ''));
            if ($poster === '' && $imdb !== '') $poster = 'posters/' . $imdb . '.webp';
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '2|' . bm_user_api_normalize_type((string)($movie['type'] ?? 'movie')) . '|' . $id,
                'archive' => 2,
                'id' => $id,
                'db_id' => (int)$id,
                'imdb_code' => $imdb,
                'type' => (string)($movie['type'] ?? 'movie'),
                'title' => (string)($movie['title'] ?? ''),
                'title_fa' => (string)($movie['title_fa'] ?? $movie['title'] ?? ''),
                'poster' => $poster,
                'year' => (string)($movie['year'] ?? ''),
                'rating' => $movie['imdb_rate'] ?? null,
                'source_url' => (string)($movie['source_url'] ?? ''),
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy db watchlist import: ' . $e->getMessage());
    }

    // Archive 1 website watchlist.
    try {
        $stmt = $pdo->prepare('SELECT * FROM archive1_watchlist WHERE user_id = ? ORDER BY added_at ASC');
        $stmt->execute([$userId]);
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $link = trim((string)($row['item_link'] ?? ''));
            if ($link === '') continue;
            $id = '';
            $parts = parse_url($link);
            if (!empty($parts['query'])) {
                parse_str((string)$parts['query'], $query);
                $id = trim((string)($query['slug'] ?? $query['id'] ?? ''));
            }
            if ($id === '' && preg_match('~/movie/arc1-([^/?#]+)~i', $link, $m)) $id = rawurldecode($m[1]);
            if ($id === '') {
                $path = trim((string)($parts['path'] ?? ''), '/');
                if ($path !== '') $id = rawurldecode((string)basename($path));
            }
            if ($id === '') $id = substr(hash('sha256', $link), 0, 32);
            $type = bm_user_api_normalize_type((string)($row['item_type'] ?? 'movie'));
            bm_user_api_upsert_app_item($pdo, $userId, [
                '_key' => '1|' . $type . '|' . $id,
                'archive' => 1,
                'id' => $id,
                'type' => $type,
                'title' => (string)($row['item_title'] ?? ''),
                'title_fa' => (string)($row['item_title_fa'] ?? $row['item_title'] ?? ''),
                'poster' => (string)($row['item_poster'] ?? ''),
                'year' => (string)($row['item_year'] ?? ''),
                'rating' => $row['item_imdb_rate'] ?? null,
                'source_url' => $link,
                'web_url_abs' => $link,
            ]);
        }
    } catch (Throwable $e) {
        error_log('app_user_api legacy archive1 watchlist import: ' . $e->getMessage());
    }
}

function bm_user_api_watchlist_items(PDO $pdo, int $userId): array {
    $stmt = $pdo->prepare('SELECT * FROM app_watchlist WHERE user_id = ? ORDER BY updated_at DESC, id DESC LIMIT 500');
    $stmt->execute([$userId]);
    $items = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        if (!is_array($payload)) $payload = [];
        $payload['_key'] = (string)$row['storage_key'];
        $payload['archive'] = (int)$row['archive_no'];
        $payload['type'] = (string)$row['item_type'];
        $payload['id'] = (string)$row['item_id'];
        if (!empty($row['db_movie_id'])) $payload['db_id'] = (int)$row['db_movie_id'];
        if (!empty($row['imdb_code'])) $payload['imdb_code'] = (string)$row['imdb_code'];
        $payload['title'] = (string)$row['title'];
        $payload['title_fa'] = (string)$row['title_fa'];
        $payload['poster'] = (string)($row['poster'] ?? '');
        $payload['year'] = (string)($row['year_value'] ?? '');
        if ($row['rating_value'] !== null) $payload['rating'] = (float)$row['rating_value'];
        if (!empty($row['source_url'])) $payload['source_url'] = (string)$row['source_url'];
        $payload['_saved_at'] = strtotime((string)$row['updated_at']) * 1000;
        $items[] = $payload;
    }
    return $items;
}

function bm_user_api_stats(PDO $pdo, int $userId): array {
    bm_user_api_ensure_watchlist($pdo);
    $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_watchlist WHERE user_id = ?');
    $stmt->execute([$userId]);
    return ['watchlist' => (int)$stmt->fetchColumn()];
}

$action = bm_user_api_action();

try {
    if ($action === 'config') {
        $bgRelative = is_file(__DIR__ . '/uploads/poste.webp') ? 'uploads/poste.webp' : (is_file(__DIR__ . '/poste.webp') ? 'poste.webp' : '');
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'background_url' => $bgRelative !== '' ? rtrim((string)SITE_URL, '/') . '/' . $bgRelative : '',
            'login_identifier' => 'username_or_email',
            'registration_email_required' => true,
            'forgot_password_enabled' => false,
        ]);
    }

    if ($action === 'login') {
        bm_user_api_require_post();
        $identity = trim((string)bm_user_api_param('identity', bm_user_api_param('username', '')));
        $password = (string)bm_user_api_param('password', '');
        if ($identity === '' || $password === '') bm_user_api_error('نام کاربری یا ایمیل و رمز عبور را وارد کنید');

        $stmt = $pdo->prepare('SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$identity, $identity]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$userRow || !password_verify($password, (string)$userRow['password'])) {
            bm_user_api_error('نام کاربری یا رمز عبور اشتباه است', 401);
        }
        if ((string)($userRow['status'] ?? 'active') !== 'active') {
            bm_user_api_error('حساب کاربری شما فعال نیست', 403);
        }

        $token = bm_user_api_issue_token($pdo, (int)$userRow['id']);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
        ]);
    }

    if ($action === 'register') {
        bm_user_api_require_post();
        $username = trim((string)bm_user_api_param('username', ''));
        $email = strtolower(trim((string)bm_user_api_param('email', '')));
        $password = (string)bm_user_api_param('password', '');
        $confirm = (string)bm_user_api_param('confirm_password', '');

        if (mb_strlen($username, 'UTF-8') < 3 || mb_strlen($username, 'UTF-8') > 40) {
            bm_user_api_error('نام کاربری باید بین ۳ تا ۴۰ کاراکتر باشد');
        }
        if (!preg_match('/^[\p{L}\p{N}_.-]+$/u', $username)) {
            bm_user_api_error('نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه، خط تیره و زیرخط باشد');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
            bm_user_api_error('ایمیل معتبر وارد کنید');
        }
        if (strlen($password) < 8) bm_user_api_error('رمز عبور باید حداقل ۸ کاراکتر باشد');
        if (!hash_equals($password, $confirm)) bm_user_api_error('رمز عبور و تکرار آن یکسان نیست');

        $stmt = $pdo->prepare('SELECT id, username, email FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $email]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            if (strcasecmp((string)$existing['email'], $email) === 0) bm_user_api_error('این ایمیل قبلاً ثبت شده است', 409);
            bm_user_api_error('این نام کاربری قبلاً ثبت شده است', 409);
        }

        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())");
        $stmt->execute([$username, $email, $hash]);
        $userId = (int)$pdo->lastInsertId();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
        $stmt->execute([$userId]);
        $userRow = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['id' => $userId, 'username' => $username, 'email' => $email, 'status' => 'active', 'role' => 'user'];
        $token = bm_user_api_issue_token($pdo, $userId);
        bm_user_api_ensure_watchlist($pdo);

        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'message' => 'ثبت‌نام با موفقیت انجام شد',
            'token' => $token,
            'user' => bm_user_api_public_user($userRow),
            'stats' => ['watchlist' => 0],
        ], 201);
    }

    if ($action === 'me') {
        $userRow = bm_user_api_current_user($pdo, true);
        $token = bm_user_api_bearer();
        $extend = $pdo->prepare('UPDATE user_sessions SET expires_at = ? WHERE session_token = ?');
        $extend->execute([date('Y-m-d H:i:s', time() + 30 * 86400), $token]);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'user' => bm_user_api_public_user($userRow),
            'stats' => bm_user_api_stats($pdo, (int)$userRow['id']),
        ]);
    }

    if ($action === 'logout') {
        bm_user_api_require_post();
        $token = bm_user_api_bearer();
        if ($token !== '') {
            $stmt = $pdo->prepare('DELETE FROM user_sessions WHERE session_token = ?');
            $stmt->execute([$token]);
        }
        bm_user_api_json(['status' => 'ok', 'success' => true]);
    }

    if ($action === 'watchlist_list') {
        $userRow = bm_user_api_current_user($pdo, true);
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, (int)$userRow['id']);
        $items = bm_user_api_watchlist_items($pdo, (int)$userRow['id']);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $items,
            'count' => count($items),
        ]);
    }

    if ($action === 'watchlist_sync') {
        bm_user_api_require_post();
        $userRow = bm_user_api_current_user($pdo, true);
        $userId = (int)$userRow['id'];
        bm_user_api_ensure_watchlist($pdo);
        bm_user_api_import_legacy($pdo, $userId);

        $body = bm_user_api_body();
        $removed = is_array($body['removed_keys'] ?? null) ? $body['removed_keys'] : [];
        $items = is_array($body['items'] ?? null) ? $body['items'] : [];

        $pdo->beginTransaction();
        try {
            foreach (array_slice($removed, 0, 500) as $key) {
                $key = substr(trim((string)$key), 0, 190);
                if ($key !== '') bm_user_api_remove_app_item($pdo, $userId, $key);
            }
            foreach (array_slice($items, 0, 500) as $item) {
                if (is_array($item)) bm_user_api_upsert_app_item($pdo, $userId, $item);
            }
            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }

        $merged = bm_user_api_watchlist_items($pdo, $userId);
        bm_user_api_json([
            'status' => 'ok',
            'success' => true,
            'items' => $merged,
            'count' => count($merged),
        ]);
    }

    bm_user_api_error('Unknown action', 404);
} catch (PDOException $e) {
    error_log('app_user_api database error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت پایگاه داده', 500);
} catch (Throwable $e) {
    error_log('app_user_api error: ' . $e->getMessage());
    bm_user_api_error('خطای موقت سرور', 500);
}
