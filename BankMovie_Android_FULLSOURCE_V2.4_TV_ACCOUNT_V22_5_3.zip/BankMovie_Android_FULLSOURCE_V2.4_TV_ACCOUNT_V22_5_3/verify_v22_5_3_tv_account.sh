#!/usr/bin/env bash
# V22.5.3 static regression checks: TV overscan, responsive columns and secured profile edits.
# Run without production DB; compile and device checks remain the CI/build steps.
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_user_api.php >/dev/null
php -l server-required/v2/api/bm_security.php >/dev/null
php -l SITE_PATCH_REQUIRED/app_user_api.php >/dev/null
node --check app/src/main/assets/bm_discover_app.js >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=Path('app/src/main/java/ir/bankmoviee/app/AccountApi.kt').read_text()
s=Path('server-required/app_user_api.php').read_text()
q=Path('server-required/v2/api/bm_security.php').read_text()
assert 'private fun tvPosterUsableWidth()' in m
assert 'private fun tvGridColumns(): Int {' in m
assert '(available / dp(132)).coerceIn(1, 8)' in m
assert 'tvSideNavCollapsedWidth() - 2 * safeEdge' in m
assert 'private fun tvPosterGridInsets(grid: GridLayout)' in m
assert 'columnCount = if (tv) 8 else 3' not in m
assert 'tvGridOrderedItems(items, grid.columnCount)' in m
assert 'collectionGridLoadingSkeleton(if (tv) tvGridColumns() else 3' in m
assert 'if (tvList) tvPosterGridInsets(grid)' in m
assert 'if (tv) tvPosterGridInsets(grid)' in m
assert 'showAccountSecurityDialog(false)' in m and 'showAccountSecurityDialog(true)' in m
assert 'if (logged) {' in m[m.index('val actionItems = mutableListOf<View>('):m.index('actionItems.forEachIndexed')]
for key in ('changeUsername(', 'changePassword(', 'requireToken = true', 'quotaIntent = "account_edit"'):
    assert key in a, key
assert 'AccountSession.saveAuth(context, fresh, user, AccountSession.stats(context))' in a
assert 'val fresh = result.json?.optString("token")' in a
for key in ('update_username', 'change_password', 'bm_user_api_current_user($pdo, true)',
            'bm_user_api_require_post()', 'password_verify($oldPassword',
            'password_hash($newPassword, PASSWORD_DEFAULT)',
            'DELETE FROM user_sessions WHERE user_id = ?',
            'SELECT password FROM users WHERE id = ? FOR UPDATE',
            'bm_user_api_issue_token($pdo, $userId)',
            'bm_user_api_public_user('):
    assert key in s, key
for k in ('update_username','change_password'):
    assert k in q, k
# Model the same DP geometry as the implementation across 720p, 1080p,
# high-density TV boxes, low-resolution panels and narrow display modes.
for px, density in ((1280,1.),(1280,1.5),(1920,1.),(1920,1.5),(1920,2.),(960,1.25),(720,1.5),(480,1.),(3840,2.)):
    dp=lambda v: round(v*density)
    safe=max(round(px*.035), dp(20))
    usable=max(px-dp(76)-2*safe-dp(54),dp(110))
    columns=min(8,max(1,usable//dp(132)))
    width=max((usable-dp(20))//columns-dp(14),dp(64))
    total=columns*(width+dp(14))+dp(20)
    assert 1<=columns<=8 and total<=usable, (px,density,columns,total,usable)
print('VERIFY_V22_5_3_TV_ACCOUNT_OK')
PYTEST
