import 'package:flutter_test/flutter_test.dart';
import 'package:fl_clash/common/gohst_display_name.dart';

void main() {
  test('percent encoded country flags and labels are readable', () {
    expect(gohstDisplayName('%F0%9F%87%AB%F0%9F%87%AE%20FNL%20%7C%20FAST%204'), '🇫🇮 FNL | FAST 4');
  });
  test('already decoded labels are not modified', () {
    expect(gohstDisplayName('🇩🇪 Germany 1'), '🇩🇪 Germany 1');
  });
  test('malformed percent input does not crash the display', () {
    expect(gohstDisplayName('node%ZZ'), 'node%ZZ');
  });
}
