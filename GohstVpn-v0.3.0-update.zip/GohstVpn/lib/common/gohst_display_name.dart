/// Display-only normalization of names from percent-encoded V2Ray fragments.
/// Do not use this as a proxy identity: selection and favorites keep raw keys.
String gohstDisplayName(String name) {
  var value = name.trim();
  for (var i = 0; i < 2; i++) {
    if (!RegExp(r'%[0-9a-fA-F]{2}').hasMatch(value)) break;
    try {
      final decoded = Uri.decodeComponent(value);
      if (decoded == value) break;
      value = decoded;
    } on FormatException {
      break;
    }
  }
  return value.replaceAll(RegExp(r'[\u0000-\u001F\u007F]'), ' ').trim();
}
