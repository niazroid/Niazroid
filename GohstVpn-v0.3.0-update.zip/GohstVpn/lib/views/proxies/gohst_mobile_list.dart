import 'package:flutter/material.dart' as m;
import 'package:fl_clash/common/gohst_subscription_notice.dart';
import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'card.dart';

/// V2Box-inspired presentation, backed by the existing Mihomo proxy state.
/// Group headers and node rows share the same scroll, without a two-column grid.
class GohstMobileServersList extends ConsumerWidget {
  const GohstMobileServersList({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    GohstSubscriptionNotice.instance.ensureLoaded();
    final profile = ref.watch(currentProfileProvider);
    final state = ref.watch(proxiesTabStateProvider);
    final rows = <({Group group, Proxy? proxy})>[
      for (final group in state.groups) ...[
        (group: group, proxy: null),
        for (final proxy in group.all) (group: group, proxy: proxy),
      ],
    ];
    if (rows.isEmpty) {
      return Center(child: Text(context.appLocalizations.nullTip(context.appLocalizations.proxies)));
    }
    return ValueListenableBuilder<Map<int, String>>(
      valueListenable: GohstSubscriptionNotice.instance.notices,
      builder: (context, notices, _) {
        final notice = profile == null ? null : notices[profile.id];
        return Column(
          children: [
            if (notice != null && notice.isNotEmpty)
              Padding(
                padding: EdgeInsets.fromLTRB(14, 12 + context.contentTopPadding, 14, 0),
                child: Card(
                  child: InkWell(
                    onTap: () => m.showDialog<void>(
                      context: context,
                      builder: (dialogContext) => m.AlertDialog(
                        title: const Text('Announcement'),
                        content: m.SelectableText(notice),
                        actions: [
                          m.TextButton(
                            onPressed: () => m.Navigator.pop(dialogContext),
                            child: const Text('OK'),
                          ),
                        ],
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(14),
                      child: Row(children: [
                        m.Icon(m.Icons.campaign_outlined, color: context.colorScheme.primary),
                        const SizedBox(width: 12),
                        Expanded(child: Text(notice, maxLines: 3, overflow: TextOverflow.ellipsis)),
                        const SizedBox(width: 6),
                        const m.Icon(m.Icons.chevron_right, size: 18),
                      ]),
                    ),
                  ),
                ),
              ),
            Expanded(
              child: ListView.builder(
                padding: EdgeInsets.fromLTRB(14, notice == null || notice.isEmpty ? 12 + context.contentTopPadding : 12,
                  14, 16 + BottomInsetScope.of(context)),
                itemCount: rows.length,
                itemBuilder: (context, index) {
                  final row = rows[index];
                  if (row.proxy == null) {
                    return Padding(
                      padding: const EdgeInsets.fromLTRB(6, 16, 6, 10),
                      child: Row(children: [
                        Expanded(child: Text(row.group.name, style: context.textTheme.titleSmall?.toSoftBold,
                          maxLines: 1, overflow: TextOverflow.ellipsis)),
                        Text('${row.group.all.length}', style: context.textTheme.labelMedium),
                      ]),
                    );
                  }
                  final proxy = row.proxy!;
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: SizedBox(
                      height: 82,
                      child: ProxyCard(
                        key: ValueKey('gohst-list:${row.group.name}:${proxy.name}'),
                        groupName: row.group.name,
                        groupType: row.group.type,
                        proxy: proxy,
                        type: ProxyCardType.shrink,
                        testUrl: row.group.testUrl,
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        );
      },
    );
  }
}
