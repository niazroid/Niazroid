import 'dart:async';

import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/common/gohst_favorites.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/icons/icons.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/views/proxies/list.dart';
import 'package:fl_clash/views/proxies/providers.dart';
import 'package:fl_clash/views/proxies/gohst_mobile_list.dart';
import 'package:fl_clash/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'card.dart';
import 'setting.dart';
import 'tab.dart';

class ProxiesView extends ConsumerStatefulWidget {
  const ProxiesView({super.key});

  @override
  ConsumerState<ProxiesView> createState() => _ProxiesViewState();
}

class _ProxiesViewState extends ConsumerState<ProxiesView> {
  final GlobalKey<ProxiesTabViewState> _proxiesTabKey = GlobalKey();
  bool _hasProviders = false;
  bool _isTab = false;
  bool _onlyFavorites = false;
  bool _pingTestingAll = false;

  String _label(String fa, String en) =>
      Localizations.localeOf(context).languageCode == 'fa' ? fa : en;

  Future<void> _pingAllGroups() async {
    if (_pingTestingAll) return;
    setState(() => _pingTestingAll = true);
    try {
      final groups = ref.read(proxiesTabStateProvider).groups;
      for (final group in groups) {
        await ref.read(proxiesActionProvider.notifier).delayTestPageGroup(group.name);
      }
    } catch (error) {
      if (mounted) {
        context.showNotifier(
          '${_label('خطا در تست پینگ', 'Ping test failed')}: $error',
          level: MessageLevel.warning,
        );
      }
    } finally {
      if (mounted) setState(() => _pingTestingAll = false);
    }
  }

  Widget _buildFavorites() {
    final groups = ref.watch(proxiesTabStateProvider).groups;
    return ValueListenableBuilder<Set<String>>(
      valueListenable: GohstFavorites.instance.favorites,
      builder: (context, favorites, _) {
        final cards = <Widget>[
          for (final group in groups)
            for (final proxy in group.all)
              if (GohstFavorites.instance.contains(group.name, proxy.name))
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: SizedBox(
                    height: 86,
                    child: ProxyCard(
                      key: ValueKey('favorite:${group.name}:${proxy.name}'),
                      groupName: group.name,
                      groupType: group.type,
                      proxy: proxy,
                      type: ProxyCardType.shrink,
                      testUrl: group.testUrl,
                    ),
                  ),
                ),
        ];
        if (cards.isEmpty) {
          return Center(
            child: Text(_label('هنوز سرور علاقه‌مندی ندارید.', 'No favorite servers yet.')),
          );
        }
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
          children: cards,
        );
      },
    );
  }

  List<CommonPopupMenuItem> _buildMenuItems(BuildContext context) {
    final appLocalizations = context.appLocalizations;
    return [
      CommonPopupMenuItem(
        glyph: AppGlyphs.sliders,
        label: appLocalizations.settings,
        onPressed: () {
          showSheet(
            context: context,
            props: const SheetProps(isScrollControlled: true),
            builder: (_) {
              return CommonScaffold(
                body: const ProxiesSetting(),
                title: appLocalizations.settings,
              );
            },
          );
        },
      ),
      if (_hasProviders)
        CommonPopupMenuItem(
          glyph: AppGlyphs.layers,
          label: appLocalizations.providers,
          onPressed: () {
            showExtend(
              context,
              builder: (_) {
                return const ProvidersView();
              },
            );
          },
        ),
    ];
  }

  IconButtonData? _buildPrimaryAction() {
    if (!_isTab || _onlyFavorites) {
      return null;
    }
    final currentGroupName = ref.watch(
      proxiesTabControllerStateProvider.select(
        (state) => state.currentGroupName,
      ),
    );
    final isDelayTesting = ref.watch(
      delayTestingGroupsProvider.select(
        (state) => state.contains(currentGroupName),
      ),
    );
    return IconButtonData(
      glyph: AppGlyphs.bolt,
      onPressed: () {
        _proxiesTabKey.currentState?.delayTestCurrentGroup();
      },
      tooltip: context.appLocalizations.delayTest,
      isLoading: isDelayTesting,
    );
  }

  void _onSearch(String value) {
    ref.read(queryProvider(QueryTag.proxies).notifier).value = value;
  }

  @override
  void initState() {
    super.initState();
    unawaited(GohstFavorites.instance.ensureLoaded());
    ref.listenManual(providersProvider.select((state) => state.isNotEmpty), (
      prev,
      next,
    ) {
      if (prev != next) {
        setState(() {
          _hasProviders = next;
        });
      }
    }, fireImmediately: true);
    ref.listenManual(
      proxiesStyleSettingProvider.select(
        (state) => state.type == ProxiesType.tab,
      ),
      (prev, next) {
        if (prev != next) {
          setState(() {
            _isTab = next;
          });
        }
      },
      fireImmediately: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final proxiesType = ref.watch(
      proxiesStyleSettingProvider.select((state) => state.type),
    );
    final isLoading = ref.watch(loadingProvider(LoadingTag.proxies));
    final isMobile = ref.watch(isMobileViewProvider);
    return CommonScaffold(
      isLoading: isLoading,
      resizeToAvoidBottomInset: false,
      primaryAction: _buildPrimaryAction(),
      iconActions: [
        IconButtonData(
          glyph: AppGlyphs.star,
          tooltip: _onlyFavorites
              ? _label('همه سرورها', 'All servers')
              : _label('علاقه‌مندی‌ها', 'Favorites'),
          onPressed: () => setState(() => _onlyFavorites = !_onlyFavorites),
        ),
        IconButtonData(
          glyph: AppGlyphs.bolt,
          tooltip: _label('تست پینگ همه سرورها', 'Ping all servers'),
          isLoading: _pingTestingAll,
          onPressed: _pingTestingAll ? null : _pingAllGroups,
        ),
        if (!_onlyFavorites && _isTab)
          IconButtonData(
            glyph: AppGlyphs.locate,
            onPressed: () {
              _proxiesTabKey.currentState?.scrollToGroupSelected();
            },
            tooltip: context.appLocalizations.scrollToSelected,
          ),
      ],
      menuItems: _buildMenuItems(context),
      title: _onlyFavorites
          ? _label('علاقه‌مندی‌ها', 'Favorites')
          : _label('سرورها', 'Servers'),
      searchState: _onlyFavorites ? null : AppBarSearchState(onSearch: _onSearch),
      body: _onlyFavorites
          ? _buildFavorites()
          : isMobile
              ? const GohstMobileServersList()
              : switch (proxiesType) {
                  ProxiesType.tab => ProxiesTabView(key: _proxiesTabKey),
                  ProxiesType.list => const ProxiesListView(),
                },
    );
  }
}
