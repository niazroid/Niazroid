import 'package:flutter/material.dart' as m;
import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/common/gohst_display_name.dart';
import 'package:fl_clash/common/gohst_subscription_notice.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/icons/icons.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class GohstDashboardView extends ConsumerWidget {
  const GohstDashboardView({super.key});

  String _label(BuildContext context, String fa, String en) =>
      Localizations.localeOf(context).languageCode == 'fa' ? fa : en;

  void _open(WidgetRef ref, PageLabel page) {
    ref.read(currentPageLabelProvider.notifier).toPage(page);
  }

  Widget _metric(BuildContext context, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: ShapeDecoration(
          color: context.colorScheme.surfaceContainerHighest,
          shape: AppShape.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: context.textTheme.labelMedium),
            const SizedBox(height: 6),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.textTheme.titleMedium?.toSoftBold,
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    GohstSubscriptionNotice.instance.ensureLoaded();
    final profile = ref.watch(currentProfileProvider);
    final isStarted = ref.watch(isStartProvider);
    final isSuspended = ref.watch(suspendProvider);
    final groups = ref.watch(proxiesTabStateProvider).groups;
    final selectedNode = groups
        .where((group) => group.now?.isNotEmpty == true)
        .map((group) => group.now!)
        .firstOrNull;
    final info = profile?.subscriptionInfo;
    final used = (info?.upload ?? 0) + (info?.download ?? 0);
    final total = info?.total ?? 0;
    final hasTraffic = total > 0;
    final int? remaining = hasTraffic ? (total > used ? total - used : 0) : null;
    final expire = info?.expire ?? 0;
    final daysLeft = expire > 0
        ? ((DateTime.fromMillisecondsSinceEpoch(expire * 1000)
                        .difference(DateTime.now())
                        .inHours +
                    23) ~/
                24)
            .clamp(0, 999999)
        : null;
    final connectedText = isStarted
        ? (isSuspended
              ? _label(context, 'اتصال موقتاً متوقف است', 'Connection suspended')
              : _label(context, 'متصل', 'Connected'))
        : _label(context, 'قطع', 'Disconnected');

    return CommonScaffold(
      title: 'GohstVpn',
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          16,
          20 + context.appBarInset,
          16,
          28 + BottomInsetScope.of(context),
        ),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 26),
              child: Column(
                children: [
                  Container(
                    width: 90,
                    height: 90,
                    decoration: ShapeDecoration(
                      color: context.colorScheme.primaryContainer,
                      shape: AppShape.circle,
                    ),
                    child: Center(
                      child: GlyphIcon(
                        AppGlyphs.bolt,
                        color: context.colorScheme.primary,
                        size: 40,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  Text(
                    connectedText,
                    style: context.textTheme.headlineSmall?.toSoftBold,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    profile == null
                        ? _label(context, 'برای شروع اشتراک اضافه کنید', 'Add a subscription to begin')
                        : profile.realLabel,
                    textAlign: TextAlign.center,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: context.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 20),
                  SizedBox(
                    width: double.infinity,
                    height: 54,
                    child: FilledButton.icon(
                      onPressed: profile == null
                          ? null
                          : () => ref
                              .read(commonActionProvider.notifier)
                              .toggleRunning(),
                      icon: GlyphIcon(
                        isStarted ? AppGlyphs.playPause(1) : AppGlyphs.bolt,
                        fill: 1,
                      ),
                      label: Text(
                        isStarted
                            ? _label(context, 'قطع اتصال', 'Disconnect')
                            : _label(context, 'اتصال', 'Connect'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: InkWell(
              customBorder: AppShape.xl,
              onTap: () => _open(ref, PageLabel.proxies),
              child: Padding(
                padding: const EdgeInsets.all(18),
                child: Row(
                  children: [
                    const GlyphIcon(AppGlyphs.proxies),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _label(context, 'سرور انتخاب‌شده', 'Selected server'),
                            style: context.textTheme.labelMedium,
                          ),
                          const SizedBox(height: 4),
                          Text(
                            selectedNode == null
                                ? _label(context, 'انتخاب سرور / تست پینگ', 'Choose server / Ping test')
                                : gohstDisplayName(selectedNode),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: context.textTheme.titleMedium,
                          ),
                        ],
                      ),
                    ),
                    const GlyphIcon(AppGlyphs.chevronForward),
                  ],
                ),
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _label(context, 'اشتراک من', 'My subscription'),
                          style: context.textTheme.titleMedium?.toSoftBold,
                        ),
                      ),
                      TextButton(
                        onPressed: () => _open(ref, PageLabel.profiles),
                        child: Text(_label(context, 'مدیریت', 'Manage')),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _metric(
                        context,
                        _label(context, 'حجم باقی‌مانده', 'Remaining data'),
                        remaining?.traffic.show ?? _label(context, 'نامشخص', 'Unknown'),
                      ),
                      const SizedBox(width: 10),
                      _metric(
                        context,
                        _label(context, 'روز باقی‌مانده', 'Days left'),
                        daysLeft?.toString() ?? _label(context, 'نامشخص', 'Unknown'),
                      ),
                    ],
                  ),
                  if (hasTraffic) ...[
                    const SizedBox(height: 14),
                    LinearProgressIndicator(
                      value: (used / total).clamp(0, 1).toDouble(),
                      minHeight: 6,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${_label(context, 'مصرف شده', 'Used')}: ${used.traffic.show} / ${total.traffic.show}',
                      style: context.textTheme.bodySmall,
                    ),
                  ] else ...[
                    const SizedBox(height: 12),
                    Text(
                      _label(
                        context,
                        'نمایش حجم و انقضا به اطلاعات ارسالی سرویس‌دهنده بستگی دارد.',
                        'Data and expiry require subscription metadata from your provider.',
                      ),
                      style: context.textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ),
          ValueListenableBuilder<Map<int, String>>(
            valueListenable: GohstSubscriptionNotice.instance.notices,
            builder: (context, notices, _) {
              final notice = profile == null ? null : notices[profile.id];
              if (notice == null || notice.isEmpty) return const SizedBox.shrink();
              return Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        m.Icon(m.Icons.campaign_outlined, color: context.colorScheme.primary),
                        const SizedBox(width: 12),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_label(context, 'اطلاعیه اشتراک', 'Subscription notice'),
                              style: context.textTheme.titleSmall?.toSoftBold),
                            const SizedBox(height: 6),
                            SelectableText(notice, style: context.textTheme.bodyMedium),
                          ],
                        )),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 16),
          Text(
            _label(context, 'آپدیت پیش‌فرض اشتراک‌های جدید: هر ۱ ساعت', 'New subscriptions update every hour by default'),
            textAlign: TextAlign.center,
            style: context.textTheme.bodySmall,
          ),
        ],
      ),
    );
  }
}
