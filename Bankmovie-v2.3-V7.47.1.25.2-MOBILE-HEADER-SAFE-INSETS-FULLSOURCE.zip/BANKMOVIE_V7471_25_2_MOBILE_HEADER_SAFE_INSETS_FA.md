# BankMovie V7.47.1.25.2 — Mobile Header Safe Insets

این هات‌فیکس فقط فاصله امن هدرهای موبایل از Status Bar / Punch-hole / Display Cutout را اصلاح می‌کند و منطق TV، آرشیوها، نوتیفیکیشن و سرور را تغییر نمی‌دهد.

## تغییرات

- هدر اسلایدر Home در موبایل همچنان Edge-to-Edge است، ولی لوگو، جستجو و منو زیر ناحیه امن سیستم قرار می‌گیرند.
- دکمه Back و Watchlist روی Hero صفحه فیلم/سریال با WindowInsets واقعی پایین آورده می‌شوند و دیگر روی ساعت، آنتن، باتری یا ناچ نمی‌افتند.
- Back صفحه بازیگر نیز همین Safe Insets را رعایت می‌کند.
- هدر صفحات Settings، Profile، About، Notifications، Cleanup، Search، Advanced Search Results و Box Office در موبایل از Status Bar و Display Cutout فاصله می‌گیرند.
- فاصله ثابت هاردکد جایگزین نشده؛ مقدار واقعی WindowInsets هر دستگاه استفاده می‌شود تا گوشی‌های با ناچ/پانچ‌هول متفاوت درست باشند.
- TV توسط helperها مستثنی است و تغییر V7.47.1.25 (Dark-only + Detail DPAD fix) دست نخورده می‌ماند.
