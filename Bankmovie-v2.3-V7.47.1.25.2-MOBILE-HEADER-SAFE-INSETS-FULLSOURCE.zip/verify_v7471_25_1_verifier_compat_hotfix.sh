#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
API="$ROOT/server-required/app_api.php"
ADMIN="$ROOT/server-required/admin.php"

# Latest server behavior must remain intact while historical verifiers stay forward-compatible.
grep -Fq 'Deliberately do NOT touch Archive 1/3/4/5 network sources here.' "$API"
grep -Fq 'delete_site_notification' "$ADMIN"
grep -Fq 'clear_site_notifications' "$ADMIN"
grep -Fq 'INTERVAL 7 DAY' "$ROOT/server-required/includes/notification_retention.php"

bash "$ROOT/verify_v7469_ui_archive_resilience.sh"
bash "$ROOT/verify_v7470_push_notification_retention.sh"
bash "$ROOT/verify_v7471_25_tv_dark_only_detail_up_scroll.sh"

echo BANKMOVIE_V7471_25_1_VERIFIER_COMPAT_HOTFIX_OK
