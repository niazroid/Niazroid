#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
DOC="$ROOT/BANKMOVIE_V7471_25_2_MOBILE_HEADER_SAFE_INSETS_FA.md"
[[ -s "$MAIN" && -s "$DOC" ]]

grep -q 'private fun applyMobileSafeTopPadding' "$MAIN"
grep -q 'private fun applyMobileSafeTopMargin' "$MAIN"
grep -q 'WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.displayCutout()' "$MAIN"
grep -q 'applyMobileSafeTopPadding(this, baseTopDp = 8, breathingRoomDp = 4)' "$MAIN"
grep -q 'applyMobileSafeTopMargin(detailBackButton, baseTopDp = 15, breathingRoomDp = 4)' "$MAIN"
grep -q 'applyMobileSafeTopMargin(detailWatchlistButton, baseTopDp = 15, breathingRoomDp = 4)' "$MAIN"
grep -q 'applyMobileSafeTopMargin(actorBackButton, baseTopDp = 12, breathingRoomDp = 4)' "$MAIN"
grep -q 'if (!tv) applyMobileSafeTopPadding(this, baseTopDp = 30, breathingRoomDp = 4)' "$MAIN"
grep -q 'if (!isTvLike()) applyMobileSafeTopPadding(this, baseTopDp = 10, breathingRoomDp = 4)' "$MAIN"
grep -q 'FrameLayout.LayoutParams(-1, -2, Gravity.TOP)' "$MAIN"

# Guard against regressing the TV-only dark theme and TV detail UP fix.
bash "$ROOT/verify_v7471_25_tv_dark_only_detail_up_scroll.sh" >/dev/null
bash "$ROOT/verify_v7471_25_1_verifier_compat_hotfix.sh" >/dev/null

echo BANKMOVIE_V7471_25_2_MOBILE_HEADER_SAFE_INSETS_OK
