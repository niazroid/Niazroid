#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"

must_have() {
  local file="$1" pattern="$2"
  grep -Fq "$pattern" "$file" || { echo "Missing [$pattern] in $file" >&2; exit 1; }
}

must_not_have() {
  local file="$1" pattern="$2"
  if grep -Fq "$pattern" "$file"; then echo "Unexpected [$pattern] in $file" >&2; exit 1; fi
}

must_have "$root/build.gradle" "com.google.gms.google-services"
must_have "$root/app/build.gradle" "firebase-messaging"
must_have "$root/app/build.gradle" "firebase-bom:34.18.0"
must_have "$root/app/src/main/AndroidManifest.xml" ".BankMovieFirebaseMessagingService"
must_have "$root/app/src/main/java/ir/bankmoviee/app/BankMoviePush.kt" "bankmovie_all"
must_have "$root/app/src/main/java/ir/bankmoviee/app/BankMovieFirebaseMessagingService.kt" "notification_id"
must_have "$root/app/src/main/java/ir/bankmoviee/app/AccountApi.kt" 'X-BM-Notification-Protocol", "2'
must_have "$root/server-required/includes/notification_retention.php" "INTERVAL 7 DAY"
must_have "$root/server-required/includes/notification_retention.php" "app_notification_global_state"
must_have "$root/server-required/includes/notification_retention.php" "global-admin:%"
must_have "$root/server-required/includes/fcm_push.php" "https://fcm.googleapis.com/v1/projects/"
must_have "$root/server-required/includes/fcm_push.php" "bankmovie_all"
if grep -Fq "cleanup_notifications" "$root/server-required/admin.php"; then
  must_have "$root/server-required/admin.php" "min(7"
else
  # V7.47.1.24 replaced the legacy retention form with persistent delete/clear controls.
  must_have "$root/server-required/admin.php" "delete_site_notification"
  must_have "$root/server-required/admin.php" "clear_site_notifications"
fi
must_have "$root/server-required/app_user_api.php" "bm_user_api_notification_protocol_v2"
must_have "$root/server-required/app_user_api.php" "source'=>'global'"

php -l "$root/server-required/app_user_api.php" >/dev/null
php -l "$root/server-required/app_api.php" >/dev/null
php -l "$root/server-required/admin.php" >/dev/null
php -l "$root/server-required/includes/notification_retention.php" >/dev/null
php -l "$root/server-required/includes/fcm_push.php" >/dev/null

python3 - <<'PY' "$root/app/src/main/AndroidManifest.xml"
import sys, xml.etree.ElementTree as ET
ET.parse(sys.argv[1])
print('manifest ok')
PY

echo "VERIFY_V7470_PUSH_NOTIFICATION_RETENTION_OK"
