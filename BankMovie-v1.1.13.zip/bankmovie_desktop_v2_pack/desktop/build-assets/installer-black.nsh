!macro customHeader
  !ifdef MUI_BGCOLOR
    !undef MUI_BGCOLOR
  !endif
  !ifdef MUI_TEXTCOLOR
    !undef MUI_TEXTCOLOR
  !endif
  !ifdef MUI_INSTFILESPAGE_COLORS
    !undef MUI_INSTFILESPAGE_COLORS
  !endif

  !define MUI_BGCOLOR "000000"
  !define MUI_TEXTCOLOR "F5F8FC"
  !define MUI_INSTFILESPAGE_COLORS "F5F8FC 000000"
!macroend

!macro customInit
  SetCtlColors $HWNDPARENT F5F8FC 000000
!macroend
