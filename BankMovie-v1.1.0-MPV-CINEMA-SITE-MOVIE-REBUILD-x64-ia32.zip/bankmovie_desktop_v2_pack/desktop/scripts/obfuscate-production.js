const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');
const root = path.resolve(__dirname, '..');
const targets = ['electron/main.js', 'electron/preload.js', 'electron/runtime.generated.js', 'electron/mpv-player.js', 'electron/player-splash.js', 'electron/player-splash-preload.js', 'electron/continue-watching.js', 'electron/profile-activity.js', 'electron/watch-party.js', 'electron/watch-party-media.js', 'electron/watch-party-picker.js'];
const opts = {
  compact: true,
  identifierNamesGenerator: 'hexadecimal',
  renameGlobals: false,
  stringArray: true,
  rotateStringArray: true,
  shuffleStringArray: true,
  stringArrayThreshold: 0.90,
  stringArrayEncoding: ['base64'],
  splitStrings: true,
  splitStringsChunkLength: 8,
  controlFlowFlattening: false,
  deadCodeInjection: false,
  selfDefending: false,
  transformObjectKeys: false,
  unicodeEscapeSequence: false
};
for (const rel of targets) {
  const file = path.join(root, rel);
  const source = fs.readFileSync(file, 'utf8');
  const out = JavaScriptObfuscator.obfuscate(source, opts).getObfuscatedCode();
  fs.writeFileSync(file, out, 'utf8');
}
