$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$source = Join-Path $root 'player/player-window-icon.cs'
$output = Join-Path $root 'player/player-window-icon.exe'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework/v4.0.30319/csc.exe'
if (!(Test-Path -LiteralPath $compiler)) { throw 'Windows .NET Framework C# compiler missing' }
& $compiler /nologo /target:winexe /platform:anycpu /optimize+ "/out:$output" $source
if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $output)) { throw 'Player icon helper compilation failed' }
