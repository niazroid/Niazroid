'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
function bundledPlayer(resourcesPath, packaged, root=path.join(__dirname,'..')) {
  const base = packaged ? resourcesPath : root;
  const exe = path.join(base, packaged ? 'mpv' : 'vendor/mpv', 'mpv.exe');
  const script = path.join(base, 'player', 'cinema.lua');
  if (!fs.existsSync(exe) || !fs.existsSync(script)) return null;
  return {id:'bm-mpv',name:'BankMovie Player',path:exe,script,score:1000,subtitleSupport:true};
}
function cleanTitle(value) {return String(value||'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,240);}
function argsFor(player, target, meta={}, local=false) {
  if (typeof target!=='string'||!target||/[\x00-\x1f]/.test(target)) throw Error('Invalid media path');
  if(local){if(!path.isAbsolute(target))throw Error('Invalid local media path');}
  else {const u=new URL(target);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid media URL');}
  const args=['--no-config','--load-scripts=no','--osc=no','--input-default-bindings=no','--input-builtin-dragging=no','--input-builtin-drag-and-drop=no','--ytdl=no','--load-unsafe-playlists=no','--tls-verify=yes','--no-terminal','--title=BankMovie Player','--force-window=yes','--idle=no','--keep-open=yes','--geometry=80%x80%','--hwdec=auto-safe','--cache=auto','--sub-auto='+ (local?'exact':'no'),'--audio-file-auto=no','--cover-art-auto=no','--slang=fa,fas,per,persian,en,eng','--script='+player.script];
  const title=cleanTitle(meta.title || (local?path.basename(target):'BankMovie'));
  if(title)args.push('--force-media-title='+title);
  if(meta.subtitlePath)args.push('--sub-file='+meta.subtitlePath);
  if(Number.isFinite(meta.start)&&meta.start>0)args.push('--start='+meta.start.toFixed(3),'--hr-seek=yes');
  args.push('--',target);
  return args;
}
function cleanAccent(v){return typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v)?v.slice(1).toUpperCase():'327CF6';}
function applyPlayerWindowIcon(player,child,spawnFn=spawn,platform=process.platform){
  if(platform!=='win32'||!Number.isSafeInteger(child?.pid)||child.pid<=0)return false;
  const helper=path.join(path.dirname(player.script),'player-window-icon.exe');
  if(!fs.existsSync(helper))return false;
  try{const proc=spawnFn(helper,[String(child.pid)],{cwd:path.dirname(helper),shell:false,detached:true,stdio:'ignore',windowsHide:true});proc.once('error',()=>{});proc.unref();return true;}catch{return false;}
}
async function launch(player,target,meta={},local=false,spawnFn=spawn){
  const args=argsFor(player,target,meta,local);
  await new Promise((resolve,reject)=>{
    const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:true,stdio:'ignore',windowsHide:false,env:{...process.env,BM_PLAYER_ACCENT:cleanAccent(meta.accent),BM_CONTINUE_DIR:meta.progressDir||'',BM_PROFILE_DIR:meta.activityDir||'',BM_PLAYER_START_DIR:meta.startupDir||'',BM_PLAYER_BRAND:path.join(path.dirname(player.script),'player-brand.bgra')}});
    child.once('error',()=>reject(new Error('اجرای موتور MPV ناموفق بود.')));
    child.once('spawn',()=>{applyPlayerWindowIcon(player,child);if(meta.onChild)meta.onChild(child);child.unref();resolve();});
  });
  return {ok:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)};
}
async function launchParty(player,target,meta={},spawnFn=spawn){
  const args=argsFor(player,target,meta);args.splice(args.length-2,0,'--pause=yes');
  return new Promise((resolve,reject)=>{const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:false,stdio:'ignore',windowsHide:false,env:{...process.env,BM_PLAYER_ACCENT:cleanAccent(meta.accent),BM_PARTY_DIR:meta.partyDir,BM_PLAYER_START_DIR:meta.startupDir||'',BM_PLAYER_BRAND:path.join(path.dirname(player.script),'player-brand.bgra')}});child.once('error',()=>reject(Error('اجرای پلیر تماشای دونفره ناموفق بود.')));child.once('spawn',()=>{applyPlayerWindowIcon(player,child);resolve(child);});});
}
module.exports={bundledPlayer,argsFor,launch,launchParty,applyPlayerWindowIcon};
