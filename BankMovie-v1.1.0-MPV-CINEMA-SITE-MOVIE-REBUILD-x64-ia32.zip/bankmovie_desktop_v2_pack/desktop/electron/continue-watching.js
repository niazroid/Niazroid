'use strict';
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const hash=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const text=(v,n=240)=>String(v??'').trim().slice(0,n);
function source(s={}){
  if(!s||typeof s!=='object')return null;
  let u;try{u=new URL(s.url);if(!['http:','https:'].includes(u.protocol)||u.username||u.password)return null;}catch{return null;}
  const canonical=new URL(u.href);canonical.hash='';
  for(const k of [...canonical.searchParams.keys()])if(/^(?:token|access_token|auth|signature|sig|expires|expiry|exp|policy|key-pair-id|x-amz-.*|x-goog-.*)$/i.test(k))canonical.searchParams.delete(k);
  canonical.searchParams.sort();
  const number=v=>Number.isSafeInteger(Number(v))?Math.max(0,Number(v)):0;
  return {season:number(s.season),episode:number(s.episode),quality:text(s.quality,80),sourceType:text(s.sourceType||s.type||s.type_fa,80),urlHash:hash(u.href),pathHash:hash(canonical.href)};
}
function identity(m={}){
  if(!m||typeof m!=='object')return null;
  const archive=Number(m.archive),id=text(m.id,190),type=m.type==='series'?'series':m.type==='movie'?'movie':'';
  if(!id||!type||!Number.isInteger(archive)||archive<1||archive>5)return null;
  return {archive,id,type,key:hash(JSON.stringify([archive,type,id]))};
}
function sameDescriptor(a,b){return a&&b&&a.season===b.season&&a.episode===b.episode&&a.quality===b.quality&&a.sourceType===b.sourceType;}
function match(record,candidates){
  const entries=candidates.map(source);let found=[];
  for(let i=0;i<entries.length;i++)if(sameDescriptor(record,entries[i])&&record.urlHash===entries[i].urlHash)found.push(i);
  if(found.length)return found[0];
  // Older nested-series entries may have no season number. Recover only a unique exact URL and edition.
  if(record.type==='series'&&record.season===0){
    found=[];for(let i=0;i<entries.length;i++){const e=entries[i];if(e&&e.urlHash===record.urlHash&&e.quality===record.quality&&e.sourceType===record.sourceType&&(!record.episode||e.episode===record.episode))found.push(i);}
    if(found.length===1)return found[0];if(found.length>1)return -1;
  }
  // Signed query strings may change. Only accept a unique match of path AND edition.
  found=[];for(let i=0;i<entries.length;i++)if(sameDescriptor(record,entries[i])&&record.pathHash===entries[i].pathHash)found.push(i);
  return found.length===1?found[0]:-1;
}
function readJSON(p){try{return JSON.parse(fs.readFileSync(p,'utf8'));}catch{return null;}}
function readCheckpoint(dir){
  const rows=['a','b'].map(slot=>{try{const [seq,position,duration,done]=fs.readFileSync(path.join(dir,slot),'utf8').trim().split(' ').map(Number);if(!Number.isSafeInteger(seq)||seq<1||!Number.isFinite(position)||position<0||!Number.isFinite(duration)||duration<=0||position>duration+5||![0,1].includes(done))return null;return {seq,position:Math.min(position,duration),duration,done:done===1};}catch{return null;}}).filter(Boolean);
  return rows.sort((a,b)=>b.seq-a.seq)[0]||null;
}
function create(root){
  const scoped=scope=>path.join(root,hash(scope));
  function records(scope){if(!scope)return [];const base=scoped(scope);let titles=[];try{titles=fs.readdirSync(base,{withFileTypes:true});}catch{return [];}
    const out=[];for(const t of titles){if(!t.isDirectory()||!/^[a-f0-9]{64}$/.test(t.name))continue;const titleDir=path.join(base,t.name);let sessions=[];try{sessions=fs.readdirSync(titleDir,{withFileTypes:true});}catch{continue;}
      const candidates=[];for(const s of sessions){if(!s.isDirectory()||!/^[a-f0-9]{32}$/.test(s.name))continue;const dir=path.join(titleDir,s.name),m=readJSON(path.join(dir,'meta.json')),p=readCheckpoint(dir);if(m&&p&&m.key===t.name&&Number.isFinite(m.started))candidates.push({...m,...p});}
      candidates.sort((a,b)=>b.started-a.started);if(candidates[0])out.push(candidates[0]);
    }return out.sort((a,b)=>b.started-a.started);
  }
  function list(scope){return records(scope).filter(r=>!r.done&&r.position>=1&&r.position<r.duration).map(({seq,done,...r})=>r);}
  function get(scope,key){return list(scope).find(r=>r.key===key)||null;}
  function begin(scope,meta,s){const i=identity(meta),src=source(s);if(!scope||!i||!src)return '';const dir=path.join(scoped(scope),i.key,crypto.randomBytes(16).toString('hex'));fs.mkdirSync(dir,{recursive:true});let poster='';try{const u=new URL(meta.poster);if(u.protocol==='https:'&&!u.username&&!u.password)poster=u.href.slice(0,1800);}catch{}
    fs.writeFileSync(path.join(dir,'meta.json'),JSON.stringify({...i,...src,title:text(meta.title),poster,started:Date.now()}));return dir;
  }
  function remove(scope,key){if(!scope||!(/^[a-f0-9]{64}$/.test(String(key))))return false;fs.rmSync(path.join(scoped(scope),key),{recursive:true,force:true});return true;}
  return {list,get,begin,remove};
}
module.exports={create,identity,source,match,readCheckpoint};
