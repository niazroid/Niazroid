'use strict';
const {ipcRenderer}=require('electron');
window.addEventListener('DOMContentLoaded',()=>{
 const bar=document.querySelector('progress'),label=document.getElementById('stage');
 ipcRenderer.on('bm-player-splash:stage',(_event,value)=>{if(!Array.isArray(value)||!Number.isFinite(value[0])||typeof value[1]!=='string')return;bar.value=value[0];label.textContent=value[1];});
 document.getElementById('cancel').addEventListener('click',()=>window.close());
});
