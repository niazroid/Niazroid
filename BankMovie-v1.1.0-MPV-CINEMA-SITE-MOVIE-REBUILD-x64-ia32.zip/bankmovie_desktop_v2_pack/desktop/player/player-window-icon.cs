// Applies the selected Player icon to the native MPV window only.
// No binary modification, injection, registry writes, or application-wide branding changes.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

internal static class PlayerWindowIcon {
    private delegate bool EnumProc(IntPtr hwnd, IntPtr arg);
    [DllImport("user32.dll")] private static extern bool EnumWindows(EnumProc callback, IntPtr arg);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(IntPtr hwnd, out uint pid);
    [DllImport("user32.dll")] private static extern bool IsWindowVisible(IntPtr hwnd);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetClassName(IntPtr hwnd, StringBuilder name, int count);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern int GetWindowText(IntPtr hwnd, StringBuilder name, int count);
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] private static extern IntPtr LoadImage(IntPtr instance, string name, uint type, int cx, int cy, uint flags);
    [DllImport("user32.dll")] private static extern bool DestroyIcon(IntPtr icon);
    [DllImport("user32.dll")] private static extern int GetSystemMetrics(int index);
    [DllImport("user32.dll", SetLastError=true)] private static extern IntPtr SendMessageTimeout(IntPtr hwnd, uint msg, IntPtr wp, IntPtr lp, uint flags, uint timeout, out IntPtr result);
    private static bool SetIcon(IntPtr hwnd, int size, IntPtr icon) {
        IntPtr result;
        return SendMessageTimeout(hwnd, 0x0080, new IntPtr(size), icon, 2, 500, out result) != IntPtr.Zero;
    }
    [STAThread] private static int Main(string[] args) {
        int pid;
        if(args.Length!=1 || !int.TryParse(args[0],out pid) || pid<=0) return 2;
        IntPtr small=IntPtr.Zero,big=IntPtr.Zero;
        try {
            using(Process target=Process.GetProcessById(pid)) {
                if(!String.Equals(target.ProcessName,"mpv",StringComparison.OrdinalIgnoreCase))return 2;
                string iconPath=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"player-icon.ico");
                if(!File.Exists(iconPath))return 2;
                small=LoadImage(IntPtr.Zero,iconPath,1,GetSystemMetrics(49),GetSystemMetrics(50),0x10);
                big=LoadImage(IntPtr.Zero,iconPath,1,GetSystemMetrics(11),GetSystemMetrics(12),0x10);
                if(small==IntPtr.Zero || big==IntPtr.Zero)return 3;
                HashSet<IntPtr> applied=new HashSet<IntPtr>();
                while(!target.HasExited) {
                    HashSet<IntPtr> seen=new HashSet<IntPtr>();
                    EnumWindows(delegate(IntPtr hwnd,IntPtr ignored) {
                        uint owner;GetWindowThreadProcessId(hwnd,out owner);
                        if(owner!=(uint)pid || !IsWindowVisible(hwnd))return true;
                        StringBuilder cls=new StringBuilder(128),title=new StringBuilder(256);
                        GetClassName(hwnd,cls,cls.Capacity);GetWindowText(hwnd,title,title.Capacity);
                        if(!String.Equals(cls.ToString(),"mpv",StringComparison.OrdinalIgnoreCase) && !String.Equals(title.ToString(),"BankMovie Player",StringComparison.Ordinal))return true;
                        seen.Add(hwnd);
                        if(!applied.Contains(hwnd)) {
                            bool a=SetIcon(hwnd,0,small),b=SetIcon(hwnd,1,big);
                            if(a&&b)applied.Add(hwnd);
                        }
                        return true;
                    },IntPtr.Zero);
                    applied.IntersectWith(seen);
                    // Keep the icon handles alive until MPV exits. No persistent background service.
                    if(target.WaitForExit(500))break;
                }
            }
            return 0;
        } catch {return 1;} finally {if(small!=IntPtr.Zero)DestroyIcon(small);if(big!=IntPtr.Zero)DestroyIcon(big);}
    }
}
