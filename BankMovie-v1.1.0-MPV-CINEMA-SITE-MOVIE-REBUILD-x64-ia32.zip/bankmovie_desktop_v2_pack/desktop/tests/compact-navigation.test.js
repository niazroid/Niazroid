const assert=require('node:assert/strict');
const fs=require('node:fs');
const vm=require('node:vm');
const path=require('node:path');
const read=f=>fs.readFileSync(path.join(__dirname,'..',f),'utf8');
const app=read('src/app.js'),main=read('electron/main.js'),css=read('src/native-refinements.css');
const between=(text,a,b)=>{const i=text.indexOf(a);assert.ok(i>=0,a);const j=text.indexOf(b,i+a.length);assert.ok(j>i,b);return text.slice(i,j)};
// Real home transition logic: stale back history is dropped, other routes retain it.
const state={archive:3,lastView:'detail',bm196NavStack:[{view:'home'},{view:'actor'}]};
const classes=new Set();let updates=0;
const ctx={state,document:{body:{classList:{toggle:(k,v)=>v?classes.add(k):classes.delete(k)}}},setHeaderActive:()=>{},bm198EnsurePageBack:()=>updates++,clearInterval:()=>{}};
vm.createContext(ctx);vm.runInContext(between(app,'function setActiveNav(view){','function img('),ctx);
vm.runInContext("setActiveNav('home')",ctx);assert.equal(state.bm196NavStack.length,0);assert.equal(state.bm196NavCurrent.archive,3);assert.ok(classes.has('home-active'));assert.equal(updates,1);
state.bm196NavStack.push({view:'home'});vm.runInContext("setActiveNav('collections')",ctx);assert.equal(state.bm196NavStack.length,1);assert.ok(!classes.has('home-active'));
assert.match(app,/const hasBack=state\.lastView!=='home'&&!!state\.bm196NavStack\?\.length/);
assert.match(app,/bm196GoBack=async function\(\)\{\s*if\(bm196NavLock\|\|state\.lastView==='home'\|\|!state\.bm196NavStack\.length\)return/);
assert.match(app,/if\(view==='home'\)state\.bm196NavStack\.length=0/);
// The actual fallback renderer handles missing URLs and keeps real photos intact.
const actorCtx={esc:s=>String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;'),cleanUrl:s=>/^https?:\/\//i.test(s)?s:''};
vm.createContext(actorCtx);vm.runInContext(between(app,'function bm1132ActorAvatarSvg(','function bm1132ReplaceBrokenActorImage('),actorCtx);
assert.match(vm.runInContext("bm1132ActorImage('', 'Actor')",actorCtx),/assets\/actor-placeholder\.webp/);
assert.match(vm.runInContext("bm1132ActorImage('https://example.com/actor.jpg','Actor')",actorCtx),/data-bm-actor-image/);
assert.match(app,/holder\.innerHTML=bm1132ActorAvatarSvg\(img\.alt/);
assert.ok(fs.statSync(path.join(__dirname,'../src/assets/actor-placeholder.webp')).size>1000);
// The native context menu is available only for editable fields in the local main frame.
const local='file:///app/src/index.html';const menuCtx={bmIsAppIndexUrl:url=>url===local};vm.createContext(menuCtx);
vm.runInContext(between(main,'function bmLocalEditMenuItems(','function createWindow()'),menuCtx);
const params={isEditable:true,pageURL:local,frameURL:local,editFlags:{canPaste:true,canSelectAll:true}};
const get=p=>{menuCtx.p=p;return JSON.parse(JSON.stringify(vm.runInContext('bmLocalEditMenuItems(p)',menuCtx)))};
assert.equal(get(params)[0].role,'paste');assert.equal(get(params)[0].enabled,true);assert.equal(get({...params,editFlags:{}})[0].enabled,false);
assert.deepEqual(get({...params,isEditable:false}),[]);assert.deepEqual(get({...params,frameURL:'bm-discover://local/discover'}),[]);assert.deepEqual(get({...params,pageURL:'https://example.com/'}),[]);
assert.match(main,/Menu\.buildFromTemplate\(items\)\.popup\(\{window:editWindow\}\)/);
// CSS and header scroll wiring.
assert.ok(!app.includes('<div class="archive-hub-copy">'));
assert.match(css,/#view \.archive-hub\{width:max-content/);
assert.match(css,/body\.home-active #bm198PageBack\{display:none!important\}/);
assert.match(css,/#view \.collection-hero\{[^}]*border:0!important;border-radius:0!important/);
assert.match(css,/has\(#view \.collection-hero\):not\(\.header-scrolled\) #appHeader\.bm-site-header-desktop\{background:transparent!important;border:0!important/);
assert.ok(app.includes("const hero=detail||$('#view .actor-hero')||$('#view .collection-hero')||$('#view .pd-hero')||$('#view .site-hero')"));
console.log('PASS compact archive, local actor fallback, root Back, full-bleed collection, trusted native Paste menu');
