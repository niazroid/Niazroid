'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm');
const app=fs.readFileSync('src/app.js','utf8'),profile=fs.readFileSync('src/profile-dashboard.js','utf8'),css=fs.readFileSync('src/profile-dashboard.css','utf8');
const between=(s,a,b)=>{const i=s.indexOf(a),j=s.indexOf(b,i+a.length);assert.ok(i>=0&&j>i,`${a} ${b}`);return s.slice(i,j)};
const state={theme:'dark-green',lastView:'home',archive:1,bm196NavStack:[],bm196NavCurrent:{kind:'route',view:'home'},user:{username:'sample'},downloads:new Map()};
const store=new Map(),classes=new Set(['home-active']),logo={src:'assets/bankmovie-logo.webp',getAttribute(k){return this[k]},setAttribute(k,v){this[k]=v}},btn={hidden:true,setAttribute(){}};
let renders=0,backs=0;
const ctx={state,document:{documentElement:{dataset:{}},body:{classList:{toggle:(k,v)=>v?classes.add(k):classes.delete(k)}},querySelector:()=>null},localStorage:{setItem:(k,v)=>store.set(k,v),getItem:k=>store.get(k)},$:q=>q==='#headerHome img'?logo:q==='#bm198PageBack'?btn:null,THEME_KEY:'bankmovie_theme_v1',applyTheme(){},toggleTheme(){},bm191ThemeSwitchHtml(){},bm191Language:'fa',setHeaderActive(){},clearInterval(){},bm196GoBack(){backs++},BM197_BACK_SVG:'',renderDetail(){},_bm1121RenderDetail(){renders++},bm1121AgeRating(){return null},bm1118RefreshSourceActionClasses(){},icon:()=>'',esc:String,img:()=>'',isVip:()=>false,faDate:()=>'',bmWatchUnlimited:()=>false,bmWatchLimit:()=>100};
vm.createContext(ctx);vm.runInContext(between(app,'const BM192_THEME_KEY=','const _bm192ShowSettings=showSettings;'),ctx);
const themes=['dark-green','dark-blue','dark-purple','dark-pink','dark-red','dark-orange','dark-cyan','dark-white','dark-black','light'];
for(const theme of themes){ctx.applyTheme(theme);const expected=theme==='light'?'assets/bankmovie-logo.webp':`assets/themes/bankmovie-logo-${theme}.webp`;assert.equal(logo.src,expected);assert.ok(fs.existsSync('src/'+expected));assert.equal(store.get('bankmovie_theme_v2'),theme)}
ctx.applyTheme('dark-red');ctx.toggleTheme();assert.equal(logo.src,'assets/bankmovie-logo.webp');ctx.toggleTheme();assert.equal(logo.src,'assets/themes/bankmovie-logo-dark-red.webp');
// Actual detail renderer, setActiveNav, and persistent button implementation.
vm.runInContext(between(app,'function setActiveNav(view){','function img(')+between(app,'function bm198EnsurePageBack(){','/* Old v1.9.7')+between(app,'renderDetail=function(d){\n  setActiveNav(\'detail\');','/* ===== BankMovie Desktop v1.1.24'),ctx);
ctx.setActiveNav('home');assert.equal(btn.hidden,true);
state.bm196NavStack.push({view:'home'});ctx.renderDetail({});assert.equal(renders,1);assert.equal(state.lastView,'detail');assert.equal(classes.has('home-active'),false);assert.equal(btn.hidden,false);assert.equal(state.bm196NavStack.length,1);
ctx.renderDetail({});assert.equal(state.bm196NavStack.length,1);assert.equal(btn.hidden,false);
ctx.setActiveNav('home');assert.equal(btn.hidden,true);assert.equal(state.bm196NavStack.length,0);
// Verify actual production hero output and icons; existing selected cover remains supported.
vm.runInContext(profile.slice(0,profile.indexOf('function bmPDActivity(')),ctx);
const html=ctx.bmPDHero({data:{history:[],movies:0,series:0,seconds:0,cover:''}});assert.doesNotMatch(html,/pdCover|تغییر کاور/);assert.match(html,/pdAvatar/);assert.match(html,/pdEdit/);
for(const name of ['bookmark','play','user','history','download','settings','palette','shield','bell','vip','dashboard','people','logout']){const svg=ctx.bmPDIcon(name);assert.match(svg,/pd-duotone/);assert.match(svg,/fill="currentColor"/);assert.match(svg,/opacity=/);}
assert.match(ctx.bmPDIcon('bookmark'),/M16 8\.98987V20\.3499/);assert.match(app,/class="bm-trailer-icon"/);assert.match(app,/M4 5h16a2 2 0 0 1 2 2v10/);assert.match(css,/\.bm-continue-detail\{background:linear-gradient\(135deg,var\(--bm-resume-start\),var\(--bm-resume-end\)\)/);
console.log('PASS: theme logos, light/dark roundtrip, detail navigation and back visibility, no cover button, local duotone and supplied vectors, distinct resume style');
