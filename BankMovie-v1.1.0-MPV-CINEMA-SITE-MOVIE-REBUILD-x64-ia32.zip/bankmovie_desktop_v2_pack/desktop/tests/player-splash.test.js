'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path'),{EventEmitter}=require('events');
const {PlayerSplash,stages}=require('../electron/player-splash');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'bm-splash-test-'));let messages=[];
class Window extends EventEmitter{constructor(opts){super();this.opts=opts;this.webContents=new EventEmitter();this.webContents.setWindowOpenHandler=()=>{};this.webContents.isDestroyed=()=>this.dead;this.webContents.send=(name,data)=>messages.push(data);}
 loadFile(){return Promise.resolve();}show(){}isDestroyed(){return !!this.dead;}destroy(){this.dead=true;this.emit('closed');}}
const create=()=>new PlayerSplash({BrowserWindow:Window,temp:root,dialog:{showMessageBox:()=>Promise.resolve()},timeout:10000});
function child(){const c=new EventEmitter();c.kill=()=>{c.killed=true;};return c;}
try{
 let s=create(),c=child();assert.equal(s.window.opts.webPreferences.nodeIntegration,false);assert.equal(s.window.opts.webPreferences.sandbox,true);s.attach(c);fs.writeFileSync(path.join(s.dir,'opening'),'');s.poll();assert.equal(s.stage,'opening');fs.writeFileSync(path.join(s.dir,'loaded'),'');s.poll();assert.equal(s.stage,'loaded');assert.equal(s.finished,false);fs.writeFileSync(path.join(s.dir,'ready'),'');s.poll();assert.equal(s.finished,true);assert.equal(c.killed,undefined);assert.equal(messages.at(-1)[0],100);assert.equal(fs.existsSync(s.dir),false);
 s=create();c=child();s.attach(c);fs.writeFileSync(path.join(s.dir,'error'),'');s.poll();assert.ok(c.killed&&s.cancelled);assert.throws(()=>s.assertActive(),/لغو/);
 s=create();c=child();s.cancel();s.attach(c);assert.ok(c.killed);
 s=create();c=child();s.attach(c);c.emit('exit',1);assert.ok(s.finished&&s.cancelled);
 const lua=fs.readFileSync(path.join(__dirname,'../player/cinema.lua'),'utf8');assert.match(lua,/register_event\('playback-restart',function\(\)startupMark\('ready'\)/);assert.match(lua,/controlBrand\(show and not locked\)/);assert.ok(fs.statSync(path.join(__dirname,'../player/player-brand.bgra')).size===40*40*4);
 console.log('PASS: splash milestone order, no premature close, error, cancel, exit and resource branding');
}finally{fs.rmSync(root,{recursive:true,force:true});}
