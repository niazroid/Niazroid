'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),os=require('node:os'),path=require('node:path');
const C=require('../electron/continue-watching'),P=require('../electron/mpv-player');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'bm-continue-'));
try{
 const store=C.create(root),scope='account:19',other='account:20';
 const title={id:'film-123',archive:3,type:'series',title:'Test Series',poster:'https://example.com/cover.webp'};
 const source={url:'https://example.com/ep3.mkv?token=private',season:2,episode:3,quality:'1080p',sourceType:'dub'};
 const key=C.identity(title).key,dir=store.begin(scope,title,source);
 assert.ok(dir);assert.equal(store.list(scope).length,0);assert.equal(store.list(other).length,0);
 fs.writeFileSync(path.join(dir,'b'),'1 723.125 1800 0\n');
 fs.writeFileSync(path.join(dir,'a'),'2 735.456789 1800 0\n');
 let r=store.get(scope,key);assert.equal(r.position,735.456789);assert.equal(r.season,2);assert.equal(r.episode,3);
 assert.equal(C.match(r,[{...source,episode:4},source]),1);
 assert.equal(C.match(r,[{...source,url:'https://example.com/ep3.mkv?token=fresh'}]),0);
 assert.equal(C.match(r,[{...source,quality:'720p'}]),-1);
 assert.equal(C.match(r,[{...source,url:'https://example.com/ep3.mkv?token=1'},{...source,url:'https://example.com/ep3.mkv?token=2'}]),-1);
 assert.equal(C.match(r,[{...source,url:'https://example.com/ep3.mkv?id=other'}]),-1);
 const oldMissingSeason={...r,season:0,episode:0};
 assert.equal(C.match(oldMissingSeason,[source]),0,'old nested series record recovers unique exact episode URL');
 assert.equal(C.match(oldMissingSeason,[source,{...source,episode:4}]),-1,'ambiguous old record is never guessed');
 const restarted=C.create(root);assert.equal(restarted.get(scope,key).position,735.456789,'journal survives store re-instantiation');
 assert.equal(store.get(other,key),null);assert.equal(store.get('guest',key),null);
 const meta=fs.readFileSync(path.join(dir,'meta.json'),'utf8');assert.ok(!meta.includes('token=private'));assert.ok(!meta.includes('ep3.mkv'));
 fs.writeFileSync(path.join(dir,'b'),'3 74');assert.equal(store.get(scope,key).position,735.456789,'partial write recovers last complete checkpoint');
 fs.writeFileSync(path.join(dir,'b'),'3 30 1800 0\n');assert.equal(store.get(scope,key).position,30,'rewinding saves actual position not maximum');
 const args=P.argsFor({script:'cinema.lua'},source.url,{start:735.456789});assert.ok(args.includes('--start=735.457'));assert.ok(args.includes('--hr-seek=yes'));
 fs.writeFileSync(path.join(dir,'a'),'4 1800 1800 1\n');assert.equal(store.list(scope).length,0,'finished title disappears');
 const next=store.begin(scope,title,{...source,episode:4});fs.writeFileSync(path.join(next,'b'),'1 17.5 1700 0\n');
 // deterministic ordering even if Date.now has millisecond ties
 const mf=path.join(next,'meta.json'),m=JSON.parse(fs.readFileSync(mf));m.started+=5;fs.writeFileSync(mf,JSON.stringify(m));
 assert.equal(store.get(scope,key).episode,4);assert.equal(store.get(scope,key).position,17.5);
 assert.equal(store.remove(scope,'../escape'),false);assert.equal(store.remove(scope,key),true);assert.equal(store.list(scope).length,0);
 console.log('PASS: exact position, safe checkpoints, account isolation, fresh source matching, completion, removal and MPV seek options');
}finally{fs.rmSync(root,{recursive:true,force:true});}
