'use strict';
const assert=require('node:assert/strict');const fs=require('fs');const path=require('path');const os=require('os');const {EventEmitter}=require('events');const P=require('../electron/mpv-player');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'bm-mpv-'));
(async()=>{try{
assert.equal(P.bundledPlayer(root,true),null);fs.mkdirSync(path.join(root,'mpv'));fs.mkdirSync(path.join(root,'player'));fs.writeFileSync(path.join(root,'mpv/mpv.exe'),'');fs.writeFileSync(path.join(root,'player/cinema.lua'),'');const p=P.bundledPlayer(root,true);assert.equal(p.id,'bm-mpv');assert.equal(p.score,1000);assert.equal(p.name,'BankMovie Player');
const u='https://example.com/movie.mkv?x=1&y=2';const a=P.argsFor(p,u,{title:'--script=evil\nMovie',subtitlePath:'test.srt'});assert.deepEqual(a.slice(-2),['--',u]);assert.ok(a.includes('--tls-verify=yes'));assert.ok(a.includes('--no-config'));assert.ok(a.includes('--title=BankMovie Player'));assert.ok(!a.some(x=>x.startsWith('--wid=')||x.startsWith('--input-ipc-server=')));assert.ok(a.includes('--script='+p.script));assert.ok(a.includes('--force-media-title=--script=evil Movie'));assert.ok(a.includes('--sub-file=test.srt'));assert.throws(()=>P.argsFor(p,'file:///secret'));assert.throws(()=>P.argsFor(p,'https://user:pass@example.com'));assert.throws(()=>P.argsFor(p,'--script=evil'));assert.throws(()=>P.argsFor(p,'relative.mkv',{},true));
const local=path.join(root,'example.mkv');assert.deepEqual(P.argsFor(p,local,{},true).slice(-2),['--',local]);assert.ok(P.argsFor(p,local,{},true).includes('--sub-auto=exact'));
let ran=false;const result=await P.launch(p,u,{accent:'#FFD54A'},false,(exe,args,options)=>{assert.equal(options.env.BM_PLAYER_ACCENT,'FFD54A');assert.equal(exe,p.path);assert.equal(options.shell,false);assert.equal(args.at(-1),u);const e=new EventEmitter();e.unref=()=>{ran=true};queueMicrotask(()=>e.emit('spawn'));return e;});assert.equal(result.player.id,'bm-mpv');assert.ok(ran);
await P.launch(p,u,{accent:'invalid;--script=bad'},false,(_exe,_args,options)=>{assert.equal(options.env.BM_PLAYER_ACCENT,'327CF6');const e=new EventEmitter();e.unref=()=>{};queueMicrotask(()=>e.emit('spawn'));return e;});
await assert.rejects(P.launch(p,u,{},false,()=>{const e=new EventEmitter();queueMicrotask(()=>e.emit('error',Error('test')));return e;}),/MPV/);
const helper=path.join(root,'player/player-window-icon.exe');fs.writeFileSync(helper,'');let iconCalls=0;
assert.equal(P.applyPlayerWindowIcon(p,{pid:12345},(exe,args,options)=>{iconCalls++;assert.equal(exe,helper);assert.deepEqual(args,['12345']);assert.equal(options.shell,false);assert.equal(options.windowsHide,true);const c=new EventEmitter();c.unref=()=>{};return c;},'win32'),true);
assert.equal(P.applyPlayerWindowIcon(p,{pid:12345},()=>{throw Error('not Windows')},'linux'),false);
assert.equal(P.applyPlayerWindowIcon(p,{pid:'--evil'},()=>{throw Error('not a PID')},'win32'),false);assert.equal(iconCalls,1);
console.log('PASS: bundled discovery, online/local arguments, no shell, safe spawn error and title handling');
}finally{fs.rmSync(root,{recursive:true,force:true});}})().catch(e=>{console.error(e);process.exitCode=1;});
