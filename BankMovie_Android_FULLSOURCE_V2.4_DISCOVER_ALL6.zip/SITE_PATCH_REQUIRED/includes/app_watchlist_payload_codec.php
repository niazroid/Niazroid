<?php
/**
 * BankMovie app watchlist: lossless storage codec (v1).
 *
 * The app API remains unchanged: this representation exists only in
 * app_watchlist.payload_json. Old plaintext rows continue to work.
 */
declare(strict_types=1);

if (!function_exists('bm_watchlist_payload_is_packed')) {
    function bm_watchlist_payload_is_packed(string $value): bool {
        return str_starts_with($value, 'BMZ1:');
    }
}

if (!function_exists('bm_watchlist_payload_pack')) {
    function bm_watchlist_payload_pack(string $value): string {
        if ($value === '' || bm_watchlist_payload_is_packed($value) || !function_exists('gzcompress')) {
            return $value;
        }
        $compressed = @gzcompress($value, 6);
        if (!is_string($compressed)) return $value;
        $packed = 'BMZ1:' . base64_encode($compressed);
        // Only use compressed form when it is materially smaller.
        return strlen($packed) + 32 < strlen($value) ? $packed : $value;
    }
}

if (!function_exists('bm_watchlist_payload_unpack')) {
    function bm_watchlist_payload_unpack(string $value): ?string {
        if (!bm_watchlist_payload_is_packed($value)) return $value;
        if (!function_exists('gzuncompress')) return null;
        $binary = base64_decode(substr($value, 5), true);
        if (!is_string($binary) || $binary === '') return null;
        // MySQL MEDIUMTEXT maximum is 16 MiB. Refuse decompression bombs.
        $decoded = @gzuncompress($binary, 16777215);
        return is_string($decoded) ? $decoded : null;
    }
}

if (!function_exists('bm_watchlist_payload_decode')) {
    function bm_watchlist_payload_decode(?string $stored): array {
        $json = bm_watchlist_payload_unpack((string)$stored);
        if ($json === null) {
            error_log('BankMovie app watchlist: compressed payload could not be decoded');
            return [];
        }
        $data = json_decode($json, true);
        return is_array($data) ? $data : [];
    }
}
