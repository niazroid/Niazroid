<?php
/**
 * BankMovie watchlist quota. 50 distinct saved titles for regular accounts;
 * active VIP and site administrators have no limit.
 * All mutations must run inside bm_wl_with_user_lock() to serialize writes
 * across archive-1, main catalog, profile and desktop/mobile app endpoints.
 */
if (!defined('BM_WATCHLIST_FREE_LIMIT')) define('BM_WATCHLIST_FREE_LIMIT', 50);

if (!class_exists('BMWatchlistQuotaReached', false)) {
    final class BMWatchlistQuotaReached extends RuntimeException {
        private int $saved;
        public function __construct(int $saved) {
            parent::__construct('ظرفیت ۵۰ عنوان واچ‌لیست رایگان شما تکمیل شده است. برای ذخیره نامحدود فیلم و سریال، اشتراک VIP تهیه کنید.');
            $this->saved = $saved;
        }
        public function payload(): array {
            $url = function_exists('bm_vip_sales_url') ? bm_vip_sales_url('watchlist') : '/vip?feature=watchlist';
            return [
                'success' => false, 'status' => 'error',
                'error' => 'watchlist_limit_reached', 'error_code' => 'WATCHLIST_LIMIT_REACHED',
                'message' => $this->getMessage(), 'limit' => BM_WATCHLIST_FREE_LIMIT,
                'count' => $this->saved, 'vip_unlimited' => true,
                'purchase_url' => $url,
            ];
        }
    }
}

if (!function_exists('bm_wl_is_unlimited')) {
    function bm_wl_is_unlimited(?array $user): bool {
        if (!$user) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (in_array($role, ['admin', 'administrator'], true)) return true;
        if (function_exists('bm_vip_user_is_active')) return bm_vip_user_is_active($user);
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        return $expiry === '' || (($ts = strtotime($expiry)) !== false && $ts > time());
    }
}

if (!function_exists('bm_wl_with_user_lock')) {
    /** MySQL named advisory locks also serialize requests across distinct web endpoints. */
    function bm_wl_with_user_lock(PDO $pdo, int $userId, callable $callback) {
        $name = 'bm_wl_quota_u_' . $userId;
        $get = $pdo->prepare('SELECT GET_LOCK(?, 8)');
        $get->execute([$name]);
        if ((int)$get->fetchColumn() !== 1) throw new RuntimeException('Watchlist is busy. Please try again.');
        try { return $callback(); }
        finally {
            try { $release = $pdo->prepare('SELECT RELEASE_LOCK(?)'); $release->execute([$name]); }
            catch (Throwable $e) { error_log('Watchlist lock release: ' . $e->getMessage()); }
        }
    }
}

if (!function_exists('bm_wl_table_exists')) {
    function bm_wl_table_exists(PDO $pdo, string $table): bool {
        // Only fixed internal identifiers; no user-controlled table names.
        if (!in_array($table, ['watchlist', 'archive1_watchlist', 'app_watchlist'], true)) return false;
        $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $q->execute([$table]);
        return (int)$q->fetchColumn() > 0;
    }
}

if (!function_exists('bm_wl_link_key')) {
    function bm_wl_link_key(string $url): string {
        $url = trim($url);
        if ($url === '') return '';
        // Both absolute and site-local movie links must compare the same.
        $path = parse_url($url, PHP_URL_PATH);
        $query = parse_url($url, PHP_URL_QUERY);
        if ($path === false) return $url;
        $path = '/' . trim((string)$path, '/');
        return rtrim($path, '/') . ($query ? '?' . $query : '');
    }
}

if (!function_exists('bm_wl_saved_count')) {
    /**
     * Count all saved titles. App entries mirrored into legacy website tables
     * count once, not twice. Existing rows are never automatically removed.
     */
    function bm_wl_saved_count(PDO $pdo, int $userId): int {
        $seenDb = []; $seenLinks = []; $count = 0;
        if (bm_wl_table_exists($pdo, 'watchlist')) {
            $s = $pdo->prepare('SELECT movie_id FROM watchlist WHERE user_id = ?');
            $s->execute([$userId]);
            while (($v = $s->fetchColumn()) !== false) { $seenDb[(int)$v] = true; }
            $count += count($seenDb);
        }
        if (bm_wl_table_exists($pdo, 'archive1_watchlist')) {
            $s = $pdo->prepare('SELECT item_link FROM archive1_watchlist WHERE user_id = ?');
            $s->execute([$userId]);
            while (($v = $s->fetchColumn()) !== false) {
                $key = bm_wl_link_key((string)$v);
                if ($key !== '') $seenLinks[$key] = true;
            }
            $count += count($seenLinks);
        }
        if (bm_wl_table_exists($pdo, 'app_watchlist')) {
            $s = $pdo->prepare('SELECT storage_key, db_movie_id, archive_no, source_url FROM app_watchlist WHERE user_id = ?');
            $s->execute([$userId]);
            while ($item = $s->fetch(PDO::FETCH_ASSOC)) {
                $dbId = (int)($item['db_movie_id'] ?? 0);
                $linkKey = bm_wl_link_key((string)($item['source_url'] ?? ''));
                if ($dbId > 0 && isset($seenDb[$dbId])) continue;
                if (in_array((int)($item['archive_no'] ?? 0), [1,3,4,5], true)
                    && $linkKey !== '' && isset($seenLinks[$linkKey])) continue;
                // An app-only item gets one quota slot.
                $count++;
            }
        }
        return $count;
    }
}

if (!function_exists('bm_wl_require_room')) {
    /** Call only for a genuinely new item, inside bm_wl_with_user_lock(). */
    function bm_wl_require_room(PDO $pdo, ?array $user, int $userId): void {
        if (bm_wl_is_unlimited($user)) return;
        $count = bm_wl_saved_count($pdo, $userId);
        if ($count >= BM_WATCHLIST_FREE_LIMIT) throw new BMWatchlistQuotaReached($count);
    }
}
