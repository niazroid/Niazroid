-- READ FIRST. WRITE ACTION. Only AFTER deploying the ID-only API and full verified backup.
-- Execute one batch at a time; re-run until affected rows = 0; validate app+site after initial batch.
-- This modifies ONLY payload_json; titles/posters in separate columns are preserved.
-- Does not DELETE rows, and does not touch movies/download links.
UPDATE `vietop_bankmovie`.`app_watchlist`
SET payload_json = JSON_OBJECT(
    '_key', storage_key,
    'archive', archive_no,
    'type', item_type,
    'id', item_id
)
WHERE payload_json IS NULL
   OR LEFT(payload_json,5) = 'BMZ1:'
   OR OCTET_LENGTH(payload_json) > 240
ORDER BY id
LIMIT 250;
