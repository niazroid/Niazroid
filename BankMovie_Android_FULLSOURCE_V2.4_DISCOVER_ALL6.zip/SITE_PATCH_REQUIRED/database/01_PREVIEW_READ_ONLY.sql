-- READ ONLY: confirm payload state before any cleanup.
SELECT COUNT(*) AS total_rows,
       ROUND(COALESCE(SUM(OCTET_LENGTH(payload_json)),0)/1048576,2) AS payload_mib,
       SUM(LEFT(payload_json,5)='BMZ1:') AS compressed_old_rows,
       SUM(COALESCE(OCTET_LENGTH(payload_json),0)>240) AS large_rows
FROM `vietop_bankmovie`.`app_watchlist`;
