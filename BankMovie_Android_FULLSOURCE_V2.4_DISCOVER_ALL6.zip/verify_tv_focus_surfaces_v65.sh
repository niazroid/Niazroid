#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.6 VIDEO REPRO DETAIL CATEGORY SEARCH ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v76_video_repro.sh
  echo 'V7_6_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.5 DETAIL CATEGORY SEARCH STABILITY' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v75_detail_category_search_stability.sh
  echo 'V7_5_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.4 SEARCH CATEGORY DETAIL NATIVE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v74_search_category_detail_native.sh
  echo 'V7_4_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.3 SEARCH CATEGORY DETAIL ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v73_search_category_detail.sh
  echo 'V7_3_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v72_search_watchlist_archive4_sticker.sh
  echo 'V7_2_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing V6.5/V6.6 marker: $2" >&2; exit 1; }; }

# Weekly: V6.6 supersedes the old detached-child rebuild. Initial TV render must
# happen only after attach; refresh remains as an empty-row fallback.
need "$MAIN" 'private var tvHomeWeeklyRefreshAction: (() -> Unit)? = null'
need "$MAIN" 'ROOT FIX 2.3/V6.6: never create the initial Weekly focus children while'
need "$MAIN" 'private fun requestHomeTvWeeklyItemEntry(): Boolean {'

# Continue Watching exact rails/full-list.
need "$MAIN" 'tag = "bm_tv_profile_continue_row"'
need "$MAIN" 'tag = "bm_tv_continue_full_list"'
need "$MAIN" 'private fun wireTvContinueRailExact(header: View, row: ViewGroup)'
need "$MAIN" 'private fun wireTvContinueFullListExact(list: ViewGroup)'

# Box Office strict rank order + direct row keys.
need "$MAIN" 'val wireBoxOffice = {'
need "$MAIN" 'API order is not guaranteed to match the displayed rank.'
need "$MAIN" '"boxoffice" -> content.findViewWithTag<View>("bm_tv_boxoffice_row_0")'
python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
a=s.index('private fun showBoxOffice()')
b=s.index('private fun showCollections()', a)
chunk=s[a:b]
for line in chunk.splitlines():
    if line.strip().startswith('wireTvDeterministicSurface(page)'):
        raise SystemExit('V6.5/V6.6 guard failed: Box Office still uses geometry deterministic surface')
PY

# Advanced filters: dialog-local direct key routing plus native nextFocus fallback.
need "$MAIN" 'fun wireAdvancedFiltersTvExact()'
need "$MAIN" 'fun installDirectRoutes(view: View, routes: Map<Int, () -> View?>)'
need "$MAIN" 'AlertDialog receives DPAD in its own Window.'
need "$MAIN" 'android.view.KeyEvent.KEYCODE_DPAD_DOWN to { firstSelector ?: yearFromInput }'
need "$MAIN" 'dialog.setOnKeyListener'

# Non-Home controls must never become a hard dead end.
need "$MAIN" 'Other screens must NOT swallow a direction when our explicit'
need "$MAIN" 'V6.7 ROOT: never swallow an unhandled DPAD event.'

echo 'TV_FOCUS_SURFACES_V65_ROOT_OK'
