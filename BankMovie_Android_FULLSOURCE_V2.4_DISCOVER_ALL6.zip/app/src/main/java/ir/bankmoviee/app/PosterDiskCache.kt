package ir.bankmoviee.app

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Bound disk cache for compressed original poster bytes, not decoded bitmaps.
 * Reads and writes happen only on the shared image executor (never UI thread).
 */
internal object PosterDiskCache {
    private const val MAX_BYTES = 80L * 1024L * 1024L
    private const val MAX_FILE = 8L * 1024L * 1024L
    private val lock = Any()
    private var writesSinceTrim = 0

    private fun file(context: Context, url: String): File {
        val digest = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        val name = digest.joinToString("") { "%02x".format(it) }
        val dir = File(context.cacheDir, "bm_posters_v2")
        if (!dir.exists()) dir.mkdirs()
        return File(dir, "$name.img")
    }

    fun read(context: Context, url: String): ByteArray? = synchronized(lock) {
        runCatching {
            val f = file(context, url)
            if (!f.isFile || f.length() !in 1..MAX_FILE) return@synchronized null
            f.setLastModified(System.currentTimeMillis())
            f.readBytes()
        }.getOrNull()
    }

    fun write(context: Context, url: String, bytes: ByteArray) {
        if (bytes.size.toLong() !in 1..MAX_FILE) return
        synchronized(lock) {
            runCatching {
                val dest = file(context, url)
                val temp = File(dest.parentFile, dest.name + ".tmp")
                temp.writeBytes(bytes)
                if (!temp.renameTo(dest)) {
                    dest.writeBytes(bytes)
                    temp.delete()
                }
                writesSinceTrim++
                if (writesSinceTrim >= 12) {
                    writesSinceTrim = 0
                    val entries = dest.parentFile?.listFiles { f -> f.isFile && f.extension == "img" }
                        ?.sortedBy { it.lastModified() }.orEmpty()
                    var used = entries.sumOf { it.length() }
                    for (old in entries) {
                        if (used <= MAX_BYTES) break
                        val n = old.length()
                        if (old.delete()) used -= n
                    }
                }
            }
        }
    }
}
