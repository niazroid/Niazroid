package ir.bankmoviee.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.view.Window
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class OnboardingActivity : Activity() {

    private data class SetupPalette(
        val bg: Int,
        val panel: Int,
        val panel2: Int,
        val stroke: Int,
        val text: Int,
        val muted: Int,
        val primary: Int,
        val onPrimary: Int,
        val light: Boolean
    )

    private var step = 0
    private var renderedStep = -1
    private val totalSteps = 5
    private var required = true

    private var language = "fa"
    // Theme is user-selectable from Quick Setup and Profile → Settings → Appearance.
    // Keep black as the default for existing installs, while exposing the restored white theme.
    private var theme = "black"
    private var accent = "blue"
    private var appFont = "bankmovie"
    private var mobileNavStyle = "classic"
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackground = "black"
    private var subtitleScale = 112
    private var subtitleFont = "font"
    private var subtitleBold = true
    private var subtitlePosition = 0
    private var subtitlePreviewText: TextView? = null
    private var subtitlePreviewContainer: FrameLayout? = null
    private var downloadBehavior = "ask"
    private var seekSeconds = 10
    private var autoNext = true
    private var tvFocusIndex = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        required = intent.getBooleanExtra("required", true)
        val prefs = UiPreferences.prefs(this)
        language = prefs.getString("lang_code", "fa") ?: "fa"
        theme = UiPreferences.themeMode(this)
        accent = UiPreferences.accentName(this)
        appFont = UiPreferences.appFontMode(this)
        mobileNavStyle = UiPreferences.mobileNavStyle(this)
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackground = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleFont = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePosition = UiPreferences.subtitlePosition(this)
        downloadBehavior = UiPreferences.downloadBehavior(this)
        seekSeconds = UiPreferences.seekSeconds(this)
        autoNext = UiPreferences.autoNext(this)
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (step > 0) {
            step--
            render()
        } else if (!required) {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun fa(): Boolean = language != "en"
    private fun tr(fa: String, en: String): String = RemoteTextStore.resolve(this, fa, en)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK) ||
            packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEVISION) ||
            resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun tvFocusDrawable(radius: Int): android.graphics.drawable.Drawable {
        val p = palette()
        val outer = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), p.primary)
        }
        val inner = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp((radius - 2).coerceAtLeast(2)).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), Color.argb(220, 255, 255, 255))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(outer, inner)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun unclampTvFocus(view: View) {
        var parent = view.parent
        while (parent is ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
    }

    private fun setTvHaloState(view: View, focused: Boolean, radius: Int, scale: Float) {
        val originalForeground = view.getTag(R.id.bm_focus_restore_key) as? android.graphics.drawable.Drawable
        val originalElevation = (view.getTag(R.id.bm_tv_focus_elevation) as? Float) ?: view.elevation
        view.animate().cancel()
        if (focused) unclampTvFocus(view)
        view.foreground = if (focused) tvFocusDrawable(radius) else originalForeground
        view.elevation = if (focused) dp(18).toFloat() else originalElevation
        view.translationZ = if (focused) dp(8).toFloat() else 0f
        view.alpha = if (focused) 1f else view.alpha.coerceAtLeast(0.96f)
        view.animate()
            .scaleX(if (focused) scale else 1f)
            .scaleY(if (focused) scale else 1f)
            .setDuration(if (focused) 105L else 80L)
            .setInterpolator(android.view.animation.DecelerateInterpolator())
            .start()
        view.invalidate()
    }

    private fun applyTvFocusHalo(view: View, radius: Int = 18, scale: Float = 1.045f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) != true) {
            view.setTag(R.id.bm_tv_focus_bound, true)
            view.setTag(R.id.bm_focus_restore_key, view.foreground)
            view.setTag(R.id.bm_tv_focus_elevation, view.elevation)
            view.setTag(R.id.bm_tv_focus_radius, radius)
            view.setTag(R.id.bm_tv_focus_scale, scale)
            view.isFocusable = true
            view.isFocusableInTouchMode = false
            if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
            unclampTvFocus(view)
            view.setOnFocusChangeListener { target, focused ->
                val targetRadius = (target.getTag(R.id.bm_tv_focus_radius) as? Int) ?: radius
                val targetScale = (target.getTag(R.id.bm_tv_focus_scale) as? Float) ?: scale
                setTvHaloState(target, focused, targetRadius, targetScale)
            }
        } else {
            view.setTag(R.id.bm_tv_focus_radius, radius)
            view.setTag(R.id.bm_tv_focus_scale, scale)
        }
        // A newly rebuilt step can already own focus before the listener is
        // attached. Apply the visual state immediately so stage 5 never loses
        // its halo after changing language or re-rendering.
        setTvHaloState(view, view.hasFocus(), radius, scale)
    }

    private fun refreshTvHalos(focusables: List<View>, focused: View?) {
        focusables.forEach { view ->
            val radius = (view.getTag(R.id.bm_tv_focus_radius) as? Int) ?: if (view is SeekBar) 14 else 18
            val scale = (view.getTag(R.id.bm_tv_focus_scale) as? Float) ?: if (view is SeekBar) 1.025f else 1.045f
            setTvHaloState(view, view === focused || view.hasFocus(), radius, scale)
        }
    }

    private fun isTvActivateKey(keyCode: Int): Boolean = keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
        keyCode == KeyEvent.KEYCODE_ENTER ||
        keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
        keyCode == KeyEvent.KEYCODE_BUTTON_A ||
        keyCode == KeyEvent.KEYCODE_SPACE

    private fun tvFocusTargetId(view: View, keyCode: Int): Int = when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP -> view.nextFocusUpId
        KeyEvent.KEYCODE_DPAD_DOWN -> view.nextFocusDownId
        KeyEvent.KEYCODE_DPAD_LEFT -> view.nextFocusLeftId
        KeyEvent.KEYCODE_DPAD_RIGHT -> view.nextFocusRightId
        else -> View.NO_ID
    }

    private fun bindTvRemoteKeys(view: View) {
        if (!isTvLike() || view is SeekBar) return
        view.setOnKeyListener { target, keyCode, event ->
            when {
                isTvActivateKey(keyCode) -> {
                    if (event.action == KeyEvent.ACTION_UP && event.repeatCount == 0 && target.isEnabled) {
                        target.performClick()
                    }
                    true
                }
                keyCode == KeyEvent.KEYCODE_DPAD_UP ||
                    keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
                    keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
                    keyCode == KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    val targetId = tvFocusTargetId(target, keyCode)
                    if (targetId == View.NO_ID) {
                        false
                    } else {
                        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                            target.rootView.findViewById<View>(targetId)?.takeIf {
                                it.visibility == View.VISIBLE && it.isEnabled && it.isFocusable
                            }?.requestFocus()
                        }
                        true
                    }
                }
                else -> false
            }
        }
    }

    private fun collectTvFocusables(root: View, out: MutableList<View>) {
        if (root.visibility != View.VISIBLE || !root.isEnabled) return
        val interactive = root.isFocusable && (root.hasOnClickListeners() || root is SeekBar)
        if (interactive) out += root
        if (root is ViewGroup) {
            for (i in 0 until root.childCount) collectTvFocusables(root.getChildAt(i), out)
        }
    }

    private fun captureTvFocusIndex() {
        if (!isTvLike()) return
        val current = currentFocus ?: return
        val all = mutableListOf<View>()
        collectTvFocusables(window.decorView, all)
        val index = all.indexOf(current)
        if (index >= 0) tvFocusIndex = index
    }

    private fun isDescendantOf(view: View, ancestor: View): Boolean {
        var current: View? = view
        while (current != null) {
            if (current === ancestor) return true
            current = current.parent as? View
        }
        return false
    }

    private fun wireTvFocusGraph(root: View) {
        val nodes = mutableListOf<View>()
        collectTvFocusables(root, nodes)
        if (nodes.size < 2) return
        nodes.forEach { if (it.id == View.NO_ID) it.id = View.generateViewId() }

        fun center(view: View): Pair<Int, Int> {
            val location = IntArray(2)
            view.getLocationOnScreen(location)
            return (location[0] + view.width / 2) to (location[1] + view.height / 2)
        }

        nodes.forEach { node ->
            val (x, y) = center(node)
            val others = nodes.filter { it !== node }
            fun nearest(horizontal: Boolean, positive: Boolean): View? = others
                .map { it to center(it) }
                .filter { (candidate, c) ->
                    val correctSide = if (horizontal) {
                        if (positive) c.first > x else c.first < x
                    } else {
                        if (positive) c.second > y else c.second < y
                    }
                    val sameRow = !horizontal || kotlin.math.abs(c.second - y) <= maxOf(node.height, candidate.height) + dp(14)
                    correctSide && sameRow
                }
                .minByOrNull { (_, c) ->
                    val dx = kotlin.math.abs(c.first - x)
                    val dy = kotlin.math.abs(c.second - y)
                    if (horizontal) dx * 4 + dy else dy * 4 + dx
                }?.first

            if (node !is SeekBar) {
                nearest(true, false)?.let { node.nextFocusLeftId = it.id }
                nearest(true, true)?.let { node.nextFocusRightId = it.id }
            }
            nearest(false, false)?.let { node.nextFocusUpId = it.id }
            nearest(false, true)?.let { node.nextFocusDownId = it.id }
        }
    }

    private fun prepareTvControls(root: View, body: View, back: View, next: View, stepChanged: Boolean) {
        if (!isTvLike()) return
        val focusables = mutableListOf<View>()
        fun walk(view: View) {
            if (view is ViewGroup) {
                view.clipChildren = false
                view.clipToPadding = false
                view.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
            }
            val isScroll = view is ScrollView || view is HorizontalScrollView
            if (isScroll) {
                view.isFocusable = false
                view.isFocusableInTouchMode = false
            }
            if (!isScroll && view.isEnabled && (view.hasOnClickListeners() || view is SeekBar)) {
                if (view is SeekBar) view.isFocusable = true
                applyTvFocusHalo(view, if (view is SeekBar) 14 else 18, if (view is SeekBar) 1.025f else 1.045f)
                focusables += view
            }
            if (view is ViewGroup) for (i in 0 until view.childCount) walk(view.getChildAt(i))
        }
        walk(root)

        root.viewTreeObserver.addOnGlobalFocusChangeListener(
            ViewTreeObserver.OnGlobalFocusChangeListener { _, newFocus ->
                refreshTvHalos(focusables, newFocus)
            }
        )

        root.postDelayed({
            wireTvFocusGraph(root)

            if (back.id == View.NO_ID) back.id = View.generateViewId()
            if (next.id == View.NO_ID) next.id = View.generateViewId()

            val bodyFocusables = mutableListOf<View>()
            collectTvFocusables(body, bodyFocusables)
            bodyFocusables.forEach { if (it.id == View.NO_ID) it.id = View.generateViewId() }

            // The bottom-most interactive row must always lead to Continue/Save.
            // This explicitly fixes the TV loop between the last toggle and Back.
            if (bodyFocusables.isNotEmpty()) {
                fun centerY(view: View): Int {
                    val pos = IntArray(2)
                    view.getLocationOnScreen(pos)
                    return pos[1] + view.height / 2
                }
                fun centerX(view: View): Int {
                    val pos = IntArray(2)
                    view.getLocationOnScreen(pos)
                    return pos[0] + view.width / 2
                }
                val maxY = bodyFocusables.maxOf(::centerY)
                val bottomRow = bodyFocusables.filter { maxY - centerY(it) <= dp(34) }
                bottomRow.forEach { it.nextFocusDownId = next.id }

                val nextX = centerX(next)
                val backX = centerX(back)
                val nextUp = bottomRow.minByOrNull { kotlin.math.abs(centerX(it) - nextX) } ?: bodyFocusables.last()
                val backUp = bottomRow.minByOrNull { kotlin.math.abs(centerX(it) - backX) } ?: bodyFocusables.last()
                next.nextFocusUpId = nextUp.id
                if (back.isEnabled) back.nextFocusUpId = backUp.id
            }

            // On the navigation row, either horizontal direction can reach the
            // other button. This also supports remotes whose left/right mapping
            // is reversed under RTL.
            if (back.isEnabled) {
                back.nextFocusLeftId = next.id
                back.nextFocusRightId = next.id
                next.nextFocusLeftId = back.id
                next.nextFocusRightId = back.id
            }

            focusables.forEach(::bindTvRemoteKeys)

            val all = mutableListOf<View>()
            collectTvFocusables(root, all)
            val target = if (stepChanged) {
                all.firstOrNull { isDescendantOf(it, body) } ?: next
            } else {
                all.getOrNull(tvFocusIndex.coerceIn(0, (all.size - 1).coerceAtLeast(0))) ?: next
            }
            target.requestFocus()
            refreshTvHalos(focusables, target)
            root.postDelayed({ refreshTvHalos(focusables, currentFocus) }, 140L)
        }, 140L)
    }

    private fun palette(): SetupPalette {
        val primary = UiPreferences.accentColor(accent)
        val onPrimary = if (UiPreferences.contrastRatio(Color.BLACK, primary) >= UiPreferences.contrastRatio(Color.WHITE, primary)) Color.BLACK else Color.WHITE
        return when (theme) {
            "light" -> SetupPalette(
                Color.rgb(242, 244, 248), Color.WHITE, Color.rgb(235, 239, 246), Color.rgb(207, 214, 226),
                Color.rgb(20, 23, 29), Color.rgb(88, 96, 111), primary, onPrimary, true
            )
            "dark" -> SetupPalette(
                Color.rgb(3, 8, 17), Color.rgb(10, 19, 34), Color.rgb(16, 29, 48), Color.rgb(45, 68, 100),
                Color.WHITE, Color.rgb(181, 192, 210), primary, onPrimary, false
            )
            else -> SetupPalette(
                Color.BLACK, Color.rgb(14, 14, 16), Color.rgb(25, 25, 29), Color.rgb(55, 55, 62),
                Color.WHITE, Color.rgb(190, 190, 198), primary, onPrimary, false
            )
        }
    }

    private fun rounded(color: Int, radius: Int, border: Int = Color.TRANSPARENT, borderWidth: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(color)
            if (border != Color.TRANSPARENT) setStroke(dp(borderWidth), border)
        }

    private fun text(
        value: String,
        size: Float = 14f,
        bold: Boolean = false,
        color: Int = palette().text,
        gravityValue: Int = if (fa()) Gravity.RIGHT else Gravity.LEFT
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = gravityValue
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun localTypeface(bold: Boolean = false): Typeface =
        BankmovieFonts.forMode(this, appFont, bold)

    private fun applyLocalFont(view: View) {
        if (view is TextView) {
            val tagValue = view.tag?.toString().orEmpty()
            if (!tagValue.startsWith("font_preview_") && tagValue != "preserve_typeface") {
                val isBold = ((view.typeface?.style ?: Typeface.NORMAL) and Typeface.BOLD) != 0
                view.typeface = localTypeface(isBold)
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyLocalFont(view.getChildAt(i))
        }
    }

    private fun persistDraft() {
        UiPreferences.saveThemeSelection(this, theme)
        UiPreferences.prefs(this).edit()
            .putString("lang_code", language)
            .putString(UiPreferences.KEY_ACCENT, accent)
            .putString(UiPreferences.KEY_APP_FONT, appFont)
            .putString(UiPreferences.KEY_MOBILE_NAV_STYLE, mobileNavStyle)
            .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
            .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
            .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackground)
            .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
            .putString(UiPreferences.KEY_SUB_FONT, subtitleFont)
            .putBoolean(UiPreferences.KEY_SUB_BOLD, subtitleBold)
            .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePosition)
            .putString(UiPreferences.KEY_DOWNLOAD_BEHAVIOR, downloadBehavior)
            .putInt(UiPreferences.KEY_SEEK_SECONDS, seekSeconds)
            .putBoolean(UiPreferences.KEY_AUTO_NEXT, autoNext)
            .apply()
    }

    private fun updateSubtitlePreviewPosition(animate: Boolean = true) {
        val preview = subtitlePreviewContainer ?: return
        val textView = subtitlePreviewText ?: return
        val params = (textView.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(-2, -2)
        params.gravity = when (subtitlePosition) {
            2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            1 -> Gravity.CENTER
            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        params.topMargin = dp(12)
        params.bottomMargin = dp(12)
        textView.layoutParams = params
        if (animate) {
            textView.animate().cancel()
            textView.alpha = 0.68f
            textView.scaleX = 0.97f
            textView.scaleY = 0.97f
            textView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        preview.invalidate()
    }

    private fun choice(label: String, active: Boolean, click: () -> Unit): TextView {
        val p = palette()
        return text(label, 13f, true, if (active) p.onPrimary else p.text, Gravity.CENTER).apply {
            isClickable = true
            isFocusable = true
            isFocusableInTouchMode = false
            setPadding(dp(10), dp(11), dp(10), dp(11))
            background = if (active) rounded(p.primary, 17) else rounded(p.panel2, 17, p.stroke)
            setOnClickListener { click(); persistDraft() }
        }
    }

    private fun sectionTitle(label: String): TextView = text(label, 14f, true).apply {
        setPadding(dp(2), dp(5), dp(2), dp(8))
    }

    private fun stepIcon(): Int = when (step) {
        0 -> R.drawable.ic_setup_magic
        1 -> R.drawable.ic_setup_theme
        2 -> R.drawable.ic_setup_subtitle
        3 -> R.drawable.ic_setup_play
        else -> R.drawable.ic_setup_language
    }

    private fun setupHeroTitle(): String = when (step) {
        0 -> tr("تجربه را برای خودت تنظیم کن", "Make it yours")
        1 -> tr("ظاهر دلخواهت را بساز", "Choose your look")
        2 -> tr("زیرنویس دقیقاً مطابق سلیقه تو", "Tune your subtitles")
        3 -> tr("پخش روان و دانلود راحت", "Smooth playback and downloads")
        else -> tr("همه‌چیز آماده است", "You are all set")
    }

    private fun render() {
        captureTvFocusIndex()
        val stepChanged = renderedStep != step
        val p = palette()
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            var flags = window.decorView.systemUiVisibility
            flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
            window.decorView.systemUiVisibility = flags
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            background = rounded(p.panel, 0)
        }
        val heroRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
        }
        heroRow.addView(FrameLayout(this).apply {
            background = rounded(UiPreferences.blend(p.panel2, p.primary, 0.18f), 18, p.primary)
            addView(ImageView(this@OnboardingActivity).apply {
                setImageResource(stepIcon())
                setColorFilter(p.primary)
                setPadding(dp(13), dp(13), dp(13), dp(13))
            }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(12) })
        heroRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text(setupHeroTitle(), 18f, true))
            addView(text(tr("مرحله ${step + 1} از $totalSteps", "Step ${step + 1} of $totalSteps"), 11.5f, false, p.muted).apply { setPadding(0, dp(4), 0, 0) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(heroRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
        val progressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        repeat(totalSteps) { index ->
            progressRow.addView(View(this).apply {
                background = rounded(if (index <= step) p.primary else p.stroke, 99)
            }, LinearLayout.LayoutParams(0, dp(4), 1f).apply {
                if (index > 0) marginStart = dp(6)
            })
        }
        top.addView(progressRow)
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        when (step) {
            0 -> renderIntro(body)
            1 -> renderAppearance(body)
            2 -> renderSubtitles(body)
            3 -> renderPlayback(body)
            else -> renderLanguageAndSummary(body)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(16))
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            background = rounded(p.panel, 0)
        }
        val back = choice(tr("قبلی", "Back"), false) {
            if (step > 0) { step--; render() } else if (!required) { setResult(RESULT_CANCELED); finish() }
        }.apply { alpha = if (step == 0 && required) 0.35f else 1f; isEnabled = step > 0 || !required }
        val nextLabel = if (step == totalSteps - 1) tr("ذخیره و شروع", "Save and start") else tr("ادامه", "Continue")
        val next = choice(nextLabel, true) {
            if (step < totalSteps - 1) { step++; render() } else finishSetup()
        }
        nav.addView(back, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(7) })
        nav.addView(next, LinearLayout.LayoutParams(0, dp(50), 1.35f).apply { marginStart = dp(7) })
        root.addView(nav)

        applyLocalFont(root)
        renderedStep = step
        setContentView(root)
        prepareTvControls(root, body, back, next, stepChanged)
        if (stepChanged) {
            root.alpha = 0f
            root.translationY = dp(10).toFloat()
            root.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(180L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun renderIntro(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("تنظیم اولیه در کمتر از یک دقیقه", "Set up your experience in under a minute"), 22f, true))
        body.addView(text(
            tr("فقط یک‌بار از شما پرسیده می‌شود و همه انتخاب‌ها تا زمان حذف برنامه ذخیره می‌مانند.", "This is shown once. Your choices remain saved until the app is uninstalled."),
            13f, false, p.muted
        ).apply { setPadding(0, dp(8), 0, dp(16)) })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(p.panel, 22, p.stroke)
        }
        panel.addView(text(tr("در این مرحله تنظیم می‌شود", "This setup configures"), 15f, true))
        listOf(
            tr("• رنگ اصلی و فونت برنامه", "• Accent color and app font"),
            tr("• رنگ، اندازه و ظاهر زیرنویس", "• Subtitle color, size and style"),
            tr("• روش دانلود و تنظیمات پخش", "• Download method and playback defaults"),
            tr("• زبان فارسی یا English", "• Persian or English language")
        ).forEach { item -> panel.addView(text(item, 13f, false, p.muted).apply { setPadding(0, dp(8), 0, 0) }) }
        body.addView(panel, LinearLayout.LayoutParams(-1, -2))

        body.addView(text(
            tr("مجوز اعلان قبل از این مرحله درخواست شد تا پیام‌های ادمین و وضعیت دانلودها را دریافت کنید.", "Notification permission was requested first so you can receive admin messages and download status."),
            12.5f, false, p.muted
        ).apply { setPadding(0, dp(15), 0, dp(5)) })
        body.addView(text(
            tr("بعداً همه این موارد از پروفایل ← تنظیمات قابل تغییر است.", "You can change all of these later from Profile → Settings."),
            12.5f, true, p.primary
        ))
    }

    private fun onboardingToggle(
        title: String,
        subtitle: String,
        checked: Boolean,
        onChanged: (Boolean) -> Unit
    ): View {
        val p = palette()
        val toggle = BmToggleView(this).apply {
            setChecked(checked, animate = false)
            if (isTvLike()) {
                isFocusable = false
                isClickable = false
            }
            setOnCheckedChangeListener {
                onChanged(it)
                persistDraft()
            }
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(10))
            background = rounded(p.panel, 20, p.stroke)
            if (isTvLike()) {
                isClickable = true
                isFocusable = true
                isFocusableInTouchMode = false
                setOnClickListener {
                    toggle.setChecked(!toggle.isCheckedState, animate = true, notify = true)
                }
            }
            addView(toggle, LinearLayout.LayoutParams(dp(120), dp(38)).apply { marginEnd = dp(13) })
            addView(LinearLayout(this@OnboardingActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = if (fa()) Gravity.RIGHT else Gravity.LEFT
                addView(text(title, 13.8f, true))
                addView(text(subtitle, 10.8f, false, p.muted).apply { setPadding(0, dp(3), 0, 0) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
    }

    private fun renderAppearance(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("ظاهر و فونت", "Look and font"), 22f, true))
        body.addView(text(tr("تغییرها همین‌جا به‌صورت زنده نمایش داده می‌شوند.", "Changes are previewed here instantly."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        // V7.47.1.25: Android TV is dark-only. Mobile keeps the local theme switch.
        if (DeviceProfile.isTv(this)) {
            theme = "black"
            UiPreferences.saveThemeSelection(this, "black")
            body.addView(sectionTitle(tr("تم تلویزیون", "TV theme")))
            body.addView(text(
                tr("مشکی سینمایی", "Cinematic black"),
                12.5f, true, p.text
            ).apply {
                gravity = Gravity.CENTER_VERTICAL or (if (fa()) Gravity.RIGHT else Gravity.LEFT)
                setPadding(dp(13), dp(10), dp(13), dp(10))
                background = rounded(p.panel2, 18, p.stroke)
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(16) })
        } else {
            body.addView(sectionTitle(tr("تم برنامه", "App theme")))
            body.addView(text(
                tr("سفید: زمینه روشن با متن مشکی • مشکی: ظاهر سینمایی فعلی", "Light: bright surfaces with dark text • Black: current cinematic look"),
                11.8f, false, p.muted
            ).apply { setPadding(0, 0, 0, dp(8)) })
            val themeRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
                background = rounded(p.panel2, 18, p.stroke)
            }
            themeRow.addView(text(tr("مشکی", "Black"), 12.5f, true, if (theme != "light") p.text else p.muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, dp(44), 1f))
            themeRow.addView(BmThemeSwitchView(this).apply {
                setDark(theme != "light", animate = false, notify = false)
                setOnDarkChangeListener { isDark ->
                    theme = if (isDark) "black" else "light"
                    UiPreferences.saveThemeSelection(this@OnboardingActivity, theme)
                    persistDraft()
                    render()
                }
            }, LinearLayout.LayoutParams(dp(90), dp(40)).apply { marginStart = dp(8); marginEnd = dp(8) })
            themeRow.addView(text(tr("سفید", "Light"), 12.5f, true, if (theme == "light") p.text else p.muted).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(0, dp(44), 1f))
            body.addView(themeRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
            body.addView(text(
                tr("تم و رنگ اپ فقط داخل خود برنامه ذخیره می‌شوند و از تم سایت جدا هستند.", "App theme and Accent are saved locally and stay separate from the website theme."),
                10.8f, false, p.muted
            ).apply { setPadding(0, 0, 0, dp(16)) })
        }

        body.addView(sectionTitle(tr("رنگ اصلی", "Accent color")))
        val colorScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3), 0, dp(8)) }
        listOf("blue", "gold", "orange", "red", "purple", "teal", "green").forEach { name ->
            val color = UiPreferences.accentColor(name)
            colorRow.addView(TextView(this).apply {
                text = if (accent == name) "✓" else ""
                setTextColor(if (name == "gold") Color.BLACK else Color.WHITE)
                textSize = 17f
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                isFocusableInTouchMode = false
                background = rounded(color, 999, if (accent == name) p.text else Color.argb(80, 255, 255, 255), if (accent == name) 2 else 1)
                setOnClickListener { accent = name; persistDraft(); render() }
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
        }
        colorScroll.addView(colorRow)
        body.addView(colorScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("فونت برنامه", "App font")))
        val fontPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        BankmovieFonts.options.forEach { option ->
            val selected = appFont == option.key
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                isClickable = true
                isFocusable = true
                isFocusableInTouchMode = false
                background = rounded(if (selected) UiPreferences.blend(p.panel2, p.primary, 0.14f) else p.panel, 20, if (selected) p.primary else p.stroke, if (selected) 2 else 1)
                setOnClickListener { appFont = option.key; persistDraft(); render() }
            }
            card.addView(text((if (selected) "✓  " else "") + tr(option.faLabel, option.enLabel), 14f, true, if (selected) p.primary else p.text))
            card.addView(TextView(this).apply {
                text = "فیلم و سریال‌های تازه\nNew movies & series"
                setTextColor(p.text)
                textSize = 16f
                gravity = if (fa()) Gravity.RIGHT else Gravity.LEFT
                typeface = BankmovieFonts.forMode(this@OnboardingActivity, option.key, true)
                tag = "font_preview_${option.key}"
                setLineSpacing(dp(3).toFloat(), 1f)
                setPadding(0, dp(8), 0, 0)
            })
            fontPanel.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        body.addView(fontPanel)

        if (!isTvLike()) {
            body.addView(sectionTitle(tr("مدل ناوبری موبایل", "Mobile navigation style")).apply {
                setPadding(dp(2), dp(12), dp(2), dp(8))
            })
            body.addView(text(
                tr("ظاهر نوار پایین را همین‌جا انتخاب کنید؛ بعداً هم از تنظیمات قابل تغییر است.", "Choose the bottom navigation look here. You can change it later from Settings."),
                12f, false, p.muted
            ).apply { setPadding(0, 0, 0, dp(9)) })

            val navOptions = listOf(
                Triple("classic", "فعلی بانک مووی", "Bankmovie current"),
                Triple("minimal", "مینیمال", "Minimal"),
                Triple("glass", "شیشه‌ای", "Glass"),
                Triple("floating", "شناور", "Floating"),
                Triple("neumorph", "نئومورف", "Neumorph"),
                Triple("pill", "کپسولی", "Pill"),
                Triple("center_fab", "دکمه مرکزی", "Center FAB"),
                Triple("gradient", "گرادیان", "Gradient"),
                Triple("outline", "آوت‌لاین", "Outline"),
                Triple("indicator", "نشانگر", "Indicator"),
                Triple("curved", "خمیده", "Curved")
            )
            val navScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_NEVER
            }
            val navRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(2), 0, dp(5))
            }
            navOptions.forEachIndexed { index, option ->
                navRow.addView(
                    choice(tr(option.second, option.third), mobileNavStyle == option.first) {
                        mobileNavStyle = option.first
                        render()
                    },
                    LinearLayout.LayoutParams(dp(124), dp(46)).apply {
                        if (index > 0) marginStart = dp(7)
                    }
                )
            }
            navScroll.addView(navRow)
            body.addView(navScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(4) })
        }
    }

    private fun renderSubtitles(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("زیرنویس", "Subtitles"), 22f, true))
        body.addView(text(tr("پیش‌نمایش زیرنویس با انتخاب‌های شما", "Live subtitle preview"), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(12)) })

        val preview = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(15, 22, 34), Color.rgb(31, 39, 53))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), p.stroke)
            }
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }
        subtitlePreviewContainer = preview
        preview.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_setup_play)
            setColorFilter(Color.argb(34, 255, 255, 255))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(42), dp(42), dp(42), dp(42))
        }, FrameLayout.LayoutParams(-1, -1))
        preview.addView(TextView(this).apply {
            text = tr("پیش‌نمایش زنده", "LIVE PREVIEW")
            setTextColor(Color.argb(170, 255, 255, 255))
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(90, 0, 0, 0), 10)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply { leftMargin = dp(10); topMargin = dp(10) })
        val bgColor = when (subtitleBackground) {
            "transparent" -> Color.TRANSPARENT
            "white" -> Color.argb(225, 255, 255, 255)
            "yellow" -> Color.argb(220, 255, 235, 59)
            else -> Color.argb(215, 0, 0, 0)
        }
        subtitlePreviewText = TextView(this).apply {
            text = "این یک نمونه زیرنویس فارسی است\nThis is an English subtitle sample"
            setTextColor(subtitleTextColor)
            textSize = (subtitleScale / 8.2f).coerceIn(12f, 22f)
            gravity = Gravity.CENTER
            typeface = BankmovieFonts.forMode(this@OnboardingActivity, subtitleFont, subtitleBold)
            tag = "preserve_typeface"
            background = rounded(bgColor, 8)
            setPadding(dp(8), dp(5), dp(8), dp(5))
            alpha = if (subtitleEnabled) 1f else 0.35f
        }
        subtitlePreviewText?.let { previewText ->
            preview.addView(previewText, FrameLayout.LayoutParams(-2, -2))
        }
        updateSubtitlePreviewPosition(animate = false)
        body.addView(preview, LinearLayout.LayoutParams(-1, dp(178)).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("نمایش زیرنویس", "Show subtitles")))
        body.addView(onboardingToggle(
            tr("نمایش زیرنویس", "Show subtitles"),
            tr("فعال یا غیرفعال‌بودن پیش‌فرض زیرنویس", "Default subtitle visibility"),
            subtitleEnabled
        ) { enabled ->
            subtitleEnabled = enabled
            subtitlePreviewText?.animate()?.alpha(if (enabled) 1f else 0.35f)?.setDuration(170L)?.start()
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("رنگ متن", "Text color")))
        val colorScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.rgb(105, 240, 174), Color.CYAN, Color.rgb(255, 105, 180), Color.rgb(255, 170, 60), Color.RED)
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3), 0, dp(7)) }
        colors.forEach { color ->
            colorRow.addView(TextView(this).apply {
                text = if (subtitleTextColor == color) "✓" else ""
                gravity = Gravity.CENTER
                textSize = 15f
                setTextColor(if (color == Color.BLACK) Color.WHITE else Color.BLACK)
                isClickable = true
                background = rounded(color, 999, if (subtitleTextColor == color) p.primary else Color.argb(95, 255, 255, 255), if (subtitleTextColor == color) 2 else 1)
                setOnClickListener { subtitleTextColor = color; persistDraft(); render() }
            }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        }
        colorScroll.addView(colorRow)
        body.addView(colorScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        body.addView(sectionTitle(tr("پس‌زمینه", "Background")))
        val bgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("black" to tr("مشکی", "Black"), "transparent" to tr("شفاف", "Clear"), "white" to tr("سفید", "White")).forEachIndexed { index, pair ->
            bgRow.addView(choice(pair.second, subtitleBackground == pair.first) { subtitleBackground = pair.first; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        body.addView(bgRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("جای زیرنویس", "Subtitle position")))
        val positionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        fun refreshPositionButtons() {
            val currentPalette = palette()
            positionButtons.forEach { (position, view) ->
                val active = subtitlePosition == position
                view.background = if (active) rounded(currentPalette.primary, 17) else rounded(currentPalette.panel2, 17, currentPalette.stroke)
                view.setTextColor(if (active) currentPalette.onPrimary else currentPalette.text)
            }
        }
        listOf(0 to tr("پایین", "Bottom"), 1 to tr("وسط", "Middle"), 2 to tr("بالا", "Top")).forEachIndexed { index, pair ->
            val button = text(pair.second, 13f, true, p.text, Gravity.CENTER).apply {
                isClickable = true
                isFocusable = true
                setPadding(dp(10), dp(11), dp(10), dp(11))
                setOnClickListener {
                    subtitlePosition = pair.first
                    persistDraft()
                    refreshPositionButtons()
                    updateSubtitlePreviewPosition()
                }
            }
            positionButtons += pair.first to button
            positionRow.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        refreshPositionButtons()
        body.addView(positionRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("فونت و ضخامت", "Font and weight")))
        val subtitleFontScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val fontRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(2), 0, dp(4)) }
        BankmovieFonts.options.forEachIndexed { index, option ->
            fontRow.addView(choice(tr(option.faLabel, option.enLabel), subtitleFont == option.key) {
                subtitleFont = option.key
                persistDraft()
                render()
            }, LinearLayout.LayoutParams(dp(112), dp(44)).apply { if (index > 0) marginStart = dp(6) })
        }
        subtitleFontScroll.addView(fontRow)
        body.addView(subtitleFontScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val weightRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        weightRow.addView(choice(tr("پررنگ", "Bold"), subtitleBold) { subtitleBold = true; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        weightRow.addView(choice(tr("معمولی", "Regular"), !subtitleBold) { subtitleBold = false; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        body.addView(weightRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        val sizeLabel = text(tr("اندازه زیرنویس: $subtitleScale٪", "Subtitle size: $subtitleScale%"), 14f, true)
        body.addView(sizeLabel)
        body.addView(SeekBar(this).apply {
            max = 90
            progress = (subtitleScale - 80).coerceIn(0, 90)
            progressTintList = ColorStateList.valueOf(p.primary)
            thumbTintList = ColorStateList.valueOf(p.primary)
            progressBackgroundTintList = ColorStateList.valueOf(p.stroke)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { persistDraft() }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) {
                        subtitleScale = 80 + value
                        persistDraft()
                        sizeLabel.text = tr("اندازه زیرنویس: $subtitleScale٪", "Subtitle size: $subtitleScale%")
                        subtitlePreviewText?.let { previewText ->
                            previewText.textSize = (subtitleScale / 8.2f).coerceIn(12f, 22f)
                            previewText.animate().cancel()
                            previewText.animate().scaleX(1.035f).scaleY(1.035f).setDuration(60L).withEndAction {
                                previewText.animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                            }.start()
                        }
                    }
                }
            })
        }, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun renderPlayback(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("پخش و دانلود", "Playback and downloads"), 22f, true))
        body.addView(text(tr("رفتار پیش‌فرض را انتخاب کنید؛ هر زمان از پروفایل قابل تغییر است.", "Choose defaults. You can change them later from Profile."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        body.addView(sectionTitle(tr("روش دانلود", "Download method")))
        val methods = listOf(
            "ask" to Pair(tr("هر بار سؤال شود", "Ask every time"), tr("انتخاب بین دانلودر داخلی و برنامه خارجی", "Choose internal or external each time")),
            "internal" to Pair(tr("دانلودر داخلی", "Internal downloader"), tr("مدیریت صف، توقف و ادامه داخل برنامه", "Queue, pause and resume inside the app")),
            "browser" to Pair(tr("مرورگر / برنامه خارجی", "Browser / external app"), tr("لینک مستقیماً به برنامه دیگر فرستاده می‌شود", "Send links directly to another app"))
        )
        methods.forEach { (key, pair) ->
            val active = downloadBehavior == key
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(if (active) UiPreferences.blend(p.panel2, p.primary, 0.15f) else p.panel, 19, if (active) p.primary else p.stroke, if (active) 2 else 1)
                isClickable = true
                isFocusable = true
                setOnClickListener { downloadBehavior = key; persistDraft(); render() }
            }
            row.addView(text((if (active) "✓  " else "") + pair.first, 14f, true, if (active) p.primary else p.text))
            row.addView(text(pair.second, 12f, false, p.muted).apply { setPadding(0, dp(5), 0, 0) })
            body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        body.addView(sectionTitle(tr("زمان پرش پلیر", "Player seek interval")).apply { setPadding(dp(2), dp(12), dp(2), dp(8)) })
        val seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(5, 10, 30, 60).forEachIndexed { index, seconds ->
            seekRow.addView(choice(tr("$seconds ثانیه", "${seconds}s"), seekSeconds == seconds) { seekSeconds = seconds; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        body.addView(seekRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("قسمت بعدی", "Next episode")))
        body.addView(onboardingToggle(
            tr("پیشنهاد قسمت بعدی", "Next episode prompt"),
            tr("در پایان پخش، قسمت بعدی پیشنهاد شود", "Suggest the next episode near the end"),
            autoNext
        ) { autoNext = it })
    }

    private fun renderLanguageAndSummary(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("زبان و پایان", "Language and finish"), 22f, true))
        body.addView(text(tr("زبان رابط برنامه را انتخاب کنید.", "Choose the app interface language."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        val languageRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        languageRow.addView(choice("فارسی", language == "fa") { language = "fa"; render() }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(7) })
        languageRow.addView(choice("English", language == "en") { language = "en"; render() }, LinearLayout.LayoutParams(0, dp(50), 1f))
        body.addView(languageRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(p.panel, 22, p.stroke)
        }
        summary.addView(text(tr("خلاصه انتخاب‌ها", "Your choices"), 15f, true))
        val themeLabel = when (theme) { "light" -> tr("روشن", "Light"); "dark" -> tr("تیره", "Dark"); else -> tr("مشکی", "Black") }
        val fontLabel = tr(BankmovieFonts.label(appFont), BankmovieFonts.label(appFont, true))
        val downloadLabel = when (downloadBehavior) { "internal" -> tr("دانلودر داخلی", "Internal downloader"); "browser" -> tr("مرورگر / خارجی", "Browser / external"); else -> tr("هر بار سؤال شود", "Ask every time") }
        val navLabel = when (mobileNavStyle) {
            "minimal" -> tr("مینیمال", "Minimal")
            "glass" -> tr("شیشه‌ای", "Glass")
            "floating" -> tr("شناور", "Floating")
            "neumorph" -> tr("نئومورف", "Neumorph")
            "pill" -> tr("کپسولی", "Pill")
            "center_fab" -> tr("دکمه مرکزی", "Center FAB")
            "gradient" -> tr("گرادیان", "Gradient")
            "outline" -> tr("آوت‌لاین", "Outline")
            "indicator" -> tr("نشانگر", "Indicator")
            "curved" -> tr("خمیده", "Curved")
            else -> tr("فعلی بانک مووی", "Bankmovie current")
        }
        listOf(
            tr("ظاهر: $themeLabel", "Theme: $themeLabel"),
            tr("فونت: $fontLabel", "Font: $fontLabel"),
            tr("ناوبری: $navLabel", "Navigation: $navLabel"),
            tr("زیرنویس: ${if (subtitleEnabled) "فعال" else "غیرفعال"}، $subtitleScale٪، ${listOf("پایین", "وسط", "بالا")[subtitlePosition]}", "Subtitles: ${if (subtitleEnabled) "On" else "Off"}, $subtitleScale%"),
            tr("دانلود: $downloadLabel", "Downloads: $downloadLabel"),
            tr("پرش پلیر: $seekSeconds ثانیه", "Player seek: ${seekSeconds}s")
        ).forEach { value -> summary.addView(text(value, 13f, false, p.muted).apply { setPadding(0, dp(8), 0, 0) }) }
        body.addView(summary)
        body.addView(text(
            tr("با ذخیره، این صفحه دیگر خودکار نمایش داده نمی‌شود. هر گزینه از پروفایل ← تنظیمات قابل تغییر است.", "After saving, this setup will not open automatically again. Every option remains available under Profile → Settings."),
            12.5f, true, p.primary
        ).apply { setPadding(0, dp(15), 0, 0) })
    }

    private fun finishSetup() {
        persistDraft()
        UiPreferences.prefs(this).edit()
            .putString("lang_code", language)
            .putString(UiPreferences.KEY_ACCENT, accent)
            .putString(UiPreferences.KEY_APP_FONT, appFont)
            .putString(UiPreferences.KEY_MOBILE_NAV_STYLE, mobileNavStyle)
            .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
            .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
            .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackground)
            .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
            .putString(UiPreferences.KEY_SUB_FONT, subtitleFont)
            .putBoolean(UiPreferences.KEY_SUB_BOLD, subtitleBold)
            .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePosition)
            .putString(UiPreferences.KEY_DOWNLOAD_BEHAVIOR, downloadBehavior)
            .putInt(UiPreferences.KEY_SEEK_SECONDS, seekSeconds)
            .putBoolean(UiPreferences.KEY_AUTO_NEXT, autoNext)
            .putInt(UiPreferences.KEY_SETUP_VERSION, UiPreferences.CURRENT_SETUP_VERSION)
            .apply()
        UiPreferences.saveThemeSelection(this, theme)
        setResult(RESULT_OK)
        finish()
    }
}
