package ir.bankmoviee.app

import android.content.Context
import android.webkit.WebView
import org.json.JSONObject

/** App presentation layer for BankMovie's existing /discover UI.
 * Uses website assets and SVGs; does not clone or fork recommendation logic.
 * All input files are bundled in Android assets, never fetched from arbitrary URLs.
 */
internal object DiscoverAppBridge {
    fun install(context: Context, web: WebView) {
        val css = context.assets.open("bm_discover_app.css").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val js = context.assets.open("bm_discover_app.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val injectCss = "(function(){var style=document.getElementById('bm-app-discover-css');" +
            "if(!style){style=document.createElement('style');style.id='bm-app-discover-css';" +
            "style.textContent=" + JSONObject.quote(css) + ";}" +
            "document.head.appendChild(style);})();"
        web.evaluateJavascript(injectCss, null)
        web.evaluateJavascript(js, null)
    }
}
