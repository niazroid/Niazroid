(function(){
  'use strict';
  if(!document.body||!document.body.classList.contains('bm4-page')) return;
  if(window.__bmAppDiscoverBridgeV2) return;
  window.__bmAppDiscoverBridgeV2=true;

  // Remove ONLY video Explorer, never #explorer (the catalog / path cards).
  ['explore','bm-native-explorer','reelsModal','detailModal'].forEach(function(id){
    var el=document.getElementById(id);if(el) el.remove();
  });
  function dots(el){
    if(!el||el.dataset.bmUiverse==='1')return;
    el.dataset.bmUiverse='1';
    for(var i=0;i<3;i++){
      var c=document.createElement('span');c.className='bm-app-circle';c.setAttribute('aria-hidden','true');el.appendChild(c);
    }
    for(var j=0;j<3;j++){
      var s=document.createElement('span');s.className='bm-app-shadow';s.setAttribute('aria-hidden','true');el.appendChild(s);
    }
  }
  function enhance(){document.querySelectorAll('.bm4-loading-bars').forEach(dots);}
  enhance();
  var mutationTimer=0;
  var observer=new MutationObserver(function(mutations){
    var changed=mutations.some(function(m){return Array.prototype.some.call(m.addedNodes,function(node){
      return node.nodeType===1 && ((node.matches&&node.matches('.bm4-loading-bars')) ||
        (node.querySelector&&node.querySelector('.bm4-loading-bars')));
    });});
    if(!changed)return;
    if(mutationTimer)return;
    mutationTimer=window.setTimeout(function(){mutationTimer=0;enhance();},0);
  });
  observer.observe(document.body,{childList:true,subtree:true});

  // All discovery API calls, including mixer, autocomplete & category cards.
  // A short delay avoids flashing on fast cached responses; we never delay requests.
  var count=0,showTimer=0,overlay=null;
  function ui(){
    if(overlay)return overlay;
    overlay=document.createElement('div');overlay.id='bm-app-network-loader';overlay.setAttribute('role','status');
    overlay.setAttribute('aria-label','در حال دریافت پیشنهادهای بانک مووی');
    var animation=document.createElement('div');animation.className='bm-app-loader-visual';dots(animation);
    var text=document.createElement('span');text.className='bm-app-loader-text';text.textContent='در حال دریافت پیشنهادها…';
    overlay.appendChild(animation);overlay.appendChild(text);document.body.appendChild(overlay);
    return overlay;
  }
  function start(){
    count++;
    if(showTimer)window.clearTimeout(showTimer);
    showTimer=window.setTimeout(function(){if(count>0)ui().classList.add('is-active');},140);
  }
  function finish(){
    count=Math.max(0,count-1);
    if(count===0){if(showTimer)window.clearTimeout(showTimer);showTimer=0;if(overlay)overlay.classList.remove('is-active');}
  }
  function matches(raw){
    try{var url=new URL(String(raw||''),location.href);return url.origin===location.origin && /\/api_discover\.php$/i.test(url.pathname);}
    catch(e){return false;}
  }
  if(window.fetch){
    var nativeFetch=window.fetch;
    window.fetch=function(input,init){
      var url=(typeof input==='string'||input instanceof URL)?String(input):((input&&input.url)||'');
      if(!matches(url))return nativeFetch.apply(this,arguments);
      start();
      try{return Promise.resolve(nativeFetch.apply(this,arguments)).then(function(result){finish();return result;},function(err){finish();throw err;});}
      catch(error){finish();throw error;}
    };
  }
  // XMLHttpRequest fallback for future site API changes.
  if(window.XMLHttpRequest){
    var proto=XMLHttpRequest.prototype,open=proto.open,send=proto.send;
    proto.open=function(method,url){this.__bmDiscoverRequest=matches(url);return open.apply(this,arguments);};
    proto.send=function(){
      if(!this.__bmDiscoverRequest)return send.apply(this,arguments);
      start();var completed=false;function done(){if(!completed){completed=true;finish();}}
      this.addEventListener('loadend',done,{once:true});
      try{return send.apply(this,arguments);}catch(e){done();throw e;}
    };
  }
})();