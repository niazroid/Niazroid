Irancell Regular is embedded directly in this source archive as:
fonts/irancell_regular.ttf
No external font upload or GitHub workflow copy step is required.
