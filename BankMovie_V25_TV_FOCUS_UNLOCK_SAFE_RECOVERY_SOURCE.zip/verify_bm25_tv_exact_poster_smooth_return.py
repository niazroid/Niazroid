#!/usr/bin/env python3
"""Structural checks only; actual D-pad behavior must be verified on TV."""
from pathlib import Path
root=Path(__file__).resolve().parent
base=root/'app/src/main/java/ir/bankmoviee/app'
main=(base/'MainActivity.kt').read_text()
auth=(base/'AuthActivity.kt').read_text()
loader=(base/'ThemeWindowLoadingView.kt').read_text()
section=lambda a,b: main.split(a,1)[1].split(b,1)[0]
remember=section('private fun rememberHomeForSession()', 'private fun tryRestoreHomeSession()')
restore=section('private fun tryRestoreHomeSession()', 'private fun restoreRetainedNavigationScreen(')
lifecycle=section('private fun rebindHomeTvFocusAfterLifecycle()', 'private fun handleHomePosterDirectionalFocus(')
poster=section('private fun posterCard(item: JSONObject', 'private fun detailRequestKey(')
assert 'markHomeTvActivatedPoster(clicked)' in poster
assert 'tvHomeActivatedPoster?.takeIf' in remember
assert 'retainedHomeSession?.children?.firstOrNull() === content.getChildAt(0)' in remember
assert 'homeRailOffsets = offsets' in remember
assert 'snapshot.homeRailOffsets.forEach' in restore
assert 'resetHomeTvRailViewportsToNewest()' not in restore
assert 'content.animate().alpha(1f)' in restore
assert 'target.requestFocus()' in restore
assert 'scrollTo(0, 0)' not in lifecycle and 'resetHomeTvRailViewportsToNewest()' not in lifecycle
assert 'tag = "bm_auth_submit_spinner"' in auth
assert 'setIndicatorColor(palette.onPrimary)' in auth
assert 'background = rounded(Color.argb(195, 8, 14, 29)' not in auth
assert 'fun setIndicatorColor(color: Int)' in loader
print('BM25_TV_EXACT_POSTER_SMOOTH_RETURN_AND_CLEAN_AUTH_SPINNER_STATIC_OK')
