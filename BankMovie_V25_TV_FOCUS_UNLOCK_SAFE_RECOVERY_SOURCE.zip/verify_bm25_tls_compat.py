#!/usr/bin/env python3
"""BankMovie 2.5 TLS release verifier: exact rooted CA fingerprints + no bypass."""
from pathlib import Path
from hashlib import sha256
import re
import subprocess

root = Path(__file__).resolve().parent
src = root / 'app/src/main'
xml = (src / 'res/xml/network_security_config.xml').read_text(encoding='utf8')
app = (src / 'java/ir/bankmoviee/app/BankmovieApplication.kt').read_text(encoding='utf8')
gradle = (root / 'app/build.gradle').read_text(encoding='utf8')
expected = {
    'isrg_root_x1': '96bcec06264976f37460779acf28c5a7cfe8a3c0aae11a8ffcee05c0bddf08c6',
    'isrg_root_yr': 'e57b7e6f150c419102e8d5c055729ff967b9d1a829bf00cec89ca604ebf4a86f',
}
for name, fingerprint in expected.items():
    pem = (src / f'res/raw/{name}.pem').read_bytes()
    der = subprocess.check_output(["openssl", "x509", "-outform", "DER"], input=pem)
    actual = sha256(der).hexdigest()
    assert actual == fingerprint, (name, actual)
    assert f'<certificates src="@raw/{name}"' in xml, name
assert '<certificates src="system"' in xml
assert 'cleartextTrafficPermitted="false"' in xml
assert "org.conscrypt:conscrypt-android:2.8.0" in gradle
assert 'SSLContext.getInstance("TLS", provider)' in app
assert 'TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())' in app
assert 'HttpsURLConnection.setDefaultSSLSocketFactory(ctx.socketFactory)' in app
assert 'tls_provider_init_error' in app and 'tls_provider_ready' in app
for text in (xml, app):
    assert 'ALLOW_ALL_HOSTNAME_VERIFIER' not in text
    assert 'checkServerTrusted(chain' not in text
    assert 'setDefaultHostnameVerifier' not in text
print('BANKMOVIE_TLS_COMPAT_SECURITY_OK: Conscrypt 2.8.0; CA X1/YR fingerprints; strict TLS')
