#ifndef MyAppVersion
#define MyAppVersion "2.0.0"
#endif
#ifndef SourceDir
#define SourceDir "..\publish"
#endif

#define MyAppName "BankMovie"
#define MyAppPublisher "BankMovie"
#define MyAppExeName "BankMovie.exe"

[Setup]
AppId={{D4737B4A-047B-4C2A-9F34-7A95AA9EA650}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\BankMovie
DefaultGroupName=BankMovie
DisableProgramGroupPage=yes
OutputBaseFilename=BankMovie-Native-Setup-x64
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
SetupIconFile=..\src\BankMovie.Windows\Resources\BankMovie.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
VersionInfoVersion={#MyAppVersion}
VersionInfoProductName=BankMovie Windows Native
VersionInfoCompany=BankMovie
CloseApplications=yes
RestartApplications=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "ایجاد میانبر روی دسکتاپ"; GroupDescription: "میانبرها:"; Flags: unchecked

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{autoprograms}\BankMovie"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\BankMovie"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "اجرای BankMovie"; Flags: nowait postinstall skipifsilent
