using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using BankMovie.Windows.Views;

namespace BankMovie.Windows;

public partial class MainWindow : Window
{
    private readonly AppSettings _settings;
    private readonly Api6Client _api;
    private readonly PlaybackHistoryStore _historyStore = new();
    private readonly Stack<UserControl> _backStack = new();
    private UserControl? _currentView;
    private bool _fullscreen;
    private WindowState _stateBeforeFullscreen;
    private bool _allowClose;

    public MainWindow()
    {
        InitializeComponent();
        _settings = SettingsService.Load();
        _api = new Api6Client(_settings);
        Loaded += (_, _) => ShowHome(clearHistory: true);
    }

    private void ShowHome(bool clearHistory)
    {
        if (clearHistory) _backStack.Clear();
        var view = new HomeView(_api, _settings.HomeSections);
        view.OpenMovieRequested += (_, movie) => OpenDetails(movie);
        view.ShowSectionRequested += (_, section) => OpenSection(section.Title, section.Section);
        Navigate(view, addCurrentToHistory: false);
        SetActiveNav(HomeNav);
    }

    private void OpenSection(string title, string section)
    {
        var view = new BrowseView(_api, title, section);
        view.OpenMovieRequested += (_, movie) => OpenDetails(movie);
        Navigate(view, addCurrentToHistory: true);
    }

    private void OpenSearch(string query = "")
    {
        var view = new SearchView(_api, query);
        view.OpenMovieRequested += (_, movie) => OpenDetails(movie);
        Navigate(view, addCurrentToHistory: true);
        SetActiveNav(SearchNav);
    }

    private void OpenDetails(MovieItem movie)
    {
        var view = new DetailView(_api, movie);
        view.OpenMovieRequested += (_, related) => OpenDetails(related);
        view.PlayRequested += (_, request) => OpenPlayer(request.Movie, request.Link, request.AllLinks);
        Navigate(view, addCurrentToHistory: true);
        SetActiveNav(null);
    }

    private void OpenPlayer(MovieItem movie, MediaLink link, IReadOnlyList<MediaLink> allLinks)
    {
        var view = new PlayerView(_historyStore, movie, link, allLinks);
        view.BackRequested += (_, _) => GoBack();
        view.FullscreenRequested += (_, enabled) => SetPlayerFullscreen(enabled);
        Navigate(view, addCurrentToHistory: true);
        SetActiveNav(null);
    }

    private void Navigate(UserControl view, bool addCurrentToHistory)
    {
        if (addCurrentToHistory && _currentView is not null) _backStack.Push(_currentView);
        _currentView = view;
        RootContent.Content = view;
        BackButton.Visibility = _backStack.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
    }

    private async void GoBack()
    {
        if (_currentView is PlayerView player) await player.ShutdownAsync();
        if (_backStack.Count == 0)
        {
            ShowHome(clearHistory: true);
            return;
        }
        var previous = _backStack.Pop();
        _currentView = previous;
        RootContent.Content = previous;
        BackButton.Visibility = _backStack.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
        SetActiveNav(previous switch
        {
            HomeView => HomeNav,
            SearchView => SearchNav,
            _ => null
        });
    }

    private void SetActiveNav(Button? active)
    {
        foreach (var button in new[] { HomeNav, MoviesNav, SeriesNav, AnimationNav, AnimeNav, SearchNav })
            button.Tag = ReferenceEquals(button, active) ? "active" : null;
    }

    private void SetPlayerFullscreen(bool enabled)
    {
        if (_fullscreen == enabled) return;
        _fullscreen = enabled;
        if (enabled)
        {
            _stateBeforeFullscreen = WindowState;
            TitleBarRow.Height = new GridLength(0);
            HeaderRow.Height = new GridLength(0);
            WindowState = System.Windows.WindowState.Maximized;
        }
        else
        {
            TitleBarRow.Height = new GridLength(34);
            HeaderRow.Height = new GridLength(70);
            WindowState = _stateBeforeFullscreen;
        }
    }

    private void HomeNav_Click(object sender, RoutedEventArgs e) => ShowHome(clearHistory: true);
    private void Logo_Click(object sender, RoutedEventArgs e) => ShowHome(clearHistory: true);
    private void MoviesNav_Click(object sender, RoutedEventArgs e) { OpenSection("جدیدترین فیلم‌ها", "new_movies"); SetActiveNav(MoviesNav); }
    private void SeriesNav_Click(object sender, RoutedEventArgs e) { OpenSection("جدیدترین سریال‌ها", "new_series"); SetActiveNav(SeriesNav); }
    private void AnimationNav_Click(object sender, RoutedEventArgs e) { OpenSection("انیمیشن‌های به‌روزشده", "updated_animations"); SetActiveNav(AnimationNav); }
    private void AnimeNav_Click(object sender, RoutedEventArgs e) { OpenSection("انیمه‌های به‌روزشده", "updated_anime"); SetActiveNav(AnimeNav); }
    private void SearchNav_Click(object sender, RoutedEventArgs e) => OpenSearch();
    private void BackButton_Click(object sender, RoutedEventArgs e) => GoBack();

    private void HeaderSearch_Click(object sender, RoutedEventArgs e) => OpenSearch(HeaderSearchBox.Text.Trim());

    private void HeaderSearchBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        e.Handled = true;
        OpenSearch(HeaderSearchBox.Text.Trim());
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2)
        {
            WindowState = WindowState == System.Windows.WindowState.Maximized ? System.Windows.WindowState.Normal : System.Windows.WindowState.Maximized;
            return;
        }
        if (e.LeftButton == MouseButtonState.Pressed) DragMove();
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = System.Windows.WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState == System.Windows.WindowState.Maximized ? System.Windows.WindowState.Normal : System.Windows.WindowState.Maximized;
    private void Close_Click(object sender, RoutedEventArgs e) => Close();

    private async void MainWindow_Closing(object? sender, CancelEventArgs e)
    {
        if (_allowClose)
        {
            _api.Dispose();
            return;
        }
        e.Cancel = true;
        if (_currentView is PlayerView player) await player.ShutdownAsync();
        _allowClose = true;
        Close();
    }
}
