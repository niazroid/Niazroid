using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace BankMovie.Windows.Converters;

public sealed class ImageUrlConverter : IValueConverter
{
    private static readonly Uri Placeholder = new("pack://application:,,,/Resources/bankmovie-icon.png", UriKind.Absolute);

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        var raw = value?.ToString()?.Trim();
        var uri = Uri.TryCreate(raw, UriKind.Absolute, out var parsed) ? parsed : Placeholder;
        try
        {
            var image = new BitmapImage();
            image.BeginInit();
            image.UriSource = uri;
            image.CacheOption = BitmapCacheOption.OnDemand;
            image.CreateOptions = BitmapCreateOptions.IgnoreColorProfile;
            image.DecodePixelWidth = parameter is string text && int.TryParse(text, out var width) ? width : 640;
            image.EndInit();
            image.Freeze();
            return image;
        }
        catch
        {
            return new BitmapImage(Placeholder);
        }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}
