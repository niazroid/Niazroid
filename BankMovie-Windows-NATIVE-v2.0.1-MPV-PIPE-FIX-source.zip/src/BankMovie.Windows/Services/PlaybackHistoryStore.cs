using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public sealed class PlaybackHistoryStore
{
    private readonly string _filePath;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private Dictionary<string, PlaybackHistoryEntry> _entries = new(StringComparer.OrdinalIgnoreCase);
    private bool _loaded;

    public PlaybackHistoryStore()
    {
        var directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie");
        Directory.CreateDirectory(directory);
        _filePath = Path.Combine(directory, "playback-history.json");
    }

    public string BuildKey(MovieItem movie, MediaLink link)
    {
        var raw = $"{movie.DetailKey}|{link.Url}";
        var hash = SHA256.HashData(Encoding.UTF8.GetBytes(raw));
        return Convert.ToHexString(hash);
    }

    public async Task<double> GetPositionAsync(string key)
    {
        await EnsureLoadedAsync();
        return _entries.TryGetValue(key, out var entry) ? Math.Max(0, entry.PositionSeconds) : 0;
    }

    public async Task SaveAsync(string key, MovieItem movie, MediaLink link, double positionSeconds, double durationSeconds)
    {
        if (string.IsNullOrWhiteSpace(key) || positionSeconds < 1) return;
        await EnsureLoadedAsync();
        await _gate.WaitAsync();
        try
        {
            if (durationSeconds > 0 && positionSeconds >= durationSeconds - 90)
            {
                _entries.Remove(key);
            }
            else
            {
                _entries[key] = new PlaybackHistoryEntry
                {
                    Key = key,
                    Title = movie.DisplayTitle,
                    Poster = movie.Poster,
                    LinkLabel = link.Label,
                    PositionSeconds = positionSeconds,
                    DurationSeconds = durationSeconds,
                    UpdatedAt = DateTimeOffset.UtcNow
                };
            }
            var json = JsonSerializer.Serialize(_entries, new JsonSerializerOptions { WriteIndented = true });
            var temporary = _filePath + ".tmp";
            await File.WriteAllTextAsync(temporary, json, Encoding.UTF8);
            File.Move(temporary, _filePath, true);
        }
        finally
        {
            _gate.Release();
        }
    }

    private async Task EnsureLoadedAsync()
    {
        if (_loaded) return;
        await _gate.WaitAsync();
        try
        {
            if (_loaded) return;
            if (File.Exists(_filePath))
            {
                try
                {
                    var json = await File.ReadAllTextAsync(_filePath, Encoding.UTF8);
                    _entries = JsonSerializer.Deserialize<Dictionary<string, PlaybackHistoryEntry>>(json)
                               ?? new Dictionary<string, PlaybackHistoryEntry>(StringComparer.OrdinalIgnoreCase);
                }
                catch
                {
                    _entries = new Dictionary<string, PlaybackHistoryEntry>(StringComparer.OrdinalIgnoreCase);
                }
            }
            _loaded = true;
        }
        finally
        {
            _gate.Release();
        }
    }

    private sealed class PlaybackHistoryEntry
    {
        public string Key { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Poster { get; set; } = string.Empty;
        public string LinkLabel { get; set; } = string.Empty;
        public double PositionSeconds { get; set; }
        public double DurationSeconds { get; set; }
        public DateTimeOffset UpdatedAt { get; set; }
    }
}
