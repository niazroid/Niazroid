using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public static class SettingsService
{
    public static AppSettings Load()
    {
        var defaults = CreateDefaults();
        try
        {
            var path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            if (!File.Exists(path)) return defaults;
            var json = File.ReadAllText(path);
            var loaded = JsonSerializer.Deserialize<AppSettings>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            });
            if (loaded is null) return defaults;
            if (string.IsNullOrWhiteSpace(loaded.Api6Url)) loaded.Api6Url = defaults.Api6Url;
            if (string.IsNullOrWhiteSpace(loaded.SiteRoot)) loaded.SiteRoot = defaults.SiteRoot;
            if (loaded.RequestTimeoutSeconds < 5) loaded.RequestTimeoutSeconds = defaults.RequestTimeoutSeconds;
            if (loaded.HomeSections.Count == 0) loaded.HomeSections = defaults.HomeSections;
            return loaded;
        }
        catch
        {
            return defaults;
        }
    }

    private static AppSettings CreateDefaults() => new()
    {
        Api6Url = "https://bankmovie.top/api6.php",
        SiteRoot = "https://bankmovie.top",
        RequestTimeoutSeconds = 25,
        HomeSections =
        [
            new() { Key = "new_movies", Title = "جدیدترین فیلم‌ها" },
            new() { Key = "new_series", Title = "جدیدترین سریال‌ها" },
            new() { Key = "updated_animations", Title = "انیمیشن‌های به‌روزشده" },
            new() { Key = "updated_anime", Title = "انیمه‌های به‌روزشده" },
            new() { Key = "dubbed_movies", Title = "فیلم‌های دوبله" }
        ]
    };
}
