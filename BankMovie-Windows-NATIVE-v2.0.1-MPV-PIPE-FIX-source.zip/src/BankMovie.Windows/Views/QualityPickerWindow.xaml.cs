using System.Windows;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Views;

public partial class QualityPickerWindow : Window
{
    public QualityPickerWindow(IReadOnlyList<MediaLink> links)
    {
        InitializeComponent();
        LinksList.ItemsSource = links;
        if (links.Count > 0) LinksList.SelectedIndex = 0;
        LinksList.MouseDoubleClick += (_, _) => ConfirmSelection();
    }

    public MediaLink? SelectedLink { get; private set; }

    private void Play_Click(object sender, RoutedEventArgs e) => ConfirmSelection();

    private void ConfirmSelection()
    {
        if (LinksList.SelectedItem is not MediaLink link) return;
        SelectedLink = link;
        DialogResult = true;
    }

    private void Cancel_Click(object sender, RoutedEventArgs e)
    {
        DialogResult = false;
    }
}
