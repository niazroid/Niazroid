using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows.Views;

public partial class PlayerView : UserControl
{
    private readonly PlaybackHistoryStore _historyStore;
    private readonly MovieItem _movie;
    private readonly IReadOnlyList<MediaLink> _allLinks;
    private readonly DispatcherTimer _timer;
    private MediaLink _currentLink;
    private MpvController? _mpv;
    private bool _started;
    private bool _ready;
    private bool _userSeeking;
    private bool _polling;
    private bool _shuttingDown;
    private bool _fullscreen;
    private double _lastPosition;
    private double _duration;
    private string _historyKey = string.Empty;

    public event EventHandler? BackRequested;
    public event EventHandler<bool>? FullscreenRequested;

    public PlayerView(PlaybackHistoryStore historyStore, MovieItem movie, MediaLink selectedLink, IReadOnlyList<MediaLink> allLinks)
    {
        InitializeComponent();
        _historyStore = historyStore;
        _movie = movie;
        _currentLink = selectedLink;
        _allLinks = allLinks;
        TitleText.Text = movie.DisplayTitle;
        LinkText.Text = selectedLink.Label;
        _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(650) };
        _timer.Tick += Timer_Tick;
        Loaded += PlayerView_Loaded;
        Unloaded += PlayerView_Unloaded;
    }

    private async void PlayerView_Loaded(object sender, RoutedEventArgs e)
    {
        Focus();
        if (!_started) await StartPlayerAsync();
    }

    private async void PlayerView_Unloaded(object sender, RoutedEventArgs e)
    {
        await ShutdownAsync();
    }

    private string ResolveMpvPath()
    {
        var packaged = Path.Combine(AppContext.BaseDirectory, "mpv", "mpv.exe");
        if (File.Exists(packaged)) return packaged;
        var flat = Path.Combine(AppContext.BaseDirectory, "mpv.exe");
        return File.Exists(flat) ? flat : packaged;
    }

    private async Task StartPlayerAsync()
    {
        _started = true;
        _ready = false;
        LoadingPanel.Visibility = Visibility.Visible;
        ErrorPanel.Visibility = Visibility.Collapsed;
        VideoHost.Visibility = Visibility.Collapsed;
        LoadingText.Text = "در حال راه‌اندازی پلیر داخلی...";

        try
        {
            var handle = VideoPanel.Handle;
            _mpv = new MpvController();
            _mpv.ProcessExited += Mpv_ProcessExited;
            await _mpv.StartAsync(handle, ResolveMpvPath());
            _historyKey = _historyStore.BuildKey(_movie, _currentLink);
            var resumePosition = await _historyStore.GetPositionAsync(_historyKey);
            LoadingText.Text = resumePosition > 10 ? "در حال ادامه پخش از محل قبلی..." : "در حال بازکردن ویدئو...";
            await _mpv.LoadAsync(_currentLink.Url, resumePosition);
            _lastPosition = resumePosition;
            _ready = true;
            LoadingPanel.Visibility = Visibility.Collapsed;
            VideoHost.Visibility = Visibility.Visible;
            StatusText.Text = resumePosition > 10 ? "ادامه پخش" : "در حال پخش";
            _timer.Start();
        }
        catch (Exception ex)
        {
            ShowError(ex.Message);
        }
    }

    private void Mpv_ProcessExited(object? sender, EventArgs e)
    {
        Dispatcher.BeginInvoke(() =>
        {
            if (!_shuttingDown) ShowError("موتور پخش به‌طور ناگهانی متوقف شد. دکمه «تلاش دوباره» را بزن؛ برنامه بسته نمی‌شود.");
        });
    }

    private async void Timer_Tick(object? sender, EventArgs e)
    {
        if (!_ready || _mpv is null || _polling) return;
        _polling = true;
        try
        {
            var position = await _mpv.GetDoublePropertyAsync("time-pos") ?? _lastPosition;
            var duration = await _mpv.GetDoublePropertyAsync("duration") ?? _duration;
            var paused = await _mpv.GetBoolPropertyAsync("pause") ?? false;
            var volume = await _mpv.GetDoublePropertyAsync("volume");
            _lastPosition = Math.Max(0, position);
            _duration = Math.Max(0, duration);
            if (!_userSeeking)
            {
                PositionSlider.Maximum = Math.Max(1, _duration);
                PositionSlider.Value = Math.Min(_lastPosition, PositionSlider.Maximum);
            }
            if (volume is not null && !VolumeSlider.IsMouseCaptureWithin) VolumeSlider.Value = Math.Clamp(volume.Value, 0, 100);
            CurrentTimeText.Text = FormatTime(_lastPosition);
            DurationText.Text = FormatTime(_duration);
            PlayPauseButton.Content = paused ? "▶" : "⏸";
            StatusText.Text = paused ? "متوقف" : "در حال پخش";
        }
        catch
        {
            // Polling failure can be transient while changing files.
        }
        finally
        {
            _polling = false;
        }
    }

    private async void PlayPause_Click(object sender, RoutedEventArgs e)
    {
        if (_mpv is not null && _ready) await _mpv.TogglePauseAsync();
    }

    private async void SeekBack_Click(object sender, RoutedEventArgs e)
    {
        if (_mpv is not null && _ready) await _mpv.SeekAsync(-10);
    }

    private async void SeekForward_Click(object sender, RoutedEventArgs e)
    {
        if (_mpv is not null && _ready) await _mpv.SeekAsync(10);
    }

    private void PositionSlider_PreviewMouseDown(object sender, MouseButtonEventArgs e) => _userSeeking = true;

    private async void PositionSlider_PreviewMouseUp(object sender, MouseButtonEventArgs e)
    {
        if (_mpv is not null && _ready) await _mpv.SeekAbsoluteAsync(PositionSlider.Value);
        _userSeeking = false;
    }

    private async void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_mpv is not null && _ready && VolumeSlider.IsMouseCaptureWithin)
            await _mpv.SetPropertyAsync("volume", Math.Round(e.NewValue));
    }

    private async void Subtitle_Click(object sender, RoutedEventArgs e)
    {
        if (_mpv is null || !_ready) return;
        await _mpv.CycleSubtitleAsync();
        StatusText.Text = "ترک زیرنویس تغییر کرد";
    }

    private async void Audio_Click(object sender, RoutedEventArgs e)
    {
        if (_mpv is null || !_ready) return;
        await _mpv.CycleAudioAsync();
        StatusText.Text = "ترک صوتی تغییر کرد";
    }

    private async void Quality_Click(object sender, RoutedEventArgs e)
    {
        var options = _allLinks.Where(x => x.IsPlayable && !x.IsAudio).ToList();
        if (options.Count <= 1 || _mpv is null || !_ready)
        {
            StatusText.Text = options.Count <= 1 ? "نسخه دیگری موجود نیست" : string.Empty;
            return;
        }
        var picker = new QualityPickerWindow(options) { Owner = Window.GetWindow(this) };
        if (picker.ShowDialog() != true || picker.SelectedLink is null || picker.SelectedLink.Url == _currentLink.Url) return;

        await SaveProgressAsync();
        _currentLink = picker.SelectedLink;
        _historyKey = _historyStore.BuildKey(_movie, _currentLink);
        LinkText.Text = _currentLink.Label;
        LoadingPanel.Visibility = Visibility.Visible;
        VideoHost.Visibility = Visibility.Collapsed;
        LoadingText.Text = "در حال تغییر کیفیت...";
        try
        {
            await _mpv.LoadAsync(_currentLink.Url, _lastPosition);
            VideoHost.Visibility = Visibility.Visible;
            LoadingPanel.Visibility = Visibility.Collapsed;
            StatusText.Text = "کیفیت تغییر کرد";
        }
        catch (Exception ex)
        {
            ShowError(ex.Message);
        }
    }

    private void Fullscreen_Click(object sender, RoutedEventArgs e)
    {
        _fullscreen = !_fullscreen;
        FullscreenRequested?.Invoke(this, _fullscreen);
    }

    private async void Back_Click(object sender, RoutedEventArgs e)
    {
        await ShutdownAsync();
        BackRequested?.Invoke(this, EventArgs.Empty);
    }

    private async void Retry_Click(object sender, RoutedEventArgs e)
    {
        await ShutdownControllerOnlyAsync();
        _started = false;
        _shuttingDown = false;
        await StartPlayerAsync();
    }

    private async void Root_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Space:
                e.Handled = true;
                if (_mpv is not null && _ready) await _mpv.TogglePauseAsync();
                break;
            case Key.Left:
                e.Handled = true;
                if (_mpv is not null && _ready) await _mpv.SeekAsync(-10);
                break;
            case Key.Right:
                e.Handled = true;
                if (_mpv is not null && _ready) await _mpv.SeekAsync(10);
                break;
            case Key.Up:
                e.Handled = true;
                VolumeSlider.Value = Math.Min(100, VolumeSlider.Value + 5);
                if (_mpv is not null && _ready) await _mpv.SetPropertyAsync("volume", VolumeSlider.Value);
                break;
            case Key.Down:
                e.Handled = true;
                VolumeSlider.Value = Math.Max(0, VolumeSlider.Value - 5);
                if (_mpv is not null && _ready) await _mpv.SetPropertyAsync("volume", VolumeSlider.Value);
                break;
            case Key.F:
                e.Handled = true;
                _fullscreen = !_fullscreen;
                FullscreenRequested?.Invoke(this, _fullscreen);
                break;
            case Key.Escape:
                e.Handled = true;
                if (_fullscreen)
                {
                    _fullscreen = false;
                    FullscreenRequested?.Invoke(this, false);
                }
                else
                {
                    await ShutdownAsync();
                    BackRequested?.Invoke(this, EventArgs.Empty);
                }
                break;
        }
    }

    private void ShowError(string message)
    {
        _timer.Stop();
        _ready = false;
        VideoHost.Visibility = Visibility.Collapsed;
        LoadingPanel.Visibility = Visibility.Collapsed;
        ErrorText.Text = message;
        ErrorPanel.Visibility = Visibility.Visible;
        StatusText.Text = "خطا";
    }

    private async Task SaveProgressAsync()
    {
        if (!string.IsNullOrWhiteSpace(_historyKey))
            await _historyStore.SaveAsync(_historyKey, _movie, _currentLink, _lastPosition, _duration);
    }

    public async Task ShutdownAsync()
    {
        if (_shuttingDown) return;
        _shuttingDown = true;
        _timer.Stop();
        await SaveProgressAsync();
        await ShutdownControllerOnlyAsync();
        if (_fullscreen)
        {
            _fullscreen = false;
            FullscreenRequested?.Invoke(this, false);
        }
    }

    private async Task ShutdownControllerOnlyAsync()
    {
        _ready = false;
        if (_mpv is not null)
        {
            _mpv.ProcessExited -= Mpv_ProcessExited;
            await _mpv.DisposeAsync();
            _mpv = null;
        }
    }

    private static string FormatTime(double seconds)
    {
        if (double.IsNaN(seconds) || double.IsInfinity(seconds) || seconds < 0) seconds = 0;
        var time = TimeSpan.FromSeconds(seconds);
        return time.TotalHours >= 1 ? time.ToString(@"hh\:mm\:ss") : time.ToString(@"mm\:ss");
    }
}
