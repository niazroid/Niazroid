using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BankMovie.Windows.Controls;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows.Views;

public partial class SearchView : UserControl
{
    private readonly Api6Client _api;
    private CancellationTokenSource? _searchCts;
    private bool _optionsLoaded;
    private int _page = 1;
    private bool _hasMore;

    public event EventHandler<MovieItem>? OpenMovieRequested;

    public SearchView(Api6Client api, string initialQuery = "")
    {
        InitializeComponent();
        _api = api;
        QueryBox.Text = initialQuery;
        Loaded += SearchView_Loaded;
        Unloaded += (_, _) => _searchCts?.Cancel();
    }

    private async void SearchView_Loaded(object sender, RoutedEventArgs e)
    {
        await EnsureOptionsAsync();
        if (!string.IsNullOrWhiteSpace(QueryBox.Text) && ResultsItems.ItemsSource is null) await ExecuteSearchAsync(1);
        QueryBox.Focus();
    }

    private async Task EnsureOptionsAsync()
    {
        if (_optionsLoaded) return;
        try
        {
            var options = await _api.GetSearchOptionsAsync();
            TypeBox.ItemsSource = options.Types;
            GenreBox.ItemsSource = options.Genres;
            YearBox.ItemsSource = new ObservableCollection<OptionItem>(options.Years
                .OrderByDescending(x => int.TryParse(x.Value, out var year) ? year : int.MaxValue));
            RatingBox.ItemsSource = options.ImdbScores;
            LanguageBox.ItemsSource = options.Languages;
            SortBox.ItemsSource = options.Sorts;
            TypeBox.SelectedValue = "all";
            GenreBox.SelectedIndex = 0;
            YearBox.SelectedIndex = 0;
            RatingBox.SelectedIndex = 0;
            LanguageBox.SelectedIndex = 0;
            SortBox.SelectedValue = "newest";
            _optionsLoaded = true;
        }
        catch (Exception ex)
        {
            MessageText.Text = $"فیلترهای پیشرفته دریافت نشدند: {ex.Message}\nجستجوی متنی همچنان قابل استفاده است.";
        }
    }

    private SearchQuery BuildQuery(int page) => new()
    {
        Query = QueryBox.Text.Trim(),
        Type = TypeBox.SelectedValue?.ToString() ?? "all",
        Genre = GenreBox.SelectedValue?.ToString() ?? string.Empty,
        Year = YearBox.SelectedValue?.ToString() ?? string.Empty,
        ImdbScore = RatingBox.SelectedValue?.ToString() ?? string.Empty,
        Language = LanguageBox.SelectedValue?.ToString() ?? string.Empty,
        Sort = SortBox.SelectedValue?.ToString() ?? "newest",
        Page = page
    };

    private async Task ExecuteSearchAsync(int page)
    {
        _searchCts?.Cancel();
        _searchCts = new CancellationTokenSource();
        LoadingOverlay.Visibility = Visibility.Visible;
        MessagePanel.Visibility = Visibility.Collapsed;
        try
        {
            var result = await _api.SearchAsync(BuildQuery(page), _searchCts.Token);
            _page = result.Page > 0 ? result.Page : page;
            _hasMore = result.HasMore || result.NextPage is > 0;
            ResultsItems.ItemsSource = result.Items;
            ResultCount.Text = result.Items.Count > 0 ? $"{result.Items.Count} نتیجه در این صفحه" : string.Empty;
            if (result.Items.Count == 0)
            {
                MessageText.Text = "نتیجه‌ای با این فیلترها پیدا نشد. فیلترها را سبک‌تر کن.";
                MessagePanel.Visibility = Visibility.Visible;
            }
            PagerPanel.Visibility = result.Items.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            PreviousButton.IsEnabled = _page > 1;
            NextButton.IsEnabled = _hasMore;
            PageText.Text = $"صفحه {_page}";
        }
        catch (OperationCanceledException)
        {
            // superseded request
        }
        catch (Exception ex)
        {
            MessageText.Text = ex.Message;
            MessagePanel.Visibility = Visibility.Visible;
            PagerPanel.Visibility = Visibility.Collapsed;
        }
        finally
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private async void Search_Click(object sender, RoutedEventArgs e) => await ExecuteSearchAsync(1);
    private async void Next_Click(object sender, RoutedEventArgs e) => await ExecuteSearchAsync(_page + 1);
    private async void Previous_Click(object sender, RoutedEventArgs e) => await ExecuteSearchAsync(Math.Max(1, _page - 1));

    private async void QueryBox_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        e.Handled = true;
        await ExecuteSearchAsync(1);
    }

    private void Clear_Click(object sender, RoutedEventArgs e)
    {
        QueryBox.Clear();
        TypeBox.SelectedValue = "all";
        GenreBox.SelectedIndex = 0;
        YearBox.SelectedIndex = 0;
        RatingBox.SelectedIndex = 0;
        LanguageBox.SelectedIndex = 0;
        SortBox.SelectedValue = "newest";
        ResultsItems.ItemsSource = null;
        ResultCount.Text = string.Empty;
        PagerPanel.Visibility = Visibility.Collapsed;
        MessageText.Text = "برای شروع، عبارت جستجو یا فیلترها را انتخاب کن.";
        MessagePanel.Visibility = Visibility.Visible;
        QueryBox.Focus();
    }

    private void MovieCard_Clicked(object sender, RoutedEventArgs e)
    {
        if (sender is MovieCard { Item: { } movie }) OpenMovieRequested?.Invoke(this, movie);
    }
}
