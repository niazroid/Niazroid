using System.Windows;
using System.Windows.Controls;
using BankMovie.Windows.Controls;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows.Views;

public partial class BrowseView : UserControl
{
    private readonly Api6Client _api;
    private readonly string _section;
    private int _page = 1;
    private bool _hasMore;
    private CancellationTokenSource? _loadCts;

    public event EventHandler<MovieItem>? OpenMovieRequested;

    public BrowseView(Api6Client api, string title, string section)
    {
        InitializeComponent();
        _api = api;
        _section = section;
        TitleText.Text = title;
        Loaded += async (_, _) =>
        {
            if (ResultsItems.ItemsSource is null) await LoadPageAsync(1);
        };
        Unloaded += (_, _) => _loadCts?.Cancel();
    }

    private async Task LoadPageAsync(int page)
    {
        _loadCts?.Cancel();
        _loadCts = new CancellationTokenSource();
        LoadingOverlay.Visibility = Visibility.Visible;
        MessagePanel.Visibility = Visibility.Collapsed;
        try
        {
            var result = await _api.GetSectionAsync(_section, page, 30, _loadCts.Token);
            _page = result.Page > 0 ? result.Page : page;
            _hasMore = result.HasMore || result.NextPage is > 0;
            ResultsItems.ItemsSource = result.Items;
            MessageText.Text = result.Items.Count == 0 ? "برای این بخش نتیجه‌ای پیدا نشد." : string.Empty;
            MessagePanel.Visibility = result.Items.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            UpdatePager();
        }
        catch (OperationCanceledException)
        {
            // navigation or a newer request
        }
        catch (Exception ex)
        {
            MessageText.Text = ex.Message;
            MessagePanel.Visibility = Visibility.Visible;
        }
        finally
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private void UpdatePager()
    {
        PageText.Text = $"صفحه {_page}";
        PreviousButton.IsEnabled = _page > 1;
        NextButton.IsEnabled = _hasMore;
    }

    private void MovieCard_Clicked(object sender, RoutedEventArgs e)
    {
        if (sender is MovieCard { Item: { } movie }) OpenMovieRequested?.Invoke(this, movie);
    }

    private async void Next_Click(object sender, RoutedEventArgs e) => await LoadPageAsync(_page + 1);
    private async void Previous_Click(object sender, RoutedEventArgs e) => await LoadPageAsync(Math.Max(1, _page - 1));
    private async void Refresh_Click(object sender, RoutedEventArgs e) => await LoadPageAsync(_page);
}
