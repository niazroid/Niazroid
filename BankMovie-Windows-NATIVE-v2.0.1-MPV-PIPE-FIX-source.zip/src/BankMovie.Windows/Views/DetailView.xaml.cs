using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BankMovie.Windows.Controls;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows.Views;

public partial class DetailView : UserControl
{
    private readonly Api6Client _api;
    private readonly MovieItem _seed;
    private MovieItem _movie;
    private CancellationTokenSource? _loadCts;

    public event EventHandler<(MovieItem Movie, MediaLink Link, IReadOnlyList<MediaLink> AllLinks)>? PlayRequested;
    public event EventHandler<MovieItem>? OpenMovieRequested;

    public DetailView(Api6Client api, MovieItem seed)
    {
        InitializeComponent();
        _api = api;
        _seed = seed;
        _movie = seed;
        DataContext = seed;
        Loaded += async (_, _) => await LoadDetailsAsync();
        Unloaded += (_, _) => _loadCts?.Cancel();
    }

    private async Task LoadDetailsAsync()
    {
        _loadCts?.Cancel();
        _loadCts = new CancellationTokenSource();
        LoadingOverlay.Visibility = Visibility.Visible;
        ErrorPanel.Visibility = Visibility.Collapsed;
        try
        {
            _movie = await _api.GetDetailsAsync(_seed, _loadCts.Token);
            DataContext = _movie;
            LinksItems.ItemsSource = _movie.Links.Where(x => !x.IsAudio).ToList();
            LinkCountText.Text = _movie.Links.Count == 0 ? "بدون لینک قابل پخش" : $"{_movie.Links.Count} نسخه";
            PlayButton.IsEnabled = GetPlayableLinks().Count > 0;
            RelatedItems.ItemsSource = _movie.Related;
            RelatedPanel.Visibility = _movie.Related.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            if (_movie.Links.Count == 0)
            {
                ErrorText.Text = "برای این عنوان فعلاً لینک پخش قابل استفاده‌ای دریافت نشد.";
                ErrorPanel.Visibility = Visibility.Visible;
            }
        }
        catch (OperationCanceledException)
        {
            // normal navigation
        }
        catch (Exception ex)
        {
            ErrorText.Text = ex.Message;
            ErrorPanel.Visibility = Visibility.Visible;
            PlayButton.IsEnabled = false;
        }
        finally
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private List<MediaLink> GetPlayableLinks() => _movie.Links
        .Where(x => x.IsPlayable && !x.IsAudio && Uri.TryCreate(x.Url, UriKind.Absolute, out _))
        .OrderByDescending(x => x.Season)
        .ThenByDescending(x => x.Episode)
        .ThenByDescending(x => x.QualityScore)
        .ToList();

    private void PlayButton_Click(object sender, RoutedEventArgs e)
    {
        var links = GetPlayableLinks();
        if (links.Count == 0) return;
        if (links.Count == 1)
        {
            RaisePlay(links[0], links);
            return;
        }
        var picker = new QualityPickerWindow(links)
        {
            Owner = Window.GetWindow(this)
        };
        if (picker.ShowDialog() == true && picker.SelectedLink is not null) RaisePlay(picker.SelectedLink, links);
    }

    private void LinkPlay_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: MediaLink link }) RaisePlay(link, GetPlayableLinks());
    }

    private void RaisePlay(MediaLink link, IReadOnlyList<MediaLink> allLinks) =>
        PlayRequested?.Invoke(this, (_movie, link, allLinks));

    private async void Retry_Click(object sender, RoutedEventArgs e) => await LoadDetailsAsync();

    private void RelatedCard_Clicked(object sender, RoutedEventArgs e)
    {
        if (sender is MovieCard { Item: { } movie }) OpenMovieRequested?.Invoke(this, movie);
    }

    private void RelatedScroller_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (sender is ScrollViewer scrollViewer)
        {
            scrollViewer.ScrollToHorizontalOffset(scrollViewer.HorizontalOffset - e.Delta);
            e.Handled = true;
        }
    }
}
