using System.Windows;
using System.Windows.Controls;
using BankMovie.Windows.Controls;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows.Views;

public partial class HomeView : UserControl
{
    private readonly Api6Client _api;
    private readonly IReadOnlyList<HomeSectionDefinition> _definitions;
    private CancellationTokenSource? _loadCts;
    private MovieItem? _hero;

    public event EventHandler<MovieItem>? OpenMovieRequested;
    public event EventHandler<(string Title, string Section)>? ShowSectionRequested;

    public HomeView(Api6Client api, IReadOnlyList<HomeSectionDefinition> definitions)
    {
        InitializeComponent();
        _api = api;
        _definitions = definitions;
        Loaded += HomeView_Loaded;
        Unloaded += (_, _) => _loadCts?.Cancel();
    }

    private async void HomeView_Loaded(object sender, RoutedEventArgs e)
    {
        if (SectionsPanel.Children.Count > 0) return;
        await LoadAsync();
    }

    public async Task LoadAsync()
    {
        _loadCts?.Cancel();
        _loadCts = new CancellationTokenSource();
        var token = _loadCts.Token;
        LoadingOverlay.Visibility = Visibility.Visible;
        ErrorPanel.Visibility = Visibility.Collapsed;
        SectionsPanel.Children.Clear();
        var failures = new List<string>();

        try
        {
            foreach (var definition in _definitions)
            {
                try
                {
                    var result = await _api.GetSectionAsync(definition.Key, 1, 18, token);
                    if (token.IsCancellationRequested) return;
                    if (result.Items.Count == 0) continue;
                    _hero ??= result.Items.FirstOrDefault();
                    if (DataContext is null && _hero is not null) DataContext = _hero;

                    var section = new MovieSectionView
                    {
                        Title = definition.Title,
                        SectionKey = definition.Key,
                        Items = result.Items
                    };
                    section.MovieSelected += (_, movie) => OpenMovieRequested?.Invoke(this, movie);
                    section.ShowAllRequested += (_, key) => ShowSectionRequested?.Invoke(this, (definition.Title, key));
                    SectionsPanel.Children.Add(section);
                }
                catch (OperationCanceledException)
                {
                    return;
                }
                catch (Exception ex)
                {
                    failures.Add($"{definition.Title}: {ex.Message}");
                }
            }

            if (_hero is null)
            {
                ErrorText.Text = failures.Count > 0
                    ? string.Join("\n", failures)
                    : "محتوایی از آرشیو دریافت نشد.";
                ErrorPanel.Visibility = Visibility.Visible;
            }
            else if (failures.Count > 0)
            {
                ErrorText.Text = "بعضی ردیف‌ها موقتاً دریافت نشدند. سایر بخش‌ها قابل استفاده‌اند.";
                ErrorPanel.Visibility = Visibility.Visible;
            }
        }
        finally
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
        }
    }

    private void HeroOpen_Click(object sender, RoutedEventArgs e)
    {
        if (_hero is not null) OpenMovieRequested?.Invoke(this, _hero);
    }

    private async void Retry_Click(object sender, RoutedEventArgs e)
    {
        _hero = null;
        DataContext = null;
        await LoadAsync();
    }
}
