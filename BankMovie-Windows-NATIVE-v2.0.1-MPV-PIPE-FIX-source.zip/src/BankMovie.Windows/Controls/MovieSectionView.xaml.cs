using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Controls;

public partial class MovieSectionView : UserControl
{
    public static readonly DependencyProperty TitleProperty = DependencyProperty.Register(
        nameof(Title), typeof(string), typeof(MovieSectionView), new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty SectionKeyProperty = DependencyProperty.Register(
        nameof(SectionKey), typeof(string), typeof(MovieSectionView), new PropertyMetadata(string.Empty));

    public static readonly DependencyProperty ItemsProperty = DependencyProperty.Register(
        nameof(Items), typeof(ObservableCollection<MovieItem>), typeof(MovieSectionView), new PropertyMetadata(null));

    public event EventHandler<MovieItem>? MovieSelected;
    public event EventHandler<string>? ShowAllRequested;

    public MovieSectionView()
    {
        InitializeComponent();
        Items = [];
    }

    public string Title
    {
        get => (string)GetValue(TitleProperty);
        set => SetValue(TitleProperty, value);
    }

    public string SectionKey
    {
        get => (string)GetValue(SectionKeyProperty);
        set => SetValue(SectionKeyProperty, value);
    }

    public ObservableCollection<MovieItem> Items
    {
        get => (ObservableCollection<MovieItem>)GetValue(ItemsProperty);
        set => SetValue(ItemsProperty, value);
    }

    private void MovieCard_Clicked(object sender, RoutedEventArgs e)
    {
        if (sender is MovieCard { Item: { } movie }) MovieSelected?.Invoke(this, movie);
    }

    private void ShowAll_Click(object sender, RoutedEventArgs e) => ShowAllRequested?.Invoke(this, SectionKey);

    private void Scroller_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        Scroller.ScrollToHorizontalOffset(Scroller.HorizontalOffset - e.Delta);
        e.Handled = true;
    }
}
