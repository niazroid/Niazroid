using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Controls;

public partial class MovieCard : UserControl
{
    public static readonly DependencyProperty ItemProperty = DependencyProperty.Register(
        nameof(Item),
        typeof(MovieItem),
        typeof(MovieCard),
        new PropertyMetadata(null, OnItemChanged));

    public static readonly RoutedEvent ClickedEvent = EventManager.RegisterRoutedEvent(
        nameof(Clicked),
        RoutingStrategy.Bubble,
        typeof(RoutedEventHandler),
        typeof(MovieCard));

    public MovieCard()
    {
        InitializeComponent();
    }

    public MovieItem? Item
    {
        get => (MovieItem?)GetValue(ItemProperty);
        set => SetValue(ItemProperty, value);
    }

    public event RoutedEventHandler Clicked
    {
        add => AddHandler(ClickedEvent, value);
        remove => RemoveHandler(ClickedEvent, value);
    }

    private static void OnItemChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs args)
    {
        if (dependencyObject is MovieCard card) card.DataContext = args.NewValue;
    }

    private void Root_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (Item is null) return;
        RaiseEvent(new RoutedEventArgs(ClickedEvent, this));
    }

    private void Root_MouseEnter(object sender, System.Windows.Input.MouseEventArgs e) => SetHighlight(true, false);
    private void Root_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e) => SetHighlight(IsKeyboardFocusWithin, IsKeyboardFocusWithin);
    private void Root_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) => SetHighlight(true, true);
    private void Root_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e) => SetHighlight(IsMouseOver, false);

    private void SetHighlight(bool highlighted, bool keyboard)
    {
        CardBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(highlighted ? (keyboard ? "#CC45A1FF" : "#84238BFF") : "#20FFFFFF"));
        CardBorder.BorderThickness = new Thickness(keyboard ? 2 : 1);
        CardBorder.Effect = highlighted ? new DropShadowEffect { Color = Color.FromRgb(35, 139, 255), BlurRadius = 24, ShadowDepth = 0, Opacity = 0.24 } : null;
        RenderTransformOrigin = new Point(0.5, 0.5);
        RenderTransform = new ScaleTransform(highlighted ? 1.035 : 1, highlighted ? 1.035 : 1);
    }

    private void Root_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
    {
        if (e.Key is Key.Enter or Key.Space)
        {
            e.Handled = true;
            RaiseEvent(new RoutedEventArgs(ClickedEvent, this));
        }
    }
}
