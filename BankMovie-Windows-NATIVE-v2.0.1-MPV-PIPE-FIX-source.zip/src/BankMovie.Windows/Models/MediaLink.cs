namespace BankMovie.Windows.Models;

public sealed class MediaLink
{
    public string Url { get; set; } = string.Empty;
    public string Quality { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string TypeFa { get; set; } = string.Empty;
    public string DisplayLabel { get; set; } = string.Empty;
    public string Size { get; set; } = string.Empty;
    public int Season { get; set; }
    public int Episode { get; set; }
    public bool IsDirect { get; set; } = true;
    public bool IsDownload { get; set; }
    public bool IsPlayable { get; set; } = true;
    public bool IsAudio { get; set; }

    public string KindLabel => !string.IsNullOrWhiteSpace(TypeFa) ? TypeFa : Type.ToLowerInvariant() switch
    {
        "dub" or "dubbed" => "دوبله",
        "hardsub" or "hard-sub" => "هاردساب",
        "softsub" or "soft-sub" => "سافت‌ساب",
        "subtitle" => "زیرنویس",
        "audio" => "صوت دوبله",
        _ => "نسخه پخش"
    };

    public string EpisodeLabel => Season > 0 || Episode > 0
        ? $"فصل {Math.Max(Season, 1)} • قسمت {Math.Max(Episode, 1)}"
        : string.Empty;

    public string Label
    {
        get
        {
            var parts = new[]
            {
                EpisodeLabel,
                DisplayLabel,
                string.IsNullOrWhiteSpace(DisplayLabel) ? Quality : string.Empty,
                string.IsNullOrWhiteSpace(DisplayLabel) ? KindLabel : string.Empty,
                string.IsNullOrWhiteSpace(DisplayLabel) ? Size : string.Empty
            }.Where(x => !string.IsNullOrWhiteSpace(x));
            return string.Join("  •  ", parts).Trim();
        }
    }

    public int QualityScore
    {
        get
        {
            var match = System.Text.RegularExpressions.Regex.Match(Quality ?? string.Empty, @"\d+");
            return match.Success && int.TryParse(match.Value, out var value) ? value : 0;
        }
    }
}
