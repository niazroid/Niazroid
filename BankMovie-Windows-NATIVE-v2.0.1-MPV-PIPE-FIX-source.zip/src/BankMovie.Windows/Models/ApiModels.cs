using System.Collections.ObjectModel;

namespace BankMovie.Windows.Models;

public sealed class ApiListResult
{
    public ObservableCollection<MovieItem> Items { get; init; } = [];
    public int Page { get; init; } = 1;
    public bool HasMore { get; init; }
    public int? NextPage { get; init; }
    public int Count { get; init; }
}

public sealed class SearchQuery
{
    public string Query { get; set; } = string.Empty;
    public string Type { get; set; } = "all";
    public string Genre { get; set; } = string.Empty;
    public string Year { get; set; } = string.Empty;
    public string ImdbScore { get; set; } = string.Empty;
    public string Language { get; set; } = string.Empty;
    public string Sort { get; set; } = "newest";
    public int Page { get; set; } = 1;
}

public sealed class OptionItem
{
    public string Value { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
    public int? Count { get; set; }
    public string DisplayLabel => Count is > 0 ? $"{Label}  ({Count:N0})" : Label;
    public override string ToString() => DisplayLabel;
}

public sealed class SearchOptions
{
    public ObservableCollection<OptionItem> Types { get; init; } = [];
    public ObservableCollection<OptionItem> Genres { get; init; } = [];
    public ObservableCollection<OptionItem> Years { get; init; } = [];
    public ObservableCollection<OptionItem> ImdbScores { get; init; } = [];
    public ObservableCollection<OptionItem> Languages { get; init; } = [];
    public ObservableCollection<OptionItem> Sorts { get; init; } = [];
}

public sealed class HomeSectionDefinition
{
    public string Key { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
}

public sealed class AppSettings
{
    public string Api6Url { get; set; } = "https://bankmovie.top/api6.php";
    public string SiteRoot { get; set; } = "https://bankmovie.top";
    public int RequestTimeoutSeconds { get; set; } = 25;
    public List<HomeSectionDefinition> HomeSections { get; set; } = [];
}
