using System.Collections.ObjectModel;

namespace BankMovie.Windows.Models;

public sealed class MovieItem
{
    public string Id { get; set; } = string.Empty;
    public string DetailId { get; set; } = string.Empty;
    public string SourceUrl { get; set; } = string.Empty;
    public string Slug { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string TitleFa { get; set; } = string.Empty;
    public string FullTitle { get; set; } = string.Empty;
    public string Type { get; set; } = string.Empty;
    public string MediaKind { get; set; } = string.Empty;
    public string Poster { get; set; } = string.Empty;
    public string Backdrop { get; set; } = string.Empty;
    public int? Year { get; set; }
    public double? Rating { get; set; }
    public int? Runtime { get; set; }
    public string Description { get; set; } = string.Empty;
    public string LongDescription { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    public string Trailer { get; set; } = string.Empty;
    public bool HasDubbed { get; set; }
    public bool HasSubtitle { get; set; }
    public bool HasOnline { get; set; }
    public List<string> Genres { get; set; } = [];
    public List<string> Countries { get; set; } = [];
    public List<string> Actors { get; set; } = [];
    public List<string> Directors { get; set; } = [];
    public List<string> Writers { get; set; } = [];
    public ObservableCollection<MediaLink> Links { get; set; } = [];
    public ObservableCollection<MovieItem> Related { get; set; } = [];

    public string DisplayTitle => FirstNotEmpty(TitleFa, FullTitle, Title, "بدون عنوان");
    public string SecondaryTitle => string.Equals(DisplayTitle, Title, StringComparison.OrdinalIgnoreCase) ? string.Empty : Title;
    public string HeroImage => FirstNotEmpty(Backdrop, Poster);
    public string DescriptionText => FirstNotEmpty(LongDescription, Description, "برای این عنوان هنوز خلاصه‌ای ثبت نشده است.");
    public string GenresText => Genres.Count == 0 ? string.Empty : string.Join("  •  ", Genres);
    public string CountriesText => Countries.Count == 0 ? string.Empty : string.Join("، ", Countries);
    public string DirectorsText => Directors.Count == 0 ? string.Empty : string.Join("، ", Directors);
    public string ActorsText => Actors.Count == 0 ? string.Empty : string.Join("، ", Actors);
    public string YearText => Year?.ToString() ?? string.Empty;
    public string RatingText => Rating is null ? "N/A" : Rating.Value.ToString("0.0", System.Globalization.CultureInfo.InvariantCulture);
    public string ImdbText => $"IMDb {RatingText}";
    public string RuntimeText => Runtime is null or <= 0 ? string.Empty : $"{Runtime} دقیقه";
    public bool HasStatus => !string.IsNullOrWhiteSpace(Status);
    public bool HasSecondaryTitle => !string.IsNullOrWhiteSpace(SecondaryTitle);
    public bool HasPoster => !string.IsNullOrWhiteSpace(Poster);
    public bool HasBackdrop => !string.IsNullOrWhiteSpace(HeroImage);
    public bool IsSeries => Type.Contains("series", StringComparison.OrdinalIgnoreCase) || Links.Any(x => x.Season > 0 || x.Episode > 0);
    public string TypeLabel => MediaKind.ToLowerInvariant() switch
    {
        "animation" => "انیمیشن",
        "anime" => "انیمه",
        _ when IsSeries => "سریال",
        _ => "فیلم"
    };

    public string DetailKey => FirstNotEmpty(DetailId, Id, Slug);

    private static string FirstNotEmpty(params string[] values) =>
        values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value))?.Trim() ?? string.Empty;
}
