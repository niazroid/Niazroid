موتور mpv هنگام Build توسط GitHub Actions به این پوشه افزوده می‌شود.
فایل مورد انتظار در خروجی نهایی: mpv\mpv.exe
