# Third-party notices

BankMovie Windows Native uses the mpv media player at runtime.

mpv is free and open-source software. The GitHub Actions workflow downloads a Windows x64 build during packaging. The exact licenses applicable to the downloaded build and its bundled libraries are included by that distribution and must be preserved when redistributing the installer.

This source package does not contain an mpv binary.
