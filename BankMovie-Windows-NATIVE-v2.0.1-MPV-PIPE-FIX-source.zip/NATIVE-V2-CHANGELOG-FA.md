# تغییرات Native v2

- بازنویسی کامل Shell برنامه با WPF/XAML
- حذف کامل WebView2 از پروژه و Installer
- حذف کامل LibVLCSharp و VideoLAN.LibVLC.Windows
- ایجاد کلاینت مقاوم API6 با Retry، Timeout، UTF-8 و فیلدهای Nullable
- ساخت کارت‌های فیلم مطابق رنگ‌ها و کارت‌های HTML/CSS سایت
- ساخت Hero تیره با گرادیان آبی/بنفش و لوگوی اصلی BankMovie
- ساخت صفحات Home، Browse، Search و Detail به‌صورت بومی
- دریافت خودکار لینک پخش از `downloads`، `links` یا `play.links`
- حفظ تفکیک دوبله، هاردساب، سافت‌ساب، زیرنویس و صوت دوبله
- ساخت پنجره انتخاب کیفیت داخل برنامه
- تعبیه mpv در همان صفحه برنامه با IPC و HWND
- جلوگیری از بسته‌شدن برنامه هنگام توقف موتور پخش
- اضافه‌شدن ادامه پخش از LocalAppData
- ساخت Setup واحد و حذف خروجی تکراری Portable
