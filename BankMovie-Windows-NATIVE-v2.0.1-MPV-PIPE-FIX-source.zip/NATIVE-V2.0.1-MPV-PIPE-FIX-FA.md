# اصلاح نسخه 2.0.1

- رفع خطای کامپایل CS8087 و CS1009 در مسیر Named Pipe موتور mpv.
- ساخت مسیر IPC بدون interpolated string و بدون escape نامعتبر.
- نام فایل سورس و Workflow روی نسخه 2.0.1 ثابت شده است.
