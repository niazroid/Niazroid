/* BankMovie Windows v1.1.47: single-source Desktop feature gates + readable comment form.
   Loaded AFTER app.js so it wraps only the final legacy handlers, with no global CSS rewrites. */
(function(){
'use strict';
const P=window.BMDesktopPolicy;
if(!P)return;
const can=(key)=>P.enabled(state.config,key);
const sectionOn=(key)=>P.section(state.config,key);
const label=(fa,en)=>((state.language||'fa')==='en'?en:fa);
const denied=()=>toast(label('این قابلیت از پنل مدیریت ویندوز غیرفعال شده است.','This feature is disabled.'),'error');
const toggle=(selector,on,scope=document)=>scope.querySelectorAll(selector).forEach(el=>el.classList.toggle('bm-section-disabled',!on));
const srcKey=d=>typeof watchKey==='function'?watchKey(d):String(d?.id||'');
const drafts=new Map();

// Honor both the signed Desktop feature flags and independently configured UI sections.
feature=(name,fallback=true)=>P.enabled(state.config,name,fallback);
bm1124SectionEnabled=(name,fallback=true)=>P.section(state.config,name,fallback);
const originalHomeSections=homeSectionsFor;
homeSectionsFor=function(a){return originalHomeSections(a).filter(name=>P.contentSection(state.config,a,name));};

function applyPolicy(root=document){
  if(!state.config)return;
  bm1124ApplySectionControls(root);
  toggle('[data-detail-tab="comments"]',sectionOn('comments'),root);
  toggle('[data-detail-tab="info"]',sectionOn('info'),root);
  toggle('[data-detail-tab="sources"]',sectionOn('sources'),root);
  toggle('#watchBtn',sectionOn('watchlist'),root);
  toggle('#headerAdvancedFilter',can('advanced_search_enabled')&&sectionOn('advanced_search'),root);
  toggle('#chooseDir',can('download_path_selection_enabled'),root);
  toggle('#preferredPlayer',can('external_player_fallback_enabled'),root);
  toggle('#commentSticker',sectionOn('comments'),root);
  toggle('[data-comment-action="reply"]',can('comment_replies_enabled'),root);
  toggle('[data-comment-action="like"],[data-comment-action="dislike"]',can('comment_votes_enabled'),root);
  toggle('[data-comment-action="report"]',can('comment_reports_enabled'),root);
  toggle('#commentSpoiler',can('comment_spoiler_enabled'),root);
  root.querySelectorAll('#commentSpoiler').forEach(el=>{if(!can('comment_spoiler_enabled'))el.closest('.bm1135-spoiler-reactor,.bm-spoiler-check')?.classList.add('bm-section-disabled')});
  toggle('[data-source-download],[data-series-source-download]',can('internal_downloader_enabled'),root);
  toggle('#downloadsHeader',sectionOn('downloads'),root);
  toggle('#notificationsHeader',sectionOn('notifications'),root);
  toggle('#watchlistHeader',sectionOn('watchlist'),root);
}

const originalDetail=renderDetail;
renderDetail=function(d){
  originalDetail(d);
  applyPolicy(document);
  const first=[...document.querySelectorAll('.detail [data-detail-tab]')].find(el=>!el.classList.contains('bm-section-disabled'));
  if(first&&first.dataset.detailTab!=='sources')first.click();
  if(!first){const box=document.getElementById('detailTab');if(box)box.innerHTML='<div class="empty">بخش‌های این عنوان از پنل مدیریت غیرفعال شده‌اند.</div>';}
};
const originalTab=switchDetailTab;
switchDetailTab=function(name,d,links,tab){
  if(!sectionOn(name))return denied();
  const result=originalTab(name,d,links,tab);
  applyPolicy(document);
  return result;
};

// Clean and accessible composer. Avoid the legacy layered white animated NSIS-like button.
bm192ComposerHtml=function(d){
  const avatar=bm192AvatarUrl(state.user),name=state.user?.username||'شما',en=(state.language||'fa')==='en';
  const spoiler=can('comment_spoiler_enabled')
    ? `<label class="bm147-spoiler"><input id="commentSpoiler" type="checkbox"><span>${en?'Contains spoilers':'دیدگاه حاوی اسپویل است'}</span></label>` : '';
  const media=`<button class="bm147-media btn ghost slim" type="button" id="commentSticker" title="Emoji / GIF / Sticker">☺ <span>${en?'Emoji / Sticker / GIF':'ایموجی / استیکر / GIF'}</span></button>`;
  return `<section class="bm-comment-composer bm147-composer" dir="rtl">
    <div class="bm147-composer-top"><div class="bm147-user">${avatar?`<img class="bm147-user-avatar" src="${esc(avatar)}" alt="">`:`<span class="bm-comment-avatar-fallback">${esc(String(name).slice(0,1).toUpperCase())}</span>`}<div><strong>${esc(name)}</strong><small>${en?'Share your review':'نظر خودت را درباره این عنوان بنویس'}</small></div></div><div class="bm147-stars" id="commentStars" aria-label="امتیاز اختیاری">${[1,2,3,4,5].map(i=>`<button type="button" data-comment-star="${i}" aria-label="${i} ${en?'stars':'ستاره'}">☆</button>`).join('')}</div></div>
    ${typeof bm110SelectedPreview==='function'?bm110SelectedPreview(bm110MainMedia):''}
    <label class="bm147-input-label" for="commentText">${en?'Your comment':'متن دیدگاه'}</label>
    <textarea class="form-control bm-comment-textarea bm147-textarea" id="commentText" maxlength="5000" rows="5" placeholder="${en?'Write your thoughts about the movie or series…':'نظرت درباره فیلم یا سریال چیه؟ اینجا بنویس…'}"></textarea>
    <div class="bm147-composer-foot"><div class="bm147-controls">${spoiler}${media}</div><div class="bm147-submit-area"><small id="bm147Count">۰ / ۵۰۰۰</small><button class="bm147-send" id="sendComment" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 3 9 15"/><path d="m21 3-7 18-5-6-6-5 18-7Z"/></svg><span>${en?'Post comment':'ارسال دیدگاه'}</span></button></div></div>
  </section>`;
};

const originalComments=renderCommentsBox;
renderCommentsBox=function(d){
  if(!sectionOn('comments')){
    const box=document.getElementById('detailTab');if(box)box.innerHTML='<div class="bm147-feature-off">دیدگاه‌ها در حال حاضر غیرفعال هستند.</div>';
    return;
  }
  const key=srcKey(d);
  originalComments(d);
  const input=document.getElementById('commentText');
  const send=document.getElementById('sendComment');
  if(input){
    input.value=drafts.get(key)||'';
    input.oninput=()=>{drafts.set(key,input.value);const count=document.getElementById('bm147Count');if(count)count.textContent=`${input.value.length.toLocaleString('fa-IR')} / ۵۰۰۰`;};
    input.dispatchEvent(new Event('input'));
  }
  // Replace the final legacy optimistic handler. Keep the draft if the server rejects.
  if(send){
    const btn=send.cloneNode(true);send.replaceWith(btn);
    btn.onclick=async()=>{
      if(!sectionOn('comments'))return denied();
      const text=input?.value.trim()||'',media=typeof bm110Marker==='function'?bm110Marker(bm110MainMedia):'';
      if(text.length<3&&!media)return toast(label('برای ارسال، حداقل چند حرف بنویس یا رسانه انتخاب کن.','Enter a comment or choose media.'),'error');
      const spoiler=!!document.getElementById('commentSpoiler')?.checked;
      if(spoiler&&!can('comment_spoiler_enabled'))return denied();
      btn.disabled=true;btn.classList.add('loading');
      try{
        await bridge.user('comment_add',{item:d,comment:[text,media].filter(Boolean).join('\n'),rating:bm192CommentRating,spoiler:spoiler?1:0},'POST');
        drafts.delete(key);bm110MainMedia=null;bm192CommentRating=0;bm192CommentSpoiler=false;
        toast(label('دیدگاه ثبت شد.','Comment posted.'),'ok');
        await loadComments(d);
        if(state.currentDetail&&srcKey(state.currentDetail)===key)renderCommentsBox(d);
      }catch(e){toast(publicUiError(e),'error');btn.disabled=false;btn.classList.remove('loading');}
    };
  }
  const mediaBtn=document.getElementById('commentSticker');
  if(mediaBtn){mediaBtn.onclick=()=>{
    if(!sectionOn('comments'))return denied();
    bm110OpenMediaPicker('commentText',m=>{bm110MainMedia=m;renderCommentsBox(d)});
  };}
  applyPolicy(document);
};

const originalAction=commentAction;
commentAction=async function(name,id,txt,d){
  if(!P.action(state.config,'comment_'+name))return denied();
  return originalAction(name,id,txt,d);
};
const originalReply=bm192ReplyComposer;
bm192ReplyComposer=function(id,d){if(!can('comment_replies_enabled')||!sectionOn('comments'))return denied();return originalReply(id,d);};
const guarded={showNotifications:'notifications',showWatchlist:'watchlist',showDownloads:'downloads',showCategories:'categories',showCollections:'collections',showBoxOffice:'boxoffice',showParty:null};
for(const [name,key] of Object.entries(guarded)){
  const fn=({showNotifications,showWatchlist,showDownloads,showCategories,showCollections,showBoxOffice,showParty})[name];
  if(typeof fn!=='function')continue;
  const f=function(...args){if(key&&!sectionOn(key))return denied();if(name==='showParty'&&!can('watch_party_enabled'))return denied();return fn(...args);};
  if(name==='showNotifications')showNotifications=f;
  if(name==='showWatchlist')showWatchlist=f;
  if(name==='showDownloads')showDownloads=f;
  if(name==='showCategories')showCategories=f;
  if(name==='showCollections')showCollections=f;
  if(name==='showBoxOffice')showBoxOffice=f;
  if(name==='showParty')showParty=f;
}
const originalAuth=showAuthModal;
showAuthModal=function(initial='login'){
  const canLogin=can('login_enabled'),canRegister=can('registration_enabled');
  if(!canLogin&&!canRegister)return denied();
  const r=originalAuth(initial==='register'&&canRegister?'register':canLogin?'login':'register');
  toggle('[data-auth-tab="login"]',canLogin,document);
  toggle('[data-auth-tab="register"]',canRegister,document);
  return r;
};
const originalVip=showVipPlansModal;
showVipPlansModal=function(...args){if(!sectionOn('vip'))return denied();return originalVip(...args);};
const originalSettings=showSettings;
showSettings=async function(...args){
  const r=await originalSettings(...args);applyPolicy(document);
  const net=document.getElementById('testNetwork');
  if(net && !document.getElementById('bm147RefreshSettings')){
    const button=document.createElement('button');button.type='button';button.className='btn ghost';
    button.id='bm147RefreshSettings';button.textContent='دریافت تنظیمات پنل';net.insertAdjacentElement('afterend',button);
    button.onclick=async()=>{button.disabled=true;button.textContent='در حال دریافت…';
      const ok=await refreshFlags();
      if(!ok)toast('کنترلر در دسترس نیست؛ تنظیمات آخرین نسخه معتبر حفظ شد.','error');
      else toast('تنظیمات پنل دریافت شد.','ok');
      button.disabled=false;button.textContent='دریافت تنظیمات پنل';
    };
  }
  return r;
};

const originalRoute=route;
route=async function(view,force=false){
  const v={categories:'categories',collections:'collections',boxoffice:'boxoffice',watchlist:'watchlist',notifications:'notifications',downloads:'downloads',profile:'profile'}[view];
  if(v&&!sectionOn(v))return denied();
  const r=await originalRoute(view,force);applyPolicy(document);return r;
};

// Controller's signed config can change while the desktop app remains open.
// One lightweight fetch every 120s, plus focus-based refresh no more than once a minute.
let refreshedAt=Date.now(),busy=false;
async function refreshFlags(){
  if(busy||!state.config||!bridge.refreshConfig)return false;
  busy=true;refreshedAt=Date.now();
  try{
    const next=await bridge.refreshConfig();
    if(!next?._verified||!next?._online)return false; // don't override trusted flags with unsigned/unavailable values
    const subset=x=>JSON.stringify({desktop:x?.desktop,features:x?.features,sections:x?.sections,home:x?.home_section_policy});
    if(subset(next)!==subset(state.config)){
      state.config=next;applyRemoteNotice();renderTopCategories();
      if(document.querySelector('.detail')&&state.currentDetail)renderDetail(state.currentDetail);
      else if(state.lastView==='home')await showHome(false);
      applyPolicy(document);
    }
    return true;
  }catch{return false;}finally{busy=false;}
}
setInterval(refreshFlags,120000);
window.addEventListener('focus',()=>{if(Date.now()-refreshedAt>60000)refreshFlags()});
const baseBind=bindGlobalUI;
bindGlobalUI=function(...args){const r=baseBind(...args);applyPolicy(document);return r;};
})();
