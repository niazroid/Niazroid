/* BankMovie Desktop policy v1.1.47. Same pure policy is used by the UI and Electron main.
 * Missing keys keep the previous behavior; explicit false is never silently re-enabled.
 */
(function(root, factory) {
  const value=factory();
  if (typeof module==='object' && module.exports) module.exports=value;
  if (root) root.BMDesktopPolicy=value;
})(typeof window==='object'?window:null,function(){
  'use strict';
  const FEATURE_FOR_SECTION=Object.freeze({
    comments:'comments_enabled', notifications:'notification_center_enabled',
    watchlist:'watchlist_enabled', downloads:'internal_downloader_enabled',
    advanced_search:'advanced_search_enabled',categories:'categories_enabled',
    profile:null
  });
  const FEATURE_FOR_ACTION=Object.freeze({
    register:'registration_enabled',login:'login_enabled',
    comments_list:'comments_enabled',comment_add:'comments_enabled',
    comment_reply:'comment_replies_enabled',comment_vote:'comment_votes_enabled',
    comment_report:'comment_reports_enabled',comment_edit:'comments_enabled',
    comment_delete:'comments_enabled',comment_pin:'comments_enabled',
    notifications_list:'notification_center_enabled',
    notifications_read:'notification_center_enabled',notifications_read_all:'notification_center_enabled',
    watch_party_status:'watch_party_enabled',watch_party_create:'watch_party_enabled',
    watch_party_join:'watch_party_enabled',watch_party_leave:'watch_party_enabled',
    watch_party_poll:'watch_party_enabled',watch_party_send:'watch_party_enabled',
    watchlist_list:'watchlist_enabled',watchlist_add:'watchlist_enabled',
    watchlist_remove:'watchlist_enabled',watchlist_toggle:'watchlist_enabled',
    watchlist_get:'watchlist_enabled',watchlist:'watchlist_enabled'
  });
  function explicit(obj,key){return obj && Object.prototype.hasOwnProperty.call(obj,key) ? obj[key]!==false && obj[key]!==0 && obj[key]!=='0' : null;}
  function enabled(config,key,fallback=true){
    const desktop=config?.desktop||{};
    if(desktop.enabled===false)return false;
    const primary=explicit(desktop.features,key);
    if(primary!==null)return primary;
    const common=explicit(config?.features,key);
    return common!==null?common:fallback;
  }
  function section(config,key,fallback=true){
    if(config?.desktop?.enabled===false)return false;
    const primary=explicit(config?.desktop?.sections,key);
    const common=explicit(config?.sections,key);
    const on=primary!==null?primary:(common!==null?common:fallback);
    return on && (!FEATURE_FOR_SECTION[key] || enabled(config,FEATURE_FOR_SECTION[key]));
  }
  function action(config,name){
    name=String(name||'').toLowerCase();
    let feature=FEATURE_FOR_ACTION[name];
    if(!feature && name.startsWith('comment_'))feature='comments_enabled';
    if(!feature && name.startsWith('notifications_'))feature='notification_center_enabled';
    if(!feature && name.startsWith('watch_party_'))feature='watch_party_enabled';
    if(!feature && name.startsWith('watchlist_'))feature='watchlist_enabled';
    if(feature && !enabled(config,feature))return false;
    if(name.startsWith('comment_') && !section(config,'comments'))return false;
    if(name.startsWith('notifications_') && !section(config,'notifications'))return false;
    if(name.startsWith('watchlist_') && !section(config,'watchlist'))return false;
    return true;
  }
  function contentSection(config,archive,key){
    const p=config?.home_section_policy?.['archive'+Number(archive)]?.[key];
    const desktop=config?.desktop?.home_sections?.['archive'+Number(archive)]?.[key];
    return desktop!==false && p?.enabled!==false && p?.access_scope!=='disabled';
  }
  return Object.freeze({enabled,section,action,contentSection,FEATURE_FOR_ACTION,FEATURE_FOR_SECTION});
});
