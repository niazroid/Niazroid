'use strict';
// Isolated navigation regression test: never needs Electron, the API or a DOM emulator.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const path=require('node:path');
const vm=require('node:vm');
const root=path.join(__dirname,'..');
const html=fs.readFileSync(path.join(root,'src/index.html'),'utf8');
const app=fs.readFileSync(path.join(root,'src/app.js'),'utf8');
const style=fs.readFileSync(path.join(root,'src/styles.css'),'utf8');

const header=html.match(/<nav class="desktop-site-nav"[\s\S]*?<\/nav>/)?.[0];
assert.ok(header,'desktop nav exists');
assert.doesNotMatch(header,/data-header-view="weekly"/,'weekly button removed from crowded header');
const dropdown=html.match(/<div class="nav-dropdown-menu" id="categoryDropdown">([\s\S]*?)<\/div>/)?.[1];
assert.ok(dropdown,'categories dropdown exists');
assert.equal((dropdown.match(/data-category-dest="weekly"/g)||[]).length,1,'weekly listed once in categories dropdown');
assert.match(dropdown,/bm-weekly-nav-symbol/,'original calendar icon preserved');
assert.match(app,/class="weekly-category-entry" data-category-card="weekly"/,'weekly listed in Categories page');
assert.match(app,/if\(k==='weekly'\)route\('weekly'\)/,'Categories page navigation wired');
assert.match(app,/if\(view!=='weekly'\)return bmWeeklyRouteBase/,'existing weekly route preserved');
assert.match(app,/home\.append\(weekly\)/,'home weekly section still present');
assert.match(style,/\.weekly-category-entry\{/,'categories tile styling present');

const activeButtons=[{dataset:{headerView:'home'},classList:{toggle(n,v){this.active=v}}},{dataset:{headerView:'categories'},classList:{toggle(n,v){this.active=v}}}];
const navFn=app.match(/function setHeaderActive\(view\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(navFn,'active-header function found');
const setHeaderActive=vm.runInNewContext(`${navFn}\nsetHeaderActive`,{$$:()=>activeButtons});
setHeaderActive('weekly');
assert.equal(activeButtons[1].classList.active,true,'Categories highlighted for weekly');
assert.equal(activeButtons[0].classList.active,false,'Home not highlighted for weekly');
setHeaderActive('home');
assert.equal(activeButtons[0].classList.active,true,'Home highlighting still works');

const handlers=app.match(/\$\$\('\[data-category-dest\]'\)\.forEach\(b=>b\.onclick=e=>\{[^\n]+\}\);/)?.[0];
assert.ok(handlers,'dropdown action wiring exists');
const menuEntries=['genres','top_series','weekly'].map(categoryDest=>({dataset:{categoryDest}}));
const calls=[];
vm.runInNewContext(handlers,{
  $$:()=>menuEntries,
  route:view=>calls.push(['route',view]),
  showGenres:()=>calls.push(['genres']),
  showCollections:()=>calls.push(['collections']),
  showBrowseSection:(a,s,p)=>calls.push(['browse',a,s,p])
});
const evt={stopPropagation(){}};
menuEntries[2].onclick(evt);
assert.deepEqual(calls.pop(),['route','weekly'],'weekly dropdown opens weekly page');
menuEntries[0].onclick(evt);
assert.deepEqual(calls.pop(),['genres'],'previous Genres dropdown still works');
menuEntries[1].onclick(evt);
assert.deepEqual(calls.pop(),['browse',1,'top_series',1],'previous IMDb categories still work');
console.log('PASS weekly navigation in dropdown and Categories page; original header and homepage unaffected');
