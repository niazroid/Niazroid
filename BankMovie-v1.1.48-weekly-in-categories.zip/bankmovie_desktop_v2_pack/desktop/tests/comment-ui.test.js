'use strict';
const fs=require('node:fs');const vm=require('node:vm');const path=require('node:path');const assert=require('node:assert/strict');
const root=path.join(__dirname,'..');
const P=require('../src/desktop-policy');
const source=fs.readFileSync(path.join(root,'src/desktop-policy-ui.js'),'utf8');
const fake=()=>null;
const context={
  window:{BMDesktopPolicy:P,addEventListener:()=>{}},document:{querySelectorAll:()=>[],getElementById:()=>null},setInterval:()=>0,
  state:{user:{username:'admin'},config:{desktop:{enabled:true,features:{comments_enabled:true,comment_spoiler_enabled:true},sections:{comments:true}}},language:'fa'},
  watchKey:d=>String(d.id),toast:fake,esc:s=>String(s),bm192AvatarUrl:fake,bm110SelectedPreview:()=>'',
  bm110MainMedia:null,bm192CommentRating:0,bm192CommentSpoiler:false,bm191Language:'fa',
  renderDetail:fake,switchDetailTab:fake,bm1124ApplySectionControls:fake,renderTopCategories:fake,applyRemoteNotice:fake,
  renderCommentsBox:fake,bm192ComposerHtml:fake,commentAction:fake,bm192ReplyComposer:fake,
  showNotifications:fake,showWatchlist:fake,showDownloads:fake,showCategories:fake,showCollections:fake,
  showBoxOffice:fake,showParty:fake,showVipPlansModal:fake,showSettings:fake,showAuthModal:fake,
  homeSectionsFor:()=>['top_movies'],route:fake,bindGlobalUI:fake,bm1124SectionEnabled:()=>true,
  feature:()=>true,bridge:{refreshConfig:fake},bm1124ApplySectionControls:fake,bm1124SectionEnabled:()=>true,
  $$:()=>[], $:fake
};
vm.createContext(context);vm.runInContext(source,context,{filename:'desktop-policy-ui.js',timeout:3000});
const html=context.bm192ComposerHtml({id:1});
for(const id of ['commentText','sendComment','commentSpoiler'])assert.match(html,new RegExp('id="'+id+'"'),id);
assert.match(html,/bm147-textarea/);assert.match(html,/bm147-send/);assert.doesNotMatch(html,/bm1135-send-button/);
context.state.config.desktop.features.comment_spoiler_enabled=false;
assert.doesNotMatch(context.bm192ComposerHtml({id:1}),/id="commentSpoiler"/);
context.state.config.desktop.features.comments_enabled=false;
assert.equal(context.feature('comments_enabled'),false);
assert.equal(context.bm1124SectionEnabled('comments'),false);
console.log('PASS comment HTML and feature switch integration');
