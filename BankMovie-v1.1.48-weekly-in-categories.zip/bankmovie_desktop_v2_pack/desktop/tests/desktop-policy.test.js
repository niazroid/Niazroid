'use strict';
const assert=require('node:assert/strict');
const P=require('../src/desktop-policy');
const allTrue={desktop:{enabled:true,features:{comments_enabled:true,comment_replies_enabled:true,comment_votes_enabled:true,comment_reports_enabled:true},sections:{comments:true}}};
const tests=[
  ['default preserves previous enabled behavior',()=>assert.equal(P.action({},'comment_add'),true)],
  ['desktop comment toggle disables list and submit',()=>{const cfg={desktop:{features:{comments_enabled:false}}};for(const action of ['comments_list','comment_add','comment_edit','comment_delete','comment_reply','comment_vote','comment_pin'])assert.equal(P.action(cfg,action),false,action)}],
  ['turning comments section off disables interaction',()=>assert.equal(P.action({desktop:{sections:{comments:false}}},'comment_add'),false)],
  ['reply vote and report work independently',()=>{const cfg={desktop:{features:{...allTrue.desktop.features,comment_replies_enabled:false}}};assert.equal(P.action(cfg,'comment_add'),true);assert.equal(P.action(cfg,'comment_reply'),false);assert.equal(P.action(cfg,'comment_vote'),true)}],
  ['notifications disabled for all actions',()=>{const cfg={desktop:{features:{notification_center_enabled:false}}};for(const name of ['notifications_list','notifications_read_all','notifications_read'])assert.equal(P.action(cfg,name),false)}],
  ['watch party and list are disabled independently',()=>{const cfg={desktop:{features:{watch_party_enabled:false,watchlist_enabled:false}}};assert.equal(P.action(cfg,'watch_party_message'),false);assert.equal(P.action(cfg,'watchlist_add'),false)}],
  ['legacy root flags work when desktop flags missing',()=>assert.equal(P.action({features:{login_enabled:false}},'login'),false)],
  ['signed desktop flags override generic site flags',()=>assert.equal(P.action({features:{comments_enabled:true},desktop:{features:{comments_enabled:false}}},'comment_add'),false)],
  ['all sections honor independent switches',()=>assert.equal(P.section({desktop:{sections:{sources:false}}},'sources'),false)],
  ['archive individual home rail switches work',()=>assert.equal(P.contentSection({desktop:{home_sections:{archive1:{top_movies:false}}}},1,'top_movies'),false)],
  ['master desktop disable blocks actions',()=>assert.equal(P.action({desktop:{enabled:false}},'comment_add'),false)],
  ['unrelated actions remain usable if comments are off',()=>assert.equal(P.action({desktop:{features:{comments_enabled:false}}},'me'),true)]
];
for(const [name,run] of tests){run();console.log('PASS',name)}
console.log(tests.length+' tests passed');
