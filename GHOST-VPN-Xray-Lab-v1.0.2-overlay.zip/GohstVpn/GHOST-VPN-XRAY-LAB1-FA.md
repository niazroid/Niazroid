# GHOST VPN — Xray Lab 1 / 1.0.2+11

## هدف

یکپارچه‌سازی اولیه موتور واقعی Xray-core 26.3.27 با اپ فعلی، با همان ظاهر، برند، آیکن، صفحه‌های فارسی، صفحه سرورها و سابسکریپشن.

## انجام‌شده در کد

- پیوند واقعی Go Xray-core 26.3.27 با APIهای StartJSON / Stop / ValidateJSON / Version / IsRunning.
- Android gomobile AAR برای ARM64 در GitHub Actions ساخته می‌شود (مرحله تست CI هنوز اجرا نشده).
- Flutter MethodChannel مستقل برای ارتباط با کتابخانه؛ عمداً هنوز از دکمه ON/OFF فراخوانی نمی‌شود.
- محافظت از سوکت‌های خروجی Xray با Android VpnService.protect؛ اگر سرویس VPN حاضر نباشد، ارتباط بسته می‌شود تا loop رخ ندهد.
- تست‌های Go برای اعتبارسنجی نسخه و JSON.
- بدون هیچ تغییر در صفحه‌های UI یا لوگو یا متن‌های فارسی.

## وضعیت مهم

**این فایل هنوز جایگزینی کامل موتور VPN نیست.** پل Xray وارد سورس شده ولی مسیر داده TUN/DNS، وضعیت اتصال، ساب و پینگ به Xray منتقل نشده‌اند. خروجی این مرحله صرفاً آزمایشی است؛ انتشار نسخه نهایی با عنوان «Xray Edition» صحیح نیست.

## چطور تست شود؟

1. فایل GHOST-VPN-Xray-Lab-v1.0.2-overlay.zip را کنار GHOST-VPN-FlClash-v1.0.0-full-source.zip و GHOST-VPN-v1.0.1-import-fix.zip در ریشه مخزن GitHub آپلود کنید.
2. Workflow مجزای `GHOST-VPN-Xray-Lab1-github-actions.yml` را زیر `.github/workflows/ghost-xray-lab1.yml` قرار دهید؛ Workflow نسخه پایدار را تغییر ندهید.
3. GitHub Actions → GHOST VPN XRAY LAB 1 → Run workflow را اجرا کنید.
4. اولین شرط موفقیت: `go test ./ghostmobile` و ساخته‌شدن `ghostxray.aar` از سورس Xray و بعد ساخت APK آزمایشی. این آزمون معادل اتصال موفق VPN نیست.

## قبل از نسخه واقعی Xray چه باقی‌مانده؟

1. انتقال VPN TUN از Mihomo به تونل Xray (مانند hev-socks5-tunnel) یا مسیردهی کنترل‌شده؛ لازم است از loop و DNS leak جلوگیری شود.
2. تبدیل خروجی کامل پروفایل به Xray JSON برای VMess/VLESS/REALITY/XHTTP و ...، بدون افت تنظیمات.
3. هماهنگی شروع/توقف/تغییر سرور، DNS، وضعیت اتصال، تست تأخیر و سرعت واقعی با API جدید.
4. تست روی یک گوشی واقعی با چند سرور یکسان در V2Box و GHOST، و تأیید خروج واقعی اینترنت.
5. بررسی امنیت و تداخل هم‌زمان دو runtime زبان Go در برنامه، یا ایزوله‌کردن Xray در process جداگانه در نسخه production.

هیچ کد اختصاصی/کتابخانه کامپایل‌شده V2Box از APK کپی نشده است. ساخت موتور از سورس عمومی و ارسالی کاربر انجام می‌شود.
