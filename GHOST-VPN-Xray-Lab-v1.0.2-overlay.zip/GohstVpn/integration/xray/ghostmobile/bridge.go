// Package ghostmobile exposes the user-provided Xray core to Android via
// gomobile. No VPN is established here: that is a separate Android step.
package ghostmobile

import (
	"errors"
	"fmt"
	"strings"
	"sync"
	"syscall"

	"github.com/xtls/xray-core/core"
	"github.com/xtls/xray-core/infra/conf/serial"
	_ "github.com/xtls/xray-core/main/distro/all"
	"github.com/xtls/xray-core/transport/internet"
)

// Protector is implemented by the Android host and must call
// android.net.VpnService.protect(fd) when a VPN tunnel is active.
// Never dial the proxy server back into the app's own VPN tunnel.
type Protector interface {
	Protect(fd int32) bool
}

var mu sync.Mutex
var protectorMu sync.RWMutex
var active *core.Instance
var socketProtector Protector
var installed bool

func Version() string { return core.Version() }

func IsRunning() bool {
	mu.Lock()
	defer mu.Unlock()
	return active != nil
}

func SetProtector(p Protector) error {
	mu.Lock()
	defer mu.Unlock()
	if active != nil {
		return errors.New("cannot change protector while core is running")
	}
	if p == nil {
		return errors.New("socket protector is required")
	}
	protectorMu.Lock()
	socketProtector = p
	protectorMu.Unlock()
	if installed {
		return nil
	}
	err := internet.RegisterDialerController(func(network, address string, conn syscall.RawConn) error {
		// This function is invoked before connecting the underlying
		// sockets. No destination, credential or subscription is logged.
		var denied bool
		e := conn.Control(func(fd uintptr) {
			protectorMu.RLock()
			protect := socketProtector
			protectorMu.RUnlock()
			if protect == nil || !protect.Protect(int32(fd)) {
				denied = true
			}
		})
		if e != nil {
			return e
		}
		if denied {
			return fmt.Errorf("failed to protect Xray socket from VPN loop")
		}
		return nil
	})
	if err == nil {
		installed = true
	}
	return err
}

// ValidateJSON parses an Xray JSON config without starting a tunnel.
// Caller must not log raw configs: they can contain proxy credentials.
func ValidateJSON(jsonText string) error {
	if strings.TrimSpace(jsonText) == "" {
		return errors.New("empty Xray config")
	}
	_, err := serial.LoadJSONConfig(strings.NewReader(jsonText))
	return err
}

// StartJSON starts the actual Xray engine with explicit JSON config.
// It is intentionally NOT called from GHOST VPN's existing ON/OFF flow
// until its TUN adapter and lifecycle have been migrated and tested.
func StartJSON(jsonText string) error {
	mu.Lock()
	defer mu.Unlock()
	if active != nil {
		return errors.New("Xray already running")
	}
	protectorMu.RLock()
	registered := socketProtector != nil
	protectorMu.RUnlock()
	if !registered {
		return errors.New("Android socket protector not registered")
	}
	cfg, err := serial.LoadJSONConfig(strings.NewReader(jsonText))
	if err != nil {
		return fmt.Errorf("invalid Xray config: %w", err)
	}
	instance, err := core.New(cfg)
	if err != nil {
		return fmt.Errorf("failed to create Xray instance: %w", err)
	}
	if err = instance.Start(); err != nil {
		_ = instance.Close()
		return fmt.Errorf("failed to start Xray: %w", err)
	}
	active = instance
	return nil
}

func Stop() error {
	mu.Lock()
	defer mu.Unlock()
	if active == nil {
		return nil
	}
	instance := active
	active = nil
	return instance.Close()
}
