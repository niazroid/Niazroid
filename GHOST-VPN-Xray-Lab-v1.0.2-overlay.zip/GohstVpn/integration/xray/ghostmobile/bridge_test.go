package ghostmobile

import "testing"

func TestVersion(t *testing.T) {
	if Version() != "26.3.27" {
		t.Fatalf("unexpected engine version: %s", Version())
	}
}

func TestRejectEmptyConfig(t *testing.T) {
	if err := ValidateJSON(""); err == nil {
		t.Fatal("empty Xray config must be rejected")
	}
}

func TestRejectInvalidJSON(t *testing.T) {
	if err := ValidateJSON(`{"inbounds":[`); err == nil {
		t.Fatal("invalid Xray config must be rejected")
	}
}

func TestValidateBasicConfig(t *testing.T) {
	sample := `{"log":{"loglevel":"warning"},"inbounds":[],"outbounds":[{"protocol":"freedom","settings":{}}]}`
	if err := ValidateJSON(sample); err != nil {
		t.Fatalf("valid baseline Xray JSON rejected: %s", err)
	}
}
