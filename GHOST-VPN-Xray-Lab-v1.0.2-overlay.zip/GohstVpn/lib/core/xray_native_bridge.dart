import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Experimental Android-native Xray interface. It does NOT replace the
/// existing Mihomo VPN service automatically: the VPN/TUN bridge is pending.
class XrayNativeBridge {
  static const MethodChannel _channel =
      MethodChannel('com.follow.clash/ghost_xray');

  static Future<String> version() async =>
      await _channel.invokeMethod<String>('version') ?? 'unknown';

  static Future<void> validateJson(String json) =>
      _channel.invokeMethod<void>('validate', {'config': json});

  static Future<bool> isRunning() async =>
      await _channel.invokeMethod<bool>('isRunning') ?? false;

  static Future<void> startJson(String json) =>
      _channel.invokeMethod<void>('start', {'config': json});

  static Future<void> stop() => _channel.invokeMethod<void>('stop');

  static bool get supported => defaultTargetPlatform == TargetPlatform.android;
}
