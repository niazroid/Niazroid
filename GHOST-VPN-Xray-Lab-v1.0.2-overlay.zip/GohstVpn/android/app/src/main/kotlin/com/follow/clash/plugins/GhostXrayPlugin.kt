package com.follow.clash.plugins

import android.os.Handler
import android.os.Looper
import com.follow.clash.common.GhostXraySocketRegistry
import ghostmobile.Ghostmobile
import ghostmobile.Protector
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.util.concurrent.Executors

/**
 * Experimental Flutter bridge to Xray 26.3.27. Does not change GHOST VPN's
 * existing ON/OFF behavior or start any VPN itself.
 */
class GhostXrayPlugin : FlutterPlugin, MethodChannel.MethodCallHandler {
    private lateinit var channel: MethodChannel
    private val mainHandler = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel = MethodChannel(binding.binaryMessenger, "com.follow.clash/ghost_xray")
        channel.setMethodCallHandler(this)
        // Native bridge is lazy. Do not crash Flutter home on load errors.
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
        // A detached UI must not terminate a running native engine.
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "version", "isRunning", "validate", "start", "stop" -> worker.execute {
                try {
                    val value: Any? = when (call.method) {
                        "version" -> Ghostmobile.version()
                        "isRunning" -> Ghostmobile.isRunning()
                        "validate" -> {
                            Ghostmobile.validateJSON(
                                requireNotNull(call.argument<String>("config"))
                            )
                            null
                        }
                        "start" -> {
                            // Xray sockets must be excluded from the Android VPN;
                            // fail closed if Android VPN service is not ready.
                            Ghostmobile.setProtector(object : Protector {
                                override fun protect(fd: Int): Boolean =
                                    GhostXraySocketRegistry.protect(fd)
                            })
                            Ghostmobile.startJSON(
                                requireNotNull(call.argument<String>("config"))
                            )
                            null
                        }
                        "stop" -> {
                            Ghostmobile.stop()
                            null
                        }
                        else -> null
                    }
                    mainHandler.post { result.success(value) }
                } catch (failure: Throwable) {
                    // Never log config JSON; it contains subscriptions and keys.
                    mainHandler.post {
                        result.error("XRAY_BRIDGE_ERROR", "Xray operation failed", null)
                    }
                }
            }
            else -> result.notImplemented()
        }
    }
}
