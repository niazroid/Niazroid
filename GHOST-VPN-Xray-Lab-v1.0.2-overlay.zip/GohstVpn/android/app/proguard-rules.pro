
-keep class com.follow.clash.models.** { *; }

-keep class com.follow.clash.service.models.** { *; }

# gomobile-generated Java + Go bridge. Required by GhostXrayPlugin.
-keep class ghostmobile.** { *; }
-keep class go.** { *; }
