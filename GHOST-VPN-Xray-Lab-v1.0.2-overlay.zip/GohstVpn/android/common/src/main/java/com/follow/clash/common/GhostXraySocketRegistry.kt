package com.follow.clash.common

import android.net.VpnService

/** Shared by the Flutter Xray bridge and the existing Android VPN host. */
object GhostXraySocketRegistry {
    @Volatile
    private var owner: VpnService? = null

    fun attach(service: VpnService) { owner = service }
    fun detach(service: VpnService) { if (owner === service) owner = null }

    /** Fail closed: never let Xray dial recursively through its own VPN. */
    fun protect(fd: Int): Boolean = owner?.protect(fd) ?: false
}
