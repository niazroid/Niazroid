<?php
/**
 * BankMovie application-only push notification storage.
 *
 * Important: this table is intentionally separate from the legacy `notifications`
 * table used by the website. Pushes created in BM Admin must never appear on the
 * public website.
 */

if (!function_exists('bm_push_table_exists')) {
    function bm_push_table_exists(PDO $pdo, string $table): bool {
        $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($safe === '') return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
            $stmt->execute([$safe]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_push_ensure_schema')) {
    function bm_push_ensure_schema(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_notifications (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(220) NOT NULL,
            message TEXT NOT NULL,
            link VARCHAR(700) NULL,
            status VARCHAR(24) NOT NULL DEFAULT 'stored',
            fcm_message_name VARCHAR(700) NULL,
            fcm_error TEXT NULL,
            expires_at DATETIME NULL,
            sent_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_app_push_created (created_at),
            INDEX idx_app_push_active (expires_at, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_revocations (
            notification_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
            revoked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_app_push_revoked_at (revoked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}

if (!function_exists('bm_push_revoke')) {
    function bm_push_revoke(PDO $pdo, int $id): void {
        if ($id <= 0) return;
        bm_push_ensure_schema($pdo);
        try {
            $stmt = $pdo->prepare("INSERT INTO app_push_revocations(notification_id,revoked_at) VALUES(?,NOW()) ON DUPLICATE KEY UPDATE revoked_at=VALUES(revoked_at)");
            $stmt->execute([$id]);
        } catch (Throwable $e) { error_log('app push revoke: ' . $e->getMessage()); }
    }
}

if (!function_exists('bm_push_revoked_ids')) {
    function bm_push_revoked_ids(PDO $pdo, int $limit = 200): array {
        bm_push_ensure_schema($pdo);
        $limit = max(1, min(500, $limit));
        try { $pdo->exec("DELETE FROM app_push_revocations WHERE revoked_at < (NOW() - INTERVAL 7 DAY)"); } catch (Throwable $e) {}
        try {
            $stmt = $pdo->query("SELECT notification_id FROM app_push_revocations ORDER BY revoked_at DESC LIMIT {$limit}");
            return array_values(array_map('intval', $stmt ? ($stmt->fetchAll(PDO::FETCH_COLUMN) ?: []) : []));
        } catch (Throwable $e) { return []; }
    }
}

if (!function_exists('bm_push_cleanup_expired')) {
    function bm_push_cleanup_expired(PDO $pdo): int {
        bm_push_ensure_schema($pdo);
        try {
            $ids = $pdo->query("SELECT id FROM app_push_notifications
                WHERE (expires_at IS NOT NULL AND expires_at < NOW())
                   OR created_at < (NOW() - INTERVAL 7 DAY)")->fetchAll(PDO::FETCH_COLUMN) ?: [];
            foreach ($ids as $id) bm_push_revoke($pdo, (int)$id);
            return (int)$pdo->exec("DELETE FROM app_push_notifications
                WHERE (expires_at IS NOT NULL AND expires_at < NOW())
                   OR created_at < (NOW() - INTERVAL 7 DAY)");
        } catch (Throwable $e) {
            error_log('app push cleanup: ' . $e->getMessage());
            return 0;
        }
    }
}

if (!function_exists('bm_push_insert')) {
    function bm_push_insert(PDO $pdo, string $title, string $message, string $link, ?string $expiresAt): int {
        bm_push_ensure_schema($pdo);
        $stmt = $pdo->prepare("INSERT INTO app_push_notifications
            (title,message,link,status,expires_at,created_at)
            VALUES (?,?,?,'stored',?,NOW())");
        $stmt->execute([
            mb_substr(trim($title) !== '' ? trim($title) : 'پیام مدیریت بانک مووی', 0, 220, 'UTF-8'),
            trim($message),
            trim($link) !== '' ? trim($link) : null,
            $expiresAt,
        ]);
        return (int)$pdo->lastInsertId();
    }
}

if (!function_exists('bm_push_mark_delivery')) {
    function bm_push_mark_delivery(PDO $pdo, int $id, array $result): void {
        if ($id <= 0) return;
        $ok = !empty($result['ok']);
        $configured = !empty($result['configured']);
        $status = $ok ? 'sent' : ($configured ? 'fcm_failed' : 'fallback');
        $name = trim((string)($result['name'] ?? ''));
        $error = $ok ? '' : trim((string)($result['debug'] ?? ($result['message'] ?? '')));
        try {
            $stmt = $pdo->prepare("UPDATE app_push_notifications
                SET status=?, fcm_message_name=?, fcm_error=?, sent_at=NOW()
                WHERE id=?");
            $stmt->execute([$status, $name !== '' ? $name : null, $error !== '' ? mb_substr($error, 0, 6000, 'UTF-8') : null, $id]);
        } catch (Throwable $e) {
            error_log('app push delivery update: ' . $e->getMessage());
        }
    }
}

if (!function_exists('bm_push_get')) {
    function bm_push_get(PDO $pdo, int $id): ?array {
        bm_push_ensure_schema($pdo);
        if ($id <= 0) return null;
        $stmt = $pdo->prepare('SELECT * FROM app_push_notifications WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }
}

if (!function_exists('bm_push_list')) {
    function bm_push_list(PDO $pdo, int $limit = 30): array {
        bm_push_ensure_schema($pdo);
        bm_push_cleanup_expired($pdo);
        $limit = max(1, min(100, $limit));
        $stmt = $pdo->query("SELECT id,title,message,COALESCE(link,'') AS link,status,
            COALESCE(fcm_message_name,'') AS fcm_message_name,
            COALESCE(fcm_error,'') AS fcm_error,expires_at,sent_at,created_at
            FROM app_push_notifications
            ORDER BY id DESC LIMIT {$limit}");
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
        return is_array($rows) ? $rows : [];
    }
}

if (!function_exists('bm_push_poll_items')) {
    function bm_push_poll_items(PDO $pdo, int $limit = 30): array {
        bm_push_ensure_schema($pdo);
        bm_push_cleanup_expired($pdo);
        $limit = max(1, min(50, $limit));
        $stmt = $pdo->query("SELECT id,
            COALESCE(NULLIF(title,''),'پیام مدیریت بانک مووی') AS title,
            message,COALESCE(link,'') AS link,'' AS image,created_at,expires_at
            FROM app_push_notifications
            WHERE (expires_at IS NULL OR expires_at > NOW())
              AND created_at >= (NOW() - INTERVAL 7 DAY)
            ORDER BY id DESC LIMIT {$limit}");
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
        return is_array($rows) ? $rows : [];
    }
}

if (!function_exists('bm_push_delete')) {
    function bm_push_delete(PDO $pdo, int $id): int {
        bm_push_ensure_schema($pdo);
        if ($id <= 0) return 0;
        bm_push_revoke($pdo, $id);
        $stmt = $pdo->prepare('DELETE FROM app_push_notifications WHERE id=?');
        $stmt->execute([$id]);
        return (int)$stmt->rowCount();
    }
}

if (!function_exists('bm_push_clear_all')) {
    function bm_push_clear_all(PDO $pdo, bool $optimize = true): int {
        bm_push_ensure_schema($pdo);
        $count = 0;
        try {
            $ids = $pdo->query('SELECT id FROM app_push_notifications')->fetchAll(PDO::FETCH_COLUMN) ?: [];
            foreach ($ids as $id) bm_push_revoke($pdo, (int)$id);
            $count = (int)$pdo->exec('DELETE FROM app_push_notifications');
        } catch (Throwable $e) {}
        if ($optimize) {
            try { $pdo->exec('OPTIMIZE TABLE app_push_notifications'); } catch (Throwable $e) {}
        }
        return $count;
    }
}

if (!function_exists('bm_push_legacy_cleanup')) {
    /**
     * Purge legacy APP notification history/read/dismiss state only.
     * Website notifications and notification_views are intentionally untouched.
     * Table structures stay in place for legacy app compatibility.
     */
    function bm_push_legacy_cleanup(PDO $pdo, bool $force = false, bool $optimize = true): array {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_migrations (
            migration_key VARCHAR(120) NOT NULL PRIMARY KEY,
            completed_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $key = 'legacy_app_notification_history_purge_v2';
        if (!$force) {
            try {
                $check = $pdo->prepare('SELECT completed_at FROM app_push_migrations WHERE migration_key=? LIMIT 1');
                $check->execute([$key]);
                if ($check->fetchColumn()) return ['ran'=>false,'already_done'=>true,'deleted'=>[]];
            } catch (Throwable $e) {}
        }

        $targets = [
            'app_notification_global_state',
            'app_notification_dismissals',
            'app_notifications',
        ];
        $deleted = [];
        foreach ($targets as $table) {
            if (!bm_push_table_exists($pdo, $table)) {
                $deleted[$table] = 0;
                continue;
            }
            try {
                $deleted[$table] = (int)$pdo->exec("DELETE FROM `{$table}`");
            } catch (Throwable $e) {
                $deleted[$table] = -1;
                error_log('legacy notification purge ' . $table . ': ' . $e->getMessage());
            }
        }

        try {
            $mark = $pdo->prepare("INSERT INTO app_push_migrations(migration_key,completed_at) VALUES(?,NOW())
                ON DUPLICATE KEY UPDATE completed_at=VALUES(completed_at)");
            $mark->execute([$key]);
        } catch (Throwable $e) {}

        if ($optimize) {
            foreach ($targets as $table) {
                if (!bm_push_table_exists($pdo, $table)) continue;
                try { $pdo->exec("OPTIMIZE TABLE `{$table}`"); } catch (Throwable $e) {}
            }
        }
        return ['ran'=>true,'already_done'=>false,'deleted'=>$deleted];
    }
}
