<?php
/** BankMovie FCM HTTP v1 sender (topic broadcast), no Composer dependency. */

if (!function_exists('bm_fcm_service_account_path')) {
    function bm_fcm_service_account_path(): string {
        $explicit = trim((string)(getenv('BANKMOVIE_FIREBASE_SERVICE_ACCOUNT_FILE') ?: ''));
        $candidates = [];
        if ($explicit !== '') $candidates[] = $explicit;
        $docRoot = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
        if ($docRoot !== '') {
            $parent = dirname($docRoot);
            $candidates[] = $parent . '/bankmovie_private/firebase-service-account.json';
        }
        // Last-resort protected location for hosts where moving above public_html
        // is impossible. The release ships a deny-all .htaccess for this folder.
        $candidates[] = dirname(__DIR__) . '/_bankmovie_private/firebase-service-account.json';
        foreach ($candidates as $path) if ($path !== '' && is_file($path) && is_readable($path)) return $path;
        return '';
    }
}

if (!function_exists('bm_fcm_config_status')) {
    function bm_fcm_config_status(): array {
        $path = bm_fcm_service_account_path();
        if ($path === '') return ['ready'=>false,'message'=>'Firebase service account پیدا نشد'];
        $raw = @file_get_contents($path);
        $json = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($json)) return ['ready'=>false,'message'=>'Firebase service account JSON نامعتبر است'];
        foreach (['project_id','client_email','private_key'] as $key) {
            if (trim((string)($json[$key] ?? '')) === '') return ['ready'=>false,'message'=>'Firebase service account ناقص است: '.$key];
        }
        return ['ready'=>true,'message'=>'FCM آماده است','project_id'=>(string)$json['project_id'],'path'=>$path];
    }
}

if (!function_exists('bm_fcm_b64url')) {
    function bm_fcm_b64url(string $value): string {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }
}

if (!function_exists('bm_fcm_http_post')) {
    function bm_fcm_http_post(string $url, string $body, array $headers): array {
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => 20,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_POSTFIELDS => $body,
            ]);
            $response = curl_exec($ch);
            $error = curl_error($ch);
            $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return ['code'=>$code,'body'=>is_string($response)?$response:'','error'=>$error];
        }
        $context = stream_context_create(['http'=>[
            'method'=>'POST','timeout'=>20,'ignore_errors'=>true,
            'header'=>implode("\r\n", $headers),'content'=>$body,
        ]]);
        $response = @file_get_contents($url, false, $context);
        $code = 0;
        foreach (($http_response_header ?? []) as $line) if (preg_match('/^HTTP\/\S+\s+(\d+)/', $line, $m)) $code=(int)$m[1];
        return ['code'=>$code,'body'=>is_string($response)?$response:'','error'=>$response===false?'HTTP request failed':''];
    }
}

if (!function_exists('bm_fcm_access_token')) {
    function bm_fcm_access_token(array $service): array {
        $now = time();
        $header = bm_fcm_b64url(json_encode(['alg'=>'RS256','typ'=>'JWT'], JSON_UNESCAPED_SLASHES));
        $claims = bm_fcm_b64url(json_encode([
            'iss'=>(string)$service['client_email'],
            'scope'=>'https://www.googleapis.com/auth/firebase.messaging',
            'aud'=>'https://oauth2.googleapis.com/token',
            'iat'=>$now,
            'exp'=>$now+3500,
        ], JSON_UNESCAPED_SLASHES));
        $unsigned = $header . '.' . $claims;
        $signature = '';
        $ok = openssl_sign($unsigned, $signature, (string)$service['private_key'], OPENSSL_ALGO_SHA256);
        if (!$ok) return ['ok'=>false,'message'=>'امضای JWT فایربیس ناموفق بود'];
        $assertion = $unsigned . '.' . bm_fcm_b64url($signature);
        $form = http_build_query([
            'grant_type'=>'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion'=>$assertion,
        ]);
        $res = bm_fcm_http_post('https://oauth2.googleapis.com/token', $form, [
            'Content-Type: application/x-www-form-urlencoded',
            'Accept: application/json',
        ]);
        $json = json_decode((string)$res['body'], true);
        $token = is_array($json) ? trim((string)($json['access_token'] ?? '')) : '';
        if ($res['code'] < 200 || $res['code'] >= 300 || $token === '') {
            return ['ok'=>false,'message'=>'دریافت OAuth فایربیس ناموفق بود','debug'=>(string)($res['error'] ?: $res['body'])];
        }
        return ['ok'=>true,'token'=>$token];
    }
}

if (!function_exists('bm_fcm_send_topic')) {
    function bm_fcm_send_topic(string $title, string $message, string $link, int $notificationId): array {
        $status = bm_fcm_config_status();
        if (empty($status['ready'])) return ['ok'=>false,'configured'=>false,'message'=>(string)$status['message']];
        $raw = @file_get_contents((string)$status['path']);
        $service = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($service)) return ['ok'=>false,'configured'=>false,'message'=>'Service account خوانده نشد'];
        $token = bm_fcm_access_token($service);
        if (empty($token['ok'])) return $token + ['configured'=>true];

        $data = [
            'bm_type'=>'admin',
            'notification_id'=>(string)$notificationId,
            'title'=>$title,
            'message'=>$message,
            'link'=>$link,
        ];
        $payload = json_encode([
            'message'=>[
                'topic'=>'bankmovie_all',
                'data'=>$data,
                'android'=>[
                    'priority'=>'HIGH',
                    'ttl'=>'604800s',
                ],
            ],
        ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $projectId = rawurlencode((string)$service['project_id']);
        $res = bm_fcm_http_post("https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send", (string)$payload, [
            'Authorization: Bearer ' . (string)$token['token'],
            'Content-Type: application/json; charset=UTF-8',
            'Accept: application/json',
        ]);
        $json = json_decode((string)$res['body'], true);
        if ($res['code'] >= 200 && $res['code'] < 300 && is_array($json) && !empty($json['name'])) {
            return ['ok'=>true,'configured'=>true,'message'=>'Push فوری FCM ارسال شد','name'=>(string)$json['name']];
        }
        return ['ok'=>false,'configured'=>true,'message'=>'FCM ارسال نشد؛ fallback سرور فعال است','debug'=>(string)($res['error'] ?: $res['body'])];
    }
}

if (!function_exists('bm_fcm_send_data_topic')) {
    function bm_fcm_send_data_topic(array $data, string $ttl = '86400s'): array {
        $status = bm_fcm_config_status();
        if (empty($status['ready'])) return ['ok'=>false,'configured'=>false,'message'=>(string)$status['message']];
        $raw = @file_get_contents((string)$status['path']);
        $service = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($service)) return ['ok'=>false,'configured'=>false,'message'=>'Service account خوانده نشد'];
        $token = bm_fcm_access_token($service);
        if (empty($token['ok'])) return $token + ['configured'=>true];
        $safeData = [];
        foreach ($data as $key => $value) $safeData[(string)$key] = (string)$value;
        $payload = json_encode([
            'message'=>[
                'topic'=>'bankmovie_all',
                'data'=>$safeData,
                'android'=>['priority'=>'HIGH','ttl'=>$ttl],
            ],
        ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $projectId = rawurlencode((string)$service['project_id']);
        $res = bm_fcm_http_post("https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send", (string)$payload, [
            'Authorization: Bearer ' . (string)$token['token'],
            'Content-Type: application/json; charset=UTF-8',
            'Accept: application/json',
        ]);
        $json = json_decode((string)$res['body'], true);
        if ($res['code'] >= 200 && $res['code'] < 300 && is_array($json) && !empty($json['name'])) {
            return ['ok'=>true,'configured'=>true,'name'=>(string)$json['name']];
        }
        return ['ok'=>false,'configured'=>true,'message'=>'FCM data message ارسال نشد','debug'=>(string)($res['error'] ?: $res['body'])];
    }
}

if (!function_exists('bm_fcm_send_revoke')) {
    function bm_fcm_send_revoke(int $notificationId): array {
        if ($notificationId <= 0) return ['ok'=>false,'configured'=>true,'message'=>'شناسه اعلان نامعتبر است'];
        return bm_fcm_send_data_topic([
            'bm_type'=>'admin_revoke',
            'notification_id'=>(string)$notificationId,
        ]);
    }
}

if (!function_exists('bm_fcm_send_revoke_all')) {
    function bm_fcm_send_revoke_all(): array {
        return bm_fcm_send_data_topic([
            'bm_type'=>'admin_revoke_all',
            'notification_id'=>'1',
        ]);
    }
}
