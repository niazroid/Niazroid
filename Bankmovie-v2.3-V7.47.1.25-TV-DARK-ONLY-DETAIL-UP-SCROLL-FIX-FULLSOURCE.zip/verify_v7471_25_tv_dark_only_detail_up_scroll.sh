#!/usr/bin/env bash
set -euo pipefail

root="$(cd "$(dirname "$0")" && pwd)"
ui="$root/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
main="$root/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
onboarding="$root/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"

for f in "$ui" "$main" "$onboarding"; do
  [[ -s "$f" ]] || { echo "missing: $f" >&2; exit 1; }
done

grep -Fq 'if (DeviceProfile.isTv(context)) return "black"' "$ui"
grep -Fq 'val normalized = if (DeviceProfile.isTv(context)) "black" else normalizeThemeMode(mode)' "$ui"
grep -Fq 'if (DeviceProfile.isTv(this)) {' "$main"
grep -Fq 'text = t("مشکی سینمایی", "Cinematic black")' "$main"
grep -Fq 'if (DeviceProfile.isTv(this)) {' "$onboarding"
grep -Fq 'tr("مشکی سینمایی", "Cinematic black")' "$onboarding"

grep -Fq 'private fun handleV747125DetailVerticalFocus' "$main"
grep -Fq 'private fun wireV747125DetailVerticalGraph' "$main"
grep -Fq 'handleV747125DetailVerticalFocus(focused, keyCode)?.let { return it }' "$main"
grep -Fq 'wireV747125DetailVerticalGraph(page)' "$main"
grep -Fq 'scroll.scrollTo(0, 0)' "$main"
grep -Fq 'v.tag != "bm_tv_detail_primary"' "$main"
grep -Fq 'v.tag != "bm_tv_detail_trailer"' "$main"
grep -Fq 'v.tag != "bm_tv_detail_favorite"' "$main"

echo BANKMOVIE_V7471_25_TV_DARK_ONLY_DETAIL_UP_SCROLL_OK
