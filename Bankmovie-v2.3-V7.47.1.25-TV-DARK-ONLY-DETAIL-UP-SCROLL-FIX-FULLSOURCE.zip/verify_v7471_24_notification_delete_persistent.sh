#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
META="BANKMOVIE_BUILD_SOURCE_2_3.txt"
MAIN="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
DISMISS="app/src/main/java/ir/bankmoviee/app/NotificationDismissStore.kt"
LOCAL="app/src/main/java/ir/bankmoviee/app/LocalNotificationStore.kt"
FCM="app/src/main/java/ir/bankmoviee/app/BankMovieFirebaseMessagingService.kt"
JOB="app/src/main/java/ir/bankmoviee/app/AdminPushJobService.kt"
MANIFEST="app/src/main/AndroidManifest.xml"

grep -Fq 'mainUpdateV7471_24=V7.47.1.24 PERSISTENT NOTIFICATION DELETE + ADMIN GLOBAL REVOKE + FCM/POLL REVOCATION' "$META"
grep -Fq 'notificationVisibleAccountKeys' "$MAIN"
grep -Fq 'R.drawable.ic_bm_trash' "$MAIN"
grep -Fq 'isAccountDismissed' "$MAIN"
grep -Fq 'dismissAccount(this@MainActivity, id, source)' "$MAIN"
! grep -Fq 'source == "global" || !NotificationDismissStore.isRemoteDismissed' "$MAIN"
grep -Fq 'KEY_ACCOUNT_KEYS' "$DISMISS"
grep -Fq 'cancelAdminPushSystemNotification' "$DISMISS"
grep -Fq 'clearAdminPushes' "$LOCAL"
grep -Fq 'admin_revoke_all' "$FCM"
grep -Fq 'admin_revoke' "$FCM"
grep -Fq '.setDeleteIntent(deletePending)' "$FCM"
grep -Fq 'revoked_ids' "$JOB"
grep -Fq '.setDeleteIntent(deletePending)' "$JOB"
grep -Fq '.NotificationDismissReceiver' "$MANIFEST"

grep -Fq 'app_push_revocations' server-required/includes/app_push_notifications.php
grep -Fq 'bm_push_revoked_ids' server-required/includes/app_push_notifications.php
grep -Fq "'revoked_ids' =>" server-required/app_api.php || grep -Fq "'revoked_ids' =>" server-required/app_api.php
grep -Fq 'bm_fcm_send_revoke' server-required/includes/fcm_push.php
grep -Fq 'delete_site_notification' server-required/admin.php
grep -Fq 'clear_site_notifications' server-required/admin.php

php -l server-required/app_api.php >/dev/null
php -l server-required/bm_admin.php >/dev/null
php -l server-required/admin.php >/dev/null
php -l server-required/includes/fcm_push.php >/dev/null
php -l server-required/includes/app_push_notifications.php >/dev/null

echo BANKMOVIE_V7471_24_NOTIFICATION_DELETE_PERSISTENT_OK
