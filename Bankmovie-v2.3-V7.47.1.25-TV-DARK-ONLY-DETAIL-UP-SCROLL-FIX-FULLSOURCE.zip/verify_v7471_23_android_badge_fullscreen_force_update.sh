#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_23_ANDROID_BADGE_FULLSCREEN_FORCE_UPDATE_FA.md"
ANDROID_ICON="$ROOT/app/src/main/res/drawable/ic_android_color.xml"
for f in "$MAIN" "$META" "$NOTE" "$ANDROID_ICON"; do test -s "$f"; done

grep -Fq 'mainUpdateV7471_23=V7.47.1.23 ANDROID DEVICE BADGE + FULLSCREEN MANDATORY UPDATE REDESIGN' "$META"

grep -Fq 'setImageResource(R.drawable.ic_android_color)' "$MAIN"
grep -Fq 'text = aboutDeviceLabel()' "$MAIN"
grep -Fq 'Build.VERSION.RELEASE' "$MAIN"
grep -Fq 'Build.MANUFACTURER' "$MAIN"
grep -Fq 'Build.MODEL' "$MAIN"
grep -Fq 'android:fillColor="#95CF00"' "$ANDROID_ICON"
grep -Fq 'android:translateX="-301"' "$ANDROID_ICON"
grep -Fq 'android:translateY="-560"' "$ANDROID_ICON"

grep -Fq 'android.R.style.Theme_DeviceDefault_NoActionBar_Fullscreen' "$MAIN"
grep -Fq 'setCancelable(false)' "$MAIN"
grep -Fq 'setCanceledOnTouchOutside(false)' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_BACK' "$MAIN"
grep -Fq 't("لیست تغییرات", "What'"'"'s new")' "$MAIN"
# V23.2 replaced the textual update glyph and legacy self-check with a native
# download icon and a single real update action. Accept both historical and current forms.
if ! grep -Fq 'text = t("⇩  آپدیت الان", "⇩  Update now")' "$MAIN"; then
  grep -Fq 'setImageResource(R.drawable.ic_bm_download)' "$MAIN"
  grep -Fq 'text = t("آپدیت الان", "Update now")' "$MAIN"
fi

python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
a=s.index('    private fun showUpdateDialog(')
b=s.index('\n    private fun telegramProCard()', a)
block=s[a:b]
assert 'setCancelable(false)' in block
assert 'setCanceledOnTouchOutside(false)' in block
assert 'KEYCODE_BACK' in block
assert 'text = "×"' not in block
assert 't("بعداً", "Later")' not in block
assert 'Theme_DeviceDefault_NoActionBar_Fullscreen' in block
# Historical V23 had a runtime self-check; V23.2 intentionally removed it because
# the old running package cannot prove a replacement install. Both remain mandatory.
if 'if (!stillOld)' in block:
    assert 'dialog.dismiss()' in block
else:
    assert 'setImageResource(R.drawable.ic_bm_download)' in block
    assert 'openExternal(apkUrl, null)' in block
PY

echo BANKMOVIE_V7471_23_ANDROID_BADGE_FULLSCREEN_FORCE_UPDATE_OK
