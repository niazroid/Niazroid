package ir.bankmoviee.app

import android.app.NotificationManager
import android.content.Context
import org.json.JSONArray

/**
 * Durable per-device tombstones for notifications.
 *
 * Remote IDs are kept even when a server delete/revoke arrives late, so an old
 * poll/FCM packet cannot recreate a notification the user has already removed.
 */
object NotificationDismissStore {
    private const val PREFS = "bankmovie_notification_dismissals"
    private const val KEY_REMOTE_IDS = "remote_ids"
    private const val KEY_LOCAL_IDS = "local_ids"
    private const val KEY_ACCOUNT_KEYS = "account_keys"
    private const val KEY_CLEAR_REMOTE_THROUGH = "clear_remote_through"
    private const val MAX_IDS = 1000
    private const val ADMIN_PUSH_NOTIFICATION_BASE = 26000

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun readIds(context: Context, key: String): LinkedHashSet<Long> {
        val raw = prefs(context).getString(key, "[]").orEmpty()
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val result = linkedSetOf<Long>()
        for (i in 0 until array.length()) {
            val id = array.optLong(i, 0L)
            if (id > 0L) result.add(id)
        }
        return result
    }

    private fun writeIds(context: Context, key: String, ids: Collection<Long>) {
        val trimmed = ids.toList().takeLast(MAX_IDS)
        val array = JSONArray()
        trimmed.forEach { array.put(it) }
        prefs(context).edit().putString(key, array.toString()).apply()
    }


    private fun readStrings(context: Context, key: String): LinkedHashSet<String> {
        val raw = prefs(context).getString(key, "[]").orEmpty()
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        val result = linkedSetOf<String>()
        for (i in 0 until array.length()) {
            val value = array.optString(i).trim()
            if (value.isNotBlank()) result.add(value)
        }
        return result
    }

    private fun writeStrings(context: Context, key: String, values: Collection<String>) {
        val array = JSONArray()
        values.filter { it.isNotBlank() }.toList().takeLast(MAX_IDS).forEach { array.put(it) }
        prefs(context).edit().putString(key, array.toString()).apply()
    }

    fun accountKey(id: Long, source: String): String = "${source.lowercase().ifBlank { "personal" }}:$id"

    fun dismissAccount(context: Context, id: Long, source: String) {
        if (id <= 0L) return
        val keys = readStrings(context, KEY_ACCOUNT_KEYS)
        keys.add(accountKey(id, source))
        writeStrings(context, KEY_ACCOUNT_KEYS, keys)
    }

    fun dismissAccountKeys(context: Context, keysToDismiss: Collection<String>) {
        val valid = keysToDismiss.filter { it.isNotBlank() }
        if (valid.isEmpty()) return
        val keys = readStrings(context, KEY_ACCOUNT_KEYS)
        keys.addAll(valid)
        writeStrings(context, KEY_ACCOUNT_KEYS, keys)
    }

    fun isAccountDismissed(context: Context, id: Long, source: String): Boolean =
        id > 0L && readStrings(context, KEY_ACCOUNT_KEYS).contains(accountKey(id, source))

    fun dismissRemote(context: Context, id: Long) {
        if (id <= 0L) return
        val ids = readIds(context, KEY_REMOTE_IDS)
        ids.add(id)
        writeIds(context, KEY_REMOTE_IDS, ids)
    }

    fun dismissRemoteMany(context: Context, idsToDismiss: Collection<Long>) {
        val valid = idsToDismiss.filter { it > 0L }
        if (valid.isEmpty()) return
        val ids = readIds(context, KEY_REMOTE_IDS)
        ids.addAll(valid)
        writeIds(context, KEY_REMOTE_IDS, ids)
    }

    fun dismissLocal(context: Context, id: Long) {
        if (id <= 0L) return
        val ids = readIds(context, KEY_LOCAL_IDS)
        ids.add(id)
        writeIds(context, KEY_LOCAL_IDS, ids)
    }

    fun isRemoteDismissed(context: Context, id: Long): Boolean {
        if (id <= 0L) return false
        val through = prefs(context).getLong(KEY_CLEAR_REMOTE_THROUGH, 0L)
        return id <= through || readIds(context, KEY_REMOTE_IDS).contains(id)
    }

    fun isLocalDismissed(context: Context, id: Long): Boolean =
        id > 0L && readIds(context, KEY_LOCAL_IDS).contains(id)

    fun clearRemoteThrough(context: Context, maxId: Long) {
        if (maxId <= 0L) return
        val old = prefs(context).getLong(KEY_CLEAR_REMOTE_THROUGH, 0L)
        prefs(context).edit().putLong(KEY_CLEAR_REMOTE_THROUGH, maxOf(old, maxId)).apply()
    }

    fun clearLocal(context: Context, ids: Collection<Long>) {
        val old = readIds(context, KEY_LOCAL_IDS)
        old.addAll(ids.filter { it > 0L })
        writeIds(context, KEY_LOCAL_IDS, old)
    }

    fun cancelAdminPushSystemNotification(context: Context, id: Long) {
        if (id <= 0L) return
        runCatching {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.cancel(ADMIN_PUSH_NOTIFICATION_BASE + (id % 3000L).toInt())
        }
    }
}
