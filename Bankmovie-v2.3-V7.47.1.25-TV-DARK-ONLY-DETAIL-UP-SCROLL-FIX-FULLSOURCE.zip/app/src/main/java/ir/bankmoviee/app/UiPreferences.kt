package ir.bankmoviee.app

import android.content.Context
import android.graphics.Color
import kotlin.math.roundToInt

object UiPreferences {
    const val PREFS = "bm_smart_cinema"

    const val KEY_THEME = "ui_theme_mode"
    const val KEY_THEME_SYNC_PENDING = "ui_theme_sync_pending"
    const val KEY_THEME_ACCOUNT_SYNC_INITIALIZED = "ui_theme_account_sync_initialized" // legacy v19; no longer network-synced
    private const val KEY_APP_APPEARANCE_LOCAL_V20 = "ui_app_appearance_local_v20"
    const val KEY_APP_FONT = "ui_app_font_mode"
    private const val KEY_APP_FONT_V7458_MIGRATED = "ui_app_font_v7458_migrated"
    const val KEY_ACCENT = "ui_accent"
    const val KEY_SITE_THEME = "ui_site_theme_key"
    const val KEY_MOBILE_NAV_STYLE = "ui_mobile_nav_style"
    const val KEY_SEEK_SECONDS = "player_seek_seconds"
    const val KEY_SUB_ENABLED = "subtitle_enabled"
    const val KEY_SUB_TEXT_COLOR = "subtitle_text_color"
    const val KEY_SUB_BG_MODE = "subtitle_background_mode"
    const val KEY_SUB_SCALE = "subtitle_scale"
    const val KEY_SUB_DELAY = "subtitle_delay_ms"
    const val KEY_SUB_FONT = "subtitle_font_mode"
    const val KEY_AUTO_NEXT = "player_auto_next"
    const val KEY_SUB_BOLD = "subtitle_bold"
    const val KEY_SUB_POSITION = "subtitle_position"
    const val KEY_DOWNLOAD_BEHAVIOR = "download_behavior"
    const val KEY_SETUP_VERSION = "quick_setup_version"
    const val CURRENT_SETUP_VERSION = 4

    data class Palette(
        val background: Int,
        val background2: Int,
        val panel: Int,
        val panel2: Int,
        val card: Int,
        val stroke: Int,
        val primary: Int,
        val primary2: Int,
        val onPrimary: Int,
        val text: Int,
        val muted: Int,
        val faint: Int,
        val light: Boolean
    )

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** Active application theme. Keep legacy dark/black installs stable while restoring a real light theme. */
    fun normalizeThemeMode(raw: String?): String {
        return when (raw?.trim()?.lowercase().orEmpty()) {
            "light", "white" -> "light"
            "dark", "black" -> "black"
            else -> "black"
        }
    }

    /**
     * TV is intentionally dark-only. A stale Light preference from a phone/tablet
     * migration must never leak into the dedicated Android TV experience.
     */
    fun themeMode(context: Context): String {
        if (DeviceProfile.isTv(context)) return "black"
        return normalizeThemeMode(prefs(context).getString(KEY_THEME, "black"))
    }

    /**
     * V7.47.1.20: app appearance is device-local by design.
     * Website/account themes are a separate product surface and must never
     * overwrite the free in-app Light/Black mode or Accent selection.
     *
     * `markForAccountSync` is intentionally retained only for source/API
     * compatibility with older call sites; it is ignored and no network sync
     * is scheduled.
     */
    fun saveThemeSelection(context: Context, mode: String, markForAccountSync: Boolean = false): String {
        // V7.47.1.25: Android TV has one cinematic theme only. Even an old
        // preference restore or legacy call site cannot switch TV back to Light.
        val normalized = if (DeviceProfile.isTv(context)) "black" else normalizeThemeMode(mode)
        prefs(context).edit()
            .putString(KEY_THEME, normalized)
            .putString("theme_mode", normalized)
            .putBoolean(KEY_APP_APPEARANCE_LOCAL_V20, true)
            .remove(KEY_THEME_SYNC_PENDING)
            .remove(KEY_THEME_ACCOUNT_SYNC_INITIALIZED)
            .apply()
        return normalized
    }

    /** One-time migration that severs every old website/account appearance bridge. */
    fun detachAppAppearanceFromWebsite(context: Context) {
        val storage = prefs(context)
        if (storage.getBoolean(KEY_APP_APPEARANCE_LOCAL_V20, false)) return
        storage.edit()
            .remove(KEY_SITE_THEME)
            .remove(KEY_THEME_SYNC_PENDING)
            .remove(KEY_THEME_ACCOUNT_SYNC_INITIALIZED)
            .putBoolean(KEY_APP_APPEARANCE_LOCAL_V20, true)
            .apply()
    }
    fun appFontMode(context: Context): String {
        val storage = prefs(context)
        val stored = storage.getString(KEY_APP_FONT, null)?.trim().orEmpty()
        if (!storage.getBoolean(KEY_APP_FONT_V7458_MIGRATED, false)) {
            // `font` was the legacy default (Irancell). Move untouched/legacy
            // installs to the new BankMovie house font once, while preserving
            // every other explicit font selection.
            val migrated = if (stored.isBlank() || stored == "font") "bankmovie" else stored
            storage.edit()
                .putString(KEY_APP_FONT, migrated)
                .putBoolean(KEY_APP_FONT_V7458_MIGRATED, true)
                .apply()
            return migrated
        }
        return stored.ifBlank { "bankmovie" }
    }
    fun accentName(context: Context): String = prefs(context).getString(KEY_ACCENT, "blue") ?: "blue"

    /**
     * Legacy website-theme key is kept readable only so old preferences can be
     * cleaned up safely. It is no longer used to drive app colors or logos.
     */
    fun siteThemeKey(context: Context): String = ""

    /** Logo artwork now follows only the locally selected in-app Accent. */
    fun brandLogoRes(context: Context): Int {
        return when (accentName(context)) {
            "orange", "gold" -> R.drawable.bankmovie_logo_dark_orange
            "red" -> R.drawable.bankmovie_logo_dark_red
            "purple" -> R.drawable.bankmovie_logo_dark_purple
            "pink" -> R.drawable.bankmovie_logo_dark_pink
            "teal" -> R.drawable.bankmovie_logo_dark_cyan
            "white" -> R.drawable.bankmovie_logo_dark_white
            "gray" -> R.drawable.bankmovie_logo_dark_black
            "green" -> R.drawable.bankmovie_logo_dark_green
            "blue" -> R.drawable.bankmovie_logo_dark_blue
            else -> R.drawable.bankmovie_logo_transparent
        }
    }

    /**
     * Mobile-only bottom navigation style. TV deliberately ignores this preference
     * and continues to use the dedicated DPAD side rail. "classic" is the existing
     * Bankmovie navigation and remains the default.
     */
    fun mobileNavStyle(context: Context): String {
        val raw = prefs(context).getString(KEY_MOBILE_NAV_STYLE, "classic") ?: "classic"
        return raw.takeIf { it in MOBILE_NAV_STYLE_KEYS } ?: "classic"
    }

    val MOBILE_NAV_STYLE_KEYS = setOf(
        "classic",
        "minimal",
        "glass",
        "floating",
        "neumorph",
        "pill",
        "center_fab",
        "gradient",
        "outline",
        "indicator",
        "curved"
    )

    fun accentColor(name: String): Int = when (name) {
        "gold" -> Color.rgb(245, 184, 46)
        // Keep these values aligned with the website user-theme catalog.
        "orange" -> Color.rgb(249, 115, 22)      // dark-orange #f97316
        "red" -> Color.rgb(239, 68, 68)          // dark-red #ef4444
        "purple" -> Color.rgb(139, 92, 246)      // dark-purple #8b5cf6
        "pink" -> Color.rgb(236, 72, 153)        // dark-pink #ec4899
        "teal" -> Color.rgb(6, 182, 212)         // dark-cyan #06b6d4
        "white" -> Color.rgb(244, 244, 245)      // dark-white #f4f4f5
        "gray" -> Color.rgb(139, 139, 146)       // dark-black #8b8b92
        "green" -> Color.rgb(25, 166, 84)
        else -> Color.rgb(47, 124, 255)           // website default #2f7cff
    }

    fun accentColor(context: Context): Int = accentColor(accentName(context))

    fun palette(context: Context): Palette {
        val mode = themeMode(context)
        val primary = accentColor(context)
        val primary2 = blend(primary, if (mode == "light") Color.BLACK else Color.WHITE, if (mode == "light") 0.08f else 0.24f)
        // Pick the foreground by measured contrast, not by a fixed luminance
        // threshold. This keeps user-selected accents readable in both themes.
        val onPrimary = if (contrastRatio(Color.BLACK, primary) >= contrastRatio(Color.WHITE, primary)) Color.BLACK else Color.WHITE

        return when (mode) {
            "light" -> Palette(
                // Near-white rather than pure white for the page avoids eye strain; cards stay pure white.
                background = Color.rgb(250, 250, 251),
                background2 = Color.rgb(244, 245, 247),
                panel = Color.WHITE,
                panel2 = Color.rgb(246, 247, 249),
                card = Color.WHITE,
                stroke = Color.rgb(216, 219, 224),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.rgb(17, 18, 20),
                muted = Color.rgb(82, 86, 94),
                // Tertiary text still clears WCAG 4.5:1 on pure-white cards.
                faint = Color.rgb(108, 112, 121),
                light = true
            )
            else -> Palette(
                background = Color.BLACK,
                background2 = Color.rgb(4, 4, 5),
                panel = Color.rgb(13, 13, 15),
                panel2 = Color.rgb(24, 24, 27),
                card = Color.rgb(18, 18, 20),
                stroke = Color.rgb(53, 53, 58),
                primary = primary,
                primary2 = primary2,
                onPrimary = onPrimary,
                text = Color.WHITE,
                muted = Color.rgb(190, 190, 196),
                faint = Color.rgb(124, 124, 132),
                light = false
            )
        }
    }

    fun seekSeconds(context: Context): Int = prefs(context).getInt(KEY_SEEK_SECONDS, 10).coerceIn(5, 60)
    fun autoNext(context: Context): Boolean = prefs(context).getBoolean(KEY_AUTO_NEXT, true)
    fun subtitleBold(context: Context): Boolean = prefs(context).getBoolean(KEY_SUB_BOLD, true)
    fun downloadBehavior(context: Context): String = prefs(context).getString(KEY_DOWNLOAD_BEHAVIOR, "ask") ?: "ask"
    fun setupRequired(context: Context): Boolean = prefs(context).getInt(KEY_SETUP_VERSION, 0) < CURRENT_SETUP_VERSION
    fun subtitleEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SUB_ENABLED, true)
    fun subtitleTextColor(context: Context): Int = prefs(context).getInt(KEY_SUB_TEXT_COLOR, Color.YELLOW)
    fun subtitleBackgroundMode(context: Context): String = prefs(context).getString(KEY_SUB_BG_MODE, "black") ?: "black"
    fun subtitleScale(context: Context): Int = prefs(context).getInt(KEY_SUB_SCALE, 112).coerceIn(80, 170)
    fun subtitleDelayMs(context: Context): Int = prefs(context).getInt(KEY_SUB_DELAY, 0).coerceIn(-10000, 10000)
    fun subtitleFontMode(context: Context): String = prefs(context).getString(KEY_SUB_FONT, "font") ?: "font"
    fun subtitlePosition(context: Context): Int = prefs(context).getInt(KEY_SUB_POSITION, 0).coerceIn(0, 2)

    fun subtitleBackgroundColor(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "white" -> Color.WHITE
        "yellow" -> Color.YELLOW
        "red" -> Color.RED
        "blue" -> Color.BLUE
        "pink" -> Color.rgb(236, 64, 122)
        "transparent" -> Color.BLACK
        else -> Color.BLACK
    }

    fun subtitleBackgroundOpacity(context: Context): Int = when (subtitleBackgroundMode(context)) {
        "transparent" -> 0
        "white" -> 225
        else -> 215
    }


    fun reset(context: Context) {
        prefs(context).edit()
            .remove(KEY_THEME)
            .remove(KEY_THEME_SYNC_PENDING)
            .remove(KEY_THEME_ACCOUNT_SYNC_INITIALIZED)
            .remove(KEY_APP_APPEARANCE_LOCAL_V20)
            .remove(KEY_APP_FONT)
            .remove(KEY_APP_FONT_V7458_MIGRATED)
            .remove(KEY_ACCENT)
            .remove(KEY_SITE_THEME)
            .remove(KEY_MOBILE_NAV_STYLE)
            .remove(KEY_SEEK_SECONDS)
            .remove(KEY_SUB_ENABLED)
            .remove(KEY_SUB_TEXT_COLOR)
            .remove(KEY_SUB_BG_MODE)
            .remove(KEY_SUB_SCALE)
            .remove(KEY_SUB_DELAY)
            .remove(KEY_SUB_FONT)
            .remove(KEY_AUTO_NEXT)
            .remove(KEY_SUB_BOLD)
            .remove(KEY_SUB_POSITION)
            .remove(KEY_DOWNLOAD_BEHAVIOR)
            .apply()
    }

    fun blend(a: Int, b: Int, fraction: Float): Int {
        val f = fraction.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).roundToInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).roundToInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).roundToInt()
        )
    }

    fun contrastRatio(foreground: Int, background: Int): Float {
        val a = luminance(foreground)
        val b = luminance(background)
        val lighter = maxOf(a, b)
        val darker = minOf(a, b)
        return (lighter + 0.05f) / (darker + 0.05f)
    }

    /**
     * Keeps the user's Accent hue as the source of truth, but darkens that same
     * accent only when it is used as foreground ink on a Light surface. This is
     * what prevents white/gold/cyan accents from disappearing on white cards.
     * The original primary color is still used for fills, rings and indicators.
     */
    fun readableAccent(context: Context, minimumContrast: Float = 4.5f): Int {
        val p = palette(context)
        if (!p.light || contrastRatio(p.primary, p.panel) >= minimumContrast) return p.primary
        var amount = 0.08f
        while (amount <= 0.88f) {
            val candidate = blend(p.primary, Color.BLACK, amount)
            if (contrastRatio(candidate, p.panel) >= minimumContrast) return candidate
            amount += 0.05f
        }
        return Color.rgb(45, 48, 54)
    }

    private fun luminance(color: Int): Float {
        fun channel(v: Int): Float {
            val c = v / 255f
            return if (c <= 0.03928f) c / 12.92f else Math.pow(((c + 0.055f) / 1.055f).toDouble(), 2.4).toFloat()
        }
        return 0.2126f * channel(Color.red(color)) + 0.7152f * channel(Color.green(color)) + 0.0722f * channel(Color.blue(color))
    }
}
