package ir.bankmoviee.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class BankMovieFirebaseMessagingService : FirebaseMessagingService() {
    companion object {
        private const val CHANNEL_ID = "bankmovie_admin_push"
        private const val PUSH_STATE_PREFS = "bankmovie_admin_push_state"
        private const val KEY_INITIALIZED = "initialized"
        private const val KEY_LAST_ID = "last_id"
        private const val NOTIFICATION_BASE = 26000
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        BankMoviePush.ensureSubscribed(this)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        val data = remoteMessage.data
        val type = data["bm_type"].orEmpty()
        val id = data["notification_id"]?.toLongOrNull()?.coerceAtLeast(1L) ?: System.currentTimeMillis()

        if (type == "admin_revoke_all") {
            LocalNotificationStore.clearAdminPushes(this)
            return
        }
        if (type == "admin_revoke") {
            NotificationDismissStore.dismissRemote(this, id)
            LocalNotificationStore.deleteByDedupeKey(this, "admin-push:$id")
            NotificationDismissStore.cancelAdminPushSystemNotification(this, id)
            return
        }

        val title = data["title"].orEmpty().ifBlank { remoteMessage.notification?.title.orEmpty() }.ifBlank { "پیام مدیریت بانک مووی" }
        val message = data["message"].orEmpty().ifBlank { remoteMessage.notification?.body.orEmpty() }
        if (message.isBlank()) return
        val link = data["link"].orEmpty()

        // A notification the user/admin already removed must never be resurrected
        // by a delayed FCM packet or the polling fallback.
        if (NotificationDismissStore.isRemoteDismissed(this, id)) {
            NotificationDismissStore.cancelAdminPushSystemNotification(this, id)
            return
        }

        // Prevent the legacy 15-minute polling fallback from showing the same
        // broadcast again after it was already delivered by FCM.
        getSharedPreferences(PUSH_STATE_PREFS, MODE_PRIVATE).let { prefs ->
            val previous = prefs.getLong(KEY_LAST_ID, 0L)
            prefs.edit()
                .putBoolean(KEY_INITIALIZED, true)
                .putLong(KEY_LAST_ID, maxOf(previous, id))
                .apply()
        }

        LocalNotificationStore.addOrUpdate(
            this,
            "admin",
            title,
            message,
            org.json.JSONObject().apply { if (link.startsWith("http", true)) put("url", link) },
            "admin-push:$id"
        )
        showSystemNotification(id, title, message, link)
    }

    private fun showSystemNotification(id: Long, title: String, message: String, link: String) {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        createChannel()
        val safeLink = link.trim().takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) }
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("admin_push_tap", true)
            if (safeLink != null) putExtra("admin_push_url", safeLink)
            // No URL on purpose: tapping the notification behaves like the launcher
            // and goes through the normal startup/Home path instead of opening UI early.
        }
        val pending = PendingIntent.getActivity(
            this,
            (id % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val deletePending = PendingIntent.getBroadcast(
            this,
            (id % Int.MAX_VALUE).toInt(),
            Intent(this, NotificationDismissReceiver::class.java).apply {
                action = NotificationDismissReceiver.ACTION
                putExtra(NotificationDismissReceiver.EXTRA_NOTIFICATION_ID, id)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notifications)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setDeleteIntent(deletePending)
            .setContentIntent(pending)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_BASE + (id % 3000L).toInt(), notification)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "پیام‌های مدیریت بانک مووی", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اطلاعیه‌ها و پیام‌هایی که از پنل مدیریت ارسال می‌شوند"
                enableVibration(true)
            }
        )
    }
}
