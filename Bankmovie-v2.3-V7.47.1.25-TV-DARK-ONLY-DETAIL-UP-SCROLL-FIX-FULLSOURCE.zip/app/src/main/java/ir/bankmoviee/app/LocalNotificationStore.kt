package ir.bankmoviee.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs

/**
 * Offline notification inbox for device-local events such as download completion/failure.
 * It is intentionally independent from the account API so unreliable connectivity never
 * causes a user-facing event to disappear.
 */
object LocalNotificationStore {
    private const val PREFS = "bankmovie_local_notifications"
    private const val KEY_ITEMS = "items"
    private val lock = Any()

    fun addOrUpdate(
        context: Context,
        type: String,
        title: String,
        message: String,
        target: JSONObject = JSONObject(),
        dedupeKey: String = ""
    ) = synchronized(lock) {
        if (dedupeKey.startsWith("admin-push:")) {
            val remoteId = dedupeKey.substringAfter(':').toLongOrNull() ?: 0L
            if (NotificationDismissStore.isRemoteDismissed(context, remoteId)) return@synchronized
        }
        val items = read(context)
        val now = System.currentTimeMillis()
        val existingIndex = if (dedupeKey.isBlank()) -1 else items.indexOfFirst { it.optString("dedupe_key") == dedupeKey }
        val item = if (existingIndex >= 0) JSONObject(items[existingIndex].toString()) else JSONObject().apply {
            // Local IDs live in a separate namespace; the explicit `local` flag is the source of truth.
            put("id", abs(now * 31L + type.hashCode().toLong()))
            put("local", true)
            put("created_at_ms", now)
            put("is_read", false)
        }
        item.put("type", type.take(40))
        item.put("title", title.take(220))
        item.put("message", message)
        item.put("target", JSONObject(target.toString()))
        item.put("dedupe_key", dedupeKey)
        item.put("updated_at_ms", now)
        if (existingIndex >= 0) items[existingIndex] = item else items.add(0, item)
        write(context, items.take(120))
    }

    private fun isHidden(context: Context, item: JSONObject): Boolean {
        if (NotificationDismissStore.isLocalDismissed(context, item.optLong("id"))) return true
        val dedupe = item.optString("dedupe_key")
        if (dedupe.startsWith("admin-push:")) {
            val remoteId = dedupe.substringAfter(':').toLongOrNull() ?: 0L
            if (NotificationDismissStore.isRemoteDismissed(context, remoteId)) return true
        }
        return false
    }

    fun all(context: Context): MutableList<JSONObject> = synchronized(lock) {
        read(context)
            .filterNot { isHidden(context, it) }
            .sortedByDescending { it.optLong("created_at_ms", 0L) }
            .map { decorate(it) }
            .toMutableList()
    }

    fun unreadCount(context: Context): Int = synchronized(lock) {
        read(context).count { !isHidden(context, it) && !it.optBoolean("is_read", false) }
    }

    fun markRead(context: Context, id: Long) = mutate(context, id) { it.put("is_read", true) }

    fun markAllRead(context: Context) = synchronized(lock) {
        val items = read(context)
        items.forEach { it.put("is_read", true) }
        write(context, items)
    }

    fun delete(context: Context, id: Long) = synchronized(lock) {
        NotificationDismissStore.dismissLocal(context, id)
        write(context, read(context).filterNot { it.optLong("id") == id })
    }

    fun deleteByDedupeKey(context: Context, dedupeKey: String) = synchronized(lock) {
        if (dedupeKey.isBlank()) return@synchronized
        val remoteId = if (dedupeKey.startsWith("admin-push:")) dedupeKey.substringAfter(':').toLongOrNull() ?: 0L else 0L
        if (remoteId > 0L) {
            NotificationDismissStore.dismissRemote(context, remoteId)
            NotificationDismissStore.cancelAdminPushSystemNotification(context, remoteId)
        }
        val items = read(context)
        items.filter { it.optString("dedupe_key") == dedupeKey }.forEach {
            NotificationDismissStore.dismissLocal(context, it.optLong("id"))
        }
        write(context, items.filterNot { it.optString("dedupe_key") == dedupeKey })
    }

    fun clear(context: Context) = synchronized(lock) {
        val items = read(context)
        val ids = items.map { it.optLong("id") }.filter { it > 0L }
        NotificationDismissStore.clearLocal(context, ids)
        val remoteIds = items.mapNotNull {
            val dedupe = it.optString("dedupe_key")
            if (dedupe.startsWith("admin-push:")) dedupe.substringAfter(':').toLongOrNull() else null
        }.filter { it > 0L }
        NotificationDismissStore.dismissRemoteMany(context, remoteIds)
        remoteIds.forEach { NotificationDismissStore.cancelAdminPushSystemNotification(context, it) }
        write(context, emptyList())
    }

    fun clearAdminPushes(context: Context) = synchronized(lock) {
        val items = read(context)
        val adminItems = items.filter { it.optString("dedupe_key").startsWith("admin-push:") }
        val localIds = adminItems.map { it.optLong("id") }.filter { it > 0L }
        val remoteIds = adminItems.mapNotNull {
            it.optString("dedupe_key").substringAfter(':').toLongOrNull()
        }.filter { it > 0L }
        NotificationDismissStore.clearLocal(context, localIds)
        NotificationDismissStore.dismissRemoteMany(context, remoteIds)
        remoteIds.forEach { NotificationDismissStore.cancelAdminPushSystemNotification(context, it) }
        write(context, items.filterNot { it.optString("dedupe_key").startsWith("admin-push:") })
    }

    private fun mutate(context: Context, id: Long, block: (JSONObject) -> Unit) = synchronized(lock) {
        val items = read(context)
        val index = items.indexOfFirst { it.optLong("id") == id }
        if (index >= 0) {
            val item = JSONObject(items[index].toString())
            block(item)
            items[index] = item
            write(context, items)
        }
    }

    private fun decorate(source: JSONObject): JSONObject {
        val item = JSONObject(source.toString())
        val ageSeconds = ((System.currentTimeMillis() - item.optLong("created_at_ms", System.currentTimeMillis())) / 1000L).coerceAtLeast(0L)
        item.put("age_seconds", ageSeconds)
        item.put("date_text", relativeTime(ageSeconds))
        item.put("local", true)
        return item
    }

    private fun relativeTime(seconds: Long): String = when {
        seconds < 45L -> "همین حالا"
        seconds < 3600L -> "${seconds / 60L} دقیقه پیش"
        seconds < 86400L -> "${seconds / 3600L} ساعت پیش"
        seconds < 604800L -> "${seconds / 86400L} روز پیش"
        else -> "${seconds / 604800L} هفته پیش"
    }

    private fun read(context: Context): MutableList<JSONObject> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]").orEmpty()
        val array = runCatching { JSONArray(raw) }.getOrDefault(JSONArray())
        return MutableList(array.length()) { index -> JSONObject(array.optJSONObject(index)?.toString() ?: "{}") }
            .filter { it.optLong("id", 0L) > 0L }
            .toMutableList()
    }

    private fun write(context: Context, items: List<JSONObject>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject(it.toString())) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, array.toString()).apply()
    }
}
