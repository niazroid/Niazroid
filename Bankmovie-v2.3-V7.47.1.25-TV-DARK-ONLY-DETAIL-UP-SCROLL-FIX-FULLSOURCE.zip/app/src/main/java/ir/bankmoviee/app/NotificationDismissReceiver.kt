package ir.bankmoviee.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Persists a user's system-tray dismissal so polling/FCM cannot resurrect it. */
class NotificationDismissReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val id = intent?.getLongExtra(EXTRA_NOTIFICATION_ID, 0L) ?: 0L
        if (id <= 0L) return
        NotificationDismissStore.dismissRemote(context, id)
        LocalNotificationStore.deleteByDedupeKey(context, "admin-push:$id")
        NotificationDismissStore.cancelAdminPushSystemNotification(context, id)
    }

    companion object {
        const val ACTION = "ir.bankmoviee.app.ACTION_DISMISS_ADMIN_PUSH"
        const val EXTRA_NOTIFICATION_ID = "notification_id"
    }
}
