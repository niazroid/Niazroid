#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_23_2_UPDATE_CHANGE_CHECKMARKS_REAL_ACTION_FA.md"

test -s "$MAIN"
test -s "$META"
test -s "$NOTE"
grep -Fq 'mainUpdateV7471_23_2=V7.47.1.23.2 UPDATE CHANGE CHECKMARKS + REAL MANDATORY UPDATE ACTION' "$META"
grep -Fq 'fun stripDecorativeEmoji(input: String): String' "$MAIN"
grep -Fq 'titleOnly.equals("لیست تغییرات", ignoreCase = true)' "$MAIN"
grep -Fq 'setImageResource(R.drawable.ic_bm_check)' "$MAIN"
grep -Fq 'Real update action only. No fake "verification" control is shown.' "$MAIN"
grep -Fq 'setImageResource(R.drawable.ic_bm_download)' "$MAIN"
grep -Fq 'setCancelable(false)' "$MAIN"
grep -Fq 'setCanceledOnTouchOutside(false)' "$MAIN"
if grep -Fq 'text = t("↻  آپدیت کردم، دوباره بررسی کن"' "$MAIN"; then
  echo 'ERROR: fake update recheck action is still present' >&2
  exit 1
fi
if grep -Fq 'setImageResource(R.drawable.ic_setup_theme)' "$MAIN" && sed -n '8580,9005p' "$MAIN" | grep -Fq 'setImageResource(R.drawable.ic_setup_theme)'; then
  echo 'ERROR: update changelog still uses mixed decorative row icons' >&2
  exit 1
fi
echo BANKMOVIE_V7471_23_2_UPDATE_CHECKMARKS_REAL_ACTION_OK
