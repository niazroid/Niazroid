# BankMovie V7.47.1.25 — TV Dark-only + Detail UP/Scroll Fix

این نسخه فقط مسیر Android TV را اصلاح می‌کند و رفتار موبایل را تغییر نمی‌دهد.

- تم سفید روی Android TV حذف شده است. `UiPreferences.themeMode()` روی TV همیشه `black` برمی‌گرداند و حتی preference قدیمی یا فراخوانی legacy نمی‌تواند TV را دوباره Light کند.
- انتخاب‌گر Light/Black در Settings، Quick Setup/Onboarding و دیالوگ زبان/پوسته روی TV نمایش داده نمی‌شود؛ فقط وضعیت ثابت «مشکی سینمایی» دیده می‌شود. موبایل همچنان هر دو تم را دارد.
- مسیر عمودی صفحه اطلاعات فیلم/سریال روی TV بازسازی شده است. پایین صفحه دیگر برای برگشت با DPAD_UP به FocusFinder سازنده تلویزیون وابسته نیست.
- کنترل‌های بدنه Detail به ردیف‌های عمودی پایدار وصل می‌شوند؛ UP به ردیف قبلی می‌رود و اولین ردیف بدنه مستقیماً به Play Online برمی‌گردد.
- هنگام برگشت از اولین بخش بدنه به Hero، ScrollView صریحاً به ابتدای صفحه برمی‌گردد تا حالت «فوکوس هست ولی صفحه بالا نمی‌آید» رخ ندهد.
- Hero action row و ترتیب Play / Trailer / Watchlist نسخه‌های V7.12/V7.13 دست‌نخورده مانده است.

Marker: `BANKMOVIE_V7471_25_TV_DARK_ONLY_DETAIL_UP_SCROLL_OK`
