#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'
manifest='app/src/main/AndroidManifest.xml'
gradle='app/build.gradle'

need() { grep -Fq -- "$1" "$2" || { echo "Missing V7.21 marker: $1 in $2" >&2; exit 1; }; }

# Generic Back state retention: actual screen tree, not just a search-only snapshot.
need 'BANKMOVIE_V721_RETAINED_BACKSTACK' "$main"
need 'private data class RetainedNavigationScreen(' "$main"
need 'val children: List<View>' "$main"
need 'private fun restoreRetainedNavigationScreen(snapshot: RetainedNavigationScreen): Boolean' "$main"
need 'snapshot.children.forEach { child ->' "$main"
need 'content.addView(child)' "$main"
need 'focusedView = currentFocus?.takeIf { isDescendantOfContent(it) }' "$main"
need 'if (snapshot == null || !restoreRetainedNavigationScreen(snapshot))' "$main"
need 'retainedNavigationMaxEntries = 3' "$main"

# Existing Advanced Search snapshot is preserved as a fallback/regression guard.
need 'rememberCurrentScreen { showAdvancedSearchResults(state.copy(), restoreSnapshot = true) }' "$main"

# Player local startup must be independent from Cast framework/UI.
need 'class PlayerActivity : Activity()' "$player"
need 'import androidx.mediarouter.app.MediaRouteChooserDialog' "$player"
need 'private lateinit var castButton: View' "$player"
need 'castButton = simplePlayerIcon(R.drawable.ic_player_cast)' "$player"
need 'MediaRouteChooserDialog(this).apply {' "$player"
need 'handler.postDelayed({ runCatching { initCastRenderer() } }, 450L)' "$player"
need 'Cast is optional. It must never prevent the local LibVLC player from opening.' "$player"
need 'V7.21: local playback owns startup.' "$player"
need 'CastContext.getSharedInstance(applicationContext, ContextCompat.getMainExecutor(this))' "$player"
need 'RemoteKind.CHROMECAST' "$player"
need 'RemoteKind.DLNA' "$player"
need 'SetAVTransportURI' app/src/main/java/ir/bankmoviee/app/DlnaController.kt
need 'M-SEARCH * HTTP/1.1' app/src/main/java/ir/bankmoviee/app/DlnaDiscovery.kt
need "implementation 'androidx.mediarouter:mediarouter:1.8.1'" "$gradle"
need "implementation 'com.google.android.gms:play-services-cast-framework:22.1.0'" "$gradle"
need 'com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME' "$manifest"
need 'sourceMainUpdateSecondHotfixTag=BANKMOVIE-2.3-V721-20260910' "$source"

# Never put framework Cast UI back into the critical buildUi path.
if grep -Fq 'private lateinit var castButton: MediaRouteButton' "$player"; then
  echo 'MediaRouteButton returned to player startup path.' >&2
  exit 1
fi
if grep -Fq 'class PlayerActivity : FragmentActivity()' "$player"; then
  echo 'PlayerActivity must stay on the pre-Cast stable Activity base.' >&2
  exit 1
fi

python3 - <<'PY'
import xml.etree.ElementTree as ET
from pathlib import Path
for p in Path('app/src/main').rglob('*.xml'):
    ET.parse(p)

# Lightweight delimiter check for touched Kotlin files.
def scrub(src):
    out=[]; i=0; state='code'
    while i < len(src):
        if state=='code':
            if src.startswith('//', i): state='line'; out += [' ',' ']; i += 2; continue
            if src.startswith('/*', i): state='block'; out += [' ',' ']; i += 2; continue
            if src.startswith('"""', i): state='triple'; out += [' ',' ',' ']; i += 3; continue
            if src[i]=='"': state='string'; out.append(' '); i += 1; continue
            if src[i]=="'": state='char'; out.append(' '); i += 1; continue
            out.append(src[i]); i += 1; continue
        if state=='line':
            if src[i]=='\n': state='code'; out.append('\n')
            else: out.append(' ')
            i += 1; continue
        if state=='block':
            if src.startswith('*/', i): state='code'; out += [' ',' ']; i += 2
            else: out.append('\n' if src[i]=='\n' else ' '); i += 1
            continue
        if state=='triple':
            if src.startswith('"""', i): state='code'; out += [' ',' ',' ']; i += 3
            else: out.append('\n' if src[i]=='\n' else ' '); i += 1
            continue
        quote='"' if state=='string' else "'"
        if src[i]=='\\':
            out.append(' '); i += 1
            if i < len(src): out.append('\n' if src[i]=='\n' else ' '); i += 1
        elif src[i]==quote:
            state='code'; out.append(' '); i += 1
        else:
            out.append('\n' if src[i]=='\n' else ' '); i += 1
    if state not in ('code','line'):
        raise SystemExit(f'unterminated lexical state: {state}')
    return ''.join(out)

pairs={')':'(',']':'[','}':'{'}
for path in [Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt'), Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt')]:
    stack=[]
    for ch in scrub(path.read_text(encoding='utf-8')):
        if ch in '([{': stack.append(ch)
        elif ch in ')]}':
            if not stack or stack.pop()!=pairs[ch]:
                raise SystemExit(f'unbalanced delimiter in {path}')
    if stack: raise SystemExit(f'unbalanced delimiter in {path}: {stack[-8:]}')
print('V721_KOTLIN_XML_STRUCTURE_OK')
PY

echo V721_RETAINED_STATE_CAST_SAFE_OK
