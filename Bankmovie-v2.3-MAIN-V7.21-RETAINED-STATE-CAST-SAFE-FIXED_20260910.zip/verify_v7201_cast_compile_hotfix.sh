#!/usr/bin/env bash
set -euo pipefail

controller='app/src/main/java/ir/bankmoviee/app/DlnaController.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
source='BANKMOVIE_BUILD_SOURCE_2_3.txt'

need() { grep -Fq -- "$1" "$2" || { echo "Missing V7.20.1 compile-hotfix marker: $1 in $2" >&2; exit 1; }; }

need 'execute<Unit>({' "$controller"
need 'return@execute Result.failure<Unit>(' "$controller"
need '}) { result: Result<Unit> ->' "$controller"
need 'context.mergedSelector?.let { castSelector ->' "$player"
need 'selectorBuilder.addSelector(castSelector)' "$player"
if grep -Fq 'castButton.routeSelector = selectorBuilder.build()' "$player"; then
  :
else
  need 'castRouteSelector = selectorBuilder.build()' "$player"
fi
need 'castCompileHotfix=V7.20.1 KOTLIN RESULT LAMBDA + NULL-SAFE CAST SELECTOR' "$source"
need 'sourceMainUpdateHotfixTag=BANKMOVIE-2.3-V7201-20260910' "$source"

if grep -Fq '} { result ->' "$controller"; then
  echo 'Invalid double trailing-lambda syntax remains in DlnaController.' >&2
  exit 1
fi
if grep -Fq '.addSelector(context.mergedSelector)' "$player"; then
  echo 'Direct nullable mergedSelector use remains in PlayerActivity.' >&2
  exit 1
fi

echo V7201_CAST_COMPILE_HOTFIX_OK
