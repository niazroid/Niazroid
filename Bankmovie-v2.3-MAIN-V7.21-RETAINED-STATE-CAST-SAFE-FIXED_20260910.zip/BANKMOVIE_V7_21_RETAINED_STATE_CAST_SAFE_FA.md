# BankMovie V7.21 — Retained Back State + Cast-safe Player Startup

## Navigation state
- Back from Detail/Actor/sub-pages now restores the actual previous `content` View tree when available.
- Loaded pagination, ScrollView position, button/list state, and focused View are retained without rebuilding or re-requesting page 1.
- Explicit navigation to a page still uses its normal `show*()` path and therefore refreshes normally.
- Retained trees are capped to 3 entries and expire after 2 hours to avoid keeping a large UI history in memory.
- Existing per-screen restorer/scroll logic remains as fallback when a retained tree was evicted or expired.

## Player/Cast startup
- `PlayerActivity` is restored to the stable platform `Activity` base used before V7.20.
- A normal lightweight player icon is used for Cast; no `MediaRouteButton` is constructed in the critical player UI build path.
- Local LibVLC UI + playback are created first. Cast/DLNA initialization is posted lazily after successful local startup.
- The actual AndroidX `MediaRouteChooserDialog` is opened only when the user presses Cast.
- Google Cast and DLNA discovery/control remain real; Cast failure no longer invalidates or blocks local playback.
