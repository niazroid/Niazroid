<?php
require_once __DIR__ . '/security_bootstrap.php';
require_once __DIR__ . '/vip_features.php';
/**
 * BankMovie Archive/API control helper
 * Shared by /, movie.php, /view_all, api4.php and admin.php.
 */

if (!function_exists('bm_archive_section_catalog_defaults')) {
    function bm_archive_section_catalog_defaults(string $archiveId = ''): array {
        $all = [
            'archive1' => [
                'updated_movies' => ['label'=>'فیلم‌های آپدیت شده'],
                'updated_series' => ['label'=>'سریال‌های آپدیت شده'],
                'collections' => ['label'=>'کالکشن‌ها'],
                'top_2026' => ['label'=>'برترین فیلم‌های 2026'],
                'dubbed_fa' => ['label'=>'فیلم‌های دوبله فارسی'],
                'turkish' => ['label'=>'سریال‌های ترکی'],
                'korean' => ['label'=>'سریال‌های کره‌ای'],
                'anime' => ['label'=>'انیمه'],
            ],
            'archive2' => [
                'new_movies' => ['label'=>'فیلم‌های جدید'],
                'updated_series' => ['label'=>'سریال‌های آپدیت'],
                'collections' => ['label'=>'کالکشن'],
                'animations' => ['label'=>'انیمیشن'],
                'dubbed' => ['label'=>'دوبله'],
            ],
            'archive3' => [
                'new_series' => ['label'=>'سریال‌های جدید'],
                'new_movies' => ['label'=>'فیلم‌های جدید'],
                'updated_animations' => ['label'=>'انیمیشن‌های به‌روز شده'],
                'updated_anime' => ['label'=>'انیمه‌های به‌روز شده'],
                'collections' => ['label'=>'کالکشن‌ها'],
            ],
            'archive4' => [
                'new_series' => ['label'=>'سریال‌های جدید'],
                'new_movies' => ['label'=>'فیلم‌های جدید'],
                'updated_animations' => ['label'=>'انیمیشن‌های به‌روز شده'],
                'updated_anime' => ['label'=>'انیمه‌های به‌روز شده'],
                'collections' => ['label'=>'کالکشن‌ها'],
            ],
        ];
        if ($archiveId === '') return $all;
        return $all[$archiveId] ?? [];
    }
}

if (!function_exists('bm_archive_section_state_defaults')) {
    function bm_archive_section_state_defaults(string $archiveId): array {
        $out = [];
        foreach (bm_archive_section_catalog_defaults($archiveId) as $key => $def) {
            $out[$key] = ['enabled'=>true, 'label'=>''];
        }
        return $out;
    }
}

if (!function_exists('bm_archive_control_defaults')) {
    function bm_archive_control_defaults(): array {
        return [
            'archives' => [
                'archive1' => [
                    'label' => 'آرشیو ۱',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'download_link_mode' => 'redirect',
                    'download_client_mode' => 'adm_copy',
                    'player_gates' => [
                        'master' => 'inherit',
                        'internal' => 'inherit',
                        'external' => 'inherit',
                        'copy_link' => 'inherit',
                    ],
                    'player_gates' => [
                        'master' => 'inherit',
                        'internal' => 'inherit',
                        'external' => 'inherit',
                        'copy_link' => 'inherit',
                    ],
                    'player_gates' => [
                        'master' => 'inherit',
                        'internal' => 'inherit',
                        'external' => 'inherit',
                        'copy_link' => 'inherit',
                    ],
                    'player_gates' => [
                        'master' => 'inherit',
                        'internal' => 'inherit',
                        'external' => 'inherit',
                        'copy_link' => 'inherit',
                    ],
                    'source_base_url' => 'https://www.my-f2mx.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۱ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                    'sections' => bm_archive_section_state_defaults('archive1'),
                ],
                'archive2' => [
                    'label' => 'آرشیو ۲',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'download_link_mode' => 'redirect',
                    'download_client_mode' => 'adm_copy',
                    'source_base_url' => 'https://serialblog1.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۲ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                    'sections' => bm_archive_section_state_defaults('archive2'),
                ],
                'archive3' => [
                    'label' => 'آرشیو ۳',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'download_link_mode' => 'redirect',
                    'download_client_mode' => 'adm_copy',
                    'source_base_url' => 'https://dornatv.com',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۳ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                    'sections' => bm_archive_section_state_defaults('archive3'),
                ],
                'archive4' => [
                    'label' => 'آرشیو ۴',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'download_link_mode' => 'redirect',
                    'download_client_mode' => 'adm_copy',
                    'source_base_url' => 'https://cinamatic.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۴ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                    'sections' => bm_archive_section_state_defaults('archive4'),
                ],
            ],
            // V228 — operational controls. File-backed; no new DB table.
            'archive_order' => ['archive1','archive2','archive3','archive4'],
            'default_archive' => 'archive1',
            'fallback_archive' => 'archive2',
            'emergency' => [
                'enabled' => false,
                'primary_archive' => 'archive2',
                // hide = external tabs disappear; visible = tabs stay disabled with message.
                'external_mode' => 'hide',
                'message' => 'به‌دلیل محدودیت اینترنت، این آرشیو موقتاً در دسترس نیست. آرشیو داخلی بانک‌مووی همچنان فعال است.',
            ],
            // V7.46.4 download delivery controls. The website keeps its existing
            // archive behavior; Android 2.2 stays on legacy/original links until a
            // client explicitly advertises download-system v2.
            'download_redirect_enabled' => true,
            'download_modern_client_only' => true,
            'blocked_items' => [],
            'archive_control_schema_version' => 8,
            'audience_schema_version' => 5,
            'updated_at' => null,
        ];
    }
}

if (!function_exists('bm_archive_normalize_base_url')) {
    function bm_archive_normalize_base_url($value, bool $allowEmpty = true): string {
        $value = trim((string)$value);
        if ($value === '') return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        if (strlen($value) > 500 || preg_match('/[\x00-\x20\x7f]/', $value)) return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        if (!preg_match('~^[a-z][a-z0-9+.-]*://~i', $value)) $value = 'https://' . ltrim($value, '/');
        $parts = @parse_url($value);
        if (!is_array($parts)) return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
        if (!in_array($scheme, ['http','https'], true) || $host === '' || isset($parts['user']) || isset($parts['pass'])) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        if ($host === 'localhost' || !str_contains($host, '.') || str_ends_with($host, '.local') || filter_var($host, FILTER_VALIDATE_IP)) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $host)) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
        $path = trim((string)($parts['path'] ?? ''), '/');
        return $scheme . '://' . $host . $port . ($path !== '' ? '/' . $path : '');
    }
}

if (!function_exists('bm_archive_normalize_url_list')) {
    function bm_archive_normalize_url_list($value, array $fallback = []): array {
        if (is_string($value)) $value = preg_split('/\R+|[,،]+/u', $value) ?: [];
        if (!is_array($value)) $value = [];
        $out = [];
        foreach ($value as $url) {
            $url = bm_archive_normalize_base_url($url, true);
            if ($url !== '' && strtolower((string)(parse_url($url, PHP_URL_SCHEME) ?: '')) !== 'https') $url = '';
            if ($url !== '' && !in_array($url, $out, true)) $out[] = $url;
            if (count($out) >= 12) break;
        }
        if (!$out) {
            foreach ($fallback as $url) {
                $url = bm_archive_normalize_base_url($url, false);
                if (strtolower((string)(parse_url($url, PHP_URL_SCHEME) ?: '')) !== 'https') continue;
                if ($url !== '' && !in_array($url, $out, true)) $out[] = $url;
            }
        }
        return $out ?: ['https://dl10.bankmovie.top'];
    }
}

if (!function_exists('bm_archive_normalize_identifier')) {
    function bm_archive_normalize_identifier($value): string {
        $value = rawurldecode(trim((string)$value));
        if ($value === '') return '';
        if (function_exists('mb_strtolower')) $value = mb_strtolower($value, 'UTF-8');
        else $value = strtolower($value);
        $value = preg_replace('/[\x{200c}\x{200e}\x{200f}\s]+/u', ' ', $value) ?? $value;
        return trim($value, " /\t\n\r\0\x0B");
    }
}

if (!function_exists('bm_archive_normalize_blocked_items')) {
    function bm_archive_normalize_blocked_items($items): array {
        if (!is_array($items)) return [];
        $out = [];
        foreach ($items as $row) {
            if (!is_array($row)) continue;
            $archiveId = strtolower(trim((string)($row['archive_id'] ?? '')));
            if (!in_array($archiveId, ['archive1','archive2','archive3','archive4'], true)) continue;
            $identifier = trim((string)($row['identifier'] ?? ''));
            $sourceUrl = trim((string)($row['source_url'] ?? ''));
            $title = trim(strip_tags((string)($row['title'] ?? '')));
            $year = trim((string)($row['year'] ?? ''));
            if ($identifier === '' && $sourceUrl === '' && $title === '') continue;
            if (strlen($identifier) > 500) $identifier = substr($identifier, 0, 500);
            if (strlen($sourceUrl) > 1000) $sourceUrl = substr($sourceUrl, 0, 1000);
            if (function_exists('mb_substr')) $title = mb_substr($title, 0, 240, 'UTF-8');
            else $title = substr($title, 0, 240);
            $stable = $archiveId . '|' . bm_archive_normalize_identifier($identifier) . '|' . bm_archive_normalize_identifier($sourceUrl) . '|' . bm_archive_normalize_identifier($title) . '|' . $year;
            $id = trim((string)($row['id'] ?? ''));
            if (!preg_match('/^[a-f0-9]{16,64}$/', $id)) $id = substr(hash('sha256', $stable), 0, 24);
            $out[$id] = [
                'id' => $id,
                'archive_id' => $archiveId,
                'identifier' => $identifier,
                'source_url' => $sourceUrl,
                'title' => $title !== '' ? $title : $identifier,
                'year' => preg_match('/^\d{4}$/', $year) ? $year : '',
                'block_downloads' => true,
                'block_streams' => true,
                'block_media' => true,
                'created_at' => trim((string)($row['created_at'] ?? '')) ?: date('c'),
            ];
            if (count($out) >= 1000) break;
        }
        return array_values($out);
    }
}

if (!function_exists('bm_archive_control_path')) {
    function bm_archive_control_path(): string {
        // Store settings outside public_html when possible. Old public file remains as read-only fallback.
        if (function_exists('bm_security_private_path')) {
            return bm_security_private_path('archive_api_settings.json');
        }
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_legacy_path')) {
    function bm_archive_control_legacy_path(): string {
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_normalize')) {
    function bm_archive_control_normalize(array $settings): array {
        $defaults = bm_archive_control_defaults();
        if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
        foreach ($defaults['archives'] as $id => $def) {
            $row = isset($settings['archives'][$id]) && is_array($settings['archives'][$id]) ? $settings['archives'][$id] : [];
            $label = trim((string)($row['label'] ?? $def['label']));
            $mode = trim((string)($row['disabled_mode'] ?? $def['disabled_mode']));
            if (!in_array($mode, ['visible', 'hide'], true)) $mode = 'visible';
            $scope = trim((string)($row['access_scope'] ?? $def['access_scope'] ?? 'public'));
            if (!in_array($scope, ['public', 'member', 'vip', 'admin'], true)) $scope = 'public';
            $downloadScope = trim((string)($row['download_access_scope'] ?? $def['download_access_scope'] ?? 'public'));
            if (!in_array($downloadScope, ['public', 'member', 'vip', 'admin', 'disabled'], true)) $downloadScope = 'public';
            $streamScope = trim((string)($row['stream_access_scope'] ?? $def['stream_access_scope'] ?? 'public'));
            if (!in_array($streamScope, ['public', 'member', 'vip', 'admin', 'disabled'], true)) $streamScope = 'public';
            $downloadLinkMode = strtolower(trim((string)($row['download_link_mode'] ?? $def['download_link_mode'] ?? 'redirect')));
            if (!in_array($downloadLinkMode, ['redirect', 'original', 'disabled'], true)) $downloadLinkMode = 'redirect';
            $downloadClientMode = strtolower(trim((string)($row['download_client_mode'] ?? $def['download_client_mode'] ?? 'adm_copy')));
            if (!in_array($downloadClientMode, ['adm_copy', 'all', 'disabled'], true)) $downloadClientMode = 'adm_copy';
            $msg = trim((string)($row['disabled_message'] ?? $def['disabled_message']));

            $playerGateDefaults = is_array($def['player_gates'] ?? null) ? $def['player_gates'] : [
                'master'=>'inherit','internal'=>'inherit','external'=>'inherit','copy_link'=>'inherit'
            ];
            $rawPlayerGates = is_array($row['player_gates'] ?? null) ? $row['player_gates'] : [];
            $playerGates = [];
            foreach (['master','internal','external','copy_link'] as $gateKey) {
                $gateMode = strtolower(trim((string)($rawPlayerGates[$gateKey] ?? ($playerGateDefaults[$gateKey] ?? 'inherit'))));
                if (!in_array($gateMode, ['inherit','free','vip'], true)) $gateMode = 'inherit';
                $playerGates[$gateKey] = $gateMode;
            }

            $sections = [];
            $rawSections = isset($row['sections']) && is_array($row['sections']) ? $row['sections'] : [];
            foreach (bm_archive_section_catalog_defaults($id) as $sectionKey => $sectionDef) {
                $rawSection = isset($rawSections[$sectionKey]) && is_array($rawSections[$sectionKey]) ? $rawSections[$sectionKey] : [];
                $customLabel = trim(strip_tags((string)($rawSection['label'] ?? '')));
                if (function_exists('mb_substr')) $customLabel = mb_substr($customLabel, 0, 120, 'UTF-8');
                else $customLabel = substr($customLabel, 0, 120);
                $sections[$sectionKey] = [
                    'enabled' => filter_var($rawSection['enabled'] ?? true, FILTER_VALIDATE_BOOLEAN),
                    // Empty means inherit the current site/default title. Existing site text settings are not reset.
                    'label' => $customLabel,
                ];
            }
            $settings['archives'][$id] = [
                'label' => $label !== '' ? $label : $def['label'],
                'enabled' => filter_var($row['enabled'] ?? $def['enabled'], FILTER_VALIDATE_BOOLEAN),
                'access_scope' => $scope,
                'download_access_scope' => $downloadScope,
                'stream_access_scope' => $streamScope,
                'download_link_mode' => $downloadLinkMode,
                'download_client_mode' => $downloadClientMode,
                'player_gates' => $playerGates,
                'source_base_url' => bm_archive_normalize_base_url($row['source_base_url'] ?? $def['source_base_url'] ?? '', true),
                'download_base_urls' => bm_archive_normalize_url_list($row['download_base_urls'] ?? ($row['download_base_url'] ?? []), $def['download_base_urls'] ?? ['https://dl10.bankmovie.top']),
                'disabled_mode' => $mode,
                'disabled_message' => $msg !== '' ? $msg : $def['disabled_message'],
                'sections' => $sections,
            ];
        }
        $knownArchiveIds = ['archive1','archive2','archive3','archive4'];

        $rawOrder = is_array($settings['archive_order'] ?? null) ? $settings['archive_order'] : [];
        $order = [];
        foreach ($rawOrder as $aid) {
            $aid = strtolower(trim((string)$aid));
            if (in_array($aid, $knownArchiveIds, true) && !in_array($aid, $order, true)) $order[] = $aid;
        }
        foreach ($knownArchiveIds as $aid) if (!in_array($aid, $order, true)) $order[] = $aid;
        $settings['archive_order'] = $order;

        $defaultArchive = strtolower(trim((string)($settings['default_archive'] ?? 'archive1')));
        if (!in_array($defaultArchive, $knownArchiveIds, true)) $defaultArchive = 'archive1';
        $settings['default_archive'] = $defaultArchive;

        $fallbackArchive = strtolower(trim((string)($settings['fallback_archive'] ?? 'archive2')));
        if (!in_array($fallbackArchive, $knownArchiveIds, true)) $fallbackArchive = 'archive2';
        $settings['fallback_archive'] = $fallbackArchive;

        $emergency = is_array($settings['emergency'] ?? null) ? $settings['emergency'] : [];
        $emergencyPrimary = strtolower(trim((string)($emergency['primary_archive'] ?? 'archive2')));
        if (!in_array($emergencyPrimary, $knownArchiveIds, true)) $emergencyPrimary = 'archive2';
        $emergencyMode = strtolower(trim((string)($emergency['external_mode'] ?? 'hide')));
        if (!in_array($emergencyMode, ['hide','visible'], true)) $emergencyMode = 'hide';
        $emergencyMessage = trim(strip_tags((string)($emergency['message'] ?? '')));
        if ($emergencyMessage === '') {
            $emergencyMessage = 'به‌دلیل محدودیت اینترنت، این آرشیو موقتاً در دسترس نیست. آرشیو داخلی بانک‌مووی همچنان فعال است.';
        }
        if (function_exists('mb_substr')) $emergencyMessage = mb_substr($emergencyMessage, 0, 280, 'UTF-8');
        else $emergencyMessage = substr($emergencyMessage, 0, 280);

        $settings['emergency'] = [
            'enabled' => filter_var($emergency['enabled'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'primary_archive' => $emergencyPrimary,
            'external_mode' => $emergencyMode,
            'message' => $emergencyMessage,
        ];
        $settings['download_redirect_enabled'] = !array_key_exists('download_redirect_enabled', $settings)
            || filter_var($settings['download_redirect_enabled'], FILTER_VALIDATE_BOOLEAN);
        $settings['download_modern_client_only'] = !array_key_exists('download_modern_client_only', $settings)
            || filter_var($settings['download_modern_client_only'], FILTER_VALIDATE_BOOLEAN);
        $settings['archive_control_schema_version'] = max(8, (int)($settings['archive_control_schema_version'] ?? 0));

        $settings['blocked_items'] = bm_archive_normalize_blocked_items($settings['blocked_items'] ?? []);
        $settings['audience_schema_version'] = max(0, (int)($settings['audience_schema_version'] ?? 0));
        if (!isset($settings['updated_at'])) $settings['updated_at'] = null;
        return $settings;
    }
}

if (!function_exists('bm_archive_get_settings')) {
    function bm_archive_get_settings(): array {
        $settings = [];
        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) $paths[] = bm_archive_control_legacy_path();
        foreach (array_values(array_unique($paths)) as $path) {
            if (is_file($path)) {
                $raw = @file_get_contents($path);
                $json = is_string($raw) ? json_decode($raw, true) : null;
                if (is_array($json)) { $settings = $json; break; }
            }
        }

        // Audience schema migration.
        // v2 introduced Public/Admin. v3 adds Member/VIP while preserving every
        // existing administrator choice instead of resetting scopes.
        $audienceVersion = (int)($settings['audience_schema_version'] ?? 0);
        if ($audienceVersion < 2) {
            if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
            foreach (['archive1','archive2','archive3','archive4'] as $aid) {
                if (!isset($settings['archives'][$aid]) || !is_array($settings['archives'][$aid])) $settings['archives'][$aid] = [];
                $settings['archives'][$aid]['access_scope'] = 'public';
            }
        }
        if ($audienceVersion < 4) {
            $settings['audience_schema_version'] = 4;
        }
        // v5 corrects the earlier controller/content mix-up without touching
        // any administrator-defined download subdomain.
        if ($audienceVersion < 5) {
            foreach (['archive1','archive2','archive3','archive4'] as $aid) {
                if (!isset($settings['archives'][$aid]) || !is_array($settings['archives'][$aid])) continue;
                $bases = (array)($settings['archives'][$aid]['download_base_urls'] ?? []);
                foreach ($bases as &$base) {
                    $host = strtolower((string)(parse_url((string)$base, PHP_URL_HOST) ?: ''));
                    if (in_array($host, ['bankmoviee.ir','www.bankmoviee.ir'], true)) $base = 'https://dl10.bankmovie.top';
                }
                unset($base);
                $settings['archives'][$aid]['download_base_urls'] = array_values(array_unique($bases));
            }
            $settings['audience_schema_version'] = 5;
            $normalized = bm_archive_control_normalize($settings);
            @bm_archive_save_settings($normalized);
            return $normalized;
        }
        return bm_archive_control_normalize($settings);
    }
}

if (!function_exists('bm_archive_save_settings')) {
    function bm_archive_save_settings(array $settings): bool {
        $settings = bm_archive_control_normalize($settings);
        $settings['audience_schema_version'] = 5;
        $settings['archive_control_schema_version'] = 8;
        $settings['updated_at'] = date('c');
        $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;

        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) {
            $paths[] = bm_archive_control_legacy_path();
        }

        foreach (array_values(array_unique($paths)) as $path) {
            $dir = dirname($path);
            if (!is_dir($dir) && !@mkdir($dir, 0700, true)) continue;
            $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
            if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
                @unlink($tmp);
                continue;
            }
            @chmod($tmp, 0600);
            if (@rename($tmp, $path)) {
                @chmod($path, 0600);
                clearstatcache(true, $path);
                return true;
            }
            @unlink($tmp);
        }
        return false;
    }
}


if (!function_exists('bm_archive_known_ids')) {
    function bm_archive_known_ids(): array {
        return ['archive1','archive2','archive3','archive4'];
    }
}

if (!function_exists('bm_archive_order')) {
    function bm_archive_order(bool $effective = false): array {
        $settings = bm_archive_get_settings();
        $order = is_array($settings['archive_order'] ?? null) ? $settings['archive_order'] : bm_archive_known_ids();
        $clean = [];
        foreach ($order as $aid) {
            $aid = strtolower(trim((string)$aid));
            if (in_array($aid, bm_archive_known_ids(), true) && !in_array($aid, $clean, true)) $clean[] = $aid;
        }
        foreach (bm_archive_known_ids() as $aid) if (!in_array($aid, $clean, true)) $clean[] = $aid;

        if ($effective) {
            $em = bm_archive_emergency_settings();
            if (!empty($em['enabled'])) {
                $primary = (string)$em['primary_archive'];
                $clean = array_values(array_filter($clean, static fn($id) => $id !== $primary));
                array_unshift($clean, $primary);
            }
        }
        return $clean;
    }
}

if (!function_exists('bm_archive_emergency_settings')) {
    function bm_archive_emergency_settings(): array {
        $settings = bm_archive_get_settings();
        $em = is_array($settings['emergency'] ?? null) ? $settings['emergency'] : [];
        return [
            'enabled' => !empty($em['enabled']),
            'primary_archive' => in_array((string)($em['primary_archive'] ?? ''), bm_archive_known_ids(), true) ? (string)$em['primary_archive'] : 'archive2',
            'external_mode' => in_array((string)($em['external_mode'] ?? ''), ['hide','visible'], true) ? (string)$em['external_mode'] : 'hide',
            'message' => trim((string)($em['message'] ?? '')) ?: 'به‌دلیل محدودیت اینترنت، این آرشیو موقتاً در دسترس نیست.',
        ];
    }
}

if (!function_exists('bm_archive_configured_default_id')) {
    function bm_archive_configured_default_id(): string {
        $settings = bm_archive_get_settings();
        $id = strtolower(trim((string)($settings['default_archive'] ?? 'archive1')));
        return in_array($id, bm_archive_known_ids(), true) ? $id : 'archive1';
    }
}

if (!function_exists('bm_archive_fallback_id')) {
    function bm_archive_fallback_id(): string {
        $settings = bm_archive_get_settings();
        $id = strtolower(trim((string)($settings['fallback_archive'] ?? 'archive2')));
        return in_array($id, bm_archive_known_ids(), true) ? $id : 'archive2';
    }
}

if (!function_exists('bm_archive_mode_for_id')) {
    function bm_archive_mode_for_id(string $archiveId): string {
        return [
            'archive1'=>'arc1',
            'archive2'=>'local',
            'archive3'=>'arc3',
            'archive4'=>'arc4',
        ][$archiveId] ?? 'local';
    }
}

if (!function_exists('bm_archive_effective_default_id')) {
    function bm_archive_effective_default_id($user = null): string {
        $em = bm_archive_emergency_settings();
        if (!empty($em['enabled'])) {
            $primary = (string)$em['primary_archive'];
            if (bm_archive_user_can_access($primary, $user)) return $primary;
        }

        $candidates = array_values(array_unique(array_merge(
            [bm_archive_configured_default_id(), bm_archive_fallback_id()],
            bm_archive_order(true)
        )));
        foreach ($candidates as $id) {
            if (bm_archive_is_enabled($id) && bm_archive_should_render_tab($id)) return $id;
        }
        return 'archive2';
    }
}

if (!function_exists('bm_archive_get_config')) {
    function bm_archive_get_config(string $archiveId): array {
        $settings = bm_archive_get_settings();
        return $settings['archives'][$archiveId] ?? bm_archive_control_defaults()['archives'][$archiveId] ?? [];
    }
}

if (!function_exists('bm_archive_is_enabled')) {
    function bm_archive_is_enabled(string $archiveId): bool {
        $cfg = bm_archive_get_config($archiveId);
        $em = bm_archive_emergency_settings();
        if (!empty($em['enabled'])) {
            // Emergency is an overlay, so underlying admin choices are preserved.
            return $archiveId === (string)$em['primary_archive'];
        }
        return !empty($cfg['enabled']);
    }
}


if (!function_exists('bm_archive_section_config')) {
    function bm_archive_section_config(string $archiveId, string $sectionKey): array {
        $catalog = bm_archive_section_catalog_defaults($archiveId);
        if (!isset($catalog[$sectionKey])) return ['enabled'=>false, 'label'=>''];
        $cfg = bm_archive_get_config($archiveId);
        $row = isset($cfg['sections'][$sectionKey]) && is_array($cfg['sections'][$sectionKey]) ? $cfg['sections'][$sectionKey] : [];
        return [
            'enabled' => array_key_exists('enabled', $row) ? !empty($row['enabled']) : true,
            'label' => trim((string)($row['label'] ?? '')),
        ];
    }
}

if (!function_exists('bm_archive_section_enabled')) {
    function bm_archive_section_enabled(string $archiveId, string $sectionKey): bool {
        $cfg = bm_archive_section_config($archiveId, $sectionKey);
        return !empty($cfg['enabled']);
    }
}

if (!function_exists('bm_archive_section_label')) {
    function bm_archive_section_label(string $archiveId, string $sectionKey, string $fallback = ''): string {
        $cfg = bm_archive_section_config($archiveId, $sectionKey);
        $custom = trim((string)($cfg['label'] ?? ''));
        if ($custom !== '') return $custom;
        if (trim($fallback) !== '') return trim($fallback);
        $catalog = bm_archive_section_catalog_defaults($archiveId);
        return trim((string)($catalog[$sectionKey]['label'] ?? $sectionKey));
    }
}

if (!function_exists('bm_archive_user_is_admin')) {
    function bm_archive_user_is_admin($user = null): bool {
        if ($user === null && isset($GLOBALS['currentUser'])) $user = $GLOBALS['currentUser'];
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return in_array($role, ['admin', 'administrator'], true);
    }
}

/**
 * Professional archive audience gate.
 *
 * public = everybody
 * member = any signed-in account
 * vip    = active VIP + administrators
 * admin  = administrators only
 *
 * Unauthorized audiences are always hidden from UI render helpers and direct
 * API/detail requests are rejected by their existing bm_archive_user_can_access()
 * checks.
 */
if (!function_exists('bm_archive_access_scope')) {
    function bm_archive_access_scope(string $archiveId): string {
        $cfg = bm_archive_get_config($archiveId);
        $scope = strtolower(trim((string)($cfg['access_scope'] ?? 'public')));
        return in_array($scope, ['public','member','vip','admin'], true) ? $scope : 'public';
    }
}

if (!function_exists('bm_archive_resolve_user')) {
    function bm_archive_resolve_user($user = null): ?array {
        if ($user === null && isset($GLOBALS['currentUser']) && is_array($GLOBALS['currentUser'])) {
            $user = $GLOBALS['currentUser'];
        }
        return is_array($user) ? $user : null;
    }
}

if (!function_exists('bm_archive_user_is_member')) {
    function bm_archive_user_is_member($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;
        if (!empty($user['id'])) return true;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return $role !== '' && !in_array($role, ['guest','anonymous'], true);
    }
}

if (!function_exists('bm_archive_user_is_vip')) {
    function bm_archive_user_is_vip($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;

        if (function_exists('bm_vip_user_is_active')) {
            return bm_vip_user_is_active($user);
        }

        // Defensive fallback if VIP helper is unavailable on an unusual route.
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}

if (!function_exists('bm_archive_user_can_access')) {
    function bm_archive_user_can_access(string $archiveId, $user = null): bool {
        $scope = bm_archive_access_scope($archiveId);
        return bm_archive_scope_allows($scope, $user);
    }
}

if (!function_exists('bm_archive_vip_gate_locked')) {
    function bm_archive_vip_gate_locked(string $archiveId, $user = null): bool {
        if (!bm_archive_is_enabled($archiveId)) return false;
        return bm_archive_access_scope($archiveId) === 'vip' && !bm_archive_user_can_access($archiveId, $user);
    }
}

if (!function_exists('bm_archive_scope_allows')) {
    function bm_archive_scope_allows(string $scope, $user = null): bool {
        $scope = strtolower(trim($scope));
        if ($scope === 'public') return true;
        if ($scope === 'member') return bm_archive_user_is_member($user);
        if ($scope === 'vip') return bm_archive_user_is_vip($user);
        if ($scope === 'admin') return bm_archive_user_is_admin(bm_archive_resolve_user($user));
        return false;
    }
}


if (!function_exists('bm_archive_player_gate_mode')) {
    function bm_archive_player_gate_mode(string $archiveId, string $gate): string {
        $cfg = bm_archive_get_config($archiveId);
        $gate = strtolower(trim($gate));
        $aliases = [
            'online_watch'=>'master',
            'master'=>'master',
            'internal_player'=>'internal',
            'internal'=>'internal',
            'external_players'=>'external',
            'external'=>'external',
            'player_copy_link'=>'copy_link',
            'copy'=>'copy_link',
            'copy_link'=>'copy_link',
        ];
        $key = $aliases[$gate] ?? '';
        if ($key === '') return 'inherit';
        $gates = is_array($cfg['player_gates'] ?? null) ? $cfg['player_gates'] : [];
        $mode = strtolower(trim((string)($gates[$key] ?? 'inherit')));
        return in_array($mode, ['inherit','free','vip'], true) ? $mode : 'inherit';
    }
}

if (!function_exists('bm_archive_player_gate_feature')) {
    function bm_archive_player_gate_feature(string $gate): string {
        $gate = strtolower(trim($gate));
        return [
            'master'=>'online_watch',
            'online_watch'=>'online_watch',
            'internal'=>'internal_player',
            'internal_player'=>'internal_player',
            'external'=>'external_players',
            'external_players'=>'external_players',
            'copy'=>'player_copy_link',
            'copy_link'=>'player_copy_link',
            'player_copy_link'=>'player_copy_link',
        ][$gate] ?? '';
    }
}

if (!function_exists('bm_archive_player_gate_locked')) {
    /**
     * Effective VIP lock for a specific archive/player action.
     *
     * inherit = use the current global VIP feature switch.
     * free    = explicitly bypass that global player gate for this archive.
     * vip     = force this player action to VIP for this archive.
     *
     * This never bypasses archive access_scope / stream_access_scope rules.
     */
    function bm_archive_player_gate_locked(string $archiveId, string $gate, $user = null): bool {
        $mode = bm_archive_player_gate_mode($archiveId, $gate);
        if ($mode === 'free') return false;
        if ($mode === 'vip') return !bm_archive_user_is_vip($user);

        $feature = bm_archive_player_gate_feature($gate);
        if ($feature === '' || !function_exists('bm_vip_gate_allows')) return false;
        $resolved = bm_archive_resolve_user($user);
        return !bm_vip_gate_allows($feature, is_array($resolved) ? $resolved : null);
    }
}

if (!function_exists('bm_archive_player_gates_public')) {
    function bm_archive_player_gates_public(string $archiveId): array {
        $out = [];
        foreach (['master','internal','external','copy_link'] as $gate) {
            $out[$gate] = bm_archive_player_gate_mode($archiveId, $gate);
        }
        return $out;
    }
}


if (!function_exists('bm_archive_download_redirect_enabled')) {
    function bm_archive_download_redirect_enabled(): bool {
        $settings = bm_archive_get_settings();
        return !array_key_exists('download_redirect_enabled', $settings) || !empty($settings['download_redirect_enabled']);
    }
}

if (!function_exists('bm_archive_download_modern_client_only')) {
    function bm_archive_download_modern_client_only(): bool {
        $settings = bm_archive_get_settings();
        return !array_key_exists('download_modern_client_only', $settings) || !empty($settings['download_modern_client_only']);
    }
}

if (!function_exists('bm_archive_request_is_modern_download_client')) {
    function bm_archive_request_is_modern_download_client(): bool {
        $raw = trim((string)($_SERVER['HTTP_X_BM_DOWNLOAD_SYSTEM'] ?? ''));
        return $raw !== '' && ctype_digit($raw) && (int)$raw >= 2;
    }
}

if (!function_exists('bm_archive_download_link_mode')) {
    function bm_archive_download_link_mode(string $archiveId, ?bool $modernClient = null): string {
        if (!bm_archive_download_redirect_enabled()) return 'original';
        if ($modernClient === false && bm_archive_download_modern_client_only()) return 'original';
        $cfg = bm_archive_get_config($archiveId);
        $mode = strtolower(trim((string)($cfg['download_link_mode'] ?? 'redirect')));
        return in_array($mode, ['redirect','original','disabled'], true) ? $mode : 'redirect';
    }
}

if (!function_exists('bm_archive_download_client_mode')) {
    function bm_archive_download_client_mode(string $archiveId, ?bool $modernClient = null): string {
        if (!bm_archive_download_redirect_enabled()) return 'all';
        if ($modernClient === false && bm_archive_download_modern_client_only()) return 'all';
        $cfg = bm_archive_get_config($archiveId);
        $mode = strtolower(trim((string)($cfg['download_client_mode'] ?? 'adm_copy')));
        return in_array($mode, ['adm_copy','all','disabled'], true) ? $mode : 'adm_copy';
    }
}

if (!function_exists('bm_archive_feature_scope')) {
    function bm_archive_feature_scope(string $archiveId, string $feature): string {
        $cfg = bm_archive_get_config($archiveId);
        $key = $feature === 'stream' ? 'stream_access_scope' : 'download_access_scope';
        $scope = strtolower(trim((string)($cfg[$key] ?? 'public')));
        return in_array($scope, ['public','member','vip','admin','disabled'], true) ? $scope : 'public';
    }
}

if (!function_exists('bm_archive_feature_user_can_access')) {
    function bm_archive_feature_user_can_access(string $archiveId, string $feature, $user = null): bool {
        if (!bm_archive_is_enabled($archiveId) || !bm_archive_user_can_access($archiveId, $user)) return false;
        if ($feature === 'download') {
            if (bm_archive_download_link_mode($archiveId) === 'disabled' || bm_archive_download_client_mode($archiveId) === 'disabled') return false;
        }
        return bm_archive_scope_allows(bm_archive_feature_scope($archiveId, $feature), $user);
    }
}

if (!function_exists('bm_archive_source_base_url')) {
    function bm_archive_source_base_url(string $archiveId, string $fallback = ''): string {
        $cfg = bm_archive_get_config($archiveId);
        $url = bm_archive_normalize_base_url($cfg['source_base_url'] ?? '', true);
        return $url !== '' ? $url : rtrim($fallback, '/');
    }
}

if (!function_exists('bm_archive_download_base_urls')) {
    function bm_archive_download_base_urls(string $archiveId): array {
        $cfg = bm_archive_get_config($archiveId);
        return bm_archive_normalize_url_list($cfg['download_base_urls'] ?? [], ['https://dl10.bankmovie.top']);
    }
}

if (!function_exists('bm_archive_pick_download_base_url')) {
    function bm_archive_pick_download_base_url(string $archiveId, string $seed = ''): string {
        $urls = bm_archive_download_base_urls($archiveId);
        if (count($urls) === 1) return $urls[0];
        $hash = hash('sha256', $archiveId . '|' . $seed, true);
        return $urls[ord($hash[0]) % count($urls)];
    }
}

if (!function_exists('bm_archive_content_identity')) {
    function bm_archive_content_identity(array $data = [], array $context = []): array {
        $identifiers = [];
        $urls = [];
        $titles = [];
        $sources = [$context, $data];
        foreach (['data','item','movie','detail'] as $containerKey) {
            if (isset($data[$containerKey]) && is_array($data[$containerKey]) && !array_is_list($data[$containerKey])) {
                $sources[] = $data[$containerKey];
            }
        }
        foreach ($sources as $source) {
            foreach (['identifier','id','movie_id','imdb_code','imdb_id','imdb','slug','source_id','post_id','detail_id'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') $identifiers[] = $value;
                if ($key === 'movie_id' && $value !== '') $identifiers[] = 'movie_id:' . $value;
            }
            foreach (['source_url','detail_url','item_link','url'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') {
                    $urls[] = $value;
                    $path = trim((string)(parse_url((string)$source[$key], PHP_URL_PATH) ?: ''), '/');
                    if ($path !== '') {
                        $segments = array_values(array_filter(explode('/', $path), 'strlen'));
                        if ($segments) $identifiers[] = bm_archive_normalize_identifier((string)end($segments));
                    }
                }
            }
            foreach (['title','title_fa','name','name_fa','full_title'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') $titles[] = $value;
            }
        }
        $year = '';
        foreach ($sources as $source) {
            foreach ([$source['year'] ?? null, $source['release_year'] ?? null] as $candidate) {
                if (preg_match('/^(?:19|20)\d{2}$/', trim((string)$candidate))) { $year = trim((string)$candidate); break 2; }
            }
        }
        return [
            'identifiers' => array_values(array_unique($identifiers)),
            'urls' => array_values(array_unique($urls)),
            'titles' => array_values(array_unique($titles)),
            'year' => $year,
        ];
    }
}

if (!function_exists('bm_archive_find_blocked_item')) {
    function bm_archive_find_blocked_item(string $archiveId, array $data = [], array $context = []): ?array {
        $identity = bm_archive_content_identity($data, $context);
        $settings = bm_archive_get_settings();
        foreach ($settings['blocked_items'] ?? [] as $rule) {
            if (!is_array($rule) || ($rule['archive_id'] ?? '') !== $archiveId) continue;
            if (empty($rule['block_media']) && empty($rule['block_downloads']) && empty($rule['block_streams'])) continue;
            $ruleIdentifier = bm_archive_normalize_identifier($rule['identifier'] ?? '');
            $ruleUrl = bm_archive_normalize_identifier($rule['source_url'] ?? '');
            $ruleTitle = bm_archive_normalize_identifier($rule['title'] ?? '');
            if ($ruleIdentifier !== '' && in_array($ruleIdentifier, $identity['identifiers'], true)) return $rule;
            if ($ruleUrl !== '' && in_array($ruleUrl, $identity['urls'], true)) return $rule;
            if ($ruleTitle !== '' && in_array($ruleTitle, $identity['titles'], true)) {
                $ruleYear = trim((string)($rule['year'] ?? ''));
                if ($ruleYear === '' || ($identity['year'] !== '' && $ruleYear === $identity['year'])) return $rule;
            }
        }
        return null;
    }
}

if (!function_exists('bm_archive_item_downloads_blocked')) {
    function bm_archive_item_downloads_blocked(string $archiveId, array $data = [], array $context = []): bool {
        return bm_archive_find_blocked_item($archiveId, $data, $context) !== null;
    }
}

if (!function_exists('bm_archive_item_media_blocked')) {
    function bm_archive_item_media_blocked(string $archiveId, array $data = [], array $context = []): bool {
        return bm_archive_find_blocked_item($archiveId, $data, $context) !== null;
    }
}

if (!function_exists('bm_archive_strip_download_payload')) {
    function bm_archive_strip_download_payload($value) {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) {
            foreach ($value as $i => $item) $value[$i] = bm_archive_strip_download_payload($item);
            return $value;
        }
        // Do not remove media rows: the same rows are also the source of online
        // playback. Remove only download capabilities and keep stream_url/url.
        $direct = ['dub_link','soft_link','download_url','download_link','subtitle_download_url','href'];
        foreach ($value as $key => $item) {
            if (in_array((string)$key, $direct, true)) {
                unset($value[$key]);
            } elseif (is_array($item)) {
                $value[$key] = bm_archive_strip_download_payload($item);
            }
        }
        if (array_key_exists('downloads_count', $value)) $value['downloads_count'] = 0;
        if (array_key_exists('has_downloads', $value)) $value['has_downloads'] = false;
        if (array_key_exists('is_download', $value)) $value['is_download'] = false;
        if (array_key_exists('download_allowed', $value)) $value['download_allowed'] = false;
        return $value;
    }
}

if (!function_exists('bm_archive_strip_stream_payload')) {
    function bm_archive_strip_stream_payload($value) {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) {
            $out = [];
            foreach ($value as $item) {
                if (is_array($item) && strtolower(trim((string)($item['media_type'] ?? ''))) === 'stream') continue;
                $out[] = bm_archive_strip_stream_payload($item);
            }
            return $out;
        }
        $looksLikeMedia = array_key_exists('download_url', $value)
            || array_key_exists('media_type', $value)
            || array_key_exists('quality', $value)
            || array_key_exists('season', $value)
            || array_key_exists('episode', $value)
            || array_key_exists('is_download', $value);
        foreach ($value as $key => $item) {
            if (in_array((string)$key, ['play','play_links','stream_url','watch_url','play_url','online_url'], true)) {
                if ((string)$key === 'stream_url') unset($value[$key]);
                else $value[$key] = is_array($item) ? [] : null;
            } elseif ((string)$key === 'url' && $looksLikeMedia) {
                unset($value[$key]);
            } elseif (is_array($item)) {
                $value[$key] = bm_archive_strip_stream_payload($item);
            }
        }
        if (array_key_exists('has_online', $value)) $value['has_online'] = false;
        if (array_key_exists('playonline', $value)) $value['playonline'] = false;
        if (array_key_exists('stream_allowed', $value)) $value['stream_allowed'] = false;
        return $value;
    }
}

if (!function_exists('bm_archive_apply_payload_policy')) {
    function bm_archive_apply_payload_policy(string $archiveId, $payload, $user = null, array $context = []) {
        if (!is_array($payload)) return $payload;
        $isListPayload = array_is_list($payload);
        $downloadScope = bm_archive_feature_scope($archiveId, 'download');
        $streamScope = bm_archive_feature_scope($archiveId, 'stream');
        $itemMediaBlocked = bm_archive_item_media_blocked($archiveId, $payload, $context);
        $downloadAllowed = bm_archive_feature_user_can_access($archiveId, 'download', $user)
            && !$itemMediaBlocked;
        $streamAllowed = bm_archive_feature_user_can_access($archiveId, 'stream', $user)
            && !$itemMediaBlocked;
        if (!$downloadAllowed) $payload = bm_archive_strip_download_payload($payload);
        if (!$streamAllowed) $payload = bm_archive_strip_stream_payload($payload);
        if (!$isListPayload) {
            $policy = [
                'download_access_scope' => $downloadScope,
                'stream_access_scope' => $streamScope,
            ];
            $payload['archive_policy'] = $policy;
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['archive_policy'] = $policy;
                    $payload[$detailKey]['download_access_scope'] = $downloadScope;
                    $payload[$detailKey]['stream_access_scope'] = $streamScope;
                }
            }
        }
        if (!$isListPayload && !$downloadAllowed) {
            $payload['downloads_locked'] = true;
            $payload['download_message'] = $itemMediaBlocked
                ? 'لینک‌های دانلود این عنوان توسط مدیریت بسته شده است.'
                : ($downloadScope === 'vip'
                    ? 'دانلود این آرشیو ویژه اعضای VIP است.'
                    : 'لینک‌های دانلود این عنوان در دسترس نیست.');
            if ($downloadScope === 'vip') $payload['download_gate'] = 'vip';
            // Detail responses are usually wrapped in {item: ...}. Mirror the
            // policy marker into the actual item because native clients render
            // that object and deliberately ignore envelope-only metadata.
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['downloads_locked'] = true;
                    $payload[$detailKey]['download_message'] = $payload['download_message'];
                    if ($downloadScope === 'vip') $payload[$detailKey]['download_gate'] = 'vip';
                }
            }
        }
        if (!$isListPayload && !$streamAllowed) {
            $payload['stream_locked'] = true;
            $payload['stream_message'] = $itemMediaBlocked
                ? 'پخش آنلاین این عنوان توسط مدیریت بسته شده است.'
                : ($streamScope === 'vip'
                    ? 'پخش آنلاین این آرشیو ویژه اعضای VIP است.'
                    : 'پخش آنلاین این آرشیو برای حساب شما فعال نیست.');
            if ($streamScope === 'vip') $payload['stream_gate'] = 'vip';
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['stream_locked'] = true;
                    $payload[$detailKey]['stream_message'] = $payload['stream_message'];
                    if ($streamScope === 'vip') $payload[$detailKey]['stream_gate'] = 'vip';
                }
            }
        }
        if (!$isListPayload && $itemMediaBlocked) {
            $payload['item_media_locked'] = true;
            $payload['media_lock_reason'] = 'admin_item_block';
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['item_media_locked'] = true;
                    $payload[$detailKey]['media_lock_reason'] = 'admin_item_block';
                }
            }
        }
        return $payload;
    }
}

if (!function_exists('bm_archive_access_scope_label')) {
    function bm_archive_access_scope_label(string $archiveId): string {
        $scope = bm_archive_access_scope($archiveId);
        return [
            'public' => 'همه کاربران',
            'member' => 'فقط کاربران واردشده',
            'vip' => 'فقط VIP فعال',
            'admin' => 'فقط مدیر',
        ][$scope] ?? 'همه کاربران';
    }
}

if (!function_exists('bm_archive_should_render_tab')) {
    function bm_archive_should_render_tab(string $archiveId): bool {
        $em = bm_archive_emergency_settings();
        if (!empty($em['enabled']) && $archiveId !== (string)$em['primary_archive']) {
            if (($em['external_mode'] ?? 'hide') === 'hide') return false;
            return bm_archive_user_can_access($archiveId);
        }

        // VIP-only archives stay visible as an upsell entry for non-VIP users.
        // Direct/API access is still denied by bm_archive_user_can_access().
        if (bm_archive_vip_gate_locked($archiveId)) return true;
        if (!bm_archive_user_can_access($archiveId)) return false;
        $cfg = bm_archive_get_config($archiveId);
        return !empty($cfg['enabled']) || (($cfg['disabled_mode'] ?? 'visible') !== 'hide');
    }
}

if (!function_exists('bm_archive_disabled_message')) {
    function bm_archive_disabled_message(string $archiveId): string {
        $em = bm_archive_emergency_settings();
        if (!empty($em['enabled']) && $archiveId !== (string)$em['primary_archive']) {
            return (string)$em['message'];
        }
        $cfg = bm_archive_get_config($archiveId);
        return trim((string)($cfg['disabled_message'] ?? 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.'));
    }
}

if (!function_exists('bm_archive_label')) {
    function bm_archive_label(string $archiveId, string $fallback = ''): string {
        $cfg = bm_archive_get_config($archiveId);
        $label = trim((string)($cfg['label'] ?? ''));
        return $label !== '' ? $label : $fallback;
    }
}

if (!function_exists('bm_archive_public_config')) {
    function bm_archive_public_config(): array {
        $settings = bm_archive_get_settings();
        $out = [];
        foreach (bm_archive_order(true) as $id) {
            $cfg = is_array($settings['archives'][$id] ?? null) ? $settings['archives'][$id] : [];
            $canAccess = bm_archive_user_can_access((string)$id);
            $enabled = bm_archive_is_enabled((string)$id);
            $out[$id] = [
                'label' => (string)($cfg['label'] ?? ''),
                'enabled' => $canAccess && $enabled,
                'access_scope' => (string)($cfg['access_scope'] ?? 'public'),
                'download_access_scope' => (string)($cfg['download_access_scope'] ?? 'public'),
                'stream_access_scope' => (string)($cfg['stream_access_scope'] ?? 'public'),
                'download_link_mode' => bm_archive_download_link_mode((string)$id),
                'download_client_mode' => bm_archive_download_client_mode((string)$id),
                'player_gates' => bm_archive_player_gates_public((string)$id),
                'downloads_allowed' => $canAccess && bm_archive_feature_user_can_access((string)$id, 'download'),
                'stream_allowed' => $canAccess && bm_archive_feature_user_can_access((string)$id, 'stream'),
                'disabled_mode' => (string)($cfg['disabled_mode'] ?? 'visible'),
                'disabled_message' => bm_archive_disabled_message((string)$id),
                'render_tab' => bm_archive_should_render_tab((string)$id),
                'preview_admin_only' => (($cfg['access_scope'] ?? 'public') === 'admin'),
                'preview_vip_only' => (($cfg['access_scope'] ?? 'public') === 'vip'),
                'preview_members_only' => (($cfg['access_scope'] ?? 'public') === 'member'),
                'access_scope_label' => function_exists('bm_archive_access_scope_label') ? bm_archive_access_scope_label((string)$id) : (string)($cfg['access_scope'] ?? 'public'),
            ];
        }
        return $out;
    }
}

if (!function_exists('bm_archive_default_mode')) {
    function bm_archive_default_mode(): string {
        return bm_archive_mode_for_id(bm_archive_effective_default_id());
    }
}

if (!function_exists('bm_archive_cookie_file')) {
    function bm_archive_cookie_file(string $archiveId): ?string {
        if ($archiveId !== 'archive4') return null;
        $name = 'api4_cookie.txt';
        if (function_exists('bm_security_private_path')) return bm_security_private_path($name);
        return dirname(__DIR__) . '/' . $name;
    }
}

if (!function_exists('bm_archive_cookie_legacy_file')) {
    function bm_archive_cookie_legacy_file(string $archiveId): ?string {
        if ($archiveId === 'archive4') return dirname(__DIR__) . '/api4_cookie.txt';
        return null;
    }
}

if (!function_exists('bm_archive_cookie_status')) {
    function bm_archive_cookie_status(string $archiveId): array {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return ['supported'=>false, 'exists'=>false, 'bytes'=>0, 'updated'=>null, 'preview'=>'', 'storage'=>'none'];
        $readFile = $file;
        $exists = is_file($readFile);
        $raw = $exists ? (string)@file_get_contents($readFile) : '';
        $raw = trim($raw);
        $preview = '';
        if ($raw !== '') $preview = substr($raw, 0, 28) . '••••' . substr($raw, -16);
        return [
            'supported'=>true,
            'exists'=>$exists,
            'bytes'=>strlen($raw),
            'updated'=>$exists ? @date('Y-m-d H:i:s', (int)@filemtime($readFile)) : null,
            'preview'=>$preview,
            'storage'=>($readFile === $file ? 'private' : 'legacy'),
        ];
    }
}

if (!function_exists('bm_archive_write_cookie')) {
    function bm_archive_write_cookie(string $archiveId, string $cookie): bool {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return false;
        $cookie = function_exists('bm_security_normalize_cookie') ? bm_security_normalize_cookie($cookie) : trim($cookie);
        if ($cookie === '') return false;
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $ok = (bool)@file_put_contents($file, $cookie . PHP_EOL, LOCK_EX);
        if ($ok) @chmod($file, 0600);
        return $ok;
    }
}

if (!function_exists('bm_archive_clear_cookie')) {
    function bm_archive_clear_cookie(string $archiveId): bool {
        $ok = false;
        foreach ([bm_archive_cookie_file($archiveId), function_exists('bm_archive_cookie_legacy_file') ? bm_archive_cookie_legacy_file($archiveId) : null] as $file) {
            if (!$file) continue;
            $dir = dirname($file);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $ok = (bool)@file_put_contents($file, '', LOCK_EX) || $ok;
            if (is_file($file)) @chmod($file, 0600);
        }
        return $ok;
    }
}
