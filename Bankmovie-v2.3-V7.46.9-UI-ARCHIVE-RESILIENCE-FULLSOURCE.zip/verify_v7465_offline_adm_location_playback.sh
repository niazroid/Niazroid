#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
OFFLINE="$ROOT/app/src/main/java/ir/bankmoviee/app/OfflineLibraryActivity.kt"
PLAYER="$ROOT/app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt"
ICON="$ROOT/app/src/main/res/drawable/ic_offline_gallery.xml"
WORKFLOW="$ROOT/.github/workflows/build-bankmovie.yml"

need() { grep -Fq -- "$2" "$1" || { echo "VERIFY_V7465_MISSING: $2 in $1" >&2; exit 1; }; }
forbid_block() {
  python3 - "$1" "$2" "$3" <<'PY'
from pathlib import Path
import re,sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
m=re.search(sys.argv[2],s,re.S)
if not m: raise SystemExit('VERIFY_V7465_BLOCK_MISSING')
if sys.argv[3] in m.group(0): raise SystemExit('VERIFY_V7465_FORBIDDEN_IN_BLOCK:'+sys.argv[3])
PY
}

# Offline entry must be local, always available and before Telegram on boot failure.
need "$MAIN" 'offlineLibraryEmergencyButton()'
need "$MAIN" 'R.drawable.ic_offline_gallery'
need "$MAIN" 'page.addView(offlineLibraryEmergencyButton()'
python3 - "$MAIN" <<'PY'
from pathlib import Path
import re,sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
m=re.search(r'private fun showNetworkError\(message: String\) \{(.*?)\n    \}\n\n    private fun offlineLibraryEmergencyButton',s,re.S)
if not m: raise SystemExit('VERIFY_V7465_NETWORK_ERROR_BLOCK_MISSING')
b=m.group(1)
if b.find('offlineLibraryEmergencyButton()') < 0 or b.find('telegramJoinButton()') < 0: raise SystemExit('VERIFY_V7465_NETWORK_ACTIONS_MISSING')
if b.find('offlineLibraryEmergencyButton()') > b.find('telegramJoinButton()'): raise SystemExit('VERIFY_V7465_OFFLINE_MUST_PRECEDE_TELEGRAM')
PY
need "$ICON" 'M17,11V2M17,11L20,8M17,11L14,8'
need "$MAIN" 'local/offline access is shown before the online help/Telegram actions'

# ADM must resolve a concrete non-browser component and never launch a chooser/view fallback.
need "$MAIN" 'packageManager.queryIntentActivities(base, 0)'
need "$MAIN" 'android.content.ComponentName'
need "$MAIN" 'activity.contains("browser")'
need "$MAIN" 'label.contains("مرورگر")'
forbid_block "$MAIN" 'private fun openAdmOnly\(url: String\) \{.*?\n    \}' 'Intent.createChooser'
forbid_block "$MAIN" 'private fun openAdmOnly\(url: String\) \{.*?\n    \}' 'Intent.ACTION_VIEW'

# First internal download location must be selected before navigating to DownloadsActivity.
need "$MAIN" 'pendingDownloadOpenDownloads'
need "$MAIN" 'openDownloadsAfterStart: Boolean = false'
need "$MAIN" 'startInternalDownload(item, link, openDownloadsAfterStart = true)'
need "$MAIN" 'if (openDownloadsAfterStart) {'
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
old='dialog.dismiss(); startInternalDownload(item, link); startActivity(Intent(this, DownloadsActivity::class.java))'
if old in s: raise SystemExit('VERIFY_V7465_OLD_PREMATURE_DOWNLOADS_NAV_PRESENT')
PY

# Offline playback: app files use local path, SAF uses a retained FD into LibVLC.
need "$OFFLINE" 'offlinePlaybackSource'
need "$OFFLINE" 'file.takeIf { it.isFile && it.length() > 0L }?.absolutePath'
need "$PLAYER" 'private var activeMediaFd: ParcelFileDescriptor? = null'
need "$PLAYER" 'contentResolver.openFileDescriptor(uri, "r")'
need "$PLAYER" 'Media(lib, pfd.fileDescriptor)'
need "$PLAYER" 'Media(lib, value)'
need "$PLAYER" 'runCatching { oldFd?.close() }'

# Preserve the complete prior release safety checks.
bash "$ROOT/verify_v7464_internal_offline_home500_legacy_safe.sh"

echo VERIFY_V7465_OFFLINE_ADM_LOCATION_PLAYBACK_OK
