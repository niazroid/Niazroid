# GohstVpn 0.5 – home dashboard and subscription refresh

- On the home connect card show the actual selected node, country inferred from the name/flag, and a **measured** ping. Missing metadata is not guessed.
- Retest the connected node every 30 seconds while the home dashboard is visible; stale readings are cleared before each test. Failed requests display Timeout rather than a fabricated latency.
- Live download/upload meters now share the connect card.
- When the app finishes bootstrapping Mihomo it refreshes enabled remote subscriptions, then tests the active selector group. On meaningful foreground return it refreshes again (10-second anti-duplicate guard). While the app process remains running, subscriptions get hourly checks. Offline or stopped Android processes cannot guarantee exact scheduling.
- A small vector SVG refresh control requests the current subscription update manually, without confusing favorites with refresh.
- Remaining data, days left, and usage bar animate from real subscription metadata; unknown fields remain unknown.

**Building:** Upload GohstVpn-v0.5.0-update.zip alongside original v0.1 and v0.2-v0.4 updates. Replace .github/workflows/gohstvpn-android.yml with gohstvpn-android-V9-dashboard.yml and run a new workflow.

**Validation:** archive integrity, YAML syntax, source merge, and SVG XML can be checked offline. Full Dart analysis, Android build, phone connectivity, network timing and widget behavior still require GitHub Actions / device testing. No APK included.
