#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path

root = Path('.')
main = root / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
s = main.read_text(encoding='utf-8')
assets = root / 'app/src/main/res/drawable-nodpi'
site_art = root / 'app/src/main/assets/site-home-art'

def require(condition, message):
    if not condition:
        raise SystemExit(f'::error::V2.4 original-site-art verification: {message}')

# The V5 app uses bm_site_neon_* drawable resources, NOT bm_home_* resource
# identifiers. bm_home_* SVGs are retained as original reference assets.
site_drawables = {
    'bm_site_neon_movie': '.webp',
    'bm_site_neon_series': '.webp',
    'bm_site_neon_collections': '.png',
    'bm_site_neon_anime': '.png',
    'bm_site_neon_animation': '.png',
    'bm_site_neon_turkey': '.png',
    'bm_site_neon_korea': '.png',
    'bm_site_neon_dub': '.png',
    'bm_site_neon_top': '.png',
}
for resource, extension in site_drawables.items():
    art_file = assets / f'{resource}{extension}'
    require(art_file.is_file() and art_file.stat().st_size > 100,
            f'missing actual site artwork: {art_file}')
    content = art_file.read_bytes()
    if extension == '.png':
        require(content.startswith(b'\x89PNG\r\n\x1a\n'), f'invalid PNG: {art_file}')
    else:
        require(content[:4] == b'RIFF' and content[8:12] == b'WEBP', f'invalid WebP: {art_file}')
    require(f'R.drawable.{resource}' in s,
            f'home section does not reference site artwork resource {resource}')

for original in ('bm_home_updated_movies', 'bm_home_updated_series',
                 'bm_home_anime_art', 'bm_home_turkey'):
    svg = site_art / f'{original}.svg'
    require(svg.is_file() and svg.stat().st_size > 100,
            f'missing original SVG reference: {svg}')

# Verify the real home title mapping and preserve TV focus.
require('private fun legacyTvSectionHeader' in s and
        'if (isTvLike()) return legacyTvSectionHeader' in s,
        'legacy TV header/focus preserved check failed')
require('val artRes = when {' in s and 'setImageResource(artRes)' in s,
        'site artwork is not wired into the mobile home section header')

# User avatar and VIP crown are native, with fallback for no account.
for marker in ('configuredAvatar', 'profileAvatarView', 'navVip', 'bindAccountAvatar'):
    require(marker in s, f'missing profile avatar behavior: {marker}')

# V5 uses a 518dp poster-mode hero and a *separate* 16dp opaque spacer
# before ratings; the obsolete V4 verifier incorrectly expected 139dp.
for marker in ('forcePosterHero', 'heroImg.visibility = View.GONE',
               'hero.addView(heroPosterShell', 'hero.addView(playOrb',
               'page.addView(hero)', 'LinearLayout.LayoutParams(-1, dp(16))',
               'bankRatingStrip(item)'):
    require(marker in s, f'missing portrait/no-backdrop detail layout: {marker}')
detail = s[s.index('private fun renderDetail(page: LinearLayout, item: JSONObject)'):]
poster_index = detail.index('hero.addView(heroPosterShell')
play_index = detail.index('hero.addView(playOrb')
hero_end_index = detail.index('page.addView(hero)')
rating_index = detail.index('bankRatingStrip(item)')
require(poster_index < play_index < hero_end_index < rating_index,
        'portrait/play/status/IMDb are out of their independent draw order')

for marker in ('background = neumorphicSurface(18)',
               'marginEnd = dp(12)', 'clipToOutline = true'):
    require(marker in s, f'missing Discover visual detail: {marker}')
start = s.index('private fun showDiscover()')
end = s.index('private fun showCategories()', start)
discover = s[start:end]
require('android.webkit.WebView(this)' not in discover and
        'WebView(this)' not in discover,
        'Discover unexpectedly uses a WebView')

build_gradle = (root / 'app/build.gradle').read_text(encoding='utf-8')
require('versionName "2.4"' in build_gradle, 'unexpected versionName')
require("applicationId 'ir.bankmoviee.app'" in build_gradle,
        'applicationId changed; existing app updates would break')
print('VERIFY_V24_NEUMORPH_AVATAR_HOME_DETAIL_OK')
PY
