#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$MAIN" && -f "$WF" ]] || { echo VERIFY_V7471_9_FILES_MISSING; exit 1; }
# Box Office TV must now use the same mobile visual structure instead of the old purple summary/list UI.
grep -Fq 'val pink = Color.rgb(255, 63, 133)' "$MAIN"
grep -Fq 'Top-grossing movies worldwide' "$MAIN"
grep -Fq 'text = rank.toString().padStart(2, '\''0'\'')' "$MAIN"
grep -Fq 'Weeks in theaters:' "$MAIN"
grep -Fq 'Weekend gross:' "$MAIN"
grep -Fq 'Total gross:' "$MAIN"
grep -Fq 'tag = "bm_v68_boxoffice_item_$index"' "$MAIN"
# Profile adopts actor/person hero: blurred avatar backdrop + black fade + dark icon surfaces.
grep -Fq 'V7.47.1.9: Profile adopts the same person-hero language as Actor pages' "$MAIN"
grep -Fq 'createBlurEffect(18f, 18f' "$MAIN"
grep -Fq 'createBlurEffect(20f, 20f' "$MAIN"
grep -Fq 'private fun accountProfileCard(): View' "$MAIN"
grep -Fq 'Color.rgb(3, 7, 14)' "$MAIN"
grep -Fq 'shape = GradientDrawable.OVAL' "$MAIN"
# Previous TV drawer click/focus fixes must remain intact.
bash verify_v7471_7_tv_drawer_offline_focus.sh
bash verify_v7471_8_tv_drawer_click_bridge.sh
grep -Fq 'V7.47.1.9-BOXOFFICE-PROFILE-UNIFIED-UI-FULLSOURCE.zip' "$WF"
grep -Fq 'verify_v7471_9_boxoffice_profile_unified_ui.sh' "$WF"
echo VERIFY_V7471_9_BOXOFFICE_PROFILE_UNIFIED_UI_OK
