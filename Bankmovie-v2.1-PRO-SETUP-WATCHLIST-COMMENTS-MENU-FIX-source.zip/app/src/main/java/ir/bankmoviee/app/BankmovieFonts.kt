package ir.bankmoviee.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

object BankmovieFonts {
    private var cached: Typeface? = null

    private fun irancell(context: Context): Typeface {
        cached?.let { return it }
        return runCatching {
            val downloaded = java.io.File(context.filesDir, "fonts/irancell_regular.ttf")
            if (downloaded.isFile && downloaded.length() > 1024L) Typeface.createFromFile(downloaded)
            else Typeface.createFromAsset(context.assets, "fonts/irancell_regular.ttf")
        }.getOrElse {
            // Visible Persian-friendly fallback. The build workflow restores the
            // private Irancell asset from any earlier embedded source when present.
            Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        }.also { cached = it }
    }

    // یک فایل فونت داخلی برای تمام وزن‌ها استفاده می‌شود تا Build به فایل خارجی وابسته نباشد.
    fun regular(context: Context): Typeface = irancell(context)
    fun medium(context: Context): Typeface = irancell(context)
    fun semiBold(context: Context): Typeface = irancell(context)
    fun bold(context: Context): Typeface = Typeface.create(irancell(context), Typeface.BOLD)
    fun black(context: Context): Typeface = Typeface.create(irancell(context), Typeface.BOLD)

    fun applyToTree(context: Context, view: View) {
        if (UiPreferences.appFontMode(context) != "font") return
        fun walk(node: View) {
            if (node is TextView) {
                val oldStyle = node.typeface?.style ?: Typeface.NORMAL
                val selected = if (oldStyle and Typeface.BOLD != 0) bold(context) else regular(context)
                node.typeface = Typeface.create(selected, oldStyle)
            }
            if (node is ViewGroup) {
                for (i in 0 until node.childCount) walk(node.getChildAt(i))
            }
        }
        walk(view)
    }
}
