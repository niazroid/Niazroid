package ir.bankmoviee.app

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class OnboardingActivity : Activity() {

    private data class SetupPalette(
        val bg: Int,
        val panel: Int,
        val panel2: Int,
        val stroke: Int,
        val text: Int,
        val muted: Int,
        val primary: Int,
        val onPrimary: Int,
        val light: Boolean
    )

    private var step = 0
    private var renderedStep = -1
    private val totalSteps = 5
    private var required = true

    private var language = "fa"
    private var theme = "black"
    private var accent = "blue"
    private var appFont = "font"
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackground = "black"
    private var subtitleScale = 112
    private var subtitleFont = "font"
    private var subtitleBold = true
    private var subtitlePosition = 0
    private var subtitlePreviewText: TextView? = null
    private var subtitlePreviewContainer: FrameLayout? = null
    private var downloadBehavior = "ask"
    private var seekSeconds = 10
    private var autoNext = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        required = intent.getBooleanExtra("required", true)
        val prefs = UiPreferences.prefs(this)
        language = prefs.getString("lang_code", "fa") ?: "fa"
        theme = UiPreferences.themeMode(this)
        accent = UiPreferences.accentName(this)
        appFont = UiPreferences.appFontMode(this)
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackground = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleFont = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePosition = UiPreferences.subtitlePosition(this)
        downloadBehavior = UiPreferences.downloadBehavior(this)
        seekSeconds = UiPreferences.seekSeconds(this)
        autoNext = UiPreferences.autoNext(this)
        render()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (step > 0) {
            step--
            render()
        } else if (!required) {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun fa(): Boolean = language != "en"
    private fun tr(fa: String, en: String): String = if (fa()) fa else en
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun palette(): SetupPalette {
        val primary = UiPreferences.accentColor(accent)
        val onPrimary = if ((Color.red(primary) * 299 + Color.green(primary) * 587 + Color.blue(primary) * 114) / 1000 > 170) Color.BLACK else Color.WHITE
        return when (theme) {
            "light" -> SetupPalette(
                Color.rgb(242, 244, 248), Color.WHITE, Color.rgb(235, 239, 246), Color.rgb(207, 214, 226),
                Color.rgb(20, 23, 29), Color.rgb(88, 96, 111), primary, onPrimary, true
            )
            "dark" -> SetupPalette(
                Color.rgb(3, 8, 17), Color.rgb(10, 19, 34), Color.rgb(16, 29, 48), Color.rgb(45, 68, 100),
                Color.WHITE, Color.rgb(181, 192, 210), primary, onPrimary, false
            )
            else -> SetupPalette(
                Color.BLACK, Color.rgb(14, 14, 16), Color.rgb(25, 25, 29), Color.rgb(55, 55, 62),
                Color.WHITE, Color.rgb(190, 190, 198), primary, onPrimary, false
            )
        }
    }

    private fun rounded(color: Int, radius: Int, border: Int = Color.TRANSPARENT, borderWidth: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(color)
            if (border != Color.TRANSPARENT) setStroke(dp(borderWidth), border)
        }

    private fun text(
        value: String,
        size: Float = 14f,
        bold: Boolean = false,
        color: Int = palette().text,
        gravityValue: Int = if (fa()) Gravity.RIGHT else Gravity.LEFT
    ): TextView = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
        gravity = gravityValue
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun localTypeface(bold: Boolean = false): Typeface {
        return if (appFont == "font") {
            if (bold) BankmovieFonts.bold(this) else BankmovieFonts.regular(this)
        } else {
            Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    private fun applyLocalFont(view: View) {
        if (view is TextView) {
            if (view.tag != "font_preview_system" && view.tag != "font_preview_bankmovie") {
                val isBold = ((view.typeface?.style ?: Typeface.NORMAL) and Typeface.BOLD) != 0
                view.typeface = localTypeface(isBold)
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) applyLocalFont(view.getChildAt(i))
        }
    }

    private fun persistDraft() {
        UiPreferences.prefs(this).edit()
            .putString("lang_code", language)
            .putString(UiPreferences.KEY_THEME, theme)
            .putString(UiPreferences.KEY_ACCENT, accent)
            .putString(UiPreferences.KEY_APP_FONT, appFont)
            .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
            .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
            .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackground)
            .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
            .putString(UiPreferences.KEY_SUB_FONT, subtitleFont)
            .putBoolean(UiPreferences.KEY_SUB_BOLD, subtitleBold)
            .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePosition)
            .putString(UiPreferences.KEY_DOWNLOAD_BEHAVIOR, downloadBehavior)
            .putInt(UiPreferences.KEY_SEEK_SECONDS, seekSeconds)
            .putBoolean(UiPreferences.KEY_AUTO_NEXT, autoNext)
            .apply()
    }

    private fun updateSubtitlePreviewPosition(animate: Boolean = true) {
        val preview = subtitlePreviewContainer ?: return
        val textView = subtitlePreviewText ?: return
        val params = (textView.layoutParams as? FrameLayout.LayoutParams) ?: FrameLayout.LayoutParams(-2, -2)
        params.gravity = when (subtitlePosition) {
            2 -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            1 -> Gravity.CENTER
            else -> Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        }
        params.topMargin = dp(12)
        params.bottomMargin = dp(12)
        textView.layoutParams = params
        if (animate) {
            textView.animate().cancel()
            textView.alpha = 0.68f
            textView.scaleX = 0.97f
            textView.scaleY = 0.97f
            textView.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L)
                .setInterpolator(android.view.animation.DecelerateInterpolator()).start()
        }
        preview.invalidate()
    }

    private fun choice(label: String, active: Boolean, click: () -> Unit): TextView {
        val p = palette()
        return text(label, 13f, true, if (active) p.onPrimary else p.text, Gravity.CENTER).apply {
            isClickable = true
            isFocusable = true
            setPadding(dp(10), dp(11), dp(10), dp(11))
            background = if (active) rounded(p.primary, 17) else rounded(p.panel2, 17, p.stroke)
            setOnClickListener { click(); persistDraft() }
        }
    }

    private fun sectionTitle(label: String): TextView = text(label, 14f, true).apply {
        setPadding(dp(2), dp(5), dp(2), dp(8))
    }

    private fun stepIcon(): Int = when (step) {
        0 -> R.drawable.ic_setup_magic
        1 -> R.drawable.ic_setup_theme
        2 -> R.drawable.ic_setup_subtitle
        3 -> R.drawable.ic_setup_play
        else -> R.drawable.ic_setup_language
    }

    private fun setupHeroTitle(): String = when (step) {
        0 -> tr("تجربه را برای خودت تنظیم کن", "Make it yours")
        1 -> tr("ظاهر دلخواهت را بساز", "Choose your look")
        2 -> tr("زیرنویس دقیقاً مطابق سلیقه تو", "Tune your subtitles")
        3 -> tr("پخش روان و دانلود راحت", "Smooth playback and downloads")
        else -> tr("همه‌چیز آماده است", "You are all set")
    }

    private fun render() {
        val p = palette()
        window.statusBarColor = p.bg
        window.navigationBarColor = p.bg
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            var flags = window.decorView.systemUiVisibility
            flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                flags = if (p.light) flags or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR else flags and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
            }
            window.decorView.systemUiVisibility = flags
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(12))
            background = rounded(p.panel, 0)
        }
        val heroRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
        }
        heroRow.addView(FrameLayout(this).apply {
            background = rounded(UiPreferences.blend(p.panel2, p.primary, 0.18f), 18, p.primary)
            addView(ImageView(this@OnboardingActivity).apply {
                setImageResource(stepIcon())
                setColorFilter(p.primary)
                setPadding(dp(13), dp(13), dp(13), dp(13))
            }, FrameLayout.LayoutParams(-1, -1))
        }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginEnd = dp(12) })
        heroRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text(setupHeroTitle(), 18f, true))
            addView(text(tr("مرحله ${step + 1} از $totalSteps", "Step ${step + 1} of $totalSteps"), 11.5f, false, p.muted).apply { setPadding(0, dp(4), 0, 0) })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(heroRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
        val progressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        repeat(totalSteps) { index ->
            progressRow.addView(View(this).apply {
                background = rounded(if (index <= step) p.primary else p.stroke, 99)
            }, LinearLayout.LayoutParams(0, dp(4), 1f).apply {
                if (index > 0) marginStart = dp(6)
            })
        }
        top.addView(progressRow)
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
        }
        when (step) {
            0 -> renderIntro(body)
            1 -> renderAppearance(body)
            2 -> renderSubtitles(body)
            3 -> renderPlayback(body)
            else -> renderLanguageAndSummary(body)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(16))
            layoutDirection = if (fa()) View.LAYOUT_DIRECTION_RTL else View.LAYOUT_DIRECTION_LTR
            background = rounded(p.panel, 0)
        }
        val back = choice(tr("قبلی", "Back"), false) {
            if (step > 0) { step--; render() } else if (!required) { setResult(RESULT_CANCELED); finish() }
        }.apply { alpha = if (step == 0 && required) 0.35f else 1f; isEnabled = step > 0 || !required }
        val nextLabel = if (step == totalSteps - 1) tr("ذخیره و شروع", "Save and start") else tr("ادامه", "Continue")
        val next = choice(nextLabel, true) {
            if (step < totalSteps - 1) { step++; render() } else finishSetup()
        }
        nav.addView(back, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(7) })
        nav.addView(next, LinearLayout.LayoutParams(0, dp(50), 1.35f).apply { marginStart = dp(7) })
        root.addView(nav)

        applyLocalFont(root)
        val stepChanged = renderedStep != step
        renderedStep = step
        setContentView(root)
        if (stepChanged) {
            root.alpha = 0f
            root.translationY = dp(10).toFloat()
            root.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(180L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun renderIntro(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("تنظیم اولیه در کمتر از یک دقیقه", "Set up your experience in under a minute"), 22f, true))
        body.addView(text(
            tr("فقط یک‌بار از شما پرسیده می‌شود و همه انتخاب‌ها تا زمان حذف برنامه ذخیره می‌مانند.", "This is shown once. Your choices remain saved until the app is uninstalled."),
            13f, false, p.muted
        ).apply { setPadding(0, dp(8), 0, dp(16)) })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(p.panel, 22, p.stroke)
        }
        panel.addView(text(tr("در این مرحله تنظیم می‌شود", "This setup configures"), 15f, true))
        listOf(
            tr("• تم، رنگ اصلی و فونت برنامه", "• Theme, accent color and app font"),
            tr("• رنگ، اندازه و ظاهر زیرنویس", "• Subtitle color, size and style"),
            tr("• روش دانلود و تنظیمات پخش", "• Download method and playback defaults"),
            tr("• زبان فارسی یا English", "• Persian or English language")
        ).forEach { item -> panel.addView(text(item, 13f, false, p.muted).apply { setPadding(0, dp(8), 0, 0) }) }
        body.addView(panel, LinearLayout.LayoutParams(-1, -2))

        body.addView(text(
            tr("مجوز اعلان قبل از این مرحله درخواست شد تا پیام‌های ادمین و وضعیت دانلودها را دریافت کنید.", "Notification permission was requested first so you can receive admin messages and download status."),
            12.5f, false, p.muted
        ).apply { setPadding(0, dp(15), 0, dp(5)) })
        body.addView(text(
            tr("بعداً همه این موارد از پروفایل ← تنظیمات قابل تغییر است.", "You can change all of these later from Profile → Settings."),
            12.5f, true, p.primary
        ))
    }

    private fun renderAppearance(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("ظاهر و فونت", "Look and font"), 22f, true))
        body.addView(text(tr("تغییرها همین‌جا به‌صورت زنده نمایش داده می‌شوند.", "Changes are previewed here instantly."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        body.addView(sectionTitle(tr("حالت ظاهری", "Theme")))
        val themeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("black" to tr("مشکی", "Black"), "dark" to tr("تیره", "Dark"), "light" to tr("روشن", "Light")).forEachIndexed { index, pair ->
            themeRow.addView(choice(pair.second, theme == pair.first) { theme = pair.first; render() }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        body.addView(themeRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        body.addView(sectionTitle(tr("رنگ اصلی", "Accent color")))
        val colorScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3), 0, dp(8)) }
        listOf("blue", "gold", "orange", "red", "purple", "teal", "green").forEach { name ->
            val color = UiPreferences.accentColor(name)
            colorRow.addView(TextView(this).apply {
                text = if (accent == name) "✓" else ""
                setTextColor(if (name == "gold") Color.BLACK else Color.WHITE)
                textSize = 17f
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                background = rounded(color, 999, if (accent == name) p.text else Color.argb(80, 255, 255, 255), if (accent == name) 2 else 1)
                setOnClickListener { accent = name; persistDraft(); render() }
            }, LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginEnd = dp(8) })
        }
        colorScroll.addView(colorRow)
        body.addView(colorScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("فونت برنامه", "App font")))
        val fontPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val samples = listOf(
            "system" to Pair(tr("فونت سیستمی", "System font"), tr("فیلم و سریال‌های تازه", "New movies and series")),
            "font" to Pair(tr("فونت ایرانسل", "Irancell font"), tr("فیلم و سریال‌های تازه", "New movies and series"))
        )
        samples.forEach { (key, pair) ->
            val selected = appFont == key
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                isClickable = true
                isFocusable = true
                background = rounded(if (selected) UiPreferences.blend(p.panel2, p.primary, 0.14f) else p.panel, 20, if (selected) p.primary else p.stroke, if (selected) 2 else 1)
                setOnClickListener { appFont = key; persistDraft(); render() }
            }
            card.addView(text((if (selected) "✓  " else "") + pair.first, 14f, true, if (selected) p.primary else p.text))
            card.addView(text(pair.second, 17f, true, p.text).apply {
                tag = if (key == "font") "font_preview_bankmovie" else "font_preview_system"
                typeface = if (key == "font") BankmovieFonts.bold(this@OnboardingActivity) else Typeface.DEFAULT_BOLD
                setPadding(0, dp(8), 0, 0)
            })
            fontPanel.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })
        }
        body.addView(fontPanel)
    }

    private fun renderSubtitles(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("زیرنویس", "Subtitles"), 22f, true))
        body.addView(text(tr("پیش‌نمایش زیرنویس با انتخاب‌های شما", "Live subtitle preview"), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(12)) })

        val preview = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(15, 22, 34), Color.rgb(31, 39, 53))).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), p.stroke)
            }
            setPadding(dp(12), dp(18), dp(12), dp(18))
        }
        subtitlePreviewContainer = preview
        preview.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_setup_play)
            setColorFilter(Color.argb(34, 255, 255, 255))
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(42), dp(42), dp(42), dp(42))
        }, FrameLayout.LayoutParams(-1, -1))
        preview.addView(TextView(this).apply {
            text = tr("پیش‌نمایش زنده", "LIVE PREVIEW")
            setTextColor(Color.argb(170, 255, 255, 255))
            textSize = 9.5f
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(90, 0, 0, 0), 10)
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.LEFT).apply { leftMargin = dp(10); topMargin = dp(10) })
        val bgColor = when (subtitleBackground) {
            "transparent" -> Color.TRANSPARENT
            "white" -> Color.argb(225, 255, 255, 255)
            "yellow" -> Color.argb(220, 255, 235, 59)
            else -> Color.argb(215, 0, 0, 0)
        }
        subtitlePreviewText = TextView(this).apply {
            text = tr("این یک پیش‌نمایش زیرنویس است", "This is how subtitles will look")
            setTextColor(subtitleTextColor)
            textSize = (subtitleScale / 8.2f).coerceIn(12f, 22f)
            gravity = Gravity.CENTER
            typeface = if (subtitleFont == "font") {
                if (subtitleBold) BankmovieFonts.bold(this@OnboardingActivity) else BankmovieFonts.regular(this@OnboardingActivity)
            } else Typeface.create(Typeface.DEFAULT, if (subtitleBold) Typeface.BOLD else Typeface.NORMAL)
            background = rounded(bgColor, 8)
            setPadding(dp(8), dp(5), dp(8), dp(5))
            alpha = if (subtitleEnabled) 1f else 0.35f
        }
        subtitlePreviewText?.let { previewText ->
            preview.addView(previewText, FrameLayout.LayoutParams(-2, -2))
        }
        updateSubtitlePreviewPosition(animate = false)
        body.addView(preview, LinearLayout.LayoutParams(-1, dp(178)).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("نمایش زیرنویس", "Show subtitles")))
        val enabledRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        enabledRow.addView(choice(tr("فعال", "On"), subtitleEnabled) { subtitleEnabled = true; render() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(7) })
        enabledRow.addView(choice(tr("غیرفعال", "Off"), !subtitleEnabled) { subtitleEnabled = false; render() }, LinearLayout.LayoutParams(0, dp(46), 1f))
        body.addView(enabledRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("رنگ متن", "Text color")))
        val colorScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.rgb(105, 240, 174), Color.CYAN, Color.rgb(255, 105, 180), Color.rgb(255, 170, 60), Color.RED)
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(3), 0, dp(7)) }
        colors.forEach { color ->
            colorRow.addView(TextView(this).apply {
                text = if (subtitleTextColor == color) "✓" else ""
                gravity = Gravity.CENTER
                textSize = 15f
                setTextColor(if (color == Color.WHITE || color == Color.YELLOW) Color.BLACK else Color.WHITE)
                isClickable = true
                background = rounded(color, 999, if (subtitleTextColor == color) p.primary else Color.argb(95, 255, 255, 255), if (subtitleTextColor == color) 2 else 1)
                setOnClickListener { subtitleTextColor = color; persistDraft(); render() }
            }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(8) })
        }
        colorScroll.addView(colorRow)
        body.addView(colorScroll, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        body.addView(sectionTitle(tr("پس‌زمینه", "Background")))
        val bgRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("black" to tr("مشکی", "Black"), "transparent" to tr("شفاف", "Clear"), "white" to tr("سفید", "White")).forEachIndexed { index, pair ->
            bgRow.addView(choice(pair.second, subtitleBackground == pair.first) { subtitleBackground = pair.first; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        body.addView(bgRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("جای زیرنویس", "Subtitle position")))
        val positionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        fun refreshPositionButtons() {
            val currentPalette = palette()
            positionButtons.forEach { (position, view) ->
                val active = subtitlePosition == position
                view.background = if (active) rounded(currentPalette.primary, 17) else rounded(currentPalette.panel2, 17, currentPalette.stroke)
                view.setTextColor(if (active) currentPalette.onPrimary else currentPalette.text)
            }
        }
        listOf(0 to tr("پایین", "Bottom"), 1 to tr("وسط", "Middle"), 2 to tr("بالا", "Top")).forEachIndexed { index, pair ->
            val button = text(pair.second, 13f, true, p.text, Gravity.CENTER).apply {
                isClickable = true
                isFocusable = true
                setPadding(dp(10), dp(11), dp(10), dp(11))
                setOnClickListener {
                    subtitlePosition = pair.first
                    persistDraft()
                    refreshPositionButtons()
                    updateSubtitlePreviewPosition()
                }
            }
            positionButtons += pair.first to button
            positionRow.addView(button, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        refreshPositionButtons()
        body.addView(positionRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("فونت و ضخامت", "Font and weight")))
        val fontRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fontRow.addView(choice(tr("سیستمی", "System"), subtitleFont == "system") { subtitleFont = "system"; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        fontRow.addView(choice(tr("ایرانسل", "Irancell"), subtitleFont == "font") { subtitleFont = "font"; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        body.addView(fontRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val weightRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        weightRow.addView(choice(tr("پررنگ", "Bold"), subtitleBold) { subtitleBold = true; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        weightRow.addView(choice(tr("معمولی", "Regular"), !subtitleBold) { subtitleBold = false; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        body.addView(weightRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) })

        val sizeLabel = text(tr("اندازه زیرنویس: $subtitleScale٪", "Subtitle size: $subtitleScale%"), 14f, true)
        body.addView(sizeLabel)
        body.addView(SeekBar(this).apply {
            max = 90
            progress = (subtitleScale - 80).coerceIn(0, 90)
            progressTintList = ColorStateList.valueOf(p.primary)
            thumbTintList = ColorStateList.valueOf(p.primary)
            progressBackgroundTintList = ColorStateList.valueOf(p.stroke)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) { persistDraft() }
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    if (fromUser) {
                        subtitleScale = 80 + value
                        persistDraft()
                        sizeLabel.text = tr("اندازه زیرنویس: $subtitleScale٪", "Subtitle size: $subtitleScale%")
                        subtitlePreviewText?.let { previewText ->
                            previewText.textSize = (subtitleScale / 8.2f).coerceIn(12f, 22f)
                            previewText.animate().cancel()
                            previewText.animate().scaleX(1.035f).scaleY(1.035f).setDuration(60L).withEndAction {
                                previewText.animate().scaleX(1f).scaleY(1f).setDuration(90L).start()
                            }.start()
                        }
                    }
                }
            })
        }, LinearLayout.LayoutParams(-1, dp(52)))
    }

    private fun renderPlayback(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("پخش و دانلود", "Playback and downloads"), 22f, true))
        body.addView(text(tr("رفتار پیش‌فرض را انتخاب کنید؛ هر زمان از پروفایل قابل تغییر است.", "Choose defaults. You can change them later from Profile."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        body.addView(sectionTitle(tr("روش دانلود", "Download method")))
        val methods = listOf(
            "ask" to Pair(tr("هر بار سؤال شود", "Ask every time"), tr("انتخاب بین دانلودر داخلی و برنامه خارجی", "Choose internal or external each time")),
            "internal" to Pair(tr("دانلودر داخلی", "Internal downloader"), tr("مدیریت صف، توقف و ادامه داخل برنامه", "Queue, pause and resume inside the app")),
            "browser" to Pair(tr("مرورگر / برنامه خارجی", "Browser / external app"), tr("لینک مستقیماً به برنامه دیگر فرستاده می‌شود", "Send links directly to another app"))
        )
        methods.forEach { (key, pair) ->
            val active = downloadBehavior == key
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                background = rounded(if (active) UiPreferences.blend(p.panel2, p.primary, 0.15f) else p.panel, 19, if (active) p.primary else p.stroke, if (active) 2 else 1)
                isClickable = true
                isFocusable = true
                setOnClickListener { downloadBehavior = key; render() }
            }
            row.addView(text((if (active) "✓  " else "") + pair.first, 14f, true, if (active) p.primary else p.text))
            row.addView(text(pair.second, 12f, false, p.muted).apply { setPadding(0, dp(5), 0, 0) })
            body.addView(row, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        }

        body.addView(sectionTitle(tr("زمان پرش پلیر", "Player seek interval")).apply { setPadding(dp(2), dp(12), dp(2), dp(8)) })
        val seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(5, 10, 30, 60).forEachIndexed { index, seconds ->
            seekRow.addView(choice(tr("$seconds ثانیه", "${seconds}s"), seekSeconds == seconds) { seekSeconds = seconds; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { if (index > 0) marginStart = dp(6) })
        }
        body.addView(seekRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        body.addView(sectionTitle(tr("قسمت بعدی", "Next episode")))
        val autoRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        autoRow.addView(choice(tr("فعال", "On"), autoNext) { autoNext = true; render() }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        autoRow.addView(choice(tr("غیرفعال", "Off"), !autoNext) { autoNext = false; render() }, LinearLayout.LayoutParams(0, dp(44), 1f))
        body.addView(autoRow)
    }

    private fun renderLanguageAndSummary(body: LinearLayout) {
        val p = palette()
        body.addView(text(tr("زبان و پایان", "Language and finish"), 22f, true))
        body.addView(text(tr("زبان رابط برنامه را انتخاب کنید.", "Choose the app interface language."), 13f, false, p.muted).apply { setPadding(0, dp(7), 0, dp(14)) })

        val languageRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        languageRow.addView(choice("فارسی", language == "fa") { language = "fa"; render() }, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(7) })
        languageRow.addView(choice("English", language == "en") { language = "en"; render() }, LinearLayout.LayoutParams(0, dp(50), 1f))
        body.addView(languageRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(16) })

        val summary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(15), dp(14), dp(15), dp(14))
            background = rounded(p.panel, 22, p.stroke)
        }
        summary.addView(text(tr("خلاصه انتخاب‌ها", "Your choices"), 15f, true))
        val themeLabel = when (theme) { "light" -> tr("روشن", "Light"); "dark" -> tr("تیره", "Dark"); else -> tr("مشکی", "Black") }
        val fontLabel = if (appFont == "font") tr("فونت ایرانسل", "Irancell font") else tr("فونت سیستمی", "System font")
        val downloadLabel = when (downloadBehavior) { "internal" -> tr("دانلودر داخلی", "Internal downloader"); "browser" -> tr("مرورگر / خارجی", "Browser / external"); else -> tr("هر بار سؤال شود", "Ask every time") }
        listOf(
            tr("ظاهر: $themeLabel", "Theme: $themeLabel"),
            tr("فونت: $fontLabel", "Font: $fontLabel"),
            tr("زیرنویس: ${if (subtitleEnabled) "فعال" else "غیرفعال"}، $subtitleScale٪، ${listOf("پایین", "وسط", "بالا")[subtitlePosition]}", "Subtitles: ${if (subtitleEnabled) "On" else "Off"}, $subtitleScale%"),
            tr("دانلود: $downloadLabel", "Downloads: $downloadLabel"),
            tr("پرش پلیر: $seekSeconds ثانیه", "Player seek: ${seekSeconds}s")
        ).forEach { value -> summary.addView(text(value, 13f, false, p.muted).apply { setPadding(0, dp(8), 0, 0) }) }
        body.addView(summary)
        body.addView(text(
            tr("با ذخیره، این صفحه دیگر خودکار نمایش داده نمی‌شود. هر گزینه از پروفایل ← تنظیمات قابل تغییر است.", "After saving, this setup will not open automatically again. Every option remains available under Profile → Settings."),
            12.5f, true, p.primary
        ).apply { setPadding(0, dp(15), 0, 0) })
    }

    private fun finishSetup() {
        persistDraft()
        UiPreferences.prefs(this).edit()
            .putString("lang_code", language)
            .putString(UiPreferences.KEY_THEME, theme)
            .putString(UiPreferences.KEY_ACCENT, accent)
            .putString(UiPreferences.KEY_APP_FONT, appFont)
            .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
            .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
            .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackground)
            .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
            .putString(UiPreferences.KEY_SUB_FONT, subtitleFont)
            .putBoolean(UiPreferences.KEY_SUB_BOLD, subtitleBold)
            .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePosition)
            .putString(UiPreferences.KEY_DOWNLOAD_BEHAVIOR, downloadBehavior)
            .putInt(UiPreferences.KEY_SEEK_SECONDS, seekSeconds)
            .putBoolean(UiPreferences.KEY_AUTO_NEXT, autoNext)
            .putInt(UiPreferences.KEY_SETUP_VERSION, UiPreferences.CURRENT_SETUP_VERSION)
            .apply()
        setResult(RESULT_OK)
        finish()
    }
}
