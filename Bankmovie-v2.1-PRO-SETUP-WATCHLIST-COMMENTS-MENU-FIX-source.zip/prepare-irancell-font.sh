#!/usr/bin/env bash
set -euo pipefail
TARGET="app/src/main/assets/fonts/irancell_regular.ttf"
mkdir -p "$(dirname "$TARGET")"
if [[ -s "$TARGET" ]]; then
  echo "Irancell font asset is ready."
  exit 0
fi
for zip in ../Bankmovie-v2.1-*-source.zip; do
  [[ -f "$zip" ]] || continue
  if unzip -Z1 "$zip" 2>/dev/null | grep -qx 'app/src/main/assets/fonts/irancell_regular.ttf'; then
    unzip -p "$zip" 'app/src/main/assets/fonts/irancell_regular.ttf' > "$TARGET"
    if [[ -s "$TARGET" ]]; then
      echo "Irancell font restored from $(basename "$zip")."
      exit 0
    fi
  fi
done
rm -f "$TARGET"
echo "Irancell private font asset was not found; Android fallback will be used." >&2
