package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.PathInterpolator
import kotlin.math.min

/** Three rounded bars that morph into a close icon. */
class MorphHamburgerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var progress = 0f
    private var animator: ValueAnimator? = null
    var lineColor: Int = android.graphics.Color.WHITE
        set(value) { field = value; invalidate() }

    fun setOpened(opened: Boolean, animate: Boolean = true) {
        val target = if (opened) 1f else 0f
        animator?.cancel()
        if (!animate) {
            progress = target
            invalidate()
            return
        }
        animator = ValueAnimator.ofFloat(progress, target).apply {
            duration = 215L
            interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val s = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val half = s * 0.25f
        val gap = s * 0.145f
        paint.color = lineColor
        paint.strokeWidth = (s * 0.07f).coerceAtLeast(2f)

        canvas.save()
        val topY = cy - gap * (1f - progress)
        canvas.rotate(45f * progress, cx, topY)
        canvas.drawLine(cx - half, topY, cx + half, topY, paint)
        canvas.restore()

        paint.alpha = (255 * (1f - progress)).toInt()
        canvas.drawLine(cx - half, cy, cx + half, cy, paint)
        paint.alpha = 255

        canvas.save()
        val bottomY = cy + gap * (1f - progress)
        canvas.rotate(-45f * progress, cx, bottomY)
        canvas.drawLine(cx - half, bottomY, cx + half, bottomY, paint)
        canvas.restore()
    }
}
