package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Native recreation of the supplied Uiverse orbital glow loader. */
class OrbitalGlowLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val d = resources.displayMetrics.density
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        maskFilter = BlurMaskFilter(10f * d, BlurMaskFilter.Blur.NORMAL)
    }
    private var angle = 0f
    private var animator: ValueAnimator? = null

    init {
        // BlurMaskFilter requires software rendering for consistent glow on API 23+.
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (!isInEditMode && animator?.isRunning != true) {
            animator = ValueAnimator.ofFloat(0f, 360f).apply {
                duration = 1000L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    angle = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        if (size <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        val border = size * 0.10f
        val radius = size * 0.38f
        val rect = RectF(cx - radius, cy - radius, cx + radius, cy + radius)

        val gradient = SweepGradient(
            cx,
            cy,
            intArrayOf(
                Color.TRANSPARENT,
                Color.TRANSPARENT,
                Color.rgb(5, 35, 88),
                Color.rgb(84, 181, 255),
                Color.WHITE,
                Color.TRANSPARENT
            ),
            floatArrayOf(0f, .20f, .46f, .67f, .84f, 1f)
        )
        ringPaint.shader = gradient
        ringPaint.strokeWidth = border
        canvas.save()
        canvas.rotate(-angle, cx, cy)
        canvas.drawArc(rect, 0f, 360f, false, ringPaint)
        canvas.restore()
        ringPaint.shader = null

        val rad = Math.toRadians((-angle - 90f).toDouble())
        val dx = (cos(rad) * radius).toFloat()
        val dy = (sin(rad) * radius).toFloat()
        glowPaint.color = Color.argb(185, 116, 199, 255)
        canvas.drawCircle(cx + dx, cy + dy, border * 1.25f, glowPaint)
        dotPaint.color = Color.WHITE
        canvas.drawCircle(cx + dx, cy + dy, border * .52f, dotPaint)
    }
}
