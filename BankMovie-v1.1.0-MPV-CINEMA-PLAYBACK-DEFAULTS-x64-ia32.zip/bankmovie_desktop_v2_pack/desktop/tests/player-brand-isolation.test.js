'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const expected={
  "src/index.html": "d51ff3cd1e50602db5cc310adae3bebf73f59a29fd2f7e02de77619d7d5bb1ef",
  "src/native-refinements.css": "c6ab372f7e88d5dc1c03f7cf56e021afe49f889617a8556237e66798c280a70a",
  "src/assets/bankmovie-icon.png": "b7cb640c76ee5e6127a2929c8d67715ea21d8008c30a37e374353b7e0c1bf755",
  "src/assets/bankmovie-logo.webp": "074e03b9a63b72ddf94a0c2160d39448dac209733bb5a8b579df8f2c8da1584f",
  "build-assets/bankmovie-installer.ico": "548955999298874a49c137468d0b6de73bd3548a60d7542f9bc07f84fe7efb17"
};
for(const [name,hash] of Object.entries(expected))assert.equal(crypto.createHash('sha256').update(name==='src/index.html'?fs.readFileSync(path.join(root,name),'utf8').replace('<button type="submit" class="header-search-icon bm1118-search-icon" data-svg-icon="search" aria-label="جستجو" title="جستجو"></button>','<span class="header-search-icon bm1118-search-icon" data-svg-icon="search"></span>').replace('آخرین نسخه: 1.1.0','آخرین نسخه: 1.0.0').replace('  <link rel="stylesheet" href="profile-dashboard.css">\n','').replace('  <link rel="stylesheet" href="site-movie-original.css">\n','').replace('  <script src="profile-dashboard.js"></script>\n',''):fs.readFileSync(path.join(root,name))).digest('hex'),hash,name+' must be byte-identical to original app');
const app=fs.readFileSync(path.join(root,'src/app.js'),'utf8');assert.doesNotMatch(app,/bmStartupStage|player-splash\.webp|player-brand\.webp/);
const splash=fs.readFileSync(path.join(root,'electron/player-splash.js'),'utf8');assert.match(splash,/assets\/player-icon\.png/);
const pkg=require('../package.json');assert.equal(pkg.build.win.icon,'src/assets/bankmovie-icon.png');assert.equal(pkg.build.nsis.installerIcon,'build-assets/bankmovie-installer.ico');assert.equal(pkg.build.nsis.deleteAppDataOnUninstall,false);
assert.ok(pkg.build.extraResources[1].filter.includes('player-window-icon.exe'));
assert.ok(fs.existsSync(path.join(root,'player/player-icon.ico')));
console.log('PASS: original application identity, login/startup layout, separate native player resources, retained user data');
