'use strict';
const {isIP}=require('node:net');
const tlsError=/^(?:CERT_[A-Z_]+|ERR_TLS_CERT_[A-Z_]+|DEPTH_ZERO_SELF_SIGNED_CERT|SELF_SIGNED_CERT_IN_CHAIN|UNABLE_TO_VERIFY_LEAF_SIGNATURE|UNABLE_TO_GET_ISSUER_CERT(?:_LOCALLY)?|ERR_SSL_WRONG_VERSION_NUMBER|ERR_SSL_UNSUPPORTED_PROTOCOL|ERR_SSL_TLSV1_ALERT_PROTOCOL_VERSION)$/;
function candidate(raw,protectedOrigins=[]){
  try{const u=new URL(raw),host=u.hostname.toLowerCase().replace(/\.$/,'');
    if(u.protocol!=='https:'||u.username||u.password||u.search||u.hash||u.port||!host.includes('.')||isIP(host)||/\.(?:local|localhost|internal|lan|test|onion)$/.test(host)||!/^[-a-z0-9.]+$/.test(host)||!(/\.(?:mp4|mkv|webm|avi|mov|m4v|mp3|m4a|aac|flac|mka|ts)$/i.test(u.pathname)))return null;
    if(protectedOrigins.some(origin=>{try{const h=new URL(origin).hostname.toLowerCase();return host===h||host.endsWith('.'+h)}catch{return false}}))return null;
    if(/(?:^|\/)(?:api|auth|login|account|token|signed|private|secure|v1|v2)(?:\/|$)/i.test(u.pathname))return null;
    u.protocol='http:';return u.toString();
  }catch{return null}
}
function certificateFailure(e){return tlsError.test(String(e?.cause?.code||e?.code||''));}
async function probe(url,fetcher=fetch){
  const c=new AbortController();const timer=setTimeout(()=>c.abort(),7000);
  try{const r=await fetcher(url,{method:'GET',headers:{Range:'bytes=0-0'},redirect:'manual',credentials:'omit',cache:'no-store',signal:c.signal});
    const type=String(r.headers?.get('content-type')||'').split(';')[0].toLowerCase();
    try{await r.body?.cancel()}catch{}
    return {status:r.status,media:/^(?:video\/|audio\/|application\/(?:octet-stream|x-matroska|mp4))/.test(type)};
  }finally{clearTimeout(timer)}
}
async function resolve(raw,{enabled=true,protectedOrigins=[],check=probe}={}){
  // Native HTTP sources (e.g. archive 5) and other ineligible URLs pass through unchanged.
  const alt=enabled&&candidate(raw,protectedOrigins);if(!alt)return {url:raw,fallback:false};
  try{await check(raw);return {url:raw,fallback:false};}catch(e){if(!certificateFailure(e))return {url:raw,fallback:false};}
  try{const r=await check(alt);if([200,206].includes(r.status)&&r.media)return {url:alt,fallback:true};}catch{}
  return {url:raw,fallback:false};
}
module.exports={candidate,certificateFailure,probe,resolve};
