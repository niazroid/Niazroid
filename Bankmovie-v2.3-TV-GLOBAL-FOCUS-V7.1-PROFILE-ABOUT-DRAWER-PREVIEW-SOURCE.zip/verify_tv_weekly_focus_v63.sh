#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
APP_API='server-required/app_api.php'
APP_CONFIG='server-required/app_config.php'
API4='server-required/api4.php'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# V6.3: Weekly must be attached before its final TV wiring pass and one DOWN
# from the final Home rail must own/queue the real weekly focus transition.
need "$MAIN" 'private fun requestHomeTvWeeklyEntry(): Boolean'
need "$MAIN" 'queued focus pass completes instead of making the user press repeatedly.'
need "$MAIN" 'registration.tabsScroller.releaseTvInitialFocusGuard()'
need "$MAIN" 'registration.itemsScroller.releaseTvInitialFocusGuard()'
need "$MAIN" 'else requestHomeTvWeeklyEntry()'
need "$MAIN" 'section.post {'
need "$MAIN" 'wireHomeWeeklyFocus()'
need "$MAIN" 'wireHomePosterRows()'
need "$MAIN" 'The real focused view can be a descendant of the poster on some TV'
need "$MAIN" 'tab.tag = "bm_home_weekly_tab_$index"'
need "$MAIN" 'item.tag = "bm_home_weekly_item_$index"'
need "$MAIN" 'source.nextFocusDownId = weeklyEntry.id'

# Archive 4 TV Home must honor the remote/site section policy just like mobile.
need "$MAIN" 'val sectionsToRender = if (remoteSections.isNotEmpty()) remoteSections else defaultSections'
need "$APP_CONFIG" "archive4_site_api_url"
need "$APP_CONFIG" "archive4_sections"
need "$API4" 'function api4_section_allowed($section)'
need "$API4" "bm_archive_section_enabled('archive4',"

# PHP Array-to-string regression guards for the exact production warnings.
need "$APP_API" 'function bm_app_scalar_string($value, $preferredKeys = array())'
need "$APP_API" 'bm_app_scalar_string($html, array('
need "$APP_API" 'bm_app_scalar_string($path, array('

if command -v php >/dev/null 2>&1; then
  php -l "$APP_API" >/dev/null
  php -l "$APP_CONFIG" >/dev/null
  php -l "$API4" >/dev/null
fi

echo 'TV_WEEKLY_ARCHIVE4_V63_OK'
