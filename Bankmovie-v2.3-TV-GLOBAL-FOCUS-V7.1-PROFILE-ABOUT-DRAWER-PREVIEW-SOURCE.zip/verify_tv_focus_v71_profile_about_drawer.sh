#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.1 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT'
need "$MARKER" 'verifierPatch=V7.1 FIRST-FOCUS BOOTSTRAP + ABOUT LIST + TV DRAWER SVG PREVIEW'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V71-20260907'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_1_PROFILE_ABOUT_DRAWER_PREVIEW_FA.md' 'Profile/About first-focus + Drawer SVG preview'

# Profile bootstrap: no Android-selected ghost owner before explicit routes exist.
need "$MAIN" 'private fun wireV71ProfileBootstrapSurface(page: View)'
need "$MAIN" 'private fun activateV71ProfileBootstrap(page: View)'
need "$MAIN" 'tag = "bm_v71_profile_local_row_$storeKey"'
need "$MAIN" 'v71ProfileFirstBodyTarget(page)'
need "$MAIN" 'content.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS'
need "$MAIN" 'activateV71ProfileBootstrap(page)'

# About / developer information list has deterministic first focus and vertical routing.
need "$MAIN" 'private fun wireV71AboutSurface(page: View)'
need "$MAIN" 'private fun activateV71AboutBootstrap(page: View)'
need "$MAIN" 'tag = "bm_v71_about_row_0"'
need "$MAIN" 'tag = "bm_v71_about_row_4"'
need "$MAIN" 'bindTvDirectionalTarget(row, android.view.KeyEvent.KEYCODE_DPAD_DOWN) { next }'
need "$MAIN" 'activateV71AboutBootstrap(page)'
need "$MAIN" '"profile" -> content.findViewWithTag<View>("bm_v71_about_row_0")'

# New Drawer preview resources are TV-only; legacy icons remain in tree for rollback.
for f in \
  app/src/main/res/drawable/ic_tv_nav_home_preview.xml \
  app/src/main/res/drawable/ic_tv_nav_search_preview.xml \
  app/src/main/res/drawable/ic_tv_nav_boxoffice_preview.xml \
  app/src/main/res/drawable/ic_tv_nav_download_preview.xml \
  app/src/main/res/drawable/ic_tv_nav_profile_preview.xml \
  app/src/main/res/drawable/ic_tv_nav_favorites_preview.xml; do
  [[ -s "$f" ]] || { echo "Missing V7.1 TV drawer icon: $f" >&2; exit 1; }
done
for f in \
  app/src/main/res/drawable/ic_nav_home.xml \
  app/src/main/res/drawable/ic_search_clean.xml \
  app/src/main/res/drawable/ic_imdb.xml \
  app/src/main/res/drawable/ic_download.xml \
  app/src/main/res/drawable/ic_nav_profile.xml \
  app/src/main/res/drawable/ic_nav_heart.xml; do
  [[ -s "$f" ]] || { echo "Legacy icon unexpectedly removed: $f" >&2; exit 1; }
done
need "$MAIN" 'Pair("home", R.drawable.ic_tv_nav_home_preview)'
need "$MAIN" 'Pair("search", R.drawable.ic_tv_nav_search_preview)'
need "$MAIN" 'Pair("boxoffice", R.drawable.ic_tv_nav_boxoffice_preview)'
need "$MAIN" 'Pair("downloads", R.drawable.ic_tv_nav_download_preview)'
need "$MAIN" 'Pair("profile", R.drawable.ic_tv_nav_profile_preview)'
need "$MAIN" 'Pair("favorites", R.drawable.ic_tv_nav_favorites_preview)'

# Confirm already-good TV surfaces still exist.
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'
need "$MAIN" 'private fun wireV69ContinueRail(header: View, row: ViewGroup)'
need "$MAIN" 'private fun wireV70WeeklySurface()'

python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
# Profile must no longer schedule the old 35ms initial-focus race.
a=s.index('private fun showProfile()')
b=s.index('private fun profileCompactActionTile', a)
profile=s[a:b]
if 'scheduleTvInitialScreenFocus(35L)' in profile:
    raise SystemExit('V7.1 profile still uses the old 35ms focus race')
if 'FOCUS_BLOCK_DESCENDANTS' not in profile or 'activateV71ProfileBootstrap(page)' not in profile:
    raise SystemExit('V7.1 profile bootstrap lock/activation missing')
# About must be deterministic and must not use delayed geometry routing.
a=s.index('private fun showAboutPage()')
b=s.index('private fun addProfileContinueSection', a)
about=s[a:b]
if 'buildDirectionalGraph = false' not in about:
    raise SystemExit('V7.1 About still enables generic geometry routing')
if about.count('bm_v71_about_row_') < 5:
    raise SystemExit('V7.1 About rows are not fully tagged')
PY

echo 'TV_FOCUS_V71_PROFILE_ABOUT_DRAWER_PREVIEW_OK'
