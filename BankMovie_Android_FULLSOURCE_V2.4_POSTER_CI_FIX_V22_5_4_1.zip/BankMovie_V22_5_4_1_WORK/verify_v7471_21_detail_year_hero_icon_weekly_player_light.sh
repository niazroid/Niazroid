#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
PLAYER="$ROOT/app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt"
META="$ROOT/BANKMOVIE_BUILD_SOURCE_2_3.txt"
NOTE="$ROOT/BANKMOVIE_V7471_21_DETAIL_YEAR_HERO_ICON_WEEKLY_PLAYER_LIGHT_FA.md"
for f in "$MAIN" "$PLAYER" "$META" "$NOTE"; do test -s "$f"; done

grep -Fq 'mainUpdateV7471_21=V7.47.1.21 DETAIL YEAR CONTRAST + WHITE HERO ICONS + WEEKLY COVER GAP + PLAYER LIGHT SHEETS' "$META"

# Poster year badge: it sits on a dark chip even when the page palette is Light.
grep -Fq 'V7.47.1.21: this chip is always painted on a dark poster overlay.' "$MAIN"
grep -Fq 'setTextColor(Color.WHITE)' "$MAIN"
grep -Fq 'background = rounded(Color.argb(155, 0, 0, 0), dp(13)' "$MAIN"

# Detail hero: V20 replaced the old solid-accent orb with a dark, outlined,
# semi-transparent glass control; preserve the white high-contrast play glyph.
# Assertions belong to the hero block so unrelated views cannot satisfy them.
python3 - "$MAIN" <<'PY_HERO'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text(encoding='utf-8')
a = s.index('val playOrb = FrameLayout(this).apply {', s.index('// V20: compact smoky glass play control.'))
b = s.index('val titleStack = LinearLayout(this).apply {', a)
hero = s[a:b]
for needle in (
    'Color.argb(192, 45, 54, 67)',
    'Color.argb(165, 14, 24, 39)',
    'setStroke(dp(1), Color.argb(205, 231, 242, 255))',
    'setColorFilter(Color.WHITE)',
    'topMargin = dp(262)',
    'setOnClickListener { showPlayableSheet(item) }',
):
    assert needle in hero, f'V20 glass play hero missing: {needle}'
assert 'heroPlayFill' not in hero, 'legacy solid-accent hero returned'
PY_HERO

# Weekly schedule cover/text breathing room.
grep -Fq 'V7.47.1.21: under RTL `marginEnd` is the interior gap' "$MAIN"
grep -Fq 'marginEnd = dp(12)' "$MAIN"

# Player settings/audio/subtitle sheets have a dedicated Light surface and semantic ink.
grep -Fq 'private fun playerSheetSurface(radius: Int = 24, elevated: Boolean = false)' "$PLAYER"
grep -Fq 'if (!p.light) return playerGlassSurface' "$PLAYER"
grep -Fq 'private fun playerSheetTextColor()' "$PLAYER"
grep -Fq 'private fun playerSheetMutedColor()' "$PLAYER"
grep -Fq 'private fun playerSheetAccentInk()' "$PLAYER"
grep -Fq 'private fun playerSheetTrackColor()' "$PLAYER"
grep -Fq 'playerSheetSurface(30, elevated = true)' "$PLAYER"
grep -Fq 'playerSheetTextColor()' "$PLAYER"
grep -Fq 'playerSheetMutedColor()' "$PLAYER"
grep -Fq 'View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR' "$PLAYER"

# Regression guard: subtitle background swatches must not be inserted twice.
python3 - "$PLAYER" <<'PY'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text(encoding='utf-8')
needle = 'bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43))'
if s.count(needle) != 1:
    raise SystemExit(f'FAIL: subtitle background swatch add count={s.count(needle)}')
PY
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text(encoding='utf-8')
a = s.index('fun yearChip(textValue: String): TextView')
b = s.index('item.optString("year").trim().takeIf', a)
chunk = s[a:b]
assert 'setTextColor(Color.WHITE)' in chunk, 'FAIL: poster year chip not explicit white'
assert 'setTextColor(white)' not in chunk, 'FAIL: poster year chip still uses theme white alias'
a = s.index('private fun weeklyScheduleCompactCell')
b = s.index('private fun addWeeklyScheduleSectionMobileV728', a)
chunk = s[a:b]
assert 'marginEnd = dp(12)' in chunk, 'FAIL: weekly poster/text gap missing'
PY

echo BANKMOVIE_V7471_21_DETAIL_YEAR_HERO_ICON_WEEKLY_PLAYER_LIGHT_OK
