#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/api5_lib.php >/dev/null
php -l server-required/includes/api4_lib.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
main = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
workflow = Path('.github/workflows/build-bankmovie.yml').read_text()
assert 'POSTER_CI_FIX_V22_5_4_1.zip' in workflow
assert 'verify_v22_5_4_1_poster_cards_ci.sh' in workflow
loader = main[main.index('private fun loadImage('):main.index('private fun animateExpandable(',main.index('private fun loadImage('))]
for required in ('instanceFollowRedirects = true', 'image/webp,image/jpeg,image/png',
    'conn.responseCode', 'status !in 200..299', 'Poster HTTPS redirect downgrade',
    'ImageDecoder.decodeBitmap', 'Unsupported poster format', 'BankMoviePoster',
    'pendingPosterTargets.remove(finalUrl)', 'PosterDiskCache.write'):
    assert required in loader, 'Missing image loader guard: ' + required
assert 'image/avif' not in loader
normalizer = main[main.index('private fun normalizeArchiveItem('):main.index('private fun normalizeArchiveResponse(')]
assert 'posterString(item.opt(key))' in normalizer
assert '"poster_url", "image", "image_url", "thumbnail", "thumb"' in normalizer
assert 'archive == 5' in normalizer and 'archive == 3 || archive == 4' in normalizer
# Make sure the old security + real API quota layers are still in source.
for token in ('BmV22Client.attach', 'BmApiRateLimit.requireContentOpenAllowed', 'quotaRequest(', 'archive5ApiUrl('):
    assert token in main
print('VERIFY_V22_5_4_1_POSTER_CARDS_CI_OK')
PYTEST
