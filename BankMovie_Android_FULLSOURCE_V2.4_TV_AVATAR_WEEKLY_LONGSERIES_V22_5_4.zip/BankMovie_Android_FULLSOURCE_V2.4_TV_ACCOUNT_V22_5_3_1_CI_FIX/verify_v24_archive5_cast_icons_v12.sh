#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
from xml.etree import ElementTree as ET
p=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
loader=Path('app/src/main/java/ir/bankmoviee/app/OrbitalGlowLoaderView.kt').read_text()
segment=p[p.index('private fun renderRemoteHomeSection('):p.index('private fun showHome()')]
for k in ['1 -> when (key)', '2 -> when (key)', '3 -> when (key)', '4 -> when (key)', '5 -> when (key)']:
    assert k in segment, f'Archive renderer missing {k}'
assert '5 -> when (key)' not in Path('verify_v24_bmadmin_archive5_guest_push_v11.sh').read_text() # confirms new regression added
for section in ['new_movies','new_series','turkish','animation']:
    assert f'addRail(page,' in segment
    assert f', 5, "{section}", false)' in segment, section
assert 'archive5SiteApiBase' in p and 'archive5=1&client=app' in p
assert 'hasArchive5' in p and 'archive5ApiUrl("id=' in p
assert 'item.optJSONObject("poster")' in p
assert 'bm_ic_actor_profile' in p and 'bm_ic_cast_group' in p
assert 'showActorAndCrewCatalogue(item)' in p
assert 'background = rounded(alphaSurface2(), dp(22), alphaLine(64))' not in p[p.index('private fun renderActors('):p.index('private fun infoGrid(')]
assert 'setOnScrollChangeListener' in p[p.index('private fun renderActors('):p.index('private fun infoGrid(')]
assert 'val glow = View(this).apply' not in p[p.index('private fun showSplashOnly()'):p.index('private fun showNetworkError(')]
assert 'canvas.drawCircle(64f, 64f, 56f, ringPaint)' not in loader
assert 'UiPreferences.accentColor(context)' in loader
for name in ['bm_ic_episode_play.xml','ic_copy_link.xml','bm_ic_cast_group.xml','bm_ic_actor_profile.xml','ic_seen_eye.xml','bm_ic_continue_watch.xml']:
    root=ET.parse(Path('app/src/main/res/drawable')/name).getroot()
    assert root.tag=='vector' and len(root)>0, name
print('V12_ARCHIVE5_CAROUSEL_ICONS_LOADER_OK')
PY
bash verify_v24_bmadmin_archive5_guest_push_v11.sh
