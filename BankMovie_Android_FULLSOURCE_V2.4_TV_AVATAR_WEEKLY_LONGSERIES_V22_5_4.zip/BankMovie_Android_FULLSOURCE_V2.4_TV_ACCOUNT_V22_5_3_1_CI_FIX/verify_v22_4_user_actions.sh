#!/usr/bin/env bash
# V22.4 backward-compatibility regression for V22.5 real-request quota.
# The V22.4 telemetry endpoint must no longer spend slots. Genuine old-APK
# detail requests and actual account operations still classify correctly.
set -euo pipefail
cd "$(dirname "$0")"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
cp server-required/v2/api/bm_security.php "$T/bm_security.php"
mkdir -p "$T/.private"
cat > "$T/test.php" <<'PHP'
<?php
error_reporting(E_ALL);
require __DIR__.'/bm_security.php';
$_SERVER['REMOTE_ADDR']='192.0.2.12';
$_SERVER['HTTPS']='on';
function quota(string $endpoint, string $method, array $query): ?string {
  $_SERVER['REQUEST_METHOD']=$method;
  $_GET=$query;
  $_POST=$method==='POST' ? $query : [];
  return bm22_billable_request_key($endpoint);
}
$id='00000000-0000-4000-8000-000000000007';
assert(quota('action','POST',['action'=>'category','id'=>'x','bm_q_request_id'=>$id])===null);
assert(quota('app_api','GET',['action'=>'detail','id'=>'tt1','bm_v224_click_reported'=>'1'])===null);
assert(quota('app_api','GET',['action'=>'detail','id'=>'tt1','bm_q_passive'=>'1'])===null);
$a=quota('app_api','GET',['action'=>'detail','id'=>'tt1','bm_v224_click_reported'=>'1','bm_v224_click_id'=>$id]);
$b=quota('app_api','GET',['action'=>'detail','id'=>'tt2','bm_v224_click_reported'=>'1','bm_v224_click_id'=>$id]);
assert(is_string($a) && $a===$b); // old retry identifier wins over the changing detail payload
assert(is_string(quota('app_api','GET',['action'=>'detail','id'=>'tt3']))); // V22.3 old APK
assert(quota('app_user_api','GET',['action'=>'me'])===null);
assert(quota('app_user_api','GET',['action'=>'watchlist_list'])===null);
assert(quota('app_user_api','POST',['action'=>'watchlist_sync'])===null);
assert(is_string(quota('app_user_api','GET',['action'=>'watchlist_list','bm_q_intent'=>'watchlist_view'])));
assert(is_string(quota('app_user_api','POST',['action'=>'watchlist_sync','bm_q_intent'=>'watchlist_change'])));
foreach (['login','register','avatar_update','comment_add'] as $action) {
  assert(is_string(quota('app_user_api','POST',['action'=>$action])), $action);
}
assert(quota('app_user_api','GET',['action'=>'login'])===null);
assert(quota('app_api','GET',['action'=>'home','bm_q_intent'=>'section'])===null);
echo "V22_4_OLD_APK_REAL_REQUEST_COMPAT_OK\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$T/test.php"
python3 - <<'PY'
from pathlib import Path
r=Path('app/src/main/java/ir/bankmoviee/app')
main=(r/'MainActivity.kt').read_text()
client=(r/'BmV22Client.kt').read_text()
account=(r/'AccountApi.kt').read_text()
security=Path('server-required/v2/api/bm_security.php').read_text()
action=Path('server-required/v2/api/action.php').read_text()
assert not (r/'BmUserActions.kt').exists()
assert 'BmUserActions' not in main and 'recordQuotaAction(' not in main
assert '"action.php"' not in client
assert 'bm22_limit_content_open' not in action
assert 'bm22_billable_request_key' in security
assert 'bm_q_intent=detail' in main
assert 'watchlist_change' in account and 'quotaView' in account
assert 'BmApiRateLimit.report(this@MainActivity' in main
assert 'سقف درخواست‌های واقعی' in Path('server-required/bm_admin.php').read_text()
assert not Path('server-required/v2/api/.private/signing.php').exists()
print('V22_4_NO_SYNTHETIC_CLICKS_AND_ACCOUNT_COMPAT_OK')
PY
