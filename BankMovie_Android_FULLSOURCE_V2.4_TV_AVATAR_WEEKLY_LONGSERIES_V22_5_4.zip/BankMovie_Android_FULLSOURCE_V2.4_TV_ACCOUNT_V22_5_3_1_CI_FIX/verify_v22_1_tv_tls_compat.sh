#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/v2/api/bm_security.php >/dev/null
php -l server-required/bm_admin.php >/dev/null
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main')
client=(root/'java/ir/bankmoviee/app/BmV22Client.kt').read_text()
player=(root/'java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
main=(root/'java/ir/bankmoviee/app/MainActivity.kt').read_text()
manifest=(root/'AndroidManifest.xml').read_text()
network=(root/'res/xml/network_security_config.xml').read_text()
php=Path('server-required/v2/api/bm_security.php').read_text()
admin=Path('server-required/bm_admin.php').read_text()
assert 'minSdk 23' in Path('app/build.gradle').read_text()
# Broken vendor Keystore must never hard-block a supported Android 6+ TV.
for part in ('AndroidKeyStore', 'keystoreUnavailable', 'keyWorks(backed)', 'KeyPairGenerator.getInstance("EC")',
             'installationKey = null', 'cache.clear()', 'no API endpoint permits an unsigned request'):
    assert part in client, f'KeyStore fallback missing {part}'
assert 'X-BM-Proof' in client and 'X-BM-Access-Token' in client
assert 'v2/api/auth.php' in client and 'BMV22-REGISTER' in client
assert 'private fun keyPair()' in client
assert 'getSharedPreferences(' not in client.split('private fun keyPair()',1)[1].split('private fun deviceId(',1)[0]
assert 'per-installation' in php and "(string)($claims['device']??'')" in php
assert "bm22_validate_proof" in php and "bm22_token_claims" in php
# The API/app reject cleartext. Only native LibVLC's MEDIA recovery is eligible.
assert 'android:usesCleartextTraffic="false"' in manifest
assert 'cleartextTrafficPermitted="false"' in network
assert 'V22 API requires HTTPS' in client
assert 'startsWith("https://", true)' in main
assert 'httpsHasSslFailure(' in player and 'HttpsURLConnection' in player
assert 'SSLException' in player and 'CertificateException' in player
assert 'verifySslBeforeMediaHttp(clean, emergencyMedia)' in player
assert 'conn.instanceFollowRedirects = false' in player
assert 'httpMediaFallbackApplied = false' in player
assert 'token|api[_-]?key' in player
assert 'host == "bankmovie.top"' in player
assert "$host==='*'" in admin
print('PASS: TV fallback with mandatory proof, HTTPS-only app/API, fresh SSL media check')
PY
# Functional PHP security regression inherited from V22.
bash verify_v22_security.sh
