#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
p="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
python3 - "$p" <<'PYVERIFY'
import sys,pathlib,re
s=pathlib.Path(sys.argv[1]).read_text()
assert 'val archive = sanitizeArchive(seed.optInt("archive", defaultArchive))' in s, 'Archive 5 must not fall back to Archive 1 detail'
assert '5 -> archive5ApiUrl("id=${enc(id)}&type=${enc(type)}")' in s, 'Archive 5 detail route missing'
assert 'archive5=1&client=app' in s, 'Archive 5 API route missing'
assert 'val downloads = json.optJSONArray("downloads")' in s, 'Archive 5 download contract missing'
assert 'item.optJSONObject("rating")?.let { details ->' in s, 'Archive 5 rating normalization missing'
assert 'R.drawable.bm_ic_episode_play' in s and 'titleKey.contains("فصل‌ها و قسمت‌ها")' in s, 'Season badge icon missing'
assert 'episodeHeader.addView(ImageView(this).apply {\n                setImageResource(R.drawable.bm_ic_episode_play)' not in s, 'Icon must not be beside individual episodes'
assert 'برای پخش روی دکمه سبز بزن.' not in s, 'Removed guidance reappeared'
assert 'val advance = ImageView(this).apply' not in s[s.index('private fun renderActors('):s.index('private fun infoGrid(')], 'Actor next arrow is still shown'
assert 'icon.setColorFilter(Color.WHITE)' in s, 'High contrast header icons missing'
assert 'android:fillAlpha="0.92"' in pathlib.Path('app/src/main/res/drawable/ic_seen_eye.xml').read_text()
print('V13_ARCHIVE5_DETAILS_UI_OK')
PYVERIFY
