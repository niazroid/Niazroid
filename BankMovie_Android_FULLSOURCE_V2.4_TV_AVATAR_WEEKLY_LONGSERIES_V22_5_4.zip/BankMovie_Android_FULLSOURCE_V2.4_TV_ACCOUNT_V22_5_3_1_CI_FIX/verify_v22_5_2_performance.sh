#!/usr/bin/env bash
# Performance regression checks. Does not require a live server or DB.
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_api.php >/dev/null
node --check app/src/main/assets/bm_explorer_v17.js >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=Path('server-required/app_api.php').read_text()
assert 'pendingApiRequests[requestKey]' in m
assert 'pendingApiRequests.remove(requestKey)' in m
assert 'requestKey = url + "\\u0000" + AccountSession.token(this)' in m
assert 'debounce.postDelayed(pendingSearch!!, 500L)' in m
assert 'debounce.postDelayed(pendingSearch!!, 550L)' in m
assert "bm_app_downloads_query_links($where, $ids, (int)$movieIdForOutput)" in a
assert 'WHERE fc.collection_id = c.id$orderSql LIMIT 1' in a
assert "foreach ($rows as &$row)" not in a[a.index('function bm_app_collections('):a.index('function bm_app_extract_slug_from_url(')]
PYTEST
php <<'PHPTEST'
<?php
$source=file_get_contents('server-required/app_api.php');
$extract=function($name) use($source) {
    $start=strpos($source,'function '.$name.'(');
    if($start===false) throw new Exception('Missing '.$name);
    $open=strpos($source,'{',$start); $depth=1;
    for($i=$open+1,$n=strlen($source);$i<$n;$i++) {
        if($source[$i]==='{') $depth++;
        elseif($source[$i]==='}' && --$depth===0) return substr($source,$start,$i-$start+1);
    }
    throw new Exception('Unclosed '.$name);
};
function bm_app_find_same_movie_rows($row) { return [['id'=>3],['id'=>4],['id'=>3]]; }
$GLOBALS['q']=0;
function bm_app_downloads_query_links($where,$ids,$movie) {
    $GLOBALS['q']++;
    if($where!=='movie_id IN (?,?)'||$ids!==[3,4]) throw new Exception('Wrong batch lookup');
    return [
        ['source_movie_id'=>4,'url'=>'https://cdn.example/b'],
        ['source_movie_id'=>3,'url'=>'https://cdn.example/a'],
        ['source_movie_id'=>4,'url'=>'https://cdn.example/a']
    ];
}
eval($extract('bm_app_downloads_from_same_movie_rows'));
$sourceIds=[];
$got=bm_app_downloads_from_same_movie_rows([],111,$sourceIds);
if($GLOBALS['q']!==1 || count($got)!==2 || $sourceIds!==[3,4] ||
   $got[0]['source_movie_id']!==3 || $got[1]['source_movie_id']!==4 ||
   $got[0]['resolved_by']!=='same_movie_identity') throw new Exception('Download N+1 regression');
class FakePDO { function query($sql) { $GLOBALS['sql']=$sql; $GLOBALS['calls']++; return new FakeRows; }}
class FakeRows {function fetchAll($type) { return [['id'=>1,'cover_image'=>'','fallback_cover_image'=>'posterA'],['id'=>2,'cover_image'=>'posterB','fallback_cover_image'=>'']]; }}
$GLOBALS['calls']=0;
function bm_app_pdo(){return new FakePDO;}
function bm_app_table_columns($table) {return match($table) {
 'collections'=>['id','status','cover_image'],
 'movies'=>['id','poster','imdb_code','year'],
 'collection_movies'=>['collection_id','movie_id','sort_order'],
 default=>[]};}
function bm_app_first_existing_column($table,$candidates){foreach($candidates as $c) if(in_array($c,bm_app_table_columns($table),true))return $c;return '';}
function bm_app_normalize_collection($row){return $row;}
eval($extract('bm_app_collections'));
$list=bm_app_collections(1,12);
if($GLOBALS['calls']!==1 || count($list['items'])!==2 ||
    !str_contains($GLOBALS['sql'],'AS fallback_cover_image') ||
    !str_contains($GLOBALS['sql'],'WHERE fc.collection_id = c.id')) throw new Exception('Collection N+1 regression');
echo "VERIFY_V22_5_2_PERFORMANCE_OK\n";
PHPTEST
