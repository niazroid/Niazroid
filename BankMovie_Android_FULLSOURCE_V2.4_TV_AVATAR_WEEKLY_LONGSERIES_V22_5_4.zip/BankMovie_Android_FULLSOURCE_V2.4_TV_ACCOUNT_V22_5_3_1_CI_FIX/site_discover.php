<?php
/** BankMovie Film Radar v4.4.5 — dual theme discovery experience. */
declare(strict_types=1);
require_once __DIR__.'/includes/security_bootstrap.php';
@include_once __DIR__.'/includes/_bm_support_widget.php';
require_once __DIR__.'/config.php';
require_once __DIR__.'/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
require_once __DIR__.'/includes/archive_control.php';
require_once __DIR__.'/includes/site_content_control.php';
require_once __DIR__.'/includes/user_theme.php';
require_once __DIR__.'/includes/public_assets.php';
require_once __DIR__.'/includes/bm_discover.php';
if (!headers_sent()) {header('Cache-Control: private, no-store');header('Vary: Cookie',false);}
$currentUser=$currentUser??null;
$userLang=(($_COOKIE['user_lang']??($currentUser['language']??'fa'))==='en')?'en':'fa';
$themeKey=bm_site_bool('ui_user_theme_enabled',true)?bm_theme_resolve(is_array($currentUser)?$currentUser:null):'dark-green';
$themeInfo=bm_theme_catalog()[$themeKey]??bm_theme_catalog()['dark-green'];
// The color palette (bm_theme_resolve) does NOT define light or dark.
// BankMovie's theme-init in the <head> sets html[data-bm-color-mode].
// No server-side color-mode guess and no class based on the accent theme.
$disabled=!bm_site_bool('discover_enabled',true)||!bm_archive_is_enabled('archive2')||!bm_archive_user_can_access('archive2',$currentUser);
if($disabled)http_response_code(403);
// Session-bound CSRF token for the new isolated Discover feedback API.
$bmfyToken='';
if(!$disabled && (int)($currentUser['id']??0)>0){
  if(session_status()!==PHP_SESSION_ACTIVE)@session_start();
  if(session_status()===PHP_SESSION_ACTIVE){
    if(!isset($_SESSION['bmfy_csrf']) || !is_string($_SESSION['bmfy_csrf']) || strlen($_SESSION['bmfy_csrf'])!==64)$_SESSION['bmfy_csrf']=bin2hex(random_bytes(32));
    $bmfyToken=$_SESSION['bmfy_csrf'];
    session_write_close();
  }
}

$catalog=['genres'=>[],'countries'=>[],'duration_available'=>false];
if(!$disabled)try{$catalog=bmd_catalog($pdo);}catch(Throwable $e){error_log('BM Film Radar catalog: '.$e->getMessage());}
$genres=array_slice($catalog['genres']??[],0,65);
$countries=array_slice($catalog['countries']??[],0,28);
// The showcase must never depend on the browser requesting a second API.
$featuredInitial=[];
if(!$disabled)try{$featuredInitial=bmd_featured_initial($pdo,5);}catch(Throwable $e){error_log('Discover featured initial: '.$e->getMessage());}
$timeTravel=[];
if(!$disabled)try{$timeTravel=bmd_time_travel_windows($pdo);}catch(Throwable $e){error_log('Discover time travel: '.$e->getMessage());}

$canArc1=bm_archive_is_enabled('archive1') && bm_archive_user_can_access('archive1',$currentUser);
// Explorer data must have functional HTML even when its secondary API is slow.
$mapGenres=array_slice($catalog['genres']??[],0,10);
$mapCountries=array_slice($catalog['countries']??[],0,12);
$categoryFallbacks=[
 'family'=>'/search?genre=Family',
 'completed'=>'/search?type=series',
 'continuing'=>'/search?type=series',
 'dubbed'=>'/search?dubbed=1',
 'topmovies'=>'/view_all?type=arc1_category&cat=top-movies',
 'topseries'=>'/view_all?type=arc1_category&cat=top-series',
 'hidden'=>'/search?rating=7',
 'collections'=>'/collections'
];

function bm4_icon(string $name,int $size=19):string {
  $paths=[
    'arrow'=>'<path d="M19 12H5m0 0 6-6m-6 6 6 6"/>','next'=>'<path d="m9 18 6-6-6-6"/>',
    'chev-right'=>'<path d="m10 6 6 6-6 6"/>','chev-left'=>'<path d="m14 6-6 6 6 6"/>',
    'shuffle'=>'<path d="M17 3h4v4M3 17h3c7 0 7-10 15-10M17 17h4v4M3 7h3c3 0 5 2 6 4M14 14c2 3 4 3 7 3"/>',
    'spark'=>'<path d="m12 2 2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2L12 2Z"/>',
    'movie'=>'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
    'search'=>'<circle cx="10.5" cy="10.5" r="7.5"/><path d="m16 16 5 5"/>',
    'sliders'=>'<path d="M5 3v18M12 3v18M19 3v18M2 8h6M9 15h6M16 10h6"/>',
    'heart'=>'<path d="M20.8 4.7a5.5 5.5 0 0 0-7.8 0l-1 1-1-1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.5a5.5 5.5 0 0 0 0-7.8Z"/>',
    'close'=>'<path d="M5 5 19 19M19 5 5 19"/>','check'=>'<path d="m4 12 5 5L20 6"/>',
    'layers'=>'<path d="m12 2 9 5-9 5-9-5 9-5ZM3 12l9 5 9-5M3 17l9 5 9-5"/>',
    'compass'=>'<circle cx="12" cy="12" r="9"/><path d="m16 8-3 5-5 3 3-5 5-3Z"/>',
    'star'=>'<path d="m12 2 3.2 6.6 7.3 1-5.2 5.1 1.3 7.3L12 18.6l-6.6 3.4 1.3-7.3-5.2-5.1 7.3-1z"/>',
    'play'=>'<path d="m9 5 11 7-11 7z"/>','refresh'=>'<path d="M3 11a9 9 0 1 1 3 7M3 17v-6h6"/>',
    'film'=>'<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M7 3v18M17 3v18M3 8h4M3 16h4M17 8h4M17 16h4"/>',
  ];
  return '<svg width="'.$size.'" height="'.$size.'" viewBox="0 0 24 24" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">'.($paths[$name]??$paths['spark']).'</svg>';
}
$moods=[
  ['excited','آدرنالین','روایت سریع و پرتنش'],['fun','خوش‌حال‌و‌هوا','کمدی‌های خوش‌ساخت'],
  ['romantic','دل‌نشین','روابط و عاشقانه‌ها'],['mystery','پر از راز','معما و جنایت'],
  ['scary','دلهره','ترس و تعلیق'],['calm','حال خوب','آرام و خانوادگی'],
  ['dream','بی‌مرز','فانتزی و علمی‌تخیلی'],['deep','تأثیرگذار','درام‌های ماندگار']
];
$mix=[
 ['excited','ضربان','از آرام تا پرهیجان','a'],['fun','نشاط','از جدی تا بامزه','b'],
 ['romantic','احساس','از سرد تا عاشقانه','c'],['mystery','راز','از روشن تا مرموز','d'],
 ['scary','دلهره','از امن تا ترسناک','e'],['calm','آرامش','از پرتنش تا ملایم','f'],
 ['dream','تخیل','از واقعیت تا خیال','g'],['deep','عمق قصه','از سبک تا تأمل‌برانگیز','h']
];
?>
<!doctype html><html lang="fa" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#080a10">
<script id="bm4-entry-top-v465">
(function(){
  'use strict';
  var path=String(location.pathname||'');
  var route=/^\/(?:discover|explore|exploare)(?:\.php)?\/?$/i.test(path);
  if(!route)return;
  var url;
  try{url=new URL(location.href);}catch(_e){return;}
  var fromMenu=url.searchParams.get('bm_entry')==='top';
  var oldExplorerHash=/^#(?:explorer|explore)$/i.test(location.hash||'');
  if(!fromMenu&&!oldExplorerHash)return;
  try{if('scrollRestoration' in history)history.scrollRestoration='manual';}catch(_e){}
  if(fromMenu){
    url.searchParams.delete('bm_entry');
    try{history.replaceState(history.state,'',url.pathname+url.search+url.hash);}catch(_e){}
  }
  if(oldExplorerHash){
    try{history.replaceState(history.state,'',location.pathname+location.search);}catch(_e){}
  }
  function top(){
    var root=document.documentElement,previous='';
    try{previous=root.style.scrollBehavior;root.style.scrollBehavior='auto';}catch(_e){}
    window.scrollTo(0,0);
    root.scrollTop=0;
    if(document.body)document.body.scrollTop=0;
    try{if(previous)root.style.scrollBehavior=previous;else root.style.removeProperty('scroll-behavior');}catch(_e){}
  }
  top();
  window.addEventListener('pageshow',function(){
    top();
    requestAnimationFrame(top);
    setTimeout(top,90);
  },{once:true});
  window.addEventListener('load',function(){requestAnimationFrame(top);},{once:true});
})();
</script>
<title>رادار فیلم | <?=bmd_escape(bm_site_get('site_name_fa','بانک مووی'))?></title>
<meta name="description" content="پیشنهاد فیلم و سریال بر اساس سلیقه، حال‌وهوا و فهرست‌های منتخب بانک‌مووی.">
<link rel="stylesheet" href="/assets/css/bm-global.css"><link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=146"><link rel="stylesheet" href="/assets/css/bm-discover.css?v=4.5.0">
<?php if(function_exists('bm_site_typography_head_markup'))echo bm_site_typography_head_markup(); ?>
<style>:root{--bm4-accent:<?=bmd_escape($themeInfo['primary'])?>;--bm4-rgb:<?=bmd_escape($themeInfo['rgb'])?>;--accent:<?=bmd_escape($themeInfo['primary'])?>;--accent-rgb:<?=bmd_escape($themeInfo['rgb'])?>}</style>
<link rel="stylesheet" href="/assets/css/bm-discover-white.css?v=4.5.0">
<link rel="stylesheet" href="/assets/css/bm-discover-moods.css?v=4.5.2">
<link rel="stylesheet" href="/assets/css/bm-native-explorer.css?v=4.6.1">
<link rel="stylesheet" href="/assets/css/bm-discover-loader.css?v=4.6.2">
<link rel="stylesheet" href="/assets/css/bm-discover-motion.css?v=4.6.4">
<link rel="stylesheet" href="/assets/css/bm-discover-viewport.css?v=4.6.5">
<link rel="stylesheet" href="/assets/css/bm-discover-for-you.css?v=1.0.0">
</head><body class="bm4-page" data-theme="<?=bmd_escape($themeKey)?>">

<?php require __DIR__.'/partials/shared_header.php'; ?>
<main id="main-content" class="bm4" data-discover-version="4.6.5">
<?php if($disabled):?><div class="bm4-unavailable"><h1>رادار فیلم برای این حساب در دسترس نیست</h1><p>برای فعال‌سازی این بخش، با پشتیبانی تماس بگیر.</p><a href="/">بازگشت به صفحه اصلی</a></div>
<?php else:?>
<section id="radar" class="bm4-hero bm4-reveal">
  <div class="bm4-stage" aria-label="اسلایدر پیشنهادهای ویژه">
    <div class="bm4-stage-glow" aria-hidden="true"></div>
    <div class="bm4-stack" id="bm4-stack"><div class="bm4-stack-placeholder"></div></div>
    <div class="bm4-stage-loader" id="bm4-stage-loader" aria-hidden="true" hidden><span class="bm4-loading-bars"><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i></span></div>
    <div class="bm4-stage-bottom"><div class="bm4-feature-caption"><div class="bm4-feature-kicker" id="bm4-feature-label">پیشنهادهای امشب</div><strong id="bm4-feature-name">در حال جستجو…</strong><span id="bm4-feature-meta">پوستر را بکش یا لمس کن</span></div><div class="bm4-stage-actions"><div class="bm4-stage-drag-hint">پوستر را بکش یا با دکمه‌ها جابه‌جا کن</div><div class="bm4-stage-buttons"><button type="button" id="bm4-prev" aria-label="پیشنهاد قبلی"><?=bm4_icon('chev-left',18)?></button><button type="button" id="bm4-next" aria-label="پیشنهاد بعدی"><?=bm4_icon('chev-right',18)?></button></div></div></div>
    <div class="bm4-pips" id="bm4-pips" aria-label="موقعیت در پیشنهادها"></div>
    <div class="bm4-stage-link"><button type="button" class="bm4-link" id="bm4-open">مشاهده جزئیات این عنوان <?=bm4_icon('arrow',15)?></button></div>
  </div>
  <div class="bm4-hero-copy"><div class="bm4-kicker"><span class="bm4-dot"></span>BANKMOVIE / FILM RADAR</div>
  <h1>امشب، چی ببینیم؟<br><span>یک انتخاب تازه پیدا کن.</span></h1>
  <p class="bm4-lead">حال‌وهوات رو انتخاب کن، پوسترها رو ورق بزن و فیلم بعدی‌ات رو پیدا کن.</p>
  <div class="bm4-hero-actions"><button id="bm4-fresh" type="button" class="bm4-btn bm4-primary"><?=bm4_icon('shuffle',17)?> پیشنهاد جدید</button><button id="bm4-surprise-run" type="button" class="bm4-btn bm4-soft"><?=bm4_icon('film',17)?> فیلم شانسی امشب</button><a href="#filters" class="bm4-btn bm4-quiet"><?=bm4_icon('sliders',17)?> فیلتر و انتخاب</a></div>
  <div class="bm4-moods" role="group" aria-label="انتخاب حال‌وهوا">
  <?php foreach($moods as $i=>$m):?><button type="button" data-mood="<?=bmd_escape($m[0])?>" aria-pressed="<?=$i===0?'true':'false'?>" class="bm4-mood<?=$i===0?' is-active':''?>"><span><?=bmd_escape($m[1])?></span><small><?=bmd_escape($m[2])?></small></button><?php endforeach; ?>
  </div>
  <div class="bm4-live-hint" id="bm4-hero-hint" aria-live="polite">یکی از حال‌وهواها را انتخاب کن تا فیلم‌های مناسبش را ببینی.</div>
  </div>
</section>
<section id="surprise" class="bm4-ticket-band bm4-reveal"><div class="bm4-ticket-copy"><span class="bm4-caption">QUICK PICK</span><strong>انتخاب شانسی امشب</strong><small>هنوز تصمیم نگرفتی؟ بگذار یک فیلم جذاب پیشنهاد بدهیم.</small></div><button id="bm4-surprise-run-2" type="button" class="bm4-btn bm4-primary"><?=bm4_icon('spark',17)?> باز کردن بلیت شانسی</button></section>
<!-- BankMovie Discover: real watchlist-powered recommendations, separate from mixer and AI quota. -->
<section id="bmfy" class="bm4-section" aria-labelledby="bmfy-title">
 <div class="bmfy-heading"><div><span class="bmfy-caption">BANKMOVIE / FOR YOU</span>
  <h2 id="bmfy-title"><span class="bmfy-heading-icon"><?=bm4_icon('spark',21)?></span> مخصوص سلیقه تو</h2>
  <p>از واچ‌لیست و انتخاب‌های قبلیت یاد می‌گیریم؛ هیچ فیلم ذخیره‌شده‌ای دوباره پیشنهاد نمی‌شه.</p></div>
  <div class="bmfy-heading-actions"><button type="button" class="bmfy-reload" data-bmfy-refresh><?=bm4_icon('refresh',16)?> به‌روزرسانی پیشنهادها</button></div>
 </div>
 <div class="bmfy-topline"><span class="bmfy-count" aria-live="polite">در حال بررسی سلیقه تو…</span><div class="bmfy-chips" aria-label="ژانرهای مورد علاقه"></div></div>
 <div class="bmfy-list" aria-live="polite"><div class="bmfy-skeleton"></div><div class="bmfy-skeleton"></div><div class="bmfy-skeleton"></div></div>
 <div class="bmfy-footer"><span class="bmfy-status" role="status" aria-live="polite">پیشنهادها فقط از اطلاعات واقعی بانک‌مووی ساخته می‌شن.</span>
  <button type="button" class="bmfy-more" data-bmfy-more hidden>پیشنهادهای بیشتر <?=bm4_icon('chev-left',15)?></button></div>
</section>
<?php require __DIR__.'/partials/bm_discover_native_explorer.php'; ?>
<section id="mixer" class="bm4-section bm4-reveal"><header class="bm4-heading"><div><span class="bm4-caption">THE TASTE CONSOLE</span><h2>میکس حال‌و‌هوا</h2><p>به هر حس امتیاز بده؛ پیشنهادها بر اساس ترکیب دلخواهت تغییر می‌کنند.</p></div></header>
<div class="bm4-console"><div class="bm4-console-controls"><div class="bm4-preset-bar"><strong>ترکیب‌های آماده</strong><button type="button" data-preset="pulse">هیجان بیشتر</button><button type="button" data-preset="light">سبک و سرگرم‌کننده</button><button type="button" data-preset="mind">فکری و رازآلود</button><button type="button" data-preset="reset">بازنشانی</button></div>
<div class="bm4-slider-grid">
<?php foreach($mix as $i=>$item):?><div class="bm4-slider-item" data-lane="<?=bmd_escape($item[0])?>" style="--lane:<?=$i?>"><div class="bm4-slider-caption"><label for="bm4-mix-<?=bmd_escape($item[0])?>"><?=bmd_escape($item[1])?><small><?=bmd_escape($item[2])?></small></label><output for="bm4-mix-<?=bmd_escape($item[0])?>" data-mix-value="<?=bmd_escape($item[0])?>">۰٪</output></div><div class="bm4-slider-shell"><input id="bm4-mix-<?=bmd_escape($item[0])?>" class="bm4-slider" type="range" data-mix="<?=bmd_escape($item[0])?>" min="0" max="100" step="5" value="<?= $item[0]==='excited'?65:($item[0]==='mystery'?30:0) ?>" aria-label="تنظیم <?=bmd_escape($item[1])?>"></div></div><?php endforeach; ?>
</div><div class="bm4-console-footer"><span>پس از اعمال ترکیب، نتیجه‌ها با اسکرول نرم نمایش داده می‌شوند.</span><button type="button" id="bm4-mix-run" class="bm4-btn bm4-primary">اعمال ترکیب <?=bm4_icon('arrow',17)?></button></div></div>
<div class="bm4-console-preview"><div class="bm4-console-glow"></div><span class="bm4-caption">CUSTOM FREQUENCY</span><h3>خروجی ترکیب</h3><p id="bm4-mix-description">اسلایدرها را جابه‌جا کن تا حال‌وهوای دلخواهت ساخته شود.</p><div class="bm4-mix-cover-grid" id="bm4-mix-covers"><div class="bm4-mini-placeholder"></div></div><button class="bm4-link" type="button" id="bm4-mix-show">نمایش پیشنهادهای ترکیب <?=bm4_icon('arrow',15)?></button></div></div>
</section>
<section id="explorer" class="bm4-section bm4-reveal" aria-labelledby="bm4-explorer-heading">
  <header class="bm4-heading"><div><span class="bm4-caption">BANKMOVIE / DISCOVER</span><h2 id="bm4-explorer-heading">از کجا شروع کنیم؟</h2><p>برای هر سلیقه، یک مسیر تازه برای تماشا.</p></div></header>
  <div class="bm4-path-grid" id="bm4-path-grid" aria-live="polite">
    <?php foreach(bmd_discover_categories() as $key=>$def): ?>
    <a href="<?=bmd_escape($categoryFallbacks[$key]??'/search')?>" class="bm4-path-card bm4-path-card--pending" data-cat="<?=bmd_escape($key)?>" style="--path-accent:<?=bmd_escape($def['color'])?>">
       <span class="bm4-path-copy"><strong><?=bmd_escape($def['label'])?></strong><small><?=bmd_escape($def['subtitle'])?></small><span class="bm4-path-count">برای مشاهده انتخاب کن</span></span>
       <span class="bm4-path-posters"><span class="bm4-path-preview-placeholder" aria-hidden="true"></span></span>
    </a>
    <?php endforeach; ?>
  </div>
  <p class="bm4-path-footnote">«ادامه‌دار» لزوماً به معنی پخش قسمت تازه در همین هفته نیست.</p>
</section>
<section id="featured-collections" class="bm4-section bm4-reveal bm4-featured-section" aria-labelledby="bm4-featured-heading">
  <header class="bm4-heading bm4-featured-heading"><div><span class="bm4-caption">FEATURED COLLECTIONS</span><h2 id="bm4-featured-heading">جهان‌هایی برای چند شب تماشا</h2><p>از داستان‌های چندقسمتی تا جهان‌های سینمایی فراموش‌نشدنی.</p></div>
  <a class="bm4-heading-link" href="/collections">همه کالکشن‌ها <?=bm4_icon('chev-left',17)?></a></header>
  <div class="bm4-collection-showcase" id="bm4-collection-showcase" aria-live="polite">
  <?php if($featuredInitial):foreach($featuredInitial as $i=>$c): ?>
    <a class="bm4-coll-card<?= $i===0?' bm4-coll-card--lead':'' ?>" href="<?=bmd_escape($c['url'])?>" aria-label="مشاهده کالکشن <?=bmd_escape($c['title'])?>">
      <span class="bm4-coll-background"><?php if(!empty($c['cover'])): ?><img class="bm4-coll-backdrop" src="<?=bmd_escape($c['cover'])?>" loading="lazy" alt="" decoding="async"><?php endif; ?></span>
      <span class="bm4-coll-trio">
      <?php foreach(array_slice($c['posters']??[],0,3) as $j=>$poster):?>
         <span class="bm4-coll-poster bm4-coll-poster-<?=$j?>"><img src="<?=bmd_escape($poster['poster'])?>" alt="پوستر <?=bmd_escape($poster['title']??'')?>" loading="lazy" decoding="async"></span>
      <?php endforeach; ?>
      </span>
      <span class="bm4-coll-info"><span class="bm4-coll-eyebrow"><?= $i===0?'انتخاب ویژه بانک‌مووی':'مجموعه سینمایی' ?></span>
      <strong class="bm4-coll-name"><?=bmd_escape($c['title'])?></strong><span class="bm4-coll-meta"><?=number_format((int)$c['count'])?> عنوان<?php if((int)$c['first_year']>1900&&(int)$c['last_year']>1900): ?> · <?=bmd_escape($c['first_year'])?>–<?=bmd_escape($c['last_year'])?><?php endif; ?></span><?php if(is_numeric($c['avg_rating']??null) && (float)$c['avg_rating']>0): ?><span class="bm4-coll-imdb" dir="ltr" title="میانگین امتیاز مجموعه در IMDb" aria-label="میانگین IMDb <?=bmd_escape(number_format((float)$c['avg_rating'],1,'.',''))?>"><b class="bm4-coll-imdb-score"><?=bmd_escape(number_format((float)$c['avg_rating'],1,'.',''))?></b><img src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy" width="28" height="14" decoding="async"></span><?php endif; ?>
      <span class="bm4-coll-action">مشاهده کالکشن <?=bm4_icon('chev-left',16)?></span></span>
    </a>
  <?php endforeach;else: ?>
    <div class="bm4-collection-wait"><strong>ویترین کالکشن‌ها فعلاً قابل دریافت نیست</strong><span>کالکشن‌های موجود را می‌توانی از صفحه اصلی مجموعه‌ها ببینی.</span><a href="/collections">مشاهده همه کالکشن‌ها</a></div>
  <?php endif; ?>
  </div>
  <div class="bm4-collection-extra" id="bm4-collection-extra" hidden></div>
  <div class="bm4-collection-bottom"><button type="button" class="bm4-btn bm4-soft" id="bm4-collections-toggle" <?= $featuredInitial?'':'hidden' ?>>نمایش کالکشن‌های بیشتر <?=bm4_icon('chev-left',16)?></button><a href="/collections" class="bm4-link">مرور همه مجموعه‌ها <?=bm4_icon('chev-left',16)?></a></div>
</section>
<?php if($timeTravel): ?><section id="time-travel" class="bm4-section bm4-reveal" aria-labelledby="bm4-time-heading">
  <header class="bm4-heading"><div><span class="bm4-caption">TIME TRAVEL</span><h2 id="bm4-time-heading">سفر در زمان</h2><p>فقط دهه دلخواهت را انتخاب کن و وارد آرشیو همان سال‌ها شو.</p></div></header>
  <div class="bm4-era-grid">
    <?php foreach($timeTravel as $era): ?><a class="bm4-era-card" href="/discover?year_min=<?= (int)$era['from'] ?>&amp;year_max=<?= (int)$era['to'] ?>" data-era-from="<?= (int)$era['from'] ?>" data-era-to="<?= (int)$era['to'] ?>" aria-label="مرور <?=bmd_escape($era['title'])?>">
      <span class="bm4-era-top"><span class="bm4-era-badge"><?=bmd_escape($era['range_label'])?></span><span class="bm4-coll-trio bm4-era-trio"><?php foreach(($era['posters']??[]) as $pi=>$poster): ?><span class="bm4-coll-poster bm4-coll-poster-<?=min(2,$pi)?>"><img src="<?=bmd_escape($poster['poster'])?>" alt="<?=bmd_escape($poster['title'])?>" loading="lazy" decoding="async"></span><?php endforeach; ?></span></span>
      <span class="bm4-era-body"><strong class="bm4-era-name"><?=bmd_escape($era['title'])?></strong><small class="bm4-era-meta"><?=number_format((int)$era['count'])?> عنوان در این بازه</small><span class="bm4-era-action">مرور بر اساس سال <?=bm4_icon('chev-left',15)?></span></span>
    </a><?php endforeach; ?>
  </div>
</section><?php endif; ?>

<section id="genre-map" class="bm4-section bm4-reveal" aria-labelledby="bm4-map-heading">
  <header class="bm4-heading"><div><span class="bm4-caption">GENRES &amp; COUNTRIES</span><h2 id="bm4-map-heading">نقشه ژانر و کشور</h2><p>ژانر یا کشور دلخواهت رو انتخاب کن.</p></div></header>
  <div class="bm4-taxonomy-grid">
    <div class="bm4-taxonomy-panel"><div class="bm4-taxonomy-label">ژانرها</div><div class="bm4-taxonomy-rows bm4-taxonomy-genres" id="bm4-map-genres">
    <?php if($mapGenres): $peak=max(1,max(array_column($mapGenres,'count')));foreach($mapGenres as $item): $value=bmd_text($item['name']??'',60);$count=(int)($item['count']??0);if($value===''||$count<=0)continue;$percent=max(7,min(100,$count/$peak*100)); ?>
      <a href="/search?genre=<?=rawurlencode($value)?>" class="bm4-taxonomy-row" data-bm-taxonomy="genre" data-name="<?=bmd_escape($value)?>"><strong class="bm4-taxonomy-name"><?=bmd_escape($value)?></strong><span class="bm4-taxonomy-count"><?=number_format($count)?></span><span class="bm4-taxonomy-bar" style="width:<?=round($percent,1)?>%"></span></a>
    <?php endforeach;else: ?><span class="bm4-taxonomy-loading">ژانرها در داده‌های فعلی پیدا نشدن. <a href="/genres">مرور ژانرها</a></span><?php endif; ?>
    </div></div>
    <div class="bm4-taxonomy-panel"><div class="bm4-taxonomy-label">کشورها</div><div class="bm4-taxonomy-rows" id="bm4-map-countries">
    <?php if($mapCountries): $peak=max(1,max(array_column($mapCountries,'count')));foreach($mapCountries as $item): $value=bmd_text($item['name']??'',80);$count=(int)($item['count']??0);if($value===''||$count<=0)continue;$percent=max(7,min(100,$count/$peak*100)); ?>
      <a href="/search?country=<?=rawurlencode($value)?>" class="bm4-taxonomy-row" data-bm-taxonomy="country" data-name="<?=bmd_escape($value)?>"><strong class="bm4-taxonomy-name"><?=bmd_escape($value)?></strong><span class="bm4-taxonomy-count"><?=number_format($count)?></span><span class="bm4-taxonomy-bar" style="width:<?=round($percent,1)?>%"></span></a>
    <?php endforeach;else: ?><span class="bm4-taxonomy-loading">کشوری برای نمایش پیدا نشد. <a href="/search">جستجوی فیلم</a></span><?php endif; ?>
    </div></div>
  </div>
</section>
<section id="filters" class="bm4-section bm4-reveal"><header class="bm4-heading"><div><span class="bm4-caption">SMART FILTER</span><h2>فیلتر روشن و دقیق</h2><p>ژانر، کشور و امتیاز را انتخاب کن تا گزینه‌ها محدودتر شوند.</p></div></header>
 <div class="bm4-filter-panel"><div class="bm4-fields">
    <label>نوع محتوا<select id="bm4-type"><option value="all">فیلم یا سریال</option><option value="movie">فقط فیلم</option><option value="series">فقط سریال</option></select></label>
    <label>ژانر<select id="bm4-genre"><option value="">طبق حال‌وهوا</option><?php foreach($genres as $g):?><option value="<?=bmd_escape($g['name'])?>"><?=bmd_escape($g['name'])?></option><?php endforeach;?></select></label>
    <label>کشور<select id="bm4-country"><option value="">بدون محدودیت</option><?php foreach($countries as $c):?><option value="<?=bmd_escape($c['name'])?>"><?=bmd_escape($c['name'])?></option><?php endforeach;?></select></label>
    <label>بازه زمانی<select id="bm4-year"><option value="1900">همه سال‌ها</option><option value="2020">۲۰۲۰ به بعد</option><option value="2015">۲۰۱۵ به بعد</option><option value="2000">۲۰۰۰ به بعد</option><option value="1980">۱۹۸۰ به بعد</option></select></label>
    <label>حداقل امتیاز<select id="bm4-rating"><option value="0">هر امتیازی</option><option value="6">۶ به بالا</option><option value="7">۷ به بالا</option><option value="8">۸ به بالا</option></select></label>
  </div><div class="bm4-filter-foot"><div class="bm4-active-filters" id="bm4-active-filters">ژانر مناسب حال‌وهوای انتخابی</div><div class="bm4-filter-actions"><button type="button" id="bm4-reset" class="bm4-text-btn">حذف فیلترها</button><button type="button" id="bm4-filter-run" class="bm4-btn bm4-primary">نمایش پیشنهادها <?=bm4_icon('arrow',16)?></button></div></div></div>
</section>
<section id="bm4-results" class="bm4-section bm4-reveal" aria-live="polite"><header class="bm4-heading"><div><span class="bm4-caption">YOUR NEXT WATCH</span><h2 id="bm4-result-title">پیشنهادهای رادار</h2><p id="bm4-result-meta">فیلم‌ها و سریال‌هایی برای سلیقه تو</p></div><div class="bm4-results-actions"><button type="button" id="bm4-more" class="bm4-btn bm4-soft"><?=bm4_icon('refresh',16)?> پیشنهاد تازه</button></div></header>
 <div class="bm4-results-surface" id="bm4-results-surface">
  <div class="bm4-poster-grid" id="bm4-grid"><div class="bm4-grid-loading"></div></div>
  <div id="bm4-results-loader" class="bm4-results-loader" role="status" aria-live="polite" aria-atomic="true" hidden>
   <div class="bm4-loading-chip"><span class="bm4-loading-bars" aria-hidden="true"><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i></span><span id="bm4-loading-label">در حال پیدا کردن پیشنهادها…</span></div>
  </div>
 </div>
 <nav class="bm4-results-pager bm4-bottom-pager" aria-label="صفحه‌بندی نتایج فیلم و سریال"><button type="button" id="bm4-page-prev" class="bm4-btn bm4-quiet"><?=bm4_icon('chev-right',14)?> صفحه قبل</button><span id="bm4-page-summary" aria-live="polite">صفحه ۱</span><button type="button" id="bm4-page-next" class="bm4-btn bm4-quiet">صفحه بعد <?=bm4_icon('chev-left',14)?></button></nav>
 <div class="bm4-results-footer" id="bm4-results-footer">برای دیدن جزئیات، روی پوستر بزن.</div>
</section>
<section id="taste" class="bm4-section bm4-reveal"><header class="bm4-heading"><div><span class="bm4-caption">TASTE DNA</span><h2>انتخاب با پوستر</h2><p>فقط با دیدن چند پوستر، سیستم حدس می‌زند بیشتر چه فضایی دوست داری.</p></div></header>
<div class="bm4-taste"><div class="bm4-taste-visual" id="bm4-taste-poster"></div><div class="bm4-taste-copy"><div class="bm4-taste-progress"><span id="bm4-taste-progress"></span></div><small id="bm4-taste-count">۱ از ۵</small><h3 id="bm4-taste-title">انتخاب فیلم‌ها…</h3><p id="bm4-taste-meta">پنج پوستر، پنج انتخاب</p><div class="bm4-taste-actions"><button id="bm4-taste-no" class="bm4-btn bm4-soft" type="button"><?=bm4_icon('close',16)?> رد می‌کنم</button><button id="bm4-taste-yes" class="bm4-btn bm4-primary" type="button"><?=bm4_icon('heart',16)?> می‌پسندم</button></div><button type="button" class="bm4-text-btn" id="bm4-taste-reset">پوسترهای تازه</button></div></div>
</section>
<section id="similar" class="bm4-section bm4-reveal"><header class="bm4-heading"><div><span class="bm4-caption">THE AFTERTASTE</span><h2>مشابه چه چیزی ببینم؟</h2><p>یک عنوان وارد کن تا آثار مشابه پیدا شوند؛ عنوان دوم هم برای ترکیب دو سلیقه اختیاری است.</p></div></header><div class="bm4-seed-form"><div class="bm4-seed-field"><label for="bm4-seed1">عنوان اول</label><div class="bm4-search-box"><?=bm4_icon('search',17)?><input id="bm4-seed1" placeholder="عنوان مورد علاقه‌ات…" type="search" autocomplete="off"></div><div class="bm4-search-results" id="bm4-seed1-list" hidden></div></div><div class="bm4-seed-field"><label for="bm4-seed2">عنوان دوم <small>(اختیاری)</small></label><div class="bm4-search-box"><?=bm4_icon('search',17)?><input id="bm4-seed2" placeholder="برای ترکیب دو سبک…" type="search" autocomplete="off"></div><div class="bm4-search-results" id="bm4-seed2-list" hidden></div></div><button id="bm4-similar-run" class="bm4-btn bm4-primary" type="button">نمایش آثار مشابه <?=bm4_icon('arrow',16)?></button></div>
<div class="bm4-personal-strip"><div><strong>پیشنهاد بر اساس سابقه تو</strong><p>اگر سابقه تماشا یا علاقه‌مندی ثبت شده باشد، نتیجه‌ها شخصی‌تر می‌شوند.</p></div><button type="button" class="bm4-btn bm4-soft" id="bm4-personal-run"><?=bm4_icon('spark',17)?> پیشنهاد براساس سابقه من</button></div>
</section>
<dialog class="bm4-dialog" id="bm4-dialog" aria-labelledby="bm4-dialog-title"><div class="bm4-dialog-inner"><button type="button" id="bm4-dialog-close" class="bm4-dialog-close" aria-label="بستن"><?=bm4_icon('close',18)?></button><div id="bm4-dialog-poster" class="bm4-dialog-art"></div><div class="bm4-dialog-content"><span class="bm4-caption">BANKMOVIE / SELECTION</span><h2 id="bm4-dialog-title"></h2><div class="bm4-dialog-subtitle" id="bm4-dialog-subtitle"></div><div class="bm4-dialog-tags" id="bm4-dialog-tags"></div><p>به نظرت مناسب امشبه؟</p><div class="bm4-dialog-actions"><a id="bm4-dialog-url" href="/search" class="bm4-btn bm4-primary">رفتن به صفحه عنوان <?=bm4_icon('arrow',17)?></a><button id="bm4-dialog-another" type="button" class="bm4-btn bm4-soft">یک عنوان دیگر</button></div></div></div></dialog>
<?php endif; ?></main>
<?php if(!$disabled) require __DIR__.'/partials/bm_discover_explorer_overlays.php'; ?>
<?php require_once __DIR__.'/includes/_bm_site_footer.php';bm_render_site_footer($userLang);?>
<?php if(is_file(__DIR__.'/partials/shared_bottom_nav.php')) require __DIR__.'/partials/shared_bottom_nav.php'; ?>
<?php /* Keep the AI assistant alongside Discover personalization. */ ?>
<?php if (!$disabled && is_file(__DIR__.'/partials/bm_ai_widget.php')) require_once __DIR__.'/partials/bm_ai_widget.php'; ?>
<?php if(!$disabled):?><script>window.BM4_BOOT=<?=json_encode(['api'=>'/api_discover.php','duration'=>(bool)($catalog['duration_available']??false),'loggedIn'=>!empty($currentUser['id'])],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script><script src="/assets/js/bm-discover.js?v=4.6.5" defer></script><?php endif;?>
<?php if(!$disabled): ?><script src="https://cdn.jsdelivr.net/npm/hls.js@1/dist/hls.min.js"></script><script src="/assets/js/bm-native-explorer.js?v=4.6.2" defer></script><?php endif; ?>
<?php if(!$disabled): ?><script>window.BMFY_BOOT=<?=json_encode(['api'=>'/api_discover_for_you.php','loggedIn'=>(int)($currentUser['id']??0)>0,'csrf'=>$bmfyToken],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT)?>;</script><script src="/assets/js/bm-discover-for-you.js?v=2.0.1" defer></script><?php endif; ?>
<script src="/assets/js/bm-header-tweaks.js?v=237001" defer></script></body></html>
