#!/usr/bin/env bash
# Read-only checks. Do not upload as a public PHP file, do not pass cookies or credentials.
set -euo pipefail
BASE="${1:-https://bankmovie.top}"
BASE="${BASE%/}"
TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT
for ROUTE in 'ping=1' 'section=new_movies&page=1&limit=2' 'section=new_series&page=1&limit=2' 'section=turkish&page=1&limit=2' 'section=animation&page=1&limit=2'; do
  URL="$BASE/api5.php?archive5=1&client=app&$ROUTE"
  STATUS="$(curl --silent --show-error --location --connect-timeout 8 --max-time 22 --output "$TMP" --write-out '%{http_code}' "$URL" || true)"
  ROUTE="$ROUTE" STATUS="$STATUS" BODY="$TMP" python3 - <<'PY'
import json,os
try:
    obj=json.load(open(os.environ['BODY'],encoding='utf-8'))
    if not isinstance(obj,dict): raise ValueError('JSON root is not object')
    items=obj.get('items') or obj.get('movies') or []
    print('Route:',os.environ['ROUTE'], 'HTTP:', os.environ['STATUS'], 'Status:',obj.get('status'), 'Count:',len(items), 'Error:',obj.get('error',''), 'Message:',obj.get('message',''))
except Exception as e:
    print('Route:',os.environ['ROUTE'], 'HTTP:',os.environ['STATUS'],'Non-JSON/unreachable response:',str(e))
PY
done
