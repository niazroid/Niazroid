#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MANIFEST='app/src/main/AndroidManifest.xml'
TRAILER='app/src/main/res/drawable/ic_trailer.xml'

grep -F 'PASS 4.7 — smart return position' "$MAIN" >/dev/null
! grep -F 'longArrayOf(0L, 90L, 220L, 480L, 900L, 1_600L, 2_800L)' "$MAIN" >/dev/null
! grep -F 'close { showAppDrawer(menuIcon) }' "$MAIN" >/dev/null

grep -F 'val genreScroll = HorizontalBankmovieSmoothScrollView(this)' "$MAIN" >/dev/null
grep -F 'genres.distinct().forEach { genre ->' "$MAIN" >/dev/null

grep -F 'private fun firstInstalledPackage' "$MAIN" >/dev/null
grep -F 'com.mxtech.videoplayer.ad' "$MAIN" >/dev/null
grep -F 'org.videolan.vlc' "$MANIFEST" >/dev/null
grep -F 'com.mxtech.videoplayer.pro' "$MANIFEST" >/dev/null
grep -F 'text = t("انتخاب برنامه…", "Choose an app…")' "$MAIN" >/dev/null

grep -F 'background = bankGlassDrawable(20, 224, 60, true)' "$MAIN" >/dev/null
grep -F '♕  BANKMOVIE VIP' "$MAIN" >/dev/null

grep -F 'android:viewportWidth="24"' "$TRAILER" >/dev/null
grep -F 'M15,9L17,3M7,9L9,3M1,9H23' "$TRAILER" >/dev/null

echo 'PASS4_7_PROFILE_GENRE_PLAYER_MODAL_OK'
