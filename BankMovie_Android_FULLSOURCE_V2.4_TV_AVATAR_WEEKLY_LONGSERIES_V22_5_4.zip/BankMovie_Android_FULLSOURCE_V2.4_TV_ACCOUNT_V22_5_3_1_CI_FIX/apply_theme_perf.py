from pathlib import Path
root=Path('/mnt/data/bm_android_v25_work/app/src/main/java/ir/bankmoviee/app')
p=root/'UiPreferences.kt'; s=p.read_text()
old='''            "purple" -> R.drawable.bankmovie_logo_dark_purple
            "pink" -> R.drawable.bankmovie_logo_dark_pink'''
new='''            "purple", "violet", "indigo" -> R.drawable.bankmovie_logo_dark_purple
            "pink", "rose", "coral" -> R.drawable.bankmovie_logo_dark_pink'''
assert old in s;s=s.replace(old,new)
old='''            "teal" -> R.drawable.bankmovie_logo_dark_cyan
            "white" ->''';new='''            "teal", "cyan", "ice", "mint" -> R.drawable.bankmovie_logo_dark_cyan
            "amber" -> R.drawable.bankmovie_logo_dark_orange
            "lime" -> R.drawable.bankmovie_logo_dark_green
            "white" ->'''
assert old in s;s=s.replace(old,new)
old='''        "pink" -> Color.rgb(236, 72, 153)        // dark-pink #ec4899
        "teal" -> Color.rgb(6, 182, 212)''';new='''        "pink" -> Color.rgb(236, 72, 153)        // dark-pink #ec4899
        "rose" -> Color.rgb(244, 63, 94)
        "coral" -> Color.rgb(255, 107, 107)
        "violet" -> Color.rgb(167, 103, 247)
        "indigo" -> Color.rgb(99, 102, 241)
        "amber" -> Color.rgb(251, 146, 60)
        "cyan" -> Color.rgb(34, 211, 238)
        "ice" -> Color.rgb(125, 211, 252)
        "mint" -> Color.rgb(52, 211, 153)
        "lime" -> Color.rgb(163, 230, 53)
        "teal" -> Color.rgb(6, 182, 212)'''
assert old in s;s=s.replace(old,new);p.write_text(s)
p=root/'MainActivity.kt';s=p.read_text()
old='''        listOf("gold", "blue", "orange", "red", "purple", "teal", "green").forEach { name ->'''
new='''        // More locally-selected themes, including pink/rose; no website sync.
        listOf("gold", "blue", "orange", "red", "pink", "rose", "coral", "purple", "violet", "indigo", "teal", "cyan", "ice", "mint", "green", "lime", "amber").forEach { name ->'''
assert old in s;s=s.replace(old,new)
# Performance: don't build per-season episode grouping arrays until the season opens.
old='''        val episodes = links.groupBy { it.optInt("episode", 0) }
            .toSortedMap(compareBy<Int> { if (it <= 0) Int.MAX_VALUE else it })

        val header ='''
new='''        // Long series (Walking Dead): count episode IDs without materializing
        // the full nested episode->qualities map for every collapsed season.
        val episodeCount = links.asSequence().map { it.optInt("episode", 0) }
            .filter { it > 0 }.distinct().count()

        val header ='''
assert old in s;s=s.replace(old,new,1)
old='''            text = episodes.keys.count { it > 0 }.takeIf { it > 0 }?.toString() ?: links.size.toString()'''
new='''            text = episodeCount.takeIf { it > 0 }?.toString() ?: links.size.toString()'''
assert old in s;s=s.replace(old,new,1)
old='''        fun ensureSeasonRows() {
            if (seasonRowsCreated) return
            seasonRowsCreated = true
            val linkPositions = allLinks.withIndex().associate { it.value to it.index }
        episodes.entries.forEachIndexed { episodeIndex, entry ->'''
new='''        fun ensureSeasonRows() {
            if (seasonRowsCreated) return
            seasonRowsCreated = true
            val episodes = links.groupBy { it.optInt("episode", 0) }
                .toSortedMap(compareBy<Int> { if (it <= 0) Int.MAX_VALUE else it })
            val linkPositions = allLinks.withIndex().associate { it.value to it.index }
        episodes.entries.forEachIndexed { episodeIndex, entry ->'''
assert old in s;s=s.replace(old,new,1)
p.write_text(s)
print('Added 10 new accents; deferred heavy episode grouping')
