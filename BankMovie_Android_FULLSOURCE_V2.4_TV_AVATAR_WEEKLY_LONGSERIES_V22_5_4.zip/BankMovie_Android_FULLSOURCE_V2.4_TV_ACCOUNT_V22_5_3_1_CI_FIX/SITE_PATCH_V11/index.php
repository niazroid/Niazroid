<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
@include_once __DIR__ . '/includes/_bm_support_widget.php';

require_once 'config.php';
// CSS cleanup V1: the homepage preloads the shared header styling in <head>.
if (!defined('BM_HOME_CSS_UNIFIED')) define('BM_HOME_CSS_UNIFIED', true);
// Removed Archive 8 bookmarks must not silently load a different archive.
if (in_array(strtolower(trim((string)($_GET['archive'] ?? ''))), ['8','archive8','arc8'], true)) { http_response_code(410); exit('Archive removed'); }

// V7.33.2: the home document is personalized/session-aware; never let a browser,
// proxy or stale PWA worker reuse an authenticated HTML shell.
if (!headers_sent()) {
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('Vary: Cookie', false);
}

// v2.1 gentle recovery: never unregister the PWA worker or purge CacheStorage
// just because one login token expired/revoked. The old hard recovery could make
// Chromium rebuild the whole frontend and leave the loading UI waiting.
if (isset($_GET['__bm_recover']) && (string)$_GET['__bm_recover'] === '7332') {
    if (!headers_sent()) header('X-BankMovie-Recovery-Page: 7332-gentle');
    ?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>بازیابی نشست | BankMovie</title><style>html,body{margin:0;min-height:100%;background:#05070d;color:#fff;font-family:Tahoma,Arial,sans-serif}body{min-height:100svh;display:grid;place-items:center;padding:24px}.bm-r{width:min(360px,92vw);text-align:center}.bm-r i{display:block;width:42px;height:42px;margin:0 auto 16px;border:3px solid rgba(255,255,255,.10);border-top-color:#2f7cff;border-radius:50%;animation:r .65s linear infinite}.bm-r strong{display:block;font-size:16px}.bm-r span{display:block;margin-top:8px;color:#9ca7bb;font-size:12px;line-height:1.9}@keyframes r{to{transform:rotate(360deg)}}</style>
</head><body><main class="bm-r"><i></i><strong>نشست قبلی منقضی شده</strong><span>در حال ورود امن به سایت بدون پاک‌کردن کش و اطلاعات آفلاین...</span></main><script>setTimeout(function(){location.replace('/?__bm_clean=7332-'+Date.now())},120);</script></body></html>
    <?php
    exit;
}

require_once __DIR__ . '/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
require_once __DIR__ . '/includes/db_housekeeping.php';
bm_dbh_maybe($pdo);
require_once __DIR__ . '/includes/site_content_control.php';
bm_site_maybe_redirect_maintenance();
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/bm_public_page_locale_v14862099.php';
require_once __DIR__ . '/includes/home_layout.php';
require_once __DIR__ . '/includes/bm_analytics.php';
require_once __DIR__ . '/includes/weekly_schedule.php';
$bmArchivePublicConfig = bm_archive_public_config();
if ((bm_archive_user_can_access('archive7', $currentUser ?? null)) && !headers_sent()) header('Vary: Cookie');
$bmHomeLayout = bm_home_layout_settings();
$bmHomeSliderEnabled = !empty(($bmHomeLayout['blocks']['slider'] ?? [])['enabled']);
// The administrator's saved default is authoritative on every fresh load.
// ?archive=N allows a safe, permission-checked one-page preview/recovery.
$bmArchiveDefaultMode = bm_archive_home_preferred_mode($currentUser ?? null);
$bmArchiveOrder = bm_archive_order(true);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// CSRF Token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Lightweight analytics
bm_analytics_track($pdo, ['page_type' => 'home', 'user_id' => $currentUser['id'] ?? null]);

// User Settings
$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) {
    $userTheme = 'dark-green';
}
$currentThemeInfo = $themes[$userTheme];
$themeHex = ltrim($currentThemeInfo['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

// تابع تبدیل اعداد فارسی به انگلیسی
function enNumbers($str) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($persian, $english, $str);
}

function bm_collection_year_range(array $col): string {
    $first = trim((string)($col['first_year'] ?? ''));
    $last = trim((string)($col['last_year'] ?? ''));
    if ($first === '' && $last === '') return '';
    if ($first === '') return enNumbers($last);
    if ($last === '') return enNumbers($first);
    $first = enNumbers($first); $last = enNumbers($last);
    return $first === $last ? $first : ($first . ' — ' . $last);
}


/** v14862120: v118 neon frame with the refresh glyph placed on the device itself. */
function bm_home_neon_heading($heading, $kind, $newText = 'NEW'): string {
    // v14862121: use the ACTUAL 3D neon artwork from the approved reference,
    // rather than drawing a simplified line icon.
    $icons = [
        'movie' => '<img class="bm-update-glyph bm-neon-reference-icon" src="/assets/images/bm-neon-movie-art-v14862121.webp" width="84" height="88" alt="" decoding="async">',
        'series' => '<img class="bm-update-glyph bm-neon-reference-icon" src="/assets/images/bm-neon-series-art-v14862121.webp" width="94" height="80" alt="" decoding="async">',
    ];
    $kind = $kind === 'series' ? 'series' : 'movie';
    $text = htmlspecialchars(trim((string)$heading), ENT_QUOTES, 'UTF-8');
    $badge = trim((string)$newText);
    $badgeHtml = $badge !== '' ? '<span class="bm-update-new">'.htmlspecialchars($badge, ENT_QUOTES, 'UTF-8').'</span>' : '';
    return '<div class="section-title bm-update-heading"><span class="bm-update-badge">'
        .'<span class="bm-update-art" aria-hidden="true">'.$icons[$kind].'</span>'
        .'<span class="bm-update-label">'.$text.'</span>'.$badgeHtml.'</span></div>';
}


/** v14862123 — slim, theme-synced category banners for dubbed / Turkish / Korean. */
function bm_home_genre_neon_heading($heading, $type, $tag = ''): string {
    $icons = [
        'dub' => '/assets/images/bm-neon-dub-v14862123.svg',
        'turkey' => '/assets/images/bm-neon-turkey-v14862123.svg',
        'korea' => '/assets/images/bm-neon-korea-v14862123.svg',
    ];
    if (!isset($icons[$type])) return '';
    $title = htmlspecialchars(trim((string)$heading), ENT_QUOTES, 'UTF-8');
    $tag = trim((string)$tag);
    $tagHtml = $tag === '' ? '' : '<span class="bm-genre-neon-tag">'.htmlspecialchars($tag, ENT_QUOTES, 'UTF-8').'</span>';
    return '<div class="section-title bm-genre-neon-heading bm-genre-neon--'.$type.'">'
        .'<span class="bm-genre-neon-badge">'
        .'<span class="bm-genre-neon-icon" aria-hidden="true"><img src="'.$icons[$type].'" width="40" height="40" alt="" decoding="async"></span>'
        .'<span class="bm-genre-neon-label">'.$title.'</span>'.$tagHtml.'</span></div>';
}



/** v14862128: guaranteed-rendered small vector badges; no HTTP image request. */
function bm_home_static_feature_svg(string $kind): string {
    static $svg = [];
    if (!$svg) {
        $svg['top'] = <<<'BMTOPSVG'
<svg aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64" fill="none"><defs><linearGradient id="gold" x1="13" y1="5" x2="51" y2="48" gradientUnits="userSpaceOnUse"><stop stop-color="#FFF6AD"/><stop offset=".33" stop-color="#FFC82D"/><stop offset=".68" stop-color="#EF9E13"/><stop offset="1" stop-color="#B65B12"/></linearGradient><linearGradient id="rim" x1="12" y1="2" x2="49" y2="39" gradientUnits="userSpaceOnUse"><stop stop-color="#FFFCE5"/><stop offset="1" stop-color="#EEA01F"/></linearGradient><filter id="gl"><feGaussianBlur stdDeviation="1.2"/></filter></defs><path d="M20 9h25v13c0 12-6 21-13 21S20 34 20 22V9Z" fill="url(#gold)" stroke="url(#rim)" stroke-width="2"/><path d="M20 16H10v5c0 12 5 17 14 17M45 16h9v5c0 12-5 17-14 17" stroke="url(#rim)" stroke-width="4" stroke-linecap="round"/><path d="M32 43v7M22 54h20v5H22z" fill="url(#gold)" stroke="#FFF0A0" stroke-width="2" stroke-linejoin="round"/><path d="m32 16 2.9 6 6.7 1-4.9 4.8 1.2 6.7-5.9-3.1-5.9 3.1 1.2-6.7-4.9-4.8 6.7-1z" fill="#FFF2A3" stroke="#F4A526" stroke-width=".7"/><path d="m11 10 1 3 3 1-3 1-1 3-1-3-3-1 3-1zM51 37l1 3 3 1-3 1-1 3-1-3-3-1 3-1z" fill="#5EE7FF"/><path d="M13 7h39M19 61h26" stroke="#FFC94F" stroke-opacity=".7" stroke-width="2" filter="url(#gl)"/></svg>
BMTOPSVG;
        $svg['animation'] = <<<'BMANIMSVG'
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 635" aria-hidden="true" focusable="false"><defs><linearGradient id="B" x1=".15" x2=".88" y1=".2" y2=".8"><stop stop-color="#54d2f9"/><stop offset=".35" stop-color="#008dc8"/><stop offset=".65" stop-color="#129ece"/><stop offset="1" stop-color="#064a92"/></linearGradient><radialGradient id="H" cx=".34" cy=".25" r=".8"><stop stop-color="#6de6ff"/><stop offset=".42" stop-color="#199acb"/><stop offset=".8" stop-color="#067ab9"/><stop offset="1" stop-color="#045487"/></radialGradient><radialGradient id="E"><stop stop-color="#ffecf6"/><stop offset=".65" stop-color="#eacde9"/><stop offset=".84" stop-color="#bb84b7"/><stop offset="1" stop-color="#703674"/></radialGradient><radialGradient id="C"><stop stop-color="#e4faff"/><stop offset=".55" stop-color="#a9e5fa"/><stop offset="1" stop-color="#32b7dd"/></radialGradient><radialGradient id="N" cx=".38" cy=".32" r=".65"><stop stop-color="#5e9ac1"/><stop offset=".45" stop-color="#275b8a"/><stop offset="1" stop-color="#10476c"/></radialGradient><linearGradient id="I" x1="0" y1="0" x2=".5" y2="1"><stop stop-color="#182636"/><stop offset=".7" stop-color="#01080e"/><stop offset="1" stop-color="#101a27"/></linearGradient></defs><path d="M144 241C119 211 93 135 62 92 44 68 30 73 18 96-9 143-8 184 17 219c26 37 76 80 126 87 26 3 33-40 1-65Z" fill="url(#B)" stroke="#095584" stroke-width="6"/><path d="M139 264C106 233 75 139 55 104 40 83 31 106 17 138-1 184 63 254 122 281c13 7 30-5 17-17Z" fill="url(#E)" stroke="#90518c" stroke-width="4"/><path d="M355 199c29-32 40-79 49-124 8-48 25-67 46-61 35 12 47 58 48 108 3 53-9 108-50 130-34 15-65 17-84-6Z" fill="url(#B)" stroke="#065f8f" stroke-width="7"/><path d="M386 213c24-34 29-81 39-134 6-31 17-42 32-26 29 35 34 104 20 143-16 49-49 56-91 38Z" fill="url(#E)" stroke="#884986" stroke-width="4"/><path d="M205 151C194 113 173 81 136 58l-22-8 18 18c29 24 42 48 43 97M288 151c2-49-17-84-23-115-5-21 0-30 10-32 1 34 30 78 38 144" fill="url(#B)" stroke="#0674af" stroke-width="6" stroke-linejoin="round"/><path d="M166 137q-19-18-30-14l28 25M301 134q18-9 30-4l-23 19" fill="#118dc4"/><path d="M175 311c-31 21-50 58-50 106 0 47 11 98 22 137 19 48 82 72 150 67 68-6 114-39 116-101 2-58-22-101-40-153-16-45-54-67-103-71-40-3-73 2-95 15Z" fill="url(#B)" stroke="#035c93" stroke-width="8"/><path d="M175 509c-30-9-72 3-94 30-20 25-23 48-8 61 21 22 76 12 106 0 24-10 35-44 18-69Z" fill="url(#B)" stroke="#096394" stroke-width="7"/><path d="M260 534c14-27 65-40 108-22 27 11 37 42 31 66-7 40-59 58-99 54-44-4-62-41-40-98Z" fill="url(#B)" stroke="#096394" stroke-width="7"/><path d="M194 349c-25 36-18 94 3 149 21 57 88 80 139 49 48-30 40-112 7-170-31-52-112-70-149-28Z" fill="url(#C)" opacity=".95"/><path d="M147 179c-6-38 36-59 60-61 17-17 43-20 59-8 30-10 58 11 76 26 28 2 51 27 61 58 20 63 14 114-33 143-52 35-143 44-205 5-47-30-71-93-57-130 8-17 21-27 39-33Z" fill="url(#H)" stroke="#066d9f" stroke-width="7" stroke-linejoin="round"/><path d="M129 281c13 28 59 45 108 51 59 9 118-2 158-39-11 38-61 61-118 67-74 7-126-14-148-51Z" fill="url(#C)"/><path d="M153 231c-3-39 23-63 48-56 25 7 42 39 41 85-11 15-49 26-76 9-8-9-12-25-13-38Z" fill="#68cdec" stroke="#046399" stroke-width="7"/><path d="M155 233c0-36 18-57 37-54 26 2 44 31 44 79-16 16-59 19-72 6-6-8-9-17-9-31Z" fill="#e6f6ff" stroke="#022032" stroke-width="5"/><path d="M162 232c-3-27 11-40 30-41 24 1 39 23 41 60-9 13-42 19-62 5-7-6-9-14-9-24Z" fill="url(#I)"/><ellipse cx="182" cy="209" rx="10" ry="11" fill="white"/><circle cx="204" cy="232" r="4" fill="#a6eaff" opacity=".7"/><path d="M344 210c6-30 23-48 41-40 18 8 27 33 26 62-1 19-9 28-24 30-32-1-42-24-43-52Z" fill="#a9effa" stroke="#075c8a" stroke-width="5"/><path d="M350 213c0-29 14-43 29-40 17 3 25 24 27 52-1 23-7 29-19 30-25-2-38-16-37-42Z" fill="#f8fcff" stroke="#032332" stroke-width="4"/><path d="M354 214c-1-26 9-37 21-38 16 1 25 24 25 47 0 21-9 28-19 29-17-2-27-17-27-38Z" fill="url(#I)"/><ellipse cx="369" cy="190" rx="8" ry="10" fill="white"/><path d="M151 190c14-22 36-26 52-18M340 165c18-20 38-17 49-8" fill="none" stroke="#02394d" stroke-width="6" stroke-linecap="round"/><path d="M240 247c2-32 26-57 54-60 29-2 57 25 58 52 2 28-17 48-40 54-32 10-64-2-70-27-2-6-3-13-2-19Z" fill="url(#N)" stroke="#1177a2" stroke-width="7"/><path d="M260 229c9-17 28-22 46-20 19 3 29 15 32 29" stroke="#96c9e6" stroke-width="9" stroke-linecap="round" fill="none" opacity=".6"/><path d="M267 266q11-1 20 16m24-13q10-10 20-6" fill="none" stroke="#164c69" stroke-width="8" stroke-linecap="round"/><path d="M163 310c53 17 171 34 235-28" stroke="#064b71" stroke-width="7" stroke-linecap="round" fill="none"/><path d="M165 317c74 44 182 26 225-19" stroke="#70d8f6" stroke-width="6" stroke-linecap="round" fill="none" opacity=".8"/><path d="M225 341q20 6 37 0" stroke="#2d9bc4" stroke-width="6" stroke-linecap="round" fill="none"/><path d="M135 275c7 12 18 18 28 21M384 271c9-3 17-8 21-17" fill="none" stroke="#64d2ed" stroke-width="7" stroke-linecap="round" opacity=".75"/><path d="M174 370c-48 8-68 43-63 78 4 35 40 64 66 53 30-12 45-45 34-79-6-24-16-41-37-52Z" fill="url(#B)" stroke="#08739f" stroke-width="7"/><path d="M344 365c44 6 65 40 59 83-6 39-41 58-72 51-22-6-42-27-29-64 7-27 23-57 42-70Z" fill="url(#B)" stroke="#08739f" stroke-width="7"/><path d="M171 450q20 19 36 14M345 454q-19 17-37 12" fill="none" stroke="#6de1f5" stroke-width="7" stroke-linecap="round" opacity=".6"/><path d="M190 466c16 5 25 17 35 29m-7-43c17 11 27 28 38 45m-8-41c17 13 23 25 33 43M320 469c-12 8-22 16-27 28m8-42c-13 6-21 15-30 35" stroke="#39739e" stroke-width="9" stroke-linecap="round" fill="none"/><ellipse cx="93" cy="569" rx="11" ry="13" fill="#185a87"/><ellipse cx="126" cy="559" rx="13" ry="14" fill="#185a87"/><ellipse cx="157" cy="573" rx="10" ry="13" fill="#185a87"/><ellipse cx="296" cy="589" rx="12" ry="14" fill="#165887"/><ellipse cx="338" cy="587" rx="13" ry="15" fill="#165887"/><ellipse cx="369" cy="575" rx="10" ry="12" fill="#165887"/><path d="M76 551q7-15 20-3M117 539q11-11 17 3M281 575q5-14 20-3M331 571q13-11 20 2" fill="none" stroke="#63b5d4" stroke-width="5" stroke-linecap="round" opacity=".75"/></svg>
BMANIMSVG;
    }
    return $svg[$kind] ?? '';
}

/** v14862125 — reuse the approved soft neon frame for top / anime / collections. */
function bm_home_feature_neon_heading($heading, $kind, $badge = ''): string {
    $icons = [
        'top' => '/assets/images/bm-neon-top-trophy-v14862125.svg',
        'anime' => '/assets/images/bm-anime-art-optimized-v14862115.svg',
        'animation' => '/assets/images/bm-stitch-animation-v14862127.svg',
        'collections' => '/assets/images/bm-collection-art-v14862115.svg',
    ];
    if (!isset($icons[$kind])) return '';
    $heading = htmlspecialchars(trim((string)$heading), ENT_QUOTES, 'UTF-8');
    $badge = htmlspecialchars(trim((string)$badge), ENT_QUOTES, 'UTF-8');
    $image = in_array($kind, ['top', 'animation'], true)
        ? bm_home_static_feature_svg($kind)
        : '<img src="'.$icons[$kind].'" width="42" height="42" alt="" loading="lazy" decoding="async">';
    $extraIconClass = $kind === 'anime' ? ' section-icon-anime bm-anime-art-icon' : ($kind === 'collections' ? ' bm-collection-round-icon' : '');
    $tagHtml = $badge === '' ? '' : '<span class="bm-feature-neon-tag" dir="ltr">'.$badge.'</span>';
    return '<div class="section-title bm-feature-neon-heading bm-feature-neon--'.$kind.'">'
        .'<span class="bm-feature-neon-frame">'
        .'<span class="bm-feature-neon-art section-icon-svg'.$extraIconClass.'" aria-hidden="true">'.$image.'</span>'
        .'<span class="bm-feature-neon-label">'.$heading.'</span>'.$tagHtml
        .'</span></div>';
}

/** v14862126 — match existing sections across all seven archives without inventing new sections. */
function bm_home_archive_neon_heading($archive, $kind, $fallback, $userLang = 'fa'): string {
    $title = (string)bm_public_home_section($archive, $kind, $fallback);
    // The public-section getter supplies the Persian/admin title by default.
    // Prefer already-existing English site-setting titles for English visitors.
    if ($userLang === 'en') {
        $defaults = [
            'new_movies' => ['home_new_movies_title_en', 'New Movies'],
            'new_series' => ['home_new_series_title_en', 'New Series'],
            'updated_animations' => ['home_updated_animations_title_en', 'Updated Animations'],
            'animations' => ['home_animations_title_en', 'Animations'],
            'animation' => ['home_animation_title_en', 'Animation & Anime'],
            'turkish' => ['home_turkish_title_en', 'Turkish Movies & Series'],
            'dubbed' => ['home_dubbed_title_en', 'Dubbed Movies'],
        ];
        if (isset($defaults[$kind])) {
            $title = (string)bm_site_get($defaults[$kind][0], $defaults[$kind][1]);
        }
    }
    switch ($kind) {
        case 'new_movies':
            return bm_home_neon_heading($title, 'movie', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW'));
        case 'new_series':
            return bm_home_neon_heading($title, 'series', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW'));
        case 'updated_animations':
        case 'animations':
            return bm_home_feature_neon_heading($title, 'animation');
        case 'animation':
            // Mixed animation/anime archive section uses the approved anime portrait.
            return bm_home_feature_neon_heading($title, 'anime');
        case 'turkish':
            return bm_home_genre_neon_heading($title, 'turkey');
        case 'dubbed':
            return bm_home_genre_neon_heading($title, 'dub', 'DUB');
        default:
            return '<div class="section-title">'.htmlspecialchars($title, ENT_QUOTES, 'UTF-8').'</div>';
    }
}

// Multi-language


// ========== BankMovie Front Ads Layer ==========
require_once __DIR__ . '/includes/manual_ads.php';
// ========== /BankMovie Front Ads Layer ==========


$t = [
    'fa' => [
        'site_title' => 'دانلود فیلم و سریال', 'stories' => 'استوری‌ها', 'search_placeholder' => 'جستجوی فیلم، سریال، بازیگر، کارگردان...',
        'advanced_search' => 'جستجوی پیشرفته', 'all' => 'همه', 'movie' => 'فیلم', 'series' => 'سریال', 'animation' => 'انیمیشن',
        'random' => 'تصادفی', 'genres' => 'ژانرها', 'popular_countries' => 'کشورهای محبوب', 'new_releases' => 'جدیدترین اکران',
        'new_releases_2025' => 'جدیدترین ریلیزهای ۲۰۲۵', 'latest_animations' => 'جدیدترین انیمیشن‌ها',
        'view_all' => (string)bm_site_get('home_view_all_label_fa','مشاهده همه'), 'admin_picks' => (string)bm_site_get('home_admin_picks_title_fa','پیشنهادات ویژه ادمین'), 'top_movies' => (string)bm_site_get('home_top_movies_title_fa','برترین فیلم‌ها'),
        'top_series' => (string)bm_site_get('home_top_series_title_fa','برترین سریال‌ها'), 'top_user_rated' => (string)bm_site_get('home_user_rated_title_fa','محبوب‌ترین نزد کاربران'), 'persian_dubbed' => (string)bm_site_get('home_dubbed_title_fa','دوبله فارسی'),
        'smart_suggestions' => (string)bm_site_get('home_suggestions_title_fa','پیشنهاد هوشمند برای شما'), 'recent_updates' => (string)bm_site_get('home_recent_updates_title_fa','آپدیت اخیر'), 'special_collections' => (string)bm_site_get('home_collections_title_fa','کالکشن‌های ویژه'),
        'movies_in_collection' => 'فیلم', 'load_more' => 'بارگذاری بیشتر', 'no_results' => 'نتیجه‌ای یافت نشد',
        'support_us' => 'حمایت مالی', 'support_text' => 'اگر از سایت بانک مووی راضی هستید، با یک حمایت کوچک در هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن', 'donate' => 'حمایت مالی',
        'home' => 'خانه', 'profile' => 'پروفایل', 'player' => 'پلیر', 'request' => 'درخواست فیلم و سریال', 'auth' => 'ثبت نام و ورود', 'account' => 'حساب کاربری', 'login' => 'ورود', 'register' => 'ثبت نام', 'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت', 'guest' => 'کاربر مهمان', 'notifications' => 'اعلان‌ها', 'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'download_story' => 'دانلود استوری', 'hold_to_pause' => 'نگه دارید برای مکث', 'swipe_to_navigate' => 'بکشید برای بعدی/قبلی',
        'notif_latest' => 'آخرین اعلان',
    ],
    'en' => [
        'site_title' => 'Download Movies & Series', 'stories' => 'Stories', 'search_placeholder' => 'Search movies, series, actors, directors...',
        'advanced_search' => 'Advanced Search', 'all' => 'All', 'movie' => 'Movie', 'series' => 'Series', 'animation' => 'Animation',
        'random' => 'Random', 'genres' => 'Genres', 'popular_countries' => 'Popular Countries', 'new_releases' => 'New Releases',
        'new_releases_2025' => 'New Releases 2025', 'latest_animations' => 'Latest Animations',
        'view_all' => 'View All', 'admin_picks' => 'Admin Picks', 'top_movies' => 'Top Movies', 'top_series' => 'Top Series',
        'top_user_rated' => 'Top User Rated', 'persian_dubbed' => 'Persian Dubbed', 'smart_suggestions' => 'Smart Suggestions for You',
        'recent_updates' => 'Recent Updates', 'special_collections' => 'Special Collections', 'movies_in_collection' => 'Movies',
        'load_more' => 'Load More', 'no_results' => 'No results found', 'support_us' => 'Support Us',
        'support_text' => 'All services on this site are free. If you would like to help us improve the site quality and renew the server, you can donate.',
        'close' => 'Close', 'donate' => 'Donate',
        'home' => 'Home', 'profile' => 'Profile', 'player' => 'Player', 'request' => 'Request Movie / Series', 'auth' => 'Login / Register', 'account' => 'Account', 'login' => 'Login', 'register' => 'Register',
        'logout' => 'Logout', 'admin_panel' => 'Admin Panel', 'guest' => 'Guest', 'notifications' => 'Notifications',
        'no_notifications' => 'No notifications', 'download_story' => 'Download story', 'hold_to_pause' => 'Hold to pause',
        'swipe_to_navigate' => 'Swipe to navigate', 'notif_latest' => 'Latest notification',
    ]
];

// تابع پرچم کامل
function getCountryFlag($countryName) {
    $countryCodes = [
        'Afghanistan' => 'AF', 'Albania' => 'AL', 'Algeria' => 'DZ', 'Andorra' => 'AD', 'Angola' => 'AO',
        'Argentina' => 'AR', 'Armenia' => 'AM', 'Australia' => 'AU', 'Austria' => 'AT', 'Azerbaijan' => 'AZ',
        'Bahamas' => 'BS', 'Bahrain' => 'BH', 'Bangladesh' => 'BD', 'Barbados' => 'BB', 'Belarus' => 'BY',
        'Belgium' => 'BE', 'Belize' => 'BZ', 'Benin' => 'BJ', 'Bhutan' => 'BT', 'Bolivia' => 'BO',
        'Bosnia and Herzegovina' => 'BA', 'Botswana' => 'BW', 'Brazil' => 'BR', 'Brunei' => 'BN', 'Bulgaria' => 'BG',
        'Burkina Faso' => 'BF', 'Burundi' => 'BI', 'Cabo Verde' => 'CV', 'Cambodia' => 'KH', 'Cameroon' => 'CM',
        'Canada' => 'CA', 'Central African Republic' => 'CF', 'Chad' => 'TD', 'Chile' => 'CL', 'China' => 'CN',
        'Colombia' => 'CO', 'Comoros' => 'KM', 'Congo' => 'CG', 'Costa Rica' => 'CR', 'Croatia' => 'HR',
        'Cuba' => 'CU', 'Cyprus' => 'CY', 'Czech Republic' => 'CZ', 'Denmark' => 'DK', 'Djibouti' => 'DJ',
        'Dominica' => 'DM', 'Dominican Republic' => 'DO', 'Ecuador' => 'EC', 'Egypt' => 'EG', 'El Salvador' => 'SV',
        'Equatorial Guinea' => 'GQ', 'Eritrea' => 'ER', 'Estonia' => 'EE', 'Eswatini' => 'SZ', 'Ethiopia' => 'ET',
        'Fiji' => 'FJ', 'Finland' => 'FI', 'France' => 'FR', 'Gabon' => 'GA', 'Gambia' => 'GM', 'Georgia' => 'GE',
        'Germany' => 'DE', 'Ghana' => 'GH', 'Greece' => 'GR', 'Grenada' => 'GD', 'Guatemala' => 'GT',
        'Guinea' => 'GN', 'Guinea-Bissau' => 'GW', 'Guyana' => 'GY', 'Haiti' => 'HT', 'Honduras' => 'HN',
        'Hungary' => 'HU', 'Iceland' => 'IS', 'India' => 'IN', 'Indonesia' => 'ID', 'Iran' => 'IR', 'Iraq' => 'IQ',
        'Ireland' => 'IE', 'Israel' => 'IL', 'Italy' => 'IT', 'Jamaica' => 'JM', 'Japan' => 'JP', 'Jordan' => 'JO',
        'Kazakhstan' => 'KZ', 'Kenya' => 'KE', 'Kiribati' => 'KI', 'Korea, North' => 'KP', 'Korea, South' => 'KR',
        'Kosovo' => 'XK', 'Kuwait' => 'KW', 'Kyrgyzstan' => 'KG', 'Laos' => 'LA', 'Latvia' => 'LV', 'Lebanon' => 'LB',
        'Lesotho' => 'LS', 'Liberia' => 'LR', 'Libya' => 'LY', 'Liechtenstein' => 'LI', 'Lithuania' => 'LT',
        'Luxembourg' => 'LU', 'Madagascar' => 'MG', 'Malawi' => 'MW', 'Malaysia' => 'MY', 'Maldives' => 'MV',
        'Mali' => 'ML', 'Malta' => 'MT', 'Marshall Islands' => 'MH', 'Mauritania' => 'MR', 'Mauritius' => 'MU',
        'Mexico' => 'MX', 'Micronesia' => 'FM', 'Moldova' => 'MD', 'Monaco' => 'MC', 'Mongolia' => 'MN',
        'Montenegro' => 'ME', 'Morocco' => 'MA', 'Mozambique' => 'MZ', 'Myanmar' => 'MM', 'Namibia' => 'NA',
        'Nauru' => 'NR', 'Nepal' => 'NP', 'Netherlands' => 'NL', 'New Zealand' => 'NZ', 'Nicaragua' => 'NI',
        'Niger' => 'NE', 'Nigeria' => 'NG', 'North Macedonia' => 'MK', 'Norway' => 'NO', 'Oman' => 'OM',
        'Pakistan' => 'PK', 'Palau' => 'PW', 'Palestine' => 'PS', 'Panama' => 'PA', 'Papua New Guinea' => 'PG',
        'Paraguay' => 'PY', 'Peru' => 'PE', 'Philippines' => 'PH', 'Poland' => 'PL', 'Portugal' => 'PT',
        'Qatar' => 'QA', 'Romania' => 'RO', 'Russia' => 'RU', 'Rwanda' => 'RW', 'Saint Kitts and Nevis' => 'KN',
        'Saint Lucia' => 'LC', 'Saint Vincent and the Grenadines' => 'VC', 'Samoa' => 'WS', 'San Marino' => 'SM',
        'Sao Tome and Principe' => 'ST', 'Saudi Arabia' => 'SA', 'Senegal' => 'SN', 'Serbia' => 'RS',
        'Seychelles' => 'SC', 'Sierra Leone' => 'SL', 'Singapore' => 'SG', 'Slovakia' => 'SK', 'Slovenia' => 'SI',
        'Solomon Islands' => 'SB', 'Somalia' => 'SO', 'South Africa' => 'ZA', 'South Sudan' => 'SS',
        'Spain' => 'ES', 'Sri Lanka' => 'LK', 'Sudan' => 'SD', 'Suriname' => 'SR', 'Sweden' => 'SE',
        'Switzerland' => 'CH', 'Syria' => 'SY', 'Taiwan' => 'TW', 'Tajikistan' => 'TJ', 'Tanzania' => 'TZ',
        'Thailand' => 'TH', 'Timor-Leste' => 'TL', 'Togo' => 'TG', 'Tonga' => 'TO', 'Trinidad and Tobago' => 'TT',
        'Tunisia' => 'TN', 'Turkey' => 'TR', 'Turkmenistan' => 'TM', 'Tuvalu' => 'TV', 'Uganda' => 'UG',
        'Ukraine' => 'UA', 'United Arab Emirates' => 'AE', 'United Kingdom' => 'GB', 'United States of America' => 'US',
        'Uruguay' => 'UY', 'Uzbekistan' => 'UZ', 'Vanuatu' => 'VU', 'Vatican City' => 'VA', 'Venezuela' => 'VE',
        'Vietnam' => 'VN', 'Yemen' => 'YE', 'Zambia' => 'ZM', 'Zimbabwe' => 'ZW'
    ];
    $countryName = trim((string)$countryName);
    $aliases = [
        'United States' => 'United States of America',
        'USA' => 'United States of America',
        'US' => 'United States of America',
        'UK' => 'United Kingdom',
        'UAE' => 'United Arab Emirates',
        'Soviet Union' => 'Russia',
        'Czechia' => 'Czech Republic',
        'South Korea' => 'Korea, South',
        'North Korea' => 'Korea, North',
    ];
    if(isset($aliases[$countryName])) $countryName = $aliases[$countryName];
    $code = $countryCodes[$countryName] ?? '';
    if($code) {
        $regionalOffset = 0x1F1E6;
        $firstChar = $regionalOffset + (ord($code[0]) - ord('A'));
        $secondChar = $regionalOffset + (ord($code[1]) - ord('A'));
        return '&#' . $firstChar . ';&#' . $secondChar . ';';
    }
    return '🏳️';
}
function e($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function js_json($value) {
    return json_encode(
        $value,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    );
}

// ========== گرفتن دیتا از دیتابیس ==========
$stmt = $pdo->query("SELECT * FROM stories ORDER BY story_order ASC");
$stories = $stmt->fetchAll();
foreach ($stories as &$bmStoryRow) {
    foreach (['file_path','thumbnail_path','thumb_path','poster_path','cover_path','cover_image','thumbnail','poster','cover','image','image_path'] as $bmStoryAssetKey) {
        if (array_key_exists($bmStoryAssetKey, $bmStoryRow)) {
            $bmStoryRow[$bmStoryAssetKey] = bm_public_asset_url($bmStoryRow[$bmStoryAssetKey], '');
        }
    }
}
unset($bmStoryRow);

$adminPicks = $movie->getAdminPicks(20);
// جدیدترین اکران - شامل ریلیزهای ۲۰۲۵ هم میشه
$newReleases = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        ORDER BY 
            CASE WHEN year >= 2025 THEN 1 ELSE 0 END DESC,
            created_at DESC,
            year DESC,
            imdb_rate DESC
        LIMIT 20
    ");
    $stmt->execute();
    $newReleases = $stmt->fetchAll();
    if(count($newReleases) === 0) {
        $newReleases = $movie->getNewReleases(20);
    }
} catch(PDOException $e) {
    $newReleases = $movie->getNewReleases(20);
}
$topMovies = $movie->getTopRated('movie', 20);
$topSeries = $movie->getTopRated('tvSeries', 20);

$updatedMovies = $movie->getUpdatedMovies(20);

// V96 — آرشیو ۲ دیتابیس: فقط دیتاست‌های لازم برای صفحه اصلی
$newMovies = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies
        WHERE type = 'movie'
        ORDER BY created_at DESC, id DESC
        LIMIT 20
    ");
    $stmt->execute();
    $newMovies = $stmt->fetchAll();
} catch(PDOException $e) {
    $newMovies = [];
}

$updatedSeries = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies
        WHERE type = 'tvSeries' OR type = 'tvMiniSeries'
        ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
        LIMIT 20
    ");
    $stmt->execute();
    $updatedSeries = $stmt->fetchAll();
} catch(PDOException $e) {
    $updatedSeries = [];
}

// دوبله فارسی بر اساس جدیدترین اضافه شده
$dubbedMovies = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE dubbed = 1 OR dubbed = 'true' OR dubbed = 'fa' 
           OR persian_dubbed = 1 OR has_dubbed = 1
           OR (audio_languages IS NOT NULL AND audio_languages LIKE '%fa%')
           OR (audio_languages IS NOT NULL AND audio_languages LIKE '%Persian%')
        ORDER BY created_at DESC, id DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $dubbedMovies = $stmt->fetchAll();
    if(count($dubbedMovies) === 0) {
        $dubbedMovies = $movie->getDubbed(20);
    }
} catch(PDOException $e) {
    $dubbedMovies = $movie->getDubbed(20);
}

// ریلیزهای جدید ۲۰۲۵
$newReleases2025 = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE year >= 2025 
        ORDER BY year DESC, created_at DESC, imdb_rate DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $newReleases2025 = $stmt->fetchAll();
} catch(PDOException $e) {
    $newReleases2025 = [];
}

// جدیدترین انیمیشن‌ها
$latestAnimations = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE (genres LIKE '%Animation%' OR genres LIKE '%Kids%' OR type = 'animation')
        ORDER BY created_at DESC, year DESC, imdb_rate DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $latestAnimations = $stmt->fetchAll();
} catch(PDOException $e) {
    $latestAnimations = [];
}

$activeCollections = $pdo->query("
    SELECT c.*, COUNT(cm.id) as movie_count, MIN(m.year) as first_year, MAX(m.year) as last_year
    FROM collections c
    LEFT JOIN collection_movies cm ON c.id = cm.collection_id
    LEFT JOIN movies m ON cm.movie_id = m.id
    WHERE c.status = 1
    GROUP BY c.id
    ORDER BY c.id DESC
    LIMIT 20
")->fetchAll();

$topUserRated = [];
try {
    $stmt = $pdo->prepare("
        SELECT m.*, COALESCE(r.avg_rating,0) as user_rating, COALESCE(r.total_votes,0) as total_votes
        FROM movies m LEFT JOIN movie_ratings r ON m.id=r.movie_id
        WHERE COALESCE(r.total_votes,0)>0
        ORDER BY COALESCE(r.avg_rating,0) DESC, COALESCE(r.total_votes,0) DESC LIMIT 20
    ");
    $stmt->execute();
    $topUserRated = $stmt->fetchAll();
    if(count($topUserRated)===0){
        $stmt = $pdo->prepare("
            SELECT m.*, AVG(c.rating) as user_rating, COUNT(c.id) as total_votes
            FROM movies m INNER JOIN comments c ON m.id=c.movie_id
            WHERE c.rating>0 AND c.status='active'
            GROUP BY m.id HAVING COUNT(c.id)>=1
            ORDER BY AVG(c.rating) DESC, COUNT(c.id) DESC LIMIT 20
        ");
        $stmt->execute();
        $topUserRated = $stmt->fetchAll();
    }
} catch(PDOException $e) { $topUserRated = []; }

$smartSuggestions = [];
if($currentUser){
    $stmt = $pdo->prepare("
        SELECT DISTINCT m.genres, m.actors 
        FROM (SELECT movie_id FROM watch_history WHERE user_id=? UNION SELECT movie_id FROM watchlist WHERE user_id=?) AS watched
        JOIN movies m ON watched.movie_id=m.id
        WHERE (m.genres IS NOT NULL AND m.genres!='') OR (m.actors IS NOT NULL AND m.actors!='') LIMIT 10
    ");
    $stmt->execute([$currentUser['id'], $currentUser['id']]);
    $userInterests = $stmt->fetchAll();
    $keywords = [];
    foreach($userInterests as $interest){
        if(!empty($interest['genres'])){
            foreach(explode(',', $interest['genres']) as $g){ $g=trim($g); if(strlen($g)>2) $keywords[]=$g; }
        }
        if(!empty($interest['actors'])){
            foreach(explode(',', $interest['actors']) as $a){ $a=trim($a); if(strlen($a)>2) $keywords[]=$a; }
        }
    }
    $keywords = array_unique($keywords);
    if(count($keywords)>0){
        $conditions = []; $params = [];
        foreach($keywords as $kw){
            $conditions[] = "(m.genres LIKE ? OR m.actors LIKE ?)";
            $params[] = "%{$kw}%"; $params[] = "%{$kw}%";
        }
        $whereSql = implode(" OR ", $conditions);
        $sql = "SELECT DISTINCT m.* FROM movies m WHERE ($whereSql) AND m.id NOT IN (SELECT movie_id FROM watch_history WHERE user_id=?) AND m.id NOT IN (SELECT movie_id FROM watchlist WHERE user_id=?) ORDER BY m.imdb_rate DESC LIMIT 20";
        $params[] = $currentUser['id']; $params[] = $currentUser['id'];
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $smartSuggestions = $stmt->fetchAll();
    }
}

$genresList = $pdo->query("
    SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) as genre
    FROM movies CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers
    WHERE genres IS NOT NULL AND genres != ''
    HAVING genre != '' AND genre IS NOT NULL ORDER BY genre
")->fetchAll(PDO::FETCH_COLUMN);

$genrePersian = [
    'Action'=>'اکشن','Adventure'=>'ماجراجویی','Animation'=>'انیمیشن','Comedy'=>'کمدی',
    'Crime'=>'جنایی','Drama'=>'درام','Documentary'=>'مستند','Family'=>'خانوادگی',
    'Fantasy'=>'فانتزی','History'=>'تاریخی','Horror'=>'ترسناک','Kids'=>'کودکان',
    'Music'=>'موسیقی','Mystery'=>'معمایی','Romance'=>'عاشقانه','Sci-Fi'=>'علمی تخیلی',
    'Thriller'=>'هیجان‌انگیز','War'=>'جنگی','Western'=>'وسترن','Biography'=>'زندگی‌نامه','Sport'=>'ورزشی'
];

$allCountries = [
    'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Argentina', 'Armenia', 'Australia', 'Austria', 'Azerbaijan',
    'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia',
    'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia', 'Cameroon',
    'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo', 'Costa Rica', 'Croatia',
    'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador',
    'Equatorial Guinea', 'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia',
    'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras',
    'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan',
    'Kazakhstan', 'Kenya', 'Kiribati', 'Korea, North', 'Korea, South', 'Kosovo', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia',
    'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Madagascar', 'Malawi', 'Malaysia',
    'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Micronesia', 'Moldova', 'Monaco',
    'Mongolia', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Zealand',
    'Nicaragua', 'Niger', 'Nigeria', 'North Macedonia', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestine', 'Panama',
    'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda',
    'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe',
    'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands',
    'Somalia', 'South Africa', 'South Sudan', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Syria',
    'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey',
    'Turkmenistan', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States of America', 'Uruguay',
    'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'
];

// Notifications
$notificationsList = [];
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
$stmt->execute();
$notificationsList = $stmt->fetchAll();
// The first row from this already-sorted result is the same active notification
// the old second query fetched. Reuse it to avoid an extra database round-trip.
$latestNotification = !empty($notificationsList) ? $notificationsList[0] : null;
$activeNotification = $latestNotification;
$notificationSeen = false;
if($activeNotification) {
    $cookieName = 'notification_seen_' . $activeNotification['id'];
    if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
}
// Cinematic pop-up campaigns: independent audience targeting and persistent per-account acknowledgement.
require_once __DIR__ . '/includes/bm_popup_notices.php';
$bmModernNotice = bm_popup_first_unseen($pdo, is_array($currentUser ?? null) ? $currentUser : null);
if ($bmModernNotice) {
    $activeNotification = $bmModernNotice;
    $notificationSeen = false;
}

// Slider slides
$sliderSlides = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM slider_slides WHERE is_active = 1 ORDER BY slide_order ASC");
    $stmt->execute();
    $sliderSlides = $stmt->fetchAll();
    foreach ($sliderSlides as &$bmSlideRow) { $bmSlideRow['image_path'] = bm_public_asset_url($bmSlideRow['image_path'] ?? '', ''); } unset($bmSlideRow);
} catch (PDOException $e) {
    $sliderSlides = [];
}

// Home SEO is deliberately stable and independent from cookies, slider titles and archive state.
// This prevents search engines from receiving a different title/description on separate crawls.
$bmSeoCanonical = function_exists('bm_seo_base_url') ? (bm_seo_base_url() . '/') : rtrim(SITE_URL, '/') . '/';
$bmSeoTitle = trim((string)bm_site_get('seo_home_title', 'بانک مووی | دانلود فیلم و سریال با دوبله و زیرنویس فارسی'));
$bmSeoDescription = trim((string)bm_site_get('seo_home_description', 'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله فارسی، زیرنویس فارسی و لینک مستقیم در بانک مووی.'));
$bmSeoImage = function_exists('bm_seo_default_image') ? bm_seo_default_image() : ($bmSeoCanonical . 'assets/brand/bankmovie-og.png');
$bmSeoSameAs = array_values(array_filter([
    bm_site_bool('telegram_enabled', true) ? trim((string)bm_site_get('telegram_url','')) : '',
    bm_site_bool('instagram_enabled', true) ? trim((string)bm_site_get('instagram_url','')) : '',
]));
$bmSeoSchema = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'WebSite',
            '@id' => $bmSeoCanonical . '#website',
            'url' => $bmSeoCanonical,
            'name' => 'بانک مووی',
            'alternateName' => ['BankMovie', 'Bank Movie'],
            'inLanguage' => 'fa-IR',
            'publisher' => ['@id' => $bmSeoCanonical . '#organization'],
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => [
                    '@type' => 'EntryPoint',
                    'urlTemplate' => $bmSeoCanonical . '/search?q={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ],
        [
            '@type' => 'Organization',
            '@id' => $bmSeoCanonical . '#organization',
            'name' => (string)bm_site_get('seo_organization_name','بانک مووی'),
            'alternateName' => 'BankMovie',
            'url' => $bmSeoCanonical,
            'sameAs' => $bmSeoSameAs,
            'logo' => [
                '@type' => 'ImageObject',
                'url' => function_exists('bm_seo_abs_url') ? bm_seo_abs_url((string)bm_site_get('seo_organization_logo','/assets/brand/bankmovie-icon.png')) : $bmSeoCanonical . 'assets/brand/bankmovie-icon.png',
                'width' => 512,
                'height' => 512,
            ],
        ],
        [
            '@type' => 'WebPage',
            '@id' => $bmSeoCanonical . '#webpage',
            'url' => $bmSeoCanonical,
            'name' => $bmSeoTitle,
            'description' => $bmSeoDescription,
            'isPartOf' => ['@id' => $bmSeoCanonical . '#website'],
            'about' => ['@id' => $bmSeoCanonical . '#organization'],
            'breadcrumb' => ['@id' => $bmSeoCanonical . '#breadcrumb'],
            'primaryImageOfPage' => [
                '@type' => 'ImageObject',
                'url' => $bmSeoImage,
                'width' => 1200,
                'height' => 630,
            ],
            'inLanguage' => 'fa-IR',
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $bmSeoCanonical . '#breadcrumb',
            'itemListElement' => [
                ['@type'=>'ListItem','position'=>1,'name'=>'بانک مووی','item'=>$bmSeoCanonical],
            ],
        ],
    ],
];
?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>" data-bm-archive="<?= e($bmArchiveDefaultMode) ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <link rel="preload" href="/assets/fonts/bonVF.woff2" as="font" type="font/woff2" crossorigin>
    <?php if ($bmHomeSliderEnabled && !empty($sliderSlides[0]['image_path'])): ?>
    <link rel="preload" as="image" href="<?= e($sliderSlides[0]['image_path']) ?>" fetchpriority="high">
    <?php endif; ?>
    <meta name="csrf-token" content="<?= e($csrf_token) ?>">

    <!-- Stable homepage SEO: do not derive these tags from cookies, slider content or archive tabs. -->
    <title><?= e($bmSeoTitle) ?></title>
    <meta name="description" content="<?= e($bmSeoDescription) ?>">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="application-name" content="بانک مووی">
    <meta name="apple-mobile-web-app-title" content="بانک مووی">
    <link rel="canonical" href="<?= e($bmSeoCanonical) ?>">

    <meta property="og:type" content="website">
    <meta property="og:locale" content="fa_IR">
    <meta property="og:site_name" content="بانک مووی">
    <meta property="og:title" content="<?= e($bmSeoTitle) ?>">
    <meta property="og:description" content="<?= e($bmSeoDescription) ?>">
    <meta property="og:url" content="<?= e($bmSeoCanonical) ?>">
    <meta property="og:image" content="<?= e($bmSeoImage) ?>">
    <meta property="og:image:secure_url" content="<?= e($bmSeoImage) ?>">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="لوگوی بانک مووی">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($bmSeoTitle) ?>">
    <meta name="twitter:description" content="<?= e($bmSeoDescription) ?>">
    <meta name="twitter:image" content="<?= e($bmSeoImage) ?>">

    <script type="application/ld+json"><?= json_encode($bmSeoSchema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
  <style>:root{--bm-accent:<?= e($currentThemeInfo['primary']) ?>;--bm-accent-rgb:<?= e($currentThemeRgbCss) ?>;--bm-accent-dark:<?= e($currentThemeInfo['primary']) ?>cc;}</style>
<!-- bundled: /assets/css/index-inline-1.css -->
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script src="/assets/js/index-inline-1.js?v=7332-hard"></script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<!-- bundled: /assets/css/bm-home-core-bundle-20261023.css -->



<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<?php if (isset($_GET['__bm_clean'])): ?>
<script id="bm-session-clean-url-7332">try{history.replaceState(null,'','/')}catch(e){}</script>
<?php endif; ?>
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-home-core-unified-v20261101.css?v=8c7a1047c73d">


<!-- Home slider fade and closer archive switch; style-only v6. -->

<!-- Final mobile/desktop fades and color-mode CTA/header polish (v7). -->


<!-- Home slider IMDb: identical score+logo treatment to the movie-page pill.
     Inline and uniquely scoped to avoid stale Safari/PWA CSS and legacy .rating-score rules. -->
<style id="bm-home-hero-imdb-20261017">
body.has-hero #bmHomeGlobalBlocks .hero-slide > .bm-home-hero-imdb {
  position:absolute!important;
  left:20px!important;
  right:auto!important;
  bottom:20px!important;
  top:auto!important;
  z-index:12!important;
  display:inline-flex!important;
  flex-direction:row!important;
  justify-content:center!important;
  align-items:center!important;
  box-sizing:border-box!important;
  width:max-content!important;
  max-width:calc(100% - 40px)!important;
  min-height:38px!important;
  margin:0!important;
  padding:6px 12px 6px 10px!important;
  gap:7px!important;
  border:1px solid rgba(0,0,0,.12)!important;
  border-radius:12px!important;
  background:#f5c518!important;
  box-shadow:0 10px 24px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.2)!important;
  color:#070707!important;
  font:950 17px/1 Arial,Helvetica,sans-serif!important;
  direction:ltr!important;
  unicode-bidi:isolate!important;
  text-shadow:none!important;
  text-decoration:none!important;
  white-space:nowrap!important;
  opacity:1!important;
  visibility:visible!important;
  -webkit-backdrop-filter:none!important;
  backdrop-filter:none!important;
}
body.has-hero #bmHomeGlobalBlocks .bm-home-hero-imdb > .bm-home-hero-imdb-score {
  display:inline-block!important;
  flex:0 0 auto!important;
  min-width:26px!important;
  color:#070707!important;
  -webkit-text-fill-color:#070707!important;
  font:950 17px/1 Arial,Helvetica,sans-serif!important;
  font-variant-numeric:tabular-nums!important;
  letter-spacing:-.02em!important;
  text-shadow:none!important;
  opacity:1!important;
  visibility:visible!important;
}
body.has-hero #bmHomeGlobalBlocks .bm-home-hero-imdb > .bm-home-hero-imdb-logo {
  display:block!important;
  flex:0 0 40px!important;
  width:40px!important;
  height:19px!important;
  max-width:40px!important;
  object-fit:contain!important;
  border-radius:4px!important;
  background:transparent!important;
  opacity:1!important;
  visibility:visible!important;
}
@media(max-width:540px){
  body.has-hero #bmHomeGlobalBlocks .hero-slide > .bm-home-hero-imdb{
    left:16px!important;
    bottom:17px!important;
    min-height:34px!important;
    max-width:calc(100% - 32px)!important;
    padding:5px 10px 5px 8px!important;
  }
  body.has-hero #bmHomeGlobalBlocks .bm-home-hero-imdb > .bm-home-hero-imdb-score{
    font-size:15px!important;
  }
  body.has-hero #bmHomeGlobalBlocks .bm-home-hero-imdb > .bm-home-hero-imdb-logo{
    flex-basis:40px!important;
    width:40px!important;
    height:19px!important;
  }
}
</style>
<!-- Keep the visible home pane bound to the selected archive from the first paint.
     Prevents Archive 1 content appearing underneath an Archive 6 selected tab. -->
<style id="bm-home-archive-pane-guard-20261017">
html[data-bm-archive] #homePage,
html[data-bm-archive] #extPage,
html[data-bm-archive] #arc3Page,
html[data-bm-archive] #arc4Page,
html[data-bm-archive] #arc5Page,
html[data-bm-archive] #arc6Page,
html[data-bm-archive] #arc7Page {
  display: none !important;
  visibility: hidden !important;
  pointer-events: none !important;
}
html[data-bm-archive="local"] #homePage,
html[data-bm-archive="arc1"] #extPage,
html[data-bm-archive="arc3"] #arc3Page,
html[data-bm-archive="arc4"] #arc4Page,
html[data-bm-archive="arc5"] #arc5Page,
html[data-bm-archive="arc6"] #arc6Page,
html[data-bm-archive="arc7"] #arc7Page {
  display: block !important;
  visibility: visible !important;
  pointer-events: auto !important;
}
</style>
<style id="bm-a7-notices-20261019">
.bm-a7-loading-note{margin:8px 16px 14px;padding:10px 14px;border:1px solid rgba(245,197,24,.20);border-radius:12px;background:rgba(245,197,24,.055);color:var(--text-secondary,#b9c3d3);font-size:12px;line-height:1.9;text-align:right}
/* Seven home archives in one row; keep original sliding active pill. */
@media(max-width:850px){
  #arcSwitch.arc-switch{display:flex!important;flex-wrap:nowrap!important;justify-content:space-between!important;gap:0!important;width:100%!important;max-width:100%!important;overflow:visible!important;touch-action:auto!important;scroll-snap-type:none!important;box-sizing:border-box!important}
  #arcSwitch .arc-tab{flex:1 1 0!important;min-width:0!important;padding:10px 2px!important;font-size:clamp(8px,1.8vw,12px)!important;white-space:nowrap!important;scroll-snap-align:none!important;letter-spacing:0!important}
  #arcSwitch .arc-pill{display:block!important}
}
@media(max-width:380px){#arcSwitch .arc-tab{padding:9px 0!important;font-size:8px!important}}

</style>
<style>
@media(max-width:850px){body #arcSwitch{overflow:visible!important;flex-wrap:nowrap!important}body #arcSwitch .arc-tab{min-width:0!important;flex:1 1 0!important;padding-inline:2px!important;font-size:clamp(8px,2.35vw,11px)!important}}
</style>
<style id="bm-five-archive-compact-v10">
/* Five-site-archive row; 6/7 remain accessible from BM ADMIN, not the public switch. */
@media(max-width:850px){
  body #arcSwitch.arc-switch{width:min(100%,470px)!important;max-width:100%!important;margin-inline:auto!important;display:grid!important;grid-template-columns:repeat(5,minmax(0,1fr))!important;padding:3px!important;gap:2px!important;overflow:hidden!important;border-radius:20px!important;box-sizing:border-box!important;}
  body #arcSwitch .arc-tab{width:100%!important;min-width:0!important;min-height:36px!important;padding:8px 0!important;font-size:clamp(9px,2.7vw,12px)!important;line-height:1.1!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:clip!important;border-radius:16px!important;letter-spacing:-.3px!important;}
  body .arc-switch-wrap{width:100%!important;padding-inline:8px!important;box-sizing:border-box!important;}
}
@media(max-width:345px){body #arcSwitch .arc-tab{font-size:9px!important;letter-spacing:-.55px!important}}
/* A privileged administrator can have 6-7 tabs. Allow scroll on narrow
   displays instead of accidentally hiding the extra archive tabs. */
@media(max-width:850px){
  body #arcSwitch.arc-switch.bm-many-archives{display:flex!important;grid-template-columns:none!important;justify-content:flex-start!important;overflow-x:auto!important;overscroll-behavior-inline:contain!important;scrollbar-width:none!important;}
  body #arcSwitch.arc-switch.bm-many-archives::-webkit-scrollbar{display:none!important;}
  body #arcSwitch.bm-many-archives .arc-tab{flex:0 0 max(56px,calc((100% - 14px)/7))!important;width:auto!important;min-width:56px!important;padding:8px 3px!important;font-size:clamp(9px,2.3vw,12px)!important;}
}
</style>
<!-- bundled: /assets/css/bm-home-anime-icon-v14862109.css -->
<!-- bundled: /assets/css/bm-home-anime-round-v14862110.css -->
<!-- bundled: /assets/css/bm-home-collection-icons-v14862115.css -->
<!-- bundled: /assets/css/bm-updated-badges-v14862120.css -->
<!-- bundled: /assets/css/bm-neon-reference-icons-v14862121.css -->
<!-- bundled: /assets/css/bm-neon-icon-size-v14862122.css -->
<!-- bundled: /assets/css/bm-genre-neon-v14862123.css -->
<!-- bundled: /assets/css/bm-genre-soft-neon-v14862124.css -->
<!-- bundled: /assets/css/bm-feature-neon-v14862125.css -->
<!-- bundled: /assets/css/bm-all-archives-neon-v14862126.css -->
<!-- bundled: /assets/css/bm-stitch-animation-v14862127.css -->
<!-- bundled: /assets/css/bm-mobile-category-visibility-v14862128.css -->
<!-- bundled: /assets/css/bm-home-neon-consistency-v14862129.css -->
<link rel="stylesheet" href="/assets/css/bm-home-enhancements-unified-v20261101.css?v=1b733f0f9b76">

<!-- Shared header CSS FIRST PAINT: loaded before the header HTML; preserves source order. -->
<link rel="stylesheet" href="/assets/css/bm-shared-header-base-unified-v20261101.css?v=a17fe6e62e1e">
<?php if (function_exists('bm_site_bool') && bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-shared-header-neon-unified-v20261101.css?v=a694f916b1e5">
<?php endif; ?>
<link rel="stylesheet" href="/assets/css/bm-shared-header-final-unified-v20261101.css?v=8112ef7b5cb6">
</head>
<body data-theme="<?= e($userTheme) ?>" class="<?= count($sliderSlides) > 0 && $bmHomeSliderEnabled ? 'has-hero' : 'no-hero' ?>">
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>

<?php if($activeNotification && !$notificationSeen): ?>
<?php
$bmNoticeIsModern = !empty($bmModernNotice);
$bmNoticeId = (int)($activeNotification['id'] ?? 0);
$bmNoticeHeading = $userLang === 'fa' ? 'اعلامیه مهم' : 'Important announcement';
$bmNoticeTitle = trim((string)($activeNotification['title'] ?? ''));
$bmNoticeText = trim((string)($activeNotification['message'] ?? ''));
$bmNoticeAction = '';
try { $bmNoticeAction = bm_popup_safe_url((string)($activeNotification[$bmNoticeIsModern ? 'button_url' : 'link'] ?? '')); } catch (Throwable $ignored) {}
$bmNoticeActionText = $bmNoticeIsModern ? trim((string)($activeNotification['button_text'] ?? '')) : '';
if ($bmNoticeAction !== '' && $bmNoticeActionText === '') $bmNoticeActionText = $userLang === 'fa' ? 'مشاهده جزئیات' : 'Read more';
$bmNoticeIconSrc = $bmNoticeIsModern ? bm_popup_svg_image((string)($activeNotification['icon_svg'] ?? '')) : '';
$bmNoticeButtonSrc = $bmNoticeIsModern ? bm_popup_svg_image((string)($activeNotification['button_svg'] ?? '')) : '';
?>
<div class="bm-pn-overlay notification-modal" id="<?= $bmNoticeIsModern ? 'bmPnOverlay' : 'notificationModal' ?>" data-notice-id="<?= $bmNoticeId ?>" role="presentation">
  <section class="bm-pn-card" role="dialog" aria-modal="true" aria-labelledby="bmPnTitle" aria-describedby="bmPnDescription" dir="<?= $userLang === 'fa' ? 'rtl' : 'ltr' ?>">
    <div class="bm-pn-ornament" aria-hidden="true"></div>
    <?php if($bmNoticeIsModern): ?>
      <button class="bm-pn-dismiss" type="button" data-pn-intent="later" aria-label="<?= $userLang==='fa'?'بستن موقت':'Close for now' ?>"><svg class="bm-pn-closeicon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>
    <?php endif; ?>
    <header class="bm-pn-header">
      <div class="bm-pn-icon" aria-hidden="true">
        <?php if($bmNoticeIconSrc !== ''): ?><img src="<?= e($bmNoticeIconSrc) ?>" alt="">
        <?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg><?php endif; ?>
      </div>
      <h2 class="bm-pn-heading"><?= e($bmNoticeHeading) ?></h2>
      <?php if($bmNoticeTitle !== ''): ?><p class="bm-pn-title" id="bmPnTitle"><?= e($bmNoticeTitle) ?></p>
      <?php else: ?><p class="bm-pn-title" id="bmPnTitle"><?= e($bmNoticeHeading) ?></p><?php endif; ?>
      <i class="bm-pn-divider" aria-hidden="true"></i>
    </header>
    <div class="bm-pn-message" id="bmPnDescription" tabindex="0"><?= e($bmNoticeText) ?></div>
    <footer class="bm-pn-actions">
      <?php if($bmNoticeAction !== ''): ?>
        <a class="bm-pn-action" href="<?= e($bmNoticeAction) ?>" <?= $bmNoticeIsModern?'data-pn-intent="action"':'onclick="if(window.bmAcknowledgeNotification)window.bmAcknowledgeNotification();"' ?>>
          <?php if($bmNoticeButtonSrc !== ''): ?><img src="<?= e($bmNoticeButtonSrc) ?>" alt="" aria-hidden="true">
          <?php else: ?><svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="m12 2 1.7 6.3L20 10l-6.3 1.7L12 18l-1.7-6.3L4 10l6.3-1.7L12 2ZM19 17l.6 2.4L22 20l-2.4.6L19 23l-.6-2.4L16 20l2.4-.6L19 17Z"/></svg><?php endif; ?>
          <span><?= e($bmNoticeActionText) ?></span>
        </a>
      <?php endif; ?>
      <button type="button" class="bm-pn-ok" <?= $bmNoticeIsModern ? 'data-pn-intent="ack"' : 'id="closeNotificationBtn" data-notification-id="'.$bmNoticeId.'"' ?>><?= $userLang==='fa'?'متوجه شدم':'Got it' ?></button>
      <?php if($bmNoticeIsModern): ?><button type="button" class="bm-pn-later" data-pn-intent="later"><?= $userLang==='fa'?'بعداً':'Later' ?></button><?php endif; ?>
    </footer>
  </section>
</div>
<?php if($bmNoticeIsModern): ?>
<script src="/assets/js/bm-popup-notice-v470.js?v=4701"></script>
<?php else: ?>
<script>window.BM_NOTIFICATION_ID = <?= json_encode((string)$bmNoticeId, JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="/assets/js/bm-notification.js?v=split35"></script>
<?php endif; ?>
<?php endif; ?>

<script src="/assets/js/index-inline-2.js?v=split35"></script>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <?php if($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username']) ?></div><div class="sidebar-userrole"><?= $currentUser['role']==='admin'?($userLang=='fa'?'مدیر':'Admin'):($userLang=='fa'?'کاربر':'User') ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" fill="currentColor"/><path d="M9 17.25C8.58579 17.25 8.25 17.5858 8.25 18C8.25 18.4142 8.58579 18.75 9 18.75H15C15.4142 18.75 15.75 18.4142 15.75 18C15.75 17.5858 15.4142 17.25 15 17.25H9Z" fill="currentColor"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M11.5 21C16.7467 21 21 16.7467 21 11.5C21 6.25329 16.7467 2 11.5 2C6.25329 2 2 6.25329 2 11.5C2 16.7467 6.25329 21 11.5 21Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path opacity="0.4" d="M22 22L20 20" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><span><?= $t[$userLang]['advanced_search'] ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.4" d="M12.1207 12.78C12.0507 12.77 11.9607 12.77 11.8807 12.78C10.1207 12.72 8.7207 11.28 8.7207 9.50998C8.7207 7.69998 10.1807 6.22998 12.0007 6.22998C13.8107 6.22998 15.2807 7.69998 15.2807 9.50998C15.2707 11.28 13.8807 12.72 12.1207 12.78Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path opacity="0.34" d="M18.7398 19.3801C16.9598 21.0101 14.5998 22.0001 11.9998 22.0001C9.39977 22.0001 7.03977 21.0101 5.25977 19.3801C5.35977 18.4401 5.95977 17.5201 7.02977 16.8001C9.76977 14.9801 14.2498 14.9801 16.9698 16.8001C18.0398 17.5201 18.6398 18.4401 18.7398 19.3801Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if($currentUser['role']==='admin'): ?>
        <a href="/_lider/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; ?><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang=='fa'?'آیا از خروج مطمئن هستید؟':'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header"><h3><?= $t[$userLang]['notifications'] ?></h3><button class="notif-close" id="closeNotifSidebar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'])) ?></div><div class="notif-date"><?= date('Y/m/d H:i', strtotime($notif['created_at'])) ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=237001" defer></script>


<div id="bmHomeGlobalBlocks">
<?php if(count($sliderSlides) > 0): ?>
<?php $bmHomeBlock = bm_home_layout_block('slider'); ?>
<div class="hero-slider" dir="ltr" data-bm-home-block="slider" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>>
    <div class="hero-track">
        <?php foreach($sliderSlides as $index => $slide): ?>
        <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
            <img src="<?= e(bm_public_asset_url($slide['image_path'] ?? '')) ?>" class="hero-bg" width="1920" height="1080" loading="<?= $index === 0 ? 'eager' : 'lazy' ?>" decoding="async" fetchpriority="<?= $index === 0 ? 'high' : 'low' ?>" alt="<?= e($userLang === 'fa' ? $slide['title_fa'] : ($slide['title_en'] ?: $slide['title_fa'])) ?>">
            <div class="hero-overlay"></div>
            <div class="bm-home-hero-bottom-fade" aria-hidden="true"></div>
            <div class="hero-content">
                <div class="hero-title"><?= e($userLang === 'fa' ? $slide['title_fa'] : ($slide['title_en'] ?: $slide['title_fa'])) ?></div>
                <?php if(!empty($slide['subtitle_fa']) || !empty($slide['subtitle_en'])): ?>
                <div class="hero-desc"><?= e($userLang === 'fa' ? $slide['subtitle_fa'] : ($slide['subtitle_en'] ?: $slide['subtitle_fa'])) ?></div>
                <?php endif; ?>
                <?php if(!empty($slide['link'])): ?>
                <div class="hero-buttons">
                    <a href="<?= e($slide['link']) ?>" class="hero-btn main"><?= $userLang === 'fa' ? 'مشاهده' : 'View' ?></a>
                </div>
                <?php endif; ?>
            </div>
            <!-- Same score-first IMDb pill as movie.php; independent of legacy slider styling. -->
            <div class="bm-home-hero-imdb" dir="ltr" aria-label="IMDb <?= e(enNumbers(number_format((float)($slide['rating'] ?? 8.5), 1))) ?>">
                <span class="bm-home-hero-imdb-score"><?= enNumbers(number_format((float)($slide['rating'] ?? 8.5), 1)) ?></span>
                <img class="bm-home-hero-imdb-logo" src="/assets/brand/imdb-logo.svg" alt="IMDb" width="34" height="17" decoding="async">
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="hero-arrow hero-prev" id="heroPrev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg></div>
    <div class="hero-arrow hero-next" id="heroNext"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg></div>

    <div class="hero-dots" id="heroDots">
        <?php foreach($sliderSlides as $index => $slide): ?>
        <button class="hero-dot <?= $index === 0 ? 'active' : '' ?>" data-dot="<?= $index ?>" aria-label="Go to slide <?= $index+1 ?>">
            <span class="dot-inner"></span>
        </button>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php
// Official Yektanet placement: exactly as issued, inline and non-sticky.
// It appears after the hero on both desktop and mobile.
$bmYkPrimaryHome = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '';
$bmYkHomeTop = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_top', 'hero') : '';
?>
<?php $bmHomeBlock = bm_home_layout_block('top_ad'); ?>
<div data-bm-home-block="top_ad" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>><?= $bmYkPrimaryHome !== '' ? $bmYkPrimaryHome : ($bmYkHomeTop !== '' ? $bmYkHomeTop : bm_render_ad_slot($pdo, 'home_top', 'hero', 1)) ?></div>

<?php if(count($stories)>0): ?>
<?php $bmHomeBlock = bm_home_layout_block('stories'); ?>
<div class="stories-section" data-bm-home-block="stories" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>><div class="stories-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_stories_title_fa','استوری‌ها')) : $t[$userLang]['stories'] ?></div><div class="stories-container" id="storiesContainer"></div></div>
<?php endif; ?>

<!-- Quick search is available only from the shared header and mobile footer. -->


<?php $bmHomeBlock = bm_home_layout_block('genres'); ?><div class="genres-section" id="genresSection" data-bm-home-block="genres" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>><div class="section-header"><div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_genres_title_fa','ژانرها')) : $t[$userLang]['genres'] ?></div></div><div class="genres-scroll" id="genresContainer"><?php foreach($genresList as $genreEn): $genreDisplay = isset($genrePersian[$genreEn]) ? $genrePersian[$genreEn] : $genreEn; ?><a href="/search?genre=<?= urlencode($genreEn) ?>" class="genre-chip"><?= e($genreDisplay) ?></a><?php endforeach; ?></div></div>

<?php $bmHomeBlock = bm_home_layout_block('countries'); ?><div class="countries-section" id="countriesSection" data-bm-home-block="countries" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>><div class="section-header"><div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_countries_title_fa','کشورهای محبوب')) : $t[$userLang]['popular_countries'] ?></div></div><div class="countries-scroll" id="countriesContainer"><?php foreach($allCountries as $country): ?><a href="/search?country=<?= urlencode($country) ?>" class="country-chip"><span style="font-size:18px"><?= getCountryFlag($country) ?></span><?= e($country) ?></a><?php endforeach; ?></div></div>

<?php $bmYkHomeMiddle = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_middle', 'wide') : ''; ?>
<?php $bmHomeBlock = bm_home_layout_block('middle_ad'); ?>
<div data-bm-home-block="middle_ad" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>><?= $bmYkHomeMiddle !== '' ? $bmYkHomeMiddle : (function_exists('bm_render_ad_with_support_card') ? bm_render_ad_with_support_card($pdo, 'home_middle', 'wide', 1, 'index.php') : bm_render_ad_slot($pdo, 'home_middle', 'wide', 1)) ?></div>

<?php $bmHomeBlock = bm_home_layout_block('archive_switch'); ?>
<?php $bmArcVisibleTabsCount = 0; foreach ($bmArchiveOrder as $bmCountArchive) if (bm_archive_should_render_tab((string)$bmCountArchive, $currentUser ?? null)) $bmArcVisibleTabsCount++; ?>
<div class="arc-switch-wrap" data-bm-home-block="archive_switch" data-bm-order="<?= (int)$bmHomeBlock['order'] ?>" <?= empty($bmHomeBlock['enabled']) ? 'hidden' : '' ?>>
    <div class="arc-switch <?= $bmArcVisibleTabsCount > 5 ? 'bm-many-archives' : '' ?>" id="arcSwitch">
        <div class="arc-pill" id="arcPill"></div>

        <?php
        $bmArchiveTabMeta = [
            'archive1'=>['mode'=>'arc1','id'=>'arcTabExt','icon'=>'globe'],
            'archive2'=>['mode'=>'local','id'=>'arcTabLocal','icon'=>'database'],
            'archive3'=>['mode'=>'arc3','id'=>'arcTabArc3','icon'=>'list'],
            'archive4'=>['mode'=>'arc4','id'=>'arcTabArc4','icon'=>'star'],
            'archive5'=>['mode'=>'arc5','id'=>'arcTabArc5','icon'=>'globe'],
            'archive6'=>['mode'=>'arc6','id'=>'arcTabArc6','icon'=>'globe'],
            'archive7'=>['mode'=>'arc7','id'=>'arcTabArc7','icon'=>'lock'],
        ];
        foreach($bmArchiveOrder as $bmAid):
            if (!bm_archive_should_render_tab($bmAid, $currentUser ?? null)) continue; // Admin-only sources remain protected by server access checks.
            $bmMeta = $bmArchiveTabMeta[$bmAid];
            $bmEnabled = bm_archive_is_enabled($bmAid);
            $bmVipLocked = bm_archive_vip_gate_locked($bmAid, $currentUser ?? null);
            $bmMode = $bmMeta['mode'];
        ?>
        <a class="arc-tab <?= $bmArchiveDefaultMode===$bmMode ? 'arc-tab-active' : '' ?> <?= $bmEnabled ? '' : 'arc-tab-disabled' ?>"
                href="/?archive=<?= (int)str_replace('archive','',$bmAid) ?>"
                data-arc="<?= e($bmMode) ?>" data-archive-id="<?= e($bmAid) ?>" id="<?= e($bmMeta['id']) ?>"
                data-disabled-message="<?= e(bm_archive_disabled_message($bmAid)) ?>"
                <?= $bmArchiveDefaultMode===$bmMode ? 'aria-current="page"' : '' ?>
                <?= $bmVipLocked ? 'data-bm-vip-gate="archive_access" aria-haspopup="dialog"' : '' ?>>
            <?= e(bm_archive_label($bmAid, $userLang==='fa' ? ('آرشیو '.str_replace('archive','',$bmAid)) : ('Archive '.str_replace('archive','',$bmAid)))) ?>
        </a>
        <?php endforeach; ?>
    </div>
    <?php if(bm_site_bool('home_archive_guide_enabled', true)): ?>
    <button type="button" class="archive-guide-btn" id="archiveGuideBtn">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
        <?= e(bm_site_get('home_archive_guide_button_fa','اگه استفاده از آرشیوها رو بلد نیستی بزن روم')) ?>
    </button>
    <?php endif; ?>
    <div class="arc-hint" id="arcHint"><?= $userLang==='fa' ? e(bm_site_get('home_archive_hint_fa','هر آرشیو محتوای متفاوتی دارد')) : 'Each archive has different content' ?></div>
</div>
<script>
(function(){
  const root=document.getElementById('bmHomeGlobalBlocks');
  if(!root)return;
  const nodes=Array.from(root.children).filter(el=>el.hasAttribute('data-bm-home-block'));
  nodes.sort((a,b)=>(parseInt(a.dataset.bmOrder||'500',10)||500)-(parseInt(b.dataset.bmOrder||'500',10)||500));
  nodes.forEach(el=>root.appendChild(el));
})();
</script>
</div>

<?php if(bm_site_bool('home_archive_guide_enabled', true)): ?>
<?php $archiveGuideVideoUrl = trim((string)bm_site_get('home_archive_guide_video_url', '')); ?>
<div class="archive-guide-overlay" id="archiveGuideModal" aria-hidden="true">
    <div class="archive-guide-modal archive-guide-video-modal" role="dialog" aria-modal="true" aria-labelledby="archiveGuideTitle">
        <div class="archive-guide-video-top">
            <span class="archive-guide-sr-title" id="archiveGuideTitle">راهنمای ویدیویی آرشیوها</span>
            <button type="button" class="archive-guide-close" id="archiveGuideClose" aria-label="بستن">×</button>
        </div>
        <div class="archive-guide-video-shell">
            <?php if($archiveGuideVideoUrl !== ''): ?>
                <video class="archive-guide-video" controls playsinline preload="metadata" src="<?= e($archiveGuideVideoUrl) ?>"></video>
            <?php else: ?>
                <div class="archive-guide-video-empty"><?= e(bm_site_get('home_archive_guide_empty_fa','ویدیو راهنما هنوز از پنل تنظیم نشده است.')) ?></div>
            <?php endif; ?>
        </div>
        <div class="archive-guide-caption"><?= e(bm_site_get('home_archive_guide_caption_fa','اگه براتون سوال شده که این آرشیوها چی هستن یا موقع استفاده گیج شدین، حتماً این ویدیو رو ببینید تا همه‌چیز براتون روشن بشه.')) ?></div>
    </div>
</div>
<?php endif; ?>

<div class="ext-page" id="extPage" style="display:<?= $bmArchiveDefaultMode === 'arc1' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc1' ? '1' : '0' ?>">

    <!-- نتایج سرچ یکپارچه آرشیو ۱ -->
    <div id="extSearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="extSearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو
            </div>
            <button onclick="extClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="extSearchResultsList"></div>
    </div>

    <!-- سکشن‌های اسکرولی آرشیو ۱ -->
    <div id="extScrollSections">

        <!-- <?= e(bm_public_home_section('archive1','updated_movies', bm_site_get('home_updated_movies_title_fa','فیلم‌های آپدیت شده'))) ?> -->
        <div class="new-releases-section" id="extUpdatedMoviesSection"<?= bm_archive_section_enabled('archive1','updated_movies') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?php
                    $bmMoviesHeading = $userLang === 'en'
                        ? (string)bm_site_get('home_updated_movies_title_en','Recently Updated Movies')
                        : (string)bm_public_home_section('archive1','updated_movies',bm_site_get('home_updated_movies_title_fa','فیلم‌های آپدیت شده'));
                    $bmMoviesHeading = trim($bmMoviesHeading) ?: ($userLang === 'en' ? 'Recently Updated Movies' : 'فیلم‌های آپدیت شده');
                    $bmUpdateNew = trim((string)bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa','NEW'));
                ?>
                <?= bm_home_neon_heading($bmMoviesHeading, 'movie', $bmUpdateNew) ?>
                <a href="/view_all?type=arc1_updates&kind=movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extUpdatedMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- <?= e(bm_public_home_section('archive1','updated_series', bm_site_get('home_updated_series_title_fa','سریال‌های آپدیت شده'))) ?> -->
        <div class="new-releases-section" id="extUpdatedSeriesSection"<?= bm_archive_section_enabled('archive1','updated_series') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?php
                    $bmSeriesHeading = $userLang === 'en'
                        ? (string)bm_site_get('home_updated_series_title_en','Recently Updated Series')
                        : (string)bm_public_home_section('archive1','updated_series',bm_site_get('home_updated_series_title_fa','سریال‌های آپدیت شده'));
                    $bmSeriesHeading = trim($bmSeriesHeading) ?: ($userLang === 'en' ? 'Recently Updated Series' : 'سریال‌های آپدیت شده');
                ?>
                <?= bm_home_neon_heading($bmSeriesHeading, 'series', $bmUpdateNew) ?>
                <a href="/view_all?type=arc1_updates&kind=series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extUpdatedSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0 && bm_archive_section_enabled('archive1','collections')): ?>
        <div class="collections-section">
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_collections_title_en','Special Collections') : bm_public_home_section('archive1','collections', $t[$userLang]['special_collections'])), 'collections') ?>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach(array_slice($activeCollections, 0, 4) as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card bm-win-collection-card" data-view-label="<?= e($userLang==='fa'?'مشاهده کالکشن':'View collection') ?>">
                    <span class="bm-win-collection-count"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></span>
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" width="300" height="450" loading="lazy" decoding="async" alt="<?= e($col['title_fa'] ?: $col['title']) ?>">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info bm-win-collection-info" data-year-range="<?= e(bm_collection_year_range($col)) ?>" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- انیمه -->
        <div class="new-releases-section" id="extAnimeSection"<?= bm_archive_section_enabled('archive1','anime') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_anime_title_en','Anime') : bm_public_home_section('archive1','anime','انیمه')), 'anime') ?>
                <a href="/view_all?type=arc1_category&cat=anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- برترین فیلم‌های 2026 -->
        <div class="new-releases-section" id="extTop2026Section"<?= bm_archive_section_enabled('archive1','top_2026') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?php
                    $bmTopTitle = $userLang === 'en'
                        ? (string)bm_site_get('home_top_2026_title_en', 'Top Movies of 2026')
                        : (string)bm_public_home_section('archive1','top_2026','برترین فیلم‌های 2026');
                    $bmTopYear = preg_match('/(?:19|20)[0-9]{2}/', enNumbers($bmTopTitle), $bmYearMatch) ? $bmYearMatch[0] : '2026';
                ?>
                <?= bm_home_feature_neon_heading($bmTopTitle, 'top', $bmTopYear) ?>
                <a href="/view_all?type=arc1_category&cat=top-2026" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extTop2026List"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- فیلم‌های دوبله فارسی -->
        <div class="new-releases-section" id="extDubbedFaSection"<?= bm_archive_section_enabled('archive1','dubbed_fa') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_genre_neon_heading(($userLang === 'en' ? bm_site_get('home_dubbed_fa_title_en','Persian Dubbed Movies') : bm_public_home_section('archive1','dubbed_fa','فیلم‌های دوبله فارسی')), 'dub', 'DUB') ?>
                <a href="/view_all?type=arc1_category&cat=dubbed-fa" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extDubbedFaList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- سریال‌های ترکی -->
        <div class="new-releases-section" id="extTurkishSection"<?= bm_archive_section_enabled('archive1','turkish') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_genre_neon_heading(($userLang === 'en' ? bm_site_get('home_turkish_title_en','Turkish Series') : bm_public_home_section('archive1','turkish','سریال‌های ترکی')), 'turkey') ?>
                <a href="/view_all?type=arc1_category&cat=turkish" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extTurkishList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- سریال‌های کره‌ای -->
        <div class="new-releases-section" id="extKoreanSection"<?= bm_archive_section_enabled('archive1','korean') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_genre_neon_heading(($userLang === 'en' ? bm_site_get('home_korean_title_en','Korean Series') : bm_public_home_section('archive1','korean','سریال‌های کره‌ای')), 'korea') ?>
                <a href="/view_all?type=arc1_category&cat=korean" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extKoreanList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

    </div><!-- /extScrollSections -->

</div>

<div class="ext-page" id="arc3Page" style="display:<?= $bmArchiveDefaultMode === 'arc3' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc3' ? '1' : '0' ?>">
    <div id="arc3SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc3SearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو — آرشیو ۳
            </div>
            <button onclick="arc3ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc3SearchResultsList"></div>
    </div>

    <div id="arc3ScrollSections">
        <?php if(bm_site_bool('home_archive3_loading_enabled', true)): ?><div class="bm-archive-speed-note" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span><?= e(bm_site_get('home_archive3_loading_text_fa','در حال دریافت تازه‌ترین محتوای آرشیو ۳...')) ?></span></div><?php endif; ?>
        <div class="new-releases-section" id="arc3NewSeriesSection"<?= bm_archive_section_enabled('archive3','new_series') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_new_series_title_en','New Series') : bm_public_home_section('archive3','new_series', bm_site_get('home_new_series_title_fa','سریال‌های جدید'))), 'series', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
                <a href="/view_all?type=arc3_section&kind=new_series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3NewSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc3NewMoviesSection"<?= bm_archive_section_enabled('archive3','new_movies') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_new_movies_title_en','New Movies') : bm_public_home_section('archive3','new_movies', bm_site_get('home_new_movies_title_fa','فیلم‌های جدید'))), 'movie', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
                <a href="/view_all?type=arc3_section&kind=new_movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3NewMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc3UpdatedAnimationsSection"<?= bm_archive_section_enabled('archive3','updated_animations') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_archive_neon_heading('archive3', 'updated_animations', bm_site_get('home_updated_animations_title_fa','انیمیشن‌های به‌روز شده'), $userLang) ?>
                <a href="/view_all?type=arc3_section&kind=updated_animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3UpdatedAnimationsList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0 && bm_archive_section_enabled('archive3','collections')): ?>
        <div class="collections-section">
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_collections_title_en','Special Collections') : bm_public_home_section('archive3','collections', $t[$userLang]['special_collections'])), 'collections') ?>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach(array_slice($activeCollections, 0, 4) as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card bm-win-collection-card" data-view-label="<?= e($userLang==='fa'?'مشاهده کالکشن':'View collection') ?>">
                    <span class="bm-win-collection-count"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></span>
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" width="300" height="450" loading="lazy" decoding="async" alt="<?= e($col['title_fa'] ?: $col['title']) ?>">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info bm-win-collection-info" data-year-range="<?= e(bm_collection_year_range($col)) ?>" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="new-releases-section" id="arc3UpdatedAnimeSection"<?= bm_archive_section_enabled('archive3','updated_anime') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_anime_title_en','Anime') : bm_public_home_section('archive3','updated_anime','انیمه‌های به‌روز شده')), 'anime') ?>
                <a href="/view_all?type=arc3_section&kind=updated_anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3UpdatedAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

    </div>
</div>


<?php if (bm_archive_user_can_access('archive4', $currentUser ?? null)): ?>
<div class="ext-page" id="arc4Page" style="display:<?= $bmArchiveDefaultMode === 'arc4' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc4' ? '1' : '0' ?>">
    <div id="arc4SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc4SearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو — آرشیو ۴
            </div>
            <button onclick="arc4ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc4SearchResultsList"></div>
    </div>

    <div id="arc4ScrollSections">
        <?php if(bm_site_bool('home_archive4_loading_enabled', true)): ?><div class="bm-archive-speed-note" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span><?= e(bm_site_get('home_archive4_loading_text_fa','در حال دریافت تازه‌ترین محتوای آرشیو ۴...')) ?></span></div><?php endif; ?>
        <div class="new-releases-section" id="arc4NewSeriesSection"<?= bm_archive_section_enabled('archive4','new_series') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_new_series_title_en','New Series') : bm_public_home_section('archive4','new_series', bm_site_get('home_new_series_title_fa','سریال‌های جدید'))), 'series', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
                <a href="/view_all?type=arc4_section&kind=new_series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4NewSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc4NewMoviesSection"<?= bm_archive_section_enabled('archive4','new_movies') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_new_movies_title_en','New Movies') : bm_public_home_section('archive4','new_movies', bm_site_get('home_new_movies_title_fa','فیلم‌های جدید'))), 'movie', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
                <a href="/view_all?type=arc4_section&kind=new_movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4NewMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc4UpdatedAnimationsSection"<?= bm_archive_section_enabled('archive4','updated_animations') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_archive_neon_heading('archive4', 'updated_animations', bm_site_get('home_updated_animations_title_fa','انیمیشن‌های به‌روز شده'), $userLang) ?>
                <a href="/view_all?type=arc4_section&kind=updated_animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4UpdatedAnimationsList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0 && bm_archive_section_enabled('archive4','collections')): ?>
        <div class="collections-section">
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_collections_title_en','Special Collections') : bm_public_home_section('archive4','collections', $t[$userLang]['special_collections'])), 'collections') ?>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach(array_slice($activeCollections, 0, 4) as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card bm-win-collection-card" data-view-label="<?= e($userLang==='fa'?'مشاهده کالکشن':'View collection') ?>">
                    <span class="bm-win-collection-count"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></span>
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" width="300" height="450" loading="lazy" decoding="async" alt="<?= e($col['title_fa'] ?: $col['title']) ?>">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info bm-win-collection-info" data-year-range="<?= e(bm_collection_year_range($col)) ?>" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <div class="new-releases-section" id="arc4UpdatedAnimeSection"<?= bm_archive_section_enabled('archive4','updated_anime') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_anime_title_en','Anime') : bm_public_home_section('archive4','updated_anime','انیمه‌های به‌روز شده')), 'anime') ?>
                <a href="/view_all?type=arc4_section&kind=updated_anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4UpdatedAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

    </div>
</div>


<?php endif; ?>

<?php if (bm_archive_user_can_access('archive6', $currentUser ?? null)): ?>
<div class="ext-page" id="arc6Page" style="display:<?= $bmArchiveDefaultMode === 'arc6' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc6' ? '1' : '0' ?>">
    <div id="arc6SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc6SearchResultTitle">نتایج جستجو — آرشیو ۶</div>
            <button type="button" onclick="arc6ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc6SearchResultsList"></div>
    </div>
    <div id="arc6ScrollSections">
        <?php foreach([
            ['new_movies','arc6NewMoviesSection','arc6NewMoviesList','فیلم‌های جدید'],
            ['new_series','arc6NewSeriesSection','arc6NewSeriesList','سریال‌های جدید'],
        ] as $bmArc6Section): ?>
        <div class="new-releases-section" id="<?= e($bmArc6Section[1]) ?>"<?= bm_archive_section_enabled('archive6',$bmArc6Section[0]) ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_archive_neon_heading('archive6', $bmArc6Section[0], $bmArc6Section[3], $userLang) ?>
                <a href="/view_all?type=arc6_section&amp;kind=<?= rawurlencode($bmArc6Section[0]) ?>" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="<?= e($bmArc6Section[2]) ?>"><div class="ext-loading-skeletons" aria-hidden="true">
                <?php for($i=0;$i<6;$i++): ?><div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div><?php endfor; ?>
            </div></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<?php if (bm_archive_user_can_access('archive7', $currentUser ?? null)): ?>
<div class="ext-page" id="arc7Page" style="display:<?= $bmArchiveDefaultMode === 'arc7' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc7' ? '1' : '0' ?>">
    <p class="bm-a7-loading-note" role="note"><?= $userLang === 'fa' ? 'آرشیو ۷ ممکن است کمی دیرتر بارگذاری شود.' : 'Archive 7 may take a little longer to load.' ?></p>
    <div id="arc7SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc7SearchResultTitle">نتایج جستجو — آرشیو ۷</div>
            <button type="button" onclick="arc7ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc7SearchResultsList"></div>
    </div>
    <div id="arc7ScrollSections">
        <?php foreach([
            ['new_movies','arc7NewMoviesSection','arc7NewMoviesList','فیلم‌های جدید'],
            ['new_series','arc7NewSeriesSection','arc7NewSeriesList','سریال‌های جدید'],
        ] as $bmArc7Section): ?>
        <div class="new-releases-section" id="<?= e($bmArc7Section[1]) ?>"<?= bm_archive_section_enabled('archive7',$bmArc7Section[0]) ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_archive_neon_heading('archive7', $bmArc7Section[0], $bmArc7Section[3], $userLang) ?>
                <a href="/view_all?type=arc7_section&amp;kind=<?= rawurlencode($bmArc7Section[0]) ?>" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="<?= e($bmArc7Section[2]) ?>"><div class="ext-loading-skeletons" aria-hidden="true">
                <?php for($i=0;$i<6;$i++): ?><div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div><?php endfor; ?>
            </div></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
<?php if (bm_archive_user_can_access('archive5', $currentUser ?? null)): ?>
<div class="ext-page" id="arc5Page" style="display:<?= $bmArchiveDefaultMode === 'arc5' ? 'block' : 'none' ?>;opacity:<?= $bmArchiveDefaultMode === 'arc5' ? '1' : '0' ?>">
    <div id="arc5SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc5SearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو — آرشیو 5
            </div>
            <button onclick="arc5ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc5SearchResultsList"></div>
    </div>

    <div id="arc5ScrollSections">
        <?php if(bm_site_bool('home_archive5_loading_enabled', true)): ?><div class="bm-archive-speed-note" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span><?= e(bm_site_get('home_archive5_loading_text_fa','در حال دریافت تازه‌ترین محتوای آرشیو 5...')) ?></span></div><?php endif; ?>

        <?php foreach([
            ['new_movies','arc5NewMoviesSection','arc5NewMoviesList','فیلم‌های جدید'],
            ['new_series','arc5NewSeriesSection','arc5NewSeriesList','سریال‌های جدید'],
            ['turkish','arc5TurkishSection','arc5TurkishList','فیلم و سریال ترکی'],
            ['animation','arc5AnimationSection','arc5AnimationList','انیمیشن و انیمه'],
        ] as $bmArc5Section): ?>
        <div class="new-releases-section" id="<?= e($bmArc5Section[1]) ?>"<?= bm_archive_section_enabled('archive5',$bmArc5Section[0]) ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
            <div class="section-header">
                <?= bm_home_archive_neon_heading('archive5', $bmArc5Section[0], $bmArc5Section[3], $userLang) ?>
                <a href="/view_all?type=arc5_section&kind=<?= rawurlencode($bmArc5Section[0]) ?>" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="<?= e($bmArc5Section[2]) ?>"><div class="ext-loading-skeletons" aria-hidden="true">
                <?php for($bmArc5Sk=0;$bmArc5Sk<6;$bmArc5Sk++): ?><div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div><?php endfor; ?>
            </div></div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>


<div class="page active" id="homePage" style="display:<?= $bmArchiveDefaultMode === 'local' ? 'block' : 'none' ?>">

    <!-- 1) فیلم‌های جدید -->
    <?php if(count($newMovies)>0): ?>
    <div class="new-releases-section" id="localNewMoviesSection"<?= bm_archive_section_enabled('archive2','new_movies') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
        <div class="section-header">
            <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_new_movies_title_en','New Movies') : bm_public_home_section('archive2','new_movies', bm_site_get('home_new_movies_title_fa','فیلم‌های جدید'))), 'movie', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
            <a href="/view_all?type=new-movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="newMoviesList"></div>
    </div>
    <?php endif; ?>

    <!-- 2) سریال‌های آپدیت -->
    <?php if(count($updatedSeries)>0): ?>
    <div class="new-releases-section" id="localUpdatedSeriesSection"<?= bm_archive_section_enabled('archive2','updated_series') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
        <div class="section-header">
            <?= bm_home_neon_heading(($userLang === 'en' ? bm_site_get('home_updated_series_title_en','Recently Updated Series') : bm_public_home_section('archive2','updated_series', bm_site_get('home_updated_series_title_fa','سریال‌های آپدیت'))), 'series', bm_site_get($userLang === 'en' ? 'home_new_badge_en' : 'home_new_badge_fa', 'NEW')) ?>
            <a href="/view_all?type=updated-series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="updatedSeriesList"></div>
    </div>
    <?php endif; ?>

    <!-- 3) کالکشن -->
    <?php if(count($activeCollections)>0 && bm_archive_section_enabled('archive2','collections')): ?>
    <div class="collections-section" id="localCollectionsSection"<?= bm_archive_section_enabled('archive2','collections') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
        <div class="section-header">
            <?= bm_home_feature_neon_heading(($userLang === 'en' ? bm_site_get('home_collections_title_en','Special Collections') : bm_public_home_section('archive2','collections','کالکشن')), 'collections') ?>
            <?php if (bm_site_bool('collection_show_view_all_links', true)): ?>
            <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            <?php endif; ?>
        </div>
        <div class="scroll-horizontal">
            <?php foreach(array_slice($activeCollections, 0, 4) as $col): ?>
            <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card bm-win-collection-card" data-view-label="<?= e($userLang==='fa'?'مشاهده کالکشن':'View collection') ?>">
                    <span class="bm-win-collection-count"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></span>
                <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" width="300" height="450" loading="lazy" decoding="async" alt="<?= e($col['title_fa'] ?: $col['title']) ?>">
                <?php else: ?>
                <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                <?php endif; ?>
                <div class="scroll-card-info bm-win-collection-info" data-year-range="<?= e(bm_collection_year_range($col)) ?>" style="text-align:center">
                    <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                    <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 4) انیمیشن -->
    <?php if(count($latestAnimations)>0): ?>
    <div class="new-releases-section" id="localAnimationsSection"<?= bm_archive_section_enabled('archive2','animations') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
        <div class="section-header">
            <?= bm_home_archive_neon_heading('archive2','animations','انیمیشن',$userLang) ?>
            <a href="/view_all?type=animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="latestAnimationsList"></div>
    </div>
    <?php endif; ?>

    <!-- 5) دوبله -->
    <?php if(count($dubbedMovies)>0): ?>
    <div class="dubbed-section" id="localDubbedSection"<?= bm_archive_section_enabled('archive2','dubbed') ? ' data-bm-section-enabled="1"' : ' hidden data-bm-section-enabled="0"' ?>>
        <div class="section-header">
            <?= bm_home_archive_neon_heading('archive2','dubbed','دوبله',$userLang) ?>
            <a href="/view_all?type=dubbed" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="dubbedList"></div>
    </div>
    <?php endif; ?>

</div>

<?php bm_weekly_schedule_render($pdo, $userLang); ?>

<?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_bottom', 'wide') : '' ?>

<?php $bmYkMobile = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('mobile', 'floating') : ''; ?>
<?= $bmYkMobile !== '' ? $bmYkMobile : bm_render_ad_slot($pdo, 'mobile', 'floating', 1) ?>

<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<div class="story-modal" id="storyModal">
    <div class="story-progress-container" id="storyProgressContainer"></div>
    <button class="story-close" id="storyCloseBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    <button class="story-nav prev" id="storyPrevBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
    <button class="story-nav next" id="storyNextBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
    <div class="story-content" id="storyContent"></div>
</div>

<div class="modal" id="donateModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(12px);align-items:center;justify-content:center;z-index:10002"><div style="background:#121215;border-radius:28px;max-width:400px;width:90%;padding:24px;text-align:center"><div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 20px;display:flex;align-items:center;justify-content:center"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div><div style="font-size:24px;font-weight:800;margin-bottom:16px"><?= $t[$userLang]['support_us'] ?></div><p style="color:var(--text-secondary);margin-bottom:24px;font-size:13px"><?= $t[$userLang]['support_text'] ?></p><button class="donate-btn" id="openDonateLink" style="width:100%;justify-content:center"><?= $t[$userLang]['donate'] ?></button><button id="closeDonateModal" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer"><?= $t[$userLang]['close'] ?></button></div></div>

<script>
window.BM_HOME_CONFIG = {
  storiesData: <?= js_json($stories) ?>,
  newMoviesData: <?= js_json($newMovies) ?>,
  updatedSeriesData: <?= js_json($updatedSeries) ?>,
  latestAnimationsData: <?= js_json($latestAnimations) ?>,
  dubbedMoviesData: <?= js_json($dubbedMovies) ?>,
  userLang: <?= js_json($userLang) ?>,
  userId: <?= js_json($currentUser['id'] ?? '') ?>,
  storyFallback: <?= js_json(bm_public_asset_url((string)bm_site_get('home_story_fallback_path', ''), '')) ?>,
  storyImageFit: <?= js_json(in_array((string)bm_site_get('home_story_image_fit', 'cover'), ['cover','contain'], true) ? (string)bm_site_get('home_story_image_fit', 'cover') : 'cover') ?>,
  archiveControl: <?= json_encode($bmArchivePublicConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  arcHints: {
    local: <?= js_json($userLang==='fa' ? 'آرشیو ۲ — دیتابیس اصلی سایت، سافت‌ساب، دوبله و همیشه در دسترس' : 'Archive 2 — Main local database') ?>,
    ext: <?= js_json($userLang==='fa' ? 'آرشیو ۱ — هاردساب + دوبله، آپدیت سریع و دائمی' : 'Archive 1 — Hardsub + dubbed, fast updates') ?>,
    arc1: <?= js_json($userLang==='fa' ? 'آرشیو ۱ — هاردساب + دوبله، آپدیت سریع و دائمی' : 'Archive 1 — Hardsub + dubbed, fast updates') ?>,
    arc3: <?= js_json($userLang==='fa' ? 'آرشیو ۳ — فیلم، سریال و انیمه به‌روز' : 'Archive 3 — Always updated') ?>,
    arc4: <?= js_json($userLang==='fa' ? 'آرشیو ۴ — فیلم، سریال، انیمیشن و انیمه' : 'Archive 4 — Movies, series, animation and anime') ?>,
    arc5: <?= js_json($userLang==='fa' ? 'آرشیو 5 — فیلم و سریال با لینک مستقیم' : 'Archive 5 — Movies and series') ?>,
    arc6: <?= js_json($userLang==='fa' ? 'آرشیو ۶ (در حال آزمایش)' : 'Archive 6 (testing)') ?>,
    arc7: <?= js_json($userLang==='fa' ? 'آرشیو ۷ — پشتیبان مدیر' : 'Archive 7 — Admin backup') ?>
  },
  activeArchive: <?= json_encode($bmArchiveDefaultMode, JSON_UNESCAPED_UNICODE) ?>,
  configuredDefaultArchive: <?= json_encode(bm_archive_configured_default_id(), JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="/assets/js/bm-home-api-cache.js?v=7332-hard"></script>
<script src="/assets/js/index-main-v97.js?v=year-en-inline-v8-20261102"></script>

<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/index-inline-3.js?v=7332-hard"></script>
<script src="/assets/js/bm-performance.js?v=7332-hard" defer></script>
<script src="/assets/js/pwa.js?v=7332-killsw" defer></script>

<!-- V12: drag horizontal posters with a desktop mouse (touch behavior unchanged) -->
<link rel="stylesheet" href="/assets/css/bm-poster-mouse-drag-v12.css?v=20261021-v12">
<script src="/assets/js/bm-poster-mouse-drag-v12.js?v=20261021-v12" defer></script>
<script src="/assets/js/bm-premium-ui-v143.js?v=143-v47-static-scroll" defer></script>
</body>
</html>
