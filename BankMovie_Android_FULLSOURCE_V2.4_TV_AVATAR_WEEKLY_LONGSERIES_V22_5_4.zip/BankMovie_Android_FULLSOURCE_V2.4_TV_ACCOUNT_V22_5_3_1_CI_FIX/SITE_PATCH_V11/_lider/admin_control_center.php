<?php
declare(strict_types=1);
/* BM_LIDER_COMPAT_V232 */
if (!defined('BM_ROOT_DIR')) define('BM_ROOT_DIR', dirname(__DIR__));
@chdir(BM_ROOT_DIR);

require_once BM_ROOT_DIR . '/includes/security_bootstrap.php';
require_once BM_ROOT_DIR . '/includes/admin_guard.php';
require_once BM_ROOT_DIR . '/includes/archive_control.php';
require_once BM_ROOT_DIR . '/includes/admin_archive_dashboard.php';
require_once BM_ROOT_DIR . '/includes/remote_delivery_control.php';
require_once BM_ROOT_DIR . '/includes/yektanet_control.php';
require_once BM_ROOT_DIR . '/app/download.php';
require_admin();
admin_enforce_csrf();

$csrf = admin_csrf_token();

function bm_cc_h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function bm_cc_bool($value): bool { return filter_var($value, FILTER_VALIDATE_BOOLEAN); }
function bm_cc_redirect(string $message, string $type = 'success', string $tab = 'overview'): never {
    header('Location: admin_control_center?' . http_build_query(['msg'=>$message,'type'=>$type,'tab'=>$tab]));
    exit;
}
function bm_cc_atomic_json_write(string $path, array $data): bool {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) return false;
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return false;
    $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
    if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) { @unlink($tmp); return false; }
    @chmod($tmp, 0644);
    if (@rename($tmp, $path)) return true;
    @unlink($tmp);
    return false;
}
function bm_cc_clean_url(string $url, bool $allowEmpty = true): string {
    $url = trim($url);
    if ($url === '' && $allowEmpty) return '';
    return function_exists('bm_security_safe_url') ? bm_security_safe_url($url, ['http','https']) : (filter_var($url, FILTER_VALIDATE_URL) ? $url : '');
}
function bm_cc_lines(string $text): array {
    $items = preg_split('/\R+|[,،]+/u', $text) ?: [];
    $out = [];
    foreach ($items as $item) { $item = trim(strip_tags((string)$item)); if ($item !== '') $out[] = $item; }
    return array_values(array_unique($out));
}

function bm_cc_text_override_lines(string $raw): array {
    $out = [];
    foreach (preg_split('/\R/u', $raw) ?: [] as $line) {
        $line = trim((string)$line);
        if ($line === '' || str_starts_with($line, '#')) continue;
        $parts = preg_split('/\s*(?:=>|→|\|\|\|)\s*/u', $line, 2);
        if (!is_array($parts) || count($parts) !== 2) continue;
        $from = trim(str_replace('\\n', "\n", strip_tags((string)$parts[0])));
        $to = trim(str_replace('\\n', "\n", strip_tags((string)$parts[1])));
        $fromLen = function_exists('mb_strlen') ? mb_strlen($from, 'UTF-8') : strlen($from);
        $toLen = function_exists('mb_strlen') ? mb_strlen($to, 'UTF-8') : strlen($to);
        if ($from === '' || $fromLen > 1600 || $toLen > 1600) continue;
        $out[$from] = $to;
        if (count($out) >= 800) break;
    }
    return $out;
}
function bm_cc_text_override_dump(array $items): string {
    $lines = [];
    foreach ($items as $from => $to) {
        if (!is_string($from)) continue;
        $left = str_replace(["\r", "\n"], ['', '\\n'], $from);
        $right = str_replace(["\r", "\n"], ['', '\\n'], (string)$to);
        $lines[] = $left . ' => ' . $right;
    }
    return implode("\n", $lines);
}

function bm_cc_load_app_config(): array {
    $path = BM_ROOT_DIR . '/bankmovie_remote_config.json';
    $raw = is_file($path) ? @file_get_contents($path) : false;
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($data) ? $data : [];
}
function bm_cc_delete_inside(string $baseDir, string $name, array $allowedExts): bool {
    $name = basename($name);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts, true)) return false;
    $base = realpath($baseDir);
    $target = realpath($baseDir . DIRECTORY_SEPARATOR . $name);
    if (!$base || !$target || !str_starts_with($target, $base . DIRECTORY_SEPARATOR) || !is_file($target)) return false;
    return @unlink($target);
}
function bm_cc_clear_archive_cache(): int {
    $deleted = 0;
    $patterns = [];
    if (function_exists('bm_security_private_dir')) {
        $private = bm_security_private_dir();
        $patterns[] = $private . '/api2_html_*.cache*';
        $patterns[] = $private . '/api2_json_*.cache*';
        $patterns[] = $private . '/cache/api6/*.html';
        $patterns[] = $private . '/cache/api6/*.html.gz';
        $patterns[] = $private . '/cache/api6/*.tmp';
        $patterns[] = $private . '/api2_html_*.cache.lock';
        $patterns[] = $private . '/api2_json_*.cache.lock';
    }
    $tmp = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR);
    $patterns[] = $tmp . '/bankmovie_a1_*.json';
    foreach ($patterns as $pattern) {
        foreach (glob($pattern) ?: [] as $file) if (is_file($file) && @unlink($file)) $deleted++;
    }
    return $deleted;
}
function bm_cc_upload_release(array $file, string $preferredName = ''): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($file['tmp_name'])) throw new RuntimeException('فایل سالم دریافت نشد. محدودیت upload_max_filesize و post_max_size هاست را بررسی کنید.');
    $original = basename((string)($file['name'] ?? ''));
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    if (!in_array($ext, ['apk','zip'], true)) throw new RuntimeException('فقط فایل APK یا ZIP مجاز است.');
    $size = (int)($file['size'] ?? 0);
    if ($size < 1 || $size > 90 * 1024 * 1024) throw new RuntimeException('حجم فایل نامعتبر یا بیشتر از ۹۰ مگابایت است. برای فایل بزرگ‌تر از File Manager هاست استفاده کنید.');
    $name = trim($preferredName);
    if ($name === '') $name = pathinfo($original, PATHINFO_FILENAME);
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name) ?: ('bankmovie-' . date('Ymd-His'));
    $name = trim($name, '.-_');
    if ($name === '') $name = 'bankmovie-' . date('Ymd-His');
    $targetName = $name . '.' . $ext;
    $target = BM_ROOT_DIR . '/app/' . $targetName;
    if (!is_dir(BM_ROOT_DIR . '/app') && !@mkdir(BM_ROOT_DIR . '/app', 0755, true)) throw new RuntimeException('پوشه app قابل ایجاد نیست.');
    if (!@move_uploaded_file((string)$file['tmp_name'], $target)) throw new RuntimeException('ذخیره فایل در پوشه app ناموفق بود. Permission را بررسی کنید.');
    @chmod($target, 0644);
    return $targetName;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = (string)($_POST['archive_quick_action'] ?? $_POST['action'] ?? '');
    try {
        if ($action === 'save_yektanet') {
            $defaults = bm_yektanet_defaults();
            $settings = [
                'enabled' => isset($_POST['yk_enabled']),
                'publisher_url' => (string)($_POST['publisher_url'] ?? ''),
                'domains' => ['bankmoviee.ir'],
                'policy_version' => 8,
                'pages' => array_values(array_intersect((array)($_POST['pages'] ?? []), $defaults['pages'])),
                'slots' => [],
            ];
            foreach ($defaults['slots'] as $id => $def) {
                $settings['slots'][$id] = [
                    'enabled' => isset($_POST['slot_enabled'][$id]),
                    'device' => (string)($_POST['slot_device'][$id] ?? $def['device']),
                    'html' => (string)($_POST['slot_html'][$id] ?? ''),
                ];
            }
            if (!bm_yektanet_save_settings($settings)) throw new RuntimeException('فایل تنظیمات یکتانت قابل نوشتن نیست.');
            bm_cc_redirect('تنظیمات یکتانت ذخیره شد.', 'success', 'ads');
        }

        if ($action === 'save_app') {
            $config = bm_cc_load_app_config();
            $activeDomain = bm_cc_clean_url((string)($_POST['active_domain'] ?? ''), false);
            $apiUrl = bm_cc_clean_url((string)($_POST['api_url'] ?? ''), false);
            if ($activeDomain === '' || $apiUrl === '') throw new RuntimeException('دامنه فعال و آدرس API باید URL معتبر باشند.');
            $servers = [];
            for ($i=0; $i<2; $i++) {
                $domain = bm_cc_clean_url((string)($_POST['server_domain'][$i] ?? ''));
                $serverApi = bm_cc_clean_url((string)($_POST['server_api'][$i] ?? ''));
                if ($domain === '' || $serverApi === '') continue;
                $servers[] = [
                    'name' => trim(strip_tags((string)($_POST['server_name'][$i] ?? ('سرور ' . ($i+1))))) ?: ('سرور ' . ($i+1)),
                    'enabled' => isset($_POST['server_enabled'][$i]),
                    'priority' => max(1, min(99, (int)($_POST['server_priority'][$i] ?? ($i+1)))),
                    'domain' => $domain,
                    'api_url' => $serverApi,
                ];
            }
            if (!$servers) throw new RuntimeException('حداقل یک سرور معتبر لازم است.');
            usort($servers, static fn($a,$b) => $a['priority'] <=> $b['priority']);
            $config['schema_version'] = max(3, (int)($config['schema_version'] ?? 3));
            $config['ready'] = isset($_POST['app_ready']);
            $config['message'] = trim(strip_tags((string)($_POST['app_message'] ?? '')));
            $config['active_domain'] = $activeDomain;
            $config['api_url'] = $apiUrl;
            $config['servers'] = $servers;
            $config['notice'] = [
                'enabled' => isset($_POST['notice_enabled']),
                'id' => preg_replace('/[^A-Za-z0-9_-]/', '', (string)($_POST['notice_id'] ?? '')),
                'title' => trim(strip_tags((string)($_POST['notice_title'] ?? ''))),
                'message' => trim(strip_tags((string)($_POST['notice_message'] ?? ''))),
            ];
            $config['update'] = [
                'enabled' => isset($_POST['update_enabled']),
                'version_code' => max(0, (int)($_POST['version_code'] ?? 0)),
                'version_name' => trim(strip_tags((string)($_POST['version_name'] ?? ''))),
                'apk_url' => bm_cc_clean_url((string)($_POST['apk_url'] ?? '')),
                'apk_urls' => [
                    'universal' => bm_cc_clean_url((string)($_POST['apk_universal'] ?? '')),
                    'arm64_v8a' => bm_cc_clean_url((string)($_POST['apk_arm64'] ?? '')),
                    'armeabi_v7a' => bm_cc_clean_url((string)($_POST['apk_v7a'] ?? '')),
                ],
                'force' => isset($_POST['update_force']),
                'title' => trim(strip_tags((string)($_POST['update_title'] ?? ''))),
                'message' => trim(strip_tags((string)($_POST['update_message'] ?? ''))),
                'changes' => bm_cc_lines((string)($_POST['changes'] ?? '')),
            ];
            $config['version_policy'] = [
                'enabled' => isset($_POST['policy_enabled']),
                'minimum_version_code' => max(0, (int)($_POST['minimum_version_code'] ?? 0)),
                'minimum_version_name' => trim(strip_tags((string)($_POST['minimum_version_name'] ?? ''))),
                'blocked_version_names' => bm_cc_lines((string)($_POST['blocked_version_names'] ?? '')),
                'blocked_version_codes' => array_values(array_map('intval', bm_cc_lines((string)($_POST['blocked_version_codes'] ?? '')))),
                'force_update_blocked' => isset($_POST['force_update_blocked']),
                'block_message' => trim(strip_tags((string)($_POST['block_message'] ?? ''))),
            ];
            $config['ui'] = [
                'display_year' => max(0, min(2200, (int)($_POST['ui_display_year'] ?? 0))),
                'search_max_year' => max(0, min(2200, (int)($_POST['ui_search_max_year'] ?? 0))),
                'text_overrides' => [
                    'fa' => bm_cc_text_override_lines((string)($_POST['ui_text_overrides_fa'] ?? '')),
                    'en' => bm_cc_text_override_lines((string)($_POST['ui_text_overrides_en'] ?? '')),
                ],
            ];
            $config['updated_at'] = gmdate('c');
            if (!bm_cc_atomic_json_write(BM_ROOT_DIR . '/bankmovie_remote_config.json', $config)) throw new RuntimeException('ذخیره bankmovie_remote_config.json ناموفق بود.');
            bm_cc_redirect('تنظیمات اپلیکیشن ذخیره شد.', 'success', 'app');
        }

        if ($action === 'upload_release') {
            $name = bm_cc_upload_release($_FILES['release_file'] ?? [], (string)($_POST['release_name'] ?? ''));
            bm_cc_redirect('فایل انتشار «' . $name . '» آپلود شد.', 'success', 'app');
        }

        if ($action === 'delete_release') {
            $name = basename((string)($_POST['release_file_name'] ?? ''));
            if (!bm_cc_delete_inside(BM_ROOT_DIR . '/app', $name, ['apk','zip'])) throw new RuntimeException('حذف فایل انجام نشد.');
            bm_cc_redirect('فایل انتشار حذف شد.', 'success', 'app');
        }

        if ($action === 'save_archives') {
            $settings = bm_archive_get_settings();
            $settings['download_redirect_enabled'] = isset($_POST['download_redirect_enabled']);

            $settings['archive_order'] = bm_archive_order_from_post($_POST, bm_archive_order(), 'nested');
            $defaultArchive = (string)($_POST['archive_default'] ?? $settings['default_archive'] ?? 'archive1');
            $fallbackArchive = (string)($_POST['archive_fallback'] ?? $settings['fallback_archive'] ?? 'archive2');
            $settings['default_archive'] = in_array($defaultArchive, bm_archive_known_ids(), true) ? $defaultArchive : 'archive1';
            $settings['fallback_archive'] = in_array($fallbackArchive, bm_archive_known_ids(), true) ? $fallbackArchive : 'archive2';
            $settings['emergency'] = [
                'enabled'=>isset($_POST['archive_emergency_enabled']),
                'primary_archive'=>in_array((string)($_POST['archive_emergency_primary'] ?? ''), ['archive1','archive2','archive3','archive4','archive5','archive6'], true) ? (string)$_POST['archive_emergency_primary'] : 'archive2',
                'external_mode'=>in_array((string)($_POST['archive_emergency_mode'] ?? ''), ['hide','visible'], true) ? (string)$_POST['archive_emergency_mode'] : 'hide',
                'message'=>trim(strip_tags((string)($_POST['archive_emergency_message'] ?? ''))) ?: 'به‌دلیل محدودیت اینترنت، این آرشیو موقتاً در دسترس نیست. آرشیو داخلی بانک‌مووی همچنان فعال است.',
            ];

            foreach (bm_archive_known_ids() as $id) {
                $old = is_array($settings['archives'][$id] ?? null) ? $settings['archives'][$id] : [];
                $scope = strtolower(trim((string)($_POST['archive_scope'][$id] ?? ($old['access_scope'] ?? 'public'))));
                if (!in_array($scope, ['public','member','vip','admin'], true)) $scope = 'public';
                $playerGates = [];
                foreach (['master','internal','external','copy_link'] as $gateKey) {
                    $gateMode = strtolower(trim((string)($_POST['archive_player_gate'][$id][$gateKey] ?? ($old['player_gates'][$gateKey] ?? 'inherit'))));
                    if (!in_array($gateMode, ['inherit','free','vip'], true)) $gateMode = 'inherit';
                    $playerGates[$gateKey] = $gateMode;
                }

                $linkMode = strtolower(trim((string)($_POST['archive_download_link_mode'][$id] ?? ($old['download_link_mode'] ?? 'redirect'))));
                if (!in_array($linkMode, ['redirect','original','disabled'], true)) $linkMode = 'redirect';
                $redirectPolicy = strtolower(trim((string)($_POST['archive_download_redirect_policy'][$id] ?? ($old['download_redirect_policy'] ?? 'inherit'))));
                if (!in_array($redirectPolicy, ['inherit','on','off'], true)) $redirectPolicy = 'inherit';
                $settings['archives'][$id] = array_merge($old, [
                    'download_link_mode' => $id === 'archive5' ? 'original' : $linkMode,
                    'download_redirect_policy' => $id === 'archive5' ? 'inherit' : $redirectPolicy,
                    'label' => trim(strip_tags((string)($_POST['archive_label'][$id] ?? $id))),
                    'enabled' => isset($_POST['archive_enabled'][$id]),
                    'access_scope' => $scope,
                    'disabled_mode' => in_array((string)($_POST['archive_mode'][$id] ?? ''), ['visible','hide'], true) ? (string)$_POST['archive_mode'][$id] : 'visible',
                    'disabled_message' => trim(strip_tags((string)($_POST['archive_message'][$id] ?? ''))),
                    'download_access_scope' => in_array((string)($_POST['archive_download_scope'][$id] ?? ($old['download_access_scope'] ?? 'public')), ['public','member','vip','admin','disabled'], true) ? (string)($_POST['archive_download_scope'][$id] ?? $old['download_access_scope'] ?? 'public') : 'public',
                    'stream_access_scope' => in_array((string)($_POST['archive_stream_scope'][$id] ?? ($old['stream_access_scope'] ?? 'public')), ['public','member','vip','admin','disabled'], true) ? (string)($_POST['archive_stream_scope'][$id] ?? $old['stream_access_scope'] ?? 'public') : 'public',
                    'player_gates' => $playerGates,
                ]);

                // Per-archive home section controls. Unknown keys are ignored so a crafted POST
                // cannot create arbitrary settings. Empty labels intentionally mean "inherit".
                $knownSections = function_exists('bm_archive_section_catalog_defaults') ? bm_archive_section_catalog_defaults($id) : [];
                $oldSections = is_array($old['sections'] ?? null) ? $old['sections'] : [];
                $settings['archives'][$id]['sections'] = [];
                foreach ($knownSections as $sectionKey => $sectionDef) {
                    $oldSection = is_array($oldSections[$sectionKey] ?? null) ? $oldSections[$sectionKey] : [];
                    $customLabel = trim(strip_tags((string)($_POST['archive_section_label'][$id][$sectionKey] ?? ($oldSection['label'] ?? ''))));
                    if (function_exists('mb_substr')) $customLabel = mb_substr($customLabel, 0, 120, 'UTF-8');
                    else $customLabel = substr($customLabel, 0, 120);
                    $settings['archives'][$id]['sections'][$sectionKey] = [
                        'enabled' => isset($_POST['archive_section_enabled'][$id][$sectionKey]),
                        'label' => $customLabel,
                    ];
                }
            }
            $oldDelivery = bm_delivery_settings(true);
            $newDelivery = $oldDelivery;
            $newDelivery['poster_redirect_enabled'] = isset($_POST['poster_redirect_enabled']);
            if (!bm_delivery_save($newDelivery)) throw new RuntimeException('ذخیره ریدایرکت پوستر ناموفق بود.');
            if (!bm_archive_save_settings($settings)) {
                bm_delivery_save($oldDelivery);
                throw new RuntimeException('ذخیره تنظیمات آرشیوها ناموفق بود.');
            }
            bm_cc_redirect('وضعیت آرشیوها ذخیره شد.', 'success', 'archives');
        }

        if ($action === 'archive_emergency_on') {
            $settings = bm_archive_get_settings();
            $settings['emergency'] = array_merge((array)($settings['emergency'] ?? []), ['enabled'=>true]);
            if (!bm_archive_save_settings($settings)) throw new RuntimeException('فعال‌سازی حالت اینترنت ملی ناموفق بود.');
            bm_cc_redirect('حالت اینترنت ملی فعال شد.', 'success', 'archives');
        }

        if ($action === 'archive_emergency_off') {
            $settings = bm_archive_get_settings();
            $settings['emergency'] = array_merge((array)($settings['emergency'] ?? []), ['enabled'=>false]);
            if (!bm_archive_save_settings($settings)) throw new RuntimeException('بازگشت حالت عادی ناموفق بود.');
            bm_cc_redirect('حالت اینترنت ملی خاموش شد.', 'success', 'archives');
        }

        if ($action === 'rate_save_settings') {
            if (!function_exists('bm_security_global_rate_save_settings')) throw new RuntimeException('ماژول Anti‑503 در دسترس نیست.');
            $settings = [
                'enabled' => isset($_POST['rate_enabled']),
                'limit' => max(1, min(5000, (int)($_POST['rate_limit'] ?? 20))),
                'window' => max(10, min(3600, (int)($_POST['rate_window'] ?? 60))),
                'penalty' => max(60, min(86400, (int)($_POST['rate_penalty'] ?? 300))),
                'page_views_only' => true,
                'challenge_enabled' => isset($_POST['rate_challenge_enabled']),
                'challenge_ttl' => max(60, min(900, (int)($_POST['rate_challenge_ttl'] ?? 300))),
                'challenge_min_age_ms' => max(700, min(10000, (int)($_POST['rate_challenge_min_age_ms'] ?? 1200))),
                'captcha_attempts' => max(1, min(10, (int)($_POST['rate_captcha_attempts'] ?? 3))),
                'captcha_pass_ttl' => max(60, min(3600, (int)($_POST['rate_captcha_pass_ttl'] ?? 600))),
                'visitor_limit' => max(1, min(5000, (int)($_POST['rate_visitor_limit'] ?? 24))),
                'session_limit' => max(1, min(5000, (int)($_POST['rate_session_limit'] ?? 30))),
                'user_limit' => max(1, min(5000, (int)($_POST['rate_user_limit'] ?? 36))),
                'escalation_enabled' => isset($_POST['rate_escalation_enabled']),
                'escalation_duration' => max(300, min(86400, (int)($_POST['rate_escalation_duration'] ?? 3600))),
                'escalation_multiplier' => max(2, min(10, (int)($_POST['rate_escalation_multiplier'] ?? 3))),
                'escalation_max_penalty' => max(60, min(86400, (int)($_POST['rate_escalation_max_penalty'] ?? 3600))),
                'endpoint_global_block' => isset($_POST['rate_endpoint_global_block']),
                'privileged_bypass' => isset($_POST['rate_privileged_bypass']),
                'live_search_bypass' => true,
                'api_background_bypass' => true,
                'app_bypass' => isset($_POST['rate_app_bypass']),
                'log_enabled' => isset($_POST['rate_log_enabled']),
                'whitelist' => bm_cc_lines((string)($_POST['rate_whitelist'] ?? '')),
                'blacklist' => bm_cc_lines((string)($_POST['rate_blacklist'] ?? '')),
            ];
            if (!bm_security_global_rate_save_settings($settings)) throw new RuntimeException('ذخیره تنظیمات Anti‑503 ناموفق بود.');
            bm_cc_redirect('تنظیمات Anti‑503 / Anti‑Spam ذخیره شد.', 'success', 'security');
        }
        if ($action === 'rate_manual_block') {
            $ip = trim((string)($_POST['rate_ip'] ?? ''));
            $minutes = max(1, min(1440, (int)($_POST['rate_minutes'] ?? 5)));
            $note = trim(strip_tags((string)($_POST['rate_note'] ?? '')));
            if (!filter_var($ip, FILTER_VALIDATE_IP)) throw new RuntimeException('IP نامعتبر است.');
            if (!function_exists('bm_security_global_rate_block_ip') || !bm_security_global_rate_block_ip($ip, $minutes * 60, $note)) throw new RuntimeException('مسدودسازی دستی انجام نشد.');
            bm_cc_redirect('IP ' . $ip . ' برای ' . $minutes . ' دقیقه مسدود شد.', 'success', 'security');
        }
        if ($action === 'rate_unblock') {
            $ip = trim((string)($_POST['rate_ip'] ?? ''));
            if (!filter_var($ip, FILTER_VALIDATE_IP)) throw new RuntimeException('IP نامعتبر است.');
            if (!function_exists('bm_security_global_rate_unblock') || !bm_security_global_rate_unblock($ip)) throw new RuntimeException('رفع مسدودی انجام نشد.');
            bm_cc_redirect('مسدودی IP ' . $ip . ' برداشته شد.', 'success', 'security');
        }
        if ($action === 'rate_prune') {
            $count = function_exists('bm_security_global_rate_prune') ? bm_security_global_rate_prune(86400) : 0;
            bm_cc_redirect($count . ' رکورد قدیمی Rate Limit پاک شد.', 'success', 'security');
        }
        if ($action === 'rate_clear_events') {
            $count = function_exists('bm_security_global_rate_clear_events') ? bm_security_global_rate_clear_events() : 0;
            bm_cc_redirect($count . ' فایل لاگ Anti‑503 پاک شد. آمار تجمیعی حمله‌ها حفظ شده است.', 'success', 'security');
        }
        if ($action === 'rate_reset_counters') {
            $count = function_exists('bm_security_global_rate_reset_states') ? bm_security_global_rate_reset_states() : 0;
            bm_cc_redirect($count . ' شمارنده/مسدودی موقت پاک شد. Whitelist/Blacklist و تنظیمات حفظ شدند.', 'success', 'security');
        }

        if ($action === 'clear_archive_cache') {
            $count = bm_cc_clear_archive_cache();
            bm_cc_redirect($count . ' فایل کش آرشیو پاک شد.', 'success', 'archives');
        }
    } catch (Throwable $e) {
        bm_cc_redirect($e->getMessage(), 'error', str_starts_with($action, 'rate_') ? 'security' : (in_array($action, ['save_yektanet'], true) ? 'ads' : (str_contains($action, 'archive') || str_contains($action, 'cookie') ? 'archives' : 'app')));
    }
}

$tab = (string)($_GET['tab'] ?? 'overview');
if (!in_array($tab, ['overview','ads','app','archives','security','tools'], true)) $tab = 'overview';
$message = trim((string)($_GET['msg'] ?? ''));
$messageType = (string)($_GET['type'] ?? 'success');
$yk = bm_yektanet_get_settings();
$appConfig = bm_cc_load_app_config();
$appConfig += ['ready'=>true,'message'=>'','active_domain'=>'https://bankmovie.top','api_url'=>'https://bankmovie.top/app_api.php','servers'=>[],'notice'=>[],'update'=>[],'version_policy'=>[],'ui'=>[]];
$appConfig['ui'] = is_array($appConfig['ui']) ? $appConfig['ui'] : [];
$appConfig['ui']['text_overrides'] = is_array($appConfig['ui']['text_overrides'] ?? null) ? $appConfig['ui']['text_overrides'] : ['fa'=>[],'en'=>[]];
$appConfig['notice'] = is_array($appConfig['notice']) ? $appConfig['notice'] : [];
$appConfig['update'] = is_array($appConfig['update']) ? $appConfig['update'] : [];
$appConfig['version_policy'] = is_array($appConfig['version_policy']) ? $appConfig['version_policy'] : [];
$servers = array_values(is_array($appConfig['servers']) ? $appConfig['servers'] : []);
while (count($servers) < 2) $servers[] = ['name'=>'','enabled'=>false,'priority'=>count($servers)+1,'domain'=>'','api_url'=>''];
$archiveSettings = bm_archive_get_settings();
$deliveryCfg = bm_delivery_settings(true);
$rateReport = ($tab === 'security' && function_exists('bm_security_global_rate_report')) ? bm_security_global_rate_report(160) : ['settings'=>['enabled'=>true,'limit'=>20,'window'=>60,'penalty'=>300,'page_views_only'=>true,'challenge_enabled'=>true,'challenge_ttl'=>300,'challenge_min_age_ms'=>1200,'captcha_attempts'=>3,'captcha_pass_ttl'=>600,'visitor_limit'=>24,'session_limit'=>30,'user_limit'=>36,'escalation_enabled'=>true,'escalation_duration'=>3600,'escalation_multiplier'=>3,'escalation_max_penalty'=>3600,'endpoint_global_block'=>true,'live_search_bypass'=>true,'api_background_bypass'=>true,'app_bypass'=>true,'log_enabled'=>true,'whitelist'=>[],'blacklist'=>[]],'active'=>[],'recent'=>[],'events'=>[],'top_ips'=>[],'top_targets'=>[],'metrics'=>[],'stats'=>['active'=>0,'recent_ips'=>0,'violations'=>0,'blocked_hits'=>0,'today_violations'=>0,'today_attack_ips'=>0,'today_blocked_hits'=>0,'total_attacks'=>0]];
$releaseFiles = array_merge(glob(BM_ROOT_DIR . '/app/*.apk') ?: [], glob(BM_ROOT_DIR . '/app/*.zip') ?: []);
usort($releaseFiles, static fn($a,$b) => ((int)@filemtime($b)) <=> ((int)@filemtime($a)));
$releaseMeta = function_exists('bm_latest_update') ? bm_latest_update() : ['version'=>'','build'=>0,'downloads'=>[]];
$dirs = [
    'پوشه خصوصی' => function_exists('bm_security_private_dir') ? bm_security_private_dir() : BM_ROOT_DIR,
    'پوشه اپ' => BM_ROOT_DIR . '/app',
    'پوشه کش' => BM_ROOT_DIR . '/cache',
    'پوشه آپلود' => BM_ROOT_DIR . '/uploads',
];
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>مرکز کنترل کامل | BankMovie</title>
<style>
:root{--bg:#070a11;--panel:#111725;--panel2:#0c111d;--line:rgba(255,255,255,.1);--text:#f7f9ff;--muted:#a8b2c7;--accent:#2f7cff;--green:#24d17e;--red:#ff5d73;--yellow:#ffc857}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% 0,rgba(47,124,255,.18),transparent 30%),var(--bg);color:var(--text);font-family:Tahoma,Arial,sans-serif}.layout{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh}.side{position:sticky;top:0;height:100vh;padding:22px 16px;background:rgba(8,12,20,.92);border-left:1px solid var(--line);overflow:auto}.brand{font-size:22px;font-weight:900;margin:4px 10px 24px}.brand span{color:var(--accent)}.nav{display:grid;gap:7px}.nav a{color:var(--muted);text-decoration:none;padding:12px 14px;border-radius:13px;font-weight:700}.nav a:hover,.nav a.active{background:rgba(47,124,255,.14);color:#fff}.nav hr{width:100%;border:0;border-top:1px solid var(--line);margin:10px 0}.main{padding:28px;width:min(1400px,100%);margin:auto}.hero{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:22px}.hero h1{margin:0 0 8px;font-size:30px}.hero p{margin:0;color:var(--muted);line-height:1.8}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 15px;border-radius:12px;border:1px solid var(--line);background:#182134;color:#fff;text-decoration:none;font:inherit;font-weight:800;cursor:pointer}.btn.primary{background:var(--accent);border-color:transparent}.btn.danger{background:rgba(255,93,115,.14);color:#ff9baa}.btn.good{background:rgba(36,209,126,.14);color:#86f0ba}.flash{padding:13px 16px;border-radius:14px;margin-bottom:18px;border:1px solid}.flash.success{background:rgba(36,209,126,.12);border-color:rgba(36,209,126,.35)}.flash.error{background:rgba(255,93,115,.12);border-color:rgba(255,93,115,.35)}.grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}.card{grid-column:span 12;background:linear-gradient(180deg,rgba(19,27,43,.95),rgba(12,17,29,.95));border:1px solid var(--line);border-radius:20px;padding:20px;box-shadow:0 18px 55px rgba(0,0,0,.22)}.card.half{grid-column:span 6}.card.third{grid-column:span 4}.card h2,.card h3{margin:0 0 8px}.sub{color:var(--muted);font-size:13px;line-height:1.8;margin:0 0 16px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat{padding:16px;border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.03)}.stat b{font-size:21px;display:block}.stat small{color:var(--muted)}.form-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:13px}.field{grid-column:span 6}.field.full{grid-column:span 12}.field.third{grid-column:span 4}.field label{display:block;margin-bottom:7px;color:#dbe4f7;font-size:13px;font-weight:800}.field input[type=text],.field input[type=url],.field input[type=number],.field textarea,.field select{width:100%;background:#080d17;border:1px solid var(--line);border-radius:12px;color:#fff;padding:11px 12px;font:inherit}.field textarea{min-height:120px;resize:vertical;direction:ltr;text-align:left}.field textarea.fa{direction:rtl;text-align:right}.check{display:flex;gap:9px;align-items:center;min-height:42px}.check input{width:18px;height:18px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.slot{border:1px solid var(--line);border-radius:16px;padding:15px;margin-top:13px}.slot-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:10px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:11px;border-bottom:1px solid var(--line);text-align:right;font-size:13px}.badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:900}.badge.on{background:rgba(36,209,126,.14);color:#82efb7}.badge.off{background:rgba(255,93,115,.13);color:#ff9baa}.code{direction:ltr;text-align:left;font-family:monospace;font-size:12px;word-break:break-all}.tabs-mobile{display:none;gap:7px;overflow:auto;margin-bottom:16px}.tabs-mobile a{white-space:nowrap}.tab{display:none}.tab.active{display:block}.tool-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.tool{display:block;text-decoration:none;color:#fff;padding:17px;border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.035)}.tool b{display:block;margin-bottom:6px}.tool span{color:var(--muted);font-size:12px;line-height:1.7}@media(max-width:980px){.layout{display:block}.side{display:none}.main{padding:18px}.tabs-mobile{display:flex}.card.half,.card.third{grid-column:span 12}.stats{grid-template-columns:repeat(2,1fr)}.field,.field.third{grid-column:span 12}.tool-grid{grid-template-columns:1fr}.hero{display:block}.hero .actions{margin-top:12px}}@media(max-width:520px){.stats{grid-template-columns:1fr}.card{padding:15px}.table{display:block;overflow:auto}}
.rate-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.rate-kpi{padding:16px;border-radius:16px;border:1px solid var(--line);background:rgba(255,255,255,.03)}.rate-kpi b{display:block;font-size:25px}.rate-kpi small{color:var(--muted)}.rate-live{color:#ffb2bf}.rate-ok{color:#8df0ba}.rate-uri{max-width:430px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:ltr;text-align:left}.rate-table-wrap{overflow:auto}.rate-table-wrap .table{min-width:920px}@media(max-width:760px){.rate-kpis{grid-template-columns:repeat(2,1fr)}}
</style>
<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>
<style id="bm-archive-manager-v14861927">
.archive-manager-hero{position:relative;overflow:hidden;padding:24px!important;background:linear-gradient(135deg,rgba(47,124,255,.18),rgba(124,92,255,.10) 52%,rgba(34,211,238,.08))!important;border-color:rgba(86,153,255,.26)!important}.archive-manager-hero:before{content:"";position:absolute;width:260px;height:260px;border-radius:50%;background:rgba(47,124,255,.12);filter:blur(10px);left:-100px;top:-150px}.archive-manager-title{display:flex;align-items:center;gap:14px}.archive-manager-icon{width:48px;height:48px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(135deg,#2f7cff,#6d5cff);box-shadow:0 14px 34px rgba(47,124,255,.26);font-size:22px}.archive-manager-kpis{display:flex;gap:9px;flex-wrap:wrap;margin-top:16px}.archive-kpi{display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border-radius:999px;border:1px solid rgba(255,255,255,.10);background:rgba(3,9,20,.34);color:#cbd8ef;font-size:12px;font-weight:800}.archive-card{position:relative;overflow:hidden;padding:18px!important;border-color:rgba(85,142,255,.18)!important;background:linear-gradient(180deg,rgba(20,29,47,.96),rgba(10,15,27,.96))!important;transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease}.archive-card:hover{transform:translateY(-2px);border-color:rgba(84,147,255,.34)!important;box-shadow:0 22px 48px rgba(0,0,0,.22)}.archive-card:after{content:"";position:absolute;width:150px;height:150px;border-radius:50%;background:rgba(47,124,255,.10);filter:blur(10px);left:-70px;top:-80px;pointer-events:none}.archive-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:16px}.archive-card-name{display:flex;align-items:center;gap:11px}.archive-num{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;background:rgba(47,124,255,.13);border:1px solid rgba(47,124,255,.25);color:#8eb8ff;font-weight:900}.archive-card h3{margin:0!important;font-size:18px}.archive-card small{display:block;color:var(--muted);margin-top:4px}.archive-state{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border-radius:999px;font-size:11px;font-weight:900;border:1px solid}.archive-state.on{color:#8cf0bb;background:rgba(36,209,126,.10);border-color:rgba(36,209,126,.24)}.archive-state.off{color:#ff9baa;background:rgba(255,93,115,.10);border-color:rgba(255,93,115,.24)}.archive-state:before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor;box-shadow:0 0 14px currentColor}.archive-toggle-box{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 13px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid var(--line);margin-bottom:13px}.archive-toggle-box .check{margin:0;min-height:auto}.archive-audience{margin-top:12px;padding:13px;border:1px solid rgba(47,124,255,.20);border-radius:15px;background:rgba(47,124,255,.055)}.archive-audience-label{font-size:12px;font-weight:900;color:#dce8ff;margin-bottom:9px}.archive-segments{display:grid;grid-template-columns:1fr 1fr;gap:7px}.archive-segment{position:relative;cursor:pointer}.archive-segment input{position:absolute;opacity:0;pointer-events:none}.archive-segment span{display:flex;align-items:center;justify-content:center;min-height:41px;border:1px solid var(--line);border-radius:12px;background:#0a1020;color:var(--muted);font-size:12px;font-weight:900;transition:.16s ease}.archive-segment input:checked+span{background:linear-gradient(135deg,rgba(47,124,255,.28),rgba(109,92,255,.22));border-color:rgba(89,153,255,.56);color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.04),0 8px 22px rgba(47,124,255,.14)}.archive-fixed-public{padding:10px 12px;border-radius:12px;background:rgba(36,209,126,.06);border:1px solid rgba(36,209,126,.16);color:#a9eac9;font-size:12px;font-weight:800}.archive-connect-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.archive-connect-card{border:1px solid var(--line);border-radius:18px;padding:18px;background:linear-gradient(180deg,rgba(18,26,43,.94),rgba(10,15,26,.94))}.archive-connect-card h3{display:flex;align-items:center;gap:8px}.archive-connect-status{display:inline-flex;margin-top:7px;padding:5px 9px;border-radius:999px;background:rgba(36,209,126,.09);color:#8cf0bb;font-size:11px;font-weight:900}.archive-savebar{position:sticky;bottom:14px;z-index:20;margin-top:16px;padding:12px 14px;border-radius:17px;border:1px solid rgba(70,139,255,.26);background:rgba(8,13,24,.86);backdrop-filter:blur(18px);box-shadow:0 18px 45px rgba(0,0,0,.28);display:flex;align-items:center;justify-content:space-between;gap:12px}.archive-savebar .sub{margin:0}.archive-manager-note{padding:13px 14px;border-radius:14px;border:1px solid rgba(255,200,87,.18);background:rgba(255,200,87,.055);color:#dbc98c;font-size:12px;line-height:1.8}@media(max-width:760px){.archive-connect-grid{grid-template-columns:1fr}.archive-savebar{align-items:stretch;flex-direction:column}.archive-savebar .btn{width:100%}.archive-card-top{align-items:center}.archive-manager-title{align-items:flex-start}}
.archive-section-manager{margin-top:13px;border:1px solid rgba(47,124,255,.18);border-radius:15px;background:rgba(5,10,20,.34);overflow:hidden}.archive-section-manager summary{list-style:none;cursor:pointer;min-height:46px;padding:11px 13px;display:flex;align-items:center;justify-content:space-between;gap:10px;font-size:12px;font-weight:900;color:#e5edff}.archive-section-manager summary::-webkit-details-marker{display:none}.archive-section-manager summary small{color:#8eb8ff;font-size:10px;padding:4px 8px;border-radius:999px;background:rgba(47,124,255,.11)}.archive-section-help{padding:0 13px 10px;color:var(--muted);font-size:11px;line-height:1.8}.archive-section-list{display:grid;gap:8px;padding:0 10px 11px}.archive-section-row{display:grid;grid-template-columns:auto minmax(110px,.7fr) minmax(150px,1.3fr);align-items:center;gap:10px;padding:9px;border-radius:12px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.025)}.archive-section-switch{display:inline-flex;align-items:center;gap:6px;white-space:nowrap;font-size:10px;font-weight:900;color:#9eb0ca}.archive-section-switch input{width:17px;height:17px;accent-color:var(--green)}.archive-section-copy{min-width:0}.archive-section-copy b{display:block;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.archive-section-copy code{display:block;margin-top:3px;color:#71819d;font-size:9px;direction:ltr;text-align:right}.archive-section-title-input{width:100%;min-width:0;background:#080d17;border:1px solid var(--line);border-radius:10px;color:#fff;padding:9px 10px;font:inherit;font-size:11px}.archive-section-title-input:focus{outline:none;border-color:rgba(47,124,255,.58);box-shadow:0 0 0 3px rgba(47,124,255,.10)}@media(max-width:760px){.archive-section-row{grid-template-columns:auto 1fr}.archive-section-title-input{grid-column:1/-1}}
</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
<link rel="stylesheet" href="/assets/css/bm-archive-sort-manager-v1.css?v=20261020-v2">
</head>
<body class="bm-admin-unified">
<div class="layout">
<aside class="side"><div class="brand">Bank<span>Movie</span></div><nav class="nav">
<?php foreach (['overview'=>'نمای کلی','ads'=>'تبلیغات یکتانت','app'=>'مدیریت اپ','archives'=>'مدیریت آرشیوها','security'=>'ضد 503 و IPها','tools'=>'همه ابزارها'] as $id=>$label): ?><a class="<?= $tab===$id?'active':'' ?>" href="?tab=<?= $id ?>"><?= $label ?></a><?php endforeach; ?>
<hr><a href="admin">پنل اصلی</a><a href="/">مشاهده سایت</a><a href="/logout">خروج</a></nav></aside>
<main class="main">
<div class="hero"><div><h1>مرکز کنترل کامل بانک‌مووی</h1><p>مدیریت تبلیغات، اپلیکیشن، آرشیوها و دسترسی سریع به تمام ابزارهای مدیریتی.</p></div><div class="actions"><a class="btn" href="admin">پنل اصلی</a><a class="btn primary" href="/" target="_blank">مشاهده سایت</a></div></div>
<div class="tabs-mobile"><?php foreach (['overview'=>'نمای کلی','ads'=>'تبلیغات','app'=>'اپ','archives'=>'آرشیوها','security'=>'ضد 503','tools'=>'ابزارها'] as $id=>$label): ?><a class="btn <?= $tab===$id?'primary':'' ?>" href="?tab=<?= $id ?>"><?= $label ?></a><?php endforeach; ?></div>
<?php if ($message !== ''): ?><div class="flash <?= $messageType==='error'?'error':'success' ?>"><?= bm_cc_h($message) ?></div><?php endif; ?>

<section class="tab <?= $tab==='overview'?'active':'' ?>">
<div class="grid"><div class="card"><h2>وضعیت سریع</h2><p class="sub">مهم‌ترین وضعیت‌های قابل کنترل از همین صفحه.</p><div class="stats">
<div class="stat"><b><?= !empty($yk['enabled'])?'فعال':'خاموش' ?></b><small>اسکریپت یکتانت</small></div>
<div class="stat"><b><?= count(array_filter($yk['slots'], fn($s)=>!empty($s['enabled']) && trim((string)$s['html'])!=='')) ?></b><small>جایگاه فعال یکتانت</small></div>
<div class="stat"><b><?= !empty($appConfig['ready'])?'آنلاین':'توقف' ?></b><small>وضعیت اپ</small></div>
<div class="stat"><b><?= count(array_filter($archiveSettings['archives'], fn($a)=>!empty($a['enabled']))) ?>/4</b><small>آرشیو فعال</small></div>
</div></div>
<div class="card half"><h3>انتشار فعلی اپ</h3><p class="sub">نسخه تشخیص داده‌شده از JSON یا فایل‌های پوشه app.</p><table class="table"><tr><th>نسخه</th><td><?= bm_cc_h($releaseMeta['version'] ?? 'نامشخص') ?></td></tr><tr><th>Build</th><td><?= (int)($releaseMeta['build'] ?? 0) ?></td></tr><tr><th>فایل‌ها</th><td><?= count($releaseFiles) ?></td></tr></table><div class="actions"><a class="btn primary" href="?tab=app">مدیریت اپ</a><a class="btn" href="/application" target="_blank">صفحه اپ</a></div></div>
<div class="card half"><h3>آرشیوها</h3><p class="sub">وضعیت هر هفت آرشیو؛ بدون حذف تنظیمات قبلی.</p><table class="table"><?php foreach($archiveSettings['archives'] as $id=>$row): ?><tr><th><?= bm_cc_h($row['label']) ?></th><td><span class="badge <?= !empty($row['enabled'])?'on':'off' ?>"><?= !empty($row['enabled'])?'فعال':'غیرفعال' ?></span></td></tr><?php endforeach; ?></table><div class="actions"><a class="btn primary" href="?tab=archives">مدیریت آرشیوها</a></div></div>
<div class="card"><h3>ابزارهای مدیریت موجود</h3><div class="tool-grid"><a class="tool" href="admin_site_manager"><b>مدیریت ظاهر و متن‌ها</b><span>کنترل هدر، فوتر، صفحه‌ها، PWA، جستجو و متن‌های عمومی</span></a><a class="tool" href="admin"><b>محتوا و کاربران</b><span>فیلم، سریال، استوری، درخواست‌ها، نظرات، بنر داخلی و کاربران</span></a><a class="tool" href="admin_slider"><b>اسلایدر</b><span>افزودن، ویرایش، ترتیب و فعال‌سازی اسلایدها</span></a><a class="tool" href="admin_collections"><b>کالکشن‌ها</b><span>ساخت کالکشن و مدیریت فیلم‌های داخل آن</span></a><a class="tool" href="/_lider/tools/api_manager"><b>API و منابع</b><span>تنظیم منابع و بررسی وضعیت APIها</span></a><a class="tool" href="admin_sitemap"><b>سایت‌مپ</b><span>ساخت، بازسازی و بررسی sitemap دامنه اصلی</span></a><a class="tool" href="admin_health"><b>عیب‌یابی</b><span>Permission، دیتابیس، افزونه‌ها و ساختار پنل</span></a></div></div></div>
</section>

<section class="tab <?= $tab==='ads'?'active':'' ?>">
<form method="post" action="admin_control_center"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_yektanet">
<div class="grid"><div class="card"><h2>مدیریت کامل یکتانت</h2><p class="sub">کدهای رسمی یکتانت را بدون تغییر ذخیره کن. هیچ CSS یا JavaScript سفارشی، حالت شناور، پاپ‌آپ یا مودال روی جایگاه‌ها اعمال نمی‌شود. جایگاه اصلی روی موبایل و دسکتاپ نمایش داده می‌شود و کل صفحه حداکثر ۴ جایگاه رندر می‌کند.</p><div class="form-grid">
<div class="field full"><label class="check"><input type="checkbox" name="yk_enabled" <?= !empty($yk['enabled'])?'checked':'' ?>> فعال‌بودن سراسری یکتانت</label></div>
<div class="field full"><label>آدرس رسمی اسکریپت ناشر یکتانت</label><input class="code" type="url" name="publisher_url" value="<?= bm_cc_h($yk['publisher_url']) ?>" required><p class="sub">فقط آدرسی را قرار بده که خود یکتانت تحویل داده است.</p></div>
<div class="field"><label>دامنه فعال تبلیغات</label><label class="check"><input type="checkbox" checked disabled> bankmoviee.ir</label><p class="sub">تبلیغات فعلاً فقط روی bankmoviee.ir فعال است و روی bankmovie.top هیچ اسکریپت یا جایگاهی لود نمی‌شود. آدرس اسکریپت ناشر دقیقاً همان کد رسمی یکتانت باقی می‌ماند.</p></div>
<div class="field"><label>صفحات فعال</label><div style="columns:2"><?php foreach(bm_yektanet_defaults()['pages'] as $page): ?><label class="check"><input type="checkbox" name="pages[]" value="<?= bm_cc_h($page) ?>" <?= in_array($page,$yk['pages'],true)?'checked':'' ?>> <?= bm_cc_h($page) ?></label><?php endforeach; ?></div></div>
</div></div>
<?php foreach(bm_yektanet_defaults()['slots'] as $id=>$def): $slot=$yk['slots'][$id]; ?><div class="card"><div class="slot-head"><div><h3><?= bm_cc_h($def['label']) ?></h3><span class="code"><?= bm_cc_h($id) ?></span></div><label class="check"><input type="checkbox" name="slot_enabled[<?= bm_cc_h($id) ?>]" <?= !empty($slot['enabled'])?'checked':'' ?>> فعال</label></div><div class="form-grid"><div class="field third"><label>نوع نمایش</label><select name="slot_device[<?= bm_cc_h($id) ?>]"><option value="all" <?= $slot['device']==='all'?'selected':'' ?>>همه دستگاه‌ها</option><option value="desktop" <?= $slot['device']==='desktop'?'selected':'' ?>>فقط دسکتاپ</option><option value="mobile" <?= $slot['device']==='mobile'?'selected':'' ?>>فقط موبایل</option></select></div><div class="field full"><label>کد HTML جایگاه از پنل یکتانت</label><textarea name="slot_html[<?= bm_cc_h($id) ?>]" placeholder="کد جایگاه یکتانت را بدون تغییر اینجا قرار بده"><?= bm_cc_h($slot['html']) ?></textarea></div></div></div><?php endforeach; ?>
<div class="card"><p class="sub">جایگاه <span class="code">global_banner</span> در صفحه اصلی بعد از اسلایدر، در صفحه فیلم قبل از لینک دانلود و در سایر صفحات محتوایی قبل از فوتر قرار می‌گیرد. اندازه، iframe و محتوای کد یکتانت دست‌کاری نمی‌شود.</p><div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات تبلیغات</button><a class="btn" href="/movie/test" target="_blank">تست صفحه فیلم</a></div></div></div></form>
</section>

<section class="tab <?= $tab==='app'?'active':'' ?>">
<form method="post" action="admin_control_center"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_app"><div class="grid">
<div class="card"><h2>وضعیت و سرورهای اپ</h2><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="app_ready" <?= !empty($appConfig['ready'])?'checked':'' ?>> اپ آماده و در دسترس باشد</label></div><div class="field full"><label>پیام زمان توقف</label><input type="text" name="app_message" value="<?= bm_cc_h($appConfig['message']) ?>"></div><div class="field"><label>دامنه فعال</label><input class="code" type="url" name="active_domain" value="<?= bm_cc_h($appConfig['active_domain']) ?>" required></div><div class="field"><label>API اصلی</label><input class="code" type="url" name="api_url" value="<?= bm_cc_h($appConfig['api_url']) ?>" required></div></div></div>
<?php for($i=0;$i<2;$i++): $srv=$servers[$i]; ?><div class="card half"><h3>سرور <?= $i+1 ?></h3><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="server_enabled[<?= $i ?>]" <?= !empty($srv['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label>نام</label><input type="text" name="server_name[<?= $i ?>]" value="<?= bm_cc_h($srv['name'] ?? '') ?>"></div><div class="field"><label>اولویت</label><input type="number" min="1" max="99" name="server_priority[<?= $i ?>]" value="<?= (int)($srv['priority'] ?? $i+1) ?>"></div><div class="field full"><label>دامنه</label><input class="code" type="url" name="server_domain[<?= $i ?>]" value="<?= bm_cc_h($srv['domain'] ?? '') ?>"></div><div class="field full"><label>API</label><input class="code" type="url" name="server_api[<?= $i ?>]" value="<?= bm_cc_h($srv['api_url'] ?? '') ?>"></div></div></div><?php endfor; ?>
<div class="card half"><h3>اعلان داخل اپ</h3><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="notice_enabled" <?= !empty($appConfig['notice']['enabled'])?'checked':'' ?>> نمایش اعلان</label></div><div class="field"><label>شناسه اعلان</label><input type="text" name="notice_id" value="<?= bm_cc_h($appConfig['notice']['id'] ?? '') ?>"></div><div class="field"><label>عنوان</label><input type="text" name="notice_title" value="<?= bm_cc_h($appConfig['notice']['title'] ?? '') ?>"></div><div class="field full"><label>متن</label><textarea class="fa" name="notice_message"><?= bm_cc_h($appConfig['notice']['message'] ?? '') ?></textarea></div></div></div>
<div class="card half"><h3>آپدیت اپ</h3><div class="form-grid"><div class="field"><label class="check"><input type="checkbox" name="update_enabled" <?= !empty($appConfig['update']['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label class="check"><input type="checkbox" name="update_force" <?= !empty($appConfig['update']['force'])?'checked':'' ?>> اجباری</label></div><div class="field"><label>Version Code</label><input type="number" min="0" name="version_code" value="<?= (int)($appConfig['update']['version_code'] ?? 0) ?>"></div><div class="field"><label>Version Name</label><input type="text" name="version_name" value="<?= bm_cc_h($appConfig['update']['version_name'] ?? '') ?>"></div><div class="field full"><label>عنوان آپدیت</label><input type="text" name="update_title" value="<?= bm_cc_h($appConfig['update']['title'] ?? '') ?>"></div><div class="field full"><label>پیام آپدیت</label><textarea class="fa" name="update_message"><?= bm_cc_h($appConfig['update']['message'] ?? '') ?></textarea></div><div class="field full"><label>تغییرات؛ هر مورد یک خط</label><textarea class="fa" name="changes"><?= bm_cc_h(implode("\n", (array)($appConfig['update']['changes'] ?? []))) ?></textarea></div></div></div>
<div class="card"><h3>لینک‌های دانلود آپدیت</h3><div class="form-grid"><div class="field full"><label>لینک عمومی APK</label><input class="code" type="url" name="apk_url" value="<?= bm_cc_h($appConfig['update']['apk_url'] ?? '') ?>"></div><div class="field third"><label>Universal</label><input class="code" type="url" name="apk_universal" value="<?= bm_cc_h($appConfig['update']['apk_urls']['universal'] ?? '') ?>"></div><div class="field third"><label>ARM64</label><input class="code" type="url" name="apk_arm64" value="<?= bm_cc_h($appConfig['update']['apk_urls']['arm64_v8a'] ?? '') ?>"></div><div class="field third"><label>V7A</label><input class="code" type="url" name="apk_v7a" value="<?= bm_cc_h($appConfig['update']['apk_urls']['armeabi_v7a'] ?? '') ?>"></div></div></div>
<div class="card"><h3>کنترل متن و سال‌های اپ</h3><p class="sub">فرمت هر قانون: متن فعلی =&gt; متن جدید. متغیرهای {{year}}، {{prev_year}} و {{next_year}} قابل استفاده‌اند. 0 یعنی سال خودکار.</p><div class="form-grid"><div class="field"><label>سال نمایشی</label><input type="number" min="0" max="2200" name="ui_display_year" value="<?= (int)($appConfig['ui']['display_year'] ?? 0) ?>"></div><div class="field"><label>بیشترین سال جستجو</label><input type="number" min="0" max="2200" name="ui_search_max_year" value="<?= (int)($appConfig['ui']['search_max_year'] ?? 0) ?>"></div><div class="field full"><label>جایگزینی متن فارسی</label><textarea class="fa" name="ui_text_overrides_fa" rows="9" placeholder="برترین‌های 2026 => فیلم‌های منتخب {{year}}"><?= bm_cc_h(bm_cc_text_override_dump((array)($appConfig['ui']['text_overrides']['fa'] ?? []))) ?></textarea></div><div class="field full"><label>English text overrides</label><textarea name="ui_text_overrides_en" rows="9" dir="ltr" placeholder="Best of 2026 => Picks of {{year}}"><?= bm_cc_h(bm_cc_text_override_dump((array)($appConfig['ui']['text_overrides']['en'] ?? []))) ?></textarea></div></div></div>
<div class="card"><h3>سیاست نسخه‌ها</h3><div class="form-grid"><div class="field"><label class="check"><input type="checkbox" name="policy_enabled" <?= !empty($appConfig['version_policy']['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label class="check"><input type="checkbox" name="force_update_blocked" <?= !empty($appConfig['version_policy']['force_update_blocked'])?'checked':'' ?>> اجبار آپدیت نسخه مسدود</label></div><div class="field"><label>حداقل Version Code</label><input type="number" min="0" name="minimum_version_code" value="<?= (int)($appConfig['version_policy']['minimum_version_code'] ?? 0) ?>"></div><div class="field"><label>حداقل Version Name</label><input type="text" name="minimum_version_name" value="<?= bm_cc_h($appConfig['version_policy']['minimum_version_name'] ?? '') ?>"></div><div class="field"><label>Version Nameهای مسدود</label><textarea name="blocked_version_names"><?= bm_cc_h(implode("\n", (array)($appConfig['version_policy']['blocked_version_names'] ?? []))) ?></textarea></div><div class="field"><label>Version Codeهای مسدود</label><textarea name="blocked_version_codes"><?= bm_cc_h(implode("\n", (array)($appConfig['version_policy']['blocked_version_codes'] ?? []))) ?></textarea></div><div class="field full"><label>پیام مسدودی</label><textarea class="fa" name="block_message"><?= bm_cc_h($appConfig['version_policy']['block_message'] ?? '') ?></textarea></div></div><div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات اپ</button><a class="btn" href="../app_config.php" target="_blank">مشاهده JSON عمومی</a></div></div>
</div></form>
<div class="grid" style="margin-top:16px"><div class="card half"><h3>آپلود نسخه جدید</h3><p class="sub">APK یا ZIP تا ۹۰ مگابایت از اینجا آپلود می‌شود. برای فایل بزرگ‌تر از File Manager هاست و پوشه app استفاده کنید؛ جدیدترین نسخه همچنان خودکار تشخیص داده می‌شود.</p><form method="post" action="admin_control_center" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="upload_release"><div class="form-grid"><div class="field full"><label>نام پیشنهادی، مثل bankmovie-v2.0-20000</label><input type="text" name="release_name"></div><div class="field full"><label>فایل APK یا ZIP</label><input type="file" name="release_file" accept=".apk,.zip" required></div></div><div class="actions"><button class="btn primary" type="submit">آپلود انتشار</button></div></form></div>
<div class="card half"><h3>فایل‌های انتشار</h3><?php if(!$releaseFiles): ?><p class="sub">فایلی در پوشه app نیست.</p><?php else: ?><table class="table"><tr><th>فایل</th><th>حجم</th><th></th></tr><?php foreach($releaseFiles as $file): ?><tr><td class="code"><?= bm_cc_h(basename($file)) ?></td><td><?= number_format(((int)@filesize($file))/1048576,1) ?> MB</td><td><form method="post" action="admin_control_center" onsubmit="return confirm('فایل حذف شود؟')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="delete_release"><input type="hidden" name="release_file_name" value="<?= bm_cc_h(basename($file)) ?>"><button class="btn danger" type="submit">حذف</button></form></td></tr><?php endforeach; ?></table><?php endif; ?></div></div>
</section>

<section class="tab <?= $tab==='archives'?'active':'' ?>">
<?php
$bmArchiveEnabledCount = 0;
foreach (bm_archive_known_ids() as $bmArchiveId) if (!empty($archiveSettings['archives'][$bmArchiveId]['enabled'])) $bmArchiveEnabledCount++;
$bmArchivePublicCount = 0; $bmArchiveAdminCount = 0;
foreach (bm_archive_known_ids() as $bmArchiveId) { (($archiveSettings['archives'][$bmArchiveId]['access_scope'] ?? 'public') === 'admin') ? $bmArchiveAdminCount++ : $bmArchivePublicCount++; }
$bmArchiveOrder = bm_archive_order();
$bmArchivePositions = array_flip($bmArchiveOrder);
$bmArchiveEmergency = bm_archive_emergency_settings();
?>
<div class="card" style="margin:10px 0 16px"><h3>واچ‌لیست سایت و اپ</h3>
 <p class="sub">محدودیت مشترک از تنظیمات مرکزی سایت می‌آید؛ این دکمه به همان بخش BM ADMIN متصل است.</p>
 <a class="btn primary" href="admin.php?admin_section=archiveOverviewSection#bmWatchlistLimitControl">مدیریت سقف واچ‌لیست (۱۰۰ عنوان پیش‌فرض)</a></div>
<div class="bm-sort-shortcut"><a class="btn primary" href="#bmControlArchiveSortable">↕ مرتب‌سازی آرشیوها</a></div>
<form id="archiveSettingsForm" method="post" action="admin_control_center">
<input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_archives">
<div class="grid">
  <div class="card archive-manager-hero">
    <div class="archive-manager-title"><div class="archive-manager-icon">◫</div><div><h2>مرکز مدیریت آرشیوها</h2><p class="sub">وضعیت، نام نمایشی، سطح دسترسی و تک‌تک بخش‌های صفحه اصلی هر آرشیو را از همین‌جا مدیریت کن.</p></div></div>
    <div class="archive-manager-kpis"><span class="archive-kpi">● <?= (int)$bmArchiveEnabledCount ?> آرشیو فعال</span><span class="archive-kpi">🌐 <?= (int)$bmArchivePublicCount ?> عمومی</span><span class="archive-kpi">🛡 <?= (int)$bmArchiveAdminCount ?> فقط مدیر</span><span class="archive-kpi">تغییرات سراسری روی خانه، جستجو و جزئیات</span></div>
  </div>
  <div class="card">
    <h3>پیش‌فرض ریدایرکت دانلود و پوستر</h3>
    <p class="sub">این دو کلید پیش‌فرض سراسری‌اند. ریدایرکت دانلود هر آرشیو را می‌توان پایین همین صفحه مستقل روشن یا خاموش کرد. بستن دانلود و مجوزهای VIP جدا هستند.</p>
    <div class="form-grid">
      <div class="field"><label class="check"><input type="checkbox" name="download_redirect_enabled" value="1" <?= !empty($archiveSettings['download_redirect_enabled'])?'checked':'' ?>> ریدایرکت دانلود فعال باشد</label></div>
      <div class="field"><label class="check"><input type="checkbox" name="poster_redirect_enabled" value="1" <?= !empty($deliveryCfg['poster_redirect_enabled'])?'checked':'' ?>> ریدایرکت پوستر فعال باشد</label></div>
    </div>
    <p class="sub" style="margin-top:9px">تغییرات با دکمه «ذخیره ترتیب و تنظیمات» در همین فرم ذخیره می‌شود.</p>
  </div>
  <div class="card">
    <h3>ترتیب و حالت اضطراری آرشیوها</h3>
    <p class="sub">برای اینترنت ملی، آرشیو نجات را مشخص کن. این حالت تنظیمات عادی آرشیوها را پاک نمی‌کند و بعداً با یک کلیک برمی‌گردد.</p>
    <div class="form-grid">
      <div class="field"><label>آرشیو پیش‌فرض</label><select name="archive_default"><?php foreach($bmArchiveOrder as$aid):?><option value="<?=$aid?>" <?=($archiveSettings['default_archive']??'archive1')===$aid?'selected':''?>><?=bm_cc_h($archiveSettings['archives'][$aid]['label']??$aid)?></option><?php endforeach;?></select></div>
      <div class="field"><label>Fallback</label><select name="archive_fallback"><?php foreach($bmArchiveOrder as$aid):?><option value="<?=$aid?>" <?=($archiveSettings['fallback_archive']??'archive2')===$aid?'selected':''?>><?=bm_cc_h($archiveSettings['archives'][$aid]['label']??$aid)?></option><?php endforeach;?></select></div>
      <div class="field"><label>آرشیو نجات اینترنت ملی</label><select name="archive_emergency_primary"><?php foreach($bmArchiveOrder as$aid): if(in_array($aid,['archive7'],true)) continue; ?><option value="<?=$aid?>" <?=($bmArchiveEmergency['primary_archive']??'archive2')===$aid?'selected':''?>><?=bm_cc_h($archiveSettings['archives'][$aid]['label']??$aid)?></option><?php endforeach;?></select></div>
      <div class="field"><label>بقیه آرشیوها هنگام قطعی</label><select name="archive_emergency_mode"><option value="hide" <?=($bmArchiveEmergency['external_mode']??'hide')==='hide'?'selected':''?>>مخفی + بدون درخواست شبکه</option><option value="visible" <?=($bmArchiveEmergency['external_mode']??'hide')==='visible'?'selected':''?>>نمایش غیرفعال + پیام</option></select></div>
      <div class="field full"><label>پیام حالت قطعی</label><textarea class="fa" name="archive_emergency_message"><?=bm_cc_h($bmArchiveEmergency['message']??'')?></textarea></div>
      <div class="field full"><label class="check"><input type="checkbox" name="archive_emergency_enabled" <?=!empty($bmArchiveEmergency['enabled'])?'checked':''?>> حالت اینترنت ملی فعال باشد</label></div>
      <div class="bm-sort-area" style="grid-column:1/-1">
        <b>چیدمان آرشیوها — با کشیدن ردیف، فلش‌ها یا جایگاه</b><p>برای کشیدن از دستهٔ ⠿ استفاده کن؛ جایگاه و فلش‌ها هم فعال‌اند. دکمهٔ ذخیره درست زیر همین لیست است.</p>
        <div class="bm-sort-archives" id="bmControlArchiveSortable" aria-label="چیدمان آرشیوها">
        <?php foreach($bmArchiveOrder as $aid): $bmSortPos=(int)($bmArchivePositions[$aid]??0)+1; ?>
          <div class="bm-sort-row" data-archive-id="<?=bm_cc_h($aid)?>">
            <span class="bm-sort-handle" title="برای جابه‌جایی بکش؛ با کلیدهای جهت‌دار هم می‌شود" role="button" tabindex="0">⠿</span>
            <strong><?=bm_cc_h($archiveSettings['archives'][$aid]['label']??$aid)?></strong><small><?=bm_cc_h($aid)?></small>
            <label class="bm-sort-pos">جایگاه <select name="archive_position[<?=bm_cc_h($aid)?>]" aria-label="جایگاه <?=bm_cc_h($aid)?>"><?php for($p=1;$p<=7;$p++): ?><option value="<?=$p?>" <?=$bmSortPos===$p?'selected':''?>><?=$p?></option><?php endfor; ?></select></label>
            <button class="bm-sort-step" type="button" data-move="up" aria-label="بالا بردن <?=bm_cc_h($aid)?>">↑</button>
            <button class="bm-sort-step" type="button" data-move="down" aria-label="پایین بردن <?=bm_cc_h($aid)?>">↓</button>
            <input type="hidden" name="archive_order[]" value="<?=bm_cc_h($aid)?>" disabled>
          </div>
        <?php endforeach; ?>
        </div>
        <div class="bm-sort-actions">
          <span class="bm-sort-status" aria-live="polite">ترتیب فعلی؛ برای تغییر، دستهٔ ⠿ را بکش.</span>
          <button class="bm-sort-reset" type="button" data-sort-reset disabled>بازگرداندن چیدمان قبلی</button>
          <button class="btn primary bm-sort-save" type="submit">ذخیره ترتیب و تنظیمات</button>
        </div>
      </div>
    </div>
    <div class="actions" style="margin-top:12px">
      <button class="btn" type="submit" name="archive_quick_action" value="archive_emergency_on" onclick="return confirm('حالت اینترنت ملی فعال شود؟')">فعال‌سازی فوری اینترنت ملی</button>
      <button class="btn" type="submit" name="archive_quick_action" value="archive_emergency_off" onclick="return confirm('به حالت عادی برگردد؟')">بازگشت فوری عادی</button>
    </div>
  </div>
<?php $bmCcArchiveStatus=[]; foreach (bm_ad_archive_dashboard_data() as $bmStatusRow) $bmCcArchiveStatus[$bmStatusRow['id']]=$bmStatusRow; ?>
<?php foreach($bmArchiveOrder as $id): $row=$archiveSettings['archives'][$id]; $num=str_replace('archive','',$id); $scope=(string)($row['access_scope'] ?? 'public'); ?>
  <div class="card half archive-card">
    <?php $bmHealth=function_exists('bm_archive_health_state')?bm_archive_health_state($id):[]; $bmCircuit=max(0,(int)($bmHealth['circuit_until']??0)-time()); ?>
<div class="archive-card-top"><div class="archive-card-name"><div class="archive-num"><?= bm_cc_h($num) ?></div><div><h3><?= bm_cc_h($row['label']) ?></h3><small><?= $id==='archive4'?'قالب و جستجو مشابه آرشیو ۳':'منبع محتوای BankMovie' ?></small></div></div><span class="archive-state <?= !empty($row['enabled'])?'on':'off' ?>"><?= !empty($row['enabled'])?'فعال':'غیرفعال' ?></span></div><?php if($id!=='archive2'): ?><div class="sub" style="margin:-8px 0 12px">Circuit: <span class="badge <?= $bmCircuit>0?'off':'on' ?>"><?= $bmCircuit>0 ? ('استراحت '.$bmCircuit.' ثانیه') : 'آماده' ?></span><?php if(!empty($bmHealth['last_error'])): ?> · <?= bm_cc_h($bmHealth['last_error']) ?><?php endif; ?></div><?php endif; ?>
    <?php $bmCcStatus=$bmCcArchiveStatus[$id]??[]; $bmCcAuth=$bmCcStatus['auth']??[]; ?>
    <div class="archive-connect-card" style="padding:12px;margin:0 0 12px">
      <b>وضعیت ورود: <?=bm_cc_h($bmCcAuth['mode_label']??'نامشخص')?></b>
      <div class="sub">نشست: <?=bm_cc_h($bmCcAuth['label']??'نامشخص')?> · <?=bm_cc_h($bmCcAuth['note']??'')?></div>
      <?php if(!empty($bmCcStatus['renew_url'])): ?><a class="btn" style="margin-top:8px" href="<?=bm_cc_h($bmCcStatus['renew_url'])?>">مدیریت ورود و تمدید نشست</a><?php endif; ?>
    </div>
    <div class="archive-toggle-box"><div><b>وضعیت آرشیو</b><div class="sub" style="margin:3px 0 0">خاموش‌کردن، دریافت محتوا را متوقف می‌کند.</div></div><label class="check"><input type="checkbox" name="archive_enabled[<?= $id ?>]" <?= !empty($row['enabled'])?'checked':'' ?>> فعال</label></div>
    <div class="form-grid"><div class="field"><label>نام نمایشی</label><input type="text" name="archive_label[<?= $id ?>]" value="<?= bm_cc_h($row['label']) ?>"></div><div class="field"><label>وقتی غیرفعال است</label><select name="archive_mode[<?= $id ?>]"><option value="visible" <?= $row['disabled_mode']==='visible'?'selected':'' ?>>تب بماند + پیام</option><option value="hide" <?= $row['disabled_mode']==='hide'?'selected':'' ?>>کاملاً مخفی شود</option></select></div><div class="field full"><label>پیام غیرفعال‌بودن</label><textarea class="fa" name="archive_message[<?= $id ?>]"><?= bm_cc_h($row['disabled_message']) ?></textarea></div></div>
    <div class="form-grid" style="margin:10px 0 14px"><div class="field full"><label>نوع لینک دانلود این آرشیو</label><select name="archive_download_link_mode[<?= bm_cc_h($id) ?>]" <?= $id==='archive5'?'disabled':'' ?>><?php $dlMode=(string)($row['download_link_mode']??($id==='archive5'?'original':'redirect')); foreach(['redirect'=>'ریدایرکت بانک‌مووی','original'=>'لینک اصلی','disabled'=>'دانلود غیرفعال'] as $v=>$l): ?><option value="<?=bm_cc_h($v)?>" <?=$dlMode===$v?'selected':''?>><?=bm_cc_h($l)?></option><?php endforeach;?></select><?php if($id==='archive5'):?><small>آرشیو ۵ در حالت لینک اصلی ثابت است.</small><?php endif;?></div></div>
    <div class="form-grid" style="margin:0 0 12px">
      <div class="field full"><label>ریدایرکت دانلود آرشیو <?= bm_cc_h($num) ?> — مستقل</label>
        <?php if ($id === 'archive5'): ?>
          <div class="sub">آرشیو ۵ همیشه از لینک اصلی استفاده می‌کند.</div>
        <?php else: ?>
          <?php $dlPolicy=(string)($row['download_redirect_policy']??'inherit'); ?>
          <select name="archive_download_redirect_policy[<?= bm_cc_h($id) ?>]">
            <?php foreach(['inherit'=>'طبق تنظیم عمومی','on'=>'روشن (مستقل)','off'=>'خاموش (لینک اصلی)'] as $v=>$l): ?>
              <option value="<?= bm_cc_h($v) ?>" <?= $dlPolicy===$v?'selected':'' ?>><?= bm_cc_h($l) ?></option>
            <?php endforeach; ?>
          </select>
          <small class="sub">نوع لینک دانلود و دسترسی VIP همچنان اولویت دارند.</small>
        <?php endif; ?>
      </div>
    </div>
    <div class="form-grid" style="margin:12px 0">
      <?php foreach (['download'=>'دانلود', 'stream'=>'پخش آنلاین'] as $bmAccessFeature=>$bmAccessTitle): $bmAccessKey=$bmAccessFeature.'_access_scope'; $bmAccessCurrent=(string)($row[$bmAccessKey]??'public'); ?>
      <div class="field"><label>سطح دسترسی <?=bm_cc_h($bmAccessTitle)?> آرشیو <?=bm_cc_h($num)?></label><select name="archive_<?=bm_cc_h($bmAccessFeature)?>_scope[<?=bm_cc_h($id)?>]">
      <?php foreach(['public'=>'عمومی','member'=>'اعضا','vip'=>'VIP','admin'=>'مدیر','disabled'=>'خاموش'] as $bmValue=>$bmLabel):?><option value="<?=bm_cc_h($bmValue)?>" <?=$bmAccessCurrent===$bmValue?'selected':''?>><?=bm_cc_h($bmLabel)?></option><?php endforeach;?></select></div>
      <?php endforeach; ?>
    </div>
    <div class="archive-audience"><div class="archive-audience-label">سطح نمایش آرشیو <?= bm_cc_h($num) ?></div><div class="archive-segments"><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="public" <?= $scope==='public'?'checked':'' ?>><span>🌐 عموم</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="member" <?= $scope==='member'?'checked':'' ?>><span>👤 اعضا</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="vip" <?= $scope==='vip'?'checked':'' ?>><span>👑 VIP</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="admin" <?= $scope==='admin'?'checked':'' ?>><span>🛡 مدیر</span></label></div></div>
    <?php
      $bmPlayerGates = is_array($row['player_gates'] ?? null) ? $row['player_gates'] : [];
      $bmGateOptions = ['inherit'=>'طبق قفل عمومی','free'=>'رایگان در این آرشیو','vip'=>'فقط VIP در این آرشیو'];
      $bmGateRows = [
        'master'=>'قفل مادر پخش',
        'internal'=>'پلیر داخلی',
        'external'=>'پلیرهای خارجی',
        'copy_link'=>'کپی لینک مستقیم',
      ];
    ?>
    <details class="archive-section-manager" open>
      <summary><span>قفل‌های پلیر آرشیو <?= bm_cc_h($num) ?></span><small>مستقل</small></summary>
      <div class="archive-section-help">برای هر آرشیو جدا تعیین کن قفل مادر، پلیر داخلی، پلیرهای خارجی و کپی لینک از تنظیم عمومی پیروی کنند، رایگان باشند یا فقط VIP.</div>
      <div class="form-grid" style="margin-top:10px">
      <?php foreach($bmGateRows as$gk=>$gl): $gm=(string)($bmPlayerGates[$gk]??'inherit'); ?>
        <div class="field"><label><?=bm_cc_h($gl)?></label><select name="archive_player_gate[<?=bm_cc_h($id)?>][<?=bm_cc_h($gk)?>]"><?php foreach($bmGateOptions as$ok=>$ol):?><option value="<?=bm_cc_h($ok)?>" <?=$gm===$ok?'selected':''?>><?=bm_cc_h($ol)?></option><?php endforeach;?></select></div>
      <?php endforeach; ?>
      </div>
      <div class="sub" style="margin-top:8px">رایگان‌کردن قفل پلیر، سطح دسترسی خود آرشیو یا محدودیت پخش آنلاین را دور نمی‌زند.</div>
    </details>
    <?php $bmSectionCatalog = function_exists('bm_archive_section_catalog_defaults') ? bm_archive_section_catalog_defaults($id) : []; ?>
    <details class="archive-section-manager" open>
      <summary><span>کنترل بخش‌های آرشیو <?= bm_cc_h($num) ?></span><small><?= count($bmSectionCatalog) ?> بخش</small></summary>
      <div class="archive-section-help">هر بخش را مستقل روشن/خاموش کن و اسمش را عوض کن. خالی گذاشتن عنوان یعنی استفاده از نام فعلی/پیش‌فرض سایت.</div>
      <div class="archive-section-list">
      <?php foreach($bmSectionCatalog as $bmSectionKey=>$bmSectionDef):
          $bmSectionRow = is_array($row['sections'][$bmSectionKey] ?? null) ? $row['sections'][$bmSectionKey] : ['enabled'=>true,'label'=>''];
          $bmSectionEnabled = !array_key_exists('enabled',$bmSectionRow) || !empty($bmSectionRow['enabled']);
          $bmSectionCustomLabel = trim((string)($bmSectionRow['label'] ?? ''));
      ?>
        <div class="archive-section-row">
          <label class="archive-section-switch"><input type="checkbox" name="archive_section_enabled[<?= bm_cc_h($id) ?>][<?= bm_cc_h($bmSectionKey) ?>]" <?= $bmSectionEnabled?'checked':'' ?>><span><?= $bmSectionEnabled?'فعال':'خاموش' ?></span></label>
          <div class="archive-section-copy"><b><?= bm_cc_h($bmSectionDef['label'] ?? $bmSectionKey) ?></b><code><?= bm_cc_h($bmSectionKey) ?></code></div>
          <input class="archive-section-title-input" type="text" name="archive_section_label[<?= bm_cc_h($id) ?>][<?= bm_cc_h($bmSectionKey) ?>]" value="<?= bm_cc_h($bmSectionCustomLabel) ?>" placeholder="<?= bm_cc_h($bmSectionDef['label'] ?? $bmSectionKey) ?>">
        </div>
      <?php endforeach; ?>
      </div>
    </details>
  </div>
<?php endforeach; ?>
</div>
<div class="archive-savebar"><p class="sub">تغییرات بخش‌ها فقط روی همان آرشیو اعمال می‌شوند؛ خاموش‌کردن یک بخش جلوی درخواست شبکه همان لیست را هم می‌گیرد.</p><button class="btn primary" type="submit">ذخیره تنظیمات آرشیوها</button></div>
</form>
<div class="archive-connect-grid" style="margin-top:18px"><div class="archive-connect-card"><h3>اتصال آرشیو ۳</h3><span class="archive-connect-status">● API6 آماده</span><p class="sub">بدون Cookie، همراه کش داخلی و مدیریت خطا.</p><div class="actions"><a class="btn primary" href="../api6.php?ping=1" target="_blank">تست API6</a></div></div><div class="archive-connect-card"><h3>اتصال آرشیو ۴</h3><span class="archive-connect-status">● API4 آماده</span><p class="sub">بدون Cookie؛ ساختار صفحه، جستجو و جزئیات همان جریان آرشیو ۳ است.</p><div class="actions"><a class="btn primary" href="../api4.php?ping=1" target="_blank">تست API4</a></div></div></div>
<div class="card" style="margin-top:16px"><h3>کش آرشیوها</h3><p class="sub">اگر محتوای تازه نمایش داده نشد، کش لیست‌ها را پاک کن. تنظیمات آرشیوها حذف نمی‌شوند.</p><form method="post" action="admin_control_center" onsubmit="return confirm('کش آرشیوها پاک شود؟')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="clear_archive_cache"><button class="btn danger" type="submit">پاک‌کردن کش آرشیو</button></form></div>
</section>

<section class="tab <?= $tab==='security'?'active':'' ?>">
<?php
$rateCfg = (array)($rateReport['settings'] ?? []);
$rateEnabled = !empty($rateCfg['enabled']);
$rateWhitelist = implode("\n", (array)($rateCfg['whitelist'] ?? []));
$rateBlacklist = implode("\n", (array)($rateCfg['blacklist'] ?? []));
$currentAdminIp = function_exists('bm_security_client_ip') ? bm_security_client_ip() : '';
?>
<div class="grid">
  <div class="card">
    <div style="display:flex;justify-content:space-between;gap:16px;align-items:flex-start;flex-wrap:wrap">
      <div>
        <h2>مرکز امنیت Anti‑503 / Anti‑Spam</h2>
        <p class="sub">لایه امنیتی قبل از دیتابیس و PHP Session اجرا می‌شود. فقط Page Viewهای واقعی شمارش می‌شوند؛ اما اگر IP/Visitor/Session/User وارد Block شود، تمام PHPهای سایت—including API/AJAX—تا پایان محدودیت یا حل CAPTCHA با 429 متوقف می‌شوند.</p>
      </div>
      <span class="badge <?= $rateEnabled?'on':'off' ?>"><?= $rateEnabled?'● سیستم امنیتی فعال':'● سیستم امنیتی خاموش' ?></span>
    </div>
    <div class="rate-kpis">
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['today_violations'] ?? 0) ?></b><small>حمله / عبور از سقف امروز</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['today_attack_ips'] ?? 0) ?></b><small>IP مهاجم امروز</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['today_blocked_hits'] ?? 0) ?></b><small>درخواست دفع‌شده امروز</small></div>
      <div class="rate-kpi"><b class="rate-live"><?= (int)($rateReport['stats']['active'] ?? 0) ?></b><small>مسدودی فعال</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['total_attacks'] ?? 0) ?></b><small>کل حمله‌های ثبت‌شده</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['captcha_success'] ?? 0) ?></b><small>رفع بلاک با CAPTCHA امروز</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['captcha_failed'] ?? 0) ?></b><small>CAPTCHA ناموفق امروز</small></div>
      <div class="rate-kpi"><b><?= (int)($rateReport['stats']['recent_ips'] ?? 0) ?></b><small>IP دیده‌شده ۲۴ ساعت</small></div>
    </div>
  </div>

  <div class="card">
    <h3>تنظیمات کامل محافظ</h3>
    <p class="sub">تغییرات بلافاصله روی درخواست بعدی اعمال می‌شوند. IP یا CIDR مثل <span class="code">1.2.3.4</span> و <span class="code">1.2.3.0/24</span> قابل استفاده است.</p>
    <form method="post" action="admin_control_center">
      <input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>">
      <input type="hidden" name="action" value="rate_save_settings">
      <div class="form-grid">
        <div class="field full"><label class="check"><input type="checkbox" name="rate_enabled" <?= $rateEnabled?'checked':'' ?>> روشن بودن کل سیستم Anti‑503 / Anti‑Spam</label></div>
        <div class="field third"><label>حداکثر درخواست</label><input type="number" min="1" max="5000" name="rate_limit" value="<?= (int)($rateCfg['limit'] ?? 20) ?>"></div>
        <div class="field third"><label>بازه زمانی (ثانیه)</label><input type="number" min="10" max="3600" name="rate_window" value="<?= (int)($rateCfg['window'] ?? 60) ?>"></div>
        <div class="field third"><label>مدت بلاک (ثانیه)</label><input type="number" min="60" max="86400" name="rate_penalty" value="<?= (int)($rateCfg['penalty'] ?? 300) ?>"></div>

        <div class="field full"><label class="check"><input type="checkbox" checked disabled> فقط صفحات واقعی کاربر محافظت می‌شوند <b>(قفل ایمنی)</b></label><div class="sub">Home، Movie، Collection، ورود، ثبت‌نام، Profile، Browse و Search پیشرفته شمارش می‌شوند. API/AJAX/Player و درخواست‌های پس‌زمینه به‌صورت اجباری بیرون از این سهمیه‌اند و این مرز از پنل قابل خراب‌شدن نیست.</div></div>
        <div class="field full"><label class="check"><input type="checkbox" checked disabled> Live Search همیشه آزاد است <span class="code">(ajax.php?action=search)</span></label><div class="sub">Search پیشرفته <span class="code">search.php</span> همچنان یک صفحه محافظت‌شده است.</div></div>
        <div class="field full"><label class="check"><input type="checkbox" checked disabled> API / AJAX از شمارش Page View آزادند</label><div class="sub">این endpointها شمارنده صفحه را مصرف نمی‌کنند؛ اما اگر IP/Session/User قبلاً Block شده باشد، Global Block قبل از API اجرا شده و پاسخ 429 می‌دهد.</div></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_privileged_bypass" <?= !array_key_exists('privileged_bypass',$rateCfg) || !empty($rateCfg['privileged_bypass'])?'checked':'' ?>> Admin/Staff و VIP فعال از محدودیت خودکار معاف باشند</label><div class="sub">استثناء با Cookie امضاشده و وابسته به Session انجام می‌شود. Blacklist دستی همچنان اولویت بالاتر دارد.</div></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_challenge_enabled" <?= !array_key_exists('challenge_enabled',$rateCfg) || !empty($rateCfg['challenge_enabled'])?'checked':'' ?>> امکان رفع بلاک با CAPTCHA فعال باشد</label><div class="sub">CAPTCHA پنج‌رقمی، یک‌بارمصرف، وابسته به IP، زمان‌دار، همراه Honeypot و حداقل زمان حل است.</div></div>
        <div class="field third"><label>اعتبار CAPTCHA (ثانیه)</label><input type="number" min="60" max="900" name="rate_challenge_ttl" value="<?= (int)($rateCfg['challenge_ttl'] ?? 300) ?>"></div>
        <div class="field third"><label>حداقل زمان حل (ms)</label><input type="number" min="700" max="10000" name="rate_challenge_min_age_ms" value="<?= (int)($rateCfg['challenge_min_age_ms'] ?? 1200) ?>"></div>
        <div class="field third"><label>نوع Challenge</label><input type="text" value="تصویر ۵ رقمی یک‌بارمصرف" disabled></div>
        <div class="field third"><label>خطای CAPTCHA تا تشدید</label><input type="number" min="1" max="10" name="rate_captcha_attempts" value="<?= (int)($rateCfg['captcha_attempts'] ?? 3) ?>"></div>
        <div class="field third"><label>Human Pass بعد حل (ثانیه)</label><input type="number" min="60" max="3600" name="rate_captcha_pass_ttl" value="<?= (int)($rateCfg['captcha_pass_ttl'] ?? 600) ?>"></div>
        <div class="field third"><label>Visitor Limit</label><input type="number" min="1" max="5000" name="rate_visitor_limit" value="<?= (int)($rateCfg['visitor_limit'] ?? 24) ?>"></div>
        <div class="field third"><label>Session Limit</label><input type="number" min="1" max="5000" name="rate_session_limit" value="<?= (int)($rateCfg['session_limit'] ?? 30) ?>"></div>
        <div class="field third"><label>User Limit</label><input type="number" min="1" max="5000" name="rate_user_limit" value="<?= (int)($rateCfg['user_limit'] ?? 36) ?>"></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_escalation_enabled" <?= !array_key_exists('escalation_enabled',$rateCfg) || !empty($rateCfg['escalation_enabled'])?'checked':'' ?>> Escalation فعال باشد؛ تخلف تکراری زمان Block را بیشتر کند</label></div>
        <div class="field third"><label>بازه Escalation (ثانیه)</label><input type="number" min="300" max="86400" name="rate_escalation_duration" value="<?= (int)($rateCfg['escalation_duration'] ?? 3600) ?>"></div>
        <div class="field third"><label>ضریب Escalation</label><input type="number" min="2" max="10" name="rate_escalation_multiplier" value="<?= (int)($rateCfg['escalation_multiplier'] ?? 3) ?>"></div>
        <div class="field third"><label>حداکثر Block (ثانیه)</label><input type="number" min="60" max="86400" name="rate_escalation_max_penalty" value="<?= (int)($rateCfg['escalation_max_penalty'] ?? 3600) ?>"></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_endpoint_global_block" <?= !array_key_exists('endpoint_global_block',$rateCfg) || !empty($rateCfg['endpoint_global_block'])?'checked':'' ?>> عبور از Rate Limit اختصاصی Login/Register/API/Comments باعث Global Block شود</label></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_app_bypass" <?= !empty($rateCfg['app_bypass'])?'checked':'' ?>> اپلیکیشن معتبرِ دارای امضای HMAC از Rate Limit آزاد باشد</label></div>
        <div class="field full"><label class="check"><input type="checkbox" name="rate_log_enabled" <?= !empty($rateCfg['log_enabled'])?'checked':'' ?>> ثبت لاگ رویدادهای امنیتی فعال باشد</label></div>

        <div class="field"><label>Whitelist — همیشه آزاد</label><textarea name="rate_whitelist" placeholder="هر IP یا CIDR یک خط"><?= bm_cc_h($rateWhitelist) ?></textarea><div class="sub">IP فعلی مدیر: <span class="code"><?= bm_cc_h($currentAdminIp) ?></span></div></div>
        <div class="field"><label>Blacklist — مسدودی دائم</label><textarea name="rate_blacklist" placeholder="هر IP یا CIDR یک خط"><?= bm_cc_h($rateBlacklist) ?></textarea><div class="sub">Whitelist بر Blacklist اولویت دارد تا مدیر اشتباهی قفل نشود.</div></div>
      </div>
      <div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات امنیتی</button></div>
    </form>
  </div>

  <div class="card half">
    <h3>مسدودسازی دستی IP</h3>
    <p class="sub">برای IP مشکوک، بدون تغییر Blacklist یک بلاک موقت ایجاد کن.</p>
    <form method="post" action="admin_control_center">
      <input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>">
      <input type="hidden" name="action" value="rate_manual_block">
      <div class="form-grid">
        <div class="field"><label>IP</label><input class="code" type="text" name="rate_ip" required placeholder="1.2.3.4"></div>
        <div class="field"><label>مدت (دقیقه)</label><input type="number" min="1" max="1440" name="rate_minutes" value="5"></div>
        <div class="field full"><label>یادداشت</label><input type="text" name="rate_note" maxlength="250" placeholder="مثلاً crawler مشکوک"></div>
      </div>
      <div class="actions"><button class="btn danger" type="submit">مسدود کن</button></div>
    </form>
  </div>

  <div class="card half">
    <h3>رفتار فعلی سیستم</h3>
    <table class="table">
      <tr><th>نوع شمارش</th><td><span class="badge on">فقط صفحات واقعی کاربر</span></td></tr>
      <tr><th>Live Search</th><td><span class="badge on">همیشه آزاد / بدون شمارش</span></td></tr>
      <tr><th>API / AJAX</th><td><span class="badge on">بدون شمارش؛ در Global Block مسدود</span></td></tr>
      <tr><th>Advanced Search</th><td><span class="badge on">محافظت‌شده</span></td></tr>
      <tr><th>CAPTCHA رفع بلاک</th><td><span class="badge <?= (!array_key_exists('challenge_enabled',$rateCfg)||!empty($rateCfg['challenge_enabled']))?'on':'off' ?>"><?= (!array_key_exists('challenge_enabled',$rateCfg)||!empty($rateCfg['challenge_enabled']))?'فعال':'خاموش' ?></span></td></tr>
      <tr><th>اپ معتبر</th><td><span class="badge <?= !empty($rateCfg['app_bypass'])?'on':'off' ?>"><?= !empty($rateCfg['app_bypass'])?'آزاد':'مشمول محدودیت' ?></span></td></tr>
      <tr><th>Session Policy</th><td><span class="badge on">حداکثر ۵ نشست فعال برای هر اکانت</span></td></tr>
      <tr><th>Rate Layers</th><td>IP + قوی‌ترین هویت (User / Session / Visitor)</td></tr>
      <tr><th>سقف</th><td><?= (int)($rateCfg['limit'] ?? 20) ?> درخواست / <?= (int)($rateCfg['window'] ?? 60) ?> ثانیه</td></tr>
      <tr><th>جریمه</th><td><?= (int)ceil(((int)($rateCfg['penalty'] ?? 300))/60) ?> دقیقه</td></tr>
      <tr><th>ثبت لاگ</th><td><?= !empty($rateCfg['log_enabled'])?'روشن':'خاموش' ?></td></tr>
    </table>
  </div>

  <div class="card">
    <h3>مسدودی‌های فعال</h3>
    <p class="sub">IP، زمان باقی‌مانده، تعداد درخواست‌های دفع‌شده و آخرین مسیر. مسدودی دائم از بخش Blacklist مدیریت می‌شود.</p>
    <div class="rate-table-wrap"><table class="table"><tr><th>IP</th><th>باقیمانده</th><th>Count</th><th>Blocked hits</th><th>آخرین مسیر</th><th>یادداشت</th><th>آخرین مشاهده</th><th></th></tr>
    <?php if (empty($rateReport['active'])): ?><tr><td colspan="8"><span class="badge on">فعلاً IP مسدودی فعال نیست</span></td></tr><?php else: foreach ($rateReport['active'] as $row): $remain=max(0,(int)($row['blocked_until']??0)-time()); ?>
      <tr>
        <td class="code"><?= bm_cc_h($row['ip']??'') ?></td>
        <td><span class="badge off"><?= (int)$remain ?>s</span></td>
        <td><?= (int)($row['count']??0) ?></td>
        <td><?= (int)($row['blocked_hits']??0) ?></td>
        <td class="rate-uri" title="<?= bm_cc_h($row['last_uri']??'') ?>"><?= bm_cc_h($row['last_uri']??'') ?></td>
        <td><?= bm_cc_h($row['manual_note']??'') ?></td>
        <td><?= !empty($row['last_seen'])?date('Y-m-d H:i:s',(int)$row['last_seen']):'-' ?></td>
        <td><form method="post" action="admin_control_center" onsubmit="return confirm('رفع مسدودی این IP؟')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="rate_unblock"><input type="hidden" name="rate_ip" value="<?= bm_cc_h($row['ip']??'') ?>"><button class="btn good" type="submit">رفع مسدودی</button></form></td>
      </tr>
    <?php endforeach; endif; ?></table></div>
  </div>

  <div class="card half">
    <h3>IPهای پرتکرار امروز</h3>
    <div class="rate-table-wrap"><table class="table"><tr><th>IP</th><th>حمله</th><th>دفع‌شده</th><th>آخرین مسیر</th></tr>
    <?php if (empty($rateReport['top_ips'])): ?><tr><td colspan="4">داده‌ای ثبت نشده.</td></tr><?php else: foreach ((array)$rateReport['top_ips'] as $row): ?>
      <tr><td class="code"><?= bm_cc_h($row['ip']??'') ?></td><td><?= (int)($row['violations_today']??0) ?></td><td><?= (int)($row['blocked_hits_today']??0) ?></td><td class="rate-uri"><?= bm_cc_h($row['last_uri']??'') ?></td></tr>
    <?php endforeach; endif; ?></table></div>
  </div>

  <div class="card half">
    <h3>مسیرهای هدف امروز</h3>
    <div class="rate-table-wrap"><table class="table"><tr><th>مسیر</th><th>درخواست دفع‌شده</th></tr>
    <?php if (empty($rateReport['top_targets'])): ?><tr><td colspan="2">داده‌ای ثبت نشده.</td></tr><?php else: foreach ((array)$rateReport['top_targets'] as $target=>$count): ?>
      <tr><td class="code"><?= bm_cc_h($target) ?></td><td><?= (int)$count ?></td></tr>
    <?php endforeach; endif; ?></table></div>
  </div>

  <div class="card">
    <h3>آخرین رویدادهای امنیتی</h3>
    <div class="actions">
      <form method="post" action="admin_control_center"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="rate_prune"><button class="btn" type="submit">پاکسازی رکوردهای قدیمی</button></form>
      <form method="post" action="admin_control_center" onsubmit="return confirm('لاگ رویدادها پاک شود؟ آمار تجمیعی حمله‌ها حفظ می‌شود.')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="rate_clear_events"><button class="btn danger" type="submit">پاک کردن Event Log</button></form>
      <form method="post" action="admin_control_center" onsubmit="return confirm('همه مسدودی‌های موقت و شمارنده‌های فعلی صفر شوند؟ Blacklist و تنظیمات حذف نمی‌شوند.')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="rate_reset_counters"><button class="btn danger" type="submit">ریست شمارنده‌ها و بلاک‌های موقت</button></form>
    </div>
    <div class="rate-table-wrap" style="margin-top:14px"><table class="table"><tr><th>زمان</th><th>رویداد</th><th>IP</th><th>User ID</th><th>Count</th><th>مسیر</th><th>User-Agent</th></tr>
    <?php if (empty($rateReport['events'])): ?><tr><td colspan="7">لاگی ثبت نشده است.</td></tr><?php else: foreach(array_slice((array)$rateReport['events'],0,160) as $ev): ?>
      <tr><td class="code"><?= bm_cc_h($ev['time']??'') ?></td><td><?= bm_cc_h($ev['event']??'') ?></td><td class="code"><?= bm_cc_h($ev['ip']??'') ?></td><td><?= (int)($ev['user_id']??0) ?: '-' ?></td><td><?= (int)($ev['count']??0) ?></td><td class="rate-uri" title="<?= bm_cc_h($ev['uri']??'') ?>"><?= bm_cc_h($ev['uri']??'') ?></td><td class="rate-uri" title="<?= bm_cc_h($ev['ua']??'') ?>"><?= bm_cc_h($ev['ua']??'') ?></td></tr>
    <?php endforeach; endif; ?></table></div>
  </div>
</div>
</section>

<section class="tab <?= $tab==='tools'?'active':'' ?>"><div class="grid"><div class="card"><h2>تمام بخش‌های مدیریتی</h2><p class="sub">بخش‌های تخصصی موجود پروژه از اینجا در دسترس‌اند.</p><div class="tool-grid">
<?php $tools=[
['/_lider/admin.php?admin_section=explorerSettingsSection#explorerSettingsSection','Explorer Settings','منابع چی‌ببین و DornaTV، حالت ترکیبی و کش مشترک Explorer'],
['admin_hub.php','مرکز مدیریت','داشبورد مرتب و دسته‌بندی‌شده برای تمام ابزارهای مدیریتی'],
['admin_ops_center.php','Ops Center — ۱۰ ابزار','سلامت آرشیوها، Import امن، Integrity، Rollback، Error Log، Home، Cache، Backup و کنترل سایت/Android'],
['admin.php','مدیریت اصلی','فیلم، سریال، کاربران، نظرات، استوری، درخواست، بنر داخلی و بکاپ'],
['admin_import_pro.php','Import Pro','ورود حرفه‌ای محتوا از منابع پشتیبانی‌شده'],
['admin_import_history.php','صف و تاریخچه Import','صف، Retry، وضعیت Adapter و خطاهای Import'],
['admin_content_updates.php','مرکز بروزرسانی محتوا','قسمت، فصل، کیفیت، دوبله، زیرنویس و پایان انتشار'],
['admin_media_manager.php','Media Manager','کاور، لوگو، بنر، WebP و فایل‌های بدون استفاده'],
['admin_feature_flags.php','Feature Flags','روشن و خاموش‌کردن قابلیت‌ها و گیت‌های دسترسی'],
['admin_paths.php','مسیرها و دانلود','Source، ساب‌دامین دانلود، Gateway و Route Map'],
['admin_stickers.php','مدیریت استیکر و گیف','پک‌ها، مسیر پوشه، WEBM/WEBP/GIF، آپلود و حذف فایل'],
['admin_site_manager.php','مدیریت ظاهر و محتوا','هدر، فوتر، متن‌ها، صفحه اصلی، جستجو، پلیر، اپ و PWA'],
['admin_custom_css.php','CSS سفارشی','ویرایش CSS کل سایت مثل Additional CSS وردپرس'],
['admin_vip_manager.php','مدیریت فروش VIP','پلن‌ها، قیمت‌ها، امکانات، محدودیت‌ها و تاریخچه قیمت'],
['admin_slider.php','اسلایدر','مدیریت کامل اسلایدهای صفحه اصلی'],
['admin_collections.php','کالکشن‌ها','ساخت و ویرایش کالکشن‌ها'],
['api_manager.php','مدیریت API','منابع آرشیو و APIهای پروژه'],
['admin_sitemap.php','سایت‌مپ','ساخت و بررسی sitemap دامنه bankmovie.top'],
['admin_health.php','عیب‌یابی پنل','دیتابیس، Permission، پوشه‌ها و افزونه PHP'],
['donyaye_series_crawler.php','خزنده سریال','بررسی و واردکردن سریال‌های منبع'],
['donyaye_json_importer.php','ایمپورت JSON','واردکردن خروجی خزنده به دیتابیس'],
['map.php','نقشه سایت HTML','نمایش نقشه عمومی سایت'],
['app_config.php','خروجی تنظیمات اپ','JSON تنظیمات فعال اپ']
]; foreach($tools as $t): ?><a class="tool" href="<?= bm_cc_h($t[0]) ?>"><b><?= bm_cc_h($t[1]) ?></b><span><?= bm_cc_h($t[2]) ?></span></a><?php endforeach; ?>
</div></div><div class="card"><h3>وضعیت مسیرهای مهم</h3><table class="table"><tr><th>مسیر</th><th>وضعیت</th><th>قابل نوشتن</th></tr><?php foreach($dirs as $label=>$path): ?><tr><td><?= bm_cc_h($label) ?><div class="code"><?= bm_cc_h($path) ?></div></td><td><span class="badge <?= is_dir($path)?'on':'off' ?>"><?= is_dir($path)?'موجود':'ناموجود' ?></span></td><td><?= is_dir($path)&&is_writable($path)?'بله':'خیر' ?></td></tr><?php endforeach; ?></table></div></div></section>
</main></div>
<script src="/assets/js/bm-archive-sort-manager-v1.js?v=20261020-v2" defer></script>
</body></html>
