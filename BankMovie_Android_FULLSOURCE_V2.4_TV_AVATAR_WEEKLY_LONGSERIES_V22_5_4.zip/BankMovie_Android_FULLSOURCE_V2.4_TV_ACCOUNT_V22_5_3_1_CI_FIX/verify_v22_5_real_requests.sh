#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
cp server-required/v2/api/bm_security.php "$T/bm_security.php"
mkdir "$T/.private"
cat > "$T/verify.php" <<'PHP'
<?php
error_reporting(E_ALL);
require __DIR__.'/bm_security.php';
$_SERVER['HTTPS']='on';
$_SERVER['REMOTE_ADDR']='192.0.2.15';
function quota_key(string $endpoint, array $get=[], array $post=[], string $method='GET'): ?string {
    $_SERVER['REQUEST_METHOD']=$method;
    $_GET=$get;
    $_POST=$post;
    return bm22_billable_request_key($endpoint);
}
function yes(string $endpoint, array $q, string $method='GET', array $post=[]): string {
    $k=quota_key($endpoint,$q,$post,$method);
    assert(is_string($k), "MISSING: $endpoint ".json_encode($q));
    return $k;
}
function no(string $endpoint, array $q, string $method='GET', array $post=[]): void {
    assert(quota_key($endpoint,$q,$post,$method)===null, "UNEXPECTED: $endpoint ".json_encode($q));
}
$id='00000000-0000-4000-8000-000000000014';
// Protect startup/background reads and every pagination/mirror branch.
foreach (['app_home_feed','app_config','api_explorer','api_boxoffice'] as $route) {
    for ($i=0;$i<120;$i++) no($route,['action'=>'home','page'=>strval($i+1)]);
}
foreach (['home','boot','init','section','collections','search','live_search','notifications','play','ping'] as $a) {
    no('app_api',['action'=>$a,'page'=>'1']);
}
foreach (['api2','api4','api5','api6','archive1_live'] as $route) {
    no($route,['section'=>'updates','page'=>'1']);
    no($route,['genre'=>'action','page'=>'1']); // without an intentional request
    no($route,['section'=>'movie','page'=>'2','bm_q_intent'=>'section']);
    no($route,['id'=>'film123']); // passive hydration must NOT spend allowance
    no($route,['poster'=>'sample']);
}
no('app_api',['action'=>'detail','id'=>'tt51','bm_v224_click_reported'=>'1']); // old 22.4 passive
no('app_api',['action'=>'detail','id'=>'tt51','bm_q_passive'=>'1']); // V22.5 passive hydration
no('app_api',['action'=>'collection','slug'=>'x','page'=>'2','bm_q_intent'=>'collection']);
no('api_discover',['mode'=>'mood','page'=>'1']); // automatic initial recommendations
no('api_discover',['mode'=>'catalog','bm_q_intent'=>'discover']);
no('app_user_api',['action'=>'me']);
no('app_user_api',['action'=>'config']);
no('app_user_api',['action'=>'watchlist_list']);
no('app_user_api',['action'=>'watchlist_sync'], 'POST'); // login migration / auto sync
no('app_api',['action'=>'home','bm_q_intent'=>'section']); // forged intent not valid
no('app_api',['action'=>'search','q'=>'x','bm_q_intent'=>'section']);
// Actual service operations: the network request itself is the counted unit.
yes('app_api',['action'=>'detail','id'=>'tt51','bm_q_intent'=>'detail','bm_q_request_id'=>$id]);
yes('app_api',['action'=>'collection','slug'=>'marvel','bm_q_intent'=>'collection','bm_q_request_id'=>$id]);
yes('app_api',['action'=>'collections','bm_q_intent'=>'collections','page'=>'1']);
yes('app_api',['action'=>'section','section'=>'top_movies','bm_q_intent'=>'section','page'=>'1']);
yes('app_api',['action'=>'search','genre'=>'action','bm_q_intent'=>'genre','page'=>'1']);
yes('app_api',['action'=>'search','q'=>'dune','bm_q_intent'=>'advanced_search','page'=>'1']);
yes('api4',['genre'=>'action','page'=>'1','bm_q_intent'=>'genre']);
yes('api5',['advanced'=>'1','page'=>'1','bm_q_intent'=>'genre']);
yes('api_discover',['mode'=>'mixer','page'=>'1','bm_q_intent'=>'discover']);
yes('app_user_api',['action'=>'login'],'POST');
yes('app_user_api',['action'=>'register'],'POST');
yes('app_user_api',['action'=>'avatar_update'],'POST');
yes('app_user_api',['action'=>'comment_add'],'POST');
yes('app_user_api',['action'=>'watchlist_sync','bm_q_intent'=>'watchlist_change','bm_q_request_id'=>$id],'POST');
yes('app_user_api',['action'=>'watchlist_list','bm_q_intent'=>'watchlist_view'],'GET');
// Old APK compatibility: page details only, no separate action endpoint.
yes('app_api',['action'=>'detail','id'=>'tt87']);
yes('app_api',['action'=>'detail','id'=>'tt88','bm_v224_click_reported'=>'1','bm_v224_click_id'=>$id]);
$policy=bm22_policy();
assert($policy['limit_per_minute']===50);
assert(bm22_save_policy(array_merge($policy,['limit_per_minute'=>10])));
assert(bm22_policy()['limit_per_minute']===10);
$install='test-installation-2026';
$cases=[
 ['app_api',['action'=>'detail','id'=>'tt1','bm_q_intent'=>'detail']],
 ['app_api',['action'=>'collection','slug'=>'marvel','bm_q_intent'=>'collection']],
 ['app_api',['action'=>'section','section'=>'top','bm_q_intent'=>'section']],
 ['app_api',['action'=>'search','genre'=>'action','bm_q_intent'=>'genre']],
 ['api_discover',['mode'=>'mixer','bm_q_intent'=>'discover']],
 ['api4',['genre'=>'crime','bm_q_intent'=>'genre']],
 ['app_api',['action'=>'collections','bm_q_intent'=>'collections']],
 ['app_api',['action'=>'search','q'=>'hey','bm_q_intent'=>'advanced_search']],
 ['app_user_api',['action'=>'login']],
 ['app_user_api',['action'=>'register']],
];
foreach ($cases as $i=>$entry) {
    [$endpoint,$q]=$entry;
    $requestId=sprintf('00000000-0000-4000-8000-%012d',$i+100);
    if (!in_array($endpoint,['app_user_api'],true)) $q['bm_q_request_id']=$requestId;
    $method=$endpoint==='app_user_api' ? 'POST':'GET';
    $k=yes($endpoint,$q,$method);
    assert(bm22_limit_content_open($install,$k,10,60,60)===0);
    assert(bm22_limit_content_open($install,$k,10,60,60)===0); // network retry
}
$eleventh=yes('app_user_api',['action'=>'avatar_update'],'POST');
$retry=bm22_limit_content_open($install,$eleventh,10,60,8);
assert($retry>0 && $retry<=60, 'Eleventh quota operation should be denied');
// Another installation has independent allowance.
assert(bm22_limit_content_open('other-installation',$eleventh,10,60)===0);
// Automatic calls after reaching quota never go into bm22_limit_content_open.
for($i=0;$i<100;$i++) assert(quota_key('app_api',['action'=>'section','page'=>'1'])===null);
$private=__DIR__.'/.private/open_'.hash('sha256',$install).'.php';
$persisted=file_get_contents($private);
assert(str_starts_with($persisted,'<?php http_response_code(404);'));
assert(!str_contains($persisted,'marvel') && !str_contains($persisted,'tt1'));
echo "PASS: real server operations, 10/min 11th denied, background free, UUID retry idem, no raw IDs\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$T/verify.php"
php -l server-required/v2/api/bm_security.php >/dev/null
php -l server-required/bm_admin.php >/dev/null
python3 - <<'PY'
from pathlib import Path
root=Path('app/src/main/java/ir/bankmoviee/app')
main=(root/'MainActivity.kt').read_text()
client=(root/'BmV22Client.kt').read_text()
account=(root/'AccountApi.kt').read_text()
security=Path('server-required/v2/api/bm_security.php').read_text()
assert not (root/'BmUserActions.kt').exists()
assert 'bm22_guard' in Path('server-required/v2/api/action.php').read_text() and 'bm22_limit_content_open' not in Path('server-required/v2/api/action.php').read_text()
assert '"action.php"' not in client
assert 'BmUserActions' not in main and 'recordQuotaAction(' not in main
assert 'bm_v224_click_reported' not in main
assert 'bm_q_intent=detail' in main and 'watchlist_change' in account and 'quotaView' in account
for scope in ('collections','collection','genre','section','discover','advanced_search'):
    assert f'"{scope}"' in main
assert 'initialDiscoverLoad = false' in main
assert 'explicitRequest = false' in main
assert 'bm22_billable_request_key' in security
assert 'bm22_guard' in Path('server-required/v2/api/app_api.php').read_text()
assert 'سقف درخواست‌های واقعی' in Path('server-required/bm_admin.php').read_text()
print('PASS: no click telemetry, only signed real requests tagged; compatibility and admin retained')
PY
