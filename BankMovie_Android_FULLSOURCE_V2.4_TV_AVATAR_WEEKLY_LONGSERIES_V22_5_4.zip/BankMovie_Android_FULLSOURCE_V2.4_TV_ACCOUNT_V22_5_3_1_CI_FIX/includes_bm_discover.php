<?php
/**
 * BankMovie Discover Studio v4 — read-only recommendations from BankMovie's PRIMARY movies table.
 * Does not call paid/remote archives, change schema or bypass archive permissions.
 * PHP 8.0+, MySQL/MariaDB, PDO. Included by discover.php and api_discover.php.
 */
declare(strict_types=1);

function bmd_text($value, int $max = 100): string {
    if (!is_scalar($value)) return '';
    $str = trim((string)$value);
    $str = preg_replace('/[\x00-\x1F\x7F]/u', '', $str) ?? '';
    return function_exists('mb_substr') ? mb_substr($str, 0, $max, 'UTF-8') : substr($str, 0, $max);
}
function bmd_num($value, float $min, float $max, float $default): float {
    return is_scalar($value) && is_numeric($value) ? max($min, min($max, (float)$value)) : $default;
}
function bmd_escape($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function bmd_normalize(string $value): string {
    $value = str_replace(['ي', 'ك', "\u{200C}", '،','|','؛',';'], ['ی','ک',' ', ',', ',', ',', ','], $value);
    return trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
}
function bmd_columns(PDO $pdo): array {
    static $memo = null;
    if ($memo !== null) return $memo;
    $memo = [];
    foreach ($pdo->query('SHOW COLUMNS FROM movies')->fetchAll(PDO::FETCH_ASSOC) as $item) $memo[(string)$item['Field']] = strtolower((string)($item['Type'] ?? ''));
    return $memo;
}
function bmd_runtime_col(PDO $pdo): ?string {
    $cols = bmd_columns($pdo);
    foreach (['runtime_minutes','duration_minutes','runtime','duration','movie_runtime'] as $field) {
        if (isset($cols[$field]) && preg_match('/^(?:tinyint|smallint|mediumint|int|bigint|float|double|decimal)\b/', $cols[$field])) return $field; // numeric minutes only; text duration is not safely comparable.
    }
    return null;
}
function bmd_themes(): array {
    return [
        'excited'=>['label'=>'هیجان','icon'=>'bolt','terms'=>['Action','Adventure','Thriller','اکشن','ماجراجویی','هیجان']],
        'fun'=>['label'=>'خنده','icon'=>'smile','terms'=>['Comedy','کمدی','طنز']],
        'romantic'=>['label'=>'عاشقانه','icon'=>'heart','terms'=>['Romance','Romantic','عاشقانه']],
        'mystery'=>['label'=>'معمایی','icon'=>'puzzle','terms'=>['Mystery','Crime','Detective','معمایی','جنایی','رازآلود']],
        'scary'=>['label'=>'ترسناک','icon'=>'moon','terms'=>['Horror','Thriller','ترسناک','وحشت']],
        'calm'=>['label'=>'آرامش','icon'=>'leaf','terms'=>['Family','Animation','Documentary','خانوادگی','انیمیشن','مستند']],
        'dream'=>['label'=>'فانتزی','icon'=>'stars','terms'=>['Fantasy','Sci-Fi','Science Fiction','فانتزی','علمی تخیلی']],
        'deep'=>['label'=>'عمیق','icon'=>'layers','terms'=>['Drama','Biography','History','درام','زندگینامه','تاریخی']],
    ];
}
function bmd_aliases(string $name): array {
    $aliases = [
        'action'=>['Action','اکشن'], 'adventure'=>['Adventure','ماجراجویی'],
        'comedy'=>['Comedy','کمدی'], 'drama'=>['Drama','درام'],
        'romance'=>['Romance','Romantic','عاشقانه'], 'thriller'=>['Thriller','هیجانی'],
        'mystery'=>['Mystery','معمایی','رازآلود'], 'crime'=>['Crime','جنایی'],
        'horror'=>['Horror','ترسناک','وحشت'], 'family'=>['Family','خانوادگی'],
        'animation'=>['Animation','انیمیشن','کارتون'], 'fantasy'=>['Fantasy','فانتزی'],
        'sci-fi'=>['Sci-Fi','Science Fiction','علمی تخیلی','علمی‌تخیلی'],
        'documentary'=>['Documentary','مستند'], 'biography'=>['Biography','بیوگرافی'],
        'history'=>['History','Historical','تاریخی'], 'war'=>['War','جنگی'],
        'music'=>['Music','Musical','موسیقی'], 'western'=>['Western','وسترن'],
        'sport'=>['Sport','ورزشی'], 'anime'=>['Anime','انیمه'],
    ];
    $needle = function_exists('mb_strtolower') ? mb_strtolower(bmd_normalize($name), 'UTF-8') : strtolower(bmd_normalize($name));
    foreach ($aliases as $group) {
        foreach ($group as $member) {
            $member = function_exists('mb_strtolower') ? mb_strtolower($member,'UTF-8') : strtolower($member);
            if ($needle === $member) return $group;
        }
    }
    return [$name];
}
/** Persistent metadata cache, private/HTTP-blocked by the existing .htaccess. */
function bmd_catalog(PDO $pdo): array {
    $file = function_exists('bm_security_private_path') ? bm_security_private_path('discover_catalog_v1.json') : dirname(__DIR__) . '/cache/discover_catalog_v1.json';
    if (is_file($file) && (time() - (int)@filemtime($file)) < 1800) {
        $data = json_decode((string)@file_get_contents($file), true);
        if (is_array($data) && isset($data['genres'])) return $data;
    }
    $genres = [];
    $genreSql = "REPLACE(REPLACE(REPLACE(genres, '،', ','), '|', ','), ';', ',')";
    $nums = implode(' UNION ALL ', array_map(static fn(int $i): string => 'SELECT '.$i.' n', range(1, 14)));
    $sql = "SELECT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(m.g, ',', n.n), ',', -1)) AS genre, COUNT(*) AS cnt
            FROM (SELECT {$genreSql} g FROM movies WHERE genres IS NOT NULL AND genres <> '') m
            JOIN ({$nums}) n ON n.n <= 1 + LENGTH(m.g) - LENGTH(REPLACE(m.g, ',', ''))
            GROUP BY genre HAVING genre <> '' ORDER BY cnt DESC LIMIT 160";
    try {
        foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $label = bmd_text(bmd_normalize((string)$row['genre']), 60);
            if ($label !== '') $genres[] = ['name'=>$label, 'count'=>(int)$row['cnt']];
        }
    } catch (Throwable $e) { error_log('bmd catalog genres: '.$e->getMessage()); }
    $countries = [];
    try {
        foreach ($pdo->query("SELECT country, COUNT(*) cnt FROM movies WHERE country IS NOT NULL AND country <> '' GROUP BY country ORDER BY cnt DESC LIMIT 60")->fetchAll(PDO::FETCH_ASSOC) as $row) {
            if (trim((string)$row['country']) !== '') $countries[]=['name'=>bmd_text($row['country'], 80),'count'=>(int)$row['cnt']];
        }
    } catch (Throwable $e) { error_log('bmd catalog country: '.$e->getMessage()); }
    $result = ['genres'=>$genres,'countries'=>$countries,'duration_available'=>bmd_runtime_col($pdo)!==null, 'updated_at'=>date(DATE_ATOM)];
    $dir = dirname($file);
    if (is_dir($dir) && is_writable($dir)) {
        $tmp = @tempnam($dir, 'bmd');
        if ($tmp !== false) { @file_put_contents($tmp, json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX); @chmod($tmp, 0640); @rename($tmp, $file); }
    }
    return $result;
}
function bmd_genres_of($text): array {
    $parts = preg_split('/[,|،;؛]/u', bmd_normalize((string)$text));
    return array_values(array_filter(array_map('trim', $parts ?: []), static fn($v)=>$v!==''));
}
function bmd_title(array $row): string { return trim((string)($row['title_fa'] ?? '')) ?: (trim((string)($row['title'] ?? '')) ?: 'بدون عنوان'); }
function bmd_card(array $m): array {
    $imdb = bmd_text($m['imdb_code'] ?? '', 32);
    $imdb = preg_match('/^tt\d{5,12}$/', $imdb) ? $imdb : '';
    $poster = $imdb !== '' ? '/posters/' . rawurlencode($imdb) . '.webp' : '';
    if ($poster === '' && isset($m['poster']) && is_string($m['poster'])) {
        $p = trim($m['poster']);
        if (str_starts_with($p, '/') && !str_starts_with($p, '//') && !str_contains($p, '..')) $poster = $p;
    }
    $link = function_exists('bm_movie_url') ? bm_movie_url($m) : ('/movie.php?imdb='.rawurlencode($imdb));
    return [
        'id'=>(int)($m['id']??0), 'title'=>bmd_title($m), 'title_en'=>bmd_text($m['title']??'',120),
        'url'=>$link, 'poster'=>$poster, 'year'=>(int)($m['year']??0),
        'rating'=>round((float)($m['imdb_rate']??0),1), 'votes'=>(int)($m['imdb_votes']??0),
        'genres'=>bmd_genres_of($m['genres']??''), 'country'=>bmd_text($m['country']??'',100),
        'type'=>strtolower(trim((string)($m['type']??'')))==='movie'?'movie':'series',
        'duration'=>(int)($m['_minutes']??0)
    ];
}
function bmd_user_history(PDO $pdo, int $userId): array {
    if ($userId < 1) return ['seen'=>[],'genres'=>[]];
    $seen=[]; $genres=[];
    try {
        $sql = 'SELECT m.id, m.genres FROM (SELECT movie_id FROM watch_history WHERE user_id = ? UNION SELECT movie_id FROM watchlist WHERE user_id = ?) w JOIN movies m ON w.movie_id=m.id LIMIT 120';
        $stmt=$pdo->prepare($sql); $stmt->execute([$userId,$userId]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $seen[(int)$row['id']]=true;
            foreach (bmd_genres_of($row['genres']??'') as $genre) {
                $key=function_exists('mb_strtolower')?mb_strtolower($genre,'UTF-8'):strtolower($genre);
                $genres[$key]=($genres[$key]??0)+1;
            }
        }
    } catch (Throwable $e) { error_log('bmd personal history: '.$e->getMessage()); }
    return ['seen'=>$seen,'genres'=>$genres];
}
function bmd_filter_input(array $input): array {
    $type = bmd_text($input['type']??'all', 12);
    if (!in_array($type,['all','movie','series'],true)) $type='all';
    $mode = bmd_text($input['mode']??'mood', 20);
    if (!in_array($mode,['mood','mixer','quiz','similar','couple','surprise','daily','hidden','popular','personal','lookup','sentence','map','taste'],true)) $mode='mood';
    $version = bmd_text($input['version']??'any',12);
    if (!in_array($version,['any','dubbed','softsub'],true)) $version='any';
    $mood = bmd_text($input['mood']??'excited', 25);
    if (!isset(bmd_themes()[$mood])) $mood='excited';
    $yearMin=(int)bmd_num($input['year_min']??null, 1900, (int)date('Y')+1, 1900);
    $yearMax=(int)bmd_num($input['year_max']??null, 1900, (int)date('Y')+1, (int)date('Y')+1);
    if ($yearMin>$yearMax) [$yearMin,$yearMax]=[$yearMax,$yearMin];
    $genre=bmd_text($input['genre']??'',60);
    $country=bmd_text($input['country']??'',80);
    $mix=[];
    foreach (['excited','fun','romantic','mystery','scary','calm','dream','deep'] as $key) $mix[$key]=(int)bmd_num($input['mix_'.$key]??null,0,100,0);
    $liked=[];
    $rawLikes=$input['likes']??[];
    if(is_array($rawLikes)) foreach(array_slice($rawLikes,0,8) as $like){
        $id=(int)bmd_num($like,0,2000000000,0);
        if($id>0)$liked[]=$id;
    }
    $liked=array_values(array_unique($liked));
    $together=[];
    foreach (['person1','person2'] as $person) {
        $raw=$input[$person]??[]; if (!is_array($raw)) $raw=[];
        $together[$person]=array_slice(array_values(array_filter(array_map(static fn($v)=>bmd_text($v,60),array_slice($raw,0,10)))),0,5);
    }
    return [
        'mode'=>$mode,'mood'=>$mood,'version'=>$version,'type'=>$type, 'genre'=>$genre,'country'=>$country,
        'year_min'=>$yearMin,'year_max'=>$yearMax,'rating_min'=>bmd_num($input['rating_min']??null,0,10,0),
        'max_minutes'=>(int)bmd_num($input['max_minutes']??null,0,300,0),
        'seed'=>(int)bmd_num($input['seed']??null,0,2000000000,0),
        'seed_id'=>(int)bmd_num($input['seed_id']??null,0,2000000000,0),
        'seed_id2'=>(int)bmd_num($input['seed_id2']??null,0,2000000000,0),
        'mix'=>$mix,'together'=>$together,'liked'=>$liked,
        'skip_ids'=>array_values(array_unique(array_filter(array_map('intval', array_slice(is_array($input['skip_ids']??null)?$input['skip_ids']:[],0,36))))),
        'page'=>(int)bmd_num($input['page']??null,1,500,1),
        'per_page'=>(int)bmd_num($input['per_page']??null,1,24,12),
    ];
}
function bmd_terms(array $f): array {
    $terms=[];
    if ($f['genre']!=='') $terms = array_merge($terms,bmd_aliases($f['genre']));
    $themes=bmd_themes();
    if (in_array($f['mode'], ['mood','quiz','surprise','map'],true) && $f['genre']==='') $terms=$themes[$f['mood']]['terms'];
    if ($f['mode']==='mixer') {
        arsort($f['mix']);
        foreach (array_slice($f['mix'],0,3,true) as $key=>$value) if ($value>0) $terms=array_merge($terms, $themes[$key]['terms']);
    }
    foreach (['person1','person2'] as $p) foreach ($f['together'][$p] as $g) $terms=array_merge($terms,bmd_aliases($g));
    return array_slice(array_values(array_unique(array_filter($terms))),0,24);
}
function bmd_seed(PDO $pdo, int $id): ?array {
    if ($id <= 0) return null;
    $stmt=$pdo->prepare('SELECT id,genres,title,imdb_code FROM movies WHERE id=? LIMIT 1');
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}
function bmd_candidates(PDO $pdo, array $f, array $terms, array $excluded): array {
    $cols=bmd_columns($pdo);
    $parts=["m.title IS NOT NULL", "m.title <> ''"];
    $params=[];
    if ($f['type']==='movie') $parts[]="m.type = 'movie'";
    if ($f['type']==='series') $parts[]="m.type <> 'movie'";
    if ($f['year_min']>1900) { $parts[]='m.year >= ?'; $params[]=$f['year_min']; }
    if ($f['year_max'] < (int)date('Y')+1) { $parts[]='m.year <= ?'; $params[]=$f['year_max']; }
    if ($f['rating_min']>0) { $parts[]='m.imdb_rate >= ?'; $params[]=$f['rating_min']; }
    if ($f['country']!=='') { $parts[]='m.country LIKE ?'; $params[]='%'.$f['country'].'%'; }
    if ($f['version']==='dubbed') $parts[]='EXISTS (SELECT 1 FROM dubbed_links d WHERE d.movie_id = m.id)';
    if ($f['version']==='softsub') $parts[]='EXISTS (SELECT 1 FROM softsub_links ss WHERE ss.movie_id = m.id)';
    $runtime=bmd_runtime_col($pdo);
    if ($runtime!==null && $f['max_minutes']>0) {
        $parts[]="CAST(m.`{$runtime}` AS UNSIGNED) BETWEEN 20 AND ?";
        $params[]=$f['max_minutes'];
    }
    if ($f['mode']==='couple' && $f['together']['person1'] && $f['together']['person2']) {
        // Both people must match: AND between participants, OR within each person's tastes.
        foreach (['person1','person2'] as $person) {
            $any=[];
            $group=[];
            foreach ($f['together'][$person] as $item) $group=array_merge($group,bmd_aliases($item));
            foreach (array_slice(array_unique($group),0,12) as $term) { $any[]='m.genres LIKE ?'; $params[]='%'.$term.'%'; }
            if ($any) $parts[]='('.implode(' OR ',$any).')';
        }
    } elseif ($f['genre'] !== '' || ($terms && !in_array($f['mode'],['daily','popular','hidden','personal'],true))) {
        // Explicit user-selected genre is ALWAYS applied, even for daily/popular/hidden/personal.
        // Mood-derived OR terms are relevant for matching moods, but are not silently forced on curation modes.
        $matchTerms=$f['genre'] !== '' ? bmd_aliases($f['genre']) : $terms;
        $or=[];
        foreach (array_slice(array_values(array_unique($matchTerms)),0,18) as $term) { $or[]='m.genres LIKE ?';$params[]='%'.$term.'%'; }
        if ($or) $parts[]='('.implode(' OR ',$or).')';
    }
    if ($excluded) {
        $ids=array_slice(array_values(array_unique(array_map('intval',$excluded))),0,40);
        $parts[]='m.id NOT IN ('.implode(',',array_fill(0,count($ids),'?')).')';
        array_push($params,...$ids);
    }
    $order="m.imdb_rate DESC, m.imdb_votes DESC, m.id DESC";
    switch ($f['mode']) {
        case 'popular': $order='m.imdb_votes DESC, m.imdb_rate DESC, m.id DESC'; break;
        case 'hidden': $parts[]='m.imdb_rate >= 7';$parts[]='m.imdb_votes BETWEEN 50 AND 30000'; $order='m.imdb_rate DESC, m.imdb_votes ASC, m.id DESC'; break;
        case 'daily':
        case 'surprise':
            // Sample a stable/random ID window instead of always using only the most recently-added 220 titles.
            // MAX(id) is indexed; no ORDER BY RAND() full-table sort.
            $maxId=(int)$pdo->query('SELECT MAX(id) FROM movies')->fetchColumn();
            if ($maxId>1) {
                $salt=$f['mode']==='daily' ? date('Y-m-d') : (string)$f['seed'];
                $pivot=1+(int)(sprintf('%u',crc32($salt.'/discover')) % $maxId);
                $parts[]='m.id >= ?'; $params[]=$pivot;
            }
            $order='m.id ASC';
            break;
        case 'personal': $order='m.imdb_rate DESC, m.id DESC'; break;
    }
    $minutesSql=$runtime!==null?"CAST(m.`{$runtime}` AS UNSIGNED)":"0";
    // No untrusted SQL identifiers: runtime derives solely from a fixed allowlist.
    $sql='SELECT m.id,m.title,m.title_fa,m.imdb_code,m.genres,m.country,m.type,m.year,m.imdb_rate,m.imdb_votes,'.$minutesSql.' AS _minutes'
      .(isset($cols['poster'])?',m.poster':''). ' FROM movies m WHERE '.implode(' AND ',$parts).' ORDER BY '.$order.' LIMIT 220';
    $stmt=$pdo->prepare($sql);$stmt->execute($params);
    $items=$stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$items && in_array($f['mode'],['daily','surprise'],true) && isset($pivot)) {
        // Sparse IDs or a restrictive genre filter can leave the sampled tail empty.
        $fallbackParts=array_filter($parts,static fn($v)=>$v!=='m.id >= ?');
        $fallbackSql='SELECT m.id,m.title,m.title_fa,m.imdb_code,m.genres,m.country,m.type,m.year,m.imdb_rate,m.imdb_votes,'.$minutesSql.' AS _minutes'
            .(isset($cols['poster'])?',m.poster':'').' FROM movies m WHERE '.implode(' AND ',$fallbackParts).' ORDER BY m.id ASC LIMIT 220';
        $fallbackParams=$params;array_pop($fallbackParams); // pivot is appended last
        $stmt=$pdo->prepare($fallbackSql);$stmt->execute($fallbackParams);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    return $items;
}
function bmd_score(array $row, array $f, array $terms, array $history, array $seeds): float {
    $g = bmd_genres_of($row['genres']??'');
    $raw = implode(' / ', $g);
    if ($f['mode']==='popular') return (float)($row['imdb_votes']??0); // actually ordered by votes, not a fabricated weekly view count.
    $score= min(10,(float)($row['imdb_rate']??0))*5 + log(1+max(0,(int)($row['imdb_votes']??0)))*1.4;
    $score += max(0,min(8,((int)($row['year']??0)-2005)*0.17));
    foreach ($terms as $term) {
        if ($term!=='' && (function_exists('mb_stripos') ? mb_stripos($raw,$term,0,'UTF-8')!==false : stripos($raw,$term)!==false)) $score+=10;
    }
    if ($f['mode']==='mixer') {
        foreach ($f['mix'] as $key=>$v) {
            $matched=false;
            foreach (bmd_themes()[$key]['terms'] as $t) {
                if (function_exists('mb_stripos') ? mb_stripos($raw,$t,0,'UTF-8')!==false : stripos($raw,$t)!==false) { $matched=true;break; }
            }
            if ($matched) $score+=($v/100)*25;
        }
    }
    if ($f['mode']==='couple') {
        foreach (['person1','person2'] as $p) {
            $points=0;
            foreach ($f['together'][$p] as $term) {
                foreach (bmd_aliases($term) as $a) if (function_exists('mb_stripos') ? mb_stripos($raw,$a,0,'UTF-8')!==false : stripos($raw,$a)!==false) { $points+=1;break; }
            }
            $score+=min(3,$points)*28; // both sides equally important
        }
    }
    foreach ($seeds as $seed) {
        $intersection=0;
        foreach (bmd_genres_of($seed['genres']??'') as $term) {
            foreach (bmd_aliases($term) as $a) if (function_exists('mb_stripos') ? mb_stripos($raw,$a,0,'UTF-8')!==false : stripos($raw,$a)!==false) {++$intersection;break; }
        }
        $score+=min(4,$intersection)*21;
    }
    if ($f['mode']==='personal') {
        foreach ($g as $item) {
            $key=function_exists('mb_strtolower')?mb_strtolower($item,'UTF-8'):strtolower($item);
            $score+=min(20,($history['genres'][$key]??0)*3);
        }
    }
    if (isset($history['seen'][(int)$row['id']])) $score-=200;
    // A user-controlled fresh seed rotates results WITHOUT relaxing the requested genre.
    // Hash jitter is applied only to discovery modes, never to the vote-ranked list.
    if (in_array($f['mode'],['mood','quiz','mixer','sentence','map','surprise','similar','taste','couple'],true)) {
        $entropy=(int)sprintf('%u',crc32((string)$f['seed'].'/'.(string)($row['id']??0)));
        $score+=($entropy%10000)/10000*39;
    }

    // Deterministic daily order changes every day; surprise uses client-supplied seed.
    if (in_array($f['mode'], ['daily','surprise'],true)) {
        $salt=$f['mode']==='daily'?date('Y-m-d'):(string)$f['seed'];
        $score+= (crc32((string)$row['id'].'/'.$salt)%10000)/55;
    }
    if ($f['mode']==='hidden') $score+=max(0,25-log(1+max(0,(int)($row['imdb_votes']??0)))*2);
    return $score;
}
function bmd_recommend(PDO $pdo, array $input, int $userId = 0): array {
    $f=bmd_filter_input($input);
    if ($f['mode']==='lookup') return ['items'=>[],'reason'=>'invalid_mode'];
    $seeds=[];
    if (in_array($f['mode'],['similar'],true)) {
        foreach ([$f['seed_id'],$f['seed_id2']] as $id) if ($seed=bmd_seed($pdo,$id)) $seeds[]=$seed;
        if (!$seeds) return ['items'=>[], 'reason'=>'select_seed'];
    }
    if ($f['mode']==='taste') {
        foreach ($f['liked'] as $id) if ($seed=bmd_seed($pdo,$id)) $seeds[]=$seed;
        if (!$seeds) return ['items'=>[],'reason'=>'select_taste'];
    }
    $terms=bmd_terms($f);
    if ($seeds) foreach ($seeds as $seed) $terms=array_merge($terms,bmd_genres_of($seed['genres']??''));
    $terms=array_values(array_unique($terms));
    $excluded=array_merge(array_map(static fn($s)=>(int)$s['id'],$seeds),$f['skip_ids']);
    $history=bmd_user_history($pdo,$userId);
    if ($f['mode']==='personal' && ($userId<1 || !$history['genres'])) return ['items'=>[], 'reason'=>'insufficient_history','personalized'=>false,'total_candidates'=>0];
    $rows=bmd_candidates($pdo,$f,$terms,$excluded);
    // Combine a high-quality pool with a seed-pivot pool. The latter is selected
    // from the SAME SQL genre/type/quality filters, so fun cannot become horror.
    // This avoids returning the same top handful on every click.
    if (in_array($f['mode'],['mood','mixer','quiz','map','sentence','similar','taste','couple'],true)) {
        $sample=bmd_candidates($pdo,array_merge($f,['mode'=>'surprise']),$terms,$excluded);
        $byId=[];
        foreach (array_merge($rows,$sample) as $row) $byId[(int)$row['id']]=$row;
        $rows=array_values($byId);
    }
    $scored=[];
    foreach ($rows as $row) {
        $score=bmd_score($row,$f,$terms,$history,$seeds);
        $card=bmd_card($row);$card['_score']=$score;
        $scored[]=$card;
    }
    usort($scored,static fn($a,$b)=>($b['_score']<=>$a['_score']) ?: ($b['id']<=>$a['id']));
    $ordered=[];$overflow=[];$countryCounts=[];
    $softCountryCap=4;
    $maxPool=max(36, min(144, $f['per_page'] * 10));
    // Soft diversity for the full paginated pool, not only the first 12 items.
    foreach ($scored as $candidate) {
        $country=bmd_normalize((string)($candidate['country']??''));
        $country=trim(explode(',', $country)[0]);
        if ($country!=='' && ($countryCounts[$country]??0)>=$softCountryCap) {$overflow[]=$candidate;continue;}
        unset($candidate['_score']);$ordered[]=$candidate;
        if($country!=='')$countryCounts[$country]=($countryCounts[$country]??0)+1;
        if(count($ordered)>=$maxPool)break;
    }
    if(count($ordered)<$maxPool)foreach($overflow as $candidate){
        if(count($ordered)>=$maxPool)break;
        unset($candidate['_score']);$ordered[]=$candidate;
    }
    $page=max(1,(int)$f['page']);
    $perPage=max(1,min(24,(int)$f['per_page']));
    $totalItems=count($ordered);
    $offset=max(0,($page-1)*$perPage);
    $cards=array_slice($ordered,$offset,$perPage);
    return [
      'items'=>$cards,
      'reason'=>($f['max_minutes']>0 && bmd_runtime_col($pdo)===null)?'duration_unavailable':null,
      'total_candidates'=>count($rows),
      'total_items'=>$totalItems,
      'duration_available'=>bmd_runtime_col($pdo)!==null,
      'personalized'=>($f['mode']==='personal' && $userId>0 && !empty($history['genres'])),
      'page'=>$page,
      'per_page'=>$perPage,
      'has_more'=>($offset+$perPage) < $totalItems
    ];
}
function bmd_lookup(PDO $pdo, string $query): array {
    $query=bmd_text($query,75);
    if ((function_exists('mb_strlen')?mb_strlen($query,'UTF-8'):strlen($query))<2) return [];
    $stmt=$pdo->prepare("SELECT id,title,title_fa,imdb_code,year,imdb_rate,genres,type FROM movies WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ? ORDER BY imdb_votes DESC, imdb_rate DESC LIMIT 12");
    $search='%'.$query.'%';$stmt->execute([$search,$search,$search]);
    return array_map('bmd_card',$stmt->fetchAll(PDO::FETCH_ASSOC));
}


/** Native collection covers (the same data/path used in BankMovie collections.php). */
function bmd_collections(PDO $pdo, int $limit=8): array {
    $limit=max(1,min(16,$limit));
    try {
        $sql='SELECT c.id,c.slug,c.title,c.title_fa,c.cover_image, COUNT(cm.id) AS movie_count FROM collections c LEFT JOIN collection_movies cm ON cm.collection_id=c.id WHERE c.status=1 GROUP BY c.id ORDER BY movie_count DESC, c.id DESC LIMIT '.$limit;
        $result=[];
        foreach($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $c){
            $slug=trim((string)($c['slug']??''));
            if($slug===''||preg_match('~[/?#]~',$slug))continue;
            $url=function_exists('bm_public_asset_url')?bm_public_asset_url($c['cover_image']??'',''):(string)($c['cover_image']??'');
            // Render only images at safe relative URLs. Browser never receives local file paths.
            if(!is_string($url)||!(preg_match('~^https?://[^\s]+$~i',$url) || (str_starts_with($url,'/')&&!str_starts_with($url,'//')&&!str_contains($url,'..'))))$url='';
            $result[]=['title'=>bmd_text($c['title_fa']?:$c['title'],120),'poster'=>$url,'url'=>'/collection/'.rawurlencode($slug),'count'=>(int)($c['movie_count']??0)];
        }
        return $result;
    }catch(Throwable $e){error_log('BM discover collections: '.$e->getMessage());return [];}
}

/** Discovery category cards: database-grounded counts and real poster previews. */
function bmd_discover_categories(): array {
    return [
        'family'    => ['label'=>'ژانر خانوادگی','subtitle'=>'بر اساس ژانر ثبت‌شده، نه رده سنی','color'=>'#2dc89c'],
        'completed' => ['label'=>'سریال‌های پایان‌یافته','subtitle'=>'پایان سریال در اطلاعات سایت','color'=>'#a88aff'],
        'continuing'=> ['label'=>'سریال‌های ادامه‌دار','subtitle'=>'ادامه‌دار؛ نه لزوماً روی آنتن','color'=>'#fb6878'],
        'dubbed'    => ['label'=>'دارای دوبله فارسی','subtitle'=>'نسخه دوبله ثبت‌شده','color'=>'#45b3e6'],
        'topmovies' => ['label'=>'فیلم‌های تحسین‌شده','subtitle'=>'IMDb حداقل ۸ و ۵هزار رأی','color'=>'#f6c743'],
        'topseries' => ['label'=>'سریال‌های تحسین‌شده','subtitle'=>'IMDb حداقل ۸ و ۵هزار رأی','color'=>'#f99d58'],
        'hidden'    => ['label'=>'گنج‌های کمترشناخته','subtitle'=>'امتیاز بالا، آرای کمتر','color'=>'#7ba6ff'],
        'collections'=>['label'=>'جهان‌های سینمایی','subtitle'=>'کالکشن‌های ثبت‌شده','color'=>'#a08cff']
    ];
}
function bmd_discover_table_cols(PDO $pdo, string $table): array {
    static $memo=[];
    if (isset($memo[$table])) return $memo[$table];
    if (!in_array($table,['movie_release_updates','movie_extra_info','dubbed_links','collections'],true)) return [];
    try {
        $q=$pdo->query('SHOW COLUMNS FROM `'.$table.'`');
        $memo[$table]=array_fill_keys(array_column($q->fetchAll(PDO::FETCH_ASSOC),'Field'),true);
    } catch(Throwable $e) { $memo[$table]=[]; }
    return $memo[$table];
}
function bmd_discover_cat_filter(PDO $pdo,string $key): ?string {
    switch($key){
    case 'family': return "(m.genres LIKE '%Family%' OR m.genres LIKE '%خانوادگی%')";
    case 'completed':
        $u=bmd_discover_table_cols($pdo,'movie_release_updates');$e=bmd_discover_table_cols($pdo,'movie_extra_info');$parts=[];
        if(isset($u['movie_id'],$u['series_completed']))$parts[]='EXISTS (SELECT 1 FROM movie_release_updates u WHERE u.movie_id=m.id AND u.series_completed=1)';
        if(isset($e['imdb_code'],$e['status']))$parts[]="EXISTS (SELECT 1 FROM movie_extra_info x WHERE x.imdb_code=m.imdb_code AND LOWER(TRIM(x.status))='ended')";
        return $parts?"m.type<>'movie' AND (".implode(' OR ',$parts).')':null;
    case 'continuing':
        $e=bmd_discover_table_cols($pdo,'movie_extra_info');
        return isset($e['imdb_code'],$e['status']) ? "m.type<>'movie' AND EXISTS (SELECT 1 FROM movie_extra_info x WHERE x.imdb_code=m.imdb_code AND LOWER(TRIM(x.status))='returning series')" : null;
    case 'dubbed':
        $d=bmd_discover_table_cols($pdo,'dubbed_links');
        return isset($d['movie_id'])?'EXISTS (SELECT 1 FROM dubbed_links d WHERE d.movie_id=m.id)':null;
    case 'topmovies':return "m.type='movie' AND m.imdb_rate>=8 AND m.imdb_votes>=5000";
    case 'topseries':return "m.type<>'movie' AND m.imdb_rate>=8 AND m.imdb_votes>=5000";
    case 'hidden':return "m.imdb_rate>=7.3 AND m.imdb_votes BETWEEN 150 AND 30000";
    default:return null;
    }
}
function bmd_discover_cat_sql(PDO $pdo,string $key): ?string {
    $where=bmd_discover_cat_filter($pdo,$key);
    return $where===null?null:"m.title IS NOT NULL AND m.title<>'' AND (".$where.")";
}
function bmd_discover_cat_rows(PDO $pdo,string $where,int $limit=3,int $offset=0): array {
    $cols=bmd_columns($pdo);$select='m.id,m.title,m.title_fa,m.imdb_code,m.genres,m.country,m.type,m.year,m.imdb_rate,m.imdb_votes'.(isset($cols['poster'])?',m.poster':'');
    $sql='SELECT '.$select.' FROM movies m WHERE '.$where.' ORDER BY m.imdb_rate DESC, m.imdb_votes DESC, m.id DESC LIMIT '.max(1,min(24,$limit)).' OFFSET '.max(0,min(10000,$offset));
    return array_map('bmd_card',$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC));
}
function bmd_discover_cat_count(PDO $pdo,string $where): int {
    // Fixed-category SQL only. Cache protects the large movies table from repeated counts.
    static $memory=[];
    $key=sha1($where);
    if(isset($memory[$key]))return $memory[$key];
    $file=function_exists('bm_security_private_path')?bm_security_private_path('discover_count_'.$key.'.txt'):null;
    if(is_string($file)&&is_file($file)&&time()-(int)@filemtime($file)<360){
        $value=trim((string)@file_get_contents($file));
        if(ctype_digit($value))return $memory[$key]=(int)$value;
    }
    $count=(int)$pdo->query('SELECT COUNT(*) FROM movies m WHERE '.$where)->fetchColumn();
    $memory[$key]=$count;
    if(is_string($file)&&is_dir(dirname($file))&&is_writable(dirname($file))){
        $temp=@tempnam(dirname($file),'bmd');
        if($temp!==false){@file_put_contents($temp,(string)$count,LOCK_EX);@chmod($temp,0640);@rename($temp,$file);}
    }
    return $count;
}
function bmd_discover_explorer(PDO $pdo): array {
    $cache=function_exists('bm_security_private_path')?bm_security_private_path('discover_explorer_v43.json'):null;
    if(is_string($cache)&&is_file($cache)&&time()-(int)@filemtime($cache)<360){
       $value=json_decode((string)@file_get_contents($cache),true);
       if(is_array($value)&&isset($value['categories']))return $value;
    }
    $output=[];
    foreach(bmd_discover_categories() as $key=>$info){
        $one=['key'=>$key]+$info+['available'=>false,'count'=>null,'posters'=>[]];
        try{
           if($key==='collections'){
               $c=bmd_discover_table_cols($pdo,'collections');
               if(isset($c['id'],$c['status'])){
                   $one['available']=true;
                   $one['count']=(int)$pdo->query('SELECT COUNT(*) FROM collections WHERE status=1')->fetchColumn();
                   $collections=bmd_collections($pdo,3);
                   foreach($collections as $item)if(!empty($item['poster']))$one['posters'][]=['poster'=>$item['poster'],'title'=>$item['title']];
                   $one['href']='/collections';
               }
           }else{
               $where=bmd_discover_cat_sql($pdo,$key);
               if($where!==null){
                   $one['available']=true;
                   $one['count']=bmd_discover_cat_count($pdo,$where);
                   $one['posters']=array_map(static fn($c)=>['poster'=>$c['poster'],'title'=>$c['title']],bmd_discover_cat_rows($pdo,$where,3));
               }
           }
        }catch(Throwable $e){error_log('Discover category '.$key.': '.$e->getMessage());}
        $output[]=$one;
    }
    $catalog=bmd_catalog($pdo);
    $result=['categories'=>$output,'genres'=>array_slice($catalog['genres']??[],0,10),'countries'=>array_slice($catalog['countries']??[],0,12)];
    if(is_string($cache)&&is_dir(dirname($cache))&&is_writable(dirname($cache))){
       $temp=@tempnam(dirname($cache),'bmd');
       if($temp!==false){@file_put_contents($temp,json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),LOCK_EX);@chmod($temp,0640);@rename($temp,$cache);}
    }
    return $result;
}
function bmd_discover_category_results(PDO $pdo,array $input): array {
    $key=bmd_text($input['category_key']??'',30);
    $defs=bmd_discover_categories();
    if(!isset($defs[$key]))return ['items'=>[],'error'=>'unknown_category','page'=>1,'has_more'=>false,'total_items'=>0];
    if($key==='collections')return ['items'=>[],'error'=>'open_collections','page'=>1,'has_more'=>false,'total_items'=>0];
    $where=bmd_discover_cat_sql($pdo,$key);
    if($where===null)return ['items'=>[],'error'=>'category_unavailable','page'=>1,'has_more'=>false,'total_items'=>0];
    $page=(int)bmd_num($input['page']??1,1,500,1);
    $perPage=(int)bmd_num($input['per_page']??12,1,24,12);
    $count=bmd_discover_cat_count($pdo,$where);
    $offset=($page-1)*$perPage;
    return ['items'=>$offset<$count?bmd_discover_cat_rows($pdo,$where,$perPage,$offset):[],
      'page'=>$page,'per_page'=>$perPage,'total_items'=>$count,'total_candidates'=>$count,
      'has_more'=>$offset+$perPage<$count,'category_title'=>$defs[$key]['label'],'category_key'=>$key];
}

/** One category per request: a slow/failed count must not block other cards or genre/country. */
function bmd_discover_explorer_item(PDO $pdo, string $key): array {
    $defs=bmd_discover_categories();
    if (!isset($defs[$key])) return ['key'=>$key,'available'=>false,'count'=>null,'posters'=>[],'error'=>'unknown_category'];
    $one=array_merge(['key'=>$key,'available'=>false,'count'=>null,'posters'=>[]],$defs[$key]);
    $file=function_exists('bm_security_private_path') ? bm_security_private_path('discover_item_v431_'.$key.'.json') : null;
    if (is_string($file)&&is_file($file)&&time()-(int)@filemtime($file)<900) {
        $cached=json_decode((string)@file_get_contents($file),true);
        if(is_array($cached)&&($cached['key']??'')===$key) return $cached;
    }
    try {
        if($key==='collections'){
            $columns=bmd_discover_table_cols($pdo,'collections');
            if(isset($columns['id'],$columns['status'])){
                $one['available']=true;
                $one['count']=(int)$pdo->query('SELECT COUNT(*) FROM collections WHERE status=1')->fetchColumn();
                foreach(bmd_collections($pdo,3) as $item)if(!empty($item['poster']))$one['posters'][]=['poster'=>$item['poster'],'title'=>$item['title']];
                $one['href']='/collections';
            }
        }else{
            $where=bmd_discover_cat_sql($pdo,$key);
            if($where!==null){
                $one['available']=true;
                // Pick a few poster previews first; report counts only if the count query succeeds.
                $one['posters']=array_map(static fn($c)=>['poster'=>$c['poster'],'title'=>$c['title']],bmd_discover_cat_rows($pdo,$where,3));
                $one['count']=bmd_discover_cat_count($pdo,$where);
            }
        }
    }catch(Throwable $e){
        error_log('BankMovie discover explorer item '.$key.': '.$e->getMessage());
        $one['available']=false;
        $one['count']=null;
        $one['error']='item_unavailable';
    }
    if($one['available']===true && $one['count']!==null && is_string($file)&&is_dir(dirname($file))&&is_writable(dirname($file))){
        $tmp=@tempnam(dirname($file),'bmd');
        if($tmp!==false){@file_put_contents($tmp,json_encode($one,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE),LOCK_EX);@chmod($tmp,0640);@rename($tmp,$file);}
    }
    return $one;
}


/**
 * BankMovie's own active collections, selected for a cinematic storefront.
 * Editorial priority is a manually curated franchise list, NOT a view-count ranking.
 * Counts, years, ratings, titles and the three posters come from the live database.
 */
function bmd_featured_priority(string $value): int {
    $value = bmd_normalize($value);
    $v = function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    $groups = [
        ['مارول','marvel'],
        ['مرد عنکبوتی','spider-man','spiderman'],
        ['هری پاتر','harry potter'],
        ['بتمن','batman'],
        ['سریع و خشن','fast & furious','fast and furious'],
        ['ماموریت غیر ممکن','ماموریت غیرممکن','mission impossible'],
        ['جنگ ستارگان','star wars'],
        ['ژوراسیک','jurassic'],
        ['ارباب حلقه','lord of the rings'],
        ['هابیت','hobbit'],
        ['جان ویک','john wick'],
        ['احضار','conjuring'],
        ['تبدیل شوندگان','ترنسفورمر','transformers'],
        ['انتقام جویان','avengers'],
        ['ماتریکس','matrix'],
        ['جیغ','scream'],
        ['مقصد نهایی','final destination'],
        ['دزدان دریایی','pirates of'],
        ['داستان اسباب بازی','toy story'],
        ['شرک','shrek'],
        ['عصر یخ بندان','ice age'],
        ['پدرخوانده','godfather'],
        ['هتل ترانسیلوانیا','transylvania'],
        ['مردان ایکس','x-men'],
        ['ددپول','deadpool'],
        ['نارنیا','narnia']
    ];
    foreach($groups as $index => $aliases) foreach($aliases as $alias) {
        $alias = function_exists('mb_strtolower') ? mb_strtolower($alias, 'UTF-8') : strtolower($alias);
        if((function_exists('mb_strpos') ? mb_strpos($v, $alias, 0, 'UTF-8') : strpos($v, $alias)) !== false) return 900 - $index * 24;
    }
    return 0;
}
function bmd_featured_asset($asset): string {
    $path = function_exists('bm_public_asset_url') ? bm_public_asset_url($asset ?? '', '') : (string)$asset;
    if(!is_string($path)) return '';
    if(str_starts_with($path,'/') && !str_starts_with($path,'//') && !str_contains($path,'..')) return $path;
    if(preg_match('~^https?://[^\\s]+$~i',$path)) return $path;
    return '';
}
function bmd_featured_pick_trio(array $items): array {
    // The highest-voted, an early entry, and a recent entry from AVAILABLE titles.
    $valid=array_values(array_filter($items, static fn($x)=>is_array($x) && !empty($x['poster'])));
    if(!$valid) return [];
    usort($valid,static fn($a,$b)=>($b['votes']??0)<=>($a['votes']??0));
    $selected=[$valid[0]];
    $old=$valid;usort($old,static fn($a,$b)=>($a['year']??9999)<=>($b['year']??9999));
    $recent=$valid;usort($recent,static fn($a,$b)=>($b['year']??0)<=>($a['year']??0));
    foreach([$old,$recent,$valid] as $group) foreach($group as $row){
        if(!in_array($row['id'],array_column($selected,'id'),true))$selected[]=$row;
        if(count($selected)>=3)break 2;
    }
    return array_slice(array_map(static fn($x)=>['poster'=>$x['poster'],'title'=>$x['title']],$selected),0,3);
}
function bmd_featured_collections(PDO $pdo,int $limit=17): array {
    $limit=max(5,min(24,$limit));
    $file=function_exists('bm_security_private_path') ? bm_security_private_path('discover_featured_collections_v2.json') : dirname(__DIR__).'/cache/discover_featured_collections_v2.json';
    if(is_file($file)&&(time()-(int)@filemtime($file))<900){
        $cached=json_decode((string)@file_get_contents($file),true);
        if(is_array($cached)&&isset($cached['items'])&&is_array($cached['items']))return array_slice($cached['items'],0,$limit);
    }
    try{
        // Query 1: cheap membership counts, with no global movies join.
        $sql='SELECT c.id,c.slug,c.title,c.title_fa,c.cover_image,COUNT(cm.id) AS movie_count '
             .'FROM collections c LEFT JOIN collection_movies cm ON cm.collection_id=c.id '
             .'WHERE c.status=1 GROUP BY c.id';
        $rows=$pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        $rank=[];
        foreach($rows as $r){
            $slug=trim((string)($r['slug']??''));$count=(int)($r['movie_count']??0);
            if($slug===''||preg_match('~[/\\?#]~',$slug)||$count<2)continue;
            $priority=bmd_featured_priority(implode(' ',[(string)($r['title_fa']??''),(string)($r['title']??''),$slug]));
            $r['_priority']=$priority*1000+min(300,$count)*7;
            $rank[]=$r;
        }
        usort($rank,static fn($a,$b)=>($b['_priority']<=>$a['_priority']) ?: ((int)$b['movie_count']<=>(int)$a['movie_count']));
        $rank=array_slice($rank,0,$limit);
        if(!$rank)return [];
        // Query 2: actual complete year/rating statistics for ONLY selected IDs.
        $ids=array_map(static fn($x)=>(int)$x['id'],$rank);
        $in=implode(',',array_fill(0,count($ids),'?'));
        $statsStmt=$pdo->prepare('SELECT cm.collection_id,MIN(m.year) AS first_year,MAX(m.year) AS last_year,'
           .'ROUND(AVG(NULLIF(m.imdb_rate,0)),1) AS avg_rating '
           .'FROM collection_movies cm JOIN movies m ON m.id=cm.movie_id '
           .'WHERE cm.collection_id IN ('.$in.') GROUP BY cm.collection_id');
        $statsStmt->execute($ids);
        $stats=[];
        foreach($statsStmt->fetchAll(PDO::FETCH_ASSOC) as $row)$stats[(int)$row['collection_id']]=$row;
        $columns=bmd_columns($pdo);
        $extra=isset($columns['poster'])?',m.poster':'';
        $postersStmt=$pdo->prepare('SELECT m.id,m.title,m.title_fa,m.imdb_code,m.year,m.imdb_rate,m.imdb_votes,m.genres'.$extra.' '
           .'FROM collection_movies cm JOIN movies m ON m.id=cm.movie_id WHERE cm.collection_id=? '
           .'ORDER BY m.imdb_votes DESC,m.imdb_rate DESC LIMIT 22');
        $out=[];
        foreach($rank as $col){
            $id=(int)$col['id'];$postersStmt->execute([$id]);$members=[];
            foreach($postersStmt->fetchAll(PDO::FETCH_ASSOC) as $m){$card=bmd_card($m);if($card['poster']!=='')$members[]=$card;}
            $stat=$stats[$id]??[];
            $out[]=[
               'title'=>bmd_text(($col['title_fa']?:$col['title']),110),
               'url'=>'/collection/'.rawurlencode((string)$col['slug']),
               'cover'=>bmd_featured_asset($col['cover_image']??''),
               'count'=>(int)$col['movie_count'],
               'first_year'=>(int)($stat['first_year']??0),
               'last_year'=>(int)($stat['last_year']??0),
               'avg_rating'=>is_numeric($stat['avg_rating']??null)?round((float)$stat['avg_rating'],1):null,
               'posters'=>bmd_featured_pick_trio($members)
            ];
        }
        $dir=dirname($file);
        if($out&&is_dir($dir)&&is_writable($dir)){
            $tmp=@tempnam($dir,'bmd');
            if($tmp!==false){@file_put_contents($tmp,json_encode(['items'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);@chmod($tmp,0640);@rename($tmp,$file);}
        }
        return $out;
    }catch(Throwable $e){error_log('BM discover featured collections: '.$e->getMessage());return [];}
}

/**
 * Lightweight first-paint collection preview. Rendered in discover.php, not
 * blocked by JavaScript, IntersectionObserver or a second HTTP request.
 * Real collections and actual members only. Cached privately for 15 min.
 */


/** Paginated, genre-neutral decade browsing from the same archive-2 movies table. */
function bmd_decade_results(PDO $pdo, array $input): array {
    $todayYear=(int)date('Y');
    $yearMin=(int)bmd_num($input['year_min']??null,1900,$todayYear+1,1900);
    $yearMax=(int)bmd_num($input['year_max']??null,1900,$todayYear+1,$todayYear);
    if($yearMin>$yearMax) [$yearMin,$yearMax]=[$yearMax,$yearMin];
    $page=(int)bmd_num($input['page']??null,1,500,1);
    $perPage=(int)bmd_num($input['per_page']??null,1,24,12);
    $where="m.year BETWEEN ? AND ? AND m.title IS NOT NULL AND m.title <> ''";
    $countStmt=$pdo->prepare('SELECT COUNT(*) FROM movies m WHERE '.$where);
    $countStmt->execute([$yearMin,$yearMax]);
    $total=(int)$countStmt->fetchColumn();
    $offset=($page-1)*$perPage;
    $items=[];
    if($offset<$total){
        $columns=bmd_columns($pdo);
        $posterSql=isset($columns['poster'])?',m.poster':'';
        $sql='SELECT m.id,m.title,m.title_fa,m.imdb_code,m.year,m.imdb_rate,m.imdb_votes,m.genres,m.country,m.type'.$posterSql
          .' FROM movies m WHERE '.$where
          .' ORDER BY m.imdb_votes DESC,m.imdb_rate DESC,m.id DESC LIMIT ? OFFSET ?';
        $stmt=$pdo->prepare($sql);
        $stmt->bindValue(1,$yearMin,PDO::PARAM_INT);
        $stmt->bindValue(2,$yearMax,PDO::PARAM_INT);
        $stmt->bindValue(3,$perPage,PDO::PARAM_INT);
        $stmt->bindValue(4,$offset,PDO::PARAM_INT);
        $stmt->execute();
        foreach($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) $items[]=bmd_card($row);
    }
    return [
        'items'=>$items,'page'=>$page,'per_page'=>$perPage,
        'total_items'=>$total,'total_candidates'=>$total,
        'has_more'=>$offset+$perPage<$total,
        'year_min'=>$yearMin,'year_max'=>$yearMax
    ];
}

/**
 * Curated decade windows for the discover storefront.
 * Uses live titles from the main movies table and renders as a compact era strip.
 */
function bmd_time_travel_windows(PDO $pdo): array {
    $file=function_exists('bm_security_private_path') ? bm_security_private_path('discover_time_travel_v4.json') : dirname(__DIR__).'/cache/discover_time_travel_v4.json';
    if(is_file($file) && (time()-(int)@filemtime($file))<1800){
        $cached=json_decode((string)@file_get_contents($file),true);
        if(is_array($cached) && isset($cached['items']) && is_array($cached['items'])) return $cached['items'];
    }
    $windows=[
        ['key'=>'classic','title'=>'کلاسیک','range_label'=>'تا ۱۹۷۹','from'=>1900,'to'=>1979,'eyebrow'=>''],
        ['key'=>'80s','title'=>'دهه هشتاد','range_label'=>'۱۹۸۰s','from'=>1980,'to'=>1989,'eyebrow'=>''],
        ['key'=>'90s','title'=>'دهه نود','range_label'=>'۱۹۹۰s','from'=>1990,'to'=>1999,'eyebrow'=>''],
        ['key'=>'2000s','title'=>'دهه ۲۰۰۰','range_label'=>'۲۰۰۰s','from'=>2000,'to'=>2009,'eyebrow'=>''],
        ['key'=>'2010s','title'=>'دهه ۲۰۱۰','range_label'=>'۲۰۱۰s','from'=>2010,'to'=>2019,'eyebrow'=>''],
        ['key'=>'2020s','title'=>'دهه ۲۰۲۰','range_label'=>'۲۰۲۰s','from'=>2020,'to'=>(int)date('Y')+1,'eyebrow'=>''],
    ];
    $out=[];
    try{
        $countStmt=$pdo->prepare('SELECT COUNT(*) FROM movies WHERE year BETWEEN ? AND ?');
        $columns=bmd_columns($pdo);
        $extra=isset($columns['poster'])?',poster':'';
        $rowsStmt=$pdo->prepare('SELECT id,title,title_fa,imdb_code,year,imdb_rate,imdb_votes,genres,country,type'.$extra.' FROM movies WHERE year BETWEEN ? AND ? ORDER BY imdb_votes DESC, imdb_rate DESC, year DESC LIMIT 36');
        foreach($windows as $win){
            $countStmt->execute([$win['from'],$win['to']]);
            $count=(int)$countStmt->fetchColumn();
            $rowsStmt->execute([$win['from'],$win['to']]);
            $cards=[]; $genreCounts=[];
            foreach($rowsStmt->fetchAll(PDO::FETCH_ASSOC) as $row){
                $card=bmd_card($row);
                if($card['poster']!=='') $cards[]=$card;
                foreach($card['genres'] as $genre){
                    $genre=bmd_text($genre,60);
                    if($genre==='') continue;
                    $genreCounts[$genre]=($genreCounts[$genre]??0)+1;
                }
            }
            if($count<1 || !$cards) continue;
            arsort($genreCounts);
            $topGenre=(string)array_key_first($genreCounts);
            if($topGenre==='') $topGenre='سینمایی';
            $out[]=[
                'key'=>$win['key'],
                'title'=>$win['title'],
                'eyebrow'=>$win['eyebrow'],
                'range_label'=>$win['range_label'],
                'count'=>$count,
                'from'=>$win['from'],
                'to'=>$win['to'],
                'top_genre'=>$topGenre,
                'url'=>'/discover?year_min='.$win['from'].'&year_max='.$win['to'],
                'posters'=>bmd_featured_pick_trio($cards),
            ];
        }
        if($out){
            $dir=dirname($file);
            if(is_dir($dir)&&is_writable($dir)){
                $tmp=@tempnam($dir,'bmd');
                if($tmp!==false){@file_put_contents($tmp,json_encode(['items'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);@chmod($tmp,0640);@rename($tmp,$file);}    
            }
        }
    }catch(Throwable $e){
        error_log('BM discover time travel: '.$e->getMessage());
        return [];
    }
    return $out;
}
function bmd_featured_initial(PDO $pdo, int $limit=5): array {
    $limit=max(1,min(5,$limit));
    $file=function_exists('bm_security_private_path') ? bm_security_private_path('discover_initial_collections_v2.json') : dirname(__DIR__).'/cache/discover_initial_collections_v2.json';
    if (is_file($file) && time()-(int)@filemtime($file)<900) {
        $cached=json_decode((string)@file_get_contents($file),true);
        if(is_array($cached)&&isset($cached['items'])&&is_array($cached['items'])) return array_slice($cached['items'],0,$limit);
    }
    try {
        // Avoid the expensive all-collection / all-movie aggregated JOIN used by
        // the previous API on every first visit. Membership COUNT is enough to
        // select the initial showcase; details come from only five collections.
        $summary='SELECT c.id,c.slug,c.title,c.title_fa,c.cover_image,COUNT(cm.id) AS movie_count '
            .'FROM collections c LEFT JOIN collection_movies cm ON cm.collection_id=c.id '
            .'WHERE c.status=1 GROUP BY c.id';
        $rows=$pdo->query($summary)->fetchAll(PDO::FETCH_ASSOC);
        $rank=[];
        foreach($rows as $r){
            $slug=trim((string)($r['slug']??''));$count=(int)($r['movie_count']??0);
            if($slug===''||preg_match('~[/\\?#]~',$slug)||$count<2)continue;
            $priority=bmd_featured_priority(implode(' ',[(string)($r['title_fa']??''),(string)($r['title']??''),$slug]));
            $r['_priority']=$priority*1000+min(300,$count)*7;
            $rank[]=$r;
        }
        usort($rank,static fn($a,$b)=>($b['_priority']<=>$a['_priority']) ?: ((int)$b['movie_count']<=>(int)$a['movie_count']));
        $rank=array_slice($rank,0,$limit);
        if(!$rank)return [];
        $ids=array_map(static fn($r)=>(int)$r['id'],$rank);
        $in=implode(',',array_fill(0,count($ids),'?'));
        $statStmt=$pdo->prepare('SELECT cm.collection_id,MIN(m.year) AS first_year,MAX(m.year) AS last_year,'
            .'ROUND(AVG(NULLIF(m.imdb_rate,0)),1) AS avg_rating FROM collection_movies cm '
            .'JOIN movies m ON m.id=cm.movie_id WHERE cm.collection_id IN ('.$in.') GROUP BY cm.collection_id');
        $statStmt->execute($ids);
        $stats=[];
        foreach($statStmt->fetchAll(PDO::FETCH_ASSOC) as $row)$stats[(int)$row['collection_id']]=$row;
        $columns=bmd_columns($pdo);
        $extra=isset($columns['poster'])?',m.poster':'';
        $st=$pdo->prepare('SELECT m.id,m.title,m.title_fa,m.imdb_code,m.year,m.imdb_rate,m.imdb_votes,m.genres'.$extra.' '
          .'FROM collection_movies cm JOIN movies m ON m.id=cm.movie_id WHERE cm.collection_id=? '
          .'ORDER BY m.imdb_votes DESC,m.imdb_rate DESC LIMIT 18');
        $out=[];
        foreach($rank as $c){
            $st->execute([(int)$c['id']]);
            $members=[];
            foreach($st->fetchAll(PDO::FETCH_ASSOC) as $r){
                $card=bmd_card($r);
                if($card['poster']!=='')$members[]=$card;
            }
            $stat=$stats[(int)$c['id']]??[];
            $out[]=[
                'title'=>bmd_text(($c['title_fa']?:$c['title']),110),
                'url'=>'/collection/'.rawurlencode((string)$c['slug']),
                'cover'=>bmd_featured_asset($c['cover_image']??''),
                'count'=>(int)$c['movie_count'],
                'first_year'=>(int)($stat['first_year']??0),
                'last_year'=>(int)($stat['last_year']??0),
                'avg_rating'=>is_numeric($stat['avg_rating']??null)?round((float)$stat['avg_rating'],1):null,
                'posters'=>bmd_featured_pick_trio($members)
            ];
        }
        if($out){
            $dir=dirname($file);
            if(is_dir($dir)&&is_writable($dir)){
                $tmp=@tempnam($dir,'bmd');
                if($tmp!==false){@file_put_contents($tmp,json_encode(['items'=>$out],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),LOCK_EX);@chmod($tmp,0640);@rename($tmp,$file);}
            }
        }
        return $out;
    } catch(Throwable $e){
        error_log('BM discover initial collections: '.$e->getMessage());
        return [];
    }
}


/** Direct, paginated browse by decade. Never routes through /search or archive1. */
function bmd_browse_decade(PDO $pdo, int $from, int $page=1, int $perPage=18): array {
    $validStarts=[1900,1980,1990,2000,2010,2020];
    if (!in_array($from,$validStarts,true)) throw new InvalidArgumentException('Invalid time range');
    $to=$from===1900?1979:($from===2020?min(2029,(int)date('Y')):$from+9);
    $page=max(1,min(10000,$page));
    $perPage=max(1,min(36,$perPage));
    $filters="m.year BETWEEN :from AND :to AND m.title IS NOT NULL AND m.title <> ''";
    $count=$pdo->prepare('SELECT COUNT(*) FROM movies m WHERE '.$filters);
    $count->bindValue(':from',$from,PDO::PARAM_INT);
    $count->bindValue(':to',$to,PDO::PARAM_INT);
    $count->execute();
    $total=(int)$count->fetchColumn();
    $lastPage=max(1,(int)ceil($total/$perPage));
    $page=min($page,$lastPage);
    $offset=($page-1)*$perPage;
    $cols=bmd_columns($pdo);
    $posterSql=isset($cols['poster'])?',m.poster':'';
    $sql='SELECT m.id,m.title,m.title_fa,m.imdb_code,m.genres,m.country,m.type,m.year,m.imdb_rate,m.imdb_votes'
        .$posterSql.' FROM movies m WHERE '.$filters
        .' ORDER BY m.imdb_votes DESC,m.imdb_rate DESC,m.id DESC LIMIT :limit OFFSET :offset';
    $stmt=$pdo->prepare($sql);
    $stmt->bindValue(':from',$from,PDO::PARAM_INT);
    $stmt->bindValue(':to',$to,PDO::PARAM_INT);
    $stmt->bindValue(':limit',$perPage,PDO::PARAM_INT);
    $stmt->bindValue(':offset',$offset,PDO::PARAM_INT);
    $stmt->execute();
    $items=[];
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) $items[]=bmd_card($row);
    return ['from'=>$from,'to'=>$to,'page'=>$page,'last_page'=>$lastPage,
        'per_page'=>$perPage,'total'=>$total,'items'=>$items,
        'has_more'=>$page<$lastPage];
}
