from pathlib import Path
p=Path('/mnt/data/bm_android_v25_work/app/src/main/java/ir/bankmoviee/app/MainActivity.kt')
s=p.read_text()
orig=s
start=s.index('    private fun showDiscover() {')
end=s.index('    private fun showCategories() {',start)
b=s[start:end]
def rep(a,c,label,once=True):
 global b
 n=b.count(a)
 if not n or (once and n!=1): raise Exception(f'{label} count {n}')
 b=b.replace(a,c,1 if once else -1)
 print(label,'ok')
# Theme aware but retains cinematic dark background when the rest of page is dark.
rep('''        val orange = Color.rgb(255, 119, 21)
        val base = Color.rgb(7, 9, 18)
        val panel = Color.rgb(16, 23, 38)
        val muted = Color.rgb(175, 184, 205)
        val ink = Color.WHITE''', '''        val orange = palette.primary
        val base = palette.background
        val panel = palette.panel
        val muted = palette.muted
        val ink = palette.text''','theme colors')
# Better readability of action primary user-selected accent.
rep('''label(value, 12.8f, if (filled) Color.BLACK else ink, filled)''', '''label(value, 12.8f, if (filled) palette.onPrimary else ink, filled)''','action contrast')
# Image frame reuse only circular rounded at parent
rep('''            frame.minimumHeight = height
            return frame''', '''            frame.minimumHeight = height
            frame.clipChildren = true
            return frame''','poster clipping')
# Loader only blocks interactive requests; passive catalog lookups don't obstruct screen.
rep('''        val loadingShield = FrameLayout(this).apply {
            setBackgroundColor(0xB909101C.toInt())
            visibility = View.GONE
            isClickable = true
            isFocusable = true
        }''','''        val loadingShield = FrameLayout(this).apply {
            setBackgroundColor(0xAD050811.toInt())
            visibility = View.GONE
            isClickable = true
            isFocusable = true
            contentDescription = "در حال بارگذاری پیشنهادها"
        }''','loader backdrop')
rep('''        fun request(mode: String, params: Map<String, String> = emptyMap(), done: (JSONObject?, String?) -> Unit) {
            activeRequests++
            showLoader()
            val qs =''','''        fun request(mode: String, params: Map<String, String> = emptyMap(), blocking: Boolean = true, done: (JSONObject?, String?) -> Unit) {
            if (blocking) {
                activeRequests++
                showLoader()
            }
            val qs =''','request loading signature')
rep('''                    hideLoader()
                    if (ok && json?.optBoolean("ok") == true)''','''                    if (blocking) hideLoader()
                    if (ok && json?.optBoolean("ok") == true)''','request loader finish')
# Banner color-safe: text is on a dark overlay and stays white
rep('''        cinematicOverlay.addView(label("BANKMOVIE / EXPLORE", 10.5f, orange, true))''', '''        cinematicOverlay.addView(label("BANKMOVIE / EXPLORE", 10.5f, Color.rgb(255, 156, 65), true))''','hero cinematic tagline')
# Rich mood cards use the same exact webp assets as website. Add fixed labels + subtitles
old='''        moodKeys.forEachIndexed { i, key ->
            val chip = action(moodNames[i], key == selectedMood) {
                selectedMood = key
                for (n in 0 until moodGrid.childCount) {
                    (moodGrid.getChildAt(n) as? TextView)?.let { view ->
                        view.background = rounded(if (n == i) orange else panel, dp(13), if (n == i) orange else Color.rgb(48, 56, 78))
                        view.setTextColor(if (n == i) Color.BLACK else ink)
                    }
                }
                runMode("mood", 1)
            }
            moodGrid.addView(chip, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(43)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }'''
new='''        val moodArt = intArrayOf(
            R.drawable.bm_discover_mood_excited, R.drawable.bm_discover_mood_fun,
            R.drawable.bm_discover_mood_romantic, R.drawable.bm_discover_mood_mystery,
            R.drawable.bm_discover_mood_scary, R.drawable.bm_discover_mood_calm,
            R.drawable.bm_discover_mood_dream, R.drawable.bm_discover_mood_deep
        )
        val moodSubtitles = arrayOf("اکشن و هیجان", "کمدی و سرگرمی", "عاشقانه و احساس", "معمایی و راز", "ترس و تعلیق", "آرام و دلچسب", "فانتزی و تخیل", "داستان اثرگذار")
        val moodCards = mutableListOf<FrameLayout>()
        fun refreshMoodCards() {
            moodCards.forEachIndexed { index, card ->
                val active = index == moodKeys.indexOf(selectedMood)
                card.background = rounded(panel, dp(17), if (active) orange else palette.stroke)
                card.alpha = if (active) 1f else .92f
            }
        }
        moodKeys.forEachIndexed { i, key ->
            val chip = FrameLayout(this).apply {
                background = rounded(panel, dp(17), palette.stroke)
                clipToOutline = true
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 17, 1.035f, 0f)
                setOnClickListener {
                    selectedMood = key
                    refreshMoodCards()
                    runMode("mood", 1)
                }
            }
            chip.addView(ImageView(this).apply {
                setImageResource(moodArt[i])
                scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(-1, -1))
            chip.addView(View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x10040711, 0x5A040711, 0xF4040711.toInt()))
            }, FrameLayout.LayoutParams(-1, -1))
            val moodCopy = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.BOTTOM or Gravity.RIGHT
                setPadding(dp(10), dp(6), dp(10), dp(8))
            }
            moodCopy.addView(label(moodNames[i], 13f, Color.WHITE, true))
            moodCopy.addView(label(moodSubtitles[i], 9.2f, Color.rgb(220, 225, 236)))
            chip.addView(moodCopy, FrameLayout.LayoutParams(-1, -1))
            moodCards.add(chip)
            moodGrid.addView(chip, GridLayout.LayoutParams().apply {
                width = 0
                height = dp(if (tv) 105 else 80)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(3), dp(3), dp(3), dp(3))
            })
        }
        refreshMoodCards()'''
rep(old,new,'mood artwork UI')
# Prevent false 'more' loaded when mode changes; auto scroll only once new API result is ready.
rep('''        var nextRequest = 0
        val resultIds =''','''        var nextRequest = 0
        var firstDiscoverResults = true
        val resultIds =''','initial vs interactive')
rep('''            if (!sameMode) {
                resultIds.clear()
                grid.removeAllViews()
                pageInfo.text = "در حال دریافت پیشنهادها..."
            }''','''            // Retain the previous posters until the new response succeeds.
            // A network error must not erase valid results or leave an empty screen.
            pageInfo.text = "در حال جستجو در آرشیو بانک مووی…"''','keep content until success')
rep('''                val arr = data.optJSONArray("items") ?: JSONArray()
                val fullWidth =''','''                val arr = data.optJSONArray("items") ?: JSONArray()
                if (!sameMode) {
                    resultIds.clear()
                    grid.removeAllViews()
                }
                val fullWidth =''','clear on success')
rep('''                hasMore = data.optBoolean("has_more", false)
                pageInfo.text =''','''                hasMore = data.optBoolean("has_more", false)
                if (firstDiscoverResults) {
                    firstDiscoverResults = false
                } else {
                    // Real scroll to results after requests complete, not on tap.
                    // It also works for filters, moods, surprise, decade and mixer.
                    scroll.post {
                        if (isActive()) scroll.smoothScrollTo(0, (resultsPanel.top - dp(18)).coerceAtLeast(0))
                    }
                }
                pageInfo.text =''','smooth results reveal')
# no longer double-scroll on click before API answer
rep('''else { categoryKey = key; runMode("category", 1); scroll.smoothScrollTo(0, resultsPanel.top) }''','''else { categoryKey = key; runMode("category", 1) }''','category scroll only after response')
rep('''                runMode("decade", 1)
                scroll.smoothScrollTo(0, resultsPanel.top)''','''                runMode("decade", 1)''','decade scroll only after response')
# add posters to category, directly from API explorer's posters field
old='''                card.addView(label(name, 12.5f, ink, true))
                card.addView(label("${item.optInt("count")} عنوان", 10f, orange), LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
                categoryPanel.addView(card, GridLayout.LayoutParams().apply { width = 0; height = dp(88); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })'''
new='''                val categoryBody = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                }
                val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                info.addView(label(name, 12.2f, ink, true).apply { maxLines = 2 })
                info.addView(label("${item.optInt("count")} عنوان", 10f, orange),
                    LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
                categoryBody.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
                val posters = item.optJSONArray("posters") ?: JSONArray()
                if (posters.length() > 0) {
                    val art = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }
                    for (j in 0 until minOf(3, posters.length())) {
                        val artUrl = posters.optJSONObject(j)?.optString("poster").orEmpty()
                            .ifBlank { posters.optString(j) }
                        if (artUrl.isBlank()) continue
                        val image = ImageView(this).apply {
                            scaleType = ImageView.ScaleType.CENTER_CROP
                            background = rounded(base, dp(7), palette.stroke)
                            clipToOutline = true
                            rotation = (j - 1) * 7f
                            loadImage(artUrl, this)
                        }
                        art.addView(image, FrameLayout.LayoutParams(dp(39), dp(65)).apply {
                            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                            rightMargin = dp(j * 17)
                        })
                    }
                    categoryBody.addView(art, LinearLayout.LayoutParams(dp(78), dp(75)).apply { marginStart = dp(5) })
                }
                card.addView(categoryBody, LinearLayout.LayoutParams(-1, -1))
                categoryPanel.addView(card, GridLayout.LayoutParams().apply { width = 0; height = dp(100); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f); setMargins(dp(4), dp(4), dp(4), dp(4)) })'''
rep(old,new,'category 3 posters')
# rounded collection card & poster trio
rep('''                    background = rounded(panel, dp(18), Color.rgb(47, 55, 74))
                    setPadding(dp(6), dp(6), dp(6), dp(8))''','''                    background = rounded(panel, dp(20), palette.stroke)
                    clipToOutline = true
                    setPadding(dp(7), dp(7), dp(7), dp(10))''','collection rounded')
rep('''                    val image = ImageView(this).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = rounded(base, dp(9), Color.rgb(53, 59, 77))
                        clipToOutline = true
                        elevation = dp((index + 1) * 2).toFloat()
                        loadImage(poster, this)
                    }''','''                    val image = ImageView(this).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        background = rounded(base, dp(12), palette.stroke)
                        clipToOutline = true
                        rotation = (index - 1) * 7f
                        elevation = dp((index + 1) * 2).toFloat()
                        loadImage(poster, this)
                    }''','collection poster stack')
# Nonblocking request for read-only section discovery
rep('''        request("explorer") { data, _ ->''','''        request("explorer", blocking = false) { data, _ ->''','background category data')
rep('''        request("featured_collections") { data, _ ->''','''        request("featured_collections", blocking = false) { data, _ ->''','background featured data')
rep('''        request("catalog") { data, _ ->''','''        request("catalog", blocking = false) { data, _ ->''','background filter data')
# feedback when similarity tapped before movie loaded
rep('''quickRow.addView(action("مشابه") { if (selectedSeedId > 0) runMode("similar", 1) }''','''quickRow.addView(action("مشابه") {
            if (selectedSeedId > 0) runMode("similar", 1)
            else Toast.makeText(this, "اول یک فیلم از پیشنهادها انتخاب کن", Toast.LENGTH_SHORT).show()
        }''','similar no-op fix')
# smooth visual travel: show cover from site for each decade? keep API generated; add decade gradients plus section overlay no static poster.
rep('''            decades.addView(action("دهه ${year}") {''','''            decades.addView(action("دهه ${year}") {''','no-op',once=True) if False else None
if b==s[start:end]:raise Exception('no changes')
s=s[:start]+b+s[end:]
p.write_text(s)
print('Kotlin bytes before',len(orig),'after',len(s),'changes',len(s)-len(orig))
