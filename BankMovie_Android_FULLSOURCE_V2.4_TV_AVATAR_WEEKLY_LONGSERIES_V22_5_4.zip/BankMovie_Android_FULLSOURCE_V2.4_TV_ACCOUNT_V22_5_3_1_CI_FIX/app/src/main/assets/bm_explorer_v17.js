/* BankMovie native Explorer engine — copied from the site's explore.php; isolated from Discover */
(()=>{
'use strict';
const API='/api_explorer.php';
const $=s=>document.querySelector(s),$$=s=>Array.from(document.querySelectorAll(s));
const esc=s=>String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const EXPLORER_BATCH_SIZE=20;
let page=1,loading=false,hasMore=true,items=[],uids=new Set(),bufferedItems=[],bufferedUids=new Set(),normalHasMore=true,lookapoHasMore=true,normalPage=1,lookapoPage=1,hls=null,activeIndex=-1,activeVideo=null,muted=true,reelsObserver=null,playSeq=0,detailPaused=false,reelObserverLocked=true,firstLoad=true;
const LAST_VIEWED_KEY='bm_explorer_last_v251';const movieCache=new Map();
const ICON_PLAY=`<svg viewBox="0 0 24 24" fill="none"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>`;
const ICON_PAUSE=`<svg viewBox="0 0 24 24" fill="none"><path d="M2 6C2 4.11438 2 3.17157 2.58579 2.58579C3.17157 2 4.11438 2 6 2C7.88562 2 8.82843 2 9.41421 2.58579C10 3.17157 10 4.11438 10 6V18C10 19.8856 10 20.8284 9.41421 21.4142C8.82843 22 7.88562 22 6 22C4.11438 22 3.17157 22 2.58579 21.4142C2 20.8284 2 19.8856 2 18V6Z" fill="currentColor"/><path opacity="0.5" d="M14 6C14 4.11438 14 3.17157 14.5858 2.58579C15.1716 2 16.1144 2 18 2C19.8856 2 20.8284 2 21.4142 2.58579C22 3.17157 22 4.11438 22 6V18C22 19.8856 22 20.8284 21.4142 21.4142C20.8284 22 19.8856 22 18 22C16.1144 22 15.1716 22 14.5858 21.4142C14 20.8284 14 19.8856 14 18V6Z" fill="currentColor"/></svg>`;
const ICON_SPEAKER=`<svg viewBox="0 0 75 75"><path d="M39.389,13.769 L22.235,28.606 L6,28.606 L6,47.699 L21.989,47.699 L39.389,62.75 L39.389,13.769z" style="stroke:#fff;stroke-width:5;stroke-linejoin:round;fill:#fff"/><path d="M48,27.6a19.5,19.5 0 0 1 0,21.4M55.1,20.5a30,30 0 0 1 0,35.6M61.6,14a38.8,38.8 0 0 1 0,48.6" style="fill:none;stroke:#fff;stroke-width:5;stroke-linecap:round"/></svg>`;
const ICON_MUTE=`<svg viewBox="0 0 75 75" stroke="#fff" stroke-width="5"><path d="m39,14-17,15H6V48H22l17,15z" fill="#fff" stroke-linejoin="round"/><path d="m49,26 20,24m0-24-20,24" fill="#fff" stroke-linecap="round"/></svg>`;
const ICON_BACK=`<svg viewBox="0 0 24 24" fill="none"><path d="M9 5l7 7-7 7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const ICON_DETAIL=`<svg viewBox="0 0 24 24" fill="none"><rect x="3" y="4" width="18" height="16" rx="4" stroke="currentColor" stroke-width="1.7"/><path d="M8 9h8M8 13h5" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/><circle cx="17" cy="15.5" r="1.5" fill="currentColor"/></svg>`;
const ICON_RETRY=`<svg viewBox="0 0 24 24" fill="none"><path d="M20 7v5h-5M19 12a7 7 0 1 1-2.05-4.95L20 10" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const ICON_SEARCH=`<svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="6.5" stroke="currentColor" stroke-width="1.8"/><path d="M16 16l4.2 4.2" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`;
const ICON_REELS=`<svg viewBox="0 0 24 24" fill="none"><rect x="3.5" y="3.5" width="17" height="17" rx="4.2" stroke="currentColor" stroke-width="1.7"/><path d="M4 8h16M8 4l2.7 4M14 4l2.7 4" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path d="M10 11.2l5 2.8-5 2.8v-5.6Z" fill="currentColor"/></svg>`;
function showError(msg){const e=$('#error');e.textContent=msg;e.classList.add('show')}function clearError(){const e=$('#error');e.textContent='';e.classList.remove('show')}
async function api(q,opt={}){const r=await fetch(API+'?'+new URLSearchParams(q),{credentials:'same-origin',...opt});const t=await r.text();let j;try{j=JSON.parse(t)}catch{throw new Error('پاسخ API نامعتبر است')}if(!r.ok||!j.success)throw new Error(j.message||('HTTP '+r.status));return j}
function uidOf(it){return String(it.uid||((it.provider||'chibebin')+':'+it.id))}
function tile(it,index){const uid=uidOf(it),provider=it.provider||'chibebin',thumb=(it.thumbnail||'').trim(),src=it.stream||(`${API}?`+new URLSearchParams({action:'stream',provider,id:it.id}));const media=thumb?`<img loading="lazy" decoding="async" src="${esc(thumb)}" ${provider==='lookapo'?`data-lookapo-img data-fallback="${esc(`${API}?`+new URLSearchParams({action:'lookapo_image',kind:'post',id:it.id}))}" referrerpolicy="no-referrer"`:''} alt="">`:(provider==='dornatv'?`<video class="explorer-thumb-video" muted playsinline preload="none" src="${esc(src)}"></video>`:`<span class="explorer-thumb-empty" aria-hidden="true">${ICON_REELS}</span>`);const backup=provider==='lookapo'?`<span class="lookapo-card-fallback" aria-hidden="true">${esc(it.title||'')}</span>`:'';return `<button class="explorer-card" data-index="${index}" data-uid="${esc(uid)}" aria-label="باز کردن ویدیو">${backup}${media}<span class="reel-mark">${ICON_REELS}</span></button>`}
function reelSlide(it,index){const provider=it.provider||'chibebin',uid=uidOf(it),title=it.title||('سکانس #'+it.id),sub=it.title_en||'',plot=it.plot||'';return `<article class="reel-slide paused" data-index="${index}" data-uid="${esc(uid)}" data-id="${esc(it.id)}" data-provider="${esc(provider)}" data-movie="${esc(it.movie_id||it.id||'')}"><div class="reel-media"><img class="reel-poster" src="${esc(it.thumbnail)}" ${provider==='lookapo'?`data-lookapo-img data-fallback="${esc(`${API}?`+new URLSearchParams({action:'lookapo_image',kind:'post',id:it.id}))}" referrerpolicy="no-referrer"`:''} alt="" fetchpriority="high"><video class="reel-video" playsinline preload="metadata" poster="${esc(it.thumbnail)}" muted></video><div class="reel-loading"><div class="reel-loading-core"><div class="loader"><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i><i class="bm4-loading-bar"></i></div><span>در حال آماده‌سازی ویدیو…</span></div></div><button class="reel-play-toggle" data-play-toggle aria-label="پخش">${ICON_PLAY}</button><div class="reel-pause-flash" aria-hidden="true">${ICON_PAUSE}</div><div class="reel-playerror"><div data-reel-error>پخش این ویدیو با خطا روبه‌رو شد.</div><button class="retry" data-retry>${ICON_RETRY}<span>تلاش دوباره</span></button></div></div><div class="reel-top"><button class="audio-toggle muted" data-sound aria-label="روشن کردن صدا"><span class="speaker">${ICON_SPEAKER}</span><span class="mute-speaker">${ICON_MUTE}</span></button><button class="reel-circle" data-reel-close aria-label="بازگشت">${ICON_BACK}</button></div><div class="reel-bottom"><div class="reel-copy"><div class="reel-title" data-title>${esc(title)}</div><div class="reel-subtitle" data-subtitle>${esc(sub)}</div><div class="reel-plot" data-plot>${esc(plot)}</div><button class="reel-more ${plot.length>105?'show':''}" data-more>بیشتر</button><div class="reel-actions"><button class="detail-pill" data-info>${ICON_DETAIL}<span>مشاهده جزئیات</span></button><button class="bm-app-vlc" data-open-native aria-label="پخش در پلیر داخلی">پخش داخلی</button><button class="archive-search" data-archive-search ${sub?'data-query="'+esc(sub)+'"':'disabled'} title="جستجو در آرشیو" aria-label="جستجوی نام انگلیسی فیلم در آرشیو">${ICON_SEARCH}</button></div></div></div><div class="reel-progress"><span></span></div></article>`}
function readLastViewed(){let id='';try{id=localStorage.getItem(LAST_VIEWED_KEY)||''}catch{}if(!id){try{const m=document.cookie.match(/(?:^|;\s*)bm_explorer_last_v251=([^;]+)/);if(m)id=decodeURIComponent(m[1])}catch{}}return String(id||'').trim()}
function rememberLastViewed(uid){uid=String(uid||'').trim();if(!uid)return;try{localStorage.setItem(LAST_VIEWED_KEY,uid)}catch{}try{document.cookie='bm_explorer_last_v251='+encodeURIComponent(uid)+'; Max-Age=2592000; Path=/; SameSite=Lax'}catch{}markLastViewed(uid)}
function markLastViewed(uid=readLastViewed()){$$('.explorer-card').forEach(x=>x.classList.toggle('is-last-viewed',x.dataset.uid===uid))}
function indexForUid(uid){uid=String(uid||'');return items.findIndex(x=>uidOf(x)===uid)}
function primeThumbVideos(root=document){
 const thumbs=root.querySelectorAll('video.explorer-thumb-video:not([data-primed])');
 thumbs.forEach(v=>{
  v.dataset.primed='1';
  v.addEventListener('loadedmetadata',()=>{try{if(Number.isFinite(v.duration)&&v.duration>0.15)v.currentTime=Math.min(.12,Math.max(.01,v.duration*.01))}catch{}},{once:true});
  v.addEventListener('canplay',()=>{try{v.pause()}catch{}},{once:true});
  // Loading every thumbnail video at once could exhaust the Android WebView renderer.
  const near=()=>{if(v.dataset.previewLoaded==='1')return;v.dataset.previewLoaded='1';v.preload='metadata';try{v.load()}catch{}};
  if(typeof IntersectionObserver==='function'){
   const obs=new IntersectionObserver(entries=>{if(entries.some(e=>e.isIntersecting)){obs.disconnect();near()}},{rootMargin:'120px'});
   obs.observe(v);
  }else if(v.getBoundingClientRect().top<window.innerHeight+120)near();
 });
}
function appendItems(list){const grid=$('#grid');if(firstLoad){$$('[data-skeleton]').forEach(x=>x.remove());firstLoad=false}const start=items.length,added=[];for(const raw of list){const it={...raw};const uid=uidOf(it);if(!uid||uids.has(uid))continue;uids.add(uid);added.push(it);items.push(it)}if(added.length){grid.insertAdjacentHTML('beforeend',added.map((x,i)=>tile(x,start+i)).join(''));primeThumbVideos(grid)}markLastViewed();if(window.BMExplorerInitialUid){const target=String(window.BMExplorerInitialUid);if(indexForUid(target)>=0){window.BMExplorerInitialUid='';setTimeout(()=>openReelsByUid(target),160)}}if($('#reelsModal').classList.contains('show')){const stream=$('#reelsStream');stream.insertAdjacentHTML('beforeend',added.map((x,i)=>reelSlide(x,start+i)).join(''));refreshReelObserver()}}
// V16.4: Manual 20-card batches; do not silently drop either source on a temporary failure.
function interleave(a,b){const out=[];let j=0;for(let i=0;i<a.length;i++){out.push(a[i]);if((i+1)%3===0&&j<b.length)out.push(b[j++]);}while(j<b.length)out.push(b[j++]);return out;}
const MORE_ICON=`<svg viewBox="0 0 24 24" width="24" height="24" fill="none" aria-hidden="true"><path d="M12 4v16M4 12h16" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"/></svg>`;
const MORE_ARROW=`<svg viewBox="0 0 24 24" width="20" height="20" fill="none" aria-hidden="true"><path d="m7 10 5 5 5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
function setupManualPaging(){
 const sentinel=$('#sentinel');if(sentinel)sentinel.style.display='none';
 const loader=$('#loader');if(!loader)return;
 if($('#explorerShowMore'))return;
 const wrap=document.createElement('div');wrap.className='explorer-pagination';
 const button=document.createElement('button');button.type='button';button.id='explorerShowMore';button.className='explorer-show-more';button.hidden=true;
 button.setAttribute('aria-controls','grid');button.setAttribute('aria-label','نمایش ۲۰ ویدیوی بیشتر');
 button.innerHTML=`<span class="explorer-more-icon">${MORE_ICON}</span><span class="explorer-more-copy"><strong data-more-heading>نمایش ۲۰ مورد بیشتر</strong><small data-more-caption>ادامه اکسپلور</small></span><span class="explorer-more-arrow">${MORE_ARROW}</span>`;
 button.addEventListener('click',()=>loadMore());wrap.appendChild(button);
 const notice=document.createElement('p');notice.id='explorerSourceStatus';notice.className='explorer-source-status';notice.hidden=true;notice.setAttribute('role','status');wrap.appendChild(notice);
 loader.insertAdjacentElement('afterend',wrap);
}
function updateMoreButton(){
 const button=$('#explorerShowMore');if(!button)return;
 button.hidden=!hasMore||(!items.length&&firstLoad);
 button.disabled=loading;
 button.classList.toggle('is-loading',loading);
 const title=button.querySelector('[data-more-heading]');if(title)title.textContent=loading?'در حال دریافت ویدیوها…':'نمایش ۲۰ مورد بیشتر';
 const caption=button.querySelector('[data-more-caption]');if(caption)caption.textContent=loading?'در حال آماده‌سازی موارد جدید':'ادامه اکسپلور';
}
function sourceStatus(msg){const el=$('#explorerSourceStatus');if(!el)return;el.textContent=msg||'';el.hidden=!msg;}
async function fetchNextPage(){
 const requests=[];
 if(normalHasMore)requests.push({source:'normal',page:normalPage,promise:api({action:'sekans',page:normalPage})});
 if(lookapoHasMore)requests.push({source:'lookapo',page:lookapoPage,promise:api({action:'lookapo_list',page:lookapoPage})});
 if(!requests.length)return {fresh:0,hadError:false};
 const results=await Promise.allSettled(requests.map(r=>r.promise));
 let base=[],extra=[],hadError=false,dornaMessage='';
 for(let i=0;i<requests.length;i++){
  const request=requests[i],result=results[i];
  if(result.status==='rejected'){
   hadError=true; // Keep the failed source's page cursor intact for the NEXT manual click.
   if(request.source==='normal')dornaMessage='دریافت بخشی از ویدیوها ناموفق بود؛ دوباره امتحان کن.';
   continue;
  }
  const data=result.value;
  if(request.source==='lookapo'){
   extra=Array.isArray(data.items)?data.items:[];
   lookapoHasMore=data.enabled!==false&&!!data.has_more;
   lookapoPage++;
   continue;
  }
  base=Array.isArray(data.items)?data.items:[];
  normalHasMore=!!data.has_more;
  normalPage++;
  // Server-side mixed feed contains Dorna + Chibebin. If Dorna temporarily
  // vanished from the mixed response, retry its configured provider directly.
  // Never bypass the existing BM ADMIN source visibility / mode controls.
  const dornatv=data.sources?.dornatv;
  if(dornatv?.enabled&& !base.some(it=>it.provider==='dornatv')){
   try{
    const fallback=await api({action:'dorna_list',page:request.page});
    if(Array.isArray(fallback.items)&&fallback.items.length)base=interleave(base,fallback.items);
    else if(data.source_errors?.dornatv)dornaMessage='بعضی ویدیوها فعلاً در دسترس نیستند؛ بعداً دوباره امتحان کن.';
   }catch(_){dornaMessage='بعضی ویدیوها فعلاً بارگذاری نشدند؛ دوباره تلاش کن.';}
  }
 }
 sourceStatus(dornaMessage);
 let fresh=0;
 for(const raw of interleave(base,extra)){
  const uid=uidOf(raw);if(!uid||uids.has(uid)||bufferedUids.has(uid))continue;
  bufferedUids.add(uid);bufferedItems.push(raw);fresh++;
 }
 return {fresh,hadError};
}
async function loadMore(){
 if(loading||!hasMore)return;
 loading=true;clearError();$('#loader').hidden=false;updateMoreButton();
 try{
  let pagesChecked=0,emptyPages=0;
  while(bufferedItems.length<EXPLORER_BATCH_SIZE&&(normalHasMore||lookapoHasMore)&&pagesChecked<8){
   const result=await fetchNextPage();pagesChecked++;
   emptyPages=result.fresh?0:emptyPages+1;
   if(result.hadError)break; // Do not hammer a failing provider eight times at once.
   if(emptyPages>=3){normalHasMore=false;lookapoHasMore=false;break;}
  }
  const next=bufferedItems.splice(0,EXPLORER_BATCH_SIZE);
  next.forEach(x=>bufferedUids.delete(uidOf(x)));
  appendItems(next);
  hasMore=bufferedItems.length>0||normalHasMore||lookapoHasMore;
 }catch(e){
  if(firstLoad)appendItems([]);
  showError(e.message||'دریافت اکسپلور ناموفق بود');
  hasMore=true;
 }finally{loading=false;$('#loader').hidden=true;updateMoreButton();}
}
function openReelsByUid(uid){const i=indexForUid(uid);if(i>=0)openReels(i)}
function openReels(index){if(!items[index])return;const targetUid=uidOf(items[index]);const exact=indexForUid(targetUid);if(exact>=0)index=exact;reelObserverLocked=true;if(reelsObserver){reelsObserver.disconnect();reelsObserver=null}document.body.classList.add('reels-open');$('#reelsModal').classList.add('show');$('#reelsModal').setAttribute('aria-hidden','false');const stream=$('#reelsStream');if(!stream.children.length||stream.children.length!==items.length)stream.innerHTML=items.map(reelSlide).join('');const slide=stream.querySelector(`.reel-slide[data-uid="${CSS.escape(targetUid)}"]`)||stream.querySelector(`.reel-slide[data-index="${index}"]`);requestAnimationFrame(()=>{if(!slide)return;stream.scrollTop=Math.max(0,slide.offsetTop);activateSlide(index,true);rememberLastViewed(targetUid);setTimeout(()=>{if($('#reelsModal').classList.contains('show')){reelObserverLocked=false;refreshReelObserver()}},260)})}
function closeReels(){reelObserverLocked=true;if(reelsObserver){reelsObserver.disconnect();reelsObserver=null}stopPlayback();$('#reelsModal').classList.remove('show');$('#reelsModal').setAttribute('aria-hidden','true');document.body.classList.remove('reels-open');activeIndex=-1;markLastViewed()}
function refreshReelObserver(){if(reelObserverLocked||!$('#reelsModal').classList.contains('show'))return;if(reelsObserver)reelsObserver.disconnect();reelsObserver=new IntersectionObserver(entries=>{if(reelObserverLocked)return;let best=null;for(const e of entries){if(!e.isIntersecting)continue;if(!best||e.intersectionRatio>best.intersectionRatio)best=e}if(best&&best.intersectionRatio>=.58){const idx=Number(best.target.dataset.index);if(Number.isFinite(idx)&&idx!==activeIndex)activateSlide(idx)}},{root:$('#reelsStream'),threshold:[.58,.72,.88]});$$('#reelsStream .reel-slide').forEach(s=>reelsObserver.observe(s))}
function stopPlayback(){playSeq++;if(hls){try{hls.destroy()}catch{}hls=null}if(activeVideo){try{activeVideo.pause();activeVideo.removeAttribute('src');activeVideo.load()}catch{}activeVideo=null}}
async function streamDiag(it){if(it.provider==='lookapo')return 'منبع ویدیوی لوکاپو در دسترس نیست';try{const j=await api({action:'stream_debug',provider:it.provider||'chibebin',id:it.id});const b=[];if(j.source_status)b.push('HTTP '+j.source_status);if(j.source_type)b.push(j.source_type);if(j.error)b.push(j.error);return b.join(' · ')}catch(e){return e.message||'diagnostic failed'}}
async function activateSlide(index,force=false){if(!items[index])return;if(index===activeIndex&&!force)return;const it=items[index],seq=++playSeq;stopPlayback();playSeq=seq;activeIndex=index;rememberLastViewed(uidOf(it));const slide=$(`#reelsStream .reel-slide[data-index="${index}"]`);if(!slide)return;$$('#reelsStream .reel-slide').forEach(s=>{s.classList.remove('active','failed','playing','has-frame','loading','buffering','pause-feedback');s.classList.add('paused')});slide.classList.add('active','loading');const v=slide.querySelector('.reel-video');activeVideo=v;v.muted=muted;v.volume=1;updateSoundIcons();hydrateMeta(index);let src=it.stream||(`${API}?`+new URLSearchParams({action:'stream',provider:it.provider||'chibebin',id:it.id}));
const markFrame=()=>{if(seq!==playSeq)return;slide.classList.add('has-frame');if(!v.paused)slide.classList.add('playing');slide.classList.remove('buffering','loading')};const sync=()=>{if(seq!==playSeq)return;if(v.paused){slide.classList.remove('playing','buffering');slide.classList.add('paused')}else{slide.classList.remove('paused');slide.classList.add('playing')}};const buffering=()=>{if(seq!==playSeq||v.paused)return;slide.classList.add('buffering','loading')};const ready=()=>{if(seq!==playSeq)return;slide.classList.remove('buffering');if(slide.classList.contains('has-frame'))slide.classList.remove('loading')};const start=()=>{if(seq!==playSeq)return;v.play().catch(sync)};v.onloadeddata=markFrame;v.onplaying=()=>{markFrame();sync()};v.onplay=sync;v.onpause=sync;v.onwaiting=buffering;v.onstalled=buffering;v.oncanplay=ready;v.oncanplaythrough=ready;v.ontimeupdate=()=>{if(v.currentTime>0&&!slide.classList.contains('has-frame'))markFrame();const d=v.duration||0,p=d>0?Math.min(100,(v.currentTime/d)*100):0;const bar=slide.querySelector('.reel-progress span');if(bar)bar.style.width=p+'%'};v.onended=()=>{const n=$(`#reelsStream .reel-slide[data-index="${index+1}"]`);if(n)n.scrollIntoView({behavior:'smooth',block:'start'})};const fail=async label=>{if(seq!==playSeq)return;slide.classList.remove('loading','buffering');slide.classList.add('failed');slide.querySelector('[data-open-native]')?.classList.add('is-visible');const diag=await streamDiag(it);const out=slide.querySelector('[data-reel-error]');if(out)out.textContent='خطا در پخش · '+label+(diag?' · '+diag:'')};
if(it.provider==='lookapo'){try{const post=await loadLookapoPost(it.id);if(seq!==playSeq)return;src=post.video_url;if(!/^https:\/\//i.test(src||'')){fail('آدرس ویدیو پیدا نشد');return;}await hydrateLookapo(index);}catch(e){if(seq===playSeq)fail(e.message||'خطا در دریافت ویدیو');return;}}
if(it.media_kind==='file'){v.src=src;v.addEventListener('loadedmetadata',start,{once:true});v.addEventListener('error',()=>fail('Video'),{once:true});v.load();return}
if(window.Hls&&Hls.isSupported()){hls=new Hls({enableWorker:true,lowLatencyMode:false,startFragPrefetch:true,maxBufferLength:18,maxMaxBufferLength:30,xhrSetup:x=>{x.withCredentials=true}});hls.loadSource(src);hls.attachMedia(v);hls.on(Hls.Events.MANIFEST_PARSED,start);hls.on(Hls.Events.FRAG_BUFFERED,()=>{if(seq===playSeq&&v.readyState>=2)markFrame()});hls.on(Hls.Events.ERROR,(ev,data)=>{if(seq!==playSeq||!data?.fatal)return;fail(data.details||data.type||'HLS')})}else if(v.canPlayType('application/vnd.apple.mpegurl')){v.src=src;v.addEventListener('loadedmetadata',start,{once:true});v.addEventListener('error',()=>fail('Native HLS'),{once:true})}else fail('HLS unsupported')}
function updateSoundIcons(){$$('#reelsStream [data-sound]').forEach(b=>{b.classList.toggle('muted',muted);b.setAttribute('aria-label',muted?'روشن کردن صدا':'بی‌صدا کردن')});if(activeVideo)activeVideo.muted=muted}function toggleSound(){muted=!muted;updateSoundIcons();if(activeVideo&&!muted)activeVideo.play().catch(()=>{})}
function togglePlayback(slide){if(!slide)return;const v=slide.querySelector('.reel-video');if(!v||v!==activeVideo)return;if(v.paused){slide.classList.remove('pause-feedback');v.play().catch(()=>{})}else{slide.classList.add('pause-feedback');v.pause();clearTimeout(slide._pauseFeedbackTimer);slide._pauseFeedbackTimer=setTimeout(()=>slide.classList.remove('pause-feedback'),260)}}
async function movieMeta(provider,id){provider=provider||'chibebin';id=String(id||'');if(!id)return null;const key=provider+':'+id;if(movieCache.has(key))return movieCache.get(key);const p=api({action:'movie',provider,id}).then(j=>j.movie).catch(e=>{movieCache.delete(key);throw e});movieCache.set(key,p);return p}
const lookapoPostCache=new Map();
async function loadLookapoPost(id){id=String(id||'');if(!lookapoPostCache.has(id)){lookapoPostCache.set(id,api({action:'lookapo_post',id}).then(j=>j.item).catch(e=>{lookapoPostCache.delete(id);throw e}));}return lookapoPostCache.get(id);}
document.addEventListener('error',e=>{const img=e.target;if(!(img instanceof HTMLImageElement)||!img.hasAttribute('data-lookapo-img'))return;const fallback=img.dataset.fallback||'';if(img.dataset.fallbackTried!=='1'&&fallback&&img.src!==fallback){img.dataset.fallbackTried='1';img.src=fallback;return;}img.style.visibility='hidden';},true);
function lookapoFilmsMarkup(post){const ids=(post.titles||[]).filter(x=>x.title_en||x.title_fa);if(!ids.length)return '<span class="lookapo-reel-empty">این ویدیو هنوز فیلم قابل جست‌وجویی ندارد.</span>';return ids.map(m=>{const q=(m.title_en||m.title_fa||'').trim(),img=(m.poster||'').trim(),fallback=m.id&&post.id?(`${API}?`+new URLSearchParams({action:'lookapo_image',kind:'movie',id:post.id,title_id:m.id})):'';return `<a class="lookapo-reel-film" href="/search?q=${encodeURIComponent(q)}" target="_blank" rel="noopener" title="جست‌وجوی ${esc(q)} در آرشیو"><span class="lookapo-reel-art">${img?`<img src="${esc(img)}" data-lookapo-img data-fallback="${esc(fallback)}" referrerpolicy="no-referrer" loading="lazy" decoding="async" alt="پوستر ${esc(m.title_fa||q)}">`:''}</span><span class="lookapo-reel-caption">${esc(m.title_fa||q)}</span>${m.year?`<small class="lookapo-reel-year">${esc(m.year)}</small>`:''}</a>`}).join('');}
async function hydrateLookapo(index){const it=items[index],slide=$(`#reelsStream .reel-slide[data-index="${index}"]`);if(!it||!slide)return null;const post=await loadLookapoPost(it.id);slide.querySelector('[data-title]').textContent=post.title||it.title||'';slide.querySelector('[data-subtitle]').textContent=post.blogger||it.blogger||'';const first=(post.titles||[]).find(t=>t.title_en||t.title_fa),search=slide.querySelector('[data-archive-search]');if(first&&search){search.disabled=false;search.dataset.query=first.title_en||first.title_fa;}return post;}
async function hydrateMeta(index){const it=items[index],slide=$(`#reelsStream .reel-slide[data-index="${index}"]`);if(!it||!slide)return;if(it.provider==='lookapo'){try{await hydrateLookapo(index)}catch{}return;}if(it.title){slide.querySelector('[data-title]').textContent=it.title;if(it.title_en)slide.querySelector('[data-subtitle]').textContent=it.title_en;if(it.plot)slide.querySelector('[data-plot]').textContent=it.plot}try{const m=await movieMeta(it.provider||'chibebin',it.movie_id||it.id);if(!m)return;const title=[m.title_fa,m.title_en].filter(Boolean).join(' · ')||it.title||('سکانس #'+it.id);slide.querySelector('[data-title]').textContent=title;slide.querySelector('[data-subtitle]').textContent=m.title_en||it.title_en||'';const plot=(m.plot||it.plot||'').trim(),p=slide.querySelector('[data-plot]'),more=slide.querySelector('[data-more]');p.textContent=plot;if(plot.length>105)more.classList.add('show');const s=slide.querySelector('[data-archive-search]'),q=(m.title_en||it.title_en||'').trim();if(s&&q){s.disabled=false;s.dataset.query=q}}catch{}}
function pauseForDetail(){detailPaused=!!(activeVideo&&!activeVideo.paused);if(activeVideo)activeVideo.pause()}function closeDetails(){$('#detailModal').classList.remove('show');$('#detailModal').setAttribute('aria-hidden','true');if(detailPaused&&activeVideo)activeVideo.play().catch(()=>{});detailPaused=false}
async function details(slide){if(!slide)return;const provider=slide.dataset.provider||'chibebin',id=slide.dataset.movie||slide.dataset.id;if(!id)return;if(provider==='lookapo'){pauseForDetail();$('#detailModal').classList.add('show');$('#detailModal').setAttribute('aria-hidden','false');$('#detailBody').innerHTML='<div class="detail-empty">در حال بارگذاری فیلم‌های معرفی‌شده…</div>';try{const post=await loadLookapoPost(id);$('#detailBody').innerHTML=`<h2>${esc(post.title||'فیلم‌های معرفی‌شده')}</h2><div class="lookapo-detail-films">${lookapoFilmsMarkup(post)}</div>`;}catch(e){$('#detailBody').textContent=e.message||'دریافت فیلم‌ها ناموفق بود';}return;}pauseForDetail();$('#detailModal').classList.add('show');$('#detailModal').setAttribute('aria-hidden','false');$('#detailBody').innerHTML='<div class="detail-empty">در حال دریافت اطلاعات…</div>';try{const m=await movieMeta(provider,id);const chips=[m.year?`سال ${m.year}`:'',m.imdb!=null?`IMDb ${m.imdb}/10`:'',m.user_rating!=null?`امتیاز ${m.user_rating}${m.votes!=null?' · '+m.votes+' رای':''}`:'',m.country||'',...(m.genres||[])].filter(Boolean),poster=(m.poster||'').trim(),posterHtml=poster?`<img class="detail-poster" src="${esc(poster)}" alt="">`:'',topClass=poster?'detail-top':'detail-top no-poster';$('#detailBody').innerHTML=`<div class="${topClass}">${posterHtml}<div><h2>${esc(m.title_fa||'بدون عنوان')}</h2><div class="detail-en">${esc(m.title_en||'')}</div><div class="chips">${chips.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}</div>${m.title_en?`<a class="detail-archive-link" href="/search?q=${encodeURIComponent(m.title_en)}" target="_blank" rel="noopener">${ICON_SEARCH}<span>جستجو در آرشیو</span></a>`:''}</div></div>${m.director?`<div class="detail-row"><b>کارگردان:</b> ${esc(m.director)}</div>`:''}${m.actors?.length?`<div class="detail-row"><b>بازیگران:</b> ${esc(m.actors.join('، '))}</div>`:''}${m.plot?`<div class="detail-plot"><b>خلاصه داستان</b><br>${esc(m.plot)}</div>`:''}`}catch(e){$('#detailBody').innerHTML=`<div class="detail-empty">${esc(e.message)}</div>`}}
document.addEventListener('click',e=>{const tileEl=e.target.closest('.explorer-card');if(tileEl){openReelsByUid(tileEl.dataset.uid);return}if(e.target.closest('[data-reel-close]')){closeReels();return}if(e.target.closest('[data-sound]')){toggleSound();return}const play=e.target.closest('[data-play-toggle]');if(play){togglePlayback(play.closest('.reel-slide'));return}const media=e.target.closest('.reel-video,.reel-poster');if(media&&$('#reelsModal').classList.contains('show')){togglePlayback(media.closest('.reel-slide'));return}const retry=e.target.closest('[data-retry]');if(retry){const s=retry.closest('.reel-slide');activateSlide(Number(s.dataset.index),true);return}const info=e.target.closest('[data-info]');if(info){details(info.closest('.reel-slide'));return}const search=e.target.closest('[data-archive-search]');if(search&&!search.disabled){const q=(search.dataset.query||'').trim();if(q)window.open('/search?q='+encodeURIComponent(q),'_blank','noopener');return}const more=e.target.closest('[data-more]');if(more){const p=more.parentElement.querySelector('[data-plot]');p.classList.toggle('expanded');more.textContent=p.classList.contains('expanded')?'کمتر':'بیشتر';return}if(e.target.closest('[data-detail-close]')||e.target.id==='detailModal'){closeDetails();return}});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if($('#detailModal').classList.contains('show'))closeDetails();else if($('#reelsModal').classList.contains('show'))closeReels()}if(!$('#reelsModal').classList.contains('show'))return;if(e.key==='ArrowDown'){e.preventDefault();const n=$(`#reelsStream .reel-slide[data-index="${activeIndex+1}"]`);if(n)n.scrollIntoView({behavior:'smooth'})}if(e.key==='ArrowUp'){e.preventDefault();const p=$(`#reelsStream .reel-slide[data-index="${activeIndex-1}"]`);if(p)p.scrollIntoView({behavior:'smooth'})}});
setupManualPaging();loadMore();

// V18: self-contained video search. Neither Enter nor the search button navigates to a different Android screen.
(function installBankmovieAppExplore(){
 const input=document.getElementById('bmAppExplorerSearch');
 const reset=document.getElementById('bmAppExplorerClear');
 const action=document.getElementById('bmAppExplorerSearchAction');
 const counter=document.getElementById('bmAppExplorerCount');
 if(!input)return;
 const normalize=s=>String(s||'').toLocaleLowerCase().normalize('NFKC')
   .replace(/[يى]/g,'ی').replace(/ك/g,'ک').replace(/[\u064b-\u065f]/g,'')
   .replace(/\s+/g,' ').trim();
 function apply(){
   const q=normalize(input.value);let count=0;
   document.querySelectorAll('#grid .explorer-card').forEach(card=>{
     const it=items[Number(card.dataset.index)];
     const hay=[it?.title,it?.title_en,it?.plot,it?.blogger].map(normalize).join(' ');
     const hit=!!it&&(!q||hay.includes(q));
     card.hidden=!hit;if(hit)count++;
   });
   if(counter)counter.textContent=q
     ? (count?count+' نتیجه در ویدیوهای بارگذاری‌شده':'نتیجه‌ای پیدا نشد؛ می‌توانی ۲۰ مورد دیگر نمایش بدهی.')
     : (count?'نمایش '+count+' ویدیو':'در حال دریافت ویدیوها…');
 }
 input.addEventListener('input',apply);
 input.addEventListener('keydown',event=>{
   if(event.key==='Enter'){
     event.preventDefault();event.stopPropagation();apply();input.blur();
   }
 });
 action?.addEventListener('click',()=>{apply();input.blur()});
 reset?.addEventListener('click',()=>{input.value='';apply();input.focus()});
 const grid=document.getElementById('grid');
 if(grid)new MutationObserver(apply).observe(grid,{childList:true});
 // Native fallback player never launches a browser tab.
 document.addEventListener('click',event=>{
   const button=event.target.closest('[data-open-native]');if(!button)return;
   const slide=button.closest('.reel-slide');if(!slide)return;
   const it=items[Number(slide.dataset.index)];if(!it)return;
   const src=it.stream||('/api_explorer.php?action=stream&provider='+encodeURIComponent(it.provider||'chibebin')+'&id='+encodeURIComponent(it.id));
   const launch=url=>{if(!url)return;try{activeVideo?.pause()}catch(_){};window.BankMovieApp?.nativePlayback?.(new URL(url,location.href).href,it.title||'اکسپلور');};
   if(it.provider==='lookapo')loadLookapoPost(it.id).then(p=>launch(p.video_url)).catch(()=>{});
   else launch(src);
 });
 // Archive search remains available deliberately ONLY from the film detail controls.
 document.addEventListener('click',event=>{
   const searchButton=event.target.closest('[data-archive-search]');
   if(searchButton&&!searchButton.disabled){
     const q=(searchButton.dataset.query||'').trim();
     if(q&&window.BankMovieApp?.searchArchive){event.stopImmediatePropagation();event.preventDefault();window.BankMovieApp.searchArchive(q)}
   }
   const searchAnchor=event.target.closest('a[href*="/search?q="]');
   if(searchAnchor&&window.BankMovieApp?.searchArchive){
     try{const q=new URL(searchAnchor.href,location.href).searchParams.get('q');if(q){event.stopImmediatePropagation();event.preventDefault();window.BankMovieApp.searchArchive(q)}}catch(_){}
   }
 },true);
 const oldOpen=window.open;
 window.open=(url,...args)=>{
   try{const u=new URL(url,location.href);if(u.pathname==='/search'&&u.searchParams.get('q')&&window.BankMovieApp?.searchArchive){window.BankMovieApp.searchArchive(u.searchParams.get('q'));return null;}}
   catch(_){}return oldOpen?.call(window,url,...args)||null;
 };
 apply();
})();

})();
