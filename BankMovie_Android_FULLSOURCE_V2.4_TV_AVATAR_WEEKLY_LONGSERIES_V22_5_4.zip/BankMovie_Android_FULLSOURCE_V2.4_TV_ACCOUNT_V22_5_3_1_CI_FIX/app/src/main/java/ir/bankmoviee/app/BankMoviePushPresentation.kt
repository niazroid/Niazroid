package ir.bankmoviee.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import org.json.JSONObject

/** V21 fields are optional: every legacy title/message/link notification stays valid. */
object BankMoviePushPresentation {
    fun allowed(context: Context, audience: String): Boolean {
        val logged = AccountSession.isLoggedIn(context)
        val user = AccountSession.user(context)
        val role = user.optString("role").trim().lowercase(java.util.Locale.US)
        val admin = logged && role in setOf("admin", "administrator")
        val vip = logged && (admin || role in setOf("vip", "premium", "special") ||
            user.optBoolean("is_vip", false) || user.optBoolean("vip_active", false) ||
            user.optString("is_vip") in setOf("1", "true") || user.optString("vip_active") in setOf("1", "true"))
        return when (audience.lowercase(java.util.Locale.US)) {
            "guest" -> !logged
            "member" -> logged
            "vip" -> vip
            "admin" -> admin
            else -> true
        }
    }
    fun safeUrl(value: String): String {
        return try {
            val parsed = Uri.parse(value.trim())
            if (parsed.scheme?.lowercase(java.util.Locale.US) in setOf("http", "https") && !parsed.host.isNullOrBlank()) value.trim() else ""
        } catch (_: Exception) { "" }
    }
    fun target(kind: String, link: String, label: String, url: String, secondLabel: String, secondUrl: String, iconSvg: String = "", imageUrl: String = ""): JSONObject {
        val first = safeUrl(url).ifBlank { safeUrl(link) }
        return JSONObject().apply {
            if (first.isNotBlank()) put("url", first)
            if (label.isNotBlank() && first.isNotBlank()) {
                put("cta_label", label.take(48)); put("cta_url", first)
            }
            val second=safeUrl(secondUrl)
            if (secondLabel.isNotBlank() && second.isNotBlank()) {
                put("secondary_label", secondLabel.take(48)); put("secondary_url", second)
            }
            if (iconSvg.startsWith("<svg") && iconSvg.length < 24000) put("icon_svg", iconSvg)
            val image = safeUrl(imageUrl)
            if (image.isNotBlank()) put("image_url", image)
            put("kind", kind.take(32))
        }
    }
    fun addActions(context: Context, builder: NotificationCompat.Builder, id: Long, target: JSONObject) {
        listOf("cta_label" to "cta_url", "secondary_label" to "secondary_url").forEachIndexed { index, keys ->
            val label=target.optString(keys.first)
            val url=safeUrl(target.optString(keys.second))
            if (label.isBlank() || url.isBlank()) return@forEachIndexed
            val intent=Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                putExtra("admin_push_tap",true)
                putExtra("admin_push_url",url)
            }
            val requestCode = (((id % 800000L) * 3L + index + 100000L) % Int.MAX_VALUE).toInt()
            val pending=PendingIntent.getActivity(context,requestCode,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            builder.addAction(R.drawable.ic_bankmovie_push, label.take(48), pending)
        }
    }
}
