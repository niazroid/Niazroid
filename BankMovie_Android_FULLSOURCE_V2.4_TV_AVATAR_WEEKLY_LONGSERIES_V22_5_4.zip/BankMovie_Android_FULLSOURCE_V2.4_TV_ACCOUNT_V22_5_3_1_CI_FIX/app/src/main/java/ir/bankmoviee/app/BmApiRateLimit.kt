package ir.bankmoviee.app

import android.content.Context
import android.os.SystemClock
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.IOException
import kotlin.math.max

/**
 * V22.2: HTTP 429 is an intentional server policy, never a network failure.
 * Honour the server Retry-After for the current process, preserve the real
 * content-open quota from the server and show one watchlist-style glass notice.
 * Background API fetches are never charged to the user-facing action quota.
 * Content details and signed explicit user actions share that 60-second limit.
 */
object BmApiRateLimit {
    private const val DEFAULT_WAIT_SECONDS = 60
    private const val MAX_WAIT_SECONDS = 600
    private const val NOTICE_INTERVAL_MS = 4_500L
    private const val FRIENDLY = "لطفاً کمی آرام‌تر!"
    @Volatile private var blockedUntilMs: Long = 0L
    private var lastNoticeMs: Long = -NOTICE_INTERVAL_MS

    /** Read the real server delay; the JSON field also covers proxies that strip headers. */
    internal fun retrySeconds(header: String?, response: String?): Int {
        val secondsFromHeader = header?.trim()?.toIntOrNull()?.takeIf { it > 0 }
        val secondsFromBody = runCatching {
            val json = JSONObject(response.orEmpty())
            json.optInt("retry_after", json.optInt("retry_after_seconds", 0))
        }.getOrDefault(0).takeIf { it > 0 }
        return (secondsFromHeader ?: secondsFromBody ?: DEFAULT_WAIT_SECONDS)
            .coerceIn(1, MAX_WAIT_SECONDS)
    }

    @Synchronized
    fun remainingSeconds(): Int {
        val rest = blockedUntilMs - SystemClock.elapsedRealtime()
        return if (rest <= 0L) 0 else ((rest + 999L) / 1_000L).toInt()
    }

    fun message(): String {
        val remaining = remainingSeconds()
        return if (remaining > 0) "$FRIENDLY تا $remaining ثانیه دیگر دوباره تلاش کنید." else
            "$FRIENDLY لطفاً یک دقیقه دیگر دوباره تلاش کنید."
    }

    /** Used by the API call sites on a REAL HTTP 429, not by local exceptions. */
    fun report(context: Context, retryAfterHeader: String?, responseBody: String?): String {
        val seconds = retrySeconds(retryAfterHeader, responseBody)
        val show: Boolean
        val left: Int
        synchronized(this) {
            val now = SystemClock.elapsedRealtime()
            blockedUntilMs = max(blockedUntilMs, now + seconds * 1_000L)
            left = ((blockedUntilMs - now + 999L) / 1_000L).toInt()
            show = now - lastNoticeMs >= NOTICE_INTERVAL_MS
            if (show) lastNoticeMs = now
        }
        if (show) BmNotice.showRateLimited(context) { remainingSeconds() }
        return "$FRIENDLY تا $left ثانیه دیگر دوباره تلاش کنید."
    }

    /** Keep unmetered background/API requests running even during quota cooldown. */
    fun isContentOpen(url: URL): Boolean {
        if (!url.path.contains("/v2/api/")) return false
        val query = url.query.orEmpty().split('&').associate { part ->
            val pos = part.indexOf('=')
            if (pos < 0) part.lowercase() to "" else part.substring(0, pos).lowercase() to part.substring(pos + 1)
        }
        val intent = query["bm_q_intent"].orEmpty()
        val endpoint = url.path.substringAfterLast('/').lowercase()
        val action = query["action"].orEmpty()
        if (endpoint == "app_api.php") {
            return (intent == "detail" && action == "detail") ||
                (intent == "collection" && action == "collection") ||
                (intent == "collections" && action == "collections") ||
                (intent == "section" && action == "section") ||
                (intent == "advanced_search" && action == "search")
        }
        if (endpoint == "api_discover.php") return intent == "discover"
        if (endpoint == "app_user_api.php") return intent == "watchlist_change" ||
            (action in setOf("login", "register", "avatar_update", "avatar_upload", "comment_add", "comment_reply"))
        return endpoint in setOf("api2.php", "api4.php", "api5.php", "api6.php", "archive1_live.php") &&
            intent in setOf("detail", "genre", "section", "advanced_search")
    }

    /** Stop only deliberate billable API calls during server-issued cooldown;
     * keep poster loads, background hydration, home feed and page scans working. */
    fun requireContentOpenAllowed(url: URL) {
        if (isContentOpen(url) && remainingSeconds() > 0) throw IOException(message())
    }

    /** Keep archive retries from turning an intentional limit into 'connection failed'. */
    fun isLimitMessage(message: String?): Boolean = message?.startsWith(FRIENDLY) == true

    /** Security throttling is different from a comment/watch-party specific 429. */
    fun isSecurityLimitResponse(json: JSONObject?, response: String, header: String?): Boolean {
        val code = json?.optString("error_code").orEmpty()
            .ifBlank { json?.optString("error").orEmpty() }
        if (code in setOf("per_device_rate_limited", "content_open_rate_limited", "user_action_rate_limited", "per_ip_rate_limited", "live_search_rate_limited",
                "registration_rate_limited", "config_rate_limited", "too_many_requests")) return true
        return header?.trim()?.toIntOrNull()?.let { it > 0 } == true &&
            (response.contains("per_device_rate_limited") || response.contains("too_many_requests"))
    }
}
