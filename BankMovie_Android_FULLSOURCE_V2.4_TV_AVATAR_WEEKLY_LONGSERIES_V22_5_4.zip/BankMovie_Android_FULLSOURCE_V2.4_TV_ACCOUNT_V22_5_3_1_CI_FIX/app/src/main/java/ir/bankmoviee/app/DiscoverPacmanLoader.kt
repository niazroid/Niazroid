package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.sin

/** A small native Pac-Man / dots loader inspired by the user-provided Uiverse sample.
 * Stops animating when hidden or detached; no WebView or external assets.
 */
internal class DiscoverPacmanLoader(context: Context, private val accent: Int) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arc = RectF()
    private var phase = 0f
    private val animator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1800L
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    fun start() { if (!animator.isStarted) animator.start() }
    fun stop() { if (animator.isStarted) animator.cancel() }
    override fun onDetachedFromWindow() { stop(); super.onDetachedFromWindow() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val scale = resources.displayMetrics.density
        val radius = 15f * scale
        val cy = height * .5f
        val start = 18f * scale
        val end = (width - 18f * scale).coerceAtLeast(start + radius * 2f)
        val travel = (end - start - radius * 2f).coerceAtLeast(1f)
        val move = if (phase < .5f) phase * 2f else (1f - phase) * 2f
        val cx = start + radius + move * travel
        paint.style = Paint.Style.FILL
        paint.color = accent
        val mouth = 12f + 25f * abs(sin(phase * Math.PI.toFloat() * 8f))
        arc.set(cx - radius, cy - radius, cx + radius, cy + radius)
        val facingRight = phase < .5f
        canvas.drawArc(arc, if (facingRight) mouth else 180f + mouth,
            360f - mouth * 2f, true, paint)
        val dots = 9
        val dotStart = start + radius * 2.3f
        val dotSpacing = (end - dotStart) / (dots - 1).coerceAtLeast(1)
        repeat(dots) { i ->
            val x = dotStart + i * dotSpacing
            if (abs(x - cx) < radius * 1.5f) return@repeat
            paint.color = if ((i + (phase * 10).toInt()) % 3 == 0)
                Color.rgb(247, 78, 99) else Color.rgb(75, 165, 245)
            canvas.drawCircle(x, cy, 3.6f * scale, paint)
        }
    }
}
