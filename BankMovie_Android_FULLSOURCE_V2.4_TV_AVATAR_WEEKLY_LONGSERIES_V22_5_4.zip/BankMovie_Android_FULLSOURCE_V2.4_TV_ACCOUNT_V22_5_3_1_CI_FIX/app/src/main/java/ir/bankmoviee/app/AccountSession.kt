package ir.bankmoviee.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object AccountSession {
    private const val PREFS = "bankmovie_account"
    private const val KEY_TOKEN = "token"
    private const val KEY_USER = "user"
    private const val KEY_AUTH_BACKGROUND = "auth_background"
    private const val KEY_REMOVED_WATCHLIST = "removed_watchlist_keys"
    private const val KEY_LAST_SYNC = "last_watchlist_sync"
    private const val KEY_WATCHLIST_DIRTY = "watchlist_pending_local_changes"
    private const val KEY_ADDED_WATCHLIST = "pending_added_watchlist_keys"
    private const val KEY_STATS = "stats"
    private const val KEY_FEATURES = "features"
    private const val KEY_VIP = "vip"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun token(context: Context): String = prefs(context).getString(KEY_TOKEN, "") ?: ""

    fun isLoggedIn(context: Context): Boolean = token(context).isNotBlank()

    fun user(context: Context): JSONObject {
        val raw = prefs(context).getString(KEY_USER, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun saveAuth(context: Context, token: String, user: JSONObject, stats: JSONObject? = null) {
        val edit = prefs(context).edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_USER, user.toString())
        stats?.let { edit.putString(KEY_STATS, it.toString()) }
        edit.apply()
    }

    fun updateUser(context: Context, user: JSONObject) {
        prefs(context).edit().putString(KEY_USER, user.toString()).apply()
    }

    fun stats(context: Context): JSONObject {
        val raw = prefs(context).getString(KEY_STATS, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun updateStats(context: Context, stats: JSONObject) {
        prefs(context).edit().putString(KEY_STATS, stats.toString()).apply()
    }

    fun unreadNotifications(context: Context): Int = stats(context).optInt("notifications_unread", 0).coerceAtLeast(0)

    fun features(context: Context): JSONObject {
        val raw = prefs(context).getString(KEY_FEATURES, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun updateFeatures(context: Context, features: JSONObject) {
        prefs(context).edit().putString(KEY_FEATURES, features.toString()).apply()
    }

    fun vip(context: Context): JSONObject {
        val raw = prefs(context).getString(KEY_VIP, "{}") ?: "{}"
        return runCatching { JSONObject(raw) }.getOrElse { JSONObject() }
    }

    fun updateVip(context: Context, vip: JSONObject) {
        prefs(context).edit().putString(KEY_VIP, vip.toString()).apply()
    }

    fun registrationEnabled(context: Context): Boolean = features(context).optBoolean("registration_enabled", true)
    fun loginEnabled(context: Context): Boolean = features(context).optBoolean("login_enabled", true)
    fun commentsEnabled(context: Context): Boolean = features(context).optBoolean("comments_enabled", true)
    fun commentRepliesEnabled(context: Context): Boolean = features(context).optBoolean("comment_replies_enabled", true)
    fun commentVotesEnabled(context: Context): Boolean = features(context).optBoolean("comment_votes_enabled", true)
    fun commentReportsEnabled(context: Context): Boolean = features(context).optBoolean("comment_reports_enabled", true)
    fun commentSpoilerEnabled(context: Context): Boolean = features(context).optBoolean("comment_spoiler_enabled", true)
    fun commentEditMinutes(context: Context): Int = features(context).optInt("comment_edit_minutes", 10).coerceIn(0, 1440)
    fun notificationCenterEnabled(context: Context): Boolean = features(context).optBoolean("notification_center_enabled", true)
    fun internalDownloaderEnabled(context: Context): Boolean = features(context).optBoolean("internal_downloader_enabled", true)
    fun multipartDownloadEnabled(context: Context): Boolean = features(context).optBoolean("multipart_download_enabled", true)
    fun downloadPathSelectionEnabled(context: Context): Boolean = features(context).optBoolean("download_path_selection_enabled", true)
    fun advancedSearchEnabled(context: Context): Boolean = features(context).optBoolean("advanced_search_enabled", true)
    fun categoriesEnabled(context: Context): Boolean = features(context).optBoolean("categories_enabled", true)
    fun watchlistEnabled(context: Context): Boolean = features(context).optBoolean("watchlist_enabled", true)
    fun continueWatchingEnabled(context: Context): Boolean = features(context).optBoolean("continue_watching_enabled", true)
    fun tvQuickMenuEnabled(context: Context): Boolean = features(context).optBoolean("tv_quick_menu_enabled", true)
    fun downloadLimit(context: Context): Int = features(context).optInt("download_limit", 2).coerceIn(1, 4)
    fun downloadRetryCount(context: Context): Int = features(context).optInt("download_retry_count", 4).coerceIn(0, 20)
    fun downloadRetryDelaySeconds(context: Context): Int = features(context).optInt("download_retry_delay_seconds", 8).coerceIn(2, 300)
    fun downloadMinFreeMb(context: Context): Int = features(context).optInt("download_min_free_mb", 256).coerceIn(32, 8192)
    fun multipartParts(context: Context): Int = features(context).optInt("multipart_parts", 4).coerceIn(2, 6)

    fun clear(context: Context) {
        prefs(context).edit()
            .remove(KEY_TOKEN)
            .remove(KEY_USER)
            .remove(KEY_REMOVED_WATCHLIST)
            .remove(KEY_LAST_SYNC)
            .remove(KEY_WATCHLIST_DIRTY)
            .remove(KEY_ADDED_WATCHLIST)
            .remove(KEY_STATS)
            .apply()
    }

    fun username(context: Context): String = user(context).optString("username")

    fun email(context: Context): String = user(context).optString("email")

    fun authBackground(context: Context): String = prefs(context).getString(KEY_AUTH_BACKGROUND, "") ?: ""

    fun setAuthBackground(context: Context, url: String) {
        if (url.isNotBlank()) prefs(context).edit().putString(KEY_AUTH_BACKGROUND, url).apply()
    }

    fun removedWatchlistKeys(context: Context): MutableSet<String> {
        val raw = prefs(context).getString(KEY_REMOVED_WATCHLIST, "[]") ?: "[]"
        val array = runCatching { JSONArray(raw) }.getOrElse { JSONArray() }
        val result = linkedSetOf<String>()
        for (i in 0 until array.length()) {
            array.optString(i).takeIf { it.isNotBlank() }?.let(result::add)
        }
        return result
    }

    fun markWatchlistAdded(context: Context, storageKey: String) {
        markWatchlistDirty(context)
        val keys = removedWatchlistKeys(context)
        if (keys.remove(storageKey)) saveRemovedWatchlistKeys(context, keys)
        val added = pendingAddedWatchlistKeys(context)
        added.add(storageKey)
        savePendingAddedWatchlistKeys(context, added)
    }

    fun markWatchlistRemoved(context: Context, storageKey: String) {
        markWatchlistDirty(context)
        val added = pendingAddedWatchlistKeys(context)
        if (added.remove(storageKey)) savePendingAddedWatchlistKeys(context, added)
        val keys = removedWatchlistKeys(context)
        keys.add(storageKey)
        saveRemovedWatchlistKeys(context, keys)
    }

    fun clearRemovedWatchlistKeys(context: Context) {
        prefs(context).edit().remove(KEY_REMOVED_WATCHLIST).apply()
    }

    private fun saveRemovedWatchlistKeys(context: Context, keys: Set<String>) {
        val array = JSONArray()
        keys.forEach(array::put)
        prefs(context).edit().putString(KEY_REMOVED_WATCHLIST, array.toString()).apply()
    }

    fun pendingAddedWatchlistKeys(context: Context): MutableSet<String> {
        val arr = runCatching { JSONArray(prefs(context).getString(KEY_ADDED_WATCHLIST, "[]") ?: "[]") }
            .getOrElse { JSONArray() }
        return (0 until arr.length()).map { arr.optString(it) }.filter { it.isNotBlank() }.toMutableSet()
    }

    private fun savePendingAddedWatchlistKeys(context: Context, keys: Set<String>) {
        val arr = JSONArray()
        keys.forEach(arr::put)
        prefs(context).edit().putString(KEY_ADDED_WATCHLIST, arr.toString()).apply()
    }

    fun discardPendingWatchlistAddition(context: Context, storageKey: String) {
        val added = pendingAddedWatchlistKeys(context)
        if (added.remove(storageKey)) savePendingAddedWatchlistKeys(context, added)
        if (added.isEmpty() && removedWatchlistKeys(context).isEmpty()) clearWatchlistDirty(context)
    }

    fun clearPendingWatchlistAdditions(context: Context) {
        prefs(context).edit().remove(KEY_ADDED_WATCHLIST).apply()
    }

    fun watchlistDirty(context: Context): Boolean =
        prefs(context).getBoolean(KEY_WATCHLIST_DIRTY, false) ||
            removedWatchlistKeys(context).isNotEmpty() || pendingAddedWatchlistKeys(context).isNotEmpty()

    fun markWatchlistDirty(context: Context) {
        prefs(context).edit().putBoolean(KEY_WATCHLIST_DIRTY, true).apply()
    }

    fun clearWatchlistDirty(context: Context) {
        prefs(context).edit().putBoolean(KEY_WATCHLIST_DIRTY, false).apply()
    }

    fun lastWatchlistSync(context: Context): Long = prefs(context).getLong(KEY_LAST_SYNC, 0L)

    fun markWatchlistSynced(context: Context) {
        prefs(context).edit().putLong(KEY_LAST_SYNC, System.currentTimeMillis()).apply()
    }
}
