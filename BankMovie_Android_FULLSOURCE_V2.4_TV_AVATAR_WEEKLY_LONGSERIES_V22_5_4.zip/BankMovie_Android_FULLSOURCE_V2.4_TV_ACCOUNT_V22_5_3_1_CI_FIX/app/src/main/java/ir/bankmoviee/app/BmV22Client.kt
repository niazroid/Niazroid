package ir.bankmoviee.app

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.Signature
import java.io.IOException
import java.security.spec.ECGenParameterSpec
import java.util.UUID

/**
 * BankMovie V22: no pre-shared HMAC key in the app.
 * The server signs 30-minute access tokens; a per-install Android Keystore
 * P-256 key signs EACH API request so a stolen access token alone is insufficient.
 * Android Keystore is an Android API, not a Google Play Services dependency.
 * On faulty Android TV Keystore implementations, an ephemeral in-memory EC
 * key is used for the current process only. The server STILL verifies every
 * signed request; no secret or private key is persisted in this fallback.
 */
object BmV22Client {
    private const val PREFS = "bm_v22_proof"
    private const val ALIAS = "bankmovie_v22_ec_proof"
    private val protectedScripts = setOf(
        "app_api.php", "app_user_api.php", "app_home_feed.php", "app_config.php",
        "api4.php", "api5.php", "api6.php", "archive1_live.php", "api_discover.php", "api_boxoffice.php", "api2.php", "api_explorer.php"
    )
    private val cache = mutableMapOf<String, Pair<String, Long>>()
    private val random = SecureRandom()
    private var installationKey: KeyPair? = null
    private var keystoreUnavailable = false
    private var usingSoftwareProof = false

    fun urlForApi(raw: String): String {
        val u = runCatching { URL(raw) }.getOrNull() ?: return raw
        if (!u.protocol.equals("https", true)) return raw
        val file = u.path.substringAfterLast('/').lowercase()
        if (file !in protectedScripts) return raw
        if (u.path.contains("/v2/api/")) return raw
        // Keep the exact query; only the path is migrated.
        val prefix = "${u.protocol}://${u.authority}"
        val query = if (u.query.isNullOrEmpty()) "" else "?${u.query}"
        return "$prefix/v2/api/$file$query"
    }

    private fun b64(raw: ByteArray): String = Base64.encodeToString(raw, Base64.NO_WRAP or Base64.URL_SAFE or Base64.NO_PADDING)
    private fun sha256(bytes: ByteArray): String = MessageDigest.getInstance("SHA-256").digest(bytes)
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }
    private fun hexRandom(): String = ByteArray(16).also { random.nextBytes(it) }
        .joinToString("") { "%02x".format(it.toInt() and 0xff) }

    /** Verify real sign + verify, not merely KeyPairGenerator success: broken TV
     * vendors may generate a keystore key but fail at first use. */
    private fun signedBy(pair: KeyPair, data: ByteArray): String {
        val signer = Signature.getInstance("SHA256withECDSA")
        signer.initSign(pair.private)
        signer.update(data)
        return b64(signer.sign())
    }

    private fun keyWorks(pair: KeyPair): Boolean = runCatching {
        val probe = "BMV22-TV-KEYSTORE-PROBE".toByteArray(Charsets.UTF_8)
        val decoded = Base64.decode(signedBy(pair, probe), Base64.URL_SAFE or Base64.NO_PADDING or Base64.NO_WRAP)
        val verifier = Signature.getInstance("SHA256withECDSA")
        verifier.initVerify(pair.public)
        verifier.update(probe)
        verifier.verify(decoded)
    }.getOrDefault(false)

    @Synchronized
    private fun keyPair(): KeyPair {
        installationKey?.let { return it }
        // Android 6+ has Keystore without requiring Google Play Services. Some
        // low-cost/older TV boxes ship buggy providers; do NOT crash or disable
        // API proof when their Keystore implementation fails.
        if (!keystoreUnavailable) {
            val backed = runCatching {
                val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
                val existing = (store.getKey(ALIAS, null) as? java.security.PrivateKey)?.let { priv ->
                    store.getCertificate(ALIAS)?.publicKey?.let { pub -> KeyPair(pub, priv) }
                }
                existing ?: run {
                    val generator = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
                    val spec = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                        .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                        .setDigests(KeyProperties.DIGEST_SHA256)
                        .setUserAuthenticationRequired(false)
                        .build()
                    generator.initialize(spec)
                    generator.generateKeyPair()
                }
            }.getOrNull()
            if (backed != null && keyWorks(backed)) {
                usingSoftwareProof = false
                return backed.also { installationKey = it }
            }
            keystoreUnavailable = true
        }
        // Compatibility fallback: a STANDARD software P-256 key, created in
        // memory each process. No private key is written to SharedPreferences
        // and no API endpoint permits an unsigned request. Rate-limiting remains
        // tied to the stored installation UUID on the server across restarts.
        val ephemeral = runCatching {
            KeyPairGenerator.getInstance("EC").apply {
                initialize(ECGenParameterSpec("secp256r1"), random)
            }.generateKeyPair()
        }.getOrElse { throw IOException("EC signing not available on this Android device", it) }
        if (!keyWorks(ephemeral)) throw IOException("This Android device cannot sign secure requests")
        usingSoftwareProof = true
        return ephemeral.also { installationKey = it }
    }

    /** A broken Keystore can also fail later (vendor provider crash). Recover
     * securely by rotating to a fresh in-memory key and invalidating old tokens. */
    @Synchronized
    private fun sign(bytes: ByteArray): String {
        val current = keyPair()
        return try {
            signedBy(current, bytes)
        } catch (failed: Exception) {
            if (usingSoftwareProof) throw IOException("Secure request signing failed", failed)
            keystoreUnavailable = true
            installationKey = null
            cache.clear()
            signedBy(keyPair(), bytes)
        }
    }

    private fun deviceId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val existing = prefs.getString("device_id", null)
        if (!existing.isNullOrEmpty()) return existing
        val fresh = UUID.randomUUID().toString().lowercase()
        prefs.edit().putString("device_id", fresh).apply()
        return fresh
    }

    private fun requestToken(context: Context, endpoint: URL): Pair<String, Long> {
        val authUrl = URL("https://${endpoint.authority}/v2/api/auth.php")
        val device = deviceId(context)
        val ts = (System.currentTimeMillis() / 1000L).toString()
        val nonce = hexRandom()
        val proof = sign("BMV22-REGISTER|$device|$ts|$nonce".toByteArray(Charsets.UTF_8))
        // sign() may have fallen back after a late Keystore failure.
        val actualPublicKey = b64(keyPair().public.encoded)
        val payload = JSONObject().apply {
            put("device_id", device)
            put("public_key", actualPublicKey)
            put("timestamp", ts)
            put("nonce", nonce)
            put("proof", proof)
        }.toString().toByteArray(Charsets.UTF_8)
        val conn = authUrl.openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 7000
            conn.readTimeout = 9500
            conn.instanceFollowRedirects = false
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Accept", "application/json")
            conn.setFixedLengthStreamingMode(payload.size)
            conn.outputStream.use { it.write(payload) }
            val status = conn.responseCode
            if (status == 429) {
                val response = conn.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                throw java.io.IOException(BmApiRateLimit.report(context, conn.getHeaderField("Retry-After"), response))
            }
            if (status !in 200..299) throw java.io.IOException("Secure session unavailable ($status)")
            val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val reply = JSONObject(body)
            val token = reply.optString("access_token")
            val ttl = reply.optLong("expires_in", 0).coerceAtMost(1800)
            if (token.isBlank() || ttl < 60L) throw java.io.IOException("Invalid V22 session")
            return token to (System.currentTimeMillis() + ttl * 1000L)
        } finally { conn.disconnect() }
    }

    @Synchronized
    private fun token(context: Context, url: URL): String {
        val host = url.authority.lowercase()
        val now = System.currentTimeMillis()
        cache[host]?.takeIf { it.second - now > 90_000L }?.let { return it.first }
        val issued = requestToken(context, url)
        cache[host] = issued
        return issued.first
    }

    @Synchronized
    fun invalidate(url: URL) { cache.remove(url.authority.lowercase()) }

    fun attach(context: Context, conn: HttpURLConnection, url: URL, method: String = "GET", body: ByteArray = ByteArray(0)) {
        if (!url.protocol.equals("https", true)) throw java.io.IOException("V22 API requires HTTPS")
        if (!url.path.contains("/v2/api/")) return
        if (url.path.endsWith("/app_config.php") || url.path.endsWith("/status.php") || url.path.endsWith("/auth.php")) return
        if (url.path.substringAfterLast('/').lowercase() !in protectedScripts) return
        // A Keystore that fails mid-session triggers a new in-memory key. The
        // old token is bound to the old public key, so re-issue before sending.
        var access = token(context, url)
        val ts = (System.currentTimeMillis() / 1000L).toString()
        val nonce = hexRandom()
        val target = url.path + if (url.query.isNullOrBlank()) "" else "?${url.query}"
        val host = url.authority.lowercase()
        var proof = ""
        for (attempt in 0..1) {
            val canonical = "BMV22|${method.uppercase()}|$target|${sha256(body)}|${sha256(access.toByteArray(Charsets.UTF_8))}|$ts|$nonce"
            proof = sign(canonical.toByteArray(Charsets.UTF_8))
            if (cache[host]?.first == access) break
            if (attempt == 1) throw IOException("Secure session rotated during signing")
            access = token(context, url)
        }
        conn.setRequestProperty("X-BM-Access-Token", access)
        conn.setRequestProperty("X-BM-Proof-Ts", ts)
        conn.setRequestProperty("X-BM-Proof-Nonce", nonce)
        conn.setRequestProperty("X-BM-Proof", proof)
    }
}
