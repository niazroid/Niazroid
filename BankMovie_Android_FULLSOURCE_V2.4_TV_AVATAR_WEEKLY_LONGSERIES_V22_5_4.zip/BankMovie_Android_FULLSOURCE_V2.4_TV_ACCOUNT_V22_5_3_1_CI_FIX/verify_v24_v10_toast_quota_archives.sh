#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYCHK'
from pathlib import Path
from xml.etree import ElementTree
src=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
notice=Path('app/src/main/java/ir/bankmoviee/app/BmNotice.kt').read_text()
quota=Path('SITE_PATCH_V10/includes/watchlist_quota.php').read_text()
settings=Path('SITE_PATCH_V10/includes/site_content_control.php').read_text()
admin=Path('SITE_PATCH_V10/_lider/admin.php').read_text()
remote=Path('SITE_PATCH_V10/includes/remote_delivery_control.php').read_text()
site=Path('SITE_PATCH_V10/index.php').read_text()
movie=Path('SITE_PATCH_V10/movie.php').read_text()
assert 'watchlist_free_limit' in settings and "'default'=>100" in settings
assert 'bm_wl_free_limit()' in quota and 'bm_wl_require_room' in quota
assert 'if ($count >= bm_wl_free_limit())' in quota
assert 'bm_watchlist_limit_action' in admin and 'bm_archive_player_master_gate' in admin
assert "['archive1','archive2','archive3','archive4','archive5','archive6','archive7']" in remote
assert "array_intersect_key($settings['archives']" in remote
assert "in_array($bmAid, ['archive6','archive7'], true)" in site
assert 'bm-five-archive-compact-v10' in site
assert 'M20.6 3H3.4' in movie and 'تماشای تریلر' in movie
assert 'BmNotice.showAction(' in src and 'showWatchlistQuotaNotice(result)' in src
assert 'regularWatchlistLimit' not in src and 'AlertDialog.Builder(this)\n            .setTitle(t("ظرفیت واچ‌لیست' not in src
assert 'fun showAction(' in notice and 'onAction()' in notice
xml=ElementTree.parse('app/src/main/res/drawable/ic_trailer.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert xml.get(ns+'viewportWidth')=='24' and len(xml)>=3
assert any('M15,9L17,3' in (p.get(ns+'pathData') or '') for p in xml)
print('V10_SOURCE_AND_UI_VERIFY_OK')
PYCHK
for p in SITE_PATCH_V10/includes/*.php SITE_PATCH_V10/_lider/*.php SITE_PATCH_V10/*.php SITE_PATCH_V10/partials/*.php; do php -l "$p" >/dev/null; done
node --check SITE_PATCH_V10/assets/js/bm-watchlist-quota-v1.js
php -r 'function bm_site_get($key,$default){return $key==="watchlist_free_limit"?137:$default;} require "SITE_PATCH_V10/includes/watchlist_quota.php"; if(bm_wl_free_limit()!==137)exit(1); echo "DYNAMIC_QUOTA_137_OK\n";'
php -r 'function bm_site_get($key,$default){return $default;} require "SITE_PATCH_V10/includes/watchlist_quota.php"; if(bm_wl_free_limit()!==100)exit(1); echo "DEFAULT_QUOTA_100_OK\n";'
echo V10_SITE_AND_ANDROID_CHECKS_OK
