#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
bash verify_v7471_21_detail_year_hero_icon_weekly_player_light.sh
bash verify_v7471_25_2_mobile_header_safe_insets.sh
bash verify_v24_archive_hero_theme_mixer_v8.sh
bash verify_v20_glass_mirror_smartnext.sh
bash verify_v7471_source_zip.sh
printf 'BANKMOVIE_V20_1_LEGACY_GUARDS_OK\n'
