<?php
/** BankMovie Discover Studio v4 — authenticated-aware, strictly read-only JSON API. */
declare(strict_types=1);
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/site_content_control.php';
require_once __DIR__ . '/includes/bm_discover.php';
require_once __DIR__ . '/includes/public_assets.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Content-Type-Options: nosniff');
    header('Vary: Cookie', false);
}
function bmd_response(int $status, array $value): void {
    http_response_code($status);
    echo json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'GET') bmd_response(405,['ok'=>false,'error'=>'method_not_allowed']);
if (!bm_site_bool('discover_enabled', true)) bmd_response(404,['ok'=>false,'error'=>'feature_disabled']);
$currentUser=$currentUser??null;
if (!bm_archive_is_enabled('archive2') || !bm_archive_user_can_access('archive2', $currentUser)) {
    bmd_response(403, ['ok'=>false,'error'=>'archive_unavailable']);
}
// Conservative per-session API throttle. Works for anonymous visitors as well.
if (session_status() !== PHP_SESSION_ACTIVE) @session_start();
if (session_status()===PHP_SESSION_ACTIVE) {
    $limit=$_SESSION['bmd_rl']??['start'=>time(),'count'=>0];
    if (!is_array($limit) || time()-(int)($limit['start']??0)>=60) $limit=['start'=>time(),'count'=>0];
    $limit['count']=(int)($limit['count']??0)+1;
    $_SESSION['bmd_rl']=$limit;
    session_write_close();
    if ($limit['count']>60) bmd_response(429,['ok'=>false,'error'=>'too_many_requests']);
}
try {
    $mode=bmd_text($_GET['mode']??'mood',20);
    if ($mode==='catalog') bmd_response(200,['ok'=>true,'data'=>bmd_catalog($pdo)]);
    if ($mode==='explorer_item') bmd_response(200,['ok'=>true,'data'=>bmd_discover_explorer_item($pdo,bmd_text($_GET['key']??'',30))]);
    if ($mode==='explorer') bmd_response(200,['ok'=>true,'data'=>bmd_discover_explorer($pdo)]);
    if ($mode==='decade') bmd_response(200,['ok'=>true,'data'=>bmd_decade_results($pdo,$_GET)]);
    if ($mode==='category') bmd_response(200,['ok'=>true,'data'=>bmd_discover_category_results($pdo,$_GET)]);
    if ($mode==='featured_collections') bmd_response(200,['ok'=>true,'data'=>['items'=>bmd_featured_collections($pdo,17)]]);
    if ($mode==='collections') bmd_response(200,['ok'=>true,'data'=>['items'=>bmd_collections($pdo,8)]]);
    if ($mode==='lookup') bmd_response(200,['ok'=>true,'data'=>['items'=>bmd_lookup($pdo,bmd_text($_GET['q']??'',75))]]);
    $input=$_GET;
    foreach (['person1','person2'] as $key) {
        if (isset($input[$key]) && !is_array($input[$key])) $input[$key]=[];
    }
    $result=bmd_recommend($pdo,$input,(int)($currentUser['id']??0));
    bmd_response(200,['ok'=>true,'data'=>$result]);
} catch (Throwable $e) {
    error_log('BM Discover API: '.$e->getMessage());
    bmd_response(503,['ok'=>false,'error'=>'temporarily_unavailable']);
}
