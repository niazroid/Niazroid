#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MAIN=app/src/main/java/ir/bankmoviee/app/MainActivity.kt
ACCOUNT=app/src/main/java/ir/bankmoviee/app/AccountApi.kt
SESSION=app/src/main/java/ir/bankmoviee/app/AccountSession.kt
SITE=OPTIONAL_SITE_PATCH/app_user_api.php
grep -Fq 'liftSection("FEATURED COLLECTIONS"' "$MAIN"
grep -Fq 'for (index in 0..2)' "$MAIN"
grep -Fq 'val loadingShield = FrameLayout(this)' "$MAIN"
grep -Fq 'fun deliverSearch(' "$MAIN"
grep -Fq 'api2.php?live_search=' "$MAIN"
grep -Fq 'outline.setOval(' "$MAIN"
grep -Fq 'if (id in pendingFavoriteKeys) return' "$MAIN"
grep -Fq 'action = "watchlist_list"' "$ACCOUNT"
grep -Fq 'val mustWrite = AccountSession.watchlistDirty(context)' "$ACCOUNT"
grep -Fq 'fun markWatchlistDirty(' "$SESSION"
php -l "$SITE" >/dev/null
grep -Fq 'X-BM-Watchlist-IDs' "$SITE"
grep -Fq 'bm_wl_with_user_lock' "$SITE"
grep -Fq 'if (!$idOnly)' "$SITE"
echo VERIFY_V24_PREMIUM_SEARCH_WATCHLIST_OK
