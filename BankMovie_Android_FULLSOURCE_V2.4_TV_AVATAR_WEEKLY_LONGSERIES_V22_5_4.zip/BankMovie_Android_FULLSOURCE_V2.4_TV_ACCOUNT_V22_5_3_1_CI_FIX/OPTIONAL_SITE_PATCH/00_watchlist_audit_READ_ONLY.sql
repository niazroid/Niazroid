-- BankMovie 2.4 watchlist diagnostics. Read-only; makes no changes.
SELECT archive_no, COUNT(*) AS count_rows,
  SUM(title IS NULL OR TRIM(title) = '') AS no_title,
  SUM(title_fa IS NULL OR TRIM(title_fa) = '') AS no_persian_title,
  SUM(poster IS NULL OR TRIM(poster) = '') AS no_poster,
  ROUND(SUM(OCTET_LENGTH(payload_json))/1048576,2) AS payload_mib
FROM app_watchlist
GROUP BY archive_no
ORDER BY count_rows DESC;
