#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
APP=app/src/main
MAIN="$APP/java/ir/bankmoviee/app/MainActivity.kt"
ACTIVITY="$APP/java/ir/bankmoviee/app/ExplorerActivity.kt"
JS="$APP/assets/bm_explorer_v17.js"
HTML="$APP/assets/bm_explorer_v17.html"
CSS="$APP/assets/bm_explorer_v17.css"
for f in "$MAIN" "$ACTIVITY" "$JS" "$HTML" "$CSS"; do test -s "$f"; done
node --check "$JS"
python3 - "$MAIN" "$ACTIVITY" "$JS" "$HTML" "$CSS" "$APP/AndroidManifest.xml" <<'PY'
from pathlib import Path
import sys,re,xml.etree.ElementTree as ET
main,activity,js,html,css,manifest=[Path(x).read_text() for x in sys.argv[1:]]
checks={
 'existing native discover retained':'private fun showDiscover()' in main,
 'three-provider engine retained behind neutral UI': all(k in js for k in ["action:'sekans'","action:'lookapo_list'","action:'dorna_list'"]) and all(k not in html for k in ['چی‌ببین','درنا تی‌وی','لوکاپو']),
 'actual explorer API':all(k in js for k in ["action:'sekans'","action:'lookapo_list'","action:'dorna_list'","action:'lookapo_post'","action:'stream'"]),
 '20-item manual batches':'EXPLORER_BATCH_SIZE=20' in js and 'setupManualPaging' in js and 'loadMore()' in js,
 'reel playback': 'function activateSlide' in js and 'Hls.isSupported()' in js,
 'native VLC fallback': 'nativePlayback' in js and 'PlayerActivity.EXTRA_VIDEO_URL' in activity,
 'archive search bridge':'searchArchive' in js and 'RESULT_ARCHIVE_QUERY' in main,
 'no separate lookapo-only rail':'فیلم‌های بیشتر لوکاپو' not in main,
 'bundled site CSS/SVG':'reel-slide' in css and '<svg' in js,
 'no embedded source cookies':all(k not in (js+html+activity).lower() for k in ['playmovix_session=','xsrf-token=','cw_conversation=']),
 'WebView restricted to https': 'MIXED_CONTENT_NEVER_ALLOW' in activity and 'allowFileAccess = false' in activity,
 'new activity registered': 'android:name=".ExplorerActivity"' in manifest,
 'archive routes retained':'archive5ApiUrl(' in main and 'archive4ApiUrl(' in main,
}
ET.fromstring(manifest)
for name,ok in checks.items():
 print(('PASS' if ok else 'FAIL'), name)
assert all(checks.values())
PY
