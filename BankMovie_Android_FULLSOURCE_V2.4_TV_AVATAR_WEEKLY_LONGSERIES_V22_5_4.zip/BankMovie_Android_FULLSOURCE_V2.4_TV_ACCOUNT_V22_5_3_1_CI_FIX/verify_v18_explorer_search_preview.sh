#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
JS='app/src/main/assets/bm_explorer_v17.js'
HTML='app/src/main/assets/bm_explorer_v17.html'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
ACT='app/src/main/java/ir/bankmoviee/app/ExplorerActivity.kt'
node --check "$JS"
python3 - "$JS" "$HTML" "$MAIN" "$ACT" <<'PY'
from pathlib import Path
import sys
js,html,main,act=[Path(f).read_text(encoding='utf8') for f in sys.argv[1:]]
checks={
 'no provider labels shown to users': all(x not in html for x in ['چی‌ببین','درنا تی‌وی','لوکاپو','فیلتر منبع']),
 'video search stays on explorer': 'event.preventDefault();event.stopPropagation();apply();input.blur()' in js,
 'Enter no longer searches native archive': "input.addEventListener('keydown'" in js and 'window.BankMovieApp?.searchArchive?.(input.value.trim())' not in js,
 'search button filters the current list': 'bmAppExplorerSearchAction' in html and 'action?.addEventListener' in js,
 'search results update on new items': 'new MutationObserver(apply)' in js,
 'three feeds preserved in engine': all(x in js for x in ["action:'sekans'", "action:'lookapo_list'", "action:'dorna_list'"]),
 'twenty manual cards retained': 'EXPLORER_BATCH_SIZE=20' in js and 'explorerShowMore' in js,
 'preview network callbacks dispatched onto UI Thread': 'fun previewFetched(' in main and 'runOnUiThread {' in main.split('fun previewFetched(',1)[1].split('fetch(',1)[0],
 'preview taps open their own video': 'openNativeExplorerV17(uid)' in main and 'BMExplorerInitialUid' in js and 'EXTRA_START_UID' in act,
 'preview is not empty while fetching': 'explorerPreviewLoading' in main,
 'chosen domain is forwarded to explorer': 'EXTRA_CONTENT_DOMAIN' in main and 'EXTRA_CONTENT_DOMAIN' in act,
 'WebView crash does not leave an unrecoverable black screen': 'onRenderProcessGone' in act,
 'thumbnail video loading is lazy': 'IntersectionObserver' in js and 'preload="none"' in js,
 'archive detail search remains explicit': 'searchArchive' in js and 'RESULT_ARCHIVE_QUERY' in act,
}
for k, v in checks.items():print(('PASS' if v else 'FAIL')+' - '+k)
assert all(checks.values()), 'V18 regression check failed'
PY
