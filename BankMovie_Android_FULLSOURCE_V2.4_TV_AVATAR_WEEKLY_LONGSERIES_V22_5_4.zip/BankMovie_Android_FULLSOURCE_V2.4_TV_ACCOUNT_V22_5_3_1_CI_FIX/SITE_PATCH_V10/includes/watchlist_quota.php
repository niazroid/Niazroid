<?php
/**
 * BankMovie watchlist quota. Configurable saved titles for regular accounts;
 * active VIP and site administrators have no limit.
 * All mutations must run inside bm_wl_with_user_lock() to serialize writes
 * across archive-1, main catalog, profile and desktop/mobile app endpoints.
 */
// Legacy constant retained for third-party code; enforcement uses the saved site setting.
if (!defined('BM_WATCHLIST_FREE_LIMIT')) define('BM_WATCHLIST_FREE_LIMIT', 100);
if (!function_exists('bm_wl_free_limit')) {
    function bm_wl_free_limit(): int {
        if (!function_exists('bm_site_get')) require_once __DIR__ . '/site_content_control.php';
        $setting = function_exists('bm_site_get') ? bm_site_get('watchlist_free_limit', 100) : 100;
        return max(1, min(500, (int)$setting));
    }
}


if (!class_exists('BMWatchlistQuotaReached', false)) {
    final class BMWatchlistQuotaReached extends RuntimeException {
        private int $saved;
        public function __construct(int $saved) {
            parent::__construct('ظرفیت ' . bm_wl_free_limit() . ' عنوان واچ‌لیست رایگان شما تکمیل شده است. یک عنوان حذف کنید یا اشتراک VIP تهیه کنید.');
            $this->saved = $saved;
        }
        public function payload(): array {
            $url = function_exists('bm_vip_sales_url') ? bm_vip_sales_url('watchlist') : '/vip?feature=watchlist';
            return [
                'success' => false, 'status' => 'error',
                'error' => 'watchlist_limit_reached', 'error_code' => 'WATCHLIST_LIMIT_REACHED',
                'message' => $this->getMessage(), 'limit' => bm_wl_free_limit(),
                'count' => $this->saved, 'vip_unlimited' => true,
                'purchase_url' => $url,
            ];
        }
    }
}

if (!function_exists('bm_wl_is_unlimited')) {
    function bm_wl_is_unlimited(?array $user): bool {
        if (!$user) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (in_array($role, ['admin', 'administrator'], true)) return true;
        if (function_exists('bm_vip_user_is_active')) return bm_vip_user_is_active($user);
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        return $expiry === '' || (($ts = strtotime($expiry)) !== false && $ts > time());
    }
}

if (!function_exists('bm_wl_with_user_lock')) {
    /** MySQL named advisory locks also serialize requests across distinct web endpoints. */
    function bm_wl_with_user_lock(PDO $pdo, int $userId, callable $callback) {
        $name = 'bm_wl_quota_u_' . $userId;
        $get = $pdo->prepare('SELECT GET_LOCK(?, 8)');
        $get->execute([$name]);
        if ((int)$get->fetchColumn() !== 1) throw new RuntimeException('Watchlist is busy. Please try again.');
        try { return $callback(); }
        finally {
            try { $release = $pdo->prepare('SELECT RELEASE_LOCK(?)'); $release->execute([$name]); }
            catch (Throwable $e) { error_log('Watchlist lock release: ' . $e->getMessage()); }
        }
    }
}

if (!function_exists('bm_wl_table_exists')) {
    function bm_wl_table_exists(PDO $pdo, string $table): bool {
        // Only fixed internal identifiers; no user-controlled table names.
        if (!in_array($table, ['watchlist', 'archive1_watchlist', 'app_watchlist'], true)) return false;
        $q = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?');
        $q->execute([$table]);
        return (int)$q->fetchColumn() > 0;
    }
}

if (!function_exists('bm_wl_link_key')) {
    function bm_wl_link_key(string $url): string {
        $url = trim($url);
        if ($url === '') return '';
        // Both absolute and site-local movie links must compare the same.
        $path = parse_url($url, PHP_URL_PATH);
        $query = parse_url($url, PHP_URL_QUERY);
        if ($path === false) return $url;
        $path = '/' . trim((string)$path, '/');
        return rtrim($path, '/') . ($query ? '?' . $query : '');
    }
}

/**
 * The website profile renders watchlist + archive1_watchlist. app_watchlist is
 * an additional compatibility store and may contain historical app-only rows.
 * Count visible website cards separately from the cross-client quota.
 */
if (!function_exists('bm_wl_website_saved_count')) {
    function bm_wl_website_saved_count(PDO $pdo, int $userId): int {
        $db = []; $links = [];
        if (bm_wl_table_exists($pdo, 'watchlist')) {
            // Match profile.php: orphan movie ids have no visible card.
            $s = $pdo->prepare('SELECT DISTINCT w.movie_id FROM watchlist w INNER JOIN movies m ON m.id=w.movie_id WHERE w.user_id=?');
            $s->execute([$userId]);
            while (($v=$s->fetchColumn()) !== false) $db[(int)$v]=true;
        }
        if (bm_wl_table_exists($pdo, 'archive1_watchlist')) {
            $s = $pdo->prepare('SELECT item_link FROM archive1_watchlist WHERE user_id=?');
            $s->execute([$userId]);
            while (($v=$s->fetchColumn()) !== false) {
                $k=bm_wl_link_key((string)$v);
                if ($k!=='') $links[$k]=true;
            }
        }
        return count($db)+count($links);
    }
}

if (!function_exists('bm_wl_saved_count')) {
    /**
     * Cross-client quota count: count one canonical identity once even if
     * old APKs created several app storage keys for the same title.
     * No records are modified or erased during counting.
     */
    function bm_wl_saved_count(PDO $pdo, int $userId): int {
        $seen=[];
        if (bm_wl_table_exists($pdo, 'watchlist')) {
            $s=$pdo->prepare('SELECT DISTINCT w.movie_id FROM watchlist w INNER JOIN movies m ON m.id=w.movie_id WHERE w.user_id=?');
            $s->execute([$userId]);
            while (($v=$s->fetchColumn()) !== false) $seen['db:' . (int)$v]=true;
        }
        if (bm_wl_table_exists($pdo, 'archive1_watchlist')) {
            $s=$pdo->prepare('SELECT item_link FROM archive1_watchlist WHERE user_id=?');
            $s->execute([$userId]);
            while (($v=$s->fetchColumn()) !== false) {
                $k=bm_wl_link_key((string)$v);
                if ($k!=='') $seen['url:' . $k]=true;
            }
        }
        $count=count($seen);
        if (bm_wl_table_exists($pdo, 'app_watchlist')) {
            $s=$pdo->prepare('SELECT storage_key,db_movie_id,archive_no,item_type,item_id,source_url FROM app_watchlist WHERE user_id=?');
            $s->execute([$userId]);
            while ($row=$s->fetch(PDO::FETCH_ASSOC)) {
                $keys=[];
                $dbId=(int)($row['db_movie_id']??0);
                if ($dbId>0) $keys[]='db:'.$dbId;
                $link=bm_wl_link_key((string)($row['source_url']??''));
                if ($link!=='') $keys[]='url:'.$link;
                $arc=(int)($row['archive_no']??0);
                $id=trim((string)($row['item_id']??''));
                $type=strtolower(trim((string)($row['item_type']??'movie')));
                if ($id!=='') $keys[]='item:'.$arc.'|'.$type.'|'.$id;
                if (!$keys) $keys[]='storage:'.(string)$row['storage_key'];
                $duplicate=false;
                foreach ($keys as $key) if (isset($seen[$key])) {$duplicate=true;break;}
                if (!$duplicate) $count++;
                foreach ($keys as $key) $seen[$key]=true;
            }
        }
        return $count;
    }
}

if (!function_exists('bm_wl_delete_app_mirror_by_db')) {
    /** User clicked Remove on the website: also remove matching app copies. */
    function bm_wl_delete_app_mirror_by_db(PDO $pdo, int $userId, int $movieId, string $imdb=''): void {
        if ($movieId<1 || !bm_wl_table_exists($pdo,'app_watchlist')) return;
        $s=$pdo->prepare('DELETE FROM app_watchlist WHERE user_id=? AND db_movie_id=?');
        $s->execute([$userId,$movieId]);
        // Do not match archive-2 external entries by an ambiguous numeric item_id.
        if ($imdb!=='') {
            $s=$pdo->prepare('DELETE FROM app_watchlist WHERE user_id=? AND archive_no=2 AND imdb_code=? AND (db_movie_id IS NULL OR db_movie_id=0)');
            $s->execute([$userId,$imdb]);
        }
    }
}

if (!function_exists('bm_wl_delete_app_mirror_by_link')) {
    function bm_wl_delete_app_mirror_by_link(PDO $pdo, int $userId, string $url): void {
        $canonical=bm_wl_link_key($url);
        if ($canonical==='' || !bm_wl_table_exists($pdo,'app_watchlist')) return;
        $q=$pdo->prepare("SELECT id,source_url FROM app_watchlist WHERE user_id=? AND archive_no IN (1,3,4,5) AND source_url IS NOT NULL AND source_url != ''");
        $q->execute([$userId]);
        $ids=[];
        while ($row=$q->fetch(PDO::FETCH_ASSOC)) {
            if (bm_wl_link_key((string)$row['source_url'])===$canonical) $ids[]=(int)$row['id'];
        }
        if ($ids) {
            $d=$pdo->prepare('DELETE FROM app_watchlist WHERE user_id=? AND id=?');
            foreach ($ids as $id) $d->execute([$userId,$id]);
        }
    }
}

if (!function_exists('bm_wl_require_room')) {
    /** Call only for a genuinely new item, inside bm_wl_with_user_lock(). */
    function bm_wl_require_room(PDO $pdo, ?array $user, int $userId): void {
        if (bm_wl_is_unlimited($user)) return;
        $count = bm_wl_saved_count($pdo, $userId);
        if ($count >= bm_wl_free_limit()) throw new BMWatchlistQuotaReached($count);
    }
}
