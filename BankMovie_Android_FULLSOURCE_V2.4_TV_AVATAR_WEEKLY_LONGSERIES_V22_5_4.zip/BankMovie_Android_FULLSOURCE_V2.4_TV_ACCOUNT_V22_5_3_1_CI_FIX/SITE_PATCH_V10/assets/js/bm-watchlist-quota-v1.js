/** BankMovie 2.4 — premium, non-blocking shared quota toast. */
(function () {
  'use strict';
  if (window.BMWatchlistQuota) return;
  let active = null;
  function showNotice(data) {
    if (!data || (data.error !== 'watchlist_limit_reached' && data.error_code !== 'WATCHLIST_LIMIT_REACHED')) return;
    if (active) active.close();
    const cap = Number.isFinite(Number(data.limit)) && Number(data.limit)>0 ? Math.floor(Number(data.limit)) : 100;
    const count = Number.isFinite(Number(data.count)) ? Math.max(0, Number(data.count)) : cap;
    const url = typeof data.purchase_url === 'string' && /^\/vip(?:[/?#]|$)/.test(data.purchase_url)
      ? data.purchase_url : '/vip?feature=watchlist';
    const root = document.createElement('aside');
    root.className = 'bm-wl-premium-toast';
    root.setAttribute('role', 'status');
    root.setAttribute('aria-live', 'polite');
    root.setAttribute('dir','rtl');
    root.innerHTML = '<span class="bm-wl-toast-icon" aria-hidden="true">★</span><div class="bm-wl-toast-main"><div class="bm-wl-toast-eyebrow">BANKMOVIE · WATCHLIST</div><strong class="bm-wl-toast-head">ظرفیت واچ‌لیست تکمیل شد</strong><p></p><div class="bm-wl-toast-meter"><span></span></div><div class="bm-wl-toast-actions"><a class="bm-wl-toast-vip">ارتقا به VIP ✦</a><button type="button" class="bm-wl-toast-dismiss">بعداً</button></div></div><button type="button" class="bm-wl-toast-x" aria-label="بستن">×</button>';
    root.querySelector('p').textContent = count.toLocaleString('fa-IR') + ' از ' + cap.toLocaleString('fa-IR') + ' عنوان ذخیره شده؛ برای ادامه یکی را حذف کن یا VIP بگیر.';
    root.querySelector('.bm-wl-toast-vip').href = url;
    root.querySelector('.bm-wl-toast-meter span').style.width = Math.min(100, count / cap * 100) + '%';
    const styleId = 'bm-wl-premium-toast-style-v10';
    if (!document.getElementById(styleId)) {
      const style = document.createElement('style');
      style.id = styleId;
      style.textContent = `
      .bm-wl-premium-toast{position:fixed;z-index:2147483000;bottom:max(18px,env(safe-area-inset-bottom));left:50%;width:min(440px,calc(100vw - 24px));transform:translate(-50%,125%) scale(.95);opacity:0;direction:rtl;display:flex;gap:12px;align-items:flex-start;padding:17px 14px;box-sizing:border-box;border-radius:25px;border:1px solid rgba(var(--accent-rgb,87,146,255),.55);background:radial-gradient(ellipse at 0 0,rgba(var(--accent-rgb,87,146,255),.19),transparent 60%),linear-gradient(145deg,rgba(28,34,51,.97),rgba(9,12,20,.98));box-shadow:0 18px 65px rgba(0,0,0,.58),0 0 0 1px rgba(255,255,255,.07) inset;color:#fff;font:inherit;backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);transition:transform .5s cubic-bezier(.18,1,.32,1),opacity .28s ease}
      .bm-wl-premium-toast.is-visible{transform:translate(-50%,0) scale(1);opacity:1}
      .bm-wl-toast-main{min-width:0;flex:1}.bm-wl-toast-icon{flex:0 0 40px;width:40px;height:40px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent,#528dff),#8669e8);font-size:23px;box-shadow:0 6px 20px rgba(var(--accent-rgb,87,146,255),.25)}
      .bm-wl-toast-eyebrow{font:800 9px/1.2 system-ui;letter-spacing:1px;opacity:.6;direction:ltr;text-align:right;margin-bottom:5px}.bm-wl-toast-head{display:block;font-size:15px;font-weight:950}.bm-wl-toast-main p{font-size:11px;line-height:1.8;color:#c6d0e2;margin:5px 0 10px}
      .bm-wl-toast-meter{height:4px;border-radius:10px;background:rgba(255,255,255,.13);overflow:hidden}.bm-wl-toast-meter>span{display:block;height:100%;border-radius:inherit;background:linear-gradient(90deg,var(--accent,#528dff),#ae81ff);transition:width .5s}
      .bm-wl-toast-actions{display:flex;gap:7px;margin-top:11px}.bm-wl-toast-actions a,.bm-wl-toast-actions button{display:inline-flex;align-items:center;justify-content:center;text-decoration:none;border-radius:12px;padding:8px 12px;font:800 11px/1.3 inherit;cursor:pointer}.bm-wl-toast-vip{background:var(--accent,#3d82ff);color:#fff;border:1px solid rgba(255,255,255,.2)}.bm-wl-toast-dismiss{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);color:#c6d0e2}.bm-wl-toast-x{border:0;background:transparent;color:#a3aec3;font-size:22px;cursor:pointer;padding:0 2px}
      @media(prefers-reduced-motion:reduce){.bm-wl-premium-toast{transition:opacity .1s ease;transform:translate(-50%,0)!important}}
      @media(min-width:960px){.bm-wl-premium-toast{left:22px;transform:translateY(125%) scale(.95);}.bm-wl-premium-toast.is-visible{transform:translateY(0) scale(1)}}
      `;
      document.head.appendChild(style);
    }
    (document.body || document.documentElement).appendChild(root);
    let timer;
    function close() { clearTimeout(timer); root.classList.remove('is-visible'); window.setTimeout(function(){root.remove();},260); if (active && active.root === root) active = null; }
    active = {root,close};
    root.querySelector('.bm-wl-toast-dismiss').addEventListener('click',close);
    root.querySelector('.bm-wl-toast-x').addEventListener('click',close);
    root.querySelector('.bm-wl-toast-vip').addEventListener('click',close);
    timer = window.setTimeout(close,9500);
    requestAnimationFrame(function(){root.classList.add('is-visible');});
  }
  window.BMWatchlistQuota = {show:showNotice};
  if (typeof window.fetch !== 'function') return;
  const original = window.fetch;
  window.fetch = function(input,init){
    const promise = original.apply(this,arguments);
    try {
      const url = new URL((typeof input === 'string' || input instanceof URL) ? String(input) : input.url, location.href);
      if (url.origin === location.origin && /\/(?:ajax_watchlist|ajax_archive1_watchlist|ajax_profile)\.php$/.test(url.pathname)) {
        promise.then(function(response){response.clone().json().then(showNotice).catch(function(){});}).catch(function(){});
      }
    } catch(e) {}
    return promise;
  };
})();
