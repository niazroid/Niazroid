<?php
/* BM_COMMENT_IDENTITY_BRIDGE_V249 */
require_once __DIR__ . '/includes/comment_identity_bridge_v249.php';

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/bm_runtime_performance.php';
bm_perf_boot(['page' => 'movie']);
bm_perf_mark('movie-entry');
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// تنظیم سطح گزارش‌دهی (در محیط تولید بهتر است E_ALL & ~E_DEPRECATED & ~E_STRICT باشد)
error_reporting(E_ALL);
ini_set('display_errors', 0);                 // خطاها را در مرورگر نشان نده (امنیت)
ini_set('log_errors', 1);                    // فعال‌سازی لاگ خطا
if (function_exists('bm_security_private_path')) ini_set('error_log', bm_security_private_path('php-errors.log')); // مسیر لاگ خارج از public

// همچنین می‌توانید خطاهای فatal را هم با Shutdown Function ثبت کنید
register_shutdown_function(function () {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        error_log(sprintf(
            "[FATAL] %s in %s on line %d",
            $error['message'],
            $error['file'],
            $error['line']
        ));
    }
});

require_once 'config.php';
require_once __DIR__ . '/includes/download_domain_manager.php';
require_once __DIR__ . '/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
require_once __DIR__ . '/includes/db_housekeeping.php';
bm_dbh_maybe($pdo);
require_once __DIR__ . '/includes/site_content_control.php';
bm_site_maybe_redirect_maintenance();
require_once __DIR__ . '/includes/vip_features.php';
require_once __DIR__ . '/includes/user_avatar.php';
require_once __DIR__ . '/includes/admin_feature_flags.php';
require_once __DIR__ . '/includes/movie_release_updates.php';
require_once __DIR__ . '/includes/bm_detail_cache.php';
bm_perf_mark('config-and-session-ready');
require_once __DIR__ . '/includes/bankmovie_comment_upgrade.php';
require_once __DIR__ . '/includes/sticker_packs.php';
bm_site_comment_upgrade_schema($pdo);
$bmCommentConfig = bm_site_comment_config();
$bmCommentTitleFa = (string)bm_site_get('comment_title_fa', 'نظرات کاربران');
$bmCommentPlaceholderFa = (string)bm_site_get('comment_placeholder_fa', 'دیدگاهت را درباره این عنوان بنویس...');
$bmCommentSubmitFa = (string)bm_site_get('comment_submit_label_fa', 'ثبت دیدگاه');
$bmCommentEmptyFa = (string)bm_site_get('comment_empty_message_fa', 'هنوز دیدگاهی ثبت نشده؛ اولین نفر باش.');
$bmMovieWindowsTemplate = strtolower(trim((string)bm_site_get('movie_windows_template', 'classic')));
if (!in_array($bmMovieWindowsTemplate, ['classic', 'cinematic'], true)) {
    $bmMovieWindowsTemplate = 'classic';
}
$bmMovieIsWindowsClient = preg_match('/Windows(?: NT)?/i', (string)($_SERVER['HTTP_USER_AGENT'] ?? '')) === 1;
$bmMovieTemplateClass = ($bmMovieWindowsTemplate === 'cinematic' && $bmMovieIsWindowsClient)
    ? 'bm-movie-template-cinematic'
    : 'bm-movie-template-classic';
$bmMovieCinematicAccent = trim((string)bm_site_get('movie_cinematic_accent_color', '#8b2cff'));
if (!preg_match('/^#[0-9a-fA-F]{6}$/', $bmMovieCinematicAccent)) {
    $bmMovieCinematicAccent = '#8b2cff';
}
$bmMovieCinematicTabs = bm_site_bool('movie_cinematic_show_tabs', true);
$bmMovieMobileTemplate = strtolower(trim((string)bm_site_get('movie_mobile_template', 'classic')));
$bmMovieMobileAllowed = ['classic','cinema_tabs'];
if (!in_array($bmMovieMobileTemplate, $bmMovieMobileAllowed, true)) $bmMovieMobileTemplate = 'classic';
$bmMovieMobilePosterSize = strtolower(trim((string)bm_site_get('movie_mobile_poster_size', 'normal')));
if (!in_array($bmMovieMobilePosterSize, ['small','normal','large'], true)) $bmMovieMobilePosterSize = 'normal';
$bmMovieMobileDensity = strtolower(trim((string)bm_site_get('movie_mobile_meta_density', 'normal')));
if (!in_array($bmMovieMobileDensity, ['compact','normal','airy'], true)) $bmMovieMobileDensity = 'normal';
$bmMovieMobileStoryLines = max(2, min(8, (int)bm_site_get('movie_mobile_story_lines', 4)));
$bmMovieMobileShowEnglish = bm_site_bool('movie_mobile_show_english_title', true);

require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/bm_analytics.php';
$currentUser = $currentUser ?? null;
$bmCurrentUserAvatarUrl = $currentUser ? bm_user_avatar_url((string)($currentUser['avatar'] ?? '')) : '';
$bmCommentMediaAllowed = bm_vip_benefit_allowed('comment_media', $currentUser);
$bmCommentStickerCatalog = bm_sticker_public_catalog(); // catalog is public for rendering; sending remains VIP-gated
$bmVipDownloadLocked = !bm_vip_gate_allows('downloads', $currentUser);
$bmVipSubtitleLocked = !bm_vip_gate_allows('subtitle_downloads', $currentUser);
$bmVipWatchLocked = !bm_vip_gate_allows('online_watch', $currentUser);
$bmVipWatchlistLocked = !bm_vip_gate_allows('watchlist', $currentUser);
$bmVipCommentsLocked = !bm_vip_gate_allows('comments_ratings', $currentUser);
$bmVipPartyLocked = bm_vip_feature_enabled('watch_party') && !bm_vip_user_is_active($currentUser);
$bmVipPlayerLocked = !bm_vip_gate_allows('online_player', $currentUser);
$bmExternalPlayersEnabled = bm_feature_enabled('external_players', true);
$bmDirectDownloadsEnabled = bm_feature_enabled('direct_downloads', true);
$bmPlayerCopyLinkEnabled = bm_feature_enabled('player_copy_link', true);
$bmVipModalEnabled = bm_feature_enabled('vip_modal', true);
// مقداردهی اولیه برای جلوگیری از خطاهای undefined variable
$inWatchlist = false;
$userRating  = 0;
$latestNotification = $activeNotification ?? null;

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrfToken = $_SESSION['csrf_token'];

if (!function_exists('bm_ext_safe_url')) {
    function bm_ext_safe_url($url): string {
        if (function_exists('bm_security_safe_url')) return bm_security_safe_url($url, ['http','https']);
        $url = trim((string)$url);
        return preg_match('~^https?://~i', $url) ? $url : '';
    }
}

if (!function_exists('bm_archive_stream_url')) {
    function bm_archive_stream_url($url): string {
        if (array_key_exists('bmArchiveStreamAllowed', $GLOBALS) && !$GLOBALS['bmArchiveStreamAllowed']) return '';
        return trim((string)$url);
    }
}


if (!function_exists('bm_archive_download_type_label')) {
    function bm_archive_download_type_label($type, $lang = 'fa', $fallbackFa = 'زیرنویس فارسی', $fallbackEn = 'Persian Subtitle'): string {
        $type = strtolower(trim((string)$type));
        $fa = $lang === 'fa';
        $labels = [
            'dub' => $fa ? 'دوبله' : 'Dubbed',
            'dubbed' => $fa ? 'دوبله' : 'Dubbed',
            'audio' => $fa ? 'صوت دوبله' : 'Dubbed Audio',
            'hardsub' => $fa ? 'هاردساب' : 'Hard Sub',
            'softsub' => $fa ? 'سافت‌ساب' : 'Soft Sub',
            'subtitle' => $fa ? 'زیرنویس فارسی' : 'Persian Subtitle',
            'nosub' => $fa ? 'بدون زیرنویس' : 'No Subtitle',
            'original' => $fa ? 'زبان اصلی' : 'Original',
        ];
        return $labels[$type] ?? ($fa ? $fallbackFa : $fallbackEn);
    }
}

if (!function_exists('bm_archive_download_type_class')) {
    function bm_archive_download_type_class($type): string {
        $type = strtolower(trim((string)$type));
        if (in_array($type, ['dub','dubbed','audio'], true)) return 'is-dub';
        if ($type === 'hardsub') return 'is-hard';
        if ($type === 'softsub') return 'is-soft';
        if ($type === 'subtitle') return 'is-subtitle';
        if ($type === 'nosub') return 'is-original';
        if ($type === 'original') return 'is-original';
        return 'is-soft';
    }
}



/** v14862111: Release flags use only this version's verified fields/name, not the movie's title. */
if (!function_exists('bm_v111_release_text')) {
    function bm_v111_release_text(array $row, string $quality = '', string $url = ''): string {
        $keys = ['quality','release','release_name','filename','file_name','original_filename','file_title','release_title','rip_name','source_name','source','source_type','rip_source','technical_note','notes','version_note','details','description','encoder','encode','release_group','encode_group','group','dub_name','dub_source','dub_group','dub_company','audio_source','studio','audio_label','display_label','label'];
        $path = (string)(parse_url($url, PHP_URL_PATH) ?: '');
        $pieces = [$quality, rawurldecode($path)];
        $query = (string)(parse_url($url, PHP_URL_QUERY) ?: '');
        if ($query !== '') {
            parse_str($query, $queryData);
            foreach (['filename','file_name','file','name','release','title','download'] as $key) {
                if (!empty($queryData[$key]) && is_scalar($queryData[$key])) $pieces[] = (string)$queryData[$key];
            }
        }
        foreach ($keys as $key) if (isset($row[$key]) && is_scalar($row[$key])) $pieces[]=(string)$row[$key];
        return trim(implode(' ', $pieces));
    }
}
if (!function_exists('bm_v111_is_cam_release')) {
    function bm_v111_is_cam_release(array $row, string $quality = '', string $url = ''): bool {
        $signal=bm_v111_release_text($row, $quality, $url);
        if (preg_match('/کیفیت\s*(?:پرده(?:\s*ای|\s*سینما)?|سینمایی)|نسخه\s*پرده(?:\s*ای)?|فیلمبرداری\s*از\s*پرده/iu', $signal)) return true;
        return preg_match('/(?:^|[.\s_\-\[(])(?:HD[.\-_ ]?CAM|HQ[.\-_ ]?CAM|CAM[.\-_ ]?RIP|CAM|TELESYNC|HDTS|TS[.\-_ ]?RIP)(?=$|[.\s_\-\])])/i', $signal) === 1;
    }
}
if (!function_exists('bm_v111_cam_notice')) {
    function bm_v111_cam_notice(array $row, string $quality = '', string $url = '', string $lang='fa'): string {
        if (!bm_v111_is_cam_release($row,$quality,$url)) return '';
        $message=$lang==='en' ? 'Cinema-recorded version — picture and sound quality may be low.' : 'این نسخه کیفیت پرده‌ای دارد؛ کیفیت صدا و تصویر ممکن است پایین باشد.';
        return '<div class="bm-v111-cam-notice" role="note"><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M12 3 2.5 20h19L12 3Z" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M12 9v5m0 3h.01" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg><span>'.htmlspecialchars($message,ENT_QUOTES,'UTF-8').'</span></div>';
    }
}


/** v14862112: detect encoders from version-specific data; never infer from resolution alone. */
if (!function_exists('bm_v112_encoder')) {
    function bm_v112_encoder(array $row, string $quality = '', string $url = ''): string {
        $signal=bm_v111_release_text($row,$quality,$url);
        $known=['PSA','ETHEL','KyoGo','YIFY','YTS','RARBG','Pahe','GalaxyRG','NTb','FLUX','CMRG','ION10','QxR','Tigole','MeGusta','ELiTE','MiNX','NTG','BHDStudio','HONE','KOGi','DEFLATE','EPSiLON','TRiToN','CtrlHD','iFT','FGT','VETO','SPARKS','ROVERS','ION265','TOMMY','playWEB','SMURF','SuccessfulCrab','NTG','Telly','AMZN'];
        $names=[]; foreach($known as $name) $names[strtolower($name)]=$name;
        // Exact name boundaries include dots, dashes, underscores and URL separators.
        if (preg_match('/(?<![a-z0-9])('.implode('|',array_map('preg_quote',array_keys($names))).')(?![a-z0-9])/i', $signal, $m)) {
            return $names[strtolower($m[1])];
        }
        // A genuinely populated encoder or release_group column takes precedence over an unknown label.
        foreach (['encoder','encode','release_group','encode_group','group'] as $key) {
            if (!isset($row[$key]) || !is_scalar($row[$key])) continue;
            $value=trim((string)$row[$key]);
            if ($value==='' || strlen($value)>28) continue;
            if (preg_match('/^(?:unknown|none|n\/a|web[. _-]?dl|webrip|bluray|remux|x26[45]|hevc|av1|10bit|1080p|720p|2160p|4k|hdr|imax|audio)$/i', $value)) continue;
            if (preg_match('/^[A-Za-z][A-Za-z0-9._-]{1,26}$/D', $value)) return $value;
        }
        return '';
    }
}

if (!function_exists('bm_arc1_download_meta')) {
    function bm_arc1_download_meta(array $row, string $quality, string $url, bool $isAudioOnly = false, string $classifiedType = ''): array {
        $pick = static function(array $keys) use ($row): string {
            foreach ($keys as $key) {
                $value = trim((string)($row[$key] ?? ''));
                if ($value !== '' && strtolower($value) !== 'unknown' && $value !== '-') return $value;
            }
            return '';
        };
        $haystack = bm_v111_release_text($row, $quality, $url);
        $encoder = bm_v112_encoder($row, $quality, $url);
        $source = $pick(['source_type','source','rip_source']);
        if ($source === '' && preg_match('/(BluRay|WEB[ ._-]?DL|WEBRip|HDTV|DVDRip|Remux)/i', $haystack, $m)) $source = strtoupper(str_replace([' ','_'], '-', $m[1]));
        $codec = $pick(['codec','video_codec','encode_type']);
        if ($codec === '' && preg_match('/(10bit\s*x265|x265|HEVC|x264|AV1|10bit)/i', $haystack, $m)) $codec = strtoupper($m[1]);
        // V14862130: only a real dub track may have a dubbing-provider tag.
        // Generic display_label/label are episode descriptions, not dub studio names.
        $metaType = strtolower(trim($classifiedType !== '' ? $classifiedType : (string)($row['type'] ?? '')));
        $isDubTrack = $isAudioOnly || in_array($metaType, ['dub','dubbed','audio'], true);
        $audioSource = $isDubTrack ? $pick(['dub_name','dub_source','dub_group','dub_company','audio_source','studio','audio_label']) : '';
        $audioSignal = $isDubTrack ? bm_v111_release_text($row,$quality,$url) : '';
        // Never present an entire season/episode/resolution/subtitle description as a green dub badge.
        if ($audioSource !== '' && preg_match('/(?:فصل\s*[۰-۹0-9]+|قسمت\s*[۰-۹0-9]+|season\s*[0-9]+|episode\s*[0-9]+|\bS[0-9]+E[0-9]+\b|\b(?:480|720|1080|2160)p\b|\b4K\b|هارد\s*[‌ -]?ساب|سافت\s*[‌ -]?ساب|زیرنویس|hard[ ._-]*sub|soft[ ._-]*sub|subtitle)/iu', $audioSource)) $audioSource = '';
        if (preg_match('/^(?:صوت\s*دوبله(?:\s*جداگانه|\s*فارسی)?|فایل\s*صوتی(?:\s*جداگانه)?|دوبله\s*فارسی|Persian\s*Dub(?:bed)?\s*Audio|Separate\s*Audio(?:\s*File)?)$/iu', $audioSource)) $audioSource='';
        if ($audioSource === '' && preg_match('/(?:Namava|نماوا)/iu', $audioSignal)) $audioSource='دوبله نماوا';
        elseif ($audioSource === '' && preg_match('/(?:Filimo|فیلیمو)/iu', $audioSignal)) $audioSource='دوبله فیلیمو';
        elseif ($audioSource === '' && preg_match('/(?:Gap[._\- ]?Film|گپ.?فیلم)/iu', $audioSignal)) $audioSource='دوبله گپ‌فیلم';
        elseif ($audioSource === '' && preg_match('/(?:^|[._\- ])IRIB(?:$|[._\- ])|صدا\s*و\s*سیما/iu', $audioSignal)) $audioSource='دوبله صداوسیما';
        elseif ($audioSource === '' && preg_match('/(?:Surena|Soren|سورن|سورنا)/iu', $audioSignal)) $audioSource='دوبله سورنا';
        elseif ($audioSource === '' && preg_match('/(?:Tak[._\- ]?Film|تک.?فیلم)/iu', $audioSignal)) $audioSource='دوبله تک‌فیلم';
        if ($audioSource === '' && $isAudioOnly) {
            if (preg_match('/(?:^|[._\- ])IRIB(?:[._\- ]|$)/i', $haystack)) $audioSource = 'دوبله صداوسیما';
            elseif (preg_match('/Namava/i', $haystack)) $audioSource = 'دوبله نماوا';
            elseif (preg_match('/Filimo/i', $haystack)) $audioSource = 'دوبله فیلیمو';
            elseif (preg_match('/GapFilm/i', $haystack)) $audioSource = 'دوبله گپ‌فیلم';
        }
        // نمایش تمیز و کوتاه: نام «منبع» و «نوع دوبله» نشان داده نمی‌شود.
        // فرمت و کدک به‌صورت برچسب ساده، انکودر با عنوان مشخص و دوبله با نام سرویس نمایش داده می‌شود.
        $normalizeSource = static function(string $value): string {
            $value = strtoupper(trim($value));
            $map = [
                'BLURAY' => 'BluRay', 'BLU-RAY' => 'BluRay',
                'WEB-DL' => 'WEB-DL', 'WEBDL' => 'WEB-DL',
                'WEBRIP' => 'WEBRip', 'WEB-RIP' => 'WEBRip',
                'HDTV' => 'HDTV', 'DVDRIP' => 'DVDRip', 'REMUX' => 'Remux',
            ];
            return $map[$value] ?? trim($value);
        };
        $normalizeCodec = static function(string $value): string {
            $value = trim($value);
            $value = preg_replace('/\s+/u', ' ', $value) ?: $value;
            $map = [
                'X265' => 'x265', 'HEVC' => 'HEVC', 'X264' => 'x264',
                'AV1' => 'AV1', '10BIT' => '10Bit', '10BIT X265' => '10Bit x265',
            ];
            $key = strtoupper($value);
            return $map[$key] ?? $value;
        };

        $out = [];
        if (!$isAudioOnly && $source !== '') $out[] = ['kind'=>'format','label'=>'','value'=>$normalizeSource($source)];
        if (!$isAudioOnly && $codec !== '') $out[] = ['kind'=>'codec','label'=>'','value'=>$normalizeCodec($codec)];
        if (!$isAudioOnly && preg_match('/(?:^|[._\- \(])IMAX(?:$|[._\- \)])/i', $audioSignal)) $out[] = ['kind'=>'imax','label'=>'','value'=>'IMAX'];
        if (!$isAudioOnly && $encoder !== '') $out[] = ['kind'=>'encoder','label'=>(($GLOBALS['userLang'] ?? 'fa') === 'fa' ? 'انکودر' : 'Encoder'),'value'=>$encoder];
        if ($audioSource !== '' && ($GLOBALS['userLang'] ?? 'fa') === 'en') {
            $knownDubs = ['دوبله صداوسیما'=>'IRIB Dub','دوبله نماوا'=>'Namava Dub','دوبله فیلیمو'=>'Filimo Dub','دوبله گپ‌فیلم'=>'GapFilm Dub',
                'دوبله سورنا'=>'Surena Dub','دوبله تک فیلم'=>'TakFilm Dub','دوبله تک‌فیلم'=>'TakFilm Dub',
                'صوت دوبله فارسی'=>'Persian Dubbed Audio','دوبله فارسی'=>'Persian Dubbed'];
            $audioSource = $knownDubs[$audioSource] ?? preg_replace('/^دوبله[\s\x{200C}]+/u', 'Persian Dub - ', $audioSource);
        }
        if ($audioSource !== '') $out[] = ['kind'=>'dub','label'=>'','value'=>$audioSource];
        return $out;
    }
}


/** Archive 6: upstream brand is not an encoder. Keep genuine encode/codec badges. */
if (!function_exists('bm_a6_visible_meta')) {
    function bm_a6_visible_meta(array $items): array {
        $visible=[];
        foreach ($items as $item) {
            if (!is_array($item)) continue;
            $value=(string)($item['value']??'');
            $value=preg_replace('/(?<![\p{L}\p{N}])(?:almas[\s._-]*movie|الماس\s*مووی)(?![\p{L}\p{N}])/iu', '', $value) ?? $value;
            $value=preg_replace('/^[\p{Z}\p{P}\s]+|[\p{Z}\p{P}\s]+$/u', '', $value) ?? trim($value);
            if ($value==='') continue;
            $item['value']=$value;
            $visible[]=$item;
        }
        return $visible;
    }
}

// ====== تشخیص آرشیو ۱ ======
// ====== تعریف اولیه متغیرهای نوتیفیکیشن ======
$notificationsList = [];
$activeNotification = null;
$notificationSeen = false;

try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    $activeNotification = $stmt->fetch(PDO::FETCH_ASSOC);
    if($activeNotification) {
        $cookieName = 'notification_seen_' . $activeNotification['id'];
        if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
    }
} catch (Throwable $e) {
    $notificationsList = [];
    $activeNotification = null;
    $notificationSeen = false;
}
$rawArcSlug = trim((string)($_GET['slug'] ?? ''), "/ \t");
// An old Archive 8 URL is gone; never reinterpret it as a local movie.
if ((int)($_GET['arc'] ?? 0) === 8 || str_starts_with($rawArcSlug, 'arc8-')) { http_response_code(410); exit('Archive removed'); }
$isArc1   = isset($_GET['arc']) && (int)$_GET['arc'] === 1;
$isArc3   = isset($_GET['arc']) && (int)$_GET['arc'] === 3;
$isArc4   = isset($_GET['arc']) && (int)$_GET['arc'] === 4;
$isArc5   = isset($_GET['arc']) && (int)$_GET['arc'] === 5;
$isArc6   = isset($_GET['arc']) && (int)$_GET['arc'] === 6;
$isArc7   = isset($_GET['arc']) && (int)$_GET['arc'] === 7;

// پشتیبانی از URLهای تمیز مثل /movie/arc1-slug ... /movie/arc5-id
if (!$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && strpos($rawArcSlug, 'arc1-') === 0) {
    $isArc1 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && strpos($rawArcSlug, 'arc3-') === 0) {
    $isArc3 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && strpos($rawArcSlug, 'arc4-') === 0) {
    $isArc4 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && strpos($rawArcSlug, 'arc5-') === 0) {
    $isArc5 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}

if (!$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && strpos($rawArcSlug, 'arc6-') === 0) {
    $isArc6 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
if (!$isArc7 && !$isArc1 && !$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && str_starts_with($rawArcSlug, 'arc7-')) {
    $isArc7 = true;
    $rawArcSlug = substr($rawArcSlug, 5);
}
// Reuse the native external detail/season/player template instead of a custom test page.
if ($isArc7) $isArc1 = true;
$bmCurrentArchiveId = $isArc7 ? 'archive7' : ($isArc6 ? 'archive6' : ($isArc5 ? 'archive5' : ($isArc4 ? 'archive4' : ($isArc3 ? 'archive3' : ($isArc1 ? 'archive1' : 'archive2')))));
$bmArchiveDownloadAllowed = $bmDirectDownloadsEnabled && bm_archive_feature_user_can_access($bmCurrentArchiveId, 'download', $currentUser ?? null);
$bmArchiveStreamAllowed = bm_archive_feature_user_can_access($bmCurrentArchiveId, 'stream', $currentUser ?? null);
$bmArchiveItemMediaBlocked = bm_archive_item_media_blocked($bmCurrentArchiveId, [], ['identifier'=>$rawArcSlug]);
$bmArchiveItemDownloadBlocked = $bmArchiveItemMediaBlocked; // Backward-compatible template variable.
if ($bmArchiveItemMediaBlocked) {
    $bmArchiveDownloadAllowed = false;
    $bmArchiveStreamAllowed = false;
}
$GLOBALS['bmArchiveDownloadAllowed'] = $bmArchiveDownloadAllowed;
$GLOBALS['bmArchiveStreamAllowed'] = $bmArchiveStreamAllowed;
$bmArchiveDownloadVipLocked = false;
$bmArchiveStreamVipLocked = false;
$bmArchiveDownloadGateAttrs = '';
$bmArchiveStreamGateAttrs = '';
$bmRefreshArchiveVipGateState = static function () use (
    &$bmArchiveDownloadVipLocked,
    &$bmArchiveStreamVipLocked,
    &$bmArchiveDownloadGateAttrs,
    &$bmArchiveStreamGateAttrs,
    &$bmArchiveItemDownloadBlocked,
    &$bmArchiveDownloadAllowed,
    &$bmArchiveStreamAllowed,
    $bmCurrentArchiveId,
    $bmDirectDownloadsEnabled,
    $currentUser
): void {
    $bmArchiveDownloadVipLocked = $bmDirectDownloadsEnabled
        && !$bmArchiveItemDownloadBlocked
        && bm_archive_feature_scope($bmCurrentArchiveId, 'download') === 'vip'
        && !$bmArchiveDownloadAllowed;
    $bmArchiveStreamScopeVipLocked = !$bmArchiveItemDownloadBlocked
        && bm_archive_feature_scope($bmCurrentArchiveId, 'stream') === 'vip'
        && !$bmArchiveStreamAllowed;
    $bmArchivePlayerMasterLocked = !$bmArchiveItemDownloadBlocked
        && bm_archive_player_gate_locked($bmCurrentArchiveId, 'master', $currentUser);
    $bmArchiveStreamVipLocked = $bmArchiveStreamScopeVipLocked || $bmArchivePlayerMasterLocked;

    // V229: player gates are resolved per archive. Supplying these keys tells
    // vip_gate_modal.php not to fall back to the global switch for this page.
    $GLOBALS['bmArchiveVipGateLocks'] = [
        'downloads' => $bmArchiveDownloadVipLocked,
        'online_watch' => $bmArchiveStreamVipLocked,
        'internal_player' => bm_archive_player_gate_locked($bmCurrentArchiveId, 'internal', $currentUser),
        'external_players' => bm_archive_player_gate_locked($bmCurrentArchiveId, 'external', $currentUser),
        'player_copy_link' => bm_archive_player_gate_locked($bmCurrentArchiveId, 'copy_link', $currentUser),
    ];
    $bmArchiveDownloadGateAttrs = $bmArchiveDownloadVipLocked
        ? ' data-bm-vip-gate="downloads" data-bm-vip-gate-fixed="1" aria-haspopup="dialog" aria-controls="bmVipGateModal"'
        : '';
    $bmArchiveStreamGateAttrs = $bmArchiveStreamVipLocked
        ? ' data-bm-vip-gate="online_watch" data-bm-vip-gate-fixed="1" aria-haspopup="dialog" aria-controls="bmVipGateModal"'
        : '';
};
$bmRefreshArchiveVipGateState();
$bmArchiveBlocked = !bm_archive_is_enabled($bmCurrentArchiveId)
    || !bm_archive_user_can_access($bmCurrentArchiveId, $currentUser ?? null);
// Never show Archive 7 detail data or media to visitors without the configured audience permission.
if ($isArc7 && $bmArchiveBlocked) { http_response_code(404); exit('Not found'); }
if ($isArc7 && !headers_sent()) {
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Vary: Cookie');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    header('Referrer-Policy: no-referrer');
}
$bmLocalArchiveBlocked = $bmCurrentArchiveId === 'archive2' && $bmArchiveBlocked;
if ($bmLocalArchiveBlocked) {
    http_response_code(404);
    header('Location: index.php');
    exit;
}
$bmArchiveBlockedMessage = $bmArchiveBlocked
    ? ((in_array($bmCurrentArchiveId, ['archive4','archive5','archive6'], true) && !bm_archive_user_can_access($bmCurrentArchiveId, $currentUser ?? null)) ? 'محتوا یافت نشد.' : bm_archive_disabled_message($bmCurrentArchiveId))
    : '';

$arcSourceLabel = $isArc7 ? 'آرشیو ۷' : ($isArc6 ? 'آرشیو ۶' : ($isArc5 ? 'آرشیو 5' : ($isArc4 ? 'آرشیو ۴' : ($isArc3 ? 'آرشیو ۳' : 'آرشیو ۱'))));
$arcSourceToastLabel = $arcSourceLabel;

// برچسب نوع نسخه برای هر آرشیو؛ فقط برای عنوان بخش‌ها/بج‌ها استفاده می‌شود، نه تنظیمات پلیر.
$bmArchiveSubFa = $isArc7 ? 'زیرنویس' : ($isArc6 ? 'زیرنویس' : ($isArc5 ? 'زیرنویس فارسی + دوبله' : (($isArc4 || $isArc3) ? 'زیرنویس فارسی' : ($isArc1 ? 'هاردساب' : 'سافت ساب'))));
$bmArchiveSubEn = $isArc7 ? 'Subtitle' : ($isArc6 ? 'Subtitle' : ($isArc5 ? 'Persian Subtitle + Dubbed' : (($isArc4 || $isArc3) ? 'Persian Subtitle' : ($isArc1 ? 'Hard Sub' : 'Soft Sub'))));
$arc1Slug = $rawArcSlug;
$arc1Type = in_array($_GET['type']??'', ['series','movie','anime'], true) ? $_GET['type'] : null;
if (($isArc6 || $isArc7) && preg_match('/^(movie|series)-[a-z0-9_-]{1,90}$/iD', $rawArcSlug, $bmArc6Type)) $arc1Type = strtolower($bmArc6Type[1]);

// برای سازگاری با قالب قبلی، آرشیوهای خارجی ۳، ۴ و ۵ از همان مسیر رندر آرشیو ۱ استفاده می‌کنند.
if ($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) {
    $isArc1 = true;
}

// ID مجازی برای کامنت‌های آرشیو خارجی
// نکته مهم: بعضی دیتابیس‌ها ستون comments.movie_id را UNSIGNED دارند؛ بنابراین ID منفی باعث خطای 500 می‌شود.
// این بازه عمداً خیلی بالاست تا با ID فیلم‌های آرشیو ۲ تداخل نداشته باشد.
$arcCrcKey = ($isArc7 ? 'arc7:' : ($isArc6 ? 'arc6:' : ($isArc5 ? 'arc5:' : ($isArc4 ? 'arc4:' : ($isArc3 ? 'arc3:' : 'arc1:'))))) . $arc1Slug;
$arc1VirtualMovieId = $arc1Slug !== '' ? (1000000000 + (abs(crc32($arcCrcKey)) % 1000000000)) : 0;

if (!function_exists('bm_ensure_archive1_comment_tables')) {
    function bm_ensure_archive1_comment_tables(PDO $pdo): void {
        $runner = static function (PDO $pdo): void {
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                movie_id INT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NULL,
                username VARCHAR(100) NOT NULL DEFAULT '',
                comment TEXT NOT NULL,
                rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
                spoiler TINYINT(1) NOT NULL DEFAULT 0,
                parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'pending',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_movie_parent_status (movie_id, parent_id, status),
                KEY idx_user_status (user_id, status),
                KEY idx_parent (parent_id),
                KEY idx_created (created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                comment_id BIGINT UNSIGNED NOT NULL,
                user_id INT UNSIGNED NOT NULL,
                type VARCHAR(10) NOT NULL DEFAULT 'like',
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_comment_user (comment_id, user_id),
                KEY idx_comment_type (comment_id, type),
                KEY idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        };
        if (function_exists('bm_schema_once')) {
            bm_schema_once($pdo, 'archive-comments', 3, $runner);
            return;
        }
        $runner($pdo);
    }
}

if (!function_exists('bm_ensure_archive1_items_table')) {
    function bm_ensure_archive1_items_table(PDO $pdo): void {
        $runner = static function (PDO $pdo): void {
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_items (
                virtual_movie_id INT UNSIGNED NOT NULL PRIMARY KEY,
                archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
                slug VARCHAR(220) NOT NULL DEFAULT '',
                item_link VARCHAR(500) NOT NULL DEFAULT '',
                item_title VARCHAR(300) NOT NULL DEFAULT '',
                item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
                item_year VARCHAR(10) DEFAULT NULL,
                item_poster VARCHAR(500) DEFAULT NULL,
                item_type VARCHAR(20) DEFAULT 'movie',
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_archive_slug (archive_no, slug)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $stmt = $pdo->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='archive1_items' AND COLUMN_NAME='archive_no' LIMIT 1");
            $stmt->execute();
            if (!$stmt->fetchColumn()) {
                $pdo->exec("ALTER TABLE archive1_items ADD COLUMN archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1 AFTER virtual_movie_id");
            }
            try { $pdo->exec("CREATE INDEX idx_archive_slug ON archive1_items (archive_no, slug)"); } catch (Throwable $ignored) {}
        };
        if (function_exists('bm_schema_once')) {
            bm_schema_once($pdo, 'archive-items', 4, $runner);
            return;
        }
        $runner($pdo);
    }
}

if (!function_exists('bm_ensure_archive1_watchlist_table')) {
    function bm_ensure_archive1_watchlist_table(PDO $pdo): void {
        $runner = static function (PDO $pdo): void {
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                item_link VARCHAR(500) NOT NULL,
                item_title VARCHAR(300) NOT NULL DEFAULT '',
                item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
                item_year VARCHAR(10) DEFAULT NULL,
                item_poster VARCHAR(500) DEFAULT NULL,
                item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
                item_type VARCHAR(20) DEFAULT 'movie',
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_user_link (user_id, item_link(200)),
                KEY idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $required = [
                'item_title_fa' => "VARCHAR(300) NOT NULL DEFAULT '' AFTER item_title",
                'item_year' => "VARCHAR(10) DEFAULT NULL AFTER item_title_fa",
                'item_imdb_rate' => "DECIMAL(3,1) DEFAULT NULL AFTER item_poster",
                'added_at' => "TIMESTAMP DEFAULT CURRENT_TIMESTAMP AFTER item_type",
            ];
            $check = $pdo->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'archive1_watchlist' AND COLUMN_NAME = ?");
            foreach ($required as $column => $definition) {
                $check->execute([$column]);
                if (!(bool)$check->fetchColumn()) $pdo->exec("ALTER TABLE archive1_watchlist ADD COLUMN `{$column}` {$definition}");
            }
        };
        if (function_exists('bm_schema_once')) {
            bm_schema_once($pdo, 'archive-watchlist', 3, $runner);
            return;
        }
        $runner($pdo);
    }
}

if (!function_exists('bm_comment_public_status_sql')) {
    function bm_comment_public_status_sql(string $alias = 'c'): string {
        $safeAlias = preg_replace('/[^A-Za-z0-9_]/', '', $alias) ?: 'c';
        return "LOWER(TRIM(CAST({$safeAlias}.status AS CHAR))) IN ('approved','active','1')";
    }
}

if (!function_exists('bm_comment_root_parent_sql')) {
    function bm_comment_root_parent_sql(string $alias = 'c'): string {
        $safeAlias = preg_replace('/[^A-Za-z0-9_]/', '', $alias) ?: 'c';
        return "({$safeAlias}.parent_id IS NULL OR {$safeAlias}.parent_id = 0)";
    }
}

if (!function_exists('bm_comment_normalize_identity')) {
    function bm_comment_normalize_identity(string $value): string {
        $value = rawurldecode(trim($value, "/ \t\n\r\0\x0B"));
        if ($value === '') return '';
        $parts = @parse_url($value);
        if (is_array($parts)) {
            if (!empty($parts['query'])) {
                parse_str((string)$parts['query'], $query);
                foreach (['slug', 'id'] as $key) {
                    if (!empty($query[$key])) {
                        $value = rawurldecode(trim((string)$query[$key], "/ \t"));
                        break;
                    }
                }
            }
            if (!empty($parts['path']) && preg_match('~(?:^|/)movie/arc[1345]-([^/?#]+)~i', '/' . trim((string)$parts['path'], '/'), $m)) {
                $value = rawurldecode((string)$m[1]);
            }
        }
        $value = preg_replace('~^arc[1345]-~i', '', trim($value, "/ \t"));
        return mb_strtolower((string)$value, 'UTF-8');
    }
}

if (!function_exists('bm_resolve_external_comment_movie_id')) {
    /**
     * Finds the real comment movie id shared by app/site for external archives.
     * Older builds sometimes used a different slug form. We select the mapped id
     * that already owns comments and merge strong aliases into it.
     */
    function bm_resolve_external_comment_movie_id(
        PDO $pdo,
        int $computedId,
        int $archiveNo,
        string $slug,
        string $itemLink = '',
        string $title = '',
        string $year = ''
    ): int {
        if ($computedId <= 0) return 0;
        try {
            bm_ensure_archive1_comment_tables($pdo);
            bm_ensure_archive1_items_table($pdo);

            $normalizedSlug = bm_comment_normalize_identity($slug);
            $normalizedLink = trim($itemLink);
            $title = trim($title);
            $year = trim($year);

            $where = ['ai.virtual_movie_id = ?'];
            $params = [$computedId];
            if ($normalizedSlug !== '') {
                $where[] = '(ai.archive_no = ? AND (LOWER(TRIM(BOTH \'/\' FROM ai.slug)) = ? OR LOWER(TRIM(BOTH \'/\' FROM ai.slug)) = ?))';
                $params[] = $archiveNo;
                $params[] = $normalizedSlug;
                $params[] = 'arc' . $archiveNo . '-' . $normalizedSlug;
            }
            if ($normalizedLink !== '') {
                $where[] = '(ai.archive_no = ? AND ai.item_link = ?)';
                $params[] = $archiveNo;
                $params[] = $normalizedLink;
            }
            if ($title !== '' && $year !== '') {
                $where[] = '(ai.archive_no = ? AND (ai.item_title = ? OR ai.item_title_fa = ?) AND ai.item_year = ?)';
                $params[] = $archiveNo;
                $params[] = $title;
                $params[] = $title;
                $params[] = $year;
            }

            $sql = "SELECT ai.virtual_movie_id, ai.archive_no, ai.slug, ai.item_link, ai.item_title, ai.item_title_fa, ai.item_year,
                           (SELECT COUNT(*) FROM archive1_comments c WHERE c.movie_id = ai.virtual_movie_id) AS comment_count
                    FROM archive1_items ai
                    WHERE " . implode(' OR ', $where) . "
                    LIMIT 30";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            if (!$rows) return $computedId;

            $scored = [];
            foreach ($rows as $row) {
                $id = (int)($row['virtual_movie_id'] ?? 0);
                if ($id <= 0) continue;
                $score = ($id === $computedId) ? 40 : 0;
                $rowSlug = bm_comment_normalize_identity((string)($row['slug'] ?? ''));
                if ($normalizedSlug !== '' && $rowSlug === $normalizedSlug) $score += 120;
                if ($normalizedLink !== '' && trim((string)($row['item_link'] ?? '')) === $normalizedLink) $score += 110;
                $rowTitleMatch = $title !== '' && (
                    trim((string)($row['item_title'] ?? '')) === $title ||
                    trim((string)($row['item_title_fa'] ?? '')) === $title
                );
                $rowYearMatch = $year !== '' && trim((string)($row['item_year'] ?? '')) === $year;
                if ($rowTitleMatch && $rowYearMatch) $score += 75;
                $count = (int)($row['comment_count'] ?? 0);
                $scored[] = ['id' => $id, 'score' => $score, 'comments' => $count];
            }
            if (!$scored) return $computedId;

            usort($scored, static function(array $a, array $b): int {
                $aRank = ($a['comments'] > 0 ? 1000000 : 0) + ($a['comments'] * 1000) + $a['score'];
                $bRank = ($b['comments'] > 0 ? 1000000 : 0) + ($b['comments'] * 1000) + $b['score'];
                return $bRank <=> $aRank;
            });
            $targetId = (int)$scored[0]['id'];
            if ($targetId <= 0) $targetId = $computedId;

            $mergeIds = [];
            foreach ($scored as $candidate) {
                if ((int)$candidate['id'] !== $targetId && (int)$candidate['score'] >= 75) {
                    $mergeIds[] = (int)$candidate['id'];
                }
            }
            $mergeIds = array_values(array_unique(array_filter($mergeIds)));
            if ($mergeIds) {
                $placeholders = implode(',', array_fill(0, count($mergeIds), '?'));
                $move = $pdo->prepare("UPDATE archive1_comments SET movie_id = ? WHERE movie_id IN ({$placeholders})");
                $move->execute(array_merge([$targetId], $mergeIds));
                error_log('BankMovie comment identity bridge merged IDs [' . implode(',', $mergeIds) . '] into ' . $targetId);
            }
            return $targetId;
        } catch (Throwable $e) {
            error_log('BankMovie comment identity bridge: ' . $e->getMessage());
            return $computedId;
        }
    }
}


// ====== BankMovie safe trailer extraction for Archive 1/3 ======
// UI/feature only: uses existing arc1 player handler; does not change player source/loading logic.
if (!function_exists('bm_movie_abs_url')) {
    function bm_movie_abs_url($url, $base) {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '') return '';
        if (preg_match('~^https?://~i', $url)) return $url;
        if (strpos($url, '//') === 0) return 'https:' . $url;
        $p = @parse_url($base);
        if (!$p || empty($p['scheme']) || empty($p['host'])) return $url;
        $root = $p['scheme'] . '://' . $p['host'];
        if (strpos($url, '/') === 0) return $root . $url;
        $dir = isset($p['path']) ? preg_replace('~/[^/]*$~', '/', $p['path']) : '/';
        return $root . $dir . $url;
    }
}
if (!function_exists('bm_movie_http_get')) {
    function bm_movie_http_get($url) {
        return bm_security_http_get_public(
            $url,
            9,
            5 * 1024 * 1024,
            ['Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'],
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) BankMovie/1.0'
        );
    }
}
if (!function_exists('bm_movie_extract_video_src')) {
    function bm_movie_extract_video_src($html, $baseUrl = '') {
        $html = (string)$html;
        if ($html === '') return '';

        $candidates = [];

        if (preg_match_all('~<video\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~<source\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~(?:file|src|source|url)\s*[:=]\s*["\']([^"\']+\.(?:mp4|mkv|m3u8)(?:\?[^"\']*)?)["\']~iu', $html, $m)) {
            foreach ($m[1] as $u) $candidates[] = $u;
        }
        if (preg_match_all('~https?://[^\s"\'<>]+?\.(?:mp4|mkv|m3u8)(?:\?[^\s"\'<>]+)?~iu', $html, $m)) {
            foreach ($m[0] as $u) $candidates[] = $u;
        }

        foreach ($candidates as $u) {
            $u = html_entity_decode(trim((string)$u), ENT_QUOTES | ENT_HTML5, 'UTF-8');
            if ($u === '') continue;
            if (!preg_match('~\.(mp4|mkv|m3u8)(?:\?|$)~i', $u)) continue;
            return bm_movie_abs_url($u, $baseUrl);
        }
        return '';
    }
}
if (!function_exists('bm_movie_find_trailer_url')) {
    function bm_movie_find_trailer_url($detailUrl) {
        $detailUrl = trim((string)$detailUrl);
        if ($detailUrl === '') return '';

        $html = bm_movie_http_get($detailUrl);
        if ($html === '') return '';

        // Oldtowns / آرشیو ۱ often keeps the trailer directly inside #trailerModal.
        if (preg_match('~id=["\']trailerModal["\'][\s\S]{0,6000}?<video\b[^>]*(?:src|data-src)=["\']([^"\']+)["\']~iu', $html, $m)) {
            $u = bm_movie_abs_url($m[1], $detailUrl);
            if (preg_match('~\.(mp4|mkv|m3u8)(?:\?|$)~i', $u)) return $u;
        }

        $direct = bm_movie_extract_video_src($html, $detailUrl);
        if ($direct !== '') return $direct;

        // PunkMovie usually exposes a playonline URL with trailer=1; fetch that page and extract its direct video source.
        $trailerPages = [];
        if (preg_match_all('~href=["\']([^"\']*(?:trailer=1|تریلر|trailer)[^"\']*)["\']~iu', $html, $m)) {
            foreach ($m[1] as $href) {
                $u = bm_movie_abs_url($href, $detailUrl);
                if ($u !== '' && !in_array($u, $trailerPages, true)) $trailerPages[] = $u;
            }
        }

        foreach ($trailerPages as $pageUrl) {
            $pageHtml = bm_movie_http_get($pageUrl);
            $src = bm_movie_extract_video_src($pageHtml, $pageUrl);
            if ($src !== '') return $src;
        }

        return '';
    }
}

// ====== BankMovie safe related movies extraction for Archive 1 / آرشیو ۱ ======
if (!function_exists('bm_arc1_clean_text')) {
    function bm_arc1_clean_text($text) {
        $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $text = preg_replace('~<[^>]+>~u', ' ', $text);
        $text = preg_replace('/\s+/u', ' ', $text);
        return trim($text);
    }
}
if (!function_exists('bm_arc1_detail_from_url')) {
    function bm_arc1_detail_from_url($href) {
        $href = html_entity_decode(trim((string)$href), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $path = trim((string)(parse_url($href, PHP_URL_PATH) ?? ''), '/');
        $parts = $path !== '' ? explode('/', $path) : [];
        $type = 'movie';
        $slug = '';
        $pos = array_search('series', $parts, true);
        if ($pos !== false && !empty($parts[$pos + 1])) {
            $type = 'series';
            $slug = 'series__' . $parts[$pos + 1];
        } elseif (count($parts) >= 2 && preg_match('/^\d+$/', $parts[0])) {
            $type = 'movie';
            $slug = $parts[0] . '__' . $parts[1];
        } elseif (!empty($parts)) {
            $last = end($parts);
            $type = (strpos($href, '/series/') !== false) ? 'series' : 'movie';
            $slug = ($type === 'series' ? 'series__' : '') . $last;
        }
        return ['slug' => $slug, 'type' => $type];
    }
}
if (!function_exists('bm_arc1_extract_img_from_article')) {
    function bm_arc1_extract_img_from_article($article, $baseUrl) {
        $img = '';
        if (preg_match('~<img\b[^>]*(?:data-splide-lazy|data-src|data-lazy-src)=["\']([^"\']+)["\']~iu', $article, $m)) {
            $img = $m[1];
        } elseif (preg_match('~<img\b[^>]*src=["\']([^"\']+)["\']~iu', $article, $m)) {
            $img = $m[1];
        }
        $img = html_entity_decode(trim($img), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($img === '' || strpos($img, 'data:image') === 0) return '';
        return bm_movie_abs_url($img, $baseUrl);
    }
}
if (!function_exists('bm_arc1_fetch_related_movies')) {
    function bm_arc1_fetch_related_movies($sourceUrl, $currentSlug = '', $limit = 12) {
        $sourceUrl = trim((string)$sourceUrl);
        if ($sourceUrl === '' || !preg_match('~^https?://~i', $sourceUrl)) return [];
        $html = bm_movie_http_get($sourceUrl);
        if ($html === '') return [];

        $relatedChunk = '';
        if (preg_match('~<section\b[^>]*id=["\']related-posts["\'][\s\S]{0,90000}</section>~iu', $html, $m)) {
            $relatedChunk = $m[0];
        } elseif (preg_match('~id=["\']related-posts["\'][\s\S]{0,90000}~iu', $html, $m)) {
            $relatedChunk = $m[0];
        }
        if ($relatedChunk === '') return [];

        $items = [];
        $seen = [];
        if (preg_match_all('~<article\b[^>]*class=["\'][^"\']*\bentry\b[^"\']*["\'][\s\S]*?</article>~iu', $relatedChunk, $cards)) {
            foreach ($cards[0] as $article) {
                if (count($items) >= $limit) break;

                $href = '';
                if (preg_match('~<a\b[^>]*href=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*stretched-link[^"\']*["\']~iu', $article, $m) ||
                    preg_match('~<a\b[^>]*class=["\'][^"\']*stretched-link[^"\']*["\'][^>]*href=["\']([^"\']+)["\']~iu', $article, $m) ||
                    preg_match('~<a\b[^>]*href=["\']([^"\']+)["\']~iu', $article, $m)) {
                    $href = bm_movie_abs_url($m[1], $sourceUrl);
                }
                if ($href === '') continue;

                $detail = bm_arc1_detail_from_url($href);
                if (empty($detail['slug']) || $detail['slug'] === $currentSlug) continue;
                if (isset($seen[$detail['slug']])) continue;
                $seen[$detail['slug']] = true;

                $title = '';
                if (preg_match('~<h2\b[^>]*class=["\'][^"\']*\bentry-title\b[^"\']*["\'][^>]*>([\s\S]*?)</h2>~iu', $article, $m)) {
                    $title = bm_arc1_clean_text($m[1]);
                }
                if ($title === '' && preg_match('~title=["\']([^"\']+)["\']~iu', $article, $m)) $title = bm_arc1_clean_text($m[1]);
                if ($title === '') continue;

                $poster = bm_arc1_extract_img_from_article($article, $sourceUrl);
                $rating = '';
                if (preg_match('/(\d+(?:\.\d+)?)\s*\/\s*10/u', bm_arc1_clean_text($article), $m)) $rating = $m[1];
                $year = '';
                if (preg_match('/\b(19|20)\d{2}\b/u', bm_arc1_clean_text($article), $m)) $year = $m[0];
                $note = '';
                if (preg_match('~<p\b[^>]*class=["\'][^"\']*text-muted[^"\']*["\'][^>]*>([\s\S]*?)</p>~iu', $article, $m)) $note = bm_arc1_clean_text($m[1]);

                $items[] = [
                    'title' => $title,
                    'poster' => $poster,
                    'rating' => $rating,
                    'year' => $year,
                    'note' => $note,
                    'type' => $detail['type'],
                    'slug' => $detail['slug'],
                    'url' => '/movie.php?arc=1&slug=' . rawurlencode($detail['slug']) . '&type=' . rawurlencode($detail['type'])
                ];
            }
        }
        return $items;
    }
}





/* V11 hotfix: helpers used during Archive 1 data parsing must exist before $arc1Data processing */
if (!function_exists('bm_actor_placeholder_svg')) {
    function bm_actor_placeholder_svg($name = '') {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="220" height="220" viewBox="0 0 220 220">
            <defs>
                <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#111827"/>
                    <stop offset=".52" stop-color="#171a28"/>
                    <stop offset="1" stop-color="#05070b"/>
                </linearGradient>
                <radialGradient id="glowA" cx=".30" cy=".18" r=".8">
                    <stop offset="0" stop-color="#36ff9f" stop-opacity=".42"/>
                    <stop offset=".56" stop-color="#36ff9f" stop-opacity=".08"/>
                    <stop offset="1" stop-color="#36ff9f" stop-opacity="0"/>
                </radialGradient>
                <radialGradient id="glowB" cx=".85" cy=".12" r=".9">
                    <stop offset="0" stop-color="#7b2cff" stop-opacity=".34"/>
                    <stop offset=".54" stop-color="#7b2cff" stop-opacity=".08"/>
                    <stop offset="1" stop-color="#7b2cff" stop-opacity="0"/>
                </radialGradient>
                <linearGradient id="strokeG" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#36ff9f"/>
                    <stop offset="1" stop-color="#8b5cf6"/>
                </linearGradient>
                <filter id="soft"><feGaussianBlur stdDeviation="13"/></filter>
            </defs>
            <rect width="220" height="220" rx="48" fill="url(#bg)"/>
            <rect width="220" height="220" rx="48" fill="url(#glowA)"/>
            <rect width="220" height="220" rx="48" fill="url(#glowB)"/>
            <circle cx="48" cy="42" r="42" fill="#36ff9f" opacity=".14" filter="url(#soft)"/>
            <circle cx="178" cy="42" r="50" fill="#8b5cf6" opacity=".16" filter="url(#soft)"/>
            <circle cx="110" cy="103" r="61" fill="#0b0f17" opacity=".96" stroke="url(#strokeG)" stroke-width="3"/>
            <circle cx="110" cy="82" r="29" fill="#f8fafc" opacity=".88"/>
            <path d="M58 165c9-34 29-52 52-52s43 18 52 52" fill="#f8fafc" opacity=".82"/>
            <path d="M72 164c8-20 22-31 38-31s30 11 38 31" fill="#dbeafe" opacity=".18"/>
            <path d="M63 184h94" stroke="#ffffff" stroke-opacity=".12" stroke-width="3" stroke-linecap="round"/>
            <path d="M78 191h64" stroke="#36ff9f" stroke-opacity=".18" stroke-width="2" stroke-linecap="round"/>
        </svg>';
        return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
    }
}

if (!function_exists('bm_actor_slug_from_url')) {
    function bm_actor_slug_from_url($url) {
        $url = trim((string)$url);
        if ($url === '') return '';
        $path = trim((string)(parse_url($url, PHP_URL_PATH) ?? ''), '/');
        if ($path === '') return '';
        $parts = explode('/', $path);
        $pos = array_search('actors', $parts, true);
        if ($pos !== false && !empty($parts[$pos + 1])) return trim((string)$parts[$pos + 1]);
        return trim((string)end($parts));
    }
}


if (!function_exists('bm_actor_is_bad_placeholder_image')) {
    function bm_actor_is_bad_placeholder_image($url) {
        $u = strtolower(html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($u === '') return true;

        // Source placeholders are often inline SVGs or generic profile/avatar images.
        if (strpos($u, 'data:image/svg') === 0) return true;
        if (strpos($u, '<svg') !== false || strpos($u, '%3csvg') !== false) return true;

        $badNeedles = [
            'placeholder', 'no-image', 'no_image', 'no-photo', 'no_photo',
            'default-user', 'default_avatar', 'default-avatar',
            'user-profile', 'profile-user', 'profile.png', 'avatar.png',
            'person-placeholder', 'unknown-person', 'empty-profile',
            'profile-placeholder'
        ];
        foreach ($badNeedles as $needle) {
            if (strpos($u, $needle) !== false) return true;
        }

        return false;
    }
}

if (!function_exists('bm_normalize_arc1_actors')) {
    function bm_normalize_arc1_actors($actorsRaw) {
        $actors = [];
        if (is_string($actorsRaw)) {
            $parts = preg_split('/\s*,\s*/u', $actorsRaw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p !== '') $actors[] = ['name' => $p, 'role' => '', 'image' => '', 'url' => '', 'bankmovie_url' => ''];
            }
            return $actors;
        }
        if (!is_array($actorsRaw)) return [];
        $seen = [];
        foreach ($actorsRaw as $a) {
            if (is_string($a)) {
                $name = trim($a);
                $role = $image = $url = $bankUrl = '';
            } elseif (is_array($a)) {
                $name = trim((string)($a['name'] ?? $a['title'] ?? ''));
                $role = trim((string)($a['role'] ?? $a['character'] ?? ''));
                $image = trim((string)($a['image'] ?? $a['photo'] ?? $a['poster'] ?? ''));
                $url = trim((string)($a['url'] ?? $a['source_url'] ?? ''));
                $bankUrl = trim((string)($a['bankmovie_url'] ?? ''));
                if ($bankUrl === '' && !empty($a['slug'])) {
                    $bankUrl = '/actors?slug=' . rawurlencode((string)$a['slug']);
                } elseif ($bankUrl === '' && $url !== '') {
                    $slugFromUrl = bm_actor_slug_from_url($url);
                    if ($slugFromUrl !== '') $bankUrl = '/actors?slug=' . rawurlencode($slugFromUrl);
                }
            } else {
                continue;
            }
            if ($name === '') continue;
            // V225: actor page can render a correct profile shell even when
            // Archive 1 is temporarily unavailable.
            if ($bankUrl !== '' && (str_starts_with($bankUrl, '/actors?') || str_starts_with($bankUrl, 'actors?'))) {
                $q = (string)(parse_url($bankUrl, PHP_URL_QUERY) ?? '');
                parse_str($q, $actorLinkQuery);
                if (empty($actorLinkQuery['name'])) {
                    $bankUrl .= (str_contains($bankUrl, '?') ? '&' : '?') . 'name=' . rawurlencode($name);
                }
            }
            if (function_exists('bm_actor_is_bad_placeholder_image') && bm_actor_is_bad_placeholder_image($image)) $image = '';
            $key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $actors[] = ['name' => $name, 'role' => $role, 'image' => $image, 'url' => $url, 'bankmovie_url' => $bankUrl];
        }
        return $actors;
    }
}


// اگر آرشیو ۱ است، داده را از api2_lib بگیر
$arc1Data  = null;
$arc1Error = null;
$arc1RelatedMovies = [];
if ($isArc1 && $arc1Slug !== '' && !$bmArchiveBlocked) {
    // جزئیات آرشیو خارجی با کش stale-while-revalidate خوانده می‌شود:
    // پاسخ قدیمی سالم فوراً نمایش داده می‌شود و بروزرسانی بعد از ارسال صفحه انجام می‌شود.
    try {
        $archiveCacheName = $isArc7 ? 'archive7' : ($isArc6 ? 'archive6' : ($isArc5 ? 'archive5' : ($isArc4 ? 'archive4' : ($isArc3 ? 'archive3' : 'archive1'))));
        $archiveCacheKey = $arc1Slug . '|' . (string)$arc1Type
            . ($isArc7 ? '|a7-auth-page-v3' : ($isArc6 ? '|api7-login-page-v2' : ($isArc5 ? '|api5-json-v4-local-pagination-direct-fallback' : ($isArc4 ? '|cinamatic-vlc-stream-compat-v79'
                : ($isArc3 ? '|subtitle-v14861926' : '|arc1-dual-softsub-v2')))))
            . '|source=' . bm_archive_source_base_url($bmCurrentArchiveId, '');
        $detailLoader = static function () use ($isArc7, $isArc6, $isArc5, $isArc4, $isArc3, $arc1Slug, $arc1Type): array {
            if ($isArc7) {
                require_once __DIR__ . '/includes/archive7_movie_bridge.php';
                $data = bm_a7_bankmovie_detail($arc1Slug);
            } elseif ($isArc6) {
                require_once __DIR__ . '/includes/api7_movie_bridge.php';
                $data = bm_a6_bankmovie_detail($arc1Slug);
            } elseif ($isArc5) {
                if (!function_exists('fitlinerim_get_details')) require_once __DIR__ . '/includes/api5_archive5_lib.php';
                $data = fitlinerim_get_details($arc1Slug, $arc1Type);
            } elseif ($isArc4) {
                if (!function_exists('api4_get_details')) require_once __DIR__ . '/includes/api4_lib.php';
                $data = api4_get_details($arc1Slug);
            } elseif ($isArc3) {
                if (!function_exists('api6_get_details')) require_once __DIR__ . '/includes/api6_lib.php';
                $data = api6_get_details($arc1Slug);
            } else {
                if (!function_exists('getMovieDetails')) require_once __DIR__ . '/includes/api2_lib.php';
                $data = getMovieDetails($arc1Slug, $arc1Type);
            }
            if (!is_array($data) || !$data || (($data['status'] ?? '') === 'error' && empty($data['title']))) {
                throw new RuntimeException((string)($data['message'] ?? 'اطلاعات آرشیو دریافت نشد.'));
            }
            return $data;
        };
        bm_perf_mark('external-detail-start', ['archive' => $archiveCacheName]);
        // Archive 4 carries expiring signed playback URLs; like login-scoped Archive 6/7 links, do not persist parsed URLs in a shared stale detail cache. The API4 HTML cache still avoids refetching the source page on every request.
        $arc1Data = ($isArc4 || $isArc6 || $isArc7) ? $detailLoader() : bm_detail_cache_get($archiveCacheName, $archiveCacheKey, $detailLoader, 600, 604800);
        $bmArchiveItemMediaBlocked = bm_archive_item_media_blocked($bmCurrentArchiveId, $arc1Data, ['identifier'=>$arc1Slug]);
        $bmArchiveItemDownloadBlocked = $bmArchiveItemMediaBlocked;
        if ($bmArchiveItemMediaBlocked) {
            $bmArchiveDownloadAllowed = false;
            $bmArchiveStreamAllowed = false;
            $GLOBALS['bmArchiveDownloadAllowed'] = false;
            $GLOBALS['bmArchiveStreamAllowed'] = false;
        }
        bm_perf_mark('external-detail-ready', ['archive' => $archiveCacheName]);
        bm_perf_context(['archive' => $archiveCacheName, 'slug' => $arc1Slug]);
    } catch (Throwable $ex) {
        $rawArchiveError = $ex->getMessage();
        $arc1Error = $isArc7 ? 'اطلاعات آرشیو ۷ در دسترس نیست؛ اتصال لاگین را بررسی کنید.' : ($isArc6 ? 'اطلاعات آرشیو ۶ موقتاً در دسترس نیست؛ ورود مدیر را بررسی کنید.' : ($isArc5 ? 'اطلاعات آرشیو 5 موقتاً در دسترس نیست.' : $rawArchiveError));
        bm_perf_note('external_detail_error', $rawArchiveError);
    }
    if (!$arc1Data && !$arc1Error) $arc1Error = 'اطلاعات دریافت نشد';

    if ($arc1Data) {
        $arc1Title        = $arc1Data['title_fa'] ?? ($arc1Data['title'] ?? '');
        if (trim((string)$arc1Title) === '') $arc1Title = $arc1Data['title'] ?? '';
        $arc1TitleEn      = trim((string)($arc1Data['title'] ?? ''));
        if ($arc1TitleEn === trim((string)$arc1Title)) $arc1TitleEn = '';
        $arc1Year         = $arc1Data['year'] ?? '';
        $arc1PosterRaw    = $arc1Data['poster'] ?? null;
        $arc1Poster       = is_array($arc1PosterRaw) ? ($arc1PosterRaw['full'] ?? ($arc1PosterRaw['medium'] ?? null)) : $arc1PosterRaw;
        $arc1Poster       = bm_ext_safe_url($arc1Poster);
        // V119: use the real source backdrop when available; fall back to the poster only when needed.
        $arc1BackdropRaw  = $arc1Data['backdrop'] ?? ($arc1Data['background'] ?? ($arc1Data['cover'] ?? ''));
        if (is_array($arc1BackdropRaw)) {
            $arc1BackdropRaw = $arc1BackdropRaw['full'] ?? ($arc1BackdropRaw['large'] ?? ($arc1BackdropRaw['medium'] ?? ''));
        }
        $arc1Backdrop     = bm_ext_safe_url($arc1BackdropRaw);
        $arc1HeroBg       = $arc1Backdrop ?: $arc1Poster;
        $arc1HeroPosterFallback = ($arc1Backdrop === '' || $arc1HeroBg === $arc1Poster);
        $arc1Desc         = $arc1Data['description'] ?? ($arc1Data['long_description'] ?? '');
        $arc1RatingRaw    = $arc1Data['rating'] ?? null;
        $arc1ImdbRate     = is_array($arc1RatingRaw) ? ($arc1RatingRaw['imdb'] ?? null) : $arc1RatingRaw;
        $arc1Satisfaction = is_array($arc1RatingRaw) ? ($arc1RatingRaw['feedback_satisfaction'] ?? null) : null;
        $arc1AgeRate      = trim((string)($arc1Data['age_rate'] ?? ($arc1Data['rated'] ?? '')));
        $arc1HasDub       = $arc1Data['has_dubbed'] ?? false;
        $arc1HasSub       = $arc1Data['has_subtitle'] ?? false;
        $arc1TypeSignal   = strtolower(trim((string)($arc1Data['type'] ?? '') . ' ' . (string)($arc1Type ?? '') . ' ' . (string)$arc1Slug));
        $arc1IsSeries     = (($arc1Data['type'] ?? '') === 'series')
            || (($arc1Type ?? '') === 'series')
            || preg_match('~(?:^|[-_/])series(?:[-_/]|$)|(?:^|[-_/])serial(?:[-_/]|$)~i', $arc1TypeSignal) === 1;
        $arc1Genres       = $arc1Data['genres'] ?? [];
        $arc1Countries    = $arc1Data['countries'] ?? ($arc1Data['country'] ?? []);
        $arc1Runtime      = trim((string)($arc1Data['runtime'] ?? ($arc1Data['duration'] ?? '')));
        $arc1ReleaseDate  = trim((string)($arc1Data['release_date'] ?? ''));
        $arc1PublishDate  = trim((string)($arc1Data['published_date'] ?? ($arc1Data['publish_date'] ?? '')));
        $arc1StatusText   = trim((string)($arc1Data['status_text'] ?? ($arc1Data['status'] ?? '')));
        $arc1LanguageText = trim((string)($arc1Data['language'] ?? ''));
        if ($arc1LanguageText === '' && !empty($arc1Data['languages']) && is_array($arc1Data['languages'])) $arc1LanguageText = implode('، ', $arc1Data['languages']);
        $arc1Network      = trim((string)($arc1Data['network'] ?? ''));
        $arc1NextEpisode  = trim((string)($arc1Data['next_episode'] ?? ''));
        $arc1EpisodeNote  = trim((string)($arc1Data['episode_note'] ?? ''));
        $arc1Actors       = bm_normalize_arc1_actors($arc1Data['actors'] ?? ($arc1Data['cast'] ?? ($arc1Data['actors_text'] ?? [])));
        $bmArchiveSourceFallback = bm_archive_source_base_url($bmCurrentArchiveId, $isArc4 ? 'https://cinamatic.top' : ($isArc3 ? 'https://dornatv.com' : 'https://www.my-f2mx.top'));
        if ($isArc7) {
            $arc1SourceUrl = '/movie/arc7-' . rawurlencode((string)$arc1Slug);
        } elseif ($isArc6) {
            $arc1SourceUrl = '/movie/arc6-' . rawurlencode((string)$arc1Slug);
        } elseif ($isArc5) {
            // Archive 5 never exposes its upstream address. Internal canonical URL only.
            $arc1SourceUrl = '/movie/arc5-' . rawurlencode((string)$arc1Slug);
        } else {
            $arc1SourceUrl = $arc1Data['source_url'] ?? ($arc1Data['url'] ?? (rtrim($bmArchiveSourceFallback, '/') . '/' . ($arc1IsSeries && !$isArc3 && !$isArc4 ? 'series/' : '') . ltrim((string)$arc1Slug, '/') . '/'));
            $arc1SourceUrl = bm_ext_safe_url($arc1SourceUrl);
        }
        $arc1Downloads    = $arc1Data['downloads'] ?? [];
        // V128: API 1/3 sometimes return type=movie while download rows clearly contain season/episode aliases.
        // The actual rows are authoritative so the series UI and bulk-link tool stay available.
        if (!$arc1IsSeries && is_array($arc1Downloads)) {
            foreach ($arc1Downloads as $bmArcSeriesRow) {
                if (!is_array($bmArcSeriesRow)) continue;
                $bmArcSeriesLabel = strtolower(trim((string)($bmArcSeriesRow['label'] ?? '') . ' ' . (string)($bmArcSeriesRow['display_label'] ?? '') . ' ' . (string)($bmArcSeriesRow['title'] ?? '')));
                $bmArcSeasonValue = $bmArcSeriesRow['season'] ?? ($bmArcSeriesRow['season_number'] ?? ($bmArcSeriesRow['season_no'] ?? null));
                $bmArcEpisodeValue = $bmArcSeriesRow['episode'] ?? ($bmArcSeriesRow['episode_number'] ?? ($bmArcSeriesRow['episode_no'] ?? null));
                if ($bmArcSeasonValue !== null || $bmArcEpisodeValue !== null || preg_match('/(?:فصل|قسمت|season|episode|\bS\d{1,2}E\d{1,3}\b)/iu', $bmArcSeriesLabel)) {
                    $arc1IsSeries = true;
                    break;
                }
            }
        }

        // DL1 poster redirect: keep the original source private and expose a stable BankMovie poster URL.
        if ($arc1Poster !== '' && function_exists('bm_poster_wrap_url')) {
            $arc1Poster = bm_poster_wrap_url($arc1Poster, [
                'type' => $arc1IsSeries ? 'series' : 'movie',
                'title' => $arc1TitleEn !== '' ? $arc1TitleEn : $arc1Title,
                'title_fa' => $arc1Title,
                'year' => $arc1Year,
            ]);
            if (!empty($arc1HeroPosterFallback)) $arc1HeroBg = $arc1Poster;
        }
        // آرشیو ۱: پیش‌فرض سافت‌ساب است؛ فقط سریال‌های ترکی و کره‌ای هاردساب نمایش داده می‌شوند.
        $bmArc1CountryParts = [];
        if (is_array($arc1Countries)) {
            foreach ($arc1Countries as $bmArc1CountryItem) {
                if (is_array($bmArc1CountryItem)) {
                    $bmArc1CountryItem = $bmArc1CountryItem['name_fa'] ?? ($bmArc1CountryItem['name'] ?? ($bmArc1CountryItem['title'] ?? ''));
                }
                $bmArc1CountryItem = trim((string)$bmArc1CountryItem);
                if ($bmArc1CountryItem !== '') $bmArc1CountryParts[] = $bmArc1CountryItem;
            }
        } else {
            $bmArc1CountryValue = trim((string)$arc1Countries);
            if ($bmArc1CountryValue !== '') $bmArc1CountryParts[] = $bmArc1CountryValue;
        }
        $bmArc1SubtitleSignal = implode(' ', $bmArc1CountryParts) . ' ' . $arc1LanguageText . ' ' . $arc1Title . ' ' . $arc1TitleEn;
        $bmArc1UseHardSub = $bmCurrentArchiveId === 'archive1'
            && $arc1IsSeries
            && preg_match('~(?:ترکیه|ترکی|turkey|turkish|کره(?:\\s*جنوبی)?|korea|korean)~iu', $bmArc1SubtitleSignal) === 1;
        if ($bmCurrentArchiveId === 'archive1') {
            $bmArchiveSubFa = $bmArc1UseHardSub ? 'هاردساب' : 'سافت‌ساب';
            $bmArchiveSubEn = $bmArc1UseHardSub ? 'Hard Sub' : 'Soft Sub';
        }

        $arc1TrailerUrl   = bm_ext_safe_url(trim((string)($arc1Data['trailer_url'] ?? $arc1Data['trailer'] ?? '')));
        if (!$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7 && $arc1TrailerUrl === '' && !empty($arc1SourceUrl)) {
            // Fallback تریلر دیگر درخواست کاربر را متوقف نمی‌کند؛ نتیجه کش‌شده
            // فوراً استفاده می‌شود و دریافت تازه بعد از ارسال صفحه انجام می‌شود.
            $trailerKey = $arc1SourceUrl . '|trailer';
            $trailerCached = bm_detail_cache_read('archive-trailer', $trailerKey, 3600, 86400);
            if ($trailerCached && !empty($trailerCached['data']['url'])) {
                $arc1TrailerUrl = bm_ext_safe_url($trailerCached['data']['url']);
            } else {
                bm_detail_cache_schedule_refresh('archive-trailer', $trailerKey, static function () use ($arc1SourceUrl): array {
                    return ['url' => bm_movie_find_trailer_url($arc1SourceUrl)];
                });
            }
        }
        if (!$isArc3 && !$isArc4 && !$isArc5 && !$isArc6 && !$isArc7) {
            if (!empty($arc1Data['related_movies']) && is_array($arc1Data['related_movies'])) {
                $arc1RelatedMovies = $arc1Data['related_movies'];
            } elseif (!empty($arc1Data['related']) && is_array($arc1Data['related'])) {
                $arc1RelatedMovies = $arc1Data['related'];
            } elseif (!empty($arc1SourceUrl)) {
                // پیشنهادها نیز از مسیر درخواست اصلی جدا شده‌اند.
                $relatedKey = $arc1SourceUrl . '|' . $arc1Slug . '|related';
                $relatedCached = bm_detail_cache_read('archive-related', $relatedKey, 1800, 21600);
                if ($relatedCached && isset($relatedCached['data']['items']) && is_array($relatedCached['data']['items'])) {
                    $arc1RelatedMovies = $relatedCached['data']['items'];
                } else {
                    bm_detail_cache_schedule_refresh('archive-related', $relatedKey, static function () use ($arc1SourceUrl, $arc1Slug): array {
                        return ['items' => bm_arc1_fetch_related_movies($arc1SourceUrl, $arc1Slug, 12)];
                    });
                }
            }
        }
        if ($arc1RelatedMovies && function_exists('bm_poster_wrap_payload')) {
            $arc1RelatedMovies = bm_poster_wrap_payload($arc1RelatedMovies);
        }

        // پردازش دانلودها؛ برای آرشیو ۳ فقط لینک‌های مستقیم ویدیو/استریم وارد پلیر داخلی می‌شوند.
        $arc1MovieDub  = [];
        $arc1MovieSoft = [];
        $arc1SeriesSeasons = [];
        $seenArcLinks = [];
        $arc1HasDubAudio = !empty($arc1Data['has_dubbed_audio']);
        $arc1HasSoftSub = !empty($arc1Data['has_softsub']);
        $arc1HasHardSub = !empty($arc1Data['has_hardsub']);
        $arc1HasGenericSub = $arc1HasSub && !$arc1HasSoftSub && !$arc1HasHardSub;

        /* v148.61.8: Archive 3 can expose a separate manual subtitle link beside the video link. */
        $bmArc3SubtitlePool = [];
        if (($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) && is_array($arc1Downloads)) {
            foreach ($arc1Downloads as $bmArc3SubRow) {
                if (!is_array($bmArc3SubRow)) continue;
                $bmArc3SubUrl = trim((string)($bmArc3SubRow['subtitle_url'] ?? ''));
                $bmArc3RowUrl = trim((string)($bmArc3SubRow['url'] ?? ''));
                $bmArc3Signal = strtolower(trim((string)($bmArc3SubRow['label'] ?? '') . ' ' . (string)($bmArc3SubRow['display_label'] ?? '') . ' ' . (string)($bmArc3SubRow['media_type'] ?? '') . ' ' . $bmArc3RowUrl));
                if ($bmArc3SubUrl === '' && (preg_match('~\.(?:srt|vtt|ass|ssa)(?:[?#]|$)~i', $bmArc3RowUrl) || preg_match('/زیر\s*نویس|subtitle|\bsrt\b|\bvtt\b|\bass\b|\bssa\b/ui', $bmArc3Signal))) {
                    if (preg_match('~\.(?:srt|vtt|ass|ssa)(?:[?#]|$)~i', $bmArc3RowUrl)) $bmArc3SubUrl = $bmArc3RowUrl;
                }
                $bmArc3SubUrl = bm_ext_safe_url($bmArc3SubUrl);
                if ($bmArc3SubUrl === '') continue;
                $bmArc3SubtitlePool[] = [
                    'url' => $bmArc3SubUrl,
                    'quality' => trim((string)($bmArc3SubRow['quality'] ?? '')),
                    'season' => $bmArc3SubRow['season'] ?? ($bmArc3SubRow['season_number'] ?? null),
                    'episode' => $bmArc3SubRow['episode'] ?? ($bmArc3SubRow['episode_number'] ?? null),
                ];
            }
        }
        $bmArc3FindSubtitle = static function (array $row, string $quality) use (&$bmArc3SubtitlePool): string {
            $own = bm_ext_safe_url($row['subtitle_url'] ?? '');
            if ($own !== '') return $own;
            if (!$bmArc3SubtitlePool) return '';
            $season = $row['season'] ?? ($row['season_number'] ?? null);
            $episode = $row['episode'] ?? ($row['episode_number'] ?? null);
            $best = '';
            $bestScore = -1;
            foreach ($bmArc3SubtitlePool as $candidate) {
                $score = 0;
                $cs = $candidate['season'];
                $ce = $candidate['episode'];
                if ($season !== null && $cs !== null) {
                    if ((int)$season !== (int)$cs) continue;
                    $score += 5;
                }
                if ($episode !== null && $ce !== null) {
                    if ((int)$episode !== (int)$ce) continue;
                    $score += 8;
                }
                if ($quality !== '' && $candidate['quality'] !== '' && strcasecmp($quality, (string)$candidate['quality']) === 0) $score += 3;
                if ($score > $bestScore) { $bestScore = $score; $best = (string)$candidate['url']; }
            }
            return $best;
        };

        if (!empty($arc1Downloads)) {
            // Real download links are authoritative. Do not trust only poster/source badges.
            $arc1HasDub = false;
            $arc1HasSub = false;
            $arc1HasDubAudio = false;
            $arc1HasSoftSub = false;
            $arc1HasHardSub = false;
            $arc1HasGenericSub = false;
        }
        foreach ($arc1Downloads as $dl) {
            $q    = trim((string)($dl['quality'] ?? ''));
            if ($q === '') $q = 'نامشخص';
            $u    = trim((string)($dl['url'] ?? ''));
            if (!$u) continue;
            $mediaType = strtolower((string)($dl['media_type'] ?? ''));
            $isAudioOnly = !empty($dl['audio_only']) || $mediaType === 'audio' || preg_match('~\.(mka|mp3|m4a|aac|ogg|wav|flac)(?:[?#]|$)~i', $u);
            if (($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) && !preg_match('~\.(mkv|mp4|avi|m3u8|webm|mov)(?:[?#]|$)~i', $u)) continue;
            if (isset($seenArcLinks[$u])) continue;
            $seenArcLinks[$u] = true;

            if ($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) {
                $sourceType = strtolower(trim((string)($dl['type'] ?? '')));
                $typeText = strtolower((string)($dl['label'] ?? '') . ' ' . (string)($dl['display_label'] ?? '') . ' ' . $u . ' ' . $sourceType);
                // Explicit source type outranks a conflicting free-text release description.
                if (in_array($sourceType, ['dub','dubbed','audio'], true)) $type = 'dub';
                elseif ($sourceType === 'softsub') $type = 'softsub';
                elseif ($sourceType === 'hardsub') $type = 'hardsub';
                elseif (in_array($sourceType, ['original','nosub'], true)) $type = $sourceType;
                elseif ($sourceType === 'subtitle') $type = 'subtitle';
                else {
                    $textDub = strpos($typeText, 'dubbed') !== false || strpos($typeText, 'دوبله') !== false || preg_match('/(?:^|[._-])duble(?:[._-]|$)/i', $typeText);
                    $textHard = (bool)preg_match('/hard[ ._-]*sub|hardsub|هارد\s*[‌ ]?ساب/u', $typeText);
                    $textSoft = (bool)preg_match('/soft[ ._-]*sub|softsub|سافت\s*[‌ ]?ساب/u', $typeText);
                    if ($textDub) $type = 'dub';
                    elseif ($textHard && !$textSoft) $type = 'hardsub';
                    elseif ($textSoft && !$textHard) $type = 'softsub';
                    else $type = 'subtitle'; // Ambiguous labels must not assert hard or soft.
                }
            } else {
                $bmArc1RawType = strtolower(trim((string)($dl['type'] ?? '')));
                $bmArc1TypeText = strtolower((string)($dl['label'] ?? '') . ' ' . (string)($dl['display_label'] ?? '') . ' ' . $u . ' ' . $bmArc1RawType);
                $bmArc1IsDub = in_array($bmArc1RawType, ['dub','dubbed','audio'], true)
                    || strpos($bmArc1TypeText, 'dubbed') !== false
                    || strpos($bmArc1TypeText, 'دوبله') !== false;
                $bmArc1IsNoSub = in_array($bmArc1RawType, ['nosub','no-sub','none'], true)
                    || strpos($bmArc1TypeText, 'nosub') !== false
                    || strpos($bmArc1TypeText, 'no-sub') !== false
                    || strpos($bmArc1TypeText, 'بدون زیرنویس') !== false;
                $bmArc1IsSoftSub = $bmArc1RawType === 'softsub'
                    || strpos($bmArc1TypeText, 'farsi.sub') !== false
                    || strpos($bmArc1TypeText, 'softsub') !== false
                    || strpos($bmArc1TypeText, 'soft.sub') !== false
                    || strpos($bmArc1TypeText, 'soft-sub') !== false
                    || strpos($bmArc1TypeText, 'سافت ساب') !== false
                    || strpos($bmArc1TypeText, 'سافت‌ساب') !== false;
                $bmArc1IsHardSub = $bmArc1RawType === 'hardsub'
                    || strpos($bmArc1TypeText, 'hardsub') !== false
                    || strpos($bmArc1TypeText, 'hard.sub') !== false
                    || strpos($bmArc1TypeText, 'hard-sub') !== false
                    || strpos($bmArc1TypeText, 'هارد ساب') !== false
                    || strpos($bmArc1TypeText, 'هاردساب') !== false;
                if (in_array($bmArc1RawType, ['dub','dubbed','audio'], true)) $type = 'dub';
                elseif ($bmArc1RawType === 'softsub') $type = 'softsub';
                elseif ($bmArc1RawType === 'hardsub') $type = 'hardsub';
                elseif ($bmArc1IsDub) $type = 'dub';
                elseif ($bmArc1IsNoSub) $type = 'nosub';
                elseif ($bmArc1IsSoftSub && !$bmArc1IsHardSub) $type = 'softsub';
                elseif ($bmArc1IsHardSub && !$bmArc1IsSoftSub) $type = 'hardsub';
                elseif ($bmArc1IsSoftSub && $bmArc1IsHardSub) $type = 'subtitle';
                elseif ($bmArc1RawType === 'subtitle') $type = $bmArc1UseHardSub ? 'hardsub' : 'softsub';
                else $type = $bmArc1UseHardSub ? 'hardsub' : 'softsub';
            }
            if ($type === 'dub') {
                if ($isAudioOnly) $arc1HasDubAudio = true;
                else $arc1HasDub = true;
            } else {
                if (!$isAudioOnly && $type !== 'nosub' && $type !== 'original') {
                    $arc1HasSub = true;
                    if ($type === 'softsub') $arc1HasSoftSub = true;
                    elseif ($type === 'hardsub') $arc1HasHardSub = true;
                    else $arc1HasGenericSub = true;
                }
            }

            if ($arc1IsSeries) {
                $seasonRaw = $dl['season'] ?? ($dl['season_number'] ?? ($dl['season_no'] ?? null));
                $episodeRaw = $dl['episode'] ?? ($dl['episode_number'] ?? ($dl['episode_no'] ?? null));
                $seriesRowLabel = (string)($dl['label'] ?? '') . ' ' . (string)($dl['display_label'] ?? '') . ' ' . (string)($dl['title'] ?? '');
                if ($seasonRaw === null && preg_match('/(?:فصل|season|\bS)\s*[-_:]?\s*([۰-۹0-9]{1,2})/iu', $seriesRowLabel, $bmSeasonMatch)) $seasonRaw = $bmSeasonMatch[1];
                if ($episodeRaw === null && preg_match('/(?:قسمت|episode|\bE)\s*[-_:]?\s*([۰-۹0-9]{1,3})/iu', $seriesRowLabel, $bmEpisodeMatch)) $episodeRaw = $bmEpisodeMatch[1];
                $toLatinDigits = static function ($value): string {
                    return strtr((string)$value, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9']);
                };
                $s  = max(1, (int)$toLatinDigits($seasonRaw ?? 1));
                $ep = max(0, (int)$toLatinDigits($episodeRaw ?? 0));
                $sk = 'S'.str_pad((string)$s,2,'0',STR_PAD_LEFT);
                $ek = $ep > 0 ? ('E'.str_pad((string)$ep,2,'0',STR_PAD_LEFT)) : 'full';
                $bmMatchedSubtitleUrl = ($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) ? $bmArc3FindSubtitle((array)$dl, $q) : bm_ext_safe_url($dl['subtitle_url'] ?? '');
                $arc1SeriesSeasons[$sk][$ek][] = ['quality'=>$q,'type'=>$type,'url'=>$u,'size'=>$dl['size']??'','is_audio'=>$isAudioOnly,'media_type'=>$mediaType,'audio_label'=>trim((string)($dl['dub_source'] ?? $dl['audio_source'] ?? $dl['studio'] ?? $dl['audio_label'] ?? $dl['display_label'] ?? $dl['label'] ?? '')),'audio_origin'=>array_intersect_key((array)$dl, array_flip(['dub_name','dub_source','audio_source','studio','audio_label','display_label','label','title','description','details'])),'version_note'=>trim((string)($dl['version_note'] ?? $dl['technical_note'] ?? $dl['notes'] ?? $dl['description'] ?? $dl['details'] ?? '')),'release_name'=>trim((string)($dl['release_name'] ?? $dl['filename'] ?? '')),'source_download_locked'=>!empty($dl['source_download_locked']),'subtitle_url'=>$bmMatchedSubtitleUrl,'meta'=>($isArc6 ? bm_a6_visible_meta(bm_arc1_download_meta((array)$dl,$q,$u,$isAudioOnly,$type)) : bm_arc1_download_meta((array)$dl,$q,$u,$isAudioOnly,$type))];
            } else {
                $bmMatchedSubtitleUrl = ($isArc3 || $isArc4 || $isArc5 || $isArc6 || $isArc7) ? $bmArc3FindSubtitle((array)$dl, $q) : bm_ext_safe_url($dl['subtitle_url'] ?? '');
                $arc1Item = ['quality'=>$q,'type'=>$type,'url'=>$u,'size'=>$dl['size']??'','is_audio'=>$isAudioOnly,'media_type'=>$mediaType,'audio_label'=>trim((string)($dl['dub_source'] ?? $dl['audio_source'] ?? $dl['studio'] ?? $dl['audio_label'] ?? $dl['display_label'] ?? $dl['label'] ?? '')),'audio_origin'=>array_intersect_key((array)$dl, array_flip(['dub_name','dub_source','audio_source','studio','audio_label','display_label','label','title','description','details'])),'version_note'=>trim((string)($dl['version_note'] ?? $dl['technical_note'] ?? $dl['notes'] ?? $dl['description'] ?? $dl['details'] ?? '')),'release_name'=>trim((string)($dl['release_name'] ?? $dl['filename'] ?? '')),'source_download_locked'=>!empty($dl['source_download_locked']),'subtitle_url'=>$bmMatchedSubtitleUrl,'meta'=>($isArc6 ? bm_a6_visible_meta(bm_arc1_download_meta((array)$dl,$q,$u,$isAudioOnly,$type)) : bm_arc1_download_meta((array)$dl,$q,$u,$isAudioOnly,$type))];
                if ($type==='dub') $arc1MovieDub[$q][]  = $arc1Item;
                else               $arc1MovieSoft[$q][] = $arc1Item;
            }
        }
        ksort($arc1SeriesSeasons, SORT_NATURAL);
        foreach ($arc1SeriesSeasons as &$_eps) {
            ksort($_eps, SORT_NATURAL);
            foreach ($_eps as &$_links) {
                usort($_links, function($a, $b) {
                    $typeRank = static function($type): int {
                        $type = strtolower(trim((string)$type));
                        if (in_array($type, ['softsub','hardsub','subtitle'], true)) return 0;
                        if (in_array($type, ['nosub','original'], true)) return 1;
                        if ($type === 'dub') return 2;
                        return 3;
                    };
                    $ta = $typeRank($a['type'] ?? '');
                    $tb = $typeRank($b['type'] ?? '');
                    if ($ta !== $tb) return $ta - $tb; // زیرنویس، بدون زیرنویس، دوبله
                    return getQualityOrder($b['quality'] ?? '') - getQualityOrder($a['quality'] ?? '');
                });
            }
            unset($_links);
        }
        unset($_eps);

        // V219: archive1_items دیگر روی هر بازدید نوشته نمی‌شود.
        // فقط هنگام ثبت دیدگاه/پاسخ ساخته می‌شود تا بازدید ساده دیتابیس را باد نکند.

        // یکسان‌سازی شناسه کامنت بین اپ و سایت؛ نسخه‌های قدیمی ممکن است slug متفاوتی ذخیره کرده باشند.
        $arc1VirtualMovieId = bm_resolve_external_comment_movie_id(
            $pdo,
            (int)$arc1VirtualMovieId,
            ($isArc7 ? 7 : ($isArc6 ? 6 : ($isArc5 ? 5 : ($isArc4 ? 4 : ($isArc3 ? 3 : 1))))),
            (string)$arc1Slug,
            (string)($arc1SourceUrl ?? ''),
            (string)($arc1Title ?? ''),
            (string)($arc1Year ?? '')
        );

        // واچ‌لیست آرشیو ۱
        $inArc1Watch = false; $arc1WatchId = null;
        if ($currentUser) {
            try {
                bm_ensure_archive1_watchlist_table($pdo);
                $st = $pdo->prepare("SELECT id FROM archive1_watchlist WHERE user_id=? AND item_link=? LIMIT 1");
                $st->execute([(int)$currentUser['id'], $arc1SourceUrl]);
                $row = $st->fetch(PDO::FETCH_ASSOC);
                if ($row) { $inArc1Watch = true; $arc1WatchId = (int)$row['id']; }
            } catch (Throwable $e) {}
        }
    }
}



$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
$userTheme = array_key_exists($userTheme, $themes) ? $userTheme : 'dark-green';
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';
$currentTheme = $themes[$userTheme];
$currentThemeInfo = $currentTheme;
$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

if (!function_exists('e')) {
    function e($str) { return htmlspecialchars((string)($str ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('js_json')) {
    function js_json($value) {
        return json_encode(
            $value,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
        );
    }
}


if (!function_exists('bm_actor_placeholder_svg')) {
    function bm_actor_placeholder_svg($name = '') {
        $name = trim((string)$name);
        $letter = '?';
        if ($name !== '') {
            if (function_exists('mb_substr')) {
                $letter = mb_substr($name, 0, 1, 'UTF-8');
            } else {
                $letter = strtoupper(substr($name, 0, 1));
            }
        }
        $letter = htmlspecialchars($letter, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180">
            <defs>
                <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
                    <stop offset="0" stop-color="#36ff9f"/>
                    <stop offset=".55" stop-color="#7b2cff"/>
                    <stop offset="1" stop-color="#111827"/>
                </linearGradient>
                <radialGradient id="r" cx=".35" cy=".22" r=".85">
                    <stop offset="0" stop-color="#ffffff" stop-opacity=".38"/>
                    <stop offset=".55" stop-color="#ffffff" stop-opacity=".06"/>
                    <stop offset="1" stop-color="#000000" stop-opacity=".20"/>
                </radialGradient>
            </defs>
            <rect width="180" height="180" rx="38" fill="url(#g)"/>
            <rect width="180" height="180" rx="38" fill="url(#r)"/>
            <circle cx="90" cy="70" r="31" fill="#ffffff" opacity=".82"/>
            <path d="M39 151c8-31 28-48 51-48s43 17 51 48" fill="#ffffff" opacity=".74"/>
            <text x="90" y="101" text-anchor="middle" dominant-baseline="middle" font-family="Arial,Tahoma,sans-serif" font-size="58" font-weight="900" fill="#07110d" opacity=".78">'.$letter.'</text>
        </svg>';
        return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
    }
}

if (!function_exists('bm_normalize_arc1_actors')) {
    function bm_normalize_arc1_actors($actorsRaw) {
        $actors = [];
        if (is_string($actorsRaw)) {
            $parts = preg_split('/\s*,\s*/u', $actorsRaw);
            foreach ($parts as $p) {
                $p = trim($p);
                if ($p !== '') $actors[] = ['name' => $p, 'role' => '', 'image' => '', 'url' => '', 'bankmovie_url' => ''];
            }
            return $actors;
        }
        if (!is_array($actorsRaw)) return [];
        $seen = [];
        foreach ($actorsRaw as $a) {
            if (is_string($a)) {
                $name = trim($a);
                $role = $image = $url = $bankUrl = '';
            } elseif (is_array($a)) {
                $name = trim((string)($a['name'] ?? $a['title'] ?? ''));
                $role = trim((string)($a['role'] ?? $a['character'] ?? ''));
                $image = trim((string)($a['image'] ?? $a['photo'] ?? $a['poster'] ?? ''));
                $url = trim((string)($a['url'] ?? $a['source_url'] ?? ''));
                $bankUrl = trim((string)($a['bankmovie_url'] ?? ''));
                if ($bankUrl === '' && !empty($a['slug'])) {
                    $bankUrl = '/actors?slug=' . rawurlencode((string)$a['slug']);
                } elseif ($bankUrl === '' && $url !== '') {
                    $slugFromUrl = bm_actor_slug_from_url($url);
                    if ($slugFromUrl !== '') $bankUrl = '/actors?slug=' . rawurlencode($slugFromUrl);
                }
            } else {
                continue;
            }
            if ($name === '') continue;
            // V225: actor page can render a correct profile shell even when
            // Archive 1 is temporarily unavailable.
            if ($bankUrl !== '' && (str_starts_with($bankUrl, '/actors?') || str_starts_with($bankUrl, 'actors?'))) {
                $q = (string)(parse_url($bankUrl, PHP_URL_QUERY) ?? '');
                parse_str($q, $actorLinkQuery);
                if (empty($actorLinkQuery['name'])) {
                    $bankUrl .= (str_contains($bankUrl, '?') ? '&' : '?') . 'name=' . rawurlencode($name);
                }
            }
            $key = function_exists('mb_strtolower') ? mb_strtolower($name, 'UTF-8') : strtolower($name);
            if (isset($seen[$key])) continue;
            $seen[$key] = true;
            $actors[] = ['name' => $name, 'role' => $role, 'image' => $image, 'url' => $url, 'bankmovie_url' => $bankUrl];
        }
        return $actors;
    }
}



// ========== BankMovie Front Ads Layer ==========
require_once __DIR__ . '/includes/manual_ads.php';
// ========== /BankMovie Front Ads Layer ==========


$t = [
    'fa' => [
        'home' => 'خانه',
        'profile' => 'پروفایل',
        'player' => 'پلیر',
        'request' => 'درخواست فیلم و سریال',
        'auth' => 'ثبت نام و ورود',
        'account' => 'حساب کاربری',
        'login' => 'ورود',
        'register' => 'ثبت نام',
        'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت',
        'guest' => 'کاربر مهمان',
        'notifications' => 'اعلان‌ها',
        'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'support_us' => 'حمایت مالی',
        'support_text' => 'اگر از سایت بانک مووی راضی هستید، با یک حمایت کوچک در هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن',
        'donate' => 'حمایت مالی',
    ],
    'en' => [
        'home' => 'Home',
        'profile' => 'Profile',
        'player' => 'Player',
        'request' => 'Request Movie / Series',
        'auth' => 'Login / Register',
        'account' => 'Account',
        'login' => 'Login',
        'register' => 'Register',
        'logout' => 'Logout',
        'admin_panel' => 'Admin Panel',
        'guest' => 'Guest',
        'notifications' => 'Notifications',
        'no_notifications' => 'No notifications',
        'support_us' => 'Support Us',
        'support_text' => 'All services on this site are free. If you would like to help us improve the site quality and renew the server, you can donate.',
        'close' => 'Close',
        'donate' => 'Donate',
    ]
];

$routeSlug = trim((string)($_GET['slug'] ?? ''), "/ \t\n\r\0\x0B");
$legacyImdbCode = trim((string)($_GET['imdb'] ?? ''));
$movieData = null;
$imdbCode = '';
if ($bmArchiveBlocked) {
    $arc1Error = $bmArchiveBlockedMessage ?: 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.';
    $arc1Data = null;
}

// ====== مقداردهی اولیه متغیرهای مورد استفاده در جاوااسکریپت برای آرشیو ۱ ======
$softLinks = [];
$dubLinks = [];
$bestQuality = '';
$hasDub = false;
$hasSoft = false;
$movieData = null;
$imdbCode = '';
$isMovie = false;

// ====== آرشیو ۱: اگر arc=1 هست، بخش دیتابیس محلی را کاملاً skip کن ======
if ($isArc1) {
    // آرشیو ۱ باید منطق اصلی خودش را حفظ کند؛ فقط داده‌های مشترک کامنت‌ها را قبل از رندر آماده می‌کنیم.
    $inWatchlist = $inArc1Watch ?? false;
    $avgRating = 0;
    $totalVotes = 0;
    $userRating = 0;
    $commentPage = isset($_GET['comment_page']) ? max(1, (int)$_GET['comment_page']) : 1;
    $commentsPerPage = 10;
    $commentOffset = ($commentPage - 1) * $commentsPerPage;
    $comments = [];
    $totalComments = 0;
    $totalCommentPages = 0;

    try {
        bm_ensure_archive1_comment_tables($pdo);
        bm_site_comment_upgrade_schema($pdo);
        $commentSort = strtolower(trim((string)($_GET['comment_sort'] ?? 'latest')));
        if (!in_array($commentSort, ['latest','oldest','popular','controversial','replies'], true)) $commentSort = 'latest';
        $approvedC = bm_comment_public_status_sql('c');
        $approvedR = bm_comment_public_status_sql('r');
        $rootC = bm_comment_root_parent_sql('c');
        $limitSql = max(1, (int)$commentsPerPage);
        $offsetSql = max(0, (int)$commentOffset);
        $viewerId = (int)($currentUser['id'] ?? 0);
        $orderSql = bm_site_comment_order_sql($commentSort, 'c', 'archive1_comment_likes', 'archive1_comments');
        $stmt = $pdo->prepare("
            SELECT c.*, 
                   COALESCE((SELECT COUNT(*) FROM archive1_comment_likes WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                   COALESCE((SELECT COUNT(*) FROM archive1_comment_likes WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                   COALESCE((SELECT type FROM archive1_comment_likes WHERE comment_id = c.id AND user_id = ? LIMIT 1), '') as user_vote,
                   (SELECT COUNT(*) FROM archive1_comments r WHERE r.parent_id = c.id AND ({$approvedR} OR (? > 0 AND r.user_id=? AND LOWER(TRIM(CAST(r.status AS CHAR)))='pending'))) as reply_count,
                   COALESCE(u.role, 'user') AS role, COALESCE(u.avatar, '') AS avatar, COALESCE(u.admin_badge_color, '') AS admin_badge_color
            FROM archive1_comments c
            LEFT JOIN users u ON c.user_id = u.id
            WHERE c.movie_id = ? AND {$rootC} AND ({$approvedC} OR (? > 0 AND c.user_id=? AND LOWER(TRIM(CAST(c.status AS CHAR)))='pending'))
            ORDER BY {$orderSql}
            LIMIT {$limitSql} OFFSET {$offsetSql}
        ");
        $stmt->execute([$viewerId, $viewerId, $viewerId, $arc1VirtualMovieId, $viewerId, $viewerId]);
        $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $approvedBase = bm_comment_public_status_sql('archive1_comments');
        $rootBase = bm_comment_root_parent_sql('archive1_comments');
        $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM archive1_comments WHERE movie_id = ? AND {$rootBase} AND ({$approvedBase} OR (? > 0 AND user_id=? AND LOWER(TRIM(CAST(status AS CHAR)))='pending'))");
        $totalStmt->execute([$arc1VirtualMovieId, $viewerId, $viewerId]);
        $totalComments = (int)$totalStmt->fetchColumn();
        $totalCommentPages = (int)ceil($totalComments / $commentsPerPage);

        $ratingStmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM archive1_comments WHERE movie_id = ? AND rating > 0 AND {$approvedBase} AND {$rootBase}");
        $ratingStmt->execute([$arc1VirtualMovieId]);
        $ratingRow = $ratingStmt->fetch(PDO::FETCH_ASSOC) ?: [];
        $avgRating = $ratingRow['avg_rating'] ?? 0;
        $totalVotes = $ratingRow['total_votes'] ?? 0;

        if ($currentUser) {
            $ur = $pdo->prepare("SELECT rating FROM archive1_comments WHERE movie_id = ? AND user_id = ? AND {$approvedBase} AND {$rootBase} ORDER BY created_at DESC, id DESC LIMIT 1");
            $ur->execute([$arc1VirtualMovieId, $currentUser['id']]);
            $userRating = (int)($ur->fetchColumn() ?: 0);
        }
    } catch (Throwable $e) {
        error_log('Archive1 comments display error [movie_id=' . (int)$arc1VirtualMovieId . ', slug=' . $arc1Slug . ']: ' . $e->getMessage());
        $comments = [];
        $totalComments = 0;
        $totalCommentPages = 0;
        $avgRating = 0;
        $totalVotes = 0;
        $userRating = 0;
    }

    // ثبت بازدید آرشیوهای خارجی/آرشیو ۱ بدون شکستن صفحه
    bm_analytics_track($pdo, [
        'page_type' => 'archive_movie',
        'user_id' => $currentUser['id'] ?? null,
        'movie_id' => null,
        'imdb_code' => $arc1Slug,
        'movie_title' => $arc1Title ?? ($arc1Data['title'] ?? ''),
    ]);

    // Goto skips the Archive-2 preparation block below, so refresh the gate
    // state here after the final per-item media policy has been resolved.
    $bmRefreshArchiveVipGateState();

    // همه پردازش اصلی آرشیو ۱ از بخش بالا انجام شده؛ دیتابیس محلی آرشیو ۲ نباید اجرا شود.
    goto arc1_render;
}

if ($legacyImdbCode !== '') {
    if (!preg_match('/^tt\d{5,12}$/', $legacyImdbCode)) { header('Location: index.php'); exit; }
    $movieData = $movie->getByImdb($legacyImdbCode);
    if (!$movieData) { header('Location: index.php'); exit; }
    header('Location: ' . bm_movie_url($movieData), true, 301);
    exit;
}

if ($routeSlug !== '') {
    $movieData = bm_find_movie_by_seo_slug($pdo, $routeSlug);
    if (!$movieData) { header('Location: index.php'); exit; }
    $imdbCode = trim((string)($movieData['imdb_code'] ?? ''));
    if ($imdbCode === '' || !preg_match('/^tt\d{5,12}$/', $imdbCode)) { header('Location: index.php'); exit; }
    $canonicalUrl = bm_movie_url($movieData);
    if ($canonicalUrl !== '/movie/' . $routeSlug) {
        header('Location: ' . $canonicalUrl, true, 301);
        exit;
    }
    $bmArchiveItemMediaBlocked = bm_archive_item_media_blocked('archive2', $movieData, [
        'identifier'=>(string)($movieData['imdb_code'] ?? ''),
        'movie_id'=>(string)($movieData['id'] ?? ''),
    ]);
    $bmArchiveItemDownloadBlocked = $bmArchiveItemMediaBlocked;
    if ($bmArchiveItemMediaBlocked) {
        $bmArchiveDownloadAllowed = false;
        $bmArchiveStreamAllowed = false;
        $GLOBALS['bmArchiveDownloadAllowed'] = false;
        $GLOBALS['bmArchiveStreamAllowed'] = false;
    }
} else {
    header('Location: index.php');
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM movie_extra_info WHERE imdb_code = ?");
$stmt->execute([$imdbCode]);
$extraInfo = $stmt->fetch(PDO::FETCH_ASSOC);
$releaseUpdate = bm_movie_update_get($pdo, (int)($movieData['id'] ?? 0));
$releaseUpdateSummary = bm_movie_update_summary($releaseUpdate, (($movieData['type'] ?? '') !== 'movie'));

if($currentUser) {
    $userIdForHistory = (int)$currentUser['id'];
    $stmt = $pdo->prepare("INSERT INTO watch_history (user_id, movie_id, last_watched) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE last_watched = NOW()");
    $stmt->execute([$userIdForHistory, (int)$movieData['id']]);

    // بعد از upsert فقط موارد اضافه‌تر از ۲۰۰ تا پاک می‌شود؛ نه قبل از آن.
    $stmtCount = $pdo->prepare("SELECT COUNT(*) FROM watch_history WHERE user_id = ?");
    $stmtCount->execute([$userIdForHistory]);
    $extraHistoryRows = max(0, (int)$stmtCount->fetchColumn() - 200);
    if($extraHistoryRows > 0) {
        $stmtDel = $pdo->prepare("DELETE FROM watch_history WHERE user_id = ? ORDER BY last_watched ASC LIMIT " . $extraHistoryRows);
        $stmtDel->execute([$userIdForHistory]);
    }
}

// آمار بازدید فقط در فایل JSON و به‌صورت IP یونیک روزانه ثبت می‌شود.
// ثبت قدیمی جدول stats عمداً حذف شده است.

bm_analytics_track($pdo, [
    'page_type' => 'movie',
    'user_id' => $currentUser['id'] ?? null,
    'movie_id' => (int)($movieData['id'] ?? 0),
    'imdb_code' => $imdbCode,
    'movie_title' => trim((string)(($movieData['title_fa'] ?? '') ?: ($movieData['title'] ?? ''))),
]);

$softLinks = [];
$dubLinks = [];
$seriesSeasons = [];
$seriesHasDub = false;
$seriesHasSoft = false;
$arc2PlayerSoftLinks = [];
$arc2PlayerDubLinks = [];
$arc2LatestPlay = ['url'=>'','season'=>'','episode'=>'','label'=>'','quality'=>'','type'=>'','next_url'=>'','next_label'=>''];
$bmArc2HasDubDisplay = false;
$bmArc2HasSoftDisplay = false;
// ========== ادامه پردازش آرشیو ۲ (دیتابیس محلی) ==========
// اگر آرشیو ۱ است، همه این بخش skip می‌شود
$isMovie = !$isArc1 && ($movieData['type'] ?? '') === 'movie';
if(!$isArc1 && !$movieData) { header('Location: index.php'); exit; }
$bestQuality = '';

function getQualityOrder($q) {
    $q = strtolower($q);
    if(strpos($q, '2160p') !== false || strpos($q, '4k') !== false) return 6;
    if(strpos($q, '1080p') !== false) return 5;
    if(strpos($q, '720p') !== false) return 4;
    if(strpos($q, '480p') !== false) return 3;
    if(strpos($q, '360p') !== false) return 2;
    return 1;
}


function bmLocalColumnExists($pdo, $table, $column) {
    static $cache = [];
    $safeTable = preg_replace('/[^A-Za-z0-9_]/', '', (string)$table);
    $safeColumn = preg_replace('/[^A-Za-z0-9_]/', '', (string)$column);
    $key = $safeTable . '.' . $safeColumn;
    if (array_key_exists($key, $cache)) return $cache[$key];
    if ($safeTable === '' || $safeColumn === '') return $cache[$key] = false;
    try {
        $stmt = $pdo->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
        $stmt->execute([$safeTable, $safeColumn]);
        return $cache[$key] = (bool)$stmt->fetchColumn();
    } catch (Throwable $e) { return $cache[$key] = false; }
}

function bmFormatSeasonKey($seasonValue) {
    $seasonValue = (string)($seasonValue ?? '');
    if (preg_match('/^S\d{2}$/i', $seasonValue)) return strtoupper($seasonValue);
    if (preg_match('/(\d+)/', $seasonValue, $m)) $seasonNum = (int)$m[1];
    else $seasonNum = 1;
    return 'S' . str_pad((string)$seasonNum, 2, '0', STR_PAD_LEFT);
}

function bmExtractEpisodeFromLocalLink($row) {
    if (isset($row['episode']) && $row['episode'] !== null && $row['episode'] !== '') return (int)$row['episode'];
    $hay = (string)($row['url'] ?? '') . ' ' . (string)($row['quality'] ?? '');
    if (preg_match('/\bS\d{1,2}E(\d{1,3})\b/i', $hay, $m)) return (int)$m[1];
    if (preg_match('/\bE(\d{1,3})\b/i', $hay, $m)) return (int)$m[1];
    if (preg_match('/قسمت\s*(\d+)/u', $hay, $m)) return (int)$m[1];
    return null;
}


function bmArc2CleanQuality($quality) {
    $q = trim((string)$quality);
    $q = preg_replace('/^S\d{1,2}E\d{1,3}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^S\d{1,2}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^E\d{1,3}\s*[-–—:]\s*/i', '', $q);
    $q = preg_replace('/^قسمت\s*\d+\s*[-–—:]\s*/u', '', $q);
    return trim($q) !== '' ? trim($q) : (trim((string)$quality) ?: 'Unknown');
}

function bmArc2CleanSize($size) {
    $s = trim((string)$size);
    if ($s === '') return '';
    $s = preg_replace('/^(?:حجم|size)\s*[:：-]?\s*/iu', '', $s);
    $s = preg_replace('/\s+/', ' ', trim($s));
    return $s;
}

function bmArc2PremiumSpecs($quality, $url = '', $row = []) {
    $row = is_array($row) ? $row : [];
    $rawQuality = trim((string)$quality);
    $pathName = urldecode(basename((string)(parse_url((string)$url, PHP_URL_PATH) ?: $url)));
    $haystack = bm_v111_release_text($row, $rawQuality, (string)$url);

    // کیفیت اصلی همیشه یک badge مستقل و کوتاه است.
    $resolution = '';
    if (preg_match('/(?:2160|1080|720|480|360)\s*[pP]?/', $haystack, $m)) {
        $num = preg_replace('/\D+/', '', $m[0]);
        if ($num !== '') $resolution = $num . 'p';
    } elseif (preg_match('/(?:^|[^A-Za-z0-9])4K(?:[^A-Za-z0-9]|$)/i', $haystack)) {
        $resolution = '4K';
    }
    if ($resolution === '') {
        $resolution = bmArc2CleanQuality($rawQuality);
        if (preg_match('/(2160|1080|720|480|360)/', $resolution, $m)) $resolution = $m[1] . 'p';
    }

    $tags = [];
    $seen = [];
    $add = static function(string $kind, string $value, string $label = '') use (&$tags, &$seen): void {
        $value = trim($value);
        if ($value === '') return;
        $key = strtolower($kind . '|' . $value);
        if (isset($seen[$key])) return;
        $seen[$key] = true;
        $tags[] = ['kind'=>$kind, 'value'=>$value, 'label'=>$label];
    };

    // همان منطق متادیتای Archive 1 را پایه قرار بده.
    if (function_exists('bm_arc1_download_meta')) {
        foreach (bm_arc1_download_meta($row, $rawQuality, (string)$url, false) as $meta) {
            $kind = trim((string)($meta['kind'] ?? 'detail')) ?: 'detail';
            $value = trim((string)($meta['value'] ?? ''));
            $label = trim((string)($meta['label'] ?? ''));
            if ($value !== '') $add($kind, $value, $label);
        }
    }

    // Archive 2 بعضی فایل‌ها را بدون جداکننده ذخیره کرده: WEB-DLx264 / WEB-DLx265.
    if (preg_match('/WEB[ ._-]?DL/i', $haystack)) $add('format', 'WEB-DL');
    elseif (preg_match('/WEB[ ._-]?Rip/i', $haystack)) $add('format', 'WEBRip');
    elseif (preg_match('/Blu[ ._-]?Ray/i', $haystack)) $add('format', 'BluRay');
    elseif (preg_match('/HDTV/i', $haystack)) $add('format', 'HDTV');
    elseif (preg_match('/DVD[ ._-]?Rip/i', $haystack)) $add('format', 'DVDRip');
    elseif (preg_match('/Remux/i', $haystack)) $add('format', 'Remux');

    if (preg_match('/x265/i', $haystack)) $add('codec', 'x265');
    elseif (preg_match('/HEVC/i', $haystack)) $add('codec', 'HEVC');
    elseif (preg_match('/x264/i', $haystack)) $add('codec', 'x264');
    elseif (preg_match('/(?:^|[^A-Za-z0-9])AV1(?:[^A-Za-z0-9]|$)/i', $haystack)) $add('codec', 'AV1');

    if (preg_match('/(?:8|10|12)[ ._-]?bit/i', $haystack, $m)) {
        $bit = preg_replace('/\D+/', '', $m[0]);
        if ($bit !== '') $add('bitdepth', $bit . 'Bit');
    }
    if (preg_match('/HDR10\+?|Dolby[ ._-]?Vision|(?:^|[^A-Za-z0-9])DV(?:[^A-Za-z0-9]|$)|(?:^|[^A-Za-z0-9])HDR(?:[^A-Za-z0-9]|$)/i', $haystack, $m)) {
        $v = trim($m[0], " ._-\t\n\r\0\x0B");
        $v = preg_replace('/Dolby[ ._-]?Vision/i', 'Dolby Vision', $v);
        $add('hdr', $v);
    }
    if (preg_match('/(?:^|[._\- ])((?:2|6|8)CH|(?:2\.0|5\.1|7\.1))(?:[._\- ]|$)/i', $haystack, $m)) {
        $add('audio', strtoupper($m[1]));
    }

    return ['resolution'=>$resolution, 'tags'=>$tags];
}

function bmArc2IsPlayableUrl($url) {
    return (bool)preg_match('~\.(mkv|mp4|m3u8|webm|avi)(?:[?#]|$)~i', (string)$url);
}


if (!$isArc1 && $isMovie) {
    $movieId = $movieData['id'];
    $stmt = $pdo->prepare("SELECT url, quality, size FROM dubbed_links WHERE movie_id = ?");
    $stmt->execute([$movieId]);
    $dubRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $softSubtitleSelect = bmLocalColumnExists($pdo, 'softsub_links', 'subtitle_url') ? ', subtitle_url' : ', NULL AS subtitle_url';
    $stmt = $pdo->prepare("SELECT url, quality, size{$softSubtitleSelect} FROM softsub_links WHERE movie_id = ?");
    $stmt->execute([$movieId]);
    $softRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($dubRows as $link) {
        $quality = $link['quality'] ?? 'Unknown';
        $size = $link['size'] ?? '';
        $url = bm_ddm_apply_active_url((string)($link['url'] ?? ''));
        if(!isset($dubLinks[$quality])) $dubLinks[$quality] = [];
        $dubLinks[$quality][] = ['url' => $url, 'size' => $size];
    }
    foreach($softRows as $link) {
        $quality = $link['quality'] ?? 'Unknown';
        $size = $link['size'] ?? '';
        $url = bm_ddm_apply_active_url((string)($link['url'] ?? ''));
        $isDuplicate = false;
        foreach($dubRows as $dub) if($dub['url'] === $url) { $isDuplicate = true; break; }
        if(!$isDuplicate) {
            if(!isset($softLinks[$quality])) $softLinks[$quality] = [];
            $softLinks[$quality][] = ['url' => $url, 'size' => $size, 'subtitle_url' => bm_ddm_apply_active_url(trim((string)($link['subtitle_url'] ?? '')))];
        }
    }
    uksort($dubLinks, function($a,$b) { return getQualityOrder($b)-getQualityOrder($a); });
    uksort($softLinks, function($a,$b) { return getQualityOrder($b)-getQualityOrder($a); });
    if(count($dubLinks)>0) $bestQuality = array_key_first($dubLinks);
    elseif(count($softLinks)>0) $bestQuality = array_key_first($softLinks);
} elseif (!$isArc1) {
    // ========== سریال آرشیو ۲: دریافت لینک‌ها از دیتابیس با استفاده از movie_id ==========
    $movieId = $movieData['id'];
    
    // دریافت لینک‌های دوبله
    $dubEpisodeSelect = bmLocalColumnExists($pdo, 'dubbed_links', 'episode') ? ', episode' : ', NULL AS episode';
    $stmtDub = $pdo->prepare("SELECT url, quality, size, season{$dubEpisodeSelect} FROM dubbed_links WHERE movie_id = ?");
    $stmtDub->execute([$movieId]);
    $dubRows = $stmtDub->fetchAll(PDO::FETCH_ASSOC);
    
    // دریافت لینک‌های زیرنویس
    $softEpisodeSelect = bmLocalColumnExists($pdo, 'softsub_links', 'episode') ? ', episode' : ', NULL AS episode';
    $softSubtitleSelect = bmLocalColumnExists($pdo, 'softsub_links', 'subtitle_url') ? ', subtitle_url' : ', NULL AS subtitle_url';
    $stmtSoft = $pdo->prepare("SELECT url, quality, size, season{$softEpisodeSelect}{$softSubtitleSelect} FROM softsub_links WHERE movie_id = ?");
    $stmtSoft->execute([$movieId]);
    $softRows = $stmtSoft->fetchAll(PDO::FETCH_ASSOC);
    
    // آرایه‌ی نهایی برای نگهداری فصل‌ها
    $seriesSeasons = [];
    
    // پردازش لینک‌های دوبله
    foreach ($dubRows as $link) {
        $season = bmFormatSeasonKey($link['season'] ?? 'S01');
        $episode = bmExtractEpisodeFromLocalLink($link);
        if (!isset($seriesSeasons[$season])) {
            $seriesSeasons[$season] = [];
        }
        $seriesSeasons[$season][] = [
            'type'    => 'dub',
            'quality' => bmArc2CleanQuality($link['quality'] ?? ''),
            'url'     => bm_ddm_apply_active_url((string)($link['url'] ?? '')),
            'size'    => $link['size'] ?? '',
            'episode' => $episode
        ];
    }
    
    // پردازش لینک‌های زیرنویس
    foreach ($softRows as $link) {
        $season = bmFormatSeasonKey($link['season'] ?? 'S01');
        $episode = bmExtractEpisodeFromLocalLink($link);
        if (!isset($seriesSeasons[$season])) {
            $seriesSeasons[$season] = [];
        }
        $bmStoredSoftUrl = bm_ddm_apply_active_url((string)($link['url'] ?? ''));
        $bmStoredSoftType = preg_match('~/NoSub(?:/|$)~i', rawurldecode($bmStoredSoftUrl)) ? 'original' : 'soft';
        $seriesSeasons[$season][] = [
            'type'    => $bmStoredSoftType,
            'quality' => bmArc2CleanQuality($link['quality'] ?? ''),
            'url'     => $bmStoredSoftUrl,
            'size'    => $link['size'] ?? '',
            'episode' => $episode,
            'subtitle_url' => bm_ddm_apply_active_url(trim((string)($link['subtitle_url'] ?? '')))
        ];
    }
    
    // مرتب‌سازی کلیدهای فصل (S01, S02, ...)
    ksort($seriesSeasons, SORT_NATURAL);
    
    // در هر فصل، لینک‌ها را بر اساس کیفیت (۴K > ۱۰۸۰p > ۷۲۰p > ...) مرتب می‌کنیم
    foreach ($seriesSeasons as $season => $links) {
        usort($links, function($a, $b) {
            $ea = isset($a['episode']) && $a['episode'] !== null ? (int)$a['episode'] : 0;
            $eb = isset($b['episode']) && $b['episode'] !== null ? (int)$b['episode'] : 0;
            if ($ea !== $eb) return $ea - $eb;
            if (($a['type'] ?? '') !== ($b['type'] ?? '')) {
                $aDub = (($a['type'] ?? '') === 'dub');
                $bDub = (($b['type'] ?? '') === 'dub');
                if ($aDub !== $bDub) return $aDub ? 1 : -1;
            }
            return getQualityOrder($b['quality']) - getQualityOrder($a['quality']);
        });
        $seriesSeasons[$season] = $links;
    }
    
    $seriesHasDub = count($dubRows) > 0;
    $seriesHasSoft = count($softRows) > 0;

    // انتخاب آخرین قسمت قابل پخش برای فعال کردن پلیر سریال‌های آرشیو ۲
    $arc2PlayableFlat = [];
    foreach ($seriesSeasons as $sn => $snLinks) {
        foreach ($snLinks as $lk) {
            if (empty($lk['url']) || !bmArc2IsPlayableUrl($lk['url'])) continue;
            $epNum = isset($lk['episode']) && $lk['episode'] !== null ? (int)$lk['episode'] : 0;
            $arc2PlayableFlat[] = [
                'season' => $sn,
                'episode' => $epNum,
                'quality' => bmArc2CleanQuality($lk['quality'] ?? ''),
                'type' => (string)($lk['type'] ?? ''),
                'url' => (string)$lk['url']
            ];
        }
    }
    usort($arc2PlayableFlat, function($a, $b) {
        $sa = (int)preg_replace('/\D+/', '', (string)($a['season'] ?? '0'));
        $sb = (int)preg_replace('/\D+/', '', (string)($b['season'] ?? '0'));
        if ($sa !== $sb) return $sb - $sa;
        $ea = (int)($a['episode'] ?? 0);
        $eb = (int)($b['episode'] ?? 0);
        if ($ea !== $eb) return $eb - $ea;
        $ta = (($a['type'] ?? '') === 'dub') ? 1 : 0;
        $tb = (($b['type'] ?? '') === 'dub') ? 1 : 0;
        if ($ta !== $tb) return $ta - $tb; // اول زیرنویس، بعد دوبله
        return getQualityOrder($b['quality'] ?? '') - getQualityOrder($a['quality'] ?? '');
    });
    if (!empty($arc2PlayableFlat)) {
        $arc2Latest = $arc2PlayableFlat[0];
        $epLabel = $arc2Latest['episode'] > 0 ? (($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $arc2Latest['episode']) : ($userLang === 'fa' ? 'پخش سریال' : 'Play series');
        $arc2LatestPlay = [
            'url' => $arc2Latest['url'],
            'season' => $arc2Latest['season'],
            'episode' => $arc2Latest['episode'] > 0 ? ('E' . str_pad((string)$arc2Latest['episode'], 2, '0', STR_PAD_LEFT)) : '',
            'label' => $arc2Latest['season'] . ' - ' . $epLabel,
            'quality' => $arc2Latest['quality'],
            'type' => $arc2Latest['type'],
            'next_url' => '',
            'next_label' => ''
        ];
    }
}


if (!$isMovie) {
    // برای فعال شدن همان پلیر آرشیو ۲ روی سریال‌ها، لینک‌های قسمت‌ها را به فرم قابل‌فهم پلیر می‌دهیم.
    // مهم: این تبدیل فقط برای سریال است؛ اگر روی فیلم اجرا شود، لینک‌های فیلم آرشیو ۲ خالی می‌شوند.
    $arc2PlayerSoftLinks = [];
    $arc2PlayerDubLinks = [];
    foreach ($seriesSeasons as $sn => $snLinks) {
        foreach ($snLinks as $lk) {
            if (empty($lk['url']) || !bmArc2IsPlayableUrl($lk['url'])) continue;
            $epNum = isset($lk['episode']) && $lk['episode'] !== null ? (int)$lk['episode'] : 0;
            $epKey = $epNum > 0 ? ('E' . str_pad((string)$epNum, 2, '0', STR_PAD_LEFT)) : 'EP';
            $qClean = bmArc2CleanQuality($lk['quality'] ?? '');
            $playerQualityKey = $sn . $epKey . ' - ' . $qClean;
            $playerItem = ['url' => (string)$lk['url'], 'size' => ''];
            if (($lk['type'] ?? '') === 'dub') {
                if (!isset($arc2PlayerDubLinks[$playerQualityKey])) $arc2PlayerDubLinks[$playerQualityKey] = [];
                $arc2PlayerDubLinks[$playerQualityKey][] = $playerItem;
            } else {
                if (!isset($arc2PlayerSoftLinks[$playerQualityKey])) $arc2PlayerSoftLinks[$playerQualityKey] = [];
                $arc2PlayerSoftLinks[$playerQualityKey][] = $playerItem;
            }
        }
    }
    uksort($arc2PlayerDubLinks, function($a, $b) { return strnatcasecmp($a, $b); });
    uksort($arc2PlayerSoftLinks, function($a, $b) { return strnatcasecmp($a, $b); });
    // movie-player-core فقط وقتی isMovie=true باشد فعال می‌شود؛ برای سریال آرشیو ۲ فقط در config جاوااسکریپت آن را فعال می‌کنیم، نه در منطق PHP صفحه.
    $softLinks = $arc2PlayerSoftLinks;
    $dubLinks = $arc2PlayerDubLinks;
    if (!$bestQuality) {
        if (!empty($arc2PlayerSoftLinks)) $bestQuality = array_key_first($arc2PlayerSoftLinks);
        elseif (!empty($arc2PlayerDubLinks)) $bestQuality = array_key_first($arc2PlayerDubLinks);
    }
}

$bmArc2HasDubDisplay = $isMovie ? $hasDub : $seriesHasDub;
$bmArc2HasSoftDisplay = $isMovie ? $hasSoft : $seriesHasSoft;

function getGenreRelatedMovies($pdo, $currentMovie, $limit=12) {
    if(empty($currentMovie['genres'])) return [];
    $genres = explode(',', $currentMovie['genres']);
    $genreConditions = [];
    $params = [];
    foreach($genres as $idx=>$genre) {
        $genreConditions[] = "FIND_IN_SET(:genre{$idx}, genres) > 0";
        $params[":genre{$idx}"] = trim($genre);
    }
    $whereGenre = implode(' OR ', $genreConditions);
    $sql = "SELECT imdb_code, title, title_fa, year, imdb_rate, type, genres FROM movies WHERE type = :type AND imdb_code != :imdb_code AND ({$whereGenre}) LIMIT 50";
    $params[':type'] = $currentMovie['type'];
    $params[':imdb_code'] = $currentMovie['imdb_code'];
    $stmt = $pdo->prepare($sql);
    foreach($params as $key=>$val) $stmt->bindValue($key, $val, is_int($val)?PDO::PARAM_INT:PDO::PARAM_STR);
    $stmt->execute();
    $results = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if(empty($results)) return [];
    $currentGenresArr = array_map('trim', explode(',', $currentMovie['genres']));
    $scored = [];
    foreach($results as $movie) {
        $movieGenres = array_map('trim', explode(',', $movie['genres']));
        $common = count(array_intersect($currentGenresArr, $movieGenres));
        $scored[] = ['movie'=>$movie, 'common'=>$common];
    }
    usort($scored, function($a,$b){ return $b['common']-$a['common']; });
    $grouped = [];
    foreach($scored as $item) $grouped[$item['common']][] = $item['movie'];
    $final = [];
    foreach($grouped as $movies) { shuffle($movies); $final = array_merge($final, $movies); }
    $unique = [];
    foreach($final as $movie) $unique[$movie['imdb_code']] = $movie;
    return array_slice($unique, 0, $limit);
}

function getRelatedMoviesFromDB($pdo, $currentMovie, $limit=12) {
    if(!$currentMovie) return [];
    $stopWords = ['the','a','an','and','of','to','in','for','on','with','by','at','from','is','was','are','were','be','been','being','have','has','had','having','do','does','did','doing','but','or','for','nor','so','yet'];
    $titleLow = mb_strtolower($currentMovie['title'], 'UTF-8');
    $titleLow = preg_replace('/[^\p{L}\p{N}]/u', ' ', $titleLow);
    $titleWords = explode(' ', $titleLow);
    $keywords = array_unique(array_filter($titleWords, function($w) use ($stopWords) { return mb_strlen($w)>2 && !in_array($w,$stopWords); }));
    if(empty($keywords)) $keywords = [mb_substr($titleLow,0,3)];
    $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, imdb_rate, type FROM movies WHERE type=? AND imdb_code!=?");
    $stmt->execute([$currentMovie['type'], $currentMovie['imdb_code']]);
    $allMovies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $scores = [];
    foreach($allMovies as $m) {
        $score = 0;
        $movieTitleLow = mb_strtolower($m['title'], 'UTF-8');
        foreach($keywords as $kw) {
            if(mb_strpos($movieTitleLow, $kw, 0, 'UTF-8') !== false) { $score+=10; if(preg_match("/\b".preg_quote($kw,'/')."\b/u", $movieTitleLow)) $score+=5; }
        }
        if(!empty($m['year']) && !empty($currentMovie['year']) && abs($m['year']-$currentMovie['year'])<=2) $score+=7;
        if(!empty($m['imdb_rate']) && !empty($currentMovie['imdb_rate']) && abs($m['imdb_rate']-$currentMovie['imdb_rate'])<=1.5) $score+=3;
        if($score>0) $scores[] = ['movie'=>$m, 'score'=>$score];
    }
    usort($scores, function($a,$b){ return $b['score']-$a['score']; });
    $unique = [];
    foreach($scores as $item) $unique[$item['movie']['imdb_code']] = $item['movie'];
    return array_slice($unique, 0, $limit);
}

$genreRelatedMovies = (!$isArc1 && $movieData) ? getGenreRelatedMovies($pdo, $movieData, 12) : [];
$relatedMovies      = (!$isArc1 && $movieData) ? getRelatedMoviesFromDB($pdo, $movieData, 12) : [];

$hasDub = $isMovie ? count($dubLinks) > 0 : $seriesHasDub;
$hasSoft = $isMovie ? count($softLinks) > 0 : $seriesHasSoft;
$bmArc2HasDubDisplay = $isMovie ? $hasDub : $seriesHasDub;
$bmArc2HasSoftDisplay = $isMovie ? $hasSoft : $seriesHasSoft;

// First playable Archive-2 movie source, used by the poster/hero play buttons.
// Prefer subtitle versions, then dubbed versions, matching the internal player's default order.
$arc2MovieFirstPlay = ['url'=>'', 'label'=>''];
if (!$isArc1 && $isMovie) {
    foreach ([$softLinks, $dubLinks] as $bmArc2MovieGroup) {
        foreach ((array)$bmArc2MovieGroup as $bmArc2MovieQuality => $bmArc2MovieItems) {
            foreach ((array)$bmArc2MovieItems as $bmArc2MovieItem) {
                $bmArc2MovieUrl = trim((string)($bmArc2MovieItem['url'] ?? ''));
                if ($bmArc2MovieUrl === '') continue;
                $arc2MovieFirstPlay = [
                    'url' => $bmArc2MovieUrl,
                    'label' => trim((string)$bmArc2MovieQuality) ?: ($userLang === 'fa' ? 'پخش فیلم' : 'Play movie')
                ];
                break 3;
            }
        }
    }
}
$pageTitle = $movieData['title_fa'] ?: $movieData['title'];

// Notifications - هماهنگ با header/index
$notificationsList = [];
$activeNotification = null;
$notificationSeen = false;
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
    $stmt->execute();
    $activeNotification = $stmt->fetch(PDO::FETCH_ASSOC);
    if($activeNotification) {
        $cookieName = 'notification_seen_' . $activeNotification['id'];
        if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
    }
} catch (Throwable $e) {
    $notificationsList = [];
    $activeNotification = null;
    $notificationSeen = false;
}

// =================== سیستم کامنت (با تأیید ادمین، اسپویلر دکمه‌ای، حذف) ===================
function updateMovieRating($pdo, $movieId) {
    $approvedStatus = bm_comment_public_status_sql('comments');
    $rootParent = bm_comment_root_parent_sql('comments');
    $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM comments WHERE movie_id = ? AND rating > 0 AND {$approvedStatus} AND {$rootParent}");
    $stmt->execute([$movieId]);
    $data = $stmt->fetch();
    $stmt = $pdo->prepare("INSERT INTO movie_ratings (movie_id, avg_rating, total_votes) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE avg_rating = ?, total_votes = ?");
    $stmt->execute([$movieId, $data['avg_rating'] ?? 0, $data['total_votes'] ?? 0, $data['avg_rating'] ?? 0, $data['total_votes'] ?? 0]);
    return ['avg' => round($data['avg_rating'] ?? 0, 1), 'total' => $data['total_votes'] ?? 0];
}

$ratingData = null; $userRating = 0; $inWatchlist = false; $avgRating = 0; $totalVotes = 0;
if(!$isArc1 && $movieData) {
    $stmt = $pdo->prepare("SELECT avg_rating, total_votes FROM movie_ratings WHERE movie_id = ?");
    $stmt->execute([$movieData['id']]);
    $ratingData = $stmt->fetch();
    if($currentUser) {
        $stmt = $pdo->prepare("SELECT id FROM watchlist WHERE user_id = ? AND movie_id = ?");
        $stmt->execute([$currentUser['id'], $movieData['id']]);
        $inWatchlist = $stmt->fetch() ? true : false;
        $approvedUserStatus = bm_comment_public_status_sql('comments');
        $rootUserParent = bm_comment_root_parent_sql('comments');
        $stmt = $pdo->prepare("SELECT rating FROM comments WHERE movie_id = ? AND user_id = ? AND {$approvedUserStatus} AND {$rootUserParent}");
        $stmt->execute([$movieData['id'], $currentUser['id']]);
        $userComment = $stmt->fetch();
        if($userComment) $userRating = $userComment['rating'];
    }
    $avgRating = $ratingData['avg_rating'] ?? 0;
    $totalVotes = $ratingData['total_votes'] ?? 0;
}

$commentPage = isset($_GET['comment_page']) ? max(1, (int)$_GET['comment_page']) : 1;
$commentsPerPage = 10;
$commentOffset = ($commentPage - 1) * $commentsPerPage;
$commentSort = strtolower(trim((string)($_GET['comment_sort'] ?? 'latest')));
if (!in_array($commentSort, ['latest','oldest','popular','controversial','replies'], true)) $commentSort = 'latest';
$approvedC = bm_comment_public_status_sql('c');
$approvedR = bm_comment_public_status_sql('r');
$rootC = bm_comment_root_parent_sql('c');
$limitSql = max(1, (int)$commentsPerPage);
$offsetSql = max(0, (int)$commentOffset);
$viewerId = (int)($currentUser['id'] ?? 0);
$orderSql = bm_site_comment_order_sql($commentSort, 'c', 'comment_likes', 'comments');

$stmt = $pdo->prepare("
    SELECT c.*, 
           COALESCE((SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
           COALESCE((SELECT COUNT(*) FROM comment_likes WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
           COALESCE((SELECT type FROM comment_likes WHERE comment_id = c.id AND user_id = ? LIMIT 1), '') as user_vote,
           (SELECT COUNT(*) FROM comments r WHERE r.parent_id = c.id AND ({$approvedR} OR (? > 0 AND r.user_id=? AND LOWER(TRIM(CAST(r.status AS CHAR)))='pending'))) as reply_count,
           COALESCE(u.role, 'user') AS role, COALESCE(u.avatar, '') AS avatar, COALESCE(u.admin_badge_color, '') AS admin_badge_color
    FROM comments c
    LEFT JOIN users u ON c.user_id = u.id
    WHERE c.movie_id = ? AND {$rootC} AND ({$approvedC} OR (? > 0 AND c.user_id=? AND LOWER(TRIM(CAST(c.status AS CHAR)))='pending'))
    ORDER BY {$orderSql}
    LIMIT {$limitSql} OFFSET {$offsetSql}
");
$stmt->execute([$viewerId, $viewerId, $viewerId, (int)($movieData['id'] ?? 0), $viewerId, $viewerId]);
$comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$approvedBase = bm_comment_public_status_sql('comments');
$rootBase = bm_comment_root_parent_sql('comments');
$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM comments WHERE movie_id = ? AND {$rootBase} AND ({$approvedBase} OR (? > 0 AND user_id=? AND LOWER(TRIM(CAST(status AS CHAR)))='pending'))");
$totalStmt->execute([(int)($movieData['id'] ?? 0), $viewerId, $viewerId]);
$totalComments = (int)$totalStmt->fetchColumn();
$totalCommentPages = (int)ceil($totalComments / $commentsPerPage);

function getRepliesHTML($commentId, $currentUserId, $userLang, $isArchive1 = false, $depth = 1) {
    global $pdo, $currentUser, $bmCommentConfig;
    if ($depth > 4 || empty($bmCommentConfig['replies'])) return '';
    $commentId = (int)$commentId;
    $currentUserId = (int)$currentUserId;
    if ($isArchive1) bm_ensure_archive1_comment_tables($pdo);
    $commentTable = $isArchive1 ? 'archive1_comments' : 'comments';
    $likeTable = $isArchive1 ? 'archive1_comment_likes' : 'comment_likes';
    $approvedReply = bm_comment_public_status_sql('r');
    $stmt = $pdo->prepare("
        SELECT r.*, 
               COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'like'), 0) as like_count,
               COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'dislike'), 0) as dislike_count,
               COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = r.id AND user_id = ? LIMIT 1), '') as user_vote,
               COALESCE(u.username, r.username, 'کاربر') as display_name,
               COALESCE(u.role, 'user') as role,
               COALESCE(u.avatar, '') as avatar,
               COALESCE(u.admin_badge_color, '') as admin_badge_color
        FROM {$commentTable} r
        LEFT JOIN users u ON r.user_id = u.id
        WHERE r.parent_id = ? AND ({$approvedReply} OR (? > 0 AND r.user_id = ? AND LOWER(TRIM(CAST(r.status AS CHAR)))='pending'))
        ORDER BY r.created_at ASC, r.id ASC
    ");
    $stmt->execute([$currentUserId, $commentId, $currentUserId, $currentUserId]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (empty($replies)) return '';

    $html = '<div class="replies-container bm-reply-depth-'.$depth.'">';
    foreach ($replies as $reply) {
        $id=(int)$reply['id'];
        $roleBadge = bm_site_comment_role_badge((string)($reply['role'] ?? 'user'), (string)($reply['admin_badge_color'] ?? ''));
        $avatar = trim(str_replace('\\', '/', (string)($reply['avatar'] ?? '')));
        if ($avatar !== '' && !preg_match('~^https?://~i', $avatar) && $avatar[0] !== '/') {
            $avatarPath = ltrim($avatar, '/');
            if (strpos($avatarPath, '..') === false && preg_match('~^(?:assets/avatars|uploads/avatars)/[A-Za-z0-9._/\\-]+$~i', $avatarPath)) {
                $avatar = '/' . $avatarPath;
            } else {
                $avatar = '';
            }
        }
        $avatarHtml = ($avatar !== '' && preg_match('~^(https?://|/)~i',$avatar))
            ? '<img src="'.htmlspecialchars($avatar,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" loading="lazy" decoding="async" alt="">'
            : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        $replyText = bm_comment_media_text_or_html((string)$reply['comment']);
        if ((int)($reply['spoiler'] ?? 0) === 1) {
            $replyText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">'.$replyText.'</div><button type="button" class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\');this.style.display=\'none\';">'.($userLang==='fa'?'مشاهده اسپویل':'Show spoiler').'</button></div>';
        }
        $isAdmin = bm_site_comment_is_admin($currentUser);
        $canDelete = $currentUserId > 0 && ($currentUserId === (int)($reply['user_id']??0) || $isAdmin);
        $canEdit = bm_site_comment_can_edit($reply, $currentUser) && bm_sticker_find_marker((string)($reply['comment'] ?? '')) === null;
        $status = strtolower(trim((string)($reply['status']??'')));
        $meta = '';
        if (!empty($reply['edited_at'])) $meta .= '<span class="bm-comment-edited">'.($userLang==='fa'?'ویرایش‌شده':'Edited').'</span>';
        if ($status==='pending') $meta .= '<span class="bm-comment-pending">'.($userLang==='fa'?'در انتظار تأیید':'Pending').'</span>';
        $buttons = '';
        if (!empty($bmCommentConfig['replies'])) $buttons .= '<button type="button" class="reply-btn" data-id="'.$id.'">'.($userLang==='fa'?'پاسخ':'Reply').'</button>';
        if ($canEdit) $buttons .= '<button type="button" class="edit-comment-btn" data-id="'.$id.'" data-text="'.htmlspecialchars((string)$reply['comment'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" data-spoiler="'.((int)($reply['spoiler']??0)).'">'.($userLang==='fa'?'ویرایش':'Edit').'</button>';
        if ($currentUserId > 0 && !empty($bmCommentConfig['reports'])) $buttons .= '<button type="button" class="report-comment-btn" data-id="'.$id.'">'.($userLang==='fa'?'گزارش تخلف':'Report').'</button>';
        if ($canDelete) $buttons .= '<button type="button" class="delete-comment-btn" data-id="'.$id.'">'.($userLang==='fa'?'حذف':'Delete').'</button>';
        $voteHtml='';
        if (!empty($bmCommentConfig['votes'])) {
            $voteHtml='<div class="bm-comment-evaluation" role="group" aria-label="Comment rating">'
            .'<button type="button" class="comment-like '.(($reply['user_vote']??'')==='like'?'active':'').'" data-id="'.$id.'" data-type="like" aria-label="Like"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg><span class="like-count">'.number_format((int)($reply['like_count']??0)).'</span></button>'
            .'<span class="bm-comment-vote-divider" aria-hidden="true"></span>'
            .'<button type="button" class="comment-dislike '.(($reply['user_vote']??'')==='dislike'?'active':'').'" data-id="'.$id.'" data-type="dislike" aria-label="Dislike"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg><span class="dislike-count">'.number_format((int)($reply['dislike_count']??0)).'</span></button>'
            .'</div>';
        }
        $children = $depth < 4 ? getRepliesHTML($id,$currentUserId,$userLang,$isArchive1,$depth+1) : '';
        $html .= '<div class="reply-item" id="comment-'.$id.'" data-id="'.$id.'" data-parent-id="'.$commentId.'">'
            .'<div class="reply-header"><div class="reply-user"><div class="reply-avatar">'.$avatarHtml.'</div><span class="reply-name">'.htmlspecialchars((string)($reply['display_name']??$reply['username']??'کاربر'),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').' '.$roleBadge.'</span></div><span class="comment-date">'.formatCommentDate($reply['created_at']??'', $userLang).' '.$meta.'</span></div>'
            .'<div class="reply-text">'.$replyText.'</div><div class="reply-actions">'.$voteHtml.$buttons.'</div>'
            .'<div class="reply-form-container" id="reply-form-'.$id.'" style="display:none"></div>'.$children.'</div>';
    }
    return $html.'</div>';
}

function formatCommentDate($date, $lang) {
    if(empty($date)) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $timestamp = strtotime($date);
    if($timestamp === false) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $diff = time() - $timestamp;
    if($diff < 0) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if($diff < 60) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if($diff < 3600) return floor($diff/60).($lang === 'fa' ? ' دقیقه پیش' : ' minutes ago');
    if($diff < 86400) return floor($diff/3600).($lang === 'fa' ? ' ساعت پیش' : ' hours ago');
    if($diff < 604800) return floor($diff/86400).($lang === 'fa' ? ' روز پیش' : ' days ago');
    if($diff < 2592000) return floor($diff/604800).($lang === 'fa' ? ' هفته پیش' : ' weeks ago');
    if($diff < 31536000) return floor($diff/2592000).($lang === 'fa' ? ' ماه پیش' : ' months ago');
    return floor($diff/31536000).($lang === 'fa' ? ' سال پیش' : ' years ago');
}

function renderStars($rating) {
    $full = floor($rating);
    $empty = 5 - $full;
    $stars = '';
    for($i=0;$i<$full;$i++) $stars .= '<svg class="star star-full" viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    for($i=0;$i<$empty;$i++) $stars .= '<svg class="star star-empty" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    return $stars;
}
function renderStarInput($selected = 0) {
    $stars = '';
    for($i=1;$i<=5;$i++) $stars .= '<svg class="star-input" data-value="'.$i.'" viewBox="0 0 24 24" fill="'.($i<=$selected ? 'currentColor' : 'none').'" stroke="currentColor" style="width:24px;height:24px;cursor:pointer;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    return $stars;
}

function renderCommentHTML($comment, $lang, $currentUserId, $isArchive1 = false) {
    global $currentUser, $bmCommentConfig;
    $id=(int)($comment['id']??0);
    $roleBadge=bm_site_comment_role_badge((string)($comment['role']??'user'), (string)($comment['admin_badge_color'] ?? ''));
    $replyCount=(int)($comment['reply_count']??0);
    $avatar=trim(str_replace('\\', '/', (string)($comment['avatar']??'')));
    if ($avatar!=='' && !preg_match('~^https?://~i',$avatar) && $avatar[0] !== '/') {
        $avatarPath=ltrim($avatar,'/');
        if (strpos($avatarPath,'..')===false && preg_match('~^(?:assets/avatars|uploads/avatars)/[A-Za-z0-9._/\\-]+$~i',$avatarPath)) {
            $avatar='/'.$avatarPath;
        } else {
            $avatar='';
        }
    }
    $avatarHtml=($avatar!=='' && preg_match('~^(https?://|/)~i',$avatar))
        ? '<img src="'.htmlspecialchars($avatar,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" loading="lazy" decoding="async" alt="">'
        : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
    $commentText=bm_comment_media_text_or_html((string)($comment['comment']??''));
    if ((int)($comment['spoiler']??0)===1) {
        $commentText='<div class="spoiler-wrapper"><div class="spoiler-content-hidden">'.$commentText.'</div><button type="button" class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\');this.style.display=\'none\';">'.($lang==='fa'?'مشاهده اسپویل':'Show spoiler').'</button></div>';
    }
    $isAdmin=bm_site_comment_is_admin($currentUser);
    $canDelete=$currentUserId>0 && ($currentUserId===(int)($comment['user_id']??0) || $isAdmin);
    $canEdit=bm_site_comment_can_edit($comment,$currentUser) && bm_sticker_find_marker((string)($comment['comment'] ?? '')) === null;
    $status=strtolower(trim((string)($comment['status']??'')));
    $stateMeta='';
    if (!empty($comment['is_pinned'])) $stateMeta.='<span class="bm-comment-pinned">📌 '.($lang==='fa'?'پین‌شده':'Pinned').'</span>';
    if (!empty($comment['edited_at'])) $stateMeta.='<span class="bm-comment-edited">'.($lang==='fa'?'ویرایش‌شده':'Edited').'</span>';
    if ($status==='pending') $stateMeta.='<span class="bm-comment-pending">'.($lang==='fa'?'در انتظار تأیید':'Pending').'</span>';
    $buttons='';
    if (!empty($bmCommentConfig['replies'])) $buttons.='<button type="button" class="reply-btn" data-id="'.$id.'"><span>'.($lang==='fa'?'پاسخ':'Reply').'</span>'.($replyCount?'<span class="reply-count">('.$replyCount.')</span>':'').'</button>';
    if ($canEdit) $buttons.='<button type="button" class="edit-comment-btn" data-id="'.$id.'" data-text="'.htmlspecialchars((string)$comment['comment'],ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').'" data-spoiler="'.((int)($comment['spoiler']??0)).'">'.($lang==='fa'?'ویرایش':'Edit').'</button>';
    if ($currentUserId>0 && !empty($bmCommentConfig['reports'])) $buttons.='<button type="button" class="report-comment-btn" data-id="'.$id.'">'.($lang==='fa'?'گزارش تخلف':'Report').'</button>';
    if ($isAdmin) $buttons.='<button type="button" class="pin-comment-btn" data-id="'.$id.'" data-pin="'.(!empty($comment['is_pinned'])?'0':'1').'">'.(!empty($comment['is_pinned'])?($lang==='fa'?'برداشتن پین':'Unpin'):($lang==='fa'?'پین':'Pin')).'</button>';
    if ($canDelete) $buttons.='<button type="button" class="delete-comment-btn" data-id="'.$id.'">'.($lang==='fa'?'حذف':'Delete').'</button>';
    $voteHtml='';
    if (!empty($bmCommentConfig['votes'])) {
        $voteHtml='<div class="bm-comment-evaluation" role="group" aria-label="Comment rating">'
        .'<button type="button" class="comment-like '.(($comment['user_vote']??'')==='like'?'active':'').'" data-id="'.$id.'" data-type="like" aria-label="Like"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg><span class="like-count">'.number_format((int)($comment['like_count']??0)).'</span></button>'
        .'<span class="bm-comment-vote-divider" aria-hidden="true"></span>'
        .'<button type="button" class="comment-dislike '.(($comment['user_vote']??'')==='dislike'?'active':'').'" data-id="'.$id.'" data-type="dislike" aria-label="Dislike"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg><span class="dislike-count">'.number_format((int)($comment['dislike_count']??0)).'</span></button>'
        .'</div>';
    }
    $repliesHtml=getRepliesHTML($id,$currentUserId,$lang,$isArchive1,1);
    $classes='comment-item'.(!empty($comment['is_pinned'])?' bm-comment-is-pinned':'').($status==='pending'?' bm-comment-is-pending':'');
    return '<div class="'.$classes.'" id="comment-'.$id.'" data-id="'.$id.'" data-reply-count="'.$replyCount.'">'
        .'<div class="comment-header"><div class="comment-user"><div class="comment-avatar-small">'.$avatarHtml.'</div><div><div class="comment-name">'.htmlspecialchars((string)($comment['username']??'کاربر'),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8').' '.$roleBadge.'</div><div class="comment-date">'.formatCommentDate($comment['created_at']??'', $lang).' '.$stateMeta.'</div></div></div><div class="comment-rating-stars">'.renderStars((int)($comment['rating']??0)).'</div></div>'
        .'<div class="comment-text">'.$commentText.'</div><div class="comment-actions">'.$voteHtml.$buttons.'</div>'
        .'<div class="reply-form-container" id="reply-form-'.$id.'" style="display:none"></div>'.$repliesHtml.'</div>';
}
?>

<?php
if (!function_exists('bm_bulk_copy_quality_key')) {
    function bm_bulk_copy_quality_key($quality): string {
        $q = trim(preg_replace('/\s+/u', ' ', strip_tags((string)$quality)));
        $lower = strtolower($q);
        if (preg_match('/(?:2160|4k)/i', $lower)) return '2160p';
        if (preg_match('/1440/i', $lower)) return '1440p';
        if (preg_match('/1080/i', $lower)) return '1080p';
        if (preg_match('/720/i', $lower)) return '720p';
        if (preg_match('/480/i', $lower)) return '480p';
        if (preg_match('/360/i', $lower)) return '360p';
        return $q !== '' ? $q : 'نامشخص';
    }
}
if (!function_exists('bm_bulk_copy_quality_rank')) {
    function bm_bulk_copy_quality_rank(string $quality): int {
        return match (strtolower($quality)) {
            '2160p' => 60,
            '1440p' => 50,
            '1080p' => 40,
            '720p' => 30,
            '480p' => 20,
            '360p' => 10,
            default => 1,
        };
    }
}
if (!function_exists('bm_bulk_copy_type_label')) {
    function bm_bulk_copy_type_label(string $type, string $lang = 'fa'): string {
        $type = strtolower(trim($type));
        $fa = $lang === 'fa';
        if (in_array($type, ['dub','dubbed','audio'], true)) return $fa ? 'دوبله' : 'Dubbed';
        if ($type === 'hardsub') return $fa ? 'هاردساب' : 'Hard Sub';
        if ($type === 'softsub') return $fa ? 'سافت‌ساب' : 'Soft Sub';
        if ($type === 'nosub') return $fa ? 'بدون زیرنویس' : 'No Subtitle';
        if ($type === 'original') return $fa ? 'زبان اصلی' : 'Original';
        return $fa ? 'زیرنویس فارسی' : 'Persian Subtitle';
    }
}
if (!function_exists('bm_bulk_copy_build_catalog')) {
    function bm_bulk_copy_build_catalog(
        bool $external,
        bool $isSeries,
        array $externalSeasons,
        array $localSeasons,
        string $title,
        string $lang = 'fa'
    ): array {
        $catalog = [
            'title' => $title,
            'lang' => $lang,
            'content_type' => $isSeries ? 'series' : 'movie',
            'is_series' => $isSeries,
            'seasons' => [],
        ];
        $seen = [];

        if ($external) {
            foreach ($externalSeasons as $seasonKey => $episodes) {
                $seasonNo = (int)(preg_replace('/\D+/', '', (string)$seasonKey) ?: 1);
                $normalizedSeason = 'S' . str_pad((string)$seasonNo, 2, '0', STR_PAD_LEFT);
                foreach ((array)$episodes as $episodeKey => $links) {
                    $episodeNo = $episodeKey === 'full' ? 0 : (int)(preg_replace('/\D+/', '', (string)$episodeKey) ?: 0);
                    foreach ((array)$links as $link) {
                        if (!empty($link['source_download_locked'])) continue;
                        $url = function_exists('bm_ext_safe_url') ? bm_ext_safe_url($link['url'] ?? '') : trim((string)($link['url'] ?? ''));
                        if ($url === '' || isset($seen[$normalizedSeason . '|' . $url])) continue;
                        $seen[$normalizedSeason . '|' . $url] = true;
                        $originalQuality = trim((string)($link['quality'] ?? ''));
                        $quality = bm_bulk_copy_quality_key($originalQuality);
                        $type = strtolower(trim((string)($link['type'] ?? 'subtitle')));
                        $catalog['seasons'][$normalizedSeason]['links'][] = [
                            'episode' => $episodeNo,
                            'episode_label' => $episodeNo > 0 ? (($lang === 'fa' ? 'قسمت ' : 'Episode ') . $episodeNo) : ($lang === 'fa' ? 'فصل کامل' : 'Full season'),
                            'quality' => $quality,
                            'quality_original' => $originalQuality !== '' ? $originalQuality : $quality,
                            'type' => $type,
                            'type_label' => bm_bulk_copy_type_label($type, $lang),
                            'size' => trim((string)($link['size'] ?? '')),
                            'url' => function_exists('bm_dl_wrap_url') ? bm_dl_wrap_url($url) : $url,
                        ];
                    }
                }
            }
        } else {
            foreach ($localSeasons as $seasonKey => $links) {
                $seasonNo = (int)(preg_replace('/\D+/', '', (string)$seasonKey) ?: 1);
                $normalizedSeason = 'S' . str_pad((string)$seasonNo, 2, '0', STR_PAD_LEFT);
                foreach ((array)$links as $link) {
                    $url = function_exists('bm_ext_safe_url') ? bm_ext_safe_url($link['url'] ?? '') : trim((string)($link['url'] ?? ''));
                    if ($url === '' || isset($seen[$normalizedSeason . '|' . $url])) continue;
                    $seen[$normalizedSeason . '|' . $url] = true;
                    $episodeNo = isset($link['episode']) && $link['episode'] !== null ? (int)$link['episode'] : 0;
                    $originalQuality = trim((string)($link['quality'] ?? ''));
                    $quality = bm_bulk_copy_quality_key($originalQuality);
                    $type = strtolower(trim((string)($link['type'] ?? 'soft')));
                    $catalog['seasons'][$normalizedSeason]['links'][] = [
                        'episode' => $episodeNo,
                        'episode_label' => $episodeNo > 0 ? (($lang === 'fa' ? 'قسمت ' : 'Episode ') . $episodeNo) : ($lang === 'fa' ? 'فصل کامل' : 'Full season'),
                        'quality' => $quality,
                        'quality_original' => $originalQuality !== '' ? $originalQuality : $quality,
                        'type' => $type,
                        'type_label' => bm_bulk_copy_type_label($type, $lang),
                        'size' => trim((string)($link['size'] ?? '')),
                        'url' => function_exists('bm_dl_wrap_url') ? bm_dl_wrap_url($url) : $url,
                    ];
                }
            }
        }

        ksort($catalog['seasons'], SORT_NATURAL);
        foreach ($catalog['seasons'] as $seasonKey => &$season) {
            $seasonNo = (int)(preg_replace('/\D+/', '', $seasonKey) ?: 1);
            $season['number'] = $seasonNo;
            $season['label'] = ($lang === 'fa' ? 'فصل ' : 'Season ') . $seasonNo;
            $season['links'] = array_values($season['links'] ?? []);
            usort($season['links'], static function (array $a, array $b): int {
                $ea = (int)($a['episode'] ?? 0);
                $eb = (int)($b['episode'] ?? 0);
                if ($ea !== $eb) {
                    if ($ea === 0) return 1;
                    if ($eb === 0) return -1;
                    return $ea <=> $eb;
                }
                $qa = bm_bulk_copy_quality_rank((string)($a['quality'] ?? ''));
                $qb = bm_bulk_copy_quality_rank((string)($b['quality'] ?? ''));
                if ($qa !== $qb) return $qb <=> $qa;
                return strcmp((string)($a['type'] ?? ''), (string)($b['type'] ?? ''));
            });
            $qualityCounts = [];
            $typeCounts = [];
            $episodes = [];
            foreach ($season['links'] as $link) {
                $q = (string)$link['quality'];
                $t = (string)$link['type'];
                $qualityCounts[$q] = ($qualityCounts[$q] ?? 0) + 1;
                $typeCounts[$t] = ($typeCounts[$t] ?? 0) + 1;
                if ((int)$link['episode'] > 0) $episodes[(int)$link['episode']] = true;
            }
            uksort($qualityCounts, static fn($a, $b) => bm_bulk_copy_quality_rank($b) <=> bm_bulk_copy_quality_rank($a));
            $season['qualities'] = $qualityCounts;
            $season['types'] = $typeCounts;
            $season['episode_count'] = count($episodes);
            $season['link_count'] = count($season['links']);
        }
        unset($season);

        $catalog['seasons'] = array_filter($catalog['seasons'], static fn($season) => !empty($season['links']));
        $catalog['season_count'] = count($catalog['seasons']);
        $catalog['link_count'] = array_sum(array_map(static fn($season) => (int)($season['link_count'] ?? 0), $catalog['seasons']));
        return $catalog;
    }
}

$bmSeriesCopyTitle = $isArc1
    ? trim((string)($arc1Title ?? $arc1TitleEn ?? ''))
    : trim((string)(($movieData['title_fa'] ?? '') ?: ($movieData['title'] ?? '')));
$bmSeriesCopyPage = (bool)($isArc1
    ? (($arc1IsSeries ?? false) || (($arc1Type ?? '') === 'series') || !empty($arc1SeriesSeasons ?? []))
    : ((!($isMovie ?? true)) || (($movieData['type'] ?? '') === 'series') || !empty($seriesSeasons ?? []))
);
// V127: some external APIs mark a series as movie even though episode rows exist.
// Detect the real page shape so the all-links tool is available on every archive.
if (!$bmSeriesCopyPage && $isArc1) {
    $bmSeriesSignals = strtolower(trim((string)($arc1Type ?? '') . ' ' . (string)($arc1Slug ?? '') . ' ' . (string)($arc1SourceUrl ?? '')));
    if (strpos($bmSeriesSignals, 'series') !== false || strpos($bmSeriesSignals, 'serial') !== false) {
        $bmSeriesCopyPage = true;
    }
    if (!$bmSeriesCopyPage && !empty($arc1Downloads) && is_array($arc1Downloads)) {
        foreach ($arc1Downloads as $bmSeriesCandidate) {
            if (!is_array($bmSeriesCandidate)) continue;
            if (isset($bmSeriesCandidate['season']) || isset($bmSeriesCandidate['episode']) || isset($bmSeriesCandidate['season_number']) || isset($bmSeriesCandidate['episode_number'])) {
                $bmSeriesCopyPage = true;
                break;
            }
        }
    }
}
if (!$bmSeriesCopyPage && !$isArc1 && (!empty($seriesSeasons ?? []) || (($movieData['type'] ?? '') === 'series'))) {
    $bmSeriesCopyPage = true;
}
$bmSeriesCopyCatalog = bm_bulk_copy_build_catalog(
    (bool)$isArc1,
    $bmSeriesCopyPage,
    is_array($arc1SeriesSeasons ?? null) ? $arc1SeriesSeasons : [],
    is_array($seriesSeasons ?? null) ? $seriesSeasons : [],
    $bmSeriesCopyTitle,
    $userLang
);
if (!$bmArchiveDownloadAllowed) {
    $bmSeriesCopyCatalog['seasons'] = [];
    $bmSeriesCopyCatalog['season_count'] = 0;
    $bmSeriesCopyCatalog['link_count'] = 0;
}
if (empty($bmSeriesCopyCatalog) || !is_array($bmSeriesCopyCatalog)) {
    $bmSeriesCopyCatalog = [
        'title' => $bmSeriesCopyTitle,
        'lang' => $userLang,
        'content_type' => $bmSeriesCopyPage ? 'series' : 'movie',
        'is_series' => $bmSeriesCopyPage,
        'seasons' => [],
        'season_count' => 0,
        'link_count' => 0,
    ];
}
$bmHasSeriesCopy = !empty($bmSeriesCopyCatalog['seasons']);
$bmShowSeriesCopy = $bmArchiveDownloadAllowed && ($bmSeriesCopyPage || ($isArc1 && !empty($arc1SeriesSeasons))) && (!$isArc4 || $bmHasSeriesCopy); // Locked downloads never render copy/export controls.
$bmRefreshArchiveVipGateState();
bm_perf_context([
    'archive' => $isArc1 ? ($isArc6 ? 'archive6' : ($isArc5 ? 'archive5' : ($isArc4 ? 'archive4' : ($isArc3 ? 'archive3' : 'archive1')))) : 'archive2',
    'movie_id' => $isArc1 ? (int)$arc1VirtualMovieId : (int)($movieData['id'] ?? 0),
    'series_bulk_links' => (int)($bmSeriesCopyCatalog['link_count'] ?? 0),
]);
bm_perf_mark('movie-data-ready');
?>
<?php arc1_render:
// BM WARNING FIX: the Archive-1 goto bypasses Archive-2 bulk-copy setup.
// Initialize safe fallbacks ONLY if the shared variables have not been built.
// Do not expose VIP download links or claim a catalog exists on a skipped path.
if (!isset($bmSeriesCopyPage)) {
    $bmSeriesCopyPage = (bool)(($arc1IsSeries ?? false)
        || (($arc1Type ?? '') === 'series') || !empty($arc1SeriesSeasons ?? []));
}
if (!isset($bmSeriesCopyCatalog) || !is_array($bmSeriesCopyCatalog)) {
    $bmSeriesCopyCatalog = [
        'title' => trim((string)($arc1Title ?? $arc1TitleEn ?? '')),
        'lang' => (string)($userLang ?? 'fa'),
        'content_type' => $bmSeriesCopyPage ? 'series' : 'movie',
        'is_series' => $bmSeriesCopyPage,
        'seasons' => [], 'season_count' => 0, 'link_count' => 0,
    ];
}
if (!isset($bmHasSeriesCopy)) $bmHasSeriesCopy = false;
if (!isset($bmShowSeriesCopy)) $bmShowSeriesCopy = false;
?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover, user-scalable=no">
    <link rel="preload" href="/assets/fonts/bonVF.woff2" as="font" type="font/woff2" crossorigin>
    <meta name="csrf-token" content="<?= e($csrfToken) ?>">
    <?php
    if($isArc1 && $arc1Data) {
        // SEO برای آرشیو ۱
        $seoTitleEn  = $arc1Title ?? '';
        $seoTitleFa  = $arc1Title ?? '';
        $seoYear     = $arc1Year  ?? '';
        $seoType     = ($arc1IsSeries ?? false) ? ($userLang==='fa'?'سریال':'Series') : ($userLang==='fa'?'فیلم':'Movie');
        $seoGenres   = is_array($arc1Genres ?? []) ? implode(', ', $arc1Genres) : '';
        $seoImdb     = '';
        $seoImage    = $arc1Poster ?? '';
        $seoDesc     = $arc1Desc  ?? '';
        $seoDescEn   = $arc1Desc  ?? '';
    } else {
        $seoTitleEn  = trim((string)($movieData['title']    ?? ''));
        $seoTitleFa  = trim((string)($movieData['title_fa'] ?? ''));
        $seoYear     = !empty($movieData['year'])      ? (int)$movieData['year']      : '';
        $seoType     = ($movieData['type'] ?? '') === 'series' ? ($userLang === 'fa' ? 'سریال' : 'Series') : ($userLang === 'fa' ? 'فیلم' : 'Movie');
        $seoGenres   = trim((string)($movieData['genres'] ?? ''));
        $seoImdb     = trim((string)($movieData['imdb_code'] ?? ''));
        $seoImgRaw   = trim((string)($movieData['poster'] ?? ($movieData['image'] ?? '')));
        // Movie pages in the local/database archive render posters from /posters/{imdb}.webp.
        // Use that same stable absolute URL for Open Graph/Twitter previews when the DB poster/image
        // column is empty, otherwise Telegram/WhatsApp receive no og:image at all.
        $seoLocalPoster = $seoImdb !== ''
            ? (rtrim(SITE_URL, '/') . '/posters/' . rawurlencode(preg_replace('/[^A-Za-z0-9_-]/', '', $seoImdb)) . '.webp')
            : '';
        $seoImage    = $seoImgRaw !== ''
            ? (preg_match('/^https?:\/\//i', $seoImgRaw) ? $seoImgRaw : rtrim(SITE_URL, '/') . '/' . ltrim($seoImgRaw, '/'))
            : $seoLocalPoster;
        $seoDesc     = trim((string)($movieData['description_fa'] ?? ($movieData['description'] ?? '')));
        $seoDescEn   = trim((string)($movieData['description'] ?? ''));
    }
    $seoRating   = !empty($movieData['imdb_rate']) ? (float)$movieData['imdb_rate'] : 0;
    $canonicalFull = rtrim(SITE_URL, '/') . ($canonicalUrl ?? '/movie/' . ($routeSlug ?? ''));

    // ── SEO title and description templates (managed from the admin panel) ──
    $seoIsSeries = $isArc1 ? (bool)($arc1IsSeries ?? false) : (($movieData['type'] ?? '') === 'series');
    $seoTypeFa = $seoIsSeries ? 'سریال' : 'فیلم';
    $titleTemplate = (string)bm_site_get(
        $seoIsSeries ? 'seo_series_title_template' : 'seo_movie_title_template',
        $seoIsSeries ? 'دانلود سریال {title_fa} {title_en} {year} | BankMovie' : 'دانلود فیلم {title_fa} {title_en} {year} | BankMovie'
    );
    $summary = function_exists('bm_seo_cut') ? bm_seo_cut($seoDesc ?: $seoDescEn, 150) : mb_substr(strip_tags((string)($seoDesc ?: $seoDescEn)), 0, 150, 'UTF-8');
    $templateValues = [
        '{type}' => $seoTypeFa,
        '{title_fa}' => $seoTitleFa,
        '{title_en}' => $seoTitleEn,
        '{year}' => (string)$seoYear,
        '{summary}' => $summary,
    ];
    $metaTitle = trim(preg_replace('/\s+/u', ' ', strtr($titleTemplate, $templateValues)) ?: '');
    if ($metaTitle === '') $metaTitle = 'دانلود ' . $seoTypeFa . ' ' . trim($seoTitleFa . ' ' . $seoTitleEn . ' ' . $seoYear) . ' | BankMovie';
    $metaTitle = function_exists('bm_seo_cut') ? bm_seo_cut($metaTitle, 95) : mb_substr($metaTitle, 0, 95, 'UTF-8');

    $descriptionTemplate = (string)bm_site_get(
        'seo_movie_description_template',
        'دانلود {type} {title_fa} {title_en} {year} با دوبله و زیرنویس فارسی، اطلاعات کامل و لینک مستقیم از بانک مووی.'
    );
    $metaDesc = trim(preg_replace('/\s+/u', ' ', strtr($descriptionTemplate, $templateValues)) ?: '');
    if ($metaDesc === '') $metaDesc = 'دانلود ' . $seoTypeFa . ' ' . trim($seoTitleFa . ' ' . $seoTitleEn . ' ' . $seoYear) . ' با اطلاعات کامل از بانک مووی.';
    $metaDesc = function_exists('bm_seo_cut') ? bm_seo_cut($metaDesc, 170) : mb_substr(strip_tags($metaDesc), 0, 170, 'UTF-8');

    // ── Truthful Schema.org graph: no invented vote counts or unsupported facts ──
    $schemaType = $seoIsSeries ? 'TVSeries' : 'Movie';
    $mediaId = $canonicalFull . '#media';
    $webPageId = $canonicalFull . '#webpage';
    $mediaEntity = [
        '@type' => $schemaType,
        '@id' => $mediaId,
        'name' => $seoTitleEn ?: $seoTitleFa,
        'url' => $canonicalFull,
        'mainEntityOfPage' => ['@id' => $webPageId],
    ];
    $alternateNames = array_values(array_unique(array_filter([$seoTitleFa, $seoTitleEn])));
    if ($alternateNames) $mediaEntity['alternateName'] = $alternateNames;
    $schemaDescription = function_exists('bm_seo_cut') ? bm_seo_cut($seoDescEn ?: $seoDesc ?: $metaDesc, 500) : mb_substr(strip_tags((string)($seoDescEn ?: $seoDesc ?: $metaDesc)), 0, 500, 'UTF-8');
    if ($schemaDescription !== '') $mediaEntity['description'] = $schemaDescription;
    if ($seoYear !== '') $mediaEntity['datePublished'] = (string)$seoYear;
    if ($seoImage !== '') {
        $seoImage = function_exists('bm_seo_abs_url') ? bm_seo_abs_url((string)$seoImage) : (string)$seoImage;
        $mediaEntity['image'] = $seoImage;
    }
    if ($seoGenres !== '') $mediaEntity['genre'] = array_values(array_filter(array_map('trim', preg_split('/[,،|]/u', $seoGenres) ?: [])));

    $parsePeople = static function ($raw): array {
        if (is_array($raw)) $parts = $raw;
        else $parts = preg_split('/[,،|]/u', (string)$raw) ?: [];
        $people = [];
        foreach ($parts as $person) {
            if (is_array($person)) $person = $person['name'] ?? '';
            $name = trim(strip_tags((string)$person));
            if ($name !== '') $people[] = ['@type'=>'Person','name'=>$name];
        }
        return array_slice($people, 0, 30);
    };
    $directors = $parsePeople($movieData['director'] ?? ($arc1Data['director'] ?? ''));
    $actors = $parsePeople($movieData['actors'] ?? ($movieData['cast'] ?? ($arc1Data['actors'] ?? '')));
    if ($directors) $mediaEntity['director'] = count($directors) === 1 ? $directors[0] : $directors;
    if ($actors) $mediaEntity['actor'] = $actors;
    if ($seoImdb !== '' && preg_match('/^tt\d+$/i', $seoImdb)) $mediaEntity['sameAs'] = 'https://www.imdb.com/title/' . rawurlencode($seoImdb) . '/';

    $voteRaw = trim((string)($movieData['imdb_votes'] ?? ''));
    $ratingCount = 0;
    if ($voteRaw !== '') {
        $voteNorm = strtoupper(str_replace([',',' '], '', $voteRaw));
        if (preg_match('/^([0-9]+(?:\.[0-9]+)?)([KMB])?$/', $voteNorm, $vm)) {
            $ratingCount = (int)round((float)$vm[1] * (($vm[2] ?? '') === 'K' ? 1000 : (($vm[2] ?? '') === 'M' ? 1000000 : (($vm[2] ?? '') === 'B' ? 1000000000 : 1))));
        }
    }
    if ($seoRating > 0 && $seoRating <= 10 && $ratingCount > 0) {
        $mediaEntity['aggregateRating'] = [
            '@type'=>'AggregateRating','ratingValue'=>round($seoRating,1),'bestRating'=>10,'worstRating'=>1,'ratingCount'=>$ratingCount
        ];
    }

    $breadcrumb = function_exists('bm_seo_breadcrumb_schema')
        ? bm_seo_breadcrumb_schema((string)(parse_url($canonicalFull, PHP_URL_PATH) ?: '/'), $canonicalFull, $metaTitle)
        : ['@type'=>'BreadcrumbList','itemListElement'=>[
            ['@type'=>'ListItem','position'=>1,'name'=>'بانک مووی','item'=>rtrim(SITE_URL,'/').'/'],
            ['@type'=>'ListItem','position'=>2,'name'=>$seoTypeFa,'item'=>$canonicalFull],
        ]];
    $schemaData = [
        '@context'=>'https://schema.org',
        '@graph'=>[
            $mediaEntity,
            [
                '@type'=>'WebPage','@id'=>$webPageId,'url'=>$canonicalFull,'name'=>$metaTitle,'description'=>$metaDesc,
                'inLanguage'=>'fa-IR','mainEntity'=>['@id'=>$mediaId],'breadcrumb'=>['@id'=>$canonicalFull . '#breadcrumb'],
                'isPartOf'=>['@id'=>(function_exists('bm_seo_base_url') ? bm_seo_base_url() : rtrim(SITE_URL,'/')) . '/#website']
            ],
            $breadcrumb,
        ],
    ];
    ?>
    <title><?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?></title>

    <!-- ══ SEO Core ══ -->
    <meta name="description" content="<?= htmlspecialchars($metaDesc, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="robots"      content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <link rel="canonical"    href="<?= htmlspecialchars($canonicalFull, ENT_QUOTES, 'UTF-8') ?>">

    <!-- ══ Open Graph (Facebook / Telegram / WhatsApp) ══ -->
    <meta property="og:type"        content="<?= $seoIsSeries ? 'video.tv_show' : 'video.movie' ?>">
    <meta property="og:title"       content="<?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:description" content="<?= htmlspecialchars($metaDesc, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:url"         content="<?= htmlspecialchars($canonicalFull, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:site_name"   content="BankMovie">
    <meta property="og:locale"      content="<?= $userLang === 'fa' ? 'fa_IR' : 'en_US' ?>">
    <?php if ($seoImage !== ''): ?>
    <meta property="og:image"       content="<?= htmlspecialchars($seoImage, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:image:secure_url" content="<?= htmlspecialchars($seoImage, ENT_QUOTES, 'UTF-8') ?>">
    <meta property="og:image:width" content="600">
    <meta property="og:image:height" content="900">
    <meta property="og:image:alt"   content="<?= htmlspecialchars($seoTitleEn ?: $seoTitleFa, ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>

    <!-- ══ Twitter Card ══ -->
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?= htmlspecialchars($metaTitle, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:description" content="<?= htmlspecialchars($metaDesc, ENT_QUOTES, 'UTF-8') ?>">
    <?php if ($seoImage !== ''): ?>
    <meta name="twitter:image"       content="<?= htmlspecialchars($seoImage, ENT_QUOTES, 'UTF-8') ?>">
    <meta name="twitter:image:alt"   content="<?= htmlspecialchars($seoTitleFa ?: $seoTitleEn, ENT_QUOTES, 'UTF-8') ?>">
    <?php endif; ?>

    <!-- ══ JSON-LD Schema.org ══ -->
    <script type="application/ld+json"><?= json_encode($schemaData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) ?></script>
    <style>:root{--bm-accent:<?= e($currentTheme['primary']) ?>;--bm-accent-rgb:<?= e($currentThemeRgbCss) ?>;--bm-accent-dark:<?= e($currentTheme['primary']) ?>cc;--bm-cinematic-accent:<?= e($currentTheme['primary']) ?>;}</style>
<link rel="stylesheet" href="/assets/css/movie-inline-1.css?v=dl40">

<link rel="stylesheet" href="/assets/css/movie-inline-2.css?v=dl37">



<link rel="stylesheet" href="/assets/css/movie-inline-3.css?v=ui93">
<link rel="stylesheet" href="/assets/css/bm-player-mobile-settings-v14.css?v=20261021-v14a">

<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script src="/assets/js/movie-inline-1.js?v=mobile-smooth37"></script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=94">
<link rel="stylesheet" href="/assets/css/bm-player-modal-v3023.css?v=3023">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">
<link rel="stylesheet" href="/assets/css/movie-bulk-copy-v123.css?v=131">
<link rel="stylesheet" href="/assets/css/bm-interactions-v148.css?v=148">
<link rel="stylesheet" href="/assets/css/bm-watch-together-v14840.css?v=14840">
<link rel="stylesheet" href="/assets/css/bm-watch-together-v1486199.css?v=1486199">

<link rel="stylesheet" href="/assets/css/bm-uiverse-elements-v42.css?v=42.0">

<style id="bm-v172-release-summary-css">
.bm-release-status{display:flex;align-items:flex-start;gap:12px;margin:16px 0;padding:14px 16px;border:1px solid rgba(54,255,159,.18);border-radius:18px;background:linear-gradient(135deg,rgba(54,255,159,.075),rgba(56,189,248,.045));box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}
.bm-release-status-icon{width:38px;height:38px;flex:0 0 38px;display:grid;place-items:center;border-radius:12px;background:rgba(54,255,159,.1);color:#63ffc0}.bm-release-status-icon svg{width:19px;height:19px;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.bm-release-status small{display:block;margin-bottom:4px;color:rgba(255,255,255,.48);font-size:9px}.bm-release-status strong{display:block;color:#f5fff9;font-size:11px;line-height:1.9;font-weight:850}.bm-story-summary{position:relative;padding:18px 18px 15px!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:20px!important;background:linear-gradient(145deg,rgba(255,255,255,.035),rgba(0,0,0,.08))!important}.bm-story-summary-head{display:flex;align-items:center;gap:8px;margin-bottom:10px;color:rgba(255,255,255,.82);font-size:11px;font-weight:900}.bm-story-summary-head:before{content:"";width:18px;height:2px;border-radius:3px;background:#36ff9f;box-shadow:0 0 12px rgba(54,255,159,.5)}.bm-story-summary .bm-readmore-content{line-height:2.05!important;color:rgba(255,255,255,.72)!important;font-size:12px!important}
@media(max-width:600px){.bm-release-status{padding:12px}.bm-release-status strong{font-size:10px}.bm-story-summary{padding:15px!important}.bm-story-summary .bm-readmore-content{font-size:11px!important;line-height:2!important}}
</style>
<link rel="stylesheet" href="/assets/css/bm-movie-mobile-layout-v190.css?v=190.0">
<link rel="stylesheet" href="/assets/css/bm-comment-spoiler-v191.css?v=191.0">
<script src="/assets/js/bm-movie-mobile-layout-v190.js?v=190.0" defer></script>
    <link rel="stylesheet" href="/assets/css/bm-movie-mobile-info-v282.css?v=282.0">
    <link rel="stylesheet" href="/assets/css/bm-player-f2m-v268.css?v=292">
</head>
<body data-theme="<?= e($userTheme) ?>" lang="<?= e($langAttr) ?>" data-bm-series-page="<?= $bmSeriesCopyPage ? '1' : '0' ?>" data-bm-content-type="<?= e($isArc1 ? (($arc1IsSeries ?? false) ? 'series' : 'movie') : (($isMovie ?? true) ? 'movie' : 'series')) ?>" data-bm-archive="<?= e($bmCurrentArchiveId) ?>" data-bm-download-allowed="<?= $bmArchiveDownloadAllowed ? '1' : '0' ?>" data-bm-stream-allowed="<?= $bmArchiveStreamAllowed ? '1' : '0' ?>" data-bm-download-vip-locked="<?= $bmArchiveDownloadVipLocked ? '1' : '0' ?>" data-bm-stream-vip-locked="<?= $bmArchiveStreamVipLocked ? '1' : '0' ?>" data-bm-mobile-layout="<?= e($bmMovieMobileTemplate) ?>" data-bm-mobile-poster-size="<?= e($bmMovieMobilePosterSize) ?>" data-bm-mobile-density="<?= e($bmMovieMobileDensity) ?>" data-bm-mobile-show-en="<?= $bmMovieMobileShowEnglish ? '1' : '0' ?>" style="--bm-mobile-story-lines:<?= (int)$bmMovieMobileStoryLines ?>" class="no-hero movie-page bm-design2-safe <?= e($bmMovieTemplateClass) ?>">
<!-- Archive choice is not saved from movie pages; the home page always starts on Archive 1. -->

<style id="bm-archive-link-policy">
body[data-bm-download-allowed="0"][data-bm-download-vip-locked="0"] [data-bm-download-only="1"],body[data-bm-download-allowed="0"][data-bm-download-vip-locked="0"] .arc1-dl-btn,body[data-bm-download-allowed="0"][data-bm-download-vip-locked="0"] .download-icon,body[data-bm-download-allowed="0"][data-bm-download-vip-locked="0"] .arc1-sub-dl-btn,body[data-bm-download-allowed="0"] .bm-bulk-copy-open{display:none!important}
body[data-bm-stream-allowed="0"][data-bm-stream-vip-locked="0"] .arc1-play-btn,body[data-bm-stream-allowed="0"][data-bm-stream-vip-locked="0"] .bm-local-play-choice,body[data-bm-stream-allowed="0"][data-bm-stream-vip-locked="0"] .bm-trailer-cta{display:none!important}
.bm-archive-policy-notice{margin:12px 0 18px;padding:13px 15px;border:1px solid rgba(245,158,11,.3);border-radius:15px;background:rgba(245,158,11,.08);color:#fde68a;font-size:13px;line-height:1.9}
</style>


<div class="bm-share-sheet" id="bmShareSheet" aria-hidden="true">
    <div class="bm-share-panel" role="dialog" aria-modal="true" aria-labelledby="bmShareTitle">
        <div class="bm-share-head">
            <strong id="bmShareTitle">اشتراک‌گذاری</strong>
            <button type="button" class="bm-share-close" data-bm-share-close aria-label="بستن"><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"></button>
        </div>
        <div class="bm-share-grid">
            <a class="bm-share-item bm-share-telegram" data-share-platform="telegram" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M21.8 4.6 18.6 20c-.2 1-1 1.2-1.8.8l-5-3.7-2.4 2.3c-.3.3-.5.5-1 .5l.4-5.2 9.4-8.5c.4-.4-.1-.6-.6-.3L6 13.2 1 11.6c-1-.3-1-1 .2-1.5L20.4 2.7c.9-.3 1.7.2 1.4 1.9Z"/></svg></span>
                <span>تلگرام</span>
            </a>
            <a class="bm-share-item bm-share-whatsapp" data-share-platform="whatsapp" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M20.5 3.5A11.8 11.8 0 0 0 2.2 17.7L1 23l5.4-1.4A11.8 11.8 0 0 0 12 23 11.8 11.8 0 0 0 20.5 3.5ZM12 21a9.7 9.7 0 0 1-5-1.4l-.4-.2-3.2.8.9-3.1-.2-.4A9.8 9.8 0 1 1 12 21Zm5.4-7.3c-.3-.2-1.8-.9-2.1-1s-.5-.2-.7.2-.8 1-.9 1.1-.3.2-.6.1a8 8 0 0 1-2.3-1.4A8.8 8.8 0 0 1 9.2 11c-.2-.3 0-.5.1-.6l.5-.6c.2-.2.2-.3.3-.5s0-.4 0-.6-.7-1.7-1-2.3c-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.6.1-.9.4s-1.2 1.1-1.2 2.8 1.2 3.2 1.4 3.4 2.4 3.7 5.8 5.1c.8.3 1.4.5 1.9.7.8.2 1.5.2 2.1.1.6-.1 1.8-.7 2.1-1.5.3-.7.3-1.3.2-1.5-.1-.2-.3-.3-.6-.4Z"/></svg></span>
                <span>واتساپ</span>
            </a>
            <a class="bm-share-item bm-share-instagram" data-share-platform="instagram" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5Zm5 5.4A4.6 4.6 0 1 0 12 16.6 4.6 4.6 0 0 0 12 7.4Zm0 1.8A2.8 2.8 0 1 1 12 14.8 2.8 2.8 0 0 1 12 9.2ZM17.8 6a1.1 1.1 0 1 0 0 2.2 1.1 1.1 0 0 0 0-2.2Z"/></svg></span>
                <span>اینستاگرام</span>
            </a>
            <a class="bm-share-item bm-share-x" data-share-platform="twitter" target="_blank" rel="noopener">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24"><path d="M18.9 2h3.3l-7.2 8.2L23.5 22h-6.7l-5.2-6.8L5.6 22H2.3l7.7-8.8L1.8 2h6.9l4.7 6.2L18.9 2Zm-1.2 17.9h1.8L7.7 4H5.8l11.9 15.9Z"/></svg></span>
                <span>توییتر / X</span>
            </a>
            <a class="bm-share-item bm-share-sms" data-share-platform="sms">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4v8Z" stroke="currentColor" stroke-width="2"/></svg></span>
                <span>پیام‌رسان</span>
            </a>
            <button type="button" class="bm-share-item bm-share-copy" data-share-platform="copy">
                <span class="bm-share-icon"><svg viewBox="0 0 24 24" fill="none"><rect x="9" y="9" width="13" height="13" rx="2" stroke="currentColor" stroke-width="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" stroke="currentColor" stroke-width="2"/></svg></span>
                <span>کپی لینک</span>
            </button>
        </div>
        <div class="bm-share-url">
            <input type="text" id="bmShareUrl" readonly value="">
            <button type="button" data-share-platform="copy">کپی</button>
        </div>
    </div>
</div>

<?php if($activeNotification && !$notificationSeen): ?>
<div class="notification-modal" id="notificationModal" style="position:fixed;inset:0;background:rgba(0,0,0,0.95);backdrop-filter:blur(20px);z-index:20000;display:flex;align-items:center;justify-content:center">
    <div style="background:#0f0f13;border:1px solid var(--border-accent);border-radius:32px;padding:40px;max-width:500px;width:90%;text-align:center">
        <div style="width:80px;height:80px;background:var(--accent-glow);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px">
            <svg width="45" height="45" viewBox="0 0 24 24" fill="none" stroke="var(--accent)"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        </div>
        <div style="font-size:24px;font-weight:800;color:var(--accent);margin-bottom:16px"><?= $userLang=='fa'?'اعلامیه مهم':'Important Announcement' ?></div>
        <div style="color:var(--text-secondary);line-height:1.6;margin-bottom:24px"><?= nl2br(e($activeNotification['message'])) ?></div>
        <button class="notification-btn" id="closeNotificationBtn" type="button" data-notification-id="<?= e((string)($activeNotification['id'] ?? '')) ?>" style="background:var(--accent);color:#000;border:none;padding:12px 32px;border-radius:40px;font-weight:700;cursor:pointer"><?= $userLang=='fa'?'متوجه شدم':'Got it' ?></button>
    </div>
</div>
<?php endif; ?>
<?php if($activeNotification && !$notificationSeen): ?>
<script>window.BM_NOTIFICATION_ID = <?= json_encode((string)($activeNotification['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="/assets/js/bm-notification.js?v=dl36"></script>
<?php endif; ?>

<div class="loading-overlay bm-video-loading-overlay" id="loadingOverlay"><div class="bm-video-spinner" role="status" aria-label="Loading video"></div></div>
<script src="/assets/js/movie-inline-2.js?v=dl36"></script>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn" aria-label="بستن"><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"></button></div>
    <?php if($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username']) ?></div><div class="sidebar-userrole"><?= $currentUser['role']==='admin'?($userLang=='fa'?'مدیر':'Admin'):($userLang=='fa'?'کاربر':'User') ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.5" d="M2 12.2039C2 9.91549 2 8.77128 2.5192 7.82274C3.0384 6.87421 3.98695 6.28551 5.88403 5.10813L7.88403 3.86687C9.88939 2.62229 10.8921 2 12 2C13.1079 2 14.1106 2.62229 16.116 3.86687L18.116 5.10812C20.0131 6.28551 20.9616 6.87421 21.4808 7.82274C22 8.77128 22 9.91549 22 12.2039V13.725C22 17.6258 22 19.5763 20.8284 20.7881C19.6569 22 17.7712 22 14 22H10C6.22876 22 4.34315 22 3.17157 20.7881C2 19.5763 2 17.6258 2 13.725V12.2039Z" fill="currentColor"/><path d="M9 17.25C8.58579 17.25 8.25 17.5858 8.25 18C8.25 18.4142 8.58579 18.75 9 18.75H15C15.4142 18.75 15.75 18.4142 15.75 18C15.75 17.5858 15.4142 17.25 15 17.25H9Z" fill="currentColor"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.4" d="M12.1207 12.78C12.0507 12.77 11.9607 12.77 11.8807 12.78C10.1207 12.72 8.7207 11.28 8.7207 9.50998C8.7207 7.69998 10.1807 6.22998 12.0007 6.22998C13.8107 6.22998 15.2807 7.69998 15.2807 9.50998C15.2707 11.28 13.8807 12.72 12.1207 12.78Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path opacity="0.34" d="M18.7398 19.3801C16.9598 21.0101 14.5998 22.0001 11.9998 22.0001C9.39977 22.0001 7.03977 21.0101 5.25977 19.3801C5.35977 18.4401 5.95977 17.5201 7.02977 16.8001C9.76977 14.9801 14.2498 14.9801 16.9698 16.8001C18.0398 17.5201 18.6398 18.4401 18.7398 19.3801Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if($currentUser['role']==='admin'): ?>
        <a href="/_lider/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; ?><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang=='fa'?'آیا از خروج مطمئن هستید؟':'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header"><h3><?= $t[$userLang]['notifications'] ?></h3><button class="notif-close" id="closeNotifSidebar" aria-label="بستن"><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"></button></div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'])) ?></div><div class="notif-date"><?= date('Y/m/d H:i', strtotime($notif['created_at'])) ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=237001" defer></script>

<div class="container">

<?php if($isArc1): ?>
<!-- ====== آرشیو خارجی ====== -->
<?php if($arc1Error && !$arc1Data): ?>
<div style="text-align:center;padding:60px 20px;color:rgba(255,255,255,.4)">
    <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="margin:0 auto 16px;opacity:.4"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <h2 style="margin-bottom:10px;color:#fff">خطا در بارگذاری</h2>
    <p style="margin-bottom:20px"><?= e($arc1Error) ?></p>
    <a href="javascript:history.back()" style="color:rgba(255,255,255,.5);font-size:13px">← برگشت</a>
</div>
<?php else: ?>
<link rel="stylesheet" href="/assets/css/movie-inline-4.css?v=dl36">
<link rel="stylesheet" href="/assets/css/bm-smooth-accordions-v158.css?v=158.0">
<link rel="stylesheet" href="/assets/css/movie-cinematic-v125-mobiletabs-off.css?v=125-mobiletabs-off-1">
<link rel="stylesheet" href="/assets/css/bm-mobile-latest-episode-premium-v30.css?v=30.0">
<link rel="stylesheet" href="/assets/css/bm-mobile-movie-polish-v35.css?v=35.0">
<link rel="stylesheet" href="/assets/css/bm-movie-detail-hotfix-v272.css?v=272.0">

<!-- پلیر آرشیو خارجی (مشابه آرشیو ۲) -->
<?php
$arc1FirstVideoUrl = '';
$arc1FirstSubtitleUrl = '';
$arc1FirstVideoDownloadLocked = false;
if(!$arc1IsSeries) {
    // برای آرشیو ۱ اگر فیلم دوبله و نسخه زیرنویس‌دار همزمان داشت، پلیر پیش‌فرض را روی نسخه زیرنویس‌دار بگذار.
    // قبلاً بعد از بعضی آپدیت‌ها نسخه دوبله زودتر انتخاب می‌شد و کاربر فکر می‌کرد زیرنویس حذف شده است.
    foreach([$arc1MovieSoft, $arc1MovieDub] as $arc1Group) {
        foreach($arc1Group as $arc1Items) {
            foreach($arc1Items as $arc1Candidate) {
                if(empty($arc1Candidate['is_audio']) && !empty($arc1Candidate['url'])) {
                    $arc1FirstVideoUrl = $arc1Candidate['url'];
                    $arc1FirstSubtitleUrl = trim((string)($arc1Candidate['subtitle_url'] ?? ''));
                    $arc1FirstVideoDownloadLocked = !empty($arc1Candidate['source_download_locked']);
                    break 3;
                }
            }
        }
    }
}

/*
 * Safe latest-episode selector for archive 1/3 series.
 * This only reads the already-built $arc1SeriesSeasons array and feeds the existing arc1 player click handler.
 * No player/source/loading logic is changed.
 */
$arc1LatestPlay = [
    'url' => '',
    'season' => '',
    'episode' => '',
    'label' => '',
    'next_url' => '',
    'next_label' => '',
    'subtitle_url' => '',
    'source_download_locked' => false
];
if($arc1IsSeries && !empty($arc1SeriesSeasons) && is_array($arc1SeriesSeasons)) {
    $seasonKeys = array_keys($arc1SeriesSeasons);
    natsort($seasonKeys);
    $lastSeasonKey = end($seasonKeys);
    $latestEpisodes = is_string($lastSeasonKey) && isset($arc1SeriesSeasons[$lastSeasonKey]) ? $arc1SeriesSeasons[$lastSeasonKey] : [];
    if(!empty($latestEpisodes) && is_array($latestEpisodes)) {
        $epKeys = array_keys($latestEpisodes);
        natsort($epKeys);
        $realEpKeys = [];
        foreach($epKeys as $ekCandidate) {
            if(preg_match('/^E\d+/i', (string)$ekCandidate)) $realEpKeys[] = $ekCandidate;
        }
        if(!empty($realEpKeys)) {
            natsort($realEpKeys);
            $lastEpKey = end($realEpKeys);
        } else {
            $lastEpKey = end($epKeys);
        }
        $latestLinks = isset($latestEpisodes[$lastEpKey]) ? $latestEpisodes[$lastEpKey] : [];
        if(!empty($latestLinks) && is_array($latestLinks)) {
            $latestLink = $latestLinks[0];
            $latestSeasonNum = ltrim(preg_replace('/[^0-9]/', '', (string)$lastSeasonKey), '0');
            if($latestSeasonNum === '') $latestSeasonNum = '1';
            $latestEpisodeNum = ((string)$lastEpKey === 'full') ? '' : ltrim(preg_replace('/[^0-9]/', '', (string)$lastEpKey), '0');
            $latestLabel = ((string)$lastEpKey === 'full' || $latestEpisodeNum === '') ? 'فصل کامل' : ('قسمت ' . $latestEpisodeNum);
            $arc1LatestPlay = [
                'url' => trim((string)($latestLink['url'] ?? '')),
                'season' => $latestSeasonNum,
                'episode' => $latestEpisodeNum,
                'label' => $latestLabel,
                'next_url' => '',
                'next_label' => '',
                'subtitle_url' => trim((string)($latestLink['subtitle_url'] ?? '')),
                'source_download_locked' => !empty($latestLink['source_download_locked'])
            ];
        }
    }
}
?>

<div class="movie-detail <?= !empty($arc1HeroPosterFallback) ? 'bm-hero-poster-fallback' : 'bm-hero-has-backdrop' ?>" style="--bg-image:url('<?= e($arc1HeroBg ?? $arc1Poster ?? '') ?>');--bm-poster-image:url('<?= e($arc1Poster ?? '') ?>');">
    <div class="poster-col">
        <?php if($arc1Poster): ?>
        <img src="<?= e($arc1Poster) ?>" alt="<?= e($arc1Title) ?>" onerror="this.onerror=null;this.src='/assets/img/no-poster.svg'" style="border-radius:18px;width:100%;object-fit:cover">
        <?php else: ?>
        <div style="width:100%;aspect-ratio:2/3;background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:18px;display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
        <?php endif; ?>
        <?php if($arc1HasDub || $arc1HasSub): ?>
        <div class="bm-poster-badges" aria-label="ویژگی‌های نسخه">
            <?php if($arc1HasDub): ?>
            <span class="bm-poster-badge bm-badge-dub" title="دوبله فارسی">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a4 4 0 0 0-4 4v6a4 4 0 0 0 8 0V6a4 4 0 0 0-4-4z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3M8 22h8"/></svg>
                <span>دوبله</span>
            </span>
            <?php endif; ?>
            <?php if($isArc3 && $arc1HasSub): ?>
            <span class="bm-poster-badge bm-badge-cc" title="زیرنویس فارسی">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                <span>زیرنویس فارسی</span>
            </span>
            <?php else: ?>
                <?php if($arc1HasHardSub): ?>
                <span class="bm-poster-badge bm-badge-cc" title="هاردساب فارسی">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                    <span>هاردساب</span>
                </span>
                <?php endif; ?>
                <?php if($arc1HasSoftSub): ?>
                <span class="bm-poster-badge bm-badge-cc" title="سافت‌ساب فارسی">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                    <span>سافت‌ساب</span>
                </span>
                <?php endif; ?>
                <?php if($arc1HasSub && !$arc1HasHardSub && !$arc1HasSoftSub): ?>
                <span class="bm-poster-badge bm-badge-cc" title="<?= e($bmArchiveSubFa) ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                    <span><?= e($bmArchiveSubFa) ?></span>
                </span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if(!$arc1IsSeries && $arc1FirstVideoUrl): ?>
        <button type="button" class="bm-poster-play arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?> data-url="<?= e(bm_archive_stream_url($arc1FirstVideoUrl)) ?>" <?php if($bmArchiveDownloadAllowed && !$arc1FirstVideoDownloadLocked): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc1FirstVideoUrl)) ?>"<?php endif; ?> data-subtitle-url="<?= e(bm_archive_stream_url($arc1FirstSubtitleUrl)) ?>" aria-label="پخش آنلاین">
            <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
        </button>
        <?php elseif($arc1IsSeries && !empty($arc1LatestPlay['url'])): ?>
        <button type="button" class="bm-poster-play arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
            data-url="<?= e(bm_archive_stream_url($arc1LatestPlay['url'])) ?>" <?php if($bmArchiveDownloadAllowed && empty($arc1LatestPlay['source_download_locked'])): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc1LatestPlay['url'])) ?>"<?php endif; ?>
            data-season="<?= e($arc1LatestPlay['season']) ?>"
            data-episode="<?= e($arc1LatestPlay['episode']) ?>"
            data-label="<?= e($arc1LatestPlay['label']) ?>"
            data-next-url=""
            data-next-label=""
            data-subtitle-url="<?= e(bm_archive_stream_url($arc1LatestPlay['subtitle_url'] ?? '')) ?>">
            <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
        </button>
        <?php endif; ?>
    </div>

    <div class="info-col">
        <h1 class="movie-title-fa"><bdi dir="auto"><?= e($arc1Title) ?></bdi></h1>
        <?php if(!empty($arc1TitleEn)): ?><div class="movie-title-en"><bdi dir="ltr"><?= e($arc1TitleEn) ?></bdi></div><?php endif; ?>
        <div class="movie-rating-section">
            <?php if($arc1ImdbRate): ?>
            <div class="bm-imdb-pill">
                <span class="bm-imdb-score"><?= number_format((float)$arc1ImdbRate,1) ?></span>
                <img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy">
            </div>
            <?php endif; ?>
            <?php if($arc1Satisfaction): ?><div class="bm-satisfaction-chip" style="display:inline-flex;align-items:center;gap:6px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2);border-radius:40px;padding:5px 12px;font-size:13px;color:#4ade80;font-weight:700"><svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M14 9V5a3 3 0 0 0-3-3L7 11v11h10.28a2 2 0 0 0 1.97-1.64l1.38-7.6A3 3 0 0 0 17.68 9H14ZM5 11H3a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h2V11Z"/></svg><span><?= e($arc1Satisfaction) ?></span></div><?php endif; ?>
        </div>

        <div class="movie-info-block" id="bmMovieMoreInfo">
            <div class="movie-info-title"><?= $userLang==='fa'?'مشخصات':'Details' ?></div>
            <div class="movie-meta-grid">
                <?php if($arc1Year): ?><div class="meta-item" data-meta="year"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span class="label">سال:</span><span class="value"><?= e($arc1Year) ?></span></div><?php endif; ?>
                <?php if($arc1ImdbRate): ?><div class="meta-item bm-meta-imdb" data-meta="imdb"><span class="bm-imdb-pill bm-imdb-pill--sm"><span class="bm-imdb-score"><?= number_format((float)$arc1ImdbRate,1) ?></span><img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy"></span></div><?php endif; ?>
                <div class="meta-item" data-meta="type"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><span class="label">نوع:</span><span class="value"><?= $arc1IsSeries ? 'سریال' : 'فیلم' ?></span></div>
                <?php if(!empty($arc1AgeRate)): ?>
                <div class="meta-item" data-meta="rated"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M9 2C6.38 2 4.25 4.13 4.25 6.75c0 2.57 2.01 4.65 4.63 4.74.08-.01.16-.01.22 0h.07a4.738 4.738 0 0 0 4.58-4.74C13.75 4.13 11.62 2 9 2Z"/><path d="M14.08 14.149c-2.79-1.86-7.34-1.86-10.15 0-1.27.85-1.97 2-1.97 3.23s.7 2.37 1.96 3.21c1.4.94 3.24 1.41 5.08 1.41 1.84 0 3.68-.47 5.08-1.41 1.26-.85 1.96-1.99 1.96-3.23-.01-1.23-.7-2.37-1.96-3.21Z"/><path opacity=".4" d="M19.99 7.338c.16 1.94-1.22 3.64-3.13 3.87h-.05c-.06 0-.12 0-.17.02-.97.05-1.86-.26-2.53-.83 1.03-.92 1.62-2.3 1.5-3.8a4.64 4.64 0 0 0-.77-2.18 3.592 3.592 0 0 1 5.15 2.92Z"/><path d="M21.988 16.59c-.08.97-.7 1.81-1.74 2.38-1 .55-2.26.81-3.51.78.72-.65 1.14-1.46 1.22-2.32.1-1.24-.49-2.43-1.67-3.38-.67-.53-1.45-.95-2.3-1.26 2.21-.64 4.99-.21 6.7 1.17.92.74 1.39 1.67 1.3 2.63Z"/></svg><span class="label">رده سنی:</span><span class="value"><?= e($arc1AgeRate) ?></span></div>
                <?php endif; ?>
                <?php if(($isArc7) && !empty($arc1Data['director'])): ?>
                <div class="meta-item" data-meta="director"><span class="label">کارگردان:</span><span class="value"><?= e((string)$arc1Data['director']) ?></span></div>
                <?php endif; ?>
                <?php if(($isArc7) && !empty($arc1Data['metacritic'])): ?>
                <div class="meta-item" data-meta="metacritic"><span class="label">Metacritic:</span><span class="value"><?= e((string)$arc1Data['metacritic']) ?></span></div>
                <?php endif; ?>
                <?php if($isArc7 && !empty($arc1Data['personality_types']) && is_array($arc1Data['personality_types'])): ?>
                <div class="meta-item" data-meta="personality"><span class="label">تیپ شخصیتی:</span><span class="value"><?= e(implode('، ', $arc1Data['personality_types'])) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Runtime)): ?>
                <div class="meta-item" data-meta="runtime"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12s4.477 10 10 10Z"/><path d="M15.71 15.932a.67.67 0 0 1-.38-.11l-3.1-1.85c-.77-.46-1.34-1.47-1.34-2.36v-4.1c0-.41.34-.75.75-.75s.75.34.75.75v4.1c0 .36.3.89.61 1.07l3.1 1.85c.36.21.47.67.26 1.03a.77.77 0 0 1-.65.37Z"/></svg><span class="label">زمان:</span><span class="value"><?= e($arc1Runtime) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1ReleaseDate)): ?>
                <div class="meta-item" data-meta="release"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M16.75 3.56V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.5h-6.5V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.56c-2.7.25-4.01 1.86-4.21 4.25-.02.29.22.53.5.53h16.92c.29 0 .53-.25.5-.53-.2-2.39-1.51-4-4.21-4.25Z"/><path opacity=".4" d="M20 9.84c.55 0 1 .45 1 1V17c0 3-1.5 5-5 5H8c-3.5 0-5-2-5-5v-6.16c0-.55.45-1 1-1h16Z"/><path d="M8.5 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.09-.1-.16-.21-.21-.33a.995.995 0 0 1-.08-.38c0-.13.03-.26.08-.38s.12-.23.21-.33c.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.09.1.16.21.21.33.05.12.08.25.08.38s-.03.26-.08.38-.12.23-.21.33c-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM12 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21.24-.11.52-.11.76 0 .12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM8.5 18.499c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08Z"/></svg><span class="label">اکران:</span><span class="value"><?= e($arc1ReleaseDate) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1PublishDate)): ?>
                <div class="meta-item" data-meta="published"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M16.75 3.56V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.5h-6.5V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.56c-2.7.25-4.01 1.86-4.21 4.25-.02.29.22.53.5.53h16.92c.29 0 .53-.25.5-.53-.2-2.39-1.51-4-4.21-4.25Z"/><path opacity=".4" d="M20 9.84c.55 0 1 .45 1 1V17c0 3-1.5 5-5 5H8c-3.5 0-5-2-5-5v-6.16c0-.55.45-1 1-1h16Z"/><path d="M8.5 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.09-.1-.16-.21-.21-.33a.995.995 0 0 1-.08-.38c0-.13.03-.26.08-.38s.12-.23.21-.33c.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.09.1.16.21.21.33.05.12.08.25.08.38s-.03.26-.08.38-.12.23-.21.33c-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM12 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21.24-.11.52-.11.76 0 .12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM8.5 18.499c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08Z"/></svg><span class="label">انتشار:</span><span class="value"><?= e($arc1PublishDate) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1StatusText)): ?>
                <div class="meta-item" data-meta="status"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M16.75 3.56V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.5h-6.5V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.56c-2.7.25-4.01 1.86-4.21 4.25-.02.29.22.53.5.53h16.92c.29 0 .53-.25.5-.53-.2-2.39-1.51-4-4.21-4.25Z"/><path opacity=".4" d="M20 9.84c.55 0 1 .45 1 1V17c0 3-1.5 5-5 5H8c-3.5 0-5-2-5-5v-6.16c0-.55.45-1 1-1h16Z"/><path d="M8.5 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.09-.1-.16-.21-.21-.33a.995.995 0 0 1-.08-.38c0-.13.03-.26.08-.38s.12-.23.21-.33c.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.09.1.16.21.21.33.05.12.08.25.08.38s-.03.26-.08.38-.12.23-.21.33c-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM12 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21.24-.11.52-.11.76 0 .12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM8.5 18.499c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08Z"/></svg><span class="label">وضعیت:</span><span class="value"><?= e($arc1StatusText) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1LanguageText)): ?>
                <div class="meta-item" data-meta="language"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M5.15 22c-.41 0-.75-.34-.75-.75V2.75c0-.41.34-.75.75-.75s.75.34.75.75v18.5c0 .41-.34.75-.75.75Z"/><path opacity=".4" d="m18.02 12.33-1.22-1.22a1.39 1.39 0 0 1-.47-1.03c-.02-.45.16-.9.49-1.23l1.2-1.2c1.04-1.04 1.43-2.04 1.1-2.83-.32-.78-1.31-1.21-2.77-1.21H5.15c-.21.01-.38.18-.38.39v12c0 .21.17.38.38.38h11.2c1.44 0 2.41-.44 2.74-1.23.33-.8-.05-1.79-1.07-2.82Z"/></svg><span class="label">زبان:</span><span class="value"><?= e($arc1LanguageText) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Network)): ?>
                <div class="meta-item" data-meta="network"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M7.649 20.91c-.03 0-.07.02-.1.02-1.94-.96-3.52-2.55-4.49-4.49 0-.03.02-.07.02-.1 1.22.36 2.48.63 3.73.84.22 1.26.48 2.51.84 3.73ZM20.94 16.45c-.99 1.99-2.64 3.6-4.65 4.57.38-1.27.7-2.55.91-3.84 1.26-.21 2.5-.48 3.72-.84-.01.04.02.08.02.11ZM21.02 7.71c-1.26-.38-2.53-.69-3.82-.91-.21-1.29-.52-2.57-.91-3.82 2.07.99 3.74 2.66 4.73 4.73ZM7.65 3.089c-.36 1.22-.62 2.46-.83 3.72-1.29.2-2.57.52-3.84.9.97-2.01 2.58-3.66 4.57-4.65.03 0 .07.03.1.03Z"></path><path d="M15.492 6.59c-2.32-.26-4.66-.26-6.98 0 .25-1.37.57-2.74 1.02-4.06.02-.08.01-.14.02-.22.79-.19 1.6-.31 2.45-.31.84 0 1.66.12 2.44.31.01.08.01.14.03.22.45 1.33.77 2.69 1.02 4.06ZM6.59 15.492c-1.38-.25-2.74-.57-4.06-1.02-.08-.02-.14-.01-.22-.02-.19-.79-.31-1.6-.31-2.45 0-.84.12-1.66.31-2.44.08-.01.14-.01.22-.03 1.33-.44 2.68-.77 4.06-1.02-.25 2.32-.25 4.66 0 6.98ZM22 12.002c0 .85-.12 1.66-.31 2.45-.08.01-.14 0-.22.02-1.33.44-2.69.77-4.06 1.02.26-2.32.26-4.66 0-6.98 1.37.25 2.74.57 4.06 1.02.08.02.14.03.22.03.19.79.31 1.6.31 2.44ZM15.492 17.41c-.25 1.38-.57 2.74-1.02 4.06-.02.08-.02.14-.03.22-.78.19-1.6.31-2.44.31-.85 0-1.66-.12-2.45-.31-.01-.08 0-.14-.02-.22a29.77 29.77 0 0 1-1.02-4.06c1.16.13 2.32.22 3.49.22 1.17 0 2.34-.09 3.49-.22ZM15.763 15.763a30.035 30.035 0 0 1-7.526 0 30.039 30.039 0 0 1 0-7.526 30.039 30.039 0 0 1 7.526 0 30.035 30.035 0 0 1 0 7.526Z" /></svg><span class="label">شبکه:</span><span class="value"><?= e($arc1Network) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1NextEpisode)): ?>
                <div class="meta-item" data-meta="next"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M3.762 7.22v9.57c0 1.96 2.13 3.19 3.83 2.21l4.15-2.39 4.15-2.4c1.7-.98 1.7-3.43 0-4.41l-4.15-2.4-4.15-2.39c-1.7-.98-3.83.24-3.83 2.21Z"></path><path d="M20.238 18.93c-.41 0-.75-.34-.75-.75V5.82c0-.41.34-.75.75-.75s.75.34.75.75v12.36c0 .41-.33.75-.75.75Z" /></svg><span class="label">قسمت بعدی:</span><span class="value"><?= e($arc1NextEpisode) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1EpisodeNote)): ?>
                <div class="meta-item" data-meta="update"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 6h16M4 12h12M4 18h9"/></svg><span class="label">آخرین وضعیت:</span><span class="value"><?= e($arc1EpisodeNote) ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Genres)): ?>
                <div class="meta-item" data-meta="genres"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><span class="label">ژانر:</span><span class="value genre-links"><?php foreach((array)$arc1Genres as $g): ?><a href="/?arc=1&genre=<?= urlencode($g) ?>" class="genre-link"><?= e($g) ?></a> <?php endforeach; ?></span></div>
                <?php endif; ?>
                <?php if(!empty($arc1Countries)): ?>
                <div class="meta-item" data-meta="country"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M8.56 3.34v14.33c-.34.01-.68.09-.93.24l-2.35 1.34c-1.64.94-2.99.16-2.99-1.74V7.78c0-.63.45-1.41 1.01-1.73l4.33-2.48c.25-.14.59-.22.93-.23Z"/><path d="M15.729 6.33v14.33c-.35.01-.69-.05-.96-.18l-5.25-2.63c-.27-.13-.61-.19-.96-.18V3.34c.35-.01.69.05.96.18l5.25 2.63c.27.13.61.19.96.18Z"/><path opacity=".4" d="M22 6.49v9.73c0 .63-.45 1.41-1.01 1.73l-4.33 2.48c-.25.14-.59.22-.93.23V6.33c.34-.01.68-.09.93-.24l2.35-1.34C20.65 3.81 22 4.59 22 6.49Z"/></svg><span class="label">کشور:</span><span class="value"><?= e(is_array($arc1Countries)?implode('، ',$arc1Countries):$arc1Countries) ?></span></div>
                <?php endif; ?>
            </div>
        </div>

        <?php if($arc1Desc): ?>
        <div class="description bm-readmore-desc" data-collapsed="1">
            <div class="bm-readmore-content"><?= nl2br(e($arc1Desc)) ?></div>
            <button type="button" class="bm-readmore-btn" data-readmore-toggle>ادامه داستان</button>
        </div>
        <?php endif; ?>

        <?php if(!empty($arc1Actors)): ?>
        <section class="bm-arc1-actors-section">
            <div class="bm-arc1-section-head">
                <div class="bm-arc1-section-title">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                    <span>بازیگران</span>
                </div>
                <span class="bm-arc1-section-count"><?= count($arc1Actors) ?> نفر</span>
            </div>
                        <div class="bm-arc1-actors-list" data-actors-list>
                <?php foreach($arc1Actors as $actorIndex => $actor): 
                    $actorName = $actor['name'] ?? '';
                    $actorRole = $actor['role'] ?? '';
                    $actorImg  = trim((string)($actor['image'] ?? ''));
                    $actorHasImage = ($actorImg !== '' && (!function_exists('bm_actor_is_bad_placeholder_image') || !bm_actor_is_bad_placeholder_image($actorImg)));
                    $actorUrl  = trim((string)($actor['bankmovie_url'] ?? ''));
                    if ($actorUrl === '') $actorUrl = 'javascript:void(0)';
                    if ($actorUrl !== 'javascript:void(0)' && $actorName !== '') {
                        $actorUrl .= (str_contains($actorUrl, '?') ? '&' : '?') . 'name=' . rawurlencode((string)$actorName);
                    }
                ?>
                <a class="bm-arc1-actor-card <?= $actorHasImage ? 'has-photo' : 'is-text-only' ?> <?= $actorIndex >= 6 ? 'bm-actor-hidden' : '' ?>" href="<?= e($actorUrl) ?>">
                    <?php if($actorHasImage): ?>
                    <span class="bm-arc1-actor-photo-wrap">
                        <img src="<?= e($actorImg) ?>" alt="<?= e($actorName) ?>" class="bm-arc1-actor-photo" loading="lazy" onerror="var c=this.closest('.bm-arc1-actor-card');if(c){c.classList.add('is-text-only');c.classList.remove('has-photo');}">
                    </span>
                    <?php endif; ?>
                    <span class="bm-arc1-actor-text-icon" aria-hidden="true">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="3.5"/><path d="M5.5 20c.5-4.05 2.7-6.1 6.5-6.1s6 2.05 6.5 6.1" stroke-linecap="round"/></svg>
                    </span>
                    <span class="bm-arc1-actor-name"><?= e($actorName) ?></span>
                    <?php if($actorRole): ?><span class="bm-arc1-actor-role"><?= e($actorRole) ?></span><?php endif; ?>
                    <span class="bm-actor-detail-pill"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3"/><path d="M6 20c.4-3.5 2.4-5.2 6-5.2s5.6 1.7 6 5.2" stroke-linecap="round"/></svg>مشاهده جزئیات</span>
                </a>
                <?php endforeach; ?>
            </div>
            <?php if(count($arc1Actors) > 6): ?>
            <button type="button" class="bm-actors-show-all" data-actors-toggle>مشاهده همه بازیگران</button>
            <?php endif; ?>
        </section>
        <?php endif; ?>

        <!-- دکمه‌های اکشن -->
        <div class="action-buttons <?= $arc1IsSeries ? 'bm-actions-series' : 'bm-actions-movie' ?> <?= ($arc1IsSeries && (!empty($arc1LatestPlay['url']) || !empty($arc1SeriesSeasons))) ? 'has-primary-latest' : '' ?> <?= !empty($arc1TrailerUrl) ? 'has-primary-trailer' : '' ?>" style="display:flex;flex-wrap:wrap;gap:10px;margin-top:16px">
            <?php if($arc1IsSeries && !empty($arc1LatestPlay['url'])): ?>
            <a href="#arc1PlayerWrapper" class="btn btn-primary hero-primary-action bm-safe-series-cta arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                data-url="<?= e(bm_archive_stream_url($arc1LatestPlay['url'])) ?>" <?php if($bmArchiveDownloadAllowed && empty($arc1LatestPlay['source_download_locked'])): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc1LatestPlay['url'])) ?>"<?php endif; ?>
                data-season="<?= e($arc1LatestPlay['season']) ?>"
                data-episode="<?= e($arc1LatestPlay['episode']) ?>"
                data-label="<?= e($arc1LatestPlay['label']) ?>"
                data-next-url=""
                data-next-label=""
                data-subtitle-url="<?= e(bm_archive_stream_url($arc1LatestPlay['subtitle_url'] ?? '')) ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                پخش آخرین قسمت
            </a>
            <?php elseif($arc1IsSeries && !empty($arc1SeriesSeasons)): ?>
            <a href="#arc1DownloadSection" class="btn btn-primary hero-primary-action bm-safe-series-cta">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                پخش آخرین قسمت
            </a>
            <?php endif; ?>
            <?php if(!empty($arc1TrailerUrl)): ?>
            <a href="#arc1PlayerWrapper" class="btn btn-outline bm-trailer-cta arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                data-url="<?= e(bm_archive_stream_url($arc1TrailerUrl)) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc1TrailerUrl)) ?>"<?php endif; ?>
                data-label="تریلر"
                data-direct-player="1"
                data-next-url=""
                data-next-label="">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M20.6 3H3.4A2.4 2.4 0 0 0 1 5.4v13.2A2.4 2.4 0 0 0 3.4 21h17.2a2.4 2.4 0 0 0 2.4-2.4V5.4A2.4 2.4 0 0 0 20.6 3Z" fill="currentColor" fill-opacity=".16" stroke="currentColor" stroke-width="1.5"/><path d="M20.6 3H3.4A2.4 2.4 0 0 0 1 5.4V9h22V5.4A2.4 2.4 0 0 0 20.6 3Z" fill="white" stroke="currentColor" stroke-width="1.5"/><path d="m15 9 2-6M7 9l2-6M1 9h22" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
                تماشای تریلر
            </a>
            <?php endif; ?>
                        <button class="arc1-wl-btn bm-watchlist-action <?= $inArc1Watch?'active':'' ?>" id="arc1WlBtn"
                data-link="<?= e($arc1SourceUrl) ?>" data-title="<?= e($arc1Title) ?>"
                data-year="<?= e($arc1Year) ?>" data-poster="<?= e($arc1Poster??'') ?>"
                data-rate="<?= e($arc1ImdbRate??0) ?>" data-type="<?= $arc1IsSeries?'series':'movie' ?>"
                data-id="<?= e($arc1WatchId??0) ?>" aria-pressed="<?= $inArc1Watch ? 'true' : 'false' ?>">
                <svg class="bm-bookmark-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><?php if($inArc1Watch): ?><path opacity="0.4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M12.0007 10.2801C10.9807 10.2801 9.96074 10.1001 8.99074 9.75005C8.60074 9.61005 8.40074 9.18005 8.54074 8.79005C8.69074 8.40005 9.12074 8.20005 9.51074 8.34005C11.1207 8.92005 12.8907 8.92005 14.5007 8.34005C14.8907 8.20005 15.3207 8.40005 15.4607 8.79005C15.6007 9.18005 15.4007 9.61005 15.0107 9.75005C14.0407 10.1001 13.0207 10.2801 12.0007 10.2801Z" fill="currentColor"/><?php else: ?><path opacity="0.4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M14.5 9.89996H12.75V8.20996C12.75 7.79996 12.41 7.45996 12 7.45996C11.59 7.45996 11.25 7.79996 11.25 8.20996V9.89996H9.5C9.09 9.89996 8.75 10.24 8.75 10.65C8.75 11.06 9.09 11.4 9.5 11.4H11.25V13.21C11.25 13.62 11.59 13.96 12 13.96C12.41 13.96 12.75 13.62 12.75 13.21V11.4H14.5C14.91 11.4 15.25 11.06 15.25 10.65C15.25 10.24 14.91 9.89996 14.5 9.89996Z" fill="currentColor"/><?php endif; ?></svg>
                <span class="bm-watchlist-label"><?= $inArc1Watch ? 'حذف از علاقه‌مندی' : 'افزودن به علاقه‌مندی' ?></span>
            </button>
            <button type="button" class="btn btn-outline bm-share-trigger bm-share-open bm-share-action">
                <svg class="bm-share-network-icon" width="19" height="19" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g opacity="0.5"><path d="M7.20468 7.56232C7.51523 7.28822 7.54478 6.81427 7.27069 6.50371C6.99659 6.19316 6.52264 6.1636 6.21208 6.4377C4.39676 8.03992 3.25 10.3865 3.25 13C3.25 13.4142 3.58579 13.75 4 13.75C4.41421 13.75 4.75 13.4142 4.75 13C4.75 10.8347 5.69828 8.89188 7.20468 7.56232Z" fill="currentColor"/><path d="M17.7879 6.4377C17.4774 6.1636 17.0034 6.19316 16.7293 6.50371C16.4552 6.81427 16.4848 7.28822 16.7953 7.56232C18.3017 8.89188 19.25 10.8347 19.25 13C19.25 13.4142 19.5858 13.75 20 13.75C20.4142 13.75 20.75 13.4142 20.75 13C20.75 10.3865 19.6032 8.03992 17.7879 6.4377Z" fill="currentColor"/><path d="M10.1869 20.0217C9.7858 19.9184 9.37692 20.1599 9.27367 20.5611C9.17043 20.9622 9.41192 21.3711 9.81306 21.4743C10.5129 21.6544 11.2458 21.75 12 21.75C12.7542 21.75 13.4871 21.6544 14.1869 21.4743C14.5881 21.3711 14.8296 20.9622 14.7263 20.5611C14.6231 20.1599 14.2142 19.9184 13.8131 20.0217C13.2344 20.1706 12.627 20.25 12 20.25C11.373 20.25 10.7656 20.1706 10.1869 20.0217Z" fill="currentColor"/></g><path d="M9 6C9 7.65685 10.3431 9 12 9C13.6569 9 15 7.65685 15 6C15 4.34315 13.6569 3 12 3C10.3431 3 9 4.34315 9 6Z" fill="currentColor"/><path d="M2.5 18C2.5 19.6569 3.84315 21 5.5 21C7.15685 21 8.5 19.6569 8.5 18C8.5 16.3431 7.15685 15 5.5 15C3.84315 15 2.5 16.3431 2.5 18Z" fill="currentColor"/><path d="M18.5 21C16.8431 21 15.5 19.6569 15.5 18C15.5 16.3431 16.8431 15 18.5 15C20.1569 15 21.5 16.3431 21.5 18C21.5 19.6569 20.1569 21 18.5 21Z" fill="currentColor"/></svg><span>اشتراک گذاری</span>
            </button>
        </div>
    </div>
</div>

<style id="bm-movie-favorite-actions-v287">
body.movie-page .bm-watchlist-action{display:inline-flex;align-items:center;justify-content:center;gap:10px}
body.movie-page .bm-watchlist-action .bm-bookmark-icon{width:20px;height:20px;flex:0 0 20px;display:block}
body.movie-page .bm-watchlist-action .bm-watchlist-label{font:inherit;white-space:nowrap}
@media (max-width:768px){
  body.movie-page .action-buttons,body.movie-page .hero-actions{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:12px!important;align-items:stretch!important}
  body.movie-page .action-buttons .btn,body.movie-page .action-buttons .arc1-wl-btn,body.movie-page .hero-actions .btn,body.movie-page .hero-actions .arc1-wl-btn{width:100%!important;min-width:0!important;min-height:54px!important;justify-content:center!important;margin:0!important}
  body.movie-page .action-buttons .bm-share-trigger,body.movie-page .action-buttons .arc1-wl-btn.bm-watchlist-action{font-size:13px!important;padding:0 12px!important;overflow:visible!important;white-space:nowrap!important}
  body.movie-page .action-buttons .bm-share-trigger svg,body.movie-page .action-buttons .arc1-wl-btn.bm-watchlist-action svg{width:20px!important;height:20px!important;margin:0!important;flex:0 0 20px!important}
  body.movie-page .action-buttons .hero-primary-action,body.movie-page .action-buttons .bm-trailer-cta{min-height:56px!important}
  /* When only one primary CTA exists (latest episode OR trailer), keep it compact and centered instead of a huge full-width block. */
  body.movie-page .action-buttons.has-primary-latest:not(.has-primary-trailer) .hero-primary-action,
  body.movie-page .action-buttons.has-primary-trailer:not(.has-primary-latest) .bm-trailer-cta{grid-column:1/-1!important;max-width:calc(50% - 6px)!important;justify-self:center!important}
  /* With both primary actions available, keep them balanced in the first row. */
  body.movie-page .action-buttons.has-primary-latest.has-primary-trailer .hero-primary-action,
  body.movie-page .action-buttons.has-primary-latest.has-primary-trailer .bm-trailer-cta{grid-column:auto!important;max-width:none!important;justify-self:stretch!important}
  /* Secondary actions should always stay aligned as two equal buttons. */
  body.movie-page .action-buttons .bm-watchlist-action,body.movie-page .action-buttons .bm-share-action{grid-column:auto!important;grid-row:auto!important;max-width:none!important;justify-self:stretch!important}
  /* Pages with no trailer and no latest episode keep the two remaining actions compact on a single row. */
  body.movie-page .action-buttons:not(.has-primary-latest):not(.has-primary-trailer) .bm-watchlist-action,
  body.movie-page .action-buttons:not(.has-primary-latest):not(.has-primary-trailer) .bm-share-action{min-height:54px!important}
}
</style>
<style id="bm-desktop-action-icon-center-v291">
@media (min-width:1025px){
  body.bm-movie-template-cinematic .action-buttons .bm-share-trigger,
  body.bm-movie-template-cinematic .action-buttons .bm-watchlist-action{
    position:relative!important;
    display:inline-flex!important;
    align-items:center!important;
    justify-content:center!important;
    padding:0!important;
    line-height:0!important;
  }
  body.bm-movie-template-cinematic .action-buttons .bm-share-trigger>svg,
  body.bm-movie-template-cinematic .action-buttons .bm-watchlist-action>svg{
    position:absolute!important;
    left:50%!important;
    top:50%!important;
    width:17px!important;
    height:17px!important;
    margin:0!important;
    flex:none!important;
    transform:translate(-50%,-50%)!important;
    display:block!important;
  }
  body.bm-movie-template-cinematic .action-buttons .bm-share-trigger>span,
  body.bm-movie-template-cinematic .action-buttons .bm-watchlist-action>.bm-watchlist-label{
    display:none!important;
  }
}
</style>

<?php if($bmMovieCinematicTabs): ?>
<nav class="bm-cinematic-tabs" aria-label="دسترسی سریع صفحه فیلم">
    <?php if($bmArchiveDownloadAllowed || $bmArchiveStreamAllowed || $bmArchiveDownloadVipLocked || $bmArchiveStreamVipLocked): ?><a href="#arc1DownloadSection" class="is-active"><svg class="bm-tab-icon bm-tab-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><span><?= ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) ? 'دانلود باکس' : 'پخش آنلاین' ?></span></a><?php endif; ?>
    <a href="#bmMovieMoreInfo"><svg class="bm-tab-icon bm-tab-icon-more" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.4" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/><path d="M12 13.75C12.41 13.75 12.75 13.41 12.75 13V8C12.75 7.59 12.41 7.25 12 7.25C11.59 7.25 11.25 7.59 11.25 8V13C11.25 13.41 11.59 13.75 12 13.75Z" fill="currentColor"/><path d="M12.92 15.6199C12.87 15.4999 12.8 15.3899 12.71 15.2899C12.61 15.1999 12.5 15.1299 12.38 15.0799C12.14 14.9799 11.86 14.9799 11.62 15.0799C11.5 15.1299 11.39 15.1999 11.29 15.2899C11.2 15.3899 11.13 15.4999 11.08 15.6199C11.03 15.7399 11 15.8699 11 15.9999C11 16.1299 11.03 16.2599 11.08 16.3799C11.13 16.5099 11.2 16.6099 11.29 16.7099C11.39 16.7999 11.5 16.8699 11.62 16.9199C11.74 16.9699 11.87 16.9999 12 16.9999C12.13 16.9999 12.26 16.9699 12.38 16.9199C12.5 16.8699 12.61 16.7999 12.71 16.7099C12.8 16.6099 12.87 16.5099 12.92 16.3799C12.97 16.2599 13 16.1299 13 15.9999C13 15.8699 12.97 15.7399 12.92 15.6199Z" fill="currentColor"/></svg><span>اطلاعات بیشتر</span></a>
    <a href="#bmMovieComments"><svg class="bm-tab-icon bm-tab-icon-comments" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g fill="currentColor"><path d="M92.574,294.24V124.336H43.277C19.449,124.336,0,144.213,0,168.467v206.44c0,24.254,19.449,44.133,43.277,44.133h62v45.469c0,3.041,1.824,5.777,4.559,6.932c2.736,1.154,5.957,0.486,8.023-1.641l49.844-50.76h106.494c23.828,0,43.279-19.879,43.279-44.133v-0.061H172.262C128.314,374.846,92.574,338.676,92.574,294.24z"/><path d="M462.717,40H172.26c-27.105,0-49.283,22.59-49.283,50.197v204.037c0,27.61,22.178,50.199,49.283,50.199h164.668l75.348,76.033c2.399,2.442,6.004,3.172,9.135,1.852c3.133-1.322,5.176-4.434,5.176-7.887v-69.998h36.131c27.106,0,49.283-22.59,49.283-50.199V90.197C512,62.59,489.822,40,462.717,40z M369.156,280.115H195.92v-24.316h173.236V280.115z M439.058,204.129H195.92v-24.314h243.138V204.129z M439.058,128.143H195.92v-24.315h243.138V128.143z"/></g></svg><span>نظرات</span></a>
    <a href="#bmMovieRelated"><svg class="bm-tab-icon bm-tab-icon-related" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M18.4834 16.7674C17.8471 16.9195 17.1829 17 16.5 17C11.8056 17 8 13.1944 8 8.50001C8 8.01653 8.04036 7.54249 8.11791 7.08105C8.08172 7.11586 8.04432 7.14792 8.00494 7.17781C7.72433 7.39083 7.37485 7.46991 6.67589 7.62806L6.03954 7.77204C3.57986 8.32856 2.35002 8.60682 2.05742 9.54774C1.76482 10.4887 2.60325 11.4691 4.2801 13.4299L4.71392 13.9372C5.19042 14.4944 5.42868 14.773 5.53586 15.1177C5.64305 15.4624 5.60703 15.8341 5.53498 16.5776L5.4694 17.2544C5.21588 19.8706 5.08912 21.1787 5.85515 21.7602C6.62117 22.3417 7.77267 21.8116 10.0757 20.7512L10.6715 20.4768C11.3259 20.1755 11.6531 20.0249 12 20.0249C12.3469 20.0249 12.6741 20.1755 13.3285 20.4768L13.9243 20.7512C16.2273 21.8116 17.3788 22.3417 18.1449 21.7602C18.9109 21.1787 18.7841 19.8706 18.5306 17.2544L18.4834 16.7674Z" fill="currentColor"/><path opacity="0.5" d="M9.15302 5.40838L8.82532 5.99623C8.46538 6.64194 8.28541 6.96479 8.0048 7.17781C8.04418 7.14791 8.08158 7.11586 8.11777 7.08105C8.04022 7.54249 7.99986 8.01653 7.99986 8.50001C7.99986 13.1944 11.8054 17 16.4999 17C17.1828 17 17.8469 16.9195 18.4833 16.7674L18.4649 16.5776C18.3928 15.8341 18.3568 15.4624 18.464 15.1177C18.5712 14.773 18.8094 14.4944 19.2859 13.9372L19.7198 13.4299C21.3966 11.4691 22.235 10.4886 21.9424 9.54773C21.6498 8.60682 20.42 8.32856 17.9603 7.77203L17.324 7.62805C16.625 7.4699 16.2755 7.39083 15.9949 7.17781C15.7143 6.96479 15.5343 6.64194 15.1744 5.99624L14.8467 5.40837C13.58 3.13612 12.9467 2 11.9999 2C11.053 2 10.4197 3.13613 9.15302 5.40838Z" fill="currentColor"/></svg><span>پیشنهادها</span></a>
</nav>
<?php endif; ?>

<!-- پلیر داخلی آرشیو ۱ — نسخه پیشرفته -->
<link rel="stylesheet" href="/assets/css/movie-inline-5.css?v=dl36-realfix">
<link rel="stylesheet" href="/assets/css/bm-player-subtitle-direct-v13.css?v=20261021-s13">
<div id="arc1PlayerWrapper" style="display:none;margin-bottom:24px">
    <div class="player-wrapper" id="arc1PlayerInner">
        <video id="arc1VideoEl" class="player-video" playsinline controlslist="nodownload noremoteplayback" disableremoteplayback disablepictureinpicture draggable="false" oncontextmenu="return false"></video>
        <!-- Next Episode Panel (آرشیو ۱) -->
        <div id="arc1NextEpPanel">
            <div class="arc1-next-card">
                <div class="arc1-next-icon"><svg viewBox="0 0 24 24"><polygon points="5 3 15 12 5 21 5 3"/><line x1="19" y1="5" x2="19" y2="19"/></svg></div>
                <div class="arc1-next-info">
                    <div class="arc1-next-label">قسمت بعدی آماده‌ست</div>
                    <div class="arc1-next-title" id="arc1NextTitle">قسمت بعدی</div>
                    <div class="arc1-next-subtitle" id="arc1NextSubtitle"></div>
                </div>
                <div class="arc1-next-ring" id="arc1NextRing">
                    <svg viewBox="0 0 36 36"><circle class="arc1-next-ring-track" cx="18" cy="18" r="15.9"/><circle class="arc1-next-ring-fill" id="arc1NextRingFill" cx="18" cy="18" r="15.9"/></svg>
                    <div class="arc1-next-ring-num" id="arc1NextCount">8</div>
                </div>
                <div class="arc1-next-actions">
                    <button class="arc1-next-go" id="arc1NextGoBtn">برو قسمت بعدی ←</button>
                    <button class="arc1-next-dismiss" id="arc1NextDismiss">نه ممنون</button>
                </div>
            </div>
        </div>

        <div class="subtitle-overlay" id="arc1SubtitleOverlay"></div>
        <div class="brightness-hud" id="arc1BrightnessHud"><div><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></div><div class="hud-value" id="arc1BrightnessHudValue">100%</div></div>
        <div class="player-toast-stack" id="arc1PlayerToastStack" aria-live="polite"></div>
        <div class="player-hud" id="arc1PlayerHud" aria-hidden="true"><div class="player-hud-icon" id="arc1PlayerHudIcon">•</div><div class="player-hud-title" id="arc1PlayerHudTitle"></div><div class="player-hud-value" id="arc1PlayerHudValue"></div><div class="player-hud-bar"><span id="arc1PlayerHudBar"></span></div></div>
        <div class="unlock-overlay" id="arc1LockOverlay"><button type="button" class="unlock-pill" id="arc1UnlockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2.3"/></svg><span><?= $userLang === 'fa' ? 'باز کردن قفل' : 'Unlock controls' ?></span></button></div>
        <div class="buffering" id="arc1Buffering"></div>
        <div class="player-controls" id="arc1Controls">
            <div class="progress-container">
                <span class="progress-time" id="arc1CurrentTime">00:00</span>
                <input type="range" id="arc1ProgressBar" class="progress-bar" min="0" max="100" value="0">
                <span class="progress-time" id="arc1Duration">00:00</span>
            </div>
            <div class="controls-row">
                <div class="controls-left">
                    <button class="ctrl-btn" id="arc1PlayPause" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
                    <button class="ctrl-btn" id="arc1SeekBack" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="10 9 6 12 10 15"/><polyline points="18 9 14 12 18 15"/></svg><span style="font-size:12px;">10</span></button>
                    <button class="ctrl-btn" id="arc1SeekFwd" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="14 9 18 12 14 15"/><polyline points="6 9 10 12 6 15"/></svg><span style="font-size:12px;">10</span></button>
                    <div class="volume-control">
                        <button class="ctrl-btn bm-sound-toggle" id="arc1VolBtn" type="button" aria-label="قطع یا وصل صدا" aria-pressed="false"><span class="bm-sound-speaker" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="M39.389 13.769 22.235 28.606H6v19.093h15.989l17.4 15.051V13.769Z"/><path d="M48 27.6a19.5 19.5 0 0 1 0 21.4M55.1 20.5a30 30 0 0 1 0 35.6M61.6 14a38.8 38.8 0 0 1 0 48.6" class="bm-sound-waves"/></svg></span><span class="bm-sound-muted" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="m39 14-17 15H6v19h16l17 15Z"/><path d="m49 26 20 24m0-24-20 24" class="bm-sound-x"/></svg></span></button>
                        <input type="range" id="arc1VolSlider" class="volume-slider" min="0" max="100" value="100">
                    </div>
                </div>
                <div class="controls-right">
                    <button type="button" class="ctrl-btn bm-subtitle-direct-btn" id="arc1SubtitleDirectBtn" title="<?= $userLang === 'fa' ? 'دوبله و زیرنویس' : 'Audio & subtitles' ?>" aria-label="<?= $userLang === 'fa' ? 'باز کردن تنظیمات دوبله و زیرنویس' : 'Open audio and subtitle settings' ?>" aria-expanded="false" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><path d="M2 12C2 15.7712 2 17.6569 3.17157 18.8284C4.34315 20 6.22876 20 10 20H14C17.7712 20 19.6569 20 20.8284 18.8284C22 17.6569 22 15.7712 22 12C22 8.22876 22 6.34315 20.8284 5.17157C19.6569 4 17.7712 4 14 4H10C6.22876 4 4.34315 4 3.17157 5.17157C2.51839 5.82475 2.22937 6.69989 2.10149 8"/><path d="M10 16H6M14 13H18M14 16H12.5M9.5 13H11.5M18 16H16.5M6 13H7"/></svg></button>
                    <div class="settings-dropdown">
                        <button class="ctrl-btn" id="arc1SettingsBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                        <div class="settings-dropdown-content player-settings-modal" id="arc1SettingsDropdown" dir="<?= e($dir) ?>">
                            <div class="settings-panel settings-main-panel active" data-settings-panel="main">
                                <div class="settings-modal-header">
                                    <div class="settings-modal-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                        <div>
                                            <div><?= $userLang === 'fa' ? 'تنظیمات پخش' : 'Playback settings' ?></div>
                                            <div class="settings-modal-subtitle"><?= $userLang === 'fa' ? 'کیفیت، سرعت، تصویر، زیرنویس و تایمر خواب' : 'Quality, speed, picture, subtitle and sleep timer' ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="arc1OpenQualityPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 13h8M8 9h8"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'انتخاب کیفیت و نوع دوبله/زیرنویس' : 'Choose quality and audio/subtitle type' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentQualityLabel"><?= $userLang === 'fa' ? 'خودکار' : 'Auto' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <button type="button" class="settings-row" id="arc1OpenSpeedPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'مودال اختصاصی قابل اسکرول' : 'Scrollable dedicated panel' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentSpeedLabel">1x</span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="arc1OpenPictureModePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7z"/><path d="M14 15h3"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'عادی، بزرگ، کشیده 16:9 یا کوچک‌تر' : 'Normal, zoom, 16:9 stretch or smaller' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentPictureModeLabel"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>


                                    <button type="button" class="settings-row" id="arc1OpenTheatrePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/><path d="M7 11h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'بزرگ‌تر شدن پلیر و تاریک شدن اطراف' : 'Larger player with darker surroundings' ?></span></span></span>
                                        <span class="settings-row-value" id="arc1CurrentTheatreModeLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="arc1OpenBrightnessPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'کنترل نور با منو یا ژست لمسی' : 'Adjust by menu or touch gesture' ?></span></span></span><span class="settings-row-value" id="arc1CurrentBrightnessLabel">100%</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <button type="button" class="settings-row" id="arc1OpenSleepTimerPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'توقف خودکار پخش بعد از زمان انتخابی' : 'Automatically pause playback after a selected time' ?></span></span></span>
                                        <span class="settings-row-value sleep-countdown" id="arc1CurrentSleepTimerLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <div class="settings-divider"></div>
                                    <button type="button" class="settings-row" id="arc1OpenSubtitlePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'دوبله و زیرنویس' : 'Audio & subtitles' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'انتخاب دوبله، آپلود و تنظیم زیرنویس' : 'Choose audio, upload and adjust subtitles' ?></span></span></span><span class="settings-row-value" id="arc1CurrentSubtitleLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <input type="file" id="arc1SubtitleUpload" accept=".srt,.vtt,.ssa,.ass" style="display:none">

                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="quality">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1QualityModalList"></div>
                            </div>
                            <div class="settings-panel" data-settings-panel="speed">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1SpeedSettingsList">

                                    <div class="speed-touch-card" id="arc1SpeedTouchCard">
                                        <div class="speed-touch-head"><span><?= $userLang === 'fa' ? 'تنظیم لمسی سرعت' : 'Touch speed control' ?></span><strong class="speed-touch-value" id="arc1SpeedTouchValue">1x</strong></div>
                                        <div class="speed-touch-pad" id="arc1SpeedTouchPad"><span><?= $userLang === 'fa' ? 'مثل کنترل آیفونی، اینجا را بالا/پایین بکش' : 'Swipe up/down here like an iOS control' ?></span></div>
                                        <input type="range" class="settings-range speed-range" id="arc1SpeedRange" min="0.25" max="2" step="0.05" value="1">
                                    </div>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.25"><span class="settings-choice-left"><span class="settings-choice-title">0.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.5"><span class="settings-choice-left"><span class="settings-choice-title">0.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.75"><span class="settings-choice-left"><span class="settings-choice-title">0.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt active" data-speed="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">1x</span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.25"><span class="settings-choice-left"><span class="settings-choice-title">1.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.5"><span class="settings-choice-left"><span class="settings-choice-title">1.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.75"><span class="settings-choice-left"><span class="settings-choice-title">1.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="2"><span class="settings-choice-left"><span class="settings-choice-title">2x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="picture">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1PictureModeSettingsList">
                                    <button type="button" class="settings-choice picture-mode-opt active" data-picture-mode="normal"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان حالت فعلی پلیر' : 'Current default player view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="cover"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'بزرگ / پرکننده' : 'Zoom / fill' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر قاب را پر می‌کند؛ ممکن است کمی برش بخورد' : 'Fills the frame; edges may crop slightly' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="stretch"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کشیده 16:9' : '16:9 stretch' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمام قاب 16:9 بدون حاشیه، با کشیدگی احتمالی' : 'No side bars, may stretch the image' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="small"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر کمی کوچک‌تر داخل قاب نمایش داده می‌شود' : 'Shows the video slightly smaller inside the frame' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="subtitle">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'دوبله و زیرنویس' : 'Audio & subtitles' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="bm-player-guide-replay" id="bmPlayerGuideReplay" aria-label="<?= $userLang === 'fa' ? 'نمایش راهنمای دوبله و زیرنویس' : 'Show audio and subtitle guide' ?>"><span aria-hidden="true">?</span><span><?= $userLang === 'fa' ? 'راهنمای استفاده از دوبله و زیرنویس' : 'How to use audio & subtitles' ?></span></button>
                                    <div class="bm-player-section-heading bm-player-subtitle-heading"><span class="bm-guide-caption-icon" aria-hidden="true">CC</span><strong><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitles' ?></strong><small><?= $userLang === 'fa' ? 'آپلود و شخصی‌سازی زیرنویس' : 'Upload and customize subtitles' ?></small></div>
                                    <button type="button" class="settings-row" id="arc1UploadSubtitleOption"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'آپلود زیرنویس' : 'Upload subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'SRT، VTT و ASS ساده' : 'SRT, VTT and basic ASS' ?></span></span></span></button>
                                    <button type="button" class="settings-row" id="arc1ToggleSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'نمایش زیرنویس' : 'Show subtitles' ?></span><span class="settings-row-desc" id="arc1SubtitleVisibilityLabel"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></span></span><span class="settings-row-value" id="arc1SubtitleToggleValue"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></button>
                                    <button type="button" class="settings-row" id="arc1RemoveSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span><span class="settings-row-title"><?= $userLang === 'fa' ? 'حذف زیرنویس' : 'Remove subtitle' ?></span></span></button>
                                        <div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'رنگ زیرنویس' : 'Subtitle color' ?></div>
                                        <div class="subtitle-color-grid">
                                            <button type="button" class="subtitle-color-btn active" data-subtitle-color="#ffffff" title="White"><span class="subtitle-color-dot" style="background:#ffffff"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ffd84d" title="Yellow"><span class="subtitle-color-dot" style="background:#ffd84d"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#36ff9f" title="Green"><span class="subtitle-color-dot" style="background:#36ff9f"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#7dd3fc" title="Blue"><span class="subtitle-color-dot" style="background:#7dd3fc"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ff9ad5" title="Pink"><span class="subtitle-color-dot" style="background:#ff9ad5"></span></button>
                                        </div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'جای زیرنویس روی تصویر' : 'Subtitle position' ?></div>
                                    <div class="settings-range-card subtitle-position-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'جابجایی عمودی' : 'Vertical position' ?></span><strong id="arc1SubtitlePositionLabel">0px</strong></div>
                                        <input type="range" class="settings-range" id="arc1SubtitlePositionRange" min="-80" max="80" step="4" value="0">
                                    </div>
                                    <div class="settings-sync-grid subtitle-position-actions">
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionUpBtn"><?= $userLang === 'fa' ? 'بالاتر' : 'Higher' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionResetBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitlePositionDownBtn"><?= $userLang === 'fa' ? 'پایین‌تر' : 'Lower' ?></button>
                                    </div>
                                    <div class="settings-choice-desc subtitle-position-hint"><?= $userLang === 'fa' ? 'اگر جای زیرنویس روی موبایل یا تلویزیون مناسب نبود، همین‌جا بالا/پایینش کن.' : 'Move subtitles up or down if the default position is not comfortable.' ?></div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'سینک و تاخیر زیرنویس' : 'Subtitle sync / delay' ?></div>
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'تاخیر فعلی' : 'Current delay' ?></span><strong id="arc1SubtitleDelayLabel">0.0s</strong></div>
                                        <input type="range" class="settings-range" id="arc1SubtitleDelayRange" min="-5" max="5" step="0.1" value="0">
                                    </div>
                                    <div class="settings-sync-grid">
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleEarlierBtn"><?= $userLang === 'fa' ? 'زودتر -0.1s' : 'Earlier -0.1s' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleResetDelayBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="arc1SubtitleLaterBtn"><?= $userLang === 'fa' ? 'دیرتر +0.1s' : 'Later +0.1s' ?></button>
                                    </div>
                                    <div class="settings-choice-desc" style="padding:6px 8px 10px;line-height:1.8;"><?= $userLang === 'fa' ? 'گام تنظیم ۰.۱ ثانیه است تا دقیق‌تر از پرش‌های چندثانیه‌ای باشد.' : 'Adjustment step is 0.1s for precise subtitle sync.' ?></div>
                                </div>
                            </div>


                            <div class="settings-panel" data-settings-panel="theatre">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-choice theatre-opt active" data-theatre="off"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'نمای عادی صفحه' : 'Normal page view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice theatre-opt" data-theatre="on"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمرکز روی فیلم بدون تمام‌صفحه' : 'Focus on video without fullscreen' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'این حالت فقط با انتخاب کاربر فعال می‌شود و فول‌اسکرین را جایگزین نمی‌کند.' : 'This mode only turns on when selected and does not replace fullscreen.' ?></div>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="brightness">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'روشنایی تصویر' : 'Brightness' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'میزان نور' : 'Brightness level' ?></span><strong id="arc1BrightnessPercentLabel">100%</strong></div>
                                        <input type="range" class="settings-range" id="arc1BrightnessRange" min="40" max="160" step="5" value="100">
                                    </div>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="0.7"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کم‌نور' : 'Dim' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset active" data-brightness="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان نور اصلی ویدیو' : 'Original video brightness' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.25"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن‌تر' : 'Brighter' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.5"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خیلی روشن' : 'Very bright' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'روی موبایل با کشیدن انگشت بالا/پایین روی نیمه چپ پلیر هم نور تغییر می‌کند.' : 'On mobile, swipe up/down on the left half of the player to adjust brightness.' ?></div>
                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="sleep">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="arc1SleepTimerSettingsList">
                                    <button type="button" class="settings-choice sleep-opt active" data-sleep-minutes="0"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تایمر فعال نیست' : 'No active timer' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="10"><span class="settings-choice-left"><span class="settings-choice-title">10 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="15"><span class="settings-choice-left"><span class="settings-choice-title">15 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="30"><span class="settings-choice-left"><span class="settings-choice-title">30 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="45"><span class="settings-choice-left"><span class="settings-choice-title">45 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="60"><span class="settings-choice-left"><span class="settings-choice-title">60 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="90"><span class="settings-choice-left"><span class="settings-choice-title">90 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="120"><span class="settings-choice-left"><span class="settings-choice-title">120 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="ctrl-btn" id="arc1DlBtn" style="display:none!important" aria-hidden="true" tabindex="-1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
                    <button class="ctrl-btn screen-lock-btn unlocked" id="arc1LockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
                    <button class="ctrl-btn" id="arc1Fullscreen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></button>
                </div>
            </div>
        </div>
    </div>
    <div id="arc1NowPlaying" style="text-align:center;font-size:12px;color:rgba(255,255,255,.45);margin-top:8px;padding:0 4px"></div>
</div>

<!-- ===== لینک‌های دانلود / قسمت‌ها آرشیو ۱ ===== -->
<?php if(!empty($arc1Downloads)): ?>
<?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '' ?>
<div class="download-section" id="arc1DownloadSection">
    <?php if($bmArchiveItemDownloadBlocked): ?><div class="bm-archive-policy-notice">لینک‌های دانلود و پخش آنلاین این عنوان توسط مدیریت بسته شده است.</div><?php endif; ?>
    <div class="section-title">
        <span style="display:flex;align-items:center;gap:9px">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                <?= $arc1IsSeries ? '<rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/>' : '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>' ?>
            </svg>
            <?= $arc1IsSeries ? 'قسمت‌ها' : (($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) ? 'لینک‌های پخش و دانلود' : 'نسخه‌های پخش آنلاین') ?>
        </span>
        <?php if($bmShowSeriesCopy): ?>
        <button type="button" class="bm-bulk-copy-open bm-bulk-copy-open--inline<?= $bmHasSeriesCopy ? '' : ' is-pending' ?>" data-bm-bulk-copy-open aria-haspopup="dialog" aria-controls="bmSeriesBulkModal">
            <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
            <span><?= $userLang === 'fa' ? 'همه لینک‌ها' : 'All links' ?></span>
            <small><?= $userLang === 'fa' ? 'کپی یا ADM/IDM' : 'Copy or ADM/IDM' ?></small>
        </button>
        <?php endif; ?>
    </div>

<style id="bm-arc1-rich-meta-v148">
/* Premium archive-1 media metadata — visual-only hotfix */
.bm-arc1-rich-meta{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:8px;
    margin-top:9px;
    direction:ltr;
}
.bm-arc1-meta-pill{
    --bm-tag-color:188,200,224;
    --bm-tag-strong:#dbe5f7;
    position:relative;
    isolation:isolate;
    overflow:hidden;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    min-height:30px;
    max-width:100%;
    padding:0 13px 0 12px;
    border-radius:11px;
    border:1px solid rgba(var(--bm-tag-color),.34);
    background:
        radial-gradient(circle at 18% 0%,rgba(var(--bm-tag-color),.25),transparent 42%),
        linear-gradient(145deg,rgba(var(--bm-tag-color),.14),rgba(10,13,22,.92) 54%,rgba(var(--bm-tag-color),.075));
    color:var(--bm-tag-strong);
    font-size:10.5px;
    font-weight:950;
    line-height:1;
    letter-spacing:.035em;
    white-space:nowrap;
    text-shadow:0 0 14px rgba(var(--bm-tag-color),.32);
    box-shadow:
        0 8px 20px rgba(0,0,0,.24),
        0 0 0 1px rgba(255,255,255,.025) inset,
        0 1px 0 rgba(255,255,255,.11) inset,
        0 -10px 24px rgba(var(--bm-tag-color),.05) inset;
    backdrop-filter:blur(12px) saturate(125%);
    -webkit-backdrop-filter:blur(12px) saturate(125%);
    transition:transform .22s ease,border-color .22s ease,box-shadow .22s ease,filter .22s ease;
}
.bm-arc1-meta-pill:before{
    content:"";
    width:8px;
    height:8px;
    flex:0 0 8px;
    border-radius:3px;
    transform:rotate(45deg);
    background:linear-gradient(135deg,#fff,var(--bm-tag-strong) 48%,rgba(var(--bm-tag-color),.65));
    box-shadow:0 0 0 3px rgba(var(--bm-tag-color),.10),0 0 15px rgba(var(--bm-tag-color),.72);
}
.bm-arc1-meta-pill:after{
    content:"";
    position:absolute;
    z-index:-1;
    top:-55%;
    bottom:-55%;
    left:-42%;
    width:34%;
    transform:skewX(-20deg);
    background:linear-gradient(90deg,transparent,rgba(255,255,255,.20),transparent);
    opacity:.7;
    transition:left .55s ease;
}
.bm-arc1-meta-pill:hover{
    transform:translateY(-2px);
    border-color:rgba(var(--bm-tag-color),.58);
    filter:saturate(1.12);
    box-shadow:
        0 12px 28px rgba(0,0,0,.34),
        0 0 22px rgba(var(--bm-tag-color),.13),
        0 1px 0 rgba(255,255,255,.15) inset;
}
.bm-arc1-meta-pill:hover:after{left:118%}
.bm-arc1-meta-pill b{
    direction:rtl;
    color:rgba(255,255,255,.58);
    font-size:9px;
    font-weight:900;
    letter-spacing:0;
}
.bm-arc1-meta-pill span{direction:ltr;unicode-bidi:plaintext}

/* Distinct premium identities */
.bm-arc1-meta-pill.is-format{
    --bm-tag-color:69,155,255;
    --bm-tag-strong:#bdddff;
}
.bm-arc1-meta-pill.is-codec{
    --bm-tag-color:162,105,255;
    --bm-tag-strong:#dfc9ff;
}
.bm-arc1-meta-pill.is-encoder{
    --bm-tag-color:255,193,92;
    --bm-tag-strong:#ffe1a0;
}
.bm-arc1-meta-pill.is-dub{
    --bm-tag-color:34,211,153;
    --bm-tag-strong:#9af3d1;
    direction:rtl;
}
.bm-arc1-meta-pill.is-dub span{direction:rtl;unicode-bidi:normal}

/* Source-specific finishes */
.bm-arc1-meta-pill[data-meta="BluRay"]{
    --bm-tag-color:52,184,255;
    --bm-tag-strong:#b9ecff;
    background:radial-gradient(circle at 18% 0%,rgba(52,184,255,.34),transparent 45%),linear-gradient(145deg,rgba(26,111,204,.30),rgba(8,15,29,.94) 57%,rgba(64,201,255,.11));
}
.bm-arc1-meta-pill[data-meta="WEB-DL"]{
    --bm-tag-color:73,123,255;
    --bm-tag-strong:#d3dcff;
    background:radial-gradient(circle at 16% 0%,rgba(151,82,255,.34),transparent 43%),linear-gradient(145deg,rgba(69,70,219,.29),rgba(10,12,28,.95) 55%,rgba(63,191,255,.12));
}
.bm-arc1-meta-pill[data-meta="WEBRip"]{
    --bm-tag-color:193,91,255;
    --bm-tag-strong:#edc6ff;
}
.bm-arc1-meta-pill[data-meta="Remux"]{
    --bm-tag-color:255,190,74;
    --bm-tag-strong:#ffe2a3;
}
.bm-arc1-meta-pill[data-meta="HDTV"]{
    --bm-tag-color:40,211,196;
    --bm-tag-strong:#a9fff3;
}

/* Codec-specific finishes */
.bm-arc1-meta-pill[data-meta="x265"],
.bm-arc1-meta-pill[data-meta="HEVC"],
.bm-arc1-meta-pill[data-meta*="x265"]{
    --bm-tag-color:37,211,146;
    --bm-tag-strong:#a4f4d1;
    background:radial-gradient(circle at 18% 0%,rgba(37,211,146,.30),transparent 44%),linear-gradient(145deg,rgba(21,139,99,.25),rgba(8,20,19,.94) 58%,rgba(37,211,146,.08));
}
.bm-arc1-meta-pill[data-meta="x264"]{
    --bm-tag-color:255,142,70;
    --bm-tag-strong:#ffd0ad;
}
.bm-arc1-meta-pill[data-meta="AV1"]{
    --bm-tag-color:255,76,138;
    --bm-tag-strong:#ffc0d7;
}
.bm-arc1-meta-pill[data-meta="10Bit"],
.bm-arc1-meta-pill[data-meta*="10Bit"]{
    --bm-tag-color:191,94,255;
    --bm-tag-strong:#efd0ff;
    background:radial-gradient(circle at 18% 0%,rgba(191,94,255,.36),transparent 44%),linear-gradient(145deg,rgba(111,50,190,.30),rgba(17,10,29,.95) 57%,rgba(232,102,255,.10));
}

.bm-movie-download-row .download-card-left{align-items:center;min-width:0}
.bm-movie-download-row .link-info{min-width:0;display:flex;flex-direction:column;align-items:flex-start}
.bm-movie-download-row .quality{white-space:normal;line-height:1.35;font-size:13px;font-weight:950}
.bm-movie-download-row .size{margin-top:3px}
@media(max-width:760px){
    .bm-movie-download-row{align-items:flex-start}
    .bm-movie-download-row .download-card-left{width:100%;align-items:flex-start}
    .bm-arc1-rich-meta{gap:6px;margin-top:7px}
    .bm-arc1-meta-pill{min-height:27px;padding:0 10px 0 9px;font-size:9.5px;border-radius:10px}
    .bm-arc1-meta-pill:before{width:7px;height:7px;flex-basis:7px;border-radius:2px}
    .bm-arc1-meta-pill b{font-size:8.5px}
}
@media(prefers-reduced-motion:reduce){
    .bm-arc1-meta-pill,.bm-arc1-meta-pill:after{transition:none!important}
}
</style>

    <?php if($arc1IsSeries): ?>
    <!-- ===== سریال: سوئیچ فصل انیمیشنی ===== -->
    <?php if(count($arc1SeriesSeasons) > 0): ?>
    <div class="arc1-season-tabs" id="arc1SeasonTabs">
        <?php $bmArc1SupportPlaced = false; foreach($arc1SeriesSeasons as $sk => $eps): $sn = ltrim(preg_replace('/[^0-9]/','',$sk),'0')?:'1'; ?>
        <button class="arc1-season-tab" aria-expanded="false" data-target="sp-<?= e($sk) ?>" onclick="arc1SwitchSeason(this, 'sp-<?= e($sk) ?>')">
            فصل <?= $sn ?>
            <span class="tab-count">(<?= count($eps) ?>)</span>
        </button>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <?php foreach($arc1SeriesSeasons as $sk => $eps):
        $sn = ltrim(preg_replace('/[^0-9]/','',$sk),'0')?:'1';
        // V47: all seasons start collapsed; user opens the desired season.
        // ساخت آرایه مسطح قسمت‌ها برای پیدا کردن next
        $allEpKeys = array_keys($eps);
    ?>
    <div id="sp-<?= e($sk) ?>" data-sp="1" style="display:none">
        <div class="arc1-season-header">
            <span style="font-size:14px;font-weight:900;color:var(--accent)">فصل <?= $sn ?></span>
            <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($eps) ?> قسمت</span>
        </div>
        <?php foreach($eps as $ek => $links):
            $en = $ek==='full' ? '' : ltrim(preg_replace('/[^0-9]/','',$ek),'0');
            $epLabel = $ek==='full' ? 'فصل کامل' : 'قسمت '.$en;
            $epQualities = array_unique(array_column($links,'quality'));
                                    // پیدا کردن قسمت بعدی
            $currentEpPos = array_search($ek, $allEpKeys);
            $nextEk = ($currentEpPos !== false && isset($allEpKeys[$currentEpPos+1])) ? $allEpKeys[$currentEpPos+1] : null;
            $nextUrl = $nextEk ? ($eps[$nextEk][0]['url'] ?? '') : '';
            $nextSubtitleUrl = $nextEk ? trim((string)($eps[$nextEk][0]['subtitle_url'] ?? '')) : '';
            $nextEnNum = $nextEk ? (ltrim(preg_replace('/[^0-9]/','',$nextEk),'0') ?: '') : '';
            $nextLabel = $nextEk ? ('فصل '.$sn.' قسمت '.$nextEnNum) : '';
        ?>
        <div class="arc1-ep-card">
            <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                <div class="arc1-ep-num"><?= e($epLabel) ?></div>
                <div style="display:flex;align-items:center;gap:8px">
                    <div class="arc1-ep-badges">
                        <?php foreach($epQualities as $qb): ?><span style="font-size:10px;padding:2px 8px;border-radius:20px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);color:var(--accent);font-weight:700"><?= e($qb) ?></span><?php endforeach; ?>
                    </div>
                    <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                </div>
            </div>
            <div class="arc1-ep-links">
                <?php foreach($links as $lkIdx => $lk): ?>
                <?php
                $arc1SubHref = !empty($lk['subtitle_url']) ? (string)$lk['subtitle_url'] : '';
                ?>
                <div class="arc1-link-row">
                    <div class="arc1-link-meta">
                        <?php $arc1LinkTypeLabel = bm_archive_download_type_label($lk['type'] ?? '', $userLang, $bmArchiveSubFa, $bmArchiveSubEn); ?>
                        <span class="download-type-badge <?= e(bm_archive_download_type_class($lk['type'] ?? '')) ?>">
                            <?php if(($lk['type'] ?? '')==='dub'): ?><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?php endif; ?>
                            <?= e($arc1LinkTypeLabel) ?>
                        </span>
                        <div>
                            <div class="bm-resolution-badge" data-bm-quality="<?= e($lk['quality']) ?>" style="font-size:13px;font-weight:800;color:#fff"><?= e($lk['quality']) ?></div>
                            <?= bm_v111_cam_notice((array)$lk,(string)($lk['quality'] ?? ''),(string)($lk['url'] ?? ''),$userLang) ?><?php if(!empty($lk['meta'])): ?><div class="bm-arc1-rich-meta"><?php foreach($lk['meta'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind'] ?? 'detail') ?>" data-meta="<?= e($meta['value'] ?? '') ?>"><?php if(trim((string)($meta['label'] ?? '')) !== ''): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="arc1-link-actions">
                        <button class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                            data-url="<?= e(bm_archive_stream_url($lk['url'])) ?>" <?php if($bmArchiveDownloadAllowed && empty($lk['source_download_locked'])): ?>data-copy-url="<?= e(bm_dl_wrap_url($lk['url'])) ?>"<?php endif; ?>
                            data-subtitle-url="<?= e(bm_archive_stream_url($lk['subtitle_url'] ?? '')) ?>"
                            data-season="<?= e($sn) ?>"
                            data-episode="<?= e($en) ?>"
                            data-label="<?= e($epLabel . ' — ' . $arc1LinkTypeLabel . ' — ' . ($lk['quality'] ?? '')) ?>"
                            data-next-url="<?= e(bm_archive_stream_url($nextUrl)) ?>"
                            data-next-label="<?= e($nextLabel) ?>"
                            data-next-subtitle-url="<?= e(bm_archive_stream_url($nextSubtitleUrl)) ?>"
                            data-next-ep="<?= e($nextEnNum) ?>"
                            data-next-season="<?= e($sn) ?>">
                            <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                            پخش
                        </button>
                        <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && empty($lk['source_download_locked'])): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($lk['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-dl-btn">
                            <svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg>
                            دانلود
                        </a><?php endif; ?>
                        <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && $arc1SubHref): ?>
                        <a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($arc1SubHref, 21600, $isArc6 ? 'archive6' : '', false, $isArc6)) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-sub-dl-btn" title="<?= $userLang === 'fa' ? 'دانلود زیرنویس فارسی' : 'Download Persian Subtitles' ?>">
                            <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                            <?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php if(!$bmArc1SupportPlaced): $bmArc1SupportPlaced = true; bm_render_download_support_card($isArc6 ? 'archive6-series' : ($isArc5 ? 'archive5-series' : ($isArc3 ? 'archive3-series' : ($isArc4 ? 'archive4-series' : 'archive1-series')))); endif; ?>
    <?php endforeach; ?>


    <?php else: ?>
    <!-- فیلم: لینک‌های دانلود/پخش داخل آکاردئون؛ سبک‌تر برای موبایل‌های ضعیف -->
    <?php if(!empty($arc1MovieDub)): ?>
    <?php $arc1DubCount = 0; foreach($arc1MovieDub as $arc1DubItems) { $arc1DubCount += is_array($arc1DubItems) ? count($arc1DubItems) : 0; } ?>
    <div class="arc1-ep-card bm-movie-download-accordion is-dub-group">
        <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
            <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg>
                <?= $userLang === 'fa' ? 'دوبله فارسی' : 'Persian Dubbed' ?>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
                <span class="bm-download-group-count"><?= (int)$arc1DubCount ?> <?= $userLang === 'fa' ? 'لینک' : 'links' ?></span>
                <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
            </div>
        </div>
        <div class="arc1-ep-links bm-movie-download-panel">
        <?php foreach($arc1MovieDub as $q => $items): foreach($items as $it): ?>
        <?php $arc1SubHref = !empty($it['subtitle_url']) ? (string)$it['subtitle_url'] : ''; ?>
        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default">
            <div class="download-card-left">
                <span class="download-type-badge is-dub"><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?= !empty($it['is_audio']) ? ($userLang === 'fa' ? 'صوت دوبله' : 'Dubbed Audio') : ($userLang === 'fa' ? 'دوبله' : 'Dubbed') ?></span>
                <div class="link-info"><span class="quality" data-bm-quality="<?= e($q) ?>"><?= e($q) ?><?php if(!empty($it['is_audio'])): ?><span class="recommended-badge"><?= $userLang === 'fa' ? 'فایل صوتی جداگانه' : 'Separate Audio File' ?></span><?php endif; ?></span><?php if(!empty($it['size'])): ?><span class="size"><?= e($it['size']) ?></span><?php endif; ?><?= bm_v111_cam_notice((array)$it,(string)$q,(string)($it['url'] ?? ''),$userLang) ?><?php if(!empty($it['meta'])): ?><div class="bm-arc1-rich-meta"><?php foreach($it['meta'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind'] ?? 'detail') ?>" data-meta="<?= e($meta['value'] ?? '') ?>"><?php if(trim((string)($meta['label'] ?? '')) !== ''): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?></div>
            </div>
            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                <button class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?> data-url="<?= e(bm_archive_stream_url($it['url'])) ?>" <?php if($bmArchiveDownloadAllowed && empty($it['source_download_locked'])): ?>data-copy-url="<?= e(bm_dl_wrap_url($it['url'])) ?>"<?php endif; ?> data-subtitle-url="<?= e(bm_archive_stream_url($it['subtitle_url'] ?? '')) ?>" data-label="<?= e((!empty($it['is_audio']) ? ($userLang === 'fa' ? 'صوت دوبله' : 'Dubbed Audio') : ($userLang === 'fa' ? 'دوبله' : 'Dubbed')) . ' — ' . $q) ?>">
                    <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                    <?= !empty($it['is_audio']) ? ($userLang === 'fa' ? 'پخش صوت' : 'Play Audio') : ($userLang === 'fa' ? 'پخش' : 'Play') ?>
                </button>
                <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && empty($it['source_download_locked'])): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($it['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="download-icon" style="text-decoration:none"><svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><?= $userLang === 'fa' ? 'دانلود' : 'Download' ?></a><?php endif; ?>
                <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && $arc1SubHref): ?>
                <a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($arc1SubHref, 21600, $isArc6 ? 'archive6' : '', false, $isArc6)) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-sub-dl-btn" title="<?= $userLang === 'fa' ? 'دانلود زیرنویس فارسی' : 'Download Persian Subtitles' ?>">
                    <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                    <?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; endforeach; ?>
        </div>
    </div>
    <?php if(!empty($arc1MovieDub)): bm_render_download_support_card($isArc6 ? 'archive6-movie' : ($isArc5 ? 'archive5-movie' : ($isArc3 ? 'archive3-movie' : ($isArc4 ? 'archive4-movie' : 'archive1-movie')))); endif; ?>
    <?php endif; ?>
    <?php if(!empty($arc1MovieSoft)): ?>
    <?php $arc1SoftCount = 0; foreach($arc1MovieSoft as $arc1SoftItems) { $arc1SoftCount += is_array($arc1SoftItems) ? count($arc1SoftItems) : 0; } ?>
    <div class="arc1-ep-card bm-movie-download-accordion is-soft-group">
        <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
            <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                <?= e($isArc3 ? 'نسخه‌های زیرنویس فارسی' : $bmArchiveSubFa) ?>
            </div>
            <div style="display:flex;align-items:center;gap:8px">
                <span class="bm-download-group-count"><?= (int)$arc1SoftCount ?> لینک</span>
                <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
            </div>
        </div>
        <div class="arc1-ep-links bm-movie-download-panel">
        <?php foreach($arc1MovieSoft as $q => $items): foreach($items as $it): ?>
        <?php $arc1SubHref = !empty($it['subtitle_url']) ? (string)$it['subtitle_url'] : ''; ?>
        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default">
            <div class="download-card-left">
                <?php $arc1MovieSubTypeLabel = bm_archive_download_type_label($it['type'] ?? '', $userLang, $bmArchiveSubFa, $bmArchiveSubEn); ?>
                <span class="download-type-badge <?= e(bm_archive_download_type_class($it['type'] ?? '')) ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h4M13 15h4"/></svg><?= e($arc1MovieSubTypeLabel) ?></span>
                <div class="link-info"><span class="quality" data-bm-quality="<?= e($q) ?>"><?= e($q) ?></span><?php if(!empty($it['size'])): ?><span class="size"><?= e($it['size']) ?></span><?php endif; ?><?= bm_v111_cam_notice((array)$it,(string)$q,(string)($it['url'] ?? ''),$userLang) ?><?php if(!empty($it['meta'])): ?><div class="bm-arc1-rich-meta"><?php foreach($it['meta'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind'] ?? 'detail') ?>" data-meta="<?= e($meta['value'] ?? '') ?>"><?php if(trim((string)($meta['label'] ?? '')) !== ''): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?></div>
            </div>
            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                <button class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?> data-url="<?= e(bm_archive_stream_url($it['url'])) ?>" <?php if($bmArchiveDownloadAllowed && empty($it['source_download_locked'])): ?>data-copy-url="<?= e(bm_dl_wrap_url($it['url'])) ?>"<?php endif; ?> data-subtitle-url="<?= e(bm_archive_stream_url($it['subtitle_url'] ?? '')) ?>" data-label="<?= e($arc1MovieSubTypeLabel . ' — ' . $q) ?>">
                    <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                    پخش
                </button>
                <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && empty($it['source_download_locked'])): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($it['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="download-icon" style="text-decoration:none"><svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><?= $userLang === 'fa' ? 'دانلود' : 'Download' ?></a><?php endif; ?>
                <?php if(($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) && $arc1SubHref): ?>
                <a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($arc1SubHref, 21600, $isArc6 ? 'archive6' : '', false, $isArc6)) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-sub-dl-btn" title="<?= $userLang === 'fa' ? 'دانلود زیرنویس فارسی' : 'Download Persian Subtitles' ?>">
                    <svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>
                    <?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; endforeach; ?>
        </div>
    </div>
    <?php if(empty($arc1MovieDub) && !empty($arc1MovieSoft)): bm_render_download_support_card($isArc6 ? 'archive6-movie' : ($isArc5 ? 'archive5-movie' : ($isArc3 ? 'archive3-movie' : ($isArc4 ? 'archive4-movie' : 'archive1-movie')))); endif; ?>
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php endif; ?>





<?php if(!empty($arc1RelatedMovies)): ?>
<section class="bm-arc1-related-section" id="bmMovieRelated">
    <div class="bm-arc1-related-head">
        <div>
            <h3>فیلم‌ها و سریال‌های مشابه</h3>
            <p>پیشنهادهای مرتبط</p>
        </div>
        <span><?= count($arc1RelatedMovies) ?> پیشنهاد</span>
    </div>
    <div class="bm-arc1-related-scroll">
        <?php foreach($arc1RelatedMovies as $rel): ?>
        <a href="<?= e($rel['bankmovie_url'] ?? $rel['url'] ?? '#') ?>" class="bm-arc1-related-card">
            <span class="bm-arc1-related-poster">
                <?php if(!empty($rel['poster'])): ?>
                <img src="<?= e($rel['poster']) ?>" alt="<?= e($rel['title']) ?>" loading="lazy">
                <?php else: ?>
                <span class="bm-arc1-related-fallback"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></span>
                <?php endif; ?>
                <?php if(!empty($rel['rating'])): ?><span class="bm-arc1-rel-imdb"><span class="bm-imdb-score"><?= e($rel['rating']) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
            </span>
            <span class="bm-arc1-related-title"><?= e($rel['title']) ?></span>
            <span class="bm-arc1-related-meta">
                <?php if(!empty($rel['year'])): ?><b><?= e($rel['year']) ?></b><?php endif; ?>
                <?= ($rel['type'] ?? '') === 'series' ? 'سریال' : 'فیلم' ?>
            </span>
            <?php if(!empty($rel['note'])): ?><span class="bm-arc1-related-note"><?= e($rel['note']) ?></span><?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<!-- بخش کامنت‌ها برای آرشیو ۱ -->
    <!-- بخش کامنت‌ها -->
    <div class="comments-section" id="bmMovieComments">
        <div class="comments-header">
            <div class="section-title" style="margin-bottom:0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $userLang === 'fa' ? e($bmCommentTitleFa) : 'User Comments' ?>
            </div>
            <div class="comments-stats">
                <div class="comment-stat">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                    <span id="totalCommentsCount"><?= number_format($totalComments) ?></span>
                </div>
                <?php if(!empty($bmCommentConfig['ratings']) && $avgRating > 0): ?><div class="comment-stat"><?= renderStars($avgRating) ?><span>(<?= number_format($avgRating, 1) ?>)</span></div><?php endif; ?>
            </div>
            <label class="bm-comment-sort-wrap">
                <span><?= $userLang === 'fa' ? 'مرتب‌سازی' : 'Sort' ?></span>
                <select class="bm-comment-sort" aria-label="Comment sort">
                    <option value="latest" <?= ($commentSort ?? 'latest')==='latest'?'selected':'' ?>><?= $userLang==='fa'?'جدیدترین':'Latest' ?></option>
                    <option value="popular" <?= ($commentSort ?? '')==='popular'?'selected':'' ?>><?= $userLang==='fa'?'محبوب‌ترین':'Popular' ?></option>
                    <option value="controversial" <?= ($commentSort ?? '')==='controversial'?'selected':'' ?>><?= $userLang==='fa'?'بحث‌برانگیزترین':'Controversial' ?></option>
                    <option value="replies" <?= ($commentSort ?? '')==='replies'?'selected':'' ?>><?= $userLang==='fa'?'بیشترین پاسخ':'Most replies' ?></option>
                    <option value="oldest" <?= ($commentSort ?? '')==='oldest'?'selected':'' ?>><?= $userLang==='fa'?'قدیمی‌ترین':'Oldest' ?></option>
                </select>
            </label>
        </div>
        
        <div class="comment-form">
            <div class="comment-form-header">
                <div class="comment-avatar">
                    <?php if($currentUser): ?>
                        <img src="<?= htmlspecialchars($bmCurrentUserAvatarUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/avatars/avatar_default.webp';" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php endif; ?>
                </div>
                <div class="comment-form-info">
                    <span class="comment-username"><?= $currentUser ? htmlspecialchars($currentUser['username']) : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest') ?></span>
                    <?php if(!empty($bmCommentConfig['ratings'])): ?><span class="comment-guest-note"><?= $userLang === 'fa' ? '(برای امتیاز دادن وارد شوید)' : '(Login to rate)' ?></span><?php endif; ?>
                </div>
            </div>
            
            <div id="commentMessage" style="display:none;" class="comment-success"></div>
            <div id="commentError" style="display:none;" class="comment-error"></div>
            
    <?php if(!empty($bmCommentConfig['spoiler'])): ?><div class="comment-toolbar" style="display: flex; justify-content: flex-end; margin-bottom: 8px;">
    <label style="display: flex; align-items: center; gap: 6px; font-size:12px;">
        <input type="checkbox" id="fullSpoilerCheckbox"> <?= $userLang === 'fa' ? 'کامنت اسپویل دار شود؟' : 'Whole comment is spoiler' ?>
    </label>
</div><?php endif; ?>
            
            <?php if(!empty($bmCommentConfig['ratings'])): ?><div class="star-rating-input"><span><?= $userLang === 'fa' ? 'امتیاز شما:' : 'Your rating:' ?></span><div class="star-rating" id="starRating"><?= renderStarInput($userRating) ?></div></div><?php endif; ?>
            <textarea id="commentText" class="comment-textarea" rows="3" placeholder="<?= $userLang === 'fa' ? e($bmCommentPlaceholderFa) : 'Write your comment...' ?>"></textarea>
            <button type="button" id="submitCommentBtn" class="comment-submit bm-comment-send-button" aria-live="polite">
                <span class="bm-send-outline" aria-hidden="true"></span>
                <span class="bm-send-state bm-send-default"><span class="bm-send-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4Z"/></svg></span><span class="bm-send-letters" aria-hidden="true"><?php foreach(($userLang === 'fa' ? ['ا','ر','س','ا','ل'] : ['S','e','n','d']) as $i=>$ch): ?><span style="--i:<?=$i?>"><?=e($ch)?></span><?php endforeach; ?></span><span class="bm-sr-only"><?= $userLang === 'fa' ? 'ارسال' : 'Send' ?></span></span>
                <span class="bm-send-state bm-send-sent"><span class="bm-send-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="m5 12 4 4L19 6"/></svg></span><span class="bm-send-letters" aria-hidden="true"><?php foreach(($userLang === 'fa' ? ['ا','ر','س','ا','ل',' ','ش','د'] : ['S','e','n','t']) as $i=>$ch): ?><span style="--i:<?=$i?>"><?= $ch === ' ' ? '&nbsp;' : e($ch) ?></span><?php endforeach; ?></span><span class="bm-sr-only"><?= $userLang === 'fa' ? 'ارسال شد' : 'Sent' ?></span></span>
            </button>
        </div>
        
        <div class="comment-list" id="commentList">
            <?php if(count($comments) > 0): ?>
                <?php foreach($comments as $comment): ?>
                    <?= renderCommentHTML($comment, $userLang, $currentUser['id'] ?? 0, $isArc1) ?>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-comments" id="emptyComments"><?= $userLang === 'fa' ? e($bmCommentEmptyFa) : 'No comments yet. Be the first to comment!' ?></div>
            <?php endif; ?>
        </div>
        
        <?php if($totalCommentPages > 1): ?>
        <div class="load-more-comments" id="loadMoreCommentsBtn">
            <button class="btn-outline" style="width:100%; padding:12px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
                <?= $userLang === 'fa' ? 'بارگذاری بیشتر' : 'Load More' ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
        </div>
        <?php endif; ?>
    </div>


<?php endif; /* arc1Data */ ?>
<?php else: ?>
<!-- ====== آرشیو ۲ — دیتابیس محلی ====== -->
<link rel="stylesheet" href="/assets/css/movie-inline-4.css?v=dl36">
<link rel="stylesheet" href="/assets/css/bm-smooth-accordions-v158.css?v=158.0">
<link rel="stylesheet" href="/assets/css/movie-cinematic-v125-mobiletabs-off.css?v=125-mobiletabs-off-1">
<link rel="stylesheet" href="/assets/css/bm-mobile-latest-episode-premium-v30.css?v=30.0">
<link rel="stylesheet" href="/assets/css/bm-mobile-movie-polish-v35.css?v=35.0">
<link rel="stylesheet" href="/assets/css/bm-movie-detail-hotfix-v272.css?v=272.0">
<link rel="stylesheet" href="/assets/css/bm-local-movie-api-parity-v236.css?v=236.0">
    <?php
    $bmArc2PosterRel = 'posters/' . preg_replace('/[^A-Za-z0-9_-]/', '', (string)$movieData['imdb_code']) . '.webp';
    $bmArc2PosterFile = __DIR__ . '/' . $bmArc2PosterRel;
    $bmArc2PosterVer = is_file($bmArc2PosterFile) ? (string)(@filemtime($bmArc2PosterFile) ?: '') : '';
    $bmArc2PosterUrl = '/' . $bmArc2PosterRel . ($bmArc2PosterVer !== '' ? ('?v=' . rawurlencode($bmArc2PosterVer)) : '');
    $bmLocalPrimaryTitle = trim((string)($movieData['title_fa'] ?: $movieData['title']));
    $bmLocalSecondaryTitle = trim((string)($movieData['title'] ?? ''));
    $bmLocalShowSecondaryTitle = $bmLocalSecondaryTitle !== '' && strcasecmp($bmLocalSecondaryTitle, $bmLocalPrimaryTitle) !== 0;
    ?>
    <div class="movie-detail bm-hero-poster-fallback" style="--bg-image:url('<?= e($bmArc2PosterUrl) ?>');--bm-poster-image:url('<?= e($bmArc2PosterUrl) ?>');">
        <div class="poster-col">
            <img src="<?= e($bmArc2PosterUrl) ?>" loading="eager" decoding="async" fetchpriority="high" width="240" height="360" onerror="this.onerror=null;this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 200 300\'%3E%3Crect width=\'200\' height=\'300\' fill=\'%2318181d\'/%3E%3Ctext x=\'100\' y=\'150\' fill=\'%236e6e7a\' text-anchor=\'middle\' font-size=\'14\'%3ENo Poster%3C/text%3E%3C/svg%3E'" alt="<?= htmlspecialchars($movieData['title']) ?>">
            <?php if($bmArc2HasDubDisplay || $bmArc2HasSoftDisplay): ?>
            <div class="bm-poster-badges" aria-label="ویژگی‌های نسخه">
                <?php if($bmArc2HasDubDisplay): ?>
                <span class="bm-poster-badge bm-badge-dub" title="دوبله فارسی">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a4 4 0 0 0-4 4v6a4 4 0 0 0 8 0V6a4 4 0 0 0-4-4z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3M8 22h8"/></svg>
                    <span>دوبله</span>
                </span>
                <?php endif; ?>
                <?php if($bmArc2HasSoftDisplay): ?>
                <span class="bm-poster-badge bm-badge-cc" title="<?= e($bmArchiveSubFa) ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2M16 10h-2a2 2 0 0 0 0 4h2"/></svg>
                    <span><?= e($bmArchiveSubFa) ?></span>
                </span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <?php if($isMovie && !empty($arc2MovieFirstPlay['url'])): ?>
            <button type="button" class="bm-poster-play bm-local-play-choice"<?= $bmArchiveStreamGateAttrs ?> aria-label="<?= $userLang === 'fa' ? 'پخش آنلاین' : 'Watch Online' ?>"
                data-url="<?= e(bm_archive_stream_url($arc2MovieFirstPlay['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc2MovieFirstPlay['url'])) ?>"<?php endif; ?>
                data-label="<?= e($arc2MovieFirstPlay['label']) ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </button>
            <?php elseif(!$isMovie && !empty($arc2LatestPlay['url'])): ?>
            <button type="button" class="bm-poster-play bm-local-play-choice"<?= $bmArchiveStreamGateAttrs ?> aria-label="<?= $userLang === 'fa' ? 'پخش آنلاین' : 'Watch Online' ?>"
                data-url="<?= e(bm_archive_stream_url($arc2LatestPlay['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc2LatestPlay['url'])) ?>"<?php endif; ?>
                data-season="<?= e($arc2LatestPlay['season']) ?>"
                data-episode="<?= e($arc2LatestPlay['episode']) ?>"
                data-label="<?= e($arc2LatestPlay['label']) ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </button>
            <?php elseif(!$isMovie): ?>
            <a href="#downloadSection" class="bm-poster-play"<?= $bmArchiveStreamGateAttrs ?> aria-label="<?= ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) ? ($userLang === 'fa' ? 'رفتن به باکس دانلود' : 'Go to download box') : ($userLang === 'fa' ? 'رفتن به نسخه‌های پخش' : 'Go to playback versions') ?>">
                <svg class="bm-poster-play-svg" viewBox="0 0 191.255 191.255" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M162.929,66.612c-2.814-1.754-6.514-0.896-8.267,1.917s-0.895,6.513,1.917,8.266c6.544,4.081,10.45,11.121,10.45,18.833s-3.906,14.752-10.45,18.833l-98.417,61.365c-6.943,4.329-15.359,4.542-22.512,0.573c-7.154-3.97-11.425-11.225-11.425-19.406V34.262c0-8.181,4.271-15.436,11.425-19.406c7.153-3.969,15.569-3.756,22.512,0.573l57.292,35.723c2.813,1.752,6.513,0.895,8.267-1.917c1.753-2.812,0.895-6.513-1.917-8.266L64.512,5.247c-10.696-6.669-23.661-7-34.685-0.883C18.806,10.48,12.226,21.657,12.226,34.262v122.73c0,12.605,6.58,23.782,17.602,29.898c5.25,2.913,10.939,4.364,16.616,4.364c6.241,0,12.467-1.754,18.068-5.247l98.417-61.365c10.082-6.287,16.101-17.133,16.101-29.015S173.011,72.899,162.929,66.612z"/></svg>
            </a>
            <?php endif; ?>
        </div>
        <div class="info-col">
            <h1 class="movie-title-fa"><?= htmlspecialchars($bmLocalPrimaryTitle) ?></h1>
            <?php if($bmLocalShowSecondaryTitle): ?><div class="movie-title-en"><?= htmlspecialchars($bmLocalSecondaryTitle) ?></div><?php endif; ?>
            <div class="movie-rating-section bm-local-rating-section">
                <?php if(isset($movieData['imdb_rate']) && (float)$movieData['imdb_rate'] > 0): ?>
                <div class="bm-imdb-pill">
                    <span class="bm-imdb-score"><?= number_format((float)$movieData['imdb_rate'], 1) ?></span>
                    <img src="/assets/brand/imdb-logo.svg" alt="IMDb" class="bm-imdb-logo" loading="lazy">
                </div>
                <?php endif; ?>
                <?php if((int)$totalVotes > 0): ?>
                <div class="user-rating bm-local-user-rating"><div class="stars"><?= renderStars($avgRating) ?></div><span>(<?= number_format($avgRating, 1) ?>/5 · <?= number_format($totalVotes) ?> <?= $userLang === 'fa' ? 'رای' : 'votes' ?>)</span></div>
                <?php endif; ?>
            </div>
            <div class="movie-info-block" id="bmMovieMoreInfo">
                <div class="movie-info-title"><?= $userLang === 'fa' ? 'مشخصات' : 'Details' ?></div>
                <div class="movie-meta-grid">
                    <div class="meta-item" data-meta="type"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'نوع:' : 'Type:' ?></span> <span class="value"><?= $isMovie ? ($userLang === 'fa' ? 'فیلم سینمایی' : 'Movie') : ($userLang === 'fa' ? 'سریال' : 'Series') ?></span></div>
                    <?php if(!empty($movieData['year'])): ?>
                    <div class="meta-item" data-meta="year"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg><span class="label"><?= $userLang === 'fa' ? 'سال:' : 'Year:' ?></span><span class="value"><?= htmlspecialchars($movieData['year']) ?></span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['genres'])): ?>
                    <div class="meta-item" data-meta="genres"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><span class="label"><?= $userLang === 'fa' ? 'ژانر:' : 'Genre:' ?></span><span class="value genre-links"><?php $genresArray = explode(', ', $movieData['genres']); foreach($genresArray as $genre) echo '<a href="/search?genre='.urlencode(trim($genre)).'" class="genre-link">'.htmlspecialchars(trim($genre)).'</a> '; ?></span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['director'])): ?>
                    <div class="meta-item" data-meta="director"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg><span class="label"><?= $userLang === 'fa' ? 'کارگردان:' : 'Director:' ?></span><span class="value"><a href="/search?director=<?= urlencode($movieData['director']) ?>" class="director-link"><?= htmlspecialchars($movieData['director']) ?></a></span></div>
                    <?php endif; ?>
                    <?php if(!empty($movieData['country'])): ?>
                    <div class="meta-item" data-meta="country"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M8.56 3.34v14.33c-.34.01-.68.09-.93.24l-2.35 1.34c-1.64.94-2.99.16-2.99-1.74V7.78c0-.63.45-1.41 1.01-1.73l4.33-2.48c.25-.14.59-.22.93-.23Z"/><path d="M15.729 6.33v14.33c-.35.01-.69-.05-.96-.18l-5.25-2.63c-.27-.13-.61-.19-.96-.18V3.34c.35-.01.69.05.96.18l5.25 2.63c.27.13.61.19.96.18Z"/><path opacity=".4" d="M22 6.49v9.73c0 .63-.45 1.41-1.01 1.73l-4.33 2.48c-.25.14-.59.22-.93.23V6.33c.34-.01.68-.09.93-.24l2.35-1.34C20.65 3.81 22 4.59 22 6.49Z"/></svg><span class="label"><?= $userLang === 'fa' ? 'کشور:' : 'Country:' ?></span><span class="value"><a href="/search?country=<?= urlencode($movieData['country']) ?>" class="country-link"><?= htmlspecialchars($movieData['country']) ?></a></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['status'])): ?>
                    <div class="meta-item" data-meta="status"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M16.75 3.56V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.5h-6.5V2c0-.41-.34-.75-.75-.75s-.75.34-.75.75v1.56c-2.7.25-4.01 1.86-4.21 4.25-.02.29.22.53.5.53h16.92c.29 0 .53-.25.5-.53-.2-2.39-1.51-4-4.21-4.25Z"/><path opacity=".4" d="M20 9.84c.55 0 1 .45 1 1V17c0 3-1.5 5-5 5H8c-3.5 0-5-2-5-5v-6.16c0-.55.45-1 1-1h16Z"/><path d="M8.5 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.09-.1-.16-.21-.21-.33a.995.995 0 0 1-.08-.38c0-.13.03-.26.08-.38s.12-.23.21-.33c.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.09.1.16.21.21.33.05.12.08.25.08.38s-.03.26-.08.38-.12.23-.21.33c-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM12 14.999c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21.24-.11.52-.11.76 0 .12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08ZM8.5 18.499c-.13 0-.26-.03-.38-.08s-.23-.12-.33-.21c-.18-.19-.29-.45-.29-.71 0-.26.11-.52.29-.71.1-.09.21-.16.33-.21a1 1 0 0 1 .76 0c.12.05.23.12.33.21.18.19.29.45.29.71 0 .26-.11.52-.29.71-.1.09-.21.16-.33.21-.12.05-.25.08-.38.08Z"/></svg><span class="label"><?= $userLang === 'fa' ? 'وضعیت:' : 'Status:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['status']) ?></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['rated'])): ?>
                    <div class="meta-item" data-meta="rated"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path opacity=".4" d="M9 2C6.38 2 4.25 4.13 4.25 6.75c0 2.57 2.01 4.65 4.63 4.74.08-.01.16-.01.22 0h.07a4.738 4.738 0 0 0 4.58-4.74C13.75 4.13 11.62 2 9 2Z"/><path d="M14.08 14.149c-2.79-1.86-7.34-1.86-10.15 0-1.27.85-1.97 2-1.97 3.23s.7 2.37 1.96 3.21c1.4.94 3.24 1.41 5.08 1.41 1.84 0 3.68-.47 5.08-1.41 1.26-.85 1.96-1.99 1.96-3.23-.01-1.23-.7-2.37-1.96-3.21Z"/><path opacity=".4" d="M19.99 7.338c.16 1.94-1.22 3.64-3.13 3.87h-.05c-.06 0-.12 0-.17.02-.97.05-1.86-.26-2.53-.83 1.03-.92 1.62-2.3 1.5-3.8a4.64 4.64 0 0 0-.77-2.18 3.592 3.592 0 0 1 5.15 2.92Z"/><path d="M21.988 16.59c-.08.97-.7 1.81-1.74 2.38-1 .55-2.26.81-3.51.78.72-.65 1.14-1.46 1.22-2.32.1-1.24-.49-2.43-1.67-3.38-.67-.53-1.45-.95-2.3-1.26 2.21-.64 4.99-.21 6.7 1.17.92.74 1.39 1.67 1.3 2.63Z"/></svg><span class="label"><?= $userLang === 'fa' ? 'رده سنی:' : 'Rated:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['rated']) ?></span></div>
                    <?php endif; ?>
                    <?php if($extraInfo && !empty($extraInfo['language'])): ?>
                    <div class="meta-item" data-meta="language"><svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true" class="bm-source-meta-icon" fill="currentColor" style="stroke:none!important;fill:currentColor!important"><path d="M5.15 22c-.41 0-.75-.34-.75-.75V2.75c0-.41.34-.75.75-.75s.75.34.75.75v18.5c0 .41-.34.75-.75.75Z"/><path opacity=".4" d="m18.02 12.33-1.22-1.22a1.39 1.39 0 0 1-.47-1.03c-.02-.45.16-.9.49-1.23l1.2-1.2c1.04-1.04 1.43-2.04 1.1-2.83-.32-.78-1.31-1.21-2.77-1.21H5.15c-.21.01-.38.18-.38.39v12c0 .21.17.38.38.38h11.2c1.44 0 2.41-.44 2.74-1.23.33-.8-.05-1.79-1.07-2.82Z"/></svg><span class="label"><?= $userLang === 'fa' ? 'زبان:' : 'Language:' ?></span><span class="value"><?= htmlspecialchars($extraInfo['language']) ?></span></div>
                    <?php endif; ?>
                    <?php if(!$isMovie && $extraInfo && !empty($extraInfo['seasons'])): ?>
                    <div class="meta-item" data-meta="seasons"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'فصل‌ها:' : 'Seasons:' ?></span><span class="value"><?= $extraInfo['seasons'] ?></span></div>
                    <?php endif; ?>
                    <?php if(!$isMovie && $extraInfo && !empty($extraInfo['episodes'])): ?>
                    <div class="meta-item" data-meta="episodes"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M9 8h6M9 12h6"/></svg><span class="label"><?= $userLang === 'fa' ? 'قسمت‌ها:' : 'Episodes:' ?></span><span class="value"><?= $extraInfo['episodes'] ?></span></div>
                    <?php endif; ?>
                </div>
            </div>
            <?php if(!empty($releaseUpdateSummary)): ?>
            <aside class="bm-release-status" aria-label="<?= $userLang === 'fa' ? 'آخرین بروزرسانی' : 'Latest update' ?>">
                <span class="bm-release-status-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6v6h-6"/><path d="M20 12a8 8 0 1 0-2.34 5.66"/></svg></span>
                <div><small><?= $userLang === 'fa' ? 'آخرین بروزرسانی' : 'Latest update' ?></small><strong><?= htmlspecialchars($releaseUpdateSummary) ?></strong></div>
            </aside>
            <?php endif; ?>
            <?php if(!empty($movieData['description'])): ?>
            <section class="description bm-readmore-desc bm-story-summary" data-collapsed="1">
                <div class="bm-story-summary-head"><span><?= $userLang === 'fa' ? 'خلاصه داستان' : 'Story' ?></span></div>
                <div class="bm-readmore-content"><?= nl2br(htmlspecialchars(trim((string)$movieData['description']))) ?></div>
                <button type="button" class="bm-readmore-btn" data-readmore-toggle><?= $userLang === 'fa' ? 'ادامه داستان' : 'Read more' ?></button>
            </section>
            <?php endif; ?>
            <?php if(!empty($movieData['actors'])): ?>
            <section class="bm-arc1-actors-section bm-local-api-actors-section">
                <?php $actorsArray = array_values(array_filter(array_map('trim', preg_split('/\s*,\s*/u', (string)$movieData['actors'])))); ?>
                <div class="bm-arc1-section-head">
                    <div class="bm-arc1-section-title">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                        <span><?= $userLang === 'fa' ? 'بازیگران و صداپیشگان' : 'Cast & Voice Actors' ?></span>
                    </div>
                    <span class="bm-arc1-section-count"><?= count($actorsArray) ?> <?= $userLang === 'fa' ? 'نفر' : 'people' ?></span>
                </div>
                <div class="bm-arc1-actors-list" data-actors-list>
                    <?php foreach($actorsArray as $actorIndex => $actorTrim): ?>
                    <a href="/search?actor=<?= urlencode($actorTrim) ?>" class="bm-arc1-actor-card is-text-only <?= $actorIndex >= 6 ? 'bm-actor-hidden' : '' ?>" title="<?= htmlspecialchars($actorTrim) ?>">
                        <span class="bm-arc1-actor-text-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="3.5"/><path d="M5.5 20c.5-4.05 2.7-6.1 6.5-6.1s6 2.05 6.5 6.1" stroke-linecap="round"/></svg></span>
                        <span class="bm-arc1-actor-name"><?= htmlspecialchars($actorTrim) ?></span>
                        <span class="bm-actor-detail-pill"><svg viewBox="0 0 24 24"><circle cx="12" cy="8" r="3"/><path d="M6 20c.4-3.5 2.4-5.2 6-5.2s5.6 1.7 6 5.2" stroke-linecap="round"/></svg><?= $userLang === 'fa' ? 'مشاهده جزئیات' : 'View details' ?></span>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php if(count($actorsArray) > 6): ?>
                <button type="button" class="bm-actors-show-all" data-actors-toggle><?= $userLang === 'fa' ? 'مشاهده همه بازیگران' : 'View all cast' ?></button>
                <?php endif; ?>
            </section>
            <?php endif; ?>
            <!-- Archive 2 actions now intentionally use the exact Archive 1 markup/class rhythm. -->
            <div class="action-buttons <?= $isMovie ? 'bm-actions-movie' : 'bm-actions-series' ?> <?= (!$isMovie && (!empty($arc2LatestPlay['url']) || !empty($seriesSeasons))) ? 'has-primary-latest' : '' ?>" style="display:flex;flex-wrap:wrap;gap:10px;margin-top:16px">
                <?php if(!$isMovie && !empty($arc2LatestPlay['url'])): ?>
                <a href="#playerWrapper" class="btn btn-primary hero-primary-action bm-safe-series-cta bm-local-play-choice"<?= $bmArchiveStreamGateAttrs ?>
                    data-url="<?= e(bm_archive_stream_url($arc2LatestPlay['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($arc2LatestPlay['url'])) ?>"<?php endif; ?>
                    data-season="<?= e($arc2LatestPlay['season']) ?>"
                    data-episode="<?= e($arc2LatestPlay['episode']) ?>"
                    data-label="<?= e($arc2LatestPlay['label']) ?>">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <?= $userLang === 'fa' ? 'پخش آخرین قسمت' : 'Play latest episode' ?>
                </a>
                <?php elseif(!$isMovie && !empty($seriesSeasons)): ?>
                <a href="#downloadSection" class="btn btn-primary hero-primary-action bm-safe-series-cta">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
                    <?= $userLang === 'fa' ? 'پخش آخرین قسمت' : 'Play latest episode' ?>
                </a>
                <?php endif; ?>
                                <button type="button" class="arc1-wl-btn bm-watchlist-action <?= $inWatchlist ? 'active' : '' ?>" id="watchlistBtn" aria-pressed="<?= $inWatchlist ? 'true' : 'false' ?>">
                    <svg class="bm-bookmark-icon" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><?php if($inWatchlist): ?><path opacity="0.4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M12.0007 10.2801C10.9807 10.2801 9.96074 10.1001 8.99074 9.75005C8.60074 9.61005 8.40074 9.18005 8.54074 8.79005C8.69074 8.40005 9.12074 8.20005 9.51074 8.34005C11.1207 8.92005 12.8907 8.92005 14.5007 8.34005C14.8907 8.20005 15.3207 8.40005 15.4607 8.79005C15.6007 9.18005 15.4007 9.61005 15.0107 9.75005C14.0407 10.1001 13.0207 10.2801 12.0007 10.2801Z" fill="currentColor"/><?php else: ?><path opacity="0.4" d="M16.8203 2H7.18031C5.05031 2 3.32031 3.74 3.32031 5.86V19.95C3.32031 21.75 4.61031 22.51 6.19031 21.64L11.0703 18.93C11.5903 18.64 12.4303 18.64 12.9403 18.93L17.8203 21.64C19.4003 22.52 20.6903 21.76 20.6903 19.95V5.86C20.6803 3.74 18.9503 2 16.8203 2Z" fill="currentColor"/><path d="M14.5 9.89996H12.75V8.20996C12.75 7.79996 12.41 7.45996 12 7.45996C11.59 7.45996 11.25 7.79996 11.25 8.20996V9.89996H9.5C9.09 9.89996 8.75 10.24 8.75 10.65C8.75 11.06 9.09 11.4 9.5 11.4H11.25V13.21C11.25 13.62 11.59 13.96 12 13.96C12.41 13.96 12.75 13.62 12.75 13.21V11.4H14.5C14.91 11.4 15.25 11.06 15.25 10.65C15.25 10.24 14.91 9.89996 14.5 9.89996Z" fill="currentColor"/><?php endif; ?></svg>
                    <span class="bm-watchlist-label"><?= $inWatchlist ? ($userLang === 'fa' ? 'حذف از علاقه‌مندی' : 'Remove favorite') : ($userLang === 'fa' ? 'افزودن به علاقه‌مندی' : 'Add to favorites') ?></span>
                </button>
                <button type="button" class="btn btn-outline bm-share-trigger bm-share-open bm-share-action" id="shareBtn">
                    <svg class="bm-share-network-icon" width="19" height="19" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g opacity="0.5"><path d="M7.20468 7.56232C7.51523 7.28822 7.54478 6.81427 7.27069 6.50371C6.99659 6.19316 6.52264 6.1636 6.21208 6.4377C4.39676 8.03992 3.25 10.3865 3.25 13C3.25 13.4142 3.58579 13.75 4 13.75C4.41421 13.75 4.75 13.4142 4.75 13C4.75 10.8347 5.69828 8.89188 7.20468 7.56232Z" fill="currentColor"/><path d="M17.7879 6.4377C17.4774 6.1636 17.0034 6.19316 16.7293 6.50371C16.4552 6.81427 16.4848 7.28822 16.7953 7.56232C18.3017 8.89188 19.25 10.8347 19.25 13C19.25 13.4142 19.5858 13.75 20 13.75C20.4142 13.75 20.75 13.4142 20.75 13C20.75 10.3865 19.6032 8.03992 17.7879 6.4377Z" fill="currentColor"/><path d="M10.1869 20.0217C9.7858 19.9184 9.37692 20.1599 9.27367 20.5611C9.17043 20.9622 9.41192 21.3711 9.81306 21.4743C10.5129 21.6544 11.2458 21.75 12 21.75C12.7542 21.75 13.4871 21.6544 14.1869 21.4743C14.5881 21.3711 14.8296 20.9622 14.7263 20.5611C14.6231 20.1599 14.2142 19.9184 13.8131 20.0217C13.2344 20.1706 12.627 20.25 12 20.25C11.373 20.25 10.7656 20.1706 10.1869 20.0217Z" fill="currentColor"/></g><path d="M9 6C9 7.65685 10.3431 9 12 9C13.6569 9 15 7.65685 15 6C15 4.34315 13.6569 3 12 3C10.3431 3 9 4.34315 9 6Z" fill="currentColor"/><path d="M2.5 18C2.5 19.6569 3.84315 21 5.5 21C7.15685 21 8.5 19.6569 8.5 18C8.5 16.3431 7.15685 15 5.5 15C3.84315 15 2.5 16.3431 2.5 18Z" fill="currentColor"/><path d="M18.5 21C16.8431 21 15.5 19.6569 15.5 18C15.5 16.3431 16.8431 15 18.5 15C20.1569 15 21.5 16.3431 21.5 18C21.5 19.6569 20.1569 21 18.5 21Z" fill="currentColor"/></svg><span><?= $userLang === 'fa' ? 'اشتراک گذاری' : 'Share' ?></span>
                </button>
            </div>
        </div>
    </div>

<?php if($bmMovieCinematicTabs): ?>
<nav class="bm-cinematic-tabs" aria-label="دسترسی سریع صفحه فیلم">
    <?php if($bmArchiveDownloadAllowed || $bmArchiveStreamAllowed || $bmArchiveDownloadVipLocked || $bmArchiveStreamVipLocked): ?><a href="#downloadSection" class="is-active"><svg class="bm-tab-icon bm-tab-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><span><?= ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) ? 'دانلود باکس' : 'پخش آنلاین' ?></span></a><?php endif; ?>
    <a href="#bmMovieMoreInfo"><svg class="bm-tab-icon bm-tab-icon-more" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path opacity="0.4" d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" fill="currentColor"/><path d="M12 13.75C12.41 13.75 12.75 13.41 12.75 13V8C12.75 7.59 12.41 7.25 12 7.25C11.59 7.25 11.25 7.59 11.25 8V13C11.25 13.41 11.59 13.75 12 13.75Z" fill="currentColor"/><path d="M12.92 15.6199C12.87 15.4999 12.8 15.3899 12.71 15.2899C12.61 15.1999 12.5 15.1299 12.38 15.0799C12.14 14.9799 11.86 14.9799 11.62 15.0799C11.5 15.1299 11.39 15.1999 11.29 15.2899C11.2 15.3899 11.13 15.4999 11.08 15.6199C11.03 15.7399 11 15.8699 11 15.9999C11 16.1299 11.03 16.2599 11.08 16.3799C11.13 16.5099 11.2 16.6099 11.29 16.7099C11.39 16.7999 11.5 16.8699 11.62 16.9199C11.74 16.9699 11.87 16.9999 12 16.9999C12.13 16.9999 12.26 16.9699 12.38 16.9199C12.5 16.8699 12.61 16.7999 12.71 16.7099C12.8 16.6099 12.87 16.5099 12.92 16.3799C12.97 16.2599 13 16.1299 13 15.9999C13 15.8699 12.97 15.7399 12.92 15.6199Z" fill="currentColor"/></svg><span>اطلاعات بیشتر</span></a>
    <a href="#bmMovieComments"><svg class="bm-tab-icon bm-tab-icon-comments" viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><g fill="currentColor"><path d="M92.574,294.24V124.336H43.277C19.449,124.336,0,144.213,0,168.467v206.44c0,24.254,19.449,44.133,43.277,44.133h62v45.469c0,3.041,1.824,5.777,4.559,6.932c2.736,1.154,5.957,0.486,8.023-1.641l49.844-50.76h106.494c23.828,0,43.279-19.879,43.279-44.133v-0.061H172.262C128.314,374.846,92.574,338.676,92.574,294.24z"/><path d="M462.717,40H172.26c-27.105,0-49.283,22.59-49.283,50.197v204.037c0,27.61,22.178,50.199,49.283,50.199h164.668l75.348,76.033c2.399,2.442,6.004,3.172,9.135,1.852c3.133-1.322,5.176-4.434,5.176-7.887v-69.998h36.131c27.106,0,49.283-22.59,49.283-50.199V90.197C512,62.59,489.822,40,462.717,40z M369.156,280.115H195.92v-24.316h173.236V280.115z M439.058,204.129H195.92v-24.314h243.138V204.129z M439.058,128.143H195.92v-24.315h243.138V128.143z"/></g></svg><span>نظرات</span></a>
    <a href="#bmMovieRelated"><svg class="bm-tab-icon bm-tab-icon-related" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M18.4834 16.7674C17.8471 16.9195 17.1829 17 16.5 17C11.8056 17 8 13.1944 8 8.50001C8 8.01653 8.04036 7.54249 8.11791 7.08105C8.08172 7.11586 8.04432 7.14792 8.00494 7.17781C7.72433 7.39083 7.37485 7.46991 6.67589 7.62806L6.03954 7.77204C3.57986 8.32856 2.35002 8.60682 2.05742 9.54774C1.76482 10.4887 2.60325 11.4691 4.2801 13.4299L4.71392 13.9372C5.19042 14.4944 5.42868 14.773 5.53586 15.1177C5.64305 15.4624 5.60703 15.8341 5.53498 16.5776L5.4694 17.2544C5.21588 19.8706 5.08912 21.1787 5.85515 21.7602C6.62117 22.3417 7.77267 21.8116 10.0757 20.7512L10.6715 20.4768C11.3259 20.1755 11.6531 20.0249 12 20.0249C12.3469 20.0249 12.6741 20.1755 13.3285 20.4768L13.9243 20.7512C16.2273 21.8116 17.3788 22.3417 18.1449 21.7602C18.9109 21.1787 18.7841 19.8706 18.5306 17.2544L18.4834 16.7674Z" fill="currentColor"/><path opacity="0.5" d="M9.15302 5.40838L8.82532 5.99623C8.46538 6.64194 8.28541 6.96479 8.0048 7.17781C8.04418 7.14791 8.08158 7.11586 8.11777 7.08105C8.04022 7.54249 7.99986 8.01653 7.99986 8.50001C7.99986 13.1944 11.8054 17 16.4999 17C17.1828 17 17.8469 16.9195 18.4833 16.7674L18.4649 16.5776C18.3928 15.8341 18.3568 15.4624 18.464 15.1177C18.5712 14.773 18.8094 14.4944 19.2859 13.9372L19.7198 13.4299C21.3966 11.4691 22.235 10.4886 21.9424 9.54773C21.6498 8.60682 20.42 8.32856 17.9603 7.77203L17.324 7.62805C16.625 7.4699 16.2755 7.39083 15.9949 7.17781C15.7143 6.96479 15.5343 6.64194 15.1744 5.99624L14.8467 5.40837C13.58 3.13612 12.9467 2 11.9999 2C11.053 2 10.4197 3.13613 9.15302 5.40838Z" fill="currentColor"/></svg><span>پیشنهادها</span></a>
</nav>
<?php endif; ?>

    <?php $bmYkMovie = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('movie_page', 'wide') : ''; ?>
<?= $bmYkMovie !== '' ? $bmYkMovie : (function_exists('bm_render_ad_with_support_card') ? bm_render_ad_with_support_card($pdo, 'movie_page', 'wide', 1, 'movie.php') : bm_render_ad_slot($pdo, 'movie_page', 'wide', 1)) ?>

    <?php if(($isMovie && ($hasDub || $hasSoft)) || (!$isMovie && !empty($arc2LatestPlay['url']))): ?>
    <div class="player-side-actions">

            <button class="player-donate-side" id="playerDonateSideBtn" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><?= $t[$userLang]['donate'] ?></button>
</div>
    <div class="player-wrapper" id="playerWrapper" style="display:none;">
        <video id="videoPlayer" class="player-video" playsinline controlslist="nodownload noremoteplayback" disableremoteplayback disablepictureinpicture draggable="false" oncontextmenu="return false"></video>
        <div class="subtitle-overlay" id="subtitleOverlay"></div>
        <div class="brightness-hud" id="brightnessHud"><div><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></div><div class="hud-value" id="brightnessHudValue">100%</div></div>
        <div class="player-toast-stack" id="playerToastStack" aria-live="polite"></div>
        <div class="player-hud" id="playerHud" aria-hidden="true"><div class="player-hud-icon" id="playerHudIcon">•</div><div class="player-hud-title" id="playerHudTitle"></div><div class="player-hud-value" id="playerHudValue"></div><div class="player-hud-bar"><span id="playerHudBar"></span></div></div>
        <div class="unlock-overlay" id="unlockOverlay"><button type="button" class="unlock-pill" id="unlockOverlayBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2.3"/></svg><span><?= $userLang === 'fa' ? 'باز کردن قفل' : 'Unlock controls' ?></span></button></div>
        <div class="buffering" id="bufferingIndicator"></div>
        <div class="player-controls" id="playerControls">
            <div class="progress-container">
                <span class="progress-time" id="currentTimeDisplay">00:00</span>
                <input type="range" id="progressBar" class="progress-bar" min="0" max="100" value="0">
                <span class="progress-time" id="durationDisplay">00:00</span>
            </div>
            <div class="controls-row">
                <div class="controls-left">
                    <button class="ctrl-btn" id="playPauseBtn" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
                    <button class="ctrl-btn" id="seekBack10Btn" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="10 9 6 12 10 15"/><polyline points="18 9 14 12 18 15"/></svg><span style="font-size:12px;">10</span></button>
                    <button class="ctrl-btn" id="seekForward10Btn" data-bm-legacy-hidden="1" hidden aria-hidden="true" tabindex="-1" style="display:none!important"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="14 9 18 12 14 15"/><polyline points="6 9 10 12 6 15"/></svg><span style="font-size:12px;">10</span></button>
                    <div class="volume-control">
                        <button class="ctrl-btn bm-sound-toggle" id="volumeBtn" type="button" aria-label="قطع یا وصل صدا" aria-pressed="false"><span class="bm-sound-speaker" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="M39.389 13.769 22.235 28.606H6v19.093h15.989l17.4 15.051V13.769Z"/><path d="M48 27.6a19.5 19.5 0 0 1 0 21.4M55.1 20.5a30 30 0 0 1 0 35.6M61.6 14a38.8 38.8 0 0 1 0 48.6" class="bm-sound-waves"/></svg></span><span class="bm-sound-muted" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="m39 14-17 15H6v19h16l17 15Z"/><path d="m49 26 20 24m0-24-20 24" class="bm-sound-x"/></svg></span></button>
                        <input type="range" id="volumeSlider" class="volume-slider" min="0" max="100" value="100">
                    </div>
                </div>
                <div class="controls-right">
                    <button type="button" class="ctrl-btn bm-subtitle-direct-btn" id="subtitleDirectBtn" title="<?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitles' ?>" aria-label="<?= $userLang === 'fa' ? 'باز کردن تنظیمات زیرنویس' : 'Open subtitle settings' ?>" aria-expanded="false" aria-pressed="false"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" aria-hidden="true"><path d="M2 12C2 15.7712 2 17.6569 3.17157 18.8284C4.34315 20 6.22876 20 10 20H14C17.7712 20 19.6569 20 20.8284 18.8284C22 17.6569 22 15.7712 22 12C22 8.22876 22 6.34315 20.8284 5.17157C19.6569 4 17.7712 4 14 4H10C6.22876 4 4.34315 4 3.17157 5.17157C2.51839 5.82475 2.22937 6.69989 2.10149 8"/><path d="M10 16H6M14 13H18M14 16H12.5M9.5 13H11.5M18 16H16.5M6 13H7"/></svg></button>
                    <div class="settings-dropdown">
                        <button class="ctrl-btn" id="settingsBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                        <div class="settings-dropdown-content player-settings-modal" id="settingsDropdown" dir="<?= e($dir) ?>">
                            <div class="settings-panel settings-main-panel active" data-settings-panel="main">
                                <div class="settings-modal-header">
                                    <div class="settings-modal-title">
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                        <div>
                                            <div><?= $userLang === 'fa' ? 'تنظیمات پخش' : 'Playback settings' ?></div>
                                            <div class="settings-modal-subtitle"><?= $userLang === 'fa' ? 'کیفیت، سرعت، تصویر، زیرنویس و تایمر خواب' : 'Quality, speed, picture, subtitle and sleep timer' ?></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="openQualityPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M8 13h8M8 9h8"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'انتخاب کیفیت و نوع دوبله/زیرنویس' : 'Choose quality and audio/subtitle type' ?></span></span></span>
                                        <span class="settings-row-value" id="currentQualityLabel"><?= $userLang === 'fa' ? 'خودکار' : 'Auto' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <button type="button" class="settings-row" id="openSpeedPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'مودال اختصاصی قابل اسکرول' : 'Scrollable dedicated panel' ?></span></span></span>
                                        <span class="settings-row-value" id="currentSpeedLabel">1x</span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="openPictureModePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7z"/><path d="M14 15h3"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'عادی، بزرگ، کشیده 16:9 یا کوچک‌تر' : 'Normal, zoom, 16:9 stretch or smaller' ?></span></span></span>
                                        <span class="settings-row-value" id="currentPictureModeLabel"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>


                                    <button type="button" class="settings-row" id="openTheatrePanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/><path d="M7 11h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'بزرگ‌تر شدن پلیر و تاریک شدن اطراف' : 'Larger player with darker surroundings' ?></span></span></span>
                                        <span class="settings-row-value" id="currentTheatreModeLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>

                                    <button type="button" class="settings-row" id="openBrightnessPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'کنترل نور با منو یا ژست لمسی' : 'Adjust by menu or touch gesture' ?></span></span></span><span class="settings-row-value" id="currentBrightnessLabel">100%</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <button type="button" class="settings-row" id="openSleepTimerPanel">
                                        <span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'توقف خودکار پخش بعد از زمان انتخابی' : 'Automatically pause playback after a selected time' ?></span></span></span>
                                        <span class="settings-row-value sleep-countdown" id="currentSleepTimerLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span>
                                        <svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>
                                    </button>
                                    <div class="settings-divider"></div>
                                    <button type="button" class="settings-row" id="openSubtitlePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'آپلود، حذف و سینک با تاخیر دقیق' : 'Upload, remove and sync delay precisely' ?></span></span></span><span class="settings-row-value" id="currentSubtitleLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                    <input type="file" id="subtitleUpload" accept=".srt,.vtt,.ssa,.ass" style="display:none">

                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="quality">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'کیفیت پخش' : 'Video quality' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="qualityModalList"></div>
                            </div>
                            <div class="settings-panel" data-settings-panel="speed">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="speedSettingsList">

                                    <div class="speed-touch-card" id="speedTouchCard">
                                        <div class="speed-touch-head"><span><?= $userLang === 'fa' ? 'تنظیم لمسی سرعت' : 'Touch speed control' ?></span><strong class="speed-touch-value" id="speedTouchValue">1x</strong></div>
                                        <div class="speed-touch-pad" id="speedTouchPad"><span><?= $userLang === 'fa' ? 'مثل کنترل آیفونی، اینجا را بالا/پایین بکش' : 'Swipe up/down here like an iOS control' ?></span></div>
                                        <input type="range" class="settings-range speed-range" id="speedRange" min="0.25" max="2" step="0.05" value="1">
                                    </div>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.25"><span class="settings-choice-left"><span class="settings-choice-title">0.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.5"><span class="settings-choice-left"><span class="settings-choice-title">0.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.75"><span class="settings-choice-left"><span class="settings-choice-title">0.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt active" data-speed="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">1x</span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.25"><span class="settings-choice-left"><span class="settings-choice-title">1.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.5"><span class="settings-choice-left"><span class="settings-choice-title">1.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="1.75"><span class="settings-choice-left"><span class="settings-choice-title">1.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice speed-opt" data-speed="2"><span class="settings-choice-left"><span class="settings-choice-title">2x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="picture">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="pictureModeSettingsList">
                                    <button type="button" class="settings-choice picture-mode-opt active" data-picture-mode="normal"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان حالت فعلی پلیر' : 'Current default player view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="cover"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'بزرگ / پرکننده' : 'Zoom / fill' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر قاب را پر می‌کند؛ ممکن است کمی برش بخورد' : 'Fills the frame; edges may crop slightly' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="stretch"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کشیده 16:9' : '16:9 stretch' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمام قاب 16:9 بدون حاشیه، با کشیدگی احتمالی' : 'No side bars, may stretch the image' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice picture-mode-opt" data-picture-mode="small"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر کمی کوچک‌تر داخل قاب نمایش داده می‌شود' : 'Shows the video slightly smaller inside the frame' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="subtitle">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-row" id="uploadSubtitleOption"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'آپلود زیرنویس' : 'Upload subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'SRT، VTT و ASS ساده' : 'SRT, VTT and basic ASS' ?></span></span></span></button>
                                    <button type="button" class="settings-row" id="toggleSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'نمایش زیرنویس' : 'Show subtitles' ?></span><span class="settings-row-desc" id="subtitleVisibilityLabel"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></span></span><span class="settings-row-value" id="subtitleToggleValue"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></button>
                                    <button type="button" class="settings-row" id="removeSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span><span class="settings-row-title"><?= $userLang === 'fa' ? 'حذف زیرنویس' : 'Remove subtitle' ?></span></span></button>
                                        <div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'رنگ زیرنویس' : 'Subtitle color' ?></div>
                                        <div class="subtitle-color-grid">
                                            <button type="button" class="subtitle-color-btn active" data-subtitle-color="#ffffff" title="White"><span class="subtitle-color-dot" style="background:#ffffff"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ffd84d" title="Yellow"><span class="subtitle-color-dot" style="background:#ffd84d"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#36ff9f" title="Green"><span class="subtitle-color-dot" style="background:#36ff9f"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#7dd3fc" title="Blue"><span class="subtitle-color-dot" style="background:#7dd3fc"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ff9ad5" title="Pink"><span class="subtitle-color-dot" style="background:#ff9ad5"></span></button>
                                        </div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'جای زیرنویس روی تصویر' : 'Subtitle position' ?></div>
                                    <div class="settings-range-card subtitle-position-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'جابجایی عمودی' : 'Vertical position' ?></span><strong id="subtitlePositionLabel">0px</strong></div>
                                        <input type="range" class="settings-range" id="subtitlePositionRange" min="-80" max="80" step="4" value="0">
                                    </div>
                                    <div class="settings-sync-grid subtitle-position-actions">
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionUpBtn"><?= $userLang === 'fa' ? 'بالاتر' : 'Higher' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionResetBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitlePositionDownBtn"><?= $userLang === 'fa' ? 'پایین‌تر' : 'Lower' ?></button>
                                    </div>
                                    <div class="settings-choice-desc subtitle-position-hint"><?= $userLang === 'fa' ? 'اگر جای زیرنویس روی موبایل یا تلویزیون مناسب نبود، همین‌جا بالا/پایینش کن.' : 'Move subtitles up or down if the default position is not comfortable.' ?></div>

                                    <div class="settings-divider"></div>
                                    <div class="settings-mini-label"><?= $userLang === 'fa' ? 'سینک و تاخیر زیرنویس' : 'Subtitle sync / delay' ?></div>
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'تاخیر فعلی' : 'Current delay' ?></span><strong id="subtitleDelayLabel">0.0s</strong></div>
                                        <input type="range" class="settings-range" id="subtitleDelayRange" min="-5" max="5" step="0.1" value="0">
                                    </div>
                                    <div class="settings-sync-grid">
                                        <button type="button" class="settings-sync-btn" id="subtitleEarlierBtn"><?= $userLang === 'fa' ? 'زودتر -0.1s' : 'Earlier -0.1s' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitleResetDelayBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                        <button type="button" class="settings-sync-btn" id="subtitleLaterBtn"><?= $userLang === 'fa' ? 'دیرتر +0.1s' : 'Later +0.1s' ?></button>
                                    </div>
                                    <div class="settings-choice-desc" style="padding:6px 8px 10px;line-height:1.8;"><?= $userLang === 'fa' ? 'گام تنظیم ۰.۱ ثانیه است تا دقیق‌تر از پرش‌های چندثانیه‌ای باشد.' : 'Adjustment step is 0.1s for precise subtitle sync.' ?></div>
                                </div>
                            </div>


                            <div class="settings-panel" data-settings-panel="theatre">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <button type="button" class="settings-choice theatre-opt active" data-theatre="off"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'نمای عادی صفحه' : 'Normal page view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice theatre-opt" data-theatre="on"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمرکز روی فیلم بدون تمام‌صفحه' : 'Focus on video without fullscreen' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'این حالت فقط با انتخاب کاربر فعال می‌شود و فول‌اسکرین را جایگزین نمی‌کند.' : 'This mode only turns on when selected and does not replace fullscreen.' ?></div>
                                </div>
                            </div>

                            <div class="settings-panel" data-settings-panel="brightness">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'روشنایی تصویر' : 'Brightness' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll">
                                    <div class="settings-range-card">
                                        <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'میزان نور' : 'Brightness level' ?></span><strong id="brightnessPercentLabel">100%</strong></div>
                                        <input type="range" class="settings-range" id="brightnessRange" min="40" max="160" step="5" value="100">
                                    </div>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="0.7"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کم‌نور' : 'Dim' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset active" data-brightness="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان نور اصلی ویدیو' : 'Original video brightness' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.25"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن‌تر' : 'Brighter' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice brightness-preset" data-brightness="1.5"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خیلی روشن' : 'Very bright' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'روی موبایل با کشیدن انگشت بالا/پایین روی نیمه چپ پلیر هم نور تغییر می‌کند.' : 'On mobile, swipe up/down on the left half of the player to adjust brightness.' ?></div>
                                </div>
                            </div>
                            <div class="settings-panel" data-settings-panel="sleep">
                                <div class="settings-modal-header">
                                    <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                    <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span></div>
                                </div>
                                <div class="settings-panel-scroll" id="sleepTimerSettingsList">
                                    <button type="button" class="settings-choice sleep-opt active" data-sleep-minutes="0"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تایمر فعال نیست' : 'No active timer' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="10"><span class="settings-choice-left"><span class="settings-choice-title">10 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="15"><span class="settings-choice-left"><span class="settings-choice-title">15 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="30"><span class="settings-choice-left"><span class="settings-choice-title">30 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="45"><span class="settings-choice-left"><span class="settings-choice-title">45 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="60"><span class="settings-choice-left"><span class="settings-choice-title">60 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="90"><span class="settings-choice-left"><span class="settings-choice-title">90 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                    <button type="button" class="settings-choice sleep-opt" data-sleep-minutes="120"><span class="settings-choice-left"><span class="settings-choice-title">120 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <button class="ctrl-btn" id="downloadCurrentBtn" style="display:none!important" aria-hidden="true" tabindex="-1"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg></button>
                    <button class="ctrl-btn screen-lock-btn unlocked" id="screenLockBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
                    <button class="ctrl-btn" id="fullscreenBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></button>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- جایگاه رسمی یکتانت؛ بدون wrapper، CSS، JavaScript یا حالت شناور -->
    <?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '' ?>

    <!-- بخش دانلود -->
    <div class="download-section" id="downloadSection">
        <?php if($bmArchiveItemDownloadBlocked): ?><div class="bm-archive-policy-notice">لینک‌های دانلود و پخش آنلاین این عنوان توسط مدیریت بسته شده است.</div><?php endif; ?>
        <div class="section-title">
            <span style="display:flex;align-items:center;gap:9px">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                <?= ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked) ? ($userLang === 'fa' ? 'لینک‌های پخش و دانلود' : 'Play and download links') : ($userLang === 'fa' ? 'نسخه‌های پخش آنلاین' : 'Online playback') ?>
            </span>
            <?php if($bmShowSeriesCopy): ?>
            <button type="button" class="bm-bulk-copy-open bm-bulk-copy-open--inline<?= $bmHasSeriesCopy ? '' : ' is-pending' ?>" data-bm-bulk-copy-open aria-haspopup="dialog" aria-controls="bmSeriesBulkModal">
                <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2 2v1"/></svg>
                <span><?= $userLang === 'fa' ? 'همه لینک‌ها' : 'All links' ?></span>
                <small><?= $userLang === 'fa' ? 'کپی یا ADM/IDM' : 'Copy or ADM/IDM' ?></small>
            </button>
            <?php endif; ?>
        </div>

        
        <?php if($isMovie): ?>
            <!-- Archive 2 / DB movie downloads: native Archive-1 visual structure, download-only for movies -->
            <div class="arc1-series-downloads bm-archive2-native">
                <?php if($hasDub): ?>
                <?php $bmArc2DubCount = 0; foreach($dubLinks as $bmItems) { $bmArc2DubCount += is_array($bmItems) ? count($bmItems) : 0; } ?>
                <div class="arc1-ep-card bm-movie-download-accordion is-dub-group">
                    <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                        <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg>
                            <?= $userLang === 'fa' ? 'دوبله فارسی' : 'Persian Dubbed' ?>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px">
                            <span class="bm-download-group-count"><?= (int)$bmArc2DubCount ?> <?= $userLang === 'fa' ? 'لینک' : 'links' ?></span>
                            <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                        </div>
                    </div>
                    <div class="arc1-ep-links bm-movie-download-panel">
                    <?php foreach($dubLinks as $quality => $items): foreach($items as $item): ?>
                        <?php if(empty($item['url'])) continue; $bmArc2Spec = bmArc2PremiumSpecs($quality, $item['url'], (array)$item); $bmArc2Size = bmArc2CleanSize($item['size'] ?? ''); ?>
                        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default" data-link-row="1">
                            <div class="download-card-left">
                                <span class="download-type-badge is-dub"><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?= $userLang === 'fa' ? 'دوبله' : 'Dubbed' ?></span>
                                <div class="link-info">
                                    <span class="quality" data-bm-quality="<?= e($bmArc2Spec['resolution']) ?>"><?= e($bmArc2Spec['resolution']) ?></span>
                                    <?php if($bmArc2Size !== ''): ?><span class="size"><?= e($bmArc2Size) ?></span><?php endif; ?>
                                    <?= bm_v111_cam_notice((array)$item,(string)$quality,(string)($item['url'] ?? ''),$userLang) ?><?php if(!empty($bmArc2Spec['tags'])): ?><div class="bm-arc1-rich-meta"><?php foreach($bmArc2Spec['tags'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind']) ?>" data-meta="<?= e($meta['value']) ?>"><?php if(!empty($meta['label'])): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?>
                                </div>
                            </div>
                            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                                <button type="button" class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                                    data-url="<?= e(bm_archive_stream_url($item['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($item['url'])) ?>"<?php endif; ?>
                                    data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="dub"
                                    data-label="<?= e(($userLang === 'fa' ? 'دوبله' : 'Dubbed') . ' — ' . $bmArc2Spec['resolution']) ?>">
                                    <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                                    <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                </button>
                                <?php if($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($item['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="dub" class="download-icon" style="text-decoration:none"><svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><?= $userLang === 'fa' ? 'دانلود' : 'Download' ?></a><?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; endforeach; ?>
                    </div>
                </div>
                <?php bm_render_download_support_card('archive2-movie'); ?>
                <?php endif; ?>

                <?php if($hasSoft): ?>
                <?php $bmArc2SoftCount = 0; foreach($softLinks as $bmItems) { $bmArc2SoftCount += is_array($bmItems) ? count($bmItems) : 0; } ?>
                <div class="arc1-ep-card bm-movie-download-accordion is-soft-group">
                    <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                        <div class="arc1-ep-num" style="display:flex;align-items:center;gap:8px">
                            <?= $userLang === 'fa' ? e($bmArchiveSubFa) : e($bmArchiveSubEn) ?>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px">
                            <span class="bm-download-group-count"><?= (int)$bmArc2SoftCount ?> <?= $userLang === 'fa' ? 'لینک' : 'links' ?></span>
                            <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                        </div>
                    </div>
                    <div class="arc1-ep-links bm-movie-download-panel">
                    <?php foreach($softLinks as $quality => $items): foreach($items as $item): ?>
                        <?php if(empty($item['url'])) continue; $bmArc2Spec = bmArc2PremiumSpecs($quality, $item['url'], (array)$item); $bmArc2Size = bmArc2CleanSize($item['size'] ?? ''); ?>
                        <div class="download-link premium-download-card bm-movie-download-row" style="cursor:default" data-link-row="1">
                            <div class="download-card-left">
                                <span class="download-type-badge is-soft"><?= $userLang === 'fa' ? e($bmArchiveSubFa) : e($bmArchiveSubEn) ?></span>
                                <div class="link-info">
                                    <span class="quality" data-bm-quality="<?= e($bmArc2Spec['resolution']) ?>"><?= e($bmArc2Spec['resolution']) ?></span>
                                    <?php if($bmArc2Size !== ''): ?><span class="size"><?= e($bmArc2Size) ?></span><?php endif; ?>
                                    <?= bm_v111_cam_notice((array)$item,(string)$quality,(string)($item['url'] ?? ''),$userLang) ?><?php if(!empty($bmArc2Spec['tags'])): ?><div class="bm-arc1-rich-meta"><?php foreach($bmArc2Spec['tags'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind']) ?>" data-meta="<?= e($meta['value']) ?>"><?php if(!empty($meta['label'])): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?>
                                </div>
                            </div>
                            <div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap">
                                <button type="button" class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                                    data-url="<?= e(bm_archive_stream_url($item['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($item['url'])) ?>"<?php endif; ?>
                                    data-subtitle-url="<?= e(bm_archive_stream_url($item['subtitle_url'] ?? '')) ?>"
                                    data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="soft"
                                    data-label="<?= e(($userLang === 'fa' ? $bmArchiveSubFa : $bmArchiveSubEn) . ' — ' . $bmArc2Spec['resolution']) ?>">
                                    <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                                    <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                </button>
                                <?php if($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($item['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="soft" class="download-icon" style="text-decoration:none"><svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg><?= $userLang === 'fa' ? 'دانلود' : 'Download' ?></a><?php endif; ?>
                                <?php $bmArc2SubtitleHref = trim((string)($item['subtitle_url'] ?? '')); if($bmArc2SubtitleHref !== '' && ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked)): ?>
                                <a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($bmArc2SubtitleHref)) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-sub-dl-btn" title="<?= $userLang === 'fa' ? 'دانلود زیرنویس فارسی' : 'Download Persian subtitle' ?>"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; endforeach; ?>
                    </div>
                </div>
                <?php if(!$hasDub): bm_render_download_support_card('archive2-movie'); endif; ?>
                <?php endif; ?>

                <?php if(!$hasDub && !$hasSoft): ?>
                    <div class="empty-state"><?= $userLang === 'fa' ? 'لینکی برای این فیلم ثبت نشده' : 'No links available' ?></div>
                <?php endif; ?>
            </div>

        <?php else: ?>
            <!-- Archive 2 / DB series: exact Archive-1 episode/card/action structure -->
            <div id="seriesSeasonsContainer" class="arc1-series-downloads bm-archive2-native">
                <?php if(count($seriesSeasons) > 0): ?>
                    <div class="arc1-season-tabs" id="arc2SeasonTabs">
                        <?php foreach($seriesSeasons as $sk => $links):
                            $snNum = ltrim(preg_replace('/[^0-9]/','',$sk),'0') ?: '1';
                            // V6.5.1: the season tab must show UNIQUE EPISODES, not raw quality/download rows.
                            // Example: 10 episodes × 6 qualities = 60 links, but the badge must remain 10.
                            $bmArc2UniqueEpisodes = [];
                            $bmArc2HasFullSeasonRow = false;
                            foreach ((array)$links as $bmArc2CountLink) {
                                $bmArc2CountEpisode = isset($bmArc2CountLink['episode']) && $bmArc2CountLink['episode'] !== null && $bmArc2CountLink['episode'] !== ''
                                    ? (int)$bmArc2CountLink['episode']
                                    : 0;
                                if ($bmArc2CountEpisode > 0) {
                                    $bmArc2UniqueEpisodes[$bmArc2CountEpisode] = true;
                                } else {
                                    $bmArc2HasFullSeasonRow = true;
                                }
                            }
                            $bmArc2SeasonEpisodeCount = count($bmArc2UniqueEpisodes);
                            if ($bmArc2SeasonEpisodeCount === 0 && $bmArc2HasFullSeasonRow) $bmArc2SeasonEpisodeCount = 1;
                        ?>
                        <button class="arc1-season-tab" aria-expanded="false" data-target="arc2-sp-<?= e($sk) ?>" onclick="arc1SwitchSeason(this, 'arc2-sp-<?= e($sk) ?>')">
                            <?= $userLang === 'fa' ? 'فصل ' : 'Season ' ?><?= e($snNum) ?>
                            <span class="tab-count">(<?= $bmArc2SeasonEpisodeCount ?>)</span>
                        </button>
                        <?php endforeach; ?>
                    </div>

                    <?php $bmArc2SupportPlaced = false; foreach($seriesSeasons as $season => $links): ?>
                    <?php
                        $snNum = ltrim(preg_replace('/[^0-9]/','',$season),'0') ?: '1';
                        $episodeGroups = [];
                        foreach($links as $link) {
                            $ep = isset($link['episode']) && $link['episode'] !== null && $link['episode'] !== '' ? (int)$link['episode'] : 0;
                            $epKey = $ep > 0 ? ('E' . str_pad((string)$ep, 2, '0', STR_PAD_LEFT)) : 'full';
                            if(!isset($episodeGroups[$epKey])) $episodeGroups[$epKey] = [];
                            $episodeGroups[$epKey][] = $link;
                        }
                        uksort($episodeGroups, static function($a, $b) {
                            if($a === 'full') return 1;
                            if($b === 'full') return -1;
                            return intval(preg_replace('/\D+/', '', $a)) <=> intval(preg_replace('/\D+/', '', $b));
                        });
                        $allEpKeys = array_keys($episodeGroups);
                    ?>
                    <div id="arc2-sp-<?= e($season) ?>" data-sp="1" style="display:none">
                        <div class="arc1-season-header">
                            <span style="font-size:14px;font-weight:900;color:var(--accent)"><?= $userLang === 'fa' ? 'فصل ' : 'Season ' ?><?= e($snNum) ?></span>
                            <span style="font-size:12px;color:rgba(255,255,255,.45);background:rgba(255,255,255,.06);padding:4px 11px;border-radius:20px;border:1px solid rgba(255,255,255,.08)"><?= count($episodeGroups) ?> <?= $userLang === 'fa' ? 'قسمت' : 'episodes' ?></span>
                        </div>
                        <?php foreach($episodeGroups as $episodeKey => $episodeLinks): ?>
                        <?php
                            $en = $episodeKey === 'full' ? '' : (ltrim(preg_replace('/[^0-9]/','',$episodeKey),'0') ?: '');
                            $epLabel = $episodeKey === 'full' ? ($userLang === 'fa' ? 'فصل کامل' : 'Full season') : (($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $en);
                            $epQualities = [];
                            foreach($episodeLinks as $_ql) { $epQualities[] = bmArc2PremiumSpecs(bmArc2CleanQuality($_ql['quality'] ?? ''), $_ql['url'] ?? '', (array)$_ql)['resolution']; }
                            $epQualities = array_values(array_unique(array_filter($epQualities)));
                            $currentEpPos = array_search($episodeKey, $allEpKeys, true);
                            $nextEk = ($currentEpPos !== false && isset($allEpKeys[$currentEpPos+1])) ? $allEpKeys[$currentEpPos+1] : null;
                            $nextUrl = $nextEk ? ($episodeGroups[$nextEk][0]['url'] ?? '') : '';
                            $nextEnNum = $nextEk ? (ltrim(preg_replace('/[^0-9]/','',$nextEk),'0') ?: '') : '';
                            $nextLabel = $nextEk ? (($userLang === 'fa' ? 'فصل ' : 'Season ') . $snNum . ' — ' . ($userLang === 'fa' ? 'قسمت ' : 'Episode ') . $nextEnNum) : '';
                        ?>
                        <div class="arc1-ep-card" data-episode="<?= e($en) ?>" data-season="<?= e($snNum) ?>">
                            <div class="arc1-ep-head" onclick="this.closest('.arc1-ep-card').classList.toggle('open')">
                                <div class="arc1-ep-num"><?= e($epLabel) ?></div>
                                <div style="display:flex;align-items:center;gap:8px">
                                    <?php if(!empty($epQualities)): ?>
                                    <div class="arc1-ep-badges">
                                        <?php foreach($epQualities as $qb): ?><span style="font-size:10px;padding:2px 8px;border-radius:20px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.18);color:var(--accent);font-weight:700"><?= e($qb) ?></span><?php endforeach; ?>
                                    </div>
                                    <?php endif; ?>
                                    <div class="arc1-ep-toggle"><svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg></div>
                                </div>
                            </div>
                            <div class="arc1-ep-links">
                                <?php foreach($episodeLinks as $link): ?>
                                <?php
                                    if(empty($link['url'])) continue;
                                    $cleanQuality = bmArc2CleanQuality($link['quality'] ?? '');
                                    $bmArc2Spec = bmArc2PremiumSpecs($cleanQuality, $link['url'] ?? '', (array)$link);
                                    $bmArc2Size = bmArc2CleanSize($link['size'] ?? '');
                                    $bmArc2Type = strtolower(trim((string)($link['type'] ?? 'soft')));
                                    $bmArc2TypeLabel = bm_archive_download_type_label($bmArc2Type, $userLang, $bmArchiveSubFa, $bmArchiveSubEn);
                                ?>
                                <div class="arc1-link-row" data-link-row="1" data-season="<?= e($snNum) ?>" data-episode="<?= e($en) ?>">
                                    <div class="arc1-link-meta">
                                        <span class="download-type-badge <?= e(bm_archive_download_type_class($bmArc2Type)) ?>">
                                            <?php if($bmArc2Type === 'dub'): ?><svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/></svg><?php endif; ?>
                                            <?= e($bmArc2TypeLabel) ?>
                                        </span>
                                        <div>
                                            <div class="quality" data-bm-quality="<?= e($bmArc2Spec['resolution']) ?>" style="font-size:13px;font-weight:800;color:#fff"><?= e($bmArc2Spec['resolution']) ?></div>
                                            <?php if($bmArc2Size !== ''): ?><div class="size" style="font-size:11px;color:rgba(255,255,255,.45)"><?= e($bmArc2Size) ?></div><?php endif; ?>
                                            <?= bm_v111_cam_notice((array)$link,(string)$cleanQuality,(string)($link['url'] ?? ''),$userLang) ?><?php if(!empty($bmArc2Spec['tags'])): ?><div class="bm-arc1-rich-meta"><?php foreach($bmArc2Spec['tags'] as $meta): ?><span class="bm-arc1-meta-pill is-<?= e($meta['kind']) ?>" data-meta="<?= e($meta['value']) ?>"><?php if(!empty($meta['label'])): ?><b><?= e($meta['label']) ?></b><?php endif; ?><span><?= e($meta['value']) ?></span></span><?php endforeach; ?></div><?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="arc1-link-actions">
                                        <button type="button" class="arc1-play-inline arc1-play-btn"<?= $bmArchiveStreamGateAttrs ?>
                                            data-url="<?= e(bm_archive_stream_url($link['url'])) ?>" <?php if($bmArchiveDownloadAllowed): ?>data-copy-url="<?= e(bm_dl_wrap_url($link['url'])) ?>"<?php endif; ?>
                                            data-subtitle-url="<?= e(bm_archive_stream_url($link['subtitle_url'] ?? '')) ?>"
                                            data-season="<?= e($snNum) ?>" data-episode="<?= e($en) ?>"
                                            data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="<?= e($bmArc2Type) ?>"
                                            data-label="<?= e($epLabel . ' — ' . $bmArc2TypeLabel . ' — ' . $bmArc2Spec['resolution']) ?>"
                                            data-next-url="<?= e(bm_archive_stream_url($nextUrl)) ?>" data-next-label="<?= e($nextLabel) ?>"
                                            data-next-ep="<?= e($nextEnNum) ?>" data-next-season="<?= e($snNum) ?>">
                                            <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                                            <?= $userLang === 'fa' ? 'پخش' : 'Play' ?>
                                        </button>
                                        <?php if($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked): ?><a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($link['url'])) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?>
                                           data-quality="<?= e($bmArc2Spec['resolution']) ?>" data-type="<?= e($bmArc2Type) ?>"
                                           data-season="<?= e($snNum) ?>" data-episode="<?= e($en) ?>" class="arc1-dl-btn">
                                            <svg class="bm-link-btn-icon bm-link-btn-icon-download" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M12 7L12 14M12 14L15 11M12 14L9 11" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/><path d="M16 17H12H8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/><path opacity="0.5" d="M2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12Z" stroke="currentColor" stroke-width="1.5"/></svg>
                                            <?= $userLang === 'fa' ? 'دانلود' : 'Download' ?>
                                        </a><?php endif; ?>
                                        <?php $bmArc2SeriesSubtitleHref = trim((string)($link['subtitle_url'] ?? '')); if($bmArc2SeriesSubtitleHref !== '' && ($bmArchiveDownloadAllowed || $bmArchiveDownloadVipLocked)): ?>
                                        <a href="<?= $bmArchiveDownloadAllowed ? e(bm_dl_wrap_url($bmArc2SeriesSubtitleHref)) : '#' ?>"<?= $bmArchiveDownloadAllowed ? ' download data-bm-download-only="1"' : $bmArchiveDownloadGateAttrs ?> class="arc1-sub-dl-btn" title="<?= $userLang === 'fa' ? 'دانلود زیرنویس فارسی' : 'Download Persian subtitle' ?>"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if(!$bmArc2SupportPlaced): $bmArc2SupportPlaced = true; bm_render_download_support_card('archive2-series'); endif; ?>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="empty-state" style="text-align:center;padding:40px"><?= $userLang === 'fa' ? 'لینکی برای این سریال ثبت نشده' : 'No links available' ?></div>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <!-- بخش کامنت‌ها -->
    <div class="comments-section" id="bmMovieComments">
        <div class="comments-header">
            <div class="section-title" style="margin-bottom:0;">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $userLang === 'fa' ? e($bmCommentTitleFa) : 'User Comments' ?>
            </div>
            <div class="comments-stats">
                <div class="comment-stat">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/></svg>
                    <span id="totalCommentsCount"><?= number_format($totalComments) ?></span>
                </div>
                <?php if(!empty($bmCommentConfig['ratings']) && $avgRating > 0): ?><div class="comment-stat"><?= renderStars($avgRating) ?><span>(<?= number_format($avgRating, 1) ?>)</span></div><?php endif; ?>
            </div>
            <label class="bm-comment-sort-wrap">
                <span><?= $userLang === 'fa' ? 'مرتب‌سازی' : 'Sort' ?></span>
                <select class="bm-comment-sort" aria-label="Comment sort">
                    <option value="latest" <?= ($commentSort ?? 'latest')==='latest'?'selected':'' ?>><?= $userLang==='fa'?'جدیدترین':'Latest' ?></option>
                    <option value="popular" <?= ($commentSort ?? '')==='popular'?'selected':'' ?>><?= $userLang==='fa'?'محبوب‌ترین':'Popular' ?></option>
                    <option value="controversial" <?= ($commentSort ?? '')==='controversial'?'selected':'' ?>><?= $userLang==='fa'?'بحث‌برانگیزترین':'Controversial' ?></option>
                    <option value="replies" <?= ($commentSort ?? '')==='replies'?'selected':'' ?>><?= $userLang==='fa'?'بیشترین پاسخ':'Most replies' ?></option>
                    <option value="oldest" <?= ($commentSort ?? '')==='oldest'?'selected':'' ?>><?= $userLang==='fa'?'قدیمی‌ترین':'Oldest' ?></option>
                </select>
            </label>
        </div>
        
        <div class="comment-form">
            <div class="comment-form-header">
                <div class="comment-avatar">
                    <?php if($currentUser): ?>
                        <img src="<?= htmlspecialchars($bmCurrentUserAvatarUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?>" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/avatars/avatar_default.webp';" style="width:40px;height:40px;border-radius:50%;object-fit:cover;">
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    <?php endif; ?>
                </div>
                <div class="comment-form-info">
                    <span class="comment-username"><?= $currentUser ? htmlspecialchars($currentUser['username']) : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest') ?></span>
                    <?php if(!empty($bmCommentConfig['ratings'])): ?><span class="comment-guest-note"><?= $userLang === 'fa' ? '(برای امتیاز دادن وارد شوید)' : '(Login to rate)' ?></span><?php endif; ?>
                </div>
            </div>
            
            <div id="commentMessage" style="display:none;" class="comment-success"></div>
            <div id="commentError" style="display:none;" class="comment-error"></div>
            
    <?php if(!empty($bmCommentConfig['spoiler'])): ?><div class="comment-toolbar" style="display: flex; justify-content: flex-end; margin-bottom: 8px;">
    <label style="display: flex; align-items: center; gap: 6px; font-size:12px;">
        <input type="checkbox" id="fullSpoilerCheckbox"> <?= $userLang === 'fa' ? 'کامنت اسپویل دار شود؟' : 'Whole comment is spoiler' ?>
    </label>
</div><?php endif; ?>
            
            <?php if(!empty($bmCommentConfig['ratings'])): ?><div class="star-rating-input"><span><?= $userLang === 'fa' ? 'امتیاز شما:' : 'Your rating:' ?></span><div class="star-rating" id="starRating"><?= renderStarInput($userRating) ?></div></div><?php endif; ?>
            <textarea id="commentText" class="comment-textarea" rows="3" placeholder="<?= $userLang === 'fa' ? e($bmCommentPlaceholderFa) : 'Write your comment...' ?>"></textarea>
            <button type="button" id="submitCommentBtn" class="comment-submit bm-comment-send-button" aria-live="polite">
                <span class="bm-send-outline" aria-hidden="true"></span>
                <span class="bm-send-state bm-send-default"><span class="bm-send-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 2 11 13"/><path d="m22 2-7 20-4-9-9-4Z"/></svg></span><span class="bm-send-letters" aria-hidden="true"><?php foreach(($userLang === 'fa' ? ['ا','ر','س','ا','ل'] : ['S','e','n','d']) as $i=>$ch): ?><span style="--i:<?=$i?>"><?=e($ch)?></span><?php endforeach; ?></span><span class="bm-sr-only"><?= $userLang === 'fa' ? 'ارسال' : 'Send' ?></span></span>
                <span class="bm-send-state bm-send-sent"><span class="bm-send-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4"><path d="m5 12 4 4L19 6"/></svg></span><span class="bm-send-letters" aria-hidden="true"><?php foreach(($userLang === 'fa' ? ['ا','ر','س','ا','ل',' ','ش','د'] : ['S','e','n','t']) as $i=>$ch): ?><span style="--i:<?=$i?>"><?= $ch === ' ' ? '&nbsp;' : e($ch) ?></span><?php endforeach; ?></span><span class="bm-sr-only"><?= $userLang === 'fa' ? 'ارسال شد' : 'Sent' ?></span></span>
            </button>
        </div>
        
        <div class="comment-list" id="commentList">
            <?php if(count($comments) > 0): ?>
                <?php foreach($comments as $comment): ?>
                    <?= renderCommentHTML($comment, $userLang, $currentUser['id'] ?? 0) ?>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-comments" id="emptyComments"><?= $userLang === 'fa' ? e($bmCommentEmptyFa) : 'No comments yet. Be the first to comment!' ?></div>
            <?php endif; ?>
        </div>
        
        <?php if($totalCommentPages > 1): ?>
        <div class="load-more-comments" id="loadMoreCommentsBtn">
            <button class="btn-outline" style="width:100%; padding:12px;">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
                <?= $userLang === 'fa' ? 'بارگذاری بیشتر' : 'Load More' ?>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
            </button>
        </div>
        <?php endif; ?>
    </div>

    <!-- فیلم‌های مشابه -->
    <?php if(count($genreRelatedMovies) > 0): ?>
    <div class="related-section" id="bmMovieRelated">
        <div class="section-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            <?= $userLang === 'fa' ? 'فیلم‌های مشابه براساس ژانر (تصادفی)' : 'Random Similar by Genre' ?>
        </div>
        <div class="related-scroll" id="genreRelatedContainer">
            <?php foreach($genreRelatedMovies as $related): ?>
            <a href="<?= e(bm_movie_url($related)) ?>" class="related-card">
                <img class="related-poster" src="/posters/<?= htmlspecialchars($related['imdb_code']) ?>.webp" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 150\'%3E%3Crect width=\'100\' height=\'150\' fill=\'%2318181d\'/%3E%3C/svg%3E'">
                <?php if(!empty($related['imdb_rate']) && (float)$related['imdb_rate'] > 0): ?><span class="bm-related-imdb-badge"><span class="bm-imdb-score"><?= number_format((float)$related['imdb_rate'], 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                <div class="related-info">
                    <div class="related-title-fa"><?= htmlspecialchars($related['title_fa'] ?: $related['title']) ?></div>
                    <div class="related-title-en"><?= htmlspecialchars($related['title']) ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if(count($relatedMovies) > 0): ?>
    <div class="related-section">
        <div class="section-title">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
            <?= $userLang === 'fa' ? 'فیلم‌های هم اسم و مرتبط' : 'Same Name & Related Movies' ?>
        </div>
        <div class="related-scroll" id="relatedContainer">
            <?php foreach($relatedMovies as $related): ?>
            <a href="<?= e(bm_movie_url($related)) ?>" class="related-card">
                <img class="related-poster" src="/posters/<?= htmlspecialchars($related['imdb_code']) ?>.webp" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 100 150\'%3E%3Crect width=\'100\' height=\'150\' fill=\'%2318181d\'/%3E%3C/svg%3E'">
                <?php if(!empty($related['imdb_rate']) && (float)$related['imdb_rate'] > 0): ?><span class="bm-related-imdb-badge"><span class="bm-imdb-score"><?= number_format((float)$related['imdb_rate'], 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                <div class="related-info">
                    <div class="related-title-fa"><?= htmlspecialchars($related['title_fa'] ?: $related['title']) ?></div>
                    <div class="related-title-en"><?= htmlspecialchars($related['title']) ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php endif; /* isArc1 / else arc2 */ ?>



<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<div id="donateModal" class="modal">
    <div class="modal-content">
        <div style="background: var(--gradient-donate); width: 70px; height: 70px; border-radius: 50%; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center;">
            <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        </div>
        <h3 style="margin-bottom:12px;"><?= $userLang === 'fa' ? 'حمایت مالی' : 'Support Us' ?></h3>
        <p style="color: var(--text-secondary); margin-bottom:20px; font-size:13px;"><?= $userLang === 'fa' ? 'تمام خدمات ما رایگان است. اگر دوست دارید از ما حمایت کنید، مبلغی را واریز کنید.' : 'All our services are free. If you would like to support us, please donate.' ?></p>
        <button id="openDonateLink" class="btn btn-primary" style="width:100%; justify-content:center;"><?= $userLang === 'fa' ? 'حمایت مالی' : 'Donate' ?></button>
        <button id="closeDonateModal" style="margin-top:12px; background:none; border:none; color:var(--text-tertiary); cursor:pointer;"><?= $userLang === 'fa' ? 'بستن' : 'Close' ?></button>
    </div>
</div>


<!-- V22: انتخاب نوع پخش -->
<div class="bm-play-choice-overlay" id="bmPlayChoiceModal" aria-hidden="true">
    <div class="bm-play-choice-modal" role="dialog" aria-modal="true" aria-labelledby="bmPlayChoiceTitle">
        <div class="bm-play-choice-head">
            <div class="bm-play-choice-title">
                <div>
                    <strong id="bmPlayChoiceTitle"><?= $userLang === 'fa' ? bm_site_h(bm_site_get('player_choice_title_fa','انتخاب روش پخش')) : bm_site_h(bm_site_get('player_choice_title_en','Choose Playback Method')) ?></strong>
                    <span id="bmPlayChoiceLabel">BankMovie Player</span>
                </div>
            </div>
            <button type="button" class="bm-play-choice-close" data-bm-play-close aria-label="<?= $userLang === 'fa' ? 'بستن' : 'Close' ?>"><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"></button>
        </div>
        <div class="bm-play-choice-body">
            <button type="button" class="bm-play-option internal" data-bm-play-action="internal">
                <span class="bm-play-option-icon">
                    <svg class="bm-link-btn-icon bm-link-btn-icon-play bm-f2m-icon bm-f2m-icon-fill" viewBox="0 0 24 24" aria-hidden="true"><path d="M18.7 8.97989L4.14 17.7099C4.05 17.3799 4 17.0299 4 16.6699V7.32989C4 4.24989 7.33 2.32989 10 3.86989L14.04 6.19989L18.09 8.53989C18.31 8.66989 18.52 8.80989 18.7 8.97989Z" fill="currentColor"/><path opacity="0.4" d="M18.0907 15.4598L14.0407 17.7998L10.0007 20.1298C8.0907 21.2298 5.8407 20.5698 4.7207 18.9598L5.1407 18.7098L19.5807 10.0498C20.5807 11.8498 20.0907 14.3098 18.0907 15.4598Z" fill="currentColor"/></svg>
                </span>
                <span class="bm-play-option-text">
                    <b><?= $userLang === 'fa' ? bm_site_h(bm_site_get('player_internal_label_fa','پخش با پلیر داخلی')) : bm_site_h(bm_site_get('player_internal_label_en','Play in Built-In Player')) ?></b>
                    <span><?= $userLang === 'fa' ? 'پخش مستقیم در پلیر بانک مووی — فقط با مرورگر Chrome' : 'Stream directly in the BankMovie player — Chrome browser only' ?></span>
                </span>
            </button>
            <?php if ($bmExternalPlayersEnabled): ?>
            <button type="button" class="bm-play-option vlc" data-bm-play-action="vlc" data-bm-platform="android ios windows" hidden>
                <span class="bm-play-option-icon bm-real-player-logo">
                    <img src="/assets/img/player-vlc.png?v=96" alt="VLC" loading="eager" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b><?= $userLang === 'fa' ? 'پخش با VLC' : 'Play with VLC' ?></b>
                    <span><?= $userLang === 'fa' ? 'آیفون/اندروید: مستقیم · ویندوز: لینک کپی می‌شود → Ctrl+N → Ctrl+V' : 'iPhone/Android: open directly · Windows: the link is copied; press Ctrl+N, then Ctrl+V' ?></span>
                </span>
            </button>
            <button type="button" class="bm-play-option mx" data-bm-play-action="mx" data-bm-platform="android" hidden>
                <span class="bm-play-option-icon bm-real-player-logo">
                    <img src="/assets/img/player-mxplayer-icon.png?v=96" alt="MX Player" loading="eager" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b><?= $userLang === 'fa' ? 'پخش با MX Player' : 'Play with MX Player' ?></b>
                    <span><?= $userLang === 'fa' ? 'نسخه اندروید — باز کردن مستقیم لینک در MX Player' : 'Android only — open the link directly in MX Player' ?></span>
                </span>
            </button>
            <button type="button" class="bm-play-option km" data-bm-play-action="km" data-bm-platform="android windows" hidden>
                <span class="bm-play-option-icon bm-real-player-logo">
                    <img src="/assets/img/player-kmplayer.png?v=96" alt="KMPlayer" loading="eager" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b><?= $userLang === 'fa' ? 'پخش با KMPlayer' : 'Play with KMPlayer' ?></b>
                    <span><?= $userLang === 'fa' ? 'اندروید: مستقیم · ویندوز: لینک کپی می‌شود → Ctrl+U → Ctrl+V' : 'Android: open directly · Windows: the link is copied; press Ctrl+U, then Ctrl+V' ?></span>
                </span>
            </button>
            <button type="button" class="bm-play-option pot" data-bm-play-action="pot" data-bm-platform="windows" hidden>
                <span class="bm-play-option-icon bm-real-player-logo">
                    <img src="/assets/img/player-potplayer.png?v=96" alt="PotPlayer" loading="eager" decoding="async">
                </span>
                <span class="bm-play-option-text">
                    <b><?= $userLang === 'fa' ? 'پخش با PotPlayer' : 'Play with PotPlayer' ?></b>
                    <span><?= $userLang === 'fa' ? 'ویندوز — باز شدن مستقیم در PotPlayer' : 'Windows — open directly in PotPlayer' ?></span>
                </span>
            </button>
            <?php endif; ?>
        </div>
        <div class="bm-play-platform-hint" id="bmPlayPlatformHint" aria-live="polite"></div>
        <?php if ($bmExternalPlayersEnabled): ?><div class="bm-play-softsub-notice" id="bmPlaySoftSubNotice" aria-hidden="false">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2.8 20h18.4L12 3Z"/><path d="M12 9v5"/><circle cx="12" cy="17" r="1"/></svg>
            <span><b><?= $userLang === 'fa' ? 'نکته سافت‌ساب:' : 'Soft Subtitle Note:' ?></b> <?= $userLang === 'fa' ? bm_site_h(bm_site_get('player_softsub_note_fa','برای نمایش صحیح زیرنویس سافت‌ساب حتماً از پلیر خارجی استفاده کنید.')) : bm_site_h(bm_site_get('player_softsub_note_en','For proper soft subtitle display, use an external player.')) ?></span>
        </div><?php endif; ?>
        <div class="bm-play-inline-notice" id="bmPlayInlineNotice" aria-hidden="true" aria-live="polite">
            <span class="bm-play-inline-notice-icon" aria-hidden="true">✓</span>
            <span class="bm-play-inline-notice-copy"><b data-bm-notice-title></b><small data-bm-notice-text></small></span>
        </div>
        <div class="bm-play-choice-foot">
            <?php if ($bmPlayerCopyLinkEnabled): ?>
            <button type="button" class="bm-play-copy-link" data-bm-play-action="copy" aria-label="<?= $userLang === 'fa' ? bm_site_h(bm_site_get('player_copy_link_label_fa','کپی لینک مستقیم')) : bm_site_h(bm_site_get('player_copy_link_label_en','Copy direct link')) ?>">
                <span class="bm-copy-icon bm-copy-icon-default" aria-hidden="true"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></span>
                <span class="bm-copy-icon bm-copy-icon-done" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="m5 12 4 4L19 6"/></svg></span>
                <span data-bm-copy-label><?= $userLang === 'fa' ? bm_site_h(bm_site_get('player_copy_link_label_fa','کپی لینک مستقیم')) : bm_site_h(bm_site_get('player_copy_link_label_en','Copy direct link')) ?></span>
            </button>
            <?php endif; ?>
        </div>
    </div>
</div>



<script type="application/json" id="bmSeriesBulkData"><?= json_encode($bmSeriesCopyCatalog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<div class="bm-bulk-modal" id="bmSeriesBulkModal" hidden aria-hidden="true">
    <div class="bm-bulk-backdrop" data-bm-bulk-close></div>
    <section class="bm-bulk-dialog" role="dialog" aria-modal="true" aria-labelledby="bmBulkDialogTitle">
        <header class="bm-bulk-head">
            <div class="bm-bulk-title-wrap">
                <span class="bm-bulk-title-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5v11a2.5 2.5 0 0 1-2.5 2.5h-11A2.5 2.5 0 0 1 4 17.5z"/><path d="M8 9h8M8 13h8M8 17h5"/></svg></span>
                <div class="bm-bulk-title">
                    <div class="bm-bulk-app-pills"><span>COPY</span><span>ADM</span><span>IDM</span></div>
                    <h3 id="bmBulkDialogTitle" data-bm-bulk-title><?= $userLang === 'fa' ? 'دریافت همه لینک‌های سریال' : 'Get all series links' ?></h3>
                    <p data-bm-bulk-subtitle><?= $userLang === 'fa' ? 'لینک‌ها را انتخاب کن، کپی کن یا فایل آمادهٔ دانلود منیجر بگیر.' : 'Select links, copy them, or export a download-manager-ready file.' ?></p>
                </div>
            </div>
            <button type="button" class="bm-bulk-close" data-bm-bulk-close aria-label="<?= $userLang === 'fa' ? 'بستن' : 'Close' ?>"><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"></button>
        </header>
        <div class="bm-bulk-body">
            <div class="bm-bulk-stats" aria-label="<?= $userLang === 'fa' ? 'خلاصه لینک‌ها' : 'Link summary' ?>">
                <span data-bm-stat-seasons-wrap><b data-bm-stat-seasons>0</b> <i data-bm-stat-seasons-label><?= $userLang === 'fa' ? 'فصل' : 'seasons' ?></i></span>
                <span data-bm-stat-episodes-wrap><b data-bm-stat-episodes>0</b> <i data-bm-stat-episodes-label><?= $userLang === 'fa' ? 'قسمت' : 'episodes' ?></i></span>
                <span><b data-bm-stat-links>0</b> <?= $userLang === 'fa' ? 'لینک' : 'links' ?></span>
            </div>

            <div data-bm-season-section><div class="bm-bulk-label"><span data-bm-season-heading><?= $userLang === 'fa' ? 'فصل' : 'Season' ?></span><small data-bm-season-help><?= $userLang === 'fa' ? 'هر فصل جدا مدیریت می‌شود' : 'Each season is managed separately' ?></small></div>
            <div class="bm-bulk-seasons" data-bm-season-tabs></div></div>

            <div class="bm-bulk-filter-grid">
                <div>
                    <div class="bm-bulk-label"><span><?= $userLang === 'fa' ? 'کیفیت' : 'Quality' ?></span></div>
                    <div class="bm-bulk-quality-grid" data-bm-quality-grid></div>
                </div>
                <div>
                    <div class="bm-bulk-label"><span><?= $userLang === 'fa' ? 'نسخه' : 'Version' ?></span></div>
                    <div class="bm-bulk-filters" data-bm-type-filters></div>
                </div>
            </div>

            <section class="bm-bulk-output-mode" aria-label="<?= $userLang === 'fa' ? 'روش دریافت لینک‌ها' : 'Link output method' ?>">
                <div class="bm-bulk-label"><span><?= $userLang === 'fa' ? 'روش دریافت' : 'Output method' ?></span><small><?= $userLang === 'fa' ? 'خود کاربر انتخاب می‌کند' : 'Choose the preferred method' ?></small></div>
                <div class="bm-bulk-mode-grid" role="radiogroup">
                    <button type="button" class="is-active" data-bm-output-mode="copy" role="radio" aria-checked="true">
                        <span class="bm-bulk-mode-icon"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></span>
                        <span><b><?= $userLang === 'fa' ? 'کپی عادی' : 'Normal copy' ?></b><small><?= $userLang === 'fa' ? 'لینک‌ها مستقیم در کلیپ‌بورد' : 'Copy directly to clipboard' ?></small></span>
                    </button>
                    <button type="button" data-bm-output-mode="manager" role="radio" aria-checked="false">
                        <span class="bm-bulk-mode-icon"><svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 19h14"/></svg></span>
                        <span><b><?= $userLang === 'fa' ? 'فایل TXT برای IDM' : 'TXT file for IDM' ?></b><small><?= $userLang === 'fa' ? 'در ADM از کپی عادی و Paste استفاده کن' : 'Use Normal copy and Paste in ADM' ?></small></span>
                    </button>
                </div>
            </section>
            <button type="button" class="bm-bulk-guide-link" data-bm-guide-open>
                <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 9h8M8 13h5"/><circle cx="17" cy="15" r="2"/></svg>
                <span><?= $userLang === 'fa' ? 'آموزش تصویری IDM و ADM' : 'Visual IDM and ADM guide' ?></span>
                <i aria-hidden="true">←</i>
            </button>

            <section class="bm-bulk-manager-card" data-bm-manager-panel hidden aria-label="<?= $userLang === 'fa' ? 'خروجی دانلود منیجر' : 'Download manager export' ?>">
                <div class="bm-bulk-manager-head">
                    <span class="bm-bulk-manager-icon"><svg viewBox="0 0 24 24"><path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 19h14"/></svg></span>
                    <div><strong><?= $userLang === 'fa' ? 'ساخت فایل TXT برای IDM' : 'Create TXT for IDM' ?></strong><small><?= $userLang === 'fa' ? 'هر لینک در یک خط؛ آماده Import در IDM ویندوز' : 'One URL per line, ready for IDM on Windows' ?></small></div>
                </div>
                <label class="bm-bulk-group-name"><span><?= $userLang === 'fa' ? 'نام گروه' : 'Group name' ?></span><input type="text" maxlength="110" data-bm-package-name autocomplete="off"></label>
                <div class="bm-bulk-scope" role="group" aria-label="<?= $userLang === 'fa' ? 'محدوده خروجی' : 'Export scope' ?>">
                    <button type="button" class="is-active" data-bm-scope="selected"><?= $userLang === 'fa' ? 'انتخاب فعلی' : 'Selected' ?></button>
                    <button type="button" data-bm-scope="season"><?= $userLang === 'fa' ? 'کل فصل' : 'Whole season' ?></button>
                    <button type="button" data-bm-scope="series"><?= $userLang === 'fa' ? 'کل سریال' : 'Whole series' ?></button>
                </div>
                <div class="bm-bulk-manager-note"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg><span><?= $userLang === 'fa' ? 'فایل TXT را برای IDM بساز؛ برای ADM گوشی حالت «کپی عادی» و Paste را استفاده کن.' : 'Create the TXT file, then follow the visual import guide.' ?></span></div>
            </section>

            <div class="bm-bulk-options" data-bm-copy-panel>
                <label class="bm-bulk-format"><span><?= $userLang === 'fa' ? 'فرمت کپی' : 'Copy format' ?></span><select data-bm-copy-format><option value="urls"><?= $userLang === 'fa' ? 'فقط لینک‌ها' : 'URLs only' ?></option><option value="labeled" data-bm-labeled-option><?= $userLang === 'fa' ? 'عنوان قسمت + لینک' : 'Episode label + URL' ?></option></select></label>
                <div class="bm-bulk-result-count" data-bm-result-count></div>
            </div>
            <div class="bm-bulk-preview" data-bm-preview></div>
        </div>
        <section class="bm-bulk-guide" data-bm-guide hidden aria-hidden="true">
            <div class="bm-bulk-guide-head">
                <button type="button" class="bm-bulk-guide-back" data-bm-guide-close aria-label="بازگشت"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button>
                <div><b><?= $userLang === 'fa' ? 'راهنمای تصویری واردکردن فایل TXT' : 'Visual TXT import guide' ?></b><small><?= $userLang === 'fa' ? 'سه مرحله کوتاه؛ بدون جست‌وجو بین منوها' : 'Three short steps' ?></small></div>
            </div>
            <div class="bm-bulk-guide-tabs" role="tablist">
                <button type="button" class="is-active" data-bm-guide-tab="idm">IDM · ویندوز</button>
                <button type="button" data-bm-guide-tab="adm">ADM · اندروید</button>
            </div>
            <div class="bm-bulk-guide-scroll">
                <div class="bm-bulk-guide-panel is-active" data-bm-guide-panel="idm">
                    <figure class="bm-guide-real-shot bm-guide-real-shot--wide">
                        <img src="/assets/images/guides/idm-import-from-text.webp?v=129" alt="<?= $userLang === 'fa' ? 'مسیر Tasks سپس Import و From text file در IDM ویندوز' : 'IDM Tasks, Import, From text file path' ?>" loading="lazy" decoding="async">
                        <figcaption><?= $userLang === 'fa' ? 'اسکرین واقعی IDM: مسیر دقیق Tasks → Import → From text file' : 'Real IDM screen: Tasks → Import → From text file' ?></figcaption>
                    </figure>
                    <ol class="bm-guide-real-steps">
                        <li><span>۱</span><div><b><?= $userLang === 'fa' ? 'فایل TXT را از بانک‌مووی بگیر' : 'Download the TXT from BankMovie' ?></b><p><?= $userLang === 'fa' ? 'بعد از انتخاب فصل و کیفیت، روی «دریافت فایل ADM / IDM» بزن.' : 'Select season and quality, then download the ADM / IDM TXT.' ?></p></div></li>
                        <li><span>۲</span><div><b><?= $userLang === 'fa' ? 'در IDM منوی Tasks را باز کن' : 'Open Tasks in IDM' ?></b><p><?= $userLang === 'fa' ? 'از نوار بالای IDM وارد Tasks و سپس Import شو.' : 'Use IDM’s top menu: Tasks, then Import.' ?></p></div></li>
                        <li><span>۳</span><div><b><?= $userLang === 'fa' ? 'From text file را انتخاب کن' : 'Choose From text file' ?></b><p><?= $userLang === 'fa' ? 'فایل BankMovie-…txt را از پوشه Downloads انتخاب کن؛ IDM همه URLها را یکجا نشان می‌دهد.' : 'Choose the BankMovie TXT from Downloads; IDM will list all URLs.' ?></p></div></li>
                    </ol>
                </div>
                <div class="bm-bulk-guide-panel" data-bm-guide-panel="adm">
                    <figure class="bm-guide-real-shot bm-guide-real-shot--phone">
                        <img src="/assets/images/guides/adm-paste-normal-links.webp?v=130" alt="<?= $userLang === 'fa' ? 'صفحه Editor در ADM اندروید و دکمه Paste برای چسباندن لینک‌ها' : 'ADM Android Editor with the Paste button' ?>" loading="lazy" decoding="async">
                        <figcaption><?= $userLang === 'fa' ? 'اسکرین واقعی ADM: داخل Editor روی Paste بزن تا لینک‌های کپی‌شده وارد شوند.' : 'Real ADM screen: tap Paste in Editor to insert copied links.' ?></figcaption>
                    </figure>
                    <div class="bm-guide-adm-verdict">
                        <strong><?= $userLang === 'fa' ? 'روش پیشنهادی برای ADM گوشی: کپی عادی و Paste' : 'Recommended for ADM mobile: normal copy and Paste' ?></strong>
                        <p><?= $userLang === 'fa' ? 'در گوشی لازم نیست فایل TXT پیدا کنی. لینک‌های انتخابی را از بانک‌مووی کپی کن و مستقیماً داخل ADM بچسبان.' : 'On mobile, you do not need to locate a TXT file. Copy the selected links from BankMovie and paste them directly into ADM.' ?></p>
                    </div>
                    <ol class="bm-guide-real-steps">
                        <li><span>۱</span><div><b><?= $userLang === 'fa' ? 'در بانک‌مووی «کپی عادی» را انتخاب کن' : 'Choose Normal copy in BankMovie' ?></b><p><?= $userLang === 'fa' ? 'کیفیت و نسخه موردنظر را انتخاب کن و روی «کپی لینک‌ها» بزن.' : 'Select the quality and version, then tap Copy links.' ?></p></div></li>
                        <li><span>۲</span><div><b><?= $userLang === 'fa' ? 'در ADM دکمه + را بزن' : 'Tap + in ADM' ?></b><p><?= $userLang === 'fa' ? 'پنجره Editor باز می‌شود؛ همان صفحه‌ای که در تصویر می‌بینی.' : 'The Editor window opens, as shown in the screenshot.' ?></p></div></li>
                        <li><span>۳</span><div><b><?= $userLang === 'fa' ? 'روی Paste بزن و Start را انتخاب کن' : 'Tap Paste, then Start' ?></b><p><?= $userLang === 'fa' ? 'آیکن کلیپ‌بورد کنار Link را بزن؛ لینک‌ها وارد می‌شوند و دکمه Start فعال می‌شود.' : 'Tap the clipboard icon beside Link; the links are inserted and Start becomes available.' ?></p></div></li>
                    </ol>
                    <div class="bm-guide-adm-fallback">
                        <b><?= $userLang === 'fa' ? 'نکته' : 'Tip' ?></b>
                        <p><?= $userLang === 'fa' ? 'برای IDM ویندوز فایل TXT مناسب است؛ برای ADM اندروید کپی عادی و Paste ساده‌تر و مطمئن‌تر است.' : 'TXT is suitable for IDM on Windows; normal copy and Paste is simpler and more reliable for ADM on Android.' ?></p>
                    </div>
                </div>
            </div>
        </section>
        <footer class="bm-bulk-foot">
            <button type="button" class="bm-bulk-btn secondary" data-bm-bulk-close><img class="bm-cancel-icon" src="/assets/icons/bm-cancel-v3023.svg?v=3023" alt="" aria-hidden="true"><?= $userLang === 'fa' ? 'بستن' : 'Close' ?></button>
            <button type="button" class="bm-bulk-btn primary" data-bm-bulk-action="run-mode">
                <svg data-bm-primary-icon="copy" viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
                <span data-bm-primary-label><?= $userLang === 'fa' ? 'کپی لینک‌ها' : 'Copy links' ?></span>
            </button>
            <div class="bm-bulk-toast" data-bm-bulk-toast role="status" aria-live="polite"></div>
        </footer>
    </section>
</div>

<script>
<?php $bmArc2EnablePlayerCore = (!$isArc1 && !$isMovie && !empty($arc2LatestPlay['url'])); ?>
window.BM_MOVIE_CONFIG = {
  siteLabels: {
    copyLink: <?= json_encode((string)bm_site_get('player_copy_link_label_fa','کپی لینک مستقیم'), JSON_UNESCAPED_UNICODE) ?>,
    copied: <?= json_encode((string)bm_site_get('player_copied_label_fa','لینک کپی شد'), JSON_UNESCAPED_UNICODE) ?>
  },
  userLang: <?= json_encode($userLang, JSON_UNESCAPED_UNICODE) ?>,
  userId: <?= json_encode((string)($currentUser['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>,
  currentUserRole: <?= json_encode((string)($currentUser['role'] ?? 'guest'), JSON_UNESCAPED_UNICODE) ?>,
  csrfToken: <?= json_encode($csrfToken, JSON_UNESCAPED_UNICODE) ?>,
  movieId: <?= $isArc1 ? (int)$arc1VirtualMovieId : (int)($movieData['id'] ?? 0) ?>,
  archiveNo: <?= $isArc1 ? ($isArc6 ? 6 : ($isArc5 ? 5 : ($isArc4 ? 4 : ($isArc3 ? 3 : 1)))) : 2 ?>,
  archiveSlug: <?= json_encode((string)($isArc1 ? ($arc1Slug ?? '') : ''), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
  archiveSourceUrl: <?= json_encode((string)($isArc1 ? ($arc1SourceUrl ?? '') : ''), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
  archiveYear: <?= json_encode((string)($isArc1 ? ($arc1Year ?? '') : ($movieData['year'] ?? '')), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
  mediaType: <?= json_encode($isArc1 ? (($arc1IsSeries ?? false) ? 'series' : 'movie') : (($isMovie ?? true) ? 'movie' : 'series'), JSON_UNESCAPED_UNICODE) ?>,
  contentTitle: <?= json_encode((string)($isArc1 ? ($arc1Title ?? '') : ($movieData['title_fa'] ?? $movieData['title'] ?? $movieData['name'] ?? '')), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  posterUrl: <?= json_encode((string)($isArc1 ? ($arc1Poster ?? '') : (!empty($bmArc2PosterUrl ?? '') ? $bmArc2PosterUrl : (!empty($movieData['imdb_code'] ?? $imdbCode ?? '') ? ('/posters/' . rawurlencode((string)($movieData['imdb_code'] ?? $imdbCode)) . '.webp') : ''))), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  isArchive1: <?= $isArc1 ? 'true' : 'false' ?>,
  imdbCode: <?= json_encode($imdbCode, JSON_UNESCAPED_UNICODE) ?>,
  isMovie: <?= ($isMovie || $bmArc2EnablePlayerCore) ? 'true' : 'false' ?>,
  hasDub: <?= $hasDub ? 'true' : 'false' ?>,
  hasSoft: <?= $hasSoft ? 'true' : 'false' ?>,
  softLinksData: <?= json_encode($bmArchiveStreamAllowed ? $softLinks : [], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
  dubLinksData: <?= json_encode($bmArchiveStreamAllowed ? $dubLinks : [], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>,
  bestQuality: <?= json_encode($bestQuality, JSON_UNESCAPED_UNICODE) ?>,
  archiveSubFa: <?= json_encode($bmArchiveSubFa, JSON_UNESCAPED_UNICODE) ?>,
  archiveSubEn: <?= json_encode($bmArchiveSubEn, JSON_UNESCAPED_UNICODE) ?>,
  inWatchlist: <?= $inWatchlist ? 'true' : 'false' ?>,
  userRating: <?= (int)$userRating ?>,
  commentSort: <?= json_encode($commentSort ?? 'latest', JSON_UNESCAPED_UNICODE) ?>,
  commentFeatures: <?= json_encode([
      'enabled'=>(bool)($bmCommentConfig['enabled']??true),
      'replies'=>(bool)($bmCommentConfig['replies']??true),
      'votes'=>(bool)($bmCommentConfig['votes']??true),
      'reports'=>(bool)($bmCommentConfig['reports']??true),
      'spoiler'=>(bool)($bmCommentConfig['spoiler']??true),
      'edit_minutes'=>(int)($bmCommentConfig['edit_minutes']??10)
  ], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
  commentMedia: {
      enabled: <?= bm_site_bool('comment_media_enabled', true) ? 'true' : 'false' ?>,
      label: <?= json_encode($userLang === 'fa' ? (string)bm_site_get('comment_media_label_fa','استیکر و گیف') : 'Stickers & GIFs', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
      selectedText: <?= json_encode($userLang === 'fa' ? (string)bm_site_get('comment_media_selected_fa','استیکر انتخاب شد؛ می‌توانید کنارش متن هم بنویسید.') : 'Sticker selected. You can add a message too.', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
      emptyText: <?= json_encode($userLang === 'fa' ? (string)bm_site_get('comment_media_empty_fa','هنوز پک فعالی از پنل مدیریت تعریف نشده است.') : 'No active sticker packs are available yet.', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
      desktopWidth: <?= max(300,min(600,(int)bm_site_get('comment_media_desktop_width',420))) ?>,
      allowed: <?= $bmCommentMediaAllowed ? 'true' : 'false' ?>,
      vipUrl: <?= json_encode(bm_vip_sales_url('comment_media', $_SERVER['REQUEST_URI'] ?? '/'), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
      packs: <?= json_encode($bmCommentStickerCatalog, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP) ?>
  }
};
</script>
<script src="/assets/js/bm-watch-together-v14862104.js?v=14862104"></script>
<script src="/assets/js/movie-bootstrap.js?v=dl36"></script>
<script src="/assets/js/movie-play-choice-v14862100.js?v=14862100"></script>
<script src="/assets/js/movie-ui.js?v=v47-static-dock"></script>
<link rel="stylesheet" href="/assets/css/bm-comment-media-v14862020.css?v=179-windows-picker">
<script src="/assets/js/movie-comments-v14862020.js?v=179-windows-picker"></script>
<script src="/assets/js/bm-spoiler-reveal-v191.js?v=191.0"></script>
<script src="/assets/js/movie-subtitles.js?v=148619"></script>
<script src="/assets/js/bm-player-mobile-settings-v14.js?v=20261021-v14a"></script>
<script src="/assets/js/movie-player-core.js?v=subtitle-v13"></script>
<script src="/assets/js/movie-actions-v76.js?v=288.0"></script>
<script src="/assets/js/movie-init-footer.js?v=dl36"></script>
<script src="/assets/js/bm-smooth-accordions-v158.js?v=158.0"></script>
<!-- ========== FOOTER با تایپینگ هنگام اسکرول (فقط یکبار، با ایموجی) ========== -->
<?php $bmYkMovieMobile = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('mobile', 'floating') : ''; ?>
<?= $bmYkMovieMobile !== '' ? $bmYkMovieMobile : bm_render_ad_slot($pdo, 'mobile', 'floating', 1) ?>

<script src="/assets/js/movie-cinematic-v122.js?v=122" defer></script>
<script src="/assets/js/movie-bulk-copy-v123.js?v=134" defer></script>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/movie-inline-3.js?v=dl37"></script>

<?php if($isArc1 || (!$isMovie && !$isArc1)): ?>
<script src="/assets/js/movie-inline-4.js?v=dl36-v47-collapsed-seasons"></script>
<?php endif; ?>

<?php if($isArc1 && $arc1Data): ?>
<script src="/assets/js/movie-inline-5.js?v=subtitle-v13"></script>
<?php endif; ?>
<?php if($isArc1 && $arc1Data && $bmArchiveStreamAllowed): ?>
<?php
// Internal player extra audio — only direct audio-only sources already available to this viewer.
// This does not change download/stream access or replace the site's existing player.
$bmSeparateAudioCatalog = ['videos'=>[], 'audio'=>[]];
$bmAddExtraAudioRow = static function(array $entry, $season, $episode) use (&$bmSeparateAudioCatalog): void {
    $originalUrl = trim((string)($entry['url'] ?? ''));
    if ($originalUrl === '') return;
    $playableUrl = bm_archive_stream_url($originalUrl);
    if (!is_string($playableUrl) || $playableUrl === '') return;
    $audioOnly = !empty($entry['is_audio']) || !empty($entry['audio_only'])
        || strtolower((string)($entry['media_type'] ?? '')) === 'audio'
        || preg_match('~\.(?:mka|m4a|mp3|aac|ogg|opus|flac|wav)(?:[?#]|$)~i', $originalUrl);
    $item = [
        'url' => $playableUrl,
        'season' => $season === null ? '' : (string)$season,
        'episode' => $episode === null ? '' : (string)$episode,
        'quality' => trim((string)($entry['quality'] ?? '')),
        'type' => trim((string)($entry['type'] ?? '')),
    ];
    if ($audioOnly) {
        // Extract a *specific* dub studio/name. Generic UI labels aren't source names.
        // Only the server's existing permitted audio URLs are exposed here.
        $origin = (array)($entry['audio_origin'] ?? []);
        $dubName = '';
        $isGeneric = static function(string $candidate): bool {
            $candidate = trim(preg_replace('/\s+/u', ' ', $candidate) ?? $candidate);
            if ($candidate === '' || strlen($candidate) > 180) return true;
            $generic = [
                'دوبله فارسی','صوت دوبله فارسی','صوت دوبله جداگانه','فایل صوتی جداگانه',
                'فایل صوتی','دوبله','صوت دوبله','دوبله فارسی جداگانه',
                'persian dubbed','persian dubbed audio','dubbed audio',
                'separate audio','separate audio file','audio only','audio','mka','unknown',
            ];
            $fold = function_exists('mb_strtolower') ? mb_strtolower($candidate,'UTF-8') : strtolower($candidate);
            return in_array($fold, $generic, true) || preg_match('/^(?:صوت|فایل)\s*دوبله\s*(?:فارسی|جداگانه)?$/u', $candidate);
        };
        foreach (['dub_name','dub_source','audio_source','studio','audio_label','display_label','label','title','description','details'] as $nameKey) {
            $candidate = trim((string)($origin[$nameKey] ?? ($entry[$nameKey] ?? '')));
            if (!$isGeneric($candidate)) { $dubName = $candidate; break; }
        }
        if ($dubName === '') {
            foreach (($entry['meta'] ?? []) as $detail) {
                if (!is_array($detail) || ($detail['kind'] ?? '') !== 'dub') continue;
                $candidate = trim((string)($detail['value'] ?? ''));
                if (!$isGeneric($candidate)) { $dubName = $candidate; break; }
            }
        }
        if ($dubName === '') {
            // Recognize studio tokens only when they are explicitly in the filename;
            // never infer the dub source from a random signed URL or the source video.
            $path = (string)(parse_url($originalUrl, PHP_URL_PATH) ?: '');
            $file = urldecode(basename($path));
            $filenameStudios = [
                'namava'=>'نماوا','filimo'=>'فیلیمو','irib'=>'صداوسیما',
                'gapfilm'=>'گپ‌فیلم','avaajhe'=>'آواژه','avazhe'=>'آواژه',
                'soren'=>'سورن','takfilm'=>'تک‌فیلم','surena'=>'سورنا',
            ];
            foreach ($filenameStudios as $token => $display) {
                if (preg_match('/(?:^|[^a-z0-9])'.preg_quote($token,'/').'(?:[^a-z0-9]|$)/i', $file)) {
                    $dubName = 'دوبله '.$display;
                    break;
                }
            }
        }
        $item['label'] = function_exists('mb_substr') ? mb_substr($dubName, 0, 80, 'UTF-8') : substr($dubName, 0, 80);
        $bmSeparateAudioCatalog['audio'][] = $item;
    } else {
        // IMPORTANT: dubbed *video* files are valid bases for separate MKA tracks, too.
        $bmSeparateAudioCatalog['videos'][] = $item;
    }
};
if (!empty($arc1IsSeries)) {
    foreach (($arc1SeriesSeasons ?? []) as $seasonCode => $episodes) {
        if (!is_array($episodes)) continue;
        $sn = preg_replace('/\D+/', '', (string)$seasonCode);
        foreach ($episodes as $episodeCode => $rows) {
            if (!is_array($rows)) continue;
            $ep = (string)$episodeCode === 'full' ? 'full' : preg_replace('/\D+/', '', (string)$episodeCode);
            foreach ($rows as $r) if (is_array($r)) $bmAddExtraAudioRow($r, (int)$sn, $ep === 'full' ? 'full' : (int)$ep);
        }
    }
} else {
    foreach ([$arc1MovieDub ?? [], $arc1MovieSoft ?? []] as $groups) {
        if (!is_array($groups)) continue;
        foreach ($groups as $rows) {
            if (!is_array($rows)) continue;
            foreach ($rows as $r) if (is_array($r)) $bmAddExtraAudioRow($r, null, null);
        }
    }
}
?>
<?php if(!empty($bmSeparateAudioCatalog['audio']) && !empty($bmSeparateAudioCatalog['videos'])): ?>
<link rel="stylesheet" href="/assets/css/bm-player-audio-language-v14862107.css?v=14862107">
<script type="application/json" id="bmSeparateAudioCatalog"><?= json_encode($bmSeparateAudioCatalog, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<script src="/assets/js/bm-player-audio-language-v14862107.js?v=14862107"></script>
<?php endif; ?>
<?php endif; ?>
<?php if($isArc1 && $arc1Data && $bmArchiveStreamAllowed): ?>
<link rel="stylesheet" href="/assets/css/bm-player-guide-v14862109.css?v=14862109">
<script src="/assets/js/bm-player-guide-v14862109.js?v=14862109" defer></script>
<?php endif; ?>
<?php if($isArc1 && $arc1Data): ?>
<script>
window.BM_ARC1_WATCH_CONFIG = {
  loggedIn: <?= $currentUser ? 'true' : 'false' ?>,
  inList: <?= $inArc1Watch ? 'true' : 'false' ?>,
  watchId: <?= (int)($arc1WatchId??0) ?>,
  source: <?= js_json($arc1SourceUrl??'') ?>,
  title: <?= js_json($arc1Title??'') ?>,
  year: <?= js_json($arc1Year??'') ?>,
  poster: <?= js_json($arc1Poster??'') ?>,
  rate: <?= js_json($arc1ImdbRate??0) ?>,
  type: <?= js_json($arc1IsSeries?'series':'movie') ?>
};
</script>
<script src="/assets/js/movie-arc1-watchlist-v76.js?v=288.0"></script>
<?php endif; ?>


<style id="bm-comment-upgrade-styles">
.bm-comment-sort-wrap{display:flex;align-items:center;gap:8px;margin-inline-start:auto;font-size:12px;color:var(--text-secondary,#aaa)}
.bm-comment-sort{min-height:36px;border-radius:12px;border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.06);color:inherit;padding:6px 10px;outline:none}
.comment-avatar-small,.reply-avatar,.comment-form .comment-avatar{border-radius:50%!important;overflow:hidden!important;flex:0 0 auto;aspect-ratio:1/1}
.comment-avatar-small img,.reply-avatar img,.comment-form .comment-avatar img{width:100%!important;height:100%!important;object-fit:cover!important;border-radius:50%!important}
.bm-role-badge{display:inline-flex;align-items:center;justify-content:center;vertical-align:middle;margin-inline-start:4px;font-size:10px;font-weight:950;line-height:1}
.bm-role-admin{width:17px;height:17px;min-width:17px;background:transparent;color:var(--bm-admin-badge-color,#1d9bf0);font-size:0;box-shadow:none}.bm-role-admin svg{display:block;width:100%;height:100%;overflow:visible;filter:drop-shadow(0 0 5px color-mix(in srgb,var(--bm-admin-badge-color,#1d9bf0) 32%,transparent))}
.bm-role-vip{min-width:28px;height:17px;padding:0 5px;border-radius:999px;background:linear-gradient(135deg,#ffd166,#f59e0b);color:#201400}
.bm-comment-pinned,.bm-comment-edited,.bm-comment-pending{display:inline-flex;align-items:center;margin-inline-start:6px;padding:2px 7px;border-radius:999px;font-size:10px;font-weight:850}
.bm-comment-pinned{background:rgba(var(--accent-rgb,52,145,255),.15);color:var(--accent,#3491ff)}
.bm-comment-edited{background:rgba(255,255,255,.08);color:rgba(255,255,255,.62)}
.bm-comment-pending{background:rgba(245,158,11,.14);color:#fbbf24}
.bm-comment-is-pinned{border-color:rgba(var(--accent-rgb,52,145,255),.42)!important;box-shadow:0 0 0 1px rgba(var(--accent-rgb,52,145,255),.12) inset,0 10px 34px rgba(var(--accent-rgb,52,145,255),.08)}
.bm-comment-is-pending{opacity:.86;border-style:dashed!important}
.comment-actions button,.reply-actions button{border:0;background:transparent;color:var(--text-secondary,#aaa);font:inherit;cursor:pointer;padding:5px 7px;border-radius:9px}
.comment-actions button:hover,.reply-actions button:hover{background:rgba(255,255,255,.07);color:#fff}
.comment-like.active{color:#22c55e!important}.comment-dislike.active{color:#ef4444!important}
.replies-container{margin-top:12px;margin-inline-start:18px;padding-inline-start:14px;border-inline-start:2px solid rgba(var(--accent-rgb,52,145,255),.34)}
.reply-item{background:var(--bg-tertiary,rgba(255,255,255,.035));border-radius:15px;padding:12px;margin-bottom:10px}
.comment-item:target,.reply-item:target{scroll-margin-top:110px;outline:1px solid rgba(var(--accent-rgb,47,124,255),.55);box-shadow:0 0 0 4px rgba(var(--accent-rgb,47,124,255),.10),0 12px 34px rgba(0,0,0,.18)}
.bm-report-dialog-hint{font-size:11px;color:rgba(255,255,255,.55)}
@media(max-width:640px){.comments-header{gap:10px;flex-wrap:wrap}.bm-comment-sort-wrap{width:100%;justify-content:space-between}.bm-comment-sort{flex:1}.replies-container{margin-inline-start:6px;padding-inline-start:9px}.comment-actions,.reply-actions{flex-wrap:wrap}}
</style>
<script>
(function(){
  const cfg=window.BM_MOVIE_CONFIG||{};
  const post=async(data)=>{
    const body=new URLSearchParams();
    Object.entries(data).forEach(([k,v])=>body.append(k,String(v??'')));
    const res=await fetch('/ajax_comments.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'},body,credentials:'same-origin'});
    const json=await res.json().catch(()=>({success:false,error:'پاسخ نامعتبر سرور'}));
    if(!res.ok && !json.error) json.error='خطای ارتباط با سرور';
    return json;
  };
  const base=(action,id)=>({action,comment_id:id,movie_id:cfg.movieId||0,archive:cfg.isArchive1?'1':'2',csrf_token:cfg.csrfToken||''});
  document.addEventListener('change',e=>{
    const select=e.target.closest('.bm-comment-sort'); if(!select)return;
    const u=new URL(location.href);u.searchParams.set('comment_sort',select.value);u.searchParams.delete('comment_page');location.href=u.toString();
  });
  document.addEventListener('click',async e=>{
    const edit=e.target.closest('.edit-comment-btn');
    if(edit){
      e.preventDefault();
      const old=edit.dataset.text||'';
      const text=await window.BMDialog.prompt({
        title:'ویرایش دیدگاه',
        message:'متن دیدگاه را اصلاح کن و سپس ذخیره را بزن.',
        label:'متن دیدگاه',
        value:old,
        confirmText:'ذخیره تغییرات',
        cancelText:'انصراف',
        multiline:true
      });
      if(text===null)return;
      const spoiler=await window.BMDialog.confirm({
        title:'وضعیت اسپویلر',
        message:'این دیدگاه شامل اسپویلر است؟',
        confirmText:'بله، اسپویلر است',
        cancelText:'خیر'
      }) ? 1 : 0;
      const r=await post({...base('edit_comment',edit.dataset.id),new_comment:text,spoiler});
      await window.BMDialog.alert({
        title:r.success?'انجام شد':'خطا',
        message:r.success?'دیدگاه ویرایش شد.':(r.error||'ویرایش انجام نشد.'),
        icon:r.success?'info':'danger'
      });
      if(r.success)location.reload();
      return;
    }
    const pin=e.target.closest('.pin-comment-btn');
    if(pin){
      e.preventDefault();
      const r=await post({...base('pin_comment',pin.dataset.id),pin:pin.dataset.pin||'0'});
      await window.BMDialog.alert({
        title:r.success?'انجام شد':'خطا',
        message:r.success?'وضعیت پین تغییر کرد.':(r.error||'عملیات ناموفق بود.'),
        icon:r.success?'info':'danger'
      });
      if(r.success)location.reload();
      return;
    }
    const report=e.target.closest('.report-comment-btn');
    if(report){
      e.preventDefault();
      const reason=await window.BMDialog.select({
        title:'گزارش تخلف دیدگاه',
        message:'دلیل گزارش را انتخاب کن.',
        value:'other',
        confirmText:'ادامه',
        cancelText:'انصراف',
        options:[
          {value:'insult',label:'توهین'},
          {value:'spam',label:'اسپم'},
          {value:'spoiler',label:'اسپویلر بدون هشدار'},
          {value:'inappropriate',label:'محتوای نامناسب'},
          {value:'wrong_info',label:'اطلاعات اشتباه'},
          {value:'other',label:'سایر'}
        ]
      });
      if(reason===null)return;
      const details=await window.BMDialog.prompt({
        title:'توضیحات گزارش',
        message:'اگر توضیح بیشتری لازم است بنویس؛ این بخش اختیاری است.',
        label:'توضیح اختیاری',
        value:'',
        confirmText:'ارسال گزارش',
        cancelText:'انصراف',
        multiline:true
      });
      if(details===null)return;
      const r=await post({...base('report_comment',report.dataset.id),reason,details});
      await window.BMDialog.alert({
        title:r.success?'گزارش ثبت شد':'خطا',
        message:r.success?'گزارش برای مدیر ارسال شد.':(r.error||'ارسال گزارش انجام نشد.'),
        icon:r.success?'info':'danger'
      });
      return;
    }
  });
})();
</script>

<script id="bm-player-surface-guard-v25">
(function(){
  'use strict';
  function protectPlayerSurface(){
    var videos=[document.getElementById('videoPlayer'),document.getElementById('arc1VideoEl')].filter(Boolean);
    videos.forEach(function(v){
      try{ v.setAttribute('controlslist','nodownload noremoteplayback'); }catch(e){}
      try{ v.setAttribute('disableremoteplayback',''); v.disableRemotePlayback=true; }catch(e){}
      try{ v.setAttribute('disablepictureinpicture',''); v.disablePictureInPicture=true; }catch(e){}
      try{ v.setAttribute('draggable','false'); }catch(e){}
    });
  }
  function insidePlayer(target){
    return !!(target && target.closest && target.closest('#playerWrapper,#arc1PlayerWrapper,#arc1PlayerInner,.player-wrapper'));
  }
  document.addEventListener('contextmenu',function(e){ if(insidePlayer(e.target)){ e.preventDefault(); e.stopPropagation(); } },true);
  document.addEventListener('dragstart',function(e){ if(insidePlayer(e.target)){ e.preventDefault(); e.stopPropagation(); } },true);
  document.addEventListener('auxclick',function(e){ if(insidePlayer(e.target)){ e.preventDefault(); e.stopPropagation(); } },true);
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',protectPlayerSurface,{once:true});
  else protectPlayerSurface();
})();
</script>

<script src="/assets/js/movie-inline-6.js?v=dl36"></script>

<script src="/assets/js/movie-inline-7.js?v=dl37"></script>


<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>
<?php bm_perf_mark('html-complete'); ?>



<script src="/assets/js/bm-uiverse-elements-v45.js?v=45.0" defer></script>

<link rel="stylesheet" href="/assets/css/bm-heart-watchlist-v44.css?v=44.0">



<style id="bm-download-feedback-v26">
/* BankMovie premium download feedback — visual only; download navigation remains native. */
.bm-download-feedback-btn{position:relative!important;overflow:hidden!important;isolation:isolate;transition:transform .22s ease,border-color .22s ease,box-shadow .22s ease,background .22s ease!important}
.bm-download-feedback-btn::before{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(110deg,transparent 12%,rgba(255,255,255,.12) 45%,transparent 72%);transform:translateX(-125%);pointer-events:none}
.bm-download-feedback-btn.is-bm-downloading{pointer-events:none;transform:translateY(-1px) scale(.985);border-color:rgba(var(--accent-rgb,91,91,240),.55)!important;box-shadow:0 0 0 1px rgba(var(--accent-rgb,91,91,240),.12) inset,0 10px 28px rgba(var(--accent-rgb,91,91,240),.18)!important}
.bm-download-feedback-btn.is-bm-downloading::before{animation:bmDlShimmer 1.05s ease-in-out infinite}
.bm-download-feedback-btn.is-bm-done{border-color:rgba(34,197,94,.55)!important;box-shadow:0 0 0 1px rgba(34,197,94,.12) inset,0 10px 28px rgba(34,197,94,.16)!important}
.bm-dl-feedback-content{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-width:0;white-space:nowrap}
.bm-dl-feedback-spinner{width:16px;height:16px;display:inline-block;border-radius:50%;border:2px solid rgba(255,255,255,.26);border-top-color:#fff;animation:bmDlSpin .72s linear infinite;flex:0 0 auto}
.bm-dl-feedback-check{width:17px;height:17px;display:inline-flex;align-items:center;justify-content:center;border-radius:50%;background:#22c55e;color:#06150a;font-size:12px;font-weight:1000;box-shadow:0 0 18px rgba(34,197,94,.35);flex:0 0 auto;animation:bmDlCheckIn .32s cubic-bezier(.2,.9,.25,1.35)}
#bmDownloadToast{position:fixed;top:max(18px,env(safe-area-inset-top));left:50%;z-index:2147482000;transform:translate(-50%,-18px) scale(.96);opacity:0;visibility:hidden;pointer-events:none;width:min(430px,calc(100vw - 28px));transition:opacity .28s ease,transform .34s cubic-bezier(.2,.8,.2,1),visibility .28s;background:linear-gradient(145deg,rgba(17,24,39,.88),rgba(9,12,20,.82));border:1px solid rgba(255,255,255,.13);border-radius:20px;box-shadow:0 22px 70px rgba(0,0,0,.42),0 0 0 1px rgba(var(--accent-rgb,91,91,240),.08) inset;backdrop-filter:blur(22px) saturate(145%);-webkit-backdrop-filter:blur(22px) saturate(145%);overflow:hidden;color:#fff;direction:rtl}
#bmDownloadToast.is-show{opacity:1;visibility:visible;transform:translate(-50%,0) scale(1)}
#bmDownloadToast.is-success{border-color:rgba(34,197,94,.24)}
.bm-dl-toast-inner{display:grid;grid-template-columns:46px minmax(0,1fr);gap:12px;align-items:center;padding:12px 14px}
.bm-dl-toast-icon{width:46px;height:46px;border-radius:15px;display:grid;place-items:center;background:radial-gradient(circle at 35% 20%,rgba(255,255,255,.20),rgba(var(--accent-rgb,91,91,240),.24) 45%,rgba(var(--accent-rgb,91,91,240),.08));border:1px solid rgba(var(--accent-rgb,91,91,240),.25);box-shadow:0 8px 28px rgba(var(--accent-rgb,91,91,240),.16)}
#bmDownloadToast.is-success .bm-dl-toast-icon{background:radial-gradient(circle at 35% 20%,rgba(255,255,255,.2),rgba(34,197,94,.24) 48%,rgba(34,197,94,.07));border-color:rgba(34,197,94,.28);box-shadow:0 8px 28px rgba(34,197,94,.15)}
.bm-dl-toast-icon svg{width:22px;height:22px;fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.bm-dl-toast-copy{min-width:0}.bm-dl-toast-title{font-size:13px;font-weight:950;line-height:1.45;letter-spacing:-.1px}.bm-dl-toast-file{margin-top:3px;font-size:11px;font-weight:700;color:rgba(255,255,255,.52);direction:ltr;unicode-bidi:plaintext;text-align:right;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.bm-dl-toast-track{height:2px;background:rgba(255,255,255,.06);overflow:hidden}.bm-dl-toast-bar{height:100%;width:34%;background:linear-gradient(90deg,transparent,var(--accent,#7c5cff),#fff,var(--accent,#7c5cff),transparent);transform:translateX(-120%);animation:bmDlBar 1.15s ease-in-out infinite}
#bmDownloadToast.is-success .bm-dl-toast-bar{width:100%;transform:none;animation:none;background:#22c55e;transition:width .28s ease}
@keyframes bmDlSpin{to{transform:rotate(360deg)}}
@keyframes bmDlShimmer{to{transform:translateX(125%)}}
@keyframes bmDlBar{0%{transform:translateX(-150%)}100%{transform:translateX(420%)}}
@keyframes bmDlCheckIn{from{transform:scale(.45);opacity:.2}to{transform:scale(1);opacity:1}}
@media(max-width:640px){#bmDownloadToast{top:max(12px,env(safe-area-inset-top));border-radius:17px}.bm-dl-toast-inner{grid-template-columns:40px minmax(0,1fr);padding:10px 12px}.bm-dl-toast-icon{width:40px;height:40px;border-radius:13px}.bm-dl-toast-title{font-size:12px}.bm-dl-toast-file{font-size:10px}}
@media(prefers-reduced-motion:reduce){.bm-download-feedback-btn,#bmDownloadToast{transition:none!important}.bm-dl-feedback-spinner,.bm-download-feedback-btn::before,.bm-dl-toast-bar{animation:none!important}}
</style>
<script id="bm-download-feedback-v26-script">
(function(){
  'use strict';
  var isFa = <?= (($userLang ?? 'fa') === 'fa') ? 'true' : 'false' ?>;
  var toastTimer=0;
  function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c];});}
  function getFileName(href){
    try{
      var u=new URL(href,location.href), p=decodeURIComponent(u.pathname||''), n=p.split('/').filter(Boolean).pop()||'';
      return n.length>92?n.slice(0,89)+'…':n;
    }catch(e){return '';}
  }
  function ensureToast(){
    var t=document.getElementById('bmDownloadToast'); if(t)return t;
    t=document.createElement('div');t.id='bmDownloadToast';t.setAttribute('role','status');t.setAttribute('aria-live','polite');
    t.innerHTML='<div class="bm-dl-toast-inner"><div class="bm-dl-toast-icon" data-bm-dl-toast-icon></div><div class="bm-dl-toast-copy"><div class="bm-dl-toast-title" data-bm-dl-toast-title></div><div class="bm-dl-toast-file" data-bm-dl-toast-file></div></div></div><div class="bm-dl-toast-track"><div class="bm-dl-toast-bar"></div></div>';
    document.body.appendChild(t);return t;
  }
  function iconLoading(){return '<svg viewBox="0 0 24 24"><path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M5 21h14"/></svg>';}
  function showToast(href){
    var t=ensureToast(), file=getFileName(href);
    clearTimeout(toastTimer);
    t.classList.remove('is-success');
    t.querySelector('[data-bm-dl-toast-icon]').innerHTML=iconLoading();
    t.querySelector('[data-bm-dl-toast-title]').textContent=isFa?'در حال دانلود…':'Downloading…';
    t.querySelector('[data-bm-dl-toast-file]').textContent=file|| (isFa?'لینک امن BankMovie':'Secure BankMovie link');
    requestAnimationFrame(function(){t.classList.add('is-show');});
    toastTimer=setTimeout(function(){t.classList.remove('is-show');},2200);
  }
  function isDownloadLink(a){
    if(!a || !a.href)return false;
    if(a.matches('[data-bm-download-only="1"],.arc1-dl-btn,.download-icon,.arc1-sub-dl-btn'))return true;
    try{return new URL(a.href,location.href).hostname.toLowerCase()==='dl10.bankmovie.top';}catch(e){return false;}
  }
  function animateButton(a){
    if(a.dataset.bmDlBusy==='1')return;
    a.dataset.bmDlBusy='1';
    var original=a.innerHTML;
    var originalAria=a.getAttribute('aria-label');
    a.classList.add('bm-download-feedback-btn','is-bm-downloading');
    a.innerHTML='<span class="bm-dl-feedback-content"><span class="bm-dl-feedback-spinner"></span><span>'+(isFa?'در حال دانلود…':'Starting…')+'</span></span>';
    a.setAttribute('aria-label',isFa?'در حال دانلود':'Downloading');
    setTimeout(function(){
      a.classList.remove('is-bm-downloading');a.innerHTML=original;delete a.dataset.bmDlBusy;
      if(originalAria===null)a.removeAttribute('aria-label');else a.setAttribute('aria-label',originalAria);
    },1800);
  }
  document.addEventListener('click',function(e){
    var a=e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if(!isDownloadLink(a))return;
    animateButton(a);showToast(a.href);
    /* Intentionally do not preventDefault(): the existing DL10/download behavior stays untouched. */
  },true);
})();
</script>




<style id="bm-archive2-db-premium-v14">
/* Archive 2 DB now inherits Archive 1 cards 1:1; only extra technical token colors live here. */
.bm-archive2-native .bm-arc1-meta-pill.is-bitdepth{--bm-tag-color:191,94,255;--bm-tag-strong:#efd0ff;background:radial-gradient(circle at 18% 0%,rgba(191,94,255,.36),transparent 44%),linear-gradient(145deg,rgba(111,50,190,.30),rgba(17,10,29,.95) 57%,rgba(232,102,255,.10))}
.bm-archive2-native .bm-arc1-meta-pill.is-audio{--bm-tag-color:54,201,160;--bm-tag-strong:#b4ffe8}
.bm-archive2-native .bm-arc1-meta-pill.is-hdr{--bm-tag-color:255,89,130;--bm-tag-strong:#ffc2d3}
/* Soft-sub in download cards is deliberately text-only: no duplicate CC icon. */
.bm-archive2-native .download-type-badge.is-soft svg{display:none!important}
</style>
<!-- BM-ARCHIVE2-DB-FINAL-V14 -->
<style id="bm-archive-shared-rich-meta-v15">
/* Premium archive-1 media metadata — visual-only hotfix */
.bm-arc1-rich-meta{
    display:flex;
    align-items:center;
    flex-wrap:wrap;
    gap:8px;
    margin-top:9px;
    direction:ltr;
}
.bm-arc1-meta-pill{
    --bm-tag-color:188,200,224;
    --bm-tag-strong:#dbe5f7;
    position:relative;
    isolation:isolate;
    overflow:hidden;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    min-height:30px;
    max-width:100%;
    padding:0 13px 0 12px;
    border-radius:11px;
    border:1px solid rgba(var(--bm-tag-color),.34);
    background:
        radial-gradient(circle at 18% 0%,rgba(var(--bm-tag-color),.25),transparent 42%),
        linear-gradient(145deg,rgba(var(--bm-tag-color),.14),rgba(10,13,22,.92) 54%,rgba(var(--bm-tag-color),.075));
    color:var(--bm-tag-strong);
    font-size:10.5px;
    font-weight:950;
    line-height:1;
    letter-spacing:.035em;
    white-space:nowrap;
    text-shadow:0 0 14px rgba(var(--bm-tag-color),.32);
    box-shadow:
        0 8px 20px rgba(0,0,0,.24),
        0 0 0 1px rgba(255,255,255,.025) inset,
        0 1px 0 rgba(255,255,255,.11) inset,
        0 -10px 24px rgba(var(--bm-tag-color),.05) inset;
    backdrop-filter:blur(12px) saturate(125%);
    -webkit-backdrop-filter:blur(12px) saturate(125%);
    transition:transform .22s ease,border-color .22s ease,box-shadow .22s ease,filter .22s ease;
}
.bm-arc1-meta-pill:before{
    content:"";
    width:8px;
    height:8px;
    flex:0 0 8px;
    border-radius:3px;
    transform:rotate(45deg);
    background:linear-gradient(135deg,#fff,var(--bm-tag-strong) 48%,rgba(var(--bm-tag-color),.65));
    box-shadow:0 0 0 3px rgba(var(--bm-tag-color),.10),0 0 15px rgba(var(--bm-tag-color),.72);
}
.bm-arc1-meta-pill:after{
    content:"";
    position:absolute;
    z-index:-1;
    top:-55%;
    bottom:-55%;
    left:-42%;
    width:34%;
    transform:skewX(-20deg);
    background:linear-gradient(90deg,transparent,rgba(255,255,255,.20),transparent);
    opacity:.7;
    transition:left .55s ease;
}
.bm-arc1-meta-pill:hover{
    transform:translateY(-2px);
    border-color:rgba(var(--bm-tag-color),.58);
    filter:saturate(1.12);
    box-shadow:
        0 12px 28px rgba(0,0,0,.34),
        0 0 22px rgba(var(--bm-tag-color),.13),
        0 1px 0 rgba(255,255,255,.15) inset;
}
.bm-arc1-meta-pill:hover:after{left:118%}
.bm-arc1-meta-pill b{
    direction:rtl;
    color:rgba(255,255,255,.58);
    font-size:9px;
    font-weight:900;
    letter-spacing:0;
}
.bm-arc1-meta-pill span{direction:ltr;unicode-bidi:plaintext}

/* Distinct premium identities */
.bm-arc1-meta-pill.is-format{
    --bm-tag-color:69,155,255;
    --bm-tag-strong:#bdddff;
}
.bm-arc1-meta-pill.is-codec{
    --bm-tag-color:162,105,255;
    --bm-tag-strong:#dfc9ff;
}
.bm-arc1-meta-pill.is-encoder{
    --bm-tag-color:255,193,92;
    --bm-tag-strong:#ffe1a0;
}
.bm-arc1-meta-pill.is-dub{
    --bm-tag-color:34,211,153;
    --bm-tag-strong:#9af3d1;
    direction:rtl;
}
.bm-arc1-meta-pill.is-dub span{direction:rtl;unicode-bidi:normal}

/* Source-specific finishes */
.bm-arc1-meta-pill[data-meta="BluRay"]{
    --bm-tag-color:52,184,255;
    --bm-tag-strong:#b9ecff;
    background:radial-gradient(circle at 18% 0%,rgba(52,184,255,.34),transparent 45%),linear-gradient(145deg,rgba(26,111,204,.30),rgba(8,15,29,.94) 57%,rgba(64,201,255,.11));
}
.bm-arc1-meta-pill[data-meta="WEB-DL"]{
    --bm-tag-color:73,123,255;
    --bm-tag-strong:#d3dcff;
    background:radial-gradient(circle at 16% 0%,rgba(151,82,255,.34),transparent 43%),linear-gradient(145deg,rgba(69,70,219,.29),rgba(10,12,28,.95) 55%,rgba(63,191,255,.12));
}
.bm-arc1-meta-pill[data-meta="WEBRip"]{
    --bm-tag-color:193,91,255;
    --bm-tag-strong:#edc6ff;
}
.bm-arc1-meta-pill[data-meta="Remux"]{
    --bm-tag-color:255,190,74;
    --bm-tag-strong:#ffe2a3;
}
.bm-arc1-meta-pill[data-meta="HDTV"]{
    --bm-tag-color:40,211,196;
    --bm-tag-strong:#a9fff3;
}

/* Codec-specific finishes */
.bm-arc1-meta-pill[data-meta="x265"],
.bm-arc1-meta-pill[data-meta="HEVC"],
.bm-arc1-meta-pill[data-meta*="x265"]{
    --bm-tag-color:37,211,146;
    --bm-tag-strong:#a4f4d1;
    background:radial-gradient(circle at 18% 0%,rgba(37,211,146,.30),transparent 44%),linear-gradient(145deg,rgba(21,139,99,.25),rgba(8,20,19,.94) 58%,rgba(37,211,146,.08));
}
.bm-arc1-meta-pill[data-meta="x264"]{
    --bm-tag-color:255,142,70;
    --bm-tag-strong:#ffd0ad;
}
.bm-arc1-meta-pill[data-meta="AV1"]{
    --bm-tag-color:255,76,138;
    --bm-tag-strong:#ffc0d7;
}
.bm-arc1-meta-pill[data-meta="10Bit"],
.bm-arc1-meta-pill[data-meta*="10Bit"]{
    --bm-tag-color:191,94,255;
    --bm-tag-strong:#efd0ff;
    background:radial-gradient(circle at 18% 0%,rgba(191,94,255,.36),transparent 44%),linear-gradient(145deg,rgba(111,50,190,.30),rgba(17,10,29,.95) 57%,rgba(232,102,255,.10));
}

.bm-movie-download-row .download-card-left{align-items:center;min-width:0}
.bm-movie-download-row .link-info{min-width:0;display:flex;flex-direction:column;align-items:flex-start}
.bm-movie-download-row .quality{white-space:normal;line-height:1.35;font-size:13px;font-weight:950}
.bm-movie-download-row .size{margin-top:3px}
@media(max-width:760px){
    .bm-movie-download-row{align-items:flex-start}
    .bm-movie-download-row .download-card-left{width:100%;align-items:flex-start}
    .bm-arc1-rich-meta{gap:6px;margin-top:7px}
    .bm-arc1-meta-pill{min-height:27px;padding:0 10px 0 9px;font-size:9.5px;border-radius:10px}
    .bm-arc1-meta-pill:before{width:7px;height:7px;flex-basis:7px;border-radius:2px}
    .bm-arc1-meta-pill b{font-size:8.5px}
}
@media(prefers-reduced-motion:reduce){
    .bm-arc1-meta-pill,.bm-arc1-meta-pill:after{transition:none!important}
}
</style>

<style id="bm-archive2-shared-parity-v15">
/* V1.5: Archive 2 consumes the exact Archive-1 premium metadata styling globally. */
.bm-archive2-native .bm-arc1-rich-meta{display:flex!important;align-items:center!important;flex-wrap:wrap!important;gap:8px!important;margin-top:9px!important;direction:ltr!important}
.bm-archive2-native .download-type-badge.is-soft svg{display:none!important}
.bm-archive2-native .download-type-badge.is-soft{gap:0!important}
</style>


<style id="bm-movie-light-modal-and-badge-v14862044">
/* V14862044 — true light player modals + preserve metadata colors without white gloss. */
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal{
  background:rgba(15,23,42,.24)!important;-webkit-backdrop-filter:blur(6px)!important;backdrop-filter:blur(6px)!important;
}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal :is(.bm-play-choice-modal,.bm-play-choice-head,.bm-play-choice-body,.bm-play-choice-foot){
  background:#fff!important;background-image:none!important;color:#111827!important;border-color:#dce3ea!important;
}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-option,
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-option:hover,
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-option:active{
  background:#f8fafc!important;background-image:none!important;color:#111827!important;border:1px solid #dce3ea!important;
  box-shadow:none!important;filter:none!important;-webkit-filter:none!important;opacity:1!important;
}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-option-text b{
  color:#111827!important;opacity:1!important;text-shadow:none!important;-webkit-text-fill-color:#111827!important;
}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-option-text span{
  color:#5f6b78!important;opacity:1!important;text-shadow:none!important;-webkit-text-fill-color:#5f6b78!important;
}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-choice-title strong{color:#111827!important;opacity:1!important}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-choice-title span{color:#5f6b78!important;opacity:1!important}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-choice-close{background:#f6f8fa!important;color:#253142!important;border-color:#dce3ea!important;box-shadow:none!important}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-platform-hint{background:#f7f9fb!important;color:#4f5b68!important;border-color:#dce3ea!important}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-softsub-notice{background:#fff8e8!important;color:#624a0c!important;border-color:#ebcf84!important}
html[data-bm-color-mode="light"] body.movie-page #bmPlayChoiceModal .bm-play-copy-link{background:#fff5ec!important;color:#27313d!important;border-color:#efc29f!important;box-shadow:none!important}

html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown),
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) .settings-panel,
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) .settings-modal-header,
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) .settings-panel-scroll{
  background:#fff!important;background-image:none!important;color:#111827!important;border-color:#dce3ea!important;
  box-shadow:none!important;filter:none!important;-webkit-filter:none!important;opacity:1!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) :is(.settings-row,.settings-choice,.setting-row,.setting-choice,.settings-range-card,.settings-sync-btn){
  background:#f8fafc!important;background-image:none!important;color:#111827!important;border-color:#dce3ea!important;
  box-shadow:none!important;filter:none!important;-webkit-filter:none!important;opacity:1!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) :is(.settings-modal-title,.settings-row-title,.settings-choice-title,.settings-mini-label,.setting-text strong,.settings-range-head,.settings-range-head span,.settings-range-head strong){
  color:#111827!important;opacity:1!important;text-shadow:none!important;-webkit-text-fill-color:#111827!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) :is(.settings-modal-subtitle,.settings-row-desc,.settings-choice-desc,.setting-text small,.setting-note,.settings-row-value,.setting-value,.subtitle-position-hint){
  color:#5f6b78!important;opacity:1!important;text-shadow:none!important;-webkit-text-fill-color:#5f6b78!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) :is(.settings-back-btn,.settings-close,.settings-row-icon){
  background:#f3f6f9!important;color:#253142!important;border-color:#dce3ea!important;box-shadow:none!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) .subtitle-color-btn{
  background:#fff!important;border-color:#d1d8e0!important;box-shadow:none!important;filter:none!important;
}
html[data-bm-color-mode="light"] body.movie-page :is(#settingsDropdown,#arc1SettingsDropdown) .subtitle-color-btn.active{
  border-color:var(--accent)!important;box-shadow:0 0 0 2px rgba(var(--accent-rgb),.12)!important;
}

/* Download source / encoder / codec pills: preserve each original authored color.
   Remove ONLY the white glass/gloss/shine effect. */
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .bm-arc1-meta-pill{
  box-shadow:0 3px 8px rgba(15,23,42,.14)!important;
  -webkit-box-shadow:0 3px 8px rgba(15,23,42,.14)!important;
  filter:none!important;-webkit-filter:none!important;-webkit-backdrop-filter:none!important;backdrop-filter:none!important;
  opacity:1!important;text-shadow:none!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .bm-arc1-meta-pill::after{
  display:none!important;content:none!important;opacity:0!important;background:none!important;
  box-shadow:none!important;-webkit-box-shadow:none!important;filter:none!important;-webkit-filter:none!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .bm-arc1-meta-pill::before{
  box-shadow:none!important;-webkit-box-shadow:none!important;filter:none!important;-webkit-filter:none!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .bm-arc1-meta-pill :is(b,span){
  color:var(--bm-tag-strong,#fff)!important;opacity:1!important;font-weight:950!important;
  text-shadow:none!important;filter:none!important;-webkit-filter:none!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .arc1-ep-badges>span{
  box-shadow:none!important;-webkit-box-shadow:none!important;filter:none!important;-webkit-filter:none!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .arc1-dl-btn{
  background:#12d68a!important;background-image:none!important;color:#063321!important;border-color:#0dbb77!important;
  box-shadow:none!important;text-shadow:none!important;filter:none!important;opacity:1!important;font-weight:950!important;
}
html[data-bm-color-mode="light"] body.movie-page #arc1DownloadSection .arc1-play-inline{
  box-shadow:none!important;text-shadow:none!important;filter:none!important;opacity:1!important;font-weight:950!important;
}
</style>
<style id="bm-download-link-icons-v276">
#arc1DownloadSection .arc1-play-inline,
#downloadSection .arc1-play-inline,
#arc1DownloadSection .arc1-dl-btn,
#downloadSection .arc1-dl-btn,
#arc1DownloadSection .download-icon,
#downloadSection .download-icon{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:8px!important}
#arc1DownloadSection .arc1-play-inline svg.bm-link-btn-icon,
#downloadSection .arc1-play-inline svg.bm-link-btn-icon,
#arc1DownloadSection .arc1-dl-btn svg.bm-link-btn-icon,
#downloadSection .arc1-dl-btn svg.bm-link-btn-icon,
#arc1DownloadSection .download-icon svg.bm-link-btn-icon,
#downloadSection .download-icon svg.bm-link-btn-icon{width:18px;height:18px;flex:0 0 18px;display:block}
#arc1DownloadSection .arc1-play-inline svg.bm-link-btn-icon-play path,
#downloadSection .arc1-play-inline svg.bm-link-btn-icon-play path{fill:currentColor}
#arc1DownloadSection .arc1-dl-btn svg.bm-link-btn-icon-download path,
#downloadSection .arc1-dl-btn svg.bm-link-btn-icon-download path,
#arc1DownloadSection .download-icon svg.bm-link-btn-icon-download path,
#downloadSection .download-icon svg.bm-link-btn-icon-download path{vector-effect:non-scaling-stroke}
#arc1DownloadSection .bm-download-feedback-btn svg.bm-link-btn-icon,
#downloadSection .bm-download-feedback-btn svg.bm-link-btn-icon{display:none!important}
.movie-page .download-link .download-icon:not(.arc4-subtitle-direct)::before{display:none!important;content:none!important}
</style>
<link rel="stylesheet" href="/assets/css/bm-movie-mobile-adaptive-v284.css?v=284.0">
<script src="/assets/js/bm-movie-mobile-info-v284.js?v=284.0" defer></script>

<style id="bm-narrow-desktop-download-fix-v289">
/* Narrow desktop/window fix: avoid download-card metadata/actions collision without changing real mobile layout. */
@media (min-width:481px) and (max-width:900px) and (hover:hover) and (pointer:fine){
  body.movie-page #arc1DownloadSection .arc1-link-row,
  body.movie-page #downloadSection .arc1-link-row,
  body.movie-page #arc1DownloadSection .download-link.premium-download-card,
  body.movie-page #downloadSection .download-link.premium-download-card,
  body.movie-page #arc1DownloadSection .bm-movie-download-row,
  body.movie-page #downloadSection .bm-movie-download-row{
    display:flex!important;
    flex-direction:column!important;
    align-items:stretch!important;
    justify-content:flex-start!important;
    gap:12px!important;
    min-height:0!important;
    padding:13px 14px!important;
  }
  body.movie-page #arc1DownloadSection :is(.arc1-link-meta,.download-card-left),
  body.movie-page #downloadSection :is(.arc1-link-meta,.download-card-left){
    width:100%!important;
    max-width:100%!important;
    min-width:0!important;
    align-items:flex-start!important;
  }
  body.movie-page #arc1DownloadSection :is(.link-info,.bm-archive2-link-info,.bm-arc1-rich-meta),
  body.movie-page #downloadSection :is(.link-info,.bm-archive2-link-info,.bm-arc1-rich-meta){
    min-width:0!important;
    max-width:100%!important;
  }
  body.movie-page #arc1DownloadSection .bm-arc1-rich-meta,
  body.movie-page #downloadSection .bm-arc1-rich-meta{
    display:flex!important;
    flex-wrap:wrap!important;
    gap:6px!important;
  }
  body.movie-page #arc1DownloadSection .arc1-link-actions,
  body.movie-page #downloadSection .arc1-link-actions,
  body.movie-page #arc1DownloadSection .bm-movie-download-row > div:last-child,
  body.movie-page #downloadSection .bm-movie-download-row > div:last-child,
  body.movie-page #arc1DownloadSection .bm-watch-together-host,
  body.movie-page #downloadSection .bm-watch-together-host{
    position:static!important;
    width:100%!important;
    max-width:100%!important;
    display:flex!important;
    align-items:center!important;
    justify-content:flex-start!important;
    gap:8px!important;
    flex-wrap:wrap!important;
    flex-shrink:1!important;
  }
  body.movie-page #arc1DownloadSection :is(.arc1-play-inline,.arc1-dl-btn,.download-icon,.arc1-sub-dl-btn,.bm-watch-together-btn),
  body.movie-page #downloadSection :is(.arc1-play-inline,.arc1-dl-btn,.download-icon,.arc1-sub-dl-btn,.bm-watch-together-btn){
    flex:0 0 auto!important;
    width:auto!important;
    min-width:0!important;
    max-width:100%!important;
    white-space:nowrap!important;
  }
  body.movie-page #arc1DownloadSection .download-link:hover,
  body.movie-page #downloadSection .download-link:hover{transform:none!important}
}
</style>

<style id="bm-desktop-cast-compact-v290">
/* Desktop cast rail: compact cards, no details pill. Mobile stays unchanged. */
@media (min-width:992px){
  body.movie-page .bm-arc1-actors-section{
    margin-top:6px!important;
  }
  body.movie-page .bm-arc1-actors-list{
    gap:6px!important;
    padding:1px 1px 5px!important;
  }
  body.movie-page .bm-arc1-actor-card,
  body.movie-page .bm-local-actor-card{
    flex:0 0 76px!important;
    width:76px!important;
    min-width:76px!important;
    max-width:76px!important;
    min-height:82px!important;
    padding:6px 5px!important;
    gap:4px!important;
    border-radius:12px!important;
  }
  body.movie-page .bm-arc1-actor-photo-wrap,
  body.movie-page .bm-local-actor-avatar,
  body.movie-page .bm-arc1-actor-text-icon{
    width:46px!important;
    height:46px!important;
    min-width:46px!important;
    min-height:46px!important;
    flex:0 0 46px!important;
    border-radius:50%!important;
  }
  body.movie-page .bm-arc1-actor-photo{
    width:100%!important;
    height:100%!important;
    border-radius:50%!important;
    object-fit:cover!important;
  }
  body.movie-page .bm-arc1-actor-text-icon svg,
  body.movie-page .bm-local-actor-avatar svg{
    width:24px!important;
    height:24px!important;
    padding:0!important;
  }
  body.movie-page .bm-arc1-actor-name,
  body.movie-page .bm-local-actor-name{
    font-size:9px!important;
    line-height:1.3!important;
    -webkit-line-clamp:2!important;
  }
  body.movie-page .bm-arc1-actor-role{
    display:none!important;
  }
  body.movie-page .bm-actor-detail-pill{
    display:none!important;
  }
  body.movie-page .bm-arc1-section-head{
    margin-bottom:6px!important;
  }
}
</style>
<style id="bm-arc2-story-actor-fallback-v1">
/* Archive 2: consistent story contrast even when the surrounding page is light.
   The story content still comes from the original movies.description field. */
body.movie-page[data-bm-archive="archive2"] .bm-story-summary{
  background:#142034!important;
  border:1px solid rgba(112,160,218,.26)!important;
  color:#eef6ff!important;
  text-shadow:none!important;
  box-shadow:0 9px 24px rgba(7,15,28,.13)!important;
}
body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-story-summary-head{
  color:#f3f8ff!important;text-shadow:none!important;
}
body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-readmore-content{
  color:#e0ecfa!important;opacity:1!important;text-shadow:none!important;
}
body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-readmore-btn{
  color:#9ed4ff!important;border-color:rgba(158,212,255,.36)!important;
}
body.movie-page[data-bm-archive="archive2"] .bm-story-summary.is-readmore-needed[data-collapsed="1"]::after{
  background:linear-gradient(180deg,rgba(20,32,52,0),rgba(20,32,52,.97))!important;
}
/* In LIGHT mode Archive 2 must match the surrounding white details cards.
   Scoped to light mode so the existing dark appearance stays unchanged. */
html[data-bm-color-mode="light"] body.movie-page[data-bm-archive="archive2"] .bm-story-summary{
  background:#ffffff!important;
  border:1px solid #dce4ed!important;
  color:#243348!important;
  box-shadow:0 5px 20px rgba(19,36,61,.055)!important;
  text-shadow:none!important;
}
html[data-bm-color-mode="light"] body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-story-summary-head{
  color:#17263b!important;
  text-shadow:none!important;
}
html[data-bm-color-mode="light"] body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-readmore-content{
  color:#37465b!important;
  opacity:1!important;
  text-shadow:none!important;
}
html[data-bm-color-mode="light"] body.movie-page[data-bm-archive="archive2"] .bm-story-summary .bm-readmore-btn{
  color:#0969b5!important;
  border-color:rgba(19,116,188,.25)!important;
}
html[data-bm-color-mode="light"] body.movie-page[data-bm-archive="archive2"] .bm-story-summary.is-readmore-needed[data-collapsed="1"]::after{
  background:linear-gradient(180deg,rgba(255,255,255,0),#ffffff 97%)!important;
}
/* All archives: photo-free cast uses a circular SVG avatar, never a grey square.
   A failed remote photo switches to is-text-only via the existing onerror code. */
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only{
  display:flex!important;flex-direction:column!important;
  align-items:center!important;justify-content:flex-start!important;
  background:transparent!important;background-image:none!important;
  border-color:transparent!important;box-shadow:none!important;
  backdrop-filter:none!important;-webkit-backdrop-filter:none!important;
  text-align:center!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only:hover{
  background:rgba(55,126,203,.07)!important;
  border-color:rgba(75,152,235,.14)!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only > .bm-arc1-actor-photo-wrap{
  display:none!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card:not(.is-text-only) > .bm-arc1-actor-text-icon{
  display:none!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only > .bm-arc1-actor-text-icon{
  display:flex!important;visibility:visible!important;opacity:1!important;
  width:46px!important;height:46px!important;
  min-width:46px!important;min-height:46px!important;flex:0 0 46px!important;
  align-items:center!important;justify-content:center!important;
  margin-inline:auto!important;padding:0!important;
  border-radius:50%!important;overflow:hidden!important;
  background:linear-gradient(145deg,#304d72,#111b2b)!important;
  border:1px solid rgba(120,184,250,.4)!important;
  box-shadow:0 5px 15px rgba(8,23,44,.18)!important;
  color:#cde7ff!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only > .bm-arc1-actor-text-icon svg{
  display:block!important;visibility:visible!important;
  width:27px!important;height:27px!important;
  min-width:0!important;min-height:0!important;
  flex:0 0 auto!important;
  fill:none!important;stroke:currentColor!important;
  stroke-width:1.7!important;
  background:none!important;border:0!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-card.is-text-only > .bm-arc1-actor-name{
  color:#eff6ff!important;background:#1a2941!important;
  padding:3px 5px!important;border-radius:7px!important;
  display:-webkit-box!important;-webkit-box-orient:vertical!important;
  -webkit-line-clamp:2!important;overflow:hidden!important;
  width:100%!important;text-shadow:none!important;
}
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-photo-wrap,
body.movie-page .bm-arc1-actors-section .bm-arc1-actor-photo{
  border-radius:50%!important;overflow:hidden!important;
  object-fit:cover!important;
}
</style>
<script src="/assets/js/bm-player-f2m-v265.js?v=265"></script>
<link rel="stylesheet" href="/assets/css/bm-movie-release-menu-v14862113.css?v=14862113">
<link rel="stylesheet" href="/assets/css/bm-light-player-pickers-and-stickers-v14862114.css?v=14862114">
</body>
</html>

<!-- BM-ARCHIVE2-RICH-META-V15 -->
