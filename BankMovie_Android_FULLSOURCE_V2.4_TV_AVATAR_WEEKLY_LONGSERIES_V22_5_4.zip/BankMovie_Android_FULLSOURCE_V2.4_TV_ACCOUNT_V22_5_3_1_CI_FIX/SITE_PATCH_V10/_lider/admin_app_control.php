<?php
declare(strict_types=1);
/* BM_LIDER_COMPAT_V232 */
if (!defined('BM_ROOT_DIR')) define('BM_ROOT_DIR', dirname(__DIR__));
@chdir(BM_ROOT_DIR);

require_once BM_ROOT_DIR . '/includes/security_bootstrap.php';
require_once BM_ROOT_DIR . '/includes/admin_guard.php';
require_once BM_ROOT_DIR . '/includes/remote_delivery_control.php';
require_once BM_ROOT_DIR . '/includes/vip_sales.php';
require_once BM_ROOT_DIR . '/includes/archive_control.php';
require_once BM_ROOT_DIR . '/includes/admin_archive_dashboard.php';
require_admin();
admin_enforce_csrf();
$csrf = admin_csrf_token();
$ok = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $archives = [];
    foreach (['archive1','archive2','archive3','archive4','archive5'] as $id) {
        $archives[$id] = [
            'enabled'=>isset($_POST[$id.'_enabled']), 'hidden'=>isset($_POST[$id.'_hidden']),
            'access_scope'=>$_POST[$id.'_access_scope'] ?? 'public',
            'online_playback'=>isset($_POST[$id.'_online_playback']), 'downloads'=>isset($_POST[$id.'_downloads']),
            'links_visible'=>isset($_POST[$id.'_links_visible']), 'vip_unlock'=>isset($_POST[$id.'_vip_unlock']),
        ];
    }
    $rewrites = [];
    foreach (preg_split('/\R+/', (string)($_POST['url_rewrites'] ?? '')) ?: [] as $line) {
        $parts = array_map('trim', explode('=>', $line, 2));
        if (count($parts) === 2 && $parts[0] !== '' && $parts[1] !== '') $rewrites[] = ['from'=>$parts[0], 'to'=>$parts[1], 'enabled'=>true];
    }
    $ok = bm_delivery_save([
        'controller_domain'=>$_POST['controller_domain'] ?? '',
        'download_proxy_enabled'=>isset($_POST['download_proxy_enabled']), 'hide_origin_links'=>isset($_POST['hide_origin_links']),
        'download_proxy_path'=>$_POST['download_proxy_path'] ?? '/download.php',
        'download_redirect_base'=>$_POST['download_redirect_base'] ?? '',
        'allowed_download_hosts'=>preg_split('/[\s,]+/', (string)($_POST['allowed_download_hosts'] ?? ''), -1, PREG_SPLIT_NO_EMPTY),
        'url_rewrites'=>$rewrites, 'archives'=>$archives,
    ]);
}
$s = bm_delivery_settings(true);
$bmAdminArchiveStatuses = [];
try {
    foreach (bm_ad_archive_dashboard_data() as $bmArcInfo) {
        $bmAdminArchiveStatuses[(string)$bmArcInfo['id']] = $bmArcInfo;
    }
} catch (Throwable $e) { error_log('Archive dashboard unavailable: '.get_class($e)); }

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>کنترل اپ بانک‌مووی</title>
<style>body{margin:0;background:#05070c;color:#f6f7fb;font-family:Tahoma;padding:24px}.wrap{max-width:1100px;margin:auto}.card{background:#11151f;border:1px solid #303746;border-radius:22px;padding:20px;margin:14px 0}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px}.archive{background:linear-gradient(150deg,#1b2332,#111722);border:1px solid #343d4e;border-radius:18px;padding:14px;min-width:0}.archive h3{margin:0 0 9px;font-size:15px}.archive-meta{display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin:0 0 10px}.archive-meta span{display:inline-flex;border-radius:99px;border:1px solid #3a4560;background:#101927;padding:5px 9px;font-size:10px;font-weight:800;color:#a9c8f9}.archive-meta .ok{color:#70e2a5}.archive-meta .bad{color:#ffb2b2}.archive-meta a{color:#b7d9ff;font-size:10px;font-weight:900}.archive-fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2px 8px}.archive-fields label{font-size:11px;margin:4px 0}.archive-fields .full{grid-column:1/-1}.archive-fields select{padding:8px}.archive-note{font-size:10px;color:#94a3b8;line-height:1.8;margin:0 0 7px}@media(max-width:700px){body{padding:10px}.card{padding:13px;border-radius:18px}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.archive{padding:10px;border-radius:15px}.archive h3{font-size:12px}.archive-fields{grid-template-columns:1fr}.archive-fields label{font-size:10px}.archive-meta{gap:3px}.archive-meta span{font-size:9px;padding:4px 6px}.archive-meta a{font-size:9px}}@media(max-width:330px){.grid{grid-template-columns:1fr}.archive-fields{grid-template-columns:repeat(2,minmax(0,1fr))}}label{display:block;margin:9px 0}input,select,textarea{box-sizing:border-box;width:100%;background:#0b0e15;color:#fff;border:1px solid #3a4354;border-radius:12px;padding:11px}input[type=checkbox]{width:auto}button{background:linear-gradient(90deg,#2684ff,#7a3cff);border:0;border-radius:14px;color:#fff;padding:14px 26px;font-weight:bold}.ok{color:#62dc9f}</style>
<link rel="stylesheet" href="/assets/css/bm-admin-premium-v308.css?v=308">
</head><body data-bm-admin-page="admin_app_control" class="bm-admin-premium-v308"><main class="wrap"><h1>کنترل ریموت اپ بانک‌مووی</h1><?php if($ok!==null):?><p class="ok"><?= $ok?'ذخیره شد':'ذخیره ناموفق بود' ?></p><?php endif;?><form method="post"><input type="hidden" name="csrf_token" value="<?=h($csrf)?>"><section class="card"><h2>دامنه و لینک‌های دانلود</h2><div class="grid"><label>دامنه کنترلر<input dir="ltr" name="controller_domain" value="<?=h($s['controller_domain'])?>"></label><label>ساب‌دامین ریدایرکت دانلود<input dir="ltr" name="download_redirect_base" value="<?=h($s['download_redirect_base'])?>"></label><label>مسیر پروکسی دانلود<input dir="ltr" name="download_proxy_path" value="<?=h($s['download_proxy_path'])?>"></label></div><label><input type="checkbox" name="download_proxy_enabled" <?=$s['download_proxy_enabled']?'checked':''?>> پروکسی دانلود فعال</label><label><input type="checkbox" name="hide_origin_links" <?=$s['hide_origin_links']?'checked':''?>> آدرس واقعی لینک‌ها از اپ مخفی شود</label><label>دامنه‌های مجاز دانلود<textarea dir="ltr" name="allowed_download_hosts"><?=h(implode("\n",$s['allowed_download_hosts']))?></textarea></label><label>تعویض دامنه‌ها؛ هر خط: old.example => https://new.example<textarea dir="ltr" name="url_rewrites"><?php foreach($s['url_rewrites'] as $r) echo h($r['from'].' => '.$r['to'])."\n";?></textarea></label></section><section class="card"><h2>کنترل کامل آرشیوها</h2><div class="grid"><?php foreach($s['archives'] as $id=>$a):?><div class="archive"><h3><?=h(str_replace('archive','آرشیو ',$id))?></h3>
<?php $status = $bmAdminArchiveStatuses[$id] ?? null; $auth = $status['auth'] ?? null; ?>
<div class="archive-meta">
  <span class="<?= !empty($status['enabled']) ? 'ok' : 'bad' ?>"><?= !empty($status['enabled']) ? 'سرور فعال' : 'سرور غیرفعال' ?></span>
  <?php if($auth): ?><span><?=h($auth['mode_label'] ?? 'وضعیت نامشخص')?></span><span class="<?= ($auth['tone']??'')==='good' ? 'ok' : (($auth['tone']??'')==='bad' ? 'bad' : '') ?>"><?=h($auth['label']??'')?></span><?php endif; ?>
  <?php if(!empty($status['renew_url'])): ?><a href="<?=h($status['renew_url'])?>">مدیریت نشست</a><?php endif; ?>
</div>
<?php if(in_array($id,['archive6','archive7'],true)): ?><p class="archive-note">فقط پنل سرور؛ بدون افزودن به منوی اپ. مدیریت اصلی وضعیت و جایگزینی در کنترل آرشیوها انجام می‌شود.</p><?php endif; ?>
<?php if(in_array($id,['archive6','archive7'],true)): ?>
  <a style="display:inline-flex;padding:10px;border-radius:12px;background:#273c63;color:#d2e5ff;text-decoration:none;font-weight:900;font-size:12px" href="admin.php#archiveOverviewSection">کنترل اصلی این آرشیو در BM ADMIN</a>
<?php else: ?><div class="archive-fields"><label><input type="checkbox" name="<?=$id?>_enabled" <?=$a['enabled']?'checked':''?>> فعال</label><label><input type="checkbox" name="<?=$id?>_hidden" <?=$a['hidden']?'checked':''?>> مخفی کامل</label><label>سطح دسترسی<select name="<?=$id?>_access_scope"><?php foreach(['public'=>'عمومی','member'=>'عضو','vip'=>'VIP','admin'=>'مدیر'] as $v=>$l):?><option value="<?=$v?>" <?=$a['access_scope']===$v?'selected':''?>><?=$l?></option><?php endforeach;?></select></label><label><input type="checkbox" name="<?=$id?>_online_playback" <?=$a['online_playback']?'checked':''?>> پخش آنلاین</label><label><input type="checkbox" name="<?=$id?>_downloads" <?=$a['downloads']?'checked':''?>> دانلود</label><label><input type="checkbox" name="<?=$id?>_links_visible" <?=$a['links_visible']?'checked':''?>> نمایش لینک‌ها</label><label><input type="checkbox" name="<?=$id?>_vip_unlock" <?=$a['vip_unlock']?'checked':''?>> بازشدن با VIP</label></div><?php endif; ?></div><?php endforeach;?></div></section><p style="color:#a4b0c3;font-size:12px">تنظیمات نشست و لاگین در سرور اجرا می‌شود؛ اپ هیچ نام کاربری یا کوکی جداگانه دریافت نمی‌کند. برای تغییر منبع، مسیر API و سیاست دسترسی هر هفت آرشیو از <a style="color:#9fcaff" href="/_lider/tools/api_manager#archive-ops">مدیریت آرشیوها</a> استفاده کنید.</p><button>ذخیره تنظیمات</button> <a style="color:#ffd66b" href="admin_vip_manager">مدیریت قیمت و پلن VIP</a></form></main>
<script src="/assets/js/bm-admin-premium-v308.js?v=308" defer></script>
</body></html>
