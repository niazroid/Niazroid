#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MAIN=app/src/main/java/ir/bankmoviee/app/MainActivity.kt
# V17 intentionally upgrades V16's isolated Lookapo-only poster row to a
# single unified explorer. Verify Lookapo remains accessible through that UI.
for token in 'BANKMOVIE / EXPLORE' 'action=lookapo_list' 'ExplorerActivity::class.java' 'archive5ApiUrl("id='; do
  if ! grep -Fq "$token" "$MAIN"; then echo "Lookapo/Archive 5 regression: $token" >&2; exit 1; fi
done
node --check app/src/main/assets/bm_explorer_v17.js
echo BANKMOVIE_V16_LOOKAPO_COMPAT_UNIFIED_V17_OK
