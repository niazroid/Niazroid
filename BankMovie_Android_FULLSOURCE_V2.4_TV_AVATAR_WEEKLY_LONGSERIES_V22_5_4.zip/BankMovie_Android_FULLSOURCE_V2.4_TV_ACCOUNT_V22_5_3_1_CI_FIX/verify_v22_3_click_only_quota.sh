#!/usr/bin/env bash
# V22.3 regression migrated to the V22.5 REAL-REQUEST quota classifier.
# Preserve the old guarantee that background loads never consume the allowance.
set -euo pipefail
cd "$(dirname "$0")"
T="$(mktemp -d)"
trap 'rm -rf "$T"' EXIT
cp server-required/v2/api/bm_security.php "$T/bm_security.php"
mkdir -p "$T/.private"
cat > "$T/test.php" <<'PHP'
<?php
error_reporting(E_ALL);
require __DIR__.'/bm_security.php';
$_SERVER['REMOTE_ADDR']='192.0.2.10';
$_SERVER['HTTPS']='on';
$_SERVER['REQUEST_METHOD']='GET';
function classify(string $endpoint, array $query): ?string {
    $_GET=$query;
    $_POST=[];
    return bm22_billable_request_key($endpoint);
}
foreach (['app_home_feed','app_config','api_explorer','api_boxoffice'] as $endpoint) {
    for ($i=1;$i<=100;$i++) assert(classify($endpoint,['action'=>'home','page'=>(string)$i]) === null);
}
foreach (['home','section','collections','search','live_search','play','ping','notifications'] as $action) {
    assert(classify('app_api',['action'=>$action,'page'=>'1'])===null);
}
foreach (['api2','api4','api5','api6','archive1_live'] as $endpoint) {
    assert(classify($endpoint,['id'=>'tt100'])===null); // passive detail hydration
    assert(classify($endpoint,['genre'=>'action','page'=>'1'])===null); // home query
    assert(classify($endpoint,['genre'=>'action','page'=>'2','bm_q_intent'=>'genre'])===null);
}
assert(classify('app_api',['action'=>'detail','id'=>'tt100','bm_q_passive'=>'1'])===null);
assert(is_string(classify('app_api',['action'=>'detail','id'=>'tt100','bm_q_intent'=>'detail'])));
assert(is_string(classify('api5',['id'=>'tt100','bm_q_intent'=>'detail'])));
assert(is_string(classify('app_api',['action'=>'search','q'=>'dune','bm_q_intent'=>'advanced_search'])));
assert(is_string(classify('app_api',['action'=>'search','genre'=>'action','bm_q_intent'=>'genre'])));
assert(is_string(classify('api4',['genre'=>'action','bm_q_intent'=>'genre'])));
assert(classify('app_api',['action'=>'search','q'=>'dune','bm_q_intent'=>'genre'])===null);
assert(bm22_policy()['limit_per_minute']===50);
$installation='v223-compat-2026';
for ($i=0;$i<10;$i++) {
    $key=classify('app_api',['action'=>'detail','id'=>'tt'.(30000+$i),'bm_q_intent'=>'detail']);
    assert(is_string($key));
    assert(bm22_limit_content_open($installation,$key,10,60,60)===0);
    assert(bm22_limit_content_open($installation,$key,10,60,60)===0);
}
$eleventh=classify('app_api',['action'=>'detail','id'=>'tt30011','bm_q_intent'=>'detail']);
$retry=bm22_limit_content_open($installation,$eleventh,10,60,60);
assert($retry>0 && $retry<=60);
assert(bm22_limit_content_open($installation,classify('app_api',['action'=>'detail','id'=>'tt30009','bm_q_intent'=>'detail']),10,60,60)===0);
assert(classify('app_api',['action'=>'home'])===null);
$stored=file_get_contents(__DIR__.'/.private/open_'.hash('sha256',$installation).'.php');
assert(str_starts_with($stored,'<?php http_response_code(404);'));
assert(!str_contains($stored,'tt30000'));
echo "V22_3_REAL_REQUEST_COMPAT_OK\n";
PHP
php -d zend.assertions=1 -d assert.exception=1 "$T/test.php"
php -l server-required/v2/api/bm_security.php >/dev/null
python3 - <<'PY'
from pathlib import Path
r=Path('app/src/main/java/ir/bankmoviee/app')
main=(r/'MainActivity.kt').read_text()
security=Path('server-required/v2/api/bm_security.php').read_text()
assert 'BmApiRateLimit.report(this@MainActivity' in main
assert 'BmNotice.showRateLimited' in (r/'BmApiRateLimit.kt').read_text()
assert 'bm22_billable_request_key' in security
assert 'سقف درخواست‌های واقعی' in Path('server-required/bm_admin.php').read_text()
print('V22_3_RATE_LIMIT_TOAST_AND_ADMIN_COMPAT_OK')
PY
