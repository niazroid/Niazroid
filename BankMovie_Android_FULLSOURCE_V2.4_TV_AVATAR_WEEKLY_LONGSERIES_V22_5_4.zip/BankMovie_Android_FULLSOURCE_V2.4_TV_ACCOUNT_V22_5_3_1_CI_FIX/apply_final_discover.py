from pathlib import Path
p=Path('/mnt/data/bm_android_v25_work/app/src/main/java/ir/bankmoviee/app/MainActivity.kt')
s=p.read_text()
a=s.index('    private fun showDiscover() {');z=s.index('    private fun showCategories() {',a);b=s[a:z]
def rep(x,y,name):
 global b
 count=b.count(x)
 if count!=1:raise Exception(f'{name} count={count}')
 b=b.replace(x,y,1);print('Updated',name)
rep('''        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)''','''        if (!tv) applyMobileSafeTopPadding(page, baseTopDp = 12, breathingRoomDp = 4)
        scroll.addView(page)
        content.addView(scroll)
        attachSmartHeader(scroll)''','status bar safe inset')
rep('''        page.addView(decadeScroll)
        listOf(1970, 1980, 1990, 2000, 2010, 2020).forEach { year ->
            decades.addView(action("دهه ${year}") {
                filterYearMin = year.toString()
                filterYearMax = (year + 9).coerceAtMost(2027).toString()
                runMode("decade", 1)
            }, LinearLayout.LayoutParams(dp(113), dp(54)).apply { marginEnd = dp(6) })
        }''','''        page.addView(decadeScroll)
        // Cinematic covers from the site's real Discover art assets. Decorative
        // backgrounds only; decade result titles/posters always come from the API.
        val decadeArt = intArrayOf(
            R.drawable.bm_discover_mood_deep, R.drawable.bm_discover_mood_mystery,
            R.drawable.bm_discover_mood_romantic, R.drawable.bm_discover_mood_fun,
            R.drawable.bm_discover_mood_excited, R.drawable.bm_discover_mood_dream
        )
        listOf(1970, 1980, 1990, 2000, 2010, 2020).forEachIndexed { index, year ->
            val tile = FrameLayout(this).apply {
                background = rounded(panel, dp(16), palette.stroke)
                clipToOutline = true
                isClickable = true
                isFocusable = true
                applyTvFocusHalo(this, 16, 1.04f, 0f)
                setOnClickListener {
                    filterYearMin = year.toString()
                    filterYearMax = (year + 9).coerceAtMost(2027).toString()
                    runMode("decade", 1)
                }
            }
            tile.addView(ImageView(this).apply {
                setImageResource(decadeArt[index]); scaleType = ImageView.ScaleType.CENTER_CROP
            }, FrameLayout.LayoutParams(-1, -1))
            tile.addView(View(this).apply {
                background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(0x33040915, 0xE5040915.toInt()))
            }, FrameLayout.LayoutParams(-1, -1))
            tile.addView(label("دهه $year", 13.5f, Color.WHITE, true).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                setPadding(dp(5), 0, dp(5), dp(12))
            }, FrameLayout.LayoutParams(-1, -1))
            decades.addView(tile, LinearLayout.LayoutParams(dp(142), dp(100)).apply { marginEnd = dp(7) })
        }''','time travel artwork')
# Some filters don't visually indicate selected category. ensure buttons reactive
rep('''                    setOnClickListener {
                        if (key == "collections") showCollections()''','''                    setOnClickListener {
                        animate().alpha(.74f).setDuration(90L).withEndAction {
                            animate().alpha(1f).setDuration(140L).start()
                        }.start()
                        if (key == "collections") showCollections()''','category tap animation')
# use light theme safe primary without black fixed label; section images maintain contrast
# Make loading chip clearer rather than only circles
rep('''        loadingShield.addView(loading, FrameLayout.LayoutParams(-1, dp(100), Gravity.CENTER))''','''        val loaderCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(0xF0101729.toInt(), dp(22), orange)
            setPadding(dp(22), dp(17), dp(22), dp(17))
        }
        loaderCard.addView(label("در حال جستجو بین فیلم‌ها و سریال‌ها…", 12.8f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
        })
        loaderCard.addView(loading, LinearLayout.LayoutParams(dp(182), dp(85)).apply { topMargin = dp(10) })
        loadingShield.addView(loaderCard, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))''','clear loading with text')
# use rounded background for featured collage area
rep('''                val collage = FrameLayout(this).apply { clipChildren = false; clipToPadding = false }''','''                val collage = FrameLayout(this).apply {
                    clipChildren = false; clipToPadding = false
                    background = rounded(base, dp(16), palette.stroke)
                }''','collection collage rounded')
# result container glass: add border and padding, not massive
rep('''        val resultsPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }''','''        val resultsPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(panel, dp(18), palette.stroke)
            setPadding(dp(7), dp(13), dp(7), dp(13))
        }''','result glass panel')
s=s[:a]+b+s[z:];p.write_text(s)
