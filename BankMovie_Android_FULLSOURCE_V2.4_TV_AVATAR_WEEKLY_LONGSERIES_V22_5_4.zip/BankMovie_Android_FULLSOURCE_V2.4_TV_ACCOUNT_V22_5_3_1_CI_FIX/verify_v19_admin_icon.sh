#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
f=app/src/main/java/ir/bankmoviee/app/MainActivity.kt
icon=app/src/main/res/drawable/bm_ic_episode_play.xml
test -s "$icon"
grep -Fq 'R.drawable.bm_ic_episode_play' "$f"
grep -Fq 'M18.7,8.97989' "$icon"
# The new art belongs in the single seasons/download badge; do not add
# repeated decorative icons to each episode/quality row.
test "$(grep -Fc 'R.drawable.bm_ic_episode_play' "$f")" -eq 2
# Original app user token and all five archive flows must remain intact.
grep -Fq 'X-BM-User-Token' "$f"
grep -Fq 'archive5ApiUrl' "$f"
for asset in app/src/main/assets/bm_explorer_v17.html app/src/main/assets/bm_explorer_v17.js; do
  test -s "$asset"
done
echo 'V19_ANDROID_BADGE_AND_ARCHIVE_COMPAT_OK'
