#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/includes/app_push_notifications.php >/dev/null
php -l server-required/includes/fcm_push.php >/dev/null
php -r 'require "server-required/includes/app_push_notifications.php"; $ok=bm_push_safe_svg("<svg viewBox=\"0 0 24 24\"><path d=\"M2 2 L22 22\" fill=\"#ffffff\" /></svg>"); if (strpos($ok,"<path")===false) exit(1); try { bm_push_safe_svg("<svg><script>alert(1)</script><path d=\"M2 2 L22 22\"/></svg>"); exit(2); } catch(Throwable $e) {}' || { echo 'SVG_VALIDATION_FAILED';exit 1; }
python3 - <<'PYTEST'
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path('app/src/main')
s=(root/'java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
assert 'time.toDouble() / length.toDouble() < 0.97' in s
assert 'min(20_000L' not in s[s.index('private fun maybePromptNextEpisode'):s.index('private fun maybePromptNextEpisode')+850]
for v in (root/'res/drawable/ic_bankmovie_push.xml',root/'res/drawable/bm_ic_cast_group_v21.xml'): ET.parse(v)
s=(root/'java/ir/bankmoviee/app/MainActivity.kt').read_text()
assert 'R.drawable.bm_ic_cast_group_v21' in s
assert 'marginStart = dp(18); marginEnd = dp(10)' in s
assert 'addNotificationAction(firstLabel, firstUrl, true)' in s
for filename in ('BankMovieFirebaseMessagingService.kt','AdminPushJobService.kt'):
 p=(root/'java/ir/bankmoviee/app'/filename).read_text()
 assert '.setSmallIcon(R.drawable.ic_bankmovie_push)' in p
 assert 'BankMoviePushPresentation.addActions' in p
 assert 'BankMoviePushPresentation.allowed' in p
svc=(root/'java/ir/bankmoviee/app/BankMoviePushPresentation.kt').read_text()
assert '"guest" -> !logged' in svc and '"vip" -> vip' in svc
manifest=(root/'AndroidManifest.xml').read_text()
assert 'android:resource="@drawable/ic_bankmovie_push"' in manifest
print('BANKMOVIE_V21_NOTIFICATION_CTA_SVG_NEXT97_OK')
PYTEST
