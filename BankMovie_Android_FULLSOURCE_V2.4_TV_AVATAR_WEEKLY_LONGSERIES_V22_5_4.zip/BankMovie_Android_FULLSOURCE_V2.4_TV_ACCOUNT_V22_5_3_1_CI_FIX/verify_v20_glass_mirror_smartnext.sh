#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYVERIFY'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
p=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
assert 'detailWatchlistButton' not in m, 'floating watchlist on hero was not removed'
assert 'topMargin = dp(262)' in m and 'Color.argb(192, 45, 54, 67)' in m
assert 'mirroredArchiveRequest' in m and 'api5.php' in m and 'api4.php' in m
assert 'sourceDown && (mirroredArchiveRequest || isApiRequest)' in m
assert 'code == 401 || code == 403 || code == 429' in m
assert 'workingArchiveMirrorHosts' in m and 'absolutizeMirrorArtwork' in m
assert 'maybePromptNextEpisode(time: Long, length: Long, atEnd: Boolean = false)' in p
assert 'atEnd = true' in p and 'nextPromptShownKey == key' in p
assert 'time.toDouble() / length.toDouble() < 0.97' in p
assert 'player?.isPlaying != true' in p
# V21 uses 97% for every series, regardless of country or episode length.
def prompt_at(length_seconds, played_seconds):
    return played_seconds / length_seconds >= .97
assert not prompt_at(3600,3420)
assert not prompt_at(3600,3480)
assert prompt_at(3600,3492)
assert not prompt_at(1200,1163)
assert prompt_at(1200,1164)
assert prompt_at(5400,5238)
print('V20_STATIC_CONTRACTS_AND_NEXT_EPISODE_BOUNDARIES_OK')
PYVERIFY
