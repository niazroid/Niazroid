#!/usr/bin/env bash
# The V15 user-selected icon design intentionally supersedes V14's icons.
# Keep the V14 metadata / advertisements coverage through the V15 verifier.
set -euo pipefail
exec bash "$(dirname "$0")/verify_v24_archive5_metadata_promo_v15.sh"
