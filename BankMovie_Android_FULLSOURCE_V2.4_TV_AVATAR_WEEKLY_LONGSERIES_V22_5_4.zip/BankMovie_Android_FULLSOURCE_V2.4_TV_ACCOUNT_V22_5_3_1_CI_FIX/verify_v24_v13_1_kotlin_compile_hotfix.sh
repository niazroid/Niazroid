#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYVERIFY'
from pathlib import Path
import re
src = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
assert not re.search(r'\bdownloadNotice\s*\(', src), 'V13 deleted downloadNotice() but calls remain: Kotlin unresolved reference'
assert 'برای پخش روی دکمه سبز بزن.' not in src, 'Removed download guidance has returned'
for name in ('showDownloadForLinks', 'showPlayablePage', 'showPlayableSheet'):
    assert re.search(r'\bfun\s+' + name + r'\s*\(', src), 'Missing original playback/download function ' + name
print('V13_1_KOTLIN_UNRESOLVED_DOWNLOAD_NOTICE_FIXED')
PYVERIFY
