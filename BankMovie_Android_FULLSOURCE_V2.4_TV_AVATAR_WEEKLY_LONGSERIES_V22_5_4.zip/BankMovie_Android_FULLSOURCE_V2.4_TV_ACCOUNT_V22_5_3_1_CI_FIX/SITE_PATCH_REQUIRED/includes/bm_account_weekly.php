<?php
/** Shared weekly username/password controls for the site profile. */
declare(strict_types=1);
function bm_profile_weekly_schema(PDO $pdo): bool {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS bm_account_credential_limits (
            user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
            username_changed_at DATETIME NULL,
            password_changed_at DATETIME NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        return true;
    } catch (Throwable $e) {
        error_log('bm account weekly schema not available');
        return false;
    }
}
/** Caller must hold users row lock and an open transaction. */
function bm_profile_weekly_claim(PDO $pdo, int $uid, string $kind): void {
    if (!in_array($kind, ['username', 'password'], true)) throw new DomainException('نامعتبر');
    $column = $kind === 'username' ? 'username_changed_at' : 'password_changed_at';
    $pdo->prepare('INSERT INTO bm_account_credential_limits(user_id) VALUES (?) ON DUPLICATE KEY UPDATE user_id = VALUES(user_id)')->execute([$uid]);
    $stmt = $pdo->prepare('SELECT username_changed_at, password_changed_at FROM bm_account_credential_limits WHERE user_id = ? FOR UPDATE');
    $stmt->execute([$uid]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
    $last = !empty($row[$column]) ? (new DateTimeImmutable((string)$row[$column], new DateTimeZone('UTC')))->getTimestamp() : false;
    $seconds = $last !== false ? max(0, $last + 7 * 86400 - time()) : 0;
    if ($seconds > 0) throw new DomainException('برای تغییر دوبارهٔ ' . ($kind === 'username' ? 'نام کاربری' : 'رمز عبور') . ' حدود ' . ceil($seconds / 86400) . ' روز دیگر صبر کنید.');
    $sql = "UPDATE bm_account_credential_limits SET $column = UTC_TIMESTAMP() WHERE user_id = ?";
    $pdo->prepare($sql)->execute([$uid]);
}
