#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYCHK'
from pathlib import Path
from xml.etree import ElementTree
import re
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
p=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
section=s[s.index('private fun sectionHeader('):s.index('private fun legacyTvSectionHeader(')]
helper=s[s.index('private fun tintHomeContentIcon('):s.index('private fun sectionHeader(')]
detail=s[s.index('private fun renderDetail(page: LinearLayout, item: JSONObject)'):s.index('private fun commentAvatarView(')]
assert 'detailBackButton' not in detail, 'overlay Back icon returned to mobile poster'
assert 'layoutParams = LinearLayout.LayoutParams(-1, dp(472))' in detail
assert 'hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1, Gravity.TOP))' in detail
assert 'FrameLayout.LayoutParams(-1, dp(230), Gravity.BOTTOM)' in detail
assert 'detailLatestUpdatePill(item)' in detail and 'bankRatingStrip(item)' in detail
assert detail.index('FrameLayout.LayoutParams(-1, dp(230), Gravity.BOTTOM)') < detail.index('page.addView(hero)') < detail.index('bankRatingStrip(item)')
assert 'handleSmartBack()' in s, 'Android back navigation must be preserved'
assert ('R.drawable.bm_ic_cast_group' in section or 'R.drawable.bm_v14_users_round' in section or 'R.drawable.bm_v15_cast_favorite' in section), 'cast section icon missing'
assert 'actorSearchHeading.addView' in s and ('bm_ic_actor_profile' in s[s.index('private fun actorHeroCard('):s.index('private fun renderActors(')] or 'siteActorAvatar(photo)' in s[s.index('private fun actorHeroCard('):s.index('private fun renderActors(')]), 'actor portrait must retain a fallback'
assert 'R.drawable.bm_site_neon_anime' in helper
assert 'icon.clearColorFilter()' in helper
assert 'preserveArtColor' in section and 'R.drawable.bm_site_neon_anime' in section
asset=ElementTree.parse('app/src/main/res/drawable/bm_ic_actors_masks.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
paths=list(asset)
assert len(paths)==6
for path in paths:
    d=path.get(ns+'pathData')
    assert d and len(d)>400 and not re.search(r'[^a-zA-Z0-9\s,\.\-+]',d), 'malformed SVG pathData'
for marker in ('KEYCODE_MEDIA_STOP','stopTvStreamWithoutExiting()','resumeTvStreamIfStale()',
               'TV_STREAM_IDLE_REOPEN_MS','TV_STALL_WATCHDOG_MS','watchTvStreamProgress(p, time, len)',
               'player !== mp','rememberTvResumePosition()','tvStallRecoveries >= 3'):
    assert marker in p, f'missing TV resume/stall safety: {marker}'
assert 'if (!isTvLike() || partyActive) return false' in p, 'TV recovery must not hijack watch parties or mobile'
assert 'lifecycleRestorePending ||' in p and 'userPausedAtMs > 0L' in p, 'background/intentional pauses must be excluded'
assert p.index('KEYCODE_MEDIA_STOP') < p.index('KEYCODE_BACK')
gradle=Path('app/build.gradle').read_text()
assert "applicationId 'ir.bankmoviee.app'" in gradle and 'versionName "2.4"' in gradle
print('VERIFY_V24_HERO_ACTORS_TV_RECOVERY_V9_OK')
PYCHK
