#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
def check(ok, why):
    if not ok: raise SystemExit('::error::V2.4 mobile polish V6: '+why)
start = s.index('    private fun sectionHeader(')
end = s.index('    private fun legacyTvSectionHeader(',start)
h = s[start:end]
check('row.addView(heading, LinearLayout.LayoutParams(-2, dp(40)))' in h, 'mobile header must wrap its content; cannot grow across entire rail')
check('row.addView(View(this), LinearLayout.LayoutParams(0, dp(1), 1f))' in h, 'free space must belong to a spacer, not heading')
check('heading.addView(TextView(this).apply {\n                text = "NEW"' in h, 'NEW must be inside the heading')
for name in ('bm_site_neon_movie','bm_site_neon_series','bm_site_neon_collections','bm_site_neon_anime',
             'bm_site_neon_animation','bm_site_neon_korea','bm_site_neon_turkey', 'bm_site_neon_dub'):
    check(f'R.drawable.{name}' in h, f'missing genuine site graphic: {name}')
sec=s[s.index('    private fun renderRemoteHomeSection('):s.index('    private fun showHome()')]
a2=sec[sec.index('            2 -> when (key) {'):sec.index('            3 -> when (key) {')]
check('"فیلم‌های جدید"' in a2 and '"سریال‌های جدید"' in a2, 'Archive 2 movie/series titles not updated')
check('addRail(page, "اکشن", 2' not in a2 and 'addRail(page, "درام", 2' not in a2, 'Archive 2 Action/Drama rails still rendered')
check('2 -> listOf("updated_movies","updated_series","dubbed","animation","collections")' in s,
      'Archive 2 default still has Action or Drama')
cc=s[s.index('    private fun collectionCard('):s.index('    private fun boxOfficeLoadingSkeleton(')]
check('if (!tv) {' in cc and 'val height = if (compact) dp(154) else dp(160)' in cc,
      'mobile collection must use compact landscape layout while TV unchanged')
check('No tall, opaque black footer' in cc and 'FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM)' in cc,
      'mobile collection must place text over softly faded artwork')
d=s[s.index('    private fun renderDetail(page: LinearLayout, item: JSONObject)'):]
check('hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1, Gravity.TOP))' in d,
      'archives 1-4 must all use full-height hero artwork')
check('hero.addView(heroPosterShell' not in d, 'extra centered floating poster must be removed')
check('if (posterOnlyArtwork) loadBalancedDetailPoster(artwork, heroImg)' in d,
      'hero must use balanced framing for portrait artwork')
check(d.index('hero.addView(heroImg,') < d.index('hero.addView(playOrb,') < d.index('page.addView(hero)') < d.index('bankRatingStrip(item)'),
      'hero artwork/play/rating draw order wrong')
discover=s[s.index('    private fun showDiscover()'):s.index('    private fun showCategories()',s.index('    private fun showDiscover()'))]
check('collectionItems.addView(card, LinearLayout.LayoutParams(dp(177), dp(146))' in discover,
      'Discover collections still too tall')
check('The three original posters sit directly on the artwork' in discover and 'val card = FrameLayout(this).apply {' in discover, 'Discover must render compact poster collage with no opaque black footer')
print('VERIFY_V24_MOBILE_COMPACT_V6_OK')
PY
