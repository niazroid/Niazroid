-- BankMovie V22.5.4: can be applied once in phpMyAdmin.
-- Separate seven-day cooldowns for username and password, enforced by server transactions.
CREATE TABLE IF NOT EXISTS bm_account_credential_limits (
    user_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
    username_changed_at DATETIME NULL,
    password_changed_at DATETIME NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
