<?php
// php v2/api/cleanup_private.php -- CLI only, hourly via cron.
if (PHP_SAPI!=='cli') {http_response_code(404);exit;}
require_once __DIR__.'/bm_security.php';
$dir=bm22_private_dir();
$n=0;
foreach (glob($dir.'/{rate_,nonce_,open_}*.php',GLOB_BRACE) ?: [] as $file) {
    if (!is_file($file) || filemtime($file) > time()-3600) continue;
    // lock first: concurrent writers must not be removed, including detail-open counters.
    $handle=@fopen($file,'c+');
    if ($handle && flock($handle,LOCK_EX|LOCK_NB)) {
        if (filemtime($file)<time()-3600) { @unlink($file); $n++; }
        flock($handle,LOCK_UN);
    }
    if ($handle) fclose($handle);
}
echo "cleaned {$n} expired rate files\n";
