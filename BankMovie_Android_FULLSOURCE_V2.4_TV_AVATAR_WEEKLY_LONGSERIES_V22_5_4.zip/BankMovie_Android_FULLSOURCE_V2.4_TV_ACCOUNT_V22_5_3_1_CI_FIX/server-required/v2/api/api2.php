<?php
/** V22 protected facade. Needs the matching existing website endpoint. */
require_once __DIR__.'/bm_security.php';
bm22_guard('api2');
$target=dirname(__DIR__,2).'/api2.php';
if (!is_file($target)) bm22_fail(503,'api_not_installed');
require $target;
