<?php
/** BankMovie V22 secured API wrapper; legacy /api5.php remains unchanged. */
require_once __DIR__.'/bm_security.php';
bm22_guard('api5');
require dirname(__DIR__,2).'/api5.php';
