<?php
/** V22.5 compatibility tombstone: never records or charges UI click events. */
require_once __DIR__.'/bm_security.php';
bm22_guard('action');
header('Cache-Control: no-store');
http_response_code(204);
exit;
