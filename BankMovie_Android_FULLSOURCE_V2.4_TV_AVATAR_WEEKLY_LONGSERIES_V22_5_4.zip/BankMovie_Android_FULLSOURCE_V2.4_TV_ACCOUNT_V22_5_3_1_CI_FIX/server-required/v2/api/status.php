<?php
// Public readiness check; returns no credential or private configuration.
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD']??'GET')!=='GET') { http_response_code(405);exit; }
echo json_encode(['status'=>'ok','api'=>'v2','tls'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
