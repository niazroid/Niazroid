<?php
// Public bootstrap config: rate-limited separately. No secret included.
require_once __DIR__.'/bm_security.php';
if (bm22_limit('config-ip',bm22_client_ip(),120,60)) bm22_fail(429,'config_rate_limited',60);
require dirname(__DIR__,2).'/app_config.php';
