<?php
/** Optional V22 box-office route; existing site's root script must be installed. */
require_once __DIR__.'/bm_security.php';
bm22_guard('api_boxoffice');
$target=dirname(__DIR__,2).'/api_boxoffice.php';
if (!is_file($target)) bm22_fail(503,'api_not_installed');
require $target;
