<?php
/** V22 protected facade. Needs the matching existing website endpoint. */
require_once __DIR__.'/bm_security.php';
bm22_guard('api_explorer');
$target=dirname(__DIR__,2).'/api_explorer.php';
if (!is_file($target)) bm22_fail(503,'api_not_installed');
require $target;
