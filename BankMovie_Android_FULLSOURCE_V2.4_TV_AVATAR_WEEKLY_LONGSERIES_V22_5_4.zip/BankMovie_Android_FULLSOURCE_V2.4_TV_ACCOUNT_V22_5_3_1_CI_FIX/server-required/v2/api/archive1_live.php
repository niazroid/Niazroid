<?php
/** BankMovie V22 secured API wrapper; legacy /archive1_live.php remains unchanged. */
require_once __DIR__.'/bm_security.php';
bm22_guard('archive1_live');
require dirname(__DIR__,2).'/archive1_live.php';
