<?php
/** BankMovie V22 secured API wrapper; legacy /api4.php remains unchanged. */
require_once __DIR__.'/bm_security.php';
bm22_guard('api4');
require dirname(__DIR__,2).'/api4.php';
