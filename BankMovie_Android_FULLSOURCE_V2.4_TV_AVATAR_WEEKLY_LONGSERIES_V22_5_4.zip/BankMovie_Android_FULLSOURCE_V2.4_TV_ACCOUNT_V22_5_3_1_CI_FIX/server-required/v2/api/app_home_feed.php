<?php
/** BankMovie V22 secured API wrapper; legacy /app_home_feed.php remains unchanged. */
require_once __DIR__.'/bm_security.php';
bm22_guard('app_home_feed');
require dirname(__DIR__,2).'/app_home_feed.php';
