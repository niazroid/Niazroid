<?php
/** BankMovie V22 secured API wrapper; legacy /app_user_api.php remains unchanged. */
require_once __DIR__.'/bm_security.php';
bm22_guard('app_user_api');
require dirname(__DIR__,2).'/app_user_api.php';
