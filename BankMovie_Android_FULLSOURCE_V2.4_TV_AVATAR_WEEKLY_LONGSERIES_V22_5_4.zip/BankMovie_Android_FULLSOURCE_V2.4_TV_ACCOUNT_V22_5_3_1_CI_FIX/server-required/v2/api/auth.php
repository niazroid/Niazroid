<?php
/** V22 public session bootstrap. Must be hosted under valid HTTPS. */
require_once __DIR__ . '/bm_security.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'OPTIONS') {
    header('Access-Control-Allow-Methods: POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');
    http_response_code(204); exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') bm22_fail(405,'method_not_allowed');
// When behind TLS termination, configure HTTPS=on at the trusted web server;
// do NOT trust a client-supplied X-Forwarded-Proto header.
if (empty($_SERVER['HTTPS']) || strtolower((string)$_SERVER['HTTPS'])==='off') bm22_fail(403,'https_required');
if (isset($_SERVER['CONTENT_LENGTH']) && (int)$_SERVER['CONTENT_LENGTH']>2048) bm22_fail(413,'request_too_large');
$policy=bm22_policy();
$retry=bm22_limit('register-ip',bm22_client_ip(),(int)$policy['register_ip_limit'],300);
if ($retry) bm22_fail(429,'registration_rate_limited',$retry);
$body=json_decode((string)file_get_contents('php://input'),true);
if (!is_array($body)) bm22_fail(400,'invalid_json');
$public=(string)($body['public_key']??'');
$device=(string)($body['device_id']??'');
$time=(string)($body['timestamp']??'');
$nonce=(string)($body['nonce']??'');
$proof=bm22_unb64((string)($body['proof']??''));
if (!preg_match('/^[a-f0-9-]{36}$/D',$device) || !ctype_digit($time)
    || abs(time()-(int)$time)>120 || !preg_match('/^[a-f0-9]{32}$/D',$nonce)
    || $proof===false || strlen($proof)>256 || !($pk=bm22_public_key($public))) bm22_fail(401,'invalid_device_registration');
$payload='BMV22-REGISTER|'.$device.'|'.$time.'|'.$nonce;
if (openssl_verify($payload,$proof,$pk,OPENSSL_ALGO_SHA256)!==1) bm22_fail(401,'invalid_device_proof');
if (!bm22_replay_check('registration-'.hash('sha256',$public),$nonce)) bm22_fail(401,'registration_replay');
$retry=bm22_limit('register-device',hash('sha256',$public),(int)$policy['register_device_limit'],60);
if ($retry) bm22_fail(429,'registration_rate_limited',$retry);
echo json_encode(bm22_token_issue($device,$public),JSON_UNESCAPED_SLASHES);
