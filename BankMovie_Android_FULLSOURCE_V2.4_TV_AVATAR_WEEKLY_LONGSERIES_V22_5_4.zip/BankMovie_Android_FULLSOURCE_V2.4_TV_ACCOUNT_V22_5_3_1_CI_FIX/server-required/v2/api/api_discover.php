<?php
require_once __DIR__.'/bm_security.php';
bm22_guard('api_discover');
$target=dirname(__DIR__,2).'/api_discover.php';
if (!is_file($target)) bm22_fail(503,'api_not_installed');
require $target;
