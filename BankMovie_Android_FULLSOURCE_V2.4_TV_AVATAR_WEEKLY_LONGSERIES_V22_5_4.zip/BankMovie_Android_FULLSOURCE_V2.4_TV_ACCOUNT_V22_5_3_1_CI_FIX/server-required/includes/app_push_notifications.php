<?php
/**
 * BankMovie application-only push notification storage.
 *
 * Important: this table is intentionally separate from the legacy `notifications`
 * table used by the website. Pushes created in BM Admin must never appear on the
 * public website.
 */

if (!function_exists('bm_push_table_exists')) {
    function bm_push_table_exists(PDO $pdo, string $table): bool {
        $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($safe === '') return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
            $stmt->execute([$safe]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_push_ensure_schema')) {
    function bm_push_ensure_schema(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_notifications (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title VARCHAR(220) NOT NULL,
            message TEXT NOT NULL,
            link VARCHAR(700) NULL,
            status VARCHAR(24) NOT NULL DEFAULT 'stored',
            fcm_message_name VARCHAR(700) NULL,
            fcm_error TEXT NULL,
            expires_at DATETIME NULL,
            sent_at DATETIME NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            INDEX idx_app_push_created (created_at),
            INDEX idx_app_push_active (expires_at, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        // V21 optional fields; old APKs still read title/message/link unchanged.
        foreach ([
            'meta_json' => 'MEDIUMTEXT NULL',
            'starts_at' => 'DATETIME NULL',
        ] as $field => $definition) {
            try {
                $exists = $pdo->query("SHOW COLUMNS FROM app_push_notifications LIKE " . $pdo->quote($field));
                if (!$exists || !$exists->fetch(PDO::FETCH_ASSOC)) {
                    $pdo->exec("ALTER TABLE app_push_notifications ADD COLUMN `{$field}` {$definition}");
                }
            } catch (Throwable $e) { error_log('BM Push v21 schema: ' . $e->getMessage()); }
        }
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_revocations (
            notification_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
            revoked_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_app_push_revoked_at (revoked_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}

if (!function_exists('bm_push_revoke')) {
    function bm_push_revoke(PDO $pdo, int $id): void {
        if ($id <= 0) return;
        bm_push_ensure_schema($pdo);
        try {
            $stmt = $pdo->prepare("INSERT INTO app_push_revocations(notification_id,revoked_at) VALUES(?,NOW()) ON DUPLICATE KEY UPDATE revoked_at=VALUES(revoked_at)");
            $stmt->execute([$id]);
        } catch (Throwable $e) { error_log('app push revoke: ' . $e->getMessage()); }
    }
}

if (!function_exists('bm_push_revoked_ids')) {
    function bm_push_revoked_ids(PDO $pdo, int $limit = 200): array {
        bm_push_ensure_schema($pdo);
        $limit = max(1, min(500, $limit));
        try { $pdo->exec("DELETE FROM app_push_revocations WHERE revoked_at < (NOW() - INTERVAL 7 DAY)"); } catch (Throwable $e) {}
        try {
            $stmt = $pdo->query("SELECT notification_id FROM app_push_revocations ORDER BY revoked_at DESC LIMIT {$limit}");
            return array_values(array_map('intval', $stmt ? ($stmt->fetchAll(PDO::FETCH_COLUMN) ?: []) : []));
        } catch (Throwable $e) { return []; }
    }
}

if (!function_exists('bm_push_cleanup_expired')) {
    function bm_push_cleanup_expired(PDO $pdo): int {
        bm_push_ensure_schema($pdo);
        try {
            $ids = $pdo->query("SELECT id FROM app_push_notifications
                WHERE (expires_at IS NOT NULL AND expires_at < NOW())
                   OR created_at < (NOW() - INTERVAL 7 DAY)")->fetchAll(PDO::FETCH_COLUMN) ?: [];
            foreach ($ids as $id) bm_push_revoke($pdo, (int)$id);
            return (int)$pdo->exec("DELETE FROM app_push_notifications
                WHERE (expires_at IS NOT NULL AND expires_at < NOW())
                   OR created_at < (NOW() - INTERVAL 7 DAY)");
        } catch (Throwable $e) {
            error_log('app push cleanup: ' . $e->getMessage());
            return 0;
        }
    }
}

// Sanitize arbitrary administrator-supplied SVG by REBUILDING a small, inert
// vector subset. No foreignObject, scripts, links, event handlers or CSS survive.
if (!function_exists('bm_push_safe_svg')) {
    function bm_push_safe_svg(string $input): string {
        if (trim($input) === '') return '';
        if (strlen($input) > 40000 || !preg_match('~<svg\b~i', $input)) throw new RuntimeException('فایل SVG نامعتبر یا بزرگ است.');
        if (preg_match('~<!|<\s*(script|foreignObject|image|use|style|animate|iframe|object|audio|video|set)\b|\bon[a-z]+\s*=|(?:href|src)\s*=|url\s*\(~i', $input)) {
            throw new RuntimeException('SVG شامل کد یا مرجع خارجی غیرمجاز است.');
        }
        $view = '0 0 24 24';
        if (preg_match('~<svg\b[^>]*\bviewBox\s*=\s*["\']([^"\']+)["\']~i', $input, $m)) {
            $parts = preg_split('/[\s,]+/', trim($m[1]));
            if (count($parts) === 4 && count(array_filter($parts, fn($v)=>is_numeric($v) && abs((float)$v)<100000))===4) {
                $view = implode(' ', array_map(fn($v)=>rtrim(rtrim(sprintf('%.4f', (float)$v), '0'), '.'), $parts));
            }
        }
        $parts=[];
        // Preserve safe nested group transforms (common in SVG Repo artwork).
        preg_match_all('~</?(g|path|circle|rect|line|ellipse|polygon|polyline)\b[^>]*>~i', $input, $tokens);
        if (count($tokens[0]) > 160) throw new RuntimeException('SVG بیش از حد پیچیده است.');
        $whitelist = ['d','fill','stroke','stroke-width','stroke-linecap','stroke-linejoin','opacity','fill-opacity','stroke-opacity','cx','cy','r','rx','ry','x','y','x1','x2','y1','y2','width','height','points','transform'];
        $depth=0;
        foreach ($tokens[0] as $token) {
            if (!preg_match('~^<(\/)?([a-zA-Z]+)\b(.*)>$~s', $token, $tag)) continue;
            $closing=$tag[1] === '/';
            $type=strtolower($tag[2]);
            if ($type==='g' && $closing) {
                if ($depth>0) { $parts[]='</g>'; $depth--; }
                continue;
            }
            if ($closing) continue;
            $attrs=[];
            preg_match_all('~([a-zA-Z][\w-]*)\s*=\s*(["\'])(.*?)\2~s', $tag[3], $pairs, PREG_SET_ORDER);
            foreach ($pairs as $pair) {
                $key=strtolower($pair[1]); $val=trim($pair[3]);
                if (!in_array($key,$whitelist,true)) continue;
                if ($key === 'transform' && !preg_match('~^(?:\s*(?:translate|scale|rotate|matrix|skewX|skewY)\s*\([0-9eE+\-.,\s]+\)\s*)+$~D', $val)) continue;
                if ($key === 'd' && !preg_match('/^[0-9eE+\-.,\sMmLlHhVvCcSsQqTtAaZz]+$/D', $val)) continue;
                if ($key === 'points' && !preg_match('/^[0-9eE+\-.,\s]+$/D', $val)) continue;
                if (in_array($key,['fill','stroke'],true) && !preg_match('/^(?:#[0-9a-fA-F]{3,8}|none|currentColor|black|white)$/D', $val)) continue;
                if (!in_array($key,['d','points','fill','stroke','stroke-linecap','stroke-linejoin','transform'],true) && !preg_match('/^[0-9eE+\-.]+$/D',$val)) continue;
                if (in_array($key,['stroke-linecap','stroke-linejoin'],true) && !in_array($val,['round','butt','square','miter','bevel'],true)) continue;
                $attrs[]=$key.'="'.htmlspecialchars($val, ENT_QUOTES|ENT_XML1,'UTF-8').'"';
            }
            if ($type==='g') { $parts[]='<g'.($attrs?' '.implode(' ',$attrs):'').'>'; $depth++; continue; }
            if (!$attrs) continue;
            $parts[]='<'.$type.' '.implode(' ',$attrs).'/>';
        }
        while ($depth-->0) $parts[]='</g>';
        if (!$parts) throw new RuntimeException('SVG مسیر قابل‌نمایش ندارد.');
        return '<svg xmlns="http://www.w3.org/2000/svg" fill="#FFFFFF" viewBox="'.htmlspecialchars($view,ENT_QUOTES,'UTF-8').'">'.implode('',$parts).'</svg>';
    }
}
if (!function_exists('bm_push_metadata')) {
    function bm_push_metadata(array $row): array {
        $data=json_decode((string)($row['meta_json']??''),true);
        return is_array($data) ? $data : [];
    }
}
if (!function_exists('bm_push_expand')) {
    function bm_push_expand(array $row): array {
        $meta=bm_push_metadata($row);
        foreach (['kind','audience','cta_label','cta_url','secondary_label','secondary_url','icon_svg','icon_mode','image_url'] as $key) {
            $row[$key]=(string)($meta[$key]??'');
        }
        $row['image']=(string)($meta['image_url']??'');
        return $row;
    }
}
if (!function_exists('bm_push_insert_v21')) {
    function bm_push_insert_v21(PDO $pdo, string $title, string $message, string $link, ?string $expiresAt, array $meta, ?string $startsAt): int {
        bm_push_ensure_schema($pdo);
        $scheduled = $startsAt && strtotime($startsAt) > time();
        $stmt=$pdo->prepare('INSERT INTO app_push_notifications(title,message,link,status,expires_at,starts_at,meta_json,created_at) VALUES(?,?,?, ?, ?, ?, ?, NOW())');
        $stmt->execute([$title,$message,$link ?: null,$scheduled?'scheduled':'stored',$expiresAt,$startsAt,json_encode($meta,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
        return (int)$pdo->lastInsertId();
    }
}
if (!function_exists('bm_push_due_scheduled')) {
    function bm_push_due_scheduled(PDO $pdo): void {
        // Triggered by app polling or an admin page load. This is best-effort
        // delivery (not a wall-clock scheduler); atomic claim prevents repeats.
        try {
            require_once __DIR__ . '/fcm_push.php';
            $rows=$pdo->query("SELECT * FROM app_push_notifications WHERE status='scheduled' AND starts_at <= NOW() AND (expires_at IS NULL OR expires_at > NOW()) ORDER BY id ASC LIMIT 4")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) {
                $claim=$pdo->prepare("UPDATE app_push_notifications SET status='sending' WHERE id=? AND status='scheduled'");
                $claim->execute([(int)$row['id']]);
                if ($claim->rowCount()!==1) continue;
                $result=function_exists('bm_fcm_send_topic') ? bm_fcm_send_topic((string)$row['title'],(string)$row['message'],(string)($row['link']??''),(int)$row['id'],bm_push_metadata($row)) : ['ok'=>false,'configured'=>false];
                bm_push_mark_delivery($pdo,(int)$row['id'],$result);
            }
        } catch (Throwable $e) { error_log('BM scheduled push: '.$e->getMessage()); }
    }
}
if (!function_exists('bm_push_insert')) {
    function bm_push_insert(PDO $pdo, string $title, string $message, string $link, ?string $expiresAt): int {
        bm_push_ensure_schema($pdo);
        $stmt = $pdo->prepare("INSERT INTO app_push_notifications
            (title,message,link,status,expires_at,created_at)
            VALUES (?,?,?,'stored',?,NOW())");
        $stmt->execute([
            mb_substr(trim($title) !== '' ? trim($title) : 'پیام مدیریت بانک مووی', 0, 220, 'UTF-8'),
            trim($message),
            trim($link) !== '' ? trim($link) : null,
            $expiresAt,
        ]);
        return (int)$pdo->lastInsertId();
    }
}

if (!function_exists('bm_push_mark_delivery')) {
    function bm_push_mark_delivery(PDO $pdo, int $id, array $result): void {
        if ($id <= 0) return;
        $ok = !empty($result['ok']);
        $configured = !empty($result['configured']);
        $status = $ok ? 'sent' : ($configured ? 'fcm_failed' : 'fallback');
        $name = trim((string)($result['name'] ?? ''));
        $error = $ok ? '' : trim((string)($result['debug'] ?? ($result['message'] ?? '')));
        try {
            $stmt = $pdo->prepare("UPDATE app_push_notifications
                SET status=?, fcm_message_name=?, fcm_error=?, sent_at=NOW()
                WHERE id=?");
            $stmt->execute([$status, $name !== '' ? $name : null, $error !== '' ? mb_substr($error, 0, 6000, 'UTF-8') : null, $id]);
        } catch (Throwable $e) {
            error_log('app push delivery update: ' . $e->getMessage());
        }
    }
}

if (!function_exists('bm_push_get')) {
    function bm_push_get(PDO $pdo, int $id): ?array {
        bm_push_ensure_schema($pdo);
        if ($id <= 0) return null;
        $stmt = $pdo->prepare('SELECT * FROM app_push_notifications WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($row) ? $row : null;
    }
}

if (!function_exists('bm_push_list')) {
    function bm_push_list(PDO $pdo, int $limit = 30): array {
        bm_push_ensure_schema($pdo);
        bm_push_cleanup_expired($pdo);
        $limit = max(1, min(100, $limit));
        $stmt = $pdo->query("SELECT id,title,message,COALESCE(link,'') AS link,status,
            COALESCE(fcm_message_name,'') AS fcm_message_name,
            COALESCE(fcm_error,'') AS fcm_error,meta_json,starts_at,expires_at,sent_at,created_at
            FROM app_push_notifications
            ORDER BY id DESC LIMIT {$limit}");
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
        return is_array($rows) ? array_map('bm_push_expand', $rows) : [];
    }
}

if (!function_exists('bm_push_poll_items')) {
    function bm_push_poll_items(PDO $pdo, int $limit = 30): array {
        bm_push_ensure_schema($pdo);
        bm_push_cleanup_expired($pdo);
        $limit = max(1, min(50, $limit));
        if (function_exists('bm_push_due_scheduled')) bm_push_due_scheduled($pdo);
        $stmt = $pdo->query("SELECT id,
            COALESCE(NULLIF(title,''),'پیام مدیریت بانک مووی') AS title,
            message,COALESCE(link,'') AS link,meta_json,starts_at,created_at,UNIX_TIMESTAMP(created_at) AS created_at_epoch,expires_at
            FROM app_push_notifications
            WHERE (expires_at IS NULL OR expires_at > NOW())
              AND (starts_at IS NULL OR starts_at <= NOW())
              AND status <> 'scheduled'
              AND created_at >= (NOW() - INTERVAL 7 DAY)
            ORDER BY id DESC LIMIT {$limit}");
        $rows = $stmt ? $stmt->fetchAll(PDO::FETCH_ASSOC) : [];
        return is_array($rows) ? array_map('bm_push_expand', $rows) : [];
    }
}

if (!function_exists('bm_push_delete')) {
    function bm_push_delete(PDO $pdo, int $id): int {
        bm_push_ensure_schema($pdo);
        if ($id <= 0) return 0;
        bm_push_revoke($pdo, $id);
        $stmt = $pdo->prepare('DELETE FROM app_push_notifications WHERE id=?');
        $stmt->execute([$id]);
        return (int)$stmt->rowCount();
    }
}

if (!function_exists('bm_push_clear_all')) {
    function bm_push_clear_all(PDO $pdo, bool $optimize = true): int {
        bm_push_ensure_schema($pdo);
        $count = 0;
        try {
            $ids = $pdo->query('SELECT id FROM app_push_notifications')->fetchAll(PDO::FETCH_COLUMN) ?: [];
            foreach ($ids as $id) bm_push_revoke($pdo, (int)$id);
            $count = (int)$pdo->exec('DELETE FROM app_push_notifications');
        } catch (Throwable $e) {}
        if ($optimize) {
            try { $pdo->exec('OPTIMIZE TABLE app_push_notifications'); } catch (Throwable $e) {}
        }
        return $count;
    }
}

if (!function_exists('bm_push_legacy_cleanup')) {
    /**
     * Purge legacy APP notification history/read/dismiss state only.
     * Website notifications and notification_views are intentionally untouched.
     * Table structures stay in place for legacy app compatibility.
     */
    function bm_push_legacy_cleanup(PDO $pdo, bool $force = false, bool $optimize = true): array {
        $pdo->exec("CREATE TABLE IF NOT EXISTS app_push_migrations (
            migration_key VARCHAR(120) NOT NULL PRIMARY KEY,
            completed_at DATETIME NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $key = 'legacy_app_notification_history_purge_v2';
        if (!$force) {
            try {
                $check = $pdo->prepare('SELECT completed_at FROM app_push_migrations WHERE migration_key=? LIMIT 1');
                $check->execute([$key]);
                if ($check->fetchColumn()) return ['ran'=>false,'already_done'=>true,'deleted'=>[]];
            } catch (Throwable $e) {}
        }

        $targets = [
            'app_notification_global_state',
            'app_notification_dismissals',
            'app_notifications',
        ];
        $deleted = [];
        foreach ($targets as $table) {
            if (!bm_push_table_exists($pdo, $table)) {
                $deleted[$table] = 0;
                continue;
            }
            try {
                $deleted[$table] = (int)$pdo->exec("DELETE FROM `{$table}`");
            } catch (Throwable $e) {
                $deleted[$table] = -1;
                error_log('legacy notification purge ' . $table . ': ' . $e->getMessage());
            }
        }

        try {
            $mark = $pdo->prepare("INSERT INTO app_push_migrations(migration_key,completed_at) VALUES(?,NOW())
                ON DUPLICATE KEY UPDATE completed_at=VALUES(completed_at)");
            $mark->execute([$key]);
        } catch (Throwable $e) {}

        if ($optimize) {
            foreach ($targets as $table) {
                if (!bm_push_table_exists($pdo, $table)) continue;
                try { $pdo->exec("OPTIMIZE TABLE `{$table}`"); } catch (Throwable $e) {}
            }
        }
        return ['ran'=>true,'already_done'=>false,'deleted'=>$deleted];
    }
}
