# BankMovie TV Focus V7.10 — Search IME Stability + Category Focus Rebuild

این پچ فقط دو مورد را تغییر می‌دهد:

1. **لایو سرچ TV بدون ریست شدن انتخاب کیبورد**
   - debounce لایو سرچ 260ms باقی مانده است.
   - هنگام تایپ، `showSoftInput()`، `requestFocus()` یا keep-alive دوباره روی EditText اجرا نمی‌شود.
   - وقتی نتیجه‌های async به Grid اضافه می‌شوند، اگر همان Search EditText هنوز فوکس دارد، دوباره `requestFocus()` روی آن زده نمی‌شود.
   - نتیجه: صفحه نتایج لایو آپدیت می‌شود ولی انتخاب داخلی کیبورد TV نباید بعد از هر حرف به کلید اول/عدد 1 برگردد.

2. **بازنویسی کامل فوکس هاب دسته‌بندی 2x2**
   - مسیر قدیمی `focusSearch()` و routing مبتنی بر child-index برای چهار کارت حذف شده است.
   - هر کارت تگ معنایی مستقل دارد و مسیرها ثابت‌اند:
     - Genres → Right: Collections / Down: Top Movies
     - Collections → Left: Genres / Down: Top Series
     - Top Movies → Right: Top Series / Up: Genres
     - Top Series → Left: Top Movies / Up: Collections
   - Generic geometry focus graph برای این هاب غیرفعال است.

هیچ تغییری در Detail/Trailer، Player، Home، Profile یا سایر مسیرها در این پچ انجام نشده است.
