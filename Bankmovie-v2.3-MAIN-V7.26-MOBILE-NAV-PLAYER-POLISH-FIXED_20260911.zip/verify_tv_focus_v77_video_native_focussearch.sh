#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.7 marker: $2" >&2; exit 1; }; }
need "$MARKER" 'focusPatch=V7.7 VIDEO NATIVE FOCUSSEARCH ROOT'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V77-20260908'
need 'BANKMOVIE_TV_FOCUS_V7_7_VIDEO_NATIVE_FOCUSSEARCH_FIX_FA.md' 'V7.7 NATIVE FOCUSSEARCH + TV SEARCH SUBMIT'
need "$MAIN" 'tvFocusVideoRootPatchV77 = "V7.7 NATIVE FOCUSSEARCH + TV SEARCH SUBMIT"'
need "$MAIN" 'override fun focusSearch(focused: View?, direction: Int): View?'
need "$MAIN" 'tag = "bm_v77_category_hub_grid"'
need "$MAIN" 'tag = "bm_v77_detail_actions"'
need "$MAIN" 'suppressTvDetailBackFocus = currentScreen == "detail" && v.tag == "bm_tv_detail_back"'
need "$MAIN" 'the recording proves the TV keyboard closes'
need "$MAIN" 'restartSearch(input.text?.toString().orEmpty(), preserveTvIme = false)'

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
# TV watcher must return before any 320ms restartSearch scheduling.
w=s.index('input.addTextChangedListener(object : TextWatcher')
e=s.index('override fun beforeTextChanged', w)
block=s[w:e]
assert 'if (tv)' in block
assert 'V7.7 VIDEO ROOT' in block
assert 'pendingSearch = Runnable { restartSearch(value, preserveTvIme = false) }' in block
assert block.index('if (tv)') < block.index('pendingSearch = Runnable { restartSearch(value, preserveTvIme = false) }')
# Category grid must intercept native FocusFinder and map DOWN by +2.
c=s.index('val grid = object : GridLayout(this) {', s.index('private fun showCategories()'))
ce=s.index('val cards=listOf(', c)
cb=s[c:ce]
assert 'View.FOCUS_DOWN -> if (index < 2) index + 2 else index' in cb
assert 'return directTvFocusable(getChildAt(targetIndex)) ?: getChildAt(targetIndex)' in cb
# Detail row must own native horizontal focus and Back must be removed from TV traversal.
d=s.index('val actions = object : LinearLayout(this) {', s.index('private fun renderDetailTv'))
de=s.index('val primaryAction = detailActionButton', d)
db=s[d:de]
assert 'direction == View.FOCUS_LEFT || direction == View.FOCUS_RIGHT' in db
assert 'return target ?: focused' in db
assert 'suppressTvDetailBackFocus' in s
print('V7.7 structural checks passed')
PY

echo 'TV_FOCUS_V77_VIDEO_NATIVE_FOCUSSEARCH_OK'
