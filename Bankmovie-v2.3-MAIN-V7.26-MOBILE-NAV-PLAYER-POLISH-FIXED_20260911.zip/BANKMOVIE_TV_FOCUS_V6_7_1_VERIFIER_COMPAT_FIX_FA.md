# BankMovie TV Focus V6.7.1 — Verifier Compatibility Fix

- App focus logic remains V6.7 NATIVE-FIRST ROOT.
- Fixes a stale compatibility chain where `verify_tv_focus_flow_v2.sh` still invoked the V6.6 source-marker verifier.
- V6.6 verifier now treats V6.7 as a superseding patch after running the V6.7 verifier.
- This change is build-verifier only; versionName remains 2.3.
