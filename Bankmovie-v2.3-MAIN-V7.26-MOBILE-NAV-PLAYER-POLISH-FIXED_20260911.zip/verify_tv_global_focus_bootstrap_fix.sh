#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
SCROLL='app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt'
DOWN='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'

for marker in \
  'private var tvScreenFocusGeneration = 0' \
  'private var tvInitialFocusPending = false' \
  'private fun requestTvInitialScreenFocus' \
  'releaseTvFocusScrollGuards(content)' \
  '"search" -> content.findViewWithTag<View>("bm_tv_search_input")' \
  'val isTvTarget = v.isFocusable && (v.hasOnClickListeners() || v is EditText)' \
  'tag = "bm_tv_search_input"' \
  'tag = "bm_tv_profile_primary"' \
  'scheduleTvInitialScreenFocus(20L)'; do
  grep -Fq "$marker" "$MAIN" || { echo "Missing MainActivity marker: $marker" >&2; exit 1; }
done

# V7.1+ Profile/About bootstrap intentionally split the old one-line profile target:
# - the About surface (still under currentScreen == "profile") uses bm_v71_about_row_0
# - the normal Profile page falls back to bm_tv_profile_primary.
# Accept either the legacy direct route or the new explicit two-stage route.
if ! grep -Fq '"profile" -> content.findViewWithTag<View>("bm_tv_profile_primary")' "$MAIN"; then
  grep -Fq '"profile" -> content.findViewWithTag<View>("bm_v71_about_row_0")' "$MAIN" || {
    echo 'Missing MainActivity profile bootstrap route: bm_v71_about_row_0' >&2
    exit 1
  }
  grep -Fq '?: content.findViewWithTag<View>("bm_tv_profile_primary")' "$MAIN" || {
    echo 'Missing MainActivity profile bootstrap fallback: bm_tv_profile_primary' >&2
    exit 1
  }
fi

for marker in \
  'private var suppressTvFocusReveal = tvLike' \
  'fun releaseTvInitialFocusGuard()' \
  'override fun requestChildFocus(child: View, focused: View)' \
  'override fun requestChildRectangleOnScreen'; do
  grep -Fq "$marker" "$SCROLL" || { echo "Missing ScrollView guard marker: $marker" >&2; exit 1; }
done

grep -Fq 'private lateinit var pageScroll: BankmovieSmoothScrollView' "$DOWN"
grep -Fq 'pageScroll.releaseTvInitialFocusGuard()' "$DOWN"
grep -Fq 'pageScroll.scrollTo(0, 0)' "$DOWN"

# Home must not directly request focus anymore; central bootstrap owns it.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
home=s[s.index('    private fun showHome()'):s.index('    private fun openTelegramChannel()', s.index('    private fun showHome()'))]
assert 'initialTarget?.requestFocus()' not in home
assert 'scheduleTvInitialScreenFocus(20L)' in home
search=s[s.index('    private fun showSearch('):s.index('    private fun liveSearch(', s.index('    private fun showSearch('))]
assert 'tag = "bm_tv_search_input"' in search
assert 'if (tv) {' in search and 'scheduleTvInitialScreenFocus(35L)' in search
print('TV_GLOBAL_FOCUS_BOOTSTRAP_FIX_OK')
PY
