#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.6.1 marker: $2" >&2; exit 1; }; }
need "$MARKER" 'focusPatch=V7.6.1 VIDEO FIRST CHAR DETAIL CATEGORY ROOT'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V761-20260908'
need 'BANKMOVIE_TV_FOCUS_V7_6_1_VIDEO_FIRST_CHAR_ROOT_FIX_FA.md' 'Video First-Character Root Fix'
need "$MAIN" 'V7.6.1 FIRST-CHAR FIX'
need "$MAIN" 'keepTvSearchImeOpen(input, 40L)'
need "$MAIN" 'keepTvSearchImeOpen(input, 180L)'
need "$MAIN" 'keepTvSearchImeOpen(input, 420L)'
need "$MAIN" 'private fun wireV76DetailActionRow('
need "$MAIN" 'tag = "bm_tv_detail_trailer"'
need "$MAIN" 'wireV76DetailActionRow(actions, primaryAction, trailerAction, favoriteAction)'
need "$MAIN" 'private fun wireV76CategoryHubGrid(grid: GridLayout)'
need "$MAIN" 'KEYCODE_DPAD_DOWN -> if (index < 2) cells[index + 2] else null'
need "$MAIN" 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)'
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=s.index('private fun keepTvSearchImeOpen')
b=s.index('private fun requestTvSoftKeyboard',a)
assert 'restartInput(input)' not in s[a:b]
rs=s.index('fun restartSearch(raw: String, preserveTvIme: Boolean = false)')
q=s.index('if (query.length < 2)', rs)
r=s.index('\n                return\n',q)
assert 'keepTvSearchImeOpen(input, 40L)' in s[q:r]
print('V7.6.1 structural checks passed')
PY
echo 'TV_FOCUS_V761_VIDEO_FIRST_CHAR_ROOT_OK'
