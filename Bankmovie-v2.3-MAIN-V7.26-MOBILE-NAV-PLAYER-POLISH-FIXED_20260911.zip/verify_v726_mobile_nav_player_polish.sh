#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
PREFS='app/src/main/java/ir/bankmoviee/app/UiPreferences.kt'

# Keep the important pre-V7.26 regressions, but do not call V7.25 directly because
# that verifier intentionally pins the previous 28dp utility icon size.
bash verify_v724_search_scroll_svg_refresh.sh
bash verify_v722_cast_removed_player_retained.sh
bash verify_v723_player_last_frame_hold.sh
bash verify_tv_focus_v719_history_watchlist_compact_bootstrap.sh

grep -Fq 'BANKMOVIE_V7_26_MOBILE_NAV_PERSONALIZATION' "$MAIN"
grep -Fq 'KEY_MOBILE_NAV_STYLE = "ui_mobile_nav_style"' "$PREFS"
grep -Fq 'fun mobileNavStyle(context: Context): String' "$PREFS"
grep -Fq '"classic",' "$PREFS"
for style in minimal glass floating neumorph pill center_fab gradient outline indicator curved; do
  grep -Fq "\"$style\"" "$PREFS"
  grep -Fq "\"$style\"" "$MAIN"
done

grep -Fq 'private fun mobileNavStylePreview(' "$MAIN"
grep -Fq 'private fun mobileNavPreviewBar(style: String): View' "$MAIN"
grep -Fq 'شخصی‌سازی منوی موبایل' "$MAIN"
grep -Fq 'if (!isTvLike()) {' "$MAIN"
grep -Fq 'applyMobileBottomNavContainerStyle(UiPreferences.mobileNavStyle(this))' "$MAIN"
# TV must branch away before any mobile style is read/applied.
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a=s.index('private fun buildBottomNav()')
b=s.index('private fun tvSideNavCollapsedWidth()', a)
block=s[a:b]
assert block.index('if (isTvLike())') < block.index('UiPreferences.mobileNavStyle(this)')
assert 'buildTvSideNavigation()' in block
# Classic remains opt-in branch with the exact pre-V7.26 dimensions.
n=s.index('private fun navSvg(', b)
e=s.index('private fun nav(', n)
nav=s[n:e]
assert 'if (style == "classic")' in nav
assert 'LinearLayout.LayoutParams(dp(25), dp(25))' in nav
assert 'setPadding(dp(4), dp(6), dp(4), dp(5))' in nav
PY

grep -Fq 'BANKMOVIE_V7_26_PLAYER_UTILITY_ICON_TUNING' "$PLAYER"
grep -Fq 'PLAYER_UTILITY_ICON_DP = 24' "$PLAYER"
grep -Fq 'FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER).apply { rightMargin = dp(8) }' "$PLAYER"
# Center controls remain unchanged from V7.25.
grep -Fq 'LinearLayout.LayoutParams(dp(32), dp(32))' "$PLAYER"
grep -Fq 'play.addView(playIcon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))' "$PLAYER"
grep -Fq 'centerControls.addView(rewind, LinearLayout.LayoutParams(dp(70), dp(70))' "$PLAYER"
grep -Fq 'centerControls.addView(play, LinearLayout.LayoutParams(dp(82), dp(82)))' "$PLAYER"
grep -Fq 'centerControls.addView(forward, LinearLayout.LayoutParams(dp(70), dp(70))' "$PLAYER"
# Frame bridge preserved.
grep -Fq 'PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L' "$PLAYER"
grep -Fq 'lifecycleFrameProbeReadySamples >= 2' "$PLAYER"
# Cast remains removed.
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$PLAYER"
! grep -Eq 'play-services-cast|androidx\.mediarouter' app/build.gradle

grep -Fq 'sourceMainUpdateSeventhHotfixTag=BANKMOVIE-2.3-V726-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V726_MOBILE_NAV_PLAYER_POLISH_OK
