# BankMovie TV Focus V6.9 — Weekly + Continue Root Fix

این پچ فقط دو سطح باقی‌مانده را از V6.8 جدا می‌کند و Box Office / Advanced Search را دست نمی‌زند.

## Weekly
- اولین render و render بعد از تغییر روز از یک wiring واحد استفاده می‌کنند.
- هیچ DPAD در صورت شکست `requestFocus()` مصرف نمی‌شود.
- تب روز و پوسترها `nextFocus` بومی + router مستقیم خود View دارند.
- wiring بعد از attach و دو فریم layout دوباره تثبیت می‌شود تا حالت «هاله آبی ولی فوکوس قفل» ایجاد نشود.

## Continue Watching
- ورود عمودی پروفایل مستقیم روی اولین/راست‌ترین کارت Continue است.
- «مشاهده همه» فقط end-cap افقی بعد از آخرین/چپ‌ترین کارت است.
- حرکت LEFT/RIGHT روی خود کارت‌ها route مستقیم دارد و به geometry graph وابسته نیست.
