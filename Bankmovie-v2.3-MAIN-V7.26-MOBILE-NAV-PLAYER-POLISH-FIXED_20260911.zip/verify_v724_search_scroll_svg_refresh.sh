#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
RES='app/src/main/res/drawable'

bash verify_v722_cast_removed_player_retained.sh
bash verify_v723_player_last_frame_hold.sh

grep -Fq 'val scrollY: Int,' "$MAIN"
grep -Fq 'scrollY = savedY,' "$MAIN"
grep -Fq 'V7.24: retaining the real Search View tree prevents refetching' "$MAIN"
grep -Fq 'val targetY = snapshot.scrollY.coerceAtMost(maxY)' "$MAIN"
grep -Fq 'retainedScroll.scrollTo(0, targetY)' "$MAIN"

for icon in \
  ic_download.xml ic_info_archive.xml ic_boxoffice_nav.xml ic_search_clean.xml \
  ic_player_settings.xml ic_nav_collection.xml \
  ic_nav_home.xml ic_nav_filter.xml ic_copy_link.xml ic_about.xml \
  ic_admin_verified.xml ic_full_cleanup.xml ic_nav_profile.xml ic_nav_heart.xml \
  ic_player_cc.xml ic_tv_nav_download_preview.xml ic_tv_nav_boxoffice_preview.xml \
  ic_tv_nav_search_preview.xml ic_tv_nav_home_preview.xml \
  ic_tv_nav_profile_preview.xml ic_tv_nav_favorites_preview.xml; do
  test -s "$RES/$icon"
done

grep -Fq 'R.drawable.ic_boxoffice_nav' "$MAIN"
grep -Fq 'R.drawable.ic_nav_collection' "$MAIN"
grep -Fq 'R.drawable.ic_about' "$MAIN"
grep -Fq 'R.drawable.ic_admin_verified' "$MAIN"
grep -Fq 'R.drawable.ic_full_cleanup' "$MAIN"
grep -Fq 'setImageResource(R.drawable.ic_player_cc)' "$PLAYER"

grep -Fq 'sourceMainUpdateFifthHotfixTag=BANKMOVIE-2.3-V724-20260910' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V724_SEARCH_SCROLL_SVG_REFRESH_OK
