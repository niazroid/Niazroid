# BankMovie TV Focus V7.15 — Auth + Downloader no-reorder fix

## علت واقعی
در `AuthActivity.applyFocusHalo()` و `DownloadsActivity.premiumFocus()` هنگام گرفتن فوکس، `bringToFront()` اجرا می‌شد. داخل `LinearLayout` این فقط یک افکت تصویری نیست؛ ترتیب childها را تغییر می‌دهد. نتیجه روی TV این بود که دکمه‌های «ورود / ثبت‌نام» و دکمه‌های اکشن دانلود هنگام جابه‌جایی فوکس واقعاً جای‌شان عوض می‌شد.

## اصلاح
- `bringToFront()` از هر دو focus decorator حذف شد؛ glow فقط با foreground/elevation/translationZ/scale نمایش داده می‌شود.
- در Auth ترتیب اکشن ثابت شد: Submit سپس سوییچ ورود/ثبت‌نام.
- برای TV زنجیره Up/Down فرم Auth صریح و مبتنی بر ID است و به FocusFinder هندسی وابسته نیست.
- ناوبری row-aware دانلود حفظ شده و چون child order دیگر mutate نمی‌شود، UP/DOWN ستون همان دکمه را بدون جابه‌جایی ظاهری دنبال می‌کند.
- فیکس‌های V7.11 Categories، V7.13 Detail و V7.14 VIP/Drawer به‌عنوان regression guard بررسی می‌شوند.
