#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$main"

# V7.16 catalogue/genre grid bootstrap: first DPAD follows the visibly focused
# physical top-right poster, not a stale GridLayout child index/currentFocus.
grep -Fq 'private fun armV716CatalogueGridBootstrap(grid: GridLayout)' "$main"
grep -Fq 'grid.tag = "bm_v716_catalogue_grid"' "$main"
grep -Fq 'private fun v716PhysicalGridNeighbor(grid: GridLayout, source: View, keyCode: Int): View?' "$main"
grep -Fq 'Deliberately ignore a stale first-frame currentFocus.' "$main"
grep -Fq 'handleV716CatalogueGridFirstDirectionalFocus(focusedOrNull, keyCode)?.let { return it }' "$main"
grep -Fq 'tvV716CatalogueConsumedDirectionalKeyCode = keyCode' "$main"
grep -Fq 'event.keyCode == tvV716CatalogueConsumedDirectionalKeyCode' "$main"
grep -Fq 'if (tv && p == 1) armV716CatalogueGridBootstrap(grid)' "$main"
grep -Fq 'if (tv && pageNumber == 1) armV716CatalogueGridBootstrap(grid)' "$main"

# VIP status/day bidi and crown SVG spacing.
grep -Fq 'val dayLabel = if (isFa()) persianDigits(days.toString()) else days.toString()' "$main"
grep -Fq 'textDirection = View.TEXT_DIRECTION_RTL' "$main"
grep -Fq 'first RTL child padded the outside edge and left the SVG' "$main"
grep -Fq 'addView(View(this@MainActivity), LinearLayout.LayoutParams(dp(9), dp(1)))' "$main"

# Home slider IMDb badge uses a real direction-safe gap from Watch Now.
grep -Fq 'tag = "bm_v716_slider_imdb_gap"' "$main"
grep -Fq 'addView(ratingGap, LinearLayout.LayoutParams(dp(18), dp(1)))' "$main"
grep -Fq 'ratingGap.visibility = if (rating > 0) View.VISIBLE else View.GONE' "$main"

# Regression guards for device-confirmed fixes.
bash verify_tv_focus_v715_auth_download_no_reorder.sh >/dev/null
bash verify_tv_focus_v713_detail_first_press.sh >/dev/null
bash verify_tv_focus_v711_category_bootstrap.sh >/dev/null
grep -Fq 'V7.10 LIVE TV SEARCH' "$main"

echo TV_FOCUS_V716_PROFILE_SLIDER_CATALOGUE_BOOTSTRAP_OK
