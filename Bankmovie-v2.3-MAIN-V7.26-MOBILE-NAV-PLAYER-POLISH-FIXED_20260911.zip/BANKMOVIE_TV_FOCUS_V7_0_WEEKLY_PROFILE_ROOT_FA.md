# BankMovie TV Focus V7.0 — Weekly + Profile Root

این پچ فقط دو سطح باقی‌مانده‌ی تلویزیون را بازسازی می‌کند و بخش‌های تأییدشده‌ی Box Office، Advanced Search و Continue Watching را دست نمی‌زند.

## Weekly
- مسیر فوکوس دیگر به tagهای V6.9 یا WeakHashMap قدیمی وابسته نیست.
- child واقعی ردیف روزها/پوسترها در لحظه‌ی فشردن DPAD از روی parent row پیدا می‌شود.
- هنگام wiring تمام listener/action قدیمی همان child پاک می‌شود و nextFocus از صفر نوشته می‌شود.
- ورود به Weekly یک focus transaction کوتاه و generation-safe دارد تا اولین render مثل تغییر روز رفتار کند.
- اگر firmware فوکوس را روی scroller/section نگه دارد، اولین DPAD آن را به child واقعی normalize می‌کند.

## Profile
- دو Grid اصلی پروفایل (`actions` و `utility`) یک router صریح RTL دارند.
- child شماره 0 سمت راست است، پس LEFT به index+1 و RIGHT به index-1 می‌رود.
- این router قبل از Grid/router عمومی Activity اجرا می‌شود؛ بنابراین دیگر لازم نیست ابتدا UP زده شود تا جهت‌ها «فعال» شوند.
- Continue Watching همان V6.9 تأییدشده باقی مانده است.

نسخه برنامه: 2.3
