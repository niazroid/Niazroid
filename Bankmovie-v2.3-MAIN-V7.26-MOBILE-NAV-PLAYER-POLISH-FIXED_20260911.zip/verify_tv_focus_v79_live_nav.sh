#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
grep -Fq 'focusPatchSecondFollowup=V7.9 LIVE SEARCH + CATEGORY VERTICAL + DETAIL TRAILER ROUTING' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.9 LIVE SEARCH + CATEGORY VERTICAL + DETAIL TRAILER ROUTING' BANKMOVIE_TV_FOCUS_V7_9_LIVE_NAV_FIX_FA.md
grep -Fq 'pendingSearch = Runnable { restartSearch(value, preserveTvIme = true) }' "$MAIN"
grep -Fq 'debounce.postDelayed(pendingSearch!!, 260L)' "$MAIN"
grep -Fq 'clearBtn.visibility = View.VISIBLE' "$MAIN"
grep -Fq 'rowSpec = GridLayout.spec(index / 2)' "$MAIN"
grep -Fq 'columnSpec = GridLayout.spec(index % 2, 1f)' "$MAIN"
grep -Fq 'val index = focusedChildIndex(grid, focused)' "$MAIN"
grep -Fq 'primary -> trailer ?: favorite ?: primary' "$MAIN"
if grep -Fq 'imm.restartInput(input)' "$MAIN"; then
  echo 'Unexpected restartInput in TV search path' >&2
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
# TV watcher must live-search and preserve IME.
w = s.index('input.addTextChangedListener(object : TextWatcher')
e = s.index('override fun beforeTextChanged', w)
block = s[w:e]
assert 'restartSearch(value, preserveTvIme = true)' in block
assert 'Search/Enter is the only submit point on TV.' not in block
# Category handler must use direct child index; no filtered cells list in handler.
c = s.index('private fun handleV76CategoryHubDirectionalFocus')
e = s.index('/** V7.4 live Categories router', c)
block = s[c:e]
assert 'focusedChildIndex(grid, focused)' in block
assert 'index + 2' in block and 'index - 2' in block
# Detail route must prefer trailer when present and not filter tags through isShown.
d = s.index('private fun handleV74DetailDirectionalFocus')
e = s.index('private fun handleTvDirectionalFocus', d)
block = s[d:e]
assert 'primary -> trailer ?: favorite ?: primary' in block
assert '.filter { it.isShown && it.isEnabled }' not in block
print('TV_FOCUS_V79_LIVE_NAV_OK')
PY
