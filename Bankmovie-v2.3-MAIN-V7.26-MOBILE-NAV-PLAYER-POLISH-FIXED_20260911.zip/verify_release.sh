#!/usr/bin/env bash
set -euo pipefail
EXPECTED_KEYSTORE="b73994bc2228e91763fde6d049fa792e44bcfce4f1359bef8d0bd6cd6d2f7b39"
echo "$EXPECTED_KEYSTORE  bankmovie_update.jks" | sha256sum -c -
grep -q "applicationId 'ir.bankmoviee.app'" app/build.gradle
grep -q 'versionName "2.3"' app/build.gradle
grep -q 'signingConfig signingConfigs.bankmovieStable' app/build.gradle
for f in server-required/*.php; do php -l "$f" >/dev/null; done
python3 - <<'PY'
import json, xml.etree.ElementTree as ET
from pathlib import Path
json.load(open('server-required/bankmovie_remote_config.json.sample', encoding='utf-8'))
for p in Path('app/src/main').rglob('*.xml'): ET.parse(p)
print('JSON/XML OK')
PY
echo 'Static validation completed.'
