#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.4 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.4 SEARCH CATEGORY DETAIL NATIVE ROOT'
need "$MARKER" 'verifierPatch=V7.4 SEARCH-VISIBLE-BRIDGE + SYNTHETIC-IME-TAP + CATEGORY-LIVE-DPAD + DETAIL-ACTION-ROW-GUARD'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V74-20260908'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_4_SEARCH_CATEGORY_DETAIL_NATIVE_ROOT_FA.md' 'Search / Category / Detail Native Root'

# Search: a real visible focus bridge plus TextView touch path, not an alpha-zero sink only.
need "$MAIN" 'private var tvSearchImeBridgeActiveUntil = 0L'
need "$MAIN" 'V7.4 SEARCH REAL-FOCUS BRIDGE'
need "$MAIN" 'content.findViewWithTag<View>("bm_v74_search_focus_bridge")'
need "$MAIN" 'input.requestFocusFromTouch()'
need "$MAIN" 'input.dispatchTouchEvent(down)'
need "$MAIN" 'imm.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_FORCED)'
need "$MAIN" 'tag = "bm_v74_search_focus_bridge"'
need "$MAIN" 'android.os.SystemClock.uptimeMillis() < tvSearchImeBridgeActiveUntil'

# Categories: first DPAD is owned synchronously before generic/native routing.
need "$MAIN" 'private fun handleV74CategoryDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'grid.tag != "bm_v73_category_grid"'
need "$MAIN" 'rows.getOrNull(rowIndex + 1)?.minByOrNull { kotlin.math.abs(it.x - current.x) }'
need "$MAIN" 'handleV74CategoryDirectionalFocus(focused, keyCode)?.let { return it }'

# Detail: horizontal action-row navigation never escapes to floating Back.
need "$MAIN" 'tag = "bm_v74_detail_actions"'
need "$MAIN" 'private fun handleV74DetailDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'native focusSearch() to jump diagonally to bm_tv_detail_back.'
need "$MAIN" 'return if (target != null) move(target) else true'
need "$MAIN" 'handleV74DetailDirectionalFocus(focused, keyCode)?.let { return it }'

# Previously confirmed fixes stay present.
need "$MAIN" 'private fun wireV72WatchlistGrid(grid: GridLayout)'
need "$MAIN" 'private fun wireV71ProfileBootstrapSurface(page: View)'
need "$MAIN" 'private fun wireV70WeeklySurface()'
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'
need "$MAIN" 'val forceArchive4PosterPalette = detailArchiveForArtwork == 4 && poster.isNotBlank()'

echo 'TV_FOCUS_V74_SEARCH_CATEGORY_DETAIL_NATIVE_ROOT_OK'
