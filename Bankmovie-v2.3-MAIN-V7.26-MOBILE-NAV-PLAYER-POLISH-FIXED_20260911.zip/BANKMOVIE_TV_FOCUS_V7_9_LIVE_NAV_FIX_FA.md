# BankMovie TV V7.9 — Live Search + Navigation Fix

این پچ سه مورد گزارش‌شده روی فوکس تلویزیون را اصلاح می‌کند:

1. **جستجوی لایو روی TV**
   - `TextWatcher` دیگر منتظر Search/Enter نمی‌ماند.
   - بعد از 260ms توقف کوتاه در تایپ، جستجو خودکار اجرا می‌شود.
   - در زمان جستجوی لایو، کنترل پاک‌کردن در layout باقی می‌ماند و فقط `alpha/enabled` تغییر می‌کند تا IME روی بعضی TVها بسته نشود.
   - `restartSearch(..., preserveTvIme = true)` همان EditText/InputConnection را حفظ می‌کند.

2. **هاب دسته‌بندی 2×2**
   - چهار کارت ژانرها، کالکشن‌ها، Top 250 فیلم و Top 250 سریال row/column صریح دارند.
   - مسیر بالا/پایین از index مستقیم child محاسبه می‌شود و دیگر از لیست focusable فیلترشده استفاده نمی‌کند.
   - DOWN/UP همیشه در همان ستون می‌ماند؛ LEFT/RIGHT رفتار قبلی را حفظ می‌کند.

3. **اکشن‌های صفحه جزئیات**
   - مسیر Play/Trailer/Watchlist بر اساس tag معنایی انجام می‌شود، نه لیست موقتی `isShown/isEnabled`.
   - اگر Trailer وجود داشته باشد، حرکت افقی از «پخش آنلاین» ابتدا روی Trailer می‌رود و آن را رد نمی‌کند.

Marker: `V7.9 LIVE SEARCH + CATEGORY VERTICAL + DETAIL TRAILER ROUTING`
