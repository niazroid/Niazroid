# BankMovie TV V7.7 — Video Native FocusSearch Fix

این پاس از روی ویدیوی واقعی دستگاه انجام شده است، نه فقط markerهای سورس.

## علت‌های پیدا شده

1. Search TV: اجرای `restartSearch()` با debounce برابر 320ms همزمان با نمایش کیبورد، grid/loading را mutate می‌کرد. در ویدیو بسته‌شدن IME دقیقاً همزمان با شروع loading دیده می‌شود. در TV، live mutation هنگام تایپ حذف شده و Search/Enter جستجو را submit می‌کند.
2. Categories 2x2: مسیرهای Activity/nextFocus روی firmware دستگاه authoritative نبودند و native FocusFinder هنوز DOWN را افقی resolve می‌کرد. Grid حالا `focusSearch()` را در خود ViewGroup override می‌کند، علاوه بر binding همزمان nextFocus/OnKey.
3. Detail: دکمه Back شناور هنوز focusable بود و به عنوان کاندید diagonal توسط FocusFinder انتخاب می‌شد. روی TV از DPAD focus traversal حذف شده و action row هم `focusSearch()` اختصاصی دارد. Back فیزیکی ریموت همچنان مسیر بازگشت است.

Marker: V7.7 NATIVE FOCUSSEARCH + TV SEARCH SUBMIT
