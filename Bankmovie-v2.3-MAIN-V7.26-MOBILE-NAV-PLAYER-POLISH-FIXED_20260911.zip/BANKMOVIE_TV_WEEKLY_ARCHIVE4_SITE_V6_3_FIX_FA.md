# BankMovie TV / Site V6.3

این پاس سه ریشه‌ی مستقل را اصلاح می‌کند:

- فوکوس TV در انتهای Home: یک بار DOWN از آخرین ریل، بخش پخش هفتگی را واقعاً فوکوس می‌کند. اتصال فوکوس بعد از attach شدن Weekly انجام می‌شود و در صورت race کوتاه layout، همان یک کلید با retry نسل‌محور تکمیل می‌شود.
- آرشیو ۴: TV دیگر تنظیم remote بخش‌های Home را نادیده نمی‌گیرد. `app_config.php` لیست بخش‌های فعال آرشیو ۴ و endpoint دقیق `api4.php` را منتشر می‌کند و خود `api4.php` نیز خاموش بودن بخش‌ها را enforce می‌کند.
- خطاهای PHP `Array to string conversion`: ورودی‌های چندشکلی poster/backdrop/html قبل از string شدن با helper امن scalar می‌شوند.

تغییر سایت ویندوز نیز در ZIP سایت انجام شده است: برای VLC/KMPlayer/PotPlayer روی Windows دیگر custom protocol یا Windows helper اجرا نمی‌شود؛ لینک کپی و راهنمای Open Network/Open URL نمایش داده می‌شود.
