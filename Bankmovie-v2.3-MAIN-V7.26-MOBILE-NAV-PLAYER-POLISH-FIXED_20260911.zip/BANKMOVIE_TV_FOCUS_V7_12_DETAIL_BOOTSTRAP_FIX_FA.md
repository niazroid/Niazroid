# BankMovie TV Focus V7.12 — Detail Action Single-Owner Bootstrap

این پچ فقط فوکس اکشن‌های بالای صفحه فیلم/سریال در TV را اصلاح می‌کند و سرچ V7.10 و دسته‌بندی V7.11 را تغییر نمی‌دهد.

## باگ
در ورود اولیه به Detail، ظاهر روی «پخش آنلاین» بود اما مالک واقعی فوکس در بعضی TVها هنوز null یا یکی از wrapperهای Hero/Page بود. اولین DPAD در این فاصله به Android FocusFinder می‌رسید و به‌صورت هندسی Watchlist را انتخاب می‌کرد؛ بعد از برگشت به Play، چون فوکس واقعی روی یکی از اکشن‌ها تثبیت شده بود، مسیر Trailer درست می‌شد.

## اصلاح V7.12
- ردیف Detail یک مالک فوکس واحد دارد: `handleV712DetailActionDirectionalFocus`.
- مالک V7.12 قبل از شرط nullable `currentFocus` و قبل از router سازگاری V7.4 اجرا می‌شود.
- `Scroll/Page/Hero/Action wrapper` اجازه گرفتن فوکس DPAD ندارند.
- bootstrap در اولین frame روی خود `bm_tv_detail_primary` انجام می‌شود.
- اگر اولین DPAD در حالت null/wrapper برسد، همان کلید از Play پردازش می‌شود و به native FocusFinder نمی‌رسد.
- مسیر افقی Play همیشه ابتدا Trailer را انتخاب می‌کند (اگر Trailer موجود باشد)، نه Watchlist.
- DOWN از اکشن‌ها به اولین کنترل واقعی زیر Hero می‌رود؛ اگر هنوز آماده نشده باشد، روی همان اکشن می‌ماند و هرگز به Watchlist fallback نمی‌کند.
- `focusSearch()` سفارشی قدیمی روی Action row و نصب `wireV76DetailActionRow(...)` برای این ردیف حذف شده‌اند تا چند مالک هم‌زمان وجود نداشته باشد.

## بدون تغییر
- Live Search V7.10
- Categories single-owner V7.11
- Player / Home / Profile / Watchlist logic
