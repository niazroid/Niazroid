# BankMovie V7.23 — Player Last-Frame Hold

- Cast remains fully removed.
- The V7.22 retained LibVLC session remains the primary resume path.
- Before HOME/app-switch, the current VLC `SurfaceView` frame is copied with Android `PixelCopy` (API 24+).
- A lightweight in-memory `ImageView` overlay keeps that exact frame visible while VLC re-attaches/rebuilds its video surface.
- The overlay is below the player controls and is removed only after VLC reports a fresh Vout/time update.
- The retained bitmap is capped to 1280 px width to avoid 4K-frame memory spikes.
- PixelCopy gets a 110 ms grace window before the stopped Activity detaches VLC views.
- Existing rebuild fallback and saved playback position are unchanged.

## Compatibility / fallback

- Android 7.0+ (API 24+): last-frame hold is available through PixelCopy.
- Android 6.0 / API 23: the old retained/rebuild path remains; PixelCopy is unavailable, so a no-black guarantee cannot be made there without switching the whole VLC output to TextureView.
- Secure/DRM/protected surfaces may reject PixelCopy; in that case playback still resumes using the existing V7.22 path, but the black transition can still be visible.
- If Android kills the whole app process, the in-memory held frame is lost. Playback position/state still restores from the existing saved-state path.
