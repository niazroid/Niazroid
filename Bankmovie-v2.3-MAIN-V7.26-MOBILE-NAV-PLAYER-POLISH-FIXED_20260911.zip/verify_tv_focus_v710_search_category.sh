#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

[[ -s "$MAIN" ]]
grep -Fq 'focusPatchThirdFollowup=V7.10 LIVE SEARCH IME STABLE + CATEGORY FOCUS REBUILD' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.10 LIVE SEARCH IME STABLE + CATEGORY FOCUS REBUILD' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.10 Categories hub focus rebuilt from scratch.' "$MAIN"
grep -Fq 'V7.10 LIVE TV SEARCH: submit automatically after a short' "$MAIN"
grep -Fq 'pendingSearch = Runnable { restartSearch(value) }' "$MAIN"
grep -Fq 'debounce.postDelayed(pendingSearch!!, 260L)' "$MAIN"
grep -Fq 'if (!(tv && input.hasFocus() && focusBeforeMutation === input)) {' "$MAIN"

# Old 4-card category routing must be gone completely.
if grep -Fq 'wireV76CategoryHubGrid' "$MAIN"; then
  echo 'Old V7.6 category hub wiring is still present' >&2
  exit 1
fi
if grep -Fq 'handleV76CategoryHubDirectionalFocus' "$MAIN"; then
  echo 'Old V7.6 category Activity router is still present' >&2
  exit 1
fi
if grep -Fq 'bm_v77_category_hub_grid' "$MAIN"; then
  echo 'Old category hub tag is still present' >&2
  exit 1
fi
if grep -Fq 'bm_v79_category_hub_' "$MAIN"; then
  echo 'Old V7.9 category child-index tags are still present' >&2
  exit 1
fi

python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

# ----- Search -----
show = s.index('    private fun showSearch(')
end = s.index('    private fun liveSearch(', show)
search = s[show:end]
w0 = search.index('input.addTextChangedListener(object : TextWatcher')
w1 = search.index('override fun beforeTextChanged', w0)
watch = search[w0:w1]

assert 'pendingSearch = Runnable { restartSearch(value) }' in watch
assert 'debounce.postDelayed(pendingSearch!!, 260L)' in watch
assert 'preserveTvIme' not in search
assert 'keepTvSearchImeOpen' not in search
# Live updates must never reopen or explicitly re-focus the editor.
assert 'showSoftInput(' not in watch
assert 'requestTvSoftKeyboard(input)' not in watch
assert 'input.requestFocus()' not in watch
# Result insertion must avoid re-requesting the already-focused TV editor.
assert 'if (!(tv && input.hasFocus() && focusBeforeMutation === input)) {' in search

# ----- Categories 2x2 hub -----
cat = s.index('    private fun categoryHubV710Target(')
cat_end = s.index('    /** V7.4 live Categories router', cat)
router = s[cat:cat_end]
expected = [
    '"bm_v710_category_genres" -> when (keyCode)',
    'KEYCODE_DPAD_RIGHT -> "bm_v710_category_collections"',
    'KEYCODE_DPAD_DOWN -> "bm_v710_category_top_movies"',
    '"bm_v710_category_collections" -> when (keyCode)',
    'KEYCODE_DPAD_LEFT -> "bm_v710_category_genres"',
    'KEYCODE_DPAD_DOWN -> "bm_v710_category_top_series"',
    '"bm_v710_category_top_movies" -> when (keyCode)',
    'KEYCODE_DPAD_RIGHT -> "bm_v710_category_top_series"',
    'KEYCODE_DPAD_UP -> "bm_v710_category_genres"',
    '"bm_v710_category_top_series" -> when (keyCode)',
    'KEYCODE_DPAD_LEFT -> "bm_v710_category_top_movies"',
    'KEYCODE_DPAD_UP -> "bm_v710_category_collections"',
]
for needle in expected:
    assert needle in router, needle

show_cat = s.index('    private fun showCategories()')
show_cat_end = s.index('    private fun showGenreDirectory(', show_cat)
hub = s[show_cat:show_cat_end]
for tag in (
    'bm_v710_category_genres',
    'bm_v710_category_collections',
    'bm_v710_category_top_movies',
    'bm_v710_category_top_series',
):
    assert tag in hub
assert 'override fun focusSearch' not in hub
assert 'wireV710CategoryHubFocus(cards)' in hub
assert 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)' in hub

# Previous Detail trailer fix must still be present and untouched.
d = s.index('    private fun handleV74DetailDirectionalFocus')
d_end = s.index('    private fun handleTvDirectionalFocus', d)
detail = s[d:d_end]
assert 'primary -> trailer ?: favorite ?: primary' in detail

print('TV_FOCUS_V710_SEARCH_CATEGORY_OK')
PY
