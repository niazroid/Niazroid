# BankMovie TV Focus V6.8 — Surface Rebuild Root

این نسخه چهار سطح مشکل‌دار TV را از گراف عمومی/هندسی فوکوس جدا می‌کند و مسیر فوکوس آن‌ها را از صفر با یک مالک مشخص برای هر کنترل می‌سازد.

## 1) جدول پخش هفتگی
- ردیف روزها و ردیف پوسترها دو sequence مستقل هستند.
- هر روز و هر پوستر tag/index پایدار دارد.
- DOWN از روز فعال مستقیماً به پوستر اول همان روز می‌رود.
- LEFT/RIGHT بین پوسترها فقط با index واقعی همان ردیف حرکت می‌کند.
- اولین render و تغییر روز از یک wiring واحد استفاده می‌کنند؛ دیگر رفتار «فقط بعد از عوض کردن روز درست می‌شود» نباید وجود داشته باشد.
- این سطح از delayed geometry focus graph حذف شده است.

## 2) Box Office
- هر رتبه یک focus owner واحد دارد: 1, 2, 3, ...
- DOWN فقط به رتبه بعدی و UP فقط به رتبه قبلی می‌رود.
- UP روی رتبه 1 و DOWN روی آخرین رتبه edge قطعی هستند و اجازه پرش به header/رتبه 3 را نمی‌دهند.
- گراف عمومی روی این صفحه ساخته نمی‌شود.

## 3) Continue Watching
- کارت بیرونی خود کارت، تنها focus owner است؛ child داخلی focusable نیست.
- Rail پروفایل با LEFT/RIGHT به صورت index-based حرکت می‌کند و «مشاهده همه» end-cap واقعی است.
- صفحه کامل ادامه تماشا با UP/DOWN sequence عمودی مستقل دارد.
- گراف عمومی روی این بخش‌ها ساخته نمی‌شود.

## 4) Advanced Search
- AlertDialog یک Window جدا دارد؛ بنابراین فقط خود Dialog یک DPAD router دارد.
- per-view Activity routes و delayed generic graph برای این Dialog حذف شده‌اند.
- مسیر: نوع محتوا → selectorها (ژانر/کشور/مرتب‌سازی و...) → سال → دوبله/زیرنویس → اعمال/پاک‌کردن.
- focus اولیه روی type انتخاب‌شده می‌ماند و callback دیرهنگام آن را نمی‌دزدد.

## Source identity
- versionName: 2.3
- focusPatch: V6.8 SURFACE REBUILD ROOT
- sourceTag: BANKMOVIE-TV-2.3-V68-20260907
