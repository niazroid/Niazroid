#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
test -s "$main"
test -s "$auth"
# Side navigation RTL SVG/text gap must be on the adjacent edge.
grep -Fq 'marginStart = dp(18)' "$main"
grep -Fq 'V7.14: RTL gap belongs on the label START' "$main"
# VIP owns first UP/DOWN and has deterministic real row bootstrap.
grep -Fq 'handleV714VipDirectionalFocus(focusedOrNull, keyCode)' "$main"
grep -Fq 'bm_v714_vip_plan_' "$main"
grep -Fq 'bm_v714_vip_discount' "$main"
grep -Fq 'bm_v714_vip_purchase' "$main"
grep -Fq 'applyTvFocusToClickableTree(shell, buildDirectionalGraph = false)' "$main"
grep -Fq 'rows.firstOrNull { it.isSelected } ?: rows.first()' "$main"
grep -Fq 'row.isSelected = active' "$main"
# Auth toggle stays outside the variable field stack and retains its own focus.
grep -Fq 'bm_v714_auth_mode_switch' "$auth"
grep -Fq 'focusModeSwitchAfterRender = isTvLike()' "$auth"
grep -Fq 'switch.requestFocus()' "$auth"
switch_line=$(grep -nF 'val switch = TextView' "$auth" | head -1 | cut -d: -f1)
status_line=$(grep -nF 'statusText = TextView' "$auth" | head -1 | cut -d: -f1)
field_line=$(grep -nF 'val identity: EditText?' "$auth" | head -1 | cut -d: -f1)
[[ "$switch_line" -lt "$status_line" && "$status_line" -lt "$field_line" ]]
# Regression guards from the device-confirmed fixes.
bash verify_tv_focus_v711_category_bootstrap.sh >/dev/null
bash verify_tv_focus_v713_detail_first_press.sh >/dev/null
echo TV_FOCUS_V714_VIP_DRAWER_AUTH_OK
