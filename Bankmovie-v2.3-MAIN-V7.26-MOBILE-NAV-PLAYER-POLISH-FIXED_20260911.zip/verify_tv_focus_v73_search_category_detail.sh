#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.4 SEARCH CATEGORY DETAIL NATIVE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v74_search_category_detail_native.sh
  echo 'V7_4_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.3 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.3 SEARCH CATEGORY DETAIL ROOT'
need "$MARKER" 'verifierPatch=V7.3 SEARCH-FOCUS-BOUNCE + CATEGORY-PHYSICAL-DPAD + PALETTE-GRADIENT-CLIP + DETAIL-DOWN-ROUTER'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V73-20260908'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_3_SEARCH_CATEGORY_DETAIL_ROOT_FA.md' 'Search IME + Category Grid + Detail Root'

# Search must force a real focus transition before opening IME.
need "$MAIN" 'V7.3 SEARCH IME BOOTSTRAP'
need "$MAIN" 'content.findViewWithTag<View>("bm_v73_search_ime_sink")'
need "$MAIN" 'imm.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_FORCED)'
need "$MAIN" 'tag = "bm_v73_search_ime_sink"'
need "$MAIN" 'sink.requestFocus()'
need "$MAIN" 'focusEditorAndShow()'

# Category/genre grids must route by actual screen position.
need "$MAIN" 'private fun wireV73CategoryGrid(grid: GridLayout)'
need "$MAIN" 'grid.tag = "bm_v73_category_grid"'
need "$MAIN" 'cells.sortedBy(::centerY)'
need "$MAIN" 'rows.getOrNull(rowIndex + 1)?.minByOrNull'
count="$(grep -Fc 'if (tv) wireV73CategoryGrid(grid)' "$MAIN")"
[[ "$count" -ge 2 ]] || { echo "Expected V7.3 category router on at least 2 grids; found $count" >&2; exit 1; }

# Palette is converted to drawable colors; no scaled 2x2 bitmap is displayed.
need "$MAIN" 'V7.3: turn the poster into two real gradient colours instead'
need "$MAIN" 'backdropImage.setImageDrawable(null)'
need "$MAIN" 'backdropImage.background = GradientDrawable('
need "$MAIN" 'V7.3 page-level seam shield.'
need "$MAIN" 'LinearLayout.LayoutParams(-1, dp(12))'
if grep -Fq 'backdropImage.setImageBitmap(tiny)' "$MAIN"; then
  echo 'V7.3 guard failed: scaled tiny palette bitmap is still displayed.' >&2
  exit 1
fi

# Detail DOWN must be explicitly owned before native focus can jump to Back.
need "$MAIN" 'private fun handleV73DetailDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleV73DetailDirectionalFocus(focused, keyCode)?.let { return it }'
need "$MAIN" 'tag = "bm_v73_detail_story_more"'
need "$MAIN" 'tag = "bm_v73_detail_more_info"'
need "$MAIN" 'node.view.tag != "bm_tv_detail_back"'

# Already-fixed V7.2 surfaces must remain present.
need "$MAIN" 'private fun wireV72WatchlistGrid(grid: GridLayout)'
need "$MAIN" 'fun wireCommentMediaPickerTv()'
need "$MAIN" 'val forceArchive4PosterPalette = detailArchiveForArtwork == 4 && poster.isNotBlank()'

# Already-fixed profile/about/weekly/boxoffice/advanced-search roots must remain present.
need "$MAIN" 'private fun wireV71ProfileBootstrapSurface(page: View)'
need "$MAIN" 'private fun wireV71AboutSurface(page: View)'
need "$MAIN" 'private fun wireV70WeeklySurface()'
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'

echo 'TV_FOCUS_V73_SEARCH_CATEGORY_DETAIL_ROOT_OK'
