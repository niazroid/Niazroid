#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
RES='app/src/main/res/drawable'

bash verify_v724_search_scroll_svg_refresh.sh
bash verify_v722_cast_removed_player_retained.sh
bash verify_v723_player_last_frame_hold.sh

grep -Fq 'BANKMOVIE_V7_25_PLAYER_FRAME_BRIDGE' "$PLAYER"
grep -Fq 'PLAYER_FRAME_PROBE_INTERVAL_MS = 140L' "$PLAYER"
grep -Fq 'PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L' "$PLAYER"
grep -Fq 'private fun sampledFrameLooksRendered(bitmap: Bitmap): Boolean' "$PLAYER"
grep -Fq 'private fun startLifecycleFrameReadyProbe()' "$PLAYER"
grep -Fq 'private fun probeLifecycleVideoSurface(generation: Int)' "$PLAYER"
grep -Fq 'lifecycleFrameProbeReadySamples >= 2' "$PLAYER"
grep -Fq 'captureLifecycleVideoFrame(force = true)' "$PLAYER"
grep -Fq 'override fun onWindowFocusChanged(hasFocus: Boolean)' "$PLAYER"
# Vout/TimeChanged may trigger the probe but must not directly expose a black surface.
python3 - "$PLAYER" <<'PY_CHECK'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text()
a=s.index('MediaPlayer.Event.Vout ->')
b=s.index('MediaPlayer.Event.Paused ->', a)
block=s[a:b]
assert 'startLifecycleFrameReadyProbe()' in block
assert 'hideLifecycleFrameOverlay()' not in block
PY_CHECK

grep -Fq 'PLAYER_UTILITY_ICON_DP = 28' "$PLAYER"
[[ "$(grep -Fc 'dp(PLAYER_UTILITY_ICON_DP)' "$PLAYER")" -ge 3 ]]
grep -Fq 'LinearLayout.LayoutParams(dp(32), dp(32))' "$PLAYER"

for icon in ic_nav_grid.xml ic_menu_bars.xml ic_player_fit.xml ic_player_lock.xml ic_player_unlock.xml ic_player_pip.xml ic_player_cc.xml ic_player_settings.xml ic_player_back.xml; do
  test -s "$RES/$icon"
done

grep -Fq 'M5,10H7C9,10 10,9 10,7V5C10,3 9,2 7,2H5C3,2 2,3 2,5V7C2,9 3,10 5,10Z' "$RES/ic_nav_grid.xml"
grep -Fq 'M4,6H20V8H4ZM8,11H20V13H8ZM13,16H20V18H13Z' "$RES/ic_menu_bars.xml"
grep -Fq 'R.drawable.ic_nav_grid' "$MAIN"
grep -Fq 'R.drawable.ic_menu_bars' "$MAIN"

# Cast must remain completely removed.
! grep -Eq 'CastContext|RemoteMediaClient|MediaRoute|DlnaController|Chromecast' "$PLAYER"
! grep -Eq 'play-services-cast|androidx\.mediarouter' app/build.gradle
! grep -Eq 'OPTIONS_PROVIDER_CLASS_NAME|CHANGE_WIFI_MULTICAST_STATE' app/src/main/AndroidManifest.xml

grep -Fq 'sourceMainUpdateSixthHotfixTag=BANKMOVIE-2.3-V725-20260911' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V725_PLAYER_FRAME_BRIDGE_ICONS_OK
