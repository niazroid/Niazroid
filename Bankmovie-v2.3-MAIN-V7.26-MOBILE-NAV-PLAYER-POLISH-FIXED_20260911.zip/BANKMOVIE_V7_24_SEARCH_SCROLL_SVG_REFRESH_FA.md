# BankMovie 2.3 — V7.24 Search Scroll + SVG Refresh

- نتیجه و pagination سرچ اصلی مثل V7.21 حفظ می‌شود.
- `scrollY` همان صفحه هم داخل retained back stack ذخیره و بعد از re-attach شدن ScrollView پس از layout بازیابی می‌شود.
- در موبایل هنگام restore دیگر focus قبلی اجباری request نمی‌شود تا FocusFinder/IME موقعیت اسکرول را تغییر ندهد.
- SVGهای جدید کاربر به Android VectorDrawable تبدیل شده‌اند: دانلود، راهنما، باکس آفیس، جستجو، تنظیمات، کالکشن، خانه، فیلتر پیشرفته، کپی، درباره، تیک ادمین، پاکسازی کامل، پروفایل، علاقه‌مندی و CC.
- Cast همچنان کاملاً حذف است و Player retained/last-frame V7.22/V7.23 دست‌نخورده باقی مانده است.
