# BankMovie TV V7.1 — Profile/About first-focus + Drawer SVG preview

این پچ فقط سه حوزه را تغییر می‌دهد و رفتارهای تأییدشده‌ی Box Office، Advanced Search، Continue Watching و Weekly V7.0 را بازنویسی نمی‌کند.

- پروفایل TV تا قبل از آماده‌شدن مسیرهای DPAD با `FOCUS_BLOCK_DESCENDANTS` قفل است؛ سپس فوکوس واقعی روی `bm_tv_profile_primary` قرار می‌گیرد.
- تمام focus-ownerهای داخل هدر پروفایل یک مسیر DOWN زنده به اولین محتوای واقعی زیر هدر دارند (Continue، History، سپس Action grid).
- صفحه About/اطلاعات برنامه مسیر UP/DOWN صریح بین پنج ردیف دارد و اولین focus فقط بعد از attach/layout اعمال می‌شود.
- آیکن‌های Drawer تلویزیون برای Home/Search/BoxOffice/Downloads/Profile/Favorites از VectorDrawableهای تبدیل‌شده از SVGهای ارسالی استفاده می‌کنند.
- آیکن‌های legacy حذف یا overwrite نشده‌اند؛ فقط Drawer TV به resourceهای preview جدید اشاره می‌کند، بنابراین برگشت به ظاهر قبلی ساده است.
