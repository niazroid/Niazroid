# BankMovie TV Focus V7.6.1 — Video First-Character Root Fix

این پچ مستقیماً بر اساس ویدیوی تست دستگاه اعمال شده است.

- Search: باگ بسته‌شدن IME بعد از اولین کاراکتر رفع شد. علت این بود که مسیر query.length < 2 قبل از keepalive برمی‌گشت. اکنون همان EditText بدون restartInput در 40/180/420ms دوباره IME را نگه می‌دارد.
- Detail: دکمه Play Online هر دو جهت افقی را داخل action row نگه می‌دارد و از Play به Trailer می‌رود؛ مسیر native nextFocus و OnKey روی خود Viewها نصب شده تا Back بالا نتواند فوکوس را بگیرد.
- Categories: هاب 2x2 با نگاشت قطعی index کار می‌کند؛ DOWN از ردیف بالا دقیقاً +2 است و generic focus graph برای این صفحه غیرفعال است.
