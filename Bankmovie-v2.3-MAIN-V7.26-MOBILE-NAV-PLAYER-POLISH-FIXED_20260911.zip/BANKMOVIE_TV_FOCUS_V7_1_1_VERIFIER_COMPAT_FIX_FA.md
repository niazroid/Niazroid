# BankMovie TV Focus V7.1.1 Verifier Compatibility Fix

این پچ منطق فوکوس V7.1 را تغییر نمی‌دهد. فقط verifier قدیمی Global Focus را با ساختار جدید Profile/About سازگار می‌کند.

در V7.1 مسیر اولیه صفحه profile عمداً دو مرحله‌ای است:
- اگر صفحه About باز باشد: `bm_v71_about_row_0`
- در Profile اصلی: fallback به `bm_tv_profile_primary`

verifier قدیمی فقط شکل تک‌خطی `"profile" -> ...bm_tv_profile_primary` را قبول می‌کرد و Build را اشتباه Fail می‌کرد.
