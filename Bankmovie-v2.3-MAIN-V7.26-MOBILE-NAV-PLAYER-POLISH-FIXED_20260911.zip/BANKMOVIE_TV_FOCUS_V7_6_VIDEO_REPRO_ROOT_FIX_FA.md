# BankMovie TV Focus V7.6 — Video-Reproduced Root Fix

این پچ مستقیماً بر اساس ویدیوی تست TV مورخ 2026-09-08 ساخته شده است، نه بر اساس حدس هندسی فوکوس.

## چیزی که در ویدیو بازتولید شد
- Search: بعد از وارد شدن دو کاراکتر (`ss`) کیبورد تا لحظه تایپ باز می‌ماند؛ درست همزمان با شروع `در حال جستجو...` و mutation نتایج، IME بسته می‌شود.
- Categories: هاب اصلی چهار کارت 2x2 است و DOWN باید فقط بین کارت هم‌ستون بالا/پایین حرکت کند؛ هیچ مسیر هندسی/RTL نباید DOWN را افقی تفسیر کند.
- Detail: ردیف Hero ترتیب فیزیکی راست به چپ `پخش آنلاین -> تریلر -> واچ‌لیست` دارد و LEFT از پخش آنلاین باید مستقیم به تریلر برود؛ Back شناور گوشه بالا اصلاً عضو این ردیف نیست.

## Search — رفع ریشه بسته شدن IME
- `restartInput()` از keepalive کاراکترها حذف شد. این فراخوانی روی بعضی TV IMEها input connection را هنگام commit ریست می‌کند.
- live search حفظ شده، اما generation مربوط به تایپ TV علامت‌گذاری می‌شود.
- بعد از mutation حالت Loading و بعد از اضافه شدن Results، همان EditText بدون focus bounce و بدون `restartInput()` دوباره با `showSoftInput()` تثبیت می‌شود.
- DPAD_CENTER نشت‌کرده از کیبورد دیگر باعث `restartInput()` فوری نمی‌شود.

## Detail — native + view-level hard route
- سه کنترل واقعی Hero tag مستقل دارند: `bm_tv_detail_primary`, `bm_tv_detail_trailer`, `bm_tv_detail_favorite`.
- روی خود Viewها `nextFocusLeftId/nextFocusRightId` نوشته می‌شود.
- علاوه بر Activity router، `OnKeyListener` مستقیم روی همان سه کنترل نصب می‌شود.
- ترتیب دیگر از screen coordinate/RTL inference محاسبه نمی‌شود: از `پخش آنلاین` هر دو کلید افقی LEFT/RIGHT ابتدا وارد `تریلر` می‌شوند؛ بنابراین تفاوت علامت/جهت ریموت هم نمی‌تواند فوکوس را به Back ببرد.
- لبه ردیف روی خودش قفل می‌شود تا Android `focusSearch()` نتواند به `bm_tv_detail_back` بپرد.

## Categories — مسیر دقیق 2x2، بدون graph عمومی
- هاب چهارکارت tag مستقل `bm_v76_category_hub_grid` دارد.
- Child index دقیق صفحه مبناست: 0 Genres، 1 Collections، 2 Top Movies، 3 Top Series.
- DOWN: `0->2` و `1->3`، UP برعکس؛ LEFT/RIGHT فقط در همان ردیف.
- `nextFocus*Id` و `OnKeyListener` مستقیم روی هر چهار کارت نصب می‌شود.
- generic delayed focus graph برای همین هاب خاموش است تا مسیر اول DPAD را بازنویسی نکند.

Marker: `TV_FOCUS_V76_VIDEO_REPRO_ROOT_OK`
