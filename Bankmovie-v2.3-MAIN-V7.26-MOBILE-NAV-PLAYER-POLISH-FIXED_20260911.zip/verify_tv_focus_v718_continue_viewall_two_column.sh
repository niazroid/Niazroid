#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$main"

# Keep the V7.17 catalogue bootstrap chain intact.
bash verify_tv_focus_v717_collection_catalogue_bootstrap.sh >/dev/null

python3 - "$main" <<'PY'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text()

def fn(name: str) -> str:
    marker = f"private fun {name}"
    start = s.find(marker)
    if start < 0:
        raise SystemExit(f"missing function: {name}")
    nxt = s.find("\n    private fun ", start + len(marker))
    return s[start:nxt if nxt >= 0 else len(s)]

show = fn('showLocalList')
needles = [
    'V7.18: the TV "View all / Continue Watching" page is a real',
    'val columns = 2',
    'columnCount = columns',
    'tag = "bm_tv_continue_full_list"',
    'continueCardWidth = cardWidth',
    'rowSpec = GridLayout.spec(index / columns)',
    'columnSpec = GridLayout.spec(index % columns)',
    'wireV68ContinueFullList(grid)',
]
for needle in needles:
    if needle not in show:
        raise SystemExit(f'showLocalList: missing {needle!r}')

card = fn('profileStoredCard')
for needle in ('continueCardWidth: Int? = null', 'val cardWidth = continueCardWidth ?:'):
    if needle not in card:
        raise SystemExit(f'profileStoredCard: missing {needle!r}')

wire = fn('wireV68ContinueFullList')
for needle in (
    'list is GridLayout && list.columnCount == 2',
    'cards.getOrNull(index - 2)',
    'cards.getOrNull(index + 2)',
    'index % 2 == 0',
):
    if needle not in wire:
        raise SystemExit(f'wireV68ContinueFullList: missing {needle!r}')

# Dispatch routing must match the same two-column physical model.
if 'two-column Continue Watching full list' not in s:
    raise SystemExit('missing V7.18 two-column dispatch router')
if 'val twoColumn = owner is GridLayout && owner.columnCount == 2' not in s:
    raise SystemExit('missing twoColumn dispatch detection')

# Search and the already-stable View All catalogue must not be touched by V7.18.
for name in ('doSearch', 'showAdvancedSearchResults', 'showList'):
    if 'V7.18:' in fn(name):
        raise SystemExit(f'{name}: V7.18 must not alter this working surface')
PY

grep -Fq 'focusPatchEleventhFollowup=V7.18 CONTINUE-WATCHING VIEW-ALL TWO-COLUMN TV GRID' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceBuildEleventhFollowupTag=BANKMOVIE-TV-2.3-V718-20260910' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo TV_FOCUS_V718_CONTINUE_VIEWALL_TWO_COLUMN_OK
