#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
grep -Fq 'focusPatchFollowup=V7.8 TV ACTION-ROW + CATEGORY GRID + SEARCH IME STABILITY' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.8 TV ACTION-ROW + CATEGORY GRID + SEARCH IME STABILITY' BANKMOVIE_TV_FOCUS_V7_8_REBUILD_FIX_FA.md
grep -Fq 'the recording proves the TV keyboard closes' "$MAIN"
grep -Fq 'clearBtn.alpha = if (value.isBlank()) 0f else 1f' "$MAIN"
grep -Fq 'clearBtn.isEnabled = value.isNotBlank()' "$MAIN"
grep -Fq 'source.nextFocusLeftId = safeLeft.id' "$MAIN"
grep -Fq 'source.nextFocusRightId = safeRight.id' "$MAIN"
grep -Fq 'View.FOCUS_DOWN -> if (index < 2) index + 2 else index' "$MAIN"
if grep -Fq 'imm.restartInput(input)' "$MAIN"; then
  echo 'Unexpected restartInput in TV focus path' >&2
  exit 1
fi
python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
w = s.index('input.addTextChangedListener(object : TextWatcher')
e = s.index('override fun beforeTextChanged', w)
block = s[w:e]
assert block.index('if (tv)') < block.index('pendingSearch = Runnable { restartSearch(value, preserveTvIme = false) }')
c = s.index('val grid = object : GridLayout(this) {', s.index('private fun showCategories()'))
e = s.index('val cards=listOf(', c)
assert 'View.FOCUS_DOWN -> if (index < 2) index + 2 else index' in s[c:e]
d = s.index('private fun wireV76DetailActionRow')
e = s.index('private fun handleV74DetailDirectionalFocus', d)
assert 'both horizontal arrows from Play intentionally' in s[d:e]
print('TV_FOCUS_V78_REBUILD_OK')
PY