#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
[[ -s "$MAIN" ]]

grep -Fq 'focusPatchFourthFollowup=V7.11 CATEGORY SINGLE-OWNER BOOTSTRAP FOCUS' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.11 Categories hub focus: single-owner deterministic TV graph.' "$MAIN"
grep -Fq 'handleV711CategoryHubDirectionalFocus' "$MAIN"
grep -Fq 'wireV711CategoryHubFocus(cards, grid, page, scroll)' "$MAIN"
grep -Fq 'bm_v711_category_hub_grid' "$MAIN"
grep -Fq 'grid.postOnAnimation' "$MAIN"
grep -Fq 'sourceTag = "bm_v711_category_collections"' "$MAIN"
# Search fix from V7.10 must remain intact.
grep -Fq 'V7.10 LIVE TV SEARCH: submit automatically after a short' "$MAIN"
grep -Fq 'pendingSearch = Runnable { restartSearch(value) }' "$MAIN"
grep -Fq 'debounce.postDelayed(pendingSearch!!, 260L)' "$MAIN"
# Detail trailer fix must remain intact.
grep -Fq 'primary -> trailer ?: favorite ?: primary' "$MAIN"

python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

# V7.11 hub is the only owner for this exact four-card surface.
assert 'categoryHubV710Target' not in s
assert 'wireV710CategoryHubFocus' not in s
assert 'handleV710CategoryHubDirectionalFocus' not in s
assert 'bm_v710_category_' not in s

start = s.index('    private val categoryHubV711Tags')
end = s.index('    /** V7.4 live Categories router', start)
router = s[start:end]
for needle in (
    '"bm_v711_category_genres"',
    '"bm_v711_category_collections"',
    '"bm_v711_category_top_movies"',
    '"bm_v711_category_top_series"',
    'KEYCODE_DPAD_RIGHT -> "bm_v711_category_collections"',
    'KEYCODE_DPAD_DOWN -> "bm_v711_category_top_movies"',
    'KEYCODE_DPAD_LEFT -> "bm_v711_category_genres"',
    'KEYCODE_DPAD_DOWN -> "bm_v711_category_top_series"',
    'KEYCODE_DPAD_RIGHT -> "bm_v711_category_top_series"',
    'KEYCODE_DPAD_UP -> "bm_v711_category_genres"',
    'KEYCODE_DPAD_LEFT -> "bm_v711_category_top_movies"',
    'KEYCODE_DPAD_UP -> "bm_v711_category_collections"',
    'wrapper.isFocusable = false',
    'wrapper.isFocusableInTouchMode = false',
    'grid.postOnAnimation',
    'requestTvFocusVerified(entry)',
    'if (!isDescendantOf(focused, content)) return null',
    'sourceTag = "bm_v711_category_collections"',
):
    assert needle in router, needle

show = s.index('    private fun showCategories()')
show_end = s.index('    private fun showGenreDirectory(', show)
hub = s[show:show_end]
assert 'tag = "bm_v711_category_hub_grid"' in hub
assert 'wireV711CategoryHubFocus(cards, grid, page, scroll)' in hub
assert 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)' in hub

# General initial/content-entry focus must point to the new semantic card.
assert s.count('"categories" -> content.findViewWithTag<View>("bm_v711_category_collections")') >= 2

# The V7.11 handler must run before legacy V7.4 category routing.
h = s.index('    private fun handleTvDirectionalFocus')
he = s.index('        // V7.4 remains the compatibility router', h)
pre = s[h:he]
assert pre.index('handleV711CategoryHubDirectionalFocus') < len(pre)

print('TV_FOCUS_V711_CATEGORY_BOOTSTRAP_OK')
PY
