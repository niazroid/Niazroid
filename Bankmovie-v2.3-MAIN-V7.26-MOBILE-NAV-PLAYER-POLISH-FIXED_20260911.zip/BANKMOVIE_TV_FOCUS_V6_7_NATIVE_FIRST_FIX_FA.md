# BankMovie TV Focus V6.7 Native-First Root Fix

این پچ چهار مشکل باقی‌مانده را با حذف تداخل بین router سراسری، OnKeyListener و focusSearch اندروید حل می‌کند:

- Weekly: DOWN فقط وقتی مصرف می‌شود که فوکوس واقعاً به پوستر منتقل شده باشد؛ در غیر این صورت nextFocus بومی اندروید اجرا می‌شود.
- Home: مسیر نامشخص دیگر DPAD را کورکورانه consume نمی‌کند.
- Continue Watching: wrapper واقعی کارت تنها focus owner است؛ inner card دیگر focusable نیست.
- Box Office: مسیر live بر اساس tag ردیف‌ها قبل از هندسه عمومی اجرا می‌شود.
- Advanced Search: Dialog مسیر DPAD مستقل در Window خودش دارد و generic geometry routing برای آن غیرفعال است.

Build marker: V6.7 NATIVE-FIRST ROOT
