#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
[[ -s "$MAIN" ]]

# Previous proven fixes must stay intact.
bash verify_tv_focus_v711_category_bootstrap.sh >/dev/null

grep -Fq 'focusPatchFifthFollowup=V7.12 DETAIL SINGLE-OWNER BOOTSTRAP FOCUS' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceBuildFifthFollowupTag=BANKMOVIE-TV-2.3-V712-20260909' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'V7.12 Detail hero focus: single-owner bootstrap and deterministic action row.' "$MAIN"
grep -Fq 'private var tvDetailActionBootstrapPending = false' "$MAIN"
grep -Fq 'handleV712DetailActionDirectionalFocus(focusedOrNull, keyCode)' "$MAIN"
grep -Fq 'wireV712DetailActionFocus(actions, primaryAction, trailerAction, favoriteAction, page)' "$MAIN"
grep -Fq 'tag = "bm_v712_detail_actions"' "$MAIN"
grep -Fq 'actions.postOnAnimation' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_DPAD_DOWN -> detailV712BelowActionTarget() ?: primary' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_DPAD_LEFT,' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> trailer ?: favorite' "$MAIN"

python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

# Search and Categories fixes remain intact.
assert 'V7.10 LIVE TV SEARCH: submit automatically after a short' in s
assert 'pendingSearch = Runnable { restartSearch(value) }' in s
assert 'handleV711CategoryHubDirectionalFocus' in s
assert 'bm_v711_category_hub_grid' in s

# V7.12 must be the first Detail owner, even before null currentFocus is rejected.
h = s.index('    private fun handleTvDirectionalFocus')
h_end = s.index('        // V7.11 Categories hub has a single owner.', h)
head = s[h:h_end]
assert head.index('handleV712DetailActionDirectionalFocus(focusedOrNull, keyCode)') < head.index('val focused = focusedOrNull ?: return false')

# The rendered Detail action row is no longer an anonymous focusSearch owner and
# no longer installs the old V7.6 per-view key router.
r = s.index('    private fun renderDetailTv(')
r_end = s.index('    private fun persianDigits(', r)
detail = s[r:r_end]
assert 'tag = "bm_v712_detail_actions"' in detail
assert 'wireV712DetailActionFocus(actions, primaryAction, trailerAction, favoriteAction, page)' in detail
assert 'wireV76DetailActionRow(actions, primaryAction, trailerAction, favoriteAction)' not in detail
assert 'override fun focusSearch(focused: View?, direction: Int)' not in detail

# Bootstrap wrappers cannot become focus owners; Play owns first-frame entry.
w = s.index('    private fun wireV712DetailActionFocus(')
w_end = s.index('    /**\n     * Single Activity-level owner for the V7.12 Detail action row.', w)
wire = s[w:w_end]
for needle in (
    'wrapper.isFocusable = false',
    'wrapper.isFocusableInTouchMode = false',
    'wrapper.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS',
    'actions.postOnAnimation',
    'requestTvFocusVerified(primary)',
    'primary.nextFocusLeftId = trailerOrFavorite.id',
    'primary.nextFocusRightId = trailerOrFavorite.id',
    'primary.nextFocusDownId = primary.id',
):
    assert needle in wire, needle

router_start = s.index('    private fun handleV712DetailActionDirectionalFocus(')
router_end = s.index('    /**\n     * V7.6 direct Detail action-row wiring', router_start)
router = s[router_start:router_end]
for needle in (
    'if (!tvDetailActionBootstrapPending) return null',
    'source = primary',
    'requestTvFocusVerified(primary)',
    'KEYCODE_DPAD_RIGHT -> trailer ?: favorite',
    'KEYCODE_DPAD_DOWN -> detailV712BelowActionTarget() ?: primary',
    'tvDetailActionBootstrapPending = false',
):
    assert needle in router, needle

# Critical regression guard: Play's first horizontal move may mention favorite
# only as the no-trailer fallback; there is no direct Play -> Watchlist route.
play = router[router.index('primary -> when (keyCode)'):router.index('trailer -> when (keyCode)')]
assert 'trailer ?: favorite' in play
assert 'KEYCODE_DPAD_DOWN -> detailV712BelowActionTarget() ?: primary' in play

print('TV_FOCUS_V712_DETAIL_BOOTSTRAP_OK')
PY
