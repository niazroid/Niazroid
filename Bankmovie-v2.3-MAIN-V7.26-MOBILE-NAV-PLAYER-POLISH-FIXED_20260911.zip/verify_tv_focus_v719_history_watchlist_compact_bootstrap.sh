#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$main"

# Preserve the already-fixed Continue Watching two-column surface and all older catalogue bootstrap fixes.
bash verify_tv_focus_v718_continue_viewall_two_column.sh >/dev/null

python3 - "$main" <<'PY'
from pathlib import Path
import sys
s = Path(sys.argv[1]).read_text()

def fn(name: str) -> str:
    marker = f"private fun {name}"
    start = s.find(marker)
    if start < 0:
        raise SystemExit(f"missing function: {name}")
    nxt = s.find("\n    private fun ", start + len(marker))
    return s[start:nxt if nxt >= 0 else len(s)]

show = fn('showLocalList')
for needle in (
    'V7.19: History View-All and Watchlist are poster catalogues on TV',
    'val columns = if (tvList) tvGridColumns()',
    '"favorites" -> tag = "bm_tv_watchlist_grid"',
    '"history" -> tag = "bm_tv_history_grid"',
    '(cellWidth - dp(12)).coerceAtMost(tvGridCardWidth())',
    'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)',
    'wireV72WatchlistGrid(grid)',
    'armV716CatalogueGridBootstrap(grid)',
):
    if needle not in show:
        raise SystemExit(f'showLocalList: missing {needle!r}')

# The Continue Watching branch remains two columns and must not be folded into this compact-poster change.
for needle in (
    'if (storeKey == "continue")',
    'val columns = 2',
    'wireV68ContinueFullList(grid)',
):
    if needle not in show:
        raise SystemExit(f'Continue branch regression: missing {needle!r}')

# First-frame physical bootstrap and physical-row router must still exist.
for name, needles in {
    'armV716CatalogueGridBootstrap': (
        'val topY = located.minOf',
        'maxByOrNull { (_, c) -> c.first }',
        'tvV716CatalogueBootstrapPending = true',
    ),
    'wireV72WatchlistGrid': (
        'view.getLocationOnScreen(loc)',
        'val physicalRow = rowCells(raw)',
        'sortedBy { centerX(it.second) }',
    ),
}.items():
    block = fn(name)
    for needle in needles:
        if needle not in block:
            raise SystemExit(f'{name}: missing {needle!r}')

# V7.19 must not alter the proven search or regular View-All catalogue implementations.
for name in ('doSearch', 'showAdvancedSearchResults', 'showList'):
    if 'V7.19:' in fn(name):
        raise SystemExit(f'{name}: V7.19 must not alter this working surface')
PY

grep -Fq 'focusPatchTwelfthFollowup=V7.19 HISTORY+WATCHLIST COMPACT TV GRID + FIRST-PRESS BOOTSTRAP' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceBuildTwelfthFollowupTag=BANKMOVIE-TV-2.3-V719-20260910' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'History / Watchlist Compact Grid + Bootstrap' BANKMOVIE_TV_FOCUS_V7_19_HISTORY_WATCHLIST_COMPACT_BOOTSTRAP_FA.md

echo TV_FOCUS_V719_HISTORY_WATCHLIST_COMPACT_BOOTSTRAP_OK
