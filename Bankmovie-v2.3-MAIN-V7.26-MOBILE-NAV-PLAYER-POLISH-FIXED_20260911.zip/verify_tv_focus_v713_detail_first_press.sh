#!/usr/bin/env bash
set -euo pipefail

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
[[ -s "$MAIN" ]]

# Keep all previous proven fixes intact.
bash verify_tv_focus_v712_detail_bootstrap.sh >/dev/null

grep -Fq 'focusPatchSixthFollowup=V7.13 DETAIL FIRST-PRESS SINGLE-STEP GUARD' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceBuildSixthFollowupTag=BANKMOVIE-TV-2.3-V713-20260909' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'tvDetailConsumedDirectionalKeyCode' "$MAIN"
grep -Fq 'V7.13 DETAIL FIRST-PRESS GUARD' "$MAIN"
grep -Fq 'source.setOnKeyListener' "$MAIN"
grep -Fq 'event.action == android.view.KeyEvent.ACTION_UP' "$MAIN"
grep -Fq 'event.repeatCount > 0' "$MAIN"

python3 - <<'PY'
from pathlib import Path
s = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')

# Search + Categories + V7.12 Detail bootstrap stay present.
for needle in (
    'V7.10 LIVE TV SEARCH: submit automatically after a short',
    'handleV711CategoryHubDirectionalFocus',
    'handleV712DetailActionDirectionalFocus(focusedOrNull, keyCode)',
    'wireV712DetailActionFocus(actions, primaryAction, trailerAction, favoriteAction, page)',
):
    assert needle in s, needle

# Dispatch must swallow the tail of a semantic Detail press before native focus.
d = s.index('    override fun dispatchKeyEvent')
d_end = s.index('    private fun showSplashOnly()', d)
dispatch = s[d:d_end]
for needle in (
    'V7.13 DETAIL FIRST-PRESS GUARD',
    'event.action == android.view.KeyEvent.ACTION_UP && age in 0L..650L',
    'event.action == android.view.KeyEvent.ACTION_DOWN && event.repeatCount > 0 && age in 0L..180L',
    'tvDetailConsumedDirectionalKeyCode = android.view.KeyEvent.KEYCODE_UNKNOWN',
):
    assert needle in dispatch, needle
assert dispatch.index('V7.13 DETAIL FIRST-PRESS GUARD') < dispatch.index('if (event.action == android.view.KeyEvent.ACTION_DOWN && ::bottomNav.isInitialized)')

# The real Play/Trailer/Favorite views own a fallback key listener, including UP.
w = s.index('    private fun wireV712DetailActionFocus(')
w_end = s.index('    /**\n     * Single Activity-level owner for the V7.12 Detail action row.', w)
wire = s[w:w_end]
for needle in (
    'fun bindDirectDetailKey(source: View)',
    'source.setOnKeyListener',
    'if (event.action == android.view.KeyEvent.ACTION_UP)',
    'row.forEach(::bindDirectDetailKey)',
    'android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> trailer ?: favorite',
    'android.view.KeyEvent.KEYCODE_DPAD_DOWN -> detailV712BelowActionTarget() ?: primary',
):
    assert needle in wire, needle

# Activity semantic move must latch the physical press before requestFocus.
r = s.index('    private fun handleV712DetailActionDirectionalFocus(')
r_end = s.index('    /**\n     * V7.6 direct Detail action-row wiring', r)
router = s[r:r_end]
assert router.index('tvDetailConsumedDirectionalKeyCode = keyCode') < router.index('requestTvFocusVerified(target)')

# Critical regression: Play has no direct path to Favorite when Trailer exists.
play = router[router.index('primary -> when (keyCode)'):router.index('trailer -> when (keyCode)')]
assert 'KEYCODE_DPAD_RIGHT -> trailer ?: favorite' in play
assert 'KEYCODE_DPAD_DOWN -> detailV712BelowActionTarget() ?: primary' in play

print('TV_FOCUS_V713_DETAIL_FIRST_PRESS_OK')
PY
