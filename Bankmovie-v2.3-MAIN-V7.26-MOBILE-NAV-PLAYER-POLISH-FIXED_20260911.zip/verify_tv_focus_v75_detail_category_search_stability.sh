#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.5 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.5 DETAIL CATEGORY SEARCH STABILITY'
need "$MARKER" 'verifierPatch=V7.5 DETAIL-REAL-ACTIONS + CATEGORY-OWNED-RETRY + SEARCH-IME-SESSION'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V75-20260908'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_5_DETAIL_CATEGORY_SEARCH_STABILITY_FA.md' 'Detail / Categories / Search Stability'

# Detail: the tag must live on the real hero action row, not Advanced Search.
need "$MAIN" 'tag = "bm_advanced_filter_actions"'
need "$MAIN" 'detailActionButton("پخش آنلاین", R.drawable.ic_play_fill, true)'
need "$MAIN" 'tag = "bm_v74_detail_actions"'
need "$MAIN" 'private fun handleV74DetailDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'This direction belongs to the Detail hero.'
need "$MAIN" 'return if (target != null) moveOwned(target) else true'

# Categories: synchronous root lookup + owned retry prevents native sideways escape.
need "$MAIN" 'content.findViewWithTag<View>("bm_v73_category_grid") as? GridLayout'
need "$MAIN" 'if (tv) tag = "bm_v73_category_grid"'
need "$MAIN" 'First DPAD can arrive while GridLayout is still finishing its focus'
need "$MAIN" 'rows.getOrNull(rowIndex + 1)?.minByOrNull { kotlin.math.abs(it.x - current.x) }'
need "$MAIN" 'else firstVisibleLoadMore(content)?.let(::moveOwned) ?: true'

# Search: visible/session guard + keepalive without focus bounce.
need "$MAIN" 'import androidx.core.view.WindowInsetsCompat'
need "$MAIN" 'private var tvSearchImeSessionPrimed = false'
need "$MAIN" 'private fun isTvSearchImeVisible(input: EditText): Boolean'
need "$MAIN" 'private fun keepTvSearchImeOpen(input: EditText, delayMs: Long = 80L)'
need "$MAIN" 'tvSearchImeBridgeActiveUntil = android.os.SystemClock.uptimeMillis() + 220L'
need "$MAIN" 'event.action == android.view.KeyEvent.ACTION_UP'
need "$MAIN" 'isTvSearchImeVisible(activeSearchEditor) || tvSearchImeSessionPrimed'
need "$MAIN" 'if (tv && input.hasFocus()) keepTvSearchImeOpen(input, 90L)'
need "$MAIN" 'tvSearchImeSessionPrimed = false'

# Previously confirmed routes stay present.
need "$MAIN" 'private fun wireV72WatchlistGrid(grid: GridLayout)'
need "$MAIN" 'private fun wireV71ProfileBootstrapSurface(page: View)'
need "$MAIN" 'private fun wireV70WeeklySurface()'
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'

echo 'TV_FOCUS_V75_DETAIL_CATEGORY_SEARCH_STABILITY_OK'
