# BankMovie 2.3 — TV V7.2

## Search + Watchlist RTL + Archive4 Palette + Detail Seam + Comment/Reply Sticker TV

این پچ فقط روی پنج سطح زیر اعمال شده و مسیرهای پایدار V7.1.1 را تغییر نمی‌دهد:

1. Search TV: فشردن OK روی EditText جستجو، حتی وقتی از قبل فوکوس دارد، مستقیماً IME را باز می‌کند.
2. Watchlist/Favorites TV: چپ/راست از موقعیت فیزیکی کارت‌ها بعد از layout محاسبه می‌شود تا RTL دستگاه/firmware ترتیب را برعکس نکند.
3. Archive 4 Detail: اگر بک‌گراند واقعی مناسب وجود نداشته باشد، wash رنگی از خود پوستر ساخته می‌شود و پوستر کم‌کیفیت کش نمی‌آید.
4. Archive 2/3/4 Detail Hero: wash قبل از خروج از Hero داخل خود قاب به مشکی fade می‌شود و strip بیرون‌زده رنگی حذف می‌شود.
5. Comment/Reply media picker: تب‌ها و استیکر/GIFها روی TV مسیر فیزیکی LEFT/RIGHT و ردیفی UP/DOWN مستقل دارند.

Version name همچنان 2.3 است.
