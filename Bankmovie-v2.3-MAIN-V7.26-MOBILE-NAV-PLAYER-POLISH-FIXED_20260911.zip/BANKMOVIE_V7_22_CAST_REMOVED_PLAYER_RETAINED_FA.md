# BankMovie 2.3 V7.22 — حذف Cast + Retained Player Session

این نسخه روی V7.21.1 ساخته شده اما کل مسیر Cast/Chromecast/MediaRouter/UPnP-DLNA حذف شده و PlayerActivity به مسیر پایدار LibVLC قبل از Cast برگشته است.

## تغییرات

- حذف کامل dependencyهای Google Cast، AndroidX MediaRouter/AppCompat/Fragment که فقط برای Cast اضافه شده بودند.
- حذف OptionsProvider، DLNA discovery/controller/provider، metadata مربوط به Cast و مجوزهای Wi-Fi multicast که فقط برای DLNA لازم بودند.
- حذف دکمه Cast و تمام branchهای RemoteKind از PlayerActivity.
- حفظ Retained Back Stack سراسری V7.21 در MainActivity؛ برگشت از Detail به صفحات لیستی تا حد ممکن همان View واقعی، scroll، pagination و focus را برمی‌گرداند.
- PlayerActivity اکنون برای خروج موقت از برنامه، خود LibVLC/MediaPlayer را تا 3 دقیقه نگه می‌دارد. در onStop فقط Surface detach می‌شود و در onResume همان MediaPlayer به VLCVideoLayout تازه attach می‌شود؛ بنابراین URL/decoder/track state از صفر ساخته نمی‌شود.
- اگر re-attach ممکن نباشد، Surface/Process از بین رفته باشد، یا بازگشت بیش از 3 دقیقه طول بکشد، fallback پایدار قبلی Player را از position ذخیره‌شده rebuild می‌کند.
- onSaveInstanceState انتخاب track، position، play/pause، speed و aspect mode را نگه می‌دارد تا recreation سیستم هم کمتر به شروع از صفر منجر شود.
- savePlaybackProgress دیگر وقتی native player در پس‌زمینه آزاد شده، position معتبر را با صفر overwrite نمی‌کند.

## Trade-off

نگه داشتن LibVLC/MediaPlayer برای 3 دقیقه RAM/native decoder بیشتری نسبت به release فوری مصرف می‌کند. این retention محدود است تا ریسک فشار حافظه پایین بماند. Android همچنان می‌تواند process را هر زمان که نیاز به RAM داشته باشد kill کند؛ در آن حالت بازسازی از position ذخیره‌شده رفتار صحیح و اجتناب‌ناپذیر است.
