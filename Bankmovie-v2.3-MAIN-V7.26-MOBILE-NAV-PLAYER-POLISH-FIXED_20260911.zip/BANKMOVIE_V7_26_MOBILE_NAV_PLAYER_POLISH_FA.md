# BankMovie V7.26 — Mobile Navigation Personalization + Player Utility Icon Polish

- ظاهر فعلی نوار پایین موبایل با کلید `classic` بدون تغییر، پیش‌فرض باقی مانده است.
- ۱۰ مدل اختیاری فقط برای موبایل اضافه شده: Minimal Clean، Glassmorphism، Floating Detached، Neumorphism، Pill Highlight، Center FAB، Gradient Bold، Outline Icons، Tab Indicator و Curved Background.
- انتخاب مدل از Settings > شخصی‌سازی منوی موبایل انجام می‌شود و هر مدل پیش‌نمایش داخلی دارد.
- Android TV این preference را نمی‌خواند و `buildTvSideNavigation()` بدون تغییر باقی مانده است؛ بنابراین DPAD/side rail تحت تأثیر نیست.
- Player: فقط glyph کنترل‌های فرعی از 28dp به 24dp کوچک شده‌اند. Play و دکمه‌های ۱۰ ثانیه عقب/جلو عمداً بدون تغییر باقی مانده‌اند.
- V7.25 frame bridge و V7.24 search scroll restore حفظ شده‌اند.
