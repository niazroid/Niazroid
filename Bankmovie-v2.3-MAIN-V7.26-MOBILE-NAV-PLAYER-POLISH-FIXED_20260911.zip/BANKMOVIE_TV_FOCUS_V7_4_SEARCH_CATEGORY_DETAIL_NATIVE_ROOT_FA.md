# BankMovie TV Focus V7.4 — Search / Category / Detail Native Root

این نسخه فقط سه باگ باقی‌مانده‌ی TV را روی پایه‌ی V7.3 اصلاح می‌کند و منطق‌های تأییدشده‌ی Weekly، Continue Watching، Box Office، Advanced Search، Profile/About، Watchlist و Sticker را دست نمی‌زند.

## Search
- فوکوس اولیه‌ی Search در بعضی TVها هاله داشت ولی IME سرد باقی می‌ماند.
- sink نامرئی برای این firmwareها کافی نبود.
- V7.4 روی OK یک focus bridge واقعی و قابل‌دیدن (دکمه Back خود Search) را برای چند ده میلی‌ثانیه استفاده می‌کند، بدون اجرای click آن.
- سپس فوکوس با `requestFocusFromTouch()` به EditText برمی‌گردد و یک tap مصنوعی روی خود EditText dispatch می‌شود تا مسیر داخلی TextView/IME فعال شود.
- ACTION_UP همان OK در بازه‌ی bridge مصرف می‌شود تا Back ناخواسته اجرا نشود.

## Categories
- wiring بعد از `post{}` برای اولین DPAD دیر بود و native focusSearch می‌توانست DOWN را افقی تفسیر کند.
- V7.4 یک router زنده‌ی synchronous دارد که هر بار مختصات واقعی کارت‌ها را می‌خواند و DOWN/UP را به نزدیک‌ترین کارت در ردیف بعد/قبل می‌فرستد.
- LEFT/RIGHT نیز بر اساس X واقعی صفحه‌اند، نه child index یا RTL bookkeeping.

## Detail
- Action row در Hero حالا tag مستقل دارد و LEFT/RIGHT کاملاً توسط V7.4 مدیریت می‌شود.
- در لبه‌ی action row، کلید consume می‌شود تا native focusSearch نتواند به دکمه Back گوشه‌ی Hero بپرد.
- DOWN از Hero همچنان مستقیم به Story More / More Info / اولین کنترل پایین می‌رود.
