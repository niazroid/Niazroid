#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.6 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.6 VIDEO REPRO DETAIL CATEGORY SEARCH ROOT'
need "$MARKER" 'verifierPatch=V7.6 DETAIL-NATIVE-VIEW + CATEGORY-2X2-HARD + SEARCH-IME-MUTATION'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V76-20260908'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_6_VIDEO_REPRO_ROOT_FIX_FA.md' 'Video-Reproduced Root Fix'

# Search: no per-character restartInput; preserve IME across loading/results mutation.
need "$MAIN" 'V7.6 VIDEO REPRO: show the existing input connection again'
need "$MAIN" 'var tvImePreserveGeneration = -1'
need "$MAIN" 'fun restartSearch(raw: String, preserveTvIme: Boolean = false)'
need "$MAIN" 'tvImePreserveGeneration = if (tv && preserveTvIme) generation else -1'
need "$MAIN" 'restartSearch(value, preserveTvIme = tv && input.hasFocus())'
need "$MAIN" 'keepTvSearchImeOpen(input, 420L)'
need "$MAIN" 'keepTvSearchImeOpen(input, 820L)'
need "$MAIN" 'query>=2 switches the page into loading/results mode.'
# The V7.6 keepalive body must not restart the connection.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
start=s.index('private fun keepTvSearchImeOpen')
end=s.index('private fun requestTvSoftKeyboard', start)
body=s[start:end]
assert 'restartInput(input)' not in body, 'V7.6 keepTvSearchImeOpen still restarts the TV input connection'
PY

# Detail: semantic order + native ids + view OnKey fallback.
need "$MAIN" 'private fun wireV76DetailActionRow('
need "$MAIN" 'actions.tag = "bm_v76_detail_actions"'
need "$MAIN" 'val physicalRightToLeft = listOfNotNull(primary, trailer, favorite)'
need "$MAIN" 'source.nextFocusLeftId = left?.id ?: source.id'
need "$MAIN" 'source.setOnKeyListener { _, keyCode, event ->'
need "$MAIN" 'tag = "bm_tv_detail_trailer"'
need "$MAIN" 'tag = "bm_tv_detail_favorite"'
need "$MAIN" 'wireV76DetailActionRow(actions, primaryAction, trailerAction, favoriteAction)'
need "$MAIN" 'content.findViewWithTag<View>("bm_tv_detail_trailer")'

# Categories: exact four-card hub, direct +/-2 vertical mapping, generic graph disabled.
need "$MAIN" 'private fun wireV76CategoryHubGrid(grid: GridLayout)'
need "$MAIN" 'grid.tag = "bm_v76_category_hub_grid"'
need "$MAIN" 'android.view.KeyEvent.KEYCODE_DPAD_DOWN -> if (index < 2) cells[index + 2] else null'
need "$MAIN" 'source.nextFocusDownId = down?.id ?: source.id'
need "$MAIN" 'private fun handleV76CategoryHubDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleV76CategoryHubDirectionalFocus(focused, keyCode)?.let { return it }'
need "$MAIN" 'if (tv) wireV76CategoryHubGrid(grid)'
need "$MAIN" 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)'

# Previously confirmed roots stay present.
need "$MAIN" 'private fun wireV72WatchlistGrid(grid: GridLayout)'
need "$MAIN" 'private fun wireV71ProfileBootstrapSurface(page: View)'
need "$MAIN" 'private fun wireV70WeeklySurface()'
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'
need "$MAIN" 'V7.4 SEARCH REAL-FOCUS BRIDGE'
need "$MAIN" 'private fun handleV74DetailDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'private fun handleV74CategoryDirectionalFocus(focused: View, keyCode: Int): Boolean?'

echo 'TV_FOCUS_V76_VIDEO_REPRO_ROOT_OK'
