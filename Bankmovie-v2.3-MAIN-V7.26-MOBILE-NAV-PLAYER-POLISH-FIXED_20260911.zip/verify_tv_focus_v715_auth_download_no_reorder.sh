#!/usr/bin/env bash
set -euo pipefail

auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
downloads='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'

test -s "$auth"
test -s "$downloads"

# V7.15 root cause: focus decoration must never mutate LinearLayout child order.
! grep -Fq '.bringToFront()' "$auth"
! grep -Fq '.bringToFront()' "$downloads"
grep -Fq 'V7.15: NEVER call bringToFront()' "$auth"
grep -Fq 'V7.15: focus glow must be visual-only.' "$downloads"

# Auth action order is permanent: Submit first, then Login/Register switch.
submit_add_line=$(grep -nF 'card.addView(submit, LinearLayout.LayoutParams(-1, dp(58))' "$auth" | head -1 | cut -d: -f1)
switch_add_line=$(grep -nF 'card.addView(switch, LinearLayout.LayoutParams(-1, dp(48))' "$auth" | head -1 | cut -d: -f1)
[[ -n "$submit_add_line" && -n "$switch_add_line" && "$submit_add_line" -lt "$switch_add_line" ]]
grep -Fq 'val focusChain = listOfNotNull<View>(identity, username, email, password, confirm, submit, switch)' "$auth"
grep -Fq 'view.nextFocusUpId = focusChain.getOrNull(index - 1)?.id ?: view.id' "$auth"
grep -Fq 'view.nextFocusDownId = focusChain.getOrNull(index + 1)?.id ?: view.id' "$auth"
grep -Fq 'focusModeSwitchAfterRender = isTvLike()' "$auth"
grep -Fq 'switch.requestFocus()' "$auth"

# Downloader keeps the existing row-aware vertical routing, but focus can no longer
# reorder action siblings while travelling UP/DOWN.
grep -Fq 'tag = "bm_download_action_row"' "$downloads"
grep -Fq 'bindDownloadActionVerticalFocus(actions)' "$downloads"
grep -Fq 'val currentColumn = row.indexOfChild(current).coerceAtLeast(0)' "$downloads"
grep -Fq 'target.requestFocus()' "$downloads"

# Regression guards from previously device-confirmed fixes.
bash verify_tv_focus_v714_vip_drawer_auth.sh >/dev/null
bash verify_tv_focus_v713_detail_first_press.sh >/dev/null
bash verify_tv_focus_v711_category_bootstrap.sh >/dev/null

echo TV_FOCUS_V715_AUTH_DOWNLOAD_NO_REORDER_OK
