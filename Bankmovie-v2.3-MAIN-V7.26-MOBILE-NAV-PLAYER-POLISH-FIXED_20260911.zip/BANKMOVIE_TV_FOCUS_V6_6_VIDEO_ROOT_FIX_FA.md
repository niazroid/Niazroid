# BankMovie TV Focus V6.6 — Video Root Fix

این پچ بر اساس بررسی مستقیم ویدیوی `video_2026-09-06_14-10-50.mp4` ساخته شده است.

## اصلاح‌های واقعی کد

- Weekly در TV دیگر بار اول در حالت detached ساخته نمی‌شود؛ اولین render فقط بعد از attach شدن section انجام می‌شود. بنابراین همان state سالمی که قبلاً فقط بعد از تغییر روز ایجاد می‌شد، از اولین ورود وجود دارد.
- Advanced Search داخل AlertDialog دیگر فقط به `MainActivity.dispatchKeyEvent` تکیه ندارد. Dialog Window رویداد DPAD را خودش می‌گیرد، بنابراین nextFocus ID و OnKeyListener مستقیم برای type/selector/year/flag/action controls نصب می‌شود.
- Continue Watching در Profile مسیر مستقیم LEFT/RIGHT روی خود کارت واقعی دارد و `مشاهده همه` end-cap مستقیم است. صفحه کامل Continue نیز UP/DOWN مستقیم دارد.
- Box Office داده‌ها را قبل از ساخت بر اساس `rank` مرتب می‌کند و هر ردیف OnKeyListener مستقیم UP/DOWN دارد تا ورود از رتبه 1 باشد و firmware نتواند روی رتبه 3 فرود بیاید.
- `bindTvDirectionalTarget` علاوه بر router داخلی، در صورت موجود بودن target مقدار native nextFocus را هم می‌نویسد تا Dialogها و firmwareهای TV مسیر fallback معتبر داشته باشند.

## نسخه

- versionName: 2.3
- patch: V6.6 VIDEO ROOT
