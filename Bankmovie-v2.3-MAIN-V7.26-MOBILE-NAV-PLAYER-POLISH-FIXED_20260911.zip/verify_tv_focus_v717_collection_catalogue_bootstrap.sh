#!/usr/bin/env bash
set -euo pipefail

main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
test -s "$main"

# Keep the V7.16 physical bootstrap implementation and all previous regressions.
bash verify_tv_focus_v716_profile_slider_catalogue_bootstrap.sh >/dev/null

python3 - "$main" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text()

def fn(name: str) -> str:
    marker = f"private fun {name}"
    start = s.find(marker)
    if start < 0:
        raise SystemExit(f"missing function: {name}")
    # next top-level private fun is sufficient for these source checks
    nxt = s.find("\n    private fun ", start + len(marker))
    return s[start: nxt if nxt >= 0 else len(s)]

checks = {
    'showCollections': [
        'V7.17: Collections is a catalogue grid too.',
        'if (tv && p == 1) armV716CatalogueGridBootstrap(grid)',
    ],
    'showCollectionItems': [
        'V7.17: collection titles use the same physical first-press',
        'if (tv && p == 1) armV716CatalogueGridBootstrap(grid)',
    ],
    'showArchive2GenreList': [
        'V7.17: keep every non-search catalogue list on the same',
        'if (tv && p == 1) armV716CatalogueGridBootstrap(grid)',
    ],
}
for name, needles in checks.items():
    block = fn(name)
    for needle in needles:
        if needle not in block:
            raise SystemExit(f"{name}: missing {needle!r}")

# Search and already-stable full-list behavior must not be rewritten by this patch.
for name in ('showAdvancedSearchResults', 'doSearch', 'showKeywordList'):
    block = fn(name)
    if 'V7.17:' in block:
        raise SystemExit(f"{name}: V7.17 must not modify the working search path")

# Full list keeps its V7.16 call exactly as before.
if 'if (tv && p == 1) armV716CatalogueGridBootstrap(grid)' not in fn('showList'):
    raise SystemExit('showList: V7.16 bootstrap regression')
PY

grep -Fq 'focusPatchTenthFollowup=V7.17 COLLECTION + COLLECTION-TITLES + NON-SEARCH CATALOGUE BOOTSTRAP' BANKMOVIE_BUILD_SOURCE_2_3.txt
grep -Fq 'sourceBuildTenthFollowupTag=BANKMOVIE-TV-2.3-V717-20260909' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo TV_FOCUS_V717_COLLECTION_CATALOGUE_BOOTSTRAP_OK
