# BankMovie TV Focus V7.3 — Search IME + Category Grid + Detail Root

این پچ فقط چهار مسیر باقی‌مانده TV را اصلاح می‌کند و مسیرهای درست‌شده V7.2/V7.1 را دست نمی‌زند.

- Search: وقتی EditText از لحظه ورود فوکوس دارد، OK یک focus-bounce یک‌فریمی روی sink نامرئی انجام می‌دهد و سپس IME را با SHOW_FORCED روی همان EditText باز می‌کند؛ دیگر نیاز به رفتن روی Back و برگشت نیست.
- Categories / Genre directory: جهت‌ها بر اساس موقعیت واقعی کارت‌ها بعد از layout سیم‌کشی می‌شوند؛ DOWN همان ستون فیزیکی ردیف بعد را می‌گیرد و اولین DOWN به چپ منحرف نمی‌شود.
- TV Detail palette: پوستر به GradientDrawable رنگی تبدیل می‌شود و دیگر bitmap کوچک scale نمی‌شود؛ یک seam shield مشکی بیرون Hero هم اضافه شده تا رنگ وارد Synopsis نشود.
- TV Detail DPAD: DOWN از هر کنترل Hero مستقیماً وارد اولین کنترل محتوای پایین (Synopsis More / More information / اولین کنترل بعدی) می‌شود و Native focus اجازه ندارد ابتدا Back را انتخاب کند.

Marker: TV_FOCUS_V73_SEARCH_CATEGORY_DETAIL_ROOT_OK
