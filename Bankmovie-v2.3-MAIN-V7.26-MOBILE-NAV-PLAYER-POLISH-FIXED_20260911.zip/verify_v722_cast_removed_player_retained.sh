#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PLAYER='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
GRADLE='app/build.gradle'
MANIFEST='app/src/main/AndroidManifest.xml'

# Cast stack must be fully absent from runtime source/dependencies.
! grep -E "play-services-cast|androidx\.mediarouter|androidx\.appcompat:appcompat|androidx\.fragment:fragment" "$GRADLE" >/dev/null
! grep -E 'CastContext|CastSession|RemoteMediaClient|MediaRoute|DlnaRouteProvider|DlnaController|Chromecast|ic_player_cast' "$PLAYER" >/dev/null
! grep -E 'com\.google\.android\.gms\.cast|OPTIONS_PROVIDER_CLASS_NAME|CHANGE_WIFI_MULTICAST_STATE|ACCESS_WIFI_STATE' "$MANIFEST" >/dev/null
for f in \
  app/src/main/java/ir/bankmoviee/app/BankmovieCastOptionsProvider.kt \
  app/src/main/java/ir/bankmoviee/app/DlnaController.kt \
  app/src/main/java/ir/bankmoviee/app/DlnaDiscovery.kt \
  app/src/main/java/ir/bankmoviee/app/DlnaRouteProvider.kt \
  app/src/main/res/drawable/ic_player_cast.xml; do
  test ! -e "$f"
done

# Player startup/lifecycle must be the local LibVLC path with retained reattach.
grep -Fq 'class PlayerActivity : Activity()' "$PLAYER"
grep -Fq 'private const val PLAYER_BACKGROUND_RETAIN_MS = 180_000L' "$PLAYER"
grep -Fq 'retained.attachViews(videoLayout, null, false, false)' "$PLAYER"
grep -Fq 'override fun onStop() {' "$PLAYER"
grep -Fq 'current.detachViews()' "$PLAYER"
grep -Fq 'handler.postDelayed(releaseRetainedPlayerRunnable, PLAYER_BACKGROUND_RETAIN_MS)' "$PLAYER"
grep -Fq 'override fun onSaveInstanceState(outState: Bundle)' "$PLAYER"
grep -Fq 'restoreInstancePlaybackState(savedInstanceState)' "$PLAYER"
grep -Fq 'max(lifecyclePosition, requestedResumePosition)' "$PLAYER"

# Generic retained navigation from V7.21 must remain intact.
grep -Fq 'BANKMOVIE_V721_RETAINED_BACKSTACK' "$MAIN"
grep -Fq 'restoreRetainedNavigationScreen' "$MAIN"

grep -Fq 'sourceMainUpdateThirdHotfixTag=BANKMOVIE-2.3-V722-20260910' BANKMOVIE_BUILD_SOURCE_2_3.txt

echo V722_CAST_REMOVED_PLAYER_RETAINED_OK
