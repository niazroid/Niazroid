# BankMovie TV Focus V7.5 — Detail / Categories / Search Stability

این پچ روی سورس V7.4 سه ایراد گزارش‌شده روی TV را هدف می‌گیرد و منطق بخش‌های تاییدشده قبلی را تغییر نمی‌دهد.

## Detail — ردیف پخش آنلاین / تریلر
- در V7.4 تگ `bm_v74_detail_actions` اشتباهاً روی ردیف اکشن‌های Advanced Search قرار گرفته بود و ردیف واقعی Hero فیلم بدون تگ مانده بود.
- تگ از Advanced Search برداشته و روی ردیف واقعی `پخش آنلاین / تریلر / واچ‌لیست` قرار گرفت.
- LEFT/RIGHT این ردیف کاملاً owned است؛ اگر `requestFocus()` در همان فریم تایید نشود، کلید مصرف و در فریم بعد retry می‌شود تا native `focusSearch()` نتواند به Back گوشه بالا بپرد.

## Categories — DOWN نباید افقی بپرد
- Grid دسته‌بندی همان لحظه ساخت tag می‌شود، نه اینکه فقط به wiring بعد از layout تکیه کند.
- router زنده Grid را مستقیماً از root پیدا می‌کند و DOWN/UP را بر اساس مختصات واقعی ردیف‌ها می‌برد.
- اگر اولین انتقال فوکوس در همان فریم تایید نشود، جهت consume و در فریم بعد retry می‌شود؛ بنابراین fallback اندروید دیگر DOWN را به حرکت افقی تبدیل نمی‌کند.

## Search — کیبورد بعد از اولین حرف بسته نشود
- guard قدیمی ۵۲۰ms که همه OKها را می‌خورد به ۲۲۰ms و فقط ACTION_UP همان OK اولیه محدود شد.
- وقتی IME باز یا session جستجو primed است، OK دیگر focus bounce به Back انجام نمی‌دهد.
- بعد از commit هر کاراکتر، اگر TV IME به اشتباه مخفی شده باشد، همان input connection بدون تغییر فوکوس دوباره باز می‌شود.
- وقتی کاربر با UP/DOWN از EditText خارج می‌شود، session reset می‌شود تا در برگشت bridge اولیه دوباره قابل استفاده باشد.

Marker: `TV_FOCUS_V75_DETAIL_CATEGORY_SEARCH_STABILITY_OK`
