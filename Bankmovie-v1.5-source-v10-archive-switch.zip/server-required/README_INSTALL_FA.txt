بسته سرور آرشیو ۱ و آرشیو ۲ بانک مووی
=====================================

این چهار فایل را کنار app_api.php و app_config.php در ریشه سایت قرار دهید:
- archive1_live.php
- archive1_live_lib.php
- api5.php
- api5_lib.php

تست‌ها:
- https://YOUR-DOMAIN/archive1_live.php?ping=1
- https://YOUR-DOMAIN/archive1_live.php?section=dubbed&page=1
- https://YOUR-DOMAIN/archive1_live.php?section=chinese_series&page=1
- https://YOUR-DOMAIN/api5.php?ping=1
- https://YOUR-DOMAIN/api5.php?section=new_movies&page=1

اپ به‌صورت پیش‌فرض همین مسیرها را از دامنه فعال سایت می‌خواند و نیازی به تغییر دستی نیست.
برای مسیر سفارشی می‌توانید این کلیدها را به bankmovie_remote_config.json اضافه کنید:

"archive1_live_api_url": "https://YOUR-DOMAIN/archive1_live.php",
"archive2_api_url": "https://YOUR-DOMAIN/api5.php",
"archive1_source_url": "https://www.oldtowns.top"

نیازمندی PHP:
- curl
- dom
- mbstring
