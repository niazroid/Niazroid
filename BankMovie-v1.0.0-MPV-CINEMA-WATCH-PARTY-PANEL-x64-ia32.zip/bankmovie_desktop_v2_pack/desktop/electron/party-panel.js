'use strict';
// A local-only dedicated companion window. MPV remains a native independent process.
const path=require('path');
const {pathToFileURL}=require('url');
class PartyPanel {
 constructor({BrowserWindow,ipcMain,screen,session,controller,icon}){
  Object.assign(this,{BrowserWindow,screen,session,controller,icon});this.window=null;this.room=null;this.closing=false;
  this.file=path.join(__dirname,'../src/party-panel.html');this.url=pathToFileURL(this.file).href;
  for(const [channel,fn] of [['bm-party-panel:state',()=>this.controller().snapshot(this.room)],['bm-party-panel:action',a=>this.controller().enqueue(this.room,a)]])ipcMain.handle(channel,(event,...args)=>{if(!this.trusted(event))throw Error('درخواست نامعتبر');return fn(...args);});
 }
 trusted(e){try{const w=this.window,c=w.webContents,f=e.senderFrame,m=c.mainFrame;return !w.isDestroyed()&&!c.isDestroyed()&&e.sender.id===c.id&&f.processId===m.processId&&f.routingId===m.routingId&&f.url===this.url&&c.getURL()===this.url&&this.controller()?.active===this.room&&!this.room.closed;}catch{return false;}}
 bounds(){const a=this.screen.getPrimaryDisplay().workArea;const width=Math.min(a.width,Math.max(300,Math.min(390,Math.round(a.width*.27))));return {x:a.x+a.width-width,y:a.y,width,height:a.height,areaWidth:a.width};}
 playerWidthPercent(){try{const b=this.bounds();return 100*(b.areaWidth-b.width-12)/b.areaWidth;}catch{return 68;}}
 open(s){if(!s||s.closed||this.controller()?.active!==s)return;if(this.window&&!this.window.isDestroyed()){if(this.room!==s)this.close(this.room);else{this.window.show();this.window.focus();return;}}
  const b=this.bounds();const ses=this.session.fromPartition('bm-party-panel');ses.setPermissionRequestHandler((_wc,_p,cb)=>cb(false));ses.setPermissionCheckHandler(()=>false);
  // No remote URLs, navigation, file upload, generic IPC, or privileged app preload.
  const w=new this.BrowserWindow({x:b.x,y:b.y,width:b.width,height:b.height,minWidth:280,minHeight:Math.min(400,b.height),show:false,autoHideMenuBar:true,title:'BankMovie | تماشای دونفره',backgroundColor:'#0b1018',icon:this.icon,webPreferences:{preload:path.join(__dirname,'party-panel-preload.js'),partition:'bm-party-panel',sandbox:true,contextIsolation:true,nodeIntegration:false,webSecurity:true}});
  this.window=w;this.room=s;s.panelVisible=false;
  w.setMenuBarVisibility(false);w.webContents.setWindowOpenHandler(()=>({action:'deny'}));w.webContents.on('will-navigate',e=>e.preventDefault());w.webContents.on('will-redirect',e=>e.preventDefault());w.webContents.on('will-attach-webview',e=>e.preventDefault());
  w.on('show',()=>{s.panelVisible=true;});w.on('hide',()=>{s.panelVisible=false;});w.on('close',e=>{if(this.window===w&&!this.closing&&!s.closed){e.preventDefault();w.hide();}});w.on('closed',()=>{s.panelVisible=false;if(this.window===w){this.window=null;this.room=null;}});
  w.once('ready-to-show',()=>{if(this.window===w&&!s.closed&&!w.isDestroyed())w.show();});w.loadFile(this.file).catch(()=>{if(this.window===w)this.close(s);});
 }
 close(s){if(this.room!==s)return;s.panelVisible=false;const w=this.window;this.closing=true;this.window=null;this.room=null;try{if(w&&!w.isDestroyed())w.destroy();}finally{this.closing=false;}}
}
module.exports={PartyPanel};
