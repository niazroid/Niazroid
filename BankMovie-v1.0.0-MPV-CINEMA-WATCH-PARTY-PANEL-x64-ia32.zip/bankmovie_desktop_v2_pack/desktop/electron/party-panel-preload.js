'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('partyPanel',Object.freeze({state:()=>ipcRenderer.invoke('bm-party-panel:state'),action:a=>ipcRenderer.invoke('bm-party-panel:action',a)}));
