<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/vip_sales.php';

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
bm_security_cors(['GET','OPTIONS'], ['Content-Type'], true);
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
bm_security_enforce_rate_limit('app_config_public', 300, 300, bm_security_client_ip(), true);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$configFile = __DIR__ . '/bankmovie_remote_config.json';
$default = [
    'schema_version' => 5,
    'ready' => true,
    'message' => 'اپ موقتاً در دسترس نیست.',
    'active_domain' => 'https://bankmoviee.ir',
    'api_url' => 'https://bankmoviee.ir/app_api.php',
    'account_api_url' => 'https://bankmoviee.ir/app_user_api.php',
    'account_api_urls' => ['https://bankmoviee.ir/app_user_api.php','https://bankmovie.top/app_user_api.php'],
    'servers' => [
        [
            'name' => 'سرور اصلی bankmoviee.ir',
            'enabled' => true,
            'priority' => 1,
            'domain' => 'https://bankmoviee.ir',
            'api_url' => 'https://bankmoviee.ir/app_api.php'
        ],
        [
            'name' => 'سرور جایگزین bankmovie.top',
            'enabled' => true,
            'priority' => 2,
            'domain' => 'https://bankmovie.top',
            'api_url' => 'https://bankmovie.top/app_api.php'
        ]
    ],
    'url_rewrites' => [],
    'features' => [
        'registration_enabled'=>true,'login_enabled'=>true,'comments_enabled'=>true,
        'comment_replies_enabled'=>true,'comment_votes_enabled'=>true,'comment_reports_enabled'=>true,'comment_spoiler_enabled'=>true,
        'notification_center_enabled'=>true,'internal_downloader_enabled'=>true,'multipart_download_enabled'=>true,
        'download_path_selection_enabled'=>true,'advanced_search_enabled'=>true,'categories_enabled'=>true,
        'watchlist_enabled'=>true,'continue_watching_enabled'=>true,'tv_quick_menu_enabled'=>true,
        'login_poster_url'=>'','download_limit'=>2,
        'archives'=>[
            'archive1_enabled'=>true,'archive1_hidden'=>false,
            'archive2_enabled'=>true,'archive2_hidden'=>false,
            'archive3_enabled'=>true,'archive3_hidden'=>false
        ]
    ],
    'comments' => ['edit_minutes'=>10,'rate_count'=>3,'rate_minutes'=>10,'auto_approve_admin'=>true,'auto_approve_vip'=>true],
    'downloads' => ['concurrent_limit'=>2,'retry_count'=>4,'retry_delay_seconds'=>8,'min_free_mb'=>256,'multipart_parts'=>4],
    'home' => [
        'archive1_sections'=>['updated_movies','updated_series','korean_series','dubbed','chinese_series','top_2026','anime','turkish','collections'],
        'archive2_sections'=>['updated_movies','updated_series','dubbed','animation','action','drama']
    ],
    'notice'  => ['enabled'=>false,'id'=>'','type'=>'admin','title'=>'','message'=>'','dismissible'=>true,'target'=>['url'=>'']],
    'update' => [
        'enabled' => false,
        'version_code' => 1110000,
        'version_name' => '1.4',
        'apk_url' => '',
        'apk_urls' => ['universal'=>'','arm64_v8a'=>'','armeabi_v7a'=>''],
        'force' => false,
        'title' => 'آپدیت جدید آماده است',
        'message' => 'نسخه جدید Bankmovie آماده دانلود است.',
        'changes' => []
    ],
    'version_policy' => [
        'enabled' => true,
        'minimum_version_code' => 0,
        'minimum_version_name' => '',
        'blocked_version_names' => [],
        'blocked_version_codes' => [],
        'force_update_blocked' => true,
        'latest_version_only' => false,
        'block_message' => 'این نسخه از Bankmovie غیرفعال شده است. برای ادامه نسخه جدید را نصب کنید.'
    ],
    'updated_at' => gmdate('c')
];

if (is_file($configFile)) {
    $raw = file_get_contents($configFile);
    $saved = is_string($raw) ? json_decode($raw, true) : null;
    if (is_array($saved)) $default = array_replace_recursive($default, $saved);
}

// One-time controller migration: old installations shipped bankmovie.top as
// the bootstrap domain. Schema v5 promotes bankmoviee.ir while still keeping
// the former host as a remotely selectable fallback.
if ((int)($default['schema_version'] ?? 0) < 5) {
    $default['schema_version'] = 5;
    $default['active_domain'] = 'https://bankmoviee.ir';
    $default['api_url'] = 'https://bankmoviee.ir/app_api.php';
    $default['account_api_url'] = 'https://bankmoviee.ir/app_user_api.php';
    $default['account_api_urls'] = ['https://bankmoviee.ir/app_user_api.php','https://bankmovie.top/app_user_api.php'];
}

// Archive access is managed in the same panel/settings used by the website.
// The content endpoint still evaluates the signed-in user for every request;
// this public document only advertises current archive capabilities/scopes.
$archivePublic = [];
if (function_exists('bm_archive_get_settings')) {
    $archiveSettings = bm_archive_get_settings();
    foreach ((array)($archiveSettings['archives'] ?? []) as $archiveId => $row) {
        if (!is_array($row)) continue;
        $enabled = !empty($row['enabled']);
        $downloadScope = (string)($row['download_access_scope'] ?? 'public');
        $streamScope = (string)($row['stream_access_scope'] ?? 'public');
        $archivePublic[(string)$archiveId] = [
            'label'=>(string)($row['label'] ?? ''),
            'enabled'=>$enabled,
            'access_scope'=>(string)($row['access_scope'] ?? 'public'),
            'download_access_scope'=>$downloadScope,
            'stream_access_scope'=>$streamScope,
            // These booleans describe anonymous access only. The content API
            // evaluates the signed-in account (including site VIP expiry) on
            // every request and is the authoritative enforcement point.
            'downloads_allowed'=>$enabled && $downloadScope === 'public',
            'stream_allowed'=>$enabled && $streamScope === 'public',
            'disabled_mode'=>(string)($row['disabled_mode'] ?? 'visible'),
            'disabled_message'=>(string)($row['disabled_message'] ?? ''),
        ];
    }
}
$default['archive_policy'] = $archivePublic;
if (!isset($default['features']['archives']) || !is_array($default['features']['archives'])) $default['features']['archives'] = [];
foreach ([1=>'archive1',2=>'archive2',3=>'archive3',4=>'archive4'] as $number => $archiveId) {
    $row = is_array($archivePublic[$archiveId] ?? null) ? $archivePublic[$archiveId] : [];
    $default['features']['archives']['archive' . $number . '_enabled'] = !empty($row['enabled']);
    $default['features']['archives']['archive' . $number . '_hidden'] = (($row['disabled_mode'] ?? 'visible') === 'hide');
}

if (function_exists('bm_vip_sales_settings')) {
    $sales = bm_vip_sales_settings();
    $default['vip'] = [
        'plans' => array_values(array_filter(array_map(static function ($plan) {
            if (!is_array($plan) || empty($plan['enabled'])) return null;
            return [
                'name'=>(string)($plan['name'] ?? ''), 'latin'=>(string)($plan['latin'] ?? ''),
                'price'=>(string)($plan['price'] ?? ''), 'period'=>(string)($plan['period'] ?? ''),
                'badge'=>(string)($plan['badge'] ?? ''), 'saving'=>(string)($plan['saving'] ?? ''),
                'featured'=>!empty($plan['featured']), 'tone'=>(string)($plan['tone'] ?? 'blue'),
            ];
        }, (array)($sales['plans'] ?? [])))),
        'telegram_username'=>(string)($sales['telegram_username'] ?? 'bankmovie_supp'),
        'purchase_enabled'=>!empty($sales['purchase_enabled']),
        'purchase_message_template'=>(string)($sales['purchase_message_template'] ?? ''),
        'section_title'=>(string)($sales['section_title'] ?? 'BankMovie VIP'),
        'section_description'=>(string)($sales['section_description'] ?? ''),
        'features'=>array_values(array_filter(array_map(static function ($feature) {
            return is_array($feature) && !empty($feature['enabled']) ? (string)($feature['label'] ?? '') : '';
        }, (array)($sales['features'] ?? [])))),
    ];
}

echo json_encode($default, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
