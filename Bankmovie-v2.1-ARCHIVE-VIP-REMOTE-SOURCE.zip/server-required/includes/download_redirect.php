<?php
/**
 * BankMovie download redirect wrapper.
 *
 * - No database lookup is required.
 * - The real destination is stored inside an authenticated encrypted token.
 * - The redirect endpoint only sends an HTTP redirect; it never proxies the file body.
 * - Instant rollback: create _bankmovie_private/download_redirect.disabled
 */
if (!function_exists('bm_security_private_path')) {
    require_once __DIR__ . '/security_bootstrap.php';
}

if (!function_exists('bm_dl_redirect_disabled')) {
    function bm_dl_redirect_disabled(): bool
    {
        $env = getenv('BANKMOVIE_DL_REDIRECT_ENABLED');
        if ($env !== false && trim((string)$env) !== '') {
            $parsed = filter_var($env, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($parsed !== null) return !$parsed;
        }
        return is_file(bm_security_private_path('download_redirect.disabled'));
    }
}

if (!function_exists('bm_dl_redirect_base')) {
    function bm_dl_redirect_base(string $archiveId = '', string $seed = ''): string
    {
        if ($archiveId !== '' && function_exists('bm_archive_pick_download_base_url')) {
            $managed = bm_archive_pick_download_base_url($archiveId, $seed);
            if ($managed !== '') return rtrim($managed, '/');
        }
        $base = function_exists('bm_security_secret')
            ? bm_security_secret('download_redirect_base', 'BANKMOVIE_DL_REDIRECT_BASE', 'https://bankmoviee.ir')
            : 'https://bankmoviee.ir';
        $base = trim((string)$base);
        if (!preg_match('~^https://[a-z0-9.-]+(?::\d+)?(?:/.*)?$~i', $base)) {
            $base = 'https://bankmoviee.ir';
        }
        return rtrim($base, '/');
    }
}

if (!function_exists('bm_dl_resolve_archive_id')) {
    function bm_dl_resolve_archive_id(string $archiveId = ''): string
    {
        $archiveId = strtolower(trim($archiveId));
        if ($archiveId === '' && isset($GLOBALS['bmCurrentArchiveId'])) {
            $archiveId = strtolower(trim((string)$GLOBALS['bmCurrentArchiveId']));
        }
        return in_array($archiveId, ['archive1','archive2','archive3','archive4'], true) ? $archiveId : '';
    }
}

if (!function_exists('bm_dl_b64u_encode')) {
    function bm_dl_b64u_encode(string $raw): string
    {
        return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
    }
}

if (!function_exists('bm_dl_b64u_decode')) {
    function bm_dl_b64u_decode(string $value): string|false
    {
        if ($value === '' || !preg_match('/^[A-Za-z0-9_-]+$/', $value)) return false;
        $pad = strlen($value) % 4;
        if ($pad) $value .= str_repeat('=', 4 - $pad);
        return base64_decode(strtr($value, '-_', '+/'), true);
    }
}

if (!function_exists('bm_dl_key')) {
    function bm_dl_key(): string|false
    {
        static $key = null;
        if (is_string($key) && strlen($key) === 32) return $key;

        $env = getenv('BANKMOVIE_DL_REDIRECT_KEY');
        if ($env !== false && trim((string)$env) !== '') {
            $candidate = trim((string)$env);
            $decoded = base64_decode($candidate, true);
            if (is_string($decoded) && strlen($decoded) === 32) return $key = $decoded;
            if (strlen($candidate) >= 32) return $key = hash('sha256', $candidate, true);
        }

        $file = bm_security_private_path('download_redirect.key');
        if (is_file($file) && is_readable($file)) {
            $stored = trim((string)@file_get_contents($file));
            $decoded = base64_decode($stored, true);
            if (is_string($decoded) && strlen($decoded) === 32) return $key = $decoded;
        }

        // First-use bootstrap. The key is kept in BankMovie's private directory, not public assets.
        try {
            $raw = random_bytes(32);
        } catch (Throwable $e) {
            error_log('BankMovie DL redirect key generation failed: ' . $e->getMessage());
            return false;
        }
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        if (@file_put_contents($file, base64_encode($raw) . "\n", LOCK_EX) === false) {
            error_log('BankMovie DL redirect key could not be persisted.');
            return false;
        }
        @chmod($file, 0600);
        return $key = $raw;
    }
}

if (!function_exists('bm_dl_is_http_url')) {
    function bm_dl_is_http_url(string $url): bool
    {
        if ($url === '' || strlen($url) > 8192 || preg_match('/[\x00-\x20\x7f]/', $url)) return false;
        $parts = @parse_url($url);
        if (!is_array($parts)) return false;
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
        if (!in_array($scheme, ['http', 'https'], true) || $host === '') return false;
        if (str_contains($host, '@') || preg_match('/[\s\\\\]/', $host)) return false;
        return true;
    }
}

if (!function_exists('bm_dl_is_own_redirect')) {
    function bm_dl_is_own_redirect(string $url, string $archiveId = ''): bool
    {
        $path = (string)(parse_url($url, PHP_URL_PATH) ?: '');
        $query = (string)(parse_url($url, PHP_URL_QUERY) ?: '');
        parse_str($query, $params);
        // A matching host by itself is not enough: a raw media file can also
        // live on BankMovie's domain. Only an already signed gateway route may
        // bypass wrapping, otherwise fail-closed app responses could leak it.
        if (!preg_match('~^/[0-9][a-z]/(?:movie|series)/[a-z]{1,2}/[^/]+$~i', $path)) return false;
        if (trim((string)($params['sig'] ?? '')) === '') return false;
        $targetHost = strtolower((string)(parse_url($url, PHP_URL_HOST) ?: ''));
        if ($targetHost === '') return false;
        $hosts = [strtolower((string)(parse_url(bm_dl_redirect_base($archiveId), PHP_URL_HOST) ?: ''))];
        if ($archiveId !== '' && function_exists('bm_archive_download_base_urls')) {
            foreach (bm_archive_download_base_urls($archiveId) as $base) {
                $hosts[] = strtolower((string)(parse_url($base, PHP_URL_HOST) ?: ''));
            }
        }
        return in_array($targetHost, array_filter(array_unique($hosts)), true);
    }
}

if (!function_exists('bm_dl_source_expiry')) {
    function bm_dl_source_expiry(string $url): ?int
    {
        $query = (string)(parse_url($url, PHP_URL_QUERY) ?: '');
        if ($query === '') return null;
        parse_str($query, $params);
        foreach (['expires', 'expire', 'exp'] as $k) {
            if (!isset($params[$k]) || !is_scalar($params[$k])) continue;
            $raw = trim((string)$params[$k]);
            if (!preg_match('/^\d{9,13}$/', $raw)) continue;
            $n = (int)$raw;
            if ($n > 20000000000) $n = (int)floor($n / 1000); // milliseconds -> seconds
            if ($n > time() - 60) return $n;
        }
        return null;
    }
}

if (!function_exists('bm_dl_token_for_url')) {
    function bm_dl_token_for_url(string $url, int $ttl = 21600, string $archiveId = ''): string|false
    {
        $url = trim($url);
        if (!bm_dl_is_http_url($url)) return false;
        $key = bm_dl_key();
        if (!is_string($key) || strlen($key) !== 32 || !function_exists('openssl_encrypt')) return false;

        $ttl = max(300, min(86400, $ttl));
        $exp = time() + $ttl;
        $sourceExp = bm_dl_source_expiry($url);
        if ($sourceExp !== null) $exp = min($exp, $sourceExp);
        if ($exp <= time() + 5) return false;

        $archiveId = bm_dl_resolve_archive_id($archiveId);
        $payload = json_encode(['v' => 1, 'u' => $url, 'exp' => $exp, 'a' => $archiveId], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($payload)) return false;

        try { $iv = random_bytes(12); } catch (Throwable $e) { return false; }
        $tag = '';
        $cipher = openssl_encrypt($payload, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'bankmovie-dl-v1', 16);
        if (!is_string($cipher) || strlen($tag) !== 16) return false;
        return bm_dl_b64u_encode(chr(1) . $iv . $tag . $cipher);
    }
}

if (!function_exists('bm_dl_decode_token')) {
    function bm_dl_decode_token(string $token): array|false
    {
        $raw = bm_dl_b64u_decode($token);
        if (!is_string($raw) || strlen($raw) < 1 + 12 + 16 + 1) return false;
        if (ord($raw[0]) !== 1) return false;
        $iv = substr($raw, 1, 12);
        $tag = substr($raw, 13, 16);
        $cipher = substr($raw, 29);
        $key = bm_dl_key();
        if (!is_string($key) || strlen($key) !== 32 || !function_exists('openssl_decrypt')) return false;
        $plain = openssl_decrypt($cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, 'bankmovie-dl-v1');
        if (!is_string($plain)) return false;
        $data = json_decode($plain, true);
        if (!is_array($data) || (int)($data['v'] ?? 0) !== 1) return false;
        $url = trim((string)($data['u'] ?? ''));
        $exp = (int)($data['exp'] ?? 0);
        if (!bm_dl_is_http_url($url) || $exp <= time()) return false;
        $archiveId = bm_dl_resolve_archive_id((string)($data['a'] ?? ''));
        return ['url' => $url, 'exp' => $exp, 'archive_id' => $archiveId];
    }
}

if (!function_exists('bm_dl_strip_source_brand')) {
    function bm_dl_strip_source_brand(string $name): string
    {
        // Cosmetic filename cleanup only. The real destination URL is never modified.
        // Keep this list intentionally narrow to avoid removing legitimate movie-title words.
        $name = preg_replace(
            '/(?:[._-]+)(?:Film2Media|DonyayeSerial)(?=(?:[._-]+)?(?:mkv|mp4|avi|mov|m4v|webm|ts)$)/i',
            '',
            $name
        ) ?? $name;
        return $name;
    }
}

if (!function_exists('bm_dl_pretty_filename')) {
    function bm_dl_pretty_filename(string $url): string
    {
        $path = (string)(parse_url($url, PHP_URL_PATH) ?: '');
        $name = rawurldecode((string)basename($path));
        $name = preg_replace('/[\x00-\x1F\x7F]+/', '', $name) ?? '';
        $name = str_replace(['/', '\\', '?', '#', '&', '='], '.', $name);
        $name = preg_replace('/\s+/u', '.', trim($name)) ?? '';
        $name = preg_replace('/\.{2,}/', '.', $name) ?? '';
        $name = trim($name, '.-_ ');
        $name = bm_dl_strip_source_brand($name);
        $name = preg_replace('/\.{2,}/', '.', $name) ?? $name;
        $name = trim($name, '.-_ ');
        if ($name === '' || strlen($name) > 180) {
            $ext = strtolower((string)pathinfo($path, PATHINFO_EXTENSION));
            if (!preg_match('/^[a-z0-9]{2,5}$/', $ext)) $ext = 'mkv';
            $name = 'BankMovie.Download.' . date('Ymd-His') . '.' . $ext;
        }
        return $name;
    }
}

if (!function_exists('bm_dl_media_bucket')) {
    function bm_dl_media_bucket(string $url): string
    {
        $haystack = rawurldecode((string)(parse_url($url, PHP_URL_PATH) ?: ''));
        if (
            preg_match('~(?:^|/)(?:series|tv|shows?)(?:/|$)~i', $haystack)
            || preg_match('~S\d{1,2}E\d{1,3}~i', $haystack)
            || preg_match('~(?:^|/)S\d{1,2}(?:/|$)~i', $haystack)
        ) {
            return 'series';
        }
        return 'movie';
    }
}


if (!function_exists('bm_dl_content_key')) {
    function bm_dl_content_key(string $url): string
    {
        $filename = bm_dl_pretty_filename($url);
        $stem = (string)pathinfo($filename, PATHINFO_FILENAME);
        $stem = preg_replace('/[._-]+S\d{1,2}E\d{1,3}(?=[._-]|$)/i', '.', $stem) ?? $stem;
        $stem = preg_replace('/[._-]+E\d{1,3}(?=[._-]|$)/i', '.', $stem) ?? $stem;
        $stem = preg_replace('/[._-]+S\d{1,2}(?=[._-]|$)/i', '.', $stem) ?? $stem;

        // Everything from the first common release/quality marker onward is technical metadata,
        // not part of the title identity. This keeps all episodes/qualities on one stable shard.
        $parts = preg_split(
            '/[._-]+(?=(?:2160p|1080p|720p|576p|540p|480p|360p|WEB[._-]?DL|WEBRip|BluRay|BRRip|HDRip|DVDRip|x26[45]|HEVC|AV1|10bit|8bit|AAC|DDP|DD5|6CH|2CH|Farsi|Persian|Dubbed|SoftSub|HardSub|Subbed|Farsi[._-]?Sub)\b)/i',
            $stem,
            2
        );
        $stem = is_array($parts) && isset($parts[0]) ? (string)$parts[0] : $stem;

        $stem = strtolower(trim((string)(preg_replace('/[._-]+/', '.', $stem) ?? $stem), '.-_ '));
        if ($stem === '') {
            $stem = strtolower((string)(parse_url($url, PHP_URL_HOST) ?: 'download'));
        }
        return bm_dl_media_bucket($url) . '|' . $stem;
    }
}

if (!function_exists('bm_dl_stable_route_parts')) {
    function bm_dl_stable_route_parts(string $url): array
    {
        $key = bm_dl_key();
        $contentKey = bm_dl_content_key($url);
        $hash = is_string($key) && strlen($key) === 32
            ? hash_hmac('sha256', $contentKey, $key, true)
            : hash('sha256', $contentKey, true);

        $edge = (string)((ord($hash[0]) % 9) + 1) . chr(97 + (ord($hash[1]) % 26));
        $len = 1 + (ord($hash[2]) % 2);
        $folder = '';
        for ($i = 0; $i < $len; $i++) {
            $folder .= chr(97 + (ord($hash[3 + $i]) % 26));
        }
        return [$edge, $folder];
    }
}

// Kept for backward compatibility with any external caller.
if (!function_exists('bm_dl_random_edge_folder')) {
    function bm_dl_random_edge_folder(): string
    {
        try { return (string)random_int(1, 9) . chr(random_int(97, 122)); }
        catch (Throwable $e) { return (string)mt_rand(1, 9) . chr(mt_rand(97, 122)); }
    }
}

if (!function_exists('bm_dl_random_folder')) {
    function bm_dl_random_folder(): string
    {
        try { $len = random_int(1, 2); } catch (Throwable $e) { $len = mt_rand(1, 2); }
        $part = '';
        for ($i = 0; $i < $len; $i++) {
            try { $idx = random_int(0, 25); } catch (Throwable $e) { $idx = mt_rand(0, 25); }
            $part .= chr(97 + $idx);
        }
        return $part;
    }
}

if (!function_exists('bm_dl_pretty_xid')) {
    function bm_dl_pretty_xid(): string
    {
        try {
            return 'BM-' . strtoupper(bin2hex(random_bytes(5)));
        } catch (Throwable $e) {
            return 'BM-' . strtoupper(substr(hash('sha256', microtime(true) . mt_rand()), 0, 10));
        }
    }
}

if (!function_exists('bm_dl_wrap_url')) {
    function bm_dl_wrap_url($url, int $ttl = 21600, string $archiveId = '', bool $failClosed = false): string
    {
        $url = trim((string)$url);
        if (array_key_exists('bmArchiveDownloadAllowed', $GLOBALS) && !$GLOBALS['bmArchiveDownloadAllowed']) return '#download-locked';
        $archiveId = bm_dl_resolve_archive_id($archiveId);
        if ($url === '' || !bm_dl_is_http_url($url)) return $failClosed ? '' : $url;
        if (bm_dl_is_own_redirect($url, $archiveId)) return $url;
        if (bm_dl_redirect_disabled()) return $failClosed ? '' : $url;
        $token = bm_dl_token_for_url($url, $ttl, $archiveId);
        if (!is_string($token) || $token === '') return $failClosed ? '' : $url;

        $decoded = bm_dl_decode_token($token);
        $exp = is_array($decoded) ? (int)($decoded['exp'] ?? 0) : 0;
        if ($exp <= time()) return $failClosed ? '' : $url;

        $filename = bm_dl_pretty_filename($url);
        [$edgeFolder, $innerFolder] = bm_dl_stable_route_parts($url);
        $path = '/' . $edgeFolder . '/' . bm_dl_media_bucket($url) . '/' . $innerFolder . '/' . rawurlencode($filename);
        $query = http_build_query([
            'xid' => bm_dl_pretty_xid(),
            'expires' => $exp,
            'sig' => $token,
        ], '', '&', PHP_QUERY_RFC3986);

        return bm_dl_redirect_base($archiveId, bm_dl_content_key($url)) . $path . '?' . $query;
    }
}

if (!function_exists('bm_dl_wrap_payload')) {
    /**
     * Give media rows two deliberately separate routes:
     *
     * - url / stream_url: the original media URL used only by the player.
     * - download_url: BankMovie's signed, remotely controlled download route.
     *
     * Keeping the stream URL intact is important because sending the redirect
     * endpoint into ExoPlayer breaks range requests on a number of hosts.
     */
    function bm_dl_wrap_payload($value, bool $downloadContext = false, string $archiveId = '', bool $failClosed = false)
    {
        if (!is_array($value)) return $value;
        $archiveId = bm_dl_resolve_archive_id($archiveId);
        $isList = array_is_list($value);
        if ($isList) {
            foreach ($value as $i => $item) $value[$i] = bm_dl_wrap_payload($item, $downloadContext, $archiveId, $failClosed);
            return $value;
        }

        $keys = array_keys($value);
        $looksLikeDownloadItem = $downloadContext
            || array_key_exists('is_download', $value)
            || array_key_exists('media_type', $value) && (array_key_exists('quality', $value) || array_key_exists('season', $value) || array_key_exists('episode', $value));

        $downloadContainers = [
            'downloads','download_links','downloadLinks','links','movie_links','series_links',
            'dubbed_links','softsub_links','hardsub_links','audio_links','play_links','seasons','episodes'
        ];
        $directDownloadKeys = ['dub_link','soft_link','download_url','download_link','subtitle_download_url'];

        foreach ($keys as $key) {
            $v = $value[$key];
            if (in_array($key, $directDownloadKeys, true) && is_string($v)) {
                $value[$key] = bm_dl_wrap_url($v, 21600, $archiveId, $failClosed);
                continue;
            }
            if ($looksLikeDownloadItem && $key === 'url' && is_string($v)) {
                if (!isset($value['stream_url']) || trim((string)$value['stream_url']) === '') {
                    $value['stream_url'] = $v;
                }
                if (!isset($value['download_url']) || trim((string)$value['download_url']) === '') {
                    $value['download_url'] = bm_dl_wrap_url($v, 21600, $archiveId, $failClosed);
                }
                $value['download_allowed'] = trim((string)($value['download_url'] ?? '')) !== '';
                continue;
            }
            if ($looksLikeDownloadItem && $key === 'href' && is_string($v)) {
                $value['download_url'] = bm_dl_wrap_url($v, 21600, $archiveId, $failClosed);
                $value['download_allowed'] = trim((string)$value['download_url']) !== '';
                continue;
            }
            if ($looksLikeDownloadItem && $key === 'subtitle_url' && is_string($v)) {
                $value['subtitle_download_url'] = bm_dl_wrap_url($v, 21600, $archiveId, $failClosed);
                continue;
            }
            if (is_array($v)) {
                $childContext = $looksLikeDownloadItem || in_array($key, $downloadContainers, true);
                $value[$key] = bm_dl_wrap_payload($v, $childContext, $archiveId, $failClosed);
            }
        }
        return $value;
    }
}
