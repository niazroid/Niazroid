#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
PLAYER="$ROOT/app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt"
MANIFEST="$ROOT/app/src/main/AndroidManifest.xml"
GRADLE="$ROOT/app/build.gradle"

for f in "$MAIN" "$PLAYER" "$MANIFEST" "$GRADLE"; do test -s "$f"; done

# Inherit all Phase 11 feature checks, but replace the old invalid GridLayout gravity guard.
# Latest-update badge: standalone, compact and above info card.
grep -F 'private fun detailLatestUpdatePill(item: JSONObject)' "$MAIN" >/dev/null
grep -F 'persianDigits(cleaned)' "$MAIN" >/dev/null
grep -F 'setImageResource(R.drawable.ic_status_update_arrow)' "$MAIN" >/dev/null
python3 - "$MAIN" <<'PY'
from pathlib import Path
import sys
s=Path(sys.argv[1]).read_text(encoding='utf-8')
hero=s.index('page.addView(hero)')
pill=s.index('detailLatestUpdatePill(item)?.let', hero)
info=s.index('page.addView(detailMoreInfoCard(item)', pill)
assert hero < pill < info, 'update pill must be standalone between hero and more-info card'
PY

# Recommendations/download header cleanup.
grep -F 'addJsonRail(page, "پیشنهاد فیلم", related, showMore = false)' "$MAIN" >/dev/null
grep -F 'addJsonRail(page, t("پیشنهاد فیلم", "Recommended"), related, showMore = false)' "$MAIN" >/dev/null
! grep -F 'text = "باکس دانلود"' "$MAIN" >/dev/null

# Collection mobile grid: explicit compact bounded dimensions and valid centering via LayoutParams.
grep -F 'coerceIn(dp(118), dp(154))' "$MAIN" >/dev/null
grep -F 'val cellHeight = (cellWidth * 1.38f).roundToInt()' "$MAIN" >/dev/null
grep -F 'page.addView(grid, LinearLayout.LayoutParams(if (tv) -1 else -2, -2).apply {' "$MAIN" >/dev/null
grep -F 'if (!tv) gravity = Gravity.CENTER_HORIZONTAL' "$MAIN" >/dev/null
! grep -F 'gravity = if (tv) Gravity.NO_GRAVITY else Gravity.CENTER_HORIZONTAL' "$MAIN" >/dev/null

# sectionHeader compile regression: all trailing-lambda call sites must bind explicitly to `more`.
grep -F 'sectionHeader(title, more = { showLocalList(title, storeKey, emptyText) })' "$MAIN" >/dev/null
grep -F 'sectionHeader("کالکشن‌ها", more = { showCollections() })' "$MAIN" >/dev/null
grep -F 'sectionHeader(title, more = { showList(title, archive, section) })' "$MAIN" >/dev/null
grep -F 'sectionHeader("بازیگران", more = { })' "$MAIN" >/dev/null

# Slider: only bottom corners are clipped.
grep -F 'private fun applyBottomCornerClip(view: View, radiusDp: Int)' "$MAIN" >/dev/null
grep -F 'applyBottomCornerClip(frame, 18)' "$MAIN" >/dev/null

# One CC control remains; Google Cast is intentionally removed.
grep -F 'private fun ccAudioSubtitleButton(click: () -> Unit): View' "$PLAYER" >/dev/null
grep -F 'text = "CC"' "$PLAYER" >/dev/null
grep -E '(actions|playerTopActions)\.addView\(ccAudioSubtitleButton \{ showAudioSubtitleSettingsSheet\(\) \}' "$PLAYER" >/dev/null
grep -F 'import android.graphics.drawable.GradientDrawable' "$PLAYER" >/dev/null
! grep -F 'CastButtonFactory' "$PLAYER" >/dev/null
! grep -F 'com.google.android.gms.cast.framework.OPTIONS_PROVIDER_CLASS_NAME' "$MANIFEST" >/dev/null
! grep -F 'play-services-cast-framework' "$ROOT/app/build.gradle" >/dev/null

# PiP remains; old standalone quality action stays absent.
grep -F 'simplePlayerIcon(R.drawable.ic_player_pip)' "$PLAYER" >/dev/null
! grep -F 'actions.addView(simplePlayerIcon(R.drawable.ic_player_quality)' "$PLAYER" >/dev/null

# Legacy APK compatibility.
echo '6ef23c64a58ffeb0f60d431f5ccfb7fcdbd75295e1a125b2ce075e0ea0c680e0  '"$ROOT"'/server-required/api5.php' | sha256sum -c - >/dev/null
echo '9a3357dfda36fe0548ee0049339f56a642c4727122a0c4ffc87b7cdf057ddfdb  '"$ROOT"'/server-required/api5_lib.php' | sha256sum -c - >/dev/null

if command -v php >/dev/null; then
  php -l "$ROOT/server-required/app_api.php" >/dev/null
  php -l "$ROOT/server-required/app_user_api.php" >/dev/null
fi
python3 - "$MANIFEST" <<'PY'
import sys, xml.etree.ElementTree as ET
ET.parse(sys.argv[1])
PY

echo PHASE11_1_VERIFY_OK
