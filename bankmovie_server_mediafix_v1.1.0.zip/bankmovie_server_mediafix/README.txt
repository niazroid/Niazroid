BankMovie Desktop Unauthorized hotfix
====================================

علت خطا:
نسخه قبلی Windows برای درخواست‌های content:request هدرهای HMAC را نمی‌فرستاد، در حالی که app_api.php همه درخواست‌ها را امضاشده می‌خواهد.

فایل‌های سمت سایت که باید به‌روز شوند:
1) includes/desktop_app_auth.php
2) app_api.php  (نسخه patch شده داخل server hotfix)
3) app_user_api.php باید patch قبلی Desktop را داشته باشد.
4) desktop_api.php همان facade قبلی است.

روش پیشنهادی بدون overwrite کامل app_api.php:
php tools/patch_app_api_desktop_auth.php /path/to/public_html
php tools/patch_app_user_api.php /path/to/public_html

سپس نسخه Windows را با سورس جدید rebuild کن، چون EXE قبلی content API را بدون امضا صدا می‌زند.

تست بعد از آپلود سرور:
cd desktop
node tools/test-content-api.js

نکته: باز کردن مستقیم desktop_api.php در مرورگر بدون هدرهای امضا می‌تواند 401 بدهد و این طبیعی است.
