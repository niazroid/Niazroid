<?php
declare(strict_types=1);
// Stable Windows facade. Content logic stays in app_api.php so Android and
// Windows receive the same normalized cards/details/archive policy.
$_SERVER['HTTP_X_BM_CLIENT']='windows';
$_SERVER['HTTP_X_BM_DOWNLOAD_SYSTEM']='2';
require __DIR__.'/app_api.php';
