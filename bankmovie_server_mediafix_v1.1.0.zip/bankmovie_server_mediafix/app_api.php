<?php
/**
 * app_api.php — API سبک مخصوص اپ اندروید BankMoviee
 * نسخه ۲.۱: تمرکز اصلی روی آرشیو ۱ + Boot/Slider/Collections/Pagination/Live Search
 *
 * Examples:
 *   app_api.php?action=ping
 *   app_api.php?action=home&archive=all
 *   app_api.php?action=section&archive=1&section=new_movies&page=1
 *   app_api.php?action=section&archive=3&section=new_series&page=1
 *   app_api.php?action=search&archive=all&q=from&type=series&page=1
 *   app_api.php?action=detail&archive=1&id=SERIES_OR_MOVIE_SLUG&type=series
 *   app_api.php?action=detail&archive=3&id=tt9813792
 *   app_api.php?action=play&archive=3&id=tt9813792
 */

@ini_set('display_errors', 0);
@ini_set('log_errors', 1);
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/app_archive_policy.php';
require_once __DIR__ . '/includes/download_redirect.php';
require_once __DIR__ . '/includes/notification_retention.php';
require_once __DIR__ . '/includes/app_push_notifications.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With, X-BM-App-Key, X-BM-Ts, X-BM-Sign, X-BM-User-Token, X-BM-Client-Version, X-BM-Client, X-BM-Download-System');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}


const BM_APP_AUTH_KEY = 'bm_android_v1_7c2f40';
const BM_APP_AUTH_SECRET = '9e1d4a7b3167f4c9b2d83f0a64e597f3d7f4b1a72638f90c6e2f2bd29d6aa8c1';
require_once __DIR__ . '/includes/desktop_app_auth.php';
const BM_TEST_KEY = 'bm_test_archive2_db_v7_2026';

function bm_app_header_value($name) {
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    return isset($_SERVER[$key]) ? trim((string)$_SERVER[$key]) : '';
}

function bm_app_require_auth() {
    if (isset($_GET['bm_test_key']) && hash_equals(BM_TEST_KEY, (string)$_GET['bm_test_key'])) return;

    $key = bm_app_header_value('X-BM-App-Key');
    $ts = bm_app_header_value('X-BM-Ts');
    $sign = bm_app_header_value('X-BM-Sign');

    $secret = null;
    if (hash_equals(BM_APP_AUTH_KEY, $key)) {
        $secret = BM_APP_AUTH_SECRET;
    } elseif (defined('BM_DESKTOP_APP_KEY') && defined('BM_DESKTOP_APP_SECRET') && hash_equals(BM_DESKTOP_APP_KEY, $key)) {
        $secret = BM_DESKTOP_APP_SECRET;
    }

    if ($secret === null || $ts === '' || $sign === '') {
        bm_app_json(array('status' => 'error', 'message' => 'Unauthorized'), 401);
    }

    $tsi = (int)$ts;
    if ($tsi < time() - 900 || $tsi > time() + 900) {
        bm_app_json(array('status' => 'error', 'message' => 'Expired request'), 401);
    }

    $uri = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '';
    $path = parse_url($uri, PHP_URL_PATH);
    $query = parse_url($uri, PHP_URL_QUERY);
    $pathQuery = $path . ($query ? ('?' . $query) : '');
    $expected = hash_hmac('sha256', $ts . '|' . $pathQuery, $secret);

    if (!hash_equals($expected, $sign)) {
        bm_app_json(array('status' => 'error', 'message' => 'Bad signature'), 401);
    }
}

bm_app_require_auth();

// V7.46.4 explicit client capability gate. Public/older 2.2 builds do not send
// X-BM-Download-System and therefore remain on the original download URLs.
$GLOBALS['bmDownloadModernClient'] = function_exists('bm_archive_request_is_modern_download_client')
    ? bm_archive_request_is_modern_download_client()
    : false;
$GLOBALS['bmDownloadLegacyCompat'] = function_exists('bm_archive_download_modern_client_only')
    && bm_archive_download_modern_client_only()
    && !$GLOBALS['bmDownloadModernClient'];

// The archive scraper libraries are optional runtimes, not global boot dependencies.
// One damaged/disabled/down archive must never take app_api.php or Android startup down.
function bm_app_try_require_site_lib($name) {
    static $state = array();
    if (isset($state[$name])) return $state[$name];
    foreach (array(__DIR__ . '/' . $name, __DIR__ . '/includes/' . $name) as $candidate) {
        if (!is_file($candidate)) continue;
        try {
            require_once $candidate;
            $state[$name] = true;
            return true;
        } catch (Throwable $e) {
            error_log('BankMovie archive runtime failed [' . $name . ']: ' . $e->getMessage());
            $state[$name] = false;
            return false;
        }
    }
    error_log('BankMovie archive runtime missing: ' . $name);
    $state[$name] = false;
    return false;
}

function bm_app_archive_id_key($archive) {
    $a = strtolower(trim((string)$archive));
    if (in_array($a, array('2','archive2','db','local','database','collection'), true)) return 'archive2';
    if (in_array($a, array('3','archive3','arc3'), true)) return 'archive3';
    if (in_array($a, array('4','archive4','arc4','serialblog','sb'), true)) return 'archive4';
    if (in_array($a, array('5','archive5','arc5'), true)) return 'archive5';
    return 'archive1';
}

function bm_app_archive_runtime_ready($archive) {
    $key = bm_app_archive_id_key($archive);
    if (function_exists('bm_app_archive_is_enabled') && !bm_app_archive_is_enabled($key)) return false;
    if ($key === 'archive2') return true;
    $lib = $key === 'archive3' ? 'api6_lib.php' : ($key === 'archive4' ? 'api4_lib.php' : ($key === 'archive5' ? 'api5_archive5_lib.php' : 'api2_lib.php'));
    return bm_app_try_require_site_lib($lib);
}

function bm_app_archive_unavailable_payload($archive, $action = '', $message = 'archive_source_unavailable') {
    $number = (int)preg_replace('/\D+/', '', bm_app_archive_id_key($archive));
    return array(
        'status' => 'degraded',
        'action' => (string)$action,
        'archive' => $number,
        'source_unavailable' => true,
        'message' => $message,
        'items' => array(),
        'movies' => array(),
        'results' => array(),
        'sections' => array(),
        'has_more' => false,
        'next_page' => null
    );
}

function bm_app_safe_section($archive, $section, $page, $limit) {
    if (!bm_app_archive_runtime_ready($archive)) {
        $out = bm_app_archive_unavailable_payload($archive, 'section');
        $out['section'] = (string)$section;
        $out['page'] = (int)$page;
        return $out;
    }
    try {
        return bm_app_section($archive, $section, $page, $limit);
    } catch (Throwable $e) {
        error_log('BankMovie archive section failed [' . $archive . '/' . $section . ']: ' . $e->getMessage());
        $out = bm_app_archive_unavailable_payload($archive, 'section');
        $out['section'] = (string)$section;
        $out['page'] = (int)$page;
        return $out;
    }
}

function bm_app_safe_search($archive, $q, $type, $page, $limit) {
    if (!bm_app_archive_runtime_ready($archive)) {
        $out = bm_app_archive_unavailable_payload($archive, 'search');
        $out['query'] = (string)$q;
        $out['page'] = (int)$page;
        $out['count'] = 0;
        $out['total'] = 0;
        $out['total_count'] = 0;
        return $out;
    }
    try {
        return bm_app_search_archive($archive, $q, $type, $page, $limit);
    } catch (Throwable $e) {
        error_log('BankMovie archive search failed [' . $archive . ']: ' . $e->getMessage());
        $out = bm_app_archive_unavailable_payload($archive, 'search');
        $out['query'] = (string)$q;
        $out['page'] = (int)$page;
        $out['count'] = 0;
        $out['total'] = 0;
        $out['total_count'] = 0;
        return $out;
    }
}

function bm_app_param($key, $default = '') {
    if (isset($_GET[$key])) return trim((string)$_GET[$key]);
    if (isset($_POST[$key])) return trim((string)$_POST[$key]);
    return $default;
}

function bm_app_int($key, $default = 1, $min = 1, $max = 1000) {
    $v = (int)bm_app_param($key, $default);
    if ($v < $min) $v = $min;
    if ($v > $max) $v = $max;
    return $v;
}

function bm_app_json($data, $code = 200) {
    $archive = strtolower(bm_app_param('archive', '1'));
    $archiveMap = array('1'=>'archive1','arc1'=>'archive1','2'=>'archive2','db'=>'archive2','local'=>'archive2','serialblog'=>'archive2','3'=>'archive3','arc3'=>'archive3','4'=>'archive4','arc4'=>'archive4','5'=>'archive5','arc5'=>'archive5');
    $action = strtolower(bm_app_param('action', bm_app_param('fn', 'home')));
    if ($action === 'debug_links') $archive = '2';
    $payloadArchive = is_array($data) ? (string)($data['archive'] ?? ($data['item']['archive'] ?? '')) : '';
    if ($payloadArchive !== '' && isset($archiveMap[strtolower($payloadArchive)])) $archive = strtolower($payloadArchive);
    $archiveActions = array('home','section','collections','collection','search','live_search','detail','play','debug_links','actor');
    if ($code < 400 && in_array($action, $archiveActions, true) && isset($archiveMap[$archive]) && function_exists('bm_app_archive_apply_payload_policy')) {
        $managedArchiveId = $archiveMap[$archive];
        $viewer = bm_app_current_user();
        if ($action !== 'ping' && (!bm_app_archive_is_enabled($managedArchiveId) || !bm_app_archive_user_can_access($managedArchiveId, $viewer))) {
            $data = array('status'=>'error', 'message'=>'این آرشیو در اپ در دسترس نیست.');
            $code = 404;
        }
        if ($code < 400 && function_exists('bm_app_archive_section_user_can_access')) {
            $managedSection = '';
            if ($action === 'section') $managedSection = bm_app_param('section', 'new_movies');
            elseif ($action === 'collections' || $action === 'collection') $managedSection = 'collections';
            if ($managedSection !== '' && !bm_app_archive_section_user_can_access($managedArchiveId, $managedSection, $viewer)) {
                $data = function_exists('bm_app_archive_section_state_payload')
                    ? array_merge(array('action'=>$action), bm_app_archive_section_state_payload($managedArchiveId, $managedSection, $viewer))
                    : array('status'=>'disabled','action'=>$action,'archive'=>(int)preg_replace('/\D+/', '', $managedArchiveId),'section'=>$managedSection,'items'=>array(),'movies'=>array(),'results'=>array(),'has_more'=>false);
                // Keep HTTP 200 so older app builds render an empty/locked section
                // instead of treating an admin switch as a network outage.
                $code = 200;
            }
        }
        // app_api.php is an Android surface. Build the managed download route
        // first, then apply the Android-only archive policy. This keeps download
        // gates fail-closed without allowing website policy to leak into the app.
        if (function_exists('bm_dl_wrap_payload')) $data = bm_dl_wrap_payload($data, false, $managedArchiveId, true);
        $data = bm_app_archive_apply_payload_policy($managedArchiveId, $data, $viewer, [
            'identifier'=>bm_app_param('id', bm_app_param('slug', bm_app_param('url', ''))),
        ]);
    }
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

function bm_app_fail($message, $code = 400, $extra = array()) {
    bm_app_json(array_merge(array(
        'status' => 'error',
        'message' => $message
    ), $extra), $code);
}

function bm_app_base_url() {
    // Relative assets follow the active secondary API host. bankmoviez.top is
    // the remote controller only and is never used as a content origin.
    $host = trim((string)($_SERVER['HTTP_HOST'] ?? ''));
    if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}(?::\d{1,5})?$/i', $host)) $host = 'bankmovie.top';
    return 'https://' . strtolower($host);
}

function bm_app_poster($poster) {
    if (is_array($poster)) {
        if (!empty($poster['full'])) return bm_app_abs_asset($poster['full']);
        if (!empty($poster['medium'])) return bm_app_abs_asset($poster['medium']);
        if (!empty($poster['url'])) return bm_app_abs_asset($poster['url']);
        return '';
    }
    return bm_app_abs_asset($poster);
}

function bm_app_rating_value($rating) {
    if (is_array($rating)) {
        if (isset($rating['imdb']) && is_numeric($rating['imdb'])) return (float)$rating['imdb'];
        if (isset($rating['value']) && is_numeric($rating['value'])) return (float)$rating['value'];
        return null;
    }
    return is_numeric($rating) ? (float)$rating : null;
}

function bm_app_feedback_satisfaction($item) {
    if (!is_array($item)) return null;
    if (isset($item['feedback_satisfaction']) && trim((string)$item['feedback_satisfaction']) !== '') {
        return trim((string)$item['feedback_satisfaction']);
    }
    $rating = $item['rating'] ?? null;
    if (is_array($rating) && isset($rating['feedback_satisfaction'])) {
        $value = trim((string)$rating['feedback_satisfaction']);
        return $value !== '' ? $value : null;
    }
    return null;
}

function bm_app_norm_type($type) {
    $t = strtolower(trim((string)$type));
    if ($t === 'tv' || $t === 'serial' || strpos($t, 'series') !== false) return 'series';
    if ($t === 'animation' || $t === 'animations') return 'anime';
    if ($t === '') return 'movie';
    return $t;
}

function bm_app_norm_audio_type($type, $label = '', $url = '') {
    // ترتیب تشخیص مهم است: لینک‌های SUB معمولاً عبارت Farsi.Sub دارند؛
    // پس اگر اول Farsi را دوبله حساب کنیم، همه زیرنویس‌ها اشتباه dub می‌شوند.
    $raw = trim((string)$type . ' ' . (string)$label . ' ' . (string)$url);
    $s = mb_strtolower(rawurldecode($raw), 'UTF-8');

    // مسیرهای رایج آرشیو ۱. NoSub MUST be checked first because the
    // Persian phrase "بدون زیرنویس" itself still contains "زیرنویس".
    if (preg_match('~/(nosub|no-sub)/~i', $url) || strpos($s, 'nosub') !== false || strpos($s, 'no-sub') !== false || strpos($s, 'بدون زیرنویس') !== false) return 'nosub';
    if (preg_match('~/(softsub|soft-sub)/~i', $url)) return 'softsub';
    if (preg_match('~/(hardsub|hard-sub)/~i', $url)) return 'hardsub';
    if (preg_match('~/(sub|subtitle)/~i', $url)) return 'subtitle';
    if (preg_match('~/(dub|dubbed|farsi\.dubbed)/~i', $url)) return 'dub';

    // نام فایل‌ها و لیبل‌ها. Farsi.Sub در آرشیو ۱ سافت‌ساب است.
    if (strpos($s, 'farsi.sub') !== false || strpos($s, 'softsub') !== false || strpos($s, 'soft.sub') !== false || strpos($s, 'soft-sub') !== false || strpos($s, 'سافت ساب') !== false || strpos($s, 'سافت‌ساب') !== false) return 'softsub';
    if (strpos($s, 'hardsub') !== false || strpos($s, 'hard.sub') !== false || strpos($s, 'hard-sub') !== false || strpos($s, 'hard sub') !== false || strpos($s, 'هارد ساب') !== false || strpos($s, 'هاردساب') !== false) return 'hardsub';
    if (strpos($s, 'subtitle') !== false || strpos($s, '.sub.') !== false || strpos($s, ' sub.') !== false || strpos($s, 'زیرنویس') !== false) return 'subtitle';
    if (strpos($s, 'dubbed') !== false || strpos($s, '.dub.') !== false || strpos($s, ' dub.') !== false || strpos($s, 'دوبله') !== false) return 'dub';

    // Farsi به تنهایی معیار دوبله نیست؛ چون Farsi.Sub هم داریم.
    return 'subtitle';
}

function bm_app_quality_rank($q) {
    $q = strtolower((string)$q);
    if (strpos($q, '4k') !== false || strpos($q, '2160') !== false) return 60;
    if (strpos($q, '1080') !== false) return 50;
    if (strpos($q, '720') !== false) return 40;
    if (strpos($q, '480') !== false) return 30;
    if (strpos($q, '360') !== false) return 20;
    return 1;
}

function bm_app_local_url($archive, $id, $type = '') {
    $archive = bm_app_scalar_string($archive, array('archive','id','value'));
    $id = bm_app_scalar_string($id, array('id','slug','value'));
    $type = bm_app_scalar_string($type, array('type','value'));
    if ($id === '') return '';
    $url = 'movie.php?arc=' . rawurlencode($archive) . '&slug=' . rawurlencode($id);
    if ($type !== '') $url .= '&type=' . rawurlencode($type);
    return $url;
}



function bm_app_scalar_string($value, $preferredKeys = array()) {
    if ($value === null) return '';
    if (is_string($value) || is_int($value) || is_float($value)) {
        return trim((string)$value);
    }
    if (is_bool($value)) return $value ? '1' : '';
    if (is_object($value)) $value = (array)$value;
    if (!is_array($value)) return '';

    $keys = array_values(array_unique(array_merge(
        (array)$preferredKeys,
        array('url','full','medium','src','path','value','rendered','html','content','body','image','poster','backdrop','name','title')
    )));
    foreach ($keys as $key) {
        if (!array_key_exists($key, $value)) continue;
        $resolved = bm_app_scalar_string($value[$key], array());
        if ($resolved !== '') return $resolved;
    }
    foreach ($value as $child) {
        $resolved = bm_app_scalar_string($child, array());
        if ($resolved !== '') return $resolved;
    }
    return '';
}

function bm_app_first_nonempty($arr, $keys) {
    if (!is_array($arr)) return '';
    foreach ($keys as $k) {
        if (!array_key_exists($k, $arr)) continue;
        $value = bm_app_scalar_string($arr[$k], array('url','full','medium','src','path','value','rendered','html'));
        if ($value !== '') return $value;
    }
    return '';
}

function bm_app_archive1_page_base() {
    return defined('BASE_URL') ? rtrim((string)BASE_URL, '/') : 'https://www.oldtowns.top';
}

function bm_app_web_abs_url($url) {
    $url = bm_app_scalar_string($url, array('url','href','src','path','value'));
    $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($url === '') return '';
    if (strpos($url, '//') === 0) return 'https:' . $url;
    if (preg_match('~^https?://~i', $url)) return $url;
    if ($url[0] === '/') return bm_app_archive1_page_base() . $url;
    return bm_app_archive1_page_base() . '/' . ltrim($url, '/');
}

function bm_app_extract_backdrop_from_html($html) {
    $html = bm_app_scalar_string($html, array('html','content','rendered','body'));
    if ($html === '') return '';
    $candidates = array();

    if (preg_match_all('~<img\b[^>]*>~is', $html, $tags)) {
        foreach ($tags[0] as $tag) {
            if (!preg_match('~class=["\'][^"\']*(?:mb-coverimg|coverimg)[^"\']*["\']~i', $tag)) continue;
            if (preg_match('~\bsrc=["\']([^"\']+)["\']~i', $tag, $m)) $candidates[] = $m[1];
            if (preg_match('~\bdata-src=["\']([^"\']+)["\']~i', $tag, $m)) $candidates[] = $m[1];
        }
    }

    if (preg_match_all('~background(?:-image)?\s*:\s*url\((["\']?)([^)"\']+)\1\)~i', $html, $bg)) {
        foreach ($bg[2] as $u) {
            if (preg_match('~\.(webp|jpe?g|png)(?:[?#]|$)~i', $u)) $candidates[] = $u;
        }
    }

    foreach ($candidates as $u) {
        $abs = bm_app_web_abs_url($u);
        if ($abs !== '' && preg_match('~\.(webp|jpe?g|png)(?:[?#]|$)~i', $abs)) return $abs;
    }
    return '';
}

function bm_app_fill_archive1_backdrop($raw, $identifier = '', $type = '') {
    if (!is_array($raw)) return $raw;
    $existing = bm_app_first_nonempty($raw, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($existing !== '') return $raw;

    $urls = array();
    foreach (array('source_url','web_url','url','detail_url','canonical','page_url') as $k) {
        if (!empty($raw[$k])) $urls[] = (string)$raw[$k];
    }
    $identifier = trim((string)$identifier);
    if ($identifier !== '') {
        if (preg_match('~^https?://~i', $identifier)) {
            $urls[] = $identifier;
        } else {
            $clean = trim($identifier, '/');
            if ($clean !== '') {
                if (strpos($clean, '/') !== false) $urls[] = bm_app_archive1_page_base() . '/' . $clean . '/';
                if ($type === 'series') $urls[] = bm_app_archive1_page_base() . '/series/' . $clean . '/';
                $urls[] = bm_app_archive1_page_base() . '/' . $clean . '/';
            }
        }
    }

    $seen = array();
    foreach ($urls as $u) {
        $u = bm_app_web_abs_url($u);
        if ($u === '' || isset($seen[$u])) continue;
        $seen[$u] = true;
        try {
            $html = function_exists('getHtml') ? getHtml($u, 0) : @file_get_contents($u);
            $bg = bm_app_extract_backdrop_from_html($html);
            if ($bg !== '') {
                $raw['backdrop'] = $bg;
                $raw['backdrop_path'] = $bg;
                $raw['background'] = $bg;
                return $raw;
            }
        } catch (Throwable $e) {}
    }
    return $raw;
}


function bm_app_normalize_card($item, $archive) {
    $archive = (string)$archive;
    $id = (string)(isset($item['detail_id']) ? $item['detail_id'] : (isset($item['slug']) ? $item['slug'] : (isset($item['id']) ? $item['id'] : '')));
    $type = bm_app_norm_type(isset($item['type']) ? $item['type'] : 'movie');
    $title = (string)(isset($item['title']) ? $item['title'] : '');
    $titleFa = (string)(isset($item['title_fa']) ? $item['title_fa'] : (isset($item['full_title']) ? $item['full_title'] : ''));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $base = bm_app_base_url();
    $local = bm_app_local_url($archive, $id, $type);
    $backdropCandidate = bm_app_first_nonempty($item, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($backdropCandidate === '') $backdropCandidate = isset($item['image']) ? $item['image'] : (isset($item['poster']) ? bm_app_poster($item['poster']) : '');

    return array(
        'archive' => (int)$archive,
        'source' => $archive === '5' ? 'archive5' : ($archive === '4' ? 'archive4' : ($archive === '3' ? 'archive3' : ((string)$archive === '2' ? 'db_movies' : 'archive1'))),
        'id' => $id,
        'slug' => $id,
        'source_slug' => $id,
        'comment_archive' => (int)$archive,
        'comment_identity' => $id,
        'imdb_code' => isset($item['imdb_code']) ? $item['imdb_code'] : null,
        'title' => $title,
        'title_fa' => $titleFa,
        'year' => isset($item['year']) ? $item['year'] : null,
        'type' => $type,
        'poster' => bm_app_poster(isset($item['poster']) ? $item['poster'] : (isset($item['image']) ? $item['image'] : (isset($item['cover_image']) ? $item['cover_image'] : ''))),
        'backdrop' => bm_app_abs_asset($backdropCandidate),
        'backdrop_path' => bm_app_abs_asset($backdropCandidate),
        'background' => bm_app_abs_asset($backdropCandidate),
        'rating' => bm_app_rating_value(isset($item['rating']) ? $item['rating'] : null),
        'feedback_satisfaction' => bm_app_feedback_satisfaction($item),
        'likes' => bm_app_feedback_satisfaction($item),
        'genres' => isset($item['genres']) && is_array($item['genres']) ? array_values($item['genres']) : array(),
        'description' => isset($item['description']) ? $item['description'] : '',
        'update_note' => isset($item['update_note']) ? $item['update_note'] : (isset($item['note']) ? $item['note'] : ''),
        'has_dubbed' => bm_app_detect_dub_card($item),
        'has_subtitle' => bm_app_detect_sub_card($item),
        'has_online' => !empty($item['has_online']),
        'source_url' => isset($item['source_url']) ? $item['source_url'] : (isset($item['url']) ? $item['url'] : ''),
        'web_url' => $local,
        'web_url_abs' => $base ? ($base . '/' . $local) : $local,
        'api_detail' => 'app_api.php?action=detail&archive=' . rawurlencode($archive) . '&id=' . rawurlencode($id) . ($type ? '&type=' . rawurlencode($type) : ''),
        'api_play' => 'app_api.php?action=play&archive=' . rawurlencode($archive) . '&id=' . rawurlencode($id) . ($type ? '&type=' . rawurlencode($type) : '')
    );
}

function bm_app_normalize_download($dl) {
    $url = (string)(isset($dl['url']) ? $dl['url'] : bm_app_db_link_url($dl));
    $quality = (string)(isset($dl['quality']) ? $dl['quality'] : '');
    if ($quality === '' && preg_match('/(2160p|4K|1080p|720p|480p|360p)/i', $url, $m)) $quality = strtoupper($m[1]);
    $label = (string)(isset($dl['label']) ? $dl['label'] : '');
    $audioType = bm_app_norm_audio_type(isset($dl['type']) ? $dl['type'] : '', $label, $url);
    $looksPlayable = (bool)preg_match('~\.(mkv|mp4|avi|m3u8|mpd|mov|webm|ts)(?:[?#]|$)~i', $url);
    $isAudio = (bool)preg_match('~\.(mka|mp3|aac|m4a|ogg|wav|flac)(?:[?#]|$)~i', $url);
    $isHttp = (bool)preg_match('~^https?://~i', $url);
    $isFolder = !empty($dl['is_folder']) && (string)$dl['is_folder'] !== '0';
    $qualityOut = $quality !== '' ? strtoupper($quality) : 'Unknown';
    $typeFa = $audioType === 'dub' ? 'دوبله' : ($audioType === 'hardsub' ? 'هاردساب' : ($audioType === 'softsub' ? 'سافت‌ساب' : ($audioType === 'audio' ? 'صوت دوبله' : ($audioType === 'nosub' ? 'بدون زیرنویس' : 'زیرنویس'))));
    if ($isAudio) $typeFa = 'صوت دوبله';
    $season = isset($dl['season']) && $dl['season'] !== '' && $dl['season'] !== null ? (int)$dl['season'] : null;
    $episode = isset($dl['episode']) && $dl['episode'] !== '' && $dl['episode'] !== null ? (int)$dl['episode'] : null;
    $subtitleUrl = '';
    foreach (array('subtitle_url','subtitleUrl','subtitle','sub_url','subtitle_link') as $sk) {
        if (!empty($dl[$sk])) { $subtitleUrl = trim((string)$dl[$sk]); break; }
    }
    if ($subtitleUrl !== '' && !preg_match('~^https?://~i', $subtitleUrl)) $subtitleUrl = bm_app_abs_asset($subtitleUrl);
    $displayParts = array();
    if ($season !== null && $season > 0) $displayParts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $displayParts[] = 'قسمت ' . $episode;
    if ($qualityOut !== '') $displayParts[] = $qualityOut;
    $displayParts[] = $typeFa;
    return array(
        'label' => $label,
        'url' => $url,
        'quality' => $qualityOut,
        'type' => $audioType,
        'type_fa' => $typeFa,
        'display_label' => isset($dl['display_label']) && $dl['display_label'] !== '' ? (string)$dl['display_label'] : trim(implode(' • ', array_filter($displayParts))),
        'season' => $season,
        'episode' => $episode,
        'size' => isset($dl['size']) ? $dl['size'] : '',
        'subtitle_url' => $subtitleUrl,
        'has_external_subtitle' => $subtitleUrl !== '',
        'is_direct' => $isHttp || $looksPlayable || $isAudio,
        'is_download' => $isHttp,
        'is_folder' => $isFolder,
        'is_playable' => $looksPlayable || $isAudio,
        'is_audio' => $isAudio || $audioType === 'audio'
    );
}


function bm_app_build_play_data($downloads) {
    $items = array();
    foreach ($downloads as $dl) {
        $n = bm_app_normalize_download($dl);
        if ($n['url'] === '') continue;
        $items[] = $n;
    }
    usort($items, function($a, $b) {
        $sa = $a['season'] === null ? 0 : (int)$a['season'];
        $sb = $b['season'] === null ? 0 : (int)$b['season'];
        if ($sa !== $sb) return $sa - $sb;
        $ea = $a['episode'] === null ? 0 : (int)$a['episode'];
        $eb = $b['episode'] === null ? 0 : (int)$b['episode'];
        if ($ea !== $eb) return $ea - $eb;
        return bm_app_quality_rank($b['quality']) - bm_app_quality_rank($a['quality']);
    });

    $seasonsMap = array();
    $movieLinks = array();
    foreach ($items as $n) {
        if ($n['season'] !== null || $n['episode'] !== null) {
            $s = $n['season'] !== null ? (string)$n['season'] : '1';
            $e = $n['episode'] !== null ? (string)$n['episode'] : '0';
            if (!isset($seasonsMap[$s])) $seasonsMap[$s] = array('season' => (int)$s, 'episodes' => array());
            if (!isset($seasonsMap[$s]['episodes'][$e])) $seasonsMap[$s]['episodes'][$e] = array('episode' => (int)$e, 'links' => array());
            $seasonsMap[$s]['episodes'][$e]['links'][] = $n;
        } else {
            $movieLinks[] = $n;
        }
    }

    $seasons = array_values($seasonsMap);
    foreach ($seasons as &$season) {
        ksort($season['episodes'], SORT_NATURAL);
        $season['episodes'] = array_values($season['episodes']);
    }
    unset($season);

    return array(
        'links' => $items,
        'movie_links' => $movieLinks,
        'seasons' => $seasons,
        'has_series_structure' => count($seasons) > 0
    );
}


function bm_app_abs_asset($path) {
    $raw = bm_app_scalar_string($path, array('url','full','medium','src','path','image','poster','backdrop','value'));
    if ($raw === '') return '';
    $raw = str_replace('\\', '/', html_entity_decode($raw, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    $base = bm_app_base_url();

    // Preserve genuinely external CDN/provider URLs. BankMovie-owned absolute
    // URLs are normalized through the same public-path rules as the website.
    if (preg_match('~^(?:https?:)?//~i', $raw)) {
        if (strpos($raw, '//') === 0) $raw = 'https:' . $raw;
        $parts = @parse_url($raw);
        $host = strtolower((string)($parts['host'] ?? ''));
        if ($host !== '' && !in_array($host, array('bankmoviez.top','www.bankmoviez.top','bankmovie.top','www.bankmovie.top'), true)) {
            return $raw;
        }
        $raw = (string)($parts['path'] ?? '/');
        if (!empty($parts['query'])) $raw .= '?' . $parts['query'];
        if (!empty($parts['fragment'])) $raw .= '#' . $parts['fragment'];
    }

    if (preg_match('~^(?:data|javascript|vbscript):~i', $raw)) return '';

    $fragment = '';
    if (($pos = strpos($raw, '#')) !== false) { $fragment = substr($raw, $pos); $raw = substr($raw, 0, $pos); }
    $query = '';
    if (($pos = strpos($raw, '?')) !== false) { $query = substr($raw, $pos); $raw = substr($raw, 0, $pos); }

    // Match includes/public_assets.php: old DB rows may contain cPanel/server
    // filesystem paths such as /home/.../public_html/uploads/... .
    if (preg_match('~/(?:public_html|htdocs)/(.*)$~i', $raw, $m)) {
        $raw = '/' . $m[1];
    } elseif (preg_match('~/www/(.*)$~i', $raw, $m)) {
        $raw = '/' . $m[1];
    }
    $raw = preg_replace('~^\\./+~', '', $raw);
    $segments = array();
    foreach (explode('/', ltrim($raw, '/')) as $segment) {
        if ($segment === '' || $segment === '.') continue;
        if ($segment === '..') { array_pop($segments); continue; }
        $segments[] = $segment;
    }
    if (!$segments) return '';
    return $base . '/' . implode('/', $segments) . $query . $fragment;
}

function bm_app_existing_local_poster($imdb) {
    $imdb = trim((string)$imdb);
    if ($imdb === '') return '';
    $file = __DIR__ . '/posters/' . basename($imdb) . '.webp';
    return is_file($file) ? ('posters/' . basename($imdb) . '.webp') : '';
}

function bm_app_text_has($text, $needles) {
    $text = mb_strtolower((string)$text, 'UTF-8');
    foreach ($needles as $n) {
        if ($n !== '' && mb_strpos($text, mb_strtolower($n, 'UTF-8')) !== false) return true;
    }
    return false;
}

function bm_app_boolish($value) {
    if (is_bool($value)) return $value;
    $v = mb_strtolower(trim((string)$value), 'UTF-8');
    return in_array($v, array('1','true','yes','on','active','dubbed','subbed','دوبله','زیرنویس','زیرنویس فارسی'), true);
}

function bm_app_detect_dub_card($item) {
    $text = '';
    foreach (array('title','title_fa','full_title','update_note','note','source_url','url') as $k) {
        if (isset($item[$k])) $text .= ' ' . rawurldecode((string)$item[$k]);
    }
    if (!empty($item['has_dubbed']) || !empty($item['is_dubbed']) || !empty($item['dubbed'])) return true;
    return bm_app_text_has($text, array('farsi-dubbed','farsi.dubbed','dubbed','دوبله'));
}

function bm_app_detect_sub_card($item) {
    $text = '';
    foreach (array('title','title_fa','full_title','update_note','note','source_url','url') as $k) {
        if (isset($item[$k])) $text .= ' ' . rawurldecode((string)$item[$k]);
    }
    if (!empty($item['has_subtitle']) || !empty($item['has_sub']) || !empty($item['subtitle'])) return true;
    return bm_app_text_has($text, array('subtitle','softsub','hardsub','subbed','زیرنویس'));
}

function bm_app_normalize_actor($actor) {
    if (is_array($actor)) {
        $name = trim((string)($actor['name'] ?? $actor['title'] ?? $actor['full_name'] ?? ''));
        if ($name === '' || $name[0] === '{') return null;
        return array(
            'name' => $name,
            'role' => trim((string)($actor['role'] ?? $actor['character'] ?? '')),
            'image' => bm_app_abs_asset($actor['image'] ?? $actor['poster'] ?? $actor['avatar'] ?? ''),
            'url' => bm_app_abs_asset($actor['url'] ?? ''),
            'slug' => trim((string)($actor['slug'] ?? '')),
            'bankmovie_url' => isset($actor['bankmovie_url']) ? (string)$actor['bankmovie_url'] : ''
        );
    }
    $name = trim((string)$actor);
    if ($name === '' || $name[0] === '{') return null;
    return array('name' => $name, 'role' => '', 'image' => '', 'url' => '', 'slug' => '', 'bankmovie_url' => '');
}

function bm_app_normalize_actors($actors) {
    if (!is_array($actors)) return array();
    $out = array();
    $seen = array();
    foreach ($actors as $a) {
        $n = bm_app_normalize_actor($a);
        if (!$n) continue;
        $key = mb_strtolower($n['name'], 'UTF-8');
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $n;
    }
    return $out;
}

function bm_app_pdo() {
    static $loaded = false;
    global $pdo;
    if (!$loaded) {
        $loaded = true;
        $cfg = __DIR__ . '/config.php';
        if (is_file($cfg)) require_once $cfg;
    }
    if (!(isset($pdo) && $pdo instanceof PDO)) return null;

    // Historical content schema label: 'vietop_bankmovie'. It is NOT auto-selected.
    // Archive 2 must be the *same database connection selected by the live
    // website config.php*. Do not scan information_schema or silently USE a
    // different schema: that was able to make Archive 2 look like another
    // archive on shared hosting. An explicit override remains available only
    // when the deployment deliberately defines BM_CONTENT_DATABASE.
    try { $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); } catch (Throwable $e) {}
    try { $pdo->exec("SET NAMES utf8mb4"); } catch (Throwable $e) {}
    if (defined('BM_CONTENT_DATABASE') && trim((string)BM_CONTENT_DATABASE) !== '') {
        $db = str_replace('`', '``', trim((string)BM_CONTENT_DATABASE));
        try { $pdo->exec('USE `' . $db . '`'); } catch (Throwable $e) {}
    }
    return $pdo;
}

function bm_app_user_token() {
    $direct = bm_app_header_value('X-BM-User-Token');
    if ($direct !== '') return $direct;
    $authorization = bm_app_header_value('Authorization');
    if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) return trim((string)$m[1]);
    return '';
}

function bm_app_current_user() {
    static $resolved = false;
    static $viewer = null;
    if ($resolved) return $viewer;
    $resolved = true;
    $token = bm_app_user_token();
    if ($token === '') return null;
    $pdo = bm_app_pdo();
    if (!$pdo || !class_exists('User')) return null;
    try {
        $candidate = (new User($pdo))->checkSession($token);
        if (is_array($candidate)) $viewer = $candidate;
    } catch (Throwable $e) {
        error_log('BankMovie app content session lookup failed: ' . $e->getMessage());
    }
    return $viewer;
}

function bm_app_is_db_archive($archive) {
    return in_array(strtolower(trim((string)$archive)), array('2','archive2','local','db','database','collection'), true);
}


function bm_app_is_serialblog_archive($archive) {
    return in_array(strtolower(trim((string)$archive)), array('4','serialblog','sb'), true);
}

function bm_app_serialblog_section_name($section) {
    $s = trim((string)$section);
    $map = array(
        'updated_movies' => 'new_movies',
        'new_movies' => 'new_movies',
        'movies' => 'new_movies',
        'movie' => 'new_movies',
        'updated_series' => 'new_series',
        'new_series' => 'new_series',
        'series' => 'new_series',
        'home' => 'home',
        'dubbed' => 'dubbed',
        'subtitled' => 'subtitled'
    );
    return isset($map[$s]) ? $map[$s] : $s;
}

function bm_app_serialblog_norm_item($m) {
    if (!is_array($m)) return null;
    $id = '';
    foreach (array('id','slug') as $k) {
        if (!empty($m[$k])) { $id = (string)$m[$k]; break; }
    }
    if ($id === '' && !empty($m['url']) && function_exists('serialblog_slug_from_url')) $id = serialblog_slug_from_url($m['url']);
    $title = (string)($m['title_fa'] ?? ($m['title'] ?? ($m['title_en'] ?? '')));
    if ($id === '' && $title === '') return null;
    $type = bm_app_norm_type((string)($m['type'] ?? 'movie'));
    if ($type !== 'series') $type = 'movie';
    $rating = $m['rating'] ?? ($m['imdb'] ?? '');
    $poster = bm_app_abs_asset((string)($m['poster'] ?? ($m['image'] ?? '')));
    $bg = bm_app_abs_asset((string)($m['backdrop'] ?? ($m['background'] ?? $poster)));
    return array(
        'archive' => 4,
        'source' => 'serialblog',
        'id' => $id,
        'slug' => $id,
        'movie_id' => $id,
        'type' => $type,
        'title' => (string)($m['title_en'] ?? ($m['title'] ?? $title)),
        'title_fa' => $title,
        'year' => (string)($m['year'] ?? ($m['release_year'] ?? '')),
        'poster' => $poster,
        'image' => $poster,
        'cover_image' => $poster,
        'backdrop' => $bg,
        'backdrop_path' => $bg,
        'background' => $bg,
        'imdb' => is_numeric($rating) ? (string)$rating : '',
        'rating' => $rating,
        'imdb_id' => (string)($m['imdb_id'] ?? ''),
        'genres' => isset($m['genres']) && is_array($m['genres']) ? array_values($m['genres']) : array(),
        'description' => (string)($m['description'] ?? ($m['plot'] ?? '')),
        'plot' => (string)($m['description'] ?? ($m['plot'] ?? '')),
        'url' => (string)($m['url'] ?? ($m['source_url'] ?? '')),
        'source_url' => (string)($m['source_url'] ?? ($m['url'] ?? '')),
        'has_dubbed' => !empty($m['has_dubbed']),
        'has_subtitle' => !empty($m['has_subtitle'])
    );
}

function bm_app_serialblog_norm_listing($raw, $page, $limit) {
    $items = array();
    $sourceItems = array();
    if (isset($raw['items']) && is_array($raw['items'])) $sourceItems = $raw['items'];
    elseif (isset($raw['movies']) && is_array($raw['movies'])) $sourceItems = $raw['movies'];
    foreach ($sourceItems as $m) {
        $n = bm_app_serialblog_norm_item($m);
        if ($n) $items[] = $n;
    }
    $hasMore = !empty($raw['has_more']) || !empty($raw['has_next_page']) || ((int)($raw['next_page'] ?? 0) > (int)$page);
    $next = isset($raw['next_page']) && (int)$raw['next_page'] > (int)$page ? (int)$raw['next_page'] : ($hasMore ? ((int)$page + 1) : null);
    return array(
        'archive' => 4,
        'source' => 'serialblog',
        'page' => (int)$page,
        'count' => count($items),
        'total' => (int)($raw['total'] ?? ($raw['total_count'] ?? count($items))),
        'total_count' => (int)($raw['total_count'] ?? ($raw['total'] ?? count($items))),
        'has_more' => $hasMore,
        'next_page' => $next,
        'items' => $items,
        'movies' => $items,
        'request_url' => (string)($raw['request_url'] ?? '')
    );
}

function bm_app_serialblog_link($d) {
    if (!is_array($d)) return null;
    $url = (string)($d['url'] ?? ($d['href'] ?? ''));
    if ($url === '') return null;
    $quality = (string)($d['quality'] ?? '');
    $label = (string)($d['label'] ?? ($d['title'] ?? ($d['text'] ?? '')));
    $type = (string)($d['type'] ?? '');
    $typeFa = (string)($d['type_fa'] ?? '');
    if ($typeFa === '') {
        if ($type === 'dubbed') $typeFa = 'دوبله فارسی';
        elseif ($type === 'nosub') $typeFa = 'بدون زیرنویس';
        elseif (in_array($type, array('softsub','hardsub','subtitle'), true)) $typeFa = 'زیرنویس فارسی';
        else $typeFa = 'لینک دانلود';
    }
    return array(
        'url' => $url,
        'quality' => $quality,
        'label' => $label,
        'display_label' => trim(($quality !== '' ? $quality : $label) . ' • ' . $typeFa),
        'type' => $type,
        'type_fa' => $typeFa,
        'version' => (string)($d['version'] ?? ''),
        'size' => (string)($d['size'] ?? ''),
        'season' => isset($d['season']) && $d['season'] !== null ? (int)$d['season'] : 0,
        'episode' => isset($d['episode']) && $d['episode'] !== null ? (int)$d['episode'] : 0,
        'is_direct' => true,
        'source' => 'serialblog'
    );
}

function bm_app_serialblog_detail($identifier, $type = '') {
    if (!function_exists('serialblog_get_details')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_get_details($identifier, $type);
    $movie = bm_app_serialblog_norm_item($raw['item'] ?? ($raw['movie'] ?? array()));
    if (!$movie) bm_app_fail('جزئیات آرشیو ۲ پیدا نشد', 404);
    $links = array();
    foreach (($raw['downloads'] ?? array()) as $d) {
        $l = bm_app_serialblog_link($d);
        if ($l) $links[] = $l;
    }
    $movie['downloads'] = $links;
    $movie['links'] = $links;
    $movie['play'] = array('links' => $links);
    return $movie;
}

function bm_app_serialblog_section($section, $page, $limit) {
    if (!function_exists('serialblog_get_section')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_get_section(bm_app_serialblog_section_name($section), $page);
    return bm_app_serialblog_norm_listing($raw, $page, $limit);
}

function bm_app_serialblog_search($q, $type, $page, $limit) {
    if (!function_exists('serialblog_search')) bm_app_fail('api5_lib.php موجود نیست', 500);
    $raw = serialblog_search(array('s' => $q, 'type' => $type, 'page' => $page));
    $res = bm_app_serialblog_norm_listing($raw, $page, $limit);
    if ($type === 'movie' || $type === 'series') {
        $filtered = array();
        foreach ($res['items'] as $it) {
            if (($type === 'series' && $it['type'] === 'series') || ($type === 'movie' && $it['type'] !== 'series')) $filtered[] = $it;
        }
        $res['items'] = $filtered;
        $res['movies'] = $filtered;
        $res['count'] = count($filtered);
    }
    return $res;
}

function bm_app_current_database_name() {
    $pdo = bm_app_pdo();
    if (!$pdo) return '';
    try { return (string)$pdo->query("SELECT DATABASE()")->fetchColumn(); } catch (Throwable $e) { return ''; }
}

function bm_app_slider_target($link) {
    $link = trim((string)$link);
    $out = array('target_archive'=>1, 'target_id'=>'', 'target_type'=>'movie', 'api_detail'=>'', 'api_play'=>'');
    if ($link === '') return $out;
    $parts = @parse_url($link);
    $query = array();
    if (!empty($parts['query'])) parse_str($parts['query'], $query);
    if (!empty($query['arc'])) $out['target_archive'] = (int)$query['arc'];
    if (!empty($query['type'])) $out['target_type'] = bm_app_norm_type($query['type']);
    if (!empty($query['slug'])) $out['target_id'] = (string)$query['slug'];
    if (!empty($query['imdb'])) $out['target_id'] = (string)$query['imdb'];

    $path = rawurldecode((string)($parts['path'] ?? $link));
    if ($out['target_id'] === '') {
        if (preg_match('~/movie/arc1-([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 1;
            $out['target_id'] = $m[1];
        } elseif (preg_match('~/movie/([^/?#]+)~i', $path, $m)) {
            $out['target_archive'] = 1;
            $out['target_id'] = $m[1];
        }
    }
    if ($out['target_id'] !== '') {
        $out['api_detail'] = 'app_api.php?action=detail&archive=' . rawurlencode((string)$out['target_archive']) . '&id=' . rawurlencode($out['target_id']) . '&type=' . rawurlencode($out['target_type']);
        $out['api_play'] = 'app_api.php?action=play&archive=' . rawurlencode((string)$out['target_archive']) . '&id=' . rawurlencode($out['target_id']) . '&type=' . rawurlencode($out['target_type']);
    }
    return $out;
}

function bm_app_normalize_slider($row) {
    $link = (string)($row['link'] ?? '');
    $target = bm_app_slider_target($link);
    return array_merge(array(
        'id' => (int)($row['id'] ?? 0),
        'title_fa' => (string)($row['title_fa'] ?? ''),
        'title' => (string)($row['title_en'] ?? ($row['title_fa'] ?? '')),
        'subtitle_fa' => (string)($row['subtitle_fa'] ?? ''),
        'subtitle' => (string)($row['subtitle_en'] ?? ''),
        'image' => bm_app_abs_asset($row['image_path'] ?? $row['image'] ?? ''),
        'link' => $link,
        'link_abs' => bm_app_abs_asset($link),
        'rating' => isset($row['rating']) ? round((float)$row['rating'], 1) : null,
        'votes' => (string)($row['votes'] ?? ''),
        'order' => (int)($row['slide_order'] ?? 0)
    ), $target);
}

function bm_app_sliders($limit = 12) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    try {
        $limit = max(1, min(30, (int)$limit));
        $sql = "SELECT * FROM slider_slides WHERE is_active = 1 ORDER BY slide_order DESC, id DESC LIMIT " . $limit;
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        return array_map('bm_app_normalize_slider', $rows ?: array());
    } catch (Throwable $e) {
        return array();
    }
}

function bm_app_normalize_collection($row) {
    $slug = (string)($row['slug'] ?? '');
    return array(
        'id' => (int)($row['id'] ?? 0),
        'slug' => $slug,
        'title_fa' => (string)($row['title_fa'] ?? ($row['title'] ?? '')),
        'title' => (string)($row['title'] ?? ($row['title_fa'] ?? '')),
        'description' => (string)($row['description'] ?? ''),
        'cover_image' => bm_app_abs_asset(bm_app_first_nonempty($row, array('cover_image','cover','image','poster','thumbnail','fallback_cover_image'))),
        'movie_count' => (int)($row['movie_count'] ?? 0),
        'first_year' => $row['first_year'] ?? null,
        'last_year' => $row['last_year'] ?? null,
        'web_url' => '/collection?slug=' . rawurlencode($slug),
        'api_items' => 'app_api.php?action=collection&slug=' . rawurlencode($slug)
    );
}

function bm_app_first_existing_column($table, $candidates) {
    $cols = bm_app_table_columns($table);
    foreach ((array)$candidates as $candidate) {
        if (in_array($candidate, $cols, true)) return $candidate;
    }
    return '';
}

function bm_app_collection_fallback_cover($collectionId) {
    $pdo = bm_app_pdo();
    if (!$pdo || !bm_app_table_exists('collection_movies') || !bm_app_table_exists('movies')) return '';
    $movieCols = bm_app_table_columns('movies');
    $cmCols = bm_app_table_columns('collection_movies');
    if (!in_array('movie_id', $cmCols, true) || !in_array('collection_id', $cmCols, true)) return '';

    $imageCol = bm_app_first_existing_column('movies', array('poster','poster_url','image','image_url','cover_image','cover','thumbnail'));
    $imdbCol = bm_app_first_existing_column('movies', array('imdb_code','imdb','imdb_id'));
    if ($imageCol === '' && $imdbCol === '') return '';

    $parts = array();
    if ($imageCol !== '') $parts[] = "NULLIF(TRIM(m.`$imageCol`), '')";
    if ($imdbCol !== '') $parts[] = "CASE WHEN TRIM(COALESCE(m.`$imdbCol`, '')) <> '' THEN CONCAT('posters/', TRIM(m.`$imdbCol`), '.webp') ELSE NULL END";
    if (in_array('id', $movieCols, true)) $parts[] = "CONCAT('posters/', m.id, '.webp')";
    $expr = 'COALESCE(' . implode(', ', $parts) . ", '')";

    $order = array();
    if (in_array('sort_order', $cmCols, true)) $order[] = 'cm.sort_order ASC';
    if (in_array('id', $movieCols, true)) $order[] = 'm.id ASC';
    $orderSql = $order ? (' ORDER BY ' . implode(', ', $order)) : '';
    try {
        $stmt = $pdo->prepare("SELECT $expr AS cover FROM collection_movies cm JOIN movies m ON cm.movie_id = m.id WHERE cm.collection_id = ?$orderSql LIMIT 1");
        $stmt->execute(array((int)$collectionId));
        return trim((string)$stmt->fetchColumn());
    } catch (Throwable $e) {
        return '';
    }
}

function bm_app_collections($page = 1, $limit = 12) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array('page'=>(int)$page,'limit'=>(int)$limit,'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array());
    $page = max(1, (int)$page); $limit = max(1, min(40, (int)$limit)); $offset = ($page - 1) * $limit;
    try {
        $collectionCols = bm_app_table_columns('collections');
        $movieCols = bm_app_table_columns('movies');
        $statusSql = in_array('status', $collectionCols, true) ? 'WHERE c.status = 1' : '';
        $yearCol = in_array('year', $movieCols, true) ? 'year' : (in_array('release_year', $movieCols, true) ? 'release_year' : '');
        $firstYear = $yearCol !== '' ? "MIN(m.`$yearCol`)" : 'NULL';
        $lastYear = $yearCol !== '' ? "MAX(m.`$yearCol`)" : 'NULL';
        $sql = "SELECT c.*, COUNT(cm.movie_id) AS movie_count, $firstYear AS first_year, $lastYear AS last_year
                FROM collections c
                LEFT JOIN collection_movies cm ON c.id = cm.collection_id
                LEFT JOIN movies m ON cm.movie_id = m.id
                $statusSql
                GROUP BY c.id
                ORDER BY c.id DESC
                LIMIT $limit OFFSET $offset";
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: array();
        foreach ($rows as &$row) {
            $cover = trim((string)($row['cover_image'] ?? ($row['cover'] ?? ($row['image'] ?? ''))));
            if ($cover === '') $row['fallback_cover_image'] = bm_app_collection_fallback_cover((int)($row['id'] ?? 0));
        }
        unset($row);
        $items = array_map('bm_app_normalize_collection', $rows);
        return array('page'=>$page,'limit'=>$limit,'count'=>count($items),'has_more'=>count($items)===$limit,'next_page'=>count($items)===$limit?$page+1:null,'items'=>$items);
    } catch (Throwable $e) {
        return array('page'=>$page,'limit'=>$limit,'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array(),'debug_error'=>$e->getMessage());
    }
}

function bm_app_extract_slug_from_url($url) {
    $url = trim((string)$url);
    if ($url === '') return '';
    $path = trim((string)(parse_url($url, PHP_URL_PATH) ?: ''), '/');
    if ($path === '') return '';
    $parts = array_values(array_filter(explode('/', $path), 'strlen'));
    if (empty($parts)) return '';
    if ($parts[0] === 'series' && !empty($parts[1])) return 'series/' . end($parts);
    if (ctype_digit($parts[0]) && count($parts) >= 2) return $parts[0] . '/' . end($parts);
    return end($parts);
}

function bm_app_normalize_db_movie($m) {
    $dbId = (int)($m['id'] ?? 0);
    $imdb = trim((string)($m['imdb_code'] ?? $m['imdb'] ?? ''));
    $sourceUrl = trim((string)($m['source_url'] ?? $m['url'] ?? $m['detail_url'] ?? $m['page_url'] ?? ''));
    $slug = trim((string)($m['detail_id'] ?? $m['source_slug'] ?? $m['slug'] ?? ''));
    if ($slug === '') $slug = bm_app_extract_slug_from_url($sourceUrl);
    $poster = (string)($m['poster'] ?? ($m['poster_url'] ?? ($m['image'] ?? ($m['image_url'] ?? ($m['cover_image'] ?? ($m['cover'] ?? ($m['thumbnail'] ?? '')))))));
    if ($poster === '') { $posterKey = $imdb !== '' ? $imdb : ($dbId > 0 ? (string)$dbId : ''); if ($posterKey !== '') $poster = 'posters/' . $posterKey . '.webp'; }
    $type = bm_app_norm_type($m['type'] ?? 'movie');
    $id = $dbId > 0 ? (string)$dbId : ($slug !== '' ? $slug : ($imdb !== '' ? $imdb : ''));
    $titleFa = (string)($m['title_fa'] ?? $m['title'] ?? '');
    $title = (string)($m['title'] ?? $titleFa);
    $text = implode(' ', array_map('strval', $m));
    return array(
        'archive' => 2,
        'source' => 'db_movies',
        'id' => $id,
        'db_id' => $dbId,
        'slug' => $slug,
        'source_slug' => $slug,
        'imdb_code' => $imdb ?: null,
        'title' => $title,
        'title_fa' => $titleFa,
        'year' => $m['year'] ?? null,
        'type' => $type,
        'poster' => bm_app_abs_asset($poster),
        'backdrop' => bm_app_abs_asset($m['backdrop'] ?? ($m['backdrop_url'] ?? ($m['background'] ?? ($m['background_url'] ?? '')))),
        'rating' => isset($m['imdb_rate']) && is_numeric($m['imdb_rate']) ? (float)$m['imdb_rate'] : (isset($m['rating']) && is_numeric($m['rating']) ? (float)$m['rating'] : null),
        'genres' => !empty($m['genres']) ? array_values(array_filter(array_map('trim', preg_split('/[,،]+/u', (string)$m['genres'])))) : array(),
        'description' => (string)($m['description_fa'] ?? $m['description'] ?? ''),
        'update_note' => (string)($m['update_note'] ?? ''),
        'has_dubbed' => !empty($m['_bm_has_dubbed']) || bm_app_detect_dub_card($m) || bm_app_text_has($text, array('دوبله','dubbed')),
        'has_subtitle' => !empty($m['_bm_has_subtitle']) || bm_app_detect_sub_card($m) || bm_app_text_has($text, array('زیرنویس','subtitle','subbed')),
        'source_url' => $sourceUrl,
        'web_url' => bm_app_local_url(2, $id, $type),
        'web_url_abs' => bm_app_abs_asset(bm_app_local_url(2, $id, $type)),
        'api_detail' => 'app_api.php?action=detail&archive=2&id=' . rawurlencode($id) . '&type=' . rawurlencode($type)
    );
}

function bm_app_collection_items($slugOrId, $page = 1, $limit = 24, $sort = 'default') {
    $pdo = bm_app_pdo();
    if (!$pdo) bm_app_fail('اتصال دیتابیس برای کالکشن آماده نیست', 500);
    $page = max(1, (int)$page); $limit = max(1, min(60, (int)$limit)); $offset = ($page - 1) * $limit;
    $where = ctype_digit((string)$slugOrId) ? 'id = ?' : 'slug = ?';
    $stmt = $pdo->prepare("SELECT * FROM collections WHERE $where AND status = 1 LIMIT 1");
    $stmt->execute(array($slugOrId));
    $collection = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$collection) bm_app_fail('کالکشن پیدا نشد', 404);
    $orderSql = 'ORDER BY cm.sort_order ASC, m.year ASC, m.id ASC';
    if ($sort === 'newest') $orderSql = 'ORDER BY m.year DESC, m.id DESC';
    if ($sort === 'oldest') $orderSql = 'ORDER BY m.year ASC, m.id ASC';
    $sql = "SELECT m.*, cm.sort_order, cm.movie_id AS collection_movie_id
            FROM collection_movies cm
            JOIN movies m ON cm.movie_id = m.id
            WHERE cm.collection_id = ?
            $orderSql
            LIMIT $limit OFFSET $offset";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array((int)$collection['id']));
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    $items = array();
    foreach ($rows as $r) {
        $card = bm_app_normalize_db_movie($r);
        $dbId = (int)($r['id'] ?? $r['collection_movie_id'] ?? 0);
        if ($dbId > 0) {
            $card['id'] = (string)$dbId;
            $card['db_id'] = $dbId;
            $card['movie_id'] = $dbId;
            $card['archive'] = 2;
            $card['source'] = 'db_movies';
            $card['api_detail'] = 'app_api.php?action=detail&archive=2&id=' . rawurlencode((string)$dbId) . '&type=' . rawurlencode($card['type']);
        }
        $items[] = $card;
    }
    return array('collection'=>bm_app_normalize_collection($collection),'page'=>$page,'limit'=>$limit,'count'=>count($items),'has_more'=>count($items)===$limit,'next_page'=>count($items)===$limit?$page+1:null,'items'=>$items);
}


function bm_app_normalize_detail($data, $archive) {
    $archive = (string)$archive;
    $id = (string)(isset($data['id']) ? $data['id'] : (isset($data['slug']) ? $data['slug'] : ''));
    $type = bm_app_norm_type(isset($data['type']) ? $data['type'] : 'movie');
    $title = (string)(isset($data['title']) ? $data['title'] : '');
    $titleFa = (string)(isset($data['title_fa']) ? $data['title_fa'] : (isset($data['full_title']) ? $data['full_title'] : ''));
    if ($title === '') $title = $titleFa;
    if ($titleFa === '') $titleFa = $title;
    $downloads = array();
    foreach (array('downloads','links','download_links','downloadLinks','dubbed_links','softsub_links','hardsub_links','audio_links','play_links') as $dk) {
        if (isset($data[$dk]) && is_array($data[$dk])) {
            foreach ($data[$dk] as $dl) if (is_array($dl)) $downloads[] = $dl;
        }
    }
    $play = bm_app_build_play_data($downloads);
    $base = bm_app_base_url();
    $local = bm_app_local_url($archive, $id, $type);
    $backdropCandidate = bm_app_first_nonempty($data, array('backdrop','backdrop_path','background','background_url','cover_bg','coverimg','mb_coverimg'));
    if ($backdropCandidate === '') $backdropCandidate = isset($data['image']) && $data['image'] !== '' ? $data['image'] : (isset($data['poster']) ? $data['poster'] : ((isset($data['imdb_code']) && $data['imdb_code'] !== '') ? bm_app_existing_local_poster($data['imdb_code']) : ''));

    return array(
        'archive' => (int)$archive,
        'source' => $archive === '5' ? 'archive5' : ($archive === '4' ? 'archive4' : ($archive === '3' ? 'archive3' : ((string)$archive === '2' ? 'db_movies' : 'archive1'))),
        'id' => $id,
        'slug' => $id,
        'source_slug' => $id,
        'comment_archive' => (int)$archive,
        'comment_identity' => $id,
        'imdb_code' => isset($data['imdb_code']) ? $data['imdb_code'] : null,
        'title' => $title,
        'title_fa' => $titleFa,
        'full_title' => isset($data['full_title']) ? $data['full_title'] : $titleFa,
        'year' => isset($data['year']) ? $data['year'] : null,
        'type' => $type,
        'poster' => bm_app_poster(isset($data['poster']) && $data['poster'] !== '' ? $data['poster'] : (isset($data['image']) && $data['image'] !== '' ? $data['image'] : ((isset($data['imdb_code']) && $data['imdb_code'] !== '') ? bm_app_existing_local_poster($data['imdb_code']) : ''))),
        'backdrop' => bm_app_abs_asset($backdropCandidate),
        'backdrop_path' => bm_app_abs_asset($backdropCandidate),
        'background' => bm_app_abs_asset($backdropCandidate),
        'rating' => bm_app_rating_value(isset($data['rating']) ? $data['rating'] : null),
        'feedback_satisfaction' => bm_app_feedback_satisfaction($data),
        'likes' => bm_app_feedback_satisfaction($data),
        'score' => isset($data['score']) ? $data['score'] : null,
        'runtime' => isset($data['runtime']) ? $data['runtime'] : (isset($data['duration']) ? $data['duration'] : ''),
        'age_rate' => isset($data['age_rate']) ? $data['age_rate'] : (isset($data['rated']) ? $data['rated'] : ''),
        'country' => isset($data['country']) ? $data['country'] : (isset($data['countries']) ? $data['countries'] : array()),
        'genres' => isset($data['genres']) && is_array($data['genres']) ? array_values($data['genres']) : array(),
        'description' => isset($data['description']) ? $data['description'] : '',
        'long_description' => isset($data['long_description']) ? $data['long_description'] : '',
        'status_text' => bm_app_first_nonempty($data, array('status_text','series_status','release_status','status')),
        'update_note' => bm_app_first_nonempty($data, array('update_note','episode_note','latest_status','last_status','last_update_note')),
        'latest_status' => bm_app_first_nonempty($data, array('update_note','episode_note','latest_status','last_status','last_update_note')),
        'language' => bm_app_first_nonempty($data, array('language','languages','lang')),
        'network' => bm_app_first_nonempty($data, array('network','network_name','tv_network','channel')),
        'production_companies' => bm_app_first_nonempty($data, array('production_companies','companies','studio')),
        'seasons' => isset($data['seasons']) ? $data['seasons'] : null,
        'episodes' => isset($data['episodes']) ? $data['episodes'] : null,
        'actors' => bm_app_normalize_actors(isset($data['actors']) ? $data['actors'] : (isset($data['cast']) ? $data['cast'] : array())),
        'directors' => bm_app_normalize_actors(isset($data['directors']) ? $data['directors'] : array()),
        'trailer' => isset($data['trailer']) ? $data['trailer'] : (isset($data['trailer_url']) ? $data['trailer_url'] : ''),
        'trailer_url' => isset($data['trailer']) ? $data['trailer'] : (isset($data['trailer_url']) ? $data['trailer_url'] : ''),
        'has_dubbed' => !empty($data['has_dubbed']) || bm_app_play_has_type($play, 'dub'),
        'has_subtitle' => !empty($data['has_subtitle']) || bm_app_play_has_sub($play),
        'has_online' => !empty($data['has_online']) || count($play['links']) > 0,
        'source_url' => isset($data['source_url']) ? $data['source_url'] : (isset($data['url']) ? $data['url'] : ''),
        'web_url' => $local,
        'web_url_abs' => $base ? ($base . '/' . $local) : $local,
        'downloads_count' => count($play['links']),
        'links' => $play['links'],
        'downloads' => $play['links'],
        'play' => $play,
        'related' => bm_app_normalize_related(isset($data['related_movies']) ? $data['related_movies'] : (isset($data['related']) ? $data['related'] : array()), $archive)
    );
}

function bm_app_play_has_type($play, $type) {
    foreach ($play['links'] as $l) if ($l['type'] === $type) return true;
    return false;
}

function bm_app_play_has_sub($play) {
    foreach ($play['links'] as $l) if (in_array($l['type'], array('subtitle','softsub','hardsub'), true)) return true;
    return false;
}

function bm_app_normalize_related($items, $archive) {
    if (!is_array($items)) return array();
    $out = array();
    foreach ($items as $it) {
        if (is_array($it)) $out[] = bm_app_normalize_card($it, $archive);
    }
    return $out;
}

function bm_app_archive1_section($section, $page) {
    $section = strtolower(trim((string)$section));
    $mapUpdatedMovies = array('updated_movies','new_movies','movie','movies','films_updated','updated-movies');
    $mapUpdatedSeries = array('updated_series','new_series','series','tv','series_updated','updated-series');
    if (in_array($section, $mapUpdatedMovies, true)) return getUpdatedList('movie', $page);
    if (in_array($section, $mapUpdatedSeries, true)) return getUpdatedList('series', $page);
    if ($section === 'anime' || $section === 'animation' || $section === 'animations') return getCategoryList('anime', $page);
    if ($section === 'turkish' || $section === 'turkey' || $section === 'turkish_series') return getCategoryList('turkish', $page);
    // Server-side fix only: existing app versions keep using the same endpoint.
    // All common dubbed aliases are routed to the corrected Archive 1 carousel.
    if (in_array($section, array('dubbed','dubbed-fa','persian_dubbed','persian-dubbed','dubbed_movies','dubbed-movies'), true)) return getDubbedMoviesList($page);
    if ($section === 'top_2026' || $section === 'top-2026') return getTop2026MoviesList($page);
    // Exact source used by the website category cards (view_all.php -> getCategoryList).
    if (in_array($section, array('top-movies','top_movies','top-250-movies','top_250_movies'), true)) return getCategoryList('top-movies', $page);
    if (in_array($section, array('top-series','top_series','top-250-series','top_250_series'), true)) return getCategoryList('top-series', $page);
    if ($section === 'archive_movies') return getArchiveList('movie', $page);
    if ($section === 'archive_series') return getArchiveList('series', $page);
    return getUpdatedList('movie', $page);
}

function bm_app_archive3_section($section, $page) {
    $section = trim((string)$section);
    if ($section === 'series' || $section === 'updated_series') $section = 'new_series';
    if ($section === 'movie' || $section === 'movies') $section = 'new_movies';
    if ($section === 'anime') $section = 'updated_anime';
    if ($section === 'animation' || $section === 'animations') $section = 'updated_animations';
    if (!function_exists('api6_section_params') || !function_exists('api6_search')) {
        throw new RuntimeException('Archive 3 api6 runtime unavailable');
    }
    $params = api6_section_params($section, $page);
    return api6_search($params);
}

function bm_app_archive5_section($section, $page, $limit = 24) {
    if (!function_exists('fitlinerim_get_section')) bm_app_fail('Archive 5 runtime unavailable', 500);
    return fitlinerim_get_section($section, $page, $limit);
}

function bm_app_archive4_section($section, $page) {
    $section = trim((string)$section);
    if ($section === 'series') $section = 'new_series';
    if ($section === 'movie' || $section === 'movies') $section = 'new_movies';
    if ($section === 'anime') $section = 'updated_anime';
    if ($section === 'animation' || $section === 'animations') $section = 'updated_animations';
    $params = api4_section_params($section, $page);
    $params['sort'] = 'newest';
    return api4_search($params);
}

function bm_app_section($archive, $section, $page, $limit = 24) {
    $archive = (string)$archive;
    if (bm_app_is_db_archive($archive)) {
        return bm_app_db_section($section, $page, $limit);
    }
    if ($archive === '5') $raw = bm_app_archive5_section($section, $page, $limit);
    elseif ($archive === '4') $raw = bm_app_archive4_section($section, $page);
    elseif ($archive === '3') $raw = bm_app_archive3_section($section, $page);
    else $raw = bm_app_archive1_section($section, $page);
    $movies = isset($raw['movies']) && is_array($raw['movies']) ? $raw['movies'] : array();
    $items = array();
    foreach ($movies as $it) {
        $items[] = bm_app_normalize_card($it, $archive);
        if ($limit > 0 && count($items) >= $limit) break;
    }
    return array(
        'archive' => (int)$archive,
        'section' => $section,
        'page' => isset($raw['page']) ? $raw['page'] : $page,
        'count' => count($items),
        'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']) || count($items) >= $limit,
        'next_page' => isset($raw['next_page']) ? $raw['next_page'] : (count($items) >= $limit ? ($page + 1) : null),
        'items' => $items,
        'pagination' => array(
            'page' => isset($raw['page']) ? (int)$raw['page'] : (int)$page,
            'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']),
            'next_page' => isset($raw['next_page']) ? $raw['next_page'] : null
        )
    );
}


function bm_app_db_search_movies($q, $type = '', $page = 1, $limit = 24, $filters = array()) {
    $pdo = bm_app_pdo();
    if (!$pdo || !bm_app_table_exists('movies')) return null;

    $page = max(1, (int)$page);
    $limit = max(1, min(80, (int)$limit));
    $offset = ($page - 1) * $limit;
    $filters = is_array($filters) ? $filters : array();

    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    $where = array();
    $params = array();

    $addLikeAny = function($columnCandidates, $needles) use (&$where, &$params, $cols) {
        $existing = array_values(array_filter($columnCandidates, function($c) use ($cols) { return in_array($c, $cols, true); }));
        $needles = is_array($needles) ? $needles : array($needles);
        $needles = array_values(array_filter(array_map(function($v) { return trim((string)$v); }, $needles), 'strlen'));
        if (!$existing || !$needles) return;
        $parts = array();
        foreach ($existing as $c) {
            foreach ($needles as $needle) {
                $parts[] = "`$c` LIKE ?";
                $params[] = '%' . $needle . '%';
            }
        }
        if ($parts) $where[] = '(' . implode(' OR ', $parts) . ')';
    };

    $q = trim((string)$q);
    if ($q !== '') {
        $addLikeAny(
            array('title','title_fa','original_title','title_en','imdb_code','imdb','slug','source_slug','detail_id'),
            array($q)
        );
    }

    $type = strtolower(trim((string)$type));
    if ($type !== '' && $type !== 'all' && in_array('type', $cols, true)) {
        if ($type === 'series' || $type === 'serial' || $type === 'tv') {
            $where[] = "(LOWER(`type`) LIKE '%series%' OR LOWER(`type`) IN ('serial','tv'))";
        } elseif ($type === 'movie' || $type === 'film') {
            $where[] = "(LOWER(`type`) IN ('movie','film') OR `type` IS NULL OR `type` = '')";
        } else {
            $where[] = "LOWER(`type`) = ?";
            $params[] = $type;
        }
    }

    $genre = trim((string)($filters['genre'] ?? ''));
    $genreAny = $filters['genre_any'] ?? array();
    if ($genre !== '') $genreAny = array_merge(is_array($genreAny) ? $genreAny : array(), array($genre));
    if ($genreAny) $addLikeAny(array('genres','genre','categories','category','tags'), $genreAny);

    $country = trim((string)($filters['country'] ?? ''));
    if ($country !== '') $addLikeAny(array('country','countries','country_name','production_country'), array($country));

    $yearCol = in_array('year', $cols, true) ? 'year' : (in_array('release_year', $cols, true) ? 'release_year' : '');
    $yearFrom = (int)($filters['year_from'] ?? 0);
    $yearTo = (int)($filters['year_to'] ?? 0);
    if ($yearCol !== '' && $yearFrom > 0) { $where[] = "CAST(`$yearCol` AS UNSIGNED) >= ?"; $params[] = $yearFrom; }
    if ($yearCol !== '' && $yearTo > 0) { $where[] = "CAST(`$yearCol` AS UNSIGNED) <= ?"; $params[] = $yearTo; }

    $ratingCol = in_array('imdb_rate', $cols, true) ? 'imdb_rate' : (in_array('rating', $cols, true) ? 'rating' : '');
    $ratingMin = (float)($filters['rating'] ?? 0);
    if ($ratingCol !== '' && $ratingMin > 0) {
        $where[] = "CAST(NULLIF(`$ratingCol`, '') AS DECIMAL(4,2)) >= ?";
        $params[] = $ratingMin;
    }

    $truthy = function($v) {
        if (is_bool($v)) return $v;
        $v = strtolower(trim((string)$v));
        return in_array($v, array('1','true','yes','on','y'), true);
    };
    if ($truthy($filters['dubbed'] ?? false)) {
        // The real Archive 2 catalog stores release availability in dubbed_links.
        // Prefer the relational source of truth over text guessing when possible.
        $dubCols = bm_app_table_exists('dubbed_links') ? bm_app_table_columns('dubbed_links') : array();
        if (in_array('movie_id', $dubCols, true) && in_array('id', $cols, true)) {
            $where[] = 'EXISTS (SELECT 1 FROM dubbed_links dl WHERE dl.movie_id = movies.id)';
        } else {
            $boolCols = array_values(array_filter(array('has_dubbed','dubbed','is_dubbed'), function($c) use ($cols) { return in_array($c, $cols, true); }));
            if ($boolCols) {
                $parts = array();
                foreach ($boolCols as $c) $parts[] = "COALESCE(`$c`, 0) <> 0";
                $where[] = '(' . implode(' OR ', $parts) . ')';
            } else {
                $addLikeAny(array('title','title_fa','description','description_fa','tags','genres'), array('دوبله','dubbed'));
            }
        }
    }
    if ($truthy($filters['subtitle'] ?? false)) {
        // Same for subtitle releases: softsub_links is authoritative in the site DB.
        $subCols = bm_app_table_exists('softsub_links') ? bm_app_table_columns('softsub_links') : array();
        if (in_array('movie_id', $subCols, true) && in_array('id', $cols, true)) {
            $where[] = 'EXISTS (SELECT 1 FROM softsub_links sl WHERE sl.movie_id = movies.id)';
        } else {
            $boolCols = array_values(array_filter(array('has_subtitle','subtitle','is_subtitle','softsub'), function($c) use ($cols) { return in_array($c, $cols, true); }));
            if ($boolCols) {
                $parts = array();
                foreach ($boolCols as $c) $parts[] = "COALESCE(`$c`, 0) <> 0";
                $where[] = '(' . implode(' OR ', $parts) . ')';
            } else {
                $addLikeAny(array('title','title_fa','description','description_fa','tags'), array('زیرنویس','subtitle','softsub'));
            }
        }
    }

    if (!$where) $where[] = '1=1';
    $whereSql = implode(' AND ', $where);

    $sort = strtolower(trim((string)($filters['sort'] ?? 'newest')));
    $idOrder = in_array('id', $cols, true) ? '`id` DESC' : '1';
    $updatedOrder = in_array('updated_at', $cols, true) ? '`updated_at` DESC' : (in_array('created_at', $cols, true) ? '`created_at` DESC' : $idOrder);
    if ($sort === 'oldest') {
        $order = in_array('created_at', $cols, true) ? '`created_at` ASC, `id` ASC' : ($yearCol !== '' ? "CAST(`$yearCol` AS UNSIGNED) ASC, `id` ASC" : '`id` ASC');
    } elseif (in_array($sort, array('year','year_desc','newest_year'), true) && $yearCol !== '') {
        $order = "CAST(`$yearCol` AS UNSIGNED) DESC, `id` DESC";
    } elseif (in_array($sort, array('rating','imdb','score'), true) && $ratingCol !== '') {
        $order = "CAST(NULLIF(`$ratingCol`, '') AS DECIMAL(4,2)) DESC, `id` DESC";
    } elseif (in_array($sort, array('title','name'), true)) {
        $titleCol = in_array('title', $cols, true) ? 'title' : (in_array('title_fa', $cols, true) ? 'title_fa' : 'id');
        $order = "`$titleCol` ASC, `id` DESC";
    } else {
        $order = $updatedOrder . (strpos($updatedOrder, '`id`') === false && in_array('id', $cols, true) ? ', `id` DESC' : '');
    }

    $extraSelect = '';
    $dubColsForSelect = bm_app_table_exists('dubbed_links') ? bm_app_table_columns('dubbed_links') : array();
    $subColsForSelect = bm_app_table_exists('softsub_links') ? bm_app_table_columns('softsub_links') : array();
    if (in_array('id', $cols, true) && in_array('movie_id', $dubColsForSelect, true)) {
        $extraSelect .= ', EXISTS (SELECT 1 FROM dubbed_links dlf WHERE dlf.movie_id = movies.id) AS _bm_has_dubbed';
    }
    if (in_array('id', $cols, true) && in_array('movie_id', $subColsForSelect, true)) {
        $extraSelect .= ', EXISTS (SELECT 1 FROM softsub_links slf WHERE slf.movie_id = movies.id) AS _bm_has_subtitle';
    }

    try {
        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM movies WHERE $whereSql");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $sql = "SELECT movies.*$extraSelect FROM movies WHERE $whereSql ORDER BY $order LIMIT $limit OFFSET $offset";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();

        $items = array();
        foreach ($rows as $r) $items[] = bm_app_normalize_db_movie($r);

        $hasMore = ($offset + count($items)) < $total;
        return array(
            'archive' => 2,
            'source' => 'db_movies',
            'page' => $page,
            'limit' => $limit,
            'query' => $q,
            'type' => $type,
            'total' => $total,
            'total_count' => $total,
            'count' => count($items),
            'has_more' => $hasMore,
            'next_page' => $hasMore ? ($page + 1) : null,
            'items' => $items,
            'pagination' => array(
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'has_more' => $hasMore,
                'next_page' => $hasMore ? ($page + 1) : null
            )
        );
    } catch (Throwable $e) {
        return null;
    }
}

function bm_app_db_genre_aliases($key) {
    $map = array(
        'action' => array('action','اکشن'),
        'drama' => array('drama','درام'),
        'comedy' => array('comedy','کمدی'),
        'horror' => array('horror','ترسناک'),
        'thriller' => array('thriller','هیجان انگیز','هیجان‌انگیز'),
        'romance' => array('romance','romantic','عاشقانه'),
        'scifi' => array('sci-fi','science fiction','علمی تخیلی','علمی‌تخیلی'),
        'science_fiction' => array('sci-fi','science fiction','علمی تخیلی','علمی‌تخیلی'),
        'fantasy' => array('fantasy','فانتزی'),
        'crime' => array('crime','جنایی'),
        'mystery' => array('mystery','معمایی'),
        'adventure' => array('adventure','ماجراجویی'),
        'family' => array('family','خانوادگی'),
        'documentary' => array('documentary','مستند'),
        'animation' => array('animation','anime','انیمیشن','انیمه'),
        'anime' => array('animation','anime','انیمیشن','انیمه')
    );
    $key = strtolower(trim((string)$key));
    return $map[$key] ?? array(str_replace('_',' ', $key));
}

function bm_app_db_section($section, $page = 1, $limit = 24) {
    $section = strtolower(trim((string)$section));
    $filters = array('sort' => 'newest');
    $type = '';

    if (strpos($section, 'genre_movie_') === 0) {
        $type = 'movie';
        $filters['genre_any'] = bm_app_db_genre_aliases(substr($section, strlen('genre_movie_')));
    } elseif (strpos($section, 'genre_series_') === 0) {
        $type = 'series';
        $filters['genre_any'] = bm_app_db_genre_aliases(substr($section, strlen('genre_series_')));
    } elseif (in_array($section, array('top_movies','top_250_movies','imdb_movies','best_movies'), true)) {
        $type = 'movie';
        $filters['sort'] = 'rating';
    } elseif (in_array($section, array('top_series','top_250_series','imdb_series','best_series'), true)) {
        $type = 'series';
        $filters['sort'] = 'rating';
    } elseif (in_array($section, array('updated_series','new_series','series','tv','series_updated','updated-series'), true)) {
        $type = 'series';
    } elseif (in_array($section, array('animation','animations','anime','updated_anime','updated_animations'), true)) {
        $filters['genre_any'] = bm_app_db_genre_aliases('animation');
    } elseif (in_array($section, array('dubbed','dubbed-fa','persian_dubbed','persian-dubbed','dubbed_movies','dubbed-movies'), true)) {
        $type = 'movie';
        $filters['dubbed'] = true;
    } elseif (in_array($section, array('subtitled','subtitle','softsub','subtitled_movies','subtitled-movies'), true)) {
        $type = 'movie';
        $filters['subtitle'] = true;
    } else {
        $type = 'movie';
        // Home section names such as action/drama are real genre sections,
        // not aliases for the generic movie list.
        if (in_array($section, array('action','drama','comedy','horror','thriller','romance','scifi','science_fiction','fantasy','crime','mystery','adventure','family','documentary'), true)) {
            $filters['genre_any'] = bm_app_db_genre_aliases($section);
        }
        if ($section === 'movies_2025_2026' || $section === 'recent_movies') {
            $filters['year_from'] = max(1900, ((int)date('Y')) - 1);
            $filters['year_to'] = (int)date('Y');
        }
    }

    $result = bm_app_db_search_movies('', $type, $page, $limit, $filters);
    if (!is_array($result)) {
        return array('archive'=>2,'section'=>$section,'page'=>$page,'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array());
    }
    $result['section'] = $section;
    return $result;
}


function bm_app_search_archive($archive, $q, $type, $page, $limit = 30) {
    $archive = (string)$archive;
    // Archive 2 is the site-owned vietop_bankmovie catalog.
    // Archive 1 remains isolated on its own source and must never consume these DB rows.
    if (bm_app_is_db_archive($archive)) {
        $filters = array(
            'genre' => bm_app_param('genre', ''),
            'country' => bm_app_param('country', ''),
            'year_from' => bm_app_param('year_from', bm_app_param('fromYear', bm_app_param('min_year', ''))),
            'year_to' => bm_app_param('year_to', bm_app_param('toYear', bm_app_param('max_year', ''))),
            'rating' => bm_app_param('rating', bm_app_param('rates', bm_app_param('imdbrate', ''))),
            'sort' => bm_app_param('sort', bm_app_param('sortby', 'newest')),
            'dubbed' => bm_app_param('dubbed', ''),
            'subtitle' => bm_app_param('subtitle', '')
        );
        $dbSearch = bm_app_db_search_movies($q, $type, $page, $limit, $filters);
        if (is_array($dbSearch)) return $dbSearch;
        // Strict Archive 2 isolation: never fall through to advancedSearch()
        // (Archive 1) when a DB query is unavailable or returns an error.
        return array(
            'archive'=>2,'source'=>'db_movies','page'=>$page,'query'=>$q,'type'=>$type,
            'count'=>0,'has_more'=>false,'next_page'=>null,'items'=>array()
        );
    }
    if ($archive === '5') {
        $genre = bm_app_param('genre', '');
        if (trim((string)$q) === '' && trim((string)$genre) !== '' && function_exists('fitlinerim_genre_id') && function_exists('fitlinerim_list')) {
            $rawItems = fitlinerim_list($type !== '' ? $type : 'all', $page, fitlinerim_genre_id($genre), $limit);
            $raw = array('page'=>$page, 'movies'=>$rawItems, 'items'=>$rawItems, 'has_more'=>count($rawItems) >= min(max(1,(int)$limit),20));
        } else {
            $raw = fitlinerim_search_result($q, $page, $type !== '' ? $type : 'all', $limit);
        }
    } elseif ($archive === '4') {
        $params = array(
            's' => $q,
            'type' => $type !== '' ? $type : 'all',
            'genre' => bm_app_param('genre', ''),
            'sort' => bm_app_param('sort', bm_app_param('sortby', 'newest')),
            'country' => bm_app_param('country', ''),
            'fromYear' => bm_app_param('fromYear', bm_app_param('min_year', '')),
            'toYear' => bm_app_param('toYear', bm_app_param('max_year', '')),
            'rates' => bm_app_param('rates', bm_app_param('rating', '')),
            'score' => bm_app_param('score', ''),
            'lang' => bm_app_param('lang', ''),
            'dubbed' => bm_app_param('dubbed', '') !== '',
            'subtitle' => bm_app_param('subtitle', '') !== '',
            'playonline' => bm_app_param('playonline', '') !== '',
            'page' => $page
        );
        $raw = api4_search($params);
    } elseif ($archive === '3') {
        $params = array(
            's' => $q,
            'type' => $type !== '' ? $type : 'all',
            'genre' => bm_app_param('genre', ''),
            'sort' => bm_app_param('sort', bm_app_param('sortby', 'newest')),
            'country' => bm_app_param('country', ''),
            'fromYear' => bm_app_param('fromYear', bm_app_param('min_year', '')),
            'toYear' => bm_app_param('toYear', bm_app_param('max_year', '')),
            'rates' => bm_app_param('rates', bm_app_param('rating', '')),
            'rating' => bm_app_param('rating', bm_app_param('rates', '')),
            'score' => bm_app_param('score', ''),
            'lang' => bm_app_param('lang', ''),
            'dubbed' => bm_app_param('dubbed', '') !== '',
            'subtitle' => bm_app_param('subtitle', '') !== '',
            'playonline' => bm_app_param('playonline', '') !== '',
            'page' => $page
        );
        if (!function_exists('api6_search')) throw new RuntimeException('Archive 3 api6 search runtime unavailable');
        $raw = api6_search($params);
    } else {
        $params = array(
            's' => $q,
            'type' => $type !== '' ? $type : 'both',
            'genre' => (int)bm_app_param('genre', 0),
            'sortby' => bm_app_param('sortby', 'newest'),
            'imdbrate' => (int)bm_app_param('imdbrate', 0),
            'country' => (int)bm_app_param('country', 0),
            'min_year' => (int)bm_app_param('min_year', 1800),
            'max_year' => (int)bm_app_param('max_year', date('Y')),
            'page' => $page,
            'dubbed' => (int)bm_app_param('dubbed', 0),
            'subtitle' => (int)bm_app_param('subtitle', 0)
        );
        $movies = advancedSearch($params);
        $raw = array('page' => $page, 'movies' => $movies);
    }

    $items = array();
    foreach ((isset($raw['movies']) ? $raw['movies'] : array()) as $it) {
        $items[] = bm_app_normalize_card($it, $archive);
        if ($limit > 0 && count($items) >= $limit) break;
    }
    return array(
        'archive' => (int)$archive,
        'page' => $page,
        'query' => $q,
        'type' => $type,
        'count' => count($items),
        'has_more' => !empty($raw['has_more']) || !empty($raw['next_page']) || (count($items) > 0 && $page < 10),
        'next_page' => isset($raw['next_page']) ? $raw['next_page'] : ((count($items) > 0 && $page < 10) ? ($page + 1) : null),
        'items' => $items
    );
}


function bm_app_table_exists($table) {
    $pdo = bm_app_pdo();
    if (!$pdo) return false;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
        $stmt->execute(array($table));
        return ((int)$stmt->fetchColumn() > 0);
    } catch (Throwable $e) {
        try {
            $stmt = $pdo->prepare("SHOW TABLES LIKE ?");
            $stmt->execute(array($table));
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e2) { return false; }
    }
}

function bm_app_table_columns($table) {
    static $cache = array();
    if (isset($cache[$table])) return $cache[$table];
    $pdo = bm_app_pdo();
    $cols = array();
    if ($pdo) {
        try {
            $stmt = $pdo->prepare("SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION");
            $stmt->execute(array($table));
            foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $r) {
                if (!empty($r['COLUMN_NAME'])) $cols[] = $r['COLUMN_NAME'];
            }
        } catch (Throwable $e) {
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM `$table`");
                foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $r) {
                    if (!empty($r['Field'])) $cols[] = $r['Field'];
                }
            } catch (Throwable $e2) {}
        }
    }
    $cache[$table] = $cols;
    return $cols;
}

function bm_app_col_exists($table, $col) {
    return in_array($col, bm_app_table_columns($table), true);
}

function bm_app_db_link_url($row) {
    foreach (array('url','link','download_url','file_url','src','href') as $k) {
        if (!empty($row[$k])) return trim((string)$row[$k]);
    }
    return '';
}

function bm_app_db_link_quality($row, $url) {
    foreach (array('quality','resolution','label','title') as $k) {
        if (!empty($row[$k])) return trim((string)$row[$k]);
    }
    if (preg_match('/(2160p|4K|1080p|720p|480p|360p)/i', $url, $m)) return strtoupper($m[1]);
    return 'Unknown';
}

function bm_app_link_tables_meta() {
    return array(
        'dubbed_links' => array('type'=>'dub', 'label'=>'دوبله فارسی'),
        'softsub_links' => array('type'=>'subtitle', 'label'=>'سافت ساب'),
        'hardsub_links' => array('type'=>'hardsub', 'label'=>'هاردساب'),
        'audio_links' => array('type'=>'audio', 'label'=>'صوت دوبله'),
        'dubbed_audio_links' => array('type'=>'audio', 'label'=>'صوت دوبله')
    );
}

function bm_app_make_download_link_from_row($table, $meta, $row, $movieIdForOutput) {
    $url = bm_app_db_link_url($row);
    if ($url === '') return null;
    $season = (isset($row['season']) && $row['season'] !== '' && $row['season'] !== null) ? (int)$row['season'] : null;
    $episode = (isset($row['episode']) && $row['episode'] !== '' && $row['episode'] !== null) ? (int)$row['episode'] : null;
    $isFolder = !empty($row['is_folder']) && (string)$row['is_folder'] !== '0';
    $quality = bm_app_db_link_quality($row, $url);
    $label = $meta['label'];
    $displayParts = array();
    if ($season !== null && $season > 0) $displayParts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $displayParts[] = 'قسمت ' . $episode;
    if ($quality !== '') $displayParts[] = $quality;
    $displayParts[] = $label;
    // Preserve fully-qualified download URLs exactly as stored in the DB.
    // This intentionally supports legacy, current and future download subdomains
    // without requiring a new APK or a hardcoded host allowlist.
    $finalUrl = preg_match('#^https?://#i', $url) ? $url : bm_app_abs_asset($url);
    $urlHost = (string)(parse_url($finalUrl, PHP_URL_HOST) ?: '');
    return array(
        'id' => isset($row['id']) ? (int)$row['id'] : 0,
        'movie_id' => $movieIdForOutput,
        'source_table' => $table,
        'source_movie_id' => isset($row['movie_id']) ? (int)$row['movie_id'] : $movieIdForOutput,
        'season' => $season,
        'episode' => $episode,
        'quality' => $quality,
        'type' => $meta['type'],
        'type_fa' => $label,
        'label' => $label,
        'display_label' => implode(' • ', array_filter($displayParts)),
        'size' => (string)($row['size'] ?? ''),
        'subtitle_url' => !empty($row['subtitle_url']) ? (preg_match('#^https?://#i', (string)$row['subtitle_url']) ? (string)$row['subtitle_url'] : bm_app_abs_asset((string)$row['subtitle_url'])) : '',
        'url' => $finalUrl,
        'url_host' => $urlHost,
        'is_folder' => $isFolder,
        'is_direct' => true,
        'is_download' => true,
        'is_audio' => $meta['type'] === 'audio'
    );
}

function bm_app_downloads_query_links($whereSql, $params, $movieIdForOutput) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    $out = array();
    foreach (bm_app_link_tables_meta() as $table => $meta) {
        if (!bm_app_table_exists($table)) continue;
        $cols = bm_app_table_columns($table);
        if (!in_array('url', $cols, true) && !in_array('link', $cols, true) && !in_array('download_url', $cols, true)) continue;
        try {
            $order = array();
            foreach (array('season','episode','id') as $c) if (in_array($c, $cols, true)) $order[] = "$c ASC";
            $orderSql = $order ? (' ORDER BY ' . implode(', ', $order)) : '';
            $stmt = $pdo->prepare("SELECT * FROM `$table` WHERE " . $whereSql . $orderSql);
            $stmt->execute($params);
            foreach (($stmt->fetchAll(PDO::FETCH_ASSOC) ?: array()) as $row) {
                $link = bm_app_make_download_link_from_row($table, $meta, $row, (int)$movieIdForOutput);
                if ($link) $out[] = $link;
            }
        } catch (Throwable $e) {}
    }
    return $out;
}

function bm_app_db_movie_row_by_id($movieId) {
    $pdo = bm_app_pdo();
    $movieId = (int)$movieId;
    if (!$pdo || $movieId <= 0 || !bm_app_table_exists('movies') || !bm_app_col_exists('movies', 'id')) return null;
    try {
        $stmt = $pdo->prepare('SELECT * FROM movies WHERE id = ? LIMIT 1');
        $stmt->execute(array($movieId));
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    } catch (Throwable $e) { return null; }
}

function bm_app_downloads_from_db_imdb($imdbCode, $movieIdForOutput = 0) {
    $imdbCode = trim((string)$imdbCode);
    if ($imdbCode === '') return array();
    return bm_app_downloads_query_links('url LIKE ?', array('%' . $imdbCode . '%'), (int)$movieIdForOutput);
}

function bm_app_movie_identity_values($row) {
    $ids = array('imdb'=>array(), 'title'=>array(), 'title_fa'=>array(), 'year'=>'');
    if (!is_array($row)) return $ids;
    foreach (array('imdb_code','imdb','imdb_id') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['imdb'][$v] = $v;
        }
    }
    foreach (array('title','title_en','original_title','name','english_title') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['title'][$v] = $v;
        }
    }
    foreach (array('title_fa','fa_title','persian_title') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v !== '') $ids['title_fa'][$v] = $v;
        }
    }
    if (!empty($row['year'])) $ids['year'] = trim((string)$row['year']);
    return $ids;
}

function bm_app_find_same_movie_rows($row) {
    $pdo = bm_app_pdo();
    if (!$pdo || !is_array($row) || !bm_app_table_exists('movies')) return array();
    $cols = bm_app_table_columns('movies');
    if (!$cols) return array();
    $currentId = isset($row['id']) ? (int)$row['id'] : 0;
    $idv = bm_app_movie_identity_values($row);
    $where = array();
    $params = array();

    foreach ($idv['imdb'] as $imdb) {
        foreach (array('imdb_code','imdb','imdb_id') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $imdb; }
        }
    }
    foreach ($idv['title'] as $title) {
        foreach (array('title','title_en','original_title','name','english_title') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $title; }
        }
    }
    foreach ($idv['title_fa'] as $titleFa) {
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (in_array($c, $cols, true)) { $where[] = "$c = ?"; $params[] = $titleFa; }
        }
    }
    if (!$where) return array();

    try {
        $score = array();
        if (in_array('id', $cols, true)) $score[] = "CASE WHEN id = " . (int)$currentId . " THEN 100 ELSE 0 END";
        $order = $score ? (" ORDER BY (" . implode(' + ', $score) . ") ASC, id ASC") : " ORDER BY id ASC";
        $stmt = $pdo->prepare('SELECT * FROM movies WHERE (' . implode(' OR ', $where) . ')' . $order . ' LIMIT 40');
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
    } catch (Throwable $e) { return array(); }
}

function bm_app_downloads_from_same_movie_rows($row, $movieIdForOutput = 0, &$sourceIds = null) {
    $out = array();
    $seen = array();
    $sourceIdsLocal = array();
    foreach (bm_app_find_same_movie_rows($row) as $r) {
        if (empty($r['id'])) continue;
        $rid = (int)$r['id'];
        $links = bm_app_downloads_query_links('movie_id = ?', array($rid), (int)$movieIdForOutput);
        if (!$links) continue;
        $sourceIdsLocal[$rid] = $rid;
        foreach ($links as $l) {
            $u = isset($l['url']) ? (string)$l['url'] : '';
            if ($u !== '' && isset($seen[$u])) continue;
            if ($u !== '') $seen[$u] = true;
            $l['source_movie_id'] = $rid;
            $l['resolved_by'] = 'same_movie_identity';
            $out[] = $l;
        }
    }
    if (is_array($sourceIds)) $sourceIds = array_values($sourceIdsLocal);
    return $out;
}

function bm_app_link_table_debug_counts($row, $movieId = 0) {
    $pdo = bm_app_pdo();
    $diag = array();
    if (!$pdo) return array('pdo'=>false);
    $imdbs = array_values(bm_app_movie_identity_values($row)['imdb']);
    foreach (bm_app_link_tables_meta() as $table => $meta) {
        $info = array('exists'=>bm_app_table_exists($table));
        if (!$info['exists']) { $diag[$table] = $info; continue; }
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE movie_id = ?");
            $stmt->execute(array((int)$movieId));
            $info['by_movie_id'] = (int)$stmt->fetchColumn();
        } catch (Throwable $e) { $info['by_movie_id_error'] = $e->getMessage(); }
        foreach ($imdbs as $imdb) {
            try {
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM `$table` WHERE url LIKE ?");
                $stmt->execute(array('%' . $imdb . '%'));
                $info['by_url_imdb'][$imdb] = (int)$stmt->fetchColumn();
            } catch (Throwable $e) { $info['by_url_imdb_error'] = $e->getMessage(); }
        }
        $diag[$table] = $info;
    }
    $same = array();
    foreach (bm_app_find_same_movie_rows($row) as $r) {
        $same[] = array('id'=>(int)($r['id'] ?? 0), 'imdb'=>$r['imdb_code'] ?? ($r['imdb'] ?? null), 'title'=>$r['title'] ?? ($r['title_en'] ?? null), 'title_fa'=>$r['title_fa'] ?? null);
    }
    $diag['same_movie_rows'] = $same;
    return $diag;
}


function bm_app_origin_url() {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (isset($_SERVER['SERVER_PORT']) && (string)$_SERVER['SERVER_PORT'] === '443');
    $scheme = $https ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST']) && $_SERVER['HTTP_HOST'] !== '' ? $_SERVER['HTTP_HOST'] : 'bankmovie.top';
    return $scheme . '://' . $host;
}

function bm_app_slugify_ascii($text) {
    $text = trim((string)$text);
    if ($text === '') return '';
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strtolower($text);
    $text = preg_replace('~[^a-z0-9]+~i', '-', $text);
    $text = trim($text, '-');
    return $text ?: '';
}

function bm_app_page_candidates_for_movie_row($row, $identifier = '') {
    $out = array();
    $base = rtrim(bm_app_origin_url(), '/');
    $publicId = bm_app_public_id_from_identifier($identifier);
    if ($publicId === '' && !empty($row['id'])) $publicId = (string)(int)$row['id'];

    foreach (array('source_url','url','detail_url','page_url','permalink','web_url') as $c) {
        if (!empty($row[$c])) {
            $v = trim((string)$row[$c]);
            if ($v === '') continue;
            if (preg_match('~^https?://~i', $v)) $out[] = $v;
            elseif (strpos($v, '/') === 0) $out[] = $base . $v;
            elseif (strpos($v, 'movie/') === 0) $out[] = $base . '/' . $v;
        }
    }

    foreach (array('slug','source_slug','detail_id') as $c) {
        if (!empty($row[$c])) {
            $s = trim((string)$row[$c]);
            if ($s === '') continue;
            if (preg_match('~^https?://~i', $s)) $out[] = $s;
            elseif (strpos($s, 'movie/') === 0) $out[] = $base . '/' . ltrim($s, '/');
            else $out[] = $base . '/movie/' . trim($s, '/');
        }
    }

    // آرشیو ۲ روی سایت خودش slug انگلیسی + public id می‌سازد، مثل vikings-277 یا toy-story-5-14500
    if ($publicId !== '') {
        foreach (array('title_en','original_title','title','name','english_title') as $c) {
            if (!empty($row[$c])) {
                $slug = bm_app_slugify_ascii($row[$c]);
                if ($slug !== '') $out[] = $base . '/movie/' . $slug . '-' . $publicId;
            }
        }
        // اگر title_fa شامل عنوان انگلیسی کنار فارسی بود، بخش لاتین را هم امتحان کن
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (!empty($row[$c]) && preg_match_all('~[A-Za-z0-9][A-Za-z0-9\s\-\:\.]+~u', (string)$row[$c], $mm)) {
                foreach ($mm[0] as $piece) {
                    $slug = bm_app_slugify_ascii($piece);
                    if ($slug !== '') $out[] = $base . '/movie/' . $slug . '-' . $publicId;
                }
            }
        }
    }

    $clean = array();
    foreach ($out as $u) {
        $u = trim((string)$u);
        if ($u !== '' && !isset($clean[$u])) $clean[$u] = $u;
    }
    return array_values($clean);
}

function bm_app_fetch_public_html($url) {
    $url = trim((string)$url);
    if ($url === '') return '';
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'BankMovieAndroidNative/HTMLFallback'
        ));
        $body = curl_exec($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);
        if ($body !== false && $code >= 200 && $code < 400) return (string)$body;
    }
    try {
        $ctx = stream_context_create(array('http'=>array('timeout'=>12,'header'=>"User-Agent: BankMovieAndroidNative/HTMLFallback\r\n"), 'ssl'=>array('verify_peer'=>false,'verify_peer_name'=>false)));
        $body = @file_get_contents($url, false, $ctx);
        return is_string($body) ? $body : '';
    } catch (Throwable $e) { return ''; }
}

function bm_app_download_type_from_context($url, $ctx) {
    $s = strtolower($url . ' ' . $ctx);
    if (strpos($s, 'softsub') !== false || strpos($s, 'soft-sub') !== false || strpos($s, 'سافت') !== false) return array('type'=>'subtitle', 'label'=>'سافت ساب');
    if (strpos($s, 'hardsub') !== false || strpos($s, 'hard-sub') !== false || strpos($s, 'هارد') !== false) return array('type'=>'hardsub', 'label'=>'هاردساب');
    if (strpos($s, 'dubbed') !== false || strpos($s, 'dub') !== false || strpos($s, 'دوبله') !== false) return array('type'=>'dub', 'label'=>'دوبله فارسی');
    if (strpos($s, 'audio') !== false || strpos($s, 'voice') !== false || strpos($s, 'صوت') !== false) return array('type'=>'audio', 'label'=>'صوت دوبله');
    return array('type'=>'download', 'label'=>'دانلود');
}

function bm_app_quality_from_text($text) {
    if (preg_match('~(2160p|4k|1080p|720p|480p|360p)[^\s<\"\']{0,40}~i', (string)$text, $m)) return trim($m[0]);
    return 'Unknown';
}

function bm_app_make_html_link($url, $ctx, $movieIdForOutput, $idx) {
    $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '' || !preg_match('~^https?://~i', $url)) return null;
    $ctx = html_entity_decode((string)$ctx, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $meta = bm_app_download_type_from_context($url, $ctx);
    $quality = bm_app_quality_from_text($ctx . ' ' . $url);
    $season = null; $episode = null;
    if (preg_match('~(?:data-season=[\"\']?S?)(\d+)~i', $ctx, $m)) $season = (int)$m[1];
    elseif (preg_match('~[\\/_\.-]S(\d{1,2})[\\/_\.-]?~i', $url, $m)) $season = (int)$m[1];
    if (preg_match('~(?:data-episode=[\"\']?E?)(\d+)~i', $ctx, $m)) $episode = (int)$m[1];
    elseif (preg_match('~S\d{1,2}E(\d{1,3})~i', $url, $m)) $episode = (int)$m[1];
    elseif (preg_match('~قسمت\s*(\d+)~u', $ctx, $m)) $episode = (int)$m[1];
    $parts = array();
    if ($season !== null && $season > 0) $parts[] = 'فصل ' . $season;
    if ($episode !== null && $episode > 0) $parts[] = 'قسمت ' . $episode;
    if ($quality !== '') $parts[] = $quality;
    $parts[] = $meta['label'];
    return array(
        'id' => $idx,
        'movie_id' => (int)$movieIdForOutput,
        'source_table' => 'html_page',
        'source_movie_id' => (int)$movieIdForOutput,
        'season' => $season,
        'episode' => $episode,
        'quality' => $quality,
        'type' => $meta['type'],
        'type_fa' => $meta['label'],
        'label' => $meta['label'],
        'display_label' => implode(' • ', array_filter($parts)),
        'size' => '',
        'url' => $url,
        'is_folder' => false,
        'is_direct' => true,
        'is_download' => true,
        'is_audio' => $meta['type'] === 'audio'
    );
}

function bm_app_parse_downloads_from_movie_html($html, $movieIdForOutput = 0) {
    $html = (string)$html;
    if ($html === '') return array();
    $out = array();
    $seen = array();
    $idx = 1;
    $add = function($url, $ctx) use (&$out, &$seen, &$idx, $movieIdForOutput) {
        $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if ($url === '' || !preg_match('~^https?://~i', $url)) return;
        if (isset($seen[$url])) return;
        // لینک‌های سایت/تبلیغ/عکس را حذف کن؛ لینک فایل/دانلود/پخش را نگه دار
        $u = strtolower($url);
        $looksDownload = preg_match('~\.(mkv|mp4|avi|m3u8|mpd|mov|webm|zip|rar)(?:[?#]|$)~i', $url) ||
            strpos($u, 'dls') !== false || strpos($u, 'dlcenter') !== false || strpos($u, 'download') !== false || strpos($u, 'playit=') !== false || strpos($u, 'softsub') !== false || strpos($u, 'hardsub') !== false;
        if (!$looksDownload) return;
        $link = bm_app_make_html_link($url, $ctx, $movieIdForOutput, $idx++);
        if ($link) { $seen[$url] = true; $out[] = $link; }
    };

    if (preg_match_all('~<button[^>]+class=[\"\'][^\"\']*bm-local-play-choice[^\"\']*[\"\'][^>]*>~is', $html, $m)) {
        foreach ($m[0] as $tag) {
            if (preg_match('~data-url=[\"\']([^\"\']+)[\"\']~i', $tag, $u)) $add($u[1], $tag);
        }
    }
    if (preg_match_all('~data-url=[\"\']([^\"\']+)[\"\']~i', $html, $m)) {
        foreach ($m[1] as $u) $add($u, substr($html, max(0, strpos($html, $u) - 500), 1200));
    }
    if (preg_match_all('~handleDownloadClick\([\"\']([^\"\']+)[\"\']\)~i', $html, $m)) {
        foreach ($m[1] as $u) $add($u, substr($html, max(0, strpos($html, $u) - 500), 1200));
    }
    if (preg_match_all('~<a\b[^>]+href=[\"\']([^\"\']+)[\"\'][^>]*>(.*?)</a>~is', $html, $m, PREG_SET_ORDER)) {
        foreach ($m as $a) $add($a[1], $a[0]);
    }
    return $out;
}

function bm_app_downloads_from_html_page_for_movie($row, $identifier = '', $movieIdForOutput = 0) {
    if (!is_array($row)) return array();
    $candidates = bm_app_page_candidates_for_movie_row($row, $identifier);
    foreach ($candidates as $url) {
        $html = bm_app_fetch_public_html($url);
        if ($html === '') continue;
        $links = bm_app_parse_downloads_from_movie_html($html, $movieIdForOutput);
        if ($links) {
            foreach ($links as &$l) $l['html_source_url'] = $url;
            unset($l);
            return $links;
        }
    }
    return array();
}


function bm_app_downloads_from_db_movie($movieId) {
    $movieId = (int)$movieId;
    if ($movieId <= 0) return array();

    // ۱) اتصال مستقیم جدول لینک‌ها با movies.id
    $out = bm_app_downloads_query_links('movie_id = ?', array($movieId), $movieId);
    if ($out) return $out;

    $row = bm_app_db_movie_row_by_id($movieId);
    if ($row) {
        // ۲) اگر این id عمومی/کپی است، ردیف اصلی همان فیلم را از روی imdb/title پیدا کن و لینک‌های آن id را بگیر.
        $sameIds = array();
        $same = bm_app_downloads_from_same_movie_rows($row, $movieId, $sameIds);
        if ($same) return $same;

        // ۳) بعضی لینک‌ها در URL شناسه IMDb دارند.
        foreach (array('imdb_code','imdb','imdb_id') as $c) {
            if (!empty($row[$c])) {
                $byImdb = bm_app_downloads_from_db_imdb((string)$row[$c], $movieId);
                if ($byImdb) return $byImdb;
            }
        }

        // ۴) fallback HTML فقط اگر هاست اجازه fetch بدهد.
        $fromHtml = bm_app_downloads_from_html_page_for_movie($row, (string)$movieId, $movieId);
        if ($fromHtml) return $fromHtml;
    }

    return array();
}

function bm_app_public_id_from_identifier($identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') return '';
    $path = (string)(parse_url($identifier, PHP_URL_PATH) ?: $identifier);
    $base = trim(basename(trim($path, '/')));
    if (ctype_digit($identifier)) return $identifier;
    if (preg_match('~-(\d+)$~', $base, $m)) return $m[1];
    if (preg_match('~/movie/[^/?#]*-(\d+)(?:[/?#]|$)~i', $identifier, $m)) return $m[1];
    return '';
}

function bm_app_lookup_movie_by_fields($fields) {
    $pdo = bm_app_pdo();
    if (!$pdo || !is_array($fields)) return null;
    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    $where = array();
    $params = array();

    foreach (array('imdb_code','imdb') as $c) {
        if (in_array($c, $cols, true) && !empty($fields[$c])) {
            $where[] = "$c = ?";
            $params[] = trim((string)$fields[$c]);
        }
    }

    $title = trim((string)($fields['title'] ?? ''));
    $titleFa = trim((string)($fields['title_fa'] ?? ''));
    $year = trim((string)($fields['year'] ?? ''));

    if ($title !== '') {
        foreach (array('title','title_en','name','english_title') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $title;
            }
        }
    }
    if ($titleFa !== '') {
        foreach (array('title_fa','fa_title','persian_title') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $titleFa;
            }
        }
    }

    if (!$where) return null;
    try {
        $sql = 'SELECT * FROM movies WHERE (' . implode(' OR ', $where) . ')';
        if ($year !== '' && in_array('year', $cols, true)) {
            $sql .= ' ORDER BY CASE WHEN year = ? THEN 0 ELSE 1 END, id ASC';
            $params[] = $year;
        } else {
            $sql .= ' ORDER BY id ASC';
        }
        $sql .= ' LIMIT 1';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($row) return $row;
    } catch (Throwable $e) {}
    return null;
}

function bm_app_find_db_movie_row($identifier) {
    $pdo = bm_app_pdo();
    if (!$pdo) return null;
    $identifier = trim((string)$identifier);
    if ($identifier === '') return null;

    $slug = bm_app_extract_slug_from_url($identifier);
    $publicId = bm_app_public_id_from_identifier($identifier);
    $base = trim((string)basename(trim((string)(parse_url($identifier, PHP_URL_PATH) ?: $identifier), '/')));
    $slugNoId = $base !== '' ? preg_replace('~-\d+$~', '', $base) : '';

    $candidates = array_values(array_unique(array_filter(array($identifier, $slug, $base, $slugNoId, $publicId))));
    $cols = bm_app_table_columns('movies');
    if (!$cols) return null;

    foreach ($candidates as $cand) {
        $where = array();
        $params = array();

        if (ctype_digit((string)$cand) && in_array('id', $cols, true)) {
            $where[] = 'id = ?';
            $params[] = (int)$cand;
        }

        foreach (array('slug','source_slug','detail_id','imdb_code','imdb','tmdb_id') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c = ?";
                $params[] = $cand;
            }
        }

        foreach (array('source_url','url','detail_url','page_url','permalink') as $c) {
            if (in_array($c, $cols, true)) {
                $where[] = "$c LIKE ?";
                $params[] = '%' . $cand . '%';
            }
        }

        if ($publicId !== '') {
            foreach (array('slug','source_slug','detail_id') as $c) {
                if (in_array($c, $cols, true)) {
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId;
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId . '/%';
                }
            }
            foreach (array('source_url','url','detail_url','page_url','permalink') as $c) {
                if (in_array($c, $cols, true)) {
                    $where[] = "$c LIKE ?";
                    $params[] = '%-' . $publicId . '%';
                    $where[] = "$c LIKE ?";
                    $params[] = '%/movie/%' . $publicId . '%';
                }
            }
        }

        if (!$where) continue;
        try {
            $stmt = $pdo->prepare('SELECT * FROM movies WHERE ' . implode(' OR ', $where) . ' ORDER BY id ASC LIMIT 1');
            $stmt->execute($params);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) return $row;
        } catch (Throwable $e) {}
    }

    // Archive 2 is intentionally strict: never ask Archive 1/external metadata
    // to fabricate a match. If the identifier is not in the site database,
    // report it as missing instead of leaking Archive 1 content into Archive 2.
    return null;
}

function bm_app_merge_db_downloads_into_detail($detail, $identifier = '') {
    if (!is_array($detail)) return $detail;
    $movieId = 0;
    foreach (array('db_id','movie_id','local_id','id') as $k) {
        if (!empty($detail[$k]) && ctype_digit((string)$detail[$k])) { $movieId = (int)$detail[$k]; break; }
    }
    $rowForVisuals = null;
    if ($movieId <= 0 && $identifier !== '') {
        $row = bm_app_find_db_movie_row($identifier);
        if ($row && !empty($row['id'])) { $movieId = (int)$row['id']; $rowForVisuals = $row; }
    } else if ($identifier !== '') {
        $rowForVisuals = bm_app_find_db_movie_row($identifier);
    }
    if ($movieId <= 0 && !empty($detail['source_url'])) {
        $row = bm_app_find_db_movie_row($detail['source_url']);
        if ($row && !empty($row['id'])) $movieId = (int)$row['id'];
    }
    if ($rowForVisuals && is_array($rowForVisuals)) {
        foreach (array('poster','image','cover_image','backdrop','imdb_code') as $vk) {
            if (empty($detail[$vk]) && !empty($rowForVisuals[$vk])) $detail[$vk] = $rowForVisuals[$vk];
        }
        if (empty($detail['poster']) && !empty($rowForVisuals['imdb_code'])) $detail['poster'] = bm_app_existing_local_poster($rowForVisuals['imdb_code']);
        if (empty($detail['image']) && !empty($detail['poster'])) $detail['image'] = $detail['poster'];
        if (empty($detail['backdrop']) && !empty($detail['poster'])) $detail['backdrop'] = $detail['poster'];
    }
    if ($movieId <= 0) return $detail;
    $dbLinks = bm_app_downloads_from_db_movie($movieId);
    if (!$dbLinks) return $detail;

    $old = array();
    if (isset($detail['downloads']) && is_array($detail['downloads'])) $old = $detail['downloads'];
    elseif (isset($detail['links']) && is_array($detail['links'])) $old = $detail['links'];
    $seen = array();
    $merged = array();
    foreach (array_merge($old, $dbLinks) as $l) {
        if (!is_array($l)) continue;
        $u = bm_app_db_link_url($l);
        if ($u === '') continue;
        $key = md5($u . '|' . ($l['quality'] ?? '') . '|' . ($l['season'] ?? '') . '|' . ($l['episode'] ?? '') . '|' . ($l['type'] ?? ''));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $merged[] = $l;
    }
    $detail['db_id'] = $movieId;
    $detail['movie_id'] = $movieId;
    $detail['downloads'] = $merged;
    $detail['links'] = $merged;
    return $detail;
}


function bm_app_enrich_db_movie_extra($row) {
    if (!is_array($row)) return $row;
    $imdb = trim((string)($row['imdb_code'] ?? ''));
    if ($imdb === '' || !bm_app_table_exists('movie_extra_info')) return $row;
    $pdo = bm_app_pdo();
    if (!$pdo) return $row;
    try {
        $stmt = $pdo->prepare("SELECT * FROM movie_extra_info WHERE imdb_code = ? LIMIT 1");
        $stmt->execute(array($imdb));
        $extra = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($extra)) return $row;

        foreach (array('language','production_companies','rated','seasons','episodes') as $key) {
            if ((!isset($row[$key]) || trim((string)$row[$key]) === '') && isset($extra[$key])) {
                $row[$key] = $extra[$key];
            }
        }
        if ((!isset($row['status_text']) || trim((string)$row['status_text']) === '') && !empty($extra['status'])) {
            $row['status_text'] = (string)$extra['status'];
        }
        if ((!isset($row['age_rate']) || trim((string)$row['age_rate']) === '') && !empty($extra['rated'])) {
            $row['age_rate'] = (string)$extra['rated'];
        }
        if ((!isset($row['update_note']) || trim((string)$row['update_note']) === '')) {
            $season = isset($extra['seasons']) && is_numeric($extra['seasons']) ? (int)$extra['seasons'] : 0;
            $episode = isset($extra['episodes']) && is_numeric($extra['episodes']) ? (int)$extra['episodes'] : 0;
            if ($season > 0 && $episode > 0) {
                $row['update_note'] = 'فصل ' . $season . ' قسمت ' . $episode . ' اضافه شد';
            } elseif ($episode > 0) {
                $row['update_note'] = 'قسمت ' . $episode . ' اضافه شد';
            }
        }
    } catch (Throwable $e) {
        // Extra information is optional; detail must remain available on older DB schemas.
    }
    return $row;
}

function bm_app_db_detail($identifier, $typeHint = '', $archiveOut = 2) {
    $row = bm_app_find_db_movie_row($identifier);
    if (!$row) return null;
    $row = bm_app_enrich_db_movie_extra($row);
    $movieId = (int)($row['id'] ?? 0);
    $downloads = bm_app_downloads_from_db_movie($movieId);
    $row['db_id'] = $movieId;
    $row['movie_id'] = $movieId;
    if (empty($row['poster'])) { $posterKey = !empty($row['imdb_code']) ? $row['imdb_code'] : ($movieId > 0 ? (string)$movieId : ''); if ($posterKey !== '') $row['poster'] = 'posters/' . basename((string)$posterKey) . '.webp'; }
    if (empty($row['image']) && !empty($row['poster'])) $row['image'] = $row['poster'];
    if (empty($row['backdrop']) && !empty($row['poster'])) $row['backdrop'] = $row['poster'];
    $row['downloads'] = $downloads;
    $row['links'] = $downloads;
    $row['type'] = $typeHint ?: ($row['type'] ?? 'movie');
    $row['rating'] = $row['imdb_rate'] ?? ($row['rating'] ?? null);
    $detail = bm_app_normalize_detail($row, (int)$archiveOut === 2 ? 2 : $archiveOut);
    $detail['source'] = 'db_movies';
    $detail['archive'] = 2;
    return $detail;
}
function bm_app_actor_db_fallback($name) {
    $pdo = bm_app_pdo();
    if (!$pdo) return array();
    $name = trim((string)$name);
    if ($name === '') return array();
    try {
        $stmt = $pdo->prepare("SELECT * FROM movies WHERE actors LIKE ? ORDER BY year DESC, id DESC LIMIT 80");
        $stmt->execute(array('%' . $name . '%'));
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: array();
        return array_map('bm_app_normalize_db_movie', $rows);
    } catch (Throwable $e) { return array(); }
}

function bm_app_detail($archive, $identifier, $type) {
    $archive = (string)$archive;
    if ($identifier === '') bm_app_fail('شناسه خالی است', 422);
    $isLocalArchive = bm_app_is_db_archive($archive);

    if ($archive === '5') {
        $raw = fitlinerim_get_details($identifier, $type);
        if (!is_array($raw) || !$raw) bm_app_fail('عنوان آرشیو 5 پیدا نشد', 404);
        $raw['source_url'] = '/movie/arc5-' . rawurlencode((string)$identifier);
        return bm_app_normalize_detail($raw, 5);
    }
    if ($archive === '4') {
        $raw = api4_get_details($identifier);
        return bm_app_normalize_detail($raw, 4);
    }
    if ($archive === '3') {
        if (!function_exists('api6_get_details')) throw new RuntimeException('Archive 3 api6 detail runtime unavailable');
        $raw = api6_get_details($identifier);
        return bm_app_normalize_detail($raw, 3);
    }

    // Phase 6: Archive 2 is database-authoritative for new APKs. Never fall
    // through to the legacy scraper/API5 path. Old installed APKs can continue
    // calling api5.php directly because that endpoint remains deployed.
    if ($isLocalArchive) {
        $db = bm_app_db_detail($identifier, $type, 2);
        if ($db) return $db;
        bm_app_fail('عنوان آرشیو ۲ در دیتابیس پیدا نشد', 404);
    }

    $raw = getMovieDetails($identifier, $type !== '' ? $type : null);
    if (is_array($raw)) $raw = bm_app_fill_archive1_backdrop($raw, $identifier, $type);
    return bm_app_normalize_detail($raw, 1);
}

function bm_app_normalize_actor_page_movie($item) {
    if (!is_array($item)) return null;
    return bm_app_normalize_card($item, 1);
}

function bm_app_actor_details($identifier) {
    $identifier = trim((string)$identifier);
    $fallbackName = trim((string)bm_app_param('name', ''));
    if ($identifier === '') $identifier = $fallbackName;
    if ($identifier === '') bm_app_fail('شناسه بازیگر خالی است', 422);

    $raw = null;
    try { $raw = getActorDetails($identifier); } catch (Throwable $e) { $raw = null; }
    $actorName = (string)($raw['name'] ?? $fallbackName ?? $identifier);
    $actor = array(
        'name' => $actorName,
        'slug' => (string)($raw['slug'] ?? ''),
        'image' => bm_app_abs_asset((string)($raw['photo'] ?? '')),
        'photo' => bm_app_abs_asset((string)($raw['photo'] ?? '')),
        'count' => (int)($raw['count'] ?? 0)
    );
    $items = array();
    foreach (($raw['movies'] ?? array()) as $m) {
        $n = bm_app_normalize_actor_page_movie($m);
        if ($n) $items[] = $n;
    }
    if (empty($items) && $actorName !== '') $items = bm_app_actor_db_fallback($actorName);
    $actor['count'] = count($items);
    return array('actor' => $actor, 'count' => count($items), 'items' => $items, 'movies' => $items);
}

try {
    $action = strtolower(bm_app_param('action', bm_app_param('fn', 'home')));
    $archive = bm_app_param('archive', '1');
    $page = bm_app_int('page', 1, 1, 500);
    $limit = bm_app_int('limit', 24, 1, 60);

    if ($action === 'ping') {
        $dbName = bm_app_current_database_name();
        $dbReady = $dbName !== '';
        bm_app_json(array(
            'status' => $dbReady ? 'success' : 'error',
            'message' => $dbReady ? 'BankMoviee app API is ready' : 'Archive 2 database is not connected',
            'version' => '2.2.0',
            'archives' => array(1, 2),
            'optional_archives' => array(3, 4),
            'default_archive' => 1,
            'archive2_source' => 'database',
            'database_ready' => $dbReady,
            'database' => $dbName,
            'site_libs' => array(
                'api2' => is_file(__DIR__ . '/api2_lib.php') || is_file(__DIR__ . '/includes/api2_lib.php'),
                'api3' => is_file(__DIR__ . '/api3_lib.php') || is_file(__DIR__ . '/includes/api3_lib.php'),
                'api4' => is_file(__DIR__ . '/api4_lib.php') || is_file(__DIR__ . '/includes/api4_lib.php')
            )
        ), $dbReady ? 200 : 500);
    }

    if ($action === 'boot' || $action === 'init') {
        // Startup must be archive-independent. The Android Home renders archive rails
        // with separate requests, so a dead Archive 1/3/4 source must not block boot.
        $bootLimit = bm_app_int('limit', 12, 4, 30);
        $bootViewer = bm_app_current_user();
        $bootSections = array();
        $archiveHealth = array();
        $enabledArchives = array();
        foreach (array(1,2,3,4,5) as $archiveNumber) {
            $key = 'archive' . $archiveNumber;
            $enabled = !function_exists('bm_app_archive_is_enabled') || bm_app_archive_is_enabled($key);
            if ($enabled) $enabledArchives[] = $archiveNumber;
            $archiveHealth[$key] = array(
                'enabled' => $enabled,
                'runtime_ready' => $archiveNumber === 2 ? (bm_app_current_database_name() !== '') : null,
                'boot_dependency' => false
            );
        }

        // Deliberately do NOT touch Archive 1/3/4/5 network sources here.
        // Their rails load independently after Home is visible. This makes boot a
        // local/controller operation and prevents one archive outage from pinning Splash.
        $archive1Enabled = in_array(1, $enabledArchives, true);
        $archive1Runtime = null;

        $bootCollections = (function_exists('bm_app_archive_section_user_can_access') && !bm_app_archive_section_user_can_access('archive1', 'collections', $bootViewer))
            ? array('page'=>1,'items'=>array(),'has_more'=>false,'next_page'=>null)
            : bm_app_collections(1, 8);
        $defaultArchive = !empty($enabledArchives) ? (int)$enabledArchives[0] : 1;

        bm_app_json(array(
            'status' => 'success',
            'action' => 'boot',
            'ready' => true,
            'degraded' => false,
            'version' => '2.2.0',
            'default_archive' => $defaultArchive,
            'archives' => $enabledArchives,
            'archive_health' => $archiveHealth,
            'archive2_source' => 'database',
            'archive2_database' => bm_app_current_database_name(),
            'loading' => array(
                'ping_ok' => true,
                'archive_independent_boot' => true,
                'wait_for' => array('sliders','collections'),
                'message' => 'BankMoviee resilient boot is ready'
            ),
            'sliders' => bm_app_sliders(10),
            'collections' => $bootCollections,
            'sections' => $bootSections
        ));
    }

    if ($action === 'sliders' || $action === 'slider') {
        bm_app_json(array('status'=>'success','action'=>'sliders','items'=>bm_app_sliders($limit)));
    }

    if ($action === 'collections') {
        bm_app_json(array_merge(array('status'=>'success','action'=>'collections'), bm_app_collections($page, $limit)));
    }

    if ($action === 'collection') {
        $slug = bm_app_param('slug', bm_app_param('id', ''));
        $sort = bm_app_param('sort', 'default');
        bm_app_json(array_merge(array('status'=>'success','action'=>'collection'), bm_app_collection_items($slug, $page, $limit, $sort)));
    }

    if ($action === 'home') {
        $homeViewer = bm_app_current_user();
        $sections = array();
        $archive1Enabled = !function_exists('bm_app_archive_is_enabled') || bm_app_archive_is_enabled('archive1');
        $archive1Runtime = $archive1Enabled && bm_app_archive_runtime_ready('1');
        if ($archive1Runtime) {
            $homeSectionKeys = function_exists('bm_app_archive_sections')
                ? bm_app_archive_sections('archive1', array('updated_movies','updated_series','anime','turkish'))
                : array('updated_movies','updated_series','anime','turkish');
            foreach ($homeSectionKeys as $homeSectionKey) {
                if (function_exists('bm_app_archive_section_user_can_access') && !bm_app_archive_section_user_can_access('archive1', $homeSectionKey, $homeViewer)) continue;
                $payload = bm_app_safe_section('1', $homeSectionKey, 1, 12);
                if (empty($payload['source_unavailable'])) $sections[] = $payload;
            }
        }
        $homeCollections = (function_exists('bm_app_archive_section_user_can_access') && !bm_app_archive_section_user_can_access('archive1', 'collections', $homeViewer))
            ? array('page'=>1,'items'=>array(),'has_more'=>false,'next_page'=>null)
            : bm_app_collections(1, 8);
        bm_app_json(array(
            'status' => 'success',
            'action' => 'home',
            'archive' => 1,
            'ready' => true,
            'degraded' => $archive1Enabled && !$archive1Runtime,
            'default_archive' => 1,
            'sliders' => bm_app_sliders(10),
            'collections' => $homeCollections,
            'sections' => $sections
        ));
    }

    if ($action === 'section') {
        $section = bm_app_param('section', 'new_movies');
        if (bm_app_is_serialblog_archive($archive)) {
            if (!bm_app_archive_runtime_ready('4')) {
                bm_app_json(array_merge(array('status'=>'degraded','action'=>'section'), bm_app_archive_unavailable_payload('4', 'section'), array('section'=>$section,'page'=>$page)));
            }
            try {
                bm_app_json(array_merge(array('status' => 'success', 'action' => 'section'), bm_app_serialblog_section($section, $page, $limit)));
            } catch (Throwable $e) {
                error_log('BankMovie archive4 section failed: ' . $e->getMessage());
                bm_app_json(array_merge(array('status'=>'degraded','action'=>'section'), bm_app_archive_unavailable_payload('4', 'section'), array('section'=>$section,'page'=>$page)));
            }
        }
        if ($archive === 'all') {
            $one = bm_app_safe_section('1', $section, $page, $limit);
            $three = bm_app_safe_section('3', $section, $page, $limit);
            bm_app_json(array(
                'status' => 'success',
                'action' => 'section',
                'archive' => 'all',
                'section' => $section,
                'page' => $page,
                'items' => array_merge($one['items'], $three['items']),
                'sources' => array($one, $three)
            ));
        }
        $sectionArchive = bm_app_is_db_archive($archive) ? '2' : ((string)$archive === '5' ? '5' : ((string)$archive === '4' ? '4' : ((string)$archive === '3' ? '3' : '1')));
        $sectionPayload = bm_app_safe_section($sectionArchive, $section, $page, $limit);
        bm_app_json(array_merge(array('status' => empty($sectionPayload['source_unavailable']) ? 'success' : 'degraded', 'action' => 'section'), $sectionPayload));
    }

    if ($action === 'search' || $action === 'live_search') {
        $q = bm_app_param('q', bm_app_param('s', ''));
        $type = bm_app_param('type', '');
        if ($action === 'live_search') $limit = min($limit, 12);
        if (bm_app_is_serialblog_archive($archive)) {
            if (!bm_app_archive_runtime_ready('4')) {
                bm_app_json(array_merge(array('status'=>'degraded','action'=>$action), bm_app_archive_unavailable_payload('4', $action), array('query'=>$q,'page'=>$page,'count'=>0,'total'=>0,'total_count'=>0)));
            }
            try {
                bm_app_json(array_merge(array('status' => 'success', 'action' => $action), bm_app_serialblog_search($q, $type, $page, $limit)));
            } catch (Throwable $e) {
                error_log('BankMovie archive4 search failed: ' . $e->getMessage());
                bm_app_json(array_merge(array('status'=>'degraded','action'=>$action), bm_app_archive_unavailable_payload('4', $action), array('query'=>$q,'page'=>$page,'count'=>0,'total'=>0,'total_count'=>0)));
            }
        }
        if ($archive === 'all') {
            $one = bm_app_safe_search('1', $q, $type, $page, $limit);
            $three = bm_app_safe_search('3', $q, $type, $page, $limit);
            $items = array_merge($one['items'], $three['items']);
            $hasMore = !empty($one['has_more']) || !empty($three['has_more']);
            bm_app_json(array(
                'status' => 'success',
                'action' => 'search',
                'archive' => 'all',
                'query' => $q,
                'page' => $page,
                'count' => count($items),
                'total' => (int)($one['total'] ?? count($one['items'])) + (int)($three['total'] ?? count($three['items'])),
                'total_count' => (int)($one['total_count'] ?? ($one['total'] ?? count($one['items']))) + (int)($three['total_count'] ?? ($three['total'] ?? count($three['items']))),
                'has_more' => $hasMore,
                'next_page' => $hasMore ? ($page + 1) : null,
                'items' => $items,
                'sources' => array($one, $three)
            ));
        }
        $searchArchive = bm_app_is_db_archive($archive) ? '2' : ((string)$archive === '5' ? '5' : ((string)$archive === '4' ? '4' : ((string)$archive === '3' ? '3' : '1')));
        $searchPayload = bm_app_safe_search($searchArchive, $q, $type, $page, $limit);
        bm_app_json(array_merge(array('status' => empty($searchPayload['source_unavailable']) ? 'success' : 'degraded', 'action' => 'search'), $searchPayload));
    }


    if ($action === 'debug_links') {
        $identifier = bm_app_param('id', bm_app_param('slug', bm_app_param('url', '')));
        $row = bm_app_find_db_movie_row($identifier);
        $movieId = $row && !empty($row['id']) ? (int)$row['id'] : 0;
        $links = $movieId > 0 ? bm_app_downloads_from_db_movie($movieId) : array();
        $imdb = $row['imdb_code'] ?? ($row['imdb'] ?? ($row['imdb_id'] ?? null));
        $sourceMovieIds = array();
        $htmlSources = array();
        foreach ($links as $l) {
            if (isset($l['source_movie_id'])) $sourceMovieIds[] = (int)$l['source_movie_id'];
            if (!empty($l['html_source_url'])) $htmlSources[] = (string)$l['html_source_url'];
        }
        $sourceMovieIds = array_values(array_unique(array_filter($sourceMovieIds)));
        $htmlSources = array_values(array_unique(array_filter($htmlSources)));
        bm_app_json(array(
            'status'=>'success',
            'action'=>'debug_links',
            'input'=>$identifier,
            'public_id'=>bm_app_public_id_from_identifier($identifier),
            'database'=>bm_app_current_database_name(),
            'resolved_movie_id'=>$movieId,
            'resolved_slug'=>$row['slug'] ?? ($row['source_slug'] ?? ($row['detail_id'] ?? null)),
            'resolved_imdb'=>$imdb,
            'html_candidates'=>$row ? bm_app_page_candidates_for_movie_row($row, $identifier) : array(),
            'html_sources'=>$htmlSources,
            'source_link_movie_ids'=>$sourceMovieIds,
            'diagnostics'=>$row ? bm_app_link_table_debug_counts($row, $movieId) : array(),
            'count'=>count($links),
            'links'=>$links
        ));
    }

    if ($action === 'actor') {
        $identifier = bm_app_param('slug', bm_app_param('actor', bm_app_param('url', '')));
        if (!bm_app_archive_runtime_ready('1')) {
            bm_app_json(array_merge(bm_app_archive_unavailable_payload('1', 'actor'), array('actor'=>array(), 'count'=>0)));
        }
        try {
            bm_app_json(array_merge(array('status'=>'success','action'=>'actor'), bm_app_actor_details($identifier)));
        } catch (Throwable $e) {
            error_log('BankMovie actor source failed: ' . $e->getMessage());
            bm_app_json(array_merge(bm_app_archive_unavailable_payload('1', 'actor'), array('actor'=>array(), 'count'=>0)));
        }
    }

    if ($action === 'detail' || $action === 'play') {
        $identifier = bm_app_param('id', bm_app_param('slug', bm_app_param('url', '')));
        $type = bm_app_param('type', '');
        $detailArchive = bm_app_is_db_archive($archive) ? '2' : ((string)$archive === '5' ? '5' : ((string)$archive === '4' ? '4' : ((string)$archive === '3' ? '3' : '1')));
        if (!bm_app_archive_runtime_ready($detailArchive)) {
            bm_app_json(array_merge(bm_app_archive_unavailable_payload($detailArchive, $action), array('id'=>$identifier)));
        }
        try {
            if (bm_app_is_serialblog_archive($archive)) {
                $detail = bm_app_serialblog_detail($identifier, $type);
            } else {
                $detail = bm_app_detail($detailArchive, $identifier, $type);
            }
        } catch (Throwable $e) {
            error_log('BankMovie detail source failed [' . $detailArchive . ']: ' . $e->getMessage());
            bm_app_json(array_merge(bm_app_archive_unavailable_payload($detailArchive, $action), array('id'=>$identifier)));
        }
        if ($action === 'play') {
            bm_app_json(array(
                'status' => 'success',
                'action' => 'play',
                'archive' => $detail['archive'],
                'id' => $detail['id'],
                'title' => $detail['title'],
                'title_fa' => $detail['title_fa'],
                'type' => $detail['type'],
                'poster' => $detail['poster'],
                'play' => $detail['play']
            ));
        }
        bm_app_json(array('status' => 'success', 'action' => 'detail', 'item' => $detail));
    }

    if ($action === 'notifications') {
        // Application-only Push fallback. This endpoint intentionally does NOT
        // read the website `notifications` table anymore.
        $items = array();
        $revokedIds = array();
        $error = '';
        try {
            require_once __DIR__ . '/config.php';
            if (isset($pdo) && $pdo instanceof PDO) {
                try { bm_push_legacy_cleanup($pdo, false, false); } catch (Throwable $ignored) {}
                $items = bm_push_poll_items($pdo, 30);
                $revokedIds = function_exists('bm_push_revoked_ids') ? bm_push_revoked_ids($pdo, 200) : array();
            }
        } catch (Throwable $e) {
            $error = $e->getMessage();
        }
        bm_app_json(array('status' => 'success', 'action' => 'notifications', 'count' => count($items), 'items' => $items, 'revoked_ids' => $revokedIds, 'debug_error' => $error));
    }

    bm_app_fail('اکشن نامعتبر است', 404, array('action' => $action));

} catch (Throwable $e) {
    bm_app_json(array(
        'status' => 'error',
        'message' => $e->getMessage(),
        'action' => isset($action) ? $action : '',
        'archive' => isset($archive) ? $archive : ''
    ), 500);
}
