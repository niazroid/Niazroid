BankMovie Desktop Media Fix 1.1.0

این بسته ادامه AUTHFIX قبلی است و علاوه بر احراز هویت Desktop، app_api.php را طوری به‌روزرسانی می‌کند که subtitle_url لینک‌های softsub در خروجی API حفظ شود.

تغییر contract فقط additive است:
- هیچ فیلد Android حذف یا rename نشده.
- فصل/قسمت فعلی همان play.seasons موجود باقی می‌ماند.
- به هر source در صورت وجود، subtitle_url و has_external_subtitle اضافه می‌شود.

برای سروری که AUTHFIX قبلی روی آن نصب شده، حداقل فایل لازم برای این مرحله app_api.php است.
قبل از جایگزینی از app_api.php فعلی backup بگیر.
