<?php
declare(strict_types=1);
// Desktop-only application signature. This is intentionally separate from Android.
const BM_DESKTOP_APP_KEY = 'bm_windows_v1_b3a9a48d9f35';
const BM_DESKTOP_APP_SECRET = '7addd06d74f3d8fc7734d05b9ab6790c19c7c4d1eb323ed9e2efb9cc96f473df';
