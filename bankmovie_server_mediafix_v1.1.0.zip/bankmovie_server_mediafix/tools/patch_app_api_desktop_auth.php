<?php
declare(strict_types=1);

$root = $argv[1] ?? dirname(__DIR__, 2);
$file = rtrim($root, '/\\') . DIRECTORY_SEPARATOR . 'app_api.php';
$auth = rtrim($root, '/\\') . DIRECTORY_SEPARATOR . 'includes' . DIRECTORY_SEPARATOR . 'desktop_app_auth.php';

if (!is_file($file)) { fwrite(STDERR, "app_api.php not found: {$file}\n"); exit(1); }
if (!is_file($auth)) { fwrite(STDERR, "desktop_app_auth.php not found: {$auth}\n"); exit(1); }

$src = (string)file_get_contents($file);
if (str_contains($src, "BM_DESKTOP_APP_KEY") && str_contains($src, "desktop_app_auth.php") && str_contains($src, "\$secret = BM_DESKTOP_APP_SECRET")) {
    echo "app_api.php is already patched for Desktop auth.\n";
    exit(0);
}

$backup = $file . '.pre-desktop-auth.bak';
if (!is_file($backup) && !copy($file, $backup)) {
    fwrite(STDERR, "Could not create backup: {$backup}\n"); exit(1);
}

$count = 0;
$src = preg_replace(
    "~(const\\s+BM_APP_AUTH_SECRET\\s*=\\s*'[^']+';\\s*)~",
    "$1\nrequire_once __DIR__ . '/includes/desktop_app_auth.php';\n",
    $src,
    1,
    $count
);
if ($count !== 1) { fwrite(STDERR, "Could not insert desktop auth include.\n"); exit(1); }

$old = <<<'OLD'
    if (!hash_equals(BM_APP_AUTH_KEY, $key) || $ts === '' || $sign === '') {
        bm_app_json(array('status' => 'error', 'message' => 'Unauthorized'), 401);
    }
OLD;
$new = <<<'NEW'
    $secret = null;
    if (hash_equals(BM_APP_AUTH_KEY, $key)) {
        $secret = BM_APP_AUTH_SECRET;
    } elseif (defined('BM_DESKTOP_APP_KEY') && defined('BM_DESKTOP_APP_SECRET') && hash_equals(BM_DESKTOP_APP_KEY, $key)) {
        $secret = BM_DESKTOP_APP_SECRET;
    }

    if ($secret === null || $ts === '' || $sign === '') {
        bm_app_json(array('status' => 'error', 'message' => 'Unauthorized'), 401);
    }
NEW;
if (!str_contains($src, $old)) { fwrite(STDERR, "Expected auth block not found; no changes written.\n"); exit(1); }
$src = str_replace($old, $new, $src, $replaced1);
$src = str_replace(
    "hash_hmac('sha256', \$ts . '|' . \$pathQuery, BM_APP_AUTH_SECRET)",
    "hash_hmac('sha256', \$ts . '|' . \$pathQuery, \$secret)",
    $src,
    $replaced2
);
if ($replaced1 !== 1 || $replaced2 !== 1) { fwrite(STDERR, "Signature patch failed; no changes written.\n"); exit(1); }

$src = str_replace(
    'X-BM-Client-Version, X-BM-Download-System',
    'X-BM-Client-Version, X-BM-Client, X-BM-Download-System',
    $src
);

if (file_put_contents($file, $src) === false) { fwrite(STDERR, "Could not write {$file}\n"); exit(1); }
echo "Patched app_api.php for Desktop HMAC auth. Backup: {$backup}\n";
