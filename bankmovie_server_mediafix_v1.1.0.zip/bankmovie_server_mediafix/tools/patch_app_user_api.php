<?php
declare(strict_types=1);
// Run from CLI once: php server/tools/patch_app_user_api.php /path/to/site
if (PHP_SAPI !== 'cli') { fwrite(STDERR,"CLI only\n"); exit(2); }
$root=rtrim((string)($argv[1]??dirname(__DIR__,2)),'/\\');$file=$root.'/app_user_api.php';$auth=$root.'/includes/desktop_app_auth.php';
if(!is_file($file)||!is_file($auth)){fwrite(STDERR,"app_user_api.php or desktop_app_auth.php not found\n");exit(2);} $src=(string)file_get_contents($file);
if(str_contains($src,"desktop_app_auth.php")&&str_contains($src,"BM_DESKTOP_APP_KEY")){echo "Already patched\n";exit(0);} @copy($file,$file.'.pre-windows.bak');
$src=preg_replace("~(const\\s+BM_USER_APP_SECRET\\s*=\\s*'[^']+';\\s*)~","$1\nrequire_once __DIR__ . '/includes/desktop_app_auth.php';\n",$src,1,$c1);
$needle="    if (!hash_equals(BM_USER_APP_KEY, \$key) || \$ts === '' || \$signature === '') {\n        bm_user_api_error('Unauthorized', 401);\n    }";
$replacement="    \$secret = null;\n    if (hash_equals(BM_USER_APP_KEY, \$key)) {\n        \$secret = BM_USER_APP_SECRET;\n    } elseif (defined('BM_DESKTOP_APP_KEY') && defined('BM_DESKTOP_APP_SECRET') && hash_equals(BM_DESKTOP_APP_KEY, \$key)) {\n        \$secret = BM_DESKTOP_APP_SECRET;\n    }\n\n    if (\$secret === null || \$ts === '' || \$signature === '') {\n        bm_user_api_error('Unauthorized', 401);\n    }";
$src2=str_replace($needle,$replacement,$src,$c2);$src2=str_replace("hash_hmac('sha256', \$ts . '|' . \$pathQuery, BM_USER_APP_SECRET)","hash_hmac('sha256', \$ts . '|' . \$pathQuery, \$secret)",$src2,$c3);
if(!$c1||!$c2||!$c3){fwrite(STDERR,"Patch pattern did not match. No file changed.\n");exit(3);} if(file_put_contents($file,$src2,LOCK_EX)===false){fwrite(STDERR,"Write failed\n");exit(4);} echo "Patched app_user_api.php; backup: app_user_api.php.pre-windows.bak\n";
