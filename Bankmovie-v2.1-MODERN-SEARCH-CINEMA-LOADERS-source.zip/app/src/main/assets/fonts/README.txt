Irancell font binaries are intentionally not stored in this source ZIP.
During GitHub Actions, prepare-irancell-font.sh reads the exact repository-root file:

irancell [@fontbazi].zip

and installs these runtime assets:
- irancell_regular.ttf
- irancell_medium.ttf
- irancell_semibold.ttf
- irancell_bold.ttf
- irancell_black.ttf
