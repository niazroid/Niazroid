package ir.bankmoviee.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

object BankmovieFonts {
    private val cache = linkedMapOf<String, Typeface>()

    @Synchronized
    private fun asset(context: Context, fileName: String, fallback: () -> Typeface): Typeface {
        cache[fileName]?.let { return it }
        val loaded = runCatching {
            val downloaded = java.io.File(context.filesDir, "fonts/$fileName")
            if (downloaded.isFile && downloaded.length() > 1024L) {
                Typeface.createFromFile(downloaded)
            } else {
                Typeface.createFromAsset(context.assets, "fonts/$fileName")
            }
        }.getOrElse { fallback() }
        cache[fileName] = loaded
        return loaded
    }

    fun regular(context: Context): Typeface = asset(context, "irancell_regular.ttf") {
        Typeface.create("sans-serif", Typeface.NORMAL)
    }

    fun medium(context: Context): Typeface = asset(context, "irancell_medium.ttf") {
        regular(context)
    }

    fun semiBold(context: Context): Typeface = asset(context, "irancell_semibold.ttf") {
        Typeface.create(regular(context), Typeface.BOLD)
    }

    fun bold(context: Context): Typeface = asset(context, "irancell_bold.ttf") {
        semiBold(context)
    }

    fun black(context: Context): Typeface = asset(context, "irancell_black.ttf") {
        bold(context)
    }

    fun applyToTree(context: Context, view: View) {
        if (UiPreferences.appFontMode(context) != "font") return
        fun walk(node: View) {
            if (node is TextView) {
                val oldStyle = node.typeface?.style ?: Typeface.NORMAL
                node.typeface = when {
                    oldStyle and Typeface.BOLD != 0 -> bold(context)
                    else -> regular(context)
                }
            }
            if (node is ViewGroup) {
                for (i in 0 until node.childCount) walk(node.getChildAt(i))
            }
        }
        walk(view)
    }
}
