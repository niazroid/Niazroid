package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Lightweight cinema-face loader inspired by the supplied Uiverse loader.
 * It is drawn entirely on one Canvas, so it stays smooth on weaker phones.
 */
class PremiumLoaderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private val density = resources.displayMetrics.density
    private val lowEnd = DeviceProfile.isLowEnd(context)

    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val eyeGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val ringMatrix = Matrix()
    private var ringShader: SweepGradient? = null
    private val ringRect = RectF()
    private val mouthRect = RectF()

    private var phase = 0f
    private var animator: ValueAnimator? = null

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    fun start() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (lowEnd) 3400L else 3000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                phase = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    fun stop() {
        animator?.cancel()
        animator = null
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val accent = UiPreferences.accentColor(context)
        val accentSoft = UiPreferences.blend(accent, Color.WHITE, 0.44f)
        ringShader = SweepGradient(
            cx,
            cy,
            intArrayOf(Color.TRANSPARENT, accent, accentSoft, Color.TRANSPARENT),
            floatArrayOf(0f, 0.22f, 0.67f, 1f)
        )
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        if (size <= 0f) return

        val palette = UiPreferences.palette(context)
        val accent = palette.primary
        val accentSoft = UiPreferences.blend(accent, Color.WHITE, 0.52f)
        val cx = width / 2f
        val cy = height / 2f
        val stroke = (size * 0.047f).coerceAtLeast(1.6f * density)
        val outerRadius = size * 0.405f

        trackPaint.strokeWidth = stroke
        trackPaint.color = Color.argb(if (palette.light) 34 else 50, Color.red(palette.muted), Color.green(palette.muted), Color.blue(palette.muted))
        ringPaint.strokeWidth = stroke
        ringPaint.shader = ringShader
        ringMatrix.setRotate(phase * 360f, cx, cy)
        ringShader?.setLocalMatrix(ringMatrix)

        ringRect.set(cx - outerRadius, cy - outerRadius, cx + outerRadius, cy + outerRadius)
        canvas.drawArc(ringRect, 0f, 360f, false, trackPaint)
        canvas.drawArc(ringRect, 8f, 255f, false, ringPaint)

        // The two eyes follow separate orbital curves and one performs a soft blink.
        val orbit = size * 0.245f
        val eyeRadius = size * 0.058f
        val eye1Angle = Math.toRadians(lerp(-260f, 225f, smooth(phase)).toDouble())
        val eye2Progress = if (phase < 0.5f) phase / 0.5f else (phase - 0.5f) / 0.5f
        val eye2AngleDeg = if (phase < 0.5f) lerp(-260f, 40f, smooth(eye2Progress)) else lerp(40f, 150f, smooth(eye2Progress))
        val eye2Angle = Math.toRadians(eye2AngleDeg.toDouble())

        val eye1X = cx + cos(eye1Angle).toFloat() * orbit
        val eye1Y = cy + sin(eye1Angle).toFloat() * orbit
        val eye2X = cx + cos(eye2Angle).toFloat() * orbit
        val eye2Y = cy + sin(eye2Angle).toFloat() * orbit

        eyeGlowPaint.strokeWidth = size * 0.022f
        eyeGlowPaint.color = Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawCircle(eye1X, eye1Y, eyeRadius * 1.55f, eyeGlowPaint)
        canvas.drawCircle(eye2X, eye2Y, eyeRadius * 1.55f, eyeGlowPaint)

        eyePaint.color = accentSoft
        val eye1Scale = if (phase > 0.82f) lerp(1f, 0.42f, (phase - 0.82f) / 0.18f) else 1f
        canvas.save()
        canvas.scale(eye1Scale, eye1Scale, eye1X, eye1Y)
        canvas.drawCircle(eye1X, eye1Y, eyeRadius, eyePaint)
        canvas.restore()

        val blinkDistance = abs(phase - 0.535f)
        val blinkY = if (blinkDistance < 0.035f) (blinkDistance / 0.035f).coerceIn(0.08f, 1f) else 1f
        canvas.save()
        canvas.scale(1f, blinkY, eye2X, eye2Y)
        canvas.drawCircle(eye2X, eye2Y, eyeRadius, eyePaint)
        canvas.restore()

        // The mouth alternates between two flowing arcs, matching the cinematic face motion.
        mouthPaint.strokeWidth = size * 0.052f
        mouthPaint.color = if (palette.light) UiPreferences.blend(accent, Color.BLACK, 0.12f) else accentSoft
        val mouthW = size * 0.48f
        val mouthH = size * 0.30f
        mouthRect.set(cx - mouthW / 2f, cy - mouthH / 2f + size * 0.075f, cx + mouthW / 2f, cy + mouthH / 2f + size * 0.075f)
        val mouthCycle = (phase * 2f) % 1f
        val sweep = 65f + 155f * sin(mouthCycle * PI).toFloat().coerceAtLeast(0f)
        val start = if (phase < 0.5f) 18f + phase * 300f else 202f + (phase - 0.5f) * 300f
        canvas.drawArc(mouthRect, start, sweep, false, mouthPaint)

        // Tiny center pulse gives the loader a polished, alive feel without extra views.
        val pulse = 0.45f + 0.55f * ((sin(phase * PI * 2.0) + 1.0) / 2.0).toFloat()
        eyePaint.color = Color.argb((32 + 42 * pulse).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawCircle(cx, cy, size * (0.035f + 0.012f * pulse), eyePaint)

        ringPaint.shader = null
    }

    private fun lerp(a: Float, b: Float, t: Float): Float = a + (b - a) * t.coerceIn(0f, 1f)

    private fun smooth(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }
}
