package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.LinearInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min

/**
 * Search-specific loader based on the supplied rotating orb + animated letters.
 * Uses one animator for all letters and one tiny Canvas orb to keep allocations low.
 */
class ModernSearchLoaderView(
    context: Context,
    label: String = "Searching"
) : LinearLayout(context) {

    private val density = resources.displayMetrics.density
    private val lowEnd = DeviceProfile.isLowEnd(context)
    private val letters = mutableListOf<TextView>()
    private var waveAnimator: ValueAnimator? = null

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        layoutDirection = View.LAYOUT_DIRECTION_LTR
        isClickable = false
        isFocusable = false
        contentDescription = label

        addView(SearchOrbView(context), LayoutParams(dp(27), dp(27)).apply {
            marginEnd = dp(10)
        })

        val letterBox = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
        }
        label.forEach { character ->
            val letter = TextView(context).apply {
                text = character.toString()
                setTextColor(UiPreferences.palette(context).text)
                textSize = 14.6f
                gravity = Gravity.CENTER
                includeFontPadding = false
                typeface = if (UiPreferences.appFontMode(context) == "font") {
                    BankmovieFonts.semiBold(context)
                } else {
                    Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                alpha = 0.42f
            }
            letters += letter
            letterBox.addView(letter, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(31)).apply {
                marginEnd = dp(1)
            })
        }
        addView(letterBox, LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(34)))
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        startWave()
    }

    override fun onDetachedFromWindow() {
        waveAnimator?.cancel()
        waveAnimator = null
        super.onDetachedFromWindow()
    }

    private fun startWave() {
        if (waveAnimator?.isRunning == true || letters.isEmpty()) return
        waveAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (lowEnd) 2300L else 2000L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { animation ->
                val progress = animation.animatedValue as Float
                val travel = progress * (letters.size + 5f) - 2f
                letters.forEachIndexed { index, letter ->
                    val direct = abs(travel - index)
                    val wrapped = min(direct, abs(travel - index - (letters.size + 5f)))
                    val intensity = exp(-(wrapped * wrapped) / 1.45f).toFloat().coerceIn(0f, 1f)
                    letter.alpha = 0.40f + 0.60f * intensity
                    val scale = 1f + 0.15f * intensity
                    letter.scaleX = scale
                    letter.scaleY = scale
                    letter.translationY = -dp(2).toFloat() * intensity
                }
            }
            start()
        }
    }

    private fun dp(value: Int): Int = (value * density + 0.5f).toInt()

    private class SearchOrbView(context: Context) : View(context) {
        private val density = resources.displayMetrics.density
        private val lowEnd = DeviceProfile.isLowEnd(context)
        private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
        }
        private val highlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
        private val rect = RectF()
        private val matrix = Matrix()
        private var shader: SweepGradient? = null
        private var rotation = 0f
        private var pulse = 0f
        private var animator: ValueAnimator? = null

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            if (animator?.isRunning == true) return
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = if (lowEnd) 1800L else 1500L
                repeatCount = ValueAnimator.INFINITE
                interpolator = LinearInterpolator()
                addUpdateListener {
                    val p = it.animatedValue as Float
                    rotation = 90f + p * 360f
                    pulse = p
                    invalidate()
                }
                start()
            }
        }

        override fun onDetachedFromWindow() {
            animator?.cancel()
            animator = null
            super.onDetachedFromWindow()
        }

        override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
            super.onSizeChanged(w, h, oldw, oldh)
            val accent = UiPreferences.accentColor(context)
            val pink = UiPreferences.blend(accent, Color.rgb(255, 95, 159), 0.42f)
            val blue = UiPreferences.blend(accent, Color.rgb(40, 169, 255), 0.38f)
            shader = SweepGradient(
                w / 2f,
                h / 2f,
                intArrayOf(Color.WHITE, pink, accent, blue, Color.WHITE),
                null
            )
        }

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val size = min(width, height).toFloat()
            if (size <= 0f) return
            val cx = width / 2f
            val cy = height / 2f
            val radius = size * 0.39f
            rect.set(cx - radius, cy - radius, cx + radius, cy + radius)

            val palette = UiPreferences.palette(context)
            val accent = palette.primary
            val backgroundMix = if (pulse in 0.34f..0.68f) 0.28f else 0.12f
            orbPaint.color = UiPreferences.blend(Color.TRANSPARENT, accent, backgroundMix)
            canvas.drawCircle(cx, cy, radius, orbPaint)

            rimPaint.strokeWidth = (size * 0.16f).coerceAtLeast(1.5f * density)
            rimPaint.shader = shader
            matrix.setRotate(rotation, cx, cy)
            shader?.setLocalMatrix(matrix)
            canvas.drawArc(rect, 0f, 300f, false, rimPaint)
            rimPaint.shader = null

            highlightPaint.color = Color.argb(185, 255, 255, 255)
            canvas.drawCircle(cx - radius * 0.27f, cy - radius * 0.31f, size * 0.075f, highlightPaint)
            highlightPaint.color = Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent))
            canvas.drawCircle(cx + radius * 0.18f, cy + radius * 0.22f, size * 0.19f, highlightPaint)
        }
    }
}
