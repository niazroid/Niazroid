#!/usr/bin/env bash
set -euo pipefail

FONT_DIR="app/src/main/assets/fonts"
FONT_ZIP="../irancell [@fontbazi].zip"
mkdir -p "$FONT_DIR"

install_from_user_zip() {
  test -f "$FONT_ZIP"
  local temp_dir
  temp_dir="$(mktemp -d)"
  unzip -P fontbazi -q "$FONT_ZIP" -d "$temp_dir"
  cp "$temp_dir/Irancell1 [@fontbazi].ttf" "$FONT_DIR/irancell_bold.ttf"
  cp "$temp_dir/Irancell2 [@fontbazi].ttf" "$FONT_DIR/irancell_regular.ttf"
  cp "$temp_dir/Irancell3 [@fontbazi].ttf" "$FONT_DIR/irancell_black.ttf"
  cp "$temp_dir/Irancell4 [@fontbazi].ttf" "$FONT_DIR/irancell_semibold.ttf"
  cp "$temp_dir/Irancell5 [@fontbazi].ttf" "$FONT_DIR/irancell_medium.ttf"
  test -s "$FONT_DIR/irancell_regular.ttf"
  test -s "$FONT_DIR/irancell_medium.ttf"
  test -s "$FONT_DIR/irancell_semibold.ttf"
  test -s "$FONT_DIR/irancell_bold.ttf"
  test -s "$FONT_DIR/irancell_black.ttf"
  rm -rf "$temp_dir"
}

if [[ -f "$FONT_ZIP" ]]; then
  install_from_user_zip
  echo "Irancell fonts installed from irancell [@fontbazi].zip."
  exit 0
fi

# Backward-compatible fallback for repositories that still contain an older
# source ZIP with an embedded regular font.
for zip in ../Bankmovie-v2.1-*-source.zip; do
  [[ -f "$zip" ]] || continue
  if unzip -Z1 "$zip" 2>/dev/null | grep -qx 'app/src/main/assets/fonts/irancell_regular.ttf'; then
    unzip -p "$zip" 'app/src/main/assets/fonts/irancell_regular.ttf' > "$FONT_DIR/irancell_regular.ttf"
    if [[ -s "$FONT_DIR/irancell_regular.ttf" ]]; then
      cp "$FONT_DIR/irancell_regular.ttf" "$FONT_DIR/irancell_medium.ttf"
      cp "$FONT_DIR/irancell_regular.ttf" "$FONT_DIR/irancell_semibold.ttf"
      cp "$FONT_DIR/irancell_regular.ttf" "$FONT_DIR/irancell_bold.ttf"
      cp "$FONT_DIR/irancell_regular.ttf" "$FONT_DIR/irancell_black.ttf"
      echo "Irancell fallback restored from $(basename "$zip")."
      exit 0
    fi
  fi
done

rm -f "$FONT_DIR"/irancell_*.ttf
echo "Required file not found at repository root: irancell [@fontbazi].zip" >&2
exit 1
