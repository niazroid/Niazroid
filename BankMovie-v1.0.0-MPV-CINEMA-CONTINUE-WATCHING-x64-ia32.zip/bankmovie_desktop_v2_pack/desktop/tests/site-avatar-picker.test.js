'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const dir=path.join(__dirname,'../src');
const read=f=>fs.readFileSync(path.join(dir,f),'utf8');
const catalog=vm.runInNewContext(read('site-avatar-catalog.js')+'\nBM_SITE_AVATARS');
assert.equal(catalog.length,166);assert.equal(new Set(catalog.map(a=>a.key)).size,166);
for(let i=1;i<=150;i++)assert.ok(catalog.some(a=>a.key===`actor_${String(i).padStart(3,'0')}`));
for(const a of catalog){assert.match(a.path,/^assets\/avatars\/[a-z0-9_]+\.webp$/);const img=fs.readFileSync(path.join(dir,a.path));assert.equal(img.toString('ascii',0,4),'RIFF');assert.equal(img.toString('ascii',8,12),'WEBP');}
const html=read('index.html'),picker=read('site-avatar-picker.js'),css=read('site-avatar-original.css');
for(const f of ['site-avatar-catalog.js','site-avatar-picker.js','site-avatar-original.css','site-avatar-desktop.css'])assert.ok(html.includes(f));
assert.match(html,/id="bmAvatarMenu"/);assert.match(picker,/save\('avatar_update',\{avatar_key:b\.dataset\.avatarKey\}\)/);assert.match(picker,/state\.user\.can_upload_avatar\?/);assert.match(picker,/if\(!r\?\.success\|\|!r\.user\)/);assert.match(css,/repeat\(4,minmax\(0,1fr\)\)/);assert.match(css,/@media\(max-width:680px\)/);
console.log('PASS: 166 local WebP presets, 150 actor keys, authenticated save, VIP upload distinction and website responsive CSS');
