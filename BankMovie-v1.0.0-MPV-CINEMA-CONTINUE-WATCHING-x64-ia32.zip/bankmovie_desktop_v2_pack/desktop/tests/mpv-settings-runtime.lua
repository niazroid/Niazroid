-- Windows CI only. Check actual property support and local settings load in staged MPV.
local mp=require 'mp'
local msg=require 'mp.msg'
local input=require 'mp.input'
assert(type(input.get)=='function','mp.input missing')
mp.register_event('file-loaded',function()
    assert(mp.get_property('sub-font')=='Tahoma','saved font was not restored')
    assert(mp.get_property_number('sub-font-size')==64,'saved font size was not restored')
    assert(mp.get_property('sub-ass-override')=='force','saved ASS preference was not restored')
    assert(mp.get_property('sub-border-style')=='background-box','saved background style was not restored')
    assert(mp.get_property('sub-color'):upper():sub(-6)=='FFFF00','saved color was not restored')
    local tracks=mp.get_property_native('track-list',{}) or {}
    local audio,sub={},{}
    for _,t in ipairs(tracks) do
        if t.type=='audio' then audio[#audio+1]=t.id elseif t.type=='sub' then sub[#sub+1]=t.id end
    end
    assert(#audio>=1 and #sub>=1,'missing real tracks in fixture')
    local originalAid=mp.get_property('aid')
    local originalSid=mp.get_property('sid')
    for _,id in ipairs(audio) do
        assert(mp.set_property('aid',tostring(id)))
        assert(mp.get_property('aid')==tostring(id),'audio selection not applied')
        assert(mp.get_property('sid')==originalSid,'audio changed subtitle selection')
    end
    assert(mp.set_property('aid',originalAid))
    assert(mp.set_property('sid','no'))
    assert(mp.get_property('sid')=='no' and mp.get_property('aid')==originalAid)
    for _,id in ipairs(sub) do
        assert(mp.set_property('sid',tostring(id)))
        assert(mp.get_property('sid')==tostring(id) and mp.get_property('aid')==originalAid,'subtitle changed audio selection')
    end
    assert(mp.set_property('sid',originalSid))
    assert(mp.set_property_number('sub-delay',0.1))
    assert(mp.set_property_number('audio-delay',0.1))
    assert(mp.set_property_number('sub-pos',90))
    assert(mp.set_property_number('sub-outline-size',3))
    assert(mp.set_property_number('sub-shadow-offset',2))
    assert(mp.set_property('sub-outline-color','#000000'))
    assert(mp.set_property('sub-back-color','#A6000000'))
    assert(mp.set_property('sub-bold','yes'))
    assert(mp.set_property('video-aspect-override','16:9'))
    assert(mp.set_property_number('video-zoom',0.1))
    assert(mp.set_property_number('panscan',1))
    msg.info('BM_SETTINGS_RUNTIME_OK')
end)
