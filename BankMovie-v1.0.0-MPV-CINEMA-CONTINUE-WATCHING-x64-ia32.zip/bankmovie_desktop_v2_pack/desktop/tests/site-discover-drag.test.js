'use strict';
const fs=require('node:fs'),assert=require('node:assert/strict'),vm=require('node:vm'),path=require('node:path');
const read=n=>fs.readFileSync(path.join(__dirname,'..',n),'utf8');
const src=read('src/app.js'),html=read('src/index.html'),main=read('electron/main.js'),preload=read('electron/preload.js'),css=read('src/styles.css');
const ctx=vm.createContext({esc:String,cleanUrl:String,img:()=>'<img>',itemTitle:x=>x.title,bmSiteSectionHeading:()=>'',bmSiteViewAll:()=>'<button data-home-collections>All</button>'});
vm.runInContext(src.slice(src.indexOf('function collectionSectionHtml('),src.indexOf('const _bm18RenderHome')),ctx);
const result=ctx.collectionSectionHtml(Array.from({length:14},(_,i)=>({slug:'c'+i,title:'C'+i,cover:'x'})));
assert.equal((result.match(/data-collection-open=/g)||[]).length,4);assert.match(result,/data-home-collections/);
assert.match(html,/data-header-view="discover"[\s\S]*?چی ببینیم؟/);assert.match(html,/src="poster-drag.js"/);assert.match(html,/src="native-discover.js"/);assert.match(src,/if\(view==='discover'\)return bmShowNativeDiscover\(\)/);assert.doesNotMatch(preload,/discover:open/);assert.doesNotMatch(main,/openDiscoverWindow/);assert.match(css,/background:transparent!important;border:0!important/);console.log('PASS: four homepage collections, native Discover route, no website child window, drag wiring');
