-- Windows CI: a real MPV seek into the bundled sample, then a normal quit.
local mp=require 'mp'
mp.register_event('playback-restart',function()
    mp.add_timeout(0.4,function()mp.commandv('quit')end)
end)
