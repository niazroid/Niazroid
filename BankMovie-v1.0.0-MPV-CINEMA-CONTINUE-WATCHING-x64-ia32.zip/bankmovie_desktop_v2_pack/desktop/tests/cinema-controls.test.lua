-- Isolated Lua control logic test; not a real MPV rendering or Windows test.
local bindings,events,commands={}, {}, {}
local props={pause=true,duration=3600,['time-pos']=60,volume=50,speed=1,['media-title']='Movie {unsafe}', aid='1',sid='1',['track-list']={{id=1,type='sub',lang='fas',codec='subrip',title='Film2Media - Namava'},{id=2,type='sub',lang='fas',codec='ass',title='Film2Media - Filimo'},{id=1,type='audio',lang='eng',codec='aac',title='Original'},{id=2,type='audio',lang='fas',codec='aac',title='Persian dub'}}}
local time,xx,yy,ow,oh=0,0,0,1280,720
local ov={update=function()end};local timer
local mp={create_osd_overlay=function()return ov end,get_time=function()return time end,get_osd_size=function()return ow,oh,ow/oh end,get_mouse_pos=function()return xx,yy end,get_property=function(n,d)return props[n] or d end,get_property_number=function(n,d)return props[n] or d end,get_property_bool=function(n,d)if props[n]==nil then return d end return props[n] end,get_property_native=function(n,d)return props[n] or d end,set_property=function(n,v)props[n]=v;return true end,set_property_bool=function(n,v)props[n]=v;return true end,set_property_number=function(n,v)props[n]=v;return true end,commandv=function(...)local a={...};commands[#commands+1]=a;if a[1]=='cycle' then props[a[2]]=not props[a[2]] end;return true end,add_forced_key_binding=function(k,n,f)bindings[k]=f end,register_event=function(k,f)events[k]=f end,observe_property=function()end,add_periodic_timer=function(_,f)timer=f end,osd_message=function()end}
local inputRequest
local filePath=os.tmpname();os.remove(filePath)
local prefsData, fileData
local originalOpen,originalGetenv=io.open,os.getenv
os.getenv=function(k)if k=='LOCALAPPDATA' then return 'test-local-appdata' end;return originalGetenv(k)end
io.open=function(p,mode) if p=='test-local-appdata/BankMovie-player-settings.json' then
  if mode=='wb' then return {write=function(_,v)fileData=v end,close=function()end} end
  if fileData then return {read=function()return fileData end,close=function()end} end
  return nil
end;return originalOpen(p,mode)end
package.loaded['mp.utils']={format_json=function(t)prefsData={};for k,v in pairs(t)do prefsData[k]=v end;return 'mock-json' end,parse_json=function()return prefsData end,file_info=function(p)if p=='C:\\movie.srt' then return {is_file=true} elseif p=='C:\\' then return {is_dir=true} end end,readdir=function(p,t) if p=='C:\\' and t=='files' then return {'movie.srt','ignore.exe'} end;return {} end}
package.loaded['mp.input']={get=function(o)inputRequest=o end}
mp.remove_key_binding=function(n)end
package.loaded.mp=mp
mp.set_property_native=function(n,v)props[n]=v;return true end

dofile('player/cinema.lua')
local function click(x,y)xx,yy=x,y;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});bindings.MBTN_LEFT({event='up'})end
local function geometry()local sc=math.min(ow/760,oh/480,1.15);return ow/sc,oh/sc,sc end
local function at(x,y)local _,_,sc=geometry();click(x*sc,y*sc)end
local function geomPanel(count)
    local w,h=geometry();local shown=math.min(count,math.max(1,math.floor((h-152)/52)))
    local mw=math.min(390,w-32);local mx=w-mw-18;local my=h-75-(52+shown*52+10)
    return mx,my,mw,shown
end
local function rowAt(count,i,offset)local mx,my,mw=geomPanel(count);at(mx+mw-90,my+52+(i-1-(offset or 0))*52+26)end
local function barAt(count,i,start,endv,offset)
    local mx,my,mw=geomPanel(count);local x=mx+14+94;local width=mw-26-116;local y=my+52+(i-1-(offset or 0))*52+2+48-14+2
    local _,_,sc=geometry();xx,yy=(x+width*start)*sc,y*sc;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});xx=(x+width*endv)*sc;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='up'})
end
local function swatchAt(count,i,j,total,offset)local mx,my,mw=geomPanel(count);at(mx+14+8+(j-.5)*(mw-26-16)/total,my+52+(i-1-(offset or 0))*52+34)end
local function snap(name) if os.getenv('BM_TEST_RENDER') then local f=originalOpen('/tmp/bm-ui-'..name..'.assdata','wb');f:write(ov.res_x..' '..ov.res_y..'\n'..ov.data);f:close()end end
local function scroll(n) for i=1,n do bindings.WHEEL_DOWN()end end
local function back()bindings.ESC()end
assert(ov.data:find('Movie',1,true));assert(not ov.data:find('{unsafe}',1,true));events['playback-restart']();timer()
local w,h=geometry();local cy=math.min(h*.48,h-126);local step=math.min(42,w*.055);local sx=w-30-step*4;local ax=sx-96
local function settings()at(w-30-step*3,h-26)end
at(w/2,cy);assert(props.pause==false);at(w/2,cy);assert(props.pause==true)
bindings.RIGHT();assert(commands[#commands][1]=='seek' and commands[#commands][2]==10)
at(w/2,h-56);assert(commands[#commands][1]=='seek' and commands[#commands][3]=='absolute-percent+exact')
at(sx-30,h-26);assert(ov.data:find('Film2Media - Namava',1,true));assert(not ov.data:find('Persian dub',1,true));snap('sub')
rowAt(5,3);assert(props.sid=='2' and props.aid=='1' and props['sub-visibility']==true)
rowAt(5,1);assert(props.sid=='no' and props.aid=='1')
at(ax-30,h-26);assert(ov.data:find('Persian dub',1,true));assert(not ov.data:find('Film2Media - Namava',1,true));rowAt(3,2);assert(props.aid=='2' and props.sid=='no');snap('audio')
back();assert(ov.data:find('تنظیمات پخش',1,true));snap('settings')
local accent=os.getenv('BM_PLAYER_ACCENT');if accent=='FFD54A' then assert(ov.data:find('4AD5FF',1,true))end
rowAt(12,3);rowAt(15,2);assert(props['sub-font']=='Tahoma');assert(prefsData['sub-font']=='Tahoma');back()
swatchAt(12,4,4,6);assert(props['sub-color']=='#FFD54A');swatchAt(12,4,6,6);snap('color');barAt(5,2,1,0);assert(props['sub-color']=='#00D54A');assert(prefsData['sub-color']=='#00D54A');back()
barAt(12,5,.2,.75);assert(props['sub-font-size']==81);assert(prefsData['sub-font-size']==81)
barAt(12,6,.9,.2);assert(props['sub-pos']==60);barAt(12,7,.5,.6);assert(math.abs(props['sub-delay']-1)<.01)
rowAt(12,8);rowAt(11,5);assert(props['sub-ass-override']=='force');barAt(11,7,.1,.5);assert(props['sub-outline-size']==3)
scroll(2);rowAt(11,10,2);rowAt(5,2);assert(props['sub-back-color']=='#A6000000');barAt(5,5,.6,.4);assert(props['sub-back-color']=='#66000000');back();back()
-- Subtitles file browser and audio delay are separate pages.
rowAt(12,2);rowAt(5,4);assert(ov.data:find('C:',1,true));rowAt(2,2);assert(ov.data:find('movie.srt',1,true) and not ov.data:find('ignore.exe',1,true));rowAt(3,3);assert(commands[#commands][1]=='sub-add' and commands[#commands][2]=='C:\\movie.srt');back()
rowAt(12,1);rowAt(3,3);barAt(5,1,.5,.6);assert(math.abs(props['audio-delay']-1)<.01);back();back()
barAt(12,9,.4,.8);assert(math.abs(props.speed-1.7)<.01);scroll(3);rowAt(12,10,3);rowAt(8,2);assert(props['video-aspect-override']=='16:9');barAt(8,6,0,.5);assert(props.panscan==.5);back()
scroll(3);rowAt(12,12,3);barAt(2,1,0,0);rowAt(2,2);time=301;props.pause=false;timer();assert(props.pause==true);back();back();time=0;timer()
at(70,h-26);at(34+104,h-88);assert(math.abs(props.volume-50)<1);at(70,h-26)
-- Floating mode preserves window state, does not spawn another process.
props['window-scale']=.8;props.dwidth=1920;props.ontop=false
at(w-30-step*2,h-26);assert(props.ontop==true and math.abs(props['window-scale']-420/1920)<.001);bindings.ESC();assert(props.ontop==false and props['window-scale']==.8)
at(w-30,h-26);assert(props.fullscreen==true);bindings.ESC();assert(props.fullscreen==false)
at(w-30-step,h-26);assert(not ov.data:find('Movie',1,true));bindings.ESC();assert(ov.data:find('Movie',1,true));assert(ov.data:find('\\p4',1,true))
props.pause=false;time=10;timer();assert(ov.data=='');bindings.MOUSE_MOVE();assert(ov.data~='')
for _,size in ipairs({{320,180},{640,360},{1920,1080},{800,600},{3440,1440},{1280,400}}) do ow,oh=size[1],size[2];timer();local w,h=geometry();local step=math.min(42,w*.055);at(w-30-step*3,h-26);assert(ov.data:find('تنظیمات پخش',1,true));local mx,my,mw=geomPanel(12);assert(my>=0 and mx>=0 and mx+mw<=w);back()end
props['sub-font']=nil;props['sub-color']=nil;dofile('player/cinema.lua');assert(props['sub-font']=='Tahoma' and props['sub-color']=='#00D54A')
io.open=originalOpen;os.getenv=originalGetenv
print('PASS: direct audio/subtitle menus, root appearance controls, drag rails, color, font, file browser, delays, picture, sleep, floating state, stored prefs, responsive layout')
