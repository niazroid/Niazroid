-- Test the production journal code, not a duplicate implementation.
local f=assert(io.open('player/cinema.lua','r'));local code=f:read('*a');f:close()
local snippet=assert(code:match('(local resumeDir=os.getenv%(\'BM_CONTINUE_DIR\'%).*)'))
local props={['time-pos']=0,duration=1800};local events,obs,timers,writes={},{},{},{}
local mp={get_property_number=function(k,default)return props[k] or default end,register_event=function(k,fn)events[k]=fn end,observe_property=function(k,_,fn)obs[k]=fn end,add_periodic_timer=function(t,fn)timers[t]=fn end}
local env=setmetatable({mp=mp,os={getenv=function()return 'test-dir' end},io={open=function(path)return {write=function(_,value)writes[path]=value end,close=function()end}end}},{__index=_G})
assert(load(snippet,'journal','t',env))()
assert(not next(writes))
props['time-pos']=735.456789;events['playback-restart']();assert(writes['test-dir/b']:match('735%.456789'))
props['time-pos']=736.25;timers[1]();assert(writes['test-dir/a']:match('736%.250000'))
props['time-pos']=30.125;obs['time-pos']('time-pos',30.125);obs.pause('pause',true);assert(writes['test-dir/b']:match('30%.125000'))
props['time-pos']=31.125;obs['time-pos']('time-pos',31.125);props['time-pos']=-1;events['end-file']({reason='quit'});events.shutdown();assert(writes['test-dir/b']:match('31%.125000'))
props['time-pos']=1799.8;events['playback-restart']();obs['eof-reached']('eof-reached',true);assert(writes['test-dir/b']:match('1800%.000000 1800%.000000 1'))
print('PASS native Lua journal: precise time, periodic checkpoint, pause, quit after property teardown, actual EOF')
