// Runs only in Windows CI with the verified engine staged, before packaging.
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const P = require('../electron/mpv-player');
assert.equal(process.platform, 'win32', 'Windows runtime test');
const root = path.resolve(__dirname, '..');
const p = P.bundledPlayer('', false, root);
assert.ok(p, 'Bundled MPV is staged');
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bm-mpv-runtime-'));
try {
  fs.writeFileSync(path.join(dir,'BankMovie-player-settings.json'), JSON.stringify({'sub-font':'Tahoma','sub-font-size':64,'sub-ass-override':'force','sub-border-style':'background-box','sub-color':'#FFFF00'}));
  const cases = [
    {file:'mpv-smoke.mkv', video:/h264|avc/i, sub:/subrip|srt/i, aid:1},
    {file:'mpv-smoke-hevc-ass.mkv', video:/hevc|h265/i, sub:/ass/i, aid:2}
  ];
  for (const c of cases) {
    const log = path.join(dir, c.file+'.log');
    const args = P.argsFor(p, path.join(__dirname,c.file), {}, true);
    args.splice(args.length-2,0,'--vo=null','--ao=null','--hwdec=no','--force-window=no','--keep-open=no','--frames=24','--sid=1','--aid='+c.aid,'--log-file='+log,'--script='+path.join(__dirname,'mpv-settings-runtime.lua'));
    const result = spawnSync(p.path,args,{cwd:path.dirname(p.path),windowsHide:true,timeout:30000,stdio:'ignore',env:{...process.env,LOCALAPPDATA:dir}});
    assert.ifError(result.error);
    assert.equal(result.status,0,`${c.file}: MPV runtime exited cleanly`);
    const output=fs.readFileSync(log,'utf8');
    assert.match(output,c.video,`${c.file}: video codec detected`);
    assert.match(output,c.sub,`${c.file}: embedded subtitle detected`);
    assert.match(output,/aac/i,`${c.file}: audio detected`);
    assert.match(output,/VO:\s*\[null\]/i,`${c.file}: decoded video output initialized`);
    assert.match(output,/AO:\s*\[null\]/i,`${c.file}: decoded audio output initialized`);
    assert.match(output,/BM_SETTINGS_RUNTIME_OK/,`${c.file}: settings restored and applied in actual MPV`);
    assert.doesNotMatch(output,/Error parsing option|Lua error|stack traceback|Error opening\/initializing|Failed to open.*mpv-smoke|Failed to initialize (?:a |the )?decoder/i);
    console.log('PASS: Windows MPV headless decoding and tracks: '+c.file);
  }
  const progressDir=path.join(dir,'continue-journal');fs.mkdirSync(progressDir);
  const resumeArgs=P.argsFor(p,path.join(__dirname,'mpv-smoke.mkv'),{start:0.6},true);
  resumeArgs.splice(resumeArgs.length-2,0,'--vo=null','--ao=null','--hwdec=no','--force-window=no','--keep-open=no','--pause=yes','--script='+path.join(__dirname,'mpv-continue-runtime.lua'));
  const resumeResult=spawnSync(p.path,resumeArgs,{cwd:path.dirname(p.path),windowsHide:true,timeout:30000,stdio:'ignore',env:{...process.env,LOCALAPPDATA:dir,BM_CONTINUE_DIR:progressDir}});
  assert.ifError(resumeResult.error);assert.equal(resumeResult.status,0);
  const saved=require('../electron/continue-watching').readCheckpoint(progressDir);
  assert.ok(saved,'MPV produced a native checkpoint');assert.ok(!saved.done,'normal quit is not EOF');assert.ok(Math.abs(saved.position-0.6)<0.15,`real resume position: ${saved.position}`);
  console.log('PASS: Windows MPV seek and continue-watching checkpoint');
} finally {fs.rmSync(dir,{recursive:true,force:true});}
