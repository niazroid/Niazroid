'use strict';
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),vm=require('node:vm');
const src=fs.readFileSync(path.join(__dirname,'../src/app.js'),'utf8'),css=fs.readFileSync(path.join(__dirname,'../src/styles.css'),'utf8'),lua=fs.readFileSync(path.join(__dirname,'../player/cinema.lua'),'utf8');
const ctx={esc:s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/"/g,'&quot;'),bmSiteHomeCard:()=>'<article></article>'};vm.createContext(ctx);
vm.runInContext(src.slice(src.indexOf('const BM_SITE_SECTION_ART='),src.indexOf('function sectionPolicy(')),ctx);
const types={updated_movies:'movie',new_series:'series',updated_animations:'animation',updated_anime:'anime',dubbed_series:'dub',korean_series:'korea',chinese_series:'china',turkish_series:'turkey',indian_movies:'india',popular:'popular',top_2026:'top',collections:'collections',subtitled_series:'series'};
for(const [section,kind] of Object.entries(types)){
 assert.equal(ctx.bmSiteSectionKind(section),kind);
 for(let archive=1;archive<=5;archive++){
  const html=ctx.sectionHtml('نمونه <عنوان>',[{}],archive,section);assert.match(html,new RegExp(`bm-site-section-${kind}`));assert.match(html,/نمونه &lt;عنوان>/);assert.doesNotMatch(html,/<small>|هاردساب|آرشیو/);assert.match(html,new RegExp(`data-archive="${archive}"`));
  const asset=html.match(/src="(assets\/site-section\/[^\"]+)"/)[1];assert.ok(fs.existsSync(path.join(__dirname,'../src',asset)),asset);
 }
}
assert.equal(ctx.sectionHtml('empty',[],1,'anime'),'');
vm.runInContext(src.slice(src.indexOf('function bmSitePosterMedia('),src.lastIndexOf('card=function(it){')),ctx);
assert.equal(ctx.bmSitePosterMedia({has_dubbed:'0',has_subtitle:false},false),'');assert.match(ctx.bmSitePosterMedia({has_dubbed:'1',has_subtitle:true},false),/dub[\s\S]*sub/);
assert.match(src,/const detail=\$\('#view \.detail-hero'\)/);assert.match(css,/body:has\(#view \.detail-hero\):not\(\.header-scrolled\) #appHeader/);assert.match(fs.readFileSync(path.join(__dirname,'../src/site-home-original.css'),'utf8'),/width:172px !important/);assert.match(lua,/P\.bounds=\{x=x,y=y,w=tw,h=th\}[\s\S]*?P\.avatar\(m\.avatar,ax,y\+15,36\)/);
console.log('PASS: all five archives share site heading art, no repeated descriptions, explicit media flags, detail header and toast avatar wiring');
const originalCss=fs.readFileSync(path.join(__dirname,'../src/site-home-original.css'),'utf8');
for(const token of ['.bm-update-heading .bm-update-badge','.bm-genre-neon-heading .bm-genre-neon-badge','.bm-feature-neon-heading .bm-feature-neon-frame','.scroll-card-title-fa','.scroll-card-info','@scope (.home-content)'])assert.ok(originalCss.includes(token),token);
assert.match(ctx.bmSiteSectionHeading('Movies','updated_movies'),/bm-update-heading[\s\S]*bm-update-glyph[\s\S]*bm-update-new/);
assert.match(ctx.bmSiteSectionHeading('Dub','dubbed'),/bm-genre-neon-heading[\s\S]*bm-genre-neon-icon/);
assert.match(ctx.bmSiteSectionHeading('Anime','anime'),/bm-feature-neon-heading[\s\S]*bm-anime-art-icon/);
assert.match(src,/class="scroll-card movie-card" data-card/);
assert.match(src,/class="scroll-card-poster bm-poster-img"|img\(poster,title,'scroll-card-poster bm-poster-img'\)/);
assert.match(fs.readFileSync(path.join(__dirname,'../src/index.html'),'utf8'),/href="site-home-original.css"/);
console.log('PASS: original website component classes and CSS bundle are wired into all home archives');
