/* Mouse-only grab scrolling. Touch, wheel, keyboard and scrollbar keep native behavior. */
(()=>{
  'use strict';
  const selector='.scroll-horizontal,.rail,.actor-rail';
  let gesture=null,suppress=null;
  function end(e,blockClick){
    if(!gesture||e.pointerId!==gesture.id)return;
    const g=gesture;gesture=null;
    if(g.dragging){
      g.rail.classList.remove('bm-poster-dragging');
      if(blockClick)suppress={rail:g.rail,until:performance.now()+450};
      if(g.rail.hasPointerCapture?.(g.id))g.rail.releasePointerCapture(g.id);
    }
  }
  document.addEventListener('pointerdown',e=>{
    if(e.pointerType!=='mouse'||e.button!==0||!e.isPrimary)return;
    suppress=null;
    const rail=e.target.closest?.(selector);
    if(!rail||rail.closest('.collections-section')||rail.scrollWidth<=rail.clientWidth+1)return;
    if(e.target.closest('input,textarea,select,[contenteditable]'))return;
    // Ignore native scrollbar gutter.
    const r=rail.getBoundingClientRect();
    if(e.clientY>=r.top+rail.clientTop+rail.clientHeight)return;
    gesture={rail,id:e.pointerId,x:e.clientX,y:e.clientY,left:rail.scrollLeft,dragging:false};
  },true);
  document.addEventListener('pointermove',e=>{
    const g=gesture;if(!g||e.pointerId!==g.id)return;
    if(!(e.buttons&1)){end(e,false);return;}
    const dx=e.clientX-g.x,dy=e.clientY-g.y;
    if(!g.dragging){
      if(Math.abs(dy)>10&&Math.abs(dy)>Math.abs(dx)){end(e,false);return;}
      if(Math.abs(dx)<7||Math.abs(dx)<Math.abs(dy))return;
      g.dragging=true;g.rail.classList.add('bm-poster-dragging');
      try{g.rail.setPointerCapture(g.id);}catch{}
    }
    e.preventDefault();
    // CSSOM scrollLeft works in both RTL (negative) and LTR in Chromium.
    g.rail.scrollLeft=g.left-dx;
  },{capture:true,passive:false});
  document.addEventListener('pointerup',e=>end(e,true),true);
  document.addEventListener('pointercancel',e=>end(e,false),true);
  document.addEventListener('lostpointercapture',e=>end(e,false),true);
  window.addEventListener('blur',()=>{if(gesture)end({pointerId:gesture.id},false);suppress=null;});
  document.addEventListener('dragstart',e=>{if(e.target.closest?.(selector))e.preventDefault();},true);
  document.addEventListener('click',e=>{
    if(suppress&&performance.now()<=suppress.until&&suppress.rail.contains(e.target)&&e.detail!==0){e.preventDefault();e.stopImmediatePropagation();suppress=null;}
  },true);
})();
