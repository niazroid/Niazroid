/* BankMovie personalized watchlist recommendations — isolated from core Discover scripts. */
(()=>{'use strict';
const root=document.querySelector('#bmfy');if(!root)return;
const boot=window.BMFY_BOOT||{};
const $=sel=>root.querySelector(sel);
const list=$('.bmfy-list'),status=$('.bmfy-status'),chips=$('.bmfy-chips'),counter=$('.bmfy-count');
const refresh=$('[data-bmfy-refresh]'),more=$('[data-bmfy-more]');
let pending=false,serial=0,page=1;
const icons={
 refresh:'<path d="M20 7v5h-5M4 17v-5h5M5.9 8A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.1-2"/>',
 heart:'<path d="M20.8 4.5a5.7 5.7 0 0 0-8.1 0l-.7.7-.7-.7a5.7 5.7 0 0 0-8.1 8.1L12 21l8.8-8.4a5.7 5.7 0 0 0 0-8.1Z"/>',
 seen:'<path d="M2 12s3.7-6 10-6 10 6 10 6-3.7 6-10 6-10-6-10-6Z"/><circle cx="12" cy="12" r="3"/>',
 less:'<path d="M4 4l16 16M9 5.5A10 10 0 0 1 12 5c6.3 0 10 7 10 7a19 19 0 0 1-3 3.5M6 8a17.5 17.5 0 0 0-4 4s3.7 7 10 7a9 9 0 0 0 4-.9"/>',
 sparkle:'<path d="m12 2 2.1 7.9L22 12l-7.9 2.1L12 22l-2.1-7.9L2 12l7.9-2.1L12 2Z"/>',
 arrow:'<path d="m14 6-6 6 6 6"/>',
 bookmark:'<path d="M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1Z"/>'
};
function svg(name){const s=document.createElementNS('http://www.w3.org/2000/svg','svg');s.setAttribute('viewBox','0 0 24 24');s.setAttribute('width','18');s.setAttribute('height','18');s.setAttribute('aria-hidden','true');s.setAttribute('stroke','currentColor');s.setAttribute('stroke-width','1.8');s.setAttribute('stroke-linecap','round');s.setAttribute('stroke-linejoin','round');s.setAttribute('fill','none');s.innerHTML=icons[name]||icons.sparkle;return s;}
function make(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e;}
const fmt=n=>Number(n||0).toLocaleString('fa-IR');
function safeLocal(u){if(typeof u!=='string'||!u.startsWith('/')||u.startsWith('//')||u.includes('..')||/[\x00-\x1f]/.test(u))return '';return u;}
function showMessage(msg){status.textContent=msg;status.hidden=false;}
function skeleton(){list.replaceChildren();for(let i=0;i<3;i++)list.append(make('div','bmfy-skeleton'));}

// Requests must always end in success or a useful error; do not leave skeletons stuck.
async function requestJSON(url,timeoutMs=14000){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),timeoutMs);
 try{
  const res=await fetch(url,{credentials:'same-origin',headers:{Accept:'application/json'},cache:'no-store',signal:controller.signal});
  const raw=await res.text();
  let data;try{data=JSON.parse(raw);}catch(_){const e=Error('invalid_json');e.code='invalid_json';e.http=res.status;throw e;}
  if(!res.ok||!data||!data.ok){const e=Error(String(data&&data.error||'server_error'));e.code=e.message;e.http=res.status;e.ref=data&&data.ref;throw e;}
  return data;
 }catch(e){if(e.name==='AbortError'){e.code='timeout';e.http=0;}throw e;}
 finally{clearTimeout(timer);}
}
async function loadRecommendations(pageNum){
 let primary;
 try{return {body:await requestJSON((boot.api||'/api_discover_for_you.php')+'?page='+pageNum),fromFallback:false};}
 catch(err){
  primary=err;
  // Never bypass a real permission, authentication or rate-limit denial.
  if([401,403,429].includes(Number(err.http)))throw err;
 }
 // The existing site Discover endpoint is a read-only, permission-checked fallback.
 // It does not claim personalized results when the new feature is unavailable.
 try{
  const url='/api_discover.php?mode=popular&page='+pageNum+'&per_page=9';
  const body=await requestJSON(url,12000);
  body.data=body.data||{};body.data.personalized=false;
  body.data.feedback_enabled=false;body.data.fallback=true;
  body.data.watchlist_count=0;body.data.genres=[];
  return {body,fromFallback:true,primaryError:primary};
 }catch(secondary){
  const e=Error('both_endpoints_failed');e.code='both_endpoints_failed';e.http=Number(primary&&primary.http)||Number(secondary.http)||0;
  e.primary=primary;e.secondary=secondary;throw e;
 }
}
function friendlyError(error){
 const e=error.primary||error;
 const code=String(e.code||e.message||'');
 const http=Number(e.http)||0;
 const ref=typeof e.ref==='string'&&/^[a-f0-9]{10}$/.test(e.ref)?' · شناسه خطا '+e.ref:'';
 if(http===404)return 'آدرس API پیشنهادهای شخصی پیدا نشد (404). فایل api_discover_for_you.php را در ریشه سایت بررسی کن.';
 if(http===403)return 'دسترسی به آرشیو موردنیاز فعال نیست (403).';
 if(http===429)return 'درخواست‌ها زیاد شده؛ یک دقیقه دیگر دوباره امتحان کن (429).';
 if(http===401)return 'برای دیدن پیشنهادهای شخصی وارد حساب شو (401).';
 if(http===503||http===500||http===502)return 'سرور پیشنهادها خطا داده (HTTP '+http+'). در لاگ PHP علت ثبت شده'+ref+'.';
 if(code==='timeout')return 'زمان پاسخ سرور طولانی شد. اتصال سایت یا اجرای API را بررسی کن.';
 if(code==='invalid_json')return 'API به‌جای JSON پاسخ غیرمنتظره داده؛ مسیر فایل و خطاهای PHP بررسی شود.';
 return 'ارتباط با پیشنهادها برقرار نشد'+(http?' (HTTP '+http+')':'')+'.';
}

function card(m,feedback){
 const c=make('article','bmfy-card');c.dataset.movieId=String(m.id);
 const a=make('a','bmfy-main');a.href=safeLocal(m.url)||'/search';a.setAttribute('aria-label','جزئیات '+(m.title||'فیلم'));
 const poster=make('span','bmfy-poster');
 if(safeLocal(m.poster)){const img=make('img');img.src=window.BMDesktopDiscover.asset(m.poster);img.loading='lazy';img.decoding='async';img.alt='پوستر '+(m.title||'');img.addEventListener('error',()=>poster.classList.add('bmfy-poster-empty'));poster.append(img);}else poster.classList.add('bmfy-poster-empty');
 const copy=make('span','bmfy-copy');
 const kicker=make('span','bmfy-kicker');kicker.append(svg('sparkle'),document.createTextNode('مناسب سلیقه تو'));
 const title=make('strong','bmfy-name',m.title||m.title_en||'بدون عنوان');
 const meta=make('span','bmfy-meta',[(m.type==='series'?'سریال':'فیلم'),m.year||''].filter(Boolean).join(' · '));
 const why=make('span','bmfy-why',m.why||'پیشنهادی از بانک‌مووی');
 copy.append(kicker,title,meta,why);a.append(poster,copy,svg('arrow'));
 const foot=make('div','bmfy-card-footer');
 if(Number(m.rating)>0){const score=make('span','bmfy-imdb',Number(m.rating).toFixed(1)+' IMDb');score.dir='ltr';foot.append(score);}
 const controls=make('div','bmfy-actions');
 for(const [name,text,ico] of [['like','می‌پسندم','heart'],['seen','دیدم','seen'],['less','کمتر پیشنهاد بده','less']]){
  const b=make('button','bmfy-feedback');b.type='button';b.dataset.feedback=name;b.setAttribute('aria-label',text+' — '+(m.title||''));b.title=text;b.append(svg(ico),make('span','',text));if(!feedback)b.disabled=true;controls.append(b);
 }
 foot.append(controls);c.append(a,foot);return c;
}
async function load(append=false){
 if(pending)return;pending=true;const thisRequest=++serial;
 refresh.disabled=true;more.disabled=true;root.classList.add('bmfy-loading');
 if(!append){skeleton();showMessage('در حال بررسی علاقه‌مندی‌ها و پیدا کردن فیلم‌های نزدیک به سلیقه‌ات…');}
 else showMessage('در حال دریافت پیشنهادهای بیشتر…');
 try{
  const {body,fromFallback}=await loadRecommendations(page);
  if(thisRequest!==serial)return;
  const data=body.data||{};
  if(!append)list.replaceChildren();
  const items=Array.isArray(data.items)?data.items:[];
  items.forEach(m=>list.append(card(m,!!boot.loggedIn&&!!data.feedback_enabled)));
  if(!items.length && !append){const empty=make('div','bmfy-empty');empty.append(svg('bookmark'),make('strong','',data.personalized?'فیلم تازه‌ای با این شرایط پیدا نشد':'هنوز سلیقه‌ات رو نمی‌شناسیم'),make('p','',data.personalized?'بعداً دوباره پیشنهادها رو تازه کن.':'چند فیلم رو به واچ‌لیست اضافه کن تا پیشنهادهای بعدی مخصوص خودت بشن.'));list.append(empty);}
  const tags=Array.isArray(data.genres)?data.genres:[];chips.replaceChildren(...tags.map(t=>make('span','bmfy-chip',t)));
  counter.textContent=fromFallback||data.fallback?'پیشنهادهای عمومی (سرویس شخصی فعلاً در دسترس نیست)':data.personalized?(data.watchlist_count>0?`بر اساس ${fmt(data.watchlist_count)} عنوان ذخیره‌شده و انتخاب‌های تو`:'بر اساس سابقه تماشا و انتخاب‌های تو'):'پیشنهادهای عمومی · با واچ‌لیست شخصی‌تر می‌شن';
  showMessage(fromFallback||data.fallback?'فعلاً پیشنهادهای عمومی نمایش داده می‌شن؛ موتور شخصی نیاز به بررسی سمت سرور داره.':!boot.loggedIn?'برای پیشنهاد مخصوص سلیقه‌ات وارد حساب شو.':data.personalized?'از واچ‌لیست و بازخوردهای واقعی تو استفاده شد.':'با افزودن فیلم به واچ‌لیست، سلیقه‌ات رو بهتر می‌شناسیم.');
  more.hidden=!data.has_more;more.disabled=!data.has_more;
 }catch(e){if(append)page=Math.max(1,page-1);if(!append)list.replaceChildren(make('div','bmfy-empty','دریافت پیشنهادها ممکن نشد.'));showMessage(friendlyError(e));}
 finally{pending=false;refresh.disabled=false;root.classList.remove('bmfy-loading');}
}
refresh.addEventListener('click',()=>{page=1;load(false);});
more.addEventListener('click',()=>{page++;load(true);});
list.addEventListener('click',async e=>{
 const b=e.target.closest('[data-feedback]');if(!b||b.disabled||pending)return;
 const c=b.closest('[data-movie-id]');if(!c)return;
 const buttons=[...c.querySelectorAll('[data-feedback]')];buttons.forEach(x=>x.disabled=true);
 b.classList.add('bmfy-feedback-pending');
 const form=new URLSearchParams({movie_id:c.dataset.movieId,preference:b.dataset.feedback,csrf:boot.csrf||''});
 try{
  const res=await fetch(boot.api||'/api_discover_for_you.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/x-www-form-urlencoded','Accept':'application/json'},body:form});
  const json=await res.json();if(!res.ok||!json.ok)throw Error(json.error||'save_failed');
  c.classList.add('bmfy-card-exit');setTimeout(()=>{c.remove();if(!list.children.length){page=1;load(false);}},230);
  showMessage('بازخورد ثبت شد؛ پیشنهادهای بعدی بر همین اساس بهتر می‌شن.');
 }catch(e){showMessage(e.message==='csrf'?'نشست تغییر کرده؛ صفحه رو تازه کن.':'ثبت بازخورد ممکن نشد؛ دوباره تلاش کن.');buttons.forEach(x=>x.disabled=false);}
 finally{b.classList.remove('bmfy-feedback-pending');}
});
if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>{if(entries.some(x=>x.isIntersecting)){observer.disconnect();load(false);}},{rootMargin:'240px'});observer.observe(root);}else load(false);
})();
