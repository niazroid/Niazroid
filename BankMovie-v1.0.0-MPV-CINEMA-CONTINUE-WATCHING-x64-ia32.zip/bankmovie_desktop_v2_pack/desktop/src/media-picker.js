/* Shared BankMovie comment and in-player media picker. */
(function(global){'use strict';
const esc=(v='')=>String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cleanUrl=(v='')=>/^https?:\/\//i.test(String(v))?String(v):'';
const EMOJI=['😀','😂','😍','🥰','😎','🤯','😭','😡','🔥','❤️','💙','👏','🙏','🍿','🎬','👑','✅','💯','🤣','🥲','😅','🤝','👌','💀'];
function mediaKey(x){return `${x?.pack||''}:${x?.id||x?.url||''}`}
function mediaHtml(media,cls=''){if(!media?.url)return '';const u=esc(cleanUrl(media.url)),ext=String(media.extension||'').toLowerCase(),video=media.media_type==='video'||['webm','mp4'].includes(ext);return video?`<video class="bm110-comment-media ${cls}" src="${u}" autoplay loop muted playsinline preload="metadata"></video>`:`<img class="bm110-comment-media ${cls}" src="${u}" loading="lazy" alt="Sticker">`}
async function open({en=false,loadCatalog,recentMedia,rememberMedia,onEmoji,onMedia,onClose=()=>{},errorText=()=>en?'Unable to load media':'دریافت رسانه ناموفق بود'}){
  document.querySelector('.bm110-media-modal')?.remove();
  const overlay=document.createElement('div');overlay.className='bm110-media-modal';overlay.innerHTML=`<div class="bm110-media-sheet"><div class="bm110-media-top"><div class="bm110-media-tabs"><button class="active" data-media-tab="emoji">Emoji</button><button data-media-tab="stickers">${en?'Stickers':'استیکرها'}</button><button data-media-tab="gifs">GIFs</button></div><button class="bm110-media-close" type="button">×</button></div><div class="bm110-media-search"><span>⌕</span><input placeholder="${en?'Search':'جستجو'}"></div><div class="bm110-media-body"><div class="bm110-media-loading"><i></i>${en?'Loading media…':'در حال دریافت استیکر و گیف…'}</div></div></div>`;
  document.body.appendChild(overlay);requestAnimationFrame(()=>overlay.classList.add('open'));
  let closed=false;const close=()=>{if(closed)return;closed=true;overlay.classList.remove('open');setTimeout(()=>overlay.remove(),160);onClose()};overlay.querySelector('.bm110-media-close').onclick=close;overlay.onclick=e=>{if(e.target===overlay)close()};
  const body=overlay.querySelector('.bm110-media-body'),search=overlay.querySelector('input');let packs=[],loadError='';try{packs=await loadCatalog()}catch(e){loadError=errorText(e)}if(closed||!overlay.isConnected)return;
  const all=packs.flatMap(p=>p.items||[]),recent=recentMedia();
  const render=tab=>{
    const q=search.value.trim().toLowerCase();
    if(tab==='emoji'){body.innerHTML=`<div class="bm110-emoji-grid">${EMOJI.filter(x=>!q||x.includes(q)).map(x=>`<button type="button" data-emoji="${x}">${x}</button>`).join('')}</div>`;body.querySelectorAll('[data-emoji]').forEach(b=>b.onclick=()=>{onEmoji(b.dataset.emoji);close()});return}
    const isGif=x=>x.media_type==='video'||['gif','webm','mp4'].includes(String(x.extension).toLowerCase());let items=all.filter(x=>tab==='gifs'?isGif(x):!isGif(x));if(loadError){body.innerHTML=`<div class="bm110-media-empty">${esc(loadError)}</div>`;return;}
    if(q)items=items.filter(x=>String(x.pack_label||x.pack||'').toLowerCase().includes(q));
    const byKey=new Map(items.map(x=>[mediaKey(x),x]));const rec=recent.map(r=>byKey.get(mediaKey(r))).filter(Boolean).slice(0,12);
    body.innerHTML=`${rec.length?`<section><h4>${en?'Recently used':'اخیراً استفاده‌شده'}</h4><div class="bm110-media-grid">${rec.map((x,i)=>`<button data-recent-media="${i}">${mediaHtml(x)}</button>`).join('')}</div></section>`:''}${packs.map((p,pi)=>{const filtered=(p.items||[]).filter(x=>byKey.has(mediaKey(x)));if(!filtered.length)return '';return `<section><h4>${esc(p.label||p.slug||'Pack')}</h4><div class="bm110-media-grid">${filtered.map((x,i)=>`<button data-pack="${pi}" data-item="${(p.items||[]).indexOf(x)}">${mediaHtml(x)}</button>`).join('')}</div></section>`}).join('')||`<div class="bm110-media-empty">${en?'Nothing found':'چیزی پیدا نشد'}</div>`}`;
    body.querySelectorAll('[data-recent-media]').forEach(b=>b.onclick=()=>{const x=rec[Number(b.dataset.recentMedia)];rememberMedia(x);onMedia(x);close()});
    body.querySelectorAll('[data-pack]').forEach(b=>{const p=packs[Number(b.dataset.pack)],x=(p?.items||[])[Number(b.dataset.item)];if(x)b.onclick=()=>{rememberMedia(x);onMedia(x);close()}});
  };
  let tab='emoji';render(tab);overlay.querySelectorAll('[data-media-tab]').forEach(b=>b.onclick=()=>{overlay.querySelectorAll('[data-media-tab]').forEach(x=>x.classList.toggle('active',x===b));tab=b.dataset.mediaTab;render(tab)});search.oninput=()=>render(tab);
}

global.BMMediaPicker=Object.freeze({open,emoji:EMOJI.slice()});
})(globalThis);
