'use strict';
// Separate origin for the locally bundled website UI. Never proxy executable remote HTML/JS.
const fs=require('node:fs');const path=require('node:path');
const SCHEME='bm-discover';const ORIGIN=SCHEME+'://local';
const JSON_ACTIONS=new Set(['sekans','dorna_list','lookapo_list','lookapo_post','lookapo_movies','movie','stream_debug']);
const MEDIA_ACTIONS=new Set(['stream','image','proxy','dorna_media','lookapo_image']);
const TYPES={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.webp':'image/webp','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'};
function register(protocol){protocol.registerSchemesAsPrivileged([{scheme:SCHEME,privileges:{standard:true,secure:true,supportFetchAPI:true,corsEnabled:true,stream:true}}])}
function json(value,status=200){return new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json','X-Content-Type-Options':'nosniff'}})}
function bad(status=404){return new Response('',{status})}
function allowedLocal(root,pathname){if(pathname==='/discover'||pathname==='/')return path.join(root,'index.html');if(!/^\/(?:desktop-(?:adapter\.js|host\.css)|assets\/(?:css|js|discover|brand)\/[a-zA-Z0-9_./-]+)$/.test(pathname)||pathname.includes('..'))return '';const f=path.resolve(root,'.'+pathname);return f.startsWith(path.resolve(root)+path.sep)&&TYPES[path.extname(f)]?f:''}
function install(protocol,root,siteOrigin){
 protocol.handle(SCHEME,async request=>{
  try{const u=new URL(request.url);if(u.host!=='local'||u.username||u.password||!['GET','HEAD'].includes(request.method))return bad(403);
   if(u.pathname==='/vendor/hls.min.js'){const f=path.join(path.dirname(require.resolve('hls.js')),'hls.min.js');return new Response(fs.readFileSync(f),{headers:{'Content-Type':TYPES['.js'],'X-Content-Type-Options':'nosniff'}})}
   if(u.pathname!=='/api_explorer.php'){const f=allowedLocal(root,u.pathname);if(!f||!fs.existsSync(f))return bad();return new Response(fs.readFileSync(f),{headers:{'Content-Type':TYPES[path.extname(f)],'X-Content-Type-Options':'nosniff'}})}
   const action=u.searchParams.get('action')||'sekans';if(!JSON_ACTIONS.has(action)&&!MEDIA_ACTIONS.has(action)||u.search.length>12000)return bad(403);
   // Root Explorer routes are already explicitly public in the site's shield. No account/device token is ever sent here.
   const remote=new URL('/api_explorer.php',siteOrigin);remote.search=u.search;
   const headers={Accept:JSON_ACTIONS.has(action)?'application/json':'*/*'};const range=request.headers.get('range');if(range&&/^bytes=\d*-\d*$/.test(range))headers.Range=range;
   const resp=await fetch(remote,{method:request.method,headers,credentials:'omit',redirect:'follow',signal:AbortSignal.timeout(30000)});
   if(!resp.url.startsWith('https:'))return bad(502);
   if(JSON_ACTIONS.has(action)){let data;try{data=await resp.json()}catch{return json({success:false,message:'پاسخ API نامعتبر است'},502)}return json(data,resp.status)}
   if(!resp.ok)return bad(resp.status);
   const type=(resp.headers.get('content-type')||'').toLowerCase();
   if(!/^(?:video\/|audio\/|image\/(?:png|jpeg|webp|gif|avif)|application\/(?:vnd\.apple\.mpegurl|x-mpegurl|octet-stream)|binary\/octet-stream|text\/plain)/.test(type))return bad(502);
   const h=new Headers({'Content-Type':type,'X-Content-Type-Options':'nosniff'});for(const name of ['content-range','accept-ranges']){const v=resp.headers.get(name);if(v)h.set(name,v)}
   if(/mpegurl|text\/plain/.test(type)){const text=await resp.text();if(!text.startsWith('#EXTM3U'))return bad(502);return new Response(text,{status:resp.status,headers:h})}
   return new Response(resp.body,{status:resp.status,headers:h});
  }catch(e){return json({success:false,message:'دریافت اطلاعات اکسپلور ممکن نشد'},502)}
 });
}
module.exports={register,install,allowedLocal,SCHEME,ORIGIN};
