package ir.bankmoviee.app

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Watchlist wire/storage format V2: identities only.
 * Never persist titles, posters, playback links or detail JSON with favorites.
 * Display-only cache is separate from identity storage and never uploaded.
 */
object WatchlistIdentity {
    private const val MAX_VISUALS = 300
    private const val FRESH_MS = 6L * 60 * 60 * 1000
    private const val EXPIRE_MS = 24L * 60 * 60 * 1000
    private data class Visual(val data: JSONObject, val saved: Long)
    private val visuals = LinkedHashMap<String, Visual>(MAX_VISUALS, 0.75f, true)
    private var cacheScope = ""
    private var disk: SharedPreferences? = null

    // Separate, bounded presentation cache. No membership, tokens or playback links.
    // Scope changes clear the previous account's display cache.
    fun bindVisualCache(context: Context) {
        val user = AccountSession.user(context)
        val uid = user.optString("id").ifBlank { user.optString("user_id") }
        val scope = if (AccountSession.isLoggedIn(context) && uid.isNotBlank() && uid != "0")
            "$uid:${user.optString("role")}:${user.optBoolean("is_vip", false)}" else ""
        synchronized(visuals) {
            if (scope == cacheScope && (disk != null || scope.isEmpty())) return
            visuals.clear()
            val prefs = context.getSharedPreferences("bm_watchlist_display_cache_v2", Context.MODE_PRIVATE)
            cacheScope = scope
            disk = if (scope.isNotEmpty()) prefs else null
            if (scope.isEmpty() || prefs.getString("_scope", "") != scope) {
                prefs.edit().clear().putString("_scope", scope).apply()
                return
            }
            val now = System.currentTimeMillis()
            val entries = prefs.all.mapNotNull { (key, raw) ->
                if (key == "_scope" || raw !is String || raw.length > 8192) null else
                    runCatching {
                        val entry = JSONObject(raw)
                        val saved = entry.optLong("at")
                        if (now - saved !in 0..EXPIRE_MS) null else
                            Triple(key, entry.getJSONObject("card"), saved)
                    }.getOrNull()
            }.sortedBy { it.third }.takeLast(MAX_VISUALS)
            val edit = prefs.edit()
            val keep = entries.map { it.first }.toSet()
            prefs.all.keys.filter { it != "_scope" && it !in keep }.forEach { edit.remove(it) }
            entries.forEach { (key, card, at) -> visuals[key] = Visual(card, at) }
            edit.apply()
        }
    }
    private val visualKeys = listOf(
        "title", "title_fa", "poster", "image", "cover_image", "backdrop",
        "rating", "year", "imdb_code"
    )

    fun onlyId(item: JSONObject): JSONObject {
        val oldKey = item.optString("_key").ifBlank { item.optString("storage_key") }.trim()
        val parts = oldKey.split('|', limit = 3)
        val rawArchive = item.optInt("archive", parts.getOrNull(0)?.toIntOrNull() ?: 1)
        var archive = rawArchive.coerceIn(1, 9)
        val type = item.optString("type").ifBlank { parts.getOrNull(1).orEmpty() }.ifBlank { "movie" }
        var id = item.optString("id")
            .ifBlank { item.optString("movie_id") }
            .ifBlank { item.optString("detail_id") }
            .ifBlank { item.optString("db_id") }
            .ifBlank { item.optString("slug") }
            .ifBlank { parts.getOrNull(2).orEmpty() }
        if (archive == 4 && item.optString("detail_id").isNotBlank()) {
            id = item.optString("detail_id")
        }
        // A genuinely unidentifiable old row must never be silently destroyed.
        if (id.isBlank()) return JSONObject().apply { put("_key", oldKey); put("archive", archive); put("type", type); put("id", "") }
        // Older APKs used archive=2 for SerialBlog. Numeric archive-2 IDs are
        // from the local movies DB; old text slugs are archive 4 instead.
        val legacySource = item.optString("source").lowercase()
        val legacySerialBlog = archive == 2 && (
            legacySource in setOf("serialblog", "sb", "archive4") ||
            (item.optInt("db_id", 0) <= 0 && id.any { !it.isDigit() } &&
                legacySource !in setOf("db_movies", "database", "local_db", "collection", "website_db"))
        )
        if (legacySerialBlog) archive = 4
        // If a stale _key disagrees with the resolved archive, canonicalize it.
        val oldArchive = oldKey.substringBefore('|').toIntOrNull()
        val key = if (legacySerialBlog || (oldArchive != null && oldArchive != archive))
            "$archive|$type|$id" else oldKey.ifBlank { "$archive|$type|$id" }
        return JSONObject().apply {
            put("_key", key)
            put("archive", archive)
            put("type", type)
            put("id", id)
            // Database numeric ID is an identity, not descriptive metadata.
            val dbId = item.optInt("db_id", 0)
            if (archive == 2 && dbId > 0 && dbId.toString() != id) put("db_id", dbId)
        }
    }

    fun clearVisuals() { synchronized(visuals) {
        visuals.clear()
        disk?.edit()?.clear()?.putString("_scope", cacheScope)?.apply()
    } }

    /** Strict wire format: a protocol-2 response cannot contain legacy cards. */
    fun acceptsServerItems(json: JSONObject?): Boolean {
        if (json?.optInt("watchlist_protocol", 0) != 2) return false
        val items = json.optJSONArray("items") ?: return false
        val fields = setOf("_key", "archive", "type", "id")
        for (i in 0 until items.length()) {
            val item = items.optJSONObject(i) ?: return false
            val key = item.optString("_key")
            val id = item.optString("id")
            val type = item.optString("type")
            val archive = item.optInt("archive", 0)
            if (archive !in 1..5 || id.isBlank() || type.isBlank() || key != "$archive|$type|$id" || key.length > 190) return false
            if (item.keys().asSequence().toSet() != fields) return false
        }
        return true
    }

    // Only catalog responses (or a currently opened catalog card) reach this cache.
    fun remember(item: JSONObject, requestedKey: String? = null): Boolean {
        val key = requestedKey ?: onlyId(item).optString("_key")
        if (key.isBlank()) return false
        val data = JSONObject()
        visualKeys.forEach { field ->
            val value = item.opt(field)
            if (value is Number || value is Boolean || value is String && value.length <= 1500) {
                data.put(field, value)
            }
        }
        val id = key.substringAfterLast('|')
        fun realTitle(value: String): Boolean = value.isNotBlank() && value != id && value != "#$id" &&
            !value.equals("null", true) && !value.equals("false", true) && !value.equals("undefined", true)
        val title = data.optString("title")
        val titleFa = data.optString("title_fa")
        if (!realTitle(title) && !realTitle(titleFa)) return false
        if (!realTitle(title)) data.put("title", titleFa)
        if (!realTitle(titleFa)) data.put("title_fa", title)
        val now = System.currentTimeMillis()
        synchronized(visuals) {
            val previous = visuals[key]?.data
            // A partial refresh must not erase a valid cover or rating.
            if (previous != null) visualKeys.forEach { field ->
                if (data.optString(field).isBlank() || data.optString(field) == "null") {
                    if (previous.has(field)) data.put(field, previous.opt(field))
                }
            }
            val encoded = JSONObject().put("at", now).put("card", data).toString()
            if (encoded.length > 8192) return false
            visuals[key] = Visual(data, now)
            val edit = disk?.edit()?.putString(key, encoded)
            while (visuals.size > MAX_VISUALS) {
                val oldest = visuals.keys.first()
                visuals.remove(oldest)
                edit?.remove(oldest)
            }
            edit?.apply()
        }
        return true
    }

    fun hasVisual(item: JSONObject): Boolean {
        val key = onlyId(item).optString("_key")
        return synchronized(visuals) { visuals[key]?.let { System.currentTimeMillis() - it.saved in 0..EXPIRE_MS } == true }
    }

    fun needsRefresh(item: JSONObject): Boolean {
        val key = onlyId(item).optString("_key")
        return synchronized(visuals) { visuals[key]?.let { System.currentTimeMillis() - it.saved !in 0..FRESH_MS } ?: true }
    }

    fun withVisual(item: JSONObject): JSONObject {
        val identity = onlyId(item)
        val key = identity.optString("_key")
        val metadata = synchronized(visuals) {
            visuals[key]?.takeIf { System.currentTimeMillis() - it.saved in 0..EXPIRE_MS }?.data?.let { JSONObject(it.toString()) }
        }
        metadata?.let { src ->
            visualKeys.forEach { field -> if (src.has(field)) identity.put(field, src.opt(field)) }
        }
        return identity
    }

    fun compactArray(array: JSONArray): JSONArray {
        val output = JSONArray()
        for (i in 0 until array.length()) {
            array.optJSONObject(i)?.let { item ->
                output.put(onlyId(item))
            }
        }
        return output
    }
}
