package ir.bankmoviee.app

import android.content.Context
import android.os.Handler
import android.net.Uri
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object AccountApi {
    data class Result(
        val success: Boolean,
        val json: JSONObject? = null,
        val message: String = "",
        val statusCode: Int = 0
    )


    private const val SMART_PREFS = "bm_smart_cinema"
    private const val FAVORITES_KEY = "favorites"
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var clockOffsetSec = 0L
    @Volatile private var syncRunning = false
    private var syncAgain = false
    private val queuedSyncCallbacks = mutableListOf<(Result) -> Unit>()

    private fun accountEndpointBases(context: Context): List<String> {
        val prefs = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
        val configured = prefs.getString("account_api_url", "").orEmpty().trim()
        val values = linkedSetOf<String>()
        configured.takeIf { it.startsWith("http", true) }?.let { values.add(it.trimEnd('?')) }
        val raw = prefs.getString("account_api_fallback_urls", "[]").orEmpty()
        runCatching { JSONArray(raw) }.getOrNull()?.let { arr ->
            for (i in 0 until arr.length()) arr.optString(i).trim().takeIf { it.startsWith("http", true) }?.let { values.add(it.trimEnd('?')) }
        }
        values.add(AppConfig.ACCOUNT_API_URL.trimEnd('?'))
        return values.toList()
    }

    private fun endpoint(base: String, action: String): String {
        val separator = if (base.contains('?')) '&' else '?'
        return "$base${separator}action=${URLEncoder.encode(action, "UTF-8")}"
    }

    /**
     * Builds one canonical comment target for every archive.
     * Database movies keep their real DB id. External archives use the exact
     * slug + archive prefix that movie.php uses on the website, so app and web
     * always read/write the same comment rows.
     */
    private fun commentItemPayload(item: JSONObject): JSONObject {
        // All comment operations (list, add, vote, reply, edit) use this same
        // canonical target.  Archive 2 is the website DB, other archives use
        // the corresponding /movie/arcN-<slug> URL and archive1_comments.
        val out = JSONObject(item.toString())
        val source = item.optString("source").trim().lowercase(java.util.Locale.US)
        val archiveHint = item.optInt("comment_archive", item.optInt("_origin_archive", item.optInt("archive", 0)))
        val apiDetail = item.optString("api_detail")
        val databaseItem = source in setOf("db_movies", "database", "local_db", "collection", "website_db") ||
            item.optInt("db_id", 0) > 0 ||
            (apiDetail.contains("app_api.php", true) && apiDetail.contains("archive=2", true))
        val websiteArchive = when {
            databaseItem -> 2
            archiveHint in setOf(1, 3, 4, 5) -> archiveHint
            source in setOf("archive1", "arc1") -> 1
            source.contains("archive3") || source.contains("arc3") -> 3
            source in setOf("archive4", "archive2", "serialblog", "sb", "arc4") -> 4
            source in setOf("archive5", "arc5") -> 5
            else -> 1
        }
        fun clean(value: String): String = Uri.decode(value.trim().trim('/'))
            .replace(Regex("^arc[1345]-", RegexOption.IGNORE_CASE), "")
            .trim().trim('/')
        // If an actual BankMovie movie URL exists, it has the *exact* slug
        // which the website uses for its CRC32 virtual comment identifier.
        fun websiteRoute(value: String): String {
            if (value.isBlank()) return ""
            return runCatching {
                val uri = Uri.parse(value)
                val host = uri.host.orEmpty().lowercase(java.util.Locale.US)
                // Do not trust third-party URLs for BankMovie comment identity.
                if (host.isNotBlank() && host !in setOf("bankmovie.top", "www.bankmovie.top", "bankmoviez.top", "www.bankmoviez.top")) return@runCatching ""
                val segments = uri.pathSegments
                val movieIndex = segments.indexOfFirst { it.equals("movie", true) }
                val slug = if (movieIndex >= 0 && movieIndex + 1 < segments.size) segments[movieIndex + 1] else ""
                val match = Regex("^arc([1345])-(.+)$", RegexOption.IGNORE_CASE).matchEntire(slug)
                if (match != null && match.groupValues[1].toInt() == websiteArchive) {
                    clean(match.groupValues[2])
                } else if (uri.lastPathSegment.equals("movie.php", true) &&
                    uri.getQueryParameter("arc")?.toIntOrNull() == websiteArchive) {
                    clean(uri.getQueryParameter("slug").orEmpty())
                } else ""
            }.getOrDefault("")
        }
        val canonicalSiteSlug = if (websiteArchive == 2) "" else sequenceOf(
            "web_url_abs", "web_url", "page_url", "canonical_url", "source_url", "item_link"
        ).map { websiteRoute(item.optString(it)) }.firstOrNull { it.isNotBlank() }.orEmpty()
        // Cards and details can contain different aliases.  The explicit website
        // slug wins, then the API's comment_identity/detail_id contract.
        val keys = if (websiteArchive == 4) listOf("detail_id", "comment_identity", "source_slug", "slug", "id")
            else listOf("comment_identity", "source_slug", "slug", "detail_id", "id")
        val identity = canonicalSiteSlug.ifBlank {
            keys.asSequence().map { clean(item.optString(it)) }.firstOrNull { it.isNotBlank() }.orEmpty()
        }
        out.put("comment_archive", websiteArchive)
        if (identity.isNotBlank() && websiteArchive != 2) out.put("comment_identity", identity)
        if (canonicalSiteSlug.isNotBlank()) out.put("source_slug", canonicalSiteSlug)
        return out
    }

    private fun parseJsonPayload(raw: String): JSONObject? {
        val text = raw.trim().trimStart('\uFEFF')
        if (text.isBlank()) return JSONObject()
        runCatching { JSONObject(text) }.getOrNull()?.let { return it }
        // A few shared-host stacks prepend a warning/banner to otherwise valid
        // JSON. Recover the object instead of turning a real account response
        // into a transport error.
        val first = text.indexOf('{')
        val last = text.lastIndexOf('}')
        if (first >= 0 && last > first) {
            return runCatching { JSONObject(text.substring(first, last + 1)) }.getOrNull()
        }
        return null
    }

    private fun parseMessage(json: JSONObject?, fallback: String): String {
        return json?.optString("message")
            ?.takeIf { it.isNotBlank() }
            ?: json?.optString("error")?.takeIf { it.isNotBlank() }
            ?: fallback
    }

    /**
     * Authentication/validation failures are real server answers, not transport
     * failures. Older builds kept trying fallback account hosts after a 401/409
     * and a later DNS/connection failure overwrote the useful Persian message
     * with «اتصال به سرور برقرار نشد». Only signature/clock protocol failures
     * are retryable here; user/account errors must be surfaced immediately.
     */
    private fun shouldRetryAccountProtocolError(code: Int, message: String): Boolean {
        if (code != 401) return false
        val value = message.trim().lowercase()
        return value == "unauthorized" ||
            value == "bad signature" ||
            value == "expired request" ||
            value.contains("signature")
    }

    private fun isDefinitiveAccountResponse(code: Int, json: JSONObject?, message: String): Boolean {
        if (json == null || message.isBlank()) return false
        if (shouldRetryAccountProtocolError(code, message)) return false
        if (code in 400..499) return true
        if (code in 200..299 && json.optBoolean("success", true) == false) return true
        // Admin-disabled login/registration is also an intentional response and
        // should never be replaced by a generic connection error from a fallback.
        if (code == 503 && (message.contains("غیرفعال") || message.contains("disabled", true))) return true
        return false
    }

    /**
     * V7.47.1.20: website/account appearance is intentionally isolated from
     * the native app. The website may keep its paid theme system, while the
     * Android Accent and Light/Black mode remain free, local preferences.
     */
    private fun syncWebsiteTheme(context: Context, user: JSONObject) {
        // Compatibility no-op. Never import website `theme` into KEY_ACCENT.
        UiPreferences.detachAppAppearanceFromWebsite(context)
    }

    /** Compatibility no-op: authenticated profile refresh must not change app theme. */
    private fun syncAccountAppTheme(context: Context, user: JSONObject): JSONObject {
        UiPreferences.detachAppAppearanceFromWebsite(context)
        return user
    }

    private fun requestBlocking(
        context: Context,
        action: String,
        method: String = "GET",
        body: JSONObject? = null,
        requireToken: Boolean = false,
        quotaIntent: String? = null
    ): Result {
        val token = AccountSession.token(context)
        if (requireToken && token.isBlank()) return Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401)

        var last = Result(false, message = "خطا در اتصال به سرور")
        // Comment threads must never silently switch to a different account
        // mirror/database. The public website is on bankmovie.top, so prefer
        // its first-party account endpoint for ALL comment reads and writes.
        // Other account operations preserve their existing failover policy.
        val commentAction = action == "comments_list" || action.startsWith("comment_")
        val configuredBases = accountEndpointBases(context)
        val commentOrigin = configuredBases.firstOrNull { candidate ->
            candidate.startsWith("https://", true) &&
                runCatching { Uri.parse(candidate).host.equals("bankmovie.top", true) }.getOrDefault(false)
        } ?: AppConfig.ACCOUNT_API_URL.trimEnd('?')
        val watchlistIdentityAction = action == "watchlist_sync" || action == "watchlist_list"
        val watchlistCardsAction = action == "watchlist_cards"
        val watchlistAction = watchlistIdentityAction || watchlistCardsAction
        // One canonical database; do not silently fall back to an old mirror.
        val bases = if (commentAction || watchlistAction) listOf(commentOrigin) else configuredBases
        // Same real operation id across mirror/failover retries.
        val quotaSuffix = if (quotaIntent in setOf("watchlist_change", "watchlist_view", "account_edit"))
            "&bm_q_intent=$quotaIntent&bm_q_request_id=${java.util.UUID.randomUUID()}" else ""
        for (round in 0 until (if (commentAction || watchlistCardsAction) 1 else 2)) {
          for (base in bases) {
            var connection: HttpURLConnection? = null
            try {
                val url = URL(BmV22Client.urlForApi(endpoint(base, action) + quotaSuffix))
                val requestBytes = if (method == "POST") (body ?: JSONObject()).toString().toByteArray(Charsets.UTF_8) else ByteArray(0)
                connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = method
                    connectTimeout = 12000
                    readTimeout = 18000
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Accept", "application/json")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("User-Agent", "BankmovieAndroidNative/2.4-Account")
                    setRequestProperty("X-BM-Notification-Protocol", "2")
                    if (watchlistAction) {
                        setRequestProperty("X-BM-Watchlist-IDs", "2")
                    }
                    setRequestProperty("Cache-Control", "no-cache")

                    if (token.isNotBlank()) {
                        setRequestProperty("Authorization", "Bearer $token")
                        setRequestProperty("X-BM-User-Token", token)
                    }
                    if (method == "POST") doOutput = true
                }

                BmV22Client.attach(context, connection, url, method, requestBytes)
                if (method == "POST") {
                    connection.setFixedLengthStreamingMode(requestBytes.size)
                    connection.outputStream.use { it.write(requestBytes) }
                }

                val code = connection.responseCode
                connection.getHeaderFieldDate("Date", -1L).takeIf { it > 0L }?.let { serverDate ->
                    clockOffsetSec = serverDate / 1000L - System.currentTimeMillis() / 1000L
                }
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                val json = parseJsonPayload(text)
                if (action.startsWith("watch_party_") && json == null) {
                    // A CDN challenge, origin redirect or PHP error document is
                    // not JSON. Preserve the actual status and content type so
                    // reports can distinguish these cases from a room logic bug.
                    val type = connection.contentType.orEmpty().substringBefore(';').take(48).ifBlank { "unknown" }
                    val reason = when (code) {
                        403 -> "درخواست توسط سرور یا محافظ امنیتی رد شد"
                        429 -> "تعداد درخواست‌ها محدود شده است"
                        502, 503, 504 -> "درگاه یا سرور موقتاً پاسخ صحیح نمی‌دهد"
                        in 500..599 -> "خطای داخلی سرور"
                        in 300..399 -> "درخواست به مسیر دیگری هدایت شده است"
                        else -> "پاسخ API به‌جای JSON، متن یا HTML بود"
                    }
                    BmDiagnostics.record(context, "watch_party_non_json:$action", url.toString(), code, "invalid_json_response", type)
                    val traceId = connection.getHeaderField("X-BM-WP-Request-ID").orEmpty().take(32)
                    val details = "HTTP $code، نوع: $type، عملیات: $action" + (if (traceId.isNotBlank()) "، شناسه: $traceId" else "")
                    return Result(false, message = "$reason ($details)", statusCode = code)
                }
                if (code == 429 && BmApiRateLimit.isSecurityLimitResponse(
                        json, text, connection.getHeaderField("Retry-After"))) {
                    // Account and VIP APIs share the V22 throttle. Don't replace
                    // this deliberate refusal with a generic failover error.
                    return Result(false, json,
                        BmApiRateLimit.report(context, connection.getHeaderField("Retry-After"), text), 429)
                }
                val ok = code in 200..299 && (json?.optBoolean("success", true) != false)
                // Auth validation errors are intentionally transported as HTTP
                // 200 by the website so hosting ErrorDocument rules cannot eat
                // the JSON body. Preserve their original semantic status here.
                val semanticCode = json?.optInt("http_status", code)?.takeIf { it > 0 } ?: code
                if (semanticCode !in 200..299 || !ok) {
                    BmDiagnostics.record(context, "account_http:$action", url.toString(), semanticCode,
                        json?.optString("error_code").orEmpty(),
                        json?.optString("message").orEmpty(),
                        requestId = connection.getHeaderField("X-Request-ID").orEmpty(),
                        retryAfter = connection.getHeaderField("Retry-After").orEmpty())
                }
                last = Result(
                    success = ok,
                    json = json,
                    message = parseMessage(json, if (ok) "" else "خطای ارتباط با حساب کاربری"),
                    statusCode = semanticCode
                )
                if (ok && watchlistIdentityAction && !WatchlistIdentity.acceptsServerItems(json)) {
                    BmDiagnostics.record(context, "watchlist_protocol_mismatch", url.toString(), code, "watchlist_protocol_2_required", "")
                    return Result(false, message = "پاسخ واچ‌لیست با روش جدید سازگار نیست (WL-2)", statusCode = 409)
                }
                if (ok) {
                    if (!commentAction && !watchlistAction) context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE).edit().putString("account_api_url", base).apply()
                    return last
                }
                if (isDefinitiveAccountResponse(last.statusCode, json, last.message)) {
                    // Keep the endpoint that produced a valid account response;
                    // this also prevents stale fallback hosts from masking it.
                    if (!commentAction) context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE).edit().putString("account_api_url", base).apply()
                    return last
                }
                if (code == 401 && round > 0) return last
            } catch (error: Throwable) {
                BmDiagnostics.record(context, "account_exception:$action", base, error = error)
                if (BmApiRateLimit.isLimitMessage(error.message)) {
                    // Token registration itself can be rate-limited. Don't hide
                    // that under a misleading "server connection failed" message.
                    return Result(false, message = BmApiRateLimit.message(), statusCode = 429)
                }
                last = Result(false, message = "اتصال به سرور برقرار نشد")
            } finally {
                runCatching { connection?.disconnect() }
            }
          }
        }
        return last
    }

    private fun run(callback: (Result) -> Unit, block: () -> Result) {
        Thread {
            val result = runCatching(block).getOrElse { Result(false, message = "خطای غیرمنتظره") }
            mainHandler.post { callback(result) }
        }.start()
    }

    /** Catalog-only batch; never merges these cards into saved identities. */
    fun readWatchlistCards(context: Context, keys: List<String>, callback: (Result) -> Unit) {
        val body = JSONObject().put("keys", JSONArray(keys.take(8)))
        run(callback) { requestBlocking(context, "watchlist_cards", "POST", body, requireToken = true) }
    }

    /** Read-only server watchlist for Discover's personal recommendation rail.
     * Never writes, migrates, replaces local favorites, or runs watchlist_sync.
     */
    fun readWatchlistForDiscovery(context: Context, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401))
            return
        }
        run(callback) { requestBlocking(context, action = "watchlist_list", method = "GET", requireToken = true) }
    }

    fun loadConfig(context: Context, callback: (Result) -> Unit = {}) {
        run(callback) {
            val result = requestBlocking(context, "config")
            result.json?.optString("background_url")?.takeIf { it.isNotBlank() }?.let {
                AccountSession.setAuthBackground(context, it)
            }
            result.json?.optJSONObject("features")?.let { AccountSession.updateFeatures(context, it) }
            result.json?.optJSONObject("vip")?.let { AccountSession.updateVip(context, it) }
            result
        }
    }

    fun authChallenge(context: Context, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "auth_challenge")
        }
    }

    fun login(
        context: Context,
        identity: String,
        password: String,
        challengeToken: String = "",
        securityCode: String = "",
        callback: (Result) -> Unit
    ) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "login",
                method = "POST",
                body = JSONObject().apply {
                    put("identity", identity.trim())
                    put("password", password)
                    if (challengeToken.isNotBlank() || securityCode.isNotBlank()) {
                        put("challenge_token", challengeToken)
                        put("security_code", securityCode.trim())
                    }
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                val stats = result.json?.optJSONObject("stats")
                syncWebsiteTheme(context, user)
                if (token.isNotBlank()) {
                    AccountSession.saveAuth(context, token, user, stats)
                    val syncedUser = syncAccountAppTheme(context, user)
                    AccountSession.updateUser(context, syncedUser)
                }
            }
            result
        }
    }

    fun register(
        context: Context,
        username: String,
        email: String,
        password: String,
        confirmPassword: String,
        challengeToken: String = "",
        securityCode: String = "",
        callback: (Result) -> Unit
    ) {
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "register",
                method = "POST",
                body = JSONObject().apply {
                    put("username", username.trim())
                    put("email", email.trim())
                    put("password", password)
                    put("confirm_password", confirmPassword)
                    if (challengeToken.isNotBlank() || securityCode.isNotBlank()) {
                        put("challenge_token", challengeToken)
                        put("security_code", securityCode.trim())
                    }
                }
            )
            if (result.success) {
                val token = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user") ?: JSONObject()
                val stats = result.json?.optJSONObject("stats")
                syncWebsiteTheme(context, user)
                if (token.isNotBlank()) {
                    AccountSession.saveAuth(context, token, user, stats)
                    val syncedUser = syncAccountAppTheme(context, user)
                    AccountSession.updateUser(context, syncedUser)
                }
            }
            result
        }
    }

    fun refreshMe(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "me", requireToken = true)
            if (result.success) {
                result.json?.optJSONObject("user")?.let { remoteUser ->
                    syncWebsiteTheme(context, remoteUser)
                    val syncedUser = syncAccountAppTheme(context, remoteUser)
                    AccountSession.updateUser(context, syncedUser)
                }
                result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
                result.json?.optJSONObject("features")?.let { AccountSession.updateFeatures(context, it) }
                result.json?.optJSONObject("vip")?.let { AccountSession.updateVip(context, it) }
            } else if (result.statusCode == 401) {
                AccountSession.clear(context)
            }
            result
        }
    }

    /** The username only changes when the authenticated server confirms the old password. */
    fun changeUsername(context: Context, username: String, currentPassword: String, callback: (Result) -> Unit) {
        run(callback) {
            val result = requestBlocking(context, "update_username", method = "POST", requireToken = true,
                quotaIntent = "account_edit", body = JSONObject().apply {
                    put("username", username.trim())
                    put("current_password", currentPassword)
                })
            if (result.success) result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            result
        }
    }

    /** Changing a password invalidates every old session; the server returns one fresh token. */
    fun changePassword(context: Context, currentPassword: String, newPassword: String, confirmPassword: String, callback: (Result) -> Unit) {
        run(callback) {
            val result = requestBlocking(context, "change_password", method = "POST", requireToken = true,
                quotaIntent = "account_edit", body = JSONObject().apply {
                    put("current_password", currentPassword)
                    put("new_password", newPassword)
                    put("confirm_password", confirmPassword)
                })
            if (result.success) {
                val fresh = result.json?.optString("token").orEmpty()
                val user = result.json?.optJSONObject("user")
                if (fresh.isNotBlank() && user != null) {
                    AccountSession.saveAuth(context, fresh, user, AccountSession.stats(context))
                } else {
                    // Never retain a revoked token if a reverse proxy truncated the response.
                    AccountSession.clear(context)
                    return@run Result(false, message = "رمز تغییر کرد، لطفاً دوباره وارد شوید")
                }
            }
            result
        }
    }

    fun logout(context: Context, callback: (Result) -> Unit = {}) {
        val hadSession = AccountSession.isLoggedIn(context)
        if (!hadSession) {
            AccountSession.clear(context)
            callback(Result(true))
            return
        }
        run(callback) {
            val result = requestBlocking(context, "logout", method = "POST", body = JSONObject(), requireToken = true)
            AccountSession.clear(context)
            result.copy(success = true)
        }
    }

    private fun localFavorites(context: Context): JSONArray {
        val raw = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString(FAVORITES_KEY, "[]") ?: "[]"
        return WatchlistIdentity.compactArray(runCatching { JSONArray(raw) }.getOrElse { JSONArray() })
    }

    private fun saveFavorites(context: Context, array: JSONArray) {
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit()
            .putString(FAVORITES_KEY, WatchlistIdentity.compactArray(array).toString())
            .apply()
    }

    fun syncWatchlist(context: Context, force: Boolean = false, quotaIntent: Boolean = false, quotaView: Boolean = false, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "وارد حساب نشده‌اید", statusCode = 401))
            return
        }
        if (!force && !AccountSession.watchlistDirty(context) &&
            System.currentTimeMillis() - AccountSession.lastWatchlistSync(context) < 20_000L) {
            callback(Result(true, message = ""))
            return
        }
        synchronized(this) {
            if (syncRunning) {
                // A second tap must never be acknowledged without reaching the server.
                syncAgain = true
                queuedSyncCallbacks.add(callback)
                return
            }
            syncRunning = true
        }

        run({ result ->
            val queued: List<(Result) -> Unit>
            val retry: Boolean
            synchronized(this) {
                syncRunning = false
                retry = syncAgain
                syncAgain = false
                queued = queuedSyncCallbacks.toList()
                queuedSyncCallbacks.clear()
            }
            callback(result)
            if (retry) {
                syncWatchlist(context, force = true, quotaIntent = quotaIntent, quotaView = quotaView) { final -> queued.forEach { it(final) } }
            }
        }) {
            val sentItems = localFavorites(context)
            val pendingAdds = AccountSession.pendingAddedWatchlistKeys(context)
            val isFirstMigration = AccountSession.lastWatchlistSync(context) == 0L && sentItems.length() > 0
            // Only mutations go over the wire after first sync, not the entire watchlist.
            val postedItems = JSONArray()
            for (i in 0 until sentItems.length()) {
                val identity = sentItems.optJSONObject(i) ?: continue
                if (isFirstMigration || identity.optString("_key") in pendingAdds) {
                    // Wire payload is ID-only. No poster/title/rating/card snapshot.
                    postedItems.put(WatchlistIdentity.onlyId(identity))
                }
            }
            val removed = JSONArray()
            AccountSession.removedWatchlistKeys(context).forEach(removed::put)
            val sentToken = AccountSession.token(context)
            // Read-only requests must never POST every user's favorites back to SQL.
            // POST only when a local addition/removal has not been acknowledged, or
            // when migrating pre-2.4 local favorites once after the first login.
            val mustWrite = AccountSession.watchlistDirty(context) || isFirstMigration
            // Prove that the origin speaks the new protocol before sending a mutation.
            if (mustWrite) {
                val probe = requestBlocking(context, action = "watchlist_list", requireToken = true)
                if (!probe.success) return@run probe
            }
            val result = if (mustWrite) requestBlocking(
                context = context,
                action = "watchlist_sync",
                method = "POST",
                body = JSONObject().apply {
                    put("items", postedItems)
                    put("removed_keys", removed)
                },
                requireToken = true,
                quotaIntent = if (quotaIntent) "watchlist_change" else null
            ) else requestBlocking(
                context = context,
                action = "watchlist_list",
                method = "GET",
                requireToken = true,
                quotaIntent = if (quotaView) "watchlist_view" else null
            )
            if (result.success && AccountSession.token(context) == sentToken) {
                val items = result.json?.optJSONArray("items") ?: JSONArray()
                // Do not overwrite a newer local tap with an older in-flight reply.
                val unchanged = localFavorites(context).toString() == sentItems.toString() &&
                    AccountSession.pendingAddedWatchlistKeys(context) == pendingAdds &&
                    AccountSession.removedWatchlistKeys(context).toList().sorted() ==
                    (0 until removed.length()).map { removed.optString(it) }.sorted()
                if (unchanged) {
                    // Protocol 2 was validated above; no old card response can be saved.
                    saveFavorites(context, items)
                    AccountSession.clearRemovedWatchlistKeys(context)
                    AccountSession.clearPendingWatchlistAdditions(context)
                    AccountSession.clearWatchlistDirty(context)
                    AccountSession.markWatchlistSynced(context)
                } else {
                    synchronized(this) { syncAgain = true }
                }
            } else if (result.statusCode == 401 && AccountSession.token(context) == sentToken) {
                AccountSession.clear(context)
            }
            result
        }
    }

    /**
     * App-only Light/Black persistence. No account endpoint is contacted and
     * no website theme can override this local preference on login/refresh.
     */
    fun updateAppTheme(context: Context, mode: String, callback: (Result) -> Unit = {}) {
        UiPreferences.saveThemeSelection(context, mode, markForAccountSync = false)
        callback(Result(true, message = ""))
    }

    fun updateAvatar(context: Context, avatarKey: String, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "avatar_update",
                method = "POST",
                body = JSONObject().put("avatar_key", avatarKey),
                requireToken = true
            )
            if (result.success) result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            result
        }
    }

    fun uploadAvatar(context: Context, base64Image: String, mimeType: String, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب کاربری شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "avatar_upload",
                method = "POST",
                body = JSONObject().apply {
                    put("image_base64", base64Image)
                    put("mime_type", mimeType)
                },
                requireToken = true
            )
            if (result.success) result.json?.optJSONObject("user")?.let { AccountSession.updateUser(context, it) }
            result
        }
    }

    fun commentMediaCatalog(context: Context, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_media_catalog",
                method = "POST",
                body = JSONObject()
            )
        }
    }

    fun listComments(
        context: Context,
        item: JSONObject,
        page: Int = 1,
        limit: Int = 10,
        sort: String = "latest",
        callback: (Result) -> Unit
    ) {
        run(callback) {
            requestBlocking(
                context = context,
                action = "comments_list",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("page", page)
                    put("limit", limit)
                    put("sort", sort)
                }
            )
        }
    }

    fun addComment(
        context: Context,
        item: JSONObject,
        text: String,
        rating: Int,
        spoiler: Boolean,
        parentId: Long? = null,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای ثبت دیدگاه وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = if (parentId != null && parentId > 0L) "comment_reply" else "comment_add",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment", text.trim())
                    put("rating", rating.coerceIn(0, 5))
                    put("spoiler", if (spoiler) 1 else 0)
                    parentId?.takeIf { it > 0L }?.let { put("parent_id", it) }
                },
                requireToken = true
            )
        }
    }

    fun voteComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        type: String,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای رأی دادن وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_vote",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("type", type)
                },
                requireToken = true
            )
        }
    }

    fun deleteComment(context: Context, item: JSONObject, commentId: Long, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_delete",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                },
                requireToken = true
            )
        }
    }

    fun editComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        text: String,
        spoiler: Boolean,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_edit",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("comment", text.trim())
                    put("spoiler", if (spoiler) 1 else 0)
                },
                requireToken = true
            )
        }
    }

    fun pinComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        pinned: Boolean,
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_pin",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("pinned", if (pinned) 1 else 0)
                },
                requireToken = true
            )
        }
    }

    fun reportComment(
        context: Context,
        item: JSONObject,
        commentId: Long,
        reason: String,
        details: String = "",
        callback: (Result) -> Unit
    ) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای گزارش دیدگاه وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            requestBlocking(
                context = context,
                action = "comment_report",
                method = "POST",
                body = JSONObject().apply {
                    put("item", commentItemPayload(item))
                    put("comment_id", commentId)
                    put("reason", reason)
                    put("details", details.trim())
                },
                requireToken = true
            )
        }
    }

    fun listNotifications(context: Context, page: Int = 1, limit: Int = 30, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "ابتدا وارد حساب شوید", statusCode = 401))
            return
        }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_list",
                method = "POST",
                body = JSONObject().apply { put("page", page); put("limit", limit) },
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun markNotificationRead(context: Context, notificationId: Long, source: String = "personal", callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notification_read",
                method = "POST",
                body = JSONObject().apply {
                    put("notification_id", notificationId)
                    put("notification_source", source)
                },
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun deleteNotification(context: Context, notificationId: Long, source: String = "personal", callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notification_delete",
                method = "POST",
                body = JSONObject().apply {
                    put("notification_id", notificationId)
                    put("notification_source", source)
                },
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun clearNotifications(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_clear",
                method = "POST",
                body = JSONObject(),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }

    fun markAllNotificationsRead(context: Context, callback: (Result) -> Unit = {}) {
        if (!AccountSession.isLoggedIn(context)) { callback(Result(false, statusCode = 401)); return }
        run(callback) {
            val result = requestBlocking(
                context = context,
                action = "notifications_read_all",
                method = "POST",
                body = JSONObject(),
                requireToken = true
            )
            result.json?.optJSONObject("stats")?.let { AccountSession.updateStats(context, it) }
            result
        }
    }


    // PASS 4 — Native Watch Party. These calls terminate in app_user_api.php,
    // which delegates to the website's existing Watch Party functions/tables.
    fun watchPartyGuestToken(context: Context): String {
        val prefs = context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
        val stored = prefs.getString("watch_party_guest_token", "").orEmpty()
        if (stored.matches(Regex("[A-Za-z0-9_-]{40,120}"))) return stored
        val fresh = (java.util.UUID.randomUUID().toString() + java.util.UUID.randomUUID().toString()).replace("-", "")
        prefs.edit().putString("watch_party_guest_token", fresh).apply()
        return fresh
    }

    private fun watchPartyBody(context: Context, roomCode: String = ""): JSONObject = JSONObject().apply {
        put("guest_token", watchPartyGuestToken(context))
        if (roomCode.isNotBlank()) put("room_code", roomCode)
    }

    private fun rememberedWatchPartyRoomCode(context: Context): String {
        return context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .getString("watch_party_host_room_code", "").orEmpty()
            .takeIf { it.matches(Regex("[A-Za-z0-9_-]{24,96}")) }.orEmpty()
    }

    private fun rememberWatchPartyRoomCode(context: Context, code: String) {
        val clean = code.trim()
        if (!clean.matches(Regex("[A-Za-z0-9_-]{24,96}"))) return
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit().putString("watch_party_host_room_code", clean).apply()
    }

    private fun clearRememberedWatchPartyRoomCode(context: Context) {
        context.getSharedPreferences(SMART_PREFS, Context.MODE_PRIVATE)
            .edit().remove("watch_party_host_room_code").apply()
    }

    fun watchPartyStatus(context: Context, callback: (Result) -> Unit) {
        run(callback) { requestBlocking(context, "watch_party_status", method = "POST", body = watchPartyBody(context), requireToken = false) }
    }

    fun watchPartyCreate(context: Context, item: JSONObject, link: JSONObject, callback: (Result) -> Unit) {
        if (!AccountSession.isLoggedIn(context)) {
            callback(Result(false, message = "برای ساخت اتاق وارد حساب شوید", statusCode = 401)); return
        }
        run(callback) {
            val source = link.optString("url").trim()
            val subtitle = listOf("subtitle_url", "sub_url", "subtitle", "vtt_url")
                .asSequence().map { link.optString(it).trim() }.firstOrNull { it.startsWith("http", true) }.orEmpty()
            val archive = item.optInt("archive", item.optInt("_origin_archive", 1)).coerceIn(1, 9)
            val mediaType = when {
                link.optInt("episode", 0) > 0 -> "episode"
                item.optString("type").contains("series", true) || item.optString("type_fa").contains("سریال") -> "series"
                else -> "movie"
            }
            val id = item.optInt("db_id", 0).takeIf { it > 0 } ?: item.optInt("id", 0)
            val title = item.optString("title_fa").ifBlank { item.optString("title") }
            val poster = listOf("poster", "poster_url", "image", "cover_image", "thumbnail")
                .asSequence().map { item.optString(it).trim() }.firstOrNull { it.isNotBlank() }.orEmpty()
            val q = link.optString("quality").ifBlank { link.optString("display_label") }.ifBlank { "source" }
            val body = watchPartyBody(context).apply {
                rememberedWatchPartyRoomCode(context).takeIf { it.isNotBlank() }?.let { put("room_code", it) }
                put("movie_id", id)
                put("archive_no", archive)
                put("media_type", mediaType)
                put("source_ref", "android-movie-${item.optString("id")}-a$archive-${q.replace(Regex("[^A-Za-z0-9._-]+"), "-").take(48)}")
                put("source_url", source)
                put("subtitle_url", subtitle)
                put("content_title", title.take(190))
                put("poster_url", poster.take(600))
            }
            val result = requestBlocking(context, "watch_party_create", method = "POST", body = body, requireToken = true)
            if (result.success) {
                result.json?.optJSONObject("room")?.optString("invite_code")
                    ?.takeIf { it.isNotBlank() }?.let { rememberWatchPartyRoomCode(context, it) }
            }
            result
        }
    }

    fun watchPartyJoin(context: Context, roomCode: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_join", method = "POST", body = watchPartyBody(context, roomCode), requireToken = false)
        }
    }

    fun watchPartyJoinNumeric(context: Context, joinCode: String, pin: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_join_numeric", method = "POST", body = watchPartyBody(context).apply {
                put("join_code", joinCode)
                put("pin", pin)
            }, requireToken = false)
        }
    }

    fun watchPartyPoll(
        context: Context,
        roomCode: String,
        afterEventId: Long,
        afterMessageId: Long,
        afterVoiceSignalId: Long,
        callback: (Result) -> Unit
    ) {
        run(callback) {
            requestBlocking(context, "watch_party_poll", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("after_event_id", afterEventId)
                put("after_message_id", afterMessageId)
                put("after_voice_signal_id", afterVoiceSignalId)
            }, requireToken = false)
        }
    }

    fun watchPartyControl(
        context: Context,
        roomCode: String,
        event: String,
        currentTimeSeconds: Double,
        paused: Boolean,
        playbackRate: Float,
        buffering: Boolean = false,
        sourceUrl: String = "",
        subtitleUrl: String = "",
        sourceRef: String = "android",
        callback: (Result) -> Unit = {}
    ) {
        run(callback) {
            requestBlocking(context, "watch_party_control", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("event", event)
                put("current_time", currentTimeSeconds.coerceAtLeast(0.0))
                put("paused", paused)
                put("playback_rate", playbackRate.coerceIn(0.5f, 2f))
                put("buffering", buffering)
                if (sourceUrl.isNotBlank()) put("source_url", sourceUrl)
                if (subtitleUrl.isNotBlank()) put("subtitle_url", subtitleUrl)
                if (sourceRef.isNotBlank()) put("source_ref", sourceRef)
            }, requireToken = false)
        }
    }

    fun watchPartyKickMember(context: Context, roomCode: String, memberId: Long, callback: (Result) -> Unit) {
        if (memberId <= 0L) {
            callback(Result(false, message = "شناسه عضو معتبر نیست", statusCode = 422))
            return
        }
        run(callback) {
            requestBlocking(context, "watch_party_kick", "POST", watchPartyBody(context, roomCode).apply {
                put("member_id", memberId)
            }, requireToken = true)
        }
    }

    fun watchPartyUndoKickMember(context: Context, roomCode: String, memberId: Long, callback: (Result) -> Unit) {
        if (memberId <= 0L) {
            callback(Result(false, message = "شناسه عضو معتبر نیست", statusCode = 422))
            return
        }
        run(callback) {
            requestBlocking(context, "watch_party_undo_kick", "POST", watchPartyBody(context, roomCode).apply {
                put("member_id", memberId)
            }, requireToken = true)
        }
    }

    fun watchPartyRoomSettings(context: Context, roomCode: String, backgroundKey: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_room_settings", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("background_key", backgroundKey)
            }, requireToken = false)
        }
    }

    fun watchPartyMessage(context: Context, roomCode: String, message: String, clientId: String, callback: (Result) -> Unit) {
        run(callback) {
            requestBlocking(context, "watch_party_message", method = "POST", body = watchPartyBody(context, roomCode).apply {
                put("message", message)
                put("client_message_id", clientId)
            }, requireToken = false)
        }
    }

    fun watchPartyVoiceStart(context: Context, roomCode: String, callback: (Result) -> Unit) {
        run(callback) { requestBlocking(context, "watch_party_voice_start", "POST", watchPartyBody(context, roomCode), false) }
    }

    fun watchPartyVoiceAction(context: Context, roomCode: String, callToken: String, action: String, muted: Boolean? = null, callback: (Result) -> Unit = {}) {
        run(callback) {
            requestBlocking(context, "watch_party_voice_action", "POST", watchPartyBody(context, roomCode).apply {
                put("call_token", callToken); put("voice_action", action); muted?.let { put("muted", it) }
            }, false)
        }
    }

    fun watchPartyVoiceSignal(context: Context, roomCode: String, callToken: String, signalType: String, clientSignalId: String, payload: JSONObject, callback: (Result) -> Unit = {}) {
        run(callback) {
            requestBlocking(context, "watch_party_voice_signal", "POST", watchPartyBody(context, roomCode).apply {
                put("call_token", callToken); put("signal_type", signalType); put("client_signal_id", clientSignalId); put("payload", payload)
            }, false)
        }
    }

    fun watchPartyLeave(context: Context, roomCode: String, close: Boolean, callback: (Result) -> Unit = {}) {
        run(callback) {
            val result = requestBlocking(context, if (close) "watch_party_close" else "watch_party_leave", "POST", watchPartyBody(context, roomCode), false)
            if (close && result.success) clearRememberedWatchPartyRoomCode(context)
            result
        }
    }

}
