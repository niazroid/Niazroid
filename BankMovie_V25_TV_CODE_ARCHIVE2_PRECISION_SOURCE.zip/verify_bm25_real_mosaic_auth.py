#!/usr/bin/env python3
"""CI-safe checks: user-supplied poster files and stable auth background.
Does not claim an Android compile, screenshot test, or native 4K detail.
"""
from pathlib import Path
from hashlib import sha256
root=Path(__file__).resolve().parent
src=root/'app/src/main/java/ir/bankmoviee/app'
res=root/'app/src/main/res/drawable-nodpi'
inputs=root/'design-resources/real-poster-inputs'
expected={
    inputs/'hero-wall.jpg': '71bb4b8bf5c2ac104d45be305dce1c5041a7d3780b25360513332662580919b9',
    inputs/'hero-5.webp': '39b4ff828bf1d047308a03dd9c3010789cd291c8b3b823cbe9bf99a6d07dde5e',
}
# Exact user-provided bytes, not synthesized assets.
for f, digest in expected.items():
    assert f.is_file(), f
    assert sha256(f.read_bytes()).hexdigest()==digest, f
for name in ('bm_splash_wall_phone.webp','bm_splash_wall_tv.webp'):
    f=res/name
    assert f.is_file() and f.stat().st_size > 250_000
    raw=f.read_bytes()
    assert raw[:4]==b'RIFF' and raw[8:12]==b'WEBP'
    assert raw.find(b'\x9d\x01\x2a', 12, 80)>=0
assert 'bm_loading_auth_bg.webp' in (root/'scripts/rebuild_real_poster_wall.py').read_text()
assert 'ImageOps.fit(art, (width, h)' in (root/'scripts/rebuild_real_poster_wall.py').read_text()
# Both login and registration use one auth activity and the same bundled
# backdrop. On config refresh no remote/legacy image may replace it.
auth=(src/'AuthActivity.kt').read_text()
assert 'registerMode = intent.getBooleanExtra("register", false)' in auth
assert 'private fun applyBundledBackground()' in auth
assert 'if (isTvLike()) R.drawable.bm_splash_wall_tv' in auth
assert 'else R.drawable.bm_splash_wall_phone' in auth
assert 'private fun loadBackground(' not in auth
assert 'AccountSession.authBackground(this).takeIf' not in auth
assert 'AccountApi.loadConfig(this)' in auth
main=(src/'MainActivity.kt').read_text()
splash=main.split('private fun showSplashOnly()',1)[1].split('private fun discardStartupSplash()',1)[0]
assert 'if (tvSplash) R.drawable.bm_splash_wall_tv' in splash
assert 'else R.drawable.bm_splash_wall_phone' in splash
assert 'if (!tvSplash) {' in splash
print('BM25_REAL_USER_POSTER_WALL_AUTH_BACKGROUND_STABLE_OK')
