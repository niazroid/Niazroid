#!/usr/bin/env python3
"""Rebuild the bundled real poster wall without AI-generated images.

Only developer-time use (requires Pillow); the Android app itself does not
need Pillow and no runtime download is used.
"""
from pathlib import Path
from PIL import Image, ImageOps, ImageFilter
root = Path(__file__).resolve().parents[1]
inputs = root / 'design-resources' / 'real-poster-inputs'
res = root / 'app/src/main/res/drawable-nodpi'
sources = [
    Image.open(inputs / 'hero-wall.jpg').convert('RGB'),
    Image.open(res / 'bm_loading_auth_bg.webp').convert('RGB'),
    Image.open(inputs / 'hero-5.webp').convert('RGB'),
]

def collage(width, height):
    canvas = Image.new('RGB', (width, height))
    sizes = (height//3, height//3, height-2*(height//3))
    y = 0
    for art, h in zip(sources, sizes):
        section = ImageOps.fit(art, (width, h), Image.Resampling.LANCZOS)
        section = section.filter(ImageFilter.UnsharpMask(radius=0.85, percent=88, threshold=3))
        canvas.paste(section, (0, y))
        y += h
    return canvas

for name, w, h, quality in (
    ('bm_splash_wall_phone.webp', 1600, 2844, 92),
    ('bm_splash_wall_tv.webp', 3840, 2160, 93),
):
    collage(w, h).save(res / name, 'WEBP', quality=quality, method=6)
    print(name, (res/name).stat().st_size)
