#!/usr/bin/env python3
"""TV splash typography / user-source fidelity guard. Static only."""
from pathlib import Path
from hashlib import sha256
r=Path(__file__).resolve().parent
src=(r/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
b=src.split('private fun showSplashOnly()',1)[1].split('private fun discardStartupSplash()',1)[0]
assert 'val tvSplash = isTvLike()' in b
assert 'alpha = 1.0f' in b
assert 'scaleX = if (tvSplash) 1.0f else 1.17f' in b
assert 'scaleY = if (tvSplash) 1.0f else 1.17f' in b
assert 'if (!tvSplash) {' in b
assert 'setTextColor(Color.WHITE)' in b
assert 'textSize = if (tvSplash) 21f else 15f' in b
assert 'textSize = if (tvSplash) 14f else 10.8f' in b
assert 'Color.argb(244, 245, 250, 255)' in b
assert b.count('setShadowLayer(') == 2
assert 'Color.argb(if (tvSplash) 125 else 85, 1, 5, 12)' in b
assert b.count('R.drawable.bm_splash_wall_tv') == 1
assert 'setImageResource(UiPreferences.brandLogoRes(this@MainActivity))' in b
# The source-art triptych is made exclusively from the user's original poster
# input files, not any synthetic/generated designs.
expected={
    'hero-wall.jpg': '71bb4b8bf5c2ac104d45be305dce1c5041a7d3780b25360513332662580919b9',
    'hero-5.webp': '39b4ff828bf1d047308a03dd9c3010789cd291c8b3b823cbe9bf99a6d07dde5e',
}
for name,digest in expected.items():
    p=r/'design-resources/real-poster-inputs'/name
    assert sha256(p.read_bytes()).hexdigest()==digest
img=r/'app/src/main/res/drawable-nodpi/bm_splash_wall_tv.webp'
assert img.stat().st_size < 3_000_000 and img.stat().st_size > 300_000
raw=img.read_bytes()
assert raw[:4]==b'RIFF' and raw[8:12]==b'WEBP'
needle=raw.find(bytes((0x9d,0x01,0x2a)),12,80)
assert needle>=0
width=int.from_bytes(raw[needle+3:needle+5],'little') & 0x3fff
height=int.from_bytes(raw[needle+5:needle+7],'little') & 0x3fff
assert (width,height)==(3840,2160)
print('BM25_TV_SPLASH_READABILITY_NATIVE_ART_STATIC_OK')
