#!/usr/bin/env python3
"""Static guard for BankMovie UI polish; device and Gradle build still required."""
from pathlib import Path
root=Path(__file__).resolve().parent
k=root/'app/src/main/java/ir/bankmoviee/app'
player=(k/'PlayerActivity.kt').read_text()
bridge=(k/'Media3PlaybackBridge.kt').read_text()
main=(k/'MainActivity.kt').read_text()
ring=(k/'ThemeWindowLoadingView.kt').read_text()
inline=(k/'InlineSpinnerButton.kt').read_text()
build=(root/'app/build.gradle').read_text()
assert 'org.videolan.android:libvlc' not in build, 'VLC dependency inadvertently restored'
assert 'Media3Player.Event.Buffering' in player
assert 'playbackBufferRing = ThemeWindowLoadingView(this)' in player
assert 'play.addView(playbackBufferRing' in player
assert 'setBufferRingVisible(true)' in player
assert 'playbackBufferOverlay' not in player, 'Old fullscreen buffering overlay still bundled'
assert 'در حال بافرینگ ویدیو' not in player
assert 'ThemeLoadingArc.draw' in ring and 'ThemeLoadingArc.draw' in inline
assert 'UiPreferences.palette(context).primary' in inline
assert 'private fun movieDetailGlassLoading()' in main
assert 'private fun notificationGlassLoadingSkeleton()' in main
assert 'private fun boxOfficeGlassLoadingSkeleton()' in main
assert 'return movieDetailGlassLoading()' in main
assert 'val loading = notificationGlassLoadingSkeleton()' in main
assert 'return boxOfficeGlassLoadingSkeleton()' in main
assert 'TrackSelectionOverride' in bridge and 'fun getAudioTracks()' in bridge
assert 'private fun trackDisplayTitle' in bridge
assert 'f.codecs?.takeIf' not in bridge, 'Codec metadata is still printed in the track picker'
assert 'private fun localizedLanguage' in bridge
assert all(x in bridge for x in ('getSpuTracks()', '"namava"', '"filimo"', '"gapfilm"'))
assert '1.10.1' in build  # preserve the working Media3 version
print('MEDIA3_UI_POLISH_STATIC_CHECK_OK (not a compile/device validation)')
