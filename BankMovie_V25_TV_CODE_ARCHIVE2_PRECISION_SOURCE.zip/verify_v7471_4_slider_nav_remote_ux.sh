#!/usr/bin/env bash
set -euo pipefail
MAIN="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
ONBOARD="app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"
VAULT="app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt"
WORKFLOW=".github/workflows/build-bankmovie.yml"

for f in "$MAIN" "$ONBOARD" "$VAULT" "$WORKFLOW"; do test -s "$f"; done

# Slider: update just the visible hero when the authoritative feed arrives.
# Rebuilding Home used to reset the poster cache, horizontal scroll and TV focus.
python3 - <<'PYCHECK'
from pathlib import Path
m = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
trigger = 'if (appShellBuilt && currentScreen == "home" && previousSliders != mergedSliders) {'
assert trigger in m, 'slider feed change must be handled while Home is visible'
block = m[m.index(trigger):m.index(trigger) + 220]
assert 'refreshHomeSliderInPlace(it)' in block, 'update only the changed hero'
assert 'showHome()' not in block, 'never rebuild every poster rail on slider refresh'
helper = m[m.index('private fun refreshHomeSliderInPlace('):m.index('private fun showHome()', m.index('private fun refreshHomeSliderInPlace('))]
assert 'val previousScroll = scroll.scrollY' in helper, 'preserve home scroll during slider refresh'
assert 'scroll.scrollTo(0, previousScroll)' in helper, 'restore home scroll after slider refresh'
print('V7471_4_SLIDER_TARGETED_UPDATE_OK')
PYCHECK

# Quick setup exposes the same persisted mobile navigation style used by Settings.
grep -q 'private var mobileNavStyle = "classic"' "$ONBOARD"
grep -q 'KEY_MOBILE_NAV_STYLE, mobileNavStyle' "$ONBOARD"
grep -q 'مدل ناوبری موبایل' "$ONBOARD"
grep -q 'Triple("center_fab"' "$ONBOARD"

# Back transition + bottom sheet contract.
grep -q 'native-feeling back transition' "$MAIN"
grep -q 'PathInterpolator(0.16f, 1f, 0.30f, 1f)' "$MAIN"
grep -q 'bottom sheets have only two resting states' "$MAIN"
modal_block="$(grep -A170 'private fun wireV728DraggableBottomSheet' "$MAIN")"
! grep -q '0.42f' <<<"$modal_block"
grep -q 'dismissDown()' <<<"$modal_block"

# Movie copy-link is removed; series may still copy individual links and bulk by season.
grep -q 'val seriesDownloadLink = itemContentType(item) == "series"' "$MAIN"
grep -q 'clientMode == "adm_copy" && seriesDownloadLink' "$MAIN"
grep -q 'openAdmOnly(url, allowClipboardFallback = seriesDownloadLink)' "$MAIN"
grep -q 'private fun openAdmOnly(url: String, allowClipboardFallback: Boolean = true)' "$MAIN"
grep -q 'همه فصل‌ها' "$MAIN"
grep -q 'selectedSeason\[0\] == 0' "$MAIN"

# RuntimeVault decode must point remote config/secondary host at bankmoviez.top.
python3 - <<'PY'
import re
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt').read_text(encoding='utf-8')
def decode(name):
    m=re.search(rf'private val {name}Data = intArrayOf\(([^)]*)\)',s)
    q=re.search(rf'private const val {name}Seed = (\d+)',s)
    if not m or not q: raise SystemExit(f'missing vault field: {name}')
    data=[int(x.strip()) for x in m.group(1).split(',') if x.strip()]
    seed=int(q.group(1))
    return ''.join(chr(v ^ ((seed+i*31+((i*i*7)&0xff)) & 0xffff)) for i,v in enumerate(data))
expected={
 'CONFIG_URL_PRIMARY':'https://bankmoviez.top/app_config.php',
 'CONFIG_URL_SECONDARY':'https://www.bankmoviez.top/app_config.php',
 'HOST_SECONDARY':'bankmoviez.top',
 'HOST_SECONDARY_WWW':'www.bankmoviez.top',
}
for k,v in expected.items():
    actual=decode(k)
    if actual != v: raise SystemExit(f'{k}: {actual!r} != {v!r}')
print('RuntimeVault remote controller OK')
PY

# Exact old remote domain must be gone from runtime/server text (package id is intentionally unchanged).
if grep -RIn --exclude-dir=build --exclude='*.zip' 'bankmoviee[.]ir' app server-required >/tmp/v7471_4_old_domain.txt; then
  cat /tmp/v7471_4_old_domain.txt
  echo 'Old remote controller domain is still present.' >&2
  exit 1
fi

# Validate current workflow source and Android version without pinning an old ZIP filename.
# Historical feature checks above remain unchanged.
bash verify_v7471_source_zip.sh "$WORKFLOW"
grep -q 'verify_v7471_4_slider_nav_remote_ux.sh' "$WORKFLOW"

echo VERIFY_V7471_4_SLIDER_NAV_REMOTE_UX_OK
