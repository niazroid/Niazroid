#!/usr/bin/env python3
"""Static guard for animated mobile splash and non-animated Android TV splash.

Not a substitute for Android compilation or real-device testing.
"""
from pathlib import Path
import re

root = Path(__file__).resolve().parent
src = (root / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
assert 'private var startupPosterPanAnimator: ValueAnimator? = null' in src
assert 'private fun stopStartupPosterPan()' in src
assert 'startupPosterPanAnimator?.cancel()' in src
assert 'startupPosterPanAnimator?.removeAllUpdateListeners()' in src

splash = src.split('private fun showSplashOnly()', 1)[1].split('private fun discardStartupSplash()', 1)[0]
# One TV-detection value is shared by all splash decisions; don't require
# the old spelling `if (isTvLike())` from the earlier release.
assert 'val tvSplash = isTvLike()' in splash
assert 'setImageResource(if (tvSplash) R.drawable.bm_splash_wall_tv' in splash
assert 'else R.drawable.bm_splash_wall_phone)' in splash
assert 'scaleType = ImageView.ScaleType.CENTER_CROP' in splash
assert 'scaleX = if (tvSplash) 1.0f else 1.17f' in splash
assert 'scaleY = if (tvSplash) 1.0f else 1.17f' in splash
assert 'alpha = 1.0f' in splash
assert 'translationX = if (tvSplash) 0f else -posterDriftX' in splash
assert 'translationY = if (tvSplash) 0f else posterDriftY' in splash
assert 'val posterDriftX = if (tvSplash) 0f else dp(24).toFloat()' in splash
assert 'val posterDriftY = if (tvSplash) 0f else dp(14).toFloat()' in splash

# The animation must be gated behind the phone-only branch, not accidentally
# started on TV; at most one startup animator is created.
start = splash.index('if (!tvSplash) {')
anim = splash.index('startupPosterPanAnimator = ValueAnimator.ofFloat(0f, 1f)')
assert start < anim
assert splash.count('startupPosterPanAnimator = ValueAnimator.ofFloat(0f, 1f)') == 1
assert 'repeatCount = ValueAnimator.INFINITE' in splash[start:]
assert 'repeatMode = ValueAnimator.REVERSE' in splash[start:]
assert 'splashBackdrop.translationX = posterDriftX * (2f * f - 1f)' in splash[start:]
assert 'splashBackdrop.translationY = posterDriftY * (1f - 2f * f)' in splash[start:]

# Logo and loading indicators are outside the moving backdrop/animation.
assert 'setImageResource(UiPreferences.brandLogoRes(this@MainActivity))' in splash
assert 'LinearLayout.LayoutParams(dp(if (tvSplash) 186 else 182), dp(if (tvSplash) 89 else 87))' in splash
assert 'ThemeWindowLoadingView(this@MainActivity)' in splash
assert 'stopStartupPosterPan()' in src.split('private fun discardStartupSplash()', 1)[1].split('private fun attachStartupSplashOverlay()', 1)[0]
assert 'stopStartupPosterPan()' in src.split('private fun dismissStartupSplashAfterHomeFrame()', 1)[1].split('private fun showNetworkError(', 1)[0]
assert 'stopStartupPosterPan()' in src.split('override fun onDestroy()', 1)[1]
assert (root / 'app/src/main/res/drawable-nodpi/bm_splash_wall_tv.webp').is_file()
assert (root / 'app/src/main/res/drawable-nodpi/bm_splash_wall_phone.webp').is_file()
assert not re.search(r'(?i)android\.animation\.ObjectAnimator|ffmpeg', splash)
print('BM25_SPLASH_MOBILE_PAN_TV_STATIC_OK')
