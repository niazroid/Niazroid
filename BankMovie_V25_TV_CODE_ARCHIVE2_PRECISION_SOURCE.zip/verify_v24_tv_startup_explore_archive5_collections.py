#!/usr/bin/env python3
"""Source-level regression guard for TV startup, Explore, Archive 5 and collections."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
MAIN = ROOT / 'app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
STYLE = ROOT / 'app/src/main/res/values/styles.xml'
WORKFLOW = ROOT / '.github/workflows/build-bankmovie.yml'
src = MAIN.read_text()
style = STYLE.read_text()
workflow = WORKFLOW.read_text()


def fn(name: str, source: str = src) -> str:
    marker = f'private fun {name}'
    start = source.find(marker)
    assert start >= 0, f'missing function: {name}'
    next_pos = source.find('\n    private fun ', start + len(marker))
    return source[start: next_pos if next_pos >= 0 else len(source)]


# Splash remains visible over the first real Home frame; the window itself is never white/transparent.
assert 'private var startupSplashView: View? = null' in src
assert 'private fun attachStartupSplashOverlay()' in src
assert 'root.addView(splash, FrameLayout.LayoutParams(-1, -1))' in fn('attachStartupSplashOverlay')
assert 'private fun dismissStartupSplashAfterHomeFrame()' in src
assert 'android.view.ViewTreeObserver.OnPreDrawListener' in fn('dismissStartupSplashAfterHomeFrame')
commit = fn('commitBootShell')
assert commit.index('showHome()') < commit.index('dismissStartupSplashAfterHomeFrame()')
assert 'attachStartupSplashOverlay()' in fn('buildShell')
assert 'window.setBackgroundDrawable(ColorDrawable(bg))' in fn('applyThemeColors')
assert 'android:windowBackground">@color/bm_black' in style
assert 'android:windowContentTransitions">false' in style
assert 'discardStartupSplash()' in fn('showNetworkError')
assert 'discardStartupSplash()' in fn('showBlockedVersionScreen')

# Explore loading text has a constrained width and wraps cleanly on TV and mobile.
discover = fn('showDiscover')
for marker in (
    'val loaderCardWidth =',
    'maxLines = 2',
    'textAlignment = View.TEXT_ALIGNMENT_CENTER',
    'setLineSpacing(dp(3).toFloat(), 1f)',
    'FrameLayout.LayoutParams(loaderCardWidth, -2, Gravity.CENTER)',
):
    assert marker in discover, f'Explore loader missing: {marker}'
assert 'در حال جستجو بین فیلم‌ها و سریال‌ها…' in discover

# Archive 5 ignores cover/backdrop aliases and uses only a subtle poster palette wash.
detail = fn('renderDetailTv')
for marker in (
    'val detailArchiveForArtwork = sanitizeArchive(item.optInt("archive", selectedArchive))',
    'val hasRealBackdrop = detailArchiveForArtwork != 5',
    'val forceArchive5PosterPalette = detailArchiveForArtwork == 5 && poster.isNotBlank()',
    'forceArchive4PosterPalette || forceArchive5PosterPalette',
):
    assert marker in detail, f'Archive 5 detail artwork missing: {marker}'

# TV Home collection rail uses a landscape card like the mobile rail; compact catalogue remains independent.
collection = fn('collectionCard')
assert 'tv -> (tvPosterUsableWidth() * 0.30f).roundToInt().coerceIn(dp(270), dp(360))' in collection
assert 'tv -> (cardWidth * 0.82f).roundToInt().coerceAtLeast(dp(220))' in collection
assert 'val artHeight = (cardHeight * if (tv && !compact) 0.56f else 0.69f).toInt()' in collection
assert 'maxLines = if (compact || tv) 1 else 2' in collection
assert 'tv && compact ->' in collection, 'Do not rewrite the TV compact catalogue grid as the home rail.'

# Profile focus is an explicit reversible path and retries if the next row is still attaching.
profile_first = fn('v71ProfileFirstBodyTarget')
assert profile_first.index('bm_tv_profile_primary') < profile_first.index('bm_tv_profile_downloads')
profile_router = fn('handleTvProfileVerticalSequence')
for marker in (
    'fromPrimary && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN -> downloads',
    'fromStats && keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN -> continueFirst ?: historyFirst ?: actionsFirst',
    'fromContinue && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> downloads',
    'fromHistory && keyCode == android.view.KeyEvent.KEYCODE_DPAD_UP -> continueFirst ?: downloads',
    'requestTvProfileSequenceFocus(next)',
):
    assert marker in profile_router, f'Profile sequence missing: {marker}'
assert 'content.postDelayed({ retry(remaining - 1) }, 55L)' in fn('requestTvProfileSequenceFocus')

# Keep skeleton loaders and the existing search implementation untouched.
for marker in (
    'private fun skeletonPosterCard(width: Int, height: Int): View',
    'private fun movieDetailLoading(seed: JSONObject): View',
    'private fun collectionGridLoadingSkeleton(columns: Int, rows: Int, collectionStyle: Boolean): View',
    'val loading = fancySpinnerText("در حال آوردن همه نتایج...", q)',
):
    assert marker in src, f'Existing loader/search behavior missing: {marker}'
assert 'doSearch()' not in discover, 'Explore-only loader fix must not rewrite search.'
assert re.search(r"(?m)^\s*SOURCE_ZIP:\s*BankMovie_Android_FULLSOURCE_V2\.4_[A-Za-z0-9_.-]+\.zip\s*$", workflow)

print('VERIFY_V24_TV_STARTUP_EXPLORE_ARCHIVE5_COLLECTIONS_OK')
