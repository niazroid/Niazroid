#!/usr/bin/env python3
"""Static regression guard for BankMovie 2.5 skeleton/watch-party changes.
This checks wiring and expected sources, not compiled APK rendering.
"""
from pathlib import Path
r = Path(__file__).resolve().parent
base = r / 'app/src/main/java/ir/bankmoviee/app'
main = (base / 'MainActivity.kt').read_text(encoding='utf-8')
player = (base / 'PlayerActivity.kt').read_text(encoding='utf-8')
gradle = (r / 'app/build.gradle').read_text(encoding='utf-8')
manifest = (r / 'app/src/main/AndroidManifest.xml').read_text(encoding='utf-8')
cache = (base / 'PosterDiskCache.kt').read_text(encoding='utf-8')
assert 'versionName "2.5"' in gradle
assert 'android:label="Bankmovie"' in manifest
assert 'BankMovie TEST' not in manifest
assert 'val heroHeight = dp(472)' in main
assert 'val castHeight = dp(158)' in main
assert 'private fun actorPageGlassLoadingSkeleton()' in main
assert 'if (!isTvLike()) return actorPageGlassLoadingSkeleton()' in main
assert 'page.addView(hero, LinearLayout.LayoutParams(-1, dp(346))' in main
assert 'repeat(9) { index ->' in main
assert 'val overlayVerified = message.optBoolean("is_verified", false)' in player
assert 'header.addView(partyVerifiedBadge(overlayAdmin || overlayVerified, 18)' in player
assert 'bubbleLp.marginEnd = dp(15)' in player
assert 'bubbleLp.marginStart = dp(15)' in player
assert 'bubble.addView(identityRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })' in player
assert 'else -> (w * 0.92f).toInt()' in player
assert 'MAX_BYTES = 48L * 1024L * 1024L' in cache
assert 'org.videolan.android:libvlc' not in gradle
print('BANKMOVIE_25_UI_SOURCE_CHECK_OK (static, not compile/device test)')
