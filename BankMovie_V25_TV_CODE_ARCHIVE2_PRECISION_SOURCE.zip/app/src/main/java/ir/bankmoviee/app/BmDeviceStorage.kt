package ir.bankmoviee.app

import android.content.Context
import android.os.StatFs
import java.io.File

/** Actual storage volume usage including OTHER apps, photos, and existing files. */
internal object BmDeviceStorage {
    data class Snapshot(val totalBytes: Long, val usedBytes: Long, val availableBytes: Long)

    fun snapshot(context: Context): Snapshot? {
        val selectedPath = DownloadLocationPrefs.exactPath(context)
        val candidate = File(selectedPath)
        // A SAF content URI cannot be passed to StatFs. For those providers,
        // fall back to the device's app external volume rather than fabricating a figure.
        val paths = listOfNotNull(
            candidate.takeIf { selectedPath.startsWith("/") && it.exists() },
            context.getExternalFilesDir(null),
            context.filesDir
        )
        for (path in paths) {
            val result = runCatching {
                val stats = StatFs(path.absolutePath)
                val total = stats.totalBytes.coerceAtLeast(0L)
                val available = stats.availableBytes.coerceIn(0L, total)
                if (total > 0L) Snapshot(total, total - available, available) else null
            }.getOrNull()
            if (result != null) return result
        }
        return null
    }
}
