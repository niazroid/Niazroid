package ir.bankmoviee.app

// BANKMOVIE_PASS4_6_2_SOURCE_FINGERPRINT: player-lifecycle-guest-glass-viewgroup-compile-fix
// BANKMOVIE_V7_23_PLAYER_LAST_FRAME_HOLD: PixelCopy SurfaceView freeze-frame lifecycle bridge
// BANKMOVIE_V7_25_PLAYER_FRAME_BRIDGE: hold last frame until a real non-black VLC surface frame is verified
// BANKMOVIE_V7_26_PLAYER_UTILITY_ICON_TUNING: slightly smaller utility glyphs; play/seek controls unchanged

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.provider.OpenableColumns
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLException
import java.security.cert.CertificateException
import java.nio.ByteBuffer
import java.util.UUID
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PLAYLIST_FILE = "playlist_file"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RESUME_POSITION = "resume_position"
        const val EXTRA_WATCH_PARTY_ROOM_CODE = "watch_party_room_code"
        const val EXTRA_WATCH_PARTY_ROLE = "watch_party_role"
        const val EXTRA_WATCH_PARTY_INVITE_URL = "watch_party_invite_url"
        private const val EXTRA_WATCH_PARTY_READY_ENTRY = "watch_party_ready_entry"
        private const val REQ_WATCH_PARTY_AUDIO = 7401
        private const val REQ_LOCAL_SUBTITLE = 7402
        private const val MAX_LOCAL_SUBTITLE_BYTES = 8L * 1024 * 1024

        // V7.22: keep the native player session alive briefly while the app is in
        // the background. Longer retention wastes decoder/native memory; after this
        // window we fall back to the existing saved-position rebuild path.
        private const val PLAYER_BACKGROUND_RETAIN_MS = 180_000L
        // V9 TV: stale HTTP/HLS sessions sometimes play their final cached
        // minutes after a long STOP/PAUSE, then silently stop fetching segments.
        private const val TV_STREAM_IDLE_REOPEN_MS = 75_000L
        private const val TV_STALL_WATCHDOG_MS = 20_000L
        private const val TV_STALL_RETRY_COOLDOWN_MS = 30_000L
        // V7.25: never expose the freshly re-attached black SurfaceView. Probe the
        // underlying VLC surface with tiny PixelCopy samples and remove the held
        // frame only after two consecutive rendered-frame samples are confirmed.
        private const val PLAYER_FRAME_PROBE_INTERVAL_MS = 140L
        private const val PLAYER_FRAME_PROBE_TIMEOUT_MS = 12_000L
        private const val PLAYER_UTILITY_ICON_DP = 24
        private const val VOLUME_BOOST_MAX_PERCENT = 200f
        private const val STATE_PLAYER_INDEX = "bm_player_index"
        private const val STATE_PLAYER_POSITION = "bm_player_position"
        private const val STATE_PLAYER_WAS_PLAYING = "bm_player_was_playing"
        private const val STATE_PLAYER_SPEED = "bm_player_speed"
        private const val STATE_PLAYER_MODE = "bm_player_mode"
        private const val STATE_PARTY_READY_CONFIRMED = "bm_party_ready_confirmed"
        private const val STATE_PARTY_READY_RECREATE = "bm_party_ready_recreate"
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue: Int get() = UiPreferences.accentColor(this)
    private val blue2: Int get() = UiPreferences.blend(blue, Color.WHITE, 0.28f)
    private val blue3: Int get() = Color.argb(170, Color.red(blue), Color.green(blue), Color.blue(blue))
    private val panel = Color.argb(230, 12, 12, 14)
    private val stroke = Color.argb(115, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 192, 202)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: Media3VideoLayout
    private lateinit var lifecycleFrameOverlay: ImageView
    private lateinit var playbackBufferRing: ThemeWindowLoadingView
    private val showPlaybackBufferRunnable = Runnable {
        if (::playbackBufferRing.isInitialized && player != null && playbackExpected && !isFinishing) {
            setBufferRingVisible(true)
        }
    }
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var playerTopActions: LinearLayout
    private lateinit var playerBottomActions: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var playerMetaRow: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var volumeGestureHud: FrameLayout
    private lateinit var volumeGestureTrack: FrameLayout
    private lateinit var volumeGestureLevel: View
    private lateinit var volumeGesturePercent: TextView
    private lateinit var volumeGestureIcon: ImageView
    private var volumeGestureTrackHeightPx = 0
    private lateinit var brightnessGestureHud: FrameLayout
    private lateinit var brightnessGestureTrack: FrameLayout
    private lateinit var brightnessGestureLevel: View
    private lateinit var brightnessGesturePercent: TextView
    private lateinit var brightnessGestureIcon: ImageView
    private var brightnessGestureTrackHeightPx = 0
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: Media3Engine? = null
    private var player: Media3Player? = null
    // V7.46.5: keep SAF/content media descriptors alive for the full VLC session.
    private var activeMediaFd: ParcelFileDescriptor? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private var requestedResumePosition = 0L
    private var resumeTarget = 0L
    private var resumeGuardUntil = 0L
    private var seekJumpMs = 10000L
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartRawY = 0f
    private var lastGestureRawY = 0f
    private var gestureVolumePercent = 0f
    private var currentVlcVolumePercent = 100
    private var lastAppliedBrightness = -1f
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var nextPromptShownKey = ""
    private var skipNextOnce = false
    private var nextPromptDialog: AlertDialog? = null
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var playbackRetryCount = 0
    private var httpMediaFallbackApplied = false
    private var httpMediaSslProbeRunning = false
    private var httpMediaSslProbeGeneration = 0
    private val maxPlaybackRetries = 3
    private var playbackRetryScheduled = false
    private var bufferingStartedAt = 0L
    // Explicit STOP is separate from PAUSE: resume recreates the network source.
    private var tvStoppedByRemote = false
    private var userPausedAtMs = 0L
    private var playbackExpected = false
    private var tvLastClockPositionMs = -1L
    private var tvLastClockAdvanceAtMs = 0L
    private var tvLastRecoveryAtMs = 0L
    private var tvStallRecoveries = 0
    private var recentLongBufferCount = 0
    private var decoderAutoFallbackUsed = false
    private var lifecycleRestorePending = false
    private var lifecycleWasPlaying = false
    private var lifecyclePosition = 0L
    private var lifecyclePausedAt = 0L
    private var pauseAfterLifecycleRestore = false
    private var lifecycleViewsDetached = false
    private var lifecycleRestoreGeneration = 0
    private var restoredFromInstanceState = false
    private var restoredInstanceWasPlaying = true
    // V7.23: keep a lightweight copy of the last rendered video frame above the
    // VLC surface while Android recreates/re-attaches that surface after HOME/app-switch.
    // This prevents the user-visible black flash without retaining a whole View tree.
    private var lifecycleFrameBitmap: Bitmap? = null
    private var lifecycleFrameCapturePending = false
    private var lifecycleFrameAwaitingVideo = false
    private var lifecycleFrameVoutSeen = false
    private var lifecycleFrameCaptureGeneration = 0
    private var lifecycleFrameLastCaptureAt = 0L
    private var lifecycleFrameProbeGeneration = 0
    private var lifecycleFrameProbeStartedAt = 0L
    private var lifecycleFrameProbeReadySamples = 0
    private var lifecycleFrameProbePending = false
    private val releaseRetainedPlayerRunnable = Runnable {
        if (!lifecycleRestorePending || isFinishing || isDestroyed) return@Runnable
        val keep = max(lifecyclePosition, runCatching { player?.time ?: 0L }.getOrDefault(0L)).coerceAtLeast(0L)
        if (keep > 0L) requestedResumePosition = max(requestedResumePosition, keep)
        savePlaybackProgress(true)
        // Free the heavy native decoder after the short retained-session window.
        // onResume will transparently rebuild at requestedResumePosition if needed.
        releasePlayerAsyncForRebuild()
    }
    private var lastGuestControlNoticeAt = 0L
    private var subtitleDelayMs = 0
    // Local subtitles live only inside the active VLC player session. No upload to
    // BankMovie servers, account APIs or database, and no media metadata stored.
    private var manualSubtitleFile: File? = null
    private var manualSubtitleSource = ""
    private var manualSubtitleAttachedPlayer: Media3Player? = null
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackgroundMode = "black"
    private var subtitleFontMode = "system"
    private var subtitleBold = true
    private var lastEnabledSpuTrack = 0
    private var refreshOpenTrackSheet: (() -> Unit)? = null
    private var preferredAudioTrackId = Int.MIN_VALUE
    private var preferredSubtitleTrackId = Int.MIN_VALUE
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val volumeGestureHideRunnable = Runnable {
        if (!::volumeGestureHud.isInitialized) return@Runnable
        volumeGestureHud.animate().cancel()
        volumeGestureHud.animate()
            .alpha(0f)
            .translationX((-dp(6)).toFloat())
            .setDuration(145L)
            .withEndAction { volumeGestureHud.visibility = View.GONE }
            .start()
    }
    private val brightnessGestureHideRunnable = Runnable {
        if (!::brightnessGestureHud.isInitialized) return@Runnable
        brightnessGestureHud.animate().cancel()
        brightnessGestureHud.animate()
            .alpha(0f)
            .translationX(dp(6).toFloat())
            .setDuration(145L)
            .withEndAction { brightnessGestureHud.visibility = View.GONE }
            .start()
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }


    // PASS 4 — Native Watch Party state. The app talks to the exact same tables
    // used by the website through app_user_api.php, so web and Android can share a room.
    private var partyRoomCode = ""
    private var partyRole = ""
    private var partyInviteUrl = ""
    private var partyIsHost = false
    private var partyActive = false
    private var partyApplyingRemote = false
    private var partyLastEventId = 0L
    private var partyLastMessageId = 0L
    private var partyLastSequence = -1L
    private var partyServerOffsetMs = 0L
    private var partyLastPollAt = 0L
    private var partyLastErrorShownAt = 0L
    private var partyLastHeartbeatAt = 0L
    private var partyLastHostActionAt = 0L
    private var partyMembers = JSONArray()
    private var partyKickedMembers = JSONArray()
    private var partyThemeKey = "simple"
    private var partyRoomTitle = ""
    private var partyRoomPoster = ""
    private var partyChatEnabled = true
    private var partyPollInFlight = false
    private var partyDock: LinearLayout? = null
    private var partyStatusChip: TextView? = null
    private var partyChatScroll: ScrollView? = null
    private var partyChatList: LinearLayout? = null
    private var partyChatDialog: AlertDialog? = null
    private var partyLobbyDialog: AlertDialog? = null
    private val partyMessageIdsShown = linkedSetOf<Long>()
    private var partyUnreadChat = 0
    private var partyChatButton: View? = null
    private var partyPlaybackStarted = false
    // A joined guest must explicitly confirm inside the player lobby before any
    // host state is allowed to create/start the local decoder.
    private var partyReadyConfirmed = false
    // V7.45.1 — Ready transition is an Activity rebuild, not an in-place VLC attach.
    // This keeps the exact normal-player startup path that is stable on MIUI/Xiaomi.
    private var partyReadyRecreateRequested = false
    private var partyPlayerStarting = false
    private var partyPlayerStable = false
    private var partyGuestAutoStarting = false
    private var partyLastExplicitPlaySentAt = 0L
    private val partyChromeHideRunnable = Runnable {
        if (partyActive && partyChatDialog?.isShowing != true) setPartyChromeVisible(false)
    }

    private val partyPollRunnable = object : Runnable {
        override fun run() {
            if (partyActive && !isFinishing && !isDestroyed) {
                // Never let network sync race the Ready -> fresh Activity transition or
                // the native Media3Engine attach. Polling resumes only after Playing confirms
                // that the single player instance is stable.
                if (!partyReadyRecreateRequested && (!partyReadyConfirmed || partyPlayerStable)) {
                    pollWatchParty()
                    if (partyIsHost) sendWatchPartyHeartbeatIfNeeded()
                }
                handler.postDelayed(this, if (partyReadyConfirmed) 900L else 650L)
            }
        }
    }

    // PASS 4.3 — Voice Call/WebRTC intentionally removed. Watch Party is chat + synchronized playback only.

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        try {
            parseIncoming()
            loadUiPreferences()
            restoreInstancePlaybackState(savedInstanceState)
            if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
            if (currentIndex !in tracks.indices) currentIndex = 0
            videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
            title = tracks.getOrNull(currentIndex)?.title ?: title
            progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
            if (videoUrl.isBlank()) throw IllegalArgumentException("Empty playback URL")
            currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
            buildUi()
            if (partyRoomCode.isNotBlank()) {
                partyActive = true
                partyIsHost = partyRole.equals("host", true)
                buildWatchPartyOverlay()
                updateGuestPlaybackLockUi()
                handler.removeCallbacks(partyPollRunnable)
                if (partyReadyConfirmed) {
                    // Fresh Ready instance: enter through the same stable startup path as
                    // the normal internal player. Do not show the lobby and do not poll
                    // until Media3Player.Event.Playing marks the native player stable.
                    partyPlaybackStarted = true
                    partyPlayerStarting = true
                    requestedResumePosition = 0L
                    pauseAfterLifecycleRestore = !partyIsHost
                    launchPlayerSafely(videoUrl)
                } else {
                    showWatchPartyLobby()
                    handler.postDelayed(partyPollRunnable, 450L)
                }
            } else {
                if (restoredFromInstanceState && !restoredInstanceWasPlaying) {
                    pauseAfterLifecycleRestore = true
                }
                switchTo(currentIndex, preserveRequestedResume = restoredFromInstanceState)
            }
        } catch (_: Throwable) {
            Toast.makeText(this, "این نسخه پخش معتبر نیست؛ نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun restoreInstancePlaybackState(state: Bundle?) {
        if (state == null) return
        restoredFromInstanceState = true
        currentIndex = state.getInt(STATE_PLAYER_INDEX, currentIndex)
        requestedResumePosition = max(
            requestedResumePosition,
            state.getLong(STATE_PLAYER_POSITION, 0L).coerceAtLeast(0L)
        )
        restoredInstanceWasPlaying = state.getBoolean(STATE_PLAYER_WAS_PLAYING, true)
        currentSpeed = state.getFloat(STATE_PLAYER_SPEED, currentSpeed).coerceIn(0.5f, 2.0f)
        modeIndex = state.getInt(STATE_PLAYER_MODE, modeIndex).coerceIn(0, modes.lastIndex)
        partyReadyConfirmed = state.getBoolean(STATE_PARTY_READY_CONFIRMED, partyReadyConfirmed)
        partyReadyRecreateRequested = state.getBoolean(STATE_PARTY_READY_RECREATE, false)
        if (partyReadyConfirmed) partyReadyRecreateRequested = false
    }

    override fun onSaveInstanceState(outState: Bundle) {
        val current = player
        val pos = max(
            requestedResumePosition,
            runCatching { current?.time ?: lifecyclePosition }.getOrDefault(lifecyclePosition)
        ).coerceAtLeast(0L)
        outState.putInt(STATE_PLAYER_INDEX, currentIndex)
        outState.putLong(STATE_PLAYER_POSITION, pos)
        outState.putBoolean(STATE_PLAYER_WAS_PLAYING, runCatching { current?.isPlaying ?: lifecycleWasPlaying }.getOrDefault(lifecycleWasPlaying))
        outState.putFloat(STATE_PLAYER_SPEED, currentSpeed)
        outState.putInt(STATE_PLAYER_MODE, modeIndex)
        outState.putBoolean(STATE_PARTY_READY_CONFIRMED, partyReadyConfirmed || partyReadyRecreateRequested)
        outState.putBoolean(STATE_PARTY_READY_RECREATE, partyReadyRecreateRequested)
        super.onSaveInstanceState(outState)
    }

    private var currentBrightness = 0.55f

    private fun loadUiPreferences() {
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackgroundMode = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleDelayMs = UiPreferences.subtitleDelayMs(this)
        subtitleFontMode = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePositionIndex = UiPreferences.subtitlePosition(this)
        seekJumpMs = UiPreferences.seekSeconds(this).toLong() * 1000L
        autoPlayNext = UiPreferences.autoNext(this)
    }

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        requestedResumePosition = intent.getLongExtra(EXTRA_RESUME_POSITION, 0L).coerceAtLeast(0L)
        partyRoomCode = intent.getStringExtra(EXTRA_WATCH_PARTY_ROOM_CODE).orEmpty().trim()
        partyRole = intent.getStringExtra(EXTRA_WATCH_PARTY_ROLE).orEmpty().trim()
        partyInviteUrl = intent.getStringExtra(EXTRA_WATCH_PARTY_INVITE_URL).orEmpty().trim()
        partyReadyConfirmed = intent.getBooleanExtra(EXTRA_WATCH_PARTY_READY_ENTRY, false)
        val payloadFile = intent.getStringExtra(EXTRA_PLAYLIST_FILE).orEmpty()
        val json = if (payloadFile.isNotBlank()) {
            runCatching {
                File(payloadFile).takeIf { it.isFile && it.length() in 1..2_500_000L }?.readText(Charsets.UTF_8).orEmpty()
            }.getOrDefault("").ifBlank { intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty() }
        } else {
            intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty()
        }
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until min(arr.length(), 160)) {
                    val it = arr.optJSONObject(i) ?: continue
                    if (it.optString("url").isBlank()) continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, Color.red(blue), Color.green(blue), Color.blue(blue)))
            setStroke(dp(2), Color.argb(205, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), blue2)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            v.foreground = if (has) playerFocusDrawable(radiusDp) else originalForeground
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.translationZ = if (has) dp(8).toFloat() else 0f
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(if (has) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun focusPlayButton() {
        if (partyGuestPlaybackLocked()) {
            partyChatButton?.takeIf { it.isShown && it.isFocusable }?.requestFocus() ?: root.requestFocus()
            return
        }
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                if (v is android.view.ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                }
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 55)
    }

    private fun ccAudioSubtitleButton(click: () -> Unit): View {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            contentDescription = "صدا و زیرنویس"
            applyPlayerFocus(this, 20, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_player_cc)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = Media3VideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        // V7.23 LAST-FRAME HOLD: sits above VLC only, below all player chrome.
        // It is shown solely during lifecycle restoration and disappears only after
        // VLC reports a fresh video output/time update.
        lifecycleFrameOverlay = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_XY
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
            isFocusable = false
            isClickable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        root.addView(lifecycleFrameOverlay, FrameLayout.LayoutParams(-1, -1))

        // Buffering arc lives *inside* the original play button below; no giant
        // overlay, dark halo, toast or status text can obscure the video.

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        // V7.44.5: VLC-style gesture HUDs with corrected spacing and direction.
        // The SVG icon now has a real visual gap below the slider, the label is
        // separated from the pill, and the fill is explicitly anchored at the
        // bottom so a larger value always grows upward on-screen.
        volumeGestureHud = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            translationX = (-dp(6)).toFloat()
            isClickable = false
            isFocusable = false
            clipChildren = false
            clipToPadding = false
        }
        val volumeRail = FrameLayout(this).apply {
            background = playerGestureRailSurface()
            elevation = dp(8).toFloat()
            setPadding(dp(7), dp(8), dp(7), dp(8))
        }
        volumeGestureHud.addView(volumeRail, FrameLayout.LayoutParams(dp(60), -1, Gravity.START))

        volumeGesturePercent = TextView(this).apply {
            text = "0%"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        volumeRail.addView(volumeGesturePercent, FrameLayout.LayoutParams(-1, dp(24), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(4)
        })

        volumeGestureTrackHeightPx = dp(88)
        volumeGestureTrack = FrameLayout(this).apply {
            background = rounded(Color.argb(118, 255, 255, 255), dp(999), Color.TRANSPARENT)
            clipToOutline = true
        }
        volumeGestureLevel = View(this).apply {
            background = rounded(Color.WHITE, dp(999), Color.TRANSPARENT)
            scaleY = 0f
            // Fixed pixel pivot avoids device/layout timing differences that made
            // the white fill look inverted on some landscape devices.
            pivotY = volumeGestureTrackHeightPx.toFloat()
        }
        volumeGestureTrack.addView(volumeGestureLevel, FrameLayout.LayoutParams(-1, volumeGestureTrackHeightPx, Gravity.BOTTOM))
        volumeRail.addView(volumeGestureTrack, FrameLayout.LayoutParams(dp(9), volumeGestureTrackHeightPx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(42)
        })

        volumeGestureIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_volume_gesture)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        volumeRail.addView(volumeGestureIcon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(12)
        })
        volumeGestureHud.addView(TextView(this).apply {
            text = "Volume"
            setTextColor(Color.WHITE)
            textSize = 13.2f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.LEFT
            includeFontPadding = false
            alpha = 0.98f
        }, FrameLayout.LayoutParams(dp(72), dp(36), Gravity.CENTER_VERTICAL or Gravity.END))
        root.addView(volumeGestureHud, FrameLayout.LayoutParams(dp(150), dp(198), Gravity.START or Gravity.CENTER_VERTICAL).apply {
            leftMargin = dp(10)
        })

        brightnessGestureHud = FrameLayout(this).apply {
            visibility = View.GONE
            alpha = 0f
            translationX = dp(6).toFloat()
            isClickable = false
            isFocusable = false
            clipChildren = false
            clipToPadding = false
        }
        val brightnessRail = FrameLayout(this).apply {
            background = playerGestureRailSurface()
            elevation = dp(8).toFloat()
            setPadding(dp(7), dp(8), dp(7), dp(8))
        }
        brightnessGestureHud.addView(brightnessRail, FrameLayout.LayoutParams(dp(60), -1, Gravity.END))

        brightnessGesturePercent = TextView(this).apply {
            text = "0%"
            setTextColor(Color.WHITE)
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
        }
        brightnessRail.addView(brightnessGesturePercent, FrameLayout.LayoutParams(-1, dp(24), Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(4)
        })

        brightnessGestureTrackHeightPx = dp(88)
        brightnessGestureTrack = FrameLayout(this).apply {
            background = rounded(Color.argb(118, 255, 255, 255), dp(999), Color.TRANSPARENT)
            clipToOutline = true
        }
        brightnessGestureLevel = View(this).apply {
            background = rounded(Color.WHITE, dp(999), Color.TRANSPARENT)
            scaleY = 0f
            pivotY = brightnessGestureTrackHeightPx.toFloat()
        }
        brightnessGestureTrack.addView(brightnessGestureLevel, FrameLayout.LayoutParams(-1, brightnessGestureTrackHeightPx, Gravity.BOTTOM))
        brightnessRail.addView(brightnessGestureTrack, FrameLayout.LayoutParams(dp(9), brightnessGestureTrackHeightPx, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(42)
        })

        brightnessGestureIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_brightness_gesture)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }
        brightnessRail.addView(brightnessGestureIcon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            bottomMargin = dp(12)
        })
        brightnessGestureHud.addView(TextView(this).apply {
            text = "Brightness"
            setTextColor(Color.WHITE)
            textSize = 13.2f
            typeface = Typeface.DEFAULT
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
            includeFontPadding = false
            alpha = 0.98f
        }, FrameLayout.LayoutParams(dp(92), dp(36), Gravity.CENTER_VERTICAL or Gravity.START))
        root.addView(brightnessGestureHud, FrameLayout.LayoutParams(dp(174), dp(198), Gravity.END or Gravity.CENTER_VERTICAL).apply {
            rightMargin = dp(10)
        })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(58, 0, 0, 0), Color.TRANSPARENT)
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { if (partyActive) showPartyRoomSheet() else finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)))

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            clipChildren = false
            clipToPadding = false
        }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        subText = TextView(this).apply {
            text = currentLabel()
            visibility = View.GONE
        }
        playerMetaRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            clipChildren = false
            clipToPadding = false
        }
        info.addView(titleText)
        info.addView(playerMetaRow, LinearLayout.LayoutParams(-1, dp(30)).apply { topMargin = dp(2) })
        info.addView(subText, LinearLayout.LayoutParams(1,1))
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })
        rebuildPlayerMetaChips()

        playerTopActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        playerTopActions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(58), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(ccAudioSubtitleButton { showAudioSubtitleSettingsSheet() }, LinearLayout.LayoutParams(dp(50), dp(48)).apply { marginStart = dp(3) })
        playerTopActions.addView(simplePlayerIcon(R.drawable.ic_player_pip) { enterPipMode() }, LinearLayout.LayoutParams(dp(50), dp(48)))
        topBar.addView(playerTopActions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(74), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        val jumpLabel = (seekJumpMs / 1000L).toString()
        val rewind = circleAction(R.drawable.ic_player_replay, jumpLabel) { seekBy(-seekJumpMs) }.apply { id = View.generateViewId() }
        val play = FrameLayout(this).apply {
            id = View.generateViewId()
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playbackBufferRing = ThemeWindowLoadingView(this).apply {
            visibility = View.GONE
            isFocusable = false
            isClickable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        play.addView(playbackBufferRing, FrameLayout.LayoutParams(dp(74), dp(74), Gravity.CENTER))
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, jumpLabel) { seekBy(seekJumpMs) }.apply { id = View.generateViewId() }
        rewind.nextFocusRightId = play.id
        play.nextFocusLeftId = rewind.id
        play.nextFocusRightId = forward.id
        forward.nextFocusLeftId = play.id
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(22) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(82), dp(82)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginStart = dp(22) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(104), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(4), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(225, 0, 0, 0))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        playerBottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            // Utility controls live on the opposite/right edge, away from the
            // timeline start and closer to the top-right playback tools.
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        val settingsButton = glassIconButton(R.drawable.ic_player_settings) { showSettingsSheet() }
        playerBottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(58), dp(32)).apply { marginEnd = dp(8) })
        playerBottomActions.addView(settingsButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        playerBottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        bottomBar.addView(playerBottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); gravity = Gravity.RIGHT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(116), Gravity.BOTTOM))

        // Use the same state transition as the normal lock button. The previous
        // direct boolean assignment left this unlock icon visible after unlocking.
        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { toggleLock() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(18) })

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) {
                handler.removeCallbacks(hideRunnable)
                onUserSeek()
            }
            override fun onStopTrackingTouch(s: SeekBar?) {
                if (partyGuestPlaybackLocked()) {
                    showGuestPlaybackLockedNotice()
                    updateProgress()
                    hideBarsLater()
                    return
                }
                val progress = s?.progress ?: 0
                val p = player ?: return
                if (p.length > 0) {
                    onUserSeek()
                    p.time = (progress.toLong() * p.length) / 1000L
                }
                if (partyActive && partyIsHost) sendWatchPartyControl("seek")
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    // ---------------------------------------------------------------------
    // PASS 4.3 — Native Watch Party room UI + sync + site-style chat + sticker packs
    // ---------------------------------------------------------------------
    private fun partyGlass(radius: Int = 22, alpha: Int = 232, strokeAlpha: Int = 92): GradientDrawable {
        // V7.44.6 — Watch Party gets its own midnight/cyan glass language,
        // matching the approved mockup instead of the old charcoal/green cards.
        val top = Color.argb(alpha.coerceIn(0,255), 8, 31, 56)
        val bottom = Color.argb((alpha - 14).coerceIn(0,255), 4, 17, 34)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0,255), 42, 169, 255))
        }
    }

    private fun partyAccent(radius: Int = 20): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(27, 225, 235), Color.rgb(17, 126, 255))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(210, 99, 229, 255))
        }

    private fun partySoftAccent(radius: Int = 18): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(178, 5, 71, 91), Color.argb(190, 7, 38, 78))).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(150, 22, 207, 235))
        }

    private fun partyRoundIcon(iconRes: Int, sizeDp: Int = 42, click: (() -> Unit)? = null): FrameLayout = FrameLayout(this).apply {
        background = partyGlass(999, 218, 92)
        isClickable = click != null
        isFocusable = click != null
        if (click != null) {
            applyPlayerFocus(this, 999, 1.07f, 0f)
            setOnClickListener { click() }
        }
        addView(ImageView(this@PlayerActivity).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }, FrameLayout.LayoutParams(dp((sizeDp * .46f).roundToInt()), dp((sizeDp * .46f).roundToInt()), Gravity.CENTER))
    }

    // PASS 4.6 — player chrome uses the same charcoal glass language as the app.
    private fun playerGlassSurface(radius: Int = 24, alpha: Int = 238, strokeAlpha: Int = 72): GradientDrawable {
        val top = Color.argb(alpha.coerceIn(0, 255), 38, 39, 44)
        val bottom = Color.argb((alpha - 18).coerceIn(0, 255), 21, 22, 26)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0, 255), 255, 255, 255))
        }
    }

    /**
     * V7.47.1.21 — modal/sheet surfaces follow the app theme independently
     * from the always-dark video chrome. This keeps player controls cinematic
     * while Settings / Audio / Subtitle sheets become true Light surfaces.
     */
    private fun playerSheetSurface(radius: Int = 24, elevated: Boolean = false): GradientDrawable {
        val p = UiPreferences.palette(this)
        if (!p.light) return playerGlassSurface(radius, if (elevated) 248 else 232, if (elevated) 88 else 62)
        val top = if (elevated) Color.WHITE else p.panel2
        val bottom = if (elevated) p.panel2 else UiPreferences.blend(p.panel2, p.background2, 0.28f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), p.stroke)
        }
    }

    private fun playerSheetTextColor(): Int = UiPreferences.palette(this).let { if (it.light) it.text else Color.WHITE }
    private fun playerSheetMutedColor(): Int = UiPreferences.palette(this).let { if (it.light) it.muted else muted }
    private fun playerSheetAccentInk(): Int = UiPreferences.readableAccent(this)
    private fun playerSheetTrackColor(): Int = UiPreferences.palette(this).let { if (it.light) it.stroke else Color.argb(95, 255, 255, 255) }

    private fun playerGlassAccent(radius: Int = 20): GradientDrawable {
        val p = UiPreferences.palette(this)
        return GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
            UiPreferences.blend(p.primary, Color.WHITE, 0.12f),
            p.primary
        )).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(120, 255, 255, 255))
        }
    }

    private fun partyGuestPlaybackLocked(): Boolean = partyActive && !partyIsHost

    private fun showGuestPlaybackLockedNotice() {
        val now = System.currentTimeMillis()
        if (now - lastGuestControlNoticeAt < 900L) return
        lastGuestControlNoticeAt = now
        showHud("کنترل پخش دست میزبان است · فقط صدا برای شما آزاد است")
    }

    private fun setPlaybackControlTreeEnabled(view: View, enabled: Boolean) {
        view.isEnabled = enabled
        view.isFocusable = enabled
        view.alpha = if (enabled) 1f else 0.38f
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) setPlaybackControlTreeEnabled(view.getChildAt(i), enabled)
        }
    }

    private fun updateGuestPlaybackLockUi() {
        if (!::seek.isInitialized || !::centerControls.isInitialized) return
        val enabled = !partyGuestPlaybackLocked()
        seek.isEnabled = enabled
        seek.isFocusable = enabled
        seek.alpha = if (enabled) 1f else 0.42f
        setPlaybackControlTreeEnabled(centerControls, enabled)
        if (::playerTopActions.isInitialized) setPlaybackControlTreeEnabled(playerTopActions, enabled)
        if (::playerBottomActions.isInitialized) setPlaybackControlTreeEnabled(playerBottomActions, enabled)
        // Room/chat controls are intentionally separate and stay available to guests.
    }

    private fun partyIcon(icon: Int, description: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            contentDescription = description
            background = partyGlass(18, 232, 76)
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 18, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon); setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }
    }

    private fun ensurePartyStatusChip(): TextView {
        partyStatusChip?.let { return it }
        return TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 9.8f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
            includeFontPadding = false
            maxLines = 1
            background = partySoftAccent(999)
            setPadding(dp(10), 0, dp(10), 0)
            compoundDrawablePadding = dp(5)
            minHeight = dp(25)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 999, 1.03f, 0f)
            setOnClickListener { showPartyChrome(); showPartyRoomSheet() }
        }.also { partyStatusChip = it }
    }

    private fun buildWatchPartyOverlay() {
        // V7.45.2 — Move the room status chip into the top player bar so the
        // center of the video remains visually clean. Also replace text-emoji
        // badges with proper project SVG/vector icons.
        ensurePartyStatusChip()
        rebuildPlayerMetaChips()

        partyDock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(7), dp(6), dp(7))
            background = partyGlass(24, 220, 120)
            elevation = dp(10).toFloat()
        }
        val chat = partyIcon(R.drawable.ic_party_chat, "گفت‌وگوی خصوصی") { showPartyChrome(); showWatchPartyChat() }
        partyChatButton = chat
        val settings = partyIcon(R.drawable.ic_player_settings, "مدیریت اتاق") { showPartyChrome(); showPartyRoomSheet() }
        partyDock?.addView(chat, LinearLayout.LayoutParams(dp(48), dp(48)).apply { bottomMargin = dp(8) })
        partyDock?.addView(settings, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(partyDock, FrameLayout.LayoutParams(dp(62), -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(14) })
        updatePartyStatusChip()
        applyPartyTheme("simple")
        showPartyChrome()
    }

    private fun setPartyChromeVisible(visible: Boolean) {
        val value = if (visible) View.VISIBLE else View.GONE
        partyDock?.visibility = value
        if (visible) {
            partyDock?.alpha = 1f
        }
    }

    private fun showPartyChrome() {
        if (!partyActive) return
        setPartyChromeVisible(true)
        handler.removeCallbacks(partyChromeHideRunnable)
        handler.postDelayed(partyChromeHideRunnable, 5000L)
    }

    private fun updatePartyStatusChip() {
        val chip = ensurePartyStatusChip()
        val count = partyMembers.length()
        val countText = if (count > 0) "$count نفر" else "همگام"
        val normalColor = if (partyPollInFlight) Color.rgb(205, 238, 248) else Color.WHITE
        chip.text = "Watch Party • $countText"
        chip.setTextColor(normalColor)
        chip.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(218, 5, 52, 72), Color.argb(210, 20, 190, 232))).apply {
            cornerRadius = dp(999).toFloat()
            setStroke(dp(1), Color.argb(150, 83, 224, 255))
        }
        val members = ContextCompat.getDrawable(this, R.drawable.ic_party_members)?.mutate()
        members?.setTint(normalColor)
        val role = if (partyIsHost) ContextCompat.getDrawable(this, R.drawable.ic_profile_vip)?.mutate() else null
        role?.setTint(if (partyPollInFlight) Color.rgb(238, 246, 255) else Color.rgb(255, 214, 88))
        chip.setCompoundDrawablesRelativeWithIntrinsicBounds(members, null, role, null)
        chip.compoundDrawablePadding = dp(5)
        updateChatBadge()
    }

    private fun showWatchPartyLobby() {
        if (!partyActive || partyRoomCode.isBlank() || partyReadyConfirmed) return
        if (partyLobbyDialog?.isShowing == true) return
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(15), dp(16), dp(14))
            background = partyGlass(26, 246, 132)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "سینمای خصوصی BankMovie"
                setTextColor(Color.WHITE)
                textSize = 19f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "BankMovie Watch Party"
                setTextColor(Color.rgb(174, 201, 239))
                textSize = 10.5f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(1) })
        }
        header.addView(titleBox, LinearLayout.LayoutParams(0, -2, 1f))
        // V7.44.9 — visual close button stays, but the pre-ready lobby is a hard gate.
        // Do not dismiss/rebuild the player here; simply explain how to continue.
        header.addView(partyRoundIcon(R.drawable.ic_close_clean, 42) {
            Toast.makeText(this, "برای ورود به اتاق روی «شروع تماشا / آماده‌ام» بزنید", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(8) })
        header.addView(FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(21, 221, 235), Color.rgb(13, 120, 255))).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(220, 125, 236, 255))
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_party_members)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(54), dp(54)).apply { marginStart = dp(10) })
        shell.addView(header)

        val infoLine = TextView(this).apply {
            text = if (partyIsHost)
                "◷  این اتاق تا ۴ ساعت فعال است     ⚡  فیلم با کیفیت بالا برای همه اعضا همگام می‌شود."
            else
                "◷  اتاق فعال است     ⚡  بعد از آماده‌شدن، پخش با میزبان همگام می‌شود."
            setTextColor(Color.rgb(181, 207, 232))
            textSize = 10f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.05f)
        }
        shell.addView(infoLine, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(10) })

        val roomCodeShell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(7), dp(10), dp(7))
            background = partyGlass(18, 220, 96)
        }
        val roomText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "کد اتاق"
                setTextColor(Color.rgb(153, 187, 224))
                textSize = 9.5f
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = partyRoomCode
                setTextColor(Color.rgb(225, 239, 255))
                textSize = 13.5f
                typeface = Typeface.MONOSPACE
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(-1, dp(26)).apply { topMargin = dp(2) })
        }
        roomCodeShell.addView(roomText, LinearLayout.LayoutParams(0, -2, 1f))
        roomCodeShell.addView(partyRoundIcon(R.drawable.ic_copy_link, 40) {
            copyPartyInvite()
            Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show()
        }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(10) })
        shell.addView(roomCodeShell, LinearLayout.LayoutParams(-1, -2))

        fun actionButton(label: String, icon: Int, click: () -> Unit): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyGlass(17, 214, 96)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 17, 1.04f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        actions.addView(actionButton("دعوت اعضای اتاق", R.drawable.ic_party_members) {
            // Child sheet opens above the lobby; closing it returns to this same gate.
            showPartyMembers()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(6) })
        actions.addView(actionButton("دعوت", R.drawable.ic_copy_link) {
            sharePartyInvite()
        }, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(6) })
        shell.addView(actions, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val startButton = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyAccent(20)
            elevation = dp(8).toFloat()
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 20, 1.035f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginStart = dp(9) })
            addView(LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                addView(TextView(this@PlayerActivity).apply {
                    text = if (partyIsHost) "همه آماده‌اند؟" else "آماده‌ای؟"
                    setTextColor(Color.argb(220, 255, 255, 255))
                    textSize = 9.4f
                    gravity = Gravity.CENTER
                })
                addView(TextView(this@PlayerActivity).apply {
                    text = "شروع تماشا"
                    setTextColor(Color.WHITE)
                    textSize = 18f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                })
            })
            setOnClickListener {
                if (partyReadyConfirmed || partyReadyRecreateRequested) return@setOnClickListener
                // The old implementation attached Media3Engine inside the same Activity while
                // an AlertDialog and Watch Party poll were active. On MIUI that race can
                // kill the process a few seconds later. Ready now does exactly one thing:
                // close the gate and recreate this Activity. The new instance starts VLC
                // through the normal, proven player startup path before sync is resumed.
                partyReadyRecreateRequested = true
                isEnabled = false
                alpha = 0.86f
                handler.removeCallbacks(partyPollRunnable)
                partyPollInFlight = false
                dialog.setOnDismissListener(null)
                dialog.dismiss()
                partyLobbyDialog = null
                window.decorView.post {
                    if (isFinishing || isDestroyed) return@post
                    partyReadyConfirmed = true
                    partyReadyRecreateRequested = true
                    intent.putExtra(EXTRA_WATCH_PARTY_READY_ENTRY, true)
                    recreate()
                }
            }
        }
        shell.addView(startButton, LinearLayout.LayoutParams(-1, dp(66)).apply { topMargin = dp(11) })

        val syncChip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partySoftAccent(999)
            setPadding(dp(12), dp(5), dp(12), dp(5))
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_detail_update_sync)
                setColorFilter(Color.rgb(46, 223, 242))
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginStart = dp(6) })
            addView(TextView(this@PlayerActivity).apply {
                text = if (partyIsHost) "همگام با میزبان" else "همگام‌سازی با میزبان"
                setTextColor(Color.rgb(66, 226, 242))
                textSize = 10f
                typeface = Typeface.DEFAULT_BOLD
            })
        }
        shell.addView(syncChip, LinearLayout.LayoutParams(-2, dp(32)).apply { gravity = Gravity.CENTER_HORIZONTAL; topMargin = dp(10) })

        dialog = AlertDialog.Builder(this).setView(shell).setCancelable(false).create()
        partyLobbyDialog = dialog
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOnDismissListener { if (partyLobbyDialog === dialog) partyLobbyDialog = null }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if (isTvLike()) dp(650) else (resources.displayMetrics.widthPixels * 0.92f).toInt(), -2)
    }

    private fun updateChatBadge() {
        val button = partyChatButton as? FrameLayout ?: return
        val old = button.findViewWithTag<View>("party_unread")
        if (partyUnreadChat <= 0) { old?.let { button.removeView(it) }; return }
        val badge = (old as? TextView) ?: TextView(this).apply {
            tag = "party_unread"; setTextColor(Color.WHITE); textSize = 8f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; background = rounded(Color.rgb(239,68,68), 999, Color.WHITE)
            button.addView(this, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.RIGHT).apply { topMargin = -dp(3); rightMargin = -dp(3) })
        }
        badge.text = partyUnreadChat.coerceAtMost(99).toString()
    }

    private fun pollWatchParty() {
        if (!partyActive || partyRoomCode.isBlank() || partyPollInFlight) return
        partyPollInFlight = true
        val requestStart = System.currentTimeMillis()
        AccountApi.watchPartyPoll(this, partyRoomCode, partyLastEventId, partyLastMessageId, 0L) { result ->
            val requestEnd = System.currentTimeMillis()
            partyPollInFlight = false
            partyLastPollAt = requestEnd
            if (partyReadyRecreateRequested || (partyReadyConfirmed && !partyPlayerStable)) {
                return@watchPartyPoll
            }
            if (!result.success || result.json == null) {
                if (result.json?.optString("error") == "room_member_kicked" ||
                    result.message.contains("میزبان شما را از اتاق خارج کرده")) {
                    partyActive = false
                    handler.removeCallbacks(partyPollRunnable)
                    Toast.makeText(this, "میزبان شما را از اتاق خارج کرده است", Toast.LENGTH_LONG).show()
                    finish()
                    return@watchPartyPoll
                }
                if (result.statusCode == 404 || result.json?.optString("error") == "room_expired") {
                    partyActive = false
                    handler.removeCallbacks(partyPollRunnable)
                    Toast.makeText(this, result.message.ifBlank { "اتاق Watch Party پایان یافت" }, Toast.LENGTH_LONG).show()
                }
                // Show the actionable HTTP/certificate/content-type reason, but
                // do not spam a toast for every routine polling retry.
                if (requestEnd - partyLastErrorShownAt >= 30000L && result.message.isNotBlank()) {
                    partyLastErrorShownAt = requestEnd
                    Toast.makeText(this, result.message.take(190), Toast.LENGTH_LONG).show()
                }
                updatePartyStatusChip()
                return@watchPartyPoll
            }
            val json = result.json
            json.optLong("server_time_ms", 0L).takeIf { it > 0L }?.let { server ->
                val midpoint = requestStart + (requestEnd - requestStart) / 2L
                val candidate = server - midpoint
                partyServerOffsetMs = if (partyServerOffsetMs == 0L) candidate else ((partyServerOffsetMs * 3L + candidate) / 4L)
            }
            partyRole = json.optString("member_role", partyRole)
            partyIsHost = partyRole.equals("host", true)
            updateGuestPlaybackLockUi()
            partyChatEnabled = json.optBoolean("chat_enabled", true)

            var sharedSource = ""
            json.optJSONObject("room")?.let { room ->
                partyThemeKey = room.optString("background_key", partyThemeKey)
                partyRoomTitle = room.optString("content_title", partyRoomTitle)
                partyRoomPoster = room.optString("poster_url", partyRoomPoster)
                applyPartyTheme(partyThemeKey)
                sharedSource = room.optString("shared_source_url").trim()
                if (partyReadyConfirmed && partyPlayerStable && !partyPlayerStarting && !partyIsHost && sharedSource.isNotBlank() && sharedSource != videoUrl && partyPlaybackStarted) {
                    partyApplyingRemote = true
                    videoUrl = sharedSource
                    requestedResumePosition = 0L
                    handler.postDelayed({
                        launchPlayerSafely(sharedSource)
                        handler.postDelayed({ partyApplyingRemote = false }, 180L)
                    }, 60L)
                }
            }

            val events = json.optJSONArray("events") ?: JSONArray()
            for (i in 0 until events.length()) partyLastEventId = max(partyLastEventId, events.optJSONObject(i)?.optLong("id", 0L) ?: 0L)
            val messages = json.optJSONArray("messages") ?: JSONArray()
            handlePartyMessages(messages)
            partyMembers = json.optJSONArray("members") ?: partyMembers
            partyKickedMembers = json.optJSONArray("kicked_members") ?: JSONArray()
            if (!partyIsHost) {
                val state = json.optJSONObject("state")
                val serverNow = json.optLong("server_time_ms", requestEnd + partyServerOffsetMs)
                if (partyReadyConfirmed && partyPlayerStable && !partyPlayerStarting && state != null && !state.optBoolean("paused", true) && sharedSource.isNotBlank() && (!partyPlaybackStarted || player == null)) {
                    // Android-to-Android: when the host starts, a guest that is still in
                    // the room lobby must create its local VLC player automatically.
                    // Previously only the timeline state moved while player==null.
                    partyPlaybackStarted = true
                    partyGuestAutoStarting = true
                    partyApplyingRemote = true
                    partyLobbyDialog?.dismiss()
                    videoUrl = sharedSource
                    val targetMs = (state.optDouble("current_time", 0.0).coerceAtLeast(0.0) * 1000.0).toLong()
                    requestedResumePosition = targetMs
                    pauseAfterLifecycleRestore = false
                    launchPlayerSafely(sharedSource)
                    handler.postDelayed({
                        partyApplyingRemote = false
                        partyGuestAutoStarting = false
                        applyWatchPartyState(state, serverNow)
                        showPartyChrome()
                    }, 320L)
                } else {
                    state?.let { applyWatchPartyState(it, serverNow) }
                }
            }
            updatePartyStatusChip()
        }
    }

    private fun applyWatchPartyState(state: JSONObject, serverTimeMs: Long) {
        val seq = state.optLong("sequence_no", -1L)
        if (seq < partyLastSequence) return
        partyLastSequence = seq
        val paused = state.optBoolean("paused", true)
        val rate = state.optDouble("playback_rate", 1.0).toFloat().coerceIn(0.5f, 2f)
        var target = state.optDouble("current_time", 0.0).coerceAtLeast(0.0)
        val updatedAt = state.optLong("updated_at_ms", 0L)
        if (!paused && updatedAt > 0L) {
            val effectiveServerNow = if (serverTimeMs > 0L) serverTimeMs else System.currentTimeMillis() + partyServerOffsetMs
            target += ((effectiveServerNow - updatedAt).coerceAtLeast(0L) / 1000.0) * rate
        }
        val p = player ?: return
        val local = p.time.coerceAtLeast(0L) / 1000.0
        val drift = target - local
        partyApplyingRemote = true
        try {
            if (paused && p.isPlaying) p.pause()
            if (!paused && !p.isPlaying) p.play()
            when {
                kotlin.math.abs(drift) > 0.55 -> {
                    onUserSeek()
                    p.time = (target * 1000.0).toLong().coerceAtLeast(0L)
                    p.setRate(rate)
                }
                !paused && kotlin.math.abs(drift) > 0.12 -> {
                    val correction = if (drift > 0) 0.055f else -0.055f
                    p.setRate((rate + correction).coerceIn(0.90f, 1.10f))
                }
                else -> p.setRate(rate)
            }
            currentSpeed = rate
            playIcon.setImageResource(if (paused) R.drawable.ic_player_play else R.drawable.ic_player_pause)
        } catch (_: Throwable) {
        } finally {
            handler.postDelayed({ partyApplyingRemote = false }, 90L)
        }
    }

    private fun currentPartyPositionSeconds(): Double {
        return (player?.time ?: 0L).coerceAtLeast(0L) / 1000.0
    }

    private fun currentPartyPaused(): Boolean {
        return player?.isPlaying != true
    }

    private fun sendWatchPartyControl(event: String, retryAttempt: Int = 0) {
        if (!partyActive || !partyIsHost || partyApplyingRemote || partyRoomCode.isBlank()) return
        partyLastHostActionAt = System.currentTimeMillis()
        AccountApi.watchPartyControl(
            this, partyRoomCode, event, currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed,
            buffering = false, sourceUrl = if (event == "source_change") videoUrl else ""
        ) { result ->
            if (result.success) {
                result.json?.optJSONObject("state")?.optLong("sequence_no", -1L)?.let { if (it >= 0) partyLastSequence = max(partyLastSequence, it) }
            } else if (event != "state" && retryAttempt < 1 && partyActive && partyIsHost) {
                // User actions are important for Android-to-Android rooms. One short
                // retry prevents a dropped PLAY/PAUSE/SEEK request from leaving the
                // other phone with only a moving timestamp and no playback.
                handler.postDelayed({ sendWatchPartyControl(event, retryAttempt + 1) }, 260L)
            }
        }
    }

    private fun sendWatchPartyHeartbeatIfNeeded() {
        val now = System.currentTimeMillis()
        if (!partyActive || !partyReadyConfirmed || !partyPlayerStable || player == null || !partyIsHost || partyApplyingRemote || now - partyLastHeartbeatAt < 1500L || now - partyLastHostActionAt < 900L) return
        partyLastHeartbeatAt = now
        AccountApi.watchPartyControl(this, partyRoomCode, "state", currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed) {}
    }

    private fun handlePartyMessages(messages: JSONArray) {
        for (i in 0 until messages.length()) {
            val message = messages.optJSONObject(i) ?: continue
            val id = message.optLong("id", 0L)
            if (id <= 0L) continue
            partyLastMessageId = max(partyLastMessageId, id)
            if (!partyMessageIdsShown.add(id)) continue
            appendPartyMessage(message)
            showPartyMessageOverlay(message)
            val media = message.optJSONObject("media")
            if (media != null && media.optString("url").isNotBlank()) showPartyReaction(media)
            if (partyChatDialog?.isShowing != true) partyUnreadChat++
        }
        while (partyMessageIdsShown.size > 220) partyMessageIdsShown.remove(partyMessageIdsShown.first())
        updateChatBadge()
    }

    private fun showPartyMessageOverlay(message: JSONObject) {
        if (!partyActive || message.optBoolean("is_mine", false)) return
        val username = message.optString("username").ifBlank { "همراه" }
        val textValue = message.optString("text").ifBlank { message.optString("message") }
        val media = message.optJSONObject("media")
        if (textValue.isBlank() && (media == null || media.optString("url").isBlank())) return

        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = playerGlassSurface(20, 236, 82)
            elevation = dp(8).toFloat()
            alpha = 0f
            translationY = -dp(10).toFloat()
        }
        bubble.addView(partyAvatarView(message, 40), LinearLayout.LayoutParams(dp(40), dp(40)).apply {
            marginEnd = dp(14)
        })

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        val overlayAdmin = message.optBoolean("is_admin", false)
        val overlayVerified = message.optBoolean("is_verified", false)
        val overlayVip = message.optBoolean("is_vip", false) && !overlayAdmin
        header.addView(TextView(this).apply {
            text = username
            setTextColor(when {
                overlayAdmin -> Color.rgb(93, 188, 255)
                overlayVip -> Color.rgb(73, 220, 129)
                else -> Color.WHITE
            })
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false
        }, LinearLayout.LayoutParams(-2, -2))
        if (overlayAdmin || overlayVip || overlayVerified) {
            header.addView(partyVerifiedBadge(overlayAdmin || overlayVerified, 18), LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                marginStart = dp(6)
            })
        }
        content.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            content.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.rgb(242, 244, 248))
                textSize = 13.3f
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                gravity = Gravity.RIGHT
                setLineSpacing(dp(1).toFloat(), 1f)
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        } else if (media != null) {
            content.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                media.optString("url").takeIf { it.isNotBlank() }?.let { loadPartyImage(it, this) }
            }, LinearLayout.LayoutParams(dp(92), dp(58)))
        }
        bubble.addView(content, LinearLayout.LayoutParams(0, -2, 1f))

        val width = if (isTvLike()) dp(460) else min(dp(340), resources.displayMetrics.widthPixels - dp(28))
        root.addView(bubble, FrameLayout.LayoutParams(width, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(if (isTvLike()) 90 else 58)
        })
        bubble.animate().alpha(1f).translationY(0f).setDuration(170L).withEndAction {
            bubble.postDelayed({
                bubble.animate().alpha(0f).translationY(-dp(8).toFloat()).setDuration(220L).withEndAction {
                    runCatching { root.removeView(bubble) }
                }.start()
            }, 3300L)
        }.start()
    }

    private fun partyVerifiedBadge(admin: Boolean, sizeDp: Int = 18): ImageView {
        return ImageView(this).apply {
            setImageResource(if (admin) R.drawable.ic_admin_verified else R.drawable.ic_vip_verified_green)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            contentDescription = if (admin) "مدیر تأییدشده" else "عضو ویژه تأییدشده"
            setPadding(dp(1), dp(1), dp(1), dp(1))
        }
    }

    private fun partyAvatarView(payload: JSONObject, sizeDp: Int = 38): FrameLayout {
        val username = payload.optString("username").ifBlank { "همراه" }
        val vip = payload.optBoolean("is_vip", false)
        val admin = payload.optBoolean("is_admin", false)
        val avatarUrl = payload.optString("avatar_url").trim()
        val border = when {
            admin -> Color.rgb(29, 155, 240)
            vip -> Color.rgb(36, 196, 103)
            else -> Color.argb(95,255,255,255)
        }
        return FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(27, 43, 53))
                setStroke(dp(1), border)
            }
            clipToOutline = true
            addView(TextView(this@PlayerActivity).apply {
                text = username.take(1).uppercase()
                setTextColor(Color.WHITE)
                textSize = if (sizeDp >= 42) 12f else 10.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(34,122,118), Color.rgb(46,75,143))).apply {
                    shape = GradientDrawable.OVAL
                }
            }, FrameLayout.LayoutParams(-1,-1))
            if (avatarUrl.isNotBlank()) {
                addView(ImageView(this@PlayerActivity).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.TRANSPARENT) }
                    clipToOutline = true
                    loadPartyImage(avatarUrl, this)
                }, FrameLayout.LayoutParams(-1,-1).apply { setMargins(dp(2),dp(2),dp(2),dp(2)) })
            }
            addView(View(this@PlayerActivity).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.rgb(42, 214, 132))
                    setStroke(dp(1), Color.rgb(5,42,35))
                }
            }, FrameLayout.LayoutParams(dp(9),dp(9),Gravity.BOTTOM or Gravity.RIGHT).apply {
                rightMargin = dp(1); bottomMargin = dp(1)
            })
        }
    }

    private fun partyMessageTime(raw: String): String {
        val clean = raw.trim()
        val match = Regex("(?:T|\\s)(\\d{2}):(\\d{2})").find(clean)
        return if (match != null) "${match.groupValues[1]}:${match.groupValues[2]}" else ""
    }

    private fun showWatchPartyChat() {
        if (!partyChatEnabled) {
            Toast.makeText(this, "گفت‌وگوی اتاق غیرفعال است", Toast.LENGTH_SHORT).show()
            return
        }
        partyUnreadChat = 0
        updateChatBadge()
        handler.removeCallbacks(partyChromeHideRunnable)
        lateinit var dialog: AlertDialog

        // V7.45.3 — Side-drawer chat. The composer is permanently pinned to the
        // bottom of the dialog, so SOFT_INPUT_ADJUST_RESIZE keeps the text field
        // directly above the keyboard (Clash-style) instead of hiding it or
        // switching the IME to landscape extract/full-screen mode.
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 0, 0, 0)
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                Color.rgb(5, 22, 42),
                Color.rgb(3, 13, 27)
            )).apply {
                cornerRadius = dp(24).toFloat()
                setStroke(dp(1), Color.argb(150, 41, 173, 255))
            }
        }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable(GradientDrawable.Orientation.RIGHT_LEFT, intArrayOf(
                Color.rgb(7, 42, 76),
                Color.rgb(4, 23, 45)
            )).apply {
                setCornerRadii(floatArrayOf(
                    dp(24).toFloat(), dp(24).toFloat(),
                    dp(24).toFloat(), dp(24).toFloat(),
                    0f, 0f, 0f, 0f
                ))
                setStroke(dp(1), Color.argb(120, 63, 190, 255))
            }
        }

        val chatMark = FrameLayout(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                Color.rgb(26, 219, 235),
                Color.rgb(17, 126, 255)
            )).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(190, 128, 235, 255))
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_party_chat)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        }
        head.addView(chatMark, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginEnd = dp(9) })

        val headText = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        headText.addView(TextView(this).apply {
            text = "گفت‌وگوی خصوصی"
            setTextColor(Color.WHITE)
            textSize = 16.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            includeFontPadding = false
        })
        val memberCount = partyMembers.length().coerceAtLeast(1)
        headText.addView(TextView(this).apply {
            text = "$memberCount عضو آنلاین  •  Watch Party"
            setTextColor(Color.rgb(139, 199, 232))
            textSize = 9.3f
            gravity = Gravity.RIGHT
            includeFontPadding = false
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
        head.addView(headText, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(partyRoundIcon(R.drawable.ic_close_clean, 40) { dialog.dismiss() }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(7) })
        shell.addView(head, LinearLayout.LayoutParams(-1, -2))

        shell.addView(View(this).apply {
            setBackgroundColor(Color.argb(82, 65, 183, 255))
        }, LinearLayout.LayoutParams(-1, dp(1)))

        val emptyHint = TextView(this).apply {
            text = "پیام‌های اتاق اینجا نمایش داده می‌شوند"
            setTextColor(Color.rgb(104, 135, 164))
            textSize = 10f
            gravity = Gravity.CENTER
            includeFontPadding = false
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }
        shell.addView(emptyHint, LinearLayout.LayoutParams(-1, -2))

        partyChatList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), dp(8), dp(11), dp(10))
            minimumHeight = dp(if (isTvLike()) 320 else 180)
            background = ColorDrawable(Color.TRANSPARENT)
        }
        partyChatScroll = ScrollView(this).apply {
            addView(partyChatList)
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
            background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(
                Color.rgb(3, 16, 31),
                Color.rgb(5, 25, 46)
            ))
        }
        shell.addView(partyChatScroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(9), dp(8), dp(9), dp(9))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
                Color.rgb(5, 29, 53),
                Color.rgb(3, 18, 35)
            )).apply {
                setStroke(dp(1), Color.argb(72, 60, 171, 241))
            }
        }

        val inputShell = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(3), dp(8), dp(3))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                Color.rgb(7, 32, 56),
                Color.rgb(6, 25, 47)
            )).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(1), Color.argb(125, 69, 164, 235))
            }
        }

        val input = EditText(this).apply {
            hint = "پیام بنویسید..."
            setHintTextColor(Color.rgb(130, 157, 181))
            setTextColor(Color.WHITE)
            textSize = 13f
            minLines = 1
            maxLines = 2
            setSingleLine(false)
            background = ColorDrawable(Color.TRANSPARENT)
            setPadding(dp(7), dp(3), dp(7), dp(3))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_FLAG_NO_FULLSCREEN or EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_ACTION_SEND
            maxEms = 24
        }

        val sticker = FrameLayout(this).apply {
            background = rounded(Color.argb(95, 13, 55, 88), dp(14), Color.argb(110, 64, 166, 235))
            isClickable = true
            isFocusable = true
            contentDescription = "استیکر و ایموجی"
            applyPlayerFocus(this, 14, 1.07f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_party_emoji)
                setColorFilter(Color.rgb(226, 238, 249))
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
            setOnClickListener { showPartyStickerPicker() }
        }
        inputShell.addView(input, LinearLayout.LayoutParams(0, dp(48), 1f))
        inputShell.addView(sticker, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(5) })

        val send = FrameLayout(this).apply {
            background = partyAccent(999)
            isClickable = true
            isFocusable = true
            elevation = dp(6).toFloat()
            applyPlayerFocus(this, 999, 1.06f, 0f)
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_send_round)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }
        composer.addView(inputShell, LinearLayout.LayoutParams(0, dp(54), 1f))
        composer.addView(send, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(8) })
        shell.addView(composer, LinearLayout.LayoutParams(-1, -2))

        fun submitMessage(): Boolean {
            val value = input.text?.toString()?.trim().orEmpty()
            if (value.isBlank()) return false
            sendPartyMessage(value)
            input.setText("")
            partyChatScroll?.postDelayed({ partyChatScroll?.fullScroll(View.FOCUS_DOWN) }, 80L)
            return true
        }

        send.setOnClickListener { submitMessage() }
        input.setOnEditorActionListener { _, actionId, event ->
            val enterPressed = event?.let {
                it.keyCode == android.view.KeyEvent.KEYCODE_ENTER && it.action == android.view.KeyEvent.ACTION_DOWN
            } == true
            val sendAction = actionId == EditorInfo.IME_ACTION_SEND || enterPressed
            if (sendAction) submitMessage() else false
        }
        input.setOnFocusChangeListener { _, focused ->
            inputShell.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(
                if (focused) Color.rgb(8, 44, 72) else Color.rgb(7, 32, 56),
                Color.rgb(6, 25, 47)
            )).apply {
                cornerRadius = dp(18).toFloat()
                setStroke(dp(if (focused) 2 else 1), if (focused) Color.rgb(42, 204, 245) else Color.argb(125, 69, 164, 235))
            }
            if (focused) partyChatScroll?.postDelayed({ partyChatScroll?.fullScroll(View.FOCUS_DOWN) }, 120L)
        }

        dialog = AlertDialog.Builder(this).setView(shell).create()
        partyChatDialog = dialog
        dialog.setOnDismissListener {
            partyChatDialog = null
            partyChatList = null
            partyChatScroll = null
            enterImmersive()
            showPartyChrome()
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        dialog.window?.clearFlags(WindowManager.LayoutParams.FLAG_ALT_FOCUSABLE_IM)
        dialog.window?.decorView?.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        dialog.window?.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE)
        dialog.window?.setDimAmount(0.14f)

        val w = resources.displayMetrics.widthPixels
        val dialogWidth = when {
            isTvLike() -> (w * 0.40f).toInt()
            w > resources.displayMetrics.heightPixels -> (w * 0.47f).toInt()
            else -> (w * 0.92f).toInt()
        }
        dialog.window?.setLayout(dialogWidth, WindowManager.LayoutParams.MATCH_PARENT)
        dialog.window?.attributes = dialog.window?.attributes?.apply {
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }

        input.requestFocus()
        input.postDelayed({
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            imm?.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            partyChatScroll?.fullScroll(View.FOCUS_DOWN)
        }, 140L)

        partyMessageIdsShown.clear()
        partyLastMessageId = 0L
        pollWatchParty()
    }

    private fun appendPartyMessage(message: JSONObject) {
        val list = partyChatList ?: return
        val mine = message.optBoolean("is_mine", false)
        val username = message.optString("username").ifBlank { "همراه" }
        val admin = message.optBoolean("is_admin", false)
        val vip = message.optBoolean("is_vip", false) && !admin
        val verified = message.optBoolean("is_verified", false)

        // V7.45.4 — Bubble width is derived from the drawer width, not the whole
        // screen. This prevents short/RTL messages, stickers and avatars from
        // overflowing the chat drawer on landscape phones.
        val screenW = resources.displayMetrics.widthPixels
        val drawerWidth = when {
            isTvLike() -> (screenW * 0.40f).toInt()
            screenW > resources.displayMetrics.heightPixels -> (screenW * 0.47f).toInt()
            else -> (screenW * 0.92f).toInt()
        }
        val availableBubbleWidth = (drawerWidth - dp(94)).coerceAtLeast(dp(82))
        val maxBubbleWidth = min(dp(if (isTvLike()) 360 else 300), availableBubbleWidth)
        val minBubbleWidth = min(dp(if (isTvLike()) 150 else 124), (maxBubbleWidth * 0.68f).toInt())

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (mine) Gravity.RIGHT or Gravity.BOTTOM else Gravity.LEFT or Gravity.BOTTOM
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(4), dp(1), dp(4), dp(1))
            clipChildren = false
            clipToPadding = false
        }
        val avatar = partyAvatarView(message, 40)
        val bubble = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            minimumWidth = minBubbleWidth
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(2).toFloat()
            background = if (mine) {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(15, 123, 183), Color.rgb(7, 76, 132))).apply {
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), Color.argb(125, 72, 189, 255))
                }
            } else {
                GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(20, 47, 74), Color.rgb(8, 27, 49))).apply {
                    cornerRadius = dp(18).toFloat()
                    setStroke(dp(1), Color.argb(105, 80, 143, 207))
                }
            }
        }

        val identityRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
        }
        identityRow.addView(TextView(this@PlayerActivity).apply {
            text = if (mine) "شما" else username
            setTextColor(when {
                admin -> Color.rgb(93, 188, 255)
                vip -> Color.rgb(73, 220, 129)
                else -> Color.rgb(219, 235, 250)
            })
            textSize = 11.7f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            maxWidth = maxBubbleWidth - dp(51)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            includeFontPadding = false
        })
        if (admin || vip || verified) {
            identityRow.addView(partyVerifiedBadge(admin || verified, 18), LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                marginStart = dp(7)
            })
        }
        bubble.addView(identityRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(9) })

        val textValue = message.optString("text").ifBlank { message.optString("message") }
        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            bubble.addView(TextView(this).apply {
                text = textValue
                setTextColor(Color.WHITE)
                textSize = 14f
                gravity = Gravity.RIGHT
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                setLineSpacing(dp(2).toFloat(), 1.03f)
                maxWidth = maxBubbleWidth - dp(24)
                setTextIsSelectable(false)
                includeFontPadding = false
            }, LinearLayout.LayoutParams(-2, -2))
        }

        message.optJSONObject("media")?.optString("url")?.takeIf { it.isNotBlank() }?.let { url ->
            val mediaSize = min(dp(if (isTvLike()) 210 else 164), maxBubbleWidth - dp(24))
            bubble.addView(ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                adjustViewBounds = true
                background = rounded(Color.argb(35, 255, 255, 255), dp(13), Color.argb(55, 255, 255, 255))
                clipToOutline = true
                loadPartyImage(url, this)
            }, LinearLayout.LayoutParams(mediaSize, mediaSize).apply {
                gravity = Gravity.RIGHT
                topMargin = dp(7)
            })
        }

        val time = partyMessageTime(message.optString("created_at"))
        if (time.isNotBlank()) {
            bubble.addView(TextView(this).apply {
                text = if (mine && message.optString("delivered_at").isNotBlank()) "$time  ✓✓" else time
                setTextColor(Color.argb(175, 213, 231, 240))
                textSize = 8.5f
                gravity = Gravity.LEFT
                includeFontPadding = false
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        }

        val bubbleLp = LinearLayout.LayoutParams(-2, -2)
        if (mine) {
            bubbleLp.marginEnd = dp(15)
            wrap.addView(bubble, bubbleLp)
            wrap.addView(avatar, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                bottomMargin = dp(2)
            })
        } else {
            wrap.addView(avatar, LinearLayout.LayoutParams(dp(40), dp(40)).apply {
                bottomMargin = dp(2)
            })
            bubbleLp.marginStart = dp(15)
            wrap.addView(bubble, bubbleLp)
        }
        list.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(15) })
        partyChatScroll?.post { partyChatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendPartyMessage(message: String) {
        if (!partyActive || partyRoomCode.isBlank()) return
        val clientId = "android_${UUID.randomUUID().toString().replace("-","").take(40)}"
        AccountApi.watchPartyMessage(this, partyRoomCode, message, clientId) { result ->
            if (!result.success) Toast.makeText(this, result.message.ifBlank { "پیام ارسال نشد" }, Toast.LENGTH_SHORT).show()
            else handler.postDelayed({ pollWatchParty() }, 120L)
        }
    }

    private fun showPartyStickerPicker() {
        AccountApi.commentMediaCatalog(this) { result ->
            val packs=result.json?.optJSONArray("packs") ?: JSONArray()
            if (!result.success || packs.length()==0) {
                Toast.makeText(this,result.message.ifBlank { "استیکرها دریافت نشد" },Toast.LENGTH_SHORT).show()
                return@commentMediaCatalog
            }
            lateinit var dialog: AlertDialog
            val landscape = resources.displayMetrics.widthPixels > resources.displayMetrics.heightPixels
            val shell=LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL
                setPadding(dp(10),dp(10),dp(10),dp(10)); background=partyGlass(26,246,86)
            }
            val header=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;gravity=Gravity.CENTER_VERTICAL }
            header.addView(LinearLayout(this).apply {
                orientation=LinearLayout.VERTICAL;gravity=Gravity.RIGHT
                addView(TextView(this@PlayerActivity).apply { text="استیکر و GIF";setTextColor(Color.WHITE);textSize=17f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT })
                addView(TextView(this@PlayerActivity).apply { text="همان بسته‌های گفت‌وگو و کامنت بانک‌مووی";setTextColor(muted);textSize=9.8f;gravity=Gravity.RIGHT })
            },LinearLayout.LayoutParams(0,-2,1f))
            header.addView(TextView(this).apply { text="×";setTextColor(Color.WHITE);textSize=22f;gravity=Gravity.CENTER;background=partyGlass(999,214,60);setOnClickListener{dialog.dismiss()} },LinearLayout.LayoutParams(dp(42),dp(42)).apply{marginStart=dp(6)})
            shell.addView(header,LinearLayout.LayoutParams(-1,-2).apply{bottomMargin=dp(7)})

            val tabScroll=HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled=false;overScrollMode=View.OVER_SCROLL_NEVER;layoutDirection=View.LAYOUT_DIRECTION_RTL }
            val tabs=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(2),dp(3),dp(2),dp(6)) }
            tabScroll.addView(tabs)
            shell.addView(tabScroll,LinearLayout.LayoutParams(-1,dp(48)))

            val contentScroll=ScrollView(this).apply { isFillViewport=true }
            val grid=GridLayout(this).apply { columnCount=if(isTvLike())5 else if(landscape)4 else 3;alignmentMode=GridLayout.ALIGN_BOUNDS;useDefaultMargins=false }
            contentScroll.addView(grid)
            shell.addView(contentScroll,LinearLayout.LayoutParams(-1,0,1f))

            fun renderPack(pack:JSONObject) {
                grid.removeAllViews()
                val slug=pack.optString("slug").ifBlank { pack.optString("key") }
                val items=pack.optJSONArray("items") ?: JSONArray()
                for(j in 0 until items.length()) {
                    val it=items.optJSONObject(j)?:continue
                    val id=it.optString("id");val url=it.optString("url")
                    if(slug.isBlank()||id.isBlank()||url.isBlank())continue
                    val card=FrameLayout(this).apply {
                        background=partyGlass(16,208,54);isClickable=true;isFocusable=true;applyPlayerFocus(this,16,1.06f,0f)
                        addView(ImageView(this@PlayerActivity).apply { scaleType=ImageView.ScaleType.FIT_CENTER;adjustViewBounds=true;loadPartyImage(url,this) },FrameLayout.LayoutParams(-1,-1).apply{setMargins(dp(5),dp(5),dp(5),dp(5))})
                        setOnClickListener{sendPartyMessage("[bm-sticker:$slug:$id]");dialog.dismiss()}
                    }
                    val spec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    grid.addView(card,GridLayout.LayoutParams(spec,spec).apply { width=dp(if(isTvLike())112 else if(landscape)96 else 102);height=dp(if(isTvLike())94 else if(landscape)78 else 90);setMargins(dp(4),dp(4),dp(4),dp(4)) })
                }
                contentScroll.post{contentScroll.scrollTo(0,0)}
            }

            val tabViews=mutableListOf<TextView>()
            for(i in 0 until packs.length()) {
                val pack=packs.optJSONObject(i)?:continue
                val label=pack.optString("label").ifBlank{pack.optString("name").ifBlank{"بسته ${i+1}"}}
                val tab=TextView(this).apply {
                    text=label;setTextColor(Color.WHITE);textSize=10.5f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER
                    setPadding(dp(12),0,dp(12),0);isClickable=true;isFocusable=true
                    background=if(i==0)partyAccent(999)else partyGlass(999,210,52)
                    setOnClickListener{
                        tabViews.forEach{v->v.background=partyGlass(999,210,52)};background=partyAccent(999);renderPack(pack)
                    }
                }
                tabViews.add(tab);tabs.addView(tab,LinearLayout.LayoutParams(-2,dp(38)).apply{marginStart=dp(4);marginEnd=dp(4)})
            }
            if(packs.length()>0)packs.optJSONObject(0)?.let(::renderPack)
            dialog=AlertDialog.Builder(this).setView(shell).create();dialog.show();dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            val w=if(isTvLike())dp(690) else (resources.displayMetrics.widthPixels*(if(landscape)0.78f else 0.95f)).toInt()
            val h=(resources.displayMetrics.heightPixels*(if(landscape)0.82f else 0.68f)).toInt()
            dialog.window?.setLayout(w,h)
        }
    }

    private fun partyAbsoluteUrl(raw: String): String {
        val clean = raw.trim()
        if (clean.isBlank()) return ""
        if (clean.startsWith("http://", true) || clean.startsWith("https://", true)) return clean
        return AppConfig.BASE_DOMAIN.trimEnd('/') + "/" + clean.trimStart('/')
    }

    private fun loadPartyImage(url: String, target: ImageView) {
        val resolved = partyAbsoluteUrl(url)
        if (resolved.isBlank()) return
        Thread {
            try {
                val conn=(URL(resolved).openConnection() as HttpURLConnection).apply { connectTimeout=8000; readTimeout=10000; useCaches=true; setRequestProperty("User-Agent","BankmovieAndroidNative/2.4-WatchParty") }
                val bytes=conn.inputStream.use { input -> input.readBytes().let { if(it.size>5_000_000) ByteArray(0) else it } }
                conn.disconnect(); if(bytes.isEmpty()) return@Thread
                if(Build.VERSION.SDK_INT>=28) {
                    val drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(bytes)))
                    runOnUiThread { if(!isFinishing){ target.setImageDrawable(drawable); if(drawable is AnimatedImageDrawable) drawable.start() } }
                } else {
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                    runOnUiThread { if(!isFinishing) target.setImageBitmap(bitmap) }
                }
            } catch (_:Throwable) {}
        }.start()
    }

    private fun showPartyReaction(media: JSONObject) {
        val url=media.optString("url"); if(url.isBlank()||!partyActive) return
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; alpha=0f; scaleX=0.75f; scaleY=0.75f; background=partyGlass(24,170,42); loadPartyImage(url,this) }
        root.addView(image,FrameLayout.LayoutParams(dp(150),dp(150),Gravity.CENTER).apply { leftMargin=dp(220) })
        image.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).withEndAction {
            image.postDelayed({ image.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(240L).withEndAction { runCatching { root.removeView(image) } }.start() },2200L)
        }.start()
    }

    private fun showPartyMembers() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = partyGlass(24, 246, 126)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "اعضای اتاق (${partyMembers.length()})"
            setTextColor(Color.WHITE)
            textSize = 17f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(partyRoundIcon(R.drawable.ic_close_clean, 40) { dialog.dismiss() }, LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginStart = dp(8) })
        shell.addView(header)

        fun sectionLabel(label: String) = TextView(this).apply {
            text = label
            setTextColor(Color.rgb(156, 188, 222))
            textSize = 10f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(9), 0, dp(4))
        }
        fun memberCard(m: JSONObject, isHost: Boolean): LinearLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = if (isHost) partySoftAccent(17) else partyGlass(17, 214, 88)
            addView(partyAvatarView(m, 44), LinearLayout.LayoutParams(dp(44), dp(44)).apply { marginStart = dp(10) })
            addView(LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(this@PlayerActivity).apply {
                    text = if (isHost) "${m.optString("username").ifBlank { "میزبان" }}  ♛" else m.optString("username").ifBlank { "همراه" }
                    setTextColor(if (isHost) Color.rgb(255, 203, 84) else Color.rgb(100, 232, 241))
                    textSize = 13f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.RIGHT
                })
                addView(TextView(this@PlayerActivity).apply {
                    text = if (isHost) "میزبان · کنترل پخش" else "آنلاین"
                    setTextColor(Color.rgb(182, 205, 229))
                    textSize = 9.5f
                    gravity = Gravity.RIGHT
                }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
            }, LinearLayout.LayoutParams(0, -2, 1f))
            if (!isHost && partyIsHost && m.optLong("member_id", 0L) > 0L) {
                val targetId = m.optLong("member_id", 0L)
                val targetName = m.optString("username").ifBlank { "همراه" }
                addView(TextView(this@PlayerActivity).apply {
                    text = "اخراج"
                    setTextColor(Color.rgb(255, 155, 169))
                    textSize = 11f
                    typeface = Typeface.DEFAULT_BOLD
                    gravity = Gravity.CENTER
                    setPadding(dp(9), dp(8), dp(9), dp(8))
                    background = partyGlass(14, 220, 60)
                    isClickable = true
                    isFocusable = true
                    applyPlayerFocus(this, 14, 1.06f, 0f)
                    setOnClickListener {
                        AlertDialog.Builder(this@PlayerActivity)
                            .setTitle("اخراج همراه")
                            .setMessage("$targetName از اتاق خارج شود؟")
                            .setNegativeButton("انصراف", null)
                            .setPositiveButton("اخراج") { _, _ ->
                                AccountApi.watchPartyKickMember(this@PlayerActivity, partyRoomCode, targetId) { result ->
                                    if (result.success) {
                                        Toast.makeText(this@PlayerActivity, "همراه اخراج شد و ظرفیت اتاق آزاد شد", Toast.LENGTH_LONG).show()
                                        dialog.dismiss()
                                        pollWatchParty()
                                    } else {
                                        Toast.makeText(this@PlayerActivity, result.message.ifBlank { "اخراج انجام نشد" }, Toast.LENGTH_LONG).show()
                                    }
                                }
                            }.show()
                    }
                }, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(6) })
            }
            addView(TextView(this@PlayerActivity).apply {
                text = "●"
                setTextColor(Color.rgb(67, 229, 126))
                textSize = 12f
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(dp(24), -2))
        }

        val hosts = mutableListOf<JSONObject>()
        val members = mutableListOf<JSONObject>()
        for (i in 0 until partyMembers.length()) {
            val m = partyMembers.optJSONObject(i) ?: continue
            if (m.optString("member_role").equals("host", true)) hosts += m else members += m
        }
        shell.addView(sectionLabel("میزبان (${hosts.size})"))
        if (hosts.isEmpty()) {
            shell.addView(TextView(this).apply {
                text = "در حال دریافت اطلاعات میزبان..."
                setTextColor(muted)
                textSize = 10f
                gravity = Gravity.RIGHT
                background = partyGlass(16, 205, 62)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            })
        } else hosts.forEach { shell.addView(memberCard(it, true), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) }

        shell.addView(sectionLabel("اعضا (${members.size})"))
        if (members.isEmpty()) {
            shell.addView(TextView(this).apply {
                text = "هنوز کسی به اتاق اضافه نشده"
                setTextColor(muted)
                textSize = 10f
                gravity = Gravity.RIGHT
                background = partyGlass(16, 205, 62)
                setPadding(dp(10), dp(12), dp(10), dp(12))
            })
        } else members.forEach { shell.addView(memberCard(it, false), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(6) }) }

        if (partyIsHost && partyKickedMembers.length() > 0) {
            shell.addView(sectionLabel("اخراج‌شده‌ها — امکان ورود دوباره"))
            for (i in 0 until partyKickedMembers.length()) {
                val kicked = partyKickedMembers.optJSONObject(i) ?: continue
                val id = kicked.optLong("member_id", 0L)
                if (id <= 0L) continue
                shell.addView(LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(8), dp(12), dp(8))
                    background = partyGlass(14, 218, 85)
                    addView(TextView(this@PlayerActivity).apply {
                        text = kicked.optString("member_name").ifBlank { "همراه" }
                        setTextColor(Color.WHITE)
                        textSize = 12f
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    addView(TextView(this@PlayerActivity).apply {
                        text = "لغو اخراج"
                        textSize = 11f
                        typeface = Typeface.DEFAULT_BOLD
                        setTextColor(Color.rgb(112, 239, 176))
                        gravity = Gravity.CENTER
                        background = partySoftAccent(14)
                        setPadding(dp(10), dp(8), dp(10), dp(8))
                        isClickable = true
                        isFocusable = true
                        setOnClickListener {
                            AccountApi.watchPartyUndoKickMember(this@PlayerActivity, partyRoomCode, id) { result ->
                                if (result.success) {
                                    Toast.makeText(this@PlayerActivity, "لغو شد؛ همراه می‌تواند دوباره با لینک وارد شود", Toast.LENGTH_LONG).show()
                                    dialog.dismiss()
                                    pollWatchParty()
                                } else {
                                    Toast.makeText(this@PlayerActivity, result.message.ifBlank { "لغو اخراج انجام نشد" }, Toast.LENGTH_LONG).show()
                                }
                            }
                        }
                    }, LinearLayout.LayoutParams(-2, dp(38)).apply { marginStart = dp(7) })
                }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
            }
        }

        shell.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = partyGlass(18, 220, 100)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this, 18, 1.04f, 0f)
            setOnClickListener { dialog.dismiss(); showPartyRoomSheet() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_player_settings)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginStart = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = "مدیریت اتاق"
                setTextColor(Color.WHITE)
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            })
        }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(10) })

        val inviteRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun inviteButton(label: String, click: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(Color.rgb(92, 225, 240))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partySoftAccent(999)
            isClickable = true
            isFocusable = true
            setOnClickListener { click() }
        }
        inviteRow.addView(inviteButton("دعوت") { sharePartyInvite() }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        inviteRow.addView(inviteButton("کپی لینک") { copyPartyInvite(); Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(5) })
        shell.addView(inviteRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.window?.setLayout(if (isTvLike()) dp(520) else (resources.displayMetrics.widthPixels * 0.82f).toInt(), -2)
    }

    private fun copyPartyInvite() {
        val url=partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val cb=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("BankMovie Watch Party",url))
    }

    private fun sharePartyInvite() {
        val url = partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val share = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "BankMovie Watch Party")
            putExtra(Intent.EXTRA_TEXT, "به اتاق خصوصی BankMovie من بیا:\n$url")
        }
        runCatching { startActivity(Intent.createChooser(share, "دعوت به Watch Party")) }
            .onFailure {
                copyPartyInvite()
                Toast.makeText(this, "لینک دعوت کپی شد", Toast.LENGTH_SHORT).show()
            }
    }

    private fun showPartyRoomSheet() {
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            background = partyGlass(26,246,82)
        }
        shell.addView(TextView(this).apply {
            text = "تنظیمات اتاق"
            setTextColor(Color.WHITE)
            textSize = 19f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        })
        shell.addView(TextView(this).apply {
            text = "سینمای خصوصی BankMovie  •  $partyRoomCode"
            setTextColor(muted)
            textSize = 10.5f
            gravity = Gravity.RIGHT
            setPadding(0,dp(5),0,dp(10))
        })

        val scroll = ScrollView(this).apply {
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0,0,dp(2),dp(3))
        }
        fun row(label:String, sub:String, click:()->Unit) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            setPadding(dp(13),dp(10),dp(13),dp(10))
            background = partyGlass(17,212,52)
            isClickable = true
            isFocusable = true
            applyPlayerFocus(this,17,1.035f,0f)
            setOnClickListener { click() }
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(playerSheetMutedColor())
                textSize = 9.6f
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(2) })
        }
        body.addView(row("اعضای اتاق","${partyMembers.length()}/2 نفر در اتاق") { dialog.dismiss(); showPartyMembers() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("تم و پس‌زمینه", if (partyIsHost) "انتخاب تم اتاق" else "فقط میزبان می‌تواند تغییر دهد") { dialog.dismiss(); showPartyThemes() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("کپی لینک دعوت","ارسال لینک واقعی همین اتاق") { copyPartyInvite(); Toast.makeText(this,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("گفت‌وگوی خصوصی","باز کردن چت اتاق") { dialog.dismiss(); showWatchPartyChat() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(row("وضعیت همگام‌سازی", if (partyIsHost) "میزبان · کنترل پخش و تغییر منبع" else "همراه · دریافت زمان و منبع از میزبان") { showPartyChrome() }, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })
        body.addView(TextView(this).apply {
            text = if (partyIsHost) "بستن اتاق و خروج" else "خروج از اتاق"
            setTextColor(Color.rgb(255,138,154))
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyGlass(17,214,58)
            setOnClickListener { dialog.dismiss(); leaveWatchPartyAndFinish() }
        }, LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(3) })
        scroll.addView(body)
        shell.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        dialog = AlertDialog.Builder(this).setView(shell).create()
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val width = if (isTvLike()) dp(560) else (resources.displayMetrics.widthPixels*.86f).toInt()
        val maxHeight = (resources.displayMetrics.heightPixels * if (isTvLike()) .82f else .78f).toInt()
        dialog.window?.setLayout(width, maxHeight)
    }

    private fun showPartyThemes() {
        val themes=listOf(
            "simple" to "ساده", "purple_dream" to "رویای بنفش", "teal_mist" to "مه آبی", "golden" to "طلایی",
            "forest" to "جنگل", "pink_cloud" to "رویای پونی", "interstellar" to "میان ستاره‌ای", "pony" to "پونی", "pizza" to "پیتزا",
            "darkness" to "تاریکی", "romantic_hearts" to "عاشقانه", "galaxy_nova" to "کهکشانی", "starlight" to "ستاره‌ای", "aurora" to "شفق قطبی"
        )
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="تم و پس‌زمینه اتاق"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT; setPadding(0,0,0,dp(8)) })
        val scroll=ScrollView(this); val grid=GridLayout(this).apply { columnCount=3; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
        themes.forEach { (key,label) ->
            val color=partyThemeColor(key)
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(5),dp(5),dp(5)); background=if(key==partyThemeKey) rounded(Color.argb(72,Color.red(blue),Color.green(blue),Color.blue(blue)),16,blue2) else partyGlass(16,205,45); isClickable=partyIsHost; isFocusable=partyIsHost; applyPlayerFocus(this,16,1.05f,0f)
                addView(View(this@PlayerActivity).apply { background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(color,Color.rgb(20,21,26))).apply { cornerRadius=dp(12).toFloat() } },LinearLayout.LayoutParams(-1,dp(55)))
                addView(TextView(this@PlayerActivity).apply { text=label; setTextColor(Color.WHITE); textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,dp(28)))
                setOnClickListener { if(partyIsHost) AccountApi.watchPartyRoomSettings(this@PlayerActivity,partyRoomCode,key){r->if(r.success){partyThemeKey=key;applyPartyTheme(key);dialog.dismiss()}else Toast.makeText(this@PlayerActivity,r.message,Toast.LENGTH_SHORT).show()} }
            }
            grid.addView(card,GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f)).apply { width=dp(if(isTvLike())160 else 105); height=dp(96); setMargins(dp(4),dp(4),dp(4),dp(4)) })
        }
        scroll.addView(grid); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(!partyIsHost) shell.addView(TextView(this).apply { text="انتخاب تم فقط در اختیار میزبان VIP است"; setTextColor(muted); textSize=10f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(6) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(590) else (resources.displayMetrics.widthPixels*0.9f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
    }

    private fun partyThemeColor(key:String):Int=when(key){
        "purple_dream"->Color.rgb(126,53,210); "teal_mist"->Color.rgb(20,150,153); "golden"->Color.rgb(204,146,24); "forest"->Color.rgb(22,116,67);
        "pink_cloud"->Color.rgb(182,72,130); "interstellar"->Color.rgb(60,43,127); "pony"->Color.rgb(178,92,136); "pizza"->Color.rgb(142,74,35); "darkness"->Color.rgb(24,27,34);
        "romantic_hearts"->Color.rgb(171,46,93); "galaxy_nova"->Color.rgb(91,34,130); "starlight"->Color.rgb(38,68,137); "aurora"->Color.rgb(19,135,111);
        else->Color.rgb(45,49,58)
    }

    private fun applyPartyTheme(key:String) {
        val c = if (key == "simple") Color.rgb(20, 190, 232) else partyThemeColor(key)
        val dark = UiPreferences.blend(Color.rgb(4, 18, 35), c, if (key == "simple") 0.10f else 0.18f)
        partyDock?.background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.argb(224, Color.red(dark), Color.green(dark), Color.blue(dark)), Color.argb(238, 3, 15, 29))).apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.argb(130, 48, 185, 255))
        }
        partyStatusChip?.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(218, 5, 52, 72), Color.argb(210, Color.red(c), Color.green(c), Color.blue(c)))).apply {
            cornerRadius = dp(999).toFloat()
            setStroke(dp(1), Color.argb(150, 83, 224, 255))
        }
        partyChatDialog?.window?.decorView?.background = ColorDrawable(Color.TRANSPARENT)
        val chatBase = if (key == "simple") Color.rgb(5, 24, 45) else UiPreferences.blend(Color.rgb(5, 24, 45), c, 0.22f)
        partyChatList?.background = GradientDrawable(GradientDrawable.Orientation.BL_TR, intArrayOf(chatBase, UiPreferences.blend(chatBase, Color.BLACK, 0.24f)))
    }

    private fun leaveWatchPartyAndFinish() {
        if (!partyActive) { finish(); return }
        partyActive=false; handler.removeCallbacks(partyPollRunnable)
        AccountApi.watchPartyLeave(this,partyRoomCode,partyIsHost) { finish() }
        handler.postDelayed({ if(!isFinishing) finish() },700L)
    }

    // PASS 4.3 — WebRTC/voice call removed to keep APK compact and stable.

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER).apply { rightMargin = dp(8) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.045f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(PLAYER_UTILITY_ICON_DP), dp(PLAYER_UTILITY_ICON_DP), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(32), dp(32)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 11.2f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    /** V22: media-only HTTP recovery, controlled by BM ADMIN, never API credentials. */
    private fun allowedHttpMediaFallback(https: String): String? {
        val prefs = getSharedPreferences("bm_smart_cinema", Context.MODE_PRIVATE)
        if (!prefs.getBoolean("v22_http_video_fallback", false) || httpMediaFallbackApplied) return null
        if (partyActive) return null
        val parsed = runCatching { Uri.parse(https) }.getOrNull() ?: return null
        if (!parsed.scheme.equals("https", true) || !parsed.encodedUserInfo.isNullOrBlank()) return null
        val host = parsed.host?.lowercase(Locale.US)?.trim().orEmpty()
        if (host.isEmpty() || host in AppConfig.TRUSTED_HOSTS.map { it.lowercase(Locale.US) }) return null
        // Prevent player HTTP recovery from being used on internal app/API gateways.
        if (host.endsWith(".bankmovie.top") || host == "bankmovie.top") return null
        val activeApiHost = runCatching { Uri.parse(prefs.getString("active_domain", "")).host }.getOrNull()
        if (host.equals(activeApiHost, true)) return null
        val configured = runCatching { JSONArray(prefs.getString("v22_http_video_hosts", "[]")) }.getOrNull() ?: return null
        var approved = false
        for (i in 0 until configured.length()) if (configured.optString(i).equals(host, true) || configured.optString(i) == "*") approved = true
        if (!approved) return null
        // Signed URLs, cookies, secrets or authorization material MUST NEVER cross plain HTTP.
        val sensitive = Regex("(?i)(^|&)(token|api[_-]?key|access[_-]?token|auth|authorization|signature|sig|jwt|session|expires|policy|x-amz-[^=]*|x-goog-[^=]*)=")
        if (sensitive.containsMatchIn(parsed.encodedQuery.orEmpty())) return null
        val path = parsed.path.orEmpty().lowercase(Locale.US)
        val mediaLike = listOf(".mp4", ".mkv", ".m3u8", ".mpd", ".avi", ".webm", ".ts").any { path.endsWith(it) } ||
            path.contains("/stream/") || path.contains("/video/") || path.contains("/play/")
        if (!mediaLike) return null
        return parsed.buildUpon().scheme("http").build().toString()
    }

    /** Called only after all HTTPS VLC retries failed. A failing video URL is
     * NOT proof of TLS failure (could be 403/404/codec/network error). Probe the
     * normal HTTPS certificate chain again, fresh on EVERY playback attempt. */
    private fun httpsHasSslFailure(raw: String): Boolean {
        var target = runCatching { URL(raw) }.getOrNull() ?: return false
        for (attempt in 0 until 4) {
            if (!target.protocol.equals("https", true)) return false
            val conn = (target.openConnection() as? HttpsURLConnection) ?: return false
            try {
                conn.requestMethod = "HEAD"
                conn.instanceFollowRedirects = false  // never downgrade silently
                conn.connectTimeout = 4500
                conn.readTimeout = 4500
                conn.useCaches = false
                // A 403, 404, 405 or 5xx proves TLS DID work; do not downgrade.
                val status = conn.responseCode
                if (status in 300..399) {
                    val location = conn.getHeaderField("Location")?.trim().orEmpty()
                    if (location.isEmpty()) return false
                    target = URL(target, location)
                    continue
                }
                return false
            } catch (failure: Exception) {
                // Never downgrade on timeout, bad codec, forbidden video, DNS
                // failure or a server rejecting HEAD. Only TLS/cert failure.
                return generateSequence(failure as Throwable) { it.cause }
                    .any { it is SSLException || it is CertificateException }
            } finally {
                conn.disconnect()
            }
        }
        return false
    }

    private fun verifySslBeforeMediaHttp(original: String, httpCandidate: String) {
        if (httpMediaSslProbeRunning) return
        httpMediaSslProbeRunning = true
        val generation = ++httpMediaSslProbeGeneration
        Thread({
            val sslBroken = runCatching { httpsHasSslFailure(original) }.getOrDefault(false)
            runOnUiThread {
                if (generation != httpMediaSslProbeGeneration) return@runOnUiThread
                httpMediaSslProbeRunning = false
                if (isFinishing || isDestroyed || videoUrl != original || currentIndex !in tracks.indices) return@runOnUiThread
                if (sslBroken && !httpMediaFallbackApplied && allowedHttpMediaFallback(original) == httpCandidate) {
                    httpMediaFallbackApplied = true
                    playbackRetryCount = 0
                    videoUrl = httpCandidate
                    Toast.makeText(this, "گواهی HTTPS رسانه مشکل دارد؛ تلاش HTTP فقط در پلیر", Toast.LENGTH_LONG).show()
                    handler.postDelayed({ if (!isFinishing && !isDestroyed) launchPlayerSafely(httpCandidate) }, 350L)
                } else {
                    Toast.makeText(this, "HTTPS بررسی شد؛ تغییر به HTTP مجاز نیست. کیفیت یا نسخه دیگری انتخاب کنید", Toast.LENGTH_LONG).show()
                    releasePlayerAsyncForRebuild()
                }
            }
        }, "BM-MediaTLS-Recheck").start()
    }

    private fun schedulePlaybackRetry(url: String, reason: String = "خطا در پخش") {
        if (playbackRetryScheduled || isFinishing || isDestroyed) return
        val clean = url.trim()
        if (clean.isBlank()) return
        if (playbackRetryCount >= maxPlaybackRetries) {
            playbackRetryScheduled = false
            val emergencyMedia = allowedHttpMediaFallback(clean)
            if (emergencyMedia != null) {
                // TLS may recover between retry cycles. Never remember HTTP for
                // the next play/episode/app launch: check a fresh TLS connection.
                verifySslBeforeMediaHttp(clean, emergencyMedia)
                return
            }
            Toast.makeText(this, "این لینک بعد از $maxPlaybackRetries تلاش پخش نشد؛ کیفیت یا نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            releasePlayerAsyncForRebuild()
            return
        }
        playbackRetryCount += 1
        if (playbackRetryCount == 1) hardwareDecoder = false
        val keep = runCatching { player?.time?.coerceAtLeast(0L) ?: 0L }.getOrDefault(0L)
        if (keep > 0L) requestedResumePosition = max(requestedResumePosition, keep)
        playbackRetryScheduled = true
        Toast.makeText(this, "$reason؛ تلاش مجدد ${playbackRetryCount}/$maxPlaybackRetries", Toast.LENGTH_SHORT).show()
        val delayMs = (650L + playbackRetryCount * 250L).coerceAtMost(1700L)
        handler.postDelayed({
            playbackRetryScheduled = false
            if (!isFinishing && !isDestroyed) launchPlayerSafely(clean)
        }, delayMs)
    }

    private fun launchPlayerSafely(url: String) {
        val clean = url.trim()
        if (partyActive && partyReadyConfirmed) partyPlayerStarting = true
        if (clean.isBlank()) {
            Toast.makeText(this, "لینک پخش خالی است", Toast.LENGTH_LONG).show()
            return
        }
        try {
            startPlayer(clean)
        } catch (_: Throwable) {
            if (partyActive) { partyPlayerStarting = false; partyPlayerStable = false }
            releasePlayerAsyncForRebuild()
            schedulePlaybackRetry(clean, "پلیر نتوانست منبع را باز کند")
        }
    }

    private fun irancellSubtitleFontPath(): String? {
        val assetName = BankmovieFonts.assetFileName(subtitleFontMode) ?: return null
        val dir = File(filesDir, "subtitle_fonts")
        val out = File(dir, assetName)
        if (out.isFile && out.length() > 4096L) return out.absolutePath
        return runCatching {
            dir.mkdirs()
            assets.open("fonts/$assetName").use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.takeIf { it.isFile && it.length() > 4096L }?.absolutePath
        }.getOrNull()
    }

    private fun isMeteredOrMobileNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching {
            val network = cm.activeNetwork ?: return@runCatching true
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching true
            cm.isActiveNetworkMetered || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        }.getOrDefault(true)
    }

    private fun stableCacheMs(isAdaptive: Boolean): Int {
        if (!isAdaptive) return if (DeviceProfile.isLowEnd(this)) 2200 else 1700
        return when {
            isMeteredOrMobileNetwork() -> 6500
            DeviceProfile.isLowEnd(this) -> 5200
            else -> 4200
        }
    }

    private fun createMediaSource(lib: Media3Engine, raw: String): Media3Source {
        val value = raw.trim()
        if (value.isBlank()) throw IllegalArgumentException("Empty media source")
        val uri = Uri.parse(value)
        // Media3 has an Android ContentDataSource: it can read SAF document URIs
        // without a native fd workaround, unlike libVLC.
        return when (uri.scheme?.lowercase(Locale.US).orEmpty()) {
            "file" -> Media3Source(lib, uri)
            "" -> if (value.startsWith("/")) Media3Source(lib, value) else Media3Source(lib, uri)
            else -> Media3Source(lib, uri)
        }
    }

    private fun setBufferRingVisible(visible: Boolean) {
        if (!::playbackBufferRing.isInitialized || !::centerControls.isInitialized) return
        playbackBufferRing.visibility = if (visible && !controlsLocked) View.VISIBLE else View.GONE
        if (visible && !controlsLocked && !controlsVisible) {
            centerControls.visibility = View.VISIBLE
            // Only the middle play symbol + arc remain when chrome is auto-hidden.
            centerControls.getChildAt(0)?.visibility = View.INVISIBLE
            centerControls.getChildAt(2)?.visibility = View.INVISIBLE
            playIcon.setImageResource(R.drawable.ic_player_play)
        } else if (!visible) {
            centerControls.getChildAt(0)?.visibility = View.VISIBLE
            centerControls.getChildAt(2)?.visibility = View.VISIBLE
            if (!controlsVisible || controlsLocked) centerControls.visibility = View.GONE
        }
    }

    private fun setPlaybackBuffering(buffering: Boolean) {
        handler.removeCallbacks(showPlaybackBufferRunnable)
        if (!::playbackBufferRing.isInitialized) return
        if (buffering && playbackExpected && !controlsLocked) {
            // Only show the arc after a real Media3 BUFFERING event remains active
            // for at least 180 ms. A fast seek/decoder transition stays unobtrusive.
            handler.postDelayed(showPlaybackBufferRunnable, 180L)
        } else {
            setBufferRingVisible(false)
        }
    }

    private fun startPlayer(url: String) {
        releasePlayerAsyncForRebuild()
        resumeApplied = false
        playbackExpected = true
        tvLastClockPositionMs = -1L
        tvLastClockAdvanceAtMs = System.currentTimeMillis()
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        // Restore the previously stable player buffering. The aggressive TV
        // adaptive/caching patch caused decoder artifacts on some televisions.
        val cacheMs = stableCacheMs(isDash || isHls)
        val subtitleBgColor = UiPreferences.subtitleBackgroundColor(this) and 0xFFFFFF
        val subtitleBgOpacity = UiPreferences.subtitleBackgroundOpacity(this)
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--drop-late-frames",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-color=${subtitleTextColor and 0xFFFFFF}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-color=$subtitleBgColor",
            "--freetype-background-opacity=$subtitleBgOpacity"
        )
        if (subtitleBold) libOptions.add("--freetype-bold")
        irancellSubtitleFontPath()?.let { fontPath ->
            libOptions.add("--freetype-font=$fontPath")
        }
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=rate")
            libOptions.add("--adaptive-use-access")
        }
        val lib = Media3Engine(this, libOptions)
        vlc = lib
        val mp = Media3Player(lib)
        player = mp
        manualSubtitleAttachedPlayer = null
        // Preserve VLC-style boost when switching quality/episode inside the same player activity.
        runCatching { mp.setVolume(currentVlcVolumePercent.coerceIn(0, VOLUME_BOOST_MAX_PERCENT.roundToInt())) }
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                // A retired libVLC session can still deliver queued callbacks.
                // Never let them modify the active player's UI or retry state.
                if (player !== mp || isFinishing || isDestroyed) return@runOnUiThread
                when (event.type) {
                    Media3Player.Event.Buffering -> {
                        // Event comes from STATE_BUFFERING/STATE_READY, not an
                        // artificial progress percentage. No decoder restart loops.
                        setPlaybackBuffering(event.buffering < 99f)
                    }
                    Media3Player.Event.TracksChanged -> {
                        // Media3 discovers tracks asynchronously (especially HLS).
                        // Refresh an already-open picker without closing the UI.
                        refreshOpenTrackSheet?.invoke()
                    }
                    Media3Player.Event.Playing -> {
                        setPlaybackBuffering(false)
                        playbackExpected = true
                        tvLastClockAdvanceAtMs = System.currentTimeMillis()
                        playbackRetryCount = 0
                        playbackRetryScheduled = false
                        bufferingStartedAt = 0L
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        if (partyActive && partyReadyConfirmed) {
                            partyPlayerStarting = false
                            if (!partyPlayerStable) {
                                partyPlayerStable = true
                                handler.removeCallbacks(partyPollRunnable)
                                handler.postDelayed(partyPollRunnable, 700L)
                                handler.postDelayed({ showControls(); showPartyChrome(); enterImmersive() }, 120L)
                            }
                        }
                        if (partyActive && partyReadyConfirmed && partyPlayerStable && partyIsHost && !partyApplyingRemote) {
                            val now = System.currentTimeMillis()
                            if (now - partyLastExplicitPlaySentAt > 900L) {
                                partyLastExplicitPlaySentAt = now
                                handler.postDelayed({
                                    if (partyActive && partyReadyConfirmed && partyPlayerStable && player?.isPlaying == true) {
                                        sendWatchPartyControl("play")
                                    }
                                }, 380L)
                            }
                        }
                        if (pauseAfterLifecycleRestore && !lifecycleFrameAwaitingVideo) {
                            pauseAfterLifecycleRestore = false
                            playbackExpected = false
                            handler.postDelayed({ runCatching { player?.pause() } }, 180L)
                        }
                        applyMode()
                        applySubtitleDelay()
                        handler.postDelayed({ attachManualSubtitle(mp) }, 250L)
                        handler.postDelayed({ applySubtitleVisibility() }, 350L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 500L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 1300L)
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val stored = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            val saved = max(stored, requestedResumePosition)
                            if (saved > 15000L) {
                                fun applyResumeSeek() {
                                    // Ignore stale scheduled resume corrections after manual
                                    // seeking or when the player source has changed.
                                    if (player !== mp || resumeTarget == 0L || resumeGuardUntil == 0L) return
                                    try {
                                        val current = mp.time
                                        if (current < saved - 5000L) mp.time = saved
                                    } catch (_: Throwable) {}
                                }
                                applyResumeSeek()
                                listOf(300L, 800L, 1600L, 3000L, 5000L, 8000L, 11000L).forEach { delayMs ->
                                    handler.postDelayed({ applyResumeSeek() }, delayMs)
                                }
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    Media3Player.Event.Vout -> {
                        // V7.25: Vout only means a video output object exists; on many
                        // devices that Surface is still black for several seconds.
                        // Never reveal it yet. Probe the actual Surface pixels instead.
                        lifecycleFrameVoutSeen = true
                        if (lifecycleFrameAwaitingVideo) startLifecycleFrameReadyProbe()
                    }
                    Media3Player.Event.TimeChanged -> {
                        // Audio/time can advance before the first video frame. Keep the
                        // frozen frame visible until the surface probe confirms pixels.
                        if (lifecycleFrameAwaitingVideo) startLifecycleFrameReadyProbe()
                    }
                    Media3Player.Event.Paused -> {
                        setPlaybackBuffering(false)
                        if (!playbackExpected) playIcon.setImageResource(R.drawable.ic_player_play)
                    }
                    Media3Player.Event.Stopped -> {
                        setPlaybackBuffering(false)
                        playbackExpected = false
                        playIcon.setImageResource(R.drawable.ic_player_play)
                        if (isTvLike() && !partyActive) tvStoppedByRemote = true
                    }
                    Media3Player.Event.EndReached -> {
                        setPlaybackBuffering(false)
                        playbackExpected = false
                        playNext()
                    }
                    Media3Player.Event.EncounteredError -> {
                        setPlaybackBuffering(false)
                        if (partyActive) {
                            partyPlayerStarting = false
                            partyPlayerStable = false
                            handler.removeCallbacks(partyPollRunnable)
                        }
                        schedulePlaybackRetry(videoUrl, "خطا در پخش")
                    }
                }
            }
        }
        val media = createMediaSource(lib, url)
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        if (subtitleBold) media.addOption(":freetype-bold")
        irancellSubtitleFontPath()?.let { media.addOption(":freetype-font=$it") }
        media.addOption(":freetype-color=${subtitleTextColor and 0xFFFFFF}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-color=$subtitleBgColor")
        media.addOption(":freetype-background-opacity=$subtitleBgOpacity")
        val resumePrefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val resumeStableKey = progressKey.ifBlank { "progress_$videoUrl" }
        val resumeBeforePlay = max(
            resumePrefs.getLong(
                resumeStableKey,
                resumePrefs.getLong("progress_$videoUrl", 0L)
            ),
            requestedResumePosition
        )
        resumeTarget = resumeBeforePlay
        resumeGuardUntil = System.currentTimeMillis() + 12000L
        if (resumeBeforePlay > 15000L) {
            media.addOption(":start-time=${resumeBeforePlay / 1000L}")
        }
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=rate")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int, preserveRequestedResume: Boolean = false) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        tvStoppedByRemote = false
        userPausedAtMs = 0L
        tvStallRecoveries = 0
        tvLastRecoveryAtMs = 0L
        nextPromptShownKey = ""
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        if (manualSubtitleSource.isNotBlank() && manualSubtitleSource != tracks[index].url) {
            // Uploaded subtitle belongs to the previous episode, not every
            // episode in the series. Avoid accidentally displaying wrong text.
            manualSubtitleFile = null
            manualSubtitleSource = ""
            manualSubtitleAttachedPlayer = null
        }
        title = tracks[index].title
        httpMediaFallbackApplied = false
        httpMediaSslProbeRunning = false
        httpMediaSslProbeGeneration += 1
        playbackRetryCount = 0
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        val storedResume = UiPreferences.prefs(this).getLong(
            progressKey,
            UiPreferences.prefs(this).getLong("progress_$videoUrl", 0L)
        )
        requestedResumePosition = if (preserveRequestedResume) {
            max(requestedResumePosition, storedResume)
        } else {
            storedResume
        }
        updateLabels()
        refreshTopActions()
        launchPlayerSafely(videoUrl)
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
        rebuildPlayerMetaChips()
    }

    private fun playerMetaChip(label: String, iconRes: Int? = null, onClick: (() -> Unit)? = null): LinearLayout {
        val accent = blue
        val glassTop = UiPreferences.blend(Color.rgb(18, 20, 27), accent, 0.15f)
        val glassBottom = UiPreferences.blend(Color.rgb(8, 10, 16), accent, 0.08f)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(9), 0, dp(9), 0)
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(glassTop, glassBottom)).apply {
                cornerRadius = dp(999).toFloat()
                setStroke(dp(1), Color.argb(118, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
            if (onClick != null) {
                isClickable = true
                isFocusable = true
                applyPlayerFocus(this, 8, 1.035f, 0f)
                setOnClickListener { onClick() }
            }
            if (iconRes != null) {
                addView(ImageView(this@PlayerActivity).apply {
                    setImageResource(iconRes)
                    setColorFilter(Color.WHITE)
                    scaleType = ImageView.ScaleType.CENTER_INSIDE
                }, LinearLayout.LayoutParams(dp(14), dp(14)).apply { marginEnd = dp(5) })
            }
            if (label.isNotBlank()) {
                addView(TextView(this@PlayerActivity).apply {
                    text = label
                    setTextColor(Color.rgb(229, 238, 252))
                    textSize = 9.5f
                    typeface = Typeface.DEFAULT_BOLD
                    includeFontPadding = false
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
            }
        }
    }

    private fun rebuildPlayerMetaChips() {
        if (!::playerMetaRow.isInitialized) return
        playerMetaRow.removeAllViews()
        val current = tracks.getOrNull(currentIndex)
        val quality = current?.quality?.trim()?.takeIf { it.isNotBlank() }
            ?: Regex("(?i)(2160|1440|1080|720|480|360|240)p").find(currentLabel())?.value
            ?: ""
        fun add(view: View) {
            playerMetaRow.addView(view, LinearLayout.LayoutParams(-2, dp(25)).apply { marginEnd = dp(5) })
        }
        if (quality.isNotBlank()) add(playerMetaChip(quality.uppercase(Locale.US)) { showQualitySheet() })
        val hasDub = tracks.any { !isSubtitle(it) && !isAudioOnly(it) }
        if (hasDub) add(playerMetaChip("دوبله", R.drawable.ic_dubbed_mic_green) { showTypeSheet(false) })
        // V7.47.1.5: CC is the single subtitle/audio entry. The separate
        // "زیرنویس" chip duplicated the same action and made the player HUD noisy.
        add(playerMetaChip("CC", R.drawable.ic_player_cc) { showAudioSubtitleSettingsSheet() })
        if (partyActive) {
            val partyChip = ensurePartyStatusChip()
            (partyChip.parent as? ViewGroup)?.removeView(partyChip)
            updatePartyStatusChip()
            playerMetaRow.addView(partyChip, LinearLayout.LayoutParams(-2, dp(25)).apply { marginStart = dp(2) })
        }
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }.trim()
        val normalized = base.lowercase(Locale.US).replace("‌", " ")
        val alreadyHasEpisode = normalized.contains("قسمت ${t.episode}") || normalized.contains("episode ${t.episode}") || normalized.contains("e${t.episode}")
        val alreadyHasSeason = normalized.contains("فصل ${t.season}") || normalized.contains("season ${t.season}") || normalized.contains("s${t.season}")
        val episodeHead = when {
            t.season > 0 && t.episode > 0 && !(alreadyHasSeason || alreadyHasEpisode) -> "فصل ${t.season} • قسمت ${t.episode}"
            t.episode > 0 && !alreadyHasEpisode -> "قسمت ${t.episode}"
            t.season > 0 && !alreadyHasSeason -> "فصل ${t.season}"
            else -> ""
        }
        val standard = streamStandard(t.url)
        return listOf(episodeHead, base, standard).filter { it.isNotBlank() }.distinct().joinToString(" • ")
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerSheetSurface(26, elevated = true)
        }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(playerSheetMutedColor())
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerSheetSurface(26, elevated = true)
        }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerSheetSurface(26, elevated = true)
        }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private data class NativeTrackOption(val id: Int, val name: String)

    // Direct typed calls are essential: R8 renames JVM methods in release builds.
    // Reflecting by VLC-era method-name strings silently returned empty track lists.
    private fun nativeTrackOptions(methodName: String): List<NativeTrackOption> {
        val mp = player ?: return emptyList()
        val tracks = when (methodName) {
            "getAudioTracks" -> mp.getAudioTracks()
            "getSpuTracks" -> mp.getSpuTracks()
            else -> return emptyList()
        }
        return tracks.map { NativeTrackOption(it.id, it.name) }
    }

    private fun currentNativeTrack(methodName: String): Int {
        val mp = player ?: return -1
        return when (methodName) {
            "getAudioTrack" -> mp.getAudioTrack()
            "getSpuTrack" -> mp.getSpuTrack()
            else -> -1
        }
    }

    private fun setNativeTrack(methodName: String, id: Int): Boolean {
        val mp = player ?: return false
        return when (methodName) {
            "setAudioTrack" -> mp.setAudioTrack(id)
            "setSpuTrack" -> mp.setSpuTrack(id)
            else -> false
        }
    }

    private fun applySubtitleVisibility() {
        if (!subtitleEnabled) {
            val current = currentNativeTrack("getSpuTrack")
            if (current >= 0) lastEnabledSpuTrack = current
            setNativeTrack("setSpuTrack", -1)
            return
        }
        val current = currentNativeTrack("getSpuTrack")
        if (current >= 0) return
        val available = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        val target = available.firstOrNull { it.id == lastEnabledSpuTrack } ?: available.firstOrNull()
        if (target != null) setNativeTrack("setSpuTrack", target.id)
    }

    private fun applyPreferredNativeTracks() {
        if (preferredAudioTrackId != Int.MIN_VALUE && preferredAudioTrackId >= 0) {
            setNativeTrack("setAudioTrack", preferredAudioTrackId)
        }
        if (!subtitleEnabled || preferredSubtitleTrackId == -1) {
            setNativeTrack("setSpuTrack", -1)
            return
        }
        if (preferredSubtitleTrackId != Int.MIN_VALUE && preferredSubtitleTrackId >= 0) {
            lastEnabledSpuTrack = preferredSubtitleTrackId
            setNativeTrack("setSpuTrack", preferredSubtitleTrackId)
        }
    }

    private fun showNativeTrackDialog(titleValue: String, audio: Boolean) {
        val options = nativeTrackOptions(if (audio) "getAudioTracks" else "getSpuTracks")
        val current = currentNativeTrack(if (audio) "getAudioTrack" else "getSpuTrack")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = playerSheetSurface(28, elevated = true)
        }
        box.addView(sectionTitle(titleValue))
        var dialog: AlertDialog? = null
        if (!audio) {
            box.addView(sheetButton("خاموش${if (current < 0) "  ✓" else ""}") {
                subtitleEnabled = false
                UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, false).apply()
                applySubtitleVisibility()
                dialog?.dismiss()
                showHud("زیرنویس غیرفعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        options.filter { audio || it.id >= 0 }.forEach { option ->
            box.addView(sheetButton("${option.name}${if (option.id == current) "  ✓" else ""}") {
                if (audio) setNativeTrack("setAudioTrack", option.id)
                else {
                    subtitleEnabled = true
                    lastEnabledSpuTrack = option.id
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    setNativeTrack("setSpuTrack", option.id)
                }
                dialog?.dismiss()
                showHud(if (audio) "ترک صدا تغییر کرد" else "زیرنویس فعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        if (options.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "ترکی برای انتخاب پیدا نشد"
                setTextColor(playerSheetMutedColor())
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = playerSheetSurface(30, elevated = true)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات پخش"
            setTextColor(playerSheetTextColor())
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_settings)
            setColorFilter(UiPreferences.palette(this@PlayerActivity).onPrimary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("صدا و زیرنویس"))
        box.addView(settingButton("صدا، زیرنویس و ظاهر", subtitleStyleLabel(), "انتخاب ترک صدا و زیرنویس، خاموش‌کردن، رنگ، پس‌زمینه، اندازه و فونت") { showAudioSubtitleSettingsSheet() })

        box.addView(settingsMiniLabel("پخش"))
        // A focusable TV settings action is easier to access with a DPAD than
        // the small overlay FIT icon; both call the same resize state machine.
        if (isTvLike()) {
            box.addView(settingButton("حالت تصویر", modeTitles[modeIndex], "متناسب / برش سینمایی / کشیده — هر بار یک حالت") {
                nextMode()
            })
        }
        box.addView(settingButton("سرعت پخش", speedLabel(), "تنظیم از 0.5x تا 2x") { showSpeedSheet() })
        box.addView(settingButton("زمان پرش", "${seekJumpMs / 1000L} ثانیه", "مقدار عقب و جلو رفتن") {
            val values = listOf(5L, 10L, 30L, 60L)
            val currentIndex = values.indexOf(seekJumpMs / 1000L).let { if (it < 0) 1 else it }
            val next = values[(currentIndex + 1) % values.size]
            seekJumpMs = next * 1000L
            UiPreferences.prefs(this).edit().putInt(UiPreferences.KEY_SEEK_SECONDS, next.toInt()).apply()
            showHud("زمان پرش: $next ثانیه")
        })
        box.addView(settingButton("پخش خودکار قسمت بعد", if (autoPlayNext) "روشن" else "خاموش", "پس از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("پخش خودکار: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری", "برای دستگاه‌های ضعیف حالت سخت‌افزاری بهتر است") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("دیکودر: ${if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری"}")
        })
        box.addView(settingButton("تصویر در تصویر", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("تایمر خواب", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("قفل کنترل‌ها", if (controlsLocked) "قفل" else "باز", "قفل‌کردن دکمه‌ها و ژست‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(playerSheetAccentInk())
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = playerSheetSurface(18)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(playerSheetTextColor())
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(playerSheetAccentInk())
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(playerSheetMutedColor())
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerSheetSurface(28, elevated = true)
            elevation = dp(9).toFloat()
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(playerSheetTextColor())
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary)
            thumbTintList = android.content.res.ColorStateList.valueOf(UiPreferences.palette(this@PlayerActivity).primary2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(playerSheetTrackColor())
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(playerSheetMutedColor())
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showAudioSubtitleSettingsSheet() {
        var localEnabled = subtitleEnabled
        var localTextColor = subtitleTextColor
        var localBgMode = subtitleBackgroundMode
        var localFontMode = subtitleFontMode
        var localScale = subtitleScale
        var localPosition = subtitlePositionIndex
        var localDelay = subtitleDelayMs
        var localAudioTrack = currentNativeTrack("getAudioTrack")
        var localSubtitleTrack = currentNativeTrack("getSpuTrack")

        var audioOptions = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
        var subtitleOptions = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
        if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = playerSheetSurface(30, elevated = true)
            elevation = dp(10).toFloat()
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(TextView(this).apply {
            text = "صدا و زیرنویس"
            setTextColor(playerSheetTextColor())
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_audio)
            setColorFilter(UiPreferences.palette(this@PlayerActivity).onPrimary)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = playerGlassAccent(15)
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        fun optionButton(label: String, selected: () -> Boolean, click: () -> Unit): TextView {
            lateinit var view: TextView
            view = TextView(this).apply {
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(13), 0, dp(13), 0)
                maxLines = 2
                setOnClickListener { click() }
                applyPlayerFocus(this, 17, 1.03f, 0f)
            }
            fun refresh() {
                val active = selected()
                view.text = label + if (active) "   ✓" else ""
                view.background = if (active) playerGlassAccent(16) else playerSheetSurface(16)
                view.setTextColor(if (active) UiPreferences.palette(this@PlayerActivity).onPrimary else playerSheetTextColor())
            }
            view.tag = Runnable { refresh() }
            refresh()
            return view
        }

        fun refreshOptions(container: LinearLayout) {
            for (i in 0 until container.childCount) {
                (container.getChildAt(i).tag as? Runnable)?.run()
            }
        }

        box.addView(settingsMiniLabel("ترک صدا"))
        val audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(audioBox)

        box.addView(settingsMiniLabel("زیرنویس"))
        val subtitleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(subtitleBox)

        fun drawTrackRows() {
            val updatedAudio = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
            val updatedSub = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
            // Rebuild only on a real list change: avoid stealing TV focus.
            if (updatedAudio == audioOptions && updatedSub == subtitleOptions &&
                audioBox.childCount > 0 && subtitleBox.childCount > 0) return
            audioOptions = updatedAudio
            subtitleOptions = updatedSub
            if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
            if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1
            audioBox.removeAllViews()
            subtitleBox.removeAllViews()
            if (audioOptions.isEmpty()) {
                audioBox.addView(TextView(this).apply {
                    text = "ترک صدای قابل انتخاب پیدا نشد؛ ممکن است صدا فقط یک ترک داشته باشد"
                    setTextColor(playerSheetMutedColor())
                    textSize = 12.5f
                    gravity = Gravity.RIGHT
                    setPadding(dp(12), dp(13), dp(12), dp(13))
                    background = playerSheetSurface(15)
                })
            } else {
                audioOptions.forEach { option ->
                    val button = optionButton(option.name, { localAudioTrack == option.id }) {
                        if (!option.name.contains("پشتیبانی‌نشده")) {
                            localAudioTrack = option.id
                            refreshOptions(audioBox)
                        } else showHud("کدک این ترک روی دستگاه پشتیبانی نمی‌شود")
                    }
                    audioBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
                }
            }
            subtitleBox.addView(optionButton("خاموش", { !localEnabled || localSubtitleTrack < 0 }) {
                localEnabled = false
                localSubtitleTrack = -1
                refreshOptions(subtitleBox)
            }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            subtitleOptions.forEach { option ->
                val button = optionButton(option.name, { localEnabled && localSubtitleTrack == option.id }) {
                    if (!option.name.contains("پشتیبانی‌نشده")) {
                        localEnabled = true
                        localSubtitleTrack = option.id
                        refreshOptions(subtitleBox)
                    } else showHud("فرمت این زیرنویس روی دستگاه پشتیبانی نمی‌شود")
                }
                subtitleBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            }
            if (subtitleOptions.isEmpty()) {
                subtitleBox.addView(TextView(this).apply {
                    text = "ترک زیرنویس قابل انتخاب پیدا نشد (زیرنویس چسبیده به تصویر، ترک جدا ندارد)"
                    setTextColor(playerSheetMutedColor())
                    textSize = 12.5f
                    gravity = Gravity.RIGHT
                    setPadding(dp(12), dp(13), dp(12), dp(13))
                })
            }
        }
        drawTrackRows()

        // Android SAF picker: works with device file manager and supported TV
        // document providers. The file is copied to app-private cache for VLC.
        box.addView(settingsMiniLabel("زیرنویس از حافظه دستگاه"))
        val manualSubtitleName = manualSubtitleFile?.name ?: "انتخاب فایل SRT / ASS / SSA / VTT"
        val importSubtitle = optionButton("＋  $manualSubtitleName", { manualSubtitleFile != null }) {
            openManualSubtitlePicker()
        }
        // User-supplied SVG upload/tray icon (Android VectorDrawable conversion).
        // The drawable is tinted to the current sheet foreground for light/dark themes.
        ContextCompat.getDrawable(this, R.drawable.ic_upload_subtitle)?.mutate()?.let { icon ->
            icon.setTint(playerSheetTextColor())
            icon.setBounds(0, 0, dp(23), dp(23))
            importSubtitle.setCompoundDrawablesRelative(icon, null, null, null)
            importSubtitle.compoundDrawablePadding = dp(11)
        }
        box.addView(importSubtitle, LinearLayout.LayoutParams(-1, dp(51)).apply { bottomMargin = dp(7) })
        if (manualSubtitleFile != null) {
            box.addView(optionButton("حذف زیرنویس دستی از این پخش", { false }) {
                manualSubtitleFile = null
                manualSubtitleSource = ""
                manualSubtitleAttachedPlayer = null
                restartKeepingTime("زیرنویس دستی حذف شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        box.addView(TextView(this).apply {
            text = "فایل روی دستگاه می‌ماند؛ چیزی روی سرور آپلود نمی‌شود."
            textSize = 11.5f
            setTextColor(playerSheetMutedColor())
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("رنگ متن"))
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, dp(6)) }
        fun refreshColorViews() {
            colorViews.forEachIndexed { i, view ->
                view.text = if (colors[i] == localTextColor) "✓" else ""
                view.background = rounded(colors[i], dp(999), if (colors[i] == localTextColor) blue2 else Color.argb(90, 255, 255, 255))
                view.setTextColor(if (colors[i] == Color.BLACK) Color.WHITE else Color.BLACK)
            }
        }
        colors.forEachIndexed { index, color ->
            val v = TextView(this).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localTextColor = color; refreshColorViews() }
                applyPlayerFocus(this, 999, 1.08f, 0f)
            }
            colorViews.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColorViews()
        box.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("پس‌زمینه زیرنویس"))
        val bgOptions = listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی")
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        fun refreshBgButtons() {
            bgButtons.forEach { (key, view) ->
                val selected = key == localBgMode
                view.background = if (selected) rounded(blue, dp(15), blue2) else playerSheetSurface(15)
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else playerSheetTextColor())
            }
        }
        bgOptions.forEachIndexed { index, pair ->
            val v = TextView(this).apply {
                text = pair.second
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localBgMode = pair.first; refreshBgButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBgButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("فونت زیرنویس"))
        val fontButtons = mutableListOf<Pair<String, TextView>>()
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshFontButtons() {
            fontButtons.forEach { (key, view) ->
                val selected = key == localFontMode
                view.background = if (selected) rounded(blue, dp(16), blue2) else playerSheetSurface(16)
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else playerSheetTextColor())
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val v = TextView(this).apply {
                text = option.faLabel
                textSize = 13f
                typeface = BankmovieFonts.forMode(this@PlayerActivity, option.key, true)
                gravity = Gravity.CENTER
                setOnClickListener { localFontMode = option.key; refreshFontButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            fontButtons += option.key to v
            fontRow.addView(v, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshFontButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(fontRow)
        }, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("جای زیرنویس"))
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        val positionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshPositionButtons() {
            positionButtons.forEach { (index, view) ->
                val selected = index == localPosition
                view.background = if (selected) rounded(blue, dp(16), blue2) else playerSheetSurface(16)
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else playerSheetTextColor())
            }
        }
        subtitlePositions.forEachIndexed { index, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localPosition = index; refreshPositionButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            positionButtons += index to v
            positionRow.addView(v, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshPositionButtons()
        box.addView(positionRow, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("اندازه و هماهنگی"))
        val sizeValue = TextView(this).apply { text = "اندازه متن: $localScale%"; setTextColor(playerSheetTextColor()); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeValue)
        val sizeSeek = SeekBar(this).apply {
            max = 90
            progress = (localScale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(playerSheetTrackColor())
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localScale = 80 + progress; sizeValue.text = "اندازه متن: $localScale%" }
            }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })

        fun delayText(ms: Int) = String.format(Locale.US, "هماهنگی زیرنویس: %+.2f ثانیه", ms / 1000.0)
        val delayValue = TextView(this).apply { text = delayText(localDelay); setTextColor(playerSheetTextColor()); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(delayValue)
        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(playerSheetTrackColor())
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    localDelay = progress * 100 - 10000
                    delayValue.text = delayText(localDelay)
                    previewSubtitleDelay(localDelay)
                }
            }
        })
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(5) })
        // VLC's setSpuDelay accepts microseconds; 10ms steps are real native
        // subtitle timing changes, NOT a seek of the video timeline.
        val fineDelayRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun updateFineDelay(deltaMs: Int) {
            localDelay = (localDelay + deltaMs).coerceIn(-600_000, 600_000)
            delayValue.text = delayText(localDelay)
            delaySeek.progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            previewSubtitleDelay(localDelay)
        }
        listOf(
            "−۰٫۱۰" to -100, "−۰٫۰۱" to -10,
            "+۰٫۰۱" to 10, "+۰٫۱۰" to 100
        ).forEachIndexed { index, (label, delta) ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setTextColor(playerSheetTextColor())
                background = playerSheetSurface(14)
                isClickable = true
                isFocusable = true
                setOnClickListener { updateFineDelay(delta) }
                applyPlayerFocus(this, 16, 1.025f, 0f)
            }
            fineDelayRow.addView(v, LinearLayout.LayoutParams(0, dp(43), 1f).apply {
                if (index > 0) marginStart = dp(5)
            })
        }
        box.addView(fineDelayRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        val resetDelay = optionButton("↺  بازنشانی هماهنگی به صفر", { localDelay == 0 }) { updateFineDelay(-localDelay) }
        box.addView(resetDelay, LinearLayout.LayoutParams(-1, dp(43)).apply { bottomMargin = dp(9) })

        val applyButton = TextView(this).apply {
            text = "اعمال صدا و زیرنویس"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = playerGlassAccent(22)
            applyPlayerFocus(this, 23, 1.035f, 0f)
        }
        box.addView(applyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val dialog = dialogOf(scroll)
        var settingsApplied = false
        dialog.setOnDismissListener {
            if (!settingsApplied) applySubtitleDelay()
            refreshOpenTrackSheet = null
        }
        // Let the system file picker take over without keeping a stale sheet.
        importSubtitle.setOnClickListener { dialog.dismiss(); openManualSubtitlePicker() }
        applyButton.setOnClickListener {
            val styleChanged = localTextColor != subtitleTextColor || localBgMode != subtitleBackgroundMode || localFontMode != subtitleFontMode || localScale != subtitleScale || localPosition != subtitlePositionIndex
            subtitleEnabled = localEnabled
            subtitleTextColor = localTextColor
            subtitleBackgroundMode = localBgMode
            subtitleFontMode = localFontMode
            subtitleScale = localScale
            subtitlePositionIndex = localPosition
            subtitleDelayMs = localDelay
            preferredAudioTrackId = localAudioTrack
            preferredSubtitleTrackId = if (localEnabled) localSubtitleTrack else -1
            UiPreferences.prefs(this).edit()
                .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
                .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
                .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackgroundMode)
                .putString(UiPreferences.KEY_SUB_FONT, subtitleFontMode)
                .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
                .putInt(UiPreferences.KEY_SUB_DELAY, subtitleDelayMs)
                .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePositionIndex)
                .apply()
            settingsApplied = true
            dialog.dismiss()
            if (styleChanged) {
                restartKeepingTime("تنظیمات صدا و زیرنویس اعمال شد")
            } else {
                applyPreferredNativeTracks()
                applySubtitleDelay()
                showHud("صدا و زیرنویس اعمال شد")
            }
        }
        dialog.show()
        refreshOpenTrackSheet = { if (dialog.isShowing) drawTrackRows() }
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        showAudioSubtitleSettingsSheet()
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = playerSheetSurface(26, elevated = true)
        }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String {
        val colorLabel = when (subtitleTextColor) {
            Color.YELLOW -> "زرد"
            Color.BLACK -> "مشکی"
            Color.RED -> "قرمز"
            Color.BLUE -> "آبی"
            Color.GREEN -> "سبز"
            else -> "سفید"
        }
        val bgLabel = when (subtitleBackgroundMode) {
            "black" -> "پس‌زمینه مشکی"
            "white" -> "پس‌زمینه سفید"
            "yellow" -> "پس‌زمینه زرد"
            "red" -> "پس‌زمینه قرمز"
            "blue" -> "پس‌زمینه آبی"
            "pink" -> "پس‌زمینه صورتی"
            else -> "شفاف"
        }
        val fontLabel = BankmovieFonts.label(subtitleFontMode)
        return "$colorLabel • $bgLabel • $fontLabel • $subtitleScale%"
    }

    private fun applySubtitleDelay() {
        previewSubtitleDelay(subtitleDelayMs)
    }

    private fun previewSubtitleDelay(delayMs: Int) {
        // libVLC uses microseconds. 10ms granularity = 0.01 seconds.
        runCatching { player?.setSpuDelay(delayMs.toLong() * 1000L) }
    }

    private fun openManualSubtitlePicker() {
        val request = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            // Do not narrow MIME types: many TV file pickers label .srt/.ass
            // files as application/octet-stream or unknown.
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivityForResult(request, REQ_LOCAL_SUBTITLE)
        } catch (_: android.content.ActivityNotFoundException) {
            // Some Android TV firmwares have no document provider installed.
            Toast.makeText(this, "برنامهٔ مدیریت فایل در این دستگاه پیدا نشد", Toast.LENGTH_LONG).show()
        }
    }

    @Deprecated("Legacy Activity result required by the existing native Activity")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_LOCAL_SUBTITLE || resultCode != Activity.RESULT_OK) return
        val source = data?.data ?: return
        val displayName = runCatching {
            contentResolver.query(source, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull().orEmpty().ifBlank { "subtitle.srt" }
        val ext = displayName.substringAfterLast('.', "srt").lowercase(Locale.US)
        if (ext !in setOf("srt", "ass", "ssa", "vtt", "sub")) {
            Toast.makeText(this, "فایل SRT، ASS، SSA، VTT یا SUB انتخاب کنید", Toast.LENGTH_LONG).show()
            return
        }
        val selectedForUrl = videoUrl
        val selectedIndex = currentIndex
        Thread {
            var staged: File? = null
            try {
                // SAF content URIs cannot be handed directly to VLC on all TVs;
                // copy at most 8 MB into app-private cache, not the database.
                staged = File.createTempFile("bm_local_sub_", ".$ext", cacheDir)
                var count = 0L
                val input = contentResolver.openInputStream(source) ?: error("فایل باز نشد")
                input.use { stream ->
                    staged!!.outputStream().use { output ->
                        val buffer = ByteArray(8192)
                        while (true) {
                            val n = stream.read(buffer)
                            if (n < 0) break
                            count += n
                            if (count > MAX_LOCAL_SUBTITLE_BYTES) error("حجم زیرنویس بیشتر از ۸ مگابایت است")
                            output.write(buffer, 0, n)
                        }
                    }
                }
                if (count == 0L) error("فایل زیرنویس خالی است")
                val finished = staged!!
                runOnUiThread {
                    if (isFinishing || isDestroyed || selectedForUrl != videoUrl || selectedIndex != currentIndex) {
                        finished.delete()
                        return@runOnUiThread
                    }
                    val old = manualSubtitleFile
                    manualSubtitleFile = finished
                    manualSubtitleSource = selectedForUrl
                    manualSubtitleAttachedPlayer = null
                    subtitleEnabled = true
                    preferredSubtitleTrackId = Int.MIN_VALUE
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    old?.delete()
                    if (!attachManualSubtitle(player)) {
                        // VLC may not be fully ready following the document picker.
                        handler.postDelayed({ attachManualSubtitle(player) }, 800L)
                    }
                    showHud("زیرنویس دستی اضافه شد: $displayName")
                }
            } catch (e: Exception) {
                staged?.delete()
                runOnUiThread {
                    if (!isFinishing && !isDestroyed) Toast.makeText(this, e.message ?: "فایل زیرنویس قابل خواندن نیست", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun attachManualSubtitle(candidate: Media3Player?): Boolean {
        val mp = candidate ?: return false
        val file = manualSubtitleFile ?: return false
        if (manualSubtitleSource != videoUrl || !file.exists() || player !== mp) return false
        if (manualSubtitleAttachedPlayer === mp) return true
        val success = try {
            mp.addSlave(SubtitleTrackType.Subtitle, file.absolutePath, true)
        } catch (_: Throwable) { false }
        if (success) {
            manualSubtitleAttachedPlayer = mp
            subtitleEnabled = true
            preferredSubtitleTrackId = Int.MIN_VALUE
            handler.postDelayed({ if (player === mp) applySubtitleDelay() }, 400L)
        } else if (!isFinishing) {
            showHud("Media3 از این نوع فایل زیرنویس پشتیبانی نکرد")
        }
        return success
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        requestedResumePosition = pos
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode(showError: Boolean = true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val width = videoLayout.width.takeIf { it > 0 } ?: root.width.takeIf { it > 0 } ?: 16
                val height = videoLayout.height.takeIf { it > 0 } ?: root.height.takeIf { it > 0 } ?: 9
                val ratio = android.util.Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
                val builder = PictureInPictureParams.Builder()
                    .setAspectRatio(ratio)
                enterPictureInPictureMode(builder.build())
            } catch (_: Throwable) {
                if (showError) Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else if (showError) {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(playerSheetTextColor())
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun ensurePlayerModalDragHandle(view: View): View? {
        if (isTvLike()) return null
        val root = when (view) {
            is LinearLayout -> view
            is ScrollView -> (if (view.childCount > 0) view.getChildAt(0) else null) as? LinearLayout
            else -> null
        } ?: return null
        val first = if (root.childCount > 0) root.getChildAt(0) else null
        if (first?.tag == "bm_player_modal_drag_target") return first
        val modalPalette = UiPreferences.palette(this)
        val target = FrameLayout(this).apply {
            tag = "bm_player_modal_drag_target"
            isClickable = true
            isFocusable = true
            contentDescription = "برای باز و بسته کردن پنجره بکشید"
            addView(View(this@PlayerActivity).apply {
                background = rounded(
                    if (modalPalette.light) Color.rgb(139, 144, 153) else Color.rgb(146, 157, 178),
                    dp(999),
                    if (modalPalette.light) Color.rgb(119, 124, 132) else Color.rgb(92, 102, 120)
                )
            }, FrameLayout.LayoutParams(dp(62), dp(5), Gravity.CENTER))
        }
        root.addView(target, 0, LinearLayout.LayoutParams(-1, dp(34)).apply { bottomMargin = dp(2) })
        return target
    }

    private fun wirePlayerModalDrag(dialog: AlertDialog, handle: View) {
        if (isTvLike()) return
        val target = dialog.window?.decorView ?: return
        var downY = 0f
        var startY = 0f
        var moved = false
        val slop = dp(7).toFloat()
        fun snapTo(value: Float) {
            target.animate().cancel()
            target.animate().translationY(value).alpha(1f).setDuration(260L)
                .setInterpolator(android.view.animation.DecelerateInterpolator(1.7f)).start()
        }
        handle.setOnTouchListener { _, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    startY = target.translationY
                    moved = false
                    target.animate().cancel()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawY - downY
                    if (kotlin.math.abs(delta) > slop) moved = true
                    val maxY = (target.height * 0.72f).coerceAtLeast(dp(120).toFloat())
                    target.translationY = (startY + delta).coerceIn(0f, maxY)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val height = target.height.coerceAtLeast(dp(260)).toFloat()
                    val current = target.translationY
                    val collapsed = height * 0.42f
                    if (!moved && event.actionMasked == MotionEvent.ACTION_UP) {
                        snapTo(if (current > height * 0.18f) 0f else collapsed)
                    } else if (current > height * 0.64f) {
                        target.animate().cancel()
                        target.animate().translationY(height).alpha(0.82f).setDuration(190L).withEndAction {
                            if (dialog.isShowing) dialog.dismiss()
                        }.start()
                    } else if (current > height * 0.20f) {
                        snapTo(collapsed)
                    } else snapTo(0f)
                    true
                }
                else -> false
            }
        }
    }

    private fun dialogOf(view: View): AlertDialog {
        val mobileDragHandle = ensurePlayerModalDragHandle(view)
        return AlertDialog.Builder(this).setView(view).create().also { dialog ->
            dialog.setOnShowListener {
                val win = dialog.window
                win?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win?.setDimAmount(0.62f)
                win?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val sheetPalette = UiPreferences.palette(this@PlayerActivity)
                if (sheetPalette.light) {
                    win?.navigationBarColor = sheetPalette.background
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        win?.decorView?.let { decor ->
                            decor.systemUiVisibility = decor.systemUiVisibility or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                        }
                    }
                } else {
                    win?.navigationBarColor = Color.BLACK
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        win?.decorView?.let { decor ->
                            decor.systemUiVisibility = decor.systemUiVisibility and View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR.inv()
                        }
                    }
                }
                val screenWidth = resources.displayMetrics.widthPixels
                val preferredWidth = if (isTvLike()) min(screenWidth - dp(80), dp(760)) else min(screenWidth - dp(24), dp(620))
                win?.setLayout(preferredWidth, android.view.WindowManager.LayoutParams.WRAP_CONTENT)
                if (!isTvLike()) {
                    win?.let { window ->
                        window.setGravity(Gravity.BOTTOM)
                        val attrs = window.attributes
                        attrs.y = dp(10)
                        window.attributes = attrs
                    }
                }
                val decor = win?.decorView
                decor?.animate()?.cancel()
                if (decor != null) {
                    decor.alpha = 0f
                    decor.scaleX = 0.97f
                    decor.scaleY = 0.97f
                    decor.translationY = dp(10).toFloat()
                    decor.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                if (!isTvLike() && mobileDragHandle != null) {
                    view.post { wirePlayerModalDrag(dialog, mobileDragHandle) }
                }
                applyPlayerFocusTree(view)
                view.postDelayed({
                    fun first(v: View): Boolean {
                        if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                            v.requestFocus()
                            return true
                        }
                        if (v is android.view.ViewGroup) {
                            for (i in 0 until v.childCount) if (first(v.getChildAt(i))) return true
                        }
                        return false
                    }
                    first(view)
                }, 95L)
            }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(playerSheetTextColor())
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = playerSheetSurface(16)
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun isTvHttpStream(): Boolean {
        if (!isTvLike() || partyActive) return false
        val scheme = Uri.parse(videoUrl.trim()).scheme?.lowercase(Locale.US)
        return scheme == "http" || scheme == "https"
    }

    private fun rememberTvResumePosition() {
        val at = runCatching { player?.time ?: lifecyclePosition }.getOrDefault(0L).coerceAtLeast(0L)
        if (at > 0L) requestedResumePosition = max(requestedResumePosition, at)
        savePlaybackProgress(true)
    }

    private fun stopTvStreamWithoutExiting() {
        if (partyGuestPlaybackLocked()) { showGuestPlaybackLockedNotice(); return }
        rememberTvResumePosition()
        tvStoppedByRemote = true
        userPausedAtMs = System.currentTimeMillis()
        playbackExpected = false
        handler.removeCallbacks(progressRunnable)
        // STOP closes the idle VLC socket; PLAY opens a fresh HTTP connection.
        // The Activity, selected track and saved position remain intact.
        releasePlayerAsyncForRebuild()
        playIcon.setImageResource(R.drawable.ic_player_play)
        showControls()
        focusPlayButton()
        showHud("پخش متوقف شد؛ برای ادامه PLAY را بزنید")
    }

    private fun resumeTvStreamIfStale(): Boolean {
        if (!isTvHttpStream() || videoUrl.isBlank()) return false
        val now = System.currentTimeMillis()
        val idle = userPausedAtMs > 0L && now - userPausedAtMs >= TV_STREAM_IDLE_REOPEN_MS
        if (!tvStoppedByRemote && !idle) return false
        rememberTvResumePosition()
        userPausedAtMs = 0L
        tvStoppedByRemote = false
        playbackExpected = true
        tvLastClockPositionMs = -1L
        tvLastClockAdvanceAtMs = now
        showHud("اتصال مجدد به فیلم از همان زمان...")
        launchPlayerSafely(videoUrl)
        return true
    }

    private fun toggle() {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        if (resumeTvStreamIfStale()) { hideBarsLater(); return }
        val p = player ?: return
        if (p.isPlaying) {
            if (isTvHttpStream()) {
                rememberTvResumePosition()
                userPausedAtMs = System.currentTimeMillis()
            }
            playbackExpected = false
            p.pause()
        } else {
            userPausedAtMs = 0L
            tvStoppedByRemote = false
            playbackExpected = true
            tvLastClockAdvanceAtMs = System.currentTimeMillis()
            p.play()
        }
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        if (partyActive && partyIsHost) sendWatchPartyControl(if (p.isPlaying) "play" else "pause")
        hideBarsLater()
    }

    private fun onUserSeek() {
        // Undo both VLC-era resume guards. They used to overwrite an intentional
        // backward seek for up to 11 seconds, making the picture jump back.
        resumeTarget = 0L
        resumeGuardUntil = 0L
        requestedResumePosition = 0L
        tvLastClockPositionMs = -1L
        tvLastClockAdvanceAtMs = System.currentTimeMillis()
    }

    private fun seekBy(delta: Long) {
        if (partyGuestPlaybackLocked()) {
            showGuestPlaybackLockedNotice()
            return
        }
        val p = player ?: return
        val len = p.length
        onUserSeek()
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        if (partyActive && partyIsHost) sendWatchPartyControl("seek")
        updateProgress()
        hideBarsLater()
    }

    private fun nextEpisodeIndex(): Int {
        val current = tracks.getOrNull(currentIndex) ?: return -1
        if (current.episode <= 0 && current.season <= 0) return -1
        val candidates = tracks.withIndex().filter { (_, track) ->
            track.episode > 0 && (
                track.season > current.season ||
                    (track.season == current.season && track.episode > current.episode)
                )
        }
        if (candidates.isEmpty()) return -1
        val targetPair = candidates.minWithOrNull(
            compareBy<IndexedValue<Track>> { it.value.season }
                .thenBy { it.value.episode }
        ) ?: return -1
        val sameEpisode = candidates.filter {
            it.value.season == targetPair.value.season && it.value.episode == targetPair.value.episode
        }
        return (sameEpisode.firstOrNull {
            it.value.quality.equals(current.quality, true) && isSubtitle(it.value) == isSubtitle(current)
        } ?: sameEpisode.firstOrNull {
            isSubtitle(it.value) == isSubtitle(current) && isAudioOnly(it.value) == isAudioOnly(current)
        } ?: sameEpisode.first()).index
    }

    private fun nextEpisodeTitle(index: Int): String {
        val target = tracks.getOrNull(index) ?: return "قسمت بعدی"
        return if (target.season > 0) "فصل ${target.season} • قسمت ${target.episode}" else "قسمت ${target.episode}"
    }

    private fun maybePromptNextEpisode(time: Long, length: Long, atEnd: Boolean = false) {
        if (!autoPlayNext || skipNextOnce || nextPromptDialog != null) return
        if (!atEnd) {
            // Consistent across all countries and series: prompt after 97% watched.
            // Never autoplay without user choice; honor VLC EndReached as fallback.
            if (length < 120_000L || time <= 0L || player?.isPlaying != true) return
            if (time.toDouble() / length.toDouble() < 0.97) return
        }
        val nextIndex = nextEpisodeIndex()
        if (nextIndex < 0) return
        val current = tracks.getOrNull(currentIndex) ?: return
        val key = "${current.season}:${current.episode}:${current.url}"
        if (nextPromptShownKey == key) return
        nextPromptShownKey = key
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        val accent = blue
        val accentSoft = UiPreferences.blend(accent, Color.WHITE, 0.18f)
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(22), dp(20), dp(22), dp(20))
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                UiPreferences.blend(Color.rgb(18, 20, 25), accent, 0.10f),
                Color.rgb(20, 21, 25),
                Color.rgb(13, 15, 20)
            )).apply {
                cornerRadius = dp(26).toFloat()
                setStroke(dp(1), Color.argb(145, Color.red(accent), Color.green(accent), Color.blue(accent)))
            }
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        head.addView(FrameLayout(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(accent)
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(R.drawable.ic_play_fill)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(14) })
        head.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply {
                text = "قسمت بعدی آماده است"
                setTextColor(Color.WHITE)
                textSize = if (isTvLike()) 19f else 17f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            })
            addView(TextView(this@PlayerActivity).apply {
                text = "${nextEpisodeTitle(nextIndex)} پخش شود؟"
                setTextColor(Color.rgb(176, 188, 207))
                textSize = if (isTvLike()) 13.5f else 12.5f
                gravity = Gravity.RIGHT
                setPadding(0, dp(7), 0, 0)
            })
        }, LinearLayout.LayoutParams(0, -2, 1f))
        shell.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(20) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        lateinit var dialog: AlertDialog
        val playNextButton = TextView(this).apply {
            text = "▶  بله، پخش کن"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(accentSoft, accent)).apply {
                cornerRadius = dp(17).toFloat()
            }
            isClickable = true
            isFocusable = true
            setOnClickListener {
                skipNextOnce = false
                dialog.dismiss()
                switchTo(nextIndex)
            }
        }
        val cancelButton = TextView(this).apply {
            text = "لغو"
            setTextColor(Color.rgb(220, 226, 236))
            textSize = 13.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(235, 28, 38, 53), dp(17), Color.argb(78, 255, 255, 255))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                skipNextOnce = true
                dialog.dismiss()
                showHud("در همین قسمت می‌مانیم")
            }
        }
        actions.addView(playNextButton, LinearLayout.LayoutParams(0, dp(56), 1.22f).apply { marginEnd = dp(6) })
        actions.addView(cancelButton, LinearLayout.LayoutParams(0, dp(56), 0.88f).apply { marginStart = dp(6) })
        shell.addView(actions, LinearLayout.LayoutParams(-1, -2))

        dialog = AlertDialog.Builder(this).setView(shell).setCancelable(true).create()
        nextPromptDialog = dialog
        dialog.setOnDismissListener { if (nextPromptDialog === dialog) nextPromptDialog = null }
        dialog.setOnShowListener {
            dialog.window?.let { win ->
                win.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                win.setDimAmount(0.54f)
                val width = if (isTvLike()) dp(540) else min(resources.displayMetrics.widthPixels - dp(28), dp(520))
                win.setLayout(width, WindowManager.LayoutParams.WRAP_CONTENT)
                win.setGravity(Gravity.CENTER)
            }
            playNextButton.requestFocus()
        }
        dialog.show()
    }

    private fun playNext() {
        if (!autoPlayNext || skipNextOnce) {
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        val next = nextEpisodeIndex()
        if (next >= 0 && nextPromptDialog == null) {
            // VLC EndReached is a stronger signal than a duration estimate.
            maybePromptNextEpisode(player?.time ?: 0L, player?.length ?: 0L, atEnd = true)
        }
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        // One atomic resize mode: FIT -> crop without stretching -> fill/stretch.
        // Old Media3 adapter translated all non-null ratios to FILL and then
        // setScale(0) never restored the FIT mode.
        player?.setDisplayMode(modes[modeIndex])
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
        if (::unlockOverlay.isInitialized) {
            unlockOverlay.visibility = if (controlsLocked) View.VISIBLE else View.GONE
        }
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        centerControls.getChildAt(0)?.visibility = View.VISIBLE
        centerControls.getChildAt(2)?.visibility = View.VISIBLE
        if (partyActive) showPartyChrome()
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        if (::playbackBufferRing.isInitialized && playbackBufferRing.visibility == View.VISIBLE) {
            centerControls.visibility = View.VISIBLE
            centerControls.getChildAt(0)?.visibility = View.INVISIBLE
            centerControls.getChildAt(2)?.visibility = View.INVISIBLE
            playIcon.setImageResource(R.drawable.ic_player_play)
        } else {
            centerControls.visibility = View.GONE
        }
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun playerGestureRailSurface(): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                Color.argb(188, 43, 45, 43),
                Color.argb(208, 24, 26, 25)
            )
        ).apply {
            cornerRadius = dp(24).toFloat()
            setStroke(dp(1), Color.argb(82, 255, 255, 255))
        }
    }

    private fun currentGestureVolumePercent(): Float {
        val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val systemVol = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC).coerceIn(0, maxVol)
        return if (systemVol >= maxVol && currentVlcVolumePercent > 100) {
            currentVlcVolumePercent.toFloat().coerceAtMost(VOLUME_BOOST_MAX_PERCENT)
        } else {
            (systemVol.toFloat() / maxVol.toFloat() * 100f).coerceIn(0f, 100f)
        }
    }

    private fun applyVlcAmplification(percent: Int) {
        val safe = percent.coerceIn(0, VOLUME_BOOST_MAX_PERCENT.roundToInt())
        if (currentVlcVolumePercent == safe) return
        currentVlcVolumePercent = safe
        runCatching { player?.setVolume(safe) }
    }

    private fun applyGestureVolumePercent(value: Float) {
        val percent = value.coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
        gestureVolumePercent = percent
        val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        if (percent <= 100f) {
            val targetVol = (percent / 100f * maxVol.toFloat()).roundToInt().coerceIn(0, maxVol)
            if (targetVol != audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)) {
                audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, targetVol, 0)
            }
            applyVlcAmplification(100)
        } else {
            if (audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) != maxVol) {
                audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, maxVol, 0)
            }
            applyVlcAmplification(percent.roundToInt())
        }
    }

    private fun showVolumeGestureHud(percentValue: Float) {
        if (!::volumeGestureHud.isInitialized) return
        if (::brightnessGestureHud.isInitialized && brightnessGestureHud.visibility == View.VISIBLE) {
            handler.removeCallbacks(brightnessGestureHideRunnable)
            brightnessGestureHud.animate().cancel()
            brightnessGestureHud.visibility = View.GONE
            brightnessGestureHud.alpha = 0f
            brightnessGestureHud.translationX = dp(6).toFloat()
        }
        val percent = percentValue.coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
        // Boost-aware scale: 100% is the middle of the bar, 200% is full.
        val trackRatio = (percent / VOLUME_BOOST_MAX_PERCENT).coerceIn(0f, 1f)
        volumeGesturePercent.text = "${percent.roundToInt()}%"
        volumeGestureIcon.alpha = if (percent <= 0.5f) 0.48f else 1f
        volumeGestureLevel.scaleY = trackRatio
        if (volumeGestureHud.visibility != View.VISIBLE) {
            volumeGestureHud.animate().cancel()
            volumeGestureHud.visibility = View.VISIBLE
            volumeGestureHud.alpha = 0f
            volumeGestureHud.translationX = (-dp(6)).toFloat()
            volumeGestureHud.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(95L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
        handler.removeCallbacks(volumeGestureHideRunnable)
        handler.postDelayed(volumeGestureHideRunnable, 900L)
    }

    private fun showBrightnessGestureHud(brightness: Float) {
        if (!::brightnessGestureHud.isInitialized) return
        if (::volumeGestureHud.isInitialized && volumeGestureHud.visibility == View.VISIBLE) {
            handler.removeCallbacks(volumeGestureHideRunnable)
            volumeGestureHud.animate().cancel()
            volumeGestureHud.visibility = View.GONE
            volumeGestureHud.alpha = 0f
            volumeGestureHud.translationX = (-dp(6)).toFloat()
        }
        val ratio = brightness.coerceIn(0.05f, 1f)
        brightnessGesturePercent.text = "${(ratio * 100f).roundToInt()}%"
        brightnessGestureLevel.scaleY = ratio
        if (brightnessGestureHud.visibility != View.VISIBLE) {
            brightnessGestureHud.animate().cancel()
            brightnessGestureHud.visibility = View.VISIBLE
            brightnessGestureHud.alpha = 0f
            brightnessGestureHud.translationX = dp(6).toFloat()
            brightnessGestureHud.animate()
                .alpha(1f)
                .translationX(0f)
                .setDuration(95L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
        handler.removeCallbacks(brightnessGestureHideRunnable)
        handler.postDelayed(brightnessGestureHideRunnable, 900L)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartRawY = e.rawY
                lastGestureRawY = e.rawY
                gestureVolumePercent = currentGestureVolumePercent()
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                if (!partyGuestPlaybackLocked()) handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val totalRawDy = e.rawY - touchStartRawY
                if (gestureMode == 0 && abs(totalRawDy) > abs(dx) && abs(totalRawDy) > dp(14)) {
                    handler.removeCallbacks(longPressRunnable)
                    // Left lane = volume, right lane = brightness. Use raw screen Y
                    // because some landscape device/view combinations report local
                    // coordinates in a transformed direction.
                    gestureMode = if (partyGuestPlaybackLocked()) 2 else if (touchStartX < root.width / 2f) 2 else 1
                    lastGestureRawY = e.rawY
                    return true
                }

                // This is intentionally incremental and explicit:
                // finger moves UP => rawY gets smaller => stepUpPx is POSITIVE.
                // finger moves DOWN => rawY gets larger => stepUpPx is NEGATIVE.
                val stepUpPx = lastGestureRawY - e.rawY
                lastGestureRawY = e.rawY

                if (gestureMode == 1) {
                    val stepRatio = (stepUpPx / root.height) * 1.42f
                    val nextBrightness = (currentBrightness + stepRatio).coerceIn(0.05f, 1f)
                    currentBrightness = nextBrightness
                    if (lastAppliedBrightness < 0f || abs(nextBrightness - lastAppliedBrightness) >= 0.003f) {
                        val lp = window.attributes
                        lp.screenBrightness = nextBrightness
                        window.attributes = lp
                        lastAppliedBrightness = nextBrightness
                    }
                    showBrightnessGestureHud(nextBrightness)
                    return true
                } else if (gestureMode == 2) {
                    // Logical 0–200% VLC-style range. Up always adds, down always subtracts.
                    val stepPercent = (stepUpPx / root.height) * 205f
                    val nextPercent = (gestureVolumePercent + stepPercent).coerceIn(0f, VOLUME_BOOST_MAX_PERCENT)
                    applyGestureVolumePercent(nextPercent)
                    showVolumeGestureHud(nextPercent)
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (partyGuestPlaybackLocked()) {
                        showGuestPlaybackLockedNotice()
                    } else {
                        if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    }
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            val partyHidden = partyActive && partyDock?.visibility != View.VISIBLE
                            if (partyHidden) {
                                showControls()
                                showPartyChrome()
                            } else if (controlsVisible) {
                                hideControls()
                                if (partyActive) showPartyChrome()
                            } else {
                                showControls()
                                if (partyActive) showPartyChrome()
                            }
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val p = player
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
            // If the retained native player has already been released while the app
            // is backgrounded, never overwrite the last valid position with zero.
            val savedTime = (p?.time ?: max(lifecyclePosition, requestedResumePosition)).coerceAtLeast(0L)
            val duration = (p?.length ?: prefs.getLong("${stableKey}_duration", 0L)).coerceAtLeast(0L)
            prefs.edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .putLong("${stableKey}_duration", duration)
                .putLong("progress_${videoUrl}_duration", duration)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val p = player ?: return
        val len = p.length
        var time = p.time
        if (resumeTarget > 15000L && System.currentTimeMillis() < resumeGuardUntil) {
            if (time < resumeTarget - 5000L) {
                try { p.time = resumeTarget } catch (_: Throwable) {}
                time = p.time
            } else {
                resumeTarget = 0L
            }
        }
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        if (len > 0L) maybePromptNextEpisode(time, len)
        watchTvStreamProgress(p, time, len)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun watchTvStreamProgress(current: Media3Player, position: Long, duration: Long) {
        if (!isTvHttpStream() || !playbackExpected || lifecycleRestorePending ||
            playbackRetryScheduled || tvStoppedByRemote || userPausedAtMs > 0L ||
            player !== current || isFinishing || isDestroyed) return
        val now = System.currentTimeMillis()
        if (position > tvLastClockPositionMs + 300L) {
            tvLastClockPositionMs = position
            tvLastClockAdvanceAtMs = now
            // Sustained healthy playback clears the bounded recovery budget.
            if (tvLastRecoveryAtMs > 0L && now - tvLastRecoveryAtMs > 90_000L) tvStallRecoveries = 0
            return
        }
        if (tvLastClockAdvanceAtMs == 0L) tvLastClockAdvanceAtMs = now
        if (duration > 0L && position >= duration - 12_000L) return
        if (now - tvLastClockAdvanceAtMs < TV_STALL_WATCHDOG_MS ||
            now - tvLastRecoveryAtMs < TV_STALL_RETRY_COOLDOWN_MS) return
        if (tvStallRecoveries >= 3) {
            playbackExpected = false
            showHud("اتصال استریم قطع شد؛ یک کیفیت دیگر را امتحان کنید")
            return
        }
        tvStallRecoveries += 1
        tvLastRecoveryAtMs = now
        tvLastClockAdvanceAtMs = now
        rememberTvResumePosition()
        showHud("پخش متوقف شده؛ اتصال دوباره در حال انجام است")
        launchPlayerSafely(videoUrl)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: Media3Player, ratio: String?) { mp.setAspectRatio(ratio) }

    private fun setScale(mp: Media3Player, scale: Float) { mp.setScale(scale) }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        if (partyGuestPlaybackLocked()) {
            val playbackKey = key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PAUSE ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_REWIND ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_NEXT ||
                key == android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS ||
                key == android.view.KeyEvent.KEYCODE_MENU ||
                key == android.view.KeyEvent.KEYCODE_SETTINGS ||
                key == android.view.KeyEvent.KEYCODE_CAPTIONS ||
                key == android.view.KeyEvent.KEYCODE_C
            if (playbackKey) {
                showGuestPlaybackLockedNotice()
                return true
            }
            val focus = currentFocus
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_LEFT || key == android.view.KeyEvent.KEYCODE_DPAD_RIGHT) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
            if ((key == android.view.KeyEvent.KEYCODE_DPAD_CENTER || key == android.view.KeyEvent.KEYCODE_ENTER ||
                    key == android.view.KeyEvent.KEYCODE_NUMPAD_ENTER || key == android.view.KeyEvent.KEYCODE_SPACE) &&
                (focus == null || focus == root || focus == videoLayout || focus == seek || focus == playButtonBox)) {
                showControls()
                showGuestPlaybackLockedNotice()
                return true
            }
        }

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_MEDIA_STOP -> {
                if (isTvLike() && !partyActive) {
                    stopTvStreamWithoutExiting()
                    return true
                }
                if (!partyGuestPlaybackLocked() && player?.isPlaying == true) toggle()
                return true
            }

            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (key == android.view.KeyEvent.KEYCODE_MEDIA_PLAY && resumeTvStreamIfStale()) {
                    showControls()
                    focusPlayButton()
                    return true
                }
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    showSubtitleStyleSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    private fun findLargestVideoSurface(view: View): SurfaceView? {
        var best: SurfaceView? = if (view is SurfaceView) view else null
        var bestArea = if (best != null) best.width.toLong() * best.height.toLong() else -1L
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                val candidate = findLargestVideoSurface(view.getChildAt(i)) ?: continue
                val area = candidate.width.toLong() * candidate.height.toLong()
                if (area > bestArea) {
                    best = candidate
                    bestArea = area
                }
            }
        }
        return best
    }

    private fun captureLifecycleVideoFrame(force: Boolean = false) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !::videoLayout.isInitialized) return
        val now = System.currentTimeMillis()
        if (lifecycleFrameCapturePending) return
        if (!force && lifecycleFrameBitmap != null && now - lifecycleFrameLastCaptureAt < 450L) return
        val surface = findLargestVideoSurface(videoLayout) ?: return
        val sourceW = surface.width
        val sourceH = surface.height
        if (sourceW < 2 || sourceH < 2 || !surface.isShown) return

        // Cap the held frame to ~720p/1280px width. It is visible for only the short
        // surface restoration window and should not cost tens of MB on 4K devices.
        val scale = min(1f, 1280f / sourceW.toFloat())
        val targetW = max(2, (sourceW * scale).roundToInt())
        val targetH = max(2, (sourceH * scale).roundToInt())
        val bitmap = runCatching { Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888) }.getOrNull() ?: return
        val generation = ++lifecycleFrameCaptureGeneration
        lifecycleFrameCapturePending = true
        try {
            PixelCopy.request(surface, bitmap, { result ->
                if (generation == lifecycleFrameCaptureGeneration) lifecycleFrameCapturePending = false
                if (result == PixelCopy.SUCCESS && generation == lifecycleFrameCaptureGeneration) {
                    val previous = lifecycleFrameBitmap
                    lifecycleFrameBitmap = bitmap
                    lifecycleFrameLastCaptureAt = System.currentTimeMillis()
                    if (lifecycleRestorePending || lifecycleFrameAwaitingVideo) {
                        showLifecycleFrameOverlay()
                    }
                    if (previous !== bitmap) runCatching { previous?.recycle() }
                } else {
                    runCatching { bitmap.recycle() }
                }
            }, handler)
        } catch (_: Throwable) {
            lifecycleFrameCapturePending = false
            runCatching { bitmap.recycle() }
        }
    }

    private fun sampledFrameLooksRendered(bitmap: Bitmap): Boolean {
        if (bitmap.width < 2 || bitmap.height < 2) return false
        var samples = 0
        var visible = 0
        var minLuma = 255
        var maxLuma = 0
        val cols = 12
        val rows = 7
        for (gy in 0 until rows) {
            val y = ((gy + 0.5f) * bitmap.height / rows).toInt().coerceIn(0, bitmap.height - 1)
            for (gx in 0 until cols) {
                val x = ((gx + 0.5f) * bitmap.width / cols).toInt().coerceIn(0, bitmap.width - 1)
                val c = bitmap.getPixel(x, y)
                if (Color.alpha(c) < 16) continue
                val luma = (Color.red(c) * 3 + Color.green(c) * 6 + Color.blue(c)) / 10
                samples++
                minLuma = min(minLuma, luma)
                maxLuma = max(maxLuma, luma)
                if (luma >= 10) visible++
            }
        }
        if (samples == 0) return false
        // A newly attached SurfaceView is normally uniform #000000. Real dark movie
        // frames still contain either a few lit pixels or measurable luma variance.
        return visible >= max(3, samples / 14) || (maxLuma >= 14 && maxLuma - minLuma >= 8)
    }

    private fun startLifecycleFrameReadyProbe() {
        if (!lifecycleFrameAwaitingVideo || Build.VERSION.SDK_INT < Build.VERSION_CODES.N) return
        if (lifecycleFrameProbeStartedAt == 0L) {
            lifecycleFrameProbeStartedAt = System.currentTimeMillis()
            lifecycleFrameProbeReadySamples = 0
            lifecycleFrameProbeGeneration += 1
        }
        scheduleLifecycleFrameProbe(lifecycleFrameProbeGeneration)
    }

    private fun scheduleLifecycleFrameProbe(generation: Int, delayMs: Long = PLAYER_FRAME_PROBE_INTERVAL_MS) {
        if (lifecycleFrameProbePending) return
        lifecycleFrameProbePending = true
        handler.postDelayed({
            lifecycleFrameProbePending = false
            if (generation == lifecycleFrameProbeGeneration && lifecycleFrameAwaitingVideo) {
                probeLifecycleVideoSurface(generation)
            }
        }, delayMs)
    }

    private fun probeLifecycleVideoSurface(generation: Int) {
        if (generation != lifecycleFrameProbeGeneration || !lifecycleFrameAwaitingVideo) return
        val elapsed = System.currentTimeMillis() - lifecycleFrameProbeStartedAt
        if (elapsed >= PLAYER_FRAME_PROBE_TIMEOUT_MS) {
            // Safety valve: never pin a stale frame forever if the stream is actually
            // audio-only/broken. Normal HOME restores are confirmed well before this.
            hideLifecycleFrameOverlay()
            return
        }
        val surface = if (::videoLayout.isInitialized) findLargestVideoSurface(videoLayout) else null
        if (surface == null || surface.width < 2 || surface.height < 2 || !surface.isShown) {
            scheduleLifecycleFrameProbe(generation)
            return
        }
        val probe = runCatching { Bitmap.createBitmap(96, 54, Bitmap.Config.ARGB_8888) }.getOrNull() ?: run {
            scheduleLifecycleFrameProbe(generation, 220L)
            return
        }
        try {
            lifecycleFrameProbePending = true
            PixelCopy.request(surface, probe, { result ->
                lifecycleFrameProbePending = false
                if (generation != lifecycleFrameProbeGeneration || !lifecycleFrameAwaitingVideo) {
                    runCatching { probe.recycle() }
                } else {
                    val rendered = result == PixelCopy.SUCCESS && sampledFrameLooksRendered(probe)
                    runCatching { probe.recycle() }
                    lifecycleFrameProbeReadySamples = if (rendered) lifecycleFrameProbeReadySamples + 1 else 0
                    if (lifecycleFrameProbeReadySamples >= 2) {
                        hideLifecycleFrameOverlay()
                    } else {
                        scheduleLifecycleFrameProbe(generation)
                    }
                }
            }, handler)
        } catch (_: Throwable) {
            lifecycleFrameProbePending = false
            runCatching { probe.recycle() }
            scheduleLifecycleFrameProbe(generation, 220L)
        }
    }

    private fun showLifecycleFrameOverlay() {
        val bitmap = lifecycleFrameBitmap ?: return
        if (!::lifecycleFrameOverlay.isInitialized || bitmap.isRecycled) return
        lifecycleFrameOverlay.setImageBitmap(bitmap)
        lifecycleFrameOverlay.alpha = 1f
        lifecycleFrameOverlay.visibility = View.VISIBLE
    }

    private fun hideLifecycleFrameOverlay() {
        if (!lifecycleFrameAwaitingVideo) return
        lifecycleFrameAwaitingVideo = false
        lifecycleFrameVoutSeen = false
        lifecycleFrameProbeGeneration += 1
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        if (::lifecycleFrameOverlay.isInitialized) lifecycleFrameOverlay.visibility = View.GONE
        if (pauseAfterLifecycleRestore) {
            pauseAfterLifecycleRestore = false
            playbackExpected = false
            handler.post { runCatching { player?.pause() } }
        }
    }

    private fun detachRetainedViewsForBackground() {
        if (!lifecycleRestorePending) return
        val current = player ?: return
        if (lifecycleViewsDetached) return
        runCatching {
            current.detachViews()
            lifecycleViewsDetached = true
        }
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        handler.removeCallbacks(releaseRetainedPlayerRunnable)

        // V7.44.9 — Share/chooser round-trips may temporarily remove the dialog on
        // some OEMs. Restore only the UI gate. Never bootstrap/rebuild VLC here.
        if (partyActive && !partyReadyConfirmed && !partyReadyRecreateRequested && partyRoomCode.isNotBlank() && partyLobbyDialog?.isShowing != true) {
            handler.post {
                if (partyActive && !partyReadyConfirmed && !partyReadyRecreateRequested && partyLobbyDialog?.isShowing != true && !isFinishing && !isDestroyed) {
                    showWatchPartyLobby()
                }
            }
        }

        if (!lifecycleRestorePending || videoUrl.isBlank()) return

        lifecycleFrameAwaitingVideo = lifecycleFrameBitmap != null
        lifecycleFrameVoutSeen = false
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        lifecycleFrameProbeGeneration += 1
        if (lifecycleFrameAwaitingVideo) {
            showLifecycleFrameOverlay()
            startLifecycleFrameReadyProbe()
        }

        val target = lifecyclePosition.coerceAtLeast(0L)
        val shouldPlay = lifecycleWasPlaying
        playbackExpected = shouldPlay
        lifecycleRestorePending = false
        requestedResumePosition = max(requestedResumePosition, target)
        val generation = ++lifecycleRestoreGeneration

        // V7.22 PLAYER RETAINED SESSION:
        // Prefer re-attaching the same Media3Engine Media3Player instead of recreating the
        // media/network request after every HOME/app-switch. This preserves decoder
        // state, selected tracks and the current playback position. If Android killed
        // the surface/player or re-attach fails, use the proven rebuild fallback.
        val retained = player
        if (retained != null) {
            val restored = runCatching {
                if (lifecycleViewsDetached) {
                    retained.attachViews(videoLayout, null, false, false)
                    lifecycleViewsDetached = false
                }
                val now = retained.time.coerceAtLeast(0L)
                if (target > 0L && abs(now - target) > 2500L) retained.time = target
                applyMode()
                applySubtitleDelay()
                handler.postDelayed({ applySubtitleVisibility() }, 180L)
                handler.postDelayed({ applyPreferredNativeTracks() }, 320L)
                if (shouldPlay) {
                    pauseAfterLifecycleRestore = false
                    retained.play()
                } else {
                    // A paused VLC surface may not redraw after re-attach. Let one
                    // frame render, then the Playing callback pauses it again.
                    pauseAfterLifecycleRestore = true
                    retained.play()
                }
                handler.removeCallbacks(progressRunnable)
                handler.post(progressRunnable)
                true
            }.getOrDefault(false)
            if (restored) return
        }

        // Fallback for process/surface loss or after PLAYER_BACKGROUND_RETAIN_MS.
        pauseAfterLifecycleRestore = !shouldPlay
        resumeApplied = false
        releasePlayerAsyncForRebuild()
        lifecycleViewsDetached = false
        val delay = if (DeviceProfile.isLowEnd(this)) 220L else 120L
        videoLayout.postDelayed({
            if (isFinishing || isDestroyed || generation != lifecycleRestoreGeneration) return@postDelayed
            launchPlayerSafely(videoUrl)
        }, delay)
    }

    private fun releasePlayer() {
        val oldFd = activeMediaFd
        activeMediaFd = null
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        runCatching { oldFd?.close() }
        player = null
        vlc = null
        lifecycleViewsDetached = false
    }

    private fun releasePlayerAsyncForRebuild() {
        val oldPlayer = player
        val oldVlc = vlc
        val oldFd = activeMediaFd
        player = null
        vlc = null
        activeMediaFd = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { if (oldPlayer?.isPlaying == true) oldPlayer.pause() }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null && oldFd == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
            runCatching { oldFd?.close() }
        }, "BM-VLC-RebuildRelease").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    private fun releasePlayerAsyncForExit() {
        val oldPlayer = player
        val oldVlc = vlc
        val oldFd = activeMediaFd
        player = null
        vlc = null
        activeMediaFd = null
        runCatching { oldPlayer?.setEventListener { _ -> } }
        runCatching { oldPlayer?.detachViews() }
        if (oldPlayer == null && oldVlc == null && oldFd == null) return
        Thread({
            runCatching { oldPlayer?.stop() }
            runCatching { oldPlayer?.release() }
            runCatching { oldVlc?.release() }
            runCatching { oldFd?.close() }
        }, "BM-VLC-Release").apply {
            priority = Thread.MIN_PRIORITY
            start()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus && !isFinishing && !isDestroyed && player != null && videoUrl.isNotBlank()) {
            val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
            if (!inPip) {
                // HOME/app-switch normally drops window focus slightly before onPause;
                // this gives PixelCopy a better chance to capture while SurfaceView
                // still contains the exact visible frame. Dialog focus changes are
                // harmless and simply refresh the same in-memory snapshot.
                captureLifecycleVideoFrame(force = true)
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !isFinishing &&
            player?.isPlaying == true &&
            videoUrl.isNotBlank()
        ) {
            enterPipMode(showError = false)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            handler.removeCallbacks(hideRunnable)
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.GONE
            hudBox.visibility = View.GONE
            setPartyChromeVisible(false)
            controlsVisible = false
        } else if (!controlsLocked) {
            showControls()
        }
    }

    override fun onPause() {
        setPlaybackBuffering(false)
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing) {
            // Capture while the VLC SurfaceView still owns a valid rendered buffer.
            // PixelCopy is asynchronous; onStop gives it a tiny grace period before detach.
            captureLifecycleVideoFrame(force = true)
            val current = player
            lifecyclePosition = (current?.time ?: requestedResumePosition).coerceAtLeast(0L)
            lifecycleWasPlaying = current?.isPlaying == true
            playbackExpected = false
            lifecyclePausedAt = System.currentTimeMillis()
            // Before Watch Party Ready, current == null by design. Do not arm the
            // generic player restore path just because Share/chooser paused Activity.
            lifecycleRestorePending = videoUrl.isNotBlank() && current != null
            if (lifecyclePosition > 0L) requestedResumePosition = max(requestedResumePosition, lifecyclePosition)
            runCatching { current?.pause() }
            // Do NOT detach here. onPause is also used by transient overlays/dialogs.
            // Detach only once the Activity is really stopped/backgrounded.
            if (partyActive && partyIsHost && lifecycleWasPlaying) sendWatchPartyControl("pause")
        }
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onStop() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing && lifecycleRestorePending) {
            if (lifecycleFrameCapturePending && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                handler.postDelayed({ detachRetainedViewsForBackground() }, 110L)
            } else {
                detachRetainedViewsForBackground()
            }
            handler.removeCallbacks(releaseRetainedPlayerRunnable)
            handler.postDelayed(releaseRetainedPlayerRunnable, PLAYER_BACKGROUND_RETAIN_MS)
        }
        super.onStop()
    }

    override fun onDestroy() {
        handler.removeCallbacks(releaseRetainedPlayerRunnable)
        savePlaybackProgress(true)
        nextPromptDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        runCatching { partyLobbyDialog?.dismiss() }
        partyLobbyDialog = null
        runCatching { partyChatDialog?.dismiss() }
        lifecycleFrameCaptureGeneration += 1
        lifecycleFrameCapturePending = false
        lifecycleFrameAwaitingVideo = false
        lifecycleFrameProbeGeneration += 1
        lifecycleFrameProbeStartedAt = 0L
        lifecycleFrameProbeReadySamples = 0
        lifecycleFrameProbePending = false
        runCatching { lifecycleFrameBitmap?.recycle() }
        lifecycleFrameBitmap = null
        // Native VLC shutdown can block for seconds on low-end devices. Never make the
        // main thread wait while the user is leaving the player.
        releasePlayerAsyncForExit()
        manualSubtitleFile?.delete()
        manualSubtitleFile = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
