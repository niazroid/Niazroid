package ir.bankmoviee.app

import android.content.Context
import java.io.File
import java.security.MessageDigest

/** Bound disk cache for compressed original poster bytes, not decoded bitmaps.
 * Reads and writes happen only on the shared image executor (never UI thread).
 *
 * V2.4 polish: the cache now auto-trims by size and age so Android settings no
 * longer show an ever-growing poster cache after long browsing sessions.
 */
internal object PosterDiskCache {
    private const val MAX_BYTES = 48L * 1024L * 1024L
    private const val MAX_FILE = 8L * 1024L * 1024L
    private const val MAX_AGE_MS = 5L * 24L * 60L * 60L * 1000L
    private const val TRIM_EVERY_OPS = 8

    private val lock = Any()
    private var opsSinceTrim = 0

    private fun cacheDir(context: Context): File {
        val dir = File(context.cacheDir, "bm_posters_v2")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun file(context: Context, url: String): File {
        val digest = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        val name = digest.joinToString("") { "%02x".format(it) }
        return File(cacheDir(context), "$name.img")
    }

    private fun trimLocked(context: Context, force: Boolean = false) {
        if (!force) {
            opsSinceTrim++
            if (opsSinceTrim < TRIM_EVERY_OPS) return
        }
        opsSinceTrim = 0
        runCatching {
            val now = System.currentTimeMillis()
            val dir = cacheDir(context)
            val entries = dir.listFiles { f -> f.isFile && f.extension == "img" }
                ?.sortedBy { it.lastModified() }
                .orEmpty()
                .toMutableList()
            if (entries.isEmpty()) return@runCatching

            var used = 0L
            val kept = ArrayList<File>(entries.size)
            for (entry in entries) {
                val len = entry.length()
                val stale = len <= 0L || len > MAX_FILE || now - entry.lastModified() > MAX_AGE_MS
                if (stale) {
                    entry.delete()
                } else {
                    kept += entry
                    used += len
                }
            }

            for (old in kept) {
                if (used <= MAX_BYTES) break
                val len = old.length()
                if (old.delete()) used -= len
            }
        }
    }

    fun read(context: Context, url: String): ByteArray? = synchronized(lock) {
        trimLocked(context)
        runCatching {
            val f = file(context, url)
            if (!f.isFile || f.length() !in 1..MAX_FILE) return@synchronized null
            f.setLastModified(System.currentTimeMillis())
            f.readBytes()
        }.getOrNull()
    }

    fun write(context: Context, url: String, bytes: ByteArray) {
        if (bytes.size.toLong() !in 1..MAX_FILE) return
        synchronized(lock) {
            runCatching {
                val dest = file(context, url)
                val temp = File(dest.parentFile, dest.name + ".tmp")
                temp.writeBytes(bytes)
                if (!temp.renameTo(dest)) {
                    dest.writeBytes(bytes)
                    temp.delete()
                }
            }
            trimLocked(context, force = true)
        }
    }
}
