@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package ir.bankmoviee.app

/**
 * BankMovie's Media3 playback adapter. The existing native player chrome and its
 * screen-reader / remote-control focus tree are deliberately not recreated here.
 *
 * No libVLC native code is linked by this file. Media3 uses device MediaCodec
 * decoders; do not mistake decoder fallback for VLC codec parity.
 */

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.FrameLayout
import androidx.media3.common.C
import androidx.media3.common.text.CueGroup
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.io.File
import kotlin.math.log10

internal class Media3Engine(val context: Context, val options: List<String>) {
    fun release() = Unit // ExoPlayer owns the actual decoder and resources.
}

internal class Media3Source(private val engine: Media3Engine, val uri: Uri) {
    constructor(engine: Media3Engine, path: String) : this(engine, Uri.fromFile(File(path)))

    var startAtMs: Long = 0L
        private set

    val mimeType: String? get() {
        val path = uri.toString().lowercase()
        return when {
            path.startsWith("rtsp:") -> MimeTypes.APPLICATION_RTSP
            path.contains(".m3u8") || path.contains("format=hls") || path.contains("type=hls") -> MimeTypes.APPLICATION_M3U8
            path.contains(".mpd") || path.contains("format=mpd") || path.contains("type=dash") -> MimeTypes.APPLICATION_MPD
            path.contains(".ism/manifest") -> MimeTypes.APPLICATION_SS
            else -> null
        }
    }

    fun addOption(option: String) {
        // Only VLC's start-time option translates to a media-source property.
        // The other VLC-only flags are intentionally *not* advertised as supported.
        if (option.startsWith(":start-time=")) {
            startAtMs = (option.substringAfter('=').toDoubleOrNull()?.times(1000)?.toLong() ?: 0L)
                .coerceAtLeast(0L)
        }
    }

    fun setHWDecoderEnabled(enabled: Boolean, force: Boolean) {
        // Media3's codec selection is provided by Android MediaCodec. There is
        // no bundled software H264/HEVC/AC3 decoder in the lightweight build.
    }

    fun release() = Unit
}

internal enum class SubtitleTrackType { Subtitle }

/** The existing PlayerActivity draws all controls on top of this frame. */
internal class Media3VideoLayout(context: Context) : FrameLayout(context) {
    // Unlike the lightweight mobile path, some Android TVs won't apply the
    // PlayerView/SurfaceView resizeMode visually for 16:9 streams. Adjusting
    // the actual measured video surface container is essential on those TVs.
    private val tvLike: Boolean = run {
        val config = resources.configuration
        val type = config.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        type == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || config.smallestScreenWidthDp >= 600
    }
    private var actualDisplayMode = "FIT"
    val videoView = PlayerView(context).apply {
        useController = false
        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
        // The bridge renders delayed text cues in a separate, styled view.
        subtitleView?.visibility = View.INVISIBLE
    }
    val styledSubtitles = SubtitleView(context).apply {
        setApplyEmbeddedStyles(false)
        setApplyEmbeddedFontSizes(false)
    }

    init {
        setBackgroundColor(Color.BLACK)
        clipChildren = true
        clipToPadding = true
        addView(videoView, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT, android.view.Gravity.CENTER))
        addView(styledSubtitles, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        // Recompute against the real TV viewport after orientation / HDMI resize.
        post { if (width > 0 && height > 0) applyVideoSizing() }
    }

    private fun applyVideoSizing() {
        val containerWidth = width
        val containerHeight = height
        if (containerWidth <= 0 || containerHeight <= 0) return
        val mode = actualDisplayMode
        val resize = when (mode) {
            "CROP" -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            "STRETCH" -> AspectRatioFrameLayout.RESIZE_MODE_FILL
            else -> AspectRatioFrameLayout.RESIZE_MODE_FIT
        }

        // Explicit container bounds force a *real* new SurfaceView measure even
        // on TVs whose decoder optimizes away Media3's resizeMode-only change.
        // FIT never applies scaling; the following overscan is TV-only.
        val widthScale = if (!tvLike) 1f else when (mode) {
            "CROP" -> 1.18f
            "STRETCH" -> 1.14f
            else -> 1f
        }
        val heightScale = if (!tvLike) 1f else when (mode) {
            "CROP" -> 1.18f
            else -> 1f
        }
        val targetWidth = (containerWidth * widthScale).toInt().coerceAtLeast(containerWidth)
        val targetHeight = (containerHeight * heightScale).toInt().coerceAtLeast(containerHeight)
        val params = videoView.layoutParams as? FrameLayout.LayoutParams
        if (params == null || params.width != targetWidth || params.height != targetHeight ||
            params.gravity != android.view.Gravity.CENTER) {
            videoView.layoutParams = FrameLayout.LayoutParams(
                targetWidth, targetHeight, android.view.Gravity.CENTER
            )
        }
        if (videoView.resizeMode != resize) videoView.resizeMode = resize
        videoView.videoSurfaceView?.requestLayout()
        videoView.requestLayout()
        invalidate()
    }

    fun setDisplayMode(mode: String) {
        actualDisplayMode = when (mode) {
            "CROP", "STRETCH" -> mode
            else -> "FIT"
        }
        // A newly created player has not yet been measured.
        if (width > 0 && height > 0) applyVideoSizing()
        else post { applyVideoSizing() }
    }

    fun setResizeMode(mode: Int) = setDisplayMode(when (mode) {
        AspectRatioFrameLayout.RESIZE_MODE_ZOOM -> "CROP"
        AspectRatioFrameLayout.RESIZE_MODE_FILL -> "STRETCH"
        else -> "FIT"
    })
}

internal class Media3Player(private val engine: Media3Engine) {
    internal class Event(val type: Int, val buffering: Float = 0f) {
        companion object {
            const val Buffering = 1
            const val Playing = 2
            const val Vout = 3
            const val TimeChanged = 4
            const val Paused = 5
            const val Stopped = 6
            const val EndReached = 7
            const val EncounteredError = 8
            const val TracksChanged = 9
        }
    }

    // Java reflection in the original settings sheet expects getId()/getName().
    data class TrackDescription(val id: Int, val name: String)

    private val ui = Handler(Looper.getMainLooper())
    private val exo = ExoPlayer.Builder(engine.context)
        .setRenderersFactory(DefaultRenderersFactory(engine.context).setEnableDecoderFallback(true))
        .build()
    private var attachedView: Media3VideoLayout? = null
    // Keep the TV resize choice across decoder readiness and surface reattach.
    private var requestedDisplayMode = "FIT"
    private var eventListener: ((Event) -> Unit)? = null
    private var released = false
    private var stopped = false
    private var lastPosition = -1L
    private var queuedSubtitleEvent = 0L
    private var subtitleDelayMs = 0L
    private var loudness: LoudnessEnhancer? = null
    private var wantedVolume = 100
    private val extraSubs = ArrayList<MediaItem.SubtitleConfiguration>()

    var media: Media3Source? = null
        set(value) {
            field = value
            stopped = false
            if (value != null) {
                extraSubs.clear()
                queuedSubtitleEvent++
                val item = MediaItem.Builder().setUri(value.uri).setMimeType(value.mimeType).build()
                runOnUi {
                    if (released) return@runOnUi
                    exo.setMediaItem(item, value.startAtMs)
                    exo.prepare()
                }
            }
        }

    init {
        exo.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                when (playbackState) {
                    Player.STATE_BUFFERING -> notifyEvent(Event.Buffering, 0f)
                    Player.STATE_READY -> {
                        notifyEvent(Event.Buffering, 100f)
                        setVolume(wantedVolume)
                        applyRequestedDisplayMode()
                    }
                    Player.STATE_ENDED -> notifyEvent(Event.EndReached)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    stopped = false
                    notifyEvent(Event.Playing)
                } else if (!stopped && exo.playbackState != Player.STATE_ENDED && !exo.playWhenReady) {
                    notifyEvent(Event.Paused)
                }
            }

            override fun onRenderedFirstFrame() {
                applyRequestedDisplayMode()
                notifyEvent(Event.Vout)
            }

            override fun onTracksChanged(tracks: Tracks) { notifyEvent(Event.TracksChanged) }

            override fun onPlayerError(error: PlaybackException) {
                notifyEvent(Event.EncounteredError)
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                queuedSubtitleEvent++
                attachedView?.styledSubtitles?.setCues(emptyList())
            }

            override fun onCues(cueGroup: CueGroup) {
                // Positive delay is implemented by postponing cue transitions,
                // including the empty cue that clears subtitles. Negative delay
                // needs an ahead-of-time subtitle parser and is not supported.
                val generation = queuedSubtitleEvent
                val target = cueGroup.cues
                ui.postDelayed({
                    if (!released && generation == queuedSubtitleEvent) {
                        attachedView?.styledSubtitles?.setCues(target)
                    }
                }, subtitleDelayMs.coerceAtLeast(0L))
            }
        })
        ui.post(object : Runnable {
            override fun run() {
                if (released) return
                val position = exo.currentPosition
                if (lastPosition != position) {
                    lastPosition = position
                    notifyEvent(Event.TimeChanged)
                }
                ui.postDelayed(this, 400L)
            }
        })
    }

    private fun runOnUi(action: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) action() else ui.post(action)
    }

    private fun notifyEvent(type: Int, buffering: Float = 0f) {
        if (!released) eventListener?.invoke(Event(type, buffering))
    }

    fun setEventListener(listener: (Event) -> Unit) { eventListener = listener }

    fun attachViews(layout: Media3VideoLayout, unused: Any?, enableSubtitles: Boolean, isTextureView: Boolean) {
        runOnUi {
            if (released) return@runOnUi
            if (attachedView !== layout) attachedView?.videoView?.player = null
            attachedView = layout
            layout.videoView.player = exo
            applyRequestedDisplayMode()
            layout.videoView.post { if (attachedView === layout && !released) applyRequestedDisplayMode() }
            applySubtitleOptions(layout)
        }
    }

    fun detachViews() {
        runOnUi {
            queuedSubtitleEvent++
            attachedView?.videoView?.player = null
            attachedView?.styledSubtitles?.setCues(emptyList())
            attachedView = null
        }
    }

    val isPlaying: Boolean get() = if (released) false else exo.isPlaying
    val length: Long get() = if (released || exo.duration == C.TIME_UNSET) 0L else exo.duration.coerceAtLeast(0L)

    var time: Long
        get() = if (released) 0L else exo.currentPosition.coerceAtLeast(0L)
        set(value) { runOnUi { if (!released) exo.seekTo(value.coerceAtLeast(0L)) } }

    fun play() = runOnUi {
        if (released) return@runOnUi
        stopped = false
        if (exo.playbackState == Player.STATE_IDLE) exo.prepare()
        exo.play()
    }

    fun pause() = runOnUi { if (!released) exo.pause() }
    fun stop() = runOnUi {
        if (released) return@runOnUi
        queuedSubtitleEvent++
        attachedView?.styledSubtitles?.setCues(emptyList())
        stopped = true
        exo.stop()
        notifyEvent(Event.Stopped)
    }

    fun setRate(rate: Float) = runOnUi {
        if (!released) exo.playbackParameters = PlaybackParameters(rate.coerceIn(0.25f, 4f))
    }

    /** VLC-style 0..200% mapped to Media3 volume + Android loudness processing. */
    fun setVolume(value: Int) = runOnUi {
        if (released) return@runOnUi
        val percent = value.coerceIn(0, 200)
        wantedVolume = percent
        exo.volume = (percent.coerceAtMost(100) / 100f)
        runCatching {
            if (percent > 100 && exo.audioSessionId != C.AUDIO_SESSION_ID_UNSET) {
                if (loudness == null) loudness = LoudnessEnhancer(exo.audioSessionId)
                // 200% ~= +6dB; success depends on device audio effects.
                val gainMb = (2000f * log10(percent / 100f)).toInt().coerceIn(0, 700)
                loudness?.setTargetGain(gainMb)
                loudness?.enabled = true
            } else {
                loudness?.enabled = false
            }
        }
    }

    fun setSpuDelay(microseconds: Long) {
        queuedSubtitleEvent++
        subtitleDelayMs = (microseconds / 1000L).coerceAtLeast(0L)
        // ExoPlayer emits cues when they become active, so early (negative)
        // offset cannot work without a separate look-ahead subtitle parser.
    }

    fun setAspectRatio(ratio: String?) {
        setDisplayMode(if (ratio.isNullOrBlank()) "FIT" else "STRETCH")
    }

    fun setScale(scale: Float) {
        setDisplayMode(if (scale > 1.0f) "CROP" else "FIT")
    }

    private fun applyRequestedDisplayMode() {
        attachedView?.setDisplayMode(requestedDisplayMode)
    }

    fun setDisplayMode(mode: String) {
        requestedDisplayMode = when (mode) {
            "CROP", "STRETCH" -> mode
            else -> "FIT"
        }
        runOnUi { if (!released) applyRequestedDisplayMode() }
    }

    private data class IndexedTrack(val id: Int, val group: Tracks.Group, val track: Int)

    private fun availableTracks(type: Int): List<IndexedTrack> {
        if (released) return emptyList()
        val items = ArrayList<IndexedTrack>()
        exo.currentTracks.groups.forEachIndexed { groupIndex, group ->
            if (group.type == type) {
                for (index in 0 until group.length) {
                    // Show discovered streams even if the device decoder cannot
                    // play one of them; do not falsely claim no tracks exist.
                    items.add(IndexedTrack(((groupIndex + 1) shl 16) or index, group, index))
                }
            }
        }
        return items
    }

    private fun localizedLanguage(language: String?): String = when (language?.lowercase()?.substringBefore('-')) {
        "fa", "fas", "per" -> "فارسی"
        "en", "eng" -> "انگلیسی"
        "ar", "ara" -> "عربی"
        "tr", "tur" -> "ترکی"
        "fr", "fra" -> "فرانسوی"
        "de", "deu", "ger" -> "آلمانی"
        "es", "spa" -> "اسپانیایی"
        "hi", "hin" -> "هندی"
        "ko", "kor" -> "کره‌ای"
        "ja", "jpn" -> "ژاپنی"
        "und", "", null -> ""
        else -> language?.uppercase().orEmpty()
    }

    private fun trackDisplayTitle(raw: String?): String {
        val clean = raw.orEmpty()
            .replace(Regex("(?i)^\\s*Film2Media\\s*[-:]\\s*"), "")
            .trim()
        if (clean.isBlank() || clean.matches(Regex("(?i)(application|audio|video|text)/[-+\\w.]+")) ||
            clean.matches(Regex("(?i)(mp4a|avc1|hev1|hvc1|ac-3|ec-3)[.\\w-]*"))) return ""
        return when (clean.lowercase()) {
            "namava" -> "نماوا"
            "filimo" -> "فیلیمو"
            "soren" -> "سورن"
            "gapfilm" -> "گپ‌فیلم"
            "sheyda" -> "شیدا"
            else -> clean
        }
    }

    private fun getTracks(type: Int): Array<TrackDescription> {
        val tracks = availableTracks(type)
        val labels = tracks.mapIndexed { index, item ->
            val format = item.group.getTrackFormat(item.track)
            val origin = trackDisplayTitle(format.label)
            val language = localizedLanguage(format.language)
            listOf(origin, language).filter { it.isNotBlank() }.distinct().joinToString(" • ").ifBlank {
                (if (type == C.TRACK_TYPE_AUDIO) "صدای" else "زیرنویس") + " ${index + 1}"
            }
        }
        return tracks.mapIndexed { index, item ->
            val duplicate = labels.count { it == labels[index] } > 1
            val label = if (duplicate) "${labels[index]} (${index + 1})" else labels[index]
            TrackDescription(item.id, label + if (!item.group.isTrackSupported(item.track, true)) " • پشتیبانی‌نشده" else "")
        }.toTypedArray()
    }

    fun getAudioTracks() = getTracks(C.TRACK_TYPE_AUDIO)
    fun getSpuTracks() = getTracks(C.TRACK_TYPE_TEXT)

    private fun selectedId(type: Int): Int = availableTracks(type)
        .firstOrNull { it.group.isTrackSelected(it.track) }?.id ?: -1

    fun getAudioTrack(): Int = selectedId(C.TRACK_TYPE_AUDIO)
    fun getSpuTrack(): Int = selectedId(C.TRACK_TYPE_TEXT)

    private fun setSelectedTrack(type: Int, id: Int): Boolean {
        if (released) return false
        val match = availableTracks(type).firstOrNull { it.id == id }
        if (id >= 0 && (match == null || !match.group.isTrackSupported(match.track, true))) return false
        val params = exo.trackSelectionParameters.buildUpon()
        if (id == -1 && type == C.TRACK_TYPE_TEXT) {
            params.setTrackTypeDisabled(type, true)
        } else if (match != null) {
            params.setTrackTypeDisabled(type, false)
            params.setOverrideForType(TrackSelectionOverride(match.group.mediaTrackGroup, listOf(match.track)))
        } else return false
        runOnUi { if (!released) exo.trackSelectionParameters = params.build() }
        return true
    }

    fun setAudioTrack(id: Int): Boolean = setSelectedTrack(C.TRACK_TYPE_AUDIO, id)
    fun setSpuTrack(id: Int): Boolean = setSelectedTrack(C.TRACK_TYPE_TEXT, id)

    /** Adds external SRT, ASS/SSA or WebVTT, preserving playback position. */
    fun addSlave(type: SubtitleTrackType, path: String, select: Boolean): Boolean {
        val file = File(path)
        if (type != SubtitleTrackType.Subtitle || !file.isFile || released) return false
        val mime = when (file.extension.lowercase()) {
            "srt" -> MimeTypes.APPLICATION_SUBRIP
            "ass", "ssa" -> MimeTypes.TEXT_SSA
            "vtt" -> MimeTypes.TEXT_VTT
            // No verified Media3 parser for MicroDVD/SubViewer .sub.
            else -> return false
        }
        extraSubs.add(
            MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(file))
                .setMimeType(mime)
                .setLanguage("fa")
                .setSelectionFlags(if (select) C.SELECTION_FLAG_DEFAULT else 0)
                .build()
        )
        runOnUi {
            if (released) return@runOnUi
            val item = exo.currentMediaItem ?: return@runOnUi
            val wasPlaying = exo.playWhenReady
            val position = exo.currentPosition.coerceAtLeast(0L)
            queuedSubtitleEvent++
            exo.setMediaItem(item.buildUpon().setSubtitleConfigurations(extraSubs.toList()).build(), position)
            exo.prepare()
            exo.playWhenReady = wasPlaying
            if (select) exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build()
        }
        return true
    }

    private fun applySubtitleOptions(layout: Media3VideoLayout) {
        val opts = engine.options
        fun option(prefix: String): String? = opts.lastOrNull { it.startsWith(prefix) }?.substringAfter('=')
        val color = option("--freetype-color=")?.toIntOrNull()?.let { 0xFF000000.toInt() or it }
            ?: Color.WHITE
        val scale = option("--sub-text-scale=")?.toIntOrNull() ?: 100
        val margin = option("--sub-margin=")?.toIntOrNull() ?: 70
        val bg = option("--freetype-background-color=")?.toIntOrNull() ?: 0
        val bgOpacity = (option("--freetype-background-opacity=")?.toIntOrNull() ?: 0).coerceIn(0, 255)
        val backgroundColor = Color.argb(bgOpacity, bg shr 16 and 0xff, bg shr 8 and 0xff, bg and 0xff)
        val fontFile = option("--freetype-font=")?.let { File(it) }
        val typeface = runCatching {
            if (fontFile != null && fontFile.isFile) Typeface.createFromFile(fontFile)
            else if (opts.contains("--freetype-bold")) Typeface.DEFAULT_BOLD
            else Typeface.DEFAULT
        }.getOrDefault(Typeface.DEFAULT)
        layout.styledSubtitles.setStyle(CaptionStyleCompat(color, backgroundColor, Color.TRANSPARENT,
            CaptionStyleCompat.EDGE_TYPE_OUTLINE, Color.BLACK, typeface))
        layout.styledSubtitles.setFractionalTextSize((0.055f * scale / 100f).coerceIn(0.025f, 0.13f))
        // Original margins: 70 bottom / 205 middle / 350 top.
        layout.styledSubtitles.setBottomPaddingFraction(when {
            margin >= 300 -> 0.72f
            margin >= 180 -> 0.42f
            else -> 0.075f
        })
    }

    fun release() {
        runOnUi {
            if (released) return@runOnUi
            released = true
            eventListener = null
            queuedSubtitleEvent++
            attachedView?.videoView?.player = null
            attachedView?.styledSubtitles?.setCues(emptyList())
            attachedView = null
            runCatching { loudness?.release() }
            loudness = null
            exo.release()
        }
    }
}
