package ir.bankmoviee.app

import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.net.ConnectivityManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.TimeZone

/** Persistent, bounded diagnostic ring buffer; never stores request bodies or credentials. */
object BmDiagnostics {
    private const val PREFS = "bm_app_diagnostics_25"
    private const val KEY = "recent_errors"
    private const val LIMIT = 45
    private const val DEST = "https://bankmovie.top/v2/api/diagnostics.php"
    private val guard = Any()

    private fun safe(raw: String, max: Int = 700): String {
        var text = raw.take(7000)
        text = text.replace(Regex("(?i)(Bearer\\s+)[a-z0-9._~+/-]+"), "$1[REDACTED]")
        text = text.replace(Regex("(?i)((?:access[_-]?token|authorization|password|secret|proof|private[_-]?key|api[_-]?key)\\s*[:=]\\s*)[^\\s,;\\\"}]+"), "$1[REDACTED]")
        text = text.replace(Regex("(?i)(https?://[^\\s?]+)\\?[^\\s]+"), "$1?[QUERY_REDACTED]")
        return text.take(max)
    }

    private fun endpoint(raw: String): String = try {
        val url = URL(raw)
        "${url.protocol}://${url.host}${url.path}".take(180)
    } catch (_: Throwable) { safe(raw, 180) }

    fun record(
        context: Context, stage: String, url: String = "", httpStatus: Int = 0,
        errorCode: String = "", message: String = "", error: Throwable? = null,
        durationMs: Long = 0, requestId: String = "", retryAfter: String = ""
    ) {
        try {
            val item = JSONObject().apply {
                put("time", System.currentTimeMillis().toString())
                put("stage", safe(stage, 80))
                put("endpoint", endpoint(url))
                if (httpStatus > 0) put("http_status", httpStatus.toString())
                put("error_code", safe(errorCode, 120))
                put("exception", error?.javaClass?.name.orEmpty())
                put("message", safe(message.ifBlank { error?.message.orEmpty() }))
                put("cause", safe(error?.cause?.let { "${it.javaClass.name}: ${it.message.orEmpty()}" }.orEmpty(), 350))
                put("stack", safe(error?.stackTrace?.take(8)?.joinToString(" | ") { it.toString() }.orEmpty(), 1300))
                if (durationMs > 0) put("duration_ms", durationMs.toString())
                put("request_id", safe(requestId, 100))
                put("retry_after", safe(retryAfter, 30))
            }
            synchronized(guard) {
                val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val events = runCatching { JSONArray(prefs.getString(KEY, "[]")) }.getOrDefault(JSONArray())
                val next = JSONArray()
                val start = (events.length() - LIMIT + 1).coerceAtLeast(0)
                for (i in start until events.length()) next.put(events.optJSONObject(i))
                next.put(item)
                val editor = prefs.edit().putString(KEY, next.toString())
                if (stage.startsWith("uncaught_crash")) editor.commit() else editor.apply()
            }
        } catch (_: Throwable) { /* Telemetry can never crash BankMovie. */ }
    }

    private fun device(context: Context): JSONObject = JSONObject().apply {
        val info = runCatching { context.packageManager.getPackageInfo(context.packageName, 0) }.getOrNull()
        val net = runCatching {
            @Suppress("DEPRECATION")
            (context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager)
                ?.activeNetworkInfo?.typeName.orEmpty()
        }.getOrDefault("unknown")
        put("manufacturer", Build.MANUFACTURER.orEmpty())
        put("brand", Build.BRAND.orEmpty())
        put("model", Build.MODEL.orEmpty())
        put("device", Build.DEVICE.orEmpty())
        put("product", Build.PRODUCT.orEmpty())
        put("android", Build.VERSION.RELEASE.orEmpty())
        put("sdk", Build.VERSION.SDK_INT.toString())
        put("abi", Build.SUPPORTED_ABIS.take(3).joinToString(","))
        put("app_version", info?.versionName.orEmpty())
        @Suppress("DEPRECATION")
        put("app_build", if (Build.VERSION.SDK_INT >= 28) info?.longVersionCode?.toString().orEmpty() else info?.versionCode?.toString().orEmpty())
        put("language", Locale.getDefault().language)
        put("locale", Locale.getDefault().toString())
        put("network", safe(net, 80))
        put("time_utc", System.currentTimeMillis().toString())
        put("timezone", TimeZone.getDefault().id)
        // Random install reference is NOT an Android hardware ID.
        val pref = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        var ref = pref.getString("install_ref", "").orEmpty()
        if (ref.isBlank()) {
            ref = java.util.UUID.randomUUID().toString()
            pref.edit().putString("install_ref", ref).apply()
        }
        put("install_ref", ref)
    }

    fun snapshot(context: Context, note: String = "", tests: JSONArray = JSONArray()): JSONObject {
        val events = synchronized(guard) {
            runCatching { JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")) }
                .getOrDefault(JSONArray())
        }
        return JSONObject().apply {
            put("device", device(context))
            put("events", events)
            put("issue_note", safe(note, 1800))
            put("tests", tests)
        }
    }

    /** Tests run separately from the signed API, to diagnose DNS/TLS/HTTP even if login fails. */
    private fun statusProbe(): JSONArray {
        val checks = JSONArray()
        val started = System.currentTimeMillis()
        var conn: HttpURLConnection? = null
        try {
            val url = URL("https://bankmovie.top/v2/api/status.php")
            val count = java.net.InetAddress.getAllByName(url.host).size
            checks.put(JSONObject().put("name", "DNS").put("result", "resolved ($count address records)"))
            conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"; connectTimeout = 6000; readTimeout = 7500
                instanceFollowRedirects = false; useCaches = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("Cache-Control", "no-store")
            }
            val status = conn.responseCode
            val serverDate = conn.getHeaderFieldDate("Date", -1L)
            if (serverDate > 0L) checks.put(JSONObject().put("name", "ServerClockSkew")
                .put("result", "${(System.currentTimeMillis() - serverDate) / 1000L} seconds (device minus HTTP Date)"))
            val body = (if (status in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText().take(300) }.orEmpty()
            val json = runCatching { JSONObject(body) }.getOrNull()
            checks.put(JSONObject().put("name", "HTTPS_API_Status").put("result", "HTTP $status; tls=${json?.optString("tls")}; elapsed=${System.currentTimeMillis() - started}ms"))
        } catch (error: Throwable) {
            checks.put(JSONObject().put("name", "HTTPS_API_Status").put("result", safe("${error.javaClass.name}: ${error.message.orEmpty()}", 220)))
        } finally { runCatching { conn?.disconnect() } }
        return checks
    }

    fun send(context: Context, note: String, done: (Boolean, String) -> Unit) {
        Thread {
            val tests = statusProbe()
            val json = snapshot(context, note, tests).toString()
            var connection: HttpURLConnection? = null
            val result: Pair<Boolean, String> = try {
                connection = (URL(DEST).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"; connectTimeout = 8000; readTimeout = 12000
                    doOutput = true; instanceFollowRedirects = false; useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept", "application/json")
                }
                val bytes = json.toByteArray(Charsets.UTF_8)
                connection.setFixedLengthStreamingMode(bytes.size)
                connection.outputStream.use { it.write(bytes) }
                val code = connection.responseCode
                val response = (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader(Charsets.UTF_8)?.use { it.readText().take(500) }.orEmpty()
                val responseJson = runCatching { JSONObject(response) }.getOrNull()
                if (code in 200..299 && responseJson?.optBoolean("ok") == true) {
                    true to responseJson.optString("report_id", "ثبت شد")
                } else {
                    record(context, "diagnostic_upload", DEST, code, responseJson?.optString("error_code").orEmpty(), "Upload rejected")
                    false to "HTTP $code - ${responseJson?.optString("error_code").orEmpty()}"
                }
            } catch (error: Throwable) {
                record(context, "diagnostic_upload", DEST, message = "Upload unavailable", error = error)
                false to "${error.javaClass.simpleName}: ${safe(error.message.orEmpty(), 120)}"
            } finally { runCatching { connection?.disconnect() } }
            Handler(Looper.getMainLooper()).post { done(result.first, result.second) }
        }.start()
    }
}
