package ir.bankmoviee.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.widget.TextView

/**
 * The shared splash arc in pagination buttons. Async callers can disable/enable
 * this text view as before; the button shows the same accent-colored ring.
 */
class InlineSpinnerButton @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.textViewStyle
) : TextView(context, attrs, defStyleAttr) {

    private val spinnerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private var loading = false
    private var savedTextColor = Color.WHITE
    private var loadingStartedAt = 0L
    private val stopRunnable = Runnable { stopInlineLoading() }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    fun isInlineLoading(): Boolean = loading

    fun startInlineLoading() {
        if (loading || !isEnabled) return
        loading = true
        loadingStartedAt = android.os.SystemClock.uptimeMillis()
        savedTextColor = currentTextColor
        setTextColor(Color.TRANSPARENT)
        removeCallbacks(stopRunnable)
        // Navigation replaces/detaches the source button. Async pagination must
        // re-enable it on completion; the short fallback only guards abandoned taps.
        postDelayed(stopRunnable, 20000L)
        postInvalidateOnAnimation()
    }

    fun stopInlineLoading() {
        if (!loading) return
        loading = false
        removeCallbacks(stopRunnable)
        setTextColor(savedTextColor)
        invalidate()
    }

    override fun setEnabled(enabled: Boolean) {
        // Initial page loads can start without a click, so listen to the existing
        // disabled/loading contract instead of relying solely on performClick().
        if (!enabled && !loading && isEnabled &&
            (text.contains("در حال بارگذاری") || text.contains("Loading", ignoreCase = true))) {
            startInlineLoading()
        }
        if (enabled && loading) stopInlineLoading()
        super.setEnabled(enabled)
    }

    override fun performClick(): Boolean {
        if (loading) return true
        startInlineLoading()
        return super.performClick()
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(stopRunnable)
        if (loading) {
            loading = false
            setTextColor(savedTextColor)
        }
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!loading) return

        val phase = ((android.os.SystemClock.uptimeMillis() - loadingStartedAt) % 2000L) / 2000f
        spinnerPaint.strokeWidth = dp(2.5f)
        spinnerPaint.color = UiPreferences.palette(context).primary
        spinnerPaint.alpha = 255
        ThemeLoadingArc.draw(canvas, width / 2f, height / 2f, dp(13f), spinnerPaint, phase)
        postInvalidateOnAnimation()
    }
}
