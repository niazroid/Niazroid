package ir.bankmoviee.app

import android.app.Activity
import android.app.Application
import android.os.Build
import android.os.Bundle
import org.conscrypt.Conscrypt
import java.security.KeyStore
import java.security.Security
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManagerFactory

class BankmovieApplication : Application(), Application.ActivityLifecycleCallbacks {
    override fun onCreate() {
        super.onCreate()
        // TLS fix for Android 6-9: use bundled Conscrypt (TLS 1.2/1.3) instead of the old system TLS.
        if (Build.VERSION.SDK_INT < 29) {
            var insertedProviderName: String? = null
            try {
                // Preserve Android's application-aware trust manager (including Network Security
                // Config's verified Let's Encrypt roots) and normal hostname validation.
                val tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm())
                tmf.init(null as KeyStore?)
                val provider = Conscrypt.newProvider()
                val index = Security.insertProviderAt(provider, 1)
                if (index > 0) insertedProviderName = provider.name
                val ctx = SSLContext.getInstance("TLS", provider)
                ctx.init(null, tmf.trustManagers, null)
                HttpsURLConnection.setDefaultSSLSocketFactory(ctx.socketFactory)
                BmDiagnostics.record(this, "tls_provider_ready", message = "Conscrypt TLS active; provider=${provider.name}; sdk=${Build.VERSION.SDK_INT}")
            } catch (error: Throwable) {
                // A partially initialized global provider must not break normal HTTPS fallback.
                insertedProviderName?.let { name -> runCatching { Security.removeProvider(name) } }
                BmDiagnostics.record(this, "tls_provider_init_error", error = error)
            }
        }
        // Store crash details for the next manual diagnostic submission. Never swallow crashes.
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            BmDiagnostics.record(this, "uncaught_crash:${thread.name}", error = error)
            if (previousHandler != null) previousHandler.uncaughtException(thread, error)
            else android.os.Process.killProcess(android.os.Process.myPid())
        }
        // V7.47.1.20: native appearance is local-only; drop any legacy bridge
        // state before account refresh or website profile data can be consumed.
        UiPreferences.detachAppAppearanceFromWebsite(this)
        registerActivityLifecycleCallbacks(this)
        BankMoviePush.ensureSubscribed(this)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        RemoteTextStore.install(activity)
    }

    override fun onActivityResumed(activity: Activity) {
        RemoteTextStore.install(activity)
    }

    override fun onActivityStarted(activity: Activity) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
