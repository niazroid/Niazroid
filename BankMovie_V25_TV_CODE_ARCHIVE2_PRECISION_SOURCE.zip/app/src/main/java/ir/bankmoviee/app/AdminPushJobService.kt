package ir.bankmoviee.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.job.JobParameters
import android.app.job.JobService
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class AdminPushJobService : JobService() {
    companion object {
        private const val CHANNEL_ID = "bankmovie_admin_push"
        private const val PREFS = "bankmovie_admin_push_state"
        private const val KEY_INITIALIZED = "initialized"
        private const val KEY_LAST_ID = "last_id"
        private const val NOTIFICATION_BASE = 26000
    }

    override fun onStartJob(params: JobParameters?): Boolean {
        Thread {
            try { syncAdminNotifications() } finally { params?.let { jobFinished(it, false) } }
        }.start()
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean = true

    private fun endpoint(): String {
        val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val base = prefs.getString("api_base", "").orEmpty().ifBlank { AppConfig.APP_API_URL }
        val separator = if (base.contains('?')) '&' else '?'
        return "$base${separator}action=notifications"
    }

    private fun syncAdminNotifications() {
        var connection: HttpURLConnection? = null
        try {
            val url = URL(BmV22Client.urlForApi(endpoint()))
            connection = (url.openConnection() as HttpURLConnection).apply {
                connectTimeout = 7000
                readTimeout = 9000
                instanceFollowRedirects = false
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "BankmovieAndroidNative/2.4-Push")

            }
            BmV22Client.attach(this, connection, url)
            if (connection.responseCode !in 200..299) return
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val payload = JSONObject(body)
            val revoked = payload.optJSONArray("revoked_ids")
            if (revoked != null) {
                for (i in 0 until revoked.length()) {
                    val revokedId = revoked.optLong(i, 0L)
                    if (revokedId <= 0L) continue
                    NotificationDismissStore.dismissRemote(this, revokedId)
                    LocalNotificationStore.deleteByDedupeKey(this, "admin-push:$revokedId")
                    NotificationDismissStore.cancelAdminPushSystemNotification(this, revokedId)
                }
            }
            val items = payload.optJSONArray("items") ?: return
            val state = getSharedPreferences(PREFS, MODE_PRIVATE)
            var lastId = state.getLong(KEY_LAST_ID, 0L)
            var maxId = lastId
            val fresh = mutableListOf<JSONObject>()
            for (i in 0 until items.length()) {
                val item = items.optJSONObject(i) ?: continue
                val id = item.optLong("id", 0L)
                if (id > maxId) maxId = id
                if (id > lastId) fresh.add(item)
                // The FCM packet intentionally omits large SVG payloads. The
                // periodic fetch can upgrade the local card without replaying it.
                if (id <= lastId && !NotificationDismissStore.isRemoteDismissed(this, id)) {
                    val existingTarget=BankMoviePushPresentation.target(item.optString("kind"), item.optString("link"),
                        item.optString("cta_label"), item.optString("cta_url"),
                        item.optString("secondary_label"), item.optString("secondary_url"), item.optString("icon_svg"), item.optString("image_url"))
                    if (item.optString("icon_svg").isNotBlank()) {
                        LocalNotificationStore.addOrUpdate(this, item.optString("kind").ifBlank { "admin" },
                            item.optString("title"),item.optString("message"),existingTarget,"admin-push:$id")
                    }
                }
            }
            if (!state.getBoolean(KEY_INITIALIZED, false)) {
                // Guests have the same public notification feed. On a fresh install,
                // show only very recent messages instead of silently dropping them.
                // Do not replay the entire historic admin feed.
                val now = System.currentTimeMillis()
                val recent = fresh.filter { item ->
                    val timeString = item.optString("created_at").trim()
                    val postedEpoch = item.optLong("created_at_epoch", 0L)
                    val postedAt = if (postedEpoch > 0L) postedEpoch * 1000L else runCatching {
                        java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).parse(timeString)?.time ?: 0L
                    }.getOrDefault(0L)
                    postedAt > 0L && postedAt <= now + 60000L && now - postedAt <= 30L * 60L * 1000L
                }.takeLast(3)
                recent.sortedBy { it.optLong("id") }.forEach { showAdminNotification(it) }
                state.edit().putBoolean(KEY_INITIALIZED, true).putLong(KEY_LAST_ID, maxId).apply()
                return
            }
            fresh.sortedBy { it.optLong("id") }.forEach { showAdminNotification(it) }
            if (maxId > lastId) state.edit().putLong(KEY_LAST_ID, maxId).apply()
        } catch (_: Throwable) {
        } finally {
            runCatching { connection?.disconnect() }
        }
    }

    private fun showAdminNotification(item: JSONObject) {
        val id = item.optLong("id", System.currentTimeMillis()).coerceAtLeast(1L)
        if (NotificationDismissStore.isRemoteDismissed(this, id)) return
        val title = item.optString("title").ifBlank { "پیام مدیریت بانک مووی" }
        val message = item.optString("message")
        if (message.isBlank()) return
        val link = item.optString("link")
        if (!BankMoviePushPresentation.allowed(this, item.optString("audience"))) return
        val target = BankMoviePushPresentation.target(
            item.optString("kind").ifBlank { "admin" }, link,
            item.optString("cta_label"), item.optString("cta_url"),
            item.optString("secondary_label"), item.optString("secondary_url"),
            item.optString("icon_svg"), item.optString("image_url")
        )
        LocalNotificationStore.addOrUpdate(
            this,
            item.optString("kind").ifBlank { "admin" },
            title,
            message,
            target,
            "admin-push:$id"
        )
        // Android 13 may deny system notifications, but the in-app inbox and
        // colored unread bell must still work for both guests and members.
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        createChannel()
        val safeLink = BankMoviePushPresentation.safeUrl(target.optString("url")).takeIf { it.isNotBlank() }
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra("admin_push_tap", true)
            if (safeLink != null) putExtra("admin_push_url", safeLink)
        }
        val pending = PendingIntent.getActivity(
            this,
            (id % Int.MAX_VALUE).toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val deletePending = PendingIntent.getBroadcast(
            this,
            (id % Int.MAX_VALUE).toInt(),
            Intent(this, NotificationDismissReceiver::class.java).apply {
                action = NotificationDismissReceiver.ACTION
                putExtra(NotificationDismissReceiver.EXTRA_NOTIFICATION_ID, id)
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_bankmovie_push)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setDeleteIntent(deletePending)
            .setContentIntent(pending)
        BankMoviePushPresentation.addActions(this, notification, id, target)
        val built = notification.build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(NOTIFICATION_BASE + (id % 3000L).toInt(), built)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "پیام‌های مدیریت بانک مووی", NotificationManager.IMPORTANCE_HIGH).apply {
                description = "اطلاعیه‌ها و پیام‌هایی که از پنل مدیریت ارسال می‌شوند"
                enableVibration(true)
            }
        )
    }
}
