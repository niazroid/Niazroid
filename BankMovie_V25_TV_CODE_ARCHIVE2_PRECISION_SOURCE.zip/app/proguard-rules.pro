-keep class org.videolan.** { *; }
-dontwarn org.videolan.**

-keep class ir.bankmoviee.app.InternalDownloadService { *; }
-keep class ir.bankmoviee.app.DownloadsActivity { *; }


# Preserve native/JNI entry points but allow app implementation names and the
# runtime vault to be optimized and renamed by R8.
-keepclasseswithmembers,allowoptimization,allowobfuscation class * {
    native <methods>;
}
-allowaccessmodification
-repackageclasses x
-adaptclassstrings

# Media3's DefaultRenderersFactory loads the optional FFmpeg renderer via
# reflection. Keep it in minified release builds (ABI4-Full only).
-keep class androidx.media3.decoder.ffmpeg.** { *; }
-dontwarn androidx.media3.decoder.ffmpeg.**

# Conscrypt TLS provider (Android 6-9 TLS/Let's Encrypt fix)
-keep class org.conscrypt.** { *; }
-dontwarn org.conscrypt.**
