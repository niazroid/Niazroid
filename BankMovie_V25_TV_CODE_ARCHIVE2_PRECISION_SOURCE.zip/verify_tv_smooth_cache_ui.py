#!/usr/bin/env python3
"""TV DPAD rollback guard. Static checks; device testing still required."""
from pathlib import Path
root = Path(__file__).resolve().parent
main=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
scroll=(root/'app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt').read_text()
card=main.split('private fun unifiedNetworkFailureCard(',1)[1].split('private fun errorView(',1)[0]
assert 'bm_no_wifi_original' in card
assert 'bm_v14_clapperboard' not in card
assert card.count('actions.addView(errorActionButton(') == 2
assert 'clipToOutline = true' in card
assert 'managedHomePosterFocus' not in scroll
assert 'private fun animateTvPosterRailFocus(' not in main
assert 'scroller.tag = "bm_tv_home_rail"' not in main
assert 'if (tvLike && suppressTvFocusReveal)' in scroll
assert 'if (tvLike && suppressTvFocusReveal) return false' in scroll
assert 'private fun rememberHomeForSession()' in main
assert 'if (isTvLike()) {\n            retainedHomeSession = null\n            return' in main
assert 'private fun tryRestoreHomeSession()' in main
assert 'if (isTvLike()) {\n            retainedHomeSession = null\n            return false' in main
focus=main.split('private fun rebindHomeTvFocusAfterLifecycle()',1)[1].split('private fun handleHomePosterDirectionalFocus(',1)[0]
assert 'resetHomeTvRailViewportsToNewest()' in focus
assert 'scheduleTvInitialScreenFocus(35L)' in focus
assert 'v is TextView || v.tag == "bm_v73_detail_more_info"' in main
assert 'addView(head, LinearLayout.LayoutParams(-1, -2))' in main
print('TV_DPAD_FOCUS_ROLLBACK_STATIC_OK (not a device test)')
