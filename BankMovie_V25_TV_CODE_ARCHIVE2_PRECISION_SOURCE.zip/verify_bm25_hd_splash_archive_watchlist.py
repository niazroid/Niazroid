#!/usr/bin/env python3
"""Static regression guard for sharpened phone splash, static TV splash,
Home sections and watchlist tabs.
Not an Android compile, image-restoration or device test.
"""
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
def webp_dimensions(path: Path):
    raw=path.read_bytes()
    assert raw[:4] == b'RIFF' and raw[8:12] == b'WEBP'
    marker=raw.find(b'\x9d\x01\x2a', 12, 80)
    assert marker >= 0, 'WEBP_VP8_FRAME_HEADER_MISSING'
    w=int.from_bytes(raw[marker+3:marker+5], 'little') & 0x3fff
    h=int.from_bytes(raw[marker+5:marker+7], 'little') & 0x3fff
    return (w,h)
phone=root/'app/src/main/res/drawable-nodpi/bm_splash_wall_phone.webp'
tv=root/'app/src/main/res/drawable-nodpi/bm_splash_wall_tv.webp'
assert webp_dimensions(phone)==(1600,2844)
assert webp_dimensions(tv)==(3840,2160)
assert phone.stat().st_size < 3_000_000 and tv.stat().st_size < 3_000_000
splash=src.split('private fun showSplashOnly()',1)[1].split('private fun discardStartupSplash()',1)[0]
assert 'val tvSplash = isTvLike()' in splash
assert 'setImageResource(if (tvSplash) R.drawable.bm_splash_wall_tv' in splash
assert 'else R.drawable.bm_splash_wall_phone)' in splash
assert 'alpha = 1.0f' in splash
assert 'scaleX = if (tvSplash) 1.0f else 1.17f' in splash
assert 'translationX = if (tvSplash) 0f else -posterDriftX' in splash
assert 'LinearLayout.LayoutParams(dp(if (tvSplash) 186 else 182), dp(if (tvSplash) 89 else 87))' in splash
assert 'if (!tvSplash) {' in splash
assert 'repeatMode = ValueAnimator.REVERSE' in splash
# Splash should never contain the heavy black veil or a black divider.
assert 'Color.argb(180, 0, 0, 0)' not in splash
assert 'Color.argb(if (tvSplash) 125 else 85, 1, 5, 12)' in splash
# Login and registration use the same approved high-resolution textures.
auth=(root/'app/src/main/java/ir/bankmoviee/app/AuthActivity.kt').read_text()
auth_bg=auth.split('private fun applyBundledBackground()',1)[1].split('private fun renderForm()',1)[0]
assert 'if (isTvLike()) R.drawable.bm_splash_wall_tv' in auth_bg
assert 'else R.drawable.bm_splash_wall_phone' in auth_bg
assert 'backgroundImage.alpha = if (isTvLike()) 0.92f else 0.88f' in auth_bg
assert 'R.drawable.bm_loading_auth_bg' not in auth_bg
# Old authBackground URL must not override the approved local image after
# login/registration renders. Keep the account-config callback and TV keyboard.
assert 'AccountSession.authBackground(this).takeIf { it.isNotBlank() }?.let(::loadBackground)' not in auth
assert 'private fun loadBackground(' not in auth
assert 'AccountApi.loadConfig(this)' in auth
assert 'private fun showTvKeyboard(' in auth

policy=src.split('private fun homeSectionEnabled(',1)[1].split('private fun homeSectionTitle(',1)[0]
assert 'safe in 3..4 && key in setOf("updated_animations", "subtitled_movies", "subtitled_series")' in policy
for archive in (3,4):
    b=src.split(f'            {archive} -> when (key) {{',2)[-1].split('            }',1)[0]
    assert 'addRail(page, "انیمیشن‌های به‌روزشده", '+str(archive) not in b
    assert 'addRail(page, "فیلم‌های زیرنویس‌دار", '+str(archive) not in b
assert '"updated_anime" -> addRail(page' in src
wt=src.split('private fun watchlistTabs(',1)[1].split('private fun showFavorites(',1)[0]
assert 'R.drawable.ic_bm_film' in wt and 'R.drawable.ic_bm_series' in wt
assert 'watchlistCategorySelection = key' in wt
assert 'hydrateWatchlistCards()' in wt
sk=src.split('private fun movieDetailGlassLoading()',1)[1].split('private fun notificationGlassLoadingSkeleton()',1)[0]
assert 'Color.argb(72, 91, 99, 117)' in sk
assert 'Color.argb(65, 204, 209, 228)' in sk
assert 'setImageResource(R.drawable.ic_imdb)' in sk
assert 'setImageResource(R.drawable.ic_comment_like)' in sk
print('BM25_TV_STATIC_HD_SPLASH_ARCHIVE_WATCHLIST_STATIC_OK')
