#!/usr/bin/env python3
"""Structural regression for the smooth startup & session Home View retention."""
from pathlib import Path
import re
src=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
w=Path('.github/workflows/build-bankmovie.yml').read_text()
section=lambda a,b: src.split(a,1)[1].split(b,1)[0]
startup=section('private fun dismissStartupSplashAfterHomeFrame()', 'private fun showNetworkError')
home=section('private fun showHome()', 'private fun openTelegramChannel()')
profile=section('private fun showProfile()', 'private fun profileCompactActionTile')
back=section('private fun handleSmartBack()', 'private fun updateSearchRestorer()')
remember=section('private fun rememberHomeForSession()', 'private fun tryRestoreHomeSession()')
restore=section('private fun tryRestoreHomeSession()', 'private fun restoreRetainedNavigationScreen(')
assert re.search(r'if \(isTvLike\(\)\)\s*\{\s*retainedHomeSession = null\s*return\s*\}', remember), 'TV Home must not save a retained scroll/focus snapshot'
assert re.search(r'if \(isTvLike\(\)\)\s*\{\s*retainedHomeSession = null\s*return false\s*\}', restore), 'TV Home must rebuild instead of restoring its saved scroll/focus snapshot'
assert 'if (!startupHomeContentReady) return' in startup
assert 'startupHomeContentReady && content.childCount > 0' in startup
assert 'val homeGeneration = ++homeRenderSerial' in home
assert 'val stagedStartup = startupSplashView != null && !restoringNavigation' in home
assert 'renderHomeSectionWithPolicy(homeBody, selectedArchive, sectionsForDisplay[nextSection++])' in home
assert 'uiHandler.postDelayed({ renderNext() }, 20L)' in home
assert 'startupHomeContentReady = true' in home
assert home.index('if (currentScreen != "home" && tryRestoreHomeSession())') < home.index('buildBottomNav()')
assert 'if (currentScreen == "home") rememberHomeForSession()' in profile
assert 'if (currentScreen == "home") rememberHomeForSession()' in section('private fun pushCurrentScreenForBack()', 'private fun runBackNavigationMotion(')
assert 'showHome()' in back
assert 'snapshot.children.isEmpty()' in restore
assert 'retainedHomeArchive != selectedArchive' in restore
assert 'retainedHomeAppearance != currentHomeAppearanceKey()' in restore
assert 'retainedHomeStructure != homeConfigStructureSignature' in restore
assert 'wireHomePosterRows()' in restore and 'content.setPadding(0, 0, 0, 0)' in restore
assert 'refreshHomeAdvertisingInPlace()' in restore
assert 'retainedHomeSession = null' in section('private fun setSelectedArchive(', 'private fun archiveSectionUrl(')
assert 'retainedHomeSession = null' in section('private fun archiveSegment(', 'private fun archiveSwitchBar(')
assert 'retainedHomeSession = null' in section('private fun refreshConfigOnForeground(', 'private fun refreshHomeAdFromController(')
assert 'private fun movieDetailLoading(seed: JSONObject): View' in src
assert 'ModernSearchLoaderView(this@MainActivity, "Searching")' in src
assert 'ImageCache' in src or 'imageCache:' in src
assert re.search(r"(?m)^\s*SOURCE_ZIP:\s*BankMovie_Android_FULLSOURCE_V2\.4_[A-Za-z0-9_.-]+\.zip\s*$", w)
assert 'verify_v24_smooth_startup_home_session_cache.py' in w
print('VERIFY_V24_SMOOTH_STARTUP_HOME_SESSION_CACHE_OK')
