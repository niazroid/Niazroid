'use strict';
const path = require('path');
const fs = require('fs');
const net = require('net');
const crypto = require('crypto');
const { spawn } = require('child_process');
function bundledPlayer(resourcesPath, packaged, root=path.join(__dirname,'..')) {
  const base = packaged ? resourcesPath : root;
  const exe = path.join(base, packaged ? 'mpv' : 'vendor/mpv', 'mpv.exe');
  const script = path.join(base, 'player', 'cinema.lua');
  if (!fs.existsSync(exe) || !fs.existsSync(script)) return null;
  return {id:'bm-mpv',name:'BankMovie (MPV)',path:exe,script,score:1000,subtitleSupport:true};
}
function cleanTitle(value) {return String(value||'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,240);}
function argsFor(player, target, meta={}, local=false) {
  if (typeof target!=='string'||!target||/[\x00-\x1f]/.test(target)) throw Error('Invalid media path');
  if(local){if(!path.isAbsolute(target))throw Error('Invalid local media path');}
  else {const u=new URL(target);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid media URL');}
  const args=['--no-config','--load-scripts=no','--osc=no','--input-default-bindings=no','--input-builtin-dragging=no','--input-builtin-drag-and-drop=no','--ytdl=no','--load-unsafe-playlists=no','--tls-verify=yes','--no-terminal','--force-window=yes','--idle=no','--keep-open=yes','--geometry=80%x80%','--hwdec=auto-safe','--cache=auto','--sub-auto='+ (local?'exact':'no'),'--audio-file-auto=no','--cover-art-auto=no','--slang=fa,fas,per,persian,en,eng','--script='+player.script];
  const title=cleanTitle(meta.title || (local?path.basename(target):'BankMovie'));
  if(title)args.push('--force-media-title='+title);
  if(meta.subtitlePath)args.push('--sub-file='+meta.subtitlePath);
  if(meta.embed){
    if(!Number.isInteger(meta.embed.hwnd)||meta.embed.hwnd<=0||meta.embed.hwnd>0xffffffff)throw Error('Invalid window handle');
    if(typeof meta.embed.pipe!=='string'||!/^\\\\\.\\pipe\\bm-mpv-[a-f0-9]{32}$/.test(meta.embed.pipe))throw Error('Invalid private player pipe');
    args.splice(args.indexOf('--geometry=80%x80%'),1);
    args.push('--wid='+meta.embed.hwnd,'--input-ipc-server='+meta.embed.pipe,'--script-opts=bm-embedded=yes');
  }
  args.push('--',target);
  return args;
}
async function launch(player,target,meta={},local=false,spawnFn=spawn){
  const args=argsFor(player,target,meta,local);
  await new Promise((resolve,reject)=>{
    const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:true,stdio:'ignore',windowsHide:false});
    child.once('error',()=>reject(new Error('اجرای موتور MPV ناموفق بود.')));
    child.once('spawn',()=>{child.unref();resolve();});
  });
  return {ok:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)};
}
// MPV draws its native child into the existing Electron window. No new BrowserWindow.
const active = new WeakMap();
function hwndOf(win){
  if(!win||win.isDestroyed())throw Error('BankMovie window unavailable');
  const b=win.getNativeWindowHandle();
  if(!Buffer.isBuffer(b)||b.length<4)throw Error('Invalid native window');
  const id=b.readUInt32LE(0);if(!id)throw Error('Invalid native window');return id;
}
async function launchEmbedded(player,target,meta={},local=false,win,opts={}){
  const hwnd=hwndOf(win);
  if(active.has(win))throw Error('ابتدا پلیر فعلی را ببندید.');
  const pipe='\\\\.\\pipe\\bm-mpv-'+crypto.randomBytes(16).toString('hex');
  const args=argsFor(player,target,{...meta,embed:{hwnd,pipe}},local);
  const spawnFn=opts.spawnFn||spawn, connect=opts.connect||net.createConnection;
  const initialFull=win.isFullScreen();
  let child,socket,retry,deadline,buffer='',finished=false,ready=false,lastRequest='',intentional=false;
  let resolveReady,rejectReady;
  const started=new Promise((resolve,reject)=>{resolveReady=resolve;rejectReady=reject;});
  function send(command){if(socket&&!socket.destroyed&&ready)socket.write(JSON.stringify({command})+'\n');}
  function syncFull(){if(!win.isDestroyed())send(['set_property','user-data/bm/parent-fullscreen',win.isFullScreen()]);}
  function clean(error){
    if(finished)return;finished=true;clearTimeout(retry);clearTimeout(deadline);
    if(socket)socket.destroy();active.delete(win);
    win.removeListener('closed',onClose);win.removeListener('enter-full-screen',syncFull);win.removeListener('leave-full-screen',syncFull);
    if(!win.isDestroyed()){
      if(win.isFullScreen()!==initialFull)win.setFullScreen(initialFull);
      if(!win.isMinimized()){win.focus();if(win.webContents&&!win.webContents.isDestroyed())win.webContents.focus();}
    }
    if(!ready)rejectReady(error||Error('موتور MPV قبل از آماده شدن بسته شد.'));
    else if(error&&!intentional&&opts.onError)opts.onError(error);
  }
  function onClose(){intentional=true;if(child&&!child.killed)child.kill();clean();}
  function read(chunk){
    buffer+=chunk;if(buffer.length>65536){buffer='';return;}
    let i;while((i=buffer.indexOf('\n'))>=0){const line=buffer.slice(0,i);buffer=buffer.slice(i+1);let m;try{m=JSON.parse(line)}catch{continue}
      if(m.event==='property-change'&&m.name==='user-data/bm/request'&&typeof m.data==='string'&&m.data!==lastRequest){
        lastRequest=m.data;if(!win.isDestroyed()&&/^toggle:\d+$/.test(m.data))win.setFullScreen(!win.isFullScreen());
      }
    }
  }
  function attempt(){if(finished||ready)return;socket=connect(pipe);socket.setEncoding('utf8');
    socket.on('data',read);socket.once('connect',()=>{if(finished)return;ready=true;clearTimeout(deadline);send(['observe_property',1,'user-data/bm/request']);syncFull();resolveReady({ok:true,embedded:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)});});
    socket.once('error',()=>{if(!finished&&!ready)retry=setTimeout(attempt,150);});
  }
  active.set(win,{close:onClose});
  win.once('closed',onClose);win.on('enter-full-screen',syncFull);win.on('leave-full-screen',syncFull);
  try{child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:false,stdio:'ignore',windowsHide:true});
    child.once('error',()=>clean(Error('اجرای موتور MPV ناموفق بود.')));
    child.once('exit',(code)=>clean(code===0||intentional?null:Error('پخش MPV متوقف شد.')));
    child.once('spawn',attempt);
    deadline=setTimeout(()=>{intentional=true;if(child&&!child.killed)child.kill();clean(Error('اتصال پلیر به پنجره برنامه ناموفق بود.'));},10000);
  }catch(e){clean(e);}
  return started;
}
module.exports={bundledPlayer,argsFor,launch,launchEmbedded,hwndOf};
