'use strict';
const assert=require('node:assert/strict');const {EventEmitter}=require('node:events');const P=require('../electron/mpv-player');
const player={id:'bm-mpv',name:'BankMovie',path:'C:/mpv.exe',script:'C:/cinema.lua'};
const url='https://example.com/movie.mkv';
function fixture(){
  const win=new EventEmitter();let full=false,destroyed=false,focused=0;
  Object.assign(win,{isDestroyed:()=>destroyed,getNativeWindowHandle:()=>Buffer.from([0x78,0x56,0x34,0x12,0,0,0,0]),isFullScreen:()=>full,setFullScreen:v=>{full=v;win.emit(v?'enter-full-screen':'leave-full-screen')},isMinimized:()=>false,focus:()=>{focused++},webContents:{isDestroyed:()=>false,focus:()=>{focused++}}});
  const child=new EventEmitter();child.kill=()=>{child.killed=true;queueMicrotask(()=>child.emit('exit',0));};const socket=new EventEmitter();const sent=[];
  Object.assign(socket,{setEncoding(){},write(v){sent.push(JSON.parse(v).command)},destroy(){this.destroyed=true}});
  const opts={spawnFn(exe,args,opt){assert.equal(exe,player.path);assert.ok(args.includes('--wid=305419896'));assert.ok(args.includes('--script-opts=bm-embedded=yes'));assert.ok(!args.includes('--geometry=80%x80%'));assert.equal(opt.detached,false);assert.equal(opt.shell,false);queueMicrotask(()=>child.emit('spawn'));return child},connect(pipe){assert.match(pipe,/^\\\\\.\\pipe\\bm-mpv-[a-f0-9]{32}$/);queueMicrotask(()=>socket.emit('connect'));return socket}};
  return {win,child,socket,sent,opts,focused:()=>focused,destroy(){destroyed=true;win.emit('closed')}};
}
(async()=>{
  const f=fixture();assert.equal(P.hwndOf(f.win),305419896);
  const result=await P.launchEmbedded(player,url,{},false,f.win,f.opts);assert.equal(result.embedded,true);
  assert.ok(f.sent.some(c=>c[0]==='observe_property'));
  await assert.rejects(P.launchEmbedded(player,url,{},false,f.win,f.opts),/پلیر فعلی/);
  const msg=JSON.stringify({event:'property-change',name:'user-data/bm/request',data:'toggle:1'})+'\n';
  f.socket.emit('data',msg.slice(0,10));f.socket.emit('data',msg.slice(10));assert.equal(f.win.isFullScreen(),true);
  f.socket.emit('data',msg);assert.equal(f.win.isFullScreen(),true);
  f.child.emit('exit',0);assert.equal(f.win.isFullScreen(),false);assert.equal(f.focused(),2);assert.ok(f.socket.destroyed);
  const g=fixture();await P.launchEmbedded(player,url,{},false,g.win,g.opts);g.destroy();assert.ok(g.child.killed);
  const h=fixture();h.opts.spawnFn=()=>{queueMicrotask(()=>h.child.emit('error',Error('no exe')));return h.child};await assert.rejects(P.launchEmbedded(player,url,{},false,h.win,h.opts),/MPV/);
  console.log('PASS: embedded HWND, private IPC, duplicate session guard, fullscreen, close and startup failure');
})().catch(e=>{console.error(e);process.exitCode=1});
