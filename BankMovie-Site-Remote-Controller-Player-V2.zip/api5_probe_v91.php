<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$out = [
    'build' => 'v91-pre-update-restore-probe',
    'php' => PHP_VERSION,
    'curl' => function_exists('curl_init'),
    'dom' => class_exists('DOMDocument'),
    'mbstring' => function_exists('mb_strlen'),
    'api5_lib_exists' => is_file(__DIR__ . '/includes/api5_lib.php'),
];

try {
    require_once __DIR__ . '/includes/api5_lib.php';
    $out['base_url'] = defined('SERIALBLOG_BASE_URL') ? SERIALBLOG_BASE_URL : null;

    if (!function_exists('serialblog_get_html') || !function_exists('serialblog_parse_listing')) {
        throw new RuntimeException('api5_functions_missing');
    }

    $started = microtime(true);
    $html = serialblog_get_html(rtrim(SERIALBLOG_BASE_URL, '/') . '/');
    $out['fetch_ms'] = (int)round((microtime(true) - $started) * 1000);
    $out['html_bytes'] = strlen($html);

    $parsed = serialblog_parse_listing($html, 1, rtrim(SERIALBLOG_BASE_URL, '/') . '/');
    $out['parse_count'] = (int)($parsed['count'] ?? 0);
    $first = $parsed['items'][0] ?? null;

    if (is_array($first)) {
        $out['first'] = [
            'title' => (string)($first['title'] ?? ''),
            'type' => (string)($first['type'] ?? ''),
            'poster' => (string)($first['poster'] ?? ''),
        ];
    }

    $out['ok'] = $out['parse_count'] > 0;
} catch (Throwable $e) {
    http_response_code(500);
    $out['ok'] = false;
    $out['error'] = $e->getMessage();
}

echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
