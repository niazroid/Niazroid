<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// /search - صفحه جستجوی پیشرفته BankMovie با هدر/فوتر هماهنگ با index
require_once 'config.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/vip_features.php';
bm_vip_gate_require('advanced_search', $currentUser ?? null);
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('page_search_enabled');

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$currentUser = $currentUser ?? null;
if (!$currentUser && isset($_COOKIE['session_token'])) {
    try {
        $userObj = new User($pdo);
        $currentUser = $userObj->checkSession($_COOKIE['session_token']) ?: null;
    } catch (Throwable $e) {
        $currentUser = null;
    }
}

$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) {
    $userTheme = 'dark-green';
}
$currentTheme = $themes[$userTheme];
$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgbCss = hexdec(substr($themeHex, 0, 2)) . ',' . hexdec(substr($themeHex, 2, 2)) . ',' . hexdec(substr($themeHex, 4, 2));

$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

if (!function_exists('e')) {
    function e($str) {
        return htmlspecialchars((string)($str ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

$t = [
    'fa' => [
        'home' => 'خانه', 'search' => 'جستجو', 'profile' => 'پروفایل', 'player' => 'پلیر', 'request' => 'درخواست فیلم و سریال',
        'auth' => 'ثبت نام و ورود', 'account' => 'حساب کاربری', 'login' => 'ورود', 'register' => 'ثبت نام', 'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت', 'notifications' => 'اعلان‌ها', 'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'donate' => 'حمایت مالی', 'support_us' => 'حمایت مالی',
        'support_text' => 'تمام خدمات سایت رایگان است. اگر از بانک مووی راضی هستید، با یک حمایت کوچک به هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن'
    ],
    'en' => [
        'home' => 'Home', 'search' => 'Search', 'profile' => 'Profile', 'player' => 'Player', 'request' => 'Request Movie / Series',
        'auth' => 'Login / Register', 'account' => 'Account', 'login' => 'Login', 'register' => 'Register', 'logout' => 'Logout',
        'admin_panel' => 'Admin Panel', 'notifications' => 'Notifications', 'no_notifications' => 'No notifications',
        'donate' => 'Donate', 'support_us' => 'Support Us',
        'support_text' => 'All services are free. If you like BankMovie, you can support server and development costs.',
        'close' => 'Close'
    ]
];

$notificationsList = [];
$latestNotification = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $latestNotification = $notificationsList[0] ?? null;
} catch (Throwable $e) {
    $notificationsList = [];
    $latestNotification = null;
}

// دریافت و اعتبارسنجی پارامترهای جستجوی پیشرفته
$q = trim((string)($_GET['q'] ?? ''));
$genre = trim((string)($_GET['genre'] ?? ''));
$genreId = max(0, (int)($_GET['genre_id'] ?? 0));
$director = trim((string)($_GET['director'] ?? ''));
$country = trim((string)($_GET['country'] ?? ''));
$countryId = max(0, (int)($_GET['country_id'] ?? 0));
$actor = trim((string)($_GET['actor'] ?? ''));

$type = strtolower(trim((string)($_GET['type'] ?? 'all')));
if (!in_array($type, ['all','movie','series'], true)) $type = 'all';

$legacyYear = trim((string)($_GET['year'] ?? ''));
$fromYear = trim((string)($_GET['from_year'] ?? $legacyYear));
$toYear = trim((string)($_GET['to_year'] ?? $legacyYear));
$currentYear = (int)date('Y');
if ($fromYear !== '' && (!ctype_digit($fromYear) || (int)$fromYear < 1900 || (int)$fromYear > $currentYear)) $fromYear = '';
if ($toYear !== '' && (!ctype_digit($toYear) || (int)$toYear < 1900 || (int)$toYear > $currentYear)) $toYear = '';
if ($fromYear !== '' && $toYear !== '' && (int)$fromYear > (int)$toYear) {
    [$fromYear, $toYear] = [$toYear, $fromYear];
}
$year = ($fromYear !== '' && $fromYear === $toYear) ? $fromYear : '';

$rating = trim((string)($_GET['rating'] ?? ''));
if ($rating !== '' && (!is_numeric($rating) || (float)$rating < 0 || (float)$rating > 10)) $rating = '';

$sort = strtolower(trim((string)($_GET['sort'] ?? 'newest')));
$allowedSorts = ['newest','modified','popular','rating_desc','year_desc','year_asc','title_asc'];
if (!in_array($sort, $allowedSorts, true)) $sort = 'newest';

$dubbed = !empty($_GET['dubbed']);
$subtitle = !empty($_GET['subtitle']);
$suggest = !empty($_GET['suggest']);
// سازگاری با لینک‌های نسخه قبلی
$dubType = trim((string)($_GET['dub_type'] ?? 'all'));
if ($dubType === 'dubbed') $dubbed = true;
if ($dubType === 'softsub') $subtitle = true;

$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset = ($page - 1) * $perPage;

$archive = isset($_GET['archive']) ? trim((string)$_GET['archive']) : 'all';
$archiveAliases = array(
    '1' => 'arc1', 'archive1' => 'arc1', 'arc1' => 'arc1',
    '2' => 'local', 'archive2' => 'local', 'local' => 'local', 'arc2' => 'local',
    '3' => 'arc3', 'archive3' => 'arc3', 'arc3' => 'arc3',
    '4' => 'arc4', 'archive4' => 'arc4', 'arc4' => 'arc4',
    'all' => 'all', 'همه' => 'all'
);
$archive = isset($archiveAliases[$archive]) ? $archiveAliases[$archive] : 'all';
$archiveLabels = array(
    'all'   => $userLang === 'fa' ? 'همه آرشیوها' : 'All archives',
    'arc1'  => $userLang === 'fa' ? 'آرشیو ۱' : 'Archive 1',
    'local' => $userLang === 'fa' ? 'آرشیو ۲' : 'Archive 2',
    'arc3'  => $userLang === 'fa' ? 'آرشیو ۳' : 'Archive 3',
    'arc4'  => $userLang === 'fa' ? 'آرشیو ۴' : 'Archive 4',
);

$archiveEnabled = array(
    'arc1' => bm_site_bool('search_archive1_enabled', true) && bm_archive_is_enabled('archive1') && bm_archive_user_can_access('archive1', $currentUser ?? null),
    'local' => bm_site_bool('search_archive2_enabled', true) && bm_archive_is_enabled('archive2') && bm_archive_user_can_access('archive2', $currentUser ?? null),
    'arc3' => bm_site_bool('search_archive3_enabled', true) && bm_archive_is_enabled('archive3') && bm_archive_user_can_access('archive3', $currentUser ?? null),
    'arc4' => bm_archive_is_enabled('archive4') && bm_archive_user_can_access('archive4', $currentUser ?? null),
);
$advancedSearchEnabled = bm_site_bool('advanced_search_enabled', true);
$showActorDirector = bm_site_bool('search_show_actor_director', true);
$showCountryFilter = bm_site_bool('search_show_country', true);
$showSuggestedFilter = bm_site_bool('search_show_suggested_filter', true) && !empty($archiveEnabled['arc1']);
if ($archive !== 'all' && empty($archiveEnabled[$archive])) $archive = 'all';
if ($archive === 'all' && !array_filter($archiveEnabled)) {
    $archiveEnabled['local'] = true; // قفل ایمن: صفحه جستجو هرگز بدون منبع نمی‌ماند.
}
// فیلتر «پیشنهاد ویژه» متعلق به فرم واقعی آرشیو ۱ است. در حالت همه آرشیوها،
// برای یکدست ماندن معنی فیلتر فقط نتایج آرشیو ۱ خوانده می‌شوند.
if ($suggest && $archive !== 'all' && $archive !== 'arc1') $suggest = false;
$onlyArchive1ForSuggested = $suggest && $archive === 'all' && !empty($archiveEnabled['arc1']);

if (!function_exists('bm_search_archive_url')) {
    function bm_search_archive_url($archiveName) {
        $query = $_GET;
        $query['archive'] = $archiveName;
        unset($query['page']);
        return '/search' . (!empty($query) ? '?' . http_build_query($query) : '');
    }
}

if (!function_exists('bm_search_normalize_type')) {
    function bm_search_normalize_type($type) {
        $t = strtolower(trim((string)$type));
        if ($t === 'movie' || $t === 'film' || $t === 'فیلم') return 'movie';
        if ($t === 'series' || strpos($t, 'series') !== false || strpos($t, 'سریال') !== false || strpos($t, 'tv') !== false) return 'series';
        return 'series' === $t ? 'series' : ($t === 'movie' ? 'movie' : 'movie');
    }
}

if (!function_exists('bm_search_local_movie_url')) {
    function bm_search_local_movie_url($m) {
        if (function_exists('bm_movie_url')) {
            try { return bm_movie_url($m); } catch (Throwable $e) {}
        }
        $imdb = trim((string)(isset($m['imdb_code']) ? $m['imdb_code'] : ''));
        return $imdb !== '' ? ('movie.php?imdb=' . rawurlencode($imdb)) : '#';
    }
}

if (!function_exists('bm_search_norm_local')) {
    function bm_search_norm_local($m) {
        $m['source_archive'] = 'local';
        $m['source_label'] = 'آرشیو ۲';
        $m['detail_url'] = bm_search_local_movie_url($m);
        $m['poster'] = '';
        $m['imdb_rate'] = isset($m['imdb_rate']) ? $m['imdb_rate'] : (isset($m['rating']) ? $m['rating'] : 0);
        $m['type'] = (isset($m['type']) && strtolower((string)$m['type']) === 'movie') ? 'movie' : ((isset($m['type']) && stripos((string)$m['type'], 'series') !== false) ? 'series' : (isset($m['type']) ? $m['type'] : 'movie'));
        return $m;
    }
}

if (!function_exists('bm_search_norm_arc1')) {
    function bm_search_norm_arc1($item) {
        $detailId = '';
        foreach (array('detail_id','external_id','source_key','slug','id') as $k) {
            if (!empty($item[$k])) { $detailId = (string)$item[$k]; break; }
        }
        $title = isset($item['title']) ? $item['title'] : '';
        return array(
            'source_archive' => 'arc1',
            'source_label' => 'آرشیو ۱',
            'id' => $detailId,
            'imdb_code' => '',
            'title' => $title,
            'title_fa' => isset($item['title_fa']) ? $item['title_fa'] : $title,
            'year' => isset($item['year']) ? $item['year'] : '',
            'type' => isset($item['type']) ? bm_search_normalize_type($item['type']) : 'movie',
            'poster' => isset($item['poster']) ? $item['poster'] : '',
            'imdb_rate' => isset($item['rating']) ? $item['rating'] : (isset($item['imdb_rate']) ? $item['imdb_rate'] : 0),
            'dub_count' => !empty($item['has_dubbed']) ? 1 : 0,
            'soft_count' => !empty($item['has_subtitle']) ? 1 : 0,
            'has_dubbed' => !empty($item['has_dubbed']),
            'has_subtitle' => !empty($item['has_subtitle']),
            'detail_url' => $detailId !== '' ? ('/movie/arc1-' . rawurlencode($detailId)) : (isset($item['url']) ? $item['url'] : '#'),
        );
    }
}

if (!function_exists('bm_search_norm_arc3')) {
    function bm_search_norm_arc3($item) {
        $id = '';
        foreach (array('detail_id','source_post_id','slug','id','imdb_code') as $k) {
            if (!empty($item[$k])) { $id = $k === 'source_post_id' ? ('p' . (string)$item[$k]) : (string)$item[$k]; break; }
        }
        $title = isset($item['title']) ? $item['title'] : '';
        $titleFa = isset($item['title_fa']) && $item['title_fa'] !== '' ? $item['title_fa'] : $title;
        return array(
            'source_archive' => 'arc3',
            'source_label' => 'آرشیو ۳',
            'id' => $id,
            'imdb_code' => isset($item['imdb_code']) ? (string)$item['imdb_code'] : '',
            'title' => $title,
            'title_fa' => $titleFa,
            'year' => isset($item['year']) ? $item['year'] : '',
            'type' => isset($item['type']) ? bm_search_normalize_type($item['type']) : 'movie',
            'poster' => isset($item['poster']) ? $item['poster'] : '',
            'imdb_rate' => isset($item['rating']) ? $item['rating'] : (isset($item['imdb_rate']) ? $item['imdb_rate'] : 0),
            'age_rate' => isset($item['age_rate']) ? $item['age_rate'] : '',
            'dub_count' => !empty($item['has_dubbed']) ? 1 : 0,
            'soft_count' => !empty($item['has_subtitle']) ? 1 : 0,
            'has_dubbed' => !empty($item['has_dubbed']),
            'has_subtitle' => !empty($item['has_subtitle']),
            'detail_url' => $id !== '' ? ('/movie/arc3-' . rawurlencode($id)) : (isset($item['url']) ? $item['url'] : '#'),
        );
    }
}

if (!function_exists('bm_search_norm_arc4')) {
    function bm_search_norm_arc4($item) {
        $id = '';
        foreach (array('detail_id','source_post_id','slug','id','imdb_code') as $k) {
            if (!empty($item[$k])) { $id = $k === 'source_post_id' ? ('p' . (string)$item[$k]) : (string)$item[$k]; break; }
        }
        $title = isset($item['title']) ? $item['title'] : '';
        $titleFa = isset($item['title_fa']) && $item['title_fa'] !== '' ? $item['title_fa'] : $title;
        return array(
            'source_archive' => 'arc4',
            'source_label' => 'آرشیو ۴',
            'id' => $id,
            'imdb_code' => isset($item['imdb_code']) ? (string)$item['imdb_code'] : '',
            'title' => $title,
            'title_fa' => $titleFa,
            'year' => isset($item['year']) ? $item['year'] : '',
            'type' => isset($item['type']) ? bm_search_normalize_type($item['type']) : 'movie',
            'poster' => isset($item['poster']) ? $item['poster'] : '',
            'imdb_rate' => isset($item['rating']) ? $item['rating'] : (isset($item['imdb_rate']) ? $item['imdb_rate'] : 0),
            'age_rate' => isset($item['age_rate']) ? $item['age_rate'] : '',
            'dub_count' => !empty($item['has_dubbed']) ? 1 : 0,
            'soft_count' => !empty($item['has_subtitle']) ? 1 : 0,
            'has_dubbed' => !empty($item['has_dubbed']),
            'has_subtitle' => !empty($item['has_subtitle']),
            'detail_url' => $id !== '' ? ('/movie/arc4-' . rawurlencode($id)) : (isset($item['url']) ? $item['url'] : '#'),
        );
    }
}

if (!function_exists('bm_search_fetch_arc1')) {
    function bm_search_fetch_arc1($params, &$hasMore, &$errors) {
        $hasMore = false;
        $items = array();
        $lib = __DIR__ . '/includes/api2_lib.php';
        if (!is_file($lib)) return $items;
        try {
            if (!function_exists('advancedSearch')) require_once $lib;
            $q = trim((string)$params['q']);
            // آرشیو ۱ فیلد مستقل بازیگر/کارگردان ندارد؛ در صورت خالی بودن نام اثر،
            // عبارت بازیگر یا کارگردان را به سرچ متنی واقعی منبع می‌فرستیم.
            if ($q === '') {
                $q = trim((string)$params['actor']);
                if ($q === '') $q = trim((string)$params['director']);
            }
            $sortMap = array(
                'newest'=>'newest', 'modified'=>'modified', 'popular'=>'popular',
                'rating_desc'=>'imdb_rate', 'year_desc'=>'release',
                'year_asc'=>'release', 'title_asc'=>'newest'
            );
            $apiParams = array(
                's' => $q,
                'type' => $params['type'] === 'all' ? 'both' : $params['type'],
                'genre' => $params['genre'],
                'genre_id' => (int)$params['genreId'],
                'sortby' => $sortMap[$params['sort']] ?? 'newest',
                'imdbrate' => is_numeric($params['rating']) ? (int)$params['rating'] : 0,
                'country' => $params['country'],
                'country_id' => (int)$params['countryId'],
                'min_year' => is_numeric($params['fromYear']) ? (int)$params['fromYear'] : 1800,
                'max_year' => is_numeric($params['toYear']) ? (int)$params['toYear'] : (int)date('Y'),
                'page' => (int)$params['page'],
                'dubbed' => !empty($params['dubbed']) ? 1 : 0,
                'subtitle' => !empty($params['subtitle']) ? 1 : 0,
                'suggest' => !empty($params['suggest']) ? 1 : 0,
            );
            $raw = advancedSearch($apiParams);
            foreach ((array)$raw as $it) $items[] = bm_search_norm_arc1($it);
            if ($params['sort'] === 'year_asc') {
                usort($items, fn($a,$b) => (int)($a['year'] ?? 0) <=> (int)($b['year'] ?? 0));
            } elseif ($params['sort'] === 'title_asc') {
                usort($items, fn($a,$b) => strnatcasecmp((string)($a['title'] ?? ''), (string)($b['title'] ?? '')));
            } elseif ($params['sort'] === 'rating_desc') {
                usort($items, fn($a,$b) => (float)($b['imdb_rate'] ?? 0) <=> (float)($a['imdb_rate'] ?? 0));
            }
            $hasMore = count($items) >= 20;
        } catch (Throwable $e) {
            error_log('search archive1 [' . (function_exists('bm_security_request_id') ? bm_security_request_id() : '-') . ']: ' . $e->getMessage());
            $errors[] = 'Archive 1 is temporarily unavailable.';
        }
        return $items;
    }
}

if (!function_exists('bm_search_fetch_arc3')) {
    function bm_search_fetch_arc3($params, &$hasMore, &$errors) {
        $hasMore = false;
        $items = array();
        $lib = __DIR__ . '/includes/api6_lib.php';
        if (!is_file($lib)) return $items;
        try {
            if (!function_exists('api6_search')) require_once $lib;
            $q = trim((string)$params['q']);
            $exactYear = '';
            if ($params['fromYear'] !== '' && $params['fromYear'] === $params['toYear']) $exactYear = $params['fromYear'];
            $sortMap = array(
                'newest'=>'newest', 'modified'=>'newest', 'popular'=>'newest',
                'rating_desc'=>'rating', 'year_desc'=>'year_desc',
                'year_asc'=>'year_asc', 'title_asc'=>'title'
            );
            $apiParams = array(
                's' => $q,
                'type' => $params['type'] === 'all' ? 'all' : $params['type'],
                'genre' => trim((string)$params['genre']),
                'country' => trim((string)$params['country']),
                'director' => trim((string)$params['director']),
                'actor' => trim((string)$params['actor']),
                'sort' => $sortMap[$params['sort']] ?? 'newest',
                'yearse' => $exactYear,
                'fromYear' => is_numeric($params['fromYear']) ? (string)$params['fromYear'] : '',
                'toYear' => is_numeric($params['toYear']) ? (string)$params['toYear'] : '',
                'rates' => is_numeric($params['rating']) ? (string)$params['rating'] : '',
                'score' => '',
                'dubbed' => !empty($params['dubbed']),
                'subtitle' => !empty($params['subtitle']),
                'playonline' => false,
                'page' => (int)$params['page'],
            );
            $raw = api6_search($apiParams);
            foreach ((array)($raw['movies'] ?? array()) as $it) $items[] = bm_search_norm_arc3($it);
            $hasMore = !empty($raw['has_more']);

            // مرتب‌سازی‌های صعودی/عنوان روی همان صفحه نتیجه، چون فرم اصلی آرشیو ۳
            // این دو حالت را به‌صورت مستقیم ارائه نمی‌کند.
            if ($params['sort'] === 'year_asc') {
                usort($items, fn($a,$b) => (int)($a['year'] ?? 0) <=> (int)($b['year'] ?? 0));
            } elseif ($params['sort'] === 'title_asc') {
                usort($items, fn($a,$b) => strnatcasecmp((string)($a['title'] ?? ''), (string)($b['title'] ?? '')));
            } elseif ($params['sort'] === 'rating_desc') {
                usort($items, fn($a,$b) => (float)($b['imdb_rate'] ?? 0) <=> (float)($a['imdb_rate'] ?? 0));
            }
        } catch (Throwable $e) {
            error_log('search archive3 [' . (function_exists('bm_security_request_id') ? bm_security_request_id() : '-') . ']: ' . $e->getMessage());
            $errors[] = 'Archive 3 is temporarily unavailable.';
        }
        return $items;
    }
}

if (!function_exists('bm_search_fetch_arc4')) {
    function bm_search_fetch_arc4($params, &$hasMore, &$errors) {
        $hasMore = false;
        $items = array();
        $lib = __DIR__ . '/includes/api4_lib.php';
        if (!is_file($lib)) return $items;
        try {
            if (!function_exists('api4_search')) require_once $lib;
            $q = trim((string)$params['q']);
            $exactYear = '';
            if ($params['fromYear'] !== '' && $params['fromYear'] === $params['toYear']) $exactYear = $params['fromYear'];
            $sortMap = array(
                'newest'=>'newest', 'modified'=>'newest', 'popular'=>'newest',
                'rating_desc'=>'rating', 'year_desc'=>'year_desc',
                'year_asc'=>'year_asc', 'title_asc'=>'title'
            );
            $apiParams = array(
                's' => $q,
                'type' => $params['type'] === 'all' ? 'all' : $params['type'],
                'genre' => trim((string)$params['genre']),
                'country' => trim((string)$params['country']),
                'director' => trim((string)$params['director']),
                'actor' => trim((string)$params['actor']),
                'sort' => $sortMap[$params['sort']] ?? 'newest',
                'yearse' => $exactYear,
                'fromYear' => is_numeric($params['fromYear']) ? (string)$params['fromYear'] : '',
                'toYear' => is_numeric($params['toYear']) ? (string)$params['toYear'] : '',
                'rates' => is_numeric($params['rating']) ? (string)$params['rating'] : '',
                'score' => '',
                'dubbed' => !empty($params['dubbed']),
                'subtitle' => !empty($params['subtitle']),
                'playonline' => false,
                'page' => (int)$params['page'],
            );
            $raw = api4_search($apiParams);
            foreach ((array)($raw['movies'] ?? array()) as $it) $items[] = bm_search_norm_arc4($it);
            $hasMore = !empty($raw['has_more']);

            // مرتب‌سازی‌های صعودی/عنوان روی همان صفحه نتیجه، چون فرم اصلی آرشیو ۴
            // این دو حالت را به‌صورت مستقیم ارائه نمی‌کند.
            if ($params['sort'] === 'year_asc') {
                usort($items, fn($a,$b) => (int)($a['year'] ?? 0) <=> (int)($b['year'] ?? 0));
            } elseif ($params['sort'] === 'title_asc') {
                usort($items, fn($a,$b) => strnatcasecmp((string)($a['title'] ?? ''), (string)($b['title'] ?? '')));
            } elseif ($params['sort'] === 'rating_desc') {
                usort($items, fn($a,$b) => (float)($b['imdb_rate'] ?? 0) <=> (float)($a['imdb_rate'] ?? 0));
            }
        } catch (Throwable $e) {
            error_log('search archive4 [' . (function_exists('bm_security_request_id') ? bm_security_request_id() : '-') . ']: ' . $e->getMessage());
            $errors[] = 'Archive 4 is temporarily unavailable.';
        }
        return $items;
    }
}

$searchParams = array(
    'q'=>$q, 'genre'=>$genre, 'genreId'=>$genreId, 'director'=>$director,
    'country'=>$country, 'countryId'=>$countryId, 'actor'=>$actor,
    'type'=>$type, 'year'=>$year, 'fromYear'=>$fromYear, 'toYear'=>$toYear,
    'rating'=>$rating, 'sort'=>$sort, 'dubbed'=>$dubbed, 'subtitle'=>$subtitle,
    'suggest'=>$suggest, 'page'=>$page
);

$movies = array();
$total = 0;
$lastPage = 1;
$externalErrors = array();
$sourceCounts = array('local' => 0, 'arc1' => 0, 'arc3' => 0, 'arc4' => 0);
$hasMoreArc1 = false;
$hasMoreArc3 = false;
$hasMoreArc4 = false;
$localTotal = 0;
$localLastPage = 1;
$userWatchlistSet = array();
$isLoggedIn = false;

// ساخت کوئری شرطی آرشیو ۲
$where = array();
$params = array();

if(!empty($q)) {
    $where[] = "(title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ? OR actors LIKE ? OR director LIKE ?)";
    $searchTerm = "%{$q}%";
    $params[] = $searchTerm; $params[] = $searchTerm; $params[] = $searchTerm;
    $params[] = $searchTerm; $params[] = $searchTerm;
}
if(!empty($genre)) { $where[] = "genres LIKE ?"; $params[] = "%{$genre}%"; }
if(!empty($director)) { $where[] = "director LIKE ?"; $params[] = "%{$director}%"; }
if(!empty($country)) { $where[] = "country LIKE ?"; $params[] = "%{$country}%"; }
if(!empty($actor)) { $where[] = "actors LIKE ?"; $params[] = "%{$actor}%"; }
if($type !== 'all') {
    if($type === 'movie') $where[] = "type = 'movie'";
    elseif($type === 'series') $where[] = "type LIKE '%Series%'";
}
if($fromYear !== '' && is_numeric($fromYear)) { $where[] = "year >= ?"; $params[] = (int)$fromYear; }
if($toYear !== '' && is_numeric($toYear)) { $where[] = "year <= ?"; $params[] = (int)$toYear; }
if($rating !== '' && is_numeric($rating)) { $where[] = "imdb_rate >= ?"; $params[] = (float)$rating; }
if($dubbed) $where[] = "EXISTS (SELECT 1 FROM dubbed_links WHERE movie_id = m.id)";
if($subtitle) $where[] = "EXISTS (SELECT 1 FROM softsub_links WHERE movie_id = m.id)";

switch($sort) {
    case 'year_asc': $orderBy = "year ASC, id ASC"; break;
    case 'rating_desc': $orderBy = "imdb_rate DESC, imdb_votes DESC"; break;
    case 'title_asc': $orderBy = "title ASC"; break;
    case 'popular': $orderBy = "imdb_votes DESC, imdb_rate DESC, id DESC"; break;
    case 'modified': $orderBy = "id DESC"; break;
    default: $orderBy = "year DESC, id DESC"; break;
}

if (!$onlyArchive1ForSuggested && (($archive === 'all' && $archiveEnabled['local']) || $archive === 'local')) {
    try {
        $whereSql = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        $countSql = "SELECT COUNT(*) FROM movies m $whereSql";
        $stmt = $pdo->prepare($countSql);
        $stmt->execute($params);
        $localTotal = (int)$stmt->fetchColumn();
        $localLastPage = max(1, (int)ceil($localTotal / $perPage));

        $sql = "SELECT m.*, 
            (SELECT COUNT(*) FROM softsub_links WHERE movie_id = m.id) as soft_count,
            (SELECT COUNT(*) FROM dubbed_links WHERE movie_id = m.id) as dub_count
            FROM movies m $whereSql 
            ORDER BY $orderBy 
            LIMIT ? OFFSET ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($params, array($perPage, $offset)));
        $localMovies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($localMovies as $lm) $movies[] = bm_search_norm_local($lm);
        $sourceCounts['local'] = count($localMovies);
    } catch (Throwable $e) {
        $externalErrors[] = 'Archive 2: ' . $e->getMessage();
    }
}

if (($archive === 'all' && $archiveEnabled['arc1']) || $archive === 'arc1') {
    $arc1Movies = bm_search_fetch_arc1($searchParams, $hasMoreArc1, $externalErrors);
    $sourceCounts['arc1'] = count($arc1Movies);
    $movies = array_merge($movies, $arc1Movies);
}

if (!$onlyArchive1ForSuggested && (($archive === 'all' && $archiveEnabled['arc3']) || $archive === 'arc3')) {
    $arc3Movies = bm_search_fetch_arc3($searchParams, $hasMoreArc3, $externalErrors);
    $sourceCounts['arc3'] = count($arc3Movies);
    $movies = array_merge($movies, $arc3Movies);
}

if (!$onlyArchive1ForSuggested && (($archive === 'all' && $archiveEnabled['arc4']) || $archive === 'arc4')) {
    $arc4Movies = bm_search_fetch_arc4($searchParams, $hasMoreArc4, $externalErrors);
    $sourceCounts['arc4'] = count($arc4Movies);
    $movies = array_merge($movies, $arc4Movies);
}

$total = ($archive === 'local') ? $localTotal : count($movies);
$lastPage = $archive === 'local' ? $localLastPage : max(1, $page + (($hasMoreArc1 || $hasMoreArc3 || $hasMoreArc4) ? 1 : 0));
if ($archive === 'all') $lastPage = max($lastPage, $localLastPage > $page ? $page + 1 : 1);

// واچ لیست کاربر لاگین شده فقط برای آرشیو ۲
if($currentUser) {
    $isLoggedIn = true;
    $userId = (int)$currentUser['id'];
    $localImdbCodes = array();
    foreach ($movies as $m) {
        if (($m['source_archive'] ?? 'local') === 'local' && !empty($m['imdb_code'])) $localImdbCodes[] = $m['imdb_code'];
    }
    $localImdbCodes = array_values(array_unique($localImdbCodes));
    if(!empty($localImdbCodes)) {
        $placeholders = implode(',', array_fill(0, count($localImdbCodes), '?'));
        $stmt = $pdo->prepare("SELECT m.imdb_code FROM watchlist w JOIN movies m ON w.movie_id = m.id WHERE w.user_id = ? AND m.imdb_code IN ($placeholders)");
        $stmt->execute(array_merge(array($userId), $localImdbCodes));
        $userWatchlistSet = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));
    }
}

// گزینه‌های واقعی فیلتر برای هر سه آرشیو
if (!function_exists('bm_search_option_key')) {
    function bm_search_option_key($value) {
        $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = str_replace(array("\u{200c}","\u{200f}","\u{00a0}",'ي','ك','ۀ','ة'), array(' ',' ',' ','ی','ک','ه','ه'), $value);
        $value = preg_replace('/\s+/u', ' ', trim($value));
        return function_exists('mb_strtolower') ? mb_strtolower((string)$value, 'UTF-8') : strtolower((string)$value);
    }
}
if (!function_exists('bm_search_merge_option')) {
    function bm_search_merge_option(&$map, $label, $archiveName) {
        $label = preg_replace('/\s+/u', ' ', trim((string)$label));
        if ($label === '') return;
        $key = bm_search_option_key($label);
        if ($key === '') return;
        if (!isset($map[$key])) $map[$key] = array('label'=>$label, 'archives'=>array());
        if (!in_array($archiveName, $map[$key]['archives'], true)) $map[$key]['archives'][] = $archiveName;
    }
}

$localGenres = array();
$localCountries = array();
try {
    $localGenres = $pdo->query("
        SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(src.normalized, ',', nums.n), ',', -1)) AS genre
        FROM (
            SELECT REPLACE(REPLACE(REPLACE(genres, '،', ','), '|', ','), ';', ',') AS normalized
            FROM movies
            WHERE genres IS NOT NULL AND TRIM(genres) <> ''
        ) src
        CROSS JOIN (
            SELECT 1 n UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5
            UNION ALL SELECT 6 UNION ALL SELECT 7 UNION ALL SELECT 8 UNION ALL SELECT 9 UNION ALL SELECT 10
            UNION ALL SELECT 11 UNION ALL SELECT 12 UNION ALL SELECT 13 UNION ALL SELECT 14
        ) nums
        WHERE nums.n <= 1 + LENGTH(src.normalized) - LENGTH(REPLACE(src.normalized, ',', ''))
        HAVING genre <> '' AND genre IS NOT NULL
        ORDER BY genre
    ")->fetchAll(PDO::FETCH_COLUMN);
    $localCountries = $pdo->query("
        SELECT DISTINCT TRIM(country) AS country
        FROM movies
        WHERE country IS NOT NULL AND country != '' AND LENGTH(TRIM(country)) > 1
        ORDER BY country
    ")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    $localGenres = array();
    $localCountries = array();
}

$arc1Options = array('genres'=>array(),'countries'=>array());
if ($archiveEnabled['arc1']) {
    try {
        if (!function_exists('api2_search_options')) require_once __DIR__ . '/includes/api2_lib.php';
        $arc1Options = api2_search_options();
    } catch (Throwable $e) {}
}
$arc3Options = array('genres'=>array());
if ($archiveEnabled['arc3']) {
    try {
        if (!function_exists('api6_search_options')) require_once __DIR__ . '/includes/api6_lib.php';
        $arc3Options = api6_search_options();
    } catch (Throwable $e) {}
}
$arc4Options = array('genres'=>array());
if ($archiveEnabled['arc4']) {
    try {
        if (!function_exists('api4_search_options')) require_once __DIR__ . '/includes/api4_lib.php';
        $arc4Options = api4_search_options();
    } catch (Throwable $e) {}
}

$genreOptionMap = array();
$countryOptionMap = array();
foreach ($localGenres as $label) bm_search_merge_option($genreOptionMap, $label, 'local');
foreach ($localCountries as $label) bm_search_merge_option($countryOptionMap, $label, 'local');
foreach (($arc1Options['genres'] ?? array()) as $row) bm_search_merge_option($genreOptionMap, $row['label'] ?? '', 'arc1');
foreach (($arc1Options['countries'] ?? array()) as $row) bm_search_merge_option($countryOptionMap, $row['label'] ?? '', 'arc1');
foreach (($arc3Options['genres'] ?? array()) as $row) { if (($row['advanced_form_supported'] ?? true) !== false) bm_search_merge_option($genreOptionMap, $row['value'] ?? ($row['label'] ?? ''), 'arc3'); }
foreach (($arc4Options['genres'] ?? array()) as $row) { if (($row['advanced_form_supported'] ?? true) !== false) bm_search_merge_option($genreOptionMap, $row['value'] ?? ($row['label'] ?? ''), 'arc4'); }

$genreOptionRows = array_values($genreOptionMap);
$countryOptionRows = array_values($countryOptionMap);
usort($genreOptionRows, fn($a,$b) => strnatcasecmp((string)$a['label'], (string)$b['label']));
usort($countryOptionRows, fn($a,$b) => strnatcasecmp((string)$a['label'], (string)$b['label']));

$years = range($currentYear, 1900);

$advancedFilterCount = 0;
$advancedFilterCount += $archive !== 'all' ? 1 : 0;
$advancedFilterCount += $q !== '' ? 1 : 0;
$advancedFilterCount += $genre !== '' ? 1 : 0;
$advancedFilterCount += $country !== '' ? 1 : 0;
$advancedFilterCount += $actor !== '' ? 1 : 0;
$advancedFilterCount += $director !== '' ? 1 : 0;
$advancedFilterCount += $fromYear !== '' ? 1 : 0;
$advancedFilterCount += ($toYear !== '' && $toYear !== $fromYear) ? 1 : 0;
$advancedFilterCount += $rating !== '' ? 1 : 0;
$advancedFilterCount += $dubbed ? 1 : 0;
$advancedFilterCount += $subtitle ? 1 : 0;
$advancedFilterCount += $suggest ? 1 : 0;
$advancedFilterCount += $type !== 'all' ? 1 : 0;
$advancedFilterCount += $sort !== 'newest' ? 1 : 0;

// ساخت عنوان صفحه
$searchTerms = [];
if($archive !== 'all') $searchTerms[] = $archiveLabels[$archive];
if(!empty($q)) $searchTerms[] = htmlspecialchars($q);
if(!empty($genre)) $searchTerms[] = "ژانر: $genre";
if(!empty($director)) $searchTerms[] = "کارگردان: $director";
if(!empty($country)) $searchTerms[] = "کشور: $country";
if(!empty($actor)) $searchTerms[] = "بازیگر: $actor";
if($type !== 'all') $searchTerms[] = $type === 'movie' ? 'فیلم' : 'سریال';
if($fromYear !== '' && $toYear !== '') $searchTerms[] = $fromYear === $toYear ? "سال: $fromYear" : "سال: $fromYear تا $toYear";
elseif($fromYear !== '') $searchTerms[] = "از سال: $fromYear";
elseif($toYear !== '') $searchTerms[] = "تا سال: $toYear";
if($rating !== '') $searchTerms[] = "امتیاز: {$rating}+";
if($dubbed) $searchTerms[] = 'دوبله فارسی';
if($subtitle) $searchTerms[] = 'زیرنویس فارسی';
if($suggest) $searchTerms[] = 'پیشنهاد ویژه';
$searchTitle = !empty($searchTerms) ? implode(' | ', $searchTerms) : 'همه فیلم‌ها و سریال‌ها';

if (!function_exists('escapeHtml')) {
    function escapeHtml($str) { return htmlspecialchars($str ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
}
function buildSearchUrlWithout($keys) {
    $query = $_GET;
    foreach((array)$keys as $key) {
        unset($query[$key]);
    }
    unset($query['page']);
    return '/search' . (!empty($query) ? '?' . http_build_query($query) : '');
}
?>
<!DOCTYPE html>
<html lang="<?= $langAttr ?>" dir="<?= $dir ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?= $userLang === 'fa' ? 'جستجو' : 'Search' ?> - <?= strip_tags($searchTitle) ?> | BankMovie</title>
    <style>
        /* ========== فونت و متغیرها ========== */
        @font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}
        *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
        :root{--bg-primary:#08090d;--bg-secondary:#101116;--bg-tertiary:#171922;--bg-card:#0e1017;--bg-card-hover:#151926;--accent:<?= e($currentTheme['primary']) ?>;--accent-rgb:<?= e($currentThemeRgbCss) ?>;--accent-dark:<?= e($currentTheme['primary']) ?>cc;--accent-glow:rgba(var(--accent-rgb),.14);--text-primary:#fff;--text-secondary:#a4a8b6;--text-tertiary:#6e7384;--border-subtle:rgba(255,255,255,.075);--border-accent:rgba(var(--accent-rgb),.28);--gradient-hero:linear-gradient(135deg,#fff,var(--accent));--gradient-donate:linear-gradient(135deg,#ff3366,#ff6633);--shadow-soft:0 18px 50px rgba(0,0,0,.38)}
        html{scroll-behavior:smooth}
        body{min-height:100vh;background:radial-gradient(circle at 18% -10%,rgba(var(--accent-rgb),.16),transparent 34%),radial-gradient(circle at 88% 12%,rgba(59,130,246,.08),transparent 36%),#08090d;color:var(--text-primary);font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,Segoe UI,sans-serif;overflow-x:hidden;padding-bottom:104px}
        ::-webkit-scrollbar{width:7px;height:7px}::-webkit-scrollbar-track{background:#101116}::-webkit-scrollbar-thumb{background:var(--accent);border-radius:10px}svg{display:block}

        .header{position:sticky;top:0;z-index:100;background:rgba(8,9,13,.74);border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(22px);transition:.22s ease}.header.header-solid{background:rgba(8,9,13,.94);box-shadow:0 16px 34px rgba(0,0,0,.24)}.header-inner{max-width:1400px;height:68px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:18px}.logo{display:inline-flex;align-items:center;gap:10px;text-decoration:none;color:#fff;min-width:0}.logo-icon{width:34px;height:34px;filter:drop-shadow(0 0 14px rgba(var(--accent-rgb),.28))}.logo-text{font-size:18px;font-weight:900;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent;letter-spacing:.2px}.desktop-nav{display:flex;align-items:center;gap:8px;flex:1;justify-content:center}.desktop-nav-item{display:inline-flex;align-items:center;gap:8px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:760;padding:10px 14px;border-radius:999px;border:1px solid transparent;transition:.2s ease}.desktop-nav-item svg{width:17px;height:17px;stroke:currentColor}.desktop-nav-item:hover,.desktop-nav-item.active{color:#fff;background:rgba(255,255,255,.055);border-color:rgba(255,255,255,.08)}.desktop-nav-item.active{box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18);color:var(--accent)}.header-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}.menu-btn,.notif-bell,.auth-trigger,.user-trigger,.donate-btn{border:none;cursor:pointer;color:#fff;transition:.2s ease}.menu-btn,.notif-bell{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;position:relative}.menu-btn svg,.notif-bell svg{width:20px;height:20px}.menu-btn:hover,.notif-bell:hover{background:var(--accent-glow);border-color:var(--border-accent);color:var(--accent)}.notif-badge{position:absolute;top:7px;right:9px;width:8px;height:8px;background:#ff3b5c;border-radius:50%;box-shadow:0 0 0 3px rgba(255,59,92,.15)}.donate-btn{display:inline-flex;align-items:center;gap:7px;background:var(--gradient-donate);border-radius:999px;padding:10px 16px;font-size:12px;font-weight:850;box-shadow:0 12px 28px rgba(255,51,102,.14)}.donate-btn:hover{transform:translateY(-1px);box-shadow:0 16px 32px rgba(255,51,102,.24)}.auth-dropdown{position:relative}.auth-trigger,.user-trigger{height:42px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.045);border:1px solid var(--border-subtle);border-radius:999px;padding:0 13px;font-size:12px;font-weight:760}.auth-trigger svg,.user-trigger svg{width:17px;height:17px}.auth-dropdown:hover .auth-menu{opacity:1;visibility:visible;transform:translateY(6px)}.auth-menu{position:absolute;top:100%;left:0;min-width:190px;background:rgba(17,19,28,.96);border:1px solid var(--border-subtle);border-radius:18px;padding:8px;box-shadow:var(--shadow-soft);backdrop-filter:blur(18px);opacity:0;visibility:hidden;transform:translateY(0);transition:.2s ease;z-index:120}.auth-menu a{display:flex;align-items:center;gap:9px;text-decoration:none;color:var(--text-secondary);font-size:12px;font-weight:760;padding:10px 12px;border-radius:13px}.auth-menu a:hover{background:var(--accent-glow);color:var(--accent)}.auth-menu svg{width:16px;height:16px}
        .menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,.68);backdrop-filter:blur(8px);z-index:180;opacity:0;visibility:hidden;transition:.22s ease}.menu-overlay.active{opacity:1;visibility:visible}.sidebar-menu{position:fixed;top:0;bottom:0;right:0;width:min(330px,88vw);background:rgba(13,15,23,.96);border-left:1px solid var(--border-subtle);z-index:190;transform:translateX(105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px);display:flex;flex-direction:column}.sidebar-menu.open{transform:translateX(0)}[dir="ltr"] .sidebar-menu{right:auto;left:0;transform:translateX(-105%)}[dir="ltr"] .sidebar-menu.open{transform:translateX(0)}.sidebar-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.sidebar-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.sidebar-close svg{width:18px;height:18px}.sidebar-user{margin:18px 18px 10px;padding:18px;border:1px solid var(--border-subtle);border-radius:24px;background:linear-gradient(145deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.035));text-align:center}.sidebar-avatar{width:58px;height:58px;border-radius:50%;margin:0 auto 10px;background:rgba(var(--accent-rgb),.12);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent)}.sidebar-avatar svg{width:28px;height:28px}.sidebar-username{font-weight:900}.sidebar-userrole{margin-top:3px;color:var(--text-tertiary);font-size:12px}.sidebar-nav,.sidebar-footer{padding:10px 14px;display:flex;flex-direction:column;gap:6px}.sidebar-nav{flex:1}.sidebar-item{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:780;padding:13px 14px;border-radius:16px;transition:.18s}.sidebar-item:hover,.sidebar-item.active{background:var(--accent-glow);color:var(--accent)}.sidebar-item svg{width:19px;height:19px}.notif-sidebar{position:fixed;top:0;bottom:0;left:0;width:min(380px,92vw);background:rgba(13,15,23,.97);border-right:1px solid var(--border-subtle);z-index:185;transform:translateX(-105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px)}[dir="ltr"] .notif-sidebar{left:auto;right:0;transform:translateX(105%);border-right:none;border-left:1px solid var(--border-subtle)}.notif-sidebar.open{transform:translateX(0)}.notif-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.notif-header h3{font-size:18px;color:var(--accent)}.notif-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.notif-close svg{width:18px;height:18px}.notif-list{padding:16px;display:flex;flex-direction:column;gap:10px}.notif-item{padding:14px;border-radius:18px;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle)}.notif-message{font-size:13px;line-height:1.7;color:#fff}.notif-date{margin-top:8px;color:var(--text-tertiary);font-size:11px}
        .bottom-nav{position:fixed;left:50%;bottom:calc(10px + env(safe-area-inset-bottom));transform:translateX(-50%);width:min(520px,calc(100% - 28px));height:74px;background:linear-gradient(180deg,rgba(27,31,45,.86),rgba(13,15,23,.92));border:1px solid rgba(255,255,255,.1);border-radius:34px;z-index:95;display:grid;grid-template-columns:repeat(3,1fr);align-items:center;padding:6px;box-shadow:0 18px 48px rgba(0,0,0,.44),inset 0 1px 0 rgba(255,255,255,.08);backdrop-filter:blur(22px);transition:.26s ease}.bottom-nav.nav-hidden{transform:translate(-50%,calc(100% + 28px));opacity:0;pointer-events:none}.bottom-nav.nav-compact{height:66px;opacity:.96}.nav-item{height:100%;border-radius:28px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;text-decoration:none;color:var(--text-secondary);font-size:10px;font-weight:760;transition:.2s}.nav-item svg{width:22px;height:22px;stroke:currentColor}.nav-item.active{color:var(--accent);background:linear-gradient(180deg,rgba(var(--accent-rgb),.18),rgba(var(--accent-rgb),.08));box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18)}.nav-label{font-size:10px;color:inherit}.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);z-index:10020;align-items:center;justify-content:center;padding:22px}.modal-content{background:linear-gradient(180deg,#151823,#0f1118);border:1px solid var(--border-subtle);border-radius:30px;max-width:420px;width:100%;padding:26px;text-align:center;box-shadow:var(--shadow-soft)}.btn{border:none;cursor:pointer;text-decoration:none}.btn-primary{height:46px;border-radius:999px;background:var(--accent);color:#050505;font-weight:900;display:inline-flex;align-items:center;justify-content:center}

        /* بخش جستجو */
        .search-section { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .search-box { background: var(--bg-secondary); border-radius: 60px; border: 1px solid var(--border-subtle); display: flex; align-items: center; padding: 4px; transition: 0.2s; margin-bottom: 20px; }
        .search-box:focus-within { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-glow); }
        .search-input { flex: 1; background: transparent; border: none; padding: 14px 20px; color: var(--text-primary); font-size: 14px; outline: none; }
        .search-btn { background: var(--accent); border: none; border-radius: 60px; padding: 10px 24px; color: #000; font-weight: 600; cursor: pointer; transition: 0.2s; display: flex; align-items: center; gap: 8px; font-size: 13px; }
        .search-btn:hover { background: var(--accent-dark); transform: scale(0.98); }
        .archive-search-tabs{display:flex;gap:8px;flex-wrap:wrap;justify-content:center;margin:0 0 18px}
        .archive-search-tab{display:inline-flex;align-items:center;justify-content:center;padding:9px 16px;border-radius:999px;text-decoration:none;color:var(--text-secondary);font-size:12px;font-weight:850;background:rgba(255,255,255,.045);border:1px solid var(--border-subtle);transition:.2s}
        .archive-search-tab:hover{color:#fff;border-color:var(--border-accent);background:var(--accent-glow)}
        .archive-search-tab.active{color:#050505;background:var(--accent);border-color:var(--accent);box-shadow:0 10px 26px rgba(var(--accent-rgb),.18)}
        @media(max-width:540px){.archive-search-tabs{gap:6px;justify-content:flex-start;overflow-x:auto;padding-bottom:3px}.archive-search-tab{padding:7px 11px;font-size:11px;white-space:nowrap}}

        /* نوار ابزار فیلتر (دکمه مودال) */
        .filter-toolbar { display: flex; justify-content: flex-end; margin-bottom: 20px; }
        .filter-modal-btn { background: rgba(255,255,255,0.08); border: 1px solid var(--border-subtle); padding: 8px 20px; border-radius: 40px; color: var(--text-primary); font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; transition: 0.2s; }
        .filter-modal-btn:hover { background: var(--accent-glow); border-color: var(--accent); }

        /* مودال فیلتر */
        .filter-modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.9); backdrop-filter: blur(12px); z-index: 10002; align-items: center; justify-content: center; }
        .filter-modal.active { display: flex; }
        .filter-modal-content { background: var(--bg-secondary); border-radius: 32px; max-width: 600px; width: 90%; max-height: 85vh; overflow-y: auto; padding: 24px; border: 1px solid var(--border-accent); }
        .filter-modal-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
        .filter-modal-header h3 { color: var(--accent); font-size: 20px; display: flex; align-items: center; gap: 8px; }
        .filter-close { background: none; border: none; cursor: pointer; padding: 8px; }
        .filter-close svg { width: 24px; height: 24px; stroke: var(--text-primary); }
        .filter-group { margin-bottom: 20px; }
        .filter-group label { display: block; margin-bottom: 8px; color: var(--text-secondary); font-size: 13px; display: flex; align-items: center; gap: 6px; }
        .filter-group select, .filter-group input { width: 100%; padding: 12px; background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 20px; color: var(--text-primary); font-size: 14px; }
        .filter-group select:focus, .filter-group input:focus { outline: none; border-color: var(--accent); }
        .filter-actions { display: flex; gap: 12px; margin-top: 24px; }
        .apply-filters-btn { background: var(--accent); color: #000; border: none; padding: 12px 24px; border-radius: 40px; font-weight: bold; cursor: pointer; flex: 1; display: flex; align-items: center; justify-content: center; gap: 8px; }
        .reset-filters-btn { background: rgba(255,68,68,0.15); color: #ff8888; border: 1px solid rgba(255,68,68,0.3); padding: 12px 24px; border-radius: 40px; cursor: pointer; flex: 1; display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; }

        /* فیلترهای فعال (چیپ) */
        .active-filters { display: flex; flex-wrap: wrap; gap: 10px; margin-bottom: 20px; }
        .filter-chip { background: var(--accent-glow); border: 1px solid var(--border-accent); border-radius: 40px; padding: 6px 14px; font-size: 12px; display: inline-flex; align-items: center; gap: 8px; }
        .filter-chip a { color: var(--accent); text-decoration: none; font-weight: 600; margin-left: 4px; }
        .filter-chip svg { width: 14px; height: 14px; stroke: currentColor; }
        .clear-filters { background: rgba(255,68,68,0.15); color: #ff8888; border: 1px solid rgba(255,68,68,0.3); padding: 6px 14px; border-radius: 40px; text-decoration: none; font-size: 12px; display: inline-flex; align-items: center; gap: 6px; transition: 0.2s; }
        .clear-filters:hover { background: rgba(255,68,68,0.25); }

        /* صفحه عنوان */
        .page-header { padding: 0 20px; margin-bottom: 20px; }
        .page-header h1 { font-size: 28px; font-weight: 800; background: var(--gradient-hero); -webkit-background-clip: text; background-clip: text; color: transparent; }
        .page-header .count { color: var(--text-tertiary); font-size: 14px; margin-top: 6px; }
        .search-term { color: var(--accent); background: var(--accent-glow); padding: 2px 10px; border-radius: 20px; display: inline-block; }

        /* گرید فیلم‌ها */
        .movies-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; padding: 0 20px; max-width: 1400px; margin: 0 auto; }
        .grid-item { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 16px; overflow: hidden; cursor: pointer; transition: 0.2s; text-decoration: none; color: inherit; display: block; position: relative; }
        .grid-item:hover { transform: translateY(-4px); border-color: var(--border-accent); box-shadow: 0 10px 25px -10px rgba(0,0,0,0.5); }
        .grid-poster { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: var(--bg-tertiary); }
        .grid-info { padding: 10px 8px; }
        .grid-title-fa { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 3px; }
        .grid-title-en { font-size: 10px; color: var(--text-tertiary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 5px; }
        .grid-meta { display: flex; justify-content: space-between; align-items: center; font-size: 10px; color: var(--text-tertiary); }
        .grid-badge { font-size: 9px; padding: 2px 8px; border-radius: 20px; background: var(--accent-glow); color: var(--accent); }
        .watchlist-icon-grid { width: 28px; height: 28px; display: flex; align-items: center; justify-content: center; border-radius: 50%; cursor: pointer; background: rgba(0,0,0,0.5); transition: 0.2s; }
        .watchlist-icon-grid:hover { background: rgba(0,0,0,0.8); transform: scale(1.05); }
        .watchlist-icon-grid.active svg { fill: var(--accent); stroke: var(--accent); }
        .watchlist-icon-grid svg { width: 14px; height: 14px; stroke: currentColor; fill: none; stroke-width: 1.5; }

        /* صفحه‌بندی */
        .pagination { display: flex; justify-content: center; gap: 8px; margin: 40px 0; flex-wrap: wrap; }
        .page-link { background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: 40px; padding: 8px 16px; color: var(--text-primary); text-decoration: none; font-size: 13px; transition: 0.2s; display: inline-flex; align-items: center; gap: 6px; }
        .page-link:hover { border-color: var(--accent); background: var(--accent-glow); color: var(--accent); }
        .page-link.active { background: var(--accent); color: #000; border-color: var(--accent); }

        .empty-state { text-align: center; padding: 80px 20px; color: var(--text-tertiary); grid-column: 1/-1; }
        .empty-state svg { width: 80px; height: 80px; margin-bottom: 20px; opacity: 0.5; stroke: currentColor; }

        .toast-container { position: fixed; top: 80px; right: 16px; left: 16px; z-index: 10001; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
        .toast { background: var(--bg-tertiary); border: 1px solid var(--border-accent); border-radius: 60px; padding: 12px 20px; animation: slideIn 0.3s ease; pointer-events: auto; backdrop-filter: blur(10px); font-size: 13px; text-align: center; max-width: 400px; margin: 0 auto; }
        .loading-overlay { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: #0a0a0c; z-index: 9999; display: flex; align-items: center; justify-content: center; transition: 0.5s; }
        .loading-overlay.hide { opacity: 0; visibility: hidden; pointer-events: none; }
        .loading-spinner { width: 50px; height: 50px; border: 3px solid var(--border-subtle); border-top-color: var(--accent); border-radius: 50%; animation: spin 1s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }


        .search-section{padding-top:28px}.search-box{background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.025));box-shadow:0 18px 45px rgba(0,0,0,.22)}.page-header{max-width:1400px;margin-left:auto;margin-right:auto}.grid-item{border-radius:20px;background:linear-gradient(180deg,rgba(255,255,255,.045),rgba(255,255,255,.018));box-shadow:0 12px 34px rgba(0,0,0,.18)}.grid-item:hover{box-shadow:0 18px 42px rgba(0,0,0,.35),0 0 0 1px rgba(var(--accent-rgb),.14)}.grid-poster{display:block;transition:.3s ease}.grid-item:hover .grid-poster{transform:scale(1.025)}.grid-info{position:relative;z-index:2;background:linear-gradient(180deg,rgba(14,16,23,.96),rgba(10,11,16,.98))}.grid-meta svg{display:inline-block;vertical-align:-2px}.watchlist-icon-grid{margin-inline-start:auto;color:#fff}.filter-modal-content{box-shadow:var(--shadow-soft)}.active-filters{max-width:1400px;margin-left:auto;margin-right:auto}.footer-space{height:18px}
        @media(max-width:991px){.desktop-nav,.auth-dropdown{display:none}.header-inner{height:62px;padding:0 14px}.donate-btn{padding:9px 12px;font-size:11px}.menu-btn,.notif-bell{width:38px;height:38px}.search-section{padding:16px 12px}.movies-grid{padding:0 12px}.page-header{padding:0 12px}.filter-modal-content{border-radius:26px;padding:18px}.bottom-nav{display:grid}}
        @media(min-width:992px){body{padding-bottom:50px}.bottom-nav{display:none!important}.menu-btn{display:none}.search-section{padding-top:30px}}
        @media(max-width:540px){body{padding-bottom:96px}.logo-text{font-size:15px}.donate-btn{display:none}.search-box{border-radius:28px}.search-input{padding:13px 14px}.search-btn{padding:10px 14px}.filter-actions{flex-direction:column}.movies-grid{grid-template-columns:repeat(2,1fr)!important;gap:14px}.grid-title-fa{font-size:12px}.page-header h1{font-size:24px}}

        @media (min-width: 600px) { .movies-grid { grid-template-columns: repeat(4, 1fr); gap: 20px; } }
        @media (min-width: 900px) { .movies-grid { grid-template-columns: repeat(5, 1fr); gap: 24px; } }
        @media (min-width: 1200px) { .movies-grid { grid-template-columns: repeat(6, 1fr); } }
        @media (max-width: 600px) { .filter-toolbar { justify-content: center; } }
        html { scroll-behavior: smooth; }

        /* ===== Professional Search Cards Upgrade: IMDb on poster + premium grid ===== */
        .search-section{position:relative;isolation:isolate}
        .search-section:before{content:"";position:absolute;inset:-80px 0 auto 0;height:240px;background:radial-gradient(circle at 50% 0,rgba(var(--accent-rgb),.16),transparent 58%);pointer-events:none;z-index:-1}
        .movies-grid{align-items:start}
        .grid-item{border-radius:26px!important;overflow:hidden;background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(255,255,255,.022))!important;border:1px solid rgba(255,255,255,.075)!important;box-shadow:0 18px 46px rgba(0,0,0,.22);transform:translateZ(0);isolation:isolate}
        .grid-item:before{content:"";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(135deg,rgba(var(--accent-rgb),.18),transparent 34%,rgba(255,255,255,.045));opacity:0;transition:.28s ease;pointer-events:none;z-index:3}
        .grid-item:hover{transform:translateY(-8px)!important;border-color:rgba(var(--accent-rgb),.34)!important;box-shadow:0 24px 56px rgba(0,0,0,.46),0 0 0 1px rgba(var(--accent-rgb),.12)!important}
        .grid-item:hover:before{opacity:1}
        .poster-shell{position:relative;width:100%;aspect-ratio:2/3;overflow:hidden;background:linear-gradient(145deg,#11141d,#050608)}
        .poster-shell .grid-poster{width:100%;height:100%;object-fit:cover;display:block;transition:transform .45s cubic-bezier(.2,.8,.2,1),filter .3s ease;will-change:transform}
        .grid-item:hover .poster-shell .grid-poster{transform:scale(1.055);filter:saturate(1.08) contrast(1.04)}
        .poster-shell:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.34) 0%,transparent 30%,rgba(0,0,0,.08) 48%,rgba(0,0,0,.86) 100%);z-index:1;pointer-events:none}
        .poster-shine{position:absolute;inset:-30% -80%;background:linear-gradient(115deg,transparent 42%,rgba(255,255,255,.14),transparent 58%);transform:translateX(-55%) rotate(4deg);opacity:0;transition:.55s ease;z-index:2;pointer-events:none}
        .grid-item:hover .poster-shine{opacity:1;transform:translateX(55%) rotate(4deg)}
        .poster-top-row{position:absolute;top:10px;left:10px;right:10px;display:flex;align-items:flex-start;justify-content:space-between;gap:8px;z-index:4;pointer-events:none}
        .imdb-poster-badge{display:inline-flex;align-items:center;gap:6px;min-height:27px;padding:4px 7px;background:rgba(0,0,0,.72);border:1px solid rgba(255,255,255,.13);border-radius:10px;backdrop-filter:blur(12px);box-shadow:0 8px 20px rgba(0,0,0,.28)}
        .imdb-poster-badge b{display:inline-flex;align-items:center;height:18px;padding:0 5px;border-radius:5px;background:#f5c518;color:#050505;font-weight:950;font-size:10px;line-height:1;letter-spacing:-.2px;font-family:Arial,Helvetica,sans-serif}.imdb-poster-badge .imdb-mini-svg{width:30px;height:15px;display:block;object-fit:contain;border-radius:3px}
        .imdb-poster-badge em{font-style:normal;color:#fff;font-weight:900;font-size:11px;line-height:1;letter-spacing:.2px}
        .year-poster-badge{display:inline-flex;align-items:center;justify-content:center;min-height:27px;padding:4px 9px;border-radius:10px;background:rgba(var(--accent-rgb),.88);color:#050505;font-weight:950;font-size:11px;box-shadow:0 10px 24px rgba(var(--accent-rgb),.18)}
        .watchlist-icon-grid{position:absolute!important;top:48px;inset-inline-end:10px;width:34px!important;height:34px!important;z-index:5;margin:0!important;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.58)!important;backdrop-filter:blur(12px);color:#fff}
        .watchlist-icon-grid:hover{background:rgba(var(--accent-rgb),.18)!important;border-color:rgba(var(--accent-rgb),.45);color:var(--accent);transform:scale(1.08)!important}
        .watchlist-icon-grid svg{width:16px!important;height:16px!important}
        .poster-bottom-badges{position:absolute;left:10px;right:10px;bottom:10px;z-index:4;display:flex;align-items:center;gap:6px;flex-wrap:wrap;pointer-events:none}
        .poster-media-badge{display:inline-flex;align-items:center;gap:5px;min-height:24px;padding:4px 8px;border-radius:999px;background:rgba(0,0,0,.64);border:1px solid rgba(255,255,255,.11);color:#fff;font-size:10px;font-weight:850;backdrop-filter:blur(10px)}
        .poster-media-badge svg{width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2}
        .poster-media-badge.dub{color:var(--accent);border-color:rgba(var(--accent-rgb),.38);background:rgba(var(--accent-rgb),.12)}
        .poster-media-badge.soft{color:#9dc2ff;border-color:rgba(90,142,255,.34);background:rgba(68,112,255,.12)}
        .card-hover-layer{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.42);z-index:3;opacity:0;transition:.24s ease;pointer-events:none}
        .grid-item:hover .card-hover-layer{opacity:1}
        .card-hover-layer span{display:inline-flex;align-items:center;gap:7px;padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#fff;font-size:12px;font-weight:900;backdrop-filter:blur(14px)}
        .pro-grid-info{padding:12px 12px 13px!important;background:linear-gradient(180deg,rgba(13,16,24,.98),rgba(7,8,12,.99))!important;border-top:1px solid rgba(255,255,255,.055)}
        .grid-title-fa{font-size:13px!important;font-weight:900!important;letter-spacing:-.2px;line-height:1.55;margin-bottom:4px!important}
        .grid-title-en{font-size:10.5px!important;color:rgba(255,255,255,.47)!important;margin-bottom:10px!important;direction:ltr;text-align:start}
        .grid-meta.pro-meta{display:grid!important;grid-template-columns:1fr auto;gap:8px;align-items:center;color:var(--text-secondary)!important;font-size:10.5px!important}
        .grid-badge.pro-type{justify-self:start;font-weight:900;border:1px solid rgba(var(--accent-rgb),.24);background:rgba(var(--accent-rgb),.10)!important;color:var(--accent)!important;padding:4px 9px!important}
        .pro-mini-meta{display:flex;align-items:center;gap:7px;justify-content:flex-end;color:rgba(255,255,255,.55);font-weight:800;white-space:nowrap}
        .pro-mini-meta svg{width:11px;height:11px;stroke:#f5c518!important;fill:#f5c518!important}
        .result-tools{max-width:1400px;margin:0 auto 18px;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}
        .result-hint{display:inline-flex;align-items:center;gap:8px;color:var(--text-tertiary);font-size:12px;font-weight:760}
        .result-hint svg{width:16px;height:16px;stroke:var(--accent)}
        @media(max-width:540px){.grid-item{border-radius:22px!important}.poster-top-row{top:8px;left:8px;right:8px}.imdb-poster-badge{min-height:24px;padding:3px 6px}.imdb-poster-badge b{font-size:9px;height:16px}.imdb-poster-badge .imdb-mini-svg{width:26px;height:13px}.imdb-poster-badge em{font-size:10px}.year-poster-badge{min-height:24px;padding:3px 7px;font-size:10px}.watchlist-icon-grid{top:40px;inset-inline-end:8px;width:31px!important;height:31px!important}.poster-bottom-badges{left:8px;right:8px;bottom:8px}.poster-media-badge{font-size:9px;padding:3px 7px}.pro-grid-info{padding:10px!important}.grid-title-fa{font-size:12px!important}.grid-title-en{font-size:9.8px!important}.grid-meta.pro-meta{grid-template-columns:1fr;gap:6px}.pro-mini-meta{justify-content:flex-start}}

        /* ===== Quick Fix: filter modal above cards + rating only on poster ===== */
        .filter-modal{
            position:fixed!important;
            inset:0!important;
            z-index:2147483000!important;
            isolation:isolate!important;
            pointer-events:auto!important;
            background:rgba(0,0,0,.86)!important;
            backdrop-filter:blur(18px)!important;
            -webkit-backdrop-filter:blur(18px)!important;
        }
        .filter-modal.active{display:flex!important}
        .filter-modal-content{
            position:relative!important;
            z-index:2147483001!important;
            box-shadow:0 30px 90px rgba(0,0,0,.72),0 0 0 1px rgba(var(--accent-rgb),.22)!important;
        }
        body.filter-modal-open{overflow:hidden!important}
        .grid-meta.pro-meta{display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:8px!important}
        .pro-mini-meta{display:none!important}

    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<link rel="stylesheet" href="/assets/css/bm-advanced-search-v105.css?v=146">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body data-theme="<?= $userTheme ?>" class="search-page">
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header">
        <span class="logo-text">BankMovie</span>
        <button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <?php if($currentUser): ?>
    <div class="sidebar-user">
        <div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="sidebar-username"><?= e($currentUser['username'] ?? '') ?></div>
        <div class="sidebar-userrole"><?= ($currentUser['role'] ?? '') === 'admin' ? $t[$userLang]['admin_panel'] : $t[$userLang]['account'] ?></div>
    </div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/search" class="sidebar-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span><?= $t[$userLang]['search'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if(($currentUser['role'] ?? '') === 'admin'): ?>
        <a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang === 'fa' ? 'آیا از خروج مطمئن هستید؟' : 'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header">
        <h3><?= $t[$userLang]['notifications'] ?></h3>
        <button class="notif-close" id="closeNotifSidebar" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'] ?? '')) ?></div><div class="notif-date"><?= !empty($notif['created_at']) ? e(date('Y/m/d H:i', strtotime($notif['created_at']))) : '' ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<div class="search-section">
    <form method="GET" action="" class="search-box" id="mainSearchForm">
        <input type="hidden" name="archive" value="<?= e($archive) ?>">
        <input type="text" name="q" class="search-input" placeholder="<?= $userLang === 'fa' ? 'جستجوی فیلم، سریال، بازیگر، کارگردان...' : 'Search movies, series, actors, directors...' ?>" value="<?= escapeHtml($q) ?>">
        <button type="submit" class="search-btn">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            <?= $userLang === 'fa' ? 'جستجو' : 'Search' ?>
        </button>
    </form>

    <?php $enabledArchiveCount = count(array_filter($archiveEnabled)); ?>
    <div class="archive-search-tabs" aria-label="Archive source">
        <?php if($enabledArchiveCount > 1): ?><a href="<?= e(bm_search_archive_url('all')) ?>" class="archive-search-tab <?= $archive === 'all' ? 'active' : '' ?>"><?= $userLang === 'fa' ? 'همه آرشیوها' : 'All' ?></a><?php endif; ?>
        <?php if($archiveEnabled['arc1']): ?><a href="<?= e(bm_search_archive_url('arc1')) ?>" class="archive-search-tab <?= $archive === 'arc1' ? 'active' : '' ?>"><?= $userLang === 'fa' ? 'آرشیو ۱' : 'Archive 1' ?></a><?php endif; ?>
        <?php if($archiveEnabled['local']): ?><a href="<?= e(bm_search_archive_url('local')) ?>" class="archive-search-tab <?= $archive === 'local' ? 'active' : '' ?>"><?= $userLang === 'fa' ? 'آرشیو ۲' : 'Archive 2' ?></a><?php endif; ?>
        <?php if($archiveEnabled['arc3']): ?><a href="<?= e(bm_search_archive_url('arc3')) ?>" class="archive-search-tab <?= $archive === 'arc3' ? 'active' : '' ?>"><?= $userLang === 'fa' ? 'آرشیو ۳' : 'Archive 3' ?></a><?php endif; ?>
        <?php if($archiveEnabled['arc4']): ?><a href="<?= e(bm_search_archive_url('arc4')) ?>" class="archive-search-tab <?= $archive === 'arc4' ? 'active' : '' ?>"><?= $userLang === 'fa' ? 'آرشیو ۴' : 'Archive 4' ?></a><?php endif; ?>
    </div>

    <?php if($advancedSearchEnabled): ?>
    <div class="filter-toolbar bm-advanced-toolbar">
        <div class="bm-advanced-toolbar-copy">
            <span class="bm-advanced-toolbar-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 6h16M7 12h10M10 18h4"/><circle cx="7" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="12" cy="18" r="2"/></svg></span>
            <span class="bm-advanced-toolbar-text">
                <strong><?= $userLang === 'fa' ? 'نتیجه دقیق‌تر می‌خواهی؟' : 'Need more precise results?' ?></strong>
                <small><?= $userLang === 'fa' ? 'منبع، ژانر، کشور، سال، امتیاز و نسخه پخش را یکجا تنظیم کن' : 'Tune source, genre, country, year, rating and playback in one place' ?></small>
            </span>
        </div>
        <button type="button" class="filter-modal-btn" id="openFilterModalBtn" aria-haspopup="dialog" aria-controls="filterModal" aria-expanded="false">
            <span class="filter-modal-btn-main-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="22 3 2 3 10 13 10 21 14 18 14 13 22 3"/></svg></span>
            <span><?= $userLang === 'fa' ? 'فیلترهای پیشرفته' : 'Advanced filters' ?></span>
            <span class="filter-count-badge" data-filter-count <?= $advancedFilterCount > 0 ? '' : 'hidden' ?>><?= (int)$advancedFilterCount ?></span>
            <svg class="filter-modal-btn-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>
        </button>
    </div>

    <div class="filter-modal" id="filterModal" aria-hidden="true">
        <div class="filter-modal-grid" aria-hidden="true"></div>
        <div class="filter-modal-shell">
            <div class="filter-modal-content" role="dialog" aria-modal="true" aria-labelledby="advancedFilterTitle" aria-describedby="advancedFilterDescription">
                <div class="filter-modal-mobile-handle" aria-hidden="true"></div>
                <div class="filter-modal-header">
                    <div class="filter-modal-heading">
                        <span class="filter-modal-heading-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 5h16M7 12h10M10 19h4"/><circle cx="7" cy="5" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg></span>
                        <div class="filter-modal-heading-copy">
                            <span class="filter-modal-kicker">BANKMOVIE SMART FILTER</span>
                            <h3 id="advancedFilterTitle"><?= $userLang === 'fa' ? 'جستجوی پیشرفته واقعی' : 'Advanced search' ?></h3>
                            <span class="filter-modal-subtitle" id="advancedFilterDescription"><?= $userLang === 'fa' ? 'فیلترهای آرشیوهای فعال با گزینه‌های واقعی همان منبع' : 'Real filters backed by all enabled archives' ?></span>
                        </div>
                    </div>
                    <div class="filter-modal-header-actions">
                        <span class="filter-live-stat"><strong><?= number_format($total) ?></strong><span><?= $userLang === 'fa' ? 'نتیجه فعلی' : 'current results' ?></span></span>
                        <button type="button" class="filter-close" id="closeFilterModalBtn" aria-label="<?= $userLang === 'fa' ? 'بستن فیلترها' : 'Close filters' ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
                    </div>
                </div>

                <div class="filter-modal-body">
                    <div class="filter-presets" aria-label="<?= $userLang === 'fa' ? 'فیلترهای سریع' : 'Quick presets' ?>">
                        <span class="filter-presets-title"><?= $userLang === 'fa' ? 'انتخاب سریع:' : 'Quick picks:' ?></span>
                        <button type="button" class="filter-preset-btn" data-preset-name="type" data-preset-value="movie"><?= $userLang === 'fa' ? 'فقط فیلم' : 'Movies' ?></button>
                        <button type="button" class="filter-preset-btn" data-preset-name="type" data-preset-value="series"><?= $userLang === 'fa' ? 'فقط سریال' : 'Series' ?></button>
                        <button type="button" class="filter-preset-btn" data-preset-name="rating" data-preset-value="8">IMDb 8+</button>
                        <button type="button" class="filter-preset-btn" data-preset-name="dubbed" data-preset-value="1"><?= $userLang === 'fa' ? 'دوبله فارسی' : 'Dubbed' ?></button>
                        <button type="button" class="filter-preset-btn" data-preset-name="subtitle" data-preset-value="1"><?= $userLang === 'fa' ? 'زیرنویس فارسی' : 'Subtitle' ?></button>
                        <?php if($showSuggestedFilter): ?><button type="button" class="filter-preset-btn" data-archive-only="arc1" data-preset-name="suggest" data-preset-value="1"><?= $userLang === 'fa' ? 'پیشنهاد ویژه' : 'Suggested' ?></button><?php endif; ?>
                    </div>

                    <div class="filter-draft-summary">
                        <span class="filter-draft-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 13a8 8 0 1 1-3-6.3"/><polyline points="20 4 20 10 14 10"/></svg><?= $userLang === 'fa' ? 'انتخاب‌های فعلی' : 'Current choices' ?></span>
                        <div class="filter-draft-chips" id="filterDraftChips" aria-live="polite"></div>
                        <button type="button" class="filter-draft-reset" id="resetFilterDraftBtn"><?= $userLang === 'fa' ? 'پاک‌کردن' : 'Reset' ?></button>
                    </div>

                    <form method="GET" action="" id="filterForm">
                        <section class="filter-section">
                            <div class="filter-section-head">
                                <div class="filter-section-title"><span class="filter-section-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18M6 12h12M9 17h6"/></svg></span><?= $userLang === 'fa' ? 'منبع و نوع محتوا' : 'Source and content type' ?></div>
                                <span class="filter-section-desc"><?= $userLang === 'fa' ? 'آرشیو و نوع اثر را مشخص کن' : 'Choose the archive and content type' ?></span>
                            </div>
                            <div class="filter-grid">
                                <div class="filter-field-card full">
                                    <span class="filter-field-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M7 8h10M7 12h7"/></svg><?= $userLang === 'fa' ? 'آرشیو جستجو' : 'Search archive' ?></span>
                                    <div class="filter-choice-grid">
                                        <?php if($enabledArchiveCount > 1): ?><label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'همه آرشیوها' : 'All archives' ?>"><input type="radio" name="archive" value="all" <?= $archive === 'all' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'همه' : 'All' ?></span></label><?php endif; ?>
                                        <?php if($archiveEnabled['arc1']): ?><label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'آرشیو ۱' : 'Archive 1' ?>"><input type="radio" name="archive" value="arc1" <?= $archive === 'arc1' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'آرشیو ۱' : 'Archive 1' ?></span></label><?php endif; ?>
                                        <?php if($archiveEnabled['local']): ?><label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'آرشیو ۲' : 'Archive 2' ?>"><input type="radio" name="archive" value="local" <?= $archive === 'local' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'آرشیو ۲' : 'Archive 2' ?></span></label><?php endif; ?>
                                        <?php if($archiveEnabled['arc3']): ?><label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'آرشیو ۳' : 'Archive 3' ?>"><input type="radio" name="archive" value="arc3" <?= $archive === 'arc3' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'آرشیو ۳' : 'Archive 3' ?></span></label><?php endif; ?>
                                        <?php if($archiveEnabled['arc4']): ?><label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'آرشیو ۴' : 'Archive 4' ?>"><input type="radio" name="archive" value="arc4" <?= $archive === 'arc4' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'آرشیو ۴' : 'Archive 4' ?></span></label><?php endif; ?>
                                    </div>
                                </div>
                                <div class="filter-field-card full">
                                    <span class="filter-field-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="3"/><polygon points="10 8 16 12 10 16 10 8"/></svg><?= $userLang === 'fa' ? 'نوع محتوا' : 'Content type' ?></span>
                                    <div class="filter-choice-grid">
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'همه نوع‌ها' : 'All types' ?>"><input type="radio" name="type" value="all" <?= $type === 'all' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'همه' : 'All' ?></span></label>
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'فیلم' : 'Movie' ?>"><input type="radio" name="type" value="movie" <?= $type === 'movie' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'فیلم' : 'Movie' ?></span></label>
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'سریال' : 'Series' ?>"><input type="radio" name="type" value="series" <?= $type === 'series' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'سریال' : 'Series' ?></span></label>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="filter-section">
                            <div class="filter-section-head">
                                <div class="filter-section-title"><span class="filter-section-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/></svg></span><?= $userLang === 'fa' ? 'مشخصات اثر' : 'Title details' ?></div>
                                <span class="filter-section-desc"><?= $userLang === 'fa' ? 'نام، ژانر و مشخصات تولید' : 'Title, genre and production details' ?></span>
                            </div>
                            <div class="filter-grid">
                                <div class="filter-field-card full">
                                    <label for="advancedQuery"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><?= $userLang === 'fa' ? 'نام فیلم یا سریال' : 'Movie or series title' ?></label>
                                    <input id="advancedQuery" type="text" name="q" value="<?= escapeHtml($q) ?>" placeholder="<?= $userLang === 'fa' ? 'نام فارسی یا انگلیسی اثر' : 'Persian or English title' ?>" autocomplete="off">
                                </div>
                                <div class="filter-field-card">
                                    <label for="advancedGenre"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M12 3a13 13 0 0 1 0 18"/></svg><?= $userLang === 'fa' ? 'ژانر' : 'Genre' ?></label>
                                    <div class="filter-control-wrap"><select id="advancedGenre" name="genre"><option value=""><?= $userLang === 'fa' ? 'همه ژانرها' : 'All genres' ?></option><?php foreach($genreOptionRows as $row): $g=(string)$row['label']; ?><option value="<?= escapeHtml($g) ?>" data-archives="<?= e(implode(',', (array)$row['archives'])) ?>" <?= bm_search_option_key($genre) === bm_search_option_key($g) ? 'selected' : '' ?>><?= escapeHtml($g) ?></option><?php endforeach; ?></select></div>
                                </div>
                                <?php if($showCountryFilter): ?>
                                <div class="filter-field-card">
                                    <label for="advancedCountry"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18"/></svg><?= $userLang === 'fa' ? 'کشور سازنده' : 'Country' ?></label>
                                    <input id="advancedCountry" type="text" name="country" value="<?= escapeHtml($country) ?>" list="advancedCountryList" placeholder="<?= $userLang === 'fa' ? 'مثلاً آمریکا، کره جنوبی یا Japan' : 'e.g. USA, South Korea or Japan' ?>" autocomplete="off">
                                    <datalist id="advancedCountryList"><?php foreach($countryOptionRows as $row): ?><option value="<?= escapeHtml($row['label']) ?>"></option><?php endforeach; ?></datalist>
                                </div>
                                <?php endif; ?>
                                <?php if($showActorDirector): ?>
                                <div class="filter-field-card">
                                    <label for="advancedActor"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><?= $userLang === 'fa' ? 'بازیگر' : 'Actor' ?></label>
                                    <input id="advancedActor" type="text" name="actor" value="<?= escapeHtml($actor) ?>" placeholder="<?= $userLang === 'fa' ? 'مثلاً Cillian Murphy' : 'e.g. Cillian Murphy' ?>" autocomplete="off">
                                </div>
                                <div class="filter-field-card">
                                    <label for="advancedDirector"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 4h18v16H3z"/><path d="M8 4v16M16 4v16M3 9h5M16 9h5M3 15h5M16 15h5"/></svg><?= $userLang === 'fa' ? 'کارگردان' : 'Director' ?></label>
                                    <input id="advancedDirector" type="text" name="director" value="<?= escapeHtml($director) ?>" placeholder="<?= $userLang === 'fa' ? 'مثلاً Christopher Nolan' : 'e.g. Christopher Nolan' ?>" autocomplete="off">
                                </div>
                                <?php endif; ?>
                            </div>
                        </section>

                        <section class="filter-section">
                            <div class="filter-section-head">
                                <div class="filter-section-title"><span class="filter-section-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 12h18M5 7h14M8 17h8"/></svg></span><?= $userLang === 'fa' ? 'امتیاز و نسخه پخش' : 'Rating and playback' ?></div>
                                <span class="filter-section-desc"><?= $userLang === 'fa' ? 'چند شرط را می‌توانی همزمان فعال کنی' : 'Multiple conditions can be enabled together' ?></span>
                            </div>
                            <div class="filter-grid">
                                <div class="filter-field-card full">
                                    <span class="filter-field-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="12 2 15 8.3 22 9.3 17 14.2 18.2 21 12 17.8 5.8 21 7 14.2 2 9.3 9 8.3 12 2"/></svg><?= $userLang === 'fa' ? 'حداقل امتیاز IMDb' : 'Minimum IMDb rating' ?></span>
                                    <div class="filter-choice-grid five">
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'همه امتیازها' : 'Any rating' ?>"><input type="radio" name="rating" value="" <?= $rating === '' ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'همه' : 'Any' ?></span></label>
                                        <?php foreach([6,7,8,9] as $rate): ?><label class="filter-choice" data-filter-label="IMDb <?= $rate ?>+"><input type="radio" name="rating" value="<?= $rate ?>" <?= (string)$rating === (string)$rate ? 'checked' : '' ?>><span><?= $rate ?>+</span></label><?php endforeach; ?>
                                    </div>
                                </div>
                                <div class="filter-field-card full">
                                    <span class="filter-field-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5 6 9H2v6h4l5 4V5z"/><path d="M15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/></svg><?= $userLang === 'fa' ? 'نسخه موردنظر' : 'Playback version' ?></span>
                                    <div class="filter-choice-grid">
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'دوبله فارسی' : 'Persian dubbed' ?>"><input type="checkbox" name="dubbed" value="1" <?= $dubbed ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'دوبله فارسی' : 'Dubbed' ?></span></label>
                                        <label class="filter-choice" data-filter-label="<?= $userLang === 'fa' ? 'زیرنویس فارسی' : 'Persian subtitle' ?>"><input type="checkbox" name="subtitle" value="1" <?= $subtitle ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'زیرنویس فارسی' : 'Subtitle' ?></span></label>
                                        <?php if($showSuggestedFilter): ?><label class="filter-choice" data-archive-only="arc1" data-filter-label="<?= $userLang === 'fa' ? 'پیشنهاد ویژه آرشیو ۱' : 'Archive 1 suggested title' ?>"><input type="checkbox" name="suggest" value="1" <?= $suggest ? 'checked' : '' ?>><span><?= $userLang === 'fa' ? 'پیشنهاد ویژه آرشیو ۱' : 'Archive 1 suggested' ?></span></label><?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </section>

                        <section class="filter-section">
                            <div class="filter-section-head">
                                <div class="filter-section-title"><span class="filter-section-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="17" rx="3"/><path d="M8 2v4M16 2v4M3 9h18"/></svg></span><?= $userLang === 'fa' ? 'بازه زمانی و ترتیب نمایش' : 'Year range and sorting' ?></div>
                                <span class="filter-section-desc"><?= $userLang === 'fa' ? 'یک سال یا یک بازه کامل انتخاب کن' : 'Choose one year or a complete range' ?></span>
                            </div>
                            <div class="filter-grid">
                                <div class="filter-field-card">
                                    <label for="advancedFromYear"><?= $userLang === 'fa' ? 'از سال' : 'From year' ?></label>
                                    <div class="filter-control-wrap"><select id="advancedFromYear" name="from_year"><option value=""><?= $userLang === 'fa' ? 'بدون حداقل' : 'No minimum' ?></option><?php foreach($years as $y): ?><option value="<?= $y ?>" <?= (string)$fromYear === (string)$y ? 'selected' : '' ?>><?= $y ?></option><?php endforeach; ?></select></div>
                                </div>
                                <div class="filter-field-card">
                                    <label for="advancedToYear"><?= $userLang === 'fa' ? 'تا سال' : 'To year' ?></label>
                                    <div class="filter-control-wrap"><select id="advancedToYear" name="to_year"><option value=""><?= $userLang === 'fa' ? 'بدون حداکثر' : 'No maximum' ?></option><?php foreach($years as $y): ?><option value="<?= $y ?>" <?= (string)$toYear === (string)$y ? 'selected' : '' ?>><?= $y ?></option><?php endforeach; ?></select></div>
                                </div>
                                <div class="filter-field-card full">
                                    <label for="advancedSort"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M6 12h12M9 18h6"/></svg><?= $userLang === 'fa' ? 'مرتب‌سازی' : 'Sort results' ?></label>
                                    <div class="filter-control-wrap"><select id="advancedSort" name="sort">
                                        <option value="newest" <?= $sort === 'newest' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'جدیدترین انتشار' : 'Newest release' ?></option>
                                        <option value="modified" <?= $sort === 'modified' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'تازه به‌روزشده' : 'Recently updated' ?></option>
                                        <option value="popular" <?= $sort === 'popular' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'محبوب‌ترین' : 'Most popular' ?></option>
                                        <option value="rating_desc" <?= $sort === 'rating_desc' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'بالاترین امتیاز' : 'Top rated' ?></option>
                                        <option value="year_desc" <?= $sort === 'year_desc' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'سال نزولی' : 'Year descending' ?></option>
                                        <option value="year_asc" <?= $sort === 'year_asc' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'قدیمی‌ترین' : 'Oldest' ?></option>
                                        <option value="title_asc" <?= $sort === 'title_asc' ? 'selected' : '' ?>><?= $userLang === 'fa' ? 'براساس عنوان' : 'Title' ?></option>
                                    </select></div>
                                </div>
                            </div>
                        </section>

                        <div class="filter-actions">
                            <button type="submit" class="apply-filters-btn"><span class="filter-submit-spinner" aria-hidden="true"></span><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 5h16M7 12h10M10 19h4"/></svg><span data-submit-label><?= $userLang === 'fa' ? 'اعمال فیلترها و نمایش نتایج' : 'Apply filters and show results' ?></span></button>
                            <a href="/search" class="reset-filters-btn"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 12a9 9 0 1 0 3-6.7"/><polyline points="3 4 3 10 9 10"/></svg><?= $userLang === 'fa' ? 'حذف همه فیلترها' : 'Clear all filters' ?></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- فیلترهای فعال -->
    <?php $hasActiveFilters = $archive !== 'all' || $genre !== '' || $director !== '' || $country !== '' || $actor !== '' || $q !== '' || $type !== 'all' || $fromYear !== '' || $toYear !== '' || $rating !== '' || $dubbed || $subtitle || $suggest || $sort !== 'newest'; ?>
    <?php if($hasActiveFilters): ?>
    <div class="active-filters">
        <span class="filter-chip"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg><?= $userLang === 'fa' ? 'فیلترهای فعال:' : 'Active filters:' ?></span>
        <?php if($archive !== 'all'): ?><span class="filter-chip"><?= e($archiveLabels[$archive]) ?> <a href="<?= e(buildSearchUrlWithout('archive')) ?>">✕</a></span><?php endif; ?>
        <?php if($q !== ''): ?><span class="filter-chip"><?= escapeHtml($q) ?> <a href="<?= e(buildSearchUrlWithout('q')) ?>">✕</a></span><?php endif; ?>
        <?php if($genre !== ''): ?><span class="filter-chip"><?= escapeHtml($genre) ?> <a href="<?= e(buildSearchUrlWithout(['genre','genre_id'])) ?>">✕</a></span><?php endif; ?>
        <?php if($director !== ''): ?><span class="filter-chip"><?= escapeHtml($director) ?> <a href="<?= e(buildSearchUrlWithout('director')) ?>">✕</a></span><?php endif; ?>
        <?php if($country !== ''): ?><span class="filter-chip"><?= escapeHtml($country) ?> <a href="<?= e(buildSearchUrlWithout(['country','country_id'])) ?>">✕</a></span><?php endif; ?>
        <?php if($actor !== ''): ?><span class="filter-chip"><?= escapeHtml($actor) ?> <a href="<?= e(buildSearchUrlWithout('actor')) ?>">✕</a></span><?php endif; ?>
        <?php if($type !== 'all'): ?><span class="filter-chip"><?= $type === 'movie' ? ($userLang === 'fa' ? 'فیلم' : 'Movie') : ($userLang === 'fa' ? 'سریال' : 'Series') ?> <a href="<?= e(buildSearchUrlWithout('type')) ?>">✕</a></span><?php endif; ?>
        <?php if($fromYear !== '' || $toYear !== ''): ?><span class="filter-chip"><?= $fromYear !== '' && $toYear !== '' ? e($fromYear.' تا '.$toYear) : ($fromYear !== '' ? e('از '.$fromYear) : e('تا '.$toYear)) ?> <a href="<?= e(buildSearchUrlWithout(['from_year','to_year','year'])) ?>">✕</a></span><?php endif; ?>
        <?php if($rating !== ''): ?><span class="filter-chip">IMDb <?= e($rating) ?>+ <a href="<?= e(buildSearchUrlWithout('rating')) ?>">✕</a></span><?php endif; ?>
        <?php if($dubbed): ?><span class="filter-chip"><?= $userLang === 'fa' ? 'دوبله فارسی' : 'Dubbed' ?> <a href="<?= e(buildSearchUrlWithout(['dubbed','dub_type'])) ?>">✕</a></span><?php endif; ?>
        <?php if($subtitle): ?><span class="filter-chip"><?= $userLang === 'fa' ? 'زیرنویس فارسی' : 'Subtitle' ?> <a href="<?= e(buildSearchUrlWithout(['subtitle','dub_type'])) ?>">✕</a></span><?php endif; ?>
        <?php if($suggest): ?><span class="filter-chip"><?= $userLang === 'fa' ? 'پیشنهاد ویژه' : 'Suggested' ?> <a href="<?= e(buildSearchUrlWithout('suggest')) ?>">✕</a></span><?php endif; ?>
        <?php if($sort !== 'newest'): ?><span class="filter-chip"><?= $userLang === 'fa' ? 'مرتب‌سازی سفارشی' : 'Custom sort' ?> <a href="<?= e(buildSearchUrlWithout('sort')) ?>">✕</a></span><?php endif; ?>
        <a href="/search" class="clear-filters"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg><?= $userLang === 'fa' ? 'حذف همه' : 'Clear all' ?></a>
    </div>
    <?php endif; ?>
</div>

<div class="page-header">
    <h1><?= $userLang === 'fa' ? 'نتایج جستجو' : 'Search Results' ?></h1>
    <div class="count">
        <?php if($total > 0): ?>
            <?= number_format($total) ?> <?= $userLang === 'fa' ? 'نتیجه برای' : 'results for' ?> 
            <span class="search-term"><?= $searchTitle ?></span>
        <?php else: ?>
            <?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?>
        <?php endif; ?>
    </div>
</div>

<?php if($total > 0 && !empty($movies)): ?>
<div class="result-tools">
    <div class="result-hint">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 6h16M4 12h10M4 18h7"/></svg>
        <?= $userLang === 'fa' ? 'نتایج از آرشیو انتخاب‌شده نمایش داده می‌شود؛ روی هر کارت منبع آرشیو مشخص است.' : 'Results are shown from the selected archive; each card shows its source.' ?>
    </div>
</div>
<div class="movies-grid" id="moviesGrid"></div>
<?php if($lastPage > 1): ?>
<div class="pagination">
    <?php if($page > 1): ?>
    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page-1])) ?>" class="page-link"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg><?= $userLang === 'fa' ? 'قبلی' : 'Previous' ?></a>
    <?php endif; ?>
    <?php $start = max(1, $page-2); $end = min($lastPage, $page+2);
    for($i=$start; $i<=$end; $i++): ?>
        <a href="?<?= http_build_query(array_merge($_GET, ['page' => $i])) ?>" class="page-link <?= $i == $page ? 'active' : '' ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if($page < $lastPage): ?>
    <a href="?<?= http_build_query(array_merge($_GET, ['page' => $page+1])) ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></a>
    <?php endif; ?>
</div>
<?php endif; ?>
<?php else: ?>
<div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای با این مشخصات یافت نشد.' : 'No results found with these criteria.' ?></p><p style="font-size:12px;margin-top:10px;"><?= $userLang === 'fa' ? 'پیشنهاد: املای کلمات را بررسی کنید یا فیلترهای دیگری امتحان کنید.' : 'Suggestion: Check your spelling or try different filters.' ?></p></div></div>
<?php endif; ?>

<div class="footer-space"></div>

<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('search.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<div class="bottom-nav" data-mobile-bottom-nav aria-label="Mobile bottom navigation">
    <a href="/" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span class="nav-label"><?= $t[$userLang]['home'] ?></span></a>
    <a href="/search" class="nav-item active bm-footer-search-trigger" aria-haspopup="dialog" aria-controls="bmQuickSearchModal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span class="nav-label"><?= $t[$userLang]['search'] ?></span></a>
    <a href="<?= $currentUser ? '/profile' : '/login' ?>" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span class="nav-label"><?= $currentUser ? $t[$userLang]['profile'] : $t[$userLang]['login'] ?></span></a>
</div>

<div id="donateModal" class="modal">
    <div class="modal-content">
        <div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
        <h3 style="margin-bottom:10px;font-size:22px;"><?= $t[$userLang]['support_us'] ?></h3>
        <p style="color:var(--text-secondary);margin-bottom:20px;font-size:13px;line-height:1.8;"><?= $t[$userLang]['support_text'] ?></p>
        <button id="openDonateLink" class="btn btn-primary" style="width:100%;"><?= $t[$userLang]['donate'] ?></button>
        <button id="closeDonateModal" type="button" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer;"><?= $t[$userLang]['close'] ?></button>
    </div>
</div>

<script>
<?php $bmSearchPublicMovies = function_exists('bm_poster_wrap_payload') ? bm_poster_wrap_payload($movies) : $movies; ?>
const moviesData = <?= json_encode($bmSearchPublicMovies, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
const userWatchlistSet = <?= json_encode($userWatchlistSet, JSON_UNESCAPED_UNICODE) ?>;
const isLoggedIn = <?= $isLoggedIn ? 'true' : 'false' ?>;
const userLang = '<?= $userLang ?>';
const DEFAULT_POSTER = 'uploads/no.png';

let toastTimeout = null;


function setupMenu(){
    const menuBtn=document.getElementById('menuBtn'),sidebar=document.getElementById('sidebarMenu'),overlay=document.getElementById('menuOverlay'),closeBtn=document.getElementById('closeMenuBtn');
    if(!menuBtn||!sidebar||!overlay||!closeBtn)return;
    function openMenu(){sidebar.classList.add('open');overlay.classList.add('active');document.body.style.overflow='hidden';menuBtn.setAttribute('aria-expanded','true');}
    function closeMenu(){sidebar.classList.remove('open');overlay.classList.remove('active');document.body.style.overflow='';menuBtn.setAttribute('aria-expanded','false');}
    menuBtn.addEventListener('click',openMenu);closeBtn.addEventListener('click',closeMenu);overlay.addEventListener('click',closeMenu);window.addEventListener('resize',()=>{if(window.innerWidth>=992)closeMenu();});
}
function setupHeaderScroll(){const header=document.getElementById('siteHeader');if(!header)return;function update(){header.classList.toggle('header-solid',(window.scrollY||0)>20);}update();window.addEventListener('scroll',update,{passive:true});}
function setupSmartBottomNav(){
    const nav=document.querySelector('.bottom-nav');if(!nav)return;let lastY=window.scrollY||0,ticking=false;
    function keep(){const ae=document.activeElement;return window.innerWidth>=992||window.scrollY<100||document.body.style.overflow==='hidden'||document.querySelector('.sidebar-menu.open')||(ae&&['INPUT','TEXTAREA','SELECT'].includes(ae.tagName));}
    function update(){const y=window.scrollY||0,diff=y-lastY;if(keep()){nav.classList.remove('nav-hidden');nav.classList.toggle('nav-compact',y>220);lastY=y;ticking=false;return;}if(Math.abs(diff)>12){nav.classList.toggle('nav-hidden',diff>0);nav.classList.toggle('nav-compact',y>220&&diff<=0);lastY=y;}ticking=false;}
    window.addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(update);ticking=true;}},{passive:true});window.addEventListener('resize',update);document.addEventListener('focusin',update);document.addEventListener('focusout',()=>setTimeout(update,80));update();
}
function setupNotifications(){const bell=document.getElementById('notifBell'),sidebar=document.getElementById('notifSidebar'),close=document.getElementById('closeNotifSidebar');if(!bell||!sidebar||!close)return;bell.addEventListener('click',()=>sidebar.classList.add('open'));bell.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();sidebar.classList.add('open');}});close.addEventListener('click',()=>sidebar.classList.remove('open'));document.addEventListener('click',e=>{if(sidebar.classList.contains('open')&&!sidebar.contains(e.target)&&!bell.contains(e.target))sidebar.classList.remove('open');});}
function setupDonate(){const btn=document.getElementById('donateModalBtn'),modal=document.getElementById('donateModal'),close=document.getElementById('closeDonateModal'),open=document.getElementById('openDonateLink');if(btn&&modal)btn.onclick=()=>modal.style.display='flex';if(close&&modal)close.onclick=()=>modal.style.display='none';if(open&&modal)open.onclick=()=>{window.open('https://daramet.com/manuel','_blank');modal.style.display='none';};if(modal)modal.addEventListener('click',e=>{if(e.target===modal)modal.style.display='none';});}

function showToast(msg){
    if(toastTimeout) clearTimeout(toastTimeout);
    const container = document.getElementById('toastContainer');
    container.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = msg;
    container.appendChild(t);
    toastTimeout = setTimeout(() => t?.remove(), 3000);
}

function hideLoading() {
    document.getElementById('loadingOverlay').classList.add('hide');
    setTimeout(() => document.getElementById('loadingOverlay').style.display = 'none', 500);
}

async function toggleWatchlist(imdbCode, element) {
    if(!isLoggedIn) {
        showToast(userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login');
        setTimeout(() => window.location.href = '/login', 1500);
        return;
    }
    const isActive = element.classList.contains('active');
    const action = isActive ? 'remove' : 'add';
    const fd = new FormData();
    fd.append('action', action);
    fd.append('imdb_code', imdbCode);
    try {
        const res = await fetch('/ajax_watchlist.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            if(data.added) {
                element.classList.add('active');
                element.querySelector('svg').setAttribute('fill', '#36ff9f');
                showToast(userLang === 'fa' ? 'افزودن به نشانه‌ها' : 'Added to watchlist');
            } else {
                element.classList.remove('active');
                element.querySelector('svg').setAttribute('fill', 'none');
                showToast(userLang === 'fa' ? 'حذف از نشانه‌ها' : 'Removed from watchlist');
            }
        } else showToast(data.error || (userLang === 'fa' ? 'خطا' : 'Error'));
    } catch(e) { showToast(userLang === 'fa' ? 'خطا در ارتباط' : 'Server error'); }
}

function escapeHtml(str){ return String(str||'').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m])); }

function renderMoviesGrid() {
    const container = document.getElementById('moviesGrid');
    if(!container) return;
    if(!moviesData || moviesData.length === 0) {
        container.innerHTML = '<div class="empty-state"><p>' + (userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found') + '</p></div>';
        hideLoading();
        return;
    }
    container.innerHTML = moviesData.map(m => {
        const archive = m.source_archive || 'local';
        const isLocal = archive === 'local';
        const sourceLabel = m.source_label || (isLocal ? 'آرشیو ۲' : (archive === 'arc1' ? 'آرشیو ۱' : (archive === 'arc4' ? 'آرشیو ۴' : 'آرشیو ۳')));
        const typeLabel = m.type === 'movie' ? (userLang === 'fa' ? 'فیلم' : 'Movie') : (userLang === 'fa' ? 'سریال' : 'Series');
        const imdbKey = m.imdb_code || m.id || '';
        const inWl = isLocal && userWatchlistSet[imdbKey] !== undefined;
        const ratingNumber = parseFloat(m.imdb_rate || m.rating || 0);
        const rating = Number.isFinite(ratingNumber) && ratingNumber > 0 ? ratingNumber.toFixed(1) : 'N/A';
        const poster = m.poster ? m.poster : (isLocal && m.imdb_code ? `posters/${m.imdb_code}.webp` : DEFAULT_POSTER);
        const detailUrl = m.detail_url || (isLocal && m.imdb_code ? `movie.php?imdb=${encodeURIComponent(m.imdb_code)}` : '#');
        const yearBadge = m.year ? `<span class="year-poster-badge">${escapeHtml(m.year)}</span>` : '';
        const hasDub = parseInt(m.dub_count || 0, 10) > 0 || !!m.has_dubbed;
        const hasSoft = parseInt(m.soft_count || 0, 10) > 0 || !!m.has_subtitle;
        const dubBadge = hasDub ? `<span class="poster-media-badge dub"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><path d="M12 19v3M8 22h8"/></svg>${userLang === 'fa' ? 'دوبله' : 'Dub'}</span>` : '';
        const softBadge = hasSoft ? `<span class="poster-media-badge soft"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h4M13 15h4M7 11h10"/></svg>${userLang === 'fa' ? 'زیرنویس' : 'Sub'}</span>` : '';
        const sourceBadge = `<span class="poster-media-badge">${escapeHtml(sourceLabel)}</span>`;
        const watchBtn = isLocal ? `<div class="watchlist-icon-grid ${inWl ? 'active' : ''}" data-imdb="${escapeHtml(imdbKey)}" title="Watchlist">
                    <svg viewBox="0 0 24 24" fill="${inWl ? '#36ff9f' : 'none'}" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                </div>` : '';
        return `<a href="${detailUrl}" class="grid-item pro-card" aria-label="${escapeHtml(m.title_fa || m.title)}">
            <div class="poster-shell">
                <img class="grid-poster" src="${poster}" loading="lazy" alt="${escapeHtml(m.title_fa || m.title)}" onerror="this.src='${DEFAULT_POSTER}'; this.onerror=null;">
                <div class="poster-shine"></div>
                <div class="poster-top-row">
                    <span class="imdb-poster-badge"><span class="bm-imdb-score">${rating}</span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span>
                    ${yearBadge}
                </div>
                ${watchBtn}
                <div class="poster-bottom-badges">${dubBadge}${softBadge}${sourceBadge}</div>
                <div class="card-hover-layer"><span>${userLang === 'fa' ? 'مشاهده جزئیات' : 'View details'}</span></div>
            </div>
            <div class="grid-info pro-grid-info">
                <div class="grid-title-fa">${escapeHtml(m.title_fa || m.title)}</div>
                <div class="grid-title-en">${escapeHtml(m.title || '')}</div>
                <div class="grid-meta pro-meta">
                    <span class="grid-badge pro-type">${typeLabel}</span>
                </div>
            </div>
        </a>`;
    }).join('');
    document.querySelectorAll('.watchlist-icon-grid').forEach(icon => {
        icon.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            toggleWatchlist(icon.dataset.imdb, icon);
        });
    });
    hideLoading();
}

// Advanced search modal behavior is isolated in bm-advanced-search-v105.js.

if(moviesData && moviesData.length > 0) renderMoviesGrid();
else hideLoading();
setupMenu();setupHeaderScroll();setupSmartBottomNav();setupNotifications();setupDonate();
</script>
<script src="/assets/js/bm-advanced-search-v105.js?v=146" defer></script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
