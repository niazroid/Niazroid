<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';

require_once 'config.php';
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/vip_features.php';
bm_vip_gate_require('collections', $currentUser ?? null);
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('page_collections_enabled');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$currentUser = $currentUser ?? null;
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];

$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
if (!isset($themes[$userTheme])) $userTheme = 'dark-green';
$currentThemeInfo = $themes[$userTheme];

$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

$themeHex = ltrim($currentThemeInfo['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);

function e($str) { return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8'); }
function enNumbers($str) {
    $persian = ['۰','۱','۲','۳','۴','۵','۶','۷','۸','۹'];
    $english = ['0','1','2','3','4','5','6','7','8','9'];
    return str_replace($persian, $english, (string)$str);
}
function safe_asset($path, $fallback = '') {
    $path = trim((string)$path);
    if ($path === '') return $fallback;
    if (preg_match('~^(https?:)?//~i', $path)) return $path;
    if (preg_match('~^(javascript:|data:text/html)~i', $path)) return $fallback;
    return $path;
}
function bm_bool($value) {
    if (is_bool($value)) return $value;
    $value = mb_strtolower(trim((string)$value), 'UTF-8');
    return in_array($value, ['1','true','yes','on','active','dubbed','subbed','دوبله','زیرنویس','زیرنویس فارسی'], true);
}
function movie_has_any($movie, $keys) {
    foreach ($keys as $key) {
        if (array_key_exists($key, $movie) && bm_bool($movie[$key])) return true;
    }
    return false;
}
function movie_has_text($movie, $keys, $needles) {
    foreach ($keys as $key) {
        if (!array_key_exists($key, $movie)) continue;
        $haystack = mb_strtolower((string)$movie[$key], 'UTF-8');
        foreach ($needles as $needle) {
            if ($needle !== '' && mb_strpos($haystack, mb_strtolower($needle, 'UTF-8')) !== false) return true;
        }
    }
    return false;
}

$t = [
    'fa' => [
        'home'=>'خانه','collections'=>'کالکشن‌ها','all_collections'=>'همه کالکشن‌ها','special_collections'=>'کالکشن‌های ویژه',
        'player'=>'پلیر','request'=>'درخواست فیلم و سریال','profile'=>'پروفایل','account'=>'حساب کاربری','login'=>'ورود','register'=>'ثبت نام','logout'=>'خروج','admin_panel'=>'پنل مدیریت',
        'notifications'=>'اعلان‌ها','no_notifications'=>'هیچ اعلانی وجود ندارد','active_notifications'=>'اعلان فعال','latest'=>'جدیدترین','back'=>'بازگشت','movies'=>'فیلم','titles'=>'عنوان','collection'=>'کالکشن','cinematic_collection'=>'مجموعه سینمایی',
        'search_placeholder'=>'جستجو بین کالکشن‌ها...','popular_collection'=>'منتخب BankMovie','view_collection'=>'مشاهده کالکشن','movie_list'=>'فیلم‌های مجموعه','default'=>'پیش‌فرض','oldest'=>'قدیمی‌ترین','newest'=>'جدیدترین','dubbed'=>'دوبله','subbed'=>'زیرنویس','imdb'=>'IMDb','footer_text'=>'آرشیو مرتب فیلم‌ها، سریال‌ها و کالکشن‌های سینمایی با تجربه‌ای سریع و تاریک.', 'quick_access'=>'دسترسی سریع', 'made_for'=>'ساخته شده برای عاشقان سینما', 'support'=>'حمایت مالی'
    ],
    'en' => [
        'home'=>'Home','collections'=>'Collections','all_collections'=>'All Collections','special_collections'=>'Special Collections',
        'player'=>'Player','request'=>'Request Movie / Series','profile'=>'Profile','account'=>'Account','login'=>'Login','register'=>'Register','logout'=>'Logout','admin_panel'=>'Admin Panel',
        'notifications'=>'Notifications','no_notifications'=>'No notifications','active_notifications'=>'active notifications','latest'=>'Latest','back'=>'Back','movies'=>'Movies','titles'=>'Titles','collection'=>'Collection','cinematic_collection'=>'Cinematic Collection',
        'search_placeholder'=>'Search collections...','popular_collection'=>'BankMovie Pick','view_collection'=>'View Collection','movie_list'=>'Collection Movies','default'=>'Default','oldest'=>'Oldest','newest'=>'Newest','dubbed'=>'Dubbed','subbed'=>'Subtitles','imdb'=>'IMDb','footer_text'=>'A polished dark archive for movies, series, and cinematic collections.', 'quick_access'=>'Quick Access', 'made_for'=>'Made for cinema lovers', 'support'=>'Support'
    ]
];

$notificationsList = [];
$latestNotification = null;
$notificationSeen = false;
try {
    $stmt = $pdo->prepare("SELECT id, message, created_at FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll();
    $latestNotification = $notificationsList[0] ?? null;
    if ($latestNotification) {
        $cookieName = 'notification_seen_' . (int)$latestNotification['id'];
        $notificationSeen = isset($_COOKIE[$cookieName]);
    }
} catch (Throwable $e) {
    $notificationsList = [];
}


try {
    $collections = $pdo->query("\n        SELECT c.*, COUNT(cm.id) as movie_count, MIN(m.year) as first_year, MAX(m.year) as last_year\n        FROM collections c\n        LEFT JOIN collection_movies cm ON c.id = cm.collection_id\n        LEFT JOIN movies m ON cm.movie_id = m.id\n        WHERE c.status = 1\n        GROUP BY c.id\n        ORDER BY c.id DESC\n    ")->fetchAll();
} catch (Throwable $e) {
    $collections = $pdo->query("\n        SELECT c.*, COUNT(cm.id) as movie_count\n        FROM collections c\n        LEFT JOIN collection_movies cm ON c.id = cm.collection_id\n        WHERE c.status = 1\n        GROUP BY c.id\n        ORDER BY c.id DESC\n    ")->fetchAll();
}

foreach ($collections as &$bmCollectionRow) {
    $bmCollectionRow['cover_image'] = bm_public_asset_url($bmCollectionRow['cover_image'] ?? '', '');
}
unset($bmCollectionRow);
$totalCollections = count($collections);
$totalMoviesInCollections = array_sum(array_map(fn($c) => (int)($c['movie_count'] ?? 0), $collections));
?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="csrf-token" content="<?= e($csrf_token) ?>">
    <title><?= $t[$userLang]['all_collections'] ?> | BankMovie</title>
    <style>
        @font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}
        *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
        :root{
            --bg-primary:#08090d;--bg-secondary:#101116;--bg-tertiary:#171922;--bg-card:#0e1017;--bg-card-hover:#151824;
            --accent:<?= e($currentThemeInfo['primary']) ?>;--accent-rgb:<?= e($currentThemeRgbCss) ?>;--accent-dark:<?= e($currentThemeInfo['primary']) ?>cc;
            --accent-glow:rgba(var(--accent-rgb),0.14);--accent-soft:rgba(var(--accent-rgb),0.08);
            --text-primary:#fff;--text-secondary:#a9abb8;--text-tertiary:#707482;
            --border-subtle:rgba(255,255,255,0.075);--border-accent:rgba(var(--accent-rgb),0.28);
            --shadow-card:0 24px 60px rgba(0,0,0,.36);--gradient-hero:linear-gradient(135deg,#fff 0%,var(--accent) 80%);
            --collection-card-fit:<?= e(in_array((string)bm_site_get('collection_card_image_fit', 'cover'), ['cover','contain'], true) ? (string)bm_site_get('collection_card_image_fit', 'cover') : 'cover') ?>;
        }
        html{scroll-behavior:smooth}
        body{
            min-height:100vh;background:
                radial-gradient(circle at 10% -10%,rgba(var(--accent-rgb),.18),transparent 34%),
                radial-gradient(circle at 88% 2%,rgba(120,80,255,.14),transparent 30%),
                linear-gradient(180deg,#090a0f 0%,#08090d 48%,#0b0c11 100%);
            color:var(--text-primary);font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;overflow-x:hidden;padding-bottom:110px;
        }
        a{color:inherit} svg{display:block} ::selection{background:var(--accent);color:#000}
        ::-webkit-scrollbar{width:7px;height:7px}::-webkit-scrollbar-track{background:#101116}::-webkit-scrollbar-thumb{background:rgba(var(--accent-rgb),.72);border-radius:999px}
        .page-shell{position:relative;z-index:1}
        .bg-orb{position:fixed;border-radius:999px;filter:blur(42px);opacity:.42;pointer-events:none;z-index:0}.orb-1{width:320px;height:320px;background:rgba(var(--accent-rgb),.22);top:10%;right:-120px}.orb-2{width:260px;height:260px;background:rgba(80,120,255,.16);bottom:6%;left:-90px}
        .menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,.68);backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);z-index:1000;opacity:0;visibility:hidden;transition:.28s ease}.menu-overlay.active{opacity:1;visibility:visible}
        .header{position:sticky;top:0;left:0;right:0;z-index:900;background:linear-gradient(180deg,rgba(10,11,16,.78),rgba(10,11,16,.55));border-bottom:1px solid rgba(255,255,255,.08);backdrop-filter:blur(18px) saturate(150%);-webkit-backdrop-filter:blur(18px) saturate(150%);box-shadow:0 18px 42px rgba(0,0,0,.18);transition:.25s ease}
        .header.header-solid{background:rgba(10,11,16,.93);box-shadow:0 18px 50px rgba(0,0,0,.32)}
        .header-inner{max-width:1440px;height:72px;margin:0 auto;padding:0 22px;display:flex;align-items:center;justify-content:space-between;gap:18px}
        .logo{display:flex;align-items:center;gap:11px;text-decoration:none;flex-shrink:0}.logo-icon{width:36px;height:36px;filter:drop-shadow(0 0 16px rgba(var(--accent-rgb),.22))}.logo-text{font-size:21px;font-weight:900;letter-spacing:-.3px;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent}
        .desktop-nav{display:none;align-items:center;gap:7px;margin-inline-start:18px;margin-inline-end:auto}.desktop-nav-item{height:42px;display:inline-flex;align-items:center;gap:8px;padding:0 14px;border-radius:999px;color:rgba(255,255,255,.82);font-size:13px;font-weight:800;text-decoration:none;transition:.2s ease}.desktop-nav-item svg{width:17px;height:17px;stroke:currentColor}.desktop-nav-item:hover,.desktop-nav-item.active{background:rgba(255,255,255,.07);color:#fff;transform:translateY(-1px)}.desktop-nav-item.active{color:var(--accent);border:1px solid rgba(var(--accent-rgb),.18);background:var(--accent-soft)}.desktop-nav-item.request-link{color:var(--accent);background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.16)}
        .header-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}.icon-btn,.menu-btn,.notif-bell,.donate-btn,.auth-trigger,.user-trigger{height:42px;border-radius:999px;border:1px solid rgba(255,255,255,.10);background:rgba(18,20,28,.66);color:#fff;display:inline-flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;transition:.2s ease;font-family:inherit;text-decoration:none}.icon-btn:hover,.menu-btn:hover,.notif-bell:hover,.auth-trigger:hover,.user-trigger:hover{background:rgba(255,255,255,.08);border-color:var(--border-accent);transform:translateY(-1px)}.icon-btn,.menu-btn,.notif-bell{width:42px}.icon-btn svg,.menu-btn svg,.notif-bell svg,.auth-trigger svg,.user-trigger svg{width:19px;height:19px;stroke:currentColor}.notif-bell{position:relative}.notif-badge{position:absolute;top:-4px;right:-4px;min-width:18px;height:18px;padding:0 5px;background:#ff3366;color:#fff;border-radius:999px;font-size:10px;display:flex;align-items:center;justify-content:center;font-weight:900;border:2px solid #0b0c11}.donate-btn{padding:0 15px;background:linear-gradient(135deg,#ff3366,#ff7a33);border:0;font-weight:900;font-size:12px;box-shadow:0 14px 28px rgba(255,76,84,.20)}.donate-btn:hover{transform:translateY(-1px);box-shadow:0 18px 34px rgba(255,76,84,.28)}
        .auth-dropdown{position:relative;display:none}.auth-trigger,.user-trigger{padding:0 14px;font-size:13px;font-weight:900}.auth-menu{position:absolute;top:calc(100% + 12px);inset-inline-end:0;min-width:205px;padding:9px;background:rgba(18,20,28,.96);border:1px solid rgba(255,255,255,.10);border-radius:22px;box-shadow:0 24px 70px rgba(0,0,0,.46);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);opacity:0;visibility:hidden;transform:translateY(8px) scale(.98);transition:.2s ease;z-index:1200}.auth-dropdown:hover .auth-menu,.auth-dropdown:focus-within .auth-menu{opacity:1;visibility:visible;transform:translateY(0) scale(1)}.auth-menu a{display:flex;align-items:center;gap:10px;padding:11px 12px;border-radius:15px;color:#fff;text-decoration:none;font-size:13px;font-weight:800;transition:.18s ease}.auth-menu a:hover{background:var(--accent-glow);color:var(--accent)}.auth-menu a svg{width:18px;height:18px;stroke:currentColor}
        .sidebar-menu{position:fixed;top:0;right:0;width:min(320px,86vw);height:100%;background:linear-gradient(180deg,rgba(18,20,28,.98),rgba(10,11,16,.98));backdrop-filter:blur(22px);-webkit-backdrop-filter:blur(22px);z-index:1001;transform:translateX(105%);transition:transform .3s cubic-bezier(.2,.8,.2,1);display:flex;flex-direction:column;border-left:1px solid var(--border-accent);box-shadow:-24px 0 70px rgba(0,0,0,.46)}[dir="ltr"] .sidebar-menu{right:auto;left:0;transform:translateX(-105%);border-left:0;border-right:1px solid var(--border-accent)}.sidebar-menu.open{transform:translateX(0)}.sidebar-header{padding:22px 20px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;justify-content:space-between;align-items:center}.sidebar-close{width:40px;height:40px;border-radius:999px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);cursor:pointer;color:#fff;display:flex;align-items:center;justify-content:center}.sidebar-close svg{width:22px;height:22px;stroke:currentColor}.sidebar-user{margin:16px;padding:16px;border:1px solid rgba(var(--accent-rgb),.18);border-radius:24px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.14),rgba(255,255,255,.035));text-align:center}.sidebar-avatar{width:62px;height:62px;border-radius:22px;background:var(--accent);color:#000;display:flex;align-items:center;justify-content:center;margin:0 auto 10px;box-shadow:0 14px 28px rgba(var(--accent-rgb),.18)}.sidebar-avatar svg{width:30px;height:30px;stroke:currentColor}.sidebar-username{font-weight:900}.sidebar-userrole{font-size:11px;color:var(--text-tertiary);margin-top:3px}.sidebar-nav{flex:1;padding:8px 12px;overflow:auto}.sidebar-item{display:flex;align-items:center;gap:13px;padding:13px 14px;border-radius:18px;text-decoration:none;color:#fff;transition:.2s ease;font-size:14px;font-weight:750}.sidebar-item:hover,.sidebar-item.active{background:var(--accent-glow);color:var(--accent)}.sidebar-item svg{width:21px;height:21px;stroke:currentColor}.sidebar-footer{padding:14px 12px 20px;border-top:1px solid rgba(255,255,255,.07)}
        .notif-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.58);backdrop-filter:blur(6px);-webkit-backdrop-filter:blur(6px);z-index:1100}.notif-sidebar{position:fixed;top:0;right:0;width:min(390px,92vw);height:100%;background:linear-gradient(180deg,rgba(18,20,28,.98),rgba(10,11,16,.98));border-left:1px solid var(--border-accent);box-shadow:-24px 0 80px rgba(0,0,0,.52);z-index:1101;transform:translateX(105%);transition:.3s cubic-bezier(.2,.8,.2,1);display:flex;flex-direction:column}[dir="ltr"] .notif-sidebar{right:auto;left:0;transform:translateX(-105%);border-left:0;border-right:1px solid var(--border-accent)}.notif-sidebar.open{transform:translateX(0)}.notif-header{padding:20px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;justify-content:space-between;align-items:center}.notif-title-wrap{display:flex;align-items:center;gap:12px}.notif-title-icon{width:44px;height:44px;border-radius:16px;background:var(--accent-glow);color:var(--accent);display:flex;align-items:center;justify-content:center}.notif-title-icon svg,.notif-date svg{stroke:currentColor}.notif-title-icon svg{width:22px;height:22px}.notif-header h3{font-size:18px;color:var(--accent);margin:0}.notif-count{font-size:11px;color:var(--text-tertiary);margin-top:3px}.notif-close{width:40px;height:40px;border-radius:999px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.04);color:#fff;cursor:pointer;display:flex;align-items:center;justify-content:center}.notif-close svg{width:22px;height:22px;stroke:currentColor}.notif-list{flex:1;overflow:auto;padding:14px}.notif-item{position:relative;background:linear-gradient(135deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.035));border:1px solid rgba(var(--accent-rgb),.18);border-radius:22px;padding:14px 14px 13px;margin-bottom:12px;box-shadow:0 16px 36px rgba(0,0,0,.20)}.notif-message{font-size:13px;line-height:1.75;color:#e9e9ef}.notif-date{margin-top:9px;display:flex;align-items:center;gap:6px;color:var(--text-tertiary);font-size:10px;direction:ltr;justify-content:flex-end}.notif-date svg{width:13px;height:13px}.notif-empty{text-align:center;color:var(--text-tertiary);padding:70px 12px}.notif-empty svg{width:58px;height:58px;margin:0 auto 14px;stroke:currentColor;opacity:.45}
        .hero-band{max-width:1440px;margin:28px auto 0;padding:0 22px}.premium-hero{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.08);border-radius:34px;background:linear-gradient(135deg,rgba(255,255,255,.06),rgba(var(--accent-rgb),.09));box-shadow:var(--shadow-card);min-height:260px;display:flex;align-items:flex-end}.premium-hero:before{content:"";position:absolute;inset:-1px;background:radial-gradient(circle at 18% 10%,rgba(var(--accent-rgb),.30),transparent 36%),radial-gradient(circle at 84% 18%,rgba(255,255,255,.10),transparent 28%);pointer-events:none}.premium-hero:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,transparent,rgba(0,0,0,.42));pointer-events:none}.hero-content{position:relative;z-index:1;padding:34px;width:100%}.eyebrow{display:inline-flex;align-items:center;gap:8px;height:32px;padding:0 12px;border-radius:999px;background:rgba(var(--accent-rgb),.11);border:1px solid rgba(var(--accent-rgb),.20);color:var(--accent);font-size:12px;font-weight:900;margin-bottom:14px}.eyebrow svg{width:16px;height:16px;stroke:currentColor}.hero-title{font-size:clamp(2rem,5.5vw,4.4rem);line-height:1.08;font-weight:950;letter-spacing:-1.2px;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent;margin-bottom:12px}.hero-desc{max-width:720px;color:var(--text-secondary);font-size:15px;line-height:1.9}.hero-stats{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}.stat-pill{display:inline-flex;align-items:center;gap:8px;padding:9px 13px;border-radius:999px;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.09);color:#fff;font-size:12px;font-weight:850}.stat-pill svg{width:16px;height:16px;stroke:var(--accent)}
        .container,.movies-container{max-width:1440px;margin:0 auto;padding:30px 22px 70px}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin:0 0 24px;flex-wrap:wrap}.section-title{display:flex;align-items:center;gap:10px;font-size:18px;font-weight:950;color:var(--accent)}.section-title svg{width:21px;height:21px;stroke:currentColor}.section-subtitle{margin-top:6px;font-size:12px;color:var(--text-tertiary)}.search-box{position:relative;min-width:min(100%,360px);flex:0 1 420px}.search-box svg{position:absolute;inset-inline-start:16px;top:50%;transform:translateY(-50%);width:18px;height:18px;stroke:var(--text-tertiary)}.search-input{width:100%;height:48px;border-radius:999px;border:1px solid rgba(255,255,255,.08);background:rgba(16,17,22,.74);color:#fff;outline:none;font-family:inherit;font-size:13px;padding:0 46px;transition:.2s ease}.search-input:focus{border-color:var(--border-accent);box-shadow:0 0 0 4px var(--accent-glow)}
        .collections-grid,.movies-grid{display:grid;gap:22px}.collections-grid{grid-template-columns:repeat(auto-fill,minmax(185px,1fr))}.movies-grid{grid-template-columns:repeat(auto-fill,minmax(160px,1fr))}.collection-card,.movie-card{position:relative;display:block;text-decoration:none;color:inherit;border-radius:24px;background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.02));border:1px solid rgba(255,255,255,.075);overflow:hidden;box-shadow:0 16px 42px rgba(0,0,0,.22);transition:transform .25s ease,border-color .25s ease,box-shadow .25s ease,background .25s ease}.collection-card:hover,.movie-card:hover{transform:translateY(-7px);border-color:var(--border-accent);box-shadow:0 26px 70px rgba(0,0,0,.38),0 0 0 1px rgba(var(--accent-rgb),.06)}.poster-frame,.collection-cover-wrap{position:relative;aspect-ratio:2/3;background:linear-gradient(135deg,#181b24,#10121a);overflow:hidden}.poster-img,.collection-cover{width:100%;height:100%;object-fit:var(--collection-card-fit);display:block;transition:transform .38s ease,filter .28s ease}.collection-card:hover .collection-cover,.movie-card:hover .poster-img{transform:scale(1.055);filter:saturate(1.08)}.poster-frame:after,.collection-cover-wrap:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.22),transparent 34%,rgba(0,0,0,.76));pointer-events:none}.card-top-left,.card-top-right{position:absolute;top:10px;z-index:3}.card-top-left{left:10px}.card-top-right{right:10px}.year-badge,.imdb-badge,.collection-count-badge{height:28px;padding:0 9px;border-radius:999px;display:inline-flex;align-items:center;gap:6px;background:rgba(0,0,0,.64);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);font-size:11px;font-weight:950;color:#fff;direction:ltr;unicode-bidi:embed}.year-badge{color:var(--accent)}.imdb-badge{color:#fff;border-color:rgba(245,197,24,.22)}.imdb-badge svg{width:30px;height:15px}.bottom-tags{position:absolute;left:9px;right:9px;bottom:9px;z-index:4;display:flex;gap:6px;flex-wrap:wrap}.media-tag{height:26px;padding:0 8px;border-radius:999px;display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:950;background:rgba(0,0,0,.62);color:#fff;border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(9px);-webkit-backdrop-filter:blur(9px)}.media-tag svg{width:14px;height:14px;stroke:currentColor}.media-tag.dub{color:var(--accent);border-color:rgba(var(--accent-rgb),.22)}.media-tag.sub{color:#9cc7ff;border-color:rgba(156,199,255,.22)}.card-info{padding:13px 12px 14px}.card-title-fa,.movie-title-fa{font-size:13px;font-weight:950;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.card-title-en,.movie-title-en{margin-top:4px;font-size:10px;color:var(--text-tertiary);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:ltr;text-align:left}.card-meta,.movie-meta{margin-top:10px;display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:10px;color:var(--text-secondary)}.type-pill,.view-pill{display:inline-flex;align-items:center;gap:5px;border-radius:999px;background:var(--accent-glow);color:var(--accent);padding:4px 8px;font-size:10px;font-weight:950}.view-pill svg{width:12px;height:12px;stroke:currentColor}.empty-state{border:1px dashed rgba(255,255,255,.12);border-radius:28px;background:rgba(255,255,255,.03);padding:70px 20px;text-align:center;color:var(--text-tertiary)}.empty-state svg{width:62px;height:62px;margin:0 auto 16px;stroke:currentColor;opacity:.52}
        .collection-hero-wrap{position:relative;margin-top:0}.collection-cover-bg{position:absolute;inset:0;background-size:cover;background-position:center 24%;filter:blur(0);opacity:.38}.collection-hero-main{position:relative;min-height:430px;display:flex;align-items:flex-end;overflow:hidden;border-radius:0 0 38px 38px;border-bottom:1px solid rgba(255,255,255,.08);background:#08090d}.collection-hero-main:before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(8,9,13,.38),rgba(8,9,13,.68) 48%,#08090d 96%),radial-gradient(circle at 18% 22%,rgba(var(--accent-rgb),.24),transparent 34%)}.collection-hero-content{position:relative;z-index:2;max-width:1440px;width:100%;margin:0 auto;padding:112px 24px 42px}.collection-title{font-size:clamp(2rem,5.5vw,4.7rem);line-height:1.05;font-weight:950;letter-spacing:-1.4px;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent;max-width:850px}.collection-description{max-width:780px;margin-top:14px;color:#d5d7df;font-size:15px;line-height:1.9;text-shadow:0 1px 10px rgba(0,0,0,.35)}.sort-panel{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin-bottom:22px;padding:14px;border:1px solid rgba(255,255,255,.075);background:rgba(255,255,255,.035);border-radius:26px}.sort-buttons{display:flex;gap:8px;flex-wrap:wrap}.sort-btn{display:inline-flex;align-items:center;gap:7px;height:38px;padding:0 13px;border-radius:999px;border:1px solid rgba(255,255,255,.08);background:rgba(16,17,22,.70);color:var(--text-secondary);text-decoration:none;font-size:12px;font-weight:900;transition:.2s ease}.sort-btn svg{width:15px;height:15px;stroke:currentColor}.sort-btn:hover,.sort-btn.active{color:var(--accent);border-color:var(--border-accent);background:var(--accent-glow)}.movies-count{font-size:12px;color:var(--text-tertiary);font-weight:850}.quality-row{display:flex;gap:6px;flex-wrap:wrap}.site-footer{position:relative;z-index:1;margin:10px auto 0;max-width:1440px;padding:0 22px 28px}.footer-card{border:1px solid rgba(255,255,255,.08);background:linear-gradient(135deg,rgba(255,255,255,.055),rgba(var(--accent-rgb),.055));border-radius:32px;padding:24px;display:grid;grid-template-columns:1.4fr .9fr .9fr;gap:22px;box-shadow:0 24px 70px rgba(0,0,0,.24)}.footer-brand{display:flex;align-items:flex-start;gap:14px}.footer-logo{width:44px;height:44px;flex:0 0 auto}.footer-title{font-size:18px;font-weight:950;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent}.footer-text{margin-top:8px;color:var(--text-secondary);font-size:13px;line-height:1.9}.footer-block-title{font-size:13px;font-weight:950;color:var(--accent);margin-bottom:10px}.footer-links{display:flex;flex-direction:column;gap:9px}.footer-links a{text-decoration:none;color:var(--text-secondary);font-size:13px;transition:.2s}.footer-links a:hover{color:var(--accent);transform:translateX(-2px)}[dir="ltr"] .footer-links a:hover{transform:translateX(2px)}.footer-chip{display:inline-flex;width:max-content;align-items:center;gap:8px;padding:8px 10px;border-radius:999px;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.08);color:var(--text-secondary);font-size:12px;font-weight:850}.footer-chip svg{width:15px;height:15px;stroke:var(--accent)}
        /* V77: local collections footer-nav CSS removed; shared fixed nav owns it. */
        @media(min-width:992px){body{padding-bottom:0}.desktop-nav{display:flex}.auth-dropdown{display:block}.menu-btn{display:none!important}.bottom-nav{display:none!important}.header-inner{padding:0 28px}.collections-grid{grid-template-columns:repeat(auto-fill,minmax(205px,1fr))}.movies-grid{grid-template-columns:repeat(auto-fill,minmax(180px,1fr))}}
        @media(min-width:1440px){.collections-grid{grid-template-columns:repeat(auto-fill,minmax(220px,1fr))}.movies-grid{grid-template-columns:repeat(auto-fill,minmax(190px,1fr))}}
        @media(max-width:991px){.header-inner{height:66px}.desktop-nav,.auth-dropdown{display:none!important}.donate-btn span{display:none}.donate-btn{width:42px;padding:0}.hero-band{margin-top:18px;padding:0 14px}.premium-hero{border-radius:26px;min-height:230px}.hero-content{padding:25px 20px}.container,.movies-container{padding:24px 14px 54px}.collection-hero-main{min-height:360px;border-radius:0 0 28px 28px}.collection-hero-content{padding:96px 16px 32px}.footer-card{grid-template-columns:1fr}.site-footer{padding-bottom:106px}.sort-panel{align-items:stretch;flex-direction:column}.sort-buttons{overflow-x:auto;flex-wrap:nowrap;padding-bottom:2px}.sort-btn{white-space:nowrap}}
        @media(max-width:620px){.collections-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.movies-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.card-info{padding:10px 7px 11px}.card-title-fa,.movie-title-fa{font-size:10.5px}.card-title-en,.movie-title-en{font-size:8.5px}.card-meta,.movie-meta{display:none}.year-badge,.imdb-badge{height:23px;padding:0 7px;font-size:9px}.imdb-badge svg{width:25px;height:13px}.card-top-left,.card-top-right{top:7px}.card-top-left{left:7px}.card-top-right{right:7px}.bottom-tags{bottom:7px;left:7px;right:7px}.media-tag{height:22px;padding:0 6px;font-size:8.5px}.media-tag svg{width:12px;height:12px}.toolbar{align-items:stretch}.search-box{flex:1 1 100%;min-width:0}.hero-stats{gap:7px}.stat-pill{font-size:10px;padding:7px 9px}.footer-card{border-radius:26px;padding:18px}.nav-item{min-width:54px;padding-inline:7px}.nav-item.active{min-width:84px}.nav-label{font-size:9px;max-width:62px}}

        /* v148 collection stability patch */
        .page-shell{padding-top:92px!important}
        .hero-band{margin-top:0!important}
        .notif-bell{position:relative!important;width:42px!important;min-width:42px!important;height:42px!important;padding:0!important;overflow:visible!important}
        .notif-bell svg{width:20px!important;height:20px!important}
        .notif-badge{top:1px!important;right:1px!important;width:10px!important;min-width:10px!important;height:10px!important;padding:0!important;font-size:0!important;border:2px solid #0b0d14!important}
        .year-badge{width:auto!important;min-width:0!important;max-width:112px!important;height:24px!important;padding:0 8px!important;font-size:9.5px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;line-height:1!important}
        .collection-card[hidden]{display:none!important}
        .bm-load-more-wrap{display:flex;justify-content:center;margin:22px 0 4px}
        .bm-load-more-btn{min-width:170px;min-height:46px;padding:0 20px;border-radius:15px;border:1px solid rgba(var(--accent-rgb),.28);background:linear-gradient(135deg,rgba(var(--accent-rgb),.22),rgba(17,22,34,.96));color:#fff;font-family:inherit;font-size:13px;font-weight:950;cursor:pointer;box-shadow:0 14px 32px rgba(0,0,0,.28)}
        .bm-load-more-btn:hover{transform:translateY(-1px);border-color:rgba(var(--accent-rgb),.5)}
        @media(max-width:991px){.page-shell{padding-top:80px!important}.hero-band{padding-top:8px!important}.premium-hero{overflow:hidden!important}.hero-content{padding-top:30px!important}.eyebrow{position:static!important;max-width:100%!important}.notif-sidebar{z-index:25050!important}.notif-backdrop{z-index:25040!important}}
        @media(max-width:620px){.year-badge{max-width:86px!important;height:21px!important;padding:0 6px!important;font-size:8px!important}.card-top-right{right:7px!important}.bm-load-more-btn{min-width:150px;min-height:43px;font-size:12px}}
    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body data-theme="<?= e($userTheme) ?>">
<div class="bg-orb orb-1"></div>
<div class="bg-orb orb-2"></div>
<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu" aria-hidden="true">
    <div class="sidebar-header">
        <span class="logo-text">BankMovie</span>
        <button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="<?= $userLang==='fa'?'بستن':'Close' ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <?php if($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username'] ?? $t[$userLang]['account']) ?></div><div class="sidebar-userrole"><?= ($currentUser['role'] ?? '')==='admin' ? $t[$userLang]['admin_panel'] : $t[$userLang]['account'] ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/collections" class="sidebar-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="2" y1="16" x2="22" y2="16"/></svg><span><?= $t[$userLang]['collections'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span><?= $userLang==='fa'?'جستجوی پیشرفته':'Advanced Search' ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if(($currentUser['role'] ?? '') === 'admin'): ?><a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a><?php endif; ?>
        <?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang==='fa'?'آیا از خروج مطمئن هستید؟':'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-backdrop" id="notifBackdrop" hidden></div>
<div class="notif-sidebar" id="notifSidebar" aria-hidden="true">
    <div class="notif-header">
        <div class="notif-title-wrap"><div class="notif-title-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg></div><div><h3><?= $t[$userLang]['notifications'] ?></h3><div class="notif-count"><?= count($notificationsList) ?> <?= $t[$userLang]['active_notifications'] ?></div></div></div>
        <button type="button" class="notif-close" id="closeNotifSidebar" aria-label="<?= $userLang==='fa'?'بستن':'Close' ?>"><svg viewBox="0 0 24 24" fill="none"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item" data-notification-id="<?= (int)$notif['id'] ?>"><div class="notif-message"><?= nl2br(e($notif['message'])) ?></div><div class="notif-date"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg><?= date('Y/m/d H:i', strtotime($notif['created_at'])) ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="notif-empty"><svg viewBox="0 0 24 24" fill="none"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg><div><?= $t[$userLang]['no_notifications'] ?></div></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<main class="page-shell">
    <section class="hero-band">
        <div class="premium-hero">
            <div class="hero-content">
                <div class="eyebrow"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/></svg><?= $t[$userLang]['popular_collection'] ?></div>
                <h1 class="hero-title"><?= $t[$userLang]['special_collections'] ?></h1>
                <p class="hero-desc"><?= $userLang==='fa' ? 'مجموعه‌های سینمایی، دنباله‌های محبوب، جهان‌های مشترک و کالکشن‌های مرتب‌شده با ظاهر تازه و هماهنگ با صفحه اصلی.' : 'Cinematic universes, popular sequels, and curated collections with a polished BankMovie layout.' ?></p>
                <div class="hero-stats">
                    <span class="stat-pill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg><?= enNumbers($totalCollections) ?> <?= $t[$userLang]['collection'] ?></span>
                    <span class="stat-pill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg><?= enNumbers($totalMoviesInCollections) ?> <?= $t[$userLang]['titles'] ?></span>
                </div>
            </div>
        </div>
    </section>

    <section class="container">
        <div class="toolbar">
            <div><div class="section-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5z"/></svg><?= $t[$userLang]['all_collections'] ?></div><div class="section-subtitle"><?= $userLang==='fa' ? 'مجموعه‌های دنباله‌دار و فرنچایزهای محبوب را مرتب و یکجا مرور کنید.' : 'Header, footer, and cards now match the new index style.' ?></div></div>
            <div class="search-box"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><input class="search-input" id="collectionSearch" type="search" placeholder="<?= e($t[$userLang]['search_placeholder']) ?>"></div>
        </div>

        <?php if(count($collections) > 0): ?>
        <div class="collections-grid">
            <?php foreach($collections as $collectionIndex => $col): ?>
            <?php
                $title = $col['title_fa'] ?: ($col['title'] ?? '');
                $cover = bm_public_asset_url($col['cover_image'] ?? '', '');
                $range = '';
                if(!empty($col['first_year']) && !empty($col['last_year'])) {
                    $firstYear = enNumbers($col['first_year']);
                    $lastYear = enNumbers($col['last_year']);
                    $range = ($firstYear === $lastYear) ? $firstYear : ($firstYear.'–'.$lastYear);
                }
            ?>
            <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="collection-card" data-collection-card data-index="<?= (int)$collectionIndex ?>" <?= $collectionIndex >= 20 ? 'hidden' : '' ?> data-title="<?= e(($col['title'] ?? '').' '.($col['title_fa'] ?? '')) ?>">
                <div class="collection-cover-wrap">
                    <?php if($cover && bm_public_asset_renderable($cover)): ?>
                    <img class="collection-cover" src="<?= e($cover) ?>" loading="lazy" alt="<?= e($title) ?>">
                    <?php else: ?>
                    <div class="collection-cover" style="display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#1a1d28,#10121a)"><svg width="46" height="46" viewBox="0 0 24 24" fill="none" stroke="#737784"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/></svg></div>
                    <?php endif; ?>
                    <span class="card-top-left collection-count-badge"><?= enNumbers($col['movie_count'] ?? 0) ?> <?= $t[$userLang]['movies'] ?></span>
                    <?php if($range): ?><span class="card-top-right year-badge"><?= e($range) ?></span><?php endif; ?>
                    <div class="bottom-tags"><span class="media-tag dub"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3v18M8 7v10M16 7v10M4 10v4M20 10v4"/></svg><?= $t[$userLang]['collection'] ?></span></div>
                </div>
                <div class="card-info">
                    <div class="card-title-fa"><?= e($title) ?></div>
                    <div class="card-title-en"><?= e($col['title'] ?? '') ?></div>
                    <div class="card-meta"><span class="view-pill"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14"/><path d="M12 5l7 7-7 7"/></svg><?= $t[$userLang]['view_collection'] ?></span></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
        <?php if(count($collections) > 20): ?>
        <div class="bm-load-more-wrap"><button type="button" id="bmLoadMoreCollections" class="bm-load-more-btn">نمایش ۲۰ کالکشن بعدی</button></div>
        <?php endif; ?>
        <?php else: ?>
        <div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= $userLang==='fa'?'هنوز کالکشنی ایجاد نشده است.':'No collections have been created yet.' ?></p></div>
        <?php endif; ?>
    </section>
</main>
<?php if (function_exists('bm_render_support_card') && bm_site_bool('support_before_footer', true)) { bm_render_support_card('collections.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<script>
const userLang = <?= json_encode($userLang, JSON_UNESCAPED_UNICODE) ?>;
const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
function showToast(message){
    const box=document.getElementById('toastContainer'); if(!box) return;
    const item=document.createElement('div'); item.className='toast'; item.textContent=message;
    box.appendChild(item); setTimeout(()=>{item.style.opacity='0'; item.style.transform='translateY(-6px)';},2400); setTimeout(()=>item.remove(),2850);
}
function setupMenu(){
    const menuBtn=document.getElementById('menuBtn'), sidebar=document.getElementById('sidebarMenu'), overlay=document.getElementById('menuOverlay'), closeBtn=document.getElementById('closeMenuBtn');
    if(!menuBtn||!sidebar||!overlay||!closeBtn) return;
    const open=()=>{ if(window.matchMedia('(min-width: 992px)').matches) return; sidebar.classList.add('open'); overlay.classList.add('active'); document.body.style.overflow='hidden'; menuBtn.setAttribute('aria-expanded','true'); sidebar.setAttribute('aria-hidden','false'); };
    const close=()=>{ sidebar.classList.remove('open'); overlay.classList.remove('active'); document.body.style.overflow=''; menuBtn.setAttribute('aria-expanded','false'); sidebar.setAttribute('aria-hidden','true'); };
    menuBtn.addEventListener('click',open); closeBtn.addEventListener('click',close); overlay.addEventListener('click',close); window.addEventListener('resize',()=>{ if(window.innerWidth>=992) close(); }); document.addEventListener('keydown',e=>{ if(e.key==='Escape') close(); });
}
function setupNotifications(){
    const bell=document.getElementById('notifBell'), panel=document.getElementById('notifSidebar'), backdrop=document.getElementById('notifBackdrop'), closeBtn=document.getElementById('closeNotifSidebar');
    if(!bell||!panel||!backdrop||!closeBtn) return;
    const latestId = panel.querySelector('.notif-item')?.dataset.notificationId || '';
    const markSeen=()=>{
        const badge=bell.querySelector('.notif-badge'); if(badge) badge.remove();
        if(latestId){ document.cookie=`notification_seen_${latestId}=1; path=/; max-age=${60*60*24*30}; SameSite=Lax`; fetch('/mark_notification_seen.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:`notification_id=${encodeURIComponent(latestId)}&csrf_token=${encodeURIComponent(csrfToken)}`}).catch(()=>{}); }
    };
    const open=()=>{ panel.classList.add('open'); backdrop.hidden=false; document.body.style.overflow='hidden'; panel.setAttribute('aria-hidden','false'); markSeen(); };
    const close=()=>{ panel.classList.remove('open'); backdrop.hidden=true; document.body.style.overflow=''; panel.setAttribute('aria-hidden','true'); };
    bell.addEventListener('click',open); closeBtn.addEventListener('click',close); backdrop.addEventListener('click',close); document.addEventListener('keydown',e=>{ if(e.key==='Escape') close(); });
}
/* V77: legacy collections scroll-driven footer-nav controller removed. */
function setupHeader(){
    const header=document.getElementById('siteHeader'); if(!header) return;
    const update=()=> header.classList.toggle('header-solid', window.scrollY>18);
    update(); window.addEventListener('scroll',update,{passive:true});
}
function setupDonate(){
    const btn=document.getElementById('donateBtn'); if(!btn) return;
    btn.addEventListener('click',()=>showToast(userLang==='fa'?'بخش حمایت مالی آماده اتصال به لینک پرداخت است.':'Donation link is ready to be connected.'));
}
function setupCollectionSearch(){
    const input=document.getElementById('collectionSearch');
    const button=document.getElementById('bmLoadMoreCollections');
    const cards=[...document.querySelectorAll('[data-collection-card]')];
    if(!cards.length) return;
    let visibleCount=20;
    const render=()=>{
        const q=(input?.value||'').trim().toLowerCase();
        cards.forEach((card,index)=>{
            const matches=!q || (card.dataset.title||'').toLowerCase().includes(q);
            card.hidden = q ? !matches : index>=visibleCount;
        });
        if(button){
            button.hidden=!!q || visibleCount>=cards.length;
            button.textContent='نمایش ۲۰ کالکشن بعدی';
        }
    };
    if(button) button.addEventListener('click',()=>{visibleCount=Math.min(visibleCount+20,cards.length);render();});
    if(input) input.addEventListener('input',render);
    render();
}
document.addEventListener('DOMContentLoaded',()=>{setupHeader();setupMenu();setupNotifications();setupDonate();setupCollectionSearch();});
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
