<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/yektanet_control.php';
require_once __DIR__ . '/app/download.php';
require_admin();
admin_enforce_csrf();

$csrf = admin_csrf_token();

function bm_cc_h($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function bm_cc_bool($value): bool { return filter_var($value, FILTER_VALIDATE_BOOLEAN); }
function bm_cc_redirect(string $message, string $type = 'success', string $tab = 'overview'): never {
    header('Location: admin_control_center.php?' . http_build_query(['msg'=>$message,'type'=>$type,'tab'=>$tab]));
    exit;
}
function bm_cc_atomic_json_write(string $path, array $data): bool {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (!is_string($json)) return false;
    $dir = dirname($path);
    if (!is_dir($dir) && !@mkdir($dir, 0755, true)) return false;
    $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
    if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) { @unlink($tmp); return false; }
    @chmod($tmp, 0644);
    if (@rename($tmp, $path)) return true;
    @unlink($tmp);
    return false;
}
function bm_cc_clean_url(string $url, bool $allowEmpty = true): string {
    $url = trim($url);
    if ($url === '' && $allowEmpty) return '';
    return function_exists('bm_security_safe_url') ? bm_security_safe_url($url, ['http','https']) : (filter_var($url, FILTER_VALIDATE_URL) ? $url : '');
}
function bm_cc_lines(string $text): array {
    $items = preg_split('/\R+|[,،]+/u', $text) ?: [];
    $out = [];
    foreach ($items as $item) { $item = trim(strip_tags((string)$item)); if ($item !== '') $out[] = $item; }
    return array_values(array_unique($out));
}
function bm_cc_load_app_config(): array {
    $path = __DIR__ . '/bankmovie_remote_config.json';
    $raw = is_file($path) ? @file_get_contents($path) : false;
    $data = is_string($raw) ? json_decode($raw, true) : null;
    return is_array($data) ? $data : [];
}
function bm_cc_delete_inside(string $baseDir, string $name, array $allowedExts): bool {
    $name = basename($name);
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, $allowedExts, true)) return false;
    $base = realpath($baseDir);
    $target = realpath($baseDir . DIRECTORY_SEPARATOR . $name);
    if (!$base || !$target || !str_starts_with($target, $base . DIRECTORY_SEPARATOR) || !is_file($target)) return false;
    return @unlink($target);
}
function bm_cc_clear_archive_cache(): int {
    $deleted = 0;
    $patterns = [];
    if (function_exists('bm_security_private_dir')) {
        $private = bm_security_private_dir();
        $patterns[] = $private . '/api2_html_*.cache*';
        $patterns[] = $private . '/api2_json_*.cache*';
        $patterns[] = $private . '/cache/api6/*.html';
        $patterns[] = $private . '/cache/api6/*.html.gz';
        $patterns[] = $private . '/cache/api6/*.tmp';
        $patterns[] = $private . '/api2_html_*.cache.lock';
        $patterns[] = $private . '/api2_json_*.cache.lock';
    }
    $tmp = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR);
    $patterns[] = $tmp . '/bankmovie_a1_*.json';
    foreach ($patterns as $pattern) {
        foreach (glob($pattern) ?: [] as $file) if (is_file($file) && @unlink($file)) $deleted++;
    }
    return $deleted;
}
function bm_cc_upload_release(array $file, string $preferredName = ''): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || empty($file['tmp_name'])) throw new RuntimeException('فایل سالم دریافت نشد. محدودیت upload_max_filesize و post_max_size هاست را بررسی کنید.');
    $original = basename((string)($file['name'] ?? ''));
    $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
    if (!in_array($ext, ['apk','zip'], true)) throw new RuntimeException('فقط فایل APK یا ZIP مجاز است.');
    $size = (int)($file['size'] ?? 0);
    if ($size < 1 || $size > 1500 * 1024 * 1024) throw new RuntimeException('حجم فایل نامعتبر یا بیشتر از ۱.۵ گیگابایت است.');
    $name = trim($preferredName);
    if ($name === '') $name = pathinfo($original, PATHINFO_FILENAME);
    $name = preg_replace('/[^A-Za-z0-9._-]+/', '-', $name) ?: ('bankmovie-' . date('Ymd-His'));
    $name = trim($name, '.-_');
    if ($name === '') $name = 'bankmovie-' . date('Ymd-His');
    $targetName = $name . '.' . $ext;
    $target = __DIR__ . '/app/' . $targetName;
    if (!is_dir(__DIR__ . '/app') && !@mkdir(__DIR__ . '/app', 0755, true)) throw new RuntimeException('پوشه app قابل ایجاد نیست.');
    if (!@move_uploaded_file((string)$file['tmp_name'], $target)) throw new RuntimeException('ذخیره فایل در پوشه app ناموفق بود. Permission را بررسی کنید.');
    @chmod($target, 0644);
    return $targetName;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_yektanet') {
            $defaults = bm_yektanet_defaults();
            $settings = [
                'enabled' => isset($_POST['yk_enabled']),
                'publisher_url' => (string)($_POST['publisher_url'] ?? ''),
                'domains' => ['bankmoviee.ir'],
                'policy_version' => 8,
                'pages' => array_values(array_intersect((array)($_POST['pages'] ?? []), $defaults['pages'])),
                'slots' => [],
            ];
            foreach ($defaults['slots'] as $id => $def) {
                $settings['slots'][$id] = [
                    'enabled' => isset($_POST['slot_enabled'][$id]),
                    'device' => (string)($_POST['slot_device'][$id] ?? $def['device']),
                    'html' => (string)($_POST['slot_html'][$id] ?? ''),
                ];
            }
            if (!bm_yektanet_save_settings($settings)) throw new RuntimeException('فایل تنظیمات یکتانت قابل نوشتن نیست.');
            bm_cc_redirect('تنظیمات یکتانت ذخیره شد.', 'success', 'ads');
        }

        if ($action === 'save_app') {
            $config = bm_cc_load_app_config();
            $activeDomain = bm_cc_clean_url((string)($_POST['active_domain'] ?? ''), false);
            $apiUrl = bm_cc_clean_url((string)($_POST['api_url'] ?? ''), false);
            if ($activeDomain === '' || $apiUrl === '') throw new RuntimeException('دامنه فعال و آدرس API باید URL معتبر باشند.');
            $servers = [];
            for ($i=0; $i<2; $i++) {
                $domain = bm_cc_clean_url((string)($_POST['server_domain'][$i] ?? ''));
                $serverApi = bm_cc_clean_url((string)($_POST['server_api'][$i] ?? ''));
                if ($domain === '' || $serverApi === '') continue;
                $servers[] = [
                    'name' => trim(strip_tags((string)($_POST['server_name'][$i] ?? ('سرور ' . ($i+1))))) ?: ('سرور ' . ($i+1)),
                    'enabled' => isset($_POST['server_enabled'][$i]),
                    'priority' => max(1, min(99, (int)($_POST['server_priority'][$i] ?? ($i+1)))),
                    'domain' => $domain,
                    'api_url' => $serverApi,
                ];
            }
            if (!$servers) throw new RuntimeException('حداقل یک سرور معتبر لازم است.');
            usort($servers, static fn($a,$b) => $a['priority'] <=> $b['priority']);
            $config['schema_version'] = max(3, (int)($config['schema_version'] ?? 3));
            $config['ready'] = isset($_POST['app_ready']);
            $config['message'] = trim(strip_tags((string)($_POST['app_message'] ?? '')));
            $config['active_domain'] = $activeDomain;
            $config['api_url'] = $apiUrl;
            $config['servers'] = $servers;
            $config['notice'] = [
                'enabled' => isset($_POST['notice_enabled']),
                'id' => preg_replace('/[^A-Za-z0-9_-]/', '', (string)($_POST['notice_id'] ?? '')),
                'title' => trim(strip_tags((string)($_POST['notice_title'] ?? ''))),
                'message' => trim(strip_tags((string)($_POST['notice_message'] ?? ''))),
            ];
            $config['update'] = [
                'enabled' => isset($_POST['update_enabled']),
                'version_code' => max(0, (int)($_POST['version_code'] ?? 0)),
                'version_name' => trim(strip_tags((string)($_POST['version_name'] ?? ''))),
                'apk_url' => bm_cc_clean_url((string)($_POST['apk_url'] ?? '')),
                'apk_urls' => [
                    'universal' => bm_cc_clean_url((string)($_POST['apk_universal'] ?? '')),
                    'arm64_v8a' => bm_cc_clean_url((string)($_POST['apk_arm64'] ?? '')),
                    'armeabi_v7a' => bm_cc_clean_url((string)($_POST['apk_v7a'] ?? '')),
                ],
                'force' => isset($_POST['update_force']),
                'title' => trim(strip_tags((string)($_POST['update_title'] ?? ''))),
                'message' => trim(strip_tags((string)($_POST['update_message'] ?? ''))),
                'changes' => bm_cc_lines((string)($_POST['changes'] ?? '')),
            ];
            $config['version_policy'] = [
                'enabled' => isset($_POST['policy_enabled']),
                'minimum_version_code' => max(0, (int)($_POST['minimum_version_code'] ?? 0)),
                'minimum_version_name' => trim(strip_tags((string)($_POST['minimum_version_name'] ?? ''))),
                'blocked_version_names' => bm_cc_lines((string)($_POST['blocked_version_names'] ?? '')),
                'blocked_version_codes' => array_values(array_map('intval', bm_cc_lines((string)($_POST['blocked_version_codes'] ?? '')))),
                'force_update_blocked' => isset($_POST['force_update_blocked']),
                'block_message' => trim(strip_tags((string)($_POST['block_message'] ?? ''))),
            ];
            $config['updated_at'] = gmdate('c');
            if (!bm_cc_atomic_json_write(__DIR__ . '/bankmovie_remote_config.json', $config)) throw new RuntimeException('ذخیره bankmovie_remote_config.json ناموفق بود.');
            bm_cc_redirect('تنظیمات اپلیکیشن ذخیره شد.', 'success', 'app');
        }

        if ($action === 'upload_release') {
            $name = bm_cc_upload_release($_FILES['release_file'] ?? [], (string)($_POST['release_name'] ?? ''));
            bm_cc_redirect('فایل انتشار «' . $name . '» آپلود شد.', 'success', 'app');
        }

        if ($action === 'delete_release') {
            $name = basename((string)($_POST['release_file_name'] ?? ''));
            if (!bm_cc_delete_inside(__DIR__ . '/app', $name, ['apk','zip'])) throw new RuntimeException('حذف فایل انجام نشد.');
            bm_cc_redirect('فایل انتشار حذف شد.', 'success', 'app');
        }

        if ($action === 'save_archives') {
            $settings = bm_archive_get_settings();
            foreach (['archive1','archive2','archive3','archive4'] as $id) {
                $old = is_array($settings['archives'][$id] ?? null) ? $settings['archives'][$id] : [];
                $scope = strtolower(trim((string)($_POST['archive_scope'][$id] ?? ($old['access_scope'] ?? 'public'))));
                if (!in_array($scope, ['public','member','vip','admin'], true)) $scope = 'public';
                $settings['archives'][$id] = array_merge($old, [
                    'label' => trim(strip_tags((string)($_POST['archive_label'][$id] ?? $id))),
                    'enabled' => isset($_POST['archive_enabled'][$id]),
                    'access_scope' => $scope,
                    'disabled_mode' => in_array((string)($_POST['archive_mode'][$id] ?? ''), ['visible','hide'], true) ? (string)$_POST['archive_mode'][$id] : 'visible',
                    'disabled_message' => trim(strip_tags((string)($_POST['archive_message'][$id] ?? ''))),
                ]);
            }
            if (!bm_archive_save_settings($settings)) throw new RuntimeException('ذخیره تنظیمات آرشیوها ناموفق بود.');
            bm_cc_redirect('وضعیت آرشیوها ذخیره شد.', 'success', 'archives');
        }

        if ($action === 'clear_archive_cache') {
            $count = bm_cc_clear_archive_cache();
            bm_cc_redirect($count . ' فایل کش آرشیو پاک شد.', 'success', 'archives');
        }
    } catch (Throwable $e) {
        bm_cc_redirect($e->getMessage(), 'error', in_array($action, ['save_yektanet'], true) ? 'ads' : (str_contains($action, 'archive') || str_contains($action, 'cookie') ? 'archives' : 'app'));
    }
}

$tab = (string)($_GET['tab'] ?? 'overview');
if (!in_array($tab, ['overview','ads','app','archives','tools'], true)) $tab = 'overview';
$message = trim((string)($_GET['msg'] ?? ''));
$messageType = (string)($_GET['type'] ?? 'success');
$yk = bm_yektanet_get_settings();
$appConfig = bm_cc_load_app_config();
$appConfig += ['ready'=>true,'message'=>'','active_domain'=>'https://bankmovie.top','api_url'=>'https://bankmovie.top/app_api.php','servers'=>[],'notice'=>[],'update'=>[],'version_policy'=>[]];
$appConfig['notice'] = is_array($appConfig['notice']) ? $appConfig['notice'] : [];
$appConfig['update'] = is_array($appConfig['update']) ? $appConfig['update'] : [];
$appConfig['version_policy'] = is_array($appConfig['version_policy']) ? $appConfig['version_policy'] : [];
$servers = array_values(is_array($appConfig['servers']) ? $appConfig['servers'] : []);
while (count($servers) < 2) $servers[] = ['name'=>'','enabled'=>false,'priority'=>count($servers)+1,'domain'=>'','api_url'=>''];
$archiveSettings = bm_archive_get_settings();
$releaseFiles = array_merge(glob(__DIR__ . '/app/*.apk') ?: [], glob(__DIR__ . '/app/*.zip') ?: []);
usort($releaseFiles, static fn($a,$b) => ((int)@filemtime($b)) <=> ((int)@filemtime($a)));
$releaseMeta = function_exists('bm_latest_update') ? bm_latest_update() : ['version'=>'','build'=>0,'downloads'=>[]];
$dirs = [
    'پوشه خصوصی' => function_exists('bm_security_private_dir') ? bm_security_private_dir() : __DIR__,
    'پوشه اپ' => __DIR__ . '/app',
    'پوشه کش' => __DIR__ . '/cache',
    'پوشه آپلود' => __DIR__ . '/uploads',
];
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>مرکز کنترل کامل | BankMovie</title>
<style>
:root{--bg:#070a11;--panel:#111725;--panel2:#0c111d;--line:rgba(255,255,255,.1);--text:#f7f9ff;--muted:#a8b2c7;--accent:#2f7cff;--green:#24d17e;--red:#ff5d73;--yellow:#ffc857}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% 0,rgba(47,124,255,.18),transparent 30%),var(--bg);color:var(--text);font-family:Tahoma,Arial,sans-serif}.layout{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh}.side{position:sticky;top:0;height:100vh;padding:22px 16px;background:rgba(8,12,20,.92);border-left:1px solid var(--line);overflow:auto}.brand{font-size:22px;font-weight:900;margin:4px 10px 24px}.brand span{color:var(--accent)}.nav{display:grid;gap:7px}.nav a{color:var(--muted);text-decoration:none;padding:12px 14px;border-radius:13px;font-weight:700}.nav a:hover,.nav a.active{background:rgba(47,124,255,.14);color:#fff}.nav hr{width:100%;border:0;border-top:1px solid var(--line);margin:10px 0}.main{padding:28px;width:min(1400px,100%);margin:auto}.hero{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:22px}.hero h1{margin:0 0 8px;font-size:30px}.hero p{margin:0;color:var(--muted);line-height:1.8}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:0 15px;border-radius:12px;border:1px solid var(--line);background:#182134;color:#fff;text-decoration:none;font:inherit;font-weight:800;cursor:pointer}.btn.primary{background:var(--accent);border-color:transparent}.btn.danger{background:rgba(255,93,115,.14);color:#ff9baa}.btn.good{background:rgba(36,209,126,.14);color:#86f0ba}.flash{padding:13px 16px;border-radius:14px;margin-bottom:18px;border:1px solid}.flash.success{background:rgba(36,209,126,.12);border-color:rgba(36,209,126,.35)}.flash.error{background:rgba(255,93,115,.12);border-color:rgba(255,93,115,.35)}.grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}.card{grid-column:span 12;background:linear-gradient(180deg,rgba(19,27,43,.95),rgba(12,17,29,.95));border:1px solid var(--line);border-radius:20px;padding:20px;box-shadow:0 18px 55px rgba(0,0,0,.22)}.card.half{grid-column:span 6}.card.third{grid-column:span 4}.card h2,.card h3{margin:0 0 8px}.sub{color:var(--muted);font-size:13px;line-height:1.8;margin:0 0 16px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat{padding:16px;border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.03)}.stat b{font-size:21px;display:block}.stat small{color:var(--muted)}.form-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:13px}.field{grid-column:span 6}.field.full{grid-column:span 12}.field.third{grid-column:span 4}.field label{display:block;margin-bottom:7px;color:#dbe4f7;font-size:13px;font-weight:800}.field input[type=text],.field input[type=url],.field input[type=number],.field textarea,.field select{width:100%;background:#080d17;border:1px solid var(--line);border-radius:12px;color:#fff;padding:11px 12px;font:inherit}.field textarea{min-height:120px;resize:vertical;direction:ltr;text-align:left}.field textarea.fa{direction:rtl;text-align:right}.check{display:flex;gap:9px;align-items:center;min-height:42px}.check input{width:18px;height:18px}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}.slot{border:1px solid var(--line);border-radius:16px;padding:15px;margin-top:13px}.slot-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:10px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:11px;border-bottom:1px solid var(--line);text-align:right;font-size:13px}.badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:900}.badge.on{background:rgba(36,209,126,.14);color:#82efb7}.badge.off{background:rgba(255,93,115,.13);color:#ff9baa}.code{direction:ltr;text-align:left;font-family:monospace;font-size:12px;word-break:break-all}.tabs-mobile{display:none;gap:7px;overflow:auto;margin-bottom:16px}.tabs-mobile a{white-space:nowrap}.tab{display:none}.tab.active{display:block}.tool-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.tool{display:block;text-decoration:none;color:#fff;padding:17px;border:1px solid var(--line);border-radius:16px;background:rgba(255,255,255,.035)}.tool b{display:block;margin-bottom:6px}.tool span{color:var(--muted);font-size:12px;line-height:1.7}@media(max-width:980px){.layout{display:block}.side{display:none}.main{padding:18px}.tabs-mobile{display:flex}.card.half,.card.third{grid-column:span 12}.stats{grid-template-columns:repeat(2,1fr)}.field,.field.third{grid-column:span 12}.tool-grid{grid-template-columns:1fr}.hero{display:block}.hero .actions{margin-top:12px}}@media(max-width:520px){.stats{grid-template-columns:1fr}.card{padding:15px}.table{display:block;overflow:auto}}
</style>
<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>
<style id="bm-archive-manager-v14861927">
.archive-manager-hero{position:relative;overflow:hidden;padding:24px!important;background:linear-gradient(135deg,rgba(47,124,255,.18),rgba(124,92,255,.10) 52%,rgba(34,211,238,.08))!important;border-color:rgba(86,153,255,.26)!important}.archive-manager-hero:before{content:"";position:absolute;width:260px;height:260px;border-radius:50%;background:rgba(47,124,255,.12);filter:blur(10px);left:-100px;top:-150px}.archive-manager-title{display:flex;align-items:center;gap:14px}.archive-manager-icon{width:48px;height:48px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(135deg,#2f7cff,#6d5cff);box-shadow:0 14px 34px rgba(47,124,255,.26);font-size:22px}.archive-manager-kpis{display:flex;gap:9px;flex-wrap:wrap;margin-top:16px}.archive-kpi{display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border-radius:999px;border:1px solid rgba(255,255,255,.10);background:rgba(3,9,20,.34);color:#cbd8ef;font-size:12px;font-weight:800}.archive-card{position:relative;overflow:hidden;padding:18px!important;border-color:rgba(85,142,255,.18)!important;background:linear-gradient(180deg,rgba(20,29,47,.96),rgba(10,15,27,.96))!important;transition:transform .18s ease,border-color .18s ease,box-shadow .18s ease}.archive-card:hover{transform:translateY(-2px);border-color:rgba(84,147,255,.34)!important;box-shadow:0 22px 48px rgba(0,0,0,.22)}.archive-card:after{content:"";position:absolute;width:150px;height:150px;border-radius:50%;background:rgba(47,124,255,.10);filter:blur(10px);left:-70px;top:-80px;pointer-events:none}.archive-card-top{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;margin-bottom:16px}.archive-card-name{display:flex;align-items:center;gap:11px}.archive-num{width:42px;height:42px;border-radius:14px;display:grid;place-items:center;background:rgba(47,124,255,.13);border:1px solid rgba(47,124,255,.25);color:#8eb8ff;font-weight:900}.archive-card h3{margin:0!important;font-size:18px}.archive-card small{display:block;color:var(--muted);margin-top:4px}.archive-state{display:inline-flex;align-items:center;gap:7px;padding:7px 10px;border-radius:999px;font-size:11px;font-weight:900;border:1px solid}.archive-state.on{color:#8cf0bb;background:rgba(36,209,126,.10);border-color:rgba(36,209,126,.24)}.archive-state.off{color:#ff9baa;background:rgba(255,93,115,.10);border-color:rgba(255,93,115,.24)}.archive-state:before{content:"";width:7px;height:7px;border-radius:50%;background:currentColor;box-shadow:0 0 14px currentColor}.archive-toggle-box{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 13px;border-radius:14px;background:rgba(255,255,255,.035);border:1px solid var(--line);margin-bottom:13px}.archive-toggle-box .check{margin:0;min-height:auto}.archive-audience{margin-top:12px;padding:13px;border:1px solid rgba(47,124,255,.20);border-radius:15px;background:rgba(47,124,255,.055)}.archive-audience-label{font-size:12px;font-weight:900;color:#dce8ff;margin-bottom:9px}.archive-segments{display:grid;grid-template-columns:1fr 1fr;gap:7px}.archive-segment{position:relative;cursor:pointer}.archive-segment input{position:absolute;opacity:0;pointer-events:none}.archive-segment span{display:flex;align-items:center;justify-content:center;min-height:41px;border:1px solid var(--line);border-radius:12px;background:#0a1020;color:var(--muted);font-size:12px;font-weight:900;transition:.16s ease}.archive-segment input:checked+span{background:linear-gradient(135deg,rgba(47,124,255,.28),rgba(109,92,255,.22));border-color:rgba(89,153,255,.56);color:#fff;box-shadow:inset 0 0 0 1px rgba(255,255,255,.04),0 8px 22px rgba(47,124,255,.14)}.archive-fixed-public{padding:10px 12px;border-radius:12px;background:rgba(36,209,126,.06);border:1px solid rgba(36,209,126,.16);color:#a9eac9;font-size:12px;font-weight:800}.archive-connect-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.archive-connect-card{border:1px solid var(--line);border-radius:18px;padding:18px;background:linear-gradient(180deg,rgba(18,26,43,.94),rgba(10,15,26,.94))}.archive-connect-card h3{display:flex;align-items:center;gap:8px}.archive-connect-status{display:inline-flex;margin-top:7px;padding:5px 9px;border-radius:999px;background:rgba(36,209,126,.09);color:#8cf0bb;font-size:11px;font-weight:900}.archive-savebar{position:sticky;bottom:14px;z-index:20;margin-top:16px;padding:12px 14px;border-radius:17px;border:1px solid rgba(70,139,255,.26);background:rgba(8,13,24,.86);backdrop-filter:blur(18px);box-shadow:0 18px 45px rgba(0,0,0,.28);display:flex;align-items:center;justify-content:space-between;gap:12px}.archive-savebar .sub{margin:0}.archive-manager-note{padding:13px 14px;border-radius:14px;border:1px solid rgba(255,200,87,.18);background:rgba(255,200,87,.055);color:#dbc98c;font-size:12px;line-height:1.8}@media(max-width:760px){.archive-connect-grid{grid-template-columns:1fr}.archive-savebar{align-items:stretch;flex-direction:column}.archive-savebar .btn{width:100%}.archive-card-top{align-items:center}.archive-manager-title{align-items:flex-start}}
</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<div class="layout">
<aside class="side"><div class="brand">Bank<span>Movie</span></div><nav class="nav">
<?php foreach (['overview'=>'نمای کلی','ads'=>'تبلیغات یکتانت','app'=>'مدیریت اپ','archives'=>'مدیریت آرشیوها','tools'=>'همه ابزارها'] as $id=>$label): ?><a class="<?= $tab===$id?'active':'' ?>" href="?tab=<?= $id ?>"><?= $label ?></a><?php endforeach; ?>
<hr><a href="admin.php">پنل اصلی</a><a href="/">مشاهده سایت</a><a href="/logout">خروج</a></nav></aside>
<main class="main">
<div class="hero"><div><h1>مرکز کنترل کامل بانک‌مووی</h1><p>مدیریت تبلیغات، اپلیکیشن، آرشیوها و دسترسی سریع به تمام ابزارهای مدیریتی.</p></div><div class="actions"><a class="btn" href="admin.php">پنل اصلی</a><a class="btn primary" href="/" target="_blank">مشاهده سایت</a></div></div>
<div class="tabs-mobile"><?php foreach (['overview'=>'نمای کلی','ads'=>'تبلیغات','app'=>'اپ','archives'=>'آرشیوها','tools'=>'ابزارها'] as $id=>$label): ?><a class="btn <?= $tab===$id?'primary':'' ?>" href="?tab=<?= $id ?>"><?= $label ?></a><?php endforeach; ?></div>
<?php if ($message !== ''): ?><div class="flash <?= $messageType==='error'?'error':'success' ?>"><?= bm_cc_h($message) ?></div><?php endif; ?>

<section class="tab <?= $tab==='overview'?'active':'' ?>">
<div class="grid"><div class="card"><h2>وضعیت سریع</h2><p class="sub">مهم‌ترین وضعیت‌های قابل کنترل از همین صفحه.</p><div class="stats">
<div class="stat"><b><?= !empty($yk['enabled'])?'فعال':'خاموش' ?></b><small>اسکریپت یکتانت</small></div>
<div class="stat"><b><?= count(array_filter($yk['slots'], fn($s)=>!empty($s['enabled']) && trim((string)$s['html'])!=='')) ?></b><small>جایگاه فعال یکتانت</small></div>
<div class="stat"><b><?= !empty($appConfig['ready'])?'آنلاین':'توقف' ?></b><small>وضعیت اپ</small></div>
<div class="stat"><b><?= count(array_filter($archiveSettings['archives'], fn($a)=>!empty($a['enabled']))) ?>/4</b><small>آرشیو فعال</small></div>
</div></div>
<div class="card half"><h3>انتشار فعلی اپ</h3><p class="sub">نسخه تشخیص داده‌شده از JSON یا فایل‌های پوشه app.</p><table class="table"><tr><th>نسخه</th><td><?= bm_cc_h($releaseMeta['version'] ?? 'نامشخص') ?></td></tr><tr><th>Build</th><td><?= (int)($releaseMeta['build'] ?? 0) ?></td></tr><tr><th>فایل‌ها</th><td><?= count($releaseFiles) ?></td></tr></table><div class="actions"><a class="btn primary" href="?tab=app">مدیریت اپ</a><a class="btn" href="/application" target="_blank">صفحه اپ</a></div></div>
<div class="card half"><h3>آرشیوها</h3><p class="sub">فعال یا غیرفعال‌بودن چهار منبع محتوایی.</p><table class="table"><?php foreach($archiveSettings['archives'] as $id=>$row): ?><tr><th><?= bm_cc_h($row['label']) ?></th><td><span class="badge <?= !empty($row['enabled'])?'on':'off' ?>"><?= !empty($row['enabled'])?'فعال':'غیرفعال' ?></span></td></tr><?php endforeach; ?></table><div class="actions"><a class="btn primary" href="?tab=archives">مدیریت آرشیوها</a></div></div>
<div class="card"><h3>ابزارهای مدیریت موجود</h3><div class="tool-grid"><a class="tool" href="admin_site_manager.php"><b>مدیریت ظاهر و متن‌ها</b><span>کنترل هدر، فوتر، صفحه‌ها، PWA، جستجو و متن‌های عمومی</span></a><a class="tool" href="admin.php"><b>محتوا و کاربران</b><span>فیلم، سریال، استوری، درخواست‌ها، نظرات، بنر داخلی و کاربران</span></a><a class="tool" href="admin_slider.php"><b>اسلایدر</b><span>افزودن، ویرایش، ترتیب و فعال‌سازی اسلایدها</span></a><a class="tool" href="admin_collections.php"><b>کالکشن‌ها</b><span>ساخت کالکشن و مدیریت فیلم‌های داخل آن</span></a><a class="tool" href="api_manager.php"><b>API و منابع</b><span>تنظیم منابع و بررسی وضعیت APIها</span></a><a class="tool" href="admin_sitemap.php"><b>سایت‌مپ</b><span>ساخت، بازسازی و بررسی sitemap دامنه اصلی</span></a><a class="tool" href="admin_health.php"><b>عیب‌یابی</b><span>Permission، دیتابیس، افزونه‌ها و ساختار پنل</span></a></div></div></div>
</section>

<section class="tab <?= $tab==='ads'?'active':'' ?>">
<form method="post" action="admin_control_center.php"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_yektanet">
<div class="grid"><div class="card"><h2>مدیریت کامل یکتانت</h2><p class="sub">کدهای رسمی یکتانت را بدون تغییر ذخیره کن. هیچ CSS یا JavaScript سفارشی، حالت شناور، پاپ‌آپ یا مودال روی جایگاه‌ها اعمال نمی‌شود. جایگاه اصلی روی موبایل و دسکتاپ نمایش داده می‌شود و کل صفحه حداکثر ۴ جایگاه رندر می‌کند.</p><div class="form-grid">
<div class="field full"><label class="check"><input type="checkbox" name="yk_enabled" <?= !empty($yk['enabled'])?'checked':'' ?>> فعال‌بودن سراسری یکتانت</label></div>
<div class="field full"><label>آدرس رسمی اسکریپت ناشر یکتانت</label><input class="code" type="url" name="publisher_url" value="<?= bm_cc_h($yk['publisher_url']) ?>" required><p class="sub">فقط آدرسی را قرار بده که خود یکتانت تحویل داده است.</p></div>
<div class="field"><label>دامنه فعال تبلیغات</label><label class="check"><input type="checkbox" checked disabled> bankmoviee.ir</label><p class="sub">تبلیغات فعلاً فقط روی bankmoviee.ir فعال است و روی bankmovie.top هیچ اسکریپت یا جایگاهی لود نمی‌شود. آدرس اسکریپت ناشر دقیقاً همان کد رسمی یکتانت باقی می‌ماند.</p></div>
<div class="field"><label>صفحات فعال</label><div style="columns:2"><?php foreach(bm_yektanet_defaults()['pages'] as $page): ?><label class="check"><input type="checkbox" name="pages[]" value="<?= bm_cc_h($page) ?>" <?= in_array($page,$yk['pages'],true)?'checked':'' ?>> <?= bm_cc_h($page) ?></label><?php endforeach; ?></div></div>
</div></div>
<?php foreach(bm_yektanet_defaults()['slots'] as $id=>$def): $slot=$yk['slots'][$id]; ?><div class="card"><div class="slot-head"><div><h3><?= bm_cc_h($def['label']) ?></h3><span class="code"><?= bm_cc_h($id) ?></span></div><label class="check"><input type="checkbox" name="slot_enabled[<?= bm_cc_h($id) ?>]" <?= !empty($slot['enabled'])?'checked':'' ?>> فعال</label></div><div class="form-grid"><div class="field third"><label>نوع نمایش</label><select name="slot_device[<?= bm_cc_h($id) ?>]"><option value="all" <?= $slot['device']==='all'?'selected':'' ?>>همه دستگاه‌ها</option><option value="desktop" <?= $slot['device']==='desktop'?'selected':'' ?>>فقط دسکتاپ</option><option value="mobile" <?= $slot['device']==='mobile'?'selected':'' ?>>فقط موبایل</option></select></div><div class="field full"><label>کد HTML جایگاه از پنل یکتانت</label><textarea name="slot_html[<?= bm_cc_h($id) ?>]" placeholder="کد جایگاه یکتانت را بدون تغییر اینجا قرار بده"><?= bm_cc_h($slot['html']) ?></textarea></div></div></div><?php endforeach; ?>
<div class="card"><p class="sub">جایگاه <span class="code">global_banner</span> در صفحه اصلی بعد از اسلایدر، در صفحه فیلم قبل از لینک دانلود و در سایر صفحات محتوایی قبل از فوتر قرار می‌گیرد. اندازه، iframe و محتوای کد یکتانت دست‌کاری نمی‌شود.</p><div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات تبلیغات</button><a class="btn" href="/movie/test" target="_blank">تست صفحه فیلم</a></div></div></div></form>
</section>

<section class="tab <?= $tab==='app'?'active':'' ?>">
<form method="post" action="admin_control_center.php"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_app"><div class="grid">
<div class="card"><h2>وضعیت و سرورهای اپ</h2><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="app_ready" <?= !empty($appConfig['ready'])?'checked':'' ?>> اپ آماده و در دسترس باشد</label></div><div class="field full"><label>پیام زمان توقف</label><input type="text" name="app_message" value="<?= bm_cc_h($appConfig['message']) ?>"></div><div class="field"><label>دامنه فعال</label><input class="code" type="url" name="active_domain" value="<?= bm_cc_h($appConfig['active_domain']) ?>" required></div><div class="field"><label>API اصلی</label><input class="code" type="url" name="api_url" value="<?= bm_cc_h($appConfig['api_url']) ?>" required></div></div></div>
<?php for($i=0;$i<2;$i++): $srv=$servers[$i]; ?><div class="card half"><h3>سرور <?= $i+1 ?></h3><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="server_enabled[<?= $i ?>]" <?= !empty($srv['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label>نام</label><input type="text" name="server_name[<?= $i ?>]" value="<?= bm_cc_h($srv['name'] ?? '') ?>"></div><div class="field"><label>اولویت</label><input type="number" min="1" max="99" name="server_priority[<?= $i ?>]" value="<?= (int)($srv['priority'] ?? $i+1) ?>"></div><div class="field full"><label>دامنه</label><input class="code" type="url" name="server_domain[<?= $i ?>]" value="<?= bm_cc_h($srv['domain'] ?? '') ?>"></div><div class="field full"><label>API</label><input class="code" type="url" name="server_api[<?= $i ?>]" value="<?= bm_cc_h($srv['api_url'] ?? '') ?>"></div></div></div><?php endfor; ?>
<div class="card half"><h3>اعلان داخل اپ</h3><div class="form-grid"><div class="field full"><label class="check"><input type="checkbox" name="notice_enabled" <?= !empty($appConfig['notice']['enabled'])?'checked':'' ?>> نمایش اعلان</label></div><div class="field"><label>شناسه اعلان</label><input type="text" name="notice_id" value="<?= bm_cc_h($appConfig['notice']['id'] ?? '') ?>"></div><div class="field"><label>عنوان</label><input type="text" name="notice_title" value="<?= bm_cc_h($appConfig['notice']['title'] ?? '') ?>"></div><div class="field full"><label>متن</label><textarea class="fa" name="notice_message"><?= bm_cc_h($appConfig['notice']['message'] ?? '') ?></textarea></div></div></div>
<div class="card half"><h3>آپدیت اپ</h3><div class="form-grid"><div class="field"><label class="check"><input type="checkbox" name="update_enabled" <?= !empty($appConfig['update']['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label class="check"><input type="checkbox" name="update_force" <?= !empty($appConfig['update']['force'])?'checked':'' ?>> اجباری</label></div><div class="field"><label>Version Code</label><input type="number" min="0" name="version_code" value="<?= (int)($appConfig['update']['version_code'] ?? 0) ?>"></div><div class="field"><label>Version Name</label><input type="text" name="version_name" value="<?= bm_cc_h($appConfig['update']['version_name'] ?? '') ?>"></div><div class="field full"><label>عنوان آپدیت</label><input type="text" name="update_title" value="<?= bm_cc_h($appConfig['update']['title'] ?? '') ?>"></div><div class="field full"><label>پیام آپدیت</label><textarea class="fa" name="update_message"><?= bm_cc_h($appConfig['update']['message'] ?? '') ?></textarea></div><div class="field full"><label>تغییرات؛ هر مورد یک خط</label><textarea class="fa" name="changes"><?= bm_cc_h(implode("\n", (array)($appConfig['update']['changes'] ?? []))) ?></textarea></div></div></div>
<div class="card"><h3>لینک‌های دانلود آپدیت</h3><div class="form-grid"><div class="field full"><label>لینک عمومی APK</label><input class="code" type="url" name="apk_url" value="<?= bm_cc_h($appConfig['update']['apk_url'] ?? '') ?>"></div><div class="field third"><label>Universal</label><input class="code" type="url" name="apk_universal" value="<?= bm_cc_h($appConfig['update']['apk_urls']['universal'] ?? '') ?>"></div><div class="field third"><label>ARM64</label><input class="code" type="url" name="apk_arm64" value="<?= bm_cc_h($appConfig['update']['apk_urls']['arm64_v8a'] ?? '') ?>"></div><div class="field third"><label>V7A</label><input class="code" type="url" name="apk_v7a" value="<?= bm_cc_h($appConfig['update']['apk_urls']['armeabi_v7a'] ?? '') ?>"></div></div></div>
<div class="card"><h3>سیاست نسخه‌ها</h3><div class="form-grid"><div class="field"><label class="check"><input type="checkbox" name="policy_enabled" <?= !empty($appConfig['version_policy']['enabled'])?'checked':'' ?>> فعال</label></div><div class="field"><label class="check"><input type="checkbox" name="force_update_blocked" <?= !empty($appConfig['version_policy']['force_update_blocked'])?'checked':'' ?>> اجبار آپدیت نسخه مسدود</label></div><div class="field"><label>حداقل Version Code</label><input type="number" min="0" name="minimum_version_code" value="<?= (int)($appConfig['version_policy']['minimum_version_code'] ?? 0) ?>"></div><div class="field"><label>حداقل Version Name</label><input type="text" name="minimum_version_name" value="<?= bm_cc_h($appConfig['version_policy']['minimum_version_name'] ?? '') ?>"></div><div class="field"><label>Version Nameهای مسدود</label><textarea name="blocked_version_names"><?= bm_cc_h(implode("\n", (array)($appConfig['version_policy']['blocked_version_names'] ?? []))) ?></textarea></div><div class="field"><label>Version Codeهای مسدود</label><textarea name="blocked_version_codes"><?= bm_cc_h(implode("\n", (array)($appConfig['version_policy']['blocked_version_codes'] ?? []))) ?></textarea></div><div class="field full"><label>پیام مسدودی</label><textarea class="fa" name="block_message"><?= bm_cc_h($appConfig['version_policy']['block_message'] ?? '') ?></textarea></div></div><div class="actions"><button class="btn primary" type="submit">ذخیره تنظیمات اپ</button><a class="btn" href="app_config.php" target="_blank">مشاهده JSON عمومی</a></div></div>
</div></form>
<div class="grid" style="margin-top:16px"><div class="card half"><h3>آپلود نسخه جدید</h3><p class="sub">APK یا ZIP در پوشه app ذخیره می‌شود و جدیدترین نسخه خودکار تشخیص داده می‌شود.</p><form method="post" action="admin_control_center.php" enctype="multipart/form-data"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="upload_release"><div class="form-grid"><div class="field full"><label>نام پیشنهادی، مثل bankmovie-v2.0-20000</label><input type="text" name="release_name"></div><div class="field full"><label>فایل APK یا ZIP</label><input type="file" name="release_file" accept=".apk,.zip" required></div></div><div class="actions"><button class="btn primary" type="submit">آپلود انتشار</button></div></form></div>
<div class="card half"><h3>فایل‌های انتشار</h3><?php if(!$releaseFiles): ?><p class="sub">فایلی در پوشه app نیست.</p><?php else: ?><table class="table"><tr><th>فایل</th><th>حجم</th><th></th></tr><?php foreach($releaseFiles as $file): ?><tr><td class="code"><?= bm_cc_h(basename($file)) ?></td><td><?= number_format(((int)@filesize($file))/1048576,1) ?> MB</td><td><form method="post" action="admin_control_center.php" onsubmit="return confirm('فایل حذف شود؟')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="delete_release"><input type="hidden" name="release_file_name" value="<?= bm_cc_h(basename($file)) ?>"><button class="btn danger" type="submit">حذف</button></form></td></tr><?php endforeach; ?></table><?php endif; ?></div></div>
</section>

<section class="tab <?= $tab==='archives'?'active':'' ?>">
<?php
$bmArchiveEnabledCount = 0;
foreach (['archive1','archive2','archive3','archive4'] as $bmArchiveId) if (!empty($archiveSettings['archives'][$bmArchiveId]['enabled'])) $bmArchiveEnabledCount++;
$bmArchivePublicCount = 0; $bmArchiveAdminCount = 0;
foreach (['archive1','archive2','archive3','archive4'] as $bmArchiveId) { (($archiveSettings['archives'][$bmArchiveId]['access_scope'] ?? 'public') === 'admin') ? $bmArchiveAdminCount++ : $bmArchivePublicCount++; }
?>
<form id="archiveSettingsForm" method="post" action="admin_control_center.php">
<input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="save_archives">
<div class="grid">
  <div class="card archive-manager-hero">
    <div class="archive-manager-title"><div class="archive-manager-icon">◫</div><div><h2>مرکز مدیریت آرشیوها</h2><p class="sub">وضعیت، نام نمایشی، رفتار خاموش و سطح دسترسی هر چهار آرشیو را از یک بخش مدیریت کن.</p></div></div>
    <div class="archive-manager-kpis"><span class="archive-kpi">● <?= (int)$bmArchiveEnabledCount ?> آرشیو فعال</span><span class="archive-kpi">🌐 <?= (int)$bmArchivePublicCount ?> عمومی</span><span class="archive-kpi">🛡 <?= (int)$bmArchiveAdminCount ?> فقط مدیر</span><span class="archive-kpi">تغییرات سراسری روی خانه، جستجو و جزئیات</span></div>
  </div>
<?php foreach(['archive1','archive2','archive3','archive4'] as $id): $row=$archiveSettings['archives'][$id]; $num=str_replace('archive','',$id); $scope=(string)($row['access_scope'] ?? 'public'); ?>
  <div class="card half archive-card">
    <div class="archive-card-top"><div class="archive-card-name"><div class="archive-num"><?= bm_cc_h($num) ?></div><div><h3><?= bm_cc_h($row['label']) ?></h3><small><?= $id==='archive4'?'قالب و جستجو مشابه آرشیو ۳':'منبع محتوای BankMovie' ?></small></div></div><span class="archive-state <?= !empty($row['enabled'])?'on':'off' ?>"><?= !empty($row['enabled'])?'فعال':'غیرفعال' ?></span></div>
    <div class="archive-toggle-box"><div><b>وضعیت آرشیو</b><div class="sub" style="margin:3px 0 0">خاموش‌کردن، دریافت محتوا را متوقف می‌کند.</div></div><label class="check"><input type="checkbox" name="archive_enabled[<?= $id ?>]" <?= !empty($row['enabled'])?'checked':'' ?>> فعال</label></div>
    <div class="form-grid"><div class="field"><label>نام نمایشی</label><input type="text" name="archive_label[<?= $id ?>]" value="<?= bm_cc_h($row['label']) ?>"></div><div class="field"><label>وقتی غیرفعال است</label><select name="archive_mode[<?= $id ?>]"><option value="visible" <?= $row['disabled_mode']==='visible'?'selected':'' ?>>تب بماند + پیام</option><option value="hide" <?= $row['disabled_mode']==='hide'?'selected':'' ?>>کاملاً مخفی شود</option></select></div><div class="field full"><label>پیام غیرفعال‌بودن</label><textarea class="fa" name="archive_message[<?= $id ?>]"><?= bm_cc_h($row['disabled_message']) ?></textarea></div></div>
    <div class="archive-audience"><div class="archive-audience-label">سطح نمایش آرشیو <?= bm_cc_h($num) ?></div><div class="archive-segments"><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="public" <?= $scope==='public'?'checked':'' ?>><span>🌐 عموم</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="member" <?= $scope==='member'?'checked':'' ?>><span>👤 اعضا</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="vip" <?= $scope==='vip'?'checked':'' ?>><span>👑 VIP</span></label><label class="archive-segment"><input type="radio" name="archive_scope[<?= $id ?>]" value="admin" <?= $scope==='admin'?'checked':'' ?>><span>🛡 مدیر</span></label></div></div>
  </div>
<?php endforeach; ?>
</div>
<div class="archive-savebar"><p class="sub">هر چهار آرشیو روی «عموم» مهاجرت شده‌اند؛ هر کدام را می‌توانی مستقل روی «فقط مدیر» بگذاری و بعد دوباره عمومی کنی.</p><button class="btn primary" type="submit">ذخیره تنظیمات آرشیوها</button></div>
</form>
<div class="archive-connect-grid" style="margin-top:18px"><div class="archive-connect-card"><h3>اتصال آرشیو ۳</h3><span class="archive-connect-status">● API6 آماده</span><p class="sub">بدون Cookie، همراه کش داخلی و مدیریت خطا.</p><div class="actions"><a class="btn primary" href="api6.php?ping=1" target="_blank">تست API6</a></div></div><div class="archive-connect-card"><h3>اتصال آرشیو ۴</h3><span class="archive-connect-status">● API4 آماده</span><p class="sub">بدون Cookie؛ ساختار صفحه، جستجو و جزئیات همان جریان آرشیو ۳ است.</p><div class="actions"><a class="btn primary" href="api4.php?ping=1" target="_blank">تست API4</a></div></div></div>
<div class="card" style="margin-top:16px"><h3>کش آرشیوها</h3><p class="sub">اگر محتوای تازه نمایش داده نشد، کش لیست‌ها را پاک کن. تنظیمات آرشیوها حذف نمی‌شوند.</p><form method="post" action="admin_control_center.php" onsubmit="return confirm('کش آرشیوها پاک شود؟')"><input type="hidden" name="csrf_token" value="<?= bm_cc_h($csrf) ?>"><input type="hidden" name="action" value="clear_archive_cache"><button class="btn danger" type="submit">پاک‌کردن کش آرشیو</button></form></div>
</section>

<section class="tab <?= $tab==='tools'?'active':'' ?>"><div class="grid"><div class="card"><h2>تمام بخش‌های مدیریتی</h2><p class="sub">بخش‌های تخصصی موجود پروژه از اینجا در دسترس‌اند.</p><div class="tool-grid">
<?php $tools=[['admin.php','مدیریت اصلی','فیلم، سریال، کاربران، نظرات، استوری، درخواست، بنر داخلی و بکاپ'],['admin_stickers.php','مدیریت استیکر و گیف','پک‌ها، مسیر پوشه، WEBM/WEBP/GIF، آپلود و حذف فایل برای Watch Party و دیدگاه‌های عمومی'],['admin_site_manager.php','مدیریت ظاهر و محتوا','هدر، فوتر، متن‌ها، بخش‌های صفحه اصلی، جستجو، پلیر، اپلیکیشن و PWA'],['admin_vip_manager.php','مدیریت فروش VIP','پلن‌ها، قیمت‌ها، امکانات و متن معرفی Watch Party'],['admin_slider.php','اسلایدر','مدیریت کامل اسلایدهای صفحه اصلی'],['admin_collections.php','کالکشن‌ها','ساخت و ویرایش کالکشن‌ها'],['api_manager.php','مدیریت API','منابع آرشیو و APIهای پروژه'],['admin_sitemap.php','سایت‌مپ','ساخت و بررسی sitemap دامنه bankmovie.top'],['admin_health.php','عیب‌یابی پنل','دیتابیس، Permission، پوشه‌ها و افزونه PHP'],['donyaye_series_crawler.php','خزنده سریال','بررسی و واردکردن سریال‌های منبع'],['donyaye_json_importer.php','ایمپورت JSON','واردکردن خروجی خزنده به دیتابیس'],['map.php','نقشه سایت HTML','نمایش نقشه عمومی سایت'],['app_config.php','خروجی تنظیمات اپ','JSON تنظیمات فعال اپ']]; foreach($tools as $t): ?><a class="tool" href="<?= bm_cc_h($t[0]) ?>"><b><?= bm_cc_h($t[1]) ?></b><span><?= bm_cc_h($t[2]) ?></span></a><?php endforeach; ?>
</div></div><div class="card"><h3>وضعیت مسیرهای مهم</h3><table class="table"><tr><th>مسیر</th><th>وضعیت</th><th>قابل نوشتن</th></tr><?php foreach($dirs as $label=>$path): ?><tr><td><?= bm_cc_h($label) ?><div class="code"><?= bm_cc_h($path) ?></div></td><td><span class="badge <?= is_dir($path)?'on':'off' ?>"><?= is_dir($path)?'موجود':'ناموجود' ?></span></td><td><?= is_dir($path)&&is_writable($path)?'بله':'خیر' ?></td></tr><?php endforeach; ?></table></div></div></section>
</main></div>
</body></html>
