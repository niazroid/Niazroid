<?php
// ajax_profile.php - عملیات AJAX پروفایل (کامل)
require_once 'config.php';

header('Content-Type: application/json');

if(!$currentUser) {
    echo json_encode(['success' => false, 'error' => 'لطفاً وارد شوید', 'redirect' => '/login']);
    exit;
}

$userId = $currentUser['id'];
$action = '';
foreach (['action', 'ajax_action', 'profile_action', 'bm_action', 'do', 'task'] as $key) {
    if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') { $action = trim((string)$_POST[$key]); break; }
    if (isset($_GET[$key]) && trim((string)$_GET[$key]) !== '') { $action = trim((string)$_GET[$key]); break; }
}
$action = strtolower($action);
$actionAliases = [
    'watchlist' => 'toggle_watchlist',
    'add_watchlist' => 'toggle_watchlist',
    'delete_watchlist' => 'remove_watchlist',
    'delete' => 'remove_watchlist',
    'remove' => 'remove_watchlist',
    'history' => 'get_history',
    'continue' => 'get_continue',
];
if (isset($actionAliases[$action])) $action = $actionAliases[$action];

$bm_profile_mutating_actions = ['save_progress','toggle_watchlist','remove_watchlist','clear_watchlist','clear_history'];
if (in_array($action, $bm_profile_mutating_actions, true)) {
    bm_require_post(true);
    bm_require_user_csrf(true, true);
}

switch($action) {
    // ========== ذخیره پیشرفت تماشا ==========
    case 'save_progress':
        $imdbCode = $_POST['imdb_code'] ?? '';
        $currentTime = intval($_POST['current_time'] ?? 0);
        $duration = intval($_POST['duration'] ?? 0);
        
        if($imdbCode && $currentTime > 0 && $duration > 0) {
            $stmt = $pdo->prepare("SELECT id FROM movies WHERE imdb_code = ?");
            $stmt->execute([$imdbCode]);
            $movie = $stmt->fetch();
            
            if($movie) {
                $stmt = $pdo->prepare("
                    INSERT INTO watch_history (user_id, movie_id, current_time, duration, last_watched) 
                    VALUES (?, ?, ?, ?, NOW())
                    ON DUPLICATE KEY UPDATE 
                    current_time = ?, duration = ?, last_watched = NOW()
                ");
                $stmt->execute([$userId, $movie['id'], $currentTime, $duration, $currentTime, $duration]);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'error' => 'فیلم یافت نشد']);
            }
        } else {
            echo json_encode(['success' => false, 'error' => 'داده نامعتبر']);
        }
        break;
    
    // ========== دریافت لیست نشانه‌ها ==========
    case 'get_watchlist':
        $stmt = $pdo->prepare("
            SELECT m.* FROM watchlist w
            JOIN movies m ON w.movie_id = m.id
            WHERE w.user_id = ?
            ORDER BY w.added_at DESC
        ");
        $stmt->execute([$userId]);
        $watchlist = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $watchlist]);
        break;
    
    // ========== افزودن/حذف نشانه ==========
    case 'toggle_watchlist':
        $imdbCode = $_POST['imdb_code'] ?? '';
        $actionType = $_POST['watch_action'] ?? 'add';
        
        if(empty($imdbCode)) {
            echo json_encode(['success' => false, 'error' => 'کد فیلم نامعتبر']);
            break;
        }
        
        // دریافت movie_id
        $stmt = $pdo->prepare("SELECT id FROM movies WHERE imdb_code = ?");
        $stmt->execute([$imdbCode]);
        $movie = $stmt->fetch();
        
        if(!$movie) {
            echo json_encode(['success' => false, 'error' => 'فیلم یافت نشد']);
            break;
        }
        
        $movieId = $movie['id'];
        
        if($actionType === 'add') {
            // افزودن به نشانه‌ها
            $stmt = $pdo->prepare("
                INSERT IGNORE INTO watchlist (user_id, movie_id, added_at) 
                VALUES (?, ?, NOW())
            ");
            $stmt->execute([$userId, $movieId]);
            echo json_encode(['success' => true, 'added' => true]);
        } else {
            // حذف از نشانه‌ها
            $stmt = $pdo->prepare("
                DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?
            ");
            $stmt->execute([$userId, $movieId]);
            echo json_encode(['success' => true, 'added' => false]);
        }
        break;
    
    // ========== حذف یک آیتم از نشانه‌ها ==========
    case 'remove_watchlist':
        $imdbCode = $_POST['imdb_code'] ?? '';
        if($imdbCode) {
            $stmt = $pdo->prepare("
                DELETE w FROM watchlist w
                JOIN movies m ON w.movie_id = m.id
                WHERE w.user_id = ? AND m.imdb_code = ?
            ");
            $stmt->execute([$userId, $imdbCode]);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;
    
    // ========== پاک کردن همه نشانه‌ها ==========
    case 'clear_watchlist':
        $stmt = $pdo->prepare("DELETE FROM watchlist WHERE user_id = ?");
        $stmt->execute([$userId]);
        echo json_encode(['success' => true]);
        break;
    
    // ========== پاک کردن تاریخچه تماشا ==========
    case 'clear_history':
        $stmt = $pdo->prepare("DELETE FROM watch_history WHERE user_id = ?");
        $stmt->execute([$userId]);
        echo json_encode(['success' => true]);
        break;
    
    // ========== دریافت تاریخچه تماشا ==========
    case 'get_history':
        $stmt = $pdo->prepare("
            SELECT m.*, w.current_time, w.duration, w.last_watched 
            FROM watch_history w
            JOIN movies m ON w.movie_id = m.id
            WHERE w.user_id = ?
            ORDER BY w.last_watched DESC
            LIMIT 30
        ");
        $stmt->execute([$userId]);
        $history = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $history]);
        break;
    
    // ========== دریافت ادامه تماشا ==========
    case 'get_continue':
        $stmt = $pdo->prepare("
            SELECT m.*, w.current_time, w.duration, w.last_watched,
                   ROUND((w.current_time / w.duration) * 100) as progress
            FROM watch_history w
            JOIN movies m ON w.movie_id = m.id
            WHERE w.user_id = ? AND w.current_time > 30 AND (w.current_time / w.duration) < 0.95
            ORDER BY w.last_watched DESC
            LIMIT 20
        ");
        $stmt->execute([$userId]);
        $continue = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $continue]);
        break;
    
    default:
        echo json_encode(['success' => false, 'error' => 'action not found']);
}
?>