<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/site_bootstrap.php';

if (!headers_sent()) {
    header('Content-Type: text/plain; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('CDN-Cache-Control: no-store');
}

$base = function_exists('bm_seo_base_url') ? bm_seo_base_url() : rtrim(SITE_URL, '/');
?>User-agent: *
Allow: /

# بخش‌های کم‌ارزش یا خصوصی برای crawl نشدن
Disallow: /admin.php
Disallow: /admin_
Disallow: /ajax_
Disallow: /api
Disallow: /api2.php
Disallow: /api3.php
Disallow: /api6.php
Disallow: /api4.php
Disallow: /api_bot.php
Disallow: /bm_admin.php
Disallow: /admin_health.php
Disallow: /admin_sitemap.php
Disallow: /admin_watch_party.php
Disallow: /watch_party_lab.php
Disallow: /watch-party
Disallow: /watch_party_api.php
Disallow: /watch_party_cleanup.php
Disallow: /login
Disallow: /login.php
Disallow: /register
Disallow: /register.php
Disallow: /profile
Disallow: /profile.php
Disallow: /logout
Disallow: /logout.php
Disallow: /mark_notification_seen.php
Disallow: /proxy.php
Disallow: /proxy2.php
Disallow: /proxy_api.php
Disallow: /cache/
Disallow: /logs/
Disallow: /_bankmovie_private/

# فایل‌های بکاپ یا تست
Disallow: /*.php1$
Disallow: /.htaccess1
Disallow: /ptest.html
Disallow: /1.html

Sitemap: <?= $base ?>/sitemap.xml
