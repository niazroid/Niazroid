<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
if (!$currentUser || !in_array(strtolower((string)($currentUser['role'] ?? '')), ['admin','administrator'], true)) {
    http_response_code(403); exit('Forbidden');
}
function bm_count(PDO $pdo, string $table, string $where='1=1'): int {
    try { return (int)$pdo->query("SELECT COUNT(*) FROM `$table` WHERE $where")->fetchColumn(); }
    catch (Throwable $e) { return -1; }
}
$dbName=''; try {$dbName=(string)$pdo->query('SELECT DATABASE()')->fetchColumn();} catch(Throwable $e){}
$host=(string)($_SERVER['HTTP_HOST'] ?? '');
$server=(string)($_SERVER['SERVER_ADDR'] ?? '');
?><!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><title>بررسی مسیر حساب</title>
<style>body{background:#090a0f;color:#fff;font-family:tahoma;padding:28px}.box{max-width:780px;margin:auto;background:#151720;border:1px solid #343846;border-radius:20px;padding:22px}code{direction:ltr;display:block;background:#08090d;padding:12px;border-radius:10px;margin:8px 0}.ok{color:#64d98b}.bad{color:#ff7373}</style>
<div class="box"><h2>بررسی سرور و دیتابیس کامنت</h2>
<p>دامنه این صفحه:</p><code><?=htmlspecialchars($host)?></code>
<p>IP سرور:</p><code><?=htmlspecialchars($server)?></code>
<p>اثر انگشت دیتابیس:</p><code><?=htmlspecialchars(substr(hash('sha256',$dbName),0,16))?></code>
<p>comments در انتظار: <b><?=bm_count($pdo,'comments',"status='pending'")?></b></p>
<p>archive1_comments کل: <b><?=bm_count($pdo,'archive1_comments')?></b></p>
<p>archive1_comments در انتظار: <b><?=bm_count($pdo,'archive1_comments',"status='pending'")?></b></p>
<hr><p>همین صفحه را روی هر دو دامنه باز کن. اثر انگشت دیتابیس باید دقیقاً یکی باشد. اگر فرق کند، دو دامنه به دو دیتابیس جدا وصل‌اند.</p></div>