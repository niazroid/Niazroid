<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, max-age=0');
bm_security_enforce_rate_limit('user_comments_read', 120, 300, bm_security_client_ip(), true);

$userId = (int)($_GET['user_id'] ?? 0);
if ($userId <= 0) {
    echo json_encode(['success' => false, 'error' => 'user_id required'], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $stmt = $pdo->prepare("\n        SELECT c.id, c.user_id, c.movie_id, c.parent_id, c.comment, c.rating, c.status, c.created_at,\n               m.title_fa AS movie_title, m.imdb_code\n        FROM comments c\n        JOIN movies m ON c.movie_id = m.id\n        WHERE c.user_id = ? AND c.status = 'active'\n        ORDER BY c.created_at DESC\n        LIMIT 100\n    ");
    $stmt->execute([$userId]);
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    error_log('ajax_get_user_comments error [' . bm_security_request_id() . ']: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Server error', 'request_id' => bm_security_request_id()], JSON_UNESCAPED_UNICODE);
}
