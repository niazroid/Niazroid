<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/vip_sales.php';

if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
}

$userLang = (string)($_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa'));
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';
$notificationsList = [];
$latestNotification = null;
$t = [
    'fa' => ['home'=>'خانه','notifications'=>'اعلان‌ها','account'=>'حساب کاربری','login'=>'ورود','register'=>'ثبت نام','logout'=>'خروج','admin_panel'=>'پنل مدیریت'],
    'en' => ['home'=>'Home','notifications'=>'Notifications','account'=>'Account','login'=>'Login','register'=>'Register','logout'=>'Logout','admin_panel'=>'Admin Panel'],
];

function bm_vip_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$vipSettings = bm_vip_sales_settings();
$plans = array_values(array_filter((array)($vipSettings['plans'] ?? []), static fn($plan): bool => is_array($plan) && !empty($plan['enabled'])));
$features = array_values(array_filter((array)($vipSettings['features'] ?? []), static fn($feature): bool => is_array($feature) && !empty($feature['enabled']) && trim((string)($feature['label'] ?? '')) !== ''));
$watchPartyBadges = array_values(array_filter(array_map('strval', (array)($vipSettings['watch_party_badges'] ?? [])), static fn(string $value): bool => trim($value) !== ''));
$purchaseEnabled = !empty($vipSettings['purchase_enabled']);
$telegramUsername = ltrim(trim((string)($vipSettings['telegram_username'] ?? 'bankmovie_supp')), '@');
if (!preg_match('/^[A-Za-z0-9_]{5,32}$/', $telegramUsername)) $telegramUsername = 'bankmovie_supp';
$telegramUrl = 'https://t.me/' . rawurlencode($telegramUsername);
$purchaseInstruction = trim((string)($vipSettings['purchase_instruction'] ?? ''));
$purchaseMessageTemplate = trim((string)($vipSettings['purchase_message_template'] ?? ''));
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#05060d">
    <meta name="robots" content="index,follow">
    <title>اشتراک VIP | بانک مووی</title>
    <link rel="stylesheet" href="/assets/css/bm-global.css?v=148.36">
    <link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=148.36">
    <?= bm_site_typography_head_markup() ?>
    <style>
        :root{
            --vip-blue:#2f7cf8;
            --vip-purple:#975af4;
            --vip-soft:#78aafa;
            --vip-bg:#05060d;
            --vip-panel:#10131b;
        }
        *{box-sizing:border-box}
        html{scroll-behavior:smooth}
        body{
            margin:0;
            min-height:100vh;
            color:#fff;
            overflow-x:hidden;
            background:
                radial-gradient(circle at 12% 0%,rgba(151,90,244,.18),transparent 31%),
                radial-gradient(circle at 88% 12%,rgba(47,124,248,.16),transparent 30%),
                linear-gradient(180deg,#05060d 0%,#070913 48%,#04050b 100%);
        }
        body:before{
            content:"";
            position:fixed;
            inset:0;
            pointer-events:none;
            opacity:.16;
            background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);
            background-size:42px 42px;
            mask-image:linear-gradient(to bottom,#000,transparent 86%);
        }
        .bm-vip-page{
            position:relative;
            z-index:1;
            width:min(1420px,calc(100% - 30px));
            margin:112px auto 0;
            padding:0 0 120px;
        }
        .bm-vip-section-head{text-align:center;max-width:760px;margin:24px auto 26px}
        .bm-vip-section-head span{color:#8db8ff;font-size:10px;font-weight:1000;letter-spacing:.18em}
        .bm-vip-section-head h2{font-size:clamp(26px,4vw,43px);margin:9px 0 8px;font-weight:1000;letter-spacing:-.035em}
        .bm-vip-section-head p{margin:0;color:rgba(255,255,255,.52);font-size:12px;line-height:1.9}
        .bm-vip-watch-party{
            position:relative;overflow:hidden;
            max-width:1040px;margin:0 auto 30px;padding:24px 26px;
            display:grid;grid-template-columns:minmax(0,1.4fr) minmax(260px,.7fr);gap:24px;align-items:center;
            border:1px solid rgba(123,158,255,.16);border-radius:26px;
            background:linear-gradient(135deg,rgba(13,17,29,.9),rgba(14,18,31,.72)),radial-gradient(circle at 92% 20%,rgba(151,90,244,.2),transparent 34%);
            box-shadow:0 24px 70px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.055);
            backdrop-filter:blur(18px);
        }
        .bm-vip-watch-party:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(110deg,transparent,rgba(255,255,255,.045),transparent);transform:translateX(-45%)}
        .bm-vip-watch-copy{position:relative;z-index:1}
        .bm-vip-watch-copy small{display:block;margin-bottom:8px;color:#8db8ff;font-size:9px;font-weight:1000;letter-spacing:.17em}
        .bm-vip-watch-copy h3{margin:0 0 10px;font-size:clamp(20px,2.8vw,31px);font-weight:1000;letter-spacing:-.035em}
        .bm-vip-watch-copy p{margin:0;color:rgba(255,255,255,.62);font-size:12px;line-height:2.05}
        .bm-vip-watch-badges{position:relative;z-index:1;display:flex;flex-wrap:wrap;gap:9px;justify-content:flex-start}
        .bm-vip-watch-badge{display:inline-flex;align-items:center;gap:8px;min-height:38px;padding:8px 11px;border-radius:13px;color:#dce8ff;background:rgba(255,255,255,.045);border:1px solid rgba(125,170,255,.13);font-size:10px;font-weight:850}
        .bm-vip-watch-badge i{width:7px;height:7px;border-radius:50%;background:linear-gradient(135deg,#78aafa,#a855f7);box-shadow:0 0 13px rgba(120,170,250,.75)}

        /* Adapted from the Uiverse card supplied by the site owner. */
        .bm-vip-plans{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:18px;align-items:stretch}
        .card-container{
            --card-a:#975af4;
            --card-b:#2f7cf8;
            --card-c:#78aafa;
            --card-d:#934cff;
            position:relative;
            width:100%;
            min-width:0;
            padding:3px;
            border-radius:32px;
            display:flex;
            flex-direction:column;
            background:linear-gradient(to top right,var(--card-a),var(--card-b) 40%,var(--card-c) 65%,var(--card-d) 100%);
            box-shadow:0 24px 64px rgba(0,0,0,.38),0 0 32px color-mix(in srgb,var(--card-a) 12%,transparent);
            transition:transform .32s ease,box-shadow .32s ease;
        }
        .card-container:hover{transform:translateY(-8px);box-shadow:0 34px 84px rgba(0,0,0,.48),0 0 46px color-mix(in srgb,var(--card-a) 20%,transparent)}
        .card-container.tone-blue{--card-a:#477bff;--card-b:#1f62e9;--card-c:#69c2ff;--card-d:#4b5dff}
        .card-container.tone-violet{--card-a:#935cff;--card-b:#5b4bf5;--card-c:#8c9cff;--card-d:#b14cff}
        .card-container.tone-premium{--card-a:#a855f7;--card-b:#2877ff;--card-c:#80b7ff;--card-d:#d946ef}
        .card-container.tone-gold{--card-a:#f0a52b;--card-b:#7155ff;--card-c:#66a7ff;--card-d:#f9c85f}
        .card-container.featured{transform:translateY(-12px)}
        .card-container.featured:hover{transform:translateY(-18px)}
        .card-container .featured-ribbon{
            position:absolute;top:-14px;right:22px;z-index:5;
            padding:8px 13px;border-radius:999px;
            color:#fff;font-size:10px;font-weight:1000;
            background:linear-gradient(135deg,#a855f7,#2f7cf8);
            border:1px solid rgba(255,255,255,.28);
            box-shadow:0 12px 30px rgba(59,130,246,.28);
        }
        .card-container .title-card{display:flex;align-items:center;padding:15px 17px;justify-content:space-between;color:#fff;min-height:63px}
        .card-container .title-card p{margin:0;font-size:12px;font-weight:900;font-style:italic;text-shadow:2px 2px 6px rgba(41,117,238,.72);letter-spacing:.08em}
        .card-container .title-card strong{font-size:13px;font-weight:1000}
        .card-container .card-content{
            width:100%;height:100%;
            min-height:455px;
            border-radius:29px;
            color:#838383;
            font-size:12px;
            padding:20px;
            display:flex;
            flex-direction:column;
            gap:14px;
            background:
                radial-gradient(circle at 90% 4%,rgba(120,170,250,.09),transparent 30%),
                linear-gradient(180deg,#161a20,#101319 100%);
            box-shadow:inset 0 1px 0 rgba(255,255,255,.055);
        }
        .card-content .plan-badge{width:max-content;max-width:100%;padding:6px 10px;border-radius:999px;color:#c8dcff;background:rgba(47,124,248,.1);border:1px solid rgba(120,170,250,.17);font-size:9px;font-weight:1000}
        .card-container .card-content .title{font-weight:700;color:#bab9b9;margin-top:1px}
        .card-container .card-content .plain{display:flex;align-items:flex-end;gap:8px;color:#8f95a2;direction:rtl}
        .card-container .card-content .plain .price{font-size:42px;line-height:1;color:#fff;font-weight:1000;letter-spacing:-.04em}
        .card-container .card-content .plain .currency{padding-bottom:5px;font-size:11px;color:#b8bdc7;font-weight:900;line-height:1.45}
        .card-container .card-content .period{margin-top:-4px;color:#737b89;font-size:10px;font-weight:800}
        .card-container .card-content .saving{min-height:18px;color:#7dd3fc;font-size:9.5px;font-weight:900}
        .card-container .card-content .card-btn{
            position:relative;
            overflow:hidden;
            background:linear-gradient(4deg,var(--card-a),var(--card-b) 40%,var(--card-c) 65%,var(--card-d) 100%);
            padding:11px 12px;
            border:0;width:100%;border-radius:12px;
            color:rgba(255,255,255,.78);
            font-size:11px;font-weight:1000;
            transition:all .3s ease-in-out;
            cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;
            box-shadow:inset 0 2px 4px rgba(255,255,255,.46),0 12px 28px color-mix(in srgb,var(--card-b) 22%,transparent);
        }
        .card-container .card-content .card-btn:before{content:"";position:absolute;inset:0;background:linear-gradient(110deg,transparent,rgba(255,255,255,.28),transparent);transform:translateX(-130%);transition:transform .6s ease}
        .card-container .card-content .card-btn:hover{color:#fff;text-shadow:0 0 8px #fff;transform:scale(1.025)}
        .card-container .card-content .card-btn:hover:before{transform:translateX(130%)}
        .card-container .card-content .card-btn:active{transform:scale(1)}
        .card-container .card-content .card-btn.is-disabled{cursor:not-allowed;opacity:.72;filter:saturate(.78)}
        .card-container .card-content .card-btn.is-disabled:hover{transform:none;text-shadow:none}
        .bm-vip-purchase-guide{
            max-width:1040px;margin:0 auto 24px;padding:14px 16px;display:flex;align-items:center;justify-content:space-between;gap:14px;
            border:1px solid rgba(56,189,248,.18);border-radius:18px;background:linear-gradient(135deg,rgba(14,165,233,.10),rgba(99,102,241,.08));
            box-shadow:inset 0 1px 0 rgba(255,255,255,.045);backdrop-filter:blur(14px)
        }
        .bm-vip-purchase-guide p{margin:0;color:rgba(255,255,255,.66);font-size:11px;line-height:1.9}
        .bm-vip-purchase-guide a{flex:0 0 auto;direction:ltr;text-decoration:none;color:#e0f2fe;font-size:11px;font-weight:1000;padding:9px 12px;border-radius:11px;border:1px solid rgba(125,211,252,.22);background:rgba(14,165,233,.11)}
        .bm-vip-toast{position:fixed;z-index:99999;left:50%;bottom:24px;transform:translate(-50%,20px);max-width:min(430px,calc(100% - 28px));padding:12px 15px;border-radius:14px;color:#eef6ff;background:rgba(8,12,22,.94);border:1px solid rgba(96,165,250,.24);box-shadow:0 18px 52px rgba(0,0,0,.48);font-size:11px;font-weight:850;line-height:1.8;opacity:0;pointer-events:none;transition:opacity .2s ease,transform .2s ease;backdrop-filter:blur(16px)}
        .bm-vip-toast.show{opacity:1;transform:translate(-50%,0)}
        .card-container .card-content .card-separate{display:flex;gap:8px;align-items:center;width:100%;font-size:9px;color:rgba(131,131,131,.58)}
        .card-container .card-content .card-separate .separate{width:100%;height:1px;background:rgba(131,131,131,.25)}
        .card-container .card-content .card-list-features{color:#bab9b9;display:flex;flex-direction:column;gap:10px}
        .card-container .card-content .card-list-features .option{display:flex;gap:9px;align-items:center;line-height:1.55}
        .card-container .card-content .card-list-features .option svg{width:16px;height:16px;flex:0 0 16px;stroke:#7fb0ff}
        .card-container .card-content .card-note{margin-top:auto;padding:10px;border-radius:12px;color:#79808e;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.045);font-size:9px;line-height:1.8;text-align:center}

        .bm-vip-footer-note{
            margin-top:24px;
            padding:17px 20px;
            display:flex;align-items:center;justify-content:space-between;gap:18px;
            border:1px solid rgba(255,255,255,.09);
            border-radius:22px;
            background:rgba(13,16,27,.72);
            box-shadow:0 18px 46px rgba(0,0,0,.28),inset 0 1px 0 rgba(255,255,255,.045);
            backdrop-filter:blur(14px);
        }
        .bm-vip-footer-note strong{display:block;font-size:13px;margin-bottom:4px}
        .bm-vip-footer-note p{margin:0;color:rgba(255,255,255,.52);font-size:10.5px;line-height:1.8}
        .bm-vip-footer-note a{flex:0 0 auto;text-decoration:none;color:#dbeafe;font-size:11px;font-weight:950;padding:10px 14px;border-radius:12px;border:1px solid rgba(96,165,250,.2);background:rgba(47,124,248,.09)}
        @media(max-width:1180px){.bm-vip-plans{grid-template-columns:repeat(2,minmax(0,1fr))}.card-container.featured{transform:none}.card-container.featured:hover{transform:translateY(-8px)}}
        @media(max-width:820px){
            .bm-vip-page{width:calc(100% - 20px);margin-top:80px;padding-bottom:96px}
            .bm-vip-section-head{margin-top:24px}.bm-vip-plans{gap:14px}
            .bm-vip-watch-party{grid-template-columns:1fr;padding:20px;margin-bottom:24px}
            .bm-vip-watch-badges{justify-content:flex-start}
        }
        @media(max-width:610px){
            .bm-vip-plans{grid-template-columns:1fr}
            .card-container{max-width:390px;margin-inline:auto;border-radius:28px}
            .card-container .card-content{min-height:0;border-radius:25px;padding:18px}
            .bm-vip-purchase-guide{align-items:flex-start;flex-direction:column}.bm-vip-purchase-guide a{width:100%;text-align:center}
            .bm-vip-footer-note{align-items:flex-start;flex-direction:column}
            .bm-vip-footer-note a{width:100%;text-align:center}
        }
        @media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;animation:none!important;transition:none!important}}
    </style>

<style id="bm-v56-mobile-nav-safe-space">
@media (max-width:991px){
  body{padding-bottom:max(92px,calc(78px + env(safe-area-inset-bottom,0px)))!important}
}
</style>

</head>
<body>
<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>

<main class="bm-vip-page">
    <section class="bm-vip-section-head">
        <span><?= bm_vip_h($vipSettings['section_eyebrow'] ?? '') ?></span>
        <h2><?= bm_vip_h($vipSettings['section_title'] ?? '') ?></h2>
        <p><?= bm_vip_h($vipSettings['section_description'] ?? '') ?></p>
    </section>

    <?php if (!empty($vipSettings['watch_party_enabled'])): ?>
    <section class="bm-vip-watch-party" aria-label="معرفی Watch Party">
        <div class="bm-vip-watch-copy">
            <small><?= bm_vip_h($vipSettings['watch_party_kicker'] ?? '') ?></small>
            <h3><?= bm_vip_h($vipSettings['watch_party_title'] ?? '') ?></h3>
            <p><?= nl2br(bm_vip_h($vipSettings['watch_party_body'] ?? '')) ?></p>
        </div>
        <?php if ($watchPartyBadges): ?>
        <div class="bm-vip-watch-badges">
            <?php foreach ($watchPartyBadges as $badge): ?>
                <span class="bm-vip-watch-badge"><i></i><?= bm_vip_h($badge) ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </section>
    <?php endif; ?>

    <?php if ($purchaseEnabled && $purchaseInstruction !== ''): ?>
    <section class="bm-vip-purchase-guide" aria-label="راهنمای خرید اشتراک">
        <p><?= bm_vip_h($purchaseInstruction) ?></p>
        <a href="<?= bm_vip_h($telegramUrl) ?>" target="_blank" rel="noopener noreferrer">@<?= bm_vip_h($telegramUsername) ?></a>
    </section>
    <?php endif; ?>

    <section class="bm-vip-plans" aria-label="پلن‌های اشتراک VIP">
        <?php foreach ($plans as $plan): ?>
            <article class="card-container tone-<?= bm_vip_h($plan['tone']) ?><?= $plan['featured'] ? ' featured' : '' ?>">
                <?php if (!empty($plan['featured'])): ?><span class="featured-ribbon"><?= bm_vip_h($vipSettings['featured_ribbon_label'] ?? '') ?></span><?php endif; ?>
                <div class="title-card">
                    <strong><?= bm_vip_h($plan['name']) ?></strong>
                    <p><?= bm_vip_h($plan['latin']) ?></p>
                </div>
                <div class="card-content">
                    <span class="plan-badge"><?= bm_vip_h($plan['badge']) ?></span>
                    <div class="title"><?= bm_vip_h($vipSettings['card_subscription_title'] ?? '') ?></div>
                    <div class="plain">
                        <span class="price"><?= bm_vip_h($plan['price']) ?></span>
                        <span class="currency"><?= nl2br(bm_vip_h($vipSettings['currency_label'] ?? '')) ?></span>
                    </div>
                    <div class="period"><?= bm_vip_h($plan['period']) ?></div>
                    <div class="saving"><?= bm_vip_h($plan['saving']) ?></div>
                    <?php
                        $orderText = strtr($purchaseMessageTemplate, [
                            '{plan}' => (string)($plan['name'] ?? ''),
                            '{price}' => (string)($plan['price'] ?? ''),
                        ]);
                        $toastText = strtr((string)($vipSettings['toast_template'] ?? ''), [
                            '{plan}' => (string)($plan['name'] ?? ''),
                            '{price}' => (string)($plan['price'] ?? ''),
                        ]);
                    ?>
                    <?php if ($purchaseEnabled): ?>
                        <a class="card-btn" href="<?= bm_vip_h($telegramUrl) ?>" target="_blank" rel="noopener noreferrer" data-vip-purchase="1" data-order-text="<?= bm_vip_h($orderText) ?>" data-toast-text="<?= bm_vip_h($toastText) ?>"><?= bm_vip_h($vipSettings['select_button_label'] ?? '') ?></a>
                    <?php else: ?>
                        <button type="button" class="card-btn is-disabled" disabled aria-disabled="true"><?= bm_vip_h($vipSettings['select_button_label'] ?? '') ?></button>
                    <?php endif; ?>
                    <div class="card-separate"><div class="separate"></div><span><?= bm_vip_h($vipSettings['features_label'] ?? '') ?></span><div class="separate"></div></div>
                    <div class="card-list-features">
                        <?php foreach ($features as $feature): ?>
                            <div class="option">
                                <svg viewBox="0 0 24 24" fill="none" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg>
                                <span><?= bm_vip_h($feature['label'] ?? '') ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="card-note"><?= bm_vip_h($vipSettings['card_note'] ?? '') ?></div>
                </div>
            </article>
        <?php endforeach; ?>
    </section>

    <section class="bm-vip-footer-note">
        <div>
            <strong><?= bm_vip_h($vipSettings['footer_title'] ?? '') ?></strong>
            <p><?= bm_vip_h($vipSettings['footer_description'] ?? '') ?></p>
        </div>
        <a href="<?= bm_vip_h($vipSettings['footer_button_url'] ?? '/') ?>"><?= bm_vip_h($vipSettings['footer_button_label'] ?? '') ?></a>
    </section>
</main>

<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>
<div class="bm-vip-toast" id="bmVipToast" role="status" aria-live="polite"></div>
<script>
(function(){
    'use strict';
    var toast=document.getElementById('bmVipToast'),timer=null;
    function showToast(text){
        if(!toast||!text)return;
        toast.textContent=text;
        toast.classList.add('show');
        clearTimeout(timer);
        timer=setTimeout(function(){toast.classList.remove('show');},3200);
    }
    function copyText(text){
        if(!text)return Promise.resolve(false);
        if(navigator.clipboard&&window.isSecureContext){
            return navigator.clipboard.writeText(text).then(function(){return true;}).catch(function(){return false;});
        }
        try{
            var area=document.createElement('textarea');
            area.value=text;area.setAttribute('readonly','');area.style.position='fixed';area.style.opacity='0';
            document.body.appendChild(area);area.select();var ok=document.execCommand('copy');area.remove();return Promise.resolve(ok);
        }catch(e){return Promise.resolve(false);}
    }
    document.querySelectorAll('[data-vip-purchase="1"]').forEach(function(link){
        link.addEventListener('click',function(){
            var text=link.getAttribute('data-order-text')||'';
            var notice=link.getAttribute('data-toast-text')||'تلگرام پشتیبانی باز شد.';
            copyText(text).then(function(copied){
                showToast(copied?notice:'تلگرام پشتیبانی باز شد؛ نام پلن را برای هماهنگی ارسال کن.');
            });
        });
    });
})();
</script>

</body>
</html>
