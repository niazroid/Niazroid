<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';
require_once __DIR__ . '/config.php';

$type = strtolower(trim((string)($_GET['type'] ?? 'movie')));
if (!in_array($type, ['movie', 'series'], true)) $type = 'movie';
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 48;
$offset = ($page - 1) * $perPage;

$isSeriesSql = "(type LIKE '%Series%' OR type IN ('tvSeries','tvMiniSeries','series','TV Series','tv') OR type LIKE '%MiniSeries%')";
$whereSql = $type === 'series' ? $isSeriesSql : "NOT $isSeriesSql";

$total = 0;
$items = [];
try {
    $total = (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE id > 0 AND $whereSql")->fetchColumn();
    $stmt = $pdo->prepare("SELECT id, imdb_code, title, title_fa, year, type, imdb_rate, genres, description, updated_at FROM movies WHERE id > 0 AND $whereSql ORDER BY id DESC LIMIT ? OFFSET ?");
    $stmt->bindValue(1, $perPage, PDO::PARAM_INT);
    $stmt->bindValue(2, $offset, PDO::PARAM_INT);
    $stmt->execute();
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('catalog.php error: ' . $e->getMessage());
}
$totalPages = max(1, (int)ceil($total / $perPage));
if ($page > $totalPages && $totalPages > 0) {
    header('Location: /catalog?type=' . rawurlencode($type) . '&page=' . $totalPages, true, 302);
    exit;
}

$base = rtrim(SITE_URL, '/') . '/';
$canonical = $base . 'catalog?type=' . rawurlencode($type) . ($page > 1 ? '&page=' . $page : '');
$titleFa = $type === 'series' ? 'لیست سریال‌های بانک مووی' : 'لیست فیلم‌های بانک مووی';
$desc = $type === 'series'
    ? 'آرشیو قابل پیمایش سریال‌های بانک مووی با لینک مستقیم به صفحات دانلود، دوبله و زیرنویس.'
    : 'آرشیو قابل پیمایش فیلم‌های بانک مووی با لینک مستقیم به صفحات دانلود، دوبله و زیرنویس.';
$userLang = $_COOKIE['user_lang'] ?? 'fa';
function bm_catalog_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function bm_catalog_page_url(string $type, int $page): string { $url='/catalog?type=' . rawurlencode($type); return $page > 1 ? $url . '&page=' . max(1,$page) : $url; }
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta name="theme-color" content="#05050a">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?= bm_catalog_h($titleFa) ?> - صفحه <?= (int)$page ?> | BankMovie</title>
    <meta name="description" content="<?= bm_catalog_h($desc) ?> صفحه <?= (int)$page ?> از <?= (int)$totalPages ?>.">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
    <link rel="canonical" href="<?= bm_catalog_h($canonical) ?>">
    <?php if ($page > 1): ?><link rel="prev" href="<?= bm_catalog_h(rtrim($base, '/') . bm_catalog_page_url($type, $page - 1)) ?>"><?php endif; ?>
    <?php if ($page < $totalPages): ?><link rel="next" href="<?= bm_catalog_h(rtrim($base, '/') . bm_catalog_page_url($type, $page + 1)) ?>"><?php endif; ?>
    <style>
        :root{--bg:#07080d;--card:#10131c;--line:rgba(255,255,255,.09);--txt:#fff;--muted:#a9b0c2;--accent:#2f7cff}
        *{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at top,#12182a 0,#07080d 45%,#05060a 100%);color:var(--txt);font-family:system-ui,-apple-system,Segoe UI,Roboto,Tahoma,sans-serif;min-height:100vh;padding:24px 14px 120px}.wrap{max-width:1180px;margin:0 auto}.top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}.brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff;font-weight:900}.brand img{height:48px;width:auto}.nav{display:flex;gap:8px;flex-wrap:wrap}.nav a{color:#fff;text-decoration:none;border:1px solid var(--line);background:rgba(255,255,255,.04);padding:10px 13px;border-radius:14px;font-size:13px;font-weight:800}.nav a.active{background:rgba(47,124,255,.18);border-color:rgba(47,124,255,.35);color:#dce9ff}.hero{border:1px solid var(--line);background:linear-gradient(135deg,rgba(47,124,255,.16),rgba(255,255,255,.03));border-radius:24px;padding:18px;margin-bottom:18px}.hero h1{font-size:24px;margin:0 0 7px}.hero p{margin:0;color:var(--muted);line-height:1.8;font-size:14px}.stats{display:inline-flex;margin-top:12px;color:#dce9ff;background:rgba(47,124,255,.13);border:1px solid rgba(47,124,255,.22);border-radius:999px;padding:7px 12px;font-size:12px;font-weight:900}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:14px}.card{background:rgba(16,19,28,.86);border:1px solid var(--line);border-radius:18px;overflow:hidden;text-decoration:none;color:#fff;display:block;min-height:100%;box-shadow:0 12px 30px rgba(0,0,0,.22)}.poster{aspect-ratio:2/3;background:#0c0f18;display:flex;align-items:center;justify-content:center;color:#596176;font-size:12px;overflow:hidden}.poster img{width:100%;height:100%;object-fit:cover;display:block}.body{padding:10px}.fa{font-weight:900;font-size:13px;line-height:1.6;min-height:42px}.en{color:#8ea0c8;font-size:12px;direction:ltr;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:4px}.meta{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px;color:#b8c0d3;font-size:11px}.rate{color:#ffd166}.pages{display:flex;align-items:center;justify-content:center;gap:8px;flex-wrap:wrap;margin:24px 0 10px}.pages a,.pages span{min-width:38px;height:38px;padding:0 12px;display:inline-flex;align-items:center;justify-content:center;border-radius:13px;border:1px solid var(--line);text-decoration:none;color:#fff;background:rgba(255,255,255,.04);font-size:13px;font-weight:900}.pages .cur{background:var(--accent);border-color:var(--accent)}.empty{border:1px solid var(--line);border-radius:20px;padding:24px;text-align:center;color:var(--muted);background:rgba(255,255,255,.035)}@media(max-width:520px){body{padding-left:10px;padding-right:10px}.grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.top{align-items:flex-start}.hero h1{font-size:20px}.brand img{height:40px}.nav a{font-size:12px;padding:9px 10px}.card{border-radius:15px}.body{padding:8px}.fa{font-size:12px}}
    </style>
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body>
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>
<div class="wrap">
    <div class="top">
        <a class="brand" href="/"><img src="/assets/brand/bankmovie-logo.webp?v=perf32" alt="BankMovie"><span>BankMovie</span></a>
        <div class="nav">
            <a href="<?= bm_catalog_h(bm_catalog_page_url('movie', 1)) ?>" class="<?= $type === 'movie' ? 'active' : '' ?>">فیلم‌ها</a>
            <a href="<?= bm_catalog_h(bm_catalog_page_url('series', 1)) ?>" class="<?= $type === 'series' ? 'active' : '' ?>">سریال‌ها</a>
            <a href="/collections">کالکشن‌ها</a>
            <a href="/map">نقشه سایت</a>
        </div>
    </div>

    <section class="hero">
        <h1><?= bm_catalog_h($titleFa) ?> - صفحه <?= (int)$page ?></h1>
        <p><?= bm_catalog_h($desc) ?></p>
        <div class="stats"><?= number_format($total) ?> عنوان، <?= number_format($totalPages) ?> صفحه قابل پیمایش</div>
    </section>

    <?php if (!$items): ?>
        <div class="empty">موردی برای نمایش پیدا نشد.</div>
    <?php else: ?>
        <div class="grid">
            <?php foreach ($items as $movie):
                $url = bm_movie_url($movie);
                $nameFa = trim((string)($movie['title_fa'] ?? '')) ?: trim((string)($movie['title'] ?? ''));
                $nameEn = trim((string)($movie['title'] ?? ''));
                $imdb = trim((string)($movie['imdb_code'] ?? ''));
                $posterPath = $imdb !== '' ? __DIR__ . '/posters/' . basename($imdb) . '.webp' : '';
                $posterUrl = ($posterPath && is_file($posterPath)) ? '/posters/' . rawurlencode($imdb) . '.webp' : '';
            ?>
            <a class="card" href="<?= bm_catalog_h($url) ?>">
                <div class="poster"><?php if ($posterUrl): ?><img src="<?= bm_catalog_h($posterUrl) ?>" alt="<?= bm_catalog_h($nameFa) ?>" loading="lazy"><?php else: ?>بدون پوستر<?php endif; ?></div>
                <div class="body">
                    <div class="fa"><?= bm_catalog_h($nameFa) ?></div>
                    <div class="en"><?= bm_catalog_h($nameEn) ?></div>
                    <div class="meta"><span><?= bm_catalog_h($movie['year'] ?? '') ?></span><span class="rate">★ <?= bm_catalog_h($movie['imdb_rate'] ?? '-') ?></span></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <nav class="pages" aria-label="صفحه‌بندی">
        <?php if ($page > 1): ?><a href="<?= bm_catalog_h(bm_catalog_page_url($type, $page - 1)) ?>">قبلی</a><?php endif; ?>
        <?php
        $start = max(1, $page - 3); $end = min($totalPages, $page + 3);
        if ($start > 1) echo '<a href="' . bm_catalog_h(bm_catalog_page_url($type, 1)) . '">1</a><span>…</span>';
        for ($i = $start; $i <= $end; $i++) {
            if ($i === $page) echo '<span class="cur">' . $i . '</span>';
            else echo '<a href="' . bm_catalog_h(bm_catalog_page_url($type, $i)) . '">' . $i . '</a>';
        }
        if ($end < $totalPages) echo '<span>…</span><a href="' . bm_catalog_h(bm_catalog_page_url($type, $totalPages)) . '">' . $totalPages . '</a>';
        ?>
        <?php if ($page < $totalPages): ?><a href="<?= bm_catalog_h(bm_catalog_page_url($type, $page + 1)) ?>">بعدی</a><?php endif; ?>
    </nav>
</div>
<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('catalog.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
