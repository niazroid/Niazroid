<?php header('Content-Type: text/plain; charset=utf-8'); echo "BM-ARC2-INTERNAL-PLAYER-V16\narchive2_internal=dedicated\narchive1_delegate=blocked-for-archive2\nplay_choice=1486201\n";
