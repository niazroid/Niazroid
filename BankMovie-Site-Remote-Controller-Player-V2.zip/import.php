<?php
// scraper_advanced_update.php
// اسکرپر پیشرفته با قابلیت بروزرسانی، تبدیل ژانر به انگلیسی (با فرمت کاما + فاصله) و استخراج رده سنی

require_once __DIR__ . '/includes/admin_guard.php';
require_admin();

$csrf_token = admin_csrf_token();
admin_enforce_csrf();

require_once 'config.php';

// ==================== جدول تبدیل ژانر فارسی به انگلیسی ====================
function getGenreMapping() {
    return [
        'اکشن' => 'Action',
        'انیمیشن' => 'Animation',
        'انیمیشن' => 'Animation',
        'بیوگرافی' => 'Biography',
        'بیوگرافی تاریخی' => 'Biography',
        'تاریخی' => 'History',
        'تاک شو' => 'Talk-Show',
        'تالک شوترسناک' => 'Talk-Show',
        'ترسناک' => 'Horror',
        'جنایی' => 'Crime',
        'جنکی' => 'Action',
        'خانوادگگی' => 'Family',
        'خانوادگی' => 'Family',
        'خبری' => 'News',
        'درام' => 'Drama',
        'ریتیلی تیوی' => 'Reality-TV',
        'ریئلیتی تیوی' => 'Reality-TV',
        'زندگی نامه' => 'Biography',
        'شوی تلوزیونی' => 'TV Show',
        'عاشقانه' => 'Romance',
        'علمی تخیلبی' => 'Sci-Fi',
        'علمی تخیلی' => 'Sci-Fi',
        'فانتزی' => 'Fantasy',
        'فیلم نوار' => 'Film-Noir',
        'فیلم نوآر' => 'Film-Noir',
        'کمدی' => 'Comedy',
        'کوتاه' => 'Short',
        'گیم شو' => 'Game-Show',
        'ماجراجویی' => 'Adventure',
        'مستند' => 'Documentary',
        'معمایی' => 'Mystery',
        'موزیک' => 'Music',
        'موزیکال' => 'Musical',
        'موزیمکا' => 'Music',
        'موسیقثی' => 'Music',
        'هیجان انگیز' => 'Thriller',
        'هیجان انگکیز' => 'Thriller',
        'ورزشی' => 'Sport',
        'وسترن' => 'Western'
    ];
}

function translateGenres($persianGenres) {
    $map = getGenreMapping();
    $englishGenres = [];
    foreach ($persianGenres as $pg) {
        $pg = trim($pg);
        if (isset($map[$pg])) {
            $englishGenres[] = $map[$pg];
        } else {
            // اگر پیدا نشد، خود فارسی را نگه دار (اختیاری)
            $englishGenres[] = $pg;
        }
    }
    return array_unique($englishGenres);
}

function extractFromHtml($html) {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $dom->loadHTML(mb_convert_encoding($html, 'HTML-ENTITIES', 'UTF-8'));
    libxml_clear_errors();
    $xpath = new DOMXPath($dom);
    
    // عنوان انگلیسی و تشخیص نوع فیلم/سریال از روی h1
    $titleEn = '';
    $type = 'movie';
    $h1 = $xpath->query('//h1');
    if ($h1->length) {
        $h1Text = trim($h1->item(0)->nodeValue);
        if (mb_strpos($h1Text, 'سریال') !== false) {
            $type = 'tvSeries';
        }
        $titleEn = trim(preg_replace('/^(دانلود سریال|دانلود فیلم)\s+/u', '', $h1Text));
    }
    
    // عنوان فارسی
    $titleFa = '';
    $h2 = $xpath->query('//h2');
    if ($h2->length) $titleFa = trim($h2->item(0)->nodeValue);
    
    // کد IMDb
    $imdbCode = '';
    $imdbLink = $xpath->query('//a[contains(@href, "imdb.com/title/tt")]');
    if ($imdbLink->length && preg_match('/tt\d+/', $imdbLink->item(0)->getAttribute('href'), $m)) {
        $imdbCode = $m[0];
    }
    
    // امتیاز و رای
    $rate = 0; $votes = 0;
    $rateDiv = $xpath->query('//div[contains(@class, "-rate-number")]');
    if ($rateDiv->length) {
        $fullText = trim($rateDiv->item(0)->nodeValue);
        if (preg_match('/(\d+(?:\.\d+)?)\/10\s+(\d+(?:,\d+)?)/', $fullText, $matches)) {
            $rate = floatval($matches[1]);
            $votes = intval(str_replace(',', '', $matches[2]));
        }
    }
    
    // سال انتشار
    $year = 0;
    $yearSpan = $xpath->query('//span[contains(text(), "سال انتشار")]/following-sibling::a');
    if ($yearSpan->length) {
        $year = intval(trim($yearSpan->item(0)->nodeValue));
    }
    if ($year == 0) {
        $yearLink = $xpath->query('//a[contains(@href, "/release-series/") or contains(@href, "/release/")]');
        if ($yearLink->length) {
            $year = intval(trim($yearLink->item(0)->nodeValue));
        }
    }
    
    // کشور
    $country = '';
    $countrySpan = $xpath->query('//span[contains(text(), "محصول")]/following-sibling::a');
    if ($countrySpan->length) $country = trim($countrySpan->item(0)->nodeValue);
    
    // زبان
    $language = '';
    $langSpan = $xpath->query('//li[contains(., "زبان")]//a');
    if ($langSpan->length) $language = trim($langSpan->item(0)->nodeValue);
    
    // توضیحات
    $description = '';
    $plotDiv = $xpath->query('//div[contains(@class, "-plot")]//p');
    if ($plotDiv->length) $description = trim($plotDiv->item(0)->nodeValue);
    
    // پوستر
    $posterUrl = '';
    $posterImg = $xpath->query('//div[contains(@class, "post-poster")]//img');
    if ($posterImg->length) {
        $src = $posterImg->item(0)->getAttribute('src');
        $posterUrl = preg_replace('/-\d+x\d+\./', '.', $src);
        if (strpos($posterUrl, 'http') !== 0) $posterUrl = 'https://serialblog1.top' . $posterUrl;
    }
    
    // ========== استخراج ژانرها ==========
    $genresPersian = [];
    $genreContainer = $xpath->query('//span[contains(@class, "pr-genre")]');
    if ($genreContainer->length) {
        $genreLinks = $xpath->query('.//a', $genreContainer->item(0));
        foreach ($genreLinks as $link) {
            $genreText = trim($link->nodeValue);
            if (!empty($genreText)) {
                $genresPersian[] = $genreText;
            }
        }
    }
    $genresEnglish = translateGenres($genresPersian);
    // ✅ ذخیره با کاما و فاصله
    $genresString = implode(', ', $genresEnglish);
    
    // ========== استخراج رده سنی (rated) ==========
    $rated = '';
    $infoItems = $xpath->query('//ul[contains(@class, "flex-single-info")]/li');
    foreach ($infoItems as $item) {
        $itemText = $item->textContent;
        if (mb_strpos($itemText, 'رده سنی') !== false) {
            if (preg_match('/رده سنی\s*[\:\s]+([^\n]+)/u', $itemText, $matches)) {
                $rated = trim($matches[1]);
            } else {
                $valueNode = $xpath->query('.//text()[last()]', $item);
                if ($valueNode->length) {
                    $rated = trim($valueNode->item(0)->nodeValue);
                }
            }
            break;
        }
    }
    
    // لینک‌های دانلود
    $downloads = [];
    $downloadBox = $xpath->query('//div[contains(@class, "download_box")]');
    if ($downloadBox->length) {
        $allLinks = $xpath->query('.//a', $downloadBox->item(0));
        foreach ($allLinks as $link) {
            $url = $link->getAttribute('href');
            $anchorText = trim($link->nodeValue);
            $parentText = $link->parentNode ? trim($link->parentNode->textContent) : '';
            $fullText = $anchorText . ' ' . $parentText;
            
            if (strpos($url, 'rzb.ir') !== false || strpos($url, '10_thous.html') !== false) continue;
            
            $size = '';
            if (preg_match('/حجم:\s*([\d\.]+)\s*(MB|GB|KB)/i', $fullText, $s)) $size = trim($s[1] . ' ' . $s[2]);
            elseif (preg_match('/\(([\d\.]+)\s*(MB|GB|KB)\)/i', $fullText, $s)) $size = trim($s[1] . ' ' . $s[2]);
            elseif (preg_match('/(\d+(?:\.\d+)?)\s*(MB|GB|KB)/i', $fullText, $s)) $size = trim($s[1] . ' ' . $s[2]);
            
            $quality = 'HD';
            $patterns = [
                '/(S\d{2}\s*-\s*)?(480p|720p|1080p|4K)\s*(BluRay|Web-DL|WEBRip|BluRay\.?)/i',
                '/(S\d{2}\s*-\s*)?(480p|720p|1080p|4K)/i',
            ];
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $anchorText . ' ' . $url, $q)) {
                    $quality = trim(preg_replace('/\s+/', ' ', $q[0]));
                    break;
                }
            }
            
            $dlType = 'unknown';
            if (stripos($url, 'SoftSub') !== false) $dlType = 'softsub';
            elseif (stripos($url, 'Dubbed') !== false) $dlType = 'dubbed';
            elseif (stripos($url, 'NoSub') !== false) $dlType = 'nosub';
            
            $season = null;
            if (preg_match('/\/S(\d{2})\//i', $url, $se)) $season = (int)$se[1];
            elseif (preg_match('/[_-]S(\d{2})/i', $anchorText, $se)) $season = (int)$se[1];
            
            $is_folder = 0;
            if (substr($url, -1) == '/' && !preg_match('/\.(mkv|mp4|avi|rar|zip)$/i', $url)) $is_folder = 1;
            if (preg_match('/لینک\s*های\s*دانلود/i', $anchorText)) $is_folder = 1;
            if (preg_match('/^\d{3,4}p\.BluRay$/i', $anchorText)) $is_folder = 1;
            
            $downloads[] = [
                'type' => $dlType,
                'quality' => $quality,
                'url' => $url,
                'size' => $size,
                'season' => $season,
                'is_folder' => $is_folder
            ];
        }
    }
    
    return [
        'title_en' => $titleEn,
        'title_fa' => $titleFa,
        'imdb_code' => $imdbCode,
        'rate' => $rate,
        'votes' => $votes,
        'year' => $year,
        'type' => $type,
        'country' => $country,
        'language' => $language,
        'description' => $description,
        'poster_url' => $posterUrl,
        'genres' => $genresString,
        'rated' => $rated,
        'downloads' => $downloads
    ];
}

// تابع بروزرسانی یا درج هوشمند (upsert)
function upsertMovie($pdo, $data) {
    $imdb = $data['imdb_code'];
    if (empty($imdb)) return ['status' => 'error', 'msg' => '❌ کد IMDb یافت نشد'];
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("SELECT id FROM movies WHERE imdb_code = ?");
        $stmt->execute([$imdb]);
        $exists = $stmt->fetch();
        
        if ($exists) {
            $movieId = $exists['id'];
            $updateFields = [];
            $params = [];
            
            $fieldsMap = [
                'title' => $data['title_en'],
                'title_fa' => $data['title_fa'],
                'type' => $data['type'],
                'year' => $data['year'],
                'imdb_rate' => $data['rate'],
                'imdb_votes' => $data['votes'],
                'description' => $data['description'],
                'country' => $data['country'],
                'genres' => $data['genres']
            ];
            
            foreach ($fieldsMap as $col => $val) {
                if (!empty($val) || (is_numeric($val) && $val > 0)) {
                    $updateFields[] = "$col = ?";
                    $params[] = $val;
                }
            }
            
            if (!empty($updateFields)) {
                $updateFields[] = "updated_at = NOW()";
                $sql = "UPDATE movies SET " . implode(', ', $updateFields) . " WHERE id = ?";
                $params[] = $movieId;
                $pdo->prepare($sql)->execute($params);
            }
            
            // بروزرسانی movie_extra_info
            $extraExists = $pdo->prepare("SELECT id FROM movie_extra_info WHERE imdb_code = ?");
            $extraExists->execute([$imdb]);
            if ($extraExists->fetch()) {
                $extraUpdate = [];
                $extraParams = [];
                if (!empty($data['language'])) {
                    $extraUpdate[] = "language = ?";
                    $extraParams[] = $data['language'];
                }
                if (!empty($data['rated'])) {
                    $extraUpdate[] = "rated = ?";
                    $extraParams[] = $data['rated'];
                }
                if (!empty($extraUpdate)) {
                    $extraUpdate[] = "updated_at = NOW()";
                    $extraParams[] = $imdb;
                    $sqlExtra = "UPDATE movie_extra_info SET " . implode(', ', $extraUpdate) . " WHERE imdb_code = ?";
                    $pdo->prepare($sqlExtra)->execute($extraParams);
                }
            } else {
                $sqlExtra = "INSERT INTO movie_extra_info (imdb_code, language, production_companies, status, rated, seasons, episodes, created_at, updated_at)
                             VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
                $pdo->prepare($sqlExtra)->execute([$imdb, $data['language'] ?? '', '', '', $data['rated'] ?? '', null, null]);
            }
            
            $action = 'updated';
            $msg = "🔄 اطلاعات موجود بروزرسانی شد (ژانرها: {$data['genres']}, رده سنی: {$data['rated']})";
        } else {
            $sql = "INSERT INTO movies (title, title_fa, type, year, imdb_rate, imdb_votes, imdb_code, description, country, genres, director, actors, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $data['title_en'], $data['title_fa'], $data['type'], $data['year'],
                $data['rate'], $data['votes'], $imdb, $data['description'], $data['country'],
                $data['genres'], '', ''
            ]);
            $movieId = $pdo->lastInsertId();
            
            $sqlExtra = "INSERT INTO movie_extra_info (imdb_code, language, production_companies, status, rated, seasons, episodes, created_at, updated_at)
                         VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
            $pdo->prepare($sqlExtra)->execute([$imdb, $data['language'], '', '', $data['rated'], null, null]);
            
            $action = 'inserted';
            $msg = "✅ آیتم جدید با موفقیت اضافه شد (ژانرها: {$data['genres']}, رده سنی: {$data['rated']})";
        }
        
        // حذف لینک‌های قدیمی و درج جدید
        $pdo->prepare("DELETE FROM softsub_links WHERE movie_id = ?")->execute([$movieId]);
        $pdo->prepare("DELETE FROM dubbed_links WHERE movie_id = ?")->execute([$movieId]);
        
        $softsubCount = 0;
        $dubbedCount = 0;
        foreach ($data['downloads'] as $dl) {
            if ($dl['type'] == 'softsub') {
                $sqlLink = "INSERT INTO softsub_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)";
                $pdo->prepare($sqlLink)->execute([$movieId, $dl['quality'], $dl['url'], $dl['size'], $dl['season'], $dl['is_folder']]);
                $softsubCount++;
            } elseif ($dl['type'] == 'dubbed') {
                $sqlLink = "INSERT INTO dubbed_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)";
                $pdo->prepare($sqlLink)->execute([$movieId, $dl['quality'], $dl['url'], $dl['size'], $dl['season'], $dl['is_folder']]);
                $dubbedCount++;
            }
        }
        
        $pdo->commit();
        return [
            'status' => 'success',
            'msg' => "$msg (لینک‌های سافت‌ساب: $softsubCount - دوبله: $dubbedCount)",
            'movie_id' => $movieId,
            'action' => $action
        ];
        
    } catch (Exception $e) {
        $pdo->rollBack();
        return ['status' => 'error', 'msg' => '❌ خطا در دیتابیس: ' . $e->getMessage()];
    }
}

// پردازش فرم
$resultMsg = '';
$movieData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['html_file']) && $_FILES['html_file']['error'] === UPLOAD_ERR_OK) {
        $html = file_get_contents($_FILES['html_file']['tmp_name']);
        if ($html) {
            $movieData = extractFromHtml($html);
            if (empty($movieData['imdb_code'])) {
                $resultMsg = "❌ کد IMDb در این صفحه یافت نشد.";
            } else {
                $importResult = upsertMovie($pdo, $movieData);
                $resultMsg = $importResult['msg'];
                $movieData['action'] = $importResult['action'] ?? 'none';
            }
        } else {
            $resultMsg = "❌ خطا در خواندن فایل";
        }
    } elseif (isset($_POST['html_code']) && !empty($_POST['html_code'])) {
        $html = $_POST['html_code'];
        $movieData = extractFromHtml($html);
        if (empty($movieData['imdb_code'])) {
            $resultMsg = "❌ کد IMDb در این صفحه یافت نشد.";
        } else {
            $importResult = upsertMovie($pdo, $movieData);
            $resultMsg = $importResult['msg'];
            $movieData['action'] = $importResult['action'] ?? 'none';
        }
    } else {
        $resultMsg = "❌ لطفاً یک فایل یا کد HTML وارد کنید";
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>اسکرپر هوشمند فیلم و سریال | تبدیل ژانر + رده سنی</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:opsz,wght@14..32,400;14..32,500;14..32,600;14..32,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            font-family: 'Inter', 'Tahoma', system-ui, sans-serif;
            padding: 2rem 1rem;
            min-height: 100vh;
            color: #f1f5f9;
        }
        .container { max-width: 1300px; margin: 0 auto; }
        .header-card, .glass-card {
            background: rgba(30, 41, 59, 0.7);
            backdrop-filter: blur(16px);
            border-radius: 2rem;
            border: 1px solid rgba(255,255,255,0.15);
            padding: 2rem;
            margin-bottom: 2rem;
        }
        .header-card h1 {
            font-size: 1.8rem;
            font-weight: 700;
            background: linear-gradient(120deg, #a5f3fc, #c084fc);
            background-clip: text;
            -webkit-background-clip: text;
            color: transparent;
            display: inline-flex;
            align-items: center;
            gap: 12px;
        }
        .badge {
            background: #0f172a;
            padding: 6px 14px;
            border-radius: 40px;
            font-size: 0.75rem;
            font-weight: 500;
            color: #94a3b8;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }
        .features-grid {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            margin-top: 1.2rem;
        }
        .feature {
            background: rgba(0,0,0,0.3);
            border-radius: 60px;
            padding: 0.4rem 1rem;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #cbd5e1;
        }
        .form-group { margin-bottom: 1.5rem; }
        label {
            font-weight: 600;
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 8px;
            color: #e2e8f0;
        }
        input, textarea {
            width: 100%;
            padding: 0.9rem 1.2rem;
            background: #1e293b;
            border: 1px solid #334155;
            border-radius: 1.2rem;
            color: white;
            font-size: 0.95rem;
            transition: all 0.2s;
            font-family: inherit;
        }
        input:focus, textarea:focus {
            outline: none;
            border-color: #818cf8;
            box-shadow: 0 0 0 3px rgba(129, 140, 248, 0.3);
        }
        .file-zone {
            border: 2px dashed #475569;
            background: #0f172a80;
            border-radius: 1.5rem;
            padding: 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
        }
        .file-zone:hover { border-color: #818cf8; background: #1e293b; }
        button {
            background: linear-gradient(90deg, #4f46e5, #7c3aed);
            border: none;
            padding: 1rem 1.8rem;
            border-radius: 3rem;
            font-weight: 700;
            font-size: 1rem;
            color: white;
            cursor: pointer;
            transition: all 0.2s;
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        button:hover { transform: translateY(-2px); filter: brightness(1.05); }
        .result-box {
            margin-top: 1.5rem;
            padding: 1.2rem;
            border-radius: 1.2rem;
            font-weight: 500;
            border-right: 6px solid;
        }
        .result-success { background: #064e3b30; border-right-color: #10b981; color: #a7f3d0; }
        .result-error { background: #7f1a1a30; border-right-color: #ef4444; color: #fecaca; }
        .result-skip { background: #854d0e30; border-right-color: #f59e0b; color: #fed7aa; }
        pre {
            background: #0f172a;
            padding: 1rem;
            border-radius: 1rem;
            overflow-x: auto;
            font-size: 0.8rem;
            font-family: monospace;
            border: 1px solid #334155;
            margin-top: 1.2rem;
        }
        .data-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            margin-bottom: 1rem;
        }
        .type-badge {
            background: #0ea5e9;
            padding: 0.3rem 1rem;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: bold;
        }
        .download-stats {
            display: flex;
            gap: 15px;
            margin-top: 10px;
            font-size: 0.8rem;
        }
        .loader {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 2px solid #fff;
            border-radius: 50%;
            border-top-color: transparent;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .footer { text-align: center; font-size: 0.75rem; color: #64748b; margin-top: 2rem; }
        hr { border-color: #334155; margin: 1.2rem 0; }
    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
</head>
<body>
<div class="container">
    <div class="header-card">
        <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap;">
            <h1><i class="fas fa-robot"></i> اسکرپر حرفه‌ای <span style="font-weight:400">فیلم و سریال</span></h1>
            <div class="badge"><i class="fas fa-sync-alt"></i> بروزرسانی خودکار + تبدیل ژانر + رده سنی</div>
        </div>
        <div class="features-grid">
            <div class="feature"><i class="fas fa-microchip"></i> تشخیص type از h1</div>
            <div class="feature"><i class="fas fa-tag"></i> ژانر فارسی → انگلیسی (Action, Crime, Thriller)</div>
            <div class="feature"><i class="fas fa-child"></i> استخراج رده سنی (rated)</div>
            <div class="feature"><i class="fas fa-database"></i> آپدیت اطلاعات قدیمی</div>
            <div class="feature"><i class="fas fa-link"></i> لینک‌های دانلود</div>
        </div>
    </div>

    <div class="glass-card">
        <form method="POST" enctype="multipart/form-data" id="scrapeForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <div class="form-group">
                <label><i class="fas fa-file-upload"></i> آپلود فایل HTML (ذخیره صفحه)</label>
                <div class="file-zone" id="fileZone">
                    <i class="fas fa-cloud-upload-alt fa-2x" style="opacity:0.7"></i>
                    <p style="margin-top:8px">فایل HTML را اینجا کلیک کنید یا بکشید</p>
                    <input type="file" name="html_file" id="htmlFile" accept=".html,.htm" style="display: none;">
                </div>
            </div>
            <div class="form-group">
                <label><i class="fas fa-code"></i> یا کد HTML را مستقیما وارد کنید</label>
                <textarea name="html_code" rows="5" placeholder="<html> ... محتوای کامل صفحه ... </html>" id="htmlCode"></textarea>
            </div>
            <button type="submit" id="submitBtn"><i class="fas fa-magic"></i> پردازش و بروزرسانی دیتابیس</button>
        </form>
        
        <?php if ($resultMsg): ?>
            <div class="result-box result-<?= strpos($resultMsg, 'موفقیت') !== false ? 'success' : (strpos($resultMsg, 'بروزرسانی') !== false ? 'success' : (strpos($resultMsg, 'خطا') !== false ? 'error' : 'skip')) ?>">
                <i class="fas fa-<?= strpos($resultMsg, 'موفق') !== false || strpos($resultMsg, 'بروز') !== false ? 'check-circle' : (strpos($resultMsg, 'خطا') !== false ? 'exclamation-triangle' : 'info-circle') ?>"></i>
                <?= htmlspecialchars($resultMsg) ?>
            </div>
        <?php endif; ?>
    </div>

    <?php if ($movieData && !empty($movieData['imdb_code'])): ?>
    <div class="glass-card">
        <div class="data-header">
            <h3><i class="fas fa-film"></i> اطلاعات استخراج شده</h3>
            <span class="type-badge"><i class="fas fa-<?= $movieData['type'] == 'tvSeries' ? 'tv' : 'video' ?>"></i> <?= $movieData['type'] == 'tvSeries' ? 'سریال (tvSeries)' : 'فیلم (movie)' ?></span>
        </div>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap: 12px; background:#0f172a60; padding: 1rem; border-radius: 1rem;">
            <div><i class="fas fa-tag"></i> <strong>کد IMDb:</strong> <?= htmlspecialchars($movieData['imdb_code']) ?></div>
            <div><i class="fas fa-heading"></i> <strong>عنوان اصلی:</strong> <?= htmlspecialchars($movieData['title_en'] ?: 'نامشخص') ?></div>
            <div><i class="fas fa-language"></i> <strong>عنوان فارسی:</strong> <?= htmlspecialchars($movieData['title_fa'] ?: 'ندارد') ?></div>
            <div><i class="fas fa-calendar"></i> <strong>سال:</strong> <?= $movieData['year'] ?: 'نامشخص' ?></div>
            <div><i class="fas fa-star" style="color:#fbbf24"></i> <strong>امتیاز:</strong> <?= $movieData['rate'] ?: '-' ?> (<?= number_format($movieData['votes']) ?> رای)</div>
            <div><i class="fas fa-globe"></i> <strong>کشور:</strong> <?= htmlspecialchars($movieData['country'] ?: '—') ?></div>
            <div><i class="fas fa-microphone-alt"></i> <strong>زبان:</strong> <?= htmlspecialchars($movieData['language'] ?: '—') ?></div>
            <div><i class="fas fa-tags"></i> <strong>ژانرها (انگلیسی):</strong> <?= htmlspecialchars($movieData['genres'] ?: '—') ?></div>
            <div><i class="fas fa-child"></i> <strong>رده سنی:</strong> <?= htmlspecialchars($movieData['rated'] ?: '—') ?></div>
        </div>
        <?php if($movieData['description']): ?>
        <div style="margin-top: 1rem;">
            <strong><i class="fas fa-align-left"></i> خلاصه داستان:</strong>
            <p style="margin-top: 6px; line-height: 1.5; font-size: 0.9rem;"><?= nl2br(htmlspecialchars($movieData['description'])) ?></p>
        </div>
        <?php endif; ?>
        <div class="download-stats">
            <span><i class="fas fa-download"></i> سافت‌ساب: <?= count(array_filter($movieData['downloads'], fn($d)=>$d['type']=='softsub')) ?></span>
            <span><i class="fas fa-microphone"></i> دوبله: <?= count(array_filter($movieData['downloads'], fn($d)=>$d['type']=='dubbed')) ?></span>
        </div>
        <hr>
        <details>
            <summary style="cursor: pointer; font-weight: 600;"><i class="fas fa-list-ul"></i> نمایش جزییات کامل</summary>
            <pre><?php print_r($movieData); ?></pre>
        </details>
    </div>
    <?php endif; ?>
    <div class="footer">
        <i class="fas fa-shield-alt"></i> اسکرپر پیشرفته | ژانرهای فارسی خودکار به انگلیسی با فرمت "Action, Crime, Thriller" تبدیل می‌شوند.
    </div>
</div>
<script>
    const fileZone = document.getElementById('fileZone');
    const fileInput = document.getElementById('htmlFile');
    if(fileZone && fileInput) {
        fileZone.addEventListener('click', () => fileInput.click());
        fileZone.addEventListener('dragover', (e) => { e.preventDefault(); fileZone.style.borderColor = '#818cf8'; });
        fileZone.addEventListener('dragleave', () => fileZone.style.borderColor = '#475569');
        fileZone.addEventListener('drop', (e) => {
            e.preventDefault();
            const dt = e.dataTransfer;
            const files = dt.files;
            if(files.length) {
                fileInput.files = files;
                fileZone.querySelector('p').innerHTML = `<i class="fas fa-check-circle"></i> ${files[0].name}`;
            }
            fileZone.style.borderColor = '#475569';
        });
        fileInput.addEventListener('change', function() {
            if(this.files.length) {
                fileZone.querySelector('p').innerHTML = `<i class="fas fa-file-code"></i> ${this.files[0].name}`;
            } else {
                fileZone.querySelector('p').innerHTML = 'فایل HTML را اینجا کلیک کنید یا بکشید';
            }
        });
    }
    const form = document.getElementById('scrapeForm');
    const submitBtn = document.getElementById('submitBtn');
    if(form) {
        form.addEventListener('submit', function() {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<div class="loader"></div> در حال پردازش...';
        });
    }
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>