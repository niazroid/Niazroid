<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/site_content_control.php';
header('Content-Type: application/manifest+json; charset=utf-8');
header('Cache-Control: public, max-age=300, must-revalidate');
$data = [
  'id' => '/',
  'name' => (string)bm_site_get('pwa_name','بانک مووی | BankMovie'),
  'short_name' => (string)bm_site_get('pwa_short_name','BankMovie'),
  'description' => (string)bm_site_get('pwa_description','فیلم و سریال، جستجو، کالکشن‌ها و پخش آنلاین در نسخه وب بانک مووی'),
  'lang' => 'fa-IR',
  'dir' => 'rtl',
  'start_url' => '/?source=pwa',
  'scope' => '/',
  'display' => 'standalone',
  'display_override' => ['window-controls-overlay','standalone','minimal-ui','browser'],
  'orientation' => 'any',
  'background_color' => (string)bm_site_get('pwa_background_color','#05050a'),
  'theme_color' => (string)bm_site_get('pwa_theme_color','#05050a'),
  'categories' => ['entertainment','video'],
  'icons' => [
    ['src'=>'/assets/icons/icon-192.png?v=102.2','sizes'=>'192x192','type'=>'image/png','purpose'=>'any'],
    ['src'=>'/assets/icons/icon-512.png?v=102.2','sizes'=>'512x512','type'=>'image/png','purpose'=>'any'],
    ['src'=>'/assets/icons/icon-maskable-192.png?v=102.2','sizes'=>'192x192','type'=>'image/png','purpose'=>'maskable'],
    ['src'=>'/assets/icons/icon-maskable-512.png?v=102.2','sizes'=>'512x512','type'=>'image/png','purpose'=>'maskable'],
  ],
  'shortcuts' => [
    ['name'=>'خانه','short_name'=>'خانه','url'=>'/?source=pwa-shortcut','icons'=>[['src'=>'/assets/icons/icon-192.png?v=102.2','sizes'=>'192x192']]],
    ['name'=>'جستجو','short_name'=>'جستجو','url'=>'/search?source=pwa-shortcut','icons'=>[['src'=>'/assets/icons/icon-192.png?v=102.2','sizes'=>'192x192']]],
    ['name'=>'اپلیکیشن','short_name'=>'نصب','url'=>'/application?source=pwa-shortcut','icons'=>[['src'=>'/assets/icons/icon-192.png?v=102.2','sizes'=>'192x192']]],
  ],
  'screenshots' => [
    ['src'=>'/assets/app/bankmovie-app-screen-home-real.webp','sizes'=>'576x1280','type'=>'image/webp','form_factor'=>'narrow','label'=>'صفحه اصلی بانک مووی'],
    ['src'=>'/assets/app/bankmovie-app-screen-detail-real.webp','sizes'=>'576x1280','type'=>'image/webp','form_factor'=>'narrow','label'=>'صفحه جزئیات فیلم'],
    ['src'=>'/assets/app/bankmovie-app-screen-collections-real.webp','sizes'=>'576x1280','type'=>'image/webp','form_factor'=>'narrow','label'=>'کالکشن‌های بانک مووی'],
    ['src'=>'/assets/app/bankmovie-pwa-wide.webp','sizes'=>'1280x720','type'=>'image/webp','form_factor'=>'wide','label'=>'نمای نسخه وب بانک مووی روی چند صفحه'],
  ],
];
echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);
