<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/watch_party.php';

$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    }
    $expected = function_exists('bm_security_secret')
        ? bm_security_secret('watch_party_cron_token', 'BANKMOVIE_WATCH_PARTY_CRON_TOKEN')
        : '';
    $provided = trim((string)($_SERVER['HTTP_X_CRON_TOKEN'] ?? $_GET['token'] ?? ''));
    if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'not_found'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

$result = bm_watch_party_cleanup_expired($pdo, 5000);
$output = ['success' => true] + $result;
if ($isCli) {
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . PHP_EOL;
} else {
    echo json_encode($output, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
