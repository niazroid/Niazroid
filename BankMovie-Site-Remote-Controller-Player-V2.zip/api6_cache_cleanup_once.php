<?php
/**
 * پاک‌سازی یک‌باره کش حجیم API6.
 * اجرای وب فقط برای ادمین واردشده و با POST+CSRF مجاز است.
 * اجرای CLI نیز برای نگهداری سرور مجاز است.
 */
require_once __DIR__ . '/includes/security_bootstrap.php';

if (PHP_SAPI !== 'cli') {
    require_once __DIR__ . '/includes/admin_guard.php';
    require_admin();
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        exit('Method not allowed');
    }
    admin_enforce_csrf();
}

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

$base = rtrim(bm_security_private_dir(), '/\\');
$dir = $base . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'api6';

if (!is_dir($dir)) {
    exit("پوشه کش API6 پیدا نشد. هیچ فایلی حذف نشد.\n");
}

$deleted = 0;
$bytes = 0;
$failed = 0;
$iterator = new DirectoryIterator($dir);
foreach ($iterator as $entry) {
    if ($entry->isDot() || !$entry->isFile()) continue;
    $name = $entry->getFilename();
    if (!preg_match('/(?:\.html|\.html\.gz|\.tmp)$/i', $name)) continue;
    $size = max(0, (int)$entry->getSize());
    if (@unlink($entry->getPathname())) {
        $deleted++;
        $bytes += $size;
    } else {
        $failed++;
    }
}

@unlink($dir . '/.cleanup.stamp');
@unlink($dir . '/.cleanup.lock');
bm_security_audit('api6_cache_cleanup', ['deleted' => $deleted, 'bytes' => $bytes, 'failed' => $failed]);

echo "پاک‌سازی API6 انجام شد.\n";
echo "تعداد فایل حذف‌شده: {$deleted}\n";
echo "فضای آزادشده: " . number_format($bytes / 1024 / 1024, 2) . " MB\n";
echo "خطای حذف: {$failed}\n";
