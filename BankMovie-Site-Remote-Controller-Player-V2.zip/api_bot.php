<?php
// api_bot.php - واسط دیتابیس برای ربات تلگرام
require_once 'config.php';
require_once __DIR__ . '/includes/archive_control.php';

header('Content-Type: application/json; charset=utf-8');
bm_security_cors(['GET','OPTIONS'], ['Content-Type','X-BM-Bot-Key'], false);
bm_security_enforce_rate_limit('api_bot', 180, 300, bm_security_client_ip(), true);
$expectedBotKey = bm_security_secret('bot_api_key', 'BANKMOVIE_BOT_API_KEY');
if ($expectedBotKey !== '') {
    $providedBotKey = trim((string)($_SERVER['HTTP_X_BM_BOT_KEY'] ?? ''));
    if ($providedBotKey === '' || !hash_equals($expectedBotKey, $providedBotKey)) {
        http_response_code(401);
        echo json_encode(['success'=>false,'error'=>'unauthorized'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'search':
            $keyword = mb_substr(trim((string)($_GET['q'] ?? '')), 0, 100, 'UTF-8');
            if (strlen($keyword) < 2) {
                echo json_encode(['success' => false, 'error' => 'کلمه جستجو خیلی کوتاه است']);
                break;
            }
            $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, type FROM movies WHERE title LIKE ? OR title_fa LIKE ? LIMIT 15");
            $kw = "%$keyword%";
            $stmt->execute([$kw, $kw]);
            $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'data' => $movies]);
            break;

        case 'new_releases':
            $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, type FROM movies WHERE year >= YEAR(CURRENT_DATE)-2 ORDER BY year DESC, id DESC LIMIT 10");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'top_movies':
            $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, type FROM movies WHERE type='movie' AND imdb_rate>=7 ORDER BY imdb_rate DESC LIMIT 10");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'top_series':
            $stmt = $pdo->prepare("SELECT imdb_code, title, title_fa, year, type FROM movies WHERE (type='tvSeries' OR type='tvMiniSeries') AND imdb_rate>=7 ORDER BY imdb_rate DESC LIMIT 10");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'dubbed':
            $stmt = $pdo->prepare("SELECT DISTINCT m.imdb_code, m.title, m.title_fa, m.year, m.type FROM movies m JOIN dubbed_links d ON m.id=d.movie_id ORDER BY m.imdb_rate DESC LIMIT 10");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'admin_picks':
            $stmt = $pdo->prepare("SELECT m.imdb_code, m.title, m.title_fa, m.year, m.type FROM admin_picks ap JOIN movies m ON ap.movie_id=m.id ORDER BY ap.pick_order LIMIT 10");
            $stmt->execute();
            echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'movie_detail':
            $imdb = trim((string)($_GET['imdb'] ?? ''));
            if (!preg_match('/^tt\d{5,12}$/', $imdb)) {
                echo json_encode(['success' => false, 'error' => 'IMDB code required']);
                break;
            }
            $movieObj = new Movie($pdo);
            $movie = $movieObj->getByImdb($imdb);
            if ($movie) {
                // خلاصه اطلاعات مورد نیاز ربات
                $info = [
                    'imdb_code' => $movie['imdb_code'],
                    'title_fa' => $movie['title_fa'],
                    'title' => $movie['title'],
                    'year' => $movie['year'],
                    'imdb_rate' => $movie['imdb_rate'],
                    'imdb_votes' => $movie['imdb_votes'],
                    'genres' => $movie['genres'],
                    'director' => $movie['director'],
                    'actors' => $movie['actors'],
                    'description' => $movie['description'],
                    'has_dub' => !empty($movie['dubbed_links']),
                    'has_soft' => !empty($movie['softsub_links']),
                    'dub_link' => !empty($movie['dubbed_links']) ? bm_dl_wrap_url($movie['dubbed_links'][0]['url'], 21600, 'archive2') : null,
                    'soft_link' => !empty($movie['softsub_links']) ? bm_dl_wrap_url($movie['softsub_links'][0]['url'], 21600, 'archive2') : null
                ];
                $info = bm_archive_apply_payload_policy('archive2', $info, null, ['identifier'=>$imdb]);
                echo json_encode(['success' => true, 'data' => $info]);
            } else {
                echo json_encode(['success' => false, 'error' => 'فیلم یافت نشد']);
            }
            break;

        default:
            echo json_encode(['success' => false, 'error' => 'action not found']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'database error']);
}
