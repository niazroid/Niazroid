<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/boxoffice.php';

require_admin();
admin_enforce_csrf();
bm_boxoffice_schema($pdo);

$status = trim((string)($_GET['status'] ?? ''));
$statusType = trim((string)($_GET['type'] ?? 'ok')) === 'error' ? 'error' : 'ok';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = strtolower(trim((string)($_POST['action'] ?? '')));
    try {
        if ($action === 'save') {
            bm_boxoffice_save_settings($pdo, $_POST);
            bm_boxoffice_clear_cache($pdo);
            $status = 'تنظیمات ذخیره شد و کش برای دریافت تازه پاک شد.';
        } elseif ($action === 'test') {
            $weekend = bm_boxoffice_get_data($pdo, 'weekend', true);
            if (empty($weekend['success'])) throw new RuntimeException((string)($weekend['message'] ?? 'اتصال ناموفق بود.'));
            $status = 'دریافت با موفقیت انجام شد؛ ' . count((array)($weekend['items'] ?? [])) . ' فیلم دریافت شد.';
        } elseif ($action === 'clear_cache') {
            bm_boxoffice_clear_cache($pdo);
            $status = 'کش باکس آفیس پاک شد؛ اولین بازدید بعدی داده تازه دریافت می‌کند.';
        }
    } catch (Throwable $e) {
        $statusType = 'error';
        $status = 'عملیات انجام نشد: ' . mb_substr(preg_replace('/[\r\n\t]+/', ' ', $e->getMessage()) ?? $e->getMessage(), 0, 350, 'UTF-8');
        error_log('BoxOffice admin error: ' . $e->getMessage());
    }
    header('Location: admin_boxoffice.php?type=' . rawurlencode($statusType) . '&status=' . rawurlencode($status));
    exit;
}

$data = bm_boxoffice_admin_status($pdo);
$settings = $data['settings'];
$cache = $data['cache'];

function bm_bo_admin_h($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function bm_bo_admin_time($ts): string { $ts=(int)$ts; return $ts>0 ? date('Y/m/d H:i:s',$ts) : '—'; }
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>مدیریت باکس آفیس | BankMovie</title>
<style>
@font-face{font-family:BonVF;src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 85% 0,rgba(47,124,255,.17),transparent 32rem),#070911;color:#fff;font-family:BonVF,Tahoma,sans-serif}.wrap{width:min(1120px,calc(100% - 28px));margin:28px auto 70px}.top{display:flex;align-items:center;justify-content:space-between;gap:15px;flex-wrap:wrap;margin-bottom:20px}.top h1{margin:0;font-size:clamp(27px,4vw,42px)}.top p{margin:6px 0 0;color:#8f98aa;line-height:1.9}.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{min-height:42px;padding:0 15px;border:1px solid rgba(255,255,255,.1);border-radius:13px;background:#111827;color:#fff;text-decoration:none;cursor:pointer;font:inherit;font-weight:850}.btn.primary{background:linear-gradient(135deg,#2f7cff,#715cff);border-color:transparent}.btn.danger{background:rgba(244,63,94,.08);color:#fecdd3;border-color:rgba(244,63,94,.25)}.notice{padding:14px 16px;margin:0 0 18px;border-radius:15px;border:1px solid rgba(34,197,94,.25);background:rgba(34,197,94,.07);color:#c6f6d5;line-height:1.9}.notice.error{border-color:rgba(244,63,94,.27);background:rgba(244,63,94,.08);color:#fecdd3}.hero{border:1px solid rgba(255,255,255,.08);border-radius:25px;padding:22px;background:linear-gradient(145deg,rgba(17,24,39,.92),rgba(10,14,25,.95));box-shadow:0 25px 70px rgba(0,0,0,.28);margin-bottom:18px}.hero-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat{padding:17px;border-radius:17px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.065)}.stat small{display:block;color:#818aa0;font-size:10px;margin-bottom:6px}.stat strong{display:block;font-size:15px;word-break:break-word}.dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#ef4444;margin-left:6px}.dot.ok{background:#22c55e;box-shadow:0 0 12px rgba(34,197,94,.6)}.panel{border:1px solid rgba(255,255,255,.08);border-radius:23px;background:rgba(10,14,25,.9);overflow:hidden;margin-top:18px}.panel-head{padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.07);display:flex;align-items:center;justify-content:space-between;gap:10px}.panel-head h2{margin:0;font-size:18px}.panel-head span{font-size:10px;color:#7f8a9f}.form{padding:20px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.field{display:flex;flex-direction:column;gap:7px}.field.full{grid-column:1/-1}.field label{font-size:11px;font-weight:900;color:#d8deeb}.field small{font-size:9.5px;color:#7f8a9f;line-height:1.8}.input,.select{width:100%;min-height:46px;border:1px solid rgba(255,255,255,.1);border-radius:13px;background:#0b1020;color:#fff;padding:0 13px;outline:none;font:inherit}.toggle{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px;border:1px solid rgba(255,255,255,.07);border-radius:15px;background:rgba(255,255,255,.025)}.toggle-copy strong,.toggle-copy small{display:block}.toggle-copy strong{font-size:12px}.toggle-copy small{margin-top:4px}.toggle input{width:19px;height:19px;accent-color:#2f7cff}.savebar{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:18px;padding-top:18px;border-top:1px solid rgba(255,255,255,.06)}.savebar span{color:#7f8a9f;font-size:10px;line-height:1.7}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:650px}.table th,.table td{padding:13px 14px;border-bottom:1px solid rgba(255,255,255,.055);text-align:right;font-size:11px}.table th{color:#93b7ff;background:rgba(255,255,255,.02)}.muted{color:#7f8a9f}.security{margin-top:18px;padding:16px;border-radius:17px;border:1px solid rgba(47,124,255,.19);background:rgba(47,124,255,.06);color:#a8b9d7;font-size:10.5px;line-height:2}.provider{display:flex;align-items:center;gap:10px}.provider b{font-size:13px}.provider span{font-size:9px;padding:4px 7px;border-radius:7px;background:rgba(34,197,94,.1);color:#86efac}@media(max-width:760px){.hero-grid,.grid{grid-template-columns:1fr}.field.full{grid-column:auto}.savebar{align-items:stretch;flex-direction:column}.savebar .btn{width:100%}.wrap{width:min(100% - 18px,1120px);margin-top:16px}.hero{padding:14px;border-radius:19px}.panel{border-radius:19px}.form{padding:14px}.top .actions{width:100%}.top .actions .btn{flex:1;text-align:center;display:grid;place-items:center}.table{min-width:590px}}
</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<main class="wrap">
  <header class="top"><div><h1>مدیریت باکس آفیس</h1><p>دریافت خودکار جدول هفتگی با کش مشترک ۲۴ ساعته و نمایش اختصاصی BankMovie.</p></div><div class="actions"><a class="btn primary" href="/boxoffice" target="_blank">مشاهده باکس آفیس</a><a class="btn" href="/admin.php">پنل اصلی</a></div></header>
  <?php if ($status !== ''): ?><div class="notice <?= $statusType === 'error' ? 'error' : '' ?>"><?= bm_bo_admin_h($status) ?></div><?php endif; ?>

  <section class="hero"><div class="hero-grid bm-admin-kpis" style="margin:0">
    <div class="stat bm-admin-kpi"><small>وضعیت قابلیت</small><strong><span class="dot <?= !empty($settings['enabled']) ? 'ok' : '' ?>"></span><?= !empty($settings['enabled']) ? 'فعال' : 'غیرفعال' ?></strong></div>
    <div class="stat bm-admin-kpi"><small>کش</small><strong>۲۴ ساعت</strong></div>
    <div class="stat bm-admin-kpi"><small>آخرین دریافت موفق</small><strong><?= bm_bo_admin_time((int)($settings['last_fetch_at'] ?? 0)) ?></strong></div>
    <div class="stat bm-admin-kpi"><small>وضعیت اتصال</small><strong><?= bm_bo_admin_h((string)($settings['last_test_status'] ?? 'idle')) ?></strong></div>
  </div></section>

  <section class="panel">
    <div class="panel-head"><h2>تنظیمات نمایش</h2><span>دریافت خودکار • بدون کلید</span></div>
    <form class="form" method="post">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="action" value="save">
      <div class="grid">
        <div class="field full"><div class="toggle"><div class="toggle-copy"><strong>فعال بودن باکس آفیس</strong><small>با خاموش کردن، صفحه عمومی باکس آفیس غیرفعال می‌شود.</small></div><input type="checkbox" name="enabled" value="1" <?= !empty($settings['enabled']) ? 'checked' : '' ?>></div></div>
        <div class="field"><label>دریافت داده</label><div class="input provider"><b>خودکار</b><span>ACTIVE</span></div><small>داده‌ها سمت سرور دریافت می‌شوند و مرورگر کاربران مستقیماً به سرویس خارجی وصل نمی‌شود.</small></div>
        <div class="field"><label>مدت کش</label><div class="input provider"><b>۲۴ ساعت</b><span>FIXED</span></div><small>تمام کاربران از یک کش مشترک استفاده می‌کنند تا درخواست خارجی و فشار هاست حداقل بماند.</small></div>
        <div class="field"><label>تعداد ردیف‌های نمایشی</label><select class="select" name="items_limit"><?php foreach ([5,10,15,20,25] as $n): ?><option value="<?= $n ?>" <?= (int)$settings['items_limit']===$n?'selected':'' ?>><?= $n ?> فیلم</option><?php endforeach; ?></select><small>تعداد فیلم‌هایی که در صفحه عمومی نمایش داده می‌شوند.</small></div>
        <div class="field"><label>نوع جدول</label><div class="input provider"><b>Weekend Box Office</b><span>WEEKLY</span></div><small>رتبه، فروش آخر هفته، فروش کل و تعداد هفته‌های اکران.</small></div>
      </div>
      <div class="savebar"><span>با ذخیره تنظیمات، کش قبلی پاک می‌شود تا داده تازه ساخته شود.</span><button class="btn primary" type="submit">ذخیره تنظیمات</button></div>
    </form>
  </section>

  <section class="panel"><div class="panel-head"><h2>تست و کش</h2><span><?= bm_bo_admin_h((string)($settings['last_test_message'] ?? '')) ?></span></div><div class="form" style="display:flex;gap:10px;flex-wrap:wrap"><form method="post"><?= admin_csrf_input() ?><input type="hidden" name="action" value="test"><button class="btn primary" type="submit">تست دریافت</button></form><form method="post"><?= admin_csrf_input() ?><input type="hidden" name="action" value="clear_cache"><button class="btn danger" type="submit">پاک کردن کش</button></form></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>کش</th><th>دریافت</th><th>انقضا</th><th>آخرین خطا</th></tr></thead><tbody><?php if (!$cache): ?><tr><td colspan="4" class="muted">هنوز داده‌ای کش نشده است.</td></tr><?php else: ?><?php foreach ($cache as $row): ?><tr><td><?= bm_bo_admin_h((string)$row['cache_key']) ?></td><td><?= bm_bo_admin_time((int)$row['fetched_at']) ?></td><td><?= bm_bo_admin_time((int)$row['expires_at']) ?></td><td class="muted"><?= bm_bo_admin_h((string)$row['last_error']) ?></td></tr><?php endforeach; ?><?php endif; ?></tbody></table></div>
  </section>

  <div class="security">امنیت و فشار هاست: مقصد دریافت در کد سرور ثابت و Allowlist شده، Redirect غیرفعال است، TLS بررسی می‌شود، Cookie و Credential ارسال نمی‌شود و حجم پاسخ محدود است. کش مشترک ۲۴ ساعته و Lock دیتابیس نیز جلوی درخواست‌های همزمان و اضافه را می‌گیرد.</div>
</main>
</body>
</html>
