<?php
// auth.php - Animated registration and automatic login
require_once 'config.php';
require_once __DIR__ . '/includes/vip_sales.php';
bm_site_enforce_page('register_page_enabled');

$userTheme = $_COOKIE['user_theme'] ?? 'dark-green';
$userLang  = $_COOKIE['user_lang'] ?? 'fa';

$duckIdleWebp    = 'full/29-ezgif.com-gif-maker.webp';
$duckErrorWebp   = 'full/32-ezgif.com-gif-maker.webp';
$duckSuccessWebp = 'full/3-ezgif.com-gif-maker.webp';

$themes = [
    'dark-green'  => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض'],
    'dark-blue'   => ['primary' => '#3b82f6', 'name' => 'آبی مشکی'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی'],
    'dark-pink'   => ['primary' => '#ec4899', 'name' => 'صورتی مشکی'],
    'dark-red'    => ['primary' => '#ef4444', 'name' => 'قرمز مشکی'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی'],
    'dark-cyan'   => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی'],
    'dark-white'  => ['primary' => '#ffffff', 'name' => 'سفید مشکی'],
    'dark-black'  => ['primary' => '#888888', 'name' => 'دارک مطلق'],
];

$themeRgb = [
    '#2f7cff' => '47,124,255', '#36ff9f' => '54,255,159', '#3b82f6' => '59,130,246', '#8b5cf6' => '139,92,246',
    '#ec4899' => '236,72,153', '#ef4444' => '239,68,68', '#f97316' => '249,115,22',
    '#06b6d4' => '6,182,212', '#ffffff' => '255,255,255', '#888888' => '136,136,136',
];

$currentTheme = $themes[$userTheme] ?? $themes['dark-green'];
$accentRgb = $themeRgb[$currentTheme['primary']] ?? '47,124,255';
// ورود و ثبت‌نام همیشه به صفحه اصلی ختم می‌شوند.
$bmAuthReturn = '/';
$vipSalesSettings = function_exists('bm_vip_sales_settings') ? bm_vip_sales_settings() : [];
$supportTelegram = ltrim(trim((string)($vipSalesSettings['telegram_username'] ?? 'bankmovie_supp')), '@');
if (!preg_match('/^[A-Za-z0-9_]{5,32}$/', $supportTelegram)) $supportTelegram = 'bankmovie_supp';
$supportTelegramUrl = 'https://t.me/' . rawurlencode($supportTelegram);

if ($currentUser) {
    header('Location: /');
    exit;
}
$csrfToken = bm_user_csrf_token();

$loginError = $loginSuccess = $registerError = $registerSuccess = false;
$usernameValue = '';
$emailValue = '';

// پردازش لاگین
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_username'])) {
    bm_require_user_csrf(false, false);
    $username = trim($_POST['login_username'] ?? '');
    $password = $_POST['login_password'] ?? '';
    bm_security_enforce_rate_limit('web_login', 12, 900, bm_security_client_ip() . '|' . hash('sha256', strtolower($username)), false);

    if (empty($username) || empty($password)) {
        $loginError = $userLang === 'fa' ? 'لطفاً نام کاربری و رمز عبور را وارد کنید' : 'Please enter username and password';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            if ($user['status'] !== 'active') {
                $loginError = $userLang === 'fa' ? 'حساب کاربری شما فعال نیست' : 'Your account is not active';
            } else {
                if (password_needs_rehash((string)$user['password'], PASSWORD_DEFAULT)) {
                    try {
                        $rehash = $pdo->prepare('UPDATE users SET password = ? WHERE id = ?');
                        $rehash->execute([password_hash($password, PASSWORD_DEFAULT), (int)$user['id']]);
                    } catch (Throwable $ignored) {}
                }
                session_regenerate_id(true);
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', time() + 604800);
                bm_user_session_insert($pdo, (int)$user['id'], $token, $expires);
                setcookie('session_token', $token, bm_session_cookie_options(604800));
                $_SESSION['user_id'] = (int)$user['id'];
                bm_security_audit('web_login_success', ['user_id' => (int)$user['id']]);
                header('Location: /');
                exit;
            }
        } else {
            bm_security_audit('web_login_failed', ['identity_hash' => hash('sha256', strtolower($username))]);
            $loginError = $userLang === 'fa' ? 'نام کاربری یا رمز عبور اشتباه است' : 'Invalid username or password';
        }
    }
}

// پردازش ثبت‌نام و ورود خودکار
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reg_username'])) {
    bm_require_user_csrf(false, false);
    $username = trim((string)($_POST['reg_username'] ?? ''));
    $email = strtolower(trim((string)($_POST['reg_email'] ?? '')));
    $password = (string)($_POST['reg_password'] ?? '');
    $confirmPassword = (string)($_POST['reg_confirm_password'] ?? '');
    $captcha = isset($_POST['reg_captcha']);
    bm_security_enforce_rate_limit('web_register', 5, 3600, bm_security_client_ip(), false);

    if ($username === '' || $email === '' || $password === '') {
        $registerError = $userLang === 'fa' ? 'نام کاربری، ایمیل و رمز عبور را کامل وارد کنید' : 'Please enter username, email and password';
    } elseif (mb_strlen($username, 'UTF-8') < 3 || mb_strlen($username, 'UTF-8') > 40) {
        $registerError = $userLang === 'fa' ? 'نام کاربری باید بین ۳ تا ۴۰ کاراکتر باشد' : 'Username must be 3 to 40 characters';
    } elseif (!preg_match('/^[\p{L}\p{N}_.-]+$/u', $username)) {
        $registerError = $userLang === 'fa' ? 'نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه، خط تیره و زیرخط باشد' : 'Username contains invalid characters';
    } elseif (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registerError = $userLang === 'fa' ? 'یک ایمیل معتبر وارد کنید' : 'Please enter a valid email address';
    } elseif (strlen($password) < 8) {
        $registerError = $userLang === 'fa' ? 'رمز عبور باید حداقل ۸ کاراکتر باشد' : 'Password must be at least 8 characters';
    } elseif ($password !== $confirmPassword) {
        $registerError = $userLang === 'fa' ? 'رمز عبور و تکرار آن مطابقت ندارند' : 'Passwords do not match';
    } elseif (!$captcha) {
        $registerError = $userLang === 'fa' ? 'لطفاً تأیید کنید که ربات نیستید' : 'Please verify you are not a robot';
    } else {
        $stmt = $pdo->prepare('SELECT username,email FROM users WHERE username = ? OR email = ? LIMIT 1');
        $stmt->execute([$username, $email]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($existing) {
            $sameEmail = isset($existing['email']) && strcasecmp((string)$existing['email'], $email) === 0;
            $registerError = $sameEmail
                ? ($userLang === 'fa' ? 'این ایمیل قبلاً ثبت شده است' : 'Email is already registered')
                : ($userLang === 'fa' ? 'این نام کاربری قبلاً ثبت شده است' : 'Username already exists');
        } else {
            try {
                $pdo->beginTransaction();
                $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status, created_at) VALUES (?, ?, ?, 'user', 'active', NOW())");
                $stmt->execute([$username, $email, $hashedPassword]);
                $newUserId = (int)$pdo->lastInsertId();

                session_regenerate_id(true);
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', time() + 604800);
                bm_user_session_insert($pdo, $newUserId, $token, $expires);
                $pdo->commit();

                setcookie('session_token', $token, bm_session_cookie_options(604800));
                $_SESSION['user_id'] = $newUserId;
                bm_security_audit('web_register_success', ['user_id' => $newUserId]);
                bm_security_audit('web_login_success', ['user_id' => $newUserId, 'source' => 'auto_after_register']);
                header('Location: /');
                exit;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('BankMovie register error: ' . $e->getMessage());
                $registerError = $userLang === 'fa' ? 'خطا در ساخت حساب. دوباره تلاش کنید' : 'Registration failed. Please try again';
            }
        }
    }
    $usernameValue = $username;
    $emailValue = $email;
}

$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';
$bgImage = file_exists('uploads/poste.webp') ? 'uploads/poste.webp' : (file_exists('assets/img/poste.webp') ? 'assets/img/poste.webp' : '');
?>
<!DOCTYPE html>
<html lang="<?= $langAttr ?>" dir="<?= $dir ?>">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#05070c">
<meta name="robots" content="noindex,nofollow">
<title><?= $userLang === 'fa' ? 'ورود و ثبت نام' : 'Login & Register' ?> | BankMovie</title>
<link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
<link rel="preload" href="/assets/fonts/bonVF.woff2" as="font" type="font/woff2" crossorigin>
<style>
@font-face{font-family:BonVF;src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}
*{margin:0;padding:0;box-sizing:border-box}
:root{--accent:<?= htmlspecialchars($currentTheme['primary'],ENT_QUOTES,'UTF-8') ?>;--accent-rgb:<?= htmlspecialchars($accentRgb,ENT_QUOTES,'UTF-8') ?>;--panel:#10131c;--panel-deep:#080a10;--muted:#9aa1b2;--danger:#ff6677;--success:#58e0a5}
html{background:#05070c}
body{min-height:100svh;display:grid;place-items:center;padding:24px;color:#fff;font-family:BonVF,Tahoma,system-ui,sans-serif;background:#05070c;overflow-x:hidden}
.auth-bg{position:fixed;inset:0;background-image:linear-gradient(135deg,rgba(2,4,9,.46),rgba(2,4,9,.70)),url('<?= $bgImage !== '' ? '/'.ltrim(htmlspecialchars($bgImage,ENT_QUOTES,'UTF-8'),'/') : '' ?>');background-size:cover;background-position:center;z-index:0}
.auth-bg:after{content:"";position:absolute;inset:0;background:radial-gradient(circle at 12% 14%,rgba(var(--accent-rgb),.22),transparent 31%),radial-gradient(circle at 86% 86%,rgba(var(--accent-rgb),.12),transparent 34%);backdrop-filter:blur(.5px)}
.auth-shell{position:relative;z-index:2;width:min(900px,100%);min-height:610px;border:1px solid rgba(var(--accent-rgb),.58);border-radius:30px;background:linear-gradient(145deg,rgba(14,17,26,.96),rgba(6,8,13,.98));box-shadow:0 34px 120px rgba(0,0,0,.68),0 0 44px rgba(var(--accent-rgb),.22),inset 0 1px 0 rgba(255,255,255,.07);overflow:hidden;isolation:isolate}
.auth-shell:before{content:"";position:absolute;inset:1px;border:1px solid rgba(255,255,255,.045);border-radius:28px;pointer-events:none;z-index:20}
.auth-shell .curved-shape{position:absolute;right:-40px;top:-50px;height:690px;width:880px;background:linear-gradient(45deg,#151923,var(--accent));transform:rotate(10deg) skewY(40deg);transform-origin:bottom right;transition:1.25s cubic-bezier(.2,.75,.2,1);transition-delay:.75s;z-index:0;opacity:.95}
.auth-shell.active .curved-shape{transform:rotate(0) skewY(0);transition-delay:.18s}
.auth-shell .curved-shape2{position:absolute;left:250px;top:100%;height:720px;width:900px;background:#11151f;border-top:2px solid var(--accent);transform:rotate(0) skewY(0);transform-origin:bottom left;transition:1.25s cubic-bezier(.2,.75,.2,1);transition-delay:.16s;z-index:0}
.auth-shell.active .curved-shape2{transform:rotate(-11deg) skewY(-41deg);transition-delay:.64s}
.form-box,.info-content{position:absolute;top:0;width:50%;height:100%;display:flex;justify-content:center;flex-direction:column;z-index:4}
.form-box{padding:84px 48px 34px;text-align:right}.form-box.login{left:0}.form-box.register{right:0;padding-inline:50px}.form-box.register h1,.form-box.register .auth-subtitle{text-align:center}
.info-content{z-index:3;pointer-events:none}.info-content.login{right:0;text-align:right;padding:40px 44px 50px 150px}.info-content.register{left:0;text-align:right;padding:40px 150px 50px 44px}
.form-box h1{font-size:31px;text-align:center;margin-bottom:22px;font-weight:950;letter-spacing:-.04em}.form-box h1 span{color:var(--accent)}
.auth-subtitle{text-align:center;color:rgba(255,255,255,.52);font-size:10px;line-height:1.8;margin:-14px 0 8px}
.auth-form{width:100%}.input-box{position:relative;width:100%;height:52px;margin-top:22px}.input-box input{width:100%;height:100%;background:transparent;border:0;border-bottom:2px solid rgba(255,255,255,.62);outline:0;font-size:13px;color:#fff;font-weight:750;padding:10px 40px 0 34px;transition:.35s}.input-box input:focus,.input-box input:not(:placeholder-shown){border-bottom-color:var(--accent);box-shadow:0 10px 18px -18px rgba(var(--accent-rgb),.8)}
.input-box label{position:absolute;right:40px;top:50%;transform:translateY(-50%);font-size:11px;color:rgba(255,255,255,.62);transition:.3s;pointer-events:none}.input-box input:focus~label,.input-box input:not(:placeholder-shown)~label{top:2px;right:0;color:var(--accent);font-size:9px}
.field-icon{position:absolute;right:8px;top:55%;transform:translateY(-50%);width:20px;height:20px;color:rgba(255,255,255,.6);transition:.3s}.input-box input:focus~.field-icon{color:var(--accent)}
.password-toggle{position:absolute;left:4px;top:55%;transform:translateY(-50%);width:30px;height:30px;border:0;background:transparent;color:rgba(255,255,255,.46);cursor:pointer;display:grid;place-items:center}.password-toggle svg{width:17px;height:17px}
.auth-btn{position:relative;width:100%;height:47px;margin-top:22px;background:transparent;border-radius:999px;cursor:pointer;font-size:13px;font-weight:950;border:1px solid rgba(var(--accent-rgb),.75);color:#fff;overflow:hidden;z-index:1;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);transition:.28s}.auth-btn:before{content:"";position:absolute;height:320%;width:100%;background:linear-gradient(#11151f,var(--accent),#11151f,var(--accent));top:-110%;left:0;z-index:-1;transition:.48s}.auth-btn:hover:before,.auth-btn.is-loading:before{top:0}.auth-btn:hover{transform:translateY(-2px);box-shadow:0 13px 32px rgba(var(--accent-rgb),.23)}.auth-btn:disabled{opacity:.65;cursor:wait}
.switch-link{text-align:center;font-size:10px;line-height:1.9;color:rgba(255,255,255,.53);margin:17px 0 0}.switch-link button,.forgot-link{border:0;background:transparent;color:var(--accent);font:950 10px inherit;cursor:pointer;text-decoration:none}.switch-link button:hover,.forgot-link:hover{text-decoration:underline}.forgot-row{display:flex;justify-content:flex-start;margin:10px 2px -8px}
.info-content h2{font-size:clamp(28px,4vw,42px);line-height:1.2;font-weight:950;letter-spacing:-.045em;margin-bottom:12px}.info-content h2 em{font-style:normal;color:var(--accent)}.info-content p{font-size:11px;line-height:2;color:rgba(255,255,255,.7)}
.info-chip{display:inline-flex;width:max-content;align-items:center;gap:7px;margin-bottom:12px;padding:7px 11px;border:1px solid rgba(255,255,255,.1);border-radius:999px;background:rgba(4,6,10,.22);font-size:9px;font-weight:850}.info-chip i{width:7px;height:7px;border-radius:50%;background:var(--accent);box-shadow:0 0 13px var(--accent)}
.auth-alert{display:flex;gap:8px;align-items:flex-start;margin:10px 0 -4px;padding:10px 11px;border-radius:14px;font-size:9.5px;line-height:1.7;text-align:right}.auth-alert.error{color:#ffd4d8;background:rgba(255,75,96,.1);border:1px solid rgba(255,75,96,.18)}.auth-alert.success{color:#b7ffdc;background:rgba(60,218,144,.09);border:1px solid rgba(60,218,144,.17)}
.captcha-row{display:flex;align-items:center;gap:9px;margin-top:15px;color:rgba(255,255,255,.61);font-size:9.5px;cursor:pointer}.captcha-row input{width:18px;height:18px;accent-color:var(--accent)}
.forgot-modal{position:fixed;inset:0;z-index:90;display:grid;place-items:center;padding:18px;background:rgba(2,4,9,.78);backdrop-filter:blur(18px);opacity:0;visibility:hidden;transition:.25s}.forgot-modal.is-open{opacity:1;visibility:visible}.forgot-card{position:relative;width:min(450px,100%);padding:28px;border:1px solid rgba(var(--accent-rgb),.45);border-radius:26px;background:linear-gradient(145deg,rgba(18,22,32,.98),rgba(7,9,15,.99));box-shadow:0 30px 100px rgba(0,0,0,.7),0 0 38px rgba(var(--accent-rgb),.18);text-align:right}.forgot-card h2{margin:0 0 10px;font-size:22px}.forgot-card p{margin:0;color:rgba(255,255,255,.64);font-size:11px;line-height:2}.forgot-handle{display:flex;direction:ltr;align-items:center;justify-content:center;margin:18px 0;padding:12px;border:1px solid rgba(var(--accent-rgb),.28);border-radius:15px;background:rgba(var(--accent-rgb),.08);font-weight:950;color:#fff}.forgot-actions{display:grid;grid-template-columns:1fr 1fr;gap:10px}.forgot-actions a,.forgot-actions button{min-height:43px;border-radius:13px;border:1px solid rgba(255,255,255,.1);font:850 11px BonVF,Tahoma,sans-serif;cursor:pointer;display:flex;align-items:center;justify-content:center;text-decoration:none}.forgot-primary{background:var(--accent);color:#fff}.forgot-close{background:rgba(255,255,255,.05);color:rgba(255,255,255,.78)}.forgot-note{display:block;margin-top:13px;color:rgba(255,255,255,.4);font-size:9px;line-height:1.8}.auth-shell-footer{position:absolute;z-index:6;left:0;right:0;bottom:0;display:flex;justify-content:center;padding:0 24px 22px}.auth-home{display:inline-flex;align-items:center;justify-content:center;gap:7px;color:rgba(255,255,255,.66);font-size:10px;text-decoration:none;padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}.auth-home:hover{color:#fff;border-color:rgba(var(--accent-rgb),.35);background:rgba(var(--accent-rgb),.08)}
.form-box.login .animation,.info-content.login .animation{transform:translateX(0);opacity:1;filter:blur(0);transition:.65s ease;transition-delay:calc(.035s * var(--s))}.auth-shell.active .form-box.login .animation{transform:translateX(-120%);opacity:0;filter:blur(7px);transition-delay:calc(.025s * var(--d))}.auth-shell.active .info-content.login .animation{transform:translateX(120%);opacity:0;filter:blur(7px);transition-delay:calc(.025s * var(--d))}
.form-box.register .animation,.info-content.register .animation{opacity:0;filter:blur(8px);transition:.65s ease;transition-delay:calc(.03s * var(--s))}.form-box.register .animation{transform:translateX(120%)}.info-content.register .animation{transform:translateX(-120%)}.auth-shell.active .form-box.register .animation,.auth-shell.active .info-content.register .animation{transform:translateX(0);opacity:1;filter:blur(0);transition-delay:calc(.035s * var(--li))}
.form-box.register,.info-content.register{visibility:hidden;transition:visibility 0s .8s}.auth-shell.active .form-box.register,.auth-shell.active .info-content.register{visibility:visible;transition-delay:0s}.auth-shell.active .form-box.login,.auth-shell.active .info-content.login{visibility:hidden;transition:visibility 0s .8s}
/* Mobile auth v148.52: vertically centered forms + lightweight CSS-only entrance animation. */
@keyframes bmAuthItemIn{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
@media(max-width:760px){html,body{min-height:100%;height:auto}body{min-height:100svh;display:flex;align-items:center;justify-content:center;padding:max(18px,env(safe-area-inset-top)) 10px max(22px,env(safe-area-inset-bottom));overflow-x:hidden;overflow-y:auto}.auth-shell{width:min(470px,100%);height:auto;min-height:0;max-height:none;margin:auto;border-radius:26px;overflow:hidden;transition:none}.info-content{display:none!important}.form-box,.form-box.login,.form-box.register{position:relative;inset:auto;width:100%;height:auto;display:flex;flex-direction:column;justify-content:center;padding:30px 24px 26px;overflow:visible;text-align:right}.form-box.login{left:auto;min-height:520px}.form-box.register{right:auto;min-height:665px;display:none!important;visibility:hidden!important}.auth-shell.active .form-box.login{display:none!important;visibility:hidden!important}.auth-shell.active .form-box.register{display:flex!important;visibility:visible!important}.auth-form{margin:auto 0}.form-box .animation,.auth-shell.active .form-box .animation{filter:none!important;transition:none!important;transition-delay:0s!important;opacity:0;transform:translateY(14px);animation:bmAuthItemIn .44s cubic-bezier(.22,.75,.25,1) both}.form-box.login .animation{animation-delay:calc(.028s * var(--s))}.auth-shell.active .form-box.register .animation{animation-delay:calc(.026s * var(--li))}.auth-shell .curved-shape,.auth-shell.active .curved-shape{width:700px;height:760px;right:-430px;top:-245px;opacity:.17;transform:rotate(8deg) skewY(35deg);transition:none}.auth-shell .curved-shape2,.auth-shell.active .curved-shape2{left:-420px;top:78%;opacity:.20;transform:rotate(-7deg) skewY(-30deg);transition:none}.form-box h1{font-size:28px;margin-bottom:16px}.form-box.register h1,.form-box.register .auth-subtitle{text-align:center}.input-box{height:50px;margin-top:18px}.auth-btn{height:46px;margin-top:20px}.switch-link{margin-top:15px}.captcha-row{margin-top:13px}.auth-shell-footer{position:relative;inset:auto;padding:0 18px 16px}.forgot-modal{padding:max(18px,env(safe-area-inset-top)) 18px max(18px,env(safe-area-inset-bottom))}}
@media(max-width:380px){body{padding-inline:7px}.form-box,.form-box.login,.form-box.register{padding:26px 18px 22px}.form-box.login{min-height:500px}.form-box.register{min-height:635px}.form-box h1{font-size:26px}.input-box{height:49px;margin-top:17px}.input-box label{font-size:10.5px}.captcha-row{font-size:9px;line-height:1.75}.auth-shell-footer{padding:0 14px 13px}}
@media(prefers-reduced-motion:reduce){*,*:before,*:after{animation:none!important;transition-duration:.01ms!important}}

/* v148.61.9.9 — auth interaction/responsive hardening */
.switch-link{position:relative;z-index:30;pointer-events:auto}
.switch-link button{position:relative;z-index:31;pointer-events:auto;min-height:30px;padding:4px 6px;margin:-4px -2px;border-radius:8px}
.auth-shell-footer{pointer-events:none}
.auth-home{pointer-events:auto;position:relative;z-index:31;max-width:calc(100% - 20px);white-space:nowrap}
.form-box{z-index:8}
@media(min-width:761px){
  .auth-shell.active .curved-shape2{left:170px;width:1020px;top:99.2%;box-shadow:0 -7px 22px rgba(var(--accent-rgb),.18)}
  .auth-shell{min-height:640px}
  .form-box.register{padding:58px 50px 78px}
  .form-box.register .input-box{margin-top:16px;height:50px}
  .form-box.register .captcha-row{margin-top:11px}
  .form-box.register .auth-btn{margin-top:15px}
  .form-box.register .switch-link{margin-top:9px}
  .auth-shell-footer{bottom:0;padding:0 18px 12px}
  .auth-home{min-height:36px;padding:8px 13px}
}
@media(min-width:761px) and (max-height:760px){
  body{padding-block:12px}
  .auth-shell{min-height:580px}
  .form-box.register{padding:38px 46px 62px}
  .form-box.register .input-box{margin-top:12px;height:47px}
  .form-box.register .captcha-row{margin-top:8px}
  .form-box.register .auth-btn{height:43px;margin-top:10px}
  .form-box.register .switch-link{margin-top:6px}
  .auth-shell-footer{padding-bottom:8px}
}
@media(max-width:760px){
  body{align-items:flex-start;padding-top:max(14px,env(safe-area-inset-top));padding-bottom:max(18px,env(safe-area-inset-bottom))}
  .auth-shell{margin:auto 0;width:min(470px,100%)}
  .form-box,.form-box.login,.form-box.register{padding-left:clamp(18px,6vw,26px);padding-right:clamp(18px,6vw,26px)}
  .auth-shell-footer{width:100%;padding:0 14px 14px}
  .auth-home{max-width:100%;min-height:40px;padding:9px 12px;font-size:9.5px}
  .switch-link button{min-height:34px;padding:6px 7px}
}
@media(max-width:340px){
  .auth-home{font-size:9px;gap:5px;padding-inline:9px}
  .auth-home svg{width:12px;height:12px}
}

</style>
</head>
<?php
$isRegisterPage = basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) === 'register.php';
$showRegister = (bool)$registerError || ($isRegisterPage && !$registerSuccess);
?>
<body>
<div class="auth-bg" aria-hidden="true"></div>
<main class="auth-shell<?= $showRegister ? ' active' : '' ?>" id="authShell">
    <div class="curved-shape" aria-hidden="true"></div>
    <div class="curved-shape2" aria-hidden="true"></div>

    <section class="form-box login" aria-label="<?= $userLang === 'fa' ? 'ورود' : 'Login' ?>">
        <form method="POST" action="/login" class="auth-form" data-auth-form>
            <?= bm_user_csrf_field() ?>
            <input type="hidden" name="return" value="<?= htmlspecialchars($bmAuthReturn,ENT_QUOTES,'UTF-8') ?>">
            <h1 class="animation" style="--s:1;--d:5"><?= $userLang === 'fa' ? 'ورود به ' : 'Login to ' ?><span>BankMovie</span></h1>
            <p class="auth-subtitle animation" style="--s:2;--d:4"><?= $userLang === 'fa' ? 'برای ادامه تماشا و مدیریت حساب وارد شوید.' : 'Sign in to continue.' ?></p>
            <?php if($loginError): ?><div class="auth-alert error animation" style="--s:3;--d:3"><?= htmlspecialchars((string)$loginError) ?></div><?php endif; ?>
            <div class="input-box animation" style="--s:3;--d:3"><input type="text" name="login_username" autocomplete="username" placeholder=" " required><label><?= $userLang === 'fa' ? 'نام کاربری یا ایمیل' : 'Username or email' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></div>
            <div class="input-box animation" style="--s:4;--d:2"><input type="password" name="login_password" autocomplete="current-password" placeholder=" " required><label><?= $userLang === 'fa' ? 'رمز عبور' : 'Password' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><button type="button" class="password-toggle" aria-label="نمایش رمز" data-password-toggle><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg></button></div>
            <div class="forgot-row animation" style="--s:5;--d:1"><button type="button" class="forgot-link" data-open-forgot><?= $userLang === 'fa' ? 'رمز عبور را فراموش کرده‌ام' : 'Forgot password' ?></button></div>
            <button class="auth-btn animation" style="--s:5;--d:1" type="submit" data-auth-submit><?= $userLang === 'fa' ? 'ورود به حساب' : 'Login' ?></button>
            <p class="switch-link animation" style="--s:6;--d:0"><?= $userLang === 'fa' ? 'هنوز حساب نداری؟' : 'No account yet?' ?> <button type="button" data-show-register><?= $userLang === 'fa' ? 'ثبت‌نام رایگان' : 'Create account' ?></button></p>
        </form>
    </section>

    <section class="info-content login" aria-hidden="true"><span class="info-chip animation" style="--s:1;--d:4"><i></i><?= $userLang === 'fa' ? 'حساب شخصی بانک مووی' : 'BankMovie account' ?></span><h2 class="animation" style="--s:2;--d:3"><?= $userLang === 'fa' ? 'خوش اومدی؛<br><em>ادامه بده.</em>' : 'Welcome back;<br><em>keep watching.</em>' ?></h2><p class="animation" style="--s:3;--d:2"><?= $userLang === 'fa' ? 'نشانه‌ها، تنظیمات، دیدگاه‌ها و امکانات VIP شما بعد از ورود در دسترس هستند.' : 'Your watchlist, preferences and VIP features are waiting.' ?></p></section>

    <section class="form-box register" aria-label="<?= $userLang === 'fa' ? 'ثبت نام' : 'Register' ?>">
        <form method="POST" action="/register" class="auth-form" data-auth-form>
            <?= bm_user_csrf_field() ?>
            <input type="hidden" name="return" value="<?= htmlspecialchars($bmAuthReturn,ENT_QUOTES,'UTF-8') ?>">
            <h1 class="animation" style="--li:1;--s:6"><?= $userLang === 'fa' ? 'ساخت حساب ' : 'Create ' ?><span>BankMovie</span></h1>
            <p class="auth-subtitle animation" style="--li:2;--s:5"><?= $userLang === 'fa' ? 'چند ثانیه تا ساخت داشبورد سینمایی شما.' : 'Create your movie dashboard in seconds.' ?></p>
            <?php if($registerError): ?><div class="auth-alert error animation" style="--li:2;--s:5"><?= htmlspecialchars((string)$registerError) ?></div><?php endif; ?>
            <div class="input-box animation" style="--li:3;--s:4"><input type="text" name="reg_username" value="<?= htmlspecialchars((string)$usernameValue,ENT_QUOTES,'UTF-8') ?>" autocomplete="username" placeholder=" " required><label><?= $userLang === 'fa' ? 'نام کاربری' : 'Username' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></div>
            <div class="input-box animation" style="--li:4;--s:4"><input type="email" name="reg_email" value="<?= htmlspecialchars((string)$emailValue,ENT_QUOTES,'UTF-8') ?>" autocomplete="email" inputmode="email" dir="ltr" placeholder=" " required><label><?= $userLang === 'fa' ? 'ایمیل معتبر' : 'Email address' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="m4 7 8 6 8-6"/></svg></div>
            <div class="input-box animation" style="--li:5;--s:3"><input type="password" name="reg_password" autocomplete="new-password" placeholder=" " required><label><?= $userLang === 'fa' ? 'رمز عبور (حداقل ۸ کاراکتر)' : 'Password (8+ characters)' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="10" width="16" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><button type="button" class="password-toggle" aria-label="نمایش رمز" data-password-toggle><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></svg></button></div>
            <div class="input-box animation" style="--li:6;--s:2"><input type="password" name="reg_confirm_password" autocomplete="new-password" placeholder=" " required><label><?= $userLang === 'fa' ? 'تکرار رمز عبور' : 'Confirm password' ?></label><svg class="field-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="m5 12 4 4L19 6"/></svg></div>
            <label class="captcha-row animation" style="--li:7;--s:1"><input type="checkbox" name="reg_captcha" value="1" required><span><?= $userLang === 'fa' ? 'من ربات نیستم و قوانین سایت را می‌پذیرم.' : 'I am not a robot and accept the site rules.' ?></span></label>
            <button class="auth-btn animation" style="--li:8;--s:0" type="submit" data-auth-submit><?= $userLang === 'fa' ? 'ساخت حساب کاربری' : 'Register' ?></button>
            <p class="switch-link animation" style="--li:9;--s:0"><?= $userLang === 'fa' ? 'قبلاً ثبت‌نام کردی؟' : 'Already registered?' ?> <button type="button" data-show-login><?= $userLang === 'fa' ? 'ورود به حساب' : 'Sign in' ?></button></p>
        </form>
    </section>

    <section class="info-content register" aria-hidden="true"><span class="info-chip animation" style="--li:1;--s:4"><i></i><?= $userLang === 'fa' ? 'عضویت رایگان' : 'Free account' ?></span><h2 class="animation" style="--li:2;--s:3"><?= $userLang === 'fa' ? 'به جمع ما<br><em>خوش اومدی.</em>' : 'Welcome to<br><em>BankMovie.</em>' ?></h2><p class="animation" style="--li:3;--s:2"><?= $userLang === 'fa' ? 'حساب بساز، نشانه‌ها و تنظیمات خودت را نگه دار و هر زمان خواستی VIP را فعال کن.' : 'Save your watchlist and preferences, then activate VIP whenever you need it.' ?></p></section>
    <div class="auth-shell-footer"><a class="auth-home" href="/"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 12H5M12 19l-7-7 7-7"/></svg><?= $userLang === 'fa' ? 'بازگشت به بانک مووی' : 'Back to BankMovie' ?></a></div>
</main>
<div class="forgot-modal" id="forgotModal" role="dialog" aria-modal="true" aria-labelledby="forgotTitle">
  <div class="forgot-card">
    <h2 id="forgotTitle"><?= $userLang === 'fa' ? 'رمز عبورت را فراموش کردی؟' : 'Forgot your password?' ?></h2>
    <p><?= $userLang === 'fa' ? 'برای بازیابی حساب، نام کاربری و ایمیلی که موقع ثبت‌نام وارد کردی را برای پشتیبانی بفرست. پشتیبانی هیچ‌وقت رمز فعلی یا کد ورودت را درخواست نمی‌کند.' : 'Send your username and registration email to support. Support will never ask for your current password or login code.' ?></p>
    <div class="forgot-handle">@<?= htmlspecialchars($supportTelegram,ENT_QUOTES,'UTF-8') ?></div>
    <div class="forgot-actions">
      <a class="forgot-primary" href="<?= htmlspecialchars($supportTelegramUrl,ENT_QUOTES,'UTF-8') ?>" target="_blank" rel="noopener"><?= $userLang === 'fa' ? 'پیام در تلگرام' : 'Open Telegram' ?></a>
      <button class="forgot-close" type="button" data-close-forgot><?= $userLang === 'fa' ? 'بستن' : 'Close' ?></button>
    </div>
    <small class="forgot-note"><?= $userLang === 'fa' ? 'برای امنیت بیشتر، فقط از آیدی رسمی بالا استفاده کن.' : 'For your security, only contact the official username above.' ?></small>
  </div>
</div>
<script>
(function(){
 const shell=document.getElementById('authShell');

// v148.61.9.9 — delegated capture switch prevents footer/overlay from eating auth toggle taps.
document.addEventListener('click',function(event){
  var reg = event.target && event.target.closest ? event.target.closest('[data-show-register]') : null;
  var login = event.target && event.target.closest ? event.target.closest('[data-show-login]') : null;
  if(!reg && !login) return;
  event.preventDefault();
  event.stopPropagation();
  if(event.stopImmediatePropagation) event.stopImmediatePropagation();
  if(!shell) return;
  if(reg) shell.classList.add('active');
  if(login) shell.classList.remove('active');
  try{
    var next = reg ? '/register' : '/login';
    if(location.pathname !== next) history.replaceState(history.state,'',next + location.search + location.hash);
  }catch(_e){}
},true);

 document.querySelectorAll('[data-show-register]').forEach(b=>b.addEventListener('click',()=>shell.classList.add('active')));
 document.querySelectorAll('[data-show-login]').forEach(b=>b.addEventListener('click',()=>shell.classList.remove('active')));
 document.querySelectorAll('[data-password-toggle]').forEach(btn=>btn.addEventListener('click',()=>{const input=btn.parentElement.querySelector('input');if(!input)return;input.type=input.type==='password'?'text':'password';btn.classList.toggle('is-visible',input.type==='text')}));
 document.querySelectorAll('[data-auth-form]').forEach(form=>form.addEventListener('submit',()=>{const btn=form.querySelector('[data-auth-submit]');if(btn){btn.classList.add('is-loading');btn.disabled=true;btn.dataset.old=btn.textContent;btn.textContent='<?= $userLang === 'fa' ? 'در حال پردازش…' : 'Processing…' ?>'}}));
 const forgotModal=document.getElementById('forgotModal');
 const openForgot=()=>{if(!forgotModal)return;forgotModal.classList.add('is-open');document.body.style.overflow='hidden';};
 const closeForgot=()=>{if(!forgotModal)return;forgotModal.classList.remove('is-open');document.body.style.overflow='';};
 document.querySelectorAll('[data-open-forgot]').forEach(btn=>btn.addEventListener('click',openForgot));
 document.querySelectorAll('[data-close-forgot]').forEach(btn=>btn.addEventListener('click',closeForgot));
 forgotModal?.addEventListener('click',event=>{if(event.target===forgotModal)closeForgot()});
 document.addEventListener('keydown',event=>{if(event.key==='Escape')closeForgot()});
})();
</script>
</body>
</html>
