<?php
/**
 * BankMovie Manual Sitemap Generator v40
 * Admin-only manual builder for physical sitemap.xml + /sitemaps/*.xml files.
 * The public sitemap files are static after generation; Google does not trigger DB work.
 */
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

@set_time_limit(180);
@ini_set('memory_limit', '256M');

function bm_admin_sm_base(): string {
    // Search Console primary property: never generate legacy-domain URLs.
    return (function_exists('bm_seo_base_url') ? bm_seo_base_url() : rtrim(SITE_URL, '/')) . '/';
}

function bm_admin_sm_repair_existing_domains(): array {
    $files = [
        __DIR__ . '/sitemap.xml',
        __DIR__ . '/sitemap-source.xml',
        __DIR__ . '/_bankmovie_private/sitemap_source.xml',
    ];
    foreach (glob(__DIR__ . '/sitemaps/*.xml') ?: [] as $file) $files[] = $file;

    $checked = 0;
    $changed = 0;
    $failed = 0;
    foreach (array_unique($files) as $file) {
        if (!is_file($file) || filesize($file) < 20) continue;
        $checked++;
        $xml = @file_get_contents($file);
        if (!is_string($xml) || $xml === '') continue;
        $fixed = preg_replace(
            '~https?://(?:www\.)?(?:bankmoviee\.ir|bankmovie\.top)~i',
            rtrim(bm_admin_sm_base(), '/'),
            $xml
        ) ?? $xml;
        if ($fixed === $xml) continue;
        try {
            bm_admin_sm_write_atomic($file, $fixed);
            $changed++;
        } catch (Throwable $e) {
            $failed++;
        }
    }
    return ['checked' => $checked, 'changed' => $changed, 'failed' => $failed];
}
function bm_admin_sm_xml($v): string {
    return htmlspecialchars((string)$v, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}
function bm_admin_sm_rebase_local_url(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    $base = bm_admin_sm_base();
    if (str_starts_with($url, '/')) return $base . ltrim($url, '/');

    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return $url;
    $host = strtolower((string)$parts['host']);
    $host = preg_replace('/^www\./i', '', $host) ?: $host;
    if (!in_array($host, ['bankmovie.top', 'bankmoviee.ir'], true)) return $url;

    $path = (string)($parts['path'] ?? '/');
    $query = isset($parts['query']) ? '?' . $parts['query'] : '';
    $fragment = isset($parts['fragment']) ? '#' . $parts['fragment'] : '';
    return $base . ltrim($path, '/') . $query . $fragment;
}
function bm_admin_sm_date($v = null): string {
    $ts = $v ? strtotime((string)$v) : false;
    if (!$ts) $ts = time();
    return gmdate('Y-m-d', $ts);
}
function bm_admin_sm_table_exists(PDO $pdo, string $table): bool {
    try { $st = $pdo->prepare('SHOW TABLES LIKE ?'); $st->execute([$table]); return (bool)$st->fetchColumn(); }
    catch (Throwable $e) { return false; }
}
function bm_admin_sm_col_exists(PDO $pdo, string $table, string $column): bool {
    try { $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?"); $st->execute([$column]); return (bool)$st->fetchColumn(); }
    catch (Throwable $e) { return false; }
}
function bm_admin_sm_url_item(string $loc, ?string $lastmod = null, string $changefreq = 'weekly', string $priority = '0.8', ?string $image = null): string {
    $x = "  <url>\n";
    $x .= '    <loc>' . bm_admin_sm_xml($loc) . "</loc>\n";
    if ($lastmod) $x .= '    <lastmod>' . bm_admin_sm_xml(bm_admin_sm_date($lastmod)) . "</lastmod>\n";
    if ($changefreq !== '') $x .= '    <changefreq>' . bm_admin_sm_xml($changefreq) . "</changefreq>\n";
    if ($priority !== '') $x .= '    <priority>' . bm_admin_sm_xml($priority) . "</priority>\n";
    if ($image) {
        $x .= "    <image:image>\n";
        $x .= '      <image:loc>' . bm_admin_sm_xml($image) . "</image:loc>\n";
        $x .= "    </image:image>\n";
    }
    $x .= "  </url>\n";
    return $x;
}
function bm_admin_sm_write_atomic(string $path, string $contents): void {
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0755, true)) {
        throw new RuntimeException('امکان ساخت پوشه sitemap وجود ندارد: ' . $dir);
    }
    $tmp = $path . '.tmp-' . bin2hex(random_bytes(4));
    if (file_put_contents($tmp, $contents, LOCK_EX) === false) {
        throw new RuntimeException('امکان نوشتن فایل وجود ندارد: ' . basename($path));
    }
    @chmod($tmp, 0644);
    if (!@rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('امکان جایگزینی فایل وجود ندارد: ' . basename($path));
    }
    @chmod($path, 0644);
}
function bm_admin_sm_urlset_start(bool $image = false): string {
    return '<?xml version="1.0" encoding="UTF-8"?>' . "\n" .
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . ($image ? ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"' : '') . '>' . "\n";
}
function bm_admin_sm_urlset_end(): string { return "</urlset>\n"; }
function bm_admin_sm_is_series(array $row): bool {
    $t = strtolower(trim((string)($row['type'] ?? $row['category'] ?? $row['kind'] ?? '')));
    return $t !== '' && (str_contains($t, 'series') || str_contains($t, 'mini') || str_contains($t, 'tv') || str_contains($t, 'show') || str_contains($t, 'serial') || str_contains($t, 'serie'));
}
function bm_admin_sm_collect_from_db(PDO $pdo): array {
    $out = ['movies' => [], 'series' => [], 'source' => 'db'];
    if (!bm_admin_sm_table_exists($pdo, 'movies')) return $out;

    $want = ['id','movie_id','title','title_en','movie_title_en','movie_title','title_fa','imdb_code','type','category','kind','updated_at','created_at'];
    $cols = [];
    foreach ($want as $c) if (bm_admin_sm_col_exists($pdo, 'movies', $c)) $cols[] = '`' . $c . '`';
    if (!$cols) return $out;
    if (!in_array('`id`', $cols, true) && bm_admin_sm_col_exists($pdo, 'movies', 'id')) $cols[] = '`id`';
    $select = implode(',', array_unique($cols));
    $order = bm_admin_sm_col_exists($pdo, 'movies', 'id') ? ' ORDER BY id DESC' : '';
    try {
        $st = $pdo->query("SELECT $select FROM movies WHERE 1=1 $order LIMIT 60000");
        $base = bm_admin_sm_base();
        while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
            $id = 0;
            foreach (['id','movie_id'] as $k) if (isset($row[$k]) && is_numeric($row[$k])) { $id = (int)$row[$k]; break; }
            if ($id <= 0) continue;
            $loc = $base . ltrim(bm_movie_url($row), '/');
            $lastmod = $row['updated_at'] ?? $row['created_at'] ?? null;
            $image = null;
            $imdb = trim((string)($row['imdb_code'] ?? ''));
            if ($imdb !== '') {
                $posterPath = __DIR__ . '/posters/' . basename($imdb) . '.webp';
                if (is_file($posterPath)) $image = $base . 'posters/' . rawurlencode($imdb) . '.webp';
            }
            $item = ['loc' => $loc, 'lastmod' => $lastmod, 'image' => $image];
            if (bm_admin_sm_is_series($row)) $out['series'][] = $item; else $out['movies'][] = $item;
        }
    } catch (Throwable $e) {
        $out['error'] = $e->getMessage();
    }
    return $out;
}
function bm_admin_sm_parse_source_file(string $file): array {
    $entries = [];
    if (!is_file($file) || filesize($file) < 100) return $entries;
    $xml = @file_get_contents($file);
    if (!is_string($xml) || $xml === '') return $entries;
    if (!preg_match_all('~<url\b[^>]*>(.*?)</url>~is', $xml, $blocks)) return $entries;
    foreach ($blocks[1] as $block) {
        if (!preg_match('~<loc>(.*?)</loc>~is', $block, $m)) continue;
        $loc = html_entity_decode(trim(strip_tags($m[1])), ENT_QUOTES | ENT_XML1, 'UTF-8');
        $loc = bm_admin_sm_rebase_local_url($loc);
        if ($loc === '') continue;
        if (strpos($loc, '/movie/') === false) continue;
        $lastmod = null; $image = null;
        if (preg_match('~<lastmod>(.*?)</lastmod>~is', $block, $lm)) $lastmod = trim(strip_tags($lm[1]));
        if (preg_match('~<image:loc>(.*?)</image:loc>~is', $block, $im)) {
            $image = html_entity_decode(trim(strip_tags($im[1])), ENT_QUOTES | ENT_XML1, 'UTF-8');
            $image = bm_admin_sm_rebase_local_url($image);
        }
        $entries[] = ['loc' => $loc, 'lastmod' => $lastmod, 'image' => $image];
    }
    return $entries;
}
function bm_admin_sm_legacy_entries(): array {
    $sources = [
        __DIR__ . '/_bankmovie_private/sitemap_source.xml',
        __DIR__ . '/sitemap-source.xml',
        __DIR__ . '/sitemap.xml',
    ];
    foreach ($sources as $file) {
        $entries = bm_admin_sm_parse_source_file($file);
        if (count($entries) > 0) return $entries;
    }
    return [];
}
function bm_admin_sm_write_urlset_file(string $filename, array $entries, string $priority = '0.85'): int {
    $content = bm_admin_sm_urlset_start(true);
    $printed = 0;
    foreach ($entries as $entry) {
        $loc = trim((string)($entry['loc'] ?? ''));
        if ($loc === '') continue;
        $content .= bm_admin_sm_url_item($loc, $entry['lastmod'] ?? null, 'weekly', $priority, $entry['image'] ?? null);
        $printed++;
    }
    $content .= "  <!-- BankMovie manual sitemap v40; file=" . bm_admin_sm_xml(basename($filename)) . "; urls=" . (int)$printed . " -->\n";
    $content .= bm_admin_sm_urlset_end();
    bm_admin_sm_write_atomic($filename, $content);
    return $printed;
}
function bm_admin_sm_generate_catalog(int $moviePages, int $seriesPages): int {
    $base = bm_admin_sm_base();
    $content = bm_admin_sm_urlset_start(false);
    $printed = 0;
    for ($i = 1; $i <= max(1, $moviePages); $i++) { $content .= bm_admin_sm_url_item($base . 'catalog?type=movie&page=' . $i, null, 'daily', $i === 1 ? '0.8' : '0.55'); $printed++; }
    for ($i = 1; $i <= max(1, $seriesPages); $i++) { $content .= bm_admin_sm_url_item($base . 'catalog?type=series&page=' . $i, null, 'daily', $i === 1 ? '0.8' : '0.55'); $printed++; }
    $content .= bm_admin_sm_urlset_end();
    bm_admin_sm_write_atomic(__DIR__ . '/sitemaps/catalog.xml', $content);
    return $printed;
}
function bm_admin_sm_generate_static(): int {
    $base = bm_admin_sm_base();
    $urls = [
        [$base, 'daily', '1.0'],
        [$base . 'collections', 'weekly', '0.8'],
        [$base . 'catalog?type=movie&page=1', 'daily', '0.8'],
        [$base . 'catalog?type=series&page=1', 'daily', '0.8'],
        [$base . 'top_rated_by_users', 'weekly', '0.6'],
        [$base . 'map', 'weekly', '0.6'],
    ];
    $content = bm_admin_sm_urlset_start(false);
    foreach ($urls as $u) $content .= bm_admin_sm_url_item($u[0], null, $u[1], $u[2]);
    $content .= bm_admin_sm_urlset_end();
    bm_admin_sm_write_atomic(__DIR__ . '/sitemaps/static.xml', $content);
    return count($urls);
}
function bm_admin_sm_generate_collections(PDO $pdo): int {
    $base = bm_admin_sm_base();
    $content = bm_admin_sm_urlset_start(false);
    $printed = 0;
    if (bm_admin_sm_table_exists($pdo, 'collections')) {
        $slugCol = bm_admin_sm_col_exists($pdo, 'collections', 'slug') ? 'slug' : null;
        if ($slugCol) {
            $dateCol = bm_admin_sm_col_exists($pdo, 'collections', 'updated_at') ? 'updated_at' : (bm_admin_sm_col_exists($pdo, 'collections', 'created_at') ? 'created_at' : null);
            $select = 'id, slug' . ($dateCol ? ', ' . $dateCol : '');
            try {
                $st = $pdo->query("SELECT $select FROM collections ORDER BY id DESC LIMIT 10000");
                while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                    $slug = trim((string)($row['slug'] ?? ''));
                    if ($slug === '') continue;
                    $content .= bm_admin_sm_url_item($base . 'collection/' . rawurlencode($slug), $dateCol ? ($row[$dateCol] ?? null) : null, 'weekly', '0.65');
                    $printed++;
                }
            } catch (Throwable $e) {}
        }
    }
    $content .= bm_admin_sm_urlset_end();
    bm_admin_sm_write_atomic(__DIR__ . '/sitemaps/collections.xml', $content);
    return $printed;
}
function bm_admin_sm_generate_recent(array $movies, array $series, int $limit = 1000): int {
    $items = array_merge($movies, $series);
    usort($items, static function(array $a, array $b): int {
        return (strtotime((string)($b['lastmod'] ?? '')) ?: 0) <=> (strtotime((string)($a['lastmod'] ?? '')) ?: 0);
    });
    $items = array_slice($items, 0, max(1, $limit));
    return bm_admin_sm_write_urlset_file(__DIR__ . '/sitemaps/recent.xml', $items, '0.87');
}
function bm_admin_sm_clean_old_children(): void {
    $dir = __DIR__ . '/sitemaps';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    foreach (glob($dir . '/*.xml') ?: [] as $file) {
        @unlink($file);
    }
}
function bm_admin_sm_build_all(PDO $pdo, int $per = 2000): array {
    $base = bm_admin_sm_base();
    $domainRepairBefore = bm_admin_sm_repair_existing_domains();
    $lock = __DIR__ . '/_bankmovie_private/sitemap_generate.lock';
    if (is_file($lock) && time() - (int)@filemtime($lock) < 60) {
        throw new RuntimeException('برای جلوگیری از اسپم، تولید sitemap فقط هر ۶۰ ثانیه یک‌بار مجاز است.');
    }
    @file_put_contents($lock, (string)time(), LOCK_EX);

    // Before overwriting root sitemap.xml, preserve the old manual source if it is a urlset.
    $root = __DIR__ . '/sitemap.xml';
    $source = __DIR__ . '/_bankmovie_private/sitemap_source.xml';
    if (is_file($root)) {
        $head = (string)@file_get_contents($root, false, null, 0, 500);
        if (stripos($head, '<urlset') !== false && stripos($head, '<sitemapindex') === false) {
            @copy($root, $source);
        }
    }

    bm_admin_sm_clean_old_children();

    $db = bm_admin_sm_collect_from_db($pdo);
    $sourceMode = 'db';
    $movies = $db['movies'] ?? [];
    $series = $db['series'] ?? [];
    $dbTotal = count($movies) + count($series);

    if ($dbTotal < 100) {
        // Host DB/count quirks: use the old full sitemap source, same as the old manual method.
        $legacy = bm_admin_sm_legacy_entries();
        if (count($legacy) > 0) {
            $movies = $legacy;
            $series = [];
            $sourceMode = 'legacy-sitemap';
        }
    }

    $files = [];
    $staticCount = bm_admin_sm_generate_static();
    $files[] = ['loc' => $base . 'sitemaps/static.xml', 'count' => $staticCount];

    $moviePages = max(1, (int)ceil(count($movies) / max(1, $per)));
    $seriesPages = max(0, (int)ceil(count($series) / max(1, $per)));
    $catalogCount = bm_admin_sm_generate_catalog($moviePages, max(1, $seriesPages));
    $files[] = ['loc' => $base . 'sitemaps/catalog.xml', 'count' => $catalogCount];

    $collectionsCount = bm_admin_sm_generate_collections($pdo);
    $files[] = ['loc' => $base . 'sitemaps/collections.xml', 'count' => $collectionsCount];

    $recentCount = bm_admin_sm_generate_recent($movies, $series, 1000);
    array_unshift($files, ['loc' => $base . 'sitemaps/recent.xml', 'count' => $recentCount]);

    for ($i = 1; $i <= $moviePages; $i++) {
        $chunk = array_slice($movies, ($i - 1) * $per, $per);
        if (!$chunk) continue;
        $count = bm_admin_sm_write_urlset_file(__DIR__ . '/sitemaps/movies-' . $i . '.xml', $chunk, '0.85');
        if ($count > 0) $files[] = ['loc' => $base . 'sitemaps/movies-' . $i . '.xml', 'count' => $count];
    }
    for ($i = 1; $i <= $seriesPages; $i++) {
        $chunk = array_slice($series, ($i - 1) * $per, $per);
        if (!$chunk) continue;
        $count = bm_admin_sm_write_urlset_file(__DIR__ . '/sitemaps/series-' . $i . '.xml', $chunk, '0.8');
        if ($count > 0) $files[] = ['loc' => $base . 'sitemaps/series-' . $i . '.xml', 'count' => $count];
    }

    $now = bm_admin_sm_date();
    $index = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    $index .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
    $index .= '  <!-- BankMovie manual sitemap v40; source=' . bm_admin_sm_xml($sourceMode) . '; movies=' . count($movies) . '; series=' . count($series) . '; generated=' . bm_admin_sm_xml(date('c')) . ' -->' . "\n";
    foreach ($files as $file) {
        if (($file['count'] ?? 0) <= 0 && !str_contains($file['loc'], 'collections.xml')) continue;
        $index .= "  <sitemap>\n";
        $index .= '    <loc>' . bm_admin_sm_xml($file['loc']) . "</loc>\n";
        $index .= '    <lastmod>' . bm_admin_sm_xml($now) . "</lastmod>\n";
        $index .= "  </sitemap>\n";
    }
    $index .= "</sitemapindex>\n";
    bm_admin_sm_write_atomic($root, $index);
    $domainRepairAfter = bm_admin_sm_repair_existing_domains();

    @unlink($lock);
    return [
        'source' => $sourceMode,
        'movies' => count($movies),
        'series' => count($series),
        'movie_pages' => $moviePages,
        'series_pages' => $seriesPages,
        'files' => $files,
        'total_urls' => array_sum(array_map(static fn($f) => (int)($f['count'] ?? 0), $files)),
        'domain_repair_before' => $domainRepairBefore,
        'domain_repair_after' => $domainRepairAfter,
    ];
}

$initialDomainRepair = bm_admin_sm_repair_existing_domains();

$result = null;
$error = null;
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    try { $result = bm_admin_sm_build_all($pdo, 2000); }
    catch (Throwable $e) { $error = $e->getMessage(); }
}

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>ساخت دستی Sitemap | BankMovie</title>
<style>
body{margin:0;background:#080a10;color:#fff;font-family:Tahoma,Arial,sans-serif;line-height:1.8}.wrap{max-width:980px;margin:40px auto;padding:20px}.card{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.1);border-radius:22px;padding:22px;box-shadow:0 20px 60px rgba(0,0,0,.35)}h1{margin:0 0 10px;font-size:24px}.muted{color:rgba(255,255,255,.68)}.btn{border:0;border-radius:14px;background:#2f7cff;color:#fff;padding:13px 22px;font-weight:900;cursor:pointer}.btn:hover{filter:brightness(1.08)}.ok{background:rgba(0,200,120,.14);border:1px solid rgba(0,200,120,.35);padding:14px;border-radius:16px;margin:16px 0}.err{background:rgba(255,70,90,.14);border:1px solid rgba(255,70,90,.35);padding:14px;border-radius:16px;margin:16px 0}code{direction:ltr;display:inline-block;background:rgba(0,0,0,.35);padding:2px 8px;border-radius:8px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin:15px 0}.stat{background:rgba(0,0,0,.25);border-radius:15px;padding:13px}.stat b{display:block;font-size:20px}table{width:100%;border-collapse:collapse;margin-top:14px}td,th{border-bottom:1px solid rgba(255,255,255,.08);padding:8px;text-align:right}a{color:#84b6ff}</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<div class="wrap">
  <div class="card">
    <h1>ساخت دستی Sitemap</h1>
    <p class="muted">این صفحه فقط برای ادمین باز می‌شود. با کلیک روی دکمه، فایل‌های فیزیکی <code>sitemap.xml</code> و <code>/sitemaps/*.xml</code> ساخته می‌شوند؛ بنابراین گوگل دیگر هر بار دیتابیس را درگیر نمی‌کند.</p>
    <?php if ($error): ?><div class="err">خطا: <?= h($error) ?></div><?php endif; ?>
    <?php if ($result): ?>
      <div class="ok">Sitemap با موفقیت ساخته شد.</div>
      <div class="grid">
        <div class="stat"><span>منبع</span><b><?= h($result['source']) ?></b></div>
        <div class="stat"><span>فیلم/آیتم‌ها</span><b><?= (int)$result['movies'] ?></b></div>
        <div class="stat"><span>سریال</span><b><?= (int)$result['series'] ?></b></div>
        <div class="stat"><span>فایل‌های ثبت‌شده</span><b><?= count($result['files']) ?></b></div>
      </div>
      <p>تست کن: <a href="/sitemap.xml?manual=v38" target="_blank">/sitemap.xml</a></p>
      <table><thead><tr><th>فایل</th><th>تعداد URL</th></tr></thead><tbody>
      <?php foreach ($result['files'] as $f): ?><tr><td><a target="_blank" href="<?= h(parse_url((string)$f['loc'], PHP_URL_PATH) ?: '#') ?>"><?= h($f['loc']) ?></a></td><td><?= (int)$f['count'] ?></td></tr><?php endforeach; ?>
      </tbody></table>
    <?php endif; ?>
    <form method="post" onsubmit="return confirm('ساخت sitemap ممکن است چند ثانیه طول بکشد. ادامه می‌دهی؟')">
      <?= admin_csrf_input() ?>
      <button class="btn" type="submit">ساخت / بازسازی دستی Sitemap</button>
    </form>
    <p class="muted">تنها سایت‌مپ اصلی را در Search Console ثبت کن:<br><code><?= h(rtrim(bm_admin_sm_base(), '/') . '/sitemap.xml') ?></code><br>دامنه قدیمی دیگر داخل هیچ فایل سایت‌مپ تولید نمی‌شود.</p>
  </div>
</div>
</body>
</html>
