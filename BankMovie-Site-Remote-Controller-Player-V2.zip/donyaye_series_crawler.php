<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/donyaye_series_crawler_lib.php';
require_admin();
$csrf = admin_csrf_token();

function bm_ds_ajax_out(array $payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_ds_state_payload(PDO $pdo, string $scope = ''): array {
    $state = bm_ds_load_state();
    if ($scope === '') $scope = (string)($state['scope'] ?? 'all');
    $scope = in_array($scope, ['all','missing_links'], true) ? $scope : 'all';
    $total = 0;
    try { $total = bm_ds_count_local_series($pdo, $scope); } catch (Throwable $e) {}
    $json = bm_ds_load_existing_json();
    $items = bm_ds_compact_items_array($json);
    $matchedCount = count(array_filter($items, fn($r) => !empty($r['links'])));
    $processed = (int)($state['processed'] ?? 0);
    $offset = (int)($state['offset'] ?? 0);
    $liveOffset = max($offset, (int)($state['live_offset'] ?? 0));
    $liveProcessed = max($processed, (int)($state['live_processed'] ?? 0), $liveOffset);
    return [
        'success' => true,
        'state' => $state,
        'scope' => $scope,
        'total' => $total,
        'offset' => $liveOffset,
        'committed_offset' => $offset,
        'processed' => $liveProcessed,
        'remaining' => max(0, $total - $liveOffset),
        'json_items' => count($items),
        'json_matched' => $matchedCount,
        'generated_at' => $json['generated_at'] ?? null,
        'batch_size' => BM_DS_BATCH_SIZE,
        'save_every' => defined('BM_DS_SAVE_EVERY') ? BM_DS_SAVE_EVERY : 5,
        'connection_label' => 'اتصال مستقیم سرور BankMovie',
        'fetch_mode' => bm_ds_fetch_mode_label(),
        'storage' => bm_ds_storage_status(),
    ];
}

function bm_ds_run_batch(PDO $pdo, bool $manual = false): array {
    @set_time_limit(180);
    $state = bm_ds_load_state();
    $scope = (string)($state['scope'] ?? 'all');
    $scope = in_array($scope, ['all','missing_links'], true) ? $scope : 'all';
    $total = bm_ds_count_local_series($pdo, $scope);
    $offset = max(0, (int)($state['offset'] ?? 0));

    if (!$manual && empty($state['active'])) {
        return array_merge(bm_ds_state_payload($pdo, $scope), ['message' => 'کرال فعال نیست.']);
    }
    if ($offset >= $total) {
        bm_ds_save_json([], ['finished_at' => date('c'), 'scope' => $scope]);
        $state['active'] = false;
        $state['done'] = true;
        $state['total'] = $total;
        $state['live_offset'] = $total;
        $state['live_processed'] = $total;
        $state['current_status'] = 'کامل شد';
        $state['current_item'] = '';
        $state['last_error'] = '';
        bm_ds_save_state($state);
        return array_merge(bm_ds_state_payload($pdo, $scope), ['done' => true, 'message' => 'همه سریال‌ها بررسی شده‌اند.']);
    }

    if (function_exists('session_write_close')) { @session_write_close(); }

    $rows = bm_ds_fetch_local_series($pdo, BM_DS_BATCH_SIZE, $offset, $scope);
    $batchTotal = count($rows);
    // Create/update the JSON file at the very start so the user immediately sees storage working.
    bm_ds_save_json([], ['batch_started_at' => date('c'), 'batch_size' => BM_DS_BATCH_SIZE, 'offset' => $offset, 'scope' => $scope, 'mode' => 'direct_timeout_safe_short_batch']);

    $state['active'] = true;
    $state['done'] = false;
    $state['scope'] = $scope;
    $state['total'] = $total;
    $state['batch_offset_start'] = $offset;
    $state['batch_total'] = $batchTotal;
    $state['batch_done'] = 0;
    $state['batch_started_at'] = date('c');
    $state['batch_finished_at'] = null;
    $state['live_offset'] = $offset;
    $state['live_processed'] = max((int)($state['processed'] ?? 0), $offset);
    $state['live_matched'] = (int)($state['matched'] ?? 0);
    $state['current_status'] = 'بسته کوتاه شروع شد؛ هر آیتم همان لحظه ذخیره می‌شود';
    $state['current_item'] = '';
    $state['current_imdb'] = '';
    $state['current_title'] = '';
    $state['last_batch_items'] = [];
    $state['storage_error'] = '';
    bm_ds_save_state($state);

    $errors = [];
    $checked = 0;
    $matched = 0;
    $recent = [];
    $pendingResults = [];
    $saveEvery = defined('BM_DS_SAVE_EVERY') ? max(1, (int)BM_DS_SAVE_EVERY) : 1;
    $initialMatched = (int)($state['matched'] ?? 0);
    $initialProcessed = (int)($state['processed'] ?? 0);

    foreach ($rows as $idx => $row) {
        $itemTitle = (string)($row['title'] ?? '');
        $itemImdb = (string)($row['imdb_code'] ?? '');
        $state['current_status'] = 'در حال بررسی مورد ' . ($idx + 1) . ' از ' . $batchTotal;
        $state['current_item'] = '#' . (int)($row['id'] ?? 0) . ' — ' . $itemTitle;
        $state['current_imdb'] = $itemImdb;
        $state['current_title'] = $itemTitle;
        $state['batch_done'] = $idx;
        $state['live_offset'] = $offset + $idx;
        $state['live_processed'] = $offset + $idx;
        bm_ds_save_state($state);

        $itemResult = null;
        try {
            $itemResult = bm_ds_match_movie($row);
            $isMatched = !empty($itemResult['matched']);
            if ($isMatched) $matched++;
            $dbLinks = (int)($itemResult['db_preview']['counts']['total'] ?? 0);
            $state['current_status'] = ($isMatched ? 'پیدا شد' : 'پیدا نشد') . ' — ذخیره در JSON... لینک ذخیره‌ای: ' . $dbLinks;
        } catch (Throwable $e) {
            $errors[] = [
                'id' => (int)($row['id'] ?? 0),
                'imdb_code' => $itemImdb,
                'title' => $itemTitle,
                'error' => $e->getMessage(),
                'checked_at' => date('c'),
            ];
            $itemResult = bm_ds_error_result_for_movie($row, $e->getMessage());
            $dbLinks = 0;
            $state['current_status'] = 'خطا در کرال، اما نتیجه خطا داخل JSON ذخیره می‌شود: ' . $e->getMessage();
        }

        // TIMEOUT-SAFE MODE: write every item so nothing is lost.
        $pendingResults[] = $itemResult;
        $checked++;
        $shouldFlush = (count($pendingResults) >= $saveEvery) || ($idx + 1 >= $batchTotal);
        if ($shouldFlush) {
            bm_ds_save_json($pendingResults, [
                'saved_frequently' => true,
                'save_every' => $saveEvery,
                'batch_size' => BM_DS_BATCH_SIZE,
                'offset' => $offset,
                'scope' => $scope,
                'last_saved_imdb' => $itemImdb,
                'last_saved_at' => date('c'),
            ]);
            $pendingResults = [];
            $state['last_saved_at'] = date('c');
        }

        $isMatched = !empty($itemResult['matched']);
        $dbLinks = (int)($itemResult['db_preview']['counts']['total'] ?? 0);
        array_unshift($recent, [
            'id' => (int)($row['id'] ?? 0),
            'imdb_code' => $itemImdb,
            'title' => $itemTitle,
            'matched' => $isMatched,
            'db_links' => $dbLinks,
            'checked_at' => date('c'),
        ]);
        $recent = array_slice($recent, 0, 10);

        $state['batch_done'] = $idx + 1;
        $state['live_offset'] = $offset + $idx + 1;
        $state['live_processed'] = $offset + $idx + 1;
        $state['live_matched'] = $initialMatched + $matched;
        // Commit progress after every item. If hosting kills the request, the next click/auto-run resumes from here.
        $state['offset'] = $offset + $idx + 1;
        $state['processed'] = max($initialProcessed + $checked, $offset + $idx + 1);
        $state['matched'] = $initialMatched + $matched;
        $state['last_batch_items'] = $recent;
        $state['last_error'] = $errors ? ('خطا در ' . count($errors) . ' مورد') : '';
        $state['current_status'] = 'ذخیره شد و offset جلو رفت — ' . ($isMatched ? 'Match' : 'No match') . ' — Links: ' . $dbLinks;
        bm_ds_save_state($state);
    }

    $newOffset = $offset + $checked;
    $done = ($checked === 0 || $newOffset >= $total);
    $state['active'] = $done ? false : true;
    $state['done'] = $done;
    $state['scope'] = $scope;
    $state['offset'] = $newOffset;
    $state['live_offset'] = $newOffset;
    $state['processed'] = max($initialProcessed + $checked, $newOffset, (int)($state['processed'] ?? 0));
    $state['live_processed'] = max((int)$state['processed'], $newOffset);
    $state['matched'] = max($initialMatched + $matched, (int)($state['matched'] ?? 0));
    $state['live_matched'] = (int)$state['matched'];
    $state['total'] = $total;
    $state['last_error'] = $errors ? ('خطا در ' . count($errors) . ' مورد') : '';
    $state['current_status'] = $done ? 'کرال کامل شد' : 'نوبت تمام شد؛ نوبت بعدی بلافاصله اجرا می‌شود';
    $state['current_item'] = '';
    $state['current_imdb'] = '';
    $state['current_title'] = '';
    $state['batch_finished_at'] = date('c');
    $state['last_batch'] = [
        'offset_start' => $offset,
        'checked' => $checked,
        'matched' => $matched,
        'errors' => $errors,
        'finished_at' => date('c'),
    ];
    bm_ds_save_state($state);

    $payload = bm_ds_state_payload($pdo, $scope);
    $payload['done'] = $done;
    $payload['checked_now'] = $checked;
    $payload['matched_now'] = $matched;
    $payload['errors_now'] = $errors;
    $payload['next_delay_seconds'] = 0;
    $payload['message'] = $done ? 'کرال کامل شد.' : 'این بسته کوتاه انجام شد؛ بسته بعدی بلافاصله اجرا می‌شود.';
    return $payload;
}


if (isset($_GET['download_json'])) {
    $path = bm_ds_storage_path();
    if (!is_file($path)) {
        http_response_code(404);
        echo 'JSON هنوز ساخته نشده است.';
        exit;
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Content-Disposition: attachment; filename="donyaye_series_matches.json"');
    readfile($path);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['ajax_action'])) {
    admin_enforce_csrf();
    try {
        $action = (string)$_POST['ajax_action'];
        if ($action === 'status') {
            bm_ds_ajax_out(bm_ds_state_payload($pdo));
        }
        if ($action === 'test_storage') {
            $test = bm_ds_test_storage_write();
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo), [
                'message' => 'تست ذخیره موفق بود. فایل JSON ساخته/آپدیت شد.',
                'test_ok' => true,
                'storage_test' => $test,
            ]));
        }
        if ($action === 'test_connection') {
            $res = bm_ds_http_get(BM_DS_BASE . '/wp-json/', 18);
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo), [
                'message' => $res['ok'] ? ('تست اتصال مستقیم سرور موفق بود. HTTP ' . (int)$res['status']) : ('تست اتصال مستقیم سرور ناموفق: ' . ($res['error'] ?: ('HTTP ' . (int)$res['status']))),
                'test_ok' => (bool)$res['ok'],
                'test_status' => (int)$res['status'],
            ]));
        }
        if ($action === 'start_all') {
            $scope = (string)($_POST['scope'] ?? 'all');
            $scope = in_array($scope, ['all','missing_links'], true) ? $scope : 'all';
            $reset = !empty($_POST['reset']);
            if ($reset) {
                $path = bm_ds_storage_path();
                if (is_file($path)) @unlink($path);
            }
            bm_ds_save_json([], ['started_at' => date('c'), 'scope' => $scope, 'reset' => $reset ? true : false]);
            $total = bm_ds_count_local_series($pdo, $scope);
            $prev = bm_ds_load_state();
            $startOffset = $reset ? 0 : max(0, (int)($prev['offset'] ?? 0));
            if ($startOffset >= $total) $startOffset = 0;
            $state = bm_ds_save_state([
                'active' => true,
                'done' => false,
                'scope' => $scope,
                'offset' => $startOffset,
                'processed' => $reset ? 0 : (int)($prev['processed'] ?? 0),
                'matched' => $reset ? 0 : (int)($prev['matched'] ?? 0),
                'total' => $total,
                'started_at' => $reset || empty($prev['started_at']) ? date('c') : $prev['started_at'],
                'last_error' => '',
                'last_batch' => [],
                'live_offset' => $startOffset,
                'live_processed' => $startOffset,
                'live_matched' => (int)($prev['matched'] ?? 0),
                'batch_offset_start' => $startOffset,
                'batch_total' => 0,
                'batch_done' => 0,
                'batch_started_at' => null,
                'batch_finished_at' => null,
                'current_status' => 'آماده شروع نوبت بعدی',
                'current_item' => '',
                'current_imdb' => '',
                'current_title' => '',
                'last_saved_at' => null,
                'last_batch_items' => [],
            ]);
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo, $scope), ['message' => $reset ? 'کرال از صفر شروع شد؛ نوبت‌ها بدون وقفه پشت‌سرهم اجرا می‌شوند.' : 'کرال کلی از ادامه وضعیت قبلی شروع شد؛ نوبت‌ها بدون وقفه پشت‌سرهم اجرا می‌شوند.']));
        }
        if ($action === 'stop') {
            $state = bm_ds_load_state();
            $state['active'] = false;
            $state['done'] = false;
            bm_ds_save_state($state);
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo), ['message' => 'کرال متوقف شد.']));
        }
        if ($action === 'run_next') {
            bm_ds_ajax_out(bm_ds_run_batch($pdo, false));
        }
        if ($action === 'run_next_manual') {
            bm_ds_ajax_out(bm_ds_run_batch($pdo, true));
        }
        if ($action === 'clear') {
            $path = bm_ds_storage_path();
            if (is_file($path)) @unlink($path);
            $statePath = bm_ds_state_path();
            if (is_file($statePath)) @unlink($statePath);
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo), ['message' => 'JSON و وضعیت کرال پاک شد.']));
        }
        if ($action === 'single') {
            $imdb = trim((string)($_POST['imdb'] ?? ''));
            if (!preg_match('/^tt\d{6,10}$/i', $imdb)) throw new RuntimeException('کد IMDb معتبر نیست.');
            $stmt = $pdo->prepare("SELECT id, imdb_code, title, title_fa, year, type FROM movies WHERE imdb_code = ? LIMIT 1");
            $stmt->execute([strtolower($imdb)]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) $row = ['id' => 0, 'imdb_code' => strtolower($imdb), 'title' => (string)($_POST['title'] ?? ''), 'title_fa' => '', 'year' => '', 'type' => 'tvSeries'];
            $result = bm_ds_match_movie($row);
            bm_ds_save_json([$result], ['single' => $imdb]);
            bm_ds_ajax_out(array_merge(bm_ds_state_payload($pdo), ['message' => 'تست تک مورد انجام شد.', 'single_result' => $result]));
        }
        throw new RuntimeException('اکشن نامعتبر است.');
    } catch (Throwable $e) {
        $requestId = function_exists('bm_security_request_id') ? bm_security_request_id() : bin2hex(random_bytes(6));
        error_log('BankMovie crawler error [' . $requestId . ']: ' . $e->getMessage());
        bm_ds_ajax_out([
            'success' => false,
            'message' => 'عملیات انجام نشد. شناسه خطا: ' . $requestId,
            'request_id' => $requestId,
        ], 500);
    }
}

$scope = $_GET['scope'] ?? 'all';
$scope = in_array($scope, ['all','missing_links'], true) ? $scope : 'all';
$payload = bm_ds_state_payload($pdo, $scope);
$json = bm_ds_load_existing_json();
$items = bm_ds_compact_items_array($json);
$lastItems = array_slice(array_reverse($items), 0, 25);
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>کرال دنیای سریال - BankMovie</title>
<style>
@font-face{font-family:BonVF;src:url('/assets/fonts/bonVF.woff2') format('woff2');font-display:swap}*{box-sizing:border-box}body{margin:0;background:#08090d;color:#fff;font-family:BonVF,system-ui,sans-serif;padding:24px}.wrap{max-width:1250px;margin:auto}.top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:18px}.card{background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.10);border-radius:24px;padding:18px;margin-bottom:16px;box-shadow:0 18px 45px rgba(0,0,0,.25)}h1{margin:0;font-size:24px}h2{font-size:18px;margin:0 0 14px}p{color:#b9bcc9;line-height:1.9}.btn{border:0;border-radius:14px;padding:11px 16px;background:#36ff9f;color:#020403;font-weight:900;text-decoration:none;cursor:pointer;font-family:inherit;display:inline-flex;align-items:center;justify-content:center;gap:7px}.btn.secondary{background:#191c24;color:#fff;border:1px solid rgba(255,255,255,.12)}.btn.danger{background:#ff4d6d;color:#fff}.btn.warn{background:#ffbf4d;color:#1b1200}.btn:disabled{opacity:.45;cursor:not-allowed}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.stat{background:#0e1118;border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:14px}.stat b{display:block;font-size:22px;color:#36ff9f;margin-top:5px}.form-row{display:flex;gap:10px;flex-wrap:wrap;align-items:end}.field{display:flex;flex-direction:column;gap:7px}.field label{font-size:12px;color:#8f94a3}.field select,.field input{background:#11141b;border:1px solid rgba(255,255,255,.12);color:#fff;border-radius:13px;padding:11px 13px;font-family:inherit}.msg{display:none;background:rgba(54,255,159,.12);border:1px solid rgba(54,255,159,.28);color:#adffd5;border-radius:16px;padding:12px 14px;margin-bottom:14px}.err{display:none;background:rgba(255,77,109,.12);border:1px solid rgba(255,77,109,.28);color:#ffb6c4;border-radius:16px;padding:12px 14px;margin-bottom:14px}.bar{height:12px;background:#10131b;border:1px solid rgba(255,255,255,.09);border-radius:999px;overflow:hidden;margin-top:12px}.bar span{display:block;height:100%;width:0;background:linear-gradient(90deg,#36ff9f,#36c2ff);transition:.3s}.runner{display:grid;grid-template-columns:1.2fr .8fr;gap:14px}.status-line{display:flex;flex-wrap:wrap;gap:9px;margin-top:12px}.pill{background:#11141b;border:1px solid rgba(255,255,255,.10);border-radius:999px;padding:7px 10px;color:#dce1eb;font-size:12px}.pill.ok{color:#9bffd0;border-color:rgba(54,255,159,.25);background:rgba(54,255,159,.08)}.pill.bad{color:#ffb1c0;border-color:rgba(255,77,109,.25);background:rgba(255,77,109,.08)}table{width:100%;border-collapse:collapse;overflow:hidden;border-radius:18px}th,td{padding:11px;border-bottom:1px solid rgba(255,255,255,.075);text-align:right;vertical-align:top;font-size:13px}th{color:#36ff9f;background:#10131b}td{color:#e8eaf0}.tag{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:900}.high{background:rgba(54,255,159,.16);color:#8dffca}.medium{background:rgba(255,184,77,.16);color:#ffd49a}.low,.none{background:rgba(255,77,109,.15);color:#ffb1c0}.muted{color:#8f94a3;font-size:12px}.ltr{direction:ltr;text-align:left;word-break:break-all}.small{font-size:12px}.log{background:#080a0f;border:1px solid rgba(255,255,255,.08);border-radius:18px;padding:12px;min-height:96px;max-height:260px;overflow:auto;color:#cbd3e1;font-size:12px;line-height:1.8;direction:rtl}.progressText{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;color:#cbd3e1;font-size:12px;margin-top:8px}.mini-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:12px}.mini{background:#0b0e15;border:1px solid rgba(255,255,255,.075);border-radius:14px;padding:10px;color:#b9bcc9;font-size:12px}.mini b{color:#fff;display:block;margin-top:4px;direction:ltr;text-align:left;word-break:break-all}.directBox{background:rgba(54,194,255,.06);border-color:rgba(54,194,255,.18)}@media(max-width:900px){.grid{grid-template-columns:1fr 1fr}.runner{grid-template-columns:1fr}body{padding:12px}table{display:block;overflow:auto}.form-row{align-items:stretch}.field{width:100%}.btn{width:100%;text-align:center}}
</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <div><h1>کرال دنیای سریال</h1><p style="margin:.3rem 0 0">دیتابیس را تغییر نمی‌دهد؛ خروجی JSON به شکل IMDb => title + links ذخیره می‌شود و خوانا/خط‌به‌خط است. حالت کلی بدون وقفه اجرا می‌شود.</p></div>
    <div><a class="btn secondary" href="admin.php">بازگشت به ادمین</a> <a class="btn secondary" href="<?= bm_ds_e(BM_DS_JSON_REL) ?>" target="_blank">مشاهده JSON</a></div>
  </div>

  <div id="msg" class="msg"></div>
  <div id="err" class="err"></div>

  <div class="grid">
    <div class="stat">کل سریال‌ها <b id="stTotal"><?= number_format((int)$payload['total']) ?></b></div>
    <div class="stat">بررسی‌شده این ران <b id="stProcessed"><?= number_format((int)$payload['processed']) ?></b></div>
    <div class="stat">IMDbهای ذخیره‌شده <b id="stJson"><?= number_format((int)$payload['json_items']) ?></b></div>
    <div class="stat">دارای لینک <b id="stMatched"><?= number_format((int)$payload['json_matched']) ?></b></div>
  </div>

  <div class="card runner">
    <div>
      <h2>شروع کلی بدون وقفه</h2>
      <div class="form-row">
        <div class="field"><label>محدوده</label><select id="scope"><option value="all">همه سریال‌ها</option><option value="missing_links">فقط سریال‌های بدون لینک</option></select></div>
        <button class="btn" id="startBtn" type="button">شروع/ادامه کلی</button>
        <button class="btn warn" id="resetStartBtn" type="button">شروع از صفر</button>
        <button class="btn warn" id="runNextBtn" type="button">اجرای دستی نوبت بعدی</button>
        <button class="btn secondary" id="stopBtn" type="button">توقف</button>
        <button class="btn danger" id="clearBtn" type="button">پاک کردن JSON/وضعیت</button>
        <a class="btn secondary" href="?download_json=1">دانلود JSON</a>
      </div>
      <div class="bar"><span id="progressBar"></span></div>
      <div class="progressText"><span id="progressPct">0%</span><span id="nextRunText">نوبت بعدی: —</span><span id="saveText">ذخیره: —</span></div>
      <div class="mini-grid" style="grid-template-columns:repeat(4,minmax(0,1fr));">
        <div class="mini">پیشرفت همین نوبت<b id="batchProgress">—</b></div>
        <div class="mini">مورد فعلی<b id="currentItem">—</b></div>
        <div class="mini">IMDb فعلی<b id="currentImdb">—</b></div>
        <div class="mini">وضعیت زنده<b id="currentStatus">—</b></div>
      </div>
      <div class="status-line">
        <span class="pill" id="stActive">وضعیت: —</span>
        <span class="pill">حالت اجرا: پشت‌سرهم بدون وقفه</span>
        <span class="pill" id="stOffset">Offset: <?= (int)$payload['offset'] ?></span>
        <span class="pill" id="stRemain">مانده: <?= (int)$payload['remaining'] ?></span>
        <span class="pill ok" id="stConn">اتصال: مستقیم سرور BankMovie</span>
      </div>
      <div class="mini-grid">
        <div class="mini">حجم JSON<b id="jsonSize">—</b></div>
        <div class="mini">آخرین ذخیره<b id="jsonMtime">—</b></div>
        <div class="mini">کل لینک‌های ذخیره‌شده<b id="dbLinks">—</b></div>
        <div class="mini">وضعیت cache<b id="cacheStatus">—</b></div>
        <div class="mini">مسیر JSON<b id="jsonPath">—</b></div>
      </div>
      <p class="small">بعد از زدن «شروع کلی»، همین صفحه را باز نگه دار. بدون وقفه می‌زند و خودش JSON را آپدیت می‌کند. اگر صفحه بسته شود، با دکمه شروع کلی از آخرین offset ذخیره‌شده ادامه می‌دهد. فایل JSON فقط شامل imdb_code و links است.</p>
    </div>
    <div>
      <h2>لاگ زنده</h2>
      <div class="log" id="liveLog">آماده...</div>
    </div>
  </div>


  <div class="card">
    <h2>تست اتصال مستقیم سرور</h2>
    <p class="small">کرالر فقط با cURL خود سرور BankMovie به دنیای سریال وصل می‌شود. اگر این تست سبز شود، همان مسیر برای کرال استفاده می‌شود.</p>
    <div class="form-row">
      <button class="btn warn" id="testConnectionBtn" type="button">تست اتصال مستقیم سرور</button>
      <button class="btn secondary" id="testStorageBtn" type="button">تست ذخیره cache/JSON</button>
    </div>
  </div>

  <div class="card">
    <h2>تست تک مورد با IMDb</h2>
    <div class="form-row">
      <div class="field"><label>IMDb Code</label><input id="singleImdb" placeholder="tt0411008" dir="ltr"></div>
      <div class="field"><label>عنوان کمکی اختیاری</label><input id="singleTitle" placeholder="Lost"></div>
      <button class="btn secondary" id="singleBtn" type="button">تست و ذخیره داخل JSON</button>
    </div>
  </div>

  <div class="card">
    <h2>آخرین IMDbهای ذخیره‌شده در JSON نهایی</h2>
    <table>
      <thead><tr><th>Title</th><th>IMDb</th><th>تعداد لینک</th><th>نمونه لینک</th></tr></thead>
      <tbody>
      <?php if(empty($lastItems)): ?>
        <tr><td colspan="4" class="muted">هنوز لینک قابل ذخیره‌ای داخل JSON نیست.</td></tr>
      <?php endif; ?>
      <?php foreach($lastItems as $r):
        $imdb = (string)($r['imdb_code'] ?? ($r['local']['imdb_code'] ?? ''));
        $links = [];
        if (!empty($r['links']) && is_array($r['links'])) $links = $r['links'];
        elseif (function_exists('bm_ds_compact_links_from_item')) $links = bm_ds_compact_links_from_item($r);
        $firstLink = (string)($links[0] ?? '');
      ?>
        <tr>
          <td><b><?= bm_ds_e($r['title'] ?? '') ?></b></td>
          <td class="ltr"><b><?= bm_ds_e($imdb) ?></b></td>
          <td><?= number_format(count($links)) ?></td>
          <td class="small ltr"><?php if($firstLink): ?><a href="<?= bm_ds_e($firstLink) ?>" target="_blank"><?= bm_ds_e($firstLink) ?></a><?php else: ?>—<?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<script>
const CSRF = <?= json_encode($csrf) ?>;
let running = false;
let nextTimer = null;
let countdownTimer = null;
let nextRunAt = 0;
function qs(id){return document.getElementById(id)}
function logLine(t){ const el=qs('liveLog'); const time=new Date().toLocaleTimeString('fa-IR'); el.innerHTML = '['+time+'] '+escapeHtml(t)+'<br>'+el.innerHTML; }
function escapeHtml(s){return String(s||'').replace(/[&<>"]/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]));}
function showMsg(t){qs('msg').style.display='block';qs('msg').textContent=t||''; if(t) setTimeout(()=>qs('msg').style.display='none',6000)}
function showErr(t){qs('err').style.display='block';qs('err').textContent=t||''; if(t) setTimeout(()=>qs('err').style.display='none',9000)}
async function post(action, data={}){
  const fd = new FormData(); fd.append('ajax_action', action); fd.append('csrf_token', CSRF);
  Object.keys(data).forEach(k=>fd.append(k,data[k]));
  const res = await fetch(location.pathname, {method:'POST', body:fd, credentials:'same-origin'});
  const text = await res.text();
  let json; try{json=JSON.parse(text)}catch(e){throw new Error('پاسخ JSON نبود: '+text.slice(0,300));}
  if(!res.ok || json.success===false) throw new Error(json.message || 'خطا در درخواست');
  return json;
}
function fmtBytes(n){ n=Number(n||0); if(n<1024) return n+' B'; if(n<1048576) return (n/1024).toFixed(1)+' KB'; return (n/1048576).toFixed(2)+' MB'; }
function fmtDate(s){ if(!s) return '—'; try{return new Date(s).toLocaleString('fa-IR')}catch(e){return s} }
function updateStats(p){
  if(!p) return;
  const nf = new Intl.NumberFormat('fa-IR');
  qs('stTotal').textContent = nf.format(p.total||0);
  const stt = p.state || {};
  qs('stProcessed').textContent = nf.format(p.processed || stt.live_processed || stt.processed || 0);
  qs('stJson').textContent = nf.format(p.json_items||0);
  qs('stMatched').textContent = nf.format(p.json_matched||0);
  const liveOffset = p.offset || stt.live_offset || 0;
  qs('stOffset').textContent = 'Offset زنده: '+nf.format(liveOffset);
  qs('stRemain').textContent = 'مانده: '+nf.format(p.remaining||0);
  const pctRaw = p.total ? (liveOffset/p.total)*100 : 0;
  const pct = Math.min(100, Math.max(0, pctRaw));
  qs('progressBar').style.width = pct+'%';
  qs('progressPct').textContent = 'پیشرفت واقعی کل: '+nf.format(Math.round(pct*10)/10)+'٪ ('+nf.format(liveOffset)+' از '+nf.format(p.total||0)+')';
  const bd = Number(stt.batch_done || 0), bt = Number(stt.batch_total || 0);
  qs('batchProgress').textContent = bt ? (nf.format(bd)+' از '+nf.format(bt)+' — '+nf.format(Math.round((bd/bt)*100))+'٪') : '—';
  qs('currentItem').textContent = stt.current_item || '—';
  qs('currentImdb').textContent = stt.current_imdb || '—';
  qs('currentStatus').textContent = stt.current_status || '—';
  const st = p.storage || {};
  qs('jsonSize').textContent = fmtBytes(st.json_size||0);
  qs('jsonMtime').textContent = fmtDate(st.json_mtime);
  qs('dbLinks').textContent = nf.format(st.db_link_total||0);
  if(qs('cacheStatus')) qs('cacheStatus').textContent = (st.dir_writable ? 'قابل نوشتن' : 'غیرقابل نوشتن') + (st.dir_perms ? ' / '+st.dir_perms : '');
  if(qs('jsonPath')) qs('jsonPath').textContent = st.json_path || '—';
  qs('saveText').textContent = (st.json_exists ? 'ذخیره شد: '+fmtBytes(st.json_size||0) : (st.dir_writable ? 'آماده ذخیره' : 'cache غیرقابل نوشتن'));
  const active = !!(p.state&&p.state.active);
  qs('stActive').textContent = active ? 'وضعیت: در حال اجرا' : ((p.state&&p.state.done) ? 'وضعیت: کامل شد' : 'وضعیت: متوقف');
  qs('stActive').className = 'pill '+(active?'ok':'');
  qs('stConn').textContent = 'اتصال: مستقیم سرور BankMovie ('+('direct curl')+')';
  qs('stConn').className = 'pill ok';
}
function startCountdown(sec){
  clearInterval(countdownTimer);
  nextRunAt = Date.now() + (Number(sec||0)*1000);
  countdownTimer = setInterval(()=>{
    const left = Math.max(0, Math.ceil((nextRunAt-Date.now())/1000));
    qs('nextRunText').textContent = left ? ('نوبت بعدی: '+left+' ثانیه دیگر') : 'نوبت بعدی: در حال اجرا...';
    if(left<=0) clearInterval(countdownTimer);
  }, 1000);
}
async function refreshStatus(){ try{ updateStats(await post('status')); }catch(e){} }
async function runBatch(){
  if(!running) return;
  let poller = null;
  try{
    setButtons(true);
    qs('nextRunText').textContent = 'نوبت فعلی در حال اجراست...';
    poller = setInterval(refreshStatus, 2000);
    const p = await post('run_next');
    clearInterval(poller);
    poller = null;
    updateStats(p);
    const lastItems = (p.state && p.state.last_batch_items) ? p.state.last_batch_items : [];
    if(lastItems.length){
      logLine('آخرین مورد: '+(lastItems[0].title||'')+' / '+(lastItems[0].imdb_code||'')+' / '+(lastItems[0].matched?'پیدا شد':'پیدا نشد'));
    }
    logLine((p.message||'نوبت انجام شد')+' بررسی: '+(p.checked_now||0)+' / Match: '+(p.matched_now||0));
    if(p.done || !(p.state&&p.state.active)) { running=false; setButtons(false); showMsg('کرال تمام شد یا متوقف شد.'); return; }
    const delay = Number.isFinite(Number(p.next_delay_seconds)) ? Number(p.next_delay_seconds) : 0;
    if(delay > 0) startCountdown(delay); else qs('nextRunText').textContent = 'نوبت بعدی: بلافاصله';
    nextTimer = setTimeout(runBatch, Math.max(100, delay * 1000));
    logLine(delay > 0 ? ('نوبت بعدی '+delay+' ثانیه دیگر اجرا می‌شود...') : 'نوبت بعدی بلافاصله اجرا می‌شود...');
  }catch(e){
    if(poller) clearInterval(poller);
    const msg = e && e.message ? e.message : String(e||'');
    logLine('خطا: '+msg);
    if(running && (msg.includes('Request Timeout') || msg.includes('500 Internal Server Error') || msg.includes('پاسخ JSON نبود'))){
      showErr('سرور تایم‌اوت داد، اما چون هر آیتم ذخیره می‌شود، ۲ ثانیه دیگر از آخرین offset ادامه می‌دهم.');
      await refreshStatus();
      nextTimer = setTimeout(runBatch, 2000);
      return;
    }
    running=false; setButtons(false); showErr(msg);
  }
}
function setButtons(busy){
  qs('startBtn').disabled = busy;
  qs('runNextBtn').disabled = busy;
  qs('resetStartBtn').disabled = busy;
  qs('singleBtn').disabled = busy;
  if(qs('testConnectionBtn')) qs('testConnectionBtn').disabled = busy;
  if(qs('testStorageBtn')) qs('testStorageBtn').disabled = busy;
}
qs('startBtn').addEventListener('click', async()=>{
  try{
    clearTimeout(nextTimer); clearInterval(countdownTimer); running=true; setButtons(true);
    const p = await post('start_all', {scope:qs('scope').value, reset:''});
    updateStats(p); showMsg(p.message||'شروع شد'); logLine('شروع/ادامه کلی فعال شد.');
    runBatch();
  }catch(e){running=false;setButtons(false);showErr(e.message);}
});
qs('resetStartBtn').addEventListener('click', async()=>{
  if(!confirm('از صفر شروع شود و JSON قبلی پاک شود؟')) return;
  try{
    clearTimeout(nextTimer); clearInterval(countdownTimer); running=true; setButtons(true);
    const p = await post('start_all', {scope:qs('scope').value, reset:'1'});
    updateStats(p); showMsg(p.message||'شروع شد'); logLine('کرال از صفر فعال شد.');
    runBatch();
  }catch(e){running=false;setButtons(false);showErr(e.message);}
});
qs('stopBtn').addEventListener('click', async()=>{
  try{ running=false; clearTimeout(nextTimer); clearInterval(countdownTimer); const p=await post('stop'); updateStats(p); setButtons(false); showMsg('متوقف شد.'); logLine('کرال متوقف شد.'); }catch(e){showErr(e.message)}
});
qs('runNextBtn').addEventListener('click', async()=>{
  try{ setButtons(true); const p=await post('run_next_manual'); updateStats(p); showMsg(p.message||'نوبت بعدی انجام شد.'); logLine('اجرای دستی نوبت: بررسی '+(p.checked_now||0)+' / Match '+(p.matched_now||0)); }catch(e){showErr(e.message); logLine('خطا: '+e.message)} finally{setButtons(false)}
});
qs('clearBtn').addEventListener('click', async()=>{
  if(!confirm('JSON و وضعیت فعلی پاک شود؟')) return;
  try{ running=false; clearTimeout(nextTimer); clearInterval(countdownTimer); const p=await post('clear'); updateStats(p); showMsg('پاک شد.'); logLine('JSON و وضعیت پاک شد.'); location.reload(); }catch(e){showErr(e.message)}
});
qs('singleBtn').addEventListener('click', async()=>{
  try{ setButtons(true); const p=await post('single',{imdb:qs('singleImdb').value.trim(), title:qs('singleTitle').value.trim()}); updateStats(p); showMsg('تست تک مورد انجام شد.'); logLine('تست تک مورد انجام شد.'); }catch(e){showErr(e.message); logLine('خطا: '+e.message)} finally{setButtons(false)}
});

qs('testConnectionBtn').addEventListener('click', async()=>{
  try{ setButtons(true); const p=await post('test_connection'); updateStats(p); (p.test_ok?showMsg:showErr)(p.message||'تست انجام شد.'); logLine(p.message||'تست اتصال مستقیم انجام شد.'); }catch(e){showErr(e.message); logLine('خطای تست اتصال مستقیم: '+e.message)} finally{setButtons(false)}
});
if(qs('testStorageBtn')) qs('testStorageBtn').addEventListener('click', async()=>{
  try{ setButtons(true); const p=await post('test_storage'); updateStats(p); showMsg(p.message||'تست ذخیره انجام شد.'); logLine('تست ذخیره OK: '+((p.storage_test&&p.storage_test.main_json_path)||'')); }catch(e){showErr(e.message); logLine('خطای ذخیره: '+e.message)} finally{setButtons(false)}
});

refreshStatus();
setInterval(()=>{ if(running || (document.visibilityState !== 'hidden')) refreshStatus(); }, 5000);
</script>
</body>
</html>
