<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/archive_control.php';
if (!bm_archive_user_can_access('archive1', $currentUser ?? null)) {
    http_response_code(404);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status'=>'error','error'=>'not_found'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}
/**
 * api2.php — API endpoint اصلی (JSON output)
 * برای درخواست‌های AJAX از / و archive1.php
 */
header('Content-Type: application/json; charset=utf-8');
bm_security_enforce_rate_limit('api2_public', 600, 300, bm_security_client_ip(), true);
require_once __DIR__ . '/includes/api2_lib.php';

if (!defined('API2_JSON_CACHE_TTL')) define('API2_JSON_CACHE_TTL', 600); // 10 minutes

function api2_requested_limit(): int {
    $limit = (int)($_GET['limit'] ?? 0);
    if ($limit <= 0) return 0;
    return max(1, min(24, $limit));
}

function api2_apply_limit(array $payload, int $limit): array {
    if ($limit <= 0 || !isset($payload['movies']) || !is_array($payload['movies'])) return $payload;
    $originalCount = count($payload['movies']);
    $payload['movies'] = array_slice($payload['movies'], 0, $limit);
    $payload['count'] = count($payload['movies']);
    if ($originalCount > $limit) $payload['has_more'] = true;
    return $payload;
}

function api2_json_cache_path(string $key): string {
    $name = 'api2_json_' . sha1($key) . '.cache';
    if (function_exists('bm_security_private_path')) return bm_security_private_path($name);
    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;
}

function api2_read_json_cache(string $file): ?string {
    if (!is_file($file) || (time() - (int)@filemtime($file)) > API2_JSON_CACHE_TTL) return null;
    $json = @file_get_contents($file);
    if (!is_string($json) || $json === '') return null;
    json_decode($json, true);
    return json_last_error() === JSON_ERROR_NONE ? $json : null;
}

function api2_write_json_cache(string $file, string $json): void {
    if ($json === '' || strlen($json) > 4 * 1024 * 1024) return;
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    if (!is_dir($dir) || !is_writable($dir)) return;
    $tmp = $file . '.' . getmypid() . '.tmp';
    if (@file_put_contents($tmp, $json, LOCK_EX) === false) { @unlink($tmp); return; }
    @chmod($tmp, 0600);
    if (!@rename($tmp, $file)) @unlink($tmp);
    else @chmod($file, 0600);
}

function api2_send_cache_headers(string $state): void {
    if (!headers_sent()) {
        $scope = function_exists('bm_archive_access_scope') ? bm_archive_access_scope('archive1') : 'public';
        $downloadScope = function_exists('bm_archive_feature_scope') ? bm_archive_feature_scope('archive1', 'download') : 'public';
        $streamScope = function_exists('bm_archive_feature_scope') ? bm_archive_feature_scope('archive1', 'stream') : 'public';
        if ($scope === 'public' && $downloadScope === 'public' && $streamScope === 'public') {
            header('Cache-Control: public, max-age=600, stale-while-revalidate=60');
            header('Vary: Accept-Encoding');
        } else {
            // Never allow a VIP/member/admin response to leak through a shared CDN/browser cache.
            header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
            header('Pragma: no-cache');
            header('Vary: Cookie, Accept-Encoding');
        }
        header('X-BM-Cache: ' . strtoupper($state));
    }
}

/**
 * Cache public Archive 1 list/section responses for ten minutes.
 * Searches and detail pages deliberately bypass this cache.
 */
function api2_emit_cached(string $cacheKey, callable $producer, int $limit = 0): void {
    $publicPolicy = bm_archive_access_scope('archive1') === 'public'
        && bm_archive_feature_scope('archive1', 'download') === 'public'
        && bm_archive_feature_scope('archive1', 'stream') === 'public';
    if (!$publicPolicy) {
        $payload = $producer();
        if (!is_array($payload)) $payload = ['status' => 'error', 'error' => 'Invalid API payload'];
        $payload = api2_apply_limit($payload, $limit);
        $payload = bm_archive_apply_payload_policy('archive1', $payload, $GLOBALS['currentUser'] ?? null);
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive1');
        if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
        api2_send_cache_headers('bypass');
        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) throw new RuntimeException('JSON encoding failed');
        echo $json;
        exit;
    }

    $domainFingerprint = implode(',', bm_archive_download_base_urls('archive1'))
        . '|source=' . bm_archive_source_base_url('archive1', '');
    $file = api2_json_cache_path('v73-managed-domains|' . $domainFingerprint . '|' . $cacheKey . '|limit=' . $limit);
    $cached = api2_read_json_cache($file);
    if ($cached !== null) {
        api2_send_cache_headers('hit');
        echo $cached;
        exit;
    }

    $lock = @fopen($file . '.lock', 'c');
    if (is_resource($lock)) @flock($lock, LOCK_EX);
    try {
        $cached = api2_read_json_cache($file);
        if ($cached !== null) {
            api2_send_cache_headers('hit');
            echo $cached;
            exit;
        }

        $payload = $producer();
        if (!is_array($payload)) $payload = ['status' => 'error', 'error' => 'Invalid API payload'];
        $payload = api2_apply_limit($payload, $limit);
        if (function_exists('bm_archive_apply_payload_policy')) $payload = bm_archive_apply_payload_policy('archive1', $payload, $GLOBALS['currentUser'] ?? null);
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive1');
        if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) throw new RuntimeException('JSON encoding failed');
        api2_write_json_cache($file, $json);
        api2_send_cache_headers('miss');
        echo $json;
        exit;
    } finally {
        if (is_resource($lock)) {
            @flock($lock, LOCK_UN);
            @fclose($lock);
        }
    }
}

// ============================================================
// بخش اصلی API
// ============================================================
try {
    $sectionLimit = api2_requested_limit();

    if (!bm_archive_is_enabled('archive1')) {
        http_response_code(503);
        header('Cache-Control: no-store');
        echo json_encode(['status'=>'disabled','movies'=>[],'downloads'=>[],'message'=>bm_archive_disabled_message('archive1')], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        exit;
    }

    // گزینه‌های واقعی جستجوی پیشرفته و دسته‌بندی‌های آرشیو ۱
    // مثال: api2.php?options=search
    if (isset($_GET['options']) && trim((string)$_GET['options']) === 'search') {
        $payload = api2_search_options();
        echo json_encode(array_merge(array('status'=>'success'), $payload), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    // لیست‌های آپدیت کامل: ادغام سکشن صفحه اصلی با صفحه اول آرشیو برای جلوگیری از جاافتادن آیتم‌ها
    // مثال: api2.php?updates=movies یا api2.php?updates=series
    if (isset($_GET['updates'])) {
        $kind = trim((string)$_GET['updates']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        api2_emit_cached('updates:' . $kind . ':page:' . $page, function() use ($kind, $page) {
            $result = getUpdatedList($kind, $page);
            return array_merge(['status' => 'success'], $result);
        }, $sectionLimit);
    }

    // آرشیو مستقیم فیلم/سریال، جدا از سرچ عمومی
    // مثال: api2.php?archive=movies یا api2.php?archive=series
    if (isset($_GET['archive'])) {
        $kind = trim((string)$_GET['archive']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        api2_emit_cached('archive:' . $kind . ':page:' . $page, function() use ($kind, $page) {
            $result = getArchiveList($kind, $page);
            return array_merge(['status' => 'success'], $result);
        }, $sectionLimit);
    }

    // دریافت لیست دسته‌بندی‌های خاص
    if (isset($_GET['category'])) {
        $slug = trim((string)$_GET['category']);
        $page = max(1, (int)($_GET['page'] ?? 1));
        api2_emit_cached('category:' . $slug . ':page:' . $page, function() use ($slug, $page) {
            $result = getCategoryList($slug, $page);
            return array_merge(['status' => 'success'], $result);
        }, $sectionLimit);
    }

    // دریافت صفحه اختصاصی بازیگر و فیلم‌های او
    // مثال: api2.php?actor=catalina-sandino-moreno
    if (isset($_GET['actor']) || isset($_GET['actor_url'])) {
        $identifier = $_GET['actor_url'] ?? $_GET['actor'];
        $result = getActorDetails($identifier);
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    // درخواست جزئیات با شناسه یا لینک مستقیم
    if (isset($_GET['id']) || isset($_GET['url'])) {
        $identifier = $_GET['url'] ?? $_GET['id'];
        $typeHint = $_GET['type'] ?? null;
        $result = getMovieDetails($identifier, $typeHint);
        if (function_exists('bm_archive_apply_payload_policy')) $result = bm_archive_apply_payload_policy('archive1', $result, $currentUser ?? null, ['identifier'=>(string)$identifier]);
        if (function_exists('bm_dl_wrap_payload')) $result = bm_dl_wrap_payload($result, false, 'archive1');
        if (function_exists('bm_poster_wrap_payload')) $result = bm_poster_wrap_payload($result);
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    // جستجو / فیلتر / لیست
    if (isset($_GET['s']) || isset($_GET['type']) || isset($_GET['genre'])) {
        // سازگاری با کدهای قبلی: اگر فقط type=movie/series آمده و سرچ/فیلتر واقعی نداریم،
        // خروجی را از لیست‌های دقیق آپدیت بگیر، نه از سرچ عمومی که سکشن‌ها را قاطی می‌کند.
        $onlyTypeList = isset($_GET['type']) && !isset($_GET['s']) && !isset($_GET['genre'])
            && !isset($_GET['sortby']) && !isset($_GET['imdbrate']) && !isset($_GET['country'])
            && !isset($_GET['min_year']) && !isset($_GET['max_year']) && !isset($_GET['dubbed']) && !isset($_GET['subtitle']);
        if ($onlyTypeList && in_array($_GET['type'], ['movie','movies','series','tv','tvSeries'], true)) {
            $kind = in_array($_GET['type'], ['series','tv','tvSeries'], true) ? 'series' : 'movie';
            $page = max(1, (int)($_GET['page'] ?? 1));
            api2_emit_cached('typed-list:' . $kind . ':page:' . $page, function() use ($kind, $page) {
                $result = getUpdatedList($kind, $page);
                return array_merge(['status' => 'success'], $result);
            }, $sectionLimit);
        }

        $params = [
            's' => $_GET['s'] ?? '',
            'type' => $_GET['type'] ?? 'both',
            'genre' => (int)($_GET['genre'] ?? 0),
            'sortby' => $_GET['sortby'] ?? 'newest',
            'imdbrate' => (int)($_GET['imdbrate'] ?? 0),
            'country' => (int)($_GET['country'] ?? 0),
            'min_year' => (int)($_GET['min_year'] ?? 1800),
            'max_year' => (int)($_GET['max_year'] ?? date('Y')),
            'page' => (int)($_GET['page'] ?? 1),
            'dubbed' => (int)($_GET['dubbed'] ?? 0),
            'subtitle' => (int)($_GET['subtitle'] ?? 0)
        ];

        $movies = advancedSearch($params);
        echo json_encode([
            'status' => 'success',
            'query' => $params['s'],
            'filters' => $params,
            'count' => count($movies),
            'movies' => $movies
        ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        exit;
    }

    // لیست پیش‌فرض: ترکیب آپدیت فیلم و سریال، نه کل سکشن‌های صفحه اصلی
    $page = max(1, (int)($_GET['page'] ?? 1));
    api2_emit_cached('default:page:' . $page, function() use ($page) {
        if ($page <= 1) {
            $moviesPart = getUpdatedList('movie', 1)['movies'];
            $seriesPart = getUpdatedList('series', 1)['movies'];
            $movies = array_values(array_merge($moviesPart, $seriesPart));
        } else {
            $movies = advancedSearch(['page' => $page]);
        }
        return [
            'status' => 'success',
            'page' => $page,
            'count' => count($movies),
            'movies' => $movies
        ];
    }, $sectionLimit);

} catch (Throwable $e) {
    http_response_code(500);
    if (!headers_sent()) header('Cache-Control: no-store');
    echo json_encode(['status' => 'error', 'error' => 'internal_error', 'message' => bm_security_generic_error($e, 'خطای موقت سرور')], JSON_UNESCAPED_UNICODE);
}
