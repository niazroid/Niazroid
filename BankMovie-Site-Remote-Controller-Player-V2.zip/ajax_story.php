<?php
// ajax_story.php
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');
bm_require_post(true);
bm_require_user_csrf(true, true);
bm_security_enforce_rate_limit('ajax_story_write', 180, 300, bm_security_client_ip(), true);

$currentUser = null;
if(isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

$action = $_POST['action'] ?? '';

switch($action) {
    case 'view_story':
        if(!$currentUser) {
            echo json_encode(['success' => false, 'error' => 'Not logged in']);
            break;
        }
        
        $storyId = intval($_POST['story_id'] ?? 0);
        if($storyId <= 0) {
            echo json_encode(['success' => false, 'error' => 'Invalid story ID']);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("
                INSERT INTO story_views (story_id, user_id, viewed_at) 
                VALUES (?, ?, NOW())
                ON DUPLICATE KEY UPDATE viewed_at = NOW()
            ");
            $stmt->execute([$storyId, $currentUser['id']]);
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            error_log('ajax_story database error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Database error']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>