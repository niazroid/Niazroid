<?php
// get_movie_by_imdb.php - دریافت کامل فیلم/سریال با IMDb code
require_once 'config.php';
require_once __DIR__ . '/includes/archive_control.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
bm_security_enforce_rate_limit('api_movie_detail', 180, 300, bm_security_client_ip(), true);

if (!bm_archive_is_enabled('archive2') || !bm_archive_user_can_access('archive2', $currentUser ?? null)) {
    http_response_code(404);
    echo json_encode(['error' => 'Movie not found']);
    exit;
}

$imdb = isset($_GET['imdb']) ? trim($_GET['imdb']) : '';
if (!$imdb || !preg_match('/^tt\d+$/', $imdb)) {
    http_response_code(400);
    echo json_encode(['error' => 'Valid IMDb code (ttxxxxxx) is required']);
    exit;
}

try {
    // 1. اطلاعات اصلی فیلم/سریال
    $stmt = $pdo->prepare("SELECT * FROM movies WHERE imdb_code = ?");
    $stmt->execute([$imdb]);
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$movie) {
        http_response_code(404);
        echo json_encode(['error' => 'Movie not found']);
        exit;
    }
    
    // 2. لینک‌های دوبله (برای فیلم)
    $dubStmt = $pdo->prepare("SELECT url, quality, size FROM dubbed_links WHERE movie_id = ?");
    $dubStmt->execute([$movie['id']]);
    $movie['dubbed_links'] = $dubStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 3. لینک‌های زیرنویس (برای فیلم)
    $softStmt = $pdo->prepare("SELECT url, quality, size FROM softsub_links WHERE movie_id = ?");
    $softStmt->execute([$movie['id']]);
    $movie['softsub_links'] = $softStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // 4. اگر سریال بود، همه لینک‌های فصل‌ها رو بگیر
    if ($movie['type'] === 'tvSeries') {
        $seriesStmt = $pdo->prepare("
            SELECT 'dub' as type, url, quality, size, season 
            FROM dubbed_links WHERE movie_id = ?
            UNION
            SELECT 'soft' as type, url, quality, size, season 
            FROM softsub_links WHERE movie_id = ?
        ");
        $seriesStmt->execute([$movie['id'], $movie['id']]);
        $movie['series_links'] = $seriesStmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    $payload = [
        'success' => true,
        'data' => $movie
    ];
    if (function_exists('bm_archive_apply_payload_policy')) $payload = bm_archive_apply_payload_policy('archive2', $payload, $currentUser ?? null, ['identifier'=>$imdb]);
    if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive2');
    if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Database error']);
}
?>
