<?php
// ajax_search.php
require_once 'config.php';
header('Content-Type: application/json; charset=utf-8');
bm_require_post(true);
bm_require_user_csrf(true, true);
bm_security_enforce_rate_limit('ajax_search_write', 120, 300, bm_security_client_ip(), true);

$currentUser = null;
if(isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

$action = $_POST['action'] ?? '';

switch($action) {
    case 'save_search':
        if(!$currentUser) {
            echo json_encode(['success' => true]);
            break;
        }
        
        $term = bm_security_limit_text($_POST['term'] ?? '', 160);
        if(strlen($term) < 2) {
            echo json_encode(['success' => false]);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("DELETE FROM search_history WHERE user_id = ? AND search_term = ?");
            $stmt->execute([$currentUser['id'], $term]);
            
            $stmt = $pdo->prepare("INSERT INTO search_history (user_id, search_term, searched_at) VALUES (?, ?, NOW())");
            $stmt->execute([$currentUser['id'], $term]);
            
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            error_log('ajax_search database error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Database error']);
        }
        break;
        
    case 'delete_search':
        if(!$currentUser) {
            echo json_encode(['success' => true]);
            break;
        }
        
        $term = bm_security_limit_text($_POST['term'] ?? '', 160);
        if(empty($term)) {
            echo json_encode(['success' => false]);
            break;
        }
        
        try {
            $stmt = $pdo->prepare("DELETE FROM search_history WHERE user_id = ? AND search_term = ?");
            $stmt->execute([$currentUser['id'], $term]);
            echo json_encode(['success' => true]);
        } catch(PDOException $e) {
            error_log('ajax_search database error: ' . $e->getMessage());
            echo json_encode(['success' => false, 'error' => 'Database error']);
        }
        break;
        
    default:
        echo json_encode(['success' => false, 'error' => 'Invalid action']);
}
?>