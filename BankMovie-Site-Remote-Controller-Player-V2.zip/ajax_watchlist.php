<?php
// ajax_watchlist.php - نسخه سازگار با آرشیو ۲ و fallback برای آرشیو ۱
require_once 'config.php';
require_once __DIR__ . '/includes/vip_features.php';
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$currentUser = null;
if (isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

bm_vip_gate_require('watchlist', $currentUser ?: null, true);

$bmWatchlistIdentity = $currentUser ? ('user:' . (int)$currentUser['id']) : ('ip:' . bm_security_client_ip());
bm_security_enforce_rate_limit('web_watchlist_read', 240, 300, $bmWatchlistIdentity, true);

function bm_json($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_get_action(): string {
    foreach (['action', 'bm_action', 'watchlist_action', 'do', 'task', 'mode'] as $key) {
        if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') return strtolower(trim((string)$_POST[$key]));
        if (isset($_GET[$key]) && trim((string)$_GET[$key]) !== '') return strtolower(trim((string)$_GET[$key]));
    }
    if (isset($_POST['item_link'])) return 'toggle_archive1';
    if (isset($_POST['imdb_code']) || isset($_POST['movie_id'])) return 'toggle';
    return '';
}

function bm_ensure_archive1_watchlist(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        item_link VARCHAR(500) NOT NULL,
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_link (user_id, item_link(200)),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function bm_handle_archive1_watchlist(PDO $pdo, array $currentUser, string $action): void {
    bm_ensure_archive1_watchlist($pdo);

    $userId = (int)$currentUser['id'];
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
    $rawItemLink = bm_security_limit_text($_POST['item_link'] ?? $_POST['link'] ?? $_POST['url'] ?? $_GET['item_link'] ?? '', 500);
    $itemLink = bm_security_safe_navigation_url($rawItemLink, true);

    if (in_array($action, ['remove', 'delete', 'remove_archive1'], true)) {
        if ($id > 0) {
            $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND id = ?");
            $stmt->execute([$userId, $id]);
            bm_json(['success' => true, 'added' => false, 'message' => 'removed']);
        }
        if ($rawItemLink !== '') {
            $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND item_link = ?");
            $stmt->execute([$userId, $rawItemLink]);
            bm_json(['success' => true, 'added' => false, 'message' => 'removed']);
        }
        bm_json(['success' => false, 'error' => 'Archive1 watchlist id or link required']);
    }

    if ($itemLink === '') {
        bm_json(['success' => false, 'error' => 'Archive1 item_link is invalid']);
    }

    $stmt = $pdo->prepare("SELECT id FROM archive1_watchlist WHERE user_id = ? AND item_link = ? LIMIT 1");
    $stmt->execute([$userId, $itemLink]);
    $existingId = (int)($stmt->fetchColumn() ?: 0);

    if (in_array($action, ['toggle', 'toggle_archive1'], true) && $existingId > 0) {
        $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND id = ?");
        $stmt->execute([$userId, $existingId]);
        bm_json(['success' => true, 'added' => false, 'id' => $existingId, 'message' => 'removed']);
    }

    if ($existingId > 0) {
        bm_json(['success' => true, 'added' => true, 'id' => $existingId, 'message' => 'already exists']);
    }

    $stmt = $pdo->prepare("INSERT INTO archive1_watchlist
        (user_id, item_link, item_title, item_title_fa, item_year, item_poster, item_imdb_rate, item_type, added_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([
        $userId,
        $itemLink,
        bm_security_limit_text($_POST['item_title'] ?? $_POST['title'] ?? '', 300),
        bm_security_limit_text($_POST['item_title_fa'] ?? $_POST['title_fa'] ?? $_POST['item_title'] ?? $_POST['title'] ?? '', 300),
        bm_security_safe_year($_POST['item_year'] ?? $_POST['year'] ?? ''),
        bm_security_safe_navigation_url($_POST['item_poster'] ?? $_POST['poster'] ?? '', true),
        bm_security_safe_rating($_POST['item_imdb_rate'] ?? $_POST['rate'] ?? null),
        bm_security_safe_media_type($_POST['item_type'] ?? $_POST['type'] ?? 'movie'),
    ]);
    bm_json(['success' => true, 'added' => true, 'id' => (int)$pdo->lastInsertId(), 'message' => 'added']);
}

try {
    $action = bm_get_action();
    $aliases = [
        'add_watchlist' => 'add',
        'remove_watchlist' => 'remove',
        'delete' => 'remove',
        'status' => 'get_status',
        'get' => 'get_status',
        'check' => 'get_status',
        'toggle_watchlist' => 'toggle',
        'add_archive1' => 'add_archive1',
        'remove_archive1' => 'remove_archive1',
    ];
    if (isset($aliases[$action])) $action = $aliases[$action];

    if ($action === 'get_status') {
        if (!$currentUser) bm_json(['success' => true, 'watchlist' => []]);
        $stmt = $pdo->prepare("SELECT m.imdb_code FROM watchlist w JOIN movies m ON w.movie_id = m.id WHERE w.user_id = ?");
        $stmt->execute([(int)$currentUser['id']]);
        bm_json(['success' => true, 'watchlist' => $stmt->fetchAll(PDO::FETCH_COLUMN)]);
    }

    if (!$currentUser) {
        bm_json(['success' => false, 'error' => 'Please login']);
    }

    bm_require_post(true);
    bm_require_user_csrf(true, true);
    bm_security_enforce_rate_limit('web_watchlist_write', 120, 300, 'user:' . (int)$currentUser['id'], true);

    // اگر فیلدهای آرشیو ۱ ارسال شده باشند، همین فایل هم آن را هندل می‌کند.
    if (isset($_POST['item_link']) || isset($_GET['item_link']) || in_array($action, ['add_archive1','remove_archive1','toggle_archive1'], true)) {
        bm_handle_archive1_watchlist($pdo, $currentUser, $action === 'add_archive1' ? 'add' : ($action === 'remove_archive1' ? 'remove' : $action));
    }

    if (!in_array($action, ['add', 'remove', 'toggle'], true)) {
        // اگر اکشن نیامده ولی imdb_code/movie_id هست، toggle امن‌ترین حالت است.
        if (isset($_POST['imdb_code']) || isset($_POST['movie_id'])) $action = 'toggle';
        else bm_json(['success' => false, 'error' => 'Invalid watchlist request', 'received_action' => $action]);
    }

    $movieId = (int)($_POST['movie_id'] ?? $_GET['movie_id'] ?? 0);
    $imdbCode = trim((string)($_POST['imdb_code'] ?? $_GET['imdb_code'] ?? ''));

    if ($movieId <= 0 && $imdbCode !== '') {
        $stmt = $pdo->prepare("SELECT id FROM movies WHERE imdb_code = ? LIMIT 1");
        $stmt->execute([$imdbCode]);
        $movieId = (int)($stmt->fetchColumn() ?: 0);
    }

    if ($movieId <= 0) {
        bm_json(['success' => false, 'error' => 'Movie not found']);
    }

    $userId = (int)$currentUser['id'];

    if ($action === 'toggle') {
        $stmt = $pdo->prepare("SELECT id FROM watchlist WHERE user_id = ? AND movie_id = ? LIMIT 1");
        $stmt->execute([$userId, $movieId]);
        $exists = (bool)$stmt->fetchColumn();
        $action = $exists ? 'remove' : 'add';
    }

    if ($action === 'add') {
        $stmt = $pdo->prepare("INSERT IGNORE INTO watchlist (user_id, movie_id, added_at) VALUES (?, ?, NOW())");
        $stmt->execute([$userId, $movieId]);
        bm_json(['success' => true, 'added' => true]);
    }

    if ($action === 'remove') {
        $stmt = $pdo->prepare("DELETE FROM watchlist WHERE user_id = ? AND movie_id = ?");
        $stmt->execute([$userId, $movieId]);
        bm_json(['success' => true, 'added' => false]);
    }

    bm_json(['success' => false, 'error' => 'Invalid watchlist request', 'received_action' => $action]);
} catch (PDOException $e) {
    error_log('Watchlist AJAX Error: ' . $e->getMessage());
    bm_json(['success' => false, 'error' => 'Database error']);
} catch (Throwable $e) {
    error_log('Watchlist AJAX Error: ' . $e->getMessage());
    bm_json(['success' => false, 'error' => 'Server error']);
}
