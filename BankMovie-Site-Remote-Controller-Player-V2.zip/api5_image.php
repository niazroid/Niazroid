<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/archive_control.php';

if (!bm_archive_is_enabled('archive2') || !bm_archive_user_can_access('archive2', $currentUser ?? null)) {
    http_response_code(404); exit;
}

$token = trim((string)($_GET['u'] ?? ''));
if ($token === '' || strlen($token) > 4096) { http_response_code(400); exit; }
$pad = strlen($token) % 4;
if ($pad) $token .= str_repeat('=', 4 - $pad);
$url = base64_decode(strtr($token, '-_', '+/'), true);

if (!is_string($url) || !filter_var($url, FILTER_VALIDATE_URL) || !preg_match('~^https?://~i', $url)) {
    http_response_code(400); exit;
}

$source = bm_archive_source_base_url('archive2', 'https://serialblog1.top');
$sourceHost = strtolower((string)(parse_url($source, PHP_URL_HOST) ?: ''));
$urlHost = strtolower((string)(parse_url($url, PHP_URL_HOST) ?: ''));
$allowedHosts = array_values(array_unique(array_filter([$sourceHost, 'serialblog1.top', 'www.serialblog1.top'])));
if (str_starts_with($sourceHost, 'www.')) $allowedHosts[] = substr($sourceHost, 4);
elseif ($sourceHost !== '') $allowedHosts[] = 'www.' . $sourceHost;
$allowed = $urlHost !== '' && in_array($urlHost, $allowedHosts, true);
if (!$allowed) { http_response_code(403); exit; }

$dir = __DIR__ . '/cache/api5_images';
if (!is_dir($dir)) @mkdir($dir, 0775, true);
$key = hash('sha256', $url);
$dataFile = $dir . '/' . $key . '.bin';
$metaFile = $dir . '/' . $key . '.json';

if (is_file($dataFile) && is_file($metaFile) && time() - (int)@filemtime($dataFile) < 2592000) {
    $meta = json_decode((string)@file_get_contents($metaFile), true);
    $type = is_array($meta) ? (string)($meta['type'] ?? 'image/jpeg') : 'image/jpeg';
    header('Content-Type: ' . $type);
    header('Cache-Control: public, max-age=2592000, immutable');
    readfile($dataFile);
    exit;
}

if (!function_exists('curl_init')) { http_response_code(503); exit; }

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL=>$url,
    CURLOPT_RETURNTRANSFER=>true,
    CURLOPT_FOLLOWLOCATION=>true,
    CURLOPT_MAXREDIRS=>4,
    CURLOPT_CONNECTTIMEOUT=>5,
    CURLOPT_TIMEOUT=>12,
    CURLOPT_SSL_VERIFYPEER=>true,
    CURLOPT_SSL_VERIFYHOST=>2,
    CURLOPT_USERAGENT=>'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149 Safari/537.36',
    CURLOPT_REFERER=>rtrim($source,'/').'/',
    CURLOPT_HTTPHEADER=>['Accept: image/avif,image/webp,image/apng,image/*,*/*;q=0.8'],
]);
$body = curl_exec($ch);
$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$type = strtolower(trim((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE)));
curl_close($ch);

if (!is_string($body) || $body === '' || $code < 200 || $code >= 400 || strlen($body) > 8*1024*1024) {
    http_response_code(404); exit;
}
$type = preg_replace('/\s*;.*$/','',$type);
if (!in_array($type,['image/jpeg','image/png','image/webp','image/avif','image/gif'],true)) {
    http_response_code(415); exit;
}

@file_put_contents($dataFile,$body,LOCK_EX);
@file_put_contents($metaFile,json_encode(['type'=>$type],JSON_UNESCAPED_SLASHES),LOCK_EX);
header('Content-Type: '.$type);
header('Cache-Control: public, max-age=2592000, immutable');
echo $body;
