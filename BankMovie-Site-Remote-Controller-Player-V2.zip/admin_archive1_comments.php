<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/sticker_packs.php';
require_admin();
$csrf_token = admin_csrf_token();
admin_enforce_csrf();
function a1_h($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function a1_table_exists(PDO $pdo,string $t):bool{try{$s=$pdo->prepare('SHOW TABLES LIKE ?');$s->execute([$t]);return(bool)$s->fetchColumn();}catch(Throwable $e){return false;}}
$message='';
$exists=a1_table_exists($pdo,'archive1_comments');
if($_SERVER['REQUEST_METHOD']==='POST' && $exists){
  $id=max(0,(int)($_POST['comment_id']??0)); $action=(string)($_POST['comment_action']??'');
  try{
    if($id<1) throw new RuntimeException('شناسه نامعتبر است');
    if($action==='approve') $pdo->prepare("UPDATE archive1_comments SET status='approved' WHERE id=?")->execute([$id]);
    elseif($action==='reject') $pdo->prepare("UPDATE archive1_comments SET status='rejected' WHERE id=?")->execute([$id]);
    elseif($action==='delete'){
      $pdo->beginTransaction();
      if(a1_table_exists($pdo,'archive1_comment_likes')){
        $ids=$pdo->prepare('SELECT id FROM archive1_comments WHERE id=? OR parent_id=?');$ids->execute([$id,$id]);$all=$ids->fetchAll(PDO::FETCH_COLUMN)?:[];
        if($all){$ph=implode(',',array_fill(0,count($all),'?'));$pdo->prepare("DELETE FROM archive1_comment_likes WHERE comment_id IN ($ph)")->execute($all);}
      }
      $pdo->prepare('DELETE FROM archive1_comments WHERE parent_id=?')->execute([$id]);
      $pdo->prepare('DELETE FROM archive1_comments WHERE id=?')->execute([$id]);
      $pdo->commit();
    } else throw new RuntimeException('عملیات نامعتبر است');
    $message='عملیات با موفقیت انجام شد';
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$message='خطا: '.$e->getMessage();}
}
$status=(($_GET['status']??'pending')==='approved')?'approved':'pending';
$rows=[];$pending=0;$approved=0;
if($exists){
  try{$pending=(int)$pdo->query("SELECT COUNT(*) FROM archive1_comments WHERE status='pending'")->fetchColumn();$approved=(int)$pdo->query("SELECT COUNT(*) FROM archive1_comments WHERE status='approved'")->fetchColumn();
    $hasItems=a1_table_exists($pdo,'archive1_items');
    $join=$hasItems?' LEFT JOIN archive1_items ai ON ai.virtual_movie_id=c.movie_id ':'';
    $extra=$hasItems?",ai.archive_no,ai.slug archive_slug,ai.item_type archive_type,COALESCE(NULLIF(ai.item_title_fa,''),NULLIF(ai.item_title,'')) movie_title":",1 archive_no,'' archive_slug,'' archive_type,NULL movie_title";
    $s=$pdo->prepare("SELECT c.*,u.username user_name,u.email {$extra} FROM archive1_comments c {$join} LEFT JOIN users u ON u.id=c.user_id WHERE c.status=? ORDER BY c.created_at DESC LIMIT 300");$s->execute([$status]);$rows=$s->fetchAll(PDO::FETCH_ASSOC)?:[];
    foreach($rows as &$row){$arc=max(1,(int)($row['archive_no']??1));$slug=trim((string)($row['archive_slug']??''));$type=trim((string)($row['archive_type']??''));$row['movie_url']=$slug!==''?('/movie.php?arc='.$arc.'&slug='.rawurlencode($slug).($type!==''?'&type='.rawurlencode($type):'').'#bmMovieComments'):'';if(empty($row['movie_title']))$row['movie_title']='محتوای آرشیو '.$arc;}unset($row);
  }catch(Throwable $e){$message='خطای خواندن: '.$e->getMessage();}
}
?><!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>کامنت‌های آرشیو ۱</title><style>
body{background:#090a0e;color:#eee;font-family:Tahoma,Arial;margin:0;padding:22px}.wrap{max-width:1200px;margin:auto}.bar,.card{background:#15171d;border:1px solid #2a2d36;border-radius:18px;padding:18px;margin-bottom:14px}.tabs{display:flex;gap:10px;flex-wrap:wrap}.btn{display:inline-block;padding:9px 14px;border-radius:10px;border:1px solid #3c4250;color:#fff;text-decoration:none;background:#20242d;cursor:pointer}.ok{border-color:#1f9d63}.bad{border-color:#d94a56}.active{background:#6d34d6}.meta{color:#9ea4b2;font-size:13px}.comment{white-space:pre-wrap;line-height:1.8;margin:10px 0}.row{display:flex;justify-content:space-between;gap:15px;align-items:flex-start;flex-wrap:wrap}form{display:inline}.msg{padding:12px;border-radius:12px;background:#263044;margin-bottom:12px}</style>
<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head><body class="bm-admin-unified"><div class="wrap">
<div class="bar"><div class="row"><div><h2 style="margin:0 0 8px">مدیریت مستقیم کامنت‌های آرشیو ۱</h2><div class="meta">این صفحه مستقیماً جدول archive1_comments را می‌خواند.</div></div><a class="btn" href="admin.php?tab=pending#commentsSection">بازگشت به پنل</a></div></div>
<?php if($message):?><div class="msg"><?=a1_h($message)?></div><?php endif;?>
<?php if(!$exists):?><div class="card">جدول archive1_comments وجود ندارد؛ یعنی هنوز هیچ کامنت آرشیو ۱ در این دیتابیس ثبت نشده است.</div><?php else:?><div class="bar tabs"><a class="btn <?=$status==='pending'?'active':''?>" href="?status=pending">در انتظار (<?=$pending?>)</a><a class="btn <?=$status==='approved'?'active':''?>" href="?status=approved">تأییدشده (<?=$approved?>)</a></div>
<?php foreach($rows as $r):?><div class="card"><div class="row"><div><b><?=a1_h($r['user_name']?:($r['username']??'کاربر'))?></b><div class="meta"><?php if(!empty($r['movie_url'])):?><a class="btn" style="padding:5px 9px;margin-left:7px" target="_blank" rel="noopener" href="<?=a1_h($r['movie_url'])?>">مشاهده و پاسخ</a><?php endif;?><?=a1_h($r['movie_title']??'محتوای مرتبط')?> | <?=a1_h($r['created_at'])?></div></div><div>
<?php if($status==='pending'):?><form method="post"><?=admin_csrf_input()?><input type="hidden" name="comment_id" value="<?=(int)$r['id']?>"><button class="btn ok" name="comment_action" value="approve">تأیید</button></form><form method="post"><?=admin_csrf_input()?><input type="hidden" name="comment_id" value="<?=(int)$r['id']?>"><button class="btn bad" name="comment_action" value="reject">رد</button></form><?php endif;?>
<form method="post" onsubmit="return confirm('حذف شود؟')"><?=admin_csrf_input()?><input type="hidden" name="comment_id" value="<?=(int)$r['id']?>"><button class="btn bad" name="comment_action" value="delete">حذف</button></form></div></div><div class="comment"><?=a1_h(bm_comment_media_admin_label((string)$r['comment']))?></div></div><?php endforeach;?>
<?php if(!$rows):?><div class="card">کامنتی در این وضعیت وجود ندارد.</div><?php endif;?><?php endif;?></div></body></html>