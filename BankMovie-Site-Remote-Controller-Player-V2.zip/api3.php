<?php
/**
 * Compatibility endpoint for older clients.
 * Archive 3 is now served by api6.php.
 */
require __DIR__ . '/api6.php';
