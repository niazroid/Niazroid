Bankmovie V2.1 - Phase 8 Server Patch
=====================================

فایل‌های این پوشه باید در ریشه واقعی سایت (همان جایی که config.php و api_boxoffice.php قرار دارند) جایگزین شوند:
- app_api.php
- app_user_api.php

قبل از جایگزینی از دو فایل فعلی بکاپ بگیرید.

پیش‌نیازهای موجود روی سایت:
- config.php
- includes/api2_lib.php
- includes/api3_lib.php
- includes/security_bootstrap.php
- includes/api6_lib.php
- includes/sticker_packs.php  (برای GIF/Sticker کامنت)

این فایل‌های includes در سورس assets_5 موجود بودند و Patch آن‌ها را overwrite نمی‌کند.

تست Archive 2 بعد از آپلود:
https://bankmovie.top/app_api.php?action=ping&bm_test_key=bm_test_archive2_db_v7_2026

خروجی صحیح باید HTTP 200 و فیلدهای زیر را داشته باشد:
- status: success
- archive2_source: database
- database_ready: true
- database: <نام دیتابیس انتخاب‌شده توسط config.php>
- site_libs.api2: true
- site_libs.api3: true

سپس برای تست واقعی دیتابیس:
https://bankmovie.top/app_api.php?action=section&archive=2&section=new_movies&page=1&limit=12&bm_test_key=bm_test_archive2_db_v7_2026

Archive 2 در این نسخه به Archive 1 fallback نمی‌کند. اگر DB مشکل داشته باشد باید خطا/لیست خالی واقعی دیده شود، نه محتوای تکراری Archive 1.
