<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/sticker_packs.php';

require_admin();
admin_enforce_csrf();

function bm_sticker_admin_h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function bm_sticker_admin_redirect(string $message, string $type = 'success'): never {
    header('Location: admin_stickers.php?flash=' . rawurlencode($message) . '&type=' . rawurlencode($type));
    exit;
}
function bm_sticker_admin_all_items(string $slug, array $pack): array {
    $merged = [];
    foreach (bm_sticker_pack_candidate_paths($slug, $pack) as $candidate) {
        $items = bm_sticker_pack_scan_path($slug, (string)($candidate['path'] ?? ''), (array)($pack['extensions'] ?? []), !empty($candidate['numeric_only']));
        foreach ($items as $item) {
            $key = (string)($item['relative_path'] ?? $item['id'] ?? '');
            if ($key !== '') $merged[$key] = $item;
            if (count($merged) >= 400) break 2;
        }
    }
    return array_values($merged);
}
function bm_sticker_admin_is_path_in_pack(string $relativeFile, array $pack, string $slug = ''): bool {
    $relativeFile = trim(str_replace('\\', '/', $relativeFile), '/');
    if ($relativeFile === '' || str_contains($relativeFile, '..')) return false;
    foreach (bm_sticker_pack_candidate_paths($slug, $pack) as $candidate) {
        $root = bm_sticker_pack_relative_path((string)($candidate['path'] ?? ''));
        if ($root !== '' && str_starts_with($relativeFile, $root . '/')) return true;
    }
    return false;
}
function bm_sticker_admin_upload_is_valid(string $tmp, string $ext): bool {
    if (!is_file($tmp) || !is_readable($tmp)) return false;
    $ext = strtolower($ext);
    if ($ext === 'webm') {
        $fh = @fopen($tmp, 'rb');
        if (!$fh) return false;
        $head = (string)fread($fh, 4);
        fclose($fh);
        // Matroska/WebM EBML header.
        return bin2hex($head) === '1a45dfa3';
    }
    if (in_array($ext, ['webp','gif','png','jpg','jpeg'], true)) {
        $info = @getimagesize($tmp);
        if (!is_array($info) || empty($info['mime'])) return false;
        $mime = strtolower((string)$info['mime']);
        $allowed = [
            'webp'=>['image/webp'],
            'gif'=>['image/gif'],
            'png'=>['image/png'],
            'jpg'=>['image/jpeg'],
            'jpeg'=>['image/jpeg'],
        ];
        return in_array($mime, $allowed[$ext] ?? [], true);
    }
    return false;
}
function bm_sticker_admin_filename(string $name, string $ext): string {
    $base = pathinfo($name, PATHINFO_FILENAME);
    $base = preg_replace('/[^A-Za-z0-9_-]+/', '-', $base) ?? '';
    $base = trim($base, '-_');
    if ($base === '') $base = 'sticker-' . date('Ymd-His');
    return substr($base, 0, 80) . '.' . strtolower($ext);
}

$packs = bm_sticker_pack_registry();
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = strtolower(trim((string)($_POST['action'] ?? '')));
    try {
        if ($action === 'save_pack') {
            $originalSlug = bm_sticker_pack_slug((string)($_POST['original_slug'] ?? ''));
            // Existing slugs stay stable because historical comments/chat markers contain the slug.
            $slug = ($originalSlug !== '' && isset($packs[$originalSlug])) ? $originalSlug : bm_sticker_pack_slug((string)($_POST['slug'] ?? ''));
            if ($slug === '') throw new RuntimeException('شناسه پک معتبر نیست. فقط حروف انگلیسی، عدد، - و _ مجاز است.');
            $label = trim((string)($_POST['label'] ?? ''));
            if ($label === '') throw new RuntimeException('نام نمایشی پک را وارد کن.');
            $path = bm_sticker_pack_relative_path((string)($_POST['path'] ?? ''));
            if ($path === '') throw new RuntimeException('مسیر باید داخل sticker/ یا uploads/ باشد.');
            $extensions = [];
            foreach ((array)($_POST['extensions'] ?? []) as $ext) {
                $ext = strtolower(ltrim(trim((string)$ext), '.'));
                if (in_array($ext, bm_sticker_pack_allowed_extensions(), true)) $extensions[$ext] = true;
            }
            if (!$extensions) throw new RuntimeException('حداقل یک فرمت را انتخاب کن.');
            if ($originalSlug !== '' && $originalSlug !== $slug && isset($packs[$slug])) {
                throw new RuntimeException('پکی با این شناسه از قبل وجود دارد.');
            }
            $existing = ($originalSlug !== '' && isset($packs[$originalSlug])) ? $packs[$originalSlug] : [];
            $next = $existing;
            $next['label'] = $label;
            $next['path'] = $path;
            $next['extensions'] = array_keys($extensions);
            $next['enabled'] = !empty($_POST['enabled']);
            if ($originalSlug !== '' && $originalSlug !== $slug) unset($packs[$originalSlug]);
            $packs[$slug] = $next;
            $dir = bm_sticker_pack_abs_dir($path);
            if ($dir === '') throw new RuntimeException('مسیر پوشه نامعتبر است.');
            if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
                throw new RuntimeException('پوشه ساخته نشد. Permission هاست را بررسی کن.');
            }
            if (!bm_sticker_pack_save_registry($packs)) throw new RuntimeException('تنظیمات پک ذخیره نشد.');
            bm_sticker_admin_redirect('پک «' . $label . '» ذخیره شد و مسیر پوشه آماده است.');
        }
        if ($action === 'delete_pack') {
            $slug = bm_sticker_pack_slug((string)($_POST['slug'] ?? ''));
            if ($slug === '' || !isset($packs[$slug])) throw new RuntimeException('پک پیدا نشد.');
            $label = (string)($packs[$slug]['label'] ?? $slug);
            unset($packs[$slug]);
            if (!bm_sticker_pack_save_registry($packs)) throw new RuntimeException('حذف پک از تنظیمات انجام نشد.');
            bm_sticker_admin_redirect('پک «' . $label . '» از لیست حذف شد؛ فایل‌های پوشه برای امنیت پاک نشدند.');
        }
        if ($action === 'upload_media') {
            $slug = bm_sticker_pack_slug((string)($_POST['slug'] ?? ''));
            $pack = $packs[$slug] ?? null;
            if (!$pack) throw new RuntimeException('پک مقصد پیدا نشد.');
            $file = $_FILES['media_file'] ?? null;
            if (!is_array($file) || (int)($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                throw new RuntimeException('فایل آپلود نشد.');
            }
            $size = (int)($file['size'] ?? 0);
            if ($size < 1 || $size > 12 * 1024 * 1024) throw new RuntimeException('حجم فایل باید کمتر از ۱۲ مگابایت باشد.');
            $original = (string)($file['name'] ?? '');
            $ext = strtolower(pathinfo($original, PATHINFO_EXTENSION));
            if (!in_array($ext, (array)$pack['extensions'], true)) {
                throw new RuntimeException('فرمت این فایل برای پک فعال نیست. اول فرمت را در تنظیمات پک روشن کن.');
            }
            if (!bm_sticker_admin_upload_is_valid((string)$file['tmp_name'], $ext)) {
                throw new RuntimeException('محتوای فایل با فرمت انتخابی سازگار نیست.');
            }
            $dir = bm_sticker_pack_abs_dir((string)$pack['path']);
            if ($dir === '') throw new RuntimeException('مسیر پک نامعتبر است.');
            if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) throw new RuntimeException('پوشه مقصد ساخته نشد.');
            if (!is_writable($dir)) throw new RuntimeException('پوشه مقصد قابل نوشتن نیست. Permission را بررسی کن.');
            $safeName = bm_sticker_admin_filename($original, $ext);
            $base = pathinfo($safeName, PATHINFO_FILENAME);
            $dest = $dir . '/' . $safeName;
            $i = 1;
            while (file_exists($dest) && $i < 1000) {
                $safeName = $base . '-' . $i . '.' . $ext;
                $dest = $dir . '/' . $safeName;
                $i++;
            }
            if (!@move_uploaded_file((string)$file['tmp_name'], $dest)) throw new RuntimeException('انتقال فایل به پوشه پک ناموفق بود.');
            @chmod($dest, 0644);
            bm_sticker_admin_redirect('فایل «' . $safeName . '» به پک «' . (string)$pack['label'] . '» اضافه شد.');
        }
        if ($action === 'delete_media') {
            $slug = bm_sticker_pack_slug((string)($_POST['slug'] ?? ''));
            $pack = $packs[$slug] ?? null;
            if (!$pack) throw new RuntimeException('پک پیدا نشد.');
            $relative = trim(str_replace('\\', '/', (string)($_POST['relative_path'] ?? '')), '/');
            if (!bm_sticker_admin_is_path_in_pack($relative, $pack, $slug)) throw new RuntimeException('مسیر فایل مجاز نیست.');
            $ext = strtolower(pathinfo($relative, PATHINFO_EXTENSION));
            if (!in_array($ext, bm_sticker_pack_allowed_extensions(), true)) throw new RuntimeException('نوع فایل مجاز نیست.');
            $root = realpath(__DIR__);
            $full = realpath(__DIR__ . '/' . $relative);
            if (!$root || !$full || !is_file($full) || !str_starts_with($full, $root . DIRECTORY_SEPARATOR)) {
                throw new RuntimeException('فایل پیدا نشد.');
            }
            if (!@unlink($full)) throw new RuntimeException('فایل حذف نشد. Permission را بررسی کن.');
            bm_sticker_admin_redirect('استیکر/گیف حذف شد.');
        }
    } catch (Throwable $e) {
        bm_sticker_admin_redirect($e->getMessage(), 'error');
    }
}

$packs = bm_sticker_pack_registry(true);
$catalog = bm_sticker_public_catalog();
$flash = trim((string)($_GET['flash'] ?? ''));
$type = ((string)($_GET['type'] ?? 'success')) === 'error' ? 'error' : 'success';
$totalFiles = 0; $enabledCount = 0;
foreach ($packs as $slug => $pack) {
    if (!empty($pack['enabled'])) $enabledCount++;
    $totalFiles += count(bm_sticker_admin_all_items($slug, $pack));
}
$allowedExts = bm_sticker_pack_allowed_extensions();
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>مدیریت استیکر و گیف | BankMovie</title>
<style>
:root{--bg:#060a12;--panel:#0d1421;--panel2:#101a2b;--line:rgba(255,255,255,.09);--text:#f8fbff;--muted:#91a0b7;--accent:#3b82f6;--accent2:#7c3aed;--green:#22c55e;--red:#fb7185;--gold:#fbbf24}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 85% 0,rgba(59,130,246,.16),transparent 32rem),radial-gradient(circle at 10% 15%,rgba(124,58,237,.12),transparent 28rem),var(--bg);color:var(--text);font-family:Tahoma,"Vazirmatn",sans-serif}.shell{display:grid;grid-template-columns:250px 1fr;min-height:100vh}.side{position:sticky;top:0;height:100vh;padding:22px 14px;border-left:1px solid var(--line);background:rgba(6,10,18,.86);backdrop-filter:blur(22px)}.brand{display:flex;align-items:center;gap:10px;padding:6px 8px 24px}.brand-logo{display:grid;place-items:center;width:44px;height:44px;border-radius:15px;background:linear-gradient(135deg,var(--accent),var(--accent2));font-weight:900}.brand b{display:block;font-size:17px}.brand small{color:var(--muted)}.nav{display:grid;gap:7px}.nav a{display:flex;align-items:center;gap:9px;padding:11px 12px;border:1px solid transparent;border-radius:13px;color:#c6d1e1;text-decoration:none;font-size:13px;font-weight:700}.nav a:hover,.nav a.active{border-color:rgba(59,130,246,.28);background:rgba(59,130,246,.1);color:#fff}.main{padding:28px;min-width:0}.hero{position:relative;overflow:hidden;padding:26px;border:1px solid var(--line);border-radius:28px;background:linear-gradient(145deg,rgba(16,26,43,.96),rgba(8,14,25,.9));box-shadow:0 25px 70px rgba(0,0,0,.24)}.hero:after{content:"";position:absolute;width:280px;height:280px;border-radius:50%;left:-100px;top:-160px;background:rgba(59,130,246,.18);filter:blur(5px)}.hero-row{position:relative;z-index:1;display:flex;justify-content:space-between;gap:18px;align-items:flex-start}.hero h1{margin:0 0 8px;font-size:clamp(25px,4vw,38px)}.hero p{margin:0;color:var(--muted);line-height:1.9;max-width:760px}.hero-actions,.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:40px;padding:9px 14px;border:1px solid var(--line);border-radius:12px;background:#101827;color:#fff;text-decoration:none;font:inherit;font-size:12px;font-weight:800;cursor:pointer}.btn.primary{border-color:transparent;background:linear-gradient(135deg,var(--accent),var(--accent2))}.btn.danger{color:#fecdd3;border-color:rgba(251,113,133,.28);background:rgba(251,113,133,.09)}.stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin:18px 0}.stat{padding:16px;border:1px solid var(--line);border-radius:18px;background:rgba(13,20,33,.85)}.stat b{display:block;font-size:25px;margin-bottom:4px}.stat span{color:var(--muted);font-size:12px}.notice{margin:16px 0;padding:13px 15px;border:1px solid rgba(34,197,94,.25);border-radius:14px;background:rgba(34,197,94,.07);color:#bbf7d0}.notice.error{border-color:rgba(251,113,133,.28);background:rgba(251,113,133,.08);color:#fecdd3}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.card{min-width:0;padding:18px;border:1px solid var(--line);border-radius:22px;background:linear-gradient(180deg,rgba(13,20,33,.94),rgba(8,14,25,.94));box-shadow:0 16px 46px rgba(0,0,0,.15)}.card.full{grid-column:1/-1}.card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:15px}.pack-title{display:flex;align-items:center;gap:11px}.pack-avatar{display:grid;place-items:center;width:43px;height:43px;border-radius:14px;background:linear-gradient(135deg,rgba(59,130,246,.22),rgba(124,58,237,.18));border:1px solid rgba(96,165,250,.22);font-weight:900}.card h2,.card h3{margin:0}.card small,.sub{color:var(--muted);line-height:1.8}.badge{display:inline-flex;align-items:center;gap:6px;padding:5px 9px;border-radius:999px;border:1px solid rgba(34,197,94,.22);background:rgba(34,197,94,.07);color:#86efac;font-size:10px;font-weight:900}.badge.off{color:#fda4af;border-color:rgba(251,113,133,.23);background:rgba(251,113,133,.07)}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.field{min-width:0}.field.full{grid-column:1/-1}.field label{display:block;margin-bottom:6px;color:#cbd6e7;font-size:11px;font-weight:800}.input{width:100%;min-height:42px;border:1px solid var(--line);border-radius:12px;background:#070d17;color:#fff;padding:9px 11px;outline:none;font:inherit}.input:focus{border-color:rgba(59,130,246,.55);box-shadow:0 0 0 3px rgba(59,130,246,.08)}.switch-line{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;margin:12px 0;border:1px solid var(--line);border-radius:13px;background:rgba(255,255,255,.02)}.switch-line input{width:18px;height:18px;accent-color:var(--accent)}.exts{display:flex;gap:7px;flex-wrap:wrap}.ext{position:relative}.ext input{position:absolute;opacity:0}.ext span{display:block;padding:7px 10px;border:1px solid var(--line);border-radius:10px;background:#080f1b;color:#9facbf;font-size:10px;font-weight:900;cursor:pointer}.ext input:checked+span{color:#fff;border-color:rgba(59,130,246,.45);background:rgba(59,130,246,.14)}.path{direction:ltr;text-align:left;font:11px/1.7 Consolas,monospace;color:#9cc3ff;overflow-wrap:anywhere}.scan-paths{direction:ltr;text-align:left;margin-top:5px;max-width:520px;color:#71829b;font:9px/1.6 Consolas,monospace;overflow-wrap:anywhere}.media-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(88px,1fr));gap:9px;margin-top:14px}.media{position:relative;aspect-ratio:1;border:1px solid var(--line);border-radius:16px;overflow:hidden;background:#070b12}.media img,.media video{width:100%;height:100%;object-fit:contain;display:block}.media-info{position:absolute;inset:auto 5px 5px 5px;display:flex;gap:4px;justify-content:space-between;align-items:center;padding:4px 6px;border-radius:8px;background:rgba(3,7,14,.75);backdrop-filter:blur(7px);font-size:8px}.media-delete{position:absolute;top:5px;left:5px;z-index:3}.media-delete button{width:27px;height:27px;border:1px solid rgba(251,113,133,.3);border-radius:9px;background:rgba(40,8,15,.88);color:#fecdd3;cursor:pointer}.upload{display:grid;grid-template-columns:1fr auto;gap:9px;margin-top:13px;padding-top:13px;border-top:1px solid var(--line)}.upload input[type=file]{min-width:0;width:100%;border:1px dashed rgba(96,165,250,.25);border-radius:12px;padding:9px;background:rgba(59,130,246,.04);color:#a9b8cb}.new-pack{margin-top:16px}.note{padding:11px 12px;border-radius:13px;border:1px solid rgba(251,191,36,.2);background:rgba(251,191,36,.05);color:#fde68a;font-size:11px;line-height:1.9}@media(max-width:980px){.shell{display:block}.side{position:static;height:auto;border-left:0;border-bottom:1px solid var(--line)}.nav{display:flex;overflow:auto}.nav a{white-space:nowrap}.main{padding:18px}.grid{grid-template-columns:1fr}.card.full{grid-column:auto}}@media(max-width:600px){.main{padding:12px}.hero{padding:19px;border-radius:22px}.hero-row{display:block}.hero-actions{margin-top:14px}.stats{grid-template-columns:1fr}.form-grid{grid-template-columns:1fr}.field.full{grid-column:auto}.upload{grid-template-columns:1fr}.media-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<div class="shell">
<aside class="side">
  <div class="brand"><div class="brand-logo">BM</div><div><b>BankMovie</b><small>پنل مدیریت</small></div></div>
  <nav class="nav">
    <a href="admin.php">⌂ داشبورد اصلی</a>
    <a href="admin_site_manager.php">◫ مدیریت سایت</a>
    <a href="admin_watch_party.php">◉ Watch Party</a>
    <a class="active" href="admin_stickers.php">▣ استیکر و گیف</a>
    <a href="admin_control_center.php?tab=tools">⚙ ابزارها</a>
  </nav>
</aside>
<main class="main">
  <section class="hero">
    <div class="hero-row"><div><h1>مدیریت استیکر و گیف</h1><p>یک منبع مشترک برای Watch Party و دیدگاه‌ها. پک بساز، مسیر پوشه تعیین کن، فرمت‌ها را انتخاب کن و فایل‌ها را مستقیم از پنل اضافه یا حذف کن.</p></div><div class="hero-actions"><a class="btn" href="/" target="_blank">مشاهده سایت</a><a class="btn primary" href="admin.php#commentsSection">دیدگاه‌ها</a></div></div>
  </section>
  <div class="stats"><div class="stat"><b><?= count($packs) ?></b><span>پک تعریف‌شده</span></div><div class="stat"><b><?= (int)$enabledCount ?></b><span>پک فعال</span></div><div class="stat"><b><?= (int)$totalFiles ?></b><span>استیکر / گیف قابل استفاده</span></div></div>
  <?php if ($flash !== ''): ?><div class="notice <?= $type==='error'?'error':'' ?>"><?= bm_sticker_admin_h($flash) ?></div><?php endif; ?>
  <div class="note">استیکر و گیف در دیدگاه‌ها و پاسخ‌ها برای همه کاربران آزاد است. Watch Party همچنان قوانین دسترسی VIP خودش را دارد و همین لیست پک را می‌خواند. حذف «پک» فقط تنظیمات را پاک می‌کند؛ حذف فایل از کارت رسانه، خود فایل را واقعاً حذف می‌کند.</div>
  <div class="grid" style="margin-top:16px">
  <?php foreach ($packs as $slug => $pack): $items=bm_sticker_admin_all_items($slug,$pack); ?>
    <section class="card">
      <div class="card-head"><div class="pack-title"><div class="pack-avatar"><?= bm_sticker_admin_h(strtoupper(substr($slug,0,2))) ?></div><div><h2><?= bm_sticker_admin_h($pack['label']) ?></h2><small><?= count($items) ?> فایل · <span class="path"><?= bm_sticker_admin_h($pack['path']) ?></span></small><div class="scan-paths">جستجوی خودکار: <?php $scanPaths=array_map(static fn($c)=>(string)($c['path']??''),bm_sticker_pack_candidate_paths($slug,$pack)); ?><?= bm_sticker_admin_h(implode(' · ',$scanPaths)) ?></div></div></div><span class="badge <?= !empty($pack['enabled'])?'':'off' ?>"><?= !empty($pack['enabled'])?'فعال':'غیرفعال' ?></span></div>
      <form method="post">
        <?= admin_csrf_input() ?><input type="hidden" name="action" value="save_pack"><input type="hidden" name="original_slug" value="<?= bm_sticker_admin_h($slug) ?>">
        <div class="form-grid"><div class="field"><label>شناسه پک</label><input class="input" dir="ltr" name="slug" value="<?= bm_sticker_admin_h($slug) ?>" readonly title="شناسه پک بعد از ساخت ثابت می‌ماند تا استیکرهای قدیمی خراب نشوند"></div><div class="field"><label>نام نمایشی</label><input class="input" name="label" value="<?= bm_sticker_admin_h($pack['label']) ?>" required></div><div class="field full"><label>مسیر پوشه</label><input class="input" dir="ltr" name="path" value="<?= bm_sticker_admin_h($pack['path']) ?>" placeholder="sticker/pepe" required></div></div>
        <div class="switch-line"><div><b>پک فعال باشد</b><div class="sub">در دیدگاه‌های عمومی و چت Watch Party قابل انتخاب باشد.</div></div><input type="checkbox" name="enabled" value="1" <?= !empty($pack['enabled'])?'checked':'' ?>></div>
        <div class="field"><label>فرمت‌های قابل قبول</label><div class="exts"><?php foreach($allowedExts as $ext): ?><label class="ext"><input type="checkbox" name="extensions[]" value="<?= bm_sticker_admin_h($ext) ?>" <?= in_array($ext,(array)$pack['extensions'],true)?'checked':'' ?>><span>.<?= bm_sticker_admin_h($ext) ?></span></label><?php endforeach; ?></div></div>
        <div class="actions" style="margin-top:13px"><button class="btn primary" type="submit">ذخیره پک</button></div>
      </form>
      <form method="post" enctype="multipart/form-data" class="upload">
        <?= admin_csrf_input() ?><input type="hidden" name="action" value="upload_media"><input type="hidden" name="slug" value="<?= bm_sticker_admin_h($slug) ?>"><input type="file" name="media_file" accept=".webm,.webp,.gif,.png,.jpg,.jpeg" required><button class="btn" type="submit">+ افزودن فایل</button>
      </form>
      <?php if ($items): ?><div class="media-grid">
        <?php foreach($items as $item): ?><div class="media">
          <?php if(($item['media_type']??'image')==='video'): ?><video src="<?= bm_sticker_admin_h($item['url']) ?>" autoplay loop muted playsinline preload="metadata"></video><?php else: ?><img src="<?= bm_sticker_admin_h($item['url']) ?>" loading="lazy" alt=""><?php endif; ?>
          <form method="post" class="media-delete" onsubmit="return confirm('این فایل واقعاً از هاست حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="action" value="delete_media"><input type="hidden" name="slug" value="<?= bm_sticker_admin_h($slug) ?>"><input type="hidden" name="relative_path" value="<?= bm_sticker_admin_h($item['relative_path']) ?>"><button title="حذف فایل" type="submit">×</button></form>
          <div class="media-info"><span><?= bm_sticker_admin_h($item['name']) ?></span><span><?= number_format(((int)$item['bytes'])/1024,0) ?>K</span></div>
        </div><?php endforeach; ?>
      </div><?php else: ?><p class="sub" style="margin-top:14px">هنوز فایل قابل استفاده پیدا نشد. پوشه اصلی، مسیرهای uploads و تا ۳ سطح پوشه داخلیِ فایل ZIP به‌صورت خودکار اسکن می‌شوند.</p><?php endif; ?>
      <form method="post" style="margin-top:14px" onsubmit="return confirm('پک از لیست مدیریت حذف شود؟ فایل‌های پوشه پاک نمی‌شوند.')"><?= admin_csrf_input() ?><input type="hidden" name="action" value="delete_pack"><input type="hidden" name="slug" value="<?= bm_sticker_admin_h($slug) ?>"><button class="btn danger" type="submit">حذف پک از تنظیمات</button></form>
    </section>
  <?php endforeach; ?>
  </div>

  <section class="card full new-pack">
    <div class="card-head"><div><h3>افزودن پک / مسیر پوشه جدید</h3><div class="sub">مثال: شناسه <span class="path">love</span> و مسیر <span class="path">sticker/love</span>. اگر پوشه وجود نداشته باشد، پنل آن را می‌سازد.</div></div></div>
    <form method="post">
      <?= admin_csrf_input() ?><input type="hidden" name="action" value="save_pack">
      <div class="form-grid"><div class="field"><label>شناسه انگلیسی</label><input class="input" dir="ltr" name="slug" placeholder="love" required></div><div class="field"><label>نام نمایشی</label><input class="input" name="label" placeholder="Love" required></div><div class="field full"><label>مسیر پوشه</label><input class="input" dir="ltr" name="path" placeholder="sticker/love" required></div></div>
      <div class="switch-line"><div><b>از همین الان فعال</b><div class="sub">اگر خاموش باشد در سایت دیده نمی‌شود.</div></div><input type="checkbox" name="enabled" value="1" checked></div>
      <div class="field"><label>فرمت‌ها</label><div class="exts"><?php foreach($allowedExts as $ext): ?><label class="ext"><input type="checkbox" name="extensions[]" value="<?= bm_sticker_admin_h($ext) ?>" <?= in_array($ext,['webm','webp','gif'],true)?'checked':'' ?>><span>.<?= bm_sticker_admin_h($ext) ?></span></label><?php endforeach; ?></div></div>
      <div class="actions" style="margin-top:14px"><button class="btn primary" type="submit">ساخت و اضافه‌کردن پک</button></div>
    </form>
  </section>
</main>
</div>
</body>
</html>
