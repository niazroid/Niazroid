<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/bm_private_cleanup.php';

$isCli = PHP_SAPI === 'cli';
if (!$isCli) {
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
        header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    }
    $expected = function_exists('bm_security_secret')
        ? bm_security_secret('maintenance_cron_token', 'BANKMOVIE_MAINTENANCE_CRON_TOKEN')
        : '';
    $provided = trim((string)($_SERVER['HTTP_X_CRON_TOKEN'] ?? $_GET['token'] ?? ''));
    if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'not_found'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

$result = bm_private_cleanup_run(true);
if ($isCli) {
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT) . PHP_EOL;
} else {
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
