<?php
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
$adminPanelHealth = admin_panel_bootstrap($pdo);
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

$message = trim((string)($_GET['msg'] ?? ''));
$error = trim((string)($_GET['error'] ?? ''));

function admin_slider_redirect(string $message = '', string $error = ''): never {
  $params = [];
  if($message !== '') $params['msg'] = $message;
  if($error !== '') $params['error'] = $error;
  header('Location: admin_slider.php' . ($params ? '?' . http_build_query($params) : ''));
  exit;
}

function admin_slider_reindex(PDO $pdo): void {
  $ids = $pdo->query("SELECT id FROM slider_slides ORDER BY slide_order ASC, id ASC")->fetchAll(PDO::FETCH_COLUMN) ?: [];
  $stmt = $pdo->prepare("UPDATE slider_slides SET slide_order = ? WHERE id = ?");
  foreach($ids as $index => $id) $stmt->execute([(int)$index, (int)$id]);
}

/**
 * Keep slider CRUD compatible with legacy databases where timestamp or
 * optional presentation columns may not exist and ALTER permission is absent.
 */
function admin_slider_existing_columns(PDO $pdo): array {
  static $columns = null;
  if(is_array($columns)) return $columns;
  $columns = [];
  try {
    foreach($pdo->query("SHOW COLUMNS FROM slider_slides")->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row){
      $name = (string)($row['Field'] ?? '');
      if($name !== '') $columns[$name] = true;
    }
  } catch(Throwable $e) {
    // The normal query below will return the actual database error if the table is unavailable.
  }
  return $columns;
}

function admin_slider_has_column(PDO $pdo, string $column): bool {
  return isset(admin_slider_existing_columns($pdo)[$column]);
}

function admin_slider_insert(PDO $pdo, array $payload): void {
  $columns = [];
  $values = [];
  $params = [];
  foreach($payload as $column => $value){
    if(!admin_slider_has_column($pdo, (string)$column)) continue;
    $columns[] = '`' . $column . '`';
    $values[] = '?';
    $params[] = $value;
  }
  if(admin_slider_has_column($pdo, 'created_at')){
    $columns[] = '`created_at`';
    $values[] = 'NOW()';
  }
  if(admin_slider_has_column($pdo, 'updated_at')){
    $columns[] = '`updated_at`';
    $values[] = 'NOW()';
  }
  if(!$columns) throw new RuntimeException('ساختار جدول اسلایدر معتبر نیست.');
  $sql = 'INSERT INTO slider_slides (' . implode(', ', $columns) . ') VALUES (' . implode(', ', $values) . ')';
  $pdo->prepare($sql)->execute($params);
}

function admin_slider_update(PDO $pdo, int $id, array $payload): void {
  $sets = [];
  $params = [];
  foreach($payload as $column => $value){
    if(!admin_slider_has_column($pdo, (string)$column)) continue;
    $sets[] = '`' . $column . '` = ?';
    $params[] = $value;
  }
  if(admin_slider_has_column($pdo, 'updated_at')) $sets[] = '`updated_at` = NOW()';
  if(!$sets) throw new RuntimeException('هیچ ستون قابل ذخیره‌ای در جدول اسلایدر پیدا نشد.');
  $params[] = $id;
  $stmt = $pdo->prepare('UPDATE slider_slides SET ' . implode(', ', $sets) . ' WHERE id = ?');
  $stmt->execute($params);
  if($stmt->rowCount() < 1){
    $check = $pdo->prepare('SELECT id FROM slider_slides WHERE id = ?');
    $check->execute([$id]);
    if(!$check->fetchColumn()) throw new RuntimeException('اسلاید موردنظر پیدا نشد.');
  }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
  $action = (string)$_POST['action'];

  if($action === 'reorder'){
    header('Content-Type: application/json; charset=utf-8');
    $orderData = json_decode((string)($_POST['order'] ?? '[]'), true);
    if(!is_array($orderData) || !$orderData){
      echo json_encode(['status'=>'error','message'=>'ترتیب ارسال‌شده معتبر نیست'], JSON_UNESCAPED_UNICODE); exit;
    }
    try {
      $pdo->beginTransaction();
      $stmt = $pdo->prepare("UPDATE slider_slides SET slide_order = ? WHERE id = ?");
      foreach(array_values(array_unique(array_map('intval', $orderData))) as $index => $slideId){
        if($slideId > 0) $stmt->execute([(int)$index, $slideId]);
      }
      $pdo->commit();
      echo json_encode(['status'=>'ok'], JSON_UNESCAPED_UNICODE); exit;
    } catch(Throwable $e){
      if($pdo->inTransaction()) $pdo->rollBack();
      http_response_code(500);
      echo json_encode(['status'=>'error','message'=>'ذخیره ترتیب انجام نشد: '.$e->getMessage()], JSON_UNESCAPED_UNICODE); exit;
    }
  }

  try {
    if($action === 'add' || $action === 'edit'){
      $id = (int)($_POST['id'] ?? 0);
      $title_fa = trim((string)($_POST['title_fa'] ?? ''));
      $title_en = trim((string)($_POST['title_en'] ?? ''));
      $subtitle_fa = trim((string)($_POST['subtitle_fa'] ?? ''));
      $subtitle_en = trim((string)($_POST['subtitle_en'] ?? ''));
      $link = trim((string)($_POST['link'] ?? ''));
      $order = max(0, (int)($_POST['slide_order'] ?? 0));
      $is_active = isset($_POST['is_active']) ? 1 : 0;
      $rating = max(0, min(10, (float)($_POST['rating'] ?? 0)));
      $votes = trim((string)($_POST['votes'] ?? ''));

      if($link !== ''){
        $safeLink = admin_safe_destination_url($link);
        if($safeLink === '') throw new RuntimeException('لینک اسلاید معتبر نیست.');
        $link = $safeLink;
      }

      $oldPath = '';
      if($action === 'edit'){
        if($id <= 0) throw new RuntimeException('شناسه اسلاید نامعتبر است.');
        $stmt = $pdo->prepare("SELECT image_path FROM slider_slides WHERE id = ?");
        $stmt->execute([$id]);
        $oldValue = $stmt->fetchColumn();
        if($oldValue === false) throw new RuntimeException('اسلاید موردنظر پیدا نشد.');
        $oldPath = (string)($oldValue ?: '');
      }

      $imagePath = null;
      if(isset($_FILES['image']) && (int)($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
        $uploadError = (int)($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE);
        if($uploadError !== UPLOAD_ERR_OK) throw new RuntimeException(admin_panel_upload_error_message($uploadError));
        $imagePath = admin_safe_image_upload($_FILES['image'], 'uploads/slider/', 'slide_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)), 86, 10*1024*1024);
      }
      if($action === 'add' && !$imagePath) throw new RuntimeException('برای اسلاید جدید تصویر انتخاب کنید.');
      if($action === 'edit' && !$imagePath && $oldPath === '') throw new RuntimeException('این اسلاید تصویر ندارد؛ برای ذخیره یک تصویر انتخاب کنید.');

      $pdo->beginTransaction();
      if($action === 'add'){
        $pdo->exec("UPDATE slider_slides SET slide_order = slide_order + 1");
        admin_slider_insert($pdo, [
          'image_path' => $imagePath,
          'title_fa' => $title_fa,
          'title_en' => $title_en,
          'subtitle_fa' => $subtitle_fa,
          'subtitle_en' => $subtitle_en,
          'link' => $link,
          'slide_order' => 0,
          'is_active' => $is_active,
          'rating' => $rating,
          'votes' => $votes,
        ]);
      } else {
        $payload = [
          'title_fa' => $title_fa,
          'title_en' => $title_en,
          'subtitle_fa' => $subtitle_fa,
          'subtitle_en' => $subtitle_en,
          'link' => $link,
          'slide_order' => $order,
          'is_active' => $is_active,
          'rating' => $rating,
          'votes' => $votes,
        ];
        if($imagePath) $payload = ['image_path' => $imagePath] + $payload;
        admin_slider_update($pdo, $id, $payload);
      }
      admin_slider_reindex($pdo);
      $pdo->commit();

      if($imagePath && $oldPath && $oldPath !== $imagePath) admin_safe_unlink($oldPath, ['uploads/slider/']);
      admin_slider_redirect($action === 'add' ? 'اسلاید جدید با موفقیت اضافه شد' : 'اسلاید با موفقیت ویرایش شد');
    }

    if($action === 'delete'){
      $id = (int)($_POST['id'] ?? 0);
      if($id <= 0) throw new RuntimeException('شناسه اسلاید نامعتبر است.');
      $stmt = $pdo->prepare("SELECT image_path FROM slider_slides WHERE id = ?");
      $stmt->execute([$id]);
      $pathValue = $stmt->fetchColumn();
      if($pathValue === false) throw new RuntimeException('اسلاید موردنظر پیدا نشد.');
      $path = (string)($pathValue ?: '');
      $pdo->beginTransaction();
      $pdo->prepare("DELETE FROM slider_slides WHERE id = ?")->execute([$id]);
      admin_slider_reindex($pdo);
      $pdo->commit();
      admin_safe_unlink($path, ['uploads/slider/']);
      admin_slider_redirect('اسلاید با موفقیت حذف شد');
    }

    if($action === 'toggle'){
      $id = (int)($_POST['id'] ?? 0);
      if($id <= 0) throw new RuntimeException('شناسه اسلاید نامعتبر است.');
      $touch = admin_slider_has_column($pdo, 'updated_at') ? ', updated_at=NOW()' : '';
      $stmt = $pdo->prepare("UPDATE slider_slides SET is_active = IF(is_active=1,0,1){$touch} WHERE id = ?");
      $stmt->execute([$id]);
      if($stmt->rowCount() < 1) throw new RuntimeException('اسلاید موردنظر پیدا نشد.');
      admin_slider_redirect('وضعیت اسلاید تغییر کرد');
    }

    if($action === 'move_up' || $action === 'move_down'){
      $id = (int)($_POST['id'] ?? 0);
      $ids = $pdo->query("SELECT id FROM slider_slides ORDER BY slide_order ASC, id ASC")->fetchAll(PDO::FETCH_COLUMN) ?: [];
      $ids = array_map('intval', $ids);
      $pos = array_search($id, $ids, true);
      if($pos !== false){
        $target = $action === 'move_up' ? $pos - 1 : $pos + 1;
        if(isset($ids[$target])) [$ids[$pos], $ids[$target]] = [$ids[$target], $ids[$pos]];
        $pdo->beginTransaction();
        $stmt = $pdo->prepare("UPDATE slider_slides SET slide_order = ? WHERE id = ?");
        foreach($ids as $index => $slideId) $stmt->execute([$index, $slideId]);
        $pdo->commit();
      }
      admin_slider_redirect('ترتیب اسلایدها ذخیره شد');
    }
  } catch(Throwable $e){
    if($pdo->inTransaction()) $pdo->rollBack();
    if(isset($imagePath) && $imagePath && (!isset($oldPath) || $imagePath !== $oldPath)) admin_safe_unlink($imagePath, ['uploads/slider/']);
    admin_slider_redirect('', $e->getMessage());
  }
}

$slides = $pdo->query("SELECT * FROM slider_slides ORDER BY slide_order ASC, id ASC")->fetchAll();
$editSlide = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $stmt = $pdo->prepare("SELECT * FROM slider_slides WHERE id=?");
  $stmt->execute([$id]);
  $editSlide = $stmt->fetch() ?: null;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مدیریت اسلایدر - کشیدن و رها کردن | بانک مووی</title>
  <style>
    /* ========== BankMovie Pro UI (without emojis) ========== */
    :root {
      --pro-bg: #07090d;
      --pro-surface: rgba(18,22,30,.78);
      --pro-border: rgba(255,255,255,.09);
      --pro-border-strong: rgba(54,255,159,.32);
      --pro-text: #f7fbff;
      --pro-muted: #9aa6b5;
      --pro-accent: #36ff9f;
      --pro-accent-2: #38bdf8;
      --pro-danger: #fb7185;
      --pro-radius: 26px;
      --pro-shadow: 0 28px 80px rgba(0,0,0,.42);
    }
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: radial-gradient(circle at 85% -5%, rgba(54,255,159,.12), transparent 34%),
                  radial-gradient(circle at 5% 15%, rgba(56,189,248,.10), transparent 32%),
                  linear-gradient(180deg,#090b10,#050609 72%);
      color: var(--pro-text);
      font-family: 'Inter', system-ui, -apple-system, sans-serif;
      padding: 24px;
      min-height: 100vh;
    }
    .container { max-width: 1440px; margin: 0 auto; }
    .admin-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 32px;
      padding: 20px 28px;
      background: linear-gradient(145deg,rgba(20,25,34,.86),rgba(9,12,18,.78));
      backdrop-filter: blur(24px);
      border: 1px solid var(--pro-border);
      border-radius: 32px;
      flex-wrap: wrap;
      gap: 16px;
    }
    .logo-area { display: flex; align-items: center; gap: 12px; }
    .logo-icon svg { width: 32px; height: 32px; stroke: var(--pro-accent); }
    .logo-text { font-size: 24px; font-weight: 700; background: linear-gradient(135deg, #fff, var(--pro-accent)); -webkit-background-clip: text; background-clip: text; color: transparent; }
    .nav-links { display: flex; gap: 12px; }
    .nav-link {
      background: rgba(255,255,255,.065);
      border: 1px solid var(--pro-border);
      border-radius: 40px;
      padding: 8px 20px;
      color: var(--pro-text);
      text-decoration: none;
      font-size: 14px;
      transition: 0.2s;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    .nav-link:hover { background: rgba(54,255,159,.1); border-color: var(--pro-accent); }
    .card {
      background: linear-gradient(145deg,rgba(20,25,34,.86),rgba(9,12,18,.78));
      backdrop-filter: blur(24px);
      border: 1px solid var(--pro-border);
      border-radius: 32px;
      padding: 28px;
      margin-bottom: 32px;
    }
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 24px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--pro-border);
    }
    .card-header h3 { font-size: 20px; font-weight: 600; color: var(--pro-accent); }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; }
    .form-group { display: flex; flex-direction: column; gap: 8px; }
    .full-width { grid-column: 1 / -1; }
    label { font-size: 13px; font-weight: 500; color: var(--pro-muted); }
    input, textarea, select {
      background: rgba(4,7,12,.72);
      border: 1px solid var(--pro-border);
      border-radius: 18px;
      padding: 12px 16px;
      color: var(--pro-text);
      font-size: 14px;
      outline: none;
    }
    input:focus, textarea:focus, select:focus { border-color: var(--pro-accent); box-shadow: 0 0 0 2px rgba(54,255,159,.2); }
    .checkbox-group { flex-direction: row; align-items: center; gap: 12px; }
    button, .btn {
      background: linear-gradient(135deg, var(--pro-accent), #7dd3fc);
      border: none;
      border-radius: 40px;
      padding: 10px 24px;
      font-weight: 600;
      color: #03110a;
      cursor: pointer;
      transition: 0.2s;
      display: inline-flex;
      align-items: center;
      gap: 8px;
    }
    button:hover, .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 24px rgba(54,255,159,.3); }
    .btn-secondary {
      background: rgba(255,255,255,.08);
      color: var(--pro-text);
      border: 1px solid var(--pro-border);
    }
    .btn-danger {
      background: rgba(251,113,133,.12);
      color: #fb7185;
      border: 1px solid rgba(251,113,133,.3);
    }
    .table-responsive { overflow-x: auto; }
    table { width: 100%; border-collapse: separate; border-spacing: 0 8px; }
    th, td { padding: 14px 16px; text-align: right; vertical-align: middle; }
    th { color: var(--pro-accent); font-weight: 500; background: rgba(255,255,255,.03); border-radius: 20px 20px 0 0; }
    tbody tr {
      background: rgba(255,255,255,.035);
      transition: 0.2s;
      cursor: grab;
    }
    tbody tr:active { cursor: grabbing; }
    tbody tr:hover { background: rgba(54,255,159,.08); }
    .slide-preview { width: 80px; height: 50px; object-fit: cover; border-radius: 12px; background: #1e1e24; }
    .badge {
      display: inline-block;
      padding: 4px 12px;
      border-radius: 30px;
      font-size: 12px;
      font-weight: 600;
    }
    .badge-active { background: rgba(54,255,159,.2); color: #36ff9f; }
    .badge-inactive { background: rgba(255,94,107,.2); color: #ff8a98; }
    .rating-badge {
      background: rgba(0,0,0,.6);
      padding: 4px 10px;
      border-radius: 30px;
      font-size: 12px;
      display: inline-flex;
      align-items: center;
      gap: 5px;
    }
    .drag-handle {
      cursor: grab;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 4px;
    }
    .drag-handle svg { width: 20px; height: 20px; stroke: var(--pro-muted); }
    .action-buttons { display: flex; gap: 8px; flex-wrap: wrap; }
    .alert {
      padding: 14px 20px;
      border-radius: 20px;
      margin-bottom: 20px;
      background: rgba(0,0,0,.4);
      border-right: 3px solid;
    }
    .alert-success { border-right-color: var(--pro-accent); color: var(--pro-accent); }
    .alert-error { border-right-color: var(--pro-danger); color: #fb7185; }
    @media (max-width: 768px) {
      body { padding: 16px; }
      .card { padding: 20px; }
      .slide-preview { width: 60px; height: 40px; }
    }
  </style>
  <!-- SortableJS for drag & drop -->
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<div class="container">
  <div class="admin-header">
    <div class="logo-area">
      <div class="logo-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <rect x="3" y="5" width="18" height="14" rx="2"/>
          <path d="M8 13l2.5-2.5L14 14l2-2 3 3"/>
          <circle cx="9" cy="9" r="1"/>
        </svg>
      </div>
      <div class="logo-text">مدیریت اسلایدر</div>
    </div>
    <div class="nav-links">
      <a href="admin_collections.php" class="nav-link">مدیریت کالکشن‌ها</a>
      <a href="admin.php" class="nav-link">بازگشت به پنل</a>
    </div>
  </div>
  <?php $bmSlideTotal=count($slides); $bmSlideActive=count(array_filter($slides,static fn($s)=>!empty($s['is_active']))); ?>
  <div class="bm-admin-kpis">
    <div class="bm-admin-kpi"><small>کل اسلایدها</small><strong><?= $bmSlideTotal ?></strong></div>
    <div class="bm-admin-kpi"><small>اسلاید فعال</small><strong><?= $bmSlideActive ?></strong></div>
    <div class="bm-admin-kpi"><small>اسلاید غیرفعال</small><strong><?= max(0,$bmSlideTotal-$bmSlideActive) ?></strong></div>
    <div class="bm-admin-kpi"><small>ترتیب نمایش</small><strong style="font-size:15px">Drag & Drop</strong></div>
  </div>

  <?php if ($message): ?><div class="alert alert-success"><?= admin_escape($message) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-error"><?= admin_escape($error) ?></div><?php endif; ?>

  <!-- فرم افزودن / ویرایش -->
  <div class="card">
    <div class="card-header"><h3><?= $editSlide ? 'ویرایش اسلاید' : 'افزودن اسلاید جدید (اولین می‌شود)' ?></h3></div>
    <form method="post" enctype="multipart/form-data">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="action" value="<?= $editSlide ? 'edit' : 'add' ?>">
      <?php if ($editSlide): ?><input type="hidden" name="id" value="<?= $editSlide['id'] ?>"><?php endif; ?>
      
      <div class="form-grid">
        <div class="form-group">
          <label>تصویر اسلاید *</label>
          <input type="file" name="image" accept="image/jpeg,image/png,image/webp" <?= $editSlide ? '' : 'required' ?>>
          <?php if ($editSlide && $editSlide['image_path']): ?>
            <div style="margin-top: 8px;"><img src="<?= htmlspecialchars($editSlide['image_path']) ?>" style="width:100px; border-radius:12px;"></div>
          <?php endif; ?>
        </div>
        <div class="form-group"><label>عنوان (فارسی)</label><input type="text" name="title_fa" value="<?= $editSlide ? htmlspecialchars($editSlide['title_fa']) : '' ?>"></div>
        <div class="form-group"><label>عنوان (انگلیسی)</label><input type="text" name="title_en" value="<?= $editSlide ? htmlspecialchars($editSlide['title_en']) : '' ?>"></div>
        <div class="form-group"><label>امتیاز IMDb</label><input type="number" step="0.1" name="rating" value="<?= $editSlide ? htmlspecialchars($editSlide['rating']) : '8.5' ?>"></div>
        <div class="form-group"><label>تعداد رأی</label><input type="text" name="votes" value="<?= $editSlide ? htmlspecialchars($editSlide['votes']) : '1.2M' ?>"></div>
        <div class="form-group full-width"><label>زیرنویس (فارسی)</label><textarea name="subtitle_fa"><?= $editSlide ? htmlspecialchars($editSlide['subtitle_fa']) : '' ?></textarea></div>
        <div class="form-group full-width"><label>زیرنویس (انگلیسی)</label><textarea name="subtitle_en"><?= $editSlide ? htmlspecialchars($editSlide['subtitle_en']) : '' ?></textarea></div>
        <div class="form-group"><label>لینک (اختیاری)</label><input type="text" name="link" placeholder="/movie/slug یا https://example.com" value="<?= $editSlide ? htmlspecialchars($editSlide['link']) : '' ?>"></div>
        <div class="form-group"><label>ترتیب دستی (اختیاری)</label><input type="number" name="slide_order" value="<?= $editSlide ? $editSlide['slide_order'] : '0' ?>"><small>برای جابجایی، ردیف را بکشید و رها کنید</small></div>
        <div class="form-group checkbox-group"><input type="checkbox" name="is_active" id="is_active" <?= ($editSlide && $editSlide['is_active']) || !$editSlide ? 'checked' : '' ?>><label for="is_active">فعال</label></div>
      </div>
      <div style="display: flex; gap: 12px; margin-top: 24px;">
        <button type="submit">ذخیره اسلاید</button>
        <?php if ($editSlide): ?><a href="admin_slider.php" class="btn btn-secondary">انصراف</a><?php endif; ?>
      </div>
    </form>
  </div>

  <!-- لیست اسلایدها با قابلیت کشیدن -->
  <div class="card">
    <div class="card-header"><h3>ترتیب اسلایدها (بکشید و جابجا کنید)</h3></div>
    <div class="table-responsive">
      <table id="slides-table">
        <thead>
          <tr><th style="width: 40px;"></th><th>تصویر</th><th>عنوان</th><th>امتیاز / رأی</th><th>وضعیت</th><th>عملیات</th></tr>
        </thead>
        <tbody id="sortable-body">
          <?php foreach ($slides as $slide): ?>
          <tr data-id="<?= $slide['id'] ?>">
            <td class="drag-handle">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                <circle cx="9" cy="12" r="1.5"/>
                <circle cx="15" cy="12" r="1.5"/>
                <circle cx="9" cy="18" r="1.5"/>
                <circle cx="15" cy="18" r="1.5"/>
                <circle cx="9" cy="6" r="1.5"/>
                <circle cx="15" cy="6" r="1.5"/>
              </svg>
            </td>
            <td><img class="slide-preview" src="<?= htmlspecialchars($slide['image_path']) ?>" loading="lazy"></td>
            <td><?= htmlspecialchars($slide['title_fa'] ?: $slide['title_en']) ?></td>
            <td><span class="rating-badge"><?= number_format($slide['rating'], 1) ?> /10 (<?= htmlspecialchars($slide['votes']) ?>)</span></td>
            <td><span class="badge <?= $slide['is_active'] ? 'badge-active' : 'badge-inactive' ?>"><?= $slide['is_active'] ? 'فعال' : 'غیرفعال' ?></span></td>
            <td class="action-buttons">
              <a href="?edit=<?= (int)$slide['id'] ?>" class="btn btn-secondary">ویرایش</a>
              <form method="post" style="display:inline;">
                <?= admin_csrf_input() ?>
                <input type="hidden" name="action" value="toggle">
                <input type="hidden" name="id" value="<?= (int)$slide['id'] ?>">
                <button type="submit" class="btn btn-secondary"><?= $slide['is_active'] ? 'غیرفعال‌کردن' : 'فعال‌کردن' ?></button>
              </form>
              <form method="post" style="display:inline;">
                <?= admin_csrf_input() ?>
                <input type="hidden" name="action" value="move_up">
                <input type="hidden" name="id" value="<?= (int)$slide['id'] ?>">
                <button type="submit" class="btn btn-secondary" title="انتقال به بالا">↑</button>
              </form>
              <form method="post" style="display:inline;">
                <?= admin_csrf_input() ?>
                <input type="hidden" name="action" value="move_down">
                <input type="hidden" name="id" value="<?= (int)$slide['id'] ?>">
                <button type="submit" class="btn btn-secondary" title="انتقال به پایین">↓</button>
              </form>
              <form method="post" onsubmit="return confirm('این اسلاید حذف شود؟');" style="display:inline;">
                <?= admin_csrf_input() ?>
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?= (int)$slide['id'] ?>">
                <button type="submit" class="btn btn-danger">حذف</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
window.ADMIN_CSRF_TOKEN = <?= json_encode($csrf_token) ?>;
const tbody = document.getElementById('sortable-body');

async function saveSlideOrder() {
  const order = [...document.querySelectorAll('#sortable-body tr')].map(row => row.dataset.id);
  const formData = new FormData();
  formData.append('csrf_token', window.ADMIN_CSRF_TOKEN);
  formData.append('action', 'reorder');
  formData.append('order', JSON.stringify(order));
  const response = await fetch('admin_slider.php', {
    method: 'POST', body: formData, credentials: 'same-origin', headers: {'X-CSRF-Token': window.ADMIN_CSRF_TOKEN}
  });
  let data;
  try { data = await response.json(); }
  catch (_) { throw new Error('پاسخ نامعتبر از سرور دریافت شد.'); }
  if (!response.ok || data.status !== 'ok') throw new Error(data.message || 'ذخیره ترتیب انجام نشد.');
}

if (tbody && typeof window.Sortable !== 'undefined') {
  new window.Sortable(tbody, {
    handle: '.drag-handle', animation: 200,
    onEnd: () => saveSlideOrder().catch(error => alert(error.message))
  });
} else if (tbody) {
  // Native fallback keeps drag/drop working when the CDN is unavailable.
  let dragged = null;
  tbody.querySelectorAll('tr').forEach(row => {
    row.draggable = true;
    row.addEventListener('dragstart', event => { dragged = row; event.dataTransfer.effectAllowed = 'move'; });
    row.addEventListener('dragover', event => event.preventDefault());
    row.addEventListener('drop', event => {
      event.preventDefault();
      if (!dragged || dragged === row) return;
      const rows = [...tbody.querySelectorAll('tr')];
      if (rows.indexOf(dragged) < rows.indexOf(row)) row.after(dragged); else row.before(dragged);
      saveSlideOrder().catch(error => alert(error.message));
    });
    row.addEventListener('dragend', () => { dragged = null; });
  });
}
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>