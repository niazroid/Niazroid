<?php
// ajax_comments.php - مدیریت کامل کامنت (افزودن، پاسخ، لایک، حذف، بارگذاری بیشتر) با رفع خطاها و افزودن CSRF
require_once 'config.php';
require_once __DIR__ . '/includes/vip_features.php';
require_once __DIR__ . '/includes/bankmovie_comment_upgrade.php';
require_once __DIR__ . '/includes/sticker_packs.php';
bm_site_comment_upgrade_schema($pdo);
header('Content-Type: application/json; charset=utf-8');
bm_security_enforce_rate_limit('comments_api', 240, 300, bm_security_client_ip(), true);

$userLang = $_COOKIE['user_lang'] ?? 'fa';
$currentUser = null;
if (isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

// راه‌اندازی سشن برای CSRF
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$action = '';
foreach (['action', 'bm_action', 'comment_action', 'do', 'task', 'mode'] as $key) {
    if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') { $action = trim((string)$_POST[$key]); break; }
    if (isset($_GET[$key])  && trim((string)$_GET[$key])  !== '') { $action = trim((string)$_GET[$key]);  break; }
}
$action = strtolower($action);

// سازگاری با اسم‌های مختلف اکشن در فرانت‌های قدیمی/جدید
$actionAliases = [
    'submit_comment' => 'add_comment',
    'send_comment'   => 'add_comment',
    'new_comment'    => 'add_comment',
    'comment_add'    => 'add_comment',
    'add'            => 'add_comment',
    'submit_reply'   => 'add_reply',
    'send_reply'     => 'add_reply',
    'reply'          => 'add_reply',
    'reply_add'      => 'add_reply',
    'like'           => 'vote',
    'dislike'        => 'vote',
    'like_comment'   => 'vote',
    'dislike_comment'=> 'vote',
    'comment_vote'   => 'vote',
    'delete'         => 'delete_comment',
    'remove'         => 'delete_comment',
    'remove_comment' => 'delete_comment',
    'edit'           => 'edit_comment',
    'comment_edit'   => 'edit_comment',
    'pin'            => 'pin_comment',
    'comment_pin'    => 'pin_comment',
    'report'         => 'report_comment',
    'comment_report' => 'report_comment',
    'load_more'      => 'load_more_comments',
    'more_comments'  => 'load_more_comments',
    'get_reply'      => 'get_replies',
    'replies'        => 'get_replies',
];
if (isset($actionAliases[$action])) $action = $actionAliases[$action];
if (in_array($action, ['add_comment','add_reply','vote','edit_comment','pin_comment','report_comment','delete_comment'], true)) {
    $identity = $currentUser ? ('user:' . (int)$currentUser['id']) : ('ip:' . bm_security_client_ip());
    bm_security_enforce_rate_limit('comments_mutation', 60, 300, $identity, true);
}

// اگر action به هر دلیل ارسال نشد، از روی فیلدها حدس بزن تا خطای action not found نگیریم.
if ($action === '') {
    if (isset($_POST['comment']) && isset($_POST['parent_id'])) $action = 'add_reply';
    elseif (isset($_POST['comment']) && isset($_POST['movie_id'])) $action = 'add_comment';
    elseif (isset($_POST['comment_id']) && isset($_POST['type'])) $action = 'vote';
    elseif (isset($_POST['comment_id']) && isset($_POST['new_comment'])) $action = 'edit_comment';
    elseif (isset($_POST['comment_id']) && isset($_POST['reason'])) $action = 'report_comment';
    elseif (isset($_POST['page']) && isset($_POST['movie_id'])) $action = 'load_more_comments';
    elseif (isset($_GET['comment_id'])) $action = 'get_replies';
}
if (in_array($action, ['add_comment','add_reply','vote','edit_comment','report_comment'], true)) {
    // Sticker/GIF attachments in ordinary comments/replies are free.
    // Other comment actions keep the existing comments_ratings gate exactly as before.
    $bmFreeCommentMedia = in_array($action, ['add_comment','add_reply'], true)
        && bm_sticker_find_marker((string)($_POST['comment'] ?? '')) !== null;
    if (!$bmFreeCommentMedia) {
        bm_vip_gate_require('comments_ratings', $currentUser ?: null, true);
    }
}
$commentsPerPage = 10;

// آرشیو ۱ از ID مجازی مثبت در بازه بالا استفاده می‌کند.
// این فلگ باعث می‌شود کامنت آرشیو ۱ داخل movie_ratings آرشیو ۲ ثبت نشود.
function bm_is_archive1_comment_movie_id(int $movieId): bool {
    return $movieId >= 1000000000;
}

// آرشیو ۱ جدول جدا دارد تا به foreign key احتمالی comments.movie_id -> movies.id گیر نکند.
function bm_ensure_archive1_comment_tables(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        movie_id INT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        comment TEXT NOT NULL,
        rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
        spoiler TINYINT(1) NOT NULL DEFAULT 0,
        parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_movie_parent_status (movie_id, parent_id, status),
        KEY idx_user_status (user_id, status),
        KEY idx_parent (parent_id),
        KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comment_likes (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        comment_id BIGINT UNSIGNED NOT NULL,
        user_id INT UNSIGNED NOT NULL,
        type VARCHAR(10) NOT NULL DEFAULT 'like',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_comment_user (comment_id, user_id),
        KEY idx_comment_type (comment_id, type),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

function bm_comment_table(bool $isArchive1): string {
    return $isArchive1 ? 'archive1_comments' : 'comments';
}
function bm_like_table(bool $isArchive1): string {
    return $isArchive1 ? 'archive1_comment_likes' : 'comment_likes';
}
function bm_comment_public_status_sql(string $alias = 'c'): string {
    $safeAlias = preg_replace('/[^A-Za-z0-9_]/', '', $alias) ?: 'c';
    return "LOWER(TRIM(CAST({$safeAlias}.status AS CHAR))) IN ('approved','active','1')";
}
function bm_comment_root_parent_sql(string $alias = 'c'): string {
    $safeAlias = preg_replace('/[^A-Za-z0-9_]/', '', $alias) ?: 'c';
    return "({$safeAlias}.parent_id IS NULL OR {$safeAlias}.parent_id = 0)";
}


function bm_comment_privileged_role(string $role): bool {
    return in_array(strtolower(trim($role)), ['admin','administrator','vip','premium','special'], true);
}

function bm_comment_rate_limit(PDO $pdo, ?int $userId): void {
    global $currentUser;
    if (bm_site_comment_is_privileged($currentUser)) return;
    $cfg = bm_site_comment_config();
    $limit = max(1, (int)($cfg['rate_count'] ?? 3));
    $minutes = max(1, (int)($cfg['rate_minutes'] ?? 10));
    $windowSeconds = $minutes * 60;
    $pdo->exec("CREATE TABLE IF NOT EXISTS comment_rate_limits (
        actor_key VARCHAR(190) NOT NULL PRIMARY KEY,
        window_started_at DATETIME NOT NULL,
        comment_count INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL,
        KEY idx_updated_at (updated_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $remote = trim((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'));
    $device = trim((string)($_SERVER['HTTP_X_DEVICE_ID'] ?? $_COOKIE['bm_device_id'] ?? ''));
    $actor = ($userId !== null && $userId > 0) ? ('user:' . $userId) : ('guest:' . hash('sha256', $remote . '|' . $device));
    $stmt = $pdo->prepare("INSERT INTO comment_rate_limits(actor_key,window_started_at,comment_count,updated_at)
        VALUES(?,NOW(),1,NOW())
        ON DUPLICATE KEY UPDATE
            comment_count = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE), 1, comment_count + 1),
            window_started_at = IF(window_started_at <= DATE_SUB(NOW(), INTERVAL {$minutes} MINUTE), NOW(), window_started_at),
            updated_at = NOW()");
    $stmt->execute([$actor]);
    $read = $pdo->prepare("SELECT comment_count, GREATEST(0, ? - TIMESTAMPDIFF(SECOND, window_started_at, NOW())) AS retry_after FROM comment_rate_limits WHERE actor_key=? LIMIT 1");
    $read->execute([$windowSeconds,$actor]);
    $row = $read->fetch(PDO::FETCH_ASSOC) ?: ['comment_count'=>1,'retry_after'=>0];
    if ((int)$row['comment_count'] > $limit) {
        http_response_code(429);
        echo json_encode([
            'success'=>false,
            'error'=>"برای جلوگیری از اسپم، هر کاربر در هر {$minutes} دقیقه حداکثر {$limit} دیدگاه یا پاسخ می‌تواند ثبت کند.",
            'retry_after'=>max(1, (int)$row['retry_after'])
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }
}



if (!function_exists('bm_comment_avatar_url_safe')) {
    function bm_comment_avatar_url_safe($avatar): string
    {
        $raw = trim(str_replace('\\', '/', (string)$avatar));
        if ($raw === '') return '';
        if (preg_match('~^https?://~i', $raw)) return $raw;
        if ($raw[0] === '/') {
            if (strpos($raw, '..') !== false) return '';
            return preg_match('~^/(?:assets/avatars|uploads/avatars)/[A-Za-z0-9._/\\-]+$~i', $raw) ? $raw : '';
        }
        $raw = ltrim($raw, '/');
        if (strpos($raw, '..') !== false) return '';
        if (preg_match('~^(?:assets/avatars|uploads/avatars)/[A-Za-z0-9._/\\-]+$~i', $raw)) return '/' . $raw;
        if (preg_match('~^[A-Za-z0-9._-]+\\.(?:webp|png|jpe?g|gif|svg)$~i', $raw)) return '/assets/avatars/' . $raw;
        return '';
    }
}

if (!function_exists('bm_comment_avatar_html_safe')) {
    function bm_comment_avatar_html_safe($avatar): string
    {
        $url = bm_comment_avatar_url_safe($avatar);
        if ($url === '') {
            return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
        }
        return '<img src="' . htmlspecialchars($url, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '" loading="lazy" decoding="async" alt="">';
    }
}

// ========== توابع کمکی ==========
function validateCsrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

function formatCommentDate($date, $lang) {
    if (empty($date)) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $timestamp = strtotime($date);
    if ($timestamp === false) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    $diff = time() - $timestamp;
    if ($diff < 0) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if ($diff < 60) return $lang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ($lang === 'fa' ? ' دقیقه پیش' : ' minutes ago');
    if ($diff < 86400) return floor($diff / 3600) . ($lang === 'fa' ? ' ساعت پیش' : ' hours ago');
    if ($diff < 604800) return floor($diff / 86400) . ($lang === 'fa' ? ' روز پیش' : ' days ago');
    if ($diff < 2592000) return floor($diff / 604800) . ($lang === 'fa' ? ' هفته پیش' : ' weeks ago');
    if ($diff < 31536000) return floor($diff / 2592000) . ($lang === 'fa' ? ' ماه پیش' : ' months ago');
    return floor($diff / 31536000) . ($lang === 'fa' ? ' سال پیش' : ' years ago');
}

function renderStars($rating) {
    $full = (int)$rating;
    $empty = 5 - $full;
    $stars = '';
    for ($i = 0; $i < $full; $i++) {
        $stars .= '<svg class="star star-full" viewBox="0 0 24 24" fill="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    }
    for ($i = 0; $i < $empty; $i++) {
        $stars .= '<svg class="star star-empty" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="width:16px;height:16px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>';
    }
    return $stars;
}

function getRepliesHTML($commentId, $currentUserId, $userLang, $isArchive1 = false, $depth = 1) {
    global $pdo, $currentUser;
    if ($isArchive1) bm_ensure_archive1_comment_tables($pdo);
    $commentTable = bm_comment_table((bool)$isArchive1);
    $likeTable = bm_like_table((bool)$isArchive1);
    $approvedReply = bm_comment_public_status_sql('r');
    try {
        $stmt = $pdo->prepare("
            SELECT r.*, 
                COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'like'), 0) as like_count,
                COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = r.id AND type = 'dislike'), 0) as dislike_count,
                COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = r.id AND user_id = ?), '') as user_vote,
                u.username, u.role, u.avatar
            FROM {$commentTable} r
            LEFT JOIN users u ON r.user_id = u.id
            WHERE r.parent_id = ? AND ({$approvedReply} OR (? > 0 AND r.user_id = ? AND LOWER(TRIM(CAST(r.status AS CHAR)))='pending'))
            ORDER BY r.created_at ASC
        ");
        $stmt->execute([$currentUserId, $commentId, $currentUserId, $currentUserId]);
        $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('BankMovie ajax replies render skipped: ' . $e->getMessage());
        return '';
    }
    if (empty($replies)) return '';

    $html = '<div class="replies-container">';
    foreach ($replies as $reply) {
        $adminTick = bm_site_comment_role_badge((string)($reply['role'] ?? 'user'));
        $avatarHtml = bm_comment_avatar_html_safe($reply['avatar'] ?? '');
        $replyText = bm_comment_media_text_or_html((string)$reply['comment']);
        if ($reply['spoiler'] == 1) {
            $replyText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">' . $replyText . '</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
        }
        $canEditReply = bm_site_comment_can_edit($reply, $currentUser) && bm_sticker_find_marker((string)($reply['comment'] ?? '')) === null;
        $editReply = $canEditReply ? '<button class="edit-comment-btn" data-id="'.(int)$reply['id'].'">ویرایش</button>' : '';
        $reportReply = $currentUserId ? '<button class="report-comment-btn" data-id="'.(int)$reply['id'].'">گزارش</button>' : '';
        $replyAgain = '<button class="reply-btn" data-id="'.(int)$reply['id'].'">پاسخ</button>';
        $replyMeta = (!empty($reply['edited_at'])?' <span class="bm-comment-edited">ویرایش‌شده</span>':'').(strtolower((string)($reply['status']??''))==='pending'?' <span class="bm-comment-pending">در انتظار تأیید</span>':'');
        $children = $depth < 4 ? getRepliesHTML((int)$reply['id'],$currentUserId,$userLang,$isArchive1,$depth+1) : '';
        $html .= '<div class="reply-item" data-id="' . $reply['id'] . '">
            <div class="reply-header">
                <div class="reply-user">
                    <div class="reply-avatar">' . $avatarHtml . '</div>
                    <span class="reply-name">' . htmlspecialchars($reply['username']) . ' ' . $adminTick . '</span>
                </div>
                <span class="comment-date">' . formatCommentDate($reply['created_at'], $userLang) . $replyMeta . '</span>
            </div>
            <div class="reply-text">' . $replyText . '</div>
            <div class="reply-actions">
                <div class="comment-like ' . ($reply['user_vote'] === 'like' ? 'active' : '') . '" data-id="' . $reply['id'] . '" data-type="like">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                    <span class="like-count">' . number_format($reply['like_count']) . '</span>
                </div>
                <div class="comment-dislike ' . ($reply['user_vote'] === 'dislike' ? 'active' : '') . '" data-id="' . $reply['id'] . '" data-type="dislike">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                    <span class="dislike-count">' . number_format($reply['dislike_count']) . '</span>
                </div>
                '.$replyAgain.$editReply.$reportReply.'
            </div>
            <div class="reply-form-container" id="reply-form-'.(int)$reply['id'].'" style="display:none;"></div>
            '.$children.'
        </div>';
    }
    $html .= '</div>';
    return $html;
}

function renderCommentHTML($comment, $lang, $currentUserId, $isArchive1 = false) {
    global $currentUser; // دسترسی به متغیر سراسری برای نقش
    $adminTick = bm_site_comment_role_badge((string)($comment['role'] ?? 'user'));
    $replyText = $lang === 'fa' ? 'پاسخ' : 'Reply';
    $replyCount = $comment['reply_count'] ?? 0;
    $replyCountHtml = $replyCount > 0 ? '<span class="reply-count">(' . $replyCount . ')</span>' : '';
    $avatarHtml = bm_comment_avatar_html_safe($comment['avatar'] ?? '');
    $commentText = bm_comment_media_text_or_html((string)$comment['comment']);
    if ($comment['spoiler'] == 1) {
        $commentText = '<div class="spoiler-wrapper"><div class="spoiler-content-hidden">' . $commentText . '</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle(\'spoiler-visible\'); this.style.display=\'none\';">نمایش اسپویلر</button></div>';
    }
    $deleteBtn = '';
    if ($currentUserId && ($currentUserId == $comment['user_id'] || ($currentUser && $currentUser['role'] == 'admin'))) {
        $deleteBtn = '<button class="delete-comment-btn" data-id="' . $comment['id'] . '"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>';
    }
    $canEdit = bm_site_comment_can_edit($comment, $currentUser) && bm_sticker_find_marker((string)($comment['comment'] ?? '')) === null;
    $editBtn = $canEdit ? '<button class="edit-comment-btn" data-id="'.(int)$comment['id'].'">ویرایش</button>' : '';
    $reportBtn = $currentUserId ? '<button class="report-comment-btn" data-id="'.(int)$comment['id'].'">گزارش</button>' : '';
    $pinBtn = bm_site_comment_is_admin($currentUser) ? '<button class="pin-comment-btn" data-id="'.(int)$comment['id'].'" data-pin="'.(!empty($comment['is_pinned'])?'0':'1').'">'.(!empty($comment['is_pinned'])?'برداشتن پین':'پین').'</button>' : '';
    $stateMeta = (!empty($comment['is_pinned'])?'<span class="bm-comment-pin">📌 پین‌شده</span>':'').(!empty($comment['edited_at'])?'<span class="bm-comment-edited">ویرایش‌شده</span>':'').(strtolower((string)($comment['status']??''))==='pending'?'<span class="bm-comment-pending">در انتظار تأیید</span>':'');
    $repliesHtml = getRepliesHTML($comment['id'], $currentUserId, $lang, $isArchive1, 1);
    return '<div class="comment-item '.(!empty($comment['is_pinned'])?'bm-comment-pinned':'').'" data-id="' . $comment['id'] . '" data-reply-count="' . $replyCount . '">
        <div class="comment-header">
            <div class="comment-user">
                <div class="comment-avatar-small">' . $avatarHtml . '</div>
                <div>
                    <div class="comment-name">' . htmlspecialchars($comment['username']) . ' ' . $adminTick . '</div>
                    <div class="comment-date">' . formatCommentDate($comment['created_at'], $lang) . ' '.$stateMeta.'</div>
                </div>
            </div>
            <div class="comment-rating-stars">' . renderStars($comment['rating']) . '</div>
        </div>
        <div class="comment-text">' . $commentText . '</div>
        <div class="comment-actions">
            <div class="comment-like ' . ($comment['user_vote'] === 'like' ? 'active' : '') . '" data-id="' . $comment['id'] . '" data-type="like">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                <span class="like-count">' . number_format($comment['like_count']) . '</span>
            </div>
            <div class="comment-dislike ' . ($comment['user_vote'] === 'dislike' ? 'active' : '') . '" data-id="' . $comment['id'] . '" data-type="dislike">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                <span class="dislike-count">' . number_format($comment['dislike_count']) . '</span>
            </div>
            <button class="reply-btn" data-id="' . $comment['id'] . '">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <span>' . $replyText . '</span> ' . $replyCountHtml . '
            </button>
            ' . $editBtn . $reportBtn . $pinBtn . $deleteBtn . '
        </div>
        <div class="reply-form-container" id="reply-form-' . $comment['id'] . '" style="display:none;"></div>
        ' . $repliesHtml . '
    </div>';
}

if (!function_exists('renderCommentHTMLSafe')) {
    function renderCommentHTMLSafe($comment, $lang, $currentUserId, $isArchive1 = false): string
    {
        try {
            return renderCommentHTML($comment, $lang, $currentUserId, $isArchive1);
        } catch (Throwable $e) {
            error_log('BankMovie ajax comment fallback: ' . $e->getMessage());
            $id = (int)($comment['id'] ?? 0);
            $username = htmlspecialchars((string)($comment['username'] ?? 'کاربر'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            try {
                $avatarHtml = bm_comment_avatar_html_safe($comment['avatar'] ?? '');
            } catch (Throwable $ignored) {
                $avatarHtml = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>';
            }
            try {
                $body = bm_comment_media_text_or_html((string)($comment['comment'] ?? ''));
            } catch (Throwable $ignored) {
                $body = nl2br(htmlspecialchars((string)($comment['comment'] ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));
            }
            return '<div class="comment-item bm-comment-safe-fallback" data-id="'.$id.'">'
                .'<div class="comment-header"><div class="comment-user"><div class="comment-avatar-small">'.$avatarHtml.'</div><div><div class="comment-name">'.$username.'</div></div></div></div>'
                .'<div class="comment-text">'.$body.'</div>'
                .'<div class="comment-actions"><button type="button" class="reply-btn" data-id="'.$id.'"><span>'.($lang === 'fa' ? 'پاسخ' : 'Reply').'</span></button></div>'
                .'<div class="reply-form-container" id="reply-form-'.$id.'" style="display:none"></div>'
                .'</div>';
        }
    }
}

try {
    switch ($action) {
        // ========== افزودن کامنت اصلی ==========
        case 'add_comment':
            if (empty(bm_site_comment_config()['enabled'])) { echo json_encode(['success'=>false,'error'=>(string)(function_exists('bm_site_get')?bm_site_get('comment_disabled_message_fa','بخش دیدگاه‌ها موقتاً غیرفعال است.'):'بخش دیدگاه‌ها موقتاً غیرفعال است.')]); exit; }
            if (!empty(bm_site_comment_config()['require_login']) && !$currentUser) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'برای ثبت دیدگاه وارد حساب کاربری شوید.':'Please sign in to comment.']); exit;
            }
            // اعتبارسنجی CSRF
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $commentText = trim($_POST['comment'] ?? '');
            $rating = (int)($_POST['rating'] ?? 0);
            if (empty(bm_site_comment_config()['ratings'])) $rating = 0;
            $spoiler = (int)($_POST['spoiler'] ?? 0);
            if (empty(bm_site_comment_config()['spoiler'])) $spoiler = 0;
            $commentMediaCount = bm_sticker_marker_count($commentText);
            $commentMediaMarker = bm_sticker_find_marker($commentText);
            $commentHumanText = $commentMediaMarker ? bm_sticker_comment_text($commentText) : $commentText;
            if ($commentMediaCount > 1) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'در هر دیدگاه فقط یک استیکر یا گیف می‌توانید بفرستید.':'Only one sticker or GIF is allowed per comment.']); exit;
            }
            if ($commentMediaMarker) {
                // V14861968: stickers/GIFs in normal comments are free for everyone.
                // The marker is still resolved server-side, so clients cannot inject arbitrary media URLs.
                if (!bm_sticker_resolve_marker($commentText)) {
                    echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'این استیکر دیگر در دسترس نیست.':'This sticker is no longer available.']); exit;
                }
                // Media comments may carry normal text beside the sticker.
                $rating = 0;
                $spoiler = 0;
            }

            if ($commentHumanText === '' && !$commentMediaMarker) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً متن نظر را وارد کنید' : 'Please enter comment']);
                exit;
            }
            if ($commentHumanText !== '' && mb_strlen($commentHumanText, 'UTF-8') < 3) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'متن نظر باید حداقل ۳ کاراکتر باشد' : 'Comment text must be at least 3 characters']);
                exit;
            }
            if (mb_strlen($commentHumanText, 'UTF-8') > 500) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'نظر نمی‌تواند بیشتر از ۵۰۰ کاراکتر باشد' : 'Comment cannot exceed 500 characters']);
                exit;
            }
            if ($rating < 0 || $rating > 5) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'امتیاز باید بین ۰ تا ۵ باشد' : 'Rating must be between 0 and 5']);
                exit;
            }

            $username = $currentUser ? $currentUser['username'] : ($userLang === 'fa' ? 'کاربر مهمان' : 'Guest');
            $userId = isset($currentUser['id']) ? (int)$currentUser['id'] : null;
            bm_comment_rate_limit($pdo, $userId);
            $dup = $pdo->prepare("SELECT id FROM {$commentTable} WHERE movie_id=? AND COALESCE(user_id,0)=COALESCE(?,0) AND LOWER(TRIM(comment))=LOWER(TRIM(?)) AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE) LIMIT 1");
            $dup->execute([$movieId,$userId,$commentText]);
            if ($dup->fetchColumn()) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'این متن اخیراً ارسال شده است.':'This comment was recently submitted.']); exit;
            }
            $status = bm_site_comment_submit_status($currentUser);

            $stmt = $pdo->prepare("INSERT INTO {$commentTable} (movie_id, user_id, username, comment, rating, spoiler, status, created_at, parent_id) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NULL)");
            $stmt->execute([$movieId, $userId, $username, $commentText, $rating, $spoiler, $status]);
            $newCommentId = $pdo->lastInsertId();

            // به‌روزرسانی امتیاز فیلم (فقط برای آرشیو ۲ / movie_id مثبت)
            // آرشیو ۱ از movie_id مجازی جداگانه استفاده می‌کند و نباید داخل جدول movie_ratings آرشیو ۲ ثبت شود.
            if ($movieId > 0 && !$isArchive1Comment) {
                $approvedRatingStatus = bm_comment_public_status_sql('comments');
                $rootRatingParent = bm_comment_root_parent_sql('comments');
                $stmt = $pdo->prepare("SELECT AVG(rating) as avg_rating, COUNT(*) as total_votes FROM comments WHERE movie_id = ? AND rating > 0 AND {$approvedRatingStatus} AND {$rootRatingParent}");
                $stmt->execute([$movieId]);
                $ratingData = $stmt->fetch(PDO::FETCH_ASSOC);
                $stmt = $pdo->prepare("INSERT INTO movie_ratings (movie_id, avg_rating, total_votes) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE avg_rating = ?, total_votes = ?");
                $stmt->execute([$movieId, $ratingData['avg_rating'] ?? 0, $ratingData['total_votes'] ?? 0, $ratingData['avg_rating'] ?? 0, $ratingData['total_votes'] ?? 0]);
            }

            $message = ($status === 'pending')
                ? ($userLang === 'fa' ? (string)(function_exists('bm_site_get')?bm_site_get('comment_pending_message_fa','دیدگاه شما ثبت شد و پس از بررسی مدیریت نمایش داده می‌شود.'):'دیدگاه شما ثبت شد و پس از بررسی مدیریت نمایش داده می‌شود.') : 'Your comment will appear after admin approval')
                : ($userLang === 'fa' ? 'نظر شما با موفقیت ثبت شد' : 'Comment submitted');
            echo json_encode([
                'success' => true,
                'message' => $message,
                'approved' => ($status === 'approved'),
                'comment' => [
                    'id' => $newCommentId,
                    'username' => $username,
                    'comment' => $commentText,
                    'rating' => $rating,
                    'spoiler' => $spoiler,
                    'role' => $currentUser['role'] ?? 'user',
                    'avatar' => $currentUser['avatar'] ?? '',
                    'user_id' => $userId
                ]
            ]);
            break;

        // ========== افزودن پاسخ ==========
        case 'add_reply':
            if (empty(bm_site_comment_config()['enabled']) || empty(bm_site_comment_config()['replies'])) { echo json_encode(['success'=>false,'error'=>'پاسخ به دیدگاه موقتاً غیرفعال است']); exit; }
            if (!empty(bm_site_comment_config()['require_login']) && !$currentUser) { echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'برای پاسخ‌دادن وارد حساب کاربری شوید.':'Please sign in to reply.']); exit; }
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $parentId = (int)($_POST['parent_id'] ?? 0);
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $commentText = trim($_POST['comment'] ?? '');
            $guestName = trim($_POST['username'] ?? '');
            $replySpoiler = !empty($_POST['spoiler']) ? 1 : 0;
            if (empty(bm_site_comment_config()['spoiler'])) $replySpoiler = 0;
            $replyMediaCount = bm_sticker_marker_count($commentText);
            $replyMediaMarker = bm_sticker_find_marker($commentText);
            $replyHumanText = $replyMediaMarker ? bm_sticker_comment_text($commentText) : $commentText;
            if ($replyMediaCount > 1) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'در هر پاسخ فقط یک استیکر یا گیف می‌توانید بفرستید.':'Only one sticker or GIF is allowed per reply.']); exit;
            }
            if ($replyMediaMarker) {
                // V14861968: sticker/GIF replies are public too; Watch Party sticker access is unchanged.
                if (!bm_sticker_resolve_marker($commentText)) {
                    echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'این استیکر دیگر در دسترس نیست.':'This sticker is no longer available.']); exit;
                }
                $replySpoiler = 0;
            }

            if ($replyHumanText === '' && !$replyMediaMarker) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً متن پاسخ را وارد کنید' : 'Please enter reply']);
                exit;
            }
            if ($replyHumanText !== '' && mb_strlen($replyHumanText, 'UTF-8') < 3) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'متن پاسخ باید حداقل ۳ کاراکتر باشد' : 'Reply text must be at least 3 characters']);
                exit;
            }
            if (mb_strlen($replyHumanText, 'UTF-8') > 500) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'پاسخ نمی‌تواند بیشتر از ۵۰۰ کاراکتر باشد' : 'Reply cannot exceed 500 characters']);
                exit;
            }

            $stmt = $pdo->prepare("SELECT id FROM {$commentTable} WHERE id = ? AND status != 'deleted'");
            $stmt->execute([$parentId]);
            if (!$stmt->fetch()) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'کامنت اصلی یافت نشد یا حذف شده است' : 'Parent comment not found or deleted']);
                exit;
            }

            if ($currentUser) {
                $userId = (int)$currentUser['id'];
                $displayName = $currentUser['username'];
                $status = bm_site_comment_submit_status($currentUser);
            } else {
                if (empty($guestName)) {
                    echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً نام خود را وارد کنید' : 'Please enter your name']);
                    exit;
                }
                if (mb_strlen($guestName, 'UTF-8') < 2 || mb_strlen($guestName, 'UTF-8') > 50) {
                    echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'نام باید بین ۲ تا ۵۰ کاراکتر باشد' : 'Name must be 2-50 characters']);
                    exit;
                }
                $userId = null;
                $displayName = htmlspecialchars($guestName, ENT_QUOTES, 'UTF-8');
                $status = 'pending';
            }

            bm_comment_rate_limit($pdo, $userId !== null ? (int)$userId : null);
            $dup = $pdo->prepare("SELECT id FROM {$commentTable} WHERE movie_id=? AND COALESCE(user_id,0)=COALESCE(?,0) AND LOWER(TRIM(comment))=LOWER(TRIM(?)) AND created_at>=DATE_SUB(NOW(),INTERVAL 10 MINUTE) LIMIT 1");
            $dup->execute([$movieId,$userId,$commentText]);
            if ($dup->fetchColumn()) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'این متن اخیراً ارسال شده است.':'This reply was recently submitted.']); exit;
            }
            $stmt = $pdo->prepare("INSERT INTO {$commentTable} (movie_id, user_id, username, comment, parent_id, spoiler, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt->execute([$movieId, $userId, $displayName, $commentText, $parentId, $replySpoiler, $status]);
            $newReplyId=(int)$pdo->lastInsertId();
            bm_site_comment_notify_reply($pdo,$isArchive1Comment?1:2,$movieId,$parentId,$newReplyId,(int)($userId??0),(string)$displayName,$commentTable);

            $message = ($status === 'pending')
                ? ($userLang === 'fa' ? 'پاسخ شما پس از تأیید ادمین نمایش داده می‌شود' : 'Your reply will appear after approval')
                : ($userLang === 'fa' ? 'پاسخ شما با موفقیت ثبت شد' : 'Reply posted');
            echo json_encode(['success' => true, 'message' => $message, 'approved' => ($status === 'approved')]);
            break;

        // ========== دریافت پاسخ‌ها ==========
        case 'get_replies':
            $commentId = (int)($_GET['comment_id'] ?? 0);
            $isArchive1Comment = (($_GET['archive'] ?? $_POST['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $likeTable = bm_like_table($isArchive1Comment);
            $approvedReplyCase = bm_comment_public_status_sql('c');
            if (!$commentId) {
                echo json_encode(['success' => false, 'error' => 'Invalid comment ID']);
                exit;
            }
            $stmt = $pdo->prepare("
                SELECT c.*,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                    COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = c.id AND user_id = ?), '') as user_vote,
                    u.role, u.avatar
                FROM {$commentTable} c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.parent_id = ? AND {$approvedReplyCase}
                ORDER BY c.created_at ASC
            ");
            $stmt->execute([$currentUser['id'] ?? 0, $commentId]);
            $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['success' => true, 'replies' => $replies]);
            break;

        // ========== لایک / دیسلایک ==========
        case 'vote':
            if (empty(bm_site_comment_config()['votes'])) { echo json_encode(['success'=>false,'error'=>'رأی‌دهی موقتاً غیرفعال است']); exit; }
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            if (!$currentUser) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login']);
                exit;
            }
            $commentId = (int)($_POST['comment_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $likeTable = bm_like_table($isArchive1Comment);
            $voteType = $_POST['type'] ?? '';
            if (!in_array($voteType, ['like', 'dislike'])) {
                echo json_encode(['success' => false, 'error' => 'Invalid vote type']);
                exit;
            }

            $stmt = $pdo->prepare("SELECT type FROM {$likeTable} WHERE comment_id = ? AND user_id = ?");
            $stmt->execute([$commentId, $currentUser['id']]);
            $existing = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                if ($existing['type'] === $voteType) {
                    $stmt = $pdo->prepare("DELETE FROM {$likeTable} WHERE comment_id = ? AND user_id = ?");
                    $stmt->execute([$commentId, $currentUser['id']]);
                } else {
                    $stmt = $pdo->prepare("UPDATE {$likeTable} SET type = ? WHERE comment_id = ? AND user_id = ?");
                    $stmt->execute([$voteType, $commentId, $currentUser['id']]);
                }
            } else {
                $stmt = $pdo->prepare("INSERT INTO {$likeTable} (comment_id, user_id, type) VALUES (?, ?, ?)");
                $stmt->execute([$commentId, $currentUser['id'], $voteType]);
            }

            $stmt = $pdo->prepare("
                SELECT
                    COUNT(CASE WHEN type = 'like' THEN 1 END) as likes,
                    COUNT(CASE WHEN type = 'dislike' THEN 1 END) as dislikes,
                    (SELECT type FROM {$likeTable} WHERE comment_id = ? AND user_id = ?) as user_vote
                FROM {$likeTable}
                WHERE comment_id = ?
            ");
            $stmt->execute([$commentId, $currentUser['id'], $commentId]);
            $stats = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode([
                'success' => true,
                'likes' => (int)$stats['likes'],
                'dislikes' => (int)$stats['dislikes'],
                'user_vote' => $stats['user_vote'] ?? ''
            ]);
            break;

        // ========== ویرایش محدود کامنت ==========
        case 'edit_comment':
            if (empty(bm_site_comment_config()['enabled'])) { echo json_encode(['success'=>false,'error'=>'بخش دیدگاه‌ها موقتاً غیرفعال است']); exit; }
            if (!validateCsrf($_POST['csrf_token'] ?? '') || !$currentUser) {
                echo json_encode(['success'=>false,'error'=>$userLang==='fa'?'نشست کاربری نامعتبر است':'Invalid session']); exit;
            }
            $commentId=(int)($_POST['comment_id']??0);
            $movieId=(int)($_POST['movie_id']??0);
            $isArchive1Comment=(($_POST['archive']??$_GET['archive']??'')==='1') || bm_is_archive1_comment_movie_id($movieId);
            $commentTable=bm_comment_table($isArchive1Comment);
            $text=trim((string)($_POST['new_comment']??$_POST['comment']??''));
            $spoiler=!empty($_POST['spoiler'])?1:0; if (empty(bm_site_comment_config()['spoiler'])) $spoiler=0;
            if (mb_strlen($text,'UTF-8')<3 || mb_strlen($text,'UTF-8')>500) { echo json_encode(['success'=>false,'error'=>'متن باید بین ۳ تا ۵۰۰ کاراکتر باشد']); exit; }
            $stmt=$pdo->prepare("SELECT * FROM {$commentTable} WHERE id=? LIMIT 1"); $stmt->execute([$commentId]); $row=$stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row || !bm_site_comment_can_edit($row,$currentUser)) { echo json_encode(['success'=>false,'error'=>'زمان ویرایش تمام شده یا دسترسی ندارید']); exit; }
            if (bm_sticker_find_marker((string)($row['comment'] ?? '')) !== null || bm_sticker_find_marker($text) !== null) { echo json_encode(['success'=>false,'error'=>'استیکر یا گیف قابل ویرایش نیست؛ آن را حذف و دوباره ارسال کنید']); exit; }
            $archiveNo=$isArchive1Comment?1:2;
            $h=$pdo->prepare('INSERT INTO comment_edit_history(archive_no,comment_id,editor_user_id,old_comment,old_spoiler,edited_at) VALUES(?,?,?,?,?,NOW())');
            $h->execute([$archiveNo,$commentId,(int)$currentUser['id'],(string)$row['comment'],(int)($row['spoiler']??0)]);
            $stmt=$pdo->prepare("UPDATE {$commentTable} SET comment=?,spoiler=?,edited_at=NOW(),updated_at=NOW() WHERE id=?");
            $stmt->execute([$text,$spoiler,$commentId]);
            echo json_encode(['success'=>true,'message'=>'دیدگاه ویرایش شد','edited_at'=>date('Y-m-d H:i:s')],JSON_UNESCAPED_UNICODE);
            break;

        // ========== پین توسط مدیر ==========
        case 'pin_comment':
            if (!validateCsrf($_POST['csrf_token'] ?? '') || !bm_site_comment_is_admin($currentUser)) { echo json_encode(['success'=>false,'error'=>'فقط مدیر اجازه پین دارد']); exit; }
            $commentId=(int)($_POST['comment_id']??0);
            $movieId=(int)($_POST['movie_id']??0);
            $isArchive1Comment=(($_POST['archive']??$_GET['archive']??'')==='1') || bm_is_archive1_comment_movie_id($movieId);
            $commentTable=bm_comment_table($isArchive1Comment);
            $pin=!empty($_POST['pin'])?1:0;
            $stmt=$pdo->prepare("UPDATE {$commentTable} SET is_pinned=?,pinned_at=IF(?=1,NOW(),NULL) WHERE id=?");
            $stmt->execute([$pin,$pin,$commentId]);
            echo json_encode(['success'=>true,'pinned'=>(bool)$pin],JSON_UNESCAPED_UNICODE);
            break;

        // ========== گزارش تخلف کامنت (نه گزارش خرابی لینک) ==========
        case 'report_comment':
            if (!validateCsrf($_POST['csrf_token'] ?? '') || !$currentUser) { echo json_encode(['success'=>false,'error'=>'برای گزارش وارد حساب شوید']); exit; }
            if (!(bm_site_comment_config()['reports']??true)) { echo json_encode(['success'=>false,'error'=>'گزارش تخلف موقتاً غیرفعال است']); exit; }
            $commentId=(int)($_POST['comment_id']??0); $movieId=(int)($_POST['movie_id']??0);
            $isArchive1Comment=(($_POST['archive']??$_GET['archive']??'')==='1') || bm_is_archive1_comment_movie_id($movieId);
            $reason=trim((string)($_POST['reason']??'other')); $details=mb_substr(trim((string)($_POST['details']??'')),0,500,'UTF-8');
            $allowed=['insult','spam','spoiler','inappropriate','wrong_info','other']; if(!in_array($reason,$allowed,true))$reason='other';
            $stmt=$pdo->prepare("INSERT INTO comment_reports(archive_no,movie_id,comment_id,reporter_user_id,reason,details,status,created_at) VALUES(?,?,?,?,?,?,'open',NOW()) ON DUPLICATE KEY UPDATE reason=VALUES(reason),details=VALUES(details),status='open',created_at=NOW()");
            $stmt->execute([$isArchive1Comment?1:2,$movieId,$commentId,(int)$currentUser['id'],$reason,$details]);
            echo json_encode(['success'=>true,'message'=>'گزارش برای مدیر ارسال شد'],JSON_UNESCAPED_UNICODE);
            break;

        // ========== حذف کامنت ==========
        case 'delete_comment':
            if (!validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            if (!$currentUser) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login']);
                exit;
            }
            $commentId = (int)($_POST['comment_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1');
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);

            $stmt = $pdo->prepare("SELECT user_id FROM {$commentTable} WHERE id = ?");
            $stmt->execute([$commentId]);
            $commentOwner = $stmt->fetchColumn();
            if ($currentUser['role'] !== 'admin' && $currentUser['id'] != $commentOwner) {
                echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'شما مجاز به حذف این کامنت نیستید' : 'You are not allowed to delete this comment']);
                exit;
            }

            // حذف نرم
            $stmt = $pdo->prepare("UPDATE {$commentTable} SET status = 'deleted' WHERE id = ?");
            $stmt->execute([$commentId]);
            $stmt = $pdo->prepare("UPDATE {$commentTable} SET status = 'deleted' WHERE parent_id = ?");
            $stmt->execute([$commentId]);

            echo json_encode(['success' => true, 'message' => $userLang === 'fa' ? 'کامنت با موفقیت حذف شد' : 'Comment deleted successfully', 'deleted_top_level' => true]);
            break;

        // ========== بارگذاری بیشتر کامنت‌ها ==========
        case 'load_more_comments':
            if (empty(bm_site_comment_config()['enabled'])) { echo json_encode(['success'=>true,'html'=>'','has_more'=>false]); exit; }
            // CSRF check for POST, but GET is fine for reading
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && !validateCsrf($_POST['csrf_token'] ?? '')) {
                echo json_encode(['success' => false, 'error' => 'CSRF token invalid']);
                exit;
            }
            $page = (int)($_POST['page'] ?? 1);
            $movieId = (int)($_POST['movie_id'] ?? 0);
            $isArchive1Comment = (($_POST['archive'] ?? $_GET['archive'] ?? '') === '1') || bm_is_archive1_comment_movie_id($movieId);
            if ($isArchive1Comment) bm_ensure_archive1_comment_tables($pdo);
            $commentTable = bm_comment_table($isArchive1Comment);
            $likeTable = bm_like_table($isArchive1Comment);
            $offset = max(0, ($page - 1) * $commentsPerPage);
            $limitSql = max(1, (int)$commentsPerPage);
            $offsetSql = max(0, (int)$offset);
            $approvedC = bm_comment_public_status_sql('c');
            $approvedR = bm_comment_public_status_sql('r');
            $rootC = bm_comment_root_parent_sql('c');
            $sort = (string)($_POST['sort'] ?? $_GET['sort'] ?? 'latest');
            $orderSql = bm_site_comment_order_sql($sort,'c',$likeTable,$commentTable);
            $viewerId = (int)($currentUser['id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT c.*,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'like'), 0) as like_count,
                    COALESCE((SELECT COUNT(*) FROM {$likeTable} WHERE comment_id = c.id AND type = 'dislike'), 0) as dislike_count,
                    COALESCE((SELECT type FROM {$likeTable} WHERE comment_id = c.id AND user_id = ? LIMIT 1), '') as user_vote,
                    (SELECT COUNT(*) FROM {$commentTable} r WHERE r.parent_id = c.id AND {$approvedR}) as reply_count,
                    COALESCE(u.role, 'user') AS role, COALESCE(u.avatar, '') AS avatar
                FROM {$commentTable} c
                LEFT JOIN users u ON c.user_id = u.id
                WHERE c.movie_id = ? AND {$rootC} AND ({$approvedC} OR (? > 0 AND c.user_id=? AND LOWER(TRIM(CAST(c.status AS CHAR)))='pending'))
                ORDER BY {$orderSql}
                LIMIT {$limitSql} OFFSET {$offsetSql}
            ");
            $stmt->execute([$viewerId, $movieId, $viewerId, $viewerId]);
            $moreComments = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $html = '';
            foreach ($moreComments as $comment) {
                $html .= renderCommentHTMLSafe($comment, $userLang, $currentUser['id'] ?? 0, $isArchive1Comment);
            }

            $approvedBase = bm_comment_public_status_sql($commentTable);
            $rootBase = bm_comment_root_parent_sql($commentTable);
            $totalStmt = $pdo->prepare("SELECT COUNT(*) FROM {$commentTable} WHERE movie_id = ? AND {$rootBase} AND ({$approvedBase} OR (? > 0 AND user_id=? AND LOWER(TRIM(CAST(status AS CHAR)))='pending'))");
            $totalStmt->execute([$movieId,$viewerId,$viewerId]);
            $total = (int)$totalStmt->fetchColumn();
            $hasMore = ($page * $commentsPerPage) < $total;

            echo json_encode(['success' => true, 'html' => $html, 'has_more' => $hasMore]);
            break;

        default:
            echo json_encode(['success' => false, 'error' => $userLang === 'fa' ? 'درخواست نامعتبر است یا اکشن ارسال نشده' : 'Invalid request or missing action', 'received_action' => $action]);
    }
} catch (Exception $e) {
    error_log("ajax_comments error: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Internal server error']);
}
?>