<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
@include_once __DIR__ . '/includes/_bm_support_widget.php';
require_once 'config.php';
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('app_page_enabled');
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$currentUser = $currentUser ?? ($_SESSION['user'] ?? null);
$userLang = (($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')) === 'en') ? 'en' : 'fa';
$userTheme = trim((string)($userTheme ?? ($currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green'))));
if ($userTheme === '' || !bm_theme_is_valid($userTheme)) $userTheme = 'dark-green';
$t = $t ?? [
    'fa' => ['home'=>'خانه','search'=>'جستجو','player'=>'پلیر','profile'=>'پروفایل','login'=>'ورود','logout'=>'خروج','register'=>'ثبت نام','account'=>'حساب کاربری','notifications'=>'اعلان‌ها','admin_panel'=>'پنل مدیریت'],
    'en' => ['home'=>'Home','search'=>'Search','player'=>'Player','profile'=>'Profile','login'=>'Login','logout'=>'Logout','register'=>'Register','account'=>'Account','notifications'=>'Notifications','admin_panel'=>'Admin panel'],
];
$latestNotification = $latestNotification ?? null;
$activeNotification = $activeNotification ?? null;
$notificationsList = $notificationsList ?? [];

$bmDownloadHelper = __DIR__ . '/app/download.php';
if (is_file($bmDownloadHelper)) {
    require_once $bmDownloadHelper;
}

$bmAppUpdate = function_exists('bm_latest_update')
    ? bm_latest_update()
    : [
        'version' => 'نامشخص',
        'build' => 0,
        'changes' => [],
        'downloads' => [],
    ];

$bmAppVersion = trim((string)($bmAppUpdate['version'] ?? ''));
if ($bmAppVersion === '') {
    $bmAppVersion = 'نامشخص';
}

$bmAppChanges = is_array($bmAppUpdate['changes'] ?? null)
    ? $bmAppUpdate['changes']
    : [];

$bmDownloads = is_array($bmAppUpdate['downloads'] ?? null)
    ? $bmAppUpdate['downloads']
    : [];

$bmApk = $bmDownloads['apk'] ?? ['available' => false, 'url' => '/app/download.php?file=apk'];
$bmZip = $bmDownloads['zip'] ?? ['available' => false, 'url' => '/app/download.php?file=zip'];

$bmApkUrl = (string)($bmApk['url'] ?? '/app/download.php?file=apk');
$bmZipUrl = (string)($bmZip['url'] ?? '/app/download.php?file=zip');
$bmApkAvailable = !empty($bmApk['available']);
$bmZipAvailable = !empty($bmZip['available']);

$bmFormatSize = static function (int $bytes): string {
    if ($bytes <= 0) {
        return '';
    }

    $units = ['B', 'KB', 'MB', 'GB'];
    $index = 0;
    $value = (float)$bytes;

    while ($value >= 1024 && $index < count($units) - 1) {
        $value /= 1024;
        $index++;
    }

    return number_format($value, $index >= 2 ? 1 : 0) . ' ' . $units[$index];
};

$bmApkSize = $bmFormatSize((int)($bmApk['size'] ?? 0));
$bmZipSize = $bmFormatSize((int)($bmZip['size'] ?? 0));
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>اپلیکیشن ها | BankMovie App</title>
<meta name="description" content="دانلود اپلیکیشن رسمی بانک مووی نسخه <?= htmlspecialchars($bmAppVersion, ENT_QUOTES, 'UTF-8') ?> برای اندروید 6 به بالا، Android TV و Android Box">
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="theme-color" content="#05050a">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/icon-180.png?v=102">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<style>
:root{
  --bg:#05050a;
  --panel:#11131c;
  --panel2:#0b0d15;
  --purple:#6d22ff;
  --purple2:#a855f7;
  --blue:#2f7cff;
  --yellow:#ffce3f;
  --text:#fff;
  --muted:rgba(255,255,255,.70);
  --line:rgba(255,255,255,.10);
  --soft:0 28px 80px rgba(0,0,0,.42);
}
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:var(--bg);color:var(--text);font-family:var(--bm-site-font, BonVF),system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;overflow-x:hidden}
body.page-app{min-height:100vh;padding-bottom:112px}
a{text-decoration:none;color:inherit}button{font:inherit}img{display:block;max-width:100%}svg{stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;fill:none}
.bm-app-page{position:relative;min-height:100vh;background:
radial-gradient(circle at 18% 8%,rgba(109,34,255,.28),transparent 34%),
radial-gradient(circle at 82% 4%,rgba(47,124,255,.16),transparent 30%),
linear-gradient(180deg,#080611 0%,#05050a 52%,#070811 100%)}
.bm-app-page:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:48px 48px;mask-image:linear-gradient(180deg,rgba(0,0,0,.85),transparent 72%);opacity:.55}
.container{width:min(1240px,calc(100% - 32px));margin:0 auto;position:relative;z-index:1}
.app-header{position:sticky;top:0;z-index:1000;background:rgba(5,5,10,.62);border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px)}
.app-header .container{height:76px;display:flex;align-items:center;justify-content:space-between;gap:14px}
.brand{display:flex;align-items:center;gap:12px;min-width:0}.brand img{width:50px;height:50px;border-radius:16px;box-shadow:0 0 32px rgba(109,34,255,.28)}.brand strong{display:block;font-size:17px;font-weight:1000;white-space:nowrap}.brand span{display:block;margin-top:3px;color:var(--muted);font-size:12px;font-weight:750}
.app-header-actions{display:flex;align-items:center;gap:10px}.header-btn{height:44px;padding:0 16px;border-radius:16px;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.05);display:inline-flex;align-items:center;justify-content:center;gap:8px;font-size:13px;font-weight:900}.header-btn.primary{background:linear-gradient(135deg,var(--purple),var(--purple2));border-color:transparent;box-shadow:0 16px 36px rgba(109,34,255,.24)}.header-btn img{width:20px;height:20px}
.hero{padding:54px 0 34px}.hero-grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(360px,.9fr);gap:40px;align-items:center}.kicker{display:inline-flex;align-items:center;gap:10px;min-height:38px;padding:0 14px;border-radius:999px;background:rgba(109,34,255,.14);border:1px solid rgba(168,85,247,.24);color:#eadcff;font-size:12px;font-weight:950}.kicker svg{width:17px;height:17px}
h1{margin:18px 0 0;font-size:clamp(2.5rem,7vw,5.8rem);line-height:1.08;letter-spacing:-2px;font-weight:1000;background:linear-gradient(135deg,#fff 0%,#e8dcff 38%,#9f7cff 100%);-webkit-background-clip:text;background-clip:text;color:transparent}.lead{margin:20px 0 0;max-width:690px;color:rgba(255,255,255,.76);font-size:16px;line-height:2.15;font-weight:700}.hero-actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:28px}.download{height:56px;padding:0 20px;border-radius:18px;display:inline-flex;align-items:center;justify-content:center;gap:10px;font-size:15px;font-weight:1000}.download.primary{background:linear-gradient(135deg,#ffd85a,#ffc22e);color:#111;box-shadow:0 20px 45px rgba(255,194,46,.22)}.download.secondary{background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.10)}.download.soon{background:rgba(255,255,255,.035);border:1px dashed rgba(255,255,255,.14);color:rgba(255,255,255,.76)}.download img,.download svg{width:23px;height:23px;flex:0 0 auto}
.quick-tags{margin-top:18px;display:flex;flex-wrap:wrap;gap:9px}.quick-tags span{display:inline-flex;align-items:center;min-height:34px;padding:0 13px;border-radius:999px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.075);font-size:11px;font-weight:850;color:rgba(255,255,255,.84)}
.visual{position:relative;min-height:540px}.orbit{position:absolute;inset:10px;border:1px solid rgba(168,85,247,.14);border-radius:50%;transform:rotate(-14deg)}.orbit.o2{inset:52px;border-color:rgba(255,255,255,.06);transform:rotate(12deg)}.desktop-mock{position:absolute;left:0;bottom:44px;width:58%;border-radius:22px;background:linear-gradient(180deg,#171a28,#080912);border:1px solid rgba(255,255,255,.10);box-shadow:var(--soft);padding:9px}.desktop-bar{height:20px;border-radius:12px;background:rgba(255,255,255,.06);display:flex;align-items:center;gap:5px;padding:0 8px;margin-bottom:8px}.desktop-bar i{width:6px;height:6px;border-radius:50%;background:rgba(255,255,255,.26)}.desktop-screen{height:190px;border-radius:14px;overflow:hidden;background:#000}.desktop-screen img{width:100%;height:100%;object-fit:cover}.phone-mock{position:absolute;right:5%;top:0;width:min(270px,48vw);padding:12px;border-radius:38px;background:linear-gradient(145deg,rgba(255,255,255,.16),rgba(255,255,255,.04));border:1px solid rgba(255,255,255,.18);box-shadow:0 36px 90px rgba(0,0,0,.48),0 0 80px rgba(109,34,255,.18);transform:rotate(3deg)}.phone-screen{height:520px;border-radius:29px;overflow:hidden;background:#000;position:relative}.phone-screen img{width:100%;height:100%;object-fit:cover}.play-float{position:absolute;left:50%;top:48%;transform:translate(-50%,-50%);width:74px;height:74px;border-radius:50%;background:linear-gradient(135deg,var(--purple),var(--purple2));display:flex;align-items:center;justify-content:center;box-shadow:0 20px 44px rgba(109,34,255,.42);border:1px solid rgba(255,255,255,.18)}.play-float svg{width:28px;height:28px;fill:#fff;stroke:none;transform:translateX(-2px)}.stat-row{position:absolute;right:0;bottom:0;left:0;display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.stat{padding:14px;border-radius:20px;background:rgba(255,255,255,.06);border:1px solid rgba(255,255,255,.09);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px)}.stat b{display:block;font-size:18px;font-weight:1000}.stat span{display:block;margin-top:4px;font-size:11px;color:var(--muted);font-weight:780}
.section{padding:30px 0}.section-head{display:flex;align-items:end;justify-content:space-between;gap:18px;margin-bottom:18px}.section-head h2{margin:0;font-size:30px;font-weight:1000}.section-head p{margin:8px 0 0;color:var(--muted);font-size:14px;line-height:1.9;font-weight:700}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.feature{padding:18px;border-radius:24px;background:linear-gradient(180deg,rgba(255,255,255,.065),rgba(255,255,255,.035));border:1px solid rgba(255,255,255,.08);box-shadow:0 18px 44px rgba(0,0,0,.22)}.feature-icon{width:50px;height:50px;border-radius:18px;background:linear-gradient(135deg,rgba(109,34,255,.28),rgba(47,124,255,.16));display:flex;align-items:center;justify-content:center;margin-bottom:14px}.feature-icon svg{width:24px;height:24px}.feature h3{margin:0 0 8px;font-size:16px;font-weight:950}.feature p{margin:0;color:var(--muted);font-size:13px;line-height:1.9;font-weight:700}
.shots{display:grid;grid-template-columns:1.15fr .85fr 1.15fr;gap:14px}.shot{position:relative;height:470px;border:0;padding:0;border-radius:30px;overflow:hidden;background:#0b0e15;cursor:pointer;box-shadow:var(--soft);border:1px solid rgba(255,255,255,.08)}.shot:nth-child(2){height:520px;transform:translateY(-22px)}.shot img{width:100%;height:100%;object-fit:cover;transition:transform .35s ease}.shot:hover img{transform:scale(1.04)}.shot span{position:absolute;left:12px;right:12px;bottom:12px;min-height:42px;border-radius:16px;background:rgba(0,0,0,.48);border:1px solid rgba(255,255,255,.10);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:950}
.download-panel{padding:22px;border-radius:34px;background:linear-gradient(180deg,rgba(16,18,28,.92),rgba(8,10,16,.92));border:1px solid rgba(255,255,255,.09);box-shadow:var(--soft)}.download-grid{display:grid;grid-template-columns:1fr 1fr 1fr;gap:14px}.download-tile{min-height:210px;padding:20px;border-radius:26px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);display:flex;flex-direction:column;gap:12px}.tile-icon{width:58px;height:58px;border-radius:20px;background:rgba(255,255,255,.07);display:flex;align-items:center;justify-content:center;overflow:hidden}.tile-icon img,.tile-icon svg{width:30px;height:30px}.download-tile h3{margin:0;font-size:18px;font-weight:1000}.download-tile p{margin:0;color:var(--muted);font-size:13px;line-height:1.9;font-weight:700}.download-tile a,.download-tile button{margin-top:auto;height:50px;border:0;border-radius:17px;display:flex;align-items:center;justify-content:center;font-weight:1000;font-size:14px}.go{background:linear-gradient(135deg,#ffd85a,#ffc22e);color:#111}.soft{background:rgba(255,255,255,.065);border:1px solid rgba(255,255,255,.09);color:#fff}.soon-card{opacity:.75}
/* V58: mobile bottom navigation is rendered/styled by shared_bottom_nav.php + shared global CSS. */
.lightbox{position:fixed;inset:0;z-index:2500;opacity:0;visibility:hidden;pointer-events:none;transition:.2s ease}.lightbox.open{opacity:1;visibility:visible;pointer-events:auto}.lb-bg{position:absolute;inset:0;background:rgba(0,0,0,.88);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px)}.lb-wrap{position:relative;z-index:1;width:100%;height:100%;display:flex;align-items:center;justify-content:center;padding:22px}.lb-fig{margin:0;max-width:min(92vw,480px);max-height:82vh;border-radius:24px;overflow:hidden;border:1px solid rgba(255,255,255,.12);box-shadow:0 30px 90px rgba(0,0,0,.52)}.lb-fig img{display:block;max-width:100%;max-height:82vh;width:auto;height:auto;background:#000}.lb-btn{position:absolute;border:1px solid rgba(255,255,255,.14);background:rgba(255,255,255,.08);color:#fff;width:44px;height:44px;border-radius:999px;display:flex;align-items:center;justify-content:center;cursor:pointer;backdrop-filter:blur(10px)}.lb-close{top:22px;left:22px}.lb-prev{right:14px;top:50%;transform:translateY(-50%)}.lb-next{left:14px;top:50%;transform:translateY(-50%)}.lb-btn svg{width:20px;height:20px}
.release-card{padding:24px;border-radius:30px;background:linear-gradient(180deg,rgba(109,34,255,.13),rgba(255,255,255,.035));border:1px solid rgba(168,85,247,.20);box-shadow:var(--soft)}
.release-top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}.release-version{display:inline-flex;align-items:center;gap:9px;min-height:40px;padding:0 15px;border-radius:999px;background:linear-gradient(135deg,var(--purple),var(--purple2));font-size:13px;font-weight:1000}.release-build{color:var(--muted);font-size:12px;font-weight:800}
.release-list{margin:0;padding:0 20px 0 0;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px 24px}.release-list li{color:rgba(255,255,255,.84);font-size:13px;line-height:1.9;font-weight:750;padding-right:4px}.release-list li::marker{color:#a855f7}
.file-meta{display:block;margin-top:6px;color:var(--muted);font-size:11px;font-weight:750}
@media(max-width:1020px){.hero-grid{grid-template-columns:1fr}.visual{min-height:600px}.cards{grid-template-columns:repeat(2,1fr)}.download-grid{grid-template-columns:1fr}.shots{grid-template-columns:1fr 1fr}.shot,.shot:nth-child(2){height:400px;transform:none}}
@media(max-width:680px){.release-top{align-items:flex-start;flex-direction:column}.release-list{grid-template-columns:1fr}body.page-app{padding-bottom:118px}.container{width:calc(100% - 18px)}.app-header .container{height:68px}.brand img{width:42px;height:42px}.brand strong{font-size:14px}.brand span{font-size:11px}.header-btn{height:40px;padding:0 12px;font-size:12px}.header-btn.primary span{display:none}.hero{padding:28px 0 18px}h1{font-size:38px;letter-spacing:-1px}.lead{font-size:14px}.hero-actions{display:grid;grid-template-columns:1fr}.download{width:100%;height:52px}.visual{min-height:510px}.desktop-mock{display:none}.phone-mock{right:50%;transform:translateX(50%) rotate(2deg);width:min(285px,82vw)}.phone-screen{height:470px}.stat-row{position:relative;margin-top:16px;grid-template-columns:repeat(3,1fr)}.stat{padding:11px}.stat b{font-size:15px}.section{padding:22px 0}.section-head{display:block}.section-head h2{font-size:24px}.cards{grid-template-columns:1fr}.shots{grid-template-columns:1fr;gap:12px}.shot,.shot:nth-child(2){height:360px}.download-panel{padding:16px;border-radius:26px}.download-tile{min-height:auto;padding:16px}/* V59 corrected: no page-local mobile nav geometry */}
@media(min-width:992px){body.page-app{padding-bottom:40px}}

/* V82 screenshot fit + platform icons */
.shot{background:radial-gradient(circle at center,rgba(47,124,255,.10),#070a10 68%);display:flex;align-items:center;justify-content:center;padding:10px}
.shot img{width:100%;height:100%;object-fit:contain!important;border-radius:20px;background:#05070c}
.shot:hover img{transform:none}
@media(max-width:1020px){.shot,.shot:nth-child(2){height:520px}}
@media(max-width:680px){.shot,.shot:nth-child(2){height:520px;padding:8px;border-radius:24px}.shots{gap:16px}}
@media(max-width:390px){.shot,.shot:nth-child(2){height:500px}}

/* PWA v95 */
.download-grid{grid-template-columns:repeat(4,minmax(0,1fr))}
.tv-download-tile{border-color:rgba(54,163,255,.24);background:linear-gradient(180deg,rgba(54,163,255,.10),rgba(109,34,255,.055))}.tv-download-tile .tile-icon{background:rgba(255,255,255,.06)}
.pwa-tile{position:relative;overflow:hidden;border-color:rgba(47,124,255,.22);background:linear-gradient(180deg,rgba(47,124,255,.12),rgba(255,255,255,.035))}
.pwa-tile:before{content:"";position:absolute;inset:auto -30px -50px auto;width:150px;height:150px;border-radius:50%;background:rgba(47,124,255,.13);filter:blur(28px);pointer-events:none}
.pwa-tile>*{position:relative;z-index:1}.pwa-tile .tile-icon{background:#fff}.pwa-tile .tile-icon img{width:100%;height:100%;object-fit:cover}
.pwa-install-btn{cursor:pointer;background:linear-gradient(135deg,#2f7cff,#6d22ff)!important;color:#fff!important;box-shadow:0 14px 30px rgba(47,124,255,.2)}
.pwa-install-btn.is-installed{background:rgba(34,197,94,.16)!important;color:#86efac!important;border:1px solid rgba(34,197,94,.28)!important;cursor:default}
.pwa-status{display:block;margin-top:7px;color:#a9c8ff;font-size:11px;line-height:1.7;font-weight:800}
.ios-web-tile{border-color:rgba(255,255,255,.16);background:linear-gradient(180deg,rgba(255,255,255,.085),rgba(255,255,255,.035))}.ios-web-tile .tile-icon{background:#f5f5f7}.ios-guide-btn{cursor:pointer;background:#f5f5f7!important;color:#111!important}
.pwa-manual-note{margin:14px 0 0;padding:13px 15px;border-radius:18px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.09);color:rgba(255,255,255,.7);font-size:12px;line-height:1.9}
.pwa-manual-note[hidden]{display:none}.hero-pwa{border:1px solid rgba(47,124,255,.28)!important;background:rgba(47,124,255,.1)!important;color:#dbeafe!important;cursor:pointer}
@media(max-width:1180px){.download-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:680px){.download-grid{grid-template-columns:1fr}.pwa-tile:before{display:none}}

/* V99 shared site header on the application page */
body.page-app #siteHeader{position:sticky;top:0;z-index:1400}
body.page-app #siteHeader.header-solid{background:rgba(5,7,12,.95)!important}
body.page-app .bm-app-page{position:relative;z-index:1}
.app-menu-overlay{position:fixed;inset:0;z-index:1600;background:rgba(0,0,0,.66);opacity:0;visibility:hidden;transition:.2s ease}
.app-menu-overlay.active{opacity:1;visibility:visible}
.app-side-menu{position:fixed;top:0;bottom:0;inset-inline-start:0;z-index:1610;width:min(330px,86vw);padding:20px;background:rgba(8,10,17,.985);border-inline-end:1px solid rgba(255,255,255,.09);box-shadow:0 0 60px rgba(0,0,0,.55);transform:translateX(110%);transition:transform .24s cubic-bezier(.2,.8,.2,1);display:flex;flex-direction:column;gap:18px}
html[dir="ltr"] .app-side-menu{transform:translateX(-110%)}
.app-side-menu.open{transform:translateX(0)}
.app-side-head{display:flex;align-items:center;justify-content:space-between;gap:12px}.app-side-head strong{font-size:19px}.app-side-head button{width:42px;height:42px;border-radius:14px;border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.06);color:#fff;font-size:25px;cursor:pointer}
.app-side-menu nav{display:grid;gap:8px}.app-side-menu nav a{padding:13px 14px;border-radius:15px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.06);font-weight:900}.app-side-menu nav a:hover{background:rgba(var(--accent-rgb),.13);border-color:rgba(var(--accent-rgb),.3);color:var(--accent)}
body.app-menu-open{overflow:hidden}
@media(min-width:992px){.app-menu-overlay,.app-side-menu{display:none!important}}



/* V101: isolate the real shared header from application-page component styles. */
body.page-app #siteHeader{
  position:sticky !important;
  top:0 !important;
  z-index:20000 !important;
  min-height:78px !important;
  background:rgba(4,6,12,.97) !important;
  border-bottom:1px solid rgba(255,255,255,.085) !important;
  box-shadow:0 12px 34px rgba(0,0,0,.24) !important;
  backdrop-filter:blur(16px) saturate(125%) !important;
  -webkit-backdrop-filter:blur(16px) saturate(125%) !important;
  isolation:isolate !important;
}
body.page-app #siteHeader .header-inner{
  width:min(1420px,calc(100% - 28px)) !important;
  max-width:1420px !important;
  height:78px !important;
  min-height:78px !important;
  margin:0 auto !important;
  padding:0 10px !important;
  position:relative !important;
  z-index:2 !important;
}
body.page-app #siteHeader .header-actions{
  display:flex !important;
  align-items:center !important;
  gap:9px !important;
  flex-shrink:0 !important;
  position:relative !important;
  z-index:4 !important;
}
body.page-app #siteHeader .desktop-nav{position:relative !important;z-index:3 !important}
body.page-app #siteHeader .logo{position:relative !important;z-index:4 !important}
body.page-app .bm-app-page{position:relative !important;z-index:1 !important;isolation:isolate !important}
body.page-app .bm-app-page .hero,
body.page-app .bm-app-page .visual,
body.page-app .bm-app-page .phone-mock,
body.page-app .bm-app-page .desktop-mock{z-index:1 !important}
body.page-app .download.secondary,
body.page-app .download.secondary span,
body.page-app button.download.secondary,
body.page-app .ios-web-tile,
body.page-app .ios-web-tile h3,
body.page-app .ios-web-tile p{color:#fff !important}
body.page-app .ios-guide-btn{color:#111 !important}

@media(max-width:991px){
  body.page-app #siteHeader{min-height:72px !important}
  body.page-app #siteHeader .header-inner{height:72px !important;min-height:72px !important;width:calc(100% - 10px) !important;margin:0 auto !important;padding:0 8px !important}
  body.page-app #siteHeader .header-actions{height:72px !important;min-height:72px !important}
  body.page-app #siteHeader .bm-header-logo-img{height:39px !important;max-width:132px !important}
  body.page-app .bm-app-page main{padding-top:10px !important}
  body.page-app .hero{padding-top:34px !important}
}
@media(min-width:992px){
  body.page-app .hero{padding-top:46px !important}
  body.page-app #siteHeader.header-solid{background:rgba(4,6,12,.985) !important}
}

</style>

<style id="bm-v102-mobile-nav-guard">@media (min-width:992px){html body.page-app .bottom-nav{display:none!important;visibility:hidden!important;pointer-events:none!important}}</style>
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body class="page-app" data-theme="<?= htmlspecialchars($userTheme, ENT_QUOTES, 'UTF-8') ?>">
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>
<div class="sidebar-menu" id="sidebarMenu" aria-hidden="true">
  <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="بستن"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
  <?php if($currentUser): ?><div class="sidebar-user"><div class="sidebar-username"><?= htmlspecialchars((string)($currentUser['username'] ?? 'کاربر'), ENT_QUOTES, 'UTF-8') ?></div><div class="sidebar-userrole"><?= (($currentUser['role'] ?? '') === 'admin') ? 'مدیر' : 'کاربر' ?></div></div><?php endif; ?>
  <div class="sidebar-nav">
    <a href="/" class="sidebar-item"><span>خانه</span></a>
    <a href="/search" class="sidebar-item"><span>جستجو</span></a>
    <a href="/collections" class="sidebar-item"><span>کالکشن‌ها</span></a>
    <a href="/player" class="sidebar-item"><span>پلیر</span></a>
    <a href="/application" class="sidebar-item"><span>اپلیکیشن</span></a>
    <a href="<?= $currentUser ? '/profile' : '/login' ?>" class="sidebar-item"><span><?= $currentUser ? 'پروفایل' : 'ورود' ?></span></a>
  </div>
</div>
<?php $bmHeaderClass='header'; require __DIR__ . '/partials/shared_header.php'; ?>
<div class="bm-app-page">
<main>
  <section class="hero">
    <div class="container hero-grid">
      <div>
        <div class="kicker"><svg viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg><span>نسخه <?= htmlspecialchars($bmAppVersion, ENT_QUOTES, 'UTF-8') ?> <?= bm_site_h(bm_site_get('app_kicker_suffix_fa','برای Android 6+')) ?></span></div>
        <h1><?= bm_site_h(bm_site_get('app_hero_title_fa','دانلود اپلیکیشن ها')) ?></h1>
        <p class="lead"><?= bm_site_h(bm_site_get('app_hero_lead_fa','اپلیکیشن اندروید بانک مووی با تجربه‌ای سریع، روان و بهینه برای موبایل، Android TV و Android Box منتشر شد. بعد از نصب، بدون محدودیت از دنیایی از فیلم و سریال بدون سانسور لذت ببر.')) ?></p>
        <div class="hero-actions">
          <a class="download primary" href="<?= htmlspecialchars($bmApkUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><img src="/assets/icons/bm-android-icon.svg" alt=""><span><?= bm_site_h(bm_site_get('app_apk_button_fa','دانلود مستقیم APK')) ?><?= $bmApkSize !== '' ? ' · ' . htmlspecialchars($bmApkSize, ENT_QUOTES, 'UTF-8') : '' ?></span></a>
          <a class="download secondary" href="<?= htmlspecialchars($bmApkUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><img src="/assets/icons/bm-tv-icon.svg" alt="Android TV"><span><?= bm_site_h(bm_site_get('app_tv_button_fa','دانلود نسخه تلویزیون')) ?></span></a>
          <a class="download secondary" href="<?= htmlspecialchars($bmZipUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener"><img src="/assets/icons/bm-zip-icon.svg" alt=""><span><?= bm_site_h(bm_site_get('app_zip_button_fa','دانلود ZIP کم‌حجم')) ?><?= $bmZipSize !== '' ? ' · ' . htmlspecialchars($bmZipSize, ENT_QUOTES, 'UTF-8') : '' ?></span></a>
          <button class="download hero-pwa" type="button" data-bm-pwa-install><img src="/assets/icons/icon-192.png?v=102.2" alt=""><span data-bm-pwa-button-label><?= bm_site_h(bm_site_get('app_pwa_button_fa','نصب مستقیم نسخه وب')) ?></span></button>
          <button class="download secondary" type="button" data-bm-ios-guide><img src="/assets/icons/bm-apple-icon.svg" alt="Apple"><span><?= bm_site_h(bm_site_get('app_ios_button_fa','نسخه وب مناسب آیفون')) ?></span></button>
          <span class="download soon"><img src="/assets/icons/bm-windows-icon.svg" alt="" aria-hidden="true"><span><?= bm_site_h(bm_site_get('app_windows_soon_fa','نسخه ویندوز به‌زودی')) ?></span></span>
        </div>
        <div class="quick-tags"><span>کاملاً رایگان</span><span>بدون نیاز به ثبت‌نام</span><span>پلیر داخلی قدرتمند</span><span>سازگار با ریموت TV</span></div>
      </div>
      <div class="visual">
        <div class="orbit"></div><div class="orbit o2"></div>
        <div class="desktop-mock"><div class="desktop-bar"><i></i><i></i><i></i></div><div class="desktop-screen"><img src="/assets/app/bankmovie-app-screen-collections-real.webp" alt="BankMovie app" loading="lazy" decoding="async"></div></div>
        <div class="phone-mock"><div class="phone-screen"><img src="/assets/app/bankmovie-app-screen-home-real.webp" alt="BankMovie app" decoding="async" fetchpriority="high"><div class="play-float"><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></div></div></div>
        <div class="stat-row"><div class="stat"><b><?= htmlspecialchars($bmAppVersion, ENT_QUOTES, 'UTF-8') ?></b><span>نسخه جدید</span></div><div class="stat"><b>6+</b><span>اندروید</span></div><div class="stat"><b>TV</b><span>ریموت کنترل</span></div></div>
      </div>
    </div>
  </section>

  <?php if ($bmAppChanges !== []): ?>
  <section class="section">
    <div class="container">
      <div class="section-head">
        <div>
          <h2><?= bm_site_h(bm_site_get('app_changes_title_fa','تغییرات آخرین نسخه')) ?></h2>
          <p><?= bm_site_h(bm_site_get('app_changes_description_fa','این بخش مستقیماً از اطلاعات آخرین به‌روزرسانی خوانده می‌شود.')) ?></p>
        </div>
      </div>
      <div class="release-card">
        <div class="release-top">
          <span class="release-version">نسخه <?= htmlspecialchars($bmAppVersion, ENT_QUOTES, 'UTF-8') ?></span>
          <?php if (!empty($bmAppUpdate['build'])): ?>
            <span class="release-build">Build <?= (int)$bmAppUpdate['build'] ?></span>
          <?php endif; ?>
        </div>
        <ul class="release-list">
          <?php foreach ($bmAppChanges as $change): ?>
            <li><?= htmlspecialchars((string)$change, ENT_QUOTES, 'UTF-8') ?></li>
          <?php endforeach; ?>
        </ul>
      </div>
    </div>
  </section>
  <?php endif; ?>

  <section class="section"><div class="container"><div class="section-head"><div><h2><?= bm_site_h(bm_site_get('app_features_title_fa','چرا بانک مووی؟')) ?></h2><p><?= bm_site_h(bm_site_get('app_features_description_fa','قابلیت‌های اصلی نسخه اندروید بانک مووی برای تماشای راحت‌تر و سریع‌تر.')) ?></p></div></div>
    <div class="cards">
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z"/></svg></div><h3>سرعت فوق‌العاده بالا</h3><p>اپلیکیشن کاملاً بهینه برای موبایل و تلویزیون با اجرای سبک و سریع.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><path d="M4 6h16"/><path d="M8 12h8"/><path d="M10 18h4"/></svg></div><h3>واچ‌لیست و آخرین بازدید</h3><p>دارای واچ‌لیست، آخرین تماشا شده‌ها و آخرین بازدیدها.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></div><h3>پلیر داخلی و خارجی</h3><p>پخش عادی با پلیر داخلی انجام می‌شود؛ برای نمایش صحیح سافت‌ساب حتماً از پلیر خارجی استفاده کن.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 20h8"/><path d="M12 18v2"/></svg></div><h3>تلویزیون و اندروید باکس</h3><p>سازگار با گوشی، Android TV و Android Box با پشتیبانی کامل ریموت.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9 12l2 2 4-4"/></svg></div><h3>رایگان و بدون ثبت‌نام</h3><p>بعد از نصب، بدون محدودیت و بدون ساخت حساب کاربری استفاده کن.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><path d="M5 12a7 7 0 0 1 14 0"/><path d="M8 12a4 4 0 0 1 8 0"/><circle cx="12" cy="12" r="1.6"/></svg></div><h3>مصرف اینترنت بهینه</h3><p>حجم مناسب برنامه و مصرف اینترنت بهینه برای استفاده روزانه.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><path d="M3 6h18v12H3z"/><path d="M7 10h10"/><path d="M7 14h7"/></svg></div><h3>آرشیو بزرگ</h3><p>دسترسی به آرشیوی بزرگ از فیلم‌ها و سریال‌های بدون سانسور.</p></article>
      <article class="feature"><div class="feature-icon"><svg viewBox="0 0 24 24"><path d="M7 7h10v10H7z"/><path d="M4 10h3"/><path d="M17 10h3"/><path d="M4 14h3"/><path d="M17 14h3"/></svg></div><h3>کنترل با TV Remote</h3><p>تمام بخش‌های اپ با ریموت تلویزیون قابل کنترل هستند.</p></article>
    </div></div>
  </section>

  <section class="section"><div class="container"><div class="section-head"><div><h2><?= bm_site_h(bm_site_get('app_screenshots_title_fa','نمای اپلیکیشن')) ?></h2><p><?= bm_site_h(bm_site_get('app_screenshots_description_fa','برای بزرگ دیدن تصاویر، روی هر اسکرین‌شات بزن.')) ?></p></div></div>
    <div class="shots">
      <button class="shot js-shot" data-shot="0" type="button"><img src="/assets/app/bankmovie-app-screen-home-real.webp" alt="صفحه اصلی" loading="lazy" decoding="async"><span>صفحه اصلی</span></button>
      <button class="shot js-shot" data-shot="1" type="button"><img src="/assets/app/bankmovie-app-screen-detail-real.webp" alt="جزئیات فیلم" loading="lazy" decoding="async"><span>جزئیات فیلم</span></button>
      <button class="shot js-shot" data-shot="2" type="button"><img src="/assets/app/bankmovie-app-screen-collections-real.webp" alt="کالکشن‌ها" loading="lazy" decoding="async"><span>کالکشن‌ها</span></button>
    </div></div>
  </section>

  <section class="section"><div class="container"><div class="download-panel"><div class="section-head"><div><h2><?= bm_site_h(bm_site_get('app_download_section_title_fa','دانلود و نصب')) ?></h2><p><?= bm_site_h(bm_site_get('app_download_description_fa','نسخه APK و نسخه وب قابل نصب برای Android، iPhone، iPad و دسکتاپ در دسترس است.')) ?></p></div></div>
    <div class="download-grid">
      <article class="download-tile"><div class="tile-icon"><img src="/assets/icons/bm-android-icon.svg" alt="Android"></div><h3><?= bm_site_h(bm_site_get('app_android_tile_title_fa','دانلود APK')) ?></h3><p>نصب مستقیم برای گوشی و تبلت با Android 6 به بالا.<?php if ($bmApkSize !== ''): ?><span class="file-meta">حجم فایل: <?= htmlspecialchars($bmApkSize, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?></p><a class="go" href="<?= htmlspecialchars($bmApkUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">دانلود مستقیم</a></article>
      <article class="download-tile tv-download-tile"><div class="tile-icon"><img src="/assets/icons/bm-tv-icon.svg" alt="Android TV"></div><h3><?= bm_site_h(bm_site_get('app_tv_tile_title_fa','نسخه تلویزیون')) ?></h3><p>قابل نصب روی Android TV و Android Box با پشتیبانی ریموت و رابط مناسب نمایشگر بزرگ.<?php if ($bmApkSize !== ''): ?><span class="file-meta">حجم فایل: <?= htmlspecialchars($bmApkSize, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?></p><a class="go" href="<?= htmlspecialchars($bmApkUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">دانلود نسخه TV</a></article>
      <article class="download-tile pwa-tile"><div class="tile-icon"><img src="/assets/icons/icon-192.png?v=102.2" alt="BankMovie PWA"></div><h3><?= bm_site_h(bm_site_get('app_pwa_card_title_fa','نصب مستقیم نسخه وب')) ?></h3><p><?= bm_site_h(bm_site_get('app_pwa_card_description_fa','نصب مستقیم روی Android، Windows، macOS و Linux؛ بدون دانلود فایل و با اجرای مستقل.')) ?><span class="pwa-status" data-bm-pwa-status>در حال بررسی امکان نصب</span></p><button class="pwa-install-btn" type="button" data-bm-pwa-install><span data-bm-pwa-button-label><?= bm_site_h(bm_site_get('app_pwa_button_fa','نصب مستقیم نسخه وب')) ?></span></button></article>
      <article class="download-tile ios-web-tile"><div class="tile-icon"><img src="/assets/icons/bm-apple-icon.svg" alt="Apple"></div><h3><?= bm_site_h(bm_site_get('app_ios_tile_title_fa','نسخه وب مناسب آیفون')) ?></h3><p>مناسب iPhone و iPad؛ نصب از Safari روی Home Screen و اجرای تمام‌صفحه مثل اپلیکیشن.</p><button class="ios-guide-btn" type="button" data-bm-ios-guide>راهنمای نصب آیفون</button></article>
      <article class="download-tile"><div class="tile-icon"><img src="/assets/icons/bm-zip-icon.svg" alt="ZIP"></div><h3><?= bm_site_h(bm_site_get('app_zip_tile_title_fa','نسخه کم‌حجم (ZIP)')) ?></h3><p>فایل فشرده برای دانلود سریع‌تر و نگهداری آفلاین.<?php if ($bmZipSize !== ''): ?><span class="file-meta">حجم فایل: <?= htmlspecialchars($bmZipSize, ENT_QUOTES, 'UTF-8') ?></span><?php endif; ?></p><a class="soft" href="<?= htmlspecialchars($bmZipUrl, ENT_QUOTES, 'UTF-8') ?>" target="_blank" rel="noopener">دانلود نسخه کم‌حجم</a></article>
      <article class="download-tile soon-card"><div class="tile-icon"><img src="/assets/icons/bm-windows-icon.svg" alt="Windows"></div><h3>نسخه ویندوز</h3><p>نسخه ویندوز در حال آماده‌سازی است؛ تا آن زمان نسخه وب روی ویندوز قابل نصب است.</p><button class="soft" type="button" disabled>به‌زودی</button></article>
    </div><p class="pwa-manual-note" id="bmPwaManualNote" hidden>اگر دکمه نصب خودکار نمایش داده نشد، منوی مرورگر را باز کن و گزینه Install app یا Add to Home Screen را انتخاب کن. در آیفون و آیپد این کار باید از Safari انجام شود.</p></div></div>
  </section>
</main>

<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<div class="lightbox" id="lightbox" aria-hidden="true"><div class="lb-bg" data-close></div><div class="lb-wrap"><button class="lb-btn lb-close" data-close aria-label="بستن"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button><button class="lb-btn lb-prev" id="lbPrev" aria-label="قبلی"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><figure class="lb-fig"><img src="" id="lbImg" alt="اسکرین‌شات"></figure><button class="lb-btn lb-next" id="lbNext" aria-label="بعدی"><svg viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button></div></div>
<script>
(function(){
  const shots=['/assets/app/bankmovie-app-screen-home-real.webp','/assets/app/bankmovie-app-screen-detail-real.webp','/assets/app/bankmovie-app-screen-collections-real.webp'];
  let i=0;const box=document.getElementById('lightbox'),img=document.getElementById('lbImg');
  function set(n){i=(n+shots.length)%shots.length;img.src=shots[i]}
  function open(n){set(n);box.classList.add('open');box.setAttribute('aria-hidden','false');document.body.style.overflow='hidden'}
  function close(){box.classList.remove('open');box.setAttribute('aria-hidden','true');document.body.style.overflow=''}
  document.querySelectorAll('.js-shot').forEach(b=>b.addEventListener('click',()=>open(parseInt(b.dataset.shot||'0',10)||0)));
  document.querySelectorAll('[data-close]').forEach(b=>b.addEventListener('click',close));
  document.getElementById('lbPrev').addEventListener('click',()=>set(i-1));document.getElementById('lbNext').addEventListener('click',()=>set(i+1));
  document.addEventListener('keydown',e=>{if(!box.classList.contains('open'))return;if(e.key==='Escape')close();if(e.key==='ArrowLeft')set(i+1);if(e.key==='ArrowRight')set(i-1)});
  /* V59 corrected: shared/global bottom-nav controller only. */
  var bell=document.getElementById('notifBell');if(bell)bell.addEventListener('click',function(){location.href='<?= $currentUser ? '/profile#notifications' : '/login' ?>'});
  var header=document.getElementById('siteHeader');function syncHeader(){if(header)header.classList.toggle('header-solid',(scrollY||0)>24)}syncHeader();addEventListener('scroll',syncHeader,{passive:true});
})();
</script>
</div>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script>window.BM_SITE_PWA_LABELS = <?= json_encode([
  'direct' => (string)bm_site_get('pwa_direct_install_label_fa','نصب مستقیم نسخه وب'),
  'manual' => (string)bm_site_get('pwa_manual_label_fa','راهنمای نصب نسخه وب'),
  'ios' => (string)bm_site_get('app_ios_button_fa','نسخه وب مناسب آیفون'),
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="/assets/js/pwa.js?v=102.2" defer></script>
<script src="/assets/js/app-page.js?v=102.2" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
