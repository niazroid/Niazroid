<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/boxoffice.php';

if (session_status() === PHP_SESSION_ACTIVE) @session_write_close();

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('Cross-Origin-Resource-Policy: same-origin');
header("Content-Security-Policy: default-src 'none'; sandbox");
header('Cache-Control: public, max-age=86400, stale-while-revalidate=604800');

$key = strtolower(trim((string)($_GET['k'] ?? '')));
if (!preg_match('/^[a-f0-9]{32}$/', $key)) {
    http_response_code(404);
    exit;
}

// Reject direct document navigation; this endpoint exists only as an image resource.
$fetchDest = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_DEST'] ?? '')));
if ($fetchDest !== '' && $fetchDest !== 'image') {
    http_response_code(403);
    exit;
}

function bm_bo_image_token(array $item, string $image): string
{
    return substr(hash('sha256', (string)($item['rank'] ?? '') . '|' . strtolower((string)($item['id'] ?? '')) . '|' . $image), 0, 32);
}

function bm_bo_fetch_image_bytes(string $url): array
{
    $safe = function_exists('bm_boxoffice_safe_upstream_image') ? bm_boxoffice_safe_upstream_image($url) : '';
    if ($safe === '') throw new RuntimeException('invalid image source');

    $maxBytes = 5_000_000;
    $body = '';
    $status = 0;
    $contentType = '';

    if (function_exists('curl_init')) {
        $ch = curl_init($safe);
        if ($ch === false) throw new RuntimeException('curl init failed');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => false,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_HTTPHEADER => ['Accept: image/avif,image/webp,image/png,image/jpeg,image/gif;q=0.9,*/*;q=0.2'],
            CURLOPT_USERAGENT => 'BankMovie-Poster-Proxy/1.0',
            CURLOPT_REFERER => '',
            CURLOPT_COOKIE => '',
            CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$body, $maxBytes): int {
                if (strlen($body) + strlen($chunk) > $maxBytes) return 0;
                $body .= $chunk;
                return strlen($chunk);
            },
        ]);
        $ok = curl_exec($ch);
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $contentType = strtolower(trim((string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE)));
        $errNo = curl_errno($ch);
        curl_close($ch);
        if ($ok === false) {
            if ($errNo === CURLE_WRITE_ERROR && strlen($body) >= $maxBytes - 65536) throw new RuntimeException('image too large');
            throw new RuntimeException('image fetch failed');
        }
    } else {
        $context = stream_context_create([
            'http' => [
                'method' => 'GET', 'timeout' => 12, 'ignore_errors' => true,
                'follow_location' => 0, 'max_redirects' => 0,
                'header' => "Accept: image/avif,image/webp,image/png,image/jpeg,image/gif;q=0.9,*/*;q=0.2\r\nUser-Agent: BankMovie-Poster-Proxy/1.0\r\nConnection: close\r\n",
            ],
            'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
        ]);
        $result = @file_get_contents($safe, false, $context, 0, $maxBytes + 1);
        if (!is_string($result) || strlen($result) > $maxBytes) throw new RuntimeException('image fetch failed');
        $body = $result;
        foreach (($http_response_header ?? []) as $line) {
            if (preg_match('~^HTTP/\S+\s+(\d{3})~i', (string)$line, $m)) $status = (int)$m[1];
            if (stripos((string)$line, 'Content-Type:') === 0) $contentType = strtolower(trim(substr((string)$line, 13)));
        }
    }

    if ($status < 200 || $status >= 300 || $body === '') throw new RuntimeException('upstream image unavailable');
    $contentType = trim(explode(';', $contentType, 2)[0]);
    if (!in_array($contentType, ['image/jpeg','image/png','image/webp','image/gif','image/avif'], true)) {
        if (function_exists('finfo_buffer')) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $detected = strtolower((string)$finfo->buffer($body));
            if (in_array($detected, ['image/jpeg','image/png','image/webp','image/gif','image/avif'], true)) $contentType = $detected;
        }
    }
    if (!in_array($contentType, ['image/jpeg','image/png','image/webp','image/gif','image/avif'], true)) throw new RuntimeException('invalid image type');
    return [$body, $contentType];
}

try {
    $row = bm_boxoffice_cache_row($pdo, 'boxoffice_weekend_v3');
    $payload = bm_boxoffice_decode_cache_payload($row);
    $items = is_array($payload['items'] ?? null) ? $payload['items'] : [];
    $source = '';
    foreach ($items as $item) {
        if (!is_array($item)) continue;
        $candidate = trim((string)($item['image'] ?? ''));
        if ($candidate === '' || !preg_match('~^https://~i', $candidate)) continue;
        if (hash_equals(bm_bo_image_token($item, $candidate), $key)) {
            $source = $candidate;
            break;
        }
    }
    if ($source === '') {
        http_response_code(404);
        exit;
    }

    [$bytes, $mime] = bm_bo_fetch_image_bytes($source);
    $etag = '"' . substr(hash('sha256', $bytes), 0, 32) . '"';
    header('ETag: ' . $etag);
    if (trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')) === $etag) {
        http_response_code(304);
        exit;
    }
    header('Content-Type: ' . $mime);
    header('Content-Length: ' . strlen($bytes));
    header('Content-Disposition: inline; filename="bankmovie-poster"');
    echo $bytes;
} catch (Throwable $e) {
    error_log('BoxOffice image proxy error: ' . $e->getMessage());
    http_response_code(404);
}
