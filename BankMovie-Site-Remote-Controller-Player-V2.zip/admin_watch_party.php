<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/site_content_control.php';
require_once __DIR__ . '/includes/watch_party.php';

require_admin();
admin_enforce_csrf();
$schemaReady = bm_watch_party_schema($pdo);
if ($schemaReady) {
    // Purge expired rooms on every admin visit. The query is epoch-based, so DB/PHP timezone differences cannot extend access.
    bm_watch_party_cleanup_expired($pdo, 5000);
}
$schemaReport = bm_watch_party_schema_report($pdo);

$status = '';
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = strtolower(trim((string)($_POST['action'] ?? '')));
    try {
        if ($action === 'repair_schema') {
            $schemaReady = bm_watch_party_schema($pdo, true);
            $schemaReport = bm_watch_party_schema_report($pdo);
            if (!$schemaReady) throw new RuntimeException('تعمیر دیتابیس کامل نشد: ' . ((string)($schemaReport['last_error'] ?? '') ?: implode(',', (array)($schemaReport['missing_tables'] ?? []))));
            $status = 'ساختار دیتابیس Watch Party تعمیر و بررسی شد.';
        } elseif (in_array($action, ['create_room','create_test_room'], true)) {
            if (!$schemaReady && !bm_watch_party_schema($pdo, true)) {
                throw new RuntimeException('ساخت جدول‌های Watch Party انجام نشد: ' . (string)($GLOBALS['bm_watch_party_schema_error'] ?? 'unknown'));
            }
            $adminUser = admin_current_user();
            if (!$adminUser) throw new RuntimeException('مدیر وارد نشده است');
            $created = bm_watch_party_create_room($pdo, $adminUser, [
                'movie_id' => max(0, (int)($_POST['movie_id'] ?? 0)),
                'archive_no' => max(1, min(9, (int)($_POST['archive_no'] ?? 1))),
                'media_type' => (string)($_POST['media_type'] ?? 'movie'),
                'source_ref' => trim((string)($_POST['source_ref'] ?? 'watch-party')),
            ]);
            $_SESSION['watch_party_lab_last_room'] = (string)$created['invite_code'];
            header('Location: /watch-party?room=' . rawurlencode((string)$created['invite_code']) . '&host=1');
            exit;
        } elseif ($action === 'cleanup_expired') {
            $result = bm_watch_party_cleanup_expired($pdo, 5000);
            $status = 'پاکسازی انجام شد؛ ' . (int)$result['rooms_deleted'] . ' اتاق منقضی حذف شد.';
        } elseif ($action === 'save_features') {
            $currentSettings = function_exists('bm_site_settings') ? bm_site_settings() : [];
            foreach (['watch_party_enabled','watch_party_chat_enabled','watch_party_voice_enabled','watch_party_voice_guests_enabled'] as $featureKey) {
                $currentSettings[$featureKey] = !empty($_POST[$featureKey]);
            }
            if (!function_exists('bm_site_write_settings_file') || !bm_site_write_settings_file($currentSettings)) {
                throw new RuntimeException('ذخیره تنظیمات Watch Party انجام نشد.');
            }
            if (function_exists('bm_site_settings')) bm_site_settings(true);
            $status = 'تنظیمات Watch Party، Chat و Voice Call ذخیره شد.';
        } elseif ($action === 'close_room') {
            $roomId = max(0, (int)($_POST['room_id'] ?? 0));
            $stmt = $pdo->prepare('DELETE FROM watch_party_rooms WHERE id=?');
            $stmt->execute([$roomId]);
            $status = $stmt->rowCount() > 0 ? 'اتاق و تمام پیام‌ها و داده‌های وابسته حذف شد.' : 'اتاق پیدا نشد.';
        }
    } catch (Throwable $e) {
        $detail = preg_replace('/[\r\n\t]+/', ' ', $e->getMessage()) ?? $e->getMessage();
        $detail = function_exists('mb_substr') ? mb_substr($detail, 0, 300, 'UTF-8') : substr($detail, 0, 300);
        $status = 'عملیات انجام نشد: ' . $detail;
        error_log('Watch Party admin action error: ' . $e->getMessage());
    }
    header('Location: admin_watch_party.php?status=' . rawurlencode($status));
    exit;
}

$status = trim((string)($_GET['status'] ?? ''));
$stats = ['active_rooms'=>0,'members'=>0,'messages'=>0,'events'=>0,'vip_users'=>0];
$rooms = [];
$eventScheduler = 'unknown';
$expiryEventExists = false;
try {
    if (!$schemaReady) throw new RuntimeException('watch_party_schema_unavailable');
    $stats['active_rooms'] = (int)$pdo->query("SELECT COUNT(*) FROM watch_party_rooms WHERE (expires_at_epoch>UNIX_TIMESTAMP()) OR (expires_at_epoch=0 AND expires_at>NOW())")->fetchColumn();
    $stats['members'] = (int)$pdo->query('SELECT COUNT(*) FROM watch_party_members')->fetchColumn();
    $stats['messages'] = (int)$pdo->query('SELECT COUNT(*) FROM watch_party_messages')->fetchColumn();
    $stats['events'] = (int)$pdo->query('SELECT COUNT(*) FROM watch_party_events')->fetchColumn();
    if (bm_watch_party_column_exists($pdo, 'users', 'vip_expires_at')) {
        $stats['vip_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE LOWER(role) IN ('vip','premium','special') AND (vip_expires_at IS NULL OR vip_expires_at>NOW())")->fetchColumn();
    } else {
        $stats['vip_users'] = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE LOWER(role) IN ('vip','premium','special')")->fetchColumn();
    }
    try {
        $eventRow = $pdo->query("SHOW VARIABLES LIKE 'event_scheduler'")->fetch(PDO::FETCH_ASSOC);
        $eventScheduler = strtolower((string)($eventRow['Value'] ?? $eventRow['value'] ?? 'unknown'));
        $eventCheck = $pdo->prepare("SELECT COUNT(*) FROM information_schema.EVENTS WHERE EVENT_SCHEMA=DATABASE() AND EVENT_NAME='bm_watch_party_expiry_cleanup'");
        $eventCheck->execute();
        $expiryEventExists = (int)$eventCheck->fetchColumn() > 0;
    } catch (Throwable $e) {
        // Shared hosts may hide event metadata. Strict request cleanup still works.
    }
    $rooms = $pdo->query("SELECT r.id,r.host_user_id,r.movie_id,r.archive_no,r.media_type,r.source_ref,r.status,r.max_members,r.created_at,r.expires_at,r.last_activity_at,
        COALESCE(u.username,CONCAT('کاربر #',r.host_user_id)) host_name,
        (SELECT COUNT(*) FROM watch_party_members m WHERE m.room_id=r.id) member_count,
        (SELECT COUNT(*) FROM watch_party_messages c WHERE c.room_id=r.id) message_count,
        (SELECT COUNT(*) FROM watch_party_events e WHERE e.room_id=r.id) event_count
        FROM watch_party_rooms r
        LEFT JOIN users u ON u.id=r.host_user_id
        WHERE (r.expires_at_epoch>UNIX_TIMESTAMP()) OR (r.expires_at_epoch=0 AND r.expires_at>NOW())
        ORDER BY COALESCE(NULLIF(r.expires_at_epoch,0),UNIX_TIMESTAMP(r.expires_at)) ASC
        LIMIT 100")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    error_log('Watch Party admin stats error: ' . $e->getMessage());
}

function wp_admin_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

$masterEnabled = bm_watch_party_is_enabled();
$chatEnabled = function_exists('bm_watch_party_chat_enabled') ? bm_watch_party_chat_enabled() : bm_site_bool('watch_party_chat_enabled', true);
$voiceEnabled = function_exists('bm_site_bool') ? bm_site_bool('watch_party_voice_enabled', true) : true;
$voiceGuestsEnabled = function_exists('bm_site_bool') ? bm_site_bool('watch_party_voice_guests_enabled', true) : true;
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>مدیریت Watch Party | BankMovie</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 80% 0,rgba(124,58,237,.2),transparent 28rem),#070911;color:#f8fafc;font-family:Vazirmatn,Tahoma,sans-serif}.wrap{width:min(1180px,calc(100% - 32px));margin:32px auto 70px}.top{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap;margin-bottom:20px}.title h1{margin:0 0 8px;font-size:clamp(25px,4vw,42px)}.title p{margin:0;color:#9ca3af;line-height:1.9}.actions{display:flex;gap:10px;flex-wrap:wrap}.btn{border:1px solid rgba(255,255,255,.12);border-radius:14px;padding:11px 16px;background:#111827;color:#fff;text-decoration:none;cursor:pointer;font:inherit}.btn.primary{background:linear-gradient(135deg,#7c3aed,#2563eb)}.btn.danger{background:rgba(239,68,68,.12);border-color:rgba(239,68,68,.35);color:#fecaca}.notice{margin:16px 0;padding:14px 16px;border:1px solid rgba(34,197,94,.3);border-radius:15px;background:rgba(34,197,94,.08);color:#bbf7d0}.security{margin:18px 0;padding:18px;border:1px solid rgba(245,158,11,.28);border-radius:18px;background:rgba(245,158,11,.08);line-height:2;color:#fde68a}.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin:20px 0}.card{padding:20px;border:1px solid rgba(255,255,255,.09);border-radius:20px;background:rgba(17,24,39,.78);box-shadow:0 20px 50px rgba(0,0,0,.2)}.card strong{display:block;font-size:30px;margin-bottom:5px}.card span{color:#9ca3af}.state{display:flex;align-items:center;gap:8px}.dot{width:10px;height:10px;border-radius:50%;background:#ef4444;box-shadow:0 0 12px rgba(239,68,68,.65)}.dot.on{background:#22c55e;box-shadow:0 0 12px rgba(34,197,94,.65)}.panel{border:1px solid rgba(255,255,255,.09);border-radius:22px;overflow:hidden;background:rgba(10,14,25,.9)}.panel-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.08)}.panel-head h2{margin:0;font-size:18px}.table-wrap{overflow:auto}.table{width:100%;border-collapse:collapse;min-width:980px}.table th,.table td{padding:14px 12px;text-align:right;border-bottom:1px solid rgba(255,255,255,.06);font-size:13px}.table th{color:#a5b4fc;background:rgba(255,255,255,.025)}.muted{color:#94a3b8}.pill{display:inline-flex;padding:5px 9px;border-radius:999px;background:rgba(124,58,237,.15);color:#ddd6fe}.empty{padding:48px;text-align:center;color:#94a3b8}.feature-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;padding:18px}.feature-toggle{position:relative;display:flex;align-items:flex-start;gap:12px;padding:15px;border:1px solid rgba(255,255,255,.09);border-radius:17px;background:rgba(255,255,255,.025);cursor:pointer}.feature-toggle input{position:absolute;opacity:0;pointer-events:none}.feature-switch{width:44px;height:24px;border-radius:999px;background:#20283a;border:1px solid rgba(255,255,255,.1);padding:3px;flex:0 0 auto;transition:.2s}.feature-switch i{display:block;width:16px;height:16px;border-radius:50%;background:#94a3b8;transition:.2s}.feature-toggle input:checked+.feature-switch{background:rgba(34,197,94,.16);border-color:rgba(34,197,94,.38)}.feature-toggle input:checked+.feature-switch i{transform:translateX(20px);background:#22c55e;box-shadow:0 0 13px rgba(34,197,94,.55)}.feature-copy strong{display:block;font-size:13px;margin-bottom:5px}.feature-copy small{display:block;color:#94a3b8;font-size:11px;line-height:1.8}.feature-save{padding:0 18px 18px;display:flex;justify-content:flex-end;gap:10px;align-items:center}.feature-note{margin-inline-end:auto;color:#94a3b8;font-size:11px;line-height:1.8}@media(max-width:820px){.cards{grid-template-columns:repeat(2,1fr)}.feature-grid{grid-template-columns:1fr 1fr}.panel form[style*='grid-template-columns']{grid-template-columns:1fr!important}}@media(max-width:520px){.feature-grid{grid-template-columns:1fr;padding:12px}.feature-save{padding:0 12px 14px;flex-direction:column;align-items:stretch}.feature-note{margin:0}.wrap{width:min(100% - 20px,1180px);margin-top:18px}.cards{grid-template-columns:1fr 1fr}.card{padding:15px}.card strong{font-size:24px}}
</style>

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<main class="wrap">
  <div class="top">
    <div class="title">
      <h1>مدیریت Watch Party</h1>
      <p>مدیریت اتاق‌های تماشای دونفره، وضعیت همگام‌سازی، پاکسازی و دسترسی اعضای VIP.</p>
    </div>
    <div class="actions">
      <a class="btn primary" href="/watch-party">ورود به Watch Party</a>
      <a class="btn" href="admin.php#vipSection">مرکز VIP</a>
      <a class="btn" href="admin.php#vipSection">تنظیمات قابلیت</a>
      <a class="btn" href="admin_stickers.php">مدیریت استیکر و گیف</a>
      
      <form method="post">
        <?= admin_csrf_input() ?>
        <input type="hidden" name="action" value="repair_schema">
        <button class="btn <?= $schemaReady ? '' : 'danger' ?>" type="submit">تعمیر دیتابیس</button>
      </form>
      <form method="post" onsubmit="return confirm('اتاق‌های منقضی و تمام داده‌های وابسته حذف شوند؟')">
        <?= admin_csrf_input() ?>
        <input type="hidden" name="action" value="cleanup_expired">
        <button class="btn primary" type="submit">پاکسازی فوری</button>
      </form>
    </div>
  </div>

  <?php if ($status !== ''): ?><div class="notice"><?= wp_admin_h($status) ?></div><?php endif; ?>

  <div class="security">
    <div class="state"><span class="dot <?= $masterEnabled?'on':'' ?>"></span><b>فعال‌سازی اصلی:</b> <?= $masterEnabled?'روشن':'غیرفعال' ?></div>
    <div class="state"><span class="dot <?= $chatEnabled?'on':'' ?>"></span><b>Chat:</b> <?= $chatEnabled?'فعال':'غیرفعال' ?></div>
    <div class="state"><span class="dot <?= $voiceEnabled?'on':'' ?>"></span><b>Voice Call:</b> <?= $voiceEnabled ? ($voiceGuestsEnabled?'VIP + مهمان دعوتی':'فقط کاربران VIP') : 'غیرفعال' ?></div>
    
    <div class="state"><span class="dot <?= $schemaReady?'on':'' ?>"></span><b>دیتابیس Watch Party:</b> <?= $schemaReady?'سالم و آماده':'ناقص؛ روی تعمیر دیتابیس بزنید' ?></div>
    <div class="state"><span class="dot <?= ($eventScheduler==='on' && $expiryEventExists)?'on':'' ?>"></span><b>پاکسازی بدون بازدید:</b> <?= ($eventScheduler==='on' && $expiryEventExists)?'رویداد دقیقه‌ای MySQL فعال است':'برای تضمین حذف فیزیکی روی سرور کاملاً بی‌ترافیک، Cron دقیقه‌ای را فعال کنید' ?></div>
    <?php if (!$schemaReady): ?><div class="muted">جزئیات: <?= wp_admin_h((string)($schemaReport['last_error'] ?? '') ?: implode(', ', (array)($schemaReport['missing_tables'] ?? []))) ?></div><?php endif; ?>
    عمر هر اتاق از لحظه ساخت دقیقاً حداکثر <b>۴ ساعت</b> است و تمدید نمی‌شود. کنترل انقضا بر اساس Unix Timestamp انجام می‌شود تا اختلاف ساعت PHP و MySQL باعث تمدید ناخواسته نشود. با پایان زمان، ورود فوراً مسدود و اتاق همراه لینک، اعضا، پیام‌ها، وضعیت پخش و رویدادها حذف می‌شود.
  </div>

  <section class="panel" style="margin:20px 0;overflow:visible;">
    <div class="panel-head"><h2>کنترل قابلیت‌های Watch Party</h2><span class="muted">اعمال مستقیم برای کاربران جدید و درخواست‌های API</span></div>
    <form method="post">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="action" value="save_features">
      <div class="feature-grid">
        <label class="feature-toggle"><input type="checkbox" name="watch_party_enabled" value="1" <?= $masterEnabled?'checked':'' ?>><span class="feature-switch"><i></i></span><span class="feature-copy"><strong>Watch Party</strong><small>کل سرویس ساخت و ورود به اتاق را روشن یا خاموش می‌کند.</small></span></label>
        <label class="feature-toggle"><input type="checkbox" name="watch_party_chat_enabled" value="1" <?= $chatEnabled?'checked':'' ?>><span class="feature-switch"><i></i></span><span class="feature-copy"><strong>Chat</strong><small>پیام، ایموجی و استیکر داخل اتاق. خاموش شود، API هم ارسال پیام را رد می‌کند.</small></span></label>
        <label class="feature-toggle"><input type="checkbox" name="watch_party_voice_enabled" value="1" <?= $voiceEnabled?'checked':'' ?>><span class="feature-switch"><i></i></span><span class="feature-copy"><strong>Voice Call</strong><small>تماس صوتی برای تمام اعضای VIP حاضر در اتاق.</small></span></label>
        <label class="feature-toggle"><input type="checkbox" name="watch_party_voice_guests_enabled" value="1" <?= $voiceGuestsEnabled?'checked':'' ?>><span class="feature-switch"><i></i></span><span class="feature-copy"><strong>Voice Call مهمان</strong><small>همراه ناشناسِ واردشده با لینک خصوصی اتاق نیز بتواند تماس بگیرد و پاسخ دهد.</small></span></label>
      </div>
      <div class="feature-save"><span class="feature-note">صدا روی دیسک هاست ذخیره نمی‌شود؛ PHP فقط Signaling کوتاه‌عمر WebRTC را مدیریت می‌کند.</span><button class="btn primary" type="submit">ذخیره تنظیمات</button></div>
    </form>
  </section>

  <section class="panel" style="margin:20px 0;overflow:visible;">
    <div class="panel-head"><h2>ساخت فوری اتاق</h2><span class="muted">اتاق خصوصی چهار ساعته</span></div>
    <form method="post" style="display:grid;grid-template-columns:1fr 130px 150px 1fr auto;gap:10px;padding:18px;align-items:end;">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="action" value="create_room">
      <label class="muted">شناسه فیلم (اختیاری)<input name="movie_id" type="number" min="0" value="0" style="display:block;width:100%;margin-top:6px;padding:11px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:#0b1020;color:#fff"></label>
      <label class="muted">آرشیو<select name="archive_no" style="display:block;width:100%;margin-top:6px;padding:11px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:#0b1020;color:#fff"><option value="1">آرشیو ۱</option><option value="2">آرشیو ۲</option></select></label>
      <label class="muted">نوع<select name="media_type" style="display:block;width:100%;margin-top:6px;padding:11px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:#0b1020;color:#fff"><option value="movie">فیلم</option><option value="series">سریال</option><option value="episode">قسمت سریال</option></select></label>
      <label class="muted">شناسه منبع امن<input name="source_ref" value="watch-party" maxlength="190" style="display:block;width:100%;margin-top:6px;padding:11px;border-radius:12px;border:1px solid rgba(255,255,255,.12);background:#0b1020;color:#fff"></label>
      <button class="btn primary" type="submit">ساخت و بازکردن</button>
    </form>
  </section>

  <section class="cards">
    <div class="card"><strong><?= (int)$stats['active_rooms'] ?></strong><span>اتاق فعال</span></div>
    <div class="card"><strong><?= (int)$stats['members'] ?></strong><span>عضو موقت</span></div>
    <div class="card"><strong><?= (int)$stats['messages'] ?></strong><span>پیام موقت</span></div>
    <div class="card"><strong><?= (int)$stats['events'] ?></strong><span>رویداد همگام‌سازی</span></div>
    <div class="card"><strong><?= (int)$stats['vip_users'] ?></strong><span>کاربر VIP فعال</span></div>
  </section>

  <section class="panel">
    <div class="panel-head"><h2>اتاق‌های موقت</h2><span class="muted">حداکثر ۱۰۰ رکورد</span></div>
    <?php if (!$rooms): ?>
      <div class="empty">در حال حاضر اتاق فعالی وجود ندارد.</div>
    <?php else: ?>
      <div class="table-wrap"><table class="table">
        <thead><tr><th>شناسه</th><th>میزبان</th><th>محتوا</th><th>منبع امن</th><th>اعضا</th><th>پیام / رویداد</th><th>ایجاد</th><th>انقضا</th><th>عملیات</th></tr></thead>
        <tbody>
        <?php foreach ($rooms as $room): ?>
          <tr>
            <td>#<?= (int)$room['id'] ?></td>
            <td><?= wp_admin_h($room['host_name']) ?></td>
            <td><span class="pill"><?= wp_admin_h($room['media_type']) ?> · آرشیو <?= (int)$room['archive_no'] ?></span><div class="muted">Movie ID: <?= $room['movie_id']!==null?(int)$room['movie_id']:'—' ?></div></td>
            <td><?= $room['source_ref']!==null?wp_admin_h($room['source_ref']):'ذخیره نشده' ?></td>
            <td><?= (int)$room['member_count'] ?> / <?= (int)$room['max_members'] ?></td>
            <td><?= (int)$room['message_count'] ?> / <?= (int)$room['event_count'] ?></td>
            <td><?= wp_admin_h($room['created_at']) ?></td>
            <td><?= wp_admin_h($room['expires_at']) ?></td>
            <td><form method="post" onsubmit="return confirm('این اتاق و تمام داده‌هایش حذف شود؟')"><?= admin_csrf_input() ?><input type="hidden" name="action" value="close_room"><input type="hidden" name="room_id" value="<?= (int)$room['id'] ?>"><button type="submit" class="btn danger">حذف کامل</button></form></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    <?php endif; ?>
  </section>
</main>
</body>
</html>
