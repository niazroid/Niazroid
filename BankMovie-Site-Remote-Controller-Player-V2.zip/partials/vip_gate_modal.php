<?php
require_once dirname(__DIR__) . '/includes/vip_features.php';
if (!empty($GLOBALS['bmVipGateModalRendered'])) return;
$GLOBALS['bmVipGateModalRendered'] = true;

$bmVipGateUser = $currentUser ?? null;
$bmArchiveVipGateLocks = is_array($GLOBALS['bmArchiveVipGateLocks'] ?? null) ? $GLOBALS['bmArchiveVipGateLocks'] : [];
$bmVipGateLocks = [
    'downloads' => !bm_vip_gate_allows('downloads', $bmVipGateUser) || !empty($bmArchiveVipGateLocks['downloads']),
    'subtitle_downloads' => !bm_vip_gate_allows('subtitle_downloads', $bmVipGateUser),
    'online_watch' => !bm_vip_gate_allows('online_watch', $bmVipGateUser) || !empty($bmArchiveVipGateLocks['online_watch']),
    'online_player' => !bm_vip_gate_allows('online_player', $bmVipGateUser),
    'watch_party' => bm_vip_feature_enabled('watch_party') && !bm_vip_user_is_active($bmVipGateUser),
    'watchlist' => !bm_vip_gate_allows('watchlist', $bmVipGateUser),
    'comments_ratings' => !bm_vip_gate_allows('comments_ratings', $bmVipGateUser),
];
if (!in_array(true, $bmVipGateLocks, true)) return;
?>
<link rel="stylesheet" href="/assets/css/bm-vip-gate-modal-v14839.css?v=14839">
<div class="bm-vip-gate-modal" id="bmVipGateModal" hidden aria-hidden="true">
    <div class="bm-vip-gate-backdrop" data-bm-vip-close></div>
    <section class="bm-vip-gate-dialog" role="dialog" aria-modal="true" aria-labelledby="bmVipGateTitle" tabindex="-1">
        <span class="bm-vip-gate-glow"></span><span class="bm-vip-gate-glow second"></span>
        <button type="button" class="bm-vip-gate-close" data-bm-vip-close aria-label="بستن">
            <svg viewBox="0 0 24 24"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>
        <div class="bm-vip-gate-body">
            <div class="bm-vip-gate-emblem" aria-hidden="true">
                <svg viewBox="0 0 24 24"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 11H5L3 7Z"/><path d="M6 18h12"/></svg>
            </div>
            <span class="bm-vip-gate-kicker"><i></i>BANKMOVIE VIP</span>
            <h2 class="bm-vip-gate-title" id="bmVipGateTitle" data-bm-vip-modal-title>این قابلیت ویژه اعضای VIP است</h2>
            <p class="bm-vip-gate-description" data-bm-vip-modal-description>برای استفاده از این قابلیت، اشتراک VIP فعال لازم است.</p>
            <div class="bm-vip-gate-note">
                <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>
                <span data-bm-vip-modal-note></span>
            </div>
            <div class="bm-vip-gate-actions" data-bm-vip-modal-actions>
                <a class="bm-vip-gate-action primary" href="/vip" data-bm-vip-purchase>
                    <svg viewBox="0 0 24 24"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 11H5L3 7Z"/></svg>
                    مشاهده پلن‌ها و خرید VIP
                </a>
                <a class="bm-vip-gate-action secondary" href="/login" data-bm-vip-login data-bm-vip-guest-only>
                    <svg viewBox="0 0 24 24"><path d="M10 17l5-5-5-5M15 12H3"/><path d="M14 3h4a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3h-4"/></svg>
                    ورود به حساب
                </a>
                <a class="bm-vip-gate-action ghost" href="/register" data-bm-vip-register data-bm-vip-guest-only>
                    <svg viewBox="0 0 24 24"><path d="M15 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M19 8v6M22 11h-6"/></svg>
                    ثبت‌نام رایگان
                </a>
                <button type="button" class="bm-vip-gate-action ghost" data-bm-vip-close>فعلاً نه</button>
            </div>
            <p class="bm-vip-gate-foot">فعال‌سازی اشتراک پس از هماهنگی با پشتیبانی بانک‌مووی انجام می‌شود.</p>
        </div>
    </section>
</div>
<script>
window.BM_VIP_GATES={
  loggedIn:<?= $bmVipGateUser ? 'true' : 'false' ?>,
  salesPath:'/vip',loginPath:'/login',registerPath:'/register',
  locks:<?= json_encode($bmVipGateLocks, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>
};
</script>
<script src="/assets/js/bm-vip-gates-v14861970.js?v=14861970" defer></script>
