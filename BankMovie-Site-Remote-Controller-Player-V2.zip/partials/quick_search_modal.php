<?php
// One shared quick-search modal for every public page, including index.php.
// Keeping one markup source prevents page-specific CSS and HTML drift.
$bmQuickPage = basename((string)($_SERVER['SCRIPT_NAME'] ?? 'index.php'));

require_once __DIR__ . '/../includes/archive_control.php';
require_once __DIR__ . '/../includes/site_content_control.php';
$bmQuickLang = (($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')) === 'en') ? 'en' : 'fa';
$bmQuickEsc = static function ($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$bmQuickArchiveConfig = function_exists('bm_archive_public_config') ? bm_archive_public_config() : [];
$bmQuickDefaultMode = function_exists('bm_archive_default_mode') ? bm_archive_default_mode() : 'local';
$bmQuickKicker = $bmQuickLang === 'fa' ? (string)bm_site_get('search_kicker_fa','جستجوی سریع') : 'Quick search';
$bmQuickTitle = $bmQuickLang === 'fa' ? (string)bm_site_get('search_title_fa','فیلم، سریال یا بازیگر موردنظرت را پیدا کن') : 'Find the movie, series or actor you want';
$bmQuickDescription = $bmQuickLang === 'fa' ? (string)bm_site_get('search_description_fa','نتیجه‌ها همین‌جا نمایش داده می‌شوند و می‌توانی مستقیم وارد صفحه موردنظرت شوی.') : 'Results appear here and you can open the desired page directly.';
$bmQuickPlaceholder = $bmQuickLang === 'fa' ? (string)bm_site_get('search_placeholder_fa','جستجوی فیلم، سریال یا بازیگر...') : 'Search movies, series or actors...';
$bmQuickSubmit = $bmQuickLang === 'fa' ? (string)bm_site_get('search_submit_label_fa','جستجو') : 'Search';
$bmQuickAdvanced = $bmQuickLang === 'fa' ? (string)bm_site_get('search_advanced_label_fa','جستجوی پیشرفته') : 'Advanced search';
$bmQuickAdvancedHelp = $bmQuickLang === 'fa' ? (string)bm_site_get('search_advanced_help_fa','برای فیلتر سال، ژانر و کشور از جستجوی پیشرفته استفاده کن') : 'Use advanced search for year, genre and country filters';
$bmQuickHints = [
    'local' => $bmQuickLang === 'fa' ? 'آرشیو ۲ — دیتابیس اصلی سایت، سافت‌ساب و دوبله' : 'Archive 2 — Main local database',
    'arc1' => $bmQuickLang === 'fa' ? 'آرشیو ۱ — هاردساب، دوبله و آپدیت سریع' : 'Archive 1 — Hardsub, dubbed and fast updates',
    'arc3' => $bmQuickLang === 'fa' ? 'آرشیو ۳ — فیلم، سریال، انیمیشن و انیمه به‌روز' : 'Archive 3 — Updated movies, series and anime',
    'arc4' => $bmQuickLang === 'fa' ? 'آرشیو ۴ — ساختار مشابه آرشیو ۳' : 'Archive 4 — same structure as Archive 3',
];
?>
<?php if ($bmQuickPage !== 'index.php'): ?><link rel="stylesheet" href="/assets/css/bm-quick-search.css?v=quick102"><?php endif; ?>
<script>
window.BM_HOME_CONFIG = Object.assign({}, window.BM_HOME_CONFIG || {}, {
  userLang: <?= json_encode($bmQuickLang, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  archiveControl: <?= json_encode($bmQuickArchiveConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  arcHints: <?= json_encode($bmQuickHints, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  activeArchive: <?= json_encode($bmQuickDefaultMode, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>
});
window.BM_QUICK_SEARCH_GLOBAL_PAGE = <?= $bmQuickPage === 'index.php' ? 'false' : 'true' ?>;
</script>
<div class="bm-quick-search-overlay" id="bmQuickSearchModal" aria-hidden="true">
    <div class="bm-quick-search-grid" aria-hidden="true"></div>
    <section class="search-section bm-quick-search-card" id="unifiedSearchSection" role="dialog" aria-modal="true" aria-labelledby="bmQuickSearchTitle">
        <div class="bm-quick-search-head">
            <button type="button" class="bm-quick-search-close" id="bmQuickSearchClose" aria-label="<?= $bmQuickEsc($bmQuickLang === 'fa' ? 'بستن' : 'Close') ?>">
                <span><?= $bmQuickEsc($bmQuickLang === 'fa' ? 'بستن' : 'Close') ?></span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5"></path><path d="M12 19l-7-7 7-7"></path></svg>
            </button>
            <span class="bm-quick-search-kicker"><?= $bmQuickEsc($bmQuickKicker) ?></span>
        </div>

        <div class="bm-quick-search-copy">
            <h2 id="bmQuickSearchTitle"><?= $bmQuickEsc($bmQuickTitle) ?></h2>
            <p><?= $bmQuickEsc($bmQuickDescription) ?></p>
        </div>

        <div class="bm-quick-archive-wrap" aria-label="<?= $bmQuickEsc($bmQuickLang === 'fa' ? 'انتخاب آرشیو' : 'Choose archive') ?>">
            <span class="bm-quick-archive-label"><?= $bmQuickEsc($bmQuickLang === 'fa' ? 'جستجو در' : 'Search in') ?></span>
            <div class="bm-quick-archive-switch" id="bmQuickArchiveSwitch">
                <?php foreach ([
                    'archive1' => ['mode' => 'arc1', 'fa' => 'آرشیو ۱', 'en' => 'Archive 1'],
                    'archive2' => ['mode' => 'local', 'fa' => 'آرشیو ۲', 'en' => 'Archive 2'],
                    'archive3' => ['mode' => 'arc3', 'fa' => 'آرشیو ۳', 'en' => 'Archive 3'],
                    'archive4' => ['mode' => 'arc4', 'fa' => 'آرشیو ۴', 'en' => 'Archive 4'],
                ] as $bmQuickArchiveId => $bmQuickArchiveRow):
                    if (function_exists('bm_archive_should_render_tab') && !bm_archive_should_render_tab($bmQuickArchiveId)) continue;
                    $bmQuickEnabled = function_exists('bm_archive_is_enabled') ? bm_archive_is_enabled($bmQuickArchiveId) : true;
                    $bmQuickLabel = function_exists('bm_archive_label')
                        ? bm_archive_label($bmQuickArchiveId, $bmQuickLang === 'fa' ? $bmQuickArchiveRow['fa'] : $bmQuickArchiveRow['en'])
                        : ($bmQuickLang === 'fa' ? $bmQuickArchiveRow['fa'] : $bmQuickArchiveRow['en']);
                    $bmQuickDisabledMessage = function_exists('bm_archive_disabled_message')
                        ? bm_archive_disabled_message($bmQuickArchiveId)
                        : ($bmQuickLang === 'fa' ? 'این آرشیو موقتاً در دسترس نیست.' : 'This archive is temporarily unavailable.');
                ?>
                <button type="button" class="bm-quick-archive-btn" data-mode="<?= $bmQuickEsc($bmQuickArchiveRow['mode']) ?>" data-enabled="<?= $bmQuickEnabled ? '1' : '0' ?>" data-disabled-message="<?= $bmQuickEsc($bmQuickDisabledMessage) ?>">
                    <?= $bmQuickEsc($bmQuickLabel) ?>
                </button>
                <?php endforeach; ?>
            </div>
            <div class="bm-quick-archive-hint" id="bmQuickArchiveHint" aria-live="polite"></div>
        </div>

        <div class="bm-quick-search-poda" id="bmQuickSearchPoda">
            <span class="bm-quick-search-glow" aria-hidden="true"></span>
            <span class="bm-quick-search-white" aria-hidden="true"></span>
            <span class="bm-quick-search-border" aria-hidden="true"></span>
            <span class="bm-quick-search-dark" aria-hidden="true"></span>
            <div class="bm-quick-search-main">
                <input type="text" id="unifiedSearchInput" class="search-input bm-quick-search-input" placeholder="<?= $bmQuickEsc($bmQuickPlaceholder) ?>" autocomplete="off" enterkeyhint="search" inputmode="search" dir="<?= $bmQuickLang === 'fa' ? 'rtl' : 'ltr' ?>" spellcheck="false">
                <span class="bm-quick-input-mask" aria-hidden="true"></span>
                <span class="bm-quick-pink-mask" aria-hidden="true"></span>
                <svg class="bm-quick-search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <button type="button" class="bm-quick-search-submit" id="bmQuickSearchSubmit" aria-label="<?= $bmQuickEsc($bmQuickSubmit) ?>">
                    <span><?= $bmQuickEsc($bmQuickSubmit) ?></span>
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14"></path><path d="m13 6 6 6-6 6"></path></svg>
                </button>
            </div>
        </div>

        <div class="search-results bm-quick-search-results" id="unifiedSearchResults" aria-live="polite"></div>

        <div class="bm-quick-search-foot">
            <a href="/search" class="advanced-search-link" id="advancedSearchLink"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="22 3 2 3 10 13 10 21 14 18 14 13 22 3"></polygon></svg><?= $bmQuickEsc($bmQuickAdvanced) ?></a>
            <span><?= $bmQuickEsc($bmQuickAdvancedHelp) ?></span>
        </div>
    </section>
</div>
<script src="/assets/js/bm-quick-search.js?v=quick102"></script>
<?php if ($bmQuickPage !== 'index.php'): ?><script src="/assets/js/bm-quick-search-global.js?v=102"></script><?php endif; ?>
