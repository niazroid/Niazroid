<?php
require_once dirname(__DIR__) . '/includes/site_content_control.php';

$bmNavLang = (($userLang ?? $currentLanguage ?? 'fa') === 'en') ? 'en' : 'fa';
$bmNavPath = trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/'), '/');
$bmNavPath = preg_replace('~/{2,}~', '/', $bmNavPath) ?: '';

$bmIsHome = ($bmNavPath === '' || $bmNavPath === 'index.php');
$bmIsSearch = (bool)preg_match('~^search(?:\.php)?(?:/|$)~i', $bmNavPath);
$bmIsPlayer = (bool)preg_match('~^player(?:\.php)?(?:/|$)~i', $bmNavPath);
$bmIsCategories = (bool)preg_match('~^(categories|genres)(?:\.php)?(?:/|$)~i', $bmNavPath);
$bmIsProfile = (bool)preg_match('~^(profile|login|register)(?:\.php)?(?:/|$)~i', $bmNavPath);

$bmNavHome = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_home_label','خانه') : 'Home';
$bmNavSearch = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_search_label','جستجو') : 'Search';
$bmNavPlayer = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_player_label','پلیر') : 'Player';
$bmNavCategories = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_categories_label','دسته‌بندی') : 'Categories';
$bmNavProfile = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_profile_label','پروفایل') : 'Profile';
$bmNavLogin = $bmNavLang === 'fa' ? (string)bm_site_get('mobile_nav_login_label','ورود') : 'Login';
?>
<?php if (bm_site_bool('mobile_nav_enabled', true)): ?>
<nav class="bottom-nav" data-mobile-bottom-nav dir="ltr" aria-label="Mobile bottom navigation">
    <?php if (bm_site_bool('mobile_nav_show_profile', true)): ?>
    <a href="<?= !empty($currentUser) ? '/profile' : '/login' ?>" data-bm-nav-kind="profile" class="nav-item <?= $bmIsProfile ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
        <span class="nav-label"><?= bm_site_h(!empty($currentUser) ? $bmNavProfile : $bmNavLogin) ?></span>
    </a>
    <?php endif; ?>

    <?php if (bm_site_bool('mobile_nav_show_player', true)): ?>
    <a href="/player" data-bm-nav-kind="player" class="nav-item <?= $bmIsPlayer ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        <span class="nav-label"><?= bm_site_h($bmNavPlayer) ?></span>
    </a>
    <?php endif; ?>

    <?php if (bm_site_bool('mobile_nav_show_categories', true)): ?>
    <a href="/categories" data-bm-nav-kind="categories" class="nav-item bm-nav-categories <?= $bmIsCategories ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg>
        <span class="nav-label"><?= bm_site_h($bmNavCategories) ?></span>
    </a>
    <?php endif; ?>

    <a href="/search" data-bm-nav-kind="search" class="nav-item bm-footer-search-trigger <?= $bmIsSearch ? 'active' : '' ?>" aria-haspopup="dialog" aria-controls="bmQuickSearchModal">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <span class="nav-label"><?= bm_site_h($bmNavSearch) ?></span>
    </a>

    <a href="/" data-bm-nav-kind="home" class="nav-item <?= $bmIsHome ? 'active' : '' ?>">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg>
        <span class="nav-label"><?= bm_site_h($bmNavHome) ?></span>
    </a>
</nav>
<?php endif; ?>
