<?php
require_once dirname(__DIR__) . '/includes/site_content_control.php';
require_once dirname(__DIR__) . '/includes/user_theme.php';
require_once dirname(__DIR__) . '/includes/vip_features.php';
require_once dirname(__DIR__) . '/includes/user_avatar.php';
// Shared public header. Kept dependency-light so it can be included by every public page.
$bmHeaderLang = (($userLang ?? 'fa') === 'en') ? 'en' : 'fa';
$bmHeaderUser = $currentUser ?? null;
$bmHeaderPage = basename((string)($_SERVER['SCRIPT_FILENAME'] ?? ($_SERVER['SCRIPT_NAME'] ?? 'index.php')));
$bmHeaderClassValue = trim((string)($bmHeaderClass ?? 'header'));
if ($bmHeaderClassValue === '') $bmHeaderClassValue = 'header';
if (strpos($bmHeaderClassValue, 'bm-public-header-v148') === false) {
    $bmHeaderClassValue .= ' bm-public-header-v148';
}
if ($bmHeaderUser && (($bmHeaderUser['role'] ?? '') === 'admin') && strpos($bmHeaderClassValue, 'header-admin') === false) {
    $bmHeaderClassValue .= ' header-admin';
}
$bmHeaderEsc = static function ($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
};
$bmHeaderLabel = static function (string $key, string $fa, string $en) use ($bmHeaderLang, $t): string {
    if (isset($t[$bmHeaderLang][$key]) && trim((string)$t[$bmHeaderLang][$key]) !== '') {
        return (string)$t[$bmHeaderLang][$key];
    }
    return $bmHeaderLang === 'fa' ? $fa : $en;
};
$bmHeaderIsAdmin = $bmHeaderUser && (($bmHeaderUser['role'] ?? '') === 'admin');
$bmHeaderHasNotification = !empty($latestNotification) || !empty($activeNotification) || !empty($notificationsList);
$bmHeaderUsername = trim((string)($bmHeaderUser['username'] ?? '')) ?: $bmHeaderLabel('account', 'حساب کاربری', 'Account');
$bmHeaderVipBadge = bm_vip_member_badge_html($bmHeaderUser, true);
$bmDefaultBrandLogo = '/assets/brand/bankmovie-logo.webp';
$bmConfiguredLogo = trim((string)bm_site_get('brand_logo_path', $bmDefaultBrandLogo)) ?: $bmDefaultBrandLogo;
$bmConfiguredLogoPath = (string)(parse_url($bmConfiguredLogo, PHP_URL_PATH) ?: $bmConfiguredLogo);
$bmThemeCatalog = bm_theme_catalog();
$bmHeaderTheme = bm_site_bool('ui_user_theme_enabled', true) ? bm_theme_resolve(is_array($bmHeaderUser) ? $bmHeaderUser : null) : 'dark-green';
$bmUseThemeLogo = bm_site_bool('ui_theme_logo_enabled', true)
    && bm_site_bool('ui_user_theme_enabled', true)
    && rtrim($bmConfiguredLogoPath, '/') === $bmDefaultBrandLogo
    && isset($bmThemeCatalog[$bmHeaderTheme]['logo']);
$bmSiteLogo = $bmUseThemeLogo ? (string)$bmThemeCatalog[$bmHeaderTheme]['logo'] : $bmConfiguredLogo;
$bmHeaderHomeLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_home_label_fa', 'خانه') : 'Home';
$bmHeaderSearchLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_search_label_fa', 'جستجو') : 'Search';
$bmHeaderCollectionsLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_collections_label_fa', 'کالکشن‌ها') : 'Collections';
$bmHeaderCategoriesLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_categories_label_fa', 'دسته‌بندی') : 'Categories';
$bmHeaderBoxOfficeLabel = $bmHeaderLang === 'fa' ? 'باکس آفیس' : 'Box Office';
$bmHeaderPlayerLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_player_label_fa', 'پلیر') : 'Player';
$bmHeaderAppsLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_apps_label_fa', 'اپلیکیشن‌ها') : 'Applications';
$bmHeaderProfileLabel = $bmHeaderLang === 'fa' ? (string)bm_site_get('header_profile_label_fa', 'پروفایل') : 'Profile';

$bmHeaderAvatarRaw = trim((string)($bmHeaderUser['avatar'] ?? ''));
$bmHeaderHasAvatar = $bmHeaderAvatarRaw !== '';
$bmHeaderAvatarUrl = $bmHeaderUser ? bm_user_avatar_url($bmHeaderAvatarRaw) : bm_user_avatar_url(null);
$bmHeaderVipRemaining = bm_vip_remaining(is_array($bmHeaderUser) ? $bmHeaderUser : null);
$bmHeaderVipActive = $bmHeaderIsAdmin || bm_vip_user_is_active(is_array($bmHeaderUser) ? $bmHeaderUser : null);
$bmHeaderVipExpiryLabel = '';
if (!empty($bmHeaderVipRemaining['expires_at'])) {
    $bmHeaderVipExpiryTs = strtotime((string)$bmHeaderVipRemaining['expires_at']);
    if ($bmHeaderVipExpiryTs !== false) {
        $bmHeaderVipExpiryLabel = date('Y/m/d - H:i', $bmHeaderVipExpiryTs);
    }
}

// Some legacy pages already render their own drawer markup before this shared header.
// Every other public page receives the lightweight shared fallback below.
$bmHeaderLegacyMenuPages = [
    'index.php', 'movie.php', 'player.php', 'search.php', 'collections.php',
    'collection.php', 'view_all.php', 'top_rated_by_users.php', 'actors.php', 'app.php'
];
$bmHeaderLegacyNotificationPages = [
    'index.php', 'movie.php', 'player.php', 'search.php', 'collections.php',
    'collection.php', 'view_all.php', 'top_rated_by_users.php'
];
$bmHeaderNeedsFallbackMenu = !in_array($bmHeaderPage, $bmHeaderLegacyMenuPages, true);
$bmHeaderNeedsFallbackNotifications = false; // V14861970: universal notification center replaces legacy fallback drawer.
$bmHeaderNeedsFallbackDrawers = $bmHeaderNeedsFallbackMenu || $bmHeaderNeedsFallbackNotifications;

?>
<script src="/assets/js/bm-adaptive-mobile-tier-v49.js?v=49.0"></script>
<script src="/assets/js/bm-mobile-nav-hardlock-v66.js?v=66.0"></script>
<script src="/assets/js/bm-native-ui-v74.js?v=74.0" defer></script>
<link rel="stylesheet" href="/assets/css/bm-adaptive-mobile-perf-v49.css?v=49.0">
<link rel="stylesheet" href="/assets/css/bm-bottom-nav-unified-v57.css?v=57.0">
<link rel="stylesheet" href="/assets/css/bm-v148-surgical-fixes.css?v=14861969">
<link rel="stylesheet" href="/assets/css/bm-mobile-nav-hardlock-v66.css?v=66.0">

<link rel="stylesheet" href="/assets/css/bm-notification-center-v14861972.css?v=14861972">
<link rel="stylesheet" href="/assets/css/bm-vip-member-badge-v14840.css?v=14841">
<link rel="stylesheet" href="/assets/css/bm-mobile-universal-transparent-header-v14859.css?v=14859">
<link rel="stylesheet" href="/assets/css/bm-mobile-header-surface-only-v14861924.css?v=14861924">
<?php if (bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-native-ui-v74.css?v=74.0">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= $bmHeaderEsc((string)bm_site_get('ui_neon_checkbox_color','#00ffaa')) ?>;--primary-dark:<?= $bmHeaderEsc((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88')) ?>;--primary-light:<?= $bmHeaderEsc((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd')) ?>;--size:<?= max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<style id="bm-unified-imdb-pill-v1">
.bm-imdb-pill,
.imdb-poster-badge,
.a1-badge.is-imdb,
.bm-related-imdb-badge,
.bm-arc1-rel-imdb{
  display:inline-flex!important;align-items:center!important;justify-content:center;gap:7px!important;
  direction:ltr;unicode-bidi:isolate;line-height:1!important;text-decoration:none;
  background:#f5c518!important;color:#070707!important;border:1px solid rgba(0,0,0,.12)!important;
  border-radius:12px!important;box-shadow:0 10px 24px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.2)!important;
  font-family:Arial,Helvetica,sans-serif!important;font-weight:950!important;
}
.bm-imdb-pill{min-height:38px;padding:6px 12px 6px 10px!important}
.imdb-poster-badge,.a1-badge.is-imdb,.bm-related-imdb-badge,.bm-arc1-rel-imdb{min-height:30px;padding:5px 10px 5px 9px!important}
.bm-imdb-pill--sm{min-height:32px!important;padding:4px 10px 4px 9px!important;border-radius:11px!important}
.bm-imdb-pill--xs{min-height:28px!important;padding:4px 8px 4px 8px!important;border-radius:10px!important}
.bm-imdb-pill .bm-imdb-score,
.imdb-poster-badge .bm-imdb-score,
.a1-badge.is-imdb .bm-imdb-score,
.bm-related-imdb-badge .bm-imdb-score,
.bm-arc1-rel-imdb .bm-imdb-score{display:inline-flex;align-items:center;justify-content:center;color:#070707!important;font-weight:980!important;letter-spacing:-.02em;font-variant-numeric:tabular-nums}
.bm-imdb-pill .bm-imdb-score{font-size:17px;min-width:26px}
.imdb-poster-badge .bm-imdb-score,.a1-badge.is-imdb .bm-imdb-score,.bm-related-imdb-badge .bm-imdb-score,.bm-arc1-rel-imdb .bm-imdb-score{font-size:14px;min-width:20px}
.bm-imdb-pill img,.imdb-poster-badge img,.a1-badge.is-imdb img,.bm-related-imdb-badge img,.bm-arc1-rel-imdb img,
.bm-imdb-pill .imdb-mini-svg,.imdb-poster-badge .imdb-mini-svg,.a1-badge.is-imdb .imdb-mini-svg,.bm-related-imdb-badge .imdb-mini-svg,.bm-arc1-rel-imdb .imdb-mini-svg{
  width:46px!important;height:22px!important;display:block!important;object-fit:contain!important;border-radius:5px!important;flex:0 0 auto!important;background:transparent!important
}
.imdb-poster-badge em{display:none!important}
.a1-badge.is-imdb{color:#070707!important;border-color:rgba(0,0,0,.12)!important}
.bm-meta-imdb{padding:6px!important;background:transparent!important;border:0!important;box-shadow:none!important}
.bm-meta-imdb .label,.bm-meta-imdb .value{display:none!important}
.bm-meta-imdb > img{display:none!important}
.bm-meta-imdb .bm-imdb-pill{margin-inline-start:auto}
.related-card,.bm-arc1-related-card{position:relative!important}
.related-card .bm-related-imdb-badge{position:absolute;top:10px;left:10px;z-index:3}
.bm-arc1-rel-imdb{position:absolute;top:10px;left:10px;z-index:3}
@media (max-width:540px){
  .bm-imdb-pill{min-height:34px;padding:5px 10px 5px 8px!important}
  .bm-imdb-pill .bm-imdb-score{font-size:15px}
  .imdb-poster-badge,.a1-badge.is-imdb,.bm-related-imdb-badge,.bm-arc1-rel-imdb{min-height:27px;padding:4px 8px!important}
  .imdb-poster-badge .bm-imdb-score,.a1-badge.is-imdb .bm-imdb-score,.bm-related-imdb-badge .bm-imdb-score,.bm-arc1-rel-imdb .bm-imdb-score{font-size:13px}
  .bm-imdb-pill img,.imdb-poster-badge img,.a1-badge.is-imdb img,.bm-related-imdb-badge img,.bm-arc1-rel-imdb img,
  .bm-imdb-pill .imdb-mini-svg,.imdb-poster-badge .imdb-mini-svg,.a1-badge.is-imdb .imdb-mini-svg,.bm-related-imdb-badge .imdb-mini-svg,.bm-arc1-rel-imdb .imdb-mini-svg{width:40px!important;height:19px!important}
}
</style>
<link rel="stylesheet" href="/assets/css/bm-imdb-unified-v2.css?v=2.3">
<script src="/assets/js/bm-imdb-unified-v2.js?v=2.3" defer></script>
<?php require __DIR__ . '/loading_manager_assets.php'; ?>
<script>window.BM_MOBILE_NAV_CATEGORIES_ENABLED=<?= bm_site_bool('mobile_nav_show_categories', true) ? 'true' : 'false' ?>;window.BM_MOBILE_NAV_CATEGORIES_LABEL=<?= json_encode($bmHeaderLang === 'fa' ? (string)bm_site_get('mobile_nav_categories_label','دسته‌بندی') : 'Categories', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;</script>
<script src="/assets/js/bm-v148-surgical-fixes.js?v=14861969" defer></script>
<script src="/assets/js/bm-mobile-header-state-v148616.js?v=148616-v47" defer></script>
<script src="/assets/js/bm-boxoffice-nav-v14861953.js?v=14861953" defer></script>
<link rel="stylesheet" href="/assets/css/bm-header-placement-v149.css?v=149.1">
<header class="<?= $bmHeaderEsc($bmHeaderClassValue) ?>" id="siteHeader" data-bm-page="<?= $bmHeaderEsc($bmHeaderPage) ?>">
    <div class="header-inner">
        <a href="/" class="logo" aria-label="<?= $bmHeaderEsc($bmHeaderLabel('home', 'بانک مووی', 'BankMovie')) ?>">
            <img src="<?= $bmHeaderEsc($bmSiteLogo) ?>" alt="بانک مووی" class="bm-header-logo-img" <?= $bmUseThemeLogo ? 'data-bm-theme-logo="1"' : '' ?> loading="eager" decoding="async" fetchpriority="high" width="154" height="74">
        </a>

        <nav class="desktop-nav" aria-label="Primary">
            <?php if (bm_site_bool('header_show_home', true)): ?><a href="/" class="desktop-nav-item <?= $bmHeaderPage === 'index.php' ? 'active' : '' ?>"><span><?= $bmHeaderEsc($bmHeaderHomeLabel) ?></span></a><?php endif; ?>
            <?php if (bm_site_bool('header_show_collections', true)): ?><a href="/collections" class="desktop-nav-item collection-link <?= in_array($bmHeaderPage, ['collections.php', 'collection.php'], true) ? 'active' : '' ?>"><span><?= $bmHeaderEsc($bmHeaderCollectionsLabel) ?></span></a><?php endif; ?>
            <?php if (bm_site_bool('header_show_categories', true)): ?><a href="/categories" class="desktop-nav-item bm-category-nav <?= $bmHeaderPage === 'categories.php' ? 'active' : '' ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg><span><?= $bmHeaderEsc($bmHeaderCategoriesLabel) ?></span></a><?php endif; ?>
            <a href="/boxoffice" class="desktop-nav-item bm-boxoffice-nav <?= $bmHeaderPage === 'boxoffice.php' ? 'active' : '' ?>"><span><?= $bmHeaderEsc($bmHeaderBoxOfficeLabel) ?></span></a>
            <?php if (bm_site_bool('header_show_search', true)): ?><a href="/search" class="desktop-nav-item bm-header-search-nav <?= $bmHeaderPage === 'search.php' ? 'active' : '' ?>" aria-haspopup="dialog" aria-controls="bmQuickSearchModal"><span><?= $bmHeaderEsc($bmHeaderSearchLabel) ?></span></a><?php endif; ?>
            <?php if (bm_site_bool('header_show_player', true)): ?><a href="/player" class="desktop-nav-item <?= $bmHeaderPage === 'player.php' ? 'active' : '' ?>"><span><?= $bmHeaderEsc($bmHeaderPlayerLabel) ?></span></a><?php endif; ?>
            <?php if (bm_site_bool('header_show_apps', true)): ?><a href="/application" class="desktop-nav-item <?= $bmHeaderPage === 'app.php' ? 'active' : '' ?>"><span><?= $bmHeaderEsc($bmHeaderAppsLabel) ?></span></a><?php endif; ?>
        </nav>

        <div class="header-actions">
            <button type="button" class="menu-btn" id="menuBtn" aria-label="<?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'منو' : 'Menu') ?>" aria-expanded="false">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.15" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
            </button>
            <?php if (bm_site_bool('header_show_categories', true)): ?><a href="/categories" class="bm-header-collection bm-header-categories" aria-label="<?= $bmHeaderEsc($bmHeaderCategoriesLabel) ?>" title="<?= $bmHeaderEsc($bmHeaderCategoriesLabel) ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.05" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2"></rect><rect x="14" y="3" width="7" height="7" rx="2"></rect><rect x="3" y="14" width="7" height="7" rx="2"></rect><rect x="14" y="14" width="7" height="7" rx="2"></rect></svg>
            </a><?php endif; ?>
            <?php if (bm_site_bool('header_show_notifications', true)): ?><button type="button" class="notif-bell" id="notifBell" aria-label="<?= $bmHeaderEsc($bmHeaderLabel('notifications', 'اعلان‌ها', 'Notifications')) ?>" title="<?= $bmHeaderEsc($bmHeaderLabel('notifications', 'اعلان‌ها', 'Notifications')) ?>" aria-controls="bmNotifCenter" aria-expanded="false">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.05" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                <span class="notif-badge bm-notif-live-badge" id="bmNotifBadge" hidden aria-hidden="true"></span>
            </button><?php endif; ?>
            <?php if (bm_site_bool('header_show_search', true)): ?><a href="/search" class="bm-header-search bm-header-search-trigger" id="bmHeaderQuickSearchBtn" aria-label="<?= $bmHeaderEsc($bmHeaderSearchLabel) ?>" title="<?= $bmHeaderEsc($bmHeaderSearchLabel) ?>" aria-haspopup="dialog" aria-controls="bmQuickSearchModal">
                <span class="bm-header-search-glow" aria-hidden="true"></span>
                <span class="bm-header-search-white" aria-hidden="true"></span>
                <span class="bm-header-search-border" aria-hidden="true"></span>
                <span class="bm-header-search-dark" aria-hidden="true"></span>
                <span class="bm-header-search-content">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.05" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <span class="bm-header-search-label"><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? ($bmHeaderSearchLabel . ' در ' . bm_site_get('site_name_fa','بانک مووی')) : ('Search ' . bm_site_get('site_name_en','BankMovie'))) ?></span>
                </span>
            </a><?php endif; ?>

            <?php if ($bmHeaderIsAdmin): ?>
                <a href="/admin.php" class="admin-panel-trigger" aria-label="<?= $bmHeaderEsc($bmHeaderLabel('admin_panel', 'پنل مدیریت', 'Admin Panel')) ?>" title="<?= $bmHeaderEsc($bmHeaderLabel('admin_panel', 'پنل مدیریت', 'Admin Panel')) ?>">
                    <svg class="admin-panel-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 20h8"/><path d="M12 18v2"/><path d="M8 9h8"/><path d="M8 13h5"/></svg>
                    <span><?= $bmHeaderEsc($bmHeaderLabel('admin_panel', 'پنل مدیریت', 'Admin Panel')) ?></span>
                </a>
            <?php endif; ?>

            <div class="auth-dropdown">
                <?php if ($bmHeaderUser): ?>
                    <a class="user-trigger" href="/profile"><span><?= $bmHeaderEsc($bmHeaderUsername) ?></span><?= $bmHeaderVipBadge ?></a>
                    <div class="auth-menu">
                        <?php if ($bmHeaderIsAdmin): ?>
                            <a href="/admin.php" class="auth-menu-link auth-menu-admin"><svg class="auth-menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 20h8"/><path d="M12 18v2"/><path d="M8 9h8"/><path d="M8 13h5"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('admin_panel', 'پنل مدیریت', 'Admin Panel')) ?></span></a>
                        <?php endif; ?>
                        <a href="/profile" class="auth-menu-link"><svg class="auth-menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $bmHeaderEsc($bmHeaderProfileLabel) ?></span></a>
                        <a href="/logout" class="auth-menu-link auth-menu-logout"><svg class="auth-menu-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('logout', 'خروج', 'Logout')) ?></span></a>
                    </div>
                <?php else: ?>
                    <a class="user-trigger" href="/login"><span><?= $bmHeaderEsc($bmHeaderLabel('login', 'ورود', 'Login')) ?></span></a>
                    <div class="auth-menu">
                        <a href="/login" class="auth-menu-link"><span><?= $bmHeaderEsc($bmHeaderLabel('login', 'ورود', 'Login')) ?></span></a>
                        <a href="/register" class="auth-menu-link"><span><?= $bmHeaderEsc($bmHeaderLabel('register', 'ثبت نام', 'Register')) ?></span></a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>
<div class="bm-notif-backdrop" id="bmNotifCenterBackdrop" hidden aria-hidden="true"></div>
<aside class="bm-notif-center" id="bmNotifCenter" hidden aria-hidden="true" aria-label="<?= $bmHeaderEsc($bmHeaderLabel('notifications','اعلان‌ها','Notifications')) ?>">
    <div class="bm-notif-center-head">
        <div class="bm-notif-center-title-wrap">
            <span class="bm-notif-center-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M14 21h-4"/></svg></span>
            <div><strong><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'مرکز اعلان‌ها' : 'Notifications') ?></strong><small id="bmNotifCenterStatus"><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'آخرین خبرهای حساب شما' : 'Your latest account updates') ?></small></div>
        </div>
        <button type="button" class="bm-notif-center-close" id="bmNotifCenterClose" aria-label="<?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'بستن اعلان‌ها' : 'Close notifications') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6 6 18"/></svg></button>
    </div>
    <div class="bm-notif-center-tools" id="bmNotifCenterTools" <?= $bmHeaderUser ? '' : 'hidden' ?>>
        <button type="button" id="bmNotifReadAll"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m4 12 4 4L20 4"/><path d="m12 12 4 4 4-4"/></svg><span><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'خواندن همه' : 'Mark all read') ?></span></button>
        <button type="button" id="bmNotifClearAll"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13"/></svg><span><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'پاک کردن' : 'Clear') ?></span></button>
    </div>
    <div class="bm-notif-center-list" id="bmNotifCenterList" aria-live="polite">
        <div class="bm-notif-loading"><span></span><span></span><span></span></div>
    </div>
    <?php if (!$bmHeaderUser): ?>
    <div class="bm-notif-guest-cta"><span><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'برای اعلان‌های شخصی مثل پاسخ دیدگاه، وضعیت درخواست و VIP وارد حساب شوید.' : 'Sign in for personal notifications.') ?></span><a href="/login"><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'ورود به حساب' : 'Sign in') ?></a></div>
    <?php endif; ?>
</aside>
<script>
window.BM_NOTIFICATION_CENTER={
  api:'/notification_center_api.php',
  loggedIn:<?= $bmHeaderUser ? 'true' : 'false' ?>,
  csrf:<?= json_encode(function_exists('bm_user_csrf_token') ? bm_user_csrf_token() : '', JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>,
  lang:<?= json_encode($bmHeaderLang, JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="/assets/js/bm-notification-center-v14861970.js?v=14861970" defer></script>
<?php if ($bmHeaderNeedsFallbackDrawers): ?>
<style id="bm-shared-drawer-fallback-v14854">
.bm-shared-drawer-fallback.menu-overlay,.bm-shared-drawer-fallback.notif-backdrop{position:fixed;inset:0;z-index:2140;background:rgba(2,4,10,.72);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .24s ease,visibility .24s ease;backdrop-filter:blur(5px);-webkit-backdrop-filter:blur(5px)}
.bm-shared-drawer-fallback.menu-overlay.active,.bm-shared-drawer-fallback.notif-backdrop.active{opacity:1;visibility:visible;pointer-events:auto}
.bm-shared-drawer-fallback.sidebar-menu,.bm-shared-drawer-fallback.notif-sidebar{position:fixed;top:0;right:0;z-index:2150;width:min(342px,89vw);height:100dvh;display:flex;flex-direction:column;color:#fff;background:linear-gradient(180deg,rgba(16,20,31,.985),rgba(7,9,16,.995));border-left:1px solid rgba(255,255,255,.09);box-shadow:-30px 0 90px rgba(0,0,0,.55);transform:translate3d(105%,0,0);visibility:hidden;transition:transform .34s cubic-bezier(.22,.8,.22,1),visibility .34s ease;overflow:hidden}
html[dir="ltr"] .bm-shared-drawer-fallback.sidebar-menu,html[dir="ltr"] .bm-shared-drawer-fallback.notif-sidebar{right:auto;left:0;transform:translate3d(-105%,0,0);border-left:0;border-right:1px solid rgba(255,255,255,.09);box-shadow:30px 0 90px rgba(0,0,0,.55)}
.bm-shared-drawer-fallback.sidebar-menu.open,.bm-shared-drawer-fallback.notif-sidebar.open{transform:translate3d(0,0,0);visibility:visible}
.bm-shared-drawer-fallback .sidebar-header,.bm-shared-drawer-fallback .notif-header{min-height:76px;display:flex;align-items:center;justify-content:space-between;gap:14px;padding:16px 18px;border-bottom:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.018)}
.bm-shared-drawer-fallback .logo-text,.bm-shared-drawer-fallback .notif-header h3{margin:0;font-size:16px;font-weight:950;letter-spacing:-.02em}
.bm-shared-drawer-fallback .sidebar-close,.bm-shared-drawer-fallback .notif-close{width:38px;height:38px;display:grid;place-items:center;border:1px solid rgba(255,255,255,.09);border-radius:13px;background:rgba(255,255,255,.035);color:#fff;cursor:pointer}
.bm-shared-drawer-fallback .sidebar-close svg,.bm-shared-drawer-fallback .notif-close svg{width:19px;height:19px;stroke-width:2}
.bm-shared-drawer-fallback .sidebar-user{margin:14px 14px 4px;padding:14px;border-radius:18px;border:1px solid rgba(var(--accent-rgb,47,124,255),.19);background:linear-gradient(135deg,rgba(var(--accent-rgb,47,124,255),.11),rgba(255,255,255,.025))}
.bm-shared-drawer-fallback .sidebar-username{font-size:13px;font-weight:950}.bm-shared-drawer-fallback .sidebar-userrole{margin-top:4px;color:rgba(255,255,255,.48);font-size:9px}
.bm-shared-drawer-fallback .sidebar-nav,.bm-shared-drawer-fallback .sidebar-footer{display:flex;flex-direction:column;gap:6px;padding:14px}.bm-shared-drawer-fallback .sidebar-nav{overflow:auto;flex:1}.bm-shared-drawer-fallback .sidebar-footer{border-top:1px solid rgba(255,255,255,.07);padding-bottom:calc(14px + env(safe-area-inset-bottom,0px))}
.bm-shared-drawer-fallback .sidebar-item{min-height:47px;display:flex;align-items:center;gap:12px;padding:0 13px;border-radius:14px;color:rgba(255,255,255,.74);text-decoration:none;font-size:11px;font-weight:850;border:1px solid transparent;transition:.18s ease}
.bm-shared-drawer-fallback .sidebar-item:hover,.bm-shared-drawer-fallback .sidebar-item:focus-visible{color:#fff;background:rgba(var(--accent-rgb,47,124,255),.1);border-color:rgba(var(--accent-rgb,47,124,255),.18)}
.bm-shared-drawer-fallback .sidebar-item svg{width:19px;height:19px;flex:0 0 19px;stroke-width:1.8}
.bm-shared-drawer-fallback.notif-sidebar{z-index:2160;width:min(380px,92vw)}.bm-shared-drawer-fallback.notif-backdrop{z-index:2155}
.bm-shared-drawer-fallback .notif-list{flex:1;overflow:auto;padding:14px}.bm-shared-drawer-fallback .notif-item{padding:14px;border-radius:16px;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.025);margin-bottom:9px}.bm-shared-drawer-fallback .notif-message{font-size:10.5px;line-height:1.9;color:rgba(255,255,255,.78)}.bm-shared-drawer-fallback .notif-date{margin-top:7px;font-size:8.5px;color:rgba(255,255,255,.38)}
.bm-shared-drawer-fallback .notif-empty{min-height:220px;display:grid;place-items:center;text-align:center;color:rgba(255,255,255,.42);font-size:11px}.bm-shared-drawer-fallback .notif-empty svg{width:34px;height:34px;margin:0 auto 10px;stroke:rgba(var(--accent-rgb,47,124,255),.72)}
html.bm-drawer-open,body.bm-drawer-open{overscroll-behavior:none}
@media(prefers-reduced-motion:reduce){.bm-shared-drawer-fallback{transition:none!important}}
</style>
<?php if ($bmHeaderNeedsFallbackMenu): ?>
<div class="menu-overlay bm-shared-drawer-fallback" id="menuOverlay" aria-hidden="true" hidden></div>
<aside class="sidebar-menu bm-shared-drawer-fallback" id="sidebarMenu" aria-hidden="true">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button type="button" class="sidebar-close" id="closeMenuBtn" aria-label="<?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'بستن منو' : 'Close menu') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <?php if ($bmHeaderUser): ?><div class="sidebar-user"><div class="sidebar-username"><?= $bmHeaderEsc($bmHeaderUsername) ?></div><div class="sidebar-userrole"><?= $bmHeaderEsc($bmHeaderIsAdmin ? $bmHeaderLabel('admin_panel','مدیر بانک مووی','BankMovie Admin') : $bmHeaderLabel('account','حساب کاربری','Account')) ?></div></div><?php endif; ?>
    <nav class="sidebar-nav" aria-label="Mobile">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"/></svg><span><?= $bmHeaderEsc($bmHeaderHomeLabel) ?></span></a>
        <a href="/categories" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg><span><?= $bmHeaderEsc($bmHeaderCategoriesLabel) ?></span></a>
        <a href="/boxoffice" class="sidebar-item bm-boxoffice-menu-link"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/><path d="m3 7 5-4 5 5 7-6"/></svg><span><?= $bmHeaderEsc($bmHeaderBoxOfficeLabel) ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 4v16M16 4v16M3 10h18M3 16h18"/></svg><span><?= $bmHeaderEsc($bmHeaderCollectionsLabel) ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></svg><span><?= $bmHeaderEsc($bmHeaderSearchLabel) ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m8 5 11 7-11 7V5Z"/></svg><span><?= $bmHeaderEsc($bmHeaderPlayerLabel) ?></span></a>
        <a href="/application" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="6" y="2" width="12" height="20" rx="3"/><path d="M10 18h4"/></svg><span><?= $bmHeaderEsc($bmHeaderAppsLabel) ?></span></a>
        <?php if ($bmHeaderUser): ?>
            <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg><span><?= $bmHeaderEsc($bmHeaderProfileLabel) ?></span></a>
            <?php if ($bmHeaderIsAdmin): ?><a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 20h8M12 18v2M8 9h8M8 13h5"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('admin_panel','پنل مدیریت','Admin Panel')) ?></span></a><?php endif; ?>
        <?php endif; ?>
    </nav>
    <div class="sidebar-footer">
        <?php if ($bmHeaderUser): ?><a href="/logout" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('logout','خروج','Logout')) ?></span></a>
        <?php else: ?><a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('login','ورود','Login')) ?></span></a><a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0M19 8v6M22 11h-6"/></svg><span><?= $bmHeaderEsc($bmHeaderLabel('register','ثبت نام','Register')) ?></span></a><?php endif; ?>
    </div>
</aside>
<?php endif; ?>
<?php if ($bmHeaderNeedsFallbackNotifications): ?>
<div class="notif-backdrop bm-shared-drawer-fallback" id="notifBackdrop" aria-hidden="true" hidden></div>
<aside class="notif-sidebar bm-shared-drawer-fallback" id="notifSidebar" aria-hidden="true">
    <div class="notif-header"><h3><?= $bmHeaderEsc($bmHeaderLabel('notifications','اعلان‌ها','Notifications')) ?></h3><button type="button" class="notif-close" id="closeNotifSidebar" aria-label="<?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'بستن اعلان‌ها' : 'Close notifications') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>
    <div class="notif-list">
        <?php if (!empty($notificationsList) && is_array($notificationsList)): foreach ($notificationsList as $bmHeaderNotif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br($bmHeaderEsc((string)($bmHeaderNotif['message'] ?? ''))) ?></div><?php if (!empty($bmHeaderNotif['created_at'])): ?><div class="notif-date"><?= $bmHeaderEsc(date('Y/m/d H:i', strtotime((string)$bmHeaderNotif['created_at']))) ?></div><?php endif; ?></div>
        <?php endforeach; else: ?><div class="notif-empty"><div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M14 21h-4"/></svg><div><?= $bmHeaderEsc($bmHeaderLang === 'fa' ? 'اعلان جدیدی وجود ندارد' : 'No new notifications') ?></div></div></div><?php endif; ?>
    </div>
</aside>
<?php endif; ?>
<?php endif; ?>
<style id="bm-site-content-runtime"><?= bm_site_visibility_css() ?></style>
<script id="bm-site-control-runtime-v102">
window.BM_SITE_UI = <?= json_encode([
    'accent' => (string)bm_site_get('accent_color','#2f7cff'),
    'userThemeEnabled' => bm_site_bool('ui_user_theme_enabled', true),
    'themeLogoEnabled' => bm_site_bool('ui_theme_logo_enabled', true),
    'roleBadges' => [
        'adminVerified' => bm_site_bool('ui_admin_verified_badge_enabled', true),
        'vipMember' => bm_site_bool('ui_vip_member_badge_enabled', true),
    ],
    'appMiniBanner' => [
        'enabled' => bm_site_bool('app_bottom_nav_banner_enabled', false),
    ],
    'mobileNav' => [
        'enabled' => bm_site_bool('mobile_nav_enabled',true),
        'showPlayer' => bm_site_bool('mobile_nav_show_player',true),
        'showProfile' => bm_site_bool('mobile_nav_show_profile',true),
        'home' => (string)bm_site_get('mobile_nav_home_label','خانه'),
        'search' => (string)bm_site_get('mobile_nav_search_label','جستجو'),
        'player' => (string)bm_site_get('mobile_nav_player_label','پلیر'),
        'profile' => (string)bm_site_get('mobile_nav_profile_label','پروفایل'),
        'login' => (string)bm_site_get('mobile_nav_login_label','ورود'),
    ],
    'mobileDrawer' => [
        'enabled' => true,
        'tagline' => $bmHeaderLang === 'fa' ? 'بهترین فیلم‌ها، همیشه با شما' : 'Best movies, always with you',
        'quickAccessLabel' => $bmHeaderLang === 'fa' ? 'دسترسی سریع' : 'Quick access',
        'accountToolsLabel' => $bmHeaderLang === 'fa' ? 'حساب کاربری و ابزارها' : 'Account & tools',
        'buyVipTitle' => $bmHeaderLang === 'fa' ? 'اشتراک ویژه فعال نیست' : 'VIP membership is inactive',
        'buyVipText' => $bmHeaderLang === 'fa' ? 'برای باز شدن امکانات ویژه، اشتراک VIP را تهیه کنید.' : 'Unlock premium features by getting VIP membership.',
        'buyVipButton' => $bmHeaderLang === 'fa' ? 'خرید اشتراک ویژه' : 'Buy VIP membership',
        'buyVipUrl' => '/vip',
        'vipActiveTitle' => $bmHeaderLang === 'fa' ? 'اشتراک ویژه فعال است' : 'VIP membership is active',
        'vipLifetimeText' => $bmHeaderLang === 'fa' ? 'عضویت شما بدون تاریخ انقضا فعال است.' : 'Your membership is active with no expiry.',
        'vipRemainingPrefix' => $bmHeaderLang === 'fa' ? 'باقی‌مانده:' : 'Remaining:',
        'vipExpiresPrefix' => $bmHeaderLang === 'fa' ? 'تاریخ پایان:' : 'Expires:',
        'vipDaysLabel' => $bmHeaderLang === 'fa' ? 'روز' : 'days',
        'logoutSubtitle' => $bmHeaderLang === 'fa' ? 'خروج از حساب کاربری' : 'Sign out of your account',
        'removeCollections' => true,
        'user' => [
            'loggedIn' => (bool)$bmHeaderUser,
            'username' => $bmHeaderUsername,
            'roleLabel' => $bmHeaderIsAdmin ? ($bmHeaderLang === 'fa' ? 'مدیر' : 'Admin') : ($bmHeaderLang === 'fa' ? 'کاربر' : 'User'),
            'avatarUrl' => $bmHeaderAvatarUrl,
            'hasAvatar' => $bmHeaderHasAvatar,
            'isAdmin' => $bmHeaderIsAdmin,
            'isVip' => $bmHeaderVipActive,
            'vipActive' => $bmHeaderVipActive,
            'vipLifetime' => !empty($bmHeaderVipRemaining['active']) && !empty($bmHeaderVipRemaining['lifetime']),
            'vipDaysRemaining' => (int)($bmHeaderVipRemaining['days'] ?? 0),
            'vipExpiresLabel' => $bmHeaderVipExpiryLabel,
        ],
    ],
], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
(function(){
  'use strict';
  var cfg=window.BM_SITE_UI||{}, nav=cfg.mobileNav||{};
  function rgb(hex){var m=/^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex||'');return m?parseInt(m[1],16)+','+parseInt(m[2],16)+','+parseInt(m[3],16):'47,124,255';}
  function apply(){
    var appBanner=cfg.appMiniBanner||{};
    if(appBanner.enabled!==true){
      document.querySelectorAll('#bmAppMiniBanner,.bm-app-mini-banner').forEach(function(el){el.remove();});
      if(document.body) document.body.classList.remove('has-bm-app-mini-banner');
    }
    var accent=cfg.accent||'#2f7cff';
    document.documentElement.style.setProperty('--bm-site-accent-default',accent);
    document.documentElement.style.setProperty('--bm-site-accent-default-rgb',rgb(accent));
    if(cfg.userThemeEnabled===false){
      document.documentElement.style.setProperty('--bm-accent',accent);
      document.documentElement.style.setProperty('--bm-accent-rgb',rgb(accent));
      document.documentElement.style.setProperty('--accent',accent);
      document.documentElement.style.setProperty('--accent-rgb',rgb(accent));
    }
    var desktop=window.matchMedia&&window.matchMedia('(min-width: 992px)').matches;
    document.querySelectorAll('.bottom-nav,.actor-bottom-nav,[data-mobile-bottom-nav]').forEach(function(bar){
      if(desktop||nav.enabled===false){bar.style.setProperty('display','none','important');bar.setAttribute('aria-hidden','true');return;}
      bar.style.removeProperty('display');bar.removeAttribute('aria-hidden');
      bar.querySelectorAll('a').forEach(function(a){
        var href=(a.getAttribute('href')||'').toLowerCase(), label=a.querySelector('.nav-label,span');
        if(/player/.test(href)&&nav.showPlayer===false){a.style.setProperty('display','none','important');return;}
        if(/profile|login/.test(href)&&nav.showProfile===false){a.style.setProperty('display','none','important');return;}
        if(!label)return;
        if(href==='/'||/index/.test(href))label.textContent=nav.home||label.textContent;
        else if(/search/.test(href)||a.classList.contains('bm-footer-search-trigger'))label.textContent=nav.search||label.textContent;
        else if(/player/.test(href))label.textContent=nav.player||label.textContent;
        else if(/profile/.test(href))label.textContent=nav.profile||label.textContent;
        else if(/login/.test(href))label.textContent=nav.login||label.textContent;
      });
    });
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',apply,{once:true});else apply();
  window.addEventListener('resize',apply,{passive:true});
  window.addEventListener('load',apply,{once:true});
  window.setTimeout(apply,800);
})();
</script>
<?php if (bm_site_bool('maintenance_notice_enabled', false) && trim((string)bm_site_get('maintenance_notice_text','')) !== ''): ?>
<div class="bm-site-notice" style="position:relative;z-index:19990;margin:8px auto;padding:10px 16px;width:min(1180px,calc(100% - 24px));border-radius:14px;background:rgba(var(--accent-rgb,47,124,255),.15);border:1px solid rgba(var(--accent-rgb,47,124,255),.28);color:#fff;text-align:center;font-size:13px;font-weight:850"><?= $bmHeaderEsc(bm_site_get('maintenance_notice_text','')) ?></div>
<?php endif; ?>
<?php
$bmPromoTitle = trim((string)bm_site_get('promo_title_fa',''));
$bmPromoText = trim((string)bm_site_get('promo_text_fa',''));
$bmPromoUrl = trim((string)bm_site_get('promo_button_url',''));
$bmPromoImage = trim((string)bm_site_get('promo_image_path',''));
$bmPromoKey = substr(hash('sha256', $bmPromoTitle.'|'.$bmPromoText.'|'.$bmPromoUrl), 0, 14);
if (bm_site_bool('promo_banner_enabled', true) && ($bmPromoTitle !== '' || $bmPromoText !== '')):
?>
<style>
.bm-promo-banner{--bm-promo:<?= $bmHeaderEsc((string)bm_site_get('promo_accent_color','#2f7cff')) ?>;position:relative;z-index:19980;width:min(1220px,calc(100% - 24px));margin:10px auto;padding:13px 15px;border:1px solid color-mix(in srgb,var(--bm-promo) 42%,transparent);border-radius:20px;display:flex;align-items:center;gap:13px;overflow:hidden;color:#fff;background:radial-gradient(circle at 10% 15%,color-mix(in srgb,var(--bm-promo) 28%,transparent),transparent 42%),linear-gradient(135deg,rgba(9,12,22,.96),rgba(14,18,31,.88));box-shadow:0 18px 48px rgba(0,0,0,.26),inset 0 1px 0 rgba(255,255,255,.06)}
.bm-promo-banner:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(110deg,transparent,rgba(255,255,255,.07),transparent);transform:translateX(-120%);animation:bmPromoShine 5.4s ease-in-out infinite}@keyframes bmPromoShine{0%,62%{transform:translateX(-120%)}100%{transform:translateX(120%)}}
.bm-promo-media{position:relative;z-index:1;width:46px;height:46px;flex:0 0 46px;border-radius:15px;display:grid;place-items:center;overflow:hidden;background:linear-gradient(135deg,var(--bm-promo),rgba(255,255,255,.18));box-shadow:0 12px 28px color-mix(in srgb,var(--bm-promo) 28%,transparent)}.bm-promo-media img{width:100%;height:100%;object-fit:cover}.bm-promo-media svg{width:22px;height:22px;stroke:#fff}
.bm-promo-copy{position:relative;z-index:1;min-width:0;flex:1}.bm-promo-copy strong{display:block;font-size:14px;font-weight:950;margin-bottom:3px}.bm-promo-copy span{display:block;color:rgba(255,255,255,.72);font-size:11.5px;line-height:1.7}
.bm-promo-action{position:relative;z-index:1;min-height:38px;padding:0 15px;border-radius:13px;display:inline-flex;align-items:center;justify-content:center;color:#fff;text-decoration:none;font-size:12px;font-weight:950;background:linear-gradient(135deg,var(--bm-promo),color-mix(in srgb,var(--bm-promo) 72%,#fff));box-shadow:0 12px 26px color-mix(in srgb,var(--bm-promo) 24%,transparent)}
.bm-promo-close{position:relative;z-index:1;width:34px;height:34px;flex:0 0 34px;border:1px solid rgba(255,255,255,.1);border-radius:12px;color:#fff;background:rgba(255,255,255,.06);cursor:pointer;font-size:18px}
@media(max-width:700px){.bm-promo-banner{align-items:flex-start;padding:11px;border-radius:17px}.bm-promo-media{width:40px;height:40px;flex-basis:40px}.bm-promo-copy strong{font-size:12.5px}.bm-promo-copy span{font-size:10.5px}.bm-promo-action{min-height:34px;padding:0 11px;font-size:10.5px}.bm-promo-close{width:30px;height:30px;flex-basis:30px}}
</style>
<section class="bm-promo-banner" data-bm-promo-key="<?= $bmHeaderEsc($bmPromoKey) ?>">
  <div class="bm-promo-media"><?php if($bmPromoImage !== ''): ?><img src="<?= $bmHeaderEsc($bmPromoImage) ?>" alt=""><?php else: ?><svg viewBox="0 0 24 24" fill="none"><path d="M3 11l18-5v12L3 13v-2zM7 14v5h4v-4"/></svg><?php endif; ?></div>
  <div class="bm-promo-copy"><?php if($bmPromoTitle !== ''): ?><strong><?= $bmHeaderEsc($bmPromoTitle) ?></strong><?php endif; ?><?php if($bmPromoText !== ''): ?><span><?= $bmHeaderEsc($bmPromoText) ?></span><?php endif; ?></div>
  <?php if($bmPromoUrl !== ''): ?><a class="bm-promo-action" href="<?= $bmHeaderEsc($bmPromoUrl) ?>" <?= bm_site_bool('promo_open_new_tab',true)?'target="_blank" rel="noopener"':'' ?>><?= $bmHeaderEsc((string)bm_site_get('promo_button_label_fa','مشاهده')) ?></a><?php endif; ?>
  <?php if(bm_site_bool('promo_dismissible',true)): ?><button type="button" class="bm-promo-close" aria-label="بستن">×</button><?php endif; ?>
</section>
<script>(function(){var el=document.querySelector('.bm-promo-banner[data-bm-promo-key]');if(!el)return;var k='bm_promo_hide_'+el.dataset.bmPromoKey;try{if(sessionStorage.getItem(k)==='1'){el.remove();return}}catch(e){}var b=el.querySelector('.bm-promo-close');if(b)b.addEventListener('click',function(){try{sessionStorage.setItem(k,'1')}catch(e){}el.remove()});})();</script>
<?php endif; ?>
<?php require __DIR__ . '/quick_search_modal.php'; ?>
<?php require __DIR__ . '/vip_gate_modal.php'; ?>

<!-- BankMovie poster interaction protection v3.3. Convenience deterrence; not DRM. -->
<style id="bm-poster-protect-style-v33">
img[data-bm-poster-protected="1"]{
  -webkit-user-drag:none!important;
  user-drag:none!important;
  -webkit-user-select:none!important;
  user-select:none!important;
  -webkit-touch-callout:none!important;
}
</style>
<script id="bm-poster-protect-v33">
(function(){
  'use strict';
  var HOST='dl1.bankmovie.top';
  var IMG_EXT=/\.(?:jpe?g|png|webp|avif|gif)(?:$|[?#])/i;
  var POSTER_HINT=/(?:^|[-_\s])(poster|cover|movie-poster|series-poster)(?:$|[-_\s])/i;
  function urlIsDL1(raw){if(!raw)return false;try{return new URL(raw,location.href).hostname.toLowerCase()===HOST}catch(e){return false}}
  function posterish(img){
    if(!img||img.nodeType!==1||img.tagName!=='IMG')return false;
    var hint=((img.className&&typeof img.className==='string')?img.className:'')+' '+(img.id||'')+' '+(img.getAttribute('alt')||'');
    if(POSTER_HINT.test(hint))return true;
    if(img.closest&&img.closest('[class*="poster" i],[id*="poster" i],[class*="cover" i]'))return true;
    var vals=[img.currentSrc,img.getAttribute('src'),img.getAttribute('data-src'),img.getAttribute('data-lazy-src')];
    for(var i=0;i<vals.length;i++)if(urlIsDL1(vals[i]))return true;
    var ss=img.getAttribute('srcset')||img.getAttribute('data-srcset')||'';
    if(ss){var ps=ss.split(',');for(var j=0;j<ps.length;j++){var u=(ps[j].trim().split(/\s+/)[0]||'');if(urlIsDL1(u))return true;}}
    return false;
  }
  function mark(img){if(!posterish(img))return;img.setAttribute('data-bm-poster-protected','1');img.setAttribute('draggable','false');img.setAttribute('oncontextmenu','return false');img.setAttribute('ondragstart','return false');}
  function scan(root){if(!root)return;if(root.nodeType===1&&root.tagName==='IMG')mark(root);if(root.querySelectorAll){var a=root.querySelectorAll('img');for(var i=0;i<a.length;i++)mark(a[i]);}}
  function imgFromEvent(e){var t=e.target;return(t&&t.nodeType===1&&t.tagName==='IMG'&&posterish(t))?t:null;}
  function directImageAnchor(img){var a=img&&img.closest?img.closest('a[href]'):null;if(!a)return null;var h=a.getAttribute('href')||'';return(urlIsDL1(h)||IMG_EXT.test(h))?a:null;}
  function hard(e){var img=imgFromEvent(e);if(!img)return;e.preventDefault();e.stopPropagation();if(e.stopImmediatePropagation)e.stopImmediatePropagation();return false;}
  document.addEventListener('contextmenu',hard,true);
  document.addEventListener('dragstart',hard,true);
  document.addEventListener('selectstart',function(e){if(imgFromEvent(e))hard(e)},true);
  document.addEventListener('auxclick',function(e){if(imgFromEvent(e))hard(e)},true);
  document.addEventListener('mousedown',function(e){var img=imgFromEvent(e);if(!img)return;if(e.button===1||e.button===2||(e.button===0&&directImageAnchor(img)))hard(e)},true);
  document.addEventListener('click',function(e){var img=imgFromEvent(e);if(img&&directImageAnchor(img))hard(e)},true);
  document.addEventListener('touchstart',function(e){var img=imgFromEvent(e);if(img)mark(img)}, {capture:true,passive:true});
  function boot(){scan(document);if(window.MutationObserver)new MutationObserver(function(ms){for(var i=0;i<ms.length;i++){var m=ms[i];if(m.type==='attributes'&&m.target&&m.target.tagName==='IMG')mark(m.target);if(m.addedNodes)for(var j=0;j<m.addedNodes.length;j++){var n=m.addedNodes[j];if(n&&n.nodeType===1)scan(n)}}}).observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['src','srcset','data-src','data-srcset','data-lazy-src','class']});}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
})();
</script>
