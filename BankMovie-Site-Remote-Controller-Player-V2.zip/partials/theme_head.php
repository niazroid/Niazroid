<?php
// BankMovie color-mode bootstrap. This is intentionally independent from the
// existing accent/theme cookie so the user's accent choice stays untouched.
?>
<script id="bm-theme-bootstrap-v144">
(function(d){
  'use strict';
  var mode='dark';
  try{
    var stored=localStorage.getItem('bm_color_mode');
    if(stored!=='light'&&stored!=='dark'){
      var match=d.cookie.match(/(?:^|;\s*)bm_color_mode=(light|dark)(?:;|$)/);
      stored=match?match[1]:'';
    }
    if(stored==='light'||stored==='dark') mode=stored;
  }catch(e){}
  d.documentElement.setAttribute('data-bm-color-mode',mode);
  d.documentElement.style.colorScheme=mode;
  window.BM_INITIAL_COLOR_MODE=mode;
})(document);
</script>
<link rel="stylesheet" href="/assets/css/bm-theme-v144.css?v=144">
<link rel="stylesheet" href="/assets/css/bm-theme-v145.css?v=145">
<link rel="stylesheet" href="/assets/css/bm-theme-v146.css?v=146">
<link rel="stylesheet" href="/assets/css/bm-theme-v147.css?v=147">
<script src="/assets/js/bm-theme-v144.js?v=146" defer></script>
