<?php
if (!empty($GLOBALS['BM_LOADING_MANAGER_RENDERED'])) return;
$GLOBALS['BM_LOADING_MANAGER_RENDERED'] = true;
require_once dirname(__DIR__) . '/includes/site_content_control.php';
require_once dirname(__DIR__) . '/includes/user_theme.php';
require_once dirname(__DIR__) . '/includes/public_assets.php';

$bmLoadingScript = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
$bmLoadingPage = match ($bmLoadingScript) {
    'index.php' => 'home',
    'movie.php' => 'movie',
    'search.php' => 'search',
    'view_all.php', 'archive1_live.php', 'catalog.php' => 'archives',
    'player.php' => 'player',
    'collection.php', 'collections.php', 'categories.php', 'genres.php', 'actors.php', 'top_rated_by_users.php' => 'collections',
    'profile.php', 'login.php', 'register.php' => 'profile',
    default => 'other',
};
$bmLoadingPageKey = [
    'home' => 'loading_home_enabled',
    'movie' => 'loading_movie_enabled',
    'search' => 'loading_search_enabled',
    'archives' => 'loading_archives_enabled',
    'player' => 'loading_player_enabled',
    'collections' => 'loading_collections_enabled',
    'profile' => 'loading_profile_enabled',
    'other' => 'loading_other_pages_enabled',
][$bmLoadingPage] ?? 'loading_other_pages_enabled';
$bmLoadingEnabled = bm_site_bool('loading_enabled', true) && bm_site_bool($bmLoadingPageKey, $bmLoadingPage !== 'other');
$bmLoadingTheme = bm_theme_resolve(isset($currentUser) && is_array($currentUser) ? $currentUser : null);
$bmLoadingCatalog = bm_theme_catalog();
$bmLoadingThemeInfo = $bmLoadingCatalog[$bmLoadingTheme] ?? $bmLoadingCatalog['dark-green'];
$bmLoadingUseTheme = bm_site_bool('loading_use_theme_accent', true);
$bmLoadingAccent = $bmLoadingUseTheme ? (string)$bmLoadingThemeInfo['primary'] : (string)bm_site_get('loading_accent_color', '#2f7cff');
$bmLoadingAccentRgb = $bmLoadingUseTheme ? (string)$bmLoadingThemeInfo['rgb'] : '';
$bmHexToRgb = static function (string $hex): string {
    $hex = ltrim(trim($hex), '#');
    if (!preg_match('/^[0-9a-fA-F]{6}$/', $hex)) return '47,124,255';
    return hexdec(substr($hex,0,2)).','.hexdec(substr($hex,2,2)).','.hexdec(substr($hex,4,2));
};
if ($bmLoadingAccentRgb === '') $bmLoadingAccentRgb = $bmHexToRgb($bmLoadingAccent);
$bmLoadingBg = (string)bm_site_get('loading_background_color', '#05070d');
$bmLoadingLogo = trim((string)bm_site_get('loading_logo_path', ''));
if ($bmLoadingLogo === '') {
    $bmLoadingLogo = (string)($bmLoadingThemeInfo['logo'] ?? bm_site_get('brand_logo_path', '/assets/brand/bankmovie-logo.webp'));
}
$bmLoadingLogo = bm_public_asset_url($bmLoadingLogo, '/assets/brand/bankmovie-logo.webp');
$bmLoadingConfig = [
    'enabled' => $bmLoadingEnabled,
    'page' => $bmLoadingPage,
    'style' => (string)bm_site_get('loading_style', 'logo'),
    'showLogo' => bm_site_bool('loading_show_logo', true),
    'logo' => $bmLoadingLogo,
    'showText' => bm_site_bool('loading_show_text', true),
    'text' => (string)bm_site_get('loading_text_fa', 'در حال آماده‌سازی بانک مووی...'),
    'useThemeAccent' => $bmLoadingUseTheme,
    'accent' => $bmLoadingAccent,
    'accentRgb' => $bmLoadingAccentRgb,
    'backgroundRgb' => $bmHexToRgb($bmLoadingBg),
    'backgroundOpacity' => max(.70, min(1, ((int)bm_site_get('loading_background_opacity', 96))/100)),
    'blur' => max(0, min(32, (int)bm_site_get('loading_backdrop_blur', 16))),
    'size' => max(64, min(160, (int)bm_site_get('loading_size', 104))),
    'minDuration' => max(0, min(3000, (int)bm_site_get('loading_min_duration_ms', 450))),
    'maxDuration' => max(1500, min(12000, (int)bm_site_get('loading_max_duration_ms', 4500))),
    'skeletonEnabled' => bm_site_bool('loading_skeleton_enabled', true),
    'skeletonSpeed' => max(500, min(3000, (int)bm_site_get('loading_skeleton_speed_ms', 1250))),
];
?>
<style id="bm-single-loading-guard-v1486192">
/* V148.61.9.2: only the configured loading manager may render a page loader on every public page. */
.bm-page-loader,#bmPageLoader{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important}
</style>
<link rel="stylesheet" href="/assets/css/bm-loading-manager-v14843.css?v=14843">
<script>window.BM_LOADING_CONFIG=<?= json_encode($bmLoadingConfig, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT) ?>;</script>
<script src="/assets/js/bm-loading-manager-v14843.js?v=14843"></script>
<script id="bm-single-loading-runtime-v1486192">
(function(){
  'use strict';
  function clean(){
    document.querySelectorAll('.bm-page-loader,#bmPageLoader').forEach(function(node){node.remove();});
    var overlays=Array.prototype.slice.call(document.querySelectorAll('#loadingOverlay'));
    if(overlays.length>1){
      var keep=overlays.find(function(node){return node.classList.contains('bm-loading-managed');})||overlays[0];
      overlays.forEach(function(node){if(node!==keep)node.remove();});
    }
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',clean,{once:true});else clean();
  window.addEventListener('pageshow',clean,{once:true});
})();
</script>



<!-- V148.61.9.17: balanced mobile drawer + real BankMovie BM logo asset. -->
<script id="bm-menu-v14861917-cache-guard">
(function(){
  'use strict';
  var head=document.head;
  if(!head||head.__bmMenuGuard14861917)return;
  head.__bmMenuGuard14861917=true;
  document.querySelectorAll('link[href*="bm-mobile-menu-v"],script[src*="bm-mobile-menu-v"]').forEach(function(node){
    var url='';
    try{url=String(node.src||node.href||'');}catch(e){}
    if(url.indexOf('bm-mobile-menu-v14861915')===-1)node.remove();
  });
  var append=head.appendChild;
  head.appendChild=function(node){
    var url='';
    try{url=String((node&&node.src)||(node&&node.href)||'');}catch(e){}
    if(url.indexOf('bm-mobile-menu-v')!==-1 && url.indexOf('bm-mobile-menu-v14861915')===-1)return node;
    return append.call(head,node);
  };
  window.addEventListener('load',function(){head.appendChild=append;},{once:true});
})();
</script>
<link rel="stylesheet" href="/assets/css/bm-mobile-menu-v14861915.css?v=14861917">
<script src="/assets/js/bm-mobile-menu-v14861915.js?v=14861917" defer></script>

<!-- v148.61.3: restore the previous non-floating mobile header.
     The existing v148.59/v148.60 rules keep it transparent over the hero slider
     and restore the previous glass surface after the slider. -->
<script src="/assets/js/bm-mobile-header-static-restore-v148613.js?v=148613" defer></script>
<!-- v148.61.4: attached mobile glass header. Transparent over the hero slider, glass elsewhere, never floating. -->
<link rel="stylesheet" href="/assets/css/bm-mobile-static-glass-header-v148614.css?v=148614">
<link rel="stylesheet" href="/assets/css/bm-mobile-header-stability-v148616.css?v=148616">
<!-- V148.61.9.25: final paint-only override. Keep controls, remove only the full-width mobile header shell. -->
<link rel="stylesheet" href="/assets/css/bm-mobile-header-shell-none-v14861925.css?v=14861925">

