<?php
// Lightweight domain/SEO bootstrap. This file must not connect to the database.

// ============================================
// تنظیمات سایت
// ============================================
$isHttps = (
    (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
    (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https') ||
    (!empty($_SERVER['HTTP_CF_VISITOR']) && stripos((string)$_SERVER['HTTP_CF_VISITOR'], '"https"') !== false)
);

// هر دو دامنه مجازند، ولی نسخه‌ی این بسته به‌صورت پیش‌فرض برای bankmovie.top تنظیم شده است.
// Host فقط از لیست سفید پذیرفته می‌شود تا Host Header نتواند canonical یا sitemap جعلی بسازد.
const BM_PRIMARY_DOMAIN = 'bankmovie.top';
const BM_LEGACY_DOMAIN  = 'bankmoviee.ir';
const BM_ALLOWED_DOMAINS = [BM_PRIMARY_DOMAIN, BM_LEGACY_DOMAIN];

$rawHost = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
$rawHost = preg_replace('/:\d+$/', '', $rawHost) ?: '';
$requestHost = preg_replace('/^www\./i', '', $rawHost) ?: '';

$envSiteUrl = trim((string)(getenv('BANKMOVIE_SITE_URL') ?: ''));
// SEO v148.12: every alias uses one canonical host. The legacy domain may stay reachable,
// but canonicals, sitemaps and generated URLs always point to the primary property.
if ($envSiteUrl !== '' && filter_var($envSiteUrl, FILTER_VALIDATE_URL)) {
    $canonicalSiteUrl = rtrim($envSiteUrl, '/') . '/';
} else {
    $canonicalSiteUrl = 'https://' . BM_PRIMARY_DOMAIN . '/';
}
if (!defined('BM_REQUEST_HOST')) define('BM_REQUEST_HOST', $requestHost);

define('SITE_URL', $canonicalSiteUrl);
define('SITE_NAME', 'بانک مووی');
define('SITE_NAME_LATIN', 'BankMovie');
define('SITE_DESCRIPTION', 'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله و زیرنویس فارسی.');


// ============================================
// Yektanet publisher integration — policy compliant
// ============================================
require_once __DIR__ . '/yektanet_control.php';
require_once __DIR__ . '/site_content_control.php';
require_once __DIR__ . '/user_theme.php';
bm_theme_runtime_boot();
require_once __DIR__ . '/vip_features.php';

if (!function_exists('bm_yektanet_is_public_page')) {
    function bm_yektanet_is_public_page(): bool
    {
        if (PHP_SAPI === 'cli') return false;
        if (function_exists('bm_vip_ad_free_for_user') && bm_vip_ad_free_for_user($GLOBALS['currentUser'] ?? null)) return false;
        if (function_exists('bm_site_bool') && !bm_site_bool('ads_yektanet_enabled', true)) return false;
        $settings = bm_yektanet_get_settings();
        if (empty($settings['enabled'])) return false;
        $host = bm_yektanet_clean_host((string)($_SERVER['HTTP_HOST'] ?? ''));
        // Yektanet campaign is currently active only on bankmoviee.ir.
        if ($host !== 'bankmoviee.ir') return false;
        $script = strtolower(basename((string)($_SERVER['SCRIPT_NAME'] ?? '')));
        return in_array($script, (array)$settings['pages'], true);
    }
}

if (!function_exists('bm_yektanet_is_mobile_request')) {
    function bm_yektanet_is_mobile_request(): bool
    {
        // Mobile/desktop output must not be mixed by intermediary caches.
        if (!headers_sent()) {
            header('Accept-CH: Sec-CH-UA-Mobile', false);
            header('Vary: User-Agent, Sec-CH-UA-Mobile', false);
        }

        $hint = trim((string)($_SERVER['HTTP_SEC_CH_UA_MOBILE'] ?? ''));
        if ($hint === '?1' || $hint === '1') return true;
        if ($hint === '?0' || $hint === '0') return false;

        $ua = strtolower((string)($_SERVER['HTTP_USER_AGENT'] ?? ''));
        if ($ua === '') return false;
        return (bool)preg_match(
            '/android|iphone|ipod|blackberry|iemobile|opera mini|mobile|webos|windows phone/i',
            $ua
        );
    }
}

if (!function_exists('bm_yektanet_head_markup')) {
    function bm_yektanet_head_markup(): string
    {
        $settings = bm_yektanet_get_settings();
        $publisherUrl = bm_yektanet_valid_publisher_url((string)($settings['publisher_url'] ?? ''));
        if (empty($settings['enabled']) || $publisherUrl === '') return '';
        if (function_exists('bm_site_bool') && !bm_site_bool('ads_yektanet_enabled', true)) return '';

        $urlJson = json_encode($publisherUrl, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        if (!is_string($urlJson)) return '';

        return "<script>\n"
            . "            !function(e,t,n){e.yektanetAnalyticsObject=n,e[n]=e[n]||function(){e[n].q.push(arguments)},e[n].q=e[n].q||[];var a=t.getElementsByTagName(\"head\")[0],r=new Date,c="
            . $urlJson
            . "+\"?v=\"+r.getFullYear().toString()+\"0\"+r.getMonth()+\"0\"+r.getDate()+\"0\"+r.getHours(),s=t.createElement(\"link\");s.rel=\"preload\",s.as=\"script\",s.href=c,a.appendChild(s);var l=t.createElement(\"script\");l.async=!0,l.src=c,a.appendChild(l)}(window,document,\"yektanet\");\n"
            . "        </script>";
    }
}

if (!function_exists('bm_yektanet_render_slot')) {
    function bm_yektanet_render_slot(string $position, string $variant = 'raw'): string
    {
        if (!bm_yektanet_is_public_page()) return '';

        $settings = bm_yektanet_get_settings();
        $slot = isset($settings['slots'][$position]) && is_array($settings['slots'][$position])
            ? $settings['slots'][$position]
            : [];

        if (empty($slot['enabled'])) return '';

        $sitePositionKeys = [
            'global_banner' => 'ads_global_banner_enabled',
            'home_top' => 'ads_home_top_enabled',
            'home_middle' => 'ads_home_middle_enabled',
            'home_bottom' => 'ads_home_bottom_enabled',
            'movie_page' => 'ads_movie_page_enabled',
            'mobile' => 'ads_floating_enabled',
        ];
        if (function_exists('bm_site_bool') && isset($sitePositionKeys[$position]) && !bm_site_bool($sitePositionKeys[$position], true)) return '';

        $device = strtolower((string)($slot['device'] ?? 'all'));
        $isMobile = bm_yektanet_is_mobile_request();
        if (function_exists('bm_site_bool')) {
            if ($isMobile && !bm_site_bool('ads_mobile_enabled', true)) return '';
            if (!$isMobile && !bm_site_bool('ads_desktop_enabled', true)) return '';
            if ($variant === 'floating' && !bm_site_bool('ads_floating_enabled', true)) return '';
        }
        if ($device === 'mobile' && !$isMobile) return '';
        if ($device === 'desktop' && $isMobile) return '';

        $html = trim((string)($slot['html'] ?? ''));
        if ($html === '') return '';

        static $renderedCount = 0;
        static $renderedIds = [];
        if ($renderedCount >= 4) return '';

        if (preg_match_all('/\bid\s*=\s*["\']([^"\']+)["\']/i', $html, $matches)) {
            foreach ($matches[1] as $id) {
                $key = strtolower(trim((string)$id));
                if ($key !== '' && isset($renderedIds[$key])) return '';
            }
            foreach ($matches[1] as $id) {
                $key = strtolower(trim((string)$id));
                if ($key !== '') $renderedIds[$key] = true;
            }
        }

        $renderedCount++;
        return $html;
    }
}

if (bm_yektanet_is_public_page() && !defined('BM_YEKTANET_BUFFER_STARTED')) {
    define('BM_YEKTANET_BUFFER_STARTED', true);
    ob_start(static function (string $buffer): string {
        if (stripos($buffer, '</head>') !== false && stripos($buffer, 'yektanetAnalyticsObject') === false) {
            $headMarkup = bm_yektanet_head_markup();
            if ($headMarkup !== '') {
                $buffer = preg_replace('/<\/head>/i', $headMarkup . "\n</head>", $buffer, 1) ?? $buffer;
            }
        }
        return $buffer;
    });
}


// Inject the selected public-site font into every HTML page that uses the lightweight
// site bootstrap. API/JSON responses are untouched because they do not contain </head>.
if (PHP_SAPI !== 'cli' && !defined('BM_SITE_TYPOGRAPHY_BUFFER_STARTED')) {
    define('BM_SITE_TYPOGRAPHY_BUFFER_STARTED', true);
    ob_start(static function (string $buffer): string {
        if (stripos($buffer, '</head>') === false || stripos($buffer, 'bm-site-typography-runtime') !== false) {
            return $buffer;
        }
        $preload = bm_site_typography_preload();
        $includePreload = $preload['href'] === '' || stripos($buffer, $preload['href']) === false;
        $markup = bm_site_typography_head_markup($includePreload);
        return preg_replace('/<\/head>/i', $markup . "\n</head>", $buffer, 1) ?? $buffer;
    });
}

// Central SEO runtime: canonical, robots, social cards and structured data for every public HTML page.
require_once __DIR__ . '/bm_seo.php';
