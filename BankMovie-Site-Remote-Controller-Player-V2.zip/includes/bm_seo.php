<?php
/**
 * BankMovie SEO runtime v148.12
 * Central canonical, robots, Open Graph, Twitter and schema injection.
 * It only touches HTML pages that contain </head>; API/XML/file responses are ignored.
 */

if (!function_exists('bm_seo_h')) {
    function bm_seo_h($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('bm_seo_cut')) {
    function bm_seo_cut(string $value, int $length): string
    {
        $value = trim(preg_replace('/\s+/u', ' ', strip_tags($value)) ?: '');
        if ($value === '') return '';
        return function_exists('mb_substr') ? mb_substr($value, 0, $length, 'UTF-8') : substr($value, 0, $length);
    }
}

if (!function_exists('bm_seo_base_url')) {
    function bm_seo_base_url(): string
    {
        $fallback = defined('SITE_URL') ? (string)SITE_URL : 'https://bankmovie.top/';
        $configured = function_exists('bm_site_get')
            ? trim((string)bm_site_get('seo_canonical_base_url', $fallback))
            : $fallback;
        if ($configured === '' || !filter_var($configured, FILTER_VALIDATE_URL)) $configured = $fallback;
        $parts = @parse_url($configured);
        if (!is_array($parts) || empty($parts['host'])) return 'https://bankmovie.top';
        $scheme = strtolower((string)($parts['scheme'] ?? 'https')) === 'http' ? 'https' : strtolower((string)($parts['scheme'] ?? 'https'));
        $host = strtolower((string)$parts['host']);
        $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
        $path = trim((string)($parts['path'] ?? ''), '/');
        return rtrim($scheme . '://' . $host . $port . ($path !== '' ? '/' . $path : ''), '/');
    }
}

if (!function_exists('bm_seo_abs_url')) {
    function bm_seo_abs_url(string $value): string
    {
        $value = trim($value);
        if ($value === '') return '';
        if (preg_match('~^https?://~i', $value)) return preg_replace('~^http://~i', 'https://', $value) ?: $value;
        if (str_starts_with($value, '//')) return 'https:' . $value;
        return bm_seo_base_url() . '/' . ltrim($value, '/');
    }
}

if (!function_exists('bm_seo_request_path')) {
    function bm_seo_request_path(): string
    {
        $uri = (string)($_SERVER['REQUEST_URI'] ?? '/');
        $path = (string)(parse_url($uri, PHP_URL_PATH) ?: '/');
        $path = '/' . ltrim(preg_replace('~/+~', '/', $path) ?: '/', '/');
        if ($path !== '/') $path = rtrim($path, '/');
        $path = preg_replace('~/(index)\.php$~i', '/', $path) ?: $path;
        $cleanRoutes = ['search','categories','genres','collections','collection','boxoffice','profile','player','login','register','logout','request','team','actors','catalog','view_all','top_rated_by_users','download_app','map','application'];
        foreach ($cleanRoutes as $route) {
            if (strcasecmp($path, '/' . $route . '.php') === 0) return '/' . $route;
        }
        return $path;
    }
}

if (!function_exists('bm_seo_canonical_query')) {
    function bm_seo_canonical_query(string $path): array
    {
        $query = $_GET;
        foreach (array_keys($query) as $key) {
            if (preg_match('/^(utm_.+|gclid|dclid|fbclid|yclid|mc_cid|mc_eid|ref|source)$/i', (string)$key)) unset($query[$key]);
        }
        if ($path === '/collection') {
            return [];
        }
        if ($path === '/catalog') {
            $out = [];
            $type = strtolower(trim((string)($query['type'] ?? 'movie')));
            $out['type'] = in_array($type, ['movie','series'], true) ? $type : 'movie';
            $page = max(1, (int)($query['page'] ?? 1));
            if ($page > 1) $out['page'] = $page;
            return $out;
        }
        if ($path === '/view_all' || $path === '/genres') {
            $allowed = ['archive','type','genre','category','page','sort','list','source'];
            $out = [];
            foreach ($allowed as $key) {
                if (!isset($query[$key]) || is_array($query[$key])) continue;
                $value = trim((string)$query[$key]);
                if ($value === '' || ($key === 'page' && (int)$value <= 1)) continue;
                $out[$key] = $key === 'page' ? max(1, (int)$value) : bm_seo_cut($value, 120);
            }
            ksort($out);
            return $out;
        }
        if ($path === '/search') return [];
        return [];
    }
}

if (!function_exists('bm_seo_canonical_url')) {
    function bm_seo_canonical_url(): string
    {
        $path = bm_seo_request_path();
        if ($path === '/collection') {
            $slug = trim((string)($_GET['slug'] ?? ''));
            if ($slug !== '') $path = '/collection/' . rawurlencode($slug);
        }
        $query = bm_seo_canonical_query($path);
        $url = bm_seo_base_url() . ($path === '/' ? '/' : $path);
        if ($query) $url .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        return $url;
    }
}

if (!function_exists('bm_seo_is_private_path')) {
    function bm_seo_is_private_path(string $path): bool
    {
        return (bool)preg_match('~^/(?:admin|bm_admin|api|ajax|bot|import|proxy|login|register|profile|logout|request|account_route_check|mark_notification_seen)(?:[_.\-/]|$)~i', $path);
    }
}

if (!function_exists('bm_seo_should_noindex')) {
    function bm_seo_should_noindex(string $path): bool
    {
        if (bm_seo_is_private_path($path)) return true;
        if (preg_match('~^/(?:400|401|403|404|405|429|502|503)(?:\.php)?$~', $path)) return true;
        if ($path === '/search' && !empty($_GET)) return true;
        if ($path === '/player') return true;
        return false;
    }
}

if (!function_exists('bm_seo_page_label')) {
    function bm_seo_page_label(string $path): string
    {
        $labels = [
            '/' => 'خانه', '/categories' => 'دسته‌بندی', '/genres' => 'ژانرها', '/collections' => 'کالکشن‌ها', '/boxoffice' => 'باکس آفیس',
            '/collection' => 'کالکشن', '/catalog' => 'آرشیو', '/search' => 'جستجو', '/application' => 'اپلیکیشن‌ها',
            '/download_app' => 'دانلود اپلیکیشن', '/top_rated_by_users' => 'برترین‌های کاربران', '/actors' => 'بازیگران', '/map' => 'نقشه سایت',
        ];
        if (preg_match('~^/movie/~', $path)) return 'فیلم و سریال';
        if (preg_match('~^/collection/~', $path)) return 'کالکشن';
        return $labels[$path] ?? 'بانک مووی';
    }
}

if (!function_exists('bm_seo_default_description')) {
    function bm_seo_default_description(string $path): string
    {
        $siteDesc = function_exists('bm_site_get')
            ? (string)bm_site_get('seo_default_description', bm_site_get('site_description_fa', 'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله و زیرنویس فارسی.'))
            : 'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله و زیرنویس فارسی.';
        $map = [
            '/categories' => 'مسیر دلخواهت را از میان ژانرها، کالکشن‌ها و برترین فیلم‌ها و سریال‌ها انتخاب کن.',
            '/genres' => 'فیلم‌ها و سریال‌های بانک مووی را بر اساس ژانر، آرشیو و نوع محتوا پیدا کن.',
            '/collections' => 'کالکشن فیلم‌های دنباله‌دار و مجموعه‌های سینمایی را مرتب و یکجا مرور کن.',
            '/boxoffice' => 'جدیدترین رتبه‌بندی باکس آفیس، فروش آخر هفته و رکوردهای فروش سینمای جهان را در بانک مووی دنبال کن.',
            '/catalog' => 'آرشیو قابل پیمایش فیلم‌ها و سریال‌های بانک مووی با صفحه‌بندی و لینک مستقیم به هر عنوان.',
            '/application' => 'نسخه‌های اپلیکیشن بانک مووی برای موبایل، تلویزیون و وب را دریافت کن.',
            '/top_rated_by_users' => 'فیلم‌ها و سریال‌هایی که کاربران بانک مووی بیشترین امتیاز را به آن‌ها داده‌اند.',
        ];
        return bm_seo_cut($map[$path] ?? $siteDesc, 170);
    }
}

if (!function_exists('bm_seo_default_image')) {
    function bm_seo_default_image(): string
    {
        $path = function_exists('bm_site_get') ? (string)bm_site_get('seo_default_og_image', '/assets/brand/bankmovie-og.png') : '/assets/brand/bankmovie-og.png';
        return bm_seo_abs_url($path);
    }
}

if (!function_exists('bm_seo_breadcrumb_schema')) {
    function bm_seo_breadcrumb_schema(string $path, string $canonical, string $title): array
    {
        $base = bm_seo_base_url();
        $items = [[
            '@type' => 'ListItem', 'position' => 1, 'name' => 'بانک مووی', 'item' => $base . '/'
        ]];
        if ($path !== '/') {
            if (preg_match('~^/movie/~', $path)) {
                $items[] = ['@type'=>'ListItem','position'=>2,'name'=>'آرشیو فیلم و سریال','item'=>$base . '/catalog?type=movie'];
            } elseif (preg_match('~^/collection/~', $path)) {
                $items[] = ['@type'=>'ListItem','position'=>2,'name'=>'کالکشن‌ها','item'=>$base . '/collections'];
            }
            $items[] = ['@type'=>'ListItem','position'=>count($items)+1,'name'=>bm_seo_cut($title !== '' ? $title : bm_seo_page_label($path), 100),'item'=>$canonical];
        }
        return ['@type'=>'BreadcrumbList','@id'=>$canonical . '#breadcrumb','itemListElement'=>$items];
    }
}

if (!function_exists('bm_seo_generic_schema')) {
    function bm_seo_generic_schema(string $path, string $canonical, string $title, string $description, string $image): array
    {
        $base = bm_seo_base_url();
        $siteName = function_exists('bm_site_get') ? (string)bm_site_get('site_name_fa', 'بانک مووی') : 'بانک مووی';
        $orgName = function_exists('bm_site_get') ? (string)bm_site_get('seo_organization_name', $siteName) : $siteName;
        $logo = bm_seo_abs_url(function_exists('bm_site_get') ? (string)bm_site_get('seo_organization_logo', '/assets/brand/bankmovie-icon.png') : '/assets/brand/bankmovie-icon.png');
        $sameAs = [];
        if (function_exists('bm_site_bool') && bm_site_bool('telegram_enabled', true)) {
            $v = trim((string)bm_site_get('telegram_url', '')); if ($v !== '') $sameAs[] = $v;
        }
        if (function_exists('bm_site_bool') && bm_site_bool('instagram_enabled', true)) {
            $v = trim((string)bm_site_get('instagram_url', '')); if ($v !== '') $sameAs[] = $v;
        }
        $graph = [
            [
                '@type'=>'Organization','@id'=>$base . '/#organization','name'=>$orgName,'alternateName'=>'BankMovie',
                'url'=>$base . '/','logo'=>['@type'=>'ImageObject','url'=>$logo]
            ],
            [
                '@type'=>'WebSite','@id'=>$base . '/#website','url'=>$base . '/','name'=>$siteName,'alternateName'=>['BankMovie','Bank Movie'],
                'publisher'=>['@id'=>$base . '/#organization'],'inLanguage'=>'fa-IR'
            ],
            [
                '@type'=>$path === '/' ? 'WebPage' : (preg_match('~^/collection(?:/|$)~',$path) ? 'CollectionPage' : 'WebPage'),
                '@id'=>$canonical . '#webpage','url'=>$canonical,'name'=>$title,'description'=>$description,'inLanguage'=>'fa-IR',
                'isPartOf'=>['@id'=>$base . '/#website'],'breadcrumb'=>['@id'=>$canonical . '#breadcrumb']
            ],
            bm_seo_breadcrumb_schema($path, $canonical, $title),
        ];
        if ($image !== '') $graph[2]['primaryImageOfPage'] = ['@type'=>'ImageObject','url'=>$image];
        if ($sameAs) $graph[0]['sameAs'] = array_values(array_unique($sameAs));
        return ['@context'=>'https://schema.org','@graph'=>$graph];
    }
}

if (!function_exists('bm_seo_meta_exists')) {
    function bm_seo_meta_exists(string $html, string $attr, string $value): bool
    {
        return (bool)preg_match('~<meta\b[^>]*\b' . preg_quote($attr, '~') . '\s*=\s*["\']' . preg_quote($value, '~') . '["\'][^>]*>~i', $html);
    }
}

if (!function_exists('bm_seo_inject_head')) {
    function bm_seo_inject_head(string $html): string
    {
        if (stripos($html, '</head>') === false) return $html;
        if (function_exists('bm_site_bool') && !bm_site_bool('seo_enabled', true)) return $html;
        if (stripos($html, 'data-bm-seo-runtime="148.12"') !== false) return $html;

        $path = bm_seo_request_path();
        $canonical = bm_seo_canonical_url();
        $noindex = bm_seo_should_noindex($path);
        $siteName = function_exists('bm_site_get') ? (string)bm_site_get('site_name_fa', 'بانک مووی') : 'بانک مووی';

        $title = '';
        if (preg_match('~<title[^>]*>(.*?)</title>~is', $html, $m)) $title = bm_seo_cut(html_entity_decode(strip_tags($m[1]), ENT_QUOTES | ENT_HTML5, 'UTF-8'), 110);
        if ($title === '') $title = bm_seo_page_label($path) . ' | ' . $siteName;

        $description = '';
        if (preg_match('~<meta\b[^>]*name=["\']description["\'][^>]*content=["\']([^"\']*)["\'][^>]*>~i', $html, $m) || preg_match('~<meta\b[^>]*content=["\']([^"\']*)["\'][^>]*name=["\']description["\'][^>]*>~i', $html, $m)) {
            $description = bm_seo_cut(html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8'), 170);
        }
        if ($description === '') $description = bm_seo_default_description($path);
        $image = bm_seo_default_image();

        $injected = "\n<!-- BankMovie SEO runtime v148.12 -->\n<meta data-bm-seo-runtime=\"148.12\" name=\"bm-seo-version\" content=\"148.12\">\n";

        if (!preg_match('~<link\b[^>]*rel=["\']canonical["\'][^>]*>~i', $html)) {
            $injected .= '<link rel="canonical" href="' . bm_seo_h($canonical) . '">' . "\n";
        }
        if (!bm_seo_meta_exists($html, 'name', 'description')) {
            $injected .= '<meta name="description" content="' . bm_seo_h($description) . '">' . "\n";
        }
        if ($noindex) {
            if (preg_match('~<meta\b[^>]*name=["\']robots["\'][^>]*>~i', $html)) {
                $html = preg_replace('~<meta\b[^>]*name=["\']robots["\'][^>]*>~i', '<meta name="robots" content="noindex, nofollow, noarchive">', $html, 1) ?? $html;
            } else {
                $injected .= "<meta name=\"robots\" content=\"noindex, nofollow, noarchive\">\n";
            }
        } elseif (!bm_seo_meta_exists($html, 'name', 'robots')) {
            $injected .= "<meta name=\"robots\" content=\"index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1\">\n";
        }

        $googleVerification = function_exists('bm_site_get') ? trim((string)bm_site_get('seo_google_verification', '')) : '';
        $bingVerification = function_exists('bm_site_get') ? trim((string)bm_site_get('seo_bing_verification', '')) : '';
        if ($googleVerification !== '' && !bm_seo_meta_exists($html, 'name', 'google-site-verification')) $injected .= '<meta name="google-site-verification" content="' . bm_seo_h($googleVerification) . '">' . "\n";
        if ($bingVerification !== '' && !bm_seo_meta_exists($html, 'name', 'msvalidate.01')) $injected .= '<meta name="msvalidate.01" content="' . bm_seo_h($bingVerification) . '">' . "\n";

        if (!function_exists('bm_site_bool') || bm_site_bool('seo_open_graph_enabled', true)) {
            $og = [
                'og:type' => preg_match('~^/movie/~',$path) ? 'video.other' : 'website',
                'og:locale' => 'fa_IR', 'og:site_name' => $siteName, 'og:title' => $title,
                'og:description' => $description, 'og:url' => $canonical, 'og:image' => $image,
            ];
            foreach ($og as $property => $content) {
                if ($content !== '' && !bm_seo_meta_exists($html, 'property', $property)) $injected .= '<meta property="' . bm_seo_h($property) . '" content="' . bm_seo_h($content) . '">' . "\n";
            }
        }
        if (!function_exists('bm_site_bool') || bm_site_bool('seo_twitter_cards_enabled', true)) {
            $twitter = ['twitter:card'=>'summary_large_image','twitter:title'=>$title,'twitter:description'=>$description,'twitter:image'=>$image];
            foreach ($twitter as $name => $content) {
                if ($content !== '' && !bm_seo_meta_exists($html, 'name', $name)) $injected .= '<meta name="' . bm_seo_h($name) . '" content="' . bm_seo_h($content) . '">' . "\n";
            }
        }
        if ((!function_exists('bm_site_bool') || bm_site_bool('seo_jsonld_enabled', true)) && stripos($html, '"BreadcrumbList"') === false && stripos($html, "'BreadcrumbList'") === false) {
            $schema = bm_seo_generic_schema($path, $canonical, $title, $description, $image);
            $json = json_encode($schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT);
            if (is_string($json)) $injected .= '<script type="application/ld+json">' . $json . "</script>\n";
        }
        return preg_replace('/<\/head>/i', $injected . '</head>', $html, 1) ?? $html;
    }
}

if (PHP_SAPI !== 'cli' && !defined('BM_SEO_RUNTIME_STARTED')) {
    define('BM_SEO_RUNTIME_STARTED', true);
    $path = bm_seo_request_path();
    if (bm_seo_should_noindex($path) && !headers_sent()) {
        header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    }
    ob_start('bm_seo_inject_head');
}
