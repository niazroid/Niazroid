<?php
/**
 * کد HTML جایگاه‌های یکتانت را دقیقاً بین HEREDOC هر بخش قرار دهید.
 * اسکریپت اصلی یکتانت به‌صورت سراسری توسط site_bootstrap.php داخل <head> بارگذاری می‌شود.
 *
 * نمونه کد جایگاه را از پنل ناشران یکتانت کپی کنید؛ کدها را تغییر ندهید.
 */
return [
    'home_top' => <<<'HTML'

HTML,
    'home_middle' => <<<'HTML'

HTML,
    'home_bottom' => <<<'HTML'

HTML,
    'movie_page' => <<<'HTML'

HTML,
    'mobile' => <<<'HTML'

HTML,
    'global_banner' => <<<'HTML'
<div class="yn-bnr" id="ynpos-19355"></div>
HTML,
];
