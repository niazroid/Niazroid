<?php
require_once __DIR__ . '/security_bootstrap.php';
/**
 * api2_lib.php — توابع استخراج فیلم/سریال از oldtowns.top
 * این فایل فقط توابع دارد، بدون JSON output
 * برای include در movie.php استفاده می‌شود
 */
if(defined('API2_LIB_LOADED')) return;
define('API2_LIB_LOADED', true);

/*
 * API استخراج اطلاعات فیلم/سریال
 * نسخه اصلاح‌شده و حرفه‌ای
 *
 * تغییرات اصلی نسبت به نسخه قبل:
 *  - رفع باگ بزرگ: جستجوی جزئیات دیگر فقط با الگوی /series/ ساخته نمی‌شود؛
 *    برای هر شناسه، هم آدرس فیلم و هم آدرس سریال تلاش می‌شود (و در صورت
 *    دادن پارامتر type، اول حدس درست‌تر امتحان می‌شود).
 *  - امکان دریافت جزئیات مستقیم با لینک کامل صفحه (?url=...) برای دقت ۱۰۰٪.
 *  - حذف میانبر «اگر فقط ۱ نتیجه بود، خروجی را عوض کن» چون با ساختار
 *    خروجی لیست ناهماهنگ بود و باعث «نتیجه‌ای پیدا نشد» کاذب می‌شد.
 *  - دسترسی امن‌تر به همه‌ی فیلدهای آرایه (با ??) تا نوتیس‌های PHP باعث
 *    خطای ۵۰۰ روی میزبان‌های سخت‌گیر نشوند.
 *  - تلاش مجدد در صورت شکست curl + هدرهای واقعی‌تر مرورگر.
 *  - رفع باگ ژانرهای اضافی: محدود کردن جستجوی ژانرها به بخش اصلی صفحه
 *    (post-intro) با استفاده از context و کوئری نسبی (.//) تا ژانرهای
 *    سریال‌های پیشنهادی تداخل نکنند.
 */

// [header removed for lib mode]

define('BASE_URL', function_exists('bm_archive_source_base_url')
    ? bm_archive_source_base_url('archive1', 'https://www.my-f2mx.top')
    : 'https://www.my-f2mx.top');
define('HTTP_TIMEOUT', 12);
if (!defined('API2_SECTION_CACHE_TTL')) define('API2_SECTION_CACHE_TTL', 600); // 10 minutes

// ==================== کمکی‌های HTTP ====================

/**
 * Only cache archive/list pages. Detail pages and searches stay live so
 * download links and search results are never unintentionally delayed.
 */
function api2_should_cache_html_url($url) {
    $parts = @parse_url((string)$url);
    if (!is_array($parts)) return false;
    $host = strtolower((string)($parts['host'] ?? ''));
    $baseHost = strtolower((string)(parse_url(BASE_URL, PHP_URL_HOST) ?: ''));
    if ($host === '' || $host !== $baseHost) return false;

    $query = [];
    parse_str((string)($parts['query'] ?? ''), $query);
    if (isset($query['s']) || isset($query['search']) || isset($query['id']) || isset($query['url'])) return false;

    $path = '/' . ltrim((string)($parts['path'] ?? '/'), '/');
    if ($path === '/' || $path === '') return true;
    if (preg_match('~^/(movies|series)/?$~i', $path)) return true;
    if (preg_match('~^/(movies|series)/page/[0-9]+/?$~i', $path)) return true;
    if (preg_match('~^/category/[^/]+(?:/page/[0-9]+)?/?$~i', $path)) return true;
    if (preg_match('~^/(250tmdb|250tsdb)(?:/page/[0-9]+)?/?$~i', $path)) return true;
    return false;
}

function api2_html_cache_path($url) {
    $url = trim((string)$url);
    $parts = @parse_url($url);
    if (is_array($parts)) {
        $query = [];
        parse_str((string)($parts['query'] ?? ''), $query);
        foreach (array_keys($query) as $key) {
            $lower = strtolower((string)$key);
            if (in_array($lower, ['_', 'cb', 'cachebust', 'cache_bust', 'timestamp', 'ts', 'nonce', 'rnd', 'random', 'fbclid', 'gclid'], true) || str_starts_with($lower, 'utm_')) {
                unset($query[$key]);
            }
        }
        ksort($query);
        $canonical = strtolower((string)($parts['scheme'] ?? 'https')) . '://' . strtolower((string)($parts['host'] ?? ''));
        if (isset($parts['port'])) $canonical .= ':' . (int)$parts['port'];
        $canonical .= (string)($parts['path'] ?? '/');
        if ($query) $canonical .= '?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
        $url = $canonical;
    }
    $name = 'api2_html_' . sha1($url) . '.cache';
    if (function_exists('bm_security_private_path')) return bm_security_private_path($name);
    return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $name;
}

function api2_read_html_cache($file, $ttl) {
    if (!is_file($file) || (time() - (int)@filemtime($file)) > (int)$ttl) return null;
    $raw = @file_get_contents($file);
    if (!is_string($raw) || $raw === '') return null;
    $pos = strpos($raw, "
");
    if ($pos === false) return null;
    $code = (int)substr($raw, 0, $pos);
    $html = substr($raw, $pos + 1);
    if ($code <= 0 || $html === '') return null;
    return ['html' => $html, 'code' => $code, 'cache' => 'hit'];
}

function api2_write_html_cache($file, $httpCode, $html) {
    $html = (string)$html;
    if ($html === '' || strlen($html) > 6 * 1024 * 1024) return false;
    $dir = dirname($file);
    if (!is_dir($dir)) @mkdir($dir, 0700, true);
    if (!is_dir($dir) || !is_writable($dir)) return false;
    $tmp = $file . '.' . getmypid() . '.tmp';
    $ok = @file_put_contents($tmp, (int)$httpCode . "
" . (string)$html, LOCK_EX);
    if ($ok === false) { @unlink($tmp); return false; }
    @chmod($tmp, 0600);
    $renamed = @rename($tmp, $file);
    if (!$renamed) { @unlink($tmp); return false; }
    @chmod($file, 0600);
    return true;
}

function getHtml($url, $retries = 1, $timeoutSeconds = null) {
    $lastError = '';
    $requestTimeout = $timeoutSeconds === null ? HTTP_TIMEOUT : max(2, min(HTTP_TIMEOUT, (int)$timeoutSeconds));
    $cacheable = api2_should_cache_html_url($url);
    $cacheFile = $cacheable ? api2_html_cache_path($url) : null;

    if ($cacheFile) {
        $cached = api2_read_html_cache($cacheFile, API2_SECTION_CACHE_TTL);
        if ($cached !== null) return $cached;
    }

    // A lock collapses simultaneous requests for the same source page into
    // a single upstream cURL call (important because several home sections
    // are extracted from the same Archive 1 homepage).
    $lockHandle = null;
    if ($cacheFile) {
        $lockHandle = @fopen($cacheFile . '.lock', 'c');
        if (is_resource($lockHandle) && @flock($lockHandle, LOCK_EX)) {
            $cached = api2_read_html_cache($cacheFile, API2_SECTION_CACHE_TTL);
            if ($cached !== null) {
                @flock($lockHandle, LOCK_UN);
                @fclose($lockHandle);
                return $cached;
            }
        }
    }

    try {
        for ($attempt = 0; $attempt <= $retries; $attempt++) {
            $ch = curl_init();
            curl_setopt_array($ch, [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => 5,
                CURLOPT_ENCODING => '',
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                CURLOPT_HTTPHEADER => [
                    'Accept-Language: fa,en-US;q=0.8,en;q=0.6',
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
                ],
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_TIMEOUT => $requestTimeout,
                CURLOPT_CONNECTTIMEOUT => min(5, $requestTimeout)
            ]);
            $html = curl_exec($ch);
            $error = curl_error($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if (!$error && $html !== false && $httpCode > 0 && $httpCode < 500) {
                if ($cacheFile && $httpCode >= 200 && $httpCode < 400) {
                    api2_write_html_cache($cacheFile, $httpCode, $html);
                }
                return ['html' => $html, 'code' => $httpCode, 'cache' => 'miss'];
            }
            $lastError = $error ?: "HTTP $httpCode";
        }
    } finally {
        if (is_resource($lockHandle)) {
            @flock($lockHandle, LOCK_UN);
            @fclose($lockHandle);
        }
    }

    throw new Exception("خطا در دریافت صفحه: $lastError");
}

// ==================== استخراج‌کننده‌ها ====================

function extractPoster($xpath) {
    $img = $xpath->query("//figure[contains(@class,'entry-poster')]//img");
    if ($img->length > 0) {
        $node = $img->item(0);
        $src = $node->getAttribute('src') ?: $node->getAttribute('data-splide-lazy');
        if (!$src) return null;
        $full = str_replace(['-360x480', '-180x240'], '', $src);
        return [
            'full' => (strpos($full, 'http') === 0) ? $full : BASE_URL . $full,
            'medium' => (strpos($src, 'http') === 0) ? $src : BASE_URL . $src
        ];
    }
    return null;
}

function api2_normalize_image_url($url, $baseUrl = BASE_URL) {
    $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '' || stripos($url, 'data:image') === 0) return '';
    $url = api2_abs_url_for_base($url, $baseUrl);
    // Convert WP resized images like image-360x480.jpg to the original when possible.
    $url = preg_replace('~-(\d{2,4})x(\d{2,4})(\.(?:jpe?g|png|webp))(\?.*)?$~i', '$3$4', $url);
    return $url;
}

function extractBackdrop($xpath, $html = '', $baseUrl = BASE_URL, $poster = null) {
    $candidates = [];

    $queries = [
        "//section[@id='post-intro']//img[contains(concat(' ', normalize-space(@class), ' '), ' coverimg ')]",
        "//img[contains(concat(' ', normalize-space(@class), ' '), ' mb-coverimg ')]",
        "//img[contains(concat(' ', normalize-space(@class), ' '), ' coverimg ')]",
        "//div[contains(@class,'video-player')]//video[@poster]"
    ];
    foreach ($queries as $q) {
        $nodes = $xpath->query($q);
        if (!$nodes) continue;
        foreach ($nodes as $node) {
            $src = ($node->nodeName === 'video') ? $node->getAttribute('poster') : ($node->getAttribute('src') ?: ($node->getAttribute('data-src') ?: $node->getAttribute('data-lazy-src')));
            if ($src) $candidates[] = $src;
        }
    }

    if ($html !== '') {
        if (preg_match('~<img\b[^>]*class=["\'][^"\']*\bmb-coverimg\b[^"\']*["\'][^>]*src=["\']([^"\']+)["\']~iu', $html, $m) ||
            preg_match('~<img\b[^>]*src=["\']([^"\']+)["\'][^>]*class=["\'][^"\']*\bmb-coverimg\b[^"\']*["\']~iu', $html, $m) ||
            preg_match('~<img\b[^>]*class=["\'][^"\']*\bcoverimg\b[^"\']*["\'][^>]*src=["\']([^"\']+)["\']~iu', $html, $m) ||
            preg_match('~<video\b[^>]*poster=["\']([^"\']+)["\']~iu', $html, $m)) {
            $candidates[] = $m[1];
        }
    }

    $posterUrls = [];
    if (is_array($poster)) {
        foreach (['full','medium'] as $k) {
            if (!empty($poster[$k])) $posterUrls[] = api2_normalize_image_url($poster[$k], $baseUrl);
        }
    } elseif (!empty($poster)) {
        $posterUrls[] = api2_normalize_image_url($poster, $baseUrl);
    }

    foreach ($candidates as $candidate) {
        $url = api2_normalize_image_url($candidate, $baseUrl);
        if ($url === '') continue;
        $sameAsPoster = false;
        foreach ($posterUrls as $pu) {
            if ($pu !== '' && $pu === $url) { $sameAsPoster = true; break; }
        }
        if (!$sameAsPoster) return $url;
    }
    return '';
}

/**
 * استخراج ژانرها با محدود کردن context به بخش اصلی صفحه
 * تا ژانرهای سریال‌های پیشنهادی تداخل نکنند.
 * از کوئری نسبی (.//) استفاده می‌شود تا جستجو فقط درون context انجام شود.
 */
function extractGenres($xpath, $context = null) {
    $genres = [];
    $seen = [];
    // استفاده از .// به جای // برای جستجوی نسبی از context
    $nodes = $xpath->query(".//div[contains(@class,'entry-genres') or contains(@class,'entry-ganers')]//a", $context);
    foreach ($nodes as $node) {
        $text = trim($node->textContent);
        if ($text && strpos($text, 'زیرنویس') === false && !in_array($text, $seen)) {
            $genres[] = $text;
            $seen[] = $text;
        }
    }
    return $genres;
}

function isSeriesPage($xpath, $url) {
    if ($xpath->query("//div[contains(@class,'download-season')]")->length > 0) return true;
    if (strpos($url, '/series/') !== false) return true;
    return false;
}

function extractSeriesDownloads($html) {
    $downloads = [];
    $seen = [];

    preg_match_all('/<label[^>]*class="[^"]*bulkcopy_series[^"]*"[^>]*>.*?<textarea[^>]*>(.*?)<\/textarea>.*?<\/label>/is', $html, $textareaMatches);
    if (empty($textareaMatches[1])) {
        return $downloads;
    }
    foreach ($textareaMatches[1] as $linksText) {
        $linksText = html_entity_decode($linksText, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $linksText = html_entity_decode($linksText, ENT_QUOTES | ENT_HTML5, 'UTF-8');

        $lines = preg_split('/[\r\n]+/', trim($linksText));
        foreach ($lines as $url) {
            $url = html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
            $url = str_replace(['&#13;', '&#13'], '', $url);
            $url = trim($url, " \t\n\r\0\x0B");

            if (empty($url)) continue;
            if (!filter_var($url, FILTER_VALIDATE_URL) || strpos($url, '.mkv') === false) {
                continue;
            }

            $season = null;
            $episode = null;
       // جدید:
if (preg_match('/S(\d+)E(\d+)/i', $url, $m)) {
    $season = (int)$m[1];
    $episode = (int)$m[2];
} elseif (preg_match('/E(\d+)/i', $url, $m)) {
    // اگه S نبود، فرض کن season=1 (یا null بذار)
    $season = 1; // یا null
    $episode = (int)$m[1];
}
            $quality = 'Unknown';
            if (preg_match('/(2160p|4K|1080p|720p|480p)/i', $url, $q)) {
                $quality = strtoupper($q[1]);
            }
            $type = 'hardsub';
            if (stripos($url, 'Dubbed') !== false) {
                $type = 'dubbed';
            }
            $key = $season . '|' . $episode . '|' . $quality . '|' . $type;
            if (!isset($seen[$key])) {
                $seen[$key] = true;
                $downloads[] = [
                    'season'  => $season,
                    'episode' => $episode,
                    'quality' => $quality,
                    'type'    => $type,
                    'url'     => $url
                ];
            }
        }
    }
    usort($downloads, function($a, $b) {
        if (($a['season'] ?? 0) != ($b['season'] ?? 0)) {
            return ($a['season'] ?? 0) - ($b['season'] ?? 0);
        }
        if (($a['episode'] ?? 0) != ($b['episode'] ?? 0)) {
            return ($a['episode'] ?? 0) - ($b['episode'] ?? 0);
        }
        $qualityOrder = ['4K' => 0, '2160P' => 1, '1080P' => 2, '720P' => 3, '480P' => 4];
        $qa = $qualityOrder[$a['quality']] ?? 99;
        $qb = $qualityOrder[$b['quality']] ?? 99;
        return $qa - $qb;
    });
    return $downloads;
}

function api2_is_audio_file_url($url) {
    return (bool)preg_match('~\.(mka|mp3|m4a|aac|ogg|wav|flac)(?:[?#]|$)~i', (string)$url);
}

function api2_is_video_file_url($url) {
    return (bool)preg_match('~\.(mkv|mp4|avi|m3u8)(?:[?#]|$)~i', (string)$url);
}

function api2_quality_rank($quality) {
    $q = strtoupper((string)$quality);
    if (strpos($q, '4K') !== false || strpos($q, '2160') !== false) return 6;
    if (strpos($q, '1080') !== false) return 5;
    if (strpos($q, '720') !== false) return 4;
    if (strpos($q, '480') !== false) return 3;
    if (strpos($q, '360') !== false) return 2;
    if (strpos($q, 'صوت') !== false || stripos($q, 'audio') !== false) return 1;
    return 0;
}

function api2_extract_download_context_class($node) {
    $p = $node;
    while ($p && $p->nodeType === XML_ELEMENT_NODE) {
        if ($p->hasAttribute('class') && stripos($p->getAttribute('class'), 'download-list') !== false) {
            return strtolower($p->getAttribute('class'));
        }
        $p = $p->parentNode;
    }
    return '';
}

function api2_extract_movie_download_type($contextClass, $qualityText, $url, $rowText) {
    $hay = mb_strtolower((string)$contextClass . ' ' . (string)$qualityText . ' ' . (string)$url . ' ' . (string)$rowText, 'UTF-8');

    // Important: source pages put real dubbed video links inside:
    // <div class="download-list dubbled"> ... WEB-DL 1080p ...
    // The quality text itself may not contain "دوبله", so class/url must be used.
    if (strpos($hay, 'dubbled') !== false ||
        strpos($hay, 'dubbed') !== false ||
        strpos($hay, '/dub/') !== false ||
        strpos($hay, '.dub.') !== false ||
        strpos($hay, 'farsi.dubbed') !== false ||
        strpos($hay, 'دوبله') !== false) {
        return 'dubbed';
    }

    if (strpos($hay, 'hardsub') !== false ||
        strpos($hay, 'subbed') !== false ||
        strpos($hay, '/sub/') !== false ||
        strpos($hay, 'farsi.sub') !== false ||
        strpos($hay, 'زیرنویس') !== false ||
        strpos($hay, 'subtitle') !== false) {
        return 'subtitle';
    }

    return 'hardsub';
}

function api2_extract_movie_quality_label($qualityText, $url, $rowText, $isAudio) {
    $qualityText = api2_clean_ws($qualityText);

    if ($isAudio) {
        if (preg_match('/صوت\s+دوبله\s+فارسی/u', $qualityText . ' ' . $rowText)) {
            return 'صوت دوبله فارسی';
        }
        if (preg_match('/دوبله/u', $qualityText . ' ' . $rowText . ' ' . $url)) {
            return 'صوت دوبله فارسی';
        }
        return 'فایل صوتی';
    }

    if (preg_match('/(4K|2160p|1080p|720p|480p|360p)/iu', $qualityText . ' ' . $url, $q)) {
        return strtoupper($q[1]);
    }

    // fallback: keep meaningful text instead of Unknown
    $clean = preg_replace('/^(کیفیت\s*:?\s*)/u', '', $qualityText);
    $clean = api2_clean_ws($clean);
    if ($clean !== '') return $clean;

    return 'نامشخص';
}

function extractMovieDownloads($xpath, $html = '') {
    $downloads = [];
    $seen = [];

    // Parse each download-list separately so the parent class/title decides:
    // dubbled => dubbed, hardsub => subtitle. This fixes items whose own quality
    // only says WEB-DL 1080p and therefore used to be misclassified as subtitle.
    $lists = $xpath->query("//div[contains(concat(' ', normalize-space(@class), ' '), ' download-list ')]");
    foreach ($lists as $list) {
        $listClass = strtolower($list->getAttribute('class'));
        $listTitle = api2_first_text($xpath, ".//p[contains(@class,'title')]//span", $list);

        $items = $xpath->query(".//ul/li", $list);
        foreach ($items as $li) {
            $rowText = api2_clean_ws($li->textContent);
            $qualityText = api2_first_text($xpath, ".//span[contains(@class,'text')]", $li);

            $downloadNodes = $xpath->query(".//a[@download and @href]", $li);
            if (!$downloadNodes || $downloadNodes->length === 0) {
                // Fallback: direct media file links only, not playit pages.
                $downloadNodes = $xpath->query(".//a[contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.mkv') or contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.mp4') or contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.mka') or contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.mp3') or contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.m4a') or contains(translate(@href, 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '.aac')]", $li);
            }

            foreach ($downloadNodes as $a) {
                $href = html_entity_decode(trim($a->getAttribute('href')), ENT_QUOTES | ENT_HTML5, 'UTF-8');
                if ($href === '') continue;
                if (!preg_match('~\.(mkv|mp4|avi|m3u8|mka|mp3|m4a|aac|ogg|wav|flac)(?:[?#]|$)~i', $href)) continue;

                $href = api2_abs_url($href);
                if (isset($seen[$href])) continue;
                $seen[$href] = true;

                $isAudio = api2_is_audio_file_url($href);
                $mediaType = $isAudio ? 'audio' : 'video';
                $type = api2_extract_movie_download_type($listClass . ' ' . $listTitle, $qualityText, $href, $rowText);
                $qualityLabel = api2_extract_movie_quality_label($qualityText, $href, $rowText, $isAudio);

                $downloads[] = [
                    'season' => null,
                    'episode' => null,
                    'quality' => $qualityLabel,
                    'type' => $type,
                    'media_type' => $mediaType,
                    'audio_only' => $isAudio,
                    'label' => $isAudio ? 'صوت دوبله جداگانه' : (($type === 'dubbed') ? 'دوبله فارسی' : 'زیرنویس فارسی'),
                    'source_section' => (strpos($listClass, 'dubbled') !== false || strpos($listClass, 'dubbed') !== false) ? 'dubbled' : ((strpos($listClass, 'hardsub') !== false) ? 'hardsub' : ''),
                    'url' => $href
                ];
            }
        }
    }

    usort($downloads, function($a, $b) {
        // video first, separate audio at the bottom of the dubbed section
        $ma = ($a['media_type'] ?? 'video') === 'audio' ? 1 : 0;
        $mb = ($b['media_type'] ?? 'video') === 'audio' ? 1 : 0;
        if ($ma !== $mb) return $ma - $mb;

        $typeOrder = ['dubbed' => 0, 'subtitle' => 1, 'hardsub' => 1];
        $ta = $typeOrder[$a['type'] ?? ''] ?? 5;
        $tb = $typeOrder[$b['type'] ?? ''] ?? 5;
        if ($ta !== $tb) return $ta - $tb;

        return api2_quality_rank($b['quality'] ?? '') - api2_quality_rank($a['quality'] ?? '');
    });

    return $downloads;
}

// ==================== کمک‌کننده‌های لیست/کارت ====================

function api2_xpath_from_html($html) {
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    // جلوگیری از به‌هم‌ریختگی متن‌های فارسی در DOMDocument
    $dom->loadHTML('<?xml encoding="UTF-8">' . $html, LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors();
    return new DOMXPath($dom);
}

function api2_abs_url($href) {
    $href = trim((string)$href);
    if ($href === '') return '';
    if (strpos($href, '//') === 0) return 'https:' . $href;
    if (preg_match('/^https?:\/\//i', $href)) return $href;
    if ($href[0] === '/') return rtrim(BASE_URL, '/') . $href;
    return rtrim(BASE_URL, '/') . '/' . ltrim($href, '/');
}


function api2_abs_url_for_base($href, $base = BASE_URL) {
    $href = html_entity_decode(trim((string)$href), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($href === '') return '';
    if (strpos($href, 'data:image') === 0) return $href;
    if (preg_match('~^https?://~i', $href)) return $href;
    if (strpos($href, '//') === 0) return 'https:' . $href;

    $p = @parse_url($base);
    if (!$p || empty($p['scheme']) || empty($p['host'])) return api2_abs_url($href);
    $root = $p['scheme'] . '://' . $p['host'];
    if (strpos($href, '/') === 0) return $root . $href;
    $dir = isset($p['path']) ? preg_replace('~/[^/]*$~', '/', $p['path']) : '/';
    return $root . $dir . $href;
}

function api2_clean_ws($text) {
    $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = preg_replace('/\x{200c}+/u', '‌', $text);
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim($text);
}

function api2_first_text($xpath, $query, $context = null) {
    $nodes = $xpath->query($query, $context);
    if ($nodes && $nodes->length > 0) return api2_clean_ws($nodes->item(0)->textContent);
    return '';
}

function api2_extract_background_url($style, $baseUrl = BASE_URL) {
    $style = html_entity_decode((string)$style, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if (preg_match('~background-image\s*:\s*url\((["\']?)(.*?)\1\)~iu', $style, $m) ||
        preg_match('~url\((["\']?)(.*?)\1\)~iu', $style, $m)) {
        return api2_abs_url_for_base($m[2], $baseUrl);
    }
    return '';
}

function api2_extract_after_label($text, $label) {
    $text = api2_clean_ws($text);
    $label = preg_quote($label, '/');
    $text = preg_replace('/^.*?' . $label . '\s*[:：]?\s*/u', '', $text);
    return api2_clean_ws($text);
}

function extractDetailInfo($xpath, $context = null) {
    $info = [
        'runtime' => '',
        'release_date' => '',
        'published_date' => '',
        'status' => '',
        'age_rate' => '',
        'countries' => [],
        'languages' => [],
        'network' => '',
        'next_episode' => '',
        'next_episode_day' => '',
        'next_episode_duration' => '',
        'episode_note' => ''
    ];

    $ctx = $context ?: $xpath->query('//body')->item(0);
    $nodes = $xpath->query(".//div[contains(@class,'row') and contains(@class,'pt-4')]//div[contains(@class,'col-') or contains(@class,'d-flex')]", $ctx);
    foreach ($nodes as $node) {
        $text = api2_clean_ws($node->textContent);
        if ($text === '') continue;

        if (strpos($text, 'زمان') !== false) {
            $v = api2_extract_after_label($text, 'زمان');
            if ($v !== '') $info['runtime'] = $v;
        } elseif (strpos($text, 'اکران') !== false) {
            $v = api2_extract_after_label($text, 'اکران');
            if ($v !== '') $info['release_date'] = $v;
        } elseif (strpos($text, 'انتشار') !== false) {
            $v = api2_extract_after_label($text, 'انتشار');
            if ($v !== '') $info['published_date'] = $v;
        } elseif (strpos($text, 'وضعیت') !== false) {
            $v = api2_extract_after_label($text, 'وضعیت');
            if ($v !== '') $info['status'] = $v;
        } elseif (strpos($text, 'رده') !== false && strpos($text, 'سنی') !== false) {
            $v = api2_extract_after_label($text, 'رده‌سنی');
            if ($v === $text) $v = api2_extract_after_label($text, 'رده سنی');
            if ($v !== '') $info['age_rate'] = $v;
        } elseif (strpos($text, 'کشور سازنده') !== false || strpos($text, 'کشور') !== false) {
            $vals = [];
            foreach ($xpath->query(".//a", $node) as $a) {
                $at = api2_clean_ws($a->textContent);
                if ($at !== '' && !in_array($at, $vals, true)) $vals[] = $at;
            }
            if (empty($vals)) {
                $v = api2_extract_after_label($text, 'کشور سازنده');
                if ($v !== '') $vals[] = $v;
            }
            $info['countries'] = array_values(array_unique(array_merge($info['countries'], $vals)));
        } elseif (strpos($text, 'زبان') !== false) {
            $vals = [];
            foreach ($xpath->query(".//a", $node) as $a) {
                $at = api2_clean_ws($a->textContent);
                if ($at !== '' && !in_array($at, $vals, true)) $vals[] = $at;
            }
            if (empty($vals)) {
                $v = api2_extract_after_label($text, 'زبان');
                if ($v !== '') $vals[] = $v;
            }
            $info['languages'] = array_values(array_unique(array_merge($info['languages'], $vals)));
        } elseif (strpos($text, 'شبکه') !== false) {
            $v = api2_extract_after_label($text, 'شبکه');
            if ($v !== '') $info['network'] = $v;
        } elseif (strpos($text, 'قسمت بعدی') !== false) {
            $v = api2_extract_after_label($text, 'قسمت بعدی');
            if ($v !== '') {
                $info['next_episode'] = $v;
                if (preg_match('/^([^\s]+)\s+ساعت/u', $v, $m)) $info['next_episode_day'] = $m[1];
                if (preg_match('/\(([^)]+)\)/u', $v, $m)) $info['next_episode_duration'] = $m[1];
            }
        }
    }

    $note = api2_first_text($xpath, ".//span[contains(@class,'note')]", $ctx);
    if ($note !== '') $info['episode_note'] = $note;

    // پاک‌سازی فیلدهای خالی ولی نگهداری کلیدها برای سازگاری
    return $info;
}


function api2_actor_slug_from_url($url) {
    $url = trim((string)$url);
    if ($url === '') return '';
    $path = trim((string)(parse_url($url, PHP_URL_PATH) ?? ''), '/');
    if ($path === '') return '';
    $parts = explode('/', $path);
    $pos = array_search('actors', $parts, true);
    $slug = ($pos !== false && !empty($parts[$pos + 1])) ? (string)$parts[$pos + 1] : (string)end($parts);
    return trim(rawurldecode($slug));
}


function api2_actor_is_bad_placeholder_image($url) {
    $u = strtolower(html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($u === '') return true;
    if (strpos($u, 'data:image/svg') === 0) return true;
    if (strpos($u, '<svg') !== false || strpos($u, '%3csvg') !== false) return true;
    $badNeedles = [
        'placeholder', 'no-image', 'no_image', 'no-photo', 'no_photo',
        'default-user', 'default_avatar', 'default-avatar',
        'user-profile', 'profile-user', 'profile.png', 'avatar.png',
        'person-placeholder', 'unknown-person', 'empty-profile',
        'profile-placeholder'
    ];
    foreach ($badNeedles as $needle) {
        if (strpos($u, $needle) !== false) return true;
    }
    return false;
}

function extractActors($xpath, $baseUrl = BASE_URL) {
    $actors = [];
    $seen = [];
    $nodes = $xpath->query("//div[contains(@class,'persons-items')]//a[contains(@class,'person-item')]");
    foreach ($nodes as $node) {
        $href = api2_abs_url_for_base($node->getAttribute('href'), $baseUrl);
        $name = api2_first_text($xpath, ".//div[contains(@class,'person-name')]", $node);
        if ($name === '') $name = api2_clean_ws($node->textContent);
        $role = api2_first_text($xpath, ".//div[contains(@class,'person-role')]", $node);
        $image = '';
        $thumb = $xpath->query(".//div[contains(@class,'person-thumb')]", $node);
        if ($thumb->length > 0) $image = api2_extract_background_url($thumb->item(0)->getAttribute('style'), $baseUrl);
        if (api2_actor_is_bad_placeholder_image($image)) $image = '';

        $slug = '';
        $path = trim(parse_url($href, PHP_URL_PATH) ?? '', '/');
        if ($path !== '') {
            $parts = explode('/', $path);
            $pos = array_search('actors', $parts, true);
            if ($pos !== false && isset($parts[$pos + 1])) $slug = rawurldecode((string)$parts[$pos + 1]);
            else $slug = rawurldecode((string)end($parts));
        }
        if ($name === '') continue;
        $key = $slug ?: md5($name);
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $actors[] = [
            'name' => $name,
            'role' => $role,
            'image' => $image,
            'url' => $href,
            'slug' => $slug,
            'bankmovie_url' => '/actors?slug=' . rawurlencode($slug ?: api2_actor_slug_from_url($href) ?: $name) . '&name=' . rawurlencode($name)
        ];
    }
    return $actors;
}

function getActorDetails($identifier) {
    $identifier = trim((string)$identifier);
    if ($identifier === '') throw new Exception('شناسه بازیگر ارسال نشده است');

    $sourceHost = strtolower((string)(parse_url(BASE_URL, PHP_URL_HOST) ?: ''));
    if (preg_match('~^https?://~i', $identifier)) {
        $candidateSlug = api2_actor_slug_from_url($identifier);
        $incomingHost = strtolower((string)(parse_url($identifier, PHP_URL_HOST) ?: ''));
        // Old BankMovie/source URLs can be safely reduced to the actor slug.
        if ($candidateSlug !== '' && $incomingHost !== $sourceHost) {
            $slug = $candidateSlug;
            $url = BASE_URL . '/actors/' . rawurlencode($slug) . '/';
        } else {
            $url = $identifier;
            $slug = $candidateSlug;
        }
    } else {
        $slug = rawurldecode(trim($identifier, "/ \t"));
        $url = BASE_URL . '/actors/' . rawurlencode($slug) . '/';
    }

    // Actor pages should fail fast instead of leaving BankMovie spinning for ~25 seconds.
    $res = getHtml($url, 0, 5);
    $httpCode = (int)($res['code'] ?? 0);
    if ($httpCode >= 400) throw new Exception('صفحه بازیگر در منبع در دسترس نیست.');
    $html = (string)($res['html'] ?? '');
    if ($html === '') throw new Exception('پاسخ خالی از منبع بازیگر دریافت شد.');
    $xpath = api2_xpath_from_html($html);

    $name = api2_first_text($xpath, "//h1[contains(@class,'page-title')]");
    if ($name === '') {
        $title = api2_first_text($xpath, "//title");
        $name = preg_replace('/\s*\|.*$/u', '', str_replace('بایگانی‌های', '', $title));
        $name = api2_clean_ws($name);
    }

    $photo = '';
    $imgNode = $xpath->query("//article[contains(@class,'person-description')]//figure//img");
    if ($imgNode->length > 0) {
        $photo = $imgNode->item(0)->getAttribute('src') ?: $imgNode->item(0)->getAttribute('data-src');
        $photo = api2_abs_url_for_base($photo, $url);
    }
    if (function_exists('api2_actor_is_bad_placeholder_image') && api2_actor_is_bad_placeholder_image($photo)) $photo = '';

    $movies = api2_parse_entry_cards($xpath, null, null, 0);

    $path = trim(parse_url($url, PHP_URL_PATH) ?? '', '/');
    $parts = $path !== '' ? explode('/', $path) : [];
    $resolvedSlug = '';
    $pos = array_search('actors', $parts, true);
    if ($pos !== false && isset($parts[$pos + 1])) $resolvedSlug = rawurldecode((string)$parts[$pos + 1]);
    if ($resolvedSlug === '') $resolvedSlug = $slug ?? '';

    if ($name === '' || $name === 'پروفایل کاربری' || $name === 'Profile' || $name === 'User Profile') {
        throw new Exception('اطلاعات این بازیگر فعلاً در دسترس نیست.');
    }

    return [
        'status' => 'success',
        'source' => 'archive1',
        'type' => 'actor',
        'slug' => $resolvedSlug,
        'name' => $name,
        'photo' => $photo,
        'count' => count($movies),
        'movies' => $movies
    ];
}

function api2_clean_title($title) {
    $title = html_entity_decode((string)$title, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $title = trim(preg_replace('/\s+/u', ' ', $title));
    $title = preg_replace('/^دانلود\s+(?:فصل\s+\d+\s+)?(?:فیلم|سریال|انیمیشن|انیمه)?\s*/u', '', $title);
    $title = preg_replace('/\s*بدون\s+سانسور.*$/u', '', $title);
    $title = preg_replace('/\s*با\s+زیرنویس.*$/u', '', $title);
    return trim($title);
}

function api2_path_info_from_href($href) {
    $href = api2_abs_url($href);
    $path = trim(parse_url($href, PHP_URL_PATH) ?? '', '/');
    $parts = $path !== '' ? array_values(array_filter(explode('/', $path), 'strlen')) : [];
    $sourceSlug = !empty($parts) ? end($parts) : '';
    $detailId = $sourceSlug;
    $type = 'movie';

    if (!empty($parts) && $parts[0] === 'series') {
        $type = 'series';
        $detailId = 'series__' . $sourceSlug;
    } elseif (count($parts) >= 2 && ctype_digit($parts[0])) {
        // لینک فیلم‌های oldtowns معمولاً /ID/slug/ است؛ اگر ID حذف شود بعضی صفحه‌ها پیدا نمی‌شوند.
        $type = 'movie';
        $detailId = $parts[0] . '__' . $sourceSlug;
    } elseif (strpos($href, '/series/') !== false) {
        $type = 'series';
        $detailId = 'series__' . $sourceSlug;
    }

    return [
        'type' => $type,
        'source_path' => $path,
        'source_slug' => $sourceSlug,
        'detail_id' => $detailId,
        'url' => $href
    ];
}

function api2_parse_entry_card($xpath, $entry, $forcedType = null) {
    $linkNode = $xpath->query(".//a[contains(concat(' ', normalize-space(@class), ' '), ' stretched-link ')]", $entry);
    if ($linkNode->length === 0) {
        $linkNode = $xpath->query(".//a[@href]", $entry);
    }
    if ($linkNode->length === 0) return null;

    $href = api2_abs_url($linkNode->item(0)->getAttribute('href'));
    if ($href === '') return null;
    $pathInfo = api2_path_info_from_href($href);

    $hTitle = $xpath->query(".//h2[contains(concat(' ', normalize-space(@class), ' '), ' entry-title ')]", $entry);
    $rawTitle = $hTitle->length ? trim($hTitle->item(0)->textContent) : '';
    if ($rawTitle === '') {
        $rawTitle = trim($linkNode->item(0)->getAttribute('title') ?: $linkNode->item(0)->textContent);
    }
    $title = api2_clean_title($rawTitle);
    if ($title === '') $title = api2_clean_title($linkNode->item(0)->getAttribute('title'));

    $imgNode = $xpath->query(".//figure[contains(concat(' ', normalize-space(@class), ' '), ' entry-cover ')]//img | .//img", $entry);
    $poster = null;
    if ($imgNode->length > 0) {
        $img = $imgNode->item(0);
        $src = $img->getAttribute('data-splide-lazy')
            ?: $img->getAttribute('data-src')
            ?: $img->getAttribute('data-lazy-src')
            ?: $img->getAttribute('src');
        if (strpos($src, 'data:image') === 0) {
            $src = $img->getAttribute('data-splide-lazy') ?: $img->getAttribute('data-src') ?: $img->getAttribute('data-lazy-src');
        }
        if ($src) $poster = api2_abs_url($src);
    }

    $genres = [];
    $seenGenres = [];
    $genreNodes = $xpath->query(".//div[contains(@class,'entry-ganers') or contains(@class,'entry-genres')]//a", $entry);
    foreach ($genreNodes as $g) {
        $gText = trim($g->textContent);
        if ($gText !== '' && !in_array($gText, $seenGenres, true)) {
            $genres[] = $gText;
            $seenGenres[] = $gText;
        }
    }

    $metaText = '';
    foreach ($xpath->query(".//div[contains(@class,'entry-meta')]//span | .//p[contains(@class,'text-muted')]", $entry) as $m) {
        $metaText .= ' ' . trim($m->textContent);
    }
    $allText = trim($entry->textContent . ' ' . $linkNode->item(0)->getAttribute('title') . ' ' . $href);

    $rating = null;
    if (preg_match('/(\d+(?:\.\d+)?)\s*\/\s*10/u', $metaText . ' ' . $allText, $m)) {
        $rating = (float)$m[1];
    }

    $year = null;
    if (preg_match('/\b(19|20)\d{2}\b/u', $metaText . ' ' . $rawTitle . ' ' . $linkNode->item(0)->getAttribute('title') . ' ' . $href, $m)) {
        $year = $m[0];
    }

    $updateNote = null;
    $nNode = $xpath->query(".//p[contains(@class,'text-muted') and contains(@class,'fsz-12')]", $entry);
    if ($nNode->length > 0) {
        $nt = trim($nNode->item(0)->textContent);
        if ($nt !== '') $updateNote = $nt;
    }

    $detectedType = $forcedType ?: $pathInfo['type'];
    $hasDubbed = (stripos($allText, 'دوبله') !== false || stripos($allText, 'dubbed') !== false);
    $hasSubtitle = (stripos($allText, 'زیرنویس') !== false || stripos($allText, 'subtitle') !== false || stripos($allText, 'hardsub') !== false);

    return [
        // id/slug عمداً URL-safe شده تا در /movie/arc1-... اسلش باعث خراب شدن مسیر نشود.
        'id' => $pathInfo['detail_id'],
        'slug' => $pathInfo['detail_id'],
        'detail_id' => $pathInfo['detail_id'],
        'source_slug' => $pathInfo['source_slug'],
        'source_path' => $pathInfo['source_path'],
        'title' => $title,
        'year' => $year,
        'type' => $detectedType,
        'poster' => $poster,
        'genres' => $genres,
        'rating' => $rating,
        'has_dubbed' => $hasDubbed,
        'has_subtitle' => $hasSubtitle,
        'update_note' => $updateNote,
        'url' => $href,
        'source_url' => $href
    ];
}

function api2_parse_entry_cards($xpath, $context = null, $forcedType = null, $limit = 0) {
    $movies = [];
    $seen = [];
    $query = $context ? ".//article[contains(concat(' ', normalize-space(@class), ' '), ' entry ')]" : "//article[contains(concat(' ', normalize-space(@class), ' '), ' entry ')]";
    $entries = $xpath->query($query, $context);
    foreach ($entries as $entry) {
        $item = api2_parse_entry_card($xpath, $entry, $forcedType);
        if (!$item) continue;
        $key = $item['source_url'] ?: $item['detail_id'];
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $movies[] = $item;
        if ($limit > 0 && count($movies) >= $limit) break;
    }
    return $movies;
}

function api2_local_movie_url_from_card($item) {
    $slug = (string)($item['detail_id'] ?? $item['slug'] ?? $item['id'] ?? '');
    $type = (string)($item['type'] ?? '');
    if ($slug === '') return '#';
    return 'movie.php?arc=1&slug=' . rawurlencode($slug) . ($type !== '' ? '&type=' . rawurlencode($type) : '');
}

function api2_extract_related_posts($xpath, $sourceUrl = '', $currentSlug = '', $limit = 12) {
    $related = [];
    $seen = [];

    // Archive 1 detail pages expose related cards under:
    // <section id="related-posts" class="splide posts-splide ...">
    $sections = $xpath->query("//section[@id='related-posts'] | //*[@id='related-posts']");
    if (!$sections || $sections->length === 0) return [];

    foreach ($sections as $section) {
        $cards = api2_parse_entry_cards($xpath, $section, null, 0);
        foreach ($cards as $item) {
            $detailId = (string)($item['detail_id'] ?? '');
            $sourceSlug = (string)($item['source_slug'] ?? '');

            if ($detailId === '' && $sourceSlug === '') continue;
            if ($currentSlug !== '' && ($detailId === $currentSlug || $sourceSlug === $currentSlug)) continue;

            $key = $detailId ?: $sourceSlug ?: ($item['source_url'] ?? '');
            if ($key === '' || isset($seen[$key])) continue;
            $seen[$key] = true;

            $localUrl = api2_local_movie_url_from_card($item);
            $related[] = [
                'id' => $detailId,
                'slug' => $detailId,
                'source_slug' => $sourceSlug,
                'title' => $item['title'] ?? '',
                'poster' => $item['poster'] ?? '',
                'rating' => $item['rating'] ?? '',
                'year' => $item['year'] ?? '',
                'type' => $item['type'] ?? '',
                'note' => $item['update_note'] ?? '',
                'update_note' => $item['update_note'] ?? '',
                'genres' => $item['genres'] ?? [],
                'has_dubbed' => $item['has_dubbed'] ?? false,
                'has_subtitle' => $item['has_subtitle'] ?? false,
                'url' => $localUrl,
                'bankmovie_url' => $localUrl,
                'source_url' => $item['source_url'] ?? ($item['url'] ?? '')
            ];

            if ($limit > 0 && count($related) >= $limit) break 2;
        }
    }

    return $related;
}


function api2_next_page($xpath, $page) {
    foreach ($xpath->query("//a[contains(@class,'page-numbers') and not(contains(@class,'current'))]") as $n) {
        $href = $n->getAttribute('href');
        if (preg_match('/\/page\/(\d+)\//i', $href, $m) && (int)$m[1] === ((int)$page + 1)) {
            return (int)$m[1];
        }
    }
    return null;
}

// ==================== جزئیات یک فیلم/سریال ====================

function parseDetailPage($html, $sourceUrl) {
    $xpath = api2_xpath_from_html($html);

    $titleNode = $xpath->query("//h1[contains(@class,'entry-title')]");
    if ($titleNode->length == 0) {
        return null; // این صفحه، صفحه‌ی جزئیات معتبر نیست
    }

    // پیدا کردن گرهٔ اصلی (بخش اطلاعات فیلم/سریال) برای محدود کردن جستجوی ژانرها
    $mainNode = $xpath->query("//section[@id='post-intro']")->item(0);
    if (!$mainNode) {
        // اگر به هر دلیلی بخش اصلی پیدا نشد، از کل سند استفاده نکنید، بلکه از یک fallback معقول استفاده کنید
        // مثلاً wrapper یا خود body
        $mainNode = $xpath->query("//div[contains(@class,'wrapper')]")->item(0);
    }
    // اگر باز هم null بود، extractGenres با context null اجرا می‌شود و ممکن است ژانرهای اضافی بیاید،
    // ولی بهتر است حداقل یک context معتبر داشته باشیم.

    $isSeries = isSeriesPage($xpath, $sourceUrl);
    $title = trim($titleNode->item(0)->textContent);

    $year = null;
    if (preg_match('/\b(19|20)\d{2}\b/', $title, $matches)) $year = $matches[0];

    $poster = extractPoster($xpath);
    $backdrop = extractBackdrop($xpath, $html, $sourceUrl, $poster);
    $genres = extractGenres($xpath, $mainNode);  // <-- ارسال context با کوئری نسبی

    $downloads = $isSeries ? extractSeriesDownloads($html) : extractMovieDownloads($xpath, $html);
    // اگر روش اصلی برای فیلم چیزی پیدا نکرد، به‌عنوان fallback روش سریال را هم امتحان کن
    if (empty($downloads)) {
        $alt = extractSeriesDownloads($html);
        if (!empty($alt)) {
            $downloads = $alt;
            $isSeries = true;
        }
    }

    $description = '';
    $descNode = $xpath->query("//div[contains(@class,'entry-excerpt')]//p");
    if ($descNode->length > 0) $description = trim($descNode->item(0)->textContent);

    $detailInfo = extractDetailInfo($xpath, $mainNode);
    $countries = $detailInfo['countries'] ?? [];
    if (empty($countries)) {
        $countryNodes = $xpath->query("//div[contains(@class,'row') and contains(@class,'pt-4')]//a[@rel='tag']");
        foreach ($countryNodes as $c) $countries[] = trim($c->textContent);
    }

    $releaseDate = $detailInfo['release_date'] ?? null;
    $publishedDate = $detailInfo['published_date'] ?? null;

    $actors = extractActors($xpath, $sourceUrl);

    // Related posts from Archive 1 related-posts slider.
    $relatedMovies = api2_extract_related_posts($xpath, $sourceUrl, '', 12);

    $trailer = null;
    $videoNode = $xpath->query("//div[contains(@class,'video-player')]//video");
    if ($videoNode->length > 0) $trailer = api2_abs_url_for_base($videoNode->item(0)->getAttribute('src'), $sourceUrl);

    $satisfaction = null;
    $satNode = $xpath->query("//span[contains(@class,'feedback-satisfaction')]");
    if ($satNode->length > 0) $satisfaction = trim($satNode->item(0)->textContent);

    $imdbRating = null;
    $imdbLink = $xpath->query("//a[contains(@href,'imdb.com/title')]");
    if ($imdbLink->length > 0) {
        $imdbText = trim($imdbLink->item(0)->textContent);
        if (preg_match('/(\d+\.\d+)\/10/', $imdbText, $matches)) {
            $imdbRating = (float)$matches[1];
        }
    }

    // Feature flags must be based on the real download box, not just poster/header badges.
    // Some pages show a dubbed icon but the download box only has subtitles or only a separate audio track.
    $hasDubbed = false;
    $hasDubbedAudio = false;
    $hasSubtitle = false;
    foreach ($downloads as $dl) {
        $dlType = (string)($dl['type'] ?? '');
        $isAudio = !empty($dl['audio_only']) || (($dl['media_type'] ?? '') === 'audio');
        if ($dlType === 'dubbed') {
            if ($isAudio) $hasDubbedAudio = true;
            else $hasDubbed = true;
        }
        if (in_array($dlType, ['subtitle','hardsub'], true) && !$isAudio) {
            $hasSubtitle = true;
        }
    }

    // استخراج slug از روی آدرس صفحه
    $path = trim(parse_url($sourceUrl, PHP_URL_PATH) ?? '', '/');
    $segments = $path !== '' ? explode('/', $path) : [];
    $slug = !empty($segments) ? end($segments) : null;
    if (!empty($relatedMovies) && $slug) {
        $relatedMovies = array_values(array_filter($relatedMovies, function($item) use ($slug) {
            return (($item['source_slug'] ?? '') !== $slug) && (($item['slug'] ?? '') !== $slug);
        }));
    }

    return [
        'id' => $slug,
        'slug' => $slug,
        'source_url' => $sourceUrl,
        'title' => $title,
        'year' => $year,
        'type' => $isSeries ? 'series' : 'movie',
        'poster' => $poster,
        'backdrop' => $backdrop,
        'background' => $backdrop,
        'cover' => $backdrop,
        'description' => $description,
        'genres' => $genres,
        'countries' => $countries,
        'country' => $countries,
        'runtime' => $detailInfo['runtime'] ?? '',
        'duration' => $detailInfo['runtime'] ?? '',
        'release_date' => $releaseDate,
        'published_date' => $publishedDate,
        'status' => $detailInfo['status'] ?? '',
        'age_rate' => $detailInfo['age_rate'] ?? '',
        'rated' => $detailInfo['age_rate'] ?? '',
        'language' => !empty($detailInfo['languages']) ? implode(', ', $detailInfo['languages']) : '',
        'languages' => $detailInfo['languages'] ?? [],
        'network' => $detailInfo['network'] ?? '',
        'next_episode' => $detailInfo['next_episode'] ?? '',
        'next_episode_day' => $detailInfo['next_episode_day'] ?? '',
        'next_episode_duration' => $detailInfo['next_episode_duration'] ?? '',
        'episode_note' => $detailInfo['episode_note'] ?? '',
        'actors' => $actors,
        'actors_text' => implode(', ', array_map(function($a){ return $a['name']; }, $actors)),
        'cast' => $actors,
        'related_movies' => $relatedMovies,
        'related' => $relatedMovies,
        'related_count' => count($relatedMovies),
        'extra_info' => $detailInfo,
        'rating' => [
            'imdb' => $imdbRating,
            'metacritic' => null,
            'rotten_tomatoes' => null,
            'feedback_satisfaction' => $satisfaction
        ],
        'downloads' => $downloads,
        'trailer' => $trailer,
        'has_subtitle' => $hasSubtitle,
        'has_dubbed' => $hasDubbed,
        'has_dubbed_audio' => $hasDubbedAudio
    ];
}

/**
 * ساخت لیست آدرس‌های کاندید برای یک شناسه.
 * شناسه می‌تواند: یک URL کامل، یک عدد، یا یک slug متنی باشد.
 */
function buildCandidateUrls($identifier, $typeHint = null) {
    $identifier = trim((string)$identifier);

    if ($identifier === '') return [];
    if (preg_match('~^https?://~i', $identifier)) {
        $host = strtolower((string)(parse_url($identifier, PHP_URL_HOST) ?: ''));
        $baseHost = strtolower((string)(parse_url(BASE_URL, PHP_URL_HOST) ?: ''));
        $allowedHosts = ['oldtowns.top', 'www.oldtowns.top', $baseHost];
        if (str_starts_with($baseHost, 'www.')) $allowedHosts[] = substr($baseHost, 4);
        elseif ($baseHost !== '') $allowedHosts[] = 'www.' . $baseHost;
        $allowedHosts = array_values(array_unique(array_filter($allowedHosts)));
        if (!in_array($host, $allowedHosts, true)) return [];
        if ($baseHost !== '' && $host !== $baseHost) {
            $parts = @parse_url($identifier);
            if (is_array($parts)) {
                $identifier = rtrim(BASE_URL, '/') . '/' . ltrim((string)($parts['path'] ?? ''), '/');
                if (!empty($parts['query'])) $identifier .= '?' . $parts['query'];
            }
        }
        $resolvedHost = strtolower((string)(parse_url($identifier, PHP_URL_HOST) ?: ''));
        if (function_exists('bm_security_host_resolves_public') && !bm_security_host_resolves_public($resolvedHost)) return [];
        return [$identifier];
    }

    // شناسه‌های جدید URL-safe از لیست‌ها: 81402__killhouse یا series__from
    if (strpos($identifier, '__') !== false) {
        $identifier = str_replace('__', '/', $identifier);
    }

    $identifier = trim($identifier, '/');
    $parts = $identifier !== '' ? array_values(array_filter(explode('/', $identifier), 'strlen')) : [];
    $last = !empty($parts) ? end($parts) : $identifier;
    $urls = [];

    if (!empty($parts) && $parts[0] === 'series') {
        $urls[] = BASE_URL . '/' . implode('/', $parts) . '/';
        $urls[] = BASE_URL . '/series/' . $last . '/';
        $urls[] = BASE_URL . '/' . $last . '/';
        return array_values(array_unique($urls));
    }

    if (count($parts) >= 2 && ctype_digit($parts[0])) {
        // مسیر کامل فیلم با ID عددی؛ این همان چیزی است که قبلاً از دست می‌رفت.
        $urls[] = BASE_URL . '/' . implode('/', $parts) . '/';
        $urls[] = BASE_URL . '/' . $last . '/';
        $urls[] = BASE_URL . '/series/' . $last . '/';
        return array_values(array_unique($urls));
    }

    $seriesUrl = BASE_URL . '/series/' . $identifier . '/';
    $movieUrl  = BASE_URL . '/' . $identifier . '/';

    if ($typeHint === 'series') return [$seriesUrl, $movieUrl];
    if ($typeHint === 'movie') return [$movieUrl, $seriesUrl];
    return [$seriesUrl, $movieUrl];
}

function getMovieDetails($identifier, $typeHint = null) {
    $urls = buildCandidateUrls($identifier, $typeHint);
    $lastError = 'صفحه مورد نظر پیدا نشد';

    foreach ($urls as $url) {
        try {
            $res = getHtml($url, 0);
            if ($res['code'] == 404) {
                continue;
            }
            $result = parseDetailPage($res['html'], $url);
            if ($result !== null) {
                return $result;
            }
        } catch (Exception $e) {
            $lastError = $e->getMessage();
            continue;
        }
    }

    throw new Exception($lastError);
}


// ==================== لیست‌های آپدیت و آرشیو مستقیم ====================

/**
 * Merge Archive 1 cards without duplicates while preserving the order of
 * the first list. This is used to join the short homepage update carousel
 * with the complete first archive page.
 */
function api2_merge_unique_cards($primary, $secondary) {
    $out = [];
    $seen = [];

    foreach ([is_array($primary) ? $primary : [], is_array($secondary) ? $secondary : []] as $list) {
        foreach ($list as $item) {
            if (!is_array($item)) continue;

            $key = trim((string)($item['source_url'] ?? $item['url'] ?? $item['detail_id'] ?? $item['slug'] ?? $item['id'] ?? ''));
            if ($key === '') {
                $key = sha1(json_encode($item, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
            }
            if (isset($seen[$key])) continue;

            $seen[$key] = true;
            $out[] = $item;
        }
    }

    return $out;
}

function getUpdatedList($type = 'movies', $page = 1) {
    $type = in_array($type, ['movie','movies'], true)
        ? 'movie'
        : (in_array($type, ['series','tv','tvSeries'], true) ? 'series' : $type);
    $page = max(1, (int)$page);

    /*
     * Critical pagination fix:
     * The source homepage update carousel currently exposes fewer cards than
     * page 1 of /movies/ or /series/ (for example 16 versus 24). The old code
     * returned only the homepage cards for page 1 and then jumped directly to
     * source page 2, permanently skipping the remaining cards from archive
     * page 1. We now merge the homepage carousel with the complete first
     * archive page and only then continue to page 2.
     */
    if ($page > 1) {
        $result = getArchiveList($type, $page);
        $result['section'] = $type;
        $result['source_mode'] = 'archive_page';
        return $result;
    }

    $sectionMap = [
        'movie' => 'carougsel-posts1',
        'movies' => 'carougsel-posts1',
        'series' => 'carougsel-posts2',
        'dubbed' => 'carougsel-posts9',
        'coming-soon' => 'carougsel-posts8'
    ];
    $sectionId = $sectionMap[$type] ?? 'carougsel-posts1';
    $forcedType = ($sectionId === 'carougsel-posts2')
        ? 'series'
        : (($sectionId === 'carougsel-posts1') ? 'movie' : null);

    $homeMovies = [];
    $archiveMovies = [];
    $archiveHasMore = false;
    $archiveNextPage = null;
    $homeError = null;
    $archiveError = null;

    try {
        $res = getHtml(BASE_URL . '/');
        $xpath = api2_xpath_from_html($res['html']);
        $section = $xpath->query("//section[@id='" . $sectionId . "']")->item(0);

        // IDs on the source theme can change. Fall back to the visible section
        // title so the update feed survives a theme/layout rename.
        if (!$section && $type === 'series') {
            $section = $xpath->query("//section[.//*[contains(normalize-space(.),'سریال‌های به روز شده') or contains(normalize-space(.),'سریال های به روز شده') or contains(normalize-space(.),'سریال‌های بروز شده')]]")->item(0);
        } elseif (!$section && $type === 'movie') {
            $section = $xpath->query("//section[.//*[contains(normalize-space(.),'فیلم‌های به روز شده') or contains(normalize-space(.),'فیلم های به روز شده') or contains(normalize-space(.),'فیلم‌های بروز شده')]]")->item(0);
        }

        $homeMovies = $section ? api2_parse_entry_cards($xpath, $section, $forcedType) : [];
    } catch (Throwable $e) {
        $homeError = $e->getMessage();
    }

    try {
        $archiveResult = getArchiveList($type, 1);
        $archiveMovies = isset($archiveResult['movies']) && is_array($archiveResult['movies'])
            ? $archiveResult['movies']
            : [];
        $archiveHasMore = !empty($archiveResult['has_more']);
        $archiveNextPage = isset($archiveResult['next_page']) ? $archiveResult['next_page'] : null;
    } catch (Throwable $e) {
        $archiveError = $e->getMessage();
    }

    $movies = api2_merge_unique_cards($homeMovies, $archiveMovies);

    // If both source routes failed, keep the original error behaviour.
    if (!$movies && $homeError !== null && $archiveError !== null) {
        throw new Exception('خطا در دریافت لیست آپدیت‌ها: ' . $archiveError);
    }

    // When the archive page was temporarily unavailable, preserve the old
    // continuation behaviour so users can still try page 2.
    if (!$archiveMovies && $homeMovies) {
        $archiveHasMore = true;
        $archiveNextPage = 2;
    }

    return [
        'section' => $type,
        'page' => 1,
        'has_more' => $archiveHasMore,
        'next_page' => $archiveHasMore ? ($archiveNextPage ?: 2) : null,
        'count' => count($movies),
        'movies' => $movies,
        'source_mode' => 'home_plus_archive_page1',
        'home_count' => count($homeMovies),
        'archive_page_count' => count($archiveMovies),
        'recovered_count' => max(0, count($movies) - count($homeMovies))
    ];
}

function getArchiveList($type = 'movie', $page = 1) {
    $type = in_array($type, ['series','tv','tvSeries'], true) ? 'series' : 'movie';
    $base = $type === 'series' ? BASE_URL . '/series/' : BASE_URL . '/movies/';
    $url = $base;
    if ((int)$page > 1) $url = $base . 'page/' . (int)$page . '/';

    $res = getHtml($url);
    if ($res['code'] == 404) throw new Exception('صفحه آرشیو پیدا نشد.');
    $xpath = api2_xpath_from_html($res['html']);
    $movies = api2_parse_entry_cards($xpath, null, $type);
    $nextPage = api2_next_page($xpath, (int)$page);

    return [
        'archive' => $type,
        'page' => (int)$page,
        'has_more' => ($nextPage !== null),
        'next_page' => $nextPage,
        'count' => count($movies),
        'movies' => $movies
    ];
}


function getHomeSectionList($sectionId, $forcedType = null, $page = 1) {
    $res = getHtml(BASE_URL . '/');
    $xpath = api2_xpath_from_html($res['html']);
    $section = $xpath->query("//section[@id='" . $sectionId . "']")->item(0);
    $movies = $section ? api2_parse_entry_cards($xpath, $section, $forcedType) : [];

    return [
        'category' => $sectionId,
        'page' => (int)$page,
        'has_more' => count($movies) > 0,
        'next_page' => count($movies) > 0 ? 2 : null,
        'count' => count($movies),
        'movies' => $movies
    ];
}

function getDubbedMoviesList($page = 1) {
    $page = max(1, (int)$page);
    if ($page === 1) {
        $res = getHtml(BASE_URL . '/');
        $xpath = api2_xpath_from_html($res['html']);

        // Source layout changes occasionally. Detect the Persian-dubbed carousel
        // by its own archive link/title first, then use the current known id.
        // This prevents the previous bug where carougsel-posts7 (Anime) was returned.
        $section = $xpath->query("//section[.//a[contains(@href,'dubbled=1') or contains(@href,'dubbed=1')]]")->item(0);
        if (!$section) {
            $section = $xpath->query("//section[.//p[contains(normalize-space(.),'فیلم‌های دوبله فارسی') or contains(normalize-space(.),'فیلم های دوبله فارسی')]]")->item(0);
        }
        if (!$section) {
            $section = $xpath->query("//section[@id='carougsel-posts9']")->item(0);
        }

        $movies = $section ? api2_parse_entry_cards($xpath, $section, 'movie') : [];
        return [
            'category' => 'dubbed-fa',
            'page' => 1,
            'has_more' => count($movies) > 0,
            'next_page' => count($movies) > 0 ? 2 : null,
            'count' => count($movies),
            'movies' => $movies
        ];
    }

    $url = BASE_URL . '/movies/page/' . $page . '/?dubbled=1';
    $res = getHtml($url);
    if ($res['code'] == 404) throw new Exception("صفحه پیدا نشد.");
    $xpath = api2_xpath_from_html($res['html']);
    $movies = api2_parse_entry_cards($xpath, null, 'movie');
    $nextPage = api2_next_page($xpath, $page);

    return [
        'category' => 'dubbed-fa',
        'page' => $page,
        'has_more' => ($nextPage !== null),
        'next_page' => $nextPage,
        'count' => count($movies),
        'movies' => $movies
    ];
}

function getTop2026MoviesList($page = 1) {
    $page = max(1, (int)$page);
    if ($page === 1) {
        return getHomeSectionList('carougsel-posts3', 'movie', 1);
    }

    $url = BASE_URL . '/category/f2m-top-movies/page/' . $page . '/';
    $res = getHtml($url);
    if ($res['code'] == 404) throw new Exception("صفحه پیدا نشد.");
    $xpath = api2_xpath_from_html($res['html']);
    $movies = api2_parse_entry_cards($xpath, null, 'movie');
    $nextPage = api2_next_page($xpath, $page);

    return [
        'category' => 'top-2026',
        'page' => $page,
        'has_more' => ($nextPage !== null),
        'next_page' => $nextPage,
        'count' => count($movies),
        'movies' => $movies
    ];
}


// ==================== دریافت دسته‌بندی‌های خاص ====================

/**
 * دریافت لیست از یک صفحه دسته‌بندی مستقیم از سایت
 * مثلاً: top-movies, korean, anime, turkish, coming-soon
 */
function getCategoryList($categorySlug, $page = 1) {
    $categoryUrls = [
        'top-movies'      => BASE_URL . '/250tmdb/',
        'top-series'      => BASE_URL . '/250tsdb/',
        'korean'          => BASE_URL . '/category/korean-tv-series/',
        'anime'           => BASE_URL . '/category/anime-series/',
        'turkish'         => BASE_URL . '/category/turkish-tv-series/',
        'coming-soon'     => BASE_URL . '/category/coming-soon/',
        'dubbed-fa'       => BASE_URL . '/movies/?dubbled=1',
        'top-2026'        => BASE_URL . '/category/f2m-top-movies/',
        'updated-movies'  => BASE_URL . '/',
        'updated-series'  => BASE_URL . '/',
        'movies'          => BASE_URL . '/movies/',
        'series'          => BASE_URL . '/series/',
    ];

    if ($categorySlug === 'updated-movies') return getUpdatedList('movie', $page);
    if ($categorySlug === 'updated-series') return getUpdatedList('series', $page);
    if ($categorySlug === 'dubbed-fa') return getDubbedMoviesList($page);
    if ($categorySlug === 'top-2026') return getTop2026MoviesList($page);
    if ($categorySlug === 'movies') return getArchiveList('movie', $page);
    if ($categorySlug === 'series') return getArchiveList('series', $page);

    if (!isset($categoryUrls[$categorySlug])) {
        throw new Exception("دسته‌بندی معتبر نیست. مقادیر مجاز: " . implode(', ', array_keys($categoryUrls)));
    }

    $url = $categoryUrls[$categorySlug];
    if ($page > 1) $url = rtrim($url, '/') . '/page/' . (int)$page . '/';

    $res = getHtml($url);
    if ($res['code'] == 404) throw new Exception("صفحه پیدا نشد.");
    $xpath = api2_xpath_from_html($res['html']);

    $forcedType = null;
    if (in_array($categorySlug, ['korean','anime','turkish','top-series'], true)) $forcedType = 'series';
    if (in_array($categorySlug, ['top-movies','coming-soon','dubbed-fa','top-2026'], true)) $forcedType = 'movie';

    $movies = api2_parse_entry_cards($xpath, null, $forcedType);
    $nextPage = api2_next_page($xpath, (int)$page);

    return [
        'category' => $categorySlug,
        'page' => (int)$page,
        'has_more' => ($nextPage !== null),
        'next_page' => $nextPage,
        'count' => count($movies),
        'movies' => $movies
    ];
}


// ==================== کمک‌کننده‌های جستجوی دقیق‌تر ====================

function api2_normalize_search_text($text) {
    $text = api2_clean_ws($text);
    $text = mb_strtolower($text, 'UTF-8');
    $text = str_replace(['ي','ك','ۀ','ة','أ','إ','ؤ','ئ'], ['ی','ک','ه','ه','ا','ا','و','ی'], $text);
    $text = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $text);
    $text = preg_replace('/\b(دانلود|download|watch|مشاهده|فیلم|سریال|series|movie|بدون|سانسور|زیرنویس|چسبیده|فارسی|دوبله|فصل|قسمت)\b/iu', ' ', $text);
    $text = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $text);
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim($text);
}

function api2_slugify_search_query($query) {
    $query = html_entity_decode((string)$query, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $query = trim($query);
    if ($query === '') return '';
    // remove common Persian wrappers while preserving the English title inside the query
    $query = preg_replace('/\b(دانلود|فیلم|سریال|بدون\s+سانسور|با\s+زیرنویس\s+فارسی\s+چسبیده|زیرنویس\s+فارسی|دوبله\s+فارسی)\b/u', ' ', $query);
    $query = preg_replace('/[^\p{Latin}\p{N}]+/u', '-', $query);
    $query = strtolower(trim($query, '-'));
    $query = preg_replace('/-+/u', '-', $query);
    return trim($query, '-');
}

function api2_search_item_matches($item, $query) {
    $qNorm = api2_normalize_search_text($query);
    if ($qNorm === '') return false;

    $title = (string)($item['title'] ?? '');
    $sourceSlug = (string)($item['source_slug'] ?? '');
    $detailId = (string)($item['detail_id'] ?? ($item['slug'] ?? ''));
    $href = (string)($item['source_url'] ?? ($item['url'] ?? ''));

    $hayNorm = api2_normalize_search_text($title . ' ' . $sourceSlug . ' ' . $detailId . ' ' . $href);
    if ($hayNorm !== '' && (mb_strpos($hayNorm, $qNorm, 0, 'UTF-8') !== false || mb_strpos($qNorm, $hayNorm, 0, 'UTF-8') !== false)) {
        return true;
    }

    $qSlug = api2_slugify_search_query($query);
    if ($qSlug !== '') {
        $haySlug = strtolower($sourceSlug . ' ' . $detailId . ' ' . $href);
        if (strpos($haySlug, $qSlug) !== false) return true;
        if (strpos(str_replace('-', ' ', $haySlug), str_replace('-', ' ', $qSlug)) !== false) return true;
    }

    return false;
}

function api2_detail_result_to_search_card($detail) {
    if (!is_array($detail) || empty($detail['slug'])) return null;

    $rating = $detail['rating'] ?? null;
    $imdb = is_array($rating) ? ($rating['imdb'] ?? null) : $rating;

    return [
        'id' => $detail['slug'],
        'slug' => $detail['slug'],
        'detail_id' => $detail['slug'],
        'source_slug' => $detail['slug'],
        'source_path' => $detail['slug'],
        'title' => $detail['title'] ?? '',
        'year' => $detail['year'] ?? '',
        'type' => $detail['type'] ?? 'movie',
        'poster' => is_array($detail['poster'] ?? null) ? (($detail['poster']['full'] ?? '') ?: ($detail['poster']['medium'] ?? '')) : ($detail['poster'] ?? ''),
        'genres' => $detail['genres'] ?? [],
        'rating' => $imdb,
        'has_dubbed' => $detail['has_dubbed'] ?? false,
        'has_subtitle' => $detail['has_subtitle'] ?? false,
        'update_note' => $detail['episode_note'] ?? '',
        'url' => $detail['source_url'] ?? '',
        'source_url' => $detail['source_url'] ?? ''
    ];
}

function api2_merge_search_cards($primary, $fallback, $limit = 24) {
    $out = [];
    $seen = [];
    foreach (array_merge($primary ?: [], $fallback ?: []) as $item) {
        if (!is_array($item)) continue;
        $key = (string)($item['source_url'] ?? '') ?: (string)($item['detail_id'] ?? ($item['slug'] ?? ''));
        if ($key === '') $key = md5(json_encode($item));
        if (isset($seen[$key])) continue;
        $seen[$key] = true;
        $out[] = $item;
        if ($limit > 0 && count($out) >= $limit) break;
    }
    return $out;
}

function api2_fallback_search_updated_and_direct($query, $type = 'both', $page = 1) {
    $query = trim((string)$query);
    $page = max(1, (int)$page);
    if ($query === '' || $page > 2) return [];

    $wantedTypes = [];
    if (in_array($type, ['movie','movies'], true)) $wantedTypes = ['movie'];
    elseif (in_array($type, ['series','tv','tvSeries'], true)) $wantedTypes = ['series'];
    else $wantedTypes = ['movie','series'];

    $fallback = [];
    $seen = [];

    // 1) Search in the same updated sections the user can visibly see on the homepage.
    // This fixes cases where an item is in updated list but the source site's ?s= search does not return it.
    foreach ($wantedTypes as $t) {
        try {
            $list = getUpdatedList($t, 1);
            foreach (($list['movies'] ?? []) as $item) {
                if (!api2_search_item_matches($item, $query)) continue;
                $key = (string)($item['source_url'] ?? '') ?: (string)($item['detail_id'] ?? '');
                if ($key !== '' && !isset($seen[$key])) {
                    $seen[$key] = true;
                    $fallback[] = $item;
                }
            }
        } catch (Throwable $e) {}
    }

    // 2) Direct slug probe, e.g. "Seeking Persephone" => /series/seeking-persephone/
    // This is very useful for titles that exist but are not indexed by the source search page.
    $slug = api2_slugify_search_query($query);
    if ($slug !== '') {
        $candidateIdentifiers = [];
        foreach ($wantedTypes as $t) {
            if ($t === 'series') {
                $candidateIdentifiers[] = 'series/' . $slug;
                $candidateIdentifiers[] = 'series__' . $slug;
            } else {
                $candidateIdentifiers[] = $slug;
            }
        }

        foreach (array_values(array_unique($candidateIdentifiers)) as $identifier) {
            try {
                $detail = getMovieDetails($identifier, in_array('series', $wantedTypes, true) && count($wantedTypes) === 1 ? 'series' : (in_array('movie', $wantedTypes, true) && count($wantedTypes) === 1 ? 'movie' : null));
                $card = api2_detail_result_to_search_card($detail);
                if ($card && api2_search_item_matches($card, $query)) {
                    $key = (string)($card['source_url'] ?? '') ?: (string)($card['detail_id'] ?? '');
                    if ($key !== '' && !isset($seen[$key])) {
                        $seen[$key] = true;
                        $fallback[] = $card;
                    }
                }
            } catch (Throwable $e) {}
        }
    }

    return $fallback;
}



// ==================== گزینه‌های واقعی جستجو و ژانرهای آرشیو ۱ ====================

if (!function_exists('api2_taxonomy_key')) {
function api2_taxonomy_key($value) {
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $value = str_replace(array("\u{200c}","\u{200f}","\u{00a0}",'ي','ك','ۀ','ة'), array(' ',' ',' ','ی','ک','ه','ه'), $value);
    $value = preg_replace('/\s+/u', ' ', trim($value));
    return mb_strtolower((string)$value, 'UTF-8');
}
}

if (!function_exists('api2_search_options_fallback')) {
function api2_search_options_fallback() {
    return array(
        'genres' => array(
        array('id' => 49159, 'label' => 'کمدی'),
        array('id' => 49160, 'label' => 'درام'),
        array('id' => 49161, 'label' => 'معمایی'),
        array('id' => 49162, 'label' => 'علمی تخیلی'),
        array('id' => 49165, 'label' => 'هیجان انگیز'),
        array('id' => 49166, 'label' => 'اکشن'),
        array('id' => 49167, 'label' => 'عاشقانه'),
        array('id' => 49170, 'label' => 'ماجراجویی'),
        array('id' => 49173, 'label' => 'انیمیشن'),
        array('id' => 49174, 'label' => 'ترسناک'),
        array('id' => 49176, 'label' => 'جنگی'),
        array('id' => 49179, 'label' => 'جنایی'),
        array('id' => 49181, 'label' => 'تاریخی'),
        array('id' => 49182, 'label' => 'فانتزی'),
        array('id' => 49183, 'label' => 'ورزشی'),
        array('id' => 49190, 'label' => 'بیوگرافی'),
        array('id' => 49199, 'label' => 'خانوادگی'),
        array('id' => 49215, 'label' => 'وسترن'),
        array('id' => 49237, 'label' => 'موزیکال'),
        array('id' => 49238, 'label' => 'کوتاه'),
        array('id' => 49240, 'label' => 'تاک شو'),
        array('id' => 49243, 'label' => 'موزیک'),
        array('id' => 49336, 'label' => 'فیلم-نوآر'),
        array('id' => 49342, 'label' => 'مستند'),
        array('id' => 49343, 'label' => 'برنامه تلویزیونی'),
        array('id' => 49455, 'label' => 'نامشخص'),
        array('id' => 49456, 'label' => 'مسابقه ها'),
        array('id' => 49482, 'label' => 'ملودرام'),
        array('id' => 220319, 'label' => 'science-fiction'),
        array('id' => 220320, 'label' => 'انیمه'),
        array('id' => 220441, 'label' => 'فراطبیعی'),
        array('id' => 220513, 'label' => 'پزشکی'),
        array('id' => 220525, 'label' => 'جاسوسی'),
        array('id' => 220881, 'label' => 'حقوقی'),
        array('id' => 220947, 'label' => 'طبیعت'),
        array('id' => 221019, 'label' => 'کودک و نوجوان'),
        array('id' => 221596, 'label' => 'sports'),
        array('id' => 223786, 'label' => 'سفر'),
        array('id' => 224625, 'label' => 'diy'),
        array('id' => 224666, 'label' => 'غذا'),
        array('id' => 224680, 'label' => 'adult'),
    ),
        'countries' => array(
        array('id' => 74922, 'label' => 'India'),
        array('id' => 74923, 'label' => 'United Kingdom'),
        array('id' => 74924, 'label' => 'United States'),
        array('id' => 74925, 'label' => 'Turkey'),
        array('id' => 74926, 'label' => 'France'),
        array('id' => 74927, 'label' => 'Belgium'),
        array('id' => 74928, 'label' => 'Japan'),
        array('id' => 74929, 'label' => 'Canada'),
        array('id' => 74930, 'label' => 'Argentina'),
        array('id' => 74931, 'label' => 'Spain'),
        array('id' => 74932, 'label' => 'Chile'),
        array('id' => 74933, 'label' => 'Germany'),
        array('id' => 74934, 'label' => 'Hungary'),
        array('id' => 74935, 'label' => 'China'),
        array('id' => 74936, 'label' => 'Norway'),
        array('id' => 74937, 'label' => 'Lithuania'),
        array('id' => 74938, 'label' => 'South Korea'),
        array('id' => 74939, 'label' => 'Finland'),
        array('id' => 74940, 'label' => 'Netherlands'),
        array('id' => 74941, 'label' => 'Sweden'),
        array('id' => 74942, 'label' => 'Poland'),
        array('id' => 74943, 'label' => 'Denmark'),
        array('id' => 74944, 'label' => 'Mongolia'),
        array('id' => 74945, 'label' => 'Kazakhstan'),
        array('id' => 74946, 'label' => 'Bulgaria'),
        array('id' => 74947, 'label' => 'Australia'),
        array('id' => 74948, 'label' => 'Ireland'),
        array('id' => 74949, 'label' => 'New Zealand'),
        array('id' => 74950, 'label' => 'Russia'),
        array('id' => 74951, 'label' => 'Italy'),
        array('id' => 74952, 'label' => 'Croatia'),
        array('id' => 74953, 'label' => 'Indonesia'),
        array('id' => 74954, 'label' => 'Switzerland'),
        array('id' => 74955, 'label' => 'Tunisia'),
        array('id' => 74956, 'label' => 'Singapore'),
        array('id' => 74957, 'label' => 'Hong Kong'),
        array('id' => 74958, 'label' => 'Taiwan'),
        array('id' => 74959, 'label' => 'Iran'),
        array('id' => 74960, 'label' => 'Malaysia'),
        array('id' => 74961, 'label' => 'Colombia'),
        array('id' => 74962, 'label' => 'Egypt'),
        array('id' => 74963, 'label' => 'Malta'),
        array('id' => 74964, 'label' => 'Nigeria'),
        array('id' => 74965, 'label' => 'Estonia'),
        array('id' => 74966, 'label' => 'Slovakia'),
        array('id' => 74967, 'label' => 'Brazil'),
        array('id' => 74968, 'label' => 'Mexico'),
        array('id' => 74969, 'label' => 'Korea'),
        array('id' => 74970, 'label' => 'Thailand'),
        array('id' => 74971, 'label' => 'Serbia'),
        array('id' => 74972, 'label' => 'Luxembourg'),
        array('id' => 74973, 'label' => 'Cuba'),
        array('id' => 74974, 'label' => 'Yugoslavia'),
        array('id' => 74975, 'label' => 'Czech Republic'),
        array('id' => 74976, 'label' => 'Ukraine'),
        array('id' => 74977, 'label' => 'Romania'),
        array('id' => 74978, 'label' => 'Georgia'),
        array('id' => 74979, 'label' => 'Greece'),
        array('id' => 74980, 'label' => 'Iceland'),
        array('id' => 74981, 'label' => 'Haiti'),
        array('id' => 74982, 'label' => 'Austria'),
        array('id' => 74983, 'label' => 'Soviet Union'),
        array('id' => 74984, 'label' => 'Morocco'),
        array('id' => 74985, 'label' => 'Slovenia'),
        array('id' => 74986, 'label' => 'Pakistan'),
        array('id' => 74987, 'label' => 'Zambia'),
        array('id' => 74988, 'label' => 'West Germany'),
        array('id' => 74989, 'label' => 'United Arab Emirates'),
        array('id' => 74990, 'label' => 'Jordan'),
        array('id' => 74991, 'label' => 'Gambia'),
        array('id' => 74992, 'label' => 'Bangladesh'),
        array('id' => 74993, 'label' => 'Dominican Republic'),
        array('id' => 74994, 'label' => 'Portugal'),
        array('id' => 74995, 'label' => 'South Africa'),
        array('id' => 74996, 'label' => 'Bosnia and Herzegovina'),
        array('id' => 74997, 'label' => 'North Macedonia'),
        array('id' => 74998, 'label' => 'Qatar'),
        array('id' => 74999, 'label' => 'Bhutan'),
        array('id' => 75000, 'label' => 'Vietnam'),
        array('id' => 75001, 'label' => 'Philippines'),
        array('id' => 75002, 'label' => 'Saudi Arabia'),
        array('id' => 75003, 'label' => 'Uruguay'),
        array('id' => 75004, 'label' => 'Latvia'),
        array('id' => 75005, 'label' => 'Kenya'),
        array('id' => 75006, 'label' => 'Algeria'),
        array('id' => 75007, 'label' => 'Cyprus'),
        array('id' => 75008, 'label' => 'Belarus'),
        array('id' => 75009, 'label' => 'Kosovo'),
        array('id' => 75010, 'label' => 'Federal Republic of Yugoslavia'),
        array('id' => 75011, 'label' => 'Saint Kitts and Nevis'),
        array('id' => 75012, 'label' => 'Peru'),
        array('id' => 75013, 'label' => 'Cambodia'),
        array('id' => 75014, 'label' => 'Bolivia'),
        array('id' => 75015, 'label' => 'Panama'),
        array('id' => 97951, 'label' => 'Israel'),
        array('id' => 97952, 'label' => 'Libya'),
        array('id' => 97953, 'label' => 'North Korea'),
        array('id' => 97954, 'label' => 'Côte d\'Ivoire'),
        array('id' => 97955, 'label' => 'Senegal'),
        array('id' => 97956, 'label' => 'Bahamas'),
        array('id' => 97957, 'label' => 'Puerto Rico'),
        array('id' => 97958, 'label' => 'Paraguay'),
        array('id' => 97959, 'label' => 'Occupied Palestinian Territory'),
        array('id' => 97960, 'label' => 'Guadeloupe'),
        array('id' => 98947, 'label' => 'Monaco'),
        array('id' => 200445, 'label' => 'Moldova'),
        array('id' => 200474, 'label' => 'Benin'),
        array('id' => 200478, 'label' => 'Mali'),
        array('id' => 203181, 'label' => 'Lebanon'),
        array('id' => 203845, 'label' => 'Madagascar'),
        array('id' => 206308, 'label' => 'Syria'),
        array('id' => 214442, 'label' => 'Costa Rica'),
        array('id' => 215645, 'label' => 'Nepal'),
        array('id' => 215646, 'label' => 'Sri Lanka'),
        array('id' => 215724, 'label' => 'Saint Helena'),
        array('id' => 216362, 'label' => 'Ecuador'),
        array('id' => 217249, 'label' => 'Namibia'),
        array('id' => 222408, 'label' => 'Macao'),
        array('id' => 223636, 'label' => 'French Polynesia'),
        array('id' => 228125, 'label' => 'Venezuela'),
        array('id' => 235644, 'label' => 'Czechoslovakia'),
        array('id' => 235771, 'label' => 'Palestine'),
        array('id' => 236597, 'label' => 'Liechtenstein'),
        array('id' => 237147, 'label' => 'Sudan'),
        array('id' => 243726, 'label' => 'UK'),
    ),
        'movie_genres' => array(
        array('label' => 'اکشن', 'id' => 49166, 'slug' => 'action', 'path' => '/genres/action/', 'count' => 2419, 'type' => 'movie'),
        array('label' => 'انیمه', 'id' => 220320, 'slug' => 'anime', 'path' => '/genres/anime/', 'count' => 11, 'type' => 'movie'),
        array('label' => 'انیمیشن', 'id' => 49173, 'slug' => 'animation', 'path' => '/genres/animation/', 'count' => 566, 'type' => 'movie'),
        array('label' => 'برنامه تلویزیونی', 'id' => 49343, 'slug' => 'reality-tv', 'path' => '/genres/reality-tv/', 'count' => 6, 'type' => 'movie'),
        array('label' => 'بیوگرافی', 'id' => 49190, 'slug' => 'biography', 'path' => '/genres/biography/', 'count' => 548, 'type' => 'movie'),
        array('label' => 'تاریخی', 'id' => 49181, 'slug' => 'history', 'path' => '/genres/history/', 'count' => 459, 'type' => 'movie'),
        array('label' => 'تاک شو', 'id' => 49240, 'slug' => 'talk-show', 'path' => '/genres/talk-show/', 'count' => 2, 'type' => 'movie'),
        array('label' => 'ترسناک', 'id' => 49174, 'slug' => 'horror', 'path' => '/genres/horror/', 'count' => 1241, 'type' => 'movie'),
        array('label' => 'جنایی', 'id' => 49179, 'slug' => 'crime', 'path' => '/genres/crime/', 'count' => 1590, 'type' => 'movie'),
        array('label' => 'جنگی', 'id' => 49176, 'slug' => 'war', 'path' => '/genres/war/', 'count' => 328, 'type' => 'movie'),
        array('label' => 'خانوادگی', 'id' => 49199, 'slug' => 'family', 'path' => '/genres/family/', 'count' => 628, 'type' => 'movie'),
        array('label' => 'درام', 'id' => 49160, 'slug' => 'drama', 'path' => '/genres/drama/', 'count' => 4789, 'type' => 'movie'),
        array('label' => 'عاشقانه', 'id' => 49167, 'slug' => 'romance', 'path' => '/genres/romance/', 'count' => 1229, 'type' => 'movie'),
        array('label' => 'علمی تخیلی', 'id' => 49162, 'slug' => 'sci-fi', 'path' => '/genres/sci-fi/', 'count' => 835, 'type' => 'movie'),
        array('label' => 'فانتزی', 'id' => 49182, 'slug' => 'fantasy', 'path' => '/genres/fantasy/', 'count' => 871, 'type' => 'movie'),
        array('label' => 'فراطبیعی', 'id' => 220441, 'slug' => 'supernatural', 'path' => '/genres/supernatural/', 'count' => 1, 'type' => 'movie'),
        array('label' => 'فیلم-نوآر', 'id' => 49336, 'slug' => 'film-noir', 'path' => '/genres/film-noir/', 'count' => 46, 'type' => 'movie'),
        array('label' => 'کمدی', 'id' => 49159, 'slug' => 'comedy', 'path' => '/genres/comedy/', 'count' => 2067, 'type' => 'movie'),
        array('label' => 'کوتاه', 'id' => 49238, 'slug' => 'short', 'path' => '/genres/short/', 'count' => 45, 'type' => 'movie'),
        array('label' => 'ماجراجویی', 'id' => 49170, 'slug' => 'adventure', 'path' => '/genres/adventure/', 'count' => 1452, 'type' => 'movie'),
        array('label' => 'مستند', 'id' => 49342, 'slug' => 'documentary', 'path' => '/genres/documentary/', 'count' => 111, 'type' => 'movie'),
        array('label' => 'معمایی', 'id' => 49161, 'slug' => 'mystery', 'path' => '/genres/mystery/', 'count' => 1163, 'type' => 'movie'),
        array('label' => 'ملودرام', 'id' => 49482, 'slug' => '%d9%90drama', 'path' => '/genres/%d9%90drama/', 'count' => 60, 'type' => 'movie'),
        array('label' => 'موزیک', 'id' => 49243, 'slug' => 'music', 'path' => '/genres/music/', 'count' => 201, 'type' => 'movie'),
        array('label' => 'موزیکال', 'id' => 49237, 'slug' => 'musical', 'path' => '/genres/musical/', 'count' => 141, 'type' => 'movie'),
        array('label' => 'نامشخص', 'id' => 49455, 'slug' => 'n-a', 'path' => '/genres/n-a/', 'count' => 25, 'type' => 'movie'),
        array('label' => 'هیجان انگیز', 'id' => 49165, 'slug' => 'thriller', 'path' => '/genres/thriller/', 'count' => 2824, 'type' => 'movie'),
        array('label' => 'ورزشی', 'id' => 49183, 'slug' => 'sport', 'path' => '/genres/sport/', 'count' => 195, 'type' => 'movie'),
        array('label' => 'وسترن', 'id' => 49215, 'slug' => 'western', 'path' => '/genres/western/', 'count' => 199, 'type' => 'movie'),
    ),
        'series_genres' => array(
        array('label' => 'adult', 'id' => 224680, 'slug' => 'adult', 'path' => '/genres/adult/', 'count' => 2, 'type' => 'series'),
        array('label' => 'diy', 'id' => 224625, 'slug' => 'diy', 'path' => '/genres/diy/', 'count' => 1, 'type' => 'series'),
        array('label' => 'science-fiction', 'id' => 220319, 'slug' => 'science-fiction', 'path' => '/genres/science-fiction/', 'count' => 185, 'type' => 'series'),
        array('label' => 'sports', 'id' => 221596, 'slug' => 'sports', 'path' => '/genres/sports/', 'count' => 19, 'type' => 'series'),
        array('label' => 'اکشن', 'id' => 49166, 'slug' => 'action', 'path' => '/genres/action/', 'count' => 467, 'type' => 'series'),
        array('label' => 'انیمه', 'id' => 220320, 'slug' => 'anime', 'path' => '/genres/anime/', 'count' => 92, 'type' => 'series'),
        array('label' => 'انیمیشن', 'id' => 49173, 'slug' => 'animation', 'path' => '/genres/animation/', 'count' => 216, 'type' => 'series'),
        array('label' => 'برنامه تلویزیونی', 'id' => 49343, 'slug' => 'reality-tv', 'path' => '/genres/reality-tv/', 'count' => 9, 'type' => 'series'),
        array('label' => 'بیوگرافی', 'id' => 49190, 'slug' => 'biography', 'path' => '/genres/biography/', 'count' => 53, 'type' => 'series'),
        array('label' => 'پزشکی', 'id' => 220513, 'slug' => 'medical', 'path' => '/genres/medical/', 'count' => 21, 'type' => 'series'),
        array('label' => 'تاریخی', 'id' => 49181, 'slug' => 'history', 'path' => '/genres/history/', 'count' => 151, 'type' => 'series'),
        array('label' => 'تاک شو', 'id' => 49240, 'slug' => 'talk-show', 'path' => '/genres/talk-show/', 'count' => 1, 'type' => 'series'),
        array('label' => 'ترسناک', 'id' => 49174, 'slug' => 'horror', 'path' => '/genres/horror/', 'count' => 113, 'type' => 'series'),
        array('label' => 'جاسوسی', 'id' => 220525, 'slug' => 'espionage', 'path' => '/genres/espionage/', 'count' => 33, 'type' => 'series'),
        array('label' => 'جنایی', 'id' => 49179, 'slug' => 'crime', 'path' => '/genres/crime/', 'count' => 437, 'type' => 'series'),
        array('label' => 'جنگی', 'id' => 49176, 'slug' => 'war', 'path' => '/genres/war/', 'count' => 34, 'type' => 'series'),
        array('label' => 'حقوقی', 'id' => 220881, 'slug' => 'legal', 'path' => '/genres/legal/', 'count' => 22, 'type' => 'series'),
        array('label' => 'خانوادگی', 'id' => 49199, 'slug' => 'family', 'path' => '/genres/family/', 'count' => 58, 'type' => 'series'),
        array('label' => 'درام', 'id' => 49160, 'slug' => 'drama', 'path' => '/genres/drama/', 'count' => 1269, 'type' => 'series'),
        array('label' => 'سفر', 'id' => 223786, 'slug' => 'travel', 'path' => '/genres/travel/', 'count' => 3, 'type' => 'series'),
        array('label' => 'طبیعت', 'id' => 220947, 'slug' => 'nature', 'path' => '/genres/nature/', 'count' => 5, 'type' => 'series'),
        array('label' => 'عاشقانه', 'id' => 49167, 'slug' => 'romance', 'path' => '/genres/romance/', 'count' => 362, 'type' => 'series'),
        array('label' => 'علمی تخیلی', 'id' => 49162, 'slug' => 'sci-fi', 'path' => '/genres/sci-fi/', 'count' => 215, 'type' => 'series'),
        array('label' => 'غذا', 'id' => 224666, 'slug' => 'food', 'path' => '/genres/food/', 'count' => 4, 'type' => 'series'),
        array('label' => 'فانتزی', 'id' => 49182, 'slug' => 'fantasy', 'path' => '/genres/fantasy/', 'count' => 276, 'type' => 'series'),
        array('label' => 'فراطبیعی', 'id' => 220441, 'slug' => 'supernatural', 'path' => '/genres/supernatural/', 'count' => 62, 'type' => 'series'),
        array('label' => 'کمدی', 'id' => 49159, 'slug' => 'comedy', 'path' => '/genres/comedy/', 'count' => 414, 'type' => 'series'),
        array('label' => 'کوتاه', 'id' => 49238, 'slug' => 'short', 'path' => '/genres/short/', 'count' => 9, 'type' => 'series'),
        array('label' => 'کودک و نوجوان', 'id' => 221019, 'slug' => 'children', 'path' => '/genres/children/', 'count' => 5, 'type' => 'series'),
        array('label' => 'ماجراجویی', 'id' => 49170, 'slug' => 'adventure', 'path' => '/genres/adventure/', 'count' => 294, 'type' => 'series'),
        array('label' => 'مسابقه ها', 'id' => 49456, 'slug' => 'game-show', 'path' => '/genres/game-show/', 'count' => 3, 'type' => 'series'),
        array('label' => 'مستند', 'id' => 49342, 'slug' => 'documentary', 'path' => '/genres/documentary/', 'count' => 17, 'type' => 'series'),
        array('label' => 'معمایی', 'id' => 49161, 'slug' => 'mystery', 'path' => '/genres/mystery/', 'count' => 319, 'type' => 'series'),
        array('label' => 'ملودرام', 'id' => 49482, 'slug' => '%d9%90drama', 'path' => '/genres/%d9%90drama/', 'count' => 10, 'type' => 'series'),
        array('label' => 'موزیک', 'id' => 49243, 'slug' => 'music', 'path' => '/genres/music/', 'count' => 13, 'type' => 'series'),
        array('label' => 'موزیکال', 'id' => 49237, 'slug' => 'musical', 'path' => '/genres/musical/', 'count' => 3, 'type' => 'series'),
        array('label' => 'نامشخص', 'id' => 49455, 'slug' => 'n-a', 'path' => '/genres/n-a/', 'count' => 1, 'type' => 'series'),
        array('label' => 'هیجان انگیز', 'id' => 49165, 'slug' => 'thriller', 'path' => '/genres/thriller/', 'count' => 513, 'type' => 'series'),
        array('label' => 'ورزشی', 'id' => 49183, 'slug' => 'sport', 'path' => '/genres/sport/', 'count' => 18, 'type' => 'series'),
        array('label' => 'وسترن', 'id' => 49215, 'slug' => 'western', 'path' => '/genres/western/', 'count' => 25, 'type' => 'series'),
    ),
        'types' => array(
            array('value'=>'both','label'=>'فیلم/سریال'),
            array('value'=>'movie','label'=>'فیلم'),
            array('value'=>'series','label'=>'سریال'),
        ),
        'sorts' => array(
            array('value'=>'newest','label'=>'جدیدترین'),
            array('value'=>'modified','label'=>'بروزترین'),
            array('value'=>'popular','label'=>'محبوب‌ترین'),
            array('value'=>'imdb_rate','label'=>'امتیاز IMDb'),
            array('value'=>'release','label'=>'سال انتشار'),
        ),
        'ratings' => array(
            array('value'=>9,'label'=>'بالای ۹'),
            array('value'=>8,'label'=>'بالای ۸'),
            array('value'=>7,'label'=>'بالای ۷'),
            array('value'=>6,'label'=>'بالای ۶'),
            array('value'=>5,'label'=>'بالای ۵'),
            array('value'=>4,'label'=>'کمتر از ۵'),
        ),
        'counts_source' => 'fallback_snapshot',
        'source_url' => BASE_URL . '/?s=',
    );
}
}

if (!function_exists('api2_parse_search_options_html')) {
function api2_parse_search_options_html($html) {
    $xpath = api2_xpath_from_html((string)$html);
    $out = array(
        'genres'=>array(), 'countries'=>array(), 'movie_genres'=>array(), 'series_genres'=>array(),
        'types'=>array(), 'sorts'=>array(), 'ratings'=>array(),
        'counts_source'=>'live_cached', 'source_url'=>BASE_URL . '/?s='
    );

    $selectMap = array(
        'genre[]'=>'genres', 'madeby[]'=>'countries', 'type'=>'types',
        'sortby'=>'sorts', 'imdbrate'=>'ratings'
    );
    foreach ($selectMap as $name => $target) {
        $nodes = $xpath->query("//select[@name='" . $name . "']/option");
        foreach ($nodes as $node) {
            if (!($node instanceof DOMElement)) continue;
            $value = trim((string)$node->getAttribute('value'));
            $label = api2_clean_ws((string)$node->textContent);
            if ($label === '' || $value === '' || $value === '0') continue;
            if ($target === 'genres' || $target === 'countries') {
                if (!ctype_digit($value)) continue;
                $out[$target][] = array('id'=>(int)$value, 'label'=>$label);
            } elseif ($target === 'ratings') {
                if (!is_numeric($value)) continue;
                $out[$target][] = array('value'=>(int)$value, 'label'=>$label);
            } else {
                $out[$target][] = array('value'=>$value, 'label'=>$label);
            }
        }
    }

    $idByLabel = array();
    foreach ($out['genres'] as $row) $idByLabel[api2_taxonomy_key($row['label'])] = (int)$row['id'];

    foreach (array('movie'=>'genres-movies','series'=>'genres-series') as $type => $containerId) {
        $rows = array();
        $nodes = $xpath->query("//*[@id='" . $containerId . "']//li[.//a[@href]]");
        foreach ($nodes as $li) {
            $anchor = $xpath->query(".//a[@href]", $li)->item(0);
            if (!($anchor instanceof DOMElement)) continue;
            $label = api2_clean_ws((string)$anchor->textContent);
            $href = api2_abs_url((string)$anchor->getAttribute('href'));
            if ($label === '' || $href === '') continue;
            $count = null;
            $plain = str_replace(',', '', api2_clean_ws((string)$li->textContent));
            if (preg_match('/\((\d+)\)/u', $plain, $m)) $count = (int)$m[1];
            $path = (string)(parse_url($href, PHP_URL_PATH) ?: '');
            $slug = '';
            if (preg_match('~/genres/([^/]+)/~i', $path, $m)) $slug = rawurldecode($m[1]);
            $key = api2_taxonomy_key($label);
            $rows[] = array(
                'label'=>$label, 'id'=>(int)($idByLabel[$key] ?? 0), 'slug'=>$slug,
                'path'=>$path, 'count'=>$count, 'type'=>$type
            );
        }
        $out[$type . '_genres'] = $rows;
    }
    return $out;
}
}

if (!function_exists('api2_search_options')) {
function api2_search_options() {
    $fallback = api2_search_options_fallback();
    $cacheFile = function_exists('bm_security_private_path')
        ? bm_security_private_path('api2_search_options_v1.json')
        : rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'api2_search_options_v1.json';
    $ttl = 21600;
    if (is_file($cacheFile) && (time() - (int)@filemtime($cacheFile)) <= $ttl) {
        $cached = json_decode((string)@file_get_contents($cacheFile), true);
        if (is_array($cached) && !empty($cached['genres'])) return $cached;
    }

    try {
        $res = getHtml(BASE_URL . '/?s=');
        $live = api2_parse_search_options_html($res['html'] ?? '');
        foreach (array('genres','countries','movie_genres','series_genres','types','sorts','ratings') as $key) {
            if (empty($live[$key])) $live[$key] = $fallback[$key];
        }
        $dir = dirname($cacheFile);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        if (is_dir($dir) && is_writable($dir)) {
            $tmp = $cacheFile . '.' . getmypid() . '.tmp';
            $json = json_encode($live, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (is_string($json) && @file_put_contents($tmp, $json, LOCK_EX) !== false) {
                @chmod($tmp, 0600);
                if (!@rename($tmp, $cacheFile)) @unlink($tmp);
            }
        }
        return $live;
    } catch (Throwable $e) {
        return $fallback;
    }
}
}

if (!function_exists('api2_resolve_search_option_id')) {
function api2_resolve_search_option_id($kind, $value) {
    if (is_numeric($value) && (int)$value > 0) return (int)$value;
    $needle = api2_taxonomy_key($value);
    if ($needle === '') return 0;
    $options = api2_search_options();
    $rows = $kind === 'country' ? ($options['countries'] ?? array()) : ($options['genres'] ?? array());
    foreach ($rows as $row) {
        if (api2_taxonomy_key($row['label'] ?? '') === $needle) return (int)($row['id'] ?? 0);
    }
    return 0;
}
}


// ==================== جستجوی پیشرفته ====================

function advancedSearch($params) {
    $query = isset($params['s']) ? trim((string)$params['s']) : '';
    $type = strtolower(trim((string)($params['type'] ?? 'both')));
    if (!in_array($type, array('both','movie','movies','series','tv','tvseries'), true)) $type = 'both';

    $genreInput = !empty($params['genre_id']) ? $params['genre_id'] : ($params['genre'] ?? 0);
    $countryInput = !empty($params['country_id']) ? $params['country_id'] : ($params['country'] ?? 0);
    $genre = api2_resolve_search_option_id('genre', $genreInput);
    $country = api2_resolve_search_option_id('country', $countryInput);

    $sortRaw = strtolower(trim((string)($params['sortby'] ?? 'newest')));
    $sortAliases = array(
        'year_desc'=>'release', 'year_asc'=>'release', 'rating_desc'=>'imdb_rate',
        'imdb'=>'imdb_rate', 'rating'=>'imdb_rate', 'updated'=>'modified',
        'title_asc'=>'newest'
    );
    $sortby = $sortAliases[$sortRaw] ?? $sortRaw;
    if (!in_array($sortby, array('newest','modified','popular','imdb_rate','release'), true)) $sortby = 'newest';

    $imdbrate = is_numeric($params['imdbrate'] ?? null) ? (int)$params['imdbrate'] : 0;
    $currentYear = (int)date('Y');
    $min_year = is_numeric($params['min_year'] ?? null) ? (int)$params['min_year'] : 1800;
    $max_year = is_numeric($params['max_year'] ?? null) ? (int)$params['max_year'] : $currentYear;
    $min_year = max(1800, min($currentYear, $min_year));
    $max_year = max($min_year, min($currentYear, $max_year));
    $page = max(1, (int)($params['page'] ?? 1));
    $dubbed = !empty($params['dubbed']) ? 1 : 0;
    $subtitle = !empty($params['subtitle']) ? 1 : 0;
    $suggest = !empty($params['suggest']) ? 1 : 0;

    // وقتی فقط لیست خام فیلم/سریال خواسته شده، مستقیم از آرشیو همان بخش بخوان.
    $hasRealFilter = ($query !== '' || $genre > 0 || $country > 0 || $imdbrate > 0 || $dubbed || $subtitle || $suggest || $min_year > 1800 || $max_year < $currentYear);
    if (!$hasRealFilter && in_array($type, array('movie','movies'), true)) {
        return getArchiveList('movie', $page)['movies'];
    }
    if (!$hasRealFilter && in_array($type, array('series','tv','tvseries'), true)) {
        return getArchiveList('series', $page)['movies'];
    }

    $sourceType = in_array($type, array('movie','movies'), true) ? 'movie'
        : (in_array($type, array('series','tv','tvseries'), true) ? 'series' : 'both');

    $queryArgs = array(
        's' => $query,
        'type' => $sourceType,
        'sortby' => $sortby,
        'imdbrate' => $imdbrate,
        'min_year' => $min_year,
        'max_year' => $max_year,
        'paged' => $page,
    );
    if ($genre > 0) $queryArgs['genre'] = array($genre);
    if ($country > 0) $queryArgs['madeby'] = array($country);
    if ($dubbed) $queryArgs['dubbed'] = 1;
    if ($subtitle) $queryArgs['subtitle'] = 1;
    if ($suggest) $queryArgs['suggest'] = 1;

    $searchUrl = BASE_URL . '/?' . http_build_query($queryArgs, '', '&', PHP_QUERY_RFC3986);
    // منبع آرایه‌ها را با [] می‌خواند؛ RFC3986 خروجی genre%5B0%5D می‌سازد که معتبر است.
    $res = getHtml($searchUrl);
    $xpath = api2_xpath_from_html($res['html']);
    $forcedType = $sourceType === 'movie' ? 'movie' : ($sourceType === 'series' ? 'series' : null);

    $movies = api2_parse_entry_cards($xpath, null, $forcedType);
    if ($forcedType) {
        $movies = array_values(array_filter($movies, function($m) use ($forcedType) {
            return ($m['type'] ?? '') === $forcedType;
        }));
    }

    if ($query !== '' && $page <= 2 && count($movies) < 3) {
        $fallback = api2_fallback_search_updated_and_direct($query, $sourceType, $page);
        if (!empty($fallback)) $movies = api2_merge_search_cards($movies, $fallback, 24);
    }

    return $movies;
}
