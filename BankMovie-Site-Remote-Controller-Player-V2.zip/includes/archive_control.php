<?php
require_once __DIR__ . '/security_bootstrap.php';
require_once __DIR__ . '/vip_features.php';
/**
 * BankMovie Archive/API control helper
 * Shared by /, movie.php, /view_all, api4.php and admin.php.
 */
if (!function_exists('bm_archive_control_defaults')) {
    function bm_archive_control_defaults(): array {
        return [
            'archives' => [
                'archive1' => [
                    'label' => 'آرشیو ۱',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'source_base_url' => 'https://www.my-f2mx.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۱ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive2' => [
                    'label' => 'آرشیو ۲',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'source_base_url' => 'https://serialblog1.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۲ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive3' => [
                    'label' => 'آرشیو ۳',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'source_base_url' => 'https://dornatv.com',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۳ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
                'archive4' => [
                    'label' => 'آرشیو ۴',
                    'enabled' => true,
                    'access_scope' => 'public',
                    'download_access_scope' => 'public',
                    'stream_access_scope' => 'public',
                    'source_base_url' => 'https://cinamatic.top',
                    'download_base_urls' => ['https://dl10.bankmovie.top'],
                    'disabled_mode' => 'visible',
                    'disabled_message' => 'آرشیو ۴ موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
                ],
            ],
            'blocked_items' => [],
            'audience_schema_version' => 5,
            'updated_at' => null,
        ];
    }
}

if (!function_exists('bm_archive_normalize_base_url')) {
    function bm_archive_normalize_base_url($value, bool $allowEmpty = true): string {
        $value = trim((string)$value);
        if ($value === '') return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        if (strlen($value) > 500 || preg_match('/[\x00-\x20\x7f]/', $value)) return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        if (!preg_match('~^[a-z][a-z0-9+.-]*://~i', $value)) $value = 'https://' . ltrim($value, '/');
        $parts = @parse_url($value);
        if (!is_array($parts)) return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        $host = strtolower(rtrim((string)($parts['host'] ?? ''), '.'));
        if (!in_array($scheme, ['http','https'], true) || $host === '' || isset($parts['user']) || isset($parts['pass'])) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        if ($host === 'localhost' || !str_contains($host, '.') || str_ends_with($host, '.local') || filter_var($host, FILTER_VALIDATE_IP)) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        if (!preg_match('/^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/i', $host)) {
            return $allowEmpty ? '' : 'https://dl10.bankmovie.top';
        }
        $port = isset($parts['port']) ? ':' . (int)$parts['port'] : '';
        $path = trim((string)($parts['path'] ?? ''), '/');
        return $scheme . '://' . $host . $port . ($path !== '' ? '/' . $path : '');
    }
}

if (!function_exists('bm_archive_normalize_url_list')) {
    function bm_archive_normalize_url_list($value, array $fallback = []): array {
        if (is_string($value)) $value = preg_split('/\R+|[,،]+/u', $value) ?: [];
        if (!is_array($value)) $value = [];
        $out = [];
        foreach ($value as $url) {
            $url = bm_archive_normalize_base_url($url, true);
            if ($url !== '' && strtolower((string)(parse_url($url, PHP_URL_SCHEME) ?: '')) !== 'https') $url = '';
            if ($url !== '' && !in_array($url, $out, true)) $out[] = $url;
            if (count($out) >= 12) break;
        }
        if (!$out) {
            foreach ($fallback as $url) {
                $url = bm_archive_normalize_base_url($url, false);
                if (strtolower((string)(parse_url($url, PHP_URL_SCHEME) ?: '')) !== 'https') continue;
                if ($url !== '' && !in_array($url, $out, true)) $out[] = $url;
            }
        }
        return $out ?: ['https://dl10.bankmovie.top'];
    }
}

if (!function_exists('bm_archive_normalize_identifier')) {
    function bm_archive_normalize_identifier($value): string {
        $value = rawurldecode(trim((string)$value));
        if ($value === '') return '';
        if (function_exists('mb_strtolower')) $value = mb_strtolower($value, 'UTF-8');
        else $value = strtolower($value);
        $value = preg_replace('/[\x{200c}\x{200e}\x{200f}\s]+/u', ' ', $value) ?? $value;
        return trim($value, " /\t\n\r\0\x0B");
    }
}

if (!function_exists('bm_archive_normalize_blocked_items')) {
    function bm_archive_normalize_blocked_items($items): array {
        if (!is_array($items)) return [];
        $out = [];
        foreach ($items as $row) {
            if (!is_array($row)) continue;
            $archiveId = strtolower(trim((string)($row['archive_id'] ?? '')));
            if (!in_array($archiveId, ['archive1','archive2','archive3','archive4'], true)) continue;
            $identifier = trim((string)($row['identifier'] ?? ''));
            $sourceUrl = trim((string)($row['source_url'] ?? ''));
            $title = trim(strip_tags((string)($row['title'] ?? '')));
            $year = trim((string)($row['year'] ?? ''));
            if ($identifier === '' && $sourceUrl === '' && $title === '') continue;
            if (strlen($identifier) > 500) $identifier = substr($identifier, 0, 500);
            if (strlen($sourceUrl) > 1000) $sourceUrl = substr($sourceUrl, 0, 1000);
            if (function_exists('mb_substr')) $title = mb_substr($title, 0, 240, 'UTF-8');
            else $title = substr($title, 0, 240);
            $stable = $archiveId . '|' . bm_archive_normalize_identifier($identifier) . '|' . bm_archive_normalize_identifier($sourceUrl) . '|' . bm_archive_normalize_identifier($title) . '|' . $year;
            $id = trim((string)($row['id'] ?? ''));
            if (!preg_match('/^[a-f0-9]{16,64}$/', $id)) $id = substr(hash('sha256', $stable), 0, 24);
            $out[$id] = [
                'id' => $id,
                'archive_id' => $archiveId,
                'identifier' => $identifier,
                'source_url' => $sourceUrl,
                'title' => $title !== '' ? $title : $identifier,
                'year' => preg_match('/^\d{4}$/', $year) ? $year : '',
                'block_downloads' => true,
                'created_at' => trim((string)($row['created_at'] ?? '')) ?: date('c'),
            ];
            if (count($out) >= 1000) break;
        }
        return array_values($out);
    }
}

if (!function_exists('bm_archive_control_path')) {
    function bm_archive_control_path(): string {
        // Store settings outside public_html when possible. Old public file remains as read-only fallback.
        if (function_exists('bm_security_private_path')) {
            return bm_security_private_path('archive_api_settings.json');
        }
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_legacy_path')) {
    function bm_archive_control_legacy_path(): string {
        return dirname(__DIR__) . '/archive_api_settings.json';
    }
}

if (!function_exists('bm_archive_control_normalize')) {
    function bm_archive_control_normalize(array $settings): array {
        $defaults = bm_archive_control_defaults();
        if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
        foreach ($defaults['archives'] as $id => $def) {
            $row = isset($settings['archives'][$id]) && is_array($settings['archives'][$id]) ? $settings['archives'][$id] : [];
            $label = trim((string)($row['label'] ?? $def['label']));
            $mode = trim((string)($row['disabled_mode'] ?? $def['disabled_mode']));
            if (!in_array($mode, ['visible', 'hide'], true)) $mode = 'visible';
            $scope = trim((string)($row['access_scope'] ?? $def['access_scope'] ?? 'public'));
            if (!in_array($scope, ['public', 'member', 'vip', 'admin'], true)) $scope = 'public';
            $downloadScope = trim((string)($row['download_access_scope'] ?? $def['download_access_scope'] ?? 'public'));
            if (!in_array($downloadScope, ['public', 'member', 'vip', 'admin', 'disabled'], true)) $downloadScope = 'public';
            $streamScope = trim((string)($row['stream_access_scope'] ?? $def['stream_access_scope'] ?? 'public'));
            if (!in_array($streamScope, ['public', 'member', 'vip', 'admin', 'disabled'], true)) $streamScope = 'public';
            $msg = trim((string)($row['disabled_message'] ?? $def['disabled_message']));
            $settings['archives'][$id] = [
                'label' => $label !== '' ? $label : $def['label'],
                'enabled' => filter_var($row['enabled'] ?? $def['enabled'], FILTER_VALIDATE_BOOLEAN),
                'access_scope' => $scope,
                'download_access_scope' => $downloadScope,
                'stream_access_scope' => $streamScope,
                'source_base_url' => bm_archive_normalize_base_url($row['source_base_url'] ?? $def['source_base_url'] ?? '', true),
                'download_base_urls' => bm_archive_normalize_url_list($row['download_base_urls'] ?? ($row['download_base_url'] ?? []), $def['download_base_urls'] ?? ['https://dl10.bankmovie.top']),
                'disabled_mode' => $mode,
                'disabled_message' => $msg !== '' ? $msg : $def['disabled_message'],
            ];
        }
        $settings['blocked_items'] = bm_archive_normalize_blocked_items($settings['blocked_items'] ?? []);
        $settings['audience_schema_version'] = max(0, (int)($settings['audience_schema_version'] ?? 0));
        if (!isset($settings['updated_at'])) $settings['updated_at'] = null;
        return $settings;
    }
}

if (!function_exists('bm_archive_get_settings')) {
    function bm_archive_get_settings(): array {
        $settings = [];
        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) $paths[] = bm_archive_control_legacy_path();
        foreach (array_values(array_unique($paths)) as $path) {
            if (is_file($path)) {
                $raw = @file_get_contents($path);
                $json = is_string($raw) ? json_decode($raw, true) : null;
                if (is_array($json)) { $settings = $json; break; }
            }
        }

        // Audience schema migration.
        // v2 introduced Public/Admin. v3 adds Member/VIP while preserving every
        // existing administrator choice instead of resetting scopes.
        $audienceVersion = (int)($settings['audience_schema_version'] ?? 0);
        if ($audienceVersion < 2) {
            if (!isset($settings['archives']) || !is_array($settings['archives'])) $settings['archives'] = [];
            foreach (['archive1','archive2','archive3','archive4'] as $aid) {
                if (!isset($settings['archives'][$aid]) || !is_array($settings['archives'][$aid])) $settings['archives'][$aid] = [];
                $settings['archives'][$aid]['access_scope'] = 'public';
            }
        }
        if ($audienceVersion < 4) {
            $settings['audience_schema_version'] = 4;
        }
        // v5 corrects the earlier controller/content mix-up without touching
        // any administrator-defined download subdomain.
        if ($audienceVersion < 5) {
            foreach (['archive1','archive2','archive3','archive4'] as $aid) {
                if (!isset($settings['archives'][$aid]) || !is_array($settings['archives'][$aid])) continue;
                $bases = (array)($settings['archives'][$aid]['download_base_urls'] ?? []);
                foreach ($bases as &$base) {
                    $host = strtolower((string)(parse_url((string)$base, PHP_URL_HOST) ?: ''));
                    if (in_array($host, ['bankmoviee.ir','www.bankmoviee.ir'], true)) $base = 'https://dl10.bankmovie.top';
                }
                unset($base);
                $settings['archives'][$aid]['download_base_urls'] = array_values(array_unique($bases));
            }
            $settings['audience_schema_version'] = 5;
            $normalized = bm_archive_control_normalize($settings);
            @bm_archive_save_settings($normalized);
            return $normalized;
        }
        return bm_archive_control_normalize($settings);
    }
}

if (!function_exists('bm_archive_save_settings')) {
    function bm_archive_save_settings(array $settings): bool {
        $settings = bm_archive_control_normalize($settings);
        $settings['audience_schema_version'] = 5;
        $settings['updated_at'] = date('c');
        $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;

        $paths = [bm_archive_control_path()];
        if (function_exists('bm_archive_control_legacy_path')) {
            $paths[] = bm_archive_control_legacy_path();
        }

        foreach (array_values(array_unique($paths)) as $path) {
            $dir = dirname($path);
            if (!is_dir($dir) && !@mkdir($dir, 0700, true)) continue;
            $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(3));
            if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
                @unlink($tmp);
                continue;
            }
            @chmod($tmp, 0600);
            if (@rename($tmp, $path)) {
                @chmod($path, 0600);
                clearstatcache(true, $path);
                return true;
            }
            @unlink($tmp);
        }
        return false;
    }
}

if (!function_exists('bm_archive_get_config')) {
    function bm_archive_get_config(string $archiveId): array {
        $settings = bm_archive_get_settings();
        return $settings['archives'][$archiveId] ?? bm_archive_control_defaults()['archives'][$archiveId] ?? [];
    }
}

if (!function_exists('bm_archive_is_enabled')) {
    function bm_archive_is_enabled(string $archiveId): bool {
        $cfg = bm_archive_get_config($archiveId);
        return !empty($cfg['enabled']);
    }
}

if (!function_exists('bm_archive_user_is_admin')) {
    function bm_archive_user_is_admin($user = null): bool {
        if ($user === null && isset($GLOBALS['currentUser'])) $user = $GLOBALS['currentUser'];
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return in_array($role, ['admin', 'administrator'], true);
    }
}

/**
 * Professional archive audience gate.
 *
 * public = everybody
 * member = any signed-in account
 * vip    = active VIP + administrators
 * admin  = administrators only
 *
 * Unauthorized audiences are always hidden from UI render helpers and direct
 * API/detail requests are rejected by their existing bm_archive_user_can_access()
 * checks.
 */
if (!function_exists('bm_archive_access_scope')) {
    function bm_archive_access_scope(string $archiveId): string {
        $cfg = bm_archive_get_config($archiveId);
        $scope = strtolower(trim((string)($cfg['access_scope'] ?? 'public')));
        return in_array($scope, ['public','member','vip','admin'], true) ? $scope : 'public';
    }
}

if (!function_exists('bm_archive_resolve_user')) {
    function bm_archive_resolve_user($user = null): ?array {
        if ($user === null && isset($GLOBALS['currentUser']) && is_array($GLOBALS['currentUser'])) {
            $user = $GLOBALS['currentUser'];
        }
        return is_array($user) ? $user : null;
    }
}

if (!function_exists('bm_archive_user_is_member')) {
    function bm_archive_user_is_member($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;
        if (!empty($user['id'])) return true;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        return $role !== '' && !in_array($role, ['guest','anonymous'], true);
    }
}

if (!function_exists('bm_archive_user_is_vip')) {
    function bm_archive_user_is_vip($user = null): bool {
        $user = bm_archive_resolve_user($user);
        if (!is_array($user)) return false;
        if (bm_archive_user_is_admin($user)) return true;

        if (function_exists('bm_vip_user_is_active')) {
            return bm_vip_user_is_active($user);
        }

        // Defensive fallback if VIP helper is unavailable on an unusual route.
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (!in_array($role, ['vip','premium','special'], true)) return false;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return true;
        $ts = strtotime($expiry);
        return $ts !== false && $ts > time();
    }
}

if (!function_exists('bm_archive_user_can_access')) {
    function bm_archive_user_can_access(string $archiveId, $user = null): bool {
        $scope = bm_archive_access_scope($archiveId);
        return bm_archive_scope_allows($scope, $user);
    }
}

if (!function_exists('bm_archive_scope_allows')) {
    function bm_archive_scope_allows(string $scope, $user = null): bool {
        $scope = strtolower(trim($scope));
        if ($scope === 'public') return true;
        if ($scope === 'member') return bm_archive_user_is_member($user);
        if ($scope === 'vip') return bm_archive_user_is_vip($user);
        if ($scope === 'admin') return bm_archive_user_is_admin(bm_archive_resolve_user($user));
        return false;
    }
}

if (!function_exists('bm_archive_feature_scope')) {
    function bm_archive_feature_scope(string $archiveId, string $feature): string {
        $cfg = bm_archive_get_config($archiveId);
        $key = $feature === 'stream' ? 'stream_access_scope' : 'download_access_scope';
        $scope = strtolower(trim((string)($cfg[$key] ?? 'public')));
        return in_array($scope, ['public','member','vip','admin','disabled'], true) ? $scope : 'public';
    }
}

if (!function_exists('bm_archive_feature_user_can_access')) {
    function bm_archive_feature_user_can_access(string $archiveId, string $feature, $user = null): bool {
        if (!bm_archive_is_enabled($archiveId) || !bm_archive_user_can_access($archiveId, $user)) return false;
        return bm_archive_scope_allows(bm_archive_feature_scope($archiveId, $feature), $user);
    }
}

if (!function_exists('bm_archive_source_base_url')) {
    function bm_archive_source_base_url(string $archiveId, string $fallback = ''): string {
        $cfg = bm_archive_get_config($archiveId);
        $url = bm_archive_normalize_base_url($cfg['source_base_url'] ?? '', true);
        return $url !== '' ? $url : rtrim($fallback, '/');
    }
}

if (!function_exists('bm_archive_download_base_urls')) {
    function bm_archive_download_base_urls(string $archiveId): array {
        $cfg = bm_archive_get_config($archiveId);
        return bm_archive_normalize_url_list($cfg['download_base_urls'] ?? [], ['https://dl10.bankmovie.top']);
    }
}

if (!function_exists('bm_archive_pick_download_base_url')) {
    function bm_archive_pick_download_base_url(string $archiveId, string $seed = ''): string {
        $urls = bm_archive_download_base_urls($archiveId);
        if (count($urls) === 1) return $urls[0];
        $hash = hash('sha256', $archiveId . '|' . $seed, true);
        return $urls[ord($hash[0]) % count($urls)];
    }
}

if (!function_exists('bm_archive_content_identity')) {
    function bm_archive_content_identity(array $data = [], array $context = []): array {
        $identifiers = [];
        $urls = [];
        $titles = [];
        $sources = [$context, $data];
        foreach (['data','item','movie','detail'] as $containerKey) {
            if (isset($data[$containerKey]) && is_array($data[$containerKey]) && !array_is_list($data[$containerKey])) {
                $sources[] = $data[$containerKey];
            }
        }
        foreach ($sources as $source) {
            foreach (['identifier','id','movie_id','imdb_code','imdb_id','imdb','slug','source_id','post_id','detail_id'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') $identifiers[] = $value;
                if ($key === 'movie_id' && $value !== '') $identifiers[] = 'movie_id:' . $value;
            }
            foreach (['source_url','detail_url','item_link','url'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') {
                    $urls[] = $value;
                    $path = trim((string)(parse_url((string)$source[$key], PHP_URL_PATH) ?: ''), '/');
                    if ($path !== '') {
                        $segments = array_values(array_filter(explode('/', $path), 'strlen'));
                        if ($segments) $identifiers[] = bm_archive_normalize_identifier((string)end($segments));
                    }
                }
            }
            foreach (['title','title_fa','name','name_fa','full_title'] as $key) {
                if (!isset($source[$key]) || !is_scalar($source[$key])) continue;
                $value = bm_archive_normalize_identifier($source[$key]);
                if ($value !== '') $titles[] = $value;
            }
        }
        $year = '';
        foreach ($sources as $source) {
            foreach ([$source['year'] ?? null, $source['release_year'] ?? null] as $candidate) {
                if (preg_match('/^(?:19|20)\d{2}$/', trim((string)$candidate))) { $year = trim((string)$candidate); break 2; }
            }
        }
        return [
            'identifiers' => array_values(array_unique($identifiers)),
            'urls' => array_values(array_unique($urls)),
            'titles' => array_values(array_unique($titles)),
            'year' => $year,
        ];
    }
}

if (!function_exists('bm_archive_find_blocked_item')) {
    function bm_archive_find_blocked_item(string $archiveId, array $data = [], array $context = []): ?array {
        $identity = bm_archive_content_identity($data, $context);
        $settings = bm_archive_get_settings();
        foreach ($settings['blocked_items'] ?? [] as $rule) {
            if (!is_array($rule) || ($rule['archive_id'] ?? '') !== $archiveId || empty($rule['block_downloads'])) continue;
            $ruleIdentifier = bm_archive_normalize_identifier($rule['identifier'] ?? '');
            $ruleUrl = bm_archive_normalize_identifier($rule['source_url'] ?? '');
            $ruleTitle = bm_archive_normalize_identifier($rule['title'] ?? '');
            if ($ruleIdentifier !== '' && in_array($ruleIdentifier, $identity['identifiers'], true)) return $rule;
            if ($ruleUrl !== '' && in_array($ruleUrl, $identity['urls'], true)) return $rule;
            if ($ruleTitle !== '' && in_array($ruleTitle, $identity['titles'], true)) {
                $ruleYear = trim((string)($rule['year'] ?? ''));
                if ($ruleYear === '' || ($identity['year'] !== '' && $ruleYear === $identity['year'])) return $rule;
            }
        }
        return null;
    }
}

if (!function_exists('bm_archive_item_downloads_blocked')) {
    function bm_archive_item_downloads_blocked(string $archiveId, array $data = [], array $context = []): bool {
        return bm_archive_find_blocked_item($archiveId, $data, $context) !== null;
    }
}

if (!function_exists('bm_archive_strip_download_payload')) {
    function bm_archive_strip_download_payload($value) {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) {
            foreach ($value as $i => $item) $value[$i] = bm_archive_strip_download_payload($item);
            return $value;
        }
        // Do not remove media rows: the same rows are also the source of online
        // playback. Remove only download capabilities and keep stream_url/url.
        $direct = ['dub_link','soft_link','download_url','download_link','subtitle_download_url','href'];
        foreach ($value as $key => $item) {
            if (in_array((string)$key, $direct, true)) {
                unset($value[$key]);
            } elseif (is_array($item)) {
                $value[$key] = bm_archive_strip_download_payload($item);
            }
        }
        if (array_key_exists('downloads_count', $value)) $value['downloads_count'] = 0;
        if (array_key_exists('has_downloads', $value)) $value['has_downloads'] = false;
        if (array_key_exists('is_download', $value)) $value['is_download'] = false;
        if (array_key_exists('download_allowed', $value)) $value['download_allowed'] = false;
        return $value;
    }
}

if (!function_exists('bm_archive_strip_stream_payload')) {
    function bm_archive_strip_stream_payload($value) {
        if (!is_array($value)) return $value;
        if (array_is_list($value)) {
            $out = [];
            foreach ($value as $item) {
                if (is_array($item) && strtolower(trim((string)($item['media_type'] ?? ''))) === 'stream') continue;
                $out[] = bm_archive_strip_stream_payload($item);
            }
            return $out;
        }
        $looksLikeMedia = array_key_exists('download_url', $value)
            || array_key_exists('media_type', $value)
            || array_key_exists('quality', $value)
            || array_key_exists('season', $value)
            || array_key_exists('episode', $value)
            || array_key_exists('is_download', $value);
        foreach ($value as $key => $item) {
            if (in_array((string)$key, ['play','play_links','stream_url','watch_url','play_url','online_url'], true)) {
                if ((string)$key === 'stream_url') unset($value[$key]);
                else $value[$key] = is_array($item) ? [] : null;
            } elseif ((string)$key === 'url' && $looksLikeMedia) {
                unset($value[$key]);
            } elseif (is_array($item)) {
                $value[$key] = bm_archive_strip_stream_payload($item);
            }
        }
        if (array_key_exists('has_online', $value)) $value['has_online'] = false;
        if (array_key_exists('playonline', $value)) $value['playonline'] = false;
        if (array_key_exists('stream_allowed', $value)) $value['stream_allowed'] = false;
        return $value;
    }
}

if (!function_exists('bm_archive_apply_payload_policy')) {
    function bm_archive_apply_payload_policy(string $archiveId, $payload, $user = null, array $context = []) {
        if (!is_array($payload)) return $payload;
        $isListPayload = array_is_list($payload);
        $downloadAllowed = bm_archive_feature_user_can_access($archiveId, 'download', $user)
            && !bm_archive_item_downloads_blocked($archiveId, $payload, $context);
        $streamAllowed = bm_archive_feature_user_can_access($archiveId, 'stream', $user);
        if (!$downloadAllowed) $payload = bm_archive_strip_download_payload($payload);
        if (!$streamAllowed) $payload = bm_archive_strip_stream_payload($payload);
        if (!$isListPayload && !$downloadAllowed) {
            $payload['downloads_locked'] = true;
            $payload['download_message'] = 'لینک‌های دانلود این عنوان در دسترس نیست.';
            // Detail responses are usually wrapped in {item: ...}. Mirror the
            // policy marker into the actual item because native clients render
            // that object and deliberately ignore envelope-only metadata.
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['downloads_locked'] = true;
                    $payload[$detailKey]['download_message'] = $payload['download_message'];
                }
            }
        }
        if (!$isListPayload && !$streamAllowed) {
            $payload['stream_locked'] = true;
            $payload['stream_message'] = 'پخش آنلاین این آرشیو برای حساب شما فعال نیست.';
            foreach (['item','movie'] as $detailKey) {
                if (isset($payload[$detailKey]) && is_array($payload[$detailKey]) && !array_is_list($payload[$detailKey])) {
                    $payload[$detailKey]['stream_locked'] = true;
                    $payload[$detailKey]['stream_message'] = $payload['stream_message'];
                }
            }
        }
        return $payload;
    }
}

if (!function_exists('bm_archive_access_scope_label')) {
    function bm_archive_access_scope_label(string $archiveId): string {
        $scope = bm_archive_access_scope($archiveId);
        return [
            'public' => 'همه کاربران',
            'member' => 'فقط کاربران واردشده',
            'vip' => 'فقط VIP فعال',
            'admin' => 'فقط مدیر',
        ][$scope] ?? 'همه کاربران';
    }
}

if (!function_exists('bm_archive_should_render_tab')) {
    function bm_archive_should_render_tab(string $archiveId): bool {
        if (!bm_archive_user_can_access($archiveId)) return false;
        $cfg = bm_archive_get_config($archiveId);
        return !empty($cfg['enabled']) || (($cfg['disabled_mode'] ?? 'visible') !== 'hide');
    }
}

if (!function_exists('bm_archive_disabled_message')) {
    function bm_archive_disabled_message(string $archiveId): string {
        $cfg = bm_archive_get_config($archiveId);
        return trim((string)($cfg['disabled_message'] ?? 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.'));
    }
}

if (!function_exists('bm_archive_label')) {
    function bm_archive_label(string $archiveId, string $fallback = ''): string {
        $cfg = bm_archive_get_config($archiveId);
        $label = trim((string)($cfg['label'] ?? ''));
        return $label !== '' ? $label : $fallback;
    }
}

if (!function_exists('bm_archive_public_config')) {
    function bm_archive_public_config(): array {
        $settings = bm_archive_get_settings();
        $out = [];
        foreach ($settings['archives'] as $id => $cfg) {
            $canAccess = bm_archive_user_can_access((string)$id);
            $out[$id] = [
                'label' => (string)($cfg['label'] ?? ''),
                'enabled' => $canAccess && !empty($cfg['enabled']),
                'access_scope' => (string)($cfg['access_scope'] ?? 'public'),
                'download_access_scope' => (string)($cfg['download_access_scope'] ?? 'public'),
                'stream_access_scope' => (string)($cfg['stream_access_scope'] ?? 'public'),
                'downloads_allowed' => $canAccess && bm_archive_feature_user_can_access((string)$id, 'download'),
                'stream_allowed' => $canAccess && bm_archive_feature_user_can_access((string)$id, 'stream'),
                'disabled_mode' => (string)($cfg['disabled_mode'] ?? 'visible'),
                'disabled_message' => (string)($cfg['disabled_message'] ?? ''),
                'render_tab' => $canAccess && (!empty($cfg['enabled']) || (($cfg['disabled_mode'] ?? 'visible') !== 'hide')),
                'preview_admin_only' => (($cfg['access_scope'] ?? 'public') === 'admin'),
                'preview_vip_only' => (($cfg['access_scope'] ?? 'public') === 'vip'),
                'preview_members_only' => (($cfg['access_scope'] ?? 'public') === 'member'),
                'access_scope_label' => function_exists('bm_archive_access_scope_label') ? bm_archive_access_scope_label((string)$id) : (string)($cfg['access_scope'] ?? 'public'),
            ];
        }
        return $out;
    }
}

if (!function_exists('bm_archive_default_mode')) {
    function bm_archive_default_mode(): string {
        $map = ['archive1' => 'arc1', 'archive2' => 'local', 'archive3' => 'arc3', 'archive4' => 'arc4'];
        foreach (['archive1','archive2','archive3','archive4'] as $id) {
            if (bm_archive_is_enabled($id) && bm_archive_should_render_tab($id)) return $map[$id];
        }
        return 'local';
    }
}

if (!function_exists('bm_archive_cookie_file')) {
    function bm_archive_cookie_file(string $archiveId): ?string {
        if ($archiveId !== 'archive4') return null;
        $name = 'api4_cookie.txt';
        if (function_exists('bm_security_private_path')) return bm_security_private_path($name);
        return dirname(__DIR__) . '/' . $name;
    }
}

if (!function_exists('bm_archive_cookie_legacy_file')) {
    function bm_archive_cookie_legacy_file(string $archiveId): ?string {
        if ($archiveId === 'archive4') return dirname(__DIR__) . '/api4_cookie.txt';
        return null;
    }
}

if (!function_exists('bm_archive_cookie_status')) {
    function bm_archive_cookie_status(string $archiveId): array {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return ['supported'=>false, 'exists'=>false, 'bytes'=>0, 'updated'=>null, 'preview'=>'', 'storage'=>'none'];
        $readFile = $file;
        $exists = is_file($readFile);
        $raw = $exists ? (string)@file_get_contents($readFile) : '';
        $raw = trim($raw);
        $preview = '';
        if ($raw !== '') $preview = substr($raw, 0, 28) . '••••' . substr($raw, -16);
        return [
            'supported'=>true,
            'exists'=>$exists,
            'bytes'=>strlen($raw),
            'updated'=>$exists ? @date('Y-m-d H:i:s', (int)@filemtime($readFile)) : null,
            'preview'=>$preview,
            'storage'=>($readFile === $file ? 'private' : 'legacy'),
        ];
    }
}

if (!function_exists('bm_archive_write_cookie')) {
    function bm_archive_write_cookie(string $archiveId, string $cookie): bool {
        $file = bm_archive_cookie_file($archiveId);
        if (!$file) return false;
        $cookie = function_exists('bm_security_normalize_cookie') ? bm_security_normalize_cookie($cookie) : trim($cookie);
        if ($cookie === '') return false;
        $dir = dirname($file);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $ok = (bool)@file_put_contents($file, $cookie . PHP_EOL, LOCK_EX);
        if ($ok) @chmod($file, 0600);
        return $ok;
    }
}

if (!function_exists('bm_archive_clear_cookie')) {
    function bm_archive_clear_cookie(string $archiveId): bool {
        $ok = false;
        foreach ([bm_archive_cookie_file($archiveId), function_exists('bm_archive_cookie_legacy_file') ? bm_archive_cookie_legacy_file($archiveId) : null] as $file) {
            if (!$file) continue;
            $dir = dirname($file);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $ok = (bool)@file_put_contents($file, '', LOCK_EX) || $ok;
            if (is_file($file)) @chmod($file, 0600);
        }
        return $ok;
    }
}
