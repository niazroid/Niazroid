<?php
/**
 * donyaye_series_crawler_lib.php
 * BankMovie — crawler/matcher for Donyaye Serial / SerialBlog series pages.
 * Safe mode: does NOT write to movie database. Only writes JSON preview file.
 */
if (defined('BM_DONYAYE_CRAWLER_LIB')) return;
define('BM_DONYAYE_CRAWLER_LIB', true);

const BM_DS_BASE = 'https://serialblog1.top';
const BM_DS_JSON_REL = 'cache/donyaye_series_matches.json';
const BM_DS_STATE_REL = 'cache/donyaye_series_crawler_state.json';
const BM_DS_BATCH_SIZE = 10;
const BM_DS_SAVE_EVERY = 1;
const BM_DS_MAX_HTML_BYTES = 4_000_000;

function bm_ds_e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function bm_ds_lower(string $s): string {
    return function_exists('mb_strtolower') ? mb_strtolower($s, 'UTF-8') : strtolower($s);
}

function bm_ds_strlen(string $s): int {
    return function_exists('mb_strlen') ? mb_strlen($s, 'UTF-8') : strlen($s);
}


function bm_ds_storage_path(): string {
    return dirname(__DIR__) . '/' . BM_DS_JSON_REL;
}

function bm_ds_state_path(): string {
    return dirname(__DIR__) . '/' . BM_DS_STATE_REL;
}

function bm_ds_load_state(): array {
    $path = bm_ds_state_path();
    if (!is_file($path)) {
        return [
            'active' => false,
            'done' => false,
            'scope' => 'all',
            'offset' => 0,
            'processed' => 0,
            'matched' => 0,
            'total' => 0,
            'started_at' => null,
            'updated_at' => null,
            'last_error' => '',
            'last_batch' => [],
        ];
    }
    $data = json_decode((string)@file_get_contents($path), true);
    return is_array($data) ? array_merge(bm_ds_load_state_default(), $data) : bm_ds_load_state_default();
}

function bm_ds_load_state_default(): array {
    return [
        'active' => false,
        'done' => false,
        'scope' => 'all',
        'offset' => 0,
        'processed' => 0,
        'matched' => 0,
        'total' => 0,
        'started_at' => null,
        'updated_at' => null,
        'last_error' => '',
        'last_batch' => [],
        'live_offset' => 0,
        'live_processed' => 0,
        'live_matched' => 0,
        'batch_offset_start' => 0,
        'batch_total' => 0,
        'batch_done' => 0,
        'batch_started_at' => null,
        'batch_finished_at' => null,
        'current_status' => '',
        'current_item' => '',
        'current_imdb' => '',
        'current_title' => '',
        'last_saved_at' => null,
        'last_batch_items' => [],
        'storage_error' => '',
    ];
}

function bm_ds_ensure_storage_dir(): string {
    $dir = dirname(bm_ds_storage_path());
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('ساخت پوشه cache ناموفق بود: ' . $dir);
        }
    }
    if (!is_writable($dir)) {
        throw new RuntimeException('پوشه cache قابل نوشتن نیست: ' . $dir . ' — Permission را روی 755 یا 775 بگذار.');
    }
    return $dir;
}

function bm_ds_write_file_atomic(string $path, string $contents, int $chmod = 0644): int {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        if (!@mkdir($dir, 0755, true) && !is_dir($dir)) {
            throw new RuntimeException('ساخت پوشه ناموفق بود: ' . $dir);
        }
    }
    if (!is_writable($dir)) {
        throw new RuntimeException('پوشه قابل نوشتن نیست: ' . $dir);
    }
    $tmp = $path . '.tmp.' . getmypid() . '.' . bin2hex(random_bytes(4));
    $bytes = @file_put_contents($tmp, $contents, LOCK_EX);
    if ($bytes === false) {
        $err = error_get_last();
        throw new RuntimeException('نوشتن فایل موقت ناموفق بود: ' . $tmp . ' — ' . ($err['message'] ?? 'unknown error'));
    }
    @chmod($tmp, $chmod);
    if (!@rename($tmp, $path)) {
        // Some hosts block rename over an existing file; fallback to direct write.
        @unlink($tmp);
        $bytes = @file_put_contents($path, $contents, LOCK_EX);
        if ($bytes === false) {
            $err = error_get_last();
            throw new RuntimeException('ذخیره فایل ناموفق بود: ' . $path . ' — ' . ($err['message'] ?? 'unknown error'));
        }
    }
    @chmod($path, $chmod);
    clearstatcache(true, $path);
    if (!is_file($path) || filesize($path) <= 0) {
        throw new RuntimeException('فایل ذخیره شد اما خالی/نامعتبر است: ' . $path);
    }
    return (int)filesize($path);
}

function bm_ds_save_state(array $state): array {
    $path = bm_ds_state_path();
    $state = array_merge(bm_ds_load_state_default(), $state);
    $state['updated_at'] = date('c');
    $encoded = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        throw new RuntimeException('ساخت JSON وضعیت کرالر ناموفق بود.');
    }
    bm_ds_write_file_atomic($path, $encoded, 0644);
    return $state;
}


function bm_ds_fetch_mode_label(): string {
    return 'internal_server_direct';
}

function bm_ds_storage_status(): array {
    $jsonPath = bm_ds_storage_path();
    $statePath = bm_ds_state_path();
    $dir = dirname($jsonPath);
    $json = bm_ds_load_existing_json();
    $linkTotal = 0;
    foreach (bm_ds_compact_items_array($json) as $it) {
        $linkTotal += bm_ds_compact_link_count($it);
    }
    $perms = is_dir($dir) ? substr(sprintf('%o', (int)@fileperms($dir)), -4) : '';
    return [
        'dir' => $dir,
        'dir_exists' => is_dir($dir),
        'dir_writable' => is_dir($dir) && is_writable($dir),
        'dir_perms' => $perms,
        'json_path' => $jsonPath,
        'json_exists' => is_file($jsonPath),
        'json_size' => is_file($jsonPath) ? (int)@filesize($jsonPath) : 0,
        'json_mtime' => is_file($jsonPath) ? date('c', (int)@filemtime($jsonPath)) : null,
        'state_exists' => is_file($statePath),
        'state_size' => is_file($statePath) ? (int)@filesize($statePath) : 0,
        'db_link_total' => $linkTotal,
        'connection_label' => 'BankMovie server direct curl',
        'fetch_mode' => bm_ds_fetch_mode_label(),
    ];
}

function bm_ds_is_allowed_page_url(string $url): bool {
    $p = parse_url($url);
    if (!$p || strtolower($p['scheme'] ?? '') !== 'https') return false;
    $host = strtolower($p['host'] ?? '');
    return $host === 'serialblog1.top' || str_ends_with($host, '.serialblog1.top');
}

function bm_ds_abs_url(string $url, string $base = BM_DS_BASE): string {
    $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($url === '') return '';
    if (preg_match('~^https?://~i', $url)) return $url;
    if (str_starts_with($url, '//')) return 'https:' . $url;
    if ($url[0] === '/') return rtrim($base, '/') . $url;
    return rtrim($base, '/') . '/' . ltrim($url, '/');
}

function bm_ds_http_get(string $url, int $timeout = 18, int $redirects = 0): array {
    $url = bm_ds_abs_url($url);
    if (!bm_ds_is_allowed_page_url($url)) {
        return ['ok' => false, 'status' => 0, 'url' => $url, 'body' => '', 'error' => 'URL غیرمجاز'];
    }
    if (!function_exists('curl_init')) {
        $ctx = stream_context_create(['http' => ['timeout' => $timeout, 'header' => "User-Agent: Mozilla/5.0 BankMovieCrawler\r\nAccept: text/html,application/json,*/*\r\n"]]);
        $body = @file_get_contents($url, false, $ctx, 0, BM_DS_MAX_HTML_BYTES);
        return ['ok' => $body !== false, 'status' => $body !== false ? 200 : 0, 'url' => $url, 'body' => (string)$body, 'error' => $body === false ? 'fetch failed' : ''];
    }
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HEADER => true,
        // Direct server fetch with browser-like headers.
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => min(5, max(3, $timeout)),
        CURLOPT_TIMEOUT => $timeout,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        CURLOPT_REFERER => BM_DS_BASE . '/',
        CURLOPT_ENCODING => '',
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7',
            'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.6',
            'Cache-Control: no-cache',
            'Pragma: no-cache',
        ],
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    if (defined('CURL_IPRESOLVE_V4')) {
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
    }
    $raw = curl_exec($ch);
    $err = curl_error($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $headerSize = (int)curl_getinfo($ch, CURLINFO_HEADER_SIZE);
    $effectiveUrl = (string)curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
    curl_close($ch);
    if ($raw === false) return ['ok' => false, 'status' => $status, 'url' => $url, 'body' => '', 'error' => $err ?: 'curl failed'];
    if ($effectiveUrl !== '' && !bm_ds_is_allowed_page_url($effectiveUrl)) {
        return ['ok' => false, 'status' => $status, 'url' => $url, 'body' => '', 'error' => 'redirect نهایی غیرمجاز'];
    }
    $headers = substr($raw, 0, $headerSize);
    $body = substr($raw, $headerSize);
    if (strlen($body) > BM_DS_MAX_HTML_BYTES) $body = substr($body, 0, BM_DS_MAX_HTML_BYTES);
    return ['ok' => $status >= 200 && $status < 300 && $body !== '', 'status' => $status, 'url' => $url, 'body' => (string)$body, 'error' => ''];
}

function bm_ds_json_get(string $url): ?array {
    $res = bm_ds_http_get($url, 8);
    if (!$res['ok']) return null;
    $data = json_decode($res['body'], true);
    return is_array($data) ? $data : null;
}

function bm_ds_strip_text(string $html): string {
    $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $html = preg_replace('~<script\b[^>]*>.*?</script>~is', ' ', $html);
    $html = preg_replace('~<style\b[^>]*>.*?</style>~is', ' ', $html);
    $txt = trim(preg_replace('/\s+/u', ' ', strip_tags($html)));
    return $txt;
}

function bm_ds_clean_title(string $title): string {
    $title = html_entity_decode($title, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $title = preg_replace('/\b(دانلود|سریال|فیلم|بدون سانسور|رایگان|دوبله|زیرنویس|فارسی|چسبیده)\b/u', ' ', $title);
    $title = preg_replace('/[\|\-–—]+/u', ' ', $title);
    return trim(preg_replace('/\s+/u', ' ', $title));
}

function bm_ds_slugify(string $s): string {
    $s = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $s = strtolower($s);
    $s = preg_replace('/[^a-z0-9]+/i', '-', $s);
    return trim((string)$s, '-');
}

function bm_ds_similarity(string $a, string $b): int {
    $a = bm_ds_lower(bm_ds_clean_title($a));
    $b = bm_ds_lower(bm_ds_clean_title($b));
    if ($a === '' || $b === '') return 0;
    similar_text($a, $b, $pct);
    return (int)round($pct);
}

function bm_ds_extract_links_from_search_html(string $html): array {
    $links = [];
    if (preg_match_all('~href=["\'](https://serialblog1\.top/series/[^"\'#?]+/?)["\']~i', $html, $m)) {
        foreach ($m[1] as $u) $links[] = $u;
    }
    return array_values(array_unique($links));
}

function bm_ds_candidate_urls_for_movie(array $movie): array {
    $candidates = [];
    $imdb = trim((string)($movie['imdb_code'] ?? ''));
    $title = trim((string)($movie['title'] ?? ''));
    $titleFa = trim((string)($movie['title_fa'] ?? ''));

    // FAST MODE:
    // 1) Try predictable English slugs first (no network call here).
    // 2) If IMDb exists, use IMDb-only search endpoints. This was verified to work on SerialBlog and is much faster.
    // 3) Title/Persian fallback is only used when IMDb is missing.
    foreach ([$title, bm_ds_clean_title($title)] as $t) {
        $slug = bm_ds_slugify($t);
        if ($slug !== '') $candidates[] = BM_DS_BASE . '/series/' . $slug . '/';
    }

    if ($imdb !== '') {
        // WordPress REST search by IMDb/poster filename.
        $api = BM_DS_BASE . '/wp-json/wp/v2/series?per_page=5&search=' . rawurlencode($imdb) . '&_fields=id,link,title,slug';
        $items = bm_ds_json_get($api);
        if (is_array($items)) {
            foreach ($items as $it) {
                if (!empty($it['link'])) $candidates[] = (string)$it['link'];
            }
        }

        // WordPress public search by IMDb code.
        $res = bm_ds_http_get(BM_DS_BASE . '/?s=' . rawurlencode($imdb), 8);
        if ($res['ok']) {
            foreach (bm_ds_extract_links_from_search_html($res['body']) as $u) $candidates[] = $u;
        }

        // Media API by IMDb/poster filename. If media is attached to a series post, fetch that post.
        $media = bm_ds_json_get(BM_DS_BASE . '/wp-json/wp/v2/media?per_page=5&search=' . rawurlencode($imdb) . '&_fields=id,source_url,post,link,title');
        if (is_array($media)) {
            foreach ($media as $m) {
                if (!empty($m['post'])) {
                    $postId = (int)$m['post'];
                    $series = bm_ds_json_get(BM_DS_BASE . '/wp-json/wp/v2/series/' . $postId . '?_fields=id,link,title,slug');
                    if (is_array($series) && !empty($series['link'])) $candidates[] = (string)$series['link'];
                }
            }
        }
    } else {
        // Fallback for rare rows without IMDb code: only 2 lightweight searches.
        $terms = [];
        foreach ([$title, bm_ds_clean_title($title), $titleFa, bm_ds_clean_title($titleFa)] as $t) {
            $t = trim($t);
            if ($t !== '' && bm_ds_strlen($t) >= 2) $terms[] = $t;
        }
        foreach (array_slice(array_values(array_unique($terms)), 0, 2) as $term) {
            $api = BM_DS_BASE . '/wp-json/wp/v2/series?per_page=5&search=' . rawurlencode($term) . '&_fields=id,link,title,slug';
            $items = bm_ds_json_get($api);
            if (is_array($items)) {
                foreach ($items as $it) {
                    if (!empty($it['link'])) $candidates[] = (string)$it['link'];
                }
            }
        }
    }

    $out = [];
    foreach ($candidates as $u) {
        $u = bm_ds_abs_url($u);
        if (bm_ds_is_allowed_page_url($u) && preg_match('~/series/[^/]+/?$~i', parse_url($u, PHP_URL_PATH) ?? '')) $out[] = $u;
    }
    return array_slice(array_values(array_unique($out)), 0, 6);
}

function bm_ds_extract_page_info(string $html, string $url): array {
    $canonical = '';
    if (preg_match('~<link[^>]+rel=["\']canonical["\'][^>]+href=["\']([^"\']+)["\']~i', $html, $m)) $canonical = html_entity_decode($m[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');

    $title = '';
    foreach ([
        '~<h1[^>]*>(.*?)</h1>~is',
        '~<meta\s+property=["\']og:title["\']\s+content=["\']([^"\']+)["\']~i',
        '~<title[^>]*>(.*?)</title>~is'
    ] as $pat) {
        if (preg_match($pat, $html, $m)) { $title = bm_ds_strip_text($m[1]); break; }
    }

    $imdb = '';
    if (preg_match('~imdb\.com/title/(tt\d+)~i', $html, $m)) $imdb = strtolower($m[1]);
    elseif (preg_match('~\b(tt\d{6,10})\b~i', $html, $m)) $imdb = strtolower($m[1]);

    $poster = '';
    foreach ([
        '~id=["\']post-cover-img["\'][^>]+data-cover=["\']([^"\']+)["\']~i',
        '~<meta\s+property=["\']og:image["\']\s+content=["\']([^"\']+)["\']~i',
        '~<img[^>]+class=["\'][^"\']*wp-post-image[^"\']*["\'][^>]+src=["\']([^"\']+)["\']~i'
    ] as $pat) {
        if (preg_match($pat, $html, $m)) { $poster = bm_ds_abs_url($m[1]); break; }
    }

    $downloads = bm_ds_extract_download_blocks($html);
    $seasons = [];
    $qualities = [];
    $types = [];
    $totalLinks = 0;
    foreach ($downloads as $b) {
        if (!empty($b['season'])) $seasons[(string)$b['season']] = true;
        if (!empty($b['quality'])) $qualities[(string)$b['quality']] = true;
        if (!empty($b['version'])) $types[(string)$b['version']] = true;
        $totalLinks += count($b['links'] ?? []);
    }

    return [
        'url' => $canonical ?: $url,
        'fetched_url' => $url,
        'title' => $title,
        'imdb_code' => $imdb,
        'poster' => $poster,
        'download_summary' => [
            'blocks' => count($downloads),
            'links' => $totalLinks,
            'seasons' => array_values(array_keys($seasons)),
            'qualities' => array_values(array_keys($qualities)),
            'versions' => array_values(array_keys($types)),
        ],
        // Full parsed blocks are kept for DB preview/import; sample is only for UI readability.
        'downloads' => $downloads,
        'sample_downloads' => array_slice($downloads, 0, 10),
    ];
}


function bm_ds_pad2($n): string {
    $i = (int)$n;
    return $i > 0 ? str_pad((string)$i, 2, '0', STR_PAD_LEFT) : '';
}

function bm_ds_link_kind_from_version(string $version): string {
    $v = bm_ds_lower(trim($version));
    if (preg_match('/(دوبله|dubbed|dub)/iu', $v)) return 'dubbed';
    return 'softsub';
}

function bm_ds_db_quality_label($season, $episode, string $quality): string {
    $quality = trim(preg_replace('/\s+/u', ' ', $quality));
    $s = bm_ds_pad2($season);
    $e = bm_ds_pad2($episode);
    if ($s !== '' && $e !== '') return 'S' . $s . 'E' . $e . ' - ' . $quality;
    if ($s !== '') return 'S' . $s . ' - ' . $quality;
    return $quality;
}

function bm_ds_build_db_preview(array $movie, ?array $best): array {
    $movieId = (int)($movie['id'] ?? 0);
    $imdb = strtolower(trim((string)($movie['imdb_code'] ?? '')));
    $out = [
        'target_database' => 'niazroid_bankmovie1',
        'target_tables' => [
            'movies' => ['id','imdb_code','type','title','title_fa','year'],
            'softsub_links' => ['movie_id','quality','url','size','is_folder','season'],
            'dubbed_links' => ['movie_id','quality','url','size','season','is_folder'],
        ],
        'note' => 'فعلاً فقط JSON است و دیتابیس را تغییر نمی‌دهد. چون جدول‌های فعلی episode ندارند، شماره قسمت داخل quality_current_schema هم آمده است.',
        'movie' => [
            'movie_id' => $movieId,
            'imdb_code' => $imdb,
            'type' => (string)($movie['type'] ?? ''),
            'title' => (string)($movie['title'] ?? ''),
            'title_fa' => (string)($movie['title_fa'] ?? ''),
            'year' => (string)($movie['year'] ?? ''),
        ],
        'softsub_links' => [],
        'dubbed_links' => [],
        'all_links' => [],
        'counts' => ['softsub' => 0, 'dubbed' => 0, 'total' => 0],
    ];
    if (!$best || empty($best['remote']['downloads']) || !is_array($best['remote']['downloads'])) return $out;
    $sourcePage = (string)($best['url'] ?? ($best['remote']['url'] ?? ''));
    foreach ($best['remote']['downloads'] as $block) {
        if (!is_array($block)) continue;
        $kind = bm_ds_link_kind_from_version((string)($block['version'] ?? ''));
        $table = $kind === 'dubbed' ? 'dubbed_links' : 'softsub_links';
        $seasonInt = (int)($block['season'] ?? 0);
        $season = bm_ds_pad2($seasonInt);
        $qualityClean = trim((string)($block['quality'] ?? ''));
        $size = trim((string)($block['size'] ?? ''));
        foreach (($block['links'] ?? []) as $ln) {
            if (!is_array($ln)) continue;
            $url = trim((string)($ln['url'] ?? ''));
            if ($url === '') continue;
            $episode = isset($ln['episode']) ? (int)$ln['episode'] : 0;
            $rec = [
                'table' => $table,
                'movie_id' => $movieId,
                'imdb_code' => $imdb,
                'quality' => bm_ds_db_quality_label($seasonInt, $episode, $qualityClean),
                'quality_clean' => $qualityClean,
                'url' => $url,
                'size' => $size,
                'is_folder' => 0,
                'season' => $season ?: null,
                'season_int' => $seasonInt ?: null,
                'episode' => $episode ?: null,
                'episode_to' => $ln['episode_to'] ?? null,
                'label' => (string)($ln['label'] ?? ''),
                'version' => (string)($block['version'] ?? ''),
                'source_page' => $sourcePage,
                'quality_current_schema' => bm_ds_db_quality_label($seasonInt, $episode, $qualityClean),
            ];
            if ($kind === 'dubbed') $out['dubbed_links'][] = $rec; else $out['softsub_links'][] = $rec;
            $out['all_links'][] = $rec;
        }
    }
    $out['counts'] = [
        'softsub' => count($out['softsub_links']),
        'dubbed' => count($out['dubbed_links']),
        'total' => count($out['all_links']),
    ];
    return $out;
}

function bm_ds_extract_download_blocks(string $html): array {
    $blocks = [];
    $html = html_entity_decode($html, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $pattern = '~<p[^>]*>\s*فصل\s*:\s*([0-9۰-۹٠-٩]+)\s*/\s*کیفیت\s*:\s*([^/<]+?)\s*/\s*میانگین\s*حجم\s*:\s*([^/<]+?)\s*/\s*ورژن\s*:\s*(.*?)\s*/\s*قسمت\s*ها\s*:\s*([0-9۰-۹٠-٩]+).*?</p>\s*<p[^>]*>(.*?)</p>~isu';
    if (preg_match_all($pattern, $html, $matches, PREG_SET_ORDER)) {
        foreach ($matches as $m) {
            $season = bm_ds_num($m[1]);
            $quality = trim(bm_ds_strip_text($m[2]));
            $size = trim(bm_ds_strip_text($m[3]));
            $version = trim(bm_ds_strip_text($m[4]));
            $episodeCount = bm_ds_num($m[5]);
            $linksHtml = $m[6];
            $links = [];
            if (preg_match_all('~<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>~isu', $linksHtml, $am, PREG_SET_ORDER)) {
                foreach ($am as $a) {
                    $href = html_entity_decode($a[1], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                    $text = bm_ds_strip_text($a[2]);
                    $ep = 0; $epTo = null;
                    if (preg_match('/S\d{1,2}E(\d{1,3})(?:E(\d{1,3}))?/i', $href, $em)) {
                        $ep = (int)$em[1];
                        if (!empty($em[2])) $epTo = (int)$em[2];
                    } elseif (preg_match('/قسمت\s*([0-9۰-۹٠-٩]+)/u', $text, $em)) {
                        $ep = bm_ds_num($em[1]);
                    }
                    $links[] = [
                        'episode' => $ep ?: null,
                        'episode_to' => $epTo,
                        'label' => $text,
                        'url' => $href,
                    ];
                }
            }
            $blocks[] = [
                'season' => $season ?: null,
                'quality' => $quality,
                'size' => $size,
                'version' => $version,
                'episode_count' => $episodeCount ?: null,
                'links' => $links,
            ];
        }
    }
    return $blocks;
}

function bm_ds_num(string $s): int {
    $fa = ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9'];
    $s = strtr($s, $fa);
    return preg_match('/\d+/', $s, $m) ? (int)$m[0] : 0;
}

function bm_ds_validate_candidate(array $movie, string $url): array {
    $res = bm_ds_http_get($url, 9);
    if (!$res['ok']) return ['ok' => false, 'score' => 0, 'url' => $url, 'error' => $res['error'] ?: ('HTTP ' . $res['status'])];
    $html = $res['body'];
    $info = bm_ds_extract_page_info($html, $res['url']);
    $score = 0;
    $reasons = [];
    $localImdb = strtolower(trim((string)($movie['imdb_code'] ?? '')));
    if ($localImdb !== '') {
        if (($info['imdb_code'] ?? '') === $localImdb) { $score += 75; $reasons[] = 'IMDb exact'; }
        if (!empty($info['poster']) && stripos((string)$info['poster'], $localImdb) !== false) { $score += 65; $reasons[] = 'poster filename'; }
        if (stripos($html, $localImdb) !== false) { $score += 30; $reasons[] = 'IMDb/poster exists in HTML'; }
    }
    $sim = max(
        bm_ds_similarity((string)($movie['title'] ?? ''), (string)($info['title'] ?? '')),
        bm_ds_similarity((string)($movie['title_fa'] ?? ''), (string)($info['title'] ?? ''))
    );
    if ($sim >= 70) { $score += 25; $reasons[] = 'title similarity ' . $sim . '%'; }
    elseif ($sim >= 50) { $score += 12; $reasons[] = 'title similarity ' . $sim . '%'; }
    $dlLinks = (int)($info['download_summary']['links'] ?? 0);
    if ($dlLinks > 0) { $score += 20; $reasons[] = 'downloads found'; }
    if (stripos(parse_url($url, PHP_URL_PATH) ?? '', '/series/') !== false) { $score += 10; $reasons[] = 'series URL'; }
    $score = min(100, $score);

    return [
        'ok' => true,
        'score' => $score,
        'confidence' => $score >= 80 ? 'high' : ($score >= 55 ? 'medium' : 'low'),
        'url' => $info['url'] ?: $url,
        'fetched_url' => $res['url'],
        'reasons' => $reasons,
        'remote' => $info,
        'error' => '',
    ];
}

function bm_ds_match_movie(array $movie): array {
    $candidates = bm_ds_candidate_urls_for_movie($movie);
    $tested = [];
    $best = null;
    foreach ($candidates as $url) {
        $r = bm_ds_validate_candidate($movie, $url);
        $tested[] = [
            'url' => $url,
            'score' => (int)($r['score'] ?? 0),
            'confidence' => (string)($r['confidence'] ?? 'none'),
            'error' => (string)($r['error'] ?? ''),
        ];
        if ($r['ok'] && (!$best || ($r['score'] ?? 0) > ($best['score'] ?? 0))) $best = $r;
        if ($best && ($best['score'] ?? 0) >= 90) break;
    }
    $matched = $best && ($best['score'] ?? 0) >= 55;
    $dbPreview = bm_ds_build_db_preview($movie, $matched ? $best : null);
    return [
        'local' => [
            'id' => (int)($movie['id'] ?? 0),
            'imdb_code' => (string)($movie['imdb_code'] ?? ''),
            'title' => (string)($movie['title'] ?? ''),
            'title_fa' => (string)($movie['title_fa'] ?? ''),
            'year' => (string)($movie['year'] ?? ''),
            'type' => (string)($movie['type'] ?? ''),
            'poster_guess' => !empty($movie['imdb_code']) ? ('posters/' . $movie['imdb_code'] . '.webp') : '',
        ],
        'matched' => $matched,
        'best' => $best,
        'db_preview' => $dbPreview,
        'tested' => $tested,
        'checked_at' => date('c'),
    ];
}

function bm_ds_load_existing_json(): array {
    $path = bm_ds_storage_path();
    if (!is_file($path)) return ['generated_at' => null, 'source' => BM_DS_BASE, 'items' => []];
    $data = json_decode((string)@file_get_contents($path), true);
    return is_array($data) ? $data : ['generated_at' => null, 'source' => BM_DS_BASE, 'items' => []];
}

function bm_ds_json_is_imdb_map(array $json): bool {
    if ($json === []) return true;
    foreach ($json as $k => $v) {
        if (!is_string($k) || !preg_match('/^tt\d{6,10}$/i', $k)) return false;
        if (is_string($v)) continue;
        if (!is_array($v)) return false;
        // Supported final compact forms:
        // "tt...": ["url1", "url2"]
        // "tt...": {"title":"...", "links":[...]}
        // "tt...": {"title":"...", "seasons":{"S01":{"E01":[...]}}}
        if (array_key_exists('links', $v) || array_key_exists('title', $v) || array_key_exists('seasons', $v)) {
            if (isset($v['links']) && !is_array($v['links']) && !is_string($v['links'])) return false;
            if (isset($v['seasons']) && !is_array($v['seasons'])) return false;
            continue;
        }
    }
    return true;
}

function bm_ds_title_from_item(array $it): string {
    $title = trim((string)($it['title'] ?? ''));
    if ($title === '') $title = trim((string)($it['local']['title'] ?? ''));
    if ($title === '') $title = trim((string)($it['db_preview']['movie']['title'] ?? ''));
    if ($title === '' && !empty($it['best']['remote']['title'])) {
        $title = trim((string)$it['best']['remote']['title']);
        $title = preg_replace('~^دانلود\s+سریال\s+~u', '', $title);
        $title = preg_replace('~^دانلود\s+~u', '', $title);
    }
    $title = html_entity_decode((string)$title, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $title = trim(preg_replace('~\s+~u', ' ', $title));
    return $title;
}

function bm_ds_norm_season_key($season, string $url = ''): string {
    $n = 0;
    if (is_numeric($season)) $n = (int)$season;
    elseif (is_string($season) && preg_match('/S?0*(\d{1,3})/i', $season, $m)) $n = (int)$m[1];
    if ($n <= 0 && $url !== '' && preg_match('/(?:\/|\.|_|-)S0*(\d{1,3})(?:\/|\.|_|-|E)/i', $url, $m)) $n = (int)$m[1];
    if ($n <= 0) return 'S00';
    return 'S' . str_pad((string)$n, 2, '0', STR_PAD_LEFT);
}

function bm_ds_norm_episode_key($episode, string $url = '', string $label = ''): string {
    $n = 0;
    if (is_numeric($episode)) $n = (int)$episode;
    elseif (is_string($episode) && preg_match('/E?0*(\d{1,3})/i', $episode, $m)) $n = (int)$m[1];
    if ($n <= 0 && $url !== '' && preg_match('/S\d{1,3}E0*(\d{1,3})/i', $url, $m)) $n = (int)$m[1];
    if ($n <= 0 && $label !== '' && preg_match('/قسمت\s*([0-9۰-۹٠-٩]+)/u', $label, $m)) $n = bm_ds_num($m[1]);
    if ($n <= 0) return 'E00';
    return 'E' . str_pad((string)$n, 2, '0', STR_PAD_LEFT);
}

function bm_ds_compact_push_url(array &$links, $url): void {
    $url = trim((string)$url);
    if ($url === '') return;
    if (!preg_match('~^https?://~i', $url)) return;
    $links[$url] = true;
}

function bm_ds_compact_add_record(array &$seasons, $url, $season = null, $episode = null, string $label = ''): void {
    $url = trim((string)$url);
    if ($url === '' || !preg_match('~^https?://~i', $url)) return;
    $sKey = bm_ds_norm_season_key($season, $url);
    $eKey = bm_ds_norm_episode_key($episode, $url, $label);
    if (!isset($seasons[$sKey]) || !is_array($seasons[$sKey])) $seasons[$sKey] = [];
    if (!isset($seasons[$sKey][$eKey]) || !is_array($seasons[$sKey][$eKey])) $seasons[$sKey][$eKey] = [];
    if (!in_array($url, $seasons[$sKey][$eKey], true)) $seasons[$sKey][$eKey][] = $url;
}

function bm_ds_compact_sort_seasons(array $seasons): array {
    uksort($seasons, 'strnatcasecmp');
    foreach ($seasons as $sKey => $episodes) {
        if (!is_array($episodes)) { unset($seasons[$sKey]); continue; }
        uksort($episodes, 'strnatcasecmp');
        foreach ($episodes as $eKey => $links) {
            $links = array_values(array_unique(array_filter(array_map('strval', is_array($links) ? $links : [$links]))));
            sort($links, SORT_NATURAL | SORT_FLAG_CASE);
            $episodes[$eKey] = $links;
        }
        $seasons[$sKey] = $episodes;
    }
    return $seasons;
}

function bm_ds_compact_flat_links_from_seasons(array $seasons): array {
    $out = [];
    foreach ($seasons as $episodes) {
        if (!is_array($episodes)) continue;
        foreach ($episodes as $links) {
            foreach ((array)$links as $url) bm_ds_compact_push_url($out, $url);
        }
    }
    return array_values(array_keys($out));
}

function bm_ds_compact_seasons_from_value($value): array {
    $seasons = [];
    if (is_string($value)) {
        bm_ds_compact_add_record($seasons, $value);
        return bm_ds_compact_sort_seasons($seasons);
    }
    if (!is_array($value)) return [];

    // Final schema: {"seasons":{"S01":{"E01":[...]}}}
    if (!empty($value['seasons']) && is_array($value['seasons'])) {
        foreach ($value['seasons'] as $sKey => $episodes) {
            if (!is_array($episodes)) continue;
            foreach ($episodes as $eKey => $links) {
                foreach ((array)$links as $ln) {
                    if (is_array($ln)) bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $ln['season'] ?? $sKey, $ln['episode'] ?? $eKey, (string)($ln['label'] ?? ''));
                    else bm_ds_compact_add_record($seasons, $ln, $sKey, $eKey);
                }
            }
        }
    }

    // Old compact schema: {"links":["url", ...]}
    if (!empty($value['links']) && is_array($value['links'])) {
        foreach ($value['links'] as $ln) {
            if (is_array($ln)) bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $ln['season'] ?? ($ln['season_int'] ?? null), $ln['episode'] ?? null, (string)($ln['label'] ?? ''));
            else bm_ds_compact_add_record($seasons, $ln);
        }
    } elseif (array_is_list($value)) {
        foreach ($value as $ln) {
            if (is_array($ln)) bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $ln['season'] ?? ($ln['season_int'] ?? null), $ln['episode'] ?? null, (string)($ln['label'] ?? ''));
            else bm_ds_compact_add_record($seasons, $ln);
        }
    }
    return bm_ds_compact_sort_seasons($seasons);
}

function bm_ds_compact_seasons_from_item(array $it): array {
    $seasons = [];

    if (!empty($it['seasons']) || !empty($it['links'])) {
        foreach (bm_ds_compact_seasons_from_value($it) as $sKey => $episodes) {
            foreach ($episodes as $eKey => $links) foreach ($links as $url) bm_ds_compact_add_record($seasons, $url, $sKey, $eKey);
        }
    }

    foreach (['all_links','softsub_links','dubbed_links'] as $k) {
        if (!empty($it['db_preview'][$k]) && is_array($it['db_preview'][$k])) {
            foreach ($it['db_preview'][$k] as $ln) {
                if (!is_array($ln)) continue;
                bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $ln['season'] ?? ($ln['season_int'] ?? null), $ln['episode'] ?? null, (string)($ln['label'] ?? ''));
            }
        }
    }

    if (!empty($it['best']['remote']['downloads']) && is_array($it['best']['remote']['downloads'])) {
        foreach ($it['best']['remote']['downloads'] as $block) {
            if (empty($block['links']) || !is_array($block['links'])) continue;
            $blockSeason = $block['season'] ?? null;
            foreach ($block['links'] as $ln) {
                if (!is_array($ln)) continue;
                bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $blockSeason, $ln['episode'] ?? null, (string)($ln['label'] ?? ''));
            }
        }
    }

    if (!empty($it['best']['remote']['sample_downloads']) && is_array($it['best']['remote']['sample_downloads'])) {
        foreach ($it['best']['remote']['sample_downloads'] as $block) {
            if (empty($block['links']) || !is_array($block['links'])) continue;
            $blockSeason = $block['season'] ?? null;
            foreach ($block['links'] as $ln) {
                if (!is_array($ln)) continue;
                bm_ds_compact_add_record($seasons, $ln['url'] ?? '', $blockSeason, $ln['episode'] ?? null, (string)($ln['label'] ?? ''));
            }
        }
    }

    return bm_ds_compact_sort_seasons($seasons);
}

function bm_ds_compact_map_from_json(array $json): array {
    $map = [];
    if (bm_ds_json_is_imdb_map($json)) {
        foreach ($json as $imdb => $value) {
            $imdb = strtolower((string)$imdb);
            if (!preg_match('/^tt\d{6,10}$/i', $imdb)) continue;
            $title = is_array($value) ? trim((string)($value['title'] ?? '')) : '';
            $seasons = bm_ds_compact_seasons_from_value($value);
            if ($seasons) $map[$imdb] = ['title' => $title, 'seasons' => $seasons];
        }
        ksort($map, SORT_NATURAL);
        return $map;
    }
    foreach (($json['items'] ?? []) as $it) {
        if (!is_array($it)) continue;
        $compact = bm_ds_compact_item($it);
        if (!$compact) continue;
        $key = $compact['imdb_code'];
        if (!isset($map[$key])) $map[$key] = ['title' => '', 'seasons' => []];
        if (empty($map[$key]['title']) && !empty($compact['title'])) $map[$key]['title'] = $compact['title'];
        $map[$key]['seasons'] = bm_ds_merge_seasons($map[$key]['seasons'], $compact['seasons']);
    }
    ksort($map, SORT_NATURAL);
    return $map;
}

function bm_ds_merge_seasons(array $oldSeasons, array $newSeasons): array {
    $merged = bm_ds_compact_sort_seasons($oldSeasons);
    foreach ($newSeasons as $sKey => $episodes) {
        foreach ((array)$episodes as $eKey => $links) {
            foreach ((array)$links as $url) bm_ds_compact_add_record($merged, $url, $sKey, $eKey);
        }
    }
    return bm_ds_compact_sort_seasons($merged);
}

function bm_ds_compact_items_array(array $json): array {
    $items = [];
    foreach (bm_ds_compact_map_from_json($json) as $imdb => $data) {
        $seasons = $data['seasons'] ?? [];
        $items[] = [
            'imdb_code' => $imdb,
            'title' => (string)($data['title'] ?? ''),
            'seasons' => $seasons,
            'links' => bm_ds_compact_flat_links_from_seasons($seasons),
        ];
    }
    return $items;
}

function bm_ds_compact_item_key(array $it): string {
    $imdb = strtolower(trim((string)($it['imdb_code'] ?? '')));
    if ($imdb === '') $imdb = strtolower(trim((string)($it['local']['imdb_code'] ?? '')));
    if ($imdb === '') $imdb = strtolower(trim((string)($it['db_preview']['movie']['imdb_code'] ?? '')));
    if ($imdb === '' && !empty($it['best']['remote']['imdb_code'])) $imdb = strtolower(trim((string)$it['best']['remote']['imdb_code']));
    return preg_match('/^tt\d{6,10}$/i', $imdb) ? strtolower($imdb) : '';
}

function bm_ds_compact_links_from_item(array $it): array {
    if (!empty($it['seasons']) && is_array($it['seasons'])) return bm_ds_compact_flat_links_from_seasons($it['seasons']);
    return bm_ds_compact_flat_links_from_seasons(bm_ds_compact_seasons_from_item($it));
}

function bm_ds_compact_link_count(array $it): int {
    if (!empty($it['seasons']) && is_array($it['seasons'])) return count(bm_ds_compact_flat_links_from_seasons($it['seasons']));
    if (!empty($it['links']) && is_array($it['links'])) return count($it['links']);
    return count(bm_ds_compact_links_from_item($it));
}

function bm_ds_compact_item(array $it): ?array {
    $imdb = bm_ds_compact_item_key($it);
    if ($imdb === '') return null;
    $seasons = bm_ds_compact_seasons_from_item($it);
    if (!$seasons) return null;
    return [
        'imdb_code' => $imdb,
        'title' => bm_ds_title_from_item($it),
        'seasons' => $seasons,
        'links' => bm_ds_compact_flat_links_from_seasons($seasons),
    ];
}

function bm_ds_merge_compact_items(array $oldItem, array $newItem): array {
    $imdb = bm_ds_compact_item_key($newItem) ?: bm_ds_compact_item_key($oldItem);
    $title = bm_ds_title_from_item($newItem);
    if ($title === '') $title = bm_ds_title_from_item($oldItem);
    $oldSeasons = bm_ds_compact_seasons_from_item($oldItem);
    $newSeasons = bm_ds_compact_seasons_from_item($newItem);
    $seasons = bm_ds_merge_seasons($oldSeasons, $newSeasons);
    return [
        'imdb_code' => $imdb,
        'title' => $title,
        'seasons' => $seasons,
        'links' => bm_ds_compact_flat_links_from_seasons($seasons),
    ];
}

function bm_ds_save_json(array $newItems, array $meta = []): array {
    $path = bm_ds_storage_path();
    bm_ds_ensure_storage_dir();
    $old = bm_ds_load_existing_json();

    $map = bm_ds_compact_map_from_json($old);
    foreach ($newItems as $it) {
        if (!is_array($it)) continue;
        $compact = bm_ds_compact_item($it);
        if (!$compact) continue;
        $key = $compact['imdb_code'];
        if (!isset($map[$key])) $map[$key] = ['title' => '', 'seasons' => []];
        if (empty($map[$key]['title']) && !empty($compact['title'])) $map[$key]['title'] = $compact['title'];
        $map[$key]['seasons'] = bm_ds_merge_seasons($map[$key]['seasons'] ?? [], $compact['seasons'] ?? []);
    }

    ksort($map, SORT_NATURAL);
    foreach ($map as $imdb => $data) {
        $map[$imdb]['seasons'] = bm_ds_compact_sort_seasons($data['seasons'] ?? []);
    }
    // Final readable schema: IMDb code => { title, seasons: { S01: { E01: [links] } } }.
    $encoded = json_encode($map, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    if ($encoded === false) {
        throw new RuntimeException('ساخت JSON ناموفق بود: ' . json_last_error_msg());
    }
    bm_ds_write_file_atomic($path, $encoded, 0644);
    return $map;
}

function bm_ds_error_result_for_movie(array $movie, string $message): array {
    return [
        'local' => [
            'id' => (int)($movie['id'] ?? 0),
            'imdb_code' => (string)($movie['imdb_code'] ?? ''),
            'title' => (string)($movie['title'] ?? ''),
            'title_fa' => (string)($movie['title_fa'] ?? ''),
            'year' => (string)($movie['year'] ?? ''),
            'type' => (string)($movie['type'] ?? ''),
            'poster_guess' => !empty($movie['imdb_code']) ? ('posters/' . $movie['imdb_code'] . '.webp') : '',
        ],
        'matched' => false,
        'best' => null,
        'db_preview' => bm_ds_build_db_preview($movie, null),
        'tested' => [],
        'error' => $message,
        'checked_at' => date('c'),
    ];
}


function bm_ds_fetch_local_series(PDO $pdo, int $limit = 20, int $offset = 0, string $scope = 'all'): array {
    $where = "(type IN ('tvSeries','tvMiniSeries','series') OR type LIKE '%Series%')";
    if ($scope === 'missing_links') {
        $where .= " AND NOT EXISTS (SELECT 1 FROM softsub_links sl WHERE sl.movie_id = movies.id) AND NOT EXISTS (SELECT 1 FROM dubbed_links dl WHERE dl.movie_id = movies.id)";
    }
    $sql = "SELECT id, imdb_code, title, title_fa, year, type FROM movies WHERE $where ORDER BY id DESC LIMIT " . max(1, min(50, $limit)) . " OFFSET " . max(0, $offset);
    $stmt = $pdo->query($sql);
    return $stmt ? ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []) : [];
}

function bm_ds_count_local_series(PDO $pdo, string $scope = 'all'): int {
    $where = "(type IN ('tvSeries','tvMiniSeries','series') OR type LIKE '%Series%')";
    if ($scope === 'missing_links') {
        $where .= " AND NOT EXISTS (SELECT 1 FROM softsub_links sl WHERE sl.movie_id = movies.id) AND NOT EXISTS (SELECT 1 FROM dubbed_links dl WHERE dl.movie_id = movies.id)";
    }
    return (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE $where")->fetchColumn();
}
