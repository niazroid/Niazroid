<?php
if (defined('BM_API5_ADAPTER_LOADED')) return;
define('BM_API5_ADAPTER_LOADED', true);

if (!function_exists('bm_api5_poster_proxy_url')) {
    function bm_api5_poster_proxy_url(string $poster): string {
        $poster = trim($poster);
        if ($poster === '' || !preg_match('~^https?://~i', $poster)) return '';
        if (function_exists('bm_poster_wrap_url')) {
            return bm_poster_wrap_url($poster, ['type' => 'movie']);
        }
        $token = rtrim(strtr(base64_encode($poster), '+/', '-_'), '=');
        return '/api5_image.php?u=' . rawurlencode($token);
    }
}

if (!function_exists('bm_api5_internal_detail_url')) {
    function bm_api5_internal_detail_url(array $item): string {
        $slug = trim((string)($item['slug'] ?? $item['detail_id'] ?? $item['id'] ?? ''));
        $source = trim((string)($item['source_url'] ?? $item['url'] ?? ''));

        if ($slug === '' && $source !== '') {
            $path = trim((string)(parse_url($source, PHP_URL_PATH) ?? ''), '/');
            if ($path !== '') {
                $parts = array_values(array_filter(explode('/', $path), static fn($v) => $v !== ''));
                if ($parts) $slug = (string)end($parts);
            }
        }

        if ($slug === '') return '#';

        $type = (($item['type'] ?? '') === 'series' || stripos($source, '/series/') !== false)
            ? 'series'
            : 'movie';

        return '/movie/arc2-' . rawurlencode($slug) . '?type=' . rawurlencode($type);
    }
}

if (!function_exists('bm_api5_normalize_item')) {
    function bm_api5_normalize_item(array $item): array {
        $slug = trim((string)($item['slug'] ?? $item['id'] ?? ''));
        $title = trim((string)($item['title'] ?? ''));
        $titleFa = trim((string)($item['title_fa'] ?? $title));
        $imdb = trim((string)($item['imdb_id'] ?? $item['imdb_code'] ?? ''));
        $normalized = [
            'id' => $slug,
            'slug' => $slug,
            'detail_id' => $slug,
            'title' => $title,
            'title_fa' => $titleFa !== '' ? $titleFa : $title,
            'title_en' => trim((string)($item['title_en'] ?? '')),
            'year' => (string)($item['year'] ?? ''),
            'poster' => $item['poster'] ?? '',
            'poster_proxy' => bm_api5_poster_proxy_url((string)($item['poster'] ?? '')),
            'rating' => $item['rating'] ?? 0,
            'imdb_rate' => $item['rating'] ?? 0,
            'imdb_id' => $imdb,
            'imdb_code' => $imdb,
            'type' => (($item['type'] ?? '') === 'series') ? 'series' : 'movie',
            'genres' => is_array($item['genres'] ?? null) ? $item['genres'] : [],
            'countries' => is_array($item['countries'] ?? null) ? $item['countries'] : [],
            'language' => (string)($item['language'] ?? ''),
            'source_url' => (string)($item['source_url'] ?? $item['url'] ?? ''),
            'url' => (string)($item['url'] ?? $item['source_url'] ?? ''),
            'has_dubbed' => !empty($item['has_dubbed']),
            'has_subtitle' => !empty($item['has_subtitle']),
            'quality' => (string)($item['quality'] ?? ''),
            'source_archive' => 'local',
            'source_kind' => 'api5',
            'archive' => 2,
        ];
        $normalized['bankmovie_url'] = bm_api5_internal_detail_url($normalized);
        $normalized['detail_url'] = $normalized['bankmovie_url'];
        return $normalized;
    }
}

if (!function_exists('bm_api5_normalize_listing')) {
    function bm_api5_normalize_listing(array $result): array {
        $items = [];
        foreach (($result['items'] ?? $result['movies'] ?? []) as $item) {
            if (is_array($item)) $items[] = bm_api5_normalize_item($item);
        }
        $result['items'] = $items;
        $result['movies'] = $items;
        $result['count'] = count($items);
        $result['archive'] = 2;
        $result['source'] = 'api5_serialblog';
        return $result;
    }
}

if (!function_exists('bm_api5_normalize_detail')) {
    function bm_api5_normalize_detail(array $detail): array {
        $movie = is_array($detail['movie'] ?? null) ? $detail['movie'] : (is_array($detail['item'] ?? null) ? $detail['item'] : []);
        $flat = bm_api5_normalize_item($movie);
        foreach ($movie as $k => $v) {
            if (!array_key_exists($k, $flat) || $flat[$k] === '' || $flat[$k] === []) $flat[$k] = $v;
        }
        $flat['downloads'] = is_array($detail['downloads'] ?? null) ? $detail['downloads'] : [];
        $flat['download_groups'] = is_array($detail['download_groups'] ?? null) ? $detail['download_groups'] : [];
        $flat['seasons'] = is_array($detail['seasons'] ?? null) ? $detail['seasons'] : [];
        $flat['related'] = [];
        foreach (($detail['related'] ?? $movie['related'] ?? []) as $rel) {
            if (is_array($rel)) $flat['related'][] = bm_api5_normalize_item($rel);
        }
        $flat['has_downloads'] = !empty($detail['has_downloads']) || !empty($flat['downloads']);
        $flat['status'] = 'success';
        $flat['archive'] = 2;
        $flat['source_kind'] = 'api5';
        return $flat;
    }
}

if (!function_exists('bm_api5_get_details')) {
    function bm_api5_get_details(string $identifier, ?string $type = null): array {
        if (!function_exists('serialblog_get_details')) require_once __DIR__ . '/api5_lib.php';
        return bm_api5_normalize_detail(serialblog_get_details($identifier, (string)$type));
    }
}
