<?php
/**
 * BankMovie weekly release schedule.
 * Public renderer + small storage helpers shared with the admin page.
 */
declare(strict_types=1);

if (!function_exists('bm_weekly_schedule_days')) {
    function bm_weekly_schedule_days(): array
    {
        return [
            'saturday'  => ['fa' => 'شنبه', 'en' => 'Saturday'],
            'sunday'    => ['fa' => 'یکشنبه', 'en' => 'Sunday'],
            'monday'    => ['fa' => 'دوشنبه', 'en' => 'Monday'],
            'tuesday'   => ['fa' => 'سه‌شنبه', 'en' => 'Tuesday'],
            'wednesday' => ['fa' => 'چهارشنبه', 'en' => 'Wednesday'],
            'thursday'  => ['fa' => 'پنج‌شنبه', 'en' => 'Thursday'],
            'friday'    => ['fa' => 'جمعه', 'en' => 'Friday'],
        ];
    }
}

if (!function_exists('bm_weekly_schedule_today_key')) {
    function bm_weekly_schedule_today_key(): string
    {
        return [
            0 => 'sunday',
            1 => 'monday',
            2 => 'tuesday',
            3 => 'wednesday',
            4 => 'thursday',
            5 => 'friday',
            6 => 'saturday',
        ][(int)date('w')] ?? 'saturday';
    }
}

if (!function_exists('bm_weekly_schedule_marker')) {
    function bm_weekly_schedule_marker(): string
    {
        if (function_exists('bm_security_private_path')) {
            return bm_security_private_path('weekly_schedule_v1.installed');
        }
        return rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_weekly_schedule_v1.installed';
    }
}

if (!function_exists('bm_weekly_schedule_ensure')) {
    function bm_weekly_schedule_ensure(PDO $pdo): bool
    {
        static $done = null;
        if (is_bool($done)) return $done;

        $marker = bm_weekly_schedule_marker();
        if (is_file($marker) && (time() - (int)@filemtime($marker)) < 86400) {
            return $done = true;
        }

        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS weekly_schedule_settings (
                id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                is_enabled TINYINT(1) NOT NULL DEFAULT 1,
                title_fa VARCHAR(120) NOT NULL DEFAULT 'جدول پخش هفتگی',
                title_en VARCHAR(120) NOT NULL DEFAULT 'Weekly Release Schedule',
                subtitle_fa VARCHAR(255) NULL,
                subtitle_en VARCHAR(255) NULL,
                show_empty_days TINYINT(1) NOT NULL DEFAULT 1,
                default_day_mode VARCHAR(20) NOT NULL DEFAULT 'today',
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            $pdo->exec("CREATE TABLE IF NOT EXISTS weekly_schedule_items (
                id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
                day_key VARCHAR(16) NOT NULL,
                source_archive VARCHAR(20) NOT NULL DEFAULT 'archive2',
                source_id VARCHAR(255) NOT NULL DEFAULT '',
                source_key CHAR(40) NOT NULL,
                title VARCHAR(255) NOT NULL,
                title_fa VARCHAR(255) NULL,
                poster_url TEXT NULL,
                target_url VARCHAR(700) NOT NULL,
                media_type VARCHAR(30) NOT NULL DEFAULT 'series',
                release_year VARCHAR(12) NULL,
                episode_label VARCHAR(120) NULL,
                item_order INT NOT NULL DEFAULT 0,
                is_active TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_weekly_day_source (day_key, source_archive, source_key),
                KEY idx_weekly_active_day (is_active, day_key, item_order),
                KEY idx_weekly_archive (source_archive)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            $stmt = $pdo->prepare("INSERT IGNORE INTO weekly_schedule_settings
                (id, is_enabled, title_fa, title_en, subtitle_fa, subtitle_en, show_empty_days, default_day_mode)
                VALUES (1, 1, ?, ?, ?, ?, 1, 'today')");
            $stmt->execute([
                'جدول پخش هفتگی',
                'Weekly Release Schedule',
                'برنامه انتشار فیلم‌ها و سریال‌های منتخب بانک مووی',
                'BankMovie selected weekly releases',
            ]);

            $dir = dirname($marker);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            @file_put_contents($marker, (string)time(), LOCK_EX);
            @chmod($marker, 0600);
            return $done = true;
        } catch (Throwable $e) {
            error_log('Weekly schedule install error: ' . $e->getMessage());
            return $done = false;
        }
    }
}

if (!function_exists('bm_weekly_schedule_settings')) {
    function bm_weekly_schedule_settings(PDO $pdo): array
    {
        $defaults = [
            'is_enabled' => 1,
            'title_fa' => 'جدول پخش هفتگی',
            'title_en' => 'Weekly Release Schedule',
            'subtitle_fa' => 'برنامه انتشار فیلم‌ها و سریال‌های منتخب بانک مووی',
            'subtitle_en' => 'BankMovie selected weekly releases',
            'show_empty_days' => 1,
            'default_day_mode' => 'today',
        ];
        if (!bm_weekly_schedule_ensure($pdo)) return $defaults;
        try {
            $row = $pdo->query('SELECT * FROM weekly_schedule_settings WHERE id = 1 LIMIT 1')->fetch(PDO::FETCH_ASSOC);
            return is_array($row) ? array_merge($defaults, $row) : $defaults;
        } catch (Throwable $e) {
            error_log('Weekly schedule settings read error: ' . $e->getMessage());
            return $defaults;
        }
    }
}

if (!function_exists('bm_weekly_schedule_items')) {
    function bm_weekly_schedule_items(PDO $pdo, bool $onlyActive = true): array
    {
        if (!bm_weekly_schedule_ensure($pdo)) return [];
        try {
            $sql = 'SELECT * FROM weekly_schedule_items';
            if ($onlyActive) $sql .= ' WHERE is_active = 1';
            $sql .= " ORDER BY FIELD(day_key,'saturday','sunday','monday','tuesday','wednesday','thursday','friday'), item_order ASC, id ASC";
            return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            error_log('Weekly schedule items read error: ' . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('bm_weekly_schedule_archive_label')) {
    function bm_weekly_schedule_archive_label(string $source, string $lang = 'fa'): string
    {
        $labels = [
            'archive1' => ['fa' => 'آرشیو ۱', 'en' => 'Archive 1'],
            'archive2' => ['fa' => 'آرشیو ۲', 'en' => 'Archive 2'],
            'archive3' => ['fa' => 'آرشیو ۳', 'en' => 'Archive 3'],
            'archive4' => ['fa' => 'آرشیو ۴', 'en' => 'Archive 4'],
            'manual'   => ['fa' => 'اختصاصی', 'en' => 'Custom'],
        ];
        return $labels[$source][$lang === 'en' ? 'en' : 'fa'] ?? $source;
    }
}

if (!function_exists('bm_weekly_schedule_render')) {
    function bm_weekly_schedule_render(PDO $pdo, string $lang = 'fa'): void
    {
        $lang = $lang === 'en' ? 'en' : 'fa';
        $settings = bm_weekly_schedule_settings($pdo);
        if (empty($settings['is_enabled'])) return;

        $items = bm_weekly_schedule_items($pdo, true);
        if (!$items) return;

        $days = bm_weekly_schedule_days();
        $grouped = array_fill_keys(array_keys($days), []);
        foreach ($items as $item) {
            $day = (string)($item['day_key'] ?? '');
            if (isset($grouped[$day])) $grouped[$day][] = $item;
        }

        if (empty($settings['show_empty_days'])) {
            $days = array_filter($days, static fn($def, $key) => !empty($grouped[$key]), ARRAY_FILTER_USE_BOTH);
        }
        if (!$days) return;

        $today = bm_weekly_schedule_today_key();
        $default = ($settings['default_day_mode'] ?? 'today') === 'today' && isset($days[$today]) && !empty($grouped[$today])
            ? $today
            : (string)array_key_first(array_filter($grouped, static fn($rows, $key) => isset($days[$key]) && !empty($rows), ARRAY_FILTER_USE_BOTH));
        if ($default === '') $default = (string)array_key_first($days);

        $e = static fn($value): string => htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
        $title = trim((string)($settings[$lang === 'fa' ? 'title_fa' : 'title_en'] ?? ''));
        $subtitle = trim((string)($settings[$lang === 'fa' ? 'subtitle_fa' : 'subtitle_en'] ?? ''));
        ?>
<section class="bm-weekly-schedule" id="weeklySchedule" data-default-day="<?= $e($default) ?>" aria-label="<?= $e($title) ?>">
    <div class="bm-weekly-shell">
        <div class="bm-weekly-head">
            <div class="bm-weekly-heading">
                <span class="bm-weekly-icon" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v4M17 3v4M3 10h18"/><path d="m9 15 2 2 4-4"/></svg></span>
                <span><strong><?= $e($title) ?></strong><?php if ($subtitle !== ''): ?><small><?= $e($subtitle) ?></small><?php endif; ?></span>
            </div>
            <div class="bm-weekly-tabs" role="tablist" aria-label="<?= $lang === 'fa' ? 'روزهای هفته' : 'Weekdays' ?>">
                <?php foreach ($days as $key => $def): ?>
                <button type="button" class="bm-weekly-tab<?= $key === $default ? ' is-active' : '' ?><?= $key === $today ? ' is-today' : '' ?>" data-weekly-day="<?= $e($key) ?>" role="tab" aria-selected="<?= $key === $default ? 'true' : 'false' ?>">
                    <?= $e($def[$lang]) ?><?php if ($key === $today): ?><i><?= $lang === 'fa' ? 'امروز' : 'Today' ?></i><?php endif; ?>
                </button>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="bm-weekly-panels">
            <?php foreach ($days as $key => $def): $rows = $grouped[$key] ?? []; ?>
            <div class="bm-weekly-panel<?= $key === $default ? ' is-active' : '' ?>" data-weekly-panel="<?= $e($key) ?>" role="tabpanel" <?= $key === $default ? '' : 'hidden' ?>>
                <?php if ($rows): ?>
                <div class="bm-weekly-list">
                    <?php foreach ($rows as $row):
                        $displayTitle = trim((string)(($lang === 'fa' ? ($row['title_fa'] ?? '') : '') ?: ($row['title'] ?? '')));
                        $target = trim((string)($row['target_url'] ?? '#')) ?: '#';
                        $poster = trim((string)($row['poster_url'] ?? ''));
                        if ($poster !== '' && function_exists('bm_poster_wrap_url')) {
                            $poster = bm_poster_wrap_url($poster, [
                                'type' => (string)($row['media_type'] ?? 'series'),
                                'title' => (string)($row['title'] ?? $displayTitle),
                                'title_fa' => (string)($row['title_fa'] ?? ''),
                                'year' => (string)($row['release_year'] ?? ''),
                            ]);
                        }
                        $episode = trim((string)($row['episode_label'] ?? ''));
                        $year = trim((string)($row['release_year'] ?? ''));
                    ?>
                    <a class="bm-weekly-card" href="<?= $e($target) ?>">
                        <span class="bm-weekly-poster">
                            <?php if ($poster !== ''): ?><img src="<?= $e($poster) ?>" alt="" loading="lazy" decoding="async" onerror="this.style.display='none';this.parentElement.classList.add('is-empty')"><?php endif; ?>
                            <span class="bm-weekly-poster-fallback" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="m8 15 2.5-3 2 2 2.5-3 3 4"/><circle cx="9" cy="9" r="1"/></svg></span>
                        </span>
                        <span class="bm-weekly-copy">
                            <strong><bdi dir="auto"><?= $e($displayTitle) ?></bdi></strong>
                            <?php if ($year !== ''): ?><span class="bm-weekly-meta"><i><?= $e($year) ?></i></span><?php endif; ?>
                            <?php if ($episode !== ''): ?><small><?= $e($episode) ?></small><?php endif; ?>
                        </span>
                        <span class="bm-weekly-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M13 6l6 6-6 6"/></svg></span>
                    </a>
                    <?php endforeach; ?>
                </div>
                <?php else: ?>
                <div class="bm-weekly-empty"><span>—</span><?= $lang === 'fa' ? 'برای این روز هنوز عنوانی ثبت نشده است.' : 'Nothing scheduled for this day yet.' ?></div>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<style id="bm-weekly-schedule-style">
.bm-weekly-schedule{padding:20px 16px 8px;direction:rtl}.bm-weekly-shell{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.075);border-radius:26px;background:linear-gradient(145deg,rgba(24,29,40,.96),rgba(16,20,29,.98));box-shadow:0 22px 70px rgba(0,0,0,.24),inset 0 1px 0 rgba(255,255,255,.04)}.bm-weekly-shell:before{content:"";position:absolute;inset:-120px auto auto -80px;width:320px;height:260px;background:radial-gradient(circle,rgba(var(--accent-rgb),.16),transparent 68%);pointer-events:none}.bm-weekly-head{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:22px;padding:20px 22px 17px;border-bottom:1px solid rgba(255,255,255,.07)}.bm-weekly-heading{display:flex;align-items:center;gap:12px;min-width:max-content}.bm-weekly-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:14px;color:#fff;background:linear-gradient(145deg,var(--accent),rgba(var(--accent-rgb),.55));box-shadow:0 10px 28px rgba(var(--accent-rgb),.24)}.bm-weekly-icon svg{width:21px;height:21px}.bm-weekly-heading strong{display:block;font-size:16px;font-weight:950;letter-spacing:-.02em}.bm-weekly-heading small{display:block;margin-top:4px;color:rgba(255,255,255,.48);font-size:9px;font-weight:650}.bm-weekly-tabs{display:flex;align-items:center;gap:6px;overflow-x:auto;scrollbar-width:none;padding:2px;scroll-padding-inline:14px;overscroll-behavior-inline:contain;-webkit-overflow-scrolling:touch}.bm-weekly-tabs::-webkit-scrollbar{display:none}.bm-weekly-tab{position:relative;flex:0 0 auto;min-height:36px;padding:0 13px;border:1px solid transparent;border-radius:11px;background:transparent;color:rgba(255,255,255,.62);font:850 10px inherit;cursor:pointer;transition:background .22s,border-color .22s,color .22s,transform .22s}.bm-weekly-tab:hover{color:#fff;background:rgba(255,255,255,.055)}.bm-weekly-tab.is-active{color:#fff;border-color:rgba(var(--accent-rgb),.34);background:linear-gradient(145deg,rgba(var(--accent-rgb),.92),rgba(var(--accent-rgb),.58));box-shadow:0 8px 22px rgba(var(--accent-rgb),.18)}.bm-weekly-tab i{position:absolute;top:-7px;left:50%;transform:translateX(-50%);padding:2px 5px;border-radius:999px;background:#fff;color:#10131c;font-style:normal;font-size:6px;font-weight:950;opacity:0}.bm-weekly-tab.is-today:not(.is-active) i{opacity:.82}.bm-weekly-panels{position:relative;padding:18px 20px 21px}.bm-weekly-panel[hidden]{display:none!important}.bm-weekly-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(215px,1fr));gap:11px}.bm-weekly-card{position:relative;min-width:0;display:flex;align-items:center;gap:12px;min-height:96px;padding:10px 12px;border:1px solid rgba(255,255,255,.055);border-radius:18px;background:rgba(4,6,11,.28);color:#fff;text-decoration:none;overflow:hidden;transition:transform .22s,border-color .22s,background .22s,box-shadow .22s}.bm-weekly-card:hover{transform:translateY(-3px);border-color:rgba(var(--accent-rgb),.28);background:rgba(var(--accent-rgb),.055);box-shadow:0 15px 35px rgba(0,0,0,.22)}.bm-weekly-poster{position:relative;flex:0 0 58px;width:58px;height:76px;border-radius:12px;overflow:hidden;background:linear-gradient(145deg,#252b39,#10131b);box-shadow:0 8px 18px rgba(0,0,0,.22)}.bm-weekly-poster img{position:relative;z-index:2;width:100%;height:100%;object-fit:cover}.bm-weekly-poster-fallback{position:absolute;inset:0;display:grid;place-items:center;color:rgba(255,255,255,.22)}.bm-weekly-poster-fallback svg{width:25px;height:25px}.bm-weekly-copy{display:block;min-width:0;flex:1}.bm-weekly-copy strong{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11.5px;font-weight:900;line-height:1.7}.bm-weekly-meta{display:flex;align-items:center;gap:5px;margin-top:5px;overflow:hidden;white-space:nowrap}.bm-weekly-meta i{padding:3px 6px;border-radius:999px;background:rgba(255,255,255,.055);color:rgba(255,255,255,.48);font-style:normal;font-size:7.5px;font-weight:750}.bm-weekly-copy small{display:block;margin-top:7px;color:rgba(255,255,255,.68);font-size:8.5px;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.bm-weekly-arrow{flex:0 0 25px;width:25px;height:25px;display:grid;place-items:center;border-radius:50%;color:rgba(255,255,255,.34);background:rgba(255,255,255,.04)}.bm-weekly-arrow svg{width:13px;height:13px}.bm-weekly-empty{min-height:105px;display:flex;align-items:center;justify-content:center;gap:9px;border:1px dashed rgba(255,255,255,.08);border-radius:18px;color:rgba(255,255,255,.35);font-size:10px}.bm-weekly-empty span{width:24px;height:24px;display:grid;place-items:center;border-radius:50%;background:rgba(255,255,255,.045)}
@media(max-width:900px){.bm-weekly-head{align-items:flex-start;flex-direction:column}.bm-weekly-tabs{width:100%}.bm-weekly-list{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:620px){.bm-weekly-schedule{padding:14px 10px 6px}.bm-weekly-shell{border-radius:22px}.bm-weekly-head{padding:16px 14px 13px;gap:14px}.bm-weekly-heading{align-items:flex-start}.bm-weekly-icon{width:38px;height:38px;border-radius:12px}.bm-weekly-heading strong{font-size:14px}.bm-weekly-heading small{font-size:8px;line-height:1.7}.bm-weekly-tabs{direction:ltr;flex-direction:row-reverse;margin-inline:-2px;width:calc(100% + 4px);padding:7px 12px 4px;scroll-snap-type:x proximity;scroll-padding-inline:20px}.bm-weekly-tab{direction:rtl;scroll-snap-align:center;min-width:76px;min-height:36px;padding-inline:12px;white-space:nowrap}.bm-weekly-panels{padding:12px}.bm-weekly-list{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;overflow:visible;padding:0}.bm-weekly-card{display:grid;grid-template-columns:46px minmax(0,1fr);grid-template-areas:"poster copy";align-items:center;gap:9px;min-height:82px;padding:8px;border-radius:15px}.bm-weekly-poster{grid-area:poster;flex:none;width:46px;height:64px;border-radius:10px}.bm-weekly-copy{grid-area:copy}.bm-weekly-copy strong{font-size:9.8px;line-height:1.55;white-space:normal;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2}.bm-weekly-meta{gap:4px;margin-top:4px}.bm-weekly-meta i{padding:2px 5px;font-size:6.8px}.bm-weekly-copy small{margin-top:5px;font-size:7.6px}.bm-weekly-arrow{display:none}}
@media(max-width:360px){.bm-weekly-panels{padding:10px}.bm-weekly-list{gap:7px}.bm-weekly-card{grid-template-columns:42px minmax(0,1fr);gap:7px;padding:7px}.bm-weekly-poster{width:42px;height:59px}.bm-weekly-copy strong{font-size:9.2px}.bm-weekly-meta i{font-size:6.3px}}
/* V14861964: show all seven days on phones instead of hiding the latter days in a horizontal rail. */
@media(max-width:620px){
  .bm-weekly-tabs{
    display:grid!important;
    grid-template-columns:repeat(4,minmax(0,1fr))!important;
    direction:rtl!important;
    flex-direction:initial!important;
    width:100%!important;
    margin:0!important;
    padding:5px 0 1px!important;
    gap:7px!important;
    overflow:visible!important;
    scroll-snap-type:none!important;
    -webkit-mask-image:none!important;
    mask-image:none!important;
  }
  .bm-weekly-tab{
    width:100%!important;
    min-width:0!important;
    min-height:36px!important;
    padding:0 5px!important;
    font-size:9px!important;
    white-space:nowrap!important;
    scroll-snap-align:none!important;
  }
}
@media(max-width:370px){
  .bm-weekly-tabs{gap:5px!important}
  .bm-weekly-tab{font-size:8.2px!important;padding-inline:3px!important}
}
</style>
<script id="bm-weekly-schedule-script">
(function(){
  const root=document.getElementById('weeklySchedule'); if(!root||root.dataset.ready==='1')return; root.dataset.ready='1';
  const scroller=root.querySelector('.bm-weekly-tabs');
  const tabs=[...root.querySelectorAll('[data-weekly-day]')], panels=[...root.querySelectorAll('[data-weekly-panel]')];
  function keepVisible(tab,behavior){
    if(!tab||!scroller)return;
    const mobile=window.matchMedia('(max-width:900px)').matches;
    if(!mobile)return;
    // Horizontal only: never let the weekly tabs move the document itself.
    requestAnimationFrame(()=>{
      const max=Math.max(0,scroller.scrollWidth-scroller.clientWidth);
      const target=tab.offsetLeft-(scroller.clientWidth-tab.offsetWidth)/2;
      const left=Math.max(0,Math.min(max,target));
      try{scroller.scrollTo({left:left,behavior:behavior||'smooth'});}catch(e){scroller.scrollLeft=left;}
    });
  }
  function show(day,behavior='smooth'){
    let active=null;
    tabs.forEach(t=>{const on=t.dataset.weeklyDay===day;t.classList.toggle('is-active',on);t.setAttribute('aria-selected',on?'true':'false');if(on)active=t});
    panels.forEach(p=>{const on=p.dataset.weeklyPanel===day;p.classList.toggle('is-active',on);p.hidden=!on});
    keepVisible(active,behavior);
  }
  tabs.forEach(t=>t.addEventListener('click',()=>show(t.dataset.weeklyDay)));
  const initial=tabs.find(t=>t.classList.contains('is-active'))||tabs[0];
  if(initial){requestAnimationFrame(()=>requestAnimationFrame(()=>keepVisible(initial,'auto')));}
  let resizeTimer=0;window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>keepVisible(tabs.find(t=>t.classList.contains('is-active')),'auto'),120)},{passive:true});
})(document);
</script>
        <?php
    }
}
