<?php
/**
 * api5_lib.php — standalone SerialBlog parser library.
 * This version is independent from BankMovie site files and has no archive-control dependency.
 * It extracts public listing/detail metadata and returns JSON-compatible arrays.
 */
if (defined('SERIALBLOG_API5_LIB_LOADED')) {
    return;
}
define('SERIALBLOG_API5_LIB_LOADED', true);

if (!defined('SERIALBLOG_BASE_URL')) {
    define('SERIALBLOG_BASE_URL', function_exists('bm_archive_source_base_url')
        ? bm_archive_source_base_url('archive2', 'https://serialblog1.top')
        : 'https://serialblog1.top');
}
if (!defined('SERIALBLOG_HTTP_TIMEOUT')) {
    define('SERIALBLOG_HTTP_TIMEOUT', 25);
}

function serialblog_clean_text($text) {
    $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = strip_tags($text);
    $text = preg_replace('/\x{200c}|\x{200f}|\x{200e}/u', ' ', $text);
    $text = preg_replace('/\s+/u', ' ', $text);
    return trim($text);
}


function serialblog_clean_display_title($title, $type = '') {
    $title = serialblog_clean_text($title);
    if ($title === '') return '';

    $title = preg_replace('/\s*(?:[-–—|]\s*)?سریال\s*بلاگ.*$/u', '', $title);
    $title = preg_replace('/^\s*دانلود\s+(?:فیلم|سریال)\s*/u', '', $title);
    $title = preg_replace('/\(\s*\*?کیفیت[^)]*\)/u', '', $title);

    $parts = preg_split('/\s*(?:–|—|\|)\s*/u', $title);
    $cleanParts = [];
    foreach ($parts as $part) {
        $part = preg_replace(
            '/[،,]?\s*(?:بدون سانسور|با دوبله(?: فارسی)?|دوبله(?: فارسی)?|با زیرنویس(?: فارسی)?|زیرنویس(?: فارسی)?|کاملاً? رایگان|کاملا رایگان|رایگان|کامل|با همه کیفیت(?:‌|\s)?ها|کیفیت پرده|نسخه پرده(?:‌|\s)?ای|نسخه کامل|با لینک مستقیم)/u',
            ' ',
            $part
        );
        $part = preg_replace('/\s+/u', ' ', $part);
        $part = preg_replace('/(?:\s+و)+\s*$/u', '', $part);
        $part = preg_replace('/^[\s،,\-–—|]+|[\s،,\-–—|]+$/u', '', $part);
        if ($part !== '' && $part !== 'و') {
            $cleanParts[] = $part;
        }
    }

    $cleanParts = array_values(array_unique($cleanParts));
    $clean = implode(' – ', array_slice($cleanParts, 0, 2));
    $clean = preg_replace('/\s+/u', ' ', $clean);
    return trim($clean) !== '' ? trim($clean) : trim($title);
}

function serialblog_abs_url($url) {
    $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '') {
        return '';
    }
    if (preg_match('~^https?://~i', $url)) {
        return $url;
    }
    if (strpos($url, '//') === 0) {
        return 'https:' . $url;
    }
    if ($url[0] === '/') {
        return rtrim(SERIALBLOG_BASE_URL, '/') . $url;
    }
    return rtrim(SERIALBLOG_BASE_URL, '/') . '/' . ltrim($url, '/');
}

function serialblog_slug_from_url($url) {
    $url = html_entity_decode((string)$url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $parts = parse_url($url);
    $path = trim((string)($parts['path'] ?? $url), '/');
    if ($path === '') {
        return '';
    }
    $bits = explode('/', $path);
    $last = '';
    foreach ($bits as $bit) {
        if ($bit !== '') {
            $last = $bit;
        }
    }
    return $last;
}

function serialblog_type_from_url($url, $title = '') {
    $u = strtolower((string)$url);
    $t = serialblog_clean_text($title);
    if (strpos($u, '/series/') !== false || mb_strpos($t, 'سریال') !== false) {
        return 'series';
    }
    return 'movie';
}

function serialblog_detail_url($identifier, $type = '') {
    $identifier = html_entity_decode(trim((string)$identifier), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($identifier === '') {
        return SERIALBLOG_BASE_URL . '/';
    }
    if (preg_match('~^https?://~i', $identifier)) {
        $parts = @parse_url($identifier);
        $baseHost = strtolower((string)(parse_url(SERIALBLOG_BASE_URL, PHP_URL_HOST) ?: ''));
        $incomingHost = strtolower((string)($parts['host'] ?? ''));
        $allowedHosts = array_filter([$baseHost, 'serialblog1.top', 'www.serialblog1.top']);
        if (str_starts_with($baseHost, 'www.')) $allowedHosts[] = substr($baseHost, 4);
        elseif ($baseHost !== '') $allowedHosts[] = 'www.' . $baseHost;
        if (!in_array($incomingHost, array_values(array_unique($allowedHosts)), true)) {
            throw new Exception('Source detail URL is not allowed.');
        }
        $url = rtrim(SERIALBLOG_BASE_URL, '/') . '/' . ltrim((string)($parts['path'] ?? ''), '/');
        if (!empty($parts['query'])) $url .= '?' . $parts['query'];
        return $url;
    }

    $identifier = trim($identifier, '/');
    if (strpos($identifier, 'series/') === 0) {
        return rtrim(SERIALBLOG_BASE_URL, '/') . '/' . $identifier . '/';
    }
    if ($type === 'series') {
        return rtrim(SERIALBLOG_BASE_URL, '/') . '/series/' . rawurlencode($identifier) . '/';
    }
    return rtrim(SERIALBLOG_BASE_URL, '/') . '/' . rawurlencode($identifier) . '/';
}

function serialblog_internal_proxy_url($url) {
    $url = trim((string)$url);
    if ($url === '') {
        return $url;
    }

    $parts = parse_url($url);
    $base = parse_url(SERIALBLOG_BASE_URL);

    $originHost = strtolower((string)($parts['host'] ?? ''));
    $baseHost = strtolower((string)($base['host'] ?? ''));

    // Only proxy SerialBlog-origin requests. External poster/CDN URLs are untouched.
    if ($originHost === '' || $baseHost === '' || $originHost !== $baseHost) {
        return $url;
    }

    $path = (string)($parts['path'] ?? '/');
    if ($path === '') {
        $path = '/';
    }

    $query = isset($parts['query']) && $parts['query'] !== ''
        ? ('?' . $parts['query'])
        : '';

    $https = (!empty($_SERVER['HTTPS']) && strtolower((string)$_SERVER['HTTPS']) !== 'off');
    $scheme = $https ? 'https' : 'http';

    $host = trim((string)($_SERVER['HTTP_HOST'] ?? 'bankmovie.top'));
    if ($host === '') {
        $host = 'bankmovie.top';
    }

    $payload = $path . $query;

    return $scheme . '://' . $host .
        '/api5_internal_proxy_v95.php?path=' . rawurlencode($payload);
}

function serialblog_get_html($url, $retries = 1) {
    if (!function_exists('curl_init')) {
        throw new Exception('PHP cURL extension is required.');
    }

    $fetchUrl = serialblog_internal_proxy_url($url);

    $lastError = '';
    for ($attempt = 0; $attempt <= $retries; $attempt++) {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $fetchUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_ENCODING => '',
            CURLOPT_CONNECTTIMEOUT => 5,
            CURLOPT_TIMEOUT => 12,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0 Safari/537.36',
            CURLOPT_HTTPHEADER => [
                'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.7,en;q=0.6',
                'Cache-Control: no-cache',
                'Referer: ' . SERIALBLOG_BASE_URL . '/',
            ],
        ]);
        $body = curl_exec($ch);
        $err = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        if ($body !== false && $code >= 200 && $code < 400) {
            return (string)$body;
        }
        $lastError = $err !== '' ? $err : ('HTTP ' . $code);
        usleep(250000);
    }

    throw new Exception(
        'SerialBlog fetch failed via internal proxy: ' . $lastError .
        ' — origin=' . $url .
        ' — proxy=' . $fetchUrl
    );
}

function serialblog_xpath_from_html($html) {
    if (!class_exists('DOMDocument')) {
        throw new Exception('PHP DOM extension is required.');
    }
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $dom->loadHTML('<?xml encoding="UTF-8">' . (string)$html);
    libxml_clear_errors();
    return new DOMXPath($dom);
}

function serialblog_node_text($xpath, $query, $context = null) {
    $nodes = $context ? $xpath->query($query, $context) : $xpath->query($query);
    if (!$nodes || $nodes->length === 0) {
        return '';
    }
    return serialblog_clean_text($nodes->item(0)->textContent);
}

function serialblog_node_attr($xpath, $query, $attr, $context = null) {
    $nodes = $context ? $xpath->query($query, $context) : $xpath->query($query);
    if (!$nodes || $nodes->length === 0) {
        return '';
    }
    return serialblog_clean_text($nodes->item(0)->getAttribute($attr));
}

function serialblog_all_node_texts($xpath, $query, $context = null) {
    $nodes = $context ? $xpath->query($query, $context) : $xpath->query($query);
    $out = [];
    if (!$nodes) {
        return $out;
    }
    foreach ($nodes as $node) {
        $text = serialblog_clean_text($node->textContent);
        if ($text !== '') {
            $out[] = $text;
        }
    }
    return array_values(array_unique($out));
}

function serialblog_meta_content($xpath, $propertyOrName) {
    $propertyOrName = addslashes($propertyOrName);
    return serialblog_node_attr($xpath, "//meta[@property='{$propertyOrName}' or @name='{$propertyOrName}'][1]", 'content');
}

function serialblog_quality_from_text($text) {
    if (preg_match('/\b(2160|1440|1080|720|576|540|480|360|240)\s*p\b/i', (string)$text, $m)) {
        return $m[1] . 'p';
    }
    if (preg_match('/\b(4K|WEB[- ]?DL|BluRay|HDRip|HDTV)\b/i', (string)$text, $m)) {
        return strtoupper(str_replace(' ', '-', $m[1]));
    }
    return '';
}

function serialblog_parse_article_item($xpath, $article) {
    $link = serialblog_node_attr($xpath, './/h2//a[@href][1] | .//a[@href][.//img][1] | .//a[@href][1]', 'href', $article);
    $link = serialblog_abs_url($link);
    if ($link === '' || strpos($link, SERIALBLOG_BASE_URL) !== 0) {
        return null;
    }

    $title = serialblog_node_text($xpath, './/h2//a[1] | .//a[@title][1]', $article);
    if ($title === '') {
        $title = serialblog_node_attr($xpath, './/a[@title][1]', 'title', $article);
    }
    if ($title === '') {
        return null;
    }

    $poster = serialblog_node_attr($xpath, './/img[contains(@class,"wp-post-image")][1]', 'src', $article);
    if ($poster === '') {
        $poster = serialblog_node_attr($xpath, './/img[1]', 'src', $article);
    }
    $poster = serialblog_abs_url($poster);

    $text = serialblog_clean_text($article->textContent);
    $rating = '';
    if (preg_match('/IMDb\s*([0-9]+(?:\.[0-9]+)?)/iu', $text, $m)) {
        $rating = $m[1];
    } elseif (preg_match('/([0-9]+(?:\.[0-9]+)?)\s*\/\s*10/u', $text, $m)) {
        $rating = $m[1];
    }

    $year = '';
    $yearText = serialblog_node_text($xpath, './/li[contains(concat(" ",normalize-space(@class)," ")," fm-info-link ")][contains(.,"سال")][1]', $article);
    if ($yearText !== '' && preg_match('/\b(19|20)\d{2}\b/u', $yearText, $m)) {
        $year = $m[0];
    } elseif (preg_match('/\b(19|20)\d{2}\b/u', $text, $m)) {
        $year = $m[0];
    }

    $genres = serialblog_all_node_texts($xpath, './/li[contains(concat(" ",normalize-space(@class)," ")," fm-info-link ")][contains(.,"ژانر")]//a[contains(@href,"/genre-")] | .//a[contains(@href,"/genre-movies/") or contains(@href,"/genre-series/")]', $article);
    $countries = serialblog_all_node_texts($xpath, './/li[contains(concat(" ",normalize-space(@class)," ")," fm-info-link ")][contains(.,"محصول")]//a', $article);
    $language = serialblog_node_text($xpath, './/li[contains(concat(" ",normalize-space(@class)," ")," fm-info-link ")][contains(.,"زبان")]//*[contains(concat(" ",normalize-space(@class)," ")," fm-info-body ")][1]', $article);
    $imdbHref = serialblog_node_attr($xpath, './/a[contains(@href,"imdb.com/title/")][1]', 'href', $article);
    $imdbId = '';
    if ($imdbHref !== '' && preg_match('~/(tt\d+)~i', $imdbHref, $m)) {
        $imdbId = $m[1];
    } elseif (preg_match('/\b(tt\d{5,})\b/i', $poster . ' ' . $text, $m)) {
        $imdbId = $m[1];
    }

    $slug = serialblog_slug_from_url($link);
    $type = serialblog_type_from_url($link, $title);
    $title = serialblog_clean_display_title($title, $type);

    return [
        'id' => $slug,
        'slug' => $slug,
        'title' => $title,
        'title_fa' => $title,
        'year' => $year,
        'poster' => $poster,
        'rating' => $rating,
        'imdb_id' => $imdbId,
        'type' => $type,
        'genres' => $genres,
        'countries' => $countries,
        'language' => $language,
        'url' => $link,
        'source_url' => $link,
        'has_dubbed' => (mb_strpos($text, 'دوبله') !== false),
        'has_subtitle' => (mb_strpos($text, 'زیرنویس') !== false || mb_strpos($text, 'سافت') !== false),
        'quality' => serialblog_quality_from_text($text),
        'update_note' => ''
    ];
}

function serialblog_page_number_from_url($url) {
    $url = html_entity_decode((string)$url, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '') return null;
    $parts = parse_url($url);
    $path = (string)($parts['path'] ?? '');
    $query = (string)($parts['query'] ?? '');
    if (preg_match('~/page/(\d+)/?~i', $path, $m)) {
        return max(1, (int)$m[1]);
    }
    parse_str($query, $qs);
    foreach (['paged', 'page'] as $key) {
        if (isset($qs[$key]) && (int)$qs[$key] > 0) {
            return max(1, (int)$qs[$key]);
        }
    }
    return null;
}

function serialblog_extract_pagination($xpath, $page, $requestUrl = '') {
    $currentPage = max(1, (int)$page);
    $wrapper = serialblog_first_node($xpath, '//*[contains(concat(" ",normalize-space(@class)," ")," pagenaviWrapper ") or contains(concat(" ",normalize-space(@class)," ")," nav-links ")][1]');
    $prevUrl = '';
    $nextUrl = '';
    $totalPages = $currentPage;
    $pages = [$currentPage];

    if ($wrapper) {
        $currentText = serialblog_node_text($xpath, './/*[contains(concat(" ",normalize-space(@class)," ")," current ")][1]', $wrapper);
        $currentText = str_replace(',', '', $currentText);
        if (preg_match('/\d+/', $currentText, $m)) {
            $currentPage = max(1, (int)$m[0]);
            $pages[] = $currentPage;
        }

        $prevUrl = serialblog_node_attr($xpath, './/a[contains(concat(" ",normalize-space(@class)," ")," prev ")][1]', 'href', $wrapper);
        $nextUrl = serialblog_node_attr($xpath, './/a[contains(concat(" ",normalize-space(@class)," ")," next ")][1]', 'href', $wrapper);
        $prevUrl = $prevUrl !== '' ? serialblog_abs_url($prevUrl) : '';
        $nextUrl = $nextUrl !== '' ? serialblog_abs_url($nextUrl) : '';

        $links = $xpath->query('.//*[contains(concat(" ",normalize-space(@class)," ")," page-numbers ")]', $wrapper);
        if ($links) {
            foreach ($links as $lnk) {
                $txt = serialblog_clean_text($lnk->textContent);
                $txt = str_replace(',', '', $txt);
                if (preg_match('/^\d+$/', $txt)) {
                    $pages[] = (int)$txt;
                }
                if ($lnk->nodeType === XML_ELEMENT_NODE && $lnk->hasAttribute('href')) {
                    $n = serialblog_page_number_from_url($lnk->getAttribute('href'));
                    if ($n !== null) $pages[] = $n;
                }
            }
        }
    }

    $totalPages = max($pages);
    $prevPage = $prevUrl !== '' ? serialblog_page_number_from_url($prevUrl) : ($currentPage > 1 ? $currentPage - 1 : null);
    $nextPage = $nextUrl !== '' ? serialblog_page_number_from_url($nextUrl) : (($totalPages > $currentPage) ? $currentPage + 1 : null);

    return [
        'current_page' => $currentPage,
        'page' => $currentPage,
        'total_pages' => $totalPages,
        'has_prev_page' => $prevPage !== null && $prevPage >= 1,
        'has_next_page' => $nextPage !== null && $nextPage > $currentPage,
        'prev_page' => $prevPage,
        'next_page' => $nextPage,
        'prev_page_url' => $prevUrl,
        'next_page_url' => $nextUrl,
        'continue_page' => $nextPage,
        'continue_url' => $nextUrl,
    ];
}

function serialblog_parse_listing($html, $page = 1, $requestUrl = '') {
    $xpath = serialblog_xpath_from_html($html);
    $articles = $xpath->query('//article[contains(concat(" ",normalize-space(@class)," ")," postItems ")]');
    $items = [];
    $seen = [];

    if ($articles) {
        foreach ($articles as $article) {
            $item = serialblog_parse_article_item($xpath, $article);
            if (!$item) {
                continue;
            }
            $key = $item['url'];
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $items[] = $item;
        }
    }

    $pagination = serialblog_extract_pagination($xpath, $page, $requestUrl);
    $hasMore = !empty($pagination['has_next_page']);
    if (!$hasMore && preg_match('/class=["\'][^"\']*next\s+page-numbers/i', (string)$html)) {
        $hasMore = true;
    }
    if (!$hasMore && preg_match('/rel=["\']next["\']/i', (string)$html)) {
        $hasMore = true;
    }

    return [
        'source' => 'serialblog',
        'page' => (int)$pagination['current_page'],
        'current_page' => (int)$pagination['current_page'],
        'movies' => $items,
        'items' => $items,
        'count' => count($items),
        'has_more' => $hasMore,
        'has_next_page' => (bool)$pagination['has_next_page'],
        'next_page' => $pagination['next_page'],
        'next_page_url' => $pagination['next_page_url'],
        'has_prev_page' => (bool)$pagination['has_prev_page'],
        'prev_page' => $pagination['prev_page'],
        'prev_page_url' => $pagination['prev_page_url'],
        'total_pages' => $pagination['total_pages'],
        'continue_page' => $pagination['continue_page'],
        'continue_url' => $pagination['continue_url'],
        'pagination' => $pagination,
    ];
}

function serialblog_genre_key($name) {
    $name = serialblog_clean_text($name);
    $name = str_replace(['ي','ك','\xE2\x80\x8C'], ['ی','ک',' '], $name);
    $name = preg_replace('/\x{200c}/u', ' ', $name);
    $name = preg_replace('/[\s_]+/u', '-', trim($name));
    $name = mb_strtolower($name, 'UTF-8');
    return $name;
}

function serialblog_genre_catalog() {
    $movie = [
        'اکشن' => '/genre-movies/%d8%a7%da%a9%d8%b4%d9%86/',
        'انیمیشن' => '/genre-movies/%d8%a7%d9%86%db%8c%d9%85%db%8c%d8%b4%d9%86/',
        'تاریخی' => '/genre-movies/%d8%aa%d8%a7%d8%b1%db%8c%d8%ae%db%8c/',
        'تالک-شو' => '/genre-movies/%d8%aa%d8%a7%d9%84%da%a9-%d8%b4%d9%88/',
        'ترسناک' => '/genre-movies/%d8%aa%d8%b1%d8%b3%d9%86%d8%a7%da%a9/',
        'جنایی' => '/genre-movies/%d8%ac%d9%86%d8%a7%db%8c%db%8c/',
        'جنگی' => '/genre-movies/%d8%ac%d9%86%da%af%db%8c/',
        'خانوادگی' => '/genre-movies/%d8%ae%d8%a7%d9%86%d9%88%d8%a7%d8%af%da%af%db%8c/',
        'خبری' => '/genre-movies/%d8%ae%d8%a8%d8%b1%db%8c/',
        'درام' => '/genre-movies/%d8%af%d8%b1%d8%a7%d9%85/',
        'ریئلیتی-تیوی' => '/genre-movies/%d8%b1%db%8c%d8%a6%d9%84%db%8c%d8%aa%db%8c-%d8%aa%db%8c%d9%88%db%8c/',
        'زندگی نامه' => '/genre-movies/%d8%b2%d9%86%d8%af%da%af%db%8c-%d9%86%d8%a7%d9%85%d9%87/',
        'عاشقانه' => '/genre-movies/%d8%b9%d8%a7%d8%b4%d9%82%d8%a7%d9%86%d9%87/',
        'علمی-تخیلی' => '/genre-movies/%d8%b9%d9%84%d9%85%db%8c-%d8%aa%d8%ae%db%8c%d9%84%db%8c/',
        'فانتزی' => '/genre-movies/%d9%81%d8%a7%d9%86%d8%aa%d8%b2%db%8c/',
        'فیلم-نوآر' => '/genre-movies/%d9%81%db%8c%d9%84%d9%85-%d9%86%d9%88%d8%a2%d8%b1/',
        'کمدی' => '/genre-movies/%da%a9%d9%85%d8%af%db%8c/',
        'کوتاه' => '/genre-movies/%da%a9%d9%88%d8%aa%d8%a7%d9%87/',
        'گیم-شو' => '/genre-movies/%da%af%db%8c%d9%85-%d8%b4%d9%88/',
        'ماجراجویی' => '/genre-movies/%d9%85%d8%a7%d8%ac%d8%b1%d8%a7%d8%ac%d9%88%db%8c%db%8c/',
        'مستند' => '/genre-movies/%d9%85%d8%b3%d8%aa%d9%86%d8%af/',
        'معمایی' => '/genre-movies/%d9%85%d8%b9%d9%85%d8%a7%db%8c%db%8c/',
        'موزیک' => '/genre-movies/%d9%85%d9%88%d8%b2%db%8c%da%a9/',
        'موزیکال' => '/genre-movies/%d9%85%d9%88%d8%b2%db%8c%da%a9%d8%a7%d9%84/',
        'موسیقی' => '/genre-movies/%d9%85%d9%88%d8%b3%db%8c%d9%82%db%8c/',
        'هیجان انگیز' => '/genre-movies/%d9%87%db%8c%d8%ac%d8%a7%d9%86-%d8%a7%d9%86%da%af%db%8c%d8%b2/',
        'هیجان‌انگیز' => '/genre-movies/%d9%87%db%8c%d8%ac%d8%a7%d9%86%d8%a7%d9%86%da%af%db%8c%d8%b2/',
        'ورزشی' => '/genre-movies/%d9%88%d8%b1%d8%b2%d8%b4%db%8c/',
        'وسترن' => '/genre-movies/%d9%88%d8%b3%d8%aa%d8%b1%d9%86/',
    ];
    $series = [
        'اکشن' => '/genre-series/%d8%a7%da%a9%d8%b4%d9%86/',
        'انیمیشن' => '/genre-series/%d8%a7%d9%86%db%8c%d9%85%db%8c%d8%b4%d9%86/',
        'بیوگرافی' => '/genre-series/%d8%a8%db%8c%d9%88%da%af%d8%b1%d8%a7%d9%81%db%8c/',
        'تاریخی' => '/genre-series/%d8%aa%d8%a7%d8%b1%db%8c%d8%ae%db%8c/',
        'تاک-شو' => '/genre-series/%d8%aa%d8%a7%da%a9-%d8%b4%d9%88/',
        'ترسناک' => '/genre-series/%d8%aa%d8%b1%d8%b3%d9%86%d8%a7%da%a9/',
        'جنایی' => '/genre-series/%d8%ac%d9%86%d8%a7%db%8c%db%8c/',
        'جنگی' => '/genre-series/%d8%ac%d9%86%da%af%db%8c/',
        'خانوادگی' => '/genre-series/%d8%ae%d8%a7%d9%86%d9%88%d8%a7%d8%af%da%af%db%8c/',
        'خبری' => '/genre-series/%d8%ae%d8%a8%d8%b1%db%8c/',
        'درام' => '/genre-series/%d8%af%d8%b1%d8%a7%d9%85/',
        'شوی تلویزیونی' => '/genre-series/%d8%b4%d9%88%db%8c-%d8%aa%d9%84%d9%88%db%8c%d8%b2%db%8c%d9%88%d9%86%db%8c/',
        'عاشقانه' => '/genre-series/%d8%b9%d8%a7%d8%b4%d9%82%d8%a7%d9%86%d9%87/',
        'علمی-تخیلی' => '/genre-series/%d8%b9%d9%84%d9%85%db%8c-%d8%aa%d8%ae%db%8c%d9%84%db%8c/',
        'فانتزی' => '/genre-series/%d9%81%d8%a7%d9%86%d8%aa%d8%b2%db%8c/',
        'کمدی' => '/genre-series/%da%a9%d9%85%d8%af%db%8c/',
        'کوتاه' => '/genre-series/%da%a9%d9%88%d8%aa%d8%a7%d9%87/',
        'گیم-شو' => '/genre-series/%da%af%db%8c%d9%85-%d8%b4%d9%88/',
        'ماجراجویی' => '/genre-series/%d9%85%d8%a7%d8%ac%d8%b1%d8%a7%d8%ac%d9%88%db%8c%db%8c/',
        'مستند' => '/genre-series/%d9%85%d8%b3%d8%aa%d9%86%d8%af/',
        'معمایی' => '/genre-series/%d9%85%d8%b9%d9%85%d8%a7%db%8c%db%8c/',
        'موزیک' => '/genre-series/%d9%85%d9%88%d8%b2%db%8c%da%a9/',
        'موزیکال' => '/genre-series/%d9%85%d9%88%d8%b2%db%8c%da%a9%d8%a7%d9%84/',
        'هیجان انگیز' => '/genre-series/%d9%87%db%8c%d8%ac%d8%a7%d9%86-%d8%a7%d9%86%da%af%db%8c%d8%b2/',
        'ورزشی' => '/genre-series/%d9%88%d8%b1%d8%b2%d8%b4%db%8c/',
        'وسترن' => '/genre-series/%d9%88%d8%b3%d8%aa%d8%b1%d9%86/',
    ];
    $aliases = [
        'action' => 'اکشن', 'animation' => 'انیمیشن', 'anime' => 'انیمیشن', 'historical' => 'تاریخی', 'history' => 'تاریخی',
        'talk-show' => 'تاک-شو', 'horror' => 'ترسناک', 'crime' => 'جنایی', 'war' => 'جنگی', 'family' => 'خانوادگی',
        'news' => 'خبری', 'drama' => 'درام', 'reality-tv' => 'ریئلیتی-تیوی', 'biography' => 'بیوگرافی', 'bio' => 'بیوگرافی',
        'romance' => 'عاشقانه', 'sci-fi' => 'علمی-تخیلی', 'scifi' => 'علمی-تخیلی', 'science-fiction' => 'علمی-تخیلی',
        'fantasy' => 'فانتزی', 'film-noir' => 'فیلم-نوآر', 'comedy' => 'کمدی', 'short' => 'کوتاه', 'game-show' => 'گیم-شو',
        'adventure' => 'ماجراجویی', 'documentary' => 'مستند', 'mystery' => 'معمایی', 'music' => 'موزیک', 'musical' => 'موزیکال',
        'thriller' => 'هیجان انگیز', 'sport' => 'ورزشی', 'sports' => 'ورزشی', 'western' => 'وسترن', 'tv-show' => 'شوی تلویزیونی',
    ];
    $names = [];
    foreach (array_keys($movie + $series) as $name) {
        $names[$name] = true;
    }
    $out = [];
    foreach (array_keys($names) as $name) {
        $key = serialblog_genre_key($name);
        $out[$key] = [
            'key' => $key,
            'title' => $name,
            'fa' => $name,
            'movie_path' => $movie[$name] ?? '',
            'series_path' => $series[$name] ?? '',
            'has_movies' => isset($movie[$name]),
            'has_series' => isset($series[$name]),
        ];
    }
    foreach ($aliases as $alias => $name) {
        $key = serialblog_genre_key($name);
        if (isset($out[$key])) {
            $out[$alias] = $out[$key];
            $out[$alias]['key'] = $alias;
            $out[$alias]['alias_of'] = $key;
        }
    }
    return $out;
}

function serialblog_resolve_genre($genre) {
    $catalog = serialblog_genre_catalog();
    $key = serialblog_genre_key($genre);
    if (isset($catalog[$key])) return $catalog[$key];
    $lower = strtolower(trim((string)$genre));
    if (isset($catalog[$lower])) return $catalog[$lower];
    foreach ($catalog as $def) {
        if (serialblog_genre_key($def['title']) === $key) return $def;
    }
    return null;
}

function serialblog_genres_list() {
    $seen = [];
    $out = [];
    foreach (serialblog_genre_catalog() as $key => $def) {
        $id = serialblog_genre_key($def['title']);
        if (isset($seen[$id])) continue;
        $seen[$id] = true;
        $out[] = [
            'key' => $id,
            'title' => $def['title'],
            'movie_path' => $def['movie_path'],
            'series_path' => $def['series_path'],
            'movie_url' => $def['movie_path'] !== '' ? serialblog_abs_url($def['movie_path']) : '',
            'series_url' => $def['series_path'] !== '' ? serialblog_abs_url($def['series_path']) : '',
            'has_movies' => (bool)$def['has_movies'],
            'has_series' => (bool)$def['has_series'],
        ];
    }
    return $out;
}

function serialblog_filter_listing_type($result, $type) {
    $type = strtolower(trim((string)$type));
    if (!in_array($type, ['movie', 'series'], true)) return $result;

    $items = [];
    foreach (($result['items'] ?? []) as $item) {
        if (($item['type'] ?? '') === $type) $items[] = $item;
    }
    $result['items'] = $items;
    $result['movies'] = $items;
    $result['count'] = count($items);
    return $result;
}

function serialblog_merge_listing_results($results, $section, $title, $page) {
    $items = [];
    $seen = [];
    $hasMore = false;
    $nextPage = null;
    $requestUrls = [];

    foreach ($results as $result) {
        foreach (($result['items'] ?? []) as $item) {
            $key = $item['url'] ?? ($item['id'] ?? '');
            if ($key === '' || isset($seen[$key])) continue;
            $seen[$key] = true;
            $items[] = $item;
        }
        if (!empty($result['has_more']) || !empty($result['has_next_page'])) $hasMore = true;
        if (!empty($result['next_page'])) {
            $candidate = (int)$result['next_page'];
            if ($candidate > (int)$page && ($nextPage === null || $candidate < $nextPage)) $nextPage = $candidate;
        }
        if (!empty($result['request_url'])) $requestUrls[] = $result['request_url'];
    }

    if ($hasMore && $nextPage === null) $nextPage = max(1, (int)$page) + 1;
    return [
        'source' => 'serialblog',
        'section' => $section,
        'section_title' => $title,
        'page' => max(1, (int)$page),
        'current_page' => max(1, (int)$page),
        'movies' => $items,
        'items' => $items,
        'count' => count($items),
        'has_more' => $hasMore,
        'has_next_page' => $hasMore,
        'next_page' => $nextPage,
        'request_urls' => $requestUrls,
    ];
}

function serialblog_get_movies_2025_2026($page = 1) {
    $page = max(1, (int)$page);
    $results = [];
    foreach ([2026, 2025] as $year) {
        $url = serialblog_add_page_to_url(rtrim(SERIALBLOG_BASE_URL, '/') . '/release/' . $year . '/', $page);
        $html = serialblog_get_html($url);
        $result = serialblog_parse_listing($html, $page, $url);
        $result['request_url'] = $url;
        $results[] = serialblog_filter_listing_type($result, 'movie');
    }
    return serialblog_merge_listing_results($results, 'movies_2025_2026', 'اکران 2025 و 2026', $page);
}

function serialblog_section_catalog() {
    $sections = [
        'home'             => ['fa' => 'تازه‌های سریال بلاگ', 'en' => 'SerialBlog Latest', 'path' => '/', 'type' => 'all'],
        'movies_2025_2026' => ['fa' => 'اکران 2025 و 2026', 'en' => '2025 and 2026 Releases', 'path' => '/release/2026/', 'type' => 'movie', 'custom' => true],
        'new_movies'       => ['fa' => 'فیلم‌های جدید', 'en' => 'New Movies', 'path' => '/release/2026/', 'type' => 'movie'],
        'new_series'       => ['fa' => 'سریال‌های آپدیت‌شده', 'en' => 'Updated Series', 'path' => '/series/', 'type' => 'series'],
        'all_series' => ['fa' => 'همه سریال‌ها', 'en' => 'All Series', 'path' => '/series/', 'type' => 'series'],
        'dubbed'     => ['fa' => 'دوبله فارسی', 'en' => 'Persian Dubbed', 'search' => 'دوبله', 'type' => 'all'],
    ];
    foreach (serialblog_genres_list() as $genre) {
        $gkey = $genre['key'];
        if (!empty($genre['movie_path'])) {
            $sections['genre_movie_' . $gkey] = [
                'fa' => 'فیلم ' . $genre['title'],
                'en' => 'Movie Genre: ' . $gkey,
                'path' => $genre['movie_path'],
                'type' => 'movie',
                'genre' => $genre['title'],
            ];
        }
        if (!empty($genre['series_path'])) {
            $sections['genre_series_' . $gkey] = [
                'fa' => 'سریال ' . $genre['title'],
                'en' => 'Series Genre: ' . $gkey,
                'path' => $genre['series_path'],
                'type' => 'series',
                'genre' => $genre['title'],
            ];
        }
    }
    foreach (serialblog_genre_catalog() as $alias => $def) {
        if (empty($def['alias_of'])) continue;
        if (!empty($def['movie_path'])) {
            $sections['genre_movie_' . $alias] = [
                'fa' => 'فیلم ' . $def['title'],
                'en' => 'Movie Genre: ' . $alias,
                'path' => $def['movie_path'],
                'type' => 'movie',
                'genre' => $def['title'],
            ];
        }
        if (!empty($def['series_path'])) {
            $sections['genre_series_' . $alias] = [
                'fa' => 'سریال ' . $def['title'],
                'en' => 'Series Genre: ' . $alias,
                'path' => $def['series_path'],
                'type' => 'series',
                'genre' => $def['title'],
            ];
        }
    }
    // Backward-compatible short aliases used by the first API5 builds.
    $sections['action'] = $sections['genre_movie_action'] ?? ['fa' => 'اکشن', 'path' => '/genre-movies/%d8%a7%da%a9%d8%b4%d9%86/', 'type' => 'movie'];
    $sections['animation'] = $sections['genre_movie_animation'] ?? ['fa' => 'انیمیشن', 'path' => '/genre-movies/%d8%a7%d9%86%db%8c%d9%85%db%8c%d8%b4%d9%86/', 'type' => 'movie'];
    return $sections;
}

function serialblog_add_page_to_url($baseUrl, $page = 1, $searchQuery = '') {
    $page = max(1, (int)$page);
    $baseUrl = serialblog_abs_url($baseUrl);
    if ($searchQuery !== '') {
        if ($page > 1) {
            return rtrim(SERIALBLOG_BASE_URL, '/') . '/page/' . $page . '/?s=' . rawurlencode($searchQuery);
        }
        return rtrim(SERIALBLOG_BASE_URL, '/') . '/?s=' . rawurlencode($searchQuery);
    }
    if ($page > 1) {
        return rtrim($baseUrl, '/') . '/page/' . $page . '/';
    }
    return rtrim($baseUrl, '/') . '/';
}

function serialblog_search_url($term, $page = 1) {
    return serialblog_add_page_to_url(SERIALBLOG_BASE_URL . '/', $page, trim((string)$term));
}

function serialblog_section_url($section, $page = 1) {
    $catalog = serialblog_section_catalog();
    if (!isset($catalog[$section])) {
        $section = 'home';
    }
    $def = $catalog[$section];
    if (!empty($def['search'])) {
        return serialblog_search_url($def['search'], $page);
    }
    return serialblog_add_page_to_url(rtrim(SERIALBLOG_BASE_URL, '/') . ($def['path'] ?? '/'), $page);
}

function serialblog_get_section($section, $page = 1) {
    if ($section === 'movies_2025_2026') {
        return serialblog_get_movies_2025_2026($page);
    }

    $url = serialblog_section_url($section, $page);
    $html = serialblog_get_html($url);
    $result = serialblog_parse_listing($html, $page, $url);
    $catalog = serialblog_section_catalog();
    $resolved = isset($catalog[$section]) ? $section : 'home';
    $type = $catalog[$resolved]['type'] ?? 'all';
    $result = serialblog_filter_listing_type($result, $type);
    $result['section'] = $resolved;
    $result['section_title'] = $catalog[$resolved]['fa'] ?? $resolved;
    $result['request_url'] = $url;
    return $result;
}

function serialblog_get_genre($genre, $type = 'movie', $page = 1) {
    $def = serialblog_resolve_genre($genre);
    if (!$def) {
        return [
            'source' => 'serialblog',
            'section' => 'genre',
            'genre' => (string)$genre,
            'type' => $type,
            'page' => max(1, (int)$page),
            'movies' => [],
            'items' => [],
            'count' => 0,
            'has_more' => false,
            'error' => 'genre_not_found',
        ];
    }
    $type = strtolower(trim((string)$type));
    if ($type === 'series' && $def['series_path'] !== '') {
        $path = $def['series_path'];
        $resolvedType = 'series';
    } elseif ($type === 'movie' && $def['movie_path'] !== '') {
        $path = $def['movie_path'];
        $resolvedType = 'movie';
    } elseif ($def['movie_path'] !== '') {
        $path = $def['movie_path'];
        $resolvedType = 'movie';
    } else {
        $path = $def['series_path'];
        $resolvedType = 'series';
    }
    $url = serialblog_add_page_to_url(rtrim(SERIALBLOG_BASE_URL, '/') . $path, $page);
    $html = serialblog_get_html($url);
    $result = serialblog_parse_listing($html, $page, $url);
    $result['section'] = 'genre_' . $resolvedType . '_' . serialblog_genre_key($def['title']);
    $result['genre'] = $def['title'];
    $result['type'] = $resolvedType;
    $result['request_url'] = $url;
    return $result;
}


function serialblog_advanced_query_url($params, $page = 1, $forcedType = '') {
    $type = strtolower(trim((string)($forcedType !== '' ? $forcedType : ($params['type'] ?? 'movie'))));
    $postType = ($type === 'series') ? 'series' : 'post';

    $query = [
        's' => trim((string)($params['s'] ?? $params['q'] ?? '')),
        'search_type' => 'advanced',
        'post_type' => $postType,
    ];

    $copy = [
        'genre' => 'genre',
        'rating' => 'rating',
        'order' => 'order',
        'yearFrom' => 'yearFrom',
        'yearTo' => 'yearTo',
        'country' => 'country',
        'language' => 'language',
        'status' => 'status',
        'age' => 'age',
        'meta_critic' => 'meta_critic',
    ];
    foreach ($copy as $source => $target) {
        if (isset($params[$source]) && trim((string)$params[$source]) !== '') {
            $query[$target] = trim((string)$params[$source]);
        }
    }

    if (!empty($params['double']) || !empty($params['dubbed'])) {
        $query['double'] = '1';
    }
    if (!empty($params['subtitle'])) {
        $query['subtitle'] = '1';
    }
    if ((int)$page > 1) {
        $query['paged'] = max(1, (int)$page);
    }

    return rtrim(SERIALBLOG_BASE_URL, '/') . '/?' . http_build_query($query, '', '&', PHP_QUERY_RFC3986);
}

function serialblog_advanced_search_single($params, $type, $page = 1) {
    $url = serialblog_advanced_query_url($params, $page, $type);
    $html = serialblog_get_html($url);
    $result = serialblog_parse_listing($html, $page, $url);
    $items = [];

    foreach (($result['items'] ?? []) as $item) {
        $itemType = strtolower(trim((string)($item['type'] ?? '')));
        if ($type === 'series') {
            if ($itemType === 'series' || stripos((string)($item['url'] ?? ''), '/series/') !== false) {
                $items[] = $item;
            }
        } else {
            if ($itemType !== 'series' && stripos((string)($item['url'] ?? ''), '/series/') === false) {
                $items[] = $item;
            }
        }
    }

    $limit = max(1, min(100, (int)($params['limit'] ?? 40)));
    if (count($items) > $limit) {
        $items = array_slice($items, 0, $limit);
    }

    $result['items'] = $items;
    $result['movies'] = $items;
    $result['count'] = count($items);
    $result['type'] = $type;
    $result['search_mode'] = 'advanced';
    $result['request_url'] = $url;
    $result['filters'] = [
        'query' => trim((string)($params['s'] ?? $params['q'] ?? '')),
        'type' => $type,
        'genre' => trim((string)($params['genre'] ?? '')),
        'rating' => trim((string)($params['rating'] ?? '')),
        'order' => trim((string)($params['order'] ?? '')),
        'year_from' => trim((string)($params['yearFrom'] ?? '')),
        'year_to' => trim((string)($params['yearTo'] ?? '')),
        'country' => trim((string)($params['country'] ?? '')),
        'dubbed' => !empty($params['double']) || !empty($params['dubbed']),
        'subtitle' => !empty($params['subtitle']),
    ];
    return $result;
}

function serialblog_advanced_search($params) {
    $page = max(1, (int)($params['page'] ?? 1));
    $type = strtolower(trim((string)($params['type'] ?? 'all')));

    if ($type !== 'all') {
        return serialblog_advanced_search_single($params, $type === 'series' ? 'series' : 'movie', $page);
    }

    $movie = serialblog_advanced_search_single($params, 'movie', $page);
    $series = serialblog_advanced_search_single($params, 'series', $page);
    $merged = [];
    $seen = [];

    foreach (array_merge($movie['items'] ?? [], $series['items'] ?? []) as $item) {
        $key = (string)($item['url'] ?? $item['id'] ?? $item['slug'] ?? '');
        if ($key === '' || isset($seen[$key])) continue;
        $seen[$key] = true;
        $merged[] = $item;
    }

    $limit = max(1, min(100, (int)($params['limit'] ?? 40)));
    if (count($merged) > $limit) {
        $merged = array_slice($merged, 0, $limit);
    }

    return [
        'source' => 'serialblog',
        'search_mode' => 'advanced',
        'type' => 'all',
        'page' => $page,
        'current_page' => $page,
        'items' => $merged,
        'movies' => $merged,
        'count' => count($merged),
        'has_more' => !empty($movie['has_more']) || !empty($series['has_more']),
        'has_next_page' => !empty($movie['has_next_page']) || !empty($series['has_next_page']),
        'next_page' => (!empty($movie['has_more']) || !empty($series['has_more'])) ? $page + 1 : null,
        'filters' => [
            'query' => trim((string)($params['s'] ?? $params['q'] ?? '')),
            'type' => 'all',
            'genre' => trim((string)($params['genre'] ?? '')),
            'rating' => trim((string)($params['rating'] ?? '')),
            'order' => trim((string)($params['order'] ?? '')),
            'year_from' => trim((string)($params['yearFrom'] ?? '')),
            'year_to' => trim((string)($params['yearTo'] ?? '')),
            'country' => trim((string)($params['country'] ?? '')),
            'dubbed' => !empty($params['double']) || !empty($params['dubbed']),
            'subtitle' => !empty($params['subtitle']),
        ],
    ];
}

function serialblog_search($params) {
    $term = trim((string)($params['s'] ?? $params['q'] ?? ''));
    $page = max(1, (int)($params['page'] ?? 1));
    if ($term === '') {
        return serialblog_get_section('home', $page);
    }
    if (preg_match('/^tt\d{5,}$/i', $term)) {
        return serialblog_search_by_imdb($term, $page);
    }
    $url = serialblog_search_url($term, $page);
    $html = serialblog_get_html($url);
    $result = serialblog_parse_listing($html, $page, $url);
    $result['query'] = $term;
    $result['search_mode'] = 'text';
    $result['request_url'] = $url;
    return $result;
}

function serialblog_search_by_imdb($imdbId, $page = 1) {
    $imdbId = strtolower(trim((string)$imdbId));
    if (!preg_match('/^tt\d{5,}$/', $imdbId)) {
        return [
            'source' => 'serialblog',
            'query' => $imdbId,
            'search_mode' => 'imdb',
            'movies' => [],
            'items' => [],
            'count' => 0,
            'has_more' => false,
            'error' => 'invalid_imdb_id',
        ];
    }
    $url = serialblog_search_url($imdbId, $page);
    $html = serialblog_get_html($url);
    $result = serialblog_parse_listing($html, $page, $url);
    $filtered = [];
    foreach (($result['items'] ?? []) as $item) {
        $hay = strtolower(($item['imdb_id'] ?? '') . ' ' . ($item['poster'] ?? '') . ' ' . ($item['title'] ?? '') . ' ' . ($item['url'] ?? ''));
        if (strpos($hay, $imdbId) !== false) {
            $filtered[] = $item;
        }
    }
    // If WordPress search already returned a narrow result but the list parser could not see the IMDb id, keep those results.
    if (count($filtered) > 0 || count($result['items'] ?? []) > 1) {
        $result['movies'] = $filtered;
        $result['items'] = $filtered;
        $result['count'] = count($filtered);
    }
    $result['query'] = $imdbId;
    $result['imdb_id'] = $imdbId;
    $result['search_mode'] = 'imdb';
    $result['request_url'] = $url;
    return $result;
}

function serialblog_extract_info_by_labels($text) {
    $labels = [
        'country' => ['محصول کشور', 'کشور'],
        'language' => ['زبان'],
        'duration' => ['مدت زمان', 'زمان'],
        'age_rating' => ['رده سنی'],
        'release_year' => ['سال انتشار', 'سال تولید'],
        'quality' => ['کیفیت'],
    ];
    $out = [];
    foreach ($labels as $key => $names) {
        foreach ($names as $label) {
            $pattern = '/' . preg_quote($label, '/') . '\s*[:：]?\s*([^\|\n،]+(?:،\s*[^\|\n]+)?)/u';
            if (preg_match($pattern, $text, $m)) {
                $out[$key] = serialblog_clean_text($m[1]);
                break;
            }
        }
    }
    return $out;
}

function serialblog_first_node($xpath, $query, $context = null) {
    $nodes = $context ? $xpath->query($query, $context) : $xpath->query($query);
    if (!$nodes || $nodes->length === 0) {
        return null;
    }
    return $nodes->item(0);
}

function serialblog_text_minus_label($text, $label) {
    $text = serialblog_clean_text($text);
    $label = serialblog_clean_text($label);
    if ($label !== '') {
        $text = preg_replace('/^' . preg_quote($label, '/') . '\s*/u', '', $text);
    }
    return serialblog_clean_text($text);
}

function serialblog_parse_fm_info_items($xpath) {
    $out = [];
    $nodes = $xpath->query('//div[contains(concat(" ",normalize-space(@class)," ")," postMain ")]//*[contains(concat(" ",normalize-space(@class)," ")," fm-infos ")]');
    if (!$nodes) {
        return $out;
    }

    foreach ($nodes as $node) {
        $label = serialblog_node_text($xpath, './/strong[1]', $node);
        if ($label === '') {
            continue;
        }
        $value = serialblog_node_text($xpath, './/*[contains(concat(" ",normalize-space(@class)," ")," fm-info-body ")][1]', $node);
        if ($value === '') {
            $value = serialblog_text_minus_label($node->textContent, $label);
        }
        if ($value === '') {
            continue;
        }

        if (mb_strpos($label, 'کیفیت') !== false) {
            $out['quality'] = $value;
        } elseif (mb_strpos($label, 'شبکه') !== false) {
            $out['network'] = $value;
        } elseif (mb_strpos($label, 'سال') !== false && mb_strpos($label, 'پخش') !== false) {
            $out['broadcast_years'] = $value;
        } elseif (mb_strpos($label, 'زبان') !== false) {
            $out['language'] = $value;
        } elseif (mb_strpos($label, 'مدت') !== false || mb_strpos($label, 'زمان') !== false) {
            $out['duration'] = $value;
        } elseif (mb_strpos($label, 'رده') !== false) {
            $out['age_rating'] = $value;
        }
    }
    return $out;
}

function serialblog_detail_links_for_label($xpath, $labelText) {
    $labelText = addslashes($labelText);
    return serialblog_all_node_texts($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")]//*[contains(concat(" ",normalize-space(@class)," ")," pr-item ")][contains(normalize-space(.),"' . $labelText . '")]//a');
}

function serialblog_detail_first_link_for_label($xpath, $labelText) {
    $items = serialblog_detail_links_for_label($xpath, $labelText);
    return $items[0] ?? '';
}

function serialblog_extract_imdb_id($xpath) {
    $href = serialblog_node_attr($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")]//a[contains(@href,"imdb.com/title/")][1]', 'href');
    if ($href !== '' && preg_match('~/(tt\d+)~i', $href, $m)) {
        return $m[1];
    }
    return '';
}

function serialblog_extract_votes($xpath) {
    $txt = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")]//*[contains(concat(" ",normalize-space(@class)," ")," -rate-number ")][1]');
    $txt = preg_replace('/[0-9]+(?:\.[0-9]+)?\s*\/\s*10/u', '', $txt);
    $txt = serialblog_clean_text($txt);
    return $txt;
}

function serialblog_infer_release_from_text($text) {
    $text = serialblog_clean_text($text);
    if (preg_match('/ریلیز\s+([^\(\)]+)/u', $text, $m)) {
        return serialblog_clean_text($m[1]);
    }
    if (preg_match('/\b(Pahe|PSA|YIFY|RARBG|GalaxyRG|NTb|AMZN|WEBRip|BluRay)\b/i', $text, $m)) {
        return $m[1];
    }
    return '';
}

function serialblog_infer_size_from_text($text) {
    if (preg_match('/حجم\s*[:：]\s*([^\)]+)\)/u', (string)$text, $m)) {
        return serialblog_clean_text($m[1]);
    }
    if (preg_match('/\b([0-9]+(?:\.[0-9]+)?\s*(?:GB|MB))\b/i', (string)$text, $m)) {
        return serialblog_clean_text($m[1]);
    }
    return '';
}

function serialblog_infer_version_from_url_text($url, $text) {
    $hay = strtolower($url . ' ' . $text);
    if (strpos($hay, 'dubbed') !== false || mb_strpos($text, 'دوبله') !== false) {
        return 'دوبله فارسی';
    }
    if (strpos($hay, 'softsub') !== false || mb_strpos($text, 'سافت') !== false) {
        return 'سافت ساب فارسی';
    }
    if (strpos($hay, 'hardsub') !== false || strpos($hay, 'hard') !== false || mb_strpos($text, 'زیرنویس چسبیده') !== false) {
        return 'زیرنویس چسبیده';
    }
    return '';
}

function serialblog_is_media_url($url) {
    return (bool)preg_match('~\.(mkv|mp4|avi|m3u8)(?:[?#]|$)~i', (string)$url);
}

function serialblog_normalize_quality($quality) {
    $quality = serialblog_clean_text($quality);
    if ($quality === '') return '';
    $quality = preg_replace('/\s+/u', ' ', $quality);
    return $quality;
}

function serialblog_quality_rank($quality) {
    $q = strtolower((string)$quality);
    if (strpos($q, '2160') !== false || strpos($q, '4k') !== false) return 500;
    if (strpos($q, '1440') !== false) return 450;
    if (strpos($q, '1080') !== false) return 400;
    if (strpos($q, '720') !== false) return 300;
    if (strpos($q, '576') !== false) return 250;
    if (strpos($q, '480') !== false) return 200;
    if (strpos($q, '360') !== false) return 100;
    return 0;
}

function serialblog_download_type_from_text($text) {
    $text = (string)$text;
    $lower = strtolower($text);
    if (strpos($lower, 'dubbed') !== false || strpos($lower, 'farsi.dubbed') !== false || mb_strpos($text, 'دوبله') !== false) {
        return 'dubbed';
    }
    if (strpos($lower, 'softsub') !== false || mb_strpos($text, 'سافت') !== false) {
        return 'softsub';
    }
    if (strpos($lower, 'hardsub') !== false || strpos($lower, 'hardsub') !== false || mb_strpos($text, 'زیرنویس چسبیده') !== false) {
        return 'hardsub';
    }
    if (mb_strpos($text, 'زیرنویس') !== false) {
        return 'subtitle';
    }
    return '';
}

function serialblog_type_fa($type) {
    if ($type === 'dubbed') return 'دوبله فارسی';
    if ($type === 'softsub') return 'سافت ساب فارسی';
    if ($type === 'hardsub') return 'زیرنویس چسبیده';
    if ($type === 'subtitle') return 'زیرنویس فارسی';
    return '';
}

function serialblog_season_episode_from_text_url($text, $url, $fallbackSeason = null, $fallbackEpisode = null) {
    $hay = (string)$url . ' ' . (string)$text;
    $season = $fallbackSeason;
    $episode = $fallbackEpisode;

    if (preg_match('/S\s*0*(\d+)\s*E\s*0*(\d+)/i', $hay, $m)) {
        $season = (int)$m[1];
        $episode = (int)$m[2];
    } else {
        if (preg_match('/(?:^|[^a-z0-9])S\s*0*(\d+)(?:[^a-z0-9]|$)/i', $hay, $m)) {
            $season = (int)$m[1];
        }
        if (preg_match('/(?:قسمت|Episode|Ep\.?|E)\s*0*(\d+)/iu', $hay, $m)) {
            $episode = (int)$m[1];
        }
    }

    return [$season, $episode];
}

function serialblog_parse_series_header($text) {
    $text = serialblog_clean_text($text);
    $out = [];
    if (!preg_match('/فصل\s*[:：]\s*([0-9]+)/u', $text)) {
        return $out;
    }
    if (preg_match('/فصل\s*[:：]\s*([0-9]+)/u', $text, $m)) {
        $out['season'] = (int)$m[1];
    }
    if (preg_match('/کیفیت\s*[:：]\s*(.*?)(?:\s*\/\s*میانگین|\s*\/\s*ورژن|\s*\/\s*قسمت|$)/u', $text, $m)) {
        $out['quality'] = serialblog_normalize_quality($m[1]);
    }
    if (preg_match('/میانگین\s*حجم\s*[:：]\s*(.*?)(?:\s*\/\s*ورژن|\s*\/\s*قسمت|$)/u', $text, $m)) {
        $out['size'] = serialblog_clean_text($m[1]);
    }
    if (preg_match('/ورژن\s*[:：]\s*(.*?)(?:\s*\/\s*قسمت|$)/u', $text, $m)) {
        $out['version'] = serialblog_clean_text($m[1]);
        $out['type'] = serialblog_download_type_from_text($out['version']);
    }
    if (preg_match('/قسمت\s*ها\s*[:：]\s*([0-9]+)/u', $text, $m)) {
        $out['episode_count'] = (int)$m[1];
    }
    return $out;
}

function serialblog_push_download(&$downloads, &$seen, $href, $label = '', $contextText = '', $meta = []) {
    $href = serialblog_abs_url($href);
    if ($href === '' || !serialblog_is_media_url($href)) {
        return;
    }
    if (preg_match('~/Trailer_|/trailer_|Trailer_~i', $href)) {
        return;
    }
    if (isset($seen[$href])) {
        return;
    }
    $seen[$href] = true;

    $label = serialblog_clean_text($label);
    $contextText = serialblog_clean_text($contextText);
    $metaText = implode(' ', array_map('strval', $meta));
    $allText = trim($label . ' ' . $contextText . ' ' . $metaText . ' ' . $href);

    $quality = $meta['quality'] ?? '';
    if ($quality === '') {
        $quality = serialblog_quality_from_text($allText);
    }
    $quality = serialblog_normalize_quality($quality);

    $size = $meta['size'] ?? '';
    if ($size === '') {
        $size = serialblog_infer_size_from_text($allText);
    }

    $type = $meta['type'] ?? '';
    if ($type === '') {
        $type = serialblog_download_type_from_text($allText);
    }
    $version = $meta['version'] ?? serialblog_type_fa($type);
    if ($version === '') {
        $version = serialblog_infer_version_from_url_text($href, $allText);
    }

    [$season, $episode] = serialblog_season_episode_from_text_url(
        $label . ' ' . $contextText,
        $href,
        $meta['season'] ?? null,
        $meta['episode'] ?? null
    );

    $downloads[] = [
        'label' => $label !== '' ? $label : ('دانلود ' . ($quality !== '' ? $quality : '')),
        'url' => $href,
        'quality' => $quality,
        'type' => $type,
        'type_fa' => serialblog_type_fa($type),
        'version' => $version,
        'size' => $size,
        'season' => $season,
        'episode' => $episode,
        'media_type' => 'video',
        'audio_only' => false,
        'source' => 'serialblog'
    ];
}

function serialblog_build_download_groups($downloads) {
    $groups = [];
    foreach ($downloads as $dl) {
        $isSeries = isset($dl['season']) && $dl['season'] !== null;
        $version = $dl['version'] ?: ($dl['type_fa'] ?: 'لینک دانلود');
        $seasonPart = $isSeries ? ('فصل ' . (int)$dl['season'] . ' - ') : '';
        $key = ($isSeries ? ('S' . (int)$dl['season'] . '|') : '') . ($dl['type'] ?? '') . '|' . $version . '|' . ($isSeries ? ($dl['quality'] ?? '') : '');
        if (!isset($groups[$key])) {
            $groups[$key] = [
                'title' => $seasonPart . $version . ($isSeries && !empty($dl['quality']) ? (' - ' . $dl['quality']) : ''),
                'type' => $dl['type'] ?? '',
                'type_fa' => $dl['type_fa'] ?? '',
                'version' => $version,
                'season' => $isSeries ? (int)$dl['season'] : null,
                'quality' => $isSeries ? ($dl['quality'] ?? '') : '',
                'links' => []
            ];
        }
        $groups[$key]['links'][] = $dl;
    }
    return array_values($groups);
}

function serialblog_build_seasons($downloads) {
    $map = [];
    foreach ($downloads as $dl) {
        if (!isset($dl['season']) || $dl['season'] === null) continue;
        $s = (int)$dl['season'];
        $e = isset($dl['episode']) && $dl['episode'] !== null ? (int)$dl['episode'] : 0;
        if (!isset($map[$s])) {
            $map[$s] = ['season' => $s, 'episodes' => []];
        }
        if (!isset($map[$s]['episodes'][$e])) {
            $map[$s]['episodes'][$e] = ['episode' => $e, 'links' => []];
        }
        $map[$s]['episodes'][$e]['links'][] = $dl;
    }
    ksort($map, SORT_NUMERIC);
    foreach ($map as &$season) {
        ksort($season['episodes'], SORT_NUMERIC);
        $season['episodes'] = array_values($season['episodes']);
    }
    unset($season);
    return array_values($map);
}

function serialblog_sort_downloads(&$downloads) {
    usort($downloads, function($a, $b) {
        $sa = $a['season'] ?? 0;
        $sb = $b['season'] ?? 0;
        if ((int)$sa !== (int)$sb) return (int)$sa - (int)$sb;
        $ea = $a['episode'] ?? 0;
        $eb = $b['episode'] ?? 0;
        if ((int)$ea !== (int)$eb) return (int)$ea - (int)$eb;
        $typeOrder = ['softsub' => 0, 'hardsub' => 1, 'subtitle' => 2, 'dubbed' => 3, '' => 9];
        $ta = $typeOrder[$a['type'] ?? ''] ?? 9;
        $tb = $typeOrder[$b['type'] ?? ''] ?? 9;
        if ($ta !== $tb) return $ta - $tb;
        return serialblog_quality_rank($b['quality'] ?? '') - serialblog_quality_rank($a['quality'] ?? '');
    });
}

function serialblog_extract_downloads($xpath, $contentType = '') {
    $box = serialblog_first_node($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," download_box ")][1]');
    $downloads = [];
    $seen = [];
    if (!$box) {
        return [
            'has_download_box' => false,
            'has_dubbed' => false,
            'has_subtitle' => false,
            'downloads' => [],
            'download_groups' => [],
            'seasons' => [],
            'has_downloads' => false,
        ];
    }

    $boxText = serialblog_clean_text($box->textContent);
    $currentMeta = [];

    $paragraphs = $xpath->query('.//p', $box);
    if ($paragraphs) {
        foreach ($paragraphs as $p) {
            $pText = serialblog_clean_text($p->textContent);
            if ($pText === '') continue;

            $seriesHeader = serialblog_parse_series_header($pText);
            if (!empty($seriesHeader)) {
                $currentMeta = $seriesHeader;
            } elseif (mb_strpos($pText, 'نسخه') !== false && $xpath->query('.//a[@href]', $p)->length === 0) {
                $currentMeta = [
                    'version' => $pText,
                    'type' => serialblog_download_type_from_text($pText),
                ];
            }

            $anchors = $xpath->query('.//a[@href]', $p);
            if (!$anchors || $anchors->length === 0) continue;
            foreach ($anchors as $a) {
                serialblog_push_download(
                    $downloads,
                    $seen,
                    $a->getAttribute('href'),
                    $a->textContent,
                    $pText,
                    $currentMeta
                );
            }
        }
    }

    // Fallback for alternate templates where direct media anchors are not inside <p>.
    $allAnchors = $xpath->query('.//a[@href]', $box);
    if ($allAnchors) {
        foreach ($allAnchors as $a) {
            $parentText = $a->parentNode ? serialblog_clean_text($a->parentNode->textContent) : '';
            serialblog_push_download($downloads, $seen, $a->getAttribute('href'), $a->textContent, $parentText, []);
        }
    }

    if ($contentType === 'movie') {
        foreach ($downloads as &$download) {
            $download['season'] = null;
            $download['episode'] = null;
        }
        unset($download);
    }

    serialblog_sort_downloads($downloads);
    $groups = serialblog_build_download_groups($downloads);
    $seasons = $contentType === 'movie' ? [] : serialblog_build_seasons($downloads);

    $hasDubbed = false;
    $hasSubtitle = false;
    foreach ($downloads as $dl) {
        if (($dl['type'] ?? '') === 'dubbed') $hasDubbed = true;
        if (in_array(($dl['type'] ?? ''), ['softsub', 'hardsub', 'subtitle'], true)) $hasSubtitle = true;
    }

    return [
        'has_download_box' => true,
        'has_dubbed' => $hasDubbed || (mb_strpos($boxText, 'دوبله') !== false),
        'has_subtitle' => $hasSubtitle || (mb_strpos($boxText, 'زیرنویس') !== false || mb_strpos($boxText, 'سافت') !== false),
        'downloads' => $downloads,
        'download_groups' => $groups,
        'seasons' => $seasons,
        'has_downloads' => count($downloads) > 0,
    ];
}

function serialblog_parse_details_html($html, $url, $type = '') {
    $xpath = serialblog_xpath_from_html($html);

    $title = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," --titles ")]//h1[1]');
    if ($title === '') {
        $title = serialblog_node_text($xpath, '//h1[1]');
    }
    if ($title === '') {
        $title = serialblog_meta_content($xpath, 'og:title');
    }
    if ($title === '') {
        $title = serialblog_node_text($xpath, '//title[1]');
    }

    $titleEn = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," --titles ")]//h2[1]');

    $canonical = serialblog_node_attr($xpath, '//link[@rel="canonical"][1]', 'href');
    $canonical = $canonical !== '' ? serialblog_abs_url($canonical) : serialblog_abs_url($url);

    $poster = serialblog_meta_content($xpath, 'og:image');
    if ($poster === '') {
        $poster = serialblog_node_attr($xpath, '//article[contains(concat(" ",normalize-space(@class)," ")," postItems ")]//img[contains(concat(" ",normalize-space(@class)," ")," wp-post-image ")][1]', 'src');
    }
    if ($poster === '') {
        $poster = serialblog_node_attr($xpath, '//img[contains(concat(" ",normalize-space(@class)," ")," wp-post-image ")][1]', 'src');
    }
    $poster = serialblog_abs_url($poster);

    $description = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-hero-wrapper ")]//div[contains(concat(" ",normalize-space(@class)," ")," -plot ")][1]//p[1]');
    if ($description === '') {
        $description = serialblog_meta_content($xpath, 'description');
    }
    if ($description === '') {
        $description = serialblog_meta_content($xpath, 'og:description');
    }

    $rating = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")]//*[contains(concat(" ",normalize-space(@class)," ")," -rate-value ")][1]');
    if ($rating === '') {
        $detailTextForRating = serialblog_node_text($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")][1]');
        if (preg_match('/([0-9]+(?:\.[0-9]+)?)\s*\/\s*10/u', $detailTextForRating, $m)) {
            $rating = $m[1];
        }
    }

    $genres = serialblog_all_node_texts($xpath, '//div[contains(concat(" ",normalize-space(@class)," ")," post-details ")]//*[contains(concat(" ",normalize-space(@class)," ")," pr-genre ")]//a');
    $year = serialblog_detail_first_link_for_label($xpath, 'سال انتشار');
    if ($year === '') {
        $year = serialblog_detail_first_link_for_label($xpath, 'سال تولید');
    }
    if ($year === '' && preg_match('/\b(19|20)\d{2}\b/u', $title, $m)) {
        $year = $m[0];
    }

    $countries = serialblog_detail_links_for_label($xpath, 'محصول');
    $extraInfo = serialblog_parse_fm_info_items($xpath);

    $slug = serialblog_slug_from_url($canonical);
    $detectedType = serialblog_type_from_url($canonical, $title);
    if ($type === 'movie' || $type === 'series') {
        $detectedType = $type;
    }
    $title = serialblog_clean_display_title($title, $detectedType);
    $downloadInfo = serialblog_extract_downloads($xpath, $detectedType);

    $movie = [
        'id' => $slug,
        'slug' => $slug,
        'title' => $title,
        'title_fa' => $title,
        'title_en' => $titleEn,
        'year' => $year,
        'poster' => $poster,
        'rating' => $rating,
        'imdb_id' => serialblog_extract_imdb_id($xpath),
        'imdb_votes' => serialblog_extract_votes($xpath),
        'type' => $detectedType,
        'genres' => $genres,
        'actors' => [],
        'directors' => [],
        'countries' => $countries,
        'language' => $extraInfo['language'] ?? '',
        'duration' => $extraInfo['duration'] ?? '',
        'age_rating' => $extraInfo['age_rating'] ?? '',
        'quality' => $extraInfo['quality'] ?? '',
        'network' => $extraInfo['network'] ?? '',
        'broadcast_years' => $extraInfo['broadcast_years'] ?? '',
        'description' => $description,
        'url' => $canonical,
        'source_url' => $canonical,
        'has_dubbed' => $downloadInfo['has_dubbed'],
        'has_subtitle' => $downloadInfo['has_subtitle'],
    ];

    return [
        'status' => 'success',
        'source' => 'serialblog',
        'mode' => 'standalone_metadata',
        'movie' => $movie,
        'item' => $movie,
        'downloads' => $downloadInfo['downloads'],
        'download_groups' => $downloadInfo['download_groups'],
        'seasons' => $downloadInfo['seasons'],
        'has_downloads' => $downloadInfo['has_downloads'],
        'downloads_count' => count($downloadInfo['downloads']),
        'has_download_box' => $downloadInfo['has_download_box'],
        'request_url' => $url,
        'note' => 'Standalone package: metadata is scoped to detail blocks and download links are parsed only from .download_box.'
    ];
}

function serialblog_get_details($identifier, $type = '') {
    $url = serialblog_detail_url($identifier, $type);
    $html = serialblog_get_html($url);
    $detail = serialblog_parse_details_html($html, $url, $type);

    $movie = $detail['movie'] ?? $detail['item'] ?? [];
    $genres = isset($movie['genres']) && is_array($movie['genres']) ? $movie['genres'] : [];
    $resolvedType = (($movie['type'] ?? '') === 'series') ? 'series' : 'movie';
    $currentId = (string)($movie['id'] ?? $movie['slug'] ?? '');
    $related = [];
    $seen = [];

    foreach (array_slice($genres, 0, 2) as $genre) {
        $genre = trim((string)$genre);
        if ($genre === '') continue;
        try {
            $listing = serialblog_get_genre($genre, $resolvedType, 1);
            $items = $listing['items'] ?? $listing['movies'] ?? [];
            foreach ($items as $candidate) {
                if (!is_array($candidate)) continue;
                $candidateId = (string)($candidate['id'] ?? $candidate['slug'] ?? '');
                if ($candidateId !== '' && $candidateId === $currentId) continue;
                $dedupe = $candidateId !== '' ? $candidateId : (string)($candidate['url'] ?? $candidate['title'] ?? '');
                if ($dedupe === '' || isset($seen[$dedupe])) continue;
                $seen[$dedupe] = true;
                $candidate['archive'] = 2;
                if (empty($candidate['source_url']) && !empty($candidate['url'])) $candidate['source_url'] = $candidate['url'];
                $related[] = $candidate;
                if (count($related) >= 14) break 2;
            }
        } catch (Throwable $ignored) {
        }
    }

    $detail['related'] = $related;
    if (isset($detail['movie']) && is_array($detail['movie'])) $detail['movie']['related'] = $related;
    if (isset($detail['item']) && is_array($detail['item'])) $detail['item']['related'] = $related;
    return $detail;
}
