<?php
require_once __DIR__ . '/site_content_control.php';
if (!function_exists('bm_support_card_escape')) {
    function bm_support_card_escape($value) {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('bm_support_card_html')) {
    function bm_support_card_html($pageKey = '', $variant = 'mini') {
        static $stylePrinted = false;

        $lang = isset($GLOBALS['userLang']) && strtolower((string)$GLOBALS['userLang']) === 'en' ? 'en' : 'fa';

        if (!bm_site_bool('support_enabled', true)) return '';
        $pageKeyNormalized = strtolower(trim((string)$pageKey));
        $pageRules = [
            'index' => 'support_show_home',
            'movie' => 'support_show_movie',
            'profile' => 'support_show_profile',
            'collection' => 'support_show_collection',
            'collections' => 'support_show_collection',
            'catalog' => 'support_show_catalog',
            'view_all' => 'support_show_catalog',
            'search' => 'support_show_catalog',
        ];
        foreach ($pageRules as $needle => $settingKey) {
            if ($pageKeyNormalized !== '' && str_contains($pageKeyNormalized, $needle) && !bm_site_bool($settingKey, true)) return '';
        }

        $texts = [
            'fa' => [
                'title' => (string)bm_site_get('support_title_fa', 'همراه بانک مووی باش'),
                'desc'  => (string)bm_site_get('support_description_fa', 'حمایت تو کمک می‌کند هزینه سرور و توسعه سبک‌تر شود و آرشیو بانک مووی همیشه به‌روز بماند.'),
                'btn'   => (string)bm_site_get('support_button_fa', 'حمایت از ادامه مسیر'),
            ],
            'en' => [
                'title' => (string)bm_site_get('support_title_en', 'Keep BankMovie Going'),
                'desc'  => (string)bm_site_get('support_description_en', 'Your support helps cover server costs and keeps the archive updated.'),
                'btn'   => (string)bm_site_get('support_button_en', 'Support the Project'),
            ]
        ];
        $t = $texts[$lang];
        $donateUrl = trim((string)bm_site_get('support_url', 'https://daramet.com/manuel'));
        if ($donateUrl === '') return '';
        $supportAccent = (string)bm_site_get('support_accent_color', '#8224e3');
        $openNewTab = bm_site_bool('support_open_new_tab', true);
        $safeVariant = preg_replace('/[^a-z0-9_-]/i', '', (string)$variant) ?: 'mini';

        ob_start();

        if (!$stylePrinted) {
            $stylePrinted = true;
            ?>
<style>
.bm-ad-support-row{
    --bm-support-accent:var(--accent,#8224e3);
    --bm-support-rgb:var(--accent-rgb,130,36,227);
    max-width:1280px;
    margin:14px auto;
    padding:0 16px;
    display:grid;
    grid-template-columns:minmax(0,1fr) 255px;
    gap:12px;
    align-items:stretch;
    direction:rtl;
    position:relative;
    z-index:2;
}
.bm-ad-support-row[data-lang="en"]{direction:ltr}
.bm-ad-support-main{min-width:0}
.bm-ad-support-side{min-width:0;display:flex}
.bm-support-wrap{
    --bm-support-accent:var(--accent,#8224e3);
    --bm-support-rgb:var(--accent-rgb,130,36,227);
    max-width:1280px;
    margin:14px auto;
    padding:0 16px;
    direction:rtl;
    position:relative;
    z-index:2;
}
.bm-support-wrap[data-lang="en"]{direction:ltr}
.bm-support-card{
    width:100%;
    min-height:94px;
    display:grid;
    grid-template-columns:48px minmax(0,1fr);
    gap:12px;
    align-items:center;
    padding:13px 14px;
    border-radius:22px;
    background:
        radial-gradient(circle at 15% 20%,rgba(var(--bm-support-rgb),.38),transparent 44%),
        linear-gradient(135deg,rgba(var(--bm-support-rgb),.26),rgba(15,16,24,.88) 52%,rgba(var(--bm-support-rgb),.18));
    border:1px solid rgba(var(--bm-support-rgb),.24);
    box-shadow:0 14px 34px rgba(0,0,0,.22), inset 0 1px 0 rgba(255,255,255,.06);
    overflow:hidden;
    position:relative;
}
.bm-support-card:before{
    content:"";
    position:absolute;
    inset:-40% auto auto -16%;
    width:160px;
    height:160px;
    border-radius:50%;
    background:radial-gradient(circle,rgba(var(--bm-support-rgb),.36),transparent 68%);
    pointer-events:none;
}
.bm-support-card:after{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(110deg,transparent,rgba(255,255,255,.055),transparent);
    transform:translateX(-110%);
    animation:bmSupportShine 4.4s ease-in-out infinite;
    pointer-events:none;
}
@keyframes bmSupportShine{0%,55%{transform:translateX(-110%)}100%{transform:translateX(110%)}}
.bm-support-icon{
    position:relative;
    z-index:1;
    width:48px;
    height:48px;
    border-radius:17px;
    display:grid;
    place-items:center;
    color:#fff;
    background:linear-gradient(135deg,var(--bm-support-accent),rgba(255,255,255,.16));
    border:1px solid rgba(255,255,255,.14);
    box-shadow:0 10px 24px rgba(var(--bm-support-rgb),.28);
}
.bm-support-icon svg{width:24px;height:24px;fill:currentColor}
.bm-support-body{position:relative;z-index:1;min-width:0;text-align:right}
.bm-support-wrap[data-lang="en"] .bm-support-body,
.bm-ad-support-row[data-lang="en"] .bm-support-body{text-align:left}
.bm-support-title{
    margin:0 0 5px;
    color:#fff;
    font-size:14px;
    font-weight:950;
    line-height:1.35;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
}
.bm-support-desc{
    margin:0 0 10px;
    color:rgba(255,255,255,.76);
    font-size:11px;
    line-height:1.75;
}
.bm-support-btn{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:7px;
    min-height:32px;
    padding:0 13px;
    border-radius:999px;
    background:linear-gradient(135deg,var(--bm-support-accent),rgba(var(--bm-support-rgb),.72));
    color:#fff;
    text-decoration:none;
    font-size:11.5px;
    font-weight:950;
    box-shadow:0 10px 22px rgba(var(--bm-support-rgb),.25);
    transition:transform .18s ease,box-shadow .18s ease;
}
.bm-support-btn:hover{transform:translateY(-1px);box-shadow:0 14px 26px rgba(var(--bm-support-rgb),.32)}
.bm-support-btn svg{width:14px;height:14px;fill:currentColor}
.bm-support-wrap.is-standalone{max-width:760px}
.bm-support-wrap.is-standalone .bm-support-card{min-height:86px}
.bm-support-wrap.is-download-links{max-width:none;margin:14px 0;padding:0}.bm-support-wrap.is-download-links .bm-support-card{min-height:76px;border-radius:18px;grid-template-columns:42px minmax(0,1fr);padding:11px 13px}.bm-support-wrap.is-download-links .bm-support-icon{width:42px;height:42px;border-radius:14px}.bm-support-wrap.is-download-links .bm-support-desc{margin-bottom:7px}.bm-support-wrap.is-download-links .bm-support-title{font-size:13px}
@media(max-width:980px){
    .bm-ad-support-row{grid-template-columns:1fr;gap:8px;margin:10px auto;padding:0 12px}
    .bm-ad-support-side{display:block}
    .bm-support-wrap{margin:10px auto;padding:0 12px}
    .bm-support-card{
        min-height:72px;
        grid-template-columns:38px minmax(0,1fr);
        gap:10px;
        padding:10px 11px;
        border-radius:18px;
    }
    .bm-support-icon{width:38px;height:38px;border-radius:14px}
    .bm-support-icon svg{width:19px;height:19px}
    .bm-support-title{font-size:12.5px;margin-bottom:3px}
    .bm-support-desc{font-size:10.5px;line-height:1.55;margin-bottom:7px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
    .bm-support-btn{min-height:28px;padding:0 11px;font-size:10.5px}
}
@media(max-width:520px){
    .bm-ad-support-row{margin:8px auto;padding:0 10px}
    .bm-support-wrap{margin:8px auto;padding:0 10px}
    .bm-support-card{
        min-height:64px;
        grid-template-columns:34px minmax(0,1fr);
        padding:9px 10px;
        border-radius:16px;
    }
    .bm-support-icon{width:34px;height:34px;border-radius:12px}
    .bm-support-title{font-size:12px}
    .bm-support-desc{font-size:10px;line-height:1.45;margin-bottom:6px}
    .bm-support-btn{min-height:26px;font-size:10px;padding:0 10px}
}
</style>
            <?php
        }
        ?>
<section class="bm-support-wrap <?= $safeVariant === 'standalone' ? 'is-standalone' : ($safeVariant === 'download-links' ? 'is-download-links' : '') ?>" style="--bm-support-accent:<?= bm_support_card_escape($supportAccent) ?>" data-lang="<?= bm_support_card_escape($lang) ?>" data-page="<?= bm_support_card_escape($pageKey) ?>">
    <div class="bm-support-card">
        <div class="bm-support-icon" aria-hidden="true">
            <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
        </div>
        <div class="bm-support-body">
            <h2 class="bm-support-title"><?= bm_support_card_escape($t['title']) ?></h2>
            <p class="bm-support-desc"><?= bm_support_card_escape($t['desc']) ?></p>
            <a class="bm-support-btn" href="<?= bm_support_card_escape($donateUrl) ?>" <?= $openNewTab ? 'target="_blank" rel="noopener noreferrer"' : '' ?>>
                <svg viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
                <?= bm_support_card_escape($t['btn']) ?>
            </a>
        </div>
    </div>
</section>
        <?php
        return ob_get_clean();
    }
}

if (!function_exists('bm_support_reserve_render')) {
    function bm_support_reserve_render(): bool {
        if (!bm_site_bool('support_single_instance', true)) return true;
        if (!empty($GLOBALS['bm_support_card_rendered'])) return false;
        $GLOBALS['bm_support_card_rendered'] = true;
        return true;
    }
}

if (!function_exists('bm_render_support_card')) {
    function bm_render_support_card($pageKey = '', $variant = 'standalone') {
        $html = bm_support_card_html($pageKey, $variant);
        if (trim($html) === '' || !bm_support_reserve_render()) return;
        echo $html;
    }
}


if (!function_exists('bm_render_download_support_card')) {
    function bm_render_download_support_card(string $archiveKey = 'archive2'): void {
        static $rendered = false;
        if ($rendered || !bm_site_bool('support_show_between_downloads', true)) return;

        $html = bm_support_card_html('movie_downloads_' . $archiveKey, 'standalone');
        if (trim($html) === '' || !bm_support_reserve_render()) return;
        $rendered = true;

        echo '<div class="bm-support-movie-placement" data-bm-support-movie-placement hidden>' . $html . '</div>';
        ?>
<script id="bm-support-movie-relocator">
(function(){
  'use strict';
  function placeSupportCard(){
    var holder=document.querySelector('[data-bm-support-movie-placement]');
    if(!holder) return;
    var target=document.querySelector('#arc1DownloadSection,#downloadSection,.download-section');
    if(!target || !target.parentNode) return;
    target.parentNode.insertBefore(holder,target);
    holder.hidden=false;
    holder.removeAttribute('hidden');
    holder.classList.add('is-placed');
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',placeSupportCard,{once:true});
  else placeSupportCard();
  window.addEventListener('load',placeSupportCard,{once:true});
})();
</script>
        <?php
    }
}

if (!function_exists('bm_render_ad_with_support_card')) {
    function bm_render_ad_with_support_card(PDO $pdo, string $position, string $variant = 'wide', int $limit = 1, string $pageKey = ''): string {
        if (!function_exists('bm_render_ad_slot')) {
            return bm_support_card_html($pageKey, 'standalone');
        }

        if ($variant === 'floating') {
            return bm_render_ad_slot($pdo, $position, $variant, $limit);
        }

        $adHtml = bm_render_ad_slot($pdo, $position, $variant, $limit);
        $normalizedPage = strtolower(trim($pageKey));
        if (str_contains($normalizedPage, 'movie') && bm_site_bool('support_show_between_downloads', true) && !bm_site_bool('support_movie_next_to_ads', false)) return $adHtml;
        if (!bm_site_bool('support_show_next_to_ads', true)) return $adHtml;
        $supportHtml = bm_support_card_html($pageKey ?: $position, 'side');
        if (trim($supportHtml) === '' || !bm_support_reserve_render()) return $adHtml;
        $lang = isset($GLOBALS['userLang']) && strtolower((string)$GLOBALS['userLang']) === 'en' ? 'en' : 'fa';

        if (trim($adHtml) === '') {
            return $supportHtml;
        }

        return '<div class="bm-ad-support-row" data-lang="' . bm_support_card_escape($lang) . '" data-ad-position="' . bm_support_card_escape($position) . '">'
            . '<div class="bm-ad-support-main">' . $adHtml . '</div>'
            . '<div class="bm-ad-support-side">' . $supportHtml . '</div>'
            . '</div>';
    }
}
