<?php
require_once __DIR__ . '/security_bootstrap.php';

/**
 * BankMovie daily unique-IP analytics (JSON only)
 *
 * - No analytics data is written to MySQL.
 * - One visitor is counted once per calendar day by a one-way IP hash.
 * - The JSON file automatically resets when the date changes.
 * - Deleting storage/daily_unique_visitors.json manually is also safe;
 *   it will be recreated on the next valid visit.
 */

if (!function_exists('bm_analytics_json_path')) {
    function bm_analytics_json_path(): string
    {
        return dirname(__DIR__) . '/storage/daily_unique_visitors.json';
    }
}

if (!function_exists('bm_analytics_today')) {
    function bm_analytics_today(): string
    {
        // Uses the timezone configured by the project/PHP server.
        return date('Y-m-d');
    }
}

if (!function_exists('bm_analytics_is_bot')) {
    function bm_analytics_is_bot(): bool
    {
        $ua = strtolower(trim((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
        if ($ua === '') {
            return true;
        }

        return (bool)preg_match(
            '/bot|crawler|spider|slurp|bingpreview|facebookexternalhit|telegrambot|whatsapp|curl|wget|python-requests|go-http-client|headless|lighthouse|pagespeed|uptimerobot|monitoring/i',
            $ua
        );
    }
}

if (!function_exists('bm_analytics_client_ip')) {
    function bm_analytics_client_ip(): string
    {
        $candidates = [
            $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '',
            $_SERVER['HTTP_X_REAL_IP'] ?? '',
            $_SERVER['HTTP_X_FORWARDED_FOR'] ?? '',
            $_SERVER['REMOTE_ADDR'] ?? '',
        ];

        foreach ($candidates as $candidate) {
            foreach (explode(',', (string)$candidate) as $value) {
                $ip = trim($value);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '';
    }
}

if (!function_exists('bm_analytics_client_ip_hash')) {
    function bm_analytics_client_ip_hash(): string
    {
        $ip = bm_analytics_client_ip();
        if ($ip === '') {
            return '';
        }

        // The date makes the hash different each day, so visitors cannot be
        // followed across multiple days through this analytics file.
        return hash('sha256', $ip . '|' . bm_analytics_today() . '|bankmovie-daily-unique-v1');
    }
}

if (!function_exists('bm_analytics_empty_data')) {
    function bm_analytics_empty_data(): array
    {
        return [
            'date' => bm_analytics_today(),
            'unique_count' => 0,
            'unique_ip_hashes' => [],
            'updated_at' => date('c'),
        ];
    }
}

if (!function_exists('bm_analytics_normalize_data')) {
    function bm_analytics_normalize_data($data): array
    {
        if (!is_array($data) || (string)($data['date'] ?? '') !== bm_analytics_today()) {
            return bm_analytics_empty_data();
        }

        $hashes = $data['unique_ip_hashes'] ?? [];
        if (!is_array($hashes)) {
            $hashes = [];
        }

        $clean = [];
        foreach ($hashes as $hash) {
            $hash = strtolower(trim((string)$hash));
            if (preg_match('/^[a-f0-9]{64}$/', $hash)) {
                $clean[$hash] = true;
            }
        }

        $hashes = array_keys($clean);

        return [
            'date' => bm_analytics_today(),
            'unique_count' => count($hashes),
            'unique_ip_hashes' => $hashes,
            'updated_at' => (string)($data['updated_at'] ?? date('c')),
        ];
    }
}

if (!function_exists('bm_analytics_ensure_storage')) {
    function bm_analytics_ensure_storage(): bool
    {
        $directory = dirname(bm_analytics_json_path());
        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return false;
        }

        return is_writable($directory) || is_writable(bm_analytics_json_path());
    }
}

if (!function_exists('bm_analytics_read')) {
    function bm_analytics_read(): array
    {
        $path = bm_analytics_json_path();
        if (!is_file($path)) {
            return bm_analytics_empty_data();
        }

        $handle = @fopen($path, 'rb');
        if (!$handle) {
            return bm_analytics_empty_data();
        }

        try {
            @flock($handle, LOCK_SH);
            $raw = stream_get_contents($handle);
            @flock($handle, LOCK_UN);
        } finally {
            fclose($handle);
        }

        $decoded = json_decode((string)$raw, true);
        return bm_analytics_normalize_data($decoded);
    }
}

if (!function_exists('bm_analytics_track_unique_ip')) {
    function bm_analytics_track_unique_ip(): void
    {
        if (PHP_SAPI === 'cli' || bm_analytics_is_bot()) {
            return;
        }

        $ipHash = bm_analytics_client_ip_hash();
        if ($ipHash === '' || !bm_analytics_ensure_storage()) {
            return;
        }

        $path = bm_analytics_json_path();
        $handle = @fopen($path, 'c+');
        if (!$handle) {
            return;
        }

        try {
            if (!@flock($handle, LOCK_EX)) {
                return;
            }

            rewind($handle);
            $raw = stream_get_contents($handle);
            $data = bm_analytics_normalize_data(json_decode((string)$raw, true));

            // An associative lookup avoids duplicate hashes and is faster than
            // repeatedly scanning a large numeric array.
            $lookup = array_fill_keys($data['unique_ip_hashes'], true);
            if (isset($lookup[$ipHash])) {
                @flock($handle, LOCK_UN);
                return;
            }

            $data['unique_ip_hashes'][] = $ipHash;
            $data['unique_count'] = count($data['unique_ip_hashes']);
            $data['updated_at'] = date('c');

            $json = json_encode(
                $data,
                JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
            );
            if ($json === false) {
                @flock($handle, LOCK_UN);
                return;
            }

            rewind($handle);
            ftruncate($handle, 0);
            fwrite($handle, $json . PHP_EOL);
            fflush($handle);
            @flock($handle, LOCK_UN);
        } catch (Throwable $e) {
            @flock($handle, LOCK_UN);
        } finally {
            fclose($handle);
        }
    }
}

// Compatibility functions: existing pages can keep their current calls.
if (!function_exists('bm_analytics_init')) {
    function bm_analytics_init(PDO $pdo): void
    {
        // Intentionally empty: JSON analytics creates no database tables.
    }
}

if (!function_exists('bm_analytics_track')) {
    function bm_analytics_track(PDO $pdo, array $ctx = []): void
    {
        bm_analytics_track_unique_ip();
    }
}

if (!function_exists('bm_analytics_live_count')) {
    function bm_analytics_live_count(PDO $pdo, int $minutes = 5): int
    {
        // Live tracking is intentionally disabled.
        return 0;
    }
}

if (!function_exists('bm_analytics_today_count')) {
    function bm_analytics_today_count(PDO $pdo): int
    {
        $data = bm_analytics_read();
        return (int)($data['unique_count'] ?? 0);
    }
}

if (!function_exists('bm_analytics_total_count')) {
    function bm_analytics_total_count(PDO $pdo): int
    {
        // There is no lifetime history; only today's unique count is retained.
        return bm_analytics_today_count($pdo);
    }
}

if (!function_exists('bm_analytics_summary')) {
    function bm_analytics_summary(PDO $pdo): array
    {
        $today = bm_analytics_today_count($pdo);
        return [
            'live' => 0,
            'today' => $today,
            'total' => $today,
        ];
    }
}

if (!function_exists('bm_analytics_popular_movies')) {
    function bm_analytics_popular_movies(PDO $pdo, int $limit = 12, int $days = 14): array
    {
        // Per-page/per-movie analytics are intentionally not stored.
        return [];
    }
}
?>
