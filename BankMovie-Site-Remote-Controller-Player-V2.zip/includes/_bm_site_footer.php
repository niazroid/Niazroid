<?php
require_once __DIR__ . '/site_content_control.php';

if (!function_exists('bm_footer_e')) {
    function bm_footer_e($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

if (!function_exists('bm_footer_icon_svg')) {
    function bm_footer_icon_svg(string $icon): string
    {
        $icons = [
            'categories' => '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
            'search' => '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/><path d="M7.5 11h7M11 7.5v7"/>',
            'mobile' => '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M10 5h4M11 18h2"/>',
            'home' => '<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"/>',
            'collection' => '<rect x="4" y="4" width="13" height="16" rx="2"/><path d="M8 8h5M8 12h5M20 7v12a1 1 0 0 1-1 1"/>',
            'play' => '<circle cx="12" cy="12" r="9"/><path d="m10 8 6 4-6 4V8Z"/>',
            'star' => '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-2.9-5.6 2.9 1.1-6.2L3 9.6l6.2-.9L12 3Z"/>',
            'boxoffice' => '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/><path d="m3 7 5-4 5 4 5-3"/>',
            'globe' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/>',
            'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/>',
            'support' => '<path d="M4 13a8 8 0 0 1 16 0"/><path d="M4 13v4a2 2 0 0 0 2 2h2v-7H4ZM20 13v4a2 2 0 0 1-2 2h-2v-7h4Z"/>',
            'telegram' => '<path d="m21 3-7.2 18-4.1-6.1L3 11.5 21 3Z"/><path d="m9.7 14.9 4.1-3.8"/>',
            'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1"/>',
            'download' => '<path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/>',
            'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>',
            'link' => '<path d="M10 13a5 5 0 0 0 7.1.1l2-2a5 5 0 0 0-7.1-7.1l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.1-.1l-2 2A5 5 0 0 0 12 20l1.1-1.1"/>',
        ];
        return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . ($icons[$icon] ?? $icons['link']) . '</svg>';
    }
}

if (!function_exists('bm_footer_useful_links')) {
    function bm_footer_useful_links(): array
    {
        $raw = (string)bm_site_get('footer_links_json', function_exists('bm_site_default_footer_links_json') ? bm_site_default_footer_links_json() : '[]');
        $items = json_decode($raw, true);
        if (!is_array($items)) $items = [];
        $links = [];
        foreach ($items as $item) {
            if (!is_array($item) || empty($item['enabled'])) continue;
            $label = trim((string)($item['label'] ?? ''));
            $url = trim((string)($item['url'] ?? ''));
            if ($label === '' || $url === '' || preg_match('~^(javascript|data|vbscript):~i', $url)) continue;
            $links[] = [
                'label' => $label,
                'url' => $url,
                'icon' => (string)($item['icon'] ?? 'link'),
                'new_tab' => !empty($item['new_tab']),
                'nofollow' => !empty($item['nofollow']),
            ];
        }

        // V14861968: Box Office is a first-class public page and should always
        // be discoverable from the useful-links row, even on installations
        // whose footer JSON predates the Box Office feature.
        $hasBoxOffice = false;
        foreach ($links as $link) {
            $path = trim((string)(parse_url((string)($link['url'] ?? ''), PHP_URL_PATH) ?? ''), '/');
            if (preg_match('~^boxoffice(?:\.php)?$~i', $path)) { $hasBoxOffice = true; break; }
        }
        if (!$hasBoxOffice) {
            $links[] = [
                'label' => 'باکس آفیس',
                'url' => '/boxoffice',
                'icon' => 'boxoffice',
                'new_tab' => false,
                'nofollow' => false,
            ];
        }
        return $links;
    }
}

if (!function_exists('bm_render_site_footer')) {
    function bm_render_site_footer($lang = 'fa'): void
    {
        if (!bm_site_bool('footer_enabled', true)) return;

        $fa = strtolower((string)$lang) !== 'en';
        $dir = $fa ? 'rtl' : 'ltr';

        $headline = trim((string)bm_site_get(
            'footer_headline_fa',
            $fa ? 'یک دنیا فیلم و سریال' : 'A World of Movies and Series'
        ));
        if ($headline === '' || $headline === 'همیشه یک داستان تازه برای دیدن هست') {
            $headline = $fa ? 'یک دنیا فیلم و سریال' : 'A World of Movies and Series';
        }

        $about = trim((string)bm_site_get(
            'footer_about_text_fa',
            $fa
                ? 'بانک مووی، مسیر ساده و سریع برای کشف فیلم‌ها، سریال‌ها، کالکشن‌های سینمایی و تازه‌ترین آثار.'
                : 'BankMovie is a fast and simple way to discover movies, series, cinematic collections, and new releases.'
        ));
        if ($about === '' || $about === 'بانک مووی؛ مرجع سریع و ساده برای پیدا کردن فیلم، سریال و انیمه.') {
            $about = $fa
                ? 'بانک مووی، مسیر ساده و سریع برای کشف فیلم‌ها، سریال‌ها، کالکشن‌های سینمایی و تازه‌ترین آثار.'
                : 'BankMovie is a fast and simple way to discover movies, series, cinematic collections, and new releases.';
        }

        $copyright = trim((string)bm_site_get(
            'footer_copyright_fa',
            $fa ? 'تمامی حقوق برای بانک مووی محفوظ است.' : 'All rights reserved for BankMovie.'
        ));

        $telegram = trim((string)bm_site_get('telegram_url', 'https://t.me/bankmovie_org'));
        $instagram = trim((string)bm_site_get('instagram_url', 'https://instagram.com/bankmovie_org'));
        $usefulLinks = bm_footer_useful_links();
        $usefulTitle = trim((string)bm_site_get('footer_links_title_fa', $fa ? 'لینک‌های مفید' : 'Useful Links'));

        // V62: recommended external players — fully controlled from Site Manager > Footer.
        $playersEnabled = bm_site_bool('footer_players_enabled', true);
        $vlcEnabled = bm_site_bool('footer_vlc_enabled', true);
        $vlcLabel = trim((string)bm_site_get('footer_vlc_label_fa', $fa ? 'دانلود VLC' : 'Download VLC'));
        $vlcDownloadUrl = trim((string)bm_site_get('footer_vlc_download_url', ''));
        if ($vlcDownloadUrl === '') $vlcDownloadUrl = '#';
        $mxPlayerEnabled = bm_site_bool('footer_mxplayer_enabled', true);
        $mxPlayerLabel = trim((string)bm_site_get('footer_mxplayer_label_fa', $fa ? 'دانلود MX Player' : 'Download MX Player'));
        $mxPlayerDownloadUrl = trim((string)bm_site_get('footer_mxplayer_download_url', ''));
        if ($mxPlayerDownloadUrl === '') $mxPlayerDownloadUrl = '#';


        // V14861964: pages with a fixed mobile nav used to reserve 96-110px on the
        // body (or on the footer itself). Once the nav auto-hides, that reserve
        // becomes a visible black strip below the real footer. Keep the fix scoped
        // to the pages reported by the user so unrelated layouts are untouched.
        $bmFooterRequestPath = trim((string)(parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?? '/'), '/');
        $bmFooterFlushMobile = (bool)preg_match('~^(?:boxoffice|player|actors|search|view_all|collection|collections)(?:\.php)?(?:/|$)~i', $bmFooterRequestPath);
        ?>
<style>
.bm-global-footer{
    --bm-footer-blue:#2586ff;
    --bm-footer-blue-rgb:37,134,255;
    width:min(1180px,calc(100% - 28px));
    margin:44px auto 24px!important;
    color:#fff;
    direction:<?= bm_footer_e($dir) ?>;
    font-family:var(--bm-footer-font,var(--bm-site-font,inherit));
    position:relative;
    z-index:2;
}
.bm-global-footer *{box-sizing:border-box}
.bm-footer-stage{
    position:relative;
    overflow:hidden;
    border-radius:30px;
    border:1px solid rgba(255,255,255,.08);
    background:
        radial-gradient(circle at 88% 108%,rgba(var(--bm-footer-blue-rgb),.24),transparent 34%),
        radial-gradient(circle at 8% -15%,rgba(125,78,255,.12),transparent 30%),
        linear-gradient(180deg,#111319 0%,#0c0e14 100%);
    box-shadow:0 30px 90px rgba(0,0,0,.38),inset 0 1px 0 rgba(255,255,255,.035);
    padding:30px 38px 22px;
}
.bm-footer-stage:before{
    content:"";
    position:absolute;
    inset:0;
    pointer-events:none;
    background:linear-gradient(115deg,transparent 28%,rgba(255,255,255,.025),transparent 72%);
}
.bm-footer-useful{
    position:relative;
    z-index:2;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:22px;
    padding-bottom:25px;
    border-bottom:1px solid rgba(255,255,255,.06);
}
.bm-footer-useful-title{
    margin:0;
    font-size:14px;
    font-weight:950;
    color:rgba(255,255,255,.96);
    white-space:nowrap;
}
.bm-footer-links{
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:12px;
    flex-wrap:wrap;
}
.bm-footer-links a{
    min-height:42px;
    padding:0 16px;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:9px;
    color:rgba(255,255,255,.82);
    text-decoration:none;
    font-size:12px;
    font-weight:850;
    border-radius:14px;
    border:1px solid rgba(255,255,255,.08);
    background:rgba(255,255,255,.035);
    transition:transform .2s ease,color .2s ease,border-color .2s ease,background .2s ease;
}
.bm-footer-links a:hover{
    transform:translateY(-2px);
    color:#fff;
    border-color:rgba(var(--bm-footer-blue-rgb),.42);
    background:rgba(var(--bm-footer-blue-rgb),.11);
}
.bm-footer-links svg{width:17px;height:17px;stroke:currentColor;flex:0 0 auto}
.bm-footer-links a.bm-footer-player-link{gap:8px}
.bm-footer-links a.bm-footer-player-link img{
    width:21px;
    height:21px;
    flex:0 0 21px;
    object-fit:contain;
    border-radius:5px;
}

.bm-footer-categories{
    position:relative;
    z-index:2;
    display:grid;
    grid-template-columns:auto minmax(0,1fr);
    align-items:center;
    gap:22px;
    padding:20px 0;
    border-bottom:1px solid rgba(255,255,255,.06);
}
.bm-footer-categories-title{
    margin:0;
    font-size:13px;
    font-weight:950;
    color:rgba(255,255,255,.94);
    white-space:nowrap;
}
.bm-footer-category-links{
    display:grid;
    grid-template-columns:repeat(4,minmax(0,1fr));
    gap:9px;
}
.bm-footer-category-links a{
    min-height:48px;
    padding:0 13px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:10px;
    color:rgba(255,255,255,.82);
    text-decoration:none;
    border:1px solid rgba(255,255,255,.075);
    border-radius:15px;
    background:linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.022));
    font-size:11.5px;
    font-weight:900;
    transition:transform .2s ease,border-color .2s ease,background .2s ease,color .2s ease;
}
.bm-footer-category-links a:after{
    content:"‹";
    width:25px;
    height:25px;
    flex:0 0 25px;
    display:grid;
    place-items:center;
    border-radius:9px;
    background:rgba(var(--bm-footer-blue-rgb),.12);
    color:rgb(var(--bm-footer-blue-rgb));
    font-size:19px;
    line-height:1;
}
.bm-footer-category-links a:hover{
    transform:translateY(-2px);
    color:#fff;
    border-color:rgba(var(--bm-footer-blue-rgb),.36);
    background:rgba(var(--bm-footer-blue-rgb),.085);
}

.bm-footer-core{
    position:relative;
    z-index:2;
    display:grid;
    grid-template-columns:minmax(0,1fr) auto;
    gap:34px;
    align-items:center;
    padding:38px 0 30px;
}
.bm-footer-about{text-align:start;min-width:0}
.bm-footer-about h2{
    margin:0 0 13px;
    font-size:clamp(23px,2.5vw,34px);
    line-height:1.45;
    font-weight:950;
    color:#fff;
}
.bm-footer-about p{
    max-width:760px;
    margin:0;
    color:rgba(255,255,255,.65);
    font-size:clamp(12px,1.15vw,15px);
    line-height:2;
}
.bm-footer-socials{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:11px;
    flex-wrap:wrap;
}
.bm-footer-socials a{
    width:48px;
    height:48px;
    border-radius:16px;
    display:grid;
    place-items:center;
    color:#fff;
    text-decoration:none;
    border:1px solid rgba(255,255,255,.14);
    background:linear-gradient(145deg,rgba(255,255,255,.12),rgba(255,255,255,.035));
    box-shadow:0 12px 24px rgba(0,0,0,.24),inset 0 1px 1px rgba(255,255,255,.12);
    transition:transform .2s ease,border-color .2s ease,background .2s ease;
}
.bm-footer-socials a:hover{
    transform:translateY(-3px);
    border-color:rgba(var(--bm-footer-blue-rgb),.5);
    background:rgba(var(--bm-footer-blue-rgb),.15);
}
.bm-footer-socials svg{width:22px;height:22px}
.bm-footer-copyright{
    position:relative;
    z-index:2;
    padding-top:18px;
    border-top:1px solid rgba(255,255,255,.055);
    color:rgba(255,255,255,.38);
    text-align:center;
    font-size:10.5px;
}
@media(max-width:900px){
    .bm-global-footer{width:calc(100% - 20px);margin:28px auto 96px!important}
    .bm-footer-stage{border-radius:24px;padding:23px 22px 18px}
    .bm-footer-useful{align-items:flex-start;flex-direction:column;gap:15px;padding-bottom:21px}
    .bm-footer-links{width:100%;justify-content:flex-start}
    .bm-footer-categories{grid-template-columns:1fr;gap:12px;padding:18px 0}
    .bm-footer-category-links{grid-template-columns:repeat(2,minmax(0,1fr));width:100%}
    .bm-footer-core{grid-template-columns:1fr;gap:24px;padding:30px 0 24px}
    .bm-footer-socials{justify-content:flex-start}
}
@media(max-width:560px){
    .bm-global-footer{
        width:100%;
        margin:8px auto max(8px,env(safe-area-inset-bottom))!important;
    }
    .bm-footer-stage{border-radius:0;border-inline:0;padding:12px 12px 9px}
    .bm-footer-useful{padding:0 0 11px;gap:9px}
    .bm-footer-useful-title{font-size:12px}
    .bm-footer-links{display:flex;flex-wrap:wrap;gap:6px}
    .bm-footer-links a{flex:1 1 112px;min-width:0;min-height:39px;padding:0 8px;font-size:9.5px;border-radius:11px;gap:5px;white-space:nowrap}
    .bm-footer-links svg{width:13px;height:13px}
    .bm-footer-categories{padding:10px 0;gap:7px}
    .bm-footer-categories-title{font-size:11px}
    .bm-footer-category-links{grid-template-columns:repeat(2,minmax(0,1fr));gap:6px}
    .bm-footer-category-links a{min-height:39px;border-radius:11px;padding:0 9px;font-size:9.5px}
    .bm-footer-category-links a:after{width:22px;height:22px;flex-basis:22px;border-radius:8px;font-size:16px}

    .bm-footer-core{padding:14px 0 11px;gap:11px}
    .bm-footer-about h2{font-size:18px;line-height:1.5;margin-bottom:6px}
    .bm-footer-about p{font-size:10.8px;line-height:1.65}
    .bm-footer-socials{justify-content:center;gap:8px}
    .bm-footer-socials a{width:40px;height:40px;border-radius:13px}
    .bm-footer-socials svg{width:18px;height:18px}
    .bm-footer-copyright{padding-top:9px;font-size:8.7px}
}
</style>
<?php if ($bmFooterFlushMobile): ?>
<style id="bm-footer-mobile-flush-v14861964">
/* Remove the artificial space after the footer on the affected public pages. */
@media(max-width:991px){
    body{padding-bottom:0!important}
    .bm-global-footer{margin-bottom:0!important;padding-bottom:0!important}
}
@media(max-width:560px){
    .bm-global-footer{margin-bottom:0!important}
}
</style>
<?php endif; ?>
<style id="bm-main-footer-static-fit-v60">
/* V60 — Profile-style footer fit for STATIC/low-end navigation.
   Goal: no black empty strip before/under the real site footer.
   The fixed dock visually sits over the footer's own bottom breathing room. */
@media (max-width:991px){
    html.bm-nav-static body{
        padding-bottom:0!important;
    }

    /* Many mobile pages reserve 96–110px inside <main> for a floating dock.
       Static nav does not need that pre-footer reserve; it creates the large black hole
       visible on VIP/Categories. Keep only a small natural content-to-footer gap. */
    html.bm-nav-static body > main:last-of-type{
        padding-bottom:16px!important;
    }

    /* Pull the real BankMovie footer close to the content instead of leaving 44px + page reserve. */
    html.bm-nav-static .bm-global-footer{
        margin-top:16px!important;
        margin-bottom:0!important;
        padding-bottom:0!important;
    }

    /* Same successful pattern used on Profile: reserve space INSIDE the footer stage.
       So links/copyright stay above the fixed dock while the footer background continues
       all the way behind it — no detached black strip. */
    html.bm-nav-static .bm-footer-stage{
        padding-bottom:calc(92px + env(safe-area-inset-bottom,0px))!important;
    }
}
</style>
<footer class="bm-global-footer" aria-label="<?= $fa ? 'فوتر بانک مووی' : 'BankMovie footer' ?>">
    <div class="bm-footer-stage">
        <?php if (bm_site_bool('footer_quick_links_enabled', true) && $usefulLinks): ?>
        <section class="bm-footer-useful" aria-label="<?= bm_footer_e($usefulTitle !== '' ? $usefulTitle : ($fa ? 'لینک‌های مفید' : 'Useful links')) ?>">
            <?php if ($usefulTitle !== ''): ?><h3 class="bm-footer-useful-title"><?= bm_footer_e($usefulTitle) ?></h3><?php endif; ?>
            <nav class="bm-footer-links">
                <?php foreach ($usefulLinks as $footerLink):
                    $rel = ['noopener'];
                    if (!empty($footerLink['nofollow'])) $rel[] = 'nofollow';
                ?>
                <a href="<?= bm_footer_e($footerLink['url']) ?>" <?= !empty($footerLink['new_tab']) ? 'target="_blank"' : '' ?> rel="<?= bm_footer_e(implode(' ', $rel)) ?>">
                    <?= bm_footer_icon_svg($footerLink['icon']) ?>
                    <span><?= bm_footer_e($footerLink['label']) ?></span>
                </a>
                <?php endforeach; ?>

                <?php if ($playersEnabled && $vlcEnabled): ?>
                <a class="bm-footer-player-link" href="<?= bm_footer_e($vlcDownloadUrl) ?>" target="_blank" rel="noopener" aria-label="<?= bm_footer_e($vlcLabel) ?>">
                    <img src="/assets/img/player-vlc.png" alt="VLC" loading="lazy" decoding="async">
                    <span><?= bm_footer_e($vlcLabel) ?></span>
                </a>
                <?php endif; ?>

                <?php if ($playersEnabled && $mxPlayerEnabled): ?>
                <a class="bm-footer-player-link" href="<?= bm_footer_e($mxPlayerDownloadUrl) ?>" target="_blank" rel="noopener" aria-label="<?= bm_footer_e($mxPlayerLabel) ?>">
                    <img src="/assets/img/player-mxplayer-icon.png" alt="MX Player" loading="lazy" decoding="async">
                    <span><?= bm_footer_e($mxPlayerLabel) ?></span>
                </a>
                <?php endif; ?>
            </nav>
        </section>
        <?php endif; ?>

        <section class="bm-footer-core">
            <div class="bm-footer-about">
                <h2><?= bm_footer_e($headline) ?></h2>
                <?php if (bm_site_bool('footer_about_enabled', true) && $about !== ''): ?>
                    <p><?= nl2br(bm_footer_e($about)) ?></p>
                <?php endif; ?>
            </div>

            <div class="bm-footer-socials" aria-label="<?= $fa ? 'شبکه‌های اجتماعی' : 'Social networks' ?>">
                <?php if (bm_site_bool('telegram_enabled', true) && $telegram !== ''): ?>
                    <a href="<?= bm_footer_e($telegram) ?>" target="_blank" rel="noopener" aria-label="Telegram">
                        <svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.7 3.7 2.9 10.8c-1 .4-1 1-.2 1.3l4.6 1.4 1.7 5.4c.2.6.3.8.7.8.3 0 .5-.1.8-.4l2.2-2.1 4.5 3.3c.8.5 1.4.2 1.6-.8l3-14c.2-1.2-.5-1.7-1.1-2z"/></svg>
                    </a>
                <?php endif; ?>
                <?php if (bm_site_bool('instagram_enabled', true) && $instagram !== ''): ?>
                    <a href="<?= bm_footer_e($instagram) ?>" target="_blank" rel="noopener" aria-label="Instagram">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg>
                    </a>
                <?php endif; ?>
            </div>
        </section>

        <?php if ($copyright !== ''): ?><div class="bm-footer-copyright"><?= bm_footer_e($copyright) ?></div><?php endif; ?>
    </div>
</footer>

<?php
    }
}
