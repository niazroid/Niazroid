<?php
/**
 * BankMovie Yektanet control layer.
 * Runtime settings are stored in the private BankMovie directory when possible.
 */
require_once __DIR__ . '/security_bootstrap.php';

if (!function_exists('bm_yektanet_defaults')) {
    function bm_yektanet_defaults(): array
    {
        return [
            'policy_version' => 8,
            'enabled' => true,
            'publisher_url' => 'https://cdn.yektanet.com/superscript/jTS6ONCO/native-bankmoviee.ir-47428/yn_pub.js',
            'domains' => ['bankmoviee.ir'],
            'pages' => [
                'index.php', 'movie.php', 'search.php', 'actors.php', 'collections.php',
                'collection.php', 'catalog.php', 'view_all.php', 'player.php',
                'top_rated_by_users.php'
            ],
            'slots' => [
                'home_top' => ['label' => 'بالای صفحه اصلی', 'enabled' => false, 'device' => 'all', 'html' => ''],
                'home_middle' => ['label' => 'میانه صفحه اصلی', 'enabled' => false, 'device' => 'all', 'html' => ''],
                'home_bottom' => ['label' => 'پایین صفحه اصلی', 'enabled' => false, 'device' => 'all', 'html' => ''],
                'movie_page' => ['label' => 'صفحه فیلم و سریال', 'enabled' => false, 'device' => 'all', 'html' => ''],
                'mobile' => ['label' => 'جایگاه موبایل عادی (بدون شناوری)', 'enabled' => false, 'device' => 'mobile', 'html' => ''],
                'global_banner' => [
                    'label' => 'جایگاه اصلی یکتانت؛ صفحه اصلی، قبل دانلود و صفحات محتوایی',
                    'enabled' => true,
                    'device' => 'all',
                    'html' => '<div class="yn-bnr" id="ynpos-19355"></div>',
                ],
            ],
            'updated_at' => null,
        ];
    }
}

if (!function_exists('bm_yektanet_settings_path')) {
    function bm_yektanet_settings_path(): string
    {
        return function_exists('bm_security_private_path')
            ? bm_security_private_path('yektanet_settings.json')
            : dirname(__DIR__) . '/yektanet_settings.json';
    }
}

if (!function_exists('bm_yektanet_legacy_settings_path')) {
    function bm_yektanet_legacy_settings_path(): string
    {
        return dirname(__DIR__) . '/yektanet_settings.json';
    }
}

if (!function_exists('bm_yektanet_clean_host')) {
    function bm_yektanet_clean_host(string $host): string
    {
        $host = strtolower(trim($host));
        $host = preg_replace('/:\d+$/', '', $host) ?: '';
        return preg_replace('/^www\./', '', $host) ?: '';
    }
}

if (!function_exists('bm_yektanet_valid_publisher_url')) {
    function bm_yektanet_valid_publisher_url(string $url): string
    {
        $url = trim($url);
        $parts = @parse_url($url);
        if (!is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https') return '';
        if (strtolower((string)($parts['host'] ?? '')) !== 'cdn.yektanet.com') return '';
        if (!str_ends_with(strtolower((string)($parts['path'] ?? '')), '/yn_pub.js')) return '';
        return $url;
    }
}

if (!function_exists('bm_yektanet_normalize')) {
    function bm_yektanet_normalize(array $settings): array
    {
        $defaults = bm_yektanet_defaults();
        $out = $defaults;
        $savedPolicyVersion = max(0, (int)($settings['policy_version'] ?? 0));
        $out['policy_version'] = 8;
        $out['enabled'] = filter_var($settings['enabled'] ?? $defaults['enabled'], FILTER_VALIDATE_BOOLEAN);
        $publisher = bm_yektanet_valid_publisher_url((string)($settings['publisher_url'] ?? ''));
        $out['publisher_url'] = $publisher !== '' ? $publisher : $defaults['publisher_url'];

        // Ads are intentionally served only on bankmoviee.ir for the current campaign.
        // The publisher URL itself must remain exactly as issued by Yektanet.
        $out['domains'] = ['bankmoviee.ir'];

        $allowedPages = $defaults['pages'];
        $pages = [];
        foreach ((array)($settings['pages'] ?? $allowedPages) as $page) {
            $page = basename(trim((string)$page));
            if (in_array($page, $allowedPages, true)) $pages[] = $page;
        }
        $out['pages'] = array_values(array_unique($pages));

        // جایگاه ynpos-19355 باید در هر صفحه فقط یک بار وجود داشته باشد. اگر قبلاً
        // در یکی از جایگاه‌های صفحه اصلی ذخیره شده، آن را به جایگاه سراسری منتقل می‌کنیم.
        $globalPlacementId = 'ynpos-19355';
        $savedSlots = isset($settings['slots']) && is_array($settings['slots']) ? $settings['slots'] : [];
        $globalRow = isset($savedSlots['global_banner']) && is_array($savedSlots['global_banner'])
            ? $savedSlots['global_banner']
            : [];
        $globalHtml = trim((string)($globalRow['html'] ?? ''));
        foreach ($savedSlots as $legacyId => $legacyRow) {
            if ($legacyId === 'global_banner' || !is_array($legacyRow)) continue;
            $legacyHtml = (string)($legacyRow['html'] ?? '');
            if ($legacyHtml !== '' && stripos($legacyHtml, $globalPlacementId) !== false) {
                if ($globalHtml === '') {
                    $globalHtml = $legacyHtml;
                    $globalRow['html'] = $legacyHtml;
                    $globalRow['enabled'] = true;
                }
                $savedSlots[$legacyId]['html'] = '';
                $savedSlots[$legacyId]['enabled'] = false;
            }
        }
        if ($globalHtml === '') {
            $globalRow['html'] = $defaults['slots']['global_banner']['html'];
            $globalRow['enabled'] = true;
        }
        // v8 migration: keep the official placement available on both desktop and mobile,
        // keep it inline (never fixed/sticky), and lock ads to bankmoviee.ir only.
        if ($savedPolicyVersion < 8) {
            $out['enabled'] = true;
            $out['pages'] = $defaults['pages'];
            $globalRow['device'] = 'all';
            $globalRow['enabled'] = true;
            $globalRow['html'] = $defaults['slots']['global_banner']['html'];
        }
        $savedSlots['global_banner'] = $globalRow;

        foreach ($defaults['slots'] as $id => $def) {
            $row = isset($savedSlots[$id]) && is_array($savedSlots[$id]) ? $savedSlots[$id] : [];
            $device = strtolower(trim((string)($row['device'] ?? $def['device'])));
            if (!in_array($device, ['all', 'desktop', 'mobile'], true)) $device = $def['device'];
            $html = (string)($row['html'] ?? $def['html']);
            // Remove accidental PHP tags; Yektanet placements should be plain HTML/JS only.
            $html = preg_replace('/<\?(?:php|=)?|\?>/i', '', $html) ?? '';
            $out['slots'][$id] = [
                'label' => $def['label'],
                'enabled' => filter_var($row['enabled'] ?? $def['enabled'], FILTER_VALIDATE_BOOLEAN),
                'device' => $device,
                'html' => trim($html),
            ];
        }
        $out['updated_at'] = isset($settings['updated_at']) ? (string)$settings['updated_at'] : null;
        return $out;
    }
}

if (!function_exists('bm_yektanet_get_settings')) {
    function bm_yektanet_get_settings(): array
    {
        static $cache = null;
        if (is_array($cache)) return $cache;
        $data = [];
        foreach (array_unique([bm_yektanet_settings_path(), bm_yektanet_legacy_settings_path()]) as $path) {
            if (!is_file($path)) continue;
            $decoded = json_decode((string)@file_get_contents($path), true);
            if (is_array($decoded)) { $data = $decoded; break; }
        }

        // Import old manually edited slot file once when no settings JSON exists.
        if (!$data && is_file(__DIR__ . '/yektanet_slots.php')) {
            $legacy = require __DIR__ . '/yektanet_slots.php';
            if (is_array($legacy)) {
                $data = bm_yektanet_defaults();
                foreach ($data['slots'] as $id => $slot) {
                    $html = trim((string)($legacy[$id] ?? ''));
                    if ($html !== '') {
                        $data['slots'][$id]['html'] = $html;
                        $data['slots'][$id]['enabled'] = true;
                    }
                }
            }
        }
        return $cache = bm_yektanet_normalize($data);
    }
}

if (!function_exists('bm_yektanet_reset_cache')) {
    function bm_yektanet_reset_cache(): void
    {
        // Request-local cache resets naturally after redirects; this function documents intent.
    }
}

if (!function_exists('bm_yektanet_save_settings')) {
    function bm_yektanet_save_settings(array $settings): bool
    {
        $settings = bm_yektanet_normalize($settings);
        $settings['updated_at'] = gmdate('c');
        $json = json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($json)) return false;
        $paths = [bm_yektanet_settings_path(), bm_yektanet_legacy_settings_path()];
        foreach (array_unique($paths) as $path) {
            $dir = dirname($path);
            if (!is_dir($dir)) @mkdir($dir, 0700, true);
            $tmp = $path . '.tmp.' . getmypid();
            if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) { @unlink($tmp); continue; }
            @chmod($tmp, $path === bm_yektanet_settings_path() ? 0600 : 0644);
            if (@rename($tmp, $path)) return true;
            @unlink($tmp);
        }
        return false;
    }
}
