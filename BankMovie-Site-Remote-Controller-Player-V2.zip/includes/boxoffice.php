<?php
declare(strict_types=1);

/**
 * BankMovie Box Office service.
 * The upstream location is fixed server-side and never exposed to public clients.
 * Public requests are always served through BankMovie's shared 24-hour cache.
 */

if (!function_exists('bm_boxoffice_schema')) {
    function bm_boxoffice_schema(PDO $pdo): bool
    {
        static $ready = null;
        if (is_bool($ready)) return $ready;
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS bm_boxoffice_settings (
                id TINYINT UNSIGNED NOT NULL PRIMARY KEY,
                enabled TINYINT(1) NOT NULL DEFAULT 1,
                provider VARCHAR(32) NOT NULL DEFAULT 'darkmovis',
                api_key_enc TEXT NULL,
                cache_ttl INT UNSIGNED NOT NULL DEFAULT 86400,
                items_limit TINYINT UNSIGNED NOT NULL DEFAULT 10,
                alltime_enabled TINYINT(1) NOT NULL DEFAULT 0,
                last_test_status VARCHAR(24) NOT NULL DEFAULT 'idle',
                last_test_message VARCHAR(255) NOT NULL DEFAULT '',
                last_fetch_at INT UNSIGNED NOT NULL DEFAULT 0,
                updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            $pdo->exec("INSERT IGNORE INTO bm_boxoffice_settings (id, enabled, provider, cache_ttl, items_limit, alltime_enabled) VALUES (1,1,'darkmovis',86400,10,0)");
            $pdo->exec("UPDATE bm_boxoffice_settings SET provider='darkmovis', api_key_enc=NULL, alltime_enabled=0, cache_ttl=86400 WHERE id=1");

            $pdo->exec("CREATE TABLE IF NOT EXISTS bm_boxoffice_cache (
                cache_key VARCHAR(40) NOT NULL PRIMARY KEY,
                payload_json MEDIUMTEXT NOT NULL,
                provider VARCHAR(32) NOT NULL DEFAULT 'darkmovis',
                fetched_at INT UNSIGNED NOT NULL DEFAULT 0,
                expires_at INT UNSIGNED NOT NULL DEFAULT 0,
                last_error VARCHAR(500) NOT NULL DEFAULT '',
                INDEX idx_boxoffice_expiry (expires_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            // Old-provider cache must never leak into the new feed.
            $pdo->exec("DELETE FROM bm_boxoffice_cache WHERE cache_key IN ('paraj_weekend','tv_weekend','tv_alltime','boxoffice_weekend_v2') OR provider LIKE 'paraj%' OR provider LIKE 'tv_%' OR provider LIKE 'punkmovie%'");
            return $ready = true;
        } catch (Throwable $e) {
            error_log('BoxOffice schema error: ' . $e->getMessage());
            return $ready = false;
        }
    }
}

if (!function_exists('bm_boxoffice_settings')) {
    function bm_boxoffice_settings(PDO $pdo, bool $withSecret = false): array
    {
        bm_boxoffice_schema($pdo);
        $defaults = [
            'enabled' => 1,
            'provider' => 'darkmovis',
            'cache_ttl' => 86400,
            'items_limit' => 10,
            'alltime_enabled' => 0,
            'last_test_status' => 'idle',
            'last_test_message' => '',
            'last_fetch_at' => 0,
        ];
        try {
            $row = $pdo->query("SELECT * FROM bm_boxoffice_settings WHERE id=1 LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $e) {
            $row = [];
        }
        $settings = array_merge($defaults, $row);
        $settings['enabled'] = !empty($settings['enabled']);
        $settings['provider'] = 'darkmovis';
        $settings['cache_ttl'] = 86400;
        $settings['items_limit'] = max(5, min(25, (int)$settings['items_limit']));
        $settings['alltime_enabled'] = false;
        $settings['configured'] = true;
        $settings['api_key_source'] = 'not_required';
        $settings['api_key_masked'] = '';
        if ($withSecret) $settings['api_key'] = '';
        return $settings;
    }
}

if (!function_exists('bm_boxoffice_save_settings')) {
    function bm_boxoffice_save_settings(PDO $pdo, array $input): void
    {
        if (!bm_boxoffice_schema($pdo)) throw new RuntimeException('ساختار دیتابیس باکس آفیس آماده نیست.');
        $current = bm_boxoffice_settings($pdo, false);
        $enabled = !empty($input['enabled']) ? 1 : 0;
        $limit = max(5, min(25, (int)($input['items_limit'] ?? $current['items_limit'] ?? 10)));
        $stmt = $pdo->prepare("UPDATE bm_boxoffice_settings SET enabled=?,provider='darkmovis',cache_ttl=86400,items_limit=?,alltime_enabled=0,api_key_enc=NULL WHERE id=1");
        $stmt->execute([$enabled, $limit]);
    }
}

if (!function_exists('bm_boxoffice_ascii_digits')) {
    function bm_boxoffice_ascii_digits(string $value): string
    {
        return strtr($value, [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
            '٫'=>'.','٬'=>',',
        ]);
    }
}

if (!function_exists('bm_boxoffice_clean_text')) {
    function bm_boxoffice_clean_text(string $value): string
    {
        $value = html_entity_decode(strip_tags($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $value = preg_replace('/[\x{200C}\x{200D}\x{FEFF}]/u', ' ', $value) ?? $value;
        $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
        return trim($value);
    }
}

if (!function_exists('bm_boxoffice_money_number')) {
    function bm_boxoffice_money_number($value): float
    {
        $raw = trim(bm_boxoffice_ascii_digits((string)$value));
        if ($raw === '' || $raw === '-') return 0.0;
        $upper = strtoupper($raw);
        $mult = 1.0;
        if (str_contains($raw, 'میلیارد') || preg_match('/\bB\b|\dB/i', $upper)) $mult = 1_000_000_000.0;
        elseif (str_contains($raw, 'میلیون') || preg_match('/\bM\b|\dM/i', $upper)) $mult = 1_000_000.0;
        elseif (str_contains($raw, 'هزار') || preg_match('/\bK\b|\dK/i', $upper)) $mult = 1_000.0;
        $clean = str_replace([',', '٬', '$', '€', '£'], '', $raw);
        if (!preg_match('/-?\d+(?:\.\d+)?/', $clean, $m)) return 0.0;
        return max(0.0, (float)$m[0] * $mult);
    }
}

if (!function_exists('bm_boxoffice_extract_imdb')) {
    function bm_boxoffice_extract_imdb(string $value): string
    {
        $value = html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        if (preg_match('/\b(tt\d{5,12})\b/i', $value, $m)) return strtolower($m[1]);
        return '';
    }
}

if (!function_exists('bm_boxoffice_http_get_feed')) {
    function bm_boxoffice_http_get_feed(): string
    {
        $url = 'https://darkmovis.com/boxoffice/';
        $parts = parse_url($url);
        $host = strtolower((string)($parts['host'] ?? ''));
        $path = rtrim((string)($parts['path'] ?? ''), '/');
        if (($parts['scheme'] ?? '') !== 'https' || $host !== 'darkmovis.com' || $path !== '/boxoffice') {
            throw new RuntimeException('آدرس سرویس باکس آفیس معتبر نیست.');
        }

        $maxBytes = 5_500_000;
        $body = '';
        $status = 0;
        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            if ($ch === false) throw new RuntimeException('راه‌اندازی ارتباط انجام نشد.');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => false,
                CURLOPT_FOLLOWLOCATION => false,
                CURLOPT_CONNECTTIMEOUT => 5,
                CURLOPT_TIMEOUT => 15,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
                CURLOPT_HTTPHEADER => [
                    'Accept: text/html,application/xhtml+xml',
                    'Accept-Language: fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7',
                    'Cache-Control: no-cache',
                    'Pragma: no-cache',
                ],
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
                CURLOPT_ENCODING => '',
                CURLOPT_COOKIE => '',
                CURLOPT_REFERER => 'https://darkmovis.com/',
                CURLOPT_WRITEFUNCTION => static function ($ch, string $chunk) use (&$body, $maxBytes): int {
                    if (strlen($body) + strlen($chunk) > $maxBytes) return 0;
                    $body .= $chunk;
                    return strlen($chunk);
                },
            ]);
            $ok = curl_exec($ch);
            $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
            $errNo = curl_errno($ch);
            $err = curl_error($ch);
            curl_close($ch);
            if ($ok === false) {
                if ($errNo === CURLE_WRITE_ERROR && strlen($body) >= $maxBytes - 65536) throw new RuntimeException('پاسخ باکس آفیس بیش از حد بزرگ بود.');
                throw new RuntimeException('ارتباط با سرویس باکس آفیس برقرار نشد' . ($err !== '' ? ': ' . $err : '.'));
            }
        } else {
            $context = stream_context_create([
                'http' => [
                    'method' => 'GET',
                    'timeout' => 15,
                    'ignore_errors' => true,
                    'follow_location' => 0,
                    'max_redirects' => 0,
                    'header' => "Accept: text/html,application/xhtml+xml\r\nAccept-Language: fa-IR,fa;q=0.9,en-US;q=0.8,en;q=0.7\r\nCache-Control: no-cache\r\nUser-Agent: Mozilla/5.0 BankMovie\r\nConnection: close\r\n",
                ],
                'ssl' => ['verify_peer' => true, 'verify_peer_name' => true],
            ]);
            $result = @file_get_contents($url, false, $context, 0, $maxBytes + 1);
            if (!is_string($result)) throw new RuntimeException('ارتباط HTTPS با سرویس باکس آفیس برقرار نشد.');
            if (strlen($result) > $maxBytes) throw new RuntimeException('پاسخ باکس آفیس بیش از حد بزرگ بود.');
            $body = $result;
            foreach (($http_response_header ?? []) as $line) {
                if (preg_match('~^HTTP/\S+\s+(\d{3})~i', (string)$line, $m)) $status = (int)$m[1];
            }
        }

        if ($status < 200 || $status >= 300) throw new RuntimeException('سرویس باکس آفیس با کد HTTP ' . $status . ' پاسخ داد.');
        if ($body === '' || strlen($body) < 1500) throw new RuntimeException('پاسخ باکس آفیس خالی یا ناقص بود.');
        return $body;
    }
}

if (!function_exists('bm_boxoffice_safe_upstream_image')) {
    function bm_boxoffice_safe_upstream_image(string $value): string
    {
        $value = trim(html_entity_decode($value, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if ($value === '' || strlen($value) > 1800) return '';
        if (str_starts_with($value, '//')) $value = 'https:' . $value;
        $parts = parse_url($value);
        if (($parts['scheme'] ?? '') !== 'https') return '';
        $host = strtolower((string)($parts['host'] ?? ''));
        if (!in_array($host, ['darkmovis.com','www.darkmovis.com','m.media-amazon.com'], true)) return '';
        if (str_contains(strtolower((string)($parts['path'] ?? '')), 'darkmovis-placeholder')) return '';
        return $value;
    }
}

if (!function_exists('bm_boxoffice_dom_class_query')) {
    function bm_boxoffice_dom_class_query(string $class): string
    {
        return 'contains(concat(" ", normalize-space(@class), " "), " ' . $class . ' ")';
    }
}

if (!function_exists('bm_boxoffice_parse_feed_dom')) {
    function bm_boxoffice_parse_feed_dom(string $html, int $limit): array
    {
        $limit = max(5, min(25, $limit));
        if (!class_exists('DOMDocument') || !class_exists('DOMXPath')) return ['items'=>[], 'updated_text'=>''];
        $previous = libxml_use_internal_errors(true);
        $dom = new DOMDocument();
        $loaded = @$dom->loadHTML($html, LIBXML_NOERROR | LIBXML_NOWARNING | LIBXML_NONET);
        libxml_clear_errors();
        libxml_use_internal_errors($previous);
        if (!$loaded) return ['items'=>[], 'updated_text'=>''];
        $xp = new DOMXPath($dom);

        $updatedText = '';
        $updateNodes = $xp->query('//*[' . bm_boxoffice_dom_class_query('boxOfficeLastUpdate') . ']');
        if ($updateNodes && $updateNodes->length) {
            $updatedText = bm_boxoffice_clean_text((string)$updateNodes->item(0)->textContent);
            $updatedText = preg_replace('/^آخرین\s*بروزرسانی\s*:\s*/u', '', $updatedText) ?? $updatedText;
        }

        $nodes = $xp->query('//*[' . bm_boxoffice_dom_class_query('boxOffice_item') . ']');
        if (!$nodes) return ['items'=>[], 'updated_text'=>$updatedText];
        $items = [];
        foreach ($nodes as $node) {
            if (count($items) >= $limit) break;
            $titleNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('boxOffice_title') . ']//h3[1]', $node);
            if (!$titleNodes || !$titleNodes->length) continue;
            $title = bm_boxoffice_clean_text((string)$titleNodes->item(0)->textContent);
            if ($title === '' || mb_strlen($title, 'UTF-8') > 180) continue;

            $rank = count($items) + 1;
            $rankNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('rank') . '][1]', $node);
            if ($rankNodes && $rankNodes->length) {
                $rankText = bm_boxoffice_ascii_digits(bm_boxoffice_clean_text((string)$rankNodes->item(0)->textContent));
                if (preg_match('/\d{1,3}/', $rankText, $m)) $rank = max(1, min(999, (int)$m[0]));
            }

            $image = '';
            $imageNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('boxOffice_image') . ']//img[1]', $node);
            if ($imageNodes && $imageNodes->length) {
                foreach (['src','data-src','data-lazy-src'] as $attr) {
                    $candidate = bm_boxoffice_safe_upstream_image((string)$imageNodes->item(0)->getAttribute($attr));
                    if ($candidate !== '') { $image = $candidate; break; }
                }
            }

            $href = '';
            $linkNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('boxOffice_title') . ']//a[1]', $node);
            if (!$linkNodes || !$linkNodes->length) $linkNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('boxOffice_image') . ']//a[1]', $node);
            if ($linkNodes && $linkNodes->length) $href = (string)$linkNodes->item(0)->getAttribute('href');
            $imdb = bm_boxoffice_extract_imdb($href);

            $weeks = 0;
            $weekendText = '';
            $grossText = '';
            $metaNodes = $xp->query('.//*[' . bm_boxoffice_dom_class_query('boxOffice__meta') . ']//li', $node);
            if ($metaNodes) {
                foreach ($metaNodes as $metaNode) {
                    $line = bm_boxoffice_clean_text((string)$metaNode->textContent);
                    $spanNodes = $xp->query('.//span[1]', $metaNode);
                    $value = $spanNodes && $spanNodes->length ? bm_boxoffice_clean_text((string)$spanNodes->item(0)->textContent) : $line;
                    if (preg_match('/هفته\s*اکران/u', $line)) {
                        $ascii = bm_boxoffice_ascii_digits($value);
                        if (preg_match('/\d{1,3}/', $ascii, $m)) $weeks = max(0, min(999, (int)$m[0]));
                    } elseif (preg_match('/فروش\s*(?:اخر|آخر)\s*هفته/u', $line)) {
                        $weekendText = $value;
                    } elseif (preg_match('/فروش\s*کل/u', $line)) {
                        $grossText = $value;
                    }
                }
            }

            $weekendValue = bm_boxoffice_money_number($weekendText);
            $grossValue = bm_boxoffice_money_number($grossText);
            if ($weekendValue <= 0 && $grossValue <= 0) continue;
            $items[] = [
                'rank' => $rank,
                'id' => $imdb,
                'title' => $title,
                'image' => $image,
                'year' => '',
                'weekend' => $weekendText,
                'gross' => $grossText,
                'weeks' => $weeks,
                'weekend_value' => $weekendValue,
                'gross_value' => $grossValue,
                'mode' => 'weekend',
            ];
        }
        usort($items, static fn(array $a, array $b): int => ((int)$a['rank']) <=> ((int)$b['rank']));
        return ['items'=>array_slice($items, 0, $limit), 'updated_text'=>$updatedText];
    }
}

if (!function_exists('bm_boxoffice_parse_feed_regex')) {
    function bm_boxoffice_parse_feed_regex(string $html, int $limit): array
    {
        $limit = max(5, min(25, $limit));
        $updatedText = '';
        if (preg_match('~class=["\'][^"\']*boxOfficeLastUpdate[^"\']*["\'][^>]*>(.*?)</div>~isu', $html, $um)) {
            $updatedText = bm_boxoffice_clean_text($um[1]);
            $updatedText = preg_replace('/^آخرین\s*بروزرسانی\s*:\s*/u', '', $updatedText) ?? $updatedText;
        }
        $parts = preg_split('~<div[^>]+class=["\'][^"\']*\bboxOffice_item\b[^"\']*["\'][^>]*>~isu', $html);
        if (!is_array($parts) || count($parts) < 2) return ['items'=>[], 'updated_text'=>$updatedText];
        array_shift($parts);
        $items = [];
        foreach ($parts as $chunk) {
            if (count($items) >= $limit) break;
            if (!preg_match('~<h3[^>]*>(.*?)</h3>~isu', $chunk, $tm)) continue;
            $title = bm_boxoffice_clean_text($tm[1]);
            if ($title === '') continue;
            $rank = count($items) + 1;
            if (preg_match('~<span[^>]+class=["\'][^"\']*\brank\b[^"\']*["\'][^>]*>(.*?)</span>~isu', $chunk, $rm)) {
                $r = bm_boxoffice_ascii_digits(bm_boxoffice_clean_text($rm[1]));
                if (preg_match('/\d{1,3}/', $r, $m)) $rank = max(1, min(999, (int)$m[0]));
            }
            $href = preg_match('~<a[^>]+href=["\']([^"\']+)["\'][^>]*>\s*<h3~isu', $chunk, $hm) ? html_entity_decode($hm[1], ENT_QUOTES | ENT_HTML5, 'UTF-8') : '';
            $imdb = bm_boxoffice_extract_imdb($href . ' ' . $chunk);
            $image = '';
            if (preg_match('~<img[^>]+(?:src|data-src)=["\']([^"\']+)["\']~isu', $chunk, $im)) $image = bm_boxoffice_safe_upstream_image($im[1]);
            $weeks = 0;
            if (preg_match('~هفته\s*اکران\s*<span[^>]*>(.*?)</span>~isu', $chunk, $wm)) {
                $w = bm_boxoffice_ascii_digits(bm_boxoffice_clean_text($wm[1]));
                if (preg_match('/\d{1,3}/', $w, $m)) $weeks = max(0, min(999, (int)$m[0]));
            }
            $weekendText = preg_match('~فروش\s*(?:اخر|آخر)\s*هفته\s*<span[^>]*>(.*?)</span>~isu', $chunk, $gm) ? bm_boxoffice_clean_text($gm[1]) : '';
            $grossText = preg_match('~فروش\s*کل\s*<span[^>]*>(.*?)</span>~isu', $chunk, $tm2) ? bm_boxoffice_clean_text($tm2[1]) : '';
            $weekendValue = bm_boxoffice_money_number($weekendText);
            $grossValue = bm_boxoffice_money_number($grossText);
            if ($weekendValue <= 0 && $grossValue <= 0) continue;
            $items[] = [
                'rank'=>$rank,'id'=>$imdb,'title'=>$title,'image'=>$image,'year'=>'',
                'weekend'=>$weekendText,'gross'=>$grossText,'weeks'=>$weeks,
                'weekend_value'=>$weekendValue,'gross_value'=>$grossValue,'mode'=>'weekend',
            ];
        }
        usort($items, static fn(array $a, array $b): int => ((int)$a['rank']) <=> ((int)$b['rank']));
        return ['items'=>array_slice($items, 0, $limit), 'updated_text'=>$updatedText];
    }
}

if (!function_exists('bm_boxoffice_parse_feed')) {
    function bm_boxoffice_parse_feed(string $html, int $limit): array
    {
        $parsed = bm_boxoffice_parse_feed_dom($html, $limit);
        if (count((array)($parsed['items'] ?? [])) >= 3) return $parsed;
        $fallback = bm_boxoffice_parse_feed_regex($html, $limit);
        if (count((array)($fallback['items'] ?? [])) > count((array)($parsed['items'] ?? []))) return $fallback;
        return $parsed;
    }
}

if (!function_exists('bm_boxoffice_enrich_local')) {
    function bm_boxoffice_enrich_local(PDO $pdo, array $items): array
    {
        $imdbIds = [];
        $titles = [];
        foreach ($items as $item) {
            $imdb = strtolower(trim((string)($item['id'] ?? '')));
            if (preg_match('/^tt\d{5,12}$/', $imdb)) $imdbIds[$imdb] = $imdb;
            $title = trim((string)($item['title'] ?? ''));
            if ($title !== '') $titles[mb_strtolower($title, 'UTF-8')] = $title;
        }

        $byImdb = [];
        $byTitle = [];
        if ($imdbIds) {
            try {
                $vals = array_values($imdbIds);
                $ph = implode(',', array_fill(0, count($vals), '?'));
                $stmt = $pdo->prepare("SELECT id,title,title_fa,year,imdb_code,poster FROM movies WHERE LOWER(imdb_code) IN ($ph) LIMIT 100");
                $stmt->execute($vals);
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $movie) {
                    $key = strtolower(trim((string)($movie['imdb_code'] ?? '')));
                    if ($key !== '') $byImdb[$key] = $movie;
                }
            } catch (Throwable $e) {
                error_log('BoxOffice imdb enrichment error: ' . $e->getMessage());
            }
        }
        if ($titles) {
            try {
                $vals = array_values($titles);
                $ph = implode(',', array_fill(0, count($vals), '?'));
                $stmt = $pdo->prepare("SELECT id,title,title_fa,year,imdb_code,poster FROM movies WHERE title IN ($ph) OR title_fa IN ($ph) LIMIT 200");
                $stmt->execute(array_merge($vals, $vals));
                foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $movie) {
                    foreach (['title','title_fa'] as $field) {
                        $key = mb_strtolower(trim((string)($movie[$field] ?? '')), 'UTF-8');
                        if ($key !== '') $byTitle[$key][] = $movie;
                    }
                }
            } catch (Throwable $e) {
                error_log('BoxOffice title enrichment error: ' . $e->getMessage());
            }
        }

        foreach ($items as &$item) {
            $item['local_url'] = '';
            $item['title_fa'] = '';
            $item['local_match'] = false;
            $item['local_poster'] = '';
            $movie = null;
            $imdb = strtolower(trim((string)($item['id'] ?? '')));
            if ($imdb !== '' && isset($byImdb[$imdb])) $movie = $byImdb[$imdb];
            if (!$movie) {
                $titleKey = mb_strtolower(trim((string)($item['title'] ?? '')), 'UTF-8');
                $candidates = $byTitle[$titleKey] ?? [];
                if (count($candidates) === 1) $movie = $candidates[0];
            }
            if (is_array($movie)) {
                $item['local_match'] = true;
                $item['title_fa'] = trim((string)($movie['title_fa'] ?? ''));
                $item['year'] = (string)($movie['year'] ?? '');
                if (function_exists('bm_movie_url')) $item['local_url'] = bm_movie_url($movie);
                $poster = trim((string)($movie['poster'] ?? ''));
                if ($poster !== '' && !preg_match('~^(javascript|data:text/html):~i', $poster)) {
                    if (!preg_match('~^(?:https?:)?//~i', $poster) && !str_starts_with($poster, '/')) $poster = '/' . ltrim($poster, '/');
                    $item['local_poster'] = $poster;
                }
            }
        }
        unset($item);
        return $items;
    }
}

if (!function_exists('bm_boxoffice_fetch_provider')) {
    function bm_boxoffice_fetch_provider(PDO $pdo, string $mode, array $settings): array
    {
        if ($mode === 'alltime') throw new RuntimeException('در حال حاضر جدول هفتگی باکس آفیس فعال است.');
        $html = bm_boxoffice_http_get_feed();
        $parsed = bm_boxoffice_parse_feed($html, (int)$settings['items_limit']);
        $items = (array)($parsed['items'] ?? []);
        if (!$items) throw new RuntimeException('داده قابل نمایش برای باکس آفیس دریافت نشد.');
        return [
            'items' => bm_boxoffice_enrich_local($pdo, $items),
            'source' => 'darkmovis_boxoffice',
            'source_label' => 'DarkMovis',
            'transport' => 'server_feed',
            'source_updated_text' => trim((string)($parsed['updated_text'] ?? '')),
        ];
    }
}

if (!function_exists('bm_boxoffice_cache_row')) {
    function bm_boxoffice_cache_row(PDO $pdo, string $key): ?array
    {
        try {
            $stmt = $pdo->prepare('SELECT * FROM bm_boxoffice_cache WHERE cache_key=? LIMIT 1');
            $stmt->execute([$key]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return is_array($row) ? $row : null;
        } catch (Throwable $e) {
            return null;
        }
    }
}

if (!function_exists('bm_boxoffice_decode_cache_payload')) {
    function bm_boxoffice_decode_cache_payload(?array $row): ?array
    {
        if (!$row) return null;
        $payload = json_decode((string)($row['payload_json'] ?? ''), true);
        return is_array($payload) ? $payload : null;
    }
}

if (!function_exists('bm_boxoffice_make_payload')) {
    function bm_boxoffice_make_payload(string $mode, array $items, array $settings, int $now, array $meta = []): array
    {
        $weekendTotal = 0.0;
        foreach ($items as $item) $weekendTotal += (float)($item['weekend_value'] ?? 0);
        $leader = $items[0] ?? null;
        return [
            'success' => true,
            'configured' => true,
            'mode' => 'weekend',
            'source' => (string)($meta['source'] ?? 'boxoffice_feed'),
            'source_label' => 'DarkMovis',
            'transport' => (string)($meta['transport'] ?? 'server_feed'),
            'source_updated_text' => trim((string)($meta['source_updated_text'] ?? '')),
            'updated_at' => date(DATE_ATOM, $now),
            'updated_epoch' => $now,
            'next_refresh_at' => $now + 86400,
            'stale' => false,
            'items' => $items,
            'stats' => [
                'count' => count($items),
                'weekend_total_value' => $weekendTotal,
                'leader_title' => is_array($leader) ? (string)($leader['title'] ?? '') : '',
                'leader_value' => is_array($leader) ? (float)($leader['weekend_value'] ?? 0) : 0,
            ],
        ];
    }
}

if (!function_exists('bm_boxoffice_get_data')) {
    function bm_boxoffice_get_data(PDO $pdo, string $mode = 'weekend', bool $force = false): array
    {
        $mode = $mode === 'alltime' ? 'alltime' : 'weekend';
        if (!bm_boxoffice_schema($pdo)) throw new RuntimeException('سرویس باکس آفیس آماده نیست.');
        $settings = bm_boxoffice_settings($pdo, false);
        if (!$settings['enabled']) return ['success'=>false,'disabled'=>true,'mode'=>$mode,'message'=>'باکس آفیس موقتاً غیرفعال است.','items'=>[]];
        if ($mode === 'alltime') return ['success'=>false,'disabled'=>true,'mode'=>$mode,'message'=>'در حال حاضر جدول هفتگی باکس آفیس فعال است.','items'=>[]];

        $key = 'boxoffice_weekend_v3';
        $now = time();
        $row = bm_boxoffice_cache_row($pdo, $key);
        $cached = bm_boxoffice_decode_cache_payload($row);
        if (!$force && $cached && (int)($row['expires_at'] ?? 0) > $now) {
            $cached['cached'] = true;
            $cached['stale'] = false;
            return $cached;
        }

        $lockName = 'bm_boxoffice_weekend_v3';
        $locked = false;
        try {
            $lockStmt = $pdo->prepare('SELECT GET_LOCK(?, 2)');
            $lockStmt->execute([$lockName]);
            $locked = (int)$lockStmt->fetchColumn() === 1;
        } catch (Throwable $e) {
            $locked = true;
        }
        if (!$locked && $cached) {
            $cached['cached'] = true;
            $cached['stale'] = true;
            return $cached;
        }

        try {
            if (!$force) {
                $freshRow = bm_boxoffice_cache_row($pdo, $key);
                $freshCached = bm_boxoffice_decode_cache_payload($freshRow);
                if ($freshCached && (int)($freshRow['expires_at'] ?? 0) > time()) {
                    $freshCached['cached'] = true;
                    $freshCached['stale'] = false;
                    return $freshCached;
                }
            }
            $bundle = bm_boxoffice_fetch_provider($pdo, $mode, $settings);
            $items = (array)($bundle['items'] ?? []);
            if (!$items) throw new RuntimeException('داده باکس آفیس خالی است.');
            $fetchedAt = time();
            $payload = bm_boxoffice_make_payload($mode, $items, $settings, $fetchedAt, $bundle);
            $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
            if (!is_string($json)) throw new RuntimeException('ذخیره داده باکس آفیس انجام نشد.');
            $stmt = $pdo->prepare("INSERT INTO bm_boxoffice_cache(cache_key,payload_json,provider,fetched_at,expires_at,last_error)
                VALUES(?,?,?,?,?,'') ON DUPLICATE KEY UPDATE payload_json=VALUES(payload_json),provider=VALUES(provider),fetched_at=VALUES(fetched_at),expires_at=VALUES(expires_at),last_error=''");
            $stmt->execute([$key, $json, 'darkmovis', $fetchedAt, $fetchedAt + 86400]);
            $pdo->prepare("UPDATE bm_boxoffice_settings SET provider='darkmovis',last_test_status='ok',last_test_message=?,last_fetch_at=? WHERE id=1")
                ->execute(['دریافت باکس آفیس با موفقیت انجام شد.', $fetchedAt]);
            $payload['cached'] = false;
            return $payload;
        } catch (Throwable $e) {
            $message = mb_substr(preg_replace('/[\r\n\t]+/', ' ', $e->getMessage()) ?? $e->getMessage(), 0, 480, 'UTF-8');
            try {
                $pdo->prepare("UPDATE bm_boxoffice_settings SET last_test_status='error',last_test_message=? WHERE id=1")->execute([$message]);
                if ($row) $pdo->prepare('UPDATE bm_boxoffice_cache SET last_error=? WHERE cache_key=?')->execute([$message, $key]);
            } catch (Throwable $ignore) {}
            if ($cached) {
                $cached['cached'] = true;
                $cached['stale'] = true;
                $cached['message'] = 'بروزرسانی تازه موقتاً انجام نشد؛ آخرین داده معتبر نمایش داده می‌شود.';
                return $cached;
            }
            return ['success'=>false,'configured'=>true,'mode'=>$mode,'message'=>$message,'items'=>[]];
        } finally {
            if ($locked) {
                try {
                    $unlock = $pdo->prepare('SELECT RELEASE_LOCK(?)');
                    $unlock->execute([$lockName]);
                } catch (Throwable $ignore) {}
            }
        }
    }
}

if (!function_exists('bm_boxoffice_clear_cache')) {
    function bm_boxoffice_clear_cache(PDO $pdo): void
    {
        bm_boxoffice_schema($pdo);
        $pdo->exec('DELETE FROM bm_boxoffice_cache');
    }
}

if (!function_exists('bm_boxoffice_admin_status')) {
    function bm_boxoffice_admin_status(PDO $pdo): array
    {
        bm_boxoffice_schema($pdo);
        $settings = bm_boxoffice_settings($pdo, false);
        $cache = [];
        try {
            foreach ($pdo->query('SELECT cache_key,provider,fetched_at,expires_at,last_error FROM bm_boxoffice_cache ORDER BY fetched_at DESC')->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
                $cache[(string)$row['cache_key']] = $row;
            }
        } catch (Throwable $e) {}
        return ['settings'=>$settings,'cache'=>$cache];
    }
}
