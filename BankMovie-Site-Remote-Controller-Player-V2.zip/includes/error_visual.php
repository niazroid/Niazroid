<?php
declare(strict_types=1);

if (!function_exists('bm_error_visual_h')) {
    function bm_error_visual_h(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('bm_error_face_svg')) {
    function bm_error_face_svg(): string
    {
        return <<<'SVG'
<svg class="bm-error-face-svg" viewBox="0 0 220 220" role="img" aria-label="چهره متحرک خطا">
  <defs>
    <clipPath id="bmFaceClip"><circle cx="110" cy="110" r="96"/></clipPath>
  </defs>
  <circle cx="110" cy="110" r="96" fill="#f6d365" stroke="#171717" stroke-width="8"/>
  <g clip-path="url(#bmFaceClip)" fill="none" stroke="#171717" stroke-linecap="round" stroke-linejoin="round">
    <g class="face__eyes" stroke-width="8">
      <path d="M42 82 C58 64 80 64 94 82"/>
      <path d="M126 82 C142 64 164 64 178 82"/>
    </g>
    <g class="face__eye-lid" stroke-width="10">
      <path d="M43 72 Q68 55 94 72"/>
      <path d="M126 72 Q152 55 178 72"/>
    </g>
    <g class="face__pupil" fill="#171717" stroke="none">
      <circle cx="72" cy="91" r="10"/>
      <circle cx="150" cy="91" r="10"/>
    </g>
    <path class="face__nose" d="M111 91 Q99 124 116 128" stroke-width="8"/>
    <path class="face__mouth-left" d="M54 157 Q82 135 110 157" stroke-width="9" stroke-dasharray="102" stroke-dashoffset="-102"/>
    <path class="face__mouth-right" d="M110 157 Q138 135 166 157" stroke-width="9" stroke-dasharray="102" stroke-dashoffset="102"/>
  </g>
</svg>
SVG;
    }
}

if (!function_exists('bm_error_screen_content')) {
    function bm_error_screen_content(string $variant, string $code, string $title, string $message): string
    {
        if ($variant === 'face') {
            return '<div class="my-custom-face-container"><div class="face">' . bm_error_face_svg() . '</div></div>';
        }

        return '<span class="notfound_text" title="' . bm_error_visual_h($title) . '">'
            . bm_error_visual_h($code)
            . '</span>';
    }
}

if (!function_exists('bm_error_tv_markup')) {
    /**
     * Uses the original Uiverse television structure supplied by the project owner.
     * The component keeps the original class names so its original CSS is applied verbatim.
     */
    function bm_error_tv_markup(array $options = []): string
    {
        $id = preg_replace('/[^a-zA-Z0-9_-]/', '', (string)($options['id'] ?? 'bmErrorTv')) ?: 'bmErrorTv';
        $code = (string)($options['code'] ?? 'ERR');
        $title = (string)($options['title'] ?? 'خطا در دریافت تصویر');
        $message = (string)($options['message'] ?? 'دوباره تلاش کنید');
        $variant = in_array(($options['variant'] ?? 'signal'), ['signal', 'face', 'player'], true)
            ? (string)$options['variant']
            : 'signal';
        $hidden = !empty($options['hidden']) ? ' hidden' : '';
        $backdrop = !empty($options['backdrop']);
        $screenVariant = $variant === 'face' ? 'face' : 'signal';
        $screenContent = bm_error_screen_content($screenVariant, $code, $title, $message);

        ob_start();
        ?>
<div class="bm-uiverse-tv-shell bm-uiverse-tv-shell--<?= bm_error_visual_h($variant) ?>" id="<?= bm_error_visual_h($id) ?>" data-error-code="<?= bm_error_visual_h($code) ?>"<?= $hidden ?>>
  <div class="main_wrapper">
    <div class="main">
      <div class="antenna" aria-hidden="true">
        <div class="antenna_shadow"></div>
        <div class="a1"></div>
        <div class="a1d"></div>
        <div class="a2"></div>
        <div class="a2d"></div>
      </div>

      <div class="tv">
        <div class="display_div">
          <div class="screen_out">
            <div class="screen_out1">
              <div class="screenM"><?= $screenContent ?></div>
            </div>
          </div>
        </div>

        <div class="lines" aria-hidden="true">
          <div class="line1"></div>
          <div class="line2"></div>
          <div class="line3"></div>
        </div>

        <div class="buttons_div" aria-hidden="true">
          <div class="b1"><div></div></div>
          <div class="b2"></div>
          <div class="speakers">
            <div class="g1"><div class="g11"></div><div class="g12"></div><div class="g13"></div></div>
            <div class="g"></div>
            <div class="g"></div>
          </div>
        </div>
      </div>

      <div class="bottom" aria-hidden="true">
        <div class="base1"></div>
        <div class="base2"></div>
        <div class="base3"></div>
      </div>

      <?php if ($backdrop): ?>
      <div class="text_404" aria-hidden="true">
        <div class="text_4041">4</div>
        <div class="text_4042">0</div>
        <div class="text_4043">4</div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>
        <?php
        return (string)ob_get_clean();
    }
}
