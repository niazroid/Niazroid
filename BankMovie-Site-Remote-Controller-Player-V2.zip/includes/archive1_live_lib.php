<?php
/**
 * Archive 1 live listing parser for Bankmovie.
 * Supports the current Persian-dubbed movies feed and Chinese series feed.
 */
if (defined('BM_ARCHIVE1_LIVE_LIB_LOADED')) {
    return;
}
define('BM_ARCHIVE1_LIVE_LIB_LOADED', true);

function bma1_clean_text($value) {
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $value = strip_tags($value);
    $value = preg_replace('/[\x{200c}\x{200e}\x{200f}]+/u', ' ', $value);
    $value = preg_replace('/\s+/u', ' ', $value);
    return trim($value);
}

function bma1_base_url() {
    $fallback = 'https://www.oldtowns.top';
    $configPath = dirname(__DIR__) . '/bankmovie_remote_config.json';
    if (!is_file($configPath) || !is_readable($configPath)) {
        return $fallback;
    }
    $raw = @file_get_contents($configPath);
    $json = json_decode((string)$raw, true);
    if (!is_array($json)) {
        return $fallback;
    }
    $candidate = '';
    if (!empty($json['archive1_source_url'])) {
        $candidate = (string)$json['archive1_source_url'];
    } elseif (!empty($json['archives']['1']['source_url'])) {
        $candidate = (string)$json['archives']['1']['source_url'];
    }
    $candidate = rtrim(trim($candidate), '/');
    return preg_match('~^https?://~i', $candidate) ? $candidate : $fallback;
}

function bma1_abs_url($url, $baseUrl) {
    $url = html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '') return '';
    if (preg_match('~^https?://~i', $url)) return $url;
    if (strpos($url, '//') === 0) return 'https:' . $url;
    return rtrim($baseUrl, '/') . '/' . ltrim($url, '/');
}

function bma1_slug_from_url($url) {
    $path = trim((string)(parse_url((string)$url, PHP_URL_PATH) ?: ''), '/');
    if ($path === '') return '';
    $parts = array_values(array_filter(explode('/', $path), 'strlen'));
    return $parts ? (string)end($parts) : '';
}

function bma1_xpath_first($xpath, $query, $context = null) {
    $nodes = $context ? $xpath->query($query, $context) : $xpath->query($query);
    return ($nodes && $nodes->length > 0) ? $nodes->item(0) : null;
}

function bma1_xpath_text($xpath, $query, $context = null) {
    $node = bma1_xpath_first($xpath, $query, $context);
    return $node ? bma1_clean_text($node->textContent) : '';
}

function bma1_xpath_attr($xpath, $query, $attribute, $context = null) {
    $node = bma1_xpath_first($xpath, $query, $context);
    if (!$node || $node->nodeType !== XML_ELEMENT_NODE || !$node->hasAttribute($attribute)) return '';
    return trim((string)$node->getAttribute($attribute));
}

function bma1_title_fa($raw, $fallback) {
    $value = bma1_clean_text($raw);
    if ($value === '') $value = bma1_clean_text($fallback);
    $value = preg_replace('/^دانلود\s+(?:فیلم|سریال|انیمیشن|انیمه)\s+/u', '', $value);
    $value = preg_replace('/\s+(?:بدون سانسور|با زیرنویس|دوبله فارسی).*$/u', '', $value);
    return trim($value) !== '' ? trim($value) : bma1_clean_text($fallback);
}

function bma1_quality($text) {
    if (preg_match('/\b(2160p|1080p|720p|576p|480p|4K|BluRay|WEB[- ]?DL|WEBRip|HDRip)\b/iu', (string)$text, $m)) {
        return strtoupper(str_replace(' ', '-', $m[1]));
    }
    return '';
}

function bma1_parse_listing_html($html, $requestUrl, $section, $page, $limit) {
    if (!class_exists('DOMDocument')) throw new Exception('dom_extension_required');
    libxml_use_internal_errors(true);
    $dom = new DOMDocument();
    $loaded = $dom->loadHTML('<?xml encoding="utf-8" ?>' . (string)$html, LIBXML_NOWARNING | LIBXML_NOERROR);
    libxml_clear_errors();
    if (!$loaded) throw new Exception('archive1_html_parse_failed');
    $xpath = new DOMXPath($dom);
    $baseUrl = bma1_base_url();
    $nodes = $xpath->query('//article[contains(concat(" ",normalize-space(@class)," ")," entry ")]');
    $items = [];
    $seen = [];

    if ($nodes) {
        foreach ($nodes as $article) {
            $href = bma1_xpath_attr($xpath, './/a[contains(concat(" ",normalize-space(@class)," ")," stretched-link ")][1]', 'href', $article);
            if ($href === '') $href = bma1_xpath_attr($xpath, './/a[@href][.//h2][1]', 'href', $article);
            $href = bma1_abs_url($href, $baseUrl);
            if ($href === '') continue;

            $slug = bma1_slug_from_url($href);
            if ($slug === '' || isset($seen[$href])) continue;
            $seen[$href] = true;

            $title = bma1_xpath_text($xpath, './/h2[contains(concat(" ",normalize-space(@class)," ")," entry-title ")][1]', $article);
            if ($title === '') $title = bma1_xpath_text($xpath, './/h2[1]', $article);
            $titleAttr = bma1_xpath_attr($xpath, './/a[contains(concat(" ",normalize-space(@class)," ")," stretched-link ")][1]', 'title', $article);
            $titleFa = bma1_title_fa($titleAttr, $title);
            if ($title === '') $title = $titleFa;
            if ($title === '') continue;

            $img = bma1_xpath_first($xpath, './/img[1]', $article);
            $poster = '';
            if ($img && $img->nodeType === XML_ELEMENT_NODE) {
                foreach (['data-lazy-src', 'data-src', 'data-splide-lazy', 'src'] as $attr) {
                    if ($img->hasAttribute($attr)) {
                        $candidate = trim((string)$img->getAttribute($attr));
                        if ($candidate !== '' && stripos($candidate, 'data:image/') !== 0) {
                            $poster = bma1_abs_url($candidate, $baseUrl);
                            break;
                        }
                    }
                }
            }

            $articleText = bma1_clean_text($article->textContent);
            $iconTitles = [];
            $iconNodes = $xpath->query('.//*[contains(concat(" ",normalize-space(@class)," ")," entry-icons ")]//*[@title]', $article);
            if ($iconNodes) {
                foreach ($iconNodes as $icon) {
                    if ($icon->nodeType === XML_ELEMENT_NODE) $iconTitles[] = bma1_clean_text($icon->getAttribute('title'));
                }
            }
            $statusText = trim($articleText . ' ' . implode(' ', $iconTitles) . ' ' . $titleAttr);
            $hasDubbed = ($section === 'dubbed') || mb_strpos($statusText, 'دوبله') !== false;
            $hasSubtitle = mb_strpos($statusText, 'زیرنویس') !== false || mb_strpos($statusText, 'سافت') !== false;

            $genres = [];
            $genreNodes = $xpath->query('.//*[contains(concat(" ",normalize-space(@class)," ")," entry-ganers ")]//a', $article);
            if ($genreNodes) {
                foreach ($genreNodes as $genreNode) {
                    $genre = bma1_clean_text($genreNode->textContent);
                    if ($genre !== '' && !in_array($genre, $genres, true)) $genres[] = $genre;
                }
            }

            $updateNote = bma1_xpath_text($xpath, './/p[contains(concat(" ",normalize-space(@class)," ")," text-muted ")][1]', $article);
            $year = '';
            if (preg_match('/\b(19|20)\d{2}\b/u', $titleFa . ' ' . $title . ' ' . $articleText, $m)) $year = $m[0];
            $rating = '';
            if (preg_match('/IMDb\s*([0-9]+(?:\.[0-9]+)?)/iu', $articleText, $m)) $rating = $m[1];
            $type = ($section === 'chinese_series' || stripos($href, '/series/') !== false || mb_strpos($titleAttr, 'سریال') !== false) ? 'series' : 'movie';

            $items[] = [
                'id' => $slug,
                'slug' => $slug,
                'archive' => 1,
                'type' => $type,
                'title' => $title,
                'title_fa' => $titleFa,
                'poster' => $poster,
                'image' => $poster,
                'year' => $year,
                'rating' => $rating,
                'genres' => $genres,
                'has_dubbed' => $hasDubbed,
                'has_subtitle' => $hasSubtitle,
                'quality' => bma1_quality($statusText),
                'update_note' => $updateNote,
                'url' => $href,
                'source_url' => $href,
                'source' => 'archive1_live'
            ];
            if (count($items) >= $limit) break;
        }
    }

    $nextHref = bma1_xpath_attr($xpath, '//a[contains(concat(" ",normalize-space(@class)," ")," next ")][1]', 'href');
    $nextHref = $nextHref !== '' ? bma1_abs_url($nextHref, $baseUrl) : '';
    $hasMore = $nextHref !== '' || count($items) >= $limit;
    $nextPage = $hasMore ? ((int)$page + 1) : null;

    $totalPages = (int)$page;
    $pageNodes = $xpath->query('//*[contains(concat(" ",normalize-space(@class)," ")," page-numbers ")]');
    if ($pageNodes) {
        foreach ($pageNodes as $pNode) {
            $number = (int)preg_replace('/[^0-9]/', '', bma1_clean_text($pNode->textContent));
            if ($number > $totalPages) $totalPages = $number;
        }
    }

    return [
        'status' => 'success',
        'source' => 'archive1_live',
        'archive' => 1,
        'section' => $section,
        'page' => (int)$page,
        'current_page' => (int)$page,
        'items' => $items,
        'movies' => $items,
        'count' => count($items),
        'has_more' => $hasMore,
        'has_next_page' => $hasMore,
        'next_page' => $nextPage,
        'next_page_url' => $nextHref,
        'continue_page' => $nextPage,
        'continue_url' => $nextHref,
        'total_pages' => max($totalPages, (int)$page),
        'request_url' => $requestUrl,
        'pagination' => [
            'current_page' => (int)$page,
            'next_page' => $nextPage,
            'total_pages' => max($totalPages, (int)$page),
            'has_more' => $hasMore
        ]
    ];
}


function bma1_advanced_url($params, $page = 1) {
    $base = rtrim(bma1_base_url(), '/');
    $parts = [];

    $parts[] = 's=';

    $type = strtolower(trim((string)($params['type'] ?? 'both')));
    if (!in_array($type, ['both', 'movie', 'series'], true)) $type = 'both';
    $parts[] = 'type=' . rawurlencode($type);

    $genreId = trim((string)($params['genre_id'] ?? $params['genre'] ?? ''));
    if ($genreId !== '' && $genreId !== '0') {
        $parts[] = 'genre%5B%5D=' . rawurlencode($genreId);
    }

    $sort = trim((string)($params['sortby'] ?? $params['sort'] ?? 'newest'));
    if (!in_array($sort, ['newest', 'modified', 'popular', 'imdb_rate', 'release'], true)) {
        $sort = 'newest';
    }
    $parts[] = 'sortby=' . rawurlencode($sort);

    $rating = trim((string)($params['rating'] ?? $params['imdbrate'] ?? '0'));
    if ($rating === '') $rating = '0';
    $parts[] = 'imdbrate=' . rawurlencode($rating);

    $countryId = trim((string)($params['country_id'] ?? $params['madeby'] ?? ''));
    if ($countryId !== '' && $countryId !== '0') {
        $parts[] = 'madeby%5B%5D=' . rawurlencode($countryId);
    }

    if (!empty($params['dubbed']) || !empty($params['dubbled'])) {
        $parts[] = 'dubbed=1';
        $parts[] = 'dubbled=1';
    }
    if (!empty($params['subtitle'])) {
        $parts[] = 'subtitle=1';
    }

    $yearFrom = trim((string)($params['year_from'] ?? $params['min_year'] ?? ''));
    $yearTo = trim((string)($params['year_to'] ?? $params['max_year'] ?? ''));
    if ($yearFrom !== '') $parts[] = 'min_year=' . rawurlencode($yearFrom);
    if ($yearTo !== '') $parts[] = 'max_year=' . rawurlencode($yearTo);

    $parts[] = 'paged=' . max(1, (int)$page);

    return $base . '/?' . implode('&', $parts);
}

function bma1_section_url($section, $page) {
    $base = rtrim(bma1_base_url(), '/');
    $page = max(1, (int)$page);
    if ($section === 'dubbed') {
        return $page > 1
            ? $base . '/movies/page/' . $page . '/?dubbled=1'
            : $base . '/movies/?dubbled=1';
    }
    if ($section === 'chinese_series') {
        return $page > 1
            ? $base . '/category/chinese_series/page/' . $page . '/'
            : $base . '/category/chinese_series/';
    }
    throw new Exception('unsupported_archive1_section');
}

function bma1_fetch_html($url) {
    if (!function_exists('curl_init')) throw new Exception('curl_extension_required');
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 5,
        CURLOPT_ENCODING => '',
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 22,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/149 Mobile Safari/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: fa-IR,fa;q=0.9,en;q=0.6',
            'Cache-Control: no-cache',
            'Referer: ' . bma1_base_url() . '/'
        ]
    ]);
    $body = curl_exec($ch);
    $error = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);
    if ($body === false || $code < 200 || $code >= 400) {
        throw new Exception($error !== '' ? $error : ('upstream_http_' . $code));
    }
    return (string)$body;
}
