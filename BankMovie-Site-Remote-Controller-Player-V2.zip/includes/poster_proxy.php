<?php
/**
 * BankMovie DL1 poster redirect layer (v3.1).
 *
 * Compatibility note:
 * The filename/function names intentionally keep the old "poster_proxy" names so
 * every page/API patched by v3.0 continues to work without further edits.
 *
 * v3.1 behavior:
 * - External poster URLs are replaced with stable dl1.bankmovie.top URLs.
 * - DL1 responds with HTTP 302 only. Image bytes NEVER pass through BankMovie.
 * - No image cache is created. Only tiny private route -> source JSON maps remain.
 * - Rendering is fail-open: if route creation fails, the original poster URL is used.
 */
if (defined('BANKMOVIE_POSTER_PROXY_LOADED')) return;
define('BANKMOVIE_POSTER_PROXY_LOADED', true);

if (!function_exists('bm_security_private_dir')) {
    require_once __DIR__ . '/security_bootstrap.php';
}

if (!function_exists('bm_poster_proxy_enabled')) {
    function bm_poster_proxy_enabled(): bool
    {
        $env = getenv('BANKMOVIE_POSTER_PROXY_ENABLED');
        if ($env !== false && trim((string)$env) !== '') {
            $parsed = filter_var($env, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($parsed === false) return false;
        }
        return !is_file(bm_security_private_path('poster_proxy.disabled'));
    }
}

if (!function_exists('bm_poster_proxy_base')) {
    function bm_poster_proxy_base(): string
    {
        $base = '';
        if (function_exists('bm_security_secret')) {
            $base = trim((string)bm_security_secret('poster_proxy_base', 'BANKMOVIE_POSTER_PROXY_BASE', ''));
        }
        if ($base === '') {
            $env = getenv('BANKMOVIE_POSTER_PROXY_BASE');
            if ($env !== false) $base = trim((string)$env);
        }
        if ($base === '') $base = 'https://dl1.bankmovie.top';
        return rtrim($base, '/');
    }
}

if (!function_exists('bm_poster_proxy_key')) {
    function bm_poster_proxy_key(): string
    {
        static $key = null;
        if (is_string($key) && strlen($key) === 32) return $key;

        $raw = getenv('BANKMOVIE_POSTER_PROXY_KEY');
        if ($raw !== false && trim((string)$raw) !== '') {
            $candidate = trim((string)$raw);
            $decoded = base64_decode($candidate, true);
            if (is_string($decoded) && strlen($decoded) >= 32) return $key = substr($decoded, 0, 32);
            if (ctype_xdigit($candidate) && strlen($candidate) >= 64) {
                $hex = hex2bin(substr($candidate, 0, 64));
                if (is_string($hex) && strlen($hex) === 32) return $key = $hex;
            }
            if (strlen($candidate) >= 32) return $key = substr($candidate, 0, 32);
        }

        $path = bm_security_private_path('poster_proxy.key');
        if (is_file($path)) {
            $stored = trim((string)@file_get_contents($path));
            $decoded = base64_decode($stored, true);
            if (is_string($decoded) && strlen($decoded) === 32) return $key = $decoded;
        }

        try { $generated = random_bytes(32); } catch (Throwable $e) { return ''; }
        $tmp = $path . '.tmp.' . getmypid();
        if (@file_put_contents($tmp, base64_encode($generated), LOCK_EX) !== false) {
            @chmod($tmp, 0600);
            @rename($tmp, $path);
            @chmod($path, 0600);
        } else {
            @unlink($tmp);
        }
        if (!is_file($path)) return '';
        return $key = $generated;
    }
}

if (!function_exists('bm_poster_proxy_dirs')) {
    function bm_poster_proxy_dirs(): array
    {
        static $dirs = null;
        if (is_array($dirs)) return $dirs;
        $base = bm_security_private_dir() . DIRECTORY_SEPARATOR . 'poster_proxy';
        $maps = $base . DIRECTORY_SEPARATOR . 'maps';
        if (!is_dir($maps)) @mkdir($maps, 0700, true);
        if (is_dir($base)) @chmod($base, 0700);
        if (is_dir($maps)) @chmod($maps, 0700);
        return $dirs = ['base' => $base, 'maps' => $maps];
    }
}

if (!function_exists('bm_poster_is_http_url')) {
    function bm_poster_is_http_url(string $url): bool
    {
        if ($url === '' || strlen($url) > 8192 || preg_match('/[\x00-\x1F\x7F]/', $url)) return false;
        $parts = @parse_url($url);
        if (!is_array($parts)) return false;
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        if (!in_array($scheme, ['http', 'https'], true)) return false;
        $host = strtolower(trim((string)($parts['host'] ?? '')));
        if ($host === '' || isset($parts['user']) || isset($parts['pass'])) return false;
        if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) return false;
        return true;
    }
}

if (!function_exists('bm_poster_is_own_url')) {
    function bm_poster_is_own_url(string $url): bool
    {
        $host = strtolower((string)(parse_url($url, PHP_URL_HOST) ?? ''));
        $baseHost = strtolower((string)(parse_url(bm_poster_proxy_base(), PHP_URL_HOST) ?? ''));
        return $host !== '' && $baseHost !== '' && $host === $baseHost;
    }
}

if (!function_exists('bm_poster_route_chars')) {
    function bm_poster_route_chars(string $bytes, int $offset, int $length): string
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $out = ''; $n = strlen($bytes);
        if ($n === 0) return str_repeat('x', $length);
        for ($i = 0; $i < $length; $i++) $out .= $alphabet[ord($bytes[($offset + $i) % $n]) % strlen($alphabet)];
        return $out;
    }
}

if (!function_exists('bm_poster_route_type')) {
    function bm_poster_route_type(array $context): string
    {
        $signal = strtolower(trim((string)($context['type'] ?? $context['media_type'] ?? '')));
        return (str_contains($signal, 'series') || str_contains($signal, 'serial') || str_contains($signal, 'tv')) ? 'series' : 'movie';
    }
}

if (!function_exists('bm_poster_filename')) {
    function bm_poster_filename(string $url, array $context): string
    {
        $title = trim((string)($context['title_en'] ?? $context['title'] ?? $context['title_fa'] ?? $context['name'] ?? ''));
        $year = trim((string)($context['year'] ?? $context['release_year'] ?? ''));
        $path = (string)(parse_url($url, PHP_URL_PATH) ?? '');
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp','avif','gif'], true)) $ext = 'webp';
        if ($title === '') {
            $base = pathinfo(basename($path), PATHINFO_FILENAME);
            $title = $base !== '' ? $base : 'poster';
        }
        $title = preg_replace('/[\s_]+/u', '.', $title);
        $title = preg_replace('/[^A-Za-z0-9\p{L}.-]+/u', '.', (string)$title);
        $title = preg_replace('/\.{2,}/', '.', (string)$title);
        $title = trim((string)$title, '.-');
        if ($title === '') $title = 'poster';
        if ($year !== '' && preg_match('/^(?:19|20)\d{2}$/', $year) && !preg_match('/(?:^|\.)' . preg_quote($year, '/') . '(?:\.|$)/', $title)) $title .= '.' . $year;
        $title = function_exists('mb_substr') ? mb_substr($title, 0, 110, 'UTF-8') : substr($title, 0, 110);
        return $title . '.' . $ext;
    }
}

if (!function_exists('bm_poster_map_path')) {
    function bm_poster_map_path(string $route): string
    {
        $dirs = bm_poster_proxy_dirs();
        return $dirs['maps'] . DIRECTORY_SEPARATOR . hash('sha256', $route) . '.json';
    }
}

if (!function_exists('bm_poster_wrap_url')) {
    function bm_poster_wrap_url($url, array $context = []): string
    {
        $url = trim((string)$url);
        if (!bm_poster_proxy_enabled() || !bm_poster_is_http_url($url) || bm_poster_is_own_url($url)) return $url;
        $key = bm_poster_proxy_key();
        if ($key === '') return $url;

        $digest = hash_hmac('sha256', $url, $key, true);
        $shard = (string)(ord($digest[0]) % 10) . chr(97 + (ord($digest[1]) % 26));
        $folder = bm_poster_route_chars($digest, 2, 5);
        $type = bm_poster_route_type($context);
        $filename = bm_poster_filename($url, $context);
        $route = $shard . '/poster/' . $type . '/' . $folder . '/' . rawurlencode($filename);
        $mapPath = bm_poster_map_path($route);

        $existingUrl = '';
        if (is_file($mapPath)) {
            $existing = json_decode((string)@file_get_contents($mapPath), true);
            if (is_array($existing)) $existingUrl = trim((string)($existing['url'] ?? ''));
        }
        if ($existingUrl === '' || !hash_equals($existingUrl, $url)) {
            $payload = json_encode(['v'=>2,'mode'=>'redirect','url'=>$url,'route'=>$route,'created_at'=>time()], JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
            if (!is_string($payload)) return $url;
            try { $salt = bin2hex(random_bytes(3)); } catch (Throwable $e) { $salt = (string)getmypid(); }
            $tmp = $mapPath . '.tmp.' . getmypid() . '.' . $salt;
            if (@file_put_contents($tmp, $payload, LOCK_EX) === false) { @unlink($tmp); return $url; }
            @chmod($tmp, 0600);
            if (!@rename($tmp, $mapPath)) { @unlink($tmp); return $url; }
            @chmod($mapPath, 0600);
        }
        return bm_poster_proxy_base() . '/' . $route;
    }
}

if (!function_exists('bm_poster_wrap_value')) {
    function bm_poster_wrap_value($value, array $context = [])
    {
        if (is_string($value)) return bm_poster_wrap_url($value, $context);
        if (!is_array($value)) return $value;
        $out = [];
        foreach ($value as $k => $v) {
            $out[$k] = is_string($v) ? bm_poster_wrap_url($v, $context) : (is_array($v) ? bm_poster_wrap_value($v, $context) : $v);
        }
        return $out;
    }
}

if (!function_exists('bm_poster_wrap_payload')) {
    function bm_poster_wrap_payload($payload, array $context = [])
    {
        if (!is_array($payload)) return $payload;
        $localContext = $context;
        foreach (['title_en','title','title_fa','name','year','release_year','type','media_type'] as $ctxKey) {
            if (isset($payload[$ctxKey]) && !is_array($payload[$ctxKey]) && trim((string)$payload[$ctxKey]) !== '') $localContext[$ctxKey] = (string)$payload[$ctxKey];
        }
        $posterKeys = ['poster','poster_url','posterUrl','poster_image','posterImage','poster_proxy','cover_url','coverUrl'];
        $out = [];
        foreach ($payload as $key => $value) {
            if (in_array((string)$key, $posterKeys, true)) $out[$key] = bm_poster_wrap_value($value, $localContext);
            elseif (is_array($value)) $out[$key] = bm_poster_wrap_payload($value, $localContext);
            else $out[$key] = $value;
        }
        return $out;
    }
}

if (!function_exists('bm_poster_serve_route')) {
    function bm_poster_serve_route(string $route, bool $headOnly = false): void
    {
        $route = trim($route, '/');
        if ($route === '' || strlen($route) > 512 || !preg_match('~^[A-Za-z0-9._%\-/\x{0600}-\x{06FF}]+$~u', $route)) { http_response_code(404); return; }
        $mapPath = bm_poster_map_path($route);
        if (!is_file($mapPath)) { http_response_code(404); return; }
        $map = json_decode((string)@file_get_contents($mapPath), true);
        $sourceUrl = is_array($map) ? trim((string)($map['url'] ?? '')) : '';
        if (!bm_poster_is_http_url($sourceUrl) || bm_poster_is_own_url($sourceUrl)) { http_response_code(404); return; }

        // This endpoint is intentionally redirect-only. It never fetches or streams the image.
        http_response_code(302);
        header('Location: ' . $sourceUrl, true, 302);
        header('Cache-Control: no-store, private, max-age=0');
        header('Pragma: no-cache');
        header('X-BM-Poster-Redirect: 1');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: no-referrer');
        header('X-Robots-Tag: noindex, nofollow, noarchive');
        exit;
    }
}
