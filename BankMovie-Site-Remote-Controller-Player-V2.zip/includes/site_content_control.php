<?php
if (!function_exists('bm_site_typography_options')) {
    function bm_site_typography_options(): array
    {
        return [
            'bonvf'=>'Bon VF — فونت فعلی',
            'yekanbakh'=>'Yekan Bakh VF — یکان‌بخ متغیر',
            'filimo'=>'Filimo Demo Variable — فیلیمو',
            'iransans_fanum'=>'IRANSans FaNum — ایران‌سنس با اعداد فارسی',
            'iranyekan'=>'IRANYekan Web — ایران‌یکان',
            'iranyekanx_fanum'=>'IRANYekanX FaNum — ایران‌یکان X با اعداد فارسی',
            'brioso'=>'Brioso W04 — لاتین؛ فارسی با فونت جایگزین',
            'system'=>'فونت سیستم دستگاه',
        ];
    }
}

if (!function_exists('bm_site_default_footer_links_json')) {
    function bm_site_default_footer_links_json(): string
    {
        return json_encode([
            ['label'=>'دسته‌بندی','url'=>'/categories','icon'=>'categories','new_tab'=>false,'nofollow'=>false,'enabled'=>true],
            ['label'=>'جستجوی پیشرفته','url'=>'/search','icon'=>'search','new_tab'=>false,'nofollow'=>false,'enabled'=>true],
            ['label'=>'اپلیکیشن‌ها','url'=>'/application','icon'=>'mobile','new_tab'=>false,'nofollow'=>false,'enabled'=>true],
            ['label'=>'باکس آفیس','url'=>'/boxoffice','icon'=>'boxoffice','new_tab'=>false,'nofollow'=>false,'enabled'=>true],
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]';
    }
}
if (!function_exists('bm_site_sanitize_footer_links_json')) {
    function bm_site_sanitize_footer_links_json($raw): string
    {
        if (is_array($raw)) {
            $items = $raw;
        } else {
            $items = json_decode((string)$raw, true);
        }
        if (!is_array($items)) $items = [];

        $allowedIcons = ['link','categories','search','mobile','home','collection','play','star','boxoffice','globe','info','support','telegram','instagram','download','user'];
        $clean = [];
        foreach (array_slice($items, 0, 24) as $item) {
            if (!is_array($item)) continue;
            $label = trim(strip_tags((string)($item['label'] ?? '')));
            $label = function_exists('mb_substr') ? mb_substr($label, 0, 70, 'UTF-8') : substr($label, 0, 70);
            $url = trim((string)($item['url'] ?? ''));
            if ($label === '' || $url === '') continue;
            if (preg_match('~^(javascript|data|vbscript):~i', $url)) continue;
            if (!preg_match('~^(?:https?://|mailto:|tel:|/|#|\?)~i', $url)) {
                if (preg_match('~^[a-z0-9.-]+\.[a-z]{2,}(?:/.*)?$~i', $url)) $url = 'https://' . $url;
                else continue;
            }
            $url = function_exists('mb_substr') ? mb_substr($url, 0, 1000, 'UTF-8') : substr($url, 0, 1000);
            $icon = strtolower(trim((string)($item['icon'] ?? 'link')));
            if (!in_array($icon, $allowedIcons, true)) $icon = 'link';
            $clean[] = [
                'label' => $label,
                'url' => $url,
                'icon' => $icon,
                'new_tab' => !empty($item['new_tab']),
                'nofollow' => !empty($item['nofollow']),
                'enabled' => array_key_exists('enabled', $item) ? !empty($item['enabled']) : true,
            ];
        }
        return json_encode($clean, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?: '[]';
    }
}

/**
 * BankMovie public site content control.
 * Stores only presentation/content settings. It never controls database credentials,
 * player stream URLs, authentication logic or executable PHP.
 */
if (!function_exists('bm_site_setting_schema')) {
    function bm_site_setting_schema(): array
    {
        return [
            'general' => [
                'label' => 'هویت و تنظیمات عمومی',
                'fields' => [
                    'site_name_fa' => ['label'=>'نام فارسی سایت','type'=>'text','default'=>'بانک مووی'],
                    'site_name_en' => ['label'=>'نام انگلیسی سایت','type'=>'text','default'=>'BankMovie'],
                    'site_tagline_fa' => ['label'=>'شعار فارسی','type'=>'text','default'=>'دنیای فیلم و سریال بدون محدودیت'],
                    'site_description_fa' => ['label'=>'توضیح عمومی سایت','type'=>'textarea','default'=>'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله و زیرنویس فارسی.'],
                    'brand_logo_path' => ['label'=>'مسیر لوگوی اصلی','type'=>'text','default'=>'/assets/brand/bankmovie-logo.webp','help'=>'نمونه: /assets/brand/bankmovie-logo.webp'],
                    'brand_icon_path' => ['label'=>'مسیر آیکن مربعی','type'=>'text','default'=>'/assets/brand/bankmovie-icon.png'],
                    'accent_color' => ['label'=>'رنگ اصلی پیش‌فرض','type'=>'color','default'=>'#2f7cff'],
                    'maintenance_notice_enabled' => ['label'=>'نمایش پیام سراسری','type'=>'checkbox','default'=>true],
                    'maintenance_notice_text' => ['label'=>'متن پیام سراسری','type'=>'textarea','default'=>''],
                ],
            ],
            'seo' => [
                'label' => 'سئو حرفه‌ای و سرچ کنسول',
                'fields' => [
                    'seo_enabled' => ['label'=>'فعال بودن موتور سئوی مرکزی','type'=>'checkbox','default'=>true,'help'=>'Canonical، Robots، Open Graph، Twitter Card و Schema را در تمام صفحات عمومی یکپارچه می‌کند.'],
                    'seo_canonical_base_url' => ['label'=>'دامنه اصلی Canonical','type'=>'url','default'=>'https://bankmovie.top','help'=>'همه دامنه‌های جایگزین به این دامنه به‌عنوان نسخه اصلی اشاره می‌کنند.'],
                    'seo_home_title' => ['label'=>'عنوان سئوی صفحه اصلی','type'=>'text','default'=>'بانک مووی | دانلود فیلم و سریال با دوبله و زیرنویس فارسی'],
                    'seo_home_description' => ['label'=>'توضیحات سئوی صفحه اصلی','type'=>'textarea','default'=>'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله فارسی، زیرنویس فارسی و لینک مستقیم در بانک مووی.'],
                    'seo_default_description' => ['label'=>'توضیح پیش‌فرض صفحات','type'=>'textarea','default'=>'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله و زیرنویس فارسی در بانک مووی.'],
                    'seo_default_og_image' => ['label'=>'تصویر پیش‌فرض اشتراک‌گذاری','type'=>'text','default'=>'/assets/brand/bankmovie-og.png','help'=>'تصویر پیشنهادی 1200×630؛ مسیر داخلی یا URL کامل.'],
                    'seo_organization_name' => ['label'=>'نام برند در Schema','type'=>'text','default'=>'بانک مووی'],
                    'seo_organization_logo' => ['label'=>'لوگوی مربعی Schema','type'=>'text','default'=>'/assets/brand/bankmovie-icon.png'],
                    'seo_movie_title_template' => ['label'=>'الگوی عنوان فیلم','type'=>'text','default'=>'دانلود فیلم {title_fa} {title_en} {year} | BankMovie','help'=>'متغیرها: {type}، {title_fa}، {title_en}، {year}'],
                    'seo_series_title_template' => ['label'=>'الگوی عنوان سریال','type'=>'text','default'=>'دانلود سریال {title_fa} {title_en} {year} | BankMovie'],
                    'seo_movie_description_template' => ['label'=>'الگوی توضیح فیلم و سریال','type'=>'textarea','default'=>'دانلود {type} {title_fa} {title_en} {year} با دوبله و زیرنویس فارسی، اطلاعات کامل و لینک مستقیم از بانک مووی.','help'=>'متغیرها: {type}، {title_fa}، {title_en}، {year}، {summary}'],
                    'seo_google_verification' => ['label'=>'کد تأیید Google Search Console','type'=>'text','default'=>'','help'=>'فقط مقدار content متای google-site-verification را وارد کن.'],
                    'seo_bing_verification' => ['label'=>'کد تأیید Bing Webmaster Tools','type'=>'text','default'=>'','help'=>'فقط مقدار content متای msvalidate.01 را وارد کن.'],
                    'seo_open_graph_enabled' => ['label'=>'Open Graph برای تلگرام و شبکه‌های اجتماعی','type'=>'checkbox','default'=>true],
                    'seo_twitter_cards_enabled' => ['label'=>'Twitter / X Cards','type'=>'checkbox','default'=>true],
                    'seo_jsonld_enabled' => ['label'=>'Schema JSON-LD و Breadcrumb','type'=>'checkbox','default'=>true],
                    'seo_dynamic_sitemap_enabled' => ['label'=>'ساخت Sitemap زنده از دیتابیس','type'=>'checkbox','default'=>true,'help'=>'فایل‌های قدیمی فیزیکی فقط هنگام خطای دیتابیس به‌عنوان fallback استفاده می‌شوند.'],
                    'seo_sitemap_auto_sync_enabled' => ['label'=>'ثبت خودکار پست جدید در Sitemap','type'=>'checkbox','default'=>true,'help'=>'مثل وردپرس؛ فیلم یا سریال تازه بلافاصله از دیتابیس وارد Sitemap زنده و Recent Sitemap می‌شود و نیاز به بازسازی دستی ندارد.'],
                ],
            ],
            'typography' => [
                'label' => 'تایپوگرافی پیشرفته سایت',
                'fields' => [
                    'site_font_family' => ['label'=>'فونت پیش‌فرض کل سایت','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options(),'help'=>'فونت پایه برای قسمت‌هایی که فونت اختصاصی ندارند.'],
                    'font_header_family' => ['label'=>'فونت هدر و منوی اصلی','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_hero_family' => ['label'=>'فونت اسلایدر و تیترهای قهرمان','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_heading_family' => ['label'=>'فونت تیترهای H1 تا H6','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_body_family' => ['label'=>'فونت متن‌های عمومی و توضیحات','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_card_family' => ['label'=>'فونت کارت‌های فیلم و سریال','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_button_family' => ['label'=>'فونت دکمه‌ها و لینک‌های عملیاتی','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_form_family' => ['label'=>'فونت فرم‌ها، ورودی‌ها و جستجو','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_footer_family' => ['label'=>'فونت فوتر','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_mobile_nav_family' => ['label'=>'فونت نوار پایین موبایل','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_movie_meta_family' => ['label'=>'فونت مشخصات فیلم، امتیاز و دانلود','type'=>'select','default'=>'bonvf','options'=>bm_site_typography_options()],
                    'font_body_size' => ['label'=>'اندازه پایه متن سایت (px)','type'=>'number','default'=>14,'min'=>11,'max'=>22],
                    'font_header_size' => ['label'=>'اندازه متن منوی هدر (px)','type'=>'number','default'=>13,'min'=>10,'max'=>20],
                    'font_heading_scale' => ['label'=>'ضریب اندازه تیترها (درصد)','type'=>'number','default'=>100,'min'=>75,'max'=>145],
                    'font_card_title_size' => ['label'=>'اندازه عنوان کارت‌ها (px)','type'=>'number','default'=>14,'min'=>10,'max'=>24],
                    'font_button_size' => ['label'=>'اندازه متن دکمه‌ها (px)','type'=>'number','default'=>13,'min'=>10,'max'=>20],
                    'font_footer_size' => ['label'=>'اندازه متن فوتر (px)','type'=>'number','default'=>12,'min'=>9,'max'=>18],
                    'font_mobile_nav_size' => ['label'=>'اندازه عنوان نوار موبایل (px)','type'=>'number','default'=>10,'min'=>8,'max'=>15],
                ],
            ],
            'interface' => [
                'label' => 'ظاهر عمومی، نشان‌ها و کنترل‌ها',
                'fields' => [
                    'ui_admin_verified_badge_enabled' => ['label'=>'نمایش تیک آبی فقط برای مدیر','type'=>'checkbox','default'=>true,'help'=>'این تیک برای کاربران عادی و VIP نمایش داده نمی‌شود.'],
                    'ui_vip_member_badge_enabled' => ['label'=>'نمایش نشان طلایی برای کاربران VIP','type'=>'checkbox','default'=>true,'help'=>'مدیر صرفاً به‌خاطر نقش مدیریتی نشان VIP نمی‌گیرد.'],
                    'ui_user_theme_enabled' => ['label'=>'فعال بودن تم انتخابی کاربران','type'=>'checkbox','default'=>true,'help'=>'رنگ انتخابی هر کاربر در همه صفحات عمومی اعمال می‌شود.'],
                    'ui_theme_logo_enabled' => ['label'=>'تغییر رنگ لوگو همراه تم کاربر','type'=>'checkbox','default'=>true,'help'=>'لوگوی اصلی بدون ساخت فایل جداگانه با رنگ همان تم نمایش داده می‌شود.'],
                    'ui_theme_transition_enabled' => ['label'=>'انیمیشن نرم تغییر تم و لوگو','type'=>'checkbox','default'=>true],
                    'ui_neon_checkbox_enabled' => ['label'=>'فعال بودن چک‌باکس نئونی','type'=>'checkbox','default'=>true],
                    'ui_neon_checkbox_color' => ['label'=>'رنگ اصلی چک‌باکس نئونی','type'=>'color','default'=>'#00ffaa'],
                    'ui_neon_checkbox_dark_color' => ['label'=>'رنگ تیره قاب چک‌باکس','type'=>'color','default'=>'#00cc88'],
                    'ui_neon_checkbox_light_color' => ['label'=>'رنگ روشن افکت چک‌باکس','type'=>'color','default'=>'#88ffdd'],
                    'ui_neon_checkbox_size' => ['label'=>'اندازه چک‌باکس نئونی (px)','type'=>'number','default'=>30,'min'=>24,'max'=>38,'help'=>'کد اصلی Uiverse با اندازه ۳۰ پیکسل استفاده می‌شود.'],
                ],
            ],
            'loading' => [
                'label' => 'لودینگ‌ها و اسکلت‌ها',
                'fields' => [
                    'loading_enabled' => ['label'=>'فعال بودن سیستم لودینگ مرکزی','type'=>'checkbox','default'=>true,'help'=>'لودینگ‌های قدیمی صفحه‌ها را با یک ظاهر یکپارچه و قابل‌کنترل جایگزین می‌کند.'],
                    'loading_style' => ['label'=>'مدل لودینگ','type'=>'select','default'=>'logo','options'=>[
                        'logo'=>'لوگوی بانک‌مووی با حلقه نور',
                        'rings'=>'حلقه‌های سینمایی',
                        'pulse'=>'پالس نورانی',
                        'dots'=>'نقطه‌های متحرک',
                        'cinema'=>'نوار سینمایی',
                    ]],
                    'loading_show_logo' => ['label'=>'نمایش لوگوی بانک‌مووی','type'=>'checkbox','default'=>true],
                    'loading_logo_path' => ['label'=>'مسیر لوگوی لودینگ','type'=>'text','default'=>'','help'=>'خالی بماند تا لوگوی هماهنگ با تم کاربر استفاده شود.'],
                    'loading_show_text' => ['label'=>'نمایش متن زیر لودینگ','type'=>'checkbox','default'=>true],
                    'loading_text_fa' => ['label'=>'متن لودینگ','type'=>'text','default'=>'در حال آماده‌سازی بانک مووی...'],
                    'loading_use_theme_accent' => ['label'=>'هماهنگی رنگ لودینگ با تم کاربر','type'=>'checkbox','default'=>true],
                    'loading_accent_color' => ['label'=>'رنگ ثابت لودینگ','type'=>'color','default'=>'#2f7cff','help'=>'وقتی هماهنگی با تم خاموش باشد استفاده می‌شود.'],
                    'loading_background_color' => ['label'=>'رنگ پس‌زمینه لودینگ','type'=>'color','default'=>'#05070d'],
                    'loading_background_opacity' => ['label'=>'شفافیت پس‌زمینه (درصد)','type'=>'number','default'=>96,'min'=>70,'max'=>100],
                    'loading_backdrop_blur' => ['label'=>'مقدار محوشدگی پس‌زمینه (px)','type'=>'number','default'=>16,'min'=>0,'max'=>32],
                    'loading_size' => ['label'=>'اندازه لودینگ (px)','type'=>'number','default'=>104,'min'=>64,'max'=>160],
                    'loading_min_duration_ms' => ['label'=>'حداقل زمان نمایش (میلی‌ثانیه)','type'=>'number','default'=>450,'min'=>0,'max'=>3000],
                    'loading_max_duration_ms' => ['label'=>'حداکثر زمان نمایش اضطراری (میلی‌ثانیه)','type'=>'number','default'=>4500,'min'=>1500,'max'=>12000],
                    'loading_home_enabled' => ['label'=>'لودینگ صفحه اصلی','type'=>'checkbox','default'=>true],
                    'loading_movie_enabled' => ['label'=>'لودینگ صفحه فیلم و سریال','type'=>'checkbox','default'=>true],
                    'loading_search_enabled' => ['label'=>'لودینگ جستجو','type'=>'checkbox','default'=>true],
                    'loading_archives_enabled' => ['label'=>'لودینگ آرشیوها و مشاهده همه','type'=>'checkbox','default'=>true],
                    'loading_player_enabled' => ['label'=>'لودینگ پلیر','type'=>'checkbox','default'=>true],
                    'loading_collections_enabled' => ['label'=>'لودینگ کالکشن‌ها و دسته‌بندی‌ها','type'=>'checkbox','default'=>true],
                    'loading_profile_enabled' => ['label'=>'لودینگ پروفایل، ورود و ثبت‌نام','type'=>'checkbox','default'=>true],
                    'loading_other_pages_enabled' => ['label'=>'لودینگ سایر صفحه‌های عمومی','type'=>'checkbox','default'=>false],
                    'loading_skeleton_enabled' => ['label'=>'نمایش Skeleton کارت‌ها هنگام دریافت محتوا','type'=>'checkbox','default'=>true],
                    'loading_skeleton_speed_ms' => ['label'=>'سرعت حرکت Skeleton (میلی‌ثانیه)','type'=>'number','default'=>1250,'min'=>500,'max'=>3000],
                ],
            ],
            'header' => [
                'label' => 'هدر و منوی اصلی',
                'fields' => [
                    'header_enabled' => ['label'=>'نمایش هدر اصلی','type'=>'checkbox','default'=>true],
                    'header_home_label_fa' => ['label'=>'عنوان خانه','type'=>'text','default'=>'خانه'],
                    'header_search_label_fa' => ['label'=>'عنوان جستجو','type'=>'text','default'=>'جستجو'],
                    'header_collections_label_fa' => ['label'=>'عنوان کالکشن‌ها','type'=>'text','default'=>'کالکشن‌ها'],
                    'header_categories_label_fa' => ['label'=>'عنوان دسته‌بندی','type'=>'text','default'=>'دسته‌بندی'],
                    'header_player_label_fa' => ['label'=>'عنوان پلیر','type'=>'text','default'=>'پلیر'],
                    'header_apps_label_fa' => ['label'=>'عنوان اپلیکیشن‌ها','type'=>'text','default'=>'اپلیکیشن‌ها'],
                    'header_profile_label_fa' => ['label'=>'عنوان پروفایل','type'=>'text','default'=>'پروفایل'],
                    'header_show_home' => ['label'=>'نمایش خانه','type'=>'checkbox','default'=>true],
                    'header_show_search' => ['label'=>'نمایش جستجو','type'=>'checkbox','default'=>true],
                    'header_show_collections' => ['label'=>'نمایش کالکشن‌ها','type'=>'checkbox','default'=>true],
                    'header_show_categories' => ['label'=>'نمایش دسته‌بندی','type'=>'checkbox','default'=>true],
                    'header_show_player' => ['label'=>'نمایش پلیر','type'=>'checkbox','default'=>true],
                    'header_show_apps' => ['label'=>'نمایش اپلیکیشن‌ها','type'=>'checkbox','default'=>true],
                    'header_show_notifications' => ['label'=>'نمایش اعلان‌ها','type'=>'checkbox','default'=>true],
                ],
            ],
            'mobile_nav' => [
                'label' => 'ناوبری پایین موبایل',
                'fields' => [
                    'mobile_nav_enabled' => ['label'=>'فعال بودن ناوبری موبایل','type'=>'checkbox','default'=>true],
                    'mobile_nav_home_label' => ['label'=>'عنوان خانه','type'=>'text','default'=>'خانه'],
                    'mobile_nav_search_label' => ['label'=>'عنوان جستجو','type'=>'text','default'=>'جستجو'],
                    'mobile_nav_categories_label' => ['label'=>'عنوان دسته‌بندی','type'=>'text','default'=>'دسته‌بندی'],
                    'mobile_nav_player_label' => ['label'=>'عنوان پلیر','type'=>'text','default'=>'پلیر'],
                    'mobile_nav_profile_label' => ['label'=>'عنوان پروفایل','type'=>'text','default'=>'پروفایل'],
                    'mobile_nav_login_label' => ['label'=>'عنوان ورود','type'=>'text','default'=>'ورود'],
                    'mobile_nav_show_categories' => ['label'=>'نمایش دسته‌بندی در مرکز','type'=>'checkbox','default'=>true],
                    'mobile_nav_show_player' => ['label'=>'نمایش پلیر','type'=>'checkbox','default'=>true],
                    'mobile_nav_show_profile' => ['label'=>'نمایش پروفایل/ورود','type'=>'checkbox','default'=>true],
                ],
            ],
            'footer' => [
                'label' => 'فوتر و شبکه‌های اجتماعی',
                'fields' => [
                    'footer_enabled' => ['label'=>'نمایش فوتر اجتماعی','type'=>'checkbox','default'=>true],
                    'footer_headline_fa' => ['label'=>'تیتر فوتر','type'=>'text','default'=>'همیشه یک داستان تازه برای دیدن هست'],
                    'footer_about_enabled' => ['label'=>'نمایش معرفی کوتاه','type'=>'checkbox','default'=>true],
                    'footer_about_text_fa' => ['label'=>'متن معرفی کوتاه','type'=>'textarea','default'=>'بانک مووی؛ مرجع سریع و ساده برای پیدا کردن فیلم، سریال و انیمه.'],
                    'footer_quick_links_enabled' => ['label'=>'نمایش لینک‌های مفید','type'=>'checkbox','default'=>true],
                    'footer_links_title_fa' => ['label'=>'عنوان بخش لینک‌های مفید','type'=>'text','default'=>'لینک‌های مفید'],
                    'footer_links_json' => ['label'=>'مدیریت لینک‌های مفید فوتر','type'=>'footer_links','default'=>bm_site_default_footer_links_json(),'help'=>'لینک داخلی یا خارجی اضافه کن، آیکن و ترتیب را عوض کن و مشخص کن در تب جدید باز شود.'],
                    'footer_tools_enabled' => ['label'=>'نمایش ابزارهای مفید','type'=>'checkbox','default'=>true],

                    // V62: recommended player downloads in the real site footer.
                    'footer_players_enabled' => ['label'=>'نمایش VLC و MX Player در لینک‌های مفید','type'=>'checkbox','default'=>true],
                    'footer_vlc_enabled' => ['label'=>'نمایش VLC در لینک‌های مفید','type'=>'checkbox','default'=>true],
                    'footer_vlc_label_fa' => ['label'=>'عنوان VLC','type'=>'text','default'=>'دانلود VLC'],
                    'footer_vlc_download_url' => ['label'=>'لینک دانلود VLC','type'=>'url','default'=>'','help'=>'لینک نهایی دانلود VLC را وارد کنید. تا وقتی خالی باشد دکمه به # می‌رود.'],
                    'footer_mxplayer_enabled' => ['label'=>'نمایش MX Player در لینک‌های مفید','type'=>'checkbox','default'=>true],
                    'footer_mxplayer_label_fa' => ['label'=>'عنوان MX Player','type'=>'text','default'=>'دانلود MX Player'],
                    'footer_mxplayer_download_url' => ['label'=>'لینک دانلود MX Player','type'=>'url','default'=>'','help'=>'لینک نهایی دانلود MX Player را وارد کنید. تا وقتی خالی باشد دکمه به # می‌رود.'],

                    'footer_support_enabled' => ['label'=>'نمایش دکمه پشتیبانی','type'=>'checkbox','default'=>true],
                    'footer_support_label_fa' => ['label'=>'عنوان دکمه پشتیبانی','type'=>'text','default'=>'ارسال تیکت پشتیبانی'],
                    'footer_support_url' => ['label'=>'لینک پشتیبانی','type'=>'text','default'=>'/request'],
                    'footer_copyright_fa' => ['label'=>'متن کپی‌رایت','type'=>'text','default'=>'تمامی حقوق برای بانک مووی محفوظ است.'],
                    'telegram_enabled' => ['label'=>'نمایش تلگرام','type'=>'checkbox','default'=>true],
                    'telegram_url' => ['label'=>'لینک تلگرام','type'=>'url','default'=>'https://t.me/bankmovie_org'],
                    'telegram_label_fa' => ['label'=>'عنوان تلگرام','type'=>'text','default'=>'تلگرام'],
                    'instagram_enabled' => ['label'=>'نمایش اینستاگرام','type'=>'checkbox','default'=>true],
                    'instagram_url' => ['label'=>'لینک اینستاگرام','type'=>'url','default'=>'https://instagram.com/bankmovie_org'],
                    'instagram_label_fa' => ['label'=>'عنوان اینستاگرام','type'=>'text','default'=>'اینستاگرام'],
                ],
            ],
            'home' => [
                'label' => 'بخش‌های صفحه اصلی',
                'fields' => [
                    'home_show_slider' => ['label'=>'نمایش اسلایدر','type'=>'checkbox','default'=>true],
                    'home_slider_show_imdb_votes' => ['label'=>'نمایش تعداد رأی IMDb در اسلایدر','type'=>'checkbox','default'=>false,'help'=>'امتیاز IMDb باقی می‌ماند و فقط تعداد رأی مخفی یا نمایش داده می‌شود.'],
                    'home_story_image_fit' => ['label'=>'نحوه نمایش تصویر استوری','type'=>'select','default'=>'cover','options'=>['cover'=>'پرکردن قاب','contain'=>'نمایش کامل تصویر']],
                    'home_story_fallback_path' => ['label'=>'تصویر جایگزین استوری خراب','type'=>'text','default'=>'','help'=>'خالی بماند تا جایگزین ساده و بدون لوگوی BM نمایش داده شود.'],
                    'home_show_stories' => ['label'=>'نمایش استوری‌ها','type'=>'checkbox','default'=>true],
                    'home_show_genres' => ['label'=>'نمایش ژانرها','type'=>'checkbox','default'=>true],
                    'home_show_countries' => ['label'=>'نمایش کشورها','type'=>'checkbox','default'=>true],
                    'home_show_collections' => ['label'=>'نمایش کالکشن‌ها','type'=>'checkbox','default'=>true],
                    'home_show_admin_picks' => ['label'=>'نمایش پیشنهاد مدیریت','type'=>'checkbox','default'=>true],
                    'home_show_top_movies' => ['label'=>'نمایش فیلم‌های برتر','type'=>'checkbox','default'=>true],
                    'home_show_top_series' => ['label'=>'نمایش سریال‌های برتر','type'=>'checkbox','default'=>true],
                    'home_show_user_rated' => ['label'=>'نمایش برگزیده کاربران','type'=>'checkbox','default'=>true],
                    'home_show_dubbed' => ['label'=>'نمایش دوبله فارسی','type'=>'checkbox','default'=>true],
                    'home_show_suggestions' => ['label'=>'نمایش پیشنهاد هوشمند','type'=>'checkbox','default'=>true],
                    'home_stories_title_fa' => ['label'=>'عنوان استوری‌ها','type'=>'text','default'=>'استوری‌ها'],
                    'home_genres_title_fa' => ['label'=>'عنوان ژانرها','type'=>'text','default'=>'ژانرها'],
                    'home_countries_title_fa' => ['label'=>'عنوان کشورها','type'=>'text','default'=>'کشورهای محبوب'],
                    'home_archive_guide_video_url' => ['label'=>'لینک ویدیو راهنمای آرشیوها','type'=>'url','default'=>'','help'=>'لینک مستقیم فایل ویدیو (مثلاً MP4/WebM) را وارد کنید.'],
                ],
            ],
            'collections_design' => [
                'label' => 'ظاهر کالکشن‌ها و تصاویر',
                'fields' => [
                    'collection_hero_image_fit' => ['label'=>'نحوه نمایش تصویر اصلی کالکشن','type'=>'select','default'=>'cover','options'=>['cover'=>'پرکردن هیرو','contain'=>'نمایش کامل تصویر']],
                    'collection_hero_image_position' => ['label'=>'موقعیت تصویر اصلی کالکشن','type'=>'select','default'=>'center 24%','options'=>['center 24%'=>'مرکز متمایل به بالا','center center'=>'مرکز','center top'=>'بالا','center bottom'=>'پایین']],
                    'collection_card_image_fit' => ['label'=>'نحوه نمایش تصویر کارت کالکشن','type'=>'select','default'=>'cover','options'=>['cover'=>'پرکردن کارت','contain'=>'نمایش کامل تصویر']],
                    'collection_show_view_all_links' => ['label'=>'نمایش دکمه‌های مشاهده همه کالکشن‌ها','type'=>'checkbox','default'=>true],
                ],
            ],
            'movie_design' => [
                'label' => 'قالب صفحه فیلم؛ ویندوز و موبایل',
                'fields' => [
                    'movie_windows_template' => [
                        'label'=>'قالب فعال movie.php در ویندوز',
                        'type'=>'select',
                        'default'=>'classic',
                        'options'=>[
                            'classic'=>'قالب فعلی بانک مووی',
                            'cinematic'=>'قالب سینمایی جدید (مشابه نمونه ارسالی)',
                        ],
                        'help'=>'این انتخاب فقط در نمایشگرهای دسکتاپ/ویندوز اعمال می‌شود و مستقل از قالب موبایل است.'
                    ],
                    'movie_cinematic_accent_color' => [
                        'label'=>'رنگ اصلی قالب سینمایی ویندوز',
                        'type'=>'color',
                        'default'=>'#8b2cff',
                        'help'=>'رنگ دکمه‌ها، تب‌ها و خطوط نورانی قالب دوم دسکتاپ.'
                    ],
                    'movie_cinematic_show_tabs' => [
                        'label'=>'نمایش نوار تب‌های سینمایی در ویندوز',
                        'type'=>'checkbox',
                        'default'=>true,
                        'help'=>'دانلود باکس، اطلاعات بیشتر، نظرات و پیشنهادها را به‌صورت نوار مرتب نمایش می‌دهد.'
                    ],
                    'movie_mobile_template' => [
                        'label'=>'چیدمان اطلاعات فیلم در موبایل',
                        'type'=>'select',
                        'default'=>'classic',
                        'options'=>[
                            'classic'=>'نسخه فعلی (پیش‌فرض)',
                            'compact_card'=>'طرح ۱ — کارت جمع‌وجور',
                            'minimal_rows'=>'طرح ۲ — ردیفی و مینیمال',
                            'cinematic_modern'=>'طرح ۳ — سینمایی و مدرن',
                            'pro_compact'=>'طرح ۴ — فشرده و حرفه‌ای',
                            'vertical_card'=>'طرح ۵ — کارت عمودی',
                            'dashboard'=>'طرح ۶ — داشبوردی',
                            'premium_stack'=>'طرح ۷ — Premium Stack',
                        ],
                        'help'=>'فقط ادمین این مقدار را تغییر می‌دهد؛ قالب انتخابی برای همه کاربران موبایل اعمال می‌شود. نسخه فعلی همیشه به‌عنوان پیش‌فرض قابل بازگشت است.'
                    ],
                    'movie_mobile_poster_size' => [
                        'label'=>'اندازه پوستر در قالب‌های موبایل',
                        'type'=>'select',
                        'default'=>'normal',
                        'options'=>[
                            'small'=>'کوچک',
                            'normal'=>'استاندارد',
                            'large'=>'بزرگ',
                        ],
                        'help'=>'روی قالب فعلی (پیش‌فرض) اثر ندارد.'
                    ],
                    'movie_mobile_meta_density' => [
                        'label'=>'تراکم کارت‌های اطلاعات موبایل',
                        'type'=>'select',
                        'default'=>'normal',
                        'options'=>[
                            'compact'=>'فشرده',
                            'normal'=>'استاندارد',
                            'airy'=>'باز و راحت',
                        ],
                        'help'=>'فاصله و ارتفاع آیتم‌های سال، نوع، زبان، کشور، رده سنی و سایر مشخصات را کنترل می‌کند.'
                    ],
                    'movie_mobile_story_lines' => [
                        'label'=>'تعداد خطوط خلاصه داستان قبل از «ادامه داستان»',
                        'type'=>'number',
                        'default'=>4,
                        'min'=>2,
                        'max'=>8,
                    ],
                    'movie_mobile_show_english_title' => [
                        'label'=>'نمایش عنوان انگلیسی در موبایل',
                        'type'=>'checkbox',
                        'default'=>true,
                        'help'=>'فقط در هفت قالب موبایل جدید اعمال می‌شود.'
                    ],
                ],
            ],
            'categories' => [
                'label' => 'صفحه دسته‌بندی و ژانرها',
                'fields' => [
                    'page_categories_enabled' => ['label'=>'فعال بودن صفحه دسته‌بندی','type'=>'checkbox','default'=>true],
                    'categories_title_fa' => ['label'=>'عنوان صفحه','type'=>'text','default'=>'دسته‌بندی بر اساس ژانر'],
                    'categories_description_fa' => ['label'=>'توضیح صفحه','type'=>'textarea','default'=>'ژانر مورد علاقه‌ات را از آرشیو واقعی انتخاب کن و مستقیم وارد نتیجه‌ها شو.'],
                    'categories_default_archive' => [
                        'label'=>'آرشیو پیش‌فرض صفحه',
                        'type'=>'select',
                        'default'=>'2',
                        'options'=>['1'=>'آرشیو ۱','2'=>'آرشیو ۲','3'=>'آرشیو ۳'],
                    ],
                    'categories_show_archive1' => ['label'=>'نمایش آرشیو ۱','type'=>'checkbox','default'=>true],
                    'categories_show_archive2' => ['label'=>'نمایش آرشیو ۲','type'=>'checkbox','default'=>true],
                    'categories_show_archive3' => ['label'=>'نمایش آرشیو ۳','type'=>'checkbox','default'=>true],
                    'categories_show_counts' => ['label'=>'نمایش تعداد آثار هر ژانر','type'=>'checkbox','default'=>true],
                    'categories_show_images' => ['label'=>'نمایش تصویر کارت‌های ژانر','type'=>'checkbox','default'=>true],
                    'categories_inline_search_enabled' => ['label'=>'نمایش جستجوی داخل ژانرها','type'=>'checkbox','default'=>true],
                ],
            ],
            'search' => [
                'label' => 'جستجوی سریع و پیشرفته',
                'fields' => [
                    'search_kicker_fa' => ['label'=>'برچسب بالا','type'=>'text','default'=>'جستجوی سریع'],
                    'search_title_fa' => ['label'=>'عنوان اصلی','type'=>'text','default'=>'فیلم، سریال یا بازیگر موردنظرت را پیدا کن'],
                    'search_description_fa' => ['label'=>'توضیح','type'=>'textarea','default'=>'نتیجه‌ها همین‌جا نمایش داده می‌شوند و می‌توانی مستقیم وارد صفحه موردنظرت شوی.'],
                    'search_placeholder_fa' => ['label'=>'متن داخل کادر','type'=>'text','default'=>'جستجوی فیلم، سریال یا بازیگر...'],
                    'search_submit_label_fa' => ['label'=>'عنوان دکمه','type'=>'text','default'=>'جستجو'],
                    'search_advanced_label_fa' => ['label'=>'عنوان جستجوی پیشرفته','type'=>'text','default'=>'جستجوی پیشرفته'],
                    'search_advanced_help_fa' => ['label'=>'راهنمای پایین مودال','type'=>'text','default'=>'برای فیلتر سال، ژانر و کشور از جستجوی پیشرفته استفاده کن'],
                    'advanced_search_enabled' => ['label'=>'فعال بودن جستجوی پیشرفته','type'=>'checkbox','default'=>true],
                    'search_archive1_enabled' => ['label'=>'جستجو در آرشیو ۱','type'=>'checkbox','default'=>true],
                    'search_archive2_enabled' => ['label'=>'جستجو در آرشیو ۲','type'=>'checkbox','default'=>true],
                    'search_archive3_enabled' => ['label'=>'جستجو در آرشیو ۳','type'=>'checkbox','default'=>true],
                    'search_show_actor_director' => ['label'=>'نمایش فیلتر بازیگر و کارگردان','type'=>'checkbox','default'=>true],
                    'search_show_country' => ['label'=>'نمایش فیلتر کشور','type'=>'checkbox','default'=>true],
                    'search_show_suggested_filter' => ['label'=>'نمایش فیلتر آثار پیشنهادی','type'=>'checkbox','default'=>true],
                ],
            ],
            'player' => [
                'label' => 'پلیر و انتخاب روش پخش',
                'fields' => [
                    'player_choice_title_fa' => ['label'=>'عنوان مودال پلیر','type'=>'text','default'=>'انتخاب روش پخش'],
                    'player_softsub_note_fa' => ['label'=>'پیام سافت‌ساب','type'=>'textarea','default'=>'برای نمایش صحیح زیرنویس سافت‌ساب حتماً از پلیر خارجی استفاده کنید.'],
                    'player_copy_link_label_fa' => ['label'=>'عنوان کپی لینک','type'=>'text','default'=>'کپی لینک مستقیم'],
                    'player_copied_label_fa' => ['label'=>'پیام کپی موفق','type'=>'text','default'=>'لینک کپی شد'],
                    'player_internal_label_fa' => ['label'=>'عنوان پلیر داخلی','type'=>'text','default'=>'پخش با پلیر داخلی'],
                ],
            ],
            'application' => [
                'label' => 'صفحه اپلیکیشن و دانلودها',
                'fields' => [
                    'app_page_enabled' => ['label'=>'فعال بودن صفحه اپلیکیشن','type'=>'checkbox','default'=>true],
                    'app_bottom_nav_banner_enabled' => ['label'=>'بنر اپلیکیشن بالای منوی پایین موبایل','type'=>'checkbox','default'=>false,'help'=>'نمایش کارت «اپلیکیشن بانک مووی منتشر شد» درست بالای Footer Nav موبایل. این گزینه به‌صورت پیش‌فرض خاموش است.'],
                    'app_hero_title_fa' => ['label'=>'عنوان اصلی','type'=>'text','default'=>'دانلود اپلیکیشن ها'],
                    'app_hero_lead_fa' => ['label'=>'توضیح اصلی','type'=>'textarea','default'=>'اپلیکیشن اندروید بانک مووی با تجربه‌ای سریع، روان و بهینه برای موبایل، Android TV و Android Box منتشر شد. بعد از نصب، بدون محدودیت از دنیایی از فیلم و سریال بدون سانسور لذت ببر.'],
                    'app_apk_button_fa' => ['label'=>'عنوان دانلود APK','type'=>'text','default'=>'دانلود مستقیم APK'],
                    'app_tv_button_fa' => ['label'=>'عنوان نسخه تلویزیون','type'=>'text','default'=>'دانلود نسخه تلویزیون'],
                    'app_zip_button_fa' => ['label'=>'عنوان ZIP','type'=>'text','default'=>'دانلود ZIP کم‌حجم'],
                    'app_pwa_button_fa' => ['label'=>'عنوان نصب مستقیم PWA','type'=>'text','default'=>'نصب مستقیم نسخه وب'],
                    'app_ios_button_fa' => ['label'=>'عنوان نسخه آیفون','type'=>'text','default'=>'نسخه وب مناسب آیفون'],
                    'app_windows_soon_fa' => ['label'=>'عنوان نسخه ویندوز','type'=>'text','default'=>'نسخه ویندوز به‌زودی'],
                    'app_download_section_title_fa' => ['label'=>'عنوان بخش دانلود','type'=>'text','default'=>'دانلود و نصب'],
                    'app_pwa_card_title_fa' => ['label'=>'عنوان کارت PWA','type'=>'text','default'=>'نصب مستقیم نسخه وب'],
                    'app_pwa_card_description_fa' => ['label'=>'توضیح کارت PWA','type'=>'textarea','default'=>'نصب مستقیم روی Android، Windows، macOS و Linux؛ بدون دانلود فایل و با اجرای مستقل.'],
                ],
            ],
            'pwa' => [
                'label' => 'PWA و نصب نسخه وب',
                'fields' => [
                    'pwa_name' => ['label'=>'نام کامل PWA','type'=>'text','default'=>'بانک مووی | BankMovie'],
                    'pwa_short_name' => ['label'=>'نام کوتاه','type'=>'text','default'=>'BankMovie'],
                    'pwa_description' => ['label'=>'توضیح PWA','type'=>'textarea','default'=>'فیلم و سریال، جستجو، کالکشن‌ها و پخش آنلاین در نسخه وب بانک مووی'],
                    'pwa_theme_color' => ['label'=>'رنگ نوار مرورگر','type'=>'color','default'=>'#05050a'],
                    'pwa_background_color' => ['label'=>'رنگ پس‌زمینه شروع','type'=>'color','default'=>'#05050a'],
                    'pwa_direct_install_label_fa' => ['label'=>'متن دکمه نصب مستقیم','type'=>'text','default'=>'نصب مستقیم نسخه وب'],
                    'pwa_manual_label_fa' => ['label'=>'متن راهنمای نصب','type'=>'text','default'=>'راهنمای نصب نسخه وب'],
                ],
            ],
            'pages' => [
                'label' => 'صفحه‌ها و دسترسی عمومی',
                'fields' => [
                    'page_search_enabled' => ['label'=>'فعال بودن صفحه جستجو','type'=>'checkbox','default'=>true],
                    'page_collections_enabled' => ['label'=>'فعال بودن صفحه کالکشن‌ها','type'=>'checkbox','default'=>true],
                    'page_player_enabled' => ['label'=>'فعال بودن صفحه پلیر','type'=>'checkbox','default'=>true],
                    'page_actors_enabled' => ['label'=>'فعال بودن صفحه بازیگرها','type'=>'checkbox','default'=>true],
                    'page_profile_enabled' => ['label'=>'فعال بودن صفحه پروفایل','type'=>'checkbox','default'=>true],
                    'disabled_page_message_fa' => ['label'=>'پیام صفحه غیرفعال','type'=>'textarea','default'=>'این بخش موقتاً از دسترس خارج شده است.'],
                ],
            ],
            'actor_page' => [
                'label' => 'صفحه بازیگر و نتایج',
                'fields' => [
                    'actor_role_label_fa' => ['label'=>'برچسب نقش بازیگر','type'=>'text','default'=>'بازیگر'],
                    'actor_results_suffix_fa' => ['label'=>'پسوند تعداد آثار','type'=>'text','default'=>'عنوان پیدا شد'],
                    'actor_empty_text_fa' => ['label'=>'متن نبود نتیجه','type'=>'text','default'=>'اثری برای این بازیگر پیدا نشد'],
                    'actor_watch_button_fa' => ['label'=>'عنوان دکمه مشاهده','type'=>'text','default'=>'تماشا کنید'],
                ],
            ],
            'app_content' => [
                'label' => 'متن‌های جزئی صفحه اپلیکیشن',
                'fields' => [
                    'app_kicker_suffix_fa' => ['label'=>'متن کنار نسخه','type'=>'text','default'=>'برای Android 6+'],
                    'app_changes_title_fa' => ['label'=>'عنوان تغییرات نسخه','type'=>'text','default'=>'تغییرات آخرین نسخه'],
                    'app_changes_description_fa' => ['label'=>'توضیح تغییرات نسخه','type'=>'text','default'=>'این بخش مستقیماً از اطلاعات آخرین به‌روزرسانی خوانده می‌شود.'],
                    'app_features_title_fa' => ['label'=>'عنوان قابلیت‌ها','type'=>'text','default'=>'چرا بانک مووی؟'],
                    'app_features_description_fa' => ['label'=>'توضیح قابلیت‌ها','type'=>'textarea','default'=>'قابلیت‌های اصلی نسخه اندروید بانک مووی برای تماشای راحت‌تر و سریع‌تر.'],
                    'app_screenshots_title_fa' => ['label'=>'عنوان تصاویر','type'=>'text','default'=>'نمای اپلیکیشن'],
                    'app_screenshots_description_fa' => ['label'=>'توضیح تصاویر','type'=>'text','default'=>'برای بزرگ دیدن تصاویر، روی هر اسکرین‌شات بزن.'],
                    'app_download_description_fa' => ['label'=>'توضیح بخش دانلود','type'=>'textarea','default'=>'نسخه APK و نسخه وب قابل نصب برای Android، iPhone، iPad و دسکتاپ در دسترس است.'],
                    'app_android_tile_title_fa' => ['label'=>'عنوان کارت اندروید','type'=>'text','default'=>'دانلود APK'],
                    'app_tv_tile_title_fa' => ['label'=>'عنوان کارت تلویزیون','type'=>'text','default'=>'نسخه تلویزیون'],
                    'app_ios_tile_title_fa' => ['label'=>'عنوان کارت آیفون','type'=>'text','default'=>'نسخه وب مناسب آیفون'],
                    'app_zip_tile_title_fa' => ['label'=>'عنوان کارت ZIP','type'=>'text','default'=>'نسخه کم‌حجم (ZIP)'],
                ],
            ],
            'comments' => [
                'label' => 'نظرات، امتیاز و تعامل کاربران',
                'fields' => [
                    'comments_enabled' => ['label'=>'فعال بودن کامل بخش نظرات','type'=>'checkbox','default'=>true],
                    'comment_replies_enabled' => ['label'=>'فعال بودن پاسخ به نظرات','type'=>'checkbox','default'=>true],
                    'comment_votes_enabled' => ['label'=>'فعال بودن لایک و دیسلایک','type'=>'checkbox','default'=>true],
                    'comment_reports_enabled' => ['label'=>'فعال بودن گزارش تخلف','type'=>'checkbox','default'=>true],
                    'comment_spoiler_enabled' => ['label'=>'فعال بودن برچسب اسپویل','type'=>'checkbox','default'=>true],
                    'comment_ratings_enabled' => ['label'=>'فعال بودن امتیاز ستاره‌ای','type'=>'checkbox','default'=>true],
                    'comment_require_login' => ['label'=>'اجبار ورود برای ثبت نظر','type'=>'checkbox','default'=>true],
                    'comment_auto_approve_admin' => ['label'=>'تأیید خودکار نظر مدیر','type'=>'checkbox','default'=>true],
                    'comment_auto_approve_vip' => ['label'=>'تأیید خودکار نظر کاربران ویژه','type'=>'checkbox','default'=>true],
                    'comment_edit_minutes' => ['label'=>'مهلت ویرایش نظر به دقیقه','type'=>'number','default'=>10,'min'=>0,'max'=>1440],
                    'comment_rate_count' => ['label'=>'حداکثر تعداد نظر در بازه','type'=>'number','default'=>3,'min'=>1,'max'=>30],
                    'comment_rate_minutes' => ['label'=>'طول بازه ضداسپم به دقیقه','type'=>'number','default'=>10,'min'=>1,'max'=>1440],
                    'comment_title_fa' => ['label'=>'عنوان بخش نظرات','type'=>'text','default'=>'نظرات کاربران'],
                    'comment_placeholder_fa' => ['label'=>'متن داخل کادر نظر','type'=>'text','default'=>'دیدگاهت را درباره این عنوان بنویس...'],
                    'comment_submit_label_fa' => ['label'=>'عنوان دکمه ثبت نظر','type'=>'text','default'=>'ثبت دیدگاه'],
                    'comment_pending_message_fa' => ['label'=>'پیام بعد از ارسال برای بررسی','type'=>'textarea','default'=>'دیدگاه شما ثبت شد و پس از بررسی مدیریت نمایش داده می‌شود.'],
                    'comment_disabled_message_fa' => ['label'=>'پیام زمان غیرفعال بودن نظرات','type'=>'textarea','default'=>'بخش دیدگاه‌ها موقتاً غیرفعال است.'],
                    'comment_empty_message_fa' => ['label'=>'متن نبودن نظر','type'=>'text','default'=>'هنوز دیدگاهی ثبت نشده؛ اولین نفر باش.'],
                ],
            ],
            'support' => [
                'label' => 'حمایت مالی و پشتیبانی پروژه',
                'fields' => [
                    'support_enabled' => ['label'=>'فعال بودن حمایت مالی','type'=>'checkbox','default'=>true],
                    'support_show_home' => ['label'=>'نمایش در صفحه اصلی','type'=>'checkbox','default'=>true],
                    'support_show_movie' => ['label'=>'نمایش در صفحه فیلم','type'=>'checkbox','default'=>true],
                    'support_show_profile' => ['label'=>'نمایش در پروفایل','type'=>'checkbox','default'=>true],
                    'support_show_collection' => ['label'=>'نمایش در کالکشن‌ها','type'=>'checkbox','default'=>true],
                    'support_show_catalog' => ['label'=>'نمایش در آرشیوها و کاتالوگ','type'=>'checkbox','default'=>true],
                    'support_show_next_to_ads' => ['label'=>'نمایش کنار تبلیغات','type'=>'checkbox','default'=>true],
                    'support_show_between_downloads' => ['label'=>'نمایش دقیق بین گروه‌های لینک دانلود','type'=>'checkbox','default'=>true],
                    'support_single_instance' => ['label'=>'فقط یک کارت حمایت در هر صفحه','type'=>'checkbox','default'=>true,'help'=>'از تکرار کارت حمایت در آرشیو ۲ و صفحه فیلم جلوگیری می‌کند.'],
                    'support_movie_next_to_ads' => ['label'=>'نمایش کارت حمایت کنار تبلیغ صفحه فیلم','type'=>'checkbox','default'=>false,'help'=>'وقتی کارت بین لینک‌های دانلود فعال است، خاموش بماند تا تکراری نشود.'],
                    'support_before_footer' => ['label'=>'قرارگیری کارت حمایت قبل از فوتر','type'=>'checkbox','default'=>true],
                    'support_open_new_tab' => ['label'=>'بازشدن لینک در تب جدید','type'=>'checkbox','default'=>true],
                    'support_title_fa' => ['label'=>'عنوان فارسی کارت','type'=>'text','default'=>'همراه بانک مووی باش'],
                    'support_title_en' => ['label'=>'عنوان انگلیسی کارت','type'=>'text','default'=>'Keep BankMovie Going'],
                    'support_description_fa' => ['label'=>'توضیح فارسی','type'=>'textarea','default'=>'حمایت تو کمک می‌کند هزینه سرور و توسعه سبک‌تر شود و آرشیو بانک مووی همیشه به‌روز بماند.'],
                    'support_description_en' => ['label'=>'توضیح انگلیسی','type'=>'textarea','default'=>'Your support helps cover server costs and keeps the archive updated.'],
                    'support_button_fa' => ['label'=>'متن دکمه فارسی','type'=>'text','default'=>'حمایت از ادامه مسیر'],
                    'support_button_en' => ['label'=>'متن دکمه انگلیسی','type'=>'text','default'=>'Support the Project'],
                    'support_url' => ['label'=>'لینک پرداخت یا حمایت','type'=>'url','default'=>'https://daramet.com/manuel'],
                    'support_accent_color' => ['label'=>'رنگ کارت حمایت','type'=>'color','default'=>'#8224e3'],
                ],
            ],
            'advertising' => [
                'label' => 'بنرها، تبلیغات داخلی و یکتانت',
                'fields' => [
                    'ads_internal_enabled' => ['label'=>'فعال بودن بنرهای داخلی','type'=>'checkbox','default'=>true],
                    'ads_yektanet_enabled' => ['label'=>'فعال بودن تبلیغات یکتانت','type'=>'checkbox','default'=>true],
                    'ads_desktop_enabled' => ['label'=>'نمایش تبلیغ در ویندوز و دسکتاپ','type'=>'checkbox','default'=>true],
                    'ads_mobile_enabled' => ['label'=>'نمایش تبلیغ در موبایل','type'=>'checkbox','default'=>true],
                    'ads_floating_enabled' => ['label'=>'فعال بودن تبلیغ شناور','type'=>'checkbox','default'=>true],
                    'ads_global_banner_enabled' => ['label'=>'فعال بودن بنر سراسری','type'=>'checkbox','default'=>true],
                    'ads_home_top_enabled' => ['label'=>'تبلیغ بالای صفحه اصلی','type'=>'checkbox','default'=>true],
                    'ads_home_middle_enabled' => ['label'=>'تبلیغ میانه صفحه اصلی','type'=>'checkbox','default'=>true],
                    'ads_home_bottom_enabled' => ['label'=>'تبلیغ پایین صفحه اصلی','type'=>'checkbox','default'=>true],
                    'ads_movie_page_enabled' => ['label'=>'تبلیغ صفحه فیلم','type'=>'checkbox','default'=>true],
                    'ads_label_fa' => ['label'=>'عنوان نمایش روی تبلیغ','type'=>'text','default'=>'تبلیغات'],
                    'ads_close_label_fa' => ['label'=>'متن بستن تبلیغ','type'=>'text','default'=>'بستن تبلیغ'],
                ],
            ],
            'promotion' => [
                'label' => 'بنر اطلاع‌رسانی و کمپین',
                'fields' => [
                    'promo_banner_enabled' => ['label'=>'فعال بودن بنر کمپین','type'=>'checkbox','default'=>true],
                    'promo_dismissible' => ['label'=>'امکان بستن توسط کاربر','type'=>'checkbox','default'=>true],
                    'promo_open_new_tab' => ['label'=>'بازشدن دکمه در تب جدید','type'=>'checkbox','default'=>true],
                    'promo_title_fa' => ['label'=>'عنوان بنر','type'=>'text','default'=>''],
                    'promo_text_fa' => ['label'=>'متن بنر','type'=>'textarea','default'=>''],
                    'promo_button_label_fa' => ['label'=>'متن دکمه','type'=>'text','default'=>'مشاهده'],
                    'promo_button_url' => ['label'=>'لینک دکمه','type'=>'url','default'=>''],
                    'promo_image_path' => ['label'=>'مسیر تصویر یا آیکن بنر','type'=>'text','default'=>'','help'=>'نمونه: /assets/brand/bankmovie-icon.png'],
                    'promo_accent_color' => ['label'=>'رنگ اصلی بنر','type'=>'color','default'=>'#2f7cff'],
                ],
            ],
            'profile_auth' => [
                'label' => 'ورود، ثبت‌نام و صفحه پروفایل',
                'fields' => [
                    'login_page_enabled' => ['label'=>'فعال بودن صفحه ورود','type'=>'checkbox','default'=>true],
                    'register_page_enabled' => ['label'=>'فعال بودن ثبت‌نام','type'=>'checkbox','default'=>true],
                    'profile_watchlist_enabled' => ['label'=>'نمایش علاقه‌مندی‌ها در پروفایل','type'=>'checkbox','default'=>true],
                    'profile_history_enabled' => ['label'=>'نمایش تاریخچه تماشا','type'=>'checkbox','default'=>true],
                    'profile_comments_enabled' => ['label'=>'نمایش نظرات و پاسخ‌ها','type'=>'checkbox','default'=>true],
                    'profile_notifications_enabled' => ['label'=>'نمایش اعلان‌ها در پروفایل','type'=>'checkbox','default'=>true],
                    'login_title_fa' => ['label'=>'عنوان صفحه ورود','type'=>'text','default'=>'ورود به بانک مووی'],
                    'register_title_fa' => ['label'=>'عنوان صفحه ثبت‌نام','type'=>'text','default'=>'ساخت حساب بانک مووی'],
                    'profile_empty_watchlist_fa' => ['label'=>'متن خالی علاقه‌مندی‌ها','type'=>'text','default'=>'هنوز عنوانی به علاقه‌مندی‌ها اضافه نکرده‌ای.'],
                    'profile_empty_history_fa' => ['label'=>'متن خالی تاریخچه','type'=>'text','default'=>'هنوز چیزی تماشا نکرده‌ای.'],
                ],
            ],
            'watch_party' => [
                'label' => 'Watch Party آزمایشی و VIP',
                'fields' => [
                    'watch_party_enabled' => ['label'=>'فعال‌سازی اصلی Watch Party','type'=>'checkbox','default'=>false,'help'=>'فعلاً خاموش بماند؛ هیچ دکمه‌ای در سایت عمومی نمایش داده نمی‌شود.'],
                    'watch_party_admin_preview_enabled' => ['label'=>'آزمایش مخفی مدیر و VIPهای دعوت‌شده','type'=>'checkbox','default'=>false,'help'=>'برای تست داخلی؛ فقط مدیر و کاربران VIP دارای لینک دعوت دسترسی دارند و کاربران عادی همچنان 404 می‌گیرند.'],
                    'watch_party_public_visible' => ['label'=>'نمایش عمومی دکمه Watch Party','type'=>'checkbox','default'=>false,'help'=>'این نسخه عمداً هیچ دکمه عمومی ندارد و این گزینه برای فاز بعد رزرو شده است.'],
                    'watch_party_chat_enabled' => ['label'=>'فعال بودن گفت‌وگوی موقت داخل اتاق','type'=>'checkbox','default'=>true],
                    'watch_party_room_hours' => ['label'=>'حداکثر عمر اتاق به ساعت','type'=>'number','default'=>4,'min'=>1,'max'=>4,'help'=>'سقف امنیتی در کد ۴ ساعت است و تمدید نمی‌شود.'],
                    'watch_party_max_members' => ['label'=>'حداکثر اعضای اتاق','type'=>'number','default'=>2,'min'=>2,'max'=>2,'help'=>'نسخه اول فقط تماشای دونفره است.'],
                    'watch_party_message_limit' => ['label'=>'حداکثر پیام موقت هر اتاق','type'=>'number','default'=>500,'min'=>50,'max'=>500],
                    'watch_party_cleanup_interval_minutes' => ['label'=>'فاصله پاکسازی خودکار به دقیقه','type'=>'number','default'=>1,'min'=>1,'max'=>5],
                ],
            ],
            'advanced' => [
                'label' => 'تنظیمات پیشرفته امن',
                'fields' => [
                    'custom_css_enabled' => ['label'=>'فعال کردن CSS سفارشی','type'=>'checkbox','default'=>true],
                    'custom_css' => ['label'=>'CSS سفارشی','type'=>'textarea','default'=>'','help'=>'فقط CSS؛ تگ style یا کد JavaScript وارد نکن.'],
                ],
            ],
        ];
    }
}

if (!function_exists('bm_site_font_catalog')) {
    function bm_site_font_catalog(): array
    {
        return [
            'bonvf' => [
                'label' => 'Bon VF',
                'family' => 'BMSiteBonVF',
                'preload' => '/assets/fonts/bonVF.woff2',
                'preload_type' => 'font/woff2',
                'faces' => [
                    ['src'=>'/assets/fonts/bonVF.woff2','format'=>'woff2','weight'=>'100 900'],
                ],
            ],
            'yekanbakh' => [
                'label' => 'Yekan Bakh VF',
                'family' => 'BMSiteYekanBakh',
                'preload' => '/assets/fonts/yekan-bakh-vf.woff2',
                'preload_type' => 'font/woff2',
                'faces' => [
                    ['src'=>'/assets/fonts/yekan-bakh-vf.woff2','format'=>'woff2','weight'=>'100 950'],
                ],
            ],
            'filimo' => [
                'label' => 'Filimo Demo Variable',
                'family' => 'BMSiteFilimo',
                'preload' => '/assets/fonts/filimo-demo-variable-vf.woff2',
                'preload_type' => 'font/woff2',
                'faces' => [
                    ['src'=>'/assets/fonts/filimo-demo-variable-vf.woff2','format'=>'woff2','weight'=>'100 950'],
                ],
            ],
            'iransans_fanum' => [
                'label' => 'IRANSans FaNum',
                'family' => 'BMSiteIRANSansFaNum',
                'preload' => '/assets/fonts/iran-sans-fanum-regular.woff',
                'preload_type' => 'font/woff',
                'faces' => [
                    ['src'=>'/assets/fonts/iran-sans-fanum-light.woff','format'=>'woff','weight'=>'300'],
                    ['src'=>'/assets/fonts/iran-sans-fanum-regular.woff','format'=>'woff','weight'=>'400'],
                    ['src'=>'/assets/fonts/iran-sans-fanum-medium.woff','format'=>'woff','weight'=>'500'],
                    ['src'=>'/assets/fonts/iran-sans-fanum-bold.woff','format'=>'woff','weight'=>'700 950'],
                ],
            ],
            'iranyekan' => [
                'label' => 'IRANYekan Web',
                'family' => 'BMSiteIRANYekanWeb',
                'preload' => '/assets/fonts/iran-yekan-web-regular.woff',
                'preload_type' => 'font/woff',
                'faces' => [
                    ['src'=>'/assets/fonts/iran-yekan-web-regular.woff','format'=>'woff','weight'=>'300 400'],
                    ['src'=>'/assets/fonts/iran-yekan-web-medium.woff','format'=>'woff','weight'=>'500 950'],
                ],
            ],
            'iranyekanx_fanum' => [
                'label' => 'IRANYekanX FaNum',
                'family' => 'BMSiteIRANYekanXFaNum',
                'preload' => '/assets/fonts/iran-yekan-x-fanum-medium.woff2',
                'preload_type' => 'font/woff2',
                'faces' => [
                    ['src'=>'/assets/fonts/iran-yekan-x-fanum-medium.woff2','format'=>'woff2','weight'=>'300 600'],
                    ['src'=>'/assets/fonts/iran-yekan-x-fanum-bold.woff2','format'=>'woff2','weight'=>'700 950'],
                ],
            ],
            'brioso' => [
                'label' => 'Brioso W04 Light Cp',
                'family' => 'BMSiteBrioso',
                'preload' => '/assets/fonts/brioso-w04-light-cp.ttf',
                'preload_type' => 'font/ttf',
                'faces' => [
                    ['src'=>'/assets/fonts/brioso-w04-light-cp.ttf','format'=>'truetype','weight'=>'100 950'],
                ],
            ],
            'system' => [
                'label' => 'System UI',
                'family' => '',
                'preload' => '',
                'preload_type' => '',
                'faces' => [],
            ],
        ];
    }
}
if (!function_exists('bm_site_active_font')) {
    function bm_site_active_font(): array
    {
        $catalog = bm_site_font_catalog();
        $id = strtolower(trim((string)bm_site_get('site_font_family', 'bonvf')));
        if (!isset($catalog[$id])) $id = 'bonvf';
        $font = $catalog[$id];
        $font['id'] = $id;
        return $font;
    }
}
if (!function_exists('bm_site_font_faces_css')) {
    function bm_site_font_faces_css(array $font): string
    {
        $family = trim((string)($font['family'] ?? ''));
        if ($family === '') return '';
        $css = [];
        foreach ((array)($font['faces'] ?? []) as $face) {
            $src = (string)($face['src'] ?? '');
            $format = (string)($face['format'] ?? 'woff2');
            $weight = (string)($face['weight'] ?? '400');
            if ($src === '') continue;
            $css[] = "@font-face{font-family:'{$family}';src:url('{$src}') format('{$format}');font-style:normal;font-weight:{$weight};font-display:swap}";
        }
        return implode("\n", $css);
    }
}
if (!function_exists('bm_site_all_font_faces_css')) {
    function bm_site_all_font_faces_css(): string
    {
        $parts = [];
        foreach (bm_site_font_catalog() as $font) {
            $css = bm_site_font_faces_css($font);
            if ($css !== '') $parts[] = $css;
        }
        return implode("\n", $parts);
    }
}
if (!function_exists('bm_site_font_stack_by_id')) {
    function bm_site_font_stack_by_id(string $id): string
    {
        $catalog = bm_site_font_catalog();
        if (!isset($catalog[$id])) $id = 'bonvf';
        $family = trim((string)($catalog[$id]['family'] ?? ''));
        return $family !== '' ? "'{$family}',Tahoma,Arial,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif" : "Tahoma,Arial,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
    }
}
if (!function_exists('bm_site_typography_css')) {
    function bm_site_typography_css(): string
    {
        $map = [
            'base'=>'site_font_family','header'=>'font_header_family','hero'=>'font_hero_family','heading'=>'font_heading_family',
            'body'=>'font_body_family','card'=>'font_card_family','button'=>'font_button_family','form'=>'font_form_family',
            'footer'=>'font_footer_family','mobile'=>'font_mobile_nav_family','meta'=>'font_movie_meta_family',
        ];
        $catalog = bm_site_font_catalog();
        $selected = [];
        $vars = [];
        foreach ($map as $var=>$setting) {
            $id = strtolower(trim((string)bm_site_get($setting, (string)bm_site_get('site_font_family','bonvf'))));
            if (!isset($catalog[$id])) $id = 'bonvf';
            $selected[$id] = $catalog[$id];
            $vars[] = "--bm-font-{$var}:".bm_site_font_stack_by_id($id);
        }
        $faces = [];
        foreach ($selected as $font) { $css = bm_site_font_faces_css($font); if ($css !== '') $faces[] = $css; }
        $bodySize = max(11,min(22,(int)bm_site_get('font_body_size',14)));
        $headerSize = max(10,min(20,(int)bm_site_get('font_header_size',13)));
        $headingScale = max(75,min(145,(int)bm_site_get('font_heading_scale',100)));
        $cardSize = max(10,min(24,(int)bm_site_get('font_card_title_size',14)));
        $buttonSize = max(10,min(20,(int)bm_site_get('font_button_size',13)));
        $footerSize = max(9,min(18,(int)bm_site_get('font_footer_size',12)));
        $mobileSize = max(8,min(15,(int)bm_site_get('font_mobile_nav_size',10)));
        $vars[]="--bm-font-body-size:{$bodySize}px";$vars[]="--bm-font-header-size:{$headerSize}px";$vars[]="--bm-font-heading-scale:".($headingScale/100);
        $vars[]="--bm-font-card-size:{$cardSize}px";$vars[]="--bm-font-button-size:{$buttonSize}px";$vars[]="--bm-font-footer-size:{$footerSize}px";$vars[]="--bm-font-mobile-size:{$mobileSize}px";
        $css = implode("
",$faces)."
:root{".implode(';',$vars)."}";
        $css .= "
html,body{font-family:var(--bm-font-body)!important;font-size:var(--bm-font-body-size)}";
        $css .= "
#siteHeader,#siteHeader a,#siteHeader button,.desktop-nav,.sidebar-nav{font-family:var(--bm-font-header)!important;font-size:var(--bm-font-header-size)}";
        $css .= "
.hero,.hero-slider,.slider,.hero-title,.movie-hero,.bm-category-intro{font-family:var(--bm-font-hero)!important}";
        $css .= "
h1,h2,h3,h4,h5,h6,.section-title{font-family:var(--bm-font-heading)!important}";
        $css .= "
h1{font-size:calc(2em * var(--bm-font-heading-scale))}h2{font-size:calc(1.5em * var(--bm-font-heading-scale))}h3{font-size:calc(1.17em * var(--bm-font-heading-scale))}";
        $css .= "
.movie-card,.scroll-card,.grid-item,.collection-card,.bm-genre-card,.card-title,.movie-title{font-family:var(--bm-font-card)!important}.movie-card .title,.scroll-card .title,.grid-item .title,.movie-title{font-size:var(--bm-font-card-size)!important}";
        $css .= "
button,.btn,[class*=\"-btn\"],.button{font-family:var(--bm-font-button)!important;font-size:var(--bm-font-button-size)}";
        $css .= "
input,select,textarea,label,.search-input{font-family:var(--bm-font-form)!important}";
        $css .= "
footer,.site-footer,.bm-site-footer{font-family:var(--bm-font-footer)!important;font-size:var(--bm-font-footer-size)}";
        $css .= "
.bottom-nav,.actor-bottom-nav,[data-mobile-bottom-nav]{font-family:var(--bm-font-mobile)!important}.bottom-nav .nav-label,[data-mobile-bottom-nav] .nav-label{font-size:var(--bm-font-mobile-size)!important}";
        $css .= "
.movie-meta,.movie-info,.metadata,.download-section,.arc1-series-downloads{font-family:var(--bm-font-meta)!important}";
        return $css;
    }
}
if (!function_exists('bm_site_typography_preload')) {
    function bm_site_typography_preload(): array
    {
        $font = bm_site_active_font();
        return [
            'href' => (string)($font['preload'] ?? ''),
            'type' => (string)($font['preload_type'] ?? ''),
        ];
    }
}
if (!function_exists('bm_site_typography_head_markup')) {
    function bm_site_typography_head_markup(bool $includePreload = true): string
    {
        $parts = [];
        $preload = bm_site_typography_preload();
        if ($includePreload && $preload['href'] !== '') {
            $href = htmlspecialchars($preload['href'], ENT_QUOTES, 'UTF-8');
            $type = htmlspecialchars($preload['type'], ENT_QUOTES, 'UTF-8');
            $parts[] = '<link rel="preload" href="'.$href.'" as="font" type="'.$type.'" crossorigin>';
        }
        $parts[] = '<style id="bm-site-typography-runtime">'.bm_site_typography_css().'</style>';
        return implode("\n", $parts);
    }
}

if (!function_exists('bm_site_setting_defaults')) {
    function bm_site_setting_defaults(): array
    {
        $out = [];
        foreach (bm_site_setting_schema() as $group) {
            foreach (($group['fields'] ?? []) as $key => $field) {
                $out[$key] = $field['default'] ?? '';
            }
        }
        $out['__settings_version'] = 12;
        return $out;
    }
}
if (!function_exists('bm_site_checkbox_keys')) {
    function bm_site_checkbox_keys(?string $groupId = null): array
    {
        $keys = [];
        foreach (bm_site_setting_schema() as $id => $group) {
            if ($groupId !== null && $id !== $groupId) {
                continue;
            }
            foreach (($group['fields'] ?? []) as $key => $field) {
                if (($field['type'] ?? 'text') === 'checkbox') {
                    $keys[] = $key;
                }
            }
        }
        return $keys;
    }
}
if (!function_exists('bm_site_settings_path')) {
    function bm_site_settings_path(): string
    {
        return function_exists('bm_security_private_path')
            ? bm_security_private_path('site-content-settings.json')
            : dirname(__DIR__) . '/bankmovie_site_content.json';
    }
}
if (!function_exists('bm_site_write_settings_file')) {
    function bm_site_write_settings_file(array $data): bool
    {
        $path = bm_site_settings_path();
        $dir = dirname($path);
        if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
            return false;
        }

        $data['__settings_version'] = 12;
        $json = json_encode(
            $data,
            JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
        );
        if (!is_string($json)) {
            return false;
        }

        try {
            $suffix = bin2hex(random_bytes(4));
        } catch (Throwable $e) {
            $suffix = str_replace('.', '', uniqid('', true));
        }
        $tmp = $path . '.tmp.' . getmypid() . '.' . $suffix;
        if (@file_put_contents($tmp, $json . PHP_EOL, LOCK_EX) === false) {
            return false;
        }
        @chmod($tmp, 0640);
        if (!@rename($tmp, $path)) {
            @unlink($tmp);
            return false;
        }
        return true;
    }
}
if (!function_exists('bm_site_settings')) {
    function bm_site_settings(bool $refresh = false): array
    {
        static $cache = null;
        if (!$refresh && is_array($cache)) {
            return $cache;
        }

        $stored = [];
        $path = bm_site_settings_path();
        if (is_file($path)) {
            $raw = @file_get_contents($path);
            $decoded = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($decoded)) {
                $stored = $decoded;
            }
        }

        $settings = array_replace(bm_site_setting_defaults(), $stored);
        $storedVersion = (int)($stored['__settings_version'] ?? 0);

        // V102 saved only the currently visible tab and silently turned every
        // checkbox from other tabs off. On the first V103 load, restore every
        // feature switch to ON exactly once. Future intentional changes remain.
        if ($storedVersion < 2) {
            foreach (bm_site_checkbox_keys() as $key) {
                $settings[$key] = true;
            }
            $settings['__settings_version'] = 2;
            bm_site_write_settings_file($settings);
        }

        // V111 adds operational controls. Existing installations keep every new
        // switch enabled by default without overwriting previously saved texts.
        if ($storedVersion < 3) {
            foreach (bm_site_checkbox_keys() as $key) {
                if (!array_key_exists($key, $stored)) {
                    $settings[$key] = true;
                }
            }
            $settings['__settings_version'] = 3;
            bm_site_write_settings_file($settings);
        }

        // V144 adds a safe, whitelisted font selector. Existing sites keep BonVF.
        if ($storedVersion < 4) {
            if (!array_key_exists('site_font_family', $stored)) {
                $settings['site_font_family'] = 'bonvf';
            }
            $settings['__settings_version'] = 4;
            bm_site_write_settings_file($settings);
        }

        // V146 adds the real category catalogue and advanced-search switches.
        // Only newly introduced switches are enabled; prior admin choices remain untouched.
        if ($storedVersion < 5) {
            $newCheckboxes = [
                'page_categories_enabled','categories_show_archive1','categories_show_archive2',
                'categories_show_archive3','categories_show_counts','categories_show_images',
                'categories_inline_search_enabled','advanced_search_enabled',
                'search_archive1_enabled','search_archive2_enabled','search_archive3_enabled',
                'search_show_actor_director','search_show_country','search_show_suggested_filter',
            ];
            foreach ($newCheckboxes as $key) {
                if (!array_key_exists($key, $stored)) $settings[$key] = true;
            }
            if (!array_key_exists('categories_default_archive', $stored)) $settings['categories_default_archive'] = '2';
            $settings['__settings_version'] = 5;
            bm_site_write_settings_file($settings);
        }

        // V148 adds section-level typography, the centered categories nav item and donation placement between download groups.
        if ($storedVersion < 6) {
            foreach (['mobile_nav_show_categories','support_show_between_downloads'] as $key) {
                if (!array_key_exists($key, $stored)) $settings[$key] = true;
            }
            $settings['__settings_version'] = 6;
            bm_site_write_settings_file($settings);
        }

        // V148.12 adds the centralized SEO manager. New switches are enabled without changing prior settings.
        if ($storedVersion < 9) {
            foreach (['seo_enabled','seo_open_graph_enabled','seo_twitter_cards_enabled','seo_jsonld_enabled','seo_dynamic_sitemap_enabled','seo_sitemap_auto_sync_enabled'] as $key) {
                if (!array_key_exists($key, $stored)) $settings[$key] = true;
            }
            $settings['__settings_version'] = 9;
            bm_site_write_settings_file($settings);
        }

        // V148.13 adds WordPress-style automatic live sitemap registration.
        if ($storedVersion < 10) {
            if (!array_key_exists('seo_sitemap_auto_sync_enabled', $stored)) $settings['seo_sitemap_auto_sync_enabled'] = true;
            $settings['__settings_version'] = 10;
            bm_site_write_settings_file($settings);
        }

        // V148.14 introduces the hidden VIP Watch Party foundation. Sensitive
        // switches are deliberately opt-in and remain OFF after migration.
        if ($storedVersion < 11) {
            foreach (['watch_party_enabled','watch_party_admin_preview_enabled','watch_party_public_visible'] as $key) {
                if (!array_key_exists($key, $stored)) $settings[$key] = false;
            }
            if (!array_key_exists('watch_party_chat_enabled', $stored)) $settings['watch_party_chat_enabled'] = true;
            if (!array_key_exists('watch_party_room_hours', $stored)) $settings['watch_party_room_hours'] = 4;
            if (!array_key_exists('watch_party_max_members', $stored)) $settings['watch_party_max_members'] = 2;
            if (!array_key_exists('watch_party_message_limit', $stored)) $settings['watch_party_message_limit'] = 500;
            if (!array_key_exists('watch_party_cleanup_interval_minutes', $stored)) $settings['watch_party_cleanup_interval_minutes'] = 1;
            $settings['__settings_version'] = 11;
            bm_site_write_settings_file($settings);
        }


        // V148.43 adds centralized loading controls and restores the exact Uiverse checkbox defaults.
        if ($storedVersion < 12) {
            foreach ([
                'loading_enabled','loading_show_logo','loading_show_text','loading_use_theme_accent',
                'loading_home_enabled','loading_movie_enabled','loading_search_enabled',
                'loading_archives_enabled','loading_player_enabled','loading_collections_enabled',
                'loading_profile_enabled','loading_skeleton_enabled'
            ] as $key) {
                if (!array_key_exists($key, $stored)) $settings[$key] = true;
            }
            if (!array_key_exists('loading_other_pages_enabled', $stored)) $settings['loading_other_pages_enabled'] = false;
            if (!array_key_exists('ui_neon_checkbox_dark_color', $stored)) $settings['ui_neon_checkbox_dark_color'] = '#00cc88';
            if (!array_key_exists('ui_neon_checkbox_light_color', $stored)) $settings['ui_neon_checkbox_light_color'] = '#88ffdd';
            if (!array_key_exists('ui_neon_checkbox_size', $stored) || (int)$stored['ui_neon_checkbox_size'] === 24) {
                $settings['ui_neon_checkbox_size'] = 30;
            }
            $settings['__settings_version'] = 12;
            bm_site_write_settings_file($settings);
        }

        return $cache = $settings;
    }
}
if (!function_exists('bm_site_get')) {
    function bm_site_get(string $key, $fallback = null)
    {
        $settings = bm_site_settings();
        return array_key_exists($key, $settings) ? $settings[$key] : $fallback;
    }
}
if (!function_exists('bm_site_bool')) {
    function bm_site_bool(string $key, bool $fallback = false): bool
    {
        $value = bm_site_get($key, $fallback);
        return is_bool($value)
            ? $value
            : in_array(strtolower(trim((string)$value)), ['1', 'true', 'yes', 'on'], true);
    }
}
if (!function_exists('bm_site_h')) {
    function bm_site_h($value): string
    {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    }
}
if (!function_exists('bm_site_cut')) {
    function bm_site_cut(string $value, int $length): string
    {
        return function_exists('mb_substr')
            ? mb_substr($value, 0, $length, 'UTF-8')
            : substr($value, 0, $length);
    }
}
if (!function_exists('bm_site_sanitize_value')) {
    function bm_site_sanitize_value(string $key, array $field, $raw)
    {
        $type = (string)($field['type'] ?? 'text');
        $default = $field['default'] ?? '';

        if ($type === 'checkbox') {
            return !empty($raw);
        }

        $value = trim((string)$raw);
        if ($type === 'url') {
            if ($value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) {
                return (string)$default;
            }
            return $value;
        }
        if ($type === 'color') {
            return preg_match('/^#[0-9a-fA-F]{6}$/', $value) ? $value : (string)$default;
        }
        if ($type === 'number') {
            $number = is_numeric($value) ? (int)$value : (int)$default;
            $min = isset($field['min']) ? (int)$field['min'] : PHP_INT_MIN;
            $max = isset($field['max']) ? (int)$field['max'] : PHP_INT_MAX;
            return max($min, min($max, $number));
        }
        if ($type === 'select') {
            $options = array_keys((array)($field['options'] ?? []));
            return in_array($value, $options, true) ? $value : (string)$default;
        }
        if ($type === 'footer_links') {
            return bm_site_sanitize_footer_links_json($raw);
        }
        if ($key === 'custom_css') {
            $value = str_ireplace(['</style', '<script', 'javascript:'], '', $value);
            return bm_site_cut($value, 30000);
        }

        $value = strip_tags($value);
        return bm_site_cut($value, $type === 'textarea' ? 5000 : 500);
    }
}
if (!function_exists('bm_site_sanitize_group_settings')) {
    function bm_site_sanitize_group_settings(string $groupId, array $input): ?array
    {
        $schema = bm_site_setting_schema();
        if (!isset($schema[$groupId])) {
            return null;
        }

        $patch = [];
        foreach (($schema[$groupId]['fields'] ?? []) as $key => $field) {
            $type = (string)($field['type'] ?? 'text');
            if ($type === 'checkbox') {
                // Every checkbox in the visible group is present conceptually;
                // unchecked means false only for this group, never for other tabs.
                $patch[$key] = !empty($input[$key]);
                continue;
            }
            if (!array_key_exists($key, $input)) {
                continue;
            }
            $patch[$key] = bm_site_sanitize_value($key, $field, $input[$key]);
        }
        return $patch;
    }
}
if (!function_exists('bm_site_save_group_settings')) {
    function bm_site_save_group_settings(string $groupId, array $input): bool
    {
        $patch = bm_site_sanitize_group_settings($groupId, $input);
        if (!is_array($patch)) {
            return false;
        }

        $current = bm_site_settings();
        $next = array_replace($current, $patch);
        $next['__settings_version'] = 12;
        if (!bm_site_write_settings_file($next)) {
            return false;
        }
        bm_site_settings(true);
        return true;
    }
}
if (!function_exists('bm_site_save_settings')) {
    function bm_site_save_settings(array $input): bool
    {
        $groupId = preg_replace('/[^a-z0-9_]/i', '', (string)($input['settings_group'] ?? ''));
        if ($groupId !== '') {
            return bm_site_save_group_settings($groupId, $input);
        }

        // Compatibility path: merge only submitted keys and preserve everything else.
        $schema = bm_site_setting_schema();
        $next = bm_site_settings();
        foreach ($schema as $group) {
            foreach (($group['fields'] ?? []) as $key => $field) {
                if (!array_key_exists($key, $input)) {
                    continue;
                }
                $next[$key] = bm_site_sanitize_value($key, $field, $input[$key]);
            }
        }
        $next['__settings_version'] = 12;
        if (!bm_site_write_settings_file($next)) {
            return false;
        }
        bm_site_settings(true);
        return true;
    }
}
if (!function_exists('bm_site_enable_all_features')) {
    function bm_site_enable_all_features(): bool
    {
        $next = bm_site_settings();
        $sensitiveOptIn = ['app_bottom_nav_banner_enabled','watch_party_enabled','watch_party_admin_preview_enabled','watch_party_public_visible'];
        foreach (bm_site_checkbox_keys() as $key) {
            if (in_array($key, $sensitiveOptIn, true)) continue;
            $next[$key] = true;
        }
        foreach ($sensitiveOptIn as $key) $next[$key] = false;
        $next['__settings_version'] = 12;
        if (!bm_site_write_settings_file($next)) {
            return false;
        }
        bm_site_settings(true);
        return true;
    }
}
if (!function_exists('bm_site_reset_settings')) {
    function bm_site_reset_settings(): bool
    {
        $defaults = bm_site_setting_defaults();
        foreach (bm_site_checkbox_keys() as $key) {
            $defaults[$key] = true;
        }
        // Sensitive features must remain opt-in, even after reset.
        $defaults['app_bottom_nav_banner_enabled'] = false;
        $defaults['watch_party_enabled'] = false;
        $defaults['watch_party_admin_preview_enabled'] = false;
        $defaults['watch_party_public_visible'] = false;
        $defaults['watch_party_chat_enabled'] = true;
        $defaults['__settings_version'] = 12;
        if (!bm_site_write_settings_file($defaults)) {
            return false;
        }
        bm_site_settings(true);
        return true;
    }
}
if (!function_exists('bm_site_settings_summary')) {
    function bm_site_settings_summary(): array
    {
        $settings = bm_site_settings();
        $checkboxes = bm_site_checkbox_keys();
        $enabled = 0;
        foreach ($checkboxes as $key) {
            if (!empty($settings[$key])) {
                $enabled++;
            }
        }
        return [
            'enabled' => $enabled,
            'total' => count($checkboxes),
            'disabled' => count($checkboxes) - $enabled,
            'saved_at' => is_file(bm_site_settings_path()) ? (int)@filemtime(bm_site_settings_path()) : 0,
        ];
    }
}
if (!function_exists('bm_site_visibility_css')) {
    function bm_site_visibility_css(): string
    {
        $rules = [];
        if (!bm_site_bool('header_enabled', true)) $rules[] = '#siteHeader{display:none!important}';
        if (!bm_site_bool('mobile_nav_enabled', true)) $rules[] = '.bottom-nav,.actor-bottom-nav,[data-mobile-bottom-nav]{display:none!important}';
        if (!bm_site_bool('footer_enabled', true)) $rules[] = '.bm-global-footer{display:none!important}';
        if (!bm_site_bool('app_bottom_nav_banner_enabled', false)) {
            $rules[] = '.bm-app-mini-banner,#bmAppMiniBanner{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important}';
            $rules[] = '@media(max-width:991px){body.has-bm-app-mini-banner{padding-bottom:104px!important}}';
        }
        if (!bm_site_bool('comments_enabled', true)) $rules[] = '.comments-section,#comments-section,[data-comments-section]{display:none!important}';
        if (!bm_site_bool('profile_watchlist_enabled', true)) $rules[] = '#watchlist-section,[data-section="watchlist-section"],[data-overview-target="watchlist-section"]{display:none!important}';
        if (!bm_site_bool('profile_comments_enabled', true)) $rules[] = '#comments-section,[data-section="comments-section"],[data-overview-target="comments-section"]{display:none!important}';
        if (!bm_site_bool('profile_notifications_enabled', true)) $rules[] = '.profile-notifications,[data-profile-notifications]{display:none!important}';

        $map = [
            'home_show_slider' => '.hero-slider',
            'home_show_stories' => '.stories-section',
            'home_show_genres' => '.genres-section',
            'home_show_countries' => '.countries-section',
            'home_show_collections' => '.collections-section',
            'home_show_admin_picks' => '.admin-picks-section',
            'home_show_top_movies' => '.top-movies-section',
            'home_show_top_series' => '.top-series-section',
            'home_show_user_rated' => '.user-rated-section',
            'home_show_dubbed' => '.dubbed-section',
            'home_show_suggestions' => '.smart-suggestions-section',
        ];
        foreach ($map as $key => $selector) {
            if (!bm_site_bool($key, true)) $rules[] = $selector . '{display:none!important}';
        }

        $rules[] = '@media (min-width:992px){html body .bottom-nav,html body .actor-bottom-nav,html body [data-mobile-bottom-nav]{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;transform:none!important}}';
        if (bm_site_bool('custom_css_enabled', false)) {
            $custom = trim((string)bm_site_get('custom_css', ''));
            if ($custom !== '') $rules[] = $custom;
        }
        return implode("\n", $rules);
    }
}


if (!function_exists('bm_site_enforce_page')) {
    function bm_site_enforce_page(string $settingKey): void {
        if (bm_site_bool($settingKey, true)) return;
        if (PHP_SAPI === 'cli') return;
        http_response_code(503);
        $message = bm_site_h(bm_site_get('disabled_page_message_fa','این بخش موقتاً از دسترس خارج شده است.'));
        echo '<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>بخش غیرفعال | BankMovie</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#05050a;color:#fff;font-family:Tahoma,Arial,sans-serif}.box{width:min(520px,calc(100% - 28px));padding:32px;border:1px solid rgba(255,255,255,.1);border-radius:24px;background:#101522;text-align:center}.box a{display:inline-flex;margin-top:18px;padding:11px 18px;border-radius:14px;background:#2f7cff;color:#fff;text-decoration:none;font-weight:800}</style></head><body><main class="box"><h1>این بخش موقتاً غیرفعال است</h1><p>'.$message.'</p><a href="/">بازگشت به خانه</a></main></body></html>';
        exit;
    }
}
