<?php
/**
 * BankMovie DL1 poster redirect v3.3 - stateless 302 only.
 * No proxy. No image fetching. No image cache. No map files.
 * Pretty URL contains an authenticated encrypted source URL in ?sig=.
 */
if (defined('BANKMOVIE_POSTER_REDIRECT_LOADED')) return;
define('BANKMOVIE_POSTER_REDIRECT_LOADED', true);

if (!defined('BANKMOVIE_POSTER_SHARED_KEY_B64')) {
    define('BANKMOVIE_POSTER_SHARED_KEY_B64', 'HxRh1PT9uXpZ9j7Ss1Zv7aDpPOl2ejn80czbvwkSE2k=');
}

if (!function_exists('bm_poster_redirect_enabled')) {
    function bm_poster_redirect_enabled(): bool
    {
        $env = getenv('BANKMOVIE_POSTER_REDIRECT_ENABLED');
        if ($env !== false && trim((string)$env) !== '') {
            $parsed = filter_var($env, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
            if ($parsed === false) return false;
        }
        return true;
    }
}

if (!function_exists('bm_poster_redirect_base')) {
    function bm_poster_redirect_base(): string
    {
        $base = trim((string)(getenv('BANKMOVIE_POSTER_REDIRECT_BASE') ?: 'https://dl1.bankmovie.top'));
        return rtrim($base, '/');
    }
}

if (!function_exists('bm_poster_key')) {
    function bm_poster_key(): string
    {
        $key = base64_decode(BANKMOVIE_POSTER_SHARED_KEY_B64, true);
        return (is_string($key) && strlen($key) === 32) ? $key : '';
    }
}

if (!function_exists('bm_poster_b64u_encode')) {
    function bm_poster_b64u_encode(string $raw): string
    {
        return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
    }
}

if (!function_exists('bm_poster_is_http_url')) {
    function bm_poster_is_http_url(string $url): bool
    {
        if ($url === '' || strlen($url) > 8192 || preg_match('/[\x00-\x1F\x7F]/', $url)) return false;
        $p = @parse_url($url);
        if (!is_array($p)) return false;
        $scheme = strtolower((string)($p['scheme'] ?? ''));
        $host = strtolower(trim((string)($p['host'] ?? '')));
        if (!in_array($scheme, ['http','https'], true) || $host === '') return false;
        if (isset($p['user']) || isset($p['pass'])) return false;
        if ($host === 'localhost' || str_ends_with($host, '.localhost') || str_ends_with($host, '.local') || str_ends_with($host, '.internal')) return false;
        return true;
    }
}

if (!function_exists('bm_poster_is_own_url')) {
    function bm_poster_is_own_url(string $url): bool
    {
        $host = strtolower((string)(parse_url($url, PHP_URL_HOST) ?? ''));
        $baseHost = strtolower((string)(parse_url(bm_poster_redirect_base(), PHP_URL_HOST) ?? ''));
        return $host !== '' && $baseHost !== '' && $host === $baseHost;
    }
}

if (!function_exists('bm_poster_token_encode')) {
    function bm_poster_token_encode(string $url): string
    {
        $key = bm_poster_key();
        if ($key === '' || !function_exists('openssl_encrypt')) return '';
        // Deterministic IV keeps the same poster URL stable across page loads.
        $iv = substr(hash_hmac('sha256', 'iv|' . $url, $key, true), 0, 16);
        $cipher = openssl_encrypt($url, 'aes-256-ctr', $key, OPENSSL_RAW_DATA, $iv);
        if (!is_string($cipher)) return '';
        $tag = substr(hash_hmac('sha256', "tag|" . $iv . $cipher, $key, true), 0, 16);
        return bm_poster_b64u_encode("\x01" . $iv . $tag . $cipher);
    }
}

if (!function_exists('bm_poster_route_chars')) {
    function bm_poster_route_chars(string $bytes, int $offset, int $length): string
    {
        $alphabet = 'abcdefghijklmnopqrstuvwxyz0123456789';
        $out = ''; $n = strlen($bytes);
        if ($n === 0) return str_repeat('x', $length);
        for ($i=0; $i<$length; $i++) $out .= $alphabet[ord($bytes[($offset+$i)%$n]) % strlen($alphabet)];
        return $out;
    }
}

if (!function_exists('bm_poster_route_type')) {
    function bm_poster_route_type(array $context): string
    {
        $signal = strtolower(trim((string)($context['type'] ?? $context['media_type'] ?? '')));
        return (str_contains($signal,'series') || str_contains($signal,'serial') || str_contains($signal,'tv')) ? 'series' : 'movie';
    }
}

if (!function_exists('bm_poster_filename')) {
    function bm_poster_filename(string $url, array $context): string
    {
        $title = trim((string)($context['title_en'] ?? $context['title'] ?? $context['title_fa'] ?? $context['name'] ?? ''));
        $year  = trim((string)($context['year'] ?? $context['release_year'] ?? ''));
        $path  = (string)(parse_url($url, PHP_URL_PATH) ?? '');
        $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg','jpeg','png','webp','avif','gif'], true)) $ext = 'webp';
        if ($title === '') {
            $base = pathinfo(basename($path), PATHINFO_FILENAME);
            $title = $base !== '' ? $base : 'poster';
        }
        $title = preg_replace('/[\s_]+/u', '.', (string)$title);
        $title = preg_replace('/[^A-Za-z0-9\p{L}.-]+/u', '.', (string)$title);
        $title = preg_replace('/\.{2,}/', '.', (string)$title);
        $title = trim((string)$title, '.-');
        if ($title === '') $title = 'poster';
        if ($year !== '' && preg_match('/^(?:19|20)\d{2}$/', $year) && !preg_match('/(?:^|\.)'.preg_quote($year,'/').'(?:\.|$)/', $title)) $title .= '.' . $year;
        $title = function_exists('mb_substr') ? mb_substr($title, 0, 110, 'UTF-8') : substr($title, 0, 110);
        return $title . '.' . $ext;
    }
}

if (!function_exists('bm_poster_wrap_url')) {
    function bm_poster_wrap_url($url, array $context=[]): string
    {
        $url = trim((string)$url);
        if (!bm_poster_redirect_enabled() || !bm_poster_is_http_url($url) || bm_poster_is_own_url($url)) return $url;
        $key = bm_poster_key();
        if ($key === '') return $url;
        $digest = hash_hmac('sha256', 'route|' . $url, $key, true);
        $shard = (string)(ord($digest[0]) % 10) . chr(97 + (ord($digest[1]) % 26));
        $folder = bm_poster_route_chars($digest, 2, 5);
        $type = bm_poster_route_type($context);
        $filename = bm_poster_filename($url, $context);
        $sig = bm_poster_token_encode($url);
        if ($sig === '') return $url;
        return bm_poster_redirect_base() . '/' . $shard . '/poster/' . $type . '/' . $folder . '/' . rawurlencode($filename) . '?sig=' . rawurlencode($sig);
    }
}

if (!function_exists('bm_poster_wrap_value')) {
    function bm_poster_wrap_value($value, array $context=[])
    {
        if (is_string($value)) return bm_poster_wrap_url($value, $context);
        if (!is_array($value)) return $value;
        $out=[];
        foreach ($value as $k=>$v) $out[$k] = is_string($v) ? bm_poster_wrap_url($v,$context) : (is_array($v) ? bm_poster_wrap_value($v,$context) : $v);
        return $out;
    }
}

if (!function_exists('bm_poster_wrap_payload')) {
    function bm_poster_wrap_payload($payload, array $context=[])
    {
        if (!is_array($payload)) return $payload;
        $local=$context;
        foreach (['title_en','title','title_fa','name','year','release_year','type','media_type'] as $k) {
            if (isset($payload[$k]) && !is_array($payload[$k]) && trim((string)$payload[$k]) !== '') $local[$k]=(string)$payload[$k];
        }
        $posterKeys=['poster','poster_url','posterUrl','poster_image','posterImage','poster_proxy','cover_url','coverUrl','image','thumbnail'];
        $out=[];
        foreach ($payload as $k=>$v) {
            if (in_array((string)$k,$posterKeys,true)) $out[$k]=bm_poster_wrap_value($v,$local);
            elseif (is_array($v)) $out[$k]=bm_poster_wrap_payload($v,$local);
            else $out[$k]=$v;
        }
        return $out;
    }
}
