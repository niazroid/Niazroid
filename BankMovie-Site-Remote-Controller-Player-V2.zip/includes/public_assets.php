<?php
/**
 * Safe public-asset URL/path helpers.
 * Normalizes old DB values such as uploads/x.webp, /uploads/x.webp,
 * absolute public_html paths and same-site absolute URLs.
 */
declare(strict_types=1);

if (!function_exists('bm_public_root_path')) {
    function bm_public_root_path(): string
    {
        return rtrim(dirname(__DIR__), DIRECTORY_SEPARATOR);
    }
}

if (!function_exists('bm_public_asset_url')) {
    function bm_public_asset_url($value, string $fallback = ''): string
    {
        $raw = trim((string)$value);
        if ($raw === '') return $fallback;
        $raw = str_replace('\\', '/', $raw);

        if (preg_match('~^(?:https?:)?//~i', $raw)) {
            if (str_starts_with($raw, '//')) return 'https:' . $raw;
            $parts = @parse_url($raw);
            $host = strtolower((string)($parts['host'] ?? ''));
            $requestHost = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
            $requestHost = preg_replace('/:\d+$/', '', $requestHost);
            if ($host !== '' && $requestHost !== '' && !hash_equals($requestHost, $host)) return $raw;
            $raw = (string)($parts['path'] ?? '/');
            if (!empty($parts['query'])) $raw .= '?' . $parts['query'];
        }

        if (preg_match('~^(?:data|javascript|vbscript):~i', $raw)) return $fallback;

        $query = '';
        $fragment = '';
        if (($hashPos = strpos($raw, '#')) !== false) {
            $fragment = substr($raw, $hashPos);
            $raw = substr($raw, 0, $hashPos);
        }
        if (($queryPos = strpos($raw, '?')) !== false) {
            $query = substr($raw, $queryPos);
            $raw = substr($raw, 0, $queryPos);
        }

        $root = str_replace('\\', '/', bm_public_root_path());
        if (str_starts_with($raw, $root . '/')) $raw = substr($raw, strlen($root));
        if (preg_match('~/(?:public_html|htdocs)/(.*)$~i', $raw, $m)) {
            $raw = '/' . $m[1];
        } elseif (preg_match('~/www/(.*)$~i', $raw, $m)) {
            $raw = '/' . $m[1];
        }

        $raw = preg_replace('~^\./+~', '', $raw);
        $segments = [];
        foreach (explode('/', ltrim($raw, '/')) as $segment) {
            if ($segment === '' || $segment === '.') continue;
            if ($segment === '..') {
                array_pop($segments);
                continue;
            }
            $segments[] = $segment;
        }
        if (!$segments) return $fallback;
        return '/' . implode('/', $segments) . $query . $fragment;
    }
}

if (!function_exists('bm_public_asset_file_path')) {
    function bm_public_asset_file_path($value): string
    {
        $url = bm_public_asset_url($value, '');
        if ($url === '' || preg_match('~^https?://~i', $url)) return '';
        $path = rawurldecode((string)(parse_url($url, PHP_URL_PATH) ?: ''));
        if ($path === '') return '';
        $root = bm_public_root_path();
        $candidate = $root . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, ltrim($path, '/'));
        $normalizedRoot = str_replace('\\', '/', $root) . '/';
        $normalizedCandidate = str_replace('\\', '/', $candidate);
        if (!str_starts_with($normalizedCandidate, $normalizedRoot)) return '';
        return $candidate;
    }
}

if (!function_exists('bm_public_asset_exists')) {
    function bm_public_asset_exists($value): bool
    {
        $path = bm_public_asset_file_path($value);
        return $path !== '' && is_file($path);
    }
}

if (!function_exists('bm_public_asset_renderable')) {
    function bm_public_asset_renderable($value): bool
    {
        $url = bm_public_asset_url($value, '');
        if ($url === '') return false;
        if (preg_match('~^https?://~i', $url)) return true;
        return bm_public_asset_exists($url);
    }
}

