<?php
/**
 * Compatibility layer for older server files/plugins.
 * New code should load api6_lib.php directly.
 */
require_once __DIR__ . '/api6_lib.php';

if (!function_exists('punk_section_params')) { function punk_section_params($section, $page = 1) { return api6_section_params($section, $page); } }
if (!function_exists('punk_search')) { function punk_search($params) { return api6_search($params); } }
if (!function_exists('punk_get_details')) { function punk_get_details($identifier) { return api6_get_details($identifier); } }
if (!function_exists('punk_has_auth_cookie')) { function punk_has_auth_cookie() { return true; } }
