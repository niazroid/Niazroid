<?php
require_once __DIR__ . '/site_content_control.php';
require_once __DIR__ . '/error_visual.php';

if (!headers_sent()) {
    header('Content-Type: text/html; charset=UTF-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    if (!empty($statusHeader)) {
        header(($_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.1') . ' ' . $statusHeader);
    }
}

$siteName = 'BankMovie';
$codeRaw = (string)($errorCode ?? 'خطا');
$titleRaw = (string)($errorTitle ?? 'مشکلی پیش آمد');
$subtitleRaw = (string)($errorSubtitle ?? '');
$descriptionRaw = (string)($errorDescription ?? '');
$hintRaw = (string)($errorHint ?? '');
$codeStr = htmlspecialchars($codeRaw, ENT_QUOTES, 'UTF-8');
$titleStr = htmlspecialchars($titleRaw, ENT_QUOTES, 'UTF-8');
$subtitleStr = htmlspecialchars($subtitleRaw, ENT_QUOTES, 'UTF-8');
$descriptionStr = htmlspecialchars($descriptionRaw, ENT_QUOTES, 'UTF-8');
$hintStr = htmlspecialchars($hintRaw, ENT_QUOTES, 'UTF-8');
$showRetry = !empty($showRetry);
$is404 = $codeRaw === '404';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="robots" content="noindex, nofollow">
    <meta name="theme-color" content="#05070b">
    <title><?= $codeStr ?> | <?= $titleStr ?> | <?= $siteName ?></title>
    <link rel="stylesheet" href="/assets/vendor/boxicons.min.css">
    <link rel="stylesheet" href="/assets/css/bm-uiverse-error-v114.css?v=114">
    <link rel="stylesheet" href="/assets/css/bm-error-integration-v114.css?v=114">
    <style>
        <?= bm_site_typography_css() ?>
        *{box-sizing:border-box}
        html,body{margin:0;min-height:100%}
        body{
            min-height:100svh;
            overflow-x:hidden;
            font-family:var(--bm-site-font,'BonVF'),system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
            color:#f7f9ff;
            background:
                radial-gradient(circle at 18% 22%,rgba(25,190,125,.18),transparent 32%),
                radial-gradient(circle at 86% 76%,rgba(42,117,255,.14),transparent 30%),
                #05070b;
        }
        a,button{font:inherit}
        .bm-error-page{
            width:min(1180px,100%);
            min-height:100svh;
            margin-inline:auto;
            padding:clamp(16px,3vw,38px);
            display:flex;
            flex-direction:column;
            justify-content:center;
            gap:18px;
        }
        .bm-error-topbar{
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            color:rgba(255,255,255,.62);
            font-size:12px;
        }
        .bm-error-brand{display:inline-flex;align-items:center;gap:9px;color:#fff;text-decoration:none;font-weight:900}
        .bm-error-brand img{width:82px;height:auto;display:block;object-fit:contain}
        .bm-error-status{display:inline-flex;align-items:center;gap:8px;padding:8px 12px;border:1px solid rgba(255,255,255,.09);border-radius:999px;background:rgba(255,255,255,.045)}
        .bm-error-status::before{content:"";width:7px;height:7px;border-radius:50%;background:#ffb347;box-shadow:0 0 14px #ff8a00}
        .bm-error-card{
            position:relative;
            min-width:0;
            display:grid;
            grid-template-columns:minmax(390px,.95fr) minmax(0,1.05fr);
            align-items:center;
            gap:clamp(18px,4vw,52px);
            padding:clamp(20px,3.2vw,42px);
            overflow:hidden;
            border:1px solid rgba(255,255,255,.085);
            border-radius:32px;
            background:linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.018));
            box-shadow:0 30px 90px rgba(0,0,0,.42);
            backdrop-filter:blur(16px);
            -webkit-backdrop-filter:blur(16px);
        }
        .bm-error-card::before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(120deg,rgba(42,196,255,.06),transparent 36%,rgba(74,255,158,.045));}
        .bm-error-visual{position:relative;z-index:1;min-width:0;display:grid;place-items:center;overflow:visible}
        .bm-error-copy{position:relative;z-index:2;min-width:0}
        .bm-error-kicker{display:inline-flex;align-items:center;gap:8px;padding:7px 12px;border:1px solid rgba(56,169,255,.28);border-radius:999px;background:rgba(56,169,255,.08);color:#7fd3ff;font-size:11px;font-weight:900}
        .bm-error-code{margin:12px 0 4px;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-size:clamp(48px,8vw,92px);font-weight:1000;line-height:.95;letter-spacing:-.05em;color:#fff}
        .bm-error-copy h1{margin:0 0 10px;font-size:clamp(25px,3.2vw,43px);line-height:1.25;font-weight:1000}
        .bm-error-subtitle{margin:0 0 10px;color:#dce5f4;font-size:clamp(14px,1.5vw,17px);font-weight:750;line-height:1.9}
        .bm-error-description{margin:0;color:rgba(230,237,249,.66);font-size:14px;line-height:2}
        .bm-error-hint{margin-top:15px;padding:12px 14px;border:1px solid rgba(255,255,255,.07);border-radius:16px;background:rgba(255,255,255,.035);color:rgba(255,255,255,.72);font-size:12px;line-height:1.85}
        .bm-error-actions{display:flex;flex-wrap:wrap;gap:10px;margin-top:22px}
        .bm-error-btn{min-height:44px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:10px 16px;border:1px solid rgba(255,255,255,.11);border-radius:14px;background:rgba(255,255,255,.055);color:#fff;text-decoration:none;font-weight:900;cursor:pointer;transition:.2s ease}
        .bm-error-btn:hover{transform:translateY(-2px);background:rgba(255,255,255,.09)}
        .bm-error-btn--primary{border-color:transparent;background:linear-gradient(135deg,#28d68d,#42c8ff);color:#03120d;box-shadow:0 12px 26px rgba(40,214,141,.15)}
        .bm-error-footer{display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap;color:rgba(255,255,255,.45);font-size:11px;padding-inline:4px}
        .bm-error-footer a{color:rgba(255,255,255,.72);text-decoration:none}
        @media(max-width:900px){
            .bm-error-page{justify-content:flex-start;padding-top:max(16px,env(safe-area-inset-top))}
            .bm-error-card{grid-template-columns:1fr;gap:4px;padding:20px 18px 24px}
            .bm-error-visual{order:0}
            .bm-error-copy{order:1;text-align:center}
            .bm-error-actions{justify-content:center}
            .bm-error-hint{text-align:right}
            .bm-error-code{font-size:54px;margin-top:2px}
        }
        @media(max-width:480px){
            .bm-error-page{padding:12px}
            .bm-error-topbar{padding-inline:2px}
            .bm-error-brand img{width:68px}
            .bm-error-card{border-radius:23px;padding:14px 12px 20px}
            .bm-error-copy h1{font-size:24px}
            .bm-error-description{font-size:12px;line-height:1.85}
            .bm-error-hint{font-size:11px}
            .bm-error-btn{flex:1 1 130px;min-height:42px;padding:9px 12px}
            .bm-error-footer{justify-content:center;text-align:center}
        }
        @media(max-height:620px) and (orientation:landscape){
            .bm-error-page{justify-content:flex-start;padding:10px 18px}
            .bm-error-card{grid-template-columns:minmax(300px,.9fr) minmax(0,1.1fr);padding:12px 18px;gap:16px}
            .bm-error-copy{text-align:right}
            .bm-error-code{font-size:44px;margin:4px 0}
            .bm-error-copy h1{font-size:25px;margin-bottom:4px}
            .bm-error-subtitle{font-size:12px;line-height:1.55;margin-bottom:4px}
            .bm-error-description{font-size:11px;line-height:1.6}
            .bm-error-hint{margin-top:6px;padding:7px 10px;line-height:1.5}
            .bm-error-actions{justify-content:flex-start;margin-top:8px}
            .bm-error-btn{min-height:36px;padding:6px 11px;font-size:11px}
            .bm-error-footer{display:none}
        }
    </style>
</head>
<body>
<main class="bm-error-page">
    <div class="bm-error-topbar">
        <a class="bm-error-brand" href="/" aria-label="BankMovie">
            <img src="/assets/images/logo.png" alt="BankMovie" onerror="this.style.display='none'">
            <span>BankMovie</span>
        </a>
        <span class="bm-error-status">خطای <?= $codeStr ?></span>
    </div>

    <section class="bm-error-card" aria-labelledby="bmErrorTitle">
        <div class="bm-error-visual">
            <?= bm_error_tv_markup([
                'id' => 'pageErrorTv',
                'code' => $codeRaw,
                'title' => $titleRaw,
                'message' => $subtitleRaw,
                'variant' => $is404 ? 'face' : 'signal',
                'backdrop' => $is404,
            ]) ?>
        </div>

        <div class="bm-error-copy">
            <span class="bm-error-kicker"><i class="bx bx-tv"></i> پاسخ سرور <?= $codeStr ?></span>
            <div class="bm-error-code"><?= $codeStr ?></div>
            <h1 id="bmErrorTitle"><?= $titleStr ?></h1>
            <?php if ($subtitleStr !== ''): ?><p class="bm-error-subtitle"><?= $subtitleStr ?></p><?php endif; ?>
            <?php if ($descriptionStr !== ''): ?><p class="bm-error-description"><?= $descriptionStr ?></p><?php endif; ?>
            <?php if ($hintStr !== ''): ?><div class="bm-error-hint"><i class="bx bx-info-circle"></i> <?= $hintStr ?></div><?php endif; ?>
            <div class="bm-error-actions">
                <a class="bm-error-btn bm-error-btn--primary" href="/"><i class="bx bx-home-alt-2"></i> صفحه اصلی</a>
                <a class="bm-error-btn" href="javascript:history.back()"><i class="bx bx-arrow-back"></i> بازگشت</a>
                <?php if ($showRetry): ?><button class="bm-error-btn" type="button" onclick="location.reload()"><i class="bx bx-refresh"></i> تلاش دوباره</button><?php endif; ?>
            </div>
        </div>
    </section>

    <footer class="bm-error-footer">
        <span>BankMovie · صفحه خطای اختصاصی</span>
        <span><a href="/application">اپلیکیشن‌ها</a> · <a href="/collections.php">کالکشن‌ها</a></span>
    </footer>
</main>
</body>
</html>
