<?php
/**
 * BankMovie Watch Party foundation (VIP host + free invited companion).
 *
 * Direct test URLs may be stored only inside the private room record so the
 * invited companion browser can load the same source. The URL and every related row
 * are hard-deleted with the room after a maximum of four hours.
 */

declare(strict_types=1);

if (defined('BANKMOVIE_WATCH_PARTY_LOADED')) {
    return;
}
define('BANKMOVIE_WATCH_PARTY_LOADED', true);

require_once __DIR__ . '/user_avatar.php';
require_once __DIR__ . '/user_theme.php';

if (!function_exists('bm_watch_party_column_exists')) {
    function bm_watch_party_column_exists(PDO $pdo, string $table, string $column): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1');
            $stmt->execute([$table, $column]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_index_exists')) {
    function bm_watch_party_index_exists(PDO $pdo, string $table, string $index): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $index)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND INDEX_NAME=? LIMIT 1');
            $stmt->execute([$table, $index]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_user_vip_schema')) {
    function bm_watch_party_user_vip_schema(PDO $pdo): bool
    {
        try {
            $exists = $pdo->query("SHOW TABLES LIKE 'users'")->fetchColumn();
            if (!$exists) return false;
            if (!bm_watch_party_column_exists($pdo, 'users', 'vip_expires_at')) {
                $pdo->exec('ALTER TABLE users ADD COLUMN vip_expires_at DATETIME NULL');
            }
            if (!bm_watch_party_index_exists($pdo, 'users', 'idx_users_vip_expiry')) {
                try { $pdo->exec('ALTER TABLE users ADD INDEX idx_users_vip_expiry (vip_expires_at)'); } catch (Throwable $e) { /* optional */ }
            }
            return true;
        } catch (Throwable $e) {
            error_log('Watch Party VIP user schema error: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_grant_vip')) {
    function bm_watch_party_grant_vip(PDO $pdo, int $userId, ?string $expiresAt = null): array
    {
        if ($userId <= 0) throw new RuntimeException('invalid_user', 422);
        bm_watch_party_user_vip_schema($pdo);
        $stmt = $pdo->prepare('SELECT id,username,role FROM users WHERE id=? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) throw new RuntimeException('user_not_found', 404);
        if (in_array(strtolower((string)($user['role'] ?? '')), ['admin','administrator'], true)) {
            throw new RuntimeException('admin_role_is_protected', 409);
        }
        if ($expiresAt !== null && strtotime($expiresAt) === false) {
            throw new RuntimeException('invalid_vip_expiry', 422);
        }
        $historyReady = function_exists('bm_vip_ensure_history_columns') && bm_vip_ensure_history_columns($pdo);
        $grantSql = $historyReady
            ? "UPDATE users SET role='vip', vip_expires_at=?, vip_last_expires_at=NULL WHERE id=?"
            : "UPDATE users SET role='vip', vip_expires_at=? WHERE id=?";
        $pdo->prepare($grantSql)->execute([$expiresAt, $userId]);
        return ['user_id'=>$userId,'username'=>(string)($user['username'] ?? ''),'role'=>'vip','vip_expires_at'=>$expiresAt];
    }
}

if (!function_exists('bm_watch_party_revoke_vip')) {
    function bm_watch_party_revoke_vip(PDO $pdo, int $userId): array
    {
        if ($userId <= 0) throw new RuntimeException('invalid_user', 422);
        bm_watch_party_user_vip_schema($pdo);
        $stmt = $pdo->prepare('SELECT id,username,role FROM users WHERE id=? LIMIT 1');
        $stmt->execute([$userId]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$user) throw new RuntimeException('user_not_found', 404);
        $role = strtolower((string)($user['role'] ?? ''));
        if (in_array($role, ['admin','administrator'], true)) {
            throw new RuntimeException('admin_role_is_protected', 409);
        }
        $nextRole = in_array($role, ['vip','premium','special'], true) ? 'user' : (string)($user['role'] ?? 'user');
        $pdo->prepare('UPDATE users SET role=?, vip_expires_at=NULL WHERE id=?')->execute([$nextRole, $userId]);
        return ['user_id'=>$userId,'username'=>(string)($user['username'] ?? ''),'role'=>$nextRole,'vip_expires_at'=>null];
    }
}

if (!function_exists('bm_watch_party_table_exists')) {
    function bm_watch_party_table_exists(PDO $pdo, string $table): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? LIMIT 1');
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_prepare_connection')) {
    function bm_watch_party_prepare_connection(PDO $pdo): void
    {
        static $prepared = [];
        $key = spl_object_id($pdo);
        if (!empty($prepared[$key])) return;
        // All legacy Watch Party DATETIME values were created in Asia/Tehran.
        // Pin this PDO session to the same fixed offset so NOW(), cleanup and
        // UNIX_TIMESTAMP() never disagree with PHP or with older room rows.
        try { $pdo->exec("SET time_zone = '+03:30'"); } catch (Throwable $e) { /* epoch checks below remain authoritative */ }
        $prepared[$key] = true;
    }
}

if (!function_exists('bm_watch_party_expiry_epoch')) {
    function bm_watch_party_expiry_epoch(array $room): int
    {
        // V148.61.9.47 — one authoritative expiry resolver.
        // Some shared-host MySQL/PHP stacks can momentarily disagree about the
        // absolute epoch while the Tehran DATETIME is still correct. Never expire
        // a room from one clock alone; accept only candidates that fit inside the
        // room's original <=4 hour lifetime and self-heal the stored epoch later.
        $epoch = max(0, (int)($room['expires_at_epoch'] ?? 0));
        $raw = trim((string)($room['expires_at'] ?? ''));
        $textEpoch = $raw !== '' ? strtotime($raw) : false;
        $textEpoch = $textEpoch === false ? 0 : (int)$textEpoch;
        $createdRaw = trim((string)($room['created_at'] ?? ''));
        $createdEpoch = $createdRaw !== '' ? strtotime($createdRaw) : false;
        $createdEpoch = $createdEpoch === false ? 0 : (int)$createdEpoch;
        $hours = function_exists('bm_watch_party_max_hours') ? bm_watch_party_max_hours() : 4;
        $hardMax = $createdEpoch > 0 ? ($createdEpoch + ($hours * 3600) + 180) : 0;

        $candidates = [];
        foreach ([$epoch, $textEpoch] as $candidate) {
            if ($candidate <= 0) continue;
            if ($createdEpoch > 0 && $candidate < $createdEpoch - 180) continue;
            if ($hardMax > 0 && $candidate > $hardMax) continue;
            $candidates[] = $candidate;
        }
        if ($candidates) return max($candidates);
        return $epoch > 0 ? $epoch : $textEpoch;
    }
}

if (!function_exists('bm_watch_party_schema_report')) {
    function bm_watch_party_schema_report(PDO $pdo): array
    {
        $tables = ['watch_party_rooms','watch_party_room_codes','watch_party_members','watch_party_state','watch_party_events','watch_party_messages'];
        $missing = [];
        foreach ($tables as $table) {
            if (!bm_watch_party_table_exists($pdo, $table)) $missing[] = $table;
        }
        $stateColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_state', 'position_seconds');
        $clockColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_state', 'updated_at_ms');
        $sharedUrlColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'shared_source_url');
        $sharedSubtitleColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'shared_subtitle_url');
        $roomThemeColumnsReady = bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'theme_key')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'content_title')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'poster_url')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'background_key')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'countdown_seconds')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'start_at_seconds')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'scheduled_start_at_ms')
            && bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'scheduled_start_token');
        $expiryEpochColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'expires_at_epoch');
        $vipColumnReady = bm_watch_party_column_exists($pdo, 'users', 'vip_expires_at');
        $guestMemberColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_members', 'guest_token_hash');
        $guestMessageColumnReady = bm_watch_party_column_exists($pdo, 'watch_party_messages', 'guest_token_hash');
        $reliableMessageColumnsReady = bm_watch_party_column_exists($pdo, 'watch_party_messages', 'client_message_id')
            && bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_at')
            && bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_by_user_id')
            && bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_by_guest_hash');
        return [
            'ready' => $missing === [] && $stateColumnReady && $clockColumnReady && $sharedUrlColumnReady && $sharedSubtitleColumnReady && $roomThemeColumnsReady && $expiryEpochColumnReady && $guestMemberColumnReady && $guestMessageColumnReady && $reliableMessageColumnsReady,
            'missing_tables' => $missing,
            'state_column_ready' => $stateColumnReady,
            'clock_column_ready' => $clockColumnReady,
            'shared_url_column_ready' => $sharedUrlColumnReady,
            'shared_subtitle_column_ready' => $sharedSubtitleColumnReady,
            'room_theme_columns_ready' => $roomThemeColumnsReady,
            'expiry_epoch_column_ready' => $expiryEpochColumnReady,
            'vip_column_ready' => $vipColumnReady,
            'guest_member_column_ready' => $guestMemberColumnReady,
            'guest_message_column_ready' => $guestMessageColumnReady,
            'reliable_message_columns_ready' => $reliableMessageColumnsReady,
            'last_error' => (string)($GLOBALS['bm_watch_party_schema_error'] ?? ''),
        ];
    }
}

if (!function_exists('bm_watch_party_install_schema')) {
    function bm_watch_party_install_schema(PDO $pdo): void
    {
        // VIP expiry is useful but must not prevent the room engine from installing.
        bm_watch_party_user_vip_schema($pdo);

        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_rooms (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room_code_hash CHAR(64) NOT NULL,
            host_user_id BIGINT UNSIGNED NOT NULL,
            movie_id BIGINT UNSIGNED NULL,
            archive_no TINYINT UNSIGNED NOT NULL DEFAULT 1,
            media_type VARCHAR(20) NOT NULL DEFAULT 'movie',
            source_ref VARCHAR(190) NULL,
            shared_source_url TEXT NULL,
            shared_subtitle_url TEXT NULL,
            source_updated_at DATETIME NULL,
            content_title VARCHAR(190) NULL,
            poster_url VARCHAR(600) NULL,
            theme_key VARCHAR(32) NOT NULL DEFAULT 'default',
            background_key VARCHAR(32) NOT NULL DEFAULT 'simple',
            countdown_seconds TINYINT UNSIGNED NOT NULL DEFAULT 10,
            start_at_seconds DECIMAL(10,3) NOT NULL DEFAULT 0,
            scheduled_start_at_ms BIGINT UNSIGNED NOT NULL DEFAULT 0,
            scheduled_start_token BIGINT UNSIGNED NOT NULL DEFAULT 0,
            status VARCHAR(20) NOT NULL DEFAULT 'waiting',
            max_members TINYINT UNSIGNED NOT NULL DEFAULT 2,
            created_at DATETIME NOT NULL,
            expires_at DATETIME NOT NULL,
            expires_at_epoch BIGINT UNSIGNED NOT NULL DEFAULT 0,
            last_activity_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_watch_party_room_code_hash (room_code_hash),
            KEY idx_watch_party_rooms_expiry (expires_at),
            KEY idx_watch_party_rooms_expiry_epoch (expires_at_epoch),
            KEY idx_watch_party_rooms_host (host_user_id, expires_at),
            KEY idx_watch_party_rooms_status (status, expires_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        // CREATE TABLE IF NOT EXISTS does not add columns to an existing table.
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'shared_source_url')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN shared_source_url TEXT NULL AFTER source_ref');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'shared_subtitle_url')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN shared_subtitle_url TEXT NULL AFTER shared_source_url');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'source_updated_at')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN source_updated_at DATETIME NULL AFTER shared_subtitle_url');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'content_title')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN content_title VARCHAR(190) NULL AFTER source_updated_at');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'poster_url')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN poster_url VARCHAR(600) NULL AFTER content_title');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'theme_key')) {
            $pdo->exec("ALTER TABLE watch_party_rooms ADD COLUMN theme_key VARCHAR(32) NOT NULL DEFAULT 'default' AFTER poster_url");
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'background_key')) {
            $pdo->exec("ALTER TABLE watch_party_rooms ADD COLUMN background_key VARCHAR(32) NOT NULL DEFAULT 'simple' AFTER theme_key");
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'countdown_seconds')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN countdown_seconds TINYINT UNSIGNED NOT NULL DEFAULT 10 AFTER theme_key');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'start_at_seconds')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN start_at_seconds DECIMAL(10,3) NOT NULL DEFAULT 0 AFTER countdown_seconds');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'scheduled_start_at_ms')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN scheduled_start_at_ms BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER start_at_seconds');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'scheduled_start_token')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN scheduled_start_token BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER scheduled_start_at_ms');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_rooms', 'expires_at_epoch')) {
            $pdo->exec('ALTER TABLE watch_party_rooms ADD COLUMN expires_at_epoch BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER expires_at');
        }
        try {
            if (!bm_watch_party_index_exists($pdo, 'watch_party_rooms', 'idx_watch_party_rooms_expiry_epoch')) {
                $pdo->exec('ALTER TABLE watch_party_rooms ADD INDEX idx_watch_party_rooms_expiry_epoch (expires_at_epoch)');
            }
        } catch (Throwable $e) { /* optional optimization */ }
        // Repair legacy rows once. With the session pinned to +03:30 this converts
        // the original Tehran DATETIME to an absolute Unix timestamp correctly.
        $pdo->exec('UPDATE watch_party_rooms SET expires_at_epoch=UNIX_TIMESTAMP(expires_at) WHERE expires_at_epoch=0');

        // A room may have more than one valid invite code. This lets a VIP reopen
        // the latest room directly from a movie link without invalidating the code
        // already shared with the second viewer.
        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_room_codes (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room_id BIGINT UNSIGNED NOT NULL,
            room_code_hash CHAR(64) NOT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_watch_party_room_alias_hash (room_code_hash),
            KEY idx_watch_party_room_alias_room (room_id, id),
            CONSTRAINT fk_watch_party_room_alias_room
                FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_members (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            guest_token_hash CHAR(64) NULL,
            guest_name VARCHAR(80) NULL,
            guest_avatar VARCHAR(255) NULL,
            member_role VARCHAR(12) NOT NULL DEFAULT 'guest',
            joined_at DATETIME NOT NULL,
            last_seen_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_watch_party_member (room_id, user_id),
            KEY idx_watch_party_members_user (user_id, last_seen_at),
            KEY idx_watch_party_members_guest (room_id, guest_token_hash),
            CONSTRAINT fk_watch_party_members_room
                FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        if (!bm_watch_party_column_exists($pdo, 'watch_party_members', 'guest_token_hash')) {
            $pdo->exec('ALTER TABLE watch_party_members ADD COLUMN guest_token_hash CHAR(64) NULL AFTER user_id');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_members', 'guest_name')) {
            $pdo->exec('ALTER TABLE watch_party_members ADD COLUMN guest_name VARCHAR(80) NULL AFTER guest_token_hash');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_members', 'guest_avatar')) {
            $pdo->exec('ALTER TABLE watch_party_members ADD COLUMN guest_avatar VARCHAR(255) NULL AFTER guest_name');
        }
        try {
            if (!bm_watch_party_index_exists($pdo, 'watch_party_members', 'idx_watch_party_members_guest')) {
                $pdo->exec('ALTER TABLE watch_party_members ADD INDEX idx_watch_party_members_guest (room_id,guest_token_hash)');
            }
        } catch (Throwable $e) { /* optional optimization */ }

        // CURRENT_TIME is reserved on some MySQL/MariaDB builds. Use a neutral
        // column name so no SELECT/UPDATE query depends on quoting behavior.
        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_state (
            room_id BIGINT UNSIGNED NOT NULL,
            sequence_no BIGINT UNSIGNED NOT NULL DEFAULT 0,
            position_seconds DECIMAL(12,3) NOT NULL DEFAULT 0,
            is_paused TINYINT(1) NOT NULL DEFAULT 1,
            playback_rate DECIMAL(5,3) NOT NULL DEFAULT 1,
            buffering TINYINT(1) NOT NULL DEFAULT 0,
            updated_by BIGINT UNSIGNED NULL,
            updated_at_ms BIGINT UNSIGNED NOT NULL DEFAULT 0,
            updated_at DATETIME NOT NULL,
            PRIMARY KEY (room_id),
            CONSTRAINT fk_watch_party_state_room
                FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        if (!bm_watch_party_column_exists($pdo, 'watch_party_state', 'position_seconds')) {
            $pdo->exec('ALTER TABLE watch_party_state ADD COLUMN position_seconds DECIMAL(12,3) NOT NULL DEFAULT 0 AFTER sequence_no');
            if (bm_watch_party_column_exists($pdo, 'watch_party_state', 'current_time')) {
                $pdo->exec('UPDATE watch_party_state SET position_seconds=COALESCE(`current_time`,0)');
            }
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_state', 'updated_at_ms')) {
            $pdo->exec('ALTER TABLE watch_party_state ADD COLUMN updated_at_ms BIGINT UNSIGNED NOT NULL DEFAULT 0 AFTER updated_by');
            $pdo->exec('UPDATE watch_party_state SET updated_at_ms=CAST(UNIX_TIMESTAMP(updated_at) * 1000 AS UNSIGNED) WHERE updated_at_ms=0');
        }

        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_events (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            event_type VARCHAR(32) NOT NULL,
            sequence_no BIGINT UNSIGNED NOT NULL,
            payload_json TEXT NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY idx_watch_party_events_room_id (room_id, id),
            KEY idx_watch_party_events_created (created_at),
            CONSTRAINT fk_watch_party_events_room
                FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        $pdo->exec("CREATE TABLE IF NOT EXISTS watch_party_messages (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            room_id BIGINT UNSIGNED NOT NULL,
            user_id BIGINT UNSIGNED NOT NULL,
            guest_token_hash CHAR(64) NULL,
            guest_name VARCHAR(80) NULL,
            guest_avatar VARCHAR(255) NULL,
            client_message_id VARCHAR(64) NULL,
            message VARCHAR(500) NOT NULL,
            delivered_at DATETIME NULL,
            delivered_by_user_id BIGINT UNSIGNED NULL,
            delivered_by_guest_hash CHAR(64) NULL,
            created_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uq_watch_party_messages_client (room_id, client_message_id),
            KEY idx_watch_party_messages_room_id (room_id, id),
            KEY idx_watch_party_messages_rate (room_id, user_id, created_at),
            KEY idx_watch_party_messages_guest_rate (room_id, guest_token_hash, created_at),
            KEY idx_watch_party_messages_created (created_at),
            CONSTRAINT fk_watch_party_messages_room
                FOREIGN KEY (room_id) REFERENCES watch_party_rooms(id)
                ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'guest_token_hash')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN guest_token_hash CHAR(64) NULL AFTER user_id');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'guest_name')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN guest_name VARCHAR(80) NULL AFTER guest_token_hash');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'guest_avatar')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN guest_avatar VARCHAR(255) NULL AFTER guest_name');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'client_message_id')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN client_message_id VARCHAR(64) NULL AFTER guest_avatar');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_at')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN delivered_at DATETIME NULL AFTER message');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_by_user_id')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN delivered_by_user_id BIGINT UNSIGNED NULL AFTER delivered_at');
        }
        if (!bm_watch_party_column_exists($pdo, 'watch_party_messages', 'delivered_by_guest_hash')) {
            $pdo->exec('ALTER TABLE watch_party_messages ADD COLUMN delivered_by_guest_hash CHAR(64) NULL AFTER delivered_by_user_id');
        }
        try {
            if (!bm_watch_party_index_exists($pdo, 'watch_party_messages', 'uq_watch_party_messages_client')) {
                $pdo->exec('ALTER TABLE watch_party_messages ADD UNIQUE INDEX uq_watch_party_messages_client (room_id,client_message_id)');
            }
        } catch (Throwable $e) { /* optional idempotency index */ }
        try {
            if (!bm_watch_party_index_exists($pdo, 'watch_party_messages', 'idx_watch_party_messages_guest_rate')) {
                $pdo->exec('ALTER TABLE watch_party_messages ADD INDEX idx_watch_party_messages_guest_rate (room_id,guest_token_hash,created_at)');
            }
        } catch (Throwable $e) { /* optional optimization */ }

        try {
            // Recreate the event so older installations do not keep the legacy
            // DATETIME/NOW() body. EVENT privilege and event_scheduler are optional.
            $pdo->exec('DROP EVENT IF EXISTS bm_watch_party_expiry_cleanup');
            $pdo->exec("CREATE EVENT bm_watch_party_expiry_cleanup
                ON SCHEDULE EVERY 1 MINUTE
                DO DELETE FROM watch_party_rooms
                WHERE (expires_at_epoch>0 AND expires_at_epoch<=UNIX_TIMESTAMP() AND expires_at<=NOW())
                   OR (expires_at_epoch=0 AND expires_at<=NOW())");
        } catch (Throwable $e) {
            // Active-room countdown, strict request cleanup and cron remain authoritative.
        }
    }
}

if (!function_exists('bm_watch_party_schema')) {
    function bm_watch_party_schema(PDO $pdo, bool $forceRepair = false): bool
    {
        bm_watch_party_prepare_connection($pdo);
        static $runtimeReady = null;
        if (!$forceRepair && $runtimeReady === true) return true;

        $GLOBALS['bm_watch_party_schema_error'] = '';
        try {
            if ($forceRepair) {
                bm_watch_party_install_schema($pdo);
            } elseif (function_exists('bm_schema_once')) {
                // Version 11 adds idempotent queued chat delivery receipts.
                $ok = bm_schema_once($pdo, 'watch-party', 11, static function (PDO $pdo): void {
                    bm_watch_party_install_schema($pdo);
                });
                if (!$ok) bm_watch_party_install_schema($pdo);
            } else {
                bm_watch_party_install_schema($pdo);
            }

            $report = bm_watch_party_schema_report($pdo);
            if (!$report['ready']) {
                // A stale marker or an interrupted first install can leave only some tables.
                bm_watch_party_install_schema($pdo);
                $report = bm_watch_party_schema_report($pdo);
            }
            $runtimeReady = (bool)$report['ready'];
            if (!$runtimeReady) {
                $GLOBALS['bm_watch_party_schema_error'] = 'missing:' . implode(',', (array)$report['missing_tables']);
            }
            return $runtimeReady;
        } catch (Throwable $e) {
            $runtimeReady = false;
            $GLOBALS['bm_watch_party_schema_error'] = $e->getMessage();
            error_log('Watch Party schema repair error: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('bm_watch_party_max_hours')) {
    function bm_watch_party_max_hours(): int
    {
        $configured = function_exists('bm_site_get') ? (int)bm_site_get('watch_party_room_hours', 4) : 4;
        return max(1, min(4, $configured));
    }
}

if (!function_exists('bm_watch_party_max_members')) {
    function bm_watch_party_max_members(): int
    {
        $configured = function_exists('bm_site_get') ? (int)bm_site_get('watch_party_max_members', 2) : 2;
        return max(2, min(2, $configured)); // First release is deliberately partner-only.
    }
}

if (!function_exists('bm_watch_party_is_enabled')) {
    function bm_watch_party_is_enabled(): bool
    {
        return function_exists('bm_vip_feature_enabled') && bm_vip_feature_enabled('watch_party');
    }
}

// Backward-compatible alias for older admin links. Watch Party no longer has a preview mode.
if (!function_exists('bm_watch_party_admin_preview_enabled')) {
    function bm_watch_party_admin_preview_enabled(): bool
    {
        return bm_watch_party_is_enabled();
    }
}

if (!function_exists('bm_watch_party_chat_enabled')) {
    function bm_watch_party_chat_enabled(): bool
    {
        return !function_exists('bm_site_bool') || bm_site_bool('watch_party_chat_enabled', true);
    }
}

if (!function_exists('bm_watch_party_is_admin')) {
    function bm_watch_party_is_admin(?array $user): bool
    {
        if (!is_array($user)) return false;
        return in_array(strtolower(trim((string)($user['role'] ?? ''))), ['admin', 'administrator'], true);
    }
}

if (!function_exists('bm_watch_party_is_vip')) {
    function bm_watch_party_is_vip(?array $user): bool
    {
        if (!is_array($user)) return false;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (in_array($role, ['admin', 'administrator'], true)) return true;
        if (!in_array($role, ['vip', 'premium', 'special'], true)) return false;

        // Future-compatible: when a VIP expiry column exists, an expired account is rejected.
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry !== '') {
            $timestamp = strtotime($expiry);
            if ($timestamp !== false && $timestamp <= time()) return false;
        }
        return true;
    }
}

if (!function_exists('bm_watch_party_current_user')) {
    function bm_watch_party_current_user(PDO $pdo): ?array
    {
        global $currentUser;
        if (isset($currentUser) && is_array($currentUser) && !empty($currentUser['id'])) {
            return $currentUser;
        }

        $userId = (int)($_SESSION['user_id'] ?? 0);
        if ($userId <= 0) return null;
        try {
            $stmt = $pdo->prepare('SELECT * FROM users WHERE id=? LIMIT 1');
            $stmt->execute([$userId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return is_array($row) ? $row : null;
        } catch (Throwable $e) {
            return null;
        }
    }
}

if (!function_exists('bm_watch_party_guest_token')) {
    function bm_watch_party_guest_token(): string
    {
        $token = session_status() === PHP_SESSION_ACTIVE
            ? (string)($_SESSION['bm_watch_party_guest_token'] ?? '')
            : '';
        if (!preg_match('/^[A-Za-z0-9_-]{40,120}$/', $token)) {
            $cookieToken = (string)($_COOKIE['bm_wp_guest'] ?? '');
            $token = preg_match('/^[A-Za-z0-9_-]{40,120}$/', $cookieToken) ? $cookieToken : '';
        }
        if ($token === '') {
            $token = rtrim(strtr(base64_encode(random_bytes(36)), '+/', '-_'), '=');
        }
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION['bm_watch_party_guest_token'] = $token;
        }
        if (!headers_sent()) {
            $secure = function_exists('bm_security_is_https') ? bm_security_is_https() : false;
            setcookie('bm_wp_guest', $token, [
                'expires' => time() + 18000,
                'path' => '/',
                'domain' => '',
                'secure' => $secure,
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }
        return $token;
    }
}

if (!function_exists('bm_watch_party_guest_actor')) {
    function bm_watch_party_guest_actor(): array
    {
        $token = bm_watch_party_guest_token();
        $suffix = $token !== '' ? strtoupper(substr(hash('sha256', $token), 0, 4)) : 'GUEST';
        return [
            'id' => 0,
            'username' => 'همراه مهمان ' . $suffix,
            'role' => 'guest',
            'avatar' => '',
            'vip_expires_at' => null,
            'is_watch_party_guest' => true,
            'watch_party_guest_token' => $token,
        ];
    }
}

if (!function_exists('bm_watch_party_actor_is_guest')) {
    function bm_watch_party_actor_is_guest(?array $user): bool
    {
        return is_array($user) && !empty($user['is_watch_party_guest']) && (int)($user['id'] ?? 0) === 0;
    }
}

if (!function_exists('bm_watch_party_actor_guest_hash')) {
    function bm_watch_party_actor_guest_hash(?array $user): string
    {
        if (!bm_watch_party_actor_is_guest($user)) return '';
        $token = (string)($user['watch_party_guest_token'] ?? '');
        return $token !== '' ? hash('sha256', $token) : '';
    }
}

if (!function_exists('bm_watch_party_invite_access_allowed')) {
    function bm_watch_party_invite_access_allowed(?array $room): bool
    {
        return bm_watch_party_is_enabled() && is_array($room) && !empty($room['id']) && bm_watch_party_expiry_epoch($room) > time();
    }
}

if (!function_exists('bm_watch_party_access_allowed')) {
    function bm_watch_party_access_allowed(?array $user): bool
    {
        return bm_watch_party_is_enabled() && bm_watch_party_is_vip($user);
    }
}

if (!function_exists('bm_watch_party_random_code')) {
    function bm_watch_party_random_code(int $bytes = 24): string
    {
        return rtrim(strtr(base64_encode(random_bytes($bytes)), '+/', '-_'), '=');
    }
}

if (!function_exists('bm_watch_party_normalize_code')) {
    function bm_watch_party_normalize_code(string $code): string
    {
        $code = trim($code);
        return preg_match('/^[A-Za-z0-9_-]{24,96}$/', $code) ? $code : '';
    }
}

if (!function_exists('bm_watch_party_code_hash')) {
    function bm_watch_party_code_hash(string $code): string
    {
        return hash('sha256', $code);
    }
}

if (!function_exists('bm_watch_party_clean_source_ref')) {
    function bm_watch_party_clean_source_ref(string $sourceRef): string
    {
        $sourceRef = trim($sourceRef);
        if ($sourceRef === '') return '';
        // A source fingerprint/key is allowed; a direct stream/download URL is never persisted.
        if (preg_match('~^(?:https?:)?//~i', $sourceRef) || str_contains($sourceRef, '://')) return '';
        if (!preg_match('/^[A-Za-z0-9._:@|\/-]{1,190}$/', $sourceRef)) return '';
        return $sourceRef;
    }
}

if (!function_exists('bm_watch_party_clean_content_title')) {
    function bm_watch_party_clean_content_title(string $title): string
    {
        $title = trim(strip_tags($title));
        $title = preg_replace('/\s+/u', ' ', $title) ?? $title;
        if ($title === '') return '';
        return function_exists('mb_substr') ? mb_substr($title, 0, 190, 'UTF-8') : substr($title, 0, 190);
    }
}

if (!function_exists('bm_watch_party_clean_poster_url')) {
    function bm_watch_party_clean_poster_url(string $url): string
    {
        $url = trim($url);
        if ($url === '' || strlen($url) > 600 || str_contains($url, "\0")) return '';
        if (str_starts_with($url, '/')) {
            if (str_starts_with($url, '//') || str_contains($url, '..')) return '';
            return $url;
        }
        if (!filter_var($url, FILTER_VALIDATE_URL)) return '';
        $parts = parse_url($url);
        if (!is_array($parts)) return '';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        if (!in_array($scheme, ['http', 'https'], true)) return '';
        if (!empty($parts['user']) || !empty($parts['pass'])) return '';
        return $url;
    }
}

if (!function_exists('bm_watch_party_clean_theme')) {
    function bm_watch_party_clean_theme(string $theme): string
    {
        $theme = strtolower(trim($theme));
        return in_array($theme, ['default', 'romantic_hearts', 'galaxy_nova', 'starlight', 'aurora'], true) ? $theme : 'default';
    }
}

if (!function_exists('bm_watch_party_clean_background')) {
    function bm_watch_party_clean_background(string $background): string
    {
        $background = strtolower(trim($background));
        if (function_exists('bm_user_background_is_valid') && bm_user_background_is_valid($background)) return $background;
        return in_array($background, ['simple','purple_dream','teal_mist','golden','forest','pink_cloud','interstellar','pony','pizza','darkness','romantic_hearts','galaxy_nova','starlight','aurora'], true) ? $background : 'simple';
    }
}

if (!function_exists('bm_watch_party_clean_shared_url')) {
    function bm_watch_party_clean_shared_url(string $url): string
    {
        $url = trim($url);
        if ($url === '' || strlen($url) > 4096) return '';
        if (!filter_var($url, FILTER_VALIDATE_URL)) return '';
        $parts = parse_url($url);
        if (!is_array($parts)) return '';
        $scheme = strtolower((string)($parts['scheme'] ?? ''));
        if (!in_array($scheme, ['http', 'https'], true)) return '';
        if (!empty($parts['user']) || !empty($parts['pass'])) return '';
        return $url;
    }
}

if (!function_exists('bm_watch_party_clean_subtitle_url')) {
    function bm_watch_party_clean_subtitle_url(string $url): string
    {
        // Subtitle URLs follow the same private-room rules as the direct stream.
        // The actual proxy endpoints still enforce plain subtitle content.
        return bm_watch_party_clean_shared_url($url);
    }
}

if (!function_exists('bm_watch_party_cleanup_expired')) {
    function bm_watch_party_cleanup_expired(PDO $pdo, int $limit = 1000): array
    {
        bm_watch_party_schema($pdo);
        $limit = max(1, min(5000, $limit));
        $deleted = 0;
        $expiredVipUsers = 0;
        try {
            // Child rows disappear through ON DELETE CASCADE, including all messages and state.
            // Do not hard-delete from a single DB clock comparison. Inspect only
            // expiry candidates, resolve both stored clocks in PHP, then delete.
            $nowEpoch = time();
            $candidateStmt = $pdo->prepare("SELECT id,created_at,expires_at,expires_at_epoch
                FROM watch_party_rooms
                WHERE (expires_at_epoch>0 AND expires_at_epoch<=?) OR expires_at<=NOW()
                ORDER BY id ASC LIMIT {$limit}");
            $candidateStmt->execute([$nowEpoch]);
            foreach (($candidateStmt->fetchAll(PDO::FETCH_ASSOC) ?: []) as $candidateRoom) {
                $resolvedEpoch = bm_watch_party_expiry_epoch($candidateRoom);
                $storedEpoch = max(0, (int)($candidateRoom['expires_at_epoch'] ?? 0));
                if ($resolvedEpoch > $nowEpoch) {
                    if ($resolvedEpoch !== $storedEpoch) {
                        $repair = $pdo->prepare('UPDATE watch_party_rooms SET expires_at_epoch=? WHERE id=?');
                        $repair->execute([$resolvedEpoch, (int)$candidateRoom['id']]);
                    }
                    continue;
                }
                $delete = $pdo->prepare('DELETE FROM watch_party_rooms WHERE id=?');
                $delete->execute([(int)$candidateRoom['id']]);
                $deleted += $delete->rowCount();
            }
            // Time-limited VIP access is revoked automatically; permanent VIP has a NULL expiry.
            if (bm_watch_party_user_vip_schema($pdo)) {
                $historyReady = function_exists('bm_vip_ensure_history_columns') && bm_vip_ensure_history_columns($pdo);
                $vipSql = $historyReady
                    ? "UPDATE users SET vip_last_expires_at=vip_expires_at,role='user',vip_expires_at=NULL WHERE LOWER(role) IN ('vip','premium','special') AND vip_expires_at IS NOT NULL AND vip_expires_at<=NOW() LIMIT {$limit}"
                    : "UPDATE users SET role='user',vip_expires_at=NULL WHERE LOWER(role) IN ('vip','premium','special') AND vip_expires_at IS NOT NULL AND vip_expires_at<=NOW() LIMIT {$limit}";
                $vipStmt = $pdo->prepare($vipSql);
                $vipStmt->execute();
                $expiredVipUsers = $vipStmt->rowCount();
            }
        } catch (Throwable $e) {
            error_log('Watch Party cleanup error: ' . $e->getMessage());
        }
        return ['rooms_deleted' => $deleted, 'vip_users_expired' => $expiredVipUsers, 'ran_at' => date('c')];
    }
}

if (!function_exists('bm_watch_party_housekeeping_maybe')) {
    function bm_watch_party_housekeeping_maybe(PDO $pdo): void
    {
        try {
            bm_watch_party_schema($pdo);
            $path = function_exists('bm_security_private_path')
                ? bm_security_private_path('watch-party-housekeeping.time')
                : (sys_get_temp_dir() . '/bankmovie-watch-party-housekeeping.time');
            $intervalMinutes = function_exists('bm_site_get') ? (int)bm_site_get('watch_party_cleanup_interval_minutes', 1) : 5;
            $intervalSeconds = max(60, min(900, $intervalMinutes * 60));
            $last = is_file($path) ? (int)@file_get_contents($path) : 0;
            if ($last > 0 && (time() - $last) < $intervalSeconds) return;

            $lock = @fopen($path . '.lock', 'c+');
            if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) {
                if (is_resource($lock)) @fclose($lock);
                return;
            }
            clearstatcache(true, $path);
            $last = is_file($path) ? (int)@file_get_contents($path) : 0;
            if ($last <= 0 || (time() - $last) >= $intervalSeconds) {
                bm_watch_party_cleanup_expired($pdo, 1000);
                @file_put_contents($path, (string)time(), LOCK_EX);
                @chmod($path, 0600);
            }
            @flock($lock, LOCK_UN);
            @fclose($lock);
        } catch (Throwable $e) {
            error_log('Watch Party housekeeping error: ' . $e->getMessage());
        }
    }
}

if (!function_exists('bm_watch_party_find_room')) {
    function bm_watch_party_find_room(PDO $pdo, string $code, bool $includeExpired = false): ?array
    {
        bm_watch_party_prepare_connection($pdo);
        $code = bm_watch_party_normalize_code($code);
        if ($code === '') return null;
        $hash = bm_watch_party_code_hash($code);
        try {
            $stmt = $pdo->prepare('SELECT r.*
                FROM watch_party_rooms r
                LEFT JOIN watch_party_room_codes c ON c.room_id=r.id AND c.room_code_hash=?
                WHERE r.room_code_hash=? OR c.room_code_hash=?
                ORDER BY (r.room_code_hash=?) DESC
                LIMIT 1');
            $stmt->execute([$hash, $hash, $hash, $hash]);
        } catch (Throwable $e) {
            // Safe fallback while an older installation is completing the automatic schema upgrade.
            $stmt = $pdo->prepare('SELECT * FROM watch_party_rooms WHERE room_code_hash=? LIMIT 1');
            $stmt->execute([$hash]);
        }
        $room = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($room)) {
            $GLOBALS['bm_watch_party_room_lookup_reason'] = 'not_found';
            return null;
        }

        $nowEpoch = time();
        $storedEpoch = max(0, (int)($room['expires_at_epoch'] ?? 0));
        $expiryEpoch = bm_watch_party_expiry_epoch($room);
        $expired = $expiryEpoch <= 0 || $expiryEpoch <= $nowEpoch;
        if ($expired && !$includeExpired) {
            $GLOBALS['bm_watch_party_room_lookup_reason'] = 'expired';
            // Strict access boundary: only a room confirmed expired by the unified
            // resolver is destroyed here.
            $delete = $pdo->prepare('DELETE FROM watch_party_rooms WHERE id=?');
            $delete->execute([(int)$room['id']]);
            return null;
        }
        if ($expiryEpoch > $nowEpoch && $expiryEpoch !== $storedEpoch) {
            try {
                $repair = $pdo->prepare('UPDATE watch_party_rooms SET expires_at_epoch=? WHERE id=?');
                $repair->execute([$expiryEpoch, (int)$room['id']]);
            } catch (Throwable $e) { /* the resolved in-memory value is enough for this request */ }
        }
        $GLOBALS['bm_watch_party_room_lookup_reason'] = 'active';
        $room['expires_at_epoch'] = $expiryEpoch;
        $room['seconds_left'] = max(0, $expiryEpoch - $nowEpoch);
        return $room;
    }
}

if (!function_exists('bm_watch_party_member')) {
    function bm_watch_party_member(PDO $pdo, int $roomId, int $userId): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM watch_party_members WHERE room_id=? AND user_id=? LIMIT 1');
        $stmt->execute([$roomId, $userId]);
        $member = $stmt->fetch(PDO::FETCH_ASSOC);
        return is_array($member) ? $member : null;
    }
}

if (!function_exists('bm_watch_party_member_for_actor')) {
    function bm_watch_party_member_for_actor(PDO $pdo, int $roomId, array $user): ?array
    {
        if (bm_watch_party_actor_is_guest($user)) {
            $guestHash = bm_watch_party_actor_guest_hash($user);
            if ($guestHash === '') return null;
            $stmt = $pdo->prepare('SELECT * FROM watch_party_members WHERE room_id=? AND user_id=0 AND guest_token_hash=? LIMIT 1');
            $stmt->execute([$roomId, $guestHash]);
            $member = $stmt->fetch(PDO::FETCH_ASSOC);
            return is_array($member) ? $member : null;
        }
        return bm_watch_party_member($pdo, $roomId, (int)($user['id'] ?? 0));
    }
}

if (!function_exists('bm_watch_party_require_member')) {
    function bm_watch_party_require_member(PDO $pdo, array $room, array $user): array
    {
        $member = bm_watch_party_member_for_actor($pdo, (int)$room['id'], $user);
        if (!$member) throw new RuntimeException('not_room_member', 403);
        $pdo->prepare('UPDATE watch_party_members SET last_seen_at=NOW() WHERE id=?')->execute([(int)$member['id']]);
        return $member;
    }
}

if (!function_exists('bm_watch_party_issue_room_alias')) {
    function bm_watch_party_issue_room_alias(PDO $pdo, int $roomId): string
    {
        if ($roomId <= 0) throw new RuntimeException('room_not_found_or_expired', 404);
        for ($attempt = 0; $attempt < 8; $attempt++) {
            $code = bm_watch_party_random_code();
            try {
                $stmt = $pdo->prepare('INSERT INTO watch_party_room_codes(room_id,room_code_hash,created_at) VALUES(?,?,NOW())');
                $stmt->execute([$roomId, bm_watch_party_code_hash($code)]);
                // Keep aliases bounded. The original code in watch_party_rooms is never removed.
                try {
                    $trim = $pdo->prepare('DELETE FROM watch_party_room_codes WHERE room_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM watch_party_room_codes WHERE room_id=? ORDER BY id DESC LIMIT 8) keep_codes)');
                    $trim->execute([$roomId, $roomId]);
                } catch (Throwable $trimError) {
                    // Alias creation is authoritative; cleanup is only a bounded-size optimization.
                }
                return $code;
            } catch (PDOException $e) {
                if ((int)($e->errorInfo[1] ?? 0) === 1062) continue;
                throw $e;
            }
        }
        throw new RuntimeException('room_code_generation_failed', 500);
    }
}

if (!function_exists('bm_watch_party_remember_host_code')) {
    function bm_watch_party_remember_host_code(int $roomId, string $code): void
    {
        if ($roomId <= 0 || $code === '' || session_status() !== PHP_SESSION_ACTIVE) return;
        if (!isset($_SESSION['bm_watch_party_host_codes']) || !is_array($_SESSION['bm_watch_party_host_codes'])) {
            $_SESSION['bm_watch_party_host_codes'] = [];
        }
        $_SESSION['bm_watch_party_host_codes'][(string)$roomId] = $code;
        if (count($_SESSION['bm_watch_party_host_codes']) > 12) {
            $_SESSION['bm_watch_party_host_codes'] = array_slice($_SESSION['bm_watch_party_host_codes'], -12, null, true);
        }
    }
}

if (!function_exists('bm_watch_party_start_or_reuse_room')) {
    function bm_watch_party_start_or_reuse_room(PDO $pdo, array $user, array $input): array
    {
        if (!bm_watch_party_schema($pdo)) throw new RuntimeException('watch_party_schema_unavailable', 503);
        bm_watch_party_cleanup_expired($pdo, 300);

        $userId = max(0, (int)($user['id'] ?? 0));
        if ($userId <= 0) throw new RuntimeException('vip_required', 403);
        $movieId = max(0, (int)($input['movie_id'] ?? 0));
        $archiveNo = max(1, min(9, (int)($input['archive_no'] ?? 1)));
        $mediaType = strtolower(trim((string)($input['media_type'] ?? 'movie')));
        if (!in_array($mediaType, ['movie','series','episode'], true)) $mediaType = 'movie';
        $sourceRef = bm_watch_party_clean_source_ref((string)($input['source_ref'] ?? ''));
        $preferredRoomCode = bm_watch_party_normalize_code((string)($input['room_code'] ?? ''));
        $sourceUrl = bm_watch_party_clean_shared_url((string)($input['source_url'] ?? ''));
        $subtitleUrl = bm_watch_party_clean_subtitle_url((string)($input['subtitle_url'] ?? ''));
        $contentTitle = bm_watch_party_clean_content_title((string)($input['content_title'] ?? ''));
        $posterUrl = bm_watch_party_clean_poster_url((string)($input['poster_url'] ?? ''));
        if ($sourceUrl === '') throw new RuntimeException('invalid_source_url', 422);

        $nowEpoch = time();
        $stmt = $pdo->prepare('SELECT * FROM watch_party_rooms
            WHERE host_user_id=? AND ((expires_at_epoch>0 AND expires_at_epoch>?) OR expires_at>NOW())
            ORDER BY last_activity_at DESC,id DESC LIMIT 1');
        $stmt->execute([$userId, $nowEpoch]);
        $room = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!is_array($room)) {
            $created = bm_watch_party_create_room($pdo, $user, [
                'movie_id'=>$movieId,
                'archive_no'=>$archiveNo,
                'media_type'=>$mediaType,
                'source_ref'=>$sourceRef,
                'source_url'=>$sourceUrl,
                'subtitle_url'=>$subtitleUrl,
                'content_title'=>$contentTitle,
                'poster_url'=>$posterUrl,
            ]);
            bm_watch_party_remember_host_code((int)$created['room_id'], (string)$created['invite_code']);
            $created['reused'] = false;
            return $created;
        }

        $roomId = (int)$room['id'];
        $pdo->beginTransaction();
        try {
            $lock = $pdo->prepare('SELECT id,expires_at,expires_at_epoch,max_members FROM watch_party_rooms WHERE id=? AND host_user_id=? FOR UPDATE');
            $lock->execute([$roomId, $userId]);
            $locked = $lock->fetch(PDO::FETCH_ASSOC);
            if (!is_array($locked) || bm_watch_party_expiry_epoch($locked) <= time()) {
                throw new RuntimeException('room_not_found_or_expired', 404);
            }

            $pdo->prepare("INSERT INTO watch_party_members(room_id,user_id,member_role,joined_at,last_seen_at)
                VALUES(?,?,'host',NOW(),NOW())
                ON DUPLICATE KEY UPDATE member_role='host',last_seen_at=NOW()")
                ->execute([$roomId,$userId]);

            $pdo->prepare("UPDATE watch_party_rooms SET movie_id=?,archive_no=?,media_type=?,source_ref=?,shared_source_url=?,shared_subtitle_url=?,source_updated_at=NOW(),content_title=?,poster_url=?,status=CASE WHEN status='closed' THEN 'waiting' ELSE status END,last_activity_at=NOW() WHERE id=?")
                ->execute([$movieId>0?$movieId:null,$archiveNo,$mediaType,$sourceRef!==''?$sourceRef:null,$sourceUrl,$subtitleUrl!==''?$subtitleUrl:null,$contentTitle!==''?$contentTitle:null,$posterUrl!==''?$posterUrl:null,$roomId]);

            $stateStmt = $pdo->prepare('SELECT sequence_no FROM watch_party_state WHERE room_id=? FOR UPDATE');
            $stateStmt->execute([$roomId]);
            $sequence = (int)$stateStmt->fetchColumn() + 1;
            $updatedAtMs = (int)floor(microtime(true)*1000);
            $pdo->prepare('UPDATE watch_party_state SET sequence_no=?,position_seconds=0,is_paused=1,playback_rate=1,buffering=0,updated_by=?,updated_at_ms=?,updated_at=NOW() WHERE room_id=?')
                ->execute([$sequence,$userId,$updatedAtMs,$roomId]);
            $payload = json_encode(['current_time'=>0,'paused'=>true,'source_changed'=>true,'updated_at_ms'=>$updatedAtMs], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $pdo->prepare("INSERT INTO watch_party_events(room_id,user_id,event_type,sequence_no,payload_json,created_at) VALUES(?,?,'source_change',?,?,NOW())")
                ->execute([$roomId,$userId,$sequence,$payload]);

            $code = '';
            if ($preferredRoomCode !== '') {
                $preferredRoom = bm_watch_party_find_room($pdo, $preferredRoomCode);
                if (is_array($preferredRoom) && (int)($preferredRoom['id'] ?? 0) === $roomId && (int)($preferredRoom['host_user_id'] ?? 0) === $userId) {
                    $code = $preferredRoomCode;
                }
            }
            if ($code === '') $code = bm_watch_party_issue_room_alias($pdo,$roomId);
            $pdo->commit();
            bm_watch_party_remember_host_code($roomId,$code);
            $expiryEpoch = bm_watch_party_expiry_epoch($locked);
            return [
                'room_id'=>$roomId,
                'invite_code'=>$code,
                'expires_at'=>(string)$locked['expires_at'],
                'expires_at_epoch'=>$expiryEpoch,
                'seconds_left'=>max(0,$expiryEpoch-time()),
                'max_members'=>(int)$locked['max_members'],
                'direct_stream_url_stored'=>true,
                'reused'=>true,
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_create_room')) {
    function bm_watch_party_create_room(PDO $pdo, array $user, array $input): array
    {
        if (!bm_watch_party_schema($pdo)) throw new RuntimeException('watch_party_schema_unavailable', 503);
        bm_watch_party_cleanup_expired($pdo, 200);

        $movieId = max(0, (int)($input['movie_id'] ?? 0));
        $archiveNo = max(1, min(9, (int)($input['archive_no'] ?? 1)));
        $mediaType = strtolower(trim((string)($input['media_type'] ?? 'movie')));
        if (!in_array($mediaType, ['movie', 'series', 'episode'], true)) $mediaType = 'movie';
        $sourceRef = bm_watch_party_clean_source_ref((string)($input['source_ref'] ?? ''));
        $sharedSourceUrl = bm_watch_party_clean_shared_url((string)($input['source_url'] ?? ''));
        $sharedSubtitleUrl = bm_watch_party_clean_subtitle_url((string)($input['subtitle_url'] ?? ''));
        $contentTitle = bm_watch_party_clean_content_title((string)($input['content_title'] ?? ''));
        $posterUrl = bm_watch_party_clean_poster_url((string)($input['poster_url'] ?? ''));
        $roomBackground = function_exists('bm_user_background_resolve') ? bm_user_background_resolve($user) : 'simple';
        $roomBackground = bm_watch_party_clean_background($roomBackground);
        $maxMembers = bm_watch_party_max_members();
        $expiresEpoch = time() + (bm_watch_party_max_hours() * 3600);
        $expiresAt = date('Y-m-d H:i:s', $expiresEpoch);

        // The hidden admin laboratory always starts with a clean room. This avoids
        // stale preview rooms blocking the Create button while normal VIP rooms keep
        // the standard two-room safety limit.
        if (!empty($input['replace_existing']) && bm_watch_party_is_admin($user)) {
            $pdo->prepare('DELETE FROM watch_party_rooms WHERE host_user_id=?')->execute([(int)$user['id']]);
        }

        $nowEpoch = time();
        $activeCountStmt = $pdo->prepare('SELECT COUNT(*) FROM watch_party_rooms WHERE host_user_id=? AND ((expires_at_epoch>0 AND expires_at_epoch>?) OR expires_at>NOW())');
        $activeCountStmt->execute([(int)$user['id'], $nowEpoch]);
        if ((int)$activeCountStmt->fetchColumn() >= 2) {
            throw new RuntimeException('too_many_active_rooms', 409);
        }

        for ($attempt = 0; $attempt < 5; $attempt++) {
            $code = bm_watch_party_random_code();
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare('INSERT INTO watch_party_rooms
                    (room_code_hash,host_user_id,movie_id,archive_no,media_type,source_ref,shared_source_url,shared_subtitle_url,source_updated_at,content_title,poster_url,theme_key,background_key,countdown_seconds,start_at_seconds,scheduled_start_at_ms,scheduled_start_token,status,max_members,created_at,expires_at,expires_at_epoch,last_activity_at)
                    VALUES(?,?,?,?,?,?,?,?,IF(? IS NULL,NULL,NOW()),?,?,\'default\',?,10,0,0,0,\'waiting\',?,NOW(),?,?,NOW())');
                $stmt->execute([
                    bm_watch_party_code_hash($code),
                    (int)$user['id'],
                    $movieId > 0 ? $movieId : null,
                    $archiveNo,
                    $mediaType,
                    $sourceRef !== '' ? $sourceRef : null,
                    $sharedSourceUrl !== '' ? $sharedSourceUrl : null,
                    $sharedSubtitleUrl !== '' ? $sharedSubtitleUrl : null,
                    $sharedSourceUrl !== '' ? $sharedSourceUrl : null,
                    $contentTitle !== '' ? $contentTitle : null,
                    $posterUrl !== '' ? $posterUrl : null,
                    $roomBackground,
                    $maxMembers,
                    $expiresAt,
                    $expiresEpoch,
                ]);
                $roomId = (int)$pdo->lastInsertId();
                $pdo->prepare("INSERT INTO watch_party_members(room_id,user_id,member_role,joined_at,last_seen_at) VALUES(?,?,'host',NOW(),NOW())")
                    ->execute([$roomId, (int)$user['id']]);
                $createdAtMs = (int)floor(microtime(true) * 1000);
                $pdo->prepare('INSERT INTO watch_party_state(room_id,sequence_no,position_seconds,is_paused,playback_rate,buffering,updated_by,updated_at_ms,updated_at) VALUES(?,0,0,1,1,0,?,?,NOW())')
                    ->execute([$roomId, (int)$user['id'], $createdAtMs]);
                $pdo->commit();
                bm_watch_party_remember_host_code($roomId, $code);
                return [
                    'room_id' => $roomId,
                    'invite_code' => $code,
                    'expires_at' => $expiresAt,
                    'expires_at_epoch' => $expiresEpoch,
                    'seconds_left' => max(0, $expiresEpoch - time()),
                    'background_key' => $roomBackground,
                    'max_members' => $maxMembers,
                    'direct_stream_url_stored' => $sharedSourceUrl !== '',
                ];
            } catch (PDOException $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                if ((int)($e->errorInfo[1] ?? 0) === 1062) continue;
                throw $e;
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                throw $e;
            }
        }
        throw new RuntimeException('room_code_generation_failed', 500);
    }
}

if (!function_exists('bm_watch_party_join_room')) {
    function bm_watch_party_join_room(PDO $pdo, array $user, string $code): array
    {
        bm_watch_party_cleanup_expired($pdo, 200);
        $room = bm_watch_party_find_room($pdo, $code);
        if (!$room) {
            $reason = (string)($GLOBALS['bm_watch_party_room_lookup_reason'] ?? 'not_found');
            throw new RuntimeException($reason === 'expired' ? 'room_expired' : 'room_not_found', 404);
        }

        $roomId = (int)$room['id'];
        $isGuest = bm_watch_party_actor_is_guest($user);
        $userId = $isGuest ? 0 : (int)($user['id'] ?? 0);
        if (!$isGuest && $userId <= 0) throw new RuntimeException('not_room_member', 403);
        $guestHash = $isGuest ? bm_watch_party_actor_guest_hash($user) : '';
        if ($isGuest && $guestHash === '') throw new RuntimeException('not_room_member', 403);

        $existing = bm_watch_party_member_for_actor($pdo, $roomId, $user);
        if ($existing) {
            $pdo->prepare('UPDATE watch_party_members SET last_seen_at=NOW() WHERE id=?')->execute([(int)$existing['id']]);
            return ['room_id' => $roomId, 'member_role' => (string)$existing['member_role'], 'expires_at' => $room['expires_at'], 'expires_at_epoch' => bm_watch_party_expiry_epoch($room), 'seconds_left' => max(0, bm_watch_party_expiry_epoch($room)-time()), 'guest_access' => $isGuest];
        }

        $pdo->beginTransaction();
        try {
            $nowEpoch = time();
            $lock = $pdo->prepare('SELECT id,max_members,created_at,expires_at,expires_at_epoch FROM watch_party_rooms WHERE id=? AND ((expires_at_epoch>0 AND expires_at_epoch>?) OR expires_at>NOW()) FOR UPDATE');
            $lock->execute([$roomId, $nowEpoch]);
            $lockedRoom = $lock->fetch(PDO::FETCH_ASSOC);
            if (!$lockedRoom) throw new RuntimeException('room_not_found_or_expired', 404);

            $count = $pdo->prepare('SELECT COUNT(*) FROM watch_party_members WHERE room_id=?');
            $count->execute([$roomId]);
            if ((int)$count->fetchColumn() >= (int)$lockedRoom['max_members']) {
                throw new RuntimeException('room_is_full', 409);
            }

            if ($isGuest) {
                // Only one anonymous companion is allowed in a two-person room.
                $anonymous = $pdo->prepare('SELECT id FROM watch_party_members WHERE room_id=? AND user_id=0 LIMIT 1');
                $anonymous->execute([$roomId]);
                if ($anonymous->fetchColumn()) throw new RuntimeException('room_is_full', 409);
                $guestName = trim((string)($user['username'] ?? 'همراه مهمان'));
                if (function_exists('mb_substr')) $guestName = mb_substr($guestName, 0, 80, 'UTF-8');
                else $guestName = substr($guestName, 0, 80);
                $guestAvatar = trim((string)($user['avatar'] ?? ''));
                $pdo->prepare("INSERT INTO watch_party_members(room_id,user_id,guest_token_hash,guest_name,guest_avatar,member_role,joined_at,last_seen_at) VALUES(?,0,?,?,?,'guest',NOW(),NOW())")
                    ->execute([$roomId, $guestHash, $guestName, $guestAvatar !== '' ? $guestAvatar : null]);
            } else {
                $pdo->prepare("INSERT INTO watch_party_members(room_id,user_id,member_role,joined_at,last_seen_at) VALUES(?,?,'guest',NOW(),NOW())")
                    ->execute([$roomId, $userId]);
            }
            $pdo->prepare("UPDATE watch_party_rooms SET status='active',last_activity_at=NOW() WHERE id=?")->execute([$roomId]);
            $pdo->commit();
            return ['room_id' => $roomId, 'member_role' => 'guest', 'expires_at' => $lockedRoom['expires_at'], 'expires_at_epoch' => bm_watch_party_expiry_epoch($lockedRoom), 'seconds_left' => max(0, bm_watch_party_expiry_epoch($lockedRoom)-time()), 'guest_access' => $isGuest];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_update_state')) {
    function bm_watch_party_update_state(PDO $pdo, array $room, array $user, array $member, array $input): array
    {
        if ((string)($member['member_role'] ?? '') !== 'host' && !bm_watch_party_is_admin($user)) {
            throw new RuntimeException('host_control_only', 403);
        }

        $event = strtolower(trim((string)($input['event'] ?? 'state')));
        if (!in_array($event, ['play', 'pause', 'seek', 'state', 'buffering', 'source_change'], true)) {
            throw new RuntimeException('invalid_event', 422);
        }
        $currentTime = (float)($input['current_time'] ?? 0);
        $currentTime = max(0.0, min(172800.0, $currentTime));
        $paused = !empty($input['paused']) ? 1 : 0;
        if ($event === 'play') $paused = 0;
        if ($event === 'pause') $paused = 1;
        $rate = (float)($input['playback_rate'] ?? 1);
        $rate = max(0.5, min(2.0, $rate));
        $buffering = !empty($input['buffering']) ? 1 : 0;
        $sourceRef = bm_watch_party_clean_source_ref((string)($input['source_ref'] ?? ''));
        $rawSharedSourceUrl = trim((string)($input['source_url'] ?? ''));
        $sharedSourceUrl = bm_watch_party_clean_shared_url($rawSharedSourceUrl);
        $rawSharedSubtitleUrl = trim((string)($input['subtitle_url'] ?? ''));
        $sharedSubtitleUrl = bm_watch_party_clean_subtitle_url($rawSharedSubtitleUrl);
        if ($event === 'source_change' && $rawSharedSourceUrl !== '' && $sharedSourceUrl === '') {
            throw new RuntimeException('invalid_source_url', 422);
        }
        if ($event === 'source_change' && $rawSharedSubtitleUrl !== '' && $sharedSubtitleUrl === '') {
            throw new RuntimeException('invalid_subtitle_url', 422);
        }

        $pdo->beginTransaction();
        try {
            $lock = $pdo->prepare('SELECT sequence_no FROM watch_party_state WHERE room_id=? FOR UPDATE');
            $lock->execute([(int)$room['id']]);
            $sequence = (int)$lock->fetchColumn() + 1;
            $updatedAtMs = (int)floor(microtime(true) * 1000);
            $pdo->prepare('UPDATE watch_party_state SET sequence_no=?,position_seconds=?,is_paused=?,playback_rate=?,buffering=?,updated_by=?,updated_at_ms=?,updated_at=NOW() WHERE room_id=?')
                ->execute([$sequence, $currentTime, $paused, $rate, $buffering, (int)$user['id'], $updatedAtMs, (int)$room['id']]);
            if ($event === 'source_change') {
                $pdo->prepare('UPDATE watch_party_rooms SET source_ref=?,shared_source_url=?,shared_subtitle_url=?,source_updated_at=NOW(),last_activity_at=NOW() WHERE id=?')
                    ->execute([
                        $sourceRef !== '' ? $sourceRef : null,
                        $sharedSourceUrl !== '' ? $sharedSourceUrl : null,
                        $sharedSubtitleUrl !== '' ? $sharedSubtitleUrl : null,
                        (int)$room['id'],
                    ]);
            } else {
                $pdo->prepare('UPDATE watch_party_rooms SET last_activity_at=NOW() WHERE id=?')->execute([(int)$room['id']]);
            }
            $payload = json_encode([
                'current_time' => $currentTime,
                'paused' => (bool)$paused,
                'playback_rate' => $rate,
                'buffering' => (bool)$buffering,
                'source_ref' => $sourceRef !== '' ? $sourceRef : null,
                'source_changed' => $event === 'source_change' && $sharedSourceUrl !== '',
                'subtitle_changed' => $event === 'source_change',
                'updated_at_ms' => $updatedAtMs,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            // Heartbeats only refresh the compact state row. User actions remain in
            // the event log so the database does not receive thousands of needless rows.
            if ($event !== 'state') {
                $pdo->prepare('INSERT INTO watch_party_events(room_id,user_id,event_type,sequence_no,payload_json,created_at) VALUES(?,?,?,?,?,NOW())')
                    ->execute([(int)$room['id'], (int)$user['id'], $event, $sequence, $payload]);

                // Keep only a compact rolling event window. Chat has its own separate limit.
                $pdo->prepare('DELETE FROM watch_party_events WHERE room_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM watch_party_events WHERE room_id=? ORDER BY id DESC LIMIT 300) recent)')
                    ->execute([(int)$room['id'], (int)$room['id']]);
            }
            $pdo->commit();
            return [
                'sequence_no' => $sequence,
                'current_time' => $currentTime,
                'paused' => (bool)$paused,
                'playback_rate' => $rate,
                'buffering' => (bool)$buffering,
                'updated_at_ms' => $updatedAtMs,
                'server_time_ms' => (int)floor(microtime(true) * 1000),
                'updated_at' => date('c'),
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_update_room_settings')) {
    function bm_watch_party_update_room_settings(PDO $pdo, array $room, array $user, array $member, array $input): array
    {
        if ((string)($member['member_role'] ?? '') !== 'host' && !bm_watch_party_is_admin($user)) {
            throw new RuntimeException('host_control_only', 403);
        }
        $theme = bm_watch_party_clean_theme((string)($input['theme_key'] ?? ($room['theme_key'] ?? 'default')));
        $background = bm_watch_party_clean_background((string)($input['background_key'] ?? ($room['background_key'] ?? 'simple')));
        if (!bm_watch_party_is_vip($user)) $background = 'simple';
        $countdown = max(3, min(60, (int)($input['countdown_seconds'] ?? ($room['countdown_seconds'] ?? 10))));
        $startAt = max(0.0, min(172800.0, (float)($input['start_at_seconds'] ?? ($room['start_at_seconds'] ?? 0))));
        $title = bm_watch_party_clean_content_title((string)($input['content_title'] ?? ($room['content_title'] ?? '')));
        $poster = bm_watch_party_clean_poster_url((string)($input['poster_url'] ?? ($room['poster_url'] ?? '')));
        $pdo->prepare('UPDATE watch_party_rooms SET theme_key=?,background_key=?,countdown_seconds=?,start_at_seconds=?,content_title=?,poster_url=?,last_activity_at=NOW() WHERE id=?')
            ->execute([$theme, $background, $countdown, $startAt, $title !== '' ? $title : null, $poster !== '' ? $poster : null, (int)$room['id']]);
        return [
            'theme_key' => $theme,
            'background_key' => $background,
            'countdown_seconds' => $countdown,
            'start_at_seconds' => $startAt,
            'content_title' => $title,
            'poster_url' => $poster,
            'max_members' => (int)($room['max_members'] ?? bm_watch_party_max_members()),
        ];
    }
}

if (!function_exists('bm_watch_party_schedule_start')) {
    function bm_watch_party_schedule_start(PDO $pdo, array $room, array $user, array $member, array $input): array
    {
        if ((string)($member['member_role'] ?? '') !== 'host' && !bm_watch_party_is_admin($user)) {
            throw new RuntimeException('host_control_only', 403);
        }
        $countdown = max(3, min(60, (int)($input['countdown_seconds'] ?? ($room['countdown_seconds'] ?? 10))));
        $target = max(0.0, min(172800.0, (float)($input['start_at_seconds'] ?? ($room['start_at_seconds'] ?? 0))));
        $executeAtMs = (int)floor(microtime(true) * 1000) + ($countdown * 1000);

        $pdo->beginTransaction();
        try {
            $roomLock = $pdo->prepare('SELECT scheduled_start_token FROM watch_party_rooms WHERE id=? FOR UPDATE');
            $roomLock->execute([(int)$room['id']]);
            $token = (int)$roomLock->fetchColumn() + 1;

            $stateLock = $pdo->prepare('SELECT sequence_no FROM watch_party_state WHERE room_id=? FOR UPDATE');
            $stateLock->execute([(int)$room['id']]);
            $sequence = (int)$stateLock->fetchColumn() + 1;
            $nowMs = (int)floor(microtime(true) * 1000);

            $pdo->prepare('UPDATE watch_party_rooms SET countdown_seconds=?,start_at_seconds=?,scheduled_start_at_ms=?,scheduled_start_token=?,last_activity_at=NOW() WHERE id=?')
                ->execute([$countdown, $target, $executeAtMs, $token, (int)$room['id']]);
            $pdo->prepare('UPDATE watch_party_state SET sequence_no=?,position_seconds=?,is_paused=1,buffering=0,updated_by=?,updated_at_ms=?,updated_at=NOW() WHERE room_id=?')
                ->execute([$sequence, $target, (int)$user['id'], $nowMs, (int)$room['id']]);
            $payload = json_encode([
                'countdown_seconds' => $countdown,
                'start_at_seconds' => $target,
                'execute_at_ms' => $executeAtMs,
                'scheduled_start_token' => $token,
                'updated_at_ms' => $nowMs,
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            $pdo->prepare("INSERT INTO watch_party_events(room_id,user_id,event_type,sequence_no,payload_json,created_at) VALUES(?,?,'scheduled_start',?,?,NOW())")
                ->execute([(int)$room['id'], (int)$user['id'], $sequence, $payload]);
            $pdo->commit();
            return [
                'countdown_seconds' => $countdown,
                'start_at_seconds' => $target,
                'scheduled_start_at_ms' => $executeAtMs,
                'scheduled_start_token' => $token,
                'server_time_ms' => (int)floor(microtime(true) * 1000),
            ];
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
}

if (!function_exists('bm_watch_party_add_message')) {
    function bm_watch_party_add_message(PDO $pdo, array $room, array $user, string $message, string $clientMessageId = ''): array
    {
        if (!bm_watch_party_chat_enabled()) throw new RuntimeException('chat_disabled', 403);
        $message = trim(strip_tags($message));
        $message = preg_replace('/\s+/u', ' ', $message) ?? $message;
        if (function_exists('mb_substr')) $message = mb_substr($message, 0, 500, 'UTF-8');
        else $message = substr($message, 0, 500);
        if ($message === '') throw new RuntimeException('empty_message', 422);

        $clientMessageId = trim($clientMessageId);
        if ($clientMessageId !== '' && !preg_match('/^[A-Za-z0-9_-]{12,64}$/', $clientMessageId)) {
            $clientMessageId = '';
        }

        $roomId = (int)$room['id'];
        $isGuest = bm_watch_party_actor_is_guest($user);
        $userId = $isGuest ? 0 : (int)($user['id'] ?? 0);
        $guestHash = $isGuest ? bm_watch_party_actor_guest_hash($user) : '';

        // A retry of the same client-generated message id is a lookup, not a new
        // send. This makes offline retry safe and prevents duplicate stickers/text.
        if ($clientMessageId !== '') {
            $existing = $pdo->prepare('SELECT id,message,client_message_id,delivered_at,created_at FROM watch_party_messages WHERE room_id=? AND client_message_id=? LIMIT 1');
            $existing->execute([$roomId, $clientMessageId]);
            $row = $existing->fetch(PDO::FETCH_ASSOC);
            if (is_array($row)) {
                return [
                    'message_id' => (int)$row['id'],
                    'client_message_id' => (string)$row['client_message_id'],
                    'message' => (string)$row['message'],
                    'delivered' => !empty($row['delivered_at']),
                    'delivered_at' => $row['delivered_at'] ?: null,
                    'created_at' => (string)$row['created_at'],
                    'duplicate' => true,
                ];
            }
        }

        if ($isGuest) {
            $rate = $pdo->prepare('SELECT COUNT(*) FROM watch_party_messages WHERE room_id=? AND user_id=0 AND guest_token_hash=? AND created_at>=DATE_SUB(NOW(),INTERVAL 10 SECOND)');
            $rate->execute([$roomId, $guestHash]);
        } else {
            $rate = $pdo->prepare('SELECT COUNT(*) FROM watch_party_messages WHERE room_id=? AND user_id=? AND created_at>=DATE_SUB(NOW(),INTERVAL 10 SECOND)');
            $rate->execute([$roomId, $userId]);
        }
        if ((int)$rate->fetchColumn() >= 5) throw new RuntimeException('message_rate_limited', 429);

        try {
            if ($isGuest) {
                $guestName = trim((string)($user['username'] ?? 'همراه مهمان'));
                if (function_exists('mb_substr')) $guestName = mb_substr($guestName, 0, 80, 'UTF-8');
                else $guestName = substr($guestName, 0, 80);
                $guestAvatar = trim((string)($user['avatar'] ?? ''));
                $stmt = $pdo->prepare('INSERT INTO watch_party_messages(room_id,user_id,guest_token_hash,guest_name,guest_avatar,client_message_id,message,created_at) VALUES(?,0,?,?,?,?,?,NOW())');
                $stmt->execute([$roomId, $guestHash, $guestName, $guestAvatar !== '' ? $guestAvatar : null, $clientMessageId !== '' ? $clientMessageId : null, $message]);
            } else {
                $stmt = $pdo->prepare('INSERT INTO watch_party_messages(room_id,user_id,client_message_id,message,created_at) VALUES(?,?,?,?,NOW())');
                $stmt->execute([$roomId, $userId, $clientMessageId !== '' ? $clientMessageId : null, $message]);
            }
            $messageId = (int)$pdo->lastInsertId();
        } catch (Throwable $e) {
            // Unique client id can race when two retries arrive together. Return
            // the already accepted row instead of surfacing an error/duplicate.
            if ($clientMessageId !== '') {
                $existing = $pdo->prepare('SELECT id,message,client_message_id,delivered_at,created_at FROM watch_party_messages WHERE room_id=? AND client_message_id=? LIMIT 1');
                $existing->execute([$roomId, $clientMessageId]);
                $row = $existing->fetch(PDO::FETCH_ASSOC);
                if (is_array($row)) {
                    return [
                        'message_id' => (int)$row['id'],
                        'client_message_id' => (string)$row['client_message_id'],
                        'message' => (string)$row['message'],
                        'delivered' => !empty($row['delivered_at']),
                        'delivered_at' => $row['delivered_at'] ?: null,
                        'created_at' => (string)$row['created_at'],
                        'duplicate' => true,
                    ];
                }
            }
            throw $e;
        }

        $pdo->prepare('UPDATE watch_party_rooms SET last_activity_at=NOW() WHERE id=?')->execute([$roomId]);

        $limit = function_exists('bm_site_get') ? (int)bm_site_get('watch_party_message_limit', 500) : 500;
        $limit = max(50, min(500, $limit));
        $pdo->prepare("DELETE FROM watch_party_messages WHERE room_id=? AND id NOT IN (SELECT id FROM (SELECT id FROM watch_party_messages WHERE room_id=? ORDER BY id DESC LIMIT {$limit}) recent)")
            ->execute([$roomId, $roomId]);
        return [
            'message_id' => $messageId,
            'client_message_id' => $clientMessageId,
            'message' => $message,
            'delivered' => false,
            'delivered_at' => null,
            'created_at' => date('c'),
            'duplicate' => false,
        ];
    }
}

if (!function_exists('bm_watch_party_poll')) {
    function bm_watch_party_poll(PDO $pdo, array $room, array $actor, int $afterEventId = 0, int $afterMessageId = 0): array
    {
        bm_watch_party_prepare_connection($pdo);
        $roomId = (int)$room['id'];
        $freshStmt = $pdo->prepare('SELECT * FROM watch_party_rooms WHERE id=? LIMIT 1');
        $freshStmt->execute([$roomId]);
        $freshRoom = $freshStmt->fetch(PDO::FETCH_ASSOC);
        if (!is_array($freshRoom)) {
            throw new RuntimeException('room_not_found', 404);
        }
        $nowEpoch = time();
        $storedEpoch = max(0, (int)($freshRoom['expires_at_epoch'] ?? 0));
        $expiryEpoch = bm_watch_party_expiry_epoch($freshRoom);
        if ($expiryEpoch <= 0 || $expiryEpoch <= $nowEpoch) {
            $pdo->prepare('DELETE FROM watch_party_rooms WHERE id=?')->execute([$roomId]);
            throw new RuntimeException('room_expired', 404);
        }
        if ($expiryEpoch !== $storedEpoch) {
            try {
                $repair = $pdo->prepare('UPDATE watch_party_rooms SET expires_at_epoch=? WHERE id=?');
                $repair->execute([$expiryEpoch, $roomId]);
            } catch (Throwable $e) { /* continue with resolved value */ }
        }
        $freshRoom['expires_at_epoch'] = $expiryEpoch;
        $freshRoom['seconds_left'] = max(0, $expiryEpoch - $nowEpoch);
        $room = $freshRoom;

        // Delivery receipt: a message is considered delivered when the other
        // participant successfully polls it. No extra ACK request is required.
        $actorIsGuest = bm_watch_party_actor_is_guest($actor);
        $actorUserId = $actorIsGuest ? 0 : (int)($actor['id'] ?? 0);
        $actorGuestHash = $actorIsGuest ? bm_watch_party_actor_guest_hash($actor) : '';
        if ($actorIsGuest) {
            $ack = $pdo->prepare("UPDATE watch_party_messages SET delivered_at=COALESCE(delivered_at,NOW()),delivered_by_user_id=0,delivered_by_guest_hash=? WHERE room_id=? AND id>? AND delivered_at IS NULL AND NOT (user_id=0 AND guest_token_hash=?)");
            $ack->execute([$actorGuestHash, $roomId, max(0, $afterMessageId), $actorGuestHash]);
        } else {
            $ack = $pdo->prepare("UPDATE watch_party_messages SET delivered_at=COALESCE(delivered_at,NOW()),delivered_by_user_id=?,delivered_by_guest_hash=NULL WHERE room_id=? AND id>? AND delivered_at IS NULL AND user_id<>?");
            $ack->execute([$actorUserId, $roomId, max(0, $afterMessageId), $actorUserId]);
        }

        $stateStmt = $pdo->prepare('SELECT sequence_no,position_seconds,is_paused,playback_rate,buffering,updated_by,updated_at_ms,updated_at FROM watch_party_state WHERE room_id=? LIMIT 1');
        $stateStmt->execute([$roomId]);
        $state = $stateStmt->fetch(PDO::FETCH_ASSOC) ?: [];

        $eventStmt = $pdo->prepare('SELECT id,user_id,event_type,sequence_no,payload_json,created_at FROM watch_party_events WHERE room_id=? AND id>? ORDER BY id ASC LIMIT 100');
        $eventStmt->execute([$roomId, max(0, $afterEventId)]);
        $events = $eventStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($events as &$eventRow) {
            $eventRow['payload'] = json_decode((string)($eventRow['payload_json'] ?? ''), true) ?: [];
            unset($eventRow['payload_json']);
        }
        unset($eventRow);

        $appearanceReady = function_exists('bm_user_appearance_ensure') ? bm_user_appearance_ensure($pdo) : false;
        $frameSql = $appearanceReady ? "COALESCE(NULLIF(u.avatar_frame,''),'none')" : "'none'";

        $messages = [];
        if (bm_watch_party_chat_enabled()) {
            $messageStmt = $pdo->prepare("SELECT m.id,m.user_id,m.guest_token_hash,m.client_message_id,m.message,m.delivered_at,m.created_at,COALESCE(NULLIF(m.guest_name,''),u.username,CONCAT('کاربر #',m.user_id)) username,COALESCE(NULLIF(m.guest_avatar,''),u.avatar,'') avatar,u.role,u.vip_expires_at,{$frameSql} avatar_frame,CASE WHEN m.user_id=0 THEN 1 ELSE 0 END is_guest FROM watch_party_messages m LEFT JOIN users u ON u.id=m.user_id WHERE m.room_id=? AND m.id>? ORDER BY m.id ASC LIMIT 100");
            $messageStmt->execute([$roomId, max(0, $afterMessageId)]);
            $messages = $messageStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($messages as &$messageRow) {
                $messageRow['avatar_url'] = bm_user_avatar_url((string)($messageRow['avatar'] ?? ''));
                $messageRow['is_mine'] = $actorIsGuest
                    ? ((int)($messageRow['user_id'] ?? 0) === 0 && hash_equals($actorGuestHash, (string)($messageRow['guest_token_hash'] ?? '')))
                    : ((int)($messageRow['user_id'] ?? 0) === $actorUserId);
                $messageRow['is_vip'] = bm_vip_user_is_member_role($messageRow);
                $messageRow['is_admin'] = bm_vip_user_is_admin_role($messageRow);
                $messageRow['avatar_frame'] = function_exists('bm_user_avatar_frame_resolve') ? bm_user_avatar_frame_resolve($messageRow) : (function_exists('bm_user_avatar_frame_is_valid') && bm_user_avatar_frame_is_valid((string)($messageRow['avatar_frame'] ?? '')) ? (string)$messageRow['avatar_frame'] : 'none');
                unset($messageRow['avatar'], $messageRow['role'], $messageRow['vip_expires_at'], $messageRow['guest_token_hash']);
            }
            unset($messageRow);
        }

        $membersStmt = $pdo->prepare("SELECT m.user_id,m.member_role,m.joined_at,m.last_seen_at,COALESCE(NULLIF(m.guest_name,''),u.username,CONCAT('کاربر #',m.user_id)) username,COALESCE(NULLIF(m.guest_avatar,''),u.avatar,'') avatar,u.role,u.vip_expires_at,{$frameSql} avatar_frame,CASE WHEN m.user_id=0 THEN 1 ELSE 0 END is_guest FROM watch_party_members m LEFT JOIN users u ON u.id=m.user_id WHERE m.room_id=? ORDER BY m.id ASC");
        $membersStmt->execute([$roomId]);
        $members = $membersStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($members as &$memberRow) {
            $memberRow['avatar_url'] = bm_user_avatar_url((string)($memberRow['avatar'] ?? ''));
            $memberRow['is_vip'] = bm_vip_user_is_member_role($memberRow);
            $memberRow['is_admin'] = bm_vip_user_is_admin_role($memberRow);
            $memberRow['avatar_frame'] = function_exists('bm_user_avatar_frame_resolve') ? bm_user_avatar_frame_resolve($memberRow) : (function_exists('bm_user_avatar_frame_is_valid') && bm_user_avatar_frame_is_valid((string)($memberRow['avatar_frame'] ?? '')) ? (string)$memberRow['avatar_frame'] : 'none');
            unset($memberRow['avatar'], $memberRow['role'], $memberRow['vip_expires_at']);
        }
        unset($memberRow);

        if ($actorIsGuest) {
            $deliveredStmt = $pdo->prepare('SELECT COALESCE(MAX(id),0) FROM watch_party_messages WHERE room_id=? AND user_id=0 AND guest_token_hash=? AND delivered_at IS NOT NULL');
            $deliveredStmt->execute([$roomId, $actorGuestHash]);
        } else {
            $deliveredStmt = $pdo->prepare('SELECT COALESCE(MAX(id),0) FROM watch_party_messages WHERE room_id=? AND user_id=? AND delivered_at IS NOT NULL');
            $deliveredStmt->execute([$roomId, $actorUserId]);
        }
        $myDeliveredThroughId = (int)$deliveredStmt->fetchColumn();

        return [
            'room' => [
                'id' => $roomId,
                'movie_id' => $room['movie_id'] !== null ? (int)$room['movie_id'] : null,
                'archive_no' => (int)$room['archive_no'],
                'media_type' => (string)$room['media_type'],
                'source_ref' => (string)($room['source_ref'] ?? ''),
                'shared_source_url' => (string)($room['shared_source_url'] ?? ''),
                'shared_subtitle_url' => (string)($room['shared_subtitle_url'] ?? ''),
                'source_updated_at' => (string)($room['source_updated_at'] ?? ''),
                'content_title' => (string)($room['content_title'] ?? ''),
                'poster_url' => (string)($room['poster_url'] ?? ''),
                'theme_key' => bm_watch_party_clean_theme((string)($room['theme_key'] ?? 'default')),
                'background_key' => bm_watch_party_clean_background((string)($room['background_key'] ?? 'simple')),
                'countdown_seconds' => max(3, min(60, (int)($room['countdown_seconds'] ?? 10))),
                'start_at_seconds' => max(0.0, (float)($room['start_at_seconds'] ?? 0)),
                'scheduled_start_at_ms' => max(0, (int)($room['scheduled_start_at_ms'] ?? 0)),
                'scheduled_start_token' => max(0, (int)($room['scheduled_start_token'] ?? 0)),
                'status' => (string)$room['status'],
                'expires_at' => (string)$room['expires_at'],
                'expires_at_epoch' => (int)($room['expires_at_epoch'] ?? 0),
                'seconds_left' => max(0, (int)($room['seconds_left'] ?? 0)),
                'max_members' => (int)$room['max_members'],
            ],
            'state' => [
                'sequence_no' => (int)($state['sequence_no'] ?? 0),
                'current_time' => (float)($state['position_seconds'] ?? 0),
                'paused' => (bool)($state['is_paused'] ?? true),
                'playback_rate' => (float)($state['playback_rate'] ?? 1),
                'buffering' => (bool)($state['buffering'] ?? false),
                'updated_by' => isset($state['updated_by']) ? (int)$state['updated_by'] : null,
                'updated_at_ms' => (int)($state['updated_at_ms'] ?? 0),
                'updated_at' => (string)($state['updated_at'] ?? ''),
            ],
            'server_time_ms' => (int)floor(microtime(true) * 1000),
            'events' => $events,
            'messages' => $messages,
            'my_delivered_through_id' => $myDeliveredThroughId,
            'members' => $members,
        ];
    }
}

if (!function_exists('bm_watch_party_close_room')) {
    function bm_watch_party_close_room(PDO $pdo, array $room, array $user, array $member): int
    {
        if ((string)($member['member_role'] ?? '') !== 'host' && !bm_watch_party_is_admin($user)) {
            throw new RuntimeException('host_control_only', 403);
        }
        $stmt = $pdo->prepare('DELETE FROM watch_party_rooms WHERE id=?');
        $stmt->execute([(int)$room['id']]);
        return $stmt->rowCount();
    }
}

if (!function_exists('bm_watch_party_leave_room')) {
    function bm_watch_party_leave_room(PDO $pdo, array $room, array $user, array $member): array
    {
        if ((string)($member['member_role'] ?? '') === 'host') {
            bm_watch_party_close_room($pdo, $room, $user, $member);
            return ['room_closed' => true];
        }
        if (bm_watch_party_actor_is_guest($user)) {
            $pdo->prepare('DELETE FROM watch_party_members WHERE room_id=? AND user_id=0 AND guest_token_hash=?')
                ->execute([(int)$room['id'], bm_watch_party_actor_guest_hash($user)]);
        } else {
            $pdo->prepare('DELETE FROM watch_party_members WHERE room_id=? AND user_id=?')
                ->execute([(int)$room['id'], (int)$user['id']]);
        }
        $pdo->prepare("UPDATE watch_party_rooms SET status='waiting',last_activity_at=NOW() WHERE id=?")
            ->execute([(int)$room['id']]);
        return ['room_closed' => false];
    }
}
