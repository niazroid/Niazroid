<?php
/**
 * BankMovie unified website notification center.
 *
 * Uses app_notifications as the per-user inbox. Legacy public notifications
 * are lazily mirrored into each signed-in user's inbox so old admin notices
 * continue to work without rewriting every public page.
 */
declare(strict_types=1);

if (!function_exists('bm_notification_center_table_exists')) {
    function bm_notification_center_table_exists(PDO $pdo, string $table): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? LIMIT 1');
            $stmt->execute([$table]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return false;
        }
    }
}

if (!function_exists('bm_notification_center_column_exists')) {
    function bm_notification_center_column_exists(PDO $pdo, string $table, string $column): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $table) || !preg_match('/^[A-Za-z0-9_]+$/', $column)) return false;
        try {
            $stmt = $pdo->prepare('SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ? LIMIT 1');
            $stmt->execute([$table, $column]);
            return (bool)$stmt->fetchColumn();
        } catch (Throwable $e) { return false; }
    }
}

if (!function_exists('bm_notification_center_ensure_schema')) {
    function bm_notification_center_ensure_schema(PDO $pdo): void
    {
        static $done = false;
        if ($done) return;
        $done = true;
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS app_notifications (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id BIGINT UNSIGNED NOT NULL,
                type VARCHAR(40) NOT NULL DEFAULT 'admin',
                title VARCHAR(220) NOT NULL DEFAULT '',
                message TEXT NOT NULL,
                target_json LONGTEXT NULL,
                dedupe_key VARCHAR(190) NULL,
                read_at DATETIME NULL,
                is_read TINYINT(1) NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_user_dedupe (user_id,dedupe_key),
                KEY idx_user_read_created (user_id,read_at,created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
            foreach ([
                'target_json' => "ALTER TABLE app_notifications ADD COLUMN target_json LONGTEXT NULL AFTER message",
                'dedupe_key' => "ALTER TABLE app_notifications ADD COLUMN dedupe_key VARCHAR(190) NULL AFTER target_json",
                'read_at' => "ALTER TABLE app_notifications ADD COLUMN read_at DATETIME NULL AFTER dedupe_key",
                'is_read' => "ALTER TABLE app_notifications ADD COLUMN is_read TINYINT(1) NOT NULL DEFAULT 0 AFTER read_at",
            ] as $column => $sql) {
                if (!bm_notification_center_column_exists($pdo, 'app_notifications', $column)) {
                    try { $pdo->exec($sql); } catch (Throwable $ignore) {}
                }
            }
            try { $pdo->exec("CREATE UNIQUE INDEX uq_user_dedupe ON app_notifications (user_id,dedupe_key)"); } catch (Throwable $ignore) {}
            try { $pdo->exec("CREATE INDEX idx_user_read_created ON app_notifications (user_id,read_at,created_at)"); } catch (Throwable $ignore) {}
            $pdo->exec("CREATE TABLE IF NOT EXISTS app_notification_dismissals (
                user_id BIGINT UNSIGNED NOT NULL,
                dedupe_key VARCHAR(190) NOT NULL,
                dismissed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY(user_id,dedupe_key),
                KEY idx_dismissed_at(dismissed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
        } catch (Throwable $e) {
            error_log('notification center schema: ' . $e->getMessage());
        }
    }
}

if (!function_exists('bm_notification_center_safe_url')) {
    function bm_notification_center_safe_url(array $target): string
    {
        $url = trim((string)($target['url'] ?? ''));
        if ($url !== '' && str_starts_with($url, '/') && !str_starts_with($url, '//') && !preg_match('/[\r\n]/', $url)) {
            return substr($url, 0, 900);
        }
        $movieId = (int)($target['movie_id'] ?? 0);
        if ($movieId > 0) {
            $anchor = '';
            $commentId = (int)($target['comment_id'] ?? 0);
            if ($commentId > 0) $anchor = '#comment-' . $commentId;
            return '/movie?id=' . $movieId . $anchor;
        }
        if (!empty($target['request_id'])) return '/profile#requests-section';
        if (($target['kind'] ?? '') === 'vip' || ($target['type'] ?? '') === 'vip') return '/vip';
        return '';
    }
}

if (!function_exists('bm_notification_center_insert')) {
    function bm_notification_center_insert(PDO $pdo, int $userId, string $type, string $title, string $message, array $target = [], string $dedupe = ''): bool
    {
        if ($userId <= 0 || trim($message) === '') return false;
        bm_notification_center_ensure_schema($pdo);
        $type = substr(trim($type) ?: 'admin', 0, 40);
        $title = mb_substr(trim($title), 0, 220, 'UTF-8');
        $message = mb_substr(trim($message), 0, 5000, 'UTF-8');
        $dedupe = trim($dedupe) !== '' ? substr(trim($dedupe), 0, 190) : null;
        $targetJson = json_encode($target, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (!is_string($targetJson)) $targetJson = '{}';
        if ($dedupe !== null) {
            try {
                $dismissed = $pdo->prepare('SELECT 1 FROM app_notification_dismissals WHERE user_id=? AND dedupe_key=? LIMIT 1');
                $dismissed->execute([$userId, $dedupe]);
                if ($dismissed->fetchColumn()) return true;
            } catch (Throwable $ignore) {}
        }
        try {
            $stmt = $pdo->prepare("INSERT INTO app_notifications(user_id,type,title,message,target_json,dedupe_key,read_at,is_read,created_at)
                VALUES(?,?,?,?,?,?,NULL,0,NOW())
                ON DUPLICATE KEY UPDATE title=VALUES(title),message=VALUES(message),target_json=VALUES(target_json),read_at=NULL,is_read=0,created_at=NOW()");
            return $stmt->execute([$userId, $type, $title, $message, $targetJson, $dedupe]);
        } catch (Throwable $e) {
            error_log('notification center insert: ' . $e->getMessage());
            return false;
        }
    }
}

if (!function_exists('bm_notification_center_seed_legacy')) {
    function bm_notification_center_seed_legacy(PDO $pdo, int $userId): void
    {
        if ($userId <= 0 || !bm_notification_center_table_exists($pdo, 'notifications')) return;
        try {
            $rows = $pdo->query("SELECT id,message,created_at FROM notifications WHERE is_active=1 AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY created_at DESC,id DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC) ?: [];
            foreach ($rows as $row) {
                $id = (int)($row['id'] ?? 0);
                $message = trim((string)($row['message'] ?? ''));
                if ($id <= 0 || $message === '') continue;
                bm_notification_center_insert($pdo, $userId, 'admin', 'پیام BankMovie', $message, ['kind'=>'broadcast','legacy_id'=>$id], 'legacy:' . $id);
            }
        } catch (Throwable $e) {
            error_log('notification center legacy sync: ' . $e->getMessage());
        }
    }
}

if (!function_exists('bm_notification_center_seed_vip_reminder')) {
    function bm_notification_center_seed_vip_reminder(PDO $pdo, array $user): void
    {
        $uid = (int)($user['id'] ?? 0);
        if ($uid <= 0) return;
        $role = strtolower(trim((string)($user['role'] ?? '')));
        if (!in_array($role, ['vip','premium','special'], true)) return;
        $expiry = trim((string)($user['vip_expires_at'] ?? ''));
        if ($expiry === '') return;
        $ts = strtotime($expiry);
        if ($ts === false || $ts <= time()) return;
        $seconds = $ts - time();
        if ($seconds > 3 * 86400) return;
        $days = max(1, (int)ceil($seconds / 86400));
        $dateLabel = date('Y/m/d', $ts);
        bm_notification_center_insert(
            $pdo,
            $uid,
            'vip',
            'اشتراک VIP رو به اتمام است 👑',
            'حدود ' . $days . ' روز تا پایان VIP شما باقی مانده است. برای تمدید بدون وقفه می‌توانید پلن جدید را مشاهده کنید.',
            ['url'=>'/vip','kind'=>'vip','expires_at'=>$expiry],
            'vip-expiry:' . sha1($expiry)
        );
    }
}

if (!function_exists('bm_notification_center_sync_user')) {
    function bm_notification_center_sync_user(PDO $pdo, array $user): void
    {
        $uid = (int)($user['id'] ?? 0);
        if ($uid <= 0) return;
        bm_notification_center_ensure_schema($pdo);
        bm_notification_center_seed_legacy($pdo, $uid);
        bm_notification_center_seed_vip_reminder($pdo, $user);
    }
}

if (!function_exists('bm_notification_center_relative_time')) {
    function bm_notification_center_relative_time(int $age): string
    {
        $age = max(0, $age);
        if ($age < 60) return 'همین الان';
        if ($age < 3600) return floor($age / 60) . ' دقیقه پیش';
        if ($age < 86400) return floor($age / 3600) . ' ساعت پیش';
        if ($age < 604800) return floor($age / 86400) . ' روز پیش';
        return floor($age / 604800) . ' هفته پیش';
    }
}

if (!function_exists('bm_notification_center_list')) {
    function bm_notification_center_list(PDO $pdo, int $userId, int $limit = 30): array
    {
        bm_notification_center_ensure_schema($pdo);
        $limit = max(1, min(60, $limit));
        try {
            $stmt = $pdo->prepare("SELECT *,GREATEST(0,TIMESTAMPDIFF(SECOND,created_at,NOW())) AS age_seconds FROM app_notifications WHERE user_id=? ORDER BY created_at DESC,id DESC LIMIT {$limit}");
            $stmt->execute([$userId]);
            $items = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
                $target = json_decode((string)($row['target_json'] ?? ''), true);
                if (!is_array($target)) $target = [];
                $age = (int)($row['age_seconds'] ?? 0);
                $items[] = [
                    'id' => (int)$row['id'],
                    'type' => (string)($row['type'] ?? 'admin'),
                    'title' => (string)($row['title'] ?? ''),
                    'message' => (string)($row['message'] ?? ''),
                    'target_url' => bm_notification_center_safe_url($target),
                    'is_read' => !empty($row['read_at']) || !empty($row['is_read']),
                    'date_text' => bm_notification_center_relative_time($age),
                    'created_at' => (string)($row['created_at'] ?? ''),
                ];
            }
            return $items;
        } catch (Throwable $e) {
            error_log('notification center list: ' . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('bm_notification_center_unread')) {
    function bm_notification_center_unread(PDO $pdo, int $userId): int
    {
        bm_notification_center_ensure_schema($pdo);
        try {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM app_notifications WHERE user_id=? AND read_at IS NULL AND is_read=0');
            $stmt->execute([$userId]);
            return (int)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('bm_notification_center_public_list')) {
    function bm_notification_center_public_list(PDO $pdo, int $limit = 20): array
    {
        if (!bm_notification_center_table_exists($pdo, 'notifications')) return [];
        $limit = max(1, min(30, $limit));
        try {
            $stmt = $pdo->query("SELECT id,message,created_at,GREATEST(0,TIMESTAMPDIFF(SECOND,created_at,NOW())) AS age_seconds FROM notifications WHERE is_active=1 AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY created_at DESC,id DESC LIMIT {$limit}");
            $out = [];
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
                $out[] = [
                    'id' => 'public-' . (int)$row['id'],
                    'type' => 'admin',
                    'title' => 'پیام BankMovie',
                    'message' => (string)$row['message'],
                    'target_url' => '',
                    'is_read' => true,
                    'date_text' => bm_notification_center_relative_time((int)$row['age_seconds']),
                    'created_at' => (string)$row['created_at'],
                ];
            }
            return $out;
        } catch (Throwable $e) {
            return [];
        }
    }
}

if (!function_exists('bm_notification_center_find_user_id')) {
    function bm_notification_center_find_user_id(PDO $pdo, string $identity): int
    {
        $identity = trim($identity);
        if ($identity === '') return 0;
        try {
            if (ctype_digit($identity)) {
                $stmt = $pdo->prepare('SELECT id FROM users WHERE id=? LIMIT 1');
                $stmt->execute([(int)$identity]);
            } else {
                $stmt = $pdo->prepare('SELECT id FROM users WHERE username=? OR email=? LIMIT 1');
                $stmt->execute([$identity, $identity]);
            }
            return (int)$stmt->fetchColumn();
        } catch (Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('bm_notification_center_send_audience')) {
    function bm_notification_center_send_audience(PDO $pdo, string $audience, string $title, string $message, array $target = [], string $identity = ''): int
    {
        bm_notification_center_ensure_schema($pdo);
        $audience = strtolower(trim($audience));
        $ids = [];
        try {
            if ($audience === 'user') {
                $id = bm_notification_center_find_user_id($pdo, $identity);
                if ($id > 0) $ids = [$id];
            } elseif ($audience === 'vip') {
                $ids = array_map('intval', $pdo->query("SELECT id FROM users WHERE LOWER(role) IN ('vip','premium','special') AND (vip_expires_at IS NULL OR vip_expires_at>NOW())")->fetchAll(PDO::FETCH_COLUMN) ?: []);
            } elseif ($audience === 'regular') {
                $ids = array_map('intval', $pdo->query("SELECT id FROM users WHERE LOWER(role) NOT IN ('admin','administrator','vip','premium','special')")->fetchAll(PDO::FETCH_COLUMN) ?: []);
            } else {
                $ids = array_map('intval', $pdo->query("SELECT id FROM users WHERE LOWER(role) NOT IN ('admin','administrator')")->fetchAll(PDO::FETCH_COLUMN) ?: []);
            }
        } catch (Throwable $e) {
            error_log('notification audience select: ' . $e->getMessage());
            return 0;
        }
        $ids = array_values(array_unique(array_filter($ids, static fn($id) => $id > 0)));
        if (!$ids) return 0;
        $batch = 'admin:' . bin2hex(random_bytes(8));
        $sent = 0;
        foreach ($ids as $uid) {
            if (bm_notification_center_insert($pdo, $uid, 'admin', $title, $message, $target, $batch)) $sent++;
        }
        return $sent;
    }
}
