<?php
/**
 * BankMovie runtime performance helpers.
 *
 * Keeps schema upgrades out of hot public requests, records slow movie-page
 * stages, and provides safe one-time migration markers in the private folder.
 */

if (!function_exists('bm_perf_boot')) {
    function bm_perf_boot(array $context = []): void
    {
        if (!isset($GLOBALS['BM_PERF'])) {
            $GLOBALS['BM_PERF'] = [
                'started_at' => microtime(true),
                'last_at' => microtime(true),
                'marks' => [],
                'context' => [],
                'notes' => [],
                'registered' => false,
            ];
        }
        if ($context) bm_perf_context($context);
        if (empty($GLOBALS['BM_PERF']['registered'])) {
            $GLOBALS['BM_PERF']['registered'] = true;
            register_shutdown_function('bm_perf_shutdown');
        }
    }
}

if (!function_exists('bm_perf_context')) {
    function bm_perf_context(array $context): void
    {
        bm_perf_boot();
        foreach ($context as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $GLOBALS['BM_PERF']['context'][(string)$key] = $value;
            }
        }
    }
}

if (!function_exists('bm_perf_mark')) {
    function bm_perf_mark(string $name, array $meta = []): void
    {
        bm_perf_boot();
        $now = microtime(true);
        $last = (float)($GLOBALS['BM_PERF']['last_at'] ?? $GLOBALS['BM_PERF']['started_at']);
        $GLOBALS['BM_PERF']['marks'][] = [
            'name' => $name,
            'delta_ms' => round(($now - $last) * 1000, 2),
            'at_ms' => round(($now - (float)$GLOBALS['BM_PERF']['started_at']) * 1000, 2),
            'meta' => $meta,
        ];
        $GLOBALS['BM_PERF']['last_at'] = $now;
    }
}

if (!function_exists('bm_perf_note')) {
    function bm_perf_note(string $key, $value): void
    {
        bm_perf_boot();
        if (is_scalar($value) || $value === null || is_array($value)) {
            $GLOBALS['BM_PERF']['notes'][$key] = $value;
        }
    }
}

if (!function_exists('bm_perf_private_path')) {
    function bm_perf_private_path(string $filename): string
    {
        if (function_exists('bm_security_private_path')) {
            return bm_security_private_path($filename);
        }
        return dirname(__DIR__) . '/_bankmovie_private/' . basename($filename);
    }
}

if (!function_exists('bm_perf_append_json_line')) {
    function bm_perf_append_json_line(string $path, array $row): void
    {
        $dir = dirname($path);
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        $json = json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($json)) return;
        // لاگ تشخیصی نباید فضای هاست را پر کند.
        clearstatcache(true, $path);
        if (is_file($path) && (int)@filesize($path) > 2 * 1024 * 1024) {
            @unlink($path . '.1');
            @rename($path, $path . '.1');
        }
        $fh = @fopen($path, 'ab');
        if (!$fh) return;
        try {
            if (@flock($fh, LOCK_EX)) {
                @fwrite($fh, $json . PHP_EOL);
                @fflush($fh);
                @flock($fh, LOCK_UN);
            }
        } finally {
            @fclose($fh);
        }
    }
}

if (!function_exists('bm_perf_shutdown')) {
    function bm_perf_shutdown(): void
    {
        if (empty($GLOBALS['BM_PERF']) || !is_array($GLOBALS['BM_PERF'])) return;
        $perf = $GLOBALS['BM_PERF'];
        $totalMs = round((microtime(true) - (float)$perf['started_at']) * 1000, 2);
        $fatal = error_get_last();
        $isFatal = is_array($fatal) && in_array((int)($fatal['type'] ?? 0), [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true);
        $thresholdMs = 2500;
        if ($totalMs < $thresholdMs && !$isFatal) return;

        $largest = null;
        foreach (($perf['marks'] ?? []) as $mark) {
            if ($largest === null || (float)$mark['delta_ms'] > (float)$largest['delta_ms']) $largest = $mark;
        }
        $row = [
            'time' => date('c'),
            'request_id' => substr(hash('sha256', uniqid('', true) . '|' . ($_SERVER['REMOTE_ADDR'] ?? '')), 0, 16),
            'method' => (string)($_SERVER['REQUEST_METHOD'] ?? 'GET'),
            'uri' => substr((string)($_SERVER['REQUEST_URI'] ?? ''), 0, 500),
            'total_ms' => $totalMs,
            'largest_stage' => $largest,
            'marks' => $perf['marks'] ?? [],
            'context' => $perf['context'] ?? [],
            'notes' => $perf['notes'] ?? [],
            'memory_peak_mb' => round(memory_get_peak_usage(true) / 1048576, 2),
            'fatal' => $isFatal ? [
                'type' => (int)($fatal['type'] ?? 0),
                'message' => substr((string)($fatal['message'] ?? ''), 0, 800),
                'file' => basename((string)($fatal['file'] ?? '')),
                'line' => (int)($fatal['line'] ?? 0),
            ] : null,
        ];
        bm_perf_append_json_line(bm_perf_private_path('slow-requests.log'), $row);
    }
}

if (!function_exists('bm_schema_marker_path')) {
    function bm_schema_marker_path(string $name, int $version): string
    {
        $dbIdentity = (defined('DB_HOST') ? DB_HOST : '') . '|' . (defined('DB_NAME') ? DB_NAME : '');
        $safeName = preg_replace('/[^a-z0-9_-]+/i', '-', strtolower($name)) ?: 'schema';
        return bm_perf_private_path('schema-' . $safeName . '-v' . $version . '-' . substr(sha1($dbIdentity), 0, 10) . '.done');
    }
}

if (!function_exists('bm_schema_once')) {
    /**
     * Execute schema work once per database + version instead of on every page view.
     */
    function bm_schema_once(PDO $pdo, string $name, int $version, callable $callback): bool
    {
        static $runtimeDone = [];
        $runtimeKey = $name . ':' . $version;
        if (isset($runtimeDone[$runtimeKey])) return $runtimeDone[$runtimeKey];

        $marker = bm_schema_marker_path($name, $version);
        if (is_file($marker)) return $runtimeDone[$runtimeKey] = true;

        $lockPath = $marker . '.lock';
        $lock = @fopen($lockPath, 'c+');
        if (!$lock) return false;
        try {
            if (!@flock($lock, LOCK_EX)) return false;
            clearstatcache(true, $marker);
            if (is_file($marker)) return $runtimeDone[$runtimeKey] = true;

            $started = microtime(true);
            $callback($pdo);
            $payload = json_encode([
                'name' => $name,
                'version' => $version,
                'completed_at' => date('c'),
                'duration_ms' => round((microtime(true) - $started) * 1000, 2),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            if (@file_put_contents($marker, (string)$payload, LOCK_EX) === false) return false;
            @chmod($marker, 0600);
            return $runtimeDone[$runtimeKey] = true;
        } catch (Throwable $e) {
            error_log('Schema migration [' . $name . '] failed: ' . $e->getMessage());
            bm_perf_note('schema_error_' . $name, $e->getMessage());
            return $runtimeDone[$runtimeKey] = false;
        } finally {
            @flock($lock, LOCK_UN);
            @fclose($lock);
        }
    }
}
