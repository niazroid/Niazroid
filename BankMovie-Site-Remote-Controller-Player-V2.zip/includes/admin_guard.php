<?php
/**
 * admin_guard.php
 * نگهبان مشترک پنل مدیریت BankMovie
 * این فایل ورود ادمین را یکپارچه می‌کند و مشکل دسترسی با session قدیمی/admin123 را حذف می‌کند.
 */
declare(strict_types=1);

// config.php owns the database-backed session handler. It MUST be loaded
// before any session_start(), otherwise admin GET and POST requests can use
// different session stores and every form appears to have an invalid CSRF token.
require_once dirname(__DIR__) . '/config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Admin HTML must never be served from browser/proxy/LiteSpeed cache because
// it contains a per-session CSRF token.
if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('Expires: Thu, 01 Jan 1970 00:00:00 GMT');
    header('Vary: Cookie');
    header('Referrer-Policy: no-referrer');
}

function admin_current_user(): ?array
{
    global $currentUser;
    return (isset($currentUser) && is_array($currentUser)) ? $currentUser : null;
}

function require_admin(): void
{
    $user = admin_current_user();
    if (!$user || (($user['role'] ?? '') !== 'admin')) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'] ?? 'admin.php';
        header('Location: /login');
        exit;
    }

    // حذف بقایای سیستم ورود قدیمی تا نقش فقط از users.role خوانده شود.
    unset($_SESSION['admin_logged']);
}

function admin_csrf_token(): string
{
    if (empty($_SESSION['admin_csrf_token'])) {
        $_SESSION['admin_csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['admin_csrf_token'];
}

function admin_csrf_input(): string
{
    return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(admin_csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

function admin_request_is_same_origin(): bool
{
    $requestHost = strtolower(preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? '')));
    if ($requestHost === '') return false;

    foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $header) {
        $value = trim((string)($_SERVER[$header] ?? ''));
        if ($value === '') continue;
        $parts = @parse_url($value);
        $sourceHost = strtolower((string)($parts['host'] ?? ''));
        return $sourceHost !== '' && hash_equals($requestHost, $sourceHost);
    }

    // Some privacy tools omit both headers. SameSite=Lax + an authenticated
    // admin session still protects normal form POSTs, so keep compatibility.
    return empty($_SERVER['HTTP_ORIGIN']) && empty($_SERVER['HTTP_REFERER']);
}

function admin_request_csrf_is_valid(): bool
{
    $expected = admin_csrf_token();
    $sent = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    return is_string($sent) && $sent !== '' && hash_equals($expected, $sent);
}

function admin_enforce_csrf(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        return;
    }
    if (admin_request_csrf_is_valid()) {
        return;
    }

    http_response_code(419);
    if (isset($_POST['ajax_action'])) {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'نشست منقضی شده است. صفحه را تازه‌سازی کنید.'], JSON_UNESCAPED_UNICODE);
    } else {
        echo 'درخواست نامعتبر است. صفحه را تازه‌سازی کنید.';
    }
    exit;
}


function admin_enforce_get_csrf(array $unsafeKeys): void
{
    foreach ($unsafeKeys as $key) {
        if (isset($_GET[$key])) {
            $sent = $_GET['csrf_token'] ?? '';
            if (!is_string($sent) || !hash_equals(admin_csrf_token(), $sent)) {
                http_response_code(419);
                echo 'درخواست نامعتبر است. لطفاً از داخل پنل دوباره اقدام کنید.';
                exit;
            }
            return;
        }
    }
}

function admin_csrf_url(string $url): string
{
    $sep = str_contains($url, '?') ? '&' : '?';
    return $url . $sep . 'csrf_token=' . urlencode(admin_csrf_token());
}

function admin_escape(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function admin_safe_destination_url(string $url): string
{
    $url = html_entity_decode(trim($url), ENT_QUOTES | ENT_HTML5, 'UTF-8');
    if ($url === '' || preg_match('/[\x00-\x1F\x7F]/', $url)) return '';

    // Allow normal internal links on the same BankMovie host.
    if (str_starts_with($url, '/') && !str_starts_with($url, '//')) {
        return $url;
    }
    if (!preg_match('~^[a-z][a-z0-9+.-]*:~i', $url)) {
        if (str_contains($url, '\\') || str_starts_with($url, '//')) return '';
        return '/' . ltrim($url, '/');
    }

    if (function_exists('bm_security_safe_url')) {
        return bm_security_safe_url($url, ['http', 'https']);
    }
    return filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
}

function admin_normalize_slug(string $slug, string $fallback = ''): string
{
    $slug = trim($slug);
    if ($slug === '' && $fallback !== '') {
        $slug = $fallback;
    }
    $slug = strtolower(preg_replace('/[^a-zA-Z0-9\-_]+/', '-', $slug));
    return trim($slug, '-_');
}

function admin_safe_relative_path(string $path, array $allowedDirs = ['posters/', 'uploads/collections/', 'uploads/slider/', 'uploads/stories/', 'uploads/banners/']): bool
{
    $path = str_replace('\\', '/', $path);
    if ($path === '' || str_contains($path, '..') || str_starts_with($path, '/') || preg_match('/^[a-zA-Z]:/', $path)) {
        return false;
    }
    foreach ($allowedDirs as $dir) {
        if (str_starts_with($path, $dir)) {
            return true;
        }
    }
    return false;
}

function admin_safe_unlink(?string $path, array $allowedDirs = ['posters/', 'uploads/collections/', 'uploads/slider/', 'uploads/stories/', 'uploads/banners/']): void
{
    if (!$path || !admin_safe_relative_path($path, $allowedDirs)) {
        return;
    }
    $full = dirname(__DIR__) . '/' . $path;
    if (is_file($full)) {
        @unlink($full);
    }
}

function admin_safe_image_upload(array $file, string $uploadDir, string $baseName, int $quality = 82, int $maxBytes = 5242880): ?string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    $uploadError = (int)($file['error'] ?? UPLOAD_ERR_OK);
    if ($uploadError !== UPLOAD_ERR_OK) {
        $messages = [
            UPLOAD_ERR_INI_SIZE => 'حجم فایل از محدودیت upload_max_filesize هاست بیشتر است.',
            UPLOAD_ERR_FORM_SIZE => 'حجم فایل از محدودیت فرم بیشتر است.',
            UPLOAD_ERR_PARTIAL => 'فایل ناقص آپلود شد.',
            UPLOAD_ERR_NO_TMP_DIR => 'پوشه موقت PHP روی هاست تنظیم نشده است.',
            UPLOAD_ERR_CANT_WRITE => 'هاست اجازه نوشتن فایل را نداد.',
            UPLOAD_ERR_EXTENSION => 'یک افزونه PHP آپلود را متوقف کرد.',
        ];
        throw new RuntimeException($messages[$uploadError] ?? 'آپلود تصویر کامل نشد.');
    }
    if (($file['size'] ?? 0) <= 0) {
        throw new RuntimeException('فایل انتخاب‌شده خالی است.');
    }
    if (($file['size'] ?? 0) > $maxBytes) {
        throw new RuntimeException('حجم تصویر بیشتر از حد مجاز است.');
    }
    if (!is_uploaded_file((string)($file['tmp_name'] ?? ''))) {
        throw new RuntimeException('فایل آپلودی معتبر نیست.');
    }

    $info = @getimagesize($file['tmp_name']);
    if (!$info || empty($info['mime'])) {
        throw new RuntimeException('فایل انتخاب‌شده تصویر معتبر نیست.');
    }
    $mimeToExt = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    if (!isset($mimeToExt[$info['mime']])) {
        throw new RuntimeException('فقط تصاویر JPG، PNG و WebP مجاز هستند.');
    }

    $uploadDir = trim(str_replace('\\', '/', $uploadDir), '/') . '/';
    if (!admin_safe_relative_path($uploadDir, ['posters/', 'uploads/collections/', 'uploads/slider/', 'uploads/stories/', 'uploads/banners/'])) {
        throw new RuntimeException('مسیر آپلود معتبر نیست.');
    }
    $dirFull = dirname(__DIR__) . '/' . $uploadDir;
    if (!is_dir($dirFull) && !@mkdir($dirFull, 0755, true) && !is_dir($dirFull)) {
        throw new RuntimeException('امکان ساخت پوشه آپلود وجود ندارد.');
    }
    if (!is_writable($dirFull)) {
        throw new RuntimeException('پوشه آپلود قابل نوشتن نیست. Permission پوشه را روی 755 یا 775 قرار دهید.');
    }

    $baseName = preg_replace('/[^a-zA-Z0-9_\-]/', '_', $baseName);
    $baseName = trim((string)$baseName, '_-') ?: bin2hex(random_bytes(8));

    // Prefer WebP optimization when GD has all required functions. On hosts without GD,
    // preserve the validated original format instead of making the admin action fail.
    $canConvert = function_exists('imagewebp')
        && (($info['mime'] === 'image/jpeg' && function_exists('imagecreatefromjpeg'))
            || ($info['mime'] === 'image/png' && function_exists('imagecreatefrompng'))
            || ($info['mime'] === 'image/webp' && function_exists('imagecreatefromwebp')));

    if ($canConvert) {
        $relative = $uploadDir . $baseName . '.webp';
        $target = dirname(__DIR__) . '/' . $relative;
        if ($info['mime'] === 'image/jpeg') {
            $image = @imagecreatefromjpeg($file['tmp_name']);
        } elseif ($info['mime'] === 'image/png') {
            $image = @imagecreatefrompng($file['tmp_name']);
            if ($image) {
                if (function_exists('imagepalettetotruecolor')) @imagepalettetotruecolor($image);
                imagealphablending($image, true);
                imagesavealpha($image, true);
            }
        } else {
            $image = @imagecreatefromwebp($file['tmp_name']);
        }
        if ($image && @imagewebp($image, $target, max(1, min(100, $quality)))) {
            imagedestroy($image);
            @chmod($target, 0644);
            return $relative;
        }
        if ($image) imagedestroy($image);
    }

    if (class_exists('Imagick')) {
        try {
            $relative = $uploadDir . $baseName . '.webp';
            $target = dirname(__DIR__) . '/' . $relative;
            $imagick = new Imagick($file['tmp_name']);
            $imagick->setImageFormat('webp');
            $imagick->setImageCompressionQuality(max(1, min(100, $quality)));
            $imagick->stripImage();
            if ($imagick->writeImage($target)) {
                $imagick->clear();
                $imagick->destroy();
                @chmod($target, 0644);
                return $relative;
            }
            $imagick->clear();
            $imagick->destroy();
        } catch (Throwable $e) {
            // Continue to the safe fallback below.
        }
    }

    if ($uploadDir === 'posters/') {
        throw new RuntimeException('برای ذخیره کاور فیلم با فرمت WebP باید GD/WebP یا Imagick روی هاست فعال باشد.');
    }

    $extension = $mimeToExt[$info['mime']];
    $relative = $uploadDir . $baseName . '.' . $extension;
    $target = dirname(__DIR__) . '/' . $relative;
    if (!@move_uploaded_file($file['tmp_name'], $target)) {
        throw new RuntimeException('ذخیره تصویر روی هاست انجام نشد. Permission پوشه آپلود را بررسی کنید.');
    }
    @chmod($target, 0644);
    return $relative;
}
