<?php
/**
 * Stale-while-revalidate cache for external archive movie details.
 * A stale response is served immediately and refreshed after the response,
 * preventing upstream slowness from blocking the visitor for 20-60 seconds.
 */

if (!function_exists('bm_detail_cache_dir')) {
    function bm_detail_cache_dir(): string
    {
        $base = function_exists('bm_security_private_dir')
            ? bm_security_private_dir()
            : dirname(__DIR__) . '/_bankmovie_private';
        $dir = rtrim($base, '/\\') . DIRECTORY_SEPARATOR . 'cache' . DIRECTORY_SEPARATOR . 'movie-details';
        if (!is_dir($dir)) @mkdir($dir, 0700, true);
        return $dir;
    }
}

if (!function_exists('bm_detail_cache_file')) {
    function bm_detail_cache_file(string $namespace, string $key): string
    {
        $namespace = preg_replace('/[^a-z0-9_-]+/i', '-', strtolower($namespace)) ?: 'archive';
        return bm_detail_cache_dir() . DIRECTORY_SEPARATOR . $namespace . '-' . sha1($key) . '.json';
    }
}

if (!function_exists('bm_detail_cache_read')) {
    function bm_detail_cache_read(string $namespace, string $key, int $freshTtl, int $staleTtl): ?array
    {
        $file = bm_detail_cache_file($namespace, $key);
        if (!is_file($file)) return null;
        $age = time() - (int)@filemtime($file);
        if ($age > max($freshTtl, $staleTtl)) {
            @unlink($file);
            return null;
        }
        $raw = @file_get_contents($file);
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (!is_array($decoded) || !isset($decoded['data']) || !is_array($decoded['data'])) return null;
        return [
            'data' => $decoded['data'],
            'state' => $age <= $freshTtl ? 'fresh' : 'stale',
            'age' => $age,
            'file' => $file,
        ];
    }
}

if (!function_exists('bm_detail_cache_write')) {
    function bm_detail_cache_write(string $namespace, string $key, array $data): bool
    {
        $file = bm_detail_cache_file($namespace, $key);
        $payload = json_encode([
            'saved_at' => date('c'),
            'data' => $data,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
        if (!is_string($payload) || strlen($payload) < 20) return false;
        $tmp = $file . '.' . getmypid() . '.' . bin2hex(random_bytes(3)) . '.tmp';
        if (@file_put_contents($tmp, $payload, LOCK_EX) === false) {
            @unlink($tmp);
            return false;
        }
        @chmod($tmp, 0600);
        if (!@rename($tmp, $file)) {
            @unlink($tmp);
            return false;
        }
        @chmod($file, 0600);
        return true;
    }
}

if (!function_exists('bm_detail_cache_schedule_refresh')) {
    function bm_detail_cache_schedule_refresh(string $namespace, string $key, callable $loader): void
    {
        $file = bm_detail_cache_file($namespace, $key);
        $attemptStamp = $file . '.refresh';
        if (is_file($attemptStamp) && (time() - (int)@filemtime($attemptStamp)) < 90) return;

        register_shutdown_function(static function () use ($namespace, $key, $loader, $file, $attemptStamp): void {
            $lock = @fopen($file . '.refresh.lock', 'c+');
            if (!$lock || !@flock($lock, LOCK_EX | LOCK_NB)) {
                if (is_resource($lock)) @fclose($lock);
                return;
            }
            try {
                clearstatcache(true, $attemptStamp);
                if (is_file($attemptStamp) && (time() - (int)@filemtime($attemptStamp)) < 90) return;
                @touch($attemptStamp);
                if (function_exists('fastcgi_finish_request')) @fastcgi_finish_request();
                @ignore_user_abort(true);
                @set_time_limit(35);
                $data = $loader();
                if (is_array($data) && $data) bm_detail_cache_write($namespace, $key, $data);
            } catch (Throwable $e) {
                error_log('Movie detail background refresh [' . $namespace . ']: ' . $e->getMessage());
            } finally {
                @flock($lock, LOCK_UN);
                @fclose($lock);
            }
        });
    }
}

if (!function_exists('bm_detail_cache_get')) {
    function bm_detail_cache_get(
        string $namespace,
        string $key,
        callable $loader,
        int $freshTtl = 600,
        int $staleTtl = 21600
    ): array {
        $cached = bm_detail_cache_read($namespace, $key, $freshTtl, $staleTtl);
        if ($cached && $cached['state'] === 'fresh') {
            if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'fresh', 'age' => $cached['age']]);
            return $cached['data'];
        }
        if ($cached && $cached['state'] === 'stale') {
            if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'stale', 'age' => $cached['age']]);
            bm_detail_cache_schedule_refresh($namespace, $key, $loader);
            return $cached['data'];
        }

        $started = microtime(true);
        $cacheFile = bm_detail_cache_file($namespace, $key);
        $fetchLock = @fopen($cacheFile . '.fetch.lock', 'c+');
        $hasLock = false;
        if (is_resource($fetchLock)) {
            // از هجوم هم‌زمان چند درخواست به سرور آرشیو جلوگیری می‌کند.
            for ($wait = 0; $wait < 18; $wait++) {
                if (@flock($fetchLock, LOCK_EX | LOCK_NB)) {
                    $hasLock = true;
                    break;
                }
                usleep(100000);
                $appeared = bm_detail_cache_read($namespace, $key, $freshTtl, $staleTtl);
                if ($appeared) {
                    @fclose($fetchLock);
                    if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'wait-hit', 'age' => $appeared['age']]);
                    return $appeared['data'];
                }
            }
        }
        try {
            // ممکن است درخواست دیگری درست قبل از گرفتن Lock فایل را ساخته باشد.
            $appeared = bm_detail_cache_read($namespace, $key, $freshTtl, $staleTtl);
            if ($appeared) {
                if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'lock-hit', 'age' => $appeared['age']]);
                return $appeared['data'];
            }
            $data = $loader();
            if (!is_array($data) || !$data) throw new RuntimeException('Archive detail response was empty.');
            bm_detail_cache_write($namespace, $key, $data);
            if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'miss', 'fetch_ms' => round((microtime(true) - $started) * 1000, 2)]);
            return $data;
        } catch (Throwable $e) {
            // A cache may have appeared while this request was fetching.
            $fallback = bm_detail_cache_read($namespace, $key, 0, $staleTtl);
            if ($fallback) {
                if (function_exists('bm_perf_note')) bm_perf_note('detail_cache', ['archive' => $namespace, 'state' => 'error-fallback', 'error' => $e->getMessage()]);
                return $fallback['data'];
            }
            throw $e;
        } finally {
            if (is_resource($fetchLock)) {
                if ($hasLock) @flock($fetchLock, LOCK_UN);
                @fclose($fetchLock);
            }
        }
    }
}
