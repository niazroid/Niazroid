<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/site_content_control.php';
require_once __DIR__ . '/includes/archive_control.php';
bm_site_enforce_page('page_categories_enabled');

if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$userLang = (($_COOKIE['user_lang'] ?? 'fa') === 'en') ? 'en' : 'fa';
$currentUser = null;
try {
    if (!empty($_COOKIE['session_token']) && class_exists('User')) {
        $userObj = new User($pdo);
        $currentUser = $userObj->checkSession((string)$_COOKIE['session_token']) ?: null;
    } elseif (!empty($_SESSION['user_id'])) {
        $st = $pdo->prepare('SELECT id,username,role,vip_expires_at FROM users WHERE id=? LIMIT 1');
        $st->execute([(int)$_SESSION['user_id']]);
        $currentUser = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }
} catch (Throwable $e) {
    $currentUser = null;
}

$t = [
    'fa' => ['home'=>'خانه','notifications'=>'اعلان‌ها','account'=>'حساب کاربری','login'=>'ورود','register'=>'ثبت نام','logout'=>'خروج','admin_panel'=>'پنل مدیریت'],
    'en' => ['home'=>'Home','notifications'=>'Notifications','account'=>'Account','login'=>'Login','register'=>'Register','logout'=>'Logout','admin_panel'=>'Admin Panel'],
];
$notificationsList = [];
$latestNotification = null;

function bm_cat_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function bm_cat_key($value): string
{
    $value = html_entity_decode((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $value = str_replace(["\u{200c}", "\u{200f}", "\u{00a0}", 'ي', 'ك', 'ۀ', 'ة'], [' ', ' ', ' ', 'ی', 'ک', 'ه', 'ه'], $value);
    $value = preg_replace('/\s+/u', ' ', trim($value)) ?: '';
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}

function bm_cat_type($value): string
{
    $value = bm_cat_key($value);
    if (in_array($value, ['series','serial','tv','show','سریال'], true) || str_contains($value, 'series') || str_contains($value, 'سریال')) return 'series';
    return 'movie';
}

function bm_cat_local_cache_path(): string
{
    if (function_exists('bm_security_private_path')) return bm_security_private_path('categories_local_genres_v146.json');
    return __DIR__ . '/cache/categories_local_genres_v146.json';
}

function bm_cat_local_genres(PDO $pdo): array
{
    $cachePath = bm_cat_local_cache_path();
    if (is_file($cachePath) && time() - (int)@filemtime($cachePath) < 1800) {
        $decoded = json_decode((string)@file_get_contents($cachePath), true);
        if (is_array($decoded) && isset($decoded['all'], $decoded['movie'], $decoded['series'])) return $decoded;
    }

    $result = ['all'=>[], 'movie'=>[], 'series'=>[]];
    try {
        $normalized = "REPLACE(REPLACE(REPLACE(genres, '،', ','), '|', ','), ';', ',')";
        $numbers = implode(' UNION ALL ', array_map(static fn(int $n): string => "SELECT {$n} n", range(1, 14)));
        $sql = "SELECT m.type,
                       TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(m.normalized, ',', nums.n), ',', -1)) AS genre,
                       COUNT(*) AS total
                FROM (SELECT type, {$normalized} AS normalized FROM movies WHERE genres IS NOT NULL AND TRIM(genres) <> '') m
                JOIN ({$numbers}) nums
                  ON nums.n <= 1 + LENGTH(m.normalized) - LENGTH(REPLACE(m.normalized, ',', ''))
                GROUP BY m.type, genre
                HAVING genre <> ''
                ORDER BY total DESC, genre ASC";
        $rows = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $label = preg_replace('/\s+/u', ' ', trim((string)($row['genre'] ?? ''))) ?: '';
            $count = max(0, (int)($row['total'] ?? 0));
            if ($label === '' || $count < 1) continue;
            $key = bm_cat_key($label);
            $type = bm_cat_type($row['type'] ?? 'movie');
            if (!isset($result[$type][$key])) $result[$type][$key] = ['label'=>$label, 'count'=>0, 'type'=>$type];
            $result[$type][$key]['count'] += $count;
            if (!isset($result['all'][$key])) $result['all'][$key] = ['label'=>$label, 'count'=>0, 'type'=>'all'];
            $result['all'][$key]['count'] += $count;
        }
        foreach ($result as $type => $map) {
            $rows = array_values($map);
            usort($rows, static fn(array $a, array $b): int => (($b['count'] ?? 0) <=> ($a['count'] ?? 0)) ?: strnatcasecmp((string)$a['label'], (string)$b['label']));
            $result[$type] = $rows;
        }
        $dir = dirname($cachePath);
        if (!is_dir($dir)) @mkdir($dir, 0750, true);
        if (is_dir($dir) && is_writable($dir)) @file_put_contents($cachePath, json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
    } catch (Throwable $e) {
        // A temporary database problem must not break the public category page.
    }
    return $result;
}

function bm_cat_image_key(string $label, string $slug = ''): string
{
    $key = bm_cat_key($label . ' ' . $slug);
    $aliases = [
        'action'=>'action','اکشن'=>'action','adventure'=>'adventure','ماجراجویی'=>'adventure',
        'animation'=>'animation','انیمیشن'=>'animation','anime'=>'anime','انیمه'=>'anime',
        'biography'=>'biography','بیوگرافی'=>'biography','comedy'=>'comedy','کمدی'=>'comedy',
        'crime'=>'crime','جنایی'=>'crime','documentary'=>'documentary','مستند'=>'documentary',
        'drama'=>'drama','درام'=>'drama','family'=>'family','خانوادگی'=>'family',
        'fantasy'=>'fantasy','فانتزی'=>'fantasy','history'=>'history','historical'=>'history','تاریخی'=>'history',
        'horror'=>'horror','ترسناک'=>'horror','music'=>'music','musical'=>'music','موزیک'=>'music','موزیکال'=>'music',
        'mystery'=>'mystery','رازآلود'=>'mystery','معمایی'=>'mystery','romance'=>'romance','عاشقانه'=>'romance',
        'sci-fi'=>'sci_fi','science-fiction'=>'sci_fi','علمی تخیلی'=>'sci_fi','علمی‌تخیلی'=>'sci_fi',
        'science'=>'science','علمی'=>'science','short'=>'short','کوتاه'=>'short',
        'sport'=>'sport','sports'=>'sport','ورزشی'=>'sport','supernatural'=>'supernatural','فراطبیعی'=>'supernatural',
        'thriller'=>'thriller','هیجان انگیز'=>'thriller','هیجان‌انگیز'=>'thriller','war'=>'war','جنگی'=>'war',
        'western'=>'western','وسترن'=>'western','school'=>'school','مدرسه ای'=>'school','مدرسه‌ای'=>'school',
    ];
    foreach ($aliases as $needle => $image) {
        if ($key === bm_cat_key($needle) || str_contains($key, bm_cat_key($needle))) return $image;
    }
    return 'default';
}

function bm_cat_merge_arc1(array $movieRows, array $seriesRows): array
{
    $map = [];
    foreach (array_merge($movieRows, $seriesRows) as $row) {
        $label = trim((string)($row['label'] ?? ''));
        if ($label === '') continue;
        $key = bm_cat_key($label);
        if (!isset($map[$key])) $map[$key] = $row + ['count'=>0, 'type'=>'all'];
        else $map[$key]['count'] = (int)($map[$key]['count'] ?? 0) + (int)($row['count'] ?? 0);
        $map[$key]['type'] = 'all';
    }
    $rows = array_values($map);
    usort($rows, static fn(array $a, array $b): int => (($b['count'] ?? 0) <=> ($a['count'] ?? 0)) ?: strnatcasecmp((string)$a['label'], (string)$b['label']));
    return $rows;
}

$categoryVisible = [
    1 => bm_site_bool('categories_show_archive1', true)
        && bm_site_bool('search_archive1_enabled', true)
        && bm_archive_is_enabled('archive1')
        && bm_archive_user_can_access('archive1', $currentUser ?? null),
    2 => bm_site_bool('categories_show_archive2', true)
        && bm_site_bool('search_archive2_enabled', true)
        && bm_archive_is_enabled('archive2')
        && bm_archive_user_can_access('archive2', $currentUser ?? null),
    3 => bm_site_bool('categories_show_archive3', true)
        && bm_site_bool('search_archive3_enabled', true)
        && bm_archive_is_enabled('archive3')
        && bm_archive_user_can_access('archive3', $currentUser ?? null),
];

$visibleArchiveIds = array_keys(array_filter($categoryVisible));
$defaultArchive = (int)bm_site_get('categories_default_archive', '2');
if (!$visibleArchiveIds) {
    // No archive is available for this audience: do not silently expose a fallback.
    $defaultArchive = 0;
    $archive = 0;
} else {
    if (!isset($categoryVisible[$defaultArchive]) || !$categoryVisible[$defaultArchive]) {
        $defaultArchive = (int)$visibleArchiveIds[0];
    }
    $archive = max(1, min(3, (int)($_GET['archive'] ?? $defaultArchive)));
    if (empty($categoryVisible[$archive])) $archive = $defaultArchive;
}

$type = strtolower(trim((string)($_GET['type'] ?? ($archive === 3 ? 'all' : 'movie'))));
if (!in_array($type, ['all','movie','series'], true)) $type = $archive === 3 ? 'all' : 'movie';

$rows = [];
$dataStatus = $archive === 0 ? 'restricted' : 'cached';
if ($archive === 1) {
    require_once __DIR__ . '/includes/api2_lib.php';
    $options = api2_search_options();
    $movieRows = (array)($options['movie_genres'] ?? []);
    $seriesRows = (array)($options['series_genres'] ?? []);
    $rows = $type === 'movie' ? $movieRows : ($type === 'series' ? $seriesRows : bm_cat_merge_arc1($movieRows, $seriesRows));
    $dataStatus = (string)($options['counts_source'] ?? 'cached');
} elseif ($archive === 2) {
    $options = bm_cat_local_genres($pdo);
    $rows = (array)($options[$type] ?? $options['all'] ?? []);
    $dataStatus = 'database_cache';
} else {
    require_once __DIR__ . '/includes/api6_lib.php';
    $options = api6_search_options();
    $rows = (array)($options['genres'] ?? []);
    $dataStatus = (string)($options['counts_source'] ?? 'cached');
}

$cleanRows = [];
foreach ($rows as $row) {
    $label = trim((string)($row['label'] ?? $row['value'] ?? ''));
    if ($label === '') continue;
    $cleanRows[] = [
        'label' => $label,
        'value' => trim((string)($row['value'] ?? $label)),
        'id' => max(0, (int)($row['id'] ?? 0)),
        'slug' => trim((string)($row['slug'] ?? $row['key'] ?? '')),
        'count' => isset($row['count']) && $row['count'] !== null ? max(0, (int)$row['count']) : null,
    ];
}
$rows = $cleanRows;

$statusLabels = [
    'live' => 'داده زنده منبع',
    'live_cached' => 'داده زنده کش‌شده',
    'fallback_snapshot' => 'نسخه مرجع پایدار',
    'database_cache' => 'دیتابیس سایت (کش ۳۰ دقیقه‌ای)',
    'cached' => 'داده کش‌شده',
];
$dataStatusLabel = $statusLabels[$dataStatus] ?? 'داده واقعی آرشیو';

$showCounts = bm_site_bool('categories_show_counts', true);
$showImages = bm_site_bool('categories_show_images', true);
$inlineSearch = bm_site_bool('categories_inline_search_enabled', true);
$pageTitle = trim((string)bm_site_get('categories_title_fa', 'دسته‌بندی بر اساس ژانر')) ?: 'دسته‌بندی بر اساس ژانر';
$pageDescription = trim((string)bm_site_get('categories_description_fa', 'ژانر مورد علاقه‌ات را از آرشیو واقعی انتخاب کن و مستقیم وارد نتیجه‌ها شو.'));
$archiveSearch = $archive === 1 ? 'arc1' : ($archive === 3 ? 'arc3' : ($archive === 2 ? 'local' : ''));
$archiveLabels = [0=>'آرشیوی برای حساب شما فعال نیست', 1=>'آرشیو ۱', 2=>'آرشیو ۲', 3=>'آرشیو ۳'];
$typeLabels = ['all'=>'همه آثار', 'movie'=>'فیلم‌ها', 'series'=>'سریال‌ها'];
?>
<!doctype html>
<html lang="<?= bm_cat_h($userLang) ?>" dir="<?= $userLang === 'fa' ? 'rtl' : 'ltr' ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
    <meta name="theme-color" content="#05050a">
    <title>ژانرهای فیلم و سریال | <?= bm_cat_h((string)bm_site_get('site_name_fa', 'بانک مووی')) ?></title>
    <link rel="stylesheet" href="/assets/css/bm-global.css">
    <link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=146">
    <?= bm_site_typography_head_markup() ?>
    <style>
        :root{--cat-accent:<?= bm_cat_h((string)bm_site_get('accent_color','#2f7cff')) ?>;--cat-accent-rgb:47,124,255}
        *{box-sizing:border-box}body{margin:0;min-height:100vh;background:#030409;color:#fff}.bm-cat-wrap{width:min(1320px,calc(100% - 30px));margin:108px auto 0;padding-bottom:70px}.bm-cat-hero{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.075);border-radius:30px;padding:34px;background:radial-gradient(circle at 13% 0,color-mix(in srgb,var(--cat-accent) 27%,transparent),transparent 40%),radial-gradient(circle at 91% 110%,rgba(139,92,246,.2),transparent 38%),linear-gradient(145deg,rgba(17,18,31,.97),rgba(5,6,12,.99));box-shadow:0 28px 80px rgba(0,0,0,.28);margin-bottom:22px}.bm-cat-kicker{display:inline-flex;align-items:center;gap:8px;color:color-mix(in srgb,var(--cat-accent) 80%,#fff);font-size:11px;font-weight:900;letter-spacing:.08em;margin-bottom:12px}.bm-cat-kicker:before{content:"";width:26px;height:2px;border-radius:3px;background:currentColor;box-shadow:0 0 16px currentColor}.bm-cat-hero h1{font-size:clamp(27px,4vw,42px);line-height:1.35;margin:0 0 9px;font-weight:950}.bm-cat-hero p{max-width:700px;color:rgba(255,255,255,.58);margin:0;font-size:13px;line-height:2}.bm-cat-controls{display:flex;align-items:center;justify-content:space-between;gap:18px;flex-wrap:wrap;margin-top:25px}.bm-archive-tabs,.bm-media-tabs{display:inline-flex;gap:5px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);padding:5px;border-radius:17px}.bm-archive-tabs a,.bm-media-tabs a{min-width:104px;text-align:center;padding:11px 16px;border-radius:12px;color:rgba(255,255,255,.64);text-decoration:none;font-size:12px;font-weight:900;transition:.2s}.bm-archive-tabs a:hover,.bm-media-tabs a:hover{color:#fff;background:rgba(255,255,255,.07)}.bm-archive-tabs a.active,.bm-media-tabs a.active{color:#fff;background:linear-gradient(135deg,var(--cat-accent),color-mix(in srgb,var(--cat-accent) 62%,#a855f7));box-shadow:0 9px 28px color-mix(in srgb,var(--cat-accent) 25%,transparent)}.bm-category-panel{border:1px solid rgba(255,255,255,.07);border-radius:26px;background:linear-gradient(180deg,rgba(15,16,26,.9),rgba(6,7,12,.96));padding:20px}.bm-cat-head{display:flex;align-items:center;justify-content:space-between;gap:18px;margin:0 2px 17px}.bm-cat-title-row{display:flex;align-items:center;gap:12px}.bm-cat-title-icon{width:43px;height:43px;border-radius:14px;display:grid;place-items:center;color:var(--cat-accent);background:color-mix(in srgb,var(--cat-accent) 12%,transparent);border:1px solid color-mix(in srgb,var(--cat-accent) 23%,transparent)}.bm-cat-title-icon svg{width:21px}.bm-cat-head h2{font-size:20px;margin:0}.bm-cat-meta{margin-top:4px;font-size:11px;color:rgba(255,255,255,.44)}.bm-cat-search{position:relative;width:min(330px,100%)}.bm-cat-search svg{position:absolute;right:14px;top:50%;width:17px;transform:translateY(-50%);color:rgba(255,255,255,.4)}.bm-cat-search input{width:100%;height:45px;border-radius:14px;border:1px solid rgba(255,255,255,.09);background:rgba(255,255,255,.045);color:#fff;padding:0 43px 0 14px;outline:none;font-size:12px}.bm-cat-search input:focus{border-color:color-mix(in srgb,var(--cat-accent) 52%,transparent);box-shadow:0 0 0 3px color-mix(in srgb,var(--cat-accent) 10%,transparent)}.bm-genre-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.bm-genre-card{position:relative;display:block;min-height:178px;overflow:hidden;border-radius:20px;border:1px solid rgba(255,255,255,.075);background:linear-gradient(145deg,#141623,#090a11);text-decoration:none;color:#fff;isolation:isolate;transition:transform .22s ease,border-color .22s ease,box-shadow .22s ease}.bm-genre-card:hover{transform:translateY(-5px);border-color:color-mix(in srgb,var(--cat-accent) 46%,transparent);box-shadow:0 20px 50px rgba(0,0,0,.42)}.bm-genre-card img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;transition:transform .5s ease,filter .3s ease}.bm-genre-card:hover img{transform:scale(1.06);filter:saturate(1.15)}.bm-genre-card:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(3,4,9,.05) 10%,rgba(3,4,9,.2) 45%,rgba(3,4,9,.97) 100%)}.bm-genre-card.no-image:before{content:"";position:absolute;inset:-25%;background:radial-gradient(circle,var(--cat-accent),transparent 62%);opacity:.16;filter:blur(25px)}.bm-genre-top{position:absolute;z-index:2;top:13px;right:13px;left:13px;display:flex;align-items:center;justify-content:space-between;gap:8px}.bm-source-badge,.bm-count-badge{padding:5px 9px;border-radius:999px;font-size:9px;font-weight:900;backdrop-filter:blur(12px);border:1px solid rgba(255,255,255,.1)}.bm-source-badge{background:rgba(5,6,12,.58);color:rgba(255,255,255,.72)}.bm-count-badge{background:color-mix(in srgb,var(--cat-accent) 19%,rgba(5,6,12,.62));color:#fff}.bm-genre-info{position:absolute;z-index:2;inset:auto 16px 15px}.bm-genre-info strong{display:block;font-size:18px;margin-bottom:6px;font-weight:950}.bm-genre-info span{font-size:10px;color:rgba(255,255,255,.5)}.bm-genre-line{width:42px;height:3px;border-radius:5px;background:var(--cat-accent);margin-top:11px;box-shadow:0 0 15px color-mix(in srgb,var(--cat-accent) 68%,transparent);transition:width .25s}.bm-genre-card:hover .bm-genre-line{width:72px}.bm-empty{grid-column:1/-1;text-align:center;padding:70px 20px;color:rgba(255,255,255,.5)}.bm-empty strong{display:block;color:#fff;font-size:18px;margin-bottom:8px}.bm-card-hidden{display:none!important}

        /* v147: category hub with real Genres + Collections destinations */
        .bm-category-hub{position:relative;overflow:hidden;border:1px solid rgba(255,255,255,.075);border-radius:30px;padding:30px;background:radial-gradient(circle at 12% 0,rgba(124,58,237,.22),transparent 38%),radial-gradient(circle at 92% 100%,rgba(47,124,255,.18),transparent 42%),linear-gradient(145deg,rgba(14,15,28,.98),rgba(4,5,11,.99));box-shadow:0 28px 80px rgba(0,0,0,.32);margin-bottom:22px}
        .bm-category-hub:before{content:"";position:absolute;inset:-45% 25% auto -20%;height:360px;background:radial-gradient(circle,rgba(168,85,247,.16),transparent 65%);pointer-events:none}
        .bm-category-hub-copy{position:relative;z-index:1;text-align:center;margin:0 auto 24px;max-width:780px}.bm-category-hub-copy h1{font-size:clamp(28px,4vw,44px);line-height:1.35;margin:0 0 8px;font-weight:950}.bm-category-hub-copy p{margin:0;color:rgba(255,255,255,.58);font-size:13px;line-height:2}.bm-category-hub-copy .bm-cat-kicker{justify-content:center}
        .bm-category-entry-grid{position:relative;z-index:1;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
        .bm-category-entry{position:relative;display:block;aspect-ratio:16/9;min-height:270px;overflow:hidden;border-radius:25px;border:1px solid rgba(255,255,255,.11);background:#080914;color:#fff;text-decoration:none;isolation:isolate;box-shadow:0 18px 45px rgba(0,0,0,.28);transform:translateZ(0);transition:transform .28s ease,border-color .28s ease,box-shadow .28s ease}
        .bm-category-entry:hover{transform:translateY(-7px);border-color:rgba(181,119,255,.58);box-shadow:0 28px 70px rgba(0,0,0,.48),0 0 0 1px rgba(139,92,246,.13)}
        .bm-category-entry img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;transition:transform .65s cubic-bezier(.2,.8,.2,1),filter .35s ease}.bm-category-entry:hover img{transform:scale(1.045);filter:saturate(1.08) contrast(1.04)}
        .bm-category-entry:before{content:"";position:absolute;z-index:1;inset:0;background:linear-gradient(180deg,rgba(2,3,9,.04) 35%,rgba(2,3,9,.24) 62%,rgba(2,3,9,.94) 100%)}
        .bm-category-entry:after{content:"";position:absolute;z-index:1;inset:0;border-radius:inherit;box-shadow:inset 0 0 55px rgba(117,62,190,.15);pointer-events:none}
        .bm-category-entry-top{position:absolute;z-index:2;top:14px;right:14px;display:inline-flex;align-items:center;gap:7px;padding:7px 11px;border-radius:999px;background:rgba(4,5,13,.62);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(14px);font-size:10px;font-weight:900;color:rgba(255,255,255,.86)}
        .bm-category-entry-top i{width:7px;height:7px;border-radius:50%;background:#a855f7;box-shadow:0 0 14px #a855f7}
        .bm-category-entry-footer{position:absolute;z-index:2;right:16px;left:16px;bottom:15px;display:flex;align-items:center;justify-content:space-between;gap:12px}
        .bm-category-entry-caption{min-width:0}.bm-category-entry-caption strong{display:block;font-size:15px;font-weight:950;margin-bottom:4px}.bm-category-entry-caption span{display:block;color:rgba(255,255,255,.58);font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .bm-category-entry-action{flex:0 0 auto;display:inline-flex;align-items:center;gap:7px;padding:9px 12px;border-radius:12px;background:linear-gradient(135deg,#7c3aed,#a855f7);box-shadow:0 9px 24px rgba(124,58,237,.32);font-size:10px;font-weight:950;color:#fff}.bm-category-entry-action svg{width:15px;height:15px;transition:transform .25s}.bm-category-entry:hover .bm-category-entry-action svg{transform:translateX(-3px)}
        .bm-category-panel{scroll-margin-top:100px}.bm-cat-controls-inside{margin:0 0 20px;padding-bottom:18px;border-bottom:1px solid rgba(255,255,255,.065)}

        @media(max-width:1030px){.bm-category-entry{min-height:230px}.bm-genre-grid{grid-template-columns:repeat(3,1fr)}}
        @media(max-width:760px){.bm-cat-wrap{margin-top:78px;width:calc(100% - 20px);padding-bottom:100px}.bm-category-hub{padding:18px 12px;border-radius:23px}.bm-category-hub-copy{margin-bottom:16px;padding:0 6px}.bm-category-hub-copy h1{font-size:27px}.bm-category-entry-grid{grid-template-columns:1fr;gap:13px}.bm-category-entry{min-height:0;border-radius:19px}.bm-category-entry-footer{right:12px;left:12px;bottom:11px}.bm-category-entry-caption strong{font-size:13px}.bm-category-entry-action{padding:8px 10px}.bm-cat-hero{padding:23px 17px;border-radius:23px}.bm-cat-hero h1{font-size:25px}.bm-cat-controls{display:grid;gap:10px}.bm-archive-tabs,.bm-media-tabs{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;width:100%}.bm-archive-tabs a,.bm-media-tabs a{min-width:0;padding:10px 6px}.bm-category-panel{padding:13px;border-radius:21px}.bm-cat-head{align-items:stretch;flex-direction:column}.bm-cat-search{width:100%}.bm-genre-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.bm-genre-card{min-height:164px;border-radius:17px}.bm-genre-info{inset:auto 13px 13px}.bm-genre-info strong{font-size:15px}.bm-source-badge{display:none}}
        @media(max-width:390px){.bm-genre-grid{grid-template-columns:1fr}.bm-genre-card{min-height:150px}}
    </style>

<style id="bm-v56-mobile-nav-safe-space">
@media (max-width:991px){
  body{padding-bottom:max(92px,calc(78px + env(safe-area-inset-bottom,0px)))!important}
}
</style>

</head>
<body>
<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>

<main class="bm-cat-wrap">
    <section class="bm-cat-hero" aria-labelledby="genresPageTitle">
        <span class="bm-cat-kicker">GENRES DISCOVERY</span>
        <h1 id="genresPageTitle">ژانرهای فیلم و سریال</h1>
        <p>آرشیو و نوع محتوا را انتخاب کن؛ سپس با انتخاب هر ژانر مستقیماً وارد نتیجه‌های واقعی همان منبع شو.</p>
    </section>

    <section class="bm-category-panel" id="genre-browser">
        <div class="bm-cat-controls bm-cat-controls-inside">
            <nav class="bm-archive-tabs" aria-label="انتخاب آرشیو">
                <?php foreach ($categoryVisible as $id => $visible): if (!$visible) continue; ?>
                    <a href="/genres?archive=<?= (int)$id ?>&type=<?= $id === 3 ? 'all' : 'movie' ?>#genre-browser" class="<?= $archive === $id ? 'active' : '' ?>"><?= bm_cat_h($archiveLabels[$id]) ?></a>
                <?php endforeach; ?>
            </nav>
            <nav class="bm-media-tabs" aria-label="نوع محتوا">
                <?php foreach (['all','movie','series'] as $mediaType): ?>
                    <a href="/genres?archive=<?= (int)$archive ?>&type=<?= bm_cat_h($mediaType) ?>#genre-browser" class="<?= $type === $mediaType ? 'active' : '' ?>"><?= bm_cat_h($typeLabels[$mediaType]) ?></a>
                <?php endforeach; ?>
            </nav>
        </div>
        <header class="bm-cat-head">
            <div class="bm-cat-title-row">
                <span class="bm-cat-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/></svg></span>
                <div><h2>ژانرهای <?= bm_cat_h($archiveLabels[$archive]) ?> · <?= bm_cat_h($typeLabels[$type]) ?></h2><div class="bm-cat-meta"><span id="visibleGenreCount"><?= count($rows) ?></span> ژانر واقعی · منبع شمارش: <?= bm_cat_h($dataStatusLabel) ?></div></div>
            </div>
            <?php if ($inlineSearch): ?><label class="bm-cat-search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="7"/><line x1="20" y1="20" x2="16.2" y2="16.2"/></svg><input id="genreFilterInput" type="search" placeholder="جستجو بین ژانرها..." autocomplete="off"></label><?php endif; ?>
        </header>

        <div class="bm-genre-grid" id="genreGrid">
            <?php foreach ($rows as $row):
                $label = (string)$row['label'];
                $genreValue = $archive === 3 ? (string)$row['value'] : $label;
                $query = ['archive'=>$archiveSearch, 'type'=>$type, 'genre'=>$genreValue];
                if ($archive === 1 && (int)$row['id'] > 0) $query['genre_id'] = (int)$row['id'];
                $url = '/search?' . http_build_query($query);
                $imageKey = bm_cat_image_key($label, (string)$row['slug']);
                $imageArchive = $archive === 1 ? 1 : 2;
                $imagePath = $imageKey === 'default' ? '/assets/genres/default.svg' : "/assets/genres/archive{$imageArchive}/{$imageKey}.webp";
            ?>
                <a class="bm-genre-card <?= !$showImages ? 'no-image' : '' ?>" href="<?= bm_cat_h($url) ?>" data-genre-card data-search="<?= bm_cat_h(bm_cat_key($label . ' ' . $row['slug'])) ?>">
                    <?php if ($showImages): ?><img src="<?= bm_cat_h($imagePath) ?>" alt="<?= bm_cat_h($label) ?>" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/genres/default.svg';"><?php endif; ?>
                    <div class="bm-genre-top"><span class="bm-source-badge"><?= bm_cat_h($archiveLabels[$archive]) ?></span><?php if ($showCounts && $row['count'] !== null): ?><span class="bm-count-badge"><?= number_format((int)$row['count']) ?> اثر</span><?php endif; ?></div>
                    <div class="bm-genre-info"><strong><?= bm_cat_h($label) ?></strong><span><?= bm_cat_h($typeLabels[$type]) ?> · مشاهده نتیجه‌ها</span><div class="bm-genre-line"></div></div>
                </a>
            <?php endforeach; ?>
            <div class="bm-empty <?= $rows ? 'bm-card-hidden' : '' ?>" id="genreEmptyState"><strong>ژانری پیدا نشد</strong><span>عبارت دیگری را امتحان کن یا آرشیو را تغییر بده.</span></div>
        </div>
    </section>
</main>

<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>
<script>
(function(){
    var input=document.getElementById('genreFilterInput');
    if(!input)return;
    var cards=Array.prototype.slice.call(document.querySelectorAll('[data-genre-card]'));
    var empty=document.getElementById('genreEmptyState');
    var count=document.getElementById('visibleGenreCount');
    function normalize(value){return String(value||'').toLowerCase().replace(/[\u200c\u200f]/g,' ').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/\s+/g,' ').trim();}
    input.addEventListener('input',function(){
        var needle=normalize(input.value),visible=0;
        cards.forEach(function(card){var show=!needle||normalize(card.getAttribute('data-search')).indexOf(needle)!==-1;card.classList.toggle('bm-card-hidden',!show);if(show)visible++;});
        if(count)count.textContent=String(visible);
        if(empty)empty.classList.toggle('bm-card-hidden',visible!==0);
    });
})();
</script>
</body>
</html>
