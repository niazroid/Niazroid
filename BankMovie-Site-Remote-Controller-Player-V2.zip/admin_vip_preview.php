<?php
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
header('Location: /vip');
exit;
