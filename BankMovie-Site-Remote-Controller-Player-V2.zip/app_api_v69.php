<?php
/**
 * Fresh App API entrypoint for V69.
 * The implementation remains in app_api.php; this separate URL bypasses
 * stale client/CDN endpoint caches without changing the Android APK.
 */
require __DIR__ . '/app_api.php';
