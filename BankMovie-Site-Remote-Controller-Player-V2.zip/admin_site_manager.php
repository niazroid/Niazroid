<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/site_content_control.php';
require_once __DIR__ . '/includes/bankmovie_comment_upgrade.php';

require_admin();
admin_enforce_csrf();
if (function_exists('bm_site_comment_upgrade_schema')) { bm_site_comment_upgrade_schema($pdo); }

$csrf = admin_csrf_token();
$schema = bm_site_setting_schema();
$active = preg_replace('/[^a-z0-9_]/i', '', (string)($_GET['group'] ?? $_POST['settings_group'] ?? 'general')) ?: 'general';
if (!isset($schema[$active])) {
    $active = 'general';
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = (string)($_POST['action'] ?? 'save_group');
    $targetGroup = preg_replace('/[^a-z0-9_]/i', '', (string)($_POST['settings_group'] ?? $active)) ?: 'general';
    if (!isset($schema[$targetGroup])) {
        $targetGroup = 'general';
    }

    $ok = false;
    $status = 'error';
    if ($action === 'report_status') {
        $reportId = max(0, (int)($_POST['report_id'] ?? 0));
        $reportStatus = strtolower(trim((string)($_POST['report_status'] ?? 'resolved')));
        if (!in_array($reportStatus, ['open','resolved','dismissed'], true)) $reportStatus = 'resolved';
        try {
            $adminUser = admin_current_user();
            $stmt = $pdo->prepare('UPDATE comment_reports SET status=?, reviewed_at=NOW(), reviewed_by=? WHERE id=?');
            $ok = $stmt->execute([$reportStatus, (int)($adminUser['id'] ?? 0), $reportId]);
            $status = $ok ? 'report_updated' : 'error';
        } catch (Throwable $e) { $ok = false; $status = 'error'; }
    } elseif ($action === 'report_delete') {
        $reportId = max(0, (int)($_POST['report_id'] ?? 0));
        try { $stmt = $pdo->prepare('DELETE FROM comment_reports WHERE id=?'); $ok = $stmt->execute([$reportId]); $status = $ok ? 'report_deleted' : 'error'; }
        catch (Throwable $e) { $ok = false; $status = 'error'; }
    } elseif ($action === 'enable_all') {
        $ok = bm_site_enable_all_features();
        $status = $ok ? 'enabled_all' : 'error';
    } elseif ($action === 'reset') {
        $ok = bm_site_reset_settings();
        $status = $ok ? 'reset' : 'error';
    } else {
        $ok = bm_site_save_group_settings($targetGroup, $_POST);
        $status = $ok ? 'saved' : 'error';
    }

    if (!headers_sent()) {
        header('Location: admin_site_manager.php?group=' . rawurlencode($targetGroup) . '&status=' . rawurlencode($status) . (str_starts_with($status, 'report_') ? '#commentReports' : '#settingsEditor'));
        exit;
    }
}

$settings = bm_site_settings(true);
$summary = bm_site_settings_summary();
$status = (string)($_GET['status'] ?? '');
$statusMessages = [
    'saved' => ['success', 'تنظیمات این بخش ذخیره شد؛ تنظیمات بخش‌های دیگر بدون هیچ تغییری حفظ شدند.'],
    'enabled_all' => ['success', 'همه قابلیت‌ها و بخش‌های سایت فعال شدند.'],
    'reset' => ['success', 'همه تنظیمات به پیش‌فرض کامل و فعال برگشتند.'],
    'report_updated' => ['success', 'وضعیت گزارش نظر به‌روزرسانی شد.'],
    'report_deleted' => ['success', 'گزارش نظر حذف شد.'],
    'error' => ['error', 'ذخیره انجام نشد. دسترسی نوشتن پوشه خصوصی سایت را بررسی کن.'],
];

function sm_table_exists(PDO $pdo, string $table): bool
{
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return false;
    try {
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?');
        $stmt->execute([$table]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Throwable $e) { return false; }
}
function sm_count(PDO $pdo, string $table, string $where = '1=1'): int
{
    if (!sm_table_exists($pdo, $table)) return 0;
    try { return (int)$pdo->query("SELECT COUNT(*) FROM `{$table}` WHERE {$where}")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}

$pendingComments = sm_count($pdo, 'comments', "LOWER(TRIM(CAST(status AS CHAR)))='pending'")
    + sm_count($pdo, 'archive1_comments', "LOWER(TRIM(CAST(status AS CHAR)))='pending'");
$openCommentReports = sm_count($pdo, 'comment_reports', "LOWER(TRIM(CAST(status AS CHAR)))='open'");
$commentReportRows = [];
if (sm_table_exists($pdo, 'comment_reports')) {
    try {
        $stmt = $pdo->query("SELECT cr.*, COALESCE(u.username,'کاربر') reporter_name FROM comment_reports cr LEFT JOIN users u ON u.id=cr.reporter_user_id ORDER BY (cr.status='open') DESC, cr.created_at DESC LIMIT 12");
        $commentReportRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($commentReportRows as &$reportRow) {
            $table = ((int)($reportRow['archive_no'] ?? 1) === 1) ? 'archive1_comments' : 'comments';
            $reportRow['comment_excerpt'] = ''; $reportRow['comment_author'] = '';
            if (sm_table_exists($pdo, $table)) {
                try { $cs=$pdo->prepare("SELECT comment,username FROM `{$table}` WHERE id=? LIMIT 1"); $cs->execute([(int)$reportRow['comment_id']]); $commentData=$cs->fetch(PDO::FETCH_ASSOC) ?: []; $reportRow['comment_excerpt']=(string)($commentData['comment']??''); $reportRow['comment_author']=(string)($commentData['username']??''); } catch(Throwable $e) {}
            }
        }
        unset($reportRow);
    } catch (Throwable $e) { $commentReportRows = []; }
}
$activeBanners = sm_count($pdo, 'admin_banners', 'is_active=1');
$totalBanners = sm_count($pdo, 'admin_banners');
$usersCount = sm_count($pdo, 'users');
$requestsCount = sm_count($pdo, 'movie_requests', "LOWER(TRIM(CAST(status AS CHAR))) IN ('pending','new','0')");
$storiesCount = sm_count($pdo, 'stories', 'is_active=1');
$slidesCount = sm_count($pdo, 'slider_slides', 'is_active=1');
$collectionsCount = sm_count($pdo, 'collections');
$watchPartyActiveRooms = sm_count($pdo, 'watch_party_rooms', 'expires_at>NOW()');
$watchPartyMasterEnabled = function_exists('bm_watch_party_is_enabled') ? bm_watch_party_is_enabled() : bm_site_bool('watch_party_enabled', false);
$watchPartyPreviewEnabled = function_exists('bm_watch_party_admin_preview_enabled') ? bm_watch_party_admin_preview_enabled() : bm_site_bool('watch_party_admin_preview_enabled', false);
$ykEnabled = function_exists('bm_yektanet_get_settings') ? !empty(bm_yektanet_get_settings()['enabled']) : false;
$operationCards = [
    ['title'=>'مدیریت و تأیید نظرات','desc'=>'دیدگاه‌های دیتابیس و آرشیو ۱، پاسخ‌ها، ویرایش، رد و حذف','icon'=>'fa-comments','value'=>$pendingComments,'suffix'=>'در انتظار','href'=>'admin.php?tab=pending#commentsSection','tone'=>'cyan'],
    ['title'=>'استیکر و گیف','desc'=>'مدیریت پک‌ها، مسیر پوشه، فرمت، آپلود و حذف رسانه برای Watch Party و دیدگاه‌های عمومی','icon'=>'fa-note-sticky','value'=>'FREE','suffix'=>'کامنت عمومی + چت VIP','href'=>'admin_stickers.php','tone'=>'purple'],
    ['title'=>'گزارش‌های تخلف نظرات','desc'=>'بررسی گزارش اسپم، توهین، اسپویلر و محتوای نامناسب','icon'=>'fa-triangle-exclamation','value'=>$openCommentReports,'suffix'=>'گزارش باز','href'=>'#commentReports','tone'=>'red'],
    ['title'=>'بنرهای تبلیغاتی داخلی','desc'=>'ساخت، زمان‌بندی، جایگاه، تصویر، لینک و فعال‌سازی بنرها','icon'=>'fa-rectangle-ad','value'=>$activeBanners.' / '.$totalBanners,'suffix'=>'فعال / کل','href'=>'admin.php#bannersSection','tone'=>'purple'],
    ['title'=>'تبلیغات یکتانت','desc'=>'مدیریت کد ناشر، صفحات، دستگاه‌ها و تمام جایگاه‌های تبلیغ','icon'=>'fa-bullhorn','value'=>$ykEnabled?'فعال':'خاموش','suffix'=>'وضعیت سرویس','href'=>'admin_control_center.php','tone'=>'gold'],
    ['title'=>'حمایت مالی','desc'=>'متن، لینک پرداخت، رنگ و محل نمایش کارت حمایت در تمام صفحات','icon'=>'fa-heart','value'=>bm_site_bool('support_enabled',true)?'فعال':'خاموش','suffix'=>'تنظیمات زنده','href'=>'admin_site_manager.php?group=support','tone'=>'red'],
    ['title'=>'سئو و سرچ کنسول','desc'=>'Canonical، عنوان‌ها، توضیحات، Schema، Sitemap و کدهای تأیید گوگل و بینگ','icon'=>'fa-magnifying-glass-chart','value'=>bm_site_bool('seo_enabled',true)?'فعال':'خاموش','suffix'=>'SEO مرکزی','href'=>'admin_site_manager.php?group=seo','tone'=>'blue'],
    ['title'=>'لودینگ‌ها و Skeletonها','desc'=>'مدل لودینگ، لوگو، رنگ، متن، زمان نمایش و اسکلت کارت‌های تمام صفحات','icon'=>'fa-spinner','value'=>bm_site_bool('loading_enabled',true)?'فعال':'خاموش','suffix'=>(string)bm_site_get('loading_style','logo'),'href'=>'admin_site_manager.php?group=loading','tone'=>'cyan'],
    ['title'=>'اسلایدر اصلی','desc'=>'اسلایدها، تصویر، لینک، امتیاز، ترتیب و وضعیت انتشار','icon'=>'fa-images','value'=>$slidesCount,'suffix'=>'اسلاید فعال','href'=>'admin_slider.php','tone'=>'blue'],
    ['title'=>'استوری‌ها','desc'=>'مدیریت استوری‌های صفحه اصلی و ترتیب نمایش','icon'=>'fa-circle-play','value'=>$storiesCount,'suffix'=>'استوری فعال','href'=>'admin.php#storiesSection','tone'=>'cyan'],
    ['title'=>'کالکشن‌ها','desc'=>'ساخت، ویرایش و مدیریت محتوای مجموعه‌های سینمایی','icon'=>'fa-layer-group','value'=>$collectionsCount,'suffix'=>'کالکشن','href'=>'admin_collections.php','tone'=>'purple'],
    ['title'=>'کاربران و دسترسی‌ها','desc'=>'حساب‌ها، نقش‌ها، وضعیت کاربران و فعالیت‌های پروفایل','icon'=>'fa-users-gear','value'=>$usersCount,'suffix'=>'کاربر','href'=>'admin.php#usersSection','tone'=>'blue'],
    ['title'=>'Watch Party آزمایشی','desc'=>'اتاق‌های VIP، پاکسازی چهارساعته، پیام‌ها و همگام‌سازی مخفی','icon'=>'fa-people-group','value'=>$watchPartyMasterEnabled?'فعال':($watchPartyPreviewEnabled?'تست مدیر':'مخفی'),'suffix'=>$watchPartyActiveRooms.' اتاق','href'=>'admin_watch_party.php','tone'=>'purple'],
    ['title'=>'درخواست فیلم و سریال','desc'=>'بررسی درخواست‌های کاربران و تغییر وضعیت رسیدگی','icon'=>'fa-inbox','value'=>$requestsCount,'suffix'=>'در انتظار','href'=>'admin.php#requestsSection','tone'=>'gold'],
    ['title'=>'اعلان‌های کاربران','desc'=>'ارسال اعلان، متن پیام و مدیریت اطلاع‌رسانی‌ها','icon'=>'fa-bell','value'=>'مرکز','suffix'=>'ارسال و مدیریت','href'=>'admin.php#notifSection','tone'=>'red'],
    ['title'=>'مدیریت اپلیکیشن','desc'=>'نسخه‌ها، APK، ZIP، تصاویر، تغییرات و لینک‌های دانلود','icon'=>'fa-mobile-screen-button','value'=>'APP','suffix'=>'انتشار نسخه','href'=>'bm_admin.php','tone'=>'cyan'],
    ['title'=>'بنر اپلیکیشن موبایل','desc'=>'نمایش یا مخفی‌کردن کارت نصب اپ درست بالای منوی پایین موبایل','icon'=>'fa-window-maximize','value'=>bm_site_bool('app_bottom_nav_banner_enabled',false)?'فعال':'غیرفعال','suffix'=>'کنترل نمایش','href'=>'admin_site_manager.php?group=application#settingsEditor','tone'=>'blue'],
    ['title'=>'آرشیوها و APIها','desc'=>'وضعیت آرشیوها، اتصال API و تنظیمات خروجی محتوا','icon'=>'fa-plug-circle-bolt','value'=>'API','suffix'=>'کنترل منابع','href'=>'api_manager.php','tone'=>'purple'],
];

function sm_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function sm_group_icon(string $id): string
{
    return [
        'general' => '✦',
        'seo' => 'SEO',
        'typography' => 'Aa',
        'loading' => '◌',
        'header' => '▤',
        'categories' => '▦',
        'mobile_nav' => '⌁',
        'footer' => '◉',
        'home' => '⌂',
        'movie_design' => '◈',
        'search' => '⌕',
        'player' => '▶',
        'application' => '⬇',
        'pwa' => '◆',
        'pages' => '▣',
        'actor_page' => '♙',
        'app_content' => '✎',
        'comments' => '☵',
        'support' => '♥',
        'advertising' => '▰',
        'promotion' => '✦',
        'profile_auth' => '♙',
        'watch_party' => 'VIP',
        'advanced' => '⚙',
    ][$id] ?? '•';
}

$activeGroup = $schema[$active];
$groupCheckboxes = [];
foreach (($activeGroup['fields'] ?? []) as $key => $field) {
    if (($field['type'] ?? 'text') === 'checkbox') {
        $groupCheckboxes[] = $key;
    }
}
$activeToggleCount = count($groupCheckboxes);
$activeEnabledCount = 0;
foreach ($groupCheckboxes as $toggleKey) {
    if (!empty($settings[$toggleKey])) {
        $activeEnabledCount++;
    }
}

function sm_group_icon_class(string $id): string
{
    return [
        'general' => 'fa-sliders',
        'typography' => 'fa-font',
        'loading' => 'fa-spinner',
        'header' => 'fa-window-maximize',
        'categories' => 'fa-table-cells-large',
        'mobile_nav' => 'fa-mobile-screen-button',
        'footer' => 'fa-window-minimize',
        'home' => 'fa-house',
        'movie_design' => 'fa-clapperboard',
        'search' => 'fa-magnifying-glass',
        'player' => 'fa-circle-play',
        'application' => 'fa-download',
        'pwa' => 'fa-globe',
        'pages' => 'fa-file-lines',
        'actor_page' => 'fa-user-tie',
        'app_content' => 'fa-mobile-screen',
        'comments' => 'fa-comments',
        'support' => 'fa-heart',
        'advertising' => 'fa-rectangle-ad',
        'promotion' => 'fa-bullhorn',
        'profile_auth' => 'fa-user-shield',
        'watch_party' => 'fa-people-group',
        'advanced' => 'fa-code',
    ][$id] ?? 'fa-gear';
}
?><!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="color-scheme" content="dark">
<title>مرکز مدیریت کامل سایت | BankMovie</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<link rel="stylesheet" href="/assets/css/bm-loading-manager-v14843.css?v=14843">
<style>
*{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg-primary:#05070d;--bg-secondary:#090d17;--surface:rgba(15,21,35,.72);--surface-hover:rgba(24,33,53,.86);--surface-strong:rgba(11,16,28,.94);
  --border:rgba(148,163,184,.14);--border-glow:rgba(45,212,191,.45);--text-primary:#f8fafc;--text-secondary:#a8b3cf;--muted:#64748b;
  --accent:#2dd4bf;--accent-dark:#0f766e;--accent-2:#8b5cf6;--accent-3:#38bdf8;--danger:#fb7185;--warning:#f59e0b;--info:#60a5fa;--success:#34d399;
  --radius-sm:14px;--radius-md:20px;--radius-lg:28px;--shadow-soft:0 20px 60px rgba(0,0,0,.28);--shadow-hard:0 30px 90px rgba(0,0,0,.55);
  --transition:220ms cubic-bezier(.2,.8,.2,1)
}
html{scroll-behavior:smooth;scrollbar-color:rgba(45,212,191,.55) rgba(255,255,255,.04)}
body{min-height:100vh;overflow-x:hidden;font-family:'Vazirmatn',Tahoma,Arial,sans-serif;color:var(--text-primary);background:radial-gradient(circle at 82% 6%,rgba(45,212,191,.16),transparent 28rem),radial-gradient(circle at 14% 16%,rgba(139,92,246,.15),transparent 26rem),radial-gradient(circle at 34% 92%,rgba(56,189,248,.1),transparent 24rem),linear-gradient(135deg,#05070d 0%,#070a12 45%,#0a0f1d 100%);letter-spacing:-.015em}
body::before{content:"";position:fixed;inset:0;pointer-events:none;background:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:42px 42px;mask-image:radial-gradient(circle at center,#000 0%,transparent 72%);opacity:.5;animation:gridDrift 28s linear infinite}
body::after{content:"";position:fixed;right:-18%;bottom:-30%;width:58vw;height:58vw;border-radius:50%;pointer-events:none;background:conic-gradient(from 120deg,rgba(45,212,191,.16),rgba(139,92,246,.13),rgba(56,189,248,.12),rgba(45,212,191,.16));filter:blur(72px);opacity:.55;animation:auroraSpin 24s linear infinite}
@keyframes gridDrift{to{transform:translate3d(42px,42px,0)}}@keyframes auroraSpin{to{transform:rotate(360deg) scale(1.04)}}
::selection{background:rgba(45,212,191,.35);color:#fff}
button,input,textarea,select{font:inherit}
a{color:inherit}

.sidebar{position:fixed;right:0;top:0;width:292px;height:100vh;z-index:100;padding:26px 18px;overflow-y:auto;background:linear-gradient(180deg,rgba(9,13,24,.97),rgba(5,7,13,.94)),radial-gradient(circle at 40% 0%,rgba(45,212,191,.18),transparent 22rem);border-left:1px solid rgba(45,212,191,.25);box-shadow:-24px 0 80px rgba(0,0,0,.5);transition:var(--transition)}
.sidebar::before{content:"";position:absolute;inset:14px;border-radius:28px;border:1px solid rgba(255,255,255,.055);pointer-events:none}
.sidebar::-webkit-scrollbar{width:4px}.sidebar::-webkit-scrollbar-track{background:transparent}.sidebar::-webkit-scrollbar-thumb{background:var(--accent);border-radius:10px}
.sidebar-logo{position:relative;display:flex;align-items:center;gap:13px;margin-bottom:20px;padding:18px 16px 24px;border-bottom:1px solid rgba(255,255,255,.08);border-radius:24px;background:linear-gradient(135deg,rgba(255,255,255,.06),rgba(255,255,255,.015))}
.sidebar-logo i{width:48px;height:48px;display:grid;place-items:center;border-radius:18px;font-size:24px;color:#03120f;background:linear-gradient(135deg,var(--accent),var(--accent-3));box-shadow:0 16px 40px rgba(45,212,191,.25)}
.sidebar-logo h2{font-size:25px;line-height:1;font-weight:900;letter-spacing:-.04em;background:linear-gradient(135deg,var(--accent),var(--info));-webkit-background-clip:text;background-clip:text;color:transparent}
.sidebar-logo h2::after{content:"Admin Control";display:block;margin-top:8px;font-size:10px;font-weight:600;letter-spacing:.08em;text-transform:uppercase;color:var(--text-secondary)}
.sidebar-nav{position:relative;display:flex;flex-direction:column;gap:7px;padding:0 4px 96px}
.nav-section-label{padding:16px 13px 6px;color:#6f7d97;font-size:10px;font-weight:900;letter-spacing:.04em}
.sidebar-nav a{min-height:48px;padding:12px 14px;border:1px solid transparent;border-radius:17px;display:flex;align-items:center;gap:13px;color:#c8d1e6;text-decoration:none;font-size:13px;font-weight:650;transition:var(--transition)}
.sidebar-nav a i{width:22px;text-align:center;font-size:15px;color:rgba(45,212,191,.85)}
.sidebar-nav a .nav-badge{margin-right:auto;min-width:25px;padding:3px 7px;border-radius:999px;text-align:center;color:#95a4be;background:rgba(255,255,255,.055);font-size:10px}
.sidebar-nav a:hover,.sidebar-nav a.active{background:linear-gradient(90deg,rgba(45,212,191,.16),rgba(139,92,246,.08));color:#fff;border-color:rgba(45,212,191,.28);box-shadow:inset 0 0 0 1px rgba(255,255,255,.04),0 18px 40px rgba(0,0,0,.16);transform:translateX(-5px)}
.sidebar-nav a.active{border-right:3px solid var(--accent)}
.sidebar-footer{position:absolute;right:18px;left:18px;bottom:18px;padding:14px;border:1px solid rgba(255,255,255,.08);border-radius:22px;background:rgba(255,255,255,.035)}
.logout-btn{min-height:44px;padding:0 14px;display:flex;align-items:center;justify-content:center;gap:9px;border-radius:16px;color:#ffd9df;text-decoration:none;background:linear-gradient(135deg,rgba(251,113,133,.16),rgba(251,113,133,.08));border:1px solid rgba(251,113,133,.18)}
.sidebar-overlay{display:none;position:fixed;inset:0;z-index:98;background:rgba(2,6,23,.72);backdrop-filter:blur(4px)}
.menu-toggle{display:none;position:fixed;top:18px;right:18px;z-index:102;width:48px;height:48px;border:1px solid rgba(45,212,191,.32);border-radius:16px;color:var(--accent);background:rgba(8,12,21,.9);box-shadow:0 14px 34px rgba(0,0,0,.35);cursor:pointer}

.main-content{position:relative;z-index:1;margin-right:292px;padding:28px clamp(18px,2.4vw,38px) 60px}
.dashboard-hero{position:relative;display:grid;grid-template-columns:minmax(0,1.5fr) minmax(280px,.9fr);gap:22px;margin-bottom:24px;padding:clamp(22px,3vw,34px);overflow:hidden;border:1px solid rgba(255,255,255,.10);border-radius:34px;background:linear-gradient(135deg,rgba(15,23,42,.86),rgba(15,23,42,.52)),radial-gradient(circle at 12% 18%,rgba(139,92,246,.22),transparent 28rem),radial-gradient(circle at 88% 20%,rgba(45,212,191,.18),transparent 26rem);box-shadow:var(--shadow-soft);isolation:isolate}
.dashboard-hero::before{content:"";position:absolute;inset:-1px;z-index:-1;pointer-events:none;opacity:.26;background:linear-gradient(90deg,transparent,rgba(45,212,191,.48),transparent),linear-gradient(180deg,rgba(255,255,255,.10),transparent 44%)}
.hero-eyebrow{display:inline-flex;align-items:center;gap:9px;margin-bottom:14px;padding:8px 13px;border:1px solid rgba(45,212,191,.22);border-radius:999px;color:#c9fff8;background:rgba(45,212,191,.11);font-size:12px;font-weight:800}
.hero-eyebrow::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--success);box-shadow:0 0 16px var(--success)}
.hero-title{margin:0;font-size:clamp(28px,4vw,48px);line-height:1.15;font-weight:950;letter-spacing:-.055em}.hero-title span{background:linear-gradient(135deg,#fff,#99f6e4 45%,#bfdbfe 86%);-webkit-background-clip:text;background-clip:text;color:transparent}
.hero-subtitle{max-width:760px;margin:14px 0 22px;color:#bdc8df;font-size:14px;line-height:1.95}
.hero-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}
.hero-panel{align-self:stretch;display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:14px;border:1px solid rgba(255,255,255,.08);border-radius:26px;background:rgba(2,6,23,.36);backdrop-filter:blur(16px)}
.hero-mini-card{min-height:108px;padding:16px;border:1px solid rgba(255,255,255,.075);border-radius:20px;display:flex;flex-direction:column;justify-content:center;background:linear-gradient(145deg,rgba(255,255,255,.06),rgba(255,255,255,.015))}
.hero-mini-card i{margin-bottom:10px;color:var(--accent);font-size:20px}.hero-mini-card strong{font-size:24px;font-weight:900}.hero-mini-card span{margin-top:4px;color:var(--text-secondary);font-size:11px}

.btn{min-height:44px;padding:0 16px;border:1px solid var(--border);border-radius:15px;display:inline-flex;align-items:center;justify-content:center;gap:9px;color:#fff;background:rgba(255,255,255,.055);text-decoration:none;font-weight:800;cursor:pointer;transition:var(--transition)}
.btn:hover{transform:translateY(-2px);border-color:rgba(45,212,191,.38);background:rgba(45,212,191,.09);box-shadow:0 14px 28px rgba(0,0,0,.2)}
.btn-primary{border-color:transparent;color:#03120f;background:linear-gradient(135deg,var(--accent),var(--accent-3));box-shadow:0 14px 34px rgba(45,212,191,.22)}
.btn-outline{border-color:rgba(45,212,191,.28);color:#c9fff8;background:rgba(45,212,191,.07)}
.btn-danger{border-color:rgba(251,113,133,.28);color:#ffd6dd;background:rgba(251,113,133,.1)}
.btn-success{border-color:rgba(52,211,153,.28);color:#c7ffe8;background:rgba(52,211,153,.1)}
.btn-sm{min-height:38px;padding:0 12px;border-radius:12px;font-size:12px}

.notice{margin-bottom:20px;padding:15px 18px;border:1px solid rgba(52,211,153,.28);border-radius:18px;color:#c8f8df;background:linear-gradient(135deg,rgba(52,211,153,.11),rgba(45,212,191,.06));line-height:1.8;box-shadow:0 15px 40px rgba(0,0,0,.16)}
.notice.error{border-color:rgba(251,113,133,.3);color:#ffd1d8;background:rgba(251,113,133,.1)}
.stats-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px;margin-bottom:24px}
.stat-card{position:relative;min-height:126px;padding:20px;border:1px solid var(--border);border-radius:24px;overflow:hidden;background:linear-gradient(145deg,rgba(15,21,35,.82),rgba(9,13,24,.72));box-shadow:var(--shadow-soft)}
.stat-card::after{content:"";position:absolute;left:-25px;bottom:-38px;width:110px;height:110px;border-radius:50%;background:rgba(45,212,191,.12);filter:blur(12px)}
.stat-head{display:flex;align-items:center;justify-content:space-between;gap:12px;color:var(--text-secondary);font-size:12px;font-weight:700}.stat-icon{width:42px;height:42px;display:grid;place-items:center;border-radius:15px;color:var(--accent);background:rgba(45,212,191,.1);border:1px solid rgba(45,212,191,.18)}
.stat-number{display:block;margin-top:15px;font-size:28px;font-weight:950;letter-spacing:-.04em}.stat-number.good{color:var(--success)}.stat-number.warn{color:var(--warning)}

.admin-card{margin-bottom:22px;overflow:hidden;border:1px solid var(--border);border-radius:28px;background:linear-gradient(145deg,rgba(15,21,35,.82),rgba(9,13,24,.76));box-shadow:var(--shadow-soft)}
.card-header{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:21px 23px;border-bottom:1px solid rgba(255,255,255,.08);background:linear-gradient(180deg,rgba(255,255,255,.045),transparent)}
.card-title-wrap{display:flex;align-items:center;gap:14px}.card-title-icon{width:48px;height:48px;display:grid;place-items:center;border:1px solid rgba(45,212,191,.22);border-radius:17px;color:var(--accent);background:linear-gradient(135deg,rgba(45,212,191,.14),rgba(139,92,246,.08));font-size:19px}.card-title-wrap h2{margin:0 0 4px;font-size:20px;font-weight:900}.card-title-wrap p{margin:0;color:var(--text-secondary);font-size:12px;line-height:1.7}
.card-tools{display:flex;gap:8px;flex-wrap:wrap}.card-body{padding:20px}
.form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
.setting-field{min-width:0;padding:17px;border:1px solid rgba(255,255,255,.075);border-radius:20px;background:rgba(2,6,23,.3);transition:var(--transition)}
.setting-field:hover{border-color:rgba(45,212,191,.18);background:rgba(5,10,22,.5)}.setting-field:focus-within{border-color:rgba(45,212,191,.46);box-shadow:0 0 0 4px rgba(45,212,191,.07)}.setting-field.full{grid-column:1/-1}
.field-label{display:flex;align-items:center;gap:8px;margin-bottom:10px;color:#eef6ff;font-size:12px;font-weight:850}.field-label i{color:var(--accent);font-size:11px}.field-help{display:block;margin-top:9px;color:var(--text-secondary);font-size:11px;line-height:1.75}
input[type=text],input[type=url],input[type=color],input[type=number],select,textarea{width:100%;min-height:46px;padding:11px 13px;border:1px solid rgba(148,163,184,.17);border-radius:14px;outline:none;color:#fff;background:rgba(1,5,13,.72);transition:var(--transition)}
input[type=text]:focus,input[type=url]:focus,input[type=color]:focus,input[type=number]:focus,select:focus,textarea:focus{border-color:rgba(45,212,191,.55);box-shadow:0 0 0 4px rgba(45,212,191,.08)}input[type=color]{height:50px;padding:6px;cursor:pointer}textarea{min-height:120px;resize:vertical;line-height:1.9}
.toggle-setting{min-height:92px;display:flex;align-items:center;justify-content:space-between;gap:18px}.toggle-copy b{display:block;margin-bottom:6px;font-size:13px}.toggle-copy span{display:block;color:var(--text-secondary);font-size:11px;line-height:1.7}
.switch{position:relative;flex:0 0 auto;width:58px;height:32px}.switch input{position:absolute;opacity:0;pointer-events:none}.switch-track{position:absolute;inset:0;border:1px solid rgba(255,255,255,.10);border-radius:999px;background:#222b3c;box-shadow:inset 0 2px 8px rgba(0,0,0,.4);cursor:pointer;transition:var(--transition)}.switch-track::after{content:"";position:absolute;top:3px;right:4px;width:24px;height:24px;border-radius:50%;background:#fff;box-shadow:0 5px 14px rgba(0,0,0,.4);transition:var(--transition)}.switch input:checked + .switch-track{border-color:rgba(45,212,191,.5);background:linear-gradient(135deg,var(--accent-dark),var(--accent));box-shadow:0 0 20px rgba(45,212,191,.18)}.switch input:checked + .switch-track::after{right:29px;background:#eafffb}
.savebar{position:sticky;bottom:12px;z-index:12;margin:0 16px 16px;padding:14px 16px;border:1px solid rgba(45,212,191,.2);border-radius:20px;display:flex;align-items:center;justify-content:space-between;gap:16px;background:rgba(5,9,18,.9);backdrop-filter:blur(18px);box-shadow:0 24px 60px rgba(0,0,0,.38)}.save-note{color:var(--text-secondary);font-size:11px;line-height:1.8}.save-note strong{display:block;color:#fff;font-size:12px}.dirty-state{display:none;margin-right:7px;color:var(--warning);font-weight:800}.dirty-state.show{display:inline}
#settingsEditor{scroll-margin-top:22px}.quick-panel{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;align-items:center;padding:20px}.quick-panel p{color:var(--text-secondary);font-size:12px;line-height:1.9}.quick-actions{display:flex;gap:9px;flex-wrap:wrap}

.theme-dock{position:fixed;left:18px;bottom:18px;z-index:120;display:flex;gap:8px;padding:10px;border:1px solid var(--border);border-radius:999px;background:rgba(8,10,18,.82);backdrop-filter:blur(14px);box-shadow:0 20px 40px rgba(0,0,0,.35)}.theme-chip{width:22px;height:22px;padding:0;border:2px solid rgba(255,255,255,.28);border-radius:50%;cursor:pointer;background:#2dd4bf}.theme-chip.active{outline:2px solid var(--text-primary);outline-offset:2px}.theme-purple-chip{background:#a855f7}.theme-red-chip{background:#ff304f}.theme-gold-chip{background:#f7c948}
body.theme-purple{--accent:#a855f7;--accent-dark:#7c3aed;--border-glow:rgba(168,85,247,.55)}body.theme-red{--accent:#ff304f;--accent-dark:#c81e3a;--border-glow:rgba(255,48,79,.55)}body.theme-gold{--accent:#f7c948;--accent-dark:#d69e2e;--border-glow:rgba(247,201,72,.55)}
.operations-section{margin:0 0 24px}.operations-head{display:flex;align-items:end;justify-content:space-between;gap:16px;margin-bottom:14px}.operations-head h2{font-size:22px;font-weight:950}.operations-head p{margin-top:5px;color:var(--text-secondary);font-size:12px;line-height:1.8}.operations-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.operation-card{--op:#2dd4bf;position:relative;min-height:180px;padding:18px;overflow:hidden;border:1px solid color-mix(in srgb,var(--op) 28%,rgba(255,255,255,.08));border-radius:24px;display:flex;flex-direction:column;color:#fff;text-decoration:none;background:radial-gradient(circle at 12% 10%,color-mix(in srgb,var(--op) 18%,transparent),transparent 42%),linear-gradient(145deg,rgba(17,24,39,.88),rgba(7,10,18,.94));box-shadow:0 18px 50px rgba(0,0,0,.22);transition:var(--transition)}.operation-card:hover{transform:translateY(-5px);border-color:color-mix(in srgb,var(--op) 56%,transparent);box-shadow:0 26px 65px rgba(0,0,0,.34)}.operation-card:after{content:"";position:absolute;inset:auto -20% -55% auto;width:180px;height:180px;border-radius:50%;background:var(--op);filter:blur(65px);opacity:.13}.operation-top{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:12px}.operation-icon{width:46px;height:46px;border-radius:16px;display:grid;place-items:center;color:#06110f;background:linear-gradient(135deg,var(--op),#fff);box-shadow:0 12px 28px color-mix(in srgb,var(--op) 22%,transparent)}.operation-value{text-align:left}.operation-value strong{display:block;font-size:20px;font-weight:950}.operation-value span{color:var(--text-secondary);font-size:10px}.operation-card h3{position:relative;z-index:1;margin:18px 0 7px;font-size:15px;font-weight:950}.operation-card p{position:relative;z-index:1;margin:0;color:#aebbd2;font-size:11px;line-height:1.85}.operation-go{position:relative;z-index:1;margin-top:auto;padding-top:14px;display:flex;align-items:center;justify-content:space-between;color:color-mix(in srgb,var(--op) 82%,#fff);font-size:11px;font-weight:900}.tone-purple{--op:#a855f7}.tone-gold{--op:#f7c948}.tone-red{--op:#fb7185}.tone-blue{--op:#38bdf8}.tone-cyan{--op:#2dd4bf}


.report-list{display:grid;gap:12px}.report-item{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:18px;padding:17px;border:1px solid rgba(255,255,255,.075);border-radius:20px;background:rgba(2,6,23,.34)}.report-item.is-open{border-color:rgba(251,113,133,.24);background:linear-gradient(135deg,rgba(251,113,133,.075),rgba(2,6,23,.34))}.report-head{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:9px}.report-badge{padding:4px 9px;border-radius:999px;font-size:10px;font-weight:900;background:rgba(255,255,255,.07);color:#cbd5e1}.report-badge.open{background:rgba(251,113,133,.14);color:#fecdd3}.report-badge.resolved{background:rgba(52,211,153,.13);color:#bbf7d0}.report-reason{font-size:13px;font-weight:900;color:#fff}.report-meta{color:var(--text-secondary);font-size:10px;line-height:1.8}.report-excerpt{margin-top:9px;padding:11px 13px;border-right:3px solid rgba(45,212,191,.5);border-radius:12px;background:rgba(255,255,255,.035);color:#dbe7f8;font-size:11px;line-height:1.85}.report-details{margin-top:7px;color:#fbcfe8;font-size:10.5px}.report-actions{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.report-actions form{display:inline-flex}.empty-operations{padding:28px;text-align:center;border:1px dashed rgba(52,211,153,.25);border-radius:20px;color:#bbf7d0;background:rgba(52,211,153,.055)}
@media(max-width:1180px){.operations-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.dashboard-hero{grid-template-columns:1fr}.hero-panel{grid-template-columns:repeat(4,1fr)}.form-grid{grid-template-columns:1fr 1fr}}
@media(max-width:1024px){.sidebar{width:270px;transform:translateX(110%)}.sidebar.open{transform:translateX(0)}.sidebar-overlay.show{display:block}.main-content{margin-right:0;padding:80px 18px 50px}.menu-toggle{display:grid;place-items:center}.theme-dock{left:12px;bottom:12px}}
@media(max-width:760px){.report-item{grid-template-columns:1fr}.report-actions{justify-content:flex-start}.operations-grid{grid-template-columns:1fr}.operations-head{align-items:flex-start;flex-direction:column}.operations-head .btn{width:100%}.dashboard-hero{padding:22px;border-radius:26px}.hero-title{font-size:30px}.hero-panel{grid-template-columns:1fr 1fr}.stats-grid{grid-template-columns:1fr 1fr}.stat-card:last-child{grid-column:1/-1}.card-header{align-items:flex-start;flex-direction:column}.card-tools{width:100%}.card-tools .btn{flex:1}.form-grid{grid-template-columns:1fr}.setting-field.full{grid-column:auto}.savebar{position:static;align-items:stretch;flex-direction:column}.savebar .btn{width:100%}.quick-panel{grid-template-columns:1fr}.quick-actions .btn{flex:1}.theme-dock{display:none}}
@media(max-width:480px){.main-content{padding-left:10px;padding-right:10px}.hero-panel{grid-template-columns:1fr 1fr}.stats-grid{grid-template-columns:1fr}.stat-card:last-child{grid-column:auto}.hero-actions .btn{flex:1 1 calc(50% - 6px)}.card-body{padding:12px}.setting-field{padding:14px}.toggle-setting{min-height:82px}.quick-actions{flex-direction:column}.quick-actions .btn{width:100%}}

/* Footer links manager v148.11 */
.footer-links-manager{border:1px solid rgba(45,212,191,.18);border-radius:18px;overflow:hidden;background:rgba(1,5,13,.45)}
.footer-links-manager-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 14px;border-bottom:1px solid rgba(255,255,255,.07);background:linear-gradient(135deg,rgba(45,212,191,.08),rgba(139,92,246,.05))}
.footer-links-manager-head strong{display:block;font-size:13px}.footer-links-manager-head span{display:block;margin-top:3px;color:var(--text-secondary);font-size:10.5px;line-height:1.6}
.footer-links-list{display:grid;gap:10px;padding:12px}.footer-link-empty{padding:30px 15px;border:1px dashed rgba(148,163,184,.2);border-radius:15px;text-align:center;color:var(--text-secondary);font-size:12px}
.footer-link-row{display:grid;grid-template-columns:34px minmax(120px,.8fr) minmax(190px,1.4fr) minmax(125px,.55fr) auto;gap:9px;align-items:center;padding:10px;border:1px solid rgba(255,255,255,.075);border-radius:16px;background:rgba(5,10,22,.7);transition:.18s ease}
.footer-link-row:hover{border-color:rgba(45,212,191,.23)}.footer-link-row.is-dragging{opacity:.42;transform:scale(.99)}
.footer-link-handle{width:34px;height:42px;border:0;border-radius:11px;display:grid;place-items:center;color:#8ea1bd;background:rgba(255,255,255,.045);cursor:grab}.footer-link-handle:active{cursor:grabbing}
.footer-link-control{min-width:0}.footer-link-control small{display:block;margin:0 0 5px;color:#8290a7;font-size:9px;font-weight:800}.footer-link-control input,.footer-link-control select{min-height:40px;padding:8px 10px;border-radius:11px;font-size:11px}
.footer-link-toggles{display:flex;align-items:center;gap:7px;flex-wrap:wrap}.footer-mini-check{height:34px;padding:0 9px;border:1px solid rgba(255,255,255,.08);border-radius:10px;display:inline-flex;align-items:center;gap:6px;color:#b7c3d8;background:rgba(255,255,255,.035);font-size:9.5px;cursor:pointer}.footer-mini-check input{width:15px;height:15px;accent-color:var(--accent)}
.footer-link-actions{display:flex;align-items:center;gap:5px}.footer-link-action{width:34px;height:34px;padding:0;border:1px solid rgba(255,255,255,.08);border-radius:10px;display:grid;place-items:center;color:#c7d2e5;background:rgba(255,255,255,.04);cursor:pointer}.footer-link-action:hover{color:#fff;border-color:rgba(45,212,191,.3);background:rgba(45,212,191,.08)}.footer-link-action.remove:hover{color:#ffd7de;border-color:rgba(251,113,133,.3);background:rgba(251,113,133,.09)}
.footer-link-note{padding:0 13px 13px;color:#8492aa;font-size:10px;line-height:1.8}.footer-link-note code{direction:ltr;display:inline-block;color:#bffbf2}
@media(max-width:1120px){.footer-link-row{grid-template-columns:34px repeat(2,minmax(0,1fr));}.footer-link-control.url{grid-column:3}.footer-link-control.icon{grid-column:2}.footer-link-toggles{grid-column:3}.footer-link-actions{grid-column:2/4;justify-content:flex-end}}
@media(max-width:700px){.footer-links-manager-head{align-items:flex-start;flex-direction:column}.footer-link-row{grid-template-columns:34px minmax(0,1fr)}.footer-link-control,.footer-link-control.url,.footer-link-control.icon,.footer-link-toggles,.footer-link-actions{grid-column:2}.footer-link-actions{justify-content:flex-start}.footer-mini-check{flex:1 1 auto;justify-content:center}}
</style>
<style id="bm-font-preview-faces"><?= bm_site_all_font_faces_css() ?>
.font-preview-box{grid-column:1/-1;padding:20px;border:1px solid rgba(45,212,191,.22);border-radius:22px;background:linear-gradient(135deg,rgba(45,212,191,.08),rgba(139,92,246,.07));overflow:hidden}
.font-preview-box small{display:block;color:var(--text-secondary);margin-bottom:10px}.font-preview-fa{margin:0 0 8px;font-size:clamp(22px,3vw,34px);font-weight:850;line-height:1.75}.font-preview-en{margin:0;color:#b9c5dc;font-size:16px;direction:ltr;text-align:left;letter-spacing:.01em}.font-preview-note{margin-top:12px;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);color:#f8d38a;font-size:11px;line-height:1.8}
</style>
<style id="bm-admin-v148-overrides">
.sidebar{display:flex!important;flex-direction:column!important;overflow:hidden!important}.sidebar-logo{flex:0 0 auto}.sidebar-nav{flex:1 1 auto!important;min-height:0!important;overflow-y:auto!important;padding-bottom:12px!important;margin-bottom:0!important;scrollbar-width:thin}.sidebar-footer{position:static!important;right:auto!important;left:auto!important;bottom:auto!important;flex:0 0 auto;margin-top:12px!important}
.bm-font-preview-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin-top:14px}.bm-font-preview-grid>div{padding:14px;border-radius:16px;background:var(--surface-2,rgba(12,18,30,.88));border:1px solid var(--border,rgba(255,255,255,.08))}.bm-font-preview-grid b,.bm-font-preview-grid span{display:block}.bm-font-preview-grid b{font-size:14px;margin-bottom:5px}.bm-font-preview-grid span{font-size:12px;color:var(--text-secondary,#aab3c5)}@media(max-width:720px){.bm-font-preview-grid{grid-template-columns:1fr}}
</style>

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<style id="bm-mobile-layout-admin-v1">
.bm-mobile-layout-picker{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:4px}
.bm-mobile-layout-card{position:relative;min-width:0;padding:12px;border-radius:18px;border:1px solid rgba(255,255,255,.085);background:linear-gradient(180deg,rgba(13,22,37,.96),rgba(7,13,24,.98));color:#fff;cursor:pointer;text-align:right;transition:.2s ease;box-shadow:0 10px 28px rgba(0,0,0,.16)}
.bm-mobile-layout-card:hover{transform:translateY(-2px);border-color:rgba(47,124,255,.42)}
.bm-mobile-layout-card.is-active{border-color:#2f7cff;box-shadow:0 0 0 2px rgba(47,124,255,.16),0 18px 42px rgba(0,0,0,.25)}
.bm-layout-card-head{display:grid;grid-template-columns:1fr auto;gap:2px 8px;align-items:center;margin-bottom:10px}.bm-layout-card-head b{font-size:12px}.bm-layout-card-head small{grid-column:1/-1;color:rgba(255,255,255,.5);font-size:9px}.bm-layout-card-head em{position:absolute;top:10px;left:10px;padding:3px 7px;border-radius:999px;background:rgba(47,124,255,.14);border:1px solid rgba(47,124,255,.3);color:#76a8ff;font-size:8px;font-style:normal;font-weight:900}
.bm-layout-mini{position:relative;display:block;height:190px;border-radius:14px;overflow:hidden;background:linear-gradient(180deg,#070c14,#0b111d);border:1px solid rgba(255,255,255,.06);padding:10px}
.bm-layout-mini i{position:absolute;display:block;border-radius:5px;background:rgba(255,255,255,.1)}.bm-mini-poster{width:64px;height:92px;top:10px;right:50%;transform:translateX(50%);background:linear-gradient(145deg,#17315a,#071423)!important;border:1px solid rgba(47,124,255,.25)}.bm-mini-title{height:8px;width:70%;top:109px;right:15%}.bm-mini-rating{height:10px;width:38px;top:124px;right:calc(50% - 19px);background:#f5c518!important}.bm-mini-meta{height:17px;width:42%;top:142px}.bm-mini-meta.m1{right:7%}.bm-mini-meta.m2{left:7%}.bm-mini-meta.m3{top:162px;right:7%}.bm-mini-meta.m4{top:162px;left:7%}.bm-mini-story{height:12px;width:86%;right:7%;bottom:8px}
.bm-layout-mini--classic{filter:saturate(.7)}
.bm-layout-mini--compact .bm-mini-poster{width:58px;height:82px}.bm-layout-mini--compact .bm-mini-title{top:98px}.bm-layout-mini--compact .bm-mini-rating{top:112px}.bm-layout-mini--compact .bm-mini-meta{top:130px}.bm-layout-mini--compact .m3,.bm-layout-mini--compact .m4{top:150px}.bm-layout-mini--compact .bm-mini-story{height:20px}
.bm-layout-mini--minimal .bm-mini-poster{width:72px;height:102px;right:14px;transform:none}.bm-layout-mini--minimal .bm-mini-title{top:18px;right:98px;width:42%}.bm-layout-mini--minimal .bm-mini-rating{top:34px;right:98px}.bm-layout-mini--minimal .bm-mini-meta{right:98px;left:auto;width:45%;height:10px}.bm-layout-mini--minimal .m1{top:55px}.bm-layout-mini--minimal .m2{top:70px}.bm-layout-mini--minimal .m3{top:85px}.bm-layout-mini--minimal .m4{top:100px}.bm-layout-mini--minimal .bm-mini-story{bottom:12px;height:48px}
.bm-layout-mini--cinematic{background:radial-gradient(circle at 35% 15%,#1b3159 0,#090f19 44%,#05080e 100%)}.bm-layout-mini--cinematic .bm-mini-poster{inset:0;width:100%;height:100%;border:0;border-radius:0;opacity:.22;transform:none}.bm-layout-mini--cinematic .bm-mini-title{top:72px;right:12%;width:76%;height:12px;background:rgba(255,255,255,.72)}.bm-layout-mini--cinematic .bm-mini-rating{top:92px}.bm-layout-mini--cinematic .bm-mini-meta{top:115px}.bm-layout-mini--cinematic .m3,.bm-layout-mini--cinematic .m4{top:138px}.bm-layout-mini--cinematic .bm-mini-story{height:28px}
.bm-layout-mini--pro .bm-mini-poster{display:none}.bm-layout-mini--pro .bm-mini-title{top:15px;right:9%;width:82%;height:11px}.bm-layout-mini--pro .bm-mini-rating{top:35px;right:9%;transform:none}.bm-layout-mini--pro .bm-mini-meta{right:9%;left:auto;width:82%;height:22px}.bm-layout-mini--pro .m1{top:55px}.bm-layout-mini--pro .m2{top:81px}.bm-layout-mini--pro .m3{top:107px}.bm-layout-mini--pro .m4{top:133px}.bm-layout-mini--pro .bm-mini-story{bottom:9px;height:20px}
.bm-layout-mini--vertical .bm-mini-poster{width:58px;height:78px;top:10px}.bm-layout-mini--vertical .bm-mini-title{top:94px}.bm-layout-mini--vertical .bm-mini-rating{top:108px}.bm-layout-mini--vertical .bm-mini-meta{top:127px;height:21px}.bm-layout-mini--vertical .m3,.bm-layout-mini--vertical .m4{top:152px}.bm-layout-mini--vertical .bm-mini-story{display:none}
.bm-layout-mini--dashboard .bm-mini-poster{width:65px;height:82px;top:8px}.bm-layout-mini--dashboard .bm-mini-title{top:95px}.bm-layout-mini--dashboard .bm-mini-rating{top:109px}.bm-layout-mini--dashboard .bm-mini-meta{width:27%;height:31px;top:130px}.bm-layout-mini--dashboard .m1{right:5%}.bm-layout-mini--dashboard .m2{right:36.5%;left:auto}.bm-layout-mini--dashboard .m3{left:5%;right:auto}.bm-layout-mini--dashboard .m4{display:none}.bm-layout-mini--dashboard .bm-mini-story{height:13px;bottom:8px}
.bm-layout-mini--stack .bm-mini-poster{width:70px;height:92px;top:8px}.bm-layout-mini--stack .bm-mini-title{top:106px}.bm-layout-mini--stack .bm-mini-rating{top:120px}.bm-layout-mini--stack .bm-mini-meta{width:27%;height:21px;top:140px}.bm-layout-mini--stack .m1{right:5%}.bm-layout-mini--stack .m2{right:36.5%;left:auto}.bm-layout-mini--stack .m3{left:5%;right:auto}.bm-layout-mini--stack .m4{display:none}.bm-layout-mini--stack .bm-mini-story{height:16px;bottom:7px}
.bm-layout-select-state{display:flex;align-items:center;gap:6px;margin-top:9px;color:rgba(255,255,255,.38);font-size:9px;font-weight:900}.bm-mobile-layout-card.is-active .bm-layout-select-state{color:#6ba2ff}.bm-layout-select-state i{opacity:.4}.bm-mobile-layout-card.is-active .bm-layout-select-state i{opacity:1}
@media(max-width:1200px){.bm-mobile-layout-picker{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:650px){.bm-mobile-layout-picker{grid-template-columns:1fr 1fr;gap:9px}.bm-mobile-layout-card{padding:8px;border-radius:14px}.bm-layout-mini{height:150px}.bm-layout-card-head b{font-size:10px}.bm-layout-card-head small{font-size:8px}}
</style>

</head>
<body>
<button class="menu-toggle" id="menuToggle" type="button" aria-label="بازکردن منوی مدیریت"><i class="fas fa-bars"></i></button>
<div class="sidebar-overlay" id="sidebarOverlay"></div>

<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo"><i class="fas fa-film"></i><h2>BankMovie</h2></div>
  <nav class="sidebar-nav" aria-label="منوی مدیریت">
    <div class="nav-section-label">دسترسی سریع</div>
    <a href="admin.php"><i class="fas fa-gauge-high"></i><span>پنل اصلی</span></a>
    <a href="admin_control_center.php"><i class="fas fa-sliders"></i><span>مرکز کنترل کامل</span></a>
    <a href="bm_admin.php"><i class="fas fa-mobile-screen-button"></i><span>مدیریت اپ بانک‌مووی</span></a>
    <a href="api_manager.php"><i class="fas fa-plug-circle-bolt"></i><span>مدیریت API</span></a>
    <a href="/" target="_blank" rel="noopener"><i class="fas fa-arrow-up-right-from-square"></i><span>مشاهده سایت</span></a>
    <div class="nav-section-label">مدیریت عملیاتی</div>
    <a href="#operations"><i class="fas fa-grid-2"></i><span>همه ابزارهای مدیریت</span><span class="nav-badge"><?=count($operationCards)?></span></a>
    <a href="admin.php?tab=pending#commentsSection"><i class="fas fa-comments"></i><span>مدیریت نظرات</span><span class="nav-badge"><?=sm_h($pendingComments)?></span></a>
    <a href="admin.php#bannersSection"><i class="fas fa-rectangle-ad"></i><span>مدیریت بنرها</span><span class="nav-badge"><?=sm_h($activeBanners)?></span></a>
    <a href="admin_control_center.php"><i class="fas fa-bullhorn"></i><span>مدیریت یکتانت</span></a>
    <div class="nav-section-label">ظاهر و محتوای سایت</div>
    <?php foreach ($schema as $id => $group): ?>
      <a class="<?=$id === $active ? 'active' : ''?>" href="?group=<?=sm_h($id)?>#settingsEditor">
        <i class="fas <?=sm_h(sm_group_icon_class($id))?>"></i>
        <span><?=sm_h($group['label'])?></span>
        <span class="nav-badge"><?=count($group['fields'] ?? [])?></span>
      </a>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer"><a class="logout-btn" href="/logout" onclick="return confirm('از پنل خارج می‌شوی؟')"><i class="fas fa-right-from-bracket"></i> خروج از پنل</a></div>
</aside>

<div class="theme-dock" aria-label="انتخاب تم پنل">
  <button type="button" data-theme="neon" class="theme-chip active" title="Neon Green"></button>
  <button type="button" data-theme="purple" class="theme-chip theme-purple-chip" title="Purple Cinema"></button>
  <button type="button" data-theme="red" class="theme-chip theme-red-chip" title="Red Netflix"></button>
  <button type="button" data-theme="gold" class="theme-chip theme-gold-chip" title="Gold Premium"></button>
</div>

<main class="main-content">
  <section class="dashboard-hero">
    <div>
      <span class="hero-eyebrow">مرکز مدیریت زنده سایت</span>
      <h1 class="hero-title"><span>مرکز مدیریت کامل BankMovie</span></h1>
      <p class="hero-subtitle">تنظیمات ظاهری و متنی، نظرات، حمایت مالی، تبلیغات، بنرها، کاربران، آرشیوها و ابزارهای انتشار را از یک مرکز واحد کنترل کن. ذخیره هر تب مستقل است و تنظیمات بخش‌های دیگر را تغییر نمی‌دهد.</p>
      <div class="hero-actions">
        <a class="btn btn-primary" href="/" target="_blank" rel="noopener"><i class="fas fa-eye"></i> مشاهده سایت</a>
        <a class="btn btn-outline" href="admin.php"><i class="fas fa-gauge-high"></i> بازگشت به داشبورد</a>
        <a class="btn" href="bm_admin.php"><i class="fas fa-mobile-screen"></i> مدیریت اپ</a>
      </div>
    </div>
    <div class="hero-panel">
      <article class="hero-mini-card"><i class="fas fa-toggle-on"></i><strong><?=sm_h($summary['enabled'])?></strong><span>قابلیت فعال</span></article>
      <article class="hero-mini-card"><i class="fas fa-toggle-off"></i><strong><?=sm_h($summary['disabled'])?></strong><span>قابلیت غیرفعال</span></article>
      <article class="hero-mini-card"><i class="fas fa-layer-group"></i><strong><?=count($schema)?></strong><span>گروه تنظیمات</span></article>
      <article class="hero-mini-card"><i class="fas fa-shield-halved"></i><strong>امن</strong><span>ذخیره مستقل تب‌ها</span></article>
    </div>
  </section>

  <?php if (isset($statusMessages[$status])): [$noticeType, $noticeText] = $statusMessages[$status]; ?>
    <div class="notice <?=$noticeType === 'error' ? 'error' : ''?>"><i class="fas <?=$noticeType === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'?>"></i> <?=sm_h($noticeText)?></div>
  <?php endif; ?>

  <section class="operations-section" id="operations">
    <div class="operations-head"><div><h2>مدیریت عملیاتی سایت</h2><p>این بخش فقط تنظیم متن نیست؛ ابزارهای واقعی مدیریت نظرات، بنرها، تبلیغات، کاربران، محتوا و انتشار را یکجا باز می‌کند.</p></div><a class="btn btn-outline" href="admin.php"><i class="fas fa-gauge-high"></i> داشبورد اصلی</a></div>
    <div class="operations-grid">
      <?php foreach($operationCards as $card): ?>
      <?php $operationHref = (string)$card['href']; if (str_starts_with($operationHref, 'admin_site_manager.php?group=') && !str_contains($operationHref, '#')) $operationHref .= '#settingsEditor'; ?>
      <a class="operation-card tone-<?=sm_h($card['tone'])?>" href="<?=sm_h($operationHref)?>">
        <div class="operation-top"><span class="operation-icon"><i class="fas <?=sm_h($card['icon'])?>"></i></span><span class="operation-value"><strong><?=sm_h($card['value'])?></strong><span><?=sm_h($card['suffix'])?></span></span></div>
        <h3><?=sm_h($card['title'])?></h3><p><?=sm_h($card['desc'])?></p>
        <span class="operation-go">بازکردن مدیریت <i class="fas fa-arrow-left"></i></span>
      </a>
      <?php endforeach; ?>
    </div>
  </section>

  <section class="admin-card" id="commentReports">
    <header class="card-header"><div class="card-title-wrap"><span class="card-title-icon"><i class="fas fa-shield-halved"></i></span><div><h2>گزارش‌های تخلف نظرات</h2><p>گزارش‌های باز کاربران را همین‌جا بررسی، حل یا رد کن. مدیریت کامل خود نظر از بخش «مدیریت نظرات» انجام می‌شود.</p></div></div><div class="card-tools"><a class="btn btn-outline btn-sm" href="admin.php?tab=pending#commentsSection"><i class="fas fa-comments"></i> مدیریت همه نظرات</a></div></header>
    <div class="card-body">
      <?php if (!$commentReportRows): ?><div class="empty-operations"><i class="fas fa-circle-check"></i> هیچ گزارش نظری ثبت نشده است.</div><?php else: ?>
      <div class="report-list">
      <?php $reasonLabels=['insult'=>'توهین','spam'=>'اسپم','spoiler'=>'اسپویلر بدون هشدار','inappropriate'=>'محتوای نامناسب','wrong_info'=>'اطلاعات اشتباه','other'=>'سایر']; foreach($commentReportRows as $report): $rstatus=strtolower((string)($report['status']??'open')); ?>
        <article class="report-item <?=$rstatus==='open'?'is-open':''?>">
          <div><div class="report-head"><span class="report-badge <?=$rstatus==='open'?'open':'resolved'?>"><?=sm_h($rstatus==='open'?'باز':($rstatus==='dismissed'?'رد شده':'حل شده'))?></span><span class="report-reason"><?=sm_h($reasonLabels[$report['reason']] ?? $report['reason'] ?? 'سایر')?></span></div>
          <div class="report-meta">گزارش‌دهنده: <?=sm_h($report['reporter_name']??'کاربر')?> · نویسنده نظر: <?=sm_h($report['comment_author']?:'نامشخص')?> · آرشیو <?=sm_h($report['archive_no']??1)?> · <?=sm_h($report['created_at']??'')?></div>
          <div class="report-excerpt"><?=sm_h(mb_strlen((string)$report['comment_excerpt'])>260?mb_substr((string)$report['comment_excerpt'],0,260).'…':($report['comment_excerpt']?:'متن نظر در دسترس نیست'))?></div>
          <?php if(trim((string)($report['details']??''))!==''): ?><div class="report-details">توضیح کاربر: <?=sm_h($report['details'])?></div><?php endif; ?></div>
          <div class="report-actions">
            <?php if($rstatus!=='resolved'): ?><form method="post"><input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>"><input type="hidden" name="settings_group" value="comments"><input type="hidden" name="action" value="report_status"><input type="hidden" name="report_id" value="<?=sm_h($report['id'])?>"><input type="hidden" name="report_status" value="resolved"><button class="btn btn-success btn-sm" type="submit"><i class="fas fa-check"></i> حل شد</button></form><?php endif; ?>
            <?php if($rstatus!=='dismissed'): ?><form method="post"><input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>"><input type="hidden" name="settings_group" value="comments"><input type="hidden" name="action" value="report_status"><input type="hidden" name="report_id" value="<?=sm_h($report['id'])?>"><input type="hidden" name="report_status" value="dismissed"><button class="btn btn-sm" type="submit"><i class="fas fa-ban"></i> رد گزارش</button></form><?php endif; ?>
            <form method="post" onsubmit="return confirm('این گزارش حذف شود؟')"><input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>"><input type="hidden" name="settings_group" value="comments"><input type="hidden" name="action" value="report_delete"><input type="hidden" name="report_id" value="<?=sm_h($report['id'])?>"><button class="btn btn-danger btn-sm" type="submit"><i class="fas fa-trash"></i></button></form>
          </div>
        </article>
      <?php endforeach; ?>
      </div><?php endif; ?>
    </div>
  </section>

  <section class="stats-grid">
    <article class="stat-card"><div class="stat-head"><span>وضعیت کل قابلیت‌ها</span><span class="stat-icon"><i class="fas fa-circle-check"></i></span></div><strong class="stat-number good"><?=sm_h($summary['enabled'])?> / <?=sm_h($summary['total'])?></strong></article>
    <article class="stat-card"><div class="stat-head"><span>قابلیت‌های غیرفعال</span><span class="stat-icon"><i class="fas fa-power-off"></i></span></div><strong class="stat-number <?=$summary['disabled'] > 0 ? 'warn' : 'good'?>"><?=sm_h($summary['disabled'])?></strong></article>
    <article class="stat-card"><div class="stat-head"><span>آخرین ذخیره تنظیمات</span><span class="stat-icon"><i class="fas fa-clock-rotate-left"></i></span></div><strong class="stat-number" style="font-size:18px"><?= $summary['saved_at'] ? sm_h(date('Y/m/d H:i', (int)$summary['saved_at'])) : 'تنظیمات پیش‌فرض' ?></strong></article>
  </section>

  <form method="post" id="settingsForm" autocomplete="off">
    <input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>">
    <input type="hidden" name="action" value="save_group">
    <input type="hidden" name="settings_group" value="<?=sm_h($active)?>">

    <section class="admin-card" id="settingsEditor">
      <header class="card-header">
        <div class="card-title-wrap">
          <span class="card-title-icon"><i class="fas <?=sm_h(sm_group_icon_class($active))?>"></i></span>
          <div><h2><?=sm_h($activeGroup['label'])?></h2><p>فقط تنظیمات همین بخش ذخیره می‌شود؛ متن‌ها و وضعیت بخش‌های دیگر دست‌نخورده می‌مانند.</p></div>
        </div>
        <?php if ($groupCheckboxes): ?>
          <div class="card-tools">
            <button class="btn btn-outline btn-sm" type="button" data-toggle-group="on"><i class="fas fa-toggle-on"></i> فعال‌کردن همه این بخش</button>
            <button class="btn btn-sm" type="button" data-toggle-group="off"><i class="fas fa-toggle-off"></i> خاموش‌کردن همه این بخش</button>
          </div>
        <?php endif; ?>
      </header>
      <div class="card-body">
        <div class="form-grid">
          <?php foreach (($activeGroup['fields'] ?? []) as $key => $field):
            $typeName = (string)($field['type'] ?? 'text');
            $value = $settings[$key] ?? ($field['default'] ?? '');
            $full = in_array($typeName, ['textarea','footer_links'], true) || $key === 'movie_mobile_template';
          ?>
            <?php if ($typeName === 'checkbox'): ?>
              <div class="setting-field toggle-setting">
                <div class="toggle-copy"><b><?=sm_h($field['label'])?></b><span><?=!empty($field['help']) ? sm_h($field['help']) : 'با خاموش‌کردن این گزینه فقط همین قابلیت غیرفعال می‌شود.'?></span></div>
                <label class="switch" aria-label="<?=sm_h($field['label'])?>"><input type="checkbox" name="<?=sm_h($key)?>" value="1" <?=!empty($value) ? 'checked' : ''?>><span class="switch-track"></span></label>
              </div>
            <?php else: ?>
              <div class="setting-field <?=$full ? 'full' : ''?>">
                <label class="field-label" for="f_<?=sm_h($key)?>"><i class="fas <?=$typeName === 'color' ? 'fa-palette' : ($typeName === 'url' ? 'fa-link' : ($typeName === 'textarea' ? 'fa-align-right' : ($typeName === 'number' ? 'fa-hashtag' : ($typeName === 'select' ? 'fa-list' : 'fa-pen'))))?>"></i><?=sm_h($field['label'])?></label>
                <?php if ($key === 'movie_mobile_template'): ?>
                  <input type="hidden" id="f_<?=sm_h($key)?>" name="<?=sm_h($key)?>" value="<?=sm_h($value)?>" data-bm-mobile-layout-input>
                  <?php
                    $bmMobileLayoutCards = [
                      'classic' => ['title'=>'نسخه فعلی','subtitle'=>'پیش‌فرض و بدون تغییر','class'=>'classic'],
                      'compact_card' => ['title'=>'طرح ۱','subtitle'=>'کارت جمع‌وجور','class'=>'compact'],
                      'minimal_rows' => ['title'=>'طرح ۲','subtitle'=>'ردیفی و مینیمال','class'=>'minimal'],
                      'cinematic_modern' => ['title'=>'طرح ۳','subtitle'=>'سینمایی و مدرن','class'=>'cinematic'],
                      'pro_compact' => ['title'=>'طرح ۴','subtitle'=>'فشرده و حرفه‌ای','class'=>'pro'],
                      'vertical_card' => ['title'=>'طرح ۵','subtitle'=>'کارت عمودی','class'=>'vertical'],
                      'dashboard' => ['title'=>'طرح ۶','subtitle'=>'داشبوردی','class'=>'dashboard'],
                      'premium_stack' => ['title'=>'طرح ۷','subtitle'=>'Premium Stack','class'=>'stack'],
                    ];
                  ?>
                  <div class="bm-mobile-layout-picker" data-bm-mobile-layout-picker>
                    <?php foreach($bmMobileLayoutCards as $layoutValue=>$layoutMeta): ?>
                    <button type="button" class="bm-mobile-layout-card <?=((string)$value===(string)$layoutValue)?'is-active':''?>" data-layout-value="<?=sm_h($layoutValue)?>" aria-pressed="<?=((string)$value===(string)$layoutValue)?'true':'false'?>">
                      <span class="bm-layout-card-head"><b><?=sm_h($layoutMeta['title'])?></b><small><?=sm_h($layoutMeta['subtitle'])?></small><?php if($layoutValue==='classic'): ?><em>پیش‌فرض</em><?php endif; ?></span>
                      <span class="bm-layout-mini bm-layout-mini--<?=sm_h($layoutMeta['class'])?>" aria-hidden="true">
                        <i class="bm-mini-poster"></i><i class="bm-mini-title"></i><i class="bm-mini-rating"></i><i class="bm-mini-meta m1"></i><i class="bm-mini-meta m2"></i><i class="bm-mini-meta m3"></i><i class="bm-mini-meta m4"></i><i class="bm-mini-story"></i>
                      </span>
                      <span class="bm-layout-select-state"><i class="fas fa-circle-check"></i> انتخاب شده</span>
                    </button>
                    <?php endforeach; ?>
                  </div>
                <?php elseif ($typeName === 'footer_links'): ?>
                  <textarea id="f_<?=sm_h($key)?>" name="<?=sm_h($key)?>" hidden><?=sm_h($value)?></textarea>
                  <div class="footer-links-manager" data-footer-links-manager>
                    <div class="footer-links-manager-head">
                      <div><strong>مدیریت منوی لینک‌های مفید</strong><span>مثل منوی وردپرس: عنوان، آدرس داخلی یا خارجی، آیکن، ترتیب و نحوه بازشدن را تعیین کن.</span></div>
                      <button type="button" class="btn btn-primary btn-sm" data-footer-link-add><i class="fas fa-plus"></i> افزودن لینک</button>
                    </div>
                    <div class="footer-links-list" data-footer-links-list></div>
                    <div class="footer-link-note">آدرس داخلی: <code>/categories</code> — آدرس خارجی: <code>https://example.com</code>. حداکثر ۲۴ لینک ذخیره می‌شود.</div>
                  </div>
                <?php elseif ($typeName === 'textarea'): ?>
                  <textarea id="f_<?=sm_h($key)?>" name="<?=sm_h($key)?>"><?=sm_h($value)?></textarea>
                <?php elseif ($typeName === 'select'): ?>
                  <select id="f_<?=sm_h($key)?>" name="<?=sm_h($key)?>"><?php foreach((array)($field['options'] ?? []) as $optionValue=>$optionLabel): ?><option value="<?=sm_h($optionValue)?>" <?=((string)$value===(string)$optionValue)?'selected':''?>><?=sm_h($optionLabel)?></option><?php endforeach; ?></select>
                <?php else: ?>
                  <input id="f_<?=sm_h($key)?>" type="<?=in_array($typeName,['url','color','number'],true) ? sm_h($typeName) : 'text'?>" name="<?=sm_h($key)?>" value="<?=sm_h($value)?>" <?=isset($field['min'])?'min="'.sm_h($field['min']).'"':''?> <?=isset($field['max'])?'max="'.sm_h($field['max']).'"':''?>>
                <?php endif; ?>
                <?php if (!empty($field['help'])): ?><small class="field-help"><?=sm_h($field['help'])?></small><?php endif; ?>
              </div>
            <?php endif; ?>
          <?php endforeach; ?>
        </div>
        <?php if ($active === 'typography'): ?>
          <div class="font-preview-box" id="fontPreviewBox">
            <small>پیش‌نمایش زنده بخش‌های مختلف سایت</small>
            <div class="bm-font-preview-grid">
              <div data-font-preview="header"><b>هدر و منو</b><span>خانه · دسته‌بندی · کالکشن‌ها</span></div>
              <div data-font-preview="hero"><b>اسلایدر اصلی</b><span>دنیای فیلم و سریال بدون محدودیت</span></div>
              <div data-font-preview="heading"><b>تیترهای صفحه</b><span>جدیدترین فیلم‌ها و سریال‌ها</span></div>
              <div data-font-preview="card"><b>عنوان کارت</b><span>نام فیلم نمونه ۲۰۲۶</span></div>
              <div data-font-preview="button"><b>دکمه‌ها</b><span>تماشا و دانلود</span></div>
              <div data-font-preview="footer"><b>فوتر و ناوبری موبایل</b><span>خانه · جستجو · دسته‌بندی</span></div>
            </div>
            <div class="font-preview-note">هر انتخاب فقط روی بخش مربوط به خودش اعمال می‌شود و فونت پیش‌فرض نقش جایگزین را دارد.</div>
          </div>
        <?php endif; ?>
        <?php if ($active === 'seo'): ?>
          <?php $seoPanelBase = function_exists('bm_seo_base_url') ? bm_seo_base_url() : rtrim(SITE_URL, '/'); $seoSchemaStatus = bm_site_bool('seo_jsonld_enabled', true) ? 'فعال' : 'خاموش'; $seoOgStatus = bm_site_bool('seo_open_graph_enabled', true) ? 'فعال' : 'خاموش'; $seoAutoSitemapStatus = bm_site_bool('seo_sitemap_auto_sync_enabled', true) ? 'فعال و زنده' : 'خاموش'; ?>
          <div class="font-preview-box">
            <small>وضعیت و مسیرهای اصلی سئو</small>
            <div class="bm-font-preview-grid">
              <div><b>Canonical اصلی</b><span dir="ltr"><?=sm_h($seoPanelBase)?></span></div>
              <div><b>Sitemap Index</b><span dir="ltr"><?=sm_h($seoPanelBase . '/sitemap.xml')?></span></div>
              <div><b>ثبت خودکار پست جدید</b><span><?= sm_h($seoAutoSitemapStatus) ?></span></div>
              <div><b>Recent Sitemap</b><span dir="ltr"><?=sm_h($seoPanelBase . '/sitemaps/recent.xml')?></span></div>
              <div><b>Robots.txt</b><span dir="ltr"><?=sm_h($seoPanelBase . '/robots.txt')?></span></div>
              <div><b>Schema و Social Cards</b><span><?= sm_h($seoSchemaStatus) ?> · <?= sm_h($seoOgStatus) ?></span></div>
            </div>
            <div class="font-preview-note">ثبت خودکار مثل وردپرس انجام می‌شود: هر فیلم یا سریال جدید بدون ساخت دستی وارد <b>Recent Sitemap</b> و فایل مربوط به فیلم/سریال می‌شود. در Search Console فقط <b>sitemap.xml</b> را ثبت کن.</div>
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
              <a class="btn btn-secondary" href="/sitemap.xml" target="_blank" rel="noopener"><i class="fas fa-sitemap"></i> مشاهده Sitemap</a>
              <a class="btn btn-secondary" href="/robots.txt" target="_blank" rel="noopener"><i class="fas fa-robot"></i> مشاهده Robots</a>
              <a class="btn btn-secondary" href="admin_sitemap.php"><i class="fas fa-arrows-rotate"></i> ساخت دستی Sitemap</a>
            </div>
          </div>
        <?php endif; ?>
        <?php if ($active === 'loading'):
          $loadingPreviewStyle = (string)($settings['loading_style'] ?? 'logo');
          $loadingPreviewLogo = trim((string)($settings['loading_logo_path'] ?? '')) ?: '/assets/brand/bankmovie-logo.webp';
          $loadingPreviewAccent = (string)($settings['loading_accent_color'] ?? '#2f7cff');
          $loadingPreviewSize = max(64,min(160,(int)($settings['loading_size'] ?? 104)));
        ?>
          <div class="font-preview-box" id="loadingPreviewPanel">
            <small>پیش‌نمایش لودینگ انتخاب‌شده</small>
            <div style="display:grid;place-items:center;min-height:300px;border-radius:24px;background:radial-gradient(circle at center,rgba(47,124,255,.12),transparent 42%),#05070d;overflow:hidden;--bm-loading-accent:<?=sm_h($loadingPreviewAccent)?>;--bm-loading-accent-rgb:47,124,255;--bm-loading-size:<?=$loadingPreviewSize?>px">
              <?php if ($loadingPreviewStyle === 'logo'): ?>
                <div class="bm-loading-stage"><span class="bm-loading-orbit"></span><img class="bm-loading-logo" src="<?=sm_h($loadingPreviewLogo)?>" alt="BankMovie"></div>
              <?php elseif ($loadingPreviewStyle === 'pulse'): ?>
                <div class="bm-loading-stage"><span class="bm-loading-pulse"></span></div>
              <?php elseif ($loadingPreviewStyle === 'dots'): ?>
                <div class="bm-loading-stage"><span class="bm-loading-dots"><i></i><i></i><i></i><i></i></span></div>
              <?php elseif ($loadingPreviewStyle === 'cinema'): ?>
                <div class="bm-loading-stage"><span class="bm-loading-cinema"><i></i></span></div>
              <?php else: ?>
                <div class="bm-loading-stage"><span class="bm-loading-rings"><i></i><i></i><i></i></span></div>
              <?php endif; ?>
              <?php if (!empty($settings['loading_show_text'])): ?><p class="bm-loading-text"><?=sm_h($settings['loading_text_fa'] ?? 'در حال آماده‌سازی بانک مووی...')?></p><?php endif; ?>
              <div class="bm-loading-progress"><span></span></div>
            </div>
            <div class="font-preview-note">پس از ذخیره، همین مدل روی صفحه‌های فعال‌شده اعمال می‌شود. حداقل و حداکثر زمان نمایش نیز از همین بخش کنترل می‌شود.</div>
          </div>
        <?php endif; ?>
      </div>
      <footer class="savebar">
        <div class="save-note"><strong><i class="fas fa-shield-halved"></i> ذخیره امن و مستقل <span class="dirty-state" id="dirtyState">● تغییر ذخیره‌نشده</span></strong>پلیر، API، دیتابیس و تنظیمات تب‌های دیگر تغییر نمی‌کنند.</div>
        <button class="btn btn-primary" type="submit"><i class="fas fa-floppy-disk"></i> ذخیره تنظیمات این بخش</button>
      </footer>
    </section>
  </form>

  <section class="admin-card">
    <div class="quick-panel">
      <div><div class="card-title-wrap"><span class="card-title-icon"><i class="fas fa-wand-magic-sparkles"></i></span><div><h2>عملیات سریع تنظیمات</h2><p>فعال‌سازی همه فقط سوییچ‌ها را روشن می‌کند و متن‌ها و لینک‌های فعلی را حفظ می‌کند. بازنشانی کامل همه مقادیر را به پیش‌فرض پروژه برمی‌گرداند.</p></div></div></div>
      <div class="quick-actions">
        <form method="post" onsubmit="return confirm('تمام قابلیت‌ها فعال شوند؟ متن‌ها و لینک‌های فعلی حفظ می‌شوند.')">
          <input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>"><input type="hidden" name="settings_group" value="<?=sm_h($active)?>"><input type="hidden" name="action" value="enable_all">
          <button class="btn btn-success" type="submit"><i class="fas fa-toggle-on"></i> فعال‌سازی همه بخش‌ها</button>
        </form>
        <form method="post" onsubmit="return confirm('همه متن‌ها و تنظیمات به پیش‌فرض کامل برگردند؟')">
          <input type="hidden" name="csrf_token" value="<?=sm_h($csrf)?>"><input type="hidden" name="settings_group" value="<?=sm_h($active)?>"><input type="hidden" name="action" value="reset">
          <button class="btn btn-danger" type="submit"><i class="fas fa-arrow-rotate-left"></i> بازنشانی کامل</button>
        </form>
      </div>
    </div>
  </section>
</main>

<script>
(() => {
  const form = document.getElementById('settingsForm');
  const dirty = document.getElementById('dirtyState');
  let changed = false;
  if (form) {
    const markDirty = () => { changed = true; dirty?.classList.add('show'); };
    form.addEventListener('input', markDirty);
    form.addEventListener('change', markDirty);
    form.addEventListener('submit', () => { changed = false; });
    document.querySelectorAll('[data-toggle-group]').forEach((button) => {
      button.addEventListener('click', () => {
        const checked = button.dataset.toggleGroup === 'on';
        form.querySelectorAll('input[type="checkbox"][name]').forEach((input) => { input.checked = checked; });
        markDirty();
      });
    });
    window.addEventListener('beforeunload', (event) => {
      if (!changed) return;
      event.preventDefault();
      event.returnValue = '';
    });
  }

  const footerLinksInput = document.getElementById('f_footer_links_json');
  const footerLinksManager = document.querySelector('[data-footer-links-manager]');
  if (footerLinksInput && footerLinksManager) {
    const list = footerLinksManager.querySelector('[data-footer-links-list]');
    const addButton = footerLinksManager.querySelector('[data-footer-link-add]');
    const iconOptions = {
      link:'لینک عمومی',categories:'دسته‌بندی',search:'جستجو',mobile:'موبایل / اپ',home:'خانه',collection:'کالکشن',play:'پخش',star:'ستاره',boxoffice:'باکس آفیس',globe:'وب‌سایت',info:'اطلاعات',support:'پشتیبانی',telegram:'تلگرام',instagram:'اینستاگرام',download:'دانلود',user:'کاربر'
    };
    let items = [];
    try { items = JSON.parse(footerLinksInput.value || '[]'); } catch (error) { items = []; }
    if (!Array.isArray(items)) items = [];
    items = items.slice(0, 24).map((item) => ({
      label:String(item?.label || ''), url:String(item?.url || ''), icon:String(item?.icon || 'link'),
      enabled:item?.enabled !== false, new_tab:Boolean(item?.new_tab), nofollow:Boolean(item?.nofollow)
    }));

    const esc = (value) => String(value ?? '').replace(/[&<>'"]/g, (char) => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[char]));
    const syncFooterLinks = (mark = true) => {
      footerLinksInput.value = JSON.stringify(items);
      if (mark) footerLinksInput.dispatchEvent(new Event('input', {bubbles:true}));
    };
    const move = (from, to) => {
      if (to < 0 || to >= items.length || from === to) return;
      const [item] = items.splice(from, 1); items.splice(to, 0, item); render(); syncFooterLinks();
    };
    const render = () => {
      if (!list) return;
      if (!items.length) {
        list.innerHTML = '<div class="footer-link-empty"><i class="fas fa-link"></i><br>هنوز لینکی نساختی؛ روی «افزودن لینک» بزن.</div>';
        syncFooterLinks(false); return;
      }
      list.innerHTML = items.map((item, index) => `
        <article class="footer-link-row" draggable="true" data-footer-link-row="${index}">
          <button type="button" class="footer-link-handle" title="برای جابه‌جایی بکش"><i class="fas fa-grip-vertical"></i></button>
          <label class="footer-link-control"><small>عنوان لینک</small><input type="text" maxlength="70" value="${esc(item.label)}" data-link-field="label" placeholder="مثلاً دسته‌بندی"></label>
          <label class="footer-link-control url"><small>آدرس داخلی یا خارجی</small><input type="text" maxlength="1000" dir="ltr" value="${esc(item.url)}" data-link-field="url" placeholder="/categories یا https://example.com"></label>
          <label class="footer-link-control icon"><small>آیکن</small><select data-link-field="icon">${Object.entries(iconOptions).map(([value,label]) => `<option value="${value}" ${item.icon===value?'selected':''}>${label}</option>`).join('')}</select></label>
          <div>
            <div class="footer-link-toggles">
              <label class="footer-mini-check"><input type="checkbox" data-link-field="enabled" ${item.enabled?'checked':''}> فعال</label>
              <label class="footer-mini-check"><input type="checkbox" data-link-field="new_tab" ${item.new_tab?'checked':''}> تب جدید</label>
              <label class="footer-mini-check"><input type="checkbox" data-link-field="nofollow" ${item.nofollow?'checked':''}> nofollow</label>
            </div>
            <div class="footer-link-actions">
              <button type="button" class="footer-link-action" data-link-up title="بالاتر"><i class="fas fa-arrow-up"></i></button>
              <button type="button" class="footer-link-action" data-link-down title="پایین‌تر"><i class="fas fa-arrow-down"></i></button>
              <button type="button" class="footer-link-action remove" data-link-remove title="حذف"><i class="fas fa-trash"></i></button>
            </div>
          </div>
        </article>`).join('');

      list.querySelectorAll('[data-footer-link-row]').forEach((row) => {
        const index = Number(row.dataset.footerLinkRow || 0);
        row.querySelectorAll('[data-link-field]').forEach((field) => {
          const eventName = field.matches('select,input[type="checkbox"]') ? 'change' : 'input';
          field.addEventListener(eventName, () => {
            const key = field.dataset.linkField;
            items[index][key] = field.type === 'checkbox' ? field.checked : field.value;
            syncFooterLinks();
          });
        });
        row.querySelector('[data-link-up]')?.addEventListener('click', () => move(index, index - 1));
        row.querySelector('[data-link-down]')?.addEventListener('click', () => move(index, index + 1));
        row.querySelector('[data-link-remove]')?.addEventListener('click', () => { items.splice(index, 1); render(); syncFooterLinks(); });
        row.addEventListener('dragstart', (event) => { row.classList.add('is-dragging'); event.dataTransfer?.setData('text/plain', String(index)); });
        row.addEventListener('dragend', () => row.classList.remove('is-dragging'));
        row.addEventListener('dragover', (event) => event.preventDefault());
        row.addEventListener('drop', (event) => { event.preventDefault(); const from = Number(event.dataTransfer?.getData('text/plain')); move(from, index); });
      });
      syncFooterLinks(false);
    };
    addButton?.addEventListener('click', () => {
      if (items.length >= 24) { alert('حداکثر ۲۴ لینک می‌توانی اضافه کنی.'); return; }
      items.push({label:'لینک جدید',url:'/',icon:'link',enabled:true,new_tab:false,nofollow:false});
      render(); syncFooterLinks();
      list?.lastElementChild?.scrollIntoView({behavior:'smooth',block:'center'});
    });
    form?.addEventListener('submit', () => syncFooterLinks(false));
    render();
  }

  const fontFamilies = {
    bonvf: "'BMSiteBonVF',Tahoma,Arial,sans-serif", yekanbakh: "'BMSiteYekanBakh',Tahoma,Arial,sans-serif",
    filimo: "'BMSiteFilimo',Tahoma,Arial,sans-serif", iransans_fanum: "'BMSiteIRANSansFaNum',Tahoma,Arial,sans-serif",
    iranyekan: "'BMSiteIRANYekanWeb',Tahoma,Arial,sans-serif", iranyekanx_fanum: "'BMSiteIRANYekanXFaNum',Tahoma,Arial,sans-serif",
    brioso: "'BMSiteBrioso',Tahoma,Arial,sans-serif", system: "Tahoma,Arial,system-ui,sans-serif"
  };
  const previewMap = {header:'font_header_family',hero:'font_hero_family',heading:'font_heading_family',card:'font_card_family',button:'font_button_family',footer:'font_footer_family'};
  const baseFont = document.getElementById('f_site_font_family');
  const applyFontPreview = () => {
    document.querySelectorAll('[data-font-preview]').forEach((box) => {
      const key = previewMap[box.dataset.fontPreview];
      const select = document.getElementById('f_' + key);
      const value = select?.value || baseFont?.value || 'bonvf';
      box.style.fontFamily = fontFamilies[value] || fontFamilies.bonvf;
    });
  };
  document.querySelectorAll('#settingsForm select[id*="font_"]').forEach((select)=>select.addEventListener('change',applyFontPreview));
  baseFont?.addEventListener('change',applyFontPreview);
  applyFontPreview();

  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('sidebarOverlay');
  const toggle = document.getElementById('menuToggle');
  const closeSidebar = () => { sidebar?.classList.remove('open'); overlay?.classList.remove('show'); };
  toggle?.addEventListener('click', () => { sidebar?.classList.toggle('open'); overlay?.classList.toggle('show'); });
  overlay?.addEventListener('click', closeSidebar);
  sidebar?.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => { if (window.innerWidth <= 1024) closeSidebar(); }));

  const settingsEditor = document.getElementById('settingsEditor');
  const shouldJumpToEditor = new URLSearchParams(window.location.search).has('group') || window.location.hash === '#settingsEditor';
  if (settingsEditor && shouldJumpToEditor) {
    const jump = () => settingsEditor.scrollIntoView({behavior:'smooth', block:'start'});
    if ('requestAnimationFrame' in window) requestAnimationFrame(() => requestAnimationFrame(jump));
    else setTimeout(jump, 80);
  }

  const savedTheme = localStorage.getItem('adminTheme') || 'neon';
  const applyTheme = (theme) => {
    document.body.classList.remove('theme-purple','theme-red','theme-gold');
    if (theme !== 'neon') document.body.classList.add('theme-' + theme);
    document.querySelectorAll('.theme-chip').forEach((button) => button.classList.toggle('active', button.dataset.theme === theme));
    localStorage.setItem('adminTheme', theme);
  };
  applyTheme(savedTheme);
  document.querySelectorAll('.theme-chip').forEach((button) => button.addEventListener('click', () => applyTheme(button.dataset.theme || 'neon')));
})();
</script>

<script id="bm-mobile-layout-admin-js-v1">
(function(){
  const input=document.querySelector('[data-bm-mobile-layout-input]');
  const picker=document.querySelector('[data-bm-mobile-layout-picker]');
  if(!input||!picker)return;
  const cards=[...picker.querySelectorAll('[data-layout-value]')];
  const apply=(v)=>{input.value=v;cards.forEach(c=>{const on=c.dataset.layoutValue===v;c.classList.toggle('is-active',on);c.setAttribute('aria-pressed',on?'true':'false');});};
  cards.forEach(c=>c.addEventListener('click',()=>apply(c.dataset.layoutValue||'classic')));
  apply(input.value||'classic');
})();
</script>

</body>
</html>
