<?php
header('Content-Type: text/plain; charset=utf-8');
echo "BM-ADMIN-UNIFIED-V1.1\n";
echo "collections_add=poster-plus-english-title\n";
echo "collections_existing=poster-plus-english-title\n";
echo "health_card=dashboard-only\n";
echo "admin_dashboard=untouched\n";
