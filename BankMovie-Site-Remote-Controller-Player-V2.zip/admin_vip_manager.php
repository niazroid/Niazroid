<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/vip_sales.php';
require_admin();
admin_enforce_csrf();

if (!headers_sent()) {
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
}

function bm_vip_admin_h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $action = (string)($_POST['action'] ?? 'save');
    if ($action === 'reset') {
        $ok = bm_vip_sales_reset();
        header('Location: admin_vip_manager.php?' . http_build_query(['status' => $ok ? 'reset' : 'error']));
        exit;
    }
    $ok = bm_vip_sales_save($_POST);
    header('Location: admin_vip_manager.php?' . http_build_query(['status' => $ok ? 'saved' : 'error']));
    exit;
}

$settings = bm_vip_sales_settings();
$csrf = admin_csrf_token();
$status = (string)($_GET['status'] ?? '');
$plans = is_array($settings['plans'] ?? null) ? $settings['plans'] : [];
$features = is_array($settings['features'] ?? null) ? $settings['features'] : [];
$watchBadges = is_array($settings['watch_party_badges'] ?? null) ? $settings['watch_party_badges'] : [];
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>استودیو VIP | بانک مووی</title>
<style>
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;font-family:Tahoma,Arial,sans-serif;color:#eef2ff;background:radial-gradient(circle at 90% 0%,rgba(124,58,237,.18),transparent 30rem),radial-gradient(circle at 10% 15%,rgba(37,99,235,.15),transparent 30rem),linear-gradient(180deg,#050711,#080b16 58%,#05060c)}
a{color:inherit}.page{width:min(1480px,calc(100% - 28px));margin:28px auto 80px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:20px;padding:18px 20px;border:1px solid rgba(255,255,255,.09);border-radius:24px;background:rgba(13,17,29,.78);box-shadow:0 22px 60px rgba(0,0,0,.34);backdrop-filter:blur(18px)}.topbar h1{margin:0 0 5px;font-size:24px}.topbar p{margin:0;color:#929bb3;font-size:12px;line-height:1.8}.actions{display:flex;gap:9px;flex-wrap:wrap}.btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:10px 15px;border:1px solid rgba(255,255,255,.1);border-radius:13px;color:#dbe7ff;background:rgba(255,255,255,.045);font-weight:800;font-size:12px;text-decoration:none;cursor:pointer}.btn:hover{background:rgba(255,255,255,.08)}.btn.primary{border:0;color:#fff;background:linear-gradient(135deg,#8b5cf6,#2563eb);box-shadow:0 14px 32px rgba(37,99,235,.22)}.btn.danger{color:#fecdd3;border-color:rgba(244,63,94,.22);background:rgba(244,63,94,.08)}.notice{margin-bottom:16px;padding:13px 16px;border-radius:15px;font-size:12px;font-weight:800}.notice.ok{color:#bbf7d0;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.2)}.notice.bad{color:#fecaca;background:rgba(239,68,68,.1);border:1px solid rgba(239,68,68,.2)}.grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:16px}.card{grid-column:span 12;padding:20px;border:1px solid rgba(255,255,255,.085);border-radius:24px;background:linear-gradient(180deg,rgba(15,19,32,.86),rgba(10,13,24,.82));box-shadow:0 20px 54px rgba(0,0,0,.25);backdrop-filter:blur(16px)}.card.half{grid-column:span 6}.card h2{margin:0 0 6px;font-size:18px}.card .sub{margin:0 0 18px;color:#8993aa;font-size:11px;line-height:1.8}.form-grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:12px}.field{grid-column:span 6}.field.third{grid-column:span 4}.field.full{grid-column:span 12}.field label{display:block;margin-bottom:7px;color:#cbd5e1;font-size:11px;font-weight:850}.field small{display:block;margin-top:6px;color:#6f7990;font-size:9px;line-height:1.7}.field input,.field textarea,.field select{width:100%;border:1px solid rgba(255,255,255,.1);border-radius:13px;padding:11px 12px;color:#f8fafc;background:rgba(3,6,14,.66);outline:none;font:inherit;font-size:12px}.field textarea{min-height:105px;resize:vertical;line-height:1.9}.field input:focus,.field textarea:focus,.field select:focus{border-color:rgba(96,165,250,.55);box-shadow:0 0 0 3px rgba(59,130,246,.1)}.check{display:flex!important;align-items:center;gap:8px}.check input{width:auto}.repeat-list{display:flex;flex-direction:column;gap:12px}.repeat-item{position:relative;padding:16px;border:1px solid rgba(255,255,255,.08);border-radius:18px;background:rgba(255,255,255,.025)}.repeat-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:13px}.repeat-head strong{font-size:12px}.row-actions{display:flex;gap:7px}.mini{min-width:34px;height:34px;border:1px solid rgba(255,255,255,.09);border-radius:10px;color:#dbeafe;background:rgba(255,255,255,.04);cursor:pointer}.mini.remove{color:#fecdd3;background:rgba(244,63,94,.07)}.sticky-save{position:sticky;bottom:14px;z-index:30;margin-top:18px;padding:13px;display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid rgba(125,170,255,.18);border-radius:18px;background:rgba(8,11,20,.9);box-shadow:0 18px 50px rgba(0,0,0,.45);backdrop-filter:blur(18px)}.sticky-save span{color:#8e98ad;font-size:10px}.empty-note{padding:14px;border:1px dashed rgba(255,255,255,.12);border-radius:14px;color:#7f899f;text-align:center;font-size:11px}.sep{height:1px;margin:16px 0;background:rgba(255,255,255,.07)}
@media(max-width:900px){.card.half{grid-column:span 12}.field,.field.third,.repeat-item .field[style]{grid-column:span 12!important}.topbar{align-items:flex-start;flex-direction:column}.actions{width:100%}.actions .btn{flex:1}.page{width:calc(100% - 18px);margin-top:10px}.sticky-save{align-items:stretch;flex-direction:column}.sticky-save .btn{width:100%}}
</style>

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified">
<main class="page">
  <header class="topbar">
    <div><h1>استودیو BankMovie VIP</h1><p>محتوای صفحه اشتراک، معرفی Watch Party، امکانات، قیمت‌ها و پلن‌ها از این بخش کنترل می‌شوند.</p></div>
    <div class="actions"><a class="btn primary" href="/vip" target="_blank">مشاهده صفحه VIP</a><a class="btn" href="admin.php#vipSection">بازگشت به مرکز VIP</a></div>
  </header>

  <?php if ($status === 'saved'): ?><div class="notice ok">تنظیمات صفحه VIP ذخیره شد.</div><?php elseif ($status === 'reset'): ?><div class="notice ok">تنظیمات صفحه VIP به حالت اولیه برگشت.</div><?php elseif ($status === 'error'): ?><div class="notice bad">ذخیره تنظیمات انجام نشد. دسترسی نوشتن پوشه خصوصی هاست را بررسی کن.</div><?php endif; ?>

  <form method="post" action="admin_vip_manager.php" id="vipManagerForm">
    <input type="hidden" name="csrf_token" value="<?= bm_vip_admin_h($csrf) ?>">
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="plans_present" value="1">
    <input type="hidden" name="features_present" value="1">
    <input type="hidden" name="watch_party_badges_present" value="1">

    <div class="grid">
      <section class="card half">
        <h2>متن‌های بالای صفحه</h2><p class="sub">این متن‌ها بالای معرفی Watch Party و کارت‌های اشتراک نمایش داده می‌شوند.</p>
        <div class="form-grid">
          <input type="hidden" name="preview_badge" value="">
          <div class="field"><label>تیتر کوچک انگلیسی</label><input name="section_eyebrow" value="<?= bm_vip_admin_h($settings['section_eyebrow'] ?? '') ?>"></div>
          <div class="field"><label>عنوان اصلی انتخاب پلن</label><input name="section_title" value="<?= bm_vip_admin_h($settings['section_title'] ?? '') ?>"></div>
          <div class="field full"><label>توضیح زیر عنوان</label><textarea name="section_description"><?= bm_vip_admin_h($settings['section_description'] ?? '') ?></textarea></div>
        </div>
      </section>

      <section class="card half">
        <h2>معرفی Watch Party</h2><p class="sub">این بخش یک کارت توضیحی جمع‌وجور است و هیرو محسوب نمی‌شود.</p>
        <div class="form-grid">
          <div class="field full"><label class="check"><input type="checkbox" name="watch_party_enabled" value="1" <?= !empty($settings['watch_party_enabled']) ? 'checked' : '' ?>> نمایش توضیحات Watch Party</label></div>
          <div class="field"><label>تیتر کوچک</label><input name="watch_party_kicker" value="<?= bm_vip_admin_h($settings['watch_party_kicker'] ?? '') ?>"></div>
          <div class="field"><label>عنوان</label><input name="watch_party_title" value="<?= bm_vip_admin_h($settings['watch_party_title'] ?? '') ?>"></div>
          <div class="field full"><label>متن کامل معرفی</label><textarea name="watch_party_body" style="min-height:160px"><?= bm_vip_admin_h($settings['watch_party_body'] ?? '') ?></textarea></div>
        </div>
      </section>

      <section class="card">
        <div class="repeat-head"><div><h2>برچسب‌های معرفی Watch Party</h2><p class="sub" style="margin:5px 0 0">موارد کوتاه مثل پخش هماهنگ و چت داخل پلیر.</p></div><button class="btn" type="button" id="addWatchBadge">افزودن برچسب</button></div>
        <div class="repeat-list" id="watchBadgeList">
          <?php foreach ($watchBadges as $index => $badge): ?>
            <div class="repeat-item simple-row"><div class="form-grid"><div class="field" style="grid-column:span 11"><label>متن برچسب</label><input name="watch_party_badges[<?= (int)$index ?>]" value="<?= bm_vip_admin_h($badge) ?>"></div><div class="field" style="grid-column:span 1;display:flex;align-items:end"><button class="mini remove js-remove" type="button">حذف</button></div></div></div>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="card">
        <div class="repeat-head"><div><h2>پلن‌های اشتراک و قیمت‌ها</h2><p class="sub" style="margin:5px 0 0">پلن جدید بساز، پلن قبلی را حذف کن یا ترتیب نمایش را تغییر بده.</p></div><button class="btn primary" type="button" id="addPlan">افزودن پلن</button></div>
        <div class="repeat-list" id="planList">
          <?php foreach ($plans as $index => $plan): ?>
          <article class="repeat-item plan-item">
            <div class="repeat-head"><strong class="js-item-title"><?= bm_vip_admin_h($plan['name'] ?? ('پلن ' . ($index + 1))) ?></strong><div class="row-actions"><button class="mini js-up" type="button" title="انتقال به بالا">بالا</button><button class="mini js-down" type="button" title="انتقال به پایین">پایین</button><button class="mini remove js-remove" type="button">حذف</button></div></div>
            <div class="form-grid">
              <div class="field third"><label>نام پلن</label><input data-key="name" name="plans[<?= (int)$index ?>][name]" value="<?= bm_vip_admin_h($plan['name'] ?? '') ?>"></div>
              <div class="field third"><label>عنوان لاتین</label><input data-key="latin" name="plans[<?= (int)$index ?>][latin]" value="<?= bm_vip_admin_h($plan['latin'] ?? '') ?>"></div>
              <div class="field third"><label>قیمت بدون واحد</label><input data-key="price" name="plans[<?= (int)$index ?>][price]" value="<?= bm_vip_admin_h($plan['price'] ?? '') ?>"></div>
              <div class="field third"><label>مدت دسترسی</label><input data-key="period" name="plans[<?= (int)$index ?>][period]" value="<?= bm_vip_admin_h($plan['period'] ?? '') ?>"></div>
              <div class="field third"><label>نشان پلن</label><input data-key="badge" name="plans[<?= (int)$index ?>][badge]" value="<?= bm_vip_admin_h($plan['badge'] ?? '') ?>"></div>
              <div class="field third"><label>متن صرفه‌جویی</label><input data-key="saving" name="plans[<?= (int)$index ?>][saving]" value="<?= bm_vip_admin_h($plan['saving'] ?? '') ?>"></div>
              <div class="field third"><label>رنگ کارت</label><select data-key="tone" name="plans[<?= (int)$index ?>][tone]"><?php foreach (['blue'=>'آبی','violet'=>'بنفش','premium'=>'پرمیوم','gold'=>'طلایی'] as $value=>$label): ?><option value="<?= $value ?>" <?= (($plan['tone'] ?? '') === $value) ? 'selected' : '' ?>><?= $label ?></option><?php endforeach; ?></select></div>
              <div class="field third"><label class="check"><input data-key="featured" type="checkbox" name="plans[<?= (int)$index ?>][featured]" value="1" <?= !empty($plan['featured']) ? 'checked' : '' ?>> پلن پیشنهادی</label></div>
              <div class="field third"><label class="check"><input data-key="enabled" type="checkbox" name="plans[<?= (int)$index ?>][enabled]" value="1" <?= !empty($plan['enabled']) ? 'checked' : '' ?>> نمایش پلن</label></div>
            </div>
          </article>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="card">
        <div class="repeat-head"><div><h2>امکانات VIP</h2><p class="sub" style="margin:5px 0 0">این فهرست داخل تمام کارت‌های اشتراک نمایش داده می‌شود.</p></div><button class="btn primary" type="button" id="addFeature">افزودن امکان</button></div>
        <div class="repeat-list" id="featureList">
          <?php foreach ($features as $index => $feature): ?>
          <div class="repeat-item feature-item"><div class="form-grid"><div class="field" style="grid-column:span 9"><label>عنوان امکان</label><input data-key="label" name="features[<?= (int)$index ?>][label]" value="<?= bm_vip_admin_h($feature['label'] ?? '') ?>"></div><div class="field" style="grid-column:span 2"><label class="check"><input data-key="enabled" type="checkbox" name="features[<?= (int)$index ?>][enabled]" value="1" <?= !empty($feature['enabled']) ? 'checked' : '' ?>> نمایش</label></div><div class="field" style="grid-column:span 1;display:flex;align-items:end"><button class="mini remove js-remove" type="button">حذف</button></div></div></div>
          <?php endforeach; ?>
        </div>
      </section>

      <section class="card">
        <h2>خرید و هماهنگی در تلگرام</h2><p class="sub">فعال‌سازی دکمه‌های خرید و اطلاعات پشتیبانی فروش از این بخش کنترل می‌شود.</p>
        <div class="form-grid">
          <div class="field third"><label class="check"><input type="checkbox" name="purchase_enabled" value="1" <?= !empty($settings['purchase_enabled']) ? 'checked' : '' ?>> فعال‌بودن خرید تلگرامی</label></div>
          <div class="field third"><label>نام کاربری تلگرام</label><input name="telegram_username" dir="ltr" value="<?= bm_vip_admin_h($settings['telegram_username'] ?? '') ?>"><small>بدون علامت @ وارد شود.</small></div>
          <div class="field full"><label>راهنمای خرید</label><textarea name="purchase_instruction"><?= bm_vip_admin_h($settings['purchase_instruction'] ?? '') ?></textarea></div>
          <div class="field full"><label>متن آماده سفارش</label><textarea name="purchase_message_template"><?= bm_vip_admin_h($settings['purchase_message_template'] ?? '') ?></textarea><small>متغیرهای {plan} و {price} با نام و قیمت پلن جایگزین می‌شوند و متن هنگام کلیک روی دکمه خرید کپی می‌شود.</small></div>
        </div>
      </section>

      <section class="card half">
        <h2>متن‌های داخل کارت</h2><p class="sub">واحد قیمت، دکمه و متن‌های ثابت تمام پلن‌ها.</p>
        <div class="form-grid">
          <div class="field"><label>عنوان اشتراک</label><input name="card_subscription_title" value="<?= bm_vip_admin_h($settings['card_subscription_title'] ?? '') ?>"></div>
          <div class="field"><label>واحد قیمت</label><textarea name="currency_label" style="min-height:70px"><?= bm_vip_admin_h($settings['currency_label'] ?? '') ?></textarea><small>برای شکستن خط Enter بزن.</small></div>
          <div class="field"><label>متن دکمه انتخاب</label><input name="select_button_label" value="<?= bm_vip_admin_h($settings['select_button_label'] ?? '') ?>"></div>
          <div class="field"><label>عنوان امکانات</label><input name="features_label" value="<?= bm_vip_admin_h($settings['features_label'] ?? '') ?>"></div>
          <div class="field"><label>نشان پلن محبوب</label><input name="featured_ribbon_label" value="<?= bm_vip_admin_h($settings['featured_ribbon_label'] ?? '') ?>"></div>
          <div class="field"><label>پیام پس از کلیک خرید</label><input name="toast_template" value="<?= bm_vip_admin_h($settings['toast_template'] ?? '') ?>"><small>متغیر {plan} با نام پلن جایگزین می‌شود.</small></div>
          <div class="field full"><label>یادداشت پایین کارت</label><textarea name="card_note"><?= bm_vip_admin_h($settings['card_note'] ?? '') ?></textarea></div>
        </div>
      </section>

      <section class="card half">
        <h2>بخش پایانی صفحه</h2><p class="sub">متن معرفی پایانی و دکمه بازگشت.</p>
        <div class="form-grid">
          <div class="field full"><label>عنوان</label><input name="footer_title" value="<?= bm_vip_admin_h($settings['footer_title'] ?? '') ?>"></div>
          <div class="field full"><label>توضیح</label><textarea name="footer_description"><?= bm_vip_admin_h($settings['footer_description'] ?? '') ?></textarea></div>
          <div class="field"><label>متن دکمه</label><input name="footer_button_label" value="<?= bm_vip_admin_h($settings['footer_button_label'] ?? '') ?>"></div>
          <div class="field"><label>آدرس دکمه</label><input name="footer_button_url" value="<?= bm_vip_admin_h($settings['footer_button_url'] ?? '') ?>"></div>
        </div>
      </section>
    </div>

    <div class="sticky-save"><span>پس از ذخیره، صفحه VIP فوراً با تنظیمات جدید نمایش داده می‌شود.</span><button class="btn primary" type="submit">ذخیره همه تغییرات</button></div>
  </form>

  <form method="post" action="admin_vip_manager.php" style="margin-top:14px" onsubmit="return confirm('تمام متن‌ها و قیمت‌های صفحه VIP به حالت اولیه برگردند؟')">
    <input type="hidden" name="csrf_token" value="<?= bm_vip_admin_h($csrf) ?>"><input type="hidden" name="action" value="reset"><button class="btn danger" type="submit">بازگردانی تنظیمات اولیه</button>
  </form>
</main>

<template id="planTemplate">
  <article class="repeat-item plan-item">
    <div class="repeat-head"><strong class="js-item-title">پلن جدید</strong><div class="row-actions"><button class="mini js-up" type="button">بالا</button><button class="mini js-down" type="button">پایین</button><button class="mini remove js-remove" type="button">حذف</button></div></div>
    <div class="form-grid">
      <div class="field third"><label>نام پلن</label><input data-key="name" value="پلن جدید"></div><div class="field third"><label>عنوان لاتین</label><input data-key="latin"></div><div class="field third"><label>قیمت بدون واحد</label><input data-key="price"></div>
      <div class="field third"><label>مدت دسترسی</label><input data-key="period"></div><div class="field third"><label>نشان پلن</label><input data-key="badge"></div><div class="field third"><label>متن صرفه‌جویی</label><input data-key="saving"></div>
      <div class="field third"><label>رنگ کارت</label><select data-key="tone"><option value="blue">آبی</option><option value="violet">بنفش</option><option value="premium">پرمیوم</option><option value="gold">طلایی</option></select></div>
      <div class="field third"><label class="check"><input data-key="featured" type="checkbox" value="1"> پلن پیشنهادی</label></div><div class="field third"><label class="check"><input data-key="enabled" type="checkbox" value="1" checked> نمایش پلن</label></div>
    </div>
  </article>
</template>
<template id="featureTemplate"><div class="repeat-item feature-item"><div class="form-grid"><div class="field" style="grid-column:span 9"><label>عنوان امکان</label><input data-key="label"></div><div class="field" style="grid-column:span 2"><label class="check"><input data-key="enabled" type="checkbox" value="1" checked> نمایش</label></div><div class="field" style="grid-column:span 1;display:flex;align-items:end"><button class="mini remove js-remove" type="button">حذف</button></div></div></div></template>
<template id="badgeTemplate"><div class="repeat-item simple-row"><div class="form-grid"><div class="field" style="grid-column:span 11"><label>متن برچسب</label><input></div><div class="field" style="grid-column:span 1;display:flex;align-items:end"><button class="mini remove js-remove" type="button">حذف</button></div></div></div></template>
<script>
(function(){
  'use strict';
  var planList=document.getElementById('planList'), featureList=document.getElementById('featureList'), badgeList=document.getElementById('watchBadgeList');
  function reindex(){
    planList.querySelectorAll('.plan-item').forEach(function(item,i){item.querySelectorAll('[data-key]').forEach(function(el){el.name='plans['+i+']['+el.dataset.key+']';});var n=item.querySelector('[data-key="name"]');var t=item.querySelector('.js-item-title');if(n&&t)t.textContent=n.value||('پلن '+(i+1));});
    featureList.querySelectorAll('.feature-item').forEach(function(item,i){item.querySelectorAll('[data-key]').forEach(function(el){el.name='features['+i+']['+el.dataset.key+']';});});
    badgeList.querySelectorAll('.simple-row').forEach(function(item,i){var el=item.querySelector('input');if(el)el.name='watch_party_badges['+i+']';});
  }
  document.addEventListener('click',function(e){
    var remove=e.target.closest('.js-remove');if(remove){remove.closest('.repeat-item').remove();reindex();return;}
    var up=e.target.closest('.js-up');if(up){var item=up.closest('.repeat-item'),prev=item.previousElementSibling;if(prev)item.parentNode.insertBefore(item,prev);reindex();return;}
    var down=e.target.closest('.js-down');if(down){var item2=down.closest('.repeat-item'),next=item2.nextElementSibling;if(next)item2.parentNode.insertBefore(next,item2);reindex();return;}
  });
  document.addEventListener('input',function(e){if(e.target.matches('.plan-item [data-key="name"]'))reindex();});
  document.getElementById('addPlan').addEventListener('click',function(){planList.appendChild(document.getElementById('planTemplate').content.cloneNode(true));reindex();});
  document.getElementById('addFeature').addEventListener('click',function(){featureList.appendChild(document.getElementById('featureTemplate').content.cloneNode(true));reindex();});
  document.getElementById('addWatchBadge').addEventListener('click',function(){badgeList.appendChild(document.getElementById('badgeTemplate').content.cloneNode(true));reindex();});
  reindex();
})();
</script>
</body>
</html>
