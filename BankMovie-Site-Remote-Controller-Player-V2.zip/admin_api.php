<?php
// admin_api.php - API خواندنی پنل مدیریت BankMovie Pro

declare(strict_types=1);
require_once __DIR__ . '/includes/admin_core.php';

bm_require_admin(true);
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
admin_panel_bootstrap($pdo);
$action = (string)($_GET['action'] ?? $_POST['action'] ?? '');

try {
    switch ($action) {
        case 'stats':
            bm_json_out(['success' => true, 'data' => bm_get_dashboard_stats($pdo)]);

        case 'list_movies': {
            $page = bm_safe_int($_GET['page'] ?? 1, 1, 999999);
            $perPage = bm_safe_int($_GET['per_page'] ?? 20, 5, 100);
            $offset = ($page - 1) * $perPage;
            $search = trim((string)($_GET['q'] ?? ''));
            $type = (string)($_GET['type'] ?? 'all');
            $missing = (string)($_GET['missing'] ?? 'all');

            $where = [];
            $params = [];
            if ($search !== '') {
                $where[] = '(m.title LIKE ? OR m.title_fa LIKE ? OR m.imdb_code LIKE ? OR m.actors LIKE ? OR m.director LIKE ?)';
                $term = '%' . $search . '%';
                array_push($params, $term, $term, $term, $term, $term);
            }
            if ($type !== 'all') {
                if ($type === 'series') $where[] = "(m.type = 'tvSeries' OR m.type = 'tvMiniSeries' OR m.type LIKE '%Series%')";
                else { $where[] = 'm.type = ?'; $params[] = $type; }
            }
            if ($missing === 'imdb') $where[] = "(m.imdb_code IS NULL OR m.imdb_code = '')";
            if ($missing === 'link') $where[] = 'NOT EXISTS (SELECT 1 FROM softsub_links sl WHERE sl.movie_id = m.id) AND NOT EXISTS (SELECT 1 FROM dubbed_links dl WHERE dl.movie_id = m.id)';
            if ($missing === 'description') $where[] = "(m.description IS NULL OR m.description = '')";
            if ($missing === 'genre') $where[] = "(m.genres IS NULL OR m.genres = '')";

            $whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';
            $countStmt = $pdo->prepare("SELECT COUNT(*) FROM movies m $whereSql");
            $countStmt->execute($params);
            $total = (int)$countStmt->fetchColumn();

            $sql = "SELECT m.id, m.title, m.title_fa, m.imdb_code, m.type, m.year, m.imdb_rate, m.imdb_votes, m.updated_at,
                           (SELECT COUNT(*) FROM softsub_links WHERE movie_id = m.id) AS soft_count,
                           (SELECT COUNT(*) FROM dubbed_links WHERE movie_id = m.id) AS dub_count,
                           (SELECT COUNT(*) FROM comments WHERE movie_id = m.id AND status = 'pending') AS pending_comments
                    FROM movies m
                    $whereSql
                    ORDER BY m.id DESC
                    LIMIT $perPage OFFSET $offset";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$row) {
                $posterBase = $row['imdb_code'] ?: $row['id'];
                $poster = 'posters/' . $posterBase . '.webp';
                $row['poster'] = $poster;
                $row['poster_missing'] = !is_file(__DIR__ . '/' . $poster);
                $row['title_display'] = $row['title_fa'] ?: $row['title'];
            }
            unset($row);
            bm_json_out(['success' => true, 'data' => [
                'items' => $rows,
                'total' => $total,
                'page' => $page,
                'per_page' => $perPage,
                'last_page' => max(1, (int)ceil($total / $perPage)),
            ]]);
        }

        case 'search_movies': {
            $term = trim((string)($_GET['q'] ?? ''));
            $termLength = function_exists('mb_strlen') ? mb_strlen($term, 'UTF-8') : strlen($term);
            if ($termLength < 2) bm_json_out(['success' => true, 'data' => []]);
            $like = '%' . $term . '%';
            $stmt = $pdo->prepare("SELECT id, title, title_fa, imdb_code, year, type, imdb_rate FROM movies WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ? OR actors LIKE ? OR director LIKE ? ORDER BY CASE WHEN title LIKE ? THEN 1 WHEN title_fa LIKE ? THEN 2 ELSE 3 END, year DESC LIMIT 20");
            $stmt->execute([$like, $like, $like, $like, $like, $like, $like]);
            bm_json_out(['success' => true, 'data' => $stmt->fetchAll()]);
        }

        case 'recent_logs': {
            bm_ensure_admin_logs($pdo);
            $stmt = $pdo->query("SELECT l.*, u.username FROM admin_logs l LEFT JOIN users u ON l.admin_id = u.id ORDER BY l.id DESC LIMIT 30");
            bm_json_out(['success' => true, 'data' => $stmt->fetchAll()]);
        }

        default:
            bm_json_out(['success' => false, 'error' => 'action not found'], 404);
    }
} catch (Throwable $e) {
    error_log('Admin API error [' . $action . ']: ' . $e->getMessage());
    bm_json_out(['success' => false, 'error' => 'خطای داخلی پنل مدیریت'], 500);
}
?>