<?php
require_once 'config.php';

$fetchSite = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
if ($fetchSite === 'cross-site') { http_response_code(403); exit('Forbidden'); }

$sessionToken = $_COOKIE['session_token'] ?? '';
if($sessionToken) {
    $user->logout($sessionToken);
    setcookie('session_token', '', bm_session_cookie_options(-3600));
}

$_SESSION = [];
session_destroy();

header('Location: /login');
exit;
?>