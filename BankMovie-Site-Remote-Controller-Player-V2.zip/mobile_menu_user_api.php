<?php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

try {
    require_once __DIR__ . '/config.php';
    require_once __DIR__ . '/includes/vip_features.php';
    require_once __DIR__ . '/includes/user_avatar.php';

    $userData = is_array($currentUser ?? null) ? $currentUser : null;
    if (!$userData) {
        echo json_encode([
            'ok' => true,
            'logged_in' => false,
            'lang' => (($_COOKIE['user_lang'] ?? 'fa') === 'en') ? 'en' : 'fa',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $role = strtolower(trim((string)($userData['role'] ?? 'user')));
    $isAdmin = in_array($role, ['admin', 'administrator'], true);
    $vipRemaining = bm_vip_remaining($userData);
    $isVip = $isAdmin || bm_vip_user_is_active($userData);

    $avatarRaw = trim((string)($userData['avatar'] ?? ''));
    $hasAvatar = false;
    $avatarUrl = '';
    if ($avatarRaw !== '' && (bm_user_avatar_is_uploaded($avatarRaw) || bm_user_avatar_is_preset($avatarRaw))) {
        $resolved = bm_user_avatar_path($avatarRaw);
        if ($resolved !== 'assets/avatars/avatar_default.webp') {
            $hasAvatar = true;
            $avatarUrl = '/' . ltrim($resolved, '/');
        }
    }

    $expiresLabel = '';
    $expiresAt = trim((string)($vipRemaining['expires_at'] ?? ''));
    if ($expiresAt !== '') {
        $expiresTs = strtotime($expiresAt);
        if ($expiresTs !== false) {
            $expiresLabel = date('Y/m/d - H:i', $expiresTs);
        }
    }

    echo json_encode([
        'ok' => true,
        'logged_in' => true,
        'lang' => (($userData['language'] ?? ($_COOKIE['user_lang'] ?? 'fa')) === 'en') ? 'en' : 'fa',
        'username' => trim((string)($userData['username'] ?? '')) ?: 'User',
        'role' => $role,
        'role_label_fa' => $isAdmin ? 'مدیر' : ($isVip ? 'عضو ویژه' : 'کاربر'),
        'role_label_en' => $isAdmin ? 'Admin' : ($isVip ? 'VIP member' : 'User'),
        'is_admin' => $isAdmin,
        'is_vip' => $isVip,
        'vip_lifetime' => $isAdmin || (!empty($vipRemaining['active']) && !empty($vipRemaining['lifetime'])),
        'vip_days_remaining' => $isAdmin ? null : (int)($vipRemaining['days'] ?? 0),
        'vip_expires_label' => $expiresLabel,
        'has_avatar' => $hasAvatar,
        'avatar_url' => $avatarUrl,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'ok' => false,
        'logged_in' => false,
        'error' => 'mobile_menu_user_unavailable',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
