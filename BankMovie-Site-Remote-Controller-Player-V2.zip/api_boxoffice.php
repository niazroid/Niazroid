<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/boxoffice.php';

header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');
header('Cache-Control: public, max-age=60, stale-while-revalidate=240');

$mode = strtolower(trim((string)($_GET['mode'] ?? 'weekend')));
$mode = $mode === 'alltime' ? 'alltime' : 'weekend';
$isAdmin = is_array($currentUser ?? null) && in_array(strtolower(trim((string)($currentUser['role'] ?? ''))), ['admin','administrator'], true);
$force = $isAdmin && !empty($_GET['refresh']);

function bm_bo_public_payload(array $payload): array
{
    // Keep provider/transport details out of the public response, but return
    // the poster URL itself so browsers can render it normally.
    unset($payload['source'], $payload['source_label'], $payload['transport']);
    return $payload;
}

try {
    $payload = bm_boxoffice_get_data($pdo, $mode, $force);
    $payload = bm_bo_public_payload($payload);
    if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
    $status = !empty($payload['disabled']) ? 404 : (!empty($payload['success']) ? 200 : 503);
    http_response_code($status);
    $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    if (!is_string($json)) throw new RuntimeException('JSON encode failed');
    $etag = '"' . substr(hash('sha256', $json), 0, 32) . '"';
    header('ETag: ' . $etag);
    if (!$force && trim((string)($_SERVER['HTTP_IF_NONE_MATCH'] ?? '')) === $etag) {
        http_response_code(304);
        exit;
    }
    echo $json;
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'mode' => $mode,
        'message' => 'دریافت باکس آفیس موقتاً ممکن نیست.',
        'items' => [],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    error_log('BoxOffice API endpoint error: ' . $e->getMessage());
}
