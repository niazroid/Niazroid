Bankmovie Pass 3 - Archive 1 Likes / Satisfaction API Patch

1) app_api.php را در روت سایت جایگزین کنید.
2) includes/api2_lib.php در سورس ارسالی شما از قبل feedback-satisfaction را استخراج می‌کند؛ نسخه همراه برای همگام‌سازی قرار داده شده است.
3) app_api.php مقدار feedback_satisfaction و alias likes را به پاسخ Detail اپ اضافه می‌کند.
4) قبل از جایگزینی از فایل‌های فعلی بکاپ بگیرید.
