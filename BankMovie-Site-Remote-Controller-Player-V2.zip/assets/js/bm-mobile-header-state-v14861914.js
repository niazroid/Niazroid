(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  ready(function(){
    var header = document.getElementById('siteHeader');
    if(!header) return;

    var mq = window.matchMedia ? window.matchMedia('(max-width: 991.98px)') : {matches: window.innerWidth < 992};
    var page = String(header.getAttribute('data-bm-page') || '').toLowerCase();
    var hero = page === 'index.php' ? document.querySelector('.hero-slider') : (page === 'collection.php' ? document.querySelector('.collection-hero-main') : null);
    var raf = 0;

    function apply(){
      raf = 0;
      if(!mq.matches){
        header.classList.remove('is-mobile-surface-transparent');
        return;
      }

      /* Homepage slider and collection detail hero may switch to a truly
         transparent surface while the header is visually over their artwork.
         Every other page keeps one stable attached glass header. */
      if((page !== 'index.php' && page !== 'collection.php') || !hero || hero.offsetHeight <= 0){
        header.classList.remove('is-mobile-surface-transparent');
        return;
      }

      var headerHeight = Math.max(1, header.offsetHeight || 58);
      var limit = Math.max(24, (hero.offsetTop || 0) + hero.offsetHeight - headerHeight - 18);
      var y = window.pageYOffset || document.documentElement.scrollTop || 0;
      header.classList.toggle('is-mobile-surface-transparent', y <= limit);
    }

    function requestApply(){
      if(raf) return;
      raf = requestAnimationFrame(apply);
    }

    apply();
    window.addEventListener('scroll', requestApply, {passive:true});
    window.addEventListener('resize', requestApply, {passive:true});
    window.addEventListener('orientationchange', requestApply, {passive:true});
    window.addEventListener('pageshow', requestApply, {passive:true});
    window.addEventListener('load', requestApply, {once:true});
    if(mq.addEventListener) mq.addEventListener('change', requestApply);
    else if(mq.addListener) mq.addListener(requestApply);
  });
})();
