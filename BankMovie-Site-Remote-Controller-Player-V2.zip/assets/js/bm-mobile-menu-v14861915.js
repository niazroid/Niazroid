(function(){
  'use strict';
  if (window.__BM_MOBILE_MENU_14861915__) return;
  window.__BM_MOBILE_MENU_14861915__ = true;

  var STRINGS = {
    fa: {
      tagline: 'بهترین فیلم‌ها، همیشه با شما',
      quick: 'دسترسی سریع',
      account: 'حساب کاربری و ابزارها',
      premium: 'اشتراک', premiumBuy: 'خرید اشتراک', premiumActive: 'اشتراک فعال', home: 'خانه', player: 'پلیر', categories: 'دسته‌بندی', profile: 'پروفایل', admin: 'پنل مدیریت', apps: 'اپلیکیشن‌ها',
      login: 'ورود', register: 'ثبت‌نام', logout: 'خروج', logoutSub: 'خروج از حساب کاربری',
      user: 'کاربر', adminRole: 'مدیر', vipRole: 'عضو ویژه',
      vipActive: 'اشتراک ویژه فعال است', vipActiveCopy: 'حساب ویژه شما فعال است.', vipLifetime: 'بدون انقضا',
      remainingLabel: 'باقی‌مانده', days: 'روز',
      vipInactive: 'عضویت ویژه BankMovie', vipBuyCopy: 'با عضویت ویژه امکانات کامل بانک مووی را فعال کنید.', vipBuy: 'SUBSCRIBE',
      feature1: 'واچ‌پارتی', feature2: 'درخواست فیلم و سریال', feature3: 'امکانات اختصاصی'
    },
    en: {
      tagline: 'Best movies, always with you',
      quick: 'Quick access', account: 'Account & tools',
      premium: 'Subscription', premiumBuy: 'Buy subscription', premiumActive: 'Subscription active', home: 'Home', player: 'Player', categories: 'Categories', profile: 'Profile', admin: 'Admin Panel', apps: 'Applications',
      login: 'Login', register: 'Register', logout: 'Logout', logoutSub: 'Sign out of your account',
      user: 'User', adminRole: 'Admin', vipRole: 'VIP member',
      vipActive: 'VIP membership is active', vipActiveCopy: 'Your premium membership is active.', vipLifetime: 'No expiry',
      remainingLabel: 'Remaining', days: 'days',
      vipInactive: 'BankMovie Premium', vipBuyCopy: 'Unlock the complete BankMovie experience.', vipBuy: 'SUBSCRIBE',
      feature1: 'Watch Party', feature2: 'Content Requests', feature3: 'Premium Features'
    }
  };

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  function svg(name){
    var icons = {
      user: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>',
      crown: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="m3 8 4 4 5-7 5 7 4-4-2 10H5L3 8Z"></path></svg>',
      premium: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 15 9l6 .8-4.5 4.4 1.1 6.3L12 17.6 6.4 20.5l1.1-6.3L3 9.8 9 9l3-6Z"></path></svg>',
      chevron: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18 9 12l6-6"></path></svg>',
      home: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V10Z"></path></svg>',
      player: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="m8 5 11 7-11 7V5Z"></path></svg>',
      categories: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="3" y="3" width="7" height="7" rx="2"></rect><rect x="14" y="3" width="7" height="7" rx="2"></rect><rect x="3" y="14" width="7" height="7" rx="2"></rect><rect x="14" y="14" width="7" height="7" rx="2"></rect></svg>',
      profile: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"></circle><path d="M4 21a8 8 0 0 1 16 0"></path></svg>',
      admin: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 4.5 6v5c0 5 3.2 8 7.5 10 4.3-2 7.5-5 7.5-10V6L12 3Z"></path><path d="m9.5 12 1.6 1.6 3.5-3.7"></path></svg>',
      apps: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="6" y="2" width="12" height="20" rx="3"></rect><path d="M10 18h4"></path></svg>',
      login: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path><path d="m10 17 5-5-5-5"></path><path d="M15 12H3"></path></svg>',
      register: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="8" r="4"></circle><path d="M2 21a7 7 0 0 1 14 0"></path><path d="M19 8v6M22 11h-6"></path></svg>',
      logout: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><path d="m16 17 5-5-5-5"></path><path d="M21 12H9"></path></svg>'
    };
    return icons[name] || icons.user;
  }

  function currentPathActive(href){
    try {
      var here = location.pathname.replace(/\/+$/,'') || '/';
      var target = new URL(href, location.origin).pathname.replace(/\/+$/,'') || '/';
      if(target === '/') return here === '/';
      return here === target || here.indexOf(target + '/') === 0;
    } catch(e){ return false; }
  }

  function menuItem(key, href, label, extraClass){
    var a = document.createElement('a');
    a.className = 'sidebar-item' + (extraClass ? ' ' + extraClass : '') + (currentPathActive(href) ? ' active' : '');
    a.href = href;
    a.innerHTML = '<span class="bm-menu-iconbox" aria-hidden="true">'+svg(key)+'</span>'+
                  '<span class="bm-menu-item-label">'+label+'</span>'+
                  '<span class="bm-menu-chevron" aria-hidden="true">'+svg('chevron')+'</span>';
    return a;
  }

  function sectionTitle(label){
    var el = document.createElement('div');
    el.className = 'bm-menu-section-title';
    el.textContent = label;
    return el;
  }

  function getLanguage(data){
    if(data && data.lang === 'en') return 'en';
    var lang = (document.documentElement.getAttribute('lang') || '').toLowerCase();
    return lang.indexOf('en') === 0 ? 'en' : 'fa';
  }

  function localNumber(value, lang){
    var text = String(value == null ? '' : value);
    if(lang !== 'fa') return text;
    return text.replace(/[0-9]/g, function(d){ return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; });
  }

  function fallbackData(menu){
    var username = '';
    var role = '';
    var userBlock = menu.querySelector('.sidebar-user');
    if(userBlock){
      var nameEl = userBlock.querySelector('.sidebar-username');
      var roleEl = userBlock.querySelector('.sidebar-userrole');
      username = nameEl ? (nameEl.textContent || '').trim() : '';
      role = roleEl ? (roleEl.textContent || '').trim() : '';
    }
    return {
      ok: true,
      logged_in: !!userBlock,
      username: username || 'User',
      role_label_fa: role || 'کاربر',
      role_label_en: role || 'User',
      is_admin: /admin|مدیر/i.test(role),
      is_vip: false,
      vip_lifetime: false,
      vip_days_remaining: 0,
      vip_expires_label: '',
      has_avatar: false,
      avatar_url: ''
    };
  }

  function updateHeader(menu, t){
    var header = menu.querySelector('.sidebar-header');
    if(!header) return;
    var close = header.querySelector('.sidebar-close');
    var brand = document.createElement('div');
    brand.className = 'bm-menu-brand';
    brand.innerHTML = '<img class="bm-menu-brand-logo" src="/assets/brand/bankmovie-logo.webp" alt="BankMovie" decoding="async"><div class="bm-menu-brand-tagline">'+t.tagline+'</div>';
    header.innerHTML = '';
    header.appendChild(brand);
    if(close) header.appendChild(close);
  }

  function updateUser(menu, data, t){
    var existing = menu.querySelector('.sidebar-user');
    if(!data.logged_in){
      if(existing) existing.remove();
      return null;
    }
    var card = existing || document.createElement('div');
    card.className = 'sidebar-user';
    var avatar = data.has_avatar && data.avatar_url
      ? '<div class="bm-menu-avatar"><img src="'+data.avatar_url.replace(/"/g,'&quot;')+'" alt=""></div>'
      : '<div class="bm-menu-avatar-fallback">'+svg('user')+'</div>';
    var roleLabel = data.is_admin ? t.adminRole : (data.is_vip ? t.vipRole : t.user);
    var showPill = data.is_admin;
    var pill = showPill ? '<span class="bm-menu-role-pill">'+svg('admin')+'<span>'+roleLabel+'</span></span>' : '';
    card.innerHTML = '<div class="bm-menu-avatar-shell">'+avatar+'</div><div class="bm-menu-user-copy"><div class="sidebar-username"></div><div class="sidebar-userrole"></div>'+pill+'</div>';
    card.querySelector('.sidebar-username').textContent = data.username || 'User';
    card.querySelector('.sidebar-userrole').textContent = roleLabel;
    var img = card.querySelector('img');
    if(img){
      img.addEventListener('error', function(){
        var shell = card.querySelector('.bm-menu-avatar-shell');
        var bad = shell && shell.querySelector('.bm-menu-avatar');
        if(bad) bad.outerHTML = '<div class="bm-menu-avatar-fallback">'+svg('user')+'</div>';
      }, {once:true});
    }
    if(!existing){
      var header = menu.querySelector('.sidebar-header');
      if(header) header.insertAdjacentElement('afterend', card);
    }
    return card;
  }

  function updateMembership(menu){
    // The drawer uses a single subscription row. Remove legacy/detailed VIP cards.
    menu.querySelectorAll('.bm-menu-membership,.bm-menu-subscription,[data-bm-vip-card]').forEach(function(node){ node.remove(); });
  }

  function rebuildNav(menu, data, t){
    var nav = menu.querySelector('.sidebar-nav');
    if(!nav){
      nav = document.createElement('nav');
      nav.className = 'sidebar-nav';
      menu.appendChild(nav);
    }
    nav.innerHTML = '';
    nav.appendChild(sectionTitle(t.quick));
    var premiumActive = !!(data.logged_in && data.is_vip);
    var premiumHref = premiumActive ? '/vip?manage=1' : '/vip';
    var premiumItem = menuItem('premium', premiumHref, premiumActive ? t.premiumActive : t.premiumBuy, 'is-premium-link' + (premiumActive ? ' is-vip-active' : ''));
    premiumItem.setAttribute('data-vip-state', premiumActive ? 'active' : 'inactive');
    nav.appendChild(premiumItem);
    nav.appendChild(menuItem('apps','/application',t.apps));
    nav.appendChild(menuItem('home','/',t.home));
    nav.appendChild(menuItem('player','/player',t.player));
    nav.appendChild(menuItem('categories','/categories',t.categories));

    nav.appendChild(sectionTitle(t.account));
    if(data.logged_in){
      nav.appendChild(menuItem('profile','/profile',t.profile));
      if(data.is_admin) nav.appendChild(menuItem('admin','/admin.php',t.admin));
    }
  }

  function installDesktopPremium(data, t){
    var nav = document.querySelector('#siteHeader .desktop-nav');
    if(!nav) return;
    nav.querySelectorAll('a,button').forEach(function(node){
      var href = String(node.getAttribute('href') || '').toLowerCase();
      var txt = String(node.textContent || '').trim();
      if(href.indexOf('collection') !== -1 || href.indexOf('collections') !== -1 || /کالکشن|collections?/i.test(txt)){
        node.remove();
      }
    });
    var old = nav.querySelector('.bm-desktop-vip-cta');
    if(old) old.remove();
    var active = !!(data.logged_in && data.is_vip);
    var link = document.createElement('a');
    link.href = active ? '/vip?manage=1' : '/vip';
    link.className = 'desktop-nav-item bm-desktop-vip-cta' + (active ? ' is-vip-active' : '');
    link.setAttribute('data-vip-state', active ? 'active' : 'inactive');
    if(currentPathActive('/vip')) link.classList.add('active');
    var label = active ? t.premiumActive : t.premiumBuy;
    link.innerHTML = '<span class="bm-desktop-vip-icon">'+svg('crown')+'</span><span class="bm-desktop-vip-label">'+label+'</span>';
    nav.insertBefore(link, nav.firstChild);
  }

  function rebuildFooter(menu, data, t){
    var footer = menu.querySelector('.sidebar-footer');
    if(!footer){
      footer = document.createElement('div');
      footer.className = 'sidebar-footer';
      menu.appendChild(footer);
    }
    footer.innerHTML = '';
    if(data.logged_in){
      var logout = document.createElement('a');
      logout.className = 'sidebar-item is-logout';
      logout.href = '/logout';
      logout.innerHTML = '<span class="bm-menu-iconbox">'+svg('logout')+'</span><span class="bm-menu-footer-copy"><span class="bm-menu-footer-title">'+t.logout+'</span><span class="bm-menu-footer-subtitle">'+t.logoutSub+'</span></span>';
      footer.appendChild(logout);
    } else {
      footer.appendChild(menuItem('login','/login',t.login,'is-auth'));
      footer.appendChild(menuItem('register','/register',t.register,'is-auth'));
    }
  }

  function enhance(menu, data){
    if(!menu || menu.dataset.bmMenuV14861915 === '1') return;
    menu.dataset.bmMenuV14861915 = '1';
    menu.classList.remove('bm-mobile-menu-v148601','bm-menu-v148601','bm-menu-v148602','bm-menu-v148603','bm-menu-v148604','bm-menu-v148605','bm-menu-v148606','bm-menu-v148607','bm-menu-v148608','bm-menu-v148609','bm-menu-v1486198','bm-menu-v14861914');
    menu.removeAttribute('data-bm-menu-enhanced');
    menu.classList.add('bm-menu-v14861915');
    var lang = getLanguage(data);
    var t = STRINGS[lang] || STRINGS.fa;
    updateHeader(menu, t);
    updateUser(menu, data, t);
    updateMembership(menu);
    rebuildNav(menu, data, t);
    rebuildFooter(menu, data, t);
  }

  function inlineUserData(menu){
    var cfg = ((window.BM_SITE_UI || {}).mobileDrawer || {});
    var u = cfg.user || {};
    var fallback = fallbackData(menu);
    if(!Object.keys(u).length) return fallback;
    return {
      ok: true,
      logged_in: !!u.loggedIn,
      username: u.username || fallback.username,
      role_label_fa: u.roleLabel || fallback.role_label_fa,
      role_label_en: u.roleLabel || fallback.role_label_en,
      is_admin: !!u.isAdmin,
      is_vip: !!(u.isVip || u.vipActive),
      vip_lifetime: !!u.vipLifetime,
      vip_days_remaining: Number(u.vipDaysRemaining || 0),
      vip_expires_label: String(u.vipExpiresLabel || ''),
      has_avatar: !!u.hasAvatar,
      avatar_url: String(u.avatarUrl || '')
    };
  }

  function renderMenu(menu, data){
    if(!menu) return;
    menu.classList.remove('bm-mobile-menu-v148601','bm-menu-v148601','bm-menu-v148602','bm-menu-v148603','bm-menu-v148604','bm-menu-v148605','bm-menu-v148606','bm-menu-v148607','bm-menu-v148608','bm-menu-v148609','bm-menu-v1486198','bm-menu-v14861914');
    menu.removeAttribute('data-bm-menu-enhanced');
    menu.classList.add('bm-menu-v14861915');
    var lang = getLanguage(data);
    var t = STRINGS[lang] || STRINGS.fa;
    updateHeader(menu, t);
    updateUser(menu, data, t);
    updateMembership(menu);
    rebuildNav(menu, data, t);
    rebuildFooter(menu, data, t);
    menu.dataset.bmMenuV14861915 = '1';
  }

  ready(function(){
    var menus = Array.prototype.slice.call(document.querySelectorAll('.sidebar-menu'));
    if(!menus.length) return;

    // Paint immediately using the user state already emitted by PHP.
    var initial = inlineUserData(menus[0]);
    menus.forEach(function(menu){ renderMenu(menu, initial); });
    var initialLang = getLanguage(initial);
    installDesktopPremium(initial, STRINGS[initialLang] || STRINGS.fa);

    // Refresh silently for cached pages without blocking menu interaction.
    fetch('/mobile_menu_user_api.php', {credentials:'same-origin', cache:'no-store', headers:{'Accept':'application/json'}})
      .then(function(res){ return res.ok ? res.json() : Promise.reject(new Error('api')); })
      .then(function(data){
        if(!data) return;
        menus.forEach(function(menu){ renderMenu(menu, data); });
        var lang = getLanguage(data);
        installDesktopPremium(data, STRINGS[lang] || STRINGS.fa);
      })
      .catch(function(){});
  });
})();
