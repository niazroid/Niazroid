(function(){
  'use strict';

  function restore(){
    var header = document.getElementById('siteHeader');
    if(!header) return;

    header.classList.remove(
      'bm-mobile-floating-glass-v148612',
      'bm-mobile-header-hidden',
      'bm-mobile-header-compact'
    );

    [
      '--bm-mobile-header-width',
      '--bm-mobile-header-height',
      '--bm-mobile-header-radius',
      '--bm-mobile-header-gap',
      '--bm-mobile-header-bg',
      '--bm-mobile-header-border',
      '--bm-mobile-header-shadow',
      '--bm-mobile-header-blur'
    ].forEach(function(name){ header.style.removeProperty(name); });
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', restore, {once:true});
  }else{
    restore();
  }

  window.addEventListener('pageshow', restore, {passive:true});
})();
