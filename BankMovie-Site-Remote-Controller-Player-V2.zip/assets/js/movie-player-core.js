// =================== پلیر ===================
const bmArchiveSubFa = (window.BM_MOVIE_CONFIG && window.BM_MOVIE_CONFIG.archiveSubFa) || 'سافت ساب';
const bmArchiveSubEn = (window.BM_MOVIE_CONFIG && window.BM_MOVIE_CONFIG.archiveSubEn) || 'Soft Sub';
if(isMovie && (hasDub || hasSoft)) { 
    setTimeout(() => { 
        video = document.getElementById('videoPlayer'); 
        if(!video) return; 
        wrapper = document.getElementById('playerWrapper'); 
        controls = document.getElementById('playerControls'); 
        settingsDropdown = document.getElementById('settingsDropdown'); if(wrapper && settingsDropdown && settingsDropdown.parentElement !== wrapper) wrapper.appendChild(settingsDropdown); 
        
        let playPauseBtn = document.getElementById('playPauseBtn'), progressBar = document.getElementById('progressBar'), currentTimeDisplay = document.getElementById('currentTimeDisplay'), durationDisplay = document.getElementById('durationDisplay'), seekBack10Btn = document.getElementById('seekBack10Btn'), seekForward10Btn = document.getElementById('seekForward10Btn'), volumeBtn = document.getElementById('volumeBtn'), volumeSlider = document.getElementById('volumeSlider'), fullscreenBtn = document.getElementById('fullscreenBtn'), downloadCurrentBtn = document.getElementById('downloadCurrentBtn'), screenLockBtn = document.getElementById('screenLockBtn'), settingsBtn = document.getElementById('settingsBtn'), bufferingIndicator = document.getElementById('bufferingIndicator'), uploadSubtitleOption = document.getElementById('uploadSubtitleOption'), subtitleUpload = document.getElementById('subtitleUpload'), removeSubtitleOption = document.getElementById('removeSubtitleOption'), qualityModalList = document.getElementById('qualityModalList'), currentSpeedLabel = document.getElementById('currentSpeedLabel'), currentSleepTimerLabel = document.getElementById('currentSleepTimerLabel'), currentPictureModeLabel = document.getElementById('currentPictureModeLabel'), currentTheatreModeLabel = document.getElementById('currentTheatreModeLabel'), currentBrightnessLabel = document.getElementById('currentBrightnessLabel'), currentSubtitleLabel = document.getElementById('currentSubtitleLabel'), openQualityPanel = document.getElementById('openQualityPanel'), openSpeedPanel = document.getElementById('openSpeedPanel'), openPictureModePanel = document.getElementById('openPictureModePanel'), openTheatrePanel = document.getElementById('openTheatrePanel'), openBrightnessPanel = document.getElementById('openBrightnessPanel'), openSubtitlePanel = document.getElementById('openSubtitlePanel'), openSleepTimerPanel = document.getElementById('openSleepTimerPanel');
        
        let isMuted = false, lastVolume = 100;
        if(volumeSlider) { video.volume = 1; volumeSlider.value = 100; }
        
        function handleFullscreenChange() { 
            if(document.fullscreenElement || document.webkitFullscreenElement) { document.body.classList.add('fullscreen-active'); screen.orientation?.lock('landscape').catch(()=>{}); } 
            else { document.body.classList.remove('fullscreen-active'); screen.orientation?.lock('portrait').catch(()=>{}); } 
        }
        document.addEventListener('fullscreenchange', handleFullscreenChange); 
        document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
        
        let sleepTimerId = null, sleepTimerTickId = null, sleepTimerEndsAt = null;
        function openSettingsPanel(panelName) {
            if(!settingsDropdown) return;
            settingsDropdown.querySelectorAll('[data-settings-panel]').forEach(panel => panel.classList.toggle('active', panel.dataset.settingsPanel === panelName));
        }
        function positionSettingsDropdown() {
            if(!settingsDropdown || !settingsBtn) return;
            var innerEl = document.getElementById('arc1PlayerInner') || wrapper;
            const wrapperRect = innerEl.getBoundingClientRect();
            const btnRect = settingsBtn.getBoundingClientRect();
            const panelWidth = Math.max(240, Math.min(340, wrapperRect.width - 20));
            const panelHeight = Math.min(460, Math.max(220, wrapperRect.height - 24));
            let leftPos = (btnRect.left - wrapperRect.left) + (btnRect.width / 2) - (panelWidth / 2);
            leftPos = Math.max(10, Math.min(leftPos, wrapperRect.width - panelWidth - 10));
            let topPos = (btnRect.top - wrapperRect.top) - panelHeight - 10;
            if(topPos < 10) topPos = 10;
            settingsDropdown.style.position = 'absolute';
            settingsDropdown.style.width = panelWidth + 'px';
            settingsDropdown.style.maxHeight = panelHeight + 'px';
            settingsDropdown.style.top = topPos + 'px';
            settingsDropdown.style.left = leftPos + 'px';
            settingsDropdown.style.right = 'auto';
            settingsDropdown.style.bottom = 'auto';
            settingsDropdown.style.zIndex = '9999';
        }

        function closeSettingsDropdown() {
            if(settingsDropdown) settingsDropdown.classList.remove('active');
            openSettingsPanel('main');
        }
        function setPlaybackSpeed(speed, silent=false) {
            const normalized = Number(speed);
            if(!Number.isFinite(normalized) || normalized <= 0) return;
            currentPlaybackRate = normalized;
            video.playbackRate = normalized;
            const speedText = `${Math.round(normalized*100)/100}x`;
            if(currentSpeedLabel) currentSpeedLabel.textContent = speedText;
            document.getElementById('speedRange') && (document.getElementById('speedRange').value = String(normalized));
            document.getElementById('speedTouchValue') && (document.getElementById('speedTouchValue').textContent = speedText);
            document.querySelectorAll('.speed-opt').forEach(opt => opt.classList.toggle('active', parseFloat(opt.dataset.speed) === normalized));
            if(!silent) showToast(`${userLang === 'fa' ? 'سرعت' : 'Speed'}: ${speedText}`);
        }
        function getPictureModeLabel(mode) {
            const labels = {
                normal: userLang === 'fa' ? 'عادی' : 'Normal',
                cover: userLang === 'fa' ? 'بزرگ' : 'Zoom',
                stretch: userLang === 'fa' ? '16:9' : '16:9',
                small: userLang === 'fa' ? 'کوچک‌تر' : 'Smaller'
            };
            return labels[mode] || labels.normal;
        }
        function setPictureMode(mode) {
            const allowed = ['normal', 'cover', 'stretch', 'small'];
            const selected = allowed.includes(mode) ? mode : 'normal';
            currentPictureMode = selected;
            wrapper.classList.remove('view-mode-normal', 'view-mode-cover', 'view-mode-stretch', 'view-mode-small');
            wrapper.classList.add('view-mode-' + selected);
            if(currentPictureModeLabel) currentPictureModeLabel.textContent = getPictureModeLabel(selected);
            document.querySelectorAll('.picture-mode-opt').forEach(opt => opt.classList.toggle('active', opt.dataset.pictureMode === selected));
            showToast(`${userLang === 'fa' ? 'حالت تصویر' : 'Picture mode'}: ${getPictureModeLabel(selected)}`);
        }

        function getTheatreModeLabel(){ return theatreModeEnabled ? (userLang === 'fa' ? 'روشن' : 'On') : (userLang === 'fa' ? 'خاموش' : 'Off'); }
        function setTheatreMode(enabled, silent=false){
            theatreModeEnabled = (enabled === true || enabled === 'on' || enabled === '1');
            document.body.classList.remove('bm-theatre-active');
            if(wrapper) wrapper.classList.toggle('bm-theatre-active', theatreModeEnabled);
            if(currentTheatreModeLabel) currentTheatreModeLabel.textContent = getTheatreModeLabel();
            document.querySelectorAll('.theatre-opt').forEach(opt => opt.classList.toggle('active', (opt.dataset.theatre === 'on') === theatreModeEnabled));
            try { localStorage.removeItem('bm_theatre_mode'); } catch(e) {}
            if(!silent) {
                showToast(theatreModeEnabled ? (userLang === 'fa' ? 'حالت سینمایی روشن شد' : 'Theatre mode on') : (userLang === 'fa' ? 'حالت سینمایی خاموش شد' : 'Theatre mode off'));
                showPlayerHud(userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode', getTheatreModeLabel(), theatreModeEnabled ? 1 : 0, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/></svg>');
            }
            if(theatreModeEnabled && wrapper) wrapper.scrollIntoView({behavior:'smooth', block:'center'});
        }

        function updateSleepTimerLabel() {
            if(!currentSleepTimerLabel) return;
            if(!sleepTimerEndsAt) {
                currentSleepTimerLabel.textContent = userLang === 'fa' ? 'خاموش' : 'Off';
                return;
            }
            const remaining = Math.max(0, Math.ceil((sleepTimerEndsAt - Date.now()) / 60000));
            currentSleepTimerLabel.textContent = remaining + ' ' + (userLang === 'fa' ? 'دقیقه' : 'min');
        }
        function clearSleepTimer(silent = false) {
            if(sleepTimerId) clearTimeout(sleepTimerId);
            if(sleepTimerTickId) clearInterval(sleepTimerTickId);
            sleepTimerId = null;
            sleepTimerTickId = null;
            sleepTimerEndsAt = null;
            updateSleepTimerLabel();
            document.querySelectorAll('.sleep-opt').forEach(opt => opt.classList.toggle('active', opt.dataset.sleepMinutes === '0'));
            if(!silent) showToast(userLang === 'fa' ? 'زمان‌سنج خواب خاموش شد' : 'Sleep timer turned off');
        }
        function setSleepTimer(minutes) {
            const mins = parseInt(minutes, 10);
            if(!Number.isFinite(mins) || mins <= 0) {
                clearSleepTimer();
                return;
            }
            if(sleepTimerId) clearTimeout(sleepTimerId);
            if(sleepTimerTickId) clearInterval(sleepTimerTickId);
            sleepTimerEndsAt = Date.now() + mins * 60000;
            sleepTimerId = setTimeout(() => {
                video.pause();
                if(document.fullscreenElement) document.exitFullscreen?.();
                clearSleepTimer(true);
                showToast(userLang === 'fa' ? 'زمان‌سنج خواب تمام شد؛ پخش متوقف شد' : 'Sleep timer finished; playback paused');
            }, mins * 60000);
            sleepTimerTickId = setInterval(updateSleepTimerLabel, 30000);
            updateSleepTimerLabel();
            var _sd=document.getElementById('arc1SleepTimerSettingsList')||document.getElementById('arc1SettingsDropdown');if(_sd) _sd.querySelectorAll('.sleep-opt').forEach(opt => opt.classList.toggle('active', parseInt(opt.dataset.sleepMinutes, 10) === mins));
            showToast(`${userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer'}: ${mins} ${userLang === 'fa' ? 'دقیقه' : 'minutes'}`);
        }


    function escapeSubtitleHtml(text){return String(text||'').replace(/[&<>]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[ch]));}
    function parseSubTime(t){
        const raw=String(t||'').trim().replace(',', '.');
        const m=raw.match(/(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?/);
        if(!m)return 0;
        const h=parseInt(m[1]||'0',10),mi=parseInt(m[2]||'0',10),sec=parseInt(m[3]||'0',10),ms=parseInt((m[4]||'0').padEnd(3,'0').slice(0,3),10);
        return h*3600+mi*60+sec+ms/1000;
    }
    function cleanSubText(text){
        return String(text||'')
            .replace(/^\d+\s*$/gm,'')
            .replace(/\{\\[^}]+\}/g,'')
            .replace(/<\/?(font|b|i|u|c|ruby|rt|v)[^>]*>/gi,'')
            .replace(/<[^>]+>/g,'')
            .replace(/\\N/g,'\n')
            .replace(/\r/g,'')
            .split('\n')
            .map(x=>x.trim())
            .filter(Boolean)
            .join('\n')
            .trim();
    }
    function srtToVtt(srt){
        let text=String(srt||'').replace(/^\uFEFF/,'').replace(/\u0000/g,'').replace(/\r\n?/g,'\n');
        text=text.replace(/(\d{1,2}:\d{2}:\d{2}),(\d{1,3})/g,'$1.$2');
        if(!/^WEBVTT/i.test(text.trim())) text='WEBVTT\n\n'+text;
        return text;
    }
    function parseVttOrSrt(content){
        const cues=[];
        let text=String(content||'').replace(/^\uFEFF/,'').replace(/\u0000/g,'').replace(/\r\n?/g,'\n');
        text=text.replace(/^WEBVTT[^\n]*(?:\n|$)/i,'');
        text=text.replace(/\nSTYLE[\s\S]*?(?=\n\s*\n|$)/gi,'\n');
        text=text.replace(/\nREGION[\s\S]*?(?=\n\s*\n|$)/gi,'\n');
        if(!text.trim()) return cues;
        const blocks=text.split(/\n{2,}/);
        for(const block of blocks){
            const lines=block.split('\n').map(l=>l.trimEnd()).filter(l=>l.trim()!=='' );
            if(!lines.length) continue;
            if(/^(WEBVTT|NOTE|STYLE|REGION)\b/i.test(lines[0].trim())) continue;
            const timingIndex=lines.findIndex(l=>/\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}/.test(l));
            if(timingIndex<0) continue;
            const timing=lines[timingIndex].trim();
            const parts=timing.split(/\s*-->\s*/);
            const start=parseSubTime(parts[0]);
            const end=parseSubTime((parts[1]||'').trim().split(/\s+/)[0]);
            const body=cleanSubText(lines.slice(timingIndex+1).join('\n'));
            if(end>start && body) cues.push({start,end,text:body});
        }
        if(cues.length) return cues.sort((a,b)=>a.start-b.start);
        // fallback for malformed SRT files without blank lines
        const lines=text.split('\n');
        for(let i=0;i<lines.length;i++){
            if(!lines[i].includes('-->')) continue;
            const parts=lines[i].trim().split(/\s*-->\s*/);
            const start=parseSubTime(parts[0]);
            const end=parseSubTime((parts[1]||'').trim().split(/\s+/)[0]);
            const body=[];
            for(let j=i+1;j<lines.length;j++){
                const next=lines[j];
                if(next.includes('-->')) break;
                if(next.trim()==='' && body.length) break;
                if(!/^\d+$/.test(next.trim())) body.push(next);
            }
            const cueText=cleanSubText(body.join('\n'));
            if(end>start && cueText) cues.push({start,end,text:cueText});
        }
        return cues.sort((a,b)=>a.start-b.start);
    }
    function parseAss(content){const cues=[];let format=[];for(const raw of String(content||'').replace(/^\uFEFF/,'').split(/\r?\n/)){const line=raw.trim();if(/^Format:/i.test(line))format=line.replace(/^Format:/i,'').split(',').map(x=>x.trim().toLowerCase());else if(/^Dialogue:/i.test(line)){const body=line.replace(/^Dialogue:/i,'');const parts=body.split(/,(?=(?:[^{}]*\{[^}]*\})*[^{}]*$)/);const startIdx=format.indexOf('start'),endIdx=format.indexOf('end'),textIdx=format.indexOf('text');if(startIdx>=0&&endIdx>=0&&textIdx>=0&&parts.length>textIdx){const start=parseSubTime(parts[startIdx]);const end=parseSubTime(parts[endIdx]);const text=cleanSubText(parts.slice(textIdx).join(','));if(end>start&&text)cues.push({start,end,text});}}}return cues.sort((a,b)=>a.start-b.start);}
    function parseSubtitleFile(file, content){
        const name=file?.name||'';
        if(/\.(ass|ssa)$/i.test(name)) return parseAss(content);
        let cues=parseVttOrSrt(content);
        if(!cues.length) cues=parseVttOrSrt(srtToVtt(content));
        activeSubtitleCueIndex=-1;
        lastSubtitleHtml='';
        return cues;
    }
    async function readSubtitleText(file){
        const buffer=await file.arrayBuffer();
        const bytes=new Uint8Array(buffer);
        const decode=(enc, fatal=false)=>new TextDecoder(enc,{fatal}).decode(buffer).replace(/^\uFEFF/,'');
        const hasTiming=text=>/\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}/.test(String(text||''));
        const looksMojibake=text=>/(?:Ø|Ù|Û|Ã|Â|â€|â€™|ï»¿)/.test(String(text||''));
        const scoreText=text=>{
            const s=String(text||'');
            return (s.match(/-->/g)||[]).length*80+
                   (s.match(/[\u0600-\u06FF]/g)||[]).length*3+
                   (s.match(/[A-Za-z0-9]/g)||[]).length*.05-
                   (s.match(/�/g)||[]).length*120-
                   (looksMojibake(s)?220:0)-
                   (s.match(/\u0000/g)||[]).length*80;
        };
        try{
            if(bytes[0]===0xFF&&bytes[1]===0xFE) return decode('utf-16le');
            if(bytes[0]===0xFE&&bytes[1]===0xFF) return decode('utf-16be');
            if(bytes[0]===0xEF&&bytes[1]===0xBB&&bytes[2]===0xBF) return decode('utf-8', true);
        }catch(e){}
        // مهم: اگر فایل UTF-8 معتبر باشد، همان را برمی‌گردانیم. نسخه قبل به‌خاطر امتیازدهی، گاهی UTF-8 فارسی را اشتباهی windows-1256 می‌خواند و متن به هم می‌ریخت.
        try{
            const utf8=decode('utf-8', true);
            if(hasTiming(utf8) && !looksMojibake(utf8)) return utf8;
        }catch(e){}
        const candidates=[];
        ['windows-1256','utf-8','windows-1252','iso-8859-1'].forEach(enc=>{try{candidates.push([enc,decode(enc,false)]);}catch(e){}});
        try{candidates.push(['file.text',await file.text()]);}catch(e){}
        let best='',bestScore=-1e9;
        for(const [enc,text] of candidates){
            const sc=scoreText(text)+(enc==='windows-1256'?25:0);
            if(sc>bestScore){bestScore=sc;best=text;}
        }
        return String(best||'').replace(/^\uFEFF/,'');
    }
    function updateSubtitleUI(){const loaded=subtitleCues.length>0;const delayText=(subtitleDelay>0?'+':'')+subtitleDelay.toFixed(1)+'s';document.getElementById('subtitleDelayLabel')&&(document.getElementById('subtitleDelayLabel').textContent=delayText);document.getElementById('subtitleDelayRange')&&(document.getElementById('subtitleDelayRange').value=subtitleDelay.toFixed(1));if(currentSubtitleLabel)currentSubtitleLabel.textContent=loaded?(subtitlesEnabled?(currentSubtitleName||'On'):(userLang==='fa'?'خاموش':'Off')):(userLang==='fa'?'خاموش':'Off');document.getElementById('subtitleToggleValue')&&(document.getElementById('subtitleToggleValue').textContent=subtitlesEnabled?(userLang==='fa'?'روشن':'On'):(userLang==='fa'?'خاموش':'Off'));document.getElementById('subtitleVisibilityLabel')&&(document.getElementById('subtitleVisibilityLabel').textContent=subtitlesEnabled?(userLang==='fa'?'روشن':'On'):(userLang==='fa'?'خاموش':'Off'));document.getElementById('toggleSubtitleOption')&&(document.getElementById('toggleSubtitleOption').style.display=loaded?'flex':'none');document.getElementById('removeSubtitleOption')&&(document.getElementById('removeSubtitleOption').style.display=loaded?'flex':'none');document.querySelectorAll('.subtitle-color-btn').forEach(btn=>btn.classList.toggle('active',(btn.dataset.subtitleColor||'').toLowerCase()===subtitleColor.toLowerCase()));}
    function renderCustomSubtitle(){
        const box=document.getElementById('subtitleOverlay');
        if(!box||!video)return;
        box.style.setProperty('--subtitle-color', subtitleColor);
        if(!subtitlesEnabled||!subtitleCues.length){
            if(lastSubtitleHtml!==''){box.innerHTML='';lastSubtitleHtml='';}
            return;
        }
        const t=video.currentTime-subtitleDelay;
        let cue=null;
        if(activeSubtitleCueIndex>=0){
            const current=subtitleCues[activeSubtitleCueIndex];
            if(current && t>=current.start && t<=current.end) cue=current;
        }
        if(!cue){
            activeSubtitleCueIndex=-1;
            for(let i=0;i<subtitleCues.length;i++){
                const c=subtitleCues[i];
                if(t>=c.start && t<=c.end){cue=c;activeSubtitleCueIndex=i;break;}
                if(c.start>t) break;
            }
        }
        const html=cue?'<span>'+escapeSubtitleHtml(cue.text)+'</span>':'';
        if(html!==lastSubtitleHtml){box.innerHTML=html;lastSubtitleHtml=html;}
    }
    function clearCustomSubtitle(silent=false){subtitleCues=[];currentSubtitleName='';subtitleDelay=0;subtitlesEnabled=true;activeSubtitleCueIndex=-1;lastSubtitleHtml='';const box=document.getElementById('subtitleOverlay');if(box)box.innerHTML='';updateSubtitleUI();if(!silent)showToast(userLang==='fa'?'زیرنویس حذف شد':'Subtitle removed');}
    function setSubtitleDelay(value, silent=false){subtitleDelay=Math.max(-5,Math.min(5,Math.round(Number(value||0)*10)/10));updateSubtitleUI();renderCustomSubtitle();if(!silent)showToast(`${userLang==='fa'?'تاخیر زیرنویس':'Subtitle delay'}: ${(subtitleDelay>0?'+':'')+subtitleDelay.toFixed(1)}s`);}
    function setSubtitleColor(color, silent=false){subtitleColor=String(color||'#ffffff');const box=document.getElementById('subtitleOverlay');if(box)box.style.setProperty('--subtitle-color',subtitleColor);updateSubtitleUI();renderCustomSubtitle();try{localStorage.setItem('bm_subtitle_color',subtitleColor);}catch(e){}if(!silent)showToast(userLang==='fa'?'رنگ زیرنویس تغییر کرد':'Subtitle color changed');}

    function updateSubtitlePositionUI(){
        const label=document.getElementById('subtitlePositionLabel');
        const range=document.getElementById('subtitlePositionRange');
        const value=(subtitleVerticalOffset>0?'+':'')+subtitleVerticalOffset+'px';
        if(label) label.textContent=value;
        if(range) range.value=String(subtitleVerticalOffset);
        const box=document.getElementById('subtitleOverlay');
        if(box) box.style.setProperty('--subtitle-offset-y', subtitleVerticalOffset+'px');
    }
    function setSubtitleVerticalOffset(value, silent=false){
        const n=Math.max(-80,Math.min(80,Math.round(Number(value||0)/4)*4));
        subtitleVerticalOffset=Number.isFinite(n)?n:0;
        updateSubtitlePositionUI();
        try{localStorage.setItem('bm_subtitle_vertical_offset',String(subtitleVerticalOffset));}catch(e){}
        if(!silent) showToast(`${userLang==='fa'?'جای زیرنویس':'Subtitle position'}: ${(subtitleVerticalOffset>0?'+':'')+subtitleVerticalOffset}px`);
    }

    function setBrightness(value, silent=false){currentBrightness=Math.max(.4,Math.min(1.6,Number(value)||1));if(wrapper)wrapper.style.setProperty('--player-brightness',currentBrightness.toFixed(2));const pct=Math.round(currentBrightness*100)+'%';if(currentBrightnessLabel)currentBrightnessLabel.textContent=pct;document.getElementById('brightnessPercentLabel')&&(document.getElementById('brightnessPercentLabel').textContent=pct);document.getElementById('brightnessRange')&&(document.getElementById('brightnessRange').value=Math.round(currentBrightness*100));document.querySelectorAll('.brightness-preset').forEach(btn=>btn.classList.toggle('active',Math.abs(Number(btn.dataset.brightness)-currentBrightness)<.03));if(!silent){showPlayerHud(userLang==='fa'?'روشنایی':'Brightness',pct,(currentBrightness-.4)/1.2,brightnessHudSvg());showControlsTemporarily();}}
    function setupTouchGestures(){
        let start=null,lastTap=0,lastSide='',singleTapTimer=null;
        const setGestureClass=(side)=>{wrapper.classList.toggle('gesture-active-left',side==='left');wrapper.classList.toggle('gesture-active-right',side==='right');};
        const clearGestureClass=()=>{wrapper.classList.remove('gesture-active-left','gesture-active-right');};
        wrapper.addEventListener('touchstart',e=>{
            if(isUILocked||e.target.closest('.player-controls')||e.target.closest('.unlock-overlay')||!video.src)return;
            const t=e.touches[0],r=wrapper.getBoundingClientRect();
            start={x:t.clientX,y:t.clientY,time:Date.now(),brightness:currentBrightness,volume:Number(volumeSlider?.value||100),mode:null,moved:false,side:t.clientX<r.left+r.width/2?'left':'right',rect:r};
        },{passive:true});
        wrapper.addEventListener('touchmove',e=>{
            if(!start||isUILocked)return;
            const t=e.touches[0],dx=t.clientX-start.x,dy=t.clientY-start.y;
            if(!start.mode&&Math.abs(dy)>18&&Math.abs(dy)>Math.abs(dx))start.mode=start.side==='left'?'brightness':'volume';
            if(start.mode==='brightness'){
                e.preventDefault();start.moved=true;setGestureClass('left');
                setBrightness(start.brightness+((start.y-t.clientY)/start.rect.height)*1.4,false);
            }else if(start.mode==='volume'){
                e.preventDefault();start.moved=true;setGestureClass('right');
                const next=Math.max(0,Math.min(100,Math.round(start.volume+((start.y-t.clientY)/start.rect.height)*130)));
                if(volumeSlider)volumeSlider.value=next;
                video.volume=next/100;lastVolume=next;isMuted=next===0;
                showPlayerHud(userLang==='fa'?'صدا':'Volume',next+'%',next/100,volumeHudSvg(next));
                showControlsTemporarily();
            }
        }, {passive:false});
        wrapper.addEventListener('touchend',e=>{
            if(!start||isUILocked){start=null;clearGestureClass();return;}
            const now=Date.now();
            if(start.moved){start=null;clearGestureClass();return;}
            if(now-lastTap<320&&lastSide===start.side){
                e.preventDefault();clearTimeout(singleTapTimer);window.__bmSuppressNextClick=true;setTimeout(()=>window.__bmSuppressNextClick=false,380);
                start.side==='left'?seekBack10Btn.click():seekForward10Btn.click();lastTap=0;lastSide='';
            }else{
                lastTap=now;lastSide=start.side;window.__bmSuppressNextClick=true;setTimeout(()=>window.__bmSuppressNextClick=false,360);
                clearTimeout(singleTapTimer);singleTapTimer=setTimeout(()=>{showControlsTemporarily();},330);
            }
            start=null;clearGestureClass();
        },{passive:false});
    }

    document.querySelectorAll('[data-settings-back]').forEach(btn => btn.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('main'); }));
        openQualityPanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('quality'); });
        openSpeedPanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('speed'); });
        openPictureModePanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('picture'); });
        openTheatrePanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('theatre'); });
        openBrightnessPanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('brightness'); });
        openSubtitlePanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('subtitle'); });
        openSleepTimerPanel?.addEventListener('click', (e) => { e.stopPropagation(); openSettingsPanel('sleep'); });
        
        if(qualityModalList) { 
            let qHtml = '';
            if(hasDub) Object.keys(dubLinksData).forEach(q => qHtml += `<button type="button" class="settings-choice quality-opt" data-type="dub" data-quality="${escapeAttr(q)}"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">${escapeHtml(q)}</span><span class="settings-choice-desc">${userLang === 'fa' ? 'دوبله فارسی' : 'Persian dubbed'}</span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>`); 
            if(hasSoft) Object.keys(softLinksData).forEach(q => qHtml += `<button type="button" class="settings-choice quality-opt" data-type="soft" data-quality="${escapeAttr(q)}"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">${escapeHtml(q)}</span><span class="settings-choice-desc">${userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn}</span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>`); 
            qualityModalList.innerHTML = qHtml || `<div class="empty-state">${userLang === 'fa' ? 'کیفیتی برای پخش پیدا نشد' : 'No playback quality found'}</div>`; 
            document.querySelectorAll('.quality-opt').forEach(opt => opt.addEventListener('click', (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } setQuality(opt.dataset.type, opt.dataset.quality); })); 
        }
        

        function getQualityRank(q){q=String(q||'').toLowerCase();if(q.includes('2160')||q.includes('4k'))return 6;if(q.includes('1080'))return 5;if(q.includes('720'))return 4;if(q.includes('480'))return 3;if(q.includes('360'))return 2;return 1;}
        function getTypeQualities(type){const data=type==='dub'?dubLinksData:softLinksData;return Object.keys(data||{}).filter(q=>data[q]&&data[q][0]&&isSafeUrl(data[q][0].url)).sort((a,b)=>getQualityRank(b)-getQualityRank(a));}
        function getAutoType(){return currentType || (hasDub ? 'dub' : 'soft');}
        function chooseAutoQuality(){return null;}
        function setAutoQuality(){autoQualityMode=false;}
        function autoDowngradeQuality(){}
        function autoUpgradeQuality(){}

        function setDefaultQuality() {
            const preferredType = hasSoft ? 'soft' : (hasDub ? 'dub' : null);
            if(!preferredType) return;
            const qualities = getTypeQualities(preferredType);
            const quality = qualities[0];
            if(!quality) return;
            currentType = preferredType;
            currentQuality = quality;
            const item = preferredType === 'dub' ? dubLinksData[quality]?.[0] : softLinksData[quality]?.[0];
            if(item?.url && isSafeUrl(item.url)) {
                video.src = item.url;
                video.load();
                if(item?.subtitle_url) bmLoadSubtitleUrl(item.subtitle_url);
            }
            document.querySelectorAll('.quality-btn, .quality-opt').forEach(btn => {
                btn.classList.toggle('active', btn.dataset.type === preferredType && btn.dataset.quality === quality);
            });
            const qualityLabel = document.getElementById('currentQualityLabel');
            if(qualityLabel) qualityLabel.textContent = `${quality} ${preferredType === 'dub' ? (userLang === 'fa' ? 'دوبله' : 'Dubbed') : (userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn)}`;
            updateDownloadList?.();
        }
        
        video.addEventListener('loadedmetadata', () => { 
            if(durationDisplay && video.duration && isFinite(video.duration)) { durationDisplay.textContent = formatTime(video.duration); progressBar.max = 100; } 
            let saved = localStorage.getItem('bankmovie_continue'); 
            if(saved) { try { let data = JSON.parse(saved); if(data[imdbCode]?.currentTime && isFinite(data[imdbCode].currentTime)) video.currentTime = data[imdbCode].currentTime; } catch(e){} } 
            // v30: source can be prepared silently; do not autoplay on page load.
        });
        video.addEventListener('timeupdate', () => { if(video.duration && isFinite(video.duration) && video.currentTime) { let p = (video.currentTime / video.duration) * 100; if(isFinite(p)) { progressBar.value = p; currentTimeDisplay.textContent = formatTime(video.currentTime); } } renderCustomSubtitle(); });
        video.addEventListener('waiting', () => { bufferingIndicator.style.display = 'block'; }); 
        video.addEventListener('canplay', () => bufferingIndicator.style.display = 'none'); 
        video.addEventListener('play', () => playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>'); 
        video.addEventListener('pause', () => playPauseBtn.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>'); 
        video.addEventListener('error', () => showToast(userLang === 'fa' ? 'خطا در پخش ویدیو' : 'Video error'));
        
        playPauseBtn.onclick = () => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } if(video.paused) { video.play(); } else { video.pause(); } };
        progressBar.oninput = (e) => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } if(video.duration && isFinite(video.duration)) video.currentTime = (e.target.value / 100) * video.duration; };
        seekBack10Btn.onclick = () => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } video.currentTime = Math.max(0, video.currentTime - 10); showPlayerHud(userLang === 'fa' ? 'عقب' : 'Back', '-10s', null, seekHudSvg('back')); };
        seekForward10Btn.onclick = () => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } video.currentTime = Math.min(video.duration, video.currentTime + 10); showPlayerHud(userLang === 'fa' ? 'جلو' : 'Forward', '+10s', null, seekHudSvg('forward')); };
        volumeSlider.oninput = (e) => { let v = e.target.value / 100; video.volume = v; lastVolume = e.target.value; isMuted = (v === 0); showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', Math.round(v  * 100) + '%', v, volumeHudSvg(Math.round(v  * 100))); };
        volumeBtn.onclick = () => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } if(isMuted) { video.volume = lastVolume / 100; volumeSlider.value = lastVolume; isMuted = false; showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', Math.round(video.volume  * 100) + '%', video.volume, volumeHudSvg(Math.round(video.volume  * 100))); } else { lastVolume = volumeSlider.value; video.volume = 0; volumeSlider.value = 0; isMuted = true; showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', '0%', 0, volumeHudSvg(0)); } };
        fullscreenBtn.onclick = () => { if(!document.fullscreenElement) wrapper.requestFullscreen?.(); else document.exitFullscreen?.(); };
        
        downloadCurrentBtn.onclick = () => {
            showToast(userLang === 'fa' ? 'دانلود از باکس دانلود پایین صفحه انجام می‌شود' : 'Use the download box below the player');
        };
        
        function toggleUILock() { isUILocked = !isUILocked; if(isUILocked) { wrapper.classList.add('ui-locked'); screenLockBtn.classList.remove('unlocked'); screenLockBtn.classList.add('locked'); showToast(userLang === 'fa' ? 'کنترل ها قفل شد' : 'Controls locked'); showPlayerHud(userLang === 'fa' ? 'قفل صفحه' : 'Screen lock', userLang === 'fa' ? 'فعال' : 'On', 1, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>'); } else { wrapper.classList.remove('ui-locked'); screenLockBtn.classList.remove('locked'); screenLockBtn.classList.add('unlocked'); showToast(userLang === 'fa' ? 'کنترل ها باز شد' : 'Controls unlocked'); showPlayerHud(userLang === 'fa' ? 'قفل صفحه' : 'Screen lock', userLang === 'fa' ? 'باز' : 'Off', 0, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.2-2.4"/><path d="M19 5L5 19"/></svg>'); } }
        async function requestWakeLock() { if('wakeLock' in navigator) { try { wakeLock = await navigator.wakeLock.request('screen'); toggleUILock(); wakeLock.addEventListener('release', () => { if(isUILocked) toggleUILock(); }); } catch(err) { toggleUILock(); } } else toggleUILock(); }
        async function releaseWakeLock() { if(wakeLock) { await wakeLock.release(); wakeLock = null; if(isUILocked) toggleUILock(); } else if(isUILocked) toggleUILock(); }
        screenLockBtn.onclick = () => isUILocked ? releaseWakeLock() : requestWakeLock();
        document.getElementById('unlockOverlayBtn')?.addEventListener('click', (e) => { e.stopPropagation(); if(isUILocked) releaseWakeLock(); });
        
        function showControlsTemporarily() { controls.style.opacity = '1'; clearTimeout(controlsTimeout); controlsTimeout = setTimeout(() => { controls.style.opacity = '0'; }, 4000); }
        wrapper.addEventListener('click', showControlsTemporarily); wrapper.addEventListener('mousemove', showControlsTemporarily); wrapper.addEventListener('touchstart', showControlsTemporarily, {passive:true});
        
        settingsBtn.onclick = (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } if(!settingsDropdown.classList.contains('active')) { openSettingsPanel('main'); positionSettingsDropdown(); settingsDropdown.classList.add('active'); } else closeSettingsDropdown(); };
        settingsDropdown?.addEventListener('pointerdown', e => e.stopPropagation()); settingsDropdown?.addEventListener('click', e => e.stopPropagation()); settingsDropdown?.addEventListener('touchstart', e => e.stopPropagation(), {passive:true});
        window.addEventListener('resize', () => { if(settingsDropdown?.classList.contains('active')) positionSettingsDropdown(); });
        document.addEventListener('click', (e) => { if(settingsDropdown && !settingsDropdown.contains(e.target) && !settingsBtn.contains(e.target)) closeSettingsDropdown(); });
        
        uploadSubtitleOption.onclick = () => { if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } subtitleUpload.click(); };
        subtitleUpload.onchange = async (e) => { let file = e.target.files[0]; if(file && /\.(srt|vtt|ssa|ass)$/i.test(file.name)) { try { const content = await readSubtitleText(file); subtitleCues = parseSubtitleFile(file, content); activeSubtitleCueIndex = -1; lastSubtitleHtml = ''; if(!subtitleCues.length) { showToast(userLang === 'fa' ? 'زیرنویس قابل خواندن نبود' : 'Subtitle could not be parsed'); return; } currentSubtitleName = file.name; subtitlesEnabled = true; setSubtitleDelay(0, true); updateSubtitleUI(); renderCustomSubtitle(); showToast(`${userLang === 'fa' ? 'زیرنویس' : 'Subtitle'} ${file.name} ${userLang === 'fa' ? 'بارگذاری شد' : 'loaded'}`); openSettingsPanel('subtitle'); e.target.value = ''; } catch(err) { showToast(userLang === 'fa' ? 'خطا در خواندن زیرنویس' : 'Subtitle read error'); } } else showToast(userLang === 'fa' ? 'فرمت پشتیبانی نمی شود' : 'Format not supported'); };
        removeSubtitleOption.onclick = () => { clearCustomSubtitle(); };
        document.getElementById('toggleSubtitleOption')?.addEventListener('click', () => { subtitlesEnabled = !subtitlesEnabled; updateSubtitleUI(); renderCustomSubtitle(); showToast(subtitlesEnabled ? (userLang === 'fa' ? 'زیرنویس روشن شد' : 'Subtitles on') : (userLang === 'fa' ? 'زیرنویس خاموش شد' : 'Subtitles off')); });
        document.getElementById('subtitleEarlierBtn')?.addEventListener('click', () => setSubtitleDelay(subtitleDelay - .1));
        document.getElementById('subtitleLaterBtn')?.addEventListener('click', () => setSubtitleDelay(subtitleDelay + .1));
        document.getElementById('subtitleResetDelayBtn')?.addEventListener('click', () => setSubtitleDelay(0));
        document.getElementById('subtitleDelayRange')?.addEventListener('input', e => setSubtitleDelay(e.target.value, true));
        document.getElementById('subtitleDelayRange')?.addEventListener('change', e => setSubtitleDelay(e.target.value));

    document.querySelectorAll('.subtitle-color-btn[data-subtitle-color]').forEach(btn=>btn.addEventListener('click',e=>{e.stopPropagation();setSubtitleColor(btn.dataset.subtitleColor);}));

    try{setSubtitleVerticalOffset(parseInt(localStorage.getItem('bm_subtitle_vertical_offset')||'0',10), true);}catch(e){setSubtitleVerticalOffset(0,true);}
    document.getElementById('subtitlePositionRange')?.addEventListener('input',e=>setSubtitleVerticalOffset(e.target.value,true));
    document.getElementById('subtitlePositionRange')?.addEventListener('change',e=>setSubtitleVerticalOffset(e.target.value));
    document.getElementById('subtitlePositionUpBtn')?.addEventListener('click',()=>setSubtitleVerticalOffset(subtitleVerticalOffset-8));
    document.getElementById('subtitlePositionDownBtn')?.addEventListener('click',()=>setSubtitleVerticalOffset(subtitleVerticalOffset+8));
    document.getElementById('subtitlePositionResetBtn')?.addEventListener('click',()=>setSubtitleVerticalOffset(0));

    try{setSubtitleColor(localStorage.getItem('bm_subtitle_color')||'#ffffff',true);}catch(e){setSubtitleColor('#ffffff',true);}
    const speedRange=document.getElementById('speedRange'),speedTouchPad=document.getElementById('speedTouchPad'),speedTouchValue=document.getElementById('speedTouchValue');
    function updateSpeedTouchUI(){const v=Number(currentPlaybackRate||video?.playbackRate||1);if(speedRange)speedRange.value=String(v);if(speedTouchValue)speedTouchValue.textContent=(Math.round(v*100)/100)+'x';}
    if(speedRange){speedRange.addEventListener('input',e=>setPlaybackSpeed(e.target.value,true));speedRange.addEventListener('change',e=>setPlaybackSpeed(e.target.value));}
    if(speedTouchPad){let spStart=null;speedTouchPad.addEventListener('pointerdown',e=>{spStart={y:e.clientY,speed:Number(currentPlaybackRate||video?.playbackRate||1)};speedTouchPad.setPointerCapture?.(e.pointerId);e.preventDefault();});speedTouchPad.addEventListener('pointermove',e=>{if(!spStart)return;const diff=(spStart.y-e.clientY)/160;const next=Math.max(.25,Math.min(2,Math.round((spStart.speed+diff)*20)/20));setPlaybackSpeed(next,true);showPlayerHud(userLang==='fa'?'سرعت':'Speed',(Math.round(next*100)/100)+'x',(next-.25)/1.75,speedHudSvg());});speedTouchPad.addEventListener('pointerup',()=>{if(spStart){setPlaybackSpeed(currentPlaybackRate);spStart=null;}});speedTouchPad.addEventListener('pointercancel',()=>{spStart=null;});}

        document.getElementById('brightnessRange')?.addEventListener('input', e => setBrightness(Number(e.target.value) / 100, false));
        document.querySelectorAll('.brightness-preset[data-brightness]').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation(); setBrightness(btn.dataset.brightness); }));
        setupTouchGestures();
        document.querySelectorAll('.speed-opt[data-speed]').forEach(btn => { btn.onclick = (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } setPlaybackSpeed(btn.dataset.speed); }; });
        document.querySelectorAll('.sleep-opt[data-sleep-minutes]').forEach(btn => { btn.onclick = (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } setSleepTimer(btn.dataset.sleepMinutes); }; });
    document.querySelectorAll('.theatre-opt[data-theatre]').forEach(btn => { btn.onclick = (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } setTheatreMode(btn.dataset.theatre); }; });
        document.querySelectorAll('.picture-mode-opt[data-picture-mode]').forEach(btn => { btn.onclick = (e) => { e.stopPropagation(); if(isUILocked) { showToast(userLang === 'fa' ? 'کنترل ها قفل است' : 'Controls locked'); return; } setPictureMode(btn.dataset.pictureMode); }; });
        if(wrapper) wrapper.classList.add('view-mode-normal');
        try { localStorage.removeItem('bm_theatre_mode'); } catch(e) {}
        document.body.classList.remove('bm-theatre-active');
        if(wrapper) wrapper.classList.remove('bm-theatre-active');
        setTheatreMode(false, true);
        setDefaultQuality();
        document.addEventListener('keydown', (e) => { if(isUILocked || document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return; switch(e.key) { case ' ': case 'Space': e.preventDefault(); showControlsTemporarily(); playPauseBtn.click(); break; case 'ArrowLeft': e.preventDefault(); showControlsTemporarily(); seekBack10Btn.click(); break; case 'ArrowRight': e.preventDefault(); showControlsTemporarily(); seekForward10Btn.click(); break; case 'ArrowUp': e.preventDefault(); showControlsTemporarily(); volumeSlider.value = Math.min(100, parseInt(volumeSlider.value) + 10); volumeSlider.dispatchEvent(new Event('input')); break; case 'ArrowDown': e.preventDefault(); showControlsTemporarily(); volumeSlider.value = Math.max(0, parseInt(volumeSlider.value) - 10); volumeSlider.dispatchEvent(new Event('input')); break; case 'f': case 'F': e.preventDefault(); fullscreenBtn.click(); break; case 'm': case 'M': e.preventDefault(); volumeBtn.click(); break; case 'z': case 'Z': e.preventDefault(); setSubtitleDelay(subtitleDelay - .1); break; case 'x': case 'X': e.preventDefault(); setSubtitleDelay(subtitleDelay + .1); break; } });
    }, 100); 
}
