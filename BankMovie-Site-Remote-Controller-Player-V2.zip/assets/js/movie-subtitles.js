// =================== دانلود و پلیر (مشابه نسخه پایدار قدیم ولی با قفل صفحه و ...) ===================
function bmSubtitleFetchUrls(url){
    url = String(url || '').trim();
    if(!url) return [];
    const list = [];
    // اول خود لینک مستقیم زیرنویس را امتحان می‌کنیم؛ اگر CORS/دسترسی مشکل داشت، پروکسی داخلی fallback می‌شود.
    list.push(url);
    const isInternalProxy=/^\/?api(?:4|6)\.php\?subtitle_url=/i.test(url);
    if(!isInternalProxy){
        list.push('/api6.php?subtitle_url=' + encodeURIComponent(url));
        list.push('/api4.php?subtitle_url=' + encodeURIComponent(url));
    }
    return [...new Set(list.filter(Boolean))];
}
async function bmLoadSubtitleUrl(subtitleUrl, nameHint){
    subtitleUrl = String(subtitleUrl || '').trim();
    if(!subtitleUrl) return false;
    let lastErr = null;
    for(const candidateUrl of bmSubtitleFetchUrls(subtitleUrl)){
        try{
            const opts = /^\/api(?:4|6)\.php\?subtitle_url=/i.test(candidateUrl) ? {credentials:'same-origin'} : {credentials:'omit'};
            const res = await fetch(candidateUrl, opts);
            if(!res.ok) throw new Error('HTTP '+res.status);
            const content = await res.text();
            const fileName = String(nameHint || subtitleUrl.split('/').pop().split('?')[0] || 'subtitle.srt');
            const fakeFile = {name:fileName};
            subtitleCues = parseSubtitleFile(fakeFile, content);
            activeSubtitleCueIndex = -1;
            lastSubtitleHtml = '';
            if(!subtitleCues.length) throw new Error('Subtitle parse failed');
            currentSubtitleName = userLang === 'fa' ? 'زیرنویس خودکار' : 'Auto subtitle';
            subtitlesEnabled = true;
            setSubtitleDelay(0, true);
            updateSubtitleUI();
            renderCustomSubtitle();
            showToast(userLang === 'fa' ? 'زیرنویس خودکار بارگذاری شد' : 'Subtitle loaded automatically');
            return true;
        }catch(err){
            lastErr = err;
            console.warn('Auto subtitle load failed for', candidateUrl, err);
        }
    }
    showToast(userLang === 'fa' ? 'زیرنویس خودکار باز نشد؛ دکمه دانلود مستقیم زیرنویس کنار لینک‌هاست' : 'Auto subtitle failed; direct subtitle download is available beside links');
    return false;
}
function bmFindSubtitleForVideoUrl(url, qualityHint, typeHint){
    url = String(url || '').trim();
    qualityHint = String(qualityHint || currentQuality || '').trim();
    typeHint = String(typeHint || currentType || '').trim();
    const groups = [dubLinksData, softLinksData];
    for(const group of groups){
        for(const q of Object.keys(group || {})){
            const arr = group[q] || [];
            for(const item of arr){
                if(item && item.url === url && item.subtitle_url) return item.subtitle_url;
            }
        }
    }
    // اگر کاربر نسخه دوبله را انتخاب کرده ولی زیرنویس جدا ندارد، نزدیک‌ترین نسخه زیرنویس‌دار همان کیفیت را پیدا کن.
    // برای آرشیو ۱ اکثر مواقع زیرنویس به شکل نسخه soft/hardsub جداست، نه فایل SRT جدا.
    const softSame = qualityHint && softLinksData && softLinksData[qualityHint] ? softLinksData[qualityHint] : [];
    for(const item of softSame){ if(item && item.subtitle_url) return item.subtitle_url; }
    for(const q of Object.keys(softLinksData || {})){
        const arr = softLinksData[q] || [];
        for(const item of arr){ if(item && item.subtitle_url) return item.subtitle_url; }
    }
    return '';
}
function bmFindSoftVideoForQuality(qualityHint){
    qualityHint = String(qualityHint || currentQuality || '').trim();
    if(qualityHint && softLinksData && softLinksData[qualityHint] && softLinksData[qualityHint][0]?.url) return softLinksData[qualityHint][0].url;
    const qs = Object.keys(softLinksData || {}).sort((a,b)=>getQualityRank(b)-getQualityRank(a));
    for(const q of qs){ if(softLinksData[q] && softLinksData[q][0]?.url) return softLinksData[q][0].url; }
    return '';
}
window.bmPlayerLoadSubtitleUrl = bmLoadSubtitleUrl;
if(window.BM_PENDING_SUBTITLE_URL){
    bmLoadSubtitleUrl(window.BM_PENDING_SUBTITLE_URL);
    window.BM_PENDING_SUBTITLE_URL = '';
}
function updateDownloadList() { 
    let container = document.getElementById('downloadList'); 
    if(!container || !isMovie) return; 
    let items = []; 
    if(currentType === 'dub' && dubLinksData[currentQuality]) items = dubLinksData[currentQuality]; 
    else if(currentType === 'soft' && softLinksData[currentQuality]) items = softLinksData[currentQuality]; 
    if(items.length === 0) { 
        container.innerHTML = `<div class="empty-state">${userLang === 'fa' ? 'کیفیت مورد نظر را انتخاب کنید' : 'Select a quality'}</div>`; 
        return; 
    } 
    // Archive 2 download/play links are free; do not force login here.
    const dubMicIcon = `<svg class="dub-mic-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 14a3 3 0 0 0 3-3V5a3 3 0 0 0-6 0v6a3 3 0 0 0 3 3z"/><path d="M19 11a7 7 0 0 1-14 0"/><path d="M12 18v4"/><path d="M8 22h8"/></svg>`;
    container.innerHTML = items.filter(item => isSafeUrl(item.url)).map((item, index) => {
        const subUrl = item.subtitle_url || bmFindSubtitleForVideoUrl(item.url, currentQuality, currentType) || '';
        const softVideoUrl = currentType === 'dub' ? bmFindSoftVideoForQuality(currentQuality) : '';
        const subtitlePlayBtn = (currentType === 'dub' && softVideoUrl) ? `<button type="button" class="bm-local-play-choice" data-url="${escapeAttr(softVideoUrl)}" data-subtitle-url="${escapeAttr(subUrl)}" data-label="${escapeAttr(currentQuality + ' · ' + (userLang === 'fa' ? ('نسخه ' + bmArchiveSubFa) : (bmArchiveSubEn + ' version')))}"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg>${userLang === 'fa' ? ('پخش ' + bmArchiveSubFa) : ('Play ' + bmArchiveSubEn)}</button>` : '';
        return `<div class="download-link premium-download-card" style="cursor:default"><div class="download-card-left"><span class="download-type-badge ${currentType === 'dub' ? 'is-dub' : 'is-soft'}">${currentType === 'dub' ? dubMicIcon : ''}${currentType === 'dub' ? (userLang === 'fa' ? 'دوبله' : 'Dubbed') : (userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn)}</span><div class="link-info"><span class="quality">${escapeHtml(currentQuality)}</span><span class="size">${userLang === 'fa' ? 'حجم:' : 'Size:'} ${escapeHtml(item.size || (userLang==='fa'?'نامشخص':'Unknown'))}</span></div></div><div style="display:flex;gap:7px;flex-shrink:0;align-items:center;flex-wrap:wrap"><button type="button" class="bm-local-play-choice" data-url="${escapeAttr(item.url)}" data-subtitle-url="${escapeAttr(subUrl)}" data-label="${escapeAttr(currentQuality + ' · ' + (currentType === 'dub' ? (userLang === 'fa' ? 'دوبله' : 'Dubbed') : (userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn)))}"><svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg>${userLang === 'fa' ? 'پخش' : 'Play'}</button>${subtitlePlayBtn}<a href="${escapeAttr(item.url)}" class="download-icon" download data-bm-download-only="1" rel="noopener noreferrer" style="text-decoration:none">${userLang === 'fa' ? 'دانلود' : 'Download'}</a>${subUrl ? `<a href="${escapeAttr(subUrl)}" class="download-icon arc4-subtitle-direct" download data-bm-download-only="1" rel="noopener noreferrer" style="text-decoration:none;background:linear-gradient(135deg,#7c3aed,#a855f7);border-color:rgba(216,180,254,.45)">${userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn}</a>` : ''}</div></div>`;
    }).join('') || `<div class="empty-state">${userLang === 'fa' ? 'لینک معتبر پیدا نشد' : 'No valid link found'}</div>`; 
}

function setQuality(type, quality, opts = {}) { 
    if(isSettingQuality) return; 
    isSettingQuality = true; 
    currentType = type; 
    currentQuality = quality; 
    autoQualityMode = false; 
    const qualityLabel = document.getElementById('currentQualityLabel');
    if(qualityLabel) qualityLabel.textContent = `${quality} · ${type === 'dub' ? (userLang === 'fa' ? 'دوبله' : 'Dubbed') : (userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn)}`;
    document.querySelectorAll('.quality-opt').forEach(opt => opt.classList.toggle('active', opt.dataset.type === type && opt.dataset.quality === quality));
    document.querySelectorAll('.quality-btn').forEach(btn => { 
        if(btn.dataset.type === type && btn.dataset.quality === quality) btn.classList.add('active'); 
        else btn.classList.remove('active'); 
    }); 
    updateDownloadList(); 
    showToast(`${userLang === 'fa' ? 'کیفیت' : 'Quality'} ${quality} ${type === 'dub' ? (userLang === 'fa' ? 'دوبله فارسی' : 'Persian Dubbed') : (userLang === 'fa' ? bmArchiveSubFa : bmArchiveSubEn)} ${userLang === 'fa' ? 'انتخاب شد' : 'selected'}`); 
    if(isMovie && video) { 
        if(typeof wrapper !== 'undefined' && wrapper) wrapper.style.display = 'block';
        let url = (type === 'dub' && dubLinksData[quality]) ? dubLinksData[quality][0]?.url : (type === 'soft' && softLinksData[quality]) ? softLinksData[quality][0]?.url : null;
        if(url && video.src !== url) { 
            let wasPlaying = !video.paused, oldTime = video.currentTime; 
            video.src = url; 
            video.load(); 
            const chosenItem = (type === 'dub' && dubLinksData[quality]) ? dubLinksData[quality][0] : (type === 'soft' && softLinksData[quality]) ? softLinksData[quality][0] : null;
            const subUrl = chosenItem?.subtitle_url || bmFindSubtitleForVideoUrl(chosenItem?.url || url, quality, type);
            if(subUrl) bmLoadSubtitleUrl(subUrl);
            video.addEventListener('loadedmetadata', () => { 
                if(wasPlaying && oldTime < video.duration && isFinite(oldTime)) video.currentTime = oldTime; 
                if(wasPlaying) video.play().catch(e=>console.log); 
                isSettingQuality = false; 
            }, { once: true }); 
            video.addEventListener('error', () => { showToast(userLang === 'fa' ? 'خطا در پخش' : 'Playback error'); isSettingQuality = false; }, { once: true });
        } else { isSettingQuality = false; } 
    } else { isSettingQuality = false; } 
}
