(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  ready(function(){
    var header = document.getElementById('siteHeader');
    if(!header) return;

    var hero = document.querySelector('.hero-slider');
    var mq = window.matchMedia ? window.matchMedia('(max-width: 991.98px)') : {matches: window.innerWidth < 992};
    var rafId = 0;

    function getTransparentLimit(){
      var headerHeight = Math.max(1, header.offsetHeight || 0);

      // Homepage and any future public page using the same hero component:
      // keep the header flat until its lower edge leaves the hero.
      if(hero && hero.offsetHeight > 0){
        return Math.max(24, (hero.offsetTop || 0) + hero.offsetHeight - headerHeight - 18);
      }

      // Pages without a hero still receive the same transparent header at the top.
      // The regular background returns shortly after scrolling begins.
      return Math.max(44, Math.round(headerHeight * 0.72));
    }

    function applyState(){
      rafId = 0;
      if(!mq.matches){
        header.classList.remove('is-mobile-surface-transparent');
        return;
      }

      var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      header.classList.toggle('is-mobile-surface-transparent', scrollY <= getTransparentLimit());
    }

    function requestApply(){
      if(rafId) return;
      rafId = window.requestAnimationFrame(applyState);
    }

    applyState();
    window.addEventListener('scroll', requestApply, {passive:true});
    window.addEventListener('resize', requestApply, {passive:true});
    window.addEventListener('orientationchange', requestApply, {passive:true});
    window.addEventListener('load', requestApply, {once:true});
    window.addEventListener('pageshow', requestApply, {passive:true});
    if(mq.addEventListener) mq.addEventListener('change', requestApply);
    else if(mq.addListener) mq.addListener(requestApply);
  });
})();
