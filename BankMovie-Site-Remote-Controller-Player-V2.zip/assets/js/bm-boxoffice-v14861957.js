(() => {
  'use strict';
  const root = document.getElementById('bmBoxOffice');
  if (!root) return;
  const lang = window.BM_BOXOFFICE_LANG === 'en' ? 'en' : 'fa';
  const api = root.dataset.api || '/api_boxoffice.php';
  const isAdmin = root.dataset.admin === '1';
  const podium = document.getElementById('bmBoPodium');
  const list = document.getElementById('bmBoList');
  const refreshBtn = document.getElementById('bmBoRefresh');
  const alertBox = document.getElementById('bmBoAlert');
  const heroRank = document.getElementById('bmBoHeroRank');
  const heroTitle = document.getElementById('bmBoHeroTitle');
  const heroGross = document.getElementById('bmBoHeroGross');
  const heroPoster = document.getElementById('bmBoHeroPoster');
  const updatedAt = document.getElementById('bmBoUpdatedAt');
  const count = document.getElementById('bmBoCount');
  const total = document.getElementById('bmBoTotal');
  let loading = false;

  const esc = (v) => String(v ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const safeUrl = (v) => {
    const s = String(v || '').trim();
    if (!s) return '';
    if (s.startsWith('/') && !s.startsWith('//')) return s;
    try { const u = new URL(s, location.origin); return u.protocol === 'https:' ? u.href : ''; } catch (_) { return ''; }
  };
  const money = (n) => {
    n = Number(n || 0);
    if (!Number.isFinite(n) || n <= 0) return '—';
    try { return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',notation:'compact',maximumFractionDigits:1}).format(n); }
    catch (_) { return '$' + Math.round(n).toLocaleString('en-US'); }
  };
  const clock = (iso) => {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return '—';
      return new Intl.DateTimeFormat(lang === 'fa' ? 'fa-IR' : 'en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(d);
    } catch (_) { return '—'; }
  };
  const cleanUpdate = (payload) => String(payload?.source_updated_text || '').trim() || clock(payload?.updated_at);
  const poster = (item) => safeUrl(item?.local_poster || item?.image) || '/assets/brand/bankmovie-icon-256.webp';
  const titleParts = (item) => {
    const fa = String(item?.title_fa || '').trim();
    const en = String(item?.title || '').trim();
    return {primary: fa || en || '—', original: fa && en && fa !== en ? en : ''};
  };
  const titleNode = (item, cls) => {
    const t = titleParts(item);
    const url = safeUrl(item?.local_url || '');
    return url ? `<a class="${cls}" href="${esc(url)}">${esc(t.primary)}</a>` : `<strong class="${cls}">${esc(t.primary)}</strong>`;
  };
  const setLoading = (value) => {
    loading = value;
    root.classList.toggle('is-loading', value);
    refreshBtn?.classList.toggle('is-loading', value);
    if (refreshBtn) refreshBtn.disabled = value;
  };

  function renderHero(items, payload) {
    const leader = items[0] || {};
    const t = titleParts(leader);
    if (heroRank) heroRank.textContent = String(leader.rank || 1);
    if (heroTitle) heroTitle.textContent = t.primary;
    if (heroGross) heroGross.textContent = leader.weekend || money(leader.weekend_value);
    if (heroPoster) {
      heroPoster.src = poster(leader);
      heroPoster.alt = t.primary;
      heroPoster.onerror = () => { heroPoster.onerror = null; heroPoster.src = '/assets/brand/bankmovie-icon-256.webp'; };
    }
    if (updatedAt) updatedAt.textContent = cleanUpdate(payload);
    if (count) count.textContent = String(payload?.stats?.count || items.length || 0);
    if (total) total.textContent = money(payload?.stats?.weekend_total_value);
  }

  function renderPodium(items) {
    if (!podium) return;
    const top = (items || []).slice(0,3);
    if (!top.length) {
      podium.innerHTML = `<div class="bm-bo-empty"><strong>${lang==='fa'?'فعلاً داده‌ای برای نمایش نیست':'No box office data yet'}</strong><span>${lang==='fa'?'کمی بعد دوباره امتحان کن.':'Please try again shortly.'}</span></div>`;
      return;
    }
    podium.innerHTML = top.map((item, idx) => {
      const t = titleParts(item);
      const local = safeUrl(item.local_url || '');
      return `<article class="bm-bo-podium-card rank-${idx+1}">
        <div class="bm-bo-podium-poster"><img src="${esc(poster(item))}" alt="${esc(t.primary)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/brand/bankmovie-icon-256.webp'"><span class="bm-bo-rank-badge">${esc(item.rank || idx+1)}</span></div>
        <div class="bm-bo-podium-copy">
          <div class="bm-bo-podium-heading">${titleNode(item,'bm-bo-podium-title')}${t.original?`<span>${esc(t.original)}</span>`:''}</div>
          <div class="bm-bo-podium-money"><div><small>${lang==='fa'?'آخر هفته':'Weekend'}</small><strong>${esc(item.weekend || money(item.weekend_value))}</strong></div><div><small>${lang==='fa'?'فروش کل':'Total'}</small><strong>${esc(item.gross || money(item.gross_value))}</strong></div></div>
          <div class="bm-bo-podium-foot"><span>${lang==='fa'?'هفته اکران':'Week'} ${esc(item.weeks || '—')}</span>${local?`<a href="${esc(local)}">${lang==='fa'?'مشاهده فیلم':'Open'} <b>←</b></a>`:''}</div>
        </div>
      </article>`;
    }).join('');
  }

  function renderList(items) {
    if (!list) return;
    if (!items?.length) {
      list.innerHTML = `<div class="bm-bo-empty"><strong>${lang==='fa'?'باکس آفیس در دسترس نیست':'Box office is unavailable'}</strong><span>${lang==='fa'?'بعداً دوباره امتحان کن.':'Please try again later.'}</span></div>`;
      return;
    }
    list.innerHTML = items.map(item => {
      const t = titleParts(item);
      const local = safeUrl(item.local_url || '');
      const weekend = item.weekend || money(item.weekend_value);
      const gross = item.gross || money(item.gross_value);
      return `<article class="bm-bo-row">
        <div class="bm-bo-row-rank"><span>#</span><strong>${esc(item.rank || '—')}</strong></div>
        <div class="bm-bo-row-poster"><img src="${esc(poster(item))}" alt="${esc(t.primary)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/brand/bankmovie-icon-256.webp'"></div>
        <div class="bm-bo-row-copy">${titleNode(item,'bm-bo-row-title')}${t.original?`<span class="bm-bo-original">${esc(t.original)}</span>`:''}<div class="bm-bo-row-tags">${item.id?`<span>${esc(item.id)}</span>`:''}${item.local_match?`<span class="is-local">BANKMOVIE</span>`:''}</div></div>
        <div class="bm-bo-metric primary"><small>${lang==='fa'?'فروش آخر هفته':'Weekend'}</small><strong>${esc(weekend)}</strong></div>
        <div class="bm-bo-metric"><small>${lang==='fa'?'فروش کل':'Total gross'}</small><strong>${esc(gross)}</strong></div>
        <div class="bm-bo-metric weeks"><small>${lang==='fa'?'هفته اکران':'Weeks'}</small><strong>${esc(item.weeks || '—')}</strong></div>
        ${local?`<a class="bm-bo-row-open" href="${esc(local)}" aria-label="${lang==='fa'?'مشاهده فیلم':'Open movie'}">←</a>`:''}
      </article>`;
    }).join('');
  }

  function showAlert(payload, failed=false) {
    if (!alertBox) return;
    const msg = String(payload?.message || '').trim();
    if (!msg && !payload?.stale) {
      alertBox.hidden = true;
      alertBox.textContent = '';
      alertBox.classList.remove('is-error');
      return;
    }
    alertBox.hidden = false;
    alertBox.classList.toggle('is-error', failed && !payload?.stale);
    alertBox.textContent = msg || (lang==='fa'?'آخرین داده معتبر نمایش داده می‌شود.':'Showing the latest valid data.');
  }

  async function load(force=false) {
    if (loading) return;
    setLoading(true);
    try {
      const qs = new URLSearchParams({mode:'weekend',_:String(Date.now())});
      if (force && isAdmin) qs.set('refresh','1');
      const res = await fetch(`${api}?${qs}`,{credentials:'same-origin',headers:{Accept:'application/json'},cache:'no-store'});
      let payload = {};
      try { payload = await res.json(); } catch (_) {}
      const items = Array.isArray(payload.items) ? payload.items : [];
      if (!res.ok && !items.length) throw Object.assign(new Error(payload.message || `HTTP ${res.status}`),{payload});
      renderHero(items,payload);
      renderPodium(items);
      renderList(items);
      showAlert(payload,!res.ok);
    } catch (err) {
      const payload = err?.payload || {message:lang==='fa'?'دریافت باکس آفیس موقتاً ممکن نیست.':'Box office is temporarily unavailable.',items:[]};
      renderHero([],payload);
      renderPodium([]);
      renderList([]);
      showAlert(payload,true);
    } finally { setLoading(false); }
  }

  refreshBtn?.addEventListener('click',()=>load(true));
  load(false);
  window.setInterval(()=>{ if (!document.hidden) load(false); },30*60*1000);
})();
