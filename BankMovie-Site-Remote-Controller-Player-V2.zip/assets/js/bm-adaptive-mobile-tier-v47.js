/* BankMovie V47 — conservative one-shot mobile capability tier.
   Low-end/mid mobile gets a stable dock. Dynamic floating nav is reserved for clearly capable hardware.
   No PerformanceObserver, MutationObserver, frame monitor or scroll listener is created here. */
(function(d,n){
  'use strict';
  try{
    var root=d.documentElement;
    var mm=function(q){return !!(window.matchMedia&&window.matchMedia(q).matches);};
    var mobile=mm('(max-width: 991px)');
    if(!mobile){
      root.classList.add('bm-nav-dynamic');
      root.dataset.bmNavTier='dynamic';
      return;
    }

    var conn=n.connection||n.mozConnection||n.webkitConnection||{};
    var mem=Number(n.deviceMemory||0);
    var cores=Number(n.hardwareConcurrency||0);
    var type=String(conn.effectiveType||'').toLowerCase();
    var ua=String(n.userAgent||'');
    var android=/Android/i.test(ua);
    var ios=/iPhone|iPad|iPod/i.test(ua) || (n.platform==='MacIntel' && Number(n.maxTouchPoints||0)>1);
    var reduced=mm('(prefers-reduced-motion: reduce)');
    var save=!!conn.saveData;
    var slowNet=/^(slow-2g|2g)$/.test(type);
    var existingLite=root.classList.contains('bm-mobile-lite') ||
                     root.classList.contains('bm-low-power') ||
                     root.classList.contains('bm-ultra-lite');

    function gpuRenderer(){
      if(!android) return '';
      var canvas,gl,ext,r='';
      try{
        canvas=d.createElement('canvas');
        canvas.width=1; canvas.height=1;
        gl=canvas.getContext('webgl',{antialias:false,depth:false,stencil:false,preserveDrawingBuffer:false}) ||
           canvas.getContext('experimental-webgl',{antialias:false,depth:false,stencil:false,preserveDrawingBuffer:false});
        if(!gl) return '';
        ext=gl.getExtension('WEBGL_debug_renderer_info');
        r=ext ? String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL)||'') : String(gl.getParameter(gl.RENDERER)||'');
        try{var lose=gl.getExtension('WEBGL_lose_context'); if(lose) lose.loseContext();}catch(_e){}
      }catch(e){}
      return r.toLowerCase();
    }

    var gpu=gpuRenderer();
    var weakGpu = /adreno\s*(?:3\d\d|4\d\d|5\d\d|610|612|613|615|616|618|619|620)\b|mali[- ]?(?:t\d+|g31|g51|g52|g57|g68)\b|powervr\s*(?:ge|rogue)/i.test(gpu);
    var strongGpu = /adreno\s*(?:630|640|642|643|650|660|7\d\d|8\d\d)\b|mali[- ]?g(?:76|77|78|710|715|720|725|925)\b|immortalis[- ]?g(?:715|720|925)\b|xclipse\s*(?:920|940)/i.test(gpu);

    var clearlyWeak = existingLite || reduced || save || slowNet ||
                      (mem>0 && mem<=6) || (cores>0 && cores<=4) || weakGpu ||
                      (android && (mem===0 || cores===0));

    // Important: memory/core count alone is not enough to enable the dynamic dock on Android.
    // A device must also expose a GPU we regard as comfortably capable, or have exceptional RAM headroom.
    var clearlyStrong = ios ? (cores>=6 && !reduced) :
                       android ? (!clearlyWeak && cores>=8 && ((mem>=8 && strongGpu) || mem>=12)) :
                       (!clearlyWeak && cores>=8 && mem>=8);

    var staticNav=!clearlyStrong;
    root.classList.toggle('bm-nav-static',staticNav);
    root.classList.toggle('bm-nav-dynamic',!staticNav);
    root.classList.toggle('bm-perf-lite',staticNav);
    root.dataset.bmNavTier=staticNav?'static':'dynamic';

    window.BM_ADAPTIVE_MOBILE_V47={
      mobile:true,
      nav:staticNav?'static':'dynamic',
      memory:mem,
      cores:cores,
      effectiveType:type,
      saveData:save,
      reducedMotion:reduced,
      gpu:gpu||'unknown',
      weakGpu:weakGpu,
      strongGpu:strongGpu
    };
  }catch(e){
    try{
      d.documentElement.classList.add('bm-nav-static','bm-perf-lite');
      d.documentElement.dataset.bmNavTier='static';
    }catch(_e){}
  }
})(document,navigator);
