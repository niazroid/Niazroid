/* BankMovie V46 — one-shot mobile capability tier.
   No benchmark loops, MutationObserver, PerformanceObserver or scroll handlers. */
(function(d,n){
  'use strict';
  try{
    var root=d.documentElement;
    var mm=function(q){return !!(window.matchMedia&&window.matchMedia(q).matches);};
    var mobile=mm('(max-width: 991px)');
    if(!mobile){root.classList.add('bm-nav-dynamic');return;}

    var conn=n.connection||n.mozConnection||n.webkitConnection||{};
    var mem=Number(n.deviceMemory||0);
    var cores=Number(n.hardwareConcurrency||0);
    var type=String(conn.effectiveType||'').toLowerCase();
    var ua=String(n.userAgent||'');
    var android=/Android/i.test(ua);
    var ios=/iPhone|iPad|iPod/i.test(ua) || (n.platform==='MacIntel' && Number(n.maxTouchPoints||0)>1);
    var reduced=mm('(prefers-reduced-motion: reduce)');
    var save=!!conn.saveData;
    var slowNet=/^(slow-2g|2g)$/.test(type);

    // Reuse the project's existing low-power decision when it is already known.
    var existingLite=root.classList.contains('bm-mobile-lite') ||
                     root.classList.contains('bm-low-power') ||
                     root.classList.contains('bm-ultra-lite');

    // Dynamic nav is reserved for devices that report clearly comfortable headroom.
    // Unknown Android hardware is intentionally conservative; iOS with >=6 logical
    // cores is treated as capable because deviceMemory is normally unavailable there.
    var clearlyStrong=(mem>=8 && cores>=6) || (mem>=6 && cores>=8) || (ios && cores>=6);
    var clearlyWeak=existingLite || reduced || save || slowNet ||
                    (mem>0 && mem<=4) || (cores>0 && cores<=4) ||
                    (mem>0 && mem<=6 && cores>0 && cores<=6) ||
                    (android && (mem===0 || cores===0));

    var staticNav=clearlyWeak || !clearlyStrong;
    root.classList.toggle('bm-nav-static',staticNav);
    root.classList.toggle('bm-nav-dynamic',!staticNav);
    root.dataset.bmNavTier=staticNav?'static':'dynamic';

    window.BM_ADAPTIVE_MOBILE_V46={
      mobile:true,
      nav:staticNav?'static':'dynamic',
      memory:mem,
      cores:cores,
      effectiveType:type,
      saveData:save,
      reducedMotion:reduced
    };
  }catch(e){
    // Fail safe: keep the site's original behavior if capability detection fails.
  }
})(document,navigator);
