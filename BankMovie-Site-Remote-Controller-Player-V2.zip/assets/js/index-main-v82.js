const BM_HOME_CONFIG = window.BM_HOME_CONFIG || {};
const storiesData = BM_HOME_CONFIG.storiesData || [];
const adminPicksData = BM_HOME_CONFIG.adminPicksData || [];
const newReleasesData = BM_HOME_CONFIG.newReleasesData || [];
const latestAnimationsData = BM_HOME_CONFIG.latestAnimationsData || [];
const topMoviesData = BM_HOME_CONFIG.topMoviesData || [];
const topSeriesData = BM_HOME_CONFIG.topSeriesData || [];
const dubbedMoviesData = BM_HOME_CONFIG.dubbedMoviesData || [];
const updatedMoviesData = BM_HOME_CONFIG.updatedMoviesData || [];
const userRatedData = BM_HOME_CONFIG.userRatedData || [];
const smartSuggestionsData = BM_HOME_CONFIG.smartSuggestionsData || [];

const API_URL = 'ajax.php';
const userLang = BM_HOME_CONFIG.userLang || 'fa';
const userId = BM_HOME_CONFIG.userId || '';
const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
const DEFAULT_POSTER = '/uploads/no.png';
const STORY_FALLBACK = String(BM_HOME_CONFIG.storyFallback || '').trim();
const STORY_IMAGE_FIT = ['cover','contain'].includes(BM_HOME_CONFIG.storyImageFit) ? BM_HOME_CONFIG.storyImageFit : 'cover';

let allMovies = [];
let currentPage = 1;
let totalPages = 1;
let isLoading = false;
let currentSearch = '';
let filterType = 'all';
let currentStoryIndex = 0;
let storyProgressInterval = null;
let storyHoldTimer = null;
let storyIsPaused = false;
let storyProgressMode = 'image';
let storyImageStartedAt = 0;
let storyImageElapsed = 0;
let searchAbortController = null;
let moviesAbortController = null;
let watchlistCache = null;
let watchlistStatusPromise = null;

// تشخیص دستگاه لمسی و اضافه کردن کلاس به body
if ('ontouchstart' in window || navigator.maxTouchPoints > 0) {
    document.body.classList.add('touch');
}

// Desktop poster reveal effect is enabled only on Windows devices with a real mouse.
if (/Windows/i.test(navigator.userAgent || '') && window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    document.documentElement.classList.add('bm-windows-card-hover');
}

// تابع تبدیل اعداد فارسی به انگلیسی در جاوااسکریپت
function enNumbers(str) {
    const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const englishDigits = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return String(str).replace(/[۰-۹]/g, function(d) {
        return englishDigits[persianDigits.indexOf(d)];
    });
}

function escapeHtml(str){
    return String(str ?? '').replace(/[&<>"']/g, m => ({
        '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#039;'
    }[m]));
}

function bmSlugifyTitle(value){
    return String(value||'movie').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-+/g,'-') || 'movie';
}
function bmMovieUrl(movie){
    movie = movie || {};
    if(movie.source_kind === 'api5' || movie.archive === 2 || movie.source_api === 'api5'){
        const id = movie.detail_id || movie.slug || movie.id || '';
        const type = movie.type === 'series' ? 'series' : 'movie';
        return id ? `/movie/arc2-${encodeURIComponent(id)}?type=${encodeURIComponent(type)}` : '/search?archive=local';
    }
    const slug = bmSlugifyTitle(movie.title || movie.title_en || movie.movie_title_en || movie.title_fa || 'movie');
    const id = movie.id || movie.movie_id || '';
    return `/movie/${slug}${id ? '-' + encodeURIComponent(id) : ''}`;
}

function bmNormalizeApi5Item(item){
    item = item || {};
    const imdb = item.imdb_code || item.imdb_id || '';
    return {...item,id:item.slug||item.id||'',detail_id:item.slug||item.id||'',title:item.title||'',title_fa:item.title_fa||item.title||'',imdb_code:imdb,imdb_rate:item.imdb_rate||item.rating||0,poster:item.poster||'',poster_proxy:item.poster_proxy||'',type:item.type==='series'?'series':'movie',source_archive:'local',source_kind:'api5',source_api:'api5',archive:2};
}
function bmApi5PosterError(img){
    const proxy=img?.dataset?.proxy||'';
    if(proxy){img.dataset.proxy='';img.src=proxy;return;}
    img.onerror=null;img.src=DEFAULT_POSTER;
}
function bmCardPosterMarkup(movie,className){
    const p=safeUrl(movie?.poster||'');
    const proxy=safeUrl(movie?.poster_proxy||'');
    if(p)return `<img class="${escapeHtml(className||'grid-poster')}" src="${escapeHtml(p)}" data-proxy="${escapeHtml(proxy)}" loading="lazy" decoding="async" onerror="bmApi5PosterError(this)">`;
    if(proxy)return `<img class="${escapeHtml(className||'grid-poster')}" src="${escapeHtml(proxy)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='${DEFAULT_POSTER}'">`;
    return `<img class="${escapeHtml(className||'grid-poster')}" src="${DEFAULT_POSTER}" loading="lazy" decoding="async">`;
}
function bmApi5QuickActions(movie){
    if(movie?.source_kind==='api5') return '';
    return quickActionsMarkup(movie.imdb_code,movie.title_fa||movie.title,movie.title,movie.year,movie.type,movie.genres);
}
function safeUrl(url){
    if(!url) return '';
    try{
        const parsed = new URL(String(url), window.location.origin);
        if(!['http:', 'https:'].includes(parsed.protocol)) return '';
        return parsed.href;
    }catch(e){ return ''; }
}

function bmStoryMediaUrl(value){
    const raw=String(value||'').trim();
    if(!raw) return '';
    try{
        const parsed=new URL(raw,window.location.origin);
        if(!['http:','https:'].includes(parsed.protocol)) return '';
        return parsed.href;
    }catch(e){return '';}
}

function bmStoryFallbackNode(isFull=false,caption=''){
    const node=document.createElement('div');
    node.className=isFull?'story-media story-media-fallback':'story-thumb-fallback';
    node.setAttribute('role','img');
    node.setAttribute('aria-label',caption|| (userLang==='fa'?'استوری بانک مووی':'BankMovie story'));
    node.innerHTML='<span aria-hidden="true">✦</span>';
    return node;
}

function bmStoryImageFallback(img){
    if(!img) return;
    if(STORY_FALLBACK && img.dataset.bmStoryFallback!=='1'){
        img.dataset.bmStoryFallback='1';
        img.src=STORY_FALLBACK;
        return;
    }
    const full=img.classList.contains('story-media');
    img.replaceWith(bmStoryFallbackNode(full,img.alt||''));
}
window.BMStoryImageFallback=bmStoryImageFallback;

function arc1DetailId(item){
    item = item || {};
    // detail_id از API جدید URL-safe است: 81402__slug یا series__slug
    return item.detail_id || item.external_id || item.source_key || item.slug || item.id || '';
}
function arc1MovieUrl(item){
    const id = arc1DetailId(item);
    return id ? `/movie/arc1-${encodeURIComponent(id)}` : (item && item.url ? item.url : '#');
}
function showToast(msg, duration = 3000){
    let c=document.getElementById('toastContainer');
    if(!c) return;
    let t=document.createElement('div');
    t.className='toast';
    t.textContent=String(msg ?? '');
    c.appendChild(t);
    setTimeout(()=>{t.style.animation='slideIn 0.3s ease reverse';setTimeout(()=>t.remove(),300);},duration);
}
function showLoading(){document.getElementById('loadingOverlay').classList.remove('hide');}
function hideLoading(){document.getElementById('loadingOverlay').classList.add('hide');}


function imdbLogoSvg(){
    return `<img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy">`;
}
function imdbBadge(rating){
    const value = enNumbers(rating || '0.0');
    return `<span class="imdb-card-badge">${imdbLogoSvg()}<b>${value}</b></span>`;
}
function imdbMeta(rating){
    const value = enNumbers(rating || '0.0');
    return `<span class="meta-imdb">${imdbLogoSvg()}<span>${value}</span></span>`;
}
function dubBadgeSvg(){
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 2a3.7 3.7 0 0 0-3.7 3.7v5.6a3.7 3.7 0 0 0 7.4 0V5.7A3.7 3.7 0 0 0 12 2Z"/><path d="M18.5 10.5a6.5 6.5 0 0 1-13 0"/><path d="M12 17v4"/><path d="M8.5 21h7"/></svg>`;
}
function subBadgeSvg(){
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="M10 10H8a2 2 0 0 0 0 4h2"/><path d="M16 10h-2a2 2 0 0 0 0 4h2"/></svg>`;
}
function mediaPosterBadges(opts){
    opts = opts || {};
    const hasDub = !!(opts.hasDub || opts.hasDubbed || opts.dubbed);
    const hasSub = !!(opts.hasSub || opts.hasSubtitle || opts.subtitle || opts.softsub);
    if(!hasDub && !hasSub) return '';
    let html = '<div class="bm-card-media-badges">';
    if(hasDub) html += `<span class="bm-card-media-badge is-dub" title="${userLang==='fa'?'دوبله فارسی':'Dubbed'}" aria-label="${userLang==='fa'?'دوبله فارسی':'Dubbed'}">${dubBadgeSvg()}</span>`;
    if(hasSub) html += `<span class="bm-card-media-badge is-sub" title="${userLang==='fa'?'زیرنویس':'Subtitle'}" aria-label="${userLang==='fa'?'زیرنویس':'Subtitle'}">${subBadgeSvg()}</span>`;
    html += '</div>';
    return html;
}
function posterImageMarkup(imdbCode, imgClass){
    const code = encodeURIComponent(imdbCode || '');
    return `<img class="${imgClass} bm-poster-img" src="/posters/${code}.webp" loading="lazy" decoding="async" width="240" height="360" onload="this.closest('.poster-wrap')?.classList.remove('is-loading');this.closest('.poster-wrap')?.classList.add('is-loaded');" onerror="this.src='${DEFAULT_POSTER}';this.onerror=null;">`;
}
const BM_HOVER_GENRE_FA = {
    'Action':'اکشن','Adventure':'ماجراجویی','Animation':'انیمیشن','Biography':'زندگی‌نامه',
    'Comedy':'کمدی','Crime':'جنایی','Documentary':'مستند','Drama':'درام','Family':'خانوادگی',
    'Fantasy':'فانتزی','History':'تاریخی','Horror':'ترسناک','Kids':'کودکان','Music':'موسیقی',
    'Mystery':'معمایی','Romance':'عاشقانه','Sci-Fi':'علمی تخیلی','Science Fiction':'علمی تخیلی',
    'Sport':'ورزشی','Thriller':'هیجان‌انگیز','War':'جنگی','Western':'وسترن','School':'مدرسه‌ای',
    'Supernatural':'ماورایی','Short':'کوتاه','Anime':'انیمه'
};
function bmHoverGenreText(value){
    const genres = String(value || '')
        .split(',')
        .map(item => item.trim())
        .filter(Boolean)
        .slice(0, 2);
    if(!genres.length) return '';
    return genres.map(item => userLang === 'fa' ? (BM_HOVER_GENRE_FA[item] || item) : item).join(' • ');
}
function bmApiGenresValue(item){
    item = item || {};
    let value = item.genres ?? item.genre ?? item.categories ?? item.category ?? '';
    if(Array.isArray(value)){
        value = value.map(entry => {
            if(entry && typeof entry === 'object') return entry.name || entry.title || entry.label || '';
            return entry;
        }).filter(Boolean).join(',');
    }else if(value && typeof value === 'object'){
        value = Object.values(value).map(entry => {
            if(entry && typeof entry === 'object') return entry.name || entry.title || entry.label || '';
            return entry;
        }).filter(Boolean).join(',');
    }
    return String(value || '').replace(/[|،؛]+/g, ',');
}
function bmApiEnglishTitle(item, displayedTitle=''){
    item = item || {};
    const candidates = [item.title_en, item.original_title, item.english_title, item.original_name, item.name_en];
    for(const candidate of candidates){
        const value = String(candidate || '').trim();
        if(value && value !== String(displayedTitle || '').trim()) return value;
    }
    return '';
}
function bmWindowsApiHoverMarkup(code, titleFa='', titleEn='', year='', type='', genres=''){
    if(!document.documentElement.classList.contains('bm-windows-card-hover')) return '';
    return quickActionsMarkup(code, titleFa, titleEn, year, type, genres);
}
function quickActionsMarkup(imdbCode, titleFa = '', titleEn = '', year = '', type = '', genres = ''){
    const safeCode = escapeHtml(imdbCode || '');
    const safeTitleFa = escapeHtml(titleFa || titleEn || '');
    const safeTitleEn = escapeHtml(titleEn || '');
    const safeYear = escapeHtml(year || '');
    const typeText = type === 'series' || type === 'tvSeries' || type === 'tvMiniSeries'
        ? (userLang === 'fa' ? 'سریال' : 'Series')
        : (type === 'movie' ? (userLang === 'fa' ? 'فیلم' : 'Movie') : '');
    const genreText = escapeHtml(bmHoverGenreText(genres));
    const fallbackMeta = [typeText, safeYear].filter(Boolean).join(' • ');
    const actionText = userLang === 'fa' ? 'تماشا کنید' : 'Watch now';
    return `<div class="card-quick-actions">
        <div class="bm-desktop-hover-content">
            <div class="bm-desktop-hover-copy">
                <strong class="bm-desktop-hover-title-fa">${safeTitleFa}</strong>
                ${safeTitleEn && safeTitleEn !== safeTitleFa ? `<span class="bm-desktop-hover-title-en">${safeTitleEn}${safeYear ? ` ${safeYear}` : ''}</span>` : ''}
                ${(genreText || fallbackMeta) ? `<span class="bm-desktop-hover-meta">${genreText || fallbackMeta}</span>` : ''}
            </div>
            <span class="quick-action quick-view" data-imdb="${safeCode}" title="${userLang==='fa'?'تماشای این عنوان':'Watch this title'}" aria-label="${userLang==='fa'?'تماشای این عنوان':'Watch this title'}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polygon points="8 5 19 12 8 19 8 5"/></svg><span class="bm-quick-view-label">${actionText}</span></span>
        </div>
    </div>`;
}

function renderGridSkeleton(count = 12){
    let html='';
    for(let i=0;i<count;i++){
        html += `<div class="movie-skeleton-card"><div class="movie-skeleton-poster"></div><div class="movie-skeleton-info"><div class="skeleton-line mid"></div><div class="skeleton-line short"></div><div class="skeleton-line tiny"></div></div></div>`;
    }
    return html;
}

// v22: batch DOM insertion on weak phones to avoid long frame stalls.
const BM_CARD_BATCH = (() => {
    const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    const small = window.matchMedia && window.matchMedia('(max-width: 768px)').matches;
    const weak = small && ((navigator.deviceMemory && navigator.deviceMemory <= 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (conn && conn.saveData));
    // v35: every mobile gets smaller DOM chunks; weak phones get even smaller chunks.
    const active = small || weak;
    return { weak: active, first: weak ? 5 : (small ? 8 : 9999), step: weak ? 3 : (small ? 5 : 9999) };
})();
function bmIdle(fn){
    if('requestIdleCallback' in window) return requestIdleCallback(fn, {timeout: 700});
    return setTimeout(fn, 70);
}
function bmMarkListRendered(container){
    if(!container || !container.classList) return;
    container.classList.remove('bm-list-loading');
    container.classList.remove('bm-list-rendered');
    try{ void container.offsetWidth; }catch(e){}
    container.classList.add('bm-list-rendered');
    clearTimeout(container.__bmListRenderedTimer);
    container.__bmListRenderedTimer = setTimeout(function(){
        try{ container.classList.remove('bm-list-rendered'); }catch(e){}
    }, 520);
}
function bmStartTypeSectionTransition(){
    try{
        var bar=document.querySelector('.filter-bar');
        var grid=document.getElementById('moviesGrid');
        if(bar) bar.classList.add('bm-type-switching');
        if(grid) grid.classList.add('bm-list-loading');
        clearTimeout(window.__bmTypeSwitchTimer);
        window.__bmTypeSwitchTimer=setTimeout(function(){
            if(bar) bar.classList.remove('bm-type-switching');
        }, 650);
    }catch(e){}
}
function bmEndTypeSectionTransition(){
    try{
        var bar=document.querySelector('.filter-bar');
        if(bar) bar.classList.remove('bm-type-switching');
    }catch(e){}
}
function bmSetCardsHTML(container, cards, afterBatch){
    if(!container) return;
    cards = Array.isArray(cards) ? cards : [];
    container.classList && container.classList.add('bm-list-loading');
    if(!cards.length){
        container.innerHTML='';
        if(afterBatch) afterBatch(container);
        bmMarkListRendered(container);
        return;
    }
    if(!BM_CARD_BATCH.weak || cards.length <= BM_CARD_BATCH.first){
        container.innerHTML = cards.join('');
        if(afterBatch) afterBatch(container);
        bmMarkListRendered(container);
        return;
    }
    let i = Math.min(BM_CARD_BATCH.first, cards.length);
    container.innerHTML = cards.slice(0, i).join('');
    if(afterBatch) afterBatch(container);
    bmMarkListRendered(container);
    function appendNext(){
        if(i >= cards.length) return;
        const end = Math.min(i + BM_CARD_BATCH.step, cards.length);
        container.insertAdjacentHTML('beforeend', cards.slice(i, end).join(''));
        i = end;
        if(afterBatch) afterBatch(container);
        if(i < cards.length) bmIdle(appendNext);
    }
    bmIdle(appendNext);
}

function setWatchlistActive(imdbCode, active){
    if(watchlistCache){
        if(active) watchlistCache.add(String(imdbCode || ''));
        else watchlistCache.delete(String(imdbCode || ''));
    }
    document.querySelectorAll('.watchlist-icon-grid').forEach(el=>{
        if(String(el.dataset.imdb || '') === String(imdbCode || '')){
            el.classList.toggle('active', !!active);
            const svg = el.querySelector('svg');
            if(svg) svg.setAttribute('fill', active ? 'currentColor' : 'none');
        }
    });
}
function applyWatchlistStatus(set){
    if(!set) return;
    document.querySelectorAll('.watchlist-icon-grid').forEach(icon=>{
        const imdb=String(icon.dataset.imdb || '');
        const active=set.has(imdb);
        icon.classList.toggle('active', active);
        const svg=icon.querySelector('svg');
        if(svg) svg.setAttribute('fill', active ? 'currentColor' : 'none');
    });
}
function setupCardInteractions(root=document){
    root.querySelectorAll('.quick-view').forEach(btn => {
        btn.removeEventListener('click', btn._clickHandler);
        btn.removeEventListener('touchstart', btn._touchHandler);
        
        const handler = (e) => {
            e.preventDefault();
            e.stopPropagation();
            const card = btn.closest('a');
            window.location.href = card?.getAttribute('href') || '/';
        };
        
        btn.addEventListener('click', handler);
        btn.addEventListener('touchstart', handler, { passive: false });
        
        btn._clickHandler = handler;
        btn._touchHandler = handler;
    });
    
    if(window.matchMedia('(hover: none)').matches || document.body.classList.contains('touch')){
        root.querySelectorAll('.grid-item,.scroll-card').forEach(card=>{
            card.addEventListener('touchstart', ()=>{
                document.querySelectorAll('.grid-item.quick-open,.scroll-card.quick-open').forEach(c=>{if(c!==card)c.classList.remove('quick-open');});
                card.classList.add('quick-open');
            }, {passive:true});
        });
    }
}

function renderScrollSection(containerId,items){
    let container=document.getElementById(containerId);
    if(!container) return;
    if(!items||items.length===0){let parent=container.closest('[class*="-section"]');if(parent)parent.style.display='none';return;}
    let cards=[];
    for(let m of items){
        let imdbRating=enNumbers(parseFloat(m.imdb_rate||0).toFixed(1));
        cards.push(`<a href="${bmMovieUrl(m)}" class="scroll-card movie-card" data-imdb="${escapeHtml(m.imdb_code||'')}">
            <div class="poster-wrap is-loading">
                <span class="year-badge">${enNumbers(m.year||'?')}</span>
                ${bmCardPosterMarkup(m,'scroll-card-poster')}
                ${imdbBadge(imdbRating)}
                ${mediaPosterBadges({hasDub:m.has_dubbed||m.has_dub||m.is_dubbed, hasSub:m.has_subtitle||m.has_softsub||m.has_sub})}
                ${activeArchive==='db'?quickActionsMarkup(m.imdb_code,m.title_fa||m.title,m.title,m.year,m.type,m.genres):bmApi5QuickActions(m)}
            </div>
            <div class="scroll-card-info">
                <div class="scroll-card-title-fa">${escapeHtml(m.title_fa||m.title)}</div>
                <div class="scroll-card-title-en">${escapeHtml(m.title)}</div>
            </div>
        </a>`);
    }
    bmSetCardsHTML(container, cards, (root)=>{ setupCardInteractions(root); if(watchlistCache) applyWatchlistStatus(watchlistCache); });
    loadWatchlistStatus();
}

function renderUserRatedSection(containerId,items){
    let container=document.getElementById(containerId);
    if(!container) return;
    if(!items||items.length===0){let parent=container.closest('.user-rated-section');if(parent)parent.style.display='none';return;}
    let cards=[];
    for(let m of items){
        let userRating=enNumbers(parseFloat(m.user_rating||0).toFixed(1));
        let votes=enNumbers(parseInt(m.total_votes||0).toLocaleString());
        let imdbRating=enNumbers(parseFloat(m.imdb_rate||m.user_rating||0).toFixed(1));
        cards.push(`<a href="${bmMovieUrl(m)}" class="scroll-card movie-card" data-imdb="${escapeHtml(m.imdb_code||'')}">
            <div class="poster-wrap is-loading">
                <span class="year-badge">${enNumbers(m.year||'?')}</span>
                ${bmCardPosterMarkup(m,'scroll-card-poster')}
                ${imdbBadge(imdbRating)}
                ${mediaPosterBadges({hasDub:m.has_dubbed||m.has_dub||m.is_dubbed, hasSub:m.has_subtitle||m.has_softsub||m.has_sub})}
                ${bmApi5QuickActions(m)}
            </div>
            <div class="scroll-card-info">
                <div class="scroll-card-title-fa">${escapeHtml(m.title_fa||m.title)}</div>
                <div class="scroll-card-title-en">${escapeHtml(m.title)}</div>
            </div>
        </a>`);
    }
    bmSetCardsHTML(container, cards, (root)=>{ setupCardInteractions(root); if(watchlistCache) applyWatchlistStatus(watchlistCache); });
    loadWatchlistStatus();
}

async function toggleWatchlist(imdbCode,element){
    if(!userId){showToast('لطفاً وارد شوید');setTimeout(()=>window.location.href='/login',1500);return;}
    const isActive=element && element.classList.contains('active');
    const action=isActive?'remove':'add';
    const fd=new FormData();
    fd.append('action',action);
    fd.append('imdb_code',imdbCode);
    fd.append('csrf_token',csrfToken);
    try{
        const res=await fetch('/ajax_watchlist.php',{method:'POST',body:fd});
        const data=await res.json();
        if(data.success){
            setWatchlistActive(imdbCode, !!data.added);
            showToast(data.added ? 'به نشانه‌ها اضافه شد' : 'از نشانه‌ها حذف شد');
        }else showToast('خطا در عملیات');
    }catch(e){showToast('خطا در ارتباط');}
}

async function loadWatchlistStatus(){
    if(!userId) return;
    if(watchlistCache){
        applyWatchlistStatus(watchlistCache);
        return;
    }
    if(watchlistStatusPromise){
        try{ await watchlistStatusPromise; applyWatchlistStatus(watchlistCache); }catch(e){}
        return;
    }
    watchlistStatusPromise=(async()=>{
        const res=await fetch('/ajax_watchlist.php?action=get_status');
        const data=await res.json();
        if(data.success && data.watchlist){
            watchlistCache=new Set(data.watchlist.map(String));
        }else{
            watchlistCache=new Set();
        }
    })();
    try{
        await watchlistStatusPromise;
        applyWatchlistStatus(watchlistCache);
    }catch(e){
        watchlistCache=null;
    }finally{
        watchlistStatusPromise=null;
    }
}

async function loadMovies(reset=true){
    // دیتابیس داخلی فقط مخصوص آرشیو ۲ است.
    // وقتی آرشیو ۱/۳/۴ فعال است، حتی درخواست API داخلی هم زده نشود.
    if(typeof activeArchive !== 'undefined' && !['local','db'].includes(activeArchive)) return;
    if(isLoading && !reset) return;
    if(moviesAbortController) moviesAbortController.abort();
    const controller = new AbortController();
    moviesAbortController = controller;
    isLoading=true;

    const grid = document.getElementById('moviesGrid');
    if(reset && grid){
        currentPage=1;
        grid.classList.add('skeleton-mode');
        grid.classList.add('bm-list-loading');
        grid.innerHTML=renderGridSkeleton(window.innerWidth >= 1200 ? 16 : 9);
    }

    let typeParam=filterType;
    let genreParam='';
    if(filterType==='animation'){typeParam='all';genreParam='Animation,Kids';}

    try{
        let incoming=[],pages=1;
        if(activeArchive==='db'){
            const params=new URLSearchParams({action:'get_movies',page:String(currentPage),type:typeParam,search:currentSearch,sort:'year_desc',genre:genreParam});
            const res=await fetch(`${API_URL}?${params.toString()}`,{signal:controller.signal,credentials:'same-origin'});const data=await res.json();
            if(!(data.success&&data.data))throw new Error('db');incoming=data.data.data||[];pages=Number(data.data.last_page||1);
        }else{
            const params=new URLSearchParams({advanced:'1',page:String(currentPage),limit:'40',type:typeParam,s:currentSearch,order:'newest',genre:genreParam});
            const res=await fetch(`/api5.php?${params.toString()}`,{signal:controller.signal,credentials:'same-origin'});const data=await res.json();
            if(data.status!=='success')throw new Error('api5');incoming=(data.items||data.movies||[]).map(bmNormalizeApi5Item);pages=Number(data.total_pages||data.pagination?.total_pages||(currentPage+(data.has_more?1:0))||1);
        }
        if(reset)allMovies=incoming;else allMovies=[...allMovies,...incoming];totalPages=pages;renderMoviesGrid();
    }catch(e){
        if(e.name !== 'AbortError' && grid){
            grid.innerHTML='<div class="empty-state">خطا در ارتباط با سرور</div>';
        }
    }finally{
        if(moviesAbortController === controller){
            isLoading=false;
            hideLoading();
        }
    }
}

function renderMoviesGrid(){
    if(typeof activeArchive !== 'undefined' && !['local','db'].includes(activeArchive)) return;
    let container=document.getElementById('moviesGrid');
    if(!container) return;
    container.classList.remove('skeleton-mode');
    container.classList.remove('bm-list-loading');
    bmEndTypeSectionTransition();
    if(!allMovies||allMovies.length===0){
        container.innerHTML=`<div class="empty-search-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><p>${userLang==='fa'?'نتیجه‌ای یافت نشد':'No results found'}</p><a href="/search"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="22 3 2 3 10 13 10 21 14 18 14 13 22 3"/></svg>${userLang==='fa'?'جستجوی پیشرفته':'Advanced Search'}</a></div>`;
        const lm=document.getElementById('loadMoreBtn');if(lm)lm.style.display='none';
        return;
    }
    let cards=[];
    for(let m of allMovies){
        let typeLabel=m.type==='movie'?(userLang==='fa'?'فیلم':'Movie'):(userLang==='fa'?'سریال':'Series');
        let imdbRating=enNumbers(parseFloat(m.imdb_rate||0).toFixed(1));
        cards.push(`<a href="${bmMovieUrl(m)}" class="grid-item movie-card" data-imdb="${escapeHtml(m.imdb_code||'')}">
            <div class="poster-wrap is-loading">
                <span class="year-badge">${enNumbers(m.year||'?')}</span>
                ${activeArchive==='db'?posterImageMarkup(m.imdb_code,'grid-poster'):bmCardPosterMarkup(m,'grid-poster')}
                ${imdbBadge(imdbRating)}
                ${mediaPosterBadges({hasDub:m.has_dubbed||m.has_dub||m.is_dubbed, hasSub:m.has_subtitle||m.has_softsub||m.has_sub})}
                ${bmApi5QuickActions(m)}
            </div>
            <div class="grid-info">
                <div class="grid-title-fa">${escapeHtml(m.title_fa||m.title)}</div>
                <div class="grid-title-en">${escapeHtml(m.title)}</div>
                <div class="grid-meta">
                    <span class="grid-badge">${typeLabel}</span>
                </div>
            </div>
        </a>`);
    }
    bmSetCardsHTML(container, cards, (root)=>{ setupCardInteractions(root); if(watchlistCache) applyWatchlistStatus(watchlistCache); });
    loadWatchlistStatus();
    const lm=document.getElementById('loadMoreBtn');if(lm)lm.style.display='none';
}
function loadMoreMovies(){if(typeof activeArchive !== 'undefined' && !['local','db'].includes(activeArchive)) return;if(currentPage<totalPages){currentPage++;loadMovies(false);}}

// Stories (بدون تغییر)
function bmStoryThumbSource(story){
    story = story || {};
    return story.thumbnail_path || story.thumb_path || story.poster_path || story.cover_path || story.cover_image || story.thumbnail || story.poster || story.cover || story.image || story.image_path || '';
}

function initStories(){
    if(!storiesData.length) return;
    let container=document.getElementById('storiesContainer');
    if(!container) return;
    let html='';
    storiesData.forEach((story,idx)=>{
        const isVideo=story.type==='video';
        const caption=escapeHtml(story.caption||(userLang=='fa'?'جدید':'New'));
        const src=escapeHtml(bmStoryMediaUrl(story.file_path||''));
        const thumb=escapeHtml(bmStoryMediaUrl(bmStoryThumbSource(story)));
        const mediaHtml=isVideo
            ? `<div class="story-video-thumb-wrap" aria-label="video story">${thumb?`<img class="story-thumb-img" src="${thumb}" loading="lazy" decoding="async" onerror="window.BMStoryImageFallback(this)">`:''}<video class="story-thumb-video" muted playsinline preload="none" data-src="${src}"></video></div>`
            : (src ? `<img src="${src}" loading="lazy" decoding="async" style="object-fit:${STORY_IMAGE_FIT}" onerror="window.BMStoryImageFallback(this)">` : `<div class="story-thumb-fallback" role="img" aria-label="${caption}"><span aria-hidden="true">✦</span></div>`);
        html+=`<div class="story-item" data-index="${idx}"><div class="story-avatar">${mediaHtml}</div><div class="story-name">${caption}</div></div>`;
    });
    container.innerHTML=html;
    document.querySelectorAll('.story-item').forEach(item=>{item.addEventListener('click',()=>openStory(parseInt(item.dataset.index)));});
    hydrateStoryVideoThumbs();
}

function hydrateStoryVideoThumbs(){
    const videos=Array.from(document.querySelectorAll('.story-thumb-video[data-src]'));
    if(!videos.length) return;
    const loadThumb=(video)=>{
        if(!video || video.dataset.loaded==='1') return;
        const src=video.dataset.src;
        if(!src) return;
        video.dataset.loaded='1';
        video.src=src;
        video.preload='metadata';
        video.muted=true;
        video.playsInline=true;
        const markLoaded=()=>{
            video.classList.add('is-loaded');
            const wrap=video.closest('.story-video-thumb-wrap');
            if(wrap) wrap.classList.add('is-loaded');
        };
        video.addEventListener('loadeddata',markLoaded,{once:true});
        video.addEventListener('error',()=>{
            const wrap=video.closest('.story-video-thumb-wrap');
            if(wrap && !wrap.querySelector('.story-thumb-img,.story-thumb-fallback')) wrap.appendChild(bmStoryFallbackNode(false,''));
            video.remove();
        },{once:true});
        video.addEventListener('loadedmetadata',()=>{
            try{
                if(video.duration && video.duration>0.25){ video.currentTime=0.12; }
            }catch(e){}
            markLoaded();
        },{once:true});
        video.load();
    };
    if('IntersectionObserver' in window){
        const io=new IntersectionObserver((entries)=>{
            entries.forEach(entry=>{
                if(entry.isIntersecting){
                    loadThumb(entry.target);
                    io.unobserve(entry.target);
                }
            });
        },{rootMargin:'160px 0px',threshold:0.01});
        videos.forEach(v=>io.observe(v));
    }else{
        const run=()=>videos.forEach(loadThumb);
        if('requestIdleCallback' in window) requestIdleCallback(run,{timeout:1600});
        else setTimeout(run,800);
    }
}
function openStory(index){
    if(storiesData.length===0) return;
    currentStoryIndex=index;
    const progressContainer=document.getElementById('storyProgressContainer');
    if(progressContainer){
        progressContainer.innerHTML='';
        storiesData.forEach((_,i)=>{
            const bar=document.createElement('div');
            bar.className='story-progress-bar';
            bar.innerHTML='<div class="story-progress-fill" id="progressFill_'+i+'"></div>';
            progressContainer.appendChild(bar);
        });
    }
    document.getElementById('storyModal').classList.add('active');
    showStory(currentStoryIndex);
    addDownloadButtonToStory();
}

function addDownloadButtonToStory(){
    const modal=document.getElementById('storyModal');
    let existing=document.getElementById('storyDownloadBtn');
    if(existing) existing.remove();
    const story=storiesData[currentStoryIndex];
    if(!story) return;
    const btn=document.createElement('button');
    btn.id='storyDownloadBtn';
    btn.className='story-download-btn';
    btn.innerHTML=`<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> ${userLang=='fa'?'دانلود':'Download'}`;
    btn.onclick=(e)=>{
        e.stopPropagation();
        const a=document.createElement('a');
        a.href=safeUrl(story.file_path) || story.file_path;
        a.download=story.caption||'story_'+story.id;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        showToast(userLang=='fa'?'دانلود شروع شد':'Download started');
    };
    modal.appendChild(btn);
}

function showStory(index){
    const story=storiesData[index];
    if(!story) return;

    clearStoryProgress();
    storyIsPaused=false;
    storyImageElapsed=0;
    storyImageStartedAt=0;

    const content=document.getElementById('storyContent');
    const isVideo=story.type==='video';
    const storyLink=safeUrl(story.link);
    const linkHtml=storyLink?`<a href="${escapeHtml(storyLink)}" class="story-link" target="_blank" rel="noopener noreferrer">${userLang=='fa'?'مشاهده':'View'}</a>`:'';

    if(isVideo){
        storyProgressMode='video';
        content.innerHTML=`<video class="story-media" id="storyVideo" autoplay playsinline preload="metadata" style="max-width:100%;max-height:70vh;object-fit:contain;"><source src="${escapeHtml(bmStoryMediaUrl(story.file_path))}" type="video/mp4"></video><div class="story-caption">${escapeHtml(story.caption||'')}</div>${linkHtml}`;
        const videoEl=document.getElementById('storyVideo');
        if(videoEl){
            videoEl.addEventListener('loadedmetadata',()=>startVideoProgress(videoEl.duration),{once:true});
            videoEl.addEventListener('ended',()=>nextStory(),{once:true});
            videoEl.play().catch(()=>{});
        }
    }else{
        storyProgressMode='image';
        content.innerHTML=bmStoryMediaUrl(story.file_path) ? `<img class="story-media" src="${escapeHtml(bmStoryMediaUrl(story.file_path))}" loading="eager" decoding="async" style="max-width:100%;max-height:70vh;object-fit:${STORY_IMAGE_FIT};" onerror="window.BMStoryImageFallback(this)"><div class="story-caption">${escapeHtml(story.caption||'')}</div>${linkHtml}` : `<div class="story-media story-media-fallback" role="img"><span aria-hidden="true">✦</span></div><div class="story-caption">${escapeHtml(story.caption||'')}</div>${linkHtml}`;
        startStoryProgress();
    }

    document.querySelectorAll('.story-progress-fill').forEach((fill,i)=>{
        if(i<index) fill.style.width='100%';
        else fill.style.width='0%';
    });
}

function startStoryProgress(){
    clearStoryProgress();
    storyProgressMode='image';
    storyImageElapsed=0;
    storyImageStartedAt=Date.now();
    const duration=5000;

    storyProgressInterval=setInterval(()=>{
        if(storyIsPaused) return;
        const elapsed=storyImageElapsed + (Date.now()-storyImageStartedAt);
        const progress=Math.min((elapsed/duration)*100,100);
        updateProgressFill(progress);
        if(progress>=100){clearStoryProgress();nextStory();}
    },50);
}

function startVideoProgress(duration){
    clearStoryProgress();
    storyProgressMode='video';
    if(!Number.isFinite(duration)||duration<=0) return;
    storyProgressInterval=setInterval(()=>{
        if(storyIsPaused) return;
        const videoEl=document.getElementById('storyVideo');
        if(videoEl){
            const progress=(videoEl.currentTime/duration)*100;
            updateProgressFill(Math.min(progress,100));
            if(progress>=100) clearStoryProgress();
        }
    },100);
}

function updateProgressFill(percent){
    const fill=document.getElementById(`progressFill_${currentStoryIndex}`);
    if(fill){fill.style.width=percent+'%';if(percent>0)fill.classList.add('active');}
}
function clearStoryProgress(){if(storyProgressInterval){clearInterval(storyProgressInterval);storyProgressInterval=null;}}
function startHoldPause(){
    if(storyHoldTimer) clearTimeout(storyHoldTimer);
    storyHoldTimer=setTimeout(()=>{
        if(!storyIsPaused){
            storyIsPaused=true;
            if(storyProgressMode==='image'){
                storyImageElapsed += Date.now()-storyImageStartedAt;
            }
            const video=document.getElementById('storyVideo');
            if(video&&!video.paused) video.pause();
            showToast(userLang=='fa'?'توقف موقت':'Paused',2000);
        }
    },500);
}
function endHoldPause(){
    if(storyHoldTimer){clearTimeout(storyHoldTimer);storyHoldTimer=null;}
    if(storyIsPaused){
        storyIsPaused=false;
        if(storyProgressMode==='image'){
            storyImageStartedAt=Date.now();
        }
        const video=document.getElementById('storyVideo');
        if(video&&video.paused) video.play().catch(()=>{});
        showToast(userLang=='fa'?'ادامه پخش':'Resumed',1000);
    }
}
function initStorySwipe(){
    const modal=document.getElementById('storyModal');
    if(!modal) return;
    let touchStartX=0;
    modal.addEventListener('touchstart',(e)=>{touchStartX=e.touches[0].clientX;});
    modal.addEventListener('touchend',(e)=>{
        const endX=e.changedTouches[0].clientX;
        const diff=endX-touchStartX;
        if(Math.abs(diff)>50){
            if(diff>0) prevStory();
            else nextStory();
        }
    });
    modal.addEventListener('click',(e)=>{
        if(e.target===modal||e.target.classList.contains('story-content')){
            const rect=modal.getBoundingClientRect();
            const clickX=e.clientX-rect.left;
            if(clickX<rect.width/2) prevStory();
            else nextStory();
        }
    });
    const storyMedia=document.getElementById('storyContent');
    if(storyMedia){
        storyMedia.addEventListener('mousedown',startHoldPause);
        storyMedia.addEventListener('mouseup',endHoldPause);
        storyMedia.addEventListener('mouseleave',()=>{if(storyHoldTimer){clearTimeout(storyHoldTimer);storyHoldTimer=null;}});
        storyMedia.addEventListener('touchstart',startHoldPause,{passive:true});
        storyMedia.addEventListener('touchend',endHoldPause);
    }
}
function nextStory(){
    clearStoryProgress();
    if(currentStoryIndex+1<storiesData.length){
        currentStoryIndex++;
        showStory(currentStoryIndex);
        addDownloadButtonToStory();
    }else closeStoryModal();
}
function prevStory(){
    clearStoryProgress();
    if(currentStoryIndex-1>=0){
        currentStoryIndex--;
        showStory(currentStoryIndex);
        addDownloadButtonToStory();
    }
}
function closeStoryModal(){
    clearStoryProgress();
    storyIsPaused=false;
    document.getElementById('storyModal').classList.remove('active');
    const video=document.getElementById('storyVideo');
    if(video) video.pause();
    document.getElementById('storyContent').innerHTML='';
    const btn=document.getElementById('storyDownloadBtn');
    if(btn) btn.remove();
}

// Menu (بدون تغییر)
function setupMenu(){
    const menuBtn=document.getElementById('menuBtn');
    const sidebarMenu=document.getElementById('sidebarMenu');
    const menuOverlay=document.getElementById('menuOverlay');
    const closeMenuBtn=document.getElementById('closeMenuBtn');
    if(!menuBtn||!sidebarMenu||!menuOverlay||!closeMenuBtn) return;

    function openMenu(){
        if(window.matchMedia('(min-width: 992px)').matches) return;
        sidebarMenu.classList.add('open');
        menuOverlay.classList.add('active');
        document.body.style.overflow='hidden';
        menuBtn.setAttribute('aria-expanded','true');
    }
    function closeMenu(){
        sidebarMenu.classList.remove('open');
        menuOverlay.classList.remove('active');
        document.body.style.overflow='';
        menuBtn.setAttribute('aria-expanded','false');
    }

    menuBtn.addEventListener('click',openMenu);
    closeMenuBtn.addEventListener('click',closeMenu);
    menuOverlay.addEventListener('click',closeMenu);
    window.addEventListener('resize',()=>{if(window.innerWidth>=992) closeMenu();});
}

function setupHeaderScroll(){
    const header=document.getElementById('siteHeader') || document.querySelector('.header');
    const hero=document.querySelector('.hero-slider');
    if(!header) return;
    if(document.documentElement.classList.contains('bm-nav-static')){
        // V47 low-end: one stable header state, no per-scroll class churn/repaint.
        header.classList.remove('header-solid');
        header.classList.add('header-glass');
        header.setAttribute('data-bm-static-header','1');
        return;
    }
    if(header.dataset.bmSmartHeaderFixed === '1' || header.classList.contains('bm-header-fixed-top')){
        header.classList.remove('header-glass');
        header.classList.add('header-solid');
        return;
    }

    let threshold=0;
    let ticking=false;
    let lastOverHero=null;
    let resizeTimer=0;

    function recalc(){
        const headerHeight=header.offsetHeight || 60;
        threshold = hero ? Math.max(0, (hero.offsetTop || 0) + (hero.offsetHeight || 0) - headerHeight - 10) : 0;
        scheduleUpdate();
    }

    function applyHeaderState(){
        ticking=false;
        const y=window.scrollY || window.pageYOffset || 0;
        const overHero=!!hero && y < threshold;
        if(overHero===lastOverHero) return;
        lastOverHero=overHero;
        header.classList.toggle('header-glass',overHero);
        header.classList.toggle('header-solid',!overHero);
    }

    function scheduleUpdate(){
        if(ticking) return;
        ticking=true;
        requestAnimationFrame(applyHeaderState);
    }

    recalc();
    window.addEventListener('scroll',scheduleUpdate,{passive:true});
    window.addEventListener('resize',()=>{
        clearTimeout(resizeTimer);
        resizeTimer=setTimeout(recalc,120);
    },{passive:true});
}


function setupSmartBottomNav(){
    const nav=document.querySelector('.bottom-nav');
    if(!nav) return;
    // V46: low-end phones keep the footer nav permanently visible and do not
    // install the per-scroll hide/compact controller. Strong phones keep the
    // original behavior unchanged.
    if(document.documentElement.classList.contains('bm-nav-static')){
        nav.classList.remove('nav-hidden','nav-compact');
        nav.setAttribute('data-bm-static-nav','1');
        return;
    }
    if(document.documentElement.classList.contains('bm-ultra-lite')){
        nav.classList.remove('nav-hidden');
        nav.classList.toggle('nav-compact',(window.scrollY||0)>220);
        return;
    }
    let lastY=window.scrollY || 0;
    let ticking=false;
    const minDelta=12;

    function shouldKeepVisible(){
        const activeElement=document.activeElement;
        return window.innerWidth>=992 ||
            window.scrollY<120 ||
            document.body.style.overflow==='hidden' ||
            document.querySelector('.story-modal.active') ||
            document.querySelector('.sidebar-menu.open') ||
            (activeElement && ['INPUT','TEXTAREA','SELECT'].includes(activeElement.tagName));
    }

    function update(){
        const y=window.scrollY || 0;
        const diff=y-lastY;
        if(shouldKeepVisible()){
            nav.classList.remove('nav-hidden');
            nav.classList.toggle('nav-compact', y>220);
            lastY=y;
            ticking=false;
            return;
        }
        if(Math.abs(diff)>minDelta){
            nav.classList.toggle('nav-hidden', diff>0);
            nav.classList.toggle('nav-compact', y>220 && diff<=0);
            lastY=y;
        }
        ticking=false;
    }

    window.addEventListener('scroll',()=>{
        if(!ticking){
            window.requestAnimationFrame(update);
            ticking=true;
        }
    },{passive:true});
    window.addEventListener('resize',update);
    document.addEventListener('focusin',update);
    document.addEventListener('focusout',()=>setTimeout(update,80));
    update();
}

// Notifications sidebar (بدون تغییر)
const notifBell=document.getElementById('notifBell');
const notifSidebar=document.getElementById('notifSidebar');
const closeNotifSidebar=document.getElementById('closeNotifSidebar');
if(notifBell&&notifSidebar&&closeNotifSidebar){
    notifBell.addEventListener('click',()=>{notifSidebar.classList.add('open');});
    closeNotifSidebar.addEventListener('click',()=>{notifSidebar.classList.remove('open');});
    document.addEventListener('click',(e)=>{
        if(!notifSidebar.contains(e.target)&&!notifBell.contains(e.target)&&notifSidebar.classList.contains('open')){
            notifSidebar.classList.remove('open');
        }
    });
}

// Hero Slider (بدون تغییر)
(function(){
    const slides = document.querySelectorAll('.hero-slide');
    const dots = document.querySelectorAll('.hero-dot');
    const prevBtn = document.getElementById('heroPrev');
    const nextBtn = document.getElementById('heroNext');
    const slider = document.querySelector('.hero-slider');
    if (!slides.length) return;

    let current = 0;
    let autoTimer = null;
    const rootEl = document.documentElement;
    const heroUltraLite = rootEl.classList.contains('bm-ultra-lite');
    const heroMobileLite = rootEl.classList.contains('bm-mobile-lite');
    const autoDelay = heroMobileLite ? 8500 : 5000;

    function showSlide(index, restart = true){
        if (index < 0) index = slides.length - 1;
        if (index >= slides.length) index = 0;
        slides.forEach((s, i) => s.classList.toggle('active', i === index));
        dots.forEach((d, i) => d.classList.toggle('active', i === index));
        current = index;
        if(restart) startAutoPlay();
    }

    function nextSlide(){ showSlide(current + 1, false); }
    function prevSlide(){ showSlide(current - 1); }

    function startAutoPlay(){
        if (autoTimer) clearInterval(autoTimer);
        autoTimer = null;
        if(heroUltraLite || slides.length < 2 || document.hidden) return;
        autoTimer = setInterval(nextSlide, autoDelay);
    }

    function stopAutoPlay(){
        if (autoTimer) clearInterval(autoTimer);
        autoTimer = null;
    }

    if (prevBtn) prevBtn.addEventListener('click', () => { prevSlide(); });
    if (nextBtn) nextBtn.addEventListener('click', () => { showSlide(current + 1); });
    dots.forEach((dot, idx) => dot.addEventListener('click', () => showSlide(idx)));

    if(slider){
        slider.addEventListener('mouseenter', stopAutoPlay);
        slider.addEventListener('mouseleave', startAutoPlay);

        let touchStartX = 0;
        slider.addEventListener('touchstart', (e) => { touchStartX = e.changedTouches[0].screenX; }, {passive:true});
        slider.addEventListener('touchend', (e) => {
            const diff = e.changedTouches[0].screenX - touchStartX;
            if (Math.abs(diff) > 50) {
                if (diff > 0) prevSlide();
                else showSlide(current + 1);
            }
        });
    }

    if(slider && 'IntersectionObserver' in window){
        const heroPlayObserver = new IntersectionObserver((entries)=>{
            const visible = entries.some(entry => entry.isIntersecting);
            if(visible && !document.hidden) startAutoPlay();
            else stopAutoPlay();
        }, {threshold: 0.12});
        heroPlayObserver.observe(slider);
        document.addEventListener('visibilitychange', () => {
            if(document.hidden) stopAutoPlay();
            else startAutoPlay();
        }, {passive:true});
    }
    startAutoPlay();
})();

/* ===== Unified Search & Archive Switcher ===== */
const ARCHIVE_CONTROL = BM_HOME_CONFIG.archiveControl || {};
const ARC_MODE_TO_ID = {arc1:'archive1', local:'archive2', arc3:'archive3', arc4:'archive4', db:'archive5'};
const ARC_HINTS = BM_HOME_CONFIG.arcHints || {};
let activeArchive = BM_HOME_CONFIG.activeArchive || 'local';
let extIsActive = true;
let arc3IsActive = false;
let arc4IsActive = false;
let extAbort = null;
let arc3Abort = null;
let arc4Abort = null;
let bmLocalHomeRendered = false;
let bmDbHomeRendered = false;

function bmSetArchiveModeAttr(mode){
    const safeMode = mode || 'local';
    document.documentElement.setAttribute('data-bm-archive', safeMode);
    if(document.body) document.body.setAttribute('data-bm-archive', safeMode);
}

function bmClearLocalHomeForExternal(){
    // بخش انتهای صفحه از دیتابیس داخلی فقط باید روی آرشیو ۲ باشد.
    // در آرشیوهای دیگر، هم نمایش و هم API داخلی قطع می‌شود.
    if(moviesAbortController) { try { moviesAbortController.abort(); } catch(e){} }
    isLoading = false;
    allMovies = [];
    currentPage = 1;
    const grid = document.getElementById('moviesGrid');
    if(grid){
        grid.classList.remove('skeleton-mode');
        grid.innerHTML = '';
    }
    const loadMore = document.getElementById('loadMoreBtn');
    if(loadMore) loadMore.style.display = 'none';
}

const bmApi5SectionCache=new Map();
async function bmApi5Section(section,limit=18){
    const key=`${section}|${limit}`;
    if(bmApi5SectionCache.has(key))return bmApi5SectionCache.get(key);
    const promise=fetch(`/api5.php?section=${encodeURIComponent(section)}&page=1`,{credentials:'same-origin'})
      .then(r=>r.json()).then(data=>(data.items||data.movies||[]).slice(0,limit).map(bmNormalizeApi5Item)).catch(()=>[]);
    bmApi5SectionCache.set(key,promise);return promise;
}
function bmSectionWrapperByList(id){
    const list=document.getElementById(id);
    return list ? (list.closest('[data-home-source]')||list.parentElement) : null;
}
function bmOrderApi5Home(){
    const home=document.getElementById('homePage');if(!home)return;
    [
      bmSectionWrapperByList('topSeriesList'),
      bmSectionWrapperByList('topMoviesList'),
      bmSectionWrapperByList('latestAnimationsList'),
      home.querySelector('.collections-section[data-home-source]'),
      bmSectionWrapperByList('dubbedList')
    ].filter(Boolean).forEach(node=>home.appendChild(node));
}
async function bmRenderApi5Home(){
    bmOrderApi5Home();
    const [series,movies,animation,dubbed]=await Promise.all([
      bmApi5Section('new_series',18),
      bmApi5Section('new_movies',18),
      bmApi5Section('animation',18),
      bmApi5Section('dubbed',18)
    ]);
    renderScrollSection('topSeriesList',series);
    renderScrollSection('topMoviesList',movies);
    renderScrollSection('latestAnimationsList',animation);
    renderScrollSection('dubbedList',dubbed);
}
function bmRenderDbHome(){
    renderScrollSection('newReleasesList',newReleasesData);
    renderScrollSection('latestAnimationsList',latestAnimationsData);
    renderScrollSection('topMoviesList',topMoviesData);
    renderScrollSection('topSeriesList',topSeriesData);
    renderScrollSection('adminPicksList',adminPicksData);
    renderScrollSection('dubbedList',dubbedMoviesData);
    renderScrollSection('updatedList',updatedMoviesData);
    renderUserRatedSection('userRatedList',userRatedData);
    if(smartSuggestionsData.length)renderScrollSection('smartSuggestionsList',smartSuggestionsData);
}
function bmApplyHomeSource(mode){
    const source=mode==='db'?'db':'api5';
    document.querySelectorAll('[data-home-source]').forEach(el=>{
      const allowed=String(el.dataset.homeSource||'').split(/\s+/).filter(Boolean);
      el.style.display=allowed.includes(source)?'':'none';
    });
    const s=document.getElementById('bmTopSeriesTitle');if(s)s.textContent=source==='api5'?'سریال‌های آپدیت‌شده':'برترین سریال‌ها';
    const m=document.getElementById('bmTopMoviesTitle');if(m)m.textContent=source==='api5'?'فیلم‌های جدید':'برترین فیلم‌ها';
    const b=document.getElementById('bmBrowseTitle');if(b)b.textContent='آرشیو دیتابیس';
}
async function bmEnsureLocalHomeLoaded(mode=activeArchive){
    bmApplyHomeSource(mode);
    if(mode==='db'){
      bmRenderDbHome();
      const grid=document.getElementById('moviesGrid');
      if(grid){grid.innerHTML='';allMovies=[];currentPage=1;}
      if(!isLoading)loadMovies(true);
    }else{
      if(moviesAbortController){try{moviesAbortController.abort();}catch(_e){}}
      isLoading=false;
      const grid=document.getElementById('moviesGrid');if(grid)grid.innerHTML='';
      await bmRenderApi5Home();
    }
}

// ===== Unified Search =====
(function(){
    const inp = document.getElementById('unifiedSearchInput');
    const resultsBox = document.getElementById('unifiedSearchResults');
    if(!inp) return;

    let timer, abortCtrl;

    function normalizedTerm(value){
        if(typeof window.bmNormalizeSearchTerm === 'function') return window.bmNormalizeSearchTerm(value);
        return String(value || '').trim();
    }

    function quickSearchArchive(){
        if(typeof window.bmQuickSearchGetArchive === 'function') return window.bmQuickSearchGetArchive();
        return window.BM_QUICK_SEARCH_ARCHIVE || activeArchive;
    }

    function abortAllSearches(){
        if(abortCtrl){ try{ abortCtrl.abort(); }catch(e){} }
        if(extAbort){ try{ extAbort.abort(); }catch(e){} }
        if(arc3Abort){ try{ arc3Abort.abort(); }catch(e){} }
        if(arc4Abort){ try{ arc4Abort.abort(); }catch(e){} }
    }

    inp.addEventListener('input', function(){
        const rawTerm = inp.value.trim();
        const term = normalizedTerm(rawTerm);
        const mode = quickSearchArchive();
        clearTimeout(timer);
        abortAllSearches();

        if(term === ''){
            if(resultsBox){
                resultsBox.classList.remove('active');
                resultsBox.innerHTML = '';
            }
            return;
        }
        if(term.length < 2){
            if(resultsBox) resultsBox.classList.remove('active');
            return;
        }

        if(resultsBox){
            resultsBox.innerHTML = (typeof window.bmQuickSearchLoaderMarkup === 'function')
                ? window.bmQuickSearchLoaderMarkup()
                : '<div style="padding:20px;text-align:center"><div class="loading-spinner" style="width:30px;height:30px"></div></div>';
            resultsBox.classList.add('active');
        }

        timer = setTimeout(async () => {
            const requestedMode = quickSearchArchive();
            if(requestedMode === 'db'){ window.location.href=`/search?archive=db&q=${encodeURIComponent(term)}`; return; }
            if(requestedMode === 'arc1'){
                extSearchQuery(term);
            } else if(requestedMode === 'arc3') {
                arc3SearchQuery(term);
            } else if(requestedMode === 'arc4') {
                arc4SearchQuery(term);
            } else {
                abortCtrl = new AbortController();
                try{
                    const res = await fetch(`/api5.php?s=${encodeURIComponent(term)}&page=1`, {signal: abortCtrl.signal,credentials:'same-origin'});
                    const data = await res.json();
                    if(normalizedTerm(inp.value) !== term || quickSearchArchive() !== requestedMode) return;
                    const api5Items=(data.items||data.movies||[]).map(bmNormalizeApi5Item);
                    if(data.status==='success' && api5Items.length){
                        let html='';
                        for(let m of api5Items){
                            let typeLabel = m.type==='movie'?(userLang==='fa'?'فیلم':'Movie'):(userLang==='fa'?'سریال':'Series');
                            html += `<div class="search-result-item" data-url="${escapeHtml(bmMovieUrl(m))}">
                                <img class="search-result-poster" src="${escapeHtml(safeUrl(m.poster)||safeUrl(m.poster_proxy)||DEFAULT_POSTER)}" data-proxy="${escapeHtml(safeUrl(m.poster_proxy)||'')}" loading="lazy" decoding="async" onerror="bmApi5PosterError(this)">
                                <div class="search-result-info">
                                    <div class="search-result-title"><bdi dir="auto">${escapeHtml(m.title_fa||m.title)}</bdi></div>
                                    <div class="search-result-original"><bdi dir="auto">${escapeHtml(m.title||'')}</bdi></div>
                                    <div class="search-result-meta"><span>${enNumbers(m.year||'?')}</span>${imdbMeta(enNumbers(parseFloat(m.imdb_rate||0).toFixed(1)))}<span class="search-result-badge">${typeLabel}</span></div>
                                </div>
                            </div>`;
                        }
                        if(resultsBox){ resultsBox.innerHTML=html; resultsBox.classList.add('active'); }
                        resultsBox && resultsBox.querySelectorAll('.search-result-item').forEach(item=>{
                            item.addEventListener('click', () => window.location.href = item.dataset.url||'/');
                        });
                    } else if(resultsBox) {
                        resultsBox.innerHTML=`<div class="empty-search-state" style="padding:20px;text-align:center">${userLang==='fa'?'نتیجه‌ای یافت نشد':'No results'}</div>`;
                        resultsBox.classList.add('active');
                    }
                }catch(e){
                    if(e.name !== 'AbortError' && resultsBox){
                        resultsBox.innerHTML=`<div style="padding:20px;text-align:center;color:#f87">${userLang==='fa'?'خطا در جستجو':'Error'}</div>`;
                        resultsBox.classList.add('active');
                    }
                }
            }
        }, 260);
    });

    document.addEventListener('click', e => {
        const modal = document.getElementById('bmQuickSearchModal');
        if(modal && modal.classList.contains('open')) return;
        if(resultsBox && !inp.contains(e.target) && !resultsBox.contains(e.target)) resultsBox.classList.remove('active');
    });
})();

// جستجو در آرشیو ۱ با نتایج زیبا
async function extSearchQuery(term){
    const wrap = document.getElementById('extSearchResultsWrap');
    const list = document.getElementById('extSearchResultsList');
    const sections = document.getElementById('extScrollSections');
    const title = document.getElementById('extSearchResultTitle');
    const uniResults = document.getElementById('unifiedSearchResults');

    // سرچ زنده آرشیو ۱ فقط داخل باکس سرچ بالا نمایش داده می‌شود.
    // لیست کارت‌های بزرگ پایین را باز نمی‌کنیم تا پوسترهای بزرگ زیر dropdown نیایند.
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(title) title.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> نتایج: ${escapeHtml(term)}`;
    if(list) list.innerHTML='';

    if(extAbort) extAbort.abort();
    extAbort = new AbortController();
    try{
        const res = await fetch(`api2.php?s=${encodeURIComponent(term)}&page=1`, {signal: extAbort.signal});
        const data = await res.json();
        const items = data.movies || [];

        // نمایش نتایج در باکس سرچ بالا (ظاهر سرچ معمولی) 
        if(uniResults){
            if(items.length){
                let html='';
                const liveLimit = 20;
                const liveItems = items.slice(0, liveLimit);
                const hasMoreLiveResults = items.length >= liveLimit || data.has_more || data.next_page;
                const viewAllUrl = `/view_all?type=arc1_search&q=${encodeURIComponent(term)}`;
                for(let item of liveItems){
                    let title2 = (item.title||'').replace(/old|فیلم 2 مدیا|film2media/gi,'').trim();
                    let isSeries = item.type==='series';
                    let poster = item.poster || '';
                    let slug = arc1DetailId(item);
                    let link = arc1MovieUrl(item);
                    let rateStr = parseFloat(item.rating||0) > 0 ? enNumbers(parseFloat(item.rating).toFixed(1)) : '';
                    html += `<div class="search-result-item" data-url="${escapeHtml(link)}" style="cursor:pointer">
                        <img class="search-result-poster" src="${escapeHtml(poster)}" onerror="this.src='${DEFAULT_POSTER}'" loading="lazy">
                        <div class="search-result-info">
                            <div class="search-result-title"><bdi dir="auto">${escapeHtml(title2)}</bdi></div>
                            <div class="search-result-original">${isSeries?'سریال':'فیلم'}${item.has_dubbed?' · دوبله':''}</div>
                            <div class="search-result-meta">
                                <span>${enNumbers(item.year||'?')}</span>
                                ${rateStr ? imdbMeta(rateStr) : ''}
                                <span class="search-result-badge">آرشیو ۱</span>
                            </div>
                        </div>
                    </div>`;
                }
                if(hasMoreLiveResults){
                    html += `<a href="${escapeHtml(viewAllUrl)}" class="search-result-viewall" style="display:flex;align-items:center;justify-content:center;gap:8px;margin:8px 10px 10px;padding:11px 12px;border-radius:16px;background:rgba(var(--accent-rgb),.14);border:1px solid rgba(var(--accent-rgb),.35);color:var(--accent);font-size:12px;font-weight:900;text-decoration:none">
                        مشاهده همه نتایج
                        <span style="font-weight:650;color:rgba(255,255,255,.55)">بقیه نتایج رفت تو این</span>
                    </a>`;
                }
                uniResults.innerHTML = html;
                uniResults.classList.add('active');
                uniResults.querySelectorAll('.search-result-item').forEach(item => {
                    item.addEventListener('click', () => window.location.href = item.dataset.url);
                });
            } else {
                uniResults.innerHTML = `<div class="empty-search-state" style="padding:20px;text-align:center">${userLang==='fa'?'نتیجه‌ای در آرشیو ۱ یافت نشد':'No results'}</div>`;
                uniResults.classList.add('active');
            }
        }

        // عمداً نتیجه‌ها را پایین صفحه به صورت کارت بزرگ رندر نمی‌کنیم.
        // نتیجه کامل از دکمه مشاهده همه داخل باکس سرچ باز می‌شود.
        if(list) list.innerHTML = '';
    }catch(e){
        if(e.name !== 'AbortError' && list)
            list.innerHTML=`<div style="padding:20px;color:#f87">خطا در ارتباط با سرور</div>`;
    }
}

function extClearSearch(){
    const wrap = document.getElementById('extSearchResultsWrap');
    const sections = document.getElementById('extScrollSections');
    const uniResults = document.getElementById('unifiedSearchResults');
    const inp = document.getElementById('unifiedSearchInput');
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(uniResults) uniResults.classList.remove('active');
    if(inp) inp.value='';
}

// رندر کارت‌های آرشیو ۱
function renderExtItemsParts(items){
    let cards = [];
    for(const item of items){
        let title = (item.title||'').replace(/old|فیلم 2 مدیا|film2media/gi,'').trim();
        const year = item.year || '';
        const rate = parseFloat(item.rating||0);
        const rateStr = rate > 0 ? enNumbers(rate.toFixed(1)) : '';
        const poster = item.poster || '';
        const slug = arc1DetailId(item);
        const isSeries = item.type === 'series';
        const hasDub = item.has_dubbed;
        const detailLink = arc1MovieUrl(item);

        const titleEn = bmApiEnglishTitle(item, title);
        const genres = bmApiGenresValue(item);
        cards.push(`<a href="${escapeHtml(detailLink)}" class="scroll-card movie-card" data-bm-api-archive="1">
            <div class="poster-wrap">
                <span class="year-badge">${enNumbers(year||'?')}</span>
                ${poster
                    ? `<img class="scroll-card-poster bm-poster-img" src="${escapeHtml(poster)}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1" onerror="this.src='${DEFAULT_POSTER}'">`
                    : `<img class="scroll-card-poster bm-poster-img" src="${DEFAULT_POSTER}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1">`}
                ${rateStr ? `<span class="imdb-card-badge">${imdbLogoSvg()}<b>${rateStr}</b></span>` : ''}
                ${mediaPosterBadges({hasDub:hasDub, hasSub:item.has_subtitle})}
                ${bmWindowsApiHoverMarkup(slug, title, titleEn, year, isSeries ? 'series' : 'movie', genres)}
            </div>
            <div class="scroll-card-info">
                <div class="scroll-card-title-fa"><bdi dir="auto">${escapeHtml(title)}</bdi></div>
                <div class="scroll-card-meta" style="font-size:10px;color:#888;margin-top:2px">${isSeries?'سریال':'فیلم'}</div>
            </div>
        </a>`);
    }
    return cards;
}

function renderExtItems(items){ return renderExtItemsParts(items).join(''); }

// Skeleton loader برای آرشیو ۱
function extRenderSkeletons(containerId){
    const el = document.getElementById(containerId);
    if(!el) return;
    el.classList.add('bm-list-loading');
    el.classList.remove('bm-list-rendered');
    const count = (window.matchMedia && window.matchMedia('(max-width: 768px)').matches) ? 4 : 8;
    el.innerHTML = Array(count).fill(`<div class="scroll-card ext-skeleton-card" style="pointer-events:none">
        <div class="poster-wrap ext-skeleton-poster is-loading" style="aspect-ratio:2/3"></div>
        <div class="scroll-card-info ext-skeleton-info"><span></span><small></small></div>
    </div>`).join('');
}

// لود مرحله‌ای سکشن‌ها در موبایل؛ درخواست API فقط وقتی سکشن نزدیک viewport شد انجام می‌شود.
function bmLoadListNearViewport(containerId, loader, immediate=false){
    const el = document.getElementById(containerId);
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    const mobile = window.matchMedia && window.matchMedia('(max-width: 900px)').matches;
    if(mobile && !immediate) el.classList.add('bm-lazy-pending');
    const target = el.closest('.new-releases-section') || el;
    const run = () => {
        if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
        el.classList.remove('bm-lazy-pending');
        loader();
    };
    if(immediate || !mobile || !('IntersectionObserver' in window)){
        run();
        return;
    }
    if(el.__bmLazyObserved) return;
    el.__bmLazyObserved = true;
    const io = new IntersectionObserver((entries, obs)=>{
        for(const entry of entries){
            if(entry.isIntersecting){
                obs.disconnect();
                run();
                break;
            }
        }
    }, {rootMargin:'420px 0px', threshold:0.01});
    io.observe(target);
    // اگر مرورگر یا layout سکشن را دیر تشخیص داد، بعد از آرام شدن صفحه لود شود؛ نه همزمان با شروع صفحه.
    setTimeout(()=>{
        if(el.dataset.bmLoaded !== '1' && el.dataset.bmLoading !== '1'){
            try{ io.disconnect(); }catch(e){}
            run();
        }
    }, 20000);
}

// بارگذاری یک کتگوری در یک لیست مشخص
async function extLoadSection(containerId, cat, search=''){
    const el = document.getElementById(containerId);
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    el.dataset.bmLoading = '1';
    extRenderSkeletons(containerId);

    const url = search
        ? `api2.php?s=${encodeURIComponent(search)}&page=1`
        : (cat ? `api2.php?category=${encodeURIComponent(cat)}&page=1&limit=16` : `api2.php?page=1&limit=16`);

    try{
        if(extAbort) {} // don't abort section loads
        const ctrl = new AbortController();
        const res = await fetch(url, {signal: ctrl.signal});
        const data = await res.json();
        const items = data.movies || [];
        if(!items.length){
            el.dataset.bmLoaded = '1';
            el.innerHTML = `<div style="padding:20px;color:rgba(255,255,255,.3);font-size:12px">موردی یافت نشد</div>`;
            const section = el.closest('.new-releases-section');
            if(section) section.style.display='none';
            return;
        }
        bmSetCardsHTML(el, renderExtItemsParts(items), setupCardInteractions);
        el.dataset.bmLoaded = '1';
    }catch(e){
        el.innerHTML = `<div style="padding:20px;color:#f87;font-size:12px">خطا در بارگذاری</div>`;
    }finally{
        delete el.dataset.bmLoading;
    }
}

// بارگذاری فیلم‌های آپدیت شده (نوع movie)
async function extLoadUpdatedMovies(){
    const el = document.getElementById('extUpdatedMoviesList');
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    el.dataset.bmLoading = '1';
    extRenderSkeletons('extUpdatedMoviesList');
    try{
        const res = await fetch('api2.php?updates=movies&page=1&limit=24');
        const data = await res.json();
        const items = (data.movies||[]).filter(m => m.type !== 'series');
        if(!items.length){ el.dataset.bmLoaded='1'; el.closest('.new-releases-section').style.display='none'; return; }
        bmSetCardsHTML(el, renderExtItemsParts(items), setupCardInteractions);
        el.dataset.bmLoaded = '1';
    }catch(e){ el.innerHTML=''; el.closest('.new-releases-section').style.display='none'; }
    finally{ delete el.dataset.bmLoading; }
}

// بارگذاری سریال‌های آپدیت شده
async function extLoadUpdatedSeries(){
    const el = document.getElementById('extUpdatedSeriesList');
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    el.dataset.bmLoading = '1';
    extRenderSkeletons('extUpdatedSeriesList');
    try{
        const res = await fetch('api2.php?updates=series&page=1&limit=24');
        const data = await res.json();
        const items = (data.movies||[]).filter(m => m.type === 'series');
        if(!items.length){ el.dataset.bmLoaded='1'; el.closest('.new-releases-section').style.display='none'; return; }
        bmSetCardsHTML(el, renderExtItemsParts(items), setupCardInteractions);
        el.dataset.bmLoaded = '1';
    }catch(e){ el.innerHTML=''; el.closest('.new-releases-section').style.display='none'; }
    finally{ delete el.dataset.bmLoading; }
}

// نمایش همه آیتم‌های یک کتگوری (برای view all)
function extShowCategoryPage(cat){
    const wrap = document.getElementById('extSearchResultsWrap');
    const sections = document.getElementById('extScrollSections');
    const list = document.getElementById('extSearchResultsList');
    const title = document.getElementById('extSearchResultTitle');
    const catNames = {'turkish':'سریال‌های ترکی','korean':'سریال‌های کره‌ای','anime':'انیمه','coming-soon':'به‌زودی','top-movies':'برترین‌ها','dubbed-fa':'فیلم‌های دوبله فارسی','top-2026':'برترین فیلم‌های 2026'};

    if(wrap) wrap.style.display='block';
    if(sections) sections.style.display='none';
    if(title) title.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/></svg> ${catNames[cat]||cat}`;
    if(list) list.innerHTML='<div style="padding:30px;text-align:center"><div class="loading-spinner" style="width:30px;height:30px;margin:0 auto"></div></div>';

    (async () => {
        try{
            const res = await fetch(`api2.php?category=${encodeURIComponent(cat)}&page=1`);
            const data = await res.json();
            const items = data.movies || [];
            if(list) list.innerHTML = items.length ? renderExtItems(items) : '<div style="padding:20px;text-align:center;color:rgba(255,255,255,.3)">موردی یافت نشد</div>';
        }catch(e){
            if(list) list.innerHTML='<div style="padding:20px;color:#f87">خطا</div>';
        }
    })();
}


// ===== Archive 3 helpers =====
function arc3DetailId(item){
    if(!item) return '';
    if(item.detail_id) return String(item.detail_id);
    if(item.source_post_id) return 'p'+String(item.source_post_id);
    return item.slug || item.id || item.imdb_code || '';
}
function arc3MovieUrl(item){ const id = arc3DetailId(item); return id ? `/movie/arc3-${encodeURIComponent(id)}` : (item && item.url ? item.url : '#'); }

function renderArc3ItemsParts(items){
    let cards = [];
    for(const item of (items||[])){
        const title = (item.title_fa || item.title || '').trim();
        const subTitle = (item.title && item.title_fa && item.title !== item.title_fa) ? item.title : '';
        const year = item.year || '';
        const rate = parseFloat(item.rating||0);
        const rateStr = rate > 0 ? enNumbers(rate.toFixed(1)) : '';
        const poster = item.poster || '';
        const type = item.type || 'movie';
        const mediaKind = item.media_kind || '';
        const isSeries = type === 'series';
        const isAnimation = mediaKind === 'animation';
        const isAnime = mediaKind === 'anime' || type === 'anime';
        const label = isAnimation ? 'انیمیشن' : (isAnime ? 'انیمه' : (isSeries ? 'سریال' : 'فیلم'));
        let updateText = String(item.status_text || item.status || '').trim();
        updateText = updateText.replace(/^دانلود\s+.+?\s*:\s*/u, '').trim();
        const metaText = ((isSeries || isAnime || isAnimation) && updateText) ? updateText : subTitle;
        const detailLink = arc3MovieUrl(item);
        const titleEn = bmApiEnglishTitle(item, title) || subTitle;
        const genres = bmApiGenresValue(item);
        cards.push(`<a href="${escapeHtml(detailLink)}" class="scroll-card movie-card" data-bm-api-archive="3">
            <div class="poster-wrap">
                <span class="year-badge">${enNumbers(year||'?')}</span>
                ${poster ? `<img class="scroll-card-poster bm-poster-img" src="${escapeHtml(poster)}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1" onerror="this.src='${DEFAULT_POSTER}'">` : `<img class="scroll-card-poster bm-poster-img" src="${DEFAULT_POSTER}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1">`}
                ${rateStr ? `<span class="imdb-card-badge">${imdbLogoSvg()}<b>${rateStr}</b></span>` : ''}
                ${mediaPosterBadges({hasDub:item.has_dubbed, hasSub:item.has_subtitle})}
                ${bmWindowsApiHoverMarkup(arc3DetailId(item), title, titleEn, year, isSeries ? 'series' : 'movie', genres)}
            </div>
            <div class="scroll-card-info">
                <div class="scroll-card-title-fa"><bdi dir="auto">${escapeHtml(title)}</bdi></div>
                <div class="scroll-card-meta" style="font-size:10px;color:#888;margin-top:2px">${label}${metaText ? ' · '+escapeHtml(metaText) : ''}</div>
            </div>
        </a>`);
    }
    return cards;
}

function renderArc3Items(items){ return renderArc3ItemsParts(items).join(''); }

async function arc3LoadSection(containerId, section){
    const el = document.getElementById(containerId);
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    el.dataset.bmLoading = '1';
    extRenderSkeletons(containerId);
    try{
        const res = await fetch(`api6.php?section=${encodeURIComponent(section)}&page=1`);
        const data = await res.json();
        const items = data.movies || [];
        if(!items.length){ el.dataset.bmLoaded='1'; const sec = el.closest('.new-releases-section'); if(sec) sec.style.display='none'; return; }
        bmSetCardsHTML(el, renderArc3ItemsParts(items), setupCardInteractions);
        el.dataset.bmLoaded = '1';
    }catch(e){ el.innerHTML=''; const sec = el.closest('.new-releases-section'); if(sec) sec.style.display='none'; }
    finally{ delete el.dataset.bmLoading; }
}

function arc3LoadHomeSections(){
    bmLoadListNearViewport('arc3NewSeriesList', ()=>arc3LoadSection('arc3NewSeriesList','new_series'), true);
    bmLoadListNearViewport('arc3NewMoviesList', ()=>arc3LoadSection('arc3NewMoviesList','new_movies'));
    bmLoadListNearViewport('arc3UpdatedAnimationsList', ()=>arc3LoadSection('arc3UpdatedAnimationsList','updated_animations'));
    bmLoadListNearViewport('arc3UpdatedAnimeList', ()=>arc3LoadSection('arc3UpdatedAnimeList','updated_anime'));
}

async function arc3SearchQuery(term){
    const wrap = document.getElementById('arc3SearchResultsWrap');
    const list = document.getElementById('arc3SearchResultsList');
    const sections = document.getElementById('arc3ScrollSections');
    const title = document.getElementById('arc3SearchResultTitle');
    const uniResults = document.getElementById('unifiedSearchResults');
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(title) title.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> نتایج آرشیو ۳: ${escapeHtml(term)}`;
    if(list) list.innerHTML='';
    if(arc3Abort) arc3Abort.abort();
    arc3Abort = new AbortController();
    try{
        const res = await fetch(`api6.php?s=${encodeURIComponent(term)}&page=1`, {signal: arc3Abort.signal});
        const data = await res.json();
        const items = data.movies || [];
        if(uniResults){
            if(items.length){
                let html='';
                const liveLimit = 20;
                const liveItems = items.slice(0, liveLimit);
                const hasMoreLiveResults = items.length >= liveLimit || data.has_more || data.next_page;
                const viewAllUrl = `/view_all?type=arc3_search&q=${encodeURIComponent(term)}`;
                for(const item of liveItems){
                    const title2 = (item.title_fa || item.title || '').trim();
                    const poster = item.poster || '';
                    const link = arc3MovieUrl(item);
                    const type = item.media_kind === 'animation' ? 'انیمیشن' : (item.type === 'series' ? 'سریال' : ((item.media_kind === 'anime' || item.type === 'anime') ? 'انیمه' : 'فیلم'));
                    const rateStr = parseFloat(item.rating||0) > 0 ? enNumbers(parseFloat(item.rating).toFixed(1)) : '';
                    html += `<div class="search-result-item" data-url="${escapeHtml(link)}" style="cursor:pointer">
                        <img class="search-result-poster" src="${escapeHtml(poster)}" onerror="this.src='${DEFAULT_POSTER}'" loading="lazy">
                        <div class="search-result-info">
                            <div class="search-result-title"><bdi dir="auto">${escapeHtml(title2)}</bdi></div>
                            <div class="search-result-original">${type}${item.has_online?' · پخش آنلاین':''}</div>
                            <div class="search-result-meta"><span>${enNumbers(item.year||'?')}</span>${rateStr ? imdbMeta(rateStr) : ''}<span class="search-result-badge">آرشیو ۳</span></div>
                        </div>
                    </div>`;
                }
                if(hasMoreLiveResults){
                    html += `<a href="${escapeHtml(viewAllUrl)}" class="search-result-viewall" style="display:flex;align-items:center;justify-content:center;gap:8px;margin:8px 10px 10px;padding:11px 12px;border-radius:16px;background:rgba(var(--accent-rgb),.14);border:1px solid rgba(var(--accent-rgb),.35);color:var(--accent);font-size:12px;font-weight:900;text-decoration:none">مشاهده همه نتایج<span style="font-weight:650;color:rgba(255,255,255,.55)">بقیه نتایج رفت تو این</span></a>`;
                }
                uniResults.innerHTML = html;
                uniResults.classList.add('active');
                uniResults.querySelectorAll('.search-result-item').forEach(item => item.addEventListener('click', () => window.location.href = item.dataset.url));
            } else {
                uniResults.innerHTML = `<div class="empty-search-state" style="padding:20px;text-align:center">${userLang==='fa'?'نتیجه‌ای در آرشیو ۳ یافت نشد':'No results'}</div>`;
                uniResults.classList.add('active');
            }
        }
    }catch(e){ if(e.name !== 'AbortError' && uniResults) uniResults.innerHTML=`<div style="padding:20px;color:#f87">خطا در ارتباط با سرور</div>`; }
}

function arc3ClearSearch(){
    const wrap = document.getElementById('arc3SearchResultsWrap');
    const sections = document.getElementById('arc3ScrollSections');
    const uniResults = document.getElementById('unifiedSearchResults');
    const inp = document.getElementById('unifiedSearchInput');
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(uniResults) uniResults.classList.remove('active');
    if(inp) inp.value='';
}


function arc4DetailId(item){
    if(!item) return '';
    if(item.detail_id) return String(item.detail_id);
    if(item.source_post_id) return 'p'+String(item.source_post_id);
    return item.slug || item.id || item.imdb_code || '';
}
function arc4MovieUrl(item){ const id = arc4DetailId(item); return id ? `/movie/arc4-${encodeURIComponent(id)}` : (item && item.url ? item.url : '#'); }

function renderArc4ItemsParts(items){
    let cards = [];
    for(const item of (items||[])){
        const title = (item.title_fa || item.title || '').trim();
        const subTitle = (item.title && item.title_fa && item.title !== item.title_fa) ? item.title : '';
        const year = item.year || '';
        const rate = parseFloat(item.rating||0);
        const rateStr = rate > 0 ? enNumbers(rate.toFixed(1)) : '';
        const poster = item.poster || '';
        const type = item.type || 'movie';
        const mediaKind = item.media_kind || '';
        const isSeries = type === 'series';
        const isAnimation = mediaKind === 'animation';
        const isAnime = mediaKind === 'anime' || type === 'anime';
        const label = isAnimation ? 'انیمیشن' : (isAnime ? 'انیمه' : (isSeries ? 'سریال' : 'فیلم'));
        let updateText = String(item.status_text || item.status || '').trim();
        updateText = updateText.replace(/^دانلود\s+.+?\s*:\s*/u, '').trim();
        const metaText = ((isSeries || isAnime || isAnimation) && updateText) ? updateText : subTitle;
        const detailLink = arc4MovieUrl(item);
        const titleEn = bmApiEnglishTitle(item, title) || subTitle;
        const genres = bmApiGenresValue(item);
        cards.push(`<a href="${escapeHtml(detailLink)}" class="scroll-card movie-card" data-bm-api-archive="4">
            <div class="poster-wrap">
                <span class="year-badge">${enNumbers(year||'?')}</span>
                ${poster ? `<img class="scroll-card-poster bm-poster-img" src="${escapeHtml(poster)}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1" onerror="this.src='${DEFAULT_POSTER}'">` : `<img class="scroll-card-poster bm-poster-img" src="${DEFAULT_POSTER}" loading="lazy" decoding="async" width="240" height="360" style="opacity:1">`}
                ${rateStr ? `<span class="imdb-card-badge">${imdbLogoSvg()}<b>${rateStr}</b></span>` : ''}
                ${mediaPosterBadges({hasDub:item.has_dubbed, hasSub:item.has_subtitle})}
                ${bmWindowsApiHoverMarkup(arc4DetailId(item), title, titleEn, year, isSeries ? 'series' : 'movie', genres)}
            </div>
            <div class="scroll-card-info">
                <div class="scroll-card-title-fa"><bdi dir="auto">${escapeHtml(title)}</bdi></div>
                <div class="scroll-card-meta" style="font-size:10px;color:#888;margin-top:2px">${label}${metaText ? ' · '+escapeHtml(metaText) : ''}</div>
            </div>
        </a>`);
    }
    return cards;
}

function renderArc4Items(items){ return renderArc4ItemsParts(items).join(''); }

async function arc4LoadSection(containerId, section){
    const el = document.getElementById(containerId);
    if(!el) return;
    if(el.dataset.bmLoaded === '1' || el.dataset.bmLoading === '1') return;
    el.dataset.bmLoading = '1';
    extRenderSkeletons(containerId);
    try{
        const res = await fetch(`api4.php?section=${encodeURIComponent(section)}&page=1`);
        const data = await res.json();
        const items = data.movies || [];
        if(!items.length){ el.dataset.bmLoaded='1'; const sec = el.closest('.new-releases-section'); if(sec) sec.style.display='none'; return; }
        bmSetCardsHTML(el, renderArc4ItemsParts(items), setupCardInteractions);
        el.dataset.bmLoaded = '1';
    }catch(e){ el.innerHTML=''; const sec = el.closest('.new-releases-section'); if(sec) sec.style.display='none'; }
    finally{ delete el.dataset.bmLoading; }
}

function arc4LoadHomeSections(){
    bmLoadListNearViewport('arc4NewSeriesList', ()=>arc4LoadSection('arc4NewSeriesList','new_series'), true);
    bmLoadListNearViewport('arc4NewMoviesList', ()=>arc4LoadSection('arc4NewMoviesList','new_movies'));
    bmLoadListNearViewport('arc4UpdatedAnimationsList', ()=>arc4LoadSection('arc4UpdatedAnimationsList','updated_animations'));
    bmLoadListNearViewport('arc4UpdatedAnimeList', ()=>arc4LoadSection('arc4UpdatedAnimeList','updated_anime'));
}

async function arc4SearchQuery(term){
    const wrap = document.getElementById('arc4SearchResultsWrap');
    const list = document.getElementById('arc4SearchResultsList');
    const sections = document.getElementById('arc4ScrollSections');
    const title = document.getElementById('arc4SearchResultTitle');
    const uniResults = document.getElementById('unifiedSearchResults');
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(title) title.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg> نتایج آرشیو ۴: ${escapeHtml(term)}`;
    if(list) list.innerHTML='';
    if(arc4Abort) arc4Abort.abort();
    arc4Abort = new AbortController();
    try{
        const res = await fetch(`api4.php?s=${encodeURIComponent(term)}&page=1`, {signal: arc4Abort.signal});
        const data = await res.json();
        const items = data.movies || [];
        if(uniResults){
            if(items.length){
                let html='';
                const liveLimit = 20;
                const liveItems = items.slice(0, liveLimit);
                const hasMoreLiveResults = items.length >= liveLimit || data.has_more || data.next_page;
                const viewAllUrl = `/view_all?type=arc4_search&q=${encodeURIComponent(term)}`;
                for(const item of liveItems){
                    const title2 = (item.title_fa || item.title || '').trim();
                    const poster = item.poster || '';
                    const link = arc4MovieUrl(item);
                    const type = item.media_kind === 'animation' ? 'انیمیشن' : (item.type === 'series' ? 'سریال' : ((item.media_kind === 'anime' || item.type === 'anime') ? 'انیمه' : 'فیلم'));
                    const rateStr = parseFloat(item.rating||0) > 0 ? enNumbers(parseFloat(item.rating).toFixed(1)) : '';
                    html += `<div class="search-result-item" data-url="${escapeHtml(link)}" style="cursor:pointer">
                        <img class="search-result-poster" src="${escapeHtml(poster)}" onerror="this.src='${DEFAULT_POSTER}'" loading="lazy">
                        <div class="search-result-info">
                            <div class="search-result-title"><bdi dir="auto">${escapeHtml(title2)}</bdi></div>
                            <div class="search-result-original">${type}${item.has_online?' · پخش آنلاین':''}</div>
                            <div class="search-result-meta"><span>${enNumbers(item.year||'?')}</span>${rateStr ? imdbMeta(rateStr) : ''}<span class="search-result-badge">آرشیو ۴</span></div>
                        </div>
                    </div>`;
                }
                if(hasMoreLiveResults){
                    html += `<a href="${escapeHtml(viewAllUrl)}" class="search-result-viewall" style="display:flex;align-items:center;justify-content:center;gap:8px;margin:8px 10px 10px;padding:11px 12px;border-radius:16px;background:rgba(var(--accent-rgb),.14);border:1px solid rgba(var(--accent-rgb),.35);color:var(--accent);font-size:12px;font-weight:900;text-decoration:none">مشاهده همه نتایج<span style="font-weight:650;color:rgba(255,255,255,.55)">بقیه نتایج رفت تو این</span></a>`;
                }
                uniResults.innerHTML = html;
                uniResults.classList.add('active');
                uniResults.querySelectorAll('.search-result-item').forEach(item => item.addEventListener('click', () => window.location.href = item.dataset.url));
            } else {
                uniResults.innerHTML = `<div class="empty-search-state" style="padding:20px;text-align:center">${userLang==='fa'?'نتیجه‌ای در آرشیو ۴ یافت نشد':'No results'}</div>`;
                uniResults.classList.add('active');
            }
        }
    }catch(e){ if(e.name !== 'AbortError' && uniResults) uniResults.innerHTML=`<div style="padding:20px;color:#f87">خطا در ارتباط با سرور</div>`; }
}

function arc4ClearSearch(){
    const wrap = document.getElementById('arc4SearchResultsWrap');
    const sections = document.getElementById('arc4ScrollSections');
    const uniResults = document.getElementById('unifiedSearchResults');
    const inp = document.getElementById('unifiedSearchInput');
    if(wrap) wrap.style.display='none';
    if(sections) sections.style.display='block';
    if(uniResults) uniResults.classList.remove('active');
    if(inp) inp.value='';
}




function initSrcSwitcher(){
    const tabLocal = document.getElementById('arcTabLocal');
    const tabExt   = document.getElementById('arcTabExt');
    const tabArc3  = document.getElementById('arcTabArc3');
    const tabArc4  = document.getElementById('arcTabArc4');
    const tabDb    = document.getElementById('arcTabDb');
    const pill     = document.getElementById('arcPill');
    const hint     = document.getElementById('arcHint');
    const homePage = document.getElementById('homePage');
    const extPageEl= document.getElementById('extPage');
    const arc3PageEl= document.getElementById('arc3Page');
    const arc4PageEl= document.getElementById('arc4Page');
    const genresSec = document.getElementById('genresSection');
    const countriesSec = document.getElementById('countriesSection');
    const filterBar = document.querySelector('.filter-bar');
    if(!pill) return;

    function movePill(mode){
        const tab = mode === 'db' ? tabDb : (mode === 'arc4' ? tabArc4 : (mode === 'arc3' ? tabArc3 : (mode === 'local' ? tabLocal : tabExt)));
        const sw  = document.getElementById('arcSwitch');
        if(!sw||!tab) return;
        const swRect  = sw.getBoundingClientRect();
        const tabRect = tab.getBoundingClientRect();
        pill.style.left  = (tabRect.left - swRect.left - 5) + 'px';
        pill.style.width = tabRect.width + 'px';
    }
    requestAnimationFrame(() => movePill(activeArchive));
    window.addEventListener('resize', () => movePill(activeArchive));

    function archiveConfigForMode(mode){ return ARCHIVE_CONTROL[ARC_MODE_TO_ID[mode] || ''] || null; }
    function archiveIsDisabled(mode){ const cfg = archiveConfigForMode(mode); return cfg && cfg.enabled === false; }
    function archiveDisabledMessage(mode){ const cfg = archiveConfigForMode(mode); return (cfg && cfg.disabled_message) ? cfg.disabled_message : 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.'; }
    function showArchiveUnavailable(mode){
        const msg = archiveDisabledMessage(mode);
        if(hint) hint.textContent = msg;
        if(typeof showToast === 'function') showToast(msg); else alert(msg);
    }

    function switchArchive(mode){
        if(archiveIsDisabled(mode)){ showArchiveUnavailable(mode); return; }
        activeArchive = mode;
        bmSetArchiveModeAttr(mode);
        if(!['local','db'].includes(mode)) bmClearLocalHomeForExternal();
        extIsActive = mode === 'arc1';
        arc3IsActive = mode === 'arc3';
        arc4IsActive = mode === 'arc4';
        const isExternal = !['local','db'].includes(mode);
        if(tabLocal) tabLocal.classList.toggle('arc-tab-active', mode === 'local');
        if(tabExt) tabExt.classList.toggle('arc-tab-active', mode === 'arc1');
        if(tabArc3) tabArc3.classList.toggle('arc-tab-active', mode === 'arc3');
        if(tabArc4) tabArc4.classList.toggle('arc-tab-active', mode === 'arc4');
        if(tabDb)tabDb.classList.toggle('arc-tab-active',mode==='db');
        movePill(mode);
        if(hint) hint.textContent = ARC_HINTS[mode] || '';
        // Archive choice is intentionally not persisted; index returns to Archive 1 on next visit.

        // The public API5 Archive 2 must not expose legacy MySQL filter/genre/country controls.
        // Those controls belong exclusively to the admin-only Database Archive.
        const showDbControls = mode === 'db';
        if(genresSec) genresSec.style.display = showDbControls ? '' : 'none';
        if(countriesSec) countriesSec.style.display = showDbControls ? '' : 'none';
        if(filterBar) filterBar.style.display = showDbControls ? '' : 'none';

        const uniInp = document.getElementById('unifiedSearchInput');
        if(uniInp) uniInp.placeholder = mode === 'arc4'
            ? (userLang==='fa'?'جستجو در آرشیو ۴...':'Search Archive 4...')
            : (mode === 'arc3'
                ? (userLang==='fa'?'جستجو در آرشیو ۳...':'Search Archive 3...')
                : (mode === 'arc1'
                    ? (userLang==='fa'?'جستجو در آرشیو ۱...':'Search Archive 1...')
                    : (mode === 'db'
                        ? (userLang==='fa'?'جستجو در آرشیو دیتابیس...':'Search database archive...')
                        : (userLang==='fa'?'جستجو در API5 / SerialBlog...':'Search API5 / SerialBlog...'))));

        if(mode === 'arc1'){
            if(homePage) homePage.style.display = 'none';
            if(arc3PageEl){ arc3PageEl.style.opacity = '0'; arc3PageEl.style.display = 'none'; }
            if(arc4PageEl){ arc4PageEl.style.opacity = '0'; arc4PageEl.style.display = 'none'; }
            if(extPageEl){ extPageEl.style.display = 'block'; requestAnimationFrame(() => { extPageEl.style.opacity = '1'; }); }
            bmLoadListNearViewport('extUpdatedMoviesList', extLoadUpdatedMovies, true);
            bmLoadListNearViewport('extUpdatedSeriesList', extLoadUpdatedSeries);
            bmLoadListNearViewport('extTop2026List', ()=>extLoadSection('extTop2026List','top-2026'));
            bmLoadListNearViewport('extDubbedFaList', ()=>extLoadSection('extDubbedFaList','dubbed-fa'));
            bmLoadListNearViewport('extTurkishList', ()=>extLoadSection('extTurkishList','turkish'));
            bmLoadListNearViewport('extKoreanList', ()=>extLoadSection('extKoreanList','korean'));
            bmLoadListNearViewport('extAnimeList', ()=>extLoadSection('extAnimeList','anime'));
        } else if(mode === 'arc3'){
            if(homePage) homePage.style.display = 'none';
            if(extPageEl){ extPageEl.style.opacity = '0'; extPageEl.style.display = 'none'; }
            if(arc4PageEl){ arc4PageEl.style.opacity = '0'; arc4PageEl.style.display = 'none'; }
            if(arc3PageEl){ arc3PageEl.style.display = 'block'; requestAnimationFrame(() => { arc3PageEl.style.opacity = '1'; }); }
            arc3LoadHomeSections();
        } else if(mode === 'arc4'){
            if(homePage) homePage.style.display = 'none';
            if(extPageEl){ extPageEl.style.opacity = '0'; extPageEl.style.display = 'none'; }
            if(arc3PageEl){ arc3PageEl.style.opacity = '0'; arc3PageEl.style.display = 'none'; }
            if(arc4PageEl){ arc4PageEl.style.display = 'block'; requestAnimationFrame(() => { arc4PageEl.style.opacity = '1'; }); }
            arc4LoadHomeSections();
        } else {
            if(extPageEl){ extPageEl.style.opacity = '0'; setTimeout(() => { if(['local','db'].includes(activeArchive)) extPageEl.style.display = 'none'; }, 220); }
            if(arc3PageEl){ arc3PageEl.style.opacity = '0'; setTimeout(() => { if(['local','db'].includes(activeArchive)) arc3PageEl.style.display = 'none'; }, 220); }
            if(arc4PageEl){ arc4PageEl.style.opacity = '0'; setTimeout(() => { if(['local','db'].includes(activeArchive)) arc4PageEl.style.display = 'none'; }, 220); }
            if(homePage) homePage.style.display = 'block';
            bmEnsureLocalHomeLoaded(mode);
            extClearSearch();
            arc3ClearSearch();
            arc4ClearSearch();
        }
    }

    window.switchArchive = switchArchive;
    window.switchTo = function(toExt){ switchArchive(toExt ? 'arc1' : 'local'); };
    if(tabLocal) tabLocal.addEventListener('click', () => switchArchive('local'));
    if(tabExt) tabExt.addEventListener('click', () => switchArchive('arc1'));
    if(tabArc3) tabArc3.addEventListener('click', () => switchArchive('arc3'));
    if(tabArc4) tabArc4.addEventListener('click', () => switchArchive('arc4'));
    if(tabDb)tabDb.addEventListener('click',()=>switchArchive('db'));

    switchArchive(activeArchive);
}


(function(){
    const openBtn = document.getElementById('archiveGuideBtn');
    const modal = document.getElementById('archiveGuideModal');
    const closeBtn = document.getElementById('archiveGuideClose');
    const guideVideo = modal ? modal.querySelector('.archive-guide-video') : null;
    if(!openBtn || !modal) return;
    const open = () => { modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); };
    const close = () => {
        modal.classList.remove('open');
        modal.setAttribute('aria-hidden','true');
        if(guideVideo && !guideVideo.paused) guideVideo.pause();
    };
    openBtn.addEventListener('click', open);
    closeBtn && closeBtn.addEventListener('click', close);
    modal.addEventListener('click', e => { if(e.target === modal) close(); });
    document.addEventListener('keydown', e => { if(e.key === 'Escape' && modal.classList.contains('open')) close(); });
})();


document.addEventListener('DOMContentLoaded',function(){
    bmSetArchiveModeAttr(activeArchive);
    if(['local','db'].includes(activeArchive)) bmEnsureLocalHomeLoaded(activeArchive);
    else bmClearLocalHomeForExternal();
    initStories();
    initStorySwipe();
    initSrcSwitcher();
    // sync extSearchInput with unifiedSearchInput
    const uniInp = document.getElementById('unifiedSearchInput');
    const extInp = document.getElementById('extSearchInput');
    if(uniInp && extInp){
        uniInp.addEventListener('input', () => { if(extIsActive) extInp.value = uniInp.value; });
    }
    setupMenu();
    setupHeaderScroll();
    setupSmartBottomNav();
    
    document.getElementById('storyCloseBtn')?.addEventListener('click',closeStoryModal);
    document.getElementById('storyPrevBtn')?.addEventListener('click',prevStory);
    document.getElementById('storyNextBtn')?.addEventListener('click',nextStory);
    document.getElementById('storyModal')?.addEventListener('click',(e)=>{if(e.target===document.getElementById('storyModal'))closeStoryModal();});
    
    document.querySelectorAll('.type-btn').forEach(btn=>{
        btn.onclick=function(){document.querySelectorAll('.type-btn').forEach(b=>b.classList.remove('active'));this.classList.add('active');filterType=this.dataset.type;bmStartTypeSectionTransition();if(activeArchive==='db') loadMovies(true);};
    });
    document.getElementById('randomBtn')?.addEventListener('click',()=>{if(activeArchive==='db' && allMovies.length){let rand=Math.floor(Math.random()*allMovies.length);window.location.href=bmMovieUrl(allMovies[rand]);}});
    
    document.querySelector('.view-all-newreleases')?.addEventListener('click',()=>window.location.href='/view_all?type=arc2_section&kind=movies_2025_2026');
    document.querySelector('.view-all-topmovies')?.addEventListener('click',()=>window.location.href='/view_all?type=arc2_section&kind=new_movies');
    document.querySelector('.view-all-topseries')?.addEventListener('click',()=>window.location.href='/view_all?type=arc2_section&kind=new_series');
    document.getElementById('viewAllDubbedBtn')?.addEventListener('click',()=>window.location.href='/view_all?type=arc2_section&kind=dubbed');
    document.getElementById('viewAllAdminPicksBtn')?.addEventListener('click',()=>window.location.href='/view_all?type=arc2_section&kind=home');
    
    let donateBtn=document.getElementById('donateModalBtn'),donateModal=document.getElementById('donateModal');
    if(donateBtn)donateBtn.onclick=()=>donateModal.style.display='flex';
    document.getElementById('closeDonateModal')?.addEventListener('click',()=>donateModal.style.display='none');
    document.getElementById('openDonateLink')?.addEventListener('click',()=>{window.open('https://daramet.com/manuel','_blank');donateModal.style.display='none';});
    if(donateModal)donateModal.addEventListener('click',(e)=>{if(e.target===donateModal)donateModal.style.display='none';});
    
    // Notification modal is handled by the small inline script next to the modal.
    hideLoading();
});
// v28: Footer typing/Manuel credit removed; no footer typing initialization needed.

window.BM_INDEX_BUILD='v82-api5-exact-sections';
