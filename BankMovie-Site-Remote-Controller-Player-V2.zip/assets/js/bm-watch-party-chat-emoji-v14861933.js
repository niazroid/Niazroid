(function(){
  'use strict';
  var EMOJIS = [
    '😂','😐','😭','❤️','😘','😁','👌','😊','😡','👍','😳','😔','😜','☺️','😍','😄','💋','🫪','😝','😒','😢','😅','😏','🙈','😱','😃','😉','🥸','😚','😀','😋','😌','😞','🤣','🙊','😕','🦶','😆','😇','🙀','😾','🤝','🕯','🥹','🥱','🤩','🥳','🥰','😎','🥶','🙄','🤤','👿','😈','😹','💩','🤡','🖕','👎','🤙','🫀','❣','🩷','🧡','💛','💚','🩵','💙','💜','🖤','🩶','🤍','🤎','❤️‍🔥','❤️‍🩹','💔','💕','💞','💓','💗','💖','💘','💝','💟','♥️','🎀','🎏','🧸','🧿','👑','💍','🤮','🤢','🫠','🫩','🤬'
  ];

  function ready(fn){ if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true}); else fn(); }
  function isCoarse(){ return Boolean((navigator.maxTouchPoints||0)>0 || window.matchMedia?.('(pointer: coarse)').matches); }
  function insertAtCursor(input,text){
    if(!input) return;
    var start=typeof input.selectionStart==='number'?input.selectionStart:input.value.length;
    var end=typeof input.selectionEnd==='number'?input.selectionEnd:start;
    var next=input.value.slice(0,start)+text+input.value.slice(end);
    if(next.length>500) next=next.slice(0,500);
    input.value=next;
    var pos=Math.min(next.length,start+text.length);
    try{input.setSelectionRange(pos,pos);}catch(_){ }
    input.dispatchEvent(new Event('input',{bubbles:true}));
  }

  ready(function(){
    var body=document.body;
    if(!body || !body.classList.contains('watch-party-page')) return;
    var panel=document.getElementById('playerChatPanel');
    var form=document.getElementById('chatForm');
    var input=document.getElementById('chatInput');
    if(!panel || !form || !input || document.getElementById('bmChatEmojiBtn')) return;

    /* Telegram-like unified composer: input + SVG smile live in one pill. */
    var composer=document.createElement('div');
    composer.className='bm-chat-composer';
    form.insertBefore(composer,input);
    composer.appendChild(input);

    var button=document.createElement('button');
    button.id='bmChatEmojiBtn';
    button.className='bm-chat-emoji-btn';
    button.type='button';
    button.setAttribute('aria-label','باز کردن ایموجی‌ها');
    button.setAttribute('aria-expanded','false');
    button.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M8.4 10h.01M15.6 10h.01"></path><path d="M8.5 14c.9 1.35 2.05 2 3.5 2s2.6-.65 3.5-2"></path></svg>';
    composer.appendChild(button);

    var picker=document.createElement('div');
    picker.id='bmChatEmojiPicker';
    picker.className='bm-chat-emoji-picker';
    picker.setAttribute('role','dialog');
    picker.setAttribute('aria-label','انتخاب ایموجی');

    var head=document.createElement('div');
    head.className='bm-chat-emoji-head';
    head.innerHTML='<strong>ایموجی‌ها</strong><span>'+EMOJIS.length+' ایموجی منتخب</span>';

    var grid=document.createElement('div');
    grid.className='bm-chat-emoji-grid';
    EMOJIS.forEach(function(emoji){
      var item=document.createElement('button');
      item.type='button';
      item.className='bm-chat-emoji-item';
      item.setAttribute('aria-label','ایموجی '+emoji);
      item.textContent=emoji;
      item.addEventListener('click',function(ev){
        ev.preventDefault();
        insertAtCursor(input,emoji);
        if(!isCoarse()){
          try{input.focus({preventScroll:true});}catch(_){input.focus();}
        }
      });
      grid.appendChild(item);
    });
    picker.append(head,grid);
    panel.appendChild(picker);

    function setOpen(open){
      picker.classList.toggle('open',!!open);
      button.setAttribute('aria-expanded',open?'true':'false');
    }
    button.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      setOpen(!picker.classList.contains('open'));
    });
    picker.addEventListener('click',function(ev){ev.stopPropagation();});
    document.addEventListener('pointerdown',function(ev){
      if(!picker.classList.contains('open')) return;
      if(!picker.contains(ev.target) && !composer.contains(ev.target)) setOpen(false);
    },{passive:true});
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')setOpen(false);});
    form.addEventListener('submit',function(){setOpen(false);});

    /* Recalculate after fullscreen/resize so the pack never detaches or overflows on Windows. */
    function refreshPack(){
      if(!picker.classList.contains('open')) return;
      picker.style.maxHeight='';
      requestAnimationFrame(function(){ picker.scrollTop=Math.min(picker.scrollTop,picker.scrollHeight); });
    }
    window.addEventListener('resize',refreshPack,{passive:true});
    window.visualViewport?.addEventListener('resize',refreshPack,{passive:true});
    document.addEventListener('fullscreenchange',refreshPack);
    document.addEventListener('webkitfullscreenchange',refreshPack);

    var activePanel=document.getElementById('playerChatPanel');
    function syncBackgroundKey(){
      var key=document.documentElement.getAttribute('data-bm-background')||'simple';
      if(activePanel) activePanel.setAttribute('data-room-background',key);
    }
    syncBackgroundKey();
    new MutationObserver(syncBackgroundKey).observe(document.documentElement,{attributes:true,attributeFilter:['data-bm-background']});
    window.addEventListener('bm:watch-party-background',syncBackgroundKey);
  });
})();
