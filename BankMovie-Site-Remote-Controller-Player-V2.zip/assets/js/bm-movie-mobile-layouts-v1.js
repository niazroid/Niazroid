/* BankMovie mobile movie layouts v1: intentionally tiny.
   CSS owns the layouts; this only keeps the admin-selected state stable after BFCache/resize. */
(function(){
  const body=document.body;
  if(!body||!body.classList.contains('movie-page')) return;
  const allowed=new Set(['classic','compact_card','minimal_rows','cinematic_modern','pro_compact','vertical_card','dashboard','premium_stack']);
  if(!allowed.has(body.dataset.bmMobileLayout||'')) body.dataset.bmMobileLayout='classic';
  const sync=()=>document.documentElement.classList.toggle('bm-movie-mobile-alt',window.matchMedia('(max-width:768px)').matches&&body.dataset.bmMobileLayout!=='classic');
  sync();
  window.addEventListener('pageshow',sync,{passive:true});
  window.addEventListener('resize',sync,{passive:true});
})();
