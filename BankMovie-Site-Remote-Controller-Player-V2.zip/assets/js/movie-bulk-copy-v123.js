/* BankMovie V131 — movie-aware labels, ADM guide zoom, app admin controls */
(() => {
  'use strict';

  const dataNode = document.getElementById('bmSeriesBulkData');
  const modal = document.getElementById('bmSeriesBulkModal');
  if (!dataNode || !modal) return;

  let catalog = {};
  try { catalog = JSON.parse(dataNode.textContent || '{}') || {}; } catch (_) { catalog = {}; }
  const serverCatalogHasLinks = Number(catalog?.link_count || 0) > 0 || Object.values(catalog?.seasons || {}).some(group => Array.isArray(group?.links) && group.links.length > 0);

  const $ = (sel, root = modal) => root.querySelector(sel);
  const $$ = (sel, root = modal) => Array.from(root.querySelectorAll(sel));
  const els = {
    title: $('[data-bm-bulk-title]'),
    seasonCount: $('[data-bm-stat-seasons]'),
    linkCount: $('[data-bm-stat-links]'),
    episodeCount: $('[data-bm-stat-episodes]'),
    seasons: $('[data-bm-season-tabs]'),
    qualities: $('[data-bm-quality-grid]'),
    types: $('[data-bm-type-filters]'),
    preview: $('[data-bm-preview]'),
    resultCount: $('[data-bm-result-count]'),
    format: $('[data-bm-copy-format]'),
    packageName: $('[data-bm-package-name]'),
    toast: $('[data-bm-bulk-toast]'),
    managerPanel: $('[data-bm-manager-panel]'),
    copyPanel: $('[data-bm-copy-panel]'),
    primaryLabel: $('[data-bm-primary-label]'),
    primaryIcon: $('[data-bm-primary-icon]'),
    guide: $('[data-bm-guide]'),
    subtitle: $('[data-bm-bulk-subtitle]'),
    seasonSection: $('[data-bm-season-section]'),
    seasonHeading: $('[data-bm-season-heading]'),
    seasonHelp: $('[data-bm-season-help]'),
    seasonStatWrap: $('[data-bm-stat-seasons-wrap]'),
    episodeStatWrap: $('[data-bm-stat-episodes-wrap]'),
    seasonStatLabel: $('[data-bm-stat-seasons-label]'),
    episodeStatLabel: $('[data-bm-stat-episodes-label]'),
    labeledOption: $('[data-bm-labeled-option]'),
  };

  const typeLabels = {
    all: 'همه نسخه‌ها', dub: 'دوبله', dubbed: 'دوبله', audio: 'صوت دوبله',
    soft: 'زیرنویس فارسی', softsub: 'سافت‌ساب', hardsub: 'هاردساب',
    subtitle: 'زیرنویس فارسی', original: 'زبان اصلی'
  };

  const esc = value => String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  const explicitContentType = String(document.body?.dataset?.bmContentType || '').toLowerCase();
  const bodySeriesFlag = explicitContentType ? explicitContentType === 'series' : document.body?.dataset?.bmSeriesPage === '1';
  const catalogSaysSeries = () => catalog?.is_series === true || catalog?.content_type === 'series';
  const pageHasEpisodicSignals = () => {
    if (document.querySelector('.arc1-season-tabs,[data-series-season],[data-season],[data-episode],.arc1-ep-num,.episode-card,.bm-arc2-series-downloads')) return true;
    return Array.from(document.querySelectorAll('#arc1DownloadSection,#downloadSection,.episodes-section')).some(node => /(?:فصل|قسمت|season|episode)\s*[۰-۹0-9]+/iu.test(node.textContent || ''));
  };
  const catalogHasEpisodes = () => {
    const groups = Object.values(catalog?.seasons || {});
    if (groups.length > 1) return true;
    return groups.some(group => (group?.links || []).some(link => Number(link?.episode || 0) > 0));
  };
  const isSeriesContent = () => {
    if (explicitContentType === 'movie') return false;
    const evidence = pageHasEpisodicSignals() || catalogHasEpisodes();
    if (explicitContentType === 'series') return evidence;
    return evidence && (catalogSaysSeries() || bodySeriesFlag);
  };
  const movieGroupLabel = () => catalog.lang === 'en' ? 'Movie links' : 'لینک‌های فیلم';
  const movieItemLabel = () => catalog.lang === 'en' ? 'Movie file' : 'نسخه فیلم';

  function normalizeQuality(value) {
    const text = String(value || '').trim();
    if (/2160|4k/i.test(text)) return '2160p';
    if (/1440/i.test(text)) return '1440p';
    if (/1080/i.test(text)) return '1080p';
    if (/720/i.test(text)) return '720p';
    if (/480/i.test(text)) return '480p';
    if (/360/i.test(text)) return '360p';
    return text || 'نامشخص';
  }

  function detectType(row, label) {
    const text = `${row?.textContent || ''} ${label || ''}`.toLowerCase();
    if (/دوبله|dubbed|\bdub\b/.test(text)) return 'dub';
    if (/هاردساب|hard\s*sub/.test(text)) return 'hardsub';
    if (/سافت\s*ساب|soft\s*sub/.test(text)) return 'softsub';
    if (/زبان\s*اصلی|original/.test(text)) return 'original';
    return 'subtitle';
  }

  function uniqueLinks(items) {
    const map = new Map();
    (items || []).forEach(item => {
      const url = String(item?.url || '').trim();
      if (/^https?:\/\//i.test(url) && !map.has(url)) map.set(url, {...item, url});
    });
    return Array.from(map.values());
  }

  function rebuildSeasonMeta(target) {
    const keys = Object.keys(target.seasons || {}).sort((a, b) => a.localeCompare(b, undefined, {numeric:true}));
    const ordered = {};
    let linkTotal = 0;
    keys.forEach(key => {
      const season = target.seasons[key];
      const links = uniqueLinks(season.links).sort((a, b) => Number(a.episode || 0) - Number(b.episode || 0));
      const qualities = {};
      const types = {};
      const episodes = new Set();
      links.forEach(link => {
        link.quality = normalizeQuality(link.quality || link.quality_original);
        link.type = String(link.type || 'subtitle').toLowerCase();
        link.type_label = link.type_label || typeLabels[link.type] || 'زیرنویس فارسی';
        qualities[link.quality] = (qualities[link.quality] || 0) + 1;
        types[link.type] = (types[link.type] || 0) + 1;
        if (Number(link.episode || 0) > 0) episodes.add(Number(link.episode));
      });
      season.links = links;
      season.qualities = qualities;
      season.types = types;
      season.episode_count = episodes.size;
      season.link_count = links.length;
      ordered[key] = season;
      linkTotal += links.length;
    });
    target.seasons = ordered;
    target.season_count = keys.length;
    target.link_count = linkTotal;
    target.content_type = explicitContentType || target.content_type || (target.is_series === true ? 'series' : (bodySeriesFlag ? 'series' : 'movie'));
    target.is_series = target.content_type === 'series';
    if (!target.is_series) {
      Object.values(target.seasons).forEach(group => {
        group.label = movieGroupLabel();
        group.episode_count = 0;
        group.links.forEach(link => {
          link.episode = 0;
          link.episode_label = movieItemLabel();
        });
      });
    }
    return target;
  }

  function deriveCatalogFromDom() {
    const generated = {
      title: catalog.title || document.querySelector('.movie-title,h1,.hero-title')?.textContent?.trim() || 'BankMovie',
      lang: catalog.lang || 'fa',
      content_type: isSeriesContent() ? 'series' : 'movie',
      is_series: isSeriesContent(),
      seasons: {}
    };
    const roots = Array.from(document.querySelectorAll(
      '#arc1DownloadSection, #downloadSection, .arc1-series-downloads, .bm-arc2-series-downloads, .episodes-section, [data-sp], [data-series-season]'
    ));
    const controls = [];
    roots.forEach(root => {
      root.querySelectorAll(
        'a[data-bm-download-only="1"][href], a.arc1-dl-btn[href], a.download-icon[href], a[href][download], a.button_online[href], a[data-download-url][href]'
      ).forEach(el => controls.push(el));
    });
    const seen = new Set();

    const textNumber = value => Number(String(value || '').replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/\D/g, '')) || 0;
    const findSeasonNumber = (control, row, card, label) => {
      const explicit = control.dataset.season || row?.dataset?.season || card?.dataset?.season;
      if (textNumber(explicit)) return Math.max(1, textNumber(explicit));
      const panel = control.closest('[id^="sp-"],[id^="arc2-sp-"],[data-sp]');
      const fromId = panel?.id?.match(/(?:sp-|S)(\d+)/i)?.[1];
      if (textNumber(fromId)) return Math.max(1, textNumber(fromId));
      const headerText = panel?.querySelector('.arc1-season-header')?.textContent || '';
      const fromHeader = headerText.match(/(?:فصل|season)\s*([۰-۹0-9]+)/i)?.[1];
      if (textNumber(fromHeader)) return Math.max(1, textNumber(fromHeader));
      const fromLabel = String(label || '').match(/(?:فصل|season|S)\s*[-:]?\s*([۰-۹0-9]+)/i)?.[1];
      return Math.max(1, textNumber(fromLabel) || 1);
    };
    const findEpisodeNumber = (control, row, card, label) => {
      const explicit = control.dataset.episode || row?.dataset?.episode || card?.dataset?.episode;
      if (textNumber(explicit)) return textNumber(explicit);
      const epText = card?.querySelector('.arc1-ep-num,.episode-number,.episode-title,[data-episode-label]')?.textContent || '';
      const fromCard = epText.match(/(?:قسمت|episode|E)\s*[-:]?\s*([۰-۹0-9]+)/i)?.[1];
      if (textNumber(fromCard)) return textNumber(fromCard);
      const fromLabel = String(label || '').match(/(?:قسمت|episode|E)\s*[-:]?\s*([۰-۹0-9]+)/i)?.[1];
      return textNumber(fromLabel);
    };

    controls.forEach(control => {
      if (control.matches('.arc1-sub-dl-btn,.arc4-subtitle-direct,[data-subtitle-only]')) return;
      const rawUrl = String(control.dataset.copyUrl || control.dataset.downloadUrl || control.getAttribute('href') || control.dataset.url || '').trim();
      if (!/^https?:\/\//i.test(rawUrl) || seen.has(rawUrl)) return;
      const row = control.closest('.arc1-link-row,.download-link,.premium-download-card,.download_item,.download-item,.episode-link,.link-row,.episode-download-row,[data-link-row]') || control.parentElement;
      const card = control.closest('.arc1-ep-card,.episode-card,[data-episode],[data-sp],[data-series-season],.episode-item') || row;
      const label = String(control.dataset.label || row?.textContent || card?.textContent || '').replace(/\s+/g, ' ').trim();
      const seasonNumber = findSeasonNumber(control, row, card, label);
      const episodeNumber = findEpisodeNumber(control, row, card, label);
      // Ignore generic page links that are not episode/download controls.
      if (!control.dataset.url && !control.hasAttribute('download') && !control.matches('.arc1-dl-btn,.download-icon,.button_online,[data-download-url]')) return;
      seen.add(rawUrl);
      const seasonKey = `S${String(seasonNumber).padStart(2, '0')}`;
      const qualityText = control.dataset.quality || row?.querySelector('.quality,.bm-archive2-quality-halo,.arc1-link-meta>div>div:first-child,[data-quality],.download-quality')?.textContent?.trim() || label;
      const quality = normalizeQuality(qualityText);
      const type = detectType(row, label);
      const size = row?.querySelector('.size,.bm-size-value,[data-size],.download-size')?.textContent?.trim() || '';
      const seriesMode = generated.is_series === true;
      if (!generated.seasons[seasonKey]) generated.seasons[seasonKey] = {number: seasonNumber, label: seriesMode ? `فصل ${seasonNumber}` : movieGroupLabel(), links: []};
      generated.seasons[seasonKey].links.push({
        episode: seriesMode ? episodeNumber : 0,
        episode_label: seriesMode ? (episodeNumber > 0 ? `قسمت ${episodeNumber}` : 'فصل کامل') : movieItemLabel(),
        quality,
        quality_original: quality,
        type,
        type_label: typeLabels[type] || 'زیرنویس فارسی',
        size,
        url: rawUrl
      });
    });
    return rebuildSeasonMeta(generated);
  }

  function ensureVisibleTrigger() {
    if (document.querySelector('[data-bm-bulk-copy-open]')) return;
    const titleCandidates = Array.from(document.querySelectorAll(
      '#arc1DownloadSection .section-title, #downloadSection .section-title, .download-section .section-title, .episodes-section .section-title, [data-episodes-title]'
    ));
    const title = titleCandidates.find(node => /قسمت|فصل|episode|season/i.test(node.textContent || '')) || titleCandidates[0] || null;
    const serverSaysSeries = document.body?.dataset?.bmSeriesPage === '1';
    const episodicDom = document.querySelector(
      '#arc1DownloadSection [data-sp], #arc1DownloadSection .arc1-season-tabs, #arc1DownloadSection .arc1-ep-num, #downloadSection [data-season], #downloadSection .episode-card, .bm-arc2-series-downloads, [data-series-season]'
    );
    const episodicText = Array.from(document.querySelectorAll('#arc1DownloadSection .arc1-ep-num, #downloadSection .episode-title, .episodes-section .section-title'))
      .some(node => /قسمت|فصل|episode|season/i.test(node.textContent || ''));
    if (!title || (!serverSaysSeries && !episodicDom && !episodicText)) return;
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'bm-bulk-copy-open bm-bulk-copy-open--inline is-pending';
    button.dataset.bmBulkCopyOpen = '';
    button.setAttribute('aria-haspopup', 'dialog');
    button.setAttribute('aria-controls', 'bmSeriesBulkModal');
    button.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg><span>همه لینک‌ها</span><small>کپی یا ADM/IDM</small>';
    title.appendChild(button);
  }

  catalog = (catalog.seasons && Object.keys(catalog.seasons).length) ? rebuildSeasonMeta(catalog) : deriveCatalogFromDom();

  let seasonKeys = Object.keys(catalog.seasons || {});
  let selectedSeason = seasonKeys[0] || '';
  let selectedQuality = 'all';
  let selectedType = 'all';
  let selectedScope = 'selected';
  let selectedOutputMode = 'copy';
  let packageNameTouched = false;
  let lastFocus = null;
  let toastTimer = null;

  const currentSeason = () => catalog.seasons?.[selectedSeason] || {links: [], qualities: {}, types: {}, link_count: 0};

  function filteredLinks({allQualities = false, allTypes = false, seasonKey = selectedSeason} = {}) {
    const season = catalog.seasons?.[seasonKey] || {links: []};
    return uniqueLinks((season.links || []).filter(link => {
      const qualityOk = allQualities || selectedQuality === 'all' || link.quality === selectedQuality;
      const typeOk = allTypes || selectedType === 'all' || link.type === selectedType;
      return qualityOk && typeOk;
    }));
  }

  function allSeriesLinks() {
    return uniqueLinks(seasonKeys.flatMap(key => (catalog.seasons?.[key]?.links || []).map(link => ({...link, seasonKey:key}))));
  }

  function scopeLinks() {
    if (selectedScope === 'series') return allSeriesLinks();
    if (selectedScope === 'season') return filteredLinks({allQualities:true, allTypes:true});
    return filteredLinks();
  }

  function showToast(text) {
    if (!els.toast) return;
    els.toast.textContent = text;
    els.toast.classList.add('is-show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('is-show'), 2500);
  }

  async function copyText(text, successText = 'لینک‌ها کپی شدند') {
    if (!String(text || '').trim()) { showToast('لینکی برای کپی وجود ندارد'); return false; }
    try {
      if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
      else {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.setAttribute('readonly', '');
        ta.style.cssText = 'position:fixed;opacity:0;pointer-events:none;inset:auto';
        document.body.appendChild(ta);
        ta.select();
        if (!document.execCommand('copy')) throw new Error('copy failed');
        ta.remove();
      }
      showToast(successText);
      return true;
    } catch (_) {
      showToast('کپی خودکار نشد؛ دوباره تلاش کن');
      return false;
    }
  }

  function buildCopyText(links, scope = selectedScope) {
    const format = els.format?.value || 'urls';
    if (format === 'urls') return links.map(item => item.url).join('\n');
    const lines = [catalog.title || 'BankMovie'];
    if (!isSeriesContent()) {
      const q = selectedQuality === 'all' ? 'همه کیفیت‌ها' : selectedQuality;
      const t = selectedType === 'all' ? 'همه نسخه‌ها' : (typeLabels[selectedType] || selectedType);
      lines.push(`${movieGroupLabel()} | ${q} | ${t}`);
    } else if (scope === 'series') lines.push('همه فصل‌ها و کیفیت‌ها');
    else {
      const season = currentSeason();
      const q = scope === 'season' || selectedQuality === 'all' ? 'همه کیفیت‌ها' : selectedQuality;
      const t = scope === 'season' || selectedType === 'all' ? 'همه نسخه‌ها' : (typeLabels[selectedType] || selectedType);
      lines.push(`${season.label || selectedSeason} | ${q} | ${t}`);
    }
    lines.push('');
    let previousSeason = '';
    links.forEach((item, index) => {
      if (scope === 'series' && item.seasonKey !== previousSeason) {
        if (previousSeason) lines.push('');
        lines.push(`===== ${catalog.seasons?.[item.seasonKey]?.label || item.seasonKey} =====`);
        previousSeason = item.seasonKey;
      }
      const episode = item.episode_label || (isSeriesContent() ? (item.episode ? `قسمت ${item.episode}` : 'فصل کامل') : movieItemLabel());
      lines.push(`${episode} — ${item.quality_original || item.quality}${item.type_label ? ` — ${item.type_label}` : ''}`);
      lines.push(item.url);
      if (index !== links.length - 1) lines.push('');
    });
    return lines.join('\n');
  }

  function managerText(links) {
    return uniqueLinks(links).map(item => item.url).join('\r\n') + '\r\n';
  }

  function safeFileName(value) {
    return String(value || 'BankMovie-download-group')
      .replace(/[<>:"/\\|?*\u0000-\u001F]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 110) || 'BankMovie-download-group';
  }

  function asciiFileToken(value, fallback = '') {
    const token = String(value || '')
      .normalize('NFKD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-zA-Z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 42);
    return token || fallback;
  }

  function managerDownloadName() {
    const isAndroid = /Android/i.test(navigator.userAgent || '');
    if (!isAndroid) return safeFileName(els.packageName?.value || defaultPackageName());
    const title = asciiFileToken(catalog.title, 'BankMovie');
    const parts = [title, 'ADM'];
    if (!isSeriesContent()) {
      parts.push('MOVIE');
      if (selectedQuality !== 'all') parts.push(asciiFileToken(selectedQuality, 'Q'));
      if (selectedType !== 'all') parts.push(asciiFileToken(selectedType, 'TYPE'));
    } else if (selectedScope === 'series') {
      parts.push('ALL');
    } else {
      parts.push(`S${asciiFileToken(selectedSeason, '01')}`);
      if (selectedScope === 'selected' && selectedQuality !== 'all') parts.push(asciiFileToken(selectedQuality, 'Q'));
      if (selectedScope === 'selected' && selectedType !== 'all') parts.push(asciiFileToken(selectedType, 'TYPE'));
    }
    return safeFileName(parts.filter(Boolean).join('-'));
  }

  function scopeLabel() {
    if (!isSeriesContent()) {
      const bits = [movieGroupLabel()];
      if (selectedQuality !== 'all') bits.push(selectedQuality);
      if (selectedType !== 'all') bits.push(typeLabels[selectedType] || selectedType);
      return bits.join(' - ');
    }
    if (selectedScope === 'series') return 'همه فصل‌ها';
    if (selectedScope === 'season') return currentSeason().label || selectedSeason || 'فصل';
    const bits = [currentSeason().label || selectedSeason || 'فصل'];
    if (selectedQuality !== 'all') bits.push(selectedQuality);
    if (selectedType !== 'all') bits.push(typeLabels[selectedType] || selectedType);
    return bits.join(' - ');
  }

  function defaultPackageName() {
    return safeFileName(`${catalog.title || 'BankMovie'} - ${scopeLabel()}`);
  }

  function syncPackageName(force = false) {
    if (!els.packageName || (packageNameTouched && !force)) return;
    els.packageName.value = defaultPackageName();
  }

  function downloadManagerFile() {
    const links = scopeLinks();
    if (!links.length) { showToast('برای این گروه لینکی وجود ندارد'); return; }
    const text = managerText(links);
    const blob = new Blob([text], {type:'text/plain;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    const name = managerDownloadName();
    anchor.href = url;
    anchor.download = `${name}.txt`;
    anchor.style.display = 'none';
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    showToast(/Android/i.test(navigator.userAgent || '') ? `فایل ${name}.txt ساخته شد؛ برای ADM حالت کپی عادی و Paste راحت‌تر است` : `فایل ${name}.txt با ${links.length} لینک برای IDM ساخته شد`);
  }

  function renderSeasons() {
    if (els.seasonSection) els.seasonSection.hidden = !isSeriesContent();
    if (!seasonKeys.length) {
      els.seasons.innerHTML = '<div class="bm-bulk-empty">هنوز لینک قابل استفاده از این صفحه شناسایی نشده است.</div>';
      return;
    }
    els.seasons.innerHTML = seasonKeys.map(key => {
      const season = catalog.seasons[key];
      return `<button type="button" class="bm-bulk-season ${key === selectedSeason ? 'is-active' : ''}" data-season="${esc(key)}"><b>${esc(season.label)}</b><span>${season.episode_count || 0} قسمت · ${season.link_count || 0} لینک</span></button>`;
    }).join('');
  }

  function renderQualities() {
    const season = currentSeason();
    const items = seasonKeys.length ? [['all', season.link_count || 0], ...Object.entries(season.qualities || {})] : [];
    if (selectedQuality !== 'all' && !Object.prototype.hasOwnProperty.call(season.qualities || {}, selectedQuality)) selectedQuality = 'all';
    els.qualities.innerHTML = items.length ? items.map(([quality, count]) => `<button type="button" class="bm-bulk-quality ${quality === selectedQuality ? 'is-active' : ''}" data-quality="${esc(quality)}"><b>${quality === 'all' ? 'همه' : esc(quality)}</b><span>${count}</span></button>`).join('') : '<div class="bm-bulk-empty">کیفیتی وجود ندارد.</div>';
  }

  function renderTypes() {
    const season = currentSeason();
    const entries = seasonKeys.length ? [['all', season.link_count || 0], ...Object.entries(season.types || {})] : [];
    if (selectedType !== 'all' && !Object.prototype.hasOwnProperty.call(season.types || {}, selectedType)) selectedType = 'all';
    els.types.innerHTML = entries.length ? entries.map(([type, count]) => `<button type="button" class="bm-bulk-filter ${type === selectedType ? 'is-active' : ''}" data-type="${esc(type)}">${esc(typeLabels[type] || type)} <span>${count}</span></button>`).join('') : '<div class="bm-bulk-empty">نسخه‌ای وجود ندارد.</div>';
  }

  function renderScope() {
    if (!isSeriesContent() && selectedScope !== 'selected') selectedScope = 'selected';
    $$('[data-bm-scope]').forEach(button => {
      const scope = button.dataset.bmScope;
      button.hidden = !isSeriesContent() && scope !== 'selected';
      button.classList.toggle('is-active', scope === selectedScope);
    });
  }

  function renderOutputMode() {
    $$('[data-bm-output-mode]').forEach(button => {
      const active = button.dataset.bmOutputMode === selectedOutputMode;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-checked', active ? 'true' : 'false');
    });
    if (els.managerPanel) els.managerPanel.hidden = selectedOutputMode !== 'manager';
    if (els.copyPanel) els.copyPanel.hidden = selectedOutputMode !== 'copy';
    if (els.primaryLabel) els.primaryLabel.textContent = selectedOutputMode === 'manager' ? 'دریافت فایل TXT برای IDM' : 'کپی لینک‌ها';
    if (els.primaryIcon) {
      els.primaryIcon.innerHTML = selectedOutputMode === 'manager'
        ? '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M5 19h14"/>'
        : '<rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>';
      els.primaryIcon.dataset.bmPrimaryIcon = selectedOutputMode;
    }
  }

  function updateActionState() {
    const count = scopeLinks().length;
    $$('.bm-bulk-btn[data-bm-bulk-action]').forEach(button => {
      button.disabled = count === 0;
      button.setAttribute('aria-disabled', count === 0 ? 'true' : 'false');
    });
  }

  function renderPreview() {
    const links = filteredLinks();
    const scopeCount = scopeLinks().length;
    const resultGroup = !isSeriesContent() ? 'این فیلم' : (selectedScope === 'selected' ? 'انتخابی' : selectedScope === 'season' ? 'این فصل' : 'کل سریال');
    els.resultCount.innerHTML = `<b>${scopeCount}</b> لینک در گروه ${resultGroup}`;
    updateActionState();
    if (!links.length) {
      els.preview.innerHTML = '<div class="bm-bulk-empty">برای این ترکیب لینکی وجود ندارد.</div>';
      return;
    }
    const limit = 8;
    const rows = links.slice(0, limit).map((item, index) => `<div class="bm-bulk-row"><span class="bm-bulk-row-ep">${esc(item.episode_label)}</span><span class="bm-bulk-row-quality">${esc(item.quality)}</span><span class="bm-bulk-row-type">${esc(item.type_label)}${item.size ? ` · ${esc(item.size)}` : ''}</span><button type="button" class="bm-bulk-row-copy" data-copy-row="${index}" aria-label="کپی همین لینک"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg></button></div>`);
    if (links.length > limit) rows.push(`<div class="bm-bulk-more">+ ${links.length - limit} لینک دیگر در ${selectedOutputMode === 'manager' ? 'فایل گروه' : 'خروجی کپی'} قرار می‌گیرد</div>`);
    els.preview.innerHTML = rows.join('');
  }

  function renderAll() {
    seasonKeys = Object.keys(catalog.seasons || {});
    if (!selectedSeason || !catalog.seasons?.[selectedSeason]) selectedSeason = seasonKeys[0] || '';
    renderSeasons();
    renderQualities();
    renderTypes();
    renderScope();
    renderOutputMode();
    renderPreview();
    const seriesMode = isSeriesContent();
    const totalEpisodes = seriesMode ? seasonKeys.reduce((sum, key) => sum + Number(catalog.seasons[key]?.episode_count || 0), 0) : 0;
    els.title.textContent = catalog.title || (seriesMode ? 'مدیریت لینک‌های دانلود سریال' : 'مدیریت لینک‌های دانلود فیلم');
    if (els.subtitle) els.subtitle.textContent = seriesMode ? 'فصل، کیفیت و نسخه را انتخاب کن؛ سپس کپی یا خروجی IDM بگیر.' : 'کیفیت و نسخه فیلم را انتخاب کن؛ سپس لینک‌ها را کپی یا برای IDM خروجی بگیر.';
    if (els.seasonStatWrap) els.seasonStatWrap.hidden = !seriesMode;
    if (els.episodeStatWrap) els.episodeStatWrap.hidden = !seriesMode;
    if (els.seasonStatLabel) els.seasonStatLabel.textContent = 'فصل';
    if (els.episodeStatLabel) els.episodeStatLabel.textContent = 'قسمت';
    if (els.seasonHeading) els.seasonHeading.textContent = seriesMode ? 'فصل' : 'فیلم';
    if (els.seasonHelp) els.seasonHelp.textContent = seriesMode ? 'هر فصل جدا مدیریت می‌شود' : 'تمام کیفیت‌های همین فیلم';
    if (els.labeledOption) els.labeledOption.textContent = seriesMode ? 'عنوان قسمت + لینک' : 'عنوان نسخه + لینک';
    els.seasonCount.textContent = seriesMode ? (catalog.season_count || seasonKeys.length) : 0;
    els.linkCount.textContent = catalog.link_count || 0;
    els.episodeCount.textContent = totalEpisodes;
    syncPackageName();
  }

  function refreshCatalogFromPage() {
    // The PHP catalog is canonical. DOM scanning is fallback-only for truly dynamic pages.
    // This prevents Play + Download controls for the same file from becoming duplicate DL10 tokens.
    if (serverCatalogHasLinks) return;
    const derived = deriveCatalogFromDom();
    if (Number(derived.link_count || 0) > 0) catalog = derived;
  }

  function openGuide() {
    if (!els.guide) return;
    els.guide.hidden = false;
    els.guide.setAttribute('aria-hidden', 'false');
    modal.classList.add('is-guide-open');
    requestAnimationFrame(() => $('[data-bm-guide-close]')?.focus());
  }

  function closeGuide() {
    if (!els.guide) return;
    els.guide.hidden = true;
    els.guide.setAttribute('aria-hidden', 'true');
    modal.classList.remove('is-guide-open');
    requestAnimationFrame(() => $('[data-bm-guide-open]')?.focus());
  }

  function switchGuideTab(name) {
    $$('[data-bm-guide-tab]').forEach(button => button.classList.toggle('is-active', button.dataset.bmGuideTab === name));
    $$('[data-bm-guide-panel]').forEach(panel => panel.classList.toggle('is-active', panel.dataset.bmGuidePanel === name));
  }


  let guideLightbox = null;
  let guideLightboxImage = null;
  let guideZoomScale = 1;
  let guideZoomX = 0;
  let guideZoomY = 0;
  let guideDrag = null;

  function canUseGuideZoom() {
    return !!(window.matchMedia && window.matchMedia('(min-width: 760px) and (hover: hover) and (pointer: fine)').matches);
  }

  function applyGuideZoom() {
    if (!guideLightboxImage) return;
    guideLightboxImage.style.transform = `translate3d(${guideZoomX}px,${guideZoomY}px,0) scale(${guideZoomScale})`;
    const label = guideLightbox?.querySelector('[data-bm-guide-zoom-value]');
    if (label) label.textContent = `${Math.round(guideZoomScale * 100)}٪`;
    guideLightbox?.classList.toggle('is-zoomed', guideZoomScale > 1.01);
  }

  function resetGuideZoom() {
    guideZoomScale = 1;
    guideZoomX = 0;
    guideZoomY = 0;
    applyGuideZoom();
  }

  function ensureGuideLightbox() {
    if (guideLightbox) return guideLightbox;
    const shell = document.createElement('div');
    shell.className = 'bm-guide-lightbox';
    shell.hidden = true;
    shell.setAttribute('aria-hidden', 'true');
    shell.innerHTML = `
      <div class="bm-guide-lightbox-backdrop" data-bm-guide-lightbox-close></div>
      <section class="bm-guide-lightbox-card" role="dialog" aria-modal="true" aria-label="بزرگ‌نمایی تصویر آموزش">
        <div class="bm-guide-lightbox-toolbar">
          <button type="button" data-bm-guide-zoom-action="out" aria-label="کوچک‌نمایی">−</button>
          <span data-bm-guide-zoom-value>۱۰۰٪</span>
          <button type="button" data-bm-guide-zoom-action="in" aria-label="بزرگ‌نمایی">+</button>
          <button type="button" data-bm-guide-zoom-action="reset">اندازه اصلی</button>
          <button type="button" class="bm-guide-lightbox-close" data-bm-guide-lightbox-close aria-label="بستن">×</button>
        </div>
        <div class="bm-guide-lightbox-stage">
          <img alt="" draggable="false">
        </div>
        <small>با چرخ ماوس زوم کن؛ بعد از بزرگ‌نمایی تصویر را بکش.</small>
      </section>`;
    document.body.appendChild(shell);
    guideLightbox = shell;
    guideLightboxImage = shell.querySelector('img');
    const stage = shell.querySelector('.bm-guide-lightbox-stage');

    shell.addEventListener('click', event => {
      if (event.target.closest('[data-bm-guide-lightbox-close]')) {
        closeGuideLightbox();
        return;
      }
      const action = event.target.closest('[data-bm-guide-zoom-action]')?.dataset.bmGuideZoomAction;
      if (!action) return;
      if (action === 'in') guideZoomScale = Math.min(4, guideZoomScale + .25);
      if (action === 'out') guideZoomScale = Math.max(.75, guideZoomScale - .25);
      if (action === 'reset') resetGuideZoom();
      applyGuideZoom();
    });

    stage?.addEventListener('wheel', event => {
      event.preventDefault();
      const next = guideZoomScale + (event.deltaY < 0 ? .18 : -.18);
      guideZoomScale = Math.max(.75, Math.min(4, next));
      applyGuideZoom();
    }, {passive:false});

    stage?.addEventListener('pointerdown', event => {
      if (guideZoomScale <= 1.01) return;
      guideDrag = {id:event.pointerId, x:event.clientX, y:event.clientY, ox:guideZoomX, oy:guideZoomY};
      stage.setPointerCapture?.(event.pointerId);
      stage.classList.add('is-dragging');
    });
    stage?.addEventListener('pointermove', event => {
      if (!guideDrag || guideDrag.id !== event.pointerId) return;
      guideZoomX = guideDrag.ox + (event.clientX - guideDrag.x);
      guideZoomY = guideDrag.oy + (event.clientY - guideDrag.y);
      applyGuideZoom();
    });
    const stopDrag = event => {
      if (!guideDrag || (event.pointerId != null && guideDrag.id !== event.pointerId)) return;
      guideDrag = null;
      stage?.classList.remove('is-dragging');
    };
    stage?.addEventListener('pointerup', stopDrag);
    stage?.addEventListener('pointercancel', stopDrag);
    return shell;
  }

  function openGuideLightbox(sourceImage) {
    if (!canUseGuideZoom() || !sourceImage) return;
    const shell = ensureGuideLightbox();
    guideLightboxImage.src = sourceImage.currentSrc || sourceImage.src;
    guideLightboxImage.alt = sourceImage.alt || 'تصویر آموزش';
    resetGuideZoom();
    shell.hidden = false;
    shell.setAttribute('aria-hidden', 'false');
    document.documentElement.classList.add('bm-guide-lightbox-open');
    requestAnimationFrame(() => shell.classList.add('is-open'));
  }

  function closeGuideLightbox() {
    if (!guideLightbox || guideLightbox.hidden) return;
    guideLightbox.classList.remove('is-open');
    document.documentElement.classList.remove('bm-guide-lightbox-open');
    setTimeout(() => {
      if (!guideLightbox) return;
      guideLightbox.hidden = true;
      guideLightbox.setAttribute('aria-hidden', 'true');
      if (guideLightboxImage) guideLightboxImage.removeAttribute('src');
    }, 160);
  }

  function openModal(trigger) {
    lastFocus = trigger || document.activeElement;
    ensureVisibleTrigger();
    refreshCatalogFromPage();
    packageNameTouched = false;
    selectedOutputMode = 'copy';
    selectedScope = 'selected';
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    modal.classList.remove('is-closing');
    document.documentElement.style.overflow = 'hidden';
    renderAll();
    requestAnimationFrame(() => $('.bm-bulk-close')?.focus());
  }

  function closeModal() {
    if (modal.hidden || modal.classList.contains('is-closing')) return;
    modal.classList.add('is-closing');
    setTimeout(() => {
      modal.hidden = true;
      modal.setAttribute('aria-hidden', 'true');
      modal.classList.remove('is-closing');
      document.documentElement.style.overflow = '';
      if (lastFocus && typeof lastFocus.focus === 'function') lastFocus.focus();
    }, 160);
  }

  document.addEventListener('click', event => {
    const guideImage = event.target.closest('.bm-guide-real-shot img');
    if (guideImage && modal.contains(guideImage) && canUseGuideZoom()) {
      event.preventDefault();
      openGuideLightbox(guideImage);
      return;
    }
    const open = event.target.closest('[data-bm-bulk-copy-open]');
    if (open) { event.preventDefault(); openModal(open); return; }
    if (event.target.closest('[data-bm-bulk-close]') || event.target.classList.contains('bm-bulk-backdrop')) { closeModal(); return; }
    if (event.target.closest('[data-bm-guide-open]')) { openGuide(); return; }
    if (event.target.closest('[data-bm-guide-close]')) { closeGuide(); return; }
    const guideTab = event.target.closest('[data-bm-guide-tab]');
    if (guideTab && modal.contains(guideTab)) { switchGuideTab(guideTab.dataset.bmGuideTab || 'idm'); return; }

    const seasonButton = event.target.closest('[data-season]');
    if (seasonButton && modal.contains(seasonButton)) {
      selectedSeason = seasonButton.dataset.season;
      selectedQuality = 'all';
      selectedType = 'all';
      packageNameTouched = false;
      renderAll();
      return;
    }
    const qualityButton = event.target.closest('[data-quality]');
    if (qualityButton && modal.contains(qualityButton)) {
      selectedQuality = qualityButton.dataset.quality;
      selectedScope = 'selected';
      packageNameTouched = false;
      renderQualities(); renderScope(); renderPreview(); syncPackageName(true);
      return;
    }
    const typeButton = event.target.closest('[data-type]');
    if (typeButton && modal.contains(typeButton)) {
      selectedType = typeButton.dataset.type;
      selectedScope = 'selected';
      packageNameTouched = false;
      renderTypes(); renderScope(); renderPreview(); syncPackageName(true);
      return;
    }
    const outputModeButton = event.target.closest('[data-bm-output-mode]');
    if (outputModeButton && modal.contains(outputModeButton)) {
      selectedOutputMode = outputModeButton.dataset.bmOutputMode === 'manager' ? 'manager' : 'copy';
      packageNameTouched = false;
      renderOutputMode();
      renderPreview();
      syncPackageName(true);
      return;
    }
    const scopeButton = event.target.closest('[data-bm-scope]');
    if (scopeButton && modal.contains(scopeButton)) {
      selectedScope = scopeButton.dataset.bmScope;
      packageNameTouched = false;
      renderScope(); renderPreview(); syncPackageName(true);
      return;
    }
    const rowButton = event.target.closest('[data-copy-row]');
    if (rowButton && modal.contains(rowButton)) {
      const link = filteredLinks()[Number(rowButton.dataset.copyRow)];
      if (link) copyText(link.url, 'لینک همین قسمت کپی شد');
      return;
    }
    const action = event.target.closest('[data-bm-bulk-action]');
    if (!action || !modal.contains(action) || action.disabled) return;
    const links = scopeLinks();
    if (action.dataset.bmBulkAction === 'run-mode') {
      if (selectedOutputMode === 'manager') downloadManagerFile();
      else copyText(buildCopyText(links), `${links.length} لینک کپی شد`);
    }
  });

  els.format?.addEventListener('change', renderPreview);
  els.packageName?.addEventListener('input', () => { packageNameTouched = true; });

  document.addEventListener('keydown', event => {
    if (modal.hidden) return;
    if (event.key === 'Escape') { if (els.guide && !els.guide.hidden) closeGuide(); else closeModal(); return; }
    if (event.key !== 'Tab') return;
    const focusable = $$('.bm-bulk-dialog button:not([disabled]), .bm-bulk-dialog input:not([disabled]), .bm-bulk-dialog select:not([disabled]), .bm-bulk-dialog [href], .bm-bulk-dialog [tabindex]:not([tabindex="-1"])').filter(el => el.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0], last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  ensureVisibleTrigger();
  renderAll();
  // External archive episode blocks may arrive after the first paint.
  const apiObserver = new MutationObserver(() => {
    ensureVisibleTrigger();
    if (!modal.hidden) refreshCatalogFromPage();
  });
  apiObserver.observe(document.body, {childList:true, subtree:true});
  setTimeout(() => apiObserver.disconnect(), 15000);

  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && guideLightbox && !guideLightbox.hidden) {
      event.preventDefault();
      closeGuideLightbox();
    }
  });
})();
