(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  ready(function(){
    var header = document.getElementById('siteHeader');
    var hero = document.querySelector('.hero-slider');
    if(!header || !hero || !document.body.classList.contains('has-hero')) return;

    var mq = window.matchMedia ? window.matchMedia('(max-width: 991.98px)') : {matches: window.innerWidth < 992};
    var rafId = 0;

    function getThreshold(){
      var heroTop = hero.offsetTop || 0;
      var heroHeight = hero.offsetHeight || 0;
      var headerHeight = header.offsetHeight || 0;
      return Math.max(0, heroTop + heroHeight - headerHeight - 18);
    }

    function applyState(){
      rafId = 0;
      if(!mq.matches){
        header.classList.remove('is-home-hero-transparent');
        return;
      }
      var scrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      if(scrollY <= getThreshold()) header.classList.add('is-home-hero-transparent');
      else header.classList.remove('is-home-hero-transparent');
    }

    function requestApply(){
      if(rafId) return;
      rafId = window.requestAnimationFrame(applyState);
    }

    applyState();
    window.addEventListener('scroll', requestApply, {passive:true});
    window.addEventListener('resize', requestApply, {passive:true});
    window.addEventListener('orientationchange', requestApply, {passive:true});
    window.addEventListener('load', requestApply, {once:true});
    if(mq.addEventListener) mq.addEventListener('change', requestApply);
    else if(mq.addListener) mq.addListener(requestApply);
  });
})();
