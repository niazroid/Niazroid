(function(){
  'use strict';
  function cfg(){ return (window.BM_SITE_UI && window.BM_SITE_UI.appMiniBanner) || {}; }
  function cleanText(v,fallback){ v=String(v==null?'':v).trim(); return v || fallback; }
  function apply(banner){
    if(!banner) return;
    var c=cfg();
    if(c.enabled!==true){
      banner.remove();
      if(document.body) document.body.classList.remove('has-bm-app-mini-banner');
      return;
    }
    var title=banner.querySelector('.bm-app-mini-text strong');
    var subtitle=banner.querySelector('.bm-app-mini-text span');
    var label=banner.querySelector('.bm-app-mini-cta span');
    if(title) title.textContent=cleanText(c.title,'اپلیکیشن بانک مووی منتشر شد');
    if(subtitle) subtitle.textContent=cleanText(c.subtitle,'نسخه اندروید فیلم و سریال');
    if(label) label.textContent=cleanText(c.buttonLabel,'نصب');
    banner.setAttribute('aria-label', cleanText(c.title,'دانلود اپلیکیشن بانک مووی'));
    var button=banner.querySelector('.bm-app-mini-cta');
    if(button){
      var url=String(c.buttonUrl||'').trim();
      button.dataset.bmAdminUrl=url;
      if(!button.dataset.bmAdminUrlBound){
        button.dataset.bmAdminUrlBound='1';
        button.addEventListener('click',function(e){
          var href=String(button.dataset.bmAdminUrl||'').trim();
          if(!href) return;
          e.preventDefault(); e.stopImmediatePropagation();
          window.location.href=href;
        },true);
      }
    }
  }
  function scan(){
    var c=cfg();
    var banner=document.getElementById('bmAppMiniBanner') || document.querySelector('.bm-app-mini-banner');
    if(c.enabled!==true){
      if(banner) banner.remove();
      if(document.body) document.body.classList.remove('has-bm-app-mini-banner');
      return;
    }
    if(banner) apply(banner);
  }
  function start(){
    scan();
    var root=document.body || document.documentElement;
    if(!root) return;
    var observer=new MutationObserver(function(mutations){
      for(var i=0;i<mutations.length;i++){
        if(mutations[i].addedNodes && mutations[i].addedNodes.length){ scan(); break; }
      }
    });
    observer.observe(root,{childList:true,subtree:true});
    window.setTimeout(scan,250);
    window.setTimeout(scan,900);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
