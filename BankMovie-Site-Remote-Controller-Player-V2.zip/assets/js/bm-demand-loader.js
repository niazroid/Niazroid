/* BankMovie interaction-demand loader v91
 * Heavy home/search code is fetched only after an explicit visitor interaction.
 */
(function(){
  'use strict';
  const loaded = Object.create(null);
  let homePromise = null;
  let quickPromise = null;

  function loadScript(src){
    if(!src) return Promise.resolve();
    if(loaded[src]) return loaded[src];
    loaded[src] = new Promise(function(resolve,reject){
      const node = document.createElement('script');
      node.src = src;
      node.async = false;
      node.dataset.bmDemand = '1';
      node.onload = resolve;
      node.onerror = reject;
      document.body.appendChild(node);
    });
    return loaded[src];
  }

  function loadHomeCore(){
    if(homePromise) return homePromise;
    document.documentElement.classList.add('bm-home-core-loading');
    homePromise = loadScript('/assets/js/bm-home-api-cache.js?v=cache90')
      .then(function(){ return loadScript('/assets/js/index-main.js?v=demand91'); })
      .then(function(){
        document.documentElement.classList.remove('bm-home-core-loading');
        document.documentElement.classList.add('bm-home-core-ready');
      })
      .catch(function(error){
        document.documentElement.classList.remove('bm-home-core-loading');
        console.error('BankMovie home bundle failed to load', error);
        throw error;
      });
    return homePromise;
  }

  function loadQuickSearch(){
    if(quickPromise) return quickPromise;
    quickPromise = loadHomeCore()
      .then(function(){ return loadScript('/assets/js/bm-quick-search.js?v=keyboard91'); })
      .then(function(){ document.documentElement.classList.add('bm-quick-search-ready'); });
    return quickPromise;
  }

  function isQuickTrigger(target){
    return !!(target && target.closest && target.closest('#bmHeaderQuickSearchBtn,#bmHomeQuickSearchBtn,#bmHomeSearchInput,#bmHomeSearchPoda'));
  }

  function isHomeControl(target){
    return !!(target && target.closest && target.closest(
      '#menuBtn,#closeMenuBtn,#menuOverlay,#notifBell,#closeNotifSidebar,' +
      '.archive-tab,.type-btn,#randomBtn,#loadMoreBtn,.story-item,#storyCloseBtn,#storyPrevBtn,#storyNextBtn,' +
      '.hero-arrow,.hero-dot,#archiveGuideBtn,#archiveGuideClose,#donateModalBtn,#closeDonateModal,#openDonateLink'
    ));
  }

  document.addEventListener('click', function(event){
    const target = event.target;
    if(isQuickTrigger(target) && !window.bmQuickSearchOpen){
      event.preventDefault();
      event.stopImmediatePropagation();
      loadQuickSearch().then(function(){
        if(typeof window.bmQuickSearchOpen === 'function') window.bmQuickSearchOpen();
        else window.location.href = '/search';
      }).catch(function(){ window.location.href = '/search'; });
      return;
    }
    if(isHomeControl(target) && !window.__BM_HOME_PAGE_INITIALIZED__){
      const replayTarget = target.closest('button,a,[role="button"],.archive-tab,.story-item') || target;
      const isLink = replayTarget && replayTarget.tagName === 'A' && replayTarget.getAttribute('href') && !replayTarget.getAttribute('href').startsWith('#');
      if(!isLink){
        event.preventDefault();
        event.stopImmediatePropagation();
      }
      loadHomeCore().then(function(){
        if(!isLink && replayTarget && document.contains(replayTarget)){
          replayTarget.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
        }
      }).catch(function(){});
    }
  }, true);

  document.addEventListener('focusin', function(event){
    if(isQuickTrigger(event.target) && !window.bmQuickSearchOpen){
      loadQuickSearch().then(function(){ if(typeof window.bmQuickSearchOpen === 'function') window.bmQuickSearchOpen(); }).catch(function(){});
    }
  }, true);

  window.BM_LOAD_HOME_CORE = loadHomeCore;
  window.BM_LOAD_QUICK_SEARCH = loadQuickSearch;
})();
