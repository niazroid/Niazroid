/* BankMovie Premium UI v140 — behavior-neutral polish */
(function(){
  'use strict';

  var ticking = false;
  function updateHeaderState(){
    document.body.classList.toggle('bm-header-scrolled', window.scrollY > 24);
    ticking = false;
  }
  window.addEventListener('scroll', function(){
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(updateHeaderState);
    }
  }, {passive:true});
  updateHeaderState();

  function markStoryMedia(node){
    if (!node || !node.closest) return;
    var avatar = node.closest('.story-avatar');
    if (avatar) avatar.classList.add('bm-media-failed');
  }

  function inspectStoryMedia(root){
    (root || document).querySelectorAll('.story-avatar img').forEach(function(img){
      if (img.dataset.bmUiBound === '1') return;
      img.dataset.bmUiBound = '1';
      img.addEventListener('error', function(){ markStoryMedia(img); }, {once:true});
      if (img.complete && img.naturalWidth === 0) markStoryMedia(img);
    });
    (root || document).querySelectorAll('.story-avatar video').forEach(function(video){
      if (video.dataset.bmUiBound === '1') return;
      video.dataset.bmUiBound = '1';
      video.addEventListener('error', function(){
        var avatar = video.closest('.story-avatar');
        var usableImage = avatar && avatar.querySelector('img:not([hidden])');
        if (!usableImage) markStoryMedia(video);
      }, {once:true});
    });
  }

  function improveEpisodeAccessibility(root){
    (root || document).querySelectorAll('.arc1-ep-head').forEach(function(head){
      if (head.dataset.bmUiA11y === '1') return;
      head.dataset.bmUiA11y = '1';
      head.setAttribute('role','button');
      head.setAttribute('tabindex','0');
      var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
      head.addEventListener('keydown', function(event){
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          head.click();
          window.setTimeout(function(){
            var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
          }, 0);
        }
      });
      head.addEventListener('click', function(){
        window.setTimeout(function(){
          var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
        }, 0);
      });
    });
  }

  function hydrate(root){
    inspectStoryMedia(root);
    improveEpisodeAccessibility(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ hydrate(document); });
  } else {
    hydrate(document);
  }

  var observer = new MutationObserver(function(mutations){
    mutations.forEach(function(mutation){
      mutation.addedNodes.forEach(function(node){
        if (node.nodeType === 1) hydrate(node);
      });
    });
  });
  observer.observe(document.documentElement, {childList:true, subtree:true});
})();
