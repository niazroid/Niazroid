(function(){
  'use strict';
  var buttons = Array.prototype.slice.call(document.querySelectorAll('[data-bm-pwa-install]'));
  var statusNodes = Array.prototype.slice.call(document.querySelectorAll('[data-bm-pwa-status]'));
  var labels = window.BM_SITE_PWA_LABELS || {};

  function textFor(state){
    if(state.installed) return 'نسخه وب روی دستگاه نصب شده است';
    if(state.ios) return 'مناسب iPhone و iPad — نصب از Safari';
    if(state.canPrompt) return 'آماده نصب مستقیم روی این دستگاه';
    return 'با لمس دکمه، نصب مستقیم یا راهنمای نصب رسمی مرورگر باز می‌شود';
  }
  function labelFor(state){
    if(state.installed) return 'نصب شده';
    if(state.ios) return labels.ios || 'نسخه وب مناسب آیفون';
    if(state.canPrompt) return labels.direct || 'نصب مستقیم نسخه وب';
    return labels.direct || 'نصب مستقیم نسخه وب';
  }
  function update(state){
    statusNodes.forEach(function(el){ el.textContent = textFor(state); });
    buttons.forEach(function(btn){
      var label = btn.querySelector('[data-bm-pwa-button-label]') || btn;
      label.textContent = labelFor(state);
      btn.classList.toggle('is-installed', !!state.installed);
      btn.disabled = !!state.installed;
    });
  }
  function fallbackState(){
    return {installed:false,ios:/iPad|iPhone|iPod/.test(navigator.userAgent||''),canPrompt:false};
  }
  buttons.forEach(function(btn){
    btn.addEventListener('click', function(){
      if(!window.BankMoviePWA){ update(fallbackState()); return; }
      var state = window.BankMoviePWA.getState();
      if(state.installed) return;
      window.BankMoviePWA.install().then(function(result){
        if(result && result.outcome === 'unavailable'){
          if(state.ios) window.BankMoviePWA.openIOSGuide();
          else if(window.BankMoviePWA.openGenericGuide) window.BankMoviePWA.openGenericGuide();
        }
        update(window.BankMoviePWA.getState());
      });
    });
  });
  document.querySelectorAll('[data-bm-ios-guide]').forEach(function(btn){
    btn.addEventListener('click', function(){ if(window.BankMoviePWA) window.BankMoviePWA.openIOSGuide(); });
  });
  if(window.BankMoviePWA) window.BankMoviePWA.subscribe(update);
  else update(fallbackState());
})();
