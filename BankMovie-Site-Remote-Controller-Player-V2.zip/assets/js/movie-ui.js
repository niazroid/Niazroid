// =================== توابع عمومی ===================

function showPlayerToast(msg) {
    const text = String(msg || '').replace(/<[^>]*>/g, '').trim();
    const stack = document.getElementById('playerToastStack');
    if(!text || !stack) return;
    stack.querySelectorAll('.player-toast').forEach(old => old.classList.add('hide'));
    const item = document.createElement('div');
    item.className = 'player-toast';
    item.textContent = text;
    stack.appendChild(item);
    setTimeout(() => item.classList.add('hide'), 2600);
    setTimeout(() => item.remove(), 2850);
}
function volumeHudSvg(percent){
    const muted = Number(percent) <= 0;
    return muted
        ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="19" y1="9" x2="15" y2="13"/><line x1="15" y1="9" x2="19" y2="13"/></svg>'
        : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>';
}
function brightnessHudSvg(){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';}
function speedHudSvg(){return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg>';}
function seekHudSvg(dir){return dir==='back' ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="11 7 6 12 11 17"/><polyline points="18 7 13 12 18 17"/></svg>' : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="13 7 18 12 13 17"/><polyline points="6 7 11 12 6 17"/></svg>';}

function showPlayerHud(title, value, progress = null, icon = '•') {
    const hud = document.getElementById('playerHud');
    if(!hud) return;
    const titleEl = document.getElementById('playerHudTitle');
    const valueEl = document.getElementById('playerHudValue');
    const iconEl = document.getElementById('playerHudIcon');
    const barEl = document.getElementById('playerHudBar');
    if(titleEl) titleEl.textContent = String(title || '');
    if(valueEl) valueEl.textContent = String(value || '');
    if(iconEl){ const iconHtml = String(icon || '•'); if(iconHtml.trim().startsWith('<svg')) iconEl.innerHTML = iconHtml; else iconEl.textContent = iconHtml; }
    if(barEl) {
        const pct = progress === null ? 0 : Math.max(0, Math.min(100, Number(progress) * 100));
        barEl.style.setProperty('--hud-progress', pct + '%');
        barEl.style.width = pct + '%';
        barEl.parentElement.style.display = progress === null ? 'none' : 'block';
    }
    hud.classList.remove('active','pulse');
    void hud.offsetWidth;
    hud.classList.add('active','pulse');
    clearTimeout(hud._timer);
    hud._timer = setTimeout(() => hud.classList.remove('active'), 850);
}

function showToast(msg) {
    const text = String(msg || '');
    showPlayerToast(text);
    if(toastTimeout) clearTimeout(toastTimeout);
    const container = document.getElementById('toastContainer');
    if(!container) return;
    container.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    container.appendChild(t);
    toastTimeout = setTimeout(() => { if(t) t.remove(); toastTimeout = null; }, 3000);
}

function hideLoading() { const overlay = document.getElementById('loadingOverlay'); if(!overlay) return; overlay.classList.add('hide'); setTimeout(() => overlay.style.display = 'none', 500); }

function getProxyUrl(url) { return url; }
function isSafeUrl(url) {
    try {
        const u = new URL(String(url || ''), window.location.origin);
        return ['http:', 'https:'].includes(u.protocol);
    } catch(e) { return false; }
}
function escapeHtml(str) {
    return String(str ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function escapeAttr(str) { return escapeHtml(str); }

// Menu
function setupMenu(){
    const menuBtn=document.getElementById('menuBtn');
    const sidebarMenu=document.getElementById('sidebarMenu');
    const menuOverlay=document.getElementById('menuOverlay');
    const closeMenuBtn=document.getElementById('closeMenuBtn');
    if(!menuBtn||!sidebarMenu||!menuOverlay||!closeMenuBtn) return;

    function openMenu(){
        if(window.matchMedia('(min-width: 992px)').matches) return;
        sidebarMenu.classList.add('open');
        menuOverlay.classList.add('active');
        document.body.style.overflow='hidden';
        menuBtn.setAttribute('aria-expanded','true');
    }
    function closeMenu(){
        sidebarMenu.classList.remove('open');
        menuOverlay.classList.remove('active');
        document.body.style.overflow='';
        menuBtn.setAttribute('aria-expanded','false');
    }

    menuBtn.addEventListener('click',openMenu);
    closeMenuBtn.addEventListener('click',closeMenu);
    menuOverlay.addEventListener('click',closeMenu);
    window.addEventListener('resize',()=>{if(window.innerWidth>=992) closeMenu();});
}

function setupHeaderScroll(){
    const header=document.getElementById('siteHeader') || document.querySelector('.header');
    const hero=document.querySelector('.hero-slider');
    if(!header) return;
    if(document.documentElement.classList.contains('bm-nav-static')){
        header.classList.remove('header-glass');
        header.classList.add('header-solid');
        header.setAttribute('data-bm-static-header','1');
        return;
    }

    function updateHeaderState(){
        const heroBottom=hero ? hero.getBoundingClientRect().bottom : 0;
        const overHero=!!hero && heroBottom > (header.offsetHeight + 10);
        header.classList.toggle('header-glass',overHero);
        header.classList.toggle('header-solid',!overHero);
    }

    updateHeaderState();
    window.addEventListener('scroll',updateHeaderState,{passive:true});
    window.addEventListener('resize',updateHeaderState);
}

function setupSmartBottomNav(){
    const nav=document.querySelector('.bottom-nav');
    if(!nav) return;
    // V46: low-end phones keep the footer nav permanently visible and do not
    // install the per-scroll hide/compact controller. Strong phones keep the
    // original behavior unchanged.
    if(document.documentElement.classList.contains('bm-nav-static')){
        nav.classList.remove('nav-hidden','nav-compact');
        nav.setAttribute('data-bm-static-nav','1');
        return;
    }
    let lastY=window.scrollY || 0;
    let ticking=false;
    const minDelta=12;

    function shouldKeepVisible(){
        const activeElement=document.activeElement;
        return window.innerWidth>=992 ||
            window.scrollY<120 ||
            document.body.style.overflow==='hidden' ||
            document.querySelector('.story-modal.active') ||
            document.querySelector('.sidebar-menu.open') ||
            (activeElement && ['INPUT','TEXTAREA','SELECT'].includes(activeElement.tagName));
    }

    function update(){
        const y=window.scrollY || 0;
        const diff=y-lastY;
        if(shouldKeepVisible()){
            nav.classList.remove('nav-hidden');
            nav.classList.toggle('nav-compact', y>220);
            lastY=y;
            ticking=false;
            return;
        }
        if(Math.abs(diff)>minDelta){
            nav.classList.toggle('nav-hidden', diff>0);
            nav.classList.toggle('nav-compact', y>220 && diff<=0);
            lastY=y;
        }
        ticking=false;
    }

    window.addEventListener('scroll',()=>{
        if(!ticking){
            window.requestAnimationFrame(update);
            ticking=true;
        }
    },{passive:true});
    window.addEventListener('resize',update);
    document.addEventListener('focusin',update);
    document.addEventListener('focusout',()=>setTimeout(update,80));
    update();
}

// Notifications sidebar
const notifBell=document.getElementById('notifBell');
const notifSidebar=document.getElementById('notifSidebar');
const closeNotifSidebar=document.getElementById('closeNotifSidebar');
if(notifBell&&notifSidebar&&closeNotifSidebar){
    notifBell.addEventListener('click',()=>{notifSidebar.classList.add('open');});
    closeNotifSidebar.addEventListener('click',()=>{notifSidebar.classList.remove('open');});
    document.addEventListener('click',(e)=>{
        if(!notifSidebar.contains(e.target)&&!notifBell.contains(e.target)&&notifSidebar.classList.contains('open')){
            notifSidebar.classList.remove('open');
        }
    });
}
function formatTime(s) { if(isNaN(s) || !isFinite(s)) return '00:00'; let m = Math.floor(s / 60); let sec = Math.floor(s % 60); if(m >= 60) { let h = Math.floor(m / 60); m = m % 60; return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`; } return `${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`; }
function srtToVtt(srt) { let vtt = "WEBVTT\n\n"; const lines = srt.split(/\r?\n/); let i = 0; while(i < lines.length) { if(lines[i].trim() === '') { i++; continue; } if(/^\d+$/.test(lines[i].trim())) i++; if(i < lines.length && lines[i].includes('-->')) { let ts = lines[i].replace(/,/g, '.'); vtt += ts + "\n"; i++; const txt = []; while(i < lines.length && lines[i].trim() !== '') txt.push(lines[i++]); vtt += txt.join("\n") + "\n\n"; } else i++; } return vtt; }
function renderStarsJs(rating) { let stars = ''; for(let i=1;i<=5;i++) stars += `<svg class="star ${i<=rating?'star-full':'star-empty'}" viewBox="0 0 24 24" fill="${i<=rating?'currentColor':'none'}" stroke="currentColor" style="width:14px;height:14px;"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>`; return stars; }
function formatCommentDateJs(dateString) {
    if(!dateString) return userLang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);
    if(diff < 0) return userLang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if(diff < 60) return userLang === 'fa' ? 'لحظاتی پیش' : 'Just now';
    if(diff < 3600) return Math.floor(diff / 60) + (userLang === 'fa' ? ' دقیقه پیش' : ' minutes ago');
    if(diff < 86400) return Math.floor(diff / 3600) + (userLang === 'fa' ? ' ساعت پیش' : ' hours ago');
    if(diff < 604800) return Math.floor(diff / 86400) + (userLang === 'fa' ? ' روز پیش' : ' days ago');
    if(diff < 2592000) return Math.floor(diff / 604800) + (userLang === 'fa' ? ' هفته پیش' : ' weeks ago');
    if(diff < 31536000) return Math.floor(diff / 2592000) + (userLang === 'fa' ? ' ماه پیش' : ' months ago');
    return Math.floor(diff / 31536000) + (userLang === 'fa' ? ' سال پیش' : ' years ago');
}
