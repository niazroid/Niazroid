(function(){
  'use strict';

  var deferredPrompt = null;
  var listeners = [];
  var isStandalone = function(){
    return !!(window.matchMedia && window.matchMedia('(display-mode: standalone)').matches) || window.navigator.standalone === true;
  };
  var ua = navigator.userAgent || '';
  var isIOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  var isSafari = /Safari/i.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS/i.test(ua);
  var isSecure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';

  function emit(){
    var state = api.getState();
    listeners.slice().forEach(function(fn){ try{ fn(state); }catch(_){ } });
    document.dispatchEvent(new CustomEvent('bankmovie:pwa-state', {detail: state}));
  }

  function injectDialogStyles(){
    if(document.getElementById('bmPwaRuntimeStyles')) return;
    var style = document.createElement('style');
    style.id = 'bmPwaRuntimeStyles';
    style.textContent = ''+
      '.bm-pwa-guide{position:fixed;inset:0;z-index:2147483646;display:none;align-items:center;justify-content:center;padding:18px;background:rgba(0,0,0,.78)}'+
      '.bm-pwa-guide.is-open{display:flex}.bm-pwa-guide-card{width:min(430px,100%);max-height:min(82dvh,680px);overflow:auto;border-radius:26px;padding:22px;background:#10121a;border:1px solid rgba(255,255,255,.12);box-shadow:0 28px 80px rgba(0,0,0,.55);color:#fff;direction:rtl;text-align:right;font-family:inherit}'+
      '.bm-pwa-guide-head{display:flex;align-items:center;gap:12px}.bm-pwa-guide-icon{width:52px;height:52px;border-radius:16px;background:#fff;display:grid;place-items:center;overflow:hidden}.bm-pwa-guide-icon img{width:100%;height:100%;object-fit:cover}.bm-pwa-guide-title{flex:1}.bm-pwa-guide-title strong{display:block;font-size:17px}.bm-pwa-guide-title span{display:block;margin-top:4px;color:rgba(255,255,255,.62);font-size:11px}.bm-pwa-guide-close{width:40px;height:40px;border:0;border-radius:14px;background:rgba(255,255,255,.08);color:#fff;font-size:22px;cursor:pointer}'+
      '.bm-pwa-steps{margin:18px 0 0;padding:0;list-style:none;display:grid;gap:10px}.bm-pwa-steps li{display:flex;gap:10px;align-items:flex-start;padding:12px;border-radius:17px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.075);font-size:13px;line-height:1.8}.bm-pwa-step-num{width:28px;height:28px;flex:0 0 28px;border-radius:10px;background:var(--accent,#2f7cff);color:#fff;display:grid;place-items:center;font-weight:900}'+
      '.bm-pwa-guide-note{margin-top:12px;color:rgba(255,255,255,.58);font-size:11px;line-height:1.8}.bm-pwa-guide-action{width:100%;margin-top:16px;min-height:48px;border:0;border-radius:16px;background:var(--accent,#2f7cff);color:#fff;font-weight:900;cursor:pointer}'+
      '@media(max-width:620px){.bm-pwa-guide{align-items:flex-end;padding:10px}.bm-pwa-guide-card{border-radius:24px 24px 18px 18px;box-shadow:0 -12px 40px rgba(0,0,0,.35)}}';
    document.head.appendChild(style);
  }

  function closeGuide(){
    var dialog = document.getElementById('bmPwaGuide');
    if(dialog){ dialog.classList.remove('is-open'); dialog.setAttribute('aria-hidden','true'); }
  }

  function openIOSGuide(){
    injectDialogStyles();
    var dialog = document.getElementById('bmPwaGuide');
    if(!dialog){
      dialog = document.createElement('div');
      dialog.id = 'bmPwaGuide';
      dialog.className = 'bm-pwa-guide';
      dialog.setAttribute('aria-hidden','true');
      dialog.innerHTML = '<section class="bm-pwa-guide-card" role="dialog" aria-modal="true" aria-labelledby="bmPwaGuideTitle">'+
        '<div class="bm-pwa-guide-head"><span class="bm-pwa-guide-icon"><img src="/assets/icons/bm-apple-icon.svg" alt="Apple"></span><div class="bm-pwa-guide-title"><strong id="bmPwaGuideTitle">نصب نسخه وب روی آیفون و آیپد</strong><span>بدون App Store و با اجرای تمام‌صفحه</span></div><button type="button" class="bm-pwa-guide-close" data-bm-pwa-close aria-label="بستن">×</button></div>'+
        '<ol class="bm-pwa-steps"><li><span class="bm-pwa-step-num">۱</span><span>این صفحه را در مرورگر <b>Safari</b> باز کن.</span></li><li><span class="bm-pwa-step-num">۲</span><span>دکمه <b>Share</b> در نوار Safari را بزن.</span></li><li><span class="bm-pwa-step-num">۳</span><span>گزینه <b>Add to Home Screen</b> یا «افزودن به صفحه اصلی» را انتخاب کن.</span></li><li><span class="bm-pwa-step-num">۴</span><span>در صفحه بعد روی <b>Add</b> بزن تا آیکن بانک مووی نصب شود.</span></li></ol>'+
        '<p class="bm-pwa-guide-note">نسخه نصب‌شده به‌صورت مستقل و تمام‌صفحه اجرا می‌شود. پخش ویدیو همچنان آنلاین است و برای سافت‌ساب باید از پلیر خارجی استفاده شود.</p>'+
        '<button type="button" class="bm-pwa-guide-action" data-bm-pwa-close>متوجه شدم</button></section>';
      document.body.appendChild(dialog);
      dialog.addEventListener('click', function(e){ if(e.target === dialog || e.target.closest('[data-bm-pwa-close]')) closeGuide(); });
    }
    dialog.classList.add('is-open');
    dialog.setAttribute('aria-hidden','false');
  }

  function openGenericGuide(){
    injectDialogStyles();
    var dialog = document.getElementById('bmPwaGuide');
    if(!dialog){
      dialog = document.createElement('div');
      dialog.id = 'bmPwaGuide';
      dialog.className = 'bm-pwa-guide';
      dialog.setAttribute('aria-hidden','true');
      document.body.appendChild(dialog);
      dialog.addEventListener('click', function(e){ if(e.target === dialog || e.target.closest('[data-bm-pwa-close]')) closeGuide(); });
    }
    dialog.innerHTML = '<section class="bm-pwa-guide-card" role="dialog" aria-modal="true" aria-labelledby="bmPwaGuideTitle">'+
      '<div class="bm-pwa-guide-head"><span class="bm-pwa-guide-icon"><img src="/assets/icons/icon-192.png?v=102.2" alt="BankMovie"></span><div class="bm-pwa-guide-title"><strong id="bmPwaGuideTitle">نصب مستقیم نسخه وب بانک مووی</strong><span>اجرا مثل اپلیکیشن روی دستگاه</span></div><button type="button" class="bm-pwa-guide-close" data-bm-pwa-close aria-label="بستن">×</button></div>'+
      '<ol class="bm-pwa-steps"><li><span class="bm-pwa-step-num">۱</span><span>منوی مرورگر را باز کن.</span></li><li><span class="bm-pwa-step-num">۲</span><span>گزینه <b>Install app</b>، <b>نصب برنامه</b> یا <b>Add to Home Screen</b> را بزن.</span></li><li><span class="bm-pwa-step-num">۳</span><span>نصب را تأیید کن تا آیکن جدید بانک مووی روی دستگاه اضافه شود.</span></li></ol>'+
      '<p class="bm-pwa-guide-note">اگر مرورگر شرایط نصب مستقیم را آماده کرده باشد، دکمه نصب بدون نمایش این راهنما پنجره رسمی نصب را باز می‌کند.</p>'+
      '<button type="button" class="bm-pwa-guide-action" data-bm-pwa-close>متوجه شدم</button></section>';
    dialog.classList.add('is-open');
    dialog.setAttribute('aria-hidden','false');
  }

  function install(){
    if(isStandalone()) return Promise.resolve({outcome:'installed'});
    if(deferredPrompt){
      var promptEvent = deferredPrompt;
      deferredPrompt = null;
      return promptEvent.prompt().then(function(){ return promptEvent.userChoice; }).then(function(choice){ emit(); return choice; });
    }
    if(isIOS){ openIOSGuide(); return Promise.resolve({outcome:'instructions'}); }
    openGenericGuide();
    return Promise.resolve({outcome:'instructions'});
  }

  var api = {
    install: install,
    openIOSGuide: openIOSGuide,
    openGenericGuide: openGenericGuide,
    closeGuide: closeGuide,
    getState: function(){
      return {
        installed: isStandalone(),
        canPrompt: !!deferredPrompt,
        ios: isIOS,
        safari: isSafari,
        secure: isSecure,
        platform: isIOS ? 'ios' : (/Android/i.test(ua) ? 'android' : 'desktop')
      };
    },
    subscribe: function(fn){ if(typeof fn === 'function'){ listeners.push(fn); fn(api.getState()); } return function(){ listeners = listeners.filter(function(x){ return x !== fn; }); }; }
  };
  window.BankMoviePWA = api;

  window.addEventListener('beforeinstallprompt', function(event){
    event.preventDefault();
    deferredPrompt = event;
    emit();
  });
  window.addEventListener('appinstalled', function(){ deferredPrompt = null; emit(); });

  if(isSecure && 'serviceWorker' in navigator){
    window.addEventListener('load', function(){
      navigator.serviceWorker.register('/service-worker.js', {scope:'/'}).catch(function(){ /* PWA remains usable without offline fallback. */ });
    }, {once:true});
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', emit, {once:true}); else emit();
})();
