(function(){
  'use strict';
  const body=document.body;
  const sidebar=document.getElementById('sidebar');
  const backdrop=document.getElementById('sidebarBackdrop');
  const toggle=document.getElementById('menuToggle');

  function closeMenu(){sidebar?.classList.remove('open');backdrop?.classList.remove('open');}
  toggle?.addEventListener('click',()=>{sidebar?.classList.toggle('open');backdrop?.classList.toggle('open');});
  backdrop?.addEventListener('click',closeMenu);

  const saved=localStorage.getItem('adminTheme')||'neon';
  function applyTheme(t){
    body.classList.remove('theme-purple','theme-red','theme-gold');
    if(t!=='neon')body.classList.add('theme-'+t);
    document.querySelectorAll('.theme-chip').forEach(b=>b.classList.toggle('active',b.dataset.theme===t));
    localStorage.setItem('adminTheme',t);
  }
  applyTheme(saved);
  document.querySelectorAll('.theme-chip').forEach(b=>b.addEventListener('click',()=>applyTheme(b.dataset.theme)));

  const labels={
    public:'مهمان، کاربر، VIP و مدیر',
    member:'فقط حساب‌های واردشده + VIP + مدیر',
    vip:'فقط VIP فعال + مدیر',
    admin:'فقط مدیر'
  };

  function refreshCard(card){
    const checked=card.querySelector('input[type=radio][name$="_access_scope"]:checked');
    const preview=card.querySelector('[data-scope-preview]');
    if(preview&&checked)preview.textContent=labels[checked.value]||checked.value;

    const enabled=card.querySelector('input[type=checkbox][name$="_enabled"]');
    const badge=card.querySelector('[data-status-badge]');
    if(enabled&&badge){
      badge.textContent=enabled.checked?'فعال':'غیرفعال';
      badge.classList.toggle('on',enabled.checked);
      badge.classList.toggle('off',!enabled.checked);
    }
  }

  document.querySelectorAll('[data-archive-card]').forEach(card=>{
    refreshCard(card);
    card.addEventListener('change',()=>refreshCard(card));
  });

  document.querySelectorAll('[data-scope-preset]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const scope=btn.dataset.scopePreset;
      document.querySelectorAll(`input[type=radio][value="${scope}"][name$="_access_scope"]`).forEach(r=>{
        r.checked=true;
        r.dispatchEvent(new Event('change',{bubbles:true}));
      });
    });
  });
})();
(function(){
  'use strict';
  const grid=document.querySelector('.archive-grid');
  if(!grid)return;

  function syncOrder(){
    [...grid.querySelectorAll('[data-archive-card]')].forEach((card,i)=>{
      const input=card.querySelector('[data-sort-order]');
      if(input)input.value=String((i+1)*10);
    });
  }
  function moveCard(card,dir){
    if(!card)return;
    if(dir<0 && card.previousElementSibling) grid.insertBefore(card,card.previousElementSibling);
    if(dir>0 && card.nextElementSibling) grid.insertBefore(card.nextElementSibling,card);
    syncOrder();
  }
  grid.addEventListener('click',e=>{
    const b=e.target.closest('[data-move]');
    if(b){moveCard(b.closest('[data-archive-card]'),Number(b.dataset.move||0));return;}
    const reset=e.target.closest('.reset-domain');
    if(reset){
      const card=reset.closest('[data-archive-card]');
      const input=card?.querySelector('.domain-input');
      if(input&&input.dataset.defaultDomain)input.value=input.dataset.defaultDomain;
    }
  });

  let dragged=null;
  grid.addEventListener('dragstart',e=>{
    const card=e.target.closest('[data-archive-card]');
    if(!card)return;
    dragged=card;card.classList.add('is-dragging');grid.classList.add('dragging');
    try{e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('text/plain',card.dataset.archiveId||'');}catch(_e){}
  });
  grid.addEventListener('dragover',e=>{
    if(!dragged)return;
    e.preventDefault();
    const target=e.target.closest('[data-archive-card]');
    if(!target||target===dragged)return;
    const r=target.getBoundingClientRect();
    const before=e.clientY<r.top+r.height/2;
    grid.insertBefore(dragged,before?target:target.nextElementSibling);
  });
  grid.addEventListener('dragend',()=>{
    dragged?.classList.remove('is-dragging');grid.classList.remove('dragging');dragged=null;syncOrder();
  });
  syncOrder();
})();