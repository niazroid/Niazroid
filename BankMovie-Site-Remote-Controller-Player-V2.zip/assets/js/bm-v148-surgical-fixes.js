/* BankMovie v148.4 — narrow, one-time public UI normalization. */
(function(){
  'use strict';

  function ready(fn){
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true});
    else fn();
  }

  var categoryIcon='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="2"></rect><rect x="14" y="3" width="7" height="7" rx="2"></rect><rect x="3" y="14" width="7" height="7" rx="2"></rect><rect x="14" y="14" width="7" height="7" rx="2"></rect></svg>';

  function navKind(link){
    var href=(link.getAttribute('href')||'').toLowerCase();
    if(href==='/' || /(?:^|\/)index(?:\.php)?(?:$|[?#])/.test(href)) return 'home';
    if(/search/.test(href) || link.classList.contains('bm-footer-search-trigger')) return 'search';
    if(/application|app\.php/.test(href)) return 'application';
    if(/player/.test(href)) return 'player';
    if(/profile|login|register/.test(href)) return 'profile';
    if(/categories|genres/.test(href) || link.classList.contains('bm-mobile-category-item')) return 'categories';
    return 'other';
  }

  function standardizeBottomNav(){
    var categoriesEnabled=(window.BM_MOBILE_NAV_CATEGORIES_ENABLED!==false);
    var isFa=(document.documentElement.getAttribute('dir')||'rtl').toLowerCase()!=='ltr';
    var categoriesLabel=window.BM_MOBILE_NAV_CATEGORIES_LABEL || (isFa?'دسته‌بندی':'Categories');

    document.querySelectorAll('.bottom-nav,.actor-bottom-nav,[data-mobile-bottom-nav]').forEach(function(bar){
      bar.setAttribute('dir','ltr');

      Array.prototype.slice.call(bar.children).forEach(function(link){
        if(!link.matches || !link.matches('a')) return;
        link.dataset.bmNavKind=navKind(link);
      });

      var categoryLink=bar.querySelector('a[data-bm-nav-kind="categories"],a[href="/categories"],a[href*="categories.php"]');
      if(categoriesEnabled && !categoryLink){
        categoryLink=document.createElement('a');
        categoryLink.href='/categories';
        categoryLink.className='nav-item bm-nav-categories';
        categoryLink.dataset.bmNavKind='categories';
        categoryLink.setAttribute('aria-label',categoriesLabel);
        categoryLink.innerHTML=categoryIcon+'<span class="nav-label">'+categoriesLabel+'</span>';
        bar.appendChild(categoryLink);
      }else if(!categoriesEnabled && categoryLink){
        categoryLink.remove();
      }

      var rank={profile:10,application:20,player:20,categories:30,search:40,home:50,other:60};
      var links=Array.prototype.slice.call(bar.children).filter(function(el){return el.matches&&el.matches('a');});
      links.forEach(function(link){ link.dataset.bmNavKind=navKind(link); });
      links.sort(function(a,b){return (rank[a.dataset.bmNavKind]||60)-(rank[b.dataset.bmNavKind]||60);});
      links.forEach(function(link){bar.appendChild(link);});
      bar.style.setProperty('--bm-mobile-nav-count',String(links.length||5));
      bar.dataset.bmNavUnified='1';
    });
  }

  function addCategoriesToMenus(){
    var isFa=(document.documentElement.getAttribute('dir')||'rtl').toLowerCase()!=='ltr';
    var label=isFa?'دسته‌بندی':'Categories';
    document.querySelectorAll('.sidebar-nav').forEach(function(nav){
      if(nav.querySelector('a[href="/categories"],a[href*="categories.php"],.bm-categories-sidebar-link')) return;
      var link=document.createElement('a');
      link.href='/categories';
      link.className='sidebar-item bm-categories-sidebar-link';
      link.innerHTML=(nav.querySelector('.sidebar-item svg')?categoryIcon:'')+'<span>'+label+'</span>';
      var collections=nav.querySelector('a[href*="/collections"]');
      if(collections && collections.parentNode===nav) collections.insertAdjacentElement('afterend',link);
      else nav.appendChild(link);
    });
  }

  function enforceHeader(){
    var header=document.getElementById('siteHeader');
    if(!header) return;
    header.classList.add('bm-public-header-v148');
    header.querySelectorAll('.bm-header-collection').forEach(function(link){
      link.href='/categories';
      link.classList.add('bm-header-categories');
      link.setAttribute('aria-label','دسته‌بندی');
      link.setAttribute('title','دسته‌بندی');
      if(!link.querySelector('rect')) link.innerHTML=categoryIcon;
    });
  }

  ready(function(){
    enforceHeader();
    standardizeBottomNav();
    addCategoriesToMenus();
  });
})();

/* v148.4.1 — focused drawer, header hit-area and comment-label repair. */
(function(){
  'use strict';

  function ready(fn){
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true});
    else fn();
  }

  function safeCommentButton(){
    var btn=document.getElementById('submitCommentBtn');
    if(!btn) return;

    btn.classList.add('bm-comment-submit-safe');
    btn.setAttribute('dir','ltr');
    btn.innerHTML=''
      +'<svg class="bm-comment-safe-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
      +'<path d="M22 2 11 13"></path><path d="m22 2-7 20-4-9-9-4Z"></path></svg>'
      +'<span class="bm-comment-safe-label">Send</span>';

    var label=btn.querySelector('.bm-comment-safe-label');
    var icon=btn.querySelector('.bm-comment-safe-icon');
    var resetTimer=0;

    function setState(state){
      if(!label) return;
      if(state==='sending'){
        label.textContent='Sending...';
        btn.setAttribute('aria-label','Sending');
      }else if(state==='sent'){
        label.textContent='Sent';
        btn.setAttribute('aria-label','Sent');
        if(icon) icon.innerHTML='<path d="m5 12 4 4L19 6"></path>';
      }else{
        label.textContent='Send';
        btn.setAttribute('aria-label','Send');
        if(icon) icon.innerHTML='<path d="M22 2 11 13"></path><path d="m22 2-7 20-4-9-9-4Z"></path>';
      }
    }

    function syncFromClass(){
      if(btn.classList.contains('is-sent')) setState('sent');
      else if(btn.classList.contains('is-sending')) setState('sending');
      else setState('idle');
    }

    new MutationObserver(syncFromClass).observe(btn,{attributes:true,attributeFilter:['class','disabled']});
    syncFromClass();

    var success=document.getElementById('commentMessage');
    if(success){
      new MutationObserver(function(){
        var text=(success.textContent||'').trim();
        var visible=success.style.display!=='none';
        if(!text||!visible) return;
        window.clearTimeout(resetTimer);
        btn.classList.remove('is-sending');
        btn.classList.add('is-sent');
        setState('sent');
        resetTimer=window.setTimeout(function(){
          btn.classList.remove('is-sent','is-sending');
          btn.disabled=false;
          setState('idle');
        },1800);
      }).observe(success,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
    }

    var error=document.getElementById('commentError');
    if(error){
      new MutationObserver(function(){
        var text=(error.textContent||'').trim();
        var visible=error.style.display!=='none';
        if(!text||!visible) return;
        btn.classList.remove('is-sending','is-sent');
        btn.disabled=false;
        setState('idle');
      }).observe(error,{childList:true,subtree:true,attributes:true,attributeFilter:['style','class']});
    }
  }

  function isolateHeaderControls(){
    var bell=document.getElementById('notifBell');
    if(bell){
      /* The notification controller is attached directly to the bell.
         Stop the same click from reaching old delegated search handlers. */
      bell.addEventListener('click',function(e){ e.stopPropagation(); },false);
    }
  }

  ready(function(){
    safeCommentButton();
    isolateHeaderControls();
  });
})();
