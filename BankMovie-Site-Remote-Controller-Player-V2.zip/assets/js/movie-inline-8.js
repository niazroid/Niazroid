
(function(){
    function markLoaded(){ document.body.classList.add('bm-page-loaded'); }
    window.addEventListener('load', function(){ setTimeout(markLoaded, 260); });
    setTimeout(markLoaded, 2400);
})();
