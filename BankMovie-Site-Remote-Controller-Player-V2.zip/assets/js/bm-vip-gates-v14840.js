(() => {
  'use strict';

  const cfg = window.BM_VIP_GATES || {};
  const locks = cfg.locks || {};
  if (!Object.values(locks).some(Boolean)) return;

  const modal = document.getElementById('bmVipGateModal');
  const dialog = modal?.querySelector('.bm-vip-gate-dialog');
  const title = modal?.querySelector('[data-bm-vip-modal-title]');
  const description = modal?.querySelector('[data-bm-vip-modal-description]');
  const note = modal?.querySelector('[data-bm-vip-modal-note]');
  const actions = modal?.querySelector('[data-bm-vip-modal-actions]');
  const purchase = modal?.querySelector('[data-bm-vip-purchase]');
  const login = modal?.querySelector('[data-bm-vip-login]');
  const register = modal?.querySelector('[data-bm-vip-register]');
  const guestOnly = modal ? Array.from(modal.querySelectorAll('[data-bm-vip-guest-only]')) : [];
  const closeButtons = modal ? Array.from(modal.querySelectorAll('[data-bm-vip-close]')) : [];
  const featureMeta = cfg.features || {};
  const loggedIn = Boolean(cfg.loggedIn);
  let activeFeature = '';
  let lastFocus = null;
  let lastInterceptAt = 0;
  let lastInterceptTarget = null;

  const defaults = {
    watch_party: {
      title: 'تماشای دونفره ویژه اعضای VIP',
      description: 'با اشتراک VIP می‌توانید اتاق خصوصی بسازید، فیلم را کاملاً همگام تماشا کنید و همان‌جا با همراهتان چت کنید.'
    },
    online_watch: {
      title: 'پخش آنلاین ویژه اعضای VIP',
      description: 'برای پخش مستقیم این فیلم یا سریال، اشتراک VIP فعال لازم است.'
    },
    online_player: {
      title: 'پلیر آنلاین ویژه اعضای VIP',
      description: 'دسترسی به پلیر آنلاین مستقل برای اعضای VIP فعال شده است.'
    },
    downloads: {
      title: 'دانلود ویژه اعضای VIP',
      description: 'برای دریافت این فایل، اشتراک VIP فعال لازم است.'
    },
    subtitle_downloads: {
      title: 'زیرنویس ویژه اعضای VIP',
      description: 'برای دریافت فایل زیرنویس، اشتراک VIP فعال لازم است.'
    },
    watchlist: {
      title: 'واچ‌لیست ویژه اعضای VIP',
      description: 'برای استفاده از واچ‌لیست و ذخیره عنوان‌ها، اشتراک VIP فعال لازم است.'
    },
    comments_ratings: {
      title: 'تعاملات ویژه اعضای VIP',
      description: 'ثبت دیدگاه، پاسخ و امتیازدهی در این حالت برای اعضای VIP فعال است.'
    }
  };

  function currentReturn() {
    return location.pathname + location.search + location.hash;
  }

  function routeUrl(route, feature) {
    const url = new URL(route || '/', location.origin);
    url.searchParams.set('return', currentReturn());
    if (feature && url.pathname === '/vip') url.searchParams.set('feature', feature);
    return url.href;
  }

  function salesUrl(feature) {
    return routeUrl(cfg.salesPath || '/vip', feature);
  }

  function classify(target) {
    const explicit = target.getAttribute('data-bm-vip-gate');
    if (explicit) return explicit;
    if (target.matches('.bm-watch-together-btn,[data-bm-watch-together]')) return 'watch_party';
    if (target.matches('a[href^="/watch-party"],a[href*="watch_party_start.php"]')) return 'watch_party';
    if (target.matches('.watchlist-btn,#watchlistBtn,[data-watchlist-action]')) return 'watchlist';
    if (target.matches('.submit-comment,.comment-submit,#submitCommentBtn,.submit-reply,.reply-btn,.comment-like,.comment-dislike,.edit-comment-btn,.report-comment-btn,.star-input,[data-comment-action]')) return 'comments_ratings';
    if (target.matches('.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]')) return 'subtitle_downloads';
    if (target.matches('a[download],.arc1-dl-btn,.download-icon,#downloadCurrentBtn,[data-bm-manager-download]')) return 'downloads';
    if (target.matches('a[href^="/player"],a[href^="player.php"],a[href*="/player?"]')) return 'online_player';
    if (target.matches('.arc1-play-btn,.arc1-play-inline,.bm-local-play-choice,.bm-download-play-choice,.bm-poster-play,[data-play-url],[data-video-url],[data-direct-player],a[href="#playerWrapper"],a[href="#arc1PlayerWrapper"],[aria-label*="پخش آنلاین"]')) return 'online_watch';
    return '';
  }

  function all(root, selector) {
    const nodes = [];
    if (root instanceof Element && root.matches(selector)) nodes.push(root);
    if (root && root.querySelectorAll) nodes.push(...root.querySelectorAll(selector));
    return nodes;
  }

  function markKnownTargets(root = document) {
    all(root, '.bm-watch-together-btn,[data-bm-watch-together],a[href^="/watch-party"],a[href*="watch_party_start.php"]').forEach(el => el.setAttribute('data-bm-vip-gate', 'watch_party'));
    all(root, '.watchlist-btn,#watchlistBtn,[data-watchlist-action]').forEach(el => el.setAttribute('data-bm-vip-gate', 'watchlist'));
    all(root, '.submit-comment,.comment-submit,#submitCommentBtn,.submit-reply,.reply-btn,.comment-like,.comment-dislike,.edit-comment-btn,.report-comment-btn,.star-input,[data-comment-action]').forEach(el => el.setAttribute('data-bm-vip-gate', 'comments_ratings'));
    all(root, '.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]').forEach(el => el.setAttribute('data-bm-vip-gate', 'subtitle_downloads'));
    all(root, 'a[download],.arc1-dl-btn,.download-icon,#downloadCurrentBtn,[data-bm-manager-download]').forEach(el => {
      if (!el.matches('.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]')) el.setAttribute('data-bm-vip-gate', 'downloads');
    });
    all(root, 'a[href^="/player"],a[href^="player.php"],a[href*="/player?"]').forEach(el => el.setAttribute('data-bm-vip-gate', 'online_player'));
    all(root, '.arc1-play-btn,.arc1-play-inline,.bm-local-play-choice,.bm-download-play-choice,.bm-poster-play,[data-play-url],[data-video-url],[data-direct-player],a[href="#playerWrapper"],a[href="#arc1PlayerWrapper"],[aria-label*="پخش آنلاین"]').forEach(el => {
      if (!el.matches('.bm-watch-together-btn,[data-bm-watch-together]')) el.setAttribute('data-bm-vip-gate', 'online_watch');
    });
  }

  function isLocked(feature) {
    return Boolean(feature && locks[feature]);
  }

  function suppressNativeEvent(event) {
    if (!event) return;
    event.preventDefault?.();
    event.stopPropagation?.();
    event.stopImmediatePropagation?.();
  }

  function closeCompetingPlaybackModal() {
    try { window.bmClosePlayChoiceModal?.(); } catch (_) {}
    const playModal = document.getElementById('bmPlayChoiceModal');
    if (playModal) {
      playModal.classList.remove('active');
      playModal.setAttribute('aria-hidden', 'true');
      ['display','opacity','visibility','pointer-events','z-index','position','inset'].forEach(name => playModal.style.removeProperty(name));
    }
  }

  function copyFor(feature) {
    return Object.assign({}, defaults[feature] || defaults.online_watch, featureMeta[feature] || {});
  }

  function open(feature) {
    if (!modal || !isLocked(feature)) return false;
    window.__BM_VIP_GATE_BLOCK_UNTIL = Date.now() + 900;
    if (feature === 'online_watch' || feature === 'online_player') closeCompetingPlaybackModal();
    if (!modal.hidden && modal.classList.contains('is-open') && activeFeature === feature) return true;
    activeFeature = feature;
    lastFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    const meta = copyFor(feature);
    if (title) title.textContent = meta.title || 'این قابلیت ویژه اعضای VIP است';
    if (description) description.textContent = meta.description || 'برای استفاده از این قابلیت، اشتراک VIP فعال لازم است.';
    if (note) {
      note.textContent = loggedIn
        ? 'حساب شما فعال است، اما اشتراک VIP ندارد. پلن موردنظر را انتخاب کنید و فعال‌سازی را با پشتیبانی بانک‌مووی هماهنگ کنید.'
        : 'ابتدا وارد حساب شوید یا رایگان ثبت‌نام کنید. سپس از صفحه VIP پلن خود را انتخاب و فعال‌سازی را با پشتیبانی هماهنگ کنید.';
    }
    if (purchase) purchase.href = salesUrl(feature);
    if (login) login.href = routeUrl(cfg.loginPath || '/login', '');
    if (register) register.href = routeUrl(cfg.registerPath || '/register', '');
    guestOnly.forEach(el => { el.hidden = loggedIn; });
    actions?.classList.toggle('is-member', loggedIn);
    modal.hidden = false;
    modal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('bm-vip-modal-open');
    requestAnimationFrame(() => {
      modal.classList.add('is-open');
      window.setTimeout(() => dialog?.focus({ preventScroll: true }), 80);
    });
    return true;
  }

  function close() {
    if (!modal || modal.hidden) return;
    window.__BM_VIP_GATE_BLOCK_UNTIL = Date.now() + 650;
    modal.classList.remove('is-open');
    document.body.classList.remove('bm-vip-modal-open');
    window.setTimeout(() => {
      modal.hidden = true;
      modal.setAttribute('aria-hidden', 'true');
      activeFeature = '';
      lastFocus?.focus?.({ preventScroll: true });
    }, 230);
  }

  function intercept(event) {
    const target = event.target instanceof Element ? event.target.closest('a,button,[role="button"]') : null;
    if (!target || target.closest('#bmVipGateModal')) return false;
    const feature = classify(target);
    if (!isLocked(feature)) return false;
    const now = Date.now();
    suppressNativeEvent(event);
    if (lastInterceptTarget === target && now - lastInterceptAt < 420) return true;
    lastInterceptTarget = target;
    lastInterceptAt = now;
    open(feature);
    return true;
  }

  function blocksTarget(target, featureHint = '') {
    if (!(target instanceof Element)) return false;
    const feature = featureHint || classify(target.closest('a,button,[role="button"]') || target);
    return isLocked(feature);
  }


  markKnownTargets();
  const observer = new MutationObserver(records => {
    records.forEach(record => record.addedNodes.forEach(node => {
      if (node.nodeType === 1) markKnownTargets(node);
    }));
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  ['pointerup','touchend','click'].forEach(type => {
    document.addEventListener(type, intercept, { capture: true, passive: false });
  });
  document.addEventListener('auxclick', event => {
    if (event.button === 1) intercept(event);
  }, true);
  document.addEventListener('bm:vip-gate-request', event => {
    const feature = String(event.detail?.feature || 'online_watch');
    if (isLocked(feature)) open(feature);
  });

  closeButtons.forEach(button => button.addEventListener('click', close));
  modal?.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      event.preventDefault();
      close();
      return;
    }
    if (event.key !== 'Tab' || !dialog) return;
    const focusable = Array.from(dialog.querySelectorAll('a[href]:not([hidden]),button:not([disabled]):not([hidden])')).filter(el => el.offsetParent !== null);
    if (!focusable.length) return;
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) { event.preventDefault(); last.focus(); }
    else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
  });

  window.bmOpenVipGateModal = open;
  window.bmCloseVipGateModal = close;
  window.bmVipGateBlocksTarget = blocksTarget;
  window.bmVipGateFeatureLocked = isLocked;
})();
