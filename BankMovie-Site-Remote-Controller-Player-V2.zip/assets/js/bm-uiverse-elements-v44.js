/* BankMovie V44 — safe runtime enhancer for sound, rating and bookmark controls. */
(function(){
  'use strict';

  function syncSoundButton(btn, slider, media){
    if(!btn) return;
    var muted=false;
    if(media) muted=!!media.muted || Number(media.volume||0)===0;
    if(slider && Number(slider.value||0)===0) muted=true;
    btn.classList.toggle('is-muted',muted);
    btn.setAttribute('aria-pressed',muted?'true':'false');
    btn.setAttribute('title',muted?'وصل کردن صدا':'قطع کردن صدا');
  }

  function bindSound(btnId,sliderId,mediaId){
    var btn=document.getElementById(btnId);
    if(!btn) return;
    var slider=document.getElementById(sliderId);
    var media=document.getElementById(mediaId);
    var sync=function(){syncSoundButton(btn,slider,media);};
    btn.addEventListener('click',function(){setTimeout(sync,0);});
    slider&&slider.addEventListener('input',function(){setTimeout(sync,0);});
    media&&media.addEventListener('volumechange',sync);
    sync();
  }

  function enhanceBookmark(btn){
    if(!btn) return;
    btn.dataset.bmBookmarkV44='1';
    btn.classList.remove('bm-bookmark-btn');
    btn.classList.add('bm-heart-watchlist');
    btn.setAttribute('aria-label',btn.classList.contains('active')?'حذف از علاقه‌مندی‌ها':'افزودن به علاقه‌مندی‌ها');
    btn.setAttribute('title',btn.classList.contains('active')?'حذف از علاقه‌مندی‌ها':'افزودن به علاقه‌مندی‌ها');
    btn.innerHTML='<span class="bm-heart-icons" aria-hidden="true">'+
      '<svg class="bm-heart-empty" viewBox="0 0 24 24"><path fill="none" d="M0 0H24V24H0z"></path><path d="M16.5 3C19.538 3 22 5.5 22 9c0 7-7.5 11-10 12.5C9.5 20 2 16 2 9c0-3.5 2.5-6 5.5-6C9.36 3 11 4 12 5c1-1 2.64-2 4.5-2zm-3.566 15.604c.881-.556 1.676-1.109 2.42-1.701C18.335 14.533 20 11.943 20 9c0-2.36-1.537-4-3.5-4-1.076 0-2.24.57-3.086 1.414L12 7.828l-1.414-1.414C9.74 5.57 8.576 5 7.5 5 5.56 5 4 6.656 4 9c0 2.944 1.666 5.533 4.645 7.903.745.592 1.54 1.145 2.421 1.7.299.189.595.37.934.572.339-.202.635-.383.934-.571z"></path></svg>'+
      '<svg class="bm-heart-filled" viewBox="0 0 24 24"><path fill="none" d="M0 0H24V24H0z"></path><path d="M16.5 3C19.538 3 22 5.5 22 9c0 7-7.5 11-10 12.5C9.5 20 2 16 2 9c0-3.5 2.5-6 5.5-6C9.36 3 11 4 12 5c1-1 2.64-2 4.5-2z"></path></svg>'+
      '</span><span class="bm-heart-label">'+(btn.classList.contains('active')?'نشان شده':'نشان کردن')+'</span>';

    var sync=function(){
      var active=btn.classList.contains('active');
      var label=btn.querySelector('.bm-heart-label');
      if(label) label.textContent=active?'نشان شده':'نشان کردن';
      btn.setAttribute('aria-pressed',active?'true':'false');
      btn.setAttribute('aria-label',active?'حذف از علاقه‌مندی‌ها':'افزودن به علاقه‌مندی‌ها');
      btn.setAttribute('title',active?'حذف از علاقه‌مندی‌ها':'افزودن به علاقه‌مندی‌ها');
    };
    sync();
    if(!btn._bmHeartObserver){
      btn._bmHeartObserver=new MutationObserver(sync);
      btn._bmHeartObserver.observe(btn,{attributes:true,attributeFilter:['class']});
    }
  }

  function enhanceStars(){
    document.querySelectorAll('#starRating .star-input').forEach(function(star){
      star.setAttribute('role','button');
      star.setAttribute('tabindex','0');
      star.setAttribute('aria-label',(star.dataset.value||'')+' ستاره');
      if(star.dataset.bmKeyV42==='1') return;
      star.dataset.bmKeyV42='1';
      star.addEventListener('keydown',function(e){
        if(e.key==='Enter'||e.key===' '){e.preventDefault();star.dispatchEvent(new MouseEvent('click',{bubbles:true}));}
      });
    });
  }

  function boot(){
    bindSound('volumeBtn','volumeSlider','videoPlayer');
    bindSound('arc1VolBtn','arc1VolSlider','arc1VideoEl');
    bindSound('partyVolumeBtn','partyVolume','partyVideo');
    /* Fallback to the Watch Party video selector if its id changes. */
    var pbtn=document.getElementById('partyVolumeBtn');
    if(pbtn){
      var pslider=document.getElementById('partyVolume');
      var pvideo=document.querySelector('#playerWrapper video,.player-wrapper video');
      if(pvideo){
        var psync=function(){syncSoundButton(pbtn,pslider,pvideo);};
        pbtn.addEventListener('click',function(){setTimeout(psync,0);});
        pslider&&pslider.addEventListener('input',function(){setTimeout(psync,0);});
        pvideo.addEventListener('volumechange',psync); psync();
      }
    }
    enhanceBookmark(document.getElementById('watchlistBtn'));
    enhanceBookmark(document.getElementById('arc1WlBtn'));
    enhanceStars();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
  window.addEventListener('load',function(){setTimeout(boot,40);},{once:true});
})();
