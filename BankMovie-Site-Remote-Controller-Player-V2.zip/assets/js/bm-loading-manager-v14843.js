(function(){
  'use strict';
  var cfg = window.BM_LOADING_CONFIG || {};
  var startedAt = (window.performance && performance.now) ? performance.now() : Date.now();
  var overlay = null;
  var loaded = document.readyState === 'complete';
  var hideRequested = false;
  var released = false;
  var minDuration = Math.max(0, Number(cfg.minDuration || 0));
  var maxDuration = Math.max(1500, Number(cfg.maxDuration || 4500));

  function now(){return (window.performance && performance.now) ? performance.now() : Date.now()}
  function esc(value){return String(value == null ? '' : value).replace(/[&<>"']/g,function(ch){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]})}
  function safeStyle(){
    var style = String(cfg.style || 'logo').toLowerCase();
    return ['logo','rings','pulse','dots','cinema'].indexOf(style) >= 0 ? style : 'logo';
  }
  function coreMarkup(){
    var style = safeStyle();
    var stage = '';
    if(style === 'logo' && cfg.showLogo !== false && cfg.logo){
      stage = '<div class="bm-loading-stage"><span class="bm-loading-orbit"></span><img class="bm-loading-logo" src="'+esc(cfg.logo)+'" alt="BankMovie" decoding="async"></div>';
    }else if(style === 'pulse'){
      stage = '<div class="bm-loading-stage"><span class="bm-loading-pulse"></span></div>';
    }else if(style === 'dots'){
      stage = '<div class="bm-loading-stage"><span class="bm-loading-dots"><i></i><i></i><i></i><i></i></span></div>';
    }else if(style === 'cinema'){
      stage = '<div class="bm-loading-stage"><span class="bm-loading-cinema"><i></i></span></div>';
    }else{
      stage = '<div class="bm-loading-stage"><span class="bm-loading-rings"><i></i><i></i><i></i></span></div>';
    }
    var text = cfg.showText === false ? '' : '<p class="bm-loading-text" data-bm-loading-text>'+esc(cfg.text || '')+'</p>';
    return stage + text + '<div class="bm-loading-progress" aria-hidden="true"><span></span></div>';
  }
  function ensureOverlay(){
    overlay = document.getElementById('loadingOverlay');
    if(!cfg.enabled){
      if(overlay) overlay.remove();
      document.documentElement.classList.remove('bm-loading-lock');
      return null;
    }
    if(!overlay){
      overlay = document.createElement('div');
      overlay.id = 'loadingOverlay';
      overlay.className = 'loading-overlay';
      (document.body || document.documentElement).prepend(overlay);
    }
    overlay.classList.add('bm-loading-managed','bm-loading-style-'+safeStyle());
    overlay.classList.remove('hide');
    overlay.style.removeProperty('display');
    overlay.dataset.bmHold = '1';
    overlay.setAttribute('role','status');
    overlay.setAttribute('aria-live','polite');
    overlay.setAttribute('aria-busy','true');
    overlay.innerHTML = coreMarkup();
    document.documentElement.classList.add('bm-loading-lock');
    return overlay;
  }
  function finish(force){
    if(!overlay || released) return;
    var remaining = minDuration - (now() - startedAt);
    if(!force && remaining > 0){
      hideRequested = true;
      window.setTimeout(function(){finish(false)},remaining + 8);
      return;
    }
    released = true;
    overlay.removeAttribute('data-bm-hold');
    overlay.setAttribute('aria-busy','false');
    overlay.classList.add('hide');
    document.documentElement.classList.remove('bm-loading-lock');
    window.setTimeout(function(){if(overlay) overlay.style.display='none'},430);
  }
  function show(text){
    released = false;
    hideRequested = false;
    startedAt = now();
    if(!overlay || !document.documentElement.contains(overlay)) ensureOverlay();
    if(!overlay) return;
    overlay.style.removeProperty('display');
    overlay.classList.remove('hide');
    overlay.dataset.bmHold='1';
    overlay.setAttribute('aria-busy','true');
    document.documentElement.classList.add('bm-loading-lock');
    if(typeof text === 'string'){
      var node=overlay.querySelector('[data-bm-loading-text]');
      if(node) node.textContent=text;
    }
  }
  function configureRoot(){
    var root=document.documentElement;
    root.style.setProperty('--bm-loading-accent',cfg.useThemeAccent === false ? (cfg.accent || '#2f7cff') : 'var(--bm-accent, '+(cfg.accent || '#2f7cff')+')');
    root.style.setProperty('--bm-loading-accent-rgb',cfg.accentRgb || '47,124,255');
    root.style.setProperty('--bm-loading-bg-rgb',cfg.backgroundRgb || '5,7,13');
    root.style.setProperty('--bm-loading-bg-opacity',String(cfg.backgroundOpacity == null ? .96 : cfg.backgroundOpacity));
    root.style.setProperty('--bm-loading-blur',String(Number(cfg.blur || 0))+'px');
    root.style.setProperty('--bm-loading-size',String(Number(cfg.size || 104))+'px');
    root.style.setProperty('--bm-loading-skeleton-speed',String(Number(cfg.skeletonSpeed || 1250))+'ms');
    root.classList.toggle('bm-skeleton-disabled',cfg.skeletonEnabled === false);
  }
  function watchLegacyChanges(){
    if(!overlay || !window.MutationObserver) return;
    new MutationObserver(function(){
      if(released) return;
      if(overlay.classList.contains('hide') || overlay.style.display === 'none'){
        hideRequested = true;
        overlay.dataset.bmHold='1';
      }
    }).observe(overlay,{attributes:true,attributeFilter:['class','style']});
  }

  configureRoot();
  ensureOverlay();
  watchLegacyChanges();
  window.BMLoading = {show:show,hide:function(){finish(false)},forceHide:function(){finish(true)},setText:function(text){var n=overlay&&overlay.querySelector('[data-bm-loading-text]');if(n)n.textContent=String(text||'')}};
  window.addEventListener('load',function(){loaded=true;finish(false)},{once:true});
  if(loaded) finish(false);
  window.setTimeout(function(){finish(true)},maxDuration);
  window.setTimeout(function(){if(hideRequested && loaded) finish(false)},Math.max(0,minDuration)+20);
})();
