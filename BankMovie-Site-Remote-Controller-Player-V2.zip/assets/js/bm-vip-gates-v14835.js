(() => {
  'use strict';
  const cfg = window.BM_VIP_GATES || {};
  const locks = cfg.locks || {};
  if (!Object.values(locks).some(Boolean)) return;

  let toast = document.getElementById('bmVipGateToast');
  let timer = 0;
  function show(message) {
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(timer);
    timer = window.setTimeout(() => toast.classList.remove('show'), 2600);
  }
  function salesUrl(feature) {
    const u = new URL('/vip', location.origin);
    u.searchParams.set('feature', feature);
    u.searchParams.set('return', location.pathname + location.search + location.hash);
    return u.href;
  }
  function classify(target) {
    const explicit = target.getAttribute('data-bm-vip-gate');
    if (explicit) return explicit;
    if (target.matches('.bm-watch-together-btn')) return 'watch_party';
    if (target.matches('.watchlist-btn,#watchlistBtn,[data-watchlist-action]')) return 'watchlist';
    if (target.matches('.submit-comment,.comment-submit,#submitCommentBtn,.submit-reply,.reply-btn,.comment-like,.comment-dislike,.edit-comment-btn,.report-comment-btn,.star-input,[data-comment-action]')) return 'comments_ratings';
    if (target.matches('.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]')) return 'subtitle_downloads';
    if (target.matches('a[download],.arc1-dl-btn,.download-icon,#downloadCurrentBtn,[data-bm-manager-download]')) return 'downloads';
    if (target.matches('.bm-local-play-choice,.bm-poster-play,[data-play-url],[data-video-url]')) return 'online_watch';
    return '';
  }
  function all(root, selector) {
    const nodes = [];
    if (root instanceof Element && root.matches(selector)) nodes.push(root);
    if (root.querySelectorAll) nodes.push(...root.querySelectorAll(selector));
    return nodes;
  }
  function markKnownTargets(root = document) {
    all(root, '.watchlist-btn,#watchlistBtn,[data-watchlist-action]').forEach(el => el.setAttribute('data-bm-vip-gate', 'watchlist'));
    all(root, '.submit-comment,.comment-submit,#submitCommentBtn,.submit-reply,.reply-btn,.comment-like,.comment-dislike,.edit-comment-btn,.report-comment-btn,.star-input,[data-comment-action]').forEach(el => el.setAttribute('data-bm-vip-gate', 'comments_ratings'));
    all(root, '.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]').forEach(el => el.setAttribute('data-bm-vip-gate', 'subtitle_downloads'));
    all(root, 'a[download],.arc1-dl-btn,.download-icon,#downloadCurrentBtn,[data-bm-manager-download]').forEach(el => {
      if (!el.matches('.arc1-sub-dl-btn,[title*="زیرنویس"],[data-subtitle-url]')) el.setAttribute('data-bm-vip-gate', 'downloads');
    });
    all(root, '.bm-local-play-choice,.bm-poster-play,[data-play-url],[data-video-url]').forEach(el => {
      if (!el.matches('.bm-watch-together-btn')) el.setAttribute('data-bm-vip-gate', 'online_watch');
    });
  }

  markKnownTargets();
  const observer = new MutationObserver(records => {
    records.forEach(record => record.addedNodes.forEach(node => {
      if (node.nodeType === 1) markKnownTargets(node);
    }));
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  document.addEventListener('click', event => {
    const target = event.target.closest('a,button');
    if (!target) return;
    const feature = classify(target);
    if (!feature || feature === 'watch_party' || !locks[feature]) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    show('این قابلیت برای اعضای VIP فعال است.');
    window.setTimeout(() => { location.href = salesUrl(feature); }, 500);
  }, true);
})();
