/* BankMovie movie interaction-demand loader v91
 * Comments, action tools and players are fetched only when the visitor asks for them.
 */
(function(){
  'use strict';

  const loaded = Object.create(null);
  let commentsPromise = null;
  let actionsPromise = null;
  let normalPlayerPromise = null;
  let arcPlayerPromise = null;

  function loadScript(src){
    if(!src) return Promise.resolve();
    if(loaded[src]) return loaded[src];
    loaded[src] = new Promise(function(resolve,reject){
      const script = document.createElement('script');
      script.src = src;
      script.async = false;
      script.dataset.bmDemand = 'movie';
      script.onload = resolve;
      script.onerror = function(){ reject(new Error('Failed to load ' + src)); };
      document.body.appendChild(script);
    });
    return loaded[src];
  }

  function setBusy(element, busy){
    if(!element || !element.setAttribute) return;
    if(busy){
      element.setAttribute('aria-busy','true');
      element.classList.add('bm-demand-loading');
    }else{
      element.removeAttribute('aria-busy');
      element.classList.remove('bm-demand-loading');
    }
  }

  function loadComments(){
    if(commentsPromise) return commentsPromise;
    commentsPromise = loadScript('/assets/js/movie-comments.js?v=demand91').then(function(){
      if(typeof window.attachCommentEvents === 'function') window.attachCommentEvents();
      if(typeof window.attachReplyButtons === 'function') window.attachReplyButtons();
      if(typeof window.attachDeleteButtons === 'function') window.attachDeleteButtons();
      document.documentElement.classList.add('bm-comments-ready');
    }).catch(function(error){
      commentsPromise = null;
      console.error('BankMovie comments failed to load', error);
      throw error;
    });
    return commentsPromise;
  }

  function loadActions(){
    if(actionsPromise) return actionsPromise;
    actionsPromise = loadScript('/assets/js/movie-actions.js?v=demand91').then(function(){
      document.documentElement.classList.add('bm-movie-actions-ready');
    }).catch(function(error){
      actionsPromise = null;
      console.error('BankMovie actions failed to load', error);
      throw error;
    });
    return actionsPromise;
  }

  function loadNormalPlayer(){
    if(normalPlayerPromise) return normalPlayerPromise;
    normalPlayerPromise = loadScript('/assets/js/movie-play-choice.js?v=demand91')
      .then(function(){ return loadScript('/assets/js/movie-subtitles.js?v=demand91'); })
      .then(function(){ return loadScript('/assets/js/movie-player-core.js?v=demand91'); })
      .then(function(){ document.documentElement.classList.add('bm-normal-player-ready'); })
      .catch(function(error){
        normalPlayerPromise = null;
        console.error('BankMovie player failed to load', error);
        throw error;
      });
    return normalPlayerPromise;
  }

  function loadArcPlayer(){
    if(arcPlayerPromise) return arcPlayerPromise;
    arcPlayerPromise = loadScript('/assets/js/movie-play-choice.js?v=demand91')
      .then(function(){ return loadScript('/assets/js/movie-inline-5.js?v=demand91'); })
      .then(function(){ document.documentElement.classList.add('bm-arc-player-ready'); })
      .catch(function(error){
        arcPlayerPromise = null;
        console.error('BankMovie archive player failed to load', error);
        throw error;
      });
    return arcPlayerPromise;
  }

  const COMMENT_SELECTOR = [
    '#commentText','#submitCommentBtn','#spoilerTagBtn','#loadMoreCommentsBtn','.star-input',
    '.comment-like','.comment-dislike','.reply-btn','.delete-comment-btn','.edit-comment-btn',
    '.report-comment-btn','.pin-comment-btn','.reply-form-container','.comments-section','#commentsSection'
  ].join(',');

  const ACTION_SELECTOR = [
    '#watchlistBtn','#subkadeBtn','.bm-share-open','#shareBtn','[data-bm-share-close]',
    '[data-share-platform]','#reportBtn','#helpModalBtn','#closeHelpModal','#donateModalBtn',
    '#playerDonateSideBtn','#closeDonateModal','#openDonateLink'
  ].join(',');

  const NORMAL_PLAYER_SELECTOR = [
    'a[href="#playerWrapper"]','#playerWrapper','#videoPlayer','.quality-btn','.season-btn',
    '.bm-local-play-choice','.bm-download-play-choice','.bm-poster-play','[data-bm-play-action]',
    '[data-bm-play-close]','#playPauseBtn','#settingsBtn','#fullscreenBtn'
  ].join(',');

  const ARC_PLAYER_SELECTOR = [
    '#arc1PlayerWrapper','#arc1PlayerInner','#arc1VideoEl','.arc1-play-btn',
    '.arc1-play-inline','.bm-local-play-choice','[data-bm-play-action]','[data-bm-play-close]',
    '#arc1PlayPause','#arc1SettingsBtn','#arc1Fullscreen'
  ].join(',');

  function closest(target, selector){
    return target && target.closest ? target.closest(selector) : null;
  }

  function replayClick(target){
    if(!target || !document.contains(target)) return;
    target.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,view:window}));
  }

  function interceptAndReplay(event, target, promise){
    event.preventDefault();
    event.stopImmediatePropagation();
    setBusy(target,true);
    promise.then(function(){
      setBusy(target,false);
      replayClick(target);
    }).catch(function(){ setBusy(target,false); });
  }

  document.addEventListener('click', function(event){
    const target = event.target;
    const commentTarget = closest(target, COMMENT_SELECTOR);
    if(commentTarget && !document.documentElement.classList.contains('bm-comments-ready')){
      interceptAndReplay(event, commentTarget, loadComments());
      return;
    }

    const actionTarget = closest(target, ACTION_SELECTOR);
    if(actionTarget && !document.documentElement.classList.contains('bm-movie-actions-ready')){
      interceptAndReplay(event, actionTarget, loadActions());
      return;
    }

    const isArc = !!window.BM_MOVIE_HAS_ARC1_PLAYER;
    const playerTarget = closest(target, isArc ? ARC_PLAYER_SELECTOR : NORMAL_PLAYER_SELECTOR);
    const playerReady = document.documentElement.classList.contains(isArc ? 'bm-arc-player-ready' : 'bm-normal-player-ready');
    if(playerTarget && !playerReady){
      interceptAndReplay(event, playerTarget, isArc ? loadArcPlayer() : loadNormalPlayer());
    }
  }, true);

  document.addEventListener('focusin', function(event){
    if(closest(event.target, COMMENT_SELECTOR)) loadComments().catch(function(){});
  }, true);

  // Touch starts loading slightly before click, but still only after an explicit user gesture.
  document.addEventListener('pointerdown', function(event){
    const target = event.target;
    if(closest(target, COMMENT_SELECTOR)) loadComments().catch(function(){});
    if(closest(target, ACTION_SELECTOR)) loadActions().catch(function(){});
    const isArc = !!window.BM_MOVIE_HAS_ARC1_PLAYER;
    if(closest(target, isArc ? ARC_PLAYER_SELECTOR : NORMAL_PLAYER_SELECTOR)){
      (isArc ? loadArcPlayer() : loadNormalPlayer()).catch(function(){});
    }
  }, {capture:true,passive:true});

  window.BM_LOAD_MOVIE_COMMENTS = loadComments;
  window.BM_LOAD_MOVIE_ACTIONS = loadActions;
  window.BM_LOAD_MOVIE_PLAYER = function(){
    return window.BM_MOVIE_HAS_ARC1_PLAYER ? loadArcPlayer() : loadNormalPlayer();
  };
})();
