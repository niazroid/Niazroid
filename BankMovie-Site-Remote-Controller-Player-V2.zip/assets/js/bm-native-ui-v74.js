/* BankMovie V74 — Native UI controller */
(function(d,w){
  'use strict';

  const fa=(d.documentElement.lang||'fa').toLowerCase().startsWith('fa');
  let root=null,resolver=null,previousFocus=null,selectedValue=null;

  const icons={
    info:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></svg>',
    question:'<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.4 2.4 0 1 1 3.9 1.9c-1.2.8-1.7 1.3-1.7 2.6M12 17h.01"/></svg>',
    danger:'<svg viewBox="0 0 24 24"><path d="M10.3 3.7 2.5 17.2A2 2 0 0 0 4.2 20h15.6a2 2 0 0 0 1.7-2.8L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>',
    edit:'<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>'
  };

  function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}

  function ensure(){
    if(root)return root;
    root=d.createElement('div');
    root.className='bm-dialog-root';
    root.setAttribute('aria-hidden','true');
    root.innerHTML=`
      <div class="bm-dialog-backdrop" data-bm-dialog-cancel></div>
      <section class="bm-dialog-card" role="dialog" aria-modal="true" aria-labelledby="bmDialogTitle">
        <div class="bm-dialog-head">
          <div class="bm-dialog-icon" data-bm-dialog-icon></div>
          <div class="bm-dialog-copy">
            <h2 class="bm-dialog-title" id="bmDialogTitle"></h2>
            <p class="bm-dialog-message" data-bm-dialog-message></p>
          </div>
        </div>
        <div data-bm-dialog-content></div>
        <div class="bm-dialog-actions">
          <button class="bm-dialog-btn" type="button" data-bm-dialog-cancel></button>
          <button class="bm-dialog-btn primary" type="button" data-bm-dialog-confirm></button>
        </div>
      </section>`;
    d.body.appendChild(root);

    root.addEventListener('click',e=>{
      const option=e.target.closest('[data-bm-dialog-option]');
      if(option){
        root.querySelectorAll('[data-bm-dialog-option]').forEach(x=>x.classList.remove('is-selected'));
        option.classList.add('is-selected');
        selectedValue=option.dataset.bmDialogOption??'';
        return;
      }
      if(e.target.closest('[data-bm-dialog-cancel]'))finish(false);
      if(e.target.closest('[data-bm-dialog-confirm]'))finish(true);
    });

    d.addEventListener('keydown',e=>{
      if(!root?.classList.contains('is-open'))return;
      if(e.key==='Escape'){e.preventDefault();finish(false);return;}
      if(e.key==='Enter'&&!e.shiftKey&&!e.target.matches('textarea')){
        if(d.activeElement!==root.querySelector('[data-bm-dialog-cancel].bm-dialog-btn')){
          e.preventDefault();finish(true);
        }
      }
    });
    return root;
  }

  function finish(ok){
    if(!root||!resolver)return;
    const type=root.dataset.type||'confirm';
    const input=root.querySelector('[data-bm-dialog-input]');
    let value=ok;
    if(type==='prompt')value=ok?(input?.value??''):null;
    if(type==='select')value=ok?selectedValue:null;
    if(type==='alert')value=true;
    const resolve=resolver;resolver=null;
    root.classList.remove('is-open','is-danger');
    root.setAttribute('aria-hidden','true');
    d.body.classList.remove('bm-dialog-open');
    setTimeout(()=>{
      try{previousFocus?.focus?.({preventScroll:true});}catch(_e){}
      resolve(value);
    },70);
  }

  function open(cfg={}){
    ensure();
    if(resolver)return Promise.resolve(null);
    previousFocus=d.activeElement;
    selectedValue=cfg.value??null;
    root.dataset.type=cfg.type||'confirm';
    root.classList.toggle('is-danger',!!cfg.danger);
    root.querySelector('[data-bm-dialog-icon]').innerHTML=icons[cfg.icon||(cfg.danger?'danger':'question')]||icons.question;
    root.querySelector('.bm-dialog-title').textContent=cfg.title||(fa?'تأیید عملیات':'Confirm');
    root.querySelector('[data-bm-dialog-message]').textContent=cfg.message||'';

    const content=root.querySelector('[data-bm-dialog-content]');
    content.innerHTML='';

    if(cfg.type==='prompt'){
      const wrap=d.createElement('div');
      wrap.className='bm-dialog-field';
      wrap.innerHTML=`${cfg.label?`<label class="bm-dialog-label">${esc(cfg.label)}</label>`:''}
      ${cfg.multiline===false
        ?`<input class="bm-dialog-input" data-bm-dialog-input value="${esc(cfg.value||'')}" placeholder="${esc(cfg.placeholder||'')}">`
        :`<textarea class="bm-dialog-textarea" data-bm-dialog-input placeholder="${esc(cfg.placeholder||'')}">${esc(cfg.value||'')}</textarea>`}`;
      content.appendChild(wrap);
    }

    if(cfg.type==='select'){
      const options=d.createElement('div');
      options.className='bm-dialog-options';
      (cfg.options||[]).forEach((opt,i)=>{
        const b=d.createElement('button');
        b.type='button';
        const chosen=(selectedValue!==null&&String(selectedValue)===String(opt.value))||(selectedValue===null&&i===0);
        b.className='bm-dialog-option'+(chosen?' is-selected':'');
        b.dataset.bmDialogOption=String(opt.value);
        b.textContent=opt.label;
        options.appendChild(b);
        if(chosen)selectedValue=String(opt.value);
      });
      content.appendChild(options);
    }

    const cancel=root.querySelector('[data-bm-dialog-cancel].bm-dialog-btn');
    const confirm=root.querySelector('[data-bm-dialog-confirm]');
    cancel.textContent=cfg.cancelText||(fa?'انصراف':'Cancel');
    confirm.textContent=cfg.confirmText||(cfg.type==='alert'?(fa?'باشه':'OK'):(fa?'تأیید':'Confirm'));
    cancel.style.display=cfg.type==='alert'?'none':'';

    root.classList.add('is-open');
    root.setAttribute('aria-hidden','false');
    d.body.classList.add('bm-dialog-open');

    requestAnimationFrame(()=>{
      const target=root.querySelector('[data-bm-dialog-input]')||root.querySelector('.bm-dialog-option.is-selected')||confirm;
      try{target?.focus?.({preventScroll:true});}catch(_e){}
    });
    return new Promise(resolve=>{resolver=resolve;});
  }

  const API={
    confirm:(cfg={})=>open({...cfg,type:'confirm'}),
    alert:(cfg={})=>open({...cfg,type:'alert',icon:cfg.icon||'info'}),
    prompt:(cfg={})=>open({...cfg,type:'prompt',icon:cfg.icon||'edit'}),
    select:(cfg={})=>open({...cfg,type:'select',icon:cfg.icon||'question'})
  };
  w.BMDialog=API;

  /* Async custom replacement for non-return-value alerts. */
  w.alert=function(message){
    API.alert({title:fa?'پیام بانک مووی':'BankMovie',message:String(message??'')});
  };

  function decodeInlineMessage(code){
    if(!code)return fa?'این عملیات انجام شود؟':'Continue?';
    const m=String(code).match(/confirm\s*\(\s*(['"`])([\s\S]*?)\1\s*\)/i);
    if(!m)return fa?'این عملیات انجام شود؟':'Continue?';
    return m[2]
      .replace(/\\n/g,'\n')
      .replace(/\\'/g,"'")
      .replace(/\\"/g,'"')
      .replace(/\\\\/g,'\\');
  }

  /* Any inline onclick="return confirm(...)" gets a BankMovie modal.
     This covers logout/avatar and other legacy public links/buttons without editing old PHP files. */
  d.addEventListener('click',async e=>{
    const el=e.target.closest('[onclick*="confirm("]');
    if(!el||el.dataset.bm74ConfirmBypass==='1')return;

    const code=el.getAttribute('onclick')||'';
    e.preventDefault();
    e.stopImmediatePropagation();

    const message=decodeInlineMessage(code);
    const danger=/حذف|پاک|delete|remove|دائمی|permanent/i.test(message);
    const ok=await API.confirm({
      danger,
      icon:danger?'danger':'question',
      title:danger?(fa?'تأیید عملیات حساس':'Confirm action'):(fa?'تأیید':'Confirm'),
      message,
      confirmText:danger?(fa?'بله، انجام شود':'Continue'):(fa?'تأیید':'Confirm'),
      cancelText:fa?'انصراف':'Cancel'
    });
    if(!ok)return;

    const old=el.getAttribute('onclick');
    el.dataset.bm74ConfirmBypass='1';
    el.removeAttribute('onclick');
    try{
      if(el.tagName==='A'){
        const href=el.getAttribute('href');
        const target=el.getAttribute('target');
        if(target==='_blank')w.open(el.href,'_blank','noopener');
        else if(href&&href!=='#')w.location.href=el.href;
        else el.click();
      }else{
        el.click();
      }
    }finally{
      setTimeout(()=>{
        if(old!==null)el.setAttribute('onclick',old);
        delete el.dataset.bm74ConfirmBypass;
      },0);
    }
  },true);

  /* Any inline onsubmit="return confirm(...)" is also intercepted. */
  d.addEventListener('submit',async e=>{
    const form=e.target;
    if(!(form instanceof HTMLFormElement))return;
    const code=form.getAttribute('onsubmit')||'';
    if(!/confirm\s*\(/i.test(code)||form.dataset.bm74ConfirmBypass==='1')return;

    e.preventDefault();
    e.stopImmediatePropagation();

    const message=decodeInlineMessage(code);
    const danger=/حذف|پاک|delete|remove|دائمی|permanent|reset|پیش.?فرض/i.test(message);
    const ok=await API.confirm({
      danger,
      icon:danger?'danger':'question',
      title:danger?(fa?'تأیید عملیات حساس':'Confirm action'):(fa?'تأیید':'Confirm'),
      message,
      confirmText:danger?(fa?'بله، انجام شود':'Continue'):(fa?'تأیید':'Confirm'),
      cancelText:fa?'انصراف':'Cancel'
    });
    if(!ok)return;

    const old=form.getAttribute('onsubmit');
    form.dataset.bm74ConfirmBypass='1';
    form.removeAttribute('onsubmit');
    try{
      if(typeof form.requestSubmit==='function')form.requestSubmit(e.submitter||undefined);
      else form.submit();
    }finally{
      setTimeout(()=>{
        if(old!==null)form.setAttribute('onsubmit',old);
        delete form.dataset.bm74ConfirmBypass;
      },0);
    }
  },true);

  function autoPolish(){
    /* Only truly plain, unclassified controls. Existing designed components are left alone. */
    d.querySelectorAll('button:not([class])').forEach(el=>{
      if(el.hasAttribute('style'))return;
      if([...el.attributes].some(a=>a.name.startsWith('data-')))return;
      el.classList.add('bm74-native-button');
    });
    d.querySelectorAll('select:not([class])').forEach(el=>{
      if(el.closest('.filter-control-wrap,.request-field,.bm-bulk-format'))return;
      el.classList.add('bm74-native-select');
    });
    d.querySelectorAll('input:not([class])').forEach(el=>{
      const type=(el.type||'text').toLowerCase();
      if(['hidden','checkbox','radio','file','range','color'].includes(type))return;
      if(el.hasAttribute('style'))return;
      if(el.closest('.filter-control-wrap,.request-field,.bm-share-url,.bm-cat-search'))return;
      el.classList.add('bm74-native-input');
    });
    d.querySelectorAll('textarea:not([class])').forEach(el=>{
      if(el.hasAttribute('style'))return;
      el.classList.add('bm74-native-input');
    });
  }

  if(d.readyState==='loading')d.addEventListener('DOMContentLoaded',autoPolish,{once:true});
  else autoPolish();

  w.BM_NATIVE_UI_V74={ready:true};
})(document,window);
