(function () {
  const html = document.documentElement;
  const lang = (html.getAttribute('lang') || '').toLowerCase();
  const isRTL = html.getAttribute('dir') === 'rtl' || lang.startsWith('fa') || lang.startsWith('ar');

  function forceDarkOnly() {
    if (!document.body) return;
    document.body.classList.remove('bm-force-rtl', 'bm-force-ltr', 'bm-surface-light');
    document.body.classList.add(isRTL ? 'bm-force-rtl' : 'bm-force-ltr', 'bm-surface-dark');
    document.body.setAttribute('data-surface-scheme', 'dark');
    try {
      localStorage.setItem('bm_surface_scheme', 'dark');
      document.cookie = 'bm_surface_scheme=dark; path=/; max-age=31536000; SameSite=Lax';
    } catch (e) {}
  }

  function makeIconLink(cls, href, label, svg) {
    const link = document.createElement('a');
    link.className = cls;
    link.href = href;
    link.setAttribute('aria-label', label);
    link.setAttribute('title', label);
    link.innerHTML = svg;
    return link;
  }

  const searchSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>';
  const requestSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"></path><path d="M8 10h8"></path><path d="M8 14h5"></path></svg>';

  function patchHeader() {
    document.querySelectorAll('.header .header-actions').forEach((actions) => {
      actions.querySelectorAll('.bm-theme-toggle, .toggle').forEach(el => el.remove());
      if (!actions.querySelector('.bm-header-search')) actions.insertBefore(makeIconLink('bm-header-search', '/search', 'جستجو', searchSvg), actions.firstChild);
      if (!actions.querySelector('.bm-header-request')) {
        const req = makeIconLink('bm-header-request', '/request', 'درخواست فیلم و سریال', requestSvg);
        const menu = actions.querySelector('.menu-btn');
        if (menu) actions.insertBefore(req, menu); else actions.appendChild(req);
      }
    });
  }

  function enhanceSearchPage() {
    if (!document.body || !/search\.php$/i.test(location.pathname)) return;
    const section = document.querySelector('.search-section');
    const form = document.getElementById('mainSearchForm');
    const input = form?.querySelector('.search-input');
    if (!section || !form || !input || section.querySelector('.bm-search-fast-tabs')) return;

    const params = new URLSearchParams(location.search);
    const makeHref = (changes) => {
      const p = new URLSearchParams(location.search);
      Object.entries(changes).forEach(([k, v]) => { if (v === null) p.delete(k); else p.set(k, v); });
      p.delete('page');
      const q = p.toString();
      return '/search' + (q ? '?' + q : '');
    };
    const currentType = params.get('type') || 'all';
    const currentDub = params.get('dub_type') || 'all';
    const tabs = document.createElement('div');
    tabs.className = 'bm-search-fast-tabs';
    tabs.innerHTML = [
      ['همه', makeHref({type:'all', dub_type:'all'}), currentType === 'all' && currentDub === 'all'],
      ['فیلم', makeHref({type:'movie'}), currentType === 'movie'],
      ['سریال', makeHref({type:'series'}), currentType === 'series'],
      ['دوبله', makeHref({dub_type:'dubbed'}), currentDub === 'dubbed'],
      ['زیرنویس', makeHref({dub_type:'softsub'}), currentDub === 'softsub']
    ].map(([label, href, active]) => `<a class="bm-search-tab ${active ? 'active' : ''}" href="${href}">${label}</a>`).join('');
    section.insertBefore(tabs, form.nextSibling);

    const clear = document.createElement('button');
    clear.type = 'button';
    clear.className = 'bm-search-clear';
    clear.setAttribute('aria-label', 'پاک کردن جستجو');
    clear.innerHTML = '×';
    form.appendChild(clear);
    const sync = () => { form.classList.toggle('has-value', !!input.value.trim()); };
    input.addEventListener('input', sync);
    input.addEventListener('focus', () => form.classList.add('is-focused'));
    input.addEventListener('blur', () => form.classList.remove('is-focused'));
    clear.addEventListener('click', () => { input.value = ''; sync(); input.focus(); });
    sync();
  }

  function init() { forceDarkOnly(); patchHeader(); enhanceSearchPage(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();