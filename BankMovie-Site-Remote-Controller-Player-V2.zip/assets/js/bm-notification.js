(function(){
    var notificationId = (window.BM_NOTIFICATION_ID || '');
    function setSeenCookie(id){
        if(!id) return;
        var secure = location.protocol === 'https:' ? '; Secure' : '';
        document.cookie = 'notification_seen_' + encodeURIComponent(id) + '=1; path=/; max-age=' + (60*60*24*30) + '; SameSite=Lax' + secure;
    }
    function hideModal(){
        var modal = document.getElementById('notificationModal');
        var btn = document.getElementById('closeNotificationBtn');
        if(btn){ btn.disabled = true; btn.style.opacity = '.75'; btn.style.cursor = 'default'; }
        if(modal){
            modal.style.transition = 'opacity .18s ease, visibility .18s ease';
            modal.style.opacity = '0';
            modal.style.visibility = 'hidden';
            modal.style.pointerEvents = 'none';
            setTimeout(function(){ if(modal && modal.parentNode) modal.parentNode.removeChild(modal); }, 220);
        }
    }
    function sendSeen(id){
        if(!id || !window.fetch) return;
        var tokenEl = document.querySelector('meta[name="csrf-token"]');
        var token = tokenEl ? tokenEl.getAttribute('content') : '';
        var body = new URLSearchParams();
        body.set('notification_id', id);
        if(token) body.set('csrf_token', token);
        try {
            fetch('/mark_notification_seen.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: body.toString(),
                keepalive: true
            }).catch(function(){});
        } catch(e) {}
    }
    window.bmAcknowledgeNotification = function(id){
        id = id || notificationId || '';
        setSeenCookie(id);
        hideModal();
        sendSeen(id);
        return false;
    };
    document.addEventListener('click', function(e){
        var btn = e.target && e.target.closest ? e.target.closest('#closeNotificationBtn') : null;
        if(!btn) return;
        e.preventDefault();
        e.stopPropagation();
        if(e.stopImmediatePropagation) e.stopImmediatePropagation();
        window.bmAcknowledgeNotification(btn.getAttribute('data-notification-id') || notificationId || '');
    }, true);
})();
