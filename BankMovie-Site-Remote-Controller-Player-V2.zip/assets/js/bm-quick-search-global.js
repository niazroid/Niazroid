(function(){
    'use strict';
    if(!window.BM_QUICK_SEARCH_GLOBAL_PAGE) return;

    var input = document.getElementById('unifiedSearchInput');
    var results = document.getElementById('unifiedSearchResults');
    if(!input || !results) return;

    var config = window.BM_HOME_CONFIG || {};
    var isFa = (config.userLang || 'fa') === 'fa';
    var timer = 0;
    var controller = null;
    var fallbackPoster = '/uploads/no.png';

    function esc(value){
        return String(value == null ? '' : value).replace(/[&<>"']/g, function(ch){
            return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch];
        });
    }
    function normalize(value){
        if(typeof window.bmNormalizeSearchTerm === 'function') return window.bmNormalizeSearchTerm(value);
        return String(value || '').trim();
    }
    function archive(){
        if(typeof window.bmQuickSearchGetArchive === 'function') return window.bmQuickSearchGetArchive();
        return window.BM_QUICK_SEARCH_ARCHIVE || config.activeArchive || 'local';
    }
    function slug(value){
        return String(value || 'movie').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-+/g,'-') || 'movie';
    }
    function localUrl(item){
        var id = item.id || item.movie_id || '';
        return '/movie/' + slug(item.title || item.title_en || item.movie_title_en || item.title_fa || 'movie') + (id ? '-' + encodeURIComponent(id) : '');
    }
    function arc1Url(item){
        var id = item.detail_id || item.external_id || item.source_key || item.slug || item.id || '';
        return id ? '/movie/arc1-' + encodeURIComponent(id) : (item.url || '#');
    }
    function arc3Url(item){
        var id = item.detail_id || (item.source_post_id ? 'p' + item.source_post_id : '') || item.slug || item.id || item.imdb_code || '';
        return id ? '/movie/arc3-' + encodeURIComponent(id) : (item.url || '#');
    }
    function arc4Url(item){
        var id = item.detail_id || (item.source_post_id ? 'p' + item.source_post_id : '') || item.slug || item.id || item.imdb_code || '';
        return id ? '/movie/arc4-' + encodeURIComponent(id) : (item.url || '#');
    }
    function imdb(value){
        var num = parseFloat(value || 0);
        if(!num) return '';
        return '<span class="meta-imdb"><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"><span>' + esc(num.toFixed(1)) + '</span></span>';
    }
    function empty(text){
        results.innerHTML = '<div class="empty-search-state" style="padding:20px;text-align:center">' + esc(text) + '</div>';
        results.classList.add('active');
    }
    function bindItems(){
        results.querySelectorAll('.search-result-item[data-url]').forEach(function(item){
            item.addEventListener('click', function(){ window.location.href = item.getAttribute('data-url') || '/'; });
        });
    }
    function viewAll(mode, term){
        if(mode === 'arc1') return '/view_all?type=arc1_search&q=' + encodeURIComponent(term);
        if(mode === 'arc3') return '/view_all?type=arc3_search&q=' + encodeURIComponent(term);
        if(mode === 'arc4') return '/view_all?type=arc4_search&q=' + encodeURIComponent(term);
        return '/search?q=' + encodeURIComponent(term);
    }
    function render(mode, data, term){
        var items = mode === 'local' ? ((data && data.data) || []) : ((data && data.movies) || []);
        if(!items.length){
            empty(isFa ? 'نتیجه‌ای یافت نشد' : 'No results found');
            return;
        }
        var html = '';
        items.slice(0,20).forEach(function(item){
            var title = '';
            var original = '';
            var poster = '';
            var year = item.year || '?';
            var rating = item.rating || item.imdb || item.imdb_rate || 0;
            var link = '#';
            var badge = '';
            if(mode === 'arc1'){
                title = String(item.title || '').replace(/old|فیلم 2 مدیا|film2media/gi,'').trim();
                original = item.type === 'series' ? (isFa ? 'سریال' : 'Series') : (isFa ? 'فیلم' : 'Movie');
                if(item.has_dubbed) original += isFa ? ' · دوبله' : ' · Dubbed';
                poster = item.poster || '';
                link = arc1Url(item);
                badge = isFa ? 'آرشیو ۱' : 'Archive 1';
            }else if(mode === 'arc3'){
                title = item.title_fa || item.title || '';
                original = item.media_kind === 'animation' ? (isFa ? 'انیمیشن' : 'Animation') : (item.type === 'series' ? (isFa ? 'سریال' : 'Series') : ((item.media_kind === 'anime' || item.type === 'anime') ? (isFa ? 'انیمه' : 'Anime') : (isFa ? 'فیلم' : 'Movie')));
                if(item.has_online) original += isFa ? ' · پخش آنلاین' : ' · Online';
                poster = item.poster || '';
                link = arc3Url(item);
                badge = isFa ? 'آرشیو ۳' : 'Archive 3';
            }else if(mode === 'arc4'){
                title = item.title_fa || item.title || '';
                original = item.media_kind === 'animation' ? (isFa ? 'انیمیشن' : 'Animation') : (item.type === 'series' ? (isFa ? 'سریال' : 'Series') : ((item.media_kind === 'anime' || item.type === 'anime') ? (isFa ? 'انیمه' : 'Anime') : (isFa ? 'فیلم' : 'Movie')));
                if(item.has_online) original += isFa ? ' · پخش آنلاین' : ' · Online';
                poster = item.poster || '';
                link = arc4Url(item);
                badge = isFa ? 'آرشیو ۴' : 'Archive 4';
            }else{
                title = item.title_fa || item.title || '';
                original = (item.title && item.title_fa && item.title !== item.title_fa) ? item.title : (item.type === 'series' ? (isFa ? 'سریال' : 'Series') : (isFa ? 'فیلم' : 'Movie'));
                poster = item.imdb_code ? '/posters/' + encodeURIComponent(item.imdb_code) + '.webp' : (item.poster || fallbackPoster);
                link = localUrl(item);
                badge = isFa ? 'آرشیو ۲' : 'Archive 2';
            }
            html += '<div class="search-result-item" data-url="' + esc(link) + '" style="cursor:pointer">' +
                '<img class="search-result-poster" src="' + esc(poster || fallbackPoster) + '" onerror="this.src=\'' + fallbackPoster + '\'" loading="lazy" decoding="async">' +
                '<div class="search-result-info">' +
                    '<div class="search-result-title"><bdi dir="auto">' + esc(title) + '</bdi></div>' +
                    '<div class="search-result-original"><bdi dir="auto">' + esc(original) + '</bdi></div>' +
                    '<div class="search-result-meta"><span>' + esc(year) + '</span>' + imdb(rating) + '<span class="search-result-badge">' + esc(badge) + '</span></div>' +
                '</div></div>';
        });
        if(items.length >= 20 || data.has_more || data.next_page){
            html += '<a href="' + esc(viewAll(mode, term)) + '" class="search-result-viewall" style="display:flex;align-items:center;justify-content:center;gap:8px;margin:8px 10px 10px;padding:11px 12px;border-radius:16px;background:rgba(var(--accent-rgb),.14);border:1px solid rgba(var(--accent-rgb),.35);color:var(--accent);font-size:12px;font-weight:900;text-decoration:none">' + (isFa ? 'مشاهده همه نتایج' : 'View all results') + '</a>';
        }
        results.innerHTML = html;
        results.classList.add('active');
        bindItems();
    }
    function endpoint(mode, term){
        if(mode === 'arc1') return '/api2.php?s=' + encodeURIComponent(term) + '&page=1';
        if(mode === 'arc3') return '/api6.php?s=' + encodeURIComponent(term) + '&page=1';
        if(mode === 'arc4') return '/api4.php?s=' + encodeURIComponent(term) + '&page=1';
        return '/ajax.php?action=search&term=' + encodeURIComponent(term);
    }
    function searchNow(){
        var term = normalize(input.value);
        var mode = archive();
        clearTimeout(timer);
        if(controller){ try{ controller.abort(); }catch(e){} }
        if(!term){ results.innerHTML=''; results.classList.remove('active'); return; }
        if(term.length < 2){ results.classList.remove('active'); return; }
        results.innerHTML = typeof window.bmQuickSearchLoaderMarkup === 'function' ? window.bmQuickSearchLoaderMarkup() : '<div style="padding:20px;text-align:center">Searching</div>';
        results.classList.add('active');
        timer = window.setTimeout(function(){
            controller = new AbortController();
            var requestedMode = mode;
            fetch(endpoint(requestedMode, term), {signal:controller.signal, credentials:'same-origin'})
                .then(function(res){ if(!res.ok) throw new Error('HTTP ' + res.status); return res.json(); })
                .then(function(data){
                    if(normalize(input.value) !== term || archive() !== requestedMode) return;
                    render(requestedMode, data || {}, term);
                })
                .catch(function(error){
                    if(error && error.name === 'AbortError') return;
                    empty(isFa ? 'خطا در جستجو؛ دوباره تلاش کن' : 'Search failed; please try again');
                });
        },260);
    }
    input.addEventListener('input', searchNow);
})();
