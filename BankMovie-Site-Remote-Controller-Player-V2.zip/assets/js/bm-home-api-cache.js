(function(){
  'use strict';
  try{
    var isHome = location.pathname === '/' || /\/index\.php$/i.test(location.pathname);
    if(!isHome || typeof window.fetch !== 'function') return;

    var originalFetch = window.fetch.bind(window);
    var TTL = 10 * 60 * 1000; // Archive sections stay fresh for ten minutes
    var PREFIX = 'bm_api_cache_v71_api6animations:';
    var storage = null;
    try {
      storage = window.localStorage;
      var testKey = PREFIX + 'test';
      storage.setItem(testKey, '1');
      storage.removeItem(testKey);
    } catch(e) {
      try { storage = window.sessionStorage; } catch(_e) { storage = null; }
    }
    if(!storage) return;
    var conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
    var weak = (window.matchMedia && matchMedia('(max-width: 768px)').matches) &&
      ((navigator.deviceMemory && navigator.deviceMemory <= 4) || (navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 4) || (conn && conn.saveData));

    function reqMethod(input, init){
      return String((init && init.method) || (input && typeof input === 'object' && input.method) || 'GET').toUpperCase();
    }
    function toURL(input){
      try { return new URL((input && typeof input === 'object' && input.url) ? input.url : String(input), location.href); }
      catch(e){ return null; }
    }
    function cacheable(input, init){
      if(reqMethod(input, init) !== 'GET') return null;
      var u = toURL(input); if(!u || u.origin !== location.origin) return null;
      var file = (u.pathname.split('/').pop() || '').toLowerCase();
      if(file === 'api2.php'){
        if(u.searchParams.has('s')) return null;
        return u;
      }
      if(file === 'api6.php' || file === 'api3.php' || file === 'api4.php'){
        if(u.searchParams.has('s')) return null;
        return u;
      }
      if(file === 'ajax.php'){
        var action = u.searchParams.get('action');
        if(action === 'get_movies') return u;
      }
      return null;
    }
    function keyFor(u){ return PREFIX + u.pathname + '?' + u.searchParams.toString(); }
    function read(key){
      try{
        var raw = storage.getItem(key);
        if(!raw) return null;
        var obj = JSON.parse(raw);
        if(!obj || !obj.t || (Date.now() - obj.t) > TTL || typeof obj.body !== 'string'){
          storage.removeItem(key); return null;
        }
        return new Response(obj.body, {status: 200, headers: {'Content-Type': obj.type || 'application/json; charset=utf-8', 'X-BM-Cache':'hit'}});
      }catch(e){ return null; }
    }
    function write(key, res){
      try{
        if(!res || !res.ok) return;
        var type = res.headers && res.headers.get('Content-Type') || '';
        if(type && type.indexOf('json') === -1) return;
        res.clone().text().then(function(body){
          try{
            if(!body || body.length > 900000) return;
            storage.setItem(key, JSON.stringify({t:Date.now(), type:type || 'application/json; charset=utf-8', body:body}));
          }catch(e){
            // If storage is full, clear only our old API cache keys.
            try{
              Object.keys(storage).forEach(function(k){ if(k.indexOf(PREFIX) === 0) storage.removeItem(k); });
            }catch(_e){}
          }
        });
      }catch(e){}
    }

    window.fetch = function(input, init){
      var u;
      try{ u = cacheable(input, init); }catch(e){ u = null; }
      if(!u) return originalFetch(input, init);
      var key = keyFor(u);
      var hit = read(key);
      if(hit) return Promise.resolve(hit);
      return originalFetch(input, init).then(function(res){ write(key, res); return res; });
    };
    if(weak) document.documentElement.classList.add('bm-api-cache-ready');
  }catch(e){}
})();
