
(function(){
  function bmForceHideLoading(){
    var overlay = document.getElementById('loadingOverlay');
    if(!overlay) return;
    overlay.classList.add('hide');
    overlay.style.opacity = '0';
    overlay.style.visibility = 'hidden';
    overlay.style.pointerEvents = 'none';
    setTimeout(function(){ if(overlay) overlay.style.display = 'none'; }, 350);
  }
  if(document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ setTimeout(bmForceHideLoading, 900); });
  } else {
    setTimeout(bmForceHideLoading, 900);
  }
  window.addEventListener('load', function(){ setTimeout(bmForceHideLoading, 250); });
  setTimeout(bmForceHideLoading, 3000);
})();
