/* BankMovie V72 — custom public dialogs replacing browser-native UI. */
(function(d,w){
  'use strict';

  const fa = (d.documentElement.lang || 'fa').toLowerCase().startsWith('fa');
  let root = null;
  let resolver = null;
  let previousFocus = null;
  let selectedValue = null;

  const icons = {
    info:'<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7h.01"/></svg>',
    question:'<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9"/><path d="M9.8 9a2.4 2.4 0 1 1 3.9 1.9c-1.2.8-1.7 1.3-1.7 2.6M12 17h.01"/></svg>',
    danger:'<svg viewBox="0 0 24 24" fill="none"><path d="M10.3 3.7 2.5 17.2A2 2 0 0 0 4.2 20h15.6a2 2 0 0 0 1.7-2.8L13.7 3.7a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></svg>',
    edit:'<svg viewBox="0 0 24 24" fill="none"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg>'
  };

  function esc(v){
    return String(v ?? '').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  }

  function ensure(){
    if(root) return root;
    root=d.createElement('div');
    root.className='bm-dialog-root';
    root.setAttribute('aria-hidden','true');
    root.innerHTML=`
      <div class="bm-dialog-backdrop" data-bm-dialog-cancel></div>
      <section class="bm-dialog-card" role="dialog" aria-modal="true" aria-labelledby="bmDialogTitle">
        <div class="bm-dialog-head">
          <div class="bm-dialog-icon" data-bm-dialog-icon></div>
          <div class="bm-dialog-copy">
            <h2 class="bm-dialog-title" id="bmDialogTitle"></h2>
            <p class="bm-dialog-message" data-bm-dialog-message></p>
          </div>
        </div>
        <div data-bm-dialog-content></div>
        <div class="bm-dialog-actions">
          <button class="bm-dialog-btn" type="button" data-bm-dialog-cancel></button>
          <button class="bm-dialog-btn primary" type="button" data-bm-dialog-confirm></button>
        </div>
      </section>`;
    d.body.appendChild(root);

    root.addEventListener('click',e=>{
      const option=e.target.closest('[data-bm-dialog-option]');
      if(option){
        root.querySelectorAll('[data-bm-dialog-option]').forEach(x=>x.classList.remove('is-selected'));
        option.classList.add('is-selected');
        selectedValue=option.dataset.bmDialogOption ?? '';
        return;
      }
      if(e.target.closest('[data-bm-dialog-cancel]')) finish(false);
      if(e.target.closest('[data-bm-dialog-confirm]')) finish(true);
    });
    d.addEventListener('keydown',e=>{
      if(!root?.classList.contains('is-open')) return;
      if(e.key==='Escape'){e.preventDefault();finish(false);}
      if(e.key==='Enter' && !e.shiftKey && !e.target.matches('textarea')){
        const confirm=root.querySelector('[data-bm-dialog-confirm]');
        if(confirm && d.activeElement !== root.querySelector('[data-bm-dialog-cancel]')){
          e.preventDefault();finish(true);
        }
      }
    });
    return root;
  }

  function finish(ok){
    if(!root || !resolver) return;
    const type=root.dataset.type || 'confirm';
    const input=root.querySelector('[data-bm-dialog-input]');
    let value=ok;

    if(type==='prompt') value=ok ? (input?.value ?? '') : null;
    if(type==='select') value=ok ? selectedValue : null;
    if(type==='alert') value=true;

    const resolve=resolver;
    resolver=null;
    root.classList.remove('is-open','is-danger');
    root.setAttribute('aria-hidden','true');
    d.body.classList.remove('bm-dialog-open');
    setTimeout(()=>{
      try{previousFocus?.focus?.({preventScroll:true});}catch(_e){}
      resolve(value);
    },80);
  }

  function open(cfg={}){
    ensure();
    if(resolver) return Promise.resolve(null);

    previousFocus=d.activeElement;
    selectedValue=cfg.value ?? null;
    root.dataset.type=cfg.type || 'confirm';
    root.classList.toggle('is-danger',!!cfg.danger);
    root.querySelector('[data-bm-dialog-icon]').innerHTML=icons[cfg.icon || (cfg.danger?'danger':'question')] || icons.question;
    root.querySelector('.bm-dialog-title').textContent=cfg.title || (fa?'تأیید عملیات':'Confirm');
    root.querySelector('[data-bm-dialog-message]').textContent=cfg.message || '';

    const content=root.querySelector('[data-bm-dialog-content]');
    content.innerHTML='';

    if(cfg.type==='prompt'){
      const wrap=d.createElement('div');
      wrap.className='bm-dialog-field';
      wrap.innerHTML=`${cfg.label?`<label class="bm-dialog-label">${esc(cfg.label)}</label>`:''}
        ${cfg.multiline!==false
          ? `<textarea class="bm-dialog-textarea" data-bm-dialog-input placeholder="${esc(cfg.placeholder||'')}">${esc(cfg.value||'')}</textarea>`
          : `<input class="bm-dialog-input" data-bm-dialog-input value="${esc(cfg.value||'')}" placeholder="${esc(cfg.placeholder||'')}">`}`;
      content.appendChild(wrap);
    }

    if(cfg.type==='select'){
      const options=d.createElement('div');
      options.className='bm-dialog-options';
      (cfg.options||[]).forEach((opt,i)=>{
        const b=d.createElement('button');
        b.type='button';
        b.className='bm-dialog-option'+((selectedValue!==null && String(selectedValue)===String(opt.value)) || (selectedValue===null && i===0)?' is-selected':'');
        b.dataset.bmDialogOption=String(opt.value);
        b.textContent=opt.label;
        options.appendChild(b);
        if((selectedValue!==null && String(selectedValue)===String(opt.value)) || (selectedValue===null && i===0)) selectedValue=String(opt.value);
      });
      content.appendChild(options);
    }

    const cancel=root.querySelector('[data-bm-dialog-cancel].bm-dialog-btn');
    const confirm=root.querySelector('[data-bm-dialog-confirm]');
    cancel.textContent=cfg.cancelText || (fa?'انصراف':'Cancel');
    confirm.textContent=cfg.confirmText || (cfg.type==='alert'?(fa?'باشه':'OK'):(fa?'تأیید':'Confirm'));
    cancel.style.display=cfg.type==='alert'?'none':'';

    root.classList.add('is-open');
    root.setAttribute('aria-hidden','false');
    d.body.classList.add('bm-dialog-open');

    requestAnimationFrame(()=>{
      const target=root.querySelector('[data-bm-dialog-input]') ||
                   root.querySelector('.bm-dialog-option.is-selected') ||
                   confirm;
      try{target?.focus?.({preventScroll:true});}catch(_e){}
      if(cfg.type==='prompt' && cfg.selectAll){
        try{root.querySelector('[data-bm-dialog-input]')?.select();}catch(_e){}
      }
    });

    return new Promise(resolve=>{resolver=resolve;});
  }

  const API={
    confirm:(cfg={})=>open({...cfg,type:'confirm'}),
    alert:(cfg={})=>open({...cfg,type:'alert',icon:cfg.icon||'info'}),
    prompt:(cfg={})=>open({...cfg,type:'prompt',icon:cfg.icon||'edit'}),
    select:(cfg={})=>open({...cfg,type:'select',icon:cfg.icon||'question'})
  };
  w.BMDialog=API;

  /* alert() has no meaningful return value, so replacing it globally is safe
     and removes leftover native alert boxes from public pages. */
  w.alert=function(message){
    API.alert({title:fa?'پیام بانک مووی':'BankMovie',message:String(message??'')});
  };

  /* Intercept the recurring native inline confirm flows without editing every page. */
  d.addEventListener('click',async e=>{
    const link=e.target.closest('a[href]');
    if(!link) return;

    let kind='';
    try{
      const u=new URL(link.href,location.href);
      if(u.pathname==='/logout' || u.pathname==='/logout.php') kind='logout';
      if(u.searchParams.get('remove_avatar')==='1') kind='avatar';
    }catch(_e){}

    if(!kind) return;
    e.preventDefault();
    e.stopImmediatePropagation();

    const ok=await API.confirm({
      danger:kind==='avatar',
      icon:kind==='avatar'?'danger':'question',
      title:kind==='logout'?(fa?'خروج از حساب':'Sign out'):(fa?'حذف تصویر پروفایل':'Remove profile photo'),
      message:kind==='logout'
        ?(fa?'از حساب کاربری خارج می‌شوی؟':'Do you want to sign out?')
        :(fa?'تصویر پروفایل فعلی حذف شود؟':'Remove your current profile photo?'),
      confirmText:kind==='logout'?(fa?'خروج':'Sign out'):(fa?'حذف تصویر':'Remove'),
      cancelText:fa?'انصراف':'Cancel'
    });
    if(ok) location.href=link.href;
  },true);

})(document,window);
