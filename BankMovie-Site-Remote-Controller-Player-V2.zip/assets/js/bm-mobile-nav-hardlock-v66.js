/* BankMovie V66 — hard-lock mobile footer nav to viewport bottom.
   No scroll loop or observer. */
(function(d){
  'use strict';

  function mobile(){
    return !!(window.matchMedia && window.matchMedia('(max-width: 991px)').matches);
  }

  function lock(){
    try{
      var root=d.documentElement;
      if(!mobile()){
        root.classList.remove('bm-nav-hardlock-v66');
        return;
      }

      root.classList.remove('bm-nav-dynamic');
      root.classList.add('bm-nav-static','bm-nav-hardlock-v66');
      root.dataset.bmNavTier='static';

      if(window.BM_ADAPTIVE_MOBILE_V49){
        window.BM_ADAPTIVE_MOBILE_V49.nav='static';
        window.BM_ADAPTIVE_MOBILE_V49.navForcedStatic=true;
      }

      d.querySelectorAll('.bottom-nav,.actor-bottom-nav,[data-mobile-bottom-nav]').forEach(function(bar){
        [
          'position','left','right','inset','inset-inline','inset-inline-start','inset-inline-end',
          'bottom','top','transform','translate','width','max-width','margin',
          'border-radius','opacity','visibility','filter','backdrop-filter',
          '-webkit-backdrop-filter','transition','animation'
        ].forEach(function(prop){
          try{bar.style.removeProperty(prop);}catch(_e){}
        });
      });
    }catch(_e){}
  }

  lock();
  if(d.readyState==='loading') d.addEventListener('DOMContentLoaded',lock,{once:true});
  window.addEventListener('pageshow',lock,{passive:true});
  window.addEventListener('load',lock,{once:true});
  window.addEventListener('resize',lock,{passive:true});
})(document);
