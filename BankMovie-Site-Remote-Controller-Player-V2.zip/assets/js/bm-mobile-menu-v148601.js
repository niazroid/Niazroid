(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  function escapeHtml(value){
    return String(value == null ? '' : value)
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;')
      .replace(/'/g,'&#39;');
  }

  function userSvg(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>';
  }
  function crownSvg(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 8 4 4 5-7 5 7 4-4-2 10H5L3 8Z"></path></svg>';
  }
  function chevronSvg(){
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18 9 12l6-6"></path></svg>';
  }

  function detectKey(anchor){
    var href = (anchor.getAttribute('href') || '').toLowerCase();
    var text = (anchor.textContent || '').trim();
    if(href === '/' || /index\.php$/.test(href)) return 'home';
    if(/player/.test(href) || /پلیر/.test(text)) return 'player';
    if(/collection/.test(href) || /کالکشن/.test(text)) return 'collections';
    if(/categor/.test(href) || /دسته/.test(text)) return 'categories';
    if(/search/.test(href) || /جستجو/.test(text)) return 'search';
    if(/profile/.test(href) || /پروفایل/.test(text)) return 'profile';
    if(/admin/.test(href) || /مدیریت/.test(text)) return 'admin';
    if(/application|app(?!ly)/.test(href) || /اپلیکیشن/.test(text)) return 'apps';
    if(/logout/.test(href) || /خروج/.test(text)) return 'logout';
    if(/login/.test(href) || /ورود/.test(text)) return 'login';
    if(/register/.test(href) || /ثبت/.test(text)) return 'register';
    return text || href || 'item';
  }

  function extractItem(anchor){
    var key = detectKey(anchor);
    var href = anchor.getAttribute('href') || '#';
    var icon = anchor.querySelector('svg, i, img');
    var textNode = anchor.querySelector('span') || anchor;
    var label = (textNode.textContent || '').trim();
    return {
      key: key,
      href: href,
      active: anchor.classList.contains('active'),
      onclick: anchor.getAttribute('onclick') || '',
      iconHtml: icon ? icon.outerHTML : userSvg(),
      label: label,
      anchor: anchor
    };
  }

  function buildStandardItem(item){
    var a = document.createElement('a');
    a.className = 'sidebar-item';
    if(item.active) a.classList.add('active');
    a.href = item.href;
    if(item.onclick) a.setAttribute('onclick', item.onclick);
    a.innerHTML = '<span class="bm-menu-chevron" aria-hidden="true">'+chevronSvg()+'</span>'+
                  '<span class="bm-menu-label">'+escapeHtml(item.label)+'</span>'+
                  '<span class="bm-menu-iconbox" aria-hidden="true">'+item.iconHtml+'</span>';
    return a;
  }

  function buildFooterItem(item, cfg){
    var a = document.createElement('a');
    a.className = 'sidebar-item';
    if(item.key === 'logout') a.classList.add('is-logout');
    if(item.key === 'login' || item.key === 'register') a.classList.add('is-auth');
    a.href = item.href;
    if(item.onclick) a.setAttribute('onclick', item.onclick);
    var sub = '';
    if(item.key === 'logout' && cfg.logoutSubtitle) sub = '<span class="bm-menu-sublabel">'+escapeHtml(cfg.logoutSubtitle)+'</span>';
    a.innerHTML = '<span class="bm-menu-footer-copy"><span class="bm-menu-label">'+escapeHtml(item.label)+'</span>'+sub+'</span>'+
                  '<span class="bm-menu-iconbox" aria-hidden="true">'+item.iconHtml+'</span>';
    return a;
  }

  function createSection(title){
    var el = document.createElement('div');
    el.className = 'bm-menu-section';
    el.textContent = title;
    return el;
  }

  function buildAvatar(user){
    if(user && user.hasAvatar && user.avatarUrl){
      return '<div class="sidebar-avatar"><img src="'+escapeHtml(user.avatarUrl)+'" alt="'+escapeHtml(user.username || 'avatar')+'" loading="lazy" decoding="async"></div>';
    }
    return '<div class="bm-menu-avatar-fallback">'+userSvg()+'</div>';
  }

  function buildUserCard(menu, cfg){
    var userCard = menu.querySelector('.sidebar-user');
    if(!userCard) return;
    var user = cfg.user || {};
    var username = user.loggedIn ? (user.username || 'User') : 'Guest';
    var roleLabel = user.loggedIn ? (user.roleLabel || '') : '';
    var premiumPill = user.isVip ? '<span class="bm-menu-premium-pill">'+crownSvg()+'<span>'+(user.isAdmin ? 'VIP / Admin' : 'VIP')+'</span></span>' : '';
    userCard.innerHTML =
      '<div class="bm-menu-avatar-wrap">'+
        buildAvatar(user)+
        (user.isVip ? '<span class="bm-menu-vip-badge">'+crownSvg()+'<span>VIP</span></span>' : '')+
      '</div>'+
      '<div class="bm-menu-user-copy">'+
        '<div class="sidebar-username">'+escapeHtml(username)+'</div>'+
        '<div class="sidebar-userrole">'+escapeHtml(roleLabel)+'</div>'+
        premiumPill+
      '</div>';
  }

  function buildSubscriptionCard(menu, cfg){
    var existing = menu.querySelector('.bm-menu-subscription');
    if(existing) existing.remove();
    var user = cfg.user || {};
    if(!user.loggedIn) return;
    var card = document.createElement('div');
    card.className = 'bm-menu-subscription ' + (user.vipActive ? 'is-vip' : 'is-upsell');
    if(user.vipActive){
      var meta = [];
      if(user.vipLifetime){
        meta.push('<span class="bm-menu-subscription-chip">∞ '+escapeHtml(cfg.vipLifetimeText || '')+'</span>');
      } else {
        if(user.vipDaysRemaining > 0){
          meta.push('<span class="bm-menu-subscription-chip">'+escapeHtml(cfg.vipRemainingPrefix || '')+' '+escapeHtml(user.vipDaysRemaining)+' '+escapeHtml(cfg.vipDaysLabel || '')+'</span>');
        }
        if(user.vipExpiresLabel){
          meta.push('<span class="bm-menu-subscription-chip">'+escapeHtml(cfg.vipExpiresPrefix || '')+' '+escapeHtml(user.vipExpiresLabel)+'</span>');
        }
      }
      var copy = user.vipLifetime ? (cfg.vipLifetimeText || '') : ((cfg.vipActiveCopy || '') || '');
      if(!copy && user.vipDaysRemaining > 0){
        copy = (cfg.vipRemainingPrefix || 'Remaining:') + ' ' + user.vipDaysRemaining + ' ' + (cfg.vipDaysLabel || 'days');
      }
      card.innerHTML = '<div class="bm-menu-subscription-title">'+escapeHtml(cfg.vipActiveTitle || 'VIP membership is active')+'</div>'+
                       '<p class="bm-menu-subscription-copy">'+escapeHtml(copy)+'</p>'+
                       (meta.length ? '<div class="bm-menu-subscription-meta">'+meta.join('')+'</div>' : '');
    } else {
      card.innerHTML = '<div class="bm-menu-subscription-title">'+escapeHtml(cfg.buyVipTitle || 'VIP membership is inactive')+'</div>'+
                       '<p class="bm-menu-subscription-copy">'+escapeHtml(cfg.buyVipText || '')+'</p>'+
                       '<a class="bm-menu-subscription-btn" href="'+escapeHtml(cfg.buyVipUrl || '/vip')+'">'+crownSvg()+'<span>'+escapeHtml(cfg.buyVipButton || 'Buy VIP membership')+'</span></a>';
    }
    var userCard = menu.querySelector('.sidebar-user');
    if(userCard && userCard.parentNode) userCard.insertAdjacentElement('afterend', card);
  }

  function rebuildHeader(menu, cfg){
    var header = menu.querySelector('.sidebar-header');
    if(!header) return;
    var closeBtn = header.querySelector('.sidebar-close');
    var brand = document.createElement('div');
    brand.className = 'bm-menu-brand';
    brand.innerHTML = '<div class="bm-menu-brand-title"><span class="is-bank">Bank</span><span class="is-movie">Movie</span></div>'+
                      '<div class="bm-menu-brand-tagline">'+escapeHtml(cfg.tagline || '')+'</div>';
    header.innerHTML = '';
    header.appendChild(brand);
    if(closeBtn) header.appendChild(closeBtn);
  }

  function upgradeMenu(menu){
    var cfg = ((window.BM_SITE_UI || {}).mobileDrawer || {});
    if(cfg.enabled === false || !menu || menu.dataset.bmMenuEnhanced === '1') return;
    menu.dataset.bmMenuEnhanced = '1';
    menu.classList.add('bm-mobile-menu-v148601');

    rebuildHeader(menu, cfg);
    buildUserCard(menu, cfg);
    buildSubscriptionCard(menu, cfg);

    var nav = menu.querySelector('.sidebar-nav');
    var footer = menu.querySelector('.sidebar-footer');
    if(!nav) return;

    var items = Array.prototype.slice.call(nav.querySelectorAll('a.sidebar-item')).map(extractItem);
    var footerItems = footer ? Array.prototype.slice.call(footer.querySelectorAll('a.sidebar-item')).map(extractItem) : [];

    if(cfg.removeCollections !== false){
      items = items.filter(function(item){ return item.key !== 'collections'; });
    }

    var orderQuick = ['home','search','player','categories'];
    var orderAccount = ['profile','admin','apps'];
    var quick = [];
    var account = [];
    var used = {};
    orderQuick.forEach(function(key){
      var found = items.find(function(item){ return item.key === key; });
      if(found){ quick.push(found); used[key] = true; }
    });
    orderAccount.forEach(function(key){
      var found = items.find(function(item){ return item.key === key; });
      if(found){ account.push(found); used[key] = true; }
    });
    items.forEach(function(item){
      if(used[item.key]) return;
      if(item.key === 'collections') return;
      if(['login','register','logout'].indexOf(item.key) !== -1) return;
      if(/admin|profile|app/.test(item.key)) account.push(item); else quick.push(item);
    });

    nav.innerHTML = '';
    if(quick.length){
      nav.appendChild(createSection(cfg.quickAccessLabel || 'Quick access'));
      quick.forEach(function(item){ nav.appendChild(buildStandardItem(item)); });
    }
    if(account.length){
      nav.appendChild(createSection(cfg.accountToolsLabel || 'Account & tools'));
      account.forEach(function(item){ nav.appendChild(buildStandardItem(item)); });
    }

    if(footer){
      footer.innerHTML = '';
      footerItems.forEach(function(item){ footer.appendChild(buildFooterItem(item, cfg)); });
    }
  }

  ready(function(){
    var menu = document.getElementById('sidebarMenu') || document.querySelector('.sidebar-menu');
    upgradeMenu(menu);
  });
})();
