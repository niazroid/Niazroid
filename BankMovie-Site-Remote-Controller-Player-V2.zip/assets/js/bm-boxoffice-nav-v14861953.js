(() => {
  'use strict';
  const label = (document.documentElement.lang || '').toLowerCase().startsWith('en') ? 'Box Office' : 'باکس آفیس';
  const icon = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/><path d="m3 7 5-4 5 5 7-6"/></svg>';
  function inject(){
    document.querySelectorAll('.sidebar-nav').forEach(nav => {
      if (nav.querySelector('a[href="/boxoffice"],a[href="/boxoffice.php"]')) return;
      const a = document.createElement('a');
      a.href = '/boxoffice';
      a.className = 'sidebar-item bm-boxoffice-menu-link';
      a.innerHTML = icon + '<span>' + label + '</span>';
      const categories = nav.querySelector('a[href="/categories"],a[href="/categories.php"]');
      if (categories && categories.nextSibling) categories.parentNode.insertBefore(a, categories.nextSibling);
      else nav.appendChild(a);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', inject, {once:true}); else inject();
  window.setTimeout(inject, 700);
})();
