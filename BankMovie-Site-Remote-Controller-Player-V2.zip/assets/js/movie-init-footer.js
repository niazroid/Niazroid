// =================== راه‌اندازی اولیه ===================

function setupHeroAnchors(){
    document.querySelectorAll('.hero-actions a[href^="#"]').forEach(link => {
        link.addEventListener('click', (e) => {
            const id = link.getAttribute('href');
            const target = id ? document.querySelector(id) : null;
            if(target){
                e.preventDefault();
                target.scrollIntoView({behavior:'smooth', block:'start'});
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', function() {
    setupMenu();
    setupHeaderScroll();
    setupSmartBottomNav();
    setupHeroAnchors();
    attachCommentEvents();
    attachReplyButtons();
    attachDeleteButtons();
    hideLoading();

    // ========== رفع مشکل سوییچ کیفیت در فیلم‌ها ==========
    if (isMovie) {
        document.querySelectorAll('.quality-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                const type = this.getAttribute('data-type');
                const quality = this.getAttribute('data-quality');
                if (type && quality) {
                    const panel = this.closest('.season-quality-list');
                    setQuality(type, quality);
                    if (panel) {
                        const list = document.getElementById('downloadList');
                        if (list && list.parentElement !== panel) panel.appendChild(list);
                    }
                }
            });
        });
    }

    // ========== آکاردئون فصل‌های سریال ==========
    document.querySelectorAll('.season-btn').forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            const season = this.getAttribute('data-season');
            const targetList = document.getElementById('season-' + season + '-list');
            if (targetList) {
                const isVisible = targetList.style.display === 'flex';
                if (isVisible) {
                    targetList.style.display = 'none';
                    this.classList.remove('active');
                } else {
                    targetList.style.display = 'flex';
                    this.classList.add('active');
                }
            }
        });
    });
});
// v28: Footer typing/Manuel credit removed; no footer typing initialization needed.
