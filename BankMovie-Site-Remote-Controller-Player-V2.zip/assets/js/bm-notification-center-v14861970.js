(() => {
  'use strict';

  const cfg = window.BM_NOTIFICATION_CENTER || {};
  const originalBell = document.getElementById('notifBell');
  if (!originalBell) return;
  // Replace the legacy bell node once. This intentionally drops old page-specific
  // notification listeners so every public page uses the same notification center.
  const bell = originalBell.cloneNode(true);
  originalBell.replaceWith(bell);
  document.querySelectorAll('#notifSidebar').forEach((el, i) => { el.id = 'bmLegacyNotifSidebar' + (i || ''); });
  document.querySelectorAll('#notifBackdrop').forEach((el, i) => { el.id = 'bmLegacyNotifBackdrop' + (i || ''); });
  document.querySelectorAll('#closeNotifSidebar').forEach((el, i) => { el.id = 'bmLegacyCloseNotifSidebar' + (i || ''); });
  const badge = bell.querySelector('#bmNotifBadge');
  const panel = document.getElementById('bmNotifCenter');
  const backdrop = document.getElementById('bmNotifCenterBackdrop');
  const closeBtn = document.getElementById('bmNotifCenterClose');
  const list = document.getElementById('bmNotifCenterList');
  const status = document.getElementById('bmNotifCenterStatus');
  const readAll = document.getElementById('bmNotifReadAll');
  const clearAll = document.getElementById('bmNotifClearAll');
  if (!bell || !panel || !backdrop || !list) return;

  const fa = (cfg.lang || 'fa') !== 'en';
  let items = [];
  let loaded = false;
  let loading = false;

  const icon = (type) => {
    if (type === 'vip') return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 11H5L3 7Z"/><path d="M6 18h12"/></svg>';
    if (type === 'comment_reply') return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4Z"/><path d="M8 9h8M8 13h5"/></svg>';
    if (type === 'request' || type === 'request_update') return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 4h14v16H5z"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>';
    if (type === 'update') return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3v12M7 10l5 5 5-5"/><path d="M5 21h14"/></svg>';
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M14 21h-4"/></svg>';
  };

  function setBadge(unread) {
    unread = Math.max(0, Number(unread) || 0);
    if (!badge) return;
    if (unread <= 0) {
      badge.hidden = true;
      badge.textContent = '';
      return;
    }
    badge.hidden = false;
    badge.textContent = unread > 99 ? '99+' : String(unread);
    badge.setAttribute('aria-label', fa ? `${unread} اعلان خوانده‌نشده` : `${unread} unread notifications`);
  }

  function emptyMarkup() {
    return `<div class="bm-notif-empty"><div><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M14 21h-4"/></svg><strong>${fa ? 'همه‌چی آرومه!' : 'All caught up'}</strong><span>${fa ? 'فعلاً اعلان جدیدی برای شما وجود ندارد.' : 'There are no notifications right now.'}</span></div></div>`;
  }

  function esc(value) {
    return String(value ?? '').replace(/[&<>'"]/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[ch]));
  }

  function render() {
    if (!items.length) {
      list.innerHTML = emptyMarkup();
      if (status) status.textContent = fa ? 'اعلان جدیدی ندارید' : 'No new notifications';
      return;
    }
    const unread = items.filter(x => !x.is_read).length;
    if (status) status.textContent = unread > 0
      ? (fa ? `${unread} اعلان خوانده‌نشده` : `${unread} unread`)
      : (fa ? `${items.length} اعلان اخیر` : `${items.length} recent notifications`);

    list.innerHTML = items.map(item => {
      const id = typeof item.id === 'number' ? item.id : 0;
      const link = item.target_url ? `<span class="bm-notif-item-open">${fa ? 'مشاهده' : 'Open'}</span>` : '';
      const del = cfg.loggedIn && id > 0 ? `<button type="button" class="bm-notif-item-delete" data-notif-delete="${id}" aria-label="${fa ? 'حذف اعلان' : 'Delete notification'}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 7h16M9 7V4h6v3M7 7l1 13h8l1-13"/></svg></button>` : '<span></span>';
      return `<article class="bm-notif-item${item.is_read ? '' : ' is-unread'}" data-id="${id}" data-type="${esc(item.type || 'admin')}" data-url="${esc(item.target_url || '')}">
        <span class="bm-notif-item-icon" aria-hidden="true">${icon(item.type)}</span>
        <div class="bm-notif-item-main" tabindex="0" role="button">
          <div class="bm-notif-item-title">${esc(item.title || (fa ? 'اعلان BankMovie' : 'BankMovie notification'))}</div>
          <div class="bm-notif-item-message">${esc(item.message || '')}</div>
          <div class="bm-notif-item-meta"><span>${esc(item.date_text || '')}</span>${link}</div>
        </div>${del}
      </article>`;
    }).join('');
  }

  async function api(action = 'list', body = null) {
    const opts = {credentials:'same-origin', headers:{'Accept':'application/json'}};
    let url = cfg.api || '/notification_center_api.php';
    if (body) {
      opts.method = 'POST';
      const data = new URLSearchParams();
      data.set('action', action);
      Object.entries(body).forEach(([k,v]) => data.set(k, String(v)));
      data.set('csrf_token', cfg.csrf || '');
      opts.body = data.toString();
      opts.headers['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8';
      opts.headers['X-CSRF-Token'] = cfg.csrf || '';
    } else {
      url += (url.includes('?') ? '&' : '?') + 'action=' + encodeURIComponent(action);
    }
    const response = await fetch(url, opts);
    const data = await response.json().catch(() => ({}));
    if (!response.ok || !data.success) throw new Error(data.message || 'notification_error');
    return data;
  }

  async function refresh(silent = false) {
    if (loading) return;
    loading = true;
    if (!silent) list.innerHTML = '<div class="bm-notif-loading"><span></span><span></span><span></span></div>';
    try {
      const data = await api('list');
      items = Array.isArray(data.items) ? data.items : [];
      loaded = true;
      setBadge(data.unread || 0);
      render();
    } catch (_) {
      if (!silent) list.innerHTML = `<div class="bm-notif-empty"><div><strong>${fa ? 'دریافت اعلان‌ها انجام نشد' : 'Could not load notifications'}</strong><span>${fa ? 'اتصال را بررسی کنید و دوباره تلاش کنید.' : 'Please try again.'}</span></div></div>`;
    } finally {
      loading = false;
    }
  }

  function open() {
    bell.setAttribute('aria-expanded', 'true');
    panel.hidden = false;
    backdrop.hidden = false;
    requestAnimationFrame(() => {
      panel.classList.add('is-open');
      backdrop.classList.add('is-open');
      document.body.classList.add('bm-notif-center-open');
    });
    refresh(false);
  }

  function close() {
    bell.setAttribute('aria-expanded', 'false');
    panel.classList.remove('is-open');
    backdrop.classList.remove('is-open');
    document.body.classList.remove('bm-notif-center-open');
    window.setTimeout(() => {
      if (!panel.classList.contains('is-open')) {
        panel.hidden = true;
        backdrop.hidden = true;
      }
    }, 260);
  }

  async function mutate(action, body = {}) {
    try {
      const data = await api(action, body);
      setBadge(data.unread || 0);
      return true;
    } catch (_) { return false; }
  }

  bell.addEventListener('click', event => {
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();
    open();
  }, true);
  bell.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      event.stopImmediatePropagation();
      open();
    }
  }, true);
  closeBtn?.addEventListener('click', close);
  backdrop.addEventListener('click', close);
  document.addEventListener('keydown', event => { if (event.key === 'Escape' && panel.classList.contains('is-open')) close(); });

  readAll?.addEventListener('click', async () => {
    if (!cfg.loggedIn) return;
    if (await mutate('read_all')) {
      items = items.map(item => ({...item,is_read:true}));
      render();
    }
  });

  clearAll?.addEventListener('click', async () => {
    if (!cfg.loggedIn || !items.length) return;
    if (!(await window.BMDialog.confirm({
      danger:true,
      icon:'danger',
      title:fa ? 'پاک کردن اعلان‌ها' : 'Clear notifications',
      message:fa ? 'همه اعلان‌های حساب پاک شوند؟ این عملیات قابل بازگشت نیست.' : 'Clear all account notifications? This cannot be undone.',
      confirmText:fa ? 'پاک کردن همه' : 'Clear all',
      cancelText:fa ? 'انصراف' : 'Cancel'
    }))) return;
    if (await mutate('clear')) {
      items = [];
      setBadge(0);
      render();
    }
  });

  list.addEventListener('click', async event => {
    const del = event.target.closest('[data-notif-delete]');
    if (del) {
      event.preventDefault();
      event.stopPropagation();
      const id = Number(del.dataset.notifDelete || 0);
      if (id > 0 && await mutate('delete', {id})) {
        items = items.filter(item => Number(item.id) !== id);
        render();
      }
      return;
    }
    const main = event.target.closest('.bm-notif-item-main');
    const card = main?.closest('.bm-notif-item');
    if (!card) return;
    const id = Number(card.dataset.id || 0);
    const url = card.dataset.url || '';
    if (cfg.loggedIn && id > 0) {
      await mutate('read', {id});
      const item = items.find(x => Number(x.id) === id);
      if (item) item.is_read = true;
      render();
    }
    if (url && url.startsWith('/') && !url.startsWith('//')) location.href = url;
  });

  list.addEventListener('keydown', event => {
    if ((event.key === 'Enter' || event.key === ' ') && event.target.classList.contains('bm-notif-item-main')) {
      event.preventDefault();
      event.target.click();
    }
  });

  // Quietly refresh the badge after the main page has become interactive.
  window.setTimeout(() => refresh(true), 550);
})();
