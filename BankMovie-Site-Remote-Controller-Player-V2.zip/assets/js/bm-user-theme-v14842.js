(function () {
  'use strict';
  var server = window.BM_THEME_SERVER || {};
  var themes = server.themes || {};
  var allowed = Object.keys(themes);
  if (!allowed.length) allowed = ['dark-green','dark-blue','dark-purple','dark-pink','dark-red','dark-orange','dark-cyan','dark-white','dark-black'];

  function valid(theme) { return allowed.indexOf(String(theme || '')) !== -1; }
  function getCookie(name) {
    var prefix = name + '=';
    var parts = String(document.cookie || '').split(';');
    for (var i = 0; i < parts.length; i++) {
      var part = parts[i].trim();
      if (part.indexOf(prefix) === 0) return decodeURIComponent(part.slice(prefix.length));
    }
    return '';
  }
  function setCookie(theme) {
    try {
      document.cookie = 'user_theme=' + encodeURIComponent(theme) + '; Max-Age=31536000; Path=/; SameSite=Lax' + (location.protocol === 'https:' ? '; Secure' : '');
    } catch (e) {}
  }
  function localGet() { try { return localStorage.getItem('bankmovie-theme') || ''; } catch (e) { return ''; } }
  function localSet(theme) { try { localStorage.setItem('bankmovie-theme', theme); } catch (e) {} }

  function chooseInitial() {
    // Theme selection is VIP-only. Old localStorage/cookies must never keep a
    // paid theme active after logout or membership expiry.
    if (server.themeAllowed === false) return 'dark-green';
    // The saved database value returned by the server always wins for signed-in users.
    if (server.authenticated && valid(server.theme)) return server.theme;
    var stored = localGet();
    if (valid(stored)) return stored;
    var cookie = getCookie('user_theme');
    if (valid(cookie)) return cookie;
    if (valid(server.theme)) return server.theme;
    return 'dark-green';
  }

  function isPreviewLogo(img) {
    return !!(img && (img.hasAttribute('data-bm-theme-preview-logo') || img.closest('.theme-logo-preview')));
  }
  function isBankMovieThemeLogo(img) {
    if (!img || isPreviewLogo(img)) return false;
    if (img.getAttribute('data-bm-theme-logo') === '1') return true;
    var src = String(img.getAttribute('src') || '');
    return /\/assets\/brand\/(?:themes\/bankmovie-logo-dark-[a-z]+|bankmovie-logo)\.webp(?:[?#].*)?$/i.test(src);
  }
  function themeLogoPath(theme) {
    var item = themes && themes[theme] ? themes[theme] : null;
    return item && typeof item.logo === 'string' ? item.logo : '';
  }
  function updateLogoElement(img, theme) {
    if (server.logoEnabled === false || !isBankMovieThemeLogo(img)) return;
    var path = themeLogoPath(theme);
    if (!path) return;
    img.setAttribute('data-bm-theme-logo', '1');
    if (img.getAttribute('src') !== path) img.setAttribute('src', path);
  }
  function updateLogos(theme, root) {
    if (server.logoEnabled === false) return;
    var scope = root && root.querySelectorAll ? root : document;
    if (scope.nodeType === 1 && scope.tagName === 'IMG') updateLogoElement(scope, theme);
    scope.querySelectorAll('img[data-bm-theme-logo="1"],img[src*="/assets/brand/bankmovie-logo.webp"],img[src*="/assets/brand/themes/bankmovie-logo-"]').forEach(function (img) {
      updateLogoElement(img, theme);
    });
  }

  function apply(theme, options) {
    options = options || {};
    if (server.themeAllowed === false) theme = 'dark-green';
    if (!valid(theme)) theme = 'dark-green';
    document.documentElement.dataset.theme = theme;
    if (document.body) document.body.dataset.theme = theme;
    if (options.persist === true) {
      localSet(theme);
      setCookie(theme);
    }
    window.BM_THEME_CURRENT = theme;
    updateLogos(theme);
    document.dispatchEvent(new CustomEvent('bm:theme-applied', { detail: { theme: theme, persisted: options.persist === true } }));
    return theme;
  }

  var initial = chooseInitial();
  if (server.themeAllowed === false) {
    try { localStorage.removeItem('bankmovie-theme'); } catch (e) {}
    setCookie('dark-green');
  }
  apply(initial, { persist: !!server.authenticated && server.themeAllowed !== false });

  window.BankMovieTheme = {
    apply: apply,
    allowed: server.themeAllowed !== false,
    current: function () { return window.BM_THEME_CURRENT || initial; },
    valid: valid,
    catalog: themes,
    updateLogos: function () { updateLogos(window.BM_THEME_CURRENT || initial); }
  };

  document.addEventListener('DOMContentLoaded', function () {
    apply(window.BM_THEME_CURRENT || initial, { persist: false });
    if ('MutationObserver' in window) {
      var observer = new MutationObserver(function (records) {
        records.forEach(function (record) {
          record.addedNodes.forEach(function (node) {
            if (node && node.nodeType === 1) updateLogos(window.BM_THEME_CURRENT || initial, node);
          });
        });
      });
      observer.observe(document.body, { childList: true, subtree: true });
    }
  });

  document.addEventListener('bm:theme-preview', function (event) {
    var theme = event && event.detail ? event.detail.theme : '';
    apply(theme, { persist: false });
  });
  document.addEventListener('bm:theme-save', function (event) {
    var theme = event && event.detail ? event.detail.theme : '';
    apply(theme, { persist: true });
  });
})();
