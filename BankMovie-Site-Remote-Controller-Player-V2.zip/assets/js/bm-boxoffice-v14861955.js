(() => {
  'use strict';
  const root = document.getElementById('bmBoxOffice');
  if (!root) return;
  const lang = window.BM_BOXOFFICE_LANG === 'en' ? 'en' : 'fa';
  const api = root.dataset.api || '/api_boxoffice.php';
  const isAdmin = root.dataset.admin === '1';
  let mode = 'weekend';
  let loading = false;
  let lastPayload = null;

  const $ = (id) => document.getElementById(id);
  const podium = $('bmBoPodium');
  const list = $('bmBoList');
  const alertBox = $('bmBoAlert');
  const refreshBtn = $('bmBoRefresh');
  const heroTitle = $('bmBoHeroTitle');
  const heroGross = $('bmBoHeroGross');
  const heroRank = $('bmBoHeroRank');
  const updatedAt = $('bmBoUpdatedAt');
  const source = $('bmBoSource');
  const count = $('bmBoCount');
  const total = $('bmBoTotal');
  const totalLabel = $('bmBoTotalLabel');
  const sectionTitle = $('bmBoSectionTitle');
  const legend = $('bmBoLegend');

  const esc = (v) => String(v == null ? '' : v).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
  const safeUrl = (v) => {
    const s = String(v || '').trim();
    if (!s) return '';
    if (s.startsWith('/') && !s.startsWith('//')) return s;
    try { const u = new URL(s, location.origin); return u.protocol === 'https:' ? u.href : ''; } catch (_) { return ''; }
  };
  const money = (n) => {
    n = Number(n || 0);
    if (!Number.isFinite(n) || n <= 0) return '—';
    try { return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',notation:'compact',maximumFractionDigits:1}).format(n); }
    catch (_) { return '$' + Math.round(n).toLocaleString('en-US'); }
  };
  const clock = (iso) => {
    if (!iso) return '—';
    try {
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return '—';
      return new Intl.DateTimeFormat(lang === 'fa' ? 'fa-IR' : 'en-US',{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}).format(d);
    } catch (_) { return '—'; }
  };
  const labels = {
    weekend: {
      title: lang === 'fa' ? 'صدرنشین‌های این هفته' : 'Weekend leaders',
      l1: lang === 'fa' ? 'فروش آخر هفته' : 'Weekend',
      l2: lang === 'fa' ? 'فروش کل' : 'Gross',
      l3: lang === 'fa' ? 'هفته' : 'Weeks',
      total: lang === 'fa' ? 'جمع فروش آخر هفته' : 'Weekend total'
    },
    alltime: {
      title: lang === 'fa' ? 'غول‌های تاریخ گیشه' : 'All-time giants',
      l1: lang === 'fa' ? 'فروش جهانی' : 'Worldwide',
      l2: lang === 'fa' ? 'فروش آمریکا' : 'Domestic',
      l3: lang === 'fa' ? 'سال' : 'Year',
      total: lang === 'fa' ? 'فروش صدر جدول' : 'Leader gross'
    }
  };

  function setLoading(value) {
    loading = value;
    if (refreshBtn) refreshBtn.classList.toggle('is-loading', value);
    root.classList.toggle('is-loading', value);
  }

  function poster(item) {
    return safeUrl(item.local_poster || item.image) || '/assets/brand/bankmovie-icon-256.webp';
  }

  function titleParts(item) {
    const fa = String(item.title_fa || '').trim();
    const en = String(item.title || '').trim();
    return { primary: fa || en, original: fa && fa !== en ? en : '' };
  }

  function titleNode(item, cls) {
    const t = titleParts(item);
    const url = safeUrl(item.local_url || '');
    if (url) return `<a class="${cls}" href="${esc(url)}">${esc(t.primary)}</a>`;
    return `<strong class="${cls}">${esc(t.primary)}</strong>`;
  }

  function renderPodium(items) {
    if (!podium) return;
    const top = (items || []).slice(0,3);
    if (!top.length) {
      podium.innerHTML = `<div class="bm-bo-empty" style="grid-column:1/-1"><strong>${lang==='fa'?'داده‌ای برای نمایش نیست':'No data available'}</strong><span>${lang==='fa'?'وضعیت منبع زنده و کش را در پنل مدیریت بررسی کنید.':'Check the live source and cache status in admin.'}</span></div>`;
      return;
    }
    podium.innerHTML = top.map((item, idx) => {
      const t = titleParts(item);
      const first = mode === 'weekend' ? (item.weekend || money(item.weekend_value)) : (item.worldwide || money(item.worldwide_value));
      const second = mode === 'weekend' ? (item.gross || money(item.gross_value)) : (item.domestic || '—');
      const url = safeUrl(item.local_url || '');
      return `<article class="bm-bo-podium-card">
        <div class="bm-bo-rank-badge">#${esc(item.rank || idx+1)}</div>
        <div class="bm-bo-podium-poster"><img src="${esc(poster(item))}" alt="${esc(t.primary)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/brand/bankmovie-icon-256.webp'"></div>
        <div class="bm-bo-podium-copy">
          <small>${mode==='weekend' ? (lang==='fa'?'صدر جدول آخر هفته':'Weekend chart') : (lang==='fa'?'رکورد جهانی':'Worldwide record')}</small>
          ${titleNode(item,'bm-bo-podium-title-fa')}
          ${t.original ? `<div class="bm-bo-podium-title-en">${esc(t.original)}</div>` : ''}
          <div class="bm-bo-podium-money"><div><span>${esc(labels[mode].l1)}</span><strong>${esc(first || '—')}</strong></div><div><span>${esc(labels[mode].l2)}</span><strong>${esc(second || '—')}</strong></div></div>
          ${url ? `<a class="bm-bo-open" href="${esc(url)}">${lang==='fa'?'مشاهده در بانک مووی':'Open on BankMovie'} <span>←</span></a>` : ''}
        </div>
      </article>`;
    }).join('');
  }

  function metric(label, value, primary=false) {
    return `<div class="bm-bo-metric${primary?' primary':''}"><small>${esc(label)}</small><strong>${esc(value || '—')}</strong></div>`;
  }

  function renderList(items) {
    if (!list) return;
    if (!items || !items.length) {
      list.innerHTML = `<div class="bm-bo-empty"><strong>${lang==='fa'?'فعلاً داده‌ای نداریم':'No data yet'}</strong><span>${lang==='fa'?'دکمه بروزرسانی را بزن یا وضعیت اتصال Paraj را در پنل بررسی کن.':'Refresh or check the Paraj connection status in admin.'}</span></div>`;
      return;
    }
    list.innerHTML = items.map(item => {
      const t = titleParts(item);
      let a,b,c;
      if (mode === 'weekend') {
        a = item.weekend || money(item.weekend_value);
        b = item.gross || money(item.gross_value);
        c = item.weeks ? String(item.weeks) : '—';
      } else {
        a = item.worldwide || money(item.worldwide_value);
        b = item.domestic || '—';
        c = item.year || '—';
      }
      return `<article class="bm-bo-row">
        <div class="bm-bo-movie">
          <div class="bm-bo-row-rank"><span>#</span>${esc(item.rank || '—')}</div>
          <div class="bm-bo-row-poster"><img src="${esc(poster(item))}" alt="${esc(t.primary)}" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/assets/brand/bankmovie-icon-256.webp'"></div>
          <div class="bm-bo-row-copy">
            ${titleNode(item,'bm-bo-row-title')}
            ${t.original ? `<div class="bm-bo-original">${esc(t.original)}</div>` : ''}
            <div class="bm-bo-meta">${item.local_match ? `<span>${lang==='fa'?'موجود در بانک مووی':'On BankMovie'}</span>` : ''}${item.id ? `<span>${esc(item.id)}</span>` : ''}</div>
          </div>
        </div>
        ${metric(labels[mode].l1,a,true)}${metric(labels[mode].l2,b)}${metric(labels[mode].l3,c)}
        <div class="bm-bo-metrics-mobile">${metric(labels[mode].l1,a,true)}${metric(labels[mode].l2,b)}${metric(labels[mode].l3,c)}</div>
      </article>`;
    }).join('');
  }

  function renderHeader(payload) {
    const items = payload.items || [];
    const leader = items[0] || {};
    const t = titleParts(leader);
    if (heroRank) heroRank.textContent = leader.rank || '1';
    if (heroTitle) heroTitle.textContent = t.primary || 'BANKMOVIE';
    if (heroGross) heroGross.textContent = mode === 'weekend' ? (leader.weekend || money(leader.weekend_value)) : (leader.worldwide || money(leader.worldwide_value));
    if (updatedAt) updatedAt.textContent = clock(payload.updated_at);
    if (source) source.textContent = payload.source_label || 'Paraj Live';
    if (count) count.textContent = String((payload.stats && payload.stats.count) || items.length || 0);
    if (sectionTitle) sectionTitle.textContent = labels[mode].title;
    if (totalLabel) totalLabel.textContent = labels[mode].total;
    if (total) total.textContent = mode === 'weekend' ? money(payload.stats && payload.stats.weekend_total_value) : (leader.worldwide || money(leader.worldwide_value));
    if (legend) legend.innerHTML = `<span>${esc(labels[mode].l1)}</span><span>${esc(labels[mode].l2)}</span><span>${esc(labels[mode].l3)}</span>`;
  }

  function showAlert(payload, failed=false) {
    if (!alertBox) return;
    const message = String(payload && payload.message || '').trim();
    if (!message && !payload.stale) { alertBox.hidden = true; alertBox.textContent = ''; alertBox.classList.remove('is-error'); return; }
    alertBox.hidden = false;
    alertBox.classList.toggle('is-error', failed && !payload.stale);
    alertBox.textContent = message || (lang === 'fa' ? 'آخرین داده معتبر ذخیره‌شده نمایش داده می‌شود.' : 'Showing the latest valid cached data.');
  }

  async function load(force=false) {
    if (loading) return;
    setLoading(true);
    try {
      const qs = new URLSearchParams({mode});
      if (force && isAdmin) qs.set('refresh','1');
      qs.set('_', String(Date.now()));
      const res = await fetch(`${api}?${qs.toString()}`, {credentials:'same-origin',headers:{'Accept':'application/json'},cache:'no-store'});
      let payload = {};
      try { payload = await res.json(); } catch (_) {}
      lastPayload = payload;
      if (!res.ok && !payload.items?.length) throw Object.assign(new Error(payload.message || `HTTP ${res.status}`), {payload});
      renderHeader(payload); renderPodium(payload.items || []); renderList(payload.items || []); showAlert(payload, !res.ok);
    } catch (err) {
      const payload = err && err.payload ? err.payload : {message: lang==='fa'?'ارتباط با منبع زنده باکس آفیس برقرار نشد.':'Could not reach the live box office source.',items:[]};
      renderPodium(payload.items || []); renderList(payload.items || []); showAlert(payload,true);
      if (updatedAt) updatedAt.textContent = '—';
      if (count) count.textContent = '0';
      if (total) total.textContent = '—';
    } finally { setLoading(false); }
  }

  document.querySelectorAll('.bm-bo-tab[data-mode]').forEach(btn => btn.addEventListener('click', () => {
    const next = btn.dataset.mode === 'alltime' ? 'alltime' : 'weekend';
    if (next === mode) return;
    mode = next;
    document.querySelectorAll('.bm-bo-tab[data-mode]').forEach(b => b.classList.toggle('is-active', b === btn));
    if (podium) podium.innerHTML = '<div class="bm-bo-podium-skeleton"></div><div class="bm-bo-podium-skeleton"></div><div class="bm-bo-podium-skeleton"></div>';
    if (list) list.innerHTML = Array.from({length:6},()=>'<div class="bm-bo-row-skeleton"><i></i><b></b><span></span></div>').join('');
    load(false);
  }));
  if (refreshBtn) refreshBtn.addEventListener('click', () => load(true));

  load(false);
  window.setInterval(() => { if (!document.hidden) load(false); }, 5 * 60 * 1000);
})();
