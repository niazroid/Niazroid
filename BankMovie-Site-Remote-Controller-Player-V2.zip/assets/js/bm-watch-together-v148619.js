(() => {
  'use strict';
  const cfg = window.BM_MOVIE_CONFIG || {};
  const selectors = [
    '#arc1DownloadSection .arc1-play-btn[data-url]',
    '#arc1DownloadSection .bm-local-play-choice[data-url]',
    '#arc1DownloadSection a.arc1-dl-btn[href]',
    '#arc1DownloadSection a.download-icon[href]',
    '#downloadSection .arc1-play-btn[data-url]',
    '#downloadSection .bm-local-play-choice[data-url]',
    '#downloadSection a.arc1-dl-btn[href]',
    '#downloadSection a.download-icon[href]',
    '#downloadSection [data-video-url]',
    '#downloadSection [data-play-url]'
  ].join(',');
  const blockedExt = /\.(?:srt|vtt|ass|ssa|sub|zip|rar|7z|txt|jpg|jpeg|png|webp)(?:$|[?#])/i;
  const subtitleExt = /\.(?:srt|vtt|ass|ssa|sub)(?:$|[?#])/i;
  const audioExt = /\.(?:mp3|aac|m4a|flac|wav|ogg)(?:$|[?#])/i;

  function absoluteHttpUrl(raw) {
    raw = String(raw || '').trim();
    if (!raw || raw.startsWith('#') || /^javascript:/i.test(raw)) return '';
    try {
      const u = new URL(raw, location.href);
      return /^https?:$/.test(u.protocol) ? u.href : '';
    } catch (_) {
      return '';
    }
  }

  function mediaUrl(element) {
    const raw = element.dataset.url || element.dataset.videoUrl || element.dataset.playUrl || element.getAttribute('href') || '';
    const value = absoluteHttpUrl(raw);
    if (!value || blockedExt.test(value) || audioExt.test(value)) return '';
    return value;
  }

  function isSubtitleOrAudio(element) {
    const own = absoluteHttpUrl(element.getAttribute('href') || element.dataset.url || '');
    if (element.matches('.arc1-sub-dl-btn,.arc4-subtitle-direct,[data-subtitle-only]')) return true;
    if (own && subtitleExt.test(own)) return true;
    const row = element.closest('.arc1-link-row,.download-link,.premium-download-card,.bm-movie-download-row');
    const text = String(row?.textContent || element.textContent || '');
    return /صوت\s*دوبله|audio\s*only/i.test(text) && audioExt.test(own || '');
  }

  function rowFor(element) {
    return element.closest('.arc1-link-row,.download-link,.premium-download-card,.bm-movie-download-row,.download-item,.arc1-quality-item');
  }

  function subtitleUrlFor(element, sourceUrl) {
    const own = absoluteHttpUrl(element.dataset.subtitleUrl || '');
    if (own) return own;

    const row = rowFor(element);
    if (!row) return '';
    let fallback = '';
    for (const candidate of row.querySelectorAll('[data-subtitle-url]')) {
      const sub = absoluteHttpUrl(candidate.dataset.subtitleUrl || '');
      if (!sub) continue;
      const candidateMedia = mediaUrl(candidate);
      if (candidateMedia && candidateMedia === sourceUrl) return sub;
      if (!fallback) fallback = sub;
    }
    if (fallback) return fallback;

    const direct = row.querySelector('.arc1-sub-dl-btn[href],.arc4-subtitle-direct[href],[data-subtitle-only][href]');
    return direct ? absoluteHttpUrl(direct.getAttribute('href') || '') : '';
  }

  function actionHost(element) {
    return element.closest('.arc1-link-actions,.download-actions,.download-card-actions') || rowFor(element) || element.parentElement;
  }

  function buildStartUrl(sourceUrl, subtitleUrl, element) {
    const url = new URL('/watch-party/start', location.origin);
    url.searchParams.set('source_url', sourceUrl);
    if (subtitleUrl) url.searchParams.set('subtitle_url', subtitleUrl);
    if (cfg.csrfToken) url.searchParams.set('csrf_token', String(cfg.csrfToken));
    url.searchParams.set('movie_id', String(cfg.movieId || 0));
    url.searchParams.set('archive_no', String(cfg.archiveNo || 1));
    url.searchParams.set('media_type', String(cfg.mediaType || 'movie'));
    if (cfg.contentTitle) url.searchParams.set('content_title', String(cfg.contentTitle).slice(0, 190));
    if (cfg.posterUrl) url.searchParams.set('poster_url', String(cfg.posterUrl).slice(0, 600));
    const quality = String(rowFor(element)?.querySelector('.quality')?.textContent || element.dataset.label || '').trim();
    const ref = ['movie', cfg.movieId || 0, 'archive', cfg.archiveNo || 1, quality || 'source'].join('-').replace(/[^A-Za-z0-9._:@|\/-]+/g, '-').slice(0, 180);
    url.searchParams.set('source_ref', ref);
    return url.href;
  }

  function createButton(sourceUrl, subtitleUrl, element) {
    const link = document.createElement('a');
    link.className = 'bm-watch-together-btn';
    link.href = buildStartUrl(sourceUrl, subtitleUrl, element);
    link.dataset.bmWatchTogether = '1';
    link.dataset.bmVipGate = 'watch_party';
    link.setAttribute('aria-label', 'تماشای دونفره با Watch Party');
    link.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"/><path d="M16 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8Z"/><path d="M2 21v-2a5 5 0 0 1 5-5h2a5 5 0 0 1 5 5v2"/><path d="M14 14h3a5 5 0 0 1 5 5v2"/></svg><span class="bm-watch-together-label">تماشای دونفره</span><span class="bm-watch-together-vip">VIP</span>';
    return link;
  }

  function enhance(root = document) {
    const elements = [];
    if (root instanceof Element && root.matches(selectors)) elements.push(root);
    if (root.querySelectorAll) elements.push(...root.querySelectorAll(selectors));
    elements.forEach((element) => {
      if (!(element instanceof HTMLElement) || element.dataset.bmWatchTogetherSource === '1') return;
      element.dataset.bmWatchTogetherSource = '1';
      if (isSubtitleOrAudio(element)) return;
      const sourceUrl = mediaUrl(element);
      if (!sourceUrl) return;
      const subtitleUrl = subtitleUrlFor(element, sourceUrl);
      const host = actionHost(element);
      if (!host) return;
      const existing = host.querySelector('.bm-watch-together-btn');
      if (existing) {
        // A dynamic download row may be rendered before its play button. Upgrade
        // the already-created Watch Party URL as soon as subtitle metadata appears.
        if (subtitleUrl) {
          existing.href = buildStartUrl(sourceUrl, subtitleUrl, element);
        }
        return;
      }
      host.classList.add('bm-watch-together-host');
      host.dataset.bmWatchActionsLine = '1';
      const button = createButton(sourceUrl, subtitleUrl, element);
      if (element.parentElement === host) element.insertAdjacentElement('afterend', button);
      else host.appendChild(button);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => enhance(), { once: true });
  else enhance();

  const observer = new MutationObserver((records) => {
    for (const record of records) {
      for (const node of record.addedNodes) {
        if (node.nodeType === 1) enhance(node);
      }
    }
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
