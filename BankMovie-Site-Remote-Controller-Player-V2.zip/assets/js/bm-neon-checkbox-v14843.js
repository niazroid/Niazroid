(function(){
  'use strict';
  var EXCLUDE = [
    '.bm-no-neon','[data-bm-no-neon]','.neon-checkbox input',
    '.switch input','.toggle input','.toggle-switch input','.vip-switch input',
    '.switch-line input','.select-dot input','.movie-select','.filter-choice input','.archive3-mode input','[role="switch"]',
    '[class*="switch"] input','[class*="toggle"] input'
  ].join(',');

  function frameMarkup(){
    return '<div class="neon-checkbox__frame">' +
      '<div class="neon-checkbox__box"></div>' +
      '<div class="neon-checkbox__check-container">' +
        '<svg viewBox="0 0 24 24" class="neon-checkbox__check" aria-hidden="true">' +
          '<path d="M3,12.5l7,7L21,5"></path>' +
        '</svg>' +
      '</div>' +
      '<div class="neon-checkbox__glow"></div>' +
      '<div class="neon-checkbox__borders"><span></span><span></span><span></span><span></span></div>' +
      '<div class="neon-checkbox__particles"><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>' +
      '<div class="neon-checkbox__rings"><div class="ring"></div><div class="ring"></div><div class="ring"></div></div>' +
      '<div class="neon-checkbox__sparks"><span></span><span></span><span></span><span></span></div>' +
    '</div>';
  }

  function syncState(input, wrap){
    wrap.classList.toggle('is-disabled', !!input.disabled);
    wrap.setAttribute('aria-checked', input.checked ? 'true' : 'false');
    wrap.setAttribute('aria-disabled', input.disabled ? 'true' : 'false');
  }

  function upgrade(input){
    if(!(input instanceof HTMLInputElement) || input.type !== 'checkbox') return;
    if(input.dataset.bmNeonReady === '1' || input.matches(EXCLUDE) || input.closest('template,[hidden]')) return;
    input.dataset.bmNeonReady = '1';

    var wrap = document.createElement('span');
    wrap.className = 'neon-checkbox bm-neon-checkbox-wrap';
    wrap.setAttribute('role','checkbox');
    wrap.setAttribute('tabindex', input.disabled ? '-1' : '0');
    input.parentNode.insertBefore(wrap,input);
    wrap.appendChild(input);
    wrap.insertAdjacentHTML('beforeend',frameMarkup());
    syncState(input,wrap);

    input.addEventListener('change',function(){syncState(input,wrap)});
    input.addEventListener('focus',function(){wrap.classList.add('is-focus-visible')});
    input.addEventListener('blur',function(){wrap.classList.remove('is-focus-visible')});
    wrap.addEventListener('keydown',function(event){
      if(input.disabled || (event.key !== ' ' && event.key !== 'Enter')) return;
      event.preventDefault();
      input.click();
    });
    if(!input.closest('label')){
      wrap.addEventListener('click',function(event){
        if(input.disabled || event.target === input) return;
        event.preventDefault();
        input.click();
      });
    }

    new MutationObserver(function(){
      wrap.setAttribute('tabindex',input.disabled?'-1':'0');
      syncState(input,wrap);
    }).observe(input,{attributes:true,attributeFilter:['disabled','checked']});
  }

  function scan(root){
    if(root instanceof HTMLInputElement) upgrade(root);
    if(root && root.querySelectorAll) root.querySelectorAll('input[type="checkbox"]').forEach(upgrade);
  }

  function start(){
    scan(document);
    new MutationObserver(function(records){
      records.forEach(function(record){
        record.addedNodes.forEach(function(node){if(node.nodeType===1) scan(node)});
      });
    }).observe(document.documentElement,{childList:true,subtree:true});
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
