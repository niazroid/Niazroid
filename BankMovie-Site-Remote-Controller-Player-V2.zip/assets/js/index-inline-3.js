
// BankMovie front ad controls: UI only, no server-side logic changes.
(function(){
    const HIDE_MS = 6 * 60 * 60 * 1000;
    function keyFor(slot){ return 'bm_ad_closed_' + (slot?.dataset?.adPosition || 'mobile'); }
    document.querySelectorAll('.bm-ad-slot.bm-ad-floating').forEach(function(slot){
        try {
            const ts = parseInt(localStorage.getItem(keyFor(slot)) || '0', 10);
            if(ts && (Date.now() - ts) < HIDE_MS) slot.remove();
        } catch(e) {}
    });
    document.addEventListener('click', function(e){
        const btn = e.target.closest('[data-bm-ad-close]');
        if(!btn) return;
        const slot = btn.closest('.bm-ad-slot');
        if(!slot) return;
        try { localStorage.setItem(keyFor(slot), String(Date.now())); } catch(e) {}
        slot.remove();
    });
})();

/* BankMovie v148.24: use each desktop ad creative's real aspect ratio. */
(function(){
  'use strict';
  function apply(img){
    var card=img.closest('.bm-ad-card');
    if(!card||!img.naturalWidth||!img.naturalHeight)return;
    var ratio=Math.max(2.4,Math.min(10,img.naturalWidth/img.naturalHeight));
    card.style.setProperty('--bm-ad-natural-ratio',String(ratio));
  }
  document.querySelectorAll('.bm-ad-wide .bm-ad-card img,.bm-ad-hero .bm-ad-card img').forEach(function(img){
    if(img.complete)apply(img);else img.addEventListener('load',function(){apply(img)},{once:true});
  });
})();
