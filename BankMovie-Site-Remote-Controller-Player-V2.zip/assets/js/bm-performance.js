(function(){
  'use strict';
  try{
    var root=document.documentElement;
    var tier=window.__BM_DEVICE_TIER__||{};
    var mobile=!!tier.mobile||!!(window.matchMedia&&matchMedia('(max-width:900px)').matches);
    var lite=!!tier.lite||root.classList.contains('bm-mobile-lite');
    var ultra=!!tier.ultra||root.classList.contains('bm-ultra-lite');
    var saveData=!!tier.saveData;
    var idle=window.requestIdleCallback||function(fn){return setTimeout(fn,180)};
    var cancelIdle=window.cancelIdleCallback||clearTimeout;

    function isPoster(img){
      var c=' '+String(img.className||'')+' ';
      return / poster|poster-img|bm-poster-img|grid-poster|scroll-card-poster|related-poster|search-result-poster /.test(c);
    }
    function firstImportantImage(){
      return document.querySelector('.hero-slide.active img, body.movie-page .movie-poster img, body.movie-page .poster-col img, .hero-slider img, main img');
    }
    function tuneImage(img,important){
      if(!img||img.nodeType!==1||img.__bmTuned)return;
      img.__bmTuned=true;
      if(img===important){
        img.loading='eager';
        img.decoding='async';
        try{img.fetchPriority='high'}catch(e){}
      }else{
        if(!img.hasAttribute('loading'))img.loading='lazy';
        if(!img.hasAttribute('decoding'))img.decoding='async';
        try{img.fetchPriority='low'}catch(e){}
      }
      if(lite&&isPoster(img)){
        if(!img.hasAttribute('width'))img.setAttribute('width','240');
        if(!img.hasAttribute('height'))img.setAttribute('height','360');
      }
    }
    function tuneVideo(v){
      if(!v||v.nodeType!==1||v.__bmTuned)return;
      v.__bmTuned=true;
      if(!v.hasAttribute('preload'))v.preload=mobile?'none':'metadata';
      if(mobile&&!v.hasAttribute('playsinline'))v.setAttribute('playsinline','');
      if((ultra||saveData)&&v.muted&&v.autoplay&&!v.closest('.player-wrapper,#playerWrapper,#arc1PlayerInner')){
        v.autoplay=false;
        try{v.pause()}catch(e){}
      }
    }
    function tuneRoot(node,important){
      if(!node||node.nodeType!==1)return;
      if(node.tagName==='IMG')tuneImage(node,important);
      if(node.tagName==='VIDEO')tuneVideo(node);
      if(node.querySelectorAll){
        node.querySelectorAll('img').forEach(function(img){tuneImage(img,important)});
        node.querySelectorAll('video').forEach(tuneVideo);
      }
    }
    function initialTune(){
      var important=firstImportantImage();
      document.querySelectorAll('img').forEach(function(img){tuneImage(img,important)});
      document.querySelectorAll('video').forEach(tuneVideo);
    }

    var idleId=idle(initialTune);
    if('MutationObserver' in window&&document.body){
      var pending=[];
      var scheduled=0;
      var mo=new MutationObserver(function(records){
        for(var i=0;i<records.length;i++){
          var nodes=records[i].addedNodes;
          for(var j=0;j<nodes.length;j++)if(nodes[j]&&nodes[j].nodeType===1)pending.push(nodes[j]);
        }
        if(!pending.length||scheduled)return;
        scheduled=idle(function(){
          scheduled=0;
          var batch=pending.splice(0,pending.length);
          var important=firstImportantImage();
          for(var k=0;k<batch.length;k++)tuneRoot(batch[k],important);
        });
      });
      mo.observe(document.body,{childList:true,subtree:true});
      setTimeout(function(){
        try{mo.disconnect()}catch(e){}
        if(scheduled)cancelIdle(scheduled);
        pending.length=0;
      },30000);
    }

    document.addEventListener('visibilitychange',function(){
      root.classList.toggle('bm-tab-hidden',document.hidden);
    },{passive:true});

    if(lite&&'IntersectionObserver' in window){
      idle(function(){
        try{
          var io=new IntersectionObserver(function(entries){
            entries.forEach(function(entry){entry.target.classList.toggle('bm-offscreen',!entry.isIntersecting)});
          },{rootMargin:'420px 0px',threshold:0});
          document.querySelectorAll('.hero-slider,.new-releases-section,.collections-section,.admin-picks-section,.top-movies-section,.top-series-section,.user-rated-section,.dubbed-section,.latest-animations-section,.recent-updates-section,.bm-section').forEach(function(el){io.observe(el)});
        }catch(e){}
      });
    }

    window.addEventListener('pageshow',function(){root.classList.remove('bm-tab-hidden')},{passive:true});
  }catch(e){}
})();
