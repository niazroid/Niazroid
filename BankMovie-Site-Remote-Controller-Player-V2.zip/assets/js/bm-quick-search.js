(function(){
    'use strict';

    const FA_RE = /[\u0600-\u06FF]/;

    function normalizeSearchTerm(value){
        return String(value || '')
            .normalize('NFKC')
            .replace(/[يى]/g, 'ی')
            .replace(/ك/g, 'ک')
            .replace(/[ۀة]/g, 'ه')
            .replace(/[ؤ]/g, 'و')
            .replace(/[إأٱ]/g, 'ا')
            .replace(/[\u064B-\u065F\u0670]/g, '')
            .replace(/[\u200C\u200D]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    window.bmNormalizeSearchTerm = normalizeSearchTerm;
    window.bmQuickSearchLoaderMarkup = function(){
        return '<div class="loader-wrapper bm-searching-loader" role="status" aria-live="polite" aria-label="Searching">' +
            '<span class="loader" aria-hidden="true"></span>' +
            '<span class="letter-wrapper" aria-hidden="true" dir="ltr">' +
                '<span class="loader-letter">S</span>' +
                '<span class="loader-letter">e</span>' +
                '<span class="loader-letter">a</span>' +
                '<span class="loader-letter">r</span>' +
                '<span class="loader-letter">c</span>' +
                '<span class="loader-letter">h</span>' +
                '<span class="loader-letter">i</span>' +
                '<span class="loader-letter">n</span>' +
                '<span class="loader-letter">g</span>' +
            '</span>' +
        '</div>';
    };

    function initQuickSearch(){
        const modal = document.getElementById('bmQuickSearchModal');
        const openBtn = document.getElementById('bmHeaderQuickSearchBtn');
        const closeBtn = document.getElementById('bmQuickSearchClose');
        const input = document.getElementById('unifiedSearchInput');
        const results = document.getElementById('unifiedSearchResults');
        const submit = document.getElementById('bmQuickSearchSubmit');
        const homeInput = document.getElementById('bmHomeSearchInput');
        const homeOpenBtn = document.getElementById('bmHomeQuickSearchBtn');
        const homePoda = document.getElementById('bmHomeSearchPoda');
        const footerOpenButtons = Array.from(document.querySelectorAll('.bm-footer-search-trigger'));
        const archiveButtons = Array.from(document.querySelectorAll('.bm-quick-archive-btn'));
        const archiveHint = document.getElementById('bmQuickArchiveHint');

        if(!modal || !openBtn || !input) return;

        let lastFocused = null;
        let focusTimer = 0;
        let maxViewportHeight = 0;
        let viewportFrame = 0;
        const isFa = ((window.BM_HOME_CONFIG && BM_HOME_CONFIG.userLang) || 'fa') === 'fa';
        const hints = (window.BM_HOME_CONFIG && BM_HOME_CONFIG.arcHints) || {};

        function pageArchive(){
            return document.documentElement.getAttribute('data-bm-archive') ||
                ((window.BM_HOME_CONFIG && BM_HOME_CONFIG.activeArchive) || 'local');
        }

        function searchArchive(){
            return window.BM_QUICK_SEARCH_ARCHIVE || pageArchive();
        }

        function archivePlaceholder(mode){
            if(!isFa){
                if(mode === 'arc1') return 'Search Archive 1...';
                if(mode === 'arc3') return 'Search Archive 3...';
                if(mode === 'arc4') return 'Search Archive 4...';
                return 'Search movies, series or actors...';
            }
            if(mode === 'arc1') return 'جستجو در آرشیو ۱...';
            if(mode === 'arc3') return 'جستجو در آرشیو ۳...';
            if(mode === 'arc4') return 'جستجو در آرشیو ۴...';
            return 'جستجوی فیلم، سریال یا بازیگر...';
        }

        function syncInputDirection(){
            const value = input.value.trim();
            const rtl = value ? FA_RE.test(value.charAt(0)) : isFa;
            input.setAttribute('dir', rtl ? 'rtl' : 'ltr');
        }

        function syncArchiveUi(mode){
            const safeMode = mode || searchArchive();
            window.BM_QUICK_SEARCH_ARCHIVE = safeMode;
            archiveButtons.forEach(function(btn){
                const active = btn.dataset.mode === safeMode;
                btn.classList.toggle('active', active);
                btn.setAttribute('aria-pressed', active ? 'true' : 'false');
            });
            if(archiveHint) archiveHint.textContent = hints[safeMode] || '';
            input.placeholder = archivePlaceholder(safeMode);
        }

        function applyVisualViewport(){
            viewportFrame = 0;
            const viewport = window.visualViewport;
            const height = Math.round(viewport ? viewport.height : window.innerHeight);
            const top = Math.round(viewport ? viewport.offsetTop : 0);
            if(!maxViewportHeight || height > maxViewportHeight) maxViewportHeight = height;
            const keyboardGap = Math.max(0, maxViewportHeight - height);
            const keyboardOpen = modal.classList.contains('open') &&
                document.activeElement === input &&
                keyboardGap > 100;

            document.documentElement.style.setProperty('--bm-quick-vh', height + 'px');
            document.documentElement.style.setProperty('--bm-quick-vtop', top + 'px');
            modal.style.setProperty('--bm-quick-vh', height + 'px');
            modal.style.setProperty('--bm-quick-vtop', top + 'px');
            modal.classList.toggle('bm-keyboard-open', keyboardOpen);
            document.documentElement.classList.toggle('bm-quick-keyboard-open', keyboardOpen);
        }

        function syncVisualViewport(){
            if(viewportFrame) return;
            viewportFrame = window.requestAnimationFrame(applyVisualViewport);
        }

        function openModal(){
            lastFocused = document.activeElement === homeInput ? (homeOpenBtn || homeInput) : document.activeElement;
            window.BM_QUICK_SEARCH_ARCHIVE = pageArchive();
            syncArchiveUi(window.BM_QUICK_SEARCH_ARCHIVE);
            syncInputDirection();
            maxViewportHeight = Math.max(window.innerHeight || 0, window.visualViewport ? window.visualViewport.height : 0);
            modal.classList.add('open');
            syncVisualViewport();
            modal.setAttribute('aria-hidden','false');
            openBtn.setAttribute('aria-expanded','true');
            if(homeOpenBtn) homeOpenBtn.setAttribute('aria-expanded','true');
            footerOpenButtons.forEach(function(btn){ btn.setAttribute('aria-expanded','true'); });
            document.documentElement.classList.add('bm-quick-search-open');
            document.body.classList.add('bm-quick-search-open');
            window.clearTimeout(focusTimer);
            focusTimer = window.setTimeout(function(){
                try{ input.focus({preventScroll:true}); }
                catch(e){ input.focus(); }
                syncVisualViewport();
                window.setTimeout(syncVisualViewport, 90);
                window.setTimeout(syncVisualViewport, 240);
                window.setTimeout(syncVisualViewport, 420);
            }, 40);
        }

        function closeModal(){
            window.clearTimeout(focusTimer);
            modal.classList.remove('open');
            modal.classList.remove('bm-keyboard-open');
            document.documentElement.classList.remove('bm-quick-keyboard-open');
            modal.setAttribute('aria-hidden','true');
            openBtn.setAttribute('aria-expanded','false');
            if(homeOpenBtn) homeOpenBtn.setAttribute('aria-expanded','false');
            footerOpenButtons.forEach(function(btn){ btn.setAttribute('aria-expanded','false'); });
            document.documentElement.classList.remove('bm-quick-search-open');
            document.body.classList.remove('bm-quick-search-open');
            if(results) results.classList.remove('active');
            const coarsePointer = window.matchMedia && window.matchMedia('(pointer:coarse)').matches;
            if(!coarsePointer && lastFocused && typeof lastFocused.focus === 'function'){
                try{ lastFocused.focus({preventScroll:true}); }
                catch(e){ lastFocused.focus(); }
            }
        }

        function runSearch(){
            const term = normalizeSearchTerm(input.value);
            if(term.length < 2){
                input.focus();
                const card = document.getElementById('unifiedSearchSection');
                if(card && typeof card.animate === 'function' && !window.matchMedia('(max-width:700px)').matches){
                    card.animate([
                        {transform:'translateX(0)'},
                        {transform:'translateX(-4px)'},
                        {transform:'translateX(4px)'},
                        {transform:'translateX(0)'}
                    ], {duration:180, easing:'ease-out'});
                }
                return;
            }
            input.dispatchEvent(new Event('input', {bubbles:true}));
        }

        openBtn.setAttribute('aria-expanded','false');
        openBtn.addEventListener('click', function(event){
            event.preventDefault();
            openModal();
        });
        footerOpenButtons.forEach(function(btn){
            btn.setAttribute('aria-expanded','false');
            btn.addEventListener('click', function(event){
                event.preventDefault();
                openModal();
            });
        });
        if(homeOpenBtn){
            homeOpenBtn.setAttribute('aria-expanded','false');
            homeOpenBtn.addEventListener('click', function(event){
                event.preventDefault();
                openModal();
            });
        }
        if(homeInput){
            homeInput.addEventListener('focus', function(){ openModal(); });
            homeInput.addEventListener('click', function(event){
                event.preventDefault();
                openModal();
            });
        }
        if(homePoda){
            homePoda.addEventListener('click', function(event){
                if(event.target === homeInput || (event.target.closest && event.target.closest('#bmHomeQuickSearchBtn'))) return;
                openModal();
            });
        }
        closeBtn && closeBtn.addEventListener('click', closeModal);
        submit && submit.addEventListener('click', runSearch);

        input.addEventListener('input', syncInputDirection, {passive:true});
        input.addEventListener('focus', syncVisualViewport, {passive:true});
        input.addEventListener('blur', function(){
            window.setTimeout(syncVisualViewport, 30);
        }, {passive:true});
        input.addEventListener('keydown', function(event){
            if(event.key === 'Enter'){
                event.preventDefault();
                runSearch();
            }
        });

        archiveButtons.forEach(function(btn){
            btn.setAttribute('aria-pressed','false');
            btn.addEventListener('click', function(){
                if(btn.dataset.enabled === '0'){
                    const message = btn.dataset.disabledMessage || (isFa ? 'این آرشیو موقتاً در دسترس نیست.' : 'This archive is temporarily unavailable.');
                    if(typeof window.showToast === 'function') window.showToast(message);
                    else window.alert(message);
                    return;
                }

                const mode = btn.dataset.mode || 'local';
                window.BM_QUICK_SEARCH_ARCHIVE = mode;
                syncArchiveUi(mode);

                if(results){
                    results.innerHTML = '';
                    results.classList.remove('active');
                }

                if(normalizeSearchTerm(input.value).length >= 2){
                    results.innerHTML = window.bmQuickSearchLoaderMarkup();
                    results.classList.add('active');
                    input.dispatchEvent(new Event('input', {bubbles:true}));
                }else{
                    input.focus();
                }
            });
        });

        modal.addEventListener('click', function(event){
            if(event.target === modal) closeModal();
        });

        document.addEventListener('keydown', function(event){
            if(event.key === 'Escape' && modal.classList.contains('open')){
                event.preventDefault();
                closeModal();
                return;
            }
            if(event.key === 'Tab' && modal.classList.contains('open')){
                const focusable = Array.from(modal.querySelectorAll('button:not([disabled]),a[href],input:not([disabled])'))
                    .filter(function(el){ return el.offsetParent !== null; });
                if(!focusable.length) return;
                const first = focusable[0];
                const last = focusable[focusable.length - 1];
                if(event.shiftKey && document.activeElement === first){
                    event.preventDefault();
                    last.focus();
                }else if(!event.shiftKey && document.activeElement === last){
                    event.preventDefault();
                    first.focus();
                }
            }
        });

        const observer = new MutationObserver(function(mutations){
            if(modal.classList.contains('open')) return;
            for(const mutation of mutations){
                if(mutation.type === 'attributes' && mutation.attributeName === 'data-bm-archive'){
                    window.BM_QUICK_SEARCH_ARCHIVE = pageArchive();
                    syncArchiveUi(window.BM_QUICK_SEARCH_ARCHIVE);
                    break;
                }
            }
        });
        observer.observe(document.documentElement, {attributes:true, attributeFilter:['data-bm-archive']});

        if(window.visualViewport){
            window.visualViewport.addEventListener('resize', syncVisualViewport, {passive:true});
            window.visualViewport.addEventListener('scroll', syncVisualViewport, {passive:true});
        }
        window.addEventListener('resize', syncVisualViewport, {passive:true});

        window.bmQuickSearchGetArchive = searchArchive;
        window.bmQuickSearchOpen = openModal;
        window.bmQuickSearchClose = closeModal;
        syncArchiveUi(pageArchive());
        syncInputDirection();
        syncVisualViewport();
    }

    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initQuickSearch, {once:true});
    else initQuickSearch();
})();
