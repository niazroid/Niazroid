/* BankMovie Premium UI v140 — behavior-neutral polish */
(function(){
  'use strict';

  var ticking = false;
  function updateHeaderState(){
    document.body.classList.toggle('bm-header-scrolled', window.scrollY > 24);
    ticking = false;
  }
  if(document.documentElement.classList.contains('bm-nav-static')){
    // V47: weak/mid phones keep a stable header; avoid one extra rAF/style toggle on every scroll frame.
    document.body.classList.remove('bm-header-scrolled');
  }else{
    window.addEventListener('scroll', function(){
      if (!ticking) {
        ticking = true;
        window.requestAnimationFrame(updateHeaderState);
      }
    }, {passive:true});
    updateHeaderState();
  }

  function markStoryMedia(node){
    if (!node || !node.closest) return;
    var avatar = node.closest('.story-avatar');
    if (avatar) avatar.classList.add('bm-media-failed');
  }

  function inspectStoryMedia(root){
    (root || document).querySelectorAll('.story-avatar img').forEach(function(img){
      if (img.dataset.bmUiBound === '1') return;
      img.dataset.bmUiBound = '1';
      img.addEventListener('error', function(){ markStoryMedia(img); }, {once:true});
      if (img.complete && img.naturalWidth === 0) markStoryMedia(img);
    });
    (root || document).querySelectorAll('.story-avatar video').forEach(function(video){
      if (video.dataset.bmUiBound === '1') return;
      video.dataset.bmUiBound = '1';
      video.addEventListener('error', function(){
        var avatar = video.closest('.story-avatar');
        var usableImage = avatar && avatar.querySelector('img:not([hidden])');
        if (!usableImage) markStoryMedia(video);
      }, {once:true});
    });
  }

  function improveEpisodeAccessibility(root){
    (root || document).querySelectorAll('.arc1-ep-head').forEach(function(head){
      if (head.dataset.bmUiA11y === '1') return;
      head.dataset.bmUiA11y = '1';
      head.setAttribute('role','button');
      head.setAttribute('tabindex','0');
      var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
      head.addEventListener('keydown', function(event){
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          head.click();
          window.setTimeout(function(){
            var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
          }, 0);
        }
      });
      head.addEventListener('click', function(){
        window.setTimeout(function(){
          var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
        }, 0);
      });
    });
  }

  function hydrate(root){
    inspectStoryMedia(root);
    improveEpisodeAccessibility(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ hydrate(document); });
  } else {
    hydrate(document);
  }

  var observer = new MutationObserver(function(mutations){
    mutations.forEach(function(mutation){
      mutation.addedNodes.forEach(function(node){
        if (node.nodeType === 1) hydrate(node);
      });
    });
  });
  observer.observe(document.documentElement, {childList:true, subtree:true});
})();


/* BankMovie v143 — mobile white-flash / fullscreen recovery hardening */
(function(){
  'use strict';

  var PLAYER_SELECTOR = '.player-wrapper,#arc1PlayerInner,.bm-player-shell,#arc1PlayerWrapper';
  var wasFullscreen = isFullscreen();
  var cleanupTimer = 0;

  function isFullscreen(){
    return !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
  }

  function hasPlayer(){
    return !!document.querySelector(PLAYER_SELECTOR);
  }

  function hasBlockingOverlay(){
    return !!document.querySelector(
      '.sidebar-menu.open,.notif-sidebar.open,.bm-play-choice-overlay.active,' +
      '.bm-play-choice-backdrop.active,.modal.active,.modal-glass.active,' +
      '#bmAppInstallModal.open,.bm-share-sheet.is-open,.archive-guide-overlay.active'
    );
  }

  function prepareStoryVideos(root){
    (root || document).querySelectorAll('.story-thumb-video').forEach(function(video){
      if(video.readyState >= 1) video.classList.add('is-loaded');
      if(video.dataset.bmV143Bound === '1') return;
      video.dataset.bmV143Bound = '1';
      ['loadedmetadata','loadeddata','canplay'].forEach(function(name){
        video.addEventListener(name,function(){
          video.classList.add('is-loaded');
          var wrap = video.closest('.story-video-thumb-wrap');
          if(wrap) wrap.classList.add('is-loaded');
        },{passive:true});
      });
      video.addEventListener('error',function(){
        video.classList.remove('is-loaded');
        var wrap = video.closest('.story-video-thumb-wrap');
        if(wrap) wrap.classList.remove('is-loaded');
      },{passive:true});
    });
  }

  function removeForcedPlayerGeometry(){
    document.querySelectorAll(PLAYER_SELECTOR).forEach(function(el){
      if(!el || !el.style) return;
      ['position','inset','left','right','top','bottom','width','max-width','height','max-height','min-height','transform'].forEach(function(prop){
        el.style.removeProperty(prop);
      });
    });
  }

  function recoverAfterFullscreenExit(){
    if(isFullscreen() || !hasPlayer()) return;

    document.body.classList.remove('fullscreen-active');
    document.documentElement.classList.remove('bm-orientation-transition');
    removeForcedPlayerGeometry();

    try{
      if(screen.orientation && typeof screen.orientation.unlock === 'function') screen.orientation.unlock();
    }catch(e){}

    /* Restore page scroll only when a player/overlay had explicitly fixed the body.
       Never run scrollTo on ordinary viewport resize: Chrome changes visualViewport
       while its address bar moves and that was the source of the white repaint flash. */
    if(!hasBlockingOverlay() && document.body.style.position === 'fixed'){
      var top = parseInt(document.body.style.top || '0',10);
      var restoreY = Number.isFinite(top) ? Math.max(0,-top) : (window.pageYOffset || 0);
      ['overflow','position','top','left','right','width','height'].forEach(function(prop){
        document.body.style.removeProperty(prop);
      });
      if(document.documentElement.style.overflow === 'hidden'){
        document.documentElement.style.removeProperty('overflow');
      }
      window.requestAnimationFrame(function(){
        try{ window.scrollTo(0,restoreY); }catch(e){}
      });
    }
  }

  function scheduleExitRecovery(){
    window.clearTimeout(cleanupTimer);
    cleanupTimer = window.setTimeout(function(){
      window.requestAnimationFrame(recoverAfterFullscreenExit);
      window.setTimeout(recoverAfterFullscreenExit,160);
    },40);
  }

  function handleFullscreenChange(){
    var nowFullscreen = isFullscreen();
    if(wasFullscreen && !nowFullscreen) scheduleExitRecovery();
    wasFullscreen = nowFullscreen;
  }

  document.addEventListener('fullscreenchange',handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange',handleFullscreenChange);

  /* Orientation cleanup is player-only. It is deliberately not attached to
     resize/visualViewport.resize, so normal scrolling cannot trigger reflow. */
  window.addEventListener('orientationchange',function(){
    if(hasPlayer() && !isFullscreen()) scheduleExitRecovery();
  },{passive:true});

  window.addEventListener('pageshow',function(){
    prepareStoryVideos(document);
    if(hasPlayer() && !isFullscreen()) scheduleExitRecovery();
  },{passive:true});

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded',function(){ prepareStoryVideos(document); });
  }else{
    prepareStoryVideos(document);
  }

  var observer = new MutationObserver(function(mutations){
    mutations.forEach(function(mutation){
      mutation.addedNodes.forEach(function(node){
        if(node.nodeType === 1) prepareStoryVideos(node);
      });
    });
  });
  observer.observe(document.documentElement,{childList:true,subtree:true});
})();
