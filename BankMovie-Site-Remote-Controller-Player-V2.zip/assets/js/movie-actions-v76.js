// =================== واجد شرایط ===================
document.getElementById('watchlistBtn')?.addEventListener('click', async function() {
    if(!userId) {
        if(window.BMDialog){
            await window.BMDialog.alert({
                icon:'info',
                title:userLang === 'fa' ? 'ورود لازم است' : 'Login required',
                message:userLang === 'fa' ? 'برای نشان کردن این عنوان باید وارد حساب کاربری شوید.' : 'Please log in to add this title to your watchlist.',
                confirmText:userLang === 'fa' ? 'باشه' : 'OK'
            });
        } else {
            showToast(userLang === 'fa' ? 'برای نشان کردن باید وارد حساب شوید' : 'Please login to use watchlist');
        }
        return;
    }
    const action = inWatchlist ? 'remove' : 'add';
    const fd = new FormData();
    fd.append('csrf_token', csrfToken);
    fd.append('action', action);
    fd.append('imdb_code', imdbCode);
    try {
        const res = await fetch('/ajax_watchlist.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            inWatchlist = data.added;
            if(inWatchlist) { this.classList.add('active'); this.querySelector('svg').setAttribute('fill', 'currentColor'); showToast(userLang === 'fa' ? 'به نشانه‌ها اضافه شد' : 'Added to watchlist'); }
            else { this.classList.remove('active'); this.querySelector('svg').setAttribute('fill', 'none'); showToast(userLang === 'fa' ? 'از نشانه‌ها حذف شد' : 'Removed from watchlist'); }
        }
    } catch(e) { console.error(e); }
});

document.getElementById('subkadeBtn')?.addEventListener('click', () => { let q = document.getElementById('subkadeInput').value.trim(); if(!q) { document.getElementById('subkadeMsg').innerHTML = userLang === 'fa' ? 'لطفاً نام فیلم را وارد کنید' : 'Please enter movie name'; return; } document.getElementById('subkadeMsg').innerHTML = userLang === 'fa' ? 'در حال انتقال...' : 'Redirecting...'; setTimeout(() => { window.open(`https://subkade.ir/?s=${encodeURIComponent(q)}`, '_blank'); document.getElementById('subkadeMsg').innerHTML = userLang === 'fa' ? 'در تب جدید باز شد' : 'Opened in new tab'; setTimeout(() => document.getElementById('subkadeMsg').innerHTML = '', 3000); }, 200); });
function bmBuildShareData(){
    const url = window.location.href.split('#')[0];
    const title = (document.querySelector('.movie-title-fa')?.innerText || document.title || 'BankMovie').trim();
    const text = `${title} - BankMovie`;
    return {url, title, text, full: `${text}\n${url}`};
}
function bmCopyText(text){
    if(navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); } catch(e) {}
    ta.remove();
    return Promise.resolve();
}
function bmOpenShareSheet(){
    const sheet = document.getElementById('bmShareSheet');
    const input = document.getElementById('bmShareUrl');
    const data = bmBuildShareData();
    if(input) input.value = data.url;
    if(sheet){
        sheet.classList.add('active');
        sheet.setAttribute('aria-hidden','false');
        document.body.style.overflow = 'hidden';
    }
}
function bmCloseShareSheet(){
    const sheet = document.getElementById('bmShareSheet');
    if(sheet){
        sheet.classList.remove('active');
        sheet.setAttribute('aria-hidden','true');
        document.body.style.overflow = '';
    }
}
document.querySelectorAll('.bm-share-open, #shareBtn').forEach(btn => {
    btn.addEventListener('click', function(e){
        e.preventDefault();
        bmOpenShareSheet();
    });
});
document.querySelectorAll('[data-bm-share-close]').forEach(btn => btn.addEventListener('click', bmCloseShareSheet));
document.getElementById('bmShareSheet')?.addEventListener('click', function(e){
    if(e.target === this) bmCloseShareSheet();
});
document.querySelectorAll('[data-share-platform]').forEach(el => {
    el.addEventListener('click', async function(e){
        const platform = this.getAttribute('data-share-platform');
        const data = bmBuildShareData();
        const encUrl = encodeURIComponent(data.url);
        const encText = encodeURIComponent(data.text);
        let href = '';
        if(platform === 'telegram') href = `https://t.me/share/url?url=${encUrl}&text=${encText}`;
        if(platform === 'whatsapp') href = `https://wa.me/?text=${encodeURIComponent(data.full)}`;
        if(platform === 'twitter') href = `https://twitter.com/intent/tweet?url=${encUrl}&text=${encText}`;
        if(platform === 'sms') href = `sms:?&body=${encodeURIComponent(data.full)}`;
        if(platform === 'instagram') {
            e.preventDefault();
            await bmCopyText(data.full);
            showToast(userLang === 'fa' ? 'متن و لینک کپی شد؛ در اینستاگرام Paste کنید' : 'Copied for Instagram');
            window.open('https://www.instagram.com/', '_blank', 'noopener');
            return;
        }
        if(platform === 'copy') {
            e.preventDefault();
            await bmCopyText(data.full);
            showToast(userLang === 'fa' ? 'لینک کپی شد' : 'Link copied');
            return;
        }
        if(href) this.setAttribute('href', href);
    });
});
document.getElementById('reportBtn')?.addEventListener('click', async () => {
    const p = await window.BMDialog.prompt({
        title:userLang === 'fa' ? 'گزارش مشکل' : 'Report a problem',
        message:userLang === 'fa' ? 'مشکلی که دیدی را کوتاه و دقیق بنویس.' : 'Briefly describe the issue you found.',
        label:userLang === 'fa' ? 'توضیحات مشکل' : 'Problem details',
        placeholder:userLang === 'fa' ? 'مثلاً لینک پخش مشکل دارد...' : 'For example: playback link is broken...',
        confirmText:userLang === 'fa' ? 'ثبت گزارش' : 'Submit report',
        cancelText:userLang === 'fa' ? 'انصراف' : 'Cancel',
        multiline:true
    });
    if(p && p.trim()) showToast(userLang === 'fa' ? 'گزارش شما ثبت شد.' : 'Report submitted.');
    else if(p !== null) showToast(userLang === 'fa' ? 'لطفاً مشکل را بنویسید.' : 'Please write the problem.');
});
const helpModal = document.getElementById('helpModal'), helpModalBtn = document.getElementById('helpModalBtn'), closeHelpModal = document.getElementById('closeHelpModal');
if(helpModalBtn && helpModal) { helpModalBtn.onclick = () => helpModal.classList.add('active'); closeHelpModal.onclick = () => helpModal.classList.remove('active'); helpModal.addEventListener('click', (e) => { if(e.target === helpModal) helpModal.classList.remove('active'); }); }
const donateBtn = document.getElementById('donateModalBtn'), playerDonateSideBtn = document.getElementById('playerDonateSideBtn'), donateModal = document.getElementById('donateModal');
if(donateBtn && donateModal) { donateBtn.onclick = () => donateModal.style.display = 'flex'; document.getElementById('closeDonateModal')?.addEventListener('click', () => donateModal.style.display = 'none'); document.getElementById('openDonateLink')?.addEventListener('click', () => { window.open('https://daramet.com/manuel', '_blank'); donateModal.style.display = 'none'; }); donateModal.addEventListener('click', (e) => { if(e.target === donateModal) donateModal.style.display = 'none'; }); }


// Notification modal is handled by the small inline script next to the modal.

window.BM_MOVIE_ACTIONS_BUILD='v76';
