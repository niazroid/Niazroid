/* BankMovie shared UI polish — v145 */
(function(){
  'use strict';
  if (window.__BM_POLISH_V145__) return;
  window.__BM_POLISH_V145__ = true;

  var body = document.body;
  if (!body) return;
  body.classList.add('bm-ui-v145');

  var header = document.getElementById('siteHeader');
  if (header) {
    var cinematic = !!document.querySelector('.hero-slider,.movie-detail,[data-bm-cinematic-hero]');
    body.classList.remove('bm-v145-cinematic-header','bm-v145-solid-header');
    body.classList.add(cinematic ? 'bm-v145-cinematic-header' : 'bm-v145-solid-header');
  }

  var main = document.querySelector('main,[role="main"],.main-content,.content-wrapper,.page-content,.movie-detail');
  if (main && !main.id) main.id = 'main-content';

  function isInteractive(target){
    return !!(target && target.closest && target.closest('button,input,textarea,select,label,[role="button"]'));
  }

  function setupRail(rail){
    if (!rail || rail.dataset.bmV145Rail === '1') return;
    rail.dataset.bmV145Rail = '1';
    rail.setAttribute('tabindex', rail.getAttribute('tabindex') || '0');
    rail.setAttribute('role', rail.getAttribute('role') || 'region');
    rail.setAttribute('aria-label', rail.getAttribute('aria-label') || 'فهرست افقی محتوا');

    var host = rail.parentElement;
    if (host) host.classList.add('bm-rail-host');

    var dragging = false, moved = false, startX = 0, startScroll = 0, pointerId = null;
    var rtl = getComputedStyle(rail).direction === 'rtl';

    rail.addEventListener('pointerdown', function(e){
      if (e.pointerType !== 'mouse' || e.button !== 0 || isInteractive(e.target)) return;
      dragging = true; moved = false; pointerId = e.pointerId; startX = e.clientX; startScroll = rail.scrollLeft;
      rail.classList.add('is-dragging');
      try { rail.setPointerCapture(pointerId); } catch (_) {}
    });
    rail.addEventListener('pointermove', function(e){
      if (!dragging || e.pointerId !== pointerId) return;
      var dx = e.clientX - startX;
      if (Math.abs(dx) > 5) moved = true;
      rail.scrollLeft = startScroll + dx * (rtl ? 1 : -1);
    });
    function endDrag(e){
      if (!dragging || (e && pointerId !== null && e.pointerId !== pointerId)) return;
      dragging = false; rail.classList.remove('is-dragging');
      try { if (pointerId !== null) rail.releasePointerCapture(pointerId); } catch (_) {}
      pointerId = null;
    }
    rail.addEventListener('pointerup', endDrag);
    rail.addEventListener('pointercancel', endDrag);
    rail.addEventListener('lostpointercapture', endDrag);
    rail.addEventListener('click', function(e){
      if (!moved) return;
      e.preventDefault(); e.stopPropagation(); moved = false;
    }, true);

    rail.addEventListener('keydown', function(e){
      if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
      e.preventDefault();
      rail.scrollBy({left:(e.key === 'ArrowLeft' ? -1 : 1) * Math.max(260, rail.clientWidth * .72),behavior:'smooth'});
    });

    if (!host || window.matchMedia('(max-width: 991px)').matches) return;
    var left = document.createElement('button');
    var right = document.createElement('button');
    left.type = right.type = 'button';
    left.className = 'bm-rail-arrow is-left';
    right.className = 'bm-rail-arrow is-right';
    left.setAttribute('aria-label','حرکت به چپ');
    right.setAttribute('aria-label','حرکت به راست');
    left.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
    right.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 18l6-6-6-6"/></svg>';
    host.appendChild(left); host.appendChild(right);

    function move(sign){ rail.scrollBy({left:sign * Math.max(300, rail.clientWidth * .76),behavior:'smooth'}); }
    left.addEventListener('click',function(){move(-1)});
    right.addEventListener('click',function(){move(1)});

    function updateArrows(){
      var max = Math.max(0, rail.scrollWidth - rail.clientWidth);
      if (max < 12) { left.disabled = right.disabled = true; return; }
      /* RTL scrollLeft differs across engines; only hide both when no overflow.
         Keeping both arrows available is safer and predictable. */
      left.disabled = false; right.disabled = false;
    }
    rail.addEventListener('scroll',updateArrows,{passive:true});
    window.addEventListener('resize',updateArrows,{passive:true});
    updateArrows();
  }

  function initRails(root){
    (root || document).querySelectorAll('.scroll-horizontal').forEach(setupRail);
  }
  initRails(document);

  var observer = new MutationObserver(function(records){
    records.forEach(function(record){
      record.addedNodes.forEach(function(node){
        if (!node || node.nodeType !== 1) return;
        if (node.matches && node.matches('.scroll-horizontal')) setupRail(node);
        if (node.querySelectorAll) initRails(node);
      });
    });
  });
  observer.observe(document.documentElement,{childList:true,subtree:true});

  /* Keep the shared footer near the viewport bottom on short pages without
     changing the document structure or page-specific layout. */
  function settleFooter(){
    var footer = document.querySelector('.bm-global-footer');
    if (!footer) return;
    footer.style.marginTop = '';
    requestAnimationFrame(function(){
      var rect = footer.getBoundingClientRect();
      var viewport = window.innerHeight || document.documentElement.clientHeight;
      var gap = viewport - rect.bottom;
      if (gap > 8) {
        var current = parseFloat(getComputedStyle(footer).marginTop) || 0;
        footer.style.marginTop = (current + gap) + 'px';
      }
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded',settleFooter,{once:true}); else settleFooter();
  window.addEventListener('load',settleFooter,{once:true});
  window.addEventListener('resize',settleFooter,{passive:true});
  setTimeout(settleFooter,400);
  setTimeout(settleFooter,1200);
})();
