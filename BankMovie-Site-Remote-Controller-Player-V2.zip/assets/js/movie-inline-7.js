
document.addEventListener('click', function(e){
    var readBtn = e.target.closest('[data-readmore-toggle]');
    if(readBtn){
        var box = readBtn.closest('.bm-readmore-desc');
        if(box){
            var collapsed = box.getAttribute('data-collapsed') !== '0';
            box.setAttribute('data-collapsed', collapsed ? '0' : '1');
            readBtn.textContent = collapsed ? 'بستن داستان' : 'ادامه داستان';
        }
    }
    var actorsBtn = e.target.closest('[data-actors-toggle]');
    if(actorsBtn){
        var section = actorsBtn.closest('.bm-arc1-actors-section');
        var list = section ? section.querySelector('[data-actors-list]') : null;
        if(list){
            var expanded = list.classList.toggle('is-expanded');
            actorsBtn.textContent = expanded ? 'نمایش کمتر' : 'مشاهده همه بازیگران';
        }
    }
});
