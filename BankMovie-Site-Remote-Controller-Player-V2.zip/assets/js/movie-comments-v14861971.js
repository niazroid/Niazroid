// =================== کامنت‌ها (با پشتیبانی از اسپویلر جدید و دکمه تگ) ===================
// Surgical v148 fix: stable, readable English states for the main comment button.
function bmSetMainCommentButtonState(button, state) {
    if (!button) return;
    button.classList.remove('bm-comment-send-button', 'is-sending', 'is-sent');
    button.classList.add('bm-comment-submit-safe');
    button.dataset.bmState = state;
    button.setAttribute('aria-live', 'polite');
    if (state === 'sending') {
        button.disabled = true;
        button.textContent = 'Sending...';
    } else if (state === 'sent') {
        button.disabled = true;
        button.textContent = 'Sent';
    } else {
        button.disabled = false;
        button.textContent = 'Send';
    }
}
function bmRestoreSimpleCommentSubmitButton() {
    bmSetMainCommentButtonState(document.getElementById('submitCommentBtn'), 'idle');
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', bmRestoreSimpleCommentSubmitButton, { once: true });
} else {
    bmRestoreSimpleCommentSubmitButton();
}


// v148.61.9.68 — free sticker/GIF attachments for movie comments and replies.
// One sticker can now be attached to normal text, Telegram-style.
const BM_COMMENT_MEDIA = (window.BM_MOVIE_CONFIG && window.BM_MOVIE_CONFIG.commentMedia) || {};
const BM_COMMENT_MEDIA_PACKS = BM_COMMENT_MEDIA.packs || {};
const BM_COMMENT_MEDIA_MARKER_RE = /\[bm-sticker:([a-z0-9_-]{1,40}):([a-f0-9]{24})\]/i;
const BM_COMMENT_MEDIA_INDEX = (() => {
    const out = {};
    Object.keys(BM_COMMENT_MEDIA_PACKS).forEach(pack => {
        const key = String(pack || '').toLowerCase();
        const meta = BM_COMMENT_MEDIA_PACKS[pack] || {};
        const map = new Map();
        (Array.isArray(meta.items) ? meta.items : []).forEach(item => {
            if(item && item.id && item.url) map.set(String(item.id).toLowerCase(), item);
        });
        out[key] = {meta, map};
    });
    return out;
})();

function bmCommentMediaParse(value) {
    const source = String(value || '');
    const match = source.match(BM_COMMENT_MEDIA_MARKER_RE);
    if(!match) return null;
    return {
        raw: match[0],
        pack: String(match[1] || '').toLowerCase(),
        id: String(match[2] || '').toLowerCase(),
        text: source.replace(match[0], '').trim()
    };
}
function bmCommentMediaResolve(value) {
    const parsed = bmCommentMediaParse(value);
    if(!parsed) return null;
    const bucket = BM_COMMENT_MEDIA_INDEX[parsed.pack];
    const found = bucket?.map?.get(parsed.id);
    return found ? {pack:parsed.pack, item:found, meta:bucket.meta || {}, text:parsed.text, raw:parsed.raw} : null;
}
function bmCommentMediaAssetHtml(resolved) {
    if(!resolved) return '';
    const url = escapeAttr(String(resolved.item.url || ''));
    const label = escapeAttr(String(resolved.meta.label || resolved.pack || 'Sticker'));
    const isVideo = String(resolved.item.media_type || '').toLowerCase() === 'video' || /\.webm(?:$|\?)/i.test(String(resolved.item.url || ''));
    if(isVideo) return `<div class="bm-comment-media bm-comment-media-video" data-pack="${escapeAttr(resolved.pack)}"><video src="${url}" autoplay loop muted playsinline preload="metadata" disablepictureinpicture aria-label="${label}"></video></div>`;
    return `<div class="bm-comment-media bm-comment-media-image" data-pack="${escapeAttr(resolved.pack)}"><img src="${url}" loading="lazy" decoding="async" draggable="false" alt="${label}"></div>`;
}
function bmCommentMediaHtml(value) {
    const parsed = bmCommentMediaParse(value);
    if(!parsed) return null;
    const resolved = bmCommentMediaResolve(value);
    // If an old pack disappeared, hide the internal marker and preserve the text.
    if(!resolved) return parsed.text ? escapeHtml(parsed.text).replace(/\n/g, '<br>') : '';
    const asset = bmCommentMediaAssetHtml(resolved);
    if(!parsed.text) return asset;
    return `<div class="bm-comment-media-combo">${asset}<div class="bm-comment-media-caption">${escapeHtml(parsed.text).replace(/\n/g, '<br>')}</div></div>`;
}
function bmCommentTextHtml(value) {
    return bmCommentMediaHtml(value) ?? escapeHtml(String(value || '')).replace(/\n/g, '<br>');
}
function bmCommentMediaButtonMarkup(locked=false) {
    return `<button type="button" class="bm-comment-media-trigger${locked ? ' is-locked' : ''}" aria-label="استیکر و گیف" aria-expanded="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h9a5 5 0 0 1 5 5v5.2a3 3 0 0 1-.88 2.12l-4.8 4.8A3 3 0 0 1 13.2 21H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Z"></path><path d="M14 20v-4a2 2 0 0 1 2-2h4"></path><path d="M8.3 9.3h.01M14.7 9.3h.01"></path><path d="M8.7 12.7c.9 1.2 2 1.8 3.3 1.8 1.1 0 2.1-.45 3-1.35"></path></svg><span>استیکر و گیف</span></button>`;
}
function bmBuildCommentMediaPicker(onSelect) {
    const picker = document.createElement('div');
    picker.className = 'bm-comment-media-picker';
    picker.hidden = true;
    const packNames = Object.keys(BM_COMMENT_MEDIA_PACKS).filter(pack => Array.isArray(BM_COMMENT_MEDIA_PACKS[pack]?.items));
    if(!packNames.length) {
        picker.innerHTML = '<div class="bm-comment-media-empty">هنوز پک فعالی از پنل مدیریت تعریف نشده است.</div>';
        return picker;
    }
    const tabs = document.createElement('div');
    tabs.className = 'bm-comment-media-tabs';
    const panes = document.createElement('div');
    panes.className = 'bm-comment-media-panes';
    const paneByPack = Object.create(null);
    const tabByPack = Object.create(null);
    let active = String(packNames[0]);
    function select(pack) {
        active = String(pack);
        Object.keys(tabByPack).forEach(name => {
            const on = name === active;
            tabByPack[name].classList.toggle('active', on);
            tabByPack[name].setAttribute('aria-pressed', on ? 'true' : 'false');
        });
        Object.keys(paneByPack).forEach(name => {
            const pane = paneByPack[name];
            const on = name === active;
            pane.hidden = !on;
            pane.style.display = on ? 'grid' : 'none';
            pane.querySelectorAll('video').forEach(video => {
                try { if(on){ const pr=video.play(); if(pr?.catch) pr.catch(()=>{}); } else video.pause(); } catch(_){}
            });
        });
    }
    packNames.forEach(packName => {
        const pack = String(packName);
        const meta = BM_COMMENT_MEDIA_PACKS[pack] || {};
        const tab = document.createElement('button');
        tab.type='button'; tab.className='bm-comment-media-tab'; tab.dataset.mediaPack=pack; tab.setAttribute('aria-pressed','false');
        tab.textContent = String(meta.label || pack);
        tab.addEventListener('click', () => select(pack));
        tabs.appendChild(tab); tabByPack[pack]=tab;
        const pane = document.createElement('div');
        pane.className='bm-comment-media-grid'; pane.dataset.mediaPane=pack; pane.hidden=true; pane.style.display='none';
        const items = Array.isArray(meta.items) ? meta.items : [];
        if(!items.length) pane.innerHTML='<div class="bm-comment-media-empty">این پک فعلاً خالی است.</div>';
        items.forEach(item => {
            const button=document.createElement('button'); button.type='button'; button.className='bm-comment-media-item';
            const isVideo=String(item.media_type||'').toLowerCase()==='video' || /\.webm(?:$|\?)/i.test(String(item.url||''));
            let media;
            if(isVideo){ media=document.createElement('video'); media.src=String(item.url||''); media.loop=true; media.muted=true; media.playsInline=true; media.preload='metadata'; media.setAttribute('disablepictureinpicture',''); }
            else { media=document.createElement('img'); media.src=String(item.url||''); media.loading='lazy'; media.decoding='async'; media.draggable=false; }
            media.setAttribute('aria-hidden','true'); button.appendChild(media);
            button.addEventListener('click', () => onSelect(pack,item,picker)); pane.appendChild(button);
        });
        panes.appendChild(pane); paneByPack[pack]=pane;
    });
    picker.append(tabs, panes);
    select(active);
    return picker;
}
function bmCommentMediaMarker(pack,item){ return item?.id ? `[bm-sticker:${String(pack).toLowerCase()}:${String(item.id).toLowerCase()}]` : ''; }
function bmCommentMediaGetMarker(host){ return host?.dataset?.bmMediaMarker || ''; }
function bmCommentMediaClearSelection(host){
    if(!host) return;
    delete host.dataset.bmMediaMarker;
    host.querySelector('.bm-comment-media-selection')?.remove();
}
function bmCommentMediaSetSelection(host, pack, item){
    if(!host || !item?.id) return;
    const marker=bmCommentMediaMarker(pack,item); if(!marker) return;
    host.dataset.bmMediaMarker=marker;
    host.querySelector('.bm-comment-media-selection')?.remove();
    const wrap=document.createElement('div'); wrap.className='bm-comment-media-selection';
    const isVideo=String(item.media_type||'').toLowerCase()==='video' || /\.webm(?:$|\?)/i.test(String(item.url||''));
    const media=isVideo?document.createElement('video'):document.createElement('img');
    media.src=String(item.url||'');
    if(isVideo){media.autoplay=true;media.loop=true;media.muted=true;media.playsInline=true;media.preload='metadata';}
    else {media.loading='lazy';media.decoding='async';media.draggable=false;}
    const text=document.createElement('span'); text.textContent='استیکر انتخاب شد؛ می‌توانید کنارش متن هم بنویسید.';
    const remove=document.createElement('button'); remove.type='button'; remove.className='bm-comment-media-remove'; remove.setAttribute('aria-label','حذف استیکر'); remove.innerHTML='×';
    remove.addEventListener('click',()=>bmCommentMediaClearSelection(host));
    wrap.append(media,text,remove); host.appendChild(wrap);
}
function bmAttachCommentMediaControl(host, onSelect) {
    if(!host || host.querySelector('.bm-comment-media-control')) return;
    const wrap=document.createElement('div'); wrap.className='bm-comment-media-control';
    const locked=false; // V14861968: comments/replies are free for all users.
    wrap.innerHTML=bmCommentMediaButtonMarkup(locked);
    const trigger=wrap.querySelector('.bm-comment-media-trigger');
    if(locked){
        trigger.addEventListener('click', () => { if(BM_COMMENT_MEDIA.vipUrl) window.location.href=BM_COMMENT_MEDIA.vipUrl; });
    } else {
        const picker=bmBuildCommentMediaPicker((pack,item,p) => { onSelect(pack,item); p.hidden=true; trigger.setAttribute('aria-expanded','false'); });
        wrap.appendChild(picker);
        trigger.addEventListener('click', ev => { ev.preventDefault(); ev.stopPropagation(); picker.hidden=!picker.hidden; trigger.setAttribute('aria-expanded', picker.hidden?'false':'true'); });
        picker.addEventListener('click', ev=>ev.stopPropagation());
        document.addEventListener('click', ev => { if(!wrap.contains(ev.target)){ picker.hidden=true; trigger.setAttribute('aria-expanded','false'); } });
    }
    host.appendChild(wrap);
}
function bmInitMainCommentMedia(){
    const textarea=document.getElementById('commentText'); if(!textarea) return;
    const form=textarea.closest('.comment-form'); if(!form) return;
    let host=form.querySelector('.bm-comment-media-host');
    if(!host){ host=document.createElement('div'); host.className='bm-comment-media-host'; textarea.insertAdjacentElement('beforebegin',host); }
    bmAttachCommentMediaControl(host,(pack,item)=>bmCommentMediaSetSelection(host,pack,item));
}
if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',bmInitMainCommentMedia,{once:true}); else bmInitMainCommentMedia();

function bmCommentAvatarUrl(value) {
    const raw = String(value || '').trim().replace(/\\/g, '/');
    if(!raw) return '/assets/avatars/avatar_default.webp';
    if(raw.startsWith('/assets/avatars/') || raw.startsWith('/uploads/avatars/')) return raw;
    if(raw.startsWith('assets/avatars/') || raw.startsWith('uploads/avatars/')) return '/' + raw;
    try {
        const u = new URL(raw, location.origin);
        if(u.origin === location.origin && (u.pathname.startsWith('/assets/avatars/') || u.pathname.startsWith('/uploads/avatars/'))) return u.pathname;
    } catch(e) {}
    return '/assets/avatars/avatar_default.webp';
}

function renderNewCommentHTML(comment) {
    const adminTick = (window.BM_SITE_UI?.roleBadges?.adminVerified !== false && ['admin','administrator'].includes(String(comment.role||'').toLowerCase())) ? '<svg class="admin-tick admin-verified-tick" width="16" height="16" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" aria-label="Verified admin"><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" fill="#1d9bf0"></path></svg>' : '';
    const replyText = userLang === 'fa' ? 'پاسخ' : 'Reply';
    let avatarHtml = `<img src="${escapeHtml(bmCommentAvatarUrl(comment.avatar_url || comment.avatar))}" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;">`;
    let commentText = bmCommentTextHtml(comment.comment);
    
    if(!bmCommentMediaResolve(comment.comment) && comment.spoiler) {
        commentText = `<div class="spoiler-wrapper"><div class="spoiler-content-hidden">${commentText}</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle('spoiler-visible'); this.style.display='none';">نمایش اسپویلر</button></div>`;
    } else if(!bmCommentMediaResolve(comment.comment)) {
        commentText = commentText.replace(/\[spoiler\]([\s\S]*?)\[\/spoiler\]/gis, function(match, inner) {
            return `<div class="spoiler-wrapper"><div class="spoiler-content-hidden">${inner}</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle('spoiler-visible'); this.style.display='none';">نمایش اسپویلر</button></div>`;
        });
    }
    
    const stars = renderStarsJs(comment.rating);
    let deleteBtn = '';
    if(userId && (String(userId) === String(comment.user_id) || currentUserRole === 'admin')) {
        deleteBtn = `<button class="delete-comment-btn" data-id="${comment.id}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>`;
    }
    return `
        <div class="comment-item" data-id="${comment.id}" data-reply-count="0">
            <div class="comment-header">
                <div class="comment-user">
                    <div class="comment-avatar-small" style="overflow:hidden;">${avatarHtml}</div>
                    <div>
                        <div class="comment-name">${escapeHtml(comment.username)} ${adminTick}</div>
                        <div class="comment-date">لحظاتی پیش</div>
                    </div>
                </div>
                <div class="comment-rating-stars">${stars}</div>
            </div>
            <div class="comment-text">${commentText}</div>
            <div class="comment-actions">
                <div class="bm-comment-evaluation" role="group" aria-label="Comment rating">
                    <button type="button" class="comment-like" data-id="${comment.id}" data-type="like" aria-label="Like">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg>
                        <span class="like-count">0</span>
                    </button>
                    <span class="bm-comment-vote-divider" aria-hidden="true"></span>
                    <button type="button" class="comment-dislike" data-id="${comment.id}" data-type="dislike" aria-label="Dislike">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg>
                        <span class="dislike-count">0</span>
                    </button>
                </div>
                <button class="reply-btn" data-id="${comment.id}">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                    <span>${replyText}</span>
                </button>
                ${deleteBtn}
            </div>
            <div class="reply-form-container" id="reply-form-${comment.id}" style="display:none; margin-top:12px;"></div>
            <div class="replies-container" id="replies-${comment.id}" style="display:none; margin-top:12px; padding-left:20px; border-left:2px solid var(--border-accent);"></div>
        </div>
    `;
}

function showReplyForm(commentId) {
    const container = document.getElementById(`reply-form-${commentId}`);
    if(!container) return;
    const isLoggedIn = userId !== '';
    const html = `
        <div class="comment-form" style="background:var(--bg-tertiary); padding:12px; border-radius:16px; margin-top:8px;">
            ${!isLoggedIn ? `<input type="text" id="reply-name-${commentId}" class="comment-textarea" style="margin-bottom:8px;" placeholder="${userLang === 'fa' ? 'نام شما' : 'Your name'}">` : ''}
            <textarea id="reply-text-${commentId}" class="comment-textarea" rows="2" placeholder="${userLang === 'fa' ? 'پاسخ خود را بنویسید...' : 'Write your reply...'}"></textarea>
            <div class="form-actions" style="display:flex; gap:8px; justify-content:flex-end; margin-top:8px;">
                <button class="btn-outline cancel-reply" data-id="${commentId}" style="padding:6px 12px;">${userLang === 'fa' ? 'انصراف' : 'Cancel'}</button>
                <button class="btn-primary submit-reply" data-id="${commentId}" style="padding:6px 12px;">${userLang === 'fa' ? 'ارسال پاسخ' : 'Submit'}</button>
            </div>
        </div>
    `;
    container.innerHTML = html;
    container.style.display = 'block';
    const mediaHost=document.createElement('div'); mediaHost.className='bm-comment-media-host is-reply';
    const actions=container.querySelector('.form-actions'); if(actions) actions.insertAdjacentElement('beforebegin',mediaHost);
    bmAttachCommentMediaControl(mediaHost,(pack,item)=>bmCommentMediaSetSelection(mediaHost,pack,item));
    container.querySelector('.submit-reply').addEventListener('click', () => submitReply(commentId));
    container.querySelector('.cancel-reply').addEventListener('click', () => {
        container.style.display = 'none';
        container.innerHTML = '';
    });
}

async function submitReply(parentId) {
    const textarea = document.getElementById(`reply-text-${parentId}`);
    const replyText = textarea.value.trim();
    const replyForm = document.getElementById(`reply-form-${parentId}`);
    const mediaHost = replyForm?.querySelector('.bm-comment-media-host');
    const mediaMarker = bmCommentMediaGetMarker(mediaHost);
    if(!replyText && !mediaMarker) { showToast(userLang === 'fa' ? 'لطفاً متن پاسخ یا یک استیکر انتخاب کنید' : 'Write a reply or choose a sticker'); return; }
    if(replyText && replyText.length < 3) { showToast(userLang === 'fa' ? 'متن پاسخ باید حداقل ۳ کاراکتر باشد' : 'Reply text must be at least 3 characters'); return; }
    const replyPayload = mediaMarker ? `${mediaMarker}${replyText ? `\n${replyText}` : ''}` : replyText;
    const fd = new FormData();
    fd.append('csrf_token', csrfToken);
    fd.append('action', 'add_reply');
    fd.append('parent_id', parentId);
    fd.append('movie_id', movieId);
    fd.append('archive', isArchive1 ? '1' : '0');
    fd.append('comment', replyPayload);
    if(userId === '') {
        const nameInput = document.getElementById(`reply-name-${parentId}`);
        const guestName = nameInput ? nameInput.value.trim() : '';
        if(!guestName) { showToast(userLang === 'fa' ? 'لطفاً نام خود را وارد کنید' : 'Please enter your name'); return; }
        fd.append('username', guestName);
    }
    try {
        const res = await fetch('/ajax_comments.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            showToast(data.message);
            const form = document.getElementById(`reply-form-${parentId}`);
            if(form) { form.style.display = 'none'; form.innerHTML = ''; }
            if(data.approved) {
                await loadReplies(parentId);
                const commentDiv = document.querySelector(`.comment-item[data-id="${parentId}"]`);
                if(commentDiv) {
                    let count = parseInt(commentDiv.dataset.replyCount || '0', 10) || 0;
                    count++;
                    commentDiv.dataset.replyCount = count;
                    const replyCountEl = commentDiv.querySelector('.reply-count');
                    if(replyCountEl) replyCountEl.textContent = `(${count})`;
                    else commentDiv.querySelector('.reply-btn')?.insertAdjacentHTML('beforeend', ` <span class="reply-count">(${count})</span>`);
                }
            }
        } else showToast(data.error);
    } catch(e) { console.error(e); showToast(userLang === 'fa' ? 'خطا در ارسال پاسخ' : 'Error sending reply'); }
}

async function loadReplies(commentId) {
    const container = document.getElementById(`replies-${commentId}`);
    if(!container) return;
    try {
        const res = await fetch(`/ajax_comments.php?action=get_replies&comment_id=${commentId}&archive=${isArchive1 ? '1' : '0'}`);
        const data = await res.json();
        if(data.success && data.replies.length > 0) {
            let html = '<div class="replies-list">';
            data.replies.forEach(reply => {
                const adminTick = (window.BM_SITE_UI?.roleBadges?.adminVerified !== false && ['admin','administrator'].includes(String(reply.role||'').toLowerCase())) ? '<svg class="admin-tick admin-verified-tick" width="14" height="14" viewBox="0 0 22 22" xmlns="http://www.w3.org/2000/svg" aria-label="Verified admin"><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z" fill="#1d9bf0"></path></svg>' : '';
                let avatarHtml = `<img src="${escapeHtml(bmCommentAvatarUrl(reply.avatar_url || reply.avatar))}" loading="lazy" decoding="async" style="width:100%;height:100%;object-fit:cover;">`;
                let replyText = bmCommentTextHtml(reply.comment);
                if(!bmCommentMediaResolve(reply.comment) && reply.spoiler) {
                    replyText = `<div class="spoiler-wrapper"><div class="spoiler-content-hidden">${replyText}</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle('spoiler-visible'); this.style.display='none';">نمایش اسپویلر</button></div>`;
                } else if(!bmCommentMediaResolve(reply.comment)) {
                    replyText = replyText.replace(/\[spoiler\]([\s\S]*?)\[\/spoiler\]/gis, function(m, inner) {
                        return `<div class="spoiler-wrapper"><div class="spoiler-content-hidden">${inner}</div><button class="spoiler-reveal-btn" onclick="this.previousElementSibling.classList.toggle('spoiler-visible'); this.style.display='none';">نمایش اسپویلر</button></div>`;
                    });
                }
                const canDeleteReply = userId && (String(userId) === String(reply.user_id) || currentUserRole === 'admin');
                const deleteBtn = canDeleteReply ? `<button class="delete-comment-btn" data-id="${escapeAttr(reply.id)}"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></button>` : '';
                html += `<div class="reply-item" data-id="${escapeAttr(reply.id)}" data-parent-id="${escapeAttr(reply.parent_id || commentId)}" style="background: var(--bg-tertiary); border-radius: 16px; padding: 12px; margin-bottom: 12px;"><div class="reply-header"><div class="reply-user"><div class="reply-avatar" style="overflow:hidden;">${avatarHtml}</div><span class="reply-name">${escapeHtml(reply.username)} ${adminTick}</span></div><span class="comment-date">${formatCommentDateJs(reply.created_at)}</span></div><div class="reply-text">${replyText}</div><div class="reply-actions"><div class="bm-comment-evaluation" role="group" aria-label="Comment rating"><button type="button" class="comment-like ${reply.user_vote === 'like' ? 'active' : ''}" data-id="${escapeAttr(reply.id)}" data-type="like" aria-label="Like"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"/></svg><span class="like-count">${parseInt(reply.like_count || 0, 10)}</span></button><span class="bm-comment-vote-divider" aria-hidden="true"></span><button type="button" class="comment-dislike ${reply.user_vote === 'dislike' ? 'active' : ''}" data-id="${escapeAttr(reply.id)}" data-type="dislike" aria-label="Dislike"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"/></svg><span class="dislike-count">${parseInt(reply.dislike_count || 0, 10)}</span></button></div>${deleteBtn}</div></div>`;
            });
            html += '</div>';
            container.innerHTML = html;
            container.style.display = 'block';
            attachCommentEvents();
        } else {
            container.style.display = 'none';
            container.innerHTML = '';
        }
    } catch(e) { console.error(e); }
}

async function handleVote(e) {
    e.stopPropagation();
    if(!userId) { showToast(userLang === 'fa' ? 'لطفاً وارد شوید' : 'Please login'); return; }
    const btn = e.currentTarget;
    const commentId = btn.dataset.id;
    const type = btn.classList.contains('comment-like') ? 'like' : 'dislike';
    const fd = new FormData();
    fd.append('csrf_token', csrfToken);
    fd.append('action', 'vote');
    fd.append('comment_id', commentId);
    fd.append('type', type);
    fd.append('archive', isArchive1 ? '1' : '0');
    try {
        const res = await fetch('/ajax_comments.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            const item = btn.closest('.comment-item') || btn.closest('.reply-item');
            item.querySelector('.like-count').textContent = data.likes;
            item.querySelector('.dislike-count').textContent = data.dislikes;
            const likeBtn = item.querySelector('.comment-like');
            const dislikeBtn = item.querySelector('.comment-dislike');
            likeBtn.classList.toggle('active', data.user_vote === 'like');
            dislikeBtn.classList.toggle('active', data.user_vote === 'dislike');
            const evaluation = btn.closest('.bm-comment-evaluation');
            if(evaluation){ evaluation.classList.remove('bm-vote-pulse'); void evaluation.offsetWidth; evaluation.classList.add('bm-vote-pulse'); }
        }
    } catch(e) { console.error(e); }
}

function attachCommentEvents() {
    document.querySelectorAll('.comment-like, .comment-dislike').forEach(btn => {
        btn.removeEventListener('click', handleVote);
        btn.addEventListener('click', handleVote);
    });
}

function attachReplyButtons() {
    document.querySelectorAll('.reply-btn').forEach(btn => {
        btn.removeEventListener('click', replyClickHandler);
        btn.addEventListener('click', replyClickHandler);
    });
}

function replyClickHandler(e) {
    const id = this.dataset.id;
    const fc = document.getElementById(`reply-form-${id}`);
    if(fc && fc.style.display === 'block') {
        fc.style.display = 'none';
        fc.innerHTML = '';
    } else {
        document.querySelectorAll('[id^="reply-form-"]').forEach(f => { f.style.display = 'none'; f.innerHTML = ''; });
        showReplyForm(id);
    }
    const rc = document.getElementById(`replies-${id}`);
    const cnt = parseInt(this.closest('.comment-item').dataset.replyCount) || 0;
    if(rc && rc.style.display !== 'block' && cnt > 0) loadReplies(id);
}

async function deleteComment(commentId, element) {
    if(!confirm(userLang === 'fa' ? 'آیا از حذف این کامنت اطمینان دارید؟' : 'Are you sure you want to delete this comment?')) return;
    const fd = new FormData();
    fd.append('csrf_token', csrfToken);
    fd.append('action', 'delete_comment');
    fd.append('comment_id', commentId);
    fd.append('archive', isArchive1 ? '1' : '0');
    try {
        const res = await fetch('/ajax_comments.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            const replyDiv = element.closest('.reply-item');
            const commentDiv = element.closest('.comment-item');
            if(replyDiv) {
                const parentId = replyDiv.dataset.parentId || commentDiv?.dataset.id;
                replyDiv.remove();
                const parent = parentId ? document.querySelector(`.comment-item[data-id="${parentId}"]`) : null;
                if(parent) {
                    let count = Math.max(0, (parseInt(parent.dataset.replyCount || '0', 10) || 0) - 1);
                    parent.dataset.replyCount = count;
                    const replyCountEl = parent.querySelector('.reply-count');
                    if(replyCountEl) replyCountEl.textContent = count > 0 ? `(${count})` : '';
                }
            } else if(commentDiv) {
                commentDiv.remove();
                const totalSpan = document.getElementById('totalCommentsCount');
                if(totalSpan && data.deleted_top_level) totalSpan.textContent = Math.max(0, parseInt(totalSpan.textContent || '0', 10) - 1);
            }
            showToast(data.message);
        } else showToast(data.error);
    } catch(e) { console.error(e); showToast('خطا در حذف کامنت'); }
}

function attachDeleteButtons() {
    document.querySelectorAll('.delete-comment-btn').forEach(btn => {
        btn.removeEventListener('click', deleteHandler);
        btn.addEventListener('click', deleteHandler);
    });
}
function deleteHandler(e) {
    e.stopPropagation();
    const commentId = this.dataset.id;
    deleteComment(commentId, this);
}

// =================== ارسال کامنت اصلی ===================
document.getElementById('submitCommentBtn')?.addEventListener('click', async function() {
    const button = this;
    const textarea = document.getElementById('commentText');
    const text = textarea.value.trim();
    const mainForm = textarea.closest('.comment-form');
    const mediaHost = mainForm?.querySelector('.bm-comment-media-host');
    const mediaMarker = bmCommentMediaGetMarker(mediaHost);
    const rating = ratingValue;
    const fullSpoiler = document.getElementById('fullSpoilerCheckbox')?.checked ? 1 : 0;
    if(!text && !mediaMarker) { showError(userLang === 'fa' ? 'لطفاً متن نظر را وارد کنید یا یک استیکر انتخاب کنید' : 'Write a comment or choose a sticker'); return; }
    if(text && text.length < 3) { showError(userLang === 'fa' ? 'متن نظر باید حداقل ۳ کاراکتر باشد' : 'Comment text must be at least 3 characters'); return; }
    const commentPayload = mediaMarker ? `${mediaMarker}${text ? `\n${text}` : ''}` : text;

    let sentSuccessfully = false;
    bmSetMainCommentButtonState(button, 'sending');
    const fd = new FormData();
    fd.append('csrf_token', csrfToken);
    fd.append('action', 'add_comment');
    fd.append('movie_id', movieId);
    fd.append('archive', isArchive1 ? '1' : '0');
    fd.append('comment', commentPayload);
    fd.append('rating', rating);
    fd.append('spoiler', fullSpoiler);
    try {
        const res = await fetch('/ajax_comments.php', { method: 'POST', body: fd });
        const data = await res.json();
        if(data.success) {
            sentSuccessfully = true;
            bmSetMainCommentButtonState(button, 'sent');
            document.getElementById('commentText').value = '';
            bmCommentMediaClearSelection(mediaHost);
            ratingValue = 0;
            updateStarsFill();
            showMessage(data.message);
            if(data.approved && data.comment) {
                if(document.getElementById('emptyComments')) document.getElementById('emptyComments').style.display = 'none';
                const newHtml = renderNewCommentHTML(data.comment);
                document.getElementById('commentList').insertAdjacentHTML('afterbegin', newHtml);
                const totalSpan = document.getElementById('totalCommentsCount');
                if(totalSpan) totalSpan.textContent = Math.max(0, parseInt(totalSpan.textContent || '0', 10) + 1);
                attachCommentEvents();
                attachReplyButtons();
                attachDeleteButtons();
            }
        } else {
            showError(data.error);
        }
    } catch(e) {
        showError(userLang === 'fa' ? 'خطا در ارتباط با سرور' : 'Server error');
    } finally {
        if(sentSuccessfully) window.setTimeout(() => bmSetMainCommentButtonState(button, 'idle'), 1700);
        else bmSetMainCommentButtonState(button, 'idle');
    }
});

// دکمه درج تگ اسپویلر
document.getElementById('spoilerTagBtn')?.addEventListener('click', function() {
    const textarea = document.getElementById('commentText');
    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = textarea.value.substring(start, end);
    const spoilerText = `[spoiler]${selectedText}[/spoiler]`;
    const newText = textarea.value.substring(0, start) + spoilerText + textarea.value.substring(end);
    textarea.value = newText;
    textarea.focus();
});

const loadMoreBtn = document.getElementById('loadMoreCommentsBtn');
if(loadMoreBtn) {
    loadMoreBtn.addEventListener('click', async function() {
        if(loadingComments) return;
        loadingComments = true;
        const btn = this.querySelector('button');
        btn.disabled = true;
        btn.innerHTML = '<div class="loading-spinner" style="width:20px;height:20px;border-width:2px;"></div>';
        const fd = new FormData();
    fd.append('csrf_token', csrfToken);
        fd.append('action', 'load_more_comments');
        fd.append('page', commentPage);
        fd.append('movie_id', movieId);
        fd.append('archive', isArchive1 ? '1' : '0');
        try {
            const res = await fetch('/ajax_comments.php', { method: 'POST', body: fd });
            const data = await res.json();
            if(data.success && data.html) {
                document.getElementById('commentList').insertAdjacentHTML('beforeend', data.html);
                commentPage++;
                attachCommentEvents();
                attachReplyButtons();
                attachDeleteButtons();
                if(!data.has_more) loadMoreBtn.style.display = 'none';
            } else loadMoreBtn.style.display = 'none';
        } catch(e) { console.error(e); }
        finally {
            loadingComments = false;
            btn.disabled = false;
            btn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>${userLang === 'fa' ? 'بارگذاری بیشتر' : 'Load More'}<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="6 9 12 15 18 9"/></svg>`;
        }
    });
}

// =================== ستاره‌ها ===================
const starsEl = document.querySelectorAll('.star-input');
let ratingValue = BM_MOVIE_CONFIG.userRating || 0;
starsEl.forEach(star => {
    star.addEventListener('click', function() { ratingValue = parseInt(this.dataset.value); updateStarsFill(); });
    star.addEventListener('mouseenter', function() { let v = parseInt(this.dataset.value); document.querySelectorAll('.star-input').forEach((s,i) => s.setAttribute('fill', i < v ? 'currentColor' : 'none')); });
    star.addEventListener('mouseleave', updateStarsFill);
});
function updateStarsFill() { document.querySelectorAll('.star-input').forEach((s,i) => s.setAttribute('fill', i < ratingValue ? 'currentColor' : 'none')); }
function showMessage(msg) { const el = document.getElementById('commentMessage'); if(!el) return; el.style.display = 'block'; el.textContent = String(msg || ''); setTimeout(() => el.style.display = 'none', 3000); }
function showError(msg) { const el = document.getElementById('commentError'); if(!el) return; el.style.display = 'block'; el.textContent = String(msg || ''); setTimeout(() => el.style.display = 'none', 3000); }
