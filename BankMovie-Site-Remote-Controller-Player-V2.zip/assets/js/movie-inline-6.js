
// Fail-safe: اگر یک خطای جاوااسکریپت جانبی رخ داد، صفحه در لودینگ گیر نکند.
window.addEventListener('load', function(){
    setTimeout(function(){
        var overlay = document.getElementById('loadingOverlay');
        if(overlay){ overlay.classList.add('hide'); overlay.style.display = 'none'; }
    }, 900);
});
