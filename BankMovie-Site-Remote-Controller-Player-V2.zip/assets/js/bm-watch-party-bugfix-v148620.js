(function(){
  'use strict';

  function ready(fn){
    if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true});
    else fn();
  }

  function setupFloatingDock(){
    var nav=document.querySelector('.bottom-nav[data-mobile-bottom-nav],.bottom-nav');
    if(!nav) return;
    var lastY=window.scrollY||0;
    var ticking=false;
    function overlayOpen(){
      return document.body.classList.contains('wp-room-tools-open') ||
        document.body.classList.contains('wp-player-settings-open') ||
        document.body.classList.contains('wp-chat-modal-open');
    }
    function update(){
      var y=window.scrollY||0;
      var diff=y-lastY;
      if(window.innerWidth>=992 || y<110 || overlayOpen() || ['INPUT','TEXTAREA','SELECT'].indexOf((document.activeElement&&document.activeElement.tagName)||'')>=0){
        nav.classList.remove('nav-hidden');
        nav.classList.toggle('nav-compact',y>220);
      }else if(Math.abs(diff)>12){
        nav.classList.toggle('nav-hidden',diff>0);
        nav.classList.toggle('nav-compact',y>220&&diff<=0);
        lastY=y;
      }
      ticking=false;
    }
    window.addEventListener('scroll',function(){if(!ticking){ticking=true;requestAnimationFrame(update);}},{passive:true});
    window.addEventListener('resize',update,{passive:true});
    document.addEventListener('focusin',update);
    document.addEventListener('focusout',function(){setTimeout(update,80);});
    new MutationObserver(update).observe(document.body,{attributes:true,attributeFilter:['class']});
    update();
  }

  function setupSettingsPortal(){
    var modal=document.getElementById('playerSettings');
    var backdrop=document.getElementById('playerSettingsBackdrop');
    var wrapper=document.getElementById('partyPlayerWrapper') || document.querySelector('.player-wrapper');
    if(!modal||!backdrop||!wrapper) return;

    var modalAnchor=document.createComment('bm-player-settings-home');
    var backdropAnchor=document.createComment('bm-player-settings-backdrop-home');
    modal.parentNode.insertBefore(modalAnchor,modal);
    backdrop.parentNode.insertBefore(backdropAnchor,backdrop);

    function fullscreenElement(){return document.fullscreenElement||document.webkitFullscreenElement||null;}
    function restore(){
      modal.classList.remove('bm-body-settings');
      backdrop.classList.remove('bm-body-settings');
      if(backdropAnchor.parentNode) backdropAnchor.parentNode.insertBefore(backdrop,backdropAnchor.nextSibling);
      if(modalAnchor.parentNode) modalAnchor.parentNode.insertBefore(modal,modalAnchor.nextSibling);
    }
    function sync(){
      var open=modal.classList.contains('open');
      if(!open){restore();return;}
      var fs=fullscreenElement();
      if(fs){
        modal.classList.remove('bm-body-settings');
        backdrop.classList.remove('bm-body-settings');
        if(backdrop.parentNode!==fs) fs.appendChild(backdrop);
        if(modal.parentNode!==fs) fs.appendChild(modal);
      }else{
        backdrop.classList.add('bm-body-settings');
        modal.classList.add('bm-body-settings');
        if(backdrop.parentNode!==document.body) document.body.appendChild(backdrop);
        if(modal.parentNode!==document.body) document.body.appendChild(modal);
      }
    }
    new MutationObserver(sync).observe(modal,{attributes:true,attributeFilter:['class']});
    document.addEventListener('fullscreenchange',sync);
    document.addEventListener('webkitfullscreenchange',sync);
    sync();
  }

  ready(function(){setupFloatingDock();setupSettingsPortal();});
})();
