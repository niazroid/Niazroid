
// ===== V47: فصل‌ها بسته شروع می‌شوند؛ کاربر باز/بسته می‌کند =====
window.arc1SwitchSeason = function(btn, targetId) {
    var panel = document.getElementById(targetId);
    if (!panel) return;
    var wasOpen = btn.classList.contains('active') && panel.style.display !== 'none';

    document.querySelectorAll('.arc1-season-tab').forEach(function(t) {
        t.classList.remove('active');
        t.setAttribute('aria-expanded','false');
    });
    document.querySelectorAll('[data-sp]').forEach(function(p) {
        p.style.display = 'none';
        p.classList.remove('arc1-season-panel');
    });

    if (wasOpen) return;

    btn.classList.add('active');
    btn.setAttribute('aria-expanded','true');
    panel.style.display = 'block';
    if(!document.documentElement.classList.contains('bm-nav-static')){
        // Keep the original entrance animation only on capable devices.
        panel.classList.remove('arc1-season-panel');
        void panel.offsetWidth;
        panel.classList.add('arc1-season-panel');
    }
};
