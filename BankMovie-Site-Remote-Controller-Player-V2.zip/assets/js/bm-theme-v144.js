(function () {
  'use strict';

  var STORAGE_KEY = 'bm_color_mode';
  var COOKIE_KEY = 'bm_color_mode';
  var LIGHT = 'light';
  var DARK = 'dark';

  function normalize(value) {
    return value === LIGHT ? LIGHT : DARK;
  }

  function currentMode() {
    return normalize(document.documentElement.getAttribute('data-bm-color-mode') || window.BM_INITIAL_COLOR_MODE);
  }

  function writePreference(mode) {
    try { localStorage.setItem(STORAGE_KEY, mode); } catch (e) {}
    try {
      var cookie = COOKIE_KEY + '=' + mode + '; path=/; max-age=31536000; SameSite=Lax';
      if (location.protocol === 'https:') cookie += '; Secure';
      document.cookie = cookie;
    } catch (e) {}
  }

  function updateThemeColor(mode) {
    var color = mode === LIGHT ? '#f4f7fb' : '#05070b';
    document.querySelectorAll('meta[name="theme-color"]').forEach(function (meta) {
      meta.setAttribute('content', color);
    });
  }

  function syncControls(mode) {
    document.querySelectorAll('[data-bm-theme-toggle]').forEach(function (control) {
      var input = control.querySelector('input[type="checkbox"]');
      var dark = mode === DARK;
      control.setAttribute('data-mode', mode);
      control.setAttribute('title', dark ? 'فعال‌کردن تم روشن' : 'فعال‌کردن تم تیره');
      control.setAttribute('aria-label', dark ? 'فعال‌کردن تم روشن' : 'فعال‌کردن تم تیره');
      if (input) {
        input.checked = dark;
        input.setAttribute('aria-checked', dark ? 'true' : 'false');
        input.setAttribute('aria-label', dark ? 'فعال‌کردن تم روشن' : 'فعال‌کردن تم تیره');
      }
    });
  }

  function apply(mode, persist) {
    mode = normalize(mode);
    var root = document.documentElement;
    root.setAttribute('data-bm-color-mode', mode);
    root.style.colorScheme = mode;
    if (document.body) {
      document.body.setAttribute('data-surface-scheme', mode);
      document.body.classList.toggle('bm-surface-light', mode === LIGHT);
      document.body.classList.toggle('bm-surface-dark', mode === DARK);
    }
    updateThemeColor(mode);
    syncControls(mode);
    if (persist) writePreference(mode);
    try {
      window.dispatchEvent(new CustomEvent('bm:themechange', { detail: { mode: mode } }));
    } catch (e) {}
  }

  function bindControls() {
    document.querySelectorAll('[data-bm-theme-toggle]').forEach(function (control) {
      if (control.dataset.bmThemeBound === '1') return;
      control.dataset.bmThemeBound = '1';
      var input = control.querySelector('input[type="checkbox"]');
      if (!input) return;
      input.addEventListener('change', function () {
        // In the BB-8 scene, checked is the starry/dark side.
        apply(input.checked ? DARK : LIGHT, true);
      });
      control.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && event.target !== input) {
          event.preventDefault();
          input.checked = !input.checked;
          input.dispatchEvent(new Event('change', { bubbles: true }));
        }
      });
    });
  }

  function init() {
    apply(currentMode(), false);
    bindControls();
    requestAnimationFrame(function () {
      document.documentElement.classList.add('bm-theme-ready');
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }
})();
