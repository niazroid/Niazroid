/* BankMovie Premium UI v140 — behavior-neutral polish */
(function(){
  'use strict';

  var ticking = false;
  function updateHeaderState(){
    document.body.classList.toggle('bm-header-scrolled', window.scrollY > 24);
    ticking = false;
  }
  window.addEventListener('scroll', function(){
    if (!ticking) {
      ticking = true;
      window.requestAnimationFrame(updateHeaderState);
    }
  }, {passive:true});
  updateHeaderState();

  function markStoryMedia(node){
    if (!node || !node.closest) return;
    var avatar = node.closest('.story-avatar');
    if (avatar) avatar.classList.add('bm-media-failed');
  }

  function inspectStoryMedia(root){
    (root || document).querySelectorAll('.story-avatar img').forEach(function(img){
      if (img.dataset.bmUiBound === '1') return;
      img.dataset.bmUiBound = '1';
      img.addEventListener('error', function(){ markStoryMedia(img); }, {once:true});
      if (img.complete && img.naturalWidth === 0) markStoryMedia(img);
    });
    (root || document).querySelectorAll('.story-avatar video').forEach(function(video){
      if (video.dataset.bmUiBound === '1') return;
      video.dataset.bmUiBound = '1';
      video.addEventListener('error', function(){
        var avatar = video.closest('.story-avatar');
        var usableImage = avatar && avatar.querySelector('img:not([hidden])');
        if (!usableImage) markStoryMedia(video);
      }, {once:true});
    });
  }

  function improveEpisodeAccessibility(root){
    (root || document).querySelectorAll('.arc1-ep-head').forEach(function(head){
      if (head.dataset.bmUiA11y === '1') return;
      head.dataset.bmUiA11y = '1';
      head.setAttribute('role','button');
      head.setAttribute('tabindex','0');
      var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
      head.addEventListener('keydown', function(event){
        if (event.key === 'Enter' || event.key === ' ') {
          event.preventDefault();
          head.click();
          window.setTimeout(function(){
            var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
          }, 0);
        }
      });
      head.addEventListener('click', function(){
        window.setTimeout(function(){
          var card = head.closest('.arc1-ep-card');
      head.setAttribute('aria-expanded', card && card.classList.contains('open') ? 'true' : 'false');
        }, 0);
      });
    });
  }

  function hydrate(root){
    inspectStoryMedia(root);
    improveEpisodeAccessibility(root);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function(){ hydrate(document); });
  } else {
    hydrate(document);
  }

  var observer = new MutationObserver(function(mutations){
    mutations.forEach(function(mutation){
      mutation.addedNodes.forEach(function(node){
        if (node.nodeType === 1) hydrate(node);
      });
    });
  });
  observer.observe(document.documentElement, {childList:true, subtree:true});
})();

/* BankMovie v141 responsive/fullscreen recovery */
(function(){
  'use strict';

  function isFullscreen(){
    return !!(document.fullscreenElement || document.webkitFullscreenElement || document.msFullscreenElement);
  }

  function hasBlockingOverlay(){
    return !!document.querySelector(
      '.sidebar-menu.open,.notif-sidebar.open,.bm-play-choice-overlay.active,' +
      '.bm-play-choice-backdrop.active,.modal.active,.modal-glass.active,' +
      '#bmAppInstallModal.open,.bm-share-sheet.is-open,.archive-guide-overlay.active'
    );
  }

  function resetHorizontalPosition(){
    try{ document.documentElement.scrollLeft = 0; }catch(e){}
    try{ document.body.scrollLeft = 0; }catch(e){}
    try{ window.scrollTo({left:0,top:window.pageYOffset,behavior:'auto'}); }catch(e){ try{ window.scrollTo(0,window.pageYOffset); }catch(_e){} }
  }

  function clearStaleFullscreenState(){
    if(isFullscreen()) return;
    document.body.classList.remove('fullscreen-active');
    /* Do not force portrait after leaving fullscreen. Unlock lets the browser
       recalculate the real visual viewport instead of keeping a stale width. */
    try{
      if(screen.orientation && typeof screen.orientation.unlock === 'function') screen.orientation.unlock();
    }catch(e){}

    var wrappers = document.querySelectorAll('.player-wrapper,#arc1PlayerInner,.bm-player-shell');
    wrappers.forEach(function(el){
      if(!el || !el.style) return;
      ['position','inset','left','right','top','bottom','width','max-width','height','max-height','min-height','transform'].forEach(function(prop){
        el.style.removeProperty(prop);
      });
    });

    if(!hasBlockingOverlay()){
      document.documentElement.classList.remove('bm-drawer-open');
      document.body.classList.remove('bm-drawer-open');
      if(document.body.style.position === 'fixed'){
        var top = parseInt(document.body.style.top || '0',10);
        var restoreY = Number.isFinite(top) ? Math.max(0,-top) : window.pageYOffset;
        ['overflow','position','top','left','right','width','height'].forEach(function(prop){ document.body.style.removeProperty(prop); });
        try{ window.scrollTo(0,restoreY); }catch(e){}
      }
      if(document.documentElement.style.overflow === 'hidden') document.documentElement.style.removeProperty('overflow');
    }

    document.documentElement.classList.remove('bm-orientation-transition');
    resetHorizontalPosition();
  }

  function syncViewport(){
    var vv = window.visualViewport;
    var width = Math.max(1,Math.round(vv ? vv.width : window.innerWidth));
    var height = Math.max(1,Math.round(vv ? vv.height : window.innerHeight));
    document.documentElement.style.setProperty('--bm-live-vw',width + 'px');
    document.documentElement.style.setProperty('--bm-live-vh',height + 'px');
    if(!isFullscreen()) clearStaleFullscreenState();
  }

  function prepareStoryVideos(root){
    (root || document).querySelectorAll('.story-thumb-video').forEach(function(video){
      if(video.readyState >= 1) video.classList.add('is-loaded');
      if(video.dataset.bmV141Bound === '1') return;
      video.dataset.bmV141Bound = '1';
      ['loadedmetadata','loadeddata','canplay'].forEach(function(name){
        video.addEventListener(name,function(){
          video.classList.add('is-loaded');
          var wrap = video.closest('.story-video-thumb-wrap');
          if(wrap) wrap.classList.add('is-loaded');
        });
      });
      video.addEventListener('error',function(){
        video.classList.remove('is-loaded');
        var wrap = video.closest('.story-video-thumb-wrap');
        if(wrap) wrap.classList.remove('is-loaded');
      });
    });
  }

  var timer = 0;
  function scheduleSync(delay){
    window.clearTimeout(timer);
    timer = window.setTimeout(function(){
      window.requestAnimationFrame(function(){
        syncViewport();
        prepareStoryVideos(document);
        window.setTimeout(syncViewport,80);
        window.setTimeout(syncViewport,260);
      });
    },delay || 0);
  }

  document.addEventListener('fullscreenchange',function(){ scheduleSync(0); });
  document.addEventListener('webkitfullscreenchange',function(){ scheduleSync(0); });
  window.addEventListener('orientationchange',function(){
    document.documentElement.classList.add('bm-orientation-transition');
    scheduleSync(120);
  },{passive:true});
  window.addEventListener('resize',function(){ scheduleSync(60); },{passive:true});
  window.addEventListener('pageshow',function(){ scheduleSync(0); });
  window.addEventListener('popstate',function(){ scheduleSync(0); });
  if(window.visualViewport){
    window.visualViewport.addEventListener('resize',function(){ scheduleSync(40); },{passive:true});
  }

  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded',function(){ scheduleSync(0); });
  }else{
    scheduleSync(0);
  }

  var v141Observer = new MutationObserver(function(mutations){
    mutations.forEach(function(mutation){
      mutation.addedNodes.forEach(function(node){
        if(node.nodeType === 1) prepareStoryVideos(node);
      });
    });
  });
  v141Observer.observe(document.documentElement,{childList:true,subtree:true});
})();
