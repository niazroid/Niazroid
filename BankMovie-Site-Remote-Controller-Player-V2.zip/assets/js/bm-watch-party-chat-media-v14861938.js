(function(){
  'use strict';

  var EMOJIS = [
    '😂','😐','😭','❤️','😘','😁','👌','😊','😡','👍','😳','😔','😜','☺️','😍','😄','💋','🫪','😝','😒','😢','😅','😏','🙈','😱','😃','😉','🥸','😚','😀','😋','😌','😞','🤣','🙊','😕','🦶','😆','😇','🙀','😾','🤝','🕯','🥹','🥱','🤩','🥳','🥰','😎','🥶','🙄','🤤','👿','😈','😹','💩','🤡','🖕','👎','🤙','🫀','❣','🩷','🧡','💛','💚','🩵','💙','💜','🖤','🩶','🤍','🤎','❤️‍🔥','❤️‍🩹','💔','💕','💞','💓','💗','💖','💘','💝','💟','♥️','🎀','🎏','🧸','🧿','👑','💍','🤮','🤢','🫠','🫩','🤬'
  ];

  var PACK_META = (window.BM_WP_STICKER_PACKS && typeof window.BM_WP_STICKER_PACKS==='object') ? window.BM_WP_STICKER_PACKS : {};
  var STICKER_PACKS = {};
  Object.keys(PACK_META).forEach(function(pack){
    var list = window.BM_WP_STICKERS && window.BM_WP_STICKERS[pack];
    STICKER_PACKS[pack] = Array.isArray(list)
      ? list.filter(function(item){ return item && item.id && item.url; })
      : [];
  });

  function ready(fn){ if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true}); else fn(); }
  function isCoarse(){ return Boolean((navigator.maxTouchPoints||0)>0 || (window.matchMedia && window.matchMedia('(pointer: coarse)').matches)); }
  function insertAtCursor(input,text){
    if(!input) return;
    var start=typeof input.selectionStart==='number'?input.selectionStart:input.value.length;
    var end=typeof input.selectionEnd==='number'?input.selectionEnd:start;
    var next=input.value.slice(0,start)+text+input.value.slice(end);
    if(next.length>500) next=next.slice(0,500);
    input.value=next;
    var pos=Math.min(next.length,start+text.length);
    try{input.setSelectionRange(pos,pos);}catch(_){ }
    input.dispatchEvent(new Event('input',{bubbles:true}));
  }

  ready(function(){
    var body=document.body;
    if(!body || !body.classList.contains('watch-party-page')) return;
    var panel=document.getElementById('playerChatPanel');
    var form=document.getElementById('chatForm');
    var input=document.getElementById('chatInput');
    if(!panel || !form || !input || document.getElementById('bmChatMediaPicker')) return;

    /* Telegram-like composer: text field + emoji + sticker buttons in one pill. */
    var composer=document.createElement('div');
    composer.className='bm-chat-composer';
    form.insertBefore(composer,input);
    composer.appendChild(input);

    var emojiButton=document.createElement('button');
    emojiButton.id='bmChatEmojiBtn';
    emojiButton.className='bm-chat-media-btn bm-chat-emoji-btn';
    emojiButton.type='button';
    emojiButton.setAttribute('aria-label','ایموجی‌ها');
    emojiButton.setAttribute('aria-expanded','false');
    emojiButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M8.4 10h.01M15.6 10h.01"></path><path d="M8.5 14c.9 1.35 2.05 2 3.5 2s2.6-.65 3.5-2"></path></svg>';
    composer.appendChild(emojiButton);

    var stickerButton=document.createElement('button');
    stickerButton.id='bmChatStickerBtn';
    stickerButton.className='bm-chat-media-btn bm-chat-sticker-btn';
    stickerButton.type='button';
    stickerButton.setAttribute('aria-label','استیکرها');
    stickerButton.setAttribute('aria-expanded','false');
    stickerButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h9a5 5 0 0 1 5 5v5.2a3 3 0 0 1-.88 2.12l-4.8 4.8A3 3 0 0 1 13.2 21H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Z"></path><path d="M14 20v-4a2 2 0 0 1 2-2h4"></path><path d="M8.3 9.3h.01M14.7 9.3h.01"></path><path d="M8.7 12.7c.9 1.2 2 1.8 3.3 1.8 1.1 0 2.1-.45 3-1.35"></path></svg>';
    composer.appendChild(stickerButton);

    var picker=document.createElement('div');
    picker.id='bmChatMediaPicker';
    picker.className='bm-chat-media-picker';
    picker.setAttribute('role','dialog');
    picker.setAttribute('aria-label','ایموجی و استیکر');

    var tabs=document.createElement('div');
    tabs.className='bm-chat-picker-tabs';
    var emojiTab=document.createElement('button');
    emojiTab.type='button';
    emojiTab.className='bm-chat-picker-tab active';
    emojiTab.dataset.pane='emoji';
    emojiTab.setAttribute('aria-pressed','true');
    emojiTab.innerHTML='<span class="bm-tab-icon">☺</span><span>ایموجی</span>';
    tabs.appendChild(emojiTab);
    Object.keys(PACK_META).forEach(function(pack){
      var tab=document.createElement('button');
      tab.type='button';
      tab.className='bm-chat-picker-tab';
      tab.dataset.pane=pack;
      tab.setAttribute('aria-pressed','false');
      tab.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h9a5 5 0 0 1 5 5v5.2a3 3 0 0 1-.88 2.12l-4.8 4.8A3 3 0 0 1 13.2 21H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Z"></path><path d="M14 20v-4a2 2 0 0 1 2-2h4"></path></svg><span>'+String(PACK_META[pack].label||pack)+'</span>';
      tabs.appendChild(tab);
    });
    var closeButton=document.createElement('button');
    closeButton.type='button';
    closeButton.id='bmChatPickerClose';
    closeButton.className='bm-chat-picker-close';
    closeButton.setAttribute('aria-label','بستن پنل');
    closeButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"></path></svg>';
    tabs.appendChild(closeButton);

    var emojiPane=document.createElement('section');
    emojiPane.className='bm-chat-picker-pane active';
    emojiPane.dataset.pane='emoji';
    var emojiHead=document.createElement('div');
    emojiHead.className='bm-chat-picker-head';
    emojiHead.innerHTML='<strong>ایموجی‌ها</strong><span>'+EMOJIS.length+' مورد</span>';
    var emojiGrid=document.createElement('div');
    emojiGrid.className='bm-chat-emoji-grid';
    EMOJIS.forEach(function(emoji){
      var item=document.createElement('button');
      item.type='button';
      item.className='bm-chat-emoji-item';
      item.setAttribute('aria-label','ایموجی '+emoji);
      item.textContent=emoji;
      item.addEventListener('click',function(ev){
        ev.preventDefault();
        insertAtCursor(input,emoji);
        if(!isCoarse()){
          try{input.focus({preventScroll:true});}catch(_){input.focus();}
        }
      });
      emojiGrid.appendChild(item);
    });
    emojiPane.append(emojiHead,emojiGrid);

    var stickerVideos=[];
    var paneVideos={}; Object.keys(PACK_META).forEach(function(pack){paneVideos[pack]=[];});
    var stickerObserver=null;
    function activateStickerVideo(video){
      if(!video.src && video.dataset.src) video.src=video.dataset.src;
      var play=video.play && video.play();
      if(play && typeof play.catch==='function') play.catch(function(){});
    }
    function pauseStickerVideo(video){ try{video.pause();}catch(_){ } }
    if('IntersectionObserver' in window){
      stickerObserver=new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting && picker.classList.contains('open') && entry.target.closest('.bm-chat-picker-pane.active')) activateStickerVideo(entry.target);
          else pauseStickerVideo(entry.target);
        });
      },{root:picker,rootMargin:'80px 0px',threshold:0.01});
    }

    var activePaneName='emoji';
    var lastStickerPane=Object.keys(PACK_META)[0]||'emoji';
    var panes={emoji:emojiPane};

    function setOpen(open,paneName){
      if(paneName) selectPane(paneName);
      picker.classList.toggle('open',!!open);
      emojiButton.setAttribute('aria-expanded',open && activePaneName==='emoji'?'true':'false');
      stickerButton.setAttribute('aria-expanded',open && activePaneName!=='emoji'?'true':'false');
      stickerVideos.forEach(pauseStickerVideo);
      if(open && activePaneName!=='emoji'){
        requestAnimationFrame(function(){ (paneVideos[activePaneName]||[]).slice(0,12).forEach(activateStickerVideo); });
      }
    }

    function sendSticker(pack,sticker){
      if(!sticker || !sticker.id || !PACK_META[pack]) return;
      var marker='[bm-sticker:'+pack+':'+String(sticker.id)+']';
      var draft=input.value;
      input.value=marker;
      input.dispatchEvent(new Event('input',{bubbles:true}));
      try{
        if(typeof form.requestSubmit==='function') form.requestSubmit();
        else form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
      }catch(_){
        form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
      }
      /* Telegram behavior: close the tray immediately after a sticker is sent. */
      setOpen(false);
      setTimeout(function(){
        if(draft && input.value===''){
          input.value=draft;
          input.dispatchEvent(new Event('input',{bubbles:true}));
        }
      },0);
    }

    function buildStickerPane(pack){
      var meta=PACK_META[pack];
      var list=STICKER_PACKS[pack]||[];
      var pane=document.createElement('section');
      pane.className='bm-chat-picker-pane';
      pane.dataset.pane=pack;
      pane.hidden=true;
      var head=document.createElement('div');
      head.className='bm-chat-picker-head bm-chat-sticker-head';
      head.innerHTML='<strong>'+meta.label+'</strong><span>'+list.length+' استیکر</span>';
      var grid=document.createElement('div');
      grid.className='bm-chat-sticker-grid';
      if(list.length){
        list.forEach(function(sticker){
          var item=document.createElement('button');
          item.type='button';
          item.className='bm-chat-sticker-item';
          item.setAttribute('aria-label','ارسال استیکر '+meta.label);
          var isImage=String(sticker.media_type||'').toLowerCase()==='image' || /\.(?:webp|png|jpe?g|gif)(?:$|\?)/i.test(String(sticker.url||''));
          var media;
          if(isImage){
            media=document.createElement('img');
            media.className='bm-chat-sticker-thumb bm-chat-sticker-thumb-image';
            media.src=String(sticker.url||'');
            media.alt='';
            media.loading='lazy';
            media.decoding='async';
            media.draggable=false;
            media.setAttribute('aria-hidden','true');
          }else{
            media=document.createElement('video');
            media.className='bm-chat-sticker-thumb';
            media.dataset.src=String(sticker.url||'');
            media.muted=true;media.loop=true;media.playsInline=true;media.preload='none';
            media.setAttribute('aria-hidden','true');
            media.setAttribute('disablepictureinpicture','');
            stickerVideos.push(media);
            (paneVideos[pack]||(paneVideos[pack]=[])).push(media);
            if(stickerObserver) stickerObserver.observe(media);
          }
          item.appendChild(media);
          item.addEventListener('click',function(ev){ev.preventDefault();sendSticker(pack,sticker);});
          grid.appendChild(item);
        });
      }else{
        var empty=document.createElement('div');
        empty.className='bm-chat-sticker-empty';
        empty.innerHTML='<strong>پک '+meta.label+' پیدا نشد</strong><span>فایل‌های '+((Array.isArray(meta.extensions)?meta.extensions.join(' / ').toUpperCase():'استیکر'))+' را داخل <b>'+meta.path+'</b> قرار بده.</span>';
        grid.appendChild(empty);
      }
      pane.append(head,grid);
      return pane;
    }

    Object.keys(PACK_META).forEach(function(pack){ panes[pack]=buildStickerPane(pack); });
    picker.append(tabs,emojiPane);
    Object.keys(PACK_META).forEach(function(pack){ picker.appendChild(panes[pack]); });
    panel.appendChild(picker);

    var tabButtons=Array.prototype.slice.call(tabs.querySelectorAll('.bm-chat-picker-tab'));
    function selectPane(name){
      if(!panes[name]) name='emoji';
      activePaneName=name;
      if(name!=='emoji') lastStickerPane=name;
      Object.keys(panes).forEach(function(paneName){
        var active=paneName===name;
        panes[paneName].hidden=!active;
        panes[paneName].classList.toggle('active',active);
      });
      tabButtons.forEach(function(tab){
        var active=tab.dataset.pane===name;
        tab.classList.toggle('active',active);tab.setAttribute('aria-pressed',active?'true':'false');
      });
      stickerVideos.forEach(pauseStickerVideo);
      if(name!=='emoji' && picker.classList.contains('open')){
        requestAnimationFrame(function(){ (paneVideos[name]||[]).slice(0,12).forEach(activateStickerVideo); });
      }
    }
    tabButtons.forEach(function(tab){tab.addEventListener('click',function(){selectPane(tab.dataset.pane||'emoji');});});

    emojiButton.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      var same=picker.classList.contains('open') && activePaneName==='emoji';
      setOpen(!same,'emoji');
    });
    stickerButton.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      var same=picker.classList.contains('open') && activePaneName!=='emoji';
      setOpen(!same,lastStickerPane);
    });
    document.getElementById('bmChatPickerClose').addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();setOpen(false);
    });
    picker.addEventListener('click',function(ev){ev.stopPropagation();});
    document.addEventListener('pointerdown',function(ev){
      if(!picker.classList.contains('open')) return;
      if(!picker.contains(ev.target) && !composer.contains(ev.target)) setOpen(false);
    },{passive:true});
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')setOpen(false);});
    form.addEventListener('submit',function(){ setOpen(false); });

    function refreshPack(){
      if(!picker.classList.contains('open')) return;
      requestAnimationFrame(function(){
        picker.scrollTop=Math.min(picker.scrollTop,picker.scrollHeight);
        if(activePaneName!=='emoji') (paneVideos[activePaneName]||[]).slice(0,12).forEach(activateStickerVideo);
      });
    }
    window.addEventListener('resize',refreshPack,{passive:true});
    if(window.visualViewport) window.visualViewport.addEventListener('resize',refreshPack,{passive:true});
    document.addEventListener('fullscreenchange',refreshPack);
    document.addEventListener('webkitfullscreenchange',refreshPack);

    var activePanel=document.getElementById('playerChatPanel');
    function syncBackgroundKey(){
      var key=document.documentElement.getAttribute('data-bm-background')||'simple';
      if(activePanel) activePanel.setAttribute('data-room-background',key);
    }
    syncBackgroundKey();
    new MutationObserver(syncBackgroundKey).observe(document.documentElement,{attributes:true,attributeFilter:['data-bm-background']});
    window.addEventListener('bm:watch-party-background',syncBackgroundKey);
  });
})();
