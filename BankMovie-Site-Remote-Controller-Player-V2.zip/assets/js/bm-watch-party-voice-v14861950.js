(() => {
  'use strict';

  const cfg = window.BM_WP_VOICE_TEST || {};
  if (!cfg.enabled || !cfg.userId) return;

  const $ = (id) => document.getElementById(id);
  // Room invite codes are base64url tokens and therefore CASE-SENSITIVE.
  // Never uppercase/lowercase them: changing even one letter changes the hash and
  // makes the Voice API report a false `room_not_found` while the Watch Party is alive.
  const roomCode = () => {
    const live = String(window.BM_WP_ACTIVE_ROOM_CODE || '').trim();
    if (/^[A-Za-z0-9_-]{24,96}$/.test(live)) return live;
    const view = String(document.getElementById('roomCodeView')?.textContent || '').trim();
    if (/^[A-Za-z0-9_-]{24,96}$/.test(view)) return view;
    return String(new URLSearchParams(location.search).get('room') || '').trim();
  };
  const state = {
    mounted: false,
    peerAvailable: false,
    peer: null,
    call: null,
    callToken: '',
    pc: null,
    localStream: null,
    remoteStream: null,
    pendingOffer: null,
    pendingIce: [],
    signalQueue: [],
    signalBusy: false,
    seenSignals: new Set(),
    acceptedLocally: false,
    localMuted: false,
    remotePlayBlocked: false,
    connectedAtMs: 0,
    timerId: null,
    statsTimer: null,
    reconnectTimer: null,
    reconnectAttempts: 0,
    lastFinalToken: '',
    lastFinalStatus: '',
    lastPollAt: 0,
    micPermissionPrimed: false,
    lastSignalId: Math.max(0, Number(window.BM_WP_VOICE_AFTER_SIGNAL_ID || 0)),
    hiddenToFab: false,
    resumeBusy: false,
    lastResumeAt: 0,
    wakeLock: null,
    autoMinimizedToken: '',
    autoMinimizeTimer: null
  };

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const faDigits = (value) => String(value).replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)]);

  function voiceApi(action, payload = {}) {
    const body = new URLSearchParams();
    body.set('action', action);
    body.set('csrf_token', String(cfg.csrf || ''));
    body.set('voice_nonce', String(cfg.nonce || ''));
    Object.entries(payload).forEach(([key, value]) => {
      if (typeof value === 'object' && value !== null) body.set(key, JSON.stringify(value));
      else body.set(key, String(value ?? ''));
    });
    return fetch(String(cfg.api || '/watch_party_api.php') + '?action=' + encodeURIComponent(action), {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-Token': String(cfg.csrf || ''),
        'X-BM-Voice-Nonce': String(cfg.nonce || '')
      },
      body: body.toString()
    }).then(async res => {
      let data = {};
      try { data = await res.json(); } catch (_) {}
      if (!res.ok || !data.success) throw new Error(data.message || data.error || 'خطای تماس صوتی');
      return data;
    });
  }

  function randomId() {
    try {
      if (crypto.randomUUID) return 'v' + crypto.randomUUID().replace(/-/g, '');
      const bytes = new Uint8Array(16); crypto.getRandomValues(bytes);
      return 'v' + Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    } catch (_) {
      return 'v' + Date.now().toString(36) + Math.random().toString(36).slice(2, 18);
    }
  }

  function mount() {
    if (state.mounted) return;
    const wrapper = $('playerWrapper');
    const chat = $('playerChatBtn');
    if (!wrapper || !chat) return;

    const fab = document.createElement('button');
    fab.id = 'bmVoiceFab';
    fab.type = 'button';
    fab.className = 'bm-voice-fab';
    fab.setAttribute('aria-label', 'Voice Call');
    fab.innerHTML = `
      <span class="bm-voice-fab-ring"></span>
      <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.12.9.33 1.78.62 2.63a2 2 0 0 1-.45 2.11L8 9.73a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.85.29 1.73.5 2.63.62A2 2 0 0 1 22 16.92z"/></svg>
      <span class="bm-voice-beta-dot">BETA</span>
      <span class="bm-voice-live-dot" aria-hidden="true"></span>`;

    // Keep Chat + Voice in one responsive rail. Hard-coded independent offsets caused
    // the two buttons to drift apart in fullscreen landscape.
    let rail = wrapper.querySelector('.bm-player-quick-actions');
    if (!rail) {
      rail = document.createElement('div');
      rail.className = 'bm-player-quick-actions';
      chat.parentNode.insertBefore(rail, chat);
      rail.appendChild(chat);
    }
    // Voice Call sits directly above Chat in the vertical quick-action rail.
    rail.insertBefore(fab, chat);

    const card = document.createElement('section');
    card.id = 'bmVoiceCard';
    card.className = 'bm-voice-card';
    card.setAttribute('aria-live', 'polite');
    card.innerHTML = `
      <div class="bm-voice-card-glow"></div>
      <div class="bm-voice-head">
        <span class="bm-voice-kicker"><i></i> VOICE CALL</span>
        <button type="button" id="bmVoiceMinimize" class="bm-voice-mini" aria-label="مخفی کردن داخل آیکون تماس" title="مخفی کردن"><svg viewBox="0 0 24 24"><path d="M7 9l5 5 5-5"/></svg></button>
      </div>
      <div class="bm-voice-person">
        <span id="bmVoiceAvatar" class="bm-voice-avatar"><span>BM</span></span>
        <span class="bm-voice-meta"><strong id="bmVoiceTitle">Voice Call</strong><small id="bmVoiceStatus">آماده</small></span>
        <span id="bmVoiceWave" class="bm-voice-wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></span>
      </div>
      <div id="bmVoiceTransport" class="bm-voice-transport">WebRTC · رمزنگاری زنده</div>
      <div id="bmVoiceMovieHint" class="bm-voice-movie-hint">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5L6 9H2v6h4l5 4V5zM15 9a4 4 0 0 1 0 6"/></svg>
        <span>برای شنیدن واضح تماس، صدای فیلم را کمی کم کنید.</span>
      </div>
      <div id="bmVoiceIncomingActions" class="bm-voice-actions incoming hidden">
        <button type="button" id="bmVoiceReject" class="bm-voice-action danger"><svg viewBox="0 0 24 24"><path d="M23 7l-5 5-4-4-4 4-4-4-5 5"/></svg><span>رد</span></button>
        <button type="button" id="bmVoiceAccept" class="bm-voice-action accept"><svg viewBox="0 0 24 24"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3"/></svg><span>پاسخ</span></button>
      </div>
      <div id="bmVoiceLiveActions" class="bm-voice-actions live hidden">
        <button type="button" id="bmVoiceMute" class="bm-voice-action neutral"><svg class="mic-on" viewBox="0 0 24 24"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v3M8 22h8"/></svg><svg class="mic-off" viewBox="0 0 24 24"><path d="M1 1l22 22M9 9v3a3 3 0 0 0 5.12 2.12M15 9V5a3 3 0 0 0-5.6-1.5M5 10v2a7 7 0 0 0 11.2 5.6M19 10v2a7 7 0 0 1-.4 2.3M12 19v3M8 22h8"/></svg><span>میکروفن</span></button>
        <button type="button" id="bmVoiceResumeAudio" class="bm-voice-action neutral hidden"><svg viewBox="0 0 24 24"><path d="M11 5L6 9H2v6h4l5 4V5zM15 9a4 4 0 0 1 0 6M18 6a8 8 0 0 1 0 12"/></svg><span>فعال‌کردن صدا</span></button>
        <button type="button" id="bmVoiceEnd" class="bm-voice-action danger"><svg viewBox="0 0 24 24"><path d="M23 7l-5 5-4-4-4 4-4-4-5 5"/></svg><span>قطع</span></button>
      </div>
      <div id="bmVoiceReconnectActions" class="bm-voice-actions reconnect hidden">
        <button type="button" id="bmVoiceReconnect" class="bm-voice-action accept wide"><svg viewBox="0 0 24 24"><path d="M20 6v6h-6M4 18v-6h6"/><path d="M18.5 9A7 7 0 0 0 6.2 6.2L4 9M5.5 15A7 7 0 0 0 17.8 17.8L20 15"/></svg><span>اتصال دوباره</span></button>
      </div>`;
    wrapper.appendChild(card);

    const audio = document.createElement('audio');
    audio.id = 'bmVoiceRemoteAudio';
    audio.autoplay = true;
    audio.playsInline = true;
    audio.setAttribute('playsinline', '');
    audio.setAttribute('webkit-playsinline', '');
    audio.style.display = 'none';
    wrapper.appendChild(audio);

    fab.addEventListener('click', handleFabClick);
    $('bmVoiceAccept').addEventListener('click', acceptCall);
    $('bmVoiceReject').addEventListener('click', rejectCall);
    $('bmVoiceEnd').addEventListener('click', endCall);
    $('bmVoiceMute').addEventListener('click', toggleMute);
    $('bmVoiceResumeAudio').addEventListener('click', resumeRemoteAudio);
    $('bmVoiceReconnect').addEventListener('click', reconnectManually);
    $('bmVoiceMinimize').addEventListener('click', () => {
      state.hiddenToFab = true;
      showCard(false);
      try { fab.focus({preventScroll:true}); } catch (_) { fab.focus(); }
    });

    // Keep the movie clean: clicking anywhere outside an open active Voice Call card
    // sends it back into the phone icon without ending the call.
    document.addEventListener('pointerdown', (event) => {
      const card = $('bmVoiceCard');
      if (!card?.classList.contains('show')) return;
      if (event.target.closest?.('#bmVoiceCard') || event.target.closest?.('#bmVoiceFab')) return;
      if (state.call && ['connecting','active'].includes(String(state.call.status || ''))) {
        state.hiddenToFab = true;
        showCard(false);
      }
    }, {passive:true});

    // Mobile browsers may suspend timers/audio while backgrounded. Never hang up on
    // visibility/page lifecycle changes; when the page becomes active, repair the
    // existing server-side call instead of forcing the users to dial again.
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        requestVoiceWakeLock().catch(()=>{});
        scheduleResumeRecovery('visibility');
      }
    });
    window.addEventListener('pageshow', () => scheduleResumeRecovery('pageshow'));
    window.addEventListener('focus', () => scheduleResumeRecovery('focus'));
    window.addEventListener('pagehide', () => {
      // Intentionally do not end/close the call here. A quick return can reconnect.
      persistCallHint();
    });

    window.addEventListener('online', () => {
      if (!state.call || !['connecting','active'].includes(state.call.status)) return;
      setVoiceStatus('اینترنت برگشت؛ در حال اتصال مجدد…', 'reconnecting');
      if (state.call.is_caller) scheduleIceRestart(500);
      else enqueueSignal('reconnect', {reason:'online'});
    });
    window.addEventListener('offline', () => {
      if (state.call && ['connecting','active'].includes(state.call.status)) setVoiceStatus('اینترنت قطع است؛ تماس نگه داشته می‌شود…', 'reconnecting');
    });

    state.mounted = true;
    updateFab();
  }

  function setAvatar(peer) {
    const avatar = $('bmVoiceAvatar');
    if (!avatar) return;
    avatar.innerHTML = '';
    const url = String(peer?.avatar_url || '');
    if (url) {
      const img = new Image();
      img.alt = '';
      img.src = url;
      avatar.appendChild(img);
    } else {
      const span = document.createElement('span');
      const name = String(peer?.username || 'BM').trim();
      span.textContent = (name.slice(0, 2) || 'BM').toUpperCase();
      avatar.appendChild(span);
    }
  }

  function setVoiceStatus(text, mode = '') {
    const el = $('bmVoiceStatus');
    if (el) el.textContent = text;
    const card = $('bmVoiceCard');
    if (card) {
      card.classList.remove('is-ringing','is-connecting','is-active','is-reconnecting','is-ended');
      if (mode) card.classList.add('is-' + mode);
    }
  }

  function showCard(show = true) {
    const card = $('bmVoiceCard');
    if (!card) return;
    card.classList.toggle('show', show);
    if (show) state.hiddenToFab = false;
  }

  function handleFabClick() {
    const active = Boolean(state.call && ['ringing','connecting','active'].includes(String(state.call.status || '')));
    if (active) {
      const card = $('bmVoiceCard');
      showCard(!(card?.classList.contains('show')));
      return;
    }
    startCall();
  }

  function showActionSet(which) {
    ['bmVoiceIncomingActions','bmVoiceLiveActions','bmVoiceReconnectActions'].forEach(id => $(id)?.classList.add('hidden'));
    if (which === 'incoming') $('bmVoiceIncomingActions')?.classList.remove('hidden');
    if (which === 'live') $('bmVoiceLiveActions')?.classList.remove('hidden');
    if (which === 'reconnect') $('bmVoiceReconnectActions')?.classList.remove('hidden');
  }

  function updateFab() {
    const fab = $('bmVoiceFab');
    if (!fab) return;
    const active = Boolean(state.call && ['ringing','connecting','active'].includes(String(state.call.status || '')));
    fab.classList.toggle('active', active);
    fab.classList.toggle('call-live', Boolean(state.call && String(state.call.status || '') === 'active'));
    fab.disabled = !roomCode() || (!active && !state.peerAvailable);
    fab.title = !roomCode() ? 'ابتدا وارد اتاق شوید' : (!active && !state.peerAvailable ? 'طرف مقابل هنوز وارد اتاق نشده' : 'Voice Call');
  }

  function persistCallHint() {
    try {
      if (state.callToken && roomCode()) {
        sessionStorage.setItem('bm_wp_voice_resume', JSON.stringify({room:roomCode(), token:state.callToken, at:Date.now()}));
      }
    } catch (_) {}
  }

  function clearCallHint() {
    try { sessionStorage.removeItem('bm_wp_voice_resume'); } catch (_) {}
  }

  async function requestVoiceWakeLock() {
    if (!state.call || state.call.status !== 'active' || document.visibilityState !== 'visible') return;
    if (!('wakeLock' in navigator) || state.wakeLock) return;
    try {
      state.wakeLock = await navigator.wakeLock.request('screen');
      state.wakeLock.addEventListener?.('release', () => { state.wakeLock = null; }, {once:true});
    } catch (_) {}
  }

  function releaseVoiceWakeLock() {
    const lock = state.wakeLock;
    state.wakeLock = null;
    if (lock?.release) lock.release().catch(()=>{});
  }

  function scheduleResumeRecovery(reason = 'resume') {
    if (!state.call || !['connecting','active'].includes(String(state.call.status || ''))) return;
    if (document.visibilityState === 'hidden' || !navigator.onLine) return;
    const now = Date.now();
    if (now - state.lastResumeAt < 900) return;
    state.lastResumeAt = now;
    setTimeout(() => recoverExistingCall(reason).catch(()=>{}), 180);
  }

  async function recoverExistingCall(reason = 'resume') {
    if (state.resumeBusy || !state.callToken || !state.call) return;
    if (!['connecting','active'].includes(String(state.call.status || ''))) return;
    if (document.visibilityState === 'hidden' || !navigator.onLine) return;

    const pcState = String(state.pc?.connectionState || state.pc?.iceConnectionState || '');
    const localLive = Boolean(state.localStream?.getAudioTracks?.().some(t => t.readyState === 'live'));
    if (state.pc && ['connected','completed'].includes(pcState) && localLive) {
      const audio = $('bmVoiceRemoteAudio');
      if (audio?.srcObject && audio.paused) audio.play().catch(()=>{ state.remotePlayBlocked = true; $('bmVoiceResumeAudio')?.classList.remove('hidden'); });
      requestVoiceWakeLock().catch(()=>{});
      return;
    }

    state.resumeBusy = true;
    try {
      setVoiceStatus('در حال بازیابی Voice Call…', 'reconnecting');
      await ensureMicrophone();
      state.acceptedLocally = true;
      closePeerConnection({keepLocal:true});
      buildPeerConnection();
      state.reconnectAttempts = 0;
      if (state.call.is_caller) {
        await restartIce();
      } else {
        await enqueueSignal('reconnect', {reason:String(reason || 'resume').slice(0,24)}, true);
      }
      persistCallHint();
    } catch (error) {
      showActionSet('reconnect');
      setVoiceStatus('Voice Call حفظ شد؛ برای اتصال دوباره یک بار لمس کنید', 'reconnecting');
    } finally {
      state.resumeBusy = false;
    }
  }

  function scheduleAutoMinimize() {
    if (!state.callToken || state.autoMinimizedToken === state.callToken) return;
    state.autoMinimizedToken = state.callToken;
    clearTimeout(state.autoMinimizeTimer);
    state.autoMinimizeTimer = setTimeout(() => {
      if (!state.call || state.call.status !== 'active') return;
      state.hiddenToFab = true;
      showCard(false);
    }, 1800);
  }

  function microphonePolicyAllows() {
    try {
      const policy = document.permissionsPolicy || document.featurePolicy || null;
      if (policy && typeof policy.allowsFeature === 'function') return policy.allowsFeature('microphone');
    } catch (_) {}
    return true;
  }

  function friendlyMicError(error) {
    const name = String(error?.name || '');
    if (!window.isSecureContext) return new Error('برای تماس صوتی، صفحه باید با HTTPS باز شود.');
    if (!microphonePolicyAllows()) return new Error('دسترسی میکروفن برای این صفحه از سمت سایت بسته شده است. صفحه را تازه‌سازی کنید.');
    if (name === 'NotAllowedError' || name === 'PermissionDeniedError' || /permission denied/i.test(String(error?.message || ''))) {
      return new Error('اجازه میکروفن داده نشد. دسترسی Microphone این سایت را روی Allow بگذارید و صفحه را دوباره باز کنید.');
    }
    if (name === 'NotFoundError' || name === 'DevicesNotFoundError') return new Error('هیچ میکروفنی روی این دستگاه پیدا نشد.');
    if (name === 'NotReadableError' || name === 'TrackStartError') return new Error('میکروفن در اختیار برنامه دیگری است یا فعلاً قابل استفاده نیست.');
    return error instanceof Error ? error : new Error('فعال‌سازی میکروفن انجام نشد.');
  }

  async function ensureMicrophone() {
    if (state.localStream && state.localStream.getAudioTracks().some(t => t.readyState === 'live')) return state.localStream;
    if (!window.isSecureContext) throw new Error('برای تماس صوتی، صفحه باید با HTTPS باز شود.');
    if (!navigator.mediaDevices?.getUserMedia) throw new Error('این مرورگر دسترسی میکروفن WebRTC را ارائه نمی‌دهد.');
    if (!microphonePolicyAllows()) throw new Error('دسترسی میکروفن برای این صفحه از سمت سایت بسته شده است. صفحه را تازه‌سازی کنید.');

    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: {ideal:true},
          noiseSuppression: {ideal:true},
          autoGainControl: {ideal:true},
          channelCount: {ideal:1}
        },
        video: false
      });
    } catch (error) {
      // Some Android/WebView builds reject one of the optional audio constraints.
      // Retry once with a plain audio request; permission errors are still surfaced unchanged.
      const name = String(error?.name || '');
      if (name === 'OverconstrainedError' || name === 'ConstraintNotSatisfiedError') {
        try {
          stream = await navigator.mediaDevices.getUserMedia({audio:true, video:false});
        } catch (fallbackError) {
          throw friendlyMicError(fallbackError);
        }
      } else {
        throw friendlyMicError(error);
      }
    }
    state.localStream = stream;
    state.micPermissionPrimed = true;
    state.localMuted = false;
    updateMuteUi();
    return stream;
  }

  function closePeerConnection({keepLocal=false} = {}) {
    clearTimeout(state.reconnectTimer); state.reconnectTimer = null;
    clearInterval(state.statsTimer); state.statsTimer = null;
    if (state.pc) {
      try { state.pc.ontrack = null; state.pc.onicecandidate = null; state.pc.onconnectionstatechange = null; state.pc.close(); } catch (_) {}
      state.pc = null;
    }
    if (!keepLocal && state.localStream) {
      state.localStream.getTracks().forEach(track => { try { track.stop(); } catch (_) {} });
      state.localStream = null;
    }
    const audio = $('bmVoiceRemoteAudio');
    if (audio) {
      try { audio.pause(); } catch (_) {}
      audio.srcObject = null;
    }
    state.remoteStream = null;
    state.pendingOffer = null;
    state.pendingIce = [];
    state.remotePlayBlocked = false;
    $('bmVoiceResumeAudio')?.classList.add('hidden');
  }

  function buildPeerConnection() {
    if (state.pc && state.pc.signalingState !== 'closed') return state.pc;
    const pc = new RTCPeerConnection({
      iceServers: Array.isArray(cfg.iceServers) ? cfg.iceServers : [],
      bundlePolicy: 'max-bundle',
      rtcpMuxPolicy: 'require',
      iceCandidatePoolSize: 1
    });
    state.pc = pc;
    if (state.localStream) state.localStream.getAudioTracks().forEach(track => pc.addTrack(track, state.localStream));

    pc.onicecandidate = (event) => {
      if (!event.candidate || !state.callToken) return;
      const payload = typeof event.candidate.toJSON === 'function' ? event.candidate.toJSON() : {
        candidate:event.candidate.candidate,
        sdpMid:event.candidate.sdpMid,
        sdpMLineIndex:event.candidate.sdpMLineIndex,
        usernameFragment:event.candidate.usernameFragment
      };
      enqueueSignal('ice', payload);
    };
    pc.ontrack = (event) => {
      const stream = event.streams?.[0] || new MediaStream([event.track]);
      state.remoteStream = stream;
      const audio = $('bmVoiceRemoteAudio');
      if (!audio) return;
      audio.srcObject = stream;
      audio.volume = 1;
      const playPromise = audio.play();
      if (playPromise?.catch) playPromise.catch(() => {
        state.remotePlayBlocked = true;
        $('bmVoiceResumeAudio')?.classList.remove('hidden');
        setVoiceStatus('تماس وصل است؛ برای شنیدن صدا یک بار لمس کنید', 'active');
      });
    };
    pc.onconnectionstatechange = () => handleConnectionState(pc.connectionState || pc.iceConnectionState);
    pc.oniceconnectionstatechange = () => {
      if (pc.connectionState === 'new') handleConnectionState(pc.iceConnectionState);
    };
    return pc;
  }

  async function startCall() {
    if (state.call && ['ringing','connecting','active'].includes(state.call.status)) {
      showCard(true); return;
    }
    if (!state.peerAvailable) return;
    const code = roomCode();
    if (!code) return;
    const fab = $('bmVoiceFab');
    if (fab) fab.disabled = true;
    showCard(true); showActionSet('live');
    $('bmVoiceTitle').textContent = 'Voice Call';
    setVoiceStatus('اجازه میکروفن را تأیید کنید', 'connecting');
    try {
      await ensureMicrophone();
      const data = await voiceApi('voice_start', {room_code: code});
      if (!data.call) throw new Error('تماس ساخته نشد.');
      adoptCall(data.call, true);
      const pc = buildPeerConnection();
      const offer = await pc.createOffer({offerToReceiveAudio:true});
      await pc.setLocalDescription(offer);
      await enqueueSignal('offer', pc.localDescription?.toJSON ? pc.localDescription.toJSON() : {type:pc.localDescription.type,sdp:pc.localDescription.sdp}, true);
      setVoiceStatus('در حال زنگ خوردن…', 'ringing');
    } catch (error) {
      closePeerConnection();
      setVoiceStatus(error.message || 'شروع تماس انجام نشد.', 'ended');
      showActionSet('');
      setTimeout(() => { if (!state.call) showCard(false); }, 2600);
    } finally {
      updateFab();
    }
  }

  async function acceptCall() {
    if (!state.call || state.call.is_caller || state.call.status !== 'ringing') return;
    $('bmVoiceAccept').disabled = true;
    $('bmVoiceReject').disabled = true;
    try {
      setVoiceStatus('در حال فعال‌کردن میکروفن…', 'connecting');
      await ensureMicrophone();
      await voiceApi('voice_action', {room_code: roomCode(), call_token: state.callToken, voice_action:'accept'});
      state.acceptedLocally = true;
      buildPeerConnection();
      showActionSet('live');
      setVoiceStatus('در حال برقراری اتصال امن…', 'connecting');
      if (state.pendingOffer) await handleOffer(state.pendingOffer);
    } catch (error) {
      setVoiceStatus(error.message || 'پاسخ به تماس انجام نشد.', 'ended');
      await safeEnd('reject');
    } finally {
      $('bmVoiceAccept').disabled = false;
      $('bmVoiceReject').disabled = false;
    }
  }

  async function rejectCall() {
    if (!state.call) return;
    const token = state.callToken;
    try { await voiceApi('voice_action', {room_code: roomCode(), call_token:token, voice_action:'reject'}); } catch (_) {}
    setVoiceStatus('تماس رد شد', 'ended');
    finishLocalCall('rejected');
  }

  async function endCall() {
    if (!state.callToken) { finishLocalCall('ended'); return; }
    const action = state.call?.is_caller && ['ringing','connecting'].includes(state.call?.status) ? 'cancel' : 'hangup';
    await safeEnd(action);
    setVoiceStatus('تماس پایان یافت', 'ended');
    finishLocalCall('ended', 900);
  }

  async function safeEnd(action='hangup') {
    try { await voiceApi('voice_action', {room_code:roomCode(), call_token:state.callToken, voice_action:action}); } catch (_) {}
  }

  function finishLocalCall(status='ended', delay=1200) {
    state.lastFinalToken = state.callToken;
    state.lastFinalStatus = status;
    closePeerConnection();
    state.call = null;
    state.callToken = '';
    state.acceptedLocally = false;
    state.seenSignals.clear();
    state.signalQueue = [];
    state.signalBusy = false;
    state.reconnectAttempts = 0;
    state.hiddenToFab = false;
    state.autoMinimizedToken = '';
    clearTimeout(state.autoMinimizeTimer); state.autoMinimizeTimer = null;
    clearCallHint();
    releaseVoiceWakeLock();
    clearInterval(state.timerId); state.timerId = null;
    $('bmVoiceWave')?.classList.remove('live');
    updateFab();
    showActionSet('');
    setTimeout(() => { if (!state.call) showCard(false); }, delay);
  }

  function adoptCall(call, localCreation = false) {
    if (!call?.token) return;
    const tokenChanged = state.callToken && state.callToken !== call.token;
    if (tokenChanged) {
      closePeerConnection();
      state.seenSignals.clear();
      state.signalQueue = [];
      state.acceptedLocally = false;
      state.reconnectAttempts = 0;
    }
    state.call = call;
    state.callToken = String(call.token);
    state.peer = call.peer || state.peer;
    setAvatar(state.peer);
    $('bmVoiceTitle').textContent = String(state.peer?.username || 'همراه');

    if (call.status === 'ringing') {
      if (!state.hiddenToFab) showCard(true);
      if (call.is_caller) {
        showActionSet('live');
        setVoiceStatus('در حال زنگ خوردن…', 'ringing');
      } else {
        showActionSet('incoming');
        setVoiceStatus('Voice Call ورودی', 'ringing');
        if (!localCreation && tokenChanged !== false && navigator.vibrate) navigator.vibrate([90,80,90]);
      }
    } else if (call.status === 'connecting') {
      if (!state.hiddenToFab) showCard(true);
      showActionSet('live'); setVoiceStatus('در حال اتصال…', 'connecting');
    } else if (call.status === 'active') {
      if (!state.hiddenToFab) showCard(true);
      if (!state.pc) {
        showActionSet('live');
        setVoiceStatus('در حال بازیابی Voice Call…', 'reconnecting');
        scheduleResumeRecovery('poll');
      } else {
        showActionSet('live'); setVoiceStatus(call.peer_muted ? 'متصل · میکروفن طرف مقابل بسته است' : 'متصل', 'active');
      }
      ensureTimer(call.connected_at);
      persistCallHint();
    }
    state.localMuted = Boolean(call.mine_muted) && Boolean(state.localStream);
    updateMuteUi();
    updateFab();
  }

  function ensureTimer(serverConnectedAt) {
    if (!state.connectedAtMs) {
      const parsed = Date.parse(String(serverConnectedAt || '').replace(' ', 'T') + 'Z');
      state.connectedAtMs = Number.isFinite(parsed) ? parsed : Date.now();
    }
    clearInterval(state.timerId);
    const tick = () => {
      if (!state.call || state.call.status !== 'active') return;
      const sec = Math.max(0, Math.floor((Date.now() - state.connectedAtMs) / 1000));
      const min = Math.floor(sec / 60), rem = sec % 60;
      const suffix = `${String(min).padStart(2,'0')}:${String(rem).padStart(2,'0')}`;
      const base = state.call.peer_muted ? 'متصل · طرف مقابل بی‌صدا' : 'متصل';
      $('bmVoiceStatus').textContent = `${base} · ${faDigits(suffix)}`;
    };
    tick(); state.timerId = setInterval(tick, 1000);
    startStatsProbe();
  }

  function updateMuteUi() {
    const btn = $('bmVoiceMute');
    if (!btn) return;
    btn.classList.toggle('muted', state.localMuted);
    const span = btn.querySelector('span'); if (span) span.textContent = state.localMuted ? 'وصل میکروفن' : 'قطع میکروفن';
  }

  async function toggleMute() {
    if (!state.localStream || !state.callToken) return;
    state.localMuted = !state.localMuted;
    state.localStream.getAudioTracks().forEach(track => track.enabled = !state.localMuted);
    updateMuteUi();
    try { await voiceApi('voice_action', {room_code:roomCode(), call_token:state.callToken, voice_action:'mute', muted:state.localMuted ? '1' : '0'}); } catch (_) {}
  }

  async function resumeRemoteAudio() {
    const audio = $('bmVoiceRemoteAudio');
    if (!audio?.srcObject) return;
    try {
      await audio.play();
      state.remotePlayBlocked = false;
      $('bmVoiceResumeAudio')?.classList.add('hidden');
      setVoiceStatus('متصل · صدای فیلم را کمی کم کنید', 'active');
    } catch (_) {
      setVoiceStatus('مرورگر هنوز صدای تماس را متوقف کرده؛ دوباره لمس کنید', 'active');
    }
  }

  async function enqueueSignal(type, payload, immediate = false) {
    if (!state.callToken) return;
    const item = {type, payload, id:randomId().slice(0,64), token:state.callToken};
    state.signalQueue.push(item);
    if (immediate) return flushSignals();
    queueMicrotask(flushSignals);
  }

  async function flushSignals() {
    if (state.signalBusy || !navigator.onLine) return;
    state.signalBusy = true;
    try {
      while (state.signalQueue.length && navigator.onLine) {
        const item = state.signalQueue[0];
        if (!state.callToken || item.token !== state.callToken) { state.signalQueue.shift(); continue; }
        try {
          await voiceApi('voice_signal', {
            room_code:roomCode(), call_token:item.token, signal_type:item.type,
            client_signal_id:item.id, payload:item.payload
          });
          state.signalQueue.shift();
        } catch (error) {
          if (/زیاد|rate/i.test(error.message || '')) setTimeout(flushSignals, 1200);
          else setTimeout(flushSignals, 800);
          break;
        }
      }
    } finally { state.signalBusy = false; }
  }

  async function processSignal(signal) {
    const id = Number(signal?.id || 0);
    if (!id || state.seenSignals.has(id)) return;
    state.seenSignals.add(id);
    state.lastSignalId = Math.max(state.lastSignalId, id);
    window.BM_WP_VOICE_AFTER_SIGNAL_ID = state.lastSignalId;
    if (state.seenSignals.size > 320) state.seenSignals = new Set(Array.from(state.seenSignals).slice(-180));
    const type = String(signal.signal_type || '');
    const payload = signal.payload;
    try {
      if (type === 'offer') {
        state.pendingOffer = payload;
        if (state.acceptedLocally || state.call?.status === 'connecting' || (state.call?.status === 'active' && state.localStream)) await handleOffer(payload);
      } else if (type === 'answer') {
        if (!state.call?.is_caller) return;
        const pc = buildPeerConnection();
        if (payload?.type && payload?.sdp && pc.signalingState !== 'closed') {
          await pc.setRemoteDescription(new RTCSessionDescription(payload));
          await flushPendingIce();
        }
      } else if (type === 'ice') {
        if (!payload?.candidate) return;
        const pc = state.pc;
        if (pc?.remoteDescription) await pc.addIceCandidate(new RTCIceCandidate(payload));
        else state.pendingIce.push(payload);
      } else if (type === 'reconnect') {
        if (state.call?.is_caller && ['connecting','active'].includes(state.call.status)) scheduleIceRestart(250);
      }
    } catch (error) {
      console.debug('[BankMovie Voice Call] signal handling', type, error);
    }
  }

  async function handleOffer(payload) {
    if (!payload?.type || !payload?.sdp) return;
    if (!state.localStream) return;
    const pc = buildPeerConnection();
    if (pc.signalingState === 'have-local-offer') {
      try { await pc.setLocalDescription({type:'rollback'}); } catch (_) {}
    }
    await pc.setRemoteDescription(new RTCSessionDescription(payload));
    await flushPendingIce();
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await enqueueSignal('answer', pc.localDescription?.toJSON ? pc.localDescription.toJSON() : {type:pc.localDescription.type,sdp:pc.localDescription.sdp}, true);
    state.pendingOffer = null;
  }

  async function flushPendingIce() {
    const pc = state.pc;
    if (!pc?.remoteDescription) return;
    const pending = state.pendingIce.splice(0);
    for (const candidate of pending) {
      try { await pc.addIceCandidate(new RTCIceCandidate(candidate)); } catch (_) {}
    }
  }

  function handleConnectionState(value) {
    const status = String(value || '');
    if (status === 'connected' || status === 'completed') {
      clearTimeout(state.reconnectTimer); state.reconnectTimer = null;
      state.reconnectAttempts = 0;
      $('bmVoiceWave')?.classList.add('live');
      showActionSet('live');
      if (state.call) state.call.status = 'active';
      if (!state.connectedAtMs) state.connectedAtMs = Date.now();
      setVoiceStatus('متصل · صدای فیلم را کمی کم کنید', 'active');
      ensureTimer(state.call?.connected_at || '');
      persistCallHint();
      requestVoiceWakeLock().catch(()=>{});
      scheduleAutoMinimize();
      voiceApi('voice_action', {room_code:roomCode(),call_token:state.callToken,voice_action:'connected'}).catch(()=>{});
      return;
    }
    if (status === 'disconnected') {
      setVoiceStatus('کیفیت شبکه افت کرده؛ در حال اتصال مجدد…', 'reconnecting');
      if (state.call?.is_caller) scheduleIceRestart(3500);
      return;
    }
    if (status === 'failed') {
      setVoiceStatus('مسیر صدا قطع شد؛ در حال پیدا کردن مسیر جدید…', 'reconnecting');
      if (state.call?.is_caller) scheduleIceRestart(350);
      else enqueueSignal('reconnect', {reason:'failed'});
      return;
    }
    if (status === 'closed' && state.call) setVoiceStatus('اتصال صوتی بسته شد', 'ended');
  }

  function scheduleIceRestart(delay = 1000) {
    clearTimeout(state.reconnectTimer);
    state.reconnectTimer = setTimeout(() => restartIce().catch(()=>{}), delay);
  }

  async function restartIce() {
    if (!state.call?.is_caller || !state.localStream || !state.callToken) return;
    if (state.reconnectAttempts >= 4) {
      showActionSet('reconnect');
      setVoiceStatus('اتصال خودکار کامل نشد؛ یک بار «اتصال دوباره» را بزنید', 'reconnecting');
      return;
    }
    state.reconnectAttempts++;
    let pc = buildPeerConnection();
    try { pc.restartIce?.(); } catch (_) {}
    const offer = await pc.createOffer({iceRestart:true, offerToReceiveAudio:true});
    await pc.setLocalDescription(offer);
    await enqueueSignal('offer', pc.localDescription?.toJSON ? pc.localDescription.toJSON() : {type:pc.localDescription.type,sdp:pc.localDescription.sdp}, true);
  }

  async function reconnectManually() {
    if (!state.callToken) return;
    $('bmVoiceReconnect').disabled = true;
    try {
      await ensureMicrophone();
      state.acceptedLocally = true;
      closePeerConnection({keepLocal:true});
      buildPeerConnection();
      showActionSet('live');
      setVoiceStatus('در حال اتصال مجدد…', 'reconnecting');
      state.reconnectAttempts = 0;
      if (state.call?.is_caller) await restartIce();
      else await enqueueSignal('reconnect', {reason:'manual'}, true);
    } catch (error) {
      setVoiceStatus(error.message || 'اتصال مجدد انجام نشد.', 'reconnecting');
    } finally { $('bmVoiceReconnect').disabled = false; }
  }

  function startStatsProbe() {
    clearInterval(state.statsTimer);
    const probe = async () => {
      const pc = state.pc;
      if (!pc || pc.connectionState !== 'connected') return;
      try {
        const reports = await pc.getStats();
        let pair = null, local = null;
        reports.forEach(report => { if (report.type === 'transport' && report.selectedCandidatePairId) pair = reports.get(report.selectedCandidatePairId); });
        if (!pair) reports.forEach(report => { if (report.type === 'candidate-pair' && report.state === 'succeeded' && report.nominated) pair = report; });
        if (pair?.localCandidateId) local = reports.get(pair.localCandidateId);
        const relay = String(local?.candidateType || '') === 'relay';
        const transport = $('bmVoiceTransport');
        if (transport) transport.textContent = relay ? 'TURN Relay · رمزنگاری زنده' : 'P2P مستقیم · رمزنگاری زنده';
      } catch (_) {}
    };
    probe(); state.statsTimer = setInterval(probe, 12000);
  }

  function handleFinalStatus(call) {
    if (!call?.token || !['ended','rejected','missed'].includes(call.status)) return;
    if (state.lastFinalToken === call.token && state.lastFinalStatus === call.status) return;
    state.lastFinalToken = call.token; state.lastFinalStatus = call.status;
    const labels = {ended:'تماس پایان یافت',rejected:'تماس رد شد',missed:'پاسخی دریافت نشد'};
    setAvatar(call.peer || state.peer);
    $('bmVoiceTitle').textContent = String(call.peer?.username || 'همراه');
    setVoiceStatus(labels[call.status] || 'تماس پایان یافت', 'ended');
    if (!state.hiddenToFab) showCard(true); showActionSet('');
    finishLocalCall(call.status, 1800);
  }

  function onPoll(data) {
    mount();
    state.lastPollAt = Date.now();
    const voice = data?.voice;
    if (!voice?.enabled) return;
    state.peerAvailable = Boolean(voice.peer_available);
    if (voice.peer) state.peer = voice.peer;
    updateFab();

    const call = voice.call;
    if (!call) {
      if (state.call && !state.callToken) state.call = null;
      return;
    }
    if (['ended','rejected','missed'].includes(String(call.status))) {
      handleFinalStatus(call); return;
    }
    const newToken = state.callToken !== String(call.token || '');
    adoptCall(call, false);
    if (newToken && !call.is_caller && call.status === 'ringing') {
      state.acceptedLocally = false;
      state.hiddenToFab = false;
      showCard(true);
      $('bmVoiceWave')?.classList.add('ringing');
    }
    (voice.signals || []).forEach(signal => processSignal(signal));
    if (call.status === 'active' && !state.pc) scheduleResumeRecovery('poll-active');
    const serverLastSignalId = Math.max(0, Number(voice.last_signal_id || 0));
    if (serverLastSignalId) {
      state.lastSignalId = Math.max(state.lastSignalId, serverLastSignalId);
      window.BM_WP_VOICE_AFTER_SIGNAL_ID = state.lastSignalId;
    }
  }

  window.addEventListener('bm:watch-party-poll', event => onPoll(event.detail || {}));
  document.addEventListener('DOMContentLoaded', mount, {once:true});
  if (document.readyState !== 'loading') mount();
  setTimeout(() => scheduleResumeRecovery('boot'), 900);
})();
