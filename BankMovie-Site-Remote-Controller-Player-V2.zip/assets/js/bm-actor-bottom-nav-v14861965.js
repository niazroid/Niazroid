/* BankMovie V14861965 — actor bottom nav behaves like the main mobile nav. */
(function(){
  'use strict';
  function start(){
    if(!document.body || !document.body.classList.contains('bm-actor-v98')) return;
    var nav=document.querySelector('.bottom-nav[data-mobile-bottom-nav]');
    if(!nav || nav.dataset.bmActorSmartNav==='1') return;
    nav.dataset.bmActorSmartNav='1';
    var lastY=window.scrollY||0;
    var ticking=false;
    var minDelta=12;

    function keepVisible(){
      var active=document.activeElement;
      return window.innerWidth>=992 ||
        (window.scrollY||0)<120 ||
        document.body.classList.contains('actor-menu-open') ||
        document.querySelector('.actor-side-menu.open') ||
        (active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName));
    }

    function update(){
      var y=window.scrollY||0;
      var diff=y-lastY;
      if(keepVisible()){
        nav.classList.remove('nav-hidden');
        nav.classList.toggle('nav-compact',y>220);
        lastY=y;
        ticking=false;
        return;
      }
      if(Math.abs(diff)>minDelta){
        nav.classList.toggle('nav-hidden',diff>0);
        nav.classList.toggle('nav-compact',y>220 && diff<=0);
        lastY=y;
      }
      ticking=false;
    }

    function requestUpdate(){
      if(!ticking){
        window.requestAnimationFrame(update);
        ticking=true;
      }
    }

    window.addEventListener('scroll',requestUpdate,{passive:true});
    window.addEventListener('resize',requestUpdate,{passive:true});
    window.addEventListener('orientationchange',requestUpdate,{passive:true});
    window.addEventListener('pageshow',requestUpdate,{passive:true});
    document.addEventListener('focusin',requestUpdate);
    document.addEventListener('focusout',function(){setTimeout(requestUpdate,80)});
    nav.addEventListener('pointerdown',function(){nav.classList.remove('nav-hidden')},{passive:true});
    update();
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true});
  else start();
})();
