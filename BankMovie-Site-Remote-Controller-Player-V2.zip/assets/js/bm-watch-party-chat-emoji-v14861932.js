(function(){
  'use strict';
  var EMOJIS = [
    '😂','😐','😭','❤️','😘','😁','👌','😊','😡','👍','😳','😔','😜','☺️','😍','😄','💋','🫪','😝','😒','😢','😅','😏','🙈','😱','😃','😉','🥸','😚','😀','😋','😌','😞','🤣','🙊','😕','🦶','😆','😇','🙀','😾','🤝','🕯','🥹','🥱','🤩','🥳','🥰','😎','🥶','🙄','🤤','👿','😈','😹','💩','🤡','🖕','👎','🤙','🫀','❣','🩷','🧡','💛','💚','🩵','💙','💜','🖤','🩶','🤍','🤎','❤️‍🔥','❤️‍🩹','💔','💕','💞','💓','💗','💖','💘','💝','💟','♥️','🎀','🎏','🧸','🧿','👑','💍','🤮','🤢','🫠','🫩','🤬'
  ];

  function ready(fn){ if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true}); else fn(); }
  function insertAtCursor(input,text){
    if(!input) return;
    var start=typeof input.selectionStart==='number'?input.selectionStart:input.value.length;
    var end=typeof input.selectionEnd==='number'?input.selectionEnd:start;
    var next=input.value.slice(0,start)+text+input.value.slice(end);
    if(next.length>500) next=next.slice(0,500);
    input.value=next;
    var pos=Math.min(next.length,start+text.length);
    try{input.setSelectionRange(pos,pos);}catch(_){ }
    input.dispatchEvent(new Event('input',{bubbles:true}));
  }

  ready(function(){
    var body=document.body;
    if(!body || !body.classList.contains('watch-party-page')) return;
    var form=document.getElementById('chatForm');
    var input=document.getElementById('chatInput');
    if(!form || !input || document.getElementById('bmChatEmojiBtn')) return;

    var button=document.createElement('button');
    button.id='bmChatEmojiBtn';
    button.className='bm-chat-emoji-btn';
    button.type='button';
    button.setAttribute('aria-label','باز کردن ایموجی‌ها');
    button.setAttribute('aria-expanded','false');
    button.textContent='☺️';

    var picker=document.createElement('div');
    picker.id='bmChatEmojiPicker';
    picker.className='bm-chat-emoji-picker';
    picker.setAttribute('role','dialog');
    picker.setAttribute('aria-label','انتخاب ایموجی');
    var head=document.createElement('div');
    head.className='bm-chat-emoji-head';
    head.innerHTML='<strong>ایموجی‌ها</strong><span>'+EMOJIS.length+' ایموجی منتخب</span>';
    var grid=document.createElement('div');
    grid.className='bm-chat-emoji-grid';
    EMOJIS.forEach(function(emoji){
      var item=document.createElement('button');
      item.type='button';
      item.className='bm-chat-emoji-item';
      item.setAttribute('aria-label','ایموجی '+emoji);
      item.textContent=emoji;
      item.addEventListener('click',function(ev){
        ev.preventDefault();
        insertAtCursor(input,emoji);
        input.focus({preventScroll:true});
      });
      grid.appendChild(item);
    });
    picker.append(head,grid);

    form.insertBefore(button,input);
    form.appendChild(picker);

    function setOpen(open){
      picker.classList.toggle('open',!!open);
      button.setAttribute('aria-expanded',open?'true':'false');
    }
    button.addEventListener('click',function(ev){ev.preventDefault();ev.stopPropagation();setOpen(!picker.classList.contains('open'));});
    picker.addEventListener('click',function(ev){ev.stopPropagation();});
    document.addEventListener('pointerdown',function(ev){if(!picker.classList.contains('open'))return;if(!picker.contains(ev.target)&&ev.target!==button)setOpen(false);},{passive:true});
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')setOpen(false);});
    form.addEventListener('submit',function(){setOpen(false);});

    /*
     * The chat can be portaled between the player/fullscreen and <body> on mobile.
     * Keep a local copy of the active key as an extra safety net, while the CSS
     * hard-fix paints directly from html[data-bm-background].
     */
    var panel=document.getElementById('playerChatPanel');
    function syncBackgroundKey(){
      var key=document.documentElement.getAttribute('data-bm-background')||'simple';
      if(panel) panel.setAttribute('data-room-background',key);
    }
    syncBackgroundKey();
    new MutationObserver(syncBackgroundKey).observe(document.documentElement,{attributes:true,attributeFilter:['data-bm-background']});
    window.addEventListener('bm:watch-party-background',syncBackgroundKey);
  });
})();
