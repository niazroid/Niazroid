(function(){
  'use strict';

  var EMOJIS = [
    '😂','😐','😭','❤️','😘','😁','👌','😊','😡','👍','😳','😔','😜','☺️','😍','😄','💋','🫪','😝','😒','😢','😅','😏','🙈','😱','😃','😉','🥸','😚','😀','😋','😌','😞','🤣','🙊','😕','🦶','😆','😇','🙀','😾','🤝','🕯','🥹','🥱','🤩','🥳','🥰','😎','🥶','🙄','🤤','👿','😈','😹','💩','🤡','🖕','👎','🤙','🫀','❣','🩷','🧡','💛','💚','🩵','💙','💜','🖤','🩶','🤍','🤎','❤️‍🔥','❤️‍🩹','💔','💕','💞','💓','💗','💖','💘','💝','💟','♥️','🎀','🎏','🧸','🧿','👑','💍','🤮','🤢','🫠','🫩','🤬'
  ];
  var STICKERS = Array.isArray(window.BM_WP_STICKERS && window.BM_WP_STICKERS.duck)
    ? window.BM_WP_STICKERS.duck.filter(function(item){ return item && item.id && item.url; })
    : [];

  function ready(fn){ if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',fn,{once:true}); else fn(); }
  function isCoarse(){ return Boolean((navigator.maxTouchPoints||0)>0 || (window.matchMedia && window.matchMedia('(pointer: coarse)').matches)); }
  function insertAtCursor(input,text){
    if(!input) return;
    var start=typeof input.selectionStart==='number'?input.selectionStart:input.value.length;
    var end=typeof input.selectionEnd==='number'?input.selectionEnd:start;
    var next=input.value.slice(0,start)+text+input.value.slice(end);
    if(next.length>500) next=next.slice(0,500);
    input.value=next;
    var pos=Math.min(next.length,start+text.length);
    try{input.setSelectionRange(pos,pos);}catch(_){ }
    input.dispatchEvent(new Event('input',{bubbles:true}));
  }

  ready(function(){
    var body=document.body;
    if(!body || !body.classList.contains('watch-party-page')) return;
    var panel=document.getElementById('playerChatPanel');
    var form=document.getElementById('chatForm');
    var input=document.getElementById('chatInput');
    if(!panel || !form || !input || document.getElementById('bmChatMediaPicker')) return;

    /* Telegram-like composer: text field + emoji + sticker buttons in one pill. */
    var composer=document.createElement('div');
    composer.className='bm-chat-composer';
    form.insertBefore(composer,input);
    composer.appendChild(input);

    var emojiButton=document.createElement('button');
    emojiButton.id='bmChatEmojiBtn';
    emojiButton.className='bm-chat-media-btn bm-chat-emoji-btn';
    emojiButton.type='button';
    emojiButton.setAttribute('aria-label','ایموجی‌ها');
    emojiButton.setAttribute('aria-expanded','false');
    emojiButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"></circle><path d="M8.4 10h.01M15.6 10h.01"></path><path d="M8.5 14c.9 1.35 2.05 2 3.5 2s2.6-.65 3.5-2"></path></svg>';
    composer.appendChild(emojiButton);

    var stickerButton=document.createElement('button');
    stickerButton.id='bmChatStickerBtn';
    stickerButton.className='bm-chat-media-btn bm-chat-sticker-btn';
    stickerButton.type='button';
    stickerButton.setAttribute('aria-label','استیکرها');
    stickerButton.setAttribute('aria-expanded','false');
    stickerButton.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h9a5 5 0 0 1 5 5v5.2a3 3 0 0 1-.88 2.12l-4.8 4.8A3 3 0 0 1 13.2 21H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Z"></path><path d="M14 20v-4a2 2 0 0 1 2-2h4"></path><path d="M8.3 9.3h.01M14.7 9.3h.01"></path><path d="M8.7 12.7c.9 1.2 2 1.8 3.3 1.8 1.1 0 2.1-.45 3-1.35"></path></svg>';
    composer.appendChild(stickerButton);

    var picker=document.createElement('div');
    picker.id='bmChatMediaPicker';
    picker.className='bm-chat-media-picker';
    picker.setAttribute('role','dialog');
    picker.setAttribute('aria-label','ایموجی و استیکر');

    var tabs=document.createElement('div');
    tabs.className='bm-chat-picker-tabs';
    tabs.innerHTML=''
      +'<button type="button" class="bm-chat-picker-tab active" data-pane="emoji" aria-pressed="true"><span class="bm-tab-icon">☺</span><span>ایموجی</span></button>'
      +'<button type="button" class="bm-chat-picker-tab" data-pane="sticker" aria-pressed="false"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 3h9a5 5 0 0 1 5 5v5.2a3 3 0 0 1-.88 2.12l-4.8 4.8A3 3 0 0 1 13.2 21H7a4 4 0 0 1-4-4V7a4 4 0 0 1 4-4Z"></path><path d="M14 20v-4a2 2 0 0 1 2-2h4"></path></svg><span>Duck</span></button>';

    var emojiPane=document.createElement('section');
    emojiPane.className='bm-chat-picker-pane active';
    emojiPane.dataset.pane='emoji';
    var emojiHead=document.createElement('div');
    emojiHead.className='bm-chat-picker-head';
    emojiHead.innerHTML='<strong>ایموجی‌ها</strong><span>'+EMOJIS.length+' مورد</span>';
    var emojiGrid=document.createElement('div');
    emojiGrid.className='bm-chat-emoji-grid';
    EMOJIS.forEach(function(emoji){
      var item=document.createElement('button');
      item.type='button';
      item.className='bm-chat-emoji-item';
      item.setAttribute('aria-label','ایموجی '+emoji);
      item.textContent=emoji;
      item.addEventListener('click',function(ev){
        ev.preventDefault();
        insertAtCursor(input,emoji);
        if(!isCoarse()){
          try{input.focus({preventScroll:true});}catch(_){input.focus();}
        }
      });
      emojiGrid.appendChild(item);
    });
    emojiPane.append(emojiHead,emojiGrid);

    var stickerPane=document.createElement('section');
    stickerPane.className='bm-chat-picker-pane';
    stickerPane.dataset.pane='sticker';
    stickerPane.hidden=true;
    var stickerHead=document.createElement('div');
    stickerHead.className='bm-chat-picker-head bm-chat-sticker-head';
    stickerHead.innerHTML='<strong>Duck</strong><span>'+STICKERS.length+' استیکر</span>';
    var stickerGrid=document.createElement('div');
    stickerGrid.className='bm-chat-sticker-grid';

    var stickerVideos=[];
    var stickerObserver=null;
    function activateStickerVideo(video){
      if(!video.src && video.dataset.src) video.src=video.dataset.src;
      var play=video.play && video.play();
      if(play && typeof play.catch==='function') play.catch(function(){});
    }
    function pauseStickerVideo(video){ try{video.pause();}catch(_){ } }
    if('IntersectionObserver' in window){
      stickerObserver=new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting && picker.classList.contains('open')) activateStickerVideo(entry.target);
          else pauseStickerVideo(entry.target);
        });
      },{root:picker,rootMargin:'80px 0px',threshold:0.01});
    }

    function sendSticker(sticker){
      if(!sticker || !sticker.id) return;
      var marker='[bm-sticker:duck:'+String(sticker.id)+']';
      var draft=input.value;
      input.value=marker;
      input.dispatchEvent(new Event('input',{bubbles:true}));
      try{
        if(typeof form.requestSubmit==='function') form.requestSubmit();
        else form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
      }catch(_){
        form.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));
      }
      setTimeout(function(){
        if(draft && input.value===''){
          input.value=draft;
          input.dispatchEvent(new Event('input',{bubbles:true}));
        }
      },0);
    }

    if(STICKERS.length){
      STICKERS.forEach(function(sticker){
        var item=document.createElement('button');
        item.type='button';
        item.className='bm-chat-sticker-item';
        item.setAttribute('aria-label','ارسال استیکر Duck');
        var video=document.createElement('video');
        video.className='bm-chat-sticker-thumb';
        video.dataset.src=String(sticker.url||'');
        video.muted=true;video.loop=true;video.playsInline=true;video.preload='none';
        video.setAttribute('aria-hidden','true');
        video.setAttribute('disablepictureinpicture','');
        item.appendChild(video);
        item.addEventListener('click',function(ev){ev.preventDefault();sendSticker(sticker);});
        stickerGrid.appendChild(item);
        stickerVideos.push(video);
        if(stickerObserver) stickerObserver.observe(video);
      });
    }else{
      var empty=document.createElement('div');
      empty.className='bm-chat-sticker-empty';
      empty.innerHTML='<strong>پک Duck پیدا نشد</strong><span>فایل‌های WEBM را داخل <b>sticker/duck</b> نگه دارید.</span>';
      stickerGrid.appendChild(empty);
    }
    stickerPane.append(stickerHead,stickerGrid);
    picker.append(tabs,emojiPane,stickerPane);
    panel.appendChild(picker);

    var tabButtons=Array.prototype.slice.call(tabs.querySelectorAll('.bm-chat-picker-tab'));
    function selectPane(name){
      var stickerMode=name==='sticker';
      emojiPane.hidden=stickerMode;stickerPane.hidden=!stickerMode;
      emojiPane.classList.toggle('active',!stickerMode);stickerPane.classList.toggle('active',stickerMode);
      tabButtons.forEach(function(tab){
        var active=tab.dataset.pane===name;
        tab.classList.toggle('active',active);tab.setAttribute('aria-pressed',active?'true':'false');
      });
      if(stickerMode && picker.classList.contains('open')){
        requestAnimationFrame(function(){stickerVideos.slice(0,12).forEach(activateStickerVideo);});
      }else{
        stickerVideos.forEach(pauseStickerVideo);
      }
    }
    tabButtons.forEach(function(tab){tab.addEventListener('click',function(){selectPane(tab.dataset.pane||'emoji');});});

    function setOpen(open,paneName){
      if(paneName) selectPane(paneName);
      picker.classList.toggle('open',!!open);
      emojiButton.setAttribute('aria-expanded',open && !stickerPane.classList.contains('active')?'true':'false');
      stickerButton.setAttribute('aria-expanded',open && stickerPane.classList.contains('active')?'true':'false');
      if(open && stickerPane.classList.contains('active')) requestAnimationFrame(function(){stickerVideos.slice(0,12).forEach(activateStickerVideo);});
      if(!open) stickerVideos.forEach(pauseStickerVideo);
    }
    emojiButton.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      var same=picker.classList.contains('open') && emojiPane.classList.contains('active');
      setOpen(!same,'emoji');
    });
    stickerButton.addEventListener('click',function(ev){
      ev.preventDefault();ev.stopPropagation();
      var same=picker.classList.contains('open') && stickerPane.classList.contains('active');
      setOpen(!same,'sticker');
    });
    picker.addEventListener('click',function(ev){ev.stopPropagation();});
    document.addEventListener('pointerdown',function(ev){
      if(!picker.classList.contains('open')) return;
      if(!picker.contains(ev.target) && !composer.contains(ev.target)) setOpen(false);
    },{passive:true});
    document.addEventListener('keydown',function(ev){if(ev.key==='Escape')setOpen(false);});
    form.addEventListener('submit',function(){
      /* Emoji/text submit closes the tray. Sticker clicks can immediately reopen it. */
      if(!stickerPane.classList.contains('active')) setOpen(false);
    });

    function refreshPack(){
      if(!picker.classList.contains('open')) return;
      requestAnimationFrame(function(){
        picker.scrollTop=Math.min(picker.scrollTop,picker.scrollHeight);
        if(stickerPane.classList.contains('active')) stickerVideos.slice(0,12).forEach(activateStickerVideo);
      });
    }
    window.addEventListener('resize',refreshPack,{passive:true});
    if(window.visualViewport) window.visualViewport.addEventListener('resize',refreshPack,{passive:true});
    document.addEventListener('fullscreenchange',refreshPack);
    document.addEventListener('webkitfullscreenchange',refreshPack);

    var activePanel=document.getElementById('playerChatPanel');
    function syncBackgroundKey(){
      var key=document.documentElement.getAttribute('data-bm-background')||'simple';
      if(activePanel) activePanel.setAttribute('data-room-background',key);
    }
    syncBackgroundKey();
    new MutationObserver(syncBackgroundKey).observe(document.documentElement,{attributes:true,attributeFilter:['data-bm-background']});
    window.addEventListener('bm:watch-party-background',syncBackgroundKey);
  });
})();
