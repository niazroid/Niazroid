(function(){
  'use strict';

  var config = window.BM_WP_PRO_HOST_CONFIG || {};
  var doc = document;
  var root = doc.documentElement;
  var body = doc.body;
  if (!body || !body.classList.contains('watch-party-page')) return;

  var state = {
    room: null,
    members: [],
    role: '',
    selectedTheme: 'default',
    appliedTheme: 'default',
    serverTheme: 'default',
    themeDraftDirty: false,
    lastRoomCode: '',
    serverOffsetMs: 0,
    scheduleTimer: null,
    currentScheduleToken: 0,
    executedTokens: new Set(),
    heartsRunning: false,
    heartFrame: 0,
    hearts: [],
    canvas: null,
    ctx: null,
    lastFrameAt: 0
  };


  var THEMES = {
    default: {label:'پیش‌فرض', mobile:'تم پیش‌فرض'},
    romantic_hearts: {label:'عاشقانه', mobile:'تم عاشقانه'},
    galaxy_nova: {label:'کهکشانی', mobile:'تم کهکشانی'},
    starlight: {label:'ستاره‌ای', mobile:'تم ستاره‌ای'},
    aurora: {label:'شفق قطبی', mobile:'تم شفق قطبی'}
  };

  function normalizeTheme(theme){ return Object.prototype.hasOwnProperty.call(THEMES, theme) ? theme : 'default'; }
  function themeLabel(theme, mobile){ var item=THEMES[normalizeTheme(theme)]||THEMES.default; return mobile?item.mobile:item.label; }

  function $(id){ return doc.getElementById(id); }

  function ready(fn){
    if (doc.readyState === 'loading') doc.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  function roomCode(){
    try {
      var fromUrl = new URL(location.href).searchParams.get('room');
      if (fromUrl) return fromUrl.replace(/[^A-Za-z0-9_-]/g, '');
    } catch (_) {}
    var text = $('roomCodeView') ? $('roomCodeView').textContent : '';
    return String(text || '').replace(/[^A-Za-z0-9_-]/g, '');
  }

  function api(action, payload){
    payload = payload || {};
    var bodyData = new URLSearchParams();
    bodyData.set('csrf_token', String(config.csrf || ''));
    bodyData.set('action', action);
    bodyData.set('room_code', roomCode());
    Object.keys(payload).forEach(function(key){ bodyData.set(key, String(payload[key] == null ? '' : payload[key])); });
    return fetch('/watch_party_api.php?action=' + encodeURIComponent(action), {
      method: 'POST',
      credentials: 'same-origin',
      cache: 'no-store',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
        'X-CSRF-Token': String(config.csrf || '')
      },
      body: bodyData.toString()
    }).then(function(res){
      return res.json().catch(function(){ return {}; }).then(function(json){
        if (!res.ok || !json.success) throw new Error(json.message || json.error || 'درخواست انجام نشد.');
        return json;
      });
    });
  }

  function flash(message, error){
    var stack = $('bmWpProToastStack');
    if (!stack) {
      stack = doc.createElement('div');
      stack.id = 'bmWpProToastStack';
      stack.className = 'bm-wp-pro-toast-stack';
      body.appendChild(stack);
    }
    var item = doc.createElement('div');
    item.className = 'bm-wp-pro-toast' + (error ? ' is-error' : '');
    item.textContent = message;
    stack.appendChild(item);
    requestAnimationFrame(function(){ item.classList.add('show'); });
    setTimeout(function(){
      item.classList.remove('show');
      setTimeout(function(){ item.remove(); }, 220);
    }, 3400);
  }

  function buildRomanticBackground(){
    if ($('bmWpRomanticBg')) return;
    var layer = doc.createElement('div');
    layer.id = 'bmWpRomanticBg';
    layer.className = 'bm-wp-theme-bg';
    layer.setAttribute('aria-hidden', 'true');
    layer.innerHTML = '<div class="bm-wp-theme-wash"></div><div class="bm-wp-star-layer bm-wp-star-layer-a"></div><div class="bm-wp-star-layer bm-wp-star-layer-b"></div><div class="bm-wp-aurora-ribbon bm-wp-aurora-one"></div><div class="bm-wp-aurora-ribbon bm-wp-aurora-two"></div><canvas id="bmWpRomanticCanvas"></canvas><div class="bm-wp-theme-vignette"></div>';
    body.insertBefore(layer, body.firstChild);
    state.canvas = $('bmWpRomanticCanvas');
    state.ctx = state.canvas && state.canvas.getContext ? state.canvas.getContext('2d') : null;
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas, {passive:true});
    doc.addEventListener('visibilitychange', function(){
      if (doc.hidden) stopHearts();
      else if (state.appliedTheme === 'romantic_hearts') startHearts();
    });
  }

  function resizeCanvas(){
    if (!state.canvas || !state.ctx) return;
    var lite = root.classList.contains('wp-lite-device');
    var dpr = lite ? 1 : Math.min(1.5, window.devicePixelRatio || 1);
    var w = Math.max(320, window.innerWidth || 320);
    var h = Math.max(500, window.innerHeight || 500);
    state.canvas.width = Math.round(w * dpr);
    state.canvas.height = Math.round(h * dpr);
    state.canvas.style.width = w + 'px';
    state.canvas.style.height = h + 'px';
    state.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    resetHearts();
  }

  function resetHearts(){
    var lite = root.classList.contains('wp-lite-device');
    var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    var count = reduced ? 0 : (lite ? 7 : ((window.innerWidth || 0) < 700 ? 15 : 28));
    state.hearts = [];
    for (var i=0; i<count; i++) state.hearts.push(makeHeart(true));
  }

  function makeHeart(randomY){
    var w = Math.max(320, window.innerWidth || 320);
    var h = Math.max(500, window.innerHeight || 500);
    return {
      x: Math.random() * w,
      y: randomY ? Math.random() * h : h + 30,
      size: 3 + Math.random() * 8,
      speed: 6 + Math.random() * 15,
      drift: (Math.random() - .5) * 10,
      alpha: .12 + Math.random() * .34,
      phase: Math.random() * Math.PI * 2
    };
  }

  function drawHeart(ctx, x, y, size, alpha){
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(size / 18, size / 18);
    ctx.beginPath();
    ctx.moveTo(0, 5);
    ctx.bezierCurveTo(-11, -4, -18, 7, 0, 20);
    ctx.bezierCurveTo(18, 7, 11, -4, 0, 5);
    ctx.closePath();
    ctx.fillStyle = 'rgba(255,111,157,' + alpha.toFixed(3) + ')';
    ctx.fill();
    ctx.restore();
  }

  function renderHearts(now){
    if (!state.heartsRunning || !state.ctx || state.appliedTheme !== 'romantic_hearts') return;
    var ctx = state.ctx;
    var w = Math.max(320, window.innerWidth || 320);
    var h = Math.max(500, window.innerHeight || 500);
    var dt = Math.min(.05, Math.max(.008, (now - (state.lastFrameAt || now)) / 1000));
    state.lastFrameAt = now;
    ctx.clearRect(0, 0, w, h);
    for (var i=0; i<state.hearts.length; i++) {
      var p = state.hearts[i];
      p.phase += dt * .8;
      p.y -= p.speed * dt;
      p.x += (p.drift + Math.sin(p.phase) * 4) * dt;
      if (p.y < -35 || p.x < -35 || p.x > w + 35) state.hearts[i] = p = makeHeart(false);
      drawHeart(ctx, p.x, p.y, p.size, p.alpha);
    }
    state.heartFrame = requestAnimationFrame(renderHearts);
  }

  function startHearts(){
    var reduced = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (root.classList.contains('wp-lite-device') || reduced) return;
    if (state.heartsRunning || !state.ctx || doc.hidden) return;
    if (!state.hearts.length) resetHearts();
    state.heartsRunning = true;
    state.lastFrameAt = performance.now();
    state.heartFrame = requestAnimationFrame(renderHearts);
  }

  function stopHearts(){
    state.heartsRunning = false;
    if (state.heartFrame) cancelAnimationFrame(state.heartFrame);
    state.heartFrame = 0;
    if (state.ctx && state.canvas) state.ctx.clearRect(0, 0, state.canvas.width, state.canvas.height);
  }

  function applyTheme(theme, preview){
    theme = normalizeTheme(theme);
    state.appliedTheme = theme;
    var bodyClasses={default:'bm-wp-theme-default',romantic_hearts:'bm-wp-theme-romantic',galaxy_nova:'bm-wp-theme-galaxy',starlight:'bm-wp-theme-starlight',aurora:'bm-wp-theme-aurora'};
    Object.keys(bodyClasses).forEach(function(key){ body.classList.toggle(bodyClasses[key], theme===key); });
    var bg = $('bmWpRomanticBg');
    if (bg) {
      bg.className = 'bm-wp-theme-bg is-active theme-' + theme.replace(/_/g,'-');
      if (theme === 'default') bg.classList.remove('is-active');
    }
    if (theme === 'romantic_hearts') startHearts(); else stopHearts();
    var label = $('bmWpNowTheme');
    if (label) label.textContent = themeLabel(theme, false);
    var mobileLabel = $('bmWpMobileTheme');
    if (mobileLabel) mobileLabel.textContent = themeLabel(theme, true);
    if (!preview) state.selectedTheme = theme;
    doc.querySelectorAll('[data-bm-wp-theme]').forEach(function(btn){
      var selected = btn.getAttribute('data-bm-wp-theme') === theme;
      btn.classList.toggle('is-selected', selected);
      btn.setAttribute('aria-pressed', selected ? 'true' : 'false');
    });
  }

  function buildNowPlaying(){
    var side = doc.querySelector('.side-stack');
    if (!side || $('bmWpNowPlaying')) return;
    var card = doc.createElement('section');
    card.id = 'bmWpNowPlaying';
    card.className = 'side-card bm-wp-now-playing';
    card.innerHTML = ''+
      '<div class="bm-wp-now-poster"><img id="bmWpNowPoster" alt="پوستر فیلم در حال پخش" loading="lazy" decoding="async" referrerpolicy="no-referrer"><span class="bm-wp-now-poster-fallback"><img src="/assets/brand/bankmovie-icon-256.webp" alt=""></span><i></i></div>'+
      '<div class="bm-wp-now-copy">'+
        '<span class="bm-wp-now-kicker">NOW PLAYING</span>'+
        '<strong id="bmWpNowTitle">فیلم در حال پخش</strong>'+
        '<div class="bm-wp-now-meta">'+
          '<span><b id="bmWpNowCapacity">۰/۰</b> ظرفیت اتاق</span>'+
          '<span><b id="bmWpNowTheme">پیش‌فرض</b> تم اتاق</span>'+
        '</div>'+
      '</div>';
    side.insertBefore(card, side.firstChild);
    var img = $('bmWpNowPoster');
    if (img) img.addEventListener('error', function(){ card.classList.add('has-no-poster'); });
  }

  function buildMobileMovieHero(){
    var hero = doc.querySelector('.hero');
    if (!hero || $('bmWpMobileMovieHero')) return;
    var card = doc.createElement('div');
    card.id = 'bmWpMobileMovieHero';
    card.className = 'bm-wp-mobile-movie-hero';
    card.innerHTML = ''+
      '<div id="bmWpMobileBackdrop" class="bm-wp-mobile-movie-backdrop" aria-hidden="true"></div>'+
      '<div class="bm-wp-mobile-movie-poster"><img id="bmWpMobilePoster" alt="پوستر فیلم در حال پخش" loading="lazy" decoding="async" referrerpolicy="no-referrer"><span><img src="/assets/brand/bankmovie-icon-256.webp" alt=""></span></div>'+
      '<div class="bm-wp-mobile-movie-copy">'+
        '<small>در حال پخش در اتاق</small>'+
        '<strong id="bmWpMobileTitle">فیلم در حال پخش</strong>'+
        '<div class="bm-wp-mobile-movie-meta">'+
          '<span id="bmWpMobileCapacity">۰/۰ نفر</span>'+
          '<span id="bmWpMobileTheme">تم پیش‌فرض</span>'+
        '</div>'+
      '</div>';
    hero.appendChild(card);
    var img = $('bmWpMobilePoster');
    if (img) img.addEventListener('error', function(){ card.classList.add('has-no-poster'); });
  }

  function buildCountdownOverlay(){
    var player = $('playerWrapper');
    if (!player || $('bmWpSyncCountdown')) return;
    var overlay = doc.createElement('div');
    overlay.id = 'bmWpSyncCountdown';
    overlay.className = 'bm-wp-sync-countdown';
    overlay.innerHTML = '<div class="bm-wp-countdown-card"><span>شروع هماهنگ اتاق</span><strong id="bmWpCountdownNumber">۱۰</strong><small id="bmWpCountdownTarget">از ثانیه ۰</small></div>';
    player.appendChild(overlay);
    overlay.addEventListener('click', function(){
      if (!overlay.classList.contains('needs-tap')) return;
      var video = $('video');
      if (!video) return;
      video.play().then(function(){ overlay.classList.remove('show','needs-tap'); }).catch(function(){});
    });
  }

  function buildHostTools(){
    var tools = doc.querySelector('#roomToolsPanel .tools-body');
    if (!tools || $('bmWpProHostSection')) return;
    var section = doc.createElement('section');
    section.id = 'bmWpProHostSection';
    section.className = 'tool-section bm-wp-pro-host-section';
    section.innerHTML = ''+
      '<div class="bm-wp-pro-head"><span class="bm-wp-pro-icon">★</span><span><h3>حالت میزبان حرفه‌ای</h3><small>تم اتاق و شروع کاملاً هماهنگ برای همه</small></span></div>'+
      '<div class="bm-wp-theme-grid" role="group" aria-label="انتخاب تم اتاق">'+
        '<button type="button" class="bm-wp-theme-card is-selected" data-bm-wp-theme="default" aria-pressed="true"><span class="bm-wp-theme-preview default"></span><strong>پیش‌فرض</strong><small>ظاهر فعلی اتاق</small></button>'+
        '<button type="button" class="bm-wp-theme-card" data-bm-wp-theme="romantic_hearts" aria-pressed="false"><span class="bm-wp-theme-preview romantic"><i>♥</i></span><strong>عاشقانه</strong><small>قلب‌های نرم و پس‌زمینه گرم</small></button>'+
        '<button type="button" class="bm-wp-theme-card" data-bm-wp-theme="galaxy_nova" aria-pressed="false"><span class="bm-wp-theme-preview galaxy"><i>✦</i></span><strong>کهکشانی</strong><small>سحابی بنفش و ستاره‌های عمیق</small></button>'+
        '<button type="button" class="bm-wp-theme-card" data-bm-wp-theme="starlight" aria-pressed="false"><span class="bm-wp-theme-preview starlight"><i>✧</i></span><strong>ستاره‌ای</strong><small>آسمان شب و نور ستاره‌ها</small></button>'+
        '<button type="button" class="bm-wp-theme-card" data-bm-wp-theme="aurora" aria-pressed="false"><span class="bm-wp-theme-preview aurora"><i>≈</i></span><strong>شفق قطبی</strong><small>موج‌های سبز و آبی سینمایی</small></button>'+
      '</div>'+
      '<label class="field">عنوان فیلم در اتاق<input id="bmWpContentTitle" class="input" maxlength="190" placeholder="نام فیلم یا قسمت"></label>'+
      '<label class="field">آدرس پوستر<input id="bmWpPosterUrl" class="input" type="url" inputmode="url" placeholder="https://.../poster.webp یا /posters/...webp"></label>'+
      '<div class="bm-wp-pro-grid">'+
        '<label class="field">شمارش معکوس<input id="bmWpCountdownSeconds" class="input" type="number" min="3" max="60" step="1" value="10"><small>پیش‌فرض ۱۰ ثانیه</small></label>'+
        '<label class="field">شروع از ثانیه<input id="bmWpStartAtSeconds" class="input" type="number" min="0" max="172800" step="1" value="0"><small>مثلاً ۹۰ یعنی 01:30</small></label>'+
      '</div>'+
      '<div class="bm-wp-capacity-row"><span>ظرفیت این اتاق</span><strong id="bmWpToolCapacity">۰/۰ نفر</strong></div>'+
      '<div class="tool-actions bm-wp-pro-actions">'+
        '<button id="bmWpSaveRoomSettings" class="btn" type="button">ذخیره تنظیمات</button>'+
        '<button id="bmWpScheduleStart" class="btn primary" type="button">شروع هماهنگ</button>'+
      '</div>'+
      '<p class="privacy-note">تم و شمارش معکوس برای تمام اعضای اتاق اعمال می‌شود. مرورگر هر مهمان باید یک‌بار با دکمه «آماده‌ام» مجوز پخش صدا را فعال کرده باشد.</p>';
    section.hidden = true;
    tools.appendChild(section);

    section.querySelectorAll('[data-bm-wp-theme]').forEach(function(btn){
      btn.addEventListener('click', function(){
        state.selectedTheme = normalizeTheme(btn.getAttribute('data-bm-wp-theme') || 'default');
        state.themeDraftDirty = true;
        applyTheme(state.selectedTheme, true);
        var saveButton = $('bmWpSaveRoomSettings');
        if (saveButton) saveButton.classList.add('has-unsaved-theme');
      });
    });
    $('bmWpSaveRoomSettings').addEventListener('click', function(){ saveSettings(false); });
    $('bmWpScheduleStart').addEventListener('click', scheduleStart);
  }

  function setHostMode(role){
    state.role = role || '';
    var isHost = state.role === 'host';
    body.classList.toggle('bm-wp-pro-is-host', isHost);
    var section = $('bmWpProHostSection');
    if (section) section.hidden = !isHost;
  }

  function updateNowPlaying(room, members){
    if (!room) return;
    var title = String(room.content_title || '').trim() || 'فیلم در حال پخش';
    var poster = String(room.poster_url || '').trim();
    var titleEl = $('bmWpNowTitle');
    if (titleEl) titleEl.textContent = title;
    var card = $('bmWpNowPlaying');
    var img = $('bmWpNowPoster');
    if (card && img) {
      card.classList.toggle('has-no-poster', !poster);
      if (poster && img.getAttribute('src') !== poster) img.setAttribute('src', poster);
      if (!poster) img.removeAttribute('src');
    }
    var current = Array.isArray(members) ? members.length : 0;
    var max = Number(room.max_members || 0);
    if ($('bmWpNowCapacity')) $('bmWpNowCapacity').textContent = current + '/' + max;
    if ($('bmWpToolCapacity')) $('bmWpToolCapacity').textContent = current + '/' + max + ' نفر';
    if ($('bmWpMobileTitle')) $('bmWpMobileTitle').textContent = title;
    if ($('bmWpMobileCapacity')) $('bmWpMobileCapacity').textContent = current + '/' + max + ' نفر';
    if ($('bmWpMobileTheme')) $('bmWpMobileTheme').textContent = themeLabel(state.appliedTheme, true);
    var mobileCard = $('bmWpMobileMovieHero');
    var mobileImg = $('bmWpMobilePoster');
    var mobileBg = $('bmWpMobileBackdrop');
    if (mobileCard && mobileImg) {
      mobileCard.classList.toggle('has-no-poster', !poster);
      if (poster && mobileImg.getAttribute('src') !== poster) mobileImg.setAttribute('src', poster);
      if (!poster) mobileImg.removeAttribute('src');
      if (mobileBg) mobileBg.style.backgroundImage = poster ? 'url("' + poster.replace(/"/g, '%22') + '")' : '';
    }
    if ($('bmWpContentTitle') && doc.activeElement !== $('bmWpContentTitle')) $('bmWpContentTitle').value = title === 'فیلم در حال پخش' ? '' : title;
    if ($('bmWpPosterUrl') && doc.activeElement !== $('bmWpPosterUrl')) $('bmWpPosterUrl').value = poster;
  }

  function inferRole(data){
    var members = Array.isArray(data.members) ? data.members : [];
    var currentId = Number(config.currentUserId || 0);
    if (currentId > 0) {
      var me = members.find(function(member){ return Number(member.user_id) === currentId; });
      if (me && me.member_role) return String(me.member_role);
    }
    var badge = $('roleBadge');
    return badge && /میزبان/.test(badge.textContent || '') ? 'host' : 'guest';
  }

  function syncToolValues(room){
    if (!room) return;
    if ($('bmWpCountdownSeconds') && doc.activeElement !== $('bmWpCountdownSeconds')) $('bmWpCountdownSeconds').value = String(Number(room.countdown_seconds || 10));
    if ($('bmWpStartAtSeconds') && doc.activeElement !== $('bmWpStartAtSeconds')) $('bmWpStartAtSeconds').value = String(Math.max(0, Math.round(Number(room.start_at_seconds || 0))));
  }

  function handlePoll(data){
    if (!data || !data.room) return;
    state.room = data.room;
    state.members = Array.isArray(data.members) ? data.members : [];
    state.serverOffsetMs = Number(data.server_time_ms || Date.now()) - Date.now();
    setHostMode(inferRole(data));
    updateNowPlaying(state.room, state.members);
    syncToolValues(state.room);
    var code = String(state.room.room_code || roomCode() || '');
    if (code !== state.lastRoomCode) {
      state.lastRoomCode = code;
      state.themeDraftDirty = false;
    }
    var theme = normalizeTheme(String(state.room.theme_key || 'default'));
    state.serverTheme = theme;
    var keepHostDraft = state.role === 'host' && state.themeDraftDirty;
    if (!keepHostDraft) {
      if (theme !== state.appliedTheme) applyTheme(theme, false);
      state.selectedTheme = theme;
    }
    handleSchedule(state.room, Number(data.server_time_ms || Date.now()));
  }

  function getSettingsPayload(){
    var countdown = Math.max(3, Math.min(60, Number($('bmWpCountdownSeconds') && $('bmWpCountdownSeconds').value || 10) || 10));
    var startAt = Math.max(0, Math.min(172800, Number($('bmWpStartAtSeconds') && $('bmWpStartAtSeconds').value || 0) || 0));
    return {
      theme_key: normalizeTheme(state.selectedTheme),
      countdown_seconds: Math.round(countdown),
      start_at_seconds: startAt,
      content_title: String($('bmWpContentTitle') && $('bmWpContentTitle').value || '').trim(),
      poster_url: String($('bmWpPosterUrl') && $('bmWpPosterUrl').value || '').trim()
    };
  }

  function saveSettings(silent){
    if (state.role !== 'host') return Promise.reject(new Error('تنظیمات فقط برای میزبان فعال است.'));
    var button = $('bmWpSaveRoomSettings');
    if (button) button.disabled = true;
    return api('room_settings', getSettingsPayload()).then(function(res){
      var settings = res.settings || {};
      state.room = Object.assign({}, state.room || {}, settings);
      state.themeDraftDirty = false;
      state.serverTheme = normalizeTheme(String(settings.theme_key || 'default'));
      var saveButton = $('bmWpSaveRoomSettings');
      if (saveButton) saveButton.classList.remove('has-unsaved-theme');
      applyTheme(settings.theme_key || 'default', false);
      updateNowPlaying(state.room, state.members);
      syncToolValues(state.room);
      if (!silent) flash('تنظیمات اتاق برای همه ذخیره شد.');
      return res;
    }).catch(function(error){
      if (!silent) flash(error.message || 'ذخیره انجام نشد.', true);
      throw error;
    }).finally(function(){ if (button) button.disabled = false; });
  }

  function scheduleStart(){
    if (state.role !== 'host') { flash('شروع هماهنگ فقط در اختیار میزبان است.', true); return; }
    var button = $('bmWpScheduleStart');
    if (button) button.disabled = true;
    var video = $('video');
    if (video && !video.paused) video.pause();
    saveSettings(true).then(function(){
      var payload = getSettingsPayload();
      return api('schedule_start', {
        countdown_seconds: payload.countdown_seconds,
        start_at_seconds: payload.start_at_seconds
      });
    }).then(function(res){
      var schedule = res.schedule || {};
      state.serverOffsetMs = Number(schedule.server_time_ms || Date.now()) - Date.now();
      handleSchedule({
        scheduled_start_at_ms: schedule.scheduled_start_at_ms,
        scheduled_start_token: schedule.scheduled_start_token,
        start_at_seconds: schedule.start_at_seconds,
        countdown_seconds: schedule.countdown_seconds
      }, Number(schedule.server_time_ms || Date.now()));
      flash('شروع هماهنگ برای تمام اعضا زمان‌بندی شد.');
    }).catch(function(error){
      flash(error.message || 'شروع هماهنگ انجام نشد.', true);
    }).finally(function(){ if (button) button.disabled = false; });
  }

  function handleSchedule(room, serverNowMs){
    var token = Number(room.scheduled_start_token || 0);
    var executeAt = Number(room.scheduled_start_at_ms || 0);
    var target = Math.max(0, Number(room.start_at_seconds || 0));
    if (!token || !executeAt || state.executedTokens.has(token)) return;
    var age = Number(serverNowMs || Date.now()) - executeAt;
    if (age > 15000) {
      state.executedTokens.add(token);
      return;
    }
    if (token !== state.currentScheduleToken) {
      state.currentScheduleToken = token;
      beginCountdown(token, executeAt, target);
    }
  }

  function beginCountdown(token, executeAt, target){
    clearInterval(state.scheduleTimer);
    var overlay = $('bmWpSyncCountdown');
    var number = $('bmWpCountdownNumber');
    var targetLabel = $('bmWpCountdownTarget');
    if (!overlay || !number) return;
    overlay.classList.remove('needs-tap');
    overlay.classList.add('show');
    targetLabel.textContent = 'شروع از ثانیه ' + Math.round(target);

    function tick(){
      var serverNow = Date.now() + state.serverOffsetMs;
      var remainingMs = executeAt - serverNow;
      if (remainingMs > 0) {
        number.textContent = String(Math.max(1, Math.ceil(remainingMs / 1000)));
        return;
      }
      clearInterval(state.scheduleTimer);
      state.scheduleTimer = null;
      executeScheduledStart(token, target);
    }
    tick();
    state.scheduleTimer = setInterval(tick, 100);
  }

  function seekVideo(video, target){
    try {
      if (video.readyState >= 1) video.currentTime = target;
      else video.addEventListener('loadedmetadata', function(){ try { video.currentTime = target; } catch (_) {} }, {once:true});
    } catch (_) {}
  }

  function executeScheduledStart(token, target){
    if (state.executedTokens.has(token)) return;
    state.executedTokens.add(token);
    var overlay = $('bmWpSyncCountdown');
    var number = $('bmWpCountdownNumber');
    var targetLabel = $('bmWpCountdownTarget');
    var video = $('video');
    if (number) number.textContent = 'شروع';
    if (targetLabel) targetLabel.textContent = 'پخش هماهنگ فعال شد';
    if (!video || !video.src) {
      if (targetLabel) targetLabel.textContent = 'منبع ویدئو هنوز آماده نیست';
      setTimeout(function(){ if (overlay) overlay.classList.remove('show'); }, 1800);
      return;
    }
    seekVideo(video, target);
    var playPromise;
    try { playPromise = video.play(); } catch (error) { playPromise = Promise.reject(error); }
    Promise.resolve(playPromise).then(function(){
      setTimeout(function(){ if (overlay) overlay.classList.remove('show'); }, 900);
    }).catch(function(){
      if (number) number.textContent = '▶';
      if (targetLabel) targetLabel.textContent = 'برای شروع پخش لمس کنید';
      if (overlay) overlay.classList.add('needs-tap');
    });
  }

  function init(){
    buildRomanticBackground();
    buildNowPlaying();
    buildMobileMovieHero();
    buildCountdownOverlay();
    buildHostTools();
    applyTheme('default', false);
    window.addEventListener('bm:watch-party-poll', function(event){ handlePoll(event.detail || {}); });
  }

  ready(init);
})();
