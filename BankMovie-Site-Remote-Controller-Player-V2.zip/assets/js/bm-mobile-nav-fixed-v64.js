/* BankMovie V64 — one mobile footer-nav behavior everywhere.
   V49 still decides performance-lite vs full effects. V64 only forces the NAV itself
   to the proven static tier on every phone, including strong devices. */
(function(d){
  'use strict';
  try{
    var root=d.documentElement;
    var mobile=!!(window.matchMedia&&window.matchMedia('(max-width: 991px)').matches);
    if(!mobile) return;
    root.classList.remove('bm-nav-dynamic');
    root.classList.add('bm-nav-static','bm-nav-fixed-v64');
    root.dataset.bmNavTier='static';
    if(window.BM_ADAPTIVE_MOBILE_V49){
      window.BM_ADAPTIVE_MOBILE_V49.nav='static';
      window.BM_ADAPTIVE_MOBILE_V49.navForcedStatic=true;
    }
  }catch(e){}
})(document);
