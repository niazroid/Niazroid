(function(){
  'use strict';

  var modal = document.getElementById('filterModal');
  var openButton = document.getElementById('openFilterModalBtn');
  var closeButton = document.getElementById('closeFilterModalBtn');
  var shell = modal ? modal.querySelector('.filter-modal-shell') : null;
  var form = document.getElementById('filterForm');
  var draftChips = document.getElementById('filterDraftChips');
  var countNodes = document.querySelectorAll('[data-filter-count]');
  var resetDraftButton = document.getElementById('resetFilterDraftBtn');
  var submitButton = form ? form.querySelector('.apply-filters-btn') : null;
  var lastFocused = null;

  if(!modal || !openButton || !form) return;

  var firstArchive = form.querySelector('[name="archive"]');
  var allArchive = form.querySelector('[name="archive"][value="all"]');
  var defaults = {
    archive: allArchive ? 'all' : (firstArchive ? String(firstArchive.value || 'all') : 'all'),
    q:'', genre:'', country:'', actor:'', director:'', from_year:'', to_year:'',
    rating:'', dubbed:'', subtitle:'', suggest:'', type:'all', sort:'newest'
  };

  var names = Object.keys(defaults).filter(function(name){ return !!form.elements[name]; });
  var fa = document.documentElement.lang === 'fa' || document.documentElement.dir === 'rtl';

  function fieldList(name){
    return Array.prototype.slice.call(form.querySelectorAll('[name="' + name + '"]'));
  }

  function valueOf(name){
    var fields = fieldList(name);
    if(!fields.length) return '';
    var first = fields[0];
    if(first.type === 'radio'){
      var checkedRadio = fields.find(function(field){ return field.checked; });
      return checkedRadio ? String(checkedRadio.value || '') : '';
    }
    if(first.type === 'checkbox'){
      var checkedBox = fields.find(function(field){ return field.checked; });
      return checkedBox ? String(checkedBox.value || '1') : '';
    }
    return String(first.value || '');
  }

  function fieldOf(name){
    var fields = fieldList(name);
    if(!fields.length) return null;
    return fields.find(function(field){ return field.checked; }) || fields[0];
  }

  function labelOf(name){
    var value = valueOf(name);
    var field = fieldOf(name);
    if(!field) return value;
    if(field.type === 'radio' || field.type === 'checkbox'){
      var label = field.closest('label');
      return label ? String(label.getAttribute('data-filter-label') || label.textContent || '').trim() : value;
    }
    if(field.tagName === 'SELECT'){
      var option = field.options[field.selectedIndex];
      return option ? String(option.textContent || '').trim() : value;
    }
    var fieldLabel = form.querySelector('label[for="' + field.id + '"]');
    return fieldLabel && value ? String(fieldLabel.textContent || '').trim() + ': ' + value : value;
  }

  function isActive(name){
    return valueOf(name) !== String(defaults[name] == null ? '' : defaults[name]);
  }

  function activeNames(){
    return names.filter(isActive);
  }

  function setValue(name,value){
    var fields = fieldList(name);
    if(!fields.length) return;
    var first = fields[0];
    if(first.type === 'radio'){
      var found = false;
      fields.forEach(function(field){
        field.checked = String(field.value) === String(value);
        if(field.checked) found = true;
      });
      if(!found && fields[0]) fields[0].checked = true;
      return;
    }
    if(first.type === 'checkbox'){
      fields.forEach(function(field){ field.checked = String(value) !== '' && String(field.value || '1') === String(value); });
      return;
    }
    first.value = value;
  }

  function updatePresetStates(){
    document.querySelectorAll('.filter-preset-btn[data-preset-name]').forEach(function(button){
      var name = button.getAttribute('data-preset-name');
      var value = button.getAttribute('data-preset-value');
      button.classList.toggle('is-active', valueOf(name) === value && value !== String(defaults[name] || ''));
    });
  }

  function updateSourceSpecificFields(){
    var archive = valueOf('archive');
    document.querySelectorAll('[data-archive-only]').forEach(function(node){
      var required = String(node.getAttribute('data-archive-only') || '');
      var available = archive === 'all' || archive === required;
      node.hidden = !available;
      node.setAttribute('aria-hidden', available ? 'false' : 'true');
      if(!available && node.matches('label')){
        var field = node.querySelector('input,select,textarea');
        if(field && field.name) setValue(field.name,defaults[field.name] || '');
      }
    });
  }

  function updateGenreOptions(){
    var archive = valueOf('archive');
    var genre = form.elements.genre;
    if(!genre || genre.tagName !== 'SELECT') return;
    Array.prototype.forEach.call(genre.options,function(option,index){
      if(index === 0) return;
      var sources = String(option.getAttribute('data-archives') || '').split(',');
      var visible = archive === 'all' || sources.indexOf(archive) !== -1;
      option.hidden = !visible;
      option.disabled = !visible;
    });
    if(genre.selectedOptions.length && genre.selectedOptions[0].disabled) genre.value = '';
  }

  function updateSummary(){
    updateSourceSpecificFields();
    updateGenreOptions();
    var active = activeNames();
    countNodes.forEach(function(node){
      node.textContent = String(active.length);
      node.hidden = active.length === 0;
    });

    if(draftChips){
      if(!active.length){
        draftChips.innerHTML = '<span class="filter-draft-empty">' + (fa ? 'هنوز فیلتری انتخاب نشده' : 'No filters selected yet') + '</span>';
      }else{
        draftChips.innerHTML = active.map(function(name){
          return '<button type="button" class="filter-draft-chip" data-remove-filter="' + escapeHtml(name) + '">' + escapeHtml(labelOf(name)) + '</button>';
        }).join('');
      }
    }
    updatePresetStates();
  }

  function escapeHtml(value){
    return String(value == null ? '' : value).replace(/[&<>"']/g,function(ch){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[ch];
    });
  }

  function focusables(){
    return Array.prototype.slice.call(modal.querySelectorAll('button:not([disabled]),a[href],input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])')).filter(function(el){
      return el.offsetParent !== null;
    });
  }

  function openModal(){
    lastFocused = document.activeElement;
    if(modal.parentElement !== document.body) document.body.appendChild(modal);
    modal.classList.add('active');
    modal.setAttribute('aria-hidden','false');
    openButton.setAttribute('aria-expanded','true');
    document.body.classList.add('filter-modal-open');
    window.setTimeout(function(){
      var first = form.querySelector('input[type="text"],select,input[type="radio"]');
      if(first) first.focus({preventScroll:true});
    },180);
  }

  function closeModal(){
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden','true');
    openButton.setAttribute('aria-expanded','false');
    document.body.classList.remove('filter-modal-open');
    if(lastFocused && typeof lastFocused.focus === 'function') lastFocused.focus({preventScroll:true});
  }

  openButton.addEventListener('click',openModal);
  if(closeButton) closeButton.addEventListener('click',closeModal);
  modal.addEventListener('click',function(event){ if(event.target === modal) closeModal(); });
  if(shell) shell.addEventListener('click',function(event){ event.stopPropagation(); });

  document.addEventListener('keydown',function(event){
    if(!modal.classList.contains('active')) return;
    if(event.key === 'Escape'){
      event.preventDefault();
      closeModal();
      return;
    }
    if(event.key !== 'Tab') return;
    var items = focusables();
    if(!items.length) return;
    var first = items[0];
    var last = items[items.length - 1];
    if(event.shiftKey && document.activeElement === first){ event.preventDefault(); last.focus(); }
    else if(!event.shiftKey && document.activeElement === last){ event.preventDefault(); first.focus(); }
  });

  form.addEventListener('input',updateSummary);
  form.addEventListener('change',updateSummary);

  document.querySelectorAll('.filter-preset-btn[data-preset-name]').forEach(function(button){
    button.addEventListener('click',function(){
      var name = button.getAttribute('data-preset-name');
      var value = button.getAttribute('data-preset-value');
      setValue(name,valueOf(name) === value ? defaults[name] : value);
      updateSummary();
      var target = fieldOf(name);
      if(target) target.dispatchEvent(new Event('change',{bubbles:true}));
    });
  });

  if(draftChips){
    draftChips.addEventListener('click',function(event){
      var chip = event.target.closest('[data-remove-filter]');
      if(!chip) return;
      var name = chip.getAttribute('data-remove-filter');
      setValue(name,defaults[name]);
      updateSummary();
    });
  }

  if(resetDraftButton){
    resetDraftButton.addEventListener('click',function(){
      names.forEach(function(name){ setValue(name,defaults[name]); });
      updateSummary();
    });
  }

  form.addEventListener('submit',function(){
    Array.prototype.forEach.call(form.querySelectorAll('input,select,textarea'),function(field){
      if((field.type === 'checkbox' || field.type === 'radio') && !field.checked) return;
      if(String(field.value || '') === '') field.disabled = true;
    });
    if(submitButton){
      submitButton.classList.add('is-loading');
      submitButton.setAttribute('aria-busy','true');
      var text = submitButton.querySelector('[data-submit-label]');
      if(text) text.textContent = fa ? 'در حال اعمال فیلترها…' : 'Applying filters…';
    }
  });

  updateSummary();
})();
