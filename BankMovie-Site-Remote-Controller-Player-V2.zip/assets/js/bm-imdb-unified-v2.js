(function(){
  'use strict';

  function hasImdb(el){
    if(!el) return false;
    if(el.querySelector('img[alt*="IMDb" i], img[src*="imdb" i], .bm-imdb-logo, .bm-imdb-pill, .imdb-logo')) return true;
    return /\bIMDb\b/i.test(el.textContent || '');
  }

  function fixMovieDuplicate(){
    document.querySelectorAll('.info-col').forEach(function(info){
      var top = info.querySelector('.movie-rating-section');
      var detail = info.querySelector('.movie-info-block [data-meta="imdb"], .movie-info-block .bm-meta-imdb');
      if(!detail) return;
      /* Only hide the details duplicate when the rating row already contains IMDb. */
      if(hasImdb(top)) detail.style.setProperty('display','none','important');
      else detail.style.removeProperty('display');
    });
  }

  function fixHeroScores(root){
    (root || document).querySelectorAll('.imdb-rating-badge .rating-score').forEach(function(score){
      score.querySelectorAll('small').forEach(function(x){x.style.setProperty('display','none','important');});
      Array.prototype.forEach.call(score.childNodes,function(n){
        if(n.nodeType === Node.TEXT_NODE && /\/\s*10\b/.test(n.nodeValue || '')){
          n.nodeValue = (n.nodeValue || '').replace(/\s*\/\s*10\b/g,'').trim();
        }
      });
      /* Fallback for plain-text score nodes such as "7/10". */
      if(score.children.length === 0 && /\/\s*10\b/.test(score.textContent || '')){
        score.textContent = (score.textContent || '').replace(/\s*\/\s*10\b/g,'').trim();
      }
    });
    (root || document).querySelectorAll('.imdb-rating-badge .rating-votes').forEach(function(v){
      v.style.setProperty('display','none','important');
    });
  }

  function fixRelatedBadges(){
    /* Archive 1 already has a poster wrapper, CSS handles it. */
    document.querySelectorAll('.related-card').forEach(function(card){
      var badge = card.querySelector(':scope > .bm-related-imdb-badge');
      var poster = card.querySelector(':scope > .related-poster');
      if(!badge || !poster || poster.parentElement.classList.contains('bm-related-poster-wrap')) return;
      var wrap=document.createElement('span');
      wrap.className='bm-related-poster-wrap';
      poster.parentNode.insertBefore(wrap,poster);
      wrap.appendChild(poster);
      wrap.appendChild(badge);
    });
  }

  function run(){fixMovieDuplicate();fixHeroScores(document);fixRelatedBadges();}
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded',run,{once:true}); else run();

  /* Slider/cards can be rendered or swapped dynamically. Keep normalization lightweight. */
  var scheduled=false;
  var observer=new MutationObserver(function(muts){
    if(scheduled) return;
    var relevant=muts.some(function(m){
      return Array.prototype.some.call(m.addedNodes || [],function(n){
        return n.nodeType===1 && (n.matches?.('.hero-slide,.imdb-rating-badge,.related-card') || n.querySelector?.('.imdb-rating-badge,.related-card'));
      });
    });
    if(!relevant) return;
    scheduled=true;
    requestAnimationFrame(function(){scheduled=false;fixHeroScores(document);fixRelatedBadges();});
  });
  if(document.documentElement) observer.observe(document.documentElement,{childList:true,subtree:true});
})();


/* ===== v2.2 / UI fix v1.3 ===== */
(function(){
  'use strict';
  function isImdbNode(el){
    if(!el || el.nodeType!==1) return false;
    return !!el.matches?.('.bm-imdb-pill,.bm-meta-imdb,.imdb-rating-badge,[data-meta="imdb"]') ||
      !!el.querySelector?.('.bm-imdb-pill,.bm-imdb-logo,img[alt*="IMDb" i],img[src*="imdb" i]') ||
      /\bIMDb\b/i.test(el.textContent || '');
  }
  function hardDedupMovieImdb(){
    document.querySelectorAll('.info-col').forEach(function(info){
      var row=info.querySelector('.movie-rating-section');
      if(row){
        var imdbKids=Array.from(row.children).filter(isImdbNode);
        if(imdbKids.length>1){
          var preferred=imdbKids.find(function(x){return x.classList.contains('bm-imdb-pill') || x.querySelector('.bm-imdb-pill');}) || imdbKids[0];
          imdbKids.forEach(function(x){if(x!==preferred)x.style.setProperty('display','none','important');});
        }
        if(Array.from(row.children).some(isImdbNode)){
          info.querySelectorAll('.movie-info-block .bm-meta-imdb,.movie-info-block [data-meta="imdb"]').forEach(function(x){
            x.style.setProperty('display','none','important');
          });
        }
      }
    });
  }
  function retireLegacyArchive2Donate(){
    if(document.body?.dataset?.bmArchive!=='archive2') return;
    var btn=document.getElementById('playerDonateSideBtn');
    var actions=btn?.parentElement || null;
    if(btn) btn.remove();
    var modal=document.getElementById('donateModal');
    if(modal) modal.remove();
    if(actions && !actions.querySelector('button,a')) actions.remove();
  }
  function v22run(){hardDedupMovieImdb();retireLegacyArchive2Donate();}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',v22run,{once:true}); else v22run();
})();


/* ===== v2.3 / Archive hero IMDb hard override =====
   Cinematic movie CSS loads after the shared IMDb stylesheet and used to force
   archive rating-row children back to transparent. Inline !important values
   here intentionally win that legacy rule without touching movie.php. */
(function(){
  'use strict';
  function forceArchiveHeroImdb(){
    var body=document.body;
    if(!body) return;
    var arc=body.dataset ? body.dataset.bmArchive : '';
    if(['archive1','archive3','archive4'].indexOf(arc)===-1) return;

    document.querySelectorAll('.info-col .movie-rating-section > .bm-imdb-pill').forEach(function(pill){
      pill.style.setProperty('display','inline-flex','important');
      pill.style.setProperty('align-items','center','important');
      pill.style.setProperty('justify-content','center','important');
      pill.style.setProperty('gap','7px','important');
      pill.style.setProperty('min-height','34px','important');
      pill.style.setProperty('padding','6px 11px','important');
      pill.style.setProperty('background','#f5c518','important');
      pill.style.setProperty('color','#070707','important');
      pill.style.setProperty('border','1px solid rgba(0,0,0,.12)','important');
      pill.style.setProperty('border-radius','11px','important');
      pill.style.setProperty('box-shadow','0 8px 20px rgba(0,0,0,.24)','important');
      pill.style.setProperty('font-family','Arial,Helvetica,sans-serif','important');
      pill.style.setProperty('font-weight','950','important');

      var score=pill.querySelector('.bm-imdb-score');
      if(score){
        score.style.setProperty('color','#070707','important');
        score.style.setProperty('font-size','14px','important');
        score.style.setProperty('font-weight','950','important');
        score.style.setProperty('line-height','1','important');
      }
      var logo=pill.querySelector('img');
      if(logo){
        logo.style.setProperty('width','34px','important');
        logo.style.setProperty('height','17px','important');
        logo.style.setProperty('object-fit','contain','important');
        logo.style.setProperty('display','block','important');
      }
    });

    /* External archives should have exactly one IMDb: the hero pill. */
    document.querySelectorAll('.info-col .movie-info-block .bm-meta-imdb, .info-col .movie-info-block [data-meta="imdb"]').forEach(function(el){
      el.style.setProperty('display','none','important');
    });
  }

  function boot(){
    forceArchiveHeroImdb();
    requestAnimationFrame(forceArchiveHeroImdb);
    setTimeout(forceArchiveHeroImdb,120);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true});
  else boot();
})();
