(function(){
  'use strict';
  var root=document.documentElement;
  var isWatchParty=document.body&&document.body.classList.contains('watch-party-page');
  if(!isWatchParty)return;

  function enableLite(reason,persist){
    if(root.classList.contains('wp-lite-device'))return;
    root.classList.add('wp-lite-device','bm-low-power');
    root.setAttribute('data-wp-render-mode','lite');
    if(window.__BM_WP_RENDER_TIER__)window.__BM_WP_RENDER_TIER__.lite=true;
    if(persist){try{localStorage.setItem('bm_wp_render_safe_v1','1');}catch(e){}}
    try{console.info('[BankMovie Watch Party] compatible render mode:',reason||'runtime');}catch(e){}
  }

  var tier=window.__BM_WP_RENDER_TIER__||{};
  var mobile=!!tier.mobile||!!(window.matchMedia&&matchMedia('(max-width:900px),(pointer:coarse)').matches);
  var android=!!tier.android||/Android/i.test(navigator.userAgent||'');

  if(root.classList.contains('wp-lite-device')){
    var video=document.getElementById('video');
    if(video){video.preload='metadata';video.setAttribute('preload','metadata');}
  }

  /* Runtime fallback: some Android builds hide deviceMemory/CPU data. A long
     frame gap immediately after a touch is the observable symptom of the
     compositor dropping the page surface. Switch once and remember it. */
  if(mobile&&android&&!root.classList.contains('wp-lite-device')){
    var lastFrame=performance.now();
    var lastTouch=0;
    var armed=true;
    function frame(now){
      var gap=now-lastFrame;
      if(armed&&lastTouch&&now-lastTouch<1800&&gap>420){
        armed=false;
        enableLite('touch-frame-stall',true);
      }
      lastFrame=now;
      requestAnimationFrame(frame);
    }
    document.addEventListener('pointerdown',function(){lastTouch=performance.now();},{passive:true,capture:true});
    requestAnimationFrame(frame);
  }

  /* In lite mode keep the video layer allocation modest until playback starts. */
  document.addEventListener('play',function(e){
    if(e.target&&e.target.id==='video'&&root.classList.contains('wp-lite-device')){
      e.target.preload='auto';
    }
  },true);
})();
