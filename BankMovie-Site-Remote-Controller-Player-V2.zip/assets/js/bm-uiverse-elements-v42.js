/* BankMovie V42 — safe runtime enhancer for sound, rating and bookmark controls. */
(function(){
  'use strict';

  function syncSoundButton(btn, slider, media){
    if(!btn) return;
    var muted=false;
    if(media) muted=!!media.muted || Number(media.volume||0)===0;
    if(slider && Number(slider.value||0)===0) muted=true;
    btn.classList.toggle('is-muted',muted);
    btn.setAttribute('aria-pressed',muted?'true':'false');
    btn.setAttribute('title',muted?'وصل کردن صدا':'قطع کردن صدا');
  }

  function bindSound(btnId,sliderId,mediaId){
    var btn=document.getElementById(btnId);
    if(!btn) return;
    var slider=document.getElementById(sliderId);
    var media=document.getElementById(mediaId);
    var sync=function(){syncSoundButton(btn,slider,media);};
    btn.addEventListener('click',function(){setTimeout(sync,0);});
    slider&&slider.addEventListener('input',function(){setTimeout(sync,0);});
    media&&media.addEventListener('volumechange',sync);
    sync();
  }

  function enhanceBookmark(btn){
    if(!btn || btn.dataset.bmBookmarkV42==='1') return;
    btn.dataset.bmBookmarkV42='1';
    btn.classList.add('bm-bookmark-btn');
    btn.setAttribute('title','افزودن به علاقه‌مندی‌ها');
    btn.innerHTML='<span class="bm-bookmark-icon" aria-hidden="true"><svg viewBox="0 0 384 512"><path d="M0 48V487.7C0 501.1 10.9 512 24.3 512c5 0 9.9-1.5 14-4.4L192 400l153.7 107.6c4.1 2.9 9 4.4 14 4.4 13.4 0 24.3-10.9 24.3-24.3V48c0-26.5-21.5-48-48-48H48C21.5 0 0 21.5 0 48Z"/></svg></span><span class="bm-bookmark-text" data-add-label="نشان کردن" data-active-label="نشان شده"></span>';
  }

  function enhanceStars(){
    document.querySelectorAll('#starRating .star-input').forEach(function(star){
      star.setAttribute('role','button');
      star.setAttribute('tabindex','0');
      star.setAttribute('aria-label',(star.dataset.value||'')+' ستاره');
      if(star.dataset.bmKeyV42==='1') return;
      star.dataset.bmKeyV42='1';
      star.addEventListener('keydown',function(e){
        if(e.key==='Enter'||e.key===' '){e.preventDefault();star.dispatchEvent(new MouseEvent('click',{bubbles:true}));}
      });
    });
  }

  function boot(){
    bindSound('volumeBtn','volumeSlider','videoPlayer');
    bindSound('arc1VolBtn','arc1VolSlider','arc1VideoEl');
    bindSound('partyVolumeBtn','partyVolume','partyVideo');
    /* Fallback to the Watch Party video selector if its id changes. */
    var pbtn=document.getElementById('partyVolumeBtn');
    if(pbtn){
      var pslider=document.getElementById('partyVolume');
      var pvideo=document.querySelector('#playerWrapper video,.player-wrapper video');
      if(pvideo){
        var psync=function(){syncSoundButton(pbtn,pslider,pvideo);};
        pbtn.addEventListener('click',function(){setTimeout(psync,0);});
        pslider&&pslider.addEventListener('input',function(){setTimeout(psync,0);});
        pvideo.addEventListener('volumechange',psync); psync();
      }
    }
    enhanceBookmark(document.getElementById('watchlistBtn'));
    enhanceBookmark(document.getElementById('arc1WlBtn'));
    enhanceStars();
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',boot,{once:true}); else boot();
  window.addEventListener('load',function(){setTimeout(boot,40);},{once:true});
})();
