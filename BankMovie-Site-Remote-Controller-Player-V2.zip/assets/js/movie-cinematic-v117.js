(function(){
  'use strict';
  var body=document.body;
  if(!body || !body.classList.contains('bm-movie-template-cinematic')) return;
  if(!window.matchMedia || !window.matchMedia('(min-width:1025px)').matches) return;
  var nav=document.querySelector('.bm-cinematic-tabs');
  if(!nav) return;
  var links=Array.prototype.slice.call(nav.querySelectorAll('a[href^="#"]'));
  links.forEach(function(link){
    link.addEventListener('click',function(ev){
      var target=document.querySelector(link.getAttribute('href'));
      if(!target) return;
      ev.preventDefault();
      links.forEach(function(x){x.classList.remove('is-active');});
      link.classList.add('is-active');
      target.scrollIntoView({behavior:'smooth',block:'start'});
    });
  });
  if('IntersectionObserver' in window){
    var map=[];
    links.forEach(function(link){
      var el=document.querySelector(link.getAttribute('href'));
      if(el) map.push({link:link,el:el});
    });
    var io=new IntersectionObserver(function(entries){
      var visible=entries.filter(function(e){return e.isIntersecting;}).sort(function(a,b){return b.intersectionRatio-a.intersectionRatio;})[0];
      if(!visible) return;
      var item=map.find(function(x){return x.el===visible.target;});
      if(!item) return;
      links.forEach(function(x){x.classList.remove('is-active');});
      item.link.classList.add('is-active');
    },{rootMargin:'-120px 0px -55% 0px',threshold:[0.05,.2,.5]});
    map.forEach(function(x){io.observe(x.el);});
  }
})();
