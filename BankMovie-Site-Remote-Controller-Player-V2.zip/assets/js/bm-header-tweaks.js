(function(){
  'use strict';

  function all(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function normalizeInternalRoutes(){
    var cleanRoutes={
      'index.php':'/','profile.php':'/profile','player.php':'/player','collections.php':'/collections',
      'categories.php':'/categories','genres.php':'/genres','actors.php':'/actors','search.php':'/search',
      'login.php':'/login','register.php':'/register','logout.php':'/logout','request.php':'/request',
      'view_all.php':'/view_all','top_rated_by_users.php':'/top_rated_by_users','download_app.php':'/download_app',
      'team.php':'/team','app.php':'/application','vip.php':'/vip','admin.php':'/admin.php','movie.php':'/movie.php'
    };
    all('a[href]').forEach(function(link){
      var raw=(link.getAttribute('href')||'').trim();
      if(!raw || raw.charAt(0)==='/' || raw.charAt(0)==='#' || raw.charAt(0)==='?' || /^(?:https?:|mailto:|tel:|javascript:|data:)/i.test(raw)) return;
      var match=raw.match(/^([a-z0-9_]+\.php)([?#].*)?$/i);
      if(!match) return;
      var route=cleanRoutes[match[1].toLowerCase()];
      if(!route) return;
      link.setAttribute('href',route+(match[2]||''));
    });
  }

  function cleanHeader(){
    var header = document.getElementById('siteHeader');
    if(!header) return;

    header.classList.remove('header-solid','header-glass','bm-smart-header','bm-header-fixed-top','bm-header-hidden','is-hidden','hide','hidden');

    [header, header.querySelector('.header-inner')].forEach(function(el){
      if(!el) return;
      ['background','backgroundColor','backgroundImage','border','borderBottom','boxShadow','backdropFilter','webkitBackdropFilter','filter','transform','willChange'].forEach(function(prop){
        el.style[prop] = '';
      });
    });

    all('.request-link, .bm-header-request, a[href*="/request"]', header).forEach(function(el){ el.remove(); });

    function keepOne(selector, preferred){
      var items = all(selector, header);
      var kept = null;
      if(preferred) kept = header.querySelector(preferred);
      items.forEach(function(el){
        if(!kept){ kept = el; return; }
        if(el !== kept) el.remove();
      });
    }

    keepOne('.menu-btn', '.menu-btn');
    keepOne('.bm-header-collection, .bm-header-collections-icon, .bm-icon-only-collection, .header-actions a.collection-link', '.bm-header-collection');
    keepOne('.notif-bell', '.notif-bell');
    keepOne('.bm-header-search', '.bm-header-search');
    keepOne('.auth-dropdown', '.auth-dropdown');

    all('.header-actions a.collection-link', header).forEach(function(el){
      if(!el.classList.contains('bm-header-collection')) el.remove();
    });
  }

  function boot(){ normalizeInternalRoutes(); cleanHeader(); }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, {once:true}); else boot();
  window.addEventListener('load', function(){ normalizeInternalRoutes(); cleanHeader(); }, {once:true});
  setTimeout(function(){ normalizeInternalRoutes(); cleanHeader(); }, 100);
  setTimeout(function(){ normalizeInternalRoutes(); cleanHeader(); }, 600);
})();
/* V70: mobile-optimized drawer controller for menu + notifications. */
(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  ready(function(){
    var menuBtn = document.getElementById('menuBtn');
    var sidebar = document.getElementById('sidebarMenu');
    var overlay = document.getElementById('menuOverlay');
    var closeMenuBtn = document.getElementById('closeMenuBtn');
    var bell = document.getElementById('notifBell');
    var notif = document.getElementById('notifSidebar');
    var closeNotif = document.getElementById('closeNotifSidebar');
    var notifBackdrop = document.getElementById('notifBackdrop');
    var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var isMobile = function(){ return window.innerWidth < 992; };
    var timers = [];
    var lockedScrollY = 0;

    function duration(){
      if(reduceMotion) return 1;
      if(document.documentElement.classList.contains('bm-ultra-lite')) return 100;
      if(document.documentElement.classList.contains('bm-mobile-lite')) return 150;
      return isMobile() ? 210 : 260;
    }

    if(notif && !notifBackdrop){
      notifBackdrop = document.createElement('div');
      notifBackdrop.className = 'notif-backdrop';
      notifBackdrop.id = 'notifBackdrop';
      notifBackdrop.setAttribute('aria-hidden', 'true');
      notifBackdrop.hidden = true;
      document.body.appendChild(notifBackdrop);
    }

    function clearTimers(){
      while(timers.length) window.clearTimeout(timers.pop());
    }
    function later(fn, delay){
      var id = window.setTimeout(fn, delay);
      timers.push(id);
      return id;
    }
    function stop(e){
      if(!e) return;
      e.preventDefault();
      e.stopPropagation();
      if(e.stopImmediatePropagation) e.stopImmediatePropagation();
    }
    function lock(){
      document.documentElement.classList.add('bm-drawer-open');
      if(document.body.classList.contains('bm-drawer-open')) return;
      lockedScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      document.body.classList.add('bm-drawer-open');
      document.body.style.overflow = 'hidden';
      if(isMobile()){
        document.body.style.position = 'fixed';
        document.body.style.top = (-lockedScrollY) + 'px';
        document.body.style.left = '0';
        document.body.style.right = '0';
        document.body.style.width = '100%';
      }
    }
    function unlock(){
      if(document.querySelector('.sidebar-menu.open, .notif-sidebar.open, .sidebar-menu.bm-closing, .notif-sidebar.bm-closing')) return;
      document.documentElement.classList.remove('bm-drawer-open');
      document.body.classList.remove('bm-drawer-open');
      document.body.style.overflow = '';
      var shouldRestore = document.body.style.position === 'fixed';
      document.body.style.position = '';
      document.body.style.top = '';
      document.body.style.left = '';
      document.body.style.right = '';
      document.body.style.width = '';
      if(shouldRestore) window.scrollTo(0, lockedScrollY || 0);
    }
    function setBackdropVisible(el){
      if(!el) return;
      el.hidden = false;
      el.classList.remove('bm-overlay-closing');
      el.classList.add('bm-overlay-prep');
      el.setAttribute('aria-hidden', 'false');
      requestAnimationFrame(function(){
        requestAnimationFrame(function(){
          el.classList.add('active');
          el.classList.remove('bm-overlay-prep');
        });
      });
    }
    function hideBackdrop(el){
      if(!el) return;
      el.classList.remove('active', 'bm-overlay-prep');
      el.classList.add('bm-overlay-closing');
      el.setAttribute('aria-hidden', 'true');
      later(function(){
        el.classList.remove('bm-overlay-closing');
        el.hidden = true;
      }, duration());
    }
    function preparePanel(panel){
      if(!panel) return;
      panel.classList.add('bm-drawer-ready');
      panel.classList.remove('bm-closing','bm-opening','bm-open-complete');
      panel.style.visibility = 'visible';
    }
    function openPanel(panel, trigger, backdrop){
      if(!panel) return;
      clearTimers();
      closePanel(panel === sidebar ? notif : sidebar, panel === sidebar ? bell : menuBtn, panel === sidebar ? notifBackdrop : overlay, true);
      preparePanel(panel);
      setBackdropVisible(backdrop);
      lock();
      if(trigger) trigger.setAttribute('aria-expanded','true');
      panel.setAttribute('aria-hidden','false');

      requestAnimationFrame(function(){
        panel.classList.add('open','bm-opening');
        later(function(){
          panel.classList.remove('bm-opening');
          panel.classList.add('bm-open-complete');
        }, Math.max(1, duration() - 40));
      });
    }
    function closePanel(panel, trigger, backdrop, silent){
      if(!panel) return;
      var wasOpen = panel.classList.contains('open') || panel.classList.contains('bm-opening') || panel.classList.contains('bm-open-complete');
      if(!wasOpen && !panel.classList.contains('bm-closing')) return;

      panel.classList.remove('bm-opening','bm-open-complete');
      panel.classList.add('bm-closing');
      if(trigger) trigger.setAttribute('aria-expanded','false');
      panel.setAttribute('aria-hidden','true');
      hideBackdrop(backdrop);

      requestAnimationFrame(function(){
        panel.classList.remove('open');
      });
      later(function(){
        panel.classList.remove('bm-closing');
        panel.style.visibility = '';
        if(!silent) unlock();
      }, duration());
    }
    function openMenu(e){
      stop(e);
      if(!isMobile()) return;
      openPanel(sidebar, menuBtn, overlay);
    }
    function closeMenu(e){
      stop(e);
      closePanel(sidebar, menuBtn, overlay);
    }
    function openNotif(e){
      stop(e);
      openPanel(notif, bell, notifBackdrop);
    }
    function closeNotifPanel(e){
      stop(e);
      closePanel(notif, bell, notifBackdrop);
    }

    function bindTap(el, fn){
      if(!el) return;
      el.addEventListener('click', fn, true);
    }

    bindTap(menuBtn, openMenu);
    bindTap(closeMenuBtn, closeMenu);
    bindTap(overlay, closeMenu);

    if(bell && notif){
      bell.setAttribute('aria-expanded','false');
      bindTap(bell, openNotif);
    }
    bindTap(closeNotif, closeNotifPanel);
    bindTap(notifBackdrop, closeNotifPanel);

    if(sidebar){
      sidebar.addEventListener('click',function(e){
        var link=e.target && e.target.closest ? e.target.closest('a[href]') : null;
        if(link) closePanel(sidebar,menuBtn,overlay);
      },false);
    }

    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape'){
        if(sidebar && (sidebar.classList.contains('open') || sidebar.classList.contains('bm-closing'))) closePanel(sidebar, menuBtn, overlay);
        if(notif && (notif.classList.contains('open') || notif.classList.contains('bm-closing'))) closePanel(notif, bell, notifBackdrop);
      }
    }, true);

    window.addEventListener('resize', function(){
      if(!isMobile()){
        closePanel(sidebar, menuBtn, overlay);
        closePanel(notif, bell, notifBackdrop);
      }
    }, {passive:true});
  });
})();


/* V77: compact glass app banner + install modal + screenshot lightbox (mobile only) */
(function(){
  'use strict';
  var CLOSE_KEY = 'bm_app_banner_closed_v79';
  var SHOTS = [
    '/assets/app/bankmovie-app-screen-home-real.webp',
    '/assets/app/bankmovie-app-screen-detail-real.webp',
    '/assets/app/bankmovie-app-screen-collections-real.webp'
  ];
  var SHOT_INDEX = 0;

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }
  function qs(sel, root){ return (root || document).querySelector(sel); }
  function qsa(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function isMobile(){ return window.innerWidth < 992; }

  function syncWithNav(banner, nav){
    if(!banner || !nav) return;
    banner.classList.toggle('nav-hidden', nav.classList.contains('nav-hidden'));
    banner.classList.toggle('nav-compact', nav.classList.contains('nav-compact'));
  }

  function createLightbox(){
    if(document.getElementById('bmAppShotLightbox')) return document.getElementById('bmAppShotLightbox');
    var lightbox = document.createElement('div');
    lightbox.className = 'bm-app-shot-lightbox';
    lightbox.id = 'bmAppShotLightbox';
    lightbox.setAttribute('aria-hidden','true');
    lightbox.innerHTML = ''+
      '<div class="bm-app-shot-lightbox-backdrop" data-bm-shot-close></div>'+
      '<div class="bm-app-shot-lightbox-dialog">'+
        '<button type="button" class="bm-app-shot-lightbox-close" data-bm-shot-close aria-label="بستن">'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6L6 18"/></svg>'+
        '</button>'+
        '<button type="button" class="bm-app-shot-nav prev" data-bm-shot-prev aria-label="قبلی">'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 18l-6-6 6-6"/></svg>'+
        '</button>'+
        '<figure class="bm-app-shot-figure"><img src="" alt="اسکرین شات اپلیکیشن بانک مووی" id="bmAppShotLightboxImg"></figure>'+
        '<button type="button" class="bm-app-shot-nav next" data-bm-shot-next aria-label="بعدی">'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 18l6-6-6-6"/></svg>'+
        '</button>'+
      '</div>';
    document.body.appendChild(lightbox);
    lightbox.addEventListener('click', function(e){
      if(e.target && e.target.hasAttribute('data-bm-shot-close')) closeLightbox();
      if(e.target && e.target.hasAttribute('data-bm-shot-prev')) showLightboxShot(SHOT_INDEX - 1);
      if(e.target && e.target.hasAttribute('data-bm-shot-next')) showLightboxShot(SHOT_INDEX + 1);
    });
    document.addEventListener('keydown', function(e){
      if(!lightbox.classList.contains('open')) return;
      if(e.key === 'Escape') closeLightbox();
      if(e.key === 'ArrowLeft') showLightboxShot(SHOT_INDEX + 1);
      if(e.key === 'ArrowRight') showLightboxShot(SHOT_INDEX - 1);
    });
    return lightbox;
  }

  function showLightboxShot(index){
    var lightbox = createLightbox();
    if(!lightbox) return;
    SHOT_INDEX = (index + SHOTS.length) % SHOTS.length;
    var img = qs('#bmAppShotLightboxImg', lightbox);
    if(img) img.src = SHOTS[SHOT_INDEX];
  }

  function openLightbox(index){
    var lightbox = createLightbox();
    if(!lightbox) return;
    showLightboxShot(index);
    lightbox.classList.add('open');
    lightbox.setAttribute('aria-hidden','false');
  }

  function closeLightbox(){
    var lightbox = document.getElementById('bmAppShotLightbox');
    if(!lightbox) return;
    lightbox.classList.remove('open');
    lightbox.setAttribute('aria-hidden','true');
  }

  function bindShotOpener(root){
    qsa('[data-bm-shot-index]', root).forEach(function(btn){
      btn.addEventListener('click', function(){
        var idx = parseInt(btn.getAttribute('data-bm-shot-index') || '0', 10) || 0;
        openLightbox(idx);
      });
    });
  }

  function createInstallModal(){
    if(document.getElementById('bmAppInstallModal')) return document.getElementById('bmAppInstallModal');
    var modal=document.createElement('div');
    modal.className='bm-app-install-modal';
    modal.id='bmAppInstallModal';
    modal.setAttribute('aria-hidden','true');
    modal.innerHTML=''+
      '<div class="bm-app-install-backdrop" data-bm-app-close></div>'+
      '<section class="bm-app-install-sheet" role="dialog" aria-modal="true" aria-label="دانلود و نصب اپلیکیشن بانک مووی">'+
        '<button type="button" class="bm-app-install-close" data-bm-app-close aria-label="بستن">'+
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6L6 18"/></svg>'+
        '</button>'+
        '<header class="bm-app-install-head">'+
          '<h3>دانلود و نصب اپلیکیشن اندروید</h3>'+
          '<p>نسخه یونیورسال مناسب همه گوشی ها، سازگار با تلویزیون و کنترل TV، به همراه APK مستقیم و نسخه ZIP فشرده.</p>'+
        '</header>'+
        '<div class="bm-app-install-shots">'+
          '<button type="button" class="bm-app-install-shot" data-bm-shot-index="0">'+
            '<img src="/assets/app/bankmovie-app-screen-home-real.webp" alt="صفحه اصلی اپلیکیشن بانک مووی" loading="lazy" decoding="async">'+
            '<span class="bm-app-shot-open">بزرگ‌نمایی</span>'+
          '</button>'+
          '<button type="button" class="bm-app-install-shot" data-bm-shot-index="1">'+
            '<img src="/assets/app/bankmovie-app-screen-detail-real.webp" alt="صفحه جزئیات اپلیکیشن بانک مووی" loading="lazy" decoding="async">'+
            '<span class="bm-app-shot-open">بزرگ‌نمایی</span>'+
          '</button>'+
          '<button type="button" class="bm-app-install-shot" data-bm-shot-index="2">'+
            '<img src="/assets/app/bankmovie-app-screen-collections-real.webp" alt="نمای سوم اپلیکیشن بانک مووی" loading="lazy" decoding="async">'+
            '<span class="bm-app-shot-open">بزرگ‌نمایی</span>'+
          '</button>'+
        '</div>'+
        '<div class="bm-app-install-info">'+
          '<span>نسخه یونیورسال مناسب همه گوشی ها</span>'+
          '<span>کاملا سازگار با تلویزیون و کنترل TV</span>'+
          '<span>نسخه ZIP و فشرده شده</span>'+
        '</div>'+
        '<div class="bm-app-install-actions">'+
          '<a class="bm-app-install-main" href="/app/download.php?file=apk" target="_blank" rel="noopener">'+
            '<img src="/assets/icons/bm-android-icon.svg" alt="" aria-hidden="true">'+
            '<span>دانلود APK</span>'+
          '</a>'+
          '<a class="bm-app-install-secondary" href="/app/download.php?file=zip" target="_blank" rel="noopener">'+
            '<img src="/assets/icons/bm-zip-icon.svg" alt="" aria-hidden="true">'+
            '<span>نسخه ZIP</span>'+
          '</a>'+
        '</div>'+
      '</section>';
    document.body.appendChild(modal);
    bindShotOpener(modal);
    modal.addEventListener('click', function(e){
      if(e.target && e.target.hasAttribute('data-bm-app-close')) closeModal();
    });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape' && modal.classList.contains('open')) closeModal();
    });
    return modal;
  }

  var scrollY=0;
  function openModal(){
    var modal=createInstallModal();
    if(!modal) return;
    scrollY=window.pageYOffset || document.documentElement.scrollTop || 0;
    modal.setAttribute('aria-hidden','false');
    modal.classList.add('open');
    document.documentElement.classList.add('bm-app-modal-open');
    document.body.classList.add('bm-app-modal-open');
    document.body.style.overflow='hidden';
    document.body.style.position='fixed';
    document.body.style.top=(-scrollY)+'px';
    document.body.style.left='0';
    document.body.style.right='0';
    document.body.style.width='100%';
  }
  function closeModal(){
    closeLightbox();
    var modal=document.getElementById('bmAppInstallModal');
    if(!modal) return;
    modal.classList.add('closing');
    modal.setAttribute('aria-hidden','true');
    window.setTimeout(function(){
      modal.classList.remove('open','closing');
      document.documentElement.classList.remove('bm-app-modal-open');
      document.body.classList.remove('bm-app-modal-open');
      document.body.style.overflow='';
      document.body.style.position='';
      document.body.style.top='';
      document.body.style.left='';
      document.body.style.right='';
      document.body.style.width='';
      window.scrollTo(0, scrollY || 0);
    }, 220);
  }

  function mountBanner(){
    var cfg=(window.BM_SITE_UI&&window.BM_SITE_UI.appMiniBanner)||{};
    var enabled=cfg.enabled===true;
    var legacy=document.getElementById('bmAppMiniBanner');

    if(!enabled){
      if(legacy && legacy.parentNode) legacy.parentNode.removeChild(legacy);
      if(document.body) document.body.classList.remove('has-bm-app-mini-banner');
      return;
    }
    if(!isMobile() || legacy) return;
    try{ if(sessionStorage.getItem(CLOSE_KEY)==='1') return; }catch(e){}

    var banner=document.createElement('aside');
    banner.className='bm-app-mini-banner';
    banner.id='bmAppMiniBanner';
    banner.setAttribute('aria-label','دانلود اپلیکیشن بانک مووی');
    banner.innerHTML=''+
      '<div class="bm-app-mini-card">'+
        '<button type="button" class="bm-app-mini-copy" data-bm-app-open>'+
          '<span class="bm-app-mini-icon"><img src="/assets/brand/bankmovie-icon-256.webp" alt=""></span>'+
          '<span class="bm-app-mini-text"><strong>اپلیکیشن بانک مووی منتشر شد</strong><span>نسخه اندروید فیلم و سریال</span></span>'+
        '</button>'+
        '<button type="button" class="bm-app-mini-cta" data-bm-app-open><img src="/assets/icons/bm-android-icon.svg" alt=""><span>نصب</span></button>'+
        '<button type="button" class="bm-app-mini-close" data-bm-app-close aria-label="بستن"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M6 6l12 12M18 6L6 18"/></svg></button>'+
      '</div>';
    document.body.appendChild(banner);
    document.body.classList.add('has-bm-app-mini-banner');

    qsa('[data-bm-app-open]',banner).forEach(function(btn){btn.addEventListener('click',openModal);});
    var close=qs('[data-bm-app-close]',banner);
    if(close) close.addEventListener('click',function(){
      try{sessionStorage.setItem(CLOSE_KEY,'1');}catch(e){}
      banner.classList.add('is-closing');
      window.setTimeout(function(){banner.remove();document.body.classList.remove('has-bm-app-mini-banner');},220);
    });
    syncWithNav(banner,qs('.bottom-nav,[data-mobile-bottom-nav]'));
  }

  ready(mountBanner);
  window.addEventListener('load', mountBanner, {once:true});
})();


/* V80: add App page link to desktop header and mobile hamburger menu. */
(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }
  function all(sel, root){ return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function isAppPage(){ return /(?:^|\/)app\.php(?:$|[?#])/.test(window.location.pathname + window.location.search); }

  var appSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="7" y="2" width="10" height="20" rx="2"></rect><path d="M11 18h2"></path><path d="M9 6h6"></path></svg>';

  function mountAppLinks(){
    var labelFa = 'اپلیکیشن ها';
    var labelEn = 'Apps';
    var htmlDir = (document.documentElement.getAttribute('dir') || '').toLowerCase();
    var isFa = htmlDir !== 'ltr';
    var label = isFa ? labelFa : labelEn;
    var active = isAppPage();

    all('.desktop-nav').forEach(function(nav){
      if(nav.querySelector('a[href*="/application"], .bm-app-desktop-link')) return;
      var link = document.createElement('a');
      link.href = '/application';
      link.className = 'desktop-nav-item bm-app-desktop-link' + (active ? ' active' : '');
      link.innerHTML = '<span>' + label + '</span>';
      nav.appendChild(link);
    });

    all('.sidebar-nav').forEach(function(nav){
      if(nav.querySelector('a[href*="/application"], .bm-app-sidebar-link')) return;
      var link = document.createElement('a');
      link.href = '/application';
      link.className = 'sidebar-item bm-app-sidebar-link' + (active ? ' active' : '');
      link.innerHTML = appSvg + '<span>' + label + '</span>';

      var searchLink = nav.querySelector('a[href*="/search"]');
      if(searchLink && searchLink.parentNode === nav) nav.insertBefore(link, searchLink);
      else nav.appendChild(link);
    });
  }

  ready(mountAppLinks);
  window.addEventListener('load', mountAppLinks, {once:true});
  setTimeout(mountAppLinks, 120);
  setTimeout(mountAppLinks, 700);
})();
