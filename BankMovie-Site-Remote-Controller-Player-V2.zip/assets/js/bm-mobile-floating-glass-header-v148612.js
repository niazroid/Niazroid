(function(){
  'use strict';

  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn, {once:true});
    else fn();
  }

  ready(function(){
    var header = document.getElementById('siteHeader');
    if(!header) return;

    var mobileMq = window.matchMedia ? window.matchMedia('(max-width: 991.98px)') : null;
    var footerNav = document.querySelector('[data-mobile-bottom-nav],.bottom-nav,.actor-bottom-nav');
    var lastY = window.scrollY || 0;
    var ticking = false;
    var minDelta = 12;
    var resizeTimer = 0;

    header.classList.add('bm-mobile-floating-glass-v148612');

    function isMobile(){
      return mobileMq ? mobileMq.matches : window.innerWidth < 992;
    }

    function parsePx(value, fallback){
      var n = parseFloat(String(value || ''));
      return Number.isFinite(n) ? n : fallback;
    }

    /* Match the actual rendered bottom nav geometry. Pages that use a slightly
       different nav width/height still receive an exactly matching header. */
    function measureFromFooter(){
      if(!isMobile() || !footerNav) return;
      var style = window.getComputedStyle(footerNav);
      if(style.display === 'none') return;

      var width = footerNav.getBoundingClientRect().width || footerNav.offsetWidth;
      var height = footerNav.offsetHeight;
      var radius = style.borderRadius;
      var gap = parsePx(style.bottom, 10);

      if(width > 0) header.style.setProperty('--bm-mobile-header-width', Math.round(width) + 'px');
      if(height > 0) header.style.setProperty('--bm-mobile-header-height', Math.round(height) + 'px');
      if(radius && radius !== '0px') header.style.setProperty('--bm-mobile-header-radius', radius);
      header.style.setProperty('--bm-mobile-header-gap', Math.max(8, Math.round(gap)) + 'px');

      /* Use the same visual values when they are available. CSS fallbacks remain
         in place for legacy pages whose nav background is transparent. */
      if(style.background && style.background !== 'rgba(0, 0, 0, 0)'){
        header.style.setProperty('--bm-mobile-header-bg', style.background);
      }
      if(style.borderColor) header.style.setProperty('--bm-mobile-header-border', style.borderColor);
      if(style.boxShadow && style.boxShadow !== 'none') header.style.setProperty('--bm-mobile-header-shadow', style.boxShadow);
      var blur = style.webkitBackdropFilter || style.backdropFilter;
      if(blur && blur !== 'none') header.style.setProperty('--bm-mobile-header-blur', blur);
    }

    function shouldKeepVisible(){
      var active = document.activeElement;
      return !isMobile() ||
        (window.scrollY || 0) < 120 ||
        document.body.style.overflow === 'hidden' ||
        !!document.querySelector('.sidebar-menu.open,.menu-overlay.active,.notif-sidebar.open,.modal.active,.story-modal.active,[aria-modal="true"]') ||
        !!(active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName));
    }

    function applyState(){
      ticking = false;
      if(!isMobile()){
        header.classList.remove('bm-mobile-header-hidden','bm-mobile-header-compact');
        header.style.removeProperty('--bm-mobile-header-width');
        header.style.removeProperty('--bm-mobile-header-height');
        header.style.removeProperty('--bm-mobile-header-radius');
        header.style.removeProperty('--bm-mobile-header-gap');
        return;
      }

      var y = window.scrollY || 0;
      var diff = y - lastY;

      if(shouldKeepVisible()){
        header.classList.remove('bm-mobile-header-hidden');
        header.classList.toggle('bm-mobile-header-compact', y > 220);
        lastY = y;
        return;
      }

      if(Math.abs(diff) > minDelta){
        header.classList.toggle('bm-mobile-header-hidden', diff > 0);
        header.classList.toggle('bm-mobile-header-compact', y > 220 && diff <= 0);
        lastY = y;
      }
    }

    function requestState(){
      if(ticking) return;
      ticking = true;
      window.requestAnimationFrame(applyState);
    }

    function onResize(){
      window.clearTimeout(resizeTimer);
      resizeTimer = window.setTimeout(function(){
        measureFromFooter();
        applyState();
      }, 90);
    }

    /* Keep the header and footer nav in lockstep where page scripts already
       control nav-hidden/nav-compact. The independent scroll controller is the
       fallback on pages without a smart bottom-nav script. */
    if(footerNav && window.MutationObserver){
      var observer = new MutationObserver(function(){
        if(!isMobile()) return;
        if(footerNav.classList.contains('nav-hidden')) header.classList.add('bm-mobile-header-hidden');
        else if(shouldKeepVisible() || !footerNav.classList.contains('nav-hidden')) header.classList.remove('bm-mobile-header-hidden');
        header.classList.toggle('bm-mobile-header-compact', footerNav.classList.contains('nav-compact'));
      });
      observer.observe(footerNav, {attributes:true, attributeFilter:['class','style']});
    }

    measureFromFooter();
    applyState();
    window.addEventListener('scroll', requestState, {passive:true});
    window.addEventListener('resize', onResize, {passive:true});
    window.addEventListener('orientationchange', onResize, {passive:true});
    window.addEventListener('pageshow', function(){ measureFromFooter(); applyState(); }, {passive:true});
    document.addEventListener('focusin', applyState);
    document.addEventListener('focusout', function(){ window.setTimeout(applyState, 80); });
    document.addEventListener('pointerdown', function(e){
      if(header.contains(e.target)) header.classList.remove('bm-mobile-header-hidden');
    }, {passive:true});
  });
})();
