const BM_ARC1_WATCH_CONFIG = window.BM_ARC1_WATCH_CONFIG || {};
(function(){
    const btn = document.getElementById('arc1WlBtn');
    if(!btn) return;
    let inList = !!BM_ARC1_WATCH_CONFIG.inList;
    let watchId = Number(BM_ARC1_WATCH_CONFIG.watchId || 0);
    const SOURCE = BM_ARC1_WATCH_CONFIG.source || '';
    const TITLE = BM_ARC1_WATCH_CONFIG.title || '';
    const YEAR = BM_ARC1_WATCH_CONFIG.year || '';
    const POSTER = BM_ARC1_WATCH_CONFIG.poster || '';
    const RATE = BM_ARC1_WATCH_CONFIG.rate || 0;
    const TYPE = BM_ARC1_WATCH_CONFIG.type || 'movie';
    const archiveNo = Number((window.BM_MOVIE_CONFIG && window.BM_MOVIE_CONFIG.archiveNo) || 1);
    const archiveLabel = 'آرشیو ' + archiveNo;

    function syncVisual(){
        btn.classList.toggle('active', inList);
        const path = btn.querySelector('path');
        if(path) path.setAttribute('fill', inList ? 'currentColor' : 'none');
        const svg = btn.querySelector('svg');
        if(svg) svg.setAttribute('fill', inList ? 'currentColor' : 'none');
        btn.setAttribute('aria-pressed', inList ? 'true' : 'false');
        btn.setAttribute('title', inList ? 'حذف از علاقه‌مندی‌ها' : 'افزودن به علاقه‌مندی‌ها');
    }
    syncVisual();

    btn.addEventListener('click', async()=>{
        const fd = new FormData();
        fd.append('csrf_token', csrfToken);
        if(inList && watchId){
            fd.append('action','remove'); fd.append('id', watchId);
        } else {
            fd.append('action','add');
            fd.append('item_link', SOURCE);
            fd.append('item_title', TITLE);
            fd.append('item_title_fa', TITLE);
            fd.append('item_year', YEAR);
            fd.append('item_poster', POSTER);
            fd.append('item_imdb_rate', RATE);
            fd.append('item_type', TYPE);
        }
        try {
            const res  = await fetch('/ajax_archive1_watchlist.php',{method:'POST',body:fd});
            const data = await res.json();
            if(data.success){
                inList = (typeof data.added !== 'undefined') ? !!data.added : !inList;
                watchId = data.id ? Number(data.id) : (inList ? watchId : 0);
                syncVisual();
                showToast(inList ? ('به نشان‌های '+archiveLabel+' اضافه شد ✓') : 'از نشان‌ها حذف شد');
            } else showToast(data.message || 'خطا', true);
        } catch(e){ showToast('خطا در ارتباط', true); }
    });
})();
