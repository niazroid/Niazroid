// =================== V148.61.9.9: single-tap playback choice ===================
// Mobile bug fixed: opening the modal on pointerup and then handling the synthetic click
// could activate the option under the same finger (internal/VLC/KM/copy) at random.
(function(){
    'use strict';

    var bmPlayChoiceUrl = '';
    var bmPlayChoiceCopyUrl = '';
    var bmPlayChoiceLabel = '';
    var bmPlayChoiceInternalAction = null;
    var bmPlayChoiceIsSoftSub = false;
    var bmCopyResetTimer = null;
    var lastHandledAt = 0;

    function bmVipFeatureLocked(feature){
        try{
            if(typeof window.bmVipGateFeatureLocked === 'function') return !!window.bmVipGateFeatureLocked(feature);
            return !!(window.BM_VIP_GATES && window.BM_VIP_GATES.locks && window.BM_VIP_GATES.locks[feature]);
        }catch(e){ return false; }
    }
    function bmOpenVipInstead(feature, event){
        if(!bmVipFeatureLocked(feature)) return false;
        if(event){
            try{ event.preventDefault(); }catch(e){}
            try{ event.stopPropagation(); }catch(e){}
            try{ if(event.stopImmediatePropagation) event.stopImmediatePropagation(); }catch(e){}
        }
        lastHandledAt = Date.now();
        window.__BM_VIP_GATE_BLOCK_UNTIL = Date.now() + 900;
        try{
            if(typeof window.bmOpenVipGateModal === 'function') window.bmOpenVipGateModal(feature);
            else document.dispatchEvent(new CustomEvent('bm:vip-gate-request',{detail:{feature:feature}}));
        }catch(e){}
        return true;
    }

    function cfg(){ return window.BM_MOVIE_CONFIG || {}; }
    function lang(){ return (cfg().userLang || window.userLang || 'fa'); }
    function fa(faText, enText){ return lang() === 'fa' ? faText : enText; }
    function siteLabel(key, fallbackFa, fallbackEn){
        var labels = cfg().siteLabels || {};
        if(lang() === 'fa' && labels[key]) return String(labels[key]);
        return fa(fallbackFa, fallbackEn);
    }
    function bmToast(text){
        try{
            if(typeof window.showToast === 'function') return window.showToast(text);
            if(typeof showToast === 'function') return showToast(text);
        }catch(e){}
        try{
            var box = document.getElementById('toastContainer') || document.createElement('div');
            if(!box.id){
                box.id = 'toastContainer';
                box.style.cssText = 'position:fixed;left:16px;right:16px;bottom:90px;z-index:2147483647;display:grid;gap:8px;pointer-events:none';
                document.body.appendChild(box);
            }
            var t = document.createElement('div');
            t.textContent = String(text || '');
            t.style.cssText = 'margin:auto;padding:10px 14px;border-radius:14px;background:rgba(0,0,0,.82);color:#fff;font:12px system-ui,Tahoma;box-shadow:0 12px 28px rgba(0,0,0,.35)';
            box.appendChild(t);
            setTimeout(function(){ if(t && t.parentNode) t.parentNode.removeChild(t); }, 2600);
        }catch(e){}
    }
    function bmIsSafeUrl(url){
        try{
            if(typeof window.isSafeUrl === 'function') return !!window.isSafeUrl(url);
            if(typeof isSafeUrl === 'function') return !!isSafeUrl(url);
        }catch(e){}
        try{
            var u = new URL(String(url || ''), window.location.origin);
            return u.protocol === 'http:' || u.protocol === 'https:';
        }catch(e){ return false; }
    }
    function getVar(name, fallback){
        try{
            if(name === 'currentType' && typeof currentType !== 'undefined') return currentType;
            if(name === 'currentQuality' && typeof currentQuality !== 'undefined') return currentQuality;
            if(name === 'bestQuality' && typeof bestQuality !== 'undefined') return bestQuality;
            if(name === 'softLinksData' && typeof softLinksData !== 'undefined') return softLinksData;
            if(name === 'dubLinksData' && typeof dubLinksData !== 'undefined') return dubLinksData;
        }catch(e){}
        return fallback;
    }
    function normalizeItem(item){
        if(!item) return null;
        if(typeof item === 'string') return {url:item, size:''};
        return item;
    }
    function firstValidFromMap(map, quality){
        if(!map) return null;
        if(quality && map[quality] && map[quality][0]){
            var exact = normalizeItem(map[quality][0]);
            if(exact && exact.url && bmIsSafeUrl(exact.url)) return exact;
        }
        var keys = Object.keys(map || {});
        for(var i=0;i<keys.length;i++){
            var arr = map[keys[i]] || [];
            for(var j=0;j<arr.length;j++){
                var item = normalizeItem(arr[j]);
                if(item && item.url && bmIsSafeUrl(item.url)) return item;
            }
        }
        return null;
    }

    function bmCopyTextToClipboard(text){
        if(navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(text);
        var ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.opacity = '0';
        document.body.appendChild(ta);
        ta.select();
        try { document.execCommand('copy'); } catch(e) {}
        ta.remove();
        return Promise.resolve();
    }
    function bmSetInlineNotice(title, text, kind){
        var notice = document.getElementById('bmPlayInlineNotice');
        if(!notice) return;
        var titleEl = notice.querySelector('[data-bm-notice-title]');
        var textEl = notice.querySelector('[data-bm-notice-text]');
        if(titleEl) titleEl.textContent = String(title || '');
        if(textEl) textEl.textContent = String(text || '');
        notice.className = 'bm-play-inline-notice is-visible ' + (kind ? 'is-' + kind : '');
        notice.setAttribute('aria-hidden','false');
        try{ notice.scrollIntoView({block:'nearest', behavior:'smooth'}); }catch(e){}
    }
    function bmClearInlineNotice(){
        var notice = document.getElementById('bmPlayInlineNotice');
        if(!notice) return;
        notice.className = 'bm-play-inline-notice';
        notice.setAttribute('aria-hidden','true');
    }
    function bmSetCopyButtonState(copied){
        var btn = document.querySelector('#bmPlayChoiceModal [data-bm-play-action="copy"]');
        if(!btn) return;
        if(bmCopyResetTimer) clearTimeout(bmCopyResetTimer);
        btn.classList.toggle('is-copied', !!copied);
        btn.setAttribute('aria-label', copied ? siteLabel('copied','لینک کپی شد','Link copied') : siteLabel('copyLink','کپی لینک مستقیم','Copy direct link'));
        var label = btn.querySelector('[data-bm-copy-label]');
        if(label) label.textContent = copied ? siteLabel('copied','لینک کپی شد','Link copied') : siteLabel('copyLink','کپی لینک مستقیم','Copy direct link');
        if(copied){
            bmCopyResetTimer = setTimeout(function(){ bmSetCopyButtonState(false); }, 2400);
        }
    }
    function bmCopyWithFeedback(title, text){
        return bmCopyTextToClipboard(bmPlayChoiceCopyUrl || bmPlayChoiceUrl).then(function(){
            bmSetCopyButtonState(true);
            bmSetInlineNotice(title || fa('لینک با موفقیت کپی شد', 'Link copied successfully'), text || fa('حالا لینک را داخل پلیر خارجی باز کنید', 'Open the link in your external player'), 'success');
        }).catch(function(){
            bmSetInlineNotice(fa('کپی انجام نشد', 'Copy failed'), fa('مرورگر اجازه دسترسی به کلیپ‌بورد را نداد. دوباره تلاش کنید.', 'The browser blocked clipboard access. Please try again.'), 'error');
        });
    }
    function bmGuessSoftSub(opts){
        if(opts && opts.isSoftSub === true) return true;
        var type = String(getVar('currentType', '') || '').toLowerCase();
        var label = String((opts && opts.label) || '').toLowerCase();
        return type === 'soft' || type === 'softsub' || /soft\s*sub|softsub|سافت\s*ساب|سافتساب/.test(label);
    }
    function bmRenderSoftSubNotice(){
        var note = document.getElementById('bmPlaySoftSubNotice');
        if(!note) return;
        note.hidden = false;
        note.setAttribute('aria-hidden','false');
        note.classList.toggle('is-current-softsub', !!bmPlayChoiceIsSoftSub);
    }
    function bmIsLikelyAndroid(){ return /Android/i.test(navigator.userAgent || ''); }
    function bmIsLikelyIOS(){
        var ua = navigator.userAgent || '';
        var platform = navigator.platform || '';
        return /iPad|iPhone|iPod/i.test(ua) || (platform === 'MacIntel' && Number(navigator.maxTouchPoints || 0) > 1);
    }
    function bmIsLikelyWindows(){ return /Windows/i.test(navigator.userAgent || navigator.platform || ''); }
    function bmPlatform(){
        if(bmIsLikelyIOS()) return 'ios';
        if(bmIsLikelyAndroid()) return 'android';
        if(bmIsLikelyWindows()) return 'windows';
        return 'other';
    }
    function bmApplyPlatformOptions(modal){
        if(!modal) return;
        var platform = bmPlatform();
        modal.setAttribute('data-bm-platform', platform);
        var options = modal.querySelectorAll('[data-bm-platform]');
        for(var i=0;i<options.length;i++){
            var allowed = String(options[i].getAttribute('data-bm-platform') || '').split(/\s+/);
            var visible = allowed.indexOf(platform) !== -1 || allowed.indexOf('all') !== -1;
            options[i].hidden = !visible;
            options[i].setAttribute('aria-hidden', visible ? 'false' : 'true');
        }
        var hint = document.getElementById('bmPlayPlatformHint');
        if(hint){
            if(platform === 'ios') hint.textContent = fa('VLC روی آیفون و آیپد مستقیماً باز می‌شود', 'VLC opens directly on iPhone and iPad');
            else if(platform === 'android') hint.textContent = fa('پلیرهای سازگار با اندروید نمایش داده شده‌اند', 'Android-compatible players are shown');
            else if(platform === 'windows') hint.textContent = fa('PotPlayer مستقیم باز می‌شود؛ برای VLC و KMPlayer لینک با کلیک کپی می‌شود', 'PotPlayer opens directly; VLC and KMPlayer copy the stream URL');
            else hint.textContent = fa('برای این دستگاه از پلیر داخلی یا کپی لینک استفاده کنید', 'Use the internal player or copy the link on this device');
        }
    }
    function bmBuildAndroidIntent(url, packageName){
        try{
            var u = new URL(url);
            var scheme = u.protocol.replace(':','') || 'https';
            return 'intent://' + u.host + u.pathname + u.search + u.hash + '#Intent;scheme=' + scheme + ';type=video/*;package=' + packageName + ';S.title=BankMovie;end';
        }catch(e){ return url; }
    }
    function bmBuildIOSVlcUrl(url){
        // Restore the URL form that was already working in the earlier iPhone build.
        return 'vlc://' + String(url || '');
    }
    function bmBuildExternalPlayerUrl(url, app){
        if(!url) return '';
        if(app === 'vlc' && bmIsLikelyIOS()) return bmBuildIOSVlcUrl(url);
        if(app === 'vlc' && bmIsLikelyAndroid()) return bmBuildAndroidIntent(url, 'org.videolan.vlc');
        if(app === 'mx' && bmIsLikelyAndroid()) return bmBuildAndroidIntent(url, 'com.mxtech.videoplayer.ad');
        if(app === 'km' && bmIsLikelyAndroid()) return bmBuildAndroidIntent(url, 'com.kmplayer');
        if(app === 'pot' && bmIsLikelyWindows()) return 'potplayer://' + url;
        return '';
    }
    function bmOpenExternalPlayer(app){
        if(!bmPlayChoiceUrl) {
            bmToast(fa('لینک پخش پیدا نشد', 'Playback link not found'));
            return;
        }
        var platform = bmPlatform();
        var allowed = (platform === 'ios' && app === 'vlc') ||
                      (platform === 'android' && (app === 'vlc' || app === 'mx' || app === 'km')) ||
                      (platform === 'windows' && (app === 'pot' || app === 'vlc' || app === 'km'));
        if(!allowed){
            bmCopyWithFeedback(
                fa('لینک کپی شد', 'Link copied'),
                fa('بازشدن مستقیم این پلیر روی دستگاه فعلی ممکن نیست؛ لینک را داخل برنامه وارد کنید.', 'Direct launch is unavailable on this device; paste the link inside the app.')
            );
            return;
        }
        if(platform === 'windows' && app === 'vlc'){
            bmCopyWithFeedback(
                fa('لینک برای VLC کپی شد', 'Link copied for VLC'),
                fa('VLC را باز کن، کلید Ctrl+N را بزن، لینک را Paste کن و Play را بزن.', 'Open VLC, press Ctrl+N, paste the link, then select Play.')
            );
            return;
        }
        if(platform === 'windows' && app === 'km'){
            bmCopyWithFeedback(
                fa('لینک برای KMPlayer کپی شد', 'Link copied for KMPlayer'),
                fa('KMPlayer را باز کن، کلید Ctrl+U را بزن، لینک را Paste کن و پخش را شروع کن.', 'Open KMPlayer, press Ctrl+U, paste the link, then start playback.')
            );
            return;
        }
        var target = bmBuildExternalPlayerUrl(bmPlayChoiceUrl, app);
        if(!target){
            bmCopyWithFeedback(fa('لینک کپی شد', 'Link copied'), fa('لینک را داخل پلیر خارجی وارد کنید.', 'Paste the link into your external player.'));
            return;
        }
        try{
            var selectedBtn = document.querySelector('#bmPlayChoiceModal [data-bm-play-action="' + app + '"]');
            if(selectedBtn){
                selectedBtn.classList.add('is-opening');
                selectedBtn.setAttribute('aria-pressed','true');
            }
            bmClosePlayChoiceModal();
            window.location.href = target;
            setTimeout(function(){
                if(document.visibilityState === 'visible') bmToast(fa('اگر برنامه باز نشد، نصب بودن پلیر انتخابی را بررسی کنید', 'If the app did not open, check that the selected player is installed'));
            }, 1400);
        }catch(e){
            bmCopyWithFeedback(fa('برنامه باز نشد؛ لینک کپی شد', 'App did not open; link copied'), fa('لینک را به‌صورت دستی داخل پلیر وارد کنید.', 'Paste the link manually into the player.'));
        }
    }

    function bmResetPlayChoiceUI(modal){
        if(!modal) return;
        var options = modal.querySelectorAll('[data-bm-play-action]');
        for(var i=0;i<options.length;i++){
            options[i].classList.remove('is-selected','is-opening','is-copied');
            options[i].removeAttribute('aria-pressed');
            options[i].disabled = false;
        }
        bmClearInlineNotice();
        bmSetCopyButtonState(false);
    }

    function bmForceShowModal(modal){
        if(!modal) return;
        try{ document.documentElement.classList.remove('bm-is-scrolling'); }catch(e){}
        modal.classList.add('active');
        modal.setAttribute('aria-hidden','false');
        modal.style.setProperty('display','flex','important');
        modal.style.setProperty('opacity','1','important');
        modal.style.setProperty('visibility','visible','important');
        modal.style.setProperty('pointer-events','auto','important');
        modal.style.setProperty('z-index','2147483647','important');
        modal.style.setProperty('position','fixed','important');
        modal.style.setProperty('inset','0','important');
        var inner = modal.querySelector('.bm-play-choice-modal');
        if(inner){
            inner.style.setProperty('opacity','1','important');
            inner.style.setProperty('visibility','visible','important');
            inner.style.setProperty('pointer-events','auto','important');
        }
        document.body.classList.add('bm-player-active');
        document.body.style.overflow = 'hidden';
    }
    function bmOpenPlayChoiceModal(opts){
        if(bmOpenVipInstead('online_watch', null)) return false;
        opts = opts || {};
        bmPlayChoiceUrl = String(opts.url || '').trim();
        bmPlayChoiceCopyUrl = String(opts.copyUrl || opts.copy_url || opts.url || '').trim();
        if(!bmIsSafeUrl(bmPlayChoiceCopyUrl)) bmPlayChoiceCopyUrl = bmPlayChoiceUrl;
        bmPlayChoiceLabel = String(opts.label || '').trim();
        bmPlayChoiceInternalAction = typeof opts.internal === 'function' ? opts.internal : null;
        bmPlayChoiceIsSoftSub = bmGuessSoftSub(opts);

        if(!bmPlayChoiceUrl || !bmIsSafeUrl(bmPlayChoiceUrl)){
            bmToast(fa('لینک پخش معتبر نیست', 'Invalid playback link'));
            return false;
        }
        var modal = document.getElementById('bmPlayChoiceModal');
        var label = document.getElementById('bmPlayChoiceLabel');
        if(label) label.textContent = bmPlayChoiceLabel || fa('لینک آماده پخش', 'Ready to play');
        if(modal){
            bmResetPlayChoiceUI(modal);
            bmRenderSoftSubNotice();
            bmApplyPlatformOptions(modal);
            bmForceShowModal(modal);
            return true;
        }
        bmToast(fa('مودال انتخاب پخش در صفحه پیدا نشد', 'Playback choice modal was not found'));
        return false;
    }
    function bmClosePlayChoiceModal(){
        var modal = document.getElementById('bmPlayChoiceModal');
        if(modal){
            modal.classList.remove('active');
            modal.setAttribute('aria-hidden','true');
            modal.style.removeProperty('display');
            modal.style.removeProperty('opacity');
            modal.style.removeProperty('visibility');
            modal.style.removeProperty('pointer-events');
            modal.style.removeProperty('z-index');
            modal.style.removeProperty('position');
            modal.style.removeProperty('inset');
            document.body.style.overflow = '';
            var playerWrapper = document.getElementById('playerWrapper') || document.getElementById('arc1PlayerWrapper') || document.getElementById('arc1PlayerInner');
            var playerVisible = !!(playerWrapper && playerWrapper.style && playerWrapper.style.display && playerWrapper.style.display !== 'none');
            if(!playerVisible) document.body.classList.remove('bm-player-active');
            bmResetPlayChoiceUI(modal);
            bmPlayChoiceIsSoftSub = false;
            bmRenderSoftSubNotice();
        }
    }
    function bmGetFirstPlayableMovieItem(){
        var c = cfg();
        var soft = getVar('softLinksData', c.softLinksData || {});
        var dub  = getVar('dubLinksData', c.dubLinksData || {});
        var type = getVar('currentType', null);
        var quality = getVar('currentQuality', null);
        var best = getVar('bestQuality', c.bestQuality || '');
        var item = null;
        if(type === 'dub') item = firstValidFromMap(dub, quality);
        if(!item && type === 'soft') item = firstValidFromMap(soft, quality);
        if(!item) item = firstValidFromMap(soft, best);
        if(!item) item = firstValidFromMap(dub, best);
        if(!item) item = firstValidFromMap(soft, '');
        if(!item) item = firstValidFromMap(dub, '');
        return item;
    }
    function bmGetCurrentMoviePlayUrl(){
        var item = bmGetFirstPlayableMovieItem();
        return item ? item.url : '';
    }
    function bmFindSubtitle(url){
        try{
            if(typeof window.bmFindSubtitleForVideoUrl === 'function') return window.bmFindSubtitleForVideoUrl(url) || '';
            if(typeof bmFindSubtitleForVideoUrl === 'function') return bmFindSubtitleForVideoUrl(url) || '';
            if(typeof window.arc1FindSubtitleForVideoUrl === 'function') return window.arc1FindSubtitleForVideoUrl(url) || '';
        }catch(e){}
        return '';
    }
    function bmPlayArchive2Internal(url, subtitleUrl, sourceEl){
        if(bmOpenVipInstead('online_watch', null)) return false;
        url = String(url || '').trim();
        if(!url || !bmIsSafeUrl(url)){
            bmToast(fa('لینک پخش معتبر نیست', 'Invalid playback link'));
            return false;
        }
        var w = document.getElementById('playerWrapper');
        var v = document.getElementById('videoPlayer');
        if(!w || !v){
            bmToast(fa('پلیر داخلی آرشیو ۲ در صفحه پیدا نشد', 'Archive 2 internal player was not found'));
            return false;
        }
        document.body.classList.add('bm-player-active');
        w.style.setProperty('display','block','important');
        w.removeAttribute('hidden');
        try{
            if(v.src !== url){
                v.src = url;
                v.load();
            }
        }catch(e){
            try{ v.setAttribute('src',url); v.load(); }catch(_e){}
        }
        subtitleUrl = String(subtitleUrl || bmFindSubtitle(url) || '').trim();
        if(subtitleUrl){
            try{
                if(typeof window.bmPlayerLoadSubtitleUrl === 'function') window.bmPlayerLoadSubtitleUrl(subtitleUrl);
                else window.BM_PENDING_SUBTITLE_URL = subtitleUrl;
            }catch(e){}
        }
        try{
            var playPromise = v.play();
            if(playPromise && playPromise.catch){
                playPromise.catch(function(){
                    bmToast(fa('پلیر آماده است؛ برای شروع روی ویدیو بزنید', 'Player is ready; tap the video to start'));
                });
            }
        }catch(e){
            bmToast(fa('پلیر آماده است؛ برای شروع روی ویدیو بزنید', 'Player is ready; tap the video to start'));
        }
        setTimeout(function(){
            try{ w.scrollIntoView({behavior:'smooth',block:'start'}); }catch(e){}
        },70);
        return true;
    }

    function bmPlayLocalMovieInternal(url, subtitleUrl, sourceEl){
        if(Number(cfg().archiveNo || 0) === 2 && String(cfg().mediaType || '') === 'series'){
            return bmPlayArchive2Internal(url, subtitleUrl, sourceEl);
        }
        if(bmOpenVipInstead('online_watch', null)) return;
        url = String(url || '').trim();
        if(!url || !bmIsSafeUrl(url)){
            bmToast(fa('لینک پخش معتبر نیست', 'Invalid playback link'));
            return;
        }
        document.body.classList.add('bm-player-active');
        var v = document.getElementById('videoPlayer') || document.getElementById('arc1VideoEl');
        var outer = document.getElementById('arc1PlayerWrapper');
        var w = document.getElementById('playerWrapper') || document.getElementById('arc1PlayerInner') || outer;
        try{ if(typeof video !== 'undefined' && v) video = v; }catch(e){}
        try{ if(typeof wrapper !== 'undefined' && w) wrapper = w; }catch(e){}
        subtitleUrl = String(subtitleUrl || bmFindSubtitle(url) || '').trim();
        if(outer) outer.style.display = 'block';
        if(w) w.style.display = 'block';
        if(v){
            if(v.src !== url){
                v.src = url;
                try{ v.load(); }catch(e){}
            }
            var p = null;
            try{ p = v.play(); }catch(e){}
            if(p && p.catch) p.catch(function(){ bmToast(fa('برای شروع پخش روی ویدیو بزنید', 'Tap video to start playback')); });
            if(subtitleUrl){
                if(typeof window.bmPlayerLoadSubtitleUrl === 'function') window.bmPlayerLoadSubtitleUrl(subtitleUrl);
                else if(typeof window.bmArc1AutoLoadSubtitle === 'function') window.bmArc1AutoLoadSubtitle(subtitleUrl);
                else window.BM_PENDING_SUBTITLE_URL = subtitleUrl;
            }
        }
        try{
            var label = sourceEl && (sourceEl.getAttribute('data-label') || '');
            var season = sourceEl && (sourceEl.getAttribute('data-season') || '');
            var nowPlayingEl = document.getElementById('arc1NowPlaying');
            if(nowPlayingEl){
                var txt = label || '';
                if(season && txt && txt.indexOf('فصل') === -1 && lang() === 'fa') txt = 'فصل ' + season + ' — ' + txt;
                if(season && txt && txt.indexOf('Season') === -1 && lang() !== 'fa') txt = 'Season ' + season + ' — ' + txt;
                nowPlayingEl.textContent = txt ? (lang() === 'fa' ? 'در حال پخش: ' : 'Now playing: ') + txt : '';
            }
        }catch(e){}
        setTimeout(function(){ if((w || outer) && (w || outer).scrollIntoView) (w || outer).scrollIntoView({behavior:'smooth', block:'start'}); }, 60);
    }

    function textFrom(el, selector){
        try{
            var x = el && el.closest && el.closest('.arc1-link-row,.download-link,.premium-download-card,.movie-detail');
            var n = x && x.querySelector(selector);
            return n ? String(n.textContent || '').replace(/\s+/g,' ').trim() : '';
        }catch(e){ return ''; }
    }
    function buildLabelForTarget(target){
        var label = target.getAttribute('data-label') || '';
        if(label) return label;
        var quality = textFrom(target, '.quality,.bm-archive2-quality-halo');
        var type = textFrom(target, '.download-type-badge');
        if(quality && type) return quality + ' · ' + type;
        if(quality) return quality;
        if(type) return type;
        return fa('لینک آماده پخش', 'Ready to play');
    }
    function getUrlForTarget(target){
        var url = target.getAttribute('data-url') || '';
        if(!url && target.classList.contains('bm-poster-play')) url = bmGetCurrentMoviePlayUrl();
        if(!url && target.tagName && target.tagName.toLowerCase() === 'a') url = target.getAttribute('href') || '';
        return url;
    }
    function shouldIgnoreTarget(target){
        if(!target) return true;
        if(target.matches && target.matches('[data-bm-play-action],[data-bm-play-close]')) return true;
        if(target.classList.contains('bm-trailer-cta') || target.getAttribute('data-direct-player') === '1') return true;
        return false;
    }
    function handleOpenTarget(target, originalEvent){
        if(!target || shouldIgnoreTarget(target)) return false;
        if(bmOpenVipInstead('online_watch', originalEvent)) return true;

        // V40: آرشیوهای ۱/۳/۴ پلیر و کنترل‌های native خودشان را دارند.
        // مودال عمومی فقط بازکننده باشد؛ اکشن داخلی باید از movie-inline-5 ساخته شود تا کنترل‌های پلیر نخوابند.
        if(Number(cfg().archiveNo || 0) !== 2 && target.closest && target.closest('.arc1-play-btn') && typeof window.bmArc1OpenPlayChoiceFromButton === 'function'){
            if(originalEvent){
                originalEvent.preventDefault();
                originalEvent.stopPropagation();
                if(originalEvent.stopImmediatePropagation) originalEvent.stopImmediatePropagation();
            }
            lastHandledAt = Date.now();
            return window.bmArc1OpenPlayChoiceFromButton(target.closest('.arc1-play-btn'), null);
        }

        var url = getUrlForTarget(target);
        var label = buildLabelForTarget(target);
        var subtitleUrl = target.getAttribute('data-subtitle-url') || '';
        var copyUrl = target.getAttribute('data-copy-url') || url;
        if(!url || !bmIsSafeUrl(url)) return false;
        if(originalEvent){
            originalEvent.preventDefault();
            originalEvent.stopPropagation();
            if(originalEvent.stopImmediatePropagation) originalEvent.stopImmediatePropagation();
        }
        lastHandledAt = Date.now();
        return bmOpenPlayChoiceModal({
            url: url,
            copyUrl: copyUrl,
            label: label,
            internal: function(){ bmPlayLocalMovieInternal(url, subtitleUrl, target); }
        });
    }
    function isDownloadOnlyTarget(e){
        if(!e || !e.target || !e.target.closest) return false;
        return !!e.target.closest('a[download],a.download-icon,a.arc1-dl-btn,[data-bm-download-only="1"],.arc1-sub-dl-btn,.arc4-subtitle-direct');
    }

    function findPlayableTarget(e){
        if(!e || !e.target || !e.target.closest) return null;
        // v32: همه دکمه‌های پخش که data-url دارند باید مودال انتخاب پخش را باز کنند، نه فقط لینک‌های دیتابیس/آرشیو ۲.
        return e.target.closest('.bm-local-play-choice,.bm-download-play-choice,.bm-poster-play,.arc1-play-btn,.arc1-play-inline[data-url]');
    }

    document.addEventListener('click', function(e){
        // A download control must never be promoted into the playback chooser.
        // Leave its native/VIP-download handler untouched.
        if(isDownloadOnlyTarget(e)) return;
        var closeBtn = e.target.closest && e.target.closest('[data-bm-play-close]');
        if(closeBtn){ e.preventDefault(); bmClosePlayChoiceModal(); return; }

        var modal = document.getElementById('bmPlayChoiceModal');
        if(modal && e.target === modal){ e.preventDefault(); bmClosePlayChoiceModal(); return; }

        var actionBtn = e.target.closest && e.target.closest('[data-bm-play-action]');
        if(actionBtn){
            e.preventDefault();
            e.stopPropagation();
            var action = actionBtn.getAttribute('data-bm-play-action');
            if(action === 'internal'){
                bmClosePlayChoiceModal();
                if(bmPlayChoiceInternalAction) bmPlayChoiceInternalAction();
                else bmPlayLocalMovieInternal(bmPlayChoiceUrl);
            }else if(action === 'vlc' || action === 'mx' || action === 'km' || action === 'pot'){
                bmOpenExternalPlayer(action);
            }else if(action === 'copy'){
                if(!bmPlayChoiceUrl) return;
                bmCopyWithFeedback(
                    fa('لینک پخش کپی شد', 'Playback link copied'),
                    fa('می‌توانید لینک را در VLC، KMPlayer، PotPlayer یا پلیر دلخواه وارد کنید.', 'Paste the link into VLC, KMPlayer, PotPlayer, or another external player.')
                );
            }
            return;
        }

        if(Date.now() - lastHandledAt < 450) return;
        handleOpenTarget(findPlayableTarget(e), e);
    }, true);

    // Intentionally no pointerup opener: one physical tap must produce one action only.

    document.addEventListener('keydown', function(e){
        if(e.key === 'Escape') bmClosePlayChoiceModal();
    });

    window.bmCopyTextToClipboard = bmCopyTextToClipboard;
    window.bmOpenExternalPlayer = bmOpenExternalPlayer;
    window.bmOpenPlayChoiceModal = bmOpenPlayChoiceModal;
    window.bmClosePlayChoiceModal = bmClosePlayChoiceModal;
    window.bmGetFirstPlayableMovieItem = bmGetFirstPlayableMovieItem;
    window.bmGetCurrentMoviePlayUrl = bmGetCurrentMoviePlayUrl;
    window.bmPlayLocalMovieInternal = bmPlayLocalMovieInternal;
    window.bmPlayArchive2Internal = bmPlayArchive2Internal;
})();
