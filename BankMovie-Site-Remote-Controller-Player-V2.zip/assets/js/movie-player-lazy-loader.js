/* BankMovie movie player lazy loader - v10 */
(function(){
  const loaded = Object.create(null);
  function loadScript(src){
    if(!src) return Promise.resolve();
    if(loaded[src]) return loaded[src];
    loaded[src] = new Promise((resolve,reject)=>{
      const s=document.createElement('script');
      s.src=src;
      s.async=false;
      s.onload=resolve;
      s.onerror=reject;
      document.body.appendChild(s);
    });
    return loaded[src];
  }
  function loadNormalPlayer(){
    if(!document.getElementById('videoPlayer')) return;
    loadScript('/assets/js/movie-player-core.js?v=split12').catch(()=>{});
  }
  function loadArc1Player(){
    if(!document.getElementById('arc1VideoEl')) return;
    loadScript('/assets/js/movie-inline-5.js?v=split12').catch(()=>{});
  }
  function observeOrSoon(selector, fn, rootMargin='500px'){
    const el=document.querySelector(selector);
    if(!el) return;
    let done=false;
    const run=()=>{ if(done) return; done=true; fn(); };
    el.addEventListener('pointerdown', run, {once:true, passive:true});
    el.addEventListener('click', run, {once:true});
    if('IntersectionObserver' in window){
      const io=new IntersectionObserver((entries)=>{
        if(entries.some(e=>e.isIntersecting)){ io.disconnect(); run(); }
      }, {rootMargin});
      io.observe(el);
    } else {
      setTimeout(run, 1600);
    }
  }
  document.addEventListener('DOMContentLoaded', function(){
    observeOrSoon('#playerWrapper', loadNormalPlayer, '700px');
    observeOrSoon('#arc1PlayerWrapper,#arc1PlayerInner', loadArc1Player, '700px');
    document.querySelectorAll('a[href="#playerWrapper"],.quality-btn,.bm-local-play-choice').forEach(el=>{
      el.addEventListener('pointerdown', loadNormalPlayer, {once:true, passive:true});
      el.addEventListener('click', loadNormalPlayer, {once:true});
    });
  });
})();
