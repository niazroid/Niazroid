(function(){
  'use strict';
  const EXCLUDE='.bm-no-neon,[data-bm-no-neon],.switch input,.toggle input,.toggle-switch input,[class*="switch"] input,[class*="toggle"] input,.neon-checkbox input';
  const particles=Array.from({length:12},()=>'<span></span>').join('');
  const rings='<span class="ring"></span><span class="ring"></span><span class="ring"></span>';
  const sparks='<span></span><span></span><span></span><span></span>';
  function visual(){
    const el=document.createElement('span');
    el.className='neon-checkbox';
    el.setAttribute('aria-hidden','true');
    el.innerHTML='<span class="neon-checkbox__frame"><span class="neon-checkbox__box"></span><span class="neon-checkbox__check-container"><svg class="neon-checkbox__check" viewBox="0 0 24 24"><path d="M5 12.5 9.5 17 19 7.5"/></svg></span><span class="neon-checkbox__glow"></span><span class="neon-checkbox__borders"><span></span><span></span><span></span><span></span></span><span class="neon-checkbox__particles">'+particles+'</span><span class="neon-checkbox__rings">'+rings+'</span><span class="neon-checkbox__sparks">'+sparks+'</span></span>';
    return el;
  }
  function upgrade(input){
    if(!(input instanceof HTMLInputElement)||input.type!=='checkbox'||input.dataset.bmNeonReady==='1'||input.matches(EXCLUDE)) return;
    if(input.closest('[hidden],template')) return;
    input.dataset.bmNeonReady='1';
    input.classList.add('bm-neon-checkbox-input');
    const frame=visual();
    input.insertAdjacentElement('afterend',frame);
    let host=input.closest('label');
    if(host){host.classList.add('bm-neon-checkbox-host');}
    else{
      const wrapper=document.createElement('span');
      wrapper.className='bm-neon-checkbox-host';
      input.parentNode.insertBefore(wrapper,input);
      wrapper.append(input,frame);
      wrapper.addEventListener('click',e=>{
        if(e.target===input||input.disabled)return;
        input.checked=!input.checked;
        input.dispatchEvent(new Event('change',{bubbles:true}));
      });
    }
  }
  function scan(root){
    if(root instanceof HTMLInputElement) upgrade(root);
    root.querySelectorAll?.('input[type="checkbox"]').forEach(upgrade);
  }
  function start(){
    scan(document);
    new MutationObserver(records=>records.forEach(r=>r.addedNodes.forEach(n=>{if(n.nodeType===1)scan(n)}))).observe(document.documentElement,{childList:true,subtree:true});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
