(function(){
  'use strict';
  const body=document.body;
  const sidebar=document.getElementById('sidebar');
  const backdrop=document.getElementById('sidebarBackdrop');
  const toggle=document.getElementById('menuToggle');

  function closeMenu(){sidebar?.classList.remove('open');backdrop?.classList.remove('open');}
  toggle?.addEventListener('click',()=>{sidebar?.classList.toggle('open');backdrop?.classList.toggle('open');});
  backdrop?.addEventListener('click',closeMenu);

  const saved=localStorage.getItem('adminTheme')||'neon';
  function applyTheme(t){
    body.classList.remove('theme-purple','theme-red','theme-gold');
    if(t!=='neon')body.classList.add('theme-'+t);
    document.querySelectorAll('.theme-chip').forEach(b=>b.classList.toggle('active',b.dataset.theme===t));
    localStorage.setItem('adminTheme',t);
  }
  applyTheme(saved);
  document.querySelectorAll('.theme-chip').forEach(b=>b.addEventListener('click',()=>applyTheme(b.dataset.theme)));

  const labels={
    public:'مهمان، کاربر، VIP و مدیر',
    member:'فقط حساب‌های واردشده + VIP + مدیر',
    vip:'فقط VIP فعال + مدیر',
    admin:'فقط مدیر'
  };

  function refreshCard(card){
    const checked=card.querySelector('input[type=radio][name$="_access_scope"]:checked');
    const preview=card.querySelector('[data-scope-preview]');
    if(preview&&checked)preview.textContent=labels[checked.value]||checked.value;

    const enabled=card.querySelector('input[type=checkbox][name$="_enabled"]');
    const badge=card.querySelector('[data-status-badge]');
    if(enabled&&badge){
      badge.textContent=enabled.checked?'فعال':'غیرفعال';
      badge.classList.toggle('on',enabled.checked);
      badge.classList.toggle('off',!enabled.checked);
    }
  }

  document.querySelectorAll('[data-archive-card]').forEach(card=>{
    refreshCard(card);
    card.addEventListener('change',()=>refreshCard(card));
  });

  document.querySelectorAll('[data-scope-preset]').forEach(btn=>{
    btn.addEventListener('click',()=>{
      const scope=btn.dataset.scopePreset;
      document.querySelectorAll(`input[type=radio][value="${scope}"][name$="_access_scope"]`).forEach(r=>{
        r.checked=true;
        r.dispatchEvent(new Event('change',{bubbles:true}));
      });
    });
  });
})();