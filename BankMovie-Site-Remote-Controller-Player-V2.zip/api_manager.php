<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/admin_guard.php';
require_once __DIR__ . '/includes/archive_control.php';

require_admin();
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

function bm_api_manager_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$archiveNames = [
    'archive1' => ['label'=>'آرشیو ۱','icon'=>'fa-earth-americas','connection'=>'API2 + OldTowns Live'],
    'archive2' => ['label'=>'آرشیو ۲','icon'=>'fa-database','connection'=>'دیتابیس اصلی سایت'],
    'archive3' => ['label'=>'آرشیو ۳','icon'=>'fa-satellite-dish','connection'=>'API6'],
    'archive4' => ['label'=>'آرشیو ۴','icon'=>'fa-film','connection'=>'API4 / Cinamatic'],
];

$scopeMeta = [
    'public' => ['label'=>'همه','icon'=>'fa-earth-americas','desc'=>'مهمان + کاربر + VIP + مدیر'],
    'member' => ['label'=>'اعضا','icon'=>'fa-user-check','desc'=>'فقط کاربران واردشده + VIP + مدیر'],
    'vip' => ['label'=>'VIP','icon'=>'fa-crown','desc'=>'فقط VIP فعال + مدیر'],
    'admin' => ['label'=>'مدیر','icon'=>'fa-shield-halved','desc'=>'فقط مدیر'],
];

$featureScopeMeta = $scopeMeta + [
    'disabled' => ['label'=>'خاموش','icon'=>'fa-ban','desc'=>'این قابلیت برای همه، حتی مدیر، غیرفعال است'],
];

function bm_api_manager_search_candidates(PDO $pdo, string $archiveId, string $query): array {
    $query = trim($query);
    $queryLength = function_exists('mb_strlen') ? mb_strlen($query, 'UTF-8') : strlen($query);
    if ($query === '' || $queryLength < 2) return [];
    $rows = [];

    if ($archiveId === 'archive2') {
        $like = '%' . str_replace(['%','_'], ['\\%','\\_'], $query) . '%';
        $stmt = $pdo->prepare("SELECT id, imdb_code, title, title_fa, year, type FROM movies WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ? ORDER BY year DESC, id DESC LIMIT 30");
        $stmt->execute([$like, $like, $like]);
        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach ($rows as &$localRow) $localRow['_bm_local_db'] = true;
        unset($localRow);
        // Archive 2 is authoritative in the website database. Do not merge
        // API5 results here: a blocked result must resolve to the same local
        // identity used by movie.php and app_api.php.
    } elseif ($archiveId === 'archive1') {
        require_once __DIR__ . '/includes/api2_lib.php';
        $rows = advancedSearch([
            's'=>$query, 'type'=>'both', 'genre'=>0, 'sortby'=>'newest', 'imdbrate'=>0,
            'country'=>0, 'min_year'=>1800, 'max_year'=>(int)date('Y') + 2,
            'page'=>1, 'dubbed'=>0, 'subtitle'=>0,
        ]);
    } elseif ($archiveId === 'archive3') {
        require_once __DIR__ . '/includes/api6_lib.php';
        $result = api6_search(['s'=>$query, 'type'=>'all', 'page'=>1]);
        $rows = $result['movies'] ?? ($result['items'] ?? []);
    } elseif ($archiveId === 'archive4') {
        require_once __DIR__ . '/includes/api4_lib.php';
        $result = api4_search(['s'=>$query, 'type'=>'all', 'page'=>1]);
        $rows = $result['movies'] ?? ($result['items'] ?? []);
    }

    $out = [];
    foreach ((array)$rows as $row) {
        if (!is_array($row)) continue;
        $title = trim((string)($row['title_fa'] ?? ($row['name_fa'] ?? ($row['title'] ?? ($row['name'] ?? '')))));
        $titleEn = trim((string)($row['title'] ?? ($row['name'] ?? '')));
        if ($title === '') $title = $titleEn;
        $sourceUrl = trim((string)($row['source_url'] ?? ($row['detail_url'] ?? ($row['url'] ?? ''))));
        $identifier = trim((string)($row['imdb_code'] ?? ($row['imdb_id'] ?? ($row['slug'] ?? ($row['detail_id'] ?? ($row['source_id'] ?? ($row['id'] ?? '')))))));
        if ($archiveId === 'archive2' && !empty($row['_bm_local_db']) && !empty($row['id'])) {
            $identifier = !empty($row['imdb_code']) ? (string)$row['imdb_code'] : ('movie_id:' . (int)$row['id']);
        }
        if ($identifier === '' && $sourceUrl !== '') {
            $path = trim((string)(parse_url($sourceUrl, PHP_URL_PATH) ?: ''), '/');
            $parts = array_values(array_filter(explode('/', $path), 'strlen'));
            if ($parts) $identifier = (string)end($parts);
        }
        if ($title === '' || ($identifier === '' && $sourceUrl === '')) continue;
        $key = bm_archive_normalize_identifier($identifier !== '' ? $identifier : $sourceUrl);
        if ($key === '' || isset($out[$key])) continue;
        $out[$key] = [
            'identifier'=>$identifier,
            'source_url'=>$sourceUrl,
            'title'=>$title,
            'title_en'=>$titleEn !== $title ? $titleEn : '',
            'year'=>trim((string)($row['year'] ?? ($row['release_year'] ?? ''))),
            'type'=>trim((string)($row['type'] ?? '')),
        ];
        if (count($out) >= 30) break;
    }
    return array_values($out);
}

$flash = trim((string)($_GET['msg'] ?? ''));
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['archive_api_action'])) {
    try {
        $action = trim((string)$_POST['archive_api_action']);
        $settings = bm_archive_get_settings();

        if ($action === 'add_blocked_item') {
            $archiveId = strtolower(trim((string)($_POST['blocked_archive_id'] ?? '')));
            if (!isset($archiveNames[$archiveId])) throw new RuntimeException('آرشیو انتخاب‌شده معتبر نیست.');
            $candidate = [
                'archive_id'=>$archiveId,
                'identifier'=>trim((string)($_POST['blocked_identifier'] ?? '')),
                'source_url'=>trim((string)($_POST['blocked_source_url'] ?? '')),
                'title'=>trim((string)($_POST['blocked_title'] ?? '')),
                'year'=>trim((string)($_POST['blocked_year'] ?? '')),
                'block_downloads'=>true,
                'created_at'=>date('c'),
            ];
            $newItems = bm_archive_normalize_blocked_items(array_merge($settings['blocked_items'] ?? [], [$candidate]));
            if (count($newItems) <= count($settings['blocked_items'] ?? [])) throw new RuntimeException('این عنوان قبلاً در فهرست مسدودی قرار گرفته است.');
            $settings['blocked_items'] = $newItems;
            if (!bm_archive_save_settings($settings)) throw new RuntimeException('ذخیره فهرست مسدودی انجام نشد.');
            header('Location: api_manager.php?msg=' . urlencode('لینک‌های دانلود عنوان انتخاب‌شده بسته شد') . '#blocked-items');
            exit;
        }

        if ($action === 'remove_blocked_item') {
            $ruleId = trim((string)($_POST['blocked_rule_id'] ?? ''));
            $settings['blocked_items'] = array_values(array_filter($settings['blocked_items'] ?? [], static fn($row) => (string)($row['id'] ?? '') !== $ruleId));
            if (!bm_archive_save_settings($settings)) throw new RuntimeException('حذف از فهرست مسدودی انجام نشد.');
            header('Location: api_manager.php?msg=' . urlencode('مسدودی لینک دانلود برداشته شد') . '#blocked-items');
            exit;
        }

        if ($action !== 'save') throw new RuntimeException('عملیات ناشناخته است.');

        foreach (array_keys($archiveNames) as $aid) {
            $old = is_array($settings['archives'][$aid] ?? null) ? $settings['archives'][$aid] : [];

            $scope = strtolower(trim((string)($_POST[$aid . '_access_scope'] ?? 'public')));
            if (!isset($scopeMeta[$scope])) $scope = 'public';

            $mode = strtolower(trim((string)($_POST[$aid . '_disabled_mode'] ?? 'visible')));
            if (!in_array($mode, ['visible','hide'], true)) $mode = 'visible';

            $label = trim((string)($_POST[$aid . '_label'] ?? ($old['label'] ?? $archiveNames[$aid]['label'])));
            $disabledMessage = trim((string)($_POST[$aid . '_disabled_message'] ?? ($old['disabled_message'] ?? '')));
            $downloadScope = strtolower(trim((string)($_POST[$aid . '_download_access_scope'] ?? 'public')));
            if (!isset($featureScopeMeta[$downloadScope])) $downloadScope = 'public';
            $streamScope = strtolower(trim((string)($_POST[$aid . '_stream_access_scope'] ?? 'public')));
            if (!isset($featureScopeMeta[$streamScope])) $streamScope = 'public';
            $sourceInput = trim((string)($_POST[$aid . '_source_base_url'] ?? ''));
            $sourceBase = bm_archive_normalize_base_url($sourceInput, true);
            if ($sourceInput !== '' && $sourceBase === '') throw new RuntimeException('دامنه منبع ' . $archiveNames[$aid]['label'] . ' معتبر نیست.');
            $downloadBases = bm_archive_normalize_url_list((string)($_POST[$aid . '_download_base_urls'] ?? ''), $old['download_base_urls'] ?? ['https://dl10.bankmovie.top']);

            $settings['archives'][$aid] = [
                'label' => $label !== '' ? $label : $archiveNames[$aid]['label'],
                'enabled' => isset($_POST[$aid . '_enabled']),
                'access_scope' => $scope,
                'download_access_scope' => $downloadScope,
                'stream_access_scope' => $streamScope,
                'source_base_url' => $sourceBase,
                'download_base_urls' => $downloadBases,
                'disabled_mode' => $mode,
                'disabled_message' => $disabledMessage !== '' ? $disabledMessage : 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.',
            ];
        }

        if (!bm_archive_save_settings($settings)) {
            throw new RuntimeException('فایل تنظیمات قابل نوشتن نیست.');
        }

        header('Location: api_manager.php?msg=' . urlencode('تنظیمات حرفه‌ای آرشیوها ذخیره شد'));
        exit;
    } catch (Throwable $e) {
        $error = 'ذخیره تنظیمات انجام نشد: ' . $e->getMessage();
    }
}

$settings = bm_archive_get_settings();

$blockSearchArchive = strtolower(trim((string)($_GET['block_archive'] ?? 'archive1')));
if (!isset($archiveNames[$blockSearchArchive])) $blockSearchArchive = 'archive1';
$blockSearchQuery = trim((string)($_GET['block_q'] ?? ''));
$blockSearchResults = [];
$blockSearchError = '';
if ($blockSearchQuery !== '') {
    try {
        $blockSearchResults = bm_api_manager_search_candidates($pdo, $blockSearchArchive, $blockSearchQuery);
    } catch (Throwable $e) {
        $blockSearchError = 'جستجو انجام نشد: ' . $e->getMessage();
    }
}

$stats = ['enabled'=>0,'public'=>0,'member'=>0,'vip'=>0,'admin'=>0];
foreach ($archiveNames as $aid => $_meta) {
    $cfg = $settings['archives'][$aid] ?? [];
    if (!empty($cfg['enabled'])) $stats['enabled']++;
    $s = (string)($cfg['access_scope'] ?? 'public');
    if (isset($stats[$s])) $stats[$s]++;
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#050914">
<title>مدیریت حرفه‌ای آرشیوها | BankMovie</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="/assets/css/bm-api-manager-v79.css?v=79.0">
</head>
<body>
<button type="button" class="menu-toggle" id="menuToggle" aria-label="باز کردن منوی مدیریت"><i class="fa-solid fa-bars"></i></button>
<div class="sidebar-backdrop" id="sidebarBackdrop"></div>

<aside class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <i class="fa-solid fa-film"></i>
    <div><h2>BankMovie</h2><small>پنل مدیریت</small></div>
  </div>

  <nav class="sidebar-nav">
    <a href="admin.php"><i class="fa-solid fa-gauge-high"></i> مرکز فرماندهی</a>
    <a class="active" href="api_manager.php"><i class="fa-solid fa-plug-circle-bolt"></i> مدیریت آرشیوها و API</a>
    <a href="admin_control_center.php"><i class="fa-solid fa-sliders"></i> مرکز کنترل کامل</a>
    <a href="admin_site_manager.php"><i class="fa-solid fa-palette"></i> مدیریت ظاهر و متن‌ها</a>
    <a href="bm_admin.php"><i class="fa-solid fa-mobile-screen-button"></i> کنترل اپ بانک مووی</a>
    <a href="admin_boxoffice.php"><i class="fa-solid fa-chart-bar"></i> باکس آفیس زنده</a>
    <a href="admin_collections.php"><i class="fa-solid fa-layer-group"></i> کالکشن‌ها</a>
    <a href="admin_slider.php"><i class="fa-solid fa-images"></i> اسلایدر</a>
    <a href="admin_stickers.php"><i class="fa-solid fa-note-sticky"></i> استیکر و گیف</a>
    <a href="admin_health.php"><i class="fa-solid fa-stethoscope"></i> عیب‌یابی پنل</a>
  </nav>

  <div class="sidebar-footer">
    <a class="logout-btn" href="/logout"><i class="fa-solid fa-right-from-bracket"></i> خروج از پنل</a>
  </div>
</aside>

<div class="theme-dock" aria-label="انتخاب تم پنل">
  <button type="button" data-theme="neon" class="theme-chip active" title="Neon Green"></button>
  <button type="button" data-theme="purple" class="theme-chip theme-purple-chip" title="Purple Cinema"></button>
  <button type="button" data-theme="red" class="theme-chip theme-red-chip" title="Red Netflix"></button>
  <button type="button" data-theme="gold" class="theme-chip theme-gold-chip" title="Gold Premium"></button>
</div>

<main class="main-content">
<div class="wrap">
  <section class="dashboard-hero">
    <div class="hero-copy">
      <span class="hero-eyebrow"><i class="fa-solid fa-shield-halved"></i> کنترل دسترسی آرشیو BankMovie</span>
      <h1 class="hero-title">مدیریت <span>آرشیوها و API</span></h1>
      <p class="hero-subtitle">ظاهر این صفحه با پنل اصلی هماهنگ شده و هر آرشیو حالا کنترل مستقل وضعیت، نام، حالت تعمیرات و سطح دسترسی دارد. کاربران غیرمجاز حتی دکمه همان آرشیو را نمی‌بینند و مسیر مستقیم/API هم برایشان بسته می‌شود.</p>
      <div class="hero-actions">
        <a class="btn" href="/"><i class="fa-solid fa-arrow-up-right-from-square"></i> مشاهده سایت</a>
        <a class="btn" href="admin.php"><i class="fa-solid fa-gauge-high"></i> پنل اصلی</a>
        <a class="btn primary" href="api4.php?ping=1" target="_blank" rel="noopener"><i class="fa-solid fa-vial"></i> تست آرشیو ۴</a>
      </div>
    </div>
    <div class="hero-panel">
      <div class="hero-mini"><i class="fa-solid fa-circle-check"></i><b><?= (int)$stats['enabled'] ?></b><span>آرشیو فعال</span></div>
      <div class="hero-mini"><i class="fa-solid fa-earth-americas"></i><b><?= (int)$stats['public'] ?></b><span>عمومی</span></div>
      <div class="hero-mini"><i class="fa-solid fa-crown"></i><b><?= (int)$stats['vip'] ?></b><span>VIP Only</span></div>
      <div class="hero-mini"><i class="fa-solid fa-shield-halved"></i><b><?= (int)$stats['admin'] ?></b><span>Admin Only</span></div>
    </div>
  </section>

  <?php if ($flash !== ''): ?><div class="notice"><i class="fa-solid fa-circle-check"></i><?= bm_api_manager_e($flash) ?></div><?php endif; ?>
  <?php if ($error !== ''): ?><div class="notice error"><i class="fa-solid fa-triangle-exclamation"></i><?= bm_api_manager_e($error) ?></div><?php endif; ?>

  <div class="toolbar">
    <div class="toolbar-copy">
      <b>پریست سریع سطح دسترسی</b>
      <small>فقط Radioهای سطح دسترسی را تغییر می‌دهد؛ برای اعمال نهایی «ذخیره تنظیمات» را بزن.</small>
    </div>
    <div class="preset-row">
      <button class="btn" type="button" data-scope-preset="public"><i class="fa-solid fa-earth-americas"></i> همه عمومی</button>
      <button class="btn" type="button" data-scope-preset="member"><i class="fa-solid fa-user-check"></i> فقط اعضا</button>
      <button class="btn" type="button" data-scope-preset="vip"><i class="fa-solid fa-crown"></i> همه VIP</button>
      <button class="btn" type="button" data-scope-preset="admin"><i class="fa-solid fa-shield-halved"></i> همه مدیر</button>
    </div>
  </div>

  <form method="post">
    <?= admin_csrf_input() ?>
    <input type="hidden" name="archive_api_action" value="save">

    <div class="archive-grid">
      <?php foreach ($archiveNames as $aid => $meta):
        $cfg = is_array($settings['archives'][$aid] ?? null) ? $settings['archives'][$aid] : [];
        $enabled = !empty($cfg['enabled']);
        $scope = (string)($cfg['access_scope'] ?? 'public');
        if (!isset($scopeMeta[$scope])) $scope = 'public';
        $num = (int)str_replace('archive', '', $aid);
      ?>
      <section class="archive-card" data-archive-card>
        <div class="card-head">
          <div class="card-title">
            <div class="archive-num"><?= $num ?></div>
            <div>
              <h2><?= bm_api_manager_e($meta['label']) ?></h2>
              <small><i class="fa-solid <?= bm_api_manager_e($meta['icon']) ?>"></i> <?= bm_api_manager_e($meta['connection']) ?></small>
            </div>
          </div>
          <span class="status-badge <?= $enabled ? 'on' : 'off' ?>" data-status-badge><?= $enabled ? 'فعال' : 'غیرفعال' ?></span>
        </div>

        <div class="control-box">
          <div class="control-head">
            <div><b>سرویس آرشیو</b><small>دریافت، نمایش و استفاده از داده این آرشیو</small></div>
            <label class="switch">
              <input type="checkbox" name="<?= bm_api_manager_e($aid) ?>_enabled" <?= $enabled ? 'checked' : '' ?>>
              <span class="switch-track"></span>
            </label>
          </div>
        </div>

        <div class="form-grid">
          <div class="field">
            <label class="field-label">نام دکمه در سایت</label>
            <input class="input" type="text" name="<?= bm_api_manager_e($aid) ?>_label" value="<?= bm_api_manager_e($cfg['label'] ?? $meta['label']) ?>">
          </div>
          <div class="field">
            <label class="field-label">وقتی سرویس خاموش است</label>
            <select class="select" name="<?= bm_api_manager_e($aid) ?>_disabled_mode">
              <option value="visible" <?= (($cfg['disabled_mode'] ?? 'visible') === 'visible') ? 'selected' : '' ?>>دکمه بماند + پیام</option>
              <option value="hide" <?= (($cfg['disabled_mode'] ?? 'visible') === 'hide') ? 'selected' : '' ?>>دکمه کاملاً مخفی</option>
            </select>
          </div>
          <div class="field full">
            <label class="field-label">پیام زمان خاموش بودن</label>
            <input class="input" type="text" name="<?= bm_api_manager_e($aid) ?>_disabled_message" value="<?= bm_api_manager_e($cfg['disabled_message'] ?? 'این آرشیو موقتاً در دسترس نیست و به‌زودی برمی‌گردد.') ?>">
          </div>
        </div>

        <div class="form-grid" style="margin-top:14px">
          <div class="field full">
            <label class="field-label">دامنه اصلی منبع/API</label>
            <input class="input" dir="ltr" type="url" name="<?= bm_api_manager_e($aid) ?>_source_base_url" value="<?= bm_api_manager_e($cfg['source_base_url'] ?? '') ?>" placeholder="https://source.example.com">
            <small style="display:block;margin-top:7px;color:var(--text-secondary)">با تغییر این مقدار، درخواست‌های API این آرشیو به دامنه جدید می‌روند.</small>
          </div>
          <div class="field full">
            <label class="field-label">دامنه‌ها / ساب‌دامین‌های لینک دانلود</label>
            <textarea class="input" dir="ltr" rows="3" name="<?= bm_api_manager_e($aid) ?>_download_base_urls" placeholder="https://dl1.bankmovie.top&#10;https://dl2.bankmovie.top" style="text-align:left;min-height:88px;resize:vertical"><?= bm_api_manager_e(implode("\n", (array)($cfg['download_base_urls'] ?? []))) ?></textarea>
            <small style="display:block;margin-top:7px;color:var(--text-secondary)">این‌ها دامنه‌های عمومی مسیر امن بانک‌مووی هستند، نه دامنه خام فایل. هر دامنه HTTPS در یک خط؛ ساب‌دامین باید به همین سرور اشاره کند. برای تعویض دامنه فیلترشده، همان خط را جایگزین کن.</small>
          </div>
          <div class="field">
            <label class="field-label">دسترسی لینک دانلود</label>
            <select class="select" name="<?= bm_api_manager_e($aid) ?>_download_access_scope">
              <?php $downloadScope = (string)($cfg['download_access_scope'] ?? 'public'); foreach($featureScopeMeta as $scopeId=>$smeta): ?>
              <option value="<?= bm_api_manager_e($scopeId) ?>" <?= $downloadScope === $scopeId ? 'selected' : '' ?>><?= bm_api_manager_e($smeta['label']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="field">
            <label class="field-label">دسترسی پخش آنلاین</label>
            <select class="select" name="<?= bm_api_manager_e($aid) ?>_stream_access_scope">
              <?php $streamScope = (string)($cfg['stream_access_scope'] ?? 'public'); foreach($featureScopeMeta as $scopeId=>$smeta): ?>
              <option value="<?= bm_api_manager_e($scopeId) ?>" <?= $streamScope === $scopeId ? 'selected' : '' ?>><?= bm_api_manager_e($smeta['label']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <div class="audience">
          <div class="audience-title">
            <span><i class="fa-solid fa-users-viewfinder"></i> چه کسانی این آرشیو را ببینند؟</span>
            <span class="scope-preview" data-scope-preview><?= bm_api_manager_e($scopeMeta[$scope]['desc']) ?></span>
          </div>
          <div class="segments">
            <?php foreach ($scopeMeta as $scopeId => $smeta): ?>
            <label class="segment scope-<?= bm_api_manager_e($scopeId) ?>">
              <input type="radio" name="<?= bm_api_manager_e($aid) ?>_access_scope" value="<?= bm_api_manager_e($scopeId) ?>" <?= $scope === $scopeId ? 'checked' : '' ?>>
              <span><i class="fa-solid <?= bm_api_manager_e($smeta['icon']) ?>"></i><?= bm_api_manager_e($smeta['label']) ?></span>
            </label>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="security-note">
          <i class="fa-solid fa-eye-slash"></i>
          <span>برای مخاطب غیرمجاز، دکمه آرشیو مخفی می‌شود. تلاش برای ورود مستقیم به جزئیات/API هم پاسخ دسترسی نمی‌گیرد. مدیر برای تست همیشه به همه سطح‌ها دسترسی دارد.</span>
        </div>

        <div class="connection">
          <b>تست اتصال:</b> <?= bm_api_manager_e($meta['connection']) ?>
          <div class="test-row">
            <?php if ($aid === 'archive1'): ?><a class="btn" href="api2.php?ping=1" target="_blank" rel="noopener"><i class="fa-solid fa-vial"></i> API2</a><?php endif; ?>
            <?php if ($aid === 'archive3'): ?><a class="btn" href="api6.php?ping=1" target="_blank" rel="noopener"><i class="fa-solid fa-vial"></i> API6</a><?php endif; ?>
            <?php if ($aid === 'archive4'): ?><a class="btn" href="api4.php?ping=1" target="_blank" rel="noopener"><i class="fa-solid fa-vial"></i> API4</a><?php endif; ?>
            <a class="btn" href="/?archive=<?= $num ?>" target="_blank" rel="noopener"><i class="fa-solid fa-eye"></i> پیش‌نمایش سایت</a>
          </div>
        </div>
      </section>
      <?php endforeach; ?>
    </div>

    <div class="savebar">
      <p><i class="fa-solid fa-lock"></i> سطح دسترسی در تب‌های خانه، جستجو، مشاهده همه، ژانرها، صفحه جزئیات و APIهای مستقیم اعمال می‌شود. آرشیو ۱ در حالت محدود با کش عمومی اشتراکی سرو نمی‌شود.</p>
      <button class="btn primary" type="submit"><i class="fa-solid fa-floppy-disk"></i> ذخیره تنظیمات آرشیوها</button>
    </div>
  </form>

  <section class="help-card">
    <h3><i class="fa-solid fa-circle-question"></i> منطق دسترسی</h3>
    <div class="help-grid">
      <div class="help-item"><i class="fa-solid fa-earth-americas"></i><b>همه</b><small>مهمان، کاربر عادی، VIP و مدیر دکمه و محتوا را می‌بینند.</small></div>
      <div class="help-item"><i class="fa-solid fa-user-check"></i><b>اعضا</b><small>برای مهمان کاملاً مخفی است؛ هر حساب واردشده به آن دسترسی دارد.</small></div>
      <div class="help-item"><i class="fa-solid fa-crown"></i><b>VIP</b><small>فقط عضویت VIP فعال و مدیر. VIP منقضی‌شده دسترسی نمی‌گیرد.</small></div>
      <div class="help-item"><i class="fa-solid fa-shield-halved"></i><b>مدیر</b><small>برای تمام کاربران حتی VIP مخفی است و فقط مدیر می‌تواند تستش کند.</small></div>
    </div>
  </section>

  <section class="help-card" id="blocked-items" style="margin-top:18px">
    <h3><i class="fa-solid fa-link-slash"></i> بستن لینک دانلود یک فیلم یا سریال مشخص</h3>
    <p style="color:var(--text-secondary);line-height:1.9">آرشیو را انتخاب و عنوان را جستجو کن. با مسدودکردن نتیجه، خود صفحه و اطلاعات فیلم باقی می‌ماند اما لینک‌های دانلود آن عنوان در سایت و APIهای مستقیم نمایش داده نمی‌شود.</p>

    <form method="get" action="api_manager.php#blocked-items" class="form-grid" style="margin-top:14px">
      <div class="field">
        <label class="field-label">آرشیو موردنظر</label>
        <select class="select" name="block_archive">
          <?php foreach($archiveNames as $aid=>$meta): ?><option value="<?= bm_api_manager_e($aid) ?>" <?= $blockSearchArchive === $aid ? 'selected' : '' ?>><?= bm_api_manager_e($meta['label']) ?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <label class="field-label">نام فیلم، سریال یا IMDb</label>
        <input class="input" type="search" name="block_q" minlength="2" value="<?= bm_api_manager_e($blockSearchQuery) ?>" placeholder="مثلاً Inception یا tt1375666" required>
      </div>
      <div class="field full"><button class="btn primary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> جستجو در آرشیو انتخابی</button></div>
    </form>

    <?php if($blockSearchError !== ''): ?><div class="notice error" style="margin-top:14px"><i class="fa-solid fa-triangle-exclamation"></i><?= bm_api_manager_e($blockSearchError) ?></div><?php endif; ?>
    <?php if($blockSearchQuery !== '' && !$blockSearchError): ?>
      <div style="display:grid;gap:10px;margin-top:16px">
      <?php if(!$blockSearchResults): ?><div class="security-note"><i class="fa-solid fa-circle-info"></i><span>نتیجه‌ای پیدا نشد. نام انگلیسی، فارسی یا شناسه IMDb را امتحان کن.</span></div><?php endif; ?>
      <?php foreach($blockSearchResults as $item): ?>
        <div class="connection" style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
          <div><b><?= bm_api_manager_e($item['title']) ?></b><?php if($item['title_en'] !== ''): ?><small style="display:block;color:var(--text-secondary);margin-top:4px" dir="ltr"><?= bm_api_manager_e($item['title_en']) ?></small><?php endif; ?><small style="display:block;color:var(--text-secondary);margin-top:5px"><?= bm_api_manager_e($item['year']) ?> <?= $item['identifier'] !== '' ? '· ' . bm_api_manager_e($item['identifier']) : '' ?></small></div>
          <form method="post" action="api_manager.php#blocked-items" onsubmit="return confirm('لینک‌های دانلود این عنوان بسته شود؟')">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="archive_api_action" value="add_blocked_item">
            <input type="hidden" name="blocked_archive_id" value="<?= bm_api_manager_e($blockSearchArchive) ?>">
            <input type="hidden" name="blocked_identifier" value="<?= bm_api_manager_e($item['identifier']) ?>">
            <input type="hidden" name="blocked_source_url" value="<?= bm_api_manager_e($item['source_url']) ?>">
            <input type="hidden" name="blocked_title" value="<?= bm_api_manager_e($item['title']) ?>">
            <input type="hidden" name="blocked_year" value="<?= bm_api_manager_e($item['year']) ?>">
            <button class="btn" type="submit"><i class="fa-solid fa-lock"></i> بستن دانلود این عنوان</button>
          </form>
        </div>
      <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <h3 style="margin-top:24px"><i class="fa-solid fa-list-check"></i> عناوین مسدودشده</h3>
    <div style="display:grid;gap:10px;margin-top:12px">
      <?php $blockedItems = array_reverse((array)($settings['blocked_items'] ?? [])); if(!$blockedItems): ?><div class="security-note"><i class="fa-solid fa-circle-check"></i><span>در حال حاضر دانلود هیچ عنوانی به‌صورت اختصاصی مسدود نشده است.</span></div><?php endif; ?>
      <?php foreach($blockedItems as $rule): ?>
        <div class="connection" style="display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap">
          <div><b><?= bm_api_manager_e($rule['title'] ?? $rule['identifier']) ?></b><small style="display:block;color:var(--text-secondary);margin-top:5px"><?= bm_api_manager_e($archiveNames[$rule['archive_id']]['label'] ?? $rule['archive_id']) ?><?= !empty($rule['year']) ? ' · ' . bm_api_manager_e($rule['year']) : '' ?><?= !empty($rule['identifier']) ? ' · ' . bm_api_manager_e($rule['identifier']) : '' ?></small></div>
          <form method="post" action="api_manager.php#blocked-items" onsubmit="return confirm('مسدودی این عنوان برداشته شود؟')">
            <?= admin_csrf_input() ?>
            <input type="hidden" name="archive_api_action" value="remove_blocked_item">
            <input type="hidden" name="blocked_rule_id" value="<?= bm_api_manager_e($rule['id']) ?>">
            <button class="btn" type="submit"><i class="fa-solid fa-unlock"></i> رفع مسدودی</button>
          </form>
        </div>
      <?php endforeach; ?>
    </div>
  </section>
</div>
</main>

<script src="/assets/js/bm-api-manager-v79.js?v=79.0" defer></script>
</body>
</html>
