<?php
$errorCode = 404;
require __DIR__ . '/includes/error_bootstrap.php';
require __DIR__ . '/includes/error_template.php';
