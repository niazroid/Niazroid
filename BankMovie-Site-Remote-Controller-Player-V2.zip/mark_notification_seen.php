<?php
// mark_notification_seen.php - تأیید امن و پایدار نوتیفیکیشن
// این endpoint فقط cookie همان کاربر را برای پنهان کردن نوتیف ست می‌کند؛ دیتابیس را تغییر نمی‌دهد.
require_once __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

function bm_notif_json(array $payload, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    bm_notif_json(['success' => false, 'error' => 'method_not_allowed'], 405);
}

// دفاع سبک در برابر درخواست‌های cross-site. برای این کار ساده CSRF سخت‌گیرانه لازم نیست،
// چون فقط cookie مرورگر همین کاربر را تنظیم می‌کند و تغییری در دیتابیس/حساب ایجاد نمی‌شود.
function bm_notif_host_only(string $host): string {
    $host = strtolower(trim($host));
    if ($host === '') return '';
    // Remove userinfo/port noise from HTTP_HOST values like example.com:443.
    if (strpos($host, '@') !== false) {
        $host = substr(strrchr($host, '@'), 1) ?: $host;
    }
    $host = preg_replace('/:\d+$/', '', $host) ?: $host;
    return preg_replace('/^www\./', '', $host) ?: $host;
}

$host = bm_notif_host_only((string)($_SERVER['HTTP_HOST'] ?? ''));
foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $key) {
    $value = (string)($_SERVER[$key] ?? '');
    if ($value === '') continue;
    $parts = @parse_url($value);
    $originHost = bm_notif_host_only((string)($parts['host'] ?? ''));
    if ($host !== '' && $originHost !== '' && !hash_equals($host, $originHost)) {
        bm_notif_json(['success' => false, 'error' => 'origin_denied'], 403);
    }
}

$notificationId = (int)($_POST['notification_id'] ?? 0);
if ($notificationId <= 0) {
    bm_notif_json(['success' => false, 'error' => 'invalid_notification_id'], 422);
}

try {
    // اگر جدول وجود داشت، فقط برای نوتیف فعال cookie بزن؛ اگر جدول/ستون مشکل داشت، کاربر را گیر ننداز.
    $shouldSetCookie = true;
    try {
        $stmt = $pdo->prepare("SELECT id FROM notifications WHERE id = ? AND is_active = 1 AND (expires_at IS NULL OR expires_at > NOW()) LIMIT 1");
        $stmt->execute([$notificationId]);
        $shouldSetCookie = (bool)$stmt->fetchColumn();
    } catch (Throwable $ignored) {
        $shouldSetCookie = true;
    }

    if (!$shouldSetCookie) {
        bm_notif_json(['success' => false, 'error' => 'notification_not_found'], 404);
    }

    $secure = (
        (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ||
        (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower((string)$_SERVER['HTTP_X_FORWARDED_PROTO']) === 'https')
    );

    $cookieName = 'notification_seen_' . $notificationId;
    setcookie($cookieName, '1', [
        'expires' => time() + 86400 * 30,
        'path' => '/',
        'secure' => $secure,
        'httponly' => false,
        'samesite' => 'Lax',
    ]);
    $_COOKIE[$cookieName] = '1';

    bm_notif_json(['success' => true, 'notification_id' => $notificationId]);
} catch (Throwable $e) {
    error_log('mark_notification_seen.php error: ' . $e->getMessage());
    bm_notif_json(['success' => false, 'error' => 'server_error'], 500);
}
