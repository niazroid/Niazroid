<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$host = 'serialblog1.top';
$url  = 'https://serialblog1.top/';

function bm_v92_public_ip(string $ip): bool {
    if (!filter_var($ip, FILTER_VALIDATE_IP)) return false;
    return (bool)filter_var(
        $ip,
        FILTER_VALIDATE_IP,
        FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
    );
}

function bm_v92_curl_test(string $url, int $mode, ?string $resolve = null): array {
    if (!function_exists('curl_init')) {
        return ['ok'=>false,'error'=>'curl_missing'];
    }

    $ch = curl_init();
    $opts = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 8,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
        CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149 Safari/537.36',
        CURLOPT_HTTPHEADER => [
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language: fa-IR,fa;q=0.9,en;q=0.7',
        ],
    ];

    if ($mode === 4 && defined('CURL_IPRESOLVE_V4')) {
        $opts[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V4;
    } elseif ($mode === 6 && defined('CURL_IPRESOLVE_V6')) {
        $opts[CURLOPT_IPRESOLVE] = CURL_IPRESOLVE_V6;
    }

    if ($resolve !== null && defined('CURLOPT_RESOLVE')) {
        $opts[CURLOPT_RESOLVE] = [$resolve];
    }

    curl_setopt_array($ch, $opts);
    $body = curl_exec($ch);

    $result = [
        'ok' => $body !== false && (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE) >= 200
            && (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE) < 400,
        'http_code' => (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE),
        'errno' => curl_errno($ch),
        'error' => curl_error($ch),
        'primary_ip' => (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP),
        'primary_port' => (int)curl_getinfo($ch, CURLINFO_PRIMARY_PORT),
        'namelookup_ms' => (int)round(((float)curl_getinfo($ch, CURLINFO_NAMELOOKUP_TIME)) * 1000),
        'connect_ms' => (int)round(((float)curl_getinfo($ch, CURLINFO_CONNECT_TIME)) * 1000),
        'tls_ms' => (int)round(((float)curl_getinfo($ch, CURLINFO_APPCONNECT_TIME)) * 1000),
        'starttransfer_ms' => (int)round(((float)curl_getinfo($ch, CURLINFO_STARTTRANSFER_TIME)) * 1000),
        'total_ms' => (int)round(((float)curl_getinfo($ch, CURLINFO_TOTAL_TIME)) * 1000),
        'body_bytes' => is_string($body) ? strlen($body) : 0,
    ];
    curl_close($ch);
    return $result;
}

function bm_v92_tcp_test(string $ip, int $port = 443): array {
    $errno = 0;
    $errstr = '';
    $started = microtime(true);
    $fp = @stream_socket_client(
        'tcp://' . $ip . ':' . $port,
        $errno,
        $errstr,
        5,
        STREAM_CLIENT_CONNECT
    );
    $ms = (int)round((microtime(true) - $started) * 1000);
    if (is_resource($fp)) fclose($fp);
    return [
        'ok' => is_resource($fp),
        'errno' => $errno,
        'error' => $errstr,
        'connect_ms' => $ms,
    ];
}

$out = [
    'build' => 'v92-api5-network-diagnostic-only',
    'time_utc' => gmdate('c'),
    'php' => PHP_VERSION,
    'server_host' => (string)($_SERVER['HTTP_HOST'] ?? ''),
    'target' => $url,
    'dns' => [
        'gethostbyname' => gethostbyname($host),
        'A' => [],
        'AAAA' => [],
    ],
    'curl' => [],
    'tcp443' => [],
];

if (function_exists('dns_get_record')) {
    $records = @dns_get_record($host, DNS_A | DNS_AAAA);
    if (is_array($records)) {
        foreach ($records as $r) {
            if (($r['type'] ?? '') === 'A' && !empty($r['ip'])) {
                $out['dns']['A'][] = (string)$r['ip'];
            }
            if (($r['type'] ?? '') === 'AAAA' && !empty($r['ipv6'])) {
                $out['dns']['AAAA'][] = (string)$r['ipv6'];
            }
        }
    }
}

$out['dns']['A'] = array_values(array_unique($out['dns']['A']));
$out['dns']['AAAA'] = array_values(array_unique($out['dns']['AAAA']));

$out['curl']['auto'] = bm_v92_curl_test($url, 0);
$out['curl']['ipv4'] = bm_v92_curl_test($url, 4);
$out['curl']['ipv6'] = bm_v92_curl_test($url, 6);

foreach (array_slice($out['dns']['A'], 0, 3) as $ip) {
    if (!bm_v92_public_ip($ip)) continue;
    $out['tcp443']['ipv4:' . $ip] = bm_v92_tcp_test($ip, 443);
    $out['curl']['resolve_ipv4:' . $ip] = bm_v92_curl_test(
        $url,
        4,
        $host . ':443:' . $ip
    );
}

foreach (array_slice($out['dns']['AAAA'], 0, 2) as $ip) {
    if (!bm_v92_public_ip($ip)) continue;
    $out['tcp443']['ipv6:' . $ip] = bm_v92_tcp_test('[' . $ip . ']', 443);
}

$summary = 'unknown';
if (!empty($out['curl']['ipv4']['ok'])) {
    $summary = 'ipv4_works';
} elseif (!empty($out['curl']['ipv6']['ok'])) {
    $summary = 'ipv6_works';
} else {
    $anyTcp = false;
    foreach ($out['tcp443'] as $row) {
        if (!empty($row['ok'])) { $anyTcp = true; break; }
    }
    if ($anyTcp) {
        $summary = 'tcp_works_but_https_fails';
    } elseif (!empty($out['dns']['A']) || !empty($out['dns']['AAAA'])) {
        $summary = 'dns_works_but_tcp443_times_out_or_blocked';
    } else {
        $summary = 'dns_resolution_failed';
    }
}
$out['summary'] = $summary;

echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
