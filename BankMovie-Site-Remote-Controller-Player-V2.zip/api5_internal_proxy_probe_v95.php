<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$out = [
    'build' => 'v95-internal-proxy-test',
    'origin' => 'https://serialblog1.top/',
];

try {
    require_once __DIR__ . '/includes/api5_lib.php';

    $proxyUrl = serialblog_internal_proxy_url('https://serialblog1.top/');
    $out['proxy_url'] = $proxyUrl;

    $started = microtime(true);
    $html = serialblog_get_html('https://serialblog1.top/');
    $out['fetch_ms'] = (int)round((microtime(true) - $started) * 1000);
    $out['html_bytes'] = strlen($html);

    $parsed = serialblog_parse_listing($html, 1, 'https://serialblog1.top/');
    $out['parse_count'] = (int)($parsed['count'] ?? 0);
    $out['ok'] = $out['parse_count'] > 0;

    if (!empty($parsed['items'][0]) && is_array($parsed['items'][0])) {
        $first = $parsed['items'][0];
        $out['first_item'] = [
            'title' => (string)($first['title'] ?? ''),
            'type' => (string)($first['type'] ?? ''),
            'url' => (string)($first['url'] ?? ''),
        ];
    }
} catch (Throwable $e) {
    http_response_code(500);
    $out['ok'] = false;
    $out['error'] = $e->getMessage();
}

echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
