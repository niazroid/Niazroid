<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';
require_once __DIR__ . '/includes/error_visual.php';

// /player - پلیر آنلاین BankMovie با هدر/فوتر هماهنگ با index و ظاهر Premium
require_once 'config.php';
require_once __DIR__ . '/includes/vip_features.php';
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('page_player_enabled');

bm_vip_gate_require('online_player', $currentUser ?? null);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$currentUser = $currentUser ?? null;

$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) {
    $userTheme = 'dark-green';
}
$currentTheme = $themes[$userTheme];

$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgbCss = hexdec(substr($themeHex, 0, 2)) . ',' . hexdec(substr($themeHex, 2, 2)) . ',' . hexdec(substr($themeHex, 4, 2));

$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

function e($str) {
    return htmlspecialchars((string)($str ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

$t = [
    'fa' => [
        'site_title' => 'پلیر آنلاین',
        'home' => 'خانه',
        'profile' => 'پروفایل',
        'player' => 'پلیر',
        'request' => 'درخواست فیلم و سریال',
        'auth' => 'ثبت نام و ورود',
        'account' => 'حساب کاربری',
        'login' => 'ورود',
        'register' => 'ثبت نام',
        'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت',
        'notifications' => 'اعلان‌ها',
        'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'donate' => 'حمایت مالی',
        'support_us' => 'حمایت مالی',
        'support_text' => 'تمام خدمات سایت رایگان است. اگر از بانک مووی راضی هستید، با یک حمایت کوچک به هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن',
        'back' => 'بازگشت',
        'headline' => 'پلیر آنلاین BankMovie',
        'headline_desc' => 'لینک مستقیم ویدیو را وارد کن، با کنترل‌های حرفه‌ای، زیرنویس دستی، قفل صفحه و تمام‌صفحه تماشا کن.',
        'enter_link' => 'لینک مستقیم ویدیو',
        'input_placeholder' => 'https://example.com/video.mp4',
        'play_video' => 'پخش ویدیو',
        'movie_player' => 'BankMovie Player',
        'player_hint' => 'برای شروع، لینک مستقیم را وارد کن و پخش را بزن.',
        'subtitle' => 'زیرنویس دستی',
        'speed' => 'سرعت پخش',
        'screen_lock' => 'قفل صفحه',
        'fullscreen' => 'تمام صفحه',
        'guide_title' => 'راهنمای پخش سریال‌های فولدری',
        'guide_desc' => 'برای سریال‌هایی که لینک فولدر دارند، وارد فولدر شوید، قسمت را باز کنید، لینک مستقیم فایل ویدیو را کپی کنید و داخل پلیر قرار دهید.',
        'step_1_title' => 'ورود به فولدر',
        'step_1_desc' => 'روی لینک دانلود سریال کلیک کنید تا وارد فولدر فصل‌ها شوید.',
        'step_2_title' => 'انتخاب قسمت',
        'step_2_desc' => 'فصل و قسمت مورد نظر را انتخاب کنید.',
        'step_3_title' => 'کپی لینک ویدیو',
        'step_3_desc' => 'روی فایل ویدیو نگه دارید یا راست‌کلیک کنید و لینک مستقیم را کپی کنید.',
        'step_4_title' => 'پخش در پلیر',
        'step_4_desc' => 'لینک را در کادر بالا قرار دهید و دکمه پخش را بزنید.',
        'subkade_title' => 'نیاز به زیرنویس فارسی دارید؟',
        'subkade_desc' => 'برای پیدا کردن زیرنویس فارسی می‌توانید از ساب‌کده استفاده کنید.',
        'search_subtitle' => 'جستجو در ساب‌کده',
        'upload_subtitle' => 'آپلود زیرنویس',
        'remove_subtitle' => 'حذف زیرنویس',
        'normal' => 'عادی',
        'quality_tip' => 'اگر پخش انجام نشد، یک لینک کیفیت پایین‌تر مثل 480p را تست کنید.',
        'shortcuts' => 'میانبرها: Space پخش/توقف، ← و → عقب/جلو، F تمام‌صفحه، M بی‌صدا.',
    ],
    'en' => [
        'site_title' => 'Online Player',
        'home' => 'Home',
        'profile' => 'Profile',
        'player' => 'Player',
        'request' => 'Request Movie / Series',
        'auth' => 'Login / Register',
        'account' => 'Account',
        'login' => 'Login',
        'register' => 'Register',
        'logout' => 'Logout',
        'admin_panel' => 'Admin Panel',
        'notifications' => 'Notifications',
        'no_notifications' => 'No notifications',
        'donate' => 'Donate',
        'support_us' => 'Support Us',
        'support_text' => 'All services are free. If you like BankMovie, you can support server and development costs.',
        'close' => 'Close',
        'back' => 'Back',
        'headline' => 'BankMovie Online Player',
        'headline_desc' => 'Paste a direct video link and watch with premium controls, manual subtitles, screen lock and fullscreen mode.',
        'enter_link' => 'Direct video link',
        'input_placeholder' => 'https://example.com/video.mp4',
        'play_video' => 'Play Video',
        'movie_player' => 'BankMovie Player',
        'player_hint' => 'Paste a direct link and press play to start.',
        'subtitle' => 'Manual subtitles',
        'speed' => 'Playback speed',
        'screen_lock' => 'Screen lock',
        'fullscreen' => 'Fullscreen',
        'guide_title' => 'Folder Series Playback Guide',
        'guide_desc' => 'For folder-based series, open the folder, select an episode, copy the direct video file link and paste it here.',
        'step_1_title' => 'Open the folder',
        'step_1_desc' => 'Click the series download link to open the season folders.',
        'step_2_title' => 'Choose episode',
        'step_2_desc' => 'Select the season and episode you want to watch.',
        'step_3_title' => 'Copy video link',
        'step_3_desc' => 'Hold or right-click the video file and copy its direct URL.',
        'step_4_title' => 'Play here',
        'step_4_desc' => 'Paste the link above and press play.',
        'subkade_title' => 'Need Persian subtitles?',
        'subkade_desc' => 'You can use Subkade to find Persian subtitles.',
        'search_subtitle' => 'Search on Subkade',
        'upload_subtitle' => 'Upload Subtitle',
        'remove_subtitle' => 'Remove Subtitle',
        'normal' => 'Normal',
        'quality_tip' => 'If playback fails, try a lower quality link such as 480p.',
        'shortcuts' => 'Shortcuts: Space play/pause, ← and → seek, F fullscreen, M mute.',
    ]
];

$notificationsList = [];
$latestNotification = null;
try {
    if (isset($pdo) && $pdo instanceof PDO) {
        $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
        $stmt->execute();
        $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $latestNotification = $notificationsList[0] ?? null;
    }
} catch (Throwable $e) {
    $notificationsList = [];
    $latestNotification = null;
}
?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>">
<head>
<meta name="theme-color" content="#05050a">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>BankMovie | <?= e($t[$userLang]['site_title']) ?></title>
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Crect width='100' height='100' rx='20' fill='%23050505'/%3E%3Cpath d='M30 25 L70 25 L75 40 L25 40 Z' fill='<?= e($currentTheme['primary']) ?>'/%3E%3Crect x='25' y='42' width='50' height='33' rx='6' fill='<?= e($currentTheme['primary']) ?>'/%3E%3Ccircle cx='50' cy='75' r='8' fill='%23050505'/%3E%3C/svg%3E">
    <style>
        @font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}
        *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
        :root{--bg-primary:#08090d;--bg-secondary:#101116;--bg-tertiary:#171922;--bg-card:#0e1017;--bg-card-hover:#151926;--accent:<?= e($currentTheme['primary']) ?>;--accent-rgb:<?= e($currentThemeRgbCss) ?>;--accent-dark:<?= e($currentTheme['primary']) ?>cc;--accent-glow:rgba(var(--accent-rgb),.14);--text-primary:#fff;--text-secondary:#a4a8b6;--text-tertiary:#6e7384;--border-subtle:rgba(255,255,255,.075);--border-accent:rgba(var(--accent-rgb),.28);--gradient-hero:linear-gradient(135deg,#fff,var(--accent));--gradient-donate:linear-gradient(135deg,#ff3366,#ff6633);--shadow-soft:0 18px 50px rgba(0,0,0,.38)}
        html{scroll-behavior:smooth}
        body{min-height:100vh;background:radial-gradient(circle at 18% -10%,rgba(var(--accent-rgb),.16),transparent 34%),radial-gradient(circle at 88% 12%,rgba(59,130,246,.08),transparent 36%),#08090d;color:var(--text-primary);font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,Segoe UI,sans-serif;overflow-x:hidden;padding-bottom:104px}
        body:fullscreen .bottom-nav,body:fullscreen .header{display:none!important}
        ::-webkit-scrollbar{width:7px;height:7px}::-webkit-scrollbar-track{background:#101116}::-webkit-scrollbar-thumb{background:var(--accent);border-radius:10px}
        svg{display:block}.no-select{user-select:none}

        .loading-overlay{position:fixed;inset:0;background:#08090d;z-index:10050;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:16px;transition:.35s ease}.loading-overlay.hide{opacity:0;visibility:hidden;pointer-events:none}.loading-spinner{width:52px;height:52px;border:3px solid rgba(255,255,255,.08);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite}.loading-text{font-size:12px;color:var(--accent);letter-spacing:2px}@keyframes spin{to{transform:rotate(360deg)}}
        .toast-container{position:fixed;top:82px;right:16px;left:16px;z-index:10040;display:flex;flex-direction:column;gap:8px;pointer-events:none}.toast{max-width:460px;margin:0 auto;background:rgba(19,22,32,.92);border:1px solid var(--border-accent);color:#fff;border-radius:999px;padding:11px 18px;backdrop-filter:blur(18px);box-shadow:0 12px 32px rgba(0,0,0,.32);font-size:13px;text-align:center;pointer-events:auto;animation:toastIn .25s ease}@keyframes toastIn{from{opacity:0;transform:translateY(-12px)}to{opacity:1;transform:translateY(0)}}

        .header{position:sticky;top:0;z-index:100;background:rgba(8,9,13,.74);border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(22px);transition:.22s ease}.header.header-solid{background:rgba(8,9,13,.94);box-shadow:0 16px 34px rgba(0,0,0,.24)}.header-inner{max-width:1400px;height:68px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:18px}.logo{display:inline-flex;align-items:center;gap:10px;text-decoration:none;color:#fff;min-width:0}.logo-icon{width:34px;height:34px;filter:drop-shadow(0 0 14px rgba(var(--accent-rgb),.28))}.logo-text{font-size:18px;font-weight:900;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent;letter-spacing:.2px}.desktop-nav{display:flex;align-items:center;gap:8px;flex:1;justify-content:center}.desktop-nav-item{display:inline-flex;align-items:center;gap:8px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:760;padding:10px 14px;border-radius:999px;border:1px solid transparent;transition:.2s ease}.desktop-nav-item svg{width:17px;height:17px;stroke:currentColor}.desktop-nav-item:hover,.desktop-nav-item.active{color:#fff;background:rgba(255,255,255,.055);border-color:rgba(255,255,255,.08)}.desktop-nav-item.active{box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18);color:var(--accent)}.header-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}.menu-btn,.notif-bell,.auth-trigger,.user-trigger,.donate-btn{border:none;cursor:pointer;color:#fff;transition:.2s ease}.menu-btn,.notif-bell{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;position:relative}.menu-btn svg,.notif-bell svg{width:20px;height:20px}.menu-btn:hover,.notif-bell:hover{background:var(--accent-glow);border-color:var(--border-accent);color:var(--accent)}.notif-badge{position:absolute;top:7px;right:9px;width:8px;height:8px;background:#ff3b5c;border-radius:50%;box-shadow:0 0 0 3px rgba(255,59,92,.15)}.donate-btn{display:inline-flex;align-items:center;gap:7px;background:var(--gradient-donate);border-radius:999px;padding:10px 16px;font-size:12px;font-weight:850;box-shadow:0 12px 28px rgba(255,51,102,.14)}.donate-btn:hover{transform:translateY(-1px);box-shadow:0 16px 32px rgba(255,51,102,.24)}.auth-dropdown{position:relative}.auth-trigger,.user-trigger{height:42px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.045);border:1px solid var(--border-subtle);border-radius:999px;padding:0 13px;font-size:12px;font-weight:760}.auth-trigger svg,.user-trigger svg{width:17px;height:17px}.auth-dropdown:hover .auth-menu{opacity:1;visibility:visible;transform:translateY(6px)}.auth-menu{position:absolute;top:100%;left:0;min-width:190px;background:rgba(17,19,28,.96);border:1px solid var(--border-subtle);border-radius:18px;padding:8px;box-shadow:var(--shadow-soft);backdrop-filter:blur(18px);opacity:0;visibility:hidden;transform:translateY(0);transition:.2s ease;z-index:120}.auth-menu a{display:flex;align-items:center;gap:9px;text-decoration:none;color:var(--text-secondary);font-size:12px;font-weight:760;padding:10px 12px;border-radius:13px}.auth-menu a:hover{background:var(--accent-glow);color:var(--accent)}.auth-menu svg{width:16px;height:16px}.menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,.68);backdrop-filter:blur(8px);z-index:180;opacity:0;visibility:hidden;transition:.22s ease}.menu-overlay.active{opacity:1;visibility:visible}.sidebar-menu{position:fixed;top:0;bottom:0;right:0;width:min(330px,88vw);background:rgba(13,15,23,.96);border-left:1px solid var(--border-subtle);z-index:190;transform:translateX(105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px);display:flex;flex-direction:column}.sidebar-menu.open{transform:translateX(0)}[dir="ltr"] .sidebar-menu{right:auto;left:0;transform:translateX(-105%)}[dir="ltr"] .sidebar-menu.open{transform:translateX(0)}.sidebar-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.sidebar-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.sidebar-close svg{width:18px;height:18px}.sidebar-user{margin:18px 18px 10px;padding:18px;border:1px solid var(--border-subtle);border-radius:24px;background:linear-gradient(145deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.035));text-align:center}.sidebar-avatar{width:58px;height:58px;border-radius:50%;margin:0 auto 10px;background:rgba(var(--accent-rgb),.12);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent)}.sidebar-avatar svg{width:28px;height:28px}.sidebar-username{font-weight:900}.sidebar-userrole{margin-top:3px;color:var(--text-tertiary);font-size:12px}.sidebar-nav,.sidebar-footer{padding:10px 14px;display:flex;flex-direction:column;gap:6px}.sidebar-nav{flex:1}.sidebar-item{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:780;padding:13px 14px;border-radius:16px;transition:.18s}.sidebar-item:hover,.sidebar-item.active{background:var(--accent-glow);color:var(--accent)}.sidebar-item svg{width:19px;height:19px}.notif-sidebar{position:fixed;top:0;bottom:0;left:0;width:min(380px,92vw);background:rgba(13,15,23,.97);border-right:1px solid var(--border-subtle);z-index:185;transform:translateX(-105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px)}[dir="ltr"] .notif-sidebar{left:auto;right:0;transform:translateX(105%);border-right:none;border-left:1px solid var(--border-subtle)}.notif-sidebar.open{transform:translateX(0)}.notif-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.notif-header h3{font-size:18px;color:var(--accent)}.notif-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.notif-close svg{width:18px;height:18px}.notif-list{padding:16px;display:flex;flex-direction:column;gap:10px}.notif-item{padding:14px;border-radius:18px;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle)}.notif-message{font-size:13px;line-height:1.7;color:#fff}.notif-date{margin-top:8px;color:var(--text-tertiary);font-size:11px}.bottom-nav{position:fixed;left:50%;bottom:calc(10px + env(safe-area-inset-bottom));transform:translateX(-50%);width:min(520px,calc(100% - 28px));height:74px;background:linear-gradient(180deg,rgba(27,31,45,.86),rgba(13,15,23,.92));border:1px solid rgba(255,255,255,.1);border-radius:34px;z-index:95;display:grid;grid-template-columns:repeat(3,1fr);align-items:center;padding:6px;box-shadow:0 18px 48px rgba(0,0,0,.44),inset 0 1px 0 rgba(255,255,255,.08);backdrop-filter:blur(22px);transition:.26s ease}.bottom-nav.nav-hidden{transform:translate(-50%,calc(100% + 28px));opacity:0;pointer-events:none}.bottom-nav.nav-compact{height:66px;opacity:.96}.nav-item{height:100%;border-radius:28px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;text-decoration:none;color:var(--text-secondary);font-size:10px;font-weight:760;transition:.2s}.nav-item svg{width:22px;height:22px;stroke:currentColor}.nav-item.active{color:var(--accent);background:linear-gradient(180deg,rgba(var(--accent-rgb),.18),rgba(var(--accent-rgb),.08));box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18)}.nav-label{font-size:10px;color:inherit}.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);z-index:10020;align-items:center;justify-content:center;padding:22px}.modal-content{background:linear-gradient(180deg,#151823,#0f1118);border:1px solid var(--border-subtle);border-radius:30px;max-width:420px;width:100%;padding:26px;text-align:center;box-shadow:var(--shadow-soft)}.btn{border:none;cursor:pointer;text-decoration:none}.btn-primary{height:46px;border-radius:999px;background:var(--accent);color:#050505;font-weight:900;display:inline-flex;align-items:center;justify-content:center}

        .page-shell{max-width:1320px;margin:0 auto;padding:26px 20px 30px}.player-hero{position:relative;overflow:hidden;border-radius:34px;margin-bottom:22px;background:radial-gradient(circle at 18% 15%,rgba(var(--accent-rgb),.24),transparent 34%),linear-gradient(135deg,rgba(255,255,255,.07),rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.09);box-shadow:var(--shadow-soft)}.player-hero:before{content:"";position:absolute;inset:-2px;background:linear-gradient(120deg,rgba(var(--accent-rgb),.18),transparent 45%,rgba(255,255,255,.05));pointer-events:none}.player-hero-inner{position:relative;z-index:2;display:grid;grid-template-columns:minmax(0,1fr) 410px;gap:22px;align-items:center;padding:32px}.hero-kicker{display:inline-flex;align-items:center;gap:8px;color:var(--accent);font-size:12px;font-weight:900;background:rgba(var(--accent-rgb),.1);border:1px solid var(--border-accent);border-radius:999px;padding:8px 12px;margin-bottom:15px}.hero-kicker svg{width:17px;height:17px}.hero-title{font-size:clamp(2rem,5vw,4.2rem);line-height:1.12;font-weight:950;letter-spacing:-.7px;margin-bottom:14px;background:linear-gradient(135deg,#fff 20%,var(--accent));-webkit-background-clip:text;background-clip:text;color:transparent}.hero-desc{font-size:15px;color:var(--text-secondary);line-height:1.9;max-width:680px}.feature-chips{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-top:18px}.feature-chip{display:inline-flex;align-items:center;gap:7px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.25);border-radius:999px;padding:8px 11px;color:#d7d9e2;font-size:12px;font-weight:800}.feature-chip svg{width:15px;height:15px;stroke:var(--accent)}.quick-input-card{position:relative;background:rgba(6,7,11,.62);border:1px solid rgba(255,255,255,.09);border-radius:28px;padding:18px;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 18px 42px rgba(0,0,0,.28);backdrop-filter:blur(16px)}.input-label{display:flex;align-items:center;gap:8px;margin-bottom:10px;color:#fff;font-size:13px;font-weight:900}.input-label svg{width:18px;height:18px;stroke:var(--accent)}.url-input{width:100%;height:50px;border-radius:999px;border:1px solid rgba(255,255,255,.09);background:rgba(0,0,0,.38);color:#fff;outline:none;padding:0 17px;font-size:13px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;direction:ltr}.url-input:focus{border-color:var(--border-accent);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.09)}.play-btn{width:100%;height:48px;margin-top:12px;border:none;border-radius:999px;background:linear-gradient(135deg,var(--accent),#fff);color:#050505;font-weight:950;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px;transition:.2s}.play-btn:hover{transform:translateY(-1px);box-shadow:0 14px 30px rgba(var(--accent-rgb),.2)}.play-btn svg{width:18px;height:18px;fill:currentColor}.quick-note{margin-top:11px;display:flex;gap:8px;color:var(--text-tertiary);font-size:11px;line-height:1.6}.quick-note svg{width:15px;height:15px;stroke:var(--accent);flex-shrink:0;margin-top:2px}

        .cinema-panel{position:relative;background:linear-gradient(180deg,rgba(17,20,30,.86),rgba(8,9,13,.9));border:1px solid rgba(255,255,255,.08);border-radius:32px;padding:18px;box-shadow:var(--shadow-soft);overflow:hidden}.cinema-panel:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 16% 0%,rgba(var(--accent-rgb),.1),transparent 34%),radial-gradient(circle at 80% 100%,rgba(255,255,255,.045),transparent 34%);pointer-events:none}.cinema-titlebar{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px}.cinema-title{display:flex;align-items:center;gap:10px;font-size:13px;font-weight:950;color:#fff}.cinema-title span{color:var(--accent)}.cinema-title svg{width:18px;height:18px;stroke:var(--accent)}.cinema-shortcuts{color:var(--text-tertiary);font-size:11px}.player-wrapper{position:relative;z-index:2;background:#000;border-radius:26px;overflow:hidden;width:100%;aspect-ratio:16/9;direction:ltr;box-shadow:0 24px 75px rgba(0,0,0,.56),0 0 0 1px rgba(255,255,255,.06),0 0 0 1px rgba(var(--accent-rgb),.11);border:1px solid rgba(255,255,255,.06)}.player-wrapper:fullscreen{border-radius:0;width:100vw;height:100vh;position:fixed;inset:0;z-index:9999;aspect-ratio:auto;background:#000}.player-wrapper:fullscreen .player-video{width:100vw;height:100vh;object-fit:contain}.player-video{width:100%;height:100%;object-fit:contain;outline:none;background:#000;cursor:pointer}.player-empty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;padding:22px;background:radial-gradient(circle at 50% 42%,rgba(var(--accent-rgb),.12),transparent 30%),linear-gradient(135deg,rgba(255,255,255,.035),transparent);pointer-events:none;transition:.2s}.player-empty.hidden{opacity:0;visibility:hidden}.empty-icon{width:74px;height:74px;border-radius:28px;margin:0 auto 14px;background:rgba(var(--accent-rgb),.1);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent);box-shadow:0 0 30px rgba(var(--accent-rgb),.13)}.empty-icon svg{width:34px;height:34px}.empty-title{font-weight:950;font-size:18px;margin-bottom:6px}.empty-desc{font-size:13px;color:var(--text-secondary)}.buffering{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:70px;height:70px;border:4px solid rgba(var(--accent-rgb),.2);border-top-color:var(--accent);border-radius:50%;animation:bufferSpin 1s linear infinite;display:none;z-index:15}@keyframes bufferSpin{to{transform:translate(-50%,-50%) rotate(360deg)}}.player-controls{position:absolute;left:0;right:0;bottom:0;z-index:10;padding:48px 16px 16px;background:linear-gradient(to top,rgba(0,0,0,.88),rgba(0,0,0,.46) 54%,transparent);opacity:0;transition:opacity .25s ease}.player-wrapper:hover .player-controls,.player-wrapper:active .player-controls,.player-wrapper:fullscreen .player-controls,.player-controls.visible{opacity:1}.progress-container{display:flex;align-items:center;gap:12px;margin-bottom:12px}.progress-time{font-size:12px;color:#fff;min-width:48px;font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;text-shadow:0 2px 8px rgba(0,0,0,.4)}.progress-bar{flex:1;height:5px;-webkit-appearance:none;appearance:none;background:linear-gradient(90deg,var(--accent) 0%,var(--accent) var(--progress,0%),rgba(255,255,255,.22) var(--progress,0%),rgba(255,255,255,.22) 100%);border-radius:999px;cursor:pointer}.progress-bar::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 0 0 4px rgba(var(--accent-rgb),.3);cursor:pointer}.progress-bar::-moz-range-thumb{width:16px;height:16px;border:0;border-radius:50%;background:#fff;box-shadow:0 0 0 4px rgba(var(--accent-rgb),.3)}.controls-row{display:flex;align-items:center;justify-content:space-between;gap:12px}.controls-left,.controls-right{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.ctrl-btn{min-width:42px;height:42px;border:none;border-radius:999px;background:rgba(255,255,255,.13);color:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px;padding:0 12px;font-size:12px;font-weight:850;backdrop-filter:blur(12px);transition:.18s}.ctrl-btn:hover{background:var(--accent);color:#050505;transform:translateY(-1px)}.ctrl-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}.volume-control{height:42px;display:flex;align-items:center;gap:8px;border-radius:999px;background:rgba(255,255,255,.09);padding:0 10px}.volume-control .ctrl-btn{background:transparent;padding:0;min-width:26px}.volume-slider{width:90px;height:4px;-webkit-appearance:none;appearance:none;border-radius:999px;background:rgba(255,255,255,.28);cursor:pointer}.volume-slider::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:var(--accent)}.settings-dropdown{position:relative}.settings-dropdown-content{position:fixed;background:rgba(16,18,27,.96);border:1px solid var(--border-accent);width:min(340px,calc(100vw - 20px));max-height:min(72vh,460px);border-radius:22px;padding:0;box-shadow:0 20px 55px rgba(0,0,0,.72),inset 0 1px 0 rgba(255,255,255,.06);opacity:0;visibility:hidden;transition:.18s;z-index:10000;backdrop-filter:blur(24px) saturate(150%);overflow:hidden}.settings-dropdown-content.active{opacity:1;visibility:visible}.player-settings-modal .settings-panel{display:none;flex-direction:column;max-height:min(72vh,460px)}.player-settings-modal .settings-panel.active{display:flex;animation:settingsPanelIn .16s ease both}@keyframes settingsPanelIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}.settings-modal-header{min-height:54px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid rgba(255,255,255,.08);color:#fff;font-size:14px;font-weight:900}.settings-modal-title{display:flex;align-items:center;gap:8px;min-width:0}.settings-modal-title svg{width:18px;height:18px;stroke:var(--accent);flex:0 0 auto}.settings-modal-subtitle{color:rgba(255,255,255,.48);font-size:11px;font-weight:750;margin-top:2px}.settings-panel-scroll{overflow-y:auto;overscroll-behavior:contain;padding:8px;max-height:calc(min(72vh,460px) - 54px)}.settings-row,.settings-choice{width:100%;min-height:48px;border:0;background:transparent;color:rgba(255,255,255,.92);font-family:inherit;text-align:inherit;cursor:pointer;border-radius:14px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:12px;transition:background .18s ease,color .18s ease,transform .18s ease}.settings-row:hover,.settings-choice:hover{background:rgba(var(--accent-rgb),.12);color:#fff}.settings-row:active,.settings-choice:active{transform:scale(.985)}.settings-row-left,.settings-choice-left{display:flex;align-items:center;gap:10px;min-width:0}.settings-row-icon{width:34px;height:34px;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;background:rgba(var(--accent-rgb),.1);color:var(--accent);flex:0 0 auto}.settings-row-icon svg{width:18px;height:18px;stroke:currentColor}.settings-row-text{display:flex;flex-direction:column;gap:2px;min-width:0}.settings-row-title{font-size:13px;font-weight:850;color:rgba(255,255,255,.92);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.settings-row-desc{font-size:11px;color:rgba(255,255,255,.48);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.settings-row-value{margin-inline-start:auto;color:rgba(255,255,255,.58);font-size:12px;font-weight:800;white-space:nowrap}.settings-row-arrow{width:16px;height:16px;stroke:rgba(255,255,255,.54);flex:0 0 auto}[dir="rtl"] .settings-row-arrow{transform:rotate(180deg)}.settings-back-btn{width:36px;height:36px;border:0;border-radius:999px;background:rgba(255,255,255,.08);color:#fff;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:.18s ease;flex:0 0 auto}.settings-back-btn:hover{background:rgba(var(--accent-rgb),.16);color:var(--accent)}.settings-back-btn svg{width:18px;height:18px;stroke:currentColor}[dir="rtl"] .settings-back-btn svg{transform:rotate(180deg)}.settings-choice{justify-content:flex-start;position:relative}.settings-choice-meta{display:flex;flex-direction:column;gap:2px;min-width:0}.settings-choice-title{font-size:13px;font-weight:850;color:rgba(255,255,255,.92)}.settings-choice-desc{font-size:11px;color:rgba(255,255,255,.48)}.settings-check{margin-inline-start:auto;width:22px;height:22px;border-radius:999px;display:inline-flex;align-items:center;justify-content:center;color:#000;background:var(--accent);opacity:0;transform:scale(.78);transition:.16s ease;flex:0 0 auto}.settings-check svg{width:14px;height:14px;stroke:currentColor;stroke-width:3}.settings-choice.active{background:rgba(var(--accent-rgb),.14);color:var(--accent)}.settings-choice.active .settings-check{opacity:1;transform:scale(1)}.settings-divider{height:1px;background:rgba(255,255,255,.08);margin:8px 4px}.settings-mini-label{padding:8px 12px 4px;color:var(--accent);font-size:11px;font-weight:900}.sleep-countdown{font-variant-numeric:tabular-nums}.player-video{filter:brightness(var(--player-brightness,1));}.subtitle-overlay{    position:absolute;left:7%;right:7%;bottom:88px;z-index:9;    display:flex;justify-content:center;align-items:flex-end;text-align:center;    pointer-events:none;direction:auto;min-height:36px;}.subtitle-overlay:empty{display:none;}.subtitle-overlay span{    display:inline-block;max-width:100%;padding:6px 12px;border-radius:10px;    background:rgba(0,0,0,.68);color:#fff;font-size:clamp(15px,2.2vw,24px);    line-height:1.55;font-weight:760;text-shadow:0 2px 5px rgba(0,0,0,.85);    box-decoration-break:clone;-webkit-box-decoration-break:clone;white-space:pre-line;}.player-wrapper:fullscreen .subtitle-overlay{bottom:110px;left:8%;right:8%;}.settings-range-card{padding:12px;border-radius:16px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.075);margin:8px 4px;}.settings-range-head{display:flex;align-items:center;justify-content:space-between;gap:10px;color:#fff;font-size:13px;font-weight:850;margin-bottom:10px;}.settings-range{width:100%;height:5px;-webkit-appearance:none;appearance:none;border-radius:999px;background:rgba(255,255,255,.22);outline:none;cursor:pointer;}.settings-range::-webkit-slider-thumb{-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.18);}.settings-range::-moz-range-thumb{width:18px;height:18px;border:0;border-radius:50%;background:var(--accent);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.18);}.settings-sync-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;padding:8px 4px;}.settings-sync-btn{min-height:42px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.055);color:#fff;font-family:inherit;font-size:12px;font-weight:850;cursor:pointer;transition:.18s ease;}.settings-sync-btn:hover{background:rgba(var(--accent-rgb),.14);border-color:var(--border-accent);color:var(--accent);}.brightness-hud{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(.96);z-index:14;min-width:132px;padding:13px 16px;border-radius:18px;background:rgba(0,0,0,.72);border:1px solid rgba(255,255,255,.12);color:#fff;text-align:center;font-size:13px;font-weight:900;opacity:0;pointer-events:none;transition:.16s ease;backdrop-filter:blur(14px);}.brightness-hud.active{opacity:1;transform:translate(-50%,-50%) scale(1);}.brightness-hud .hud-value{margin-top:4px;color:var(--accent);font-variant-numeric:tabular-nums;}@media(max-width:768px){.subtitle-overlay{bottom:76px;left:5%;right:5%;}.subtitle-overlay span{font-size:15px;padding:5px 10px}.settings-sync-grid{grid-template-columns:1fr;}}.player-wrapper.view-mode-cover .player-video{object-fit:cover;transform:none}.player-wrapper.view-mode-stretch .player-video{object-fit:fill;transform:none}.player-wrapper.view-mode-small .player-video{object-fit:contain;transform:scale(.88)}.player-wrapper.view-mode-normal .player-video{object-fit:contain;transform:none}@media(max-width:768px){.player-settings-modal{width:min(360px,calc(100vw - 18px));max-height:70vh;border-radius:22px}.player-settings-modal .settings-panel{max-height:70vh}.settings-panel-scroll{max-height:calc(70vh - 54px)}}.screen-lock-btn.locked{background:var(--accent)!important;color:#050505!important}.ui-locked .ctrl-btn,.ui-locked .progress-bar,.ui-locked .volume-slider{pointer-events:none!important;opacity:.55}.ui-locked #screenLockBtn{pointer-events:auto!important;opacity:1}

        .helper-grid{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:18px;margin-top:20px}.guide-card,.subkade-card{position:relative;overflow:hidden;background:linear-gradient(180deg,rgba(17,20,30,.86),rgba(11,12,18,.88));border:1px solid rgba(255,255,255,.08);border-radius:30px;padding:22px;box-shadow:var(--shadow-soft)}.guide-card:before,.subkade-card:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 18% 10%,rgba(var(--accent-rgb),.12),transparent 34%);pointer-events:none}.section-title{position:relative;z-index:2;display:flex;align-items:center;gap:10px;font-size:18px;font-weight:950;color:#fff;margin-bottom:10px}.section-title svg{width:22px;height:22px;stroke:var(--accent)}.section-desc{position:relative;z-index:2;color:var(--text-secondary);font-size:13px;line-height:1.8;margin-bottom:16px}.steps-grid{position:relative;z-index:2;display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.step{background:rgba(0,0,0,.22);border:1px solid rgba(255,255,255,.07);border-radius:22px;padding:15px}.step-number{width:30px;height:30px;border-radius:50%;background:var(--accent);color:#050505;font-weight:950;display:flex;align-items:center;justify-content:center;font-size:13px;margin-bottom:10px}.step-title{font-size:13px;font-weight:900;margin-bottom:7px}.step-desc{font-size:12px;color:var(--text-secondary);line-height:1.65}.info-strip{position:relative;z-index:2;margin-top:15px;padding:13px 14px;border-radius:18px;background:rgba(var(--accent-rgb),.07);border:1px solid var(--border-accent);display:flex;gap:9px;align-items:flex-start;color:var(--text-secondary);font-size:12px;line-height:1.7}.info-strip svg{width:18px;height:18px;stroke:var(--accent);flex-shrink:0;margin-top:1px}.subkade-card{text-align:center;display:flex;flex-direction:column;align-items:center;justify-content:center;min-height:100%}.subkade-icon{position:relative;z-index:2;width:72px;height:72px;border-radius:28px;background:rgba(var(--accent-rgb),.1);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent);margin-bottom:14px}.subkade-icon svg{width:32px;height:32px}.subkade-btn{position:relative;z-index:2;margin-top:4px;height:44px;border-radius:999px;background:var(--accent);color:#050505;text-decoration:none;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 20px;font-size:13px;font-weight:950}.subkade-btn:hover{box-shadow:0 14px 30px rgba(var(--accent-rgb),.18)}

        @media(max-width:1100px){.player-hero-inner{grid-template-columns:1fr}.helper-grid{grid-template-columns:1fr}.steps-grid{grid-template-columns:repeat(2,1fr)}}
        @media(max-width:991px){.desktop-nav,.auth-dropdown{display:none}.header-inner{height:62px;padding:0 14px}.donate-btn{padding:9px 12px;font-size:11px}.menu-btn,.notif-bell{width:38px;height:38px}.page-shell{padding:16px 12px 24px}.player-hero{border-radius:28px}.player-hero-inner{padding:22px}.quick-input-card{padding:15px}.cinema-panel{padding:12px;border-radius:26px}.player-wrapper{border-radius:22px}.cinema-shortcuts{display:none}.controls-row{align-items:flex-end}.ctrl-btn{min-width:38px;height:38px}.volume-control{display:none}.controls-left .ctrl-btn.seek-extra{display:none}.settings-dropdown-content{min-width:210px}.steps-grid{grid-template-columns:1fr}.bottom-nav{display:grid}}
        @media(min-width:992px){.bottom-nav{display:none!important}.menu-btn{display:none}.page-shell{padding-top:28px}}
        @media(max-width:540px){body{padding-bottom:96px}.logo-text{font-size:15px}.donate-btn{display:none}.player-hero-inner{padding:18px}.hero-title{font-size:2rem}.hero-desc{font-size:13px}.feature-chip{font-size:11px;padding:7px 9px}.url-input{height:48px}.player-controls{padding:42px 10px 12px}.progress-container{gap:8px}.progress-time{font-size:11px;min-width:41px}.controls-right{gap:6px}.ctrl-btn{min-width:36px;height:36px;padding:0 10px}.helper-grid{gap:14px}.guide-card,.subkade-card{padding:18px;border-radius:25px}}
    

/* ===== BankMovie Player Pro UX: theatre, in-player toast, advanced HUD, lock, mobile gestures ===== */
.player-toast-stack{position:absolute;top:16px;left:50%;transform:translateX(-50%);z-index:42;width:min(92%,520px);display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none}.player-toast{max-width:100%;padding:10px 15px;border-radius:999px;background:rgba(12,14,20,.78);border:1px solid rgba(255,255,255,.13);color:#fff;font-size:12px;font-weight:850;line-height:1.6;text-align:center;box-shadow:0 12px 34px rgba(0,0,0,.42),0 0 0 1px rgba(var(--accent-rgb),.10);backdrop-filter:blur(18px) saturate(150%);-webkit-backdrop-filter:blur(18px) saturate(150%);animation:playerToastIn .22s cubic-bezier(.2,.8,.2,1) both}.player-toast.hide{animation:playerToastOut .18s ease both}@keyframes playerToastIn{from{opacity:0;transform:translateY(-10px) scale(.97)}to{opacity:1;transform:translateY(0) scale(1)}}@keyframes playerToastOut{to{opacity:0;transform:translateY(-8px) scale(.98)}}.player-wrapper:fullscreen .player-toast-stack{top:max(18px,env(safe-area-inset-top))}.player-hud{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%) scale(.92);z-index:41;min-width:142px;max-width:min(84%,320px);padding:16px 18px;border-radius:24px;background:rgba(6,7,11,.72);border:1px solid rgba(255,255,255,.14);box-shadow:0 18px 52px rgba(0,0,0,.52),inset 0 1px 0 rgba(255,255,255,.08);backdrop-filter:blur(20px) saturate(160%);-webkit-backdrop-filter:blur(20px) saturate(160%);color:#fff;text-align:center;opacity:0;pointer-events:none;transition:opacity .18s ease,transform .18s ease}.player-hud.active{opacity:1;transform:translate(-50%,-50%) scale(1)}.player-hud-icon{width:48px;height:48px;margin:0 auto 8px;border-radius:18px;display:flex;align-items:center;justify-content:center;background:rgba(var(--accent-rgb),.16);border:1px solid rgba(var(--accent-rgb),.25);color:var(--accent);font-size:23px;font-weight:950}.player-hud-title{font-size:12px;font-weight:900;color:rgba(255,255,255,.76);margin-bottom:3px}.player-hud-value{font-size:20px;font-weight:950;color:#fff;line-height:1.25;font-variant-numeric:tabular-nums}.player-hud-bar{height:5px;margin-top:11px;border-radius:999px;background:rgba(255,255,255,.18);overflow:hidden}.player-hud-bar span{display:block;height:100%;width:var(--hud-progress,0%);border-radius:inherit;background:linear-gradient(90deg,var(--accent),#fff);transition:width .12s ease}.player-hud.pulse .player-hud-icon{animation:hudPulse .42s ease}@keyframes hudPulse{50%{transform:scale(1.1)}}.player-wrapper.ui-locked .player-controls{opacity:0!important;visibility:hidden!important;pointer-events:none!important}.player-wrapper.ui-locked .settings-dropdown-content{display:none!important}.player-wrapper.ui-locked .subtitle-overlay{bottom:54px}.unlock-overlay{position:absolute;inset:0;z-index:39;display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,rgba(0,0,0,.08),rgba(0,0,0,.24));opacity:0;visibility:hidden;pointer-events:none;transition:.2s ease}.player-wrapper.ui-locked .unlock-overlay{opacity:1;visibility:visible;pointer-events:auto}.unlock-pill{height:46px;border:none;border-radius:999px;padding:0 18px;display:inline-flex;align-items:center;justify-content:center;gap:9px;background:rgba(255,255,255,.12);color:#fff;font-family:inherit;font-size:13px;font-weight:950;cursor:pointer;border:1px solid rgba(255,255,255,.16);box-shadow:0 16px 42px rgba(0,0,0,.34);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);transition:.18s ease}.unlock-pill:hover{background:var(--accent);color:#050505;transform:translateY(-1px)}.unlock-pill svg{width:18px;height:18px;stroke:currentColor}.settings-dropdown-content{transform-origin:bottom center}.settings-dropdown-content.active{animation:settingsPopIn .2s cubic-bezier(.2,.8,.2,1) both}.player-settings-modal .settings-panel.active{animation:settingsSlideIn .22s cubic-bezier(.2,.8,.2,1) both}@keyframes settingsPopIn{from{opacity:0;transform:translateY(8px) scale(.96);filter:blur(2px)}to{opacity:1;transform:translateY(0) scale(1);filter:blur(0)}}@keyframes settingsSlideIn{from{opacity:0;transform:translateX(14px)}to{opacity:1;transform:translateX(0)}}[dir="rtl"] .player-settings-modal .settings-panel.active{animation:settingsSlideInRtl .22s cubic-bezier(.2,.8,.2,1) both}@keyframes settingsSlideInRtl{from{opacity:0;transform:translateX(-14px)}to{opacity:1;transform:translateX(0)}}body.bm-theatre-active{background:var(--bg-primary)!important}body.bm-theatre-active:before{display:none!important;content:none!important}body.bm-theatre-active .player-wrapper{position:relative;z-index:2;box-shadow:0 28px 70px rgba(0,0,0,.58),0 0 0 1px rgba(var(--accent-rgb),.18)!important}body.bm-theatre-active .cinema-panel{position:relative;z-index:1;max-width:1500px;margin-left:auto;margin-right:auto}body.bm-theatre-active .header,body.bm-theatre-active .bottom-nav{opacity:1;transition:opacity .2s ease}body.bm-theatre-active .movie-detail,body.bm-theatre-active .download-section,body.bm-theatre-active .comments-section,body.bm-theatre-active .related-section,body.bm-theatre-active .subkade-box{visibility:visible!important;opacity:1!important}.mobile-gesture-hint{position:absolute;left:14px;right:14px;top:50%;transform:translateY(-50%);z-index:2;display:none;pointer-events:none}.player-wrapper.gesture-active-left:before,.player-wrapper.gesture-active-right:before{content:"";position:absolute;top:0;bottom:0;width:50%;z-index:3;pointer-events:none;background:rgba(var(--accent-rgb),.08)}.player-wrapper.gesture-active-left:before{left:0}.player-wrapper.gesture-active-right:before{right:0}@media(max-width:768px){.player-toast-stack{top:10px;width:min(94%,420px)}.player-toast{font-size:11px;padding:8px 12px}.player-hud{min-width:126px;padding:13px 15px;border-radius:20px}.player-hud-icon{width:42px;height:42px;border-radius:16px;font-size:20px}.player-hud-value{font-size:18px}.unlock-pill{height:44px;font-size:12px}body.bm-theatre-active .player-wrapper{border-radius:18px}}

    
/* ===== Fix pass: stable settings, subtitle color, better mobile gestures ===== */
.player-hud-icon svg{width:26px;height:26px;stroke:currentColor;stroke-width:2.2;fill:none}
.subtitle-overlay span{color:var(--subtitle-color,#fff)!important}
.subtitle-color-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin:8px 4px 12px}.subtitle-color-btn{height:38px;border:1px solid rgba(255,255,255,.12);border-radius:14px;background:rgba(255,255,255,.05);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:.16s ease}.subtitle-color-btn:hover,.subtitle-color-btn.active{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.12);transform:translateY(-1px)}.subtitle-color-dot{width:20px;height:20px;border-radius:999px;border:2px solid rgba(0,0,0,.42);box-shadow:0 0 0 1px rgba(255,255,255,.2)}
.speed-touch-card{margin:8px 4px 12px;padding:13px;border-radius:20px;background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(255,255,255,.035));border:1px solid rgba(255,255,255,.085);touch-action:none;user-select:none}.speed-touch-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px;color:#fff;font-size:13px;font-weight:900}.speed-touch-value{font-size:22px;font-weight:950;color:var(--accent);font-variant-numeric:tabular-nums}.speed-touch-pad{height:118px;border-radius:22px;display:flex;align-items:center;justify-content:center;text-align:center;color:rgba(255,255,255,.72);font-size:12px;font-weight:850;line-height:1.7;background:radial-gradient(circle at 50% 0%,rgba(var(--accent-rgb),.18),transparent 58%),rgba(0,0,0,.22);border:1px dashed rgba(var(--accent-rgb),.28);position:relative;overflow:hidden}.speed-touch-pad:before{content:"";position:absolute;left:18px;right:18px;top:50%;height:2px;border-radius:999px;background:rgba(255,255,255,.14);box-shadow:0 -34px 0 rgba(255,255,255,.06),0 34px 0 rgba(255,255,255,.06)}.speed-touch-pad span{position:relative;z-index:2}.settings-range.speed-range{margin-top:10px}.settings-dropdown-content{will-change:transform,opacity}.player-settings-modal *{touch-action:manipulation}.player-settings-modal .settings-range,.player-settings-modal input[type="range"],.speed-touch-card{touch-action:none}.player-wrapper.gesture-active-left:before,.player-wrapper.gesture-active-right:before{background:linear-gradient(180deg,rgba(var(--accent-rgb),.14),rgba(var(--accent-rgb),.05));box-shadow:inset 0 0 34px rgba(var(--accent-rgb),.16)}.player-wrapper.gesture-active-left:after,.player-wrapper.gesture-active-right:after{position:absolute;top:50%;transform:translateY(-50%);z-index:4;pointer-events:none;color:#fff;font-size:11px;font-weight:950;letter-spacing:.3px;padding:8px 10px;border-radius:999px;background:rgba(0,0,0,.42);border:1px solid rgba(255,255,255,.14);backdrop-filter:blur(14px)}.player-wrapper.gesture-active-left:after{content:"BRIGHTNESS";left:16px}.player-wrapper.gesture-active-right:after{content:"VOLUME";right:16px}
@media(max-width:768px){.subtitle-overlay{left:4%;right:4%;bottom:46px;min-height:26px}.player-wrapper:fullscreen .subtitle-overlay{bottom:max(58px,calc(env(safe-area-inset-bottom) + 46px));left:4%;right:4%}.subtitle-overlay span{font-size:clamp(13px,4vw,18px);line-height:1.45;padding:5px 9px;border-radius:9px}.player-wrapper.ui-locked .subtitle-overlay{bottom:42px}.speed-touch-pad{height:104px}.player-wrapper.gesture-active-left:after{content:"نور"}.player-wrapper.gesture-active-right:after{content:"صدا"}}
@media(min-width:992px){.desktop-nav .request-link{display:none!important}.header-actions .donate-btn{display:none!important}.player-donate-side{display:inline-flex!important}}
.player-donate-side{display:none;align-items:center;justify-content:center;gap:8px;height:44px;padding:0 16px;border:0;border-radius:999px;background:var(--gradient-donate);color:#fff;font-family:inherit;font-size:12px;font-weight:950;cursor:pointer;text-decoration:none;box-shadow:0 14px 34px rgba(255,51,102,.18);transition:.18s ease;white-space:nowrap}.player-donate-side:hover{transform:translateY(-1px);box-shadow:0 18px 38px rgba(255,51,102,.28)}.player-donate-side svg{width:16px;height:16px;stroke:currentColor}
.movie-page .related-section{position:relative;overflow:hidden;background:linear-gradient(180deg,rgba(18,18,24,.70),rgba(10,10,14,.56));padding:18px;border-radius:30px!important}.movie-page .related-section:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 12% 0%,rgba(var(--accent-rgb),.12),transparent 38%);pointer-events:none}.movie-page .related-section>.section-title,.movie-page .related-scroll{position:relative;z-index:1}.movie-page .related-scroll{gap:16px;padding:8px 4px 18px;scroll-snap-type:x proximity;scroll-behavior:smooth;mask-image:linear-gradient(90deg,transparent,#000 24px,#000 calc(100% - 24px),transparent);-webkit-mask-image:linear-gradient(90deg,transparent,#000 24px,#000 calc(100% - 24px),transparent)}.movie-page .related-card{width:148px;border-radius:24px;background:linear-gradient(180deg,rgba(255,255,255,.06),rgba(255,255,255,.025));border:1px solid rgba(255,255,255,.09);box-shadow:0 12px 30px rgba(0,0,0,.24);scroll-snap-align:start;transform:translateZ(0)}.movie-page .related-card:hover{transform:translateY(-8px) scale(1.025);border-color:rgba(var(--accent-rgb),.42);box-shadow:0 22px 44px rgba(0,0,0,.36),0 0 24px rgba(var(--accent-rgb),.12)}.movie-page .related-poster{transition:transform .35s ease,filter .35s ease}.movie-page .related-card:hover .related-poster{transform:scale(1.045);filter:saturate(1.12) contrast(1.04)}.movie-page .genre-link{display:inline-flex;align-items:center;min-height:26px;padding:4px 10px;border-radius:999px;background:rgba(var(--accent-rgb),.10);border:1px solid rgba(var(--accent-rgb),.18);color:var(--accent)!important;transition:.18s ease}.movie-page .genre-link:hover{background:var(--accent);color:#050505!important;border-color:var(--accent);text-shadow:none;transform:translateY(-1px);box-shadow:0 10px 22px rgba(var(--accent-rgb),.18)}


/* ===== Performance + SRT repair pass ===== */
.player-wrapper{contain:layout paint;isolation:isolate;transform:translateZ(0)}
.player-video{transform:translateZ(0)}
.player-controls{transition:opacity .18s ease}
.settings-dropdown-content,.player-hud,.player-toast,.unlock-pill{backdrop-filter:blur(12px) saturate(135%);-webkit-backdrop-filter:blur(12px) saturate(135%)}
.player-toast{box-shadow:0 8px 22px rgba(0,0,0,.34)}
.player-hud{transition:opacity .14s ease,transform .14s ease}
.subtitle-overlay span{white-space:pre-line;direction:auto}
@media(max-width:768px){.settings-dropdown-content,.player-hud,.player-toast,.unlock-pill{backdrop-filter:blur(8px) saturate(120%);-webkit-backdrop-filter:blur(8px) saturate(120%)}.player-controls{transition:opacity .14s ease}.subtitle-overlay{bottom:38px}.player-wrapper:fullscreen .subtitle-overlay{bottom:max(44px,calc(env(safe-area-inset-bottom) + 34px))}}



/* ===== Final fix: theatre applies only to video wrapper + settings opens inside player ===== */
body.bm-theatre-active{background:inherit!important}
body.bm-theatre-active:before{display:initial!important}
body.bm-theatre-active .header,
body.bm-theatre-active .bottom-nav,
body.bm-theatre-active .movie-detail,
body.bm-theatre-active .download-section,
body.bm-theatre-active .comments-section,
body.bm-theatre-active .related-section,
body.bm-theatre-active .subkade-box,
body.bm-theatre-active .guide-card,
body.bm-theatre-active .subkade-card,
body.bm-theatre-active .helper-grid{visibility:visible!important;opacity:1!important;filter:none!important}
.player-wrapper.bm-theatre-active{box-shadow:0 30px 82px rgba(0,0,0,.72),0 0 0 1px rgba(var(--accent-rgb),.22),0 0 60px rgba(var(--accent-rgb),.12)!important;border-color:rgba(var(--accent-rgb),.28)!important}
.player-wrapper.bm-theatre-active::before{content:"";position:absolute;inset:0;z-index:1;pointer-events:none;background:radial-gradient(circle at 50% 50%,transparent 42%,rgba(0,0,0,.22) 100%)}
.player-wrapper.bm-theatre-active .player-video{position:relative;z-index:2}
.player-wrapper.bm-theatre-active .player-controls{position:absolute;z-index:10}
.player-wrapper.bm-theatre-active .subtitle-overlay{position:absolute;z-index:18}
.player-wrapper.bm-theatre-active .player-toast-stack{position:absolute;z-index:42}
.player-wrapper.bm-theatre-active .player-hud{position:absolute;z-index:41}
.player-wrapper.bm-theatre-active .unlock-overlay{position:absolute;z-index:39}
.player-wrapper .settings-dropdown-content.player-settings-modal{z-index:45;max-height:min(460px,calc(100% - 24px));overflow:hidden}
.player-wrapper:fullscreen .settings-dropdown-content.player-settings-modal{max-height:min(560px,calc(100vh - 34px))}
.player-wrapper .settings-dropdown-content.player-settings-modal.active{pointer-events:auto}
@media(min-width:992px){.player-wrapper.bm-theatre-active{transform:none!important}}
@media(max-width:768px){.player-wrapper .settings-dropdown-content.player-settings-modal{max-height:calc(100% - 18px)}}



/* ===== Final mobile subtitle fit: player page ===== */
@media(max-width:768px){
    .player-wrapper .subtitle-overlay{
        bottom:12px!important;
        left:4%!important;
        right:4%!important;
        min-height:22px!important;
        transform:none!important;
    }
    .player-wrapper:fullscreen .subtitle-overlay{
        bottom:max(14px,calc(env(safe-area-inset-bottom) + 10px))!important;
        left:4%!important;
        right:4%!important;
    }
    .player-wrapper.ui-locked .subtitle-overlay{bottom:12px!important;}
    .player-wrapper .subtitle-overlay span{
        font-size:clamp(12px,3.7vw,17px)!important;
        line-height:1.38!important;
        padding:4px 9px!important;
        border-radius:9px!important;
        max-width:100%!important;
    }
}

    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<link rel="stylesheet" href="/assets/css/bm-uiverse-error-v114.css?v=114">
    <link rel="stylesheet" href="/assets/css/bm-error-integration-v114.css?v=114">
    <link rel="stylesheet" href="/assets/css/bm-player-controls-v116.css?v=116">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">

<link rel="stylesheet" href="/assets/css/bm-uiverse-elements-v42.css?v=42.0">
</head>
<body data-theme="<?= e($userTheme) ?>">
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>
<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header">
        <span class="logo-text">BankMovie</span>
        <button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <?php if($currentUser): ?>
    <div class="sidebar-user">
        <div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="sidebar-username"><?= e($currentUser['username'] ?? '') ?></div>
        <div class="sidebar-userrole"><?= ($currentUser['role'] ?? '') === 'admin' ? $t[$userLang]['admin_panel'] : $t[$userLang]['account'] ?></div>
    </div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/player" class="sidebar-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if(($currentUser['role'] ?? '') === 'admin'): ?>
        <a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang === 'fa' ? 'آیا از خروج مطمئن هستید؟' : 'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header">
        <h3><?= $t[$userLang]['notifications'] ?></h3>
        <button class="notif-close" id="closeNotifSidebar" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'] ?? '')) ?></div><div class="notif-date"><?= !empty($notif['created_at']) ? e(date('Y/m/d H:i', strtotime($notif['created_at']))) : '' ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<main class="page-shell">
    <section class="player-hero">
        <div class="player-hero-inner">
            <div>
                <div class="hero-kicker"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><?= $t[$userLang]['movie_player'] ?></div>
                <h1 class="hero-title"><?= $t[$userLang]['headline'] ?></h1>
                <p class="hero-desc"><?= $t[$userLang]['headline_desc'] ?></p>
                <div class="feature-chips">
                    <span class="feature-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg><?= $t[$userLang]['subtitle'] ?></span>
                    <span class="feature-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg><?= $t[$userLang]['speed'] ?></span>
                    <span class="feature-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg><?= $t[$userLang]['screen_lock'] ?></span>
                    <span class="feature-chip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg><?= $t[$userLang]['fullscreen'] ?></span>
                </div>
            </div>
            <div class="quick-input-card">
                <div class="input-label"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg><?= $t[$userLang]['enter_link'] ?></div>
                <input type="text" id="videoUrl" class="url-input" placeholder="<?= e($t[$userLang]['input_placeholder']) ?>" value="<?= isset($_GET['url']) ? e($_GET['url']) : '' ?>">
                <button class="play-btn" id="playBtn" type="button"><svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg><?= $t[$userLang]['play_video'] ?></button>
                <div class="quick-note"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg><span><?= $t[$userLang]['quality_tip'] ?></span></div>
            </div>
        </div>
    </section>

    <section class="cinema-panel" id="playerArea">
        <div class="cinema-titlebar">
            <div class="cinema-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg><span><?= $t[$userLang]['movie_player'] ?></span></div>
            <div class="cinema-shortcuts"><?= $t[$userLang]['shortcuts'] ?></div>

            <button class="player-donate-side" id="playerDonateSideBtn" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><?= $t[$userLang]['donate'] ?></button>

        </div>
        <div class="player-wrapper" id="playerWrapper">
            <video id="videoPlayer" class="player-video" playsinline preload="metadata" controlslist="nodownload noremoteplayback" disableremoteplayback oncontextmenu="return false"></video>
            <div class="subtitle-overlay" id="subtitleOverlay"></div>
            <div class="brightness-hud" id="brightnessHud"><div><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></div><div class="hud-value" id="brightnessHudValue">100%</div></div>
        <div class="player-toast-stack" id="playerToastStack" aria-live="polite"></div>
        <div class="player-hud" id="playerHud" aria-hidden="true"><div class="player-hud-icon" id="playerHudIcon">•</div><div class="player-hud-title" id="playerHudTitle"></div><div class="player-hud-value" id="playerHudValue"></div><div class="player-hud-bar"><span id="playerHudBar"></span></div></div>
        <div class="unlock-overlay" id="unlockOverlay"><button type="button" class="unlock-pill" id="unlockOverlayBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 9.5-2.3"/></svg><span><?= $userLang === 'fa' ? 'باز کردن قفل' : 'Unlock controls' ?></span></button></div>
            <div class="player-empty" id="playerEmpty">
                <div>
                    <div class="empty-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></div>
                    <div class="empty-title"><?= $t[$userLang]['movie_player'] ?></div>
                    <div class="empty-desc"><?= $t[$userLang]['player_hint'] ?></div>
                </div>
            </div>
            <div class="bm-player-error-overlay" id="playerErrorOverlay" hidden role="alertdialog" aria-modal="true" aria-labelledby="playerErrorTitle">
                <div class="bm-player-error-card">
                    <?= bm_error_tv_markup([
                        'id' => 'playerErrorTv',
                        'code' => 'E4',
                        'title' => $userLang === 'fa' ? 'پخش انجام نشد' : 'Playback failed',
                        'message' => $userLang === 'fa' ? 'لینک یا سرور را بررسی کنید' : 'Check the link or server',
                        'variant' => 'player',
                    ]) ?>
                    <div class="bm-player-error-copy">
                        <span class="bm-player-error-kicker" id="playerErrorKicker"><?= $userLang === 'fa' ? 'پیام پلیر' : 'Player message' ?></span>
                        <h3 id="playerErrorTitle"><?= $userLang === 'fa' ? 'پخش ویدیو انجام نشد' : 'Video playback failed' ?></h3>
                        <p id="playerErrorMessage"><?= $userLang === 'fa' ? 'لینک ویدیو یا دسترسی سرور را بررسی کنید و دوباره تلاش کنید.' : 'Check the video link or server access and try again.' ?></p>
                        <div class="bm-player-error-actions">
                            <button class="bm-player-error-btn bm-player-error-btn--primary" id="playerErrorRetry" type="button"><?= $userLang === 'fa' ? 'تلاش دوباره' : 'Try again' ?></button>
                            <button class="bm-player-error-btn" id="playerErrorClose" type="button"><?= $userLang === 'fa' ? 'بستن پیام' : 'Close' ?></button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="buffering" id="bufferingIndicator"></div>
            <div class="player-controls" id="playerControls">
                <div class="progress-container">
                    <span class="progress-time" id="currentTimeDisplay">00:00</span>
                    <input type="range" id="progressBar" class="progress-bar" min="0" max="100" value="0">
                    <span class="progress-time" id="durationDisplay">00:00</span>
                </div>
                <div class="controls-row">
                    <div class="controls-left">
                        <button class="ctrl-btn" id="playPauseBtn" type="button" aria-label="Play/Pause"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
                        <button class="ctrl-btn seek-extra" id="seekBack10Btn" type="button" aria-label="Back 10"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="10 9 6 12 10 15"/><polyline points="18 9 14 12 18 15"/></svg><span>10</span></button>
                        <button class="ctrl-btn seek-extra" id="seekForward10Btn" type="button" aria-label="Forward 10"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="14 9 18 12 14 15"/><polyline points="6 9 10 12 6 15"/></svg><span>10</span></button>
                        <div class="volume-control">
                            <button class="ctrl-btn bm-sound-toggle" id="volumeBtn" type="button" aria-label="قطع یا وصل صدا" aria-pressed="false"><span class="bm-sound-speaker" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="M39.389 13.769 22.235 28.606H6v19.093h15.989l17.4 15.051V13.769Z"/><path d="M48 27.6a19.5 19.5 0 0 1 0 21.4M55.1 20.5a30 30 0 0 1 0 35.6M61.6 14a38.8 38.8 0 0 1 0 48.6" class="bm-sound-waves"/></svg></span><span class="bm-sound-muted" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="m39 14-17 15H6v19h16l17 15Z"/><path d="m49 26 20 24m0-24-20 24" class="bm-sound-x"/></svg></span></button>
                            <input type="range" id="volumeSlider" class="volume-slider" min="0" max="100" value="100">
                        </div>
                    </div>
                    <div class="controls-right">
                        <div class="settings-dropdown">
                            <button class="ctrl-btn" id="settingsBtn" type="button" aria-label="Settings"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06A2 2 0 1 1 7.1 4.3l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg></button>
                            <div class="settings-dropdown-content player-settings-modal" id="settingsDropdown" dir="<?= e($dir) ?>">
                                <div class="settings-panel settings-main-panel active" data-settings-panel="main">
                                    <div class="settings-modal-header">
                                        <div class="settings-modal-title">
                                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.6 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06A2 2 0 1 1 7.1 4.3l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9c.14.31.49 1 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                                            <div>
                                                <div><?= $userLang === 'fa' ? 'تنظیمات پخش' : 'Playback settings' ?></div>
                                                <div class="settings-modal-subtitle"><?= $userLang === 'fa' ? 'سرعت، تصویر، زیرنویس و زمان‌سنج خواب' : 'Speed, picture, subtitle and sleep timer' ?></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="settings-panel-scroll">
                                        <button type="button" class="settings-row" id="openSpeedPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'مودال اختصاصی قابل اسکرول' : 'Scrollable dedicated panel' ?></span></span></span><span class="settings-row-value" id="currentSpeedLabel">1x</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                        <button type="button" class="settings-row" id="openPictureModePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7z"/><path d="M14 15h3"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'عادی، بزرگ، کشیده 16:9 یا کوچک‌تر' : 'Normal, zoom, 16:9 stretch or smaller' ?></span></span></span><span class="settings-row-value" id="currentPictureModeLabel"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>


                                        <button type="button" class="settings-row" id="openTheatrePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/><path d="M7 11h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'بزرگ‌تر شدن پلیر و تاریک شدن اطراف' : 'Larger player with darker surroundings' ?></span></span></span><span class="settings-row-value" id="currentTheatreModeLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                        <button type="button" class="settings-row" id="openBrightnessPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'روشنایی' : 'Brightness' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'کنترل نور با منو یا ژست لمسی' : 'Adjust by menu or touch gesture' ?></span></span></span><span class="settings-row-value" id="currentBrightnessLabel">100%</span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                        <button type="button" class="settings-row" id="openSleepTimerPanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'توقف خودکار پخش بعد از زمان انتخابی' : 'Automatically pause playback after a selected time' ?></span></span></span><span class="settings-row-value sleep-countdown" id="currentSleepTimerLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                        <div class="settings-divider"></div>
                                        <button type="button" class="settings-row" id="openSubtitlePanel"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'آپلود، حذف و سینک با تاخیر دقیق' : 'Upload, remove and sync delay precisely' ?></span></span></span><span class="settings-row-value" id="currentSubtitleLabel"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><svg class="settings-row-arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
                                        <input type="file" id="subtitleUpload" accept=".srt,.vtt,.ssa,.ass" style="display:none">

                                    </div>
                                </div>
                                <div class="settings-panel" data-settings-panel="speed"><div class="settings-modal-header"><button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button><div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'سرعت پخش' : 'Playback speed' ?></span></div></div><div class="settings-panel-scroll" id="speedSettingsList">

                                    <div class="speed-touch-card" id="speedTouchCard">
                                        <div class="speed-touch-head"><span><?= $userLang === 'fa' ? 'تنظیم لمسی سرعت' : 'Touch speed control' ?></span><strong class="speed-touch-value" id="speedTouchValue">1x</strong></div>
                                        <div class="speed-touch-pad" id="speedTouchPad"><span><?= $userLang === 'fa' ? 'مثل کنترل آیفونی، اینجا را بالا/پایین بکش' : 'Swipe up/down here like an iOS control' ?></span></div>
                                        <input type="range" class="settings-range speed-range" id="speedRange" min="0.25" max="2" step="0.05" value="1">
                                    </div>
                                    <button type="button" class="settings-choice speed-opt" data-speed="0.25"><span class="settings-choice-left"><span class="settings-choice-title">0.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="0.5"><span class="settings-choice-left"><span class="settings-choice-title">0.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="0.75"><span class="settings-choice-left"><span class="settings-choice-title">0.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt active" data-speed="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title">1x</span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="1.25"><span class="settings-choice-left"><span class="settings-choice-title">1.25x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="1.5"><span class="settings-choice-left"><span class="settings-choice-title">1.5x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="1.75"><span class="settings-choice-left"><span class="settings-choice-title">1.75x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice speed-opt" data-speed="2"><span class="settings-choice-left"><span class="settings-choice-title">2x</span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div></div>
                                <div class="settings-panel" data-settings-panel="picture"><div class="settings-modal-header"><button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button><div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت تصویر' : 'Picture mode' ?></span></div></div><div class="settings-panel-scroll" id="pictureModeSettingsList">
                                    <button type="button" class="settings-choice picture-mode-opt active" data-picture-mode="normal"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان حالت فعلی پلیر' : 'Current default player view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice picture-mode-opt" data-picture-mode="cover"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'بزرگ / پرکننده' : 'Zoom / fill' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر قاب را پر می‌کند؛ ممکن است کمی برش بخورد' : 'Fills the frame; edges may crop slightly' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice picture-mode-opt" data-picture-mode="stretch"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کشیده 16:9' : '16:9 stretch' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمام قاب 16:9 بدون حاشیه، با کشیدگی احتمالی' : 'No side bars, may stretch the image' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice picture-mode-opt" data-picture-mode="small"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تصویر کمی کوچک‌تر داخل قاب نمایش داده می‌شود' : 'Shows the video slightly smaller inside the frame' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div></div>

                                <div class="settings-panel" data-settings-panel="subtitle">
                                    <div class="settings-modal-header">
                                        <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                        <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زیرنویس' : 'Subtitle' ?></span></div>
                                    </div>
                                    <div class="settings-panel-scroll">
                                        <button type="button" class="settings-row" id="uploadSubtitleOption"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'آپلود زیرنویس' : 'Upload subtitle' ?></span><span class="settings-row-desc"><?= $userLang === 'fa' ? 'SRT، VTT و ASS ساده' : 'SRT, VTT and basic ASS' ?></span></span></span></button>
                                        <button type="button" class="settings-row" id="toggleSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="settings-row-text"><span class="settings-row-title"><?= $userLang === 'fa' ? 'نمایش زیرنویس' : 'Show subtitles' ?></span><span class="settings-row-desc" id="subtitleVisibilityLabel"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></span></span><span class="settings-row-value" id="subtitleToggleValue"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span></button>
                                        <button type="button" class="settings-row" id="removeSubtitleOption" style="display:none;"><span class="settings-row-left"><span class="settings-row-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg></span><span class="settings-row-title"><?= $userLang === 'fa' ? 'حذف زیرنویس' : 'Remove subtitle' ?></span></span></button>
                                        
                                        <div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'رنگ زیرنویس' : 'Subtitle color' ?></div>
                                        <div class="subtitle-color-grid">
                                            <button type="button" class="subtitle-color-btn active" data-subtitle-color="#ffffff" title="White"><span class="subtitle-color-dot" style="background:#ffffff"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ffd84d" title="Yellow"><span class="subtitle-color-dot" style="background:#ffd84d"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#36ff9f" title="Green"><span class="subtitle-color-dot" style="background:#36ff9f"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#7dd3fc" title="Blue"><span class="subtitle-color-dot" style="background:#7dd3fc"></span></button>
                                            <button type="button" class="subtitle-color-btn" data-subtitle-color="#ff9ad5" title="Pink"><span class="subtitle-color-dot" style="background:#ff9ad5"></span></button>
                                        </div>
<div class="settings-divider"></div>
                                        <div class="settings-mini-label"><?= $userLang === 'fa' ? 'سینک و تاخیر زیرنویس' : 'Subtitle sync / delay' ?></div>
                                        <div class="settings-range-card">
                                            <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'تاخیر فعلی' : 'Current delay' ?></span><strong id="subtitleDelayLabel">0.0s</strong></div>
                                            <input type="range" class="settings-range" id="subtitleDelayRange" min="-5" max="5" step="0.1" value="0">
                                        </div>
                                        <div class="settings-sync-grid">
                                            <button type="button" class="settings-sync-btn" id="subtitleEarlierBtn"><?= $userLang === 'fa' ? 'زودتر -0.1s' : 'Earlier -0.1s' ?></button>
                                            <button type="button" class="settings-sync-btn" id="subtitleResetDelayBtn"><?= $userLang === 'fa' ? 'ریست' : 'Reset' ?></button>
                                            <button type="button" class="settings-sync-btn" id="subtitleLaterBtn"><?= $userLang === 'fa' ? 'دیرتر +0.1s' : 'Later +0.1s' ?></button>
                                        </div>
                                        <div class="settings-choice-desc" style="padding:6px 8px 10px;line-height:1.8;"><?= $userLang === 'fa' ? 'گام تنظیم ۰.۱ ثانیه است تا دقیق‌تر از پرش‌های چندثانیه‌ای باشد.' : 'Adjustment step is 0.1s for precise subtitle sync.' ?></div>
                                    </div>
                                </div>


                                <div class="settings-panel" data-settings-panel="theatre">
                                    <div class="settings-modal-header">
                                        <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                        <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode' ?></span></div>
                                    </div>
                                    <div class="settings-panel-scroll">
                                        <button type="button" class="settings-choice theatre-opt active" data-theatre="off"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'نمای عادی صفحه' : 'Normal page view' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <button type="button" class="settings-choice theatre-opt" data-theatre="on"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن' : 'On' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تمرکز روی فیلم بدون تمام‌صفحه' : 'Focus on video without fullscreen' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'این حالت فقط با انتخاب کاربر فعال می‌شود و فول‌اسکرین را جایگزین نمی‌کند.' : 'This mode only turns on when selected and does not replace fullscreen.' ?></div>
                                    </div>
                                </div>

                                <div class="settings-panel" data-settings-panel="brightness">
                                    <div class="settings-modal-header">
                                        <button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
                                        <div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'روشنایی تصویر' : 'Brightness' ?></span></div>
                                    </div>
                                    <div class="settings-panel-scroll">
                                        <div class="settings-range-card">
                                            <div class="settings-range-head"><span><?= $userLang === 'fa' ? 'میزان نور' : 'Brightness level' ?></span><strong id="brightnessPercentLabel">100%</strong></div>
                                            <input type="range" class="settings-range" id="brightnessRange" min="40" max="160" step="5" value="100">
                                        </div>
                                        <button type="button" class="settings-choice brightness-preset" data-brightness="0.7"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'کم‌نور' : 'Dim' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <button type="button" class="settings-choice brightness-preset active" data-brightness="1"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'عادی' : 'Normal' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'همان نور اصلی ویدیو' : 'Original video brightness' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <button type="button" class="settings-choice brightness-preset" data-brightness="1.25"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'روشن‌تر' : 'Brighter' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <button type="button" class="settings-choice brightness-preset" data-brightness="1.5"><span class="settings-choice-left"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خیلی روشن' : 'Very bright' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                        <div class="settings-choice-desc" style="padding:10px 8px;line-height:1.8;"><?= $userLang === 'fa' ? 'روی موبایل با کشیدن انگشت بالا/پایین روی نیمه چپ پلیر هم نور تغییر می‌کند.' : 'On mobile, swipe up/down on the left half of the player to adjust brightness.' ?></div>
                                    </div>
                                </div>
                                <div class="settings-panel" data-settings-panel="sleep"><div class="settings-modal-header"><button type="button" class="settings-back-btn" data-settings-back><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button><div class="settings-modal-title"><span><?= $userLang === 'fa' ? 'زمان‌سنج خواب' : 'Sleep timer' ?></span></div></div><div class="settings-panel-scroll" id="sleepTimerSettingsList">
                                    <button type="button" class="settings-choice sleep-opt active" data-sleep-minutes="0"><span class="settings-choice-left"><span class="settings-choice-meta"><span class="settings-choice-title"><?= $userLang === 'fa' ? 'خاموش' : 'Off' ?></span><span class="settings-choice-desc"><?= $userLang === 'fa' ? 'تایمر فعال نیست' : 'No active timer' ?></span></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="10"><span class="settings-choice-left"><span class="settings-choice-title">10 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="15"><span class="settings-choice-left"><span class="settings-choice-title">15 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="30"><span class="settings-choice-left"><span class="settings-choice-title">30 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="45"><span class="settings-choice-left"><span class="settings-choice-title">45 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="60"><span class="settings-choice-left"><span class="settings-choice-title">60 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="90"><span class="settings-choice-left"><span class="settings-choice-title">90 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button><button type="button" class="settings-choice sleep-opt" data-sleep-minutes="120"><span class="settings-choice-left"><span class="settings-choice-title">120 <?= $userLang === 'fa' ? 'دقیقه' : 'minutes' ?></span></span><span class="settings-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg></span></button>
                                </div></div>
                            </div>                            </div>
                        </div>
                        <button class="ctrl-btn download-control-btn" id="downloadBtn" type="button" aria-label="Download"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3v12"/><polyline points="7 10 12 15 17 10"/><path d="M5 21h14a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2"/></svg></button>
                        <button class="ctrl-btn screen-lock-btn unlocked" id="screenLockBtn" type="button" aria-label="Lock"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg></button>
                        <button class="ctrl-btn" id="fullscreenBtn" type="button" aria-label="Fullscreen"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/></svg></button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="helper-grid">
        <div class="guide-card">
            <div class="section-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg><?= $t[$userLang]['guide_title'] ?></div>
            <p class="section-desc"><?= $t[$userLang]['guide_desc'] ?></p>
            <div class="steps-grid">
                <div class="step"><div class="step-number">1</div><div class="step-title"><?= $t[$userLang]['step_1_title'] ?></div><div class="step-desc"><?= $t[$userLang]['step_1_desc'] ?></div></div>
                <div class="step"><div class="step-number">2</div><div class="step-title"><?= $t[$userLang]['step_2_title'] ?></div><div class="step-desc"><?= $t[$userLang]['step_2_desc'] ?></div></div>
                <div class="step"><div class="step-number">3</div><div class="step-title"><?= $t[$userLang]['step_3_title'] ?></div><div class="step-desc"><?= $t[$userLang]['step_3_desc'] ?></div></div>
                <div class="step"><div class="step-number">4</div><div class="step-title"><?= $t[$userLang]['step_4_title'] ?></div><div class="step-desc"><?= $t[$userLang]['step_4_desc'] ?></div></div>
            </div>
            <div class="info-strip"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M18 10a4 4 0 0 0-4-4h-4a4 4 0 0 0-4 4M12 2v4M6 2v4M18 2v4"/><rect x="2" y="8" width="20" height="13" rx="2"/><path d="M8 13h8"/></svg><span><?= $t[$userLang]['quality_tip'] ?></span></div>
        </div>
        <div class="subkade-card">
            <div class="subkade-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
            <div class="section-title" style="justify-content:center;margin-bottom:8px;"><?= $t[$userLang]['subkade_title'] ?></div>
            <p class="section-desc" style="margin-bottom:16px;"><?= $t[$userLang]['subkade_desc'] ?></p>
            <a href="https://subkade.ir/" target="_blank" rel="noopener" class="subkade-btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><?= $t[$userLang]['search_subtitle'] ?></a>
        </div>
    </section>
</main>

<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('player.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<div class="bottom-nav" data-mobile-bottom-nav aria-label="Mobile bottom navigation">
    <a href="/" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span class="nav-label"><?= $t[$userLang]['home'] ?></span></a>
    <a href="/search" class="nav-item bm-footer-search-trigger" aria-haspopup="dialog" aria-controls="bmQuickSearchModal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span class="nav-label"><?= (($userLang ?? $currentLanguage ?? 'fa') === 'en') ? 'Search' : 'جستجو' ?></span></a>
    <a href="/player" class="nav-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span class="nav-label"><?= $t[$userLang]['player'] ?></span></a>
    <a href="<?= $currentUser ? '/profile' : '/login' ?>" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span class="nav-label"><?= $currentUser ? $t[$userLang]['profile'] : $t[$userLang]['login'] ?></span></a>
</div>

<div id="donateModal" class="modal">
    <div class="modal-content">
        <div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
        <h3 style="margin-bottom:10px;font-size:22px;"><?= $t[$userLang]['support_us'] ?></h3>
        <p style="color:var(--text-secondary);margin-bottom:20px;font-size:13px;line-height:1.8;"><?= $t[$userLang]['support_text'] ?></p>
        <button id="openDonateLink" class="btn btn-primary" style="width:100%;"><?= $t[$userLang]['donate'] ?></button>
        <button id="closeDonateModal" type="button" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer;"><?= $t[$userLang]['close'] ?></button>
    </div>
</div>

<script>
const userLang = <?= json_encode($userLang, JSON_UNESCAPED_UNICODE) ?>;
let video = null;
let wrapper = null;
let controls = null;
let settingsDropdown = null;
let isUILocked = false;
let wakeLock = null;
let controlsTimeout = null;
let currentSubtitleTrack = null;
let subtitleCues = [];
let subtitleDelay = 0;
let subtitlesEnabled = true;
let currentSubtitleName = '';
let subtitleColor = '#ffffff';
let activeSubtitleCueIndex = -1;
let lastSubtitleHtml = '';
let currentBrightness = 1;
let toastTimeout = null;
let playerEventsAttached = false;
let currentPlaybackRate = 1;
let currentPictureMode = 'normal';
let sleepTimerId = null;
let sleepTimerTickId = null;
let sleepTimerEndsAt = null;
let theatreModeEnabled = false;

function bmPlayerSettingsOpen() {
    return !!(settingsDropdown && settingsDropdown.classList.contains('active'));
}

function bmHidePlayerControls(force = false) {
    if (!wrapper || !controls) return;
    if (!force) {
        if (!video || video.paused || video.ended || bmPlayerSettingsOpen() || isUILocked) return;
    }
    clearTimeout(controlsTimeout);
    controlsTimeout = null;
    wrapper.classList.remove('controls-visible');
    controls.classList.remove('visible');
    const active = document.activeElement;
    if (active && controls.contains(active) && typeof active.blur === 'function') active.blur();
}

function bmShowPlayerControls(autoHide = true) {
    if (!wrapper || !controls || isUILocked) return;
    wrapper.classList.add('controls-visible');
    controls.classList.add('visible');
    clearTimeout(controlsTimeout);
    controlsTimeout = null;
    if (autoHide && video && !video.paused && !video.ended && !bmPlayerSettingsOpen()) {
        controlsTimeout = setTimeout(() => {
            if (video && !video.paused && !video.ended && !bmPlayerSettingsOpen() && !isUILocked) {
                bmHidePlayerControls(true);
            }
        }, 2200);
    }
}

function bmKeepPlayerControlsVisible() {
    if (!wrapper || !controls) return;
    clearTimeout(controlsTimeout);
    controlsTimeout = null;
    wrapper.classList.add('controls-paused', 'controls-visible');
    controls.classList.add('visible');
}

function bmEnterStandalonePlaybackMode() {
    document.body.classList.add('bm-player-session-active');
    requestAnimationFrame(() => {
        if (wrapper) wrapper.scrollIntoView({ block: 'start' });
    });
}

function bmLeaveStandalonePlaybackMode() {
    document.body.classList.remove('bm-player-session-active');
}

// ========== توابع کمکی ==========
function showPlayerToast(msg) {
    const text = String(msg || '').replace(/<[^>]*>/g, '').trim();
    const stack = document.getElementById('playerToastStack');
    if (!text || !stack) return;
    stack.querySelectorAll('.player-toast').forEach(old => old.classList.add('hide'));
    const item = document.createElement('div');
    item.className = 'player-toast';
    item.textContent = text;
    stack.appendChild(item);
    setTimeout(() => item.classList.add('hide'), 2600);
    setTimeout(() => item.remove(), 2850);
}
function volumeHudSvg(percent) {
    const muted = Number(percent) <= 0;
    return muted ?
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="19" y1="9" x2="15" y2="13"/><line x1="15" y1="9" x2="19" y2="13"/></svg>' :
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>';
}
function brightnessHudSvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>';
}
function speedHudSvg() {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/><path d="M12 7v5h5"/></svg>';
}
function seekHudSvg(dir) {
    return dir === 'back' ?
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="11 7 6 12 11 17"/><polyline points="18 7 13 12 18 17"/></svg>' :
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="13 7 18 12 13 17"/><polyline points="6 7 11 12 6 17"/></svg>';
}
function showPlayerHud(title, value, progress = null, icon = '•') {
    const hud = document.getElementById('playerHud');
    if (!hud) return;
    const titleEl = document.getElementById('playerHudTitle');
    const valueEl = document.getElementById('playerHudValue');
    const iconEl = document.getElementById('playerHudIcon');
    const barEl = document.getElementById('playerHudBar');
    if (titleEl) titleEl.textContent = String(title || '');
    if (valueEl) valueEl.textContent = String(value || '');
    if (iconEl) {
        const iconHtml = String(icon || '•');
        if (iconHtml.trim().startsWith('<svg')) iconEl.innerHTML = iconHtml;
        else iconEl.textContent = iconHtml;
    }
    if (barEl) {
        const pct = progress === null ? 0 : Math.max(0, Math.min(100, Number(progress) * 100));
        barEl.style.setProperty('--hud-progress', pct + '%');
        barEl.style.width = pct + '%';
        barEl.parentElement.style.display = progress === null ? 'none' : 'block';
    }
    hud.classList.remove('active', 'pulse');
    void hud.offsetWidth;
    hud.classList.add('active', 'pulse');
    clearTimeout(hud._timer);
    hud._timer = setTimeout(() => hud.classList.remove('active'), 850);
}
function showToast(msg) {
    const text = String(msg || '');
    showPlayerToast(text);
    if (toastTimeout) clearTimeout(toastTimeout);
    const container = document.getElementById('toastContainer');
    if (!container) return;
    container.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = text;
    container.appendChild(t);
    toastTimeout = setTimeout(() => { if (t) t.remove();
        toastTimeout = null; }, 3000);
}
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (!overlay) return;
    overlay.classList.add('hide');
    setTimeout(() => { overlay.style.display = 'none'; }, 400);
}
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (!overlay) return;
    overlay.style.display = 'flex';
    requestAnimationFrame(() => overlay.classList.remove('hide'));
}
function formatTime(s) {
    if (isNaN(s) || !isFinite(s)) return '00:00';
    let m = Math.floor(s / 60),
        sec = Math.floor(s % 60);
    if (m >= 60) {
        let h = Math.floor(m / 60);
        m = m % 60;
        return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
    }
    return `${m.toString().padStart(2,'0')}:${sec.toString().padStart(2,'0')}`;
}
function srtToVtt(srt) {
    return String(srt || '').replace(/\r/g, '').replace(/,(?=\d{1,3}\s*-->)/g, '.').replace(/-->([^\n]*?),(?=\d{1,3})/g, '-->$1.');
}
function isSafeVideoUrl(url) {
    try { const u = new URL(String(url || ''));
        return ['http:', 'https:'].includes(u.protocol); } catch (e) { return false; }
}
function setProgressVisual(value) {
    const bar = document.getElementById('progressBar');
    if (bar) bar.style.setProperty('--progress', `${Math.max(0,Math.min(100,value||0))}%`);
}

// ========== توابع راه‌اندازی منو و ناوبری ==========
function setupMenu() {
    const menuBtn = document.getElementById('menuBtn'),
        sidebar = document.getElementById('sidebarMenu'),
        overlay = document.getElementById('menuOverlay'),
        closeBtn = document.getElementById('closeMenuBtn');
    if (!menuBtn || !sidebar || !overlay || !closeBtn) return;

    function openMenu() { sidebar.classList.add('open');
        overlay.classList.add('active');
        document.body.style.overflow = 'hidden';
        menuBtn.setAttribute('aria-expanded', 'true'); }

    function closeMenu() { sidebar.classList.remove('open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
        menuBtn.setAttribute('aria-expanded', 'false'); }
    menuBtn.addEventListener('click', openMenu);
    closeBtn.addEventListener('click', closeMenu);
    overlay.addEventListener('click', closeMenu);
    window.addEventListener('resize', () => { if (window.innerWidth >= 992) closeMenu(); });
}
function setupHeaderScroll() {
    const header = document.getElementById('siteHeader');
    if (!header) return;

    function update() { header.classList.toggle('header-solid', (window.scrollY || 0) > 20); }
    update();
    window.addEventListener('scroll', update, { passive: true });
}
function setupSmartBottomNav() {
    const nav = document.querySelector('.bottom-nav');
    if (!nav) return;
    let lastY = window.scrollY || 0,
        ticking = false;

    function keep() { const ae = document.activeElement; return window.innerWidth >= 992 || window.scrollY < 100 || document.body.style.overflow === 'hidden' || document.querySelector('.sidebar-menu.open') || (ae && ['INPUT', 'TEXTAREA', 'SELECT'].includes(ae.tagName)); }

    function update() {
        const y = window.scrollY || 0,
            diff = y - lastY;
        if (keep()) { nav.classList.remove('nav-hidden');
            nav.classList.toggle('nav-compact', y > 220);
            lastY = y;
            ticking = false; return; }
        if (Math.abs(diff) > 12) { nav.classList.toggle('nav-hidden', diff > 0);
            nav.classList.toggle('nav-compact', y > 220 && diff <= 0);
            lastY = y; }
        ticking = false;
    }
    window.addEventListener('scroll', () => { if (!ticking) { requestAnimationFrame(update);
            ticking = true; } }, { passive: true });
    window.addEventListener('resize', update);
    document.addEventListener('focusin', update);
    document.addEventListener('focusout', () => setTimeout(update, 80));
    update();
}
function setupNotifications() {
    const bell = document.getElementById('notifBell'),
        sidebar = document.getElementById('notifSidebar'),
        close = document.getElementById('closeNotifSidebar');
    if (!bell || !sidebar || !close) return;
    bell.addEventListener('click', () => sidebar.classList.add('open'));
    bell.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault();
            sidebar.classList.add('open'); } });
    close.addEventListener('click', () => sidebar.classList.remove('open'));
    document.addEventListener('click', e => { if (sidebar.classList.contains('open') && !sidebar.contains(e.target) && !bell.contains(e.target)) sidebar.classList.remove('open'); });
}
function setupDonate() {
    const btn = document.getElementById('donateModalBtn'),
        sideBtn = document.getElementById('playerDonateSideBtn'),
        modal = document.getElementById('donateModal'),
        close = document.getElementById('closeDonateModal'),
        open = document.getElementById('openDonateLink');
    if (btn && modal) btn.onclick = () => modal.style.display = 'flex';
    if (sideBtn && modal) sideBtn.onclick = () => modal.style.display = 'flex';
    if (close && modal) close.onclick = () => modal.style.display = 'none';
    if (open && modal) open.onclick = () => { window.open('https://daramet.com/manuel', '_blank');
        modal.style.display = 'none'; };
    if (modal) modal.addEventListener('click', e => { if (e.target === modal) modal.style.display = 'none'; });
}

// ========== توابع زیرنویس ==========
function resetVideoElement() {
    if (!video) video = document.getElementById('videoPlayer');
    video.pause();
    video.removeAttribute('src');
    video.load();
    video.querySelectorAll('track').forEach(t => video.removeChild(t));
    currentSubtitleTrack = null;
    subtitleCues = [];
    currentSubtitleName = '';
    subtitleDelay = 0;
    subtitlesEnabled = true;
    activeSubtitleCueIndex = -1;
    lastSubtitleHtml = '';
    const subtitleOverlay = document.getElementById('subtitleOverlay');
    if (subtitleOverlay) subtitleOverlay.innerHTML = '';
    const removeSubtitleOption = document.getElementById('removeSubtitleOption');
    if (removeSubtitleOption) removeSubtitleOption.style.display = 'none';
}

function escapeSubtitleHtml(text) { return String(text || '').replace(/[&<>]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' } [ch])); }

function parseSubTime(t) {
    const raw = String(t || '').trim().replace(',', '.');
    const m = raw.match(/(?:(\d+):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?/);
    if (!m) return 0;
    const h = parseInt(m[1] || '0', 10),
        mi = parseInt(m[2] || '0', 10),
        sec = parseInt(m[3] || '0', 10),
        ms = parseInt((m[4] || '0').padEnd(3, '0').slice(0, 3), 10);
    return h * 3600 + mi * 60 + sec + ms / 1000;
}

function cleanSubText(text) {
    return String(text || '')
        .replace(/^\d+\s*$/gm, '')
        .replace(/\{\\[^}]+\}/g, '')
        .replace(/<\/?(font|b|i|u|c|ruby|rt|v)[^>]*>/gi, '')
        .replace(/<[^>]+>/g, '')
        .replace(/\\N/g, '\n')
        .replace(/\r/g, '')
        .split('\n')
        .map(x => x.trim())
        .filter(Boolean)
        .join('\n')
        .trim();
}

function srtToVtt(srt) {
    let text = String(srt || '').replace(/^\uFEFF/, '').replace(/\u0000/g, '').replace(/\r\n?/g, '\n');
    text = text.replace(/(\d{1,2}:\d{2}:\d{2}),(\d{1,3})/g, '$1.$2');
    if (!/^WEBVTT/i.test(text.trim())) text = 'WEBVTT\n\n' + text;
    return text;
}

function parseVttOrSrt(content) {
    const cues = [];
    let text = String(content || '').replace(/^\uFEFF/, '').replace(/\u0000/g, '').replace(/\r\n?/g, '\n');
    text = text.replace(/^WEBVTT[^\n]*(?:\n|$)/i, '');
    text = text.replace(/\nSTYLE[\s\S]*?(?=\n\s*\n|$)/gi, '\n');
    text = text.replace(/\nREGION[\s\S]*?(?=\n\s*\n|$)/gi, '\n');
    if (!text.trim()) return cues;
    const blocks = text.split(/\n{2,}/);
    for (const block of blocks) {
        const lines = block.split('\n').map(l => l.trimEnd()).filter(l => l.trim() !== '');
        if (!lines.length) continue;
        if (/^(WEBVTT|NOTE|STYLE|REGION)\b/i.test(lines[0].trim())) continue;
        const timingIndex = lines.findIndex(l => /\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}/.test(l));
        if (timingIndex < 0) continue;
        const timing = lines[timingIndex].trim();
        const parts = timing.split(/\s*-->\s*/);
        const start = parseSubTime(parts[0]);
        const end = parseSubTime((parts[1] || '').trim().split(/\s+/)[0]);
        const body = cleanSubText(lines.slice(timingIndex + 1).join('\n'));
        if (end > start && body) cues.push({ start, end, text: body });
    }
    if (cues.length) return cues.sort((a, b) => a.start - b.start);
    // fallback
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
        if (!lines[i].includes('-->')) continue;
        const parts = lines[i].trim().split(/\s*-->\s*/);
        const start = parseSubTime(parts[0]);
        const end = parseSubTime((parts[1] || '').trim().split(/\s+/)[0]);
        const body = [];
        for (let j = i + 1; j < lines.length; j++) {
            const next = lines[j];
            if (next.includes('-->')) break;
            if (next.trim() === '' && body.length) break;
            if (!/^\d+$/.test(next.trim())) body.push(next);
        }
        const cueText = cleanSubText(body.join('\n'));
        if (end > start && cueText) cues.push({ start, end, text: cueText });
    }
    return cues.sort((a, b) => a.start - b.start);
}

function parseAss(content) {
    const cues = [];
    let format = [];
    for (const raw of String(content || '').replace(/^\uFEFF/, '').split(/\r?\n/)) {
        const line = raw.trim();
        if (/^Format:/i.test(line)) format = line.replace(/^Format:/i, '').split(',').map(x => x.trim().toLowerCase());
        else if (/^Dialogue:/i.test(line)) {
            const body = line.replace(/^Dialogue:/i, '');
            const parts = body.split(/,(?=(?:[^{}]*\{[^}]*\})*[^{}]*$)/);
            const startIdx = format.indexOf('start'),
                endIdx = format.indexOf('end'),
                textIdx = format.indexOf('text');
            if (startIdx >= 0 && endIdx >= 0 && textIdx >= 0 && parts.length > textIdx) {
                const start = parseSubTime(parts[startIdx]);
                const end = parseSubTime(parts[endIdx]);
                const text = cleanSubText(parts.slice(textIdx).join(','));
                if (end > start && text) cues.push({ start, end, text });
            }
        }
    }
    return cues.sort((a, b) => a.start - b.start);
}

function parseSubtitleFile(file, content) {
    const name = file?.name || '';
    if (/\.(ass|ssa)$/i.test(name)) return parseAss(content);
    let cues = parseVttOrSrt(content);
    if (!cues.length) cues = parseVttOrSrt(srtToVtt(content));
    activeSubtitleCueIndex = -1;
    lastSubtitleHtml = '';
    return cues;
}

async function readSubtitleText(file) {
    const buffer = await file.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    const decode = (enc, fatal = false) => new TextDecoder(enc, { fatal }).decode(buffer).replace(/^\uFEFF/, '');
    const hasTiming = text => /\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}\s*-->\s*\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}/.test(String(text || ''));
    const looksMojibake = text => /(?:Ø|Ù|Û|Ã|Â|â€|â€™|ï»¿)/.test(String(text || ''));
    const scoreText = text => {
        const s = String(text || '');
        return (s.match(/-->/g) || []).length * 80 +
            (s.match(/[\u0600-\u06FF]/g) || []).length * 3 +
            (s.match(/[A-Za-z0-9]/g) || []).length * 0.05 -
            (s.match(/�/g) || []).length * 120 -
            (looksMojibake(s) ? 220 : 0) -
            (s.match(/\u0000/g) || []).length * 80;
    };
    try {
        if (bytes[0] === 0xFF && bytes[1] === 0xFE) return decode('utf-16le');
        if (bytes[0] === 0xFE && bytes[1] === 0xFF) return decode('utf-16be');
        if (bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) return decode('utf-8', true);
    } catch (e) {}
    try {
        const utf8 = decode('utf-8', true);
        if (hasTiming(utf8) && !looksMojibake(utf8)) return utf8;
    } catch (e) {}
    const candidates = [];
    ['windows-1256', 'utf-8', 'windows-1252', 'iso-8859-1'].forEach(enc => { try { candidates.push([enc, decode(enc, false)]); } catch (e) {} });
    try { candidates.push(['file.text', await file.text()]); } catch (e) {}
    let best = '',
        bestScore = -1e9;
    for (const [enc, text] of candidates) {
        const sc = scoreText(text) + (enc === 'windows-1256' ? 25 : 0);
        if (sc > bestScore) { bestScore = sc;
            best = text; }
    }
    return String(best || '').replace(/^\uFEFF/, '');
}

function updateSubtitleUI() {
    const loaded = subtitleCues.length > 0;
    const delayText = (subtitleDelay > 0 ? '+' : '') + subtitleDelay.toFixed(1) + 's';
    document.getElementById('subtitleDelayLabel') && (document.getElementById('subtitleDelayLabel').textContent = delayText);
    document.getElementById('subtitleDelayRange') && (document.getElementById('subtitleDelayRange').value = subtitleDelay.toFixed(1));
    if (currentSubtitleLabel) currentSubtitleLabel.textContent = loaded ? (subtitlesEnabled ? (currentSubtitleName || 'On') : (userLang === 'fa' ? 'خاموش' : 'Off')) : (userLang === 'fa' ? 'خاموش' : 'Off');
    document.getElementById('subtitleToggleValue') && (document.getElementById('subtitleToggleValue').textContent = subtitlesEnabled ? (userLang === 'fa' ? 'روشن' : 'On') : (userLang === 'fa' ? 'خاموش' : 'Off'));
    document.getElementById('subtitleVisibilityLabel') && (document.getElementById('subtitleVisibilityLabel').textContent = subtitlesEnabled ? (userLang === 'fa' ? 'روشن' : 'On') : (userLang === 'fa' ? 'خاموش' : 'Off'));
    document.getElementById('toggleSubtitleOption') && (document.getElementById('toggleSubtitleOption').style.display = loaded ? 'flex' : 'none');
    document.getElementById('removeSubtitleOption') && (document.getElementById('removeSubtitleOption').style.display = loaded ? 'flex' : 'none');
    document.querySelectorAll('.subtitle-color-btn').forEach(btn => btn.classList.toggle('active', (btn.dataset.subtitleColor || '').toLowerCase() === subtitleColor.toLowerCase()));
}

function renderCustomSubtitle() {
    const box = document.getElementById('subtitleOverlay');
    if (!box || !video) return;
    box.style.setProperty('--subtitle-color', subtitleColor);
    if (!subtitlesEnabled || !subtitleCues.length) {
        if (lastSubtitleHtml !== '') { box.innerHTML = '';
            lastSubtitleHtml = ''; }
        return;
    }
    const t = video.currentTime - subtitleDelay;
    let cue = null;
    if (activeSubtitleCueIndex >= 0) {
        const current = subtitleCues[activeSubtitleCueIndex];
        if (current && t >= current.start && t <= current.end) cue = current;
    }
    if (!cue) {
        activeSubtitleCueIndex = -1;
        for (let i = 0; i < subtitleCues.length; i++) {
            const c = subtitleCues[i];
            if (t >= c.start && t <= c.end) { cue = c;
                activeSubtitleCueIndex = i; break; }
            if (c.start > t) break;
        }
    }
    const html = cue ? '<span>' + escapeSubtitleHtml(cue.text) + '</span>' : '';
    if (html !== lastSubtitleHtml) { box.innerHTML = html;
        lastSubtitleHtml = html; }
}

function clearCustomSubtitle(silent = false) {
    subtitleCues = [];
    currentSubtitleName = '';
    subtitleDelay = 0;
    subtitlesEnabled = true;
    activeSubtitleCueIndex = -1;
    lastSubtitleHtml = '';
    const box = document.getElementById('subtitleOverlay');
    if (box) box.innerHTML = '';
    updateSubtitleUI();
    if (!silent) showToast(userLang === 'fa' ? 'زیرنویس حذف شد' : 'Subtitle removed');
}

function setSubtitleDelay(value, silent = false) {
    subtitleDelay = Math.max(-5, Math.min(5, Math.round(Number(value || 0) * 10) / 10));
    updateSubtitleUI();
    renderCustomSubtitle();
    if (!silent) showToast(`${userLang==='fa'?'تاخیر زیرنویس':'Subtitle delay'}: ${(subtitleDelay>0?'+':'')+subtitleDelay.toFixed(1)}s`);
}

function setSubtitleColor(color, silent = false) {
    subtitleColor = String(color || '#ffffff');
    const box = document.getElementById('subtitleOverlay');
    if (box) box.style.setProperty('--subtitle-color', subtitleColor);
    updateSubtitleUI();
    renderCustomSubtitle();
    try { localStorage.setItem('bm_subtitle_color', subtitleColor); } catch (e) {}
    if (!silent) showToast(userLang === 'fa' ? 'رنگ زیرنویس تغییر کرد' : 'Subtitle color changed');
}

function setBrightness(value, silent = false) {
    currentBrightness = Math.max(.4, Math.min(1.6, Number(value) || 1));
    if (wrapper) wrapper.style.setProperty('--player-brightness', currentBrightness.toFixed(2));
    const pct = Math.round(currentBrightness * 100) + '%';
    if (currentBrightnessLabel) currentBrightnessLabel.textContent = pct;
    document.getElementById('brightnessPercentLabel') && (document.getElementById('brightnessPercentLabel').textContent = pct);
    document.getElementById('brightnessRange') && (document.getElementById('brightnessRange').value = Math.round(currentBrightness * 100));
    document.querySelectorAll('.brightness-preset').forEach(btn => btn.classList.toggle('active', Math.abs(Number(btn.dataset.brightness) - currentBrightness) < 0.03));
    if (!silent) { showPlayerHud(userLang === 'fa' ? 'روشنایی' : 'Brightness', pct, (currentBrightness - .4) / 1.2, brightnessHudSvg());
        bmShowPlayerControls(true); }
}

// ========== تابع اصلی اتصال کنترل‌ها (سراسری) ==========
function attachPlayerEvents() {
    video = document.getElementById('videoPlayer');
    wrapper = document.getElementById('playerWrapper');
    controls = document.getElementById('playerControls');
    bmKeepPlayerControlsVisible();

    // ====== FIX: ontimeupdate برای زیرنویس و نوار پیشرفت از همان ابتدا ======
    video.ontimeupdate = function() {
        if (video.duration && isFinite(video.duration) && video.currentTime !== undefined) {
            const p = (video.currentTime / video.duration) * 100;
            document.getElementById('progressBar').value = p;
            setProgressVisual(p);
            document.getElementById('currentTimeDisplay').textContent = formatTime(video.currentTime);
        }
        renderCustomSubtitle();
    };

    // ====== بقیه کنترل‌ها ======
    const playPauseBtn = document.getElementById('playPauseBtn'),
        progressBar = document.getElementById('progressBar'),
        seekBack10Btn = document.getElementById('seekBack10Btn'),
        seekForward10Btn = document.getElementById('seekForward10Btn'),
        volumeBtn = document.getElementById('volumeBtn'),
        volumeSlider = document.getElementById('volumeSlider'),
        fullscreenBtn = document.getElementById('fullscreenBtn'),
        screenLockBtn = document.getElementById('screenLockBtn'),
        downloadBtn = document.getElementById('downloadBtn'),
        settingsBtn = document.getElementById('settingsBtn'),
        uploadSubtitleOption = document.getElementById('uploadSubtitleOption'),
        removeSubtitleOption = document.getElementById('removeSubtitleOption'),
        subtitleUpload = document.getElementById('subtitleUpload');

    let isMuted = false,
        lastVolume = 100;
    if (video && volumeSlider) {
        video.volume = 1;
        volumeSlider.value = 100;
    }

    function locked() {
        if (isUILocked) {
            showToast(userLang === 'fa' ? 'کنترل‌ها قفل است' : 'Controls are locked');
            return true;
        }
        return false;
    }

    playPauseBtn.onclick = () => {
        if (locked()) return;
        if (!video.src) {
            showToast(userLang === 'fa' ? 'اول لینک ویدیو را وارد کنید' : 'Paste a video link first');
            return;
        }
        if (video.paused) { video.play(); } else { video.pause(); }
    };

    progressBar.oninput = e => {
        if (locked()) return;
        if (video.duration && isFinite(video.duration)) {
            video.currentTime = (e.target.value / 100) * video.duration;
            setProgressVisual(e.target.value);
        }
    };

    seekBack10Btn.onclick = () => {
        if (locked()) return;
        if (video.src) {
            video.currentTime = Math.max(0, video.currentTime - 10);
            showPlayerHud(userLang === 'fa' ? 'عقب' : 'Back', '-10s', null, seekHudSvg('back'));
        }
    };

    seekForward10Btn.onclick = () => {
        if (locked()) return;
        if (video.src && video.duration) {
            video.currentTime = Math.min(video.duration, video.currentTime + 10);
            showPlayerHud(userLang === 'fa' ? 'جلو' : 'Forward', '+10s', null, seekHudSvg('forward'));
        }
    };

    volumeSlider.oninput = e => {
        const v = e.target.value / 100;
        video.volume = v;
        lastVolume = e.target.value;
        isMuted = (v === 0);
        showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', Math.round(v * 100) + '%', v, volumeHudSvg(Math.round(v * 100)));
    };

    volumeBtn.onclick = () => {
        if (locked()) return;
        if (isMuted) {
            video.volume = lastVolume / 100;
            volumeSlider.value = lastVolume;
            isMuted = false;
            showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', Math.round(video.volume * 100) + '%', video.volume, volumeHudSvg(Math.round(video.volume * 100)));
        } else {
            lastVolume = volumeSlider.value;
            video.volume = 0;
            volumeSlider.value = 0;
            isMuted = true;
            showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', '0%', 0, volumeHudSvg(0));
        }
    };

    if (downloadBtn) {
        downloadBtn.onclick = () => {
            if (locked()) return;
            const source = (video && (video.currentSrc || video.src)) || document.getElementById('videoUrl')?.value.trim() || '';
            if (!source) {
                showToast(userLang === 'fa' ? 'ابتدا لینک ویدیو را وارد کنید' : 'Paste a video link first');
                return;
            }
            const link = document.createElement('a');
            link.href = source;
            link.download = 'BankMovie-video';
            link.rel = 'noopener';
            document.body.appendChild(link);
            link.click();
            link.remove();
            bmShowPlayerControls(true);
        };
    }

    fullscreenBtn.onclick = () => {
        if (!document.fullscreenElement) {
            wrapper.requestFullscreen?.();
        } else {
            document.exitFullscreen?.();
        }
    };

    document.addEventListener('fullscreenchange', () => {
        document.body.classList.toggle('fullscreen-active', !!document.fullscreenElement);
        bmShowPlayerControls(true);
        if (document.fullscreenElement && screen.orientation?.lock) {
            screen.orientation.lock('landscape').catch(() => {});
        }
    });

    async function toggleLock() {
        isUILocked = !isUILocked;
        if (isUILocked) {
            wrapper.classList.add('ui-locked');
            screenLockBtn.classList.add('locked');
            showToast(userLang === 'fa' ? 'کنترل‌ها قفل شد' : 'Controls locked');
            showPlayerHud(userLang === 'fa' ? 'قفل صفحه' : 'Screen lock', userLang === 'fa' ? 'فعال' : 'On', 1, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>');
            try {
                if ('wakeLock' in navigator) wakeLock = await navigator.wakeLock.request('screen');
            } catch (e) {}
        } else {
            wrapper.classList.remove('ui-locked');
            screenLockBtn.classList.remove('locked');
            showToast(userLang === 'fa' ? 'کنترل‌ها باز شد' : 'Controls unlocked');
            showPlayerHud(userLang === 'fa' ? 'قفل صفحه' : 'Screen lock', userLang === 'fa' ? 'باز' : 'Off', 0, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.2-2.4"/><path d="M19 5L5 19"/></svg>');
            try {
                if (wakeLock) {
                    await wakeLock.release();
                    wakeLock = null;
                }
            } catch (e) {}
        }
    }

    screenLockBtn.onclick = () => toggleLock();
    document.getElementById('unlockOverlayBtn')?.addEventListener('click', e => {
        e.stopPropagation();
        if (isUILocked) toggleLock();
    });

    wrapper.addEventListener('click', event => {
        if (!video.src || isUILocked) return;
        if (!event.target.closest('.player-controls') && !event.target.closest('.settings-dropdown-content')) {
            bmShowPlayerControls(true);
        }
    });
    let lastPointerX = null;
    let lastPointerY = null;
    wrapper.addEventListener('pointermove', event => {
        if (event.pointerType === 'mouse') {
            const moved = lastPointerX === null || Math.abs(event.clientX - lastPointerX) > 1 || Math.abs(event.clientY - lastPointerY) > 1;
            lastPointerX = event.clientX;
            lastPointerY = event.clientY;
            if (!moved) return;
        }
        bmShowPlayerControls(true);
    }, { passive: true });
    wrapper.addEventListener('pointerleave', () => {
        if (video && !video.paused && !video.ended && !bmPlayerSettingsOpen()) {
            clearTimeout(controlsTimeout);
            controlsTimeout = setTimeout(() => bmHidePlayerControls(true), 180);
        }
    });
    wrapper.addEventListener('touchstart', () => bmShowPlayerControls(true), { passive: true });
    controls.addEventListener('pointerdown', event => event.stopPropagation());

    // ====== تنظیمات ======
    settingsDropdown = document.getElementById('settingsDropdown');
    if (wrapper && settingsDropdown && settingsDropdown.parentElement !== wrapper) {
        wrapper.appendChild(settingsDropdown);
    }

    const currentSpeedLabel = document.getElementById('currentSpeedLabel'),
        currentSleepTimerLabel = document.getElementById('currentSleepTimerLabel'),
        currentPictureModeLabel = document.getElementById('currentPictureModeLabel'),
        currentTheatreModeLabel = document.getElementById('currentTheatreModeLabel'),
        currentBrightnessLabel = document.getElementById('currentBrightnessLabel'),
        currentSubtitleLabel = document.getElementById('currentSubtitleLabel'),
        openSpeedPanel = document.getElementById('openSpeedPanel'),
        openPictureModePanel = document.getElementById('openPictureModePanel'),
        openTheatrePanel = document.getElementById('openTheatrePanel'),
        openBrightnessPanel = document.getElementById('openBrightnessPanel'),
        openSubtitlePanel = document.getElementById('openSubtitlePanel'),
        openSleepTimerPanel = document.getElementById('openSleepTimerPanel');

    function openSettingsPanel(panelName) {
        if (!settingsDropdown) return;
        settingsDropdown.querySelectorAll('[data-settings-panel]').forEach(panel => {
            panel.classList.toggle('active', panel.dataset.settingsPanel === panelName);
        });
    }

    function positionSettingsDropdown() {
        if (!settingsDropdown || !settingsBtn || !wrapper) return;
        const wrapperRect = wrapper.getBoundingClientRect();
        const btnRect = settingsBtn.getBoundingClientRect();
        const panelWidth = Math.max(240, Math.min(340, wrapperRect.width - 20));
        const panelHeight = Math.min(460, Math.max(220, wrapperRect.height - 24));
        let left = (btnRect.left - wrapperRect.left) + (btnRect.width / 2) - (panelWidth / 2);
        left = Math.max(10, Math.min(left, wrapperRect.width - panelWidth - 10));
        let top = (btnRect.top - wrapperRect.top) - panelHeight - 10;
        if (top < 10) top = 10;
        settingsDropdown.style.position = 'absolute';
        settingsDropdown.style.width = panelWidth + 'px';
        settingsDropdown.style.maxHeight = panelHeight + 'px';
        settingsDropdown.style.top = top + 'px';
        settingsDropdown.style.left = left + 'px';
        settingsDropdown.style.right = 'auto';
        settingsDropdown.style.bottom = 'auto';
    }

    function closeSettingsDropdown() {
        if (settingsDropdown) settingsDropdown.classList.remove('active');
        openSettingsPanel('main');
        bmShowPlayerControls(true);
    }

    function setPlaybackSpeed(speed, silent = false) {
        const normalized = Number(speed);
        if (!Number.isFinite(normalized) || normalized <= 0) return;
        currentPlaybackRate = normalized;
        if (video) video.playbackRate = normalized;
        const speedText = `${Math.round(normalized*100)/100}x`;
        if (currentSpeedLabel) currentSpeedLabel.textContent = speedText;
        document.getElementById('speedRange') && (document.getElementById('speedRange').value = String(normalized));
        document.getElementById('speedTouchValue') && (document.getElementById('speedTouchValue').textContent = speedText);
        document.querySelectorAll('.speed-opt').forEach(opt => opt.classList.toggle('active', parseFloat(opt.dataset.speed) === normalized));
        if (!silent) showToast(`${userLang==='fa'?'سرعت':'Speed'}: ${speedText}`);
    }

    function getPictureModeLabel(mode) {
        const labels = { normal: userLang === 'fa' ? 'عادی' : 'Normal', cover: userLang === 'fa' ? 'بزرگ' : 'Zoom', stretch: userLang === 'fa' ? '16:9' : '16:9', small: userLang === 'fa' ? 'کوچک‌تر' : 'Smaller' };
        return labels[mode] || labels.normal;
    }

    function setPictureMode(mode) {
        const allowed = ['normal', 'cover', 'stretch', 'small'];
        currentPictureMode = allowed.includes(mode) ? mode : 'normal';
        wrapper.classList.remove('view-mode-normal', 'view-mode-cover', 'view-mode-stretch', 'view-mode-small');
        wrapper.classList.add('view-mode-' + currentPictureMode);
        if (currentPictureModeLabel) currentPictureModeLabel.textContent = getPictureModeLabel(currentPictureMode);
        document.querySelectorAll('.picture-mode-opt').forEach(opt => opt.classList.toggle('active', opt.dataset.pictureMode === currentPictureMode));
        showToast(`${userLang==='fa'?'حالت تصویر':'Picture mode'}: ${getPictureModeLabel(currentPictureMode)}`);
    }

    function getTheatreModeLabel() { return theatreModeEnabled ? (userLang === 'fa' ? 'روشن' : 'On') : (userLang === 'fa' ? 'خاموش' : 'Off'); }

    function setTheatreMode(enabled, silent = false) {
        theatreModeEnabled = (enabled === true || enabled === 'on' || enabled === '1');
        document.body.classList.remove('bm-theatre-active');
        if (wrapper) wrapper.classList.toggle('bm-theatre-active', theatreModeEnabled);
        if (currentTheatreModeLabel) currentTheatreModeLabel.textContent = getTheatreModeLabel();
        document.querySelectorAll('.theatre-opt').forEach(opt => opt.classList.toggle('active', (opt.dataset.theatre === 'on') === theatreModeEnabled));
        try { localStorage.removeItem('bm_theatre_mode'); } catch (e) {}
        if (!silent) {
            showToast(theatreModeEnabled ? (userLang === 'fa' ? 'حالت سینمایی روشن شد' : 'Theatre mode on') : (userLang === 'fa' ? 'حالت سینمایی خاموش شد' : 'Theatre mode off'));
            showPlayerHud(userLang === 'fa' ? 'حالت سینمایی' : 'Theatre mode', getTheatreModeLabel(), theatreModeEnabled ? 1 : 0, '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 7h18v10H3z"/><path d="M7 3h10M7 21h10"/></svg>');
        }
        if (theatreModeEnabled && wrapper) wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }

    function updateSleepTimerLabel() {
        if (!currentSleepTimerLabel) return;
        if (!sleepTimerEndsAt) { currentSleepTimerLabel.textContent = userLang === 'fa' ? 'خاموش' : 'Off'; return; }
        const remaining = Math.max(0, Math.ceil((sleepTimerEndsAt - Date.now()) / 60000));
        currentSleepTimerLabel.textContent = remaining + ' ' + (userLang === 'fa' ? 'دقیقه' : 'min');
    }

    function clearSleepTimer(silent = false) {
        if (sleepTimerId) clearTimeout(sleepTimerId);
        if (sleepTimerTickId) clearInterval(sleepTimerTickId);
        sleepTimerId = null;
        sleepTimerTickId = null;
        sleepTimerEndsAt = null;
        updateSleepTimerLabel();
        document.querySelectorAll('.sleep-opt').forEach(opt => opt.classList.toggle('active', opt.dataset.sleepMinutes === '0'));
        if (!silent) showToast(userLang === 'fa' ? 'زمان‌سنج خواب خاموش شد' : 'Sleep timer turned off');
    }

    function setSleepTimer(minutes) {
        const mins = parseInt(minutes, 10);
        if (!Number.isFinite(mins) || mins <= 0) { clearSleepTimer(); return; }
        if (sleepTimerId) clearTimeout(sleepTimerId);
        if (sleepTimerTickId) clearInterval(sleepTimerTickId);
        sleepTimerEndsAt = Date.now() + mins * 60000;
        sleepTimerId = setTimeout(() => {
            video.pause();
            if (document.fullscreenElement) document.exitFullscreen?.();
            clearSleepTimer(true);
            showToast(userLang === 'fa' ? 'زمان‌سنج خواب تمام شد؛ پخش متوقف شد' : 'Sleep timer finished; playback paused');
        }, mins * 60000);
        sleepTimerTickId = setInterval(updateSleepTimerLabel, 30000);
        updateSleepTimerLabel();
        document.querySelectorAll('.sleep-opt').forEach(opt => opt.classList.toggle('active', parseInt(opt.dataset.sleepMinutes, 10) === mins));
        showToast(`${userLang==='fa'?'زمان‌سنج خواب':'Sleep timer'}: ${mins} ${userLang==='fa'?'دقیقه':'minutes'}`);
    }

    // ====== رویدادهای تنظیمات ======
    document.querySelectorAll('[data-settings-back]').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('main'); }));
    openSpeedPanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('speed'); });
    openPictureModePanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('picture'); });
    openTheatrePanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('theatre'); });
    openBrightnessPanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('brightness'); });
    openSubtitlePanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('subtitle'); });
    openSleepTimerPanel?.addEventListener('click', e => { e.stopPropagation();
        openSettingsPanel('sleep'); });

    settingsBtn.onclick = e => {
        e.stopPropagation();
        if (locked()) return;
        const active = settingsDropdown.classList.contains('active');
        if (!active) {
            positionSettingsDropdown();
            openSettingsPanel('main');
            settingsDropdown.classList.add('active');
            bmShowPlayerControls(false);
        } else closeSettingsDropdown();
    };

    settingsDropdown?.addEventListener('pointerdown', e => e.stopPropagation());
    settingsDropdown?.addEventListener('click', e => e.stopPropagation());
    settingsDropdown?.addEventListener('touchstart', e => e.stopPropagation(), { passive: true });

    document.addEventListener('click', e => {
        if (settingsDropdown && !settingsDropdown.contains(e.target) && !settingsBtn.contains(e.target)) closeSettingsDropdown();
    });
    window.addEventListener('resize', () => {
        if (settingsDropdown?.classList.contains('active')) positionSettingsDropdown();
    });

    uploadSubtitleOption.onclick = () => { if (locked()) return;
        subtitleUpload.click(); };
    subtitleUpload.onchange = async e => {
        const file = e.target.files[0];
        if (file && /\.(srt|vtt|ssa|ass)$/i.test(file.name)) {
            try {
                const content = await readSubtitleText(file);
                subtitleCues = parseSubtitleFile(file, content);
                activeSubtitleCueIndex = -1;
                lastSubtitleHtml = '';
                if (!subtitleCues.length) { showToast(userLang === 'fa' ? 'زیرنویس قابل خواندن نبود' : 'Subtitle could not be parsed'); return; }
                currentSubtitleName = file.name;
                subtitlesEnabled = true;
                setSubtitleDelay(0, true);
                updateSubtitleUI();
                renderCustomSubtitle();
                showToast((userLang === 'fa' ? 'زیرنویس بارگذاری شد: ' : 'Subtitle loaded: ') + file.name);
                openSettingsPanel('subtitle');
                e.target.value = '';
            } catch (err) { showToast(userLang === 'fa' ? 'خطا در خواندن زیرنویس' : 'Subtitle read error'); }
        } else showToast(userLang === 'fa' ? 'فرمت زیرنویس پشتیبانی نمی‌شود' : 'Subtitle format not supported');
    };
    removeSubtitleOption.onclick = () => { clearCustomSubtitle(); };
    document.getElementById('toggleSubtitleOption')?.addEventListener('click', () => {
        subtitlesEnabled = !subtitlesEnabled;
        updateSubtitleUI();
        renderCustomSubtitle();
        showToast(subtitlesEnabled ? (userLang === 'fa' ? 'زیرنویس روشن شد' : 'Subtitles on') : (userLang === 'fa' ? 'زیرنویس خاموش شد' : 'Subtitles off'));
    });
    document.getElementById('subtitleEarlierBtn')?.addEventListener('click', () => setSubtitleDelay(subtitleDelay - .1));
    document.getElementById('subtitleLaterBtn')?.addEventListener('click', () => setSubtitleDelay(subtitleDelay + .1));
    document.getElementById('subtitleResetDelayBtn')?.addEventListener('click', () => setSubtitleDelay(0));
    document.getElementById('subtitleDelayRange')?.addEventListener('input', e => setSubtitleDelay(e.target.value, true));
    document.getElementById('subtitleDelayRange')?.addEventListener('change', e => setSubtitleDelay(e.target.value));

    document.querySelectorAll('.subtitle-color-btn[data-subtitle-color]').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation();
        setSubtitleColor(btn.dataset.subtitleColor); }));
    try { setSubtitleColor(localStorage.getItem('bm_subtitle_color') || '#ffffff', true); } catch (e) { setSubtitleColor('#ffffff', true); }

    const speedRange = document.getElementById('speedRange'),
        speedTouchPad = document.getElementById('speedTouchPad'),
        speedTouchValue = document.getElementById('speedTouchValue');

    function updateSpeedTouchUI() {
        const v = Number(currentPlaybackRate || video?.playbackRate || 1);
        if (speedRange) speedRange.value = String(v);
        if (speedTouchValue) speedTouchValue.textContent = (Math.round(v * 100) / 100) + 'x';
    }
    if (speedRange) { speedRange.addEventListener('input', e => setPlaybackSpeed(e.target.value, true));
        speedRange.addEventListener('change', e => setPlaybackSpeed(e.target.value)); }
    if (speedTouchPad) {
        let spStart = null;
        speedTouchPad.addEventListener('pointerdown', e => { spStart = { y: e.clientY, speed: Number(currentPlaybackRate || video?.playbackRate || 1) };
            speedTouchPad.setPointerCapture?.(e.pointerId);
            e.preventDefault(); });
        speedTouchPad.addEventListener('pointermove', e => {
            if (!spStart) return;
            const diff = (spStart.y - e.clientY) / 160;
            const next = Math.max(.25, Math.min(2, Math.round((spStart.speed + diff) * 20) / 20));
            setPlaybackSpeed(next, true);
            showPlayerHud(userLang === 'fa' ? 'سرعت' : 'Speed', (Math.round(next * 100) / 100) + 'x', (next - .25) / 1.75, speedHudSvg());
        });
        speedTouchPad.addEventListener('pointerup', () => { if (spStart) { setPlaybackSpeed(currentPlaybackRate);
                spStart = null; } });
        speedTouchPad.addEventListener('pointercancel', () => { spStart = null; });
    }

    document.getElementById('brightnessRange')?.addEventListener('input', e => setBrightness(Number(e.target.value) / 100, false));
    document.querySelectorAll('.brightness-preset[data-brightness]').forEach(btn => btn.addEventListener('click', e => { e.stopPropagation();
        setBrightness(btn.dataset.brightness); }));

    function setupTouchGestures() {
        let start = null,
            lastTap = 0,
            lastSide = '',
            singleTapTimer = null;
        const setGestureClass = (side) => { wrapper.classList.toggle('gesture-active-left', side === 'left');
            wrapper.classList.toggle('gesture-active-right', side === 'right'); };
        const clearGestureClass = () => { wrapper.classList.remove('gesture-active-left', 'gesture-active-right'); };
        wrapper.addEventListener('touchstart', e => {
            if (isUILocked || e.target.closest('.player-controls') || e.target.closest('.unlock-overlay') || !video.src) return;
            const t = e.touches[0],
                r = wrapper.getBoundingClientRect();
            start = { x: t.clientX, y: t.clientY, time: Date.now(), brightness: currentBrightness, volume: Number(volumeSlider?.value || 100), mode: null, moved: false, side: t.clientX < r.left + r.width / 2 ? 'left' : 'right', rect: r };
        }, { passive: true });
        wrapper.addEventListener('touchmove', e => {
            if (!start || isUILocked) return;
            const t = e.touches[0],
                dx = t.clientX - start.x,
                dy = t.clientY - start.y;
            if (!start.mode && Math.abs(dy) > 18 && Math.abs(dy) > Math.abs(dx)) start.mode = start.side === 'left' ? 'brightness' : 'volume';
            if (start.mode === 'brightness') {
                e.preventDefault();
                start.moved = true;
                setGestureClass('left');
                setBrightness(start.brightness + ((start.y - t.clientY) / start.rect.height) * 1.4, false);
            } else if (start.mode === 'volume') {
                e.preventDefault();
                start.moved = true;
                setGestureClass('right');
                const next = Math.max(0, Math.min(100, Math.round(start.volume + ((start.y - t.clientY) / start.rect.height) * 130)));
                if (volumeSlider) volumeSlider.value = next;
                video.volume = next / 100;
                lastVolume = next;
                isMuted = next === 0;
                showPlayerHud(userLang === 'fa' ? 'صدا' : 'Volume', next + '%', next / 100, volumeHudSvg(next));
                bmShowPlayerControls(true);
            }
        }, { passive: false });
        wrapper.addEventListener('touchend', e => {
            if (!start || isUILocked) { start = null;
                clearGestureClass(); return; }
            const now = Date.now();
            if (start.moved) { start = null;
                clearGestureClass(); return; }
            if (now - lastTap < 320 && lastSide === start.side) {
                e.preventDefault();
                clearTimeout(singleTapTimer);
                window.__bmSuppressNextClick = true;
                setTimeout(() => window.__bmSuppressNextClick = false, 380);
                start.side === 'left' ? seekBack10Btn.click() : seekForward10Btn.click();
                lastTap = 0;
                lastSide = '';
            } else {
                lastTap = now;
                lastSide = start.side;
                window.__bmSuppressNextClick = true;
                setTimeout(() => window.__bmSuppressNextClick = false, 360);
                clearTimeout(singleTapTimer);
                singleTapTimer = setTimeout(() => { bmShowPlayerControls(true); }, 330);
            }
            start = null;
            clearGestureClass();
        }, { passive: false });
    }

    setupTouchGestures();

    document.querySelectorAll('.speed-opt[data-speed]').forEach(btn => {
        btn.onclick = e => { e.stopPropagation(); if (locked()) return;
            setPlaybackSpeed(btn.dataset.speed); };
    });
    document.querySelectorAll('.sleep-opt[data-sleep-minutes]').forEach(btn => {
        btn.onclick = e => { e.stopPropagation(); if (locked()) return;
            setSleepTimer(btn.dataset.sleepMinutes); };
    });
    document.querySelectorAll('.theatre-opt[data-theatre]').forEach(btn => {
        btn.onclick = e => { e.stopPropagation(); if (locked()) return;
            setTheatreMode(btn.dataset.theatre); };
    });
    document.querySelectorAll('.picture-mode-opt[data-picture-mode]').forEach(btn => {
        btn.onclick = e => { e.stopPropagation(); if (locked()) return;
            setPictureMode(btn.dataset.pictureMode); };
    });

    if (wrapper) wrapper.classList.add('view-mode-' + currentPictureMode);
    try { localStorage.removeItem('bm_theatre_mode'); } catch (e) {}
    setTheatreMode(false, true);

    video.addEventListener('click', e => {
        if (window.__bmSuppressNextClick) { e.preventDefault(); return; }
        if (isUILocked) { showToast(userLang === 'fa' ? 'کنترل‌ها قفل است' : 'Controls are locked'); return; }
        if (video.src) { video.paused ? video.play() : video.pause(); }
    });

    document.addEventListener('keydown', e => {
        if (isUILocked || document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;
        switch (e.key) {
            case ' ':
            case 'Space':
                e.preventDefault();
                playPauseBtn.click();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                seekBack10Btn.click();
                break;
            case 'ArrowRight':
                e.preventDefault();
                seekForward10Btn.click();
                break;
            case 'ArrowUp':
                e.preventDefault();
                volumeSlider.value = Math.min(100, parseInt(volumeSlider.value) + 10);
                volumeSlider.dispatchEvent(new Event('input'));
                break;
            case 'ArrowDown':
                e.preventDefault();
                volumeSlider.value = Math.max(0, parseInt(volumeSlider.value) - 10);
                volumeSlider.dispatchEvent(new Event('input'));
                break;
            case 'f':
            case 'F':
                e.preventDefault();
                fullscreenBtn.click();
                break;
            case 'm':
            case 'M':
                e.preventDefault();
                volumeBtn.click();
                break;
        }
    });

    playerEventsAttached = true;
}


// ========== سیستم خطای ریسپانسیو پلیر V112 ==========
function playerErrorMeta(kind) {
    const fa = userLang === 'fa';
    const map = {
        empty: {code:'E0', kicker:fa?'ورودی پلیر':'Player input', title:fa?'لینک ویدیو وارد نشده است':'No video link was entered', message:fa?'یک لینک مستقیم HTTP یا HTTPS وارد کنید و دوباره دکمه پخش را بزنید.':'Enter a direct HTTP or HTTPS link and press play again.'},
        unsafe: {code:'E1', kicker:fa?'لینک نامعتبر':'Invalid link', title:fa?'ساختار لینک قابل قبول نیست':'The link format is not accepted', message:fa?'لینک باید با http:// یا https:// شروع شود.':'The link must start with http:// or https://.'},
        aborted: {code:'E2', kicker:fa?'پخش متوقف شد':'Playback stopped', title:fa?'بارگذاری ویدیو لغو شد':'Video loading was aborted', message:fa?'پخش پیش از کامل‌شدن بارگذاری متوقف شد. دوباره تلاش کنید.':'Playback stopped before loading completed. Try again.'},
        network: {code:'E3', kicker:fa?'خطای شبکه':'Network error', title:fa?'ارتباط با سرور ویدیو قطع شد':'Connection to the video server was lost', message:fa?'اینترنت، VPN یا در دسترس‌بودن سرور لینک را بررسی کنید.':'Check your internet, VPN, or the availability of the video server.'},
        decode: {code:'E4', kicker:fa?'خطای فایل':'Media error', title:fa?'مرورگر نتوانست ویدیو را پردازش کند':'The browser could not decode the video', message:fa?'ممکن است فایل خراب باشد یا کدک آن روی این دستگاه پشتیبانی نشود.':'The file may be damaged or its codec may not be supported on this device.'},
        source: {code:'E5', kicker:fa?'فرمت پشتیبانی‌نشده':'Unsupported format', title:fa?'این لینک یا فرمت قابل پخش نیست':'This link or format cannot be played', message:fa?'از لینک مستقیم ویدیویی با فرمت سازگار یا پلیر خارجی استفاده کنید.':'Use a compatible direct video link or an external player.'},
        unknown: {code:'ERR', kicker:fa?'پیام پلیر':'Player message', title:fa?'پخش ویدیو انجام نشد':'Video playback failed', message:fa?'لینک یا دسترسی سرور را بررسی کنید و دوباره تلاش کنید.':'Check the link or server access and try again.'}
    };
    return map[kind] || map.unknown;
}
function showPlayerError(kind, message = '') {
    const meta = playerErrorMeta(kind);
    const overlay = document.getElementById('playerErrorOverlay');
    const tv = document.getElementById('playerErrorTv');
    if (!overlay) return;
    document.getElementById('playerErrorKicker').textContent = meta.kicker;
    document.getElementById('playerErrorTitle').textContent = meta.title;
    document.getElementById('playerErrorMessage').textContent = message || meta.message;
    if (tv) {
        tv.dataset.errorCode = meta.code;
        tv.querySelectorAll('.bm-uiverse-screen-code').forEach((node) => node.replaceChildren(document.createTextNode(meta.code)));
        tv.querySelectorAll('.bm-uiverse-screen-title').forEach((node) => node.replaceChildren(document.createTextNode(meta.title)));
        tv.querySelectorAll('.bm-uiverse-screen-message').forEach((node) => node.replaceChildren(document.createTextNode(message || meta.message)));
    }
    overlay.hidden = false;
    wrapper?.classList.add('has-player-error');
    document.getElementById('bufferingIndicator') && (document.getElementById('bufferingIndicator').style.display = 'none');
}
function hidePlayerError() {
    const overlay = document.getElementById('playerErrorOverlay');
    if (overlay) overlay.hidden = true;
    wrapper?.classList.remove('has-player-error');
}
function mediaErrorKind(mediaError) {
    if (!mediaError) return 'unknown';
    switch (mediaError.code) {
        case 1: return 'aborted';
        case 2: return 'network';
        case 3: return 'decode';
        case 4: return 'source';
        default: return 'unknown';
    }
}
document.getElementById('playerErrorRetry')?.addEventListener('click', () => {
    const url = document.getElementById('videoUrl')?.value.trim() || '';
    hidePlayerError();
    showLoading();
    const ok = initPlayer(url);
    setTimeout(hideLoading, ok ? 350 : 100);
});
document.getElementById('playerErrorClose')?.addEventListener('click', hidePlayerError);
document.getElementById('playerErrorOverlay')?.addEventListener('click', (event) => {
    if (event.target === event.currentTarget) hidePlayerError();
});

// ========== تابع بارگذاری ویدیو ==========
function initPlayer(url) {
    if (!url) { showPlayerError('empty'); return false; }
    if (!isSafeVideoUrl(url)) { showPlayerError('unsafe'); return false; }
    video = document.getElementById('videoPlayer');
    wrapper = document.getElementById('playerWrapper');
    controls = document.getElementById('playerControls');
    try { resetVideoElement(); } catch (err) { console.error('resetVideoElement failed:', err); }
    hidePlayerError();
    video.setAttribute('controlsList', 'nodownload noremoteplayback');
    video.disableRemotePlayback = true;
    document.getElementById('playerEmpty')?.classList.add('hidden');
    document.getElementById('durationDisplay').textContent = '00:00';
    document.getElementById('currentTimeDisplay').textContent = '00:00';
    document.getElementById('progressBar').value = 0;
    setProgressVisual(0);
    video.src = url;
    video.playbackRate = currentPlaybackRate;
    wrapper.classList.remove('view-mode-normal', 'view-mode-cover', 'view-mode-stretch', 'view-mode-small');
    wrapper.classList.add('view-mode-' + currentPictureMode);
    wrapper.scrollIntoView({ behavior: 'smooth', block: 'center' });

    // رویدادهای مربوط به بارگذاری
    video.onloadedmetadata = () => {
        hidePlayerError();
        if (video.duration && isFinite(video.duration)) {
            document.getElementById('durationDisplay').textContent = formatTime(video.duration);
        }
        video.play().catch(() => showToast(userLang === 'fa' ? 'برای شروع پخش روی ویدیو کلیک کنید' : 'Click the video to start playback'));
    };
    video.onwaiting = () => { document.getElementById('bufferingIndicator').style.display = 'block'; };
    video.oncanplay = () => { document.getElementById('bufferingIndicator').style.display = 'none'; hidePlayerError(); };
    video.onplay = () => {
        document.getElementById('playPauseBtn').innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
        wrapper.classList.remove('controls-paused');
        bmEnterStandalonePlaybackMode();
        bmShowPlayerControls(true);
    };
    video.onpause = () => {
        document.getElementById('playPauseBtn').innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>';
        bmKeepPlayerControlsVisible();
    };
    video.onended = () => {
        bmKeepPlayerControlsVisible();
        bmLeaveStandalonePlaybackMode();
    };
    video.onerror = () => {
        bmLeaveStandalonePlaybackMode();
        showPlayerError(mediaErrorKind(video.error));
    };
    video.load();

    // اتصال کنترل‌ها (اگر قبلاً متصل نشده باشند)
    if (!playerEventsAttached) {
        attachPlayerEvents();
    }
    return true;
}

// ========== اجرای اولیه ==========
document.getElementById('playBtn').addEventListener('click', () => {
    const url = document.getElementById('videoUrl').value.trim();
    showLoading();
    const ok = initPlayer(url);
    setTimeout(hideLoading, ok ? 350 : 100);
});
document.getElementById('videoUrl').addEventListener('keydown', e => {
    if (e.key === 'Enter') { e.preventDefault();
        document.getElementById('playBtn').click(); }
});

const urlParam = new URLSearchParams(window.location.search).get('url');
if (urlParam) {
    document.getElementById('videoUrl').value = urlParam;
    setTimeout(() => {
        showLoading();
        initPlayer(urlParam);
        setTimeout(hideLoading, 500);
    }, 450);
} else {
    setTimeout(hideLoading, 350);
    // حتی بدون ویدیو هم کنترل‌ها را آماده می‌کنیم
    attachPlayerEvents();
}

// راه‌اندازی منوها و ناوبری
setupMenu();
setupHeaderScroll();
setupSmartBottomNav();
setupNotifications();
setupDonate();
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>

<script src="/assets/js/bm-uiverse-elements-v42.js?v=42.0" defer></script>
</body>
</html>
