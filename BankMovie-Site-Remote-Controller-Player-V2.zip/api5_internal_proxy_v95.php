<?php
declare(strict_types=1);

@ini_set('display_errors', '0');
@set_time_limit(20);

require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/archive_control.php';

header('Cache-Control: no-store');
header('X-BankMovie-Proxy: internal-v95');

$path = isset($_GET['path']) ? (string)$_GET['path'] : '';
$path = trim($path);

if ($path === '' || $path[0] !== '/') {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'error' => 'invalid_path',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Block scheme/host injection and CRLF.
if (
    str_contains($path, '://') ||
    str_contains($path, "\r") ||
    str_contains($path, "\n")
) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'error' => 'invalid_path',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$sourceBase = bm_archive_source_base_url('archive2', 'https://serialblog1.top');
$target = rtrim($sourceBase, '/') . $path;

if (!function_exists('curl_init')) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'error' => 'curl_missing',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $target,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_MAXREDIRS => 5,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 12,
    CURLOPT_ENCODING => '',
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_USERAGENT => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/149 Safari/537.36',
    CURLOPT_HTTPHEADER => [
        'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language: fa-IR,fa;q=0.9,en;q=0.7',
        'Cache-Control: no-cache',
    ],
]);

$body = curl_exec($ch);
$errno = curl_errno($ch);
$error = curl_error($ch);
$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
$primaryIp = (string)curl_getinfo($ch, CURLINFO_PRIMARY_IP);
$totalMs = (int)round(((float)curl_getinfo($ch, CURLINFO_TOTAL_TIME)) * 1000);
$contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
curl_close($ch);

if ($body === false) {
    http_response_code(502);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'build' => 'v95-internal-proxy',
        'target' => $target,
        'curl_errno' => $errno,
        'curl_error' => $error,
        'http_code' => $code,
        'primary_ip' => $primaryIp,
        'total_ms' => $totalMs,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

if ($code < 200 || $code >= 400) {
    http_response_code(502);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'ok' => false,
        'build' => 'v95-internal-proxy',
        'target' => $target,
        'http_code' => $code,
        'primary_ip' => $primaryIp,
        'total_ms' => $totalMs,
        'body_prefix' => mb_substr((string)$body, 0, 300),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    exit;
}

header('Content-Type: ' . ($contentType !== '' ? $contentType : 'text/html; charset=utf-8'));
header('X-BankMovie-Upstream-IP: ' . $primaryIp);
header('X-BankMovie-Upstream-Time-Ms: ' . $totalMs);
echo $body;
