<?php
require_once __DIR__ . '/config.php';
$return = '/profile#requests-section';
if (!$currentUser) {
    header('Location: /login?return=' . rawurlencode($return), true, 302);
    exit;
}
header('Location: ' . $return, true, 302);
exit;
