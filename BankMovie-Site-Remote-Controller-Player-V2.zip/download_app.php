<?php
@include_once __DIR__ . '/includes/security_bootstrap.php';

$type = strtolower((string)($_GET['type'] ?? 'apk'));
$files = [
    'apk' => [
        'path' => __DIR__ . '/app/Bankmovie-v1.3-arm64-v7a-universal-.apk',
        'name' => 'Bankmovie-v1.3-arm64-v7a-universal-.apk',
        'mime' => 'application/vnd.android.package-archive',
    ],
    'zip' => [
        'path' => __DIR__ . '/app/Bankmovie-v1.3-arm64-v7a-universal-.zip',
        'name' => 'Bankmovie-v1.3-arm64-v7a-universal-.zip',
        'mime' => 'application/zip',
    ],
];

if (!isset($files[$type])) {
    http_response_code(404);
    exit('File not found');
}

$file = $files[$type];
$real = realpath($file['path']);
$appDir = realpath(__DIR__ . '/application');
if (!$real || !$appDir || strpos($real, $appDir . DIRECTORY_SEPARATOR) !== 0 || !is_file($real)) {
    http_response_code(404);
    exit('File not found');
}

while (ob_get_level()) { ob_end_clean(); }
header('Content-Type: ' . $file['mime']);
header('Content-Disposition: attachment; filename="' . $file['name'] . '"');
header('Content-Length: ' . filesize($real));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=86400');
readfile($real);
exit;
