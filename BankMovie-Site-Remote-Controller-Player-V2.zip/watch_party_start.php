<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/vip_features.php';
require_once __DIR__ . '/includes/watch_party.php';

if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    header('Referrer-Policy: no-referrer');
}

$userRow = bm_watch_party_current_user($pdo);
$returnHere = (string)($_SERVER['REQUEST_URI'] ?? '/watch-party/start');
if (!$userRow) {
    $_SESSION['redirect_after_login'] = $returnHere;
    bm_vip_render_gate_screen('watch_party', null, $returnHere);
}

if (!bm_watch_party_is_vip($userRow)) {
    $_SESSION['vip_return_after_purchase'] = $returnHere;
    bm_vip_render_gate_screen('watch_party', $userRow, $returnHere);
}

if (!bm_watch_party_is_enabled()) {
    header('Location: /vip?feature=watch-party-unavailable');
    exit;
}

$sentCsrf = (string)($_GET['csrf_token'] ?? $_POST['csrf_token'] ?? '');
$expectedCsrf = bm_user_csrf_token();
if ($sentCsrf === '' || !hash_equals($expectedCsrf, $sentCsrf)) {
    http_response_code(419);
    exit('درخواست نامعتبر است. صفحه فیلم را تازه‌سازی کنید.');
}

$input = [
    'movie_id' => (int)($_GET['movie_id'] ?? $_POST['movie_id'] ?? 0),
    'archive_no' => (int)($_GET['archive_no'] ?? $_POST['archive_no'] ?? 1),
    'media_type' => (string)($_GET['media_type'] ?? $_POST['media_type'] ?? 'movie'),
    'source_ref' => (string)($_GET['source_ref'] ?? $_POST['source_ref'] ?? 'movie-page'),
    'source_url' => (string)($_GET['source_url'] ?? $_POST['source_url'] ?? ''),
    'subtitle_url' => (string)($_GET['subtitle_url'] ?? $_POST['subtitle_url'] ?? ''),
    'content_title' => (string)($_GET['content_title'] ?? $_POST['content_title'] ?? ''),
    'poster_url' => (string)($_GET['poster_url'] ?? $_POST['poster_url'] ?? ''),
];

try {
    $room = bm_watch_party_start_or_reuse_room($pdo, $userRow, $input);
    $code = (string)($room['invite_code'] ?? '');
    if ($code === '') throw new RuntimeException('room_code_generation_failed', 500);
    header('Location: /watch-party?room=' . rawurlencode($code) . '&from=movie');
    exit;
} catch (Throwable $e) {
    $code = (int)$e->getCode();
    if ($code < 400 || $code > 599) $code = 500;
    http_response_code($code);
    $messageMap = [
        'invalid_source_url' => 'این لینک برای تماشای دونفره قابل استفاده نیست. یک لینک مستقیم ویدئو انتخاب کن.',
        'too_many_active_rooms' => 'تعداد اتاق‌های فعال این حساب به سقف رسیده است.',
        'watch_party_schema_unavailable' => 'راه‌اندازی اتاق در حال حاضر انجام نشد. تنظیمات Watch Party را از پنل بررسی کن.',
    ];
    $safeMessage = $messageMap[$e->getMessage()] ?? 'ساخت یا بازکردن اتاق انجام نشد.';
    ?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Watch Party | BankMovie</title><style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#080b12;color:#fff;font-family:Tahoma,Arial,sans-serif;padding:20px}.box{width:min(470px,100%);padding:26px;border-radius:24px;background:linear-gradient(145deg,rgba(25,30,44,.98),rgba(10,13,22,.98));border:1px solid rgba(139,92,246,.28);box-shadow:0 30px 90px rgba(0,0,0,.5);text-align:center}.box h1{font-size:21px;margin:0 0 10px}.box p{color:#b7bed0;line-height:2;font-size:13px}.actions{display:flex;gap:10px;justify-content:center;margin-top:18px;flex-wrap:wrap}.actions a{padding:11px 16px;border-radius:12px;text-decoration:none;color:#fff;background:linear-gradient(135deg,#8b5cf6,#2563eb);font-weight:800;font-size:12px}.actions a.alt{background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.1)}</style></head><body><main class="box"><h1>اتاق آماده نشد</h1><p><?= htmlspecialchars($safeMessage, ENT_QUOTES, 'UTF-8') ?></p><div class="actions"><a href="javascript:history.back()" class="alt">بازگشت</a><a href="/watch-party">ورود به Watch Party</a></div></main></body></html>
    <?php
    exit;
}
