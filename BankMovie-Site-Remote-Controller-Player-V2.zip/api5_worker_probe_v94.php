<?php
declare(strict_types=1);
@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$out = [
    'build' => 'v94-worker-relay-test',
    'origin' => 'https://serialblog1.top/',
    'relay' => 'https://solitary-frog-2981.amirnoteheh.workers.dev/',
];

try {
    require_once __DIR__ . '/includes/api5_lib.php';

    $out['logical_base'] = defined('SERIALBLOG_BASE_URL') ? SERIALBLOG_BASE_URL : null;
    $out['transport_base'] = defined('SERIALBLOG_FETCH_PROXY_BASE') ? SERIALBLOG_FETCH_PROXY_BASE : null;
    $out['transport_url_for_home'] = function_exists('serialblog_transport_url')
        ? serialblog_transport_url('https://serialblog1.top/')
        : null;

    $started = microtime(true);
    $html = serialblog_get_html('https://serialblog1.top/');
    $out['fetch_ms'] = (int) round((microtime(true) - $started) * 1000);
    $out['html_bytes'] = strlen($html);

    $parsed = serialblog_parse_listing($html, 1, 'https://serialblog1.top/');
    $out['parse_count'] = (int)($parsed['count'] ?? 0);
    $out['ok'] = $out['parse_count'] > 0;

    if (!empty($parsed['items'][0]) && is_array($parsed['items'][0])) {
        $item = $parsed['items'][0];
        $out['first_item'] = [
            'title' => (string)($item['title'] ?? ''),
            'type' => (string)($item['type'] ?? ''),
            'url' => (string)($item['url'] ?? ''),
            'poster' => (string)($item['poster'] ?? ''),
        ];
    }
} catch (Throwable $e) {
    http_response_code(500);
    $out['ok'] = false;
    $out['error'] = $e->getMessage();
}

echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
