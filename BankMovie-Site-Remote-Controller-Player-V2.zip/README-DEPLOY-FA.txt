BankMovie Phase 9 server patch

روی ریشه سایت فقط این دو فایل را جایگزین کنید:
- app_api.php      (Fix آرشیو 2 از Phase 8، بدون تغییر API Legacy)
- app_user_api.php (GIF + VIP custom avatar sync/upload)

قبل از جایگزینی از دو فایل فعلی بکاپ بگیرید.
به api5.php و api5_lib.php دست نزنید؛ برای APKهای قدیمی هستند.
