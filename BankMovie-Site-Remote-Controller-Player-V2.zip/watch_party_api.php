<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/watch_party.php';
require_once __DIR__ . '/includes/watch_party_voice.php';

if (!headers_sent()) {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    header('X-Content-Type-Options: nosniff', true);
    header('Referrer-Policy: same-origin', true);
    header('Cross-Origin-Resource-Policy: same-origin', true);
    header('X-Frame-Options: SAMEORIGIN', true);
}

function bm_wp_json(bool $success, array $payload = [], int $status = 200): never
{
    http_response_code($status);
    echo json_encode(array_merge(['success' => $success], $payload), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_wp_request_data(): array
{
    $data = $_POST;
    $type = strtolower(trim((string)($_SERVER['CONTENT_TYPE'] ?? '')));
    if (str_contains($type, 'application/json')) {
        $raw = file_get_contents('php://input');
        $decoded = is_string($raw) ? json_decode($raw, true) : null;
        if (is_array($decoded)) $data = array_replace($data, $decoded);
    }
    return is_array($data) ? $data : [];
}


function bm_wp_voice_same_origin_guard(): void
{
    // Voice signaling is state-changing. CSRF is still required below;
    // this is an additional browser-origin boundary, not a replacement for CSRF.
    $contentLength = max(0, (int)($_SERVER['CONTENT_LENGTH'] ?? 0));
    if ($contentLength > 65536) {
        bm_wp_json(false, ['error' => 'voice_invalid_signal', 'message' => 'درخواست تماس صوتی بیش از حد بزرگ است.'], 413);
    }
    $requestedWith = strtolower(trim((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')));
    if ($requestedWith !== 'xmlhttprequest') {
        bm_wp_json(false, ['error' => 'voice_test_forbidden', 'message' => 'درخواست تماس صوتی مجاز نیست.'], 403);
    }
    $contentType = strtolower(trim((string)($_SERVER['CONTENT_TYPE'] ?? '')));
    if ($contentType !== '' && !str_contains($contentType, 'application/x-www-form-urlencoded') && !str_contains($contentType, 'application/json')) {
        bm_wp_json(false, ['error' => 'voice_invalid_signal', 'message' => 'نوع درخواست تماس صوتی معتبر نیست.'], 415);
    }
    $fetchSite = strtolower(trim((string)($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '')));
    if ($fetchSite !== '' && !in_array($fetchSite, ['same-origin', 'none'], true)) {
        bm_wp_json(false, ['error' => 'voice_test_forbidden', 'message' => 'درخواست تماس صوتی مجاز نیست.'], 403);
    }

    $host = strtolower(preg_replace('/:\d+$/', '', trim((string)($_SERVER['HTTP_HOST'] ?? ''))) ?? '');
    foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $header) {
        $value = trim((string)($_SERVER[$header] ?? ''));
        if ($value === '') continue;
        $parsedHost = strtolower((string)(parse_url($value, PHP_URL_HOST) ?? ''));
        if ($host !== '' && $parsedHost !== '' && !hash_equals($host, $parsedHost)) {
            bm_wp_json(false, ['error' => 'voice_test_forbidden', 'message' => 'درخواست تماس صوتی مجاز نیست.'], 403);
        }
        break;
    }
}

function bm_wp_error_from_exception(Throwable $e): never
{
    $code = (int)$e->getCode();
    if ($code < 400 || $code > 599) $code = 500;
    $message = trim($e->getMessage());
    $public = [
        'not_room_member' => 'عضو این اتاق نیستید.',
        'room_not_found_or_expired' => 'اتاق در دسترس نیست.',
        'room_not_found' => 'اتاق پیدا نشد؛ کد یا لینک اتاق را بررسی کنید.',
        'room_expired' => 'زمان ۴ ساعته اتاق واقعاً تمام شده است.',
        'room_is_full' => 'ظرفیت اتاق تکمیل است.',
        'host_control_only' => 'کنترل پخش فقط در اختیار میزبان است.',
        'invalid_event' => 'رویداد پخش معتبر نیست.',
        'invalid_source_url' => 'لینک ویدئو معتبر نیست؛ فقط لینک مستقیم http یا https قابل استفاده است.',
        'invalid_subtitle_url' => 'لینک زیرنویس معتبر نیست.',
        'chat_disabled' => 'گفت‌وگوی اتاق غیرفعال است.',
        'empty_message' => 'پیام خالی است.',
        'message_rate_limited' => 'تعداد پیام‌ها زیاد است؛ چند ثانیه صبر کنید.',
        'room_code_generation_failed' => 'ساخت کد اتاق انجام نشد.',
                'too_many_active_rooms' => 'برای این حساب دو اتاق فعال وجود دارد؛ یکی را ببندید و دوباره تلاش کنید.',
        'watch_party_schema_unavailable' => 'جدول‌های Watch Party روی دیتابیس کامل ساخته نشده‌اند. از پنل Watch Party روی «تعمیر دیتابیس» بزنید.',
        'voice_test_forbidden' => 'Voice Call برای این اتاق یا حساب فعال نیست.',
        'voice_peer_unavailable' => 'طرف مقابل برای تست تماس صوتی در اتاق آماده نیست.',
        'voice_busy' => 'یک تماس صوتی دیگر در این اتاق فعال است.',
        'voice_call_not_found' => 'تماس صوتی پیدا نشد یا پایان یافته است.',
        'voice_action_invalid' => 'این عملیات برای وضعیت فعلی تماس قابل انجام نیست.',
        'voice_invalid_signal' => 'داده اتصال صوتی معتبر نیست.',
        'voice_rate_limited' => 'درخواست‌های اتصال صوتی زیاد است؛ چند لحظه صبر کنید.',
        'voice_schema_unavailable' => 'بخش آزمایشی تماس صوتی هنوز آماده نشده است.',
    ];
    $safe = $public[$message] ?? ($code < 500 ? 'درخواست قابل انجام نیست.' : 'خطای داخلی سرویس Watch Party.');
    $payload = ['error' => $message, 'message' => $safe];
    $adminUser = $GLOBALS['bm_wp_user_row'] ?? null;
    if ($code >= 500) {
        error_log('Watch Party API error: ' . $e->getMessage());
        if (bm_watch_party_is_admin(is_array($adminUser) ? $adminUser : null)) {
            $technical = $message === 'watch_party_schema_unavailable'
                ? (string)($GLOBALS['bm_watch_party_schema_error'] ?? '')
                : $e->getMessage();
            $technical = preg_replace('/[\r\n\t]+/', ' ', $technical) ?? $technical;
            $payload['technical'] = function_exists('mb_substr') ? mb_substr($technical, 0, 350, 'UTF-8') : substr($technical, 0, 350);
        }
    }
    bm_wp_json(false, $payload, $code);
}

$schemaReady = bm_watch_party_schema($pdo);
if ($schemaReady) {
    // Every Watch Party request is also a strict cleanup opportunity. This is
    // intentionally not throttled: expired rooms are tiny and must never remain
    // joinable because a filesystem lock or cron job was unavailable.
    bm_watch_party_cleanup_expired($pdo, 500);
}

$data = bm_wp_request_data();
$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'status')));
if (($data['action'] ?? '') !== '') $action = strtolower(trim((string)$data['action']));
if (strlen($action) > 40 || !preg_match('/^[a-z0-9_]+$/', $action)) {
    bm_wp_json(false, ['error' => 'unknown_action'], 404);
}
if (str_starts_with($action, 'voice_')) {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        bm_wp_json(false, ['error' => 'method_not_allowed'], 405);
    }
    bm_wp_voice_same_origin_guard();
}

$registeredUser = bm_watch_party_current_user($pdo);
$GLOBALS['bm_wp_user_row'] = $registeredUser;
$roomCodeFromRequest = (string)($data['room_code'] ?? $_GET['room_code'] ?? '');
$normalizedRoomCode = bm_watch_party_normalize_code($roomCodeFromRequest);
$actor = $registeredUser;
if (!$actor && $normalizedRoomCode !== '') {
    // The second viewer may enter only through a valid secret invite URL. The
    // browser session receives a temporary anonymous identity for this room.
    $actor = bm_watch_party_guest_actor();
}
if (str_starts_with($action, 'voice_')) {
    if (!$actor || !bm_watch_party_voice_test_allowed($actor)) {
        bm_wp_json(false, ['error' => 'voice_test_forbidden', 'message' => 'Voice Call برای این اتاق یا حساب فعال نیست.'], 403);
    }
    $nonceHeader = strtolower(trim((string)($_SERVER['HTTP_X_BM_VOICE_NONCE'] ?? '')));
    $nonceBody = strtolower(trim((string)($data['voice_nonce'] ?? '')));
    if ($nonceHeader === '' || $nonceBody === '' || !hash_equals($nonceHeader, $nonceBody)
        || !bm_watch_party_voice_verify_session_nonce($actor, $nonceHeader)) {
        bm_wp_json(false, ['error' => 'voice_test_forbidden', 'message' => 'نشست Voice Call معتبر نیست؛ صفحه را دوباره باز کنید.'], 403);
    }
}

if (!bm_watch_party_is_enabled()) {
    bm_wp_json(false, ['error' => 'not_found'], 404);
}

try {
    if ($action === 'status') {
        bm_wp_json(true, [
            'schema_ready' => $schemaReady,
            'enabled' => bm_watch_party_is_enabled(),
            'admin_preview_enabled' => bm_watch_party_admin_preview_enabled(),
            'public_visible' => false,
            'vip_only' => false,
        'host_vip_required' => true,
        'guest_invite_free' => true,
            'room_hours' => bm_watch_party_max_hours(),
            'max_members' => bm_watch_party_max_members(),
            'chat_enabled' => bm_watch_party_chat_enabled(),
            'transport' => 'php-polling-foundation',
            'voice_call_enabled' => $actor ? bm_watch_party_voice_test_allowed($actor) : false,
        ]);
    }

    if (!$schemaReady) {
        throw new RuntimeException('watch_party_schema_unavailable', 503);
    }

    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        bm_require_user_csrf(true, true);
    }

    if ($action === 'create') {
        bm_require_post(true);
        if (!$registeredUser || !bm_watch_party_is_vip($registeredUser)) {
            bm_wp_json(false, ['error' => 'vip_required', 'message' => 'ساخت اتاق فقط برای کاربران VIP فعال است.'], 403);
        }
        $result = bm_watch_party_create_room($pdo, $registeredUser, $data);
        bm_wp_json(true, ['room' => $result], 201);
    }

    if ($action === 'join') {
        bm_require_post(true);
        if (!$actor) throw new RuntimeException('not_room_member', 403);
        $result = bm_watch_party_join_room($pdo, $actor, (string)($data['room_code'] ?? ''));
        bm_wp_json(true, ['membership' => $result]);
    }

    $roomCode = (string)($data['room_code'] ?? $_GET['room_code'] ?? '');
    $room = bm_watch_party_find_room($pdo, $roomCode);
    if (!$room) {
        $reason = (string)($GLOBALS['bm_watch_party_room_lookup_reason'] ?? 'not_found');
        throw new RuntimeException($reason === 'expired' ? 'room_expired' : 'room_not_found', 404);
    }
    if (!$actor) throw new RuntimeException('not_room_member', 403);
    $member = bm_watch_party_require_member($pdo, $room, $actor);

    if ($action === 'poll') {
        $result = bm_watch_party_poll(
            $pdo,
            $room,
            $actor,
            max(0, (int)($_GET['after_event_id'] ?? $data['after_event_id'] ?? 0)),
            max(0, (int)($_GET['after_message_id'] ?? $data['after_message_id'] ?? 0))
        );
        // Voice uses the existing Watch Party poll: no second polling loop and no audio is stored here.
        $result['chat_enabled'] = bm_watch_party_chat_enabled();
        $result['voice'] = bm_watch_party_voice_poll(
            $pdo,
            $room,
            $actor,
            max(0, (int)($_GET['after_voice_signal_id'] ?? $data['after_voice_signal_id'] ?? 0))
        );
        bm_wp_json(true, $result);
    }

    if ($action === 'voice_start') {
        bm_require_post(true);
        $result = bm_watch_party_voice_start_call($pdo, $room, $actor);
        bm_wp_json(true, $result, 201);
    }

    if ($action === 'voice_action') {
        bm_require_post(true);
        $result = bm_watch_party_voice_action(
            $pdo,
            $room,
            $actor,
            (string)($data['call_token'] ?? ''),
            (string)($data['voice_action'] ?? ''),
            $data
        );
        bm_wp_json(true, $result);
    }

    if ($action === 'voice_signal') {
        bm_require_post(true);
        $payloadRaw = $data['payload'] ?? null;
        if (is_string($payloadRaw)) {
            $decoded = json_decode($payloadRaw, true);
            $payloadRaw = json_last_error() === JSON_ERROR_NONE ? $decoded : null;
        }
        $result = bm_watch_party_voice_signal(
            $pdo,
            $room,
            $actor,
            (string)($data['call_token'] ?? ''),
            (string)($data['signal_type'] ?? ''),
            (string)($data['client_signal_id'] ?? ''),
            $payloadRaw
        );
        bm_wp_json(true, $result, 201);
    }

    if ($action === 'control') {
        bm_require_post(true);
        $result = bm_watch_party_update_state($pdo, $room, $actor, $member, $data);
        bm_wp_json(true, ['state' => $result]);
    }

    if ($action === 'room_settings') {
        bm_require_post(true);
        $result = bm_watch_party_update_room_settings($pdo, $room, $actor, $member, $data);
        bm_wp_json(true, ['settings' => $result]);
    }

    if ($action === 'schedule_start') {
        bm_require_post(true);
        $result = bm_watch_party_schedule_start($pdo, $room, $actor, $member, $data);
        bm_wp_json(true, ['schedule' => $result]);
    }

    if ($action === 'message') {
        bm_require_post(true);
        $result = bm_watch_party_add_message($pdo, $room, $actor, (string)($data['message'] ?? ''), (string)($data['client_message_id'] ?? ''));
        bm_wp_json(true, ['chat' => $result], 201);
    }

    if ($action === 'leave') {
        bm_require_post(true);
        $result = bm_watch_party_leave_room($pdo, $room, $actor, $member);
        bm_wp_json(true, $result);
    }

    if ($action === 'close') {
        bm_require_post(true);
        bm_watch_party_close_room($pdo, $room, $actor, $member);
        bm_wp_json(true, ['room_closed' => true]);
    }

    bm_wp_json(false, ['error' => 'unknown_action'], 404);
} catch (Throwable $e) {
    bm_wp_error_from_exception($e);
}
