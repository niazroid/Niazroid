<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
@include_once __DIR__ . '/includes/_bm_support_widget.php';

require_once 'config.php';
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/bm_analytics.php';
require_once __DIR__ . '/includes/weekly_schedule.php';
$bmArchivePublicConfig = bm_archive_public_config();
// UX change: every fresh visit/back to index starts from Archive 1.
// User can still switch archives on the page, but we no longer persist that choice as the next default.
$bmArchiveDefaultMode = bm_archive_default_mode();
if (bm_archive_is_enabled('archive1') && bm_archive_should_render_tab('archive1')) {
    $bmArchiveDefaultMode = 'arc1';
}
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// CSRF Token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

// Lightweight analytics
bm_analytics_track($pdo, ['page_type' => 'home', 'user_id' => $currentUser['id'] ?? null]);

// User Settings
$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) {
    $userTheme = 'dark-green';
}
$currentThemeInfo = $themes[$userTheme];
$themeHex = ltrim($currentThemeInfo['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

// تابع تبدیل اعداد فارسی به انگلیسی
function enNumbers($str) {
    $persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    $english = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
    return str_replace($persian, $english, $str);
}

// Multi-language


// ========== BankMovie Front Ads Layer (safe, no core logic changes) ==========
if(!function_exists('bm_ads_table_exists')){
    function bm_ads_table_exists(PDO $pdo, string $table): bool {
        static $cache = [];
        if(isset($cache[$table])) return $cache[$table];
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?");
            $stmt->execute([$table]);
            return $cache[$table] = ((int)$stmt->fetchColumn() > 0);
        } catch(Throwable $e) {
            return $cache[$table] = false;
        }
    }
}

if(!function_exists('bm_get_active_ads')){
    function bm_get_active_ads(PDO $pdo, string $position, int $limit = 1): array {
        $limit = max(1, min(6, (int)$limit));
        if(!bm_ads_table_exists($pdo, 'admin_banners')) return [];
        try {
            $sql = "SELECT id, title, position, image_path, link_url FROM admin_banners
                    WHERE is_active = 1
                      AND position = ?
                      AND (starts_at IS NULL OR starts_at <= NOW())
                      AND (ends_at IS NULL OR ends_at >= NOW())
                    ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
                    LIMIT " . $limit;
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$position]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch(Throwable $e) {
            return [];
        }
    }
}

if(!function_exists('bm_render_ad_slot')){
    function bm_render_ad_slot(PDO $pdo, string $position, string $variant = 'wide', int $limit = 1): string {
        if (function_exists('bm_vip_ad_free_for_user') && bm_vip_ad_free_for_user($GLOBALS['currentUser'] ?? null)) return '';
        if (function_exists('bm_site_bool')) {
            if (!bm_site_bool('ads_internal_enabled', true)) return '';
            $positionKeys = [
                'global_banner' => 'ads_global_banner_enabled',
                'home_top' => 'ads_home_top_enabled',
                'home_middle' => 'ads_home_middle_enabled',
                'home_bottom' => 'ads_home_bottom_enabled',
                'movie_page' => 'ads_movie_page_enabled',
                'mobile' => 'ads_floating_enabled',
            ];
            if (isset($positionKeys[$position]) && !bm_site_bool($positionKeys[$position], true)) return '';
            $isMobile = function_exists('bm_yektanet_is_mobile_request') ? bm_yektanet_is_mobile_request() : (bool)preg_match('/android|iphone|ipod|mobile|windows phone/i', strtolower((string)($_SERVER['HTTP_USER_AGENT'] ?? '')));
            if ($isMobile && !bm_site_bool('ads_mobile_enabled', true)) return '';
            if (!$isMobile && !bm_site_bool('ads_desktop_enabled', true)) return '';
            if ($variant === 'floating' && !bm_site_bool('ads_floating_enabled', true)) return '';
        }
        $ads = bm_get_active_ads($pdo, $position, $limit);
        if(!$ads) return '';
        $lang = $GLOBALS['userLang'] ?? 'fa';
        $label = $lang === 'fa' ? (string)(function_exists('bm_site_get') ? bm_site_get('ads_label_fa','تبلیغات') : 'تبلیغات') : 'Advertisement';
        $openText = $lang === 'fa' ? 'مشاهده' : 'Open';
        $closeText = $lang === 'fa' ? (string)(function_exists('bm_site_get') ? bm_site_get('ads_close_label_fa','بستن تبلیغ') : 'بستن تبلیغ') : 'Close ad';
        $safeVariant = preg_replace('/[^a-z0-9_-]/i', '', $variant) ?: 'wide';
        ob_start();
        ?>
<section class="bm-ad-slot bm-ad-<?= e($safeVariant) ?>" data-ad-position="<?= e($position) ?>" aria-label="<?= e($label) ?>">
    <?php if($safeVariant === 'floating'): ?>
    <button type="button" class="bm-ad-close" data-bm-ad-close aria-label="<?= e($closeText) ?>">×</button>
    <?php endif; ?>
    <div class="bm-ad-grid">
        <?php foreach($ads as $ad):
            $title = trim((string)($ad['title'] ?? '')) ?: $label;
            $imagePath = trim((string)($ad['image_path'] ?? ''));
            $linkUrl = trim((string)($ad['link_url'] ?? ''));
            $isLink = $linkUrl !== '' && filter_var($linkUrl, FILTER_VALIDATE_URL);
            $hasImage = $imagePath !== '' && (preg_match('/^https?:\/\//i', $imagePath) || is_file(__DIR__ . '/' . ltrim($imagePath, '/')));
        ?>
            <?php if($isLink): ?>
            <a class="bm-ad-card" href="<?= e($linkUrl) ?>" target="_blank" rel="noopener nofollow sponsored" title="<?= e($title) ?>">
            <?php else: ?>
            <div class="bm-ad-card" title="<?= e($title) ?>">
            <?php endif; ?>
                <?php if($hasImage): ?>
                    <img src="<?= e($imagePath) ?>" alt="<?= e($title) ?>" loading="lazy">
                <?php else: ?>
                    <div class="bm-ad-fallback">
                        <span class="bm-ad-fallback-icon">AD</span>
                        <strong><?= e($title) ?></strong>
                    </div>
                <?php endif; ?>
                <span class="bm-ad-glow"></span>
                <span class="bm-ad-badge"><?= e($label) ?></span>
                <span class="bm-ad-cta"><?= e($openText) ?></span>
            <?php if($isLink): ?>
            </a>
            <?php else: ?>
            </div>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
</section>
        <?php
        return trim(ob_get_clean());
    }
}
// ========== /BankMovie Front Ads Layer ==========


$t = [
    'fa' => [
        'site_title' => 'دانلود فیلم و سریال', 'stories' => 'استوری‌ها', 'search_placeholder' => 'جستجوی فیلم، سریال، بازیگر، کارگردان...',
        'advanced_search' => 'جستجوی پیشرفته', 'all' => 'همه', 'movie' => 'فیلم', 'series' => 'سریال', 'animation' => 'انیمیشن',
        'random' => 'تصادفی', 'genres' => 'ژانرها', 'popular_countries' => 'کشورهای محبوب', 'new_releases' => 'جدیدترین اکران',
        'new_releases_2025' => 'جدیدترین ریلیزهای ۲۰۲۵', 'latest_animations' => 'جدیدترین انیمیشن‌ها',
        'view_all' => 'مشاهده همه', 'admin_picks' => 'پیشنهادات ویژه ادمین', 'top_movies' => 'برترین فیلم‌ها',
        'top_series' => 'برترین سریال‌ها', 'top_user_rated' => 'محبوب‌ترین نزد کاربران', 'persian_dubbed' => 'دوبله فارسی',
        'smart_suggestions' => 'پیشنهاد هوشمند برای شما', 'recent_updates' => 'آپدیت اخیر', 'special_collections' => 'کالکشن‌های ویژه',
        'movies_in_collection' => 'فیلم', 'load_more' => 'بارگذاری بیشتر', 'no_results' => 'نتیجه‌ای یافت نشد',
        'support_us' => 'حمایت مالی', 'support_text' => 'اگر از سایت بانک مووی راضی هستید، با یک حمایت کوچک در هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن', 'donate' => 'حمایت مالی',
        'home' => 'خانه', 'profile' => 'پروفایل', 'player' => 'پلیر', 'request' => 'درخواست فیلم و سریال', 'auth' => 'ثبت نام و ورود', 'account' => 'حساب کاربری', 'login' => 'ورود', 'register' => 'ثبت نام', 'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت', 'guest' => 'کاربر مهمان', 'notifications' => 'اعلان‌ها', 'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'download_story' => 'دانلود استوری', 'hold_to_pause' => 'نگه دارید برای مکث', 'swipe_to_navigate' => 'بکشید برای بعدی/قبلی',
        'notif_latest' => 'آخرین اعلان',
    ],
    'en' => [
        'site_title' => 'Download Movies & Series', 'stories' => 'Stories', 'search_placeholder' => 'Search movies, series, actors, directors...',
        'advanced_search' => 'Advanced Search', 'all' => 'All', 'movie' => 'Movie', 'series' => 'Series', 'animation' => 'Animation',
        'random' => 'Random', 'genres' => 'Genres', 'popular_countries' => 'Popular Countries', 'new_releases' => 'New Releases',
        'new_releases_2025' => 'New Releases 2025', 'latest_animations' => 'Latest Animations',
        'view_all' => 'View All', 'admin_picks' => 'Admin Picks', 'top_movies' => 'Top Movies', 'top_series' => 'Top Series',
        'top_user_rated' => 'Top User Rated', 'persian_dubbed' => 'Persian Dubbed', 'smart_suggestions' => 'Smart Suggestions for You',
        'recent_updates' => 'Recent Updates', 'special_collections' => 'Special Collections', 'movies_in_collection' => 'Movies',
        'load_more' => 'Load More', 'no_results' => 'No results found', 'support_us' => 'Support Us',
        'support_text' => 'All services on this site are free. If you would like to help us improve the site quality and renew the server, you can donate.',
        'close' => 'Close', 'donate' => 'Donate',
        'home' => 'Home', 'profile' => 'Profile', 'player' => 'Player', 'request' => 'Request Movie / Series', 'auth' => 'Login / Register', 'account' => 'Account', 'login' => 'Login', 'register' => 'Register',
        'logout' => 'Logout', 'admin_panel' => 'Admin Panel', 'guest' => 'Guest', 'notifications' => 'Notifications',
        'no_notifications' => 'No notifications', 'download_story' => 'Download story', 'hold_to_pause' => 'Hold to pause',
        'swipe_to_navigate' => 'Swipe to navigate', 'notif_latest' => 'Latest notification',
    ]
];

// تابع پرچم کامل
function getCountryFlag($countryName) {
    $countryCodes = [
        'Afghanistan' => 'AF', 'Albania' => 'AL', 'Algeria' => 'DZ', 'Andorra' => 'AD', 'Angola' => 'AO',
        'Argentina' => 'AR', 'Armenia' => 'AM', 'Australia' => 'AU', 'Austria' => 'AT', 'Azerbaijan' => 'AZ',
        'Bahamas' => 'BS', 'Bahrain' => 'BH', 'Bangladesh' => 'BD', 'Barbados' => 'BB', 'Belarus' => 'BY',
        'Belgium' => 'BE', 'Belize' => 'BZ', 'Benin' => 'BJ', 'Bhutan' => 'BT', 'Bolivia' => 'BO',
        'Bosnia and Herzegovina' => 'BA', 'Botswana' => 'BW', 'Brazil' => 'BR', 'Brunei' => 'BN', 'Bulgaria' => 'BG',
        'Burkina Faso' => 'BF', 'Burundi' => 'BI', 'Cabo Verde' => 'CV', 'Cambodia' => 'KH', 'Cameroon' => 'CM',
        'Canada' => 'CA', 'Central African Republic' => 'CF', 'Chad' => 'TD', 'Chile' => 'CL', 'China' => 'CN',
        'Colombia' => 'CO', 'Comoros' => 'KM', 'Congo' => 'CG', 'Costa Rica' => 'CR', 'Croatia' => 'HR',
        'Cuba' => 'CU', 'Cyprus' => 'CY', 'Czech Republic' => 'CZ', 'Denmark' => 'DK', 'Djibouti' => 'DJ',
        'Dominica' => 'DM', 'Dominican Republic' => 'DO', 'Ecuador' => 'EC', 'Egypt' => 'EG', 'El Salvador' => 'SV',
        'Equatorial Guinea' => 'GQ', 'Eritrea' => 'ER', 'Estonia' => 'EE', 'Eswatini' => 'SZ', 'Ethiopia' => 'ET',
        'Fiji' => 'FJ', 'Finland' => 'FI', 'France' => 'FR', 'Gabon' => 'GA', 'Gambia' => 'GM', 'Georgia' => 'GE',
        'Germany' => 'DE', 'Ghana' => 'GH', 'Greece' => 'GR', 'Grenada' => 'GD', 'Guatemala' => 'GT',
        'Guinea' => 'GN', 'Guinea-Bissau' => 'GW', 'Guyana' => 'GY', 'Haiti' => 'HT', 'Honduras' => 'HN',
        'Hungary' => 'HU', 'Iceland' => 'IS', 'India' => 'IN', 'Indonesia' => 'ID', 'Iran' => 'IR', 'Iraq' => 'IQ',
        'Ireland' => 'IE', 'Israel' => 'IL', 'Italy' => 'IT', 'Jamaica' => 'JM', 'Japan' => 'JP', 'Jordan' => 'JO',
        'Kazakhstan' => 'KZ', 'Kenya' => 'KE', 'Kiribati' => 'KI', 'Korea, North' => 'KP', 'Korea, South' => 'KR',
        'Kosovo' => 'XK', 'Kuwait' => 'KW', 'Kyrgyzstan' => 'KG', 'Laos' => 'LA', 'Latvia' => 'LV', 'Lebanon' => 'LB',
        'Lesotho' => 'LS', 'Liberia' => 'LR', 'Libya' => 'LY', 'Liechtenstein' => 'LI', 'Lithuania' => 'LT',
        'Luxembourg' => 'LU', 'Madagascar' => 'MG', 'Malawi' => 'MW', 'Malaysia' => 'MY', 'Maldives' => 'MV',
        'Mali' => 'ML', 'Malta' => 'MT', 'Marshall Islands' => 'MH', 'Mauritania' => 'MR', 'Mauritius' => 'MU',
        'Mexico' => 'MX', 'Micronesia' => 'FM', 'Moldova' => 'MD', 'Monaco' => 'MC', 'Mongolia' => 'MN',
        'Montenegro' => 'ME', 'Morocco' => 'MA', 'Mozambique' => 'MZ', 'Myanmar' => 'MM', 'Namibia' => 'NA',
        'Nauru' => 'NR', 'Nepal' => 'NP', 'Netherlands' => 'NL', 'New Zealand' => 'NZ', 'Nicaragua' => 'NI',
        'Niger' => 'NE', 'Nigeria' => 'NG', 'North Macedonia' => 'MK', 'Norway' => 'NO', 'Oman' => 'OM',
        'Pakistan' => 'PK', 'Palau' => 'PW', 'Palestine' => 'PS', 'Panama' => 'PA', 'Papua New Guinea' => 'PG',
        'Paraguay' => 'PY', 'Peru' => 'PE', 'Philippines' => 'PH', 'Poland' => 'PL', 'Portugal' => 'PT',
        'Qatar' => 'QA', 'Romania' => 'RO', 'Russia' => 'RU', 'Rwanda' => 'RW', 'Saint Kitts and Nevis' => 'KN',
        'Saint Lucia' => 'LC', 'Saint Vincent and the Grenadines' => 'VC', 'Samoa' => 'WS', 'San Marino' => 'SM',
        'Sao Tome and Principe' => 'ST', 'Saudi Arabia' => 'SA', 'Senegal' => 'SN', 'Serbia' => 'RS',
        'Seychelles' => 'SC', 'Sierra Leone' => 'SL', 'Singapore' => 'SG', 'Slovakia' => 'SK', 'Slovenia' => 'SI',
        'Solomon Islands' => 'SB', 'Somalia' => 'SO', 'South Africa' => 'ZA', 'South Sudan' => 'SS',
        'Spain' => 'ES', 'Sri Lanka' => 'LK', 'Sudan' => 'SD', 'Suriname' => 'SR', 'Sweden' => 'SE',
        'Switzerland' => 'CH', 'Syria' => 'SY', 'Taiwan' => 'TW', 'Tajikistan' => 'TJ', 'Tanzania' => 'TZ',
        'Thailand' => 'TH', 'Timor-Leste' => 'TL', 'Togo' => 'TG', 'Tonga' => 'TO', 'Trinidad and Tobago' => 'TT',
        'Tunisia' => 'TN', 'Turkey' => 'TR', 'Turkmenistan' => 'TM', 'Tuvalu' => 'TV', 'Uganda' => 'UG',
        'Ukraine' => 'UA', 'United Arab Emirates' => 'AE', 'United Kingdom' => 'GB', 'United States of America' => 'US',
        'Uruguay' => 'UY', 'Uzbekistan' => 'UZ', 'Vanuatu' => 'VU', 'Vatican City' => 'VA', 'Venezuela' => 'VE',
        'Vietnam' => 'VN', 'Yemen' => 'YE', 'Zambia' => 'ZM', 'Zimbabwe' => 'ZW'
    ];
    $countryName = trim((string)$countryName);
    $aliases = [
        'United States' => 'United States of America',
        'USA' => 'United States of America',
        'US' => 'United States of America',
        'UK' => 'United Kingdom',
        'UAE' => 'United Arab Emirates',
        'Soviet Union' => 'Russia',
        'Czechia' => 'Czech Republic',
        'South Korea' => 'Korea, South',
        'North Korea' => 'Korea, North',
    ];
    if(isset($aliases[$countryName])) $countryName = $aliases[$countryName];
    $code = $countryCodes[$countryName] ?? '';
    if($code) {
        $regionalOffset = 0x1F1E6;
        $firstChar = $regionalOffset + (ord($code[0]) - ord('A'));
        $secondChar = $regionalOffset + (ord($code[1]) - ord('A'));
        return '&#' . $firstChar . ';&#' . $secondChar . ';';
    }
    return '🏳️';
}
function e($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
function js_json($value) {
    return json_encode(
        $value,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    );
}

// ========== گرفتن دیتا از دیتابیس ==========
$stmt = $pdo->query("SELECT * FROM stories ORDER BY story_order ASC");
$stories = $stmt->fetchAll();
foreach ($stories as &$bmStoryRow) {
    foreach (['file_path','thumbnail_path','thumb_path','poster_path','cover_path','cover_image','thumbnail','poster','cover','image','image_path'] as $bmStoryAssetKey) {
        if (array_key_exists($bmStoryAssetKey, $bmStoryRow)) {
            $bmStoryRow[$bmStoryAssetKey] = bm_public_asset_url($bmStoryRow[$bmStoryAssetKey], '');
        }
    }
}
unset($bmStoryRow);

$adminPicks = $movie->getAdminPicks(20);
// جدیدترین اکران - شامل ریلیزهای ۲۰۲۵ هم میشه
$newReleases = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        ORDER BY 
            CASE WHEN year >= 2025 THEN 1 ELSE 0 END DESC,
            created_at DESC,
            year DESC,
            imdb_rate DESC
        LIMIT 20
    ");
    $stmt->execute();
    $newReleases = $stmt->fetchAll();
    if(count($newReleases) === 0) {
        $newReleases = $movie->getNewReleases(20);
    }
} catch(PDOException $e) {
    $newReleases = $movie->getNewReleases(20);
}
$topMovies = $movie->getTopRated('movie', 20);
$topSeries = $movie->getTopRated('tvSeries', 20);

$updatedMovies = $movie->getUpdatedMovies(20);

// V96 — آرشیو ۲ دیتابیس: فقط دیتاست‌های لازم برای صفحه اصلی
$newMovies = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies
        WHERE type = 'movie'
        ORDER BY created_at DESC, id DESC
        LIMIT 20
    ");
    $stmt->execute();
    $newMovies = $stmt->fetchAll();
} catch(PDOException $e) {
    $newMovies = [];
}

$updatedSeries = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies
        WHERE type = 'tvSeries' OR type = 'tvMiniSeries'
        ORDER BY COALESCE(updated_at, created_at) DESC, id DESC
        LIMIT 20
    ");
    $stmt->execute();
    $updatedSeries = $stmt->fetchAll();
} catch(PDOException $e) {
    $updatedSeries = [];
}

// دوبله فارسی بر اساس جدیدترین اضافه شده
$dubbedMovies = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE dubbed = 1 OR dubbed = 'true' OR dubbed = 'fa' 
           OR persian_dubbed = 1 OR has_dubbed = 1
           OR (audio_languages IS NOT NULL AND audio_languages LIKE '%fa%')
           OR (audio_languages IS NOT NULL AND audio_languages LIKE '%Persian%')
        ORDER BY created_at DESC, id DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $dubbedMovies = $stmt->fetchAll();
    if(count($dubbedMovies) === 0) {
        $dubbedMovies = $movie->getDubbed(20);
    }
} catch(PDOException $e) {
    $dubbedMovies = $movie->getDubbed(20);
}

// ریلیزهای جدید ۲۰۲۵
$newReleases2025 = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE year >= 2025 
        ORDER BY year DESC, created_at DESC, imdb_rate DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $newReleases2025 = $stmt->fetchAll();
} catch(PDOException $e) {
    $newReleases2025 = [];
}

// جدیدترین انیمیشن‌ها
$latestAnimations = [];
try {
    $stmt = $pdo->prepare("
        SELECT * FROM movies 
        WHERE (genres LIKE '%Animation%' OR genres LIKE '%Kids%' OR type = 'animation')
        ORDER BY created_at DESC, year DESC, imdb_rate DESC 
        LIMIT 20
    ");
    $stmt->execute();
    $latestAnimations = $stmt->fetchAll();
} catch(PDOException $e) {
    $latestAnimations = [];
}

$activeCollections = $pdo->query("
    SELECT c.*, COUNT(cm.id) as movie_count 
    FROM collections c
    LEFT JOIN collection_movies cm ON c.id = cm.collection_id
    WHERE c.status = 1
    GROUP BY c.id
    ORDER BY c.id DESC
    LIMIT 12
")->fetchAll();

$topUserRated = [];
try {
    $stmt = $pdo->prepare("
        SELECT m.*, COALESCE(r.avg_rating,0) as user_rating, COALESCE(r.total_votes,0) as total_votes
        FROM movies m LEFT JOIN movie_ratings r ON m.id=r.movie_id
        WHERE COALESCE(r.total_votes,0)>0
        ORDER BY COALESCE(r.avg_rating,0) DESC, COALESCE(r.total_votes,0) DESC LIMIT 20
    ");
    $stmt->execute();
    $topUserRated = $stmt->fetchAll();
    if(count($topUserRated)===0){
        $stmt = $pdo->prepare("
            SELECT m.*, AVG(c.rating) as user_rating, COUNT(c.id) as total_votes
            FROM movies m INNER JOIN comments c ON m.id=c.movie_id
            WHERE c.rating>0 AND c.status='active'
            GROUP BY m.id HAVING COUNT(c.id)>=1
            ORDER BY AVG(c.rating) DESC, COUNT(c.id) DESC LIMIT 20
        ");
        $stmt->execute();
        $topUserRated = $stmt->fetchAll();
    }
} catch(PDOException $e) { $topUserRated = []; }

$smartSuggestions = [];
if($currentUser){
    $stmt = $pdo->prepare("
        SELECT DISTINCT m.genres, m.actors 
        FROM (SELECT movie_id FROM watch_history WHERE user_id=? UNION SELECT movie_id FROM watchlist WHERE user_id=?) AS watched
        JOIN movies m ON watched.movie_id=m.id
        WHERE (m.genres IS NOT NULL AND m.genres!='') OR (m.actors IS NOT NULL AND m.actors!='') LIMIT 10
    ");
    $stmt->execute([$currentUser['id'], $currentUser['id']]);
    $userInterests = $stmt->fetchAll();
    $keywords = [];
    foreach($userInterests as $interest){
        if(!empty($interest['genres'])){
            foreach(explode(',', $interest['genres']) as $g){ $g=trim($g); if(strlen($g)>2) $keywords[]=$g; }
        }
        if(!empty($interest['actors'])){
            foreach(explode(',', $interest['actors']) as $a){ $a=trim($a); if(strlen($a)>2) $keywords[]=$a; }
        }
    }
    $keywords = array_unique($keywords);
    if(count($keywords)>0){
        $conditions = []; $params = [];
        foreach($keywords as $kw){
            $conditions[] = "(m.genres LIKE ? OR m.actors LIKE ?)";
            $params[] = "%{$kw}%"; $params[] = "%{$kw}%";
        }
        $whereSql = implode(" OR ", $conditions);
        $sql = "SELECT DISTINCT m.* FROM movies m WHERE ($whereSql) AND m.id NOT IN (SELECT movie_id FROM watch_history WHERE user_id=?) AND m.id NOT IN (SELECT movie_id FROM watchlist WHERE user_id=?) ORDER BY m.imdb_rate DESC LIMIT 20";
        $params[] = $currentUser['id']; $params[] = $currentUser['id'];
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $smartSuggestions = $stmt->fetchAll();
    }
}

$genresList = $pdo->query("
    SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) as genre
    FROM movies CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers
    WHERE genres IS NOT NULL AND genres != ''
    HAVING genre != '' AND genre IS NOT NULL ORDER BY genre
")->fetchAll(PDO::FETCH_COLUMN);

$genrePersian = [
    'Action'=>'اکشن','Adventure'=>'ماجراجویی','Animation'=>'انیمیشن','Comedy'=>'کمدی',
    'Crime'=>'جنایی','Drama'=>'درام','Documentary'=>'مستند','Family'=>'خانوادگی',
    'Fantasy'=>'فانتزی','History'=>'تاریخی','Horror'=>'ترسناک','Kids'=>'کودکان',
    'Music'=>'موسیقی','Mystery'=>'معمایی','Romance'=>'عاشقانه','Sci-Fi'=>'علمی تخیلی',
    'Thriller'=>'هیجان‌انگیز','War'=>'جنگی','Western'=>'وسترن','Biography'=>'زندگی‌نامه','Sport'=>'ورزشی'
];

$allCountries = [
    'Afghanistan', 'Albania', 'Algeria', 'Andorra', 'Angola', 'Argentina', 'Armenia', 'Australia', 'Austria', 'Azerbaijan',
    'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus', 'Belgium', 'Belize', 'Benin', 'Bhutan', 'Bolivia',
    'Bosnia and Herzegovina', 'Botswana', 'Brazil', 'Brunei', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cabo Verde', 'Cambodia', 'Cameroon',
    'Canada', 'Central African Republic', 'Chad', 'Chile', 'China', 'Colombia', 'Comoros', 'Congo', 'Costa Rica', 'Croatia',
    'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'Ecuador', 'Egypt', 'El Salvador',
    'Equatorial Guinea', 'Eritrea', 'Estonia', 'Eswatini', 'Ethiopia', 'Fiji', 'Finland', 'France', 'Gabon', 'Gambia', 'Georgia',
    'Germany', 'Ghana', 'Greece', 'Grenada', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Honduras',
    'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan',
    'Kazakhstan', 'Kenya', 'Kiribati', 'Korea, North', 'Korea, South', 'Kosovo', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Latvia',
    'Lebanon', 'Lesotho', 'Liberia', 'Libya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Madagascar', 'Malawi', 'Malaysia',
    'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Mauritania', 'Mauritius', 'Mexico', 'Micronesia', 'Moldova', 'Monaco',
    'Mongolia', 'Montenegro', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'New Zealand',
    'Nicaragua', 'Niger', 'Nigeria', 'North Macedonia', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Palestine', 'Panama',
    'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 'Rwanda',
    'Saint Kitts and Nevis', 'Saint Lucia', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe',
    'Saudi Arabia', 'Senegal', 'Serbia', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia', 'Slovenia', 'Solomon Islands',
    'Somalia', 'South Africa', 'South Sudan', 'Spain', 'Sri Lanka', 'Sudan', 'Suriname', 'Sweden', 'Switzerland', 'Syria',
    'Taiwan', 'Tajikistan', 'Tanzania', 'Thailand', 'Timor-Leste', 'Togo', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey',
    'Turkmenistan', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States of America', 'Uruguay',
    'Uzbekistan', 'Vanuatu', 'Vatican City', 'Venezuela', 'Vietnam', 'Yemen', 'Zambia', 'Zimbabwe'
];

// Notifications
$notificationsList = [];
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
$stmt->execute();
$notificationsList = $stmt->fetchAll();
$latestNotification = !empty($notificationsList) ? $notificationsList[0] : null;
$activeNotification = null;
$notificationSeen = false;
$stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 1");
$stmt->execute();
$activeNotification = $stmt->fetch();
if($activeNotification) {
    $cookieName = 'notification_seen_' . $activeNotification['id'];
    if(isset($_COOKIE[$cookieName])) $notificationSeen = true;
}

// Slider slides
$sliderSlides = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM slider_slides WHERE is_active = 1 ORDER BY slide_order ASC");
    $stmt->execute();
    $sliderSlides = $stmt->fetchAll();
    foreach ($sliderSlides as &$bmSlideRow) { $bmSlideRow['image_path'] = bm_public_asset_url($bmSlideRow['image_path'] ?? '', ''); } unset($bmSlideRow);
} catch (PDOException $e) {
    $sliderSlides = [];
}

// Home SEO is deliberately stable and independent from cookies, slider titles and archive state.
// This prevents search engines from receiving a different title/description on separate crawls.
$bmSeoCanonical = function_exists('bm_seo_base_url') ? (bm_seo_base_url() . '/') : rtrim(SITE_URL, '/') . '/';
$bmSeoTitle = trim((string)bm_site_get('seo_home_title', 'بانک مووی | دانلود فیلم و سریال با دوبله و زیرنویس فارسی'));
$bmSeoDescription = trim((string)bm_site_get('seo_home_description', 'دانلود و تماشای آنلاین جدیدترین فیلم‌ها و سریال‌ها با دوبله فارسی، زیرنویس فارسی و لینک مستقیم در بانک مووی.'));
$bmSeoImage = function_exists('bm_seo_default_image') ? bm_seo_default_image() : ($bmSeoCanonical . 'assets/brand/bankmovie-og.png');
$bmSeoSameAs = array_values(array_filter([
    bm_site_bool('telegram_enabled', true) ? trim((string)bm_site_get('telegram_url','')) : '',
    bm_site_bool('instagram_enabled', true) ? trim((string)bm_site_get('instagram_url','')) : '',
]));
$bmSeoSchema = [
    '@context' => 'https://schema.org',
    '@graph' => [
        [
            '@type' => 'WebSite',
            '@id' => $bmSeoCanonical . '#website',
            'url' => $bmSeoCanonical,
            'name' => 'بانک مووی',
            'alternateName' => ['BankMovie', 'Bank Movie'],
            'inLanguage' => 'fa-IR',
            'publisher' => ['@id' => $bmSeoCanonical . '#organization'],
            'potentialAction' => [
                '@type' => 'SearchAction',
                'target' => [
                    '@type' => 'EntryPoint',
                    'urlTemplate' => $bmSeoCanonical . '/search?q={search_term_string}',
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ],
        [
            '@type' => 'Organization',
            '@id' => $bmSeoCanonical . '#organization',
            'name' => (string)bm_site_get('seo_organization_name','بانک مووی'),
            'alternateName' => 'BankMovie',
            'url' => $bmSeoCanonical,
            'sameAs' => $bmSeoSameAs,
            'logo' => [
                '@type' => 'ImageObject',
                'url' => function_exists('bm_seo_abs_url') ? bm_seo_abs_url((string)bm_site_get('seo_organization_logo','/assets/brand/bankmovie-icon.png')) : $bmSeoCanonical . 'assets/brand/bankmovie-icon.png',
                'width' => 512,
                'height' => 512,
            ],
        ],
        [
            '@type' => 'WebPage',
            '@id' => $bmSeoCanonical . '#webpage',
            'url' => $bmSeoCanonical,
            'name' => $bmSeoTitle,
            'description' => $bmSeoDescription,
            'isPartOf' => ['@id' => $bmSeoCanonical . '#website'],
            'about' => ['@id' => $bmSeoCanonical . '#organization'],
            'breadcrumb' => ['@id' => $bmSeoCanonical . '#breadcrumb'],
            'primaryImageOfPage' => [
                '@type' => 'ImageObject',
                'url' => $bmSeoImage,
                'width' => 1200,
                'height' => 630,
            ],
            'inLanguage' => 'fa-IR',
        ],
        [
            '@type' => 'BreadcrumbList',
            '@id' => $bmSeoCanonical . '#breadcrumb',
            'itemListElement' => [
                ['@type'=>'ListItem','position'=>1,'name'=>'بانک مووی','item'=>$bmSeoCanonical],
            ],
        ],
    ],
];
?>
<!DOCTYPE html>
<html lang="<?= e($langAttr) ?>" dir="<?= e($dir) ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <link rel="preload" href="/assets/fonts/bonVF.woff2" as="font" type="font/woff2" crossorigin>
    <meta name="csrf-token" content="<?= e($csrf_token) ?>">

    <!-- Stable homepage SEO: do not derive these tags from cookies, slider content or archive tabs. -->
    <title><?= e($bmSeoTitle) ?></title>
    <meta name="description" content="<?= e($bmSeoDescription) ?>">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1">
    <meta name="application-name" content="بانک مووی">
    <meta name="apple-mobile-web-app-title" content="بانک مووی">
    <link rel="canonical" href="<?= e($bmSeoCanonical) ?>">

    <meta property="og:type" content="website">
    <meta property="og:locale" content="fa_IR">
    <meta property="og:site_name" content="بانک مووی">
    <meta property="og:title" content="<?= e($bmSeoTitle) ?>">
    <meta property="og:description" content="<?= e($bmSeoDescription) ?>">
    <meta property="og:url" content="<?= e($bmSeoCanonical) ?>">
    <meta property="og:image" content="<?= e($bmSeoImage) ?>">
    <meta property="og:image:secure_url" content="<?= e($bmSeoImage) ?>">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">
    <meta property="og:image:alt" content="لوگوی بانک مووی">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($bmSeoTitle) ?>">
    <meta name="twitter:description" content="<?= e($bmSeoDescription) ?>">
    <meta name="twitter:image" content="<?= e($bmSeoImage) ?>">

    <script type="application/ld+json"><?= json_encode($bmSeoSchema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
  <style>:root{--bm-accent:<?= e($currentThemeInfo['primary']) ?>;--bm-accent-rgb:<?= e($currentThemeRgbCss) ?>;--bm-accent-dark:<?= e($currentThemeInfo['primary']) ?>cc;}</style>
<link rel="stylesheet" href="/assets/css/index-inline-1.css?v=glass110">
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script src="/assets/js/index-inline-1.js?v=mobile-smooth29"></script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-quick-search.css?v=quick101">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body data-theme="<?= e($userTheme) ?>" class="<?= count($sliderSlides) > 0 ? 'has-hero' : 'no-hero' ?>">
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>

<?php if($activeNotification && !$notificationSeen): ?>
<div class="notification-modal" id="notificationModal" style="position:fixed;inset:0;background:rgba(0,0,0,0.95);backdrop-filter:blur(20px);z-index:20000;display:flex;align-items:center;justify-content:center">
    <div style="background:#0f0f13;border:1px solid var(--border-accent);border-radius:32px;padding:40px;max-width:500px;width:90%;text-align:center">
        <div style="width:80px;height:80px;background:var(--accent-glow);border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 20px">
            <svg width="45" height="45" viewBox="0 0 24 24" fill="none" stroke="var(--accent)"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
        </div>
        <div style="font-size:24px;font-weight:800;color:var(--accent);margin-bottom:16px"><?= $userLang=='fa'?'اعلامیه مهم':'Important Announcement' ?></div>
        <div style="color:var(--text-secondary);line-height:1.6;margin-bottom:24px"><?= nl2br(e($activeNotification['message'])) ?></div>
        <button class="notification-btn" id="closeNotificationBtn" type="button" data-notification-id="<?= e((string)($activeNotification['id'] ?? '')) ?>" style="background:var(--accent);color:#000;border:none;padding:12px 32px;border-radius:40px;font-weight:700;cursor:pointer"><?= $userLang=='fa'?'متوجه شدم':'Got it' ?></button>
    </div>
</div>
<?php endif; ?>
<?php if($activeNotification && !$notificationSeen): ?>
<script>window.BM_NOTIFICATION_ID = <?= json_encode((string)($activeNotification['id'] ?? ''), JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="/assets/js/bm-notification.js?v=split35"></script>
<?php endif; ?>

<script src="/assets/js/index-inline-2.js?v=split35"></script>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <?php if($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username']) ?></div><div class="sidebar-userrole"><?= $currentUser['role']==='admin'?($userLang=='fa'?'مدیر':'Admin'):($userLang=='fa'?'کاربر':'User') ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><polygon points="22 3 2 3 10 13 10 21 14 18 14 13 22 3"/></svg><span><?= $t[$userLang]['advanced_search'] ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if($currentUser['role']==='admin'): ?>
        <a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; ?><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang=='fa'?'آیا از خروج مطمئن هستید؟':'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4M10 17l5-5-5-5M15 12H3"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header"><h3><?= $t[$userLang]['notifications'] ?></h3><button class="notif-close" id="closeNotifSidebar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'])) ?></div><div class="notif-date"><?= date('Y/m/d H:i', strtotime($notif['created_at'])) ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<?php if(count($sliderSlides) > 0): ?>
<div class="hero-slider" dir="ltr">
    <div class="hero-track">
        <?php foreach($sliderSlides as $index => $slide): ?>
        <div class="hero-slide <?= $index === 0 ? 'active' : '' ?>" data-index="<?= $index ?>">
            <img src="<?= e(bm_public_asset_url($slide['image_path'] ?? '')) ?>" class="hero-bg" loading="<?= $index === 0 ? 'eager' : 'lazy' ?>" decoding="async" fetchpriority="<?= $index === 0 ? 'high' : 'low' ?>" alt="<?= e($userLang === 'fa' ? $slide['title_fa'] : ($slide['title_en'] ?: $slide['title_fa'])) ?>">
            <div class="hero-overlay"></div>
            <div class="hero-content">
                <div class="hero-title"><?= e($userLang === 'fa' ? $slide['title_fa'] : ($slide['title_en'] ?: $slide['title_fa'])) ?></div>
                <?php if(!empty($slide['subtitle_fa']) || !empty($slide['subtitle_en'])): ?>
                <div class="hero-desc"><?= e($userLang === 'fa' ? $slide['subtitle_fa'] : ($slide['subtitle_en'] ?: $slide['subtitle_fa'])) ?></div>
                <?php endif; ?>
                <?php if(!empty($slide['link'])): ?>
                <div class="hero-buttons">
                    <a href="<?= e($slide['link']) ?>" class="hero-btn main"><?= $userLang === 'fa' ? 'مشاهده' : 'View' ?></a>
                </div>
                <?php endif; ?>
            </div>
            <div class="imdb-rating-badge" dir="ltr">
                <div class="imdb-logo" aria-label="IMDb" style="font-weight:950;letter-spacing:.02em;line-height:1;color:#f5c518">IMDb</div>
                <div class="rating-score"><?= enNumbers(number_format($slide['rating'] ?? 8.5, 1)) ?><small>/10</small><?php if (bm_site_bool('home_slider_show_imdb_votes', false)): ?><span class="rating-votes">(<?= enNumbers($slide['votes'] ?? '1.2M') ?>)</span><?php endif; ?></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <div class="hero-arrow hero-prev" id="heroPrev"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg></div>
    <div class="hero-arrow hero-next" id="heroNext"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg></div>

    <div class="hero-dots" id="heroDots">
        <?php foreach($sliderSlides as $index => $slide): ?>
        <button class="hero-dot <?= $index === 0 ? 'active' : '' ?>" data-dot="<?= $index ?>" aria-label="Go to slide <?= $index+1 ?>">
            <span class="dot-inner"></span>
        </button>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php
// Official Yektanet placement: exactly as issued, inline and non-sticky.
// It appears after the hero on both desktop and mobile.
$bmYkPrimaryHome = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('global_banner') : '';
$bmYkHomeTop = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_top', 'hero') : '';
?>
<?= $bmYkPrimaryHome !== '' ? $bmYkPrimaryHome : ($bmYkHomeTop !== '' ? $bmYkHomeTop : bm_render_ad_slot($pdo, 'home_top', 'hero', 1)) ?>

<?php if(count($stories)>0): ?>
<div class="stories-section"><div class="stories-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15 15 0 0 1 0 20 15 15 0 0 1 0-20z"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_stories_title_fa','استوری‌ها')) : $t[$userLang]['stories'] ?></div><div class="stories-container" id="storiesContainer"></div></div>
<?php endif; ?>

<!-- Quick search is available only from the shared header and mobile footer. -->


<div class="genres-section" id="genresSection"><div class="section-header"><div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M7 20l4-16m2 16l4-16M6 9h14M4 15h14"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_genres_title_fa','ژانرها')) : $t[$userLang]['genres'] ?></div></div><div class="genres-scroll" id="genresContainer"><?php foreach($genresList as $genreEn): $genreDisplay = isset($genrePersian[$genreEn]) ? $genrePersian[$genreEn] : $genreEn; ?><a href="/search?genre=<?= urlencode($genreEn) ?>" class="genre-chip"><?= e($genreDisplay) ?></a><?php endforeach; ?></div></div>

<div class="countries-section" id="countriesSection"><div class="section-header"><div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg><?= $userLang === 'fa' ? bm_site_h(bm_site_get('home_countries_title_fa','کشورهای محبوب')) : $t[$userLang]['popular_countries'] ?></div></div><div class="countries-scroll" id="countriesContainer"><?php foreach($allCountries as $country): ?><a href="/search?country=<?= urlencode($country) ?>" class="country-chip"><span style="font-size:18px"><?= getCountryFlag($country) ?></span><?= e($country) ?></a><?php endforeach; ?></div></div>

<?php $bmYkHomeMiddle = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_middle', 'wide') : ''; ?>
<?= $bmYkHomeMiddle !== '' ? $bmYkHomeMiddle : (function_exists('bm_render_ad_with_support_card') ? bm_render_ad_with_support_card($pdo, 'home_middle', 'wide', 1, 'index.php') : bm_render_ad_slot($pdo, 'home_middle', 'wide', 1)) ?>

<div class="arc-switch-wrap">
    <div class="arc-switch" id="arcSwitch">
        <div class="arc-pill" id="arcPill"></div>

        <?php if(bm_archive_should_render_tab('archive1')): ?>
        <?php $bmArc1Enabled = bm_archive_is_enabled('archive1'); ?>
        <button class="arc-tab <?= $bmArchiveDefaultMode==='arc1' ? 'arc-tab-active' : '' ?> <?= $bmArc1Enabled ? '' : 'arc-tab-disabled' ?>" data-arc="arc1" data-archive-id="archive1" id="arcTabExt" data-disabled-message="<?= e(bm_archive_disabled_message('archive1')) ?>">
            <span class="arc-icon-ext">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
            </span>
            <?= e(bm_archive_label('archive1', $userLang==='fa'?'آرشیو ۱':'Archive 1')) ?>
            <?php if($bmArc1Enabled): ?><span class="arc-new-badge">NEW</span><?php endif; ?>
        </button>
        <?php endif; ?>

        <?php if(bm_archive_should_render_tab('archive2')): ?>
        <?php $bmArc2Enabled = bm_archive_is_enabled('archive2'); ?>
        <button class="arc-tab <?= $bmArchiveDefaultMode==='local' ? 'arc-tab-active' : '' ?> <?= $bmArc2Enabled ? '' : 'arc-tab-disabled' ?>" data-arc="local" data-archive-id="archive2" id="arcTabLocal" data-disabled-message="<?= e(bm_archive_disabled_message('archive2')) ?>">
            <span class="arc-icon-local">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>
            </span>
            <?= e(bm_archive_label('archive2', $userLang==='fa'?'آرشیو ۲':'Archive 2')) ?>
        </button>
        <?php endif; ?>

        <?php if(bm_archive_should_render_tab('archive3')): ?>
        <?php $bmArc3Enabled = bm_archive_is_enabled('archive3'); ?>
        <button class="arc-tab <?= $bmArchiveDefaultMode==='arc3' ? 'arc-tab-active' : '' ?> <?= $bmArc3Enabled ? '' : 'arc-tab-disabled' ?>" data-arc="arc3" data-archive-id="archive3" id="arcTabArc3" data-disabled-message="<?= e(bm_archive_disabled_message('archive3')) ?>">
            <span class="arc-icon-ext">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/><circle cx="7" cy="7" r="1" fill="currentColor"/><circle cx="7" cy="12" r="1" fill="currentColor"/><circle cx="7" cy="17" r="1" fill="currentColor"/></svg>
            </span>
            <?= e(bm_archive_label('archive3', $userLang==='fa'?'آرشیو ۳':'Archive 3')) ?>
        </button>
        <?php endif; ?>

        <?php if(bm_archive_should_render_tab('archive4')): ?>
        <?php $bmArc4Enabled = bm_archive_is_enabled('archive4'); ?>
        <button class="arc-tab <?= $bmArchiveDefaultMode==='arc4' ? 'arc-tab-active' : '' ?> <?= $bmArc4Enabled ? '' : 'arc-tab-disabled' ?>" data-arc="arc4" data-archive-id="archive4" id="arcTabArc4" data-disabled-message="<?= e(bm_archive_disabled_message('archive4')) ?>">
            <span class="arc-icon-ext">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3 6 6 .9-4.5 4.4 1.1 6.3L12 16.8 6.4 19.6l1.1-6.3L3 8.9 9 8z"/></svg>
            </span>
            <?= e(bm_archive_label('archive4', $userLang==='fa'?'آرشیو ۴':'Archive 4')) ?>
        </button>
        <?php endif; ?>
    </div>
    <button type="button" class="archive-guide-btn" id="archiveGuideBtn">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><path d="M12 16h.01"/></svg>
        اگه استفاده از ارشیو هارو بلد نیسی بزن روم
    </button>
    <div class="arc-hint" id="arcHint"><?= $userLang==='fa'?'هر آرشیو محتوای متفاوتی دارد':'Each archive has different content' ?></div>
</div>

<?php $archiveGuideVideoUrl = trim((string)bm_site_get('home_archive_guide_video_url', '')); ?>
<div class="archive-guide-overlay" id="archiveGuideModal" aria-hidden="true">
    <div class="archive-guide-modal archive-guide-video-modal" role="dialog" aria-modal="true" aria-labelledby="archiveGuideTitle">
        <div class="archive-guide-video-top">
            <span class="archive-guide-sr-title" id="archiveGuideTitle">راهنمای ویدیویی آرشیوها</span>
            <button type="button" class="archive-guide-close" id="archiveGuideClose" aria-label="بستن">×</button>
        </div>
        <div class="archive-guide-video-shell">
            <?php if($archiveGuideVideoUrl !== ''): ?>
                <video class="archive-guide-video" controls playsinline preload="metadata" src="<?= e($archiveGuideVideoUrl) ?>"></video>
            <?php else: ?>
                <div class="archive-guide-video-empty">ویدیو راهنما هنوز از پنل تنظیم نشده است.</div>
            <?php endif; ?>
        </div>
        <div class="archive-guide-caption">اگه براتون سوال شده که این آرشیوها چی هستن یا موقع استفاده گیج شدین، حتماً این ویدیو رو ببینید تا همه‌چیز براتون روشن بشه.</div>
    </div>
</div>

<div class="ext-page" id="extPage" style="display:block;opacity:1">

    <!-- نتایج سرچ یکپارچه آرشیو ۱ -->
    <div id="extSearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="extSearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو
            </div>
            <button onclick="extClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="extSearchResultsList"></div>
    </div>

    <!-- سکشن‌های اسکرولی آرشیو ۱ -->
    <div id="extScrollSections">

        <!-- فیلم‌های آپدیت شده -->
        <div class="new-releases-section" id="extUpdatedMoviesSection">
            <div class="section-header">
                <div class="section-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9h-4m-5 9A9 9 0 0 1 3 12m9 9v-4M3 12a9 9 0 0 1 9-9m-9 9h4m7-9a9 9 0 0 1 9 9"/><circle cx="12" cy="12" r="3"/></svg>
                    فیلم‌های آپدیت شده
                    <span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">NEW</span>
                </div>
                <a href="/view_all?type=arc1_updates&kind=movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extUpdatedMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- سریال‌های آپدیت شده -->
        <div class="new-releases-section" id="extUpdatedSeriesSection">
            <div class="section-header">
                <div class="section-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M8 10l4 4 4-4"/></svg>
                    سریال‌های آپدیت شده
                    <span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">NEW</span>
                </div>
                <a href="/view_all?type=arc1_updates&kind=series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extUpdatedSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0): ?>
        <div class="collections-section">
            <div class="section-header">
                <div class="section-title">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="2" y1="16" x2="22" y2="16"/></svg>
                    <?= $t[$userLang]['special_collections'] ?>
                </div>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach($activeCollections as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card">
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" loading="lazy" decoding="async">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- برترین فیلم‌های 2026 -->
        <div class="new-releases-section" id="extTop2026Section">
            <div class="section-header">
                <div class="section-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3 7h7l-5.5 4.4 2.1 7L12 16l-6.6 4.4 2.1-7L2 9h7l3-7Z"/></svg>
                    برترین فیلم‌های 2026
                    <span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">2026</span>
                </div>
                <a href="/view_all?type=arc1_category&cat=top-2026" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extTop2026List"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- فیلم‌های دوبله فارسی -->
        <div class="new-releases-section" id="extDubbedFaSection">
            <div class="section-header">
                <div class="section-title">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a4 4 0 0 0-4 4v5a4 4 0 0 0 8 0V7a4 4 0 0 0-4-4Z"/><path d="M5 10v2a7 7 0 0 0 14 0v-2"/><path d="M12 19v3"/></svg>
                    فیلم‌های دوبله فارسی
                    <span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">DUB</span>
                </div>
                <a href="/view_all?type=arc1_category&cat=dubbed-fa" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extDubbedFaList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- سریال‌های ترکی -->
        <div class="new-releases-section" id="extTurkishSection">
            <div class="section-header">
                <div class="section-title">
                    <span class="section-icon-svg section-icon-turkey" aria-hidden="true"><svg viewBox="0 0 64 64" role="img"><circle class="turkey-bg" cx="32" cy="32" r="30"/><circle class="turkey-moon" cx="28" cy="32" r="13"/><circle class="turkey-bg" cx="33" cy="32" r="10"/><path class="turkey-star" d="M44.5 22.8l2.4 6.3 6.7.3-5.2 4.2 1.8 6.5-5.7-3.6-5.7 3.6 1.8-6.5-5.2-4.2 6.7-.3z"/></svg></span>
                    سریال‌های ترکی
                </div>
                <a href="/view_all?type=arc1_category&cat=turkish" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extTurkishList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- سریال‌های کره‌ای -->
        <div class="new-releases-section" id="extKoreanSection">
            <div class="section-header">
                <div class="section-title">
                    <span class="section-icon-svg section-icon-korea" aria-hidden="true"><svg viewBox="0 0 64 64" role="img"><circle class="kr-white" cx="32" cy="32" r="30"/><path class="kr-red" d="M32 20a12 12 0 0 1 0 24 6 6 0 0 1 0-12 6 6 0 0 0 0-12z"/><path class="kr-blue" d="M32 44a12 12 0 0 1 0-24 6 6 0 0 1 0 12 6 6 0 0 0 0 12z"/><g class="kr-lines"><path class="kr-line" d="M17 15l7 7M20 12l7 7M12 20l7 7"/><path class="kr-line" d="M47 15l-7 7M44 12l-7 7M52 20l-7 7"/><path class="kr-line" d="M17 49l7-7M20 52l7-7M12 44l7-7"/><path class="kr-line" d="M47 49l-7-7M44 52l-7-7M52 44l-7-7"/></g></svg></span>
                    سریال‌های کره‌ای
                </div>
                <a href="/view_all?type=arc1_category&cat=korean" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extKoreanList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- انیمه -->
        <div class="new-releases-section" id="extAnimeSection">
            <div class="section-header">
                <div class="section-title">
                    <span class="section-icon-svg section-icon-anime" aria-hidden="true"><svg viewBox="0 0 24 24" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 10.5C6.2 6.8 8.6 4.5 12 4.5s5.8 2.3 6.5 6"/><path d="M4.5 11.5c.2 5.1 3.2 8 7.5 8s7.3-2.9 7.5-8"/><path d="M8.2 13.2h.01M15.8 13.2h.01"/><path d="M9.2 16.2c1.7 1.2 3.9 1.2 5.6 0"/><path d="M7.3 8.5c1.2-1 2.6-1.5 4.7-1.5s3.5.5 4.7 1.5"/><path d="M3.5 12.5l-1.5-1M20.5 12.5l1.5-1"/></svg></span>
                    انیمه
                </div>
                <a href="/view_all?type=arc1_category&cat=anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="extAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>




    </div><!-- /extScrollSections -->

</div>

<div class="ext-page" id="arc3Page" style="display:none;opacity:0">
    <div id="arc3SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc3SearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو — آرشیو ۳
            </div>
            <button onclick="arc3ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc3SearchResultsList"></div>
    </div>

    <div id="arc3ScrollSections">
        <div class="bm-archive-speed-note" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span>در حال دریافت تازه‌ترین محتوای آرشیو ۳...</span></div>
        <div class="new-releases-section" id="arc3NewSeriesSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M8 10l4 4 4-4"/></svg>سریال‌های جدید</div>
                <a href="/view_all?type=arc3_section&kind=new_series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3NewSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc3NewMoviesSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/></svg>فیلم‌های جدید<span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">NEW</span></div>
                <a href="/view_all?type=arc3_section&kind=new_movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3NewMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc3UpdatedAnimationsSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>انیمیشن‌های به‌روز شده</div>
                <a href="/view_all?type=arc3_section&kind=updated_animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3UpdatedAnimationsList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc3UpdatedAnimeSection">
            <div class="section-header">
                <div class="section-title"><span class="section-icon-svg section-icon-anime" aria-hidden="true"><svg viewBox="0 0 24 24" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 10.5C6.2 6.8 8.6 4.5 12 4.5s5.8 2.3 6.5 6"/><path d="M4.5 11.5c.2 5.1 3.2 8 7.5 8s7.3-2.9 7.5-8"/><path d="M8.2 13.2h.01M15.8 13.2h.01"/><path d="M9.2 16.2c1.7 1.2 3.9 1.2 5.6 0"/><path d="M7.3 8.5c1.2-1 2.6-1.5 4.7-1.5s3.5.5 4.7 1.5"/><path d="M3.5 12.5l-1.5-1M20.5 12.5l1.5-1"/></svg></span>انیمه‌های به‌روز شده</div>
                <a href="/view_all?type=arc3_section&kind=updated_anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc3UpdatedAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0): ?>
        <div class="collections-section">
            <div class="section-header">
                <div class="section-title">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="2" y1="16" x2="22" y2="16"/></svg>
                    <?= $t[$userLang]['special_collections'] ?>
                </div>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach($activeCollections as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card">
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" loading="lazy" decoding="async">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>


<?php if (bm_archive_user_can_access('archive4', $currentUser ?? null)): ?>
<div class="ext-page" id="arc4Page" style="display:none;opacity:0">
    <div id="arc4SearchResultsWrap" style="display:none;padding:0 16px 8px">
        <div class="section-header">
            <div class="section-title" id="arc4SearchResultTitle">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
                نتایج جستجو — آرشیو ۴
            </div>
            <button onclick="arc4ClearSearch()" class="view-all-btn" style="color:#f87">× بستن</button>
        </div>
        <div id="arc4SearchResultsList"></div>
    </div>

    <div id="arc4ScrollSections">
        <div class="bm-archive-speed-note" role="status" aria-live="polite"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg><span>در حال دریافت تازه‌ترین محتوای آرشیو ۴...</span></div>
        <div class="new-releases-section" id="arc4NewSeriesSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M8 10l4 4 4-4"/></svg>سریال‌های جدید</div>
                <a href="/view_all?type=arc4_section&kind=new_series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4NewSeriesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc4NewMoviesSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/></svg>فیلم‌های جدید<span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">NEW</span></div>
                <a href="/view_all?type=arc4_section&kind=new_movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4NewMoviesList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc4UpdatedAnimationsSection">
            <div class="section-header">
                <div class="section-title"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>انیمیشن‌های به‌روز شده</div>
                <a href="/view_all?type=arc4_section&kind=updated_animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4UpdatedAnimationsList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <div class="new-releases-section" id="arc4UpdatedAnimeSection">
            <div class="section-header">
                <div class="section-title"><span class="section-icon-svg section-icon-anime" aria-hidden="true"><svg viewBox="0 0 24 24" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 10.5C6.2 6.8 8.6 4.5 12 4.5s5.8 2.3 6.5 6"/><path d="M4.5 11.5c.2 5.1 3.2 8 7.5 8s7.3-2.9 7.5-8"/><path d="M8.2 13.2h.01M15.8 13.2h.01"/><path d="M9.2 16.2c1.7 1.2 3.9 1.2 5.6 0"/><path d="M7.3 8.5c1.2-1 2.6-1.5 4.7-1.5s3.5.5 4.7 1.5"/><path d="M3.5 12.5l-1.5-1M20.5 12.5l1.5-1"/></svg></span>انیمه‌های به‌روز شده</div>
                <a href="/view_all?type=arc4_section&kind=updated_anime" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal" id="arc4UpdatedAnimeList"><div class="ext-loading-skeletons" aria-hidden="true">
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
    <div class="ext-skeleton-card"><div class="ext-skeleton-poster"></div><div class="ext-skeleton-info"><span></span><small></small></div></div>
</div></div>
        </div>

        <!-- کالکشن‌ها -->
        <?php if(count($activeCollections)>0): ?>
        <div class="collections-section">
            <div class="section-header">
                <div class="section-title">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="2" y1="16" x2="22" y2="16"/></svg>
                    <?= $t[$userLang]['special_collections'] ?>
                </div>
                <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            </div>
            <div class="scroll-horizontal">
                <?php foreach($activeCollections as $col): ?>
                <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card">
                    <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                    <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" loading="lazy" decoding="async">
                    <?php else: ?>
                    <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                    <?php endif; ?>
                    <div class="scroll-card-info" style="text-align:center">
                        <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                        <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                    </div>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>


<?php endif; ?>


<div class="page active" id="homePage" style="display:none">

    <!-- 1) فیلم‌های جدید -->
    <?php if(count($newMovies)>0): ?>
    <div class="new-releases-section" id="localNewMoviesSection">
        <div class="section-header">
            <div class="section-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/></svg>
                فیلم‌های جدید
                <span style="font-size:10px;background:var(--accent);color:#000;padding:2px 8px;border-radius:20px;margin-right:6px">NEW</span>
            </div>
            <a href="/view_all?type=new-movies" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="newMoviesList"></div>
    </div>
    <?php endif; ?>

    <!-- 2) سریال‌های آپدیت -->
    <?php if(count($updatedSeries)>0): ?>
    <div class="new-releases-section" id="localUpdatedSeriesSection">
        <div class="section-header">
            <div class="section-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M8 10l4 4 4-4"/></svg>
                سریال‌های آپدیت
            </div>
            <a href="/view_all?type=updated-series" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="updatedSeriesList"></div>
    </div>
    <?php endif; ?>

    <!-- 3) کالکشن -->
    <?php if(count($activeCollections)>0): ?>
    <div class="collections-section" id="localCollectionsSection">
        <div class="section-header">
            <div class="section-title">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="2" width="20" height="20" rx="2.18"/><line x1="8" y1="2" x2="8" y2="22"/><line x1="16" y1="2" x2="16" y2="22"/><line x1="2" y1="8" x2="22" y2="8"/><line x1="2" y1="16" x2="22" y2="16"/></svg>
                کالکشن
            </div>
            <?php if (bm_site_bool('collection_show_view_all_links', true)): ?>
            <a href="/collections" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            <?php endif; ?>
        </div>
        <div class="scroll-horizontal">
            <?php foreach($activeCollections as $col): ?>
            <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="scroll-card">
                <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                <img class="scroll-card-poster" src="<?= e(bm_public_asset_url($col['cover_image'])) ?>" loading="lazy" decoding="async">
                <?php else: ?>
                <div class="scroll-card-poster" style="background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#888"><rect x="2" y="2" width="20" height="20" rx="2.18"/></svg></div>
                <?php endif; ?>
                <div class="scroll-card-info" style="text-align:center">
                    <div class="scroll-card-title-fa" style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis"><?= e($col['title_fa']?:$col['title']) ?></div>
                    <div class="scroll-card-meta" style="font-size:10px;color:#888"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg> <?= enNumbers($col['movie_count']) ?> <?= $t[$userLang]['movies_in_collection'] ?></div>
                </div>
            </a>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- 4) انیمیشن -->
    <?php if(count($latestAnimations)>0): ?>
    <div class="new-releases-section" id="localAnimationsSection">
        <div class="section-header">
            <div class="section-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
                انیمیشن
            </div>
            <a href="/view_all?type=animations" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="latestAnimationsList"></div>
    </div>
    <?php endif; ?>

    <!-- 5) دوبله -->
    <?php if(count($dubbedMovies)>0): ?>
    <div class="dubbed-section" id="localDubbedSection">
        <div class="section-header">
            <div class="section-title">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 5h18M3 12h18M3 19h18"/></svg>
                دوبله
            </div>
            <a href="/view_all?type=dubbed" class="view-all-btn"><?= $t[$userLang]['view_all'] ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
        </div>
        <div class="scroll-horizontal" id="dubbedList"></div>
    </div>
    <?php endif; ?>

</div>

<?php bm_weekly_schedule_render($pdo, $userLang); ?>

<?= function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('home_bottom', 'wide') : '' ?>

<?php $bmYkMobile = function_exists('bm_yektanet_render_slot') ? bm_yektanet_render_slot('mobile', 'floating') : ''; ?>
<?= $bmYkMobile !== '' ? $bmYkMobile : bm_render_ad_slot($pdo, 'mobile', 'floating', 1) ?>

<div class="bottom-nav" data-mobile-bottom-nav aria-label="Mobile bottom navigation">
    <a href="/" class="nav-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span class="nav-label"><?= $t[$userLang]['home'] ?></span></a>
    <a href="/search" class="nav-item bm-footer-search-trigger" aria-haspopup="dialog" aria-controls="bmQuickSearchModal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span class="nav-label"><?= (($userLang ?? $currentLanguage ?? 'fa') === 'en') ? 'Search' : 'جستجو' ?></span></a>
    <a href="/player" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span class="nav-label"><?= $t[$userLang]['player'] ?></span></a>
    <a href="<?= $currentUser ? '/profile' : '/login' ?>" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span class="nav-label"><?= $currentUser ? $t[$userLang]['profile'] : $t[$userLang]['login'] ?></span></a>
</div>

<div class="story-modal" id="storyModal">
    <div class="story-progress-container" id="storyProgressContainer"></div>
    <button class="story-close" id="storyCloseBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    <button class="story-nav prev" id="storyPrevBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg></button>
    <button class="story-nav next" id="storyNextBtn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg></button>
    <div class="story-content" id="storyContent"></div>
</div>

<div class="modal" id="donateModal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.85);backdrop-filter:blur(12px);align-items:center;justify-content:center;z-index:10002"><div style="background:#121215;border-radius:28px;max-width:400px;width:90%;padding:24px;text-align:center"><div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 20px;display:flex;align-items:center;justify-content:center"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div><div style="font-size:24px;font-weight:800;margin-bottom:16px"><?= $t[$userLang]['support_us'] ?></div><p style="color:var(--text-secondary);margin-bottom:24px;font-size:13px"><?= $t[$userLang]['support_text'] ?></p><button class="donate-btn" id="openDonateLink" style="width:100%;justify-content:center"><?= $t[$userLang]['donate'] ?></button><button id="closeDonateModal" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer"><?= $t[$userLang]['close'] ?></button></div></div>

<script>
window.BM_HOME_CONFIG = {
  storiesData: <?= js_json($stories) ?>,
  newMoviesData: <?= js_json($newMovies) ?>,
  updatedSeriesData: <?= js_json($updatedSeries) ?>,
  latestAnimationsData: <?= js_json($latestAnimations) ?>,
  dubbedMoviesData: <?= js_json($dubbedMovies) ?>,
  userLang: <?= js_json($userLang) ?>,
  userId: <?= js_json($currentUser['id'] ?? '') ?>,
  storyFallback: <?= js_json(bm_public_asset_url((string)bm_site_get('home_story_fallback_path', ''), '')) ?>,
  storyImageFit: <?= js_json(in_array((string)bm_site_get('home_story_image_fit', 'cover'), ['cover','contain'], true) ? (string)bm_site_get('home_story_image_fit', 'cover') : 'cover') ?>,
  archiveControl: <?= json_encode($bmArchivePublicConfig, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,
  arcHints: {
    local: <?= js_json($userLang==='fa' ? 'آرشیو ۲ — دیتابیس اصلی سایت، سافت‌ساب، دوبله و همیشه در دسترس' : 'Archive 2 — Main local database') ?>,
    ext: <?= js_json($userLang==='fa' ? 'آرشیو ۱ — هاردساب + دوبله، آپدیت سریع و دائمی' : 'Archive 1 — Hardsub + dubbed, fast updates') ?>,
    arc1: <?= js_json($userLang==='fa' ? 'آرشیو ۱ — هاردساب + دوبله، آپدیت سریع و دائمی' : 'Archive 1 — Hardsub + dubbed, fast updates') ?>,
    arc3: <?= js_json($userLang==='fa' ? 'آرشیو ۳ — فیلم، سریال و انیمه به‌روز' : 'Archive 3 — Always updated') ?>,
    arc4: <?= js_json($userLang==='fa' ? 'آرشیو ۴ — ساختار کامل مشابه آرشیو ۳' : 'Archive 4 — same flow as Archive 3') ?>
  },
  activeArchive: <?= json_encode($bmArchiveDefaultMode, JSON_UNESCAPED_UNICODE) ?>
};
</script>
<script src="/assets/js/bm-home-api-cache.js?v=cache71"></script>
<script src="/assets/js/index-main-v96.js?v=v96-db-five-sections"></script>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/index-inline-3.js?v=split36"></script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143-v47-static-scroll" defer></script>
</body>
</html>
