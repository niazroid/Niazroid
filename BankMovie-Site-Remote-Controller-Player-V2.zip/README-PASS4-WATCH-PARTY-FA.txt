Bankmovie Pass 4 — Android ↔ Site Watch Party Bridge
=====================================================

این پچ را روی روت همان سایت Bankmovie Merge کنید.

فایل اصلی تغییرکرده:
- app_user_api.php : اکشن‌های Native Watch Party برای اپ اندروید

پوشه includes:
- فایل‌های Watch Party / Voice / VIP / Sticker از همان سورس سایتی که برای این Pass مبنا قرار گرفت.
- اگر سایت شما همین فایل‌ها را دارد، Merge کردن این نسخه‌ها باعث می‌شود Bridge و اپ با همان revision تست شوند.

قابلیت‌های Bridge:
- watch_party_status
- watch_party_create
- watch_party_join
- watch_party_poll
- watch_party_control
- watch_party_room_settings
- watch_party_message
- watch_party_voice_start
- watch_party_voice_action
- watch_party_voice_signal
- watch_party_leave
- watch_party_close

اتاق، اعضا، state، sequence، chat، sticker/GIF و voice signaling همان جداول/توابع سایت را استفاده می‌کنند.

قبل از جایگزینی در سرور اصلی از فایل‌ها backup بگیرید.
