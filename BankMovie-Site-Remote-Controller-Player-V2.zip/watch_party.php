<?php
/**
 * Public Watch Party route.
 * The implementation remains in watch_party_lab.php for backward compatibility
 * with older invite links and deployed bookmarks.
 */
require __DIR__ . '/watch_party_lab.php';
