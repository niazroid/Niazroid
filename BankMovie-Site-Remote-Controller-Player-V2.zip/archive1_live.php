<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/archive1_live_lib.php';

header('Content-Type: application/json; charset=utf-8');
bm_security_enforce_rate_limit('archive1_live_public', 360, 300, bm_security_client_ip(), true);
bm_security_cors(['GET','OPTIONS'], ['Content-Type'], true);
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
$bmArc1LiveScope = function_exists('bm_archive_access_scope') ? bm_archive_access_scope('archive1') : 'public';
$bmArc1LivePublicPolicy = $bmArc1LiveScope === 'public'
    && bm_archive_feature_scope('archive1', 'download') === 'public'
    && bm_archive_feature_scope('archive1', 'stream') === 'public';
if ($bmArc1LivePublicPolicy) {
    header('Cache-Control: public, max-age=120');
} else {
    header('Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0');
    header('Pragma: no-cache');
    header('Vary: Cookie');
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if (!function_exists('bm_archive_user_can_access') || !bm_archive_user_can_access('archive1', $currentUser ?? null)) {
    http_response_code(404);
    echo json_encode(['status'=>'error','error'=>'not_found'], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    exit;
}

function bma1_json($payload, $code = 200) {
    http_response_code($code);
    $context = ['identifier'=>(string)($_GET['url'] ?? ($_GET['id'] ?? ''))];
    if (function_exists('bm_archive_apply_payload_policy')) $payload = bm_archive_apply_payload_policy('archive1', $payload, $GLOBALS['currentUser'] ?? null, $context);
    if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive1');
    if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

try {
    if (isset($_GET['ping'])) {
        bma1_json([
            'status' => 'success',
            'api' => 'archive1_live',
            'source' => 'oldtowns',
            'version' => '1.2.0-v21-advanced-search'
        ]);
    }

    if (!bm_archive_is_enabled('archive1')) {
        bma1_json(['status'=>'disabled','movies'=>[],'downloads'=>[],'message'=>bm_archive_disabled_message('archive1')], 503);
    }

    if (isset($_GET['advanced'])) {
        $page = max(1, (int)($_GET['page'] ?? $_GET['paged'] ?? 1));
        $limit = max(1, min(100, (int)($_GET['limit'] ?? 40)));
        $params = [
            's' => trim((string)($_GET['s'] ?? '')),
            'type' => trim((string)($_GET['type'] ?? 'both')),
            'genre_id' => trim((string)($_GET['genre_id'] ?? $_GET['genre'] ?? '')),
            'sortby' => trim((string)($_GET['sortby'] ?? $_GET['sort'] ?? 'newest')),
            'rating' => trim((string)($_GET['rating'] ?? $_GET['imdbrate'] ?? '0')),
            'country_id' => trim((string)($_GET['country_id'] ?? $_GET['madeby'] ?? '')),
            'dubbed' => !empty($_GET['dubbed']) || !empty($_GET['dubbled']),
            'subtitle' => !empty($_GET['subtitle']),
            'year_from' => trim((string)($_GET['year_from'] ?? $_GET['min_year'] ?? '')),
            'year_to' => trim((string)($_GET['year_to'] ?? $_GET['max_year'] ?? '')),
        ];

        $url = bma1_advanced_url($params, $page);
        $cacheKey = hash('sha256', 'advanced|' . $url . '|' . $limit);
        $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_a1_' . $cacheKey . '.json';

        if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 180) {
            $cached = @file_get_contents($cacheFile);
            if (is_string($cached) && $cached !== '') {
                $cachedPayload = json_decode($cached, true);
                if (is_array($cachedPayload)) {
                    header('X-Bankmovie-Cache: HIT');
                    bma1_json($cachedPayload);
                }
            }
        }

        $html = bma1_fetch_html($url);
        $result = bma1_parse_listing_html($html, $url, 'advanced', $page, $limit);
        $result['search_mode'] = 'advanced';
        $result['filters'] = $params;
        $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (is_string($encoded)) @file_put_contents($cacheFile, $encoded, LOCK_EX);
        header('X-Bankmovie-Cache: MISS');
        bma1_json($result);
    }

    $section = trim((string)($_GET['section'] ?? 'dubbed'));
    if (!in_array($section, ['dubbed', 'chinese_series'], true)) {
        bma1_json(['status' => 'error', 'error' => 'unsupported_section'], 400);
    }
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = max(1, min(60, (int)($_GET['limit'] ?? 24)));
    $url = bma1_section_url($section, $page);

    $cacheKey = hash('sha256', $url . '|' . $limit);
    $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_a1_' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 180) {
        $cached = @file_get_contents($cacheFile);
        if (is_string($cached) && $cached !== '') {
            $cachedPayload = json_decode($cached, true);
            if (is_array($cachedPayload)) {
                header('X-Bankmovie-Cache: HIT');
                bma1_json($cachedPayload);
            }
        }
    }

    $html = bma1_fetch_html($url);
    $result = bma1_parse_listing_html($html, $url, $section, $page, $limit);
    $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (is_string($encoded)) @file_put_contents($cacheFile, $encoded, LOCK_EX);
    header('X-Bankmovie-Cache: MISS');
    bma1_json($result);
} catch (Throwable $e) {
    bma1_json([
        'status' => 'error',
        'source' => 'archive1_live',
        'error' => 'temporary_upstream_error',
        'message' => bm_security_generic_error($e, 'خطای موقت آرشیو')
    ], 502);
}
