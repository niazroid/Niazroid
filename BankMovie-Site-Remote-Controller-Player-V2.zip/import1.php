<?php
declare(strict_types=1);

/**
 * Legacy output.json importer — secured and made admin-only.
 * Nothing is imported on GET. The administrator must submit the CSRF-protected form.
 */
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
$panelHealth = admin_panel_bootstrap($pdo);
$csrfToken = admin_csrf_token();
admin_enforce_csrf();

@set_time_limit(0);
@ini_set('memory_limit', '1024M');

function bm_import1_e($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function bm_import1_insert_links(PDO $pdo, string $table, int $movieId, array $links): int {
    if (!$links || !admin_panel_table_exists($pdo, $table)) return 0;

    $columns = ['movie_id', 'quality', 'url'];
    foreach (['size', 'season', 'is_folder'] as $column) {
        if (admin_panel_column_exists($pdo, $table, $column)) $columns[] = $column;
    }
    $quoted = implode(',', array_map(static fn($c) => '`' . $c . '`', $columns));
    $placeholders = implode(',', array_fill(0, count($columns), '?'));
    $stmt = $pdo->prepare("INSERT INTO `{$table}` ({$quoted}) VALUES ({$placeholders})");

    $count = 0;
    foreach ($links as $link) {
        if (!is_array($link)) continue;
        $url = trim((string)($link['url'] ?? ''));
        if ($url === '') continue;
        $quality = trim((string)($link['quality'] ?? 'HD')) ?: 'HD';
        $season = null;
        if (preg_match('/S(\d{1,2})/i', $quality, $match)) $season = (int)$match[1];
        elseif (preg_match('/season\s*(\d+)/i', $quality, $match)) $season = (int)$match[1];

        $values = [];
        foreach ($columns as $column) {
            $values[] = match ($column) {
                'movie_id' => $movieId,
                'quality' => $quality,
                'url' => $url,
                'size' => trim((string)($link['size'] ?? '')),
                'season' => $season,
                'is_folder' => !empty($link['is_folder']) ? 1 : 0,
                default => null,
            };
        }
        $stmt->execute($values);
        $count++;
    }
    return $count;
}

$jsonPath = __DIR__ . '/output.json';
$result = null;
$error = '';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST' && isset($_POST['run_import'])) {
    try {
        if (!is_file($jsonPath) || !is_readable($jsonPath)) throw new RuntimeException('فایل output.json در ریشه سایت پیدا نشد یا قابل خواندن نیست.');
        $raw = file_get_contents($jsonPath);
        if ($raw === false) throw new RuntimeException('خواندن output.json انجام نشد.');
        $items = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
        if (!is_array($items)) throw new RuntimeException('ساختار JSON باید یک آرایه باشد.');

        $movieColumns = [];
        foreach (['imdb_code','type','title','title_fa','year','imdb_rate','imdb_votes','description','genres','country','director','writer','actors','created_at','updated_at'] as $column) {
            if (admin_panel_column_exists($pdo, 'movies', $column)) $movieColumns[] = $column;
        }
        foreach (['imdb_code','type','title'] as $required) {
            if (!in_array($required, $movieColumns, true)) throw new RuntimeException("ستون ضروری movies.{$required} وجود ندارد.");
        }

        $insertColumns = implode(',', array_map(static fn($c) => '`' . $c . '`', $movieColumns));
        $insertValues = [];
        foreach ($movieColumns as $column) $insertValues[] = in_array($column, ['created_at','updated_at'], true) ? 'NOW()' : '?';
        $insertMovie = $pdo->prepare('INSERT INTO movies (' . $insertColumns . ') VALUES (' . implode(',', $insertValues) . ')');

        $existingCodes = $pdo->query("SELECT imdb_code FROM movies WHERE imdb_code IS NOT NULL AND imdb_code <> ''")->fetchAll(PDO::FETCH_COLUMN) ?: [];
        $existing = array_fill_keys(array_map('strval', $existingCodes), true);
        $added = $skipped = $failed = $softLinks = $dubbedLinks = 0;
        $errors = [];

        $pdo->beginTransaction();
        foreach ($items as $index => $item) {
            if (!is_array($item)) { $failed++; continue; }
            $imdbCode = trim((string)($item['imdb_code'] ?? ''));
            $title = trim((string)($item['title'] ?? ''));
            if ($imdbCode === '' || $title === '') { $failed++; $errors[] = 'ردیف ' . ($index + 1) . ': IMDb یا عنوان خالی است.'; continue; }
            if (isset($existing[$imdbCode])) { $skipped++; continue; }

            $savepoint = 'bm_item_' . (int)$index;
            $pdo->exec("SAVEPOINT {$savepoint}");
            try {
                $values = [];
                foreach ($movieColumns as $column) {
                    if (in_array($column, ['created_at','updated_at'], true)) continue;
                    $values[] = match ($column) {
                        'imdb_code' => $imdbCode,
                        'type' => trim((string)($item['type'] ?? 'movie')) ?: 'movie',
                        'title' => $title,
                        'title_fa' => trim((string)($item['title_fa'] ?? '')),
                        'year' => isset($item['year']) && is_numeric($item['year']) ? (int)$item['year'] : null,
                        'imdb_rate' => isset($item['imdb_rate']) && is_numeric($item['imdb_rate']) ? (float)$item['imdb_rate'] : null,
                        'imdb_votes' => trim((string)($item['imdb_votes'] ?? '')),
                        'description' => trim((string)($item['description'] ?? '')),
                        'genres' => trim((string)($item['genres'] ?? '')),
                        'country' => trim((string)($item['country'] ?? '')),
                        'director' => trim((string)($item['director'] ?? '')),
                        'writer' => trim((string)($item['writer'] ?? '')),
                        'actors' => trim((string)($item['actors'] ?? '')),
                        default => $item[$column] ?? null,
                    };
                }
                $insertMovie->execute($values);
                $movieId = (int)$pdo->lastInsertId();
                $softLinks += bm_import1_insert_links($pdo, 'softsub_links', $movieId, is_array($item['softsub_links'] ?? null) ? $item['softsub_links'] : []);
                $dubbedLinks += bm_import1_insert_links($pdo, 'dubbed_links', $movieId, is_array($item['dubbed_links'] ?? null) ? $item['dubbed_links'] : []);
                $existing[$imdbCode] = true;
                $added++;
                $pdo->exec("RELEASE SAVEPOINT {$savepoint}");
            } catch (Throwable $itemError) {
                $pdo->exec("ROLLBACK TO SAVEPOINT {$savepoint}");
                $failed++;
                if (count($errors) < 20) $errors[] = $imdbCode . ': ' . $itemError->getMessage();
            }
        }
        $pdo->commit();
        $result = compact('added','skipped','failed','softLinks','dubbedLinks','errors');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e->getMessage();
    }
}

$fileInfo = is_file($jsonPath) ? number_format((int)filesize($jsonPath)) . ' bytes' : 'پیدا نشد';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>ورود امن output.json | BankMovie</title>
<style>
body{margin:0;background:#080b10;color:#f5f7fb;font-family:Tahoma,Arial,sans-serif}.wrap{width:min(900px,calc(100% - 28px));margin:30px auto}.card{background:#121823;border:1px solid #273248;border-radius:22px;padding:22px;margin-bottom:16px}.muted{color:#9ca8b8;line-height:1.9}.ok{color:#5dffad}.bad{color:#ff788e}.btn{border:0;border-radius:12px;padding:12px 18px;font-weight:700;cursor:pointer;background:#44f0a0;color:#03110a;text-decoration:none;display:inline-block}.secondary{background:#202a3a;color:#fff;margin-right:8px}code{direction:ltr;display:inline-block}ul{line-height:2}
</style>
</head><body><div class="wrap">
<div class="card"><h1>ورود امن فایل output.json</h1><p class="muted">این ابزار دیگر با بازکردن صفحه چیزی را وارد نمی‌کند. فقط پس از ثبت فرم امن اجرا می‌شود. فایل: <code><?= bm_import1_e($fileInfo) ?></code></p><a class="btn secondary" href="admin.php">بازگشت به پنل</a></div>
<?php if($panelHealth['errors']): ?><div class="card bad"><strong>خطای آماده‌سازی پنل:</strong><ul><?php foreach($panelHealth['errors'] as $item): ?><li><?= bm_import1_e($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if($error !== ''): ?><div class="card bad"><strong><?= bm_import1_e($error) ?></strong></div><?php endif; ?>
<?php if(is_array($result)): ?><div class="card ok"><h2>نتیجه ورود</h2><p>فیلم جدید: <?= (int)$result['added'] ?> | تکراری: <?= (int)$result['skipped'] ?> | خطا: <?= (int)$result['failed'] ?> | لینک سافت‌ساب: <?= (int)$result['softLinks'] ?> | لینک دوبله: <?= (int)$result['dubbedLinks'] ?></p><?php if($result['errors']): ?><ul class="bad"><?php foreach($result['errors'] as $item): ?><li><?= bm_import1_e($item) ?></li><?php endforeach; ?></ul><?php endif; ?></div><?php endif; ?>
<div class="card"><form method="post" onsubmit="return confirm('ورود اطلاعات output.json شروع شود؟ رکوردهای IMDb تکراری رد می‌شوند.');"><?= admin_csrf_input() ?><button class="btn" type="submit" name="run_import" value="1" <?= is_file($jsonPath)?'':'disabled' ?>>شروع ورود امن</button></form></div>
</div></body></html>
