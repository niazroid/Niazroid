<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// /profile - optimized: requests and recent history UI removed
ob_start();
require_once 'config.php';
require_once __DIR__ . '/includes/user_avatar.php';
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('page_profile_enabled');

if(!$currentUser) {
    header('Location: /login');
    exit;
}

$userId = $currentUser['id'];
$message = '';
$messageType = '';


// Helperهای پروفایل برای نشانه‌های آرشیو ۱
if (!function_exists('bm_profile_ensure_archive1_watchlist')) {
    function bm_profile_ensure_archive1_watchlist(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            item_link VARCHAR(500) NOT NULL,
            item_title VARCHAR(300) NOT NULL DEFAULT '',
            item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
            item_year VARCHAR(10) DEFAULT NULL,
            item_poster VARCHAR(500) DEFAULT NULL,
            item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
            item_type VARCHAR(20) DEFAULT 'movie',
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_user_link (user_id, item_link(200)),
            KEY idx_user (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    }
}

if (!function_exists('bm_profile_arc1_url')) {
    function bm_profile_arc1_url(array $item): string {
        $link = trim((string)($item['item_link'] ?? ''));
        if ($link === '') return '#';
        if (preg_match('~^/movie/arc1-[A-Za-z0-9._-]+/?$~', $link)) return $link;
        $path = parse_url($link, PHP_URL_PATH);
        if (is_string($path) && preg_match('~/([^/]+)/?$~', rtrim($path, '/'), $m)) {
            $slug = trim($m[1]);
            if ($slug !== '') return '/movie/arc1-' . rawurlencode($slug);
        }
        return $link;
    }
}

if (!function_exists('bm_profile_safe_avatar_path')) {
    function bm_profile_safe_avatar_path(?string $path): bool {
        $path = str_replace('\\', '/', (string)$path);
        return $path !== '' && !str_contains($path, '..') && !str_starts_with($path, '/') && str_starts_with($path, 'uploads/avatars/');
    }
}


try { bm_vip_ensure_history_columns($pdo); } catch (Throwable $e) { error_log('Profile VIP history setup error: '.$e->getMessage()); }
$appearanceColumnsReady = function_exists('bm_user_appearance_ensure') ? bm_user_appearance_ensure($pdo) : false;
$appearanceSelect = $appearanceColumnsReady ? ', background_key, avatar_frame' : '';
try {
    $stmt = $pdo->prepare("SELECT theme, language, avatar, username, email, full_name, role, vip_expires_at, vip_last_expires_at{$appearanceSelect} FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$userId]);
    $userSettings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    $stmt = $pdo->prepare("SELECT theme, language, avatar, username, email, full_name, role, vip_expires_at{$appearanceSelect} FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$userId]);
    $userSettings = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];
}
if ($userSettings) $currentUser = array_merge($currentUser, $userSettings);

$themeAccessAllowed = bm_vip_benefit_allowed('custom_theme', $currentUser);
$currentTheme = $themeAccessAllowed ? (string)($currentUser['theme'] ?? 'dark-green') : 'dark-green';
if (!bm_theme_is_valid($currentTheme)) $currentTheme = 'dark-green';
if (!$themeAccessAllowed) $currentUser['theme'] = 'dark-green';
$currentLanguage = in_array((string)($currentUser['language'] ?? 'fa'), ['fa','en'], true) ? (string)$currentUser['language'] : 'fa';
$fontAccessAllowed = bm_vip_benefit_allowed('custom_font', $currentUser);
$appearanceAccessAllowed = function_exists('bm_user_appearance_can_customize') ? bm_user_appearance_can_customize($currentUser) : bm_vip_user_is_active($currentUser);
$fontCatalog = function_exists('bm_user_font_catalog') ? bm_user_font_catalog() : (function_exists('bm_site_font_catalog') ? bm_site_font_catalog() : []);
$defaultFontId = function_exists('bm_user_font_default_id') ? bm_user_font_default_id() : 'bonvf';
$currentFont = $fontAccessAllowed && function_exists('bm_user_font_resolve') ? bm_user_font_resolve($currentUser) : $defaultFontId;
if (!isset($fontCatalog[$currentFont])) $currentFont = $defaultFontId;
$backgroundCatalog = function_exists('bm_user_background_catalog') ? bm_user_background_catalog() : ['simple'=>['name'=>'ساده','name_en'=>'Simple']];
$avatarFrameCatalog = function_exists('bm_user_avatar_frame_catalog') ? bm_user_avatar_frame_catalog() : ['none'=>['name'=>'بدون افکت','name_en'=>'No Effect']];
$currentBackground = function_exists('bm_user_background_resolve') ? bm_user_background_resolve($currentUser) : 'simple';
$currentAvatarFrame = function_exists('bm_user_avatar_frame_resolve') ? bm_user_avatar_frame_resolve($currentUser) : 'none';
if (!isset($backgroundCatalog[$currentBackground])) $currentBackground = 'simple';
if (!isset($avatarFrameCatalog[$currentAvatarFrame])) $currentAvatarFrame = 'none';
$vipLastExpiryRaw = trim((string)($currentUser['vip_last_expires_at'] ?? ''));
$vipLastExpiryTs = $vipLastExpiryRaw !== '' ? strtotime($vipLastExpiryRaw) : false;
$vipNeedsRenewal = !bm_vip_user_is_active($currentUser) && $vipLastExpiryTs !== false && $vipLastExpiryTs <= time();
$profileAvatarValue = $currentUser['avatar'] ?? null;
if ($vipNeedsRenewal && bm_user_avatar_is_uploaded((string)$profileAvatarValue)) {
    // Keep the uploaded file for a future renewal, but fall back to the default
    // avatar while the paid membership is inactive.
    $profileAvatarValue = null;
}
$currentAvatar = $profileAvatarValue;
$avatarPresets = bm_user_avatar_presets();
$avatarUploadAllowed = bm_user_avatar_can_upload($currentUser);
$csrfToken = bm_user_csrf_token();
bm_require_get_csrf(['remove_avatar']);

// VIP content request center: kept inside the profile and enabled only while
// the paid membership is active.
if (!function_exists('bm_profile_ensure_movie_requests')) {
    function bm_profile_ensure_movie_requests(PDO $pdo): void {
        $pdo->exec("CREATE TABLE IF NOT EXISTS movie_requests (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            user_id INT UNSIGNED NOT NULL,
            title VARCHAR(255) NOT NULL,
            type VARCHAR(20) NOT NULL DEFAULT 'movie',
            year VARCHAR(10) NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            admin_response TEXT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NULL,
            KEY idx_movie_requests_user (user_id, created_at),
            KEY idx_movie_requests_status (status, created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
}
if (!function_exists('bm_profile_request_status_key')) {
    function bm_profile_request_status_key($raw): string {
        $value = strtolower(trim((string)$raw));
        if (in_array($value, ['approved','answered','accepted','accept','done','completed','complete','success','1'], true)) return 'approved';
        if (in_array($value, ['rejected','declined','denied','reject','failed','2'], true)) return 'rejected';
        return 'pending';
    }
}
try { bm_profile_ensure_movie_requests($pdo); } catch (Throwable $e) { error_log('Profile request table error: '.$e->getMessage()); }
$requestFeatureAvailable = bm_vip_benefit_allowed('content_requests', $currentUser);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_movie_request'])) {
    bm_require_user_csrf(false, false);
    if (!$requestFeatureAvailable) {
        $message = $currentLanguage === 'fa' ? 'ثبت درخواست فیلم و سریال فقط با اشتراک VIP فعال امکان‌پذیر است' : 'An active VIP membership is required to submit requests';
        $messageType = 'error';
    } else {
        bm_security_enforce_rate_limit('vip_content_request', 8, 86400, 'user:' . (int)$userId, false);
        $requestTitle = trim((string)($_POST['request_title'] ?? ''));
        $requestType = strtolower(trim((string)($_POST['request_type'] ?? 'movie')));
        $requestYear = trim((string)($_POST['request_year'] ?? ''));
        $requestTitle = preg_replace('/[\x00-\x1F\x7F]/u', '', $requestTitle) ?? '';
        $requestTitle = mb_substr($requestTitle, 0, 255, 'UTF-8');
        if (!in_array($requestType, ['movie','series'], true)) $requestType = 'movie';
        if ($requestYear !== '' && !preg_match('/^(?:19|20)\d{2}$/', $requestYear)) $requestYear = '';

        if (mb_strlen($requestTitle, 'UTF-8') < 2) {
            $message = $currentLanguage === 'fa' ? 'نام فیلم یا سریال را کامل وارد کنید' : 'Enter a valid movie or series title';
            $messageType = 'error';
        } else {
            $duplicate = $pdo->prepare("SELECT id FROM movie_requests WHERE user_id=? AND LOWER(TRIM(title))=LOWER(TRIM(?)) AND type=? AND status='pending' AND created_at>=DATE_SUB(NOW(), INTERVAL 7 DAY) LIMIT 1");
            $duplicate->execute([(int)$userId, $requestTitle, $requestType]);
            if ($duplicate->fetchColumn()) {
                $message = $currentLanguage === 'fa' ? 'این درخواست هنوز در صف بررسی شما قرار دارد' : 'This request is already pending';
                $messageType = 'error';
            } else {
                $stmt = $pdo->prepare("INSERT INTO movie_requests (user_id,title,type,year,status,created_at) VALUES (?,?,?,?, 'pending', NOW())");
                $stmt->execute([(int)$userId, $requestTitle, $requestType, $requestYear !== '' ? $requestYear : null]);
                header('Location: /profile?request_saved=1#requests-section', true, 303);
                exit;
            }
        }
    }
}

if (isset($_GET['settings_saved'])) {
    if ($appearanceAccessAllowed || $themeAccessAllowed || $fontAccessAllowed) {
        $message = $currentLanguage === 'fa' ? 'تنظیمات ظاهر، فونت و زبان ذخیره شد' : 'Appearance, font and language settings saved';
    } else {
        $message = $currentLanguage === 'fa' ? 'زبان ذخیره شد؛ شخصی‌سازی پس‌زمینه، قاب، تم و فونت مخصوص VIP است' : 'Language saved; background, frame, theme and font personalization is VIP-only';
    }
    $messageType = 'success';
}

if (isset($_GET['request_saved'])) {
    $message = $currentLanguage === 'fa' ? 'درخواست VIP شما ثبت شد و در صف بررسی قرار گرفت' : 'Your VIP request was submitted';
    $messageType = 'success';
}

if (isset($_GET['profile_saved'])) {
    $message = $currentLanguage === 'fa' ? 'اطلاعات حساب با موفقیت بروزرسانی شد' : 'Account information updated';
    $messageType = 'success';
}
if (isset($_GET['theme_saved'])) {
    $message = $currentLanguage === 'fa' ? 'پوسته سایت با موفقیت تغییر کرد' : 'Site theme updated';
    $messageType = 'success';
}

// v148.61.9.4 — ذخیره سریع تم از داشبورد موبایل. دسترسی سمت سرور نیز VIP-only است.
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_mobile_theme'])) {
    bm_require_user_csrf(false, false);
    $allowedThemes = array_keys(bm_theme_catalog());
    $newTheme = trim((string)($_POST['mobile_theme'] ?? 'dark-green'));
    if (!$themeAccessAllowed || !in_array($newTheme, $allowedThemes, true)) $newTheme = 'dark-green';
    $stmt = $pdo->prepare("UPDATE users SET theme = ? WHERE id = ?");
    if ($stmt->execute([$newTheme, $userId])) {
        $currentTheme = $newTheme;
        $currentUser['theme'] = $newTheme;
        setcookie('user_theme', $newTheme, bm_cookie_options(false));
        $_COOKIE['user_theme'] = $newTheme;
        header('Location: /profile?theme_saved=1', true, 303);
        exit;
    }
    $message = $currentLanguage === 'fa' ? 'تغییر پوسته انجام نشد' : 'Theme update failed';
    $messageType = 'error';
}

// تنظیمات ظاهر، فونت و زبان — تم/فونت فقط برای VIP فعال و فونت در Cookie ذخیره می‌شود.
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_settings'])) {
    bm_require_user_csrf(false, false);
    $allowedThemes = array_keys(bm_theme_catalog());
    $allowedFonts = array_keys($fontCatalog);
    $newTheme = $themeAccessAllowed ? trim((string)($_POST['theme'] ?? $currentTheme)) : 'dark-green';
    $newFont = $fontAccessAllowed ? strtolower(trim((string)($_POST['font'] ?? $currentFont))) : $defaultFontId;
    $newLanguage = trim((string)($_POST['language'] ?? $currentLanguage));
    $newBackground = $appearanceAccessAllowed ? trim((string)($_POST['background_key'] ?? $currentBackground)) : 'simple';
    $newAvatarFrame = $appearanceAccessAllowed ? trim((string)($_POST['avatar_frame'] ?? $currentAvatarFrame)) : 'none';
    if (!$themeAccessAllowed || !in_array($newTheme, $allowedThemes, true)) $newTheme = 'dark-green';
    if (!$fontAccessAllowed || !in_array($newFont, $allowedFonts, true)) $newFont = $defaultFontId;
    if (!in_array($newLanguage, ['fa','en'], true)) $newLanguage = 'fa';
    if (!function_exists('bm_user_background_is_valid') || !bm_user_background_is_valid($newBackground)) $newBackground = 'simple';
    if (!function_exists('bm_user_avatar_frame_is_valid') || !bm_user_avatar_frame_is_valid($newAvatarFrame)) $newAvatarFrame = 'none';
    if ($appearanceColumnsReady) {
        $stmt = $pdo->prepare("UPDATE users SET theme = ?, language = ?, background_key = ?, avatar_frame = ? WHERE id = ?");
        $saveArgs = [$newTheme, $newLanguage, $newBackground, $newAvatarFrame, $userId];
    } else {
        $stmt = $pdo->prepare("UPDATE users SET theme = ?, language = ? WHERE id = ?");
        $saveArgs = [$newTheme, $newLanguage, $userId];
    }
    if($stmt->execute($saveArgs)) {
        $currentTheme = $newTheme;
        $currentFont = $newFont;
        $currentLanguage = $newLanguage;
        $currentBackground = $newBackground;
        $currentAvatarFrame = $newAvatarFrame;
        $currentUser['theme'] = $newTheme;
        $currentUser['language'] = $newLanguage;
        $currentUser['background_key'] = $newBackground;
        $currentUser['avatar_frame'] = $newAvatarFrame;
        setcookie('user_background', $newBackground, bm_cookie_options(false));
        setcookie('user_avatar_frame', $newAvatarFrame, bm_cookie_options(false));
        $_COOKIE['user_background'] = $newBackground;
        $_COOKIE['user_avatar_frame'] = $newAvatarFrame;
        setcookie('user_theme', $newTheme, bm_cookie_options(false));
        setcookie('user_lang', $newLanguage, bm_cookie_options(false));
        $_COOKIE['user_theme'] = $newTheme;
        $_COOKIE['user_lang'] = $newLanguage;
        if ($fontAccessAllowed) {
            setcookie('user_font', $newFont, bm_cookie_options(false));
            $_COOKIE['user_font'] = $newFont;
        } else {
            if (!headers_sent()) {
                $fontCookie = bm_cookie_options(false);
                $fontCookie['expires'] = time() - 3600;
                setcookie('user_font', '', $fontCookie);
            }
            unset($_COOKIE['user_font']);
        }
        header('Location: /profile?settings_saved=1#settings-section', true, 303);
        exit;
    }
    $message = $currentLanguage === 'fa' ? 'ذخیره تنظیمات انجام نشد' : 'Settings could not be saved';
    $messageType = 'error';
}

// Cookie فقط یک بار و بعد از پردازش فرم ثبت می‌شود تا مقدار قدیمی روی مقدار جدید نوشته نشود.
setcookie('user_theme', $currentTheme, bm_cookie_options(false));
setcookie('user_lang', $currentLanguage, bm_cookie_options(false));
setcookie('user_background', $currentBackground, bm_cookie_options(false));
setcookie('user_avatar_frame', $currentAvatarFrame, bm_cookie_options(false));
$_COOKIE['user_theme'] = $currentTheme;
$_COOKIE['user_lang'] = $currentLanguage;
$_COOKIE['user_background'] = $currentBackground;
$_COOKIE['user_avatar_frame'] = $currentAvatarFrame;

// ویرایش حرفه‌ای اطلاعات حساب: نام، نام کاربری و ایمیل
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_profile'])) {
    bm_require_user_csrf(false, false);
    bm_security_enforce_rate_limit('profile_identity', 8, 3600, 'user:' . (int)$userId, false);

    $fullName = trim((string)($_POST['full_name'] ?? ''));
    $username = trim((string)($_POST['username'] ?? ''));
    $email = strtolower(trim((string)($_POST['email'] ?? '')));
    $identityPassword = (string)($_POST['identity_password'] ?? '');

    $fullName = preg_replace('/[\x00-\x1F\x7F]/u', '', $fullName) ?? '';
    $fullName = mb_substr($fullName, 0, 100, 'UTF-8');
    $username = preg_replace('/[\x00-\x1F\x7F]/u', '', $username) ?? '';
    $username = mb_substr($username, 0, 40, 'UTF-8');

    $usernameChanged = strcasecmp($username, (string)($currentUser['username'] ?? '')) !== 0;
    $emailChanged = strcasecmp($email, (string)($currentUser['email'] ?? '')) !== 0;
    $identityChanged = $usernameChanged || $emailChanged;

    if (mb_strlen($username, 'UTF-8') < 3 || mb_strlen($username, 'UTF-8') > 40) {
        $message = $currentLanguage === 'fa' ? 'نام کاربری باید بین ۳ تا ۴۰ کاراکتر باشد' : 'Username must be 3 to 40 characters';
        $messageType = 'error';
    } elseif (!preg_match('/^[\p{L}\p{N}_.-]+$/u', $username)) {
        $message = $currentLanguage === 'fa' ? 'نام کاربری فقط می‌تواند شامل حروف، عدد، نقطه، خط تیره و زیرخط باشد' : 'Username contains invalid characters';
        $messageType = 'error';
    } elseif (strlen($email) > 190 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = $currentLanguage === 'fa' ? 'یک ایمیل معتبر وارد کنید' : 'Enter a valid email address';
        $messageType = 'error';
    } elseif ($identityChanged && $identityPassword === '') {
        $message = $currentLanguage === 'fa' ? 'برای تغییر نام کاربری یا ایمیل، رمز فعلی را وارد کنید' : 'Enter your current password to change username or email';
        $messageType = 'error';
    } else {
        $canUpdate = true;
        if ($identityChanged) {
            $stmt = $pdo->prepare('SELECT password FROM users WHERE id=? LIMIT 1');
            $stmt->execute([(int)$userId]);
            $storedPassword = (string)($stmt->fetchColumn() ?: '');
            if ($storedPassword === '' || !password_verify($identityPassword, $storedPassword)) {
                $canUpdate = false;
                bm_security_audit('profile_identity_change_failed', ['user_id' => (int)$userId]);
                $message = $currentLanguage === 'fa' ? 'رمز فعلی صحیح نیست' : 'Current password is incorrect';
                $messageType = 'error';
            }
        }

        if ($canUpdate) {
            $stmt = $pdo->prepare('SELECT id,username,email FROM users WHERE id<>? AND (LOWER(username)=LOWER(?) OR LOWER(email)=LOWER(?)) LIMIT 1');
            $stmt->execute([(int)$userId, $username, $email]);
            $duplicateIdentity = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($duplicateIdentity) {
                $sameUsername = strcasecmp((string)($duplicateIdentity['username'] ?? ''), $username) === 0;
                $message = $sameUsername
                    ? ($currentLanguage === 'fa' ? 'این نام کاربری قبلاً استفاده شده است' : 'This username is already in use')
                    : ($currentLanguage === 'fa' ? 'این ایمیل قبلاً استفاده شده است' : 'This email is already in use');
                $messageType = 'error';
            } else {
                $stmt = $pdo->prepare('UPDATE users SET full_name=?, username=?, email=? WHERE id=?');
                if ($stmt->execute([$fullName, $username, $email, (int)$userId])) {
                    $currentUser['full_name'] = $fullName;
                    $currentUser['username'] = $username;
                    $currentUser['email'] = $email;
                    bm_security_audit('profile_identity_changed', [
                        'user_id' => (int)$userId,
                        'username_changed' => $usernameChanged,
                        'email_changed' => $emailChanged,
                    ]);
                    header('Location: /profile?profile_saved=1#profile-info-section', true, 303);
                    exit;
                }
                $message = $currentLanguage === 'fa' ? 'بروزرسانی حساب انجام نشد' : 'Account update failed';
                $messageType = 'error';
            }
        }
    }
}

// تغییر رمز عبور
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    bm_require_user_csrf(false, false);
    bm_security_enforce_rate_limit('profile_password', 6, 3600, 'user:' . (int)$userId, false);
    $currentPassword = (string)($_POST['current_password'] ?? '');
    $newPassword = (string)($_POST['new_password'] ?? '');
    $confirmPassword = (string)($_POST['confirm_password'] ?? '');
    if($currentPassword === '') {
        $message = $currentLanguage === 'fa' ? 'رمز فعلی را وارد کنید' : 'Enter current password';
        $messageType = 'error';
    } elseif(strlen($newPassword) < 8) {
        $message = $currentLanguage === 'fa' ? 'رمز جدید حداقل ۸ کاراکتر باشد' : 'Password must be at least 8 characters';
        $messageType = 'error';
    } elseif(strlen($newPassword) > 200) {
        $message = $currentLanguage === 'fa' ? 'رمز جدید بیش از حد طولانی است' : 'Password is too long';
        $messageType = 'error';
    } elseif(hash_equals($currentPassword, $newPassword)) {
        $message = $currentLanguage === 'fa' ? 'رمز جدید باید با رمز فعلی متفاوت باشد' : 'New password must be different';
        $messageType = 'error';
    } elseif(!hash_equals($newPassword, $confirmPassword)) {
        $message = $currentLanguage === 'fa' ? 'تکرار رمز مطابقت ندارد' : 'Passwords do not match';
        $messageType = 'error';
    } else {
        $stmt = $pdo->prepare("SELECT password FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$userId]);
        $passwordRow = $stmt->fetch(PDO::FETCH_ASSOC);
        if($passwordRow && password_verify($currentPassword, (string)$passwordRow['password'])) {
            $newHashed = password_hash($newPassword, PASSWORD_DEFAULT);
            $newToken = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', time() + 604800);
            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
                $stmt->execute([$newHashed, $userId]);
                $stmt = $pdo->prepare('DELETE FROM user_sessions WHERE user_id = ?');
                $stmt->execute([$userId]);
                bm_user_session_insert($pdo, (int)$userId, $newToken, $expiresAt);
                $pdo->commit();

                session_regenerate_id(true);
                $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
                setcookie('session_token', $newToken, bm_session_cookie_options(604800));
                $_COOKIE['session_token'] = $newToken;
                bm_security_audit('password_changed', ['user_id' => (int)$userId]);
                $message = $currentLanguage === 'fa' ? 'رمز تغییر کرد و نشست‌های قبلی بسته شدند' : 'Password changed and old sessions were closed';
                $messageType = 'success';
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                error_log('Password change failed: ' . $e->getMessage());
                $message = $currentLanguage === 'fa' ? 'تغییر رمز انجام نشد؛ دوباره تلاش کنید' : 'Password change failed; please try again';
                $messageType = 'error';
            }
        } else {
            bm_security_audit('password_change_failed', ['user_id' => (int)$userId]);
            $message = $currentLanguage === 'fa' ? 'رمز فعلی اشتباه است' : 'Wrong current password';
            $messageType = 'error';
        }
    }
}

// انتخاب آواتار آماده بانک مووی (برای همه اعضا)
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['select_preset_avatar'])) {
    bm_require_user_csrf(false, false);
    $presetKey = trim((string)($_POST['preset_avatar'] ?? ''));
    $presetPath = bm_user_avatar_preset_path($presetKey);
    if ($presetPath === null) {
        $message = $currentLanguage === 'fa' ? 'آواتار انتخاب‌شده معتبر نیست' : 'Invalid preset avatar';
        $messageType = 'error';
    } else {
        if (!empty($currentUser['avatar']) && bm_user_avatar_is_uploaded((string)$currentUser['avatar'])) {
            $oldPath = dirname(__FILE__) . '/' . ltrim((string)$currentUser['avatar'], '/');
            if (is_file($oldPath)) @unlink($oldPath);
        }
        $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        if ($stmt->execute([$presetPath, $userId])) {
            $currentUser['avatar'] = $presetPath;
            $currentAvatar = $presetPath;
            $message = $currentLanguage === 'fa' ? 'آواتار جدید انتخاب شد' : 'Avatar selected';
            $messageType = 'success';
        }
    }
}

// آپلود آواتار اختصاصی اعضای VIP (حداکثر ۱ مگابایت)
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    bm_require_user_csrf(false, false);
    if (!$avatarUploadAllowed) {
        $message = $currentLanguage === 'fa' ? 'آپلود آواتار اختصاصی فقط برای اعضای VIP فعال است' : 'Custom avatar upload is VIP only';
        $messageType = 'error';
    } else {
        $maxSize = 1 * 1024 * 1024;
        if($_FILES['avatar']['size'] > $maxSize) {
            $message = $currentLanguage === 'fa' ? 'حجم بیشتر از ۱ مگابایت' : 'File > 1MB';
            $messageType = 'error';
        } else {
            $allowed = ['jpg','jpeg','png','webp'];
            $ext = strtolower(pathinfo((string)$_FILES['avatar']['name'], PATHINFO_EXTENSION));
            $info = @getimagesize($_FILES['avatar']['tmp_name']);
            $allowedMime = ['image/jpeg', 'image/png', 'image/webp'];
            $width = (int)($info[0] ?? 0);
            $height = (int)($info[1] ?? 0);
            $tooLarge = $width <= 0 || $height <= 0 || $width > 8000 || $height > 8000 || ($width * $height) > 24000000;
            if(!in_array($ext, $allowed, true) || !$info || empty($info['mime']) || !in_array($info['mime'], $allowedMime, true) || $tooLarge) {
                $message = $currentLanguage === 'fa' ? 'تصویر معتبر نیست یا ابعاد آن بیش از حد بزرگ است' : 'Invalid image or dimensions are too large';
                $messageType = 'error';
            } else {
                $uploadDir = 'uploads/avatars/';
                if(!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
                $filename = 'user_' . (int)$userId . '_' . bin2hex(random_bytes(8)) . '.webp';
                $filepath = $uploadDir . $filename;
                $imgData = @file_get_contents($_FILES['avatar']['tmp_name']);
                $img = $imgData !== false ? @imagecreatefromstring($imgData) : false;
                if($img && imagewebp($img, $filepath, 82)) {
                    imagedestroy($img);
                    @chmod($filepath, 0644);
                    if(!empty($currentUser['avatar']) && bm_user_avatar_is_uploaded((string)$currentUser['avatar'])) {
                        $oldPath = dirname(__FILE__) . '/' . ltrim((string)$currentUser['avatar'], '/');
                        if (is_file($oldPath)) @unlink($oldPath);
                    }
                    $stmt = $pdo->prepare("UPDATE users SET avatar = ? WHERE id = ?");
                    if($stmt->execute([$filepath, $userId])) {
                        $currentUser['avatar'] = $filepath;
                        $currentAvatar = $filepath;
                        $message = $currentLanguage === 'fa' ? 'آواتار اختصاصی VIP آپلود شد' : 'VIP avatar uploaded';
                        $messageType = 'success';
                    }
                } else {
                    if($img) imagedestroy($img);
                    $message = $currentLanguage === 'fa' ? 'پردازش تصویر انجام نشد' : 'Image processing failed';
                    $messageType = 'error';
                }
            }
        }
    }
}

// حذف آواتار
if(isset($_GET['remove_avatar'])) {
    if(!empty($currentUser['avatar']) && bm_user_avatar_is_uploaded((string)$currentUser['avatar'])) { $oldPath = dirname(__FILE__) . '/' . ltrim((string)$currentUser['avatar'], '/'); if (is_file($oldPath)) @unlink($oldPath); }
    $stmt = $pdo->prepare("UPDATE users SET avatar = NULL WHERE id = ?");
    $stmt->execute([$userId]);
    $currentUser['avatar'] = null;
    header("Location: /profile?msg=" . urlencode($currentLanguage === 'fa' ? 'آواتار حذف شد' : 'Avatar removed'));
    exit;
}

// واتچ لیست (حداکثر ۲۰)
$stmt = $pdo->prepare("
    SELECT m.* FROM watchlist w 
    JOIN movies m ON w.movie_id = m.id 
    WHERE w.user_id = ? 
    ORDER BY w.added_at DESC 
    LIMIT 20
");
$stmt->execute([$userId]);
$watchlist = $stmt->fetchAll();
$totalWatchlist = $pdo->prepare("SELECT COUNT(*) FROM watchlist WHERE user_id = ?");
$totalWatchlist->execute([$userId]);
$totalWatchlistCount = (int)$totalWatchlist->fetchColumn();

// نشانه‌های آرشیو ۱ هم در پروفایل نمایش داده شود
$archive1Watchlist = [];
$totalArchive1WatchlistCount = 0;
try {
    bm_profile_ensure_archive1_watchlist($pdo);
    $stmtA1 = $pdo->prepare("SELECT * FROM archive1_watchlist WHERE user_id = ? ORDER BY added_at DESC LIMIT 20");
    $stmtA1->execute([$userId]);
    $archive1Watchlist = $stmtA1->fetchAll();

    $totalA1 = $pdo->prepare("SELECT COUNT(*) FROM archive1_watchlist WHERE user_id = ?");
    $totalA1->execute([$userId]);
    $totalArchive1WatchlistCount = (int)$totalA1->fetchColumn();
} catch (Throwable $e) {
    $archive1Watchlist = [];
    $totalArchive1WatchlistCount = 0;
}
$totalWatchlistCount = (int)$totalWatchlistCount + (int)$totalArchive1WatchlistCount;

// تاریخچه بازدید از پروفایل حذف شد تا صفحه سبک‌تر شود.
$recentViews = [];
$totalRecentCount = 0;

// جدول نگاشت آرشیو ۱ برای اینکه کامنت‌های آرشیو ۱ در پروفایل با عنوان و لینک درست نمایش داده شوند
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_items (
        virtual_movie_id INT UNSIGNED NOT NULL PRIMARY KEY,
        slug VARCHAR(220) NOT NULL DEFAULT '',
        item_link VARCHAR(500) NOT NULL DEFAULT '',
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_slug (slug)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {}
try {
    if (function_exists('bm_ensure_archive1_comment_tables')) {
        bm_ensure_archive1_comment_tables($pdo);
    } else {
        $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_comments (
            id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            movie_id INT UNSIGNED NOT NULL,
            user_id INT UNSIGNED NULL,
            username VARCHAR(100) NOT NULL DEFAULT '',
            comment TEXT NOT NULL,
            rating TINYINT UNSIGNED NOT NULL DEFAULT 0,
            spoiler TINYINT(1) NOT NULL DEFAULT 0,
            parent_id BIGINT UNSIGNED NULL DEFAULT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            KEY idx_movie_parent_status (movie_id, parent_id, status),
            KEY idx_user_status (user_id, status),
            KEY idx_parent (parent_id),
            KEY idx_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    }
} catch (Throwable $e) {}

// کامنت‌های کاربر
// منطق پایدار: در بعضی دیتابیس‌ها parent_id برای کامنت اصلی NULL است و در بعضی 0 ذخیره می‌شود.
// این نسخه هر دو حالت را پشتیبانی می‌کند و اگر فیلم حذف شده باشد هم کامنت از پروفایل حذف نمی‌شود.
$activeCommentStatusSql = "(c.status = 'active' OR c.status = 'approved' OR c.status = 1)";
$activeReplyStatusSql = "(r.status = 'active' OR r.status = 'approved' OR r.status = 1)";
$rootCommentSql = "(c.parent_id IS NULL OR c.parent_id = 0 OR c.parent_id = '')";
$replyCommentSql = "(c.parent_id IS NOT NULL AND c.parent_id <> 0 AND c.parent_id <> '')";
$rootCommentCountSql = "(parent_id IS NULL OR parent_id = 0 OR parent_id = '')";
$replyCommentCountSql = "(parent_id IS NOT NULL AND parent_id <> 0 AND parent_id <> '')";

$stmt = $pdo->prepare("
    SELECT c.*, COALESCE(m.title_fa, ai.item_title_fa, ai.item_title, 'فیلم') as movie_title,
           COALESCE(m.title, ai.item_title, ai.item_title_fa, 'movie') as movie_title_en,
           COALESCE(m.id, ai.virtual_movie_id) as movie_id, m.imdb_code, ai.item_link as archive1_link,
           (SELECT COUNT(*) FROM comments r WHERE r.parent_id = c.id AND (r.status = 'active' OR r.status = 'approved' OR r.status = 1)) as reply_count,
           u2.avatar as commenter_avatar, u2.username as commenter_name
    FROM comments c
    LEFT JOIN movies m ON c.movie_id = m.id
    LEFT JOIN archive1_items ai ON c.movie_id = ai.virtual_movie_id
    LEFT JOIN users u2 ON c.user_id = u2.id
    WHERE c.user_id = ? AND $activeCommentStatusSql AND $rootCommentSql
    ORDER BY c.created_at DESC
    LIMIT 20
");
$stmt->execute([$userId]);
$userComments = $stmt->fetchAll();
try {
    $stmtA1Comments = $pdo->prepare("
        SELECT c.*, COALESCE(ai.item_title_fa, ai.item_title, 'فیلم') as movie_title,
               COALESCE(ai.item_title, ai.item_title_fa, 'movie') as movie_title_en,
               ai.virtual_movie_id as movie_id, NULL as imdb_code, ai.item_link as archive1_link,
               (SELECT COUNT(*) FROM archive1_comments r WHERE r.parent_id = c.id AND (r.status = 'active' OR r.status = 'approved' OR r.status = 1)) as reply_count,
               u2.avatar as commenter_avatar, u2.username as commenter_name,
               1 as is_archive1_comment
        FROM archive1_comments c
        LEFT JOIN archive1_items ai ON c.movie_id = ai.virtual_movie_id
        LEFT JOIN users u2 ON c.user_id = u2.id
        WHERE c.user_id = ? AND (c.status = 'active' OR c.status = 'approved' OR c.status = 1) AND (c.parent_id IS NULL OR c.parent_id = 0 OR c.parent_id = '')
        ORDER BY c.created_at DESC
        LIMIT 20
    ");
    $stmtA1Comments->execute([$userId]);
    $userComments = array_merge($userComments, $stmtA1Comments->fetchAll());
    usort($userComments, function($a, $b) { return strtotime($b['created_at'] ?? '') <=> strtotime($a['created_at'] ?? ''); });
    $userComments = array_slice($userComments, 0, 20);
} catch (Throwable $e) {}
$totalUserComments = $pdo->prepare("SELECT COUNT(*) FROM comments c WHERE c.user_id = ? AND $activeCommentStatusSql AND $rootCommentSql");
$totalUserComments->execute([$userId]);
$totalUserCommentsCount = (int)$totalUserComments->fetchColumn();
try {
    $countA1Comments = $pdo->prepare("SELECT COUNT(*) FROM archive1_comments c WHERE c.user_id = ? AND (c.status = 'active' OR c.status = 'approved' OR c.status = 1) AND (c.parent_id IS NULL OR c.parent_id = 0 OR c.parent_id = '')");
    $countA1Comments->execute([$userId]);
    $totalUserCommentsCount += (int)$countA1Comments->fetchColumn();
} catch (Throwable $e) {}

// پاسخ‌های کاربر
$stmt = $pdo->prepare("
    SELECT c.*, COALESCE(m.title_fa, ai.item_title_fa, ai.item_title, 'فیلم') as movie_title,
           COALESCE(m.title, ai.item_title, ai.item_title_fa, 'movie') as movie_title_en,
           COALESCE(m.id, ai.virtual_movie_id) as movie_id, m.imdb_code, ai.item_link as archive1_link,
           COALESCE(parent_user.username, parent_comment.username) as parent_username,
           u2.avatar as commenter_avatar, u2.username as commenter_name
    FROM comments c
    LEFT JOIN comments parent_comment ON parent_comment.id = c.parent_id
    LEFT JOIN users parent_user ON parent_user.id = parent_comment.user_id
    LEFT JOIN movies m ON c.movie_id = m.id
    LEFT JOIN archive1_items ai ON c.movie_id = ai.virtual_movie_id
    LEFT JOIN users u2 ON c.user_id = u2.id
    WHERE c.user_id = ? AND $activeCommentStatusSql AND $replyCommentSql
    ORDER BY c.created_at DESC
    LIMIT 20
");
$stmt->execute([$userId]);
$userReplies = $stmt->fetchAll();
try {
    $stmtA1Replies = $pdo->prepare("
        SELECT c.*, COALESCE(ai.item_title_fa, ai.item_title, 'فیلم') as movie_title,
               COALESCE(ai.item_title, ai.item_title_fa, 'movie') as movie_title_en,
               ai.virtual_movie_id as movie_id, NULL as imdb_code, ai.item_link as archive1_link,
               COALESCE(parent_user.username, parent_comment.username) as parent_username,
               u2.avatar as commenter_avatar, u2.username as commenter_name,
               1 as is_archive1_comment
        FROM archive1_comments c
        LEFT JOIN archive1_comments parent_comment ON parent_comment.id = c.parent_id
        LEFT JOIN users parent_user ON parent_user.id = parent_comment.user_id
        LEFT JOIN archive1_items ai ON c.movie_id = ai.virtual_movie_id
        LEFT JOIN users u2 ON c.user_id = u2.id
        WHERE c.user_id = ? AND (c.status = 'active' OR c.status = 'approved' OR c.status = 1) AND (c.parent_id IS NOT NULL AND c.parent_id <> 0 AND c.parent_id <> '')
        ORDER BY c.created_at DESC
        LIMIT 20
    ");
    $stmtA1Replies->execute([$userId]);
    $userReplies = array_merge($userReplies, $stmtA1Replies->fetchAll());
    usort($userReplies, function($a, $b) { return strtotime($b['created_at'] ?? '') <=> strtotime($a['created_at'] ?? ''); });
    $userReplies = array_slice($userReplies, 0, 20);
} catch (Throwable $e) {}
$totalUserReplies = $pdo->prepare("SELECT COUNT(*) FROM comments c WHERE c.user_id = ? AND $activeCommentStatusSql AND $replyCommentSql");
$totalUserReplies->execute([$userId]);
$totalUserRepliesCount = (int)$totalUserReplies->fetchColumn();
try {
    $countA1Replies = $pdo->prepare("SELECT COUNT(*) FROM archive1_comments c WHERE c.user_id = ? AND (c.status = 'active' OR c.status = 'approved' OR c.status = 1) AND (c.parent_id IS NOT NULL AND c.parent_id <> 0 AND c.parent_id <> '')");
    $countA1Replies->execute([$userId]);
    $totalUserRepliesCount += (int)$countA1Replies->fetchColumn();
} catch (Throwable $e) {}

// آخرین درخواست‌های فیلم و سریال کاربر
$userRequests = [];
$totalRequestsCount = 0;
try {
    $countRequests = $pdo->prepare('SELECT COUNT(*) FROM movie_requests WHERE user_id=?');
    $countRequests->execute([(int)$userId]);
    $totalRequestsCount = (int)$countRequests->fetchColumn();
    $requestRows = $pdo->prepare('SELECT id,title,type,year,status,admin_response,created_at,updated_at FROM movie_requests WHERE user_id=? ORDER BY id DESC LIMIT 20');
    $requestRows->execute([(int)$userId]);
    $userRequests = $requestRows->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
    error_log('Profile requests load error: ' . $e->getMessage());
}

// تم‌ها — از کاتالوگ مرکزی سایت خوانده می‌شوند
$themes = bm_theme_catalog();
foreach ($themes as $themeKey => &$themeInfo) {
    $themeInfo['bg'] = $themeKey === 'dark-black' ? '#000000' : '#0a0a0c';
}
unset($themeInfo);

if (!isset($themes[$currentTheme])) {
    $currentTheme = 'dark-green';
}
$themeHex = ltrim($themes[$currentTheme]['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgb = [
    hexdec(substr($themeHex, 0, 2)),
    hexdec(substr($themeHex, 2, 2)),
    hexdec(substr($themeHex, 4, 2)),
];
$currentThemeRgbCss = implode(',', $currentThemeRgb);

$dir = $currentLanguage === 'fa' ? 'rtl' : 'ltr';
$langAttr = $currentLanguage === 'fa' ? 'fa' : 'en';
$DEFAULT_POSTER = 'uploads/no.png';
$profileBrandLogo = trim((string)bm_site_get('brand_logo_path', '/assets/brand/bankmovie-logo.webp')) ?: '/assets/brand/bankmovie-logo.webp';

function escapeHtml($str) { return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8'); }
?>
<!DOCTYPE html>
<html lang="<?= $langAttr ?>" dir="<?= $dir ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?= $currentLanguage === 'fa' ? 'پروفایل کاربری' : 'User Profile' ?> | BankMovie</title>
    <style>
       /* ========== فونت اختصاصی BonVF ========== */
@font-face {
    font-family: 'BonVF';
    src: url('/assets/fonts/bonVF.woff2') format('woff2');
    font-weight: 100 900;
    font-style: normal;
    font-display: swap;
}

<?= function_exists('bm_site_all_font_faces_css') ? bm_site_all_font_faces_css() : '' ?>

* { margin: 0; padding: 0; box-sizing: border-box; -webkit-tap-highlight-color: transparent; }
:root {
    --bg-primary: <?= $themes[$currentTheme]['bg'] ?>;
    --bg-secondary: #121215;
    --bg-tertiary: #18181d;
    --bg-card: #0f0f13;
    --accent: <?= $themes[$currentTheme]['primary'] ?>;
    --accent-rgb: <?= $currentThemeRgbCss ?>;
    --accent-dark: <?= $themes[$currentTheme]['primary'] ?>cc;
    --accent-glow: rgba(var(--accent-rgb), 0.12);
    --text-primary: #ffffff;
    --text-secondary: #a0a0a8;
    --text-tertiary: #6e6e7a;
    --border-subtle: rgba(255,255,255,0.06);
    --border-accent: rgba(var(--accent-rgb), 0.25);
    --gradient-hero: linear-gradient(135deg, #ffffff, var(--accent));
}
body { 
    background: var(--bg-primary); 
    color: var(--text-primary); 
    font-family: var(--bm-site-font, 'BonVF'), system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; 
    padding-bottom: 104px; 
}

/* فونت برای همه المان‌ها */
button, input, select, textarea, a, p, h1, h2, h3, h4, h5, h6, span, div,
.logo-text, .back-btn, .nav-label, .page-title, .page-desc, .profile-name, .profile-username,
.stat-badge, .profile-action-btn, .section-title, .view-all-link, .save-btn, .theme-option,
.lang-btn, .movie-title, .remove-btn, .comment-movie, .comment-text, .reply-item, .reply-parent,
.section-subtitle, .empty-state, .toast, .nav-item, .grid-title-fa, .grid-title-en, .grid-meta,
.grid-rating, .grid-votes, .grid-type, .pagination a, .pagination span, .sidebar-item,
.sidebar-username, .sidebar-userrole, .story-name, .scroll-card-title-fa, .scroll-card-title-en,
.scroll-card-meta, .type-btn, .reset-btn, .random-btn, .filter-group select, .search-input,
.search-result-title, .search-result-original, .search-result-meta, .search-result-badge,
.download-link .quality, .download-link .size, .quality-btn, .ctrl-btn, .settings-option,
.comment-submit, .reply-btn, .load-more-comments button, .notification-title, .notification-message,
.notification-btn, .donate-btn, .hero-title, .hero-desc, .stat-number, .stat-label {
    font-family: var(--bm-site-font, 'BonVF'), system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: var(--bg-secondary); border-radius: 10px; }
::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 10px; }

.header { position: sticky; top: 0; z-index: 100; backdrop-filter: blur(20px); background: rgba(10,10,14,0.85); border-bottom: 1px solid var(--border-subtle); }
.header-inner { max-width: 1400px; height: 64px; margin: 0 auto; padding: 0 20px; display: flex; align-items: center; justify-content: space-between; }
.logo { display: flex; align-items: center; gap: 10px; text-decoration: none; }
.logo-icon { width: 32px; height: 32px; }
.logo-text { font-size: 20px; font-weight: 800; background: var(--gradient-hero); -webkit-background-clip: text; background-clip: text; color: transparent; }
.back-btn { display: flex; align-items: center; gap: 6px; background: var(--bg-secondary); border: 1px solid var(--border-subtle); padding: 8px 16px; border-radius: 40px; color: var(--text-primary); text-decoration: none; font-size: 13px; transition: 0.2s; }
.back-btn:hover { border-color: var(--accent); }
.logout-btn { background: rgba(255,68,68,0.15); border: 1px solid rgba(255,68,68,0.3); color: #ff8888; }

.container { max-width: 1200px; margin: 0 auto; padding: 20px; }

/* پروفایل هدر */
.profile-header { background: linear-gradient(135deg, var(--accent)10, transparent); border-radius: 32px; padding: 30px; margin-bottom: 30px; border: 1px solid var(--border-accent); display: flex; flex-wrap: wrap; gap: 30px; align-items: center; }
.profile-avatar-section { display: flex; flex-direction: column; align-items: center; gap: 12px; }
.profile-avatar { width: 100px; height: 100px; background: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; overflow: hidden; border: 3px solid var(--accent); box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3); }
.profile-avatar img { width: 100%; height: 100%; object-fit: cover; }
.profile-avatar svg { width: 50px; height: 50px; stroke: #000; fill: none; }
.avatar-actions { display: flex; gap: 8px; flex-wrap: wrap; justify-content: center; }
.avatar-btn { background: var(--bg-tertiary); border: 1px solid var(--border-subtle); padding: 6px 12px; border-radius: 40px; font-size: 11px; cursor: pointer; transition: 0.2s; color: var(--text-secondary); text-decoration: none; display: inline-flex; align-items: center; gap: 4px; }
.avatar-btn:hover { border-color: var(--accent); color: var(--accent); }
.profile-info { flex: 1; }
.profile-name { font-size: 28px; font-weight: 800; margin-bottom: 5px; display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
.profile-username { color: var(--text-secondary); font-size: 14px; margin-bottom: 12px; }
.profile-stats { display: flex; gap: 20px; flex-wrap: wrap; margin: 15px 0; }
.stat-badge { background: var(--bg-tertiary); padding: 8px 18px; border-radius: 40px; font-size: 13px; }
.stat-badge span { color: var(--accent); font-weight: 700; font-size: 18px; margin-right: 5px; }
.action-buttons-header { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 10px; }
.profile-action-btn { background: var(--bg-tertiary); border: 1px solid var(--border-subtle); padding: 8px 20px; border-radius: 40px; cursor: pointer; transition: 0.2s; font-size: 13px; display: inline-flex; align-items: center; gap: 8px; color: var(--text-primary); }
.profile-action-btn:hover { border-color: var(--accent); background: var(--accent-glow); }
.profile-action-btn.active { background: var(--accent); color: #000; border-color: var(--accent); }

/* کارت‌های بخش */
.section { background: var(--bg-card); border-radius: 28px; padding: 24px; margin-bottom: 24px; border: 1px solid var(--border-subtle); transition: 0.2s; }
.section-title { font-size: 18px; font-weight: 700; color: var(--accent); margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px; border-right: 3px solid var(--accent); padding-right: 12px; }
.section-title-left { display: flex; align-items: center; gap: 10px; }
.section-title-left svg { width: 22px; height: 22px; stroke: currentColor; fill: none; }
.view-all-link { background: none; border: none; color: var(--accent); font-size: 12px; cursor: pointer; display: flex; align-items: center; gap: 4px; text-decoration: none; }

/* فرم‌ها */
.form-group { margin-bottom: 20px; }
.form-group label { display: block; margin-bottom: 8px; font-size: 13px; color: var(--text-secondary); }
.form-group input { width: 100%; background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: 20px; padding: 12px 16px; color: var(--text-primary); font-size: 14px; outline: none; }
.form-group input:focus { border-color: var(--accent); }
.save-btn { background: var(--accent); color: #000; border: none; padding: 12px 30px; border-radius: 40px; font-weight: 700; cursor: pointer; transition: 0.2s; margin-top: 20px; }
.save-btn:hover { transform: translateY(-2px); filter: brightness(1.05); }

/* تم و زبان */
.theme-grid { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; }
.theme-option { display: flex; align-items: center; gap: 10px; padding: 10px 18px; background: var(--bg-secondary); border: 2px solid var(--border-subtle); border-radius: 40px; cursor: pointer; }
.theme-option.active { border-color: var(--accent); background: var(--accent)15; }
.theme-color { width: 24px; height: 24px; border-radius: 50%; }
.lang-buttons { display: flex; gap: 12px; }
.lang-btn { padding: 10px 24px; background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: 40px; cursor: pointer; font-size: 13px; }
.lang-btn.active { background: var(--accent); color: #000; }

/* اسکرول افقی */
.scroll-horizontal { display: flex; overflow-x: auto; gap: 16px; padding-bottom: 12px; scrollbar-width: thin; }
.movie-card { flex-shrink: 0; width: 150px; background: var(--bg-secondary); border-radius: 16px; overflow: hidden; text-decoration: none; color: inherit; transition: 0.2s; border: 1px solid var(--border-subtle); }
.movie-card:hover { transform: translateY(-4px); border-color: var(--accent); }
.movie-poster { width: 100%; aspect-ratio: 2/3; object-fit: cover; }
.movie-info { padding: 10px; }
.movie-title { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.progress-bar { margin-top: 8px; height: 3px; background: var(--border-subtle); border-radius: 3px; overflow: hidden; }
.progress-fill { height: 100%; background: var(--accent); width: 0%; }
.remove-btn { background: rgba(255,68,68,0.15); border: none; padding: 4px 12px; border-radius: 20px; color: #ff8888; font-size: 11px; cursor: pointer; width: 100%; margin-top: 6px; }
.remove-btn:hover { background: rgba(255,68,68,0.3); }

/* بخش کامنت‌ها و درخواست‌ها */
.comments-scroll { max-height: 500px; overflow-y: auto; display: flex; flex-direction: column; gap: 16px; padding-right: 4px; }
.comment-card { background: var(--bg-secondary); border-radius: 20px; padding: 16px; border: 1px solid var(--border-subtle); }
.comment-header { display: flex; justify-content: space-between; align-items: flex-start; flex-wrap: wrap; margin-bottom: 10px; gap: 8px; }
.comment-user { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
.comment-avatar-small { width: 32px; height: 32px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.comment-avatar-small img { width: 100%; height: 100%; object-fit: cover; }
.comment-avatar-small svg { width: 18px; height: 18px; stroke: #000; }
.comment-movie { font-weight: 600; font-size: 14px; color: var(--accent); text-decoration: none; }
.comment-date { font-size: 11px; color: var(--text-tertiary); }
.comment-text { font-size: 13px; color: var(--text-secondary); line-height: 1.5; margin: 8px 0; }
.reply-badge { background: rgba(54,255,159,0.15); padding: 2px 8px; border-radius: 40px; font-size: 10px; display: inline-block; }
.reply-list { margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-subtle); padding-right: 15px; border-right: 2px solid var(--accent); }
.reply-item { background: var(--bg-tertiary); border-radius: 16px; padding: 12px; margin-bottom: 10px; }
.reply-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; margin-bottom: 6px; font-size: 12px; gap: 8px; }
.reply-user { display: flex; align-items: center; gap: 8px; }
.reply-avatar { width: 24px; height: 24px; border-radius: 50%; background: var(--accent); display: flex; align-items: center; justify-content: center; overflow: hidden; }
.reply-avatar img { width: 100%; height: 100%; object-fit: cover; }
.reply-avatar svg { width: 14px; height: 14px; stroke: #000; }
.reply-parent { color: var(--accent); font-weight: 500; }
.section-subtitle { font-size: 16px; font-weight: 600; color: var(--accent); margin: 20px 0 12px 0; display: flex; align-items: center; gap: 8px; border-right: 2px solid var(--accent); padding-right: 10px; }
.empty-state { text-align: center; padding: 50px; color: var(--text-tertiary); }
.toast-container { position: fixed; top: 80px; right: 16px; left: 16px; z-index: 10001; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
.toast { background: var(--bg-tertiary); border: 1px solid var(--accent); border-radius: 60px; padding: 12px 20px; text-align: center; animation: slideIn 0.3s ease; pointer-events: auto; max-width: 400px; margin: 0 auto; }
@keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
/* فوتر/داک موبایل هماهنگ با / */
.bottom-nav{
    position: fixed;
    left: 50%;
    bottom: max(10px, env(safe-area-inset-bottom));
    transform: translateX(-50%);
    width: min(calc(100% - 26px), 540px);
    height: 74px;
    display: flex;
    align-items: center;
    justify-content: space-around;
    gap: 4px;
    padding: 7px 10px;
    z-index: 100;
    border-radius: 32px;
    background:
        radial-gradient(circle at 50% -20%, rgba(var(--accent-rgb), 0.18), transparent 46%),
        linear-gradient(180deg, rgba(24,30,38,0.96), rgba(13,17,24,0.94));
    border: 1px solid rgba(var(--accent-rgb), 0.18);
    box-shadow: 0 18px 38px rgba(0,0,0,0.38), 0 0 0 1px rgba(var(--accent-rgb),0.05), inset 0 1px 0 rgba(255,255,255,0.06);
    backdrop-filter: blur(22px) saturate(145%);
    -webkit-backdrop-filter: blur(22px) saturate(145%);
    overflow: visible;
    transition: transform .28s cubic-bezier(.2,.8,.2,1), opacity .22s ease, filter .22s ease, height .22s ease, border-radius .22s ease;
}
.bottom-nav:before,
.bottom-nav:after{
    content: "";
    position: absolute;
    pointer-events: none;
    z-index: -1;
}
.bottom-nav:before{
    inset: -12px 20px auto 20px;
    height: 34px;
    border-radius: 0 0 36px 36px;
    background: radial-gradient(ellipse at center, rgba(var(--accent-rgb),0.20), transparent 68%);
    filter: blur(8px);
}
.bottom-nav:after{
    inset: 0;
    border-radius: inherit;
    background: linear-gradient(180deg, rgba(255,255,255,0.08), transparent 42%);
    z-index: 0;
}
.nav-item{
    position: relative;
    z-index: 1;
    flex: 1;
    max-width: 132px;
    min-width: 62px;
    height: 58px;
    padding: 8px 10px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4px;
    cursor: pointer;
    opacity: .68;
    text-decoration: none;
    color: rgba(255,255,255,0.82);
    border-radius: 28px;
    transition: opacity .22s ease, background .22s ease, color .22s ease, transform .22s ease, box-shadow .22s ease;
}
.nav-item:hover{ opacity: 1; background: rgba(255,255,255,0.05); }
.nav-item.active{
    min-width: 96px;
    opacity: 1;
    color: var(--accent);
    background: linear-gradient(180deg, rgba(var(--accent-rgb),0.24), rgba(var(--accent-rgb),0.11));
    border: 1px solid rgba(var(--accent-rgb),0.20);
    box-shadow: 0 12px 26px rgba(0,0,0,0.24), 0 0 22px rgba(var(--accent-rgb),0.10), inset 0 1px 0 rgba(255,255,255,0.08);
    transform: translateY(-4px);
}
.nav-item.active:before{
    content: "";
    position: absolute;
    inset: -5px;
    border-radius: 32px;
    background: radial-gradient(circle at 50% 0%, rgba(var(--accent-rgb),0.24), transparent 64%);
    z-index: -1;
}
.nav-item svg{
    width: 23px;
    height: 23px;
    stroke: currentColor;
    stroke-width: 2.2;
    fill: none;
    transition: transform .22s ease, stroke .22s ease;
}
.nav-item.active svg{ transform: translateY(-1px); }
.nav-label{
    max-width: 78px;
    color: currentColor;
    font-size: 10px;
    font-weight: 800;
    line-height: 1.1;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
.bottom-nav.nav-hidden{
    transform: translate(-50%, calc(100% + 26px));
    opacity: 0;
    pointer-events: none;
    filter: blur(1px);
}
.bottom-nav.nav-compact{
    height: 66px;
    border-radius: 30px;
    opacity: .96;
}
@media(max-width: 380px){
    .bottom-nav{ width: calc(100% - 18px); padding-inline: 6px; }
    .nav-item{ min-width: 54px; padding-inline: 7px; }
    .nav-item.active{ min-width: 84px; }
    .nav-label{ font-size: 9px; max-width: 62px; }
}
@media(min-width: 992px){
    body{ padding-bottom: 0; }
    .bottom-nav{ display: none !important; }
}

@media (max-width: 768px) {
    .container { padding: 12px; }
    .profile-header { flex-direction: column; text-align: center; }
    .profile-info { text-align: center; }
    .movie-card { width: 120px; }
    .comment-header { flex-direction: column; align-items: flex-start; }
}


/* ========== Professional Profile Redesign v2 ========== */
body{
    min-height:100vh;
    padding-top:84px;
    background:
        radial-gradient(circle at 85% 0%, rgba(var(--accent-rgb),0.16), transparent 34vw),
        radial-gradient(circle at 12% 18%, rgba(255,255,255,0.055), transparent 28vw),
        linear-gradient(180deg, #07070a 0%, var(--bg-primary) 38%, #060607 100%);
}
body:before{
    content:"";
    position:fixed;
    inset:0;
    pointer-events:none;
    z-index:-1;
    background-image:
        linear-gradient(rgba(255,255,255,0.026) 1px, transparent 1px),
        linear-gradient(90deg, rgba(255,255,255,0.022) 1px, transparent 1px);
    background-size:52px 52px;
    mask-image:linear-gradient(to bottom, rgba(0,0,0,.9), transparent 75%);
}
.profile-topbar{
    position:fixed;
    top:0;left:0;right:0;
    background:rgba(7,7,10,0.72);
    border-bottom:1px solid rgba(255,255,255,0.075);
    box-shadow:0 20px 50px rgba(0,0,0,0.22);
    backdrop-filter:blur(22px) saturate(145%);
    -webkit-backdrop-filter:blur(22px) saturate(145%);
}
.profile-topbar .header-inner{height:76px;gap:16px;}
.header-actions-profile{display:flex;align-items:center;gap:10px;flex-wrap:wrap;justify-content:flex-end;}
.ghost-btn{background:rgba(255,255,255,0.045);}
.container{max-width:1240px;padding:28px 20px 36px;}
#toastContainer:empty{display:none;}
.profile-hero{
    position:relative;
    overflow:hidden;
    border:1px solid rgba(var(--accent-rgb),0.22);
    border-radius:34px;
    padding:26px;
    margin-bottom:18px;
    background:
        linear-gradient(135deg, rgba(var(--accent-rgb),0.18), rgba(255,255,255,0.035) 42%, rgba(255,255,255,0.02)),
        rgba(13,13,18,0.78);
    box-shadow:0 30px 80px rgba(0,0,0,0.35), inset 0 1px 0 rgba(255,255,255,0.07);
    isolation:isolate;
}
.profile-hero-bg{
    position:absolute;
    inset:-40% -10% auto auto;
    width:520px;height:520px;
    background:radial-gradient(circle, rgba(var(--accent-rgb),0.28), transparent 62%);
    filter:blur(10px);
    opacity:.75;
    z-index:-1;
}
.profile-hero:before{
    content:"";
    position:absolute;
    inset:0;
    background:linear-gradient(115deg, transparent 0 48%, rgba(255,255,255,0.055) 49%, transparent 60%);
    opacity:.6;
    pointer-events:none;
}
.profile-hero-main{display:grid;grid-template-columns:180px 1fr;gap:28px;align-items:center;position:relative;z-index:1;}
.hero-avatar-card{align-items:center;justify-content:center;padding:18px;border-radius:28px;background:rgba(0,0,0,0.18);border:1px solid rgba(255,255,255,0.07);box-shadow:inset 0 1px 0 rgba(255,255,255,0.06);}
.profile-avatar{width:122px;height:122px;border:4px solid rgba(var(--accent-rgb),0.72);background:linear-gradient(135deg,var(--accent),#fff);box-shadow:0 20px 42px rgba(0,0,0,0.38),0 0 0 10px rgba(var(--accent-rgb),0.08),0 0 38px rgba(var(--accent-rgb),0.24);}
.profile-avatar svg{width:58px;height:58px;stroke:#050506;}
.avatar-actions{margin-top:10px;}
.avatar-btn{background:rgba(255,255,255,0.07);border-color:rgba(255,255,255,0.10);color:rgba(255,255,255,.82);padding:8px 12px;backdrop-filter:blur(10px);}
.avatar-btn:hover{background:var(--accent-glow);box-shadow:0 8px 24px rgba(0,0,0,.25);}
.avatar-btn.danger-soft{color:#ff9c9c;border-color:rgba(255,83,83,.18);background:rgba(255,83,83,.08);}
.profile-kicker{display:inline-flex;align-items:center;gap:8px;color:var(--accent);font-weight:800;font-size:13px;margin-bottom:8px;background:rgba(var(--accent-rgb),0.08);border:1px solid rgba(var(--accent-rgb),0.16);padding:7px 12px;border-radius:999px;}
.live-dot{width:8px;height:8px;border-radius:999px;background:var(--accent);box-shadow:0 0 0 5px rgba(var(--accent-rgb),.12),0 0 16px rgba(var(--accent-rgb),.65);}
.profile-name{font-size:clamp(28px,4vw,46px);line-height:1.1;margin-bottom:10px;letter-spacing:-.03em;}
.verified-chip{display:inline-flex;align-items:center;justify-content:center;width:30px;height:30px;border-radius:999px;background:var(--accent);color:#050506;box-shadow:0 0 24px rgba(var(--accent-rgb),.32);}
.verified-chip svg{width:17px;height:17px;stroke-width:3;}
.profile-username{font-size:14px;color:rgba(255,255,255,.70);margin-bottom:14px;}
.profile-meta-row{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px;}
.profile-meta-row span{font-size:12px;color:rgba(255,255,255,.74);border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.045);padding:7px 11px;border-radius:999px;}
.profile-stats{gap:10px;margin:0;}
.stat-badge{appearance:none;border:1px solid rgba(255,255,255,.08);color:#fff;cursor:pointer;min-width:128px;display:flex;align-items:baseline;justify-content:center;gap:7px;background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(255,255,255,.03));padding:12px 15px;border-radius:20px;transition:.2s ease;box-shadow:inset 0 1px 0 rgba(255,255,255,.055);}
.stat-badge:hover{transform:translateY(-2px);border-color:rgba(var(--accent-rgb),.30);background:rgba(var(--accent-rgb),.09);}
.stat-badge span{font-size:22px;margin:0;color:var(--accent);}
.profile-tabs{position:relative;z-index:2;margin-top:24px;padding:8px;border:1px solid rgba(255,255,255,.08);border-radius:24px;background:rgba(0,0,0,.24);backdrop-filter:blur(14px);overflow-x:auto;scrollbar-width:none;flex-wrap:nowrap;}
.profile-tabs::-webkit-scrollbar{display:none;}
.profile-action-btn{white-space:nowrap;border-radius:18px;padding:11px 15px;background:transparent;border:1px solid transparent;color:rgba(255,255,255,.74);font-weight:800;}
.profile-action-btn:hover{background:rgba(255,255,255,.055);transform:translateY(-1px);}
.profile-action-btn.active{background:var(--accent);color:#050506;border-color:transparent;box-shadow:0 14px 32px rgba(var(--accent-rgb),.20);}
.profile-overview-grid{display:grid;grid-template-columns:minmax(280px,1.8fr) repeat(4,minmax(130px,1fr));gap:14px;margin:0 0 22px;}
.continue-card,.overview-mini-card,.section{border:1px solid rgba(255,255,255,.08);background:linear-gradient(180deg,rgba(255,255,255,.055),rgba(255,255,255,.025));box-shadow:0 22px 48px rgba(0,0,0,.24),inset 0 1px 0 rgba(255,255,255,.055);backdrop-filter:blur(18px);}
.continue-card{border-radius:28px;padding:16px;min-height:164px;}
.overview-card-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:12px;}
.eyebrow{display:block;font-size:11px;color:var(--accent);font-weight:900;margin-bottom:4px;}
.continue-card h3{font-size:19px;line-height:1.2;}
.tiny-link{border:0;background:rgba(var(--accent-rgb),.12);color:var(--accent);padding:8px 12px;border-radius:999px;font-weight:900;cursor:pointer;}
.continue-inner{display:grid;grid-template-columns:78px 1fr;gap:14px;align-items:center;text-decoration:none;color:inherit;}
.continue-inner img{width:78px;aspect-ratio:2/3;object-fit:cover;border-radius:18px;border:1px solid rgba(255,255,255,.10);box-shadow:0 16px 30px rgba(0,0,0,.28);}
.continue-copy{min-width:0;display:flex;flex-direction:column;gap:6px;}
.continue-copy strong{font-size:16px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.continue-copy span,.continue-copy small{color:rgba(255,255,255,.62);font-size:12px;}
.continue-empty{display:flex;align-items:center;gap:12px;color:var(--text-secondary);padding:22px 8px;}
.continue-empty svg{width:28px;height:28px;color:var(--accent);}
.overview-mini-card{appearance:none;border-radius:24px;padding:16px;text-align:inherit;color:#fff;cursor:pointer;display:flex;flex-direction:column;justify-content:space-between;min-height:164px;transition:.2s ease;}
.overview-mini-card:hover{transform:translateY(-4px);border-color:rgba(var(--accent-rgb),.28);background:rgba(var(--accent-rgb),.08);}
.mini-icon{width:42px;height:42px;border-radius:16px;background:rgba(var(--accent-rgb),.12);color:var(--accent);display:flex;align-items:center;justify-content:center;}
.mini-icon svg{width:21px;height:21px;stroke-width:2;}
.mini-label{font-size:12px;color:rgba(255,255,255,.62);font-weight:800;margin-top:10px;}
.overview-mini-card strong{font-size:31px;line-height:1;color:#fff;letter-spacing:-.03em;}
.section{border-radius:30px;padding:24px;margin-bottom:22px;animation:fadeUp .25s ease;}
@keyframes fadeUp{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:translateY(0)}}
.section-title{border-right:0;padding-right:0;margin-bottom:22px;}
.section-title-left{position:relative;font-size:20px;}
.section-title-left:before{content:"";width:9px;height:9px;border-radius:999px;background:var(--accent);box-shadow:0 0 14px rgba(var(--accent-rgb),.8);}
.section-title-left svg{background:rgba(var(--accent-rgb),.10);border:1px solid rgba(var(--accent-rgb),.12);padding:5px;border-radius:13px;width:34px;height:34px;}
.view-all-link{background:rgba(var(--accent-rgb),.10);border:1px solid rgba(var(--accent-rgb),.16);padding:8px 12px;border-radius:999px;font-weight:900;}
.form-group input{background:rgba(0,0,0,.24);border-color:rgba(255,255,255,.08);border-radius:18px;padding:14px 16px;transition:.2s ease;}
.form-group input:focus{box-shadow:0 0 0 4px rgba(var(--accent-rgb),.10);background:rgba(0,0,0,.34);}
.save-btn{border-radius:18px;padding:13px 26px;box-shadow:0 12px 26px rgba(var(--accent-rgb),.18);}
.theme-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;}
.theme-option,.lang-btn{border-radius:18px;background:rgba(0,0,0,.22);border-color:rgba(255,255,255,.08);transition:.2s ease;}
.theme-option:hover,.lang-btn:hover{transform:translateY(-2px);border-color:rgba(var(--accent-rgb),.28);}
.theme-option.active,.lang-btn.active{box-shadow:0 0 0 4px rgba(var(--accent-rgb),.10);background:rgba(var(--accent-rgb),.12);}
.scroll-horizontal{gap:18px;padding:4px 2px 16px;scroll-snap-type:x mandatory;}
.movie-card{width:172px;border-radius:22px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.08);box-shadow:0 18px 34px rgba(0,0,0,.22);scroll-snap-align:start;position:relative;}
.movie-card:hover{transform:translateY(-7px) scale(1.01);box-shadow:0 24px 42px rgba(0,0,0,.32),0 0 0 1px rgba(var(--accent-rgb),.18);}
.movie-poster{border-radius:22px 22px 10px 10px;}
.movie-info{padding:12px;}
.movie-title{font-size:14px;line-height:1.45;}
.progress-bar{height:6px;background:rgba(255,255,255,.10);border-radius:999px;}
.progress-fill{border-radius:999px;box-shadow:0 0 14px rgba(var(--accent-rgb),.55);}
.remove-btn{border:1px solid rgba(255,83,83,.18);background:rgba(255,83,83,.10);border-radius:15px;padding:8px 12px;font-weight:800;}
.comments-scroll{max-height:620px;gap:14px;padding-inline-end:6px;}
.comment-card{border-radius:24px;background:rgba(255,255,255,.045);border:1px solid rgba(255,255,255,.075);box-shadow:0 18px 34px rgba(0,0,0,.18);transition:.2s ease;}
.comment-card:hover{border-color:rgba(var(--accent-rgb),.22);transform:translateY(-2px);}
.comment-avatar-small,.reply-avatar{background:linear-gradient(135deg,var(--accent),#fff);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08);}
.comment-text{font-size:14px;color:rgba(255,255,255,.72);line-height:1.85;}
.reply-badge,.badge{display:inline-flex;align-items:center;gap:4px;background:rgba(var(--accent-rgb),.11);border:1px solid rgba(var(--accent-rgb),.15);color:var(--accent);padding:5px 10px;border-radius:999px;font-size:11px;font-weight:900;}
.badge-warning{background:rgba(255,181,71,.12);border-color:rgba(255,181,71,.2);color:#ffcf7a;}
.reply-list{border-right:0;padding-right:0;border-top-color:rgba(255,255,255,.075);}
.reply-item{background:rgba(0,0,0,.20);border:1px solid rgba(255,255,255,.06);border-radius:18px;}
.section-subtitle{border-right:0;padding-right:0;color:#fff;margin-top:26px;}
.section-subtitle:before{content:"";width:4px;height:20px;background:var(--accent);border-radius:999px;box-shadow:0 0 14px rgba(var(--accent-rgb),.6);}
.empty-state{border:1px dashed rgba(255,255,255,.10);border-radius:24px;background:rgba(255,255,255,.025);padding:46px 20px;}
.btn-danger{display:inline-flex;align-items:center;gap:6px;text-decoration:none;color:#ff9c9c;background:rgba(255,83,83,.10);border:1px solid rgba(255,83,83,.18);border-radius:999px;font-weight:900;}
.btn-sm{padding:7px 10px;font-size:11px;}
.toast{box-shadow:0 14px 36px rgba(0,0,0,.32);background:rgba(18,18,22,.96);}
@media(max-width:1100px){.profile-overview-grid{grid-template-columns:repeat(4,1fr)}.continue-card{grid-column:1/-1}.profile-hero-main{grid-template-columns:160px 1fr}}
@media(max-width:768px){body{padding-top:74px}.profile-topbar .header-inner{height:66px}.header-actions-profile .ghost-btn{display:none}.container{padding:14px 12px 26px}.profile-hero{padding:18px;border-radius:28px}.profile-hero-main{grid-template-columns:1fr;text-align:center;gap:16px}.hero-avatar-card{max-width:260px;margin:0 auto;width:100%}.profile-name{justify-content:center}.profile-meta-row,.profile-stats{justify-content:center}.profile-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));width:100%}.stat-badge{min-width:0;flex-direction:column;gap:2px}.profile-overview-grid{grid-template-columns:repeat(2,1fr);gap:10px}.continue-card{grid-column:1/-1}.overview-mini-card{min-height:132px}.profile-tabs{margin-inline:-2px;border-radius:22px}.profile-action-btn{padding:10px 12px}.section{padding:18px;border-radius:24px}.section-title{align-items:flex-start}.movie-card{width:142px}.comments-scroll{max-height:none}.comment-header{align-items:flex-start}.bottom-nav{z-index:120}}
@media(max-width:460px){.profile-stats{grid-template-columns:1fr 1fr}.profile-overview-grid{grid-template-columns:1fr 1fr}.continue-inner{grid-template-columns:64px 1fr}.continue-inner img{width:64px}.overview-mini-card strong{font-size:26px}.header-actions-profile .logout-btn{padding:8px 11px;font-size:12px}.profile-avatar{width:108px;height:108px}}


/* ===== Reset comments/replies to the stable previous profile layout ===== */
#comments-section .comments-scroll{max-height:500px;overflow-y:auto;display:flex;flex-direction:column;gap:16px;padding-right:4px;padding-inline-end:4px;}
#comments-section .comment-card{background:var(--bg-secondary);border-radius:20px;padding:16px;border:1px solid var(--border-subtle);box-shadow:none;transition:none;transform:none;}
#comments-section .comment-card:hover{border-color:var(--border-subtle);transform:none;box-shadow:none;}
#comments-section .comment-header{display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;margin-bottom:10px;gap:8px;}
#comments-section .comment-user{display:flex;align-items:center;gap:10px;flex-wrap:wrap;}
#comments-section .comment-avatar-small{width:32px;height:32px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;overflow:hidden;box-shadow:none;}
#comments-section .comment-avatar-small img{width:100%;height:100%;object-fit:cover;}
#comments-section .comment-avatar-small svg{width:18px;height:18px;stroke:#000;}
#comments-section .comment-movie{font-weight:600;font-size:14px;color:var(--accent);text-decoration:none;}
#comments-section .comment-date{font-size:11px;color:var(--text-tertiary);}
#comments-section .comment-text{font-size:13px;color:var(--text-secondary);line-height:1.5;margin:8px 0;}
#comments-section .reply-badge{background:rgba(54,255,159,0.15);padding:2px 8px;border-radius:40px;font-size:10px;display:inline-block;color:var(--accent);border:0;font-weight:400;}
#comments-section .reply-list{margin-top:12px;padding-top:12px;border-top:1px solid var(--border-subtle);padding-right:15px;border-right:2px solid var(--accent);}
#comments-section .reply-item{background:var(--bg-tertiary);border-radius:16px;padding:12px;margin-bottom:10px;border:0;}
#comments-section .reply-header{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;margin-bottom:6px;font-size:12px;gap:8px;}
#comments-section .reply-user{display:flex;align-items:center;gap:8px;}
#comments-section .reply-avatar{width:24px;height:24px;border-radius:50%;background:var(--accent);display:flex;align-items:center;justify-content:center;overflow:hidden;box-shadow:none;}
#comments-section .reply-avatar img{width:100%;height:100%;object-fit:cover;}
#comments-section .reply-avatar svg{width:14px;height:14px;stroke:#000;}
#comments-section .reply-parent{color:var(--accent);font-weight:500;}
#comments-section .section-subtitle{font-size:16px;font-weight:600;color:var(--accent);margin:20px 0 12px 0;display:flex;align-items:center;gap:8px;border-right:2px solid var(--accent);padding-right:10px;}
#comments-section .section-subtitle:before{content:none;}
#comments-section .empty-state{text-align:center;padding:50px;color:var(--text-tertiary);border:0;border-radius:0;background:transparent;}
@media(max-width:768px){#comments-section .comments-scroll{max-height:none}#comments-section .comment-header{flex-direction:column;align-items:flex-start;}}

/* v148.42 — selectable theme cards with live logo preview */
.theme-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(225px,1fr));gap:12px}
.theme-option{appearance:none;-webkit-appearance:none;width:100%;min-height:64px;text-align:start;font-family:inherit;color:var(--text-primary);display:flex;align-items:center;gap:10px;padding:10px 12px;background:rgba(0,0,0,.22);border:1px solid rgba(255,255,255,.08);border-radius:18px;cursor:pointer;transition:.2s ease}
.theme-option:hover{transform:translateY(-2px);border-color:rgba(var(--accent-rgb),.34)}
.theme-option.active{border-color:var(--accent);background:rgba(var(--accent-rgb),.12);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.10),0 12px 30px rgba(0,0,0,.22)}
.theme-option .theme-color{width:18px;height:18px;flex:0 0 auto;border-radius:50%;box-shadow:0 0 0 4px rgba(255,255,255,.045),0 0 18px currentColor}
.theme-option .theme-name{font-size:12px;font-weight:900;line-height:1.5}
@media(max-width:560px){.theme-grid{grid-template-columns:1fr}.theme-option{min-height:60px}.theme-logo-preview{width:66px}}

/* v148.61.9.7 — VIP font personalization */
.font-access-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:22px 0 10px;padding:13px 14px;border:1px solid rgba(var(--accent-rgb),.16);border-radius:18px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.08),rgba(255,255,255,.025))}
.font-access-head strong{display:block;font-size:13px}.font-access-head span{display:block;margin-top:3px;color:rgba(255,255,255,.5);font-size:9.5px;line-height:1.7}.font-access-head .theme-vip-badge{margin:0;color:#071019;background:linear-gradient(135deg,var(--accent),#fff);padding:5px 9px;font-size:8px;font-weight:1000;border-radius:999px}
.font-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px;margin-bottom:10px}
.font-option{appearance:none;-webkit-appearance:none;width:100%;min-height:74px;display:flex;align-items:center;justify-content:space-between;gap:10px;text-align:start;color:#fff;padding:11px 13px;border-radius:17px;border:1px solid rgba(255,255,255,.08);background:rgba(0,0,0,.22);cursor:pointer;transition:.18s ease;font-family:var(--bm-font-preview,var(--bm-site-font,inherit))!important}
.font-option:hover{transform:translateY(-2px);border-color:rgba(var(--accent-rgb),.32)}.font-option.active{border-color:var(--accent);background:rgba(var(--accent-rgb),.11);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}.font-option:disabled{opacity:.52;cursor:not-allowed;transform:none}
.font-option-copy{min-width:0}.font-option-copy b{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.font-option-copy small{display:block;margin-top:4px;color:rgba(255,255,255,.45);font:700 9px/1.6 system-ui,sans-serif}.font-option-check{width:28px;height:28px;border-radius:10px;display:grid;place-items:center;flex:0 0 28px;border:1px solid rgba(255,255,255,.09);color:rgba(255,255,255,.45)}.font-option.active .font-option-check{color:#071019;background:var(--accent);border-color:transparent}.font-option-check svg{width:14px;height:14px}.font-option-lock{font-size:9px;color:rgba(255,255,255,.38)}
@media(max-width:560px){.font-grid{grid-template-columns:1fr 1fr}.font-option{min-height:68px;padding:10px}.font-option-copy b{font-size:11px}}@media(max-width:380px){.font-grid{grid-template-columns:1fr}}

/* VIP membership card v148.49 — centered crown, circular day counter, premium glass finish. */
.vip-membership-card{position:relative;overflow:hidden;display:flex;align-items:center;justify-content:space-between;gap:18px;width:min(720px,100%);margin:6px 0 20px;padding:15px 17px;border:1px solid rgba(255,214,112,.34);border-radius:25px;background:linear-gradient(122deg,rgba(40,31,21,.88),rgba(18,18,34,.94) 48%,rgba(15,22,47,.92));box-shadow:inset 0 1px 0 rgba(255,255,255,.12),inset 0 -1px 0 rgba(255,191,58,.07),0 20px 54px rgba(0,0,0,.25),0 0 32px rgba(255,193,61,.07);isolation:isolate}
.vip-membership-card:before{content:"";position:absolute;z-index:-1;inset:-120% auto auto -8%;width:330px;height:330px;border-radius:50%;background:radial-gradient(circle,rgba(255,200,88,.26),rgba(255,200,88,.06) 38%,transparent 69%);pointer-events:none}.vip-membership-card:after{content:"";position:absolute;inset:0;z-index:-1;background:linear-gradient(110deg,transparent 18%,rgba(255,255,255,.07) 42%,transparent 58%);transform:translateX(-115%);animation:vipCardShine 7s ease-in-out infinite;pointer-events:none}@keyframes vipCardShine{0%,68%{transform:translateX(-115%)}82%,100%{transform:translateX(115%)}}
.vip-membership-copy,.vip-membership-time{position:relative;z-index:1}.vip-membership-copy{display:flex;align-items:center;gap:14px;min-width:0}.vip-membership-icon{position:relative;width:66px;height:66px;display:flex;align-items:center;justify-content:center;flex:0 0 66px;padding:0;border-radius:50%;color:#fff8d8;background:linear-gradient(145deg,#ffe497 0%,#ffc247 48%,#f59e0b 100%);border:1px solid rgba(255,244,188,.72);box-shadow:inset 0 2px 1px rgba(255,255,255,.42),inset 0 -8px 14px rgba(161,84,0,.14),0 11px 30px rgba(245,158,11,.24)}.vip-membership-icon:before{content:"";position:absolute;inset:5px;border-radius:50%;border:1px solid rgba(255,255,255,.3)}.vip-membership-icon svg{position:relative;display:block;width:31px;height:31px;margin:0;overflow:visible;fill:currentColor;stroke:none;transform:translateY(1px)}.vip-membership-copy>span:last-child{min-width:0}.vip-membership-copy strong{display:block;font-size:15px;line-height:1.65;color:#fff;letter-spacing:-.02em}.vip-membership-copy strong:after{content:"VIP";display:inline-flex;align-items:center;justify-content:center;margin-inline-start:8px;padding:2px 7px;border:1px solid rgba(99,158,255,.35);border-radius:7px;background:linear-gradient(135deg,rgba(47,124,255,.48),rgba(47,124,255,.18));color:#eaf2ff;font-size:8px;line-height:1.5;vertical-align:middle}.vip-membership-copy span span{display:block;margin-top:3px;font-size:10px;line-height:1.7;color:rgba(255,255,255,.6)}
.vip-membership-time{width:78px;height:78px;display:flex;flex-direction:column;align-items:center;justify-content:center;flex:0 0 78px;text-align:center;white-space:nowrap;border-radius:50%;border:1px solid rgba(255,216,112,.46);background:radial-gradient(circle at 50% 35%,rgba(255,220,128,.18),rgba(255,183,44,.08) 54%,rgba(7,9,18,.54) 74%);box-shadow:inset 0 0 0 5px rgba(255,255,255,.025),0 10px 28px rgba(0,0,0,.24),0 0 24px rgba(255,193,61,.09)}.vip-membership-time b{display:block;margin:0;font-size:28px;line-height:.95;color:#ffd166;text-shadow:0 0 18px rgba(255,209,102,.22)}.vip-membership-time small{display:block;margin:6px 0 0;font-size:8px;line-height:1;color:rgba(255,255,255,.63)}
.request-vip-layout{display:grid;grid-template-columns:minmax(280px,.9fr) minmax(0,1.35fr);gap:18px;align-items:start}.request-vip-form,.request-vip-history{border:1px solid rgba(255,255,255,.075);border-radius:24px;background:rgba(0,0,0,.19);padding:18px}.request-vip-intro{display:flex;gap:12px;align-items:center;margin-bottom:16px;padding:12px;border-radius:18px;background:rgba(var(--accent-rgb),.08);border:1px solid rgba(var(--accent-rgb),.14)}.request-vip-intro svg{width:24px;height:24px;color:var(--accent);flex:0 0 auto}.request-vip-intro strong{display:block;font-size:13px}.request-vip-intro span{display:block;font-size:9.5px;line-height:1.7;color:rgba(255,255,255,.52);margin-top:3px}.request-fields{display:grid;grid-template-columns:1fr 110px;gap:10px}.request-field{display:flex;flex-direction:column;gap:7px;margin-bottom:12px}.request-field.is-wide{grid-column:1/-1}.request-field label{font-size:10px;color:rgba(255,255,255,.58);font-weight:800}.request-field input,.request-field select{width:100%;height:46px;border:1px solid rgba(255,255,255,.09);border-radius:15px;background:rgba(3,5,10,.42);color:#fff;padding:0 13px;font-weight:700;font-size:12px;font-family:inherit;outline:0}.request-field input:focus,.request-field select:focus{border-color:rgba(var(--accent-rgb),.55);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.09)}.request-submit{width:100%;height:46px;border:0;border-radius:16px;color:#05070b;background:linear-gradient(135deg,var(--accent),#fff);font-weight:950;cursor:pointer;box-shadow:0 13px 30px rgba(var(--accent-rgb),.18)}.request-lock-card{padding:24px;text-align:center;border:1px solid rgba(255,255,255,.08);border-radius:22px;background:rgba(0,0,0,.2)}.request-lock-card strong{display:block;font-size:15px}.request-lock-card p{font-size:10px;line-height:1.8;color:rgba(255,255,255,.52);margin:7px 0 14px}.request-lock-card a{display:inline-flex;padding:10px 16px;border-radius:999px;background:var(--accent);color:#05070b;font-weight:950;text-decoration:none}.request-history-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:12px}.request-history-title strong{font-size:13px}.request-history-title span{font-size:9px;color:rgba(255,255,255,.45)}.request-list{display:flex;flex-direction:column;gap:9px}.request-row{display:grid;grid-template-columns:1fr auto;gap:12px;padding:13px;border:1px solid rgba(255,255,255,.065);border-radius:17px;background:rgba(255,255,255,.025)}.request-row-main{min-width:0}.request-row-main strong{display:block;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.request-row-main span{display:block;margin-top:4px;font-size:9px;color:rgba(255,255,255,.46)}.request-status{align-self:start;height:25px;display:inline-flex;align-items:center;padding:0 9px;border-radius:999px;font-size:8.5px;font-weight:950}.request-status.pending{background:rgba(255,193,61,.12);color:#ffd166;border:1px solid rgba(255,193,61,.2)}.request-status.approved,.request-status.answered{background:rgba(54,255,159,.1);color:#76ffc1;border:1px solid rgba(54,255,159,.18)}.request-status.rejected{background:rgba(255,81,101,.1);color:#ff8c9a;border:1px solid rgba(255,81,101,.18)}.request-admin-response{grid-column:1/-1;margin-top:2px;padding:11px 12px;border:1px solid rgba(var(--accent-rgb),.11);border-radius:13px;background:rgba(var(--accent-rgb),.045);font-size:10px;line-height:1.9;color:rgba(255,255,255,.72)}.request-admin-response strong{display:block;margin-bottom:3px;color:var(--accent);font-size:9px}.request-admin-response time{display:block;margin-top:5px;color:rgba(255,255,255,.36);font-size:8.5px}.request-empty{padding:30px 12px;text-align:center;color:rgba(255,255,255,.4);font-size:10px}
@media(max-width:850px){.request-vip-layout{grid-template-columns:1fr}.vip-membership-card{margin-inline:auto}}@media(max-width:520px){.vip-membership-card{gap:10px;padding:12px 13px;border-radius:22px}.vip-membership-copy{gap:10px}.vip-membership-icon{width:52px;height:52px;flex-basis:52px}.vip-membership-icon svg{width:25px;height:25px}.vip-membership-copy strong{font-size:11.5px;line-height:1.55}.vip-membership-copy strong:after{margin-inline-start:5px;padding:1px 5px;font-size:7px}.vip-membership-copy span span{font-size:8.5px;line-height:1.55}.vip-membership-time{width:64px;height:64px;flex-basis:64px}.vip-membership-time b{font-size:22px}.vip-membership-time small{margin-top:4px;font-size:7px}.request-fields{grid-template-columns:1fr}.request-field.is-wide{grid-column:auto}.request-vip-form,.request-vip-history{padding:14px}.request-row{grid-template-columns:minmax(0,1fr) auto}}@media(max-width:390px){.vip-membership-card{padding:11px 10px}.vip-membership-icon{width:46px;height:46px;flex-basis:46px}.vip-membership-icon svg{width:22px;height:22px}.vip-membership-copy strong{font-size:10.5px}.vip-membership-copy span span{font-size:8px}.vip-membership-time{width:58px;height:58px;flex-basis:58px}.vip-membership-time b{font-size:20px}.vip-membership-time small{font-size:6.7px}}

    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">

<style id="bm-avatar-vip-picker-v148-27">
.avatar-vip-upload{border-color:rgba(var(--accent-rgb),.32)!important;background:linear-gradient(135deg,rgba(var(--accent-rgb),.18),rgba(255,255,255,.055))!important;color:#fff!important}
.avatar-upload-locked{opacity:.78;cursor:pointer}.vip-mini-badge{display:inline-flex;align-items:center;justify-content:center;height:18px;padding:0 6px;border-radius:999px;background:linear-gradient(135deg,var(--accent),#fff);color:#050608;font:950 8px/1 system-ui,sans-serif;letter-spacing:.6px}
.avatar-access-note{max-width:255px;text-align:center;font-size:9.5px;line-height:1.75;color:rgba(255,255,255,.48)}.avatar-access-note.is-vip{color:rgba(255,255,255,.68)}
.avatar-picker-modal{position:fixed;inset:0;z-index:2147482500;display:grid;place-items:center;padding:18px;opacity:0;visibility:hidden;transition:.22s}.avatar-picker-modal.is-open{opacity:1;visibility:visible}.avatar-picker-backdrop{position:absolute;inset:0;background:rgba(1,3,8,.82);backdrop-filter:blur(18px)}
.avatar-picker-panel{position:relative;width:min(760px,100%);max-height:min(760px,calc(100dvh - 30px));display:flex;flex-direction:column;overflow:hidden;border:1px solid rgba(255,255,255,.12);border-radius:30px;background:radial-gradient(circle at 15% 0,rgba(var(--accent-rgb),.19),transparent 34%),linear-gradient(155deg,rgba(20,24,36,.985),rgba(7,9,15,.99));box-shadow:0 34px 120px rgba(0,0,0,.72),inset 0 1px 0 rgba(255,255,255,.07);transform:translateY(18px) scale(.97);transition:.24s}.avatar-picker-modal.is-open .avatar-picker-panel{transform:translateY(0) scale(1)}
.avatar-picker-head{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:18px 20px;border-bottom:1px solid rgba(255,255,255,.08)}.avatar-picker-title{display:flex;align-items:center;gap:12px}.avatar-picker-title-icon{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;background:linear-gradient(145deg,var(--accent),#fff);color:#06070a;box-shadow:0 12px 32px rgba(var(--accent-rgb),.26)}.avatar-picker-title-icon svg{width:20px;height:20px}.avatar-picker-title strong{display:block;font-size:15px;color:#fff}.avatar-picker-title span{display:block;margin-top:3px;font-size:10px;color:rgba(255,255,255,.5)}
/* V148.61.9.8: keep the avatar-picker icon optically centered; the generic title span rule must not override its flex layout. */
.avatar-picker-title>.avatar-picker-title-icon{width:42px!important;height:42px!important;min-width:42px!important;min-height:42px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;margin:0!important;padding:0!important;line-height:1!important;overflow:hidden!important;flex:0 0 42px!important}.avatar-picker-title>.avatar-picker-title-icon svg{width:20px!important;height:20px!important;display:block!important;position:static!important;transform:none!important;margin:0!important;flex:0 0 auto!important}.avatar-picker-title>span:not(.avatar-picker-title-icon){display:block;margin-top:0}.avatar-picker-title>span:not(.avatar-picker-title-icon)>span{margin-top:3px}
.avatar-picker-close{width:40px;height:40px;border:1px solid rgba(255,255,255,.1);border-radius:50%;background:rgba(255,255,255,.055);color:#fff;display:grid;place-items:center;cursor:pointer}.avatar-picker-close:hover{color:var(--accent);border-color:rgba(var(--accent-rgb),.35)}.avatar-picker-close svg{width:18px;height:18px}
.avatar-picker-body{overflow:auto;padding:18px 20px 22px}.avatar-picker-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.avatar-preset-form{min-width:0}.avatar-preset-btn{position:relative;width:100%;min-height:150px;padding:12px;border:1px solid rgba(255,255,255,.075);border-radius:22px;background:linear-gradient(145deg,rgba(255,255,255,.06),rgba(255,255,255,.018));color:#fff;cursor:pointer;transition:.2s;overflow:hidden}.avatar-preset-btn:before{content:"";position:absolute;inset:auto -20% -55% -20%;height:85%;background:radial-gradient(circle,rgba(var(--accent-rgb),.22),transparent 65%);pointer-events:none}.avatar-preset-btn:hover{transform:translateY(-3px);border-color:rgba(var(--accent-rgb),.34);box-shadow:0 18px 45px rgba(0,0,0,.28)}.avatar-preset-btn.is-selected{border-color:rgba(var(--accent-rgb),.72);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.1),0 18px 45px rgba(0,0,0,.32)}
.avatar-preset-img{position:relative;width:86px;height:86px;margin:0 auto 10px;border-radius:50%;object-fit:cover;background:#0a0c13;border:3px solid rgba(255,255,255,.12);box-shadow:0 12px 32px rgba(0,0,0,.4)}.avatar-preset-btn.is-selected .avatar-preset-img{border-color:var(--accent)}.avatar-preset-name{position:relative;display:block;font-size:10px;font-weight:850;color:rgba(255,255,255,.75);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.avatar-preset-check{position:absolute;top:10px;right:10px;width:24px;height:24px;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#06070a;opacity:0;transform:scale(.75)}.avatar-preset-btn.is-selected .avatar-preset-check{opacity:1;transform:scale(1)}.avatar-preset-check svg{width:14px;height:14px}
.avatar-picker-foot{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:13px 20px calc(13px + env(safe-area-inset-bottom,0px));border-top:1px solid rgba(255,255,255,.075);background:rgba(4,6,11,.55)}.avatar-picker-foot p{font-size:10px;line-height:1.7;color:rgba(255,255,255,.45)}.avatar-picker-vip-btn{height:38px;padding:0 13px;border-radius:999px;border:1px solid rgba(var(--accent-rgb),.28);background:rgba(var(--accent-rgb),.1);color:var(--accent);font-size:10px;font-weight:900;display:inline-flex;align-items:center;gap:7px;cursor:pointer;white-space:nowrap}
body.avatar-picker-open{overflow:hidden!important}
@media(max-width:680px){.avatar-picker-modal{padding:7px;align-items:end}.avatar-picker-panel{width:100%;max-height:min(82dvh,720px);border-radius:26px 26px 18px 18px;transform:translateY(30px)}.avatar-picker-head{padding:14px}.avatar-picker-body{padding:13px}.avatar-picker-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:9px}.avatar-preset-btn{min-height:124px;padding:9px;border-radius:18px}.avatar-preset-img{width:68px;height:68px}.avatar-picker-foot{padding:11px 13px calc(11px + env(safe-area-inset-bottom,0px));align-items:flex-start}.avatar-picker-foot p{font-size:9px;max-width:62%}.avatar-picker-vip-btn{height:36px;padding:0 10px}}
@media(max-width:390px){.avatar-picker-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.avatar-preset-btn{min-height:132px}.avatar-preset-img{width:76px;height:76px}}
.bm-mp-vip-active-status{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px}.bm-mp-vip-active-badge{display:inline-flex;align-items:center;justify-content:center;min-width:36px;height:23px;padding:0 9px;border-radius:999px;background:rgba(var(--accent-rgb),.16);border:1px solid rgba(var(--accent-rgb),.28);color:var(--accent);font-size:9px;font-weight:950}.bm-mp-vip-active-expiry{font-size:8.5px;font-weight:750;color:rgba(255,255,255,.58)}
</style>


<style id="bm-profile-account-v148610">
/* v148.61.0 — account management, expired VIP renewal and footer attachment */
body.profile-page{min-height:100dvh;display:flex;flex-direction:column}
body.profile-page>.container{width:100%;flex:1 0 auto}
body.profile-page>.bm-global-footer{flex:0 0 auto}
.vip-renewal-card{
    position:relative;
    overflow:hidden;
    display:grid;
    grid-template-columns:auto minmax(0,1fr) auto;
    align-items:center;
    gap:14px;
    width:min(760px,100%);
    margin:8px 0 20px;
    padding:15px 16px;
    border:1px solid rgba(255,151,57,.28);
    border-radius:24px;
    background:
        radial-gradient(circle at 8% 0,rgba(255,148,39,.16),transparent 34%),
        linear-gradient(135deg,rgba(42,22,14,.92),rgba(18,17,25,.96) 50%,rgba(11,20,38,.95));
    box-shadow:0 18px 50px rgba(0,0,0,.25),inset 0 1px 0 rgba(255,255,255,.06);
}
.vip-renewal-card:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(115deg,transparent 25%,rgba(255,255,255,.045),transparent 72%)}
.vip-renewal-icon{position:relative;width:52px;height:52px;display:grid;place-items:center;border-radius:18px;color:#ffb14f;background:linear-gradient(145deg,rgba(255,166,54,.18),rgba(255,112,32,.07));border:1px solid rgba(255,178,83,.22);box-shadow:inset 0 1px 0 rgba(255,255,255,.07)}
.vip-renewal-icon svg{width:24px;height:24px}
.vip-renewal-copy{position:relative;min-width:0;display:flex;flex-direction:column;gap:4px;text-align:start}
.vip-renewal-copy strong{font-size:13.5px;color:#fff;font-weight:950}
.vip-renewal-copy span{font-size:9.8px;line-height:1.85;color:rgba(255,255,255,.56)}
.vip-renewal-btn{position:relative;min-height:42px;padding:0 15px;border-radius:14px;display:inline-flex;align-items:center;justify-content:center;text-decoration:none;color:#17100a;background:linear-gradient(135deg,#ffd07a,#ff982f);font-size:11px;font-weight:950;box-shadow:0 12px 28px rgba(255,145,37,.18);white-space:nowrap;transition:.2s ease}
.vip-renewal-btn:hover{transform:translateY(-2px);filter:brightness(1.04)}

.account-settings-section{position:relative;overflow:hidden;border-color:rgba(var(--accent-rgb),.17)!important;background:radial-gradient(circle at 92% 0,rgba(var(--accent-rgb),.11),transparent 33%),linear-gradient(145deg,rgba(14,18,31,.96),rgba(8,10,18,.98))!important}
.account-settings-section:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(120deg,transparent 28%,rgba(255,255,255,.025),transparent 68%)}
.account-section-title{position:relative;z-index:1;border:0!important;padding:0!important;margin-bottom:18px!important}
.account-section-title .section-title-left{align-items:center}
.account-section-title .section-title-left>span:last-child{display:flex;flex-direction:column;gap:3px}
.account-section-title strong{font-size:16px;color:#fff}
.account-section-title small{font-size:9.5px;font-weight:600;color:rgba(255,255,255,.45)}
.account-section-icon{width:44px;height:44px;display:grid;place-items:center;border-radius:15px;color:var(--accent);background:rgba(var(--accent-rgb),.10);border:1px solid rgba(var(--accent-rgb),.18)}
.account-section-icon svg{width:21px;height:21px}
.account-settings-layout{position:relative;z-index:1;display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:16px;align-items:stretch}
.account-identity-form{padding:17px;border-radius:22px;border:1px solid rgba(255,255,255,.075);background:rgba(0,0,0,.18);box-shadow:inset 0 1px 0 rgba(255,255,255,.025)}
.account-form-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:13px}
.account-settings-section .form-group{margin:0}
.account-settings-section .form-group label{margin-bottom:7px;font-size:10px;font-weight:800;color:rgba(255,255,255,.58)}
.account-settings-section .form-group input{height:49px;padding:0 14px;border-radius:15px;background:rgba(3,6,13,.52);border-color:rgba(255,255,255,.085);font-size:12px;font-weight:750;transition:.2s}
.account-settings-section .form-group input:focus{border-color:rgba(var(--accent-rgb),.52);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.account-field-wide{grid-column:1/-1}
.account-input-prefix{display:flex;align-items:center;direction:ltr;border:1px solid rgba(255,255,255,.085);border-radius:15px;background:rgba(3,6,13,.52);overflow:hidden;transition:.2s}
.account-input-prefix:focus-within{border-color:rgba(var(--accent-rgb),.52);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}
.account-input-prefix>span{height:49px;padding:0 12px;display:grid;place-items:center;color:var(--accent);border-right:1px solid rgba(255,255,255,.07);font-size:13px;font-weight:950}
.account-input-prefix input{border:0!important;box-shadow:none!important;background:transparent!important;border-radius:0!important;direction:ltr}
.account-password-confirm input::placeholder{font-size:9px;color:rgba(255,255,255,.28)}
.account-form-actions{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-top:15px;padding-top:14px;border-top:1px solid rgba(255,255,255,.06)}
.account-form-actions p{max-width:560px;margin:0;font-size:9px;line-height:1.8;color:rgba(255,255,255,.42)}
.account-save-btn{margin:0!important;min-height:43px;padding:0 18px!important;white-space:nowrap;box-shadow:0 12px 28px rgba(var(--accent-rgb),.18)}
.account-security-card{padding:18px;border-radius:22px;border:1px solid rgba(255,255,255,.075);background:radial-gradient(circle at 82% 5%,rgba(var(--accent-rgb),.13),transparent 34%),rgba(0,0,0,.2);display:flex;flex-direction:column;align-items:flex-start;gap:13px}
.account-security-icon{width:48px;height:48px;display:grid;place-items:center;border-radius:16px;color:var(--accent);background:rgba(var(--accent-rgb),.11);border:1px solid rgba(var(--accent-rgb),.18)}
.account-security-icon svg{width:23px;height:23px}
.account-security-card strong{font-size:14px;color:#fff}
.account-security-card p{margin:5px 0 0;font-size:9.5px;line-height:1.85;color:rgba(255,255,255,.48)}
.account-security-link{width:100%;min-height:42px;margin-top:auto;border-radius:14px;border:1px solid rgba(var(--accent-rgb),.2);background:rgba(var(--accent-rgb),.09);color:var(--accent);font-size:10.5px;font-weight:950;cursor:pointer;transition:.2s}
.account-security-link:hover{background:rgba(var(--accent-rgb),.15);transform:translateY(-1px)}

@media(max-width:900px){
    .account-settings-layout{grid-template-columns:1fr}
    .account-security-card{display:grid;grid-template-columns:auto minmax(0,1fr) auto;align-items:center}
    .account-security-link{width:auto;min-width:135px;margin:0}
}
@media(max-width:620px){
    .vip-renewal-card{grid-template-columns:auto minmax(0,1fr);padding:13px;border-radius:21px}
    .vip-renewal-btn{grid-column:1/-1;width:100%}
    .account-form-grid{grid-template-columns:1fr}
    .account-field-wide{grid-column:auto}
    .account-form-actions{align-items:stretch;flex-direction:column}
    .account-save-btn{width:100%}
    .account-security-card{grid-template-columns:auto minmax(0,1fr)}
    .account-security-link{grid-column:1/-1;width:100%}
}
@media(max-width:560px){
    body.profile-page{padding-bottom:0!important}
    body.profile-page .bm-global-footer{margin-bottom:0!important}
    body.profile-page .bm-footer-stage{padding-bottom:calc(88px + env(safe-area-inset-bottom,0px))!important}
    .account-settings-section{padding:15px!important}
    .account-identity-form,.account-security-card{padding:14px;border-radius:19px}
    .account-section-title strong{font-size:14px}
    .account-section-title small{font-size:8.8px}
}
</style>
<link rel="stylesheet" href="/assets/css/bm-profile-v1486193.css?v=1486193">
<link rel="stylesheet" href="/assets/css/bm-profile-mobile-v1486196.css?v=1486196">
<link rel="stylesheet" href="/assets/css/bm-profile-footer-sync-v14861920.css?v=14861920">

</head>
<body class="profile-page" data-theme="<?= htmlspecialchars($currentTheme, ENT_QUOTES, 'UTF-8') ?>" data-theme-access="<?= $themeAccessAllowed ? 'vip' : 'locked' ?>">

<div id="toastContainer"></div>

<div id="avatarPickerModal" class="avatar-picker-modal" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="avatarPickerTitle">
    <button type="button" class="avatar-picker-backdrop" id="avatarPickerBackdrop" aria-label="<?= $currentLanguage === 'fa' ? 'بستن' : 'Close' ?>"></button>
    <section class="avatar-picker-panel">
        <header class="avatar-picker-head">
            <div class="avatar-picker-title">
                <span class="avatar-picker-title-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/><path d="M18 3v4M16 5h4"/></svg></span>
                <span><strong id="avatarPickerTitle"><?= $currentLanguage === 'fa' ? 'انتخاب آواتار بانک مووی' : 'Choose BankMovie Avatar' ?></strong><span><?= $currentLanguage === 'fa' ? 'یک شخصیت آماده انتخاب کن؛ تغییر بلافاصله در پروفایل و Watch Party دیده می‌شود.' : 'Choose a preset; it appears instantly in your profile and Watch Party.' ?></span></span>
            </div>
            <button type="button" class="avatar-picker-close" id="closeAvatarPickerBtn" aria-label="<?= $currentLanguage === 'fa' ? 'بستن' : 'Close' ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg></button>
        </header>
        <div class="avatar-picker-body">
            <div class="avatar-picker-grid">
                <?php $selectedAvatarPath = bm_user_avatar_path($profileAvatarValue); ?>
                <?php foreach($avatarPresets as $presetKey => $preset): ?>
                    <?php $isSelectedAvatar = hash_equals((string)$preset['path'], $selectedAvatarPath); ?>
                    <form method="POST" class="avatar-preset-form">
                        <?= bm_user_csrf_field() ?>
                        <input type="hidden" name="select_preset_avatar" value="1">
                        <input type="hidden" name="preset_avatar" value="<?= htmlspecialchars((string)$presetKey, ENT_QUOTES, 'UTF-8') ?>">
                        <button type="submit" class="avatar-preset-btn <?= $isSelectedAvatar ? 'is-selected' : '' ?>" aria-label="<?= htmlspecialchars($currentLanguage === 'fa' ? (string)$preset['label_fa'] : (string)$preset['label_en'], ENT_QUOTES, 'UTF-8') ?>">
                            <span class="avatar-preset-check"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg></span>
                            <img class="avatar-preset-img" src="/<?= htmlspecialchars((string)$preset['path'], ENT_QUOTES, 'UTF-8') ?>" alt="" loading="lazy">
                            <span class="avatar-preset-name"><?= htmlspecialchars($currentLanguage === 'fa' ? (string)$preset['label_fa'] : (string)$preset['label_en']) ?></span>
                        </button>
                    </form>
                <?php endforeach; ?>
            </div>
        </div>
        <footer class="avatar-picker-foot">
            <p><?= $currentLanguage === 'fa' ? 'آواتارهای آماده برای همه اعضا فعال‌اند. بارگذاری تصویر شخصی از گالری مخصوص اعضای VIP است.' : 'Presets are available to everyone. Custom image upload is reserved for VIP members.' ?></p>
            <?php if($avatarUploadAllowed): ?>
                <label for="avatarUploadInput" class="avatar-picker-vip-btn" id="avatarModalUploadBtn"><span class="vip-mini-badge">VIP</span><?= $currentLanguage === 'fa' ? 'آپلود تصویر خودم' : 'Upload My Image' ?></label>
            <?php else: ?>
                <button type="button" class="avatar-picker-vip-btn" id="avatarModalVipLockedBtn"><span class="vip-mini-badge">VIP</span><?= $currentLanguage === 'fa' ? 'ویژه اعضای VIP' : 'VIP Exclusive' ?></button>
            <?php endif; ?>
        </footer>
    </section>
</div>


<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<div class="container">
    <?php if($message): ?>
        <div class="toast" id="messageToast"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>
    
    <!-- هدر پروفایل / داشبورد سینمایی -->
    <?php
    $displayName = $currentUser['full_name'] ?: $currentUser['username'];
    $profileRole = strtolower(trim((string)($currentUser['role'] ?? 'user')));
    $vipExpiry = trim((string)($currentUser['vip_expires_at'] ?? ''));
    $vipIsActive = in_array($profileRole, ['vip','premium','special'], true)
        && ($vipExpiry === '' || (($vipTs = strtotime($vipExpiry)) !== false && $vipTs > time()));
    $vipRemaining = bm_vip_remaining($currentUser);
    // V148.61.9.8: admin follows the same visible Premium-active state used by the shared header.
    $profileVipEffectiveActive = bm_vip_user_is_admin_role($currentUser) || !empty($vipRemaining['active']);
    $profileVipEffectiveLifetime = bm_vip_user_is_admin_role($currentUser) || !empty($vipRemaining['lifetime']);
    $profileVipEffectiveDays = bm_vip_user_is_admin_role($currentUser) ? null : (int)($vipRemaining['days'] ?? 0);
    $vipExpiryLabel = (!$vipRemaining['active'] || $vipRemaining['lifetime'] || empty($vipRemaining['expires_at']))
        ? ''
        : date('Y/m/d - H:i', strtotime((string)$vipRemaining['expires_at']));
    $vipLastExpiryLabel = $vipNeedsRenewal && $vipLastExpiryTs !== false
        ? date('Y/m/d - H:i', $vipLastExpiryTs)
        : '';
    $roleLabel = $profileRole === 'admin'
        ? ($currentLanguage === 'fa' ? 'مدیر BankMovie' : 'BankMovie Admin')
        : ($vipIsActive
            ? ($currentLanguage === 'fa' ? 'عضو VIP بانک مووی' : 'BankMovie VIP Member')
            : ($currentLanguage === 'fa' ? 'عضو BankMovie' : 'BankMovie Member'));
    $mobileRoleLabel = $profileRole === 'admin'
        ? ($currentLanguage === 'fa' ? 'مدیر اصلی' : 'Main Admin')
        : ($vipRemaining['active'] ? ($currentLanguage === 'fa' ? 'عضو ویژه' : 'VIP Member') : ($currentLanguage === 'fa' ? 'کاربر بانک مووی' : 'BankMovie Member'));
    $mobileVipHref = $vipNeedsRenewal ? '/vip?renew=1&return=%2Fprofile' : '/vip?return=%2Fprofile';
    // v148.61.9.5 — expose every real site theme in the mobile profile.
    $mobileThemeCards = [];
    foreach ($themes as $themeKey => $themeMeta) {
        $mobileThemeCards[$themeKey] = [
            'fa' => (string)($themeMeta['name'] ?? $themeKey),
            'en' => (string)($themeMeta['name_en'] ?? $themeKey),
        ];
    }
    // Keep the selected concept labels for the familiar cards where possible.
    $mobileThemeLabelOverrides = [
        'dark-black' => ['fa'=>'خاکستری مد','en'=>'Modern Gray'],
        'dark-green' => ['fa'=>'پیش‌فرض بانک مووی','en'=>'BankMovie Default'],
        'dark-purple'=> ['fa'=>'بنفش سینمایی','en'=>'Cinema Purple'],
        'dark-cyan'  => ['fa'=>'زمردی تیره','en'=>'Dark Emerald'],
        'dark-orange'=> ['fa'=>'طلایی کلاسیک','en'=>'Classic Gold'],
    ];
    foreach ($mobileThemeLabelOverrides as $themeKey => $labels) {
        if (isset($mobileThemeCards[$themeKey])) $mobileThemeCards[$themeKey] = $labels;
    }

    // The VIP card must describe the privileges that are actually enabled in
    // VIP Manager — no decorative/fake 4K or unlimited-download claims.
    $mobileVipBenefits = [];
    if (function_exists('bm_vip_feature_catalog') && function_exists('bm_vip_feature_enabled')) {
        foreach (bm_vip_feature_catalog() as $featureKey => $featureMeta) {
            if (($featureMeta['group'] ?? '') !== 'benefit' || !bm_vip_feature_enabled((string)$featureKey)) continue;
            $mobileVipBenefits[(string)$featureKey] = $featureMeta;
        }
    }
    $mobileRequestCount = count($userRequests);
    $mobileRequestPendingCount = 0;
    foreach ($userRequests as $mobileRequestRow) {
        if ((string)($mobileRequestRow['status'] ?? 'pending') === 'pending') $mobileRequestPendingCount++;
    }
    $mobileActivityCount = (int)$totalUserCommentsCount + (int)$totalUserRepliesCount;
    ?>

    <?php
    // Prioritize the two paid personalization features on the compact mobile VIP card.
    $mobileVipBenefitPreview = [];
    foreach (['custom_theme','custom_font','ad_free'] as $priorityKey) {
        if (isset($mobileVipBenefits[$priorityKey])) $mobileVipBenefitPreview[$priorityKey] = $mobileVipBenefits[$priorityKey];
    }
    if (count($mobileVipBenefitPreview) < 3) {
        foreach ($mobileVipBenefits as $featureKey => $featureMeta) {
            if (isset($mobileVipBenefitPreview[$featureKey])) continue;
            $mobileVipBenefitPreview[$featureKey] = $featureMeta;
            if (count($mobileVipBenefitPreview) >= 3) break;
        }
    }
?>
    <!-- v148.61.9.6 — clean responsive mobile profile dashboard -->
    <section id="bmMobileProfileOverview" class="bm-mobile-profile-dashboard" aria-label="<?= $currentLanguage === 'fa' ? 'پروفایل موبایل' : 'Mobile profile' ?>">
        <article class="bm-mp-hero bm-mp-clean-hero">
            <div class="bm-mp-avatar-wrap">
                <div class="bm-mp-avatar"><img src="<?= htmlspecialchars(bm_user_avatar_url($profileAvatarValue), ENT_QUOTES, 'UTF-8') ?>" alt=""></div>
                <button type="button" class="bm-mp-avatar-edit" data-avatar-picker-open aria-label="<?= $currentLanguage === 'fa' ? 'تغییر آواتار' : 'Change avatar' ?>">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 7h3l2-3h6l2 3h3v12H4z"/><circle cx="12" cy="13" r="4"/></svg>
                </button>
            </div>
            <div class="bm-mp-hero-copy">
                <div class="bm-mp-name-line"><h1><?= htmlspecialchars($displayName) ?></h1><?php if (bm_vip_user_is_admin_role($currentUser)): ?><span class="bm-mp-verified"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6L9 17l-5-5"/></svg></span><?php endif; ?></div>
                <span class="bm-mp-role"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3 4.5 6v5c0 5 3.2 8 7.5 10 4.3-2 7.5-5 7.5-10V6L12 3Z"/><path d="m9 12 2 2 4-4"/></svg><?= htmlspecialchars($mobileRoleLabel) ?></span>
                <p><?= $currentLanguage === 'fa' ? '✨ خوش آمدید به دنیای بانک مووی' : '✨ Welcome to BankMovie' ?></p>
                <button type="button" class="bm-mp-edit-profile" data-mobile-target="profile-info-section"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z"/></svg><?= $currentLanguage === 'fa' ? 'ویرایش پروفایل' : 'Edit profile' ?></button>
            </div>
        </article>

        <article class="bm-mp-vip-card bm-mp-clean-vip <?= $profileVipEffectiveActive ? 'is-active' : 'is-inactive' ?>">
            <div class="bm-mp-vip-copy">
                <div class="bm-mp-vip-title"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m3 8 4 4 5-7 5 7 4-4-2 10H5L3 8Z"/><path d="M6 21h12"/></svg><h2><?= $currentLanguage === 'fa' ? 'اشتراک ویژه VIP' : 'VIP Membership' ?></h2></div>
                <p><?= $profileVipEffectiveActive ? ($currentLanguage === 'fa' ? 'اشتراک BankMovie VIP فعال است' : 'BankMovie VIP is active') : ($currentLanguage === 'fa' ? 'دسترسی به امکانات اختصاصی فعال‌شده در بانک مووی' : 'Access the premium features enabled in BankMovie') ?></p>
                <?php if($profileVipEffectiveActive): ?>
                    <div class="bm-mp-vip-active-status">
                        <span class="bm-mp-vip-active-badge">VIP</span>
                        <span class="bm-mp-vip-active-expiry"><?= $profileVipEffectiveLifetime ? ($currentLanguage === 'fa' ? 'بدون انقضا' : 'Lifetime') : (($currentLanguage === 'fa' ? 'تاریخ پایان: ' : 'Expires: ') . htmlspecialchars($vipExpiryLabel)) ?></span>
                    </div>
                    <a class="bm-mp-vip-cta" href="/vip?manage=1&return=%2Fprofile"><span><?= $currentLanguage === 'fa' ? 'مدیریت اشتراک' : 'Manage membership' ?></span><?php if(!$profileVipEffectiveLifetime): ?><small><?= number_format((int)$profileVipEffectiveDays) ?> <?= $currentLanguage === 'fa' ? 'روز باقی‌مانده' : 'days left' ?></small><?php endif; ?></a>
                <?php else: ?>
                    <a class="bm-mp-vip-cta" href="<?= htmlspecialchars($mobileVipHref, ENT_QUOTES, 'UTF-8') ?>"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m3 8 4 4 5-7 5 7 4-4-2 10H5L3 8Z"/></svg><?= $vipNeedsRenewal ? ($currentLanguage === 'fa' ? 'تمدید اشتراک ویژه' : 'Renew VIP') : ($currentLanguage === 'fa' ? 'خرید اشتراک ویژه' : 'Get VIP') ?></a>
                <?php endif; ?>
                <?php if($mobileVipBenefitPreview): ?>
                <div class="bm-mp-vip-features bm-mp-vip-features-real">
                    <?php foreach($mobileVipBenefitPreview as $featureKey => $featureMeta): ?>
                    <span data-vip-feature="<?= htmlspecialchars($featureKey, ENT_QUOTES, 'UTF-8') ?>"><i>
                        <?php if($featureKey === 'ad_free'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/></svg>
                        <?php elseif($featureKey === 'custom_theme'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H12a2 2 0 0 1 0-4h3a6 6 0 0 0 0-12Z"/></svg>
                        <?php elseif($featureKey === 'custom_font'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 19 10 5h4l5 14M7 14h10"/></svg>
                        <?php elseif($featureKey === 'content_requests'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 9h8M8 13h5"/></svg>
                        <?php elseif($featureKey === 'watch_party'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="8" cy="9" r="3"/><circle cx="16" cy="9" r="3"/><path d="M2.5 20a5.5 5.5 0 0 1 11 0M10.5 20a5.5 5.5 0 0 1 11 0"/></svg>
                        <?php elseif($featureKey === 'vip_badge'): ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m12 3 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9L12 3Z"/></svg>
                        <?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m12 3 2.6 5.3 5.9.9-4.3 4.1 1 5.8-5.2-2.7-5.2 2.7 1-5.8-4.3-4.1 5.9-.9L12 3Z"/></svg><?php endif; ?>
                    </i><b><?= htmlspecialchars((string)($featureMeta['label'] ?? $featureKey)) ?></b></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
            <div class="bm-mp-vip-art" aria-hidden="true"><span></span><span></span><span class="bm-mp-vip-art-front"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m3 8 4 4 5-7 5 7 4-4-2 10H5L3 8Z"/></svg><b>VIP</b></span></div>
        </article>

        <article class="bm-mp-card bm-mp-clean-group">
            <header class="bm-mp-section-head"><span><h2><?= $currentLanguage === 'fa' ? 'اطلاعات شخصی و حساب' : 'Personal & account' ?></h2><p><?= $currentLanguage === 'fa' ? 'مدیریت اطلاعات و امنیت حساب شما' : 'Manage your account information and security' ?></p></span><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="7" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></i></header>
            <div class="bm-mp-clean-list">
                <button type="button" data-mobile-target="profile-info-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'نام کاربری' : 'Username' ?></b><small dir="ltr">@<?= htmlspecialchars((string)$currentUser['username']) ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="profile-info-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m4 7 8 6 8-6"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'ایمیل و تماس' : 'Email & contact' ?></b><small dir="ltr"><?= htmlspecialchars((string)($currentUser['email'] ?? '')) ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="password-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'رمز عبور' : 'Password' ?></b><small><?= $currentLanguage === 'fa' ? 'تغییر رمز و امنیت حساب' : 'Change password and account security' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="profile-info-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="8" cy="10" r="2"/><path d="M6 16c.7-2 3.3-2 4 0M13 9h5M13 13h5"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'اطلاعات شخصی' : 'Personal information' ?></b><small><?= $currentLanguage === 'fa' ? 'نام نمایشی، شناسه عضو و اطلاعات حساب' : 'Display name, member ID and account details' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
            </div>
        </article>

        <article class="bm-mp-card bm-mp-clean-group">
            <header class="bm-mp-section-head"><span><h2><?= $currentLanguage === 'fa' ? 'فعالیت‌ها و درخواست‌ها' : 'Activity & requests' ?></h2><p><?= $currentLanguage === 'fa' ? 'دسترسی سریع به بخش‌های اصلی حساب' : 'Quick access to account activity' ?></p></span><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 9h8M8 13h5"/></svg></i></header>
            <div class="bm-mp-clean-list">
                <button type="button" data-mobile-target="requests-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="M8 9h8M8 13h5M17 16h3M18.5 14.5v3"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'درخواست فیلم و سریال' : 'Movie & series requests' ?></b><small><?= number_format($mobileRequestCount) ?> <?= $currentLanguage === 'fa' ? 'درخواست' : 'requests' ?><?= $mobileRequestPendingCount ? ' • '.number_format($mobileRequestPendingCount).' '.($currentLanguage === 'fa' ? 'در بررسی' : 'pending') : '' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="watchlist-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l7.78-7.78a5.5 5.5 0 0 0 1.06-8.84Z"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'لیست من' : 'My list' ?></b><small><?= number_format((int)$totalWatchlistCount) ?> <?= $currentLanguage === 'fa' ? 'عنوان ذخیره‌شده' : 'saved titles' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="comments-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'فعالیت‌ها و کامنت‌ها' : 'Activity & comments' ?></b><small><?= number_format((int)$mobileActivityCount) ?> <?= $currentLanguage === 'fa' ? 'تعامل ثبت‌شده' : 'recorded interactions' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
            </div>
        </article>

        <article class="bm-mp-card bm-mp-clean-group bm-mp-clean-settings">
            <header class="bm-mp-section-head"><span><h2><?= $currentLanguage === 'fa' ? 'ظاهر و تنظیمات' : 'Appearance & settings' ?></h2><p><?= $currentLanguage === 'fa' ? 'پوسته، فونت و تنظیمات رابط کاربری' : 'Site theme, font and interface preferences' ?></p></span><i><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H12a2 2 0 0 1 0-4h3a6 6 0 0 0 0-12Z"/></svg></i></header>
            <div class="bm-mp-clean-list">
                <button type="button" data-mobile-target="settings-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3a9 9 0 1 0 0 18h1.5a2.5 2.5 0 0 0 0-5H12a2 2 0 0 1 0-4h3a6 6 0 0 0 0-12Z"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'پوسته سایت' : 'Site theme' ?></b><small><?= htmlspecialchars($currentLanguage === 'fa' ? (string)$themes[$currentTheme]['name'] : (string)$themes[$currentTheme]['name_en']) ?><?= !$themeAccessAllowed ? ' • VIP' : '' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="settings-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 19 10 5h4l5 14M7 14h10"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'فونت سایت' : 'Site font' ?></b><small><?= htmlspecialchars((string)($fontCatalog[$currentFont]['label'] ?? $currentFont), ENT_QUOTES, 'UTF-8') ?><?= !$fontAccessAllowed ? ' • VIP' : '' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
                <button type="button" data-mobile-target="settings-section"><span class="bm-mp-clean-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3a15 15 0 0 1 0 18M12 3a15 15 0 0 0 0 18"/></svg></span><span class="bm-mp-clean-copy"><b><?= $currentLanguage === 'fa' ? 'زبان و تنظیمات' : 'Language & settings' ?></b><small><?= $currentLanguage === 'fa' ? 'فارسی • تنظیمات کامل حساب' : 'English • full account settings' ?></small></span><span class="bm-mp-clean-chevron">‹</span></button>
            </div>
        </article>
    </section>

    <section class="profile-hero" aria-label="<?= $currentLanguage === 'fa' ? 'خلاصه پروفایل' : 'Profile overview' ?>">
        <div class="profile-hero-bg"></div>
        <div class="profile-hero-main">
            <div class="profile-avatar-section hero-avatar-card">
                <div class="profile-avatar">
                    <img src="<?= htmlspecialchars(bm_user_avatar_url($profileAvatarValue), ENT_QUOTES, 'UTF-8') ?>" alt="avatar">
                </div>
                <div class="avatar-actions">
                    <button type="button" class="avatar-btn" id="openAvatarPickerBtn">
                        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/><path d="M18 3v4M16 5h4"/></svg>
                        <?= $currentLanguage === 'fa' ? 'انتخاب آواتار' : 'Choose Avatar' ?>
                    </button>
                    <?php if($avatarUploadAllowed): ?>
                        <label class="avatar-btn avatar-vip-upload" for="avatarUploadInput">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 16V4"/><path d="M7 9l5-5 5 5"/><path d="M5 20h14"/></svg>
                            <?= $currentLanguage === 'fa' ? 'آپلود اختصاصی' : 'Custom Upload' ?>
                            <span class="vip-mini-badge">VIP</span>
                        </label>
                    <?php else: ?>
                        <button type="button" class="avatar-btn avatar-upload-locked" id="avatarVipLockedBtn">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg>
                            <?= $currentLanguage === 'fa' ? 'آپلود اختصاصی' : 'Custom Upload' ?>
                            <span class="vip-mini-badge">VIP</span>
                        </button>
                    <?php endif; ?>
                    <?php if(!empty($profileAvatarValue)): ?>
                        <a href="<?= htmlspecialchars(bm_csrf_url('?remove_avatar=1'), ENT_QUOTES, 'UTF-8') ?>" class="avatar-btn danger-soft" onclick="return confirm('<?= $currentLanguage === 'fa' ? 'حذف آواتار؟' : 'Remove avatar?' ?>')">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            <?= $currentLanguage === 'fa' ? 'حذف' : 'Remove' ?>
                        </a>
                    <?php endif; ?>
                    <?php if($avatarUploadAllowed): ?>
                        <form method="POST" enctype="multipart/form-data" id="avatarForm" style="display:none;">
                            <?= bm_user_csrf_field() ?>
                            <input type="file" name="avatar" id="avatarUploadInput" accept="image/jpeg,image/png,image/webp">
                        </form>
                    <?php endif; ?>
                </div>
                <div class="avatar-access-note <?= $avatarUploadAllowed ? 'is-vip' : 'is-standard' ?>">
                    <?php if($avatarUploadAllowed): ?>
                        <?= $currentLanguage === 'fa' ? 'عضویت VIP فعال: آواتار آماده یا تصویر اختصاصی' : 'VIP active: presets or a custom image' ?>
                    <?php elseif($vipNeedsRenewal): ?>
                        <?= $currentLanguage === 'fa' ? 'اشتراک پایان یافته؛ آواتار اختصاصی تا زمان تمدید به حالت پیش‌فرض برگشته است' : 'Membership expired; the custom avatar is hidden until renewal' ?>
                    <?php else: ?>
                        <?= $currentLanguage === 'fa' ? 'آواتارهای آماده رایگان هستند؛ آپلود تصویر شخصی مخصوص VIP است' : 'Presets are free; custom uploads are VIP only' ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="profile-info hero-copy">
                <div class="profile-kicker">
                    <span class="live-dot"></span>
                    <?= $currentLanguage === 'fa' ? 'داشبورد شخصی شما' : 'Your personal dashboard' ?>
                </div>
                <div class="profile-name">
                    <?= htmlspecialchars($displayName) ?>
                    <?= bm_vip_member_badge_html($currentUser) ?>
                    <?php if (bm_vip_user_is_admin_role($currentUser) && (!function_exists('bm_site_bool') || bm_site_bool('ui_admin_verified_badge_enabled', true))): ?>
                    <span class="verified-chip" title="مدیر تأییدشده بانک مووی" aria-label="مدیر تأییدشده">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6L9 17l-5-5"/></svg>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="profile-username">@<?= htmlspecialchars($currentUser['username']) ?> · <?= htmlspecialchars($roleLabel) ?></div>
                <?php if($profileVipEffectiveActive): ?>
                <div class="vip-membership-card" aria-label="<?= $currentLanguage === 'fa' ? 'وضعیت اشتراک VIP' : 'VIP membership status' ?>">
                    <div class="vip-membership-copy">
                        <span class="vip-membership-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 10H5L3 7Z"/><path d="M6 18h12"/></svg></span>
                        <span><strong><?= $currentLanguage === 'fa' ? 'اشتراک BankMovie VIP فعال است' : 'BankMovie VIP is active' ?></strong><span><?= $profileVipEffectiveLifetime ? ($currentLanguage === 'fa' ? 'عضویت بدون تاریخ انقضا' : 'Membership without expiry') : (($currentLanguage === 'fa' ? 'تاریخ پایان: ' : 'Expires: ') . htmlspecialchars($vipExpiryLabel)) ?></span></span>
                    </div>
                    <div class="vip-membership-time">
                        <?php if($profileVipEffectiveLifetime): ?><b>∞</b><small><?= $currentLanguage === 'fa' ? 'بدون انقضا' : 'Lifetime' ?></small>
                        <?php else: ?><b><?= number_format((int)$profileVipEffectiveDays) ?></b><small><?= $currentLanguage === 'fa' ? 'روز باقی‌مانده' : 'days remaining' ?></small><?php endif; ?>
                    </div>
                </div>
                <?php elseif($vipNeedsRenewal): ?>
                <div class="vip-renewal-card" aria-label="<?= $currentLanguage === 'fa' ? 'تمدید اشتراک VIP' : 'Renew VIP membership' ?>">
                    <span class="vip-renewal-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><path d="M20 12a8 8 0 1 1-2.34-5.66"/><path d="M20 4v6h-6"/><path d="M12 8v5l3 2"/></svg></span>
                    <span class="vip-renewal-copy"><strong><?= $currentLanguage === 'fa' ? 'اشتراک ویژه شما به پایان رسیده' : 'Your VIP membership has expired' ?></strong><span><?= $currentLanguage === 'fa' ? 'پروفایل به حالت عادی برگشته و امکانات ویژه غیرفعال شده‌اند.' : 'Your profile is back to standard mode and premium features are disabled.' ?><?= $vipLastExpiryLabel !== '' ? ' ' . ($currentLanguage === 'fa' ? 'پایان اشتراک: ' : 'Expired: ') . htmlspecialchars($vipLastExpiryLabel) : '' ?></span></span>
                    <a class="vip-renewal-btn" href="/vip?renew=1&return=%2Fprofile"><?= $currentLanguage === 'fa' ? 'تمدید اشتراک' : 'Renew membership' ?></a>
                </div>
                <?php endif; ?>
                <div class="profile-meta-row">
                    <span><?= $currentLanguage === 'fa' ? 'شناسه عضو' : 'Member ID' ?>: #<?= number_format($userId) ?></span>
                    <span><?= $currentLanguage === 'fa' ? 'زبان' : 'Language' ?>: <?= $currentLanguage === 'fa' ? 'فارسی' : 'English' ?></span>
                    <span><?= $currentLanguage === 'fa' ? 'تم' : 'Theme' ?>: <?= htmlspecialchars($currentLanguage === 'fa' ? $themes[$currentTheme]['name'] : $themes[$currentTheme]['name_en']) ?></span>
                </div>
            </div>
        </div>

        <div class="profile-quick-title"><strong><?= $currentLanguage === 'fa' ? 'دسترسی سریع' : 'Quick access' ?></strong><span><?= $currentLanguage === 'fa' ? 'مدیریت حساب و پروفایل' : 'Profile & account controls' ?></span></div>
        <nav class="action-buttons-header profile-tabs" aria-label="<?= $currentLanguage === 'fa' ? 'بخش‌های پروفایل' : 'Profile sections' ?>">
            <button class="profile-action-btn" data-section="profile-info-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                <?= $currentLanguage === 'fa' ? 'حساب' : 'Account' ?>
            </button>
            <button class="profile-action-btn" data-section="watchlist-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                <?= $currentLanguage === 'fa' ? 'نشانه‌ها' : 'Watchlist' ?>
            </button>
            <button class="profile-action-btn" data-section="comments-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $currentLanguage === 'fa' ? 'فعالیت' : 'Activity' ?>
            </button>
            <button class="profile-action-btn" data-section="requests-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h5"/></svg>
                <?= $currentLanguage === 'fa' ? 'درخواست‌ها' : 'Requests' ?>
            </button>
            <button class="profile-action-btn" data-section="settings-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                <?= $currentLanguage === 'fa' ? 'ظاهر' : 'Theme' ?>
            </button>
            <button class="profile-action-btn" data-section="password-section">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <?= $currentLanguage === 'fa' ? 'رمز عبور' : 'Password' ?>
            </button>
        </nav>
    </section>

    <!-- اطلاعات و امنیت حساب -->
    <div id="profile-info-section" class="section account-settings-section">
        <div class="profile-account-intro">
            <div><span class="profile-account-eyebrow"><?= $currentLanguage === 'fa' ? 'مرکز حساب' : 'Account center' ?></span><h1><?= $currentLanguage === 'fa' ? 'اطلاعات حساب کاربری' : 'Account information' ?></h1><p><?= $currentLanguage === 'fa' ? 'جزئیات حساب، امنیت و تنظیمات شخصی خود را مدیریت کنید.' : 'Manage your account details, security and preferences.' ?></p></div>
            <span class="profile-safe-chip"><span></span><?= $currentLanguage === 'fa' ? 'حساب شما امن است' : 'Your account is secure' ?></span>
        </div>
        <div class="section-title account-section-title">
            <div class="section-title-left">
                <span class="account-section-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></span>
                <span><strong><?= $currentLanguage === 'fa' ? 'اطلاعات حساب کاربری' : 'Account information' ?></strong><small><?= $currentLanguage === 'fa' ? 'نام، نام کاربری و ایمیل خود را از یک بخش مدیریت کنید.' : 'Manage your name, username and email in one place.' ?></small></span>
            </div>
        </div>
        <div class="account-settings-layout">
            <form method="POST" class="account-identity-form" autocomplete="on">
                <?= bm_user_csrf_field() ?>
                <div class="account-form-grid">
                    <div class="form-group">
                        <label><?= $currentLanguage === 'fa' ? 'نام نمایشی' : 'Display name' ?></label>
                        <input type="text" name="full_name" maxlength="100" autocomplete="name" value="<?= htmlspecialchars((string)($currentUser['full_name'] ?? ''), ENT_QUOTES, 'UTF-8') ?>" placeholder="<?= $currentLanguage === 'fa' ? 'نامی که در پروفایل دیده می‌شود' : 'Name shown on your profile' ?>">
                    </div>
                    <div class="form-group">
                        <label><?= $currentLanguage === 'fa' ? 'نام کاربری' : 'Username' ?></label>
                        <div class="account-input-prefix"><span>@</span><input type="text" name="username" minlength="3" maxlength="40" autocomplete="username" required value="<?= htmlspecialchars((string)($currentUser['username'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"></div>
                    </div>
                    <div class="form-group account-field-wide">
                        <label><?= $currentLanguage === 'fa' ? 'ایمیل حساب' : 'Account email' ?></label>
                        <input type="email" name="email" maxlength="190" autocomplete="email" inputmode="email" dir="ltr" required value="<?= htmlspecialchars((string)($currentUser['email'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
                    </div>
                    <div class="form-group account-field-wide account-password-confirm">
                        <label><?= $currentLanguage === 'fa' ? 'رمز فعلی برای تأیید تغییر نام کاربری یا ایمیل' : 'Current password to confirm username or email changes' ?></label>
                        <input type="password" name="identity_password" autocomplete="current-password" placeholder="<?= $currentLanguage === 'fa' ? 'فقط هنگام تغییر نام کاربری یا ایمیل لازم است' : 'Required only when changing username or email' ?>">
                    </div>
                </div>
                <div class="account-form-actions">
                    <p><?= $currentLanguage === 'fa' ? 'نام کاربری و ایمیل باید منحصربه‌فرد باشند. برای امنیت، تغییر این دو مورد با رمز فعلی تأیید می‌شود.' : 'Username and email must be unique. Your current password confirms identity changes.' ?></p>
                    <input type="hidden" name="save_profile" value="1">
                    <button type="submit" class="save-btn account-save-btn"><?= $currentLanguage === 'fa' ? 'ذخیره تغییرات حساب' : 'Save account changes' ?></button>
                </div>
            </form>
            <aside class="account-security-card">
                <span class="account-security-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15" r="1"/></svg></span>
                <div><strong><?= $currentLanguage === 'fa' ? 'امنیت حساب' : 'Account security' ?></strong><p><?= $currentLanguage === 'fa' ? 'رمز عبور را از بخش امنیت تغییر بده. بعد از تغییر، نشست‌های قبلی بسته می‌شوند.' : 'Change your password in Security. Previous sessions are closed afterward.' ?></p></div>
                <button type="button" class="account-security-link" onclick="showSection('password-section')"><?= $currentLanguage === 'fa' ? 'تغییر رمز عبور' : 'Change password' ?></button>
            </aside>
        </div>
    </div>
    
    <!-- درخواست فیلم و سریال VIP -->
    <div id="requests-section" class="section" style="display:none;">
        <div class="section-title">
            <div class="section-title-left">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 4h16v16H4z"/><path d="M8 9h8M8 13h5"/></svg>
                <?= $currentLanguage === 'fa' ? 'درخواست فیلم و سریال VIP' : 'VIP Movie & Series Requests' ?>
            </div>
        </div>
        <div class="request-vip-layout">
            <div class="request-vip-form">
                <?php if($requestFeatureAvailable): ?>
                <div class="request-vip-intro"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 3v18M3 12h18"/></svg><span><strong><?= $currentLanguage === 'fa' ? 'درخواست اولویت‌دار اعضای VIP' : 'Priority VIP request' ?></strong><span><?= $currentLanguage === 'fa' ? 'نام دقیق اثر و سال انتشار را بنویس تا تیم محتوا سریع‌تر بررسی کند.' : 'Enter the exact title and year for faster review.' ?></span></span></div>
                <form method="POST" action="/profile#requests-section">
                    <?= bm_user_csrf_field() ?>
                    <div class="request-fields">
                        <div class="request-field is-wide"><label><?= $currentLanguage === 'fa' ? 'نام فیلم یا سریال' : 'Movie or series title' ?></label><input type="text" name="request_title" maxlength="255" required placeholder="مثلاً The Last of Us"></div>
                        <div class="request-field"><label><?= $currentLanguage === 'fa' ? 'نوع محتوا' : 'Type' ?></label><select name="request_type"><option value="movie"><?= $currentLanguage === 'fa' ? 'فیلم' : 'Movie' ?></option><option value="series"><?= $currentLanguage === 'fa' ? 'سریال' : 'Series' ?></option></select></div>
                        <div class="request-field"><label><?= $currentLanguage === 'fa' ? 'سال انتشار' : 'Year' ?></label><input type="text" name="request_year" inputmode="numeric" maxlength="4" placeholder="2026"></div>
                    </div>
                    <input type="hidden" name="submit_movie_request" value="1">
                    <button type="submit" class="request-submit"><?= $currentLanguage === 'fa' ? 'ثبت درخواست VIP' : 'Submit VIP Request' ?></button>
                </form>
                <?php else: ?>
                <div class="request-lock-card"><strong><?= $currentLanguage === 'fa' ? 'این بخش به اشتراک VIP فعال نیاز دارد' : 'Active VIP membership required' ?></strong><p><?= $currentLanguage === 'fa' ? 'با فعال‌شدن اشتراک، درخواست فیلم و سریال با اولویت VIP در همین صفحه در دسترس قرار می‌گیرد.' : 'VIP members can submit priority movie and series requests here.' ?></p><a href="/vip?feature=content_requests&return=%2Fprofile%23requests-section"><?= $currentLanguage === 'fa' ? 'مشاهده پلن‌های VIP' : 'View VIP Plans' ?></a></div>
                <?php endif; ?>
            </div>
            <div class="request-vip-history">
                <div class="request-history-title"><strong><?= $currentLanguage === 'fa' ? 'پیگیری درخواست‌های من' : 'My requests' ?></strong></div>
                <?php if($userRequests): ?><div class="request-list">
                    <?php foreach($userRequests as $req): $requestStatus=bm_profile_request_status_key($req['status'] ?? 'pending'); ?>
                    <article class="request-row">
                        <div class="request-row-main"><strong><?= htmlspecialchars((string)$req['title']) ?></strong><span><?= (($req['type'] ?? 'movie') === 'series' ? ($currentLanguage === 'fa' ? 'سریال' : 'Series') : ($currentLanguage === 'fa' ? 'فیلم' : 'Movie')) ?><?= !empty($req['year']) ? ' · '.htmlspecialchars((string)$req['year']) : '' ?> · <?= htmlspecialchars(date('Y/m/d', strtotime((string)$req['created_at']))) ?></span></div>
                        <span class="request-status <?= htmlspecialchars($requestStatus) ?>"><?= $requestStatus === 'approved' ? ($currentLanguage === 'fa' ? 'پذیرفته شد' : 'Approved') : ($requestStatus === 'rejected' ? ($currentLanguage === 'fa' ? 'رد شد' : 'Rejected') : ($currentLanguage === 'fa' ? 'در حال بررسی' : 'Pending')) ?></span>
                        <?php if(trim((string)($req['admin_response'] ?? '')) !== ''): ?><div class="request-admin-response"><strong><?= $currentLanguage === 'fa' ? 'پاسخ مدیریت' : 'Admin response' ?></strong><?= nl2br(htmlspecialchars((string)$req['admin_response'])) ?><?php if(!empty($req['updated_at'])): ?><time><?= $currentLanguage === 'fa' ? 'آخرین بروزرسانی: ' : 'Updated: ' ?><?= htmlspecialchars(date('Y/m/d H:i', strtotime((string)$req['updated_at']))) ?></time><?php endif; ?></div><?php endif; ?>
                    </article>
                    <?php endforeach; ?>
                </div><?php else: ?><div class="request-empty"><?= $currentLanguage === 'fa' ? 'هنوز درخواستی ثبت نکرده‌ای.' : 'No requests yet.' ?></div><?php endif; ?>
            </div>
        </div>
    </div>

    <!-- تنظیمات ظاهر و زبان -->
    <div id="settings-section" class="section" style="display:none;">
        <div class="section-title">
            <div class="section-title-left">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
                <?= $currentLanguage === 'fa' ? 'تنظیمات ظاهر، فونت و زبان' : 'Theme, Font & Language' ?>
            </div>
        </div>
        <form method="POST" action="/profile#settings-section" id="settingsForm">
            <?= bm_user_csrf_field() ?>

            <div class="bm-appearance-block <?= $appearanceAccessAllowed ? '' : 'is-locked' ?>">
                <div class="bm-appearance-head"><div class="bm-appearance-head-copy"><strong><?= $currentLanguage === 'fa' ? 'پس‌زمینه VIP' : 'VIP Background' ?></strong><span><?= $currentLanguage === 'fa' ? 'پس‌زمینه انتخابی روی صفحه اصلی و Watch Party/چت اعمال می‌شود.' : 'Your selected wallpaper is applied to Home and Watch Party/chat.' ?></span></div><span class="bm-appearance-free">VIP</span></div>
                <?php if(!$appearanceAccessAllowed): ?><div class="bm-appearance-lock-note"><?= $currentLanguage === 'fa' ? 'انتخاب پس‌زمینه فقط با اشتراک ویژه فعال است.' : 'Background selection requires an active VIP membership.' ?> <a href="/vip?feature=appearance&return=%2Fprofile%23settings-section"><?= $currentLanguage === 'fa' ? 'خرید اشتراک' : 'Get VIP' ?></a></div><?php endif; ?>
                <div class="bm-background-grid">
                    <?php foreach($backgroundCatalog as $bgKey => $bgMeta): ?>
                    <button type="button" class="bm-background-option <?= $currentBackground === $bgKey ? 'active' : '' ?>" data-background-option="<?= htmlspecialchars((string)$bgKey, ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $currentBackground === $bgKey ? 'true' : 'false' ?>" <?= $appearanceAccessAllowed ? '' : 'disabled aria-disabled="true"' ?>>
                        <span class="bm-background-preview" data-bg="<?= htmlspecialchars((string)$bgKey, ENT_QUOTES, 'UTF-8') ?>"></span>
                        <span class="bm-background-name"><?= htmlspecialchars((string)($currentLanguage === 'fa' ? ($bgMeta['name'] ?? $bgKey) : ($bgMeta['name_en'] ?? $bgKey)), ENT_QUOTES, 'UTF-8') ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="background_key" id="backgroundInput" value="<?= htmlspecialchars($currentBackground, ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="bm-appearance-block <?= $appearanceAccessAllowed ? '' : 'is-locked' ?>">
                <div class="bm-appearance-head"><div class="bm-appearance-head-copy"><strong><?= $currentLanguage === 'fa' ? 'قاب آواتار VIP' : 'VIP Avatar Frame' ?></strong><span><?= $currentLanguage === 'fa' ? 'قاب روی پروفایل، منوی کاربری و آواتار شما در چت نمایش داده می‌شود.' : 'The frame appears on your profile, user menu and chat avatar.' ?></span></div><span class="bm-appearance-free">VIP</span></div>
                <?php if(!$appearanceAccessAllowed): ?><div class="bm-appearance-lock-note"><?= $currentLanguage === 'fa' ? 'قاب‌های ویژه فقط برای اعضای VIP فعال هستند.' : 'Premium avatar frames are available to VIP members.' ?></div><?php endif; ?>
                <div class="bm-frame-grid">
                    <?php foreach($avatarFrameCatalog as $frameKey => $frameMeta): ?>
                    <button type="button" class="bm-frame-option <?= $currentAvatarFrame === $frameKey ? 'active' : '' ?>" data-frame-option="<?= htmlspecialchars((string)$frameKey, ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $currentAvatarFrame === $frameKey ? 'true' : 'false' ?>" <?= $appearanceAccessAllowed ? '' : 'disabled aria-disabled="true"' ?>>
                        <span class="bm-frame-preview" data-frame="<?= htmlspecialchars((string)$frameKey, ENT_QUOTES, 'UTF-8') ?>">BM</span>
                        <span><?= htmlspecialchars((string)($currentLanguage === 'fa' ? ($frameMeta['name'] ?? $frameKey) : ($frameMeta['name_en'] ?? $frameKey)), ENT_QUOTES, 'UTF-8') ?></span>
                    </button>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="avatar_frame" id="avatarFrameInput" value="<?= htmlspecialchars($currentAvatarFrame, ENT_QUOTES, 'UTF-8') ?>">
            </div>

            <div class="theme-access-head">
                <div><strong><?= $currentLanguage === 'fa' ? 'تم اختصاصی BankMovie' : 'BankMovie custom themes' ?></strong><span><?= $currentLanguage === 'fa' ? 'تغییر رنگ و هویت بصری سایت برای اعضای اشتراک ویژه' : 'Personalize the site colors with an active VIP membership.' ?></span></div>
                <span class="theme-vip-badge">VIP</span>
            </div>
            <?php if(!$themeAccessAllowed): ?>
                <div class="theme-locked-notice">
                    <span class="theme-lock-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
                    <div><strong><?= $currentLanguage === 'fa' ? 'انتخاب تم فقط برای اعضای VIP فعال است' : 'Theme selection is available to VIP members' ?></strong><p><?= $currentLanguage === 'fa' ? 'تم‌های قبلی حساب عادی غیرفعال شده‌اند و سایت با تم پیش‌فرض نمایش داده می‌شود.' : 'Previous standard-account themes are disabled and the default site theme is used.' ?></p></div>
                    <a href="/vip?feature=theme&return=%2Fprofile%23settings-section"><?= $currentLanguage === 'fa' ? 'فعال‌سازی اشتراک ویژه' : 'Get VIP' ?></a>
                </div>
            <?php endif; ?>
            <div class="theme-grid <?= $themeAccessAllowed ? '' : 'is-locked' ?>">
                <?php foreach($themes as $key => $theme): ?>
                    <button type="button" class="theme-option <?= $currentTheme === $key ? 'active' : '' ?>" data-theme="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $currentTheme === $key ? 'true' : 'false' ?>" <?= $themeAccessAllowed ? '' : 'disabled aria-disabled="true"' ?>>
                        <span class="theme-logo-preview" aria-hidden="true"><img src="<?= htmlspecialchars((string)($theme['logo'] ?? $profileBrandLogo), ENT_QUOTES, 'UTF-8') ?>" alt="" data-bm-theme-preview-logo="1"></span>
                        <span class="theme-color" style="background: <?= htmlspecialchars($theme['primary'], ENT_QUOTES, 'UTF-8') ?>;"></span>
                        <span class="theme-name"><?= $currentLanguage === 'fa' ? htmlspecialchars($theme['name']) : htmlspecialchars($theme['name_en']) ?></span>
                        <?php if(!$themeAccessAllowed): ?><span class="theme-option-lock"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9"><rect x="5" y="10" width="14" height="10" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span><?php endif; ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <input type="hidden" name="theme" id="themeInput" value="<?= $themeAccessAllowed ? $currentTheme : 'dark-green' ?>">

            <div class="font-access-head">
                <div><strong><?= $currentLanguage === 'fa' ? 'فونت اختصاصی BankMovie' : 'BankMovie custom font' ?></strong><span><?= $currentLanguage === 'fa' ? 'فونت کل رابط سایت را از فونت‌های داخلی بانک مووی انتخاب کن؛ انتخاب روی همین مرورگر ذخیره می‌شود.' : 'Choose the site font from BankMovie local fonts; the choice is saved in this browser.' ?></span></div>
                <span class="theme-vip-badge">VIP</span>
            </div>
            <?php if(!$fontAccessAllowed): ?>
                <div class="theme-locked-notice">
                    <span class="theme-lock-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="4" y="10" width="16" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
                    <div><strong><?= $currentLanguage === 'fa' ? 'انتخاب فونت فقط برای اعضای VIP فعال است' : 'Font selection is available to VIP members' ?></strong><p><?= $currentLanguage === 'fa' ? 'برای حساب عادی فونت پیش‌فرض مدیریت سایت استفاده می‌شود و فونت سفارشی قبلی اعمال نمی‌شود.' : 'Standard accounts use the admin-defined default font and any custom font is disabled.' ?></p></div>
                    <a href="/vip?feature=font&return=%2Fprofile%23settings-section"><?= $currentLanguage === 'fa' ? 'فعال‌سازی اشتراک ویژه' : 'Get VIP' ?></a>
                </div>
            <?php endif; ?>
            <div class="font-grid <?= $fontAccessAllowed ? '' : 'is-locked' ?>">
                <?php foreach($fontCatalog as $fontKey => $fontMeta): $fontStack = function_exists('bm_site_font_stack_by_id') ? bm_site_font_stack_by_id((string)$fontKey) : 'inherit'; ?>
                    <button type="button" class="font-option <?= $currentFont === $fontKey ? 'active' : '' ?>" data-font="<?= htmlspecialchars((string)$fontKey, ENT_QUOTES, 'UTF-8') ?>" data-font-stack="<?= htmlspecialchars($fontStack, ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $currentFont === $fontKey ? 'true' : 'false' ?>" <?= $fontAccessAllowed ? '' : 'disabled aria-disabled="true"' ?> style="--bm-font-preview:<?= htmlspecialchars($fontStack, ENT_QUOTES, 'UTF-8') ?>">
                        <span class="font-option-copy"><b><?= htmlspecialchars((string)($fontMeta['label'] ?? $fontKey), ENT_QUOTES, 'UTF-8') ?></b><small><?= $currentLanguage === 'fa' ? 'نمونه متن بانک مووی ۱۲۳' : 'BankMovie font preview 123' ?></small></span>
                        <span class="font-option-check" aria-hidden="true"><?php if(!$fontAccessAllowed): ?><span class="font-option-lock">VIP</span><?php else: ?><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m5 12 4 4L19 6"/></svg><?php endif; ?></span>
                    </button>
                <?php endforeach; ?>
            </div>
            <input type="hidden" name="font" id="fontInput" value="<?= htmlspecialchars($fontAccessAllowed ? $currentFont : $defaultFontId, ENT_QUOTES, 'UTF-8') ?>">

            <div class="section-title" style="margin-top:20px;">
                <div class="section-title-left">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 5h18M3 12h18M3 19h18"/></svg>
                    <?= $currentLanguage === 'fa' ? 'زبان' : 'Language' ?>
                </div>
            </div>
            <div class="lang-buttons">
                <button type="button" class="lang-btn <?= $currentLanguage === 'fa' ? 'active' : '' ?>" data-lang="fa">فارسی</button>
                <button type="button" class="lang-btn <?= $currentLanguage === 'en' ? 'active' : '' ?>" data-lang="en">English</button>
            </div>
            <input type="hidden" name="language" id="languageInput" value="<?= $currentLanguage ?>">
            <input type="hidden" name="save_settings" value="1">
            <button type="submit" class="save-btn"><?= $currentLanguage === 'fa' ? 'ذخیره' : 'Save' ?></button>
        </form>
    </div>
    
    <!-- تغییر رمز -->
    <div id="password-section" class="section" style="display:none;">
        <div class="section-title">
            <div class="section-title-left">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
                <?= $currentLanguage === 'fa' ? 'تغییر رمز' : 'Change Password' ?>
            </div>
        </div>
        <form method="POST">
            <?= bm_user_csrf_field() ?>
            <div class="form-group"><label><?= $currentLanguage === 'fa' ? 'رمز فعلی' : 'Current' ?></label><input type="password" name="current_password" required></div>
            <div class="form-group"><label><?= $currentLanguage === 'fa' ? 'رمز جدید' : 'New' ?></label><input type="password" name="new_password" required></div>
            <div class="form-group"><label><?= $currentLanguage === 'fa' ? 'تکرار رمز جدید' : 'Confirm' ?></label><input type="password" name="confirm_password" required></div>
            <input type="hidden" name="change_password" value="1">
            <button type="submit" class="save-btn"><?= $currentLanguage === 'fa' ? 'تغییر رمز' : 'Change' ?></button>
        </form>
    </div>
    
    <!-- نشانه‌ها (واتچ لیست) -->
    <div id="watchlist-section" class="section" style="display:none;">
        <div class="section-title">
            <div class="section-title-left">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
                <?= $currentLanguage === 'fa' ? 'نشانه شده‌ها' : 'Watchlist' ?>
            </div>
            <?php if($totalWatchlistCount > 20): ?>
                <a href="/view_all?type=watchlist" class="view-all-link"><?= $currentLanguage === 'fa' ? 'مشاهده همه' : 'View All' ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            <?php endif; ?>
        </div>
        <?php if($watchlist || $archive1Watchlist): ?>
            <?php if($watchlist): ?>
            <div class="scroll-horizontal">
                <?php foreach($watchlist as $item): ?>
                    <div class="movie-card">
                        <a href="<?= htmlspecialchars(bm_movie_url($item), ENT_QUOTES, 'UTF-8') ?>" style="text-decoration:none; color:inherit;">
                            <img class="movie-poster" src="posters/<?= $item['imdb_code'] ?>.webp" onerror="this.src='<?= $DEFAULT_POSTER ?>'">
                            <div class="movie-info"><div class="movie-title"><?= htmlspecialchars($item['title_fa'] ?: $item['title']) ?></div></div>
                        </a>
                        <button class="remove-btn remove-watchlist" data-imdb="<?= $item['imdb_code'] ?>">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            <?= $currentLanguage === 'fa' ? 'حذف' : 'Remove' ?>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if($archive1Watchlist): ?>
            <div class="scroll-horizontal" style="margin-top:14px;">
                <?php foreach($archive1Watchlist as $item): ?>
                    <div class="movie-card">
                        <a href="<?= htmlspecialchars(bm_profile_arc1_url($item), ENT_QUOTES, 'UTF-8') ?>" style="text-decoration:none; color:inherit;">
                            <img class="movie-poster" src="<?= htmlspecialchars((function_exists('bm_poster_wrap_url') && !empty($item['item_poster'])) ? bm_poster_wrap_url((string)$item['item_poster'], ['type' => (string)($item['item_type'] ?? 'movie'), 'title' => (string)($item['item_title'] ?? $item['item_title_fa'] ?? ''), 'title_fa' => (string)($item['item_title_fa'] ?? ''), 'year' => (string)($item['item_year'] ?? '')]) : ($item['item_poster'] ?: $DEFAULT_POSTER), ENT_QUOTES, 'UTF-8') ?>" onerror="this.src='<?= $DEFAULT_POSTER ?>'">
                            <div class="movie-info">
                                <div class="movie-title"><?= htmlspecialchars($item['item_title_fa'] ?: $item['item_title'] ?: 'آرشیو ۱') ?></div>
                                <div class="movie-title" style="font-size:10px;color:var(--accent);margin-top:4px;">آرشیو ۱</div>
                            </div>
                        </a>
                        <button class="remove-btn remove-archive1-watchlist" data-id="<?= (int)$item['id'] ?>">
                            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                            <?= $currentLanguage === 'fa' ? 'حذف' : 'Remove' ?>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="empty-state"><?= $currentLanguage === 'fa' ? 'لیست نشانه‌ها خالی است' : 'Watchlist is empty' ?></div>
        <?php endif; ?>
    </div>
    <!-- کامنت‌ها و پاسخ‌ها -->
    <div id="comments-section" class="section" style="display:none;">
        <div class="section-title">
            <div class="section-title-left">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
                <?= $currentLanguage === 'fa' ? 'فعالیت‌های من' : 'My Activity' ?>
            </div>
            <?php if($totalUserCommentsCount > 20 || $totalUserRepliesCount > 20): ?>
                <a href="/view_all?type=my_comments" class="view-all-link"><?= $currentLanguage === 'fa' ? 'مشاهده همه' : 'View All' ?> <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M5 12h14M12 5l7 7-7 7"/></svg></a>
            <?php endif; ?>
        </div>
        
        <div class="section-subtitle">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            <?= $currentLanguage === 'fa' ? 'کامنت‌های من' : 'My Comments' ?>
        </div>
        <div class="comments-scroll">
            <?php if($userComments): ?>
                <?php foreach($userComments as $comment): ?>
                    <div class="comment-card">
                        <div class="comment-header">
                            <div class="comment-user">
                                <div class="comment-avatar-small">
                                    <?php if(!empty($comment['commenter_avatar']) && file_exists($comment['commenter_avatar'])): ?>
                                        <img src="<?= htmlspecialchars($comment['commenter_avatar']) ?>">
                                    <?php else: ?>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <span class="comment-movie"><?= htmlspecialchars($comment['commenter_name'] ?: $comment['username']) ?></span>
                                    <?php $commentMovieUrl = !empty($comment['archive1_link']) ? $comment['archive1_link'] : bm_movie_url(['id'=>$comment['movie_id'] ?? 0, 'title'=>$comment['movie_title_en'] ?? ($comment['movie_title'] ?? 'movie')]); ?>
                                    <a href="<?= htmlspecialchars($commentMovieUrl, ENT_QUOTES, 'UTF-8') ?>" class="comment-movie" style="margin-right:8px;"><?= htmlspecialchars($comment['movie_title'] ?: 'فیلم') ?></a>
                                </div>
                            </div>
                            <span class="comment-date"><?= date('Y/m/d H:i', strtotime($comment['created_at'])) ?></span>
                        </div>
                        <div class="comment-text"><?= nl2br(escapeHtml($comment['comment'])) ?></div>
                        <div class="reply-badge"><?= $comment['reply_count'] ?> <?= $currentLanguage === 'fa' ? 'پاسخ' : 'replies' ?></div>
                        <?php if($comment['reply_count'] > 0): ?>
                            <div class="reply-list">
                                <?php
                                $replyTableForComment = !empty($comment['is_archive1_comment']) ? 'archive1_comments' : 'comments';
                                $replyStatusForComment = "(r.status = 'active' OR r.status = 'approved' OR r.status = 1)";
                                $stmtReplies = $pdo->prepare("
                                    SELECT r.*, u.avatar as replier_avatar, u.username as replier_name
                                    FROM {$replyTableForComment} r
                                    LEFT JOIN users u ON r.user_id = u.id
                                    WHERE r.parent_id = ? AND {$replyStatusForComment}
                                    ORDER BY r.created_at ASC LIMIT 5
                                ");
                                $stmtReplies->execute([$comment['id']]);
                                $replies = $stmtReplies->fetchAll();
                                foreach($replies as $reply):
                                ?>
                                    <div class="reply-item">
                                        <div class="reply-header">
                                            <div class="reply-user">
                                                <div class="reply-avatar">
                                                    <?php if(!empty($reply['replier_avatar']) && file_exists($reply['replier_avatar'])): ?>
                                                        <img src="<?= htmlspecialchars($reply['replier_avatar']) ?>">
                                                    <?php else: ?>
                                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                                    <?php endif; ?>
                                                </div>
                                                <span class="reply-parent"><?= htmlspecialchars($reply['replier_name'] ?: $reply['username']) ?></span>
                                            </div>
                                            <span class="comment-date"><?= date('Y/m/d H:i', strtotime($reply['created_at'])) ?></span>
                                        </div>
                                        <div class="comment-text"><?= nl2br(escapeHtml($reply['comment'])) ?></div>
                                    </div>
                                <?php endforeach; ?>
                                <?php if($comment['reply_count'] > 5): ?>
                                    <div class="empty-state" style="padding: 10px; font-size: 12px;"><?= $currentLanguage === 'fa' ? 'و ...' : 'and more ...' ?></div>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= $currentLanguage === 'fa' ? 'هنوز نظری ثبت نکرده‌اید' : 'No comments yet' ?></div>
            <?php endif; ?>
        </div>
        
        <div class="section-subtitle">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 10h18M6 4h12M6 20h12"/></svg>
            <?= $currentLanguage === 'fa' ? 'پاسخ‌های من' : 'My Replies' ?>
        </div>
        <div class="comments-scroll">
            <?php if($userReplies): ?>
                <?php foreach($userReplies as $reply): ?>
                    <div class="comment-card">
                        <div class="comment-header">
                            <div class="comment-user">
                                <div class="comment-avatar-small">
                                    <?php if(!empty($reply['commenter_avatar']) && file_exists($reply['commenter_avatar'])): ?>
                                        <img src="<?= htmlspecialchars($reply['commenter_avatar']) ?>">
                                    <?php else: ?>
                                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <span><?= htmlspecialchars($reply['commenter_name'] ?: $reply['username']) ?></span>
                                    <span style="color:var(--text-tertiary); margin:0 4px;">→</span>
                                    <span class="reply-parent"><?= htmlspecialchars($reply['parent_username'] ?? 'کاربر') ?></span>
                                    <?php $replyMovieUrl = !empty($reply['archive1_link']) ? $reply['archive1_link'] : bm_movie_url(['id'=>$reply['movie_id'] ?? 0, 'title'=>$reply['movie_title_en'] ?? ($reply['movie_title'] ?? 'movie')]); ?>
                                    <a href="<?= htmlspecialchars($replyMovieUrl, ENT_QUOTES, 'UTF-8') ?>" class="comment-movie" style="margin-left:8px;"><?= htmlspecialchars($reply['movie_title'] ?: 'فیلم') ?></a>
                                </div>
                            </div>
                            <span class="comment-date"><?= date('Y/m/d H:i', strtotime($reply['created_at'])) ?></span>
                        </div>
                        <div class="comment-text"><?= nl2br(escapeHtml($reply['comment'])) ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state"><?= $currentLanguage === 'fa' ? 'هنوز پاسخی ثبت نکرده‌اید' : 'No replies yet' ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- فوتر/نوار پایین مطابق / -->
<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('profile.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<script>
// تغییر بخش‌ها
const sections = ['profile-info-section', 'settings-section', 'password-section', 'watchlist-section', 'comments-section', 'requests-section'];
const btns = document.querySelectorAll('.profile-action-btn');
const mobileProfileOverview = document.getElementById('bmMobileProfileOverview');
const mobileProfileMq = window.matchMedia('(max-width: 768px)');

function isMobileProfileView(){ return mobileProfileMq.matches; }
function showMobileOverview(){
    if(!isMobileProfileView()) return;
    sections.forEach(id => {
        const el = document.getElementById(id);
        if(el){ el.style.display='none'; el.classList.remove('bm-mobile-active-detail'); }
    });
    document.body.classList.remove('bm-mobile-detail-open');
    if(mobileProfileOverview) mobileProfileOverview.hidden = false;
    history.replaceState(null,'',location.pathname + location.search);
    window.scrollTo({top:0,behavior:'smooth'});
}
function showSection(sectionId) {
    sections.forEach(id => {
        const el = document.getElementById(id);
        if(el){ el.style.display = 'none'; el.classList.remove('bm-mobile-active-detail'); }
    });
    const target = document.getElementById(sectionId);
    if(target) {
        target.style.display = 'block';
        if(isMobileProfileView()) target.classList.add('bm-mobile-active-detail');
    }
    btns.forEach(btn => btn.classList.remove('active'));
    const activeBtn = Array.from(btns).find(btn => btn.dataset.section === sectionId);
    if(activeBtn) activeBtn.classList.add('active');
    if(isMobileProfileView()){
        document.body.classList.add('bm-mobile-detail-open');
        if(mobileProfileOverview) mobileProfileOverview.hidden = true;
    }
}
btns.forEach(btn => btn.addEventListener('click', () => showSection(btn.dataset.section)));
document.querySelectorAll('[data-overview-target]').forEach(el => {
    el.addEventListener('click', () => {
        const target = el.dataset.overviewTarget;
        if(target) {
            showSection(target);
            const targetEl = document.getElementById(target);
            if(targetEl) targetEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    });
});
document.querySelectorAll('[data-mobile-target]').forEach(el => {
    el.addEventListener('click', () => {
        const target = el.dataset.mobileTarget;
        if(!target) return;
        showSection(target);
        history.replaceState(null,'','#'+target);
        const targetEl=document.getElementById(target);
        if(targetEl) targetEl.scrollIntoView({behavior:'smooth',block:'start'});
    });
});
sections.forEach(id => {
    const section=document.getElementById(id);
    if(!section || section.querySelector('.bm-mobile-detail-back')) return;
    const back=document.createElement('button');
    back.type='button';
    back.className='bm-mobile-detail-back';
    back.innerHTML='<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="m15 18-6-6 6-6"/></svg><span><?= $currentLanguage === 'fa' ? 'بازگشت به پروفایل' : 'Back to profile' ?></span>';
    back.addEventListener('click', showMobileOverview);
    section.insertBefore(back, section.firstChild);
});
const initialSectionFromHash = (location.hash || '').replace('#','');
if(isMobileProfileView() && !sections.includes(initialSectionFromHash)){
    showMobileOverview();
}else{
    showSection(sections.includes(initialSectionFromHash) ? initialSectionFromHash : 'profile-info-section');
}

// کنترل‌های اختصاصی داشبورد موبایل
const mobileThemeForm = document.getElementById('bmMobileThemeForm');
const mobileThemeInput = document.getElementById('bmMobileThemeInput');
document.querySelectorAll('[data-mobile-theme]').forEach(btn => {
    btn.addEventListener('click', function(){
        if(!themeAccessAllowed){
            showToast('<?= $currentLanguage === 'fa' ? 'پوسته‌های اختصاصی فقط برای اعضای VIP فعال هستند' : 'Custom themes are VIP-only' ?>');
            return;
        }
        const selected=this.dataset.mobileTheme||'dark-green';
        if(mobileThemeInput) mobileThemeInput.value=selected;
        document.querySelectorAll('[data-mobile-theme]').forEach(x=>x.classList.toggle('is-active',x===this));
        const desktopTheme=Array.from(document.querySelectorAll('.theme-option')).find(x=>x.dataset.theme===selected);
        if(desktopTheme) desktopTheme.click();
        if(window.BankMovieTheme) window.BankMovieTheme.apply(selected,{persist:false});
        if(mobileThemeForm) mobileThemeForm.submit();
    });
});

// آپلود آواتار

const avatarPickerModal = document.getElementById('avatarPickerModal');
const openAvatarPickerBtn = document.getElementById('openAvatarPickerBtn');
const closeAvatarPickerBtn = document.getElementById('closeAvatarPickerBtn');
const avatarPickerBackdrop = document.getElementById('avatarPickerBackdrop');
function setAvatarPicker(open){
    if(!avatarPickerModal) return;
    avatarPickerModal.classList.toggle('is-open', Boolean(open));
    avatarPickerModal.setAttribute('aria-hidden', open ? 'false' : 'true');
    document.body.classList.toggle('avatar-picker-open', Boolean(open));
    if(open) setTimeout(() => closeAvatarPickerBtn?.focus(), 40);
}
openAvatarPickerBtn?.addEventListener('click', () => setAvatarPicker(true));
document.querySelectorAll('[data-avatar-picker-open]').forEach(btn => btn.addEventListener('click', () => setAvatarPicker(true)));
closeAvatarPickerBtn?.addEventListener('click', () => setAvatarPicker(false));
avatarPickerBackdrop?.addEventListener('click', () => setAvatarPicker(false));
document.addEventListener('keydown', e => { if(e.key === 'Escape' && avatarPickerModal?.classList.contains('is-open')) setAvatarPicker(false); });
document.getElementById('avatarVipLockedBtn')?.addEventListener('click', () => showToast('<?= $currentLanguage === 'fa' ? 'آپلود تصویر اختصاصی فقط برای اعضای VIP فعال است؛ از آواتارهای آماده انتخاب کن.' : 'Custom uploads are VIP only; choose a preset avatar.' ?>'));
document.getElementById('avatarModalVipLockedBtn')?.addEventListener('click', () => showToast('<?= $currentLanguage === 'fa' ? 'برای آپلود تصویر شخصی، عضویت VIP لازم است.' : 'VIP membership is required for custom uploads.' ?>'));
document.getElementById('avatarModalUploadBtn')?.addEventListener('click', () => setAvatarPicker(false));

const avatarInput = document.getElementById('avatarUploadInput');
if(avatarInput) {
    avatarInput.addEventListener('change', function(e) {
        const file = e.target.files[0];
        if(file && file.size > 1048576) {
            showToast('<?= $currentLanguage === 'fa' ? 'حجم بیش از ۱ مگابایت' : 'File > 1MB' ?>');
            avatarInput.value = '';
            return;
        }
        if(file) document.getElementById('avatarForm').submit();
    });
}

// تنظیمات تم و زبان
const themeInput = document.getElementById('themeInput');
const fontInput = document.getElementById('fontInput');
const languageInput = document.getElementById('languageInput');
const backgroundInput = document.getElementById('backgroundInput');
const avatarFrameInput = document.getElementById('avatarFrameInput');
const themeAccessAllowed = <?= $themeAccessAllowed ? 'true' : 'false' ?>;
const fontAccessAllowed = <?= $fontAccessAllowed ? 'true' : 'false' ?>;
let isSaving = false;

function applyProfileFontPreview(stack, id){
    if(!stack) return;
    const root=document.documentElement;
    root.style.setProperty('--bm-user-font-stack', stack);
    root.style.setProperty('--bm-site-font', 'var(--bm-user-font-stack)');
    ['base','header','hero','heading','body','card','button','form','footer','mobile','meta'].forEach(k=>root.style.setProperty('--bm-font-'+k,'var(--bm-user-font-stack)'));
    if(id) root.dataset.bmUserFont=id;
}

document.querySelectorAll('[data-background-option]').forEach(opt => {
    opt.addEventListener('click', function(){
        if(isSaving) return;
        const selected=this.dataset.backgroundOption||'simple';
        document.querySelectorAll('[data-background-option]').forEach(o=>{o.classList.toggle('active',o===this);o.setAttribute('aria-pressed',o===this?'true':'false');});
        if(backgroundInput) backgroundInput.value=selected;
        document.documentElement.dataset.bmBackground=selected;
    });
});
document.querySelectorAll('[data-frame-option]').forEach(opt => {
    opt.addEventListener('click', function(){
        if(isSaving) return;
        const selected=this.dataset.frameOption||'none';
        document.querySelectorAll('[data-frame-option]').forEach(o=>{o.classList.toggle('active',o===this);o.setAttribute('aria-pressed',o===this?'true':'false');});
        if(avatarFrameInput) avatarFrameInput.value=selected;
        document.documentElement.dataset.bmAvatarFrame=selected;
    });
});

document.querySelectorAll('.theme-option').forEach(opt => {
    opt.addEventListener('click', function() {
        if(isSaving) return;
        if(!themeAccessAllowed) { showToast('<?= $currentLanguage === 'fa' ? 'انتخاب تم مخصوص اعضای VIP است' : 'Theme selection is VIP-only' ?>'); return; }
        const selectedTheme = this.dataset.theme || 'dark-green';
        document.querySelectorAll('.theme-option').forEach(o => {
            o.classList.remove('active');
            o.setAttribute('aria-pressed','false');
        });
        this.classList.add('active');
        this.setAttribute('aria-pressed','true');
        themeInput.value = selectedTheme;
        if(window.BankMovieTheme) window.BankMovieTheme.apply(selectedTheme, {persist:false});
        else {
            document.documentElement.dataset.theme = selectedTheme;
            document.body.dataset.theme = selectedTheme;
        }
    });
});
document.querySelectorAll('.font-option').forEach(opt => {
    opt.addEventListener('click', function() {
        if(isSaving) return;
        if(!fontAccessAllowed) { showToast('<?= $currentLanguage === 'fa' ? 'انتخاب فونت مخصوص اعضای VIP است' : 'Font selection is VIP-only' ?>'); return; }
        const selectedFont = this.dataset.font || '<?= htmlspecialchars($defaultFontId, ENT_QUOTES, 'UTF-8') ?>';
        document.querySelectorAll('.font-option').forEach(o => {
            o.classList.remove('active');
            o.setAttribute('aria-pressed','false');
        });
        this.classList.add('active');
        this.setAttribute('aria-pressed','true');
        if(fontInput) fontInput.value = selectedFont;
        applyProfileFontPreview(this.dataset.fontStack || '', selectedFont);
    });
});

document.querySelectorAll('.lang-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        if(isSaving) return;
        document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        languageInput.value = this.dataset.lang;
    });
});
const settingsForm = document.getElementById('settingsForm');
if(settingsForm) {
    settingsForm.addEventListener('submit', function() {
        if(isSaving) return false;
        isSaving = true;
        const selectedTheme = themeAccessAllowed ? (themeInput.value || 'dark-green') : 'dark-green';
        if(window.BankMovieTheme) window.BankMovieTheme.apply(selectedTheme, {persist:themeAccessAllowed});
        const saveBtn = this.querySelector('.save-btn');
        if(saveBtn) {
            saveBtn.disabled = true;
            saveBtn.textContent = '<?= $currentLanguage === 'fa' ? 'در حال ذخیره…' : 'Saving…' ?>';
        }
        return true;
    });
}

// حذف از واتچ لیست
function decrementWatchlistCounter(){
    const stat = document.querySelector('.profile-stats .stat-badge:first-child span');
    if(!stat) return;
    const current = parseInt(String(stat.textContent || '').replace(/[^0-9]/g, ''), 10) || 0;
    stat.textContent = Math.max(0, current - 1);
}

function reloadIfWatchlistEmpty(){
    if(document.querySelectorAll('#watchlist-section .movie-card').length === 0) location.reload();
}

document.querySelectorAll('.remove-watchlist').forEach(btn => {
    btn.addEventListener('click', async function(e) {
        e.preventDefault();
        const imdb = this.dataset.imdb;
        const card = this.closest('.movie-card');
        const formData = new FormData();
        formData.append('action', 'remove');
        formData.append('imdb_code', imdb);
        try {
            const res = await fetch('/ajax_watchlist.php', { method: 'POST', body: formData });
            const data = await res.json();
            if(data.success && card) {
                card.remove();
                decrementWatchlistCounter();
                showToast('<?= $currentLanguage === 'fa' ? 'حذف شد' : 'Removed' ?>');
                reloadIfWatchlistEmpty();
            } else showToast('<?= $currentLanguage === 'fa' ? 'خطا' : 'Error' ?>');
        } catch(e) { showToast('خطا'); }
    });
});

document.querySelectorAll('.remove-archive1-watchlist').forEach(btn => {
    btn.addEventListener('click', async function(e) {
        e.preventDefault();
        const id = this.dataset.id;
        const card = this.closest('.movie-card');
        const formData = new FormData();
        formData.append('action', 'remove');
        formData.append('id', id);
        try {
            const res = await fetch('/ajax_archive1_watchlist.php', { method: 'POST', body: formData });
            const data = await res.json();
            if(data.success && card) {
                card.remove();
                decrementWatchlistCounter();
                showToast('<?= $currentLanguage === 'fa' ? 'حذف شد' : 'Removed' ?>');
                reloadIfWatchlistEmpty();
            } else showToast('<?= $currentLanguage === 'fa' ? 'خطا' : 'Error' ?>');
        } catch(e) { showToast('خطا'); }
    });
});


// فوتر هوشمند مطابق /: در اسکرول رو به پایین مخفی و در برگشت نمایان می‌شود
function setupSmartBottomNav(){
    const nav = document.querySelector('.bottom-nav');
    if(!nav) return;
    let lastY = window.scrollY || 0;
    let ticking = false;
    const minDelta = 12;

    function shouldKeepVisible(){
        const activeElement = document.activeElement;
        return window.innerWidth >= 992 ||
            window.scrollY < 120 ||
            document.body.style.overflow === 'hidden' ||
            (activeElement && ['INPUT','TEXTAREA','SELECT'].includes(activeElement.tagName));
    }

    function update(){
        const y = window.scrollY || 0;
        const diff = y - lastY;
        if(shouldKeepVisible()){
            nav.classList.remove('nav-hidden');
            nav.classList.toggle('nav-compact', y > 220);
            lastY = y;
            ticking = false;
            return;
        }
        if(Math.abs(diff) > minDelta){
            nav.classList.toggle('nav-hidden', diff > 0);
            nav.classList.toggle('nav-compact', y > 220 && diff <= 0);
            lastY = y;
        }
        ticking = false;
    }

    window.addEventListener('scroll', () => {
        if(!ticking){
            window.requestAnimationFrame(update);
            ticking = true;
        }
    }, {passive:true});
    window.addEventListener('resize', update);
    document.addEventListener('focusin', update);
    document.addEventListener('focusout', () => setTimeout(update, 80));
    update();
}
setupSmartBottomNav();

function showToast(msg) {
    const c = document.getElementById('toastContainer');
    c.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast';
    t.textContent = msg;
    c.appendChild(t);
    setTimeout(() => t.remove(), 3000);
}

<?php if($message): ?>if(!document.getElementById('messageToast')) showToast('<?= addslashes($message) ?>');<?php endif; ?>
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
