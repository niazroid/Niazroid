<?php
// ajax.php - نسخه امن‌تر و سازگار با Home جدید
require_once 'config.php';

header('Content-Type: application/json; charset=utf-8');
bm_security_enforce_rate_limit('ajax_public', 360, 300, bm_security_client_ip(), true);
// اگر API فقط داخل همین سایت استفاده می‌شود، CORS عمومی لازم نیست.
// header('Access-Control-Allow-Origin: *');

function json_response(array $payload, int $statusCode = 200): void {
    http_response_code($statusCode);
    echo json_encode(
        $payload,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
    );
    exit;
}

function clean_text($value, int $maxLength = 120): string {
    $value = trim((string)$value);
    $value = preg_replace('/[\x00-\x1F\x7F]/u', '', $value);
    return function_exists('mb_substr') ? mb_substr($value, 0, $maxLength, 'UTF-8') : substr($value, 0, $maxLength);
}

function text_len(string $value): int {
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function int_param(string $key, int $default, int $min, int $max, string $method = 'GET'): int {
    $source = $method === 'POST' ? $_POST : $_GET;
    $value = isset($source[$key]) ? (int)$source[$key] : $default;
    return max($min, min($max, $value));
}

$currentUser = null;
if (!empty($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

$userLang = $_COOKIE['user_lang'] ?? 'fa';
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$action = $_GET['action'] ?? $_POST['action'] ?? '';
$action = clean_text($action, 50);

try {
    switch ($action) {
        case 'get_movies':
            $page = int_param('page', 1, 1, 100000);
            $perPage = 25;
            $offset = ($page - 1) * $perPage;

            $type = clean_text($_GET['type'] ?? 'all', 30);
            $year = clean_text($_GET['year'] ?? 'all', 20);
            $rating = clean_text($_GET['rating'] ?? 'all', 20);
            $sort = clean_text($_GET['sort'] ?? 'year_desc', 30);
            $search = clean_text($_GET['search'] ?? '', 100);
            $genre = clean_text($_GET['genre'] ?? '', 160);
            $country = clean_text($_GET['country'] ?? '', 100);
            $dubType = clean_text($_GET['dub_type'] ?? 'all', 20);
            $actor = clean_text($_GET['actor'] ?? '', 100);

            $allowedTypes = ['all', 'movie', 'series', 'animation', 'tvSeries', 'tvMiniSeries'];
            if (!in_array($type, $allowedTypes, true)) {
                $type = 'all';
            }

            $allowedDubTypes = ['all', 'dubbed', 'softsub'];
            if (!in_array($dubType, $allowedDubTypes, true)) {
                $dubType = 'all';
            }

            $where = [];
            $params = [];

            if ($type !== 'all') {
                if ($type === 'series') {
                    $where[] = "(m.type = 'tvSeries' OR m.type = 'tvMiniSeries')";
                } elseif ($type === 'animation') {
                    $where[] = "(FIND_IN_SET('Animation', REPLACE(m.genres, ', ', ',')) OR FIND_IN_SET('Kids', REPLACE(m.genres, ', ', ',')))";
                } else {
                    $where[] = "m.type = ?";
                    $params[] = $type;
                }
            }

            if ($year !== 'all' && is_numeric($year)) {
                $yearInt = (int)$year;
                if ($yearInt >= 1888 && $yearInt <= ((int)date('Y') + 5)) {
                    $where[] = "m.year = ?";
                    $params[] = $yearInt;
                }
            }

            if ($rating !== 'all' && is_numeric($rating)) {
                $ratingFloat = max(0, min(10, (float)$rating));
                $where[] = "m.imdb_rate >= ?";
                $params[] = $ratingFloat;
            }

            if ($search !== '') {
                $where[] = "(m.title LIKE ? OR m.title_fa LIKE ? OR m.imdb_code LIKE ? OR m.actors LIKE ? OR m.director LIKE ?)";
                $searchTerm = "%{$search}%";
                array_push($params, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
            }

            // پشتیبانی از چند ژانر با کاما. فاصله‌های بعد از کاما هم هندل می‌شود.
            if ($genre !== '') {
                $genresArray = array_slice(array_filter(array_map('trim', explode(',', $genre))), 0, 10);
                $genreConditions = [];
                foreach ($genresArray as $g) {
                    $g = clean_text($g, 40);
                    if ($g !== '') {
                        $genreConditions[] = "FIND_IN_SET(?, REPLACE(m.genres, ', ', ','))";
                        $params[] = $g;
                    }
                }
                if ($genreConditions) {
                    $where[] = "(" . implode(" OR ", $genreConditions) . ")";
                }
            }

            if ($country !== '') {
                $where[] = "m.country = ?";
                $params[] = $country;
            }

            if ($actor !== '') {
                $where[] = "m.actors LIKE ?";
                $params[] = "%{$actor}%";
            }

            if ($dubType === 'dubbed') {
                $where[] = "EXISTS (SELECT 1 FROM dubbed_links dl WHERE dl.movie_id = m.id)";
            } elseif ($dubType === 'softsub') {
                $where[] = "EXISTS (SELECT 1 FROM softsub_links sl WHERE sl.movie_id = m.id)";
            }

            $sortMap = [
                'year_asc' => 'm.year ASC, m.id ASC',
                'year_desc' => 'm.year DESC, m.id DESC',
                'rating_desc' => 'm.imdb_rate DESC, m.imdb_votes DESC',
                'title_asc' => 'm.title ASC',
                'updated_desc' => 'm.updated_at DESC, m.id DESC',
            ];
            $orderBy = $sortMap[$sort] ?? $sortMap['year_desc'];

            $whereSql = $where ? "WHERE " . implode(" AND ", $where) : "";

            $sql = "
                SELECT m.*,
                    (SELECT COUNT(*) FROM softsub_links WHERE movie_id = m.id) AS soft_count,
                    (SELECT COUNT(*) FROM dubbed_links WHERE movie_id = m.id) AS dub_count
                FROM movies m
                {$whereSql}
                ORDER BY {$orderBy}
                LIMIT {$perPage} OFFSET {$offset}
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $movies = $stmt->fetchAll();

            $countSql = "SELECT COUNT(*) FROM movies m {$whereSql}";
            $stmt = $pdo->prepare($countSql);
            $stmt->execute($params);
            $total = (int)$stmt->fetchColumn();

            json_response([
                'success' => true,
                'data' => [
                    'data' => $movies,
                    'total' => $total,
                    'page' => $page,
                    'per_page' => $perPage,
                    'last_page' => (int)ceil($total / $perPage),
                ]
            ]);
            break;

        case 'search':
            $term = clean_text($_GET['term'] ?? '', 80);
            $limit = 25;

            if (text_len($term) < 2) {
                json_response(['success' => true, 'data' => []]);
            }

            // یکسان‌سازی حروف فارسی/عربی تا «ی/ي» و «ک/ك» باعث خراب‌شدن جستجو نشوند.
            $normalizedTerm = strtr($term, [
                'ي' => 'ی', 'ى' => 'ی', 'ك' => 'ک',
                'ۀ' => 'ه', 'ة' => 'ه', 'ؤ' => 'و',
                'إ' => 'ا', 'أ' => 'ا', 'ٱ' => 'ا',
            ]);
            $normalizedTerm = preg_replace('/[\x{064B}-\x{065F}\x{0670}]/u', '', $normalizedTerm) ?? $normalizedTerm;
            $normalizedTerm = preg_replace('/[\x{200C}\x{200D}]+/u', ' ', $normalizedTerm) ?? $normalizedTerm;
            $normalizedTerm = trim(preg_replace('/\s+/u', ' ', $normalizedTerm) ?? $normalizedTerm);

            $arabicVariant = strtr($normalizedTerm, ['ی' => 'ي', 'ک' => 'ك']);
            $compactVariant = preg_replace('/\s+/u', '', $normalizedTerm) ?? $normalizedTerm;
            $variants = array_values(array_unique(array_filter([
                $term,
                $normalizedTerm,
                $arabicVariant,
                $compactVariant,
            ], static fn($value) => $value !== '')));

            $fields = ['title', 'title_fa', 'imdb_code', 'actors', 'director'];
            $where = [];
            $params = [];
            foreach ($fields as $field) {
                foreach ($variants as $variant) {
                    $where[] = "{$field} LIKE ?";
                    $params[] = "%{$variant}%";
                }
            }

            $primary = "%{$normalizedTerm}%";
            $sql = "
                SELECT id, title, title_fa, imdb_code, year, imdb_rate, type
                FROM movies
                WHERE " . implode(' OR ', $where) . "
                ORDER BY
                    CASE
                        WHEN title_fa LIKE ? THEN 1
                        WHEN title LIKE ? THEN 2
                        WHEN imdb_code LIKE ? THEN 3
                        ELSE 4
                    END,
                    year DESC
                LIMIT {$limit}
            ";
            $params[] = $primary;
            $params[] = $primary;
            $params[] = $primary;

            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'search_movies_for_slider':
            $term = clean_text($_GET['term'] ?? '', 80);
            $limit = 15;

            if (text_len($term) < 2) {
                json_response(['success' => true, 'data' => []]);
            }

            $stmt = $pdo->prepare("
                SELECT id, title, title_fa, year, imdb_code
                FROM movies
                WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ?
                ORDER BY
                    CASE
                        WHEN title LIKE ? THEN 1
                        WHEN title_fa LIKE ? THEN 2
                        WHEN imdb_code LIKE ? THEN 3
                        ELSE 4
                    END,
                    year DESC
                LIMIT {$limit}
            ");
            $searchTerm = "%{$term}%";
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_stats':
            $stmt = $pdo->query("
                SELECT
                    (SELECT COUNT(*) FROM movies) AS total,
                    (SELECT COUNT(*) FROM movies WHERE type = 'movie') AS movies,
                    (SELECT COUNT(*) FROM movies WHERE type = 'tvSeries' OR type = 'tvMiniSeries') AS series
            ");
            json_response(['success' => true, 'data' => $stmt->fetch()]);
            break;

        case 'get_new_releases':
            $limit = int_param('limit', 25, 1, 100);
            $stmt = $pdo->prepare("SELECT * FROM movies WHERE year >= YEAR(CURRENT_DATE)-2 AND year > 0 ORDER BY year DESC, id DESC LIMIT {$limit}");
            $stmt->execute();
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_top_rated':
            $type = clean_text($_GET['type'] ?? 'movie', 30);
            $limit = int_param('limit', 25, 1, 100);

            if ($type === 'movie') {
                $stmt = $pdo->prepare("SELECT * FROM movies WHERE type='movie' AND imdb_rate>=6.5 ORDER BY imdb_rate DESC, imdb_votes DESC LIMIT {$limit}");
            } else {
                $stmt = $pdo->prepare("SELECT * FROM movies WHERE (type='tvSeries' OR type='tvMiniSeries') AND imdb_rate>=6.5 ORDER BY imdb_rate DESC, imdb_votes DESC LIMIT {$limit}");
            }
            $stmt->execute();
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_dubbed':
            $limit = int_param('limit', 25, 1, 100);
            $stmt = $pdo->prepare("SELECT DISTINCT m.* FROM movies m INNER JOIN dubbed_links d ON m.id=d.movie_id ORDER BY m.imdb_rate DESC LIMIT {$limit}");
            $stmt->execute();
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_admin_picks':
            $limit = int_param('limit', 25, 1, 100);
            $stmt = $pdo->prepare("SELECT m.* FROM admin_picks ap JOIN movies m ON ap.movie_id=m.id ORDER BY ap.pick_order ASC LIMIT {$limit}");
            $stmt->execute();
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_updated':
            $limit = int_param('limit', 25, 1, 100);
            $stmt = $pdo->prepare("SELECT * FROM movies WHERE updated_at > DATE_SUB(NOW(), INTERVAL 30 DAY) ORDER BY updated_at DESC, id DESC LIMIT {$limit}");
            $stmt->execute();
            json_response(['success' => true, 'data' => $stmt->fetchAll()]);
            break;

        case 'get_top_user_rated':
            $limit = int_param('limit', 25, 1, 100);
            $stmt = $pdo->prepare("
                SELECT m.*, COALESCE(r.avg_rating,0) AS user_rating, COALESCE(r.total_votes,0) AS total_votes
                FROM movies m
                LEFT JOIN movie_ratings r ON m.id=r.movie_id
                WHERE COALESCE(r.total_votes,0)>0
                ORDER BY r.avg_rating DESC, r.total_votes DESC
                LIMIT {$limit}
            ");
            $stmt->execute();
            $movies = $stmt->fetchAll();

            if (!$movies) {
                $stmt = $pdo->prepare("
                    SELECT m.*, AVG(c.rating) AS user_rating, COUNT(c.id) AS total_votes
                    FROM movies m
                    INNER JOIN comments c ON m.id=c.movie_id
                    WHERE c.rating>0 AND c.status='active'
                    GROUP BY m.id
                    ORDER BY AVG(c.rating) DESC, COUNT(c.id) DESC
                    LIMIT {$limit}
                ");
                $stmt->execute();
                $movies = $stmt->fetchAll();
            }

            json_response(['success' => true, 'data' => $movies]);
            break;

        default:
            json_response(['success' => false, 'error' => 'action not found'], 404);
    }
} catch (Throwable $e) {
    error_log("ajax.php error: " . $e->getMessage());
    json_response(['success' => false, 'error' => 'server error'], 500);
}
?>