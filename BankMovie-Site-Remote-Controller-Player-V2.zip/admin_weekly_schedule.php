<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/weekly_schedule.php';
require_once __DIR__ . '/includes/public_assets.php';

if (!bm_weekly_schedule_ensure($pdo)) {
    http_response_code(500);
    exit('ساخت جدول برنامه هفتگی انجام نشد. دسترسی دیتابیس را بررسی کنید.');
}
admin_enforce_csrf();

function bm_ws_e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function bm_ws_cut(string $value, int $length): string {
    $value = trim(preg_replace('/\s+/u', ' ', $value) ?? $value);
    return function_exists('mb_substr') ? mb_substr($value, 0, $length, 'UTF-8') : substr($value, 0, $length);
}
function bm_ws_safe_poster(string $url): string {
    $url = trim($url);
    if ($url === '') return '';
    if (str_starts_with($url, '/') && !str_starts_with($url, '//')) return bm_ws_cut($url, 1600);
    $parts = @parse_url($url);
    if (!is_array($parts) || !in_array(strtolower((string)($parts['scheme'] ?? '')), ['http','https'], true) || empty($parts['host'])) return '';
    return bm_ws_cut($url, 1600);
}
function bm_ws_redirect(string $msg, string $type = 'ok'): never {
    header('Location: /admin_weekly_schedule.php?' . http_build_query([$type => $msg]));
    exit;
}

$days = bm_weekly_schedule_days();
$archives = ['archive1','archive2','archive3','archive4','manual'];

if (isset($_GET['ajax']) && $_GET['ajax'] === 'local_search') {
    header('Content-Type: application/json; charset=utf-8');
    $q = bm_ws_cut((string)($_GET['q'] ?? ''), 100);
    if (mb_strlen($q, 'UTF-8') < 2) {
        echo json_encode(['status'=>'success','movies'=>[]], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
    }
    try {
        $like = '%' . $q . '%';
        $stmt = $pdo->prepare("SELECT id, imdb_code, title, title_fa, year, type
            FROM movies
            WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ?
            ORDER BY CASE WHEN title = ? OR title_fa = ? THEN 0 ELSE 1 END, year DESC, id DESC
            LIMIT 24");
        $stmt->execute([$like,$like,$like,$q,$q]);
        $movies = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $imdb = trim((string)($row['imdb_code'] ?? ''));
            $poster = '';
            if ($imdb !== '') {
                foreach (['webp','jpg','jpeg','png'] as $ext) {
                    if (is_file(__DIR__ . '/posters/' . $imdb . '.' . $ext)) { $poster = '/posters/' . $imdb . '.' . $ext; break; }
                }
            }
            $movies[] = [
                'id' => (string)$row['id'],
                'title' => (string)($row['title'] ?? ''),
                'title_fa' => (string)($row['title_fa'] ?? ''),
                'year' => (string)($row['year'] ?? ''),
                'type' => (string)($row['type'] ?? 'movie'),
                'poster' => $poster,
                'target_url' => bm_movie_url($row),
                'source_archive' => 'archive2',
            ];
        }
        echo json_encode(['status'=>'success','movies'=>$movies], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); exit;
    } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['status'=>'error','message'=>'جستجوی آرشیو ۲ انجام نشد.'], JSON_UNESCAPED_UNICODE); exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string)($_POST['action'] ?? '');
    try {
        if ($action === 'save_settings') {
            $stmt = $pdo->prepare("UPDATE weekly_schedule_settings SET
                is_enabled=?, title_fa=?, title_en=?, subtitle_fa=?, subtitle_en=?, show_empty_days=?, default_day_mode=? WHERE id=1");
            $stmt->execute([
                isset($_POST['is_enabled']) ? 1 : 0,
                bm_ws_cut((string)($_POST['title_fa'] ?? ''), 120) ?: 'جدول پخش هفتگی',
                bm_ws_cut((string)($_POST['title_en'] ?? ''), 120) ?: 'Weekly Release Schedule',
                bm_ws_cut((string)($_POST['subtitle_fa'] ?? ''), 255),
                bm_ws_cut((string)($_POST['subtitle_en'] ?? ''), 255),
                isset($_POST['show_empty_days']) ? 1 : 0,
                in_array((string)($_POST['default_day_mode'] ?? 'today'), ['today','first'], true) ? (string)$_POST['default_day_mode'] : 'today',
            ]);
            bm_ws_redirect('تنظیمات جدول هفتگی ذخیره شد.');
        }

        if ($action === 'add_item') {
            $day = (string)($_POST['day_key'] ?? '');
            $source = (string)($_POST['source_archive'] ?? 'manual');
            if (!isset($days[$day])) throw new RuntimeException('روز انتخاب‌شده معتبر نیست.');
            if (!in_array($source, $archives, true)) throw new RuntimeException('آرشیو انتخاب‌شده معتبر نیست.');
            $title = bm_ws_cut((string)($_POST['title'] ?? ''), 255);
            $titleFa = bm_ws_cut((string)($_POST['title_fa'] ?? ''), 255);
            if ($title === '' && $titleFa === '') throw new RuntimeException('عنوان خالی است.');
            if ($title === '') $title = $titleFa;
            $target = admin_safe_destination_url((string)($_POST['target_url'] ?? ''));
            if ($target === '') throw new RuntimeException('لینک داخلی اثر معتبر نیست.');
            $sourceId = bm_ws_cut((string)($_POST['source_id'] ?? ''), 255);
            if ($sourceId === '') $sourceId = sha1($target);
            $sourceKey = sha1($source . '|' . $sourceId . '|' . $target);
            $stmt = $pdo->prepare("INSERT INTO weekly_schedule_items
                (day_key,source_archive,source_id,source_key,title,title_fa,poster_url,target_url,media_type,release_year,episode_label,item_order,is_active)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE title=VALUES(title),title_fa=VALUES(title_fa),poster_url=VALUES(poster_url),target_url=VALUES(target_url),media_type=VALUES(media_type),release_year=VALUES(release_year),episode_label=VALUES(episode_label),item_order=VALUES(item_order),is_active=VALUES(is_active)");
            $stmt->execute([
                $day,$source,$sourceId,$sourceKey,$title,$titleFa,bm_ws_safe_poster((string)($_POST['poster_url'] ?? '')),$target,
                bm_ws_cut((string)($_POST['media_type'] ?? 'series'),30),bm_ws_cut((string)($_POST['release_year'] ?? ''),12),
                bm_ws_cut((string)($_POST['episode_label'] ?? ''),120),max(0,(int)($_POST['item_order'] ?? 0)),1
            ]);
            bm_ws_redirect('عنوان به برنامه هفتگی اضافه شد.');
        }

        if ($action === 'edit_item') {
            $id = (int)($_POST['id'] ?? 0);
            $day = (string)($_POST['day_key'] ?? '');
            if ($id <= 0 || !isset($days[$day])) throw new RuntimeException('اطلاعات آیتم معتبر نیست.');
            $title = bm_ws_cut((string)($_POST['title'] ?? ''),255);
            $titleFa = bm_ws_cut((string)($_POST['title_fa'] ?? ''),255);
            if ($title === '' && $titleFa === '') throw new RuntimeException('عنوان خالی است.');
            $target = admin_safe_destination_url((string)($_POST['target_url'] ?? ''));
            if ($target === '') throw new RuntimeException('لینک معتبر نیست.');
            $stmt = $pdo->prepare("UPDATE weekly_schedule_items SET day_key=?,title=?,title_fa=?,poster_url=?,target_url=?,media_type=?,release_year=?,episode_label=?,item_order=?,is_active=? WHERE id=?");
            $stmt->execute([$day,$title ?: $titleFa,$titleFa,bm_ws_safe_poster((string)($_POST['poster_url'] ?? '')),$target,bm_ws_cut((string)($_POST['media_type'] ?? 'series'),30),bm_ws_cut((string)($_POST['release_year'] ?? ''),12),bm_ws_cut((string)($_POST['episode_label'] ?? ''),120),max(0,(int)($_POST['item_order'] ?? 0)),isset($_POST['is_active'])?1:0,$id]);
            bm_ws_redirect('آیتم برنامه به‌روزرسانی شد.');
        }

        if ($action === 'delete_item') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('شناسه نامعتبر است.');
            $pdo->prepare('DELETE FROM weekly_schedule_items WHERE id=?')->execute([$id]);
            bm_ws_redirect('آیتم از جدول حذف شد.');
        }
    } catch (Throwable $e) {
        bm_ws_redirect($e->getMessage(), 'error');
    }
}

$settings = bm_weekly_schedule_settings($pdo);
$items = bm_weekly_schedule_items($pdo, false);
$grouped = array_fill_keys(array_keys($days), []);
foreach ($items as $item) if (isset($grouped[$item['day_key']])) $grouped[$item['day_key']][] = $item;
$msg = trim((string)($_GET['ok'] ?? ''));
$error = trim((string)($_GET['error'] ?? ''));
$csrf = admin_csrf_token();
?>
<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>مدیریت جدول پخش هفتگی | BankMovie</title>
<link rel="preload" href="/assets/fonts/bonVF.woff2" as="font" type="font/woff2" crossorigin>
<style>
@font-face{font-family:BonVF;src:url('/assets/fonts/bonVF.woff2') format('woff2');font-display:swap;font-weight:100 900}*{box-sizing:border-box}body{margin:0;background:#080b11;color:#fff;font-family:BonVF,Tahoma,sans-serif}.wrap{width:min(1450px,calc(100% - 28px));margin:22px auto 70px}.topbar{display:flex;align-items:center;justify-content:space-between;gap:18px;padding:19px 21px;border:1px solid rgba(255,255,255,.08);border-radius:24px;background:linear-gradient(145deg,#161b26,#0e121a);box-shadow:0 25px 80px rgba(0,0,0,.3)}h1{margin:0;font-size:23px}.sub{margin-top:5px;color:#8991a3;font-size:10px}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn,button{font-family:inherit}.btn{min-height:40px;display:inline-flex;align-items:center;justify-content:center;padding:0 14px;border:1px solid rgba(255,255,255,.1);border-radius:12px;background:rgba(255,255,255,.045);color:#fff;text-decoration:none;font-size:10px;font-weight:850;cursor:pointer}.btn.primary{background:#2f7cff;border-color:#2f7cff}.btn.danger{color:#ff8794;border-color:rgba(255,90,110,.24);background:rgba(255,70,90,.07)}.notice{margin-top:14px;padding:12px 15px;border-radius:14px;border:1px solid rgba(62,227,148,.22);background:rgba(62,227,148,.08);color:#92ffd0;font-size:11px}.notice.error{border-color:rgba(255,84,103,.25);background:rgba(255,84,103,.08);color:#ffabb5}.grid{display:grid;grid-template-columns:minmax(0,1fr) minmax(360px,.52fr);gap:15px;margin-top:15px}.panel{border:1px solid rgba(255,255,255,.075);border-radius:22px;background:#111620;padding:18px}.panel h2{margin:0 0 4px;font-size:16px}.hint{color:#7f899d;font-size:9px;line-height:1.9;margin-bottom:15px}.fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.field{display:flex;flex-direction:column;gap:6px}.field.wide{grid-column:1/-1}.field label{font-size:9px;color:#a7afbe;font-weight:800}.input,.select,.textarea{width:100%;border:1px solid rgba(255,255,255,.09);border-radius:12px;background:#090d14;color:#fff;padding:11px 12px;outline:none;font:700 10px inherit}.textarea{min-height:74px;resize:vertical}.input:focus,.select:focus,.textarea:focus{border-color:rgba(47,124,255,.65);box-shadow:0 0 0 3px rgba(47,124,255,.08)}.checks{display:flex;gap:16px;flex-wrap:wrap;margin:13px 0}.check{display:flex;align-items:center;gap:7px;font-size:10px;color:#c8ced9}.search-row{display:grid;grid-template-columns:155px minmax(0,1fr) auto;gap:8px}.results{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;margin-top:13px;max-height:560px;overflow:auto;padding-left:3px}.result{display:flex;align-items:center;gap:10px;padding:9px;border:1px solid rgba(255,255,255,.065);border-radius:15px;background:#0b0f17}.result img,.poster{width:49px;height:67px;object-fit:cover;border-radius:10px;background:#202633;flex:0 0 auto}.result-copy{min-width:0;flex:1}.result strong{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10.5px}.result small{display:block;color:#727c90;font-size:8px;margin-top:5px}.result .btn{min-height:32px;padding-inline:10px}.empty{grid-column:1/-1;padding:26px;text-align:center;border:1px dashed rgba(255,255,255,.08);border-radius:15px;color:#626c7e;font-size:10px}.days{margin-top:15px;display:flex;flex-direction:column;gap:13px}.day{border:1px solid rgba(255,255,255,.07);border-radius:20px;background:#0e131c;overflow:hidden}.day-head{display:flex;align-items:center;justify-content:space-between;padding:13px 15px;border-bottom:1px solid rgba(255,255,255,.06)}.day-head strong{font-size:12px}.count{padding:4px 8px;border-radius:99px;background:rgba(47,124,255,.11);color:#75a8ff;font-size:8px}.items{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:9px;padding:11px}.item{padding:11px;border:1px solid rgba(255,255,255,.055);border-radius:16px;background:#090d14}.item-top{display:flex;gap:9px;align-items:center;margin-bottom:10px}.item-title{min-width:0}.item-title strong{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10.5px}.item-title small{display:block;margin-top:4px;color:#6f7990;font-size:8px}.item-fields{display:grid;grid-template-columns:1fr 1fr;gap:7px}.item-fields .wide{grid-column:1/-1}.item-actions{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:9px}.source-badge{display:inline-flex;padding:3px 7px;border-radius:99px;background:rgba(255,255,255,.055);color:#9099ab;font-size:7px}.modal{position:fixed;inset:0;z-index:100;display:none;place-items:center;padding:18px;background:rgba(2,4,8,.82);backdrop-filter:blur(12px)}.modal.open{display:grid}.modal-card{width:min(530px,100%);border:1px solid rgba(47,124,255,.32);border-radius:23px;background:#111620;padding:20px;box-shadow:0 35px 110px rgba(0,0,0,.6)}.modal-head{display:flex;align-items:center;gap:11px;margin-bottom:16px}.modal-head img{width:58px;height:78px;object-fit:cover;border-radius:11px;background:#242a36}.modal-head strong{display:block;font-size:14px}.modal-head small{color:#798398;font-size:9px}.modal-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:13px}
@media(max-width:1000px){.grid{grid-template-columns:1fr}.results,.items{grid-template-columns:1fr 1fr}}@media(max-width:650px){.wrap{width:min(100% - 16px,1450px);margin-top:8px}.topbar{align-items:flex-start;flex-direction:column;border-radius:18px}.fields,.results,.items{grid-template-columns:1fr}.search-row{grid-template-columns:1fr}.panel{padding:14px;border-radius:18px}.item-fields{grid-template-columns:1fr}.item-fields .wide{grid-column:auto}}
</style>
<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head><body class="bm-admin-unified"><div class="wrap">
<div class="topbar"><div><h1>جدول پخش هفتگی</h1><div class="sub">جستجو در آرشیوهای ۱ تا ۴، افزودن به روز دلخواه و نمایش خودکار در انتهای صفحه اصلی.</div></div><div class="actions"><a class="btn" href="/admin.php">بازگشت به پنل</a><a class="btn" href="/">مشاهده سایت</a></div></div>
<?php if($msg!==''):?><div class="notice"><?=bm_ws_e($msg)?></div><?php endif;?><?php if($error!==''):?><div class="notice error"><?=bm_ws_e($error)?></div><?php endif;?>
<div class="bm-admin-kpis"><div class="bm-admin-kpi"><small>کل عناوین برنامه</small><strong><?= count($items) ?></strong></div><div class="bm-admin-kpi"><small>عنوان فعال</small><strong><?= count(array_filter($items, static fn($x)=>(int)($x['is_active']??0)===1)) ?></strong></div><div class="bm-admin-kpi"><small>روزهای دارای محتوا</small><strong><?= count(array_filter($grouped)) ?></strong></div><div class="bm-admin-kpi"><small>وضعیت سکشن</small><strong style="font-size:15px;color:<?= $settings['is_enabled']?'#bbf7d0':'#fecdd3' ?>"><?= $settings['is_enabled']?'فعال':'غیرفعال' ?></strong></div></div>
<div class="grid"><div>
<section class="panel"><h2>جستجو و افزودن اثر</h2><div class="hint">آرشیو را انتخاب کن یا روی «همه آرشیوها» بگذار. نتیجه انتخابی بدون کپی فایل، فقط با پوستر و لینک داخلی همان آرشیو در جدول ثبت می‌شود.</div><div class="search-row"><select class="select" id="searchArchive"><option value="all">همه آرشیوها</option><option value="archive1">آرشیو ۱</option><option value="archive2">آرشیو ۲</option><option value="archive3">آرشیو ۳</option><option value="archive4">آرشیو ۴</option></select><input class="input" id="searchQuery" placeholder="نام فیلم یا سریال را بنویس…"><button class="btn primary" type="button" id="searchBtn">جستجو</button></div><div class="results" id="searchResults"><div class="empty">برای افزودن عنوان، ابتدا جستجو کن.</div></div></section>
<div class="days">
<?php foreach($days as $key=>$def): ?>
<section class="day bm-week-day">
  <div class="bm-week-day-head"><strong><?= bm_ws_e($def['fa']) ?></strong><span class="count"><?= count($grouped[$key]) ?> عنوان</span></div>
  <div class="bm-admin-table-wrap">
    <table class="bm-week-table">
      <thead><tr><th>اثر</th><th>آرشیو</th><th>روز</th><th>توضیح پخش</th><th>سال / نوع</th><th>ترتیب</th><th>وضعیت</th><th>عملیات</th></tr></thead>
      <tbody>
      <?php if(!$grouped[$key]): ?><tr><td colspan="8" style="text-align:center;color:#64748b;padding:24px!important">برای این روز هنوز عنوانی اضافه نشده است.</td></tr><?php endif; ?>
      <?php foreach($grouped[$key] as $item): ?>
        <tr class="movie-item" data-id="<?= (int)$item['id'] ?>">
          <?php $bmFormId='bm-week-edit-'.(int)$item['id']; ?>
          <td><div class="bm-week-movie"><?php if(!empty($item['poster_url'])):?><img src="<?= bm_ws_e($item['poster_url']) ?>" alt=""><?php else:?><span class="bm-week-poster"></span><?php endif; ?><div><b><?= bm_ws_e($item['title_fa'] ?: $item['title']) ?></b><small><?= bm_ws_e($item['title']) ?></small></div></div><form id="<?= $bmFormId ?>" method="post" style="display:none"><?= admin_csrf_input() ?><input type="hidden" name="action" value="edit_item"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><input type="hidden" name="title_fa" value="<?=bm_ws_e($item['title_fa'])?>"><input type="hidden" name="title" value="<?=bm_ws_e($item['title'])?>"><input type="hidden" name="poster_url" value="<?=bm_ws_e($item['poster_url'])?>"><input type="hidden" name="target_url" value="<?=bm_ws_e($item['target_url'])?>"></form></td>
          <td><span class="source-badge"><?= bm_ws_e(bm_weekly_schedule_archive_label($item['source_archive'])) ?></span></td>
          <td><select form="<?= $bmFormId ?>" class="select bm-week-inline" name="day_key"><?php foreach($days as $dk=>$dd):?><option value="<?=bm_ws_e($dk)?>" <?=$dk===$item['day_key']?'selected':''?>><?=bm_ws_e($dd['fa'])?></option><?php endforeach;?></select></td>
          <td><input form="<?= $bmFormId ?>" class="input bm-week-inline wide" name="episode_label" value="<?=bm_ws_e($item['episode_label'])?>" placeholder="قسمت جدید، ساعت پخش یا توضیح"></td>
          <td><div style="display:flex;gap:5px"><input form="<?= $bmFormId ?>" class="input bm-week-inline" name="release_year" value="<?=bm_ws_e($item['release_year'])?>" placeholder="سال"><input form="<?= $bmFormId ?>" class="input bm-week-inline" name="media_type" value="<?=bm_ws_e($item['media_type'])?>" placeholder="نوع"></div></td>
          <td><input form="<?= $bmFormId ?>" class="input bm-week-inline" type="number" min="0" name="item_order" value="<?= (int)$item['item_order'] ?>"></td>
          <td><label class="check bm-week-status"><input form="<?= $bmFormId ?>" type="checkbox" name="is_active" <?=$item['is_active']?'checked':''?>> فعال</label></td>
          <td><div class="bm-week-row-actions"><button form="<?= $bmFormId ?>" class="btn primary">ذخیره</button><a class="btn" href="<?= bm_ws_e($item['target_url']) ?>" target="_blank">مشاهده</a><form method="post" onsubmit="return confirm('این عنوان حذف شود؟')" style="display:inline-flex"><?=admin_csrf_input()?><input type="hidden" name="action" value="delete_item"><input type="hidden" name="id" value="<?= (int)$item['id'] ?>"><button class="btn danger">حذف</button></form></div></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php endforeach; ?>
</div></div>
<aside><section class="panel"><h2>تنظیمات نمایش</h2><div class="hint">این تنظیمات ظاهر و رفتار سکشن انتهای صفحه اصلی را کنترل می‌کند.</div><form method="post"><?=admin_csrf_input()?><input type="hidden" name="action" value="save_settings"><div class="fields"><div class="field wide"><label>عنوان فارسی</label><input class="input" name="title_fa" value="<?=bm_ws_e($settings['title_fa'])?>"></div><div class="field wide"><label>زیرعنوان فارسی</label><input class="input" name="subtitle_fa" value="<?=bm_ws_e($settings['subtitle_fa'])?>"></div><div class="field"><label>عنوان انگلیسی</label><input class="input" name="title_en" value="<?=bm_ws_e($settings['title_en'])?>"></div><div class="field"><label>زیرعنوان انگلیسی</label><input class="input" name="subtitle_en" value="<?=bm_ws_e($settings['subtitle_en'])?>"></div><div class="field wide"><label>روز پیش‌فرض</label><select class="select" name="default_day_mode"><option value="today" <?=$settings['default_day_mode']==='today'?'selected':''?>>امروز؛ اگر خالی بود اولین روز دارای محتوا</option><option value="first" <?=$settings['default_day_mode']==='first'?'selected':''?>>اولین روز دارای محتوا</option></select></div></div><div class="checks"><label class="check"><input type="checkbox" name="is_enabled" <?=$settings['is_enabled']?'checked':''?>> نمایش در صفحه اصلی</label><label class="check"><input type="checkbox" name="show_empty_days" <?=$settings['show_empty_days']?'checked':''?>> نمایش روزهای خالی</label></div><button class="btn primary" style="width:100%">ذخیره تنظیمات</button></form></section></aside></div></div>
<div class="modal" id="addModal"><div class="modal-card"><div class="modal-head"><img id="modalPoster" alt=""><div><strong id="modalTitle">افزودن به جدول</strong><small id="modalMeta"></small></div></div><form method="post" id="addForm"><?=admin_csrf_input()?><input type="hidden" name="action" value="add_item"><input type="hidden" name="source_archive" id="fSource"><input type="hidden" name="source_id" id="fSourceId"><input type="hidden" name="title" id="fTitle"><input type="hidden" name="title_fa" id="fTitleFa"><input type="hidden" name="poster_url" id="fPoster"><input type="hidden" name="target_url" id="fTarget"><input type="hidden" name="media_type" id="fType"><input type="hidden" name="release_year" id="fYear"><div class="fields"><div class="field"><label>روز پخش</label><select class="select" name="day_key"><?php foreach($days as $key=>$def):?><option value="<?=bm_ws_e($key)?>"><?=bm_ws_e($def['fa'])?></option><?php endforeach;?></select></div><div class="field"><label>ترتیب</label><input class="input" type="number" min="0" name="item_order" value="0"></div><div class="field wide"><label>توضیح پخش</label><input class="input" name="episode_label" placeholder="مثلاً قسمت جدید، ساعت ۲۱ یا فصل ۲ قسمت ۵"></div></div><div class="modal-actions"><button class="btn" type="button" id="closeModal">انصراف</button><button class="btn primary">افزودن به جدول</button></div></form></div></div>
<script>
const csrf=<?=json_encode($csrf)?>, resultsEl=document.getElementById('searchResults'), modal=document.getElementById('addModal');
const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
function normal(source,item){
 const title=String(item.title||item.name||item.title_en||item.title_fa||'').trim(), titleFa=String(item.title_fa||item.fa_title||'').trim(), poster=String(item.poster||item.poster_url||item.image||item.thumbnail||'').trim(), year=String(item.year||item.release_year||'').trim();
 let id=String(item.detail_id||(item.source_post_id?('p'+item.source_post_id):'')||item.id||item.slug||item.source_slug||item.imdb_code||item.url||'').trim(), type=String(item.type||item.post_type||'movie').toLowerCase(), target=String(item.target_url||'').trim();
 if(source==='archive1'&&!target)target='/movie/arc1-'+encodeURIComponent(id);
 if(source==='archive2'&&!target)target=item.target_url||'#';
 if(source==='archive3'&&!target)target='/movie/arc3-'+encodeURIComponent(id);
 if(source==='archive4'&&!target)target='/movie/arc4-'+encodeURIComponent(id);
 return {source_archive:source,source_id:id,title,title_fa:titleFa,poster_url:poster,target_url:target,media_type:type,release_year:year};
}
async function fetchArchive(source,q){let url='';if(source==='archive1')url='/api2.php?s='+encodeURIComponent(q)+'&page=1';if(source==='archive2')url='/admin_weekly_schedule.php?ajax=local_search&q='+encodeURIComponent(q);if(source==='archive3')url='/api6.php?s='+encodeURIComponent(q)+'&page=1';if(source==='archive4')url='/api4.php?s='+encodeURIComponent(q)+'&page=1';const r=await fetch(url,{credentials:'same-origin'});if(!r.ok)throw new Error(source);const d=await r.json();return (d.movies||d.results||d.items||[]).slice(0,20).map(x=>normal(source,x)).filter(x=>x.source_id&&x.target_url&&(x.title||x.title_fa))}
function render(items){if(!items.length){resultsEl.innerHTML='<div class="empty">نتیجه‌ای پیدا نشد.</div>';return}resultsEl.innerHTML=items.map((x,i)=>`<article class="result"><img src="${esc(x.poster_url)}" alt="" onerror="this.style.visibility='hidden'"><div class="result-copy"><strong><bdi dir="auto">${esc(x.title_fa||x.title)}</bdi></strong><small>${esc(x.release_year||'')} · ${esc(x.source_archive.replace('archive','آرشیو '))}</small></div><button class="btn primary" type="button" data-add="${i}">افزودن</button></article>`).join('');resultsEl.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>openModal(items[+b.dataset.add]));}
function openModal(x){document.getElementById('modalPoster').src=x.poster_url||'';document.getElementById('modalTitle').textContent=x.title_fa||x.title;document.getElementById('modalMeta').textContent=(x.release_year||'')+' · '+x.source_archive.replace('archive','آرشیو ');for(const [id,k] of [['fSource','source_archive'],['fSourceId','source_id'],['fTitle','title'],['fTitleFa','title_fa'],['fPoster','poster_url'],['fTarget','target_url'],['fType','media_type'],['fYear','release_year']])document.getElementById(id).value=x[k]||'';modal.classList.add('open')}
document.getElementById('closeModal').onclick=()=>modal.classList.remove('open');modal.addEventListener('click',e=>{if(e.target===modal)modal.classList.remove('open')});
document.getElementById('searchBtn').onclick=async()=>{const q=document.getElementById('searchQuery').value.trim(), a=document.getElementById('searchArchive').value;if(q.length<2){resultsEl.innerHTML='<div class="empty">حداقل دو حرف بنویس.</div>';return}resultsEl.innerHTML='<div class="empty">در حال جستجو در آرشیوها…</div>';const sources=a==='all'?['archive1','archive2','archive3','archive4']:[a];const settled=await Promise.allSettled(sources.map(s=>fetchArchive(s,q)));let items=[];settled.forEach(r=>{if(r.status==='fulfilled')items=items.concat(r.value)});const seen=new Set;items=items.filter(x=>{const k=x.source_archive+'|'+x.source_id;if(seen.has(k))return false;seen.add(k);return true});render(items)};
document.getElementById('searchQuery').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();document.getElementById('searchBtn').click()}});
</script></body></html>
