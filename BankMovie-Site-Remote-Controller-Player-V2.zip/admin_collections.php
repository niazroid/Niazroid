<?php
// admin_collections.php - مدیریت امن و کامل کالکشن‌ها
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
require_once __DIR__ . '/includes/public_assets.php';
$adminPanelHealth = admin_panel_bootstrap($pdo);
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

$message = trim((string)($_GET['msg'] ?? ''));
$error = trim((string)($_GET['error'] ?? ''));

function admin_collections_redirect(string $message = '', string $error = '', int $editId = 0): never
{
    $query = [];
    if ($message !== '') $query['msg'] = $message;
    if ($error !== '') $query['error'] = $error;
    if ($editId > 0) $query['edit'] = $editId;
    header('Location: admin_collections.php' . ($query ? '?' . http_build_query($query) : ''));
    exit;
}


function admin_collections_text_length(string $value): int
{
    return function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
}

function admin_collections_json(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// AJAX actions are handled before rendering the page.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    $action = (string)$_POST['ajax_action'];
    $collectionId = max(0, (int)($_POST['collection_id'] ?? 0));
    $movieId = max(0, (int)($_POST['movie_id'] ?? 0));

    try {
        if ($collectionId <= 0) throw new RuntimeException('شناسه کالکشن معتبر نیست.');
        $check = $pdo->prepare('SELECT id FROM collections WHERE id = ?');
        $check->execute([$collectionId]);
        if (!$check->fetchColumn()) throw new RuntimeException('کالکشن پیدا نشد.');

        if ($action === 'add_movie') {
            if ($movieId <= 0) throw new RuntimeException('شناسه فیلم معتبر نیست.');
            $checkMovie = $pdo->prepare('SELECT id FROM movies WHERE id = ?');
            $checkMovie->execute([$movieId]);
            if (!$checkMovie->fetchColumn()) throw new RuntimeException('فیلم پیدا نشد.');

            $exists = $pdo->prepare('SELECT id FROM collection_movies WHERE collection_id = ? AND movie_id = ? LIMIT 1');
            $exists->execute([$collectionId, $movieId]);
            if ($exists->fetchColumn()) {
                admin_collections_json(['success' => true, 'message' => 'این فیلم از قبل داخل کالکشن است.']);
            }
            $maxOrder = $pdo->prepare('SELECT COALESCE(MAX(sort_order), -1) FROM collection_movies WHERE collection_id = ?');
            $maxOrder->execute([$collectionId]);
            $newOrder = (int)$maxOrder->fetchColumn() + 1;
            $stmt = $pdo->prepare('INSERT INTO collection_movies (collection_id, movie_id, sort_order, created_at) VALUES (?, ?, ?, NOW())');
            $stmt->execute([$collectionId, $movieId, $newOrder]);
            admin_collections_json(['success' => true, 'message' => 'فیلم به کالکشن اضافه شد.']);
        }

        if ($action === 'remove_movie') {
            if ($movieId <= 0) throw new RuntimeException('شناسه فیلم معتبر نیست.');
            $pdo->beginTransaction();
            $pdo->prepare('DELETE FROM collection_movies WHERE collection_id = ? AND movie_id = ?')->execute([$collectionId, $movieId]);
            $rows = $pdo->prepare('SELECT id FROM collection_movies WHERE collection_id = ? ORDER BY sort_order ASC, id ASC');
            $rows->execute([$collectionId]);
            $update = $pdo->prepare('UPDATE collection_movies SET sort_order = ? WHERE id = ? AND collection_id = ?');
            foreach (($rows->fetchAll(PDO::FETCH_COLUMN) ?: []) as $index => $rowId) {
                $update->execute([$index, (int)$rowId, $collectionId]);
            }
            $pdo->commit();
            admin_collections_json(['success' => true, 'message' => 'فیلم از کالکشن حذف شد.']);
        }

        if ($action === 'reorder_movies') {
            $ids = json_decode((string)($_POST['ids'] ?? '[]'), true);
            if (!is_array($ids)) throw new RuntimeException('ترتیب ارسال‌شده معتبر نیست.');
            $ids = array_values(array_unique(array_filter(array_map('intval', $ids), fn($id) => $id > 0)));
            $pdo->beginTransaction();
            $stmt = $pdo->prepare('UPDATE collection_movies SET sort_order = ? WHERE id = ? AND collection_id = ?');
            foreach ($ids as $index => $cmId) $stmt->execute([$index, $cmId, $collectionId]);
            $pdo->commit();
            admin_collections_json(['success' => true, 'message' => 'ترتیب فیلم‌ها ذخیره شد.']);
        }

        throw new RuntimeException('عملیات ناشناخته است.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        admin_collections_json(['success' => false, 'message' => $e->getMessage()], 400);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_collection'])) {
    $id = max(0, (int)($_POST['id'] ?? 0));
    try {
        if ($id <= 0) throw new RuntimeException('شناسه کالکشن معتبر نیست.');
        $stmt = $pdo->prepare('SELECT cover_image FROM collections WHERE id = ?');
        $stmt->execute([$id]);
        $cover = $stmt->fetchColumn();
        if ($cover === false) throw new RuntimeException('کالکشن پیدا نشد.');

        $pdo->beginTransaction();
        $pdo->prepare('DELETE FROM collection_movies WHERE collection_id = ?')->execute([$id]);
        $pdo->prepare('DELETE FROM collections WHERE id = ?')->execute([$id]);
        $pdo->commit();
        admin_safe_unlink((string)$cover, ['uploads/collections/']);
        admin_collections_redirect('کالکشن با موفقیت حذف شد.');
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        admin_collections_redirect('', $e->getMessage());
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_collection'])) {
    $id = max(0, (int)($_POST['id'] ?? 0));
    $isNewCollection = $id === 0;
    $title = trim((string)($_POST['title'] ?? ''));
    $titleFa = trim((string)($_POST['title_fa'] ?? ''));
    $slug = admin_normalize_slug((string)($_POST['slug'] ?? ''), $title);
    $description = trim((string)($_POST['description'] ?? ''));
    $status = isset($_POST['status']) ? 1 : 0;
    $coverImage = null;
    $oldCover = '';

    try {
        if ($title === '') throw new RuntimeException('عنوان انگلیسی الزامی است.');
        if ($slug === '') throw new RuntimeException('اسلاگ انگلیسی معتبر وارد کنید.');
        if (admin_collections_text_length($title) > 255 || admin_collections_text_length($titleFa) > 255 || admin_collections_text_length($slug) > 190) {
            throw new RuntimeException('عنوان یا اسلاگ بیش از حد طولانی است.');
        }

        $duplicate = $pdo->prepare('SELECT id FROM collections WHERE slug = ? AND id <> ? LIMIT 1');
        $duplicate->execute([$slug, $id]);
        if ($duplicate->fetchColumn()) throw new RuntimeException('این اسلاگ قبلاً استفاده شده است.');

        if ($id > 0) {
            $current = $pdo->prepare('SELECT cover_image FROM collections WHERE id = ?');
            $current->execute([$id]);
            $oldCover = (string)($current->fetchColumn() ?: '');
            if ($oldCover === '' && !$current->rowCount()) {
                $exists = $pdo->prepare('SELECT COUNT(*) FROM collections WHERE id = ?');
                $exists->execute([$id]);
                if (!(int)$exists->fetchColumn()) throw new RuntimeException('کالکشن پیدا نشد.');
            }
        }

        if (isset($_FILES['cover_image']) && (int)($_FILES['cover_image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $coverImage = admin_safe_image_upload($_FILES['cover_image'], 'uploads/collections/', 'collection_' . date('Ymd_His') . '_' . bin2hex(random_bytes(6)), 84, 8 * 1024 * 1024);
        }

        $pdo->beginTransaction();
        if ($id > 0) {
            if ($coverImage) {
                $stmt = $pdo->prepare('UPDATE collections SET title=?, title_fa=?, slug=?, description=?, cover_image=?, status=?, updated_at=NOW() WHERE id=?');
                $stmt->execute([$title, $titleFa, $slug, $description, $coverImage, $status, $id]);
            } else {
                $stmt = $pdo->prepare('UPDATE collections SET title=?, title_fa=?, slug=?, description=?, status=?, updated_at=NOW() WHERE id=?');
                $stmt->execute([$title, $titleFa, $slug, $description, $status, $id]);
            }
        } else {
            $stmt = $pdo->prepare('INSERT INTO collections (title, title_fa, slug, description, cover_image, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())');
            $stmt->execute([$title, $titleFa, $slug, $description, $coverImage, $status]);
            $id = (int)$pdo->lastInsertId();
        }
        $pdo->commit();

        if ($coverImage && $oldCover && $oldCover !== $coverImage) admin_safe_unlink($oldCover, ['uploads/collections/']);
        admin_collections_redirect($isNewCollection ? 'کالکشن افزوده شد.' : 'کالکشن با موفقیت ذخیره شد.', '', $id);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        if ($coverImage) admin_safe_unlink($coverImage, ['uploads/collections/']);
        admin_collections_redirect('', $e->getMessage(), $id);
    }
}

try {
    $collections = $pdo->query("SELECT c.*, (SELECT COUNT(*) FROM collection_movies cm WHERE cm.collection_id=c.id) AS movie_count FROM collections c ORDER BY c.id DESC")->fetchAll() ?: [];
} catch (Throwable $e) {
    $collections = [];
    $error = $error ?: $e->getMessage();
}

$editCollection = null;
$collectionMovies = [];
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    $editId = max(0, (int)$_GET['edit']);
    $stmt = $pdo->prepare('SELECT * FROM collections WHERE id = ?');
    $stmt->execute([$editId]);
    $editCollection = $stmt->fetch() ?: null;
    if ($editCollection) {
        $stmt = $pdo->prepare('SELECT cm.*, m.title, m.title_fa, m.year, m.imdb_code, m.imdb_rate FROM collection_movies cm JOIN movies m ON cm.movie_id = m.id WHERE cm.collection_id = ? ORDER BY cm.sort_order ASC, cm.id ASC');
        $stmt->execute([$editId]);
        $collectionMovies = $stmt->fetchAll() ?: [];
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>مدیریت کالکشن‌ها | پنل ادمین</title>
  <style>

/* ================= BankMovie Admin Pro UI v2 ================= */
:root{
  --pro-bg:#07090d;
  --pro-surface:rgba(18,22,30,.78);
  --pro-surface-2:rgba(11,14,20,.88);
  --pro-border:rgba(255,255,255,.09);
  --pro-border-strong:rgba(54,255,159,.32);
  --pro-text:#f7fbff;
  --pro-muted:#9aa6b5;
  --pro-accent:#36ff9f;
  --pro-accent-2:#38bdf8;
  --pro-danger:#fb7185;
  --pro-warning:#fbbf24;
  --pro-radius:26px;
  --pro-shadow:0 28px 80px rgba(0,0,0,.42);
}
html{scroll-behavior:smooth;}
body, body.admin-shell{
  background:
    radial-gradient(circle at 85% -5%, rgba(54,255,159,.12), transparent 34%),
    radial-gradient(circle at 5% 15%, rgba(56,189,248,.10), transparent 32%),
    linear-gradient(180deg,#090b10,#050609 72%) !important;
  color:var(--pro-text) !important;
  font-family:Vazirmatn, IRANSans, Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
  letter-spacing:-.01em;
}
body::before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.9),transparent 78%);}
.container{width:min(100%,1640px) !important;}
.header,.admin-header,.card,.add-collection-form,.login-box{
  background:linear-gradient(145deg,rgba(20,25,34,.86),rgba(9,12,18,.78)) !important;
  border:1px solid var(--pro-border) !important;
  box-shadow:var(--pro-shadow) !important;
  backdrop-filter:blur(24px) saturate(145%) !important;
}
.header,.admin-header{position:sticky;top:14px;z-index:50;border-radius:30px !important;}
.card{border-radius:var(--pro-radius) !important;overflow:hidden;}
.card:hover,.collection-card:hover,.movie-row:hover,.movie-item:hover,.link-row:hover{border-color:var(--pro-border-strong) !important;box-shadow:0 22px 70px rgba(0,0,0,.34) !important;}
.card h2,.card h3,.card-header h3,h2,h3,h4,.logo,.logo-text{
  letter-spacing:-.03em;
}
.logo svg,.logo-area svg,.card h2 svg,.card h3 svg,.card-header svg,.back-btn svg,.btn svg,.btn-secondary svg{filter:drop-shadow(0 0 12px rgba(54,255,159,.22));}
input,select,textarea,.search-input{
  background:rgba(4,7,12,.72) !important;
  border:1px solid rgba(255,255,255,.10) !important;
  border-radius:18px !important;
  color:var(--pro-text) !important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.03) !important;
}
input:focus,select:focus,textarea:focus,.search-input:focus{
  border-color:var(--pro-accent) !important;
  box-shadow:0 0 0 4px rgba(54,255,159,.12), inset 0 1px 0 rgba(255,255,255,.05) !important;
}
label{color:var(--pro-muted) !important;font-weight:650 !important;}
.btn,.btn-new-collection,button[type="submit"]{
  background:linear-gradient(135deg,var(--pro-accent),#7dd3fc) !important;
  color:#03110a !important;
  border:0 !important;
  border-radius:999px !important;
  box-shadow:0 16px 34px rgba(54,255,159,.18) !important;
}
.btn:hover,.btn-new-collection:hover,button[type="submit"]:hover{transform:translateY(-2px);box-shadow:0 22px 45px rgba(54,255,159,.24) !important;}
.btn-secondary,.back-btn,.back-link,.tab,.pagination a{
  background:rgba(255,255,255,.065) !important;
  border:1px solid rgba(255,255,255,.10) !important;
  color:var(--pro-text) !important;
  border-radius:999px !important;
}
.btn-secondary:hover,.back-btn:hover,.back-link:hover,.tab.active,.pagination a.active,.pagination a:hover{
  color:#03110a !important;
  background:linear-gradient(135deg,var(--pro-accent),#7dd3fc) !important;
  border-color:transparent !important;
}
.btn-danger,.remove-link{
  background:rgba(251,113,133,.12) !important;
  border:1px solid rgba(251,113,133,.32) !important;
  color:#fecdd3 !important;
  border-radius:999px !important;
}
.btn-danger:hover,.remove-link:hover{background:rgba(251,113,133,.22) !important;}
.badge{border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.07);border-radius:999px;padding:.24rem .62rem;}
.badge-warning{background:rgba(251,191,36,.13) !important;color:#fde68a !important;border-color:rgba(251,191,36,.25) !important;}
table{width:100%;border-collapse:separate !important;border-spacing:0 10px !important;}
th{color:var(--pro-muted) !important;font-size:12px;text-transform:none;background:rgba(255,255,255,.045) !important;}
td,th{padding:14px 16px !important;border-bottom:0 !important;}
tbody tr{background:rgba(255,255,255,.035) !important;box-shadow:0 10px 30px rgba(0,0,0,.16);}
tbody tr td:first-child{border-radius:0 18px 18px 0;} tbody tr td:last-child{border-radius:18px 0 0 18px;}
.movie-row,.movie-item,.link-row,.collection-card,.admin-pick-item,.search-result-item,.live-search-result-item{
  background:rgba(5,8,14,.66) !important;
  border:1px solid var(--pro-border) !important;
  border-radius:22px !important;
}
.collection-list{grid-template-columns:repeat(auto-fill,minmax(220px,1fr)) !important;}
.collection-cover,.poster-preview img,.poster-preview{box-shadow:0 18px 38px rgba(0,0,0,.28);}
.checkbox-grid,.genres-checkbox-group{background:rgba(4,7,12,.58) !important;border-color:var(--pro-border) !important;}
.checkbox-item,.genre-checkbox{border:1px solid transparent;}
.checkbox-item:hover,.genre-checkbox:hover{border-color:var(--pro-border-strong) !important;background:rgba(54,255,159,.09) !important;}
.toast{background:rgba(8,12,18,.92) !important;border-radius:999px !important;box-shadow:var(--pro-shadow) !important;}
.modal{backdrop-filter:blur(10px);}
.modal-content{background:linear-gradient(145deg,rgba(20,25,34,.96),rgba(9,12,18,.94)) !important;border:1px solid var(--pro-border-strong) !important;border-radius:30px !important;box-shadow:var(--pro-shadow) !important;}
@media(max-width:860px){body{padding:14px !important}.header,.admin-header{position:relative;top:0}.card{padding:18px !important}.form-grid{grid-template-columns:1fr !important}td,th{white-space:nowrap}.admin-actions{width:100%;justify-content:space-between}.collection-list{grid-template-columns:repeat(2,minmax(0,1fr)) !important}}
@media(max-width:520px){.collection-list{grid-template-columns:1fr !important}.action-buttons,.collection-actions{justify-content:stretch}.btn,.btn-secondary,.back-btn,.back-link{width:100%;justify-content:center}.logo,.logo-text{font-size:20px !important}}


    *{margin:0;padding:0;box-sizing:border-box}
    body{background:#0a0a0c;color:#fff;font-family:system-ui;padding:20px}
    .container{max-width:1400px;margin:0 auto}
    .header{display:flex;justify-content:space-between;align-items:center;margin-bottom:28px;padding-bottom:20px;border-bottom:1px solid rgba(255,255,255,0.06);flex-wrap:wrap;gap:16px}
    .logo{font-size:24px;font-weight:800;background:linear-gradient(135deg,#36ff9f,#2ecc8a);-webkit-background-clip:text;background-clip:text;color:transparent}
    .back-link{background:rgba(255,255,255,0.08);border:1px solid rgba(255,255,255,0.1);padding:8px 18px;border-radius:40px;color:#fff;text-decoration:none;transition:0.2s}
    .back-link:hover{background:rgba(54,255,159,0.1);border-color:#36ff9f}
    .btn-new-collection{background:#36ff9f;color:#000;border:none;padding:8px 20px;border-radius:40px;font-weight:bold;cursor:pointer;transition:0.2s;display:inline-flex;align-items:center;gap:8px}
    .btn-new-collection:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(54,255,159,0.3)}
    .card{background:#121215;border-radius:28px;padding:24px;margin-bottom:28px;border:1px solid rgba(255,255,255,0.06)}
    h2{color:#36ff9f;margin-bottom:20px;font-size:20px;display:flex;align-items:center;gap:10px}
    .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px}
    .form-group{margin-bottom:20px}
    label{display:block;margin-bottom:8px;color:#a0a0a8;font-size:13px}
    input,select,textarea{width:100%;padding:12px;background:#1a1a1e;border:1px solid #333;border-radius:16px;color:#fff;font-size:14px}
    input:focus,select:focus,textarea:focus{outline:none;border-color:#36ff9f}
    .btn{background:#36ff9f;color:#000;border:none;padding:12px 24px;border-radius:40px;font-weight:bold;cursor:pointer;transition:0.2s}
    .btn:hover{transform:translateY(-2px);box-shadow:0 5px 20px rgba(54,255,159,0.3)}
    .btn-secondary{background:rgba(255,255,255,0.08);color:#fff;padding:8px 18px;border-radius:40px;border:none;cursor:pointer;transition:0.2s}
    .btn-secondary:hover{background:rgba(54,255,159,0.2)}
    .btn-danger{background:rgba(255,68,68,0.15);color:#ff8888;border:1px solid rgba(255,68,68,0.3);padding:6px 14px;border-radius:40px;cursor:pointer;transition:0.2s}
    .btn-danger:hover{background:rgba(255,68,68,0.3)}
    .collection-list{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin-top:20px}
    .collection-card{background:#0f0f13;border-radius:20px;overflow:hidden;border:1px solid rgba(255,255,255,0.06);transition:0.2s}
    .collection-card:hover{transform:translateY(-4px);border-color:#36ff9f}
    .collection-cover{width:100%;aspect-ratio:2/3;object-fit:cover;background:#1a1a1e}
    .collection-info{padding:12px}
    .collection-title{font-weight:600;margin-bottom:4px}
    .collection-slug{font-size:11px;color:#888}
    .collection-actions{display:flex;gap:8px;margin-top:12px;flex-wrap:wrap}
    
    /* لایو سرچ */
    .search-movies{position:relative;margin-bottom:24px}
    .search-input{width:100%;padding:14px 18px;background:#1a1a1e;border:1px solid #333;border-radius:60px;color:#fff;font-size:14px}
    .search-input:focus{outline:none;border-color:#36ff9f;box-shadow:0 0 0 3px rgba(54,255,159,0.1)}
    .search-results{position:absolute;top:100%;left:0;right:0;background:#121215;border-radius:20px;border:1px solid rgba(54,255,159,0.3);margin-top:8px;max-height:350px;overflow-y:auto;z-index:1000;display:none}
    .search-result-item{padding:14px 18px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.06);transition:0.2s;display:flex;justify-content:space-between;align-items:center}
    .search-result-item:hover{background:rgba(54,255,159,0.1)}
    .add-movie-btn{background:#36ff9f;color:#000;border:none;padding:6px 16px;border-radius:40px;cursor:pointer;font-weight:600;transition:0.2s}
    .add-movie-btn:hover{transform:scale(0.98)}
    
    /* لیست فیلم‌های کالکشن */
    .movie-list-manager{max-height:500px;overflow-y:auto;margin-top:20px}
    .movie-item{background:#0f0f13;border-radius:16px;padding:14px 18px;margin-bottom:10px;display:flex;justify-content:space-between;align-items:center;cursor:move;border:1px solid rgba(255,255,255,0.06);transition:0.2s}
    .movie-item:hover{background:#1a1a1e;border-color:#36ff9f}
    .movie-item.dragging{opacity:0.5}
    .drag-handle{cursor:grab;color:#888;margin-left:12px;font-size:18px}
    
    .toast{position:fixed;bottom:30px;right:30px;background:#1a1a1e;border:1px solid #36ff9f;border-radius:60px;padding:12px 24px;z-index:10000;animation:slideIn 0.3s ease}
    @keyframes slideIn{from{transform:translateX(100px);opacity:0}to{transform:translateX(0);opacity:1}}
    
    /* فرم افزودن کالکشن (قابل جمع شدن) */
    .add-collection-form {
      display: none;
      margin-bottom: 30px;
      background: rgba(0,0,0,0.3);
      border-radius: 20px;
      padding: 20px;
    }
    .add-collection-form.show {
      display: block;
    }
    
    @media(max-width:768px){.collection-list{grid-template-columns:repeat(2,1fr)}.movie-item{flex-direction:column;gap:10px}}
  

/* ================= BankMovie Admin Ultra Pro v3 Overrides ================= */
:root{--admin-bg:#06080d;--admin-panel:rgba(13,17,25,.78);--admin-line:rgba(255,255,255,.10);--admin-line-strong:rgba(54,255,159,.34);--admin-text:#f8fbff;--admin-muted:#96a3b4;--admin-green:#36ff9f;--admin-blue:#67e8f9;--admin-red:#fb7185;--admin-radius:28px;}
body{padding:26px;background:radial-gradient(circle at 82% 0,rgba(54,255,159,.16),transparent 32%),radial-gradient(circle at 8% 18%,rgba(103,232,249,.12),transparent 30%),linear-gradient(180deg,#0a0d14,#05070b 78%) !important;color:var(--admin-text) !important;}
.container{max-width:1540px !important;}.header,.admin-header,.top-bar{position:sticky;top:14px;z-index:50;padding:18px 22px !important;border-radius:32px !important;background:linear-gradient(135deg,rgba(20,26,38,.88),rgba(8,11,18,.84)) !important;border:1px solid var(--admin-line) !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;backdrop-filter:blur(22px);}
.logo{font-size:clamp(20px,2vw,30px) !important;}.card,.add-collection-form{position:relative;background:linear-gradient(150deg,rgba(19,25,37,.82),rgba(7,10,16,.76)) !important;border:1px solid var(--admin-line) !important;border-radius:32px !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;}.card:before,.add-collection-form:before{content:"";position:absolute;inset:0 0 auto 0;height:1px;background:linear-gradient(90deg,transparent,rgba(54,255,159,.45),transparent);opacity:.7;}
h2,h3,.card h2,.card h3{color:#fff !important;}input,select,textarea,.search-input{background:rgba(3,6,12,.72) !important;border:1px solid rgba(255,255,255,.11) !important;border-radius:18px !important;color:var(--admin-text) !important;}input:focus,select:focus,textarea:focus,.search-input:focus{border-color:var(--admin-green) !important;box-shadow:0 0 0 4px rgba(54,255,159,.13) !important;}.btn,.btn-new-collection,button[type="submit"]{background:linear-gradient(135deg,var(--admin-green),var(--admin-blue)) !important;color:#03110a !important;border:0 !important;border-radius:999px !important;box-shadow:0 16px 34px rgba(54,255,159,.18) !important;}.btn-secondary,.back-link,.btn-logout{background:rgba(255,255,255,.065) !important;border:1px solid rgba(255,255,255,.10) !important;color:var(--admin-text) !important;border-radius:999px !important;}.btn-danger{background:rgba(251,113,133,.12) !important;border:1px solid rgba(251,113,133,.32) !important;color:#fecdd3 !important;border-radius:999px !important;}.collection-card,.movie-item,.search-result-item,tr{background:linear-gradient(135deg,rgba(12,17,26,.78),rgba(4,7,12,.68)) !important;border:1px solid rgba(255,255,255,.09) !important;border-radius:24px !important;}.collection-card{overflow:hidden;}.collection-cover,.slide-preview{box-shadow:0 22px 52px rgba(0,0,0,.36);}.nav-links{display:flex;gap:10px;flex-wrap:wrap;align-items:center}.toast{background:rgba(8,12,18,.94) !important;border-radius:999px !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;}.table-wrap{border-radius:26px;overflow:hidden;}@media(max-width:760px){body{padding:14px}.header,.admin-header,.top-bar{position:relative;top:0}.card{padding:18px !important}.nav-links>*{width:100%;justify-content:center;text-align:center}.collection-list{grid-template-columns:1fr !important}}

  </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">

<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="admin-shell bm-admin-unified">
<div class="container">
  <div class="header">
    <div class="logo">مدیریت کالکشن‌ها</div>
    <div class="nav-links">
      <button class="btn-new-collection" id="showAddCollectionBtn">کالکشن جدید</button>
      <a href="admin_slider.php" class="back-link">مدیریت اسلایدر</a>
      <a href="admin.php" class="back-link">بازگشت به پنل اصلی</a>
    </div>
  </div>
  <?php
    $bmCollectionTotal = count($collections);
    $bmCollectionActive = count(array_filter($collections, static fn($c) => !empty($c['status'])));
    $bmCollectionMovies = array_sum(array_map(static fn($c) => (int)($c['movie_count'] ?? 0), $collections));
  ?>
  <div class="bm-admin-kpis">
    <div class="bm-admin-kpi"><small>کل کالکشن‌ها</small><strong><?= number_format($bmCollectionTotal) ?></strong></div>
    <div class="bm-admin-kpi"><small>کالکشن فعال</small><strong><?= number_format($bmCollectionActive) ?></strong></div>
    <div class="bm-admin-kpi"><small>فیلم‌های متصل</small><strong><?= number_format($bmCollectionMovies) ?></strong></div>
    <div class="bm-admin-kpi"><small>وضعیت مدیریت</small><strong style="font-size:15px;color:#bbf7d0">آماده و همگام</strong></div>
  </div>
  
  <?php if($message): ?>
  <div class="toast" id="toast"><?= admin_escape($message) ?></div>
  <script>setTimeout(()=>document.getElementById('toast')?.remove(),4000);</script>
  <?php endif; ?>
  <?php if($error): ?>
  <div class="toast" id="error-toast" style="background:#7f1d1d;border-color:#fb7185;"><?= admin_escape($error) ?></div>
  <script>setTimeout(()=>document.getElementById('error-toast')?.remove(),7000);</script>
  <?php endif; ?>
  
  <!-- فرم افزودن کالکشن جدید (قابل نمایش/مخفی با دکمه) -->
  <div id="addCollectionForm" class="add-collection-form">
    <h2 style="margin-bottom:16px;"> افزودن کالکشن جدید</h2>
    <form method="POST" enctype="multipart/form-data" id="newCollectionForm">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="save_collection" value="1">
      <input type="hidden" name="id" value="0">
      <div class="form-grid">
        <div class="form-group"><label>عنوان (انگلیسی) *</label><input type="text" name="title" required></div>
        <div class="form-group"><label>عنوان (فارسی)</label><input type="text" name="title_fa"></div>
        <div class="form-group"><label>اسلاگ (slug) *</label><input type="text" name="slug" placeholder="مثال: joker-collection" required></div>
        <div class="form-group"><label>وضعیت</label><label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="status" value="1" checked> فعال</label></div>
      </div>
      <div class="form-group"><label>توضیحات</label><textarea name="description" rows="3" placeholder="توضیحات این کالکشن..."></textarea></div>
      <div class="form-group"><label>کاور کالکشن (اختیاری)</label><input type="file" name="cover_image" accept="image/jpeg,image/png,image/webp" id="newCoverInput"></div>
      <div style="display:flex; gap:12px; margin-top:16px;">
        <button type="submit" class="btn"> ذخیره کالکشن</button>
        <button type="button" id="cancelAddCollection" class="btn-secondary">انصراف</button>
      </div>
    </form>
  </div>
  
  <!-- فرم ویرایش کالکشن (اگر در حال ویرایش باشد) -->
  <?php if($editCollection): ?>
  <div class="card">
    <h2> ویرایش کالکشن: <?= htmlspecialchars($editCollection['title_fa'] ?: $editCollection['title']) ?></h2>
    <form method="POST" enctype="multipart/form-data" id="editCollectionForm">
      <?= admin_csrf_input() ?>
      <input type="hidden" name="save_collection" value="1">
      <input type="hidden" name="id" value="<?= $editCollection['id'] ?>">
      <div class="form-grid">
        <div class="form-group"><label>عنوان (انگلیسی) *</label><input type="text" name="title" value="<?= htmlspecialchars($editCollection['title'] ?? '') ?>" required></div>
        <div class="form-group"><label>عنوان (فارسی)</label><input type="text" name="title_fa" value="<?= htmlspecialchars($editCollection['title_fa'] ?? '') ?>"></div>
        <div class="form-group"><label>اسلاگ (slug) *</label><input type="text" name="slug" value="<?= htmlspecialchars($editCollection['slug'] ?? '') ?>" placeholder="مثال: joker-collection" required></div>
        <div class="form-group"><label>وضعیت</label><label style="display:flex;align-items:center;gap:8px;"><input type="checkbox" name="status" value="1" <?= (!isset($editCollection) || $editCollection['status']) ? 'checked' : '' ?>> فعال</label></div>
      </div>
      <div class="form-group"><label>توضیحات</label><textarea name="description" rows="3"><?= htmlspecialchars($editCollection['description'] ?? '') ?></textarea></div>
      <div class="form-group"><label>کاور کالکشن (اختیاری)</label><input type="file" name="cover_image" accept="image/jpeg,image/png,image/webp" id="editCoverInput"></div>
      <?php if($editCollection && !empty($editCollection['cover_image']) && bm_public_asset_renderable($editCollection['cover_image'])): ?>
      <div style="margin-bottom:16px;"><img src="<?= admin_escape(bm_public_asset_url($editCollection['cover_image'])) ?>" style="width:100px;height:150px;border-radius:16px;object-fit:cover;" id="previewImg"><br><small style="color:#888;">کاور فعلی</small></div>
      <?php endif; ?>
      <button type="submit" class="btn"> ذخیره تغییرات</button>
      <a href="admin_collections.php" class="btn-secondary" style="text-decoration:none; display:inline-block; margin-right:12px;">انصراف</a>
    </form>
  </div>
  <?php endif; ?>
  
  <!-- مدیریت فیلم‌های کالکشن (هنگام ویرایش) -->
  <?php if($editCollection): ?>
  <div class="card">
    <h2> فیلم‌های کالکشن: <?= htmlspecialchars($editCollection['title_fa'] ?: $editCollection['title']) ?></h2>
    
    <!-- لایو سرچ پیشرفته -->
    <div class="search-movies">
      <input type="text" id="movieSearchInput" class="search-input" placeholder="Search movie by English title, Persian title or IMDb...">
      <div class="search-results" id="movieSearchResults"></div>
    </div>
    
    <!-- لیست فیلم‌های کالکشن با قابلیت drag & drop -->
    <div class="movie-list-manager" id="moviesSortableList">
      <?php if(count($collectionMovies) > 0): ?>
        <?php foreach($collectionMovies as $item): ?>
        <div class="movie-item bm-collection-movie-row" data-id="<?= $item['id'] ?>" data-movie-id="<?= $item['movie_id'] ?>">
          <div class="bm-collection-movie-main">
            <span class="drag-handle" title="جابجایی"></span>
            <img class="bm-collection-movie-poster" src="/posters/<?= htmlspecialchars((string)$item['imdb_code'], ENT_QUOTES, 'UTF-8') ?>.webp" alt="<?= htmlspecialchars((string)$item['title'], ENT_QUOTES, 'UTF-8') ?>" loading="lazy" onerror="this.onerror=null;this.src='/uploads/no.png'">
            <div class="bm-collection-movie-copy">
              <strong dir="ltr"><?= htmlspecialchars((string)$item['title'], ENT_QUOTES, 'UTF-8') ?></strong>
              <?php if(!empty($item['title_fa'])): ?><small><?= htmlspecialchars((string)$item['title_fa'], ENT_QUOTES, 'UTF-8') ?></small><?php endif; ?>
              <span class="bm-collection-movie-meta"><b><?= htmlspecialchars((string)($item['year'] ?: '—'), ENT_QUOTES, 'UTF-8') ?></b><i>IMDb <?= htmlspecialchars((string)($item['imdb_rate'] ?: '—'), ENT_QUOTES, 'UTF-8') ?></i><code><?= htmlspecialchars((string)$item['imdb_code'], ENT_QUOTES, 'UTF-8') ?></code></span>
            </div>
          </div>
          <button class="btn-danger remove-movie-btn" data-movie-id="<?= $item['movie_id'] ?>">حذف</button>
        </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div style="text-align:center;padding:40px;color:#888;">هنوز فیلمی به این کالکشن اضافه نشده است</div>
      <?php endif; ?>
    </div>
    <div style="margin-top:16px;font-size:12px;color:#888;"> نکته: می‌توانید فیلم‌ها را با کشیدن و رها کردن (drag & drop) مرتب کنید.</div>
  </div>
  <?php endif; ?>
  
  <!-- لیست همه کالکشن‌ها -->
  <div class="card">
    <div class="bm-admin-section-title"><div><h2>همه کالکشن‌ها</h2><p>مدیریت سریع وضعیت، تعداد فیلم‌ها، مشاهده و ویرایش هر کالکشن</p></div><span class="badge"><?= count($collections) ?> مورد</span></div>
    <div class="bm-admin-table-wrap">
      <table class="bm-collection-table">
        <thead><tr><th>کاور</th><th>عنوان</th><th>اسلاگ</th><th>تعداد فیلم</th><th>وضعیت</th><th>آخرین بروزرسانی</th><th>عملیات</th></tr></thead>
        <tbody>
        <?php foreach($collections as $col): ?>
          <tr>
            <td>
              <?php if(!empty($col['cover_image']) && bm_public_asset_renderable($col['cover_image'])): ?>
                <img class="bm-collection-cover" src="<?= admin_escape(bm_public_asset_url($col['cover_image'])) ?>" alt="">
              <?php else: ?><span class="bm-collection-cover" style="display:grid;place-items:center;color:#64748b">—</span><?php endif; ?>
            </td>
            <td><div class="bm-admin-title-stack"><strong><?= htmlspecialchars($col['title_fa'] ?: $col['title']) ?></strong><small><?= htmlspecialchars($col['title'] ?? '') ?></small></div></td>
            <td><code style="direction:ltr;color:#93c5fd"><?= admin_escape($col['slug']) ?></code></td>
            <td><span class="badge"><?= (int)($col['movie_count'] ?? 0) ?> فیلم</span></td>
            <td><span class="bm-collection-status <?= !empty($col['status']) ? 'on':'off' ?>"><?= !empty($col['status']) ? 'فعال':'غیرفعال' ?></span></td>
            <td style="color:#94a3b8"><?= admin_escape($col['updated_at'] ?? $col['created_at'] ?? '—') ?></td>
            <td><div class="bm-admin-actions">
              <a href="?edit=<?= (int)$col['id'] ?>" class="btn btn-secondary">ویرایش</a>
              <a href="/collection/<?= rawurlencode((string)$col['slug']) ?>" class="btn btn-secondary" target="_blank">مشاهده</a>
              <form method="post" onsubmit="return confirm('کالکشن و تمام ارتباط فیلم‌های آن حذف شود؟')">
                <?= admin_csrf_input() ?><input type="hidden" name="delete_collection" value="1"><input type="hidden" name="id" value="<?= (int)$col['id'] ?>">
                <button type="submit" class="btn-danger">حذف</button>
              </form>
            </div></td>
          </tr>
        <?php endforeach; ?>
        <?php if(!$collections): ?><tr><td colspan="7" style="text-align:center;color:#64748b">هنوز کالکشنی ساخته نشده است.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<script>
const collectionId = <?= (int)($editCollection['id'] ?? 0) ?>;
const csrfToken = <?= json_encode($csrf_token, JSON_UNESCAPED_UNICODE) ?>;
const existingMovieIds = new Set(<?= json_encode(array_map('intval', array_column($collectionMovies, 'movie_id'))) ?>.map(String));
const showAddBtn = document.getElementById('showAddCollectionBtn');
const addForm = document.getElementById('addCollectionForm');
const cancelAddBtn = document.getElementById('cancelAddCollection');

if (showAddBtn && addForm) {
  showAddBtn.addEventListener('click', () => addForm.classList.toggle('show'));
}
if (cancelAddBtn && addForm) {
  cancelAddBtn.addEventListener('click', () => {
    addForm.classList.remove('show');
    document.getElementById('newCollectionForm')?.reset();
  });
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[char]));
}
function showToast(message, isError = false) {
  document.querySelector('.runtime-toast')?.remove();
  const toast = document.createElement('div');
  toast.className = 'toast runtime-toast';
  if (isError) toast.style.cssText = 'background:#7f1d1d;border-color:#fb7185;';
  toast.textContent = message;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), isError ? 6000 : 3000);
}
async function postCollectionAction(fields) {
  const formData = new FormData();
  formData.append('csrf_token', csrfToken);
  Object.entries(fields).forEach(([key, value]) => formData.append(key, String(value)));
  const response = await fetch('admin_collections.php' + (collectionId ? '?edit=' + collectionId : ''), {
    method: 'POST', body: formData, credentials: 'same-origin', headers: {'X-CSRF-Token': csrfToken}
  });
  let result;
  try { result = await response.json(); }
  catch (_) { throw new Error('پاسخ نامعتبر از سرور دریافت شد.'); }
  if (!response.ok || !result.success) throw new Error(result.message || 'عملیات انجام نشد.');
  return result;
}

const searchInput = document.getElementById('movieSearchInput');
const searchResults = document.getElementById('movieSearchResults');
let searchTimeout = null;
if (searchInput && searchResults && collectionId > 0) {
  searchInput.addEventListener('input', function () {
    const term = this.value.trim();
    clearTimeout(searchTimeout);
    if (term.length < 2) { searchResults.style.display = 'none'; searchResults.innerHTML = ''; return; }
    searchResults.style.display = 'block';
    searchResults.innerHTML = '<div style="padding:20px;text-align:center;color:#888">جستجو...</div>';
    searchTimeout = setTimeout(async () => {
      try {
        const response = await fetch('ajax.php?action=search&term=' + encodeURIComponent(term) + '&limit=20', {credentials:'same-origin'});
        const data = await response.json();
        const movies = Array.isArray(data.data) ? data.data : [];
        const available = movies.filter(movie => !existingMovieIds.has(String(movie.id)));
        if (!available.length) {
          searchResults.innerHTML = '<div style="padding:20px;text-align:center;color:#888">نتیجه جدیدی یافت نشد</div>';
          return;
        }
        searchResults.innerHTML = available.map(movie => {
          const imdb = String(movie.imdb_code || '').trim();
          const poster = imdb ? `/posters/${encodeURIComponent(imdb)}.webp` : '/uploads/no.png';
          const titleEn = String(movie.title || movie.title_fa || 'Untitled');
          const titleFa = String(movie.title_fa || '');
          return `
          <div class="search-result-item bm-collection-search-result">
            <img class="bm-collection-search-poster" src="${escapeHtml(poster)}" alt="" loading="lazy" onerror="this.onerror=null;this.src='/uploads/no.png'">
            <div class="bm-collection-search-copy">
              <strong dir="ltr">${escapeHtml(titleEn)}</strong>
              ${titleFa && titleFa !== titleEn ? `<small>${escapeHtml(titleFa)}</small>` : ''}
              <span><b>${escapeHtml(movie.year || '—')}</b><i>IMDb ${escapeHtml(movie.imdb_rate || '—')}</i>${imdb ? `<code>${escapeHtml(imdb)}</code>` : ''}</span>
            </div>
            <button type="button" class="add-movie-btn" data-id="${Number(movie.id)}">افزودن</button>
          </div>`;
        }).join('');
      } catch (error) {
        searchResults.innerHTML = '<div style="padding:20px;text-align:center;color:#ff8888">خطا در جستجو</div>';
      }
    }, 350);
  });

  searchResults.addEventListener('click', async event => {
    const button = event.target.closest('.add-movie-btn');
    if (!button) return;
    button.disabled = true;
    try {
      const result = await postCollectionAction({ajax_action:'add_movie', collection_id:collectionId, movie_id:button.dataset.id});
      showToast(result.message);
      setTimeout(() => location.reload(), 350);
    } catch (error) {
      button.disabled = false;
      showToast(error.message, true);
    }
  });
  document.addEventListener('click', event => {
    if (!searchInput.contains(event.target) && !searchResults.contains(event.target)) searchResults.style.display = 'none';
  });
}

document.querySelectorAll('.remove-movie-btn').forEach(button => {
  button.type = 'button';
  button.addEventListener('click', async () => {
    if (!confirm('این فیلم از کالکشن حذف شود؟')) return;
    button.disabled = true;
    try {
      const result = await postCollectionAction({ajax_action:'remove_movie', collection_id:collectionId, movie_id:button.dataset.movieId});
      showToast(result.message);
      button.closest('.movie-item')?.remove();
    } catch (error) {
      button.disabled = false;
      showToast(error.message, true);
    }
  });
});

async function saveMovieOrder(container) {
  const ids = [...container.querySelectorAll('.movie-item')].map(item => item.dataset.id);
  try {
    const result = await postCollectionAction({ajax_action:'reorder_movies', collection_id:collectionId, ids:JSON.stringify(ids)});
    showToast(result.message);
  } catch (error) { showToast(error.message, true); }
}
const container = document.getElementById('moviesSortableList');
if (container && collectionId > 0) {
  let dragged = null;
  container.querySelectorAll('.movie-item').forEach(item => {
    item.draggable = true;
    item.addEventListener('dragstart', event => { dragged = item; item.classList.add('dragging'); event.dataTransfer.effectAllowed = 'move'; });
    item.addEventListener('dragend', () => { item.classList.remove('dragging'); dragged = null; });
    item.addEventListener('dragover', event => event.preventDefault());
    item.addEventListener('drop', event => {
      event.preventDefault();
      if (!dragged || dragged === item) return;
      const items = [...container.querySelectorAll('.movie-item')];
      if (items.indexOf(dragged) < items.indexOf(item)) item.after(dragged); else item.before(dragged);
      saveMovieOrder(container);
    });
  });
}

function bindImagePreview(inputId, imageId, formSelector) {
  const input = document.getElementById(inputId);
  if (!input) return;
  input.addEventListener('change', () => {
    const file = input.files?.[0];
    if (!file) return;
    let image = imageId ? document.getElementById(imageId) : document.querySelector(formSelector + ' img');
    if (!image) {
      image = document.createElement('img');
      image.style.cssText = 'width:100px;height:150px;border-radius:16px;object-fit:cover;margin-top:10px;';
      input.parentElement.appendChild(image);
    }
    image.src = URL.createObjectURL(file);
    image.style.display = 'block';
  });
}
bindImagePreview('newCoverInput', null, '#addCollectionForm');
bindImagePreview('editCoverInput', 'previewImg', '#editCollectionForm');
</script>

<script>
window.ADMIN_CSRF_TOKEN = <?= json_encode($csrf_token ?? admin_csrf_token(), JSON_UNESCAPED_UNICODE) ?>;
(function(){
  function addCsrfToForms(){
    document.querySelectorAll('form').forEach(function(form){
      var method = (form.getAttribute('method') || 'GET').toUpperCase();
      if(method !== 'POST') return;
      if(!form.querySelector('input[name="csrf_token"]')){
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'csrf_token';
        input.value = window.ADMIN_CSRF_TOKEN;
        form.appendChild(input);
      }
    });
  }
  addCsrfToForms();
  document.addEventListener('DOMContentLoaded', addCsrfToForms);
  var nativeFetch = window.fetch;
  if(nativeFetch){
    window.fetch = function(resource, init){
      init = init || {};
      var method = (init.method || 'GET').toUpperCase();
      if(method === 'POST'){
        init.headers = new Headers(init.headers || {});
        init.headers.set('X-CSRF-Token', window.ADMIN_CSRF_TOKEN);
        if(init.body instanceof FormData && !init.body.has('csrf_token')){
          init.body.append('csrf_token', window.ADMIN_CSRF_TOKEN);
        } else if(typeof init.body === 'string' && init.headers.get('Content-Type') && init.headers.get('Content-Type').includes('application/x-www-form-urlencoded') && !init.body.includes('csrf_token=')){
          init.body += (init.body ? '&' : '') + 'csrf_token=' + encodeURIComponent(window.ADMIN_CSRF_TOKEN);
        }
      }
      return nativeFetch(resource, init);
    };
  }

    document.addEventListener('click', function(e){
        var a = e.target.closest && e.target.closest('a[href]');
        if(!a) return;
        var href = a.getAttribute('href') || '';
        var unsafe = ['delete_movie','delete_story','add_to_admin_pick','remove_from_admin_pick','approve_comment','reject_comment','delete_comment','delete_request','delete'];
        var hasUnsafe = unsafe.some(function(k){ return href.indexOf(k + '=') !== -1; });
        if(hasUnsafe && href.indexOf('csrf_token=') === -1){
            a.setAttribute('href', href + (href.indexOf('?') === -1 ? '?' : '&') + 'csrf_token=' + encodeURIComponent(window.ADMIN_CSRF_TOKEN));
        }
    }, true);
})();
</script>

<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>
