'use strict';
const BM_SW_VERSION = 'bankmovie-pwa-v131-1';
const BM_STATIC_CACHE = BM_SW_VERSION + '-static';
const BM_OFFLINE_URL = '/offline.html';
const BM_STATIC_SHELL = [
  BM_OFFLINE_URL,
  '/assets/icons/icon-192.png',
  '/assets/icons/icon-512.png',
  '/assets/brand/bankmovie-logo.webp'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(BM_STATIC_CACHE).then(cache => cache.addAll(BM_STATIC_SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys => Promise.all(keys.filter(key => key.startsWith('bankmovie-pwa-') && key !== BM_STATIC_CACHE).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

function isMediaRequest(request, url) {
  if (request.headers.has('range')) return true;
  if (request.destination === 'video' || request.destination === 'audio') return true;
  return /\.(?:mp4|mkv|webm|m3u8|mpd|ts|mov|avi|mp3|aac|m4a|vtt|srt)(?:$|\?)/i.test(url.pathname + url.search);
}

function isDynamicEndpoint(url) {
  return /\/(?:api\d*|app_api|app_user_api|ajax[^/]*|player|movie|login|logout|register|profile|admin[^/]*)\.php$/i.test(url.pathname)
    || /^\/(?:api|ajax|player|movie)(?:\/|$)/i.test(url.pathname);
}

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  // Never intercept streaming, range requests, player endpoints, APIs or authenticated dynamic actions.
  if (isMediaRequest(request, url) || isDynamicEndpoint(url)) return;

  if (request.mode === 'navigate') {
    event.respondWith(fetch(request).catch(() => caches.match(BM_OFFLINE_URL)));
    return;
  }

  const staticDestination = ['style','script','font','image'].includes(request.destination);
  const staticPath = /^\/assets\//.test(url.pathname) || /\.(?:css|js|woff2?|png|jpe?g|webp|gif|svg|ico)$/i.test(url.pathname);
  if (staticDestination || staticPath) {
    event.respondWith(
      caches.match(request).then(cached => {
        const update = fetch(request).then(response => {
          if (response && response.ok && response.type === 'basic') {
            const copy = response.clone();
            caches.open(BM_STATIC_CACHE).then(cache => cache.put(request, copy));
          }
          return response;
        }).catch(() => cached);
        return cached || update;
      })
    );
  }
});
