<?php
/**
 * BankMovie — Donyaye Serial JSON Importer
 * Reads cache/donyaye_series_matches.json and imports ONLY found items with links.
 * Safety rule: items not present in JSON, not found, or with empty links are NOT touched.
 */
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
$csrf = admin_csrf_token();
require_once __DIR__ . '/config.php';

const BM_DJI_JSON_REL = 'cache/donyaye_series_matches.json';

function bm_dji_e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function bm_dji_json_path(): string { return __DIR__ . '/' . BM_DJI_JSON_REL; }

function bm_dji_column_exists(PDO $pdo, string $table, string $column): bool {
    try {
        $stmt = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $stmt->execute([$column]);
        return (bool)$stmt->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) { return false; }
}

function bm_dji_ensure_episode_columns(PDO $pdo): bool {
    $ok = true;
    foreach (['softsub_links', 'dubbed_links'] as $table) {
        if (!bm_dji_column_exists($pdo, $table, 'episode')) {
            try {
                $after = bm_dji_column_exists($pdo, $table, 'season') ? ' AFTER `season`' : '';
                $pdo->exec("ALTER TABLE `$table` ADD COLUMN `episode` INT NULL DEFAULT NULL$after");
            } catch (Throwable $e) { $ok = false; }
        }
    }
    return bm_dji_column_exists($pdo, 'softsub_links', 'episode') && bm_dji_column_exists($pdo, 'dubbed_links', 'episode') && $ok;
}

function bm_dji_load_json(): array {
    $path = bm_dji_json_path();
    if (!is_file($path)) throw new RuntimeException('فایل JSON پیدا نشد: ' . BM_DJI_JSON_REL);
    $raw = (string)file_get_contents($path);
    if (trim($raw) === '') throw new RuntimeException('فایل JSON خالی است.');
    $data = json_decode($raw, true);
    if (!is_array($data)) throw new RuntimeException('JSON معتبر نیست: ' . json_last_error_msg());
    return $data;
}

function bm_dji_norm_imdb(string $imdb): string {
    $imdb = strtolower(trim($imdb));
    return preg_match('/^tt\d{6,10}$/', $imdb) ? $imdb : '';
}

function bm_dji_season_num($value): ?int {
    $value = (string)($value ?? '');
    if (preg_match('/S\s*(\d{1,2})/i', $value, $m)) return (int)$m[1];
    if (preg_match('/(\d{1,2})/', $value, $m)) return (int)$m[1];
    return null;
}

function bm_dji_episode_num($value): ?int {
    $value = (string)($value ?? '');
    if (preg_match('/E\s*(\d{1,3})/i', $value, $m)) return (int)$m[1];
    if (preg_match('/قسمت\s*(\d{1,3})/u', $value, $m)) return (int)$m[1];
    if (preg_match('/(\d{1,3})/', $value, $m)) return (int)$m[1];
    return null;
}

function bm_dji_extract_season_from_url(string $url): ?int {
    if (preg_match('~/S(\d{1,2})(?:/|\b)~i', $url, $m)) return (int)$m[1];
    if (preg_match('/\bS(\d{1,2})E\d{1,3}\b/i', $url, $m)) return (int)$m[1];
    return null;
}

function bm_dji_extract_episode_from_url(string $url): ?int {
    if (preg_match('/\bS\d{1,2}E(\d{1,3})\b/i', $url, $m)) return (int)$m[1];
    if (preg_match('/\bE(\d{1,3})\b/i', $url, $m)) return (int)$m[1];
    return null;
}

function bm_dji_format_season(?int $season): string {
    $season = $season ?: 1;
    return str_pad((string)$season, 2, '0', STR_PAD_LEFT);
}

function bm_dji_format_quality(string $url): string {
    $path = parse_url($url, PHP_URL_PATH) ?: $url;
    $segments = array_values(array_filter(explode('/', $path), 'strlen'));
    foreach ($segments as $i => $seg) {
        if (preg_match('/^S\d{1,2}$/i', $seg) && isset($segments[$i + 1])) {
            $q = $segments[$i + 1];
            $q = preg_replace('/\.(?=[A-Za-z])/', ' ', $q);
            $q = str_replace(['_', '-DL'], [' ', '-DL'], $q);
            $q = preg_replace('/\s+/', ' ', $q);
            return trim($q) ?: 'HD';
        }
    }
    if (preg_match('/(2160p|4K|1080p|720p|480p|360p)[\.\s-]*([A-Za-z0-9\.\- ]{0,40})/i', $path, $m)) {
        $q = trim(str_replace('.', ' ', $m[0]));
        $q = preg_replace('/\s+/', ' ', $q);
        return $q ?: 'HD';
    }
    return 'HD';
}

function bm_dji_detect_table(string $url): string {
    $hay = strtolower($url);
    if (strpos($hay, '/dubbed/') !== false || strpos($hay, 'dubbed') !== false || strpos($hay, 'dual.audio') !== false || strpos($hay, 'farsi.dubbed') !== false) {
        return 'dubbed_links';
    }
    return 'softsub_links';
}

function bm_dji_is_video_url(string $url): bool {
    if (!preg_match('~^https?://~i', $url)) return false;
    if (stripos($url, 'DonyayeSerial') !== false) return true;
    return (bool)preg_match('~\.(mkv|mp4|avi|mov|wmv|webm)(?:\?|$)~i', $url);
}

function bm_dji_flatten_links($node, string $imdb, string $title = '', $seasonHint = null, $episodeHint = null): array {
    $rows = [];
    if (is_string($node)) {
        $url = trim(html_entity_decode($node, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
        if (bm_dji_is_video_url($url)) {
            $season = $seasonHint ?: bm_dji_extract_season_from_url($url) ?: 1;
            $episode = $episodeHint ?: bm_dji_extract_episode_from_url($url);
            $rows[] = [
                'imdb_code' => $imdb,
                'title' => $title,
                'table' => bm_dji_detect_table($url),
                'season' => bm_dji_format_season($season),
                'episode' => $episode,
                'quality' => bm_dji_format_quality($url),
                'url' => $url,
                'size' => '',
                'is_folder' => 0,
            ];
        }
        return $rows;
    }
    if (!is_array($node)) return [];

    foreach ($node as $key => $value) {
        $sHint = $seasonHint;
        $eHint = $episodeHint;
        $k = (string)$key;
        if (preg_match('/^S\d{1,2}$/i', $k)) $sHint = bm_dji_season_num($k) ?: $sHint;
        if (preg_match('/^E\d{1,3}$/i', $k)) $eHint = bm_dji_episode_num($k) ?: $eHint;
        if ($key === 'links') {
            $rows = array_merge($rows, bm_dji_flatten_links($value, $imdb, $title, $sHint, $eHint));
        } elseif ($key === 'seasons') {
            $rows = array_merge($rows, bm_dji_flatten_links($value, $imdb, $title, $sHint, $eHint));
        } elseif (is_int($key) || is_array($value) || is_string($value)) {
            $rows = array_merge($rows, bm_dji_flatten_links($value, $imdb, $title, $sHint, $eHint));
        }
    }
    return $rows;
}

function bm_dji_normalize_json_items(array $json): array {
    $items = [];

    // Final desired shape: { "tt123": {"title":"...", "seasons": {...}} }
    foreach ($json as $key => $value) {
        $imdb = bm_dji_norm_imdb((string)$key);
        if ($imdb === '') continue;
        $title = is_array($value) ? (string)($value['title'] ?? '') : '';
        $rows = bm_dji_flatten_links(is_array($value) && array_key_exists('seasons', $value) ? $value['seasons'] : $value, $imdb, $title);
        if (!isset($items[$imdb])) $items[$imdb] = ['title' => $title, 'rows' => []];
        $items[$imdb]['title'] = $items[$imdb]['title'] ?: $title;
        $items[$imdb]['rows'] = array_merge($items[$imdb]['rows'], $rows);
    }

    // Older shapes: {items:[{imdb_code, links...}]}
    if (isset($json['items']) && is_array($json['items'])) {
        foreach ($json['items'] as $it) {
            if (!is_array($it)) continue;
            $imdb = bm_dji_norm_imdb((string)($it['imdb_code'] ?? ''));
            if ($imdb === '') continue;
            $title = (string)($it['title'] ?? ($it['local']['title'] ?? ''));
            $rows = bm_dji_flatten_links($it, $imdb, $title);
            if (!isset($items[$imdb])) $items[$imdb] = ['title' => $title, 'rows' => []];
            $items[$imdb]['title'] = $items[$imdb]['title'] ?: $title;
            $items[$imdb]['rows'] = array_merge($items[$imdb]['rows'], $rows);
        }
    }

    foreach ($items as $imdb => &$item) {
        $seen = [];
        $clean = [];
        foreach ($item['rows'] as $row) {
            $url = $row['url'] ?? '';
            if (!$url || isset($seen[$url])) continue;
            $seen[$url] = true;
            $clean[] = $row;
        }
        $item['rows'] = $clean;
    }
    unset($item);

    return $items;
}

function bm_dji_find_movie(PDO $pdo, string $imdb): ?array {
    $stmt = $pdo->prepare("SELECT id, imdb_code, title, title_fa, type FROM movies WHERE imdb_code = ? LIMIT 1");
    $stmt->execute([$imdb]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function bm_dji_analyze(PDO $pdo, array $items): array {
    $stats = [
        'json_items' => count($items),
        'with_links' => 0,
        'matched_movies' => 0,
        'will_replace_movies' => 0,
        'will_insert_links' => 0,
        'skipped_empty' => 0,
        'skipped_no_movie' => 0,
        'sample' => [],
    ];
    foreach ($items as $imdb => $item) {
        $rows = $item['rows'] ?? [];
        if (!$rows) { $stats['skipped_empty']++; continue; }
        $stats['with_links']++;
        $movie = bm_dji_find_movie($pdo, $imdb);
        if (!$movie) { $stats['skipped_no_movie']++; continue; }
        $stats['matched_movies']++;
        $stats['will_replace_movies']++;
        $stats['will_insert_links'] += count($rows);
        if (count($stats['sample']) < 20) {
            $stats['sample'][] = [
                'id' => (int)$movie['id'],
                'imdb_code' => $imdb,
                'title' => $movie['title'] ?: ($item['title'] ?? ''),
                'title_fa' => $movie['title_fa'] ?? '',
                'links' => count($rows),
            ];
        }
    }
    return $stats;
}

function bm_dji_import(PDO $pdo, array $items, bool $dryRun = true): array {
    $hasEpisode = bm_dji_ensure_episode_columns($pdo);
    $stats = bm_dji_analyze($pdo, $items);
    $stats['dry_run'] = $dryRun;
    $stats['episode_column'] = $hasEpisode;
    $stats['deleted_old_links'] = 0;
    $stats['inserted_softsub'] = 0;
    $stats['inserted_dubbed'] = 0;
    $stats['logs'] = [];

    if ($dryRun) return $stats;

    foreach ($items as $imdb => $item) {
        $rows = $item['rows'] ?? [];
        if (!$rows) continue; // IMPORTANT: empty/not found items are untouched.
        $movie = bm_dji_find_movie($pdo, $imdb);
        if (!$movie) continue; // untouched because no BankMovie movie match.
        $movieId = (int)$movie['id'];

        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM softsub_links WHERE movie_id = ?");
            $stmt->execute([$movieId]);
            $oldSoft = (int)$stmt->fetchColumn();
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM dubbed_links WHERE movie_id = ?");
            $stmt->execute([$movieId]);
            $oldDub = (int)$stmt->fetchColumn();

            // Replace only found items with valid links.
            $pdo->prepare("DELETE FROM softsub_links WHERE movie_id = ?")->execute([$movieId]);
            $pdo->prepare("DELETE FROM dubbed_links WHERE movie_id = ?")->execute([$movieId]);
            $stats['deleted_old_links'] += $oldSoft + $oldDub;

            if ($hasEpisode) {
                $insSoft = $pdo->prepare("INSERT INTO softsub_links (movie_id, quality, url, size, season, episode, is_folder) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $insDub  = $pdo->prepare("INSERT INTO dubbed_links (movie_id, quality, url, size, season, episode, is_folder) VALUES (?, ?, ?, ?, ?, ?, ?)");
            } else {
                $insSoft = $pdo->prepare("INSERT INTO softsub_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)");
                $insDub  = $pdo->prepare("INSERT INTO dubbed_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)");
            }

            foreach ($rows as $row) {
                $table = $row['table'] === 'dubbed_links' ? 'dubbed_links' : 'softsub_links';
                $quality = (string)($row['quality'] ?? 'HD');
                $url = (string)$row['url'];
                $size = (string)($row['size'] ?? '');
                $season = (string)($row['season'] ?? '01');
                $episode = isset($row['episode']) ? (int)$row['episode'] : null;
                if ($hasEpisode) {
                    $params = [$movieId, $quality, $url, $size, $season, $episode, 0];
                } else {
                    $displayQuality = $episode ? ('S' . $season . 'E' . str_pad((string)$episode, 2, '0', STR_PAD_LEFT) . ' - ' . $quality) : $quality;
                    $params = [$movieId, $displayQuality, $url, $size, $season, 0];
                }
                if ($table === 'dubbed_links') { $insDub->execute($params); $stats['inserted_dubbed']++; }
                else { $insSoft->execute($params); $stats['inserted_softsub']++; }
            }

            $pdo->commit();
            $stats['logs'][] = "OK #$movieId $imdb — حذف قدیمی: " . ($oldSoft + $oldDub) . " / درج جدید: " . count($rows);
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $stats['logs'][] = "ERROR #$movieId $imdb — " . $e->getMessage();
        }
    }
    return $stats;
}

$message = '';
$error = '';
$result = null;
try {
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        admin_enforce_csrf();
        $json = bm_dji_load_json();
        $items = bm_dji_normalize_json_items($json);
        $action = (string)($_POST['action'] ?? 'preview');
        if ($action === 'import') {
            $result = bm_dji_import($pdo, $items, false);
            $message = 'ایمپورت انجام شد. فقط سریال‌های موجود در JSON که لینک معتبر داشتند جایگزین شدند.';
        } else {
            $result = bm_dji_import($pdo, $items, true);
            $message = 'Preview آماده شد. هنوز دیتابیس تغییر نکرده است.';
        }
    } else {
        if (is_file(bm_dji_json_path())) {
            $json = bm_dji_load_json();
            $items = bm_dji_normalize_json_items($json);
            $result = bm_dji_import($pdo, $items, true);
        }
    }
} catch (Throwable $e) { $error = $e->getMessage(); }

$path = bm_dji_json_path();
$exists = is_file($path);
$size = $exists ? filesize($path) : 0;
$mtime = $exists ? date('Y-m-d H:i:s', filemtime($path)) : '—';
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ایمپورت JSON دنیای سریال</title>
<style>
body{font-family:Tahoma,Arial,sans-serif;background:#0b0d12;color:#f1f3f8;margin:0;padding:22px}.wrap{max-width:1180px;margin:auto}.card{background:#121720;border:1px solid rgba(255,255,255,.09);border-radius:18px;padding:18px;margin:14px 0}.top{display:flex;justify-content:space-between;gap:12px;align-items:center}.btn{border:0;border-radius:12px;padding:11px 15px;font-weight:800;cursor:pointer;background:#36ff9f;color:#06120b;text-decoration:none;display:inline-block}.btn.warn{background:#ffb84d}.btn.danger{background:#ff4d6d;color:#fff}.btn.secondary{background:#232b38;color:#dce3f1}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}.stat{background:#0c1018;border:1px solid rgba(255,255,255,.08);border-radius:15px;padding:13px;color:#9ca8ba}.stat b{display:block;color:#fff;font-size:23px;margin-top:6px}.msg{background:rgba(54,255,159,.1);border:1px solid rgba(54,255,159,.3);padding:12px;border-radius:12px;color:#9bffd0}.err{background:rgba(255,77,109,.1);border:1px solid rgba(255,77,109,.3);padding:12px;border-radius:12px;color:#ffbdc8}table{width:100%;border-collapse:collapse}td,th{border-bottom:1px solid rgba(255,255,255,.08);padding:10px;text-align:right}th{color:#36ff9f}.muted{color:#9aa3b6;font-size:12px}.log{max-height:280px;overflow:auto;background:#080b10;border-radius:14px;padding:12px;color:#d5dbea;direction:ltr;text-align:left;white-space:pre-wrap}.ltr{direction:ltr;text-align:left}.note{line-height:1.9;color:#d5dbea}@media(max-width:900px){.grid{grid-template-columns:1fr 1fr}.top{display:block}.btn{width:100%;box-sizing:border-box;margin:5px 0}table{display:block;overflow:auto}}
</style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <div><h1>ایمپورت JSON دنیای سریال</h1><p class="muted">فقط سریال‌هایی که داخل JSON لینک معتبر دارند جایگزین می‌شوند؛ پیدا نشده‌ها و بدون‌لینک‌ها دست نمی‌خورند.</p></div>
    <div><a class="btn secondary" href="admin.php">بازگشت به ادمین</a> <a class="btn secondary" href="<?= bm_dji_e(BM_DJI_JSON_REL) ?>" target="_blank">مشاهده JSON</a></div>
  </div>

  <?php if($message): ?><div class="msg"><?= bm_dji_e($message) ?></div><?php endif; ?>
  <?php if($error): ?><div class="err"><?= bm_dji_e($error) ?></div><?php endif; ?>

  <div class="card note">
    <b>قانون امن ایمپورت:</b><br>
    اول برای هر IMDb داخل JSON، فیلم/سریال متناظر در جدول <span class="ltr">movies.imdb_code</span> پیدا می‌شود. اگر برای آن IMDb لینک معتبر وجود داشت، لینک‌های قبلی همان <span class="ltr">movie_id</span> از <span class="ltr">softsub_links</span> و <span class="ltr">dubbed_links</span> حذف می‌شوند و لینک‌های قسمت‌بندی‌شده جدید درج می‌شوند. اگر IMDb در JSON نبود، یا لینک نداشت، یا در دیتابیس پیدا نشد، هیچ لینک قدیمی‌ای حذف نمی‌شود.
  </div>

  <div class="grid">
    <div class="stat">JSON <b><?= $exists ? 'هست' : 'نیست' ?></b><span class="muted ltr"><?= bm_dji_e(BM_DJI_JSON_REL) ?></span></div>
    <div class="stat">حجم JSON <b><?= $exists ? number_format($size/1024,1).' KB' : '—' ?></b><span class="muted">آخرین تغییر: <?= bm_dji_e($mtime) ?></span></div>
    <div class="stat">ستون episode <b><?= (bm_dji_column_exists($pdo,'softsub_links','episode') && bm_dji_column_exists($pdo,'dubbed_links','episode')) ? 'هست' : 'نیست/ساخته می‌شود' ?></b></div>
    <div class="stat">حالت <b><?= !empty($result['dry_run']) ? 'Preview' : 'Import' ?></b></div>
  </div>

  <?php if($result): ?>
  <div class="grid">
    <div class="stat">آیتم‌های JSON <b><?= number_format((int)$result['json_items']) ?></b></div>
    <div class="stat">دارای لینک <b><?= number_format((int)$result['with_links']) ?></b></div>
    <div class="stat">سریال قابل جایگزینی <b><?= number_format((int)$result['will_replace_movies']) ?></b></div>
    <div class="stat">لینک آماده درج <b><?= number_format((int)$result['will_insert_links']) ?></b></div>
  </div>
  <div class="grid">
    <div class="stat">حذف قدیمی <b><?= number_format((int)($result['deleted_old_links'] ?? 0)) ?></b></div>
    <div class="stat">درج زیرنویس/سافت <b><?= number_format((int)($result['inserted_softsub'] ?? 0)) ?></b></div>
    <div class="stat">درج دوبله <b><?= number_format((int)($result['inserted_dubbed'] ?? 0)) ?></b></div>
    <div class="stat">Skip بدون لینک/بدون فیلم <b><?= number_format((int)$result['skipped_empty'] + (int)$result['skipped_no_movie']) ?></b></div>
  </div>
  <?php endif; ?>

  <div class="card">
    <form method="post" style="display:inline-block;margin-left:8px">
      <input type="hidden" name="csrf_token" value="<?= bm_dji_e($csrf) ?>">
      <input type="hidden" name="action" value="preview">
      <button class="btn secondary" type="submit">Preview / بررسی بدون تغییر دیتابیس</button>
    </form>
    <form method="post" style="display:inline-block" onsubmit="return confirm('مطمئنی؟ فقط آیتم‌های پیدا شده با لینک معتبر جایگزین می‌شوند، اما لینک‌های قبلی همان سریال‌ها حذف خواهند شد.');">
      <input type="hidden" name="csrf_token" value="<?= bm_dji_e($csrf) ?>">
      <input type="hidden" name="action" value="import">
      <button class="btn danger" type="submit">ایمپورت واقعی و جایگزینی لینک‌های سریال‌های پیدا شده</button>
    </form>
  </div>

  <?php if(!empty($result['sample'])): ?>
  <div class="card">
    <h2>نمونه سریال‌هایی که جایگزین می‌شوند</h2>
    <table><thead><tr><th>ID</th><th>IMDb</th><th>Title</th><th>عنوان فارسی</th><th>تعداد لینک</th></tr></thead><tbody>
    <?php foreach($result['sample'] as $s): ?>
      <tr><td><?= (int)$s['id'] ?></td><td class="ltr"><?= bm_dji_e($s['imdb_code']) ?></td><td><?= bm_dji_e($s['title']) ?></td><td><?= bm_dji_e($s['title_fa']) ?></td><td><?= number_format((int)$s['links']) ?></td></tr>
    <?php endforeach; ?>
    </tbody></table>
  </div>
  <?php endif; ?>

  <?php if(!empty($result['logs'])): ?>
  <div class="card"><h2>Log</h2><div class="log"><?= bm_dji_e(implode("\n", $result['logs'])) ?></div></div>
  <?php endif; ?>
</div>
</body>
</html>
