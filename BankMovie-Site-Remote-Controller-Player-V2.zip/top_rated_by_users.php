<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// /top_rated_by_users - صفحه محبوب‌ترین فیلم‌ها و سریال‌ها با هدر/فوتر یکسان /search
require_once 'config.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$currentUser = $currentUser ?? null;
if (!$currentUser && isset($_COOKIE['session_token'])) {
    try {
        $userObj = new User($pdo);
        $currentUser = $userObj->checkSession($_COOKIE['session_token']) ?: null;
    } catch (Throwable $e) {
        $currentUser = null;
    }
}

$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang = $_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa');
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green' => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض', 'name_en' => 'Default Blue'],
    'dark-blue' => ['primary' => '#3b82f6', 'name' => 'آبی مشکی', 'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی', 'name_en' => 'Dark Purple'],
    'dark-pink' => ['primary' => '#ec4899', 'name' => 'صورتی مشکی', 'name_en' => 'Dark Pink'],
    'dark-red' => ['primary' => '#ef4444', 'name' => 'قرمز مشکی', 'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan' => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white' => ['primary' => '#ffffff', 'name' => 'سفید مشکی', 'name_en' => 'Dark White'],
    'dark-black' => ['primary' => '#888888', 'name' => 'دارک مطلق', 'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) {
    $userTheme = 'dark-green';
}
$currentTheme = $themes[$userTheme];
$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) {
    $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
}
$currentThemeRgbCss = hexdec(substr($themeHex, 0, 2)) . ',' . hexdec(substr($themeHex, 2, 2)) . ',' . hexdec(substr($themeHex, 4, 2));

$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

if (!function_exists('e')) {
    function e($str) {
        return htmlspecialchars((string)($str ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}

$t = [
    'fa' => [
        'home' => 'خانه', 'search' => 'جستجو', 'profile' => 'پروفایل', 'player' => 'پلیر', 'request' => 'درخواست فیلم و سریال',
        'auth' => 'ثبت نام و ورود', 'account' => 'حساب کاربری', 'login' => 'ورود', 'register' => 'ثبت نام', 'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت', 'notifications' => 'اعلان‌ها', 'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'donate' => 'حمایت مالی', 'support_us' => 'حمایت مالی',
        'support_text' => 'تمام خدمات سایت رایگان است. اگر از بانک مووی راضی هستید، با یک حمایت کوچک به هزینه‌های سرور و توسعه کمک کنید.',
        'close' => 'بستن', 'back' => 'بازگشت'
    ],
    'en' => [
        'home' => 'Home', 'search' => 'Search', 'profile' => 'Profile', 'player' => 'Player', 'request' => 'Request Movie / Series',
        'auth' => 'Login / Register', 'account' => 'Account', 'login' => 'Login', 'register' => 'Register', 'logout' => 'Logout',
        'admin_panel' => 'Admin Panel', 'notifications' => 'Notifications', 'no_notifications' => 'No notifications',
        'donate' => 'Donate', 'support_us' => 'Support Us',
        'support_text' => 'All services are free. If you like BankMovie, you can support server and development costs.',
        'close' => 'Close', 'back' => 'Back'
    ]
];

// دریافت اعلان‌ها
$notificationsList = [];
$latestNotification = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active = 1 AND expires_at > NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $latestNotification = $notificationsList[0] ?? null;
} catch (Throwable $e) {
    $notificationsList = [];
    $latestNotification = null;
}

// صفحه‌بندی
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 24;
$offset = ($page - 1) * $perPage;

// دریافت فیلم‌های برتر بر اساس امتیاز کاربران
$movies = [];
$total = 0;
try {
    // ابتدا از جدول movie_ratings
    $stmt = $pdo->prepare("
        SELECT m.*, 
            COALESCE(r.avg_rating, 0) as user_rating,
            COALESCE(r.total_votes, 0) as total_votes
        FROM movies m
        LEFT JOIN movie_ratings r ON m.id = r.movie_id
        WHERE COALESCE(r.total_votes, 0) > 0
        ORDER BY COALESCE(r.avg_rating, 0) DESC, COALESCE(r.total_votes, 0) DESC
        LIMIT ? OFFSET ?
    ");
    $stmt->execute([$perPage, $offset]);
    $movies = $stmt->fetchAll();
    
    // شمارش کل
    $stmt = $pdo->query("
        SELECT COUNT(DISTINCT m.id) as total
        FROM movies m
        LEFT JOIN movie_ratings r ON m.id = r.movie_id
        WHERE COALESCE(r.total_votes, 0) > 0
    ");
    $total = $stmt->fetchColumn();
    
    // اگر رتبه‌ای وجود نداشت، از کامنت‌ها استفاده کن
    if ($total == 0) {
        $stmt = $pdo->prepare("
            SELECT 
                m.*,
                AVG(c.rating) as user_rating,
                COUNT(c.id) as total_votes
            FROM movies m
            INNER JOIN comments c ON m.id = c.movie_id
            WHERE c.rating > 0 AND c.status = 'active'
            GROUP BY m.id
            HAVING COUNT(c.id) >= 1
            ORDER BY AVG(c.rating) DESC, COUNT(c.id) DESC
            LIMIT ? OFFSET ?
        ");
        $stmt->execute([$perPage, $offset]);
        $movies = $stmt->fetchAll();
        
        $stmt = $pdo->query("
            SELECT COUNT(DISTINCT m.id) as total
            FROM movies m
            INNER JOIN comments c ON m.id = c.movie_id
            WHERE c.rating > 0 AND c.status = 'active'
        ");
        $total = $stmt->fetchColumn();
    }
} catch(PDOException $e) {
    error_log("Top rated error: " . $e->getMessage());
    $movies = [];
    $total = 0;
}

$totalPages = ceil($total / $perPage);
$pageTitle = $userLang === 'fa' ? 'محبوب‌ترین فیلم‌ها و سریال‌ها' : 'Top User Rated Movies & Series';

function getPosterUrl($imdbCode) {
    return $imdbCode ? 'posters/' . $imdbCode . '.webp' : '';
}
function escapeHtml($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="<?= $langAttr ?>" dir="<?= $dir ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title><?= $pageTitle ?> | BankMovie</title>
    <style>
        /* ========== فونت و متغیرها ========== */
        @font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}
        *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
        :root{--bg-primary:#08090d;--bg-secondary:#101116;--bg-tertiary:#171922;--bg-card:#0e1017;--bg-card-hover:#151926;--accent:<?= e($currentTheme['primary']) ?>;--accent-rgb:<?= e($currentThemeRgbCss) ?>;--accent-dark:<?= e($currentTheme['primary']) ?>cc;--accent-glow:rgba(var(--accent-rgb),.14);--text-primary:#fff;--text-secondary:#a4a8b6;--text-tertiary:#6e7384;--border-subtle:rgba(255,255,255,.075);--border-accent:rgba(var(--accent-rgb),.28);--gradient-hero:linear-gradient(135deg,#fff,var(--accent));--gradient-donate:linear-gradient(135deg,#ff3366,#ff6633);--shadow-soft:0 18px 50px rgba(0,0,0,.38)}
        html{scroll-behavior:smooth}
        body{min-height:100vh;background:radial-gradient(circle at 18% -10%,rgba(var(--accent-rgb),.16),transparent 34%),radial-gradient(circle at 88% 12%,rgba(59,130,246,.08),transparent 36%),#08090d;color:var(--text-primary);font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,Segoe UI,sans-serif;overflow-x:hidden;padding-bottom:104px}
        ::-webkit-scrollbar{width:7px;height:7px}::-webkit-scrollbar-track{background:#101116}::-webkit-scrollbar-thumb{background:var(--accent);border-radius:10px}svg{display:block}

        .header{position:sticky;top:0;z-index:100;background:rgba(8,9,13,.74);border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(22px);transition:.22s ease}.header.header-solid{background:rgba(8,9,13,.94);box-shadow:0 16px 34px rgba(0,0,0,.24)}.header-inner{max-width:1400px;height:68px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:18px}.logo{display:inline-flex;align-items:center;gap:10px;text-decoration:none;color:#fff;min-width:0}.logo-icon{width:34px;height:34px;filter:drop-shadow(0 0 14px rgba(var(--accent-rgb),.28))}.logo-text{font-size:18px;font-weight:900;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent;letter-spacing:.2px}.desktop-nav{display:flex;align-items:center;gap:8px;flex:1;justify-content:center}.desktop-nav-item{display:inline-flex;align-items:center;gap:8px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:760;padding:10px 14px;border-radius:999px;border:1px solid transparent;transition:.2s ease}.desktop-nav-item svg{width:17px;height:17px;stroke:currentColor}.desktop-nav-item:hover,.desktop-nav-item.active{color:#fff;background:rgba(255,255,255,.055);border-color:rgba(255,255,255,.08)}.desktop-nav-item.active{box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18);color:var(--accent)}.header-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}.menu-btn,.notif-bell,.auth-trigger,.user-trigger,.donate-btn{border:none;cursor:pointer;color:#fff;transition:.2s ease}.menu-btn,.notif-bell{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;position:relative}.menu-btn svg,.notif-bell svg{width:20px;height:20px}.menu-btn:hover,.notif-bell:hover{background:var(--accent-glow);border-color:var(--border-accent);color:var(--accent)}.notif-badge{position:absolute;top:7px;right:9px;width:8px;height:8px;background:#ff3b5c;border-radius:50%;box-shadow:0 0 0 3px rgba(255,59,92,.15)}.donate-btn{display:inline-flex;align-items:center;gap:7px;background:var(--gradient-donate);border-radius:999px;padding:10px 16px;font-size:12px;font-weight:850;box-shadow:0 12px 28px rgba(255,51,102,.14)}.donate-btn:hover{transform:translateY(-1px);box-shadow:0 16px 32px rgba(255,51,102,.24)}.auth-dropdown{position:relative}.auth-trigger,.user-trigger{height:42px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.045);border:1px solid var(--border-subtle);border-radius:999px;padding:0 13px;font-size:12px;font-weight:760}.auth-trigger svg,.user-trigger svg{width:17px;height:17px}.auth-dropdown:hover .auth-menu{opacity:1;visibility:visible;transform:translateY(6px)}.auth-menu{position:absolute;top:100%;left:0;min-width:190px;background:rgba(17,19,28,.96);border:1px solid var(--border-subtle);border-radius:18px;padding:8px;box-shadow:var(--shadow-soft);backdrop-filter:blur(18px);opacity:0;visibility:hidden;transform:translateY(0);transition:.2s ease;z-index:120}.auth-menu a{display:flex;align-items:center;gap:9px;text-decoration:none;color:var(--text-secondary);font-size:12px;font-weight:760;padding:10px 12px;border-radius:13px}.auth-menu a:hover{background:var(--accent-glow);color:var(--accent)}.auth-menu svg{width:16px;height:16px}
        .menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,.68);backdrop-filter:blur(8px);z-index:180;opacity:0;visibility:hidden;transition:.22s ease}.menu-overlay.active{opacity:1;visibility:visible}.sidebar-menu{position:fixed;top:0;bottom:0;right:0;width:min(330px,88vw);background:rgba(13,15,23,.96);border-left:1px solid var(--border-subtle);z-index:190;transform:translateX(105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px);display:flex;flex-direction:column}.sidebar-menu.open{transform:translateX(0)}[dir="ltr"] .sidebar-menu{right:auto;left:0;transform:translateX(-105%)}[dir="ltr"] .sidebar-menu.open{transform:translateX(0)}.sidebar-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.sidebar-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.sidebar-close svg{width:18px;height:18px}.sidebar-user{margin:18px 18px 10px;padding:18px;border:1px solid var(--border-subtle);border-radius:24px;background:linear-gradient(145deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.035));text-align:center}.sidebar-avatar{width:58px;height:58px;border-radius:50%;margin:0 auto 10px;background:rgba(var(--accent-rgb),.12);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent)}.sidebar-avatar svg{width:28px;height:28px}.sidebar-username{font-weight:900}.sidebar-userrole{margin-top:3px;color:var(--text-tertiary);font-size:12px}.sidebar-nav,.sidebar-footer{padding:10px 14px;display:flex;flex-direction:column;gap:6px}.sidebar-nav{flex:1}.sidebar-item{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:780;padding:13px 14px;border-radius:16px;transition:.18s}.sidebar-item:hover,.sidebar-item.active{background:var(--accent-glow);color:var(--accent)}.sidebar-item svg{width:19px;height:19px}.notif-sidebar{position:fixed;top:0;bottom:0;left:0;width:min(380px,92vw);background:rgba(13,15,23,.97);border-right:1px solid var(--border-subtle);z-index:185;transform:translateX(-105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px)}[dir="ltr"] .notif-sidebar{left:auto;right:0;transform:translateX(105%);border-right:none;border-left:1px solid var(--border-subtle)}.notif-sidebar.open{transform:translateX(0)}.notif-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.notif-header h3{font-size:18px;color:var(--accent)}.notif-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.notif-close svg{width:18px;height:18px}.notif-list{padding:16px;display:flex;flex-direction:column;gap:10px}.notif-item{padding:14px;border-radius:18px;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle)}.notif-message{font-size:13px;line-height:1.7;color:#fff}.notif-date{margin-top:8px;color:var(--text-tertiary);font-size:11px}
        .bottom-nav{position:fixed;left:50%;bottom:calc(10px + env(safe-area-inset-bottom));transform:translateX(-50%);width:min(520px,calc(100% - 28px));height:74px;background:linear-gradient(180deg,rgba(27,31,45,.86),rgba(13,15,23,.92));border:1px solid rgba(255,255,255,.1);border-radius:34px;z-index:95;display:grid;grid-template-columns:repeat(3,1fr);align-items:center;padding:6px;box-shadow:0 18px 48px rgba(0,0,0,.44),inset 0 1px 0 rgba(255,255,255,.08);backdrop-filter:blur(22px);transition:.26s ease}.bottom-nav.nav-hidden{transform:translate(-50%,calc(100% + 28px));opacity:0;pointer-events:none}.bottom-nav.nav-compact{height:66px;opacity:.96}.nav-item{height:100%;border-radius:28px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;text-decoration:none;color:var(--text-secondary);font-size:10px;font-weight:760;transition:.2s}.nav-item svg{width:22px;height:22px;stroke:currentColor}.nav-item.active{color:var(--accent);background:linear-gradient(180deg,rgba(var(--accent-rgb),.18),rgba(var(--accent-rgb),.08));box-shadow:inset 0 0 0 1px rgba(var(--accent-rgb),.18)}.nav-label{font-size:10px;color:inherit}.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);z-index:10020;align-items:center;justify-content:center;padding:22px}.modal-content{background:linear-gradient(180deg,#151823,#0f1118);border:1px solid var(--border-subtle);border-radius:30px;max-width:420px;width:100%;padding:26px;text-align:center;box-shadow:var(--shadow-soft)}.btn{border:none;cursor:pointer;text-decoration:none}.btn-primary{height:46px;border-radius:999px;background:var(--accent);color:#050505;font-weight:900;display:inline-flex;align-items:center;justify-content:center}
        
        /* محتوای اصلی */
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .page-header { text-align: center; margin-bottom: 30px; }
        .page-title { font-size: 28px; font-weight: 800; background: var(--gradient-hero); -webkit-background-clip: text; background-clip: text; color: transparent; margin-bottom: 10px; }
        .page-desc { color: var(--text-secondary); font-size: 13px; }
        .movies-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; }
        .grid-item { background: var(--bg-card); border: 1px solid var(--border-subtle); border-radius: 20px; overflow: hidden; cursor: pointer; transition: 0.2s; text-decoration: none; color: inherit; display: block; position: relative; }
        .grid-item:hover { transform: translateY(-4px); border-color: var(--border-accent); box-shadow: 0 10px 25px -10px rgba(0,0,0,0.5); }
        .grid-poster { width: 100%; aspect-ratio: 2/3; object-fit: cover; background: var(--bg-tertiary); }
        .grid-info { padding: 10px 8px; }
        .grid-title-fa { font-size: 13px; font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 3px; }
        .grid-title-en { font-size: 10px; color: var(--text-tertiary); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; margin-bottom: 5px; }
        .grid-meta { display: flex; justify-content: space-between; align-items: center; font-size: 11px; }
        .grid-rating { display: flex; align-items: center; gap: 5px; color: var(--accent); }
        .grid-rating svg { width: 14px; height: 14px; fill: var(--accent); }
        .grid-votes { color: var(--text-tertiary); font-size: 10px; }
        .grid-type { font-size: 9px; padding: 2px 8px; border-radius: 20px; background: var(--accent-glow); color: var(--accent); }
        .pagination { display: flex; justify-content: center; gap: 8px; margin: 40px 0; flex-wrap: wrap; }
        .pagination a, .pagination span { padding: 8px 16px; background: var(--bg-secondary); border: 1px solid var(--border-subtle); border-radius: 40px; text-decoration: none; color: var(--text-primary); font-size: 13px; transition: 0.2s; }
        .pagination a:hover { border-color: var(--accent); background: var(--accent-glow); color: var(--accent); }
        .pagination .active { background: var(--accent); color: #000; border-color: var(--accent); }
        .empty-state { text-align: center; padding: 80px 20px; color: var(--text-tertiary); grid-column: 1/-1; }
        .empty-state svg { width: 80px; height: 80px; margin-bottom: 20px; opacity: 0.5; stroke: currentColor; }
        .toast-container { position: fixed; top: 80px; right: 16px; left: 16px; z-index: 10001; display: flex; flex-direction: column; gap: 8px; pointer-events: none; }
        .toast { background: var(--bg-tertiary); border: 1px solid var(--border-accent); border-radius: 60px; padding: 12px 20px; animation: slideIn 0.3s ease; pointer-events: auto; backdrop-filter: blur(10px); font-size: 13px; text-align: center; max-width: 400px; margin: 0 auto; }
        .footer-space { height: 18px; }
        @keyframes slideIn { from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        
        @media(min-width:992px){body{padding-bottom:50px}.bottom-nav{display:none!important}.menu-btn{display:none}}
        @media(max-width:991px){.desktop-nav,.auth-dropdown{display:none}}
        @media(min-width:600px){.movies-grid{grid-template-columns:repeat(4,1fr)}}
        @media(min-width:900px){.movies-grid{grid-template-columns:repeat(5,1fr)}}
        @media(min-width:1200px){.movies-grid{grid-template-columns:repeat(6,1fr)}}
        @media(max-width:540px){body{padding-bottom:96px}.movies-grid{grid-template-columns:repeat(2,1fr)!important}}
    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body data-theme="<?= $userTheme ?>">

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header">
        <span class="logo-text">BankMovie</span>
        <button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <?php if($currentUser): ?>
    <div class="sidebar-user">
        <div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="sidebar-username"><?= e($currentUser['username'] ?? '') ?></div>
        <div class="sidebar-userrole"><?= ($currentUser['role'] ?? '') === 'admin' ? $t[$userLang]['admin_panel'] : $t[$userLang]['account'] ?></div>
    </div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span><?= $t[$userLang]['search'] ?></span></a>
        <a href="/top_rated_by_users" class="sidebar-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg><span><?= $userLang === 'fa' ? 'محبوب‌ترین' : 'Top Rated' ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8M8 13h5"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if($currentUser): ?>
        <a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a>
        <?php if(($currentUser['role'] ?? '') === 'admin'): ?>
        <a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a>
        <?php endif; endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
        <a href="/logout" class="sidebar-item" onclick="return confirm('<?= $userLang === 'fa' ? 'آیا از خروج مطمئن هستید؟' : 'Are you sure you want to logout?' ?>')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
        <a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg><span><?= $t[$userLang]['login'] ?></span></a>
        <a href="/register" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" y1="8" x2="19" y2="14"/><line x1="22" y1="11" x2="16" y2="11"/></svg><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header">
        <h3><?= $t[$userLang]['notifications'] ?></h3>
        <button class="notif-close" id="closeNotifSidebar" type="button" aria-label="Close"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button>
    </div>
    <div class="notif-list">
        <?php if(count($notificationsList) > 0): ?>
            <?php foreach($notificationsList as $notif): ?>
            <div class="notif-item"><div class="notif-message"><?= nl2br(e($notif['message'] ?? '')) ?></div><div class="notif-date"><?= !empty($notif['created_at']) ? e(date('Y/m/d H:i', strtotime($notif['created_at']))) : '' ?></div></div>
            <?php endforeach; ?>
        <?php else: ?>
            <div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div>
        <?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<div class="container">
    <div class="page-header">
        <h1 class="page-title"><?= $userLang === 'fa' ? '🏆 محبوب‌ترین فیلم‌ها و سریال‌ها' : '🏆 Top User Rated Movies & Series' ?></h1>
        <p class="page-desc"><?= $userLang === 'fa' ? 'بر اساس امتیاز و نظرات کاربران بانک مووی' : 'Based on BankMovie user ratings and reviews' ?></p>
    </div>
    
    <?php if(count($movies) > 0): ?>
    <div class="movies-grid">
        <?php foreach($movies as $movie): 
            $poster = getPosterUrl($movie['imdb_code']);
            $typeLabel = $movie['type'] === 'movie' ? ($userLang === 'fa' ? 'فیلم' : 'Movie') : ($userLang === 'fa' ? 'سریال' : 'Series');
            $rating = round($movie['user_rating'] ?? 0, 1);
            $votes = number_format($movie['total_votes'] ?? 0);
        ?>
        <a href="<?= e(bm_movie_url($movie)) ?>" class="grid-item">
            <img class="grid-poster" src="<?= $poster ?>" loading="lazy" alt="<?= escapeHtml($movie['title']) ?>" onerror="this.src='uploads/no.png'">
            <div class="grid-info">
                <div class="grid-title-fa"><?= escapeHtml($movie['title_fa'] ?: $movie['title']) ?></div>
                <div class="grid-title-en"><?= escapeHtml($movie['title']) ?></div>
                <div class="grid-meta">
                    <div class="grid-rating">
                        <svg viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                        <span><?= $rating ?></span>
                    </div>
                    <span class="grid-votes">👥 <?= $votes ?></span>
                    <span class="grid-type"><?= $typeLabel ?></span>
                </div>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    
    <?php if($totalPages > 1): ?>
    <div class="pagination">
        <?php if($page > 1): ?>
        <a href="?page=<?= $page-1 ?>">« <?= $userLang === 'fa' ? 'قبلی' : 'Previous' ?></a>
        <?php else: ?>
        <span class="disabled">« <?= $userLang === 'fa' ? 'قبلی' : 'Previous' ?></span>
        <?php endif; ?>
        
        <?php for($i = 1; $i <= $totalPages; $i++): ?>
            <?php if($i == $page): ?>
            <span class="active"><?= $i ?></span>
            <?php elseif($i == 1 || $i == $totalPages || ($i >= $page-2 && $i <= $page+2)): ?>
            <a href="?page=<?= $i ?>"><?= $i ?></a>
            <?php elseif($i == $page-3 || $i == $page+3): ?>
            <span>...</span>
            <?php endif; ?>
        <?php endfor; ?>
        
        <?php if($page < $totalPages): ?>
        <a href="?page=<?= $page+1 ?>"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php else: ?>
        <span class="disabled"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</span>
        <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php else: ?>
    <div class="empty-state">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>
        <p><?= $userLang === 'fa' ? 'هنوز امتیازی ثبت نشده است.' : 'No ratings yet.' ?></p>
        <p style="font-size: 12px; margin-top: 10px;"><?= $userLang === 'fa' ? 'اولین نفری باشید که به فیلم‌ها امتیاز می‌دهید!' : 'Be the first to rate movies!' ?></p>
    </div>
    <?php endif; ?>
</div>

<div class="footer-space"></div>

<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('top_rated_by_users.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<div class="bottom-nav" data-mobile-bottom-nav aria-label="Mobile bottom navigation">
    <a href="/" class="nav-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span class="nav-label"><?= $t[$userLang]['home'] ?></span></a>
    <a href="/search" class="nav-item bm-footer-search-trigger" aria-haspopup="dialog" aria-controls="bmQuickSearchModal"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span class="nav-label"><?= $t[$userLang]['search'] ?></span></a>
    <a href="/top_rated_by_users" class="nav-item active"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg><span class="nav-label"><?= $userLang === 'fa' ? 'محبوب' : 'Top' ?></span></a>
</div>

<div id="donateModal" class="modal">
    <div class="modal-content">
        <div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
        <h3 style="margin-bottom:10px;font-size:22px;"><?= $t[$userLang]['support_us'] ?></h3>
        <p style="color:var(--text-secondary);margin-bottom:20px;font-size:13px;line-height:1.8;"><?= $t[$userLang]['support_text'] ?></p>
        <button id="openDonateLink" class="btn btn-primary" style="width:100%;"><?= $t[$userLang]['donate'] ?></button>
        <button id="closeDonateModal" type="button" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer;"><?= $t[$userLang]['close'] ?></button>
    </div>
</div>

<script>
let toastTimeout = null;
function showToast(msg){
    if(toastTimeout) clearTimeout(toastTimeout);
    const container = document.getElementById('toastContainer');
    container.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div');
    t.className = 'toast';
    t.innerHTML = msg;
    container.appendChild(t);
    toastTimeout = setTimeout(() => t?.remove(), 3000);
}
function setupMenu(){
    const menuBtn=document.getElementById('menuBtn'),sidebar=document.getElementById('sidebarMenu'),overlay=document.getElementById('menuOverlay'),closeBtn=document.getElementById('closeMenuBtn');
    if(!menuBtn||!sidebar||!overlay||!closeBtn)return;
    function openMenu(){sidebar.classList.add('open');overlay.classList.add('active');document.body.style.overflow='hidden';menuBtn.setAttribute('aria-expanded','true');}
    function closeMenu(){sidebar.classList.remove('open');overlay.classList.remove('active');document.body.style.overflow='';menuBtn.setAttribute('aria-expanded','false');}
    menuBtn.addEventListener('click',openMenu);closeBtn.addEventListener('click',closeMenu);overlay.addEventListener('click',closeMenu);window.addEventListener('resize',()=>{if(window.innerWidth>=992)closeMenu();});
}
function setupHeaderScroll(){const header=document.getElementById('siteHeader');if(!header)return;function update(){header.classList.toggle('header-solid',(window.scrollY||0)>20);}update();window.addEventListener('scroll',update,{passive:true});}
function setupSmartBottomNav(){
    const nav=document.querySelector('.bottom-nav');if(!nav)return;let lastY=window.scrollY||0,ticking=false;
    function keep(){const ae=document.activeElement;return window.innerWidth>=992||window.scrollY<100||document.body.style.overflow==='hidden'||document.querySelector('.sidebar-menu.open')||(ae&&['INPUT','TEXTAREA','SELECT'].includes(ae.tagName));}
    function update(){const y=window.scrollY||0,diff=y-lastY;if(keep()){nav.classList.remove('nav-hidden');nav.classList.toggle('nav-compact',y>220);lastY=y;ticking=false;return;}if(Math.abs(diff)>12){nav.classList.toggle('nav-hidden',diff>0);nav.classList.toggle('nav-compact',y>220&&diff<=0);lastY=y;}ticking=false;}
    window.addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(update);ticking=true;}},{passive:true});window.addEventListener('resize',update);document.addEventListener('focusin',update);document.addEventListener('focusout',()=>setTimeout(update,80));update();
}
function setupNotifications(){const bell=document.getElementById('notifBell'),sidebar=document.getElementById('notifSidebar'),close=document.getElementById('closeNotifSidebar');if(!bell||!sidebar||!close)return;bell.addEventListener('click',()=>sidebar.classList.add('open'));bell.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();sidebar.classList.add('open');}});close.addEventListener('click',()=>sidebar.classList.remove('open'));document.addEventListener('click',e=>{if(sidebar.classList.contains('open')&&!sidebar.contains(e.target)&&!bell.contains(e.target))sidebar.classList.remove('open');});}
function setupDonate(){const btn=document.getElementById('donateModalBtn'),modal=document.getElementById('donateModal'),close=document.getElementById('closeDonateModal'),open=document.getElementById('openDonateLink');if(btn&&modal)btn.onclick=()=>modal.style.display='flex';if(close&&modal)close.onclick=()=>modal.style.display='none';if(open&&modal)open.onclick=()=>{window.open('https://daramet.com/manuel','_blank');modal.style.display='none';};if(modal)modal.addEventListener('click',e=>{if(e.target===modal)modal.style.display='none';});}
setupMenu();setupHeaderScroll();setupSmartBottomNav();setupNotifications();setupDonate();
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
