<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// scraper_final_fixed.php
// اسکرپر کامل + ایمپورت هوشمند (رفع مشکل nosub و لینک‌های پوشه)

require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
admin_panel_bootstrap($pdo);
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

// -------------------- توابع کمکی (مثل قبل) --------------------
function extractQuality($text) {
    $patterns = [
        '/\b(480p|720p|1080p|4K)\s*(BluRay|WEB-DL|WEBRip|BluRay\.?|DVDRip)?\b/i',
        '/\b(DVDRip|BDRip|WEBRip|BluRay|WEB-DL)\b/i',
        '/\b(S\d{2}\s*-\s*)?(480p|720p|1080p|4K)\b/i',
    ];
    foreach ($patterns as $pattern) {
        if (preg_match($pattern, $text, $match)) {
            return trim(preg_replace('/\s+/', ' ', $match[0]));
        }
    }
    return 'HD';
}

function extractSeason($url, $label) {
    $text = $url . ' ' . $label;
    if (preg_match('/\/S(\d{2})\//i', $url, $m)) return $m[1];
    if (preg_match('/[_-]S(\d{2})/i', $text, $m)) return $m[1];
    if (preg_match('/season[_\s]?(\d+)/i', $text, $m)) return sprintf("%02d", $m[1]);
    return null;
}

function isFolderLink($url, $label) {
    if (substr($url, -1) == '/' && !preg_match('/\.(mkv|mp4|avi|rar|zip|webm)$/i', $url)) return 1;
    if (preg_match('/لینک\s*های\s*دانلود/i', $label)) return 1;
    if (preg_match('/^(1080p|720p|480p)\.(BluRay|DVDRip)$/i', $label)) return 1;
    return 0;
}

function extractSize($text) {
    if (preg_match('/حجم:\s*([\d\.]+)\s*(MB|GB|KB)/i', $text, $m)) return trim($m[1] . ' ' . $m[2]);
    if (preg_match('/\(([\d\.]+)\s*(MB|GB|KB)\)/i', $text, $m)) return trim($m[1] . ' ' . $m[2]);
    if (preg_match('/(\d+(?:\.\d+)?)\s*(MB|GB|KB)/i', $text, $m)) return trim($m[1] . ' ' . $m[2]);
    return '';
}

// -------------------- پارس کردن HTML --------------------
function extractFromHtml($html) {
    if (!class_exists('DOMDocument')) {
        throw new RuntimeException('افزونه PHP DOM روی هاست فعال نیست.');
    }
    $dom = new DOMDocument();
    libxml_use_internal_errors(true);
    $htmlForDom = function_exists('mb_convert_encoding')
        ? mb_convert_encoding((string)$html, 'HTML-ENTITIES', 'UTF-8')
        : '<?xml encoding="UTF-8">' . (string)$html;
    $loaded = $dom->loadHTML($htmlForDom);
    libxml_clear_errors();
    if (!$loaded) throw new RuntimeException('ساختار HTML قابل پردازش نیست.');
    $xpath = new DOMXPath($dom);
    
    // تشخیص نوع از h1
    $h1 = $xpath->query('//h1');
    $titleText = $h1->length ? trim($h1->item(0)->nodeValue) : '';
    $type = (mb_stripos($titleText, 'سریال') !== false) ? 'tvSeries' : 'movie';
    $titleEn = trim(preg_replace('/^(دانلود سریال|دانلود فیلم)\s+/u', '', $titleText));
    
    // عنوان فارسی
    $titleFa = '';
    $h2 = $xpath->query('//h2');
    if ($h2->length) $titleFa = trim($h2->item(0)->nodeValue);
    
    // کد IMDb
    $imdbCode = '';
    $imdbLink = $xpath->query('//a[contains(@href, "imdb.com/title/tt")]');
    if ($imdbLink->length && preg_match('/tt\d+/', $imdbLink->item(0)->getAttribute('href'), $m)) {
        $imdbCode = $m[0];
    }
    
    // امتیاز و رای
    $rate = 0; $votes = 0;
    $rateDiv = $xpath->query('//div[contains(@class, "-rate-number")]');
    if ($rateDiv->length) {
        $fullText = trim($rateDiv->item(0)->nodeValue);
        if (preg_match('/(\d+(?:\.\d+)?)\/10\s+(\d+(?:,\d+)?)/', $fullText, $matches)) {
            $rate = floatval($matches[1]);
            $votes = intval(str_replace(',', '', $matches[2]));
        }
    }
    
    // سال
    $year = 0;
    $yearSpan = $xpath->query('//span[contains(text(), "سال انتشار")]/following-sibling::a');
    if ($yearSpan->length) $year = intval(trim($yearSpan->item(0)->nodeValue));
    if ($year == 0) {
        $yearLink = $xpath->query('//a[contains(@href, "/release/") or contains(@href, "/release-series/")]');
        if ($yearLink->length) $year = intval(trim($yearLink->item(0)->nodeValue));
    }
    
    // کشور
    $country = '';
    $countrySpan = $xpath->query('//span[contains(text(), "محصول")]/following-sibling::a');
    if ($countrySpan->length) $country = trim($countrySpan->item(0)->nodeValue);
    
    // زبان
    $language = '';
    $langSpan = $xpath->query('//li[contains(., "زبان")]//a');
    if ($langSpan->length) $language = trim($langSpan->item(0)->nodeValue);
    
    // توضیحات
    $description = '';
    $plotDiv = $xpath->query('//div[contains(@class, "-plot")]//p');
    if ($plotDiv->length) $description = trim($plotDiv->item(0)->nodeValue);
    
    // پوستر
    $posterUrl = '';
    $posterImg = $xpath->query('//div[contains(@class, "post-poster")]//img');
    if ($posterImg->length) {
        $src = $posterImg->item(0)->getAttribute('src');
        $posterUrl = preg_replace('/-\d+x\d+\./', '.', $src);
        if (strpos($posterUrl, 'http') !== 0) $posterUrl = 'https://serialblog1.top' . $posterUrl;
    }
    
    // لینک‌های دانلود
    $downloads = [];
    $downloadBox = $xpath->query('//div[contains(@class, "download_box")]');
    if ($downloadBox->length) {
        $allLinks = $xpath->query('.//a', $downloadBox->item(0));
        foreach ($allLinks as $link) {
            $url = $link->getAttribute('href');
            $label = trim($link->nodeValue);
            $parentText = $link->parentNode ? trim($link->parentNode->textContent) : '';
            $fullText = $label . ' ' . $parentText;
            
            if (strpos($url, 'rzb.ir') !== false || strpos($url, '10_thous.html') !== false) continue;
            
            // تعیین نوع لینک
            $typeLink = 'unknown';
            if (stripos($url, 'SoftSub') !== false) $typeLink = 'softsub';
            elseif (stripos($url, 'Dubbed') !== false) $typeLink = 'dubbed';
            elseif (stripos($url, 'NoSub') !== false) $typeLink = 'nosub';
            
            // اصلاح: لینک‌های NoSub را هم به عنوان softsub ذخیره می‌کنیم (چون جدول جدا نداریم)
            if ($typeLink == 'nosub') $typeLink = 'softsub';
            
            // کیفیت
            $quality = extractQuality($label . ' ' . $url);
            // حجم
            $size = extractSize($fullText);
            // فصل
            $season = extractSeason($url, $label);
            // is_folder
            $is_folder = isFolderLink($url, $label);
            
            $downloads[] = [
                'type' => $typeLink,
                'quality' => $quality,
                'url' => $url,
                'size' => $size,
                'season' => $season,
                'is_folder' => $is_folder
            ];
        }
    }
    
    return [
        'title_en' => $titleEn,
        'title_fa' => $titleFa,
        'imdb_code' => $imdbCode,
        'rate' => $rate,
        'votes' => $votes,
        'year' => $year,
        'type' => $type,
        'country' => $country,
        'language' => $language,
        'description' => $description,
        'poster_url' => $posterUrl,
        'downloads' => $downloads
    ];
}

// -------------------- ایمپورت به دیتابیس (فقط آیتم‌های جدید) --------------------
function importMovie($pdo, $data) {
    $imdb = $data['imdb_code'];
    if (empty($imdb)) return ['status' => 'error', 'msg' => 'کد IMDb ندارد'];
    
    // بررسی تکراری
    $stmt = $pdo->prepare("SELECT id FROM movies WHERE imdb_code = ?");
    $stmt->execute([$imdb]);
    if ($stmt->fetch()) {
        return ['status' => 'skip', 'msg' => 'فیلم/سریال قبلاً در دیتابیس موجود است'];
    }
    
    try {
        $pdo->beginTransaction();
        
        // 1. درج در movies
        $sql = "INSERT INTO movies (title, title_fa, type, year, imdb_rate, imdb_votes, imdb_code, description, country, genres, director, actors, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['title_en'], $data['title_fa'], $data['type'], $data['year'],
            $data['rate'], $data['votes'], $imdb, $data['description'], $data['country'],
            '', '', ''
        ]);
        $movieId = $pdo->lastInsertId();
        
        // 2. درج در movie_extra_info
        $sqlExtra = "INSERT INTO movie_extra_info (imdb_code, language, production_companies, status, rated, seasons, episodes, created_at, updated_at)
                     VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        $pdo->prepare($sqlExtra)->execute([$imdb, $data['language'], '', '', '', null, null]);
        
        // 3. حذف لینک‌های قبلی (امنیتی)
        $pdo->prepare("DELETE FROM softsub_links WHERE movie_id = ?")->execute([$movieId]);
        $pdo->prepare("DELETE FROM dubbed_links WHERE movie_id = ?")->execute([$movieId]);
        
        // 4. درج لینک‌ها (همه نوع softsub و dubbed)
        foreach ($data['downloads'] as $dl) {
            if ($dl['type'] == 'softsub') {
                $sqlLink = "INSERT INTO softsub_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)";
            } elseif ($dl['type'] == 'dubbed') {
                $sqlLink = "INSERT INTO dubbed_links (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)";
            } else {
                continue; // نوع ناشناخته، رد کن
            }
            $pdo->prepare($sqlLink)->execute([
                $movieId, $dl['quality'], $dl['url'], $dl['size'], $dl['season'], $dl['is_folder']
            ]);
        }
        
        $pdo->commit();
        return ['status' => 'success', 'msg' => 'با موفقیت اضافه شد', 'movie_id' => $movieId];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return ['status' => 'error', 'msg' => 'خطا در دیتابیس: ' . $e->getMessage()];
    }
}

// -------------------- پردازش فرم --------------------
$resultMsg = '';
$movieData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $html = '';
        if (isset($_FILES['html_file']) && (int)($_FILES['html_file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $uploadError = (int)($_FILES['html_file']['error'] ?? UPLOAD_ERR_NO_FILE);
            if ($uploadError !== UPLOAD_ERR_OK) throw new RuntimeException(admin_panel_upload_error_message($uploadError));
            if ((int)($_FILES['html_file']['size'] ?? 0) > 5 * 1024 * 1024) throw new RuntimeException('حجم فایل HTML بیشتر از ۵ مگابایت است.');
            if (!is_uploaded_file((string)($_FILES['html_file']['tmp_name'] ?? ''))) throw new RuntimeException('فایل آپلودی معتبر نیست.');
            $html = (string)file_get_contents($_FILES['html_file']['tmp_name']);
        } elseif (isset($_POST['html_code']) && trim((string)$_POST['html_code']) !== '') {
            $html = (string)$_POST['html_code'];
            if (strlen($html) > 5 * 1024 * 1024) throw new RuntimeException('حجم کد HTML بیشتر از حد مجاز است.');
        } else {
            throw new RuntimeException('لطفاً یک فایل یا کد HTML وارد کنید.');
        }
        if (trim($html) === '') throw new RuntimeException('فایل HTML خالی است.');
        $movieData = extractFromHtml($html);
        if (empty($movieData['imdb_code'])) {
            throw new RuntimeException('کد IMDb در این صفحه یافت نشد.');
        }
        $importResult = importMovie($pdo, $movieData);
        $resultMsg = $importResult['msg'];
    } catch (Throwable $e) {
        $resultMsg = '❌ ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html dir="rtl">
<head>
<meta name="theme-color" content="#05050a">
    <meta charset="UTF-8">
    <title>اسکرپر نهایی (رفع مشکل NoSub و لینک‌های پوشه)</title>
    <style>
        body { background: #0a0a0a; color: #eee; font-family: Tahoma; padding: 30px; direction: rtl; }
        .container { max-width: 1000px; margin: auto; background: #1e1e1e; padding: 20px; border-radius: 16px; }
        input, textarea, button { margin: 10px 0; padding: 10px; border-radius: 8px; border: none; width: 100%; box-sizing: border-box; }
        textarea { font-family: monospace; background: #2d2d2d; color: #0f0; }
        button { background: #00cc66; color: #000; font-weight: bold; cursor: pointer; }
        pre { background: #2d2d2d; padding: 15px; overflow: auto; border-radius: 12px; font-size: 12px; max-height: 500px; }
        .success { background: #0a3a0a; border-right: 4px solid #00cc66; padding: 10px; margin: 10px 0; }
        .error { background: #3a0a0a; border-right: 4px solid #ff4444; padding: 10px; margin: 10px 0; }
        .skip { background: #3a3a0a; border-right: 4px solid #ffaa00; padding: 10px; margin: 10px 0; }
    </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
</head>
<body>
<div class="container">
    <h2>🎯 اسکرپر نهایی (NoSub هم ذخیره می‌شود + پشتیبانی از لینک‌های پوشه)</h2>
    <p>🔹 لینک‌های <code>NoSub</code> به عنوان <code>softsub</code> در جدول <code>softsub_links</code> ذخیره می‌شوند.<br>
    🔹 لینک‌های پوشه (<code>is_folder=1</code>) بدون حجم مشکلی ندارند.<br>
    🔹 کیفیت‌های مختلف (480p، 720p، 1080p، DVDRip، Web-DL، ...) پشتیبانی می‌شوند.<br>
    🔹 فقط آیتم‌های جدید (بر اساس <code>imdb_code</code>) وارد دیتابیس می‌شوند.</p>
    
    <form method="POST" enctype="multipart/form-data">
        <?= admin_csrf_input() ?>
        <label>📂 آپلود فایل HTML (ذخیره شده از مرورگر)</label>
        <input type="file" name="html_file" accept=".html,.htm">
        <hr>
        <label>📝 یا کد HTML را مستقیما وارد کن:</label>
        <textarea name="html_code" rows="6" placeholder="<html> ... </html>"></textarea>
        <button type="submit">پردازش و اضافه کردن به دیتابیس</button>
    </form>
    
    <?php if ($resultMsg): ?>
        <div class="<?= strpos($resultMsg, 'موفقیت') !== false ? 'success' : (strpos($resultMsg, 'قبلاً') !== false ? 'skip' : 'error') ?>">
            <?= htmlspecialchars($resultMsg) ?>
        </div>
    <?php endif; ?>
    
    <?php if ($movieData && !empty($movieData['imdb_code'])): ?>
        <hr>
        <h3>📄 اطلاعات استخراج شده از HTML:</h3>
        <pre><?php print_r($movieData); ?></pre>
        <p>✅ نوع تشخیص داده شده: <?= $movieData['type'] === 'tvSeries' ? 'سریال (tvSeries)' : 'فیلم (movie)' ?></p>
    <?php endif; ?>
</div>
<?php if (function_exists('bm_render_support_card')) { bm_render_support_card('team.php', 'standalone'); } ?>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>