<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/poster_redirect.php';
require_once __DIR__ . '/includes/site_bootstrap.php';
require_once __DIR__ . '/includes/site_content_control.php'; bm_site_enforce_page('page_actors_enabled');
@include_once __DIR__ . '/includes/_bm_support_widget.php';

// /actors — صفحه سبک نمایش اطلاعات بازیگر و فیلم‌های او از آرشیو ۱ / Archive 1
require_once __DIR__ . '/includes/api2_lib.php';
bm_security_enforce_rate_limit('actors_page', 180, 300, bm_security_client_ip(), false);

function bm_actor_e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

// V56: actor pages must never depend on ext-mbstring just to render.
// Some hosts do not load mbstring for every PHP SAPI; the previous unguarded
// mb_strtolower() could fatal before any HTML was emitted and leave a black page.
function bm_actor_lower($value): string {
    $value = (string)$value;
    return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
}


function bm_actor_page_placeholder_svg($name = '') {
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="220" height="290" viewBox="0 0 220 290">
        <defs>
            <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#111827"/>
                <stop offset=".55" stop-color="#171a28"/>
                <stop offset="1" stop-color="#05070b"/>
            </linearGradient>
            <radialGradient id="glowA" cx=".30" cy=".17" r=".88">
                <stop offset="0" stop-color="#36ff9f" stop-opacity=".42"/>
                <stop offset=".54" stop-color="#36ff9f" stop-opacity=".08"/>
                <stop offset="1" stop-color="#36ff9f" stop-opacity="0"/>
            </radialGradient>
            <radialGradient id="glowB" cx=".82" cy=".16" r=".85">
                <stop offset="0" stop-color="#8b5cf6" stop-opacity=".34"/>
                <stop offset=".56" stop-color="#8b5cf6" stop-opacity=".08"/>
                <stop offset="1" stop-color="#8b5cf6" stop-opacity="0"/>
            </radialGradient>
            <linearGradient id="strokeG" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0" stop-color="#36ff9f"/>
                <stop offset="1" stop-color="#8b5cf6"/>
            </linearGradient>
            <filter id="soft"><feGaussianBlur stdDeviation="15"/></filter>
        </defs>
        <rect width="220" height="290" rx="30" fill="url(#bg)"/>
        <rect width="220" height="290" rx="30" fill="url(#glowA)"/>
        <rect width="220" height="290" rx="30" fill="url(#glowB)"/>
        <circle cx="46" cy="46" r="44" fill="#36ff9f" opacity=".14" filter="url(#soft)"/>
        <circle cx="178" cy="58" r="56" fill="#8b5cf6" opacity=".16" filter="url(#soft)"/>
        <circle cx="110" cy="132" r="66" fill="#0b0f17" opacity=".96" stroke="url(#strokeG)" stroke-width="3"/>
        <circle cx="110" cy="107" r="31" fill="#f8fafc" opacity=".88"/>
        <path d="M54 199c10-37 32-56 56-56s46 19 56 56" fill="#f8fafc" opacity=".82"/>
        <path d="M70 198c8-22 23-34 40-34s32 12 40 34" fill="#dbeafe" opacity=".18"/>
        <path d="M58 236h104" stroke="#ffffff" stroke-opacity=".12" stroke-width="3" stroke-linecap="round"/>
        <path d="M78 245h64" stroke="#36ff9f" stroke-opacity=".18" stroke-width="2" stroke-linecap="round"/>
    </svg>';
    return 'data:image/svg+xml;charset=UTF-8,' . rawurlencode($svg);
}

function bm_actor_movie_url($item) {
    $slug = $item['detail_id'] ?? $item['id'] ?? $item['slug'] ?? '';
    $type = $item['type'] ?? '';
    if ($slug === '') return '#';
    return 'movie.php?arc=1&slug=' . rawurlencode($slug) . ($type ? '&type=' . rawurlencode($type) : '');
}


if (isset($_GET['url']) && trim((string)$_GET['url']) !== '') {
    $rawActorUrl = trim((string)$_GET['url']);
    $path = trim((string)(parse_url($rawActorUrl, PHP_URL_PATH) ?? ''), '/');
    $slugFromUrl = '';
    if ($path !== '') {
        $parts = explode('/', $path);
        $pos = array_search('actors', $parts, true);
        if ($pos !== false && !empty($parts[$pos + 1])) $slugFromUrl = trim((string)$parts[$pos + 1]);
        else $slugFromUrl = trim((string)end($parts));
    }
    if ($slugFromUrl !== '' && !headers_sent()) {
        header('Location: /actors?slug=' . rawurlencode($slugFromUrl), true, 302);
        exit;
    }
}


function bm_actor_page_is_bad_placeholder_image($url) {
    $u = strtolower(html_entity_decode(trim((string)$url), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($u === '') return true;
    if (strpos($u, 'data:image/svg') === 0) return true;
    if (strpos($u, '<svg') !== false || strpos($u, '%3csvg') !== false) return true;
    $badNeedles = [
        'placeholder', 'no-image', 'no_image', 'no-photo', 'no_photo',
        'default-user', 'default_avatar', 'default-avatar',
        'user-profile', 'profile-user', 'profile.png', 'avatar.png',
        'person-placeholder', 'unknown-person', 'empty-profile',
        'profile-placeholder'
    ];
    foreach ($badNeedles as $needle) {
        if (strpos($u, $needle) !== false) return true;
    }
    return false;
}

$actorId = bm_security_limit_text($_GET['slug'] ?? ($_GET['actor'] ?? ($_GET['url'] ?? '')), 180);
$actorId = rawurldecode(trim((string)$actorId));
$fallbackActorName = bm_security_limit_text($_GET['name'] ?? '', 160);
// V57: old actor links may contain only ?slug=. Keep a visible profile shell even if
// the upstream archive is temporarily unavailable.
if ($fallbackActorName === '' && $actorId !== '') {
    $actorSlugLabel = preg_replace('/[-_]+/u', ' ', trim((string)$actorId));
    $actorSlugLabel = preg_replace('/\s+/u', ' ', (string)$actorSlugLabel);
    $actorSlugLabel = trim((string)$actorSlugLabel);
    if ($actorSlugLabel !== '') $fallbackActorName = bm_security_limit_text($actorSlugLabel, 160);
}
$data = null;
$error = '';
if ($actorId === '' && $fallbackActorName === '') {
    $error = 'شناسه بازیگر ارسال نشده است.';
}

// Actor pages are upstream-backed. Keep a small local cache so opening an actor is instant
// after the first successful fetch and a temporary archive outage does not break the page.
$actorCacheDir = __DIR__ . '/_bankmovie_private/cache/actors';
$actorCacheKey = sha1(bm_actor_lower($actorId !== '' ? $actorId : $fallbackActorName));
$actorCacheFile = $actorCacheDir . '/' . $actorCacheKey . '.json';
$actorCached = null;
if ($actorCacheKey !== sha1('') && is_file($actorCacheFile)) {
    $raw = @file_get_contents($actorCacheFile);
    $decoded = is_string($raw) ? json_decode($raw, true) : null;
    if (is_array($decoded) && !empty($decoded['name'])) $actorCached = $decoded;
}
$actorCacheAge = is_file($actorCacheFile) ? max(0, time() - (int)@filemtime($actorCacheFile)) : PHP_INT_MAX;

try {
    if ($error !== '') {
        $data = null;
    } elseif (is_array($actorCached) && $actorCacheAge <= 12 * 3600) {
        $data = $actorCached;
    } else {
        try {
            $data = getActorDetails($actorId);
        } catch (Throwable $primaryActorError) {
            // Some source links occasionally expose an encoded/broken slug. English actor names
            // usually map directly to the source slug, so try that once before falling back.
            $nameSlug = trim((string)$fallbackActorName);
            $nameSlug = preg_replace('/\s+/u', '-', $nameSlug);
            if ($nameSlug !== '' && bm_actor_lower($nameSlug) !== bm_actor_lower($actorId)) {
                $data = getActorDetails($nameSlug);
            } else {
                throw $primaryActorError;
            }
        }
        if (is_array($data) && !empty($data['name'])) {
            if (!is_dir($actorCacheDir)) @mkdir($actorCacheDir, 0755, true);
            @file_put_contents($actorCacheFile, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), LOCK_EX);
        }
    }

    $badActorName = trim((string)($data['name'] ?? ''));
    if ($badActorName === '' || $badActorName === 'پروفایل کاربری' || $badActorName === 'Profile' || $badActorName === 'User Profile') {
        throw new RuntimeException('اطلاعات بازیگر نامعتبر است.');
    }
    if (isset($data['photo']) && bm_actor_page_is_bad_placeholder_image($data['photo'])) $data['photo'] = '';
} catch (Throwable $e) {
    error_log('actors page error [' . bm_security_request_id() . ']: ' . $e->getMessage());
    if (is_array($actorCached) && $actorCacheAge <= 30 * 86400) {
        $data = $actorCached; // stale-but-valid fallback
    } elseif ($fallbackActorName !== '') {
        // Never leave a clicked actor link as a dead page: render the profile shell immediately.
        $data = ['status'=>'partial','source'=>'fallback','type'=>'actor','slug'=>$actorId,'name'=>$fallbackActorName,'photo'=>'','count'=>0,'movies'=>[]];
    } else {
        $error = 'اطلاعات این بازیگر فعلاً در دسترس نیست.';
    }
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    @session_start();
}
$currentUser = $currentUser ?? ($_SESSION['user'] ?? null);
$userLang = (($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')) === 'en') ? 'en' : 'fa';
$userTheme = trim((string)($userTheme ?? ($currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green'))));
if ($userTheme === '' || !bm_theme_is_valid($userTheme)) $userTheme = 'dark-green';
$t = $t ?? [
    'fa' => ['home'=>'خانه','search'=>'جستجو','advanced_search'=>'جستجوی پیشرفته','player'=>'پلیر','profile'=>'پروفایل','login'=>'ورود','logout'=>'خروج','register'=>'ثبت نام','account'=>'حساب کاربری','notifications'=>'اعلان‌ها','admin_panel'=>'پنل مدیریت'],
    'en' => ['home'=>'Home','search'=>'Search','advanced_search'=>'Advanced search','player'=>'Player','profile'=>'Profile','login'=>'Login','logout'=>'Logout','register'=>'Register','account'=>'Account','notifications'=>'Notifications','admin_panel'=>'Admin panel'],
];
$latestNotification = $latestNotification ?? null;
$activeNotification = $activeNotification ?? null;
$notificationsList = $notificationsList ?? [];
$actorPhoto = $data ? ($data['photo'] ?: bm_actor_page_placeholder_svg($data['name'] ?? '')) : bm_actor_page_placeholder_svg('');
?><!doctype html>
<html lang="<?= $userLang === 'en' ? 'en' : 'fa' ?>" dir="<?= $userLang === 'en' ? 'ltr' : 'rtl' ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#05050a">
<title><?= $data ? bm_actor_e($data['name']) : 'بازیگر' ?> | BankMovie</title>
<link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="manifest" href="/manifest.php?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<link rel="stylesheet" href="/assets/css/actors-v98.css?v=98">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
<!-- V67: legacy BoxOffice/Actor floating-nav stylesheet removed -->
<link rel="stylesheet" href="/assets/css/bm-mobile-menu-v14861915.css?v=14861967">
<link rel="stylesheet" href="/assets/css/bm-actor-menu-sync-v14861967.css?v=14861967">
</head>
<body class="bm-actor-v98" data-theme="<?= bm_actor_e($userTheme) ?>">
<div class="menu-overlay" id="menuOverlay" aria-hidden="true"></div>
<div class="sidebar-menu" id="sidebarMenu" aria-hidden="true">
    <div class="sidebar-header">
        <span class="logo-text">BankMovie</span>
        <button class="sidebar-close" id="closeMenuBtn" type="button" aria-label="بستن">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
    </div>
    <?php if($currentUser): ?>
    <div class="sidebar-user">
        <div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div>
        <div class="sidebar-username"><?= bm_actor_e($currentUser['username'] ?? 'User') ?></div>
        <div class="sidebar-userrole"><?= strtolower((string)($currentUser['role'] ?? 'user')) === 'admin' ? ($userLang==='fa'?'مدیر':'Admin') : ($userLang==='fa'?'کاربر':'User') ?></div>
    </div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/player" class="sidebar-item"><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="/application" class="sidebar-item"><span><?= $userLang==='fa'?'اپلیکیشن‌ها':'Applications' ?></span></a>
        <a href="/search" class="sidebar-item"><span><?= $t[$userLang]['advanced_search'] ?></span></a>
        <?php if($currentUser): ?><a href="/profile" class="sidebar-item"><span><?= $t[$userLang]['profile'] ?></span></a><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if($currentUser): ?>
            <a href="/logout" class="sidebar-item"><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?>
            <a href="/login" class="sidebar-item"><span><?= $t[$userLang]['login'] ?></span></a>
            <a href="/register" class="sidebar-item"><span><?= $t[$userLang]['register'] ?></span></a>
        <?php endif; ?>
    </div>
</div>
<?php $bmHeaderClass='header'; require __DIR__ . '/partials/shared_header.php'; ?>

<main class="bm-actor-page">
<?php if($error): ?>
    <section class="actor-error"><a class="actor-back" href="javascript:history.back()" aria-label="بازگشت">←</a><div class="err"><?= bm_actor_e($error) ?></div></section>
<?php elseif($data): ?>
    <section class="actor-cover" aria-labelledby="actorTitle">
        <img class="actor-cover-bg" src="<?= bm_actor_e($actorPhoto) ?>" alt="" aria-hidden="true" onerror="this.style.display='none'">
        <div class="actor-cover-shade" aria-hidden="true"></div>
        <button class="actor-back" type="button" onclick="history.back()" aria-label="بازگشت">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
        </button>
        <div class="actor-profile">
            <img class="actor-avatar" src="<?= bm_actor_e($actorPhoto) ?>" alt="<?= bm_actor_e($data['name']) ?>" onerror="this.onerror=null;this.src='<?= bm_actor_e(bm_actor_page_placeholder_svg($data['name'] ?? '')) ?>';">
            <span class="actor-role"><?= bm_actor_e(bm_site_get('actor_role_label_fa','بازیگر')) ?></span>
            <h1 id="actorTitle"><?= bm_actor_e($data['name']) ?></h1>
        </div>
    </section>

    <section class="actor-catalog">
        <?php if (($data['status'] ?? '') === 'partial'): ?>
        <div class="actor-empty" style="margin-top:0;margin-bottom:18px">پروفایل بازیگر باز شد؛ فهرست آثار موقتاً از منبع قابل دریافت نیست.</div>
        <?php endif; ?>
        <div class="actor-results-title"><strong><?= (int)($data['count'] ?? count($data['movies'] ?? [])) ?></strong> <?= bm_actor_e(bm_site_get('actor_results_suffix_fa','عنوان پیدا شد')) ?></div>
        <?php if(!empty($data['movies'])): ?>
        <div class="actor-movie-grid">
            <?php foreach(($data['movies'] ?? []) as $item):
                $title = trim((string)($item['title_fa'] ?? $item['title'] ?? $item['title_en'] ?? ''));
                $note = trim((string)($item['update_note'] ?? ''));
                $hasDub = $note !== '' && preg_match('/دوبله|dubbed|dub/i', $note);
            ?>
            <a class="actor-movie-card" href="<?= bm_actor_e(bm_actor_movie_url($item)) ?>">
                <span class="actor-poster-shell">
                    <img class="actor-movie-poster" src="<?= bm_actor_e(function_exists('bm_poster_wrap_url') ? bm_poster_wrap_url((string)($item['poster'] ?? ''), ['type' => (string)($item['type'] ?? 'movie'), 'title' => $title, 'year' => (string)($item['year'] ?? '')]) : (string)($item['poster'] ?? '')) ?>" alt="<?= bm_actor_e($title) ?>" loading="lazy" decoding="async" onerror="this.onerror=null;this.src='/uploads/no.png';">
                    <?php if(!empty($item['year'])): ?><span class="actor-year"><?= bm_actor_e($item['year']) ?></span><?php endif; ?>
                    <?php if($hasDub): ?><span class="actor-dub" title="دوبله فارسی" aria-label="دوبله فارسی"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3.7 3.7 0 0 0-3.7 3.7v5.6a3.7 3.7 0 0 0 7.4 0V5.7A3.7 3.7 0 0 0 12 2Z"/><path d="M18.5 10.5a6.5 6.5 0 0 1-13 0M12 17v4M8.5 21h7"/></svg></span><?php endif; ?>
                </span>
                <h2><?= bm_actor_e($title) ?></h2>
            </a>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="actor-empty"><?= bm_actor_e(bm_site_get('actor_empty_text_fa','اثری برای این بازیگر پیدا نشد')) ?></div>
        <?php endif; ?>
    </section>
<?php endif; ?>
</main>

<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('actors.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>


<script>
(function(){
  var menuBtn=document.getElementById('menuBtn'),menu=document.getElementById('sidebarMenu'),overlay=document.getElementById('menuOverlay'),close=document.getElementById('closeMenuBtn');
  function setMenu(open){if(!menu||!overlay)return;menu.classList.toggle('open',open);overlay.classList.toggle('active',open);menu.setAttribute('aria-hidden',open?'false':'true');overlay.setAttribute('aria-hidden',open?'false':'true');document.body.classList.toggle('actor-menu-open',open);if(menuBtn)menuBtn.setAttribute('aria-expanded',open?'true':'false')}
  if(menuBtn)menuBtn.addEventListener('click',function(){setMenu(true)});
  if(close)close.addEventListener('click',function(){setMenu(false)});
  if(overlay)overlay.addEventListener('click',function(){setMenu(false)});
  var bell=document.getElementById('notifBell');if(bell)bell.addEventListener('click',function(){location.href='<?= $currentUser ? '/profile#notifications' : '/login' ?>'});
  var header=document.getElementById('siteHeader');function head(){if(header)header.classList.toggle('header-solid',(scrollY||0)>24)}head();addEventListener('scroll',head,{passive:true});
})();
</script>
<script src="/assets/js/bm-mobile-menu-v14861915.js?v=14861967" defer></script>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>
<script src="/assets/js/bm-actor-bottom-nav-v14861965.js?v=14861965-36" defer></script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=102.2" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
