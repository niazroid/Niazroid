<?php
// BankMovie Importer Pro
// Robust movie/series HTML importer for SerialBlog-like pages.

declare(strict_types=1);

require_once __DIR__ . '/includes/admin_guard.php';
require_admin();

$csrf_token = admin_csrf_token();
admin_enforce_csrf();

require_once __DIR__ . '/config.php';

// ---------------------------------------------------------
// Text / parsing helpers
// ---------------------------------------------------------
function bmNormalizeText(?string $text): string
{
    $text = html_entity_decode((string)$text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = str_replace(["\xC2\xA0", "\u{200C}", "\u{200F}", "\u{202A}", "\u{202B}", "\u{202C}"], ' ', $text);
    $text = str_replace(['ي', 'ك'], ['ی', 'ک'], $text);
    return trim((string)preg_replace('/\s+/u', ' ', $text));
}

function bmEnglishDigits(string $text): string
{
    return strtr($text, [
        '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
        '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
    ]);
}

function bmClassContains(DOMNode $node, string $class): bool
{
    if (!($node instanceof DOMElement)) return false;
    $classes = preg_split('/\s+/', trim($node->getAttribute('class'))) ?: [];
    return in_array($class, $classes, true);
}

function bmClosestClass(?DOMNode $node, string $class): ?DOMElement
{
    while ($node) {
        if ($node instanceof DOMElement && bmClassContains($node, $class)) return $node;
        $node = $node->parentNode;
    }
    return null;
}

function bmClosestTag(?DOMNode $node, string $tag): ?DOMElement
{
    $tag = strtolower($tag);
    while ($node) {
        if ($node instanceof DOMElement && strtolower($node->tagName) === $tag) return $node;
        $node = $node->parentNode;
    }
    return null;
}

function bmNodeContext(DOMXPath $xpath, ?DOMNode $node): string
{
    if (!$node) return '';
    $parts = [bmNormalizeText($node->textContent ?? '')];
    if ($node instanceof DOMElement && $node->hasAttribute('title')) {
        $parts[] = bmNormalizeText($node->getAttribute('title'));
    }
    $withTitle = $xpath->query('.//*[@title]', $node);
    if ($withTitle) {
        foreach ($withTitle as $el) {
            if ($el instanceof DOMElement) $parts[] = bmNormalizeText($el->getAttribute('title'));
        }
    }
    return bmNormalizeText(implode(' ', array_filter($parts)));
}

function bmCanonicalGenre(string $genre): string
{
    $genre = bmNormalizeText($genre);
    $genre = str_replace(['-', '–', '—', '_'], ' ', $genre);
    $genre = (string)preg_replace('/\s+/u', ' ', $genre);
    return trim($genre);
}

function getGenreMapping(): array
{
    return [
        'اکشن' => 'Action',
        'انیمیشن' => 'Animation',
        'بیوگرافی' => 'Biography',
        'بیوگرافی تاریخی' => 'Biography',
        'زندگی نامه' => 'Biography',
        'زندگینامه' => 'Biography',
        'تاریخی' => 'History',
        'تاک شو' => 'Talk-Show',
        'تالک شو' => 'Talk-Show',
        'ترسناک' => 'Horror',
        'جنایی' => 'Crime',
        'جنگی' => 'War',
        'خانوادگی' => 'Family',
        'خبری' => 'News',
        'درام' => 'Drama',
        'ریالیتی تی وی' => 'Reality-TV',
        'ریئلیتی تی وی' => 'Reality-TV',
        'شوی تلویزیونی' => 'TV Show',
        'عاشقانه' => 'Romance',
        'علمی تخیلی' => 'Sci-Fi',
        'فانتزی' => 'Fantasy',
        'فیلم نوآر' => 'Film-Noir',
        'کمدی' => 'Comedy',
        'کوتاه' => 'Short',
        'گیم شو' => 'Game-Show',
        'ماجراجویی' => 'Adventure',
        'مستند' => 'Documentary',
        'معمایی' => 'Mystery',
        'موزیک' => 'Music',
        'موسیقی' => 'Music',
        'موزیکال' => 'Musical',
        'هیجان انگیز' => 'Thriller',
        'ورزشی' => 'Sport',
        'وسترن' => 'Western',
    ];
}

function translateGenres(array $persianGenres): array
{
    $map = getGenreMapping();
    $result = [];
    foreach ($persianGenres as $genre) {
        $original = bmNormalizeText((string)$genre);
        if ($original === '') continue;
        $key = bmCanonicalGenre($original);
        $result[] = $map[$key] ?? $original;
    }
    return array_values(array_unique($result));
}

function bmExtractEnglishTitle(string $h1Text, int $year = 0): string
{
    $text = bmNormalizeText($h1Text);
    $text = (string)preg_replace('/^(?:دانلود\s+)?(?:فیلم|سریال)\s+/u', '', $text);

    // Common source format: Persian marketing title – English Title 2026
    $segments = preg_split('/\s+[–—]\s+|\s+-\s+/u', $text) ?: [$text];
    for ($i = count($segments) - 1; $i >= 0; $i--) {
        $segment = trim($segments[$i]);
        if (preg_match('/[A-Za-z]/', $segment)) {
            $segment = (string)preg_replace('/\b(?:19|20)\d{2}\b\s*$/', '', $segment);
            $segment = trim($segment, " \t\n\r\0\x0B-|–—");
            if ($segment !== '' && !preg_match('/[\x{0600}-\x{06FF}]/u', $segment)) return $segment;
        }
    }

    // Series format: Straight to Hell + Persian title
    if (preg_match('/^([A-Za-z0-9][A-Za-z0-9 .,&:+\'’!?()\-]{1,}?)(?=\s*[\x{0600}-\x{06FF}])/u', $text, $m)) {
        $candidate = trim($m[1]);
        $candidate = (string)preg_replace('/\b(?:19|20)\d{2}\b\s*$/', '', $candidate);
        return trim($candidate);
    }

    // Last-resort: longest latin-looking phrase.
    if (preg_match_all('/[A-Za-z][A-Za-z0-9 .,&:+\'’!?()\-]{1,}/u', $text, $matches)) {
        $best = '';
        foreach ($matches[0] as $candidate) {
            $candidate = trim((string)preg_replace('/\b(?:19|20)\d{2}\b\s*$/', '', trim($candidate)));
            if (mb_strlen($candidate) > mb_strlen($best)) $best = $candidate;
        }
        if ($best !== '') return $best;
    }

    if ($year > 0) $text = (string)preg_replace('/\b' . preg_quote((string)$year, '/') . '\b\s*$/', '', $text);
    return trim($text);
}

function bmExtractQuality(string ...$texts): string
{
    $haystack = bmEnglishDigits(bmNormalizeText(implode(' ', $texts)));
    $scan = str_replace(['.', '_'], ' ', $haystack);
    $scan = (string)preg_replace('/\s+/u', ' ', $scan);

    $resolution = '';
    if (preg_match('/\b(2160p|1080p|720p|480p|360p|4K)\b/i', $scan, $m)) {
        $resolution = strtoupper($m[1]) === '4K' ? '4K' : strtolower($m[1]);
    }

    $source = '';
    $sourcePatterns = [
        'Web-DL' => '/\bWEB\s*-?\s*DL\b/i',
        'WEBRip' => '/\bWEB\s*RIP\b/i',
        'BluRay' => '/\bBLU\s*-?\s*RAY\b|\bBLURAY\b/i',
        'HDTV' => '/\bHDTV\b/i',
        'HDRip' => '/\bHDRIP\b/i',
        'DVDRip' => '/\bDVDRIP\b/i',
    ];
    foreach ($sourcePatterns as $label => $pattern) {
        if (preg_match($pattern, $scan)) { $source = $label; break; }
    }

    $codec = '';
    if (preg_match('/\b(?:x265|H\.?265|HEVC)\b/i', $scan)) $codec = 'x265';
    elseif (preg_match('/\b(?:x264|H\.?264|AVC)\b/i', $scan)) $codec = 'x264';

    $bit = '';
    if (preg_match('/\b(10\s*bit|8\s*bit)\b/i', $scan, $m)) $bit = preg_replace('/\s+/', '', strtolower($m[1]));

    $quality = trim(implode(' ', array_filter([$resolution, $source, $codec, $bit])));
    return $quality !== '' ? $quality : 'Unknown';
}

function bmExtractSize(string $context): string
{
    $context = bmEnglishDigits(bmNormalizeText($context));
    $unitMap = [
        'gb' => 'GB', 'گیگابایت' => 'GB', 'گیگ' => 'GB',
        'mb' => 'MB', 'مگابایت' => 'MB', 'مگ' => 'MB',
        'kb' => 'KB', 'کیلوبایت' => 'KB', 'کیلو' => 'KB',
    ];
    if (preg_match('/(?:حجم\s*[:：]?\s*|\()?(\d+(?:\.\d+)?)\s*(GB|MB|KB|گیگابایت|گیگ|مگابایت|مگ|کیلوبایت|کیلو)\b/ui', $context, $m)) {
        $unitKey = mb_strtolower($m[2]);
        return $m[1] . ' ' . ($unitMap[$unitKey] ?? strtoupper($m[2]));
    }
    return '';
}

function bmDetectDownloadType(string $url, string $context): string
{
    $urlL = strtolower(rawurldecode($url));
    $ctx = mb_strtolower(bmNormalizeText($context));

    if (str_contains($urlL, 'softsub')) return 'softsub';
    if (str_contains($urlL, 'dubbed')) return 'dubbed';
    if (str_contains($urlL, 'nosub')) return 'nosub';

    if (preg_match('/دوبله|dubbed/u', $ctx)) return 'dubbed';
    if (preg_match('/سافت\s*ساب|زیرنویس\s*(?:چسبیده|فارسی)|soft\s*sub/u', $ctx)) return 'softsub';
    if (preg_match('/بدون\s*زیرنویس|نسخه\s*اصلی|no\s*sub|original/u', $ctx)) return 'nosub';
    return 'unknown';
}

function bmIsDownloadCandidate(DOMElement $link, string $url, string $text): bool
{
    if ($url === '' || preg_match('/^(?:#|javascript:|mailto:|tel:)/i', $url)) return false;
    if (str_contains($url, 'rzb.ir') || str_contains($url, '10_thous.html')) return false;

    $class = $link->getAttribute('class');
    if (preg_match('/(?:download-link-btn|dl-link-item|download)/i', $class)) return true;
    if (preg_match('/\.(?:mkv|mp4|avi|mov|m4v|rar|zip|7z)(?:[?#].*)?$/i', $url)) return true;
    if (preg_match('/\/(?:SoftSub|Dubbed|NoSub)(?:\/|$)/i', $url)) return true;
    if (preg_match('/دانلود|کیفیت|لینک/u', $text)) return true;
    return false;
}

function bmExtractGroupHeader(DOMXPath $xpath, DOMElement $link): string
{
    $seasonGroup = bmClosestClass($link, 'dl-season-links');
    if ($seasonGroup) {
        $header = $xpath->query('./div[contains(concat(" ", normalize-space(@class), " "), " dl-title-open ")]', $seasonGroup);
        if ($header && $header->length) return bmNormalizeText($header->item(0)->textContent);
    }

    // Movie pages often place "نسخه دوبله" / "نسخه سافت ساب" in preceding <p> siblings.
    $p = bmClosestTag($link, 'p');
    if ($p) {
        $texts = [];
        $prev = $p->previousSibling;
        $steps = 0;
        while ($prev && $steps < 6) {
            if ($prev instanceof DOMElement) {
                if (strtolower($prev->tagName) === 'hr') break;
                $t = bmNormalizeText($prev->textContent);
                if ($t !== '') $texts[] = $t;
                if (preg_match('/نسخه\s+(?:دوبله|سافت)|زیرنویس/u', $t)) break;
            }
            $prev = $prev->previousSibling;
            $steps++;
        }
        if ($texts) return bmNormalizeText(implode(' ', $texts));
    }
    return '';
}

function bmExtractDownloads(DOMXPath $xpath): array
{
    $downloads = [];
    $seen = [];
    $diagnostics = [
        'download_boxes' => 0,
        'anchors_seen' => 0,
        'candidates' => 0,
        'ignored' => 0,
        'duplicates' => 0,
        'unsupported' => 0,
    ];

    $boxes = $xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " download_box ")]');
    if (!$boxes || !$boxes->length) {
        // Fallback for theme changes: download tab/content container.
        $boxes = $xpath->query('//*[@id="content-downloads" or contains(concat(" ", normalize-space(@class), " "), " links-body ")]');
    }
    $diagnostics['download_boxes'] = $boxes ? $boxes->length : 0;

    if (!$boxes || !$boxes->length) return [$downloads, $diagnostics];

    foreach ($boxes as $box) {
        $allLinks = $xpath->query('.//a[@href]', $box);
        if (!$allLinks) continue;

        foreach ($allLinks as $link) {
            if (!($link instanceof DOMElement)) continue;
            $diagnostics['anchors_seen']++;

            $url = trim(html_entity_decode($link->getAttribute('href'), ENT_QUOTES | ENT_HTML5, 'UTF-8'));
            $anchorText = bmNormalizeText($link->textContent);
            if (!bmIsDownloadCandidate($link, $url, $anchorText)) {
                $diagnostics['ignored']++;
                continue;
            }
            $diagnostics['candidates']++;

            $key = strtolower($url);
            if (isset($seen[$key])) {
                $diagnostics['duplicates']++;
                continue;
            }
            $seen[$key] = true;

            $item = bmClosestClass($link, 'dl-items');
            $groupHeader = bmExtractGroupHeader($xpath, $link);
            $itemContext = $item ? bmNodeContext($xpath, $item) : bmNodeContext($xpath, $link->parentNode);
            $context = bmNormalizeText($anchorText . ' ' . $groupHeader . ' ' . $itemContext . ' ' . rawurldecode($url));

            $type = bmDetectDownloadType($url, $context);
            if ($type === 'unknown' || $type === 'nosub') $diagnostics['unsupported']++;

            $season = null;
            $episode = null;
            $numericContext = bmEnglishDigits($context);
            if (preg_match('/(?:\/|\b)S(\d{1,2})(?:\/|E|\b)/i', rawurldecode($url), $m)) $season = (int)$m[1];
            elseif (preg_match('/فصل\s*(\d{1,2})/u', $numericContext, $m)) $season = (int)$m[1];

            if (preg_match('/S\d{1,2}E(\d{1,3})/i', rawurldecode($url), $m)) $episode = (int)$m[1];
            elseif (preg_match('/قسمت\s*(\d{1,3})/u', $numericContext, $m)) $episode = (int)$m[1];

            $path = (string)(parse_url($url, PHP_URL_PATH) ?? '');
            $isFolder = 0;
            if ($path !== '' && str_ends_with($path, '/') && !preg_match('/\.(?:mkv|mp4|avi|mov|m4v|rar|zip|7z)$/i', $path)) $isFolder = 1;
            if (preg_match('/لینک\s*(?:های|‌های)?\s*دانلود/u', $context) && !preg_match('/\.(?:mkv|mp4|avi|mov|m4v|rar|zip|7z)(?:[?#].*)?$/i', $url)) $isFolder = 1;

            $downloads[] = [
                'type' => $type,
                'quality' => bmExtractQuality($groupHeader, $anchorText, rawurldecode($url)),
                'url' => $url,
                'size' => bmExtractSize($itemContext . ' ' . $anchorText),
                'season' => $season,
                'episode' => $episode,
                'is_folder' => $isFolder,
            ];
        }
    }

    return [$downloads, $diagnostics];
}

function bmParseInfoValue(DOMXPath $xpath, string $label): string
{
    $items = $xpath->query('//ul[contains(concat(" ", normalize-space(@class), " "), " flex-single-info ")]/li');
    if (!$items) return '';
    foreach ($items as $item) {
        $text = bmNormalizeText($item->textContent);
        if ($text === '' || mb_strpos($text, $label) === false) continue;
        $value = trim((string)preg_replace('/^.*?' . preg_quote($label, '/') . '\s*/u', '', $text));
        return bmNormalizeText($value);
    }
    return '';
}

function extractFromHtml(string $html): array
{
    if (!class_exists('DOMDocument')) {
        throw new RuntimeException('افزونه PHP DOM/XML روی سرور فعال نیست.');
    }

    $dom = new DOMDocument('1.0', 'UTF-8');
    $previous = libxml_use_internal_errors(true);
    $flags = LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING;
    $loaded = $dom->loadHTML('<?xml encoding="UTF-8">' . $html, $flags);
    $xmlErrors = libxml_get_errors();
    libxml_clear_errors();
    libxml_use_internal_errors($previous);

    if (!$loaded) throw new RuntimeException('HTML قابل پردازش نیست.');
    $xpath = new DOMXPath($dom);

    $h1Text = '';
    $h1 = $xpath->query('//h1[1]');
    if ($h1 && $h1->length) $h1Text = bmNormalizeText($h1->item(0)->textContent);

    $canonical = '';
    $canonicalNode = $xpath->query('//link[@rel="canonical"]/@href');
    if ($canonicalNode && $canonicalNode->length) $canonical = trim($canonicalNode->item(0)->nodeValue);

    $type = 'movie';
    if (mb_strpos($h1Text, 'سریال') !== false || str_contains($canonical, '/series/')) {
        $type = 'tvSeries';
    } elseif ($h1Text === '' && $canonical === '' && $xpath->query('//span[contains(concat(" ", normalize-space(@class), " "), " pr-item ")]//a[contains(@href,"/release-series/")]')->length) {
        $type = 'tvSeries';
    }

    // IMDb code - prefer the current article, not related cards/footer links.
    $imdbCode = '';
    $imdbLink = $xpath->query('//article//a[contains(@href, "imdb.com/title/tt")]');
    if (!$imdbLink || !$imdbLink->length) $imdbLink = $xpath->query('//a[contains(@href, "imdb.com/title/tt")]');
    if ($imdbLink && $imdbLink->length && preg_match('/tt\d+/i', $imdbLink->item(0)->getAttribute('href'), $m)) {
        $imdbCode = strtolower($m[0]);
    } elseif (preg_match('/\btt\d{5,12}\b/i', $html, $m)) {
        $imdbCode = strtolower($m[0]);
    }

    // Year (prefer release taxonomy link)
    $year = 0;
    $yearLinks = $xpath->query('//span[contains(concat(" ", normalize-space(@class), " "), " pr-item ")][contains(.,"سال انتشار")]//a[contains(@href, "/release-series/") or contains(@href, "/release/")]');
    if (!$yearLinks || !$yearLinks->length) $yearLinks = $xpath->query('//article//a[contains(@href, "/release-series/") or contains(@href, "/release/")]');
    if ($yearLinks) {
        foreach ($yearLinks as $node) {
            $text = bmEnglishDigits(bmNormalizeText($node->textContent));
            if (preg_match('/\b(19|20)\d{2}\b/', $text, $m)) { $year = (int)$m[0]; break; }
        }
    }
    if ($year === 0 && preg_match('/\b((?:19|20)\d{2})\b/u', bmEnglishDigits($h1Text), $m)) $year = (int)$m[1];

    $titleEn = bmExtractEnglishTitle($h1Text, $year);
    $titleFa = '';
    $h2 = $xpath->query('//h2[1]');
    if ($h2 && $h2->length) $titleFa = bmNormalizeText($h2->item(0)->textContent);

    // Rating + vote count
    $rate = 0.0;
    $votes = 0;
    $rateNode = $xpath->query('//*[contains(concat(" ", normalize-space(@class), " "), " -rate-number ")]');
    if ($rateNode && $rateNode->length) {
        $full = bmEnglishDigits(bmNormalizeText($rateNode->item(0)->textContent));
        $valueNode = $xpath->query('.//*[contains(concat(" ", normalize-space(@class), " "), " -rate-value ")]', $rateNode->item(0));
        if ($valueNode && $valueNode->length) {
            $value = bmEnglishDigits(bmNormalizeText($valueNode->item(0)->textContent));
            if (is_numeric($value)) $rate = (float)$value;
        }
        if ($rate <= 0 && preg_match('/(\d+(?:\.\d+)?)\s*\/\s*10/i', $full, $m)) $rate = (float)$m[1];
        if (preg_match('/\/\s*10\s*([\d,\.\s]+)/i', $full, $m)) {
            $votes = (int)preg_replace('/\D+/', '', $m[1]);
        }
    }

    // Country / release metadata
    $countryParts = [];
    $countryLinks = $xpath->query('//span[contains(concat(" ", normalize-space(@class), " "), " pr-item ")][contains(.,"محصول")]//a[contains(@href,"/country/") or contains(@href,"/country-series/")]');
    if (!$countryLinks || !$countryLinks->length) $countryLinks = $xpath->query('//article//a[contains(@href,"/country/") or contains(@href,"/country-series/")]');
    if ($countryLinks) {
        foreach ($countryLinks as $node) {
            $v = bmNormalizeText($node->textContent);
            if ($v !== '') $countryParts[] = $v;
        }
    }
    $country = implode(', ', array_values(array_unique($countryParts)));

    $languageParts = [];
    $languageLinks = $xpath->query('//li[contains(., "زبان")]//a');
    if ($languageLinks) {
        foreach ($languageLinks as $node) {
            $v = bmNormalizeText($node->textContent);
            if ($v !== '') $languageParts[] = $v;
        }
    }
    $language = implode(', ', array_values(array_unique($languageParts)));
    if ($language === '') $language = bmParseInfoValue($xpath, 'زبان');

    $rated = bmParseInfoValue($xpath, 'رده سنی');

    $description = '';
    $plot = $xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " -plot ")]//p[1]');
    if ($plot && $plot->length) $description = bmNormalizeText($plot->item(0)->textContent);

    $posterUrl = '';
    $poster = $xpath->query('//div[contains(concat(" ", normalize-space(@class), " "), " post-poster ")]//img[1]');
    if ($poster && $poster->length) {
        $src = trim($poster->item(0)->getAttribute('src'));
        if ($src === '' && $poster->item(0)->hasAttribute('data-src')) $src = trim($poster->item(0)->getAttribute('data-src'));
        $posterUrl = (string)preg_replace('/-\d+x\d+(?=\.[a-zA-Z]{2,5}(?:\?|$))/', '', $src);
        if ($posterUrl !== '' && !preg_match('~^https?://~i', $posterUrl)) {
            $posterUrl = 'https://serialblog1.top/' . ltrim($posterUrl, '/');
        }
    }

    $genresPersian = [];
    $genreLinks = $xpath->query('//span[contains(concat(" ", normalize-space(@class), " "), " pr-genre ")]//a');
    if ($genreLinks) {
        foreach ($genreLinks as $node) {
            $g = bmNormalizeText($node->textContent);
            if ($g !== '') $genresPersian[] = $g;
        }
    }
    if (!$genresPersian) {
        $genreLinks = $xpath->query('//article//a[contains(@href,"/genre-movies/") or contains(@href,"/genre-series/")]');
        if ($genreLinks) foreach ($genreLinks as $node) {
            $g = bmNormalizeText($node->textContent);
            if ($g !== '') $genresPersian[] = $g;
        }
    }
    $genresString = implode(', ', translateGenres(array_values(array_unique($genresPersian))));

    // Optional fields already present in the movies schema used by the old importer.
    $director = '';
    $actors = '';
    $directorNodes = $xpath->query('//article//a[contains(@href,"/director/") or contains(@href,"/directors/")]');
    if ($directorNodes && $directorNodes->length) {
        $vals = [];
        foreach ($directorNodes as $n) { $v = bmNormalizeText($n->textContent); if ($v !== '') $vals[] = $v; }
        $director = implode(', ', array_values(array_unique($vals)));
    }
    $actorNodes = $xpath->query('//article//a[contains(@href,"/actor/") or contains(@href,"/actors/")]');
    if ($actorNodes && $actorNodes->length) {
        $vals = [];
        foreach ($actorNodes as $n) { $v = bmNormalizeText($n->textContent); if ($v !== '') $vals[] = $v; }
        $actors = implode(', ', array_values(array_unique($vals)));
    }

    [$downloads, $downloadDiagnostics] = bmExtractDownloads($xpath);

    $seasonSet = [];
    $episodeSet = [];
    foreach ($downloads as $dl) {
        if (!empty($dl['season'])) $seasonSet[(int)$dl['season']] = true;
        if (!empty($dl['episode'])) $episodeSet[((int)($dl['season'] ?? 0)) . ':' . (int)$dl['episode']] = true;
    }
    $seasons = $seasonSet ? max(array_keys($seasonSet)) : null;
    $episodes = $episodeSet ? count($episodeSet) : null;

    $status = bmParseInfoValue($xpath, 'وضعیت');

    $warnings = [];
    if ($titleEn === '') $warnings[] = 'عنوان انگلیسی تشخیص داده نشد.';
    if ($imdbCode === '') $warnings[] = 'کد IMDb تشخیص داده نشد.';
    if (!$downloads) $warnings[] = 'هیچ لینک دانلود معتبری تشخیص داده نشد.';
    if ($downloadDiagnostics['unsupported'] > 0) $warnings[] = $downloadDiagnostics['unsupported'] . ' لینک از نوع NoSub/Unknown شناسایی شد و فقط در صورت وجود جدول سازگار قابل ذخیره است.';

    return [
        'title_en' => $titleEn,
        'title_fa' => $titleFa,
        'imdb_code' => $imdbCode,
        'rate' => $rate,
        'votes' => $votes,
        'year' => $year,
        'type' => $type,
        'country' => $country,
        'language' => $language,
        'description' => $description,
        'poster_url' => $posterUrl,
        'genres' => $genresString,
        'rated' => $rated,
        'director' => $director,
        'actors' => $actors,
        'status' => $status,
        'seasons' => $seasons,
        'episodes' => $episodes,
        'downloads' => $downloads,
        'diagnostics' => [
            'libxml_errors' => count($xmlErrors),
            'downloads' => $downloadDiagnostics,
            'warnings' => $warnings,
        ],
    ];
}

// ---------------------------------------------------------
// Poster mirroring (remote source -> local host)
// ---------------------------------------------------------
function bmIsPublicIp(string $ip): bool
{
    return filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false;
}

function bmValidateRemoteImageUrl(string $url): array
{
    $url = trim(html_entity_decode($url, ENT_QUOTES | ENT_HTML5, 'UTF-8'));
    if ($url === '' || !filter_var($url, FILTER_VALIDATE_URL)) return [false, 'آدرس پوستر معتبر نیست.'];
    $parts = parse_url($url);
    $scheme = strtolower((string)($parts['scheme'] ?? ''));
    $host = strtolower((string)($parts['host'] ?? ''));
    if (!in_array($scheme, ['http', 'https'], true) || $host === '') return [false, 'فقط پوستر HTTP/HTTPS مجاز است.'];
    if ($host === 'localhost' || str_ends_with($host, '.local')) return [false, 'مقصد محلی برای پوستر مجاز نیست.'];

    if (filter_var($host, FILTER_VALIDATE_IP)) {
        if (!bmIsPublicIp($host)) return [false, 'IP خصوصی/رزروشده برای پوستر مجاز نیست.'];
    } else {
        $ips = @gethostbynamel($host) ?: [];
        if (!$ips) return [false, 'DNS پوستر قابل Resolve نیست.'];
        foreach ($ips as $ip) {
            if (!bmIsPublicIp($ip)) return [false, 'دامنه پوستر به IP خصوصی/رزروشده Resolve می‌شود.'];
        }
    }
    return [true, $url];
}

function bmFetchRemoteImage(string $url, int $maxBytes = 8388608): array
{
    [$ok, $validated] = bmValidateRemoteImageUrl($url);
    if (!$ok) return ['ok'=>false, 'error'=>$validated];
    $url = $validated;

    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_CONNECTTIMEOUT => 6,
            CURLOPT_TIMEOUT => 14,
            CURLOPT_USERAGENT => 'BankMovie-PosterMirror/1.0',
            CURLOPT_HTTPHEADER => ['Accept: image/avif,image/webp,image/png,image/jpeg,image/*;q=0.8'],
            CURLOPT_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
            CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTP | CURLPROTO_HTTPS,
        ]);
        if (defined('CURLOPT_MAXFILESIZE')) curl_setopt($ch, CURLOPT_MAXFILESIZE, $maxBytes);
        $body = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $contentType = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        curl_close($ch);
        if ($body === false || $errno) return ['ok'=>false, 'error'=>'دانلود پوستر ناموفق بود: ' . ($error ?: 'cURL error')];
        if ($code < 200 || $code >= 300) return ['ok'=>false, 'error'=>'سرور پوستر HTTP ' . $code . ' برگرداند.'];
    } else {
        $ctx = stream_context_create([
            'http' => [
                'method' => 'GET', 'timeout' => 14, 'follow_location' => 0,
                'header' => "User-Agent: BankMovie-PosterMirror/1.0\r\nAccept: image/webp,image/png,image/jpeg,image/*;q=0.8\r\n",
            ],
            'ssl' => ['verify_peer'=>true, 'verify_peer_name'=>true],
        ]);
        $body = @file_get_contents($url, false, $ctx, 0, $maxBytes + 1);
        $contentType = '';
        if ($body === false) return ['ok'=>false, 'error'=>'دانلود پوستر روی این هاست ممکن نشد (cURL نیز در دسترس نیست).'];
    }

    $length = strlen((string)$body);
    if ($length < 64) return ['ok'=>false, 'error'=>'فایل پوستر دریافتی خالی/نامعتبر است.'];
    if ($length > $maxBytes) return ['ok'=>false, 'error'=>'حجم پوستر بیشتر از 8MB است.'];

    $mime = '';
    if (class_exists('finfo')) {
        $f = new finfo(FILEINFO_MIME_TYPE);
        $mime = (string)$f->buffer($body);
    }
    if ($mime === '' && $contentType !== '') $mime = strtolower(trim(explode(';', $contentType)[0]));
    $allowed = [
        'image/jpeg'=>'jpg',
        'image/png'=>'png',
        'image/webp'=>'webp',
        'image/avif'=>'avif',
    ];
    if (!isset($allowed[$mime])) return ['ok'=>false, 'error'=>'فرمت پوستر مجاز نیست (' . ($mime ?: 'unknown') . ').'];

    if ($mime !== 'image/avif' && function_exists('getimagesizefromstring') && @getimagesizefromstring($body) === false) {
        return ['ok'=>false, 'error'=>'محتوای دریافتی تصویر سالمی نیست.'];
    }
    return ['ok'=>true, 'bytes'=>$body, 'mime'=>$mime, 'ext'=>$allowed[$mime], 'size'=>$length];
}

function bmMirrorPosterToHost(string $remoteUrl, string $imdbCode): array
{
    $remoteUrl = trim($remoteUrl);
    $imdbCode = strtolower(trim($imdbCode));
    if ($remoteUrl === '') return ['status'=>'skipped', 'error'=>'پوستر در HTML پیدا نشد.'];
    if (!preg_match('/^tt\d{5,12}$/', $imdbCode)) return ['status'=>'skipped', 'error'=>'IMDb معتبر برای نام‌گذاری پوستر وجود ندارد.'];

    $fetched = bmFetchRemoteImage($remoteUrl);
    if (empty($fetched['ok'])) return ['status'=>'error', 'error'=>$fetched['error'] ?? 'دانلود پوستر ناموفق بود.'];

    $rootDir = rtrim((string)($_SERVER['DOCUMENT_ROOT'] ?? ''), '/\\');
    if ($rootDir === '') $rootDir = __DIR__;
    $dir = $rootDir . '/posters';
    if (!is_dir($dir) && !@mkdir($dir, 0755, true) && !is_dir($dir)) {
        return ['status'=>'error', 'error'=>'ساخت پوشه posters در روت سایت ممکن نشد؛ Permission هاست را بررسی کنید.'];
    }
    if (!is_writable($dir)) return ['status'=>'error', 'error'=>'پوشه posters قابل نوشتن نیست.'];

    $ext = $fetched['ext'];
    $filename = $imdbCode . '.' . $ext;
    $target = $dir . '/' . $filename;
    $tmp = $dir . '/.' . $imdbCode . '-' . bin2hex(random_bytes(5)) . '.tmp';
    if (@file_put_contents($tmp, $fetched['bytes'], LOCK_EX) === false) {
        return ['status'=>'error', 'error'=>'نوشتن فایل پوستر روی هاست ناموفق بود.'];
    }
    @chmod($tmp, 0644);
    if (!@rename($tmp, $target)) {
        @unlink($tmp);
        return ['status'=>'error', 'error'=>'انتقال نهایی فایل پوستر روی هاست ناموفق بود.'];
    }
    @chmod($target, 0644);

    // Remove old copies of the same IMDb with another extension.
    foreach (['jpg','jpeg','png','webp','avif'] as $oldExt) {
        $old = $dir . '/' . $imdbCode . '.' . $oldExt;
        if ($old !== $target && is_file($old)) @unlink($old);
    }

    $publicUrl = '/posters/' . rawurlencode($filename);

    return [
        'status'=>'success',
        'source_url'=>$remoteUrl,
        'local_path'=>$target,
        'public_url'=>$publicUrl,
        'filename'=>$filename,
        'mime'=>$fetched['mime'],
        'bytes'=>$fetched['size'],
    ];
}

// ---------------------------------------------------------
// Database helpers
// ---------------------------------------------------------
function bmTableExists(PDO $pdo, string $table): bool
{
    static $cache = [];
    if (array_key_exists($table, $cache)) return $cache[$table];
    try {
        $stmt = $pdo->prepare('SELECT 1 FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ? LIMIT 1');
        $stmt->execute([$table]);
        return $cache[$table] = (bool)$stmt->fetchColumn();
    } catch (Throwable $e) {
        // Some restricted DB users cannot read information_schema; direct read is a safe fallback.
        if (preg_match('/^[A-Za-z0-9_]+$/', $table)) {
            try {
                $pdo->query("SELECT 1 FROM `{$table}` LIMIT 1");
                return $cache[$table] = true;
            } catch (Throwable $ignored) {}
        }
        return $cache[$table] = false;
    }
}

function bmTableColumns(PDO $pdo, string $table): array
{
    static $cache = [];
    if (isset($cache[$table])) return $cache[$table];
    if (!preg_match('/^[A-Za-z0-9_]+$/', $table)) return [];
    try {
        $rows = $pdo->query("SHOW COLUMNS FROM `{$table}`")->fetchAll(PDO::FETCH_ASSOC);
        $cols = [];
        foreach ($rows as $row) $cols[$row['Field']] = true;
        return $cache[$table] = $cols;
    } catch (Throwable $e) {
        // Fallback to the schema already used by the previous importer.
        $known = [
            'movies' => ['id','title','title_fa','type','year','imdb_rate','imdb_votes','imdb_code','description','country','genres','director','actors','created_at','updated_at'],
            'movie_extra_info' => ['id','imdb_code','language','production_companies','status','rated','seasons','episodes','created_at','updated_at'],
            'softsub_links' => ['movie_id','quality','url','size','season','is_folder'],
            'dubbed_links' => ['movie_id','quality','url','size','season','is_folder'],
            'nosub_links' => ['movie_id','quality','url','size','season','is_folder'],
        ];
        $fallback = [];
        foreach (($known[$table] ?? []) as $col) $fallback[$col] = true;
        return $cache[$table] = $fallback;
    }
}

function bmNonEmptyValue(mixed $value): bool
{
    if (is_int($value) || is_float($value)) return $value > 0;
    return trim((string)$value) !== '';
}

function bmSyncLinkTable(PDO $pdo, string $table, int $movieId, array $links): int
{
    if (!$links || !bmTableExists($pdo, $table)) return 0;
    $columns = bmTableColumns($pdo, $table);
    $required = ['movie_id','quality','url','size','season','is_folder'];
    foreach ($required as $col) if (!isset($columns[$col])) return 0;

    $pdo->prepare("DELETE FROM `{$table}` WHERE movie_id = ?")->execute([$movieId]);
    $stmt = $pdo->prepare("INSERT INTO `{$table}` (movie_id, quality, url, size, season, is_folder) VALUES (?, ?, ?, ?, ?, ?)");
    $count = 0;
    $seen = [];
    foreach ($links as $dl) {
        $url = trim((string)$dl['url']);
        if ($url === '' || isset($seen[$url])) continue;
        $seen[$url] = true;
        $stmt->execute([$movieId, $dl['quality'], $url, $dl['size'], $dl['season'], $dl['is_folder']]);
        $count++;
    }
    return $count;
}

function upsertMovie(PDO $pdo, array $data): array
{
    $imdb = trim((string)($data['imdb_code'] ?? ''));
    if ($imdb === '') return ['status'=>'error','msg'=>'کد IMDb یافت نشد.'];

    try {
        $pdo->beginTransaction();
        $movieColumns = bmTableColumns($pdo, 'movies');
        $extraColumns = bmTableColumns($pdo, 'movie_extra_info');

        $stmt = $pdo->prepare('SELECT id FROM movies WHERE imdb_code = ? LIMIT 1');
        $stmt->execute([$imdb]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        $fieldsMap = [
            'title' => $data['title_en'] ?? '',
            'title_fa' => $data['title_fa'] ?? '',
            'type' => $data['type'] ?? '',
            'year' => $data['year'] ?? 0,
            'imdb_rate' => $data['rate'] ?? 0,
            'imdb_votes' => $data['votes'] ?? 0,
            'description' => $data['description'] ?? '',
            'country' => $data['country'] ?? '',
            'genres' => $data['genres'] ?? '',
            'director' => $data['director'] ?? '',
            'actors' => $data['actors'] ?? '',
        ];

        // Different BankMovie builds may use a different poster column name.
        // Pick the first supported column automatically and store the LOCAL host URL when available.
        $posterDbColumn = null;
        $posterValue = trim((string)($data['poster_url'] ?? ''));
        foreach (['poster_url','poster','cover_url','cover','image_url','image','thumbnail','poster_path','cover_path'] as $candidate) {
            if (isset($movieColumns[$candidate])) { $posterDbColumn = $candidate; break; }
        }
        if ($posterDbColumn !== null && $posterValue !== '') $fieldsMap[$posterDbColumn] = $posterValue;

        if ($existing) {
            $movieId = (int)$existing['id'];
            $sets = [];
            $params = [];
            foreach ($fieldsMap as $column => $value) {
                if (!isset($movieColumns[$column]) || !bmNonEmptyValue($value)) continue;
                $sets[] = "`{$column}` = ?";
                $params[] = $value;
            }
            if ($sets) {
                if (isset($movieColumns['updated_at'])) $sets[] = '`updated_at` = NOW()';
                $params[] = $movieId;
                $pdo->prepare('UPDATE movies SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($params);
            }
            $action = 'updated';
        } else {
            $insert = ['imdb_code' => $imdb] + $fieldsMap;
            $cols = [];
            $vals = [];
            foreach ($insert as $column => $value) {
                if (!isset($movieColumns[$column])) continue;
                $cols[] = "`{$column}`";
                $vals[] = $value;
            }
            $placeholders = array_fill(0, count($cols), '?');
            $createdSql = isset($movieColumns['created_at']) ? ', `created_at`' : '';
            $updatedSql = isset($movieColumns['updated_at']) ? ', `updated_at`' : '';
            $createdVal = isset($movieColumns['created_at']) ? ', NOW()' : '';
            $updatedVal = isset($movieColumns['updated_at']) ? ', NOW()' : '';
            $sql = 'INSERT INTO movies (' . implode(', ', $cols) . $createdSql . $updatedSql . ') VALUES (' . implode(', ', $placeholders) . $createdVal . $updatedVal . ')';
            $pdo->prepare($sql)->execute($vals);
            $movieId = (int)$pdo->lastInsertId();
            $action = 'inserted';
        }

        // Extra info: update only fields confidently extracted; never erase good old values with blanks.
        if (bmTableExists($pdo, 'movie_extra_info')) {
            $extraMap = [
                'language' => $data['language'] ?? '',
                'rated' => $data['rated'] ?? '',
                'status' => $data['status'] ?? '',
                'seasons' => $data['seasons'] ?? null,
                'episodes' => $data['episodes'] ?? null,
            ];
            $check = $pdo->prepare('SELECT id FROM movie_extra_info WHERE imdb_code = ? LIMIT 1');
            $check->execute([$imdb]);
            $extraExists = (bool)$check->fetchColumn();

            if ($extraExists) {
                $sets = [];
                $params = [];
                foreach ($extraMap as $column => $value) {
                    if (!isset($extraColumns[$column]) || !bmNonEmptyValue($value)) continue;
                    $sets[] = "`{$column}` = ?";
                    $params[] = $value;
                }
                if ($sets) {
                    if (isset($extraColumns['updated_at'])) $sets[] = '`updated_at` = NOW()';
                    $params[] = $imdb;
                    $pdo->prepare('UPDATE movie_extra_info SET ' . implode(', ', $sets) . ' WHERE imdb_code = ?')->execute($params);
                }
            } else {
                $base = ['imdb_code' => $imdb] + $extraMap;
                // Keep compatibility with the old schema if these columns are required.
                if (isset($extraColumns['production_companies'])) $base['production_companies'] = '';
                $cols = [];
                $vals = [];
                foreach ($base as $column => $value) {
                    if (!isset($extraColumns[$column])) continue;
                    $cols[] = "`{$column}`";
                    $vals[] = $value ?? null;
                }
                $ph = array_fill(0, count($cols), '?');
                $createdSql = isset($extraColumns['created_at']) ? ', `created_at`' : '';
                $updatedSql = isset($extraColumns['updated_at']) ? ', `updated_at`' : '';
                $createdVal = isset($extraColumns['created_at']) ? ', NOW()' : '';
                $updatedVal = isset($extraColumns['updated_at']) ? ', NOW()' : '';
                $pdo->prepare('INSERT INTO movie_extra_info (' . implode(', ', $cols) . $createdSql . $updatedSql . ') VALUES (' . implode(', ', $ph) . $createdVal . $updatedVal . ')')->execute($vals);
            }
        }

        $groups = ['softsub'=>[], 'dubbed'=>[], 'nosub'=>[], 'unknown'=>[]];
        foreach (($data['downloads'] ?? []) as $dl) {
            $type = $dl['type'] ?? 'unknown';
            if (!isset($groups[$type])) $type = 'unknown';
            $groups[$type][] = $dl;
        }

        // Important safety change: only replace a table when that type was actually extracted.
        // A temporary parser/source change can no longer wipe all existing links.
        $softsubCount = bmSyncLinkTable($pdo, 'softsub_links', $movieId, $groups['softsub']);
        $dubbedCount = bmSyncLinkTable($pdo, 'dubbed_links', $movieId, $groups['dubbed']);

        $nosubCount = 0;
        $nosubStored = false;
        if ($groups['nosub'] && bmTableExists($pdo, 'nosub_links')) {
            $nosubCount = bmSyncLinkTable($pdo, 'nosub_links', $movieId, $groups['nosub']);
            $nosubStored = true;
        }

        $pdo->commit();

        $parts = [
            'SoftSub: ' . $softsubCount,
            'Dubbed: ' . $dubbedCount,
        ];
        if ($groups['nosub']) $parts[] = 'NoSub: ' . ($nosubStored ? $nosubCount : count($groups['nosub']) . ' (جدول ندارد)');
        if ($groups['unknown']) $parts[] = 'Unknown: ' . count($groups['unknown']);

        return [
            'status' => 'success',
            'msg' => ($action === 'inserted' ? 'آیتم جدید با موفقیت اضافه شد.' : 'اطلاعات آیتم با موفقیت بروزرسانی شد.') . ' ' . implode(' | ', $parts),
            'movie_id' => $movieId,
            'action' => $action,
            'poster_db_column' => $posterDbColumn,
            'counts' => [
                'softsub' => $softsubCount,
                'dubbed' => $dubbedCount,
                'nosub' => $nosubCount,
                'nosub_detected' => count($groups['nosub']),
                'unknown' => count($groups['unknown']),
            ],
        ];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return ['status'=>'error','msg'=>'خطا در دیتابیس: ' . $e->getMessage()];
    }
}

// ---------------------------------------------------------
// Request processing
// ---------------------------------------------------------
$resultMsg = '';
$resultType = '';
$movieData = null;
$importResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $html = '';
        if (isset($_FILES['html_file']) && $_FILES['html_file']['error'] === UPLOAD_ERR_OK) {
            if ((int)$_FILES['html_file']['size'] > 30 * 1024 * 1024) throw new RuntimeException('حجم فایل بیشتر از 30MB است.');
            $html = (string)file_get_contents($_FILES['html_file']['tmp_name']);
        } elseif (!empty($_POST['html_code'])) {
            $html = (string)$_POST['html_code'];
        }

        if (trim($html) === '') throw new RuntimeException('یک فایل HTML انتخاب کنید یا کد HTML را وارد کنید.');
        $movieData = extractFromHtml($html);
        if (empty($movieData['imdb_code'])) throw new RuntimeException('کد IMDb در صفحه پیدا نشد؛ دیتابیس تغییر نکرد.');

        $movieData['poster_source_url'] = $movieData['poster_url'] ?? '';
        $movieData['poster_mirror'] = ['status'=>'disabled'];
        if (!empty($_POST['mirror_poster']) && !empty($movieData['poster_source_url'])) {
            $movieData['poster_mirror'] = bmMirrorPosterToHost($movieData['poster_source_url'], $movieData['imdb_code']);
            if (($movieData['poster_mirror']['status'] ?? '') === 'success') {
                $movieData['poster_url'] = $movieData['poster_mirror']['public_url'];
            }
        }

        $importResult = upsertMovie($pdo, $movieData);
        $resultMsg = $importResult['msg'];
        if (($movieData['poster_mirror']['status'] ?? '') === 'success') {
            $resultMsg .= ' | Cover: روی هاست ذخیره شد';
            if (empty($importResult['poster_db_column'])) $resultMsg .= ' (ستون کاور در جدول movies پیدا نشد)';
        } elseif (($movieData['poster_mirror']['status'] ?? '') === 'error') {
            $resultMsg .= ' | Cover: ذخیره محلی ناموفق';
        }
        $resultType = $importResult['status'] === 'success' ? 'success' : 'error';
        $movieData['action'] = $importResult['action'] ?? 'none';
        $movieData['poster_db_column'] = $importResult['poster_db_column'] ?? null;
    } catch (Throwable $e) {
        $resultMsg = $e->getMessage();
        $resultType = 'error';
    }
}

$downloadCounts = ['softsub'=>0,'dubbed'=>0,'nosub'=>0,'unknown'=>0];
if ($movieData) {
    foreach ($movieData['downloads'] as $dl) {
        $t = $dl['type'] ?? 'unknown';
        if (!isset($downloadCounts[$t])) $t = 'unknown';
        $downloadCounts[$t]++;
    }
}
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="color-scheme" content="dark">
    <title>BankMovie Importer Pro</title>
    <style>
        :root{
            --bg:#05080d;--panel:#0b1119;--panel2:#101823;--line:rgba(255,255,255,.075);
            --text:#f5f7fb;--muted:#8290a3;--green:#55e6b5;--cyan:#67d8ff;--violet:#9b87ff;
            --warning:#ffc966;--danger:#ff7890;--shadow:0 24px 80px rgba(0,0,0,.42);
        }
        *{box-sizing:border-box}html{background:var(--bg)}body{margin:0;min-height:100vh;color:var(--text);font-family:Inter,Tahoma,Arial,sans-serif;background:
            radial-gradient(900px 500px at 90% -10%,rgba(103,216,255,.13),transparent 62%),
            radial-gradient(800px 520px at -10% 10%,rgba(155,135,255,.12),transparent 64%),
            linear-gradient(180deg,#060a10 0%,#05080d 100%);padding:28px 16px 60px;overflow-x:hidden}
        body:before{content:"";position:fixed;inset:0;pointer-events:none;opacity:.26;background-image:linear-gradient(rgba(255,255,255,.017) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.017) 1px,transparent 1px);background-size:34px 34px;mask-image:linear-gradient(to bottom,#000,transparent 72%)}
        .wrap{position:relative;max-width:1240px;margin:auto}.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin:0 2px 22px}.brand{display:flex;align-items:center;gap:13px}.logo{width:46px;height:46px;border-radius:15px;display:grid;place-items:center;font-size:20px;font-weight:900;background:linear-gradient(145deg,rgba(103,216,255,.22),rgba(155,135,255,.19));border:1px solid rgba(255,255,255,.12);box-shadow:inset 0 1px 0 rgba(255,255,255,.12),0 12px 32px rgba(0,0,0,.25)}
        .brand h1{font-size:16px;margin:0 0 4px;letter-spacing:.1px}.brand p{font-size:10px;color:var(--muted);margin:0}.version{display:flex;align-items:center;gap:8px;padding:8px 12px;border-radius:999px;border:1px solid var(--line);background:rgba(10,15,23,.72);backdrop-filter:blur(16px);font-size:10px;color:#aab7c7}.version:before{content:"";width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 16px var(--green)}
        .card{position:relative;background:linear-gradient(180deg,rgba(16,24,35,.91),rgba(8,13,20,.93));border:1px solid var(--line);border-radius:24px;box-shadow:var(--shadow);overflow:hidden;backdrop-filter:blur(18px)}.card:after{content:"";position:absolute;inset:0;pointer-events:none;border-radius:inherit;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)}
        .hero{display:grid;grid-template-columns:1.17fr .83fr;gap:16px;margin-bottom:16px}.intro{padding:30px}.eyebrow{display:inline-flex;align-items:center;gap:7px;color:#9ce8ff;font-size:9px;font-weight:800;letter-spacing:2px;text-transform:uppercase;margin-bottom:13px}.eyebrow:before{content:"";width:18px;height:1px;background:#67d8ff;box-shadow:0 0 9px #67d8ff}.intro h2{max-width:720px;margin:0 0 12px;font-size:27px;line-height:1.65;font-weight:800;letter-spacing:-.4px}.intro p{margin:0;max-width:760px;color:#9aa8ba;font-size:11px;line-height:2}
        .feature-grid{padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:10px}.feature{position:relative;padding:16px;border:1px solid rgba(255,255,255,.055);border-radius:17px;background:linear-gradient(145deg,rgba(255,255,255,.035),rgba(255,255,255,.012));min-height:96px}.feature strong{display:block;font-size:11px;margin-bottom:8px}.feature span{display:block;color:#75859a;font-size:9.5px;line-height:1.8}.feature.premium{background:linear-gradient(145deg,rgba(85,230,181,.07),rgba(103,216,255,.025));border-color:rgba(85,230,181,.13)}
        .form-card{padding:22px;margin-bottom:16px}.form-title,.section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:15px}.form-title h3,.section-head h3{margin:0;font-size:13px}.form-title span{font-size:9px;color:var(--muted)}.source-grid{display:grid;grid-template-columns:.9fr 1.1fr;gap:14px}.field-label{font-size:10px;color:#aeb9c7;margin:0 2px 8px;font-weight:700}.drop,textarea{width:100%;height:174px;border:1px solid rgba(255,255,255,.075);border-radius:18px;background:#070d14;color:#d9e3ef;transition:.2s}.drop{display:grid;place-items:center;text-align:center;padding:20px;cursor:pointer}.drop:hover,.drop.drag{border-color:rgba(103,216,255,.46);background:#09131d;box-shadow:inset 0 0 35px rgba(103,216,255,.03)}.drop .big{font-size:27px;color:#8da0b5;margin-bottom:10px}.drop p{font-size:10px;line-height:1.8;color:#8d9caf;margin:0}.filename{color:#c8d5e3}.drop.drag .big{color:var(--cyan)}textarea{resize:vertical;padding:15px;direction:ltr;text-align:left;font:10px/1.75 ui-monospace,SFMono-Regular,Consolas,monospace;outline:none}textarea:focus{border-color:rgba(155,135,255,.45);box-shadow:0 0 0 3px rgba(155,135,255,.06)}
        .options{display:flex;flex-wrap:wrap;gap:10px;margin-top:13px}.switch-card{display:flex;align-items:center;gap:10px;min-width:280px;padding:11px 13px;border-radius:15px;border:1px solid rgba(85,230,181,.13);background:rgba(85,230,181,.035);cursor:pointer}.switch-card input{appearance:none;width:34px;height:19px;border-radius:999px;background:#243141;position:relative;transition:.2s;margin:0}.switch-card input:after{content:"";position:absolute;width:13px;height:13px;border-radius:50%;background:#9cabbc;top:3px;left:3px;transition:.2s}.switch-card input:checked{background:rgba(85,230,181,.35)}.switch-card input:checked:after{left:18px;background:var(--green);box-shadow:0 0 10px rgba(85,230,181,.6)}.switch-card b{font-size:10px;display:block;margin-bottom:3px}.switch-card small{display:block;color:#6f8094;font-size:8.5px}.submit{margin-top:14px;width:100%;border:0;border-radius:16px;padding:14px 18px;color:#06100d;background:linear-gradient(100deg,#55e6b5,#77dff6);font-size:11px;font-weight:900;cursor:pointer;box-shadow:0 12px 30px rgba(85,230,181,.11);transition:.2s}.submit:hover{transform:translateY(-1px);filter:saturate(1.1) brightness(1.03)}.submit:disabled{opacity:.58;cursor:wait;transform:none}
        .result{display:grid;grid-template-columns:auto 1fr;gap:8px 14px;align-items:center;padding:15px 17px;border-radius:18px;margin:0 0 16px;border:1px solid}.result strong{font-size:11px}.result span{font-size:10px;line-height:1.8}.result.success{background:rgba(85,230,181,.055);border-color:rgba(85,230,181,.18);color:#bdf8e5}.result.error{background:rgba(255,120,144,.055);border-color:rgba(255,120,144,.18);color:#ffc1cd}
        .section{padding:22px;margin-bottom:16px}.badge{display:inline-flex;align-items:center;gap:6px;padding:7px 10px;border:1px solid rgba(255,255,255,.08);border-radius:999px;background:rgba(255,255,255,.025);color:#a7b5c6;font-size:9px}.badge.movie{color:#9fe7ff;border-color:rgba(103,216,255,.18)}.badge.tv{color:#cbbfff;border-color:rgba(155,135,255,.22)}.badge.local{color:#adf5dc;border-color:rgba(85,230,181,.22);background:rgba(85,230,181,.045)}
        .movie-summary{display:grid;grid-template-columns:178px 1fr;gap:20px}.poster-shell{position:relative}.poster{width:178px;height:267px;object-fit:cover;border-radius:18px;border:1px solid rgba(255,255,255,.09);background:#080d14;box-shadow:0 20px 45px rgba(0,0,0,.33)}.poster-empty{display:grid;place-items:center;color:#364456;font-size:38px}.cover-state{margin-top:9px;font-size:9px;line-height:1.7;color:#8291a4}.cover-state.ok{color:#8becc9}.cover-state.err{color:#ffadbd}.cover-path{direction:ltr;text-align:left;word-break:break-all;color:#708196;font-size:8px;margin-top:4px}
        .meta{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.meta-item{min-width:0;padding:13px 14px;border-radius:15px;background:rgba(255,255,255,.024);border:1px solid rgba(255,255,255,.045)}.meta-item span{display:block;color:#66788e;font-size:8.5px;margin-bottom:6px}.meta-item strong{display:block;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.plot{margin-top:10px;padding:14px 15px;border-radius:15px;border:1px solid rgba(255,255,255,.045);background:#080e16;color:#9aa9ba;font-size:10px;line-height:2}
        .stats{display:grid;grid-template-columns:repeat(4,1fr);gap:9px;margin-bottom:13px}.stat{padding:14px;border-radius:15px;background:#080f17;border:1px solid rgba(255,255,255,.055)}.stat b{font-size:20px;display:block;margin-bottom:5px}.stat span{font-size:9px;color:#708196}.warning{padding:10px 12px;border-radius:12px;background:rgba(255,201,102,.055);border:1px solid rgba(255,201,102,.16);color:#f1d398;font-size:10px;line-height:1.8;margin-bottom:8px}
        .table-wrap{overflow:auto;border:1px solid rgba(255,255,255,.06);border-radius:16px}.links-table{width:100%;border-collapse:collapse;min-width:840px;background:#070d14}.links-table th,.links-table td{padding:11px 12px;border-bottom:1px solid rgba(255,255,255,.045);text-align:right;font-size:10px}.links-table th{position:sticky;top:0;z-index:1;background:#0d151f;color:#91a1b4}.links-table tr:last-child td{border-bottom:0}.links-table tbody tr:hover{background:rgba(255,255,255,.018)}.links-table td.url{direction:ltr;text-align:left;max-width:380px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.type-pill{display:inline-block;padding:5px 8px;border-radius:999px;font-size:9px;border:1px solid}.type-softsub{color:#9ff0db;border-color:#276f62}.type-dubbed{color:#d9c6ff;border-color:#674d9f}.type-nosub{color:#ffe0a2;border-color:#8b6b2e}.type-unknown{color:#ffbdca;border-color:#874353}
        details{margin-top:14px}summary{cursor:pointer;color:#8fa0b3;font-size:10px}pre{direction:ltr;text-align:left;white-space:pre-wrap;word-break:break-word;background:#050a10;border:1px solid rgba(255,255,255,.055);border-radius:14px;padding:14px;color:#9aabba;font-size:9px;max-height:360px;overflow:auto}.foot{text-align:center;color:#435165;font-size:9px;margin-top:22px;letter-spacing:.3px}
        @media(max-width:900px){.hero,.source-grid{grid-template-columns:1fr}.feature-grid{grid-template-columns:1fr 1fr}.movie-summary{grid-template-columns:1fr}.poster{width:100%;height:320px;object-fit:contain}.meta{grid-template-columns:1fr 1fr}.stats{grid-template-columns:1fr 1fr}}
        @media(max-width:560px){body{padding:18px 10px 38px}.topbar{align-items:flex-start}.version{display:none}.intro{padding:21px}.intro h2{font-size:21px}.feature-grid,.meta{grid-template-columns:1fr}.card{border-radius:19px}.section,.form-card{padding:16px}.switch-card{min-width:100%}}
    </style>
    <!-- Keep project-wide performance hooks if these assets exist; harmless if cached by the site. -->
    <link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
</head>
<body>
<div class="wrap">
    <div class="topbar">
        <div class="brand">
            <div class="logo">↯</div>
            <div><h1>BankMovie Importer Pro</h1><p>استخراج دقیق اطلاعات و همگام‌سازی امن لینک‌های دانلود</p></div>
        </div>
        <div class="version">Parser v2.1 · Local Cover Mirror</div>
    </div>

    <div class="hero">
        <section class="card intro">
            <div class="eyebrow">SMART HTML PARSER</div>
            <h2>ورودی خام را می‌خواند؛ دیتای تمیز و قابل اعتماد ذخیره می‌کند.</h2>
            <p>تشخیص فیلم/سریال، عنوان انگلیسی تمیز، IMDb، امتیاز و رأی، ژانر، زبان، رده سنی و لینک‌های چندکیفیتی با محافظت در برابر پاک‌شدن ناخواسته لینک‌های قبلی.</p>
        </section>
        <section class="card feature-grid">
            <div class="feature"><strong>🔗 لینک‌یابی مقاوم</strong><span>همه لینک‌های باکس دانلود + حذف تکراری‌ها</span></div>
            <div class="feature"><strong>🎞 کیفیت دقیق</strong><span>Resolution + Source + Codec + Bit depth</span></div>
            <div class="feature"><strong>🛡 Safe Sync</strong><span>خالی شدن یک parser دیگر لینک‌های سالم را پاک نمی‌کند</span></div>
            <div class="feature premium"><strong>🖼 Local Cover</strong><span>دانلود امن پوستر و ذخیره مستقیم روی هاست</span></div>
        </section>
    </div>

    <section class="card form-card">
        <div class="form-title"><h3>ورودی صفحه</h3><span>یکی از دو روش کافی است</span></div>
        <form method="post" enctype="multipart/form-data" id="importForm">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token, ENT_QUOTES, 'UTF-8') ?>">
            <div class="source-grid">
                <div>
                    <div class="field-label">📁 فایل HTML</div>
                    <label class="drop" id="dropZone" for="htmlFile">
                        <input type="file" id="htmlFile" name="html_file" accept=".html,.htm,.txt,text/html" hidden>
                        <div><div class="big">⇧</div><p id="fileLabel">فایل ذخیره‌شده صفحه را انتخاب یا اینجا رها کنید<br><span class="filename">HTML / HTM تا 30MB</span></p></div>
                    </label>
                </div>
                <div>
                    <div class="field-label">⌘ کد HTML</div>
                    <textarea name="html_code" id="htmlCode" placeholder="<html> ... </html>"></textarea>
                </div>
            </div>
            <div class="options">
                <label class="switch-card">
                    <input type="checkbox" name="mirror_poster" value="1" checked>
                    <span><b>ذخیره کاور روی همین هاست</b><small>پوستر با نام IMDb داخل uploads/posters ذخیره و در صورت وجود ستون سازگار، مسیر محلی در دیتابیس ثبت می‌شود.</small></span>
                </label>
            </div>
            <button class="submit" id="submitBtn" type="submit">پردازش هوشمند و همگام‌سازی امن</button>
        </form>
    </section>

    <?php if ($resultMsg): ?>
        <div class="result <?= $resultType === 'success' ? 'success' : 'error' ?>">
            <strong><?= $resultType === 'success' ? '✓ عملیات انجام شد' : '× عملیات متوقف شد' ?></strong>
            <span><?= htmlspecialchars($resultMsg, ENT_QUOTES, 'UTF-8') ?></span>
        </div>
    <?php endif; ?>

    <?php if ($movieData): ?>
        <section class="card section">
            <div class="section-head">
                <h3>اطلاعات استخراج‌شده</h3>
                <span class="badge <?= $movieData['type']==='tvSeries'?'tv':'movie' ?>"><?= $movieData['type']==='tvSeries'?'سریال · tvSeries':'فیلم · movie' ?></span>
            </div>
            <div class="movie-summary">
                <div class="poster-shell">
                    <?php if (!empty($movieData['poster_url'])): ?>
                        <img class="poster" src="<?= htmlspecialchars($movieData['poster_url'], ENT_QUOTES, 'UTF-8') ?>" alt="poster" referrerpolicy="no-referrer">
                    <?php else: ?>
                        <div class="poster poster-empty">▧</div>
                    <?php endif; ?>
                    <?php $pm = $movieData['poster_mirror'] ?? ['status'=>'disabled']; ?>
                    <?php if (($pm['status'] ?? '') === 'success'): ?>
                        <div class="cover-state ok">● کاور روی هاست ذخیره شد</div>
                        <div class="cover-path"><?= htmlspecialchars($pm['public_url'] ?? '', ENT_QUOTES, 'UTF-8') ?></div>
                    <?php elseif (($pm['status'] ?? '') === 'error'): ?>
                        <div class="cover-state err">● ذخیره محلی ناموفق: <?= htmlspecialchars($pm['error'] ?? 'خطای نامشخص', ENT_QUOTES, 'UTF-8') ?></div>
                    <?php elseif (!empty($movieData['poster_source_url'])): ?>
                        <div class="cover-state">● نمایش از منبع خارجی</div>
                    <?php endif; ?>
                </div>
                <div>
                    <div class="meta">
                        <div class="meta-item"><span>IMDb</span><strong><?= htmlspecialchars($movieData['imdb_code'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>عنوان اصلی</span><strong title="<?= htmlspecialchars($movieData['title_en'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($movieData['title_en'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>عنوان فارسی</span><strong><?= htmlspecialchars($movieData['title_fa'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>سال</span><strong><?= $movieData['year'] ?: '—' ?></strong></div>
                        <div class="meta-item"><span>IMDb Rating</span><strong><?= $movieData['rate'] > 0 ? htmlspecialchars((string)$movieData['rate']) . ' / 10' : '—' ?> · <?= number_format((int)$movieData['votes']) ?> رأی</strong></div>
                        <div class="meta-item"><span>کشور</span><strong><?= htmlspecialchars($movieData['country'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>زبان</span><strong><?= htmlspecialchars($movieData['language'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>ژانر</span><strong><?= htmlspecialchars($movieData['genres'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>رده سنی</span><strong><?= htmlspecialchars($movieData['rated'] ?: '—') ?></strong></div>
                        <div class="meta-item"><span>ذخیره کاور DB</span><strong><?= htmlspecialchars($movieData['poster_db_column'] ?: 'ستون سازگار پیدا نشد') ?></strong></div>
                    </div>
                    <?php if (!empty($movieData['description'])): ?><div class="plot"><?= htmlspecialchars($movieData['description']) ?></div><?php endif; ?>
                </div>
            </div>
        </section>

        <section class="card section">
            <div class="section-head"><h3>لینک‌های شناسایی‌شده</h3><span class="badge"><?= count($movieData['downloads']) ?> لینک یکتا</span></div>
            <div class="stats">
                <div class="stat"><b><?= $downloadCounts['softsub'] ?></b><span>SoftSub</span></div>
                <div class="stat"><b><?= $downloadCounts['dubbed'] ?></b><span>Dubbed</span></div>
                <div class="stat"><b><?= $downloadCounts['nosub'] ?></b><span>NoSub</span></div>
                <div class="stat"><b><?= $downloadCounts['unknown'] ?></b><span>Unknown</span></div>
            </div>

            <?php foreach (($movieData['diagnostics']['warnings'] ?? []) as $warning): ?>
                <div class="warning">⚠ <?= htmlspecialchars($warning, ENT_QUOTES, 'UTF-8') ?></div>
            <?php endforeach; ?>

            <?php if ($movieData['downloads']): ?>
                <div class="table-wrap">
                    <table class="links-table">
                        <thead><tr><th>#</th><th>نوع</th><th>فصل</th><th>قسمت</th><th>کیفیت</th><th>حجم</th><th>URL</th></tr></thead>
                        <tbody>
                        <?php foreach ($movieData['downloads'] as $i => $dl): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><span class="type-pill type-<?= htmlspecialchars($dl['type']) ?>"><?= htmlspecialchars($dl['type']) ?></span></td>
                                <td><?= $dl['season'] ?? '—' ?></td>
                                <td><?= $dl['episode'] ?? '—' ?></td>
                                <td><?= htmlspecialchars($dl['quality'] ?: '—') ?></td>
                                <td><?= htmlspecialchars($dl['size'] ?: '—') ?></td>
                                <td class="url" title="<?= htmlspecialchars($dl['url'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($dl['url']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <details><summary>جزئیات فنی Parser</summary><pre><?= htmlspecialchars(print_r($movieData['diagnostics'], true), ENT_QUOTES, 'UTF-8') ?></pre></details>
        </section>
    <?php endif; ?>

    <div class="foot">BankMovie Importer Pro · local-cover · transaction-safe · duplicate-safe · diagnostics</div>
</div>
<script>
(() => {
    const file = document.getElementById('htmlFile');
    const zone = document.getElementById('dropZone');
    const label = document.getElementById('fileLabel');
    const form = document.getElementById('importForm');
    const submit = document.getElementById('submitBtn');

    const showFile = f => {
        if (!f) return;
        label.innerHTML = 'فایل انتخاب شد<br><span class="filename"></span>';
        label.querySelector('.filename').textContent = `${f.name} · ${(f.size / 1024 / 1024).toFixed(2)} MB`;
    };
    file?.addEventListener('change', () => showFile(file.files?.[0]));
    ['dragenter','dragover'].forEach(ev => zone?.addEventListener(ev, e => { e.preventDefault(); zone.classList.add('drag'); }));
    ['dragleave','drop'].forEach(ev => zone?.addEventListener(ev, e => { e.preventDefault(); zone.classList.remove('drag'); }));
    zone?.addEventListener('drop', e => {
        if (!e.dataTransfer?.files?.length) return;
        const dt = new DataTransfer(); dt.items.add(e.dataTransfer.files[0]); file.files = dt.files; showFile(file.files[0]);
    });
    form?.addEventListener('submit', () => {
        submit.disabled = true;
        submit.textContent = 'در حال پردازش و همگام‌سازی…';
    });
})();
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>