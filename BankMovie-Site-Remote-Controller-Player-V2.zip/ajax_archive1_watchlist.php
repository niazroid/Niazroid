<?php
// ajax_archive1_watchlist.php - مخصوص واچ‌لیست آرشیو ۱، بدون وابستگی به imdb_code آرشیو ۲
require_once 'config.php';
require_once __DIR__ . '/includes/vip_features.php';
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$currentUser = null;
if (isset($_COOKIE['session_token'])) {
    $user = new User($pdo);
    $currentUser = $user->checkSession($_COOKIE['session_token']);
}

bm_vip_gate_require('watchlist', $currentUser ?: null, true);

$bmWatchlistIdentity = $currentUser ? ('user:' . (int)$currentUser['id']) : ('ip:' . bm_security_client_ip());
bm_security_enforce_rate_limit('archive1_watchlist_read', 240, 300, $bmWatchlistIdentity, true);

function bm_arc1_json($data) {
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function bm_arc1_action(): string {
    foreach (['action', 'bm_action', 'watchlist_action', 'do', 'task', 'mode'] as $key) {
        if (isset($_POST[$key]) && trim((string)$_POST[$key]) !== '') return strtolower(trim((string)$_POST[$key]));
        if (isset($_GET[$key]) && trim((string)$_GET[$key]) !== '') return strtolower(trim((string)$_GET[$key]));
    }
    if (isset($_POST['item_link'])) return 'toggle';
    return '';
}

function bm_arc1_table(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        item_link VARCHAR(500) NOT NULL,
        item_title VARCHAR(300) NOT NULL DEFAULT '',
        item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
        item_year VARCHAR(10) DEFAULT NULL,
        item_poster VARCHAR(500) DEFAULT NULL,
        item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
        item_type VARCHAR(20) DEFAULT 'movie',
        added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_link (user_id, item_link(200)),
        KEY idx_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

try {
    if (!$currentUser) bm_arc1_json(['success' => false, 'error' => 'Please login']);

    bm_require_post(true);
    bm_require_user_csrf(true, true);
    bm_security_enforce_rate_limit('archive1_watchlist_write', 120, 300, 'user:' . (int)$currentUser['id'], true);

    bm_arc1_table($pdo);

    $action = bm_arc1_action();
    $aliases = [
        'add_watchlist' => 'add',
        'remove_watchlist' => 'remove',
        'delete' => 'remove',
        'toggle_watchlist' => 'toggle',
        'add_archive1' => 'add',
        'remove_archive1' => 'remove',
    ];
    if (isset($aliases[$action])) $action = $aliases[$action];

    $userId = (int)$currentUser['id'];
    $id = (int)($_POST['id'] ?? $_GET['id'] ?? 0);
    $rawItemLink = bm_security_limit_text($_POST['item_link'] ?? $_POST['link'] ?? $_POST['url'] ?? $_GET['item_link'] ?? '', 500);
    $itemLink = bm_security_safe_navigation_url($rawItemLink, true);

    if ($action === 'remove') {
        if ($id > 0) {
            $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND id = ?");
            $stmt->execute([$userId, $id]);
            bm_arc1_json(['success' => true, 'added' => false, 'message' => 'removed']);
        }
        if ($rawItemLink !== '') {
            $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND item_link = ?");
            $stmt->execute([$userId, $rawItemLink]);
            bm_arc1_json(['success' => true, 'added' => false, 'message' => 'removed']);
        }
        bm_arc1_json(['success' => false, 'error' => 'id or item_link is invalid']);
    }

    if (!in_array($action, ['add', 'toggle', ''], true)) {
        bm_arc1_json(['success' => false, 'error' => 'Invalid archive1 watchlist request', 'received_action' => $action]);
    }

    if ($itemLink === '') bm_arc1_json(['success' => false, 'error' => 'item_link is invalid']);

    $stmt = $pdo->prepare("SELECT id FROM archive1_watchlist WHERE user_id = ? AND item_link = ? LIMIT 1");
    $stmt->execute([$userId, $itemLink]);
    $existingId = (int)($stmt->fetchColumn() ?: 0);

    if (($action === 'toggle' || $action === '') && $existingId > 0) {
        $stmt = $pdo->prepare("DELETE FROM archive1_watchlist WHERE user_id = ? AND id = ?");
        $stmt->execute([$userId, $existingId]);
        bm_arc1_json(['success' => true, 'added' => false, 'id' => $existingId, 'message' => 'removed']);
    }

    if ($existingId > 0) {
        bm_arc1_json(['success' => true, 'added' => true, 'id' => $existingId, 'message' => 'already exists']);
    }

    $stmt = $pdo->prepare("INSERT INTO archive1_watchlist
        (user_id, item_link, item_title, item_title_fa, item_year, item_poster, item_imdb_rate, item_type, added_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    $stmt->execute([
        $userId,
        $itemLink,
        bm_security_limit_text($_POST['item_title'] ?? $_POST['title'] ?? '', 300),
        bm_security_limit_text($_POST['item_title_fa'] ?? $_POST['title_fa'] ?? $_POST['item_title'] ?? $_POST['title'] ?? '', 300),
        bm_security_safe_year($_POST['item_year'] ?? $_POST['year'] ?? ''),
        bm_security_safe_navigation_url($_POST['item_poster'] ?? $_POST['poster'] ?? '', true),
        bm_security_safe_rating($_POST['item_imdb_rate'] ?? $_POST['rate'] ?? null),
        bm_security_safe_media_type($_POST['item_type'] ?? $_POST['type'] ?? 'movie'),
    ]);

    bm_arc1_json(['success' => true, 'added' => true, 'id' => (int)$pdo->lastInsertId(), 'message' => 'added']);
} catch (PDOException $e) {
    error_log('Archive1 watchlist AJAX Error: ' . $e->getMessage());
    bm_arc1_json(['success' => false, 'error' => 'Database error']);
} catch (Throwable $e) {
    error_log('Archive1 watchlist AJAX Error: ' . $e->getMessage());
    bm_arc1_json(['success' => false, 'error' => 'Server error']);
}
