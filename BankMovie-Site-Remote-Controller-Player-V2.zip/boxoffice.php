<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/site_content_control.php';
require_once __DIR__ . '/includes/boxoffice.php';
require_once __DIR__ . '/includes/user_theme.php';

$currentUser = $currentUser ?? null;
$userLang = (($_COOKIE['user_lang'] ?? ($currentUser['language'] ?? 'fa')) === 'en') ? 'en' : 'fa';
$dir = $userLang === 'fa' ? 'rtl' : 'ltr';
$themeId = bm_theme_resolve(is_array($currentUser) ? $currentUser : null);
$theme = bm_theme_catalog()[$themeId] ?? bm_theme_catalog()['dark-green'];
$isAdmin = is_array($currentUser) && in_array(strtolower(trim((string)($currentUser['role'] ?? ''))), ['admin','administrator'], true);
$boxSettings = bm_boxoffice_settings($pdo, false);

function bm_bo_h($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
?>
<!doctype html>
<html lang="<?= bm_bo_h($userLang) ?>" dir="<?= bm_bo_h($dir) ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#07090f">
<title><?= $userLang === 'fa' ? 'باکس آفیس | BankMovie' : 'Box Office | BankMovie' ?></title>
<meta name="description" content="<?= $userLang === 'fa' ? 'جدول باکس آفیس و رتبه‌بندی پرفروش‌ترین فیلم‌های هفته در بانک مووی.' : 'Weekly box office rankings and top-grossing movies on BankMovie.' ?>">
<link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
<link rel="stylesheet" href="/assets/css/bm-global.css?v=148">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=148">
<?php require __DIR__ . '/partials/theme_head.php'; ?>
<?= function_exists('bm_site_typography_head_markup') ? bm_site_typography_head_markup() : '' ?>
<link rel="stylesheet" href="/assets/css/bm-boxoffice-v14861968.css?v=14861968">
<!-- V67: legacy BoxOffice/Actor floating-nav stylesheet removed -->
<style>:root{--bm-bo-accent:var(--accent,<?= bm_bo_h((string)$theme['primary']) ?>);--bm-bo-accent-rgb:var(--accent-rgb,<?= bm_bo_h((string)$theme['rgb']) ?>)}</style>
</head>
<body class="bm-boxoffice-page" data-theme="<?= bm_bo_h($themeId) ?>">
<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=14854" defer></script>

<main class="bm-bo-shell" id="bmBoxOffice" data-api="/api_boxoffice.php" data-admin="<?= $isAdmin ? '1' : '0' ?>">
  <section class="bm-bo-hero" aria-labelledby="bmBoTitle">
    <div class="bm-bo-hero-grid" aria-hidden="true"></div>
    <div class="bm-bo-hero-copy">
      <div class="bm-bo-kicker"><span></span>BOX OFFICE</div>
      <h1 id="bmBoTitle"><?= $userLang === 'fa' ? 'باکس آفیس' : 'Box Office' ?></h1>
      <p><?= $userLang === 'fa' ? 'پرفروش‌ترین فیلم‌های هفته، رتبه‌بندی گیشه، فروش آخر هفته و مجموع فروش؛ یک‌جا و مرتب.' : 'The week’s top-grossing films, weekend numbers and total gross in one clean chart.' ?></p>
      <div class="bm-bo-hero-stats">
        <div><small><?= $userLang === 'fa' ? 'صدرنشین هفته' : 'No. 1 this week' ?></small><strong id="bmBoHeroTitle">—</strong></div>
        <div><small><?= $userLang === 'fa' ? 'فروش آخر هفته' : 'Weekend gross' ?></small><strong id="bmBoHeroGross">—</strong></div>
      </div>
    </div>
    <div class="bm-bo-hero-visual">
      <div class="bm-bo-hero-glow"></div>
      <div class="bm-bo-hero-poster-wrap">
        <img id="bmBoHeroPoster" src="/uploads/no.png" alt="" decoding="async" draggable="false">
        <div class="bm-bo-hero-poster-shade"></div>
        <div class="bm-bo-hero-rank"><span>#</span><strong id="bmBoHeroRank">1</strong></div>
      </div>
    </div>
  </section>

  <section class="bm-bo-statusbar">
    <div class="bm-bo-status-item"><span class="bm-bo-status-icon">↻</span><div><small><?= $userLang === 'fa' ? 'آخرین بروزرسانی' : 'Last update' ?></small><strong id="bmBoUpdatedAt">—</strong></div></div>
    <div class="bm-bo-status-item"><span class="bm-bo-status-icon">▥</span><div><small><?= $userLang === 'fa' ? 'فیلم‌های جدول' : 'Chart entries' ?></small><strong id="bmBoCount">—</strong></div></div>
    <div class="bm-bo-status-item bm-bo-status-total"><span class="bm-bo-status-icon">$</span><div><small><?= $userLang === 'fa' ? 'جمع فروش آخر هفته' : 'Weekend total' ?></small><strong id="bmBoTotal">—</strong></div></div>
    <?php if ($isAdmin): ?><a class="bm-bo-admin-link" href="/admin_boxoffice.php"><?= $userLang === 'fa' ? 'مدیریت' : 'Manage' ?></a><?php endif; ?>
  </section>

  <section class="bm-bo-podium-section">
    <div class="bm-bo-section-head">
      <div><span class="bm-bo-section-eyebrow">TOP 3</span><h2><?= $userLang === 'fa' ? 'سه فیلم اول هفته' : 'Top three this week' ?></h2></div>
      <button type="button" class="bm-bo-refresh" id="bmBoRefresh"><span>↻</span><?= $userLang === 'fa' ? 'تازه‌سازی' : 'Refresh' ?></button>
    </div>
    <div class="bm-bo-podium" id="bmBoPodium">
      <div class="bm-bo-podium-skeleton"></div><div class="bm-bo-podium-skeleton"></div><div class="bm-bo-podium-skeleton"></div>
    </div>
  </section>

  <section class="bm-bo-chart-section">
    <div class="bm-bo-chart-head">
      <div><span class="bm-bo-section-eyebrow">WEEKEND CHART</span><h2><?= $userLang === 'fa' ? 'جدول باکس آفیس' : 'Box office chart' ?></h2></div>
      <div class="bm-bo-chart-legend"><span><?= $userLang === 'fa' ? 'آخر هفته' : 'Weekend' ?></span><span><?= $userLang === 'fa' ? 'فروش کل' : 'Total' ?></span><span><?= $userLang === 'fa' ? 'هفته اکران' : 'Weeks' ?></span></div>
    </div>
    <div class="bm-bo-alert" id="bmBoAlert" hidden></div>
    <div class="bm-bo-list" id="bmBoList" aria-live="polite">
      <?php for ($i=0;$i<6;$i++): ?><div class="bm-bo-row-skeleton"><i></i><b></b><span></span></div><?php endfor; ?>
    </div>
  </section>
</main>

<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>
<script>window.BM_BOXOFFICE_LANG=<?= json_encode($userLang, JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="/assets/js/bm-boxoffice-v14861968.js?v=14861968" defer></script>
</body>
</html>
