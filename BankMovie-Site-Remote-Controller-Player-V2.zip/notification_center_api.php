<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/notification_center.php';

@ini_set('display_errors', '0');
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: same-origin');

if (function_exists('bm_security_enforce_rate_limit')) {
    $uidForRate = (int)($currentUser['id'] ?? 0);
    bm_security_enforce_rate_limit('notification_center', 240, 300, bm_security_client_ip() . '|' . $uidForRate, true);
}

function bm_nc_json(array $payload, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$action = strtolower(trim((string)($_GET['action'] ?? $_POST['action'] ?? 'list')));
$userId = (int)($currentUser['id'] ?? 0);

if ($action === 'list') {
    if ($userId <= 0) {
        bm_nc_json([
            'success' => true,
            'logged_in' => false,
            'items' => bm_notification_center_public_list($pdo, 20),
            'unread' => 0,
        ]);
    }
    bm_notification_center_sync_user($pdo, $currentUser);
    bm_nc_json([
        'success' => true,
        'logged_in' => true,
        'items' => bm_notification_center_list($pdo, $userId, 40),
        'unread' => bm_notification_center_unread($pdo, $userId),
    ]);
}

if ($userId <= 0) bm_nc_json(['success'=>false,'message'=>'برای مدیریت اعلان‌ها وارد حساب شوید.'], 401);
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') bm_nc_json(['success'=>false,'message'=>'POST required'], 405);
bm_require_user_csrf(true, true);
bm_notification_center_ensure_schema($pdo);

try {
    if ($action === 'read') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) throw new RuntimeException('شناسه اعلان نامعتبر است.');
        $stmt = $pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()),is_read=1 WHERE id=? AND user_id=?');
        $stmt->execute([$id, $userId]);
    } elseif ($action === 'read_all') {
        $stmt = $pdo->prepare('UPDATE app_notifications SET read_at=COALESCE(read_at,NOW()),is_read=1 WHERE user_id=? AND read_at IS NULL');
        $stmt->execute([$userId]);
    } elseif ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) throw new RuntimeException('شناسه اعلان نامعتبر است.');
        $q = $pdo->prepare('SELECT dedupe_key FROM app_notifications WHERE id=? AND user_id=? LIMIT 1');
        $q->execute([$id, $userId]);
        $dedupe = trim((string)$q->fetchColumn());
        if ($dedupe !== '') {
            $d = $pdo->prepare('INSERT INTO app_notification_dismissals(user_id,dedupe_key,dismissed_at) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE dismissed_at=VALUES(dismissed_at)');
            $d->execute([$userId, $dedupe]);
        }
        $stmt = $pdo->prepare('DELETE FROM app_notifications WHERE id=? AND user_id=?');
        $stmt->execute([$id, $userId]);
    } elseif ($action === 'clear') {
        $rows = $pdo->prepare("SELECT dedupe_key FROM app_notifications WHERE user_id=? AND dedupe_key IS NOT NULL AND dedupe_key<>''");
        $rows->execute([$userId]);
        $dismiss = $pdo->prepare('INSERT INTO app_notification_dismissals(user_id,dedupe_key,dismissed_at) VALUES(?,?,NOW()) ON DUPLICATE KEY UPDATE dismissed_at=VALUES(dismissed_at)');
        foreach ($rows->fetchAll(PDO::FETCH_COLUMN) ?: [] as $dedupe) {
            $dedupe = trim((string)$dedupe);
            if ($dedupe !== '') $dismiss->execute([$userId, $dedupe]);
        }
        $stmt = $pdo->prepare('DELETE FROM app_notifications WHERE user_id=?');
        $stmt->execute([$userId]);
    } else {
        bm_nc_json(['success'=>false,'message'=>'اکشن نامعتبر است.'], 400);
    }
    bm_nc_json(['success'=>true,'unread'=>bm_notification_center_unread($pdo, $userId)]);
} catch (Throwable $e) {
    error_log('notification center api: ' . $e->getMessage());
    bm_nc_json(['success'=>false,'message'=>'عملیات اعلان انجام نشد.'], 500);
}
