<?php
// BankMovie dynamic XML sitemaps - v40 automatic live registration
// /sitemap.xml -> live sitemap index
// /sitemaps/recent.xml always contains the newest posts immediately (WordPress-style).
// /sitemaps/movies-1.xml, /sitemaps/series-1.xml, /sitemaps/static.xml, /sitemaps/catalog.xml, /sitemaps/collections.xml
require_once __DIR__ . '/includes/site_bootstrap.php';

@set_time_limit(20);

if (!headers_sent()) {
    header('Content-Type: application/xml; charset=UTF-8');
    // Keep sitemap fresh; CDN/browser cache can hide newly added child sitemaps.
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
    header('CDN-Cache-Control: no-store');
    header('Cloudflare-CDN-Cache-Control: no-store');
    header('Surrogate-Control: no-store');
    header('Pragma: no-cache');
    header('Expires: 0');
    header('X-BankMovie-Sitemap-Domain: bankmovie.top');
    header('X-BankMovie-Sitemap-Version: 40');
    header('X-BankMovie-Sitemap-Auto-Sync: live');
}

function bm_sm_base(): string {
    // Sitemap URLs are intentionally locked to the Search Console primary property.
    // Never derive this value from HTTP_HOST, addon-domain aliases, ENV, or the legacy domain.
    return (function_exists('bm_seo_base_url') ? bm_seo_base_url() : rtrim(SITE_URL, '/')) . '/';
}

function bm_sm_repair_physical_domains(): array {
    static $done = false;
    if ($done) return ['checked' => 0, 'changed' => 0];
    $done = true;

    $files = [
        __DIR__ . '/sitemap.xml',
        __DIR__ . '/sitemap-source.xml',
        __DIR__ . '/_bankmovie_private/sitemap_source.xml',
    ];
    foreach (glob(__DIR__ . '/sitemaps/*.xml') ?: [] as $file) $files[] = $file;

    $checked = 0;
    $changed = 0;
    foreach (array_unique($files) as $file) {
        if (!is_file($file) || filesize($file) < 20) continue;
        $checked++;
        $xml = @file_get_contents($file);
        if (!is_string($xml) || $xml === '') continue;
        $fixed = preg_replace(
            '~https?://(?:www\.)?(?:bankmoviee\.ir|bankmovie\.top)~i',
            rtrim(bm_sm_base(), '/'),
            $xml
        ) ?? $xml;
        if ($fixed !== $xml && is_writable($file)) {
            $tmp = $file . '.domain-fix-' . bin2hex(random_bytes(4));
            if (@file_put_contents($tmp, $fixed, LOCK_EX) !== false && @rename($tmp, $file)) {
                $changed++;
            } else {
                @unlink($tmp);
            }
        }
    }
    return ['checked' => $checked, 'changed' => $changed];
}
function bm_sm_xml($v): string {
    return htmlspecialchars((string)$v, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}
function bm_sm_rebase_local_url(string $url): string {
    $url = trim($url);
    if ($url === '') return '';

    $base = bm_sm_base();
    if (str_starts_with($url, '/')) return $base . ltrim($url, '/');

    $parts = @parse_url($url);
    if (!is_array($parts) || empty($parts['host'])) return $url;

    $host = strtolower((string)$parts['host']);
    $host = preg_replace('/^www\./i', '', $host) ?: $host;
    if (!in_array($host, ['bankmovie.top', 'bankmoviee.ir'], true)) return $url;

    $path = (string)($parts['path'] ?? '/');
    $query = isset($parts['query']) ? '?' . $parts['query'] : '';
    $fragment = isset($parts['fragment']) ? '#' . $parts['fragment'] : '';
    return $base . ltrim($path, '/') . $query . $fragment;
}
function bm_sm_physical_file(string $type, int $page): ?string {
    return match ($type) {
        'index' => __DIR__ . '/sitemap.xml',
        'static', 'catalog', 'collections', 'recent' => __DIR__ . '/sitemaps/' . $type . '.xml',
        'movies', 'series' => __DIR__ . '/sitemaps/' . $type . '-' . max(1, $page) . '.xml',
        default => null,
    };
}
function bm_sm_try_serve_physical(string $type, int $page): bool {
    $file = bm_sm_physical_file($type, $page);
    if ($file === null || !is_file($file) || filesize($file) < 40) return false;

    $xml = @file_get_contents($file);
    if (!is_string($xml) || stripos($xml, '<?xml') === false) return false;

    // فایل فیزیکی برای سرعت استفاده می‌شود، اما دامنه همیشه با Host فعلی هماهنگ می‌شود.
    $target = rtrim(bm_sm_base(), '/');
    $xml = preg_replace(
        '~https?://(?:www\.)?(?:bankmovie\.top|bankmoviee\.ir)~i',
        $target,
        $xml
    ) ?? $xml;

    if (!headers_sent()) header('X-BankMovie-Sitemap-Source: physical-primary-domain-locked');
    echo $xml;
    return true;
}
function bm_sm_date($v = null): string {
    $ts = $v ? strtotime((string)$v) : false;
    if (!$ts) $ts = time();
    // Full W3C timestamp, same behavior expected from modern CMS sitemaps.
    return gmdate('Y-m-d\TH:i:s\Z', $ts);
}
function bm_sm_table_exists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare('SHOW TABLES LIKE ?');
        $st->execute([$table]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return false; }
}
function bm_sm_col_exists(PDO $pdo, string $table, string $column): bool {
    try {
        $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $st->execute([$column]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return false; }
}
function bm_sm_url_item(string $loc, ?string $lastmod = null, string $changefreq = 'weekly', string $priority = '0.7', ?string $image = null): string {
    $x = "  <url>\n";
    $x .= '    <loc>' . bm_sm_xml($loc) . "</loc>\n";
    if ($lastmod) $x .= '    <lastmod>' . bm_sm_xml(bm_sm_date($lastmod)) . "</lastmod>\n";
    if ($changefreq !== '') $x .= '    <changefreq>' . bm_sm_xml($changefreq) . "</changefreq>\n";
    if ($priority !== '') $x .= '    <priority>' . bm_sm_xml($priority) . "</priority>\n";
    if ($image) {
        $x .= "    <image:image>\n";
        $x .= '      <image:loc>' . bm_sm_xml($image) . "</image:loc>\n";
        $x .= "    </image:image>\n";
    }
    $x .= "  </url>\n";
    return $x;
}
function bm_sm_urlset_start(bool $image = false): string {
    return '<?xml version="1.0" encoding="UTF-8"?>' . "\n" .
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"' . ($image ? ' xmlns:image="http://www.google.com/schemas/sitemap-image/1.1"' : '') . '>' . "\n";
}
function bm_sm_urlset_end(): string { return "</urlset>\n"; }
function bm_sm_is_series_sql(): string {
    // Robust detection for different values used by imports/admin tools: tvSeries, TV Series, series, serial, etc.
    return "(LOWER(COALESCE(type,'')) LIKE '%series%' OR LOWER(COALESCE(type,'')) LIKE '%mini%' OR LOWER(COALESCE(type,'')) IN ('tv','tvshow','tv show','show','serial','serie'))";
}
function bm_sm_count_movies(PDO $pdo, string $kind): int {
    if (!bm_sm_table_exists($pdo, 'movies')) return 0;
    $seriesWhere = bm_sm_is_series_sql();
    if ($kind === 'series') $where = $seriesWhere;
    elseif ($kind === 'movies') $where = "NOT $seriesWhere";
    else $where = '1=1';
    try { return (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE id > 0 AND $where")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}
function bm_sm_count_all_movies(PDO $pdo): int {
    if (!bm_sm_table_exists($pdo, 'movies')) return 0;
    try { return (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE id > 0")->fetchColumn(); }
    catch (Throwable $e) { return 0; }
}
function bm_sm_has_page(PDO $pdo, string $kind, int $page, int $per): bool {
    if (!bm_sm_table_exists($pdo, 'movies') || $page < 1) return false;
    $seriesWhere = bm_sm_is_series_sql();
    $where = ($kind === 'series') ? $seriesWhere : "NOT $seriesWhere";
    $offset = ($page - 1) * $per;
    try {
        $st = $pdo->query("SELECT id FROM movies WHERE id > 0 AND $where ORDER BY id DESC LIMIT 1 OFFSET $offset");
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) { return false; }
}
function bm_sm_page_count(PDO $pdo, string $kind, int $per): int {
    $count = bm_sm_count_movies($pdo, $kind);
    $pages = (int)ceil(max(0, $count) / max(1, $per));
    // Safety probe: if COUNT is affected by import quirks/caching, verify next pages by OFFSET.
    // This prevents sitemap.xml from listing only movies-1 while movies-2.xml actually has URLs.
    $probeLimit = max(3, min(80, $pages + 8));
    for ($i = 1; $i <= $probeLimit; $i++) {
        if (bm_sm_has_page($pdo, $kind, $i, $per)) $pages = max($pages, $i);
        elseif ($i > $pages + 2) break;
    }
    return $pages;
}

function bm_sm_legacy_source_path(): string {
    $sources = [
        __DIR__ . '/_bankmovie_private/sitemap_source.xml',
        __DIR__ . '/sitemap-source.xml',
        __DIR__ . '/sitemap.xml',
    ];
    foreach ($sources as $file) {
        if (is_file($file) && filesize($file) >= 100) return $file;
    }
    return __DIR__ . '/sitemap.xml';
}
function bm_sm_legacy_movie_entries(): array {
    static $entries = null;
    if (is_array($entries)) return $entries;
    $entries = [];
    $file = bm_sm_legacy_source_path();
    if (!is_file($file) || filesize($file) < 100) return $entries;
    $xml = @file_get_contents($file);
    if (!is_string($xml) || $xml === '') return $entries;
    if (!preg_match_all('~<url\b[^>]*>(.*?)</url>~is', $xml, $blocks)) return $entries;
    foreach ($blocks[1] as $block) {
        if (!preg_match('~<loc>(.*?)</loc>~is', $block, $m)) continue;
        $loc = html_entity_decode(trim(strip_tags($m[1])), ENT_QUOTES | ENT_XML1, 'UTF-8');
        $loc = bm_sm_rebase_local_url($loc);
        if ($loc === '' || strpos($loc, '/movie/') === false) continue;
        $lastmod = null; $image = null;
        if (preg_match('~<lastmod>(.*?)</lastmod>~is', $block, $lm)) $lastmod = trim(strip_tags($lm[1]));
        if (preg_match('~<image:loc>(.*?)</image:loc>~is', $block, $im)) {
            $image = html_entity_decode(trim(strip_tags($im[1])), ENT_QUOTES | ENT_XML1, 'UTF-8');
            $image = bm_sm_rebase_local_url($image);
        }
        $entries[] = ['loc' => $loc, 'lastmod' => $lastmod, 'image' => $image];
    }
    return $entries;
}
function bm_sm_legacy_movie_count(): int { return count(bm_sm_legacy_movie_entries()); }
function bm_sm_legacy_movie_pages(int $per): int { return (int)ceil(max(0, bm_sm_legacy_movie_count()) / max(1, $per)); }
function bm_sm_legacy_movie_page_entries(int $page, int $per): array {
    $offset = max(0, ($page - 1) * $per);
    return array_slice(bm_sm_legacy_movie_entries(), $offset, $per);
}

function bm_sm_lastmod_movies(PDO $pdo, string $kind): string {
    $seriesWhere = bm_sm_is_series_sql();
    if ($kind === 'series') $where = $seriesWhere;
    elseif ($kind === 'movies') $where = "NOT $seriesWhere";
    else $where = '1=1';
    try {
        $col = bm_sm_col_exists($pdo, 'movies', 'updated_at') ? 'updated_at' : (bm_sm_col_exists($pdo, 'movies', 'created_at') ? 'created_at' : 'NULL');
        if ($col === 'NULL') return bm_sm_date();
        $v = $pdo->query("SELECT MAX($col) FROM movies WHERE id > 0 AND $where")->fetchColumn();
        return bm_sm_date($v ?: null);
    } catch (Throwable $e) { return bm_sm_date(); }
}

bm_sm_repair_physical_domains();

$type = strtolower(trim((string)($_GET['type'] ?? 'index')));
$page = max(1, (int)($_GET['page'] ?? 1));
$per = 2000;
// v35: DB count may return 0 on host. Use the old physical sitemap.xml as a reliable fallback source.
$bmMinMovieSitemapPages = 0;
$bmMinSeriesSitemapPages = 0;
$base = bm_sm_base();

// Automatic mode behaves like WordPress: every request is generated from current database rows.
// Physical XML is used only when the administrator explicitly disables automatic live registration.
$bmAutoSync = !function_exists('bm_site_bool') || bm_site_bool('seo_sitemap_auto_sync_enabled', true);
if ($type !== 'debug' && !$bmAutoSync && function_exists('bm_site_bool') && !bm_site_bool('seo_dynamic_sitemap_enabled', true) && bm_sm_try_serve_physical($type, $page)) exit;

// Database is loaded only when a physical sitemap file is unavailable.
require_once __DIR__ . '/config.php';

try {
    if ($type === 'debug') {
        if (!headers_sent()) header('Content-Type: text/plain; charset=UTF-8');
        $movies = bm_sm_count_movies($pdo, 'movies');
        $series = bm_sm_count_movies($pdo, 'series');
        $allItems = bm_sm_count_all_movies($pdo);
        echo "BankMovie sitemap debug v40\n";
        echo "auto_sync=" . ($bmAutoSync ? "on" : "off") . "\n";
        echo "db_movies_count=" . $movies . "\n";
        echo "db_series_count=" . $series . "\n";
        echo "db_all_items=" . $allItems . "\n";
        echo "legacy_movie_urls=" . bm_sm_legacy_movie_count() . "\n";
        echo "legacy_movie_pages=" . bm_sm_legacy_movie_pages($per) . "\n";
        echo "final_movie_pages=" . max(1, bm_sm_page_count($pdo, 'movies', $per), (int)ceil(max(0,$allItems)/$per), bm_sm_legacy_movie_pages($per)) . "\n";
        echo "final_series_pages=" . max(0, bm_sm_page_count($pdo, 'series', $per)) . "\n";
        exit;
    }

    if ($type === 'index') {
        $movies = bm_sm_count_movies($pdo, 'movies');
        $series = bm_sm_count_movies($pdo, 'series');
        $allItems = bm_sm_count_all_movies($pdo);
        $moviePages = bm_sm_page_count($pdo, 'movies', $per);
        $seriesPages = bm_sm_page_count($pdo, 'series', $per);
        // DB COUNT is returning 0 on some hosts. Use the old physical sitemap.xml as fallback,
        // so sitemap index lists only the movie pages that are actually present there.
        $legacyMoviePages = bm_sm_legacy_movie_pages($per);
        $allPages = (int)ceil(max(0, $allItems) / $per);
        $moviePages = max(1, $moviePages, $allPages, $legacyMoviePages);
        // Do not invent series pages when DB cannot prove they exist; series URLs are often inside /movie/ URLs.
        $seriesPages = max(0, $seriesPages);
        $now = bm_sm_date();
        echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
        echo '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
        echo '  <!-- BankMovie sitemap v40; autoSync=' . ($bmAutoSync ? 'on' : 'off') . '; db_movies=' . (int)$movies . '; db_series=' . (int)$series . '; db_all=' . (int)$allItems . '; legacyMovieUrls=' . bm_sm_legacy_movie_count() . '; moviePages=' . (int)$moviePages . '; seriesPages=' . (int)$seriesPages . ' -->' . "\n";
        $entries = [
            [$base . 'sitemaps/recent.xml', bm_sm_lastmod_movies($pdo, 'all')],
            [$base . 'sitemaps/static.xml', $now],
            [$base . 'sitemaps/catalog.xml', $now],
            [$base . 'sitemaps/collections.xml', $now],
        ];
        foreach ($entries as $e) {
            echo "  <sitemap><loc>" . bm_sm_xml($e[0]) . "</loc><lastmod>" . bm_sm_xml($e[1]) . "</lastmod></sitemap>\n";
        }
        $movieLast = bm_sm_lastmod_movies($pdo, 'movies');
        for ($i = 1; $i <= $moviePages; $i++) {
            echo "  <sitemap><loc>" . bm_sm_xml($base . 'sitemaps/movies-' . $i . '.xml') . "</loc><lastmod>" . bm_sm_xml($movieLast) . "</lastmod></sitemap>\n";
        }
        $seriesLast = bm_sm_lastmod_movies($pdo, 'series');
        for ($i = 1; $i <= $seriesPages; $i++) {
            echo "  <sitemap><loc>" . bm_sm_xml($base . 'sitemaps/series-' . $i . '.xml') . "</loc><lastmod>" . bm_sm_xml($seriesLast) . "</lastmod></sitemap>\n";
        }
        echo "</sitemapindex>\n";
        exit;
    }

    if ($type === 'static') {
        echo bm_sm_urlset_start(false);
        echo bm_sm_url_item($base, null, 'daily', '1.0');
        echo bm_sm_url_item($base . 'categories', null, 'weekly', '0.85');
        echo bm_sm_url_item($base . 'genres', null, 'weekly', '0.82');
        echo bm_sm_url_item($base . 'collections', null, 'weekly', '0.8');
        echo bm_sm_url_item($base . 'boxoffice', null, 'daily', '0.78');
        echo bm_sm_url_item($base . 'application', null, 'monthly', '0.55');
        echo bm_sm_url_item($base . 'catalog?type=movie', null, 'daily', '0.8');
        echo bm_sm_url_item($base . 'catalog?type=series', null, 'daily', '0.8');
        echo bm_sm_url_item($base . 'top_rated_by_users', null, 'weekly', '0.6');
        echo bm_sm_url_item($base . 'map', null, 'weekly', '0.6');
        echo bm_sm_urlset_end();
        exit;
    }

    if ($type === 'catalog') {
        $moviePages = max(1, (int)ceil(bm_sm_count_movies($pdo, 'movies') / 48));
        $seriesPages = max(1, (int)ceil(bm_sm_count_movies($pdo, 'series') / 48));
        echo bm_sm_urlset_start(false);
        for ($i = 1; $i <= $moviePages; $i++) echo bm_sm_url_item($base . 'catalog?type=movie' . ($i > 1 ? '&page=' . $i : ''), null, 'daily', $i === 1 ? '0.8' : '0.55');
        for ($i = 1; $i <= $seriesPages; $i++) echo bm_sm_url_item($base . 'catalog?type=series' . ($i > 1 ? '&page=' . $i : ''), null, 'daily', $i === 1 ? '0.8' : '0.55');
        echo bm_sm_urlset_end();
        exit;
    }

    if ($type === 'recent') {
        // Latest 1000 posts are always queried live, so a newly published movie/series
        // appears immediately without rebuilding files or running cron.
        echo bm_sm_urlset_start(true);
        $printed = 0;
        if (bm_sm_table_exists($pdo, 'movies')) {
            $dateCol = bm_sm_col_exists($pdo, 'movies', 'updated_at') ? 'updated_at' : (bm_sm_col_exists($pdo, 'movies', 'created_at') ? 'created_at' : 'NULL AS updated_at');
            $orderCol = $dateCol === 'NULL AS updated_at' ? 'id' : 'updated_at';
            $sql = "SELECT id, imdb_code, title, title_fa, type, $dateCol FROM movies WHERE id > 0 ORDER BY $orderCol DESC, id DESC LIMIT 1000";
            try {
                $st = $pdo->query($sql);
                while ($movie = $st->fetch(PDO::FETCH_ASSOC)) {
                    $url = $base . ltrim(bm_movie_url($movie), '/');
                    $img = null;
                    $imdb = trim((string)($movie['imdb_code'] ?? ''));
                    if ($imdb !== '') {
                        $posterPath = __DIR__ . '/posters/' . basename($imdb) . '.webp';
                        if (is_file($posterPath)) $img = $base . 'posters/' . rawurlencode($imdb) . '.webp';
                    }
                    $isSeries = preg_match('/series|mini|tv|show|serial|serie/i', (string)($movie['type'] ?? '')) === 1;
                    echo bm_sm_url_item($url, $movie['updated_at'] ?? null, 'daily', $isSeries ? '0.82' : '0.87', $img);
                    $printed++;
                }
            } catch (Throwable $e) {
                error_log('Recent sitemap error: ' . $e->getMessage());
            }
        }
        echo "  <!-- BankMovie recent sitemap v40; live=1; urls=" . (int)$printed . " -->
";
        echo bm_sm_urlset_end();
        exit;
    }

    if ($type === 'collections') {
        echo bm_sm_urlset_start(false);
        if (bm_sm_table_exists($pdo, 'collections')) {
            $statusSql = bm_sm_col_exists($pdo, 'collections', 'status') ? "WHERE status IN ('active','published','public','1',1)" : '';
            $dateCol = bm_sm_col_exists($pdo, 'collections', 'updated_at') ? 'updated_at' : (bm_sm_col_exists($pdo, 'collections', 'created_at') ? 'created_at' : 'NULL AS updated_at');
            $st = $pdo->query("SELECT id, slug, $dateCol FROM collections $statusSql ORDER BY id DESC LIMIT 10000");
            while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
                $slug = trim((string)($row['slug'] ?? ''));
                if ($slug === '') continue;
                echo bm_sm_url_item($base . 'collection/' . rawurlencode($slug), $row['updated_at'] ?? null, 'weekly', '0.65');
            }
        }
        echo bm_sm_urlset_end();
        exit;
    }

    if ($type === 'movies' || $type === 'series') {
        $seriesWhere = bm_sm_is_series_sql();
        $where = ($type === 'series') ? $seriesWhere : "NOT $seriesWhere";
        $offset = ($page - 1) * $per;
        $dateCol = bm_sm_col_exists($pdo, 'movies', 'updated_at') ? 'updated_at' : (bm_sm_col_exists($pdo, 'movies', 'created_at') ? 'created_at' : 'NULL AS updated_at');
        $sql = "SELECT id, imdb_code, title, title_fa, type, $dateCol FROM movies WHERE id > 0 AND $where ORDER BY id DESC LIMIT $per OFFSET $offset";
        $st = null;
        try { $st = $pdo->query($sql); } catch (Throwable $e) { $st = null; }
        echo bm_sm_urlset_start(true);
        $printed = 0;
        if ($st) {
            while ($movie = $st->fetch(PDO::FETCH_ASSOC)) {
                $url = $base . ltrim(bm_movie_url($movie), '/');
                $img = null;
                $imdb = trim((string)($movie['imdb_code'] ?? ''));
                if ($imdb !== '') {
                    $posterPath = __DIR__ . '/posters/' . basename($imdb) . '.webp';
                    if (is_file($posterPath)) $img = $base . 'posters/' . rawurlencode($imdb) . '.webp';
                }
                echo bm_sm_url_item($url, $movie['updated_at'] ?? null, 'weekly', $type === 'series' ? '0.8' : '0.85', $img);
                $printed++;
            }
        }
        // Fallback only for movie sitemap: old full sitemap.xml has all /movie/ URLs and avoids empty child sitemaps.
        if ($printed === 0 && $type === 'movies') {
            foreach (bm_sm_legacy_movie_page_entries($page, $per) as $entry) {
                echo bm_sm_url_item($entry['loc'], $entry['lastmod'] ?? null, 'weekly', '0.85', $entry['image'] ?? null);
                $printed++;
            }
        }
        echo "  <!-- BankMovie sitemap v40 child type=" . bm_sm_xml($type) . "; page=" . (int)$page . "; urls=" . (int)$printed . " -->
";
        echo bm_sm_urlset_end();
        exit;
    }

    http_response_code(404);
    echo '<?xml version="1.0" encoding="UTF-8"?><error>Unknown sitemap type</error>';
} catch (Throwable $e) {
    http_response_code(500);
    error_log('Sitemap error: ' . $e->getMessage());
    echo '<?xml version="1.0" encoding="UTF-8"?><error>Sitemap generation failed</error>';
}
