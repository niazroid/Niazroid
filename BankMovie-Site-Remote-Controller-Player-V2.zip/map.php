<?php
@include_once __DIR__ . '/includes/_bm_support_widget.php';
require_once __DIR__ . '/config.php';

function bm_map_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
$isSeriesSql = "(type LIKE '%Series%' OR type IN ('tvSeries','tvMiniSeries','series','TV Series','tv') OR type LIKE '%MiniSeries%')";
$movieCount = $seriesCount = 0;
$recent = [];
try {
    $movieCount = (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE id > 0 AND NOT $isSeriesSql")->fetchColumn();
    $seriesCount = (int)$pdo->query("SELECT COUNT(*) FROM movies WHERE id > 0 AND $isSeriesSql")->fetchColumn();
    $st = $pdo->query("SELECT id, title, title_fa, year, type, imdb_code FROM movies WHERE id > 0 ORDER BY id DESC LIMIT 80");
    $recent = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) { error_log('map.php SEO map error: ' . $e->getMessage()); }
$moviePages = max(1, (int)ceil($movieCount / 48));
$seriesPages = max(1, (int)ceil($seriesCount / 48));
$userLang = $_COOKIE['user_lang'] ?? 'fa';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta name="theme-color" content="#05050a">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>نقشه سایت بانک مووی | فیلم‌ها، سریال‌ها و کالکشن‌ها</title>
    <meta name="description" content="نقشه سایت بانک مووی برای دسترسی سریع و قابل پیمایش به آرشیو فیلم‌ها، سریال‌ها، کالکشن‌ها و صفحات مهم.">
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1">
    <link rel="canonical" href="<?= bm_map_h(rtrim(SITE_URL, '/') . '/map') ?>">
    <style>
        :root{--bg:#07080d;--card:#10131c;--line:rgba(255,255,255,.09);--txt:#fff;--muted:#a9b0c2;--accent:#2f7cff}*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at top,#12182a 0,#07080d 48%,#05060a 100%);color:#fff;font-family:system-ui,-apple-system,Segoe UI,Roboto,Tahoma,sans-serif;padding:24px 14px 120px}.wrap{max-width:1120px;margin:0 auto}.top{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:18px}.brand{display:flex;align-items:center;gap:10px;text-decoration:none;color:#fff;font-weight:900}.brand img{height:50px}.nav{display:flex;gap:8px;flex-wrap:wrap}.nav a,.btn{color:#fff;text-decoration:none;border:1px solid var(--line);background:rgba(255,255,255,.04);padding:10px 13px;border-radius:14px;font-size:13px;font-weight:800}.hero{border:1px solid var(--line);background:linear-gradient(135deg,rgba(47,124,255,.16),rgba(255,255,255,.03));border-radius:24px;padding:20px;margin-bottom:18px}.hero h1{margin:0 0 8px;font-size:26px}.hero p{margin:0;color:var(--muted);line-height:1.8}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:18px}.box{border:1px solid var(--line);background:rgba(16,19,28,.86);border-radius:22px;padding:16px}.box h2{font-size:18px;margin:0 0 8px}.num{font-size:28px;font-weight:950;color:#dce9ff;margin:4px 0}.box p{color:var(--muted);font-size:13px;line-height:1.8;margin:0 0 12px}.links{display:flex;flex-wrap:wrap;gap:8px}.links a{color:#dce9ff;text-decoration:none;background:rgba(47,124,255,.11);border:1px solid rgba(47,124,255,.22);border-radius:12px;padding:8px 10px;font-size:12px;font-weight:850}.section{margin-top:18px}.section h2{font-size:19px;margin:0 0 12px}.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}.item{display:block;text-decoration:none;color:#fff;border:1px solid var(--line);background:rgba(255,255,255,.035);border-radius:15px;padding:11px}.item strong{display:block;font-size:13px;line-height:1.6}.item span{display:block;color:var(--muted);font-size:12px;direction:ltr;text-align:left;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:4px}@media(max-width:560px){body{padding-left:10px;padding-right:10px}.top{align-items:flex-start}.brand img{height:40px}.hero h1{font-size:21px}.grid{grid-template-columns:1fr}.nav a,.btn{font-size:12px;padding:9px 10px}}
    </style>
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
</head>
<body>
<div class="wrap">
    <div class="top">
        <a href="/" class="brand"><img src="/assets/brand/bankmovie-logo.webp?v=perf32" alt="BankMovie"><span>BankMovie</span></a>
        <div class="nav"><a href="/">خانه</a><a href="/collections">کالکشن‌ها</a><a href="/catalog?type=movie&page=1">فیلم‌ها</a><a href="/catalog?type=series&page=1">سریال‌ها</a></div>
    </div>
    <section class="hero">
        <h1>نقشه سایت بانک مووی</h1>
        <p>این صفحه برای کاربران و موتورهای جستجو ساخته شده تا آرشیو فیلم‌ها، سریال‌ها و کالکشن‌ها از مسیر لینک‌های واقعی و قابل Crawl پیدا شوند.</p>
    </section>
    <div class="cards">
        <div class="box"><h2>فیلم‌ها</h2><div class="num"><?= number_format($movieCount) ?></div><p>آرشیو فیلم‌ها به صورت صفحه‌بندی‌شده و سبک.</p><a class="btn" href="/catalog?type=movie&page=1">مشاهده فیلم‌ها</a></div>
        <div class="box"><h2>سریال‌ها</h2><div class="num"><?= number_format($seriesCount) ?></div><p>آرشیو سریال‌ها با لینک مستقیم به صفحه هر عنوان.</p><a class="btn" href="/catalog?type=series&page=1">مشاهده سریال‌ها</a></div>
        <div class="box"><h2>کالکشن‌ها</h2><div class="num">Collection</div><p>مجموعه فیلم‌ها و سریال‌های مرتبط.</p><a class="btn" href="/collections">مشاهده کالکشن‌ها</a></div>
    </div>
    <section class="section box">
        <h2>صفحه‌های آرشیو فیلم</h2>
        <div class="links">
            <?php for($i=1;$i<=min($moviePages,60);$i++): ?><a href="/catalog?type=movie&page=<?= $i ?>">فیلم صفحه <?= $i ?></a><?php endfor; ?>
            <?php if($moviePages>60): ?><a href="/catalog?type=movie&page=<?= $moviePages ?>">آخرین صفحه فیلم</a><?php endif; ?>
        </div>
    </section>
    <section class="section box">
        <h2>صفحه‌های آرشیو سریال</h2>
        <div class="links">
            <?php for($i=1;$i<=min($seriesPages,60);$i++): ?><a href="/catalog?type=series&page=<?= $i ?>">سریال صفحه <?= $i ?></a><?php endfor; ?>
            <?php if($seriesPages>60): ?><a href="/catalog?type=series&page=<?= $seriesPages ?>">آخرین صفحه سریال</a><?php endif; ?>
        </div>
    </section>
    <section class="section">
        <h2>تازه‌ترین عنوان‌ها</h2>
        <div class="grid">
            <?php foreach($recent as $m): $nameFa = trim((string)($m['title_fa'] ?? '')) ?: ($m['title'] ?? ''); ?>
                <a class="item" href="<?= bm_map_h(bm_movie_url($m)) ?>"><strong><?= bm_map_h($nameFa) ?></strong><span><?= bm_map_h(($m['title'] ?? '') . ' ' . ($m['year'] ?? '')) ?></span></a>
            <?php endforeach; ?>
        </div>
    </section>
</div>
<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('map.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<script src="/assets/js/pwa.js?v=95" defer></script>
</body>
</html>
