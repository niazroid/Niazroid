<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/site_content_control.php';
bm_site_enforce_page('page_categories_enabled');
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
$userLang = (($_COOKIE['user_lang'] ?? 'fa') === 'en') ? 'en' : 'fa';
$currentUser = null;
try {
    if (!empty($_COOKIE['session_token']) && class_exists('User')) {
        $userObj = new User($pdo);
        $currentUser = $userObj->checkSession((string)$_COOKIE['session_token']) ?: null;
    } elseif (!empty($_SESSION['user_id'])) {
        $st = $pdo->prepare('SELECT id,username,role FROM users WHERE id=? LIMIT 1');
        $st->execute([(int)$_SESSION['user_id']]);
        $currentUser = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    }
} catch (Throwable $e) { $currentUser = null; }
$t = [
 'fa'=>['home'=>'خانه','notifications'=>'اعلان‌ها','account'=>'حساب کاربری','login'=>'ورود','register'=>'ثبت نام','logout'=>'خروج','admin_panel'=>'پنل مدیریت'],
 'en'=>['home'=>'Home','notifications'=>'Notifications','account'=>'Account','login'=>'Login','register'=>'Register','logout'=>'Logout','admin_panel'=>'Admin Panel'],
];
$notificationsList=[];$latestNotification=null;
function bm_categories_h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
$pageTitle=trim((string)bm_site_get('categories_title_fa','دسته‌بندی')) ?: 'دسته‌بندی';
$pageDescription=trim((string)bm_site_get('categories_description_fa','فیلم‌ها و سریال‌ها را بر اساس ژانر، مجموعه‌های دنباله‌دار و فهرست برترین آثار پیدا کن؛ سریع‌تر به محتوایی برس که با سلیقه و حال‌وهوایت هماهنگ است.'));
?>
<!doctype html>
<html lang="<?=bm_categories_h($userLang)?>" dir="<?=$userLang==='fa'?'rtl':'ltr'?>">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#05050a">
<title><?=bm_categories_h($pageTitle)?> | <?=bm_categories_h((string)bm_site_get('site_name_fa','بانک مووی'))?></title>
<link rel="stylesheet" href="/assets/css/bm-global.css?v=148"><link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=148">
<?=bm_site_typography_head_markup()?>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;background:radial-gradient(circle at 50% -20%,rgba(124,58,237,.22),transparent 35%),#030409;color:#fff}.bm-category-page{width:min(1320px,calc(100% - 30px));margin:105px auto 0;padding-bottom:110px}.bm-category-intro{text-align:center;margin:0 auto 25px;max-width:770px}.bm-category-kicker{display:inline-flex;align-items:center;gap:8px;color:#b58cff;font-size:11px;font-weight:950;letter-spacing:.14em}.bm-category-kicker:before,.bm-category-kicker:after{content:"";width:34px;height:1px;background:linear-gradient(90deg,transparent,#a855f7)}.bm-category-kicker:after{transform:scaleX(-1)}.bm-category-intro h1{font-size:clamp(31px,5vw,54px);margin:10px 0 8px;font-weight:950}.bm-category-intro p{margin:0;color:rgba(255,255,255,.6);font-size:13px;line-height:2}.bm-category-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.bm-category-card{position:relative;min-height:390px;overflow:hidden;border-radius:30px;border:1px solid rgba(181,140,255,.28);background:#090912;box-shadow:0 28px 80px rgba(0,0,0,.4),inset 0 1px 0 rgba(255,255,255,.06);isolation:isolate;text-decoration:none;color:#fff;transition:transform .35s ease,border-color .35s ease,box-shadow .35s ease}.bm-category-card:before{content:"";position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,rgba(1,2,8,.04) 15%,rgba(2,3,10,.25) 55%,rgba(2,3,10,.96) 100%)}.bm-category-card:after{content:"";position:absolute;inset:-2px;z-index:3;border-radius:inherit;pointer-events:none;background:linear-gradient(110deg,transparent 25%,rgba(255,255,255,.16),transparent 75%);transform:translateX(-110%);transition:transform .8s ease}.bm-category-card:hover{transform:translateY(-7px);border-color:rgba(181,140,255,.62);box-shadow:0 36px 96px rgba(0,0,0,.5),0 0 42px rgba(124,58,237,.18)}.bm-category-card:hover:after{transform:translateX(110%)}.bm-category-card img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;transition:transform .7s ease,filter .7s ease}.bm-category-card:hover img{transform:scale(1.045);filter:saturate(1.08)}.bm-category-card-content{position:absolute;z-index:2;right:22px;left:22px;bottom:20px;display:flex;align-items:flex-end;justify-content:space-between;gap:14px}.bm-category-card-copy{min-width:0}.bm-category-card-copy small{display:inline-flex;padding:6px 10px;margin-bottom:8px;border-radius:999px;background:rgba(6,7,16,.58);border:1px solid rgba(255,255,255,.13);backdrop-filter:blur(15px);color:#d8c7ff;font-size:10px;font-weight:900}.bm-category-card-copy h2{font-size:24px;margin:0 0 6px;font-weight:950}.bm-category-card-copy p{margin:0;max-width:430px;color:rgba(255,255,255,.67);font-size:11px;line-height:1.8}.bm-category-go{flex:0 0 auto;width:48px;height:48px;border-radius:17px;display:grid;place-items:center;background:linear-gradient(135deg,#7c3aed,#b86cff);box-shadow:0 14px 30px rgba(124,58,237,.38);transition:transform .3s ease}.bm-category-card:hover .bm-category-go{transform:translateX(-5px) rotate(-4deg)}.bm-category-go svg{width:22px;height:22px}.bm-category-meta{position:absolute;z-index:2;top:16px;right:16px;padding:7px 11px;border-radius:999px;background:rgba(3,4,12,.58);border:1px solid rgba(255,255,255,.12);backdrop-filter:blur(14px);font-size:10px;font-weight:900}.bm-category-meta i{display:inline-block;width:7px;height:7px;margin-left:6px;border-radius:50%;background:#a855f7;box-shadow:0 0 13px #a855f7}
@media(max-width:820px){.bm-category-page{margin-top:76px;width:calc(100% - 20px)}.bm-category-grid{grid-template-columns:1fr}.bm-category-card{min-height:280px;border-radius:22px}.bm-category-intro h1{font-size:30px}.bm-category-card-content{right:14px;left:14px;bottom:13px}.bm-category-card-copy h2{font-size:18px}.bm-category-card-copy p{font-size:10px}.bm-category-go{width:42px;height:42px;border-radius:14px}}
</style>

<style id="bm-v56-mobile-nav-safe-space">
@media (max-width:991px){
  body{padding-bottom:max(92px,calc(78px + env(safe-area-inset-bottom,0px)))!important}
}
</style>

</head><body>
<?php require __DIR__.'/partials/shared_header.php'; ?><script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>
<main class="bm-category-page">
<section class="bm-category-intro"><span class="bm-category-kicker">CATEGORIES</span><h1><?=bm_categories_h($pageTitle)?></h1><?php if($pageDescription!==''):?><p><?=bm_categories_h($pageDescription)?></p><?php endif;?></section>
<section class="bm-category-grid" aria-label="انتخاب دسته‌بندی">
<a class="bm-category-card" href="/genres"><img src="/assets/categories/genres-cover.webp?v=147" alt="ژانرهای فیلم و سریال" fetchpriority="high" decoding="async"><span class="bm-category-meta"><i></i> کشف بر اساس موضوع</span><span class="bm-category-card-content"><span class="bm-category-card-copy"><small>GENRES</small><h2>ژانرها</h2><p>اکشن، عاشقانه، ترسناک، علمی‌تخیلی و همه ژانرهای واقعی آرشیوها.</p></span><span class="bm-category-go"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5m6-6-6 6 6 6"/></svg></span></span></a>
<a class="bm-category-card" href="/collections"><img src="/assets/categories/collections-cover.webp?v=147" alt="کالکشن فیلم‌های دنباله‌دار" loading="eager" decoding="async"><span class="bm-category-meta"><i></i> مجموعه‌های دنباله‌دار</span><span class="bm-category-card-content"><span class="bm-category-card-copy"><small>COLLECTIONS</small><h2>کالکشن‌ها</h2><p>تمام قسمت‌های هر فرنچایز و مجموعه فیلم، مرتب و یکجا.</p></span><span class="bm-category-go"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5m6-6-6 6 6 6"/></svg></span></span></a>
<a class="bm-category-card" href="/view_all?type=arc1_category&amp;cat=top-movies"><img src="/assets/categories/top-250-movies.webp?v=150" alt="۲۵۰ فیلم برتر" loading="lazy" decoding="async"><span class="bm-category-meta"><i></i> رتبه‌بندی آرشیو ۲</span><span class="bm-category-card-content"><span class="bm-category-card-copy"><small>TOP 250 MOVIES</small><h2>برترین فیلم‌ها</h2><p>فهرست ۲۵۰ فیلم برتر آرشیو ۲، مرتب‌شده برای دسترسی سریع.</p></span><span class="bm-category-go"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5m6-6-6 6 6 6"/></svg></span></span></a>
<a class="bm-category-card" href="/view_all?type=arc1_category&amp;cat=top-series"><img src="/assets/categories/top-250-series.webp?v=150" alt="۲۵۰ سریال برتر" loading="lazy" decoding="async"><span class="bm-category-meta"><i></i> رتبه‌بندی آرشیو ۲</span><span class="bm-category-card-content"><span class="bm-category-card-copy"><small>TOP 250 SERIES</small><h2>برترین سریال‌ها</h2><p>فهرست ۲۵۰ سریال برتر آرشیو ۲ با صفحه‌بندی واقعی منبع.</p></span><span class="bm-category-go"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M19 12H5m6-6-6 6 6 6"/></svg></span></span></a>
</section></main>
<?php require_once __DIR__.'/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>
</body></html>
