<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/watch_party.php';
require_once __DIR__ . '/includes/watch_party_voice.php';
require_once __DIR__ . '/includes/sticker_packs.php';

if (!headers_sent()) {
    header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0, private');
    header('Pragma: no-cache');
    header('X-Robots-Tag: noindex, nofollow, noarchive', true);
    header('Referrer-Policy: same-origin');
}

$bmWpSchemaReady = bm_watch_party_schema($pdo);
if ($bmWpSchemaReady) {
    // Strict purge on every Watch Party request; the active countdown performs another final poll at expiry.
    bm_watch_party_cleanup_expired($pdo, 500);
}

$roomFromUrl = bm_watch_party_normalize_code((string)($_GET['room'] ?? ''));
$inviteRoom = ($bmWpSchemaReady && $roomFromUrl !== '') ? bm_watch_party_find_room($pdo, $roomFromUrl) : null;
$hasInviteAccess = bm_watch_party_invite_access_allowed($inviteRoom);
$registeredUser = bm_watch_party_current_user($pdo);
$isAnonymousCompanion = false;

if (!$registeredUser) {
    if (!$hasInviteAccess) {
        $bmWpReturn = (string)($_SERVER['REQUEST_URI'] ?? '/watch-party');
        $_SESSION['redirect_after_login'] = $bmWpReturn;
        bm_vip_render_gate_screen('watch_party', null, $bmWpReturn);
    }
    $user = bm_watch_party_guest_actor();
    $isAnonymousCompanion = true;
} else {
    $user = $registeredUser;
    if (!bm_watch_party_is_vip($user) && !$hasInviteAccess) {
        $bmWpReturn = (string)($_SERVER['REQUEST_URI'] ?? '/watch-party');
        $_SESSION['vip_return_after_purchase'] = $bmWpReturn;
        bm_vip_render_gate_screen('watch_party', $user, $bmWpReturn);
    }
}

$isAdmin = bm_watch_party_is_admin($user);
$bmChatEnabled = bm_watch_party_chat_enabled();
$accessReady = bm_watch_party_is_enabled() && (bm_watch_party_is_vip($user) || $hasInviteAccess);
$canCreate = bm_watch_party_is_vip($user);
$csrf = bm_user_csrf_token();
$username = (string)($user['username'] ?? 'همراه مهمان');
// Voice Call is public for active VIP room members and, if enabled by admin,
// the one anonymous companion who entered through the secret room invite.
$bmVoiceTestEnabled = bm_watch_party_voice_test_allowed($user);
// Microphone stays blocked site-wide and is opened only on this Watch Party response
// when the current room actor is actually eligible for Voice Call.
if (!headers_sent()) {
    header('Permissions-Policy: geolocation=(), microphone=' . ($bmVoiceTestEnabled ? '(self)' : '()') . ', camera=(), payment=()', true);
}
$bmVoiceIceServers = $bmVoiceTestEnabled ? bm_watch_party_voice_ice_servers($user) : [];
$bmVoiceTurnReady = $bmVoiceTestEnabled ? bm_watch_party_voice_turn_ready($user) : false;
// Anonymous companions should still see the normal Login/Register header instead
// of being presented as a permanent site account.
$currentUser = $isAnonymousCompanion ? null : $user;
$userLang = (string)($_COOKIE['user_lang'] ?? ($user['language'] ?? 'fa'));
$userLang = in_array($userLang, ['fa', 'en'], true) ? $userLang : 'fa';
$currentLanguage = $userLang;
$t = [
    'fa' => ['home'=>'خانه','search'=>'جستجو','collections'=>'کالکشن‌ها','categories'=>'دسته‌بندی','player'=>'پلیر','notifications'=>'اعلان‌ها','account'=>'حساب کاربری','profile'=>'پروفایل','login'=>'ورود','register'=>'ثبت نام','logout'=>'خروج','admin_panel'=>'پنل مدیریت'],
    'en' => ['home'=>'Home','search'=>'Search','collections'=>'Collections','categories'=>'Categories','player'=>'Player','notifications'=>'Notifications','account'=>'Account','profile'=>'Profile','login'=>'Login','register'=>'Register','logout'=>'Logout','admin_panel'=>'Admin Panel'],
];
$notificationsList = [];
$latestNotification = null;

$userTheme = (string)($user['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-purple'));
$watchPartyThemes = [
    'dark-green' => '#2f7cff',
    'dark-blue' => '#3b82f6',
    'dark-purple' => '#8b5cf6',
    'dark-pink' => '#ec4899',
    'dark-red' => '#ef4444',
    'dark-orange' => '#f97316',
    'dark-cyan' => '#06b6d4',
    'dark-white' => '#ffffff',
    'dark-black' => '#8b5cf6',
];
$watchPartyBackgroundCatalog = function_exists('bm_user_background_catalog') ? bm_user_background_catalog() : ['simple'=>['name'=>'ساده','name_en'=>'Simple']];
// V148.61.9.30: Watch Party has one unified appearance catalog.
// The legacy pro-host visual themes are now room backgrounds too, so two competing
// appearance systems can no longer overwrite each other.
$watchPartyBackgroundCatalog += [
    'romantic_hearts' => ['name'=>'عاشقانه','name_en'=>'Romantic'],
    'galaxy_nova'     => ['name'=>'کهکشانی','name_en'=>'Galaxy'],
    'starlight'       => ['name'=>'ستاره‌ای','name_en'=>'Starlight'],
    'aurora'          => ['name'=>'شفق قطبی','name_en'=>'Aurora'],
];
$watchPartyUserBackground = function_exists('bm_user_background_resolve') ? bm_user_background_resolve($user) : 'simple';
$watchPartyAccent = $watchPartyThemes[$userTheme] ?? '#8b5cf6';
$watchPartyHex = ltrim($watchPartyAccent, '#');
if (strlen($watchPartyHex) === 3) {
    $watchPartyHex = $watchPartyHex[0] . $watchPartyHex[0] . $watchPartyHex[1] . $watchPartyHex[1] . $watchPartyHex[2] . $watchPartyHex[2];
}
$watchPartyAccentRgb = hexdec(substr($watchPartyHex, 0, 2)) . ',' . hexdec(substr($watchPartyHex, 2, 2)) . ',' . hexdec(substr($watchPartyHex, 4, 2));

// V148.61.9.38 — shared dynamic sticker/GIF registry managed from admin.
$bmWatchPartyStickerCatalog = bm_sticker_public_catalog();
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow,noarchive">
<meta name="theme-color" content="#08090d">
<title>تماشای دونفره | BankMovie</title>
<!-- Exact public BankMovie header stack (same assets and order as index.php). -->
<script id="bm-watch-party-device-tier-v148611">
(function(d,n){
  try{
    var root=d.documentElement;
    var mm=function(q){return !!(window.matchMedia&&window.matchMedia(q).matches);};
    var conn=n.connection||n.mozConnection||n.webkitConnection||{};
    var mobile=mm('(max-width: 900px)')||mm('(pointer: coarse)');
    var ua=String(n.userAgent||'');
    var android=/Android/i.test(ua);
    var match=ua.match(/Android\s+([0-9]+)/i);
    var androidMajor=match?Number(match[1]||0):0;
    var memory=Number(n.deviceMemory||0);
    var cores=Number(n.hardwareConcurrency||0);
    var effective=String(conn.effectiveType||'');
    var slow=/slow-2g|2g/.test(effective);
    var forced=false;
    try{forced=new URLSearchParams(location.search).get('wp_lite')==='1'||localStorage.getItem('bm_wp_render_safe_v1')==='1';}catch(e){}
    var weak=mobile&&(
      forced||!!conn.saveData||slow||
      (memory>0&&memory<=4)||
      (cores>0&&cores<=4)||
      (android&&androidMajor>0&&androidMajor<=11)||
      (android&&memory>0&&memory<=6&&cores>0&&cores<=6)||
      (android&&memory===0&&cores===0)
    );
    if(mobile)root.classList.add('wp-touch-device');
    if(android)root.classList.add('wp-android-device');
    if(weak){
      root.classList.add('wp-lite-device','bm-low-power');
      root.setAttribute('data-wp-render-mode','lite');
    }else{
      root.setAttribute('data-wp-render-mode','full');
    }
    window.__BM_WP_RENDER_TIER__={mobile:mobile,android:android,androidMajor:androidMajor,memory:memory,cores:cores,effectiveType:effective,lite:weak};
  }catch(e){}
})(document,navigator);
</script>
<link rel="stylesheet" href="/assets/css/index-inline-1.css?v=glass108">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-quick-search.css?v=quick101">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">
<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
<style>
@font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-style:normal;font-display:swap}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
:root{color-scheme:dark;--accent:<?= htmlspecialchars($watchPartyAccent,ENT_QUOTES,'UTF-8') ?>;--accent-rgb:<?= htmlspecialchars($watchPartyAccentRgb,ENT_QUOTES,'UTF-8') ?>;--bg:#08090d;--panel:#10131c;--panel-2:#151925;--text:#fff;--muted:#9da3b4;--muted-2:#6e7384;--line:rgba(255,255,255,.08);--soft:rgba(255,255,255,.045);--danger:#ff5574;--success:#39d98a;--shadow:0 24px 70px rgba(0,0,0,.46)}
html{scroll-behavior:smooth}body{min-height:100vh;background:radial-gradient(circle at 16% -10%,rgba(var(--accent-rgb),.18),transparent 34%),radial-gradient(circle at 94% 30%,rgba(59,130,246,.08),transparent 32%),#08090d;color:var(--text);font-family:var(--bm-site-font,'BonVF'),Tahoma,system-ui,sans-serif;overflow-x:hidden}button,input,select{font:inherit}button{color:inherit}a{color:inherit;text-decoration:none}svg{display:block}.hidden{display:none!important}
.wp-header{position:sticky;top:0;z-index:100;height:72px;background:rgba(8,9,13,.78);border-bottom:1px solid var(--line);backdrop-filter:blur(22px) saturate(150%)}.wp-header-inner{width:min(1440px,calc(100% - 32px));height:100%;margin:auto;display:flex;align-items:center;justify-content:space-between;gap:16px}.wp-brand{display:flex;align-items:center;gap:12px;min-width:0}.wp-brand img{width:142px;height:auto;display:block}.wp-brand-sep{width:1px;height:28px;background:var(--line)}.wp-brand-label{display:flex;align-items:center;gap:7px;font-size:12px;font-weight:900;color:#ddd}.vip-mark{display:inline-flex;align-items:center;justify-content:center;height:24px;padding:0 9px;border-radius:999px;background:linear-gradient(135deg,var(--accent),#d6c4ff);color:#09080d;font-size:10px;font-weight:950;letter-spacing:.6px}.wp-header .header-actions{display:flex;align-items:center;gap:8px}.icon-btn,.header-pill{height:42px;border-radius:999px;border:1px solid var(--line);background:rgba(255,255,255,.045);display:inline-flex;align-items:center;justify-content:center;gap:8px;cursor:pointer;transition:.2s}.icon-btn{width:42px}.icon-btn svg,.header-pill svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}.icon-btn:hover,.header-pill:hover{border-color:rgba(var(--accent-rgb),.34);background:rgba(var(--accent-rgb),.12);color:var(--accent)}.header-pill{padding:0 14px;font-size:12px;font-weight:850}.header-account{color:var(--muted)}
.page-shell{width:min(1440px,calc(100% - 32px));margin:0 auto;padding:24px 0 52px}.hero{position:relative;overflow:hidden;border:1px solid var(--line);border-radius:30px;padding:24px 26px;margin-bottom:18px;background:radial-gradient(circle at 12% 0%,rgba(var(--accent-rgb),.23),transparent 38%),linear-gradient(135deg,rgba(255,255,255,.065),rgba(255,255,255,.018));box-shadow:var(--shadow)}.hero:after{content:"";position:absolute;inset:0;background:linear-gradient(120deg,transparent 40%,rgba(255,255,255,.035));pointer-events:none}.hero-content{position:relative;z-index:1;display:flex;align-items:center;justify-content:space-between;gap:20px}.hero-kicker{display:inline-flex;align-items:center;gap:8px;color:var(--accent);font-size:11px;font-weight:950;border:1px solid rgba(var(--accent-rgb),.28);background:rgba(var(--accent-rgb),.1);border-radius:999px;padding:7px 11px;margin-bottom:10px}.hero-kicker svg{width:16px;height:16px;stroke:currentColor}.hero h1{font-size:clamp(25px,4vw,42px);line-height:1.2;font-weight:950;background:linear-gradient(135deg,#fff,var(--accent));-webkit-background-clip:text;background-clip:text;color:transparent}.hero p{color:var(--muted);font-size:13px;line-height:1.9;margin-top:8px}.hero-status{display:flex;align-items:center;gap:8px;flex-wrap:wrap;justify-content:flex-end}.status-pill{height:34px;padding:0 12px;border-radius:999px;border:1px solid var(--line);background:rgba(0,0,0,.24);display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:850;color:var(--muted)}.status-pill.host{color:#ffd873;border-color:rgba(255,216,115,.24)}.status-pill.guest{color:#9dc5ff;border-color:rgba(157,197,255,.24)}.dot{width:8px;height:8px;border-radius:50%;background:#74798a}.dot.on{background:var(--success);box-shadow:0 0 14px rgba(57,217,138,.85)}
.toast-stack{position:fixed;top:84px;left:16px;right:16px;z-index:1000;display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none}.toast{max-width:min(520px,calc(100vw - 28px));display:flex;align-items:center;gap:10px;background:rgba(19,22,32,.94);border:1px solid var(--line);border-radius:999px;padding:11px 16px;box-shadow:0 16px 42px rgba(0,0,0,.38);backdrop-filter:blur(20px);font-size:12px;color:#fff;opacity:0;transform:translateY(-12px);transition:.22s}.toast.show{opacity:1;transform:translateY(0)}.toast.error{border-color:rgba(255,85,116,.34)}.toast-icon{width:22px;height:22px;border-radius:50%;display:grid;place-items:center;background:rgba(var(--accent-rgb),.14);color:var(--accent);font-weight:950}.toast.error .toast-icon{background:rgba(255,85,116,.14);color:var(--danger)}
.lobby-panel{border:1px solid var(--line);background:rgba(14,16,24,.88);border-radius:26px;margin-bottom:18px;overflow:hidden;box-shadow:0 18px 50px rgba(0,0,0,.26);transition:.3s}.lobby-panel.is-collapsed{max-height:0;margin-bottom:0;border-width:0;opacity:0;pointer-events:none}.lobby-head{padding:17px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between;gap:12px}.lobby-head h2{font-size:15px}.lobby-head span{font-size:11px;color:var(--muted)}.lobby-body{padding:18px;display:grid;grid-template-columns:1.1fr .75fr .75fr 1.1fr;gap:11px}.field{display:flex;flex-direction:column;gap:7px;color:var(--muted);font-size:11px}.input,select{width:100%;height:46px;padding:0 14px;background:#090b11;color:#fff;border:1px solid var(--line);border-radius:15px;outline:none}.input:focus,select:focus{border-color:rgba(var(--accent-rgb),.48);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.08)}.lobby-actions{grid-column:1/-1;display:grid;grid-template-columns:1fr auto 1fr;gap:12px;align-items:center}.or{font-size:11px;color:var(--muted-2)}.btn{height:46px;border-radius:999px;border:1px solid var(--line);background:rgba(255,255,255,.055);display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 16px;cursor:pointer;font-weight:900;font-size:12px;transition:.2s}.btn svg{width:17px;height:17px;stroke:currentColor;fill:none}.btn:hover{transform:translateY(-1px);border-color:rgba(var(--accent-rgb),.34)}.btn.primary{border:none;background:linear-gradient(135deg,var(--accent),#fff);color:#07070a}.btn.danger{color:#ff9bae;border-color:rgba(255,85,116,.25);background:rgba(255,85,116,.08)}.btn:disabled{opacity:.45;cursor:not-allowed;transform:none}.join-inline{display:flex;gap:8px}.join-inline .input{flex:1;direction:ltr;text-align:left}.access-warning{padding:12px 16px;border-radius:16px;margin-bottom:14px;color:#ffc6d1;background:rgba(255,85,116,.08);border:1px solid rgba(255,85,116,.25);font-size:12px}
.room-stage{display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:18px;align-items:start}.room-stage.is-locked{filter:saturate(.7);opacity:.82}.cinema-panel{position:relative;background:linear-gradient(180deg,rgba(17,20,30,.88),rgba(8,9,13,.94));border:1px solid var(--line);border-radius:32px;padding:17px;box-shadow:var(--shadow);overflow:hidden}.cinema-panel:before{content:"";position:absolute;inset:0;background:radial-gradient(circle at 16% 0%,rgba(var(--accent-rgb),.1),transparent 34%),radial-gradient(circle at 80% 100%,rgba(255,255,255,.04),transparent 34%);pointer-events:none}.cinema-titlebar{position:relative;z-index:2;display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:13px}.cinema-title{display:flex;align-items:center;gap:10px;font-size:13px;font-weight:950}.cinema-title svg{width:18px;height:18px;stroke:var(--accent)}.room-meta{display:flex;align-items:center;gap:7px;flex-wrap:wrap;justify-content:flex-end}.room-code{direction:ltr;display:inline-block;max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;color:#ddd}.mini-chip{height:30px;border:1px solid var(--line);background:rgba(255,255,255,.04);border-radius:999px;padding:0 10px;display:inline-flex;align-items:center;gap:6px;font-size:10px;color:var(--muted)}
.player-wrapper{position:relative;z-index:2;background:#000;border-radius:26px;overflow:hidden;width:100%;aspect-ratio:16/9;direction:ltr;box-shadow:0 24px 75px rgba(0,0,0,.56),0 0 0 1px rgba(255,255,255,.06),0 0 0 1px rgba(var(--accent-rgb),.11);border:1px solid rgba(255,255,255,.06)}.player-wrapper:fullscreen{border-radius:0;width:100vw;height:100vh;position:fixed;inset:0;z-index:9999;aspect-ratio:auto}.player-video{width:100%;height:100%;object-fit:contain;outline:none;background:#000;cursor:pointer}.player-empty{position:absolute;inset:0;display:grid;place-items:center;text-align:center;padding:24px;background:radial-gradient(circle at 50% 42%,rgba(var(--accent-rgb),.14),transparent 31%),linear-gradient(135deg,rgba(255,255,255,.03),transparent);pointer-events:none;transition:.2s}.player-empty.hidden{opacity:0;visibility:hidden}.empty-icon{width:74px;height:74px;border-radius:28px;margin:0 auto 14px;background:rgba(var(--accent-rgb),.1);border:1px solid rgba(var(--accent-rgb),.3);display:flex;align-items:center;justify-content:center;color:var(--accent);box-shadow:0 0 30px rgba(var(--accent-rgb),.14)}.empty-icon svg{width:34px;height:34px;fill:none;stroke:currentColor}.empty-title{font-weight:950;font-size:18px}.empty-desc{font-size:12px;color:var(--muted);margin-top:6px;max-width:450px;line-height:1.8}.activate-overlay{position:absolute;inset:0;z-index:8;display:grid;place-items:center;background:rgba(0,0,0,.34);backdrop-filter:blur(3px)}.activate-card{display:flex;flex-direction:column;align-items:center;gap:11px;text-align:center}.activate-card p{font-size:11px;color:#d5d7df}.big-play{width:74px;height:74px;border:1px solid rgba(255,255,255,.18);border-radius:50%;background:linear-gradient(135deg,var(--accent),#fff);color:#050508;display:grid;place-items:center;cursor:pointer;box-shadow:0 0 0 10px rgba(var(--accent-rgb),.1),0 18px 42px rgba(0,0,0,.45)}.big-play svg{width:28px;height:28px;fill:currentColor;stroke:none}.big-play.is-playing{opacity:0;transform:translate(-50%,-50%) scale(.86)!important;pointer-events:none}.buffering{position:absolute;top:50%;left:50%;z-index:15;transform:translate(-50%,-50%);width:64px;height:64px;border:4px solid rgba(var(--accent-rgb),.2);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite;display:none}.buffering.show{display:block}@keyframes spin{to{transform:translate(-50%,-50%) rotate(360deg)}}.guest-hint{position:absolute;top:14px;left:14px;z-index:9;border:1px solid rgba(255,255,255,.12);border-radius:999px;padding:7px 10px;background:rgba(0,0,0,.58);backdrop-filter:blur(12px);font-size:10px;color:#ddd}
.player-controls{position:absolute;left:0;right:0;bottom:0;z-index:10;padding:48px 16px 16px;background:linear-gradient(to top,rgba(0,0,0,.9),rgba(0,0,0,.46) 54%,transparent);opacity:0;transition:opacity .22s}.player-wrapper:hover .player-controls,.player-wrapper:active .player-controls,.player-controls:focus-within,.player-wrapper.paused .player-controls{opacity:1}.progress-container{display:flex;align-items:center;gap:11px;margin-bottom:12px}.progress-time{font-size:11px;color:#fff;min-width:42px;font-family:ui-monospace,SFMono-Regular,Menlo,monospace}.progress-bar{flex:1;height:5px;-webkit-appearance:none;appearance:none;background:linear-gradient(90deg,var(--accent) 0%,var(--accent) var(--progress,0%),rgba(255,255,255,.22) var(--progress,0%),rgba(255,255,255,.22) 100%);border-radius:999px;cursor:pointer}.progress-bar::-webkit-slider-thumb{-webkit-appearance:none;width:15px;height:15px;border-radius:50%;background:#fff;box-shadow:0 0 0 4px rgba(var(--accent-rgb),.3)}.controls-row,.controls-left,.controls-right{display:flex;align-items:center;gap:8px}.controls-row{justify-content:space-between}.ctrl-btn{min-width:42px;height:42px;border:0;border-radius:999px;background:rgba(255,255,255,.13);color:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:5px;padding:0 11px;font-size:10px;font-weight:900;backdrop-filter:blur(12px);transition:.18s}.ctrl-btn:hover,.ctrl-btn.active{background:var(--accent);color:#050505;transform:translateY(-1px)}.ctrl-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:2}.ctrl-btn.guest-locked{opacity:.45;cursor:not-allowed}.volume-control{height:42px;display:flex;align-items:center;gap:7px;border-radius:999px;background:rgba(255,255,255,.09);padding:0 9px}.volume-control .ctrl-btn{background:transparent;padding:0;min-width:27px}.volume-slider{width:78px;height:4px;-webkit-appearance:none;appearance:none;border-radius:999px;background:rgba(255,255,255,.28)}.volume-slider::-webkit-slider-thumb{-webkit-appearance:none;width:13px;height:13px;border-radius:50%;background:var(--accent)}
.side-stack{display:flex;flex-direction:column;gap:14px;position:sticky;top:90px}.side-card{background:linear-gradient(180deg,rgba(19,22,32,.9),rgba(10,12,18,.92));border:1px solid var(--line);border-radius:25px;overflow:hidden;box-shadow:0 18px 48px rgba(0,0,0,.3)}.side-head{min-height:58px;padding:12px 15px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line)}.side-head h3{font-size:13px;display:flex;align-items:center;gap:8px}.side-head svg{width:17px;height:17px;stroke:var(--accent)}.member-count{height:27px;padding:0 9px;border-radius:999px;background:rgba(var(--accent-rgb),.11);color:var(--accent);display:inline-flex;align-items:center;font-size:10px;font-weight:900}.members{padding:11px;display:flex;flex-direction:column;gap:7px}.member{display:flex;align-items:center;gap:9px;padding:9px;border-radius:16px;background:rgba(255,255,255,.035)}.member-avatar{width:35px;height:35px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,rgba(var(--accent-rgb),.32),rgba(var(--accent-rgb),.1));border:1px solid rgba(var(--accent-rgb),.28);color:#fff;font-weight:950}.member-meta{display:flex;flex-direction:column;gap:2px;min-width:0;flex:1}.member-meta strong{font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.member-meta small{font-size:9px;color:var(--muted)}.member-live{font-size:9px;color:var(--success);display:flex;align-items:center;gap:5px}.member-live i{width:6px;height:6px;border-radius:50%;background:var(--success)}.empty-side{padding:18px;text-align:center;color:var(--muted);font-size:11px}.chat-card{height:460px;display:flex;flex-direction:column}.messages{flex:1;overflow:auto;padding:12px;display:flex;flex-direction:column;gap:8px;overscroll-behavior:contain}.message{max-width:86%;align-self:flex-start;padding:9px 11px;border-radius:16px 16px 16px 5px;background:rgba(255,255,255,.065);font-size:11px;line-height:1.7}.message.mine{align-self:flex-end;border-radius:16px 16px 5px 16px;background:rgba(var(--accent-rgb),.16);border:1px solid rgba(var(--accent-rgb),.15)}.message b{display:block;color:var(--accent);font-size:9px;margin-bottom:2px}.chat-form{display:flex;gap:7px;padding:10px;border-top:1px solid var(--line)}.chat-form input{height:42px;flex:1}.send-btn{width:42px;height:42px;border-radius:50%;border:0;background:var(--accent);color:#08090d;display:grid;place-items:center;cursor:pointer}.send-btn svg{width:18px;height:18px;stroke:currentColor;fill:none}
.room-footer{position:relative;z-index:2;padding:13px 2px 0;display:flex;align-items:center;justify-content:space-between;gap:10px}.room-footer-info{display:flex;align-items:center;gap:8px;color:var(--muted);font-size:10px}.room-footer-actions{display:flex;gap:7px}.footer-btn{height:36px;border:1px solid var(--line);border-radius:999px;background:rgba(255,255,255,.045);padding:0 12px;display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:10px;font-weight:850}.footer-btn svg{width:15px;height:15px;stroke:currentColor;fill:none}.footer-btn:hover{color:var(--accent);border-color:rgba(var(--accent-rgb),.3)}.footer-btn.danger{color:#ff9bae}
.tool-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.7);backdrop-filter:blur(8px);z-index:390;opacity:0;visibility:hidden;transition:.2s}.tool-backdrop.open{opacity:1;visibility:visible}.room-tools{position:fixed;top:0;bottom:0;right:0;width:min(420px,94vw);z-index:400;background:rgba(13,15,23,.98);border-left:1px solid var(--line);transform:translateX(105%);transition:.28s cubic-bezier(.2,.8,.2,1);box-shadow:-24px 0 70px rgba(0,0,0,.44);display:flex;flex-direction:column}.room-tools.open{transform:translateX(0)}.tools-head{height:72px;padding:0 18px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between}.tools-head h2{font-size:16px}.tools-body{padding:16px;overflow:auto;display:flex;flex-direction:column;gap:16px}.tool-section{padding:15px;border:1px solid var(--line);border-radius:20px;background:rgba(255,255,255,.025)}.tool-section h3{font-size:12px;margin-bottom:11px}.tool-section .field+.field{margin-top:10px}.tool-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:11px}.privacy-note{font-size:10px;color:var(--muted);line-height:1.8;margin-top:10px}.file-input{height:auto;padding:10px}.close-circle{width:38px;height:38px;border-radius:50%;border:1px solid var(--line);background:rgba(255,255,255,.04);display:grid;place-items:center;cursor:pointer}.close-circle svg{width:17px;height:17px;stroke:currentColor}
@media(max-width:1040px){.room-stage{grid-template-columns:1fr}.side-stack{position:static;display:grid;grid-template-columns:.75fr 1.25fr}.chat-card{height:360px}.lobby-body{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.wp-header{height:64px}.wp-header-inner,.page-shell{width:min(100% - 18px,1440px)}.wp-brand img{width:118px}.wp-brand-sep,.wp-brand-label,.header-account{display:none}.page-shell{padding-top:12px}.hero{padding:18px;border-radius:23px}.hero-content{align-items:flex-start}.hero p{display:none}.hero-status{max-width:150px}.status-pill{height:30px;padding:0 9px;font-size:9px}.lobby-body{grid-template-columns:1fr}.lobby-actions{grid-template-columns:1fr}.or{text-align:center}.join-inline{flex-direction:column}.room-stage{gap:12px}.cinema-panel{padding:9px;border-radius:22px}.cinema-titlebar{padding:4px 2px;margin-bottom:9px}.cinema-title{font-size:11px}.room-meta .mini-chip:first-child{display:none}.player-wrapper{border-radius:18px}.player-controls{padding:38px 9px 9px}.progress-container{gap:7px;margin-bottom:8px}.progress-time{font-size:9px;min-width:34px}.ctrl-btn{min-width:36px;height:36px;padding:0 8px}.ctrl-btn svg{width:16px;height:16px}.volume-control{height:36px;padding:0 6px}.volume-slider{display:none}.controls-left{gap:5px}.controls-right{gap:5px}.side-stack{display:flex}.chat-card{height:350px}.room-footer{padding:10px 2px 1px;align-items:flex-start}.room-footer-info{flex-direction:column;align-items:flex-start;gap:3px}.room-footer-actions{flex-wrap:wrap;justify-content:flex-end}.header-pill span{display:none}.header-pill{width:42px;padding:0}.activate-card p{max-width:230px}.big-play{width:64px;height:64px}}
@media(max-width:420px){.hero h1{font-size:23px}.hero-kicker{font-size:9px}.hero-status{display:none}.cinema-titlebar{align-items:flex-start}.room-meta{gap:4px}.mini-chip{height:26px;padding:0 7px;font-size:8px}.seek-label{display:none}.room-footer{flex-direction:column}.room-footer-actions{width:100%}.footer-btn{flex:1;justify-content:center}.side-head{min-height:52px}.chat-form{padding:8px}.chat-form input{height:39px}.send-btn{width:39px;height:39px}}

/* v148.21 — Premium player settings + in-video chat */
.player-topbar{position:absolute;top:0;left:0;right:0;z-index:9;min-height:66px;padding:14px 16px 20px;display:flex;align-items:flex-start;justify-content:space-between;gap:14px;background:linear-gradient(to bottom,rgba(0,0,0,.72),rgba(0,0,0,.22) 68%,transparent);pointer-events:none;transition:.24s}.player-topbar>*{pointer-events:auto}.player-brand-inline{display:flex;align-items:center;gap:10px;min-width:0}.player-brand-orb{width:35px;height:35px;border-radius:13px;background:linear-gradient(135deg,var(--accent),rgba(255,255,255,.9));display:grid;place-items:center;color:#08090d;box-shadow:0 10px 28px rgba(var(--accent-rgb),.25)}.player-brand-orb svg{width:18px;height:18px;stroke:currentColor}.player-title-inline{display:flex;flex-direction:column;min-width:0;direction:rtl;text-align:right}.player-title-inline strong{font-size:12px;font-weight:950;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.player-title-inline span{font-size:9px;color:rgba(255,255,255,.62);margin-top:2px}.player-live-chip{height:31px;padding:0 10px;border-radius:999px;border:1px solid rgba(255,255,255,.12);background:rgba(7,8,12,.56);backdrop-filter:blur(14px);display:flex;align-items:center;gap:6px;font-size:9px;font-weight:900;color:rgba(255,255,255,.78);direction:rtl}.player-live-chip i{width:7px;height:7px;border-radius:50%;background:var(--success);box-shadow:0 0 13px rgba(57,217,138,.85)}
.player-wrapper.controls-hidden .player-topbar,.player-wrapper.controls-hidden .player-controls{opacity:0}.player-wrapper:not(.controls-hidden) .player-topbar,.player-wrapper:not(.controls-hidden) .player-controls{opacity:1}.player-wrapper.locked .player-topbar,.player-wrapper.locked .player-controls,.player-wrapper.locked .player-chat-fab,.player-wrapper.locked .player-chat-panel,.player-wrapper.locked .player-settings-modal,.player-wrapper.locked .chat-preview-toast{opacity:0!important;visibility:hidden!important;pointer-events:none!important}.player-lock-layer{position:absolute;inset:0;z-index:50;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.04)}.player-wrapper.locked .player-lock-layer{display:flex}.unlock-player-btn{width:58px;height:58px;border-radius:50%;border:1px solid rgba(255,255,255,.18);background:rgba(9,10,14,.76);backdrop-filter:blur(16px);color:#fff;display:grid;place-items:center;cursor:pointer;box-shadow:0 18px 46px rgba(0,0,0,.4)}.unlock-player-btn svg{width:23px;height:23px;stroke:currentColor}.unlock-player-btn:hover{color:var(--accent);border-color:rgba(var(--accent-rgb),.45)}
.subtitle-overlay{position:absolute;left:6%;right:6%;bottom:86px;z-index:8;text-align:center;pointer-events:none;direction:rtl;color:var(--subtitle-color,#fff);font-size:calc(22px * var(--subtitle-scale,1));font-weight:850;line-height:1.8;text-shadow:0 2px 3px #000,0 0 7px #000,0 0 16px rgba(0,0,0,.95)}.subtitle-overlay span{display:inline;white-space:pre-line;padding:2px 8px;border-radius:7px;background:rgba(0,0,0,.42);box-decoration-break:clone;-webkit-box-decoration-break:clone}.player-wrapper:fullscreen .subtitle-overlay{bottom:106px;font-size:calc(30px * var(--subtitle-scale,1))}
/* V32 — sticker/GIF overlay on the movie itself */
.player-sticker-layer{position:absolute;right:18px;bottom:236px;left:auto;top:auto;z-index:30;width:96px;height:96px;display:grid;place-items:end center;pointer-events:none;overflow:visible}
.player-sticker-pop{position:absolute;inset:0;display:grid;place-items:center;border-radius:25px;background:linear-gradient(145deg,rgba(8,11,18,.68),rgba(8,11,18,.34));border:1px solid rgba(255,255,255,.16);box-shadow:0 18px 36px rgba(0,0,0,.36),0 0 0 1px rgba(var(--accent-rgb),.12);opacity:0;transform:translateY(16px) scale(.72);filter:blur(1px);transition:opacity .22s ease,transform .34s cubic-bezier(.2,.9,.25,1.18),filter .22s ease}
.player-sticker-pop::after{content:"";position:absolute;right:22px;bottom:-8px;width:18px;height:18px;background:linear-gradient(145deg,rgba(8,11,18,.68),rgba(8,11,18,.34));border-right:1px solid rgba(255,255,255,.13);border-bottom:1px solid rgba(255,255,255,.13);transform:rotate(45deg);border-bottom-right-radius:5px;box-shadow:6px 6px 16px rgba(0,0,0,.18)}
.player-sticker-pop.show{opacity:1;transform:translateY(0) scale(1);filter:none}
.player-sticker-pop.leave{opacity:0;transform:translateY(-8px) scale(.86);filter:blur(1px)}
.player-sticker-pop.mine{border-color:rgba(var(--accent-rgb),.42);box-shadow:0 18px 36px rgba(0,0,0,.36),0 0 26px rgba(var(--accent-rgb),.18)}
.player-sticker-pop img,.player-sticker-pop video{display:block;width:80px;height:80px;max-width:80px;max-height:80px;object-fit:contain;border-radius:18px;filter:drop-shadow(0 8px 14px rgba(0,0,0,.26))}
.player-wrapper:fullscreen .player-sticker-layer,.player-wrapper:-webkit-full-screen .player-sticker-layer{right:24px;bottom:254px;width:112px;height:112px}
.player-wrapper:fullscreen .player-sticker-pop img,.player-wrapper:fullscreen .player-sticker-pop video,.player-wrapper:-webkit-full-screen .player-sticker-pop img,.player-wrapper:-webkit-full-screen .player-sticker-pop video{width:94px;height:94px;max-width:94px;max-height:94px}
@media(max-width:640px){.player-sticker-layer{right:10px;bottom:168px;width:76px;height:76px}.player-sticker-pop{border-radius:20px}.player-sticker-pop::after{right:18px;bottom:-7px;width:15px;height:15px}.player-sticker-pop img,.player-sticker-pop video{width:62px;height:62px;max-width:62px;max-height:62px;border-radius:14px}.player-wrapper:fullscreen .player-sticker-layer,.player-wrapper:-webkit-full-screen .player-sticker-layer{right:12px;bottom:184px;width:86px;height:86px}.player-wrapper:fullscreen .player-sticker-pop img,.player-wrapper:fullscreen .player-sticker-pop video,.player-wrapper:-webkit-full-screen .player-sticker-pop img,.player-wrapper:-webkit-full-screen .player-sticker-pop video{width:70px;height:70px;max-width:70px;max-height:70px}}
.player-chat-panel.open ~ .player-sticker-layer,.player-chat-panel.open + .player-settings-backdrop + .player-settings-modal + .player-sticker-layer{opacity:0}

.player-chat-fab{position:absolute;right:15px;bottom:84px;z-index:21;width:45px;height:45px;border-radius:50%;border:1px solid rgba(255,255,255,.16);background:linear-gradient(145deg,rgba(18,21,31,.9),rgba(7,8,12,.92));color:#fff;display:grid;place-items:center;cursor:pointer;box-shadow:0 14px 38px rgba(0,0,0,.45),0 0 0 1px rgba(var(--accent-rgb),.08);backdrop-filter:blur(18px);transition:.2s}.player-chat-fab:hover,.player-chat-fab.active{background:var(--accent);color:#07070a;transform:translateY(-2px)}.player-chat-fab svg{width:20px;height:20px;stroke:currentColor;fill:none}.chat-unread{position:absolute;top:-4px;right:-4px;min-width:20px;height:20px;padding:0 5px;border-radius:999px;background:#ff486d;color:#fff;border:2px solid #090a0f;display:none;align-items:center;justify-content:center;font-size:9px;font-weight:950;box-shadow:0 5px 18px rgba(255,72,109,.4)}.chat-unread.show{display:flex}.player-chat-fab.pulse{animation:chatPulse 1.1s ease 2}@keyframes chatPulse{0%,100%{box-shadow:0 14px 38px rgba(0,0,0,.45),0 0 0 0 rgba(var(--accent-rgb),.4)}50%{box-shadow:0 14px 38px rgba(0,0,0,.45),0 0 0 12px rgba(var(--accent-rgb),0)}}
.player-chat-panel{position:absolute;right:14px;bottom:138px;z-index:35;width:min(360px,calc(100% - 28px));height:min(430px,calc(100% - 92px));border:1px solid rgba(255,255,255,.12);border-radius:24px;background:linear-gradient(180deg,rgba(17,20,30,.97),rgba(8,9,14,.98));box-shadow:0 28px 80px rgba(0,0,0,.62),inset 0 1px 0 rgba(255,255,255,.05);backdrop-filter:blur(26px) saturate(145%);display:flex;flex-direction:column;opacity:0;visibility:hidden;transform:translateY(12px) scale(.97);transform-origin:bottom right;transition:.2s;overflow:hidden;direction:rtl}.player-chat-panel.open{opacity:1;visibility:visible;transform:translateY(0) scale(1)}.chat-panel-head{height:60px;padding:0 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid rgba(255,255,255,.08);background:linear-gradient(135deg,rgba(var(--accent-rgb),.12),transparent)}.chat-panel-title{display:flex;align-items:center;gap:10px}.chat-panel-icon{width:35px;height:35px;border-radius:13px;background:rgba(var(--accent-rgb),.14);color:var(--accent);display:grid;place-items:center}.chat-panel-icon svg{width:18px;height:18px;stroke:currentColor}.chat-panel-title strong{display:block;font-size:12px}.chat-panel-title small{display:block;color:var(--muted);font-size:9px;margin-top:2px}.chat-close-btn{width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.07);display:grid;place-items:center;cursor:pointer;color:#fff}.chat-close-btn:hover{background:rgba(255,255,255,.13)}.chat-close-btn svg{width:16px;height:16px;stroke:currentColor}.player-chat-panel .messages{flex:1;min-height:0;padding:13px 12px 8px}.player-chat-panel .message{max-width:84%;padding:9px 11px 8px;border-radius:17px 17px 17px 5px;background:rgba(255,255,255,.075);border:1px solid rgba(255,255,255,.045);box-shadow:0 8px 22px rgba(0,0,0,.12);font-size:11px}.player-chat-panel .message.mine{border-radius:17px 17px 5px 17px;background:linear-gradient(135deg,rgba(var(--accent-rgb),.24),rgba(var(--accent-rgb),.12));border-color:rgba(var(--accent-rgb),.19)}.message-time{display:flex;align-items:center;justify-content:flex-start;gap:3px;margin-top:3px;font-size:8px;color:rgba(255,255,255,.38);direction:ltr;text-align:left}.message-delivery-slot{display:inline-flex;align-items:center;justify-content:center;min-width:14px;height:14px}.message-delivery{width:14px;height:14px;display:inline-grid;place-items:center;color:rgba(255,255,255,.45)}.message-delivery svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:1.75;stroke-linecap:round;stroke-linejoin:round}.message-delivery.queued{color:rgba(255,255,255,.42)}.message-delivery.sent{color:rgba(255,255,255,.58)}.message-delivery.delivered{color:var(--accent)}.message-delivery.failed{color:#ff6476;cursor:pointer}.bm-wp-send-spinner{width:13px;height:13px;border-radius:50%;border:2px solid rgba(255,255,255,.25);border-top-color:var(--accent);display:inline-block;vertical-align:-2px;animation:bmWpSendSpin .8s linear infinite;box-shadow:0 0 10px rgba(var(--accent-rgb),.14)}@keyframes bmWpSendSpin{to{transform:rotate(360deg)}}.message-row.is-pending .message{opacity:.9}.message-row:not(.is-pending) .bm-wp-send-spinner{display:none!important}.player-chat-panel .chat-form{padding:10px;background:rgba(5,6,9,.58);border-top:1px solid rgba(255,255,255,.08)}.player-chat-panel .chat-form .input{height:42px;border-radius:999px;background:rgba(255,255,255,.055);padding:0 15px}.player-chat-panel .send-btn{flex:0 0 42px;box-shadow:0 8px 24px rgba(var(--accent-rgb),.25)}
.chat-preview-toast{position:absolute;right:14px;bottom:140px;z-index:29;width:min(330px,calc(100% - 28px));padding:11px 12px;border:1px solid rgba(var(--accent-rgb),.28);border-radius:18px;background:rgba(13,15,22,.94);box-shadow:0 20px 54px rgba(0,0,0,.56);backdrop-filter:blur(20px);display:flex;align-items:center;gap:10px;direction:rtl;cursor:pointer;opacity:0;visibility:hidden;transform:translateY(14px);transition:.22s}.chat-preview-toast.show{opacity:1;visibility:visible;transform:translateY(0)}.chat-preview-avatar{width:37px;height:37px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,var(--accent),rgba(255,255,255,.9));color:#08090d;font-weight:950;flex:0 0 auto}.chat-preview-text{min-width:0;flex:1}.chat-preview-text strong{display:block;font-size:10px;color:var(--accent);margin-bottom:2px}.chat-preview-text span{display:block;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}.chat-preview-reply{font-size:9px;color:rgba(255,255,255,.55);white-space:nowrap}
.player-settings-modal{position:absolute;right:14px;bottom:72px;z-index:38;width:min(350px,calc(100% - 28px));max-height:min(500px,calc(100% - 82px));border:1px solid rgba(255,255,255,.12);border-radius:24px;background:linear-gradient(180deg,rgba(18,21,31,.98),rgba(8,9,14,.98));box-shadow:0 28px 80px rgba(0,0,0,.66),inset 0 1px 0 rgba(255,255,255,.06);backdrop-filter:blur(26px) saturate(150%);overflow:hidden;opacity:0;visibility:hidden;transform:translateY(12px) scale(.97);transform-origin:bottom right;transition:.2s;direction:rtl}.player-settings-modal.open{opacity:1;visibility:visible;transform:translateY(0) scale(1)}.settings-panel{display:none;max-height:inherit;flex-direction:column}.settings-panel.active{display:flex}.settings-head{height:58px;padding:0 13px;display:flex;align-items:center;justify-content:space-between;gap:8px;border-bottom:1px solid rgba(255,255,255,.08);background:linear-gradient(135deg,rgba(var(--accent-rgb),.12),transparent)}.settings-head-title{display:flex;align-items:center;gap:9px;min-width:0}.settings-head-title svg{width:18px;height:18px;stroke:var(--accent)}.settings-head-title strong{font-size:12px}.settings-head-title small{display:block;font-size:8px;color:var(--muted);margin-top:2px}.settings-back,.settings-close{width:34px;height:34px;border:0;border-radius:50%;background:rgba(255,255,255,.07);display:grid;place-items:center;cursor:pointer;color:#fff}.settings-back:hover,.settings-close:hover{background:rgba(var(--accent-rgb),.17);color:var(--accent)}.settings-back svg,.settings-close svg{width:16px;height:16px;stroke:currentColor}.settings-scroll{padding:8px;overflow:auto;overscroll-behavior:contain;max-height:calc(min(500px,calc(100vh - 100px)) - 58px)}.setting-row,.setting-choice{width:100%;min-height:49px;padding:9px 10px;border:0;border-radius:15px;background:transparent;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:10px;cursor:pointer;text-align:right;transition:.18s}.setting-row:hover,.setting-choice:hover{background:rgba(var(--accent-rgb),.11)}.setting-row-main{display:flex;align-items:center;gap:10px;min-width:0}.setting-icon{width:35px;height:35px;border-radius:13px;background:rgba(var(--accent-rgb),.1);color:var(--accent);display:grid;place-items:center;flex:0 0 auto}.setting-icon svg{width:18px;height:18px;stroke:currentColor}.setting-text{min-width:0}.setting-text strong{display:block;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.setting-text small{display:block;font-size:8px;color:var(--muted);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.setting-value{font-size:9px;color:rgba(255,255,255,.56);font-weight:850;white-space:nowrap}.setting-arrow{width:15px;height:15px;stroke:rgba(255,255,255,.45);transform:rotate(180deg);flex:0 0 auto}.setting-divider{height:1px;background:rgba(255,255,255,.07);margin:5px 8px}.setting-choice{justify-content:flex-start}.setting-choice.active{background:rgba(var(--accent-rgb),.14);color:var(--accent)}.setting-check{margin-right:auto;width:21px;height:21px;border-radius:50%;background:var(--accent);color:#08090d;display:none;place-items:center}.setting-choice.active .setting-check{display:grid}.setting-check svg{width:13px;height:13px;stroke:currentColor}.setting-range-card{margin:6px 3px 10px;padding:13px;border:1px solid rgba(255,255,255,.08);border-radius:17px;background:rgba(255,255,255,.03)}.setting-range-head{display:flex;align-items:center;justify-content:space-between;font-size:10px;margin-bottom:12px}.setting-range-head strong{color:var(--accent);font-size:11px}.setting-range{width:100%;height:5px;-webkit-appearance:none;appearance:none;border-radius:999px;background:rgba(255,255,255,.18)}.setting-range::-webkit-slider-thumb{-webkit-appearance:none;width:17px;height:17px;border-radius:50%;background:var(--accent);box-shadow:0 0 0 4px rgba(var(--accent-rgb),.18)}.setting-note{padding:9px 11px;color:var(--muted);font-size:9px;line-height:1.8}.setting-switch{width:42px;height:24px;border-radius:999px;background:rgba(255,255,255,.13);padding:3px;transition:.18s;flex:0 0 auto}.setting-switch i{display:block;width:18px;height:18px;border-radius:50%;background:#fff;transition:.18s}.setting-row.on .setting-switch{background:var(--accent)}.setting-row.on .setting-switch i{transform:translateX(-18px);background:#08090d}.subtitle-color-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;padding:8px}.subtitle-color-btn{height:38px;border-radius:13px;border:2px solid transparent;background:var(--swatch);cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.18)}.subtitle-color-btn.active{border-color:var(--accent);box-shadow:0 0 0 3px rgba(var(--accent-rgb),.14)}.subtitle-file-label{display:flex;align-items:center;justify-content:center;gap:8px;height:43px;margin:6px 8px;border:1px dashed rgba(var(--accent-rgb),.36);border-radius:15px;color:var(--accent);cursor:pointer;font-size:10px;font-weight:900;background:rgba(var(--accent-rgb),.06)}.subtitle-file-label svg{width:17px;height:17px;stroke:currentColor}
body.theatre-mode .hero,body.theatre-mode .lobby-panel,body.theatre-mode .side-stack{display:none!important}body.theatre-mode .page-shell{width:min(1700px,100%);padding:10px 10px 30px}body.theatre-mode .room-stage{display:block}body.theatre-mode .cinema-panel{border-radius:22px}body.theatre-mode .player-wrapper{aspect-ratio:auto;height:calc(100vh - 185px);min-height:520px}.picture-fit .player-video{object-fit:contain;transform:none}.picture-fill .player-video{object-fit:cover;transform:none}.picture-stretch .player-video{object-fit:fill;transform:none}.picture-zoom .player-video{object-fit:contain;transform:scale(1.14)}
.room-glance{padding:12px}.room-glance-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.glance-box{padding:11px;border-radius:16px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.055)}.glance-box span{display:block;font-size:8px;color:var(--muted);margin-bottom:4px}.glance-box strong{display:block;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.room-glance-note{margin-top:9px;padding:9px 10px;border-radius:14px;background:rgba(var(--accent-rgb),.08);color:var(--muted);font-size:9px;line-height:1.8}
@media(max-width:700px){.player-topbar{padding:10px 10px 18px}.player-brand-orb{width:30px;height:30px;border-radius:11px}.player-title-inline strong{font-size:10px}.player-title-inline span{display:none}.player-live-chip{height:27px;font-size:8px}.player-chat-fab{width:40px;height:40px;right:9px;bottom:63px}.player-chat-panel{position:fixed;left:9px;right:9px;bottom:calc(12px + env(safe-area-inset-bottom));width:auto;height:min(390px,56vh);border-radius:22px;z-index:10050}.chat-preview-toast{right:7px;bottom:111px;width:calc(100% - 14px)}.player-settings-modal{position:fixed;left:9px;right:9px;bottom:calc(12px + env(safe-area-inset-bottom));width:auto;max-height:min(560px,76vh);border-radius:22px;z-index:10051;transform-origin:bottom center}.settings-scroll{max-height:calc(min(560px,76vh) - 58px)}.subtitle-overlay{left:3%;right:3%;bottom:66px;font-size:calc(15px * var(--subtitle-scale,1));line-height:1.65}.player-wrapper:fullscreen .subtitle-overlay{bottom:82px;font-size:calc(20px * var(--subtitle-scale,1))}.controls-right .mini-chip{display:none}.player-settings-modal .setting-text small{max-width:185px}.room-glance-grid{grid-template-columns:1fr 1fr}body.theatre-mode .player-wrapper{height:calc(100vh - 110px);min-height:0}}
@media(max-width:420px){.player-chat-panel{height:min(370px,54vh)}.player-chat-fab{bottom:58px}.chat-preview-toast{bottom:103px}.player-settings-modal{max-height:min(540px,78vh)}.setting-row{min-height:45px}.setting-icon{width:32px;height:32px}.subtitle-color-grid{gap:6px}.subtitle-color-btn{height:34px}}

</style>

<style id="bm-watch-party-v148-22-premium-fix">
:root{--wp-visible-height:100dvh;--wp-viewport-top:0px;--wp-keyboard-offset:0px;--wp-safe-bottom:env(safe-area-inset-bottom,0px)}
body{background:
 radial-gradient(circle at 8% 3%,rgba(var(--accent-rgb),.21),transparent 28rem),
 radial-gradient(circle at 92% 35%,rgba(37,134,255,.12),transparent 32rem),
 linear-gradient(180deg,#070910 0%,#090b12 48%,#05070c 100%);padding-bottom:0}
.wp-header{display:none!important}
.watch-party-site-header{position:sticky!important;top:0!important;z-index:12000!important;background:rgba(5,7,12,.78)!important;border-bottom:1px solid rgba(255,255,255,.075)!important;backdrop-filter:blur(24px) saturate(155%)!important;box-shadow:0 12px 34px rgba(0,0,0,.16)!important}
.watch-party-site-header .desktop-nav-item.active,.watch-party-site-header .desktop-nav-item:hover{color:var(--accent)!important}
.page-shell{padding-top:20px;padding-bottom:26px}
.hero{min-height:156px;padding:29px 32px;border-radius:32px;border-color:rgba(255,255,255,.095);background:
 radial-gradient(circle at 15% 0%,rgba(var(--accent-rgb),.31),transparent 38%),
 radial-gradient(circle at 92% 100%,rgba(37,134,255,.14),transparent 34%),
 linear-gradient(135deg,rgba(21,25,38,.96),rgba(9,11,18,.93));box-shadow:0 30px 90px rgba(0,0,0,.36),inset 0 1px 0 rgba(255,255,255,.055)}
.hero:before{content:"";position:absolute;width:360px;height:360px;border-radius:50%;top:-250px;right:12%;background:rgba(var(--accent-rgb),.2);filter:blur(60px);pointer-events:none}
.hero-kicker{letter-spacing:.65px;box-shadow:inset 0 1px 0 rgba(255,255,255,.07)}
.hero h1{letter-spacing:-.6px;text-shadow:0 10px 44px rgba(var(--accent-rgb),.16)}
.hero p{font-size:13.5px;max-width:760px;color:rgba(255,255,255,.61)}
.lobby-panel{background:linear-gradient(180deg,rgba(17,20,30,.94),rgba(8,10,16,.95));box-shadow:0 24px 64px rgba(0,0,0,.3),inset 0 1px 0 rgba(255,255,255,.035)}
.lobby-head{background:linear-gradient(90deg,rgba(var(--accent-rgb),.08),transparent)}
.input,select{background:linear-gradient(180deg,#0c0f17,#090b12);border-color:rgba(255,255,255,.09);box-shadow:inset 0 1px 0 rgba(255,255,255,.025)}
.room-stage{grid-template-columns:minmax(0,1fr) 350px;gap:20px}
.cinema-panel{padding:18px;border-radius:34px;border-color:rgba(255,255,255,.095);background:linear-gradient(155deg,rgba(20,24,36,.96),rgba(7,9,15,.98));box-shadow:0 35px 110px rgba(0,0,0,.52),inset 0 1px 0 rgba(255,255,255,.045)}
.cinema-panel:after{content:"";position:absolute;inset:-35% 22% auto;width:52%;height:52%;background:rgba(var(--accent-rgb),.12);filter:blur(70px);pointer-events:none}
.cinema-titlebar{min-height:43px;padding:0 5px}.cinema-title{letter-spacing:.15px}.cinema-title svg{filter:drop-shadow(0 0 12px rgba(var(--accent-rgb),.55))}
.player-wrapper{border-radius:28px;border:1px solid rgba(255,255,255,.11);background:#000;box-shadow:0 32px 90px rgba(0,0,0,.66),0 0 0 1px rgba(var(--accent-rgb),.08),0 0 55px rgba(var(--accent-rgb),.1)}
.player-wrapper:before{content:"";position:absolute;inset:0;z-index:2;pointer-events:none;border-radius:inherit;box-shadow:inset 0 0 0 1px rgba(255,255,255,.035),inset 0 -120px 100px -90px rgba(0,0,0,.82)}
.player-topbar{background:linear-gradient(180deg,rgba(0,0,0,.74),transparent)!important;padding:18px 19px 40px!important}
.player-brand-orb{background:linear-gradient(145deg,#fff,var(--accent))!important;box-shadow:0 12px 35px rgba(var(--accent-rgb),.3)!important}
.player-brand-orb img{width:25px;height:25px;object-fit:contain;filter:drop-shadow(0 4px 10px rgba(0,0,0,.28))}.cinema-title em{font-style:normal;font-size:8px;letter-spacing:1.4px;color:var(--accent);padding:4px 7px;border-radius:999px;background:rgba(var(--accent-rgb),.09);border:1px solid rgba(var(--accent-rgb),.2)}
.empty-premium-card{display:flex;flex-direction:column;align-items:center;max-width:520px;padding:22px 28px;border:1px solid rgba(255,255,255,.075);border-radius:28px;background:radial-gradient(circle at 50% 0,rgba(var(--accent-rgb),.17),transparent 52%),rgba(5,7,12,.58);backdrop-filter:blur(18px);box-shadow:0 24px 70px rgba(0,0,0,.28)}.empty-brand-logo{width:min(180px,48vw);height:auto;opacity:.88;filter:drop-shadow(0 14px 30px rgba(var(--accent-rgb),.2));margin-bottom:10px}.empty-premium-card .empty-icon{box-shadow:0 16px 38px rgba(var(--accent-rgb),.32)}.empty-badges{display:flex;align-items:center;justify-content:center;gap:7px;flex-wrap:wrap;margin-top:15px}.empty-badges span{font:800 8px/1 system-ui,sans-serif;letter-spacing:.8px;color:rgba(255,255,255,.66);padding:6px 8px;border-radius:999px;border:1px solid rgba(255,255,255,.085);background:rgba(255,255,255,.035)}
.player-live-chip{background:rgba(7,9,14,.56)!important;border:1px solid rgba(255,255,255,.12)!important;backdrop-filter:blur(14px)}
.player-controls{background:linear-gradient(0deg,rgba(0,0,0,.88),rgba(0,0,0,.45) 62%,transparent)!important;padding:70px 16px 14px!important}
.controls-row{border:1px solid rgba(255,255,255,.085);border-radius:20px;padding:7px 8px;background:rgba(9,11,17,.56);backdrop-filter:blur(18px) saturate(145%);box-shadow:0 16px 44px rgba(0,0,0,.25)}
.ctrl-btn{border:1px solid transparent!important;border-radius:13px!important;background:transparent!important}.ctrl-btn:hover,.ctrl-btn.active{background:rgba(var(--accent-rgb),.14)!important;border-color:rgba(var(--accent-rgb),.22)!important;color:var(--accent)!important}
#partyPlayBtn{background:linear-gradient(135deg,var(--accent),color-mix(in srgb,var(--accent) 64%,#fff))!important;color:#05070b!important;box-shadow:0 12px 28px rgba(var(--accent-rgb),.28)}
.progress-bar{height:5px!important}.progress-bar::-webkit-slider-thumb{width:15px!important;height:15px!important;box-shadow:0 0 0 4px rgba(var(--accent-rgb),.18)!important}
.player-chat-fab{right:18px!important;bottom:103px!important;width:48px!important;height:48px!important;border-radius:17px!important;background:linear-gradient(145deg,var(--accent),color-mix(in srgb,var(--accent) 62%,#fff))!important;color:#080a0f!important;border:1px solid rgba(255,255,255,.45)!important;box-shadow:0 18px 45px rgba(var(--accent-rgb),.35),inset 0 1px 0 rgba(255,255,255,.55)!important}
.player-chat-fab:hover{transform:translateY(-3px) scale(1.03)!important}.chat-unread{border:2px solid #080a0f!important}
.player-chat-panel{border-color:rgba(255,255,255,.14);background:linear-gradient(180deg,rgba(19,23,35,.985),rgba(6,8,13,.99));box-shadow:0 34px 100px rgba(0,0,0,.7),inset 0 1px 0 rgba(255,255,255,.07)}
.chat-panel-head{background:radial-gradient(circle at 90% 10%,rgba(var(--accent-rgb),.2),transparent 55%),rgba(255,255,255,.018)}
.player-chat-panel .message{font-size:11.5px;line-height:1.85}.player-chat-panel .chat-form{padding:11px 12px calc(11px + env(safe-area-inset-bottom,0px))}
.chat-preview-toast{box-shadow:0 22px 60px rgba(0,0,0,.52),0 0 0 1px rgba(var(--accent-rgb),.11)!important}
.side-card{border-color:rgba(255,255,255,.09);background:linear-gradient(155deg,rgba(20,24,36,.94),rgba(8,10,16,.96));box-shadow:0 28px 75px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.04)}
.side-head{background:linear-gradient(90deg,rgba(var(--accent-rgb),.075),transparent)}
.member,.glance-box{border:1px solid rgba(255,255,255,.045);background:linear-gradient(145deg,rgba(255,255,255,.055),rgba(255,255,255,.022))!important}
.room-footer{margin-top:3px;padding:15px 5px 2px;border-top:1px solid rgba(255,255,255,.055)}
.footer-btn{background:linear-gradient(145deg,rgba(255,255,255,.075),rgba(255,255,255,.025));border-color:rgba(255,255,255,.095)}
.room-tools{background:linear-gradient(180deg,rgba(17,20,31,.995),rgba(7,9,15,.995));box-shadow:-34px 0 100px rgba(0,0,0,.58)}
.tool-section{background:linear-gradient(145deg,rgba(255,255,255,.05),rgba(255,255,255,.018))}
.bm-global-footer{margin-top:26px!important}

@media(max-width:1040px){.room-stage{grid-template-columns:1fr}.side-stack{grid-template-columns:1fr 1fr}.side-card{min-height:100%}}
@media(max-width:700px){
 body{padding-bottom:calc(88px + env(safe-area-inset-bottom,0px))}
 .page-shell{width:min(100% - 14px,1440px);padding-top:10px}.hero{min-height:auto;padding:18px 16px;border-radius:23px}.hero h1{font-size:24px}.hero-status{display:none}.hero p{display:block;font-size:11px;line-height:1.8}
 .cinema-panel{padding:8px;border-radius:23px}.cinema-titlebar{padding:4px 3px}.cinema-title em{display:none}.player-wrapper{border-radius:18px;min-height:210px}.empty-premium-card{padding:14px 16px;border-radius:20px}.empty-brand-logo{width:126px;margin-bottom:5px}.empty-badges{display:none}.player-controls{padding:54px 7px 7px!important}.controls-row{padding:4px;border-radius:15px}.ctrl-btn{height:35px!important;min-width:34px!important;border-radius:10px!important}.controls-right #memberCountTop{display:none}.player-topbar{padding:12px 12px 34px!important}.player-title-inline strong{font-size:10px!important}.player-title-inline span{font-size:8px!important}
 .player-chat-fab{right:10px!important;bottom:82px!important;width:44px!important;height:44px!important;border-radius:15px!important}
 .side-stack{display:flex}.bm-global-footer{width:calc(100% - 14px)!important;margin-top:16px!important}
}

/* Android/iOS keyboard-safe chat sheet. It is portalled to body/fullscreen by JS. */
.player-chat-panel.is-viewport-sheet{position:fixed!important;z-index:2147483000!important;left:max(8px,env(safe-area-inset-left,0px))!important;right:max(8px,env(safe-area-inset-right,0px))!important;bottom:calc(10px + env(safe-area-inset-bottom,0px))!important;top:auto!important;width:auto!important;height:min(430px,calc(var(--wp-visible-height,100dvh) - 20px))!important;max-height:calc(var(--wp-visible-height,100dvh) - 20px)!important;border-radius:24px!important;transform-origin:bottom center!important}
/* Chrome Android already moves fixed layers into the visual viewport when the keyboard opens.
   Using keyboard height as bottom offset pushed the sheet above the screen. Anchor the sheet
   to the exact VisualViewport top/height instead. */
body.wp-keyboard-open .player-chat-panel.is-viewport-sheet{top:calc(var(--wp-viewport-top,0px) + 5px)!important;bottom:auto!important;height:calc(var(--wp-visible-height,100dvh) - 10px)!important;max-height:calc(var(--wp-visible-height,100dvh) - 10px)!important;border-radius:20px!important}
body.wp-keyboard-open .player-chat-panel.is-viewport-sheet .chat-panel-head{height:49px;min-height:49px}
body.wp-keyboard-open .player-chat-panel.is-viewport-sheet .chat-panel-title small{display:none}
body.wp-keyboard-open .player-chat-panel.is-viewport-sheet .messages{padding-top:8px}
body.wp-keyboard-open .player-chat-panel.is-viewport-sheet .chat-form{padding:7px 8px calc(7px + env(safe-area-inset-bottom,0px))}
@media(max-width:900px),(pointer:coarse){body.wp-chat-modal-open{overflow:hidden!important;overscroll-behavior:none!important}.player-chat-panel{max-width:none}.player-chat-panel.is-viewport-sheet .chat-form .input{font-size:16px!important}}
@media(max-width:700px) and (orientation:landscape){
 .player-chat-panel.is-viewport-sheet{height:min(300px,calc(var(--wp-visible-height,100dvh) - 8px))!important;max-height:calc(var(--wp-visible-height,100dvh) - 8px)!important;bottom:4px!important;border-radius:17px!important}
 body.wp-keyboard-open .player-chat-panel.is-viewport-sheet{top:calc(var(--wp-viewport-top,0px) + 4px)!important;bottom:auto!important;height:calc(var(--wp-visible-height,100dvh) - 8px)!important}
 .player-chat-panel.is-viewport-sheet .chat-panel-head{height:46px;min-height:46px}.player-chat-panel.is-viewport-sheet .chat-panel-icon{width:31px;height:31px}.player-chat-panel.is-viewport-sheet .messages{padding:7px}.player-chat-panel.is-viewport-sheet .message{padding:7px 9px;font-size:10.5px}.player-chat-panel.is-viewport-sheet .chat-form{padding:6px}.player-chat-panel.is-viewport-sheet .chat-form .input{height:38px}.player-chat-panel.is-viewport-sheet .send-btn{width:38px;height:38px;flex-basis:38px}
}
</style>

<style id="bm-watch-party-original-header-bridge-v148-25">
/* The exact shared BankMovie header is absolute on desktop and overlays the page by design.
   Reserve its real height here so the Watch Party hero always starts below it. */
body.watch-party-page{padding-top:0!important}
body.watch-party-page #siteHeader{z-index:12000}
body.watch-party-page .page-shell{position:relative;z-index:1;padding-top:112px!important}
@media(min-width:992px) and (max-width:1279px){body.watch-party-page .page-shell{padding-top:98px!important}}
@media(max-width:991px){body.watch-party-page .page-shell{padding-top:88px!important}}
@media(max-width:520px){body.watch-party-page .page-shell{padding-top:82px!important}}
</style>

<style id="bm-watch-party-mobile-fullscreen-chat-v148-26">
:root{--wp-visible-width:100vw;--wp-viewport-left:0px}

/* پیام جدید مستقل از دکمه چت و در ناحیه میانی تصویر نمایش داده می‌شود. */
.chat-preview-toast{
  left:50%!important;right:auto!important;top:43%!important;bottom:auto!important;
  width:min(430px,calc(100% - 28px))!important;max-width:calc(100% - 28px)!important;
  transform:translate(-50%,-50%) scale(.94)!important;
  transform-origin:center!important;border-radius:20px!important;
}
.chat-preview-toast.show{transform:translate(-50%,-50%) scale(1)!important}
.player-wrapper:fullscreen .chat-preview-toast,.player-wrapper:-webkit-full-screen .chat-preview-toast{top:44%!important}

@media(max-width:900px),(pointer:coarse){
  body.player-fullscreen{overflow:hidden!important;overscroll-behavior:none!important}
  .player-wrapper:fullscreen,.player-wrapper:-webkit-full-screen{
    position:fixed!important;inset:0!important;width:100vw!important;height:100dvh!important;
    min-width:100vw!important;min-height:100dvh!important;max-width:none!important;max-height:none!important;
    border:0!important;border-radius:0!important;aspect-ratio:auto!important;background:#000!important;
  }
  .player-wrapper:fullscreen .player-video,.player-wrapper:-webkit-full-screen .player-video{width:100%!important;height:100%!important;object-fit:contain!important}
  .player-wrapper:fullscreen .player-controls,.player-wrapper:-webkit-full-screen .player-controls{padding-bottom:calc(8px + env(safe-area-inset-bottom,0px))!important}
  .player-wrapper:fullscreen .player-topbar,.player-wrapper:-webkit-full-screen .player-topbar{padding-top:calc(10px + env(safe-area-inset-top,0px))!important}
  #partyFullscreenBtn.active{color:var(--accent)!important;background:rgba(var(--accent-rgb),.16)!important;border-color:rgba(var(--accent-rgb),.28)!important}

  /* در موبایل چت ابتدا مثل Bottom Sheet باز می‌شود و تا زمان لمس ورودی، کیبورد را بالا نمی‌آورد. */
  .player-chat-panel.is-viewport-sheet{
    left:max(7px,env(safe-area-inset-left,0px))!important;
    right:max(7px,env(safe-area-inset-right,0px))!important;
    bottom:calc(7px + env(safe-area-inset-bottom,0px))!important;top:auto!important;
    width:auto!important;height:min(560px,72dvh,calc(var(--wp-visible-height,100dvh) - 14px))!important;
    max-height:calc(var(--wp-visible-height,100dvh) - 14px)!important;
    border-radius:24px!important;transform-origin:bottom center!important;
    contain:layout paint;will-change:transform,opacity;
  }
  .player-chat-panel.is-viewport-sheet .messages{overscroll-behavior:contain;padding:11px 10px 8px!important;scrollbar-width:thin}
  .player-chat-panel.is-viewport-sheet .chat-panel-head{flex:0 0 56px;min-height:56px;height:56px;padding:0 12px}
  .player-chat-panel.is-viewport-sheet .chat-form{flex:0 0 auto;padding:9px 9px calc(9px + env(safe-area-inset-bottom,0px))!important}
  .player-chat-panel.is-viewport-sheet .chat-form .input{font-size:16px!important;min-width:0}

  body.wp-keyboard-open .player-chat-panel.is-viewport-sheet{
    left:calc(var(--wp-viewport-left,0px) + max(5px,env(safe-area-inset-left,0px)))!important;
    right:auto!important;top:calc(var(--wp-viewport-top,0px) + 5px)!important;bottom:auto!important;
    width:calc(var(--wp-visible-width,100vw) - max(10px,env(safe-area-inset-left,0px) + env(safe-area-inset-right,0px)))!important;
    height:calc(var(--wp-visible-height,100dvh) - 10px)!important;max-height:calc(var(--wp-visible-height,100dvh) - 10px)!important;
    border-radius:19px!important;
  }

  .chat-preview-toast{
    top:40%!important;width:min(390px,calc(100% - 22px))!important;max-width:calc(100% - 22px)!important;
    padding:10px 11px!important;border-radius:18px!important;
  }
}

/* در حالت افقی، چت روی یک‌سوم سمت راست ویدئو قرار می‌گیرد تا تصویر و کنترل‌ها قابل استفاده بمانند. */
@media(max-width:950px) and (orientation:landscape), (pointer:coarse) and (orientation:landscape) and (max-height:700px){
  .player-chat-panel.is-viewport-sheet{
    left:auto!important;right:calc(7px + env(safe-area-inset-right,0px))!important;
    top:calc(7px + env(safe-area-inset-top,0px))!important;bottom:calc(7px + env(safe-area-inset-bottom,0px))!important;
    width:min(390px,48vw)!important;height:auto!important;max-height:none!important;border-radius:20px!important;
    transform-origin:center right!important;
  }
  body.wp-keyboard-open .player-chat-panel.is-viewport-sheet{
    left:auto!important;right:calc(5px + env(safe-area-inset-right,0px))!important;
    top:calc(var(--wp-viewport-top,0px) + 4px)!important;bottom:auto!important;
    width:min(390px,52vw)!important;height:calc(var(--wp-visible-height,100dvh) - 8px)!important;
    max-height:calc(var(--wp-visible-height,100dvh) - 8px)!important;border-radius:16px!important;
  }
  .player-chat-panel.is-viewport-sheet .chat-panel-head{flex-basis:48px!important;min-height:48px!important;height:48px!important}
  .player-chat-panel.is-viewport-sheet .chat-panel-title small{display:none}
  .player-chat-panel.is-viewport-sheet .messages{padding:7px!important;gap:6px!important}
  .player-chat-panel.is-viewport-sheet .message{padding:7px 9px!important;font-size:10.5px!important;line-height:1.65!important}
  .player-chat-panel.is-viewport-sheet .chat-form{padding:6px calc(6px + env(safe-area-inset-right,0px)) 6px 6px!important}
  .player-chat-panel.is-viewport-sheet .chat-form .input{height:38px!important}
  .player-chat-panel.is-viewport-sheet .send-btn{width:38px!important;height:38px!important;flex-basis:38px!important}
  .chat-preview-toast{top:43%!important;width:min(390px,54vw)!important}
}

@media(max-width:430px) and (orientation:portrait){
  .player-chat-panel.is-viewport-sheet{height:min(520px,70dvh,calc(var(--wp-visible-height,100dvh) - 12px))!important}
  .chat-preview-toast{top:37%!important}
}
</style>

<style id="bm-watch-party-avatar-chat-v148-27">
/* پیام چت کمی بالاتر از مرکز تصویر قرار می‌گیرد؛ نه وسط و نه روی کنترل‌ها. */
.chat-preview-toast{top:35%!important}
.player-wrapper:fullscreen .chat-preview-toast,.player-wrapper:-webkit-full-screen .chat-preview-toast{top:34%!important}
.chat-preview-avatar,.member-avatar,.message-avatar{overflow:hidden;background:linear-gradient(145deg,rgba(var(--accent-rgb),.28),rgba(255,255,255,.08));border:1px solid rgba(var(--accent-rgb),.28);box-shadow:0 9px 24px rgba(0,0,0,.3)}
.chat-preview-avatar img,.member-avatar img,.message-avatar img{display:block;width:100%;height:100%;object-fit:cover;border-radius:inherit}
.member-avatar{flex:0 0 35px}.message-row{display:flex;align-items:flex-end;gap:7px;max-width:92%;align-self:flex-start}.message-row.mine{align-self:flex-end;flex-direction:row-reverse}.message-row .message{max-width:100%;align-self:auto}.message-avatar{display:inline-flex;align-items:center;justify-content:center;width:29px;height:29px;border-radius:50%;flex:0 0 29px;margin-bottom:2px;color:#fff;font-size:10px;font-weight:950}.message-row.mine .message-avatar{border-color:rgba(var(--accent-rgb),.5)}
.player-chat-panel .messages{align-items:stretch}.player-chat-panel .message{position:relative}.player-chat-panel .message b{display:flex;align-items:center;gap:5px}
@media(max-width:900px),(pointer:coarse){.chat-preview-toast{top:33%!important}}
@media(max-width:950px) and (orientation:landscape), (pointer:coarse) and (orientation:landscape) and (max-height:700px){.chat-preview-toast{top:31%!important}.message-row{max-width:94%}.message-avatar{width:25px;height:25px;flex-basis:25px}}
@media(max-width:430px) and (orientation:portrait){.chat-preview-toast{top:32%!important}}
</style>


<style id="bm-watch-party-v148-28-faq-subtitle-glass">
/* کنترل‌های منظم و شیشه‌ای */
.player-controls{padding:76px 14px 13px!important}
.controls-row{gap:10px!important;padding:7px 8px!important;border-radius:22px!important;border:1px solid rgba(255,255,255,.13)!important;background:linear-gradient(135deg,rgba(18,22,34,.68),rgba(6,8,13,.58))!important;box-shadow:0 18px 48px rgba(0,0,0,.36),inset 0 1px 0 rgba(255,255,255,.08)!important;backdrop-filter:blur(24px) saturate(165%)!important}
.controls-left,.controls-right{gap:7px!important}.ctrl-btn{height:43px!important;min-width:43px!important;padding:0 11px!important;border:1px solid rgba(255,255,255,.09)!important;border-radius:15px!important;background:linear-gradient(145deg,rgba(255,255,255,.105),rgba(255,255,255,.035))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.06),0 9px 24px rgba(0,0,0,.18)!important;backdrop-filter:blur(16px)!important}
.ctrl-btn:hover,.ctrl-btn.active{background:linear-gradient(145deg,rgba(var(--accent-rgb),.27),rgba(var(--accent-rgb),.12))!important;border-color:rgba(var(--accent-rgb),.38)!important;color:#fff!important;transform:translateY(-2px)!important}
#partyPlayBtn{width:48px!important;min-width:48px!important;background:linear-gradient(145deg,color-mix(in srgb,var(--accent) 82%,#fff),var(--accent))!important;border-color:rgba(255,255,255,.42)!important;color:#07101d!important;box-shadow:0 13px 32px rgba(var(--accent-rgb),.38),inset 0 1px 0 rgba(255,255,255,.62)!important}
.volume-control{height:43px!important;border:1px solid rgba(255,255,255,.09)!important;background:linear-gradient(145deg,rgba(255,255,255,.09),rgba(255,255,255,.028))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.055)!important;backdrop-filter:blur(16px)!important}.volume-control .ctrl-btn{box-shadow:none!important;border:0!important;background:transparent!important}
.progress-container{padding:0 3px}.progress-bar{height:6px!important;box-shadow:0 0 0 1px rgba(255,255,255,.04)}
/* اعلان پیام دقیقاً بالای دکمه چت و در سمت چت */
.chat-preview-toast{left:auto!important;top:auto!important;right:18px!important;bottom:162px!important;width:min(340px,calc(100% - 36px))!important;transform:translateY(12px) scale(.97)!important;transform-origin:bottom right!important;border-radius:20px!important;background:linear-gradient(145deg,rgba(19,23,35,.96),rgba(7,9,15,.96))!important}
.chat-preview-toast.show{transform:translateY(0) scale(1)!important}.player-wrapper:fullscreen .chat-preview-toast,.player-wrapper:-webkit-full-screen .chat-preview-toast{top:auto!important;right:22px!important;bottom:166px!important}
/* جستجوی زیرنویس */
.subtitle-search-card{margin-bottom:9px;padding:12px;border:1px solid rgba(var(--accent-rgb),.24);border-radius:18px;background:radial-gradient(circle at 90% 0,rgba(var(--accent-rgb),.16),transparent 58%),rgba(255,255,255,.035)}.subtitle-search-brand{display:flex;align-items:center;gap:10px;margin-bottom:10px}.subtitle-search-icon{width:38px;height:38px;border-radius:14px;display:grid;place-items:center;color:var(--accent);background:rgba(var(--accent-rgb),.12);border:1px solid rgba(var(--accent-rgb),.22)}.subtitle-search-icon svg{width:19px;height:19px;stroke:currentColor}.subtitle-search-brand strong{display:block;font-size:11px}.subtitle-search-brand small{display:block;color:var(--muted);font-size:8px;margin-top:2px}.subtitle-search-form{display:flex;gap:7px}.subtitle-search-form .input{height:42px;min-width:0}.subtitle-search-btn{height:42px;padding:0 14px;border:1px solid rgba(255,255,255,.35);border-radius:13px;background:linear-gradient(145deg,var(--accent),color-mix(in srgb,var(--accent) 64%,#fff));color:#07101a;font-weight:950;cursor:pointer;white-space:nowrap}.subtitle-search-card p{margin-top:8px;color:var(--muted);font-size:8.5px;line-height:1.75}.subtitle-file-label{background:linear-gradient(145deg,rgba(255,255,255,.08),rgba(255,255,255,.025))!important;border-style:solid!important}
/* راهنما داخل تنظیمات */
.mini-help-list{display:flex;flex-direction:column;gap:8px}.mini-help-item{padding:11px;border:1px solid rgba(255,255,255,.075);border-radius:15px;background:rgba(255,255,255,.035)}.mini-help-item strong{font-size:10.5px}.mini-help-item p{margin-top:5px;color:var(--muted);font-size:9px;line-height:1.8}.setting-full-help-btn{height:42px;border:1px solid rgba(var(--accent-rgb),.28);border-radius:14px;background:rgba(var(--accent-rgb),.11);color:var(--accent);font-weight:900;cursor:pointer}
/* FAQ کامل */
.wp-faq-section{margin-top:20px;padding:22px;border:1px solid rgba(255,255,255,.09);border-radius:30px;background:radial-gradient(circle at 10% 0,rgba(var(--accent-rgb),.16),transparent 34%),linear-gradient(155deg,rgba(17,21,32,.94),rgba(7,9,15,.96));box-shadow:0 28px 85px rgba(0,0,0,.34),inset 0 1px 0 rgba(255,255,255,.045)}.wp-faq-head{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:16px}.wp-faq-kicker{display:block;color:var(--accent);font-size:8px;font-weight:950;letter-spacing:1.5px;margin-bottom:5px}.wp-faq-head h2{font-size:20px}.wp-faq-head p{margin-top:6px;color:var(--muted);font-size:11px;line-height:1.8}.wp-faq-badge{height:30px;padding:0 10px;border-radius:999px;display:inline-flex;align-items:center;border:1px solid rgba(var(--accent-rgb),.25);background:rgba(var(--accent-rgb),.1);color:var(--accent);font-size:8px;font-weight:950;letter-spacing:1px}.wp-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}.wp-faq-item{border:1px solid rgba(255,255,255,.075);border-radius:17px;background:linear-gradient(145deg,rgba(255,255,255,.05),rgba(255,255,255,.018));overflow:hidden}.wp-faq-item[open]{border-color:rgba(var(--accent-rgb),.25);background:linear-gradient(145deg,rgba(var(--accent-rgb),.1),rgba(255,255,255,.018))}.wp-faq-item summary{list-style:none;min-height:52px;padding:12px 14px;display:flex;align-items:center;justify-content:space-between;gap:10px;cursor:pointer;font-size:11px;font-weight:900}.wp-faq-item summary::-webkit-details-marker{display:none}.wp-faq-item summary span{width:26px;height:26px;border-radius:9px;display:grid;place-items:center;background:rgba(255,255,255,.055);color:var(--accent);font-size:16px;transition:.2s}.wp-faq-item[open] summary span{transform:rotate(45deg)}.wp-faq-answer{padding:0 14px 13px;color:var(--muted);font-size:10px;line-height:1.9}
.direct-source-only .tool-section-title{display:flex;align-items:center;gap:10px;margin-bottom:13px}.direct-source-only .tool-section-title h3{margin:0;font-size:12px}.direct-source-only .tool-section-title small{display:block;margin-top:3px;color:var(--muted);font-size:8px}.direct-publish-btn{width:100%}.room-appearance-section .tool-section-title{display:flex;align-items:center;gap:10px;margin-bottom:6px}.room-appearance-section .tool-section-title h3{margin:0;font-size:12px}.room-appearance-section .tool-section-title small{display:block;margin-top:3px;color:var(--muted);font-size:8px}.room-appearance-section .privacy-note{margin-top:8px}
@media(max-width:700px){.player-controls{padding:56px 7px 7px!important}.controls-row{gap:5px!important;padding:4px!important;border-radius:16px!important}.controls-left,.controls-right{gap:4px!important}.ctrl-btn{height:36px!important;min-width:35px!important;padding:0 7px!important;border-radius:11px!important}#partyPlayBtn{width:40px!important;min-width:40px!important}.volume-control{height:36px!important;padding:0 4px!important}.chat-preview-toast{right:10px!important;bottom:135px!important;width:min(320px,calc(100% - 20px))!important}.player-wrapper:fullscreen .chat-preview-toast,.player-wrapper:-webkit-full-screen .chat-preview-toast{right:10px!important;bottom:132px!important}.wp-faq-section{padding:15px 11px;border-radius:23px}.wp-faq-head h2{font-size:17px}.wp-faq-badge{display:none}.wp-faq-grid{grid-template-columns:1fr}.subtitle-search-form{flex-direction:column}.subtitle-search-btn{width:100%}}
@media(max-width:950px) and (orientation:landscape), (pointer:coarse) and (orientation:landscape) and (max-height:700px){.chat-preview-toast{right:64px!important;bottom:70px!important;width:min(330px,46vw)!important}.player-wrapper:fullscreen .chat-preview-toast,.player-wrapper:-webkit-full-screen .chat-preview-toast{right:64px!important;bottom:70px!important}}


/* BankMovie v148.29 — cinematic auto-hide chrome. */
.player-topbar,.player-controls,.player-chat-fab{
  transition:opacity .28s ease,visibility .28s ease,transform .28s ease!important;
}
.player-wrapper.controls-hidden{cursor:none}
.player-wrapper.controls-hidden .player-topbar,
.player-wrapper.controls-hidden .player-controls{
  opacity:0!important;
  visibility:hidden!important;
  pointer-events:none!important;
}
.player-wrapper.controls-hidden .player-topbar{transform:translateY(-10px)}
.player-wrapper.controls-hidden .player-controls{transform:translateY(12px)}
.player-wrapper.controls-hidden .player-chat-fab{
  opacity:0!important;
  visibility:hidden!important;
  pointer-events:none!important;
  transform:translateY(10px) scale(.9)!important;
}
.player-wrapper.controls-hidden.has-chat-unread .player-chat-fab,
.player-wrapper.controls-hidden .player-chat-fab.active{
  opacity:1!important;
  visibility:visible!important;
  pointer-events:auto!important;
  transform:translateY(0) scale(1)!important;
}
.player-wrapper.has-chat-unread .player-chat-fab{
  box-shadow:0 18px 45px rgba(var(--accent-rgb),.40),0 0 0 7px rgba(var(--accent-rgb),.10),inset 0 1px 0 rgba(255,255,255,.55)!important;
}
.player-wrapper.controls-hidden .chat-preview-toast.show{
  opacity:1!important;
  visibility:visible!important;
  pointer-events:auto!important;
}
@media (hover:hover){
  .player-wrapper.controls-hidden:hover{cursor:default}
}

</style>



<style id="bm-watch-party-free-companion-v14844">
body.companion-entry #lobbyPanel .lobby-body>.field,
body.companion-entry #lobbyPanel .lobby-actions>#createBtn,
body.companion-entry #lobbyPanel .lobby-actions>.or{display:none!important}
body.companion-entry #lobbyPanel .lobby-actions{justify-content:center}
body.companion-entry #lobbyPanel .join-inline{width:min(620px,100%);margin-inline:auto}
body.companion-entry #lobbyPanel .join-inline .input{display:none}
body.companion-entry #lobbyPanel .join-inline .btn{min-width:220px;background:linear-gradient(135deg,var(--accent),rgba(var(--accent-rgb),.72));color:#fff;border-color:rgba(var(--accent-rgb),.48)}
</style>
<style id="bm-role-badges-v14841">
.bm-admin-verified-badge{display:inline-grid;place-items:center;width:17px;height:17px;margin-inline-start:5px;border-radius:50%;background:linear-gradient(145deg,#39a7ff,#1765e8);border:1px solid rgba(255,255,255,.58);box-shadow:0 0 14px rgba(44,137,255,.5),inset 0 1px 0 rgba(255,255,255,.45);vertical-align:middle;flex:0 0 auto}
.bm-admin-verified-badge svg{width:10px;height:10px;fill:none;stroke:#fff;stroke-width:3.2;stroke-linecap:round;stroke-linejoin:round}
.member-meta strong,.message b,#chatPreviewName{display:flex;align-items:center;gap:4px;flex-wrap:wrap}
</style>
<link rel="stylesheet" href="/assets/css/bm-watch-party-low-end-v148611.css?v=148611">

<style id="bm-watch-party-home-footer-v41-glass-match">
/* V41 — Make Watch Party mobile footer visually match the homepage glass dock much more closely. */
@media (max-width:991px){
  html body.watch-party-page{padding-bottom:118px!important}

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]{
    position:fixed!important;
    left:50%!important;
    right:auto!important;
    top:auto!important;
    bottom:max(14px,env(safe-area-inset-bottom))!important;
    transform:translateX(-50%)!important;
    width:min(calc(100% - 22px),560px)!important;
    max-width:560px!important;
    min-height:80px!important;
    height:80px!important;
    padding:8px 9px!important;
    gap:4px!important;
    direction:ltr!important;
    align-items:center!important;
    justify-content:space-between!important;
    border-radius:34px!important;
    background:
      radial-gradient(circle at 8% 78%, rgba(255,151,87,.42), transparent 26%),
      radial-gradient(circle at 26% 20%, rgba(255,115,80,.22), transparent 25%),
      radial-gradient(circle at 54% 52%, rgba(153,228,255,.20), transparent 33%),
      radial-gradient(circle at 84% 18%, rgba(196,215,255,.20), transparent 24%),
      linear-gradient(135deg, rgba(255,173,120,.15) 0%, rgba(255,135,94,.12) 18%, rgba(179,211,229,.10) 47%, rgba(133,186,247,.12) 76%, rgba(255,255,255,.10) 100%),
      linear-gradient(180deg, rgba(255,255,255,.15), rgba(255,255,255,.07)),
      rgba(14,18,29,.58)!important;
    border:1px solid rgba(255,255,255,.18)!important;
    box-shadow:
      0 26px 55px rgba(0,0,0,.34),
      0 8px 30px rgba(255,133,78,.15),
      inset 0 1px 0 rgba(255,255,255,.28),
      inset 0 -1px 0 rgba(255,255,255,.05)!important;
    backdrop-filter:blur(26px) saturate(180%)!important;
    -webkit-backdrop-filter:blur(26px) saturate(180%)!important;
    overflow:visible!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::before{
    content:""!important;
    position:absolute!important;
    inset:1px!important;
    border-radius:33px!important;
    background:linear-gradient(180deg, rgba(255,255,255,.12), rgba(255,255,255,.02) 45%, rgba(255,255,255,.04) 100%)!important;
    pointer-events:none!important;
    z-index:0!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::after{
    content:""!important;
    position:absolute!important;
    left:16px!important;
    right:16px!important;
    bottom:-5px!important;
    height:28px!important;
    border-radius:999px!important;
    background:radial-gradient(ellipse at center, rgba(255,150,84,.28), rgba(131,192,255,.14) 48%, transparent 76%)!important;
    filter:blur(10px)!important;
    pointer-events:none!important;
    z-index:-1!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item{
    position:relative!important;
    z-index:1!important;
    flex:1 1 0!important;
    min-width:0!important;
    max-width:none!important;
    width:auto!important;
    height:62px!important;
    min-height:62px!important;
    margin:0!important;
    padding:8px 6px!important;
    display:flex!important;
    flex-direction:column!important;
    align-items:center!important;
    justify-content:center!important;
    gap:5px!important;
    border-radius:26px!important;
    background:transparent!important;
    border:0!important;
    box-shadow:none!important;
    text-decoration:none!important;
    color:rgba(255,255,255,.92)!important;
    opacity:1!important;
    transition:transform .22s ease, color .22s ease, background .22s ease, box-shadow .22s ease!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item svg{
    width:24px!important;
    height:24px!important;
    stroke:currentColor!important;
    fill:none!important;
    stroke-width:2.1!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item .nav-label{
    font-size:12.5px!important;
    line-height:1!important;
    font-weight:800!important;
    letter-spacing:0!important;
    color:inherit!important;
    white-space:nowrap!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item.active{
    flex:1.18 1 0!important;
    color:#f48a34!important;
    background:linear-gradient(180deg, rgba(255,255,255,.98), rgba(244,243,242,.93))!important;
    border:1px solid rgba(255,255,255,.45)!important;
    box-shadow:
      0 10px 24px rgba(255,255,255,.18),
      0 8px 18px rgba(0,0,0,.10),
      inset 0 1px 0 rgba(255,255,255,.96)!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item.active::after{
    content:""!important;
    position:absolute!important;
    left:10px!important;
    right:10px!important;
    top:7px!important;
    height:18px!important;
    border-radius:999px!important;
    background:linear-gradient(180deg, rgba(255,255,255,.55), rgba(255,255,255,0))!important;
    pointer-events:none!important;
  }

  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav] > .nav-item:not(.active):hover{
    transform:translateY(-1px)!important;
  }
}
</style>


<link rel="stylesheet" href="/assets/css/bm-uiverse-elements-v42.css?v=42.0">

<style id="bm-watch-party-chat-window-v51">
.chat-history-tools{position:absolute;top:64px;left:0;right:0;z-index:38;padding:8px 12px 0;display:flex;justify-content:center;pointer-events:none;transform:translateY(-5px);opacity:0;transition:opacity .16s ease,transform .16s ease}
.chat-history-tools:not([hidden]){pointer-events:auto;transform:translateY(0);opacity:1}
.chat-history-tools[hidden]{display:none!important}
.player-chat-panel.is-viewport-sheet .chat-history-tools{top:48px}
.chat-load-more-btn{height:40px;min-width:170px;padding:5px 12px;border:1px solid rgba(255,255,255,.11);border-radius:999px;background:linear-gradient(145deg,rgba(20,24,35,.94),rgba(9,11,17,.95));color:#fff;display:flex;align-items:center;justify-content:center;gap:9px;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.22),inset 0 1px 0 rgba(255,255,255,.055);transition:border-color .18s ease,transform .18s ease}
.chat-load-more-btn:hover{border-color:rgba(var(--accent-rgb),.40);transform:translateY(-1px)}
.chat-load-more-btn:active{transform:scale(.985)}
.chat-load-more-btn:disabled{cursor:default;opacity:.82;transform:none}
.chat-history-spinner{width:28px;height:28px;display:none;align-items:center;justify-content:center;gap:3px;flex:0 0 auto}
.chat-history-spinner i{width:5px;height:5px;border-radius:50%;background:var(--accent);box-shadow:0 0 10px rgba(var(--accent-rgb),.55);animation:bmV51ChatDots .82s ease-in-out infinite}
.chat-history-spinner i:nth-child(2){animation-delay:.12s}.chat-history-spinner i:nth-child(3){animation-delay:.24s}
.chat-load-more-btn.is-loading .chat-history-spinner{display:flex}.chat-load-more-btn.is-loading .chat-history-icon{display:none}
.chat-history-icon{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;background:rgba(var(--accent-rgb),.13);color:var(--accent)}
.chat-history-icon svg{width:14px;height:14px;fill:none;stroke:currentColor;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.chat-history-copy{display:flex;flex-direction:column;align-items:flex-start;line-height:1.12}.chat-history-copy strong{font-size:10px;font-weight:900}.chat-history-copy small{font-size:8px;color:rgba(255,255,255,.46);margin-top:2px}
@keyframes bmV51ChatDots{0%,100%{transform:translateY(0);opacity:.45}50%{transform:translateY(-4px);opacity:1}}
@media(max-width:700px){.chat-history-tools{padding:7px 10px 0}.chat-load-more-btn{height:38px;min-width:164px}}
@media(prefers-reduced-motion:reduce){.chat-history-spinner i{animation:none}.chat-load-more-btn{transition:none}}
</style>

</head>
<body data-theme="<?= htmlspecialchars($userTheme,ENT_QUOTES,'UTF-8') ?>" class="watch-party-page<?= $canCreate ? '' : ' companion-entry' ?>">
<div id="toastStack" class="toast-stack" aria-live="polite"></div>
<?php $bmHeaderClass='header'; require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>
<main class="page-shell">
  <section class="hero">
    <div class="hero-content">
      <div>
        <div class="hero-kicker"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M8 12h8M12 8v8"/><circle cx="12" cy="12" r="9"/></svg> BANKMOVIE WATCH PARTY</div>
        <h1>با هم ببینید؛ دقیقاً در یک لحظه</h1>
        <p>سینمای خصوصی بانک مووی؛ میزبان VIP اتاق را می‌سازد و همراه با همان لینک دعوت، رایگان وارد می‌شود.</p>
      </div>
      <div class="hero-status">
        <span id="roleBadge" class="status-pill">بدون اتاق</span>
        <span id="syncBadge" class="status-pill"><span class="dot"></span> آفلاین</span>
        <span class="status-pill"><span class="dot <?= $accessReady?'on':'' ?>"></span><?= $accessReady?'Watch Party فعال':'Watch Party غیرفعال' ?></span>
      </div>
    </div>
  </section>
  <?php if(!$accessReady): ?><div class="access-warning">قابلیت Watch Party در حال حاضر غیرفعال است.</div><?php endif; ?>
  <section id="lobbyPanel" class="lobby-panel">
    <div class="lobby-head"><h2><?= $canCreate ? 'ساخت یا ورود به اتاق خصوصی' : 'ورود رایگان همراه با لینک دعوت' ?></h2><span>همراه مهمان به ثبت‌نام یا اشتراک نیاز ندارد</span></div>
    <div class="lobby-body">
      <label class="field">شناسه فیلم<input id="movieId" class="input" type="number" min="0" value="0"></label>
      <label class="field">آرشیو<select id="archiveNo"><option value="1">آرشیو ۱</option><option value="2">آرشیو ۲</option></select></label>
      <label class="field">نوع محتوا<select id="mediaType"><option value="movie">فیلم</option><option value="series">سریال</option><option value="episode">قسمت سریال</option></select></label>
      <label class="field">شناسه منبع<input id="sourceRef" class="input" value="watch-party" maxlength="190"></label>
      <div class="lobby-actions">
        <button id="createBtn" class="btn primary" type="button" <?= $canCreate?'':'disabled' ?>><svg viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>ساخت اتاق خصوصی</button>
        <span class="or">یا</span>
        <div class="join-inline"><input id="joinCode" class="input" autocomplete="off" placeholder="کد یا لینک دعوت"><button id="joinBtn" class="btn" type="button">ورود به اتاق</button></div>
      </div>
    </div>
  </section>
  <div id="roomStage" class="room-stage is-locked">
    <section class="cinema-panel">
      <div class="cinema-titlebar">
        <div class="cinema-title"><svg viewBox="0 0 24 24" fill="none"><rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/></svg><span>سینمای خصوصی بانک مووی</span><em>WATCH PARTY</em></div>
        <div class="room-meta"><span class="mini-chip">اتاق <b id="roomCodeView" class="room-code">—</b></span><span class="mini-chip">زمان باقی‌مانده <b id="countdown">—</b></span></div>
      </div>
      <div class="player-wrapper paused" id="playerWrapper">
        <video id="video" class="player-video" playsinline webkit-playsinline preload="metadata" controlslist="nodownload noremoteplayback" disableremoteplayback></video>
        <div id="videoEmpty" class="player-empty"><div class="empty-premium-card"><img class="empty-brand-logo" src="/assets/brand/bankmovie-logo.webp" alt="BankMovie"><div class="empty-icon"><svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></div><div class="empty-title">سینمای خصوصی بانک مووی</div><div class="empty-desc">میزبان لینک مستقیم فیلم را وارد می‌کند و پخش برای همراه اتاق به‌صورت هم‌زمان آماده می‌شود.</div><div class="empty-badges"><span>SYNC PLAY</span><span>PRIVATE CHAT</span><span>FREE GUEST</span></div></div></div>
        <div id="activateOverlay" class="activate-overlay hidden"><div class="activate-card"><button id="activateBtn" class="big-play" type="button" aria-label="فعال کردن همگام‌سازی"><svg viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></button><p>یک بار لمس کنید تا همگام‌سازی صدادار مرورگر فعال شود</p></div></div>
        <div id="partyBuffering" class="buffering"></div>
        <div id="guestControlHint" class="guest-hint hidden">کنترل پخش با میزبان است</div>
        <button id="partyCenterPlay" class="big-play" type="button" style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:6;width:62px;height:62px" aria-label="پخش"><svg id="partyCenterIcon" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
        <div class="player-topbar">
          <div class="player-brand-inline"><span class="player-brand-orb"><img src="/assets/brand/bankmovie-icon-256.webp" alt=""></span><span class="player-title-inline"><strong>سینمای VIP بانک مووی</strong><span>تماشای خصوصی، همگام و زنده</span></span></div>
          <span class="player-live-chip"><i></i><span id="playerRoleText">اتاق خصوصی</span></span>
        </div>
        <div id="subtitleOverlay" class="subtitle-overlay" aria-live="off"></div>
        <div id="playerStickerLayer" class="player-sticker-layer" aria-live="polite" aria-atomic="true"></div>
        <div id="chatPreviewToast" class="chat-preview-toast" role="button" tabindex="0" aria-label="باز کردن پیام جدید"><span id="chatPreviewAvatar" class="chat-preview-avatar">؟</span><span class="chat-preview-text"><strong id="chatPreviewName">پیام جدید</strong><span id="chatPreviewMessage">—</span></span><span class="chat-preview-reply">پاسخ</span></div>
        <button id="playerChatBtn" class="player-chat-fab" type="button" aria-label="گفت‌وگوی داخل پلیر" <?= $bmChatEnabled ? '' : 'disabled style="display:none!important"' ?>><svg viewBox="0 0 24 24"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg><span id="chatUnread" class="chat-unread">۰</span></button>
        <section id="playerChatPanel" class="player-chat-panel" aria-label="گفت‌وگوی خصوصی" <?= $bmChatEnabled ? '' : 'style="display:none!important"' ?>>
          <div class="chat-panel-head"><div class="chat-panel-title"><span class="chat-panel-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg></span><span><strong>گفت‌وگوی خصوصی</strong><small>پیام‌ها با پایان اتاق پاک می‌شوند</small></span></div><button id="closePlayerChatBtn" class="chat-close-btn" type="button" aria-label="بستن"><svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>
          <div id="chatHistoryTools" class="chat-history-tools" hidden>
            <button id="chatLoadMoreBtn" class="chat-load-more-btn" type="button" aria-label="نمایش پیام‌های قدیمی‌تر">
              <span class="chat-history-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M12 5v14M6.5 10.5 12 5l5.5 5.5"/></svg></span>
              <span class="chat-history-spinner" aria-hidden="true"><i></i><i></i><i></i></span>
              <span class="chat-history-copy"><strong>پیام‌های قدیمی‌تر</strong><small>برای بارگذاری لمس کنید</small></span>
            </button>
          </div>
          <div id="messages" class="messages"><div class="empty-side">هنوز پیامی ارسال نشده</div></div>
          <form id="chatForm" class="chat-form"><input id="chatInput" class="input" maxlength="500" autocomplete="off" inputmode="text" enterkeyhint="send" autocapitalize="sentences" placeholder="پیام بنویسید…"><button class="send-btn" type="submit" aria-label="ارسال"><svg viewBox="0 0 24 24"><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></svg></button></form>
        </section>
        <div id="playerSettingsBackdrop" class="player-settings-backdrop" aria-hidden="true"></div>
        <section id="playerSettings" class="player-settings-modal" aria-label="تنظیمات پلیر">
          <div class="settings-panel active" data-settings-panel="main">
            <div class="settings-head"><div class="settings-head-title"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1-2.8-2.8.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3v-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1 2.8-2.8.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3h4v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1 2.8 2.8-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1h.2v4h-.2a1.7 1.7 0 0 0-1.4 1z"/></svg><span><strong>تنظیمات پخش</strong><small>تصویر، صدا، زیرنویس و امکانات حرفه‌ای</small></span></div><button class="settings-close" id="closePlayerSettingsBtn" type="button"><svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>
            <div class="settings-scroll">
              <button class="setting-row" type="button" data-open-settings="speed"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M12 3a9 9 0 1 0 9 9"/><path d="M12 12l5-5"/></svg></span><span class="setting-text"><strong>سرعت پخش</strong><small>برای میزبان روی هر دو پلیر اعمال می‌شود</small></span></span><span id="speedValue" class="setting-value">1x</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <button class="setting-row" type="button" data-open-settings="picture"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 9h4v3H7zM14 15h3"/></svg></span><span class="setting-text"><strong>حالت تصویر</strong><small>عادی، پرکننده، کشیده یا زوم</small></span></span><span id="pictureValue" class="setting-value">عادی</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <button class="setting-row" type="button" data-open-settings="brightness"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></span><span class="setting-text"><strong>روشنایی تصویر</strong><small>تنظیم محلی بدون اثر روی همراه</small></span></span><span id="brightnessValue" class="setting-value">100%</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <button class="setting-row" type="button" data-open-settings="subtitle"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 13h4M13 13h4M7 16h10"/></svg></span><span class="setting-text"><strong>زیرنویس دستی</strong><small>جستجو، افزودن فایل، رنگ، اندازه و تأخیر</small></span></span><span id="subtitleValue" class="setting-value">خاموش</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <button class="setting-row" type="button" data-open-settings="help"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 4.6 1.4c-.9 1.1-2.3 1.5-2.3 3.1"/><path d="M12 17h.01"/></svg></span><span class="setting-text"><strong>راهنما و سوالات متداول</strong><small>زیرنویس، همگام‌سازی، لینک ویدئو و مشکلات رایج</small></span></span><span class="setting-value">راهنما</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <button class="setting-row" type="button" data-open-settings="sleep"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M21 12.8A9 9 0 1 1 11.2 3 7 7 0 0 0 21 12.8z"/></svg></span><span class="setting-text"><strong>زمان‌سنج خواب</strong><small>توقف خودکار در زمان انتخابی</small></span></span><span id="sleepValue" class="setting-value">خاموش</span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
              <div class="setting-divider"></div>
              <button id="theatreSettingRow" class="setting-row" type="button"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M3 7h18v10H3zM7 3h10M7 21h10"/></svg></span><span class="setting-text"><strong>حالت سینمایی</strong><small>پلیر بزرگ و تمرکز کامل روی تماشا</small></span></span><span class="setting-switch"><i></i></span></button>
              <button id="chatSoundSettingRow" class="setting-row on" type="button" <?= $bmChatEnabled ? '' : 'style="display:none!important"' ?>><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/></svg></span><span class="setting-text"><strong>صدای اعلان چت</strong><small>اعلان کوتاه برای پیام جدید</small></span></span><span class="setting-switch"><i></i></span></button>
              <button id="sourceSettingRow" class="setting-row" type="button"><span class="setting-row-main"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1.1-1.1"/></svg></span><span class="setting-text"><strong>منبع و کیفیت ویدئو</strong><small>تغییر لینک برای میزبان اتاق</small></span></span><svg class="setting-arrow" viewBox="0 0 24 24"><path d="M9 18l6-6-6-6"/></svg></button>
            </div>
          </div>
          <div class="settings-panel" data-settings-panel="speed"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>سرعت پخش</strong><small>کنترل همگام توسط میزبان</small></span></div><span></span></div><div class="settings-scroll" id="speedChoices"></div></div>
          <div class="settings-panel" data-settings-panel="picture"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>حالت تصویر</strong><small>فقط روی همین دستگاه</small></span></div><span></span></div><div class="settings-scroll" id="pictureChoices"></div></div>
          <div class="settings-panel" data-settings-panel="brightness"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>روشنایی تصویر</strong><small>تنظیم محلی</small></span></div><span></span></div><div class="settings-scroll"><div class="setting-range-card"><div class="setting-range-head"><span>میزان روشنایی</span><strong id="brightnessPercent">100%</strong></div><input id="brightnessRange" class="setting-range" type="range" min="40" max="160" step="5" value="100"></div><div class="setting-note">این گزینه فقط فیلتر تصویر دستگاه شما را تغییر می‌دهد و روی پلیر همراه اثری ندارد.</div></div></div>
          <div class="settings-panel" data-settings-panel="subtitle"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>زیرنویس دستی</strong><small>SRT، VTT، ASS و SSA</small></span></div><span></span></div><div class="settings-scroll"><div class="subtitle-search-card"><div class="subtitle-search-brand"><span class="subtitle-search-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/><path d="M8 11h6M11 8v6"/></svg></span><span><strong>جستجوی زیرنویس در سابکده</strong><small>نام انگلیسی فیلم یا سریال و سال انتشار را وارد کن</small></span></div><form id="subkadeSearchForm" class="subtitle-search-form"><input id="subkadeQuery" class="input" type="search" autocomplete="off" placeholder="مثلاً I Swear 2025"><button id="subkadeSearchBtn" class="subtitle-search-btn" type="submit">جستجو</button></form><p>فایل ZIP را دانلود و استخراج کن، سپس فایل SRT، VTT، ASS یا SSA را انتخاب کن.</p></div><label class="subtitle-file-label"><svg viewBox="0 0 24 24" fill="none"><path d="M12 3v12M7 8l5-5 5 5M5 21h14"/></svg><span id="subtitleFileName">انتخاب فایل زیرنویس</span><input id="subtitleUpload" type="file" accept=".srt,.vtt,.ass,.ssa" hidden></label><div id="subtitleFileStatus" class="subtitle-file-status"><strong>فایلی بارگذاری نشده</strong><small>تنظیمات زیرنویس فقط روی همین دستگاه اعمال می‌شود.</small></div><button id="subtitleToggleRow" class="setting-row on" type="button"><span class="setting-row-main"><span class="setting-text"><strong>نمایش زیرنویس</strong><small>روشن یا خاموش کردن سریع</small></span></span><span class="setting-switch"><i></i></span></button><div class="setting-range-card"><div class="setting-range-head"><span>تأخیر زیرنویس</span><strong id="subtitleDelayValue">0.0s</strong></div><input id="subtitleDelayRange" class="setting-range" type="range" min="-10" max="10" step="0.1" value="0"></div><div class="setting-range-card"><div class="setting-range-head"><span>اندازه متن</span><strong id="subtitleSizeValue">100%</strong></div><input id="subtitleSizeRange" class="setting-range" type="range" min="65" max="180" step="5" value="100"></div><div class="setting-range-card"><div class="setting-range-head"><span>موقعیت عمودی</span><strong id="subtitlePositionValue">56px</strong></div><input id="subtitlePositionRange" class="setting-range" type="range" min="24" max="220" step="4" value="56"><small class="setting-range-help">فاصله زیرنویس از پایین پلیر؛ روی موبایل مقدار پیش‌فرض ۵۶ پیکسل است و از همین بخش قابل تنظیم می‌ماند.</small></div><div class="setting-range-card"><div class="setting-range-head"><span>تیرگی پس‌زمینه متن</span><strong id="subtitleBackgroundValue">42%</strong></div><input id="subtitleBackgroundRange" class="setting-range" type="range" min="0" max="85" step="5" value="42"></div><div class="subtitle-color-title">رنگ زیرنویس</div><div class="subtitle-color-grid"><button class="subtitle-color-btn active" style="--swatch:#fff" data-subtitle-color="#ffffff" type="button" aria-label="سفید"></button><button class="subtitle-color-btn" style="--swatch:#ffe66d" data-subtitle-color="#ffe66d" type="button" aria-label="زرد"></button><button class="subtitle-color-btn" style="--swatch:#68d7ff" data-subtitle-color="#68d7ff" type="button" aria-label="آبی"></button><button class="subtitle-color-btn" style="--swatch:#ff9fc8" data-subtitle-color="#ff9fc8" type="button" aria-label="صورتی"></button><button class="subtitle-color-btn" style="--swatch:#8dffb1" data-subtitle-color="#8dffb1" type="button" aria-label="سبز"></button></div><div class="subtitle-actions"><button id="resetSubtitleStyleBtn" class="setting-choice" type="button"><span class="setting-row-main"><span class="setting-text"><strong>بازنشانی ظاهر زیرنویس</strong><small>اندازه، موقعیت، رنگ و پس‌زمینه به حالت پیشنهادی برگردد</small></span></span></button><button id="removeSubtitleBtn" class="setting-choice danger" type="button"><span class="setting-row-main"><span class="setting-text"><strong>حذف زیرنویس</strong><small>پاک‌کردن فایل فعلی از پلیر</small></span></span></button></div></div></div>

          <div class="settings-panel" data-settings-panel="help"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>راهنما و سوالات متداول</strong><small>پاسخ سریع بدون خروج از پلیر</small></span></div><span></span></div><div class="settings-scroll"><div class="mini-help-list"><div class="mini-help-item"><strong>زیرنویس چطور اضافه می‌شود؟</strong><p>اگر پخش را از صفحه فیلم شروع کنی، زیرنویس جدا همراه لینک وارد اتاق می‌شود. برای فایل‌های دیگر، بارگذاری دستی SRT، VTT، ASS و SSA همچنان فعال است.</p></div><div class="mini-help-item"><strong>زیرنویس برای همراه هم فعال می‌شود؟</strong><p>بله؛ زیرنویس ثبت‌شده روی لینک فیلم برای هر دو دستگاه خودکار دریافت می‌شود. ظاهر و تأخیر زیرنویس روی هر دستگاه مستقل است.</p></div><div class="mini-help-item"><strong>چرا پخش خودکار شروع نمی‌شود؟</strong><p>هر کاربر باید فقط یک بار دکمه فعال‌سازی پخش را لمس کند تا مرورگر اجازه پخش صدادار بدهد.</p></div><button id="openFullFaqBtn" class="setting-full-help-btn" type="button">مشاهده همه سوالات متداول</button></div></div></div>
          <div class="settings-panel" data-settings-panel="sleep"><div class="settings-head"><button class="settings-back" type="button"><svg viewBox="0 0 24 24"><path d="M15 18l-6-6 6-6"/></svg></button><div class="settings-head-title"><span><strong>زمان‌سنج خواب</strong><small>توقف خودکار پخش</small></span></div><span></span></div><div class="settings-scroll" id="sleepChoices"></div></div>
        </section>
        <div id="playerLockLayer" class="player-lock-layer"><button id="unlockPlayerBtn" class="unlock-player-btn" type="button" aria-label="باز کردن قفل"><svg viewBox="0 0 24 24" fill="none"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/></svg></button></div>
        <div class="player-controls" id="playerControls">
          <div class="progress-container"><span id="partyCurrent" class="progress-time">00:00</span><input id="partyProgress" class="progress-bar" type="range" min="0" max="100" value="0"><span id="partyDuration" class="progress-time">00:00</span></div>
          <div class="controls-row">
            <div class="controls-left">
              <button id="partyPlayBtn" class="ctrl-btn" type="button" aria-label="پخش یا توقف"><svg id="partyPlayIcon" viewBox="0 0 24 24"><polygon points="5 3 19 12 5 21 5 3"/></svg></button>
              <button id="partyBackBtn" class="ctrl-btn" type="button"><svg viewBox="0 0 24 24"><path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/></svg><span class="seek-label">10-</span></button>
              <button id="partyForwardBtn" class="ctrl-btn" type="button"><svg viewBox="0 0 24 24"><path d="M21 12a9 9 0 1 1-3-6.7"/><path d="M21 4v6h-6"/></svg><span class="seek-label">10+</span></button>
              <div class="volume-control bm-volume-control-uiverse"><button id="partyVolumeBtn" class="ctrl-btn bm-sound-toggle" type="button" aria-label="قطع یا وصل صدا" aria-pressed="false"><span class="bm-sound-speaker" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="M39.389 13.769 22.235 28.606H6v19.093h15.989l17.4 15.051V13.769Z"/><path d="M48 27.6a19.5 19.5 0 0 1 0 21.4M55.1 20.5a30 30 0 0 1 0 35.6M61.6 14a38.8 38.8 0 0 1 0 48.6" class="bm-sound-waves"/></svg></span><span class="bm-sound-muted" aria-hidden="true"><svg viewBox="0 0 75 75"><path d="m39 14-17 15H6v19h16l17 15Z"/><path d="m49 26 20 24m0-24-20 24" class="bm-sound-x"/></svg></span><svg id="partyVolumeIcon" viewBox="0 0 24 24" aria-hidden="true" style="display:none!important"></svg></button><input id="partyVolume" class="volume-slider" type="range" min="0" max="100" value="100"></div>
            </div>
            <div class="controls-right"><span id="memberCountTop" class="mini-chip">۰ نفر</span><button id="partyPipBtn" class="ctrl-btn" type="button" aria-label="تصویر در تصویر" title="تصویر در تصویر"><svg viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="14" rx="2"/><rect x="12" y="11" width="7" height="5" rx="1"/></svg></button><button id="partySettingsBtn" class="ctrl-btn" type="button" aria-label="تنظیمات" title="تنظیمات"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1-2.8-2.8.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3v-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1 2.8-2.8.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3h4v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1 2.8 2.8-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1h.2v4h-.2a1.7 1.7 0 0 0-1.4 1z"/></svg></button><button id="partyLockBtn" class="ctrl-btn" type="button" aria-label="قفل کنترل‌ها" title="قفل کنترل‌ها"><svg viewBox="0 0 24 24"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg></button><button id="partyFullscreenBtn" class="ctrl-btn" type="button" aria-label="تمام صفحه"><svg viewBox="0 0 24 24"><path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M16 21h3a2 2 0 0 0 2-2v-3M8 21H5a2 2 0 0 1-2-2v-3"/></svg></button></div>
          </div>
        </div>
      </div>
      <div class="room-footer">
        <div class="room-footer-info"><span>انقضا: <b id="expiresView">—</b></span><span>·</span><span>پیام‌ها و لینک با پایان اتاق حذف می‌شوند</span></div>
        <div class="room-footer-actions"><button id="faqJumpBtn" class="footer-btn" type="button"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M9.7 9a2.5 2.5 0 1 1 4.6 1.4c-.9 1.1-2.3 1.5-2.3 3.1"/><path d="M12 17h.01"/></svg>راهنما</button><button id="copyBtn" class="footer-btn" type="button"><svg viewBox="0 0 24 24"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>کپی دعوت</button><button id="roomToolsBtn" class="footer-btn hidden" type="button"><svg viewBox="0 0 24 24"><path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1-2.8 2.8-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21h-4v-.2a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1-2.8-2.8.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3v-4h.2a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1 2.8-2.8.1.1a1.7 1.7 0 0 0 1.8.3 1.7 1.7 0 0 0 1-1.5V3h4v.2a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1 2.8 2.8-.1.1a1.7 1.7 0 0 0-.3 1.8 1.7 1.7 0 0 0 1.5 1h.2v4h-.2a1.7 1.7 0 0 0-1.4 1z"/></svg>تنظیم اتاق</button><button id="leaveBtn" class="footer-btn danger" type="button">خروج</button></div>
      </div>
    </section>
    <aside class="side-stack">
      <section class="side-card"><div class="side-head"><h3><svg viewBox="0 0 24 24" fill="none"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><path d="M20 8v6M23 11h-6"/></svg>اعضای اتاق</h3><span id="memberCount" class="member-count">۰/۲</span></div><div id="members" class="members"><div class="empty-side">هنوز کسی داخل اتاق نیست</div></div></section>
      <section class="side-card"><div class="side-head"><h3><svg viewBox="0 0 24 24" fill="none"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>وضعیت اتاق خصوصی</h3><span class="member-count">خصوصی</span></div><div class="room-glance"><div class="room-glance-grid"><div class="glance-box"><span>نقش شما</span><strong id="sideRoleValue">—</strong></div><div class="glance-box"><span>وضعیت همگام‌سازی</span><strong id="sideSyncValue">آفلاین</strong></div><div class="glance-box"><span>پیام‌های خوانده‌نشده</span><strong id="sideUnreadValue">۰</strong></div><div class="glance-box"><span>حریم خصوصی</span><strong>حذف خودکار ۴ ساعته</strong></div></div><div class="room-glance-note">چت داخل خود پلیر قرار گرفته است. هنگام دریافت پیام، اعلان روی تصویر نمایش داده می‌شود و با دکمه دایره‌ای می‌توانی همان‌جا پاسخ بدهی.</div></div></section>
    </aside>
  </div>
  <section id="watchPartyFaq" class="wp-faq-section">
    <div class="wp-faq-head"><div><span class="wp-faq-kicker">BANKMOVIE HELP CENTER</span><h2>سوالات متداول تماشای دونفره</h2><p>راهنمای سریع ورود همراه، لینک مستقیم، زیرنویس، همگام‌سازی، چت و حریم خصوصی اتاق.</p></div><span class="wp-faq-badge">WATCH GUIDE</span></div>
    <div class="wp-faq-grid">
      <details class="wp-faq-item" open><summary>آیا همراه هم باید ثبت‌نام یا VIP داشته باشد؟<span>+</span></summary><div class="wp-faq-answer">خیر. فقط سازنده اتاق باید اشتراک VIP فعال داشته باشد. نفر دوم با همان لینک دعوت، بدون ثبت‌نام و بدون خرید اشتراک وارد اتاق می‌شود و می‌تواند فیلم را همگام ببیند و داخل پلیر چت کند.</div></details>
      <details class="wp-faq-item"><summary>چطور لینک فیلم را برای همراه ارسال کنم؟<span>+</span></summary><div class="wp-faq-answer">بعد از ساخت اتاق، «تنظیم اتاق» را باز کن، لینک مستقیم ویدئو را وارد و «بارگذاری و ارسال» را بزن. فایل ویدئو روی بانک مووی آپلود نمی‌شود و فقط همان لینک تا پایان اتاق نگه‌داری می‌شود.</div></details>
      <details class="wp-faq-item"><summary>چطور زیرنویس را از سابکده پیدا و اضافه کنم؟<span>+</span></summary><div class="wp-faq-answer">در پلیر روی تنظیمات بزن و وارد «زیرنویس دستی» شو. نام انگلیسی فیلم یا سریال به‌همراه سال را در بخش سابکده جستجو کن. فایل ZIP را دانلود و Extract کن، سپس فایل با پسوند SRT، VTT، ASS یا SSA را از «انتخاب فایل زیرنویس» وارد پلیر کن.</div></details>
      <details class="wp-faq-item"><summary>زیرنویس در اتاق چطور بارگذاری می‌شود؟<span>+</span></summary><div class="wp-faq-answer">اگر لینک پخش از صفحه فیلم بانک مووی دارای زیرنویس جدا باشد، زیرنویس همراه ویدئو برای میزبان و مهمان خودکار باز می‌شود. فایل دستی همچنان قابل انتخاب است و اندازه، موقعیت، رنگ و تأخیر روی هر دستگاه مستقل می‌ماند.</div></details>
      <details class="wp-faq-item"><summary>چرا بعضی لینک‌های مستقیم پخش نمی‌شوند؟<span>+</span></summary><div class="wp-faq-answer">لینک باید مستقیم و قابل پخش در مرورگر باشد و سرور مقصد از HTTPS، Range Request و فرمت/کدک سازگار پشتیبانی کند. لینک صفحه دانلود یا لینک منقضی‌شده داخل پلیر باز نمی‌شود.</div></details>
      <details class="wp-faq-item"><summary>Play، Pause و عقب‌وجلو دست چه کسی است؟<span>+</span></summary><div class="wp-faq-answer">کنترل اصلی با میزبان است. مهمان بعد از یک بار لمس دکمه فعال‌سازی، به‌صورت خودکار با زمان میزبان همگام می‌شود. صدا، روشنایی، حالت تصویر و زیرنویس هر دستگاه مستقل باقی می‌مانند.</div></details>
      <details class="wp-faq-item"><summary>چرا مرورگر از من می‌خواهد یک بار روی پخش بزنم؟<span>+</span></summary><div class="wp-faq-answer">مرورگرهای موبایل و دسکتاپ پخش خودکار صدادار را مسدود می‌کنند. این لمس فقط یک بار برای فعال شدن مجوز صوت لازم است و بعد از آن فرمان‌های میزبان خودکار اجرا می‌شوند.</div></details>
      <details class="wp-faq-item"><summary>پیام‌ها و لینک فیلم چه زمانی حذف می‌شوند؟<span>+</span></summary><div class="wp-faq-answer">اتاق حداکثر چهار ساعت اعتبار دارد. پس از پایان زمان، لینک ویدئو، پیام‌ها، اعضا، وضعیت پخش و رویدادهای همگام‌سازی اتاق حذف می‌شوند و کد دعوت دیگر قابل استفاده نیست.</div></details>
      <details class="wp-faq-item"><summary>برای بهترین همگام‌سازی چه کار کنم؟<span>+</span></summary><div class="wp-faq-answer">هر دو نفر از یک لینک و کیفیت استفاده کنند، اینترنت پایدار داشته باشند، تب مرورگر را در حالت Sleep نگذارند و کنترل‌های Play و Seek را فقط میزبان انجام دهد.</div></details>
    </div>
  </section>

</main>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>
<div id="toolBackdrop" class="tool-backdrop"></div>
<aside id="roomToolsPanel" class="room-tools">
  <div class="tools-head"><h2>تنظیمات اتاق</h2><button id="closeToolsBtn" class="close-circle" type="button"><svg viewBox="0 0 24 24"><path d="M18 6L6 18M6 6l12 12"/></svg></button></div>
  <div class="tools-body">
    <section id="roomAppearanceSection" class="tool-section room-appearance-section">
      <div class="tool-section-title"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="9"/><path d="M8 12h8M12 8v8"/></svg></span><span><h3>تم و پس‌زمینه اتاق</h3><small>همه ظاهرها یکجا؛ انتخاب مشترک Watch Party و چت · ویژه VIP</small></span></div>
      <div id="roomBackgroundGrid" class="bm-room-background-grid">
        <?php foreach($watchPartyBackgroundCatalog as $bgKey => $bgMeta): ?>
          <button type="button" class="bm-room-background-option <?= $watchPartyUserBackground === $bgKey ? 'active' : '' ?>" data-room-background="<?= htmlspecialchars((string)$bgKey, ENT_QUOTES, 'UTF-8') ?>" aria-pressed="<?= $watchPartyUserBackground === $bgKey ? 'true' : 'false' ?>">
            <span class="bm-background-preview" data-bg="<?= htmlspecialchars((string)$bgKey, ENT_QUOTES, 'UTF-8') ?>"></span>
            <span class="bm-background-name"><?= htmlspecialchars((string)($bgMeta['name'] ?? $bgKey), ENT_QUOTES, 'UTF-8') ?></span>
          </button>
        <?php endforeach; ?>
      </div>
      <p class="privacy-note">همه تم‌ها و پس‌زمینه‌ها در همین بخش قرار دارند. فقط میزبان VIP می‌تواند انتخاب را تغییر دهد و همان انتخاب روی صفحه اتاق و چت هر دو نفر همگام می‌شود.</p>
    </section>
    <section id="hostOnlySource" class="tool-section direct-source-only"><div class="tool-section-title"><span class="setting-icon"><svg viewBox="0 0 24 24" fill="none"><path d="M10 13a5 5 0 0 0 7.5.5l3-3a5 5 0 0 0-7-7l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.5-.5l-3 3a5 5 0 0 0 7 7l1.7-1.7"/></svg></span><span><h3>لینک مستقیم ویدئو</h3><small>روش فعال بارگذاری ویدئو</small></span></div><label class="field">آدرس مستقیم فایل ویدئو<input id="videoUrl" class="input" type="url" inputmode="url" autocomplete="off" placeholder="https://cdn.example.com/movie.mp4"></label><div class="tool-actions"><button id="loadUrlBtn" class="btn primary direct-publish-btn" type="button"><svg viewBox="0 0 24 24"><path d="M5 12h14M13 6l6 6-6 6"/></svg>بارگذاری و ارسال برای اتاق</button></div><p class="privacy-note">فایل روی بانک مووی آپلود نمی‌شود. لینک فقط داخل همین اتاق نگه‌داری می‌شود و پس از پایان یا حذف اتاق پاک خواهد شد.</p></section>
  </div>
</aside>
<script>
window.BM_WP_STICKER_PACKS = <?= json_encode(array_map(static fn($pack)=>[
  'label'=>$pack['label']??'', 'path'=>$pack['path']??'', 'extensions'=>$pack['extensions']??[]
], $bmWatchPartyStickerCatalog), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
window.BM_WP_STICKERS = <?= json_encode(array_map(static fn($pack)=>$pack['items']??[], $bmWatchPartyStickerCatalog), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<script>
(() => {
  'use strict';
  const API = '/watch_party_api.php';
  const CSRF = <?= json_encode($csrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const CURRENT_USER_ID = <?= (int)$user['id'] ?>;
  const CURRENT_USER_NAME = <?= json_encode((string)($user['username'] ?? 'شما'), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const CURRENT_USER_AVATAR = <?= json_encode(bm_user_avatar_url((string)($user['avatar'] ?? '')), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const CURRENT_USER_AVATAR_FRAME = <?= json_encode(function_exists('bm_user_avatar_frame_resolve') ? bm_user_avatar_frame_resolve($user) : 'none', JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const IS_ANONYMOUS_COMPANION = <?= $isAnonymousCompanion ? 'true' : 'false' ?>;
  const INITIAL_ROOM = <?= json_encode($roomFromUrl, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const ACCESS_READY = <?= $accessReady ? 'true' : 'false' ?>;
  const CAN_CREATE = <?= $canCreate ? 'true' : 'false' ?>;
  const USER_BACKGROUND = <?= json_encode($watchPartyUserBackground, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const ROOM_BACKGROUND_KEYS = <?= json_encode(array_values(array_keys($watchPartyBackgroundCatalog)), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
  const STICKER_PACKS = Object.keys(window.BM_WP_STICKERS || {});
  const STICKER_MAPS = Object.fromEntries(STICKER_PACKS.map(pack => {
    const stickers = Array.isArray(window.BM_WP_STICKERS?.[pack]) ? window.BM_WP_STICKERS[pack] : [];
    return [pack, new Map(stickers.map(sticker => [String(sticker.id || '').toLowerCase(), sticker]))];
  }));
  const STICKER_MESSAGE_RE = /^\[bm-sticker:([a-z0-9_-]{1,40}):([a-f0-9]{24})\]$/i;
  const $ = id => document.getElementById(id);
  const state = {
    roomCode:'',role:'',expiresAt:'',expiresEpoch:0,expiryAnchorSeconds:0,expiryAnchorClientMs:0,expiryFinalizing:false,lastEventId:0,lastMessageId:0,
    pollTimer:null,stateTimer:null,countdownTimer:null,applying:false,
    userActivated:false,inviteUrl:'',lastSequence:0,lastAppliedSequence:0,polling:false,
    loadedSharedUrl:'',sharedSubtitleUrl:'',loadedSubtitleUrl:'',subtitleSource:'',subtitleFetchToken:0,remoteState:null,remoteServerNowMs:0,remoteReceivedClientMs:0,
    controlQueue:Promise.resolve(),controlBusy:false,pendingHeartbeat:null,
    remoteQueue:Promise.resolve(),remoteGeneration:0,desiredPaused:true,
    lastSyncLogAt:0,lastSyncLogSequence:0,lastHostAction:'',lastHostActionAt:0,
    lastHostActionTime:-1,hostSeeking:false,lastDriftCheckAt:0,
    chatOpen:false,chatUnread:0,chatPrimed:false,chatPreviewTimer:null,chatSoundEnabled:true,roomBackground:USER_BACKGROUND||'simple',
    basePlaybackRate:1,pictureMode:'fit',brightness:1,subtitleCues:[],subtitleEnabled:true,
    subtitleDelay:0,subtitleColor:'#ffffff',subtitleScale:1,subtitleBottom:56,subtitleBackground:.42,subtitleActiveIndex:-1,
    sleepTimer:null,sleepEndsAt:0,theatreMode:false,screenLocked:false,controlsTimer:null,
    lastMediaProgressAt:Date.now(),lastMediaTime:0,stallStartedAt:0,stallTimer:null,
    stallAttempts:0,lastStallRecoveryAt:0,lastHardSeekAt:0,sourceReloading:false,
    pendingResumeTarget:0,lastPollSuccessAt:0,pollFailureCount:0,
    messageQueue:[],messageSending:false,messageRetryTimer:null,messageQueueRoom:'',messageQueueLoaded:false,lastMessageSendAt:0,
    lastMediaNotice:'',lastMediaNoticeAt:0
  };
  const video = $('video');
  const chatPanelHome = $('playerChatPanel').parentNode;
  const chatPanelAnchor = $('playerSettings');

  function log(message, data){
    if(window.console && console.debug)console.debug('[WatchParty]',message,data ?? '');
  }
  function flash(message, kind='ok'){
    const stack=$('toastStack');
    if(!stack)return;
    const el=document.createElement('div');
    el.className='toast '+(kind==='error'?'error':'ok');
    el.innerHTML=`<span class="toast-icon">${kind==='error'?'!':'✓'}</span><span></span>`;
    el.lastElementChild.textContent=message;
    stack.appendChild(el);
    requestAnimationFrame(()=>el.classList.add('show'));
    setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),240);},4300);
  }
  function mediaNotice(message, kind='error'){
    const now=Date.now();
    if(state.lastMediaNotice===message && now-state.lastMediaNoticeAt<5000)return;
    state.lastMediaNotice=message;state.lastMediaNoticeAt=now;
    flash(message,kind);
  }
  function sourceExtension(value){
    try{return (new URL(String(value||''),location.href).pathname.split('.').pop()||'').toLowerCase();}catch(e){return '';}
  }
  function likelyMobileContainerMismatch(value){
    const ext=sourceExtension(value);
    return isMobilePlaybackDevice() && (ext==='mkv'||ext==='avi');
  }
  function mediaPlayErrorMessage(error){
    const name=String(error?.name||'');
    if(name==='NotAllowedError')return 'برای شروع پخش یک بار روی دکمه پخش داخل پلیر بزن.';
    // بعضی مرورگرهای موبایل هنگام تعویض/بارگذاری منبع، موقتاً NotSupportedError می‌دهند
    // و چند لحظه بعد همان فایل را پخش می‌کنند. پس از روی پسوند فایل درباره پشتیبانی قضاوت نکن.
    if(name==='NotSupportedError')return 'ویدئو هنوز آماده پخش نشده؛ چند لحظه بعد دوباره دکمه پخش را بزن.';
    if(name==='AbortError')return 'بارگذاری ویدئو هنوز کامل نشده؛ چند لحظه صبر کن و دوباره پخش را بزن.';
    return 'پخش شروع نشد؛ یک بار روی دکمه پخش داخل پلیر بزن.';
  }
  function messageQueueStorageKey(roomCode){
    const identity=IS_ANONYMOUS_COMPANION?'guest':'u'+CURRENT_USER_ID;
    return 'bm_wp_msgq_v1_'+identity+'_'+String(roomCode||'').replace(/[^A-Za-z0-9_-]/g,'').slice(0,80);
  }
  function makeClientMessageId(){
    try{
      if(crypto?.randomUUID)return 'bm'+crypto.randomUUID().replace(/-/g,'');
      const bytes=new Uint8Array(16);crypto.getRandomValues(bytes);return 'bm'+Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
    }catch(e){return 'bm'+Date.now().toString(36)+Math.random().toString(36).slice(2,18);}
  }
  function saveMessageQueue(){
    if(!state.messageQueueRoom)return;
    const keep=state.messageQueue.filter(x=>x&&x.status!=='delivered').slice(-60);
    state.messageQueue=keep;
    try{localStorage.setItem(messageQueueStorageKey(state.messageQueueRoom),JSON.stringify(keep));}catch(e){}
  }
  function loadMessageQueue(roomCode){
    clearTimeout(state.messageRetryTimer);state.messageRetryTimer=null;
    state.messageQueueRoom=String(roomCode||'');state.messageQueueLoaded=true;state.messageSending=false;
    let rows=[];
    try{rows=JSON.parse(localStorage.getItem(messageQueueStorageKey(roomCode))||'[]');}catch(e){rows=[];}
    const cutoff=Date.now()-24*60*60*1000;
    state.messageQueue=(Array.isArray(rows)?rows:[]).filter(x=>x&&x.clientId&&x.message&&Number(x.createdMs||0)>cutoff&&x.status!=='delivered').slice(-60).map(x=>({
      clientId:String(x.clientId),message:String(x.message).slice(0,500),createdMs:Number(x.createdMs)||Date.now(),
      status:x.status==='failed'?'failed':((x.status==='awaiting'&&Number(x.serverId)>0)?'awaiting':'queued'),serverId:Number(x.serverId)||0,attempts:Number(x.attempts)||0,nextRetryAt:0,error:''
    }));
    state.messageQueue.forEach(renderPendingMessage);
    saveMessageQueue();
    setTimeout(drainMessageQueue,80);
  }
  function messageStatusMarkup(status){
    if(status==='delivered')return '<span class="message-delivery delivered" title="تحویل شد" aria-label="تحویل شد"><svg viewBox="0 0 20 18" aria-hidden="true"><path d="M2.6 9.3 6 12.6 11.7 7.1"></path><path d="M8.1 9.8 10.9 12.6 17.4 5.9"></path></svg></span>';
    if(status==='awaiting')return '<span class="message-delivery sent" title="ارسال شد" aria-label="ارسال شد"><svg viewBox="0 0 18 18" aria-hidden="true"><path d="M3.4 9.2 7 12.7 14.6 5.4"></path></svg></span>';
    if(status==='failed')return '<span class="message-delivery failed" title="ارسال نشد؛ برای تلاش دوباره لمس کنید" aria-label="ارسال نشد"><svg viewBox="0 0 18 18" aria-hidden="true"><path d="M9 3.2v6.5"></path><path d="M9 13.7h.01"></path></svg></span>';
    if(status==='queued')return '<span class="message-delivery queued" title="در صف ارسال" aria-label="در صف ارسال"><svg viewBox="0 0 18 18" aria-hidden="true"><circle cx="9" cy="9" r="6.2"></circle><path d="M9 5.2v4.1l2.7 1.7"></path></svg></span>';
    return '<span class="bm-wp-send-spinner" title="در حال ارسال" aria-label="در حال ارسال"></span>';
  }
  function setMessageDeliveryUi(clientId,status){
    const row=document.querySelector('[data-client-message-id="'+CSS.escape(String(clientId||''))+'"]');
    if(!row)return;
    row.dataset.deliveryStatus=status;
    row.classList.toggle('is-pending',status==='queued'||status==='sending');
    row.classList.toggle('is-failed',status==='failed');
    let holder=row.querySelector('.message-delivery-slot');
    if(!holder){holder=document.createElement('span');holder.className='message-delivery-slot';const time=row.querySelector('.message-time');if(time)time.appendChild(holder);}
    holder.innerHTML=messageStatusMarkup(status);
  }
  function renderPendingMessage(entry){
    if(!entry||!entry.clientId||document.querySelector('[data-client-message-id="'+CSS.escape(entry.clientId)+'"]'))return;
    const box=$('messages');if(!box)return;if(box.querySelector('.empty-side'))box.textContent='';
    const row=document.createElement('div');row.className='message-row mine is-pending';row.dataset.clientMessageId=entry.clientId;row.dataset.deliveryStatus=entry.status||'queued';
    const avatar=createAvatarNode('message-avatar',CURRENT_USER_AVATAR,CURRENT_USER_NAME,CURRENT_USER_AVATAR_FRAME);
    const item=document.createElement('div');item.className='message mine';
    const b=document.createElement('b');const author=document.createElement('span');author.textContent='شما';b.appendChild(author);
    const sticker=stickerFromMessage(entry.message);
    const time=document.createElement('small');time.className='message-time';time.textContent=new Date(entry.createdMs||Date.now()).toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
    const statusSlot=document.createElement('span');statusSlot.className='message-delivery-slot';statusSlot.innerHTML=messageStatusMarkup(entry.status||'queued');time.appendChild(statusSlot);
    if(sticker){
      item.classList.add('is-sticker');
      const isImage=String(sticker.media_type||'').toLowerCase()==='image'||/\.(?:webp|png|jpe?g|gif)(?:$|\?)/i.test(String(sticker.url||''));
      let media;if(isImage){media=document.createElement('img');media.className='chat-sticker-webm chat-sticker-image';media.src=String(sticker.url||'');media.alt='استیکر';media.loading='lazy';media.decoding='async';}
      else{media=document.createElement('video');media.className='chat-sticker-webm';media.src=String(sticker.url||'');media.autoplay=true;media.loop=true;media.muted=true;media.playsInline=true;media.preload='metadata';}
      item.append(b,media,time);
    }else{const t=document.createElement('span');t.className='message-text';t.textContent=entry.message;item.append(b,t,time);}
    row.append(avatar,item);box.appendChild(row);box.scrollTop=box.scrollHeight;
    row.addEventListener('click',()=>{if(row.dataset.deliveryStatus==='failed'){const found=state.messageQueue.find(x=>x.clientId===entry.clientId);if(found){found.status='queued';found.error='';found.nextRetryAt=0;setMessageDeliveryUi(found.clientId,'queued');saveMessageQueue();drainMessageQueue();}}});
  }
  function enqueueMessage(message){
    const entry={clientId:makeClientMessageId(),message:String(message||'').slice(0,500),createdMs:Date.now(),status:'queued',serverId:0,attempts:0,nextRetryAt:0,error:''};
    state.messageQueue.push(entry);renderPendingMessage(entry);const localSticker=stickerFromMessage(entry.message);if(localSticker)showPlayerStickerOverlay(localSticker,CURRENT_USER_NAME,true);saveMessageQueue();drainMessageQueue();return entry;
  }
  function isTransientMessageError(error){
    const text=String(error?.message||error||'').toLowerCase();
    return !navigator.onLine || /اتصال|شبکه|network|failed to fetch|fetch|مهلت|timeout|429|زیاد است|دوباره/.test(text);
  }
  function scheduleMessageRetry(delay){
    clearTimeout(state.messageRetryTimer);state.messageRetryTimer=setTimeout(()=>{state.messageRetryTimer=null;drainMessageQueue();},Math.max(250,delay||900));
  }
  async function drainMessageQueue(){
    if(state.messageSending||!state.roomCode||state.messageQueueRoom!==state.roomCode)return;
    const now=Date.now();
    const entry=state.messageQueue.find(x=>x.status==='queued'&&(Number(x.nextRetryAt)||0)<=now);
    if(!entry){const future=state.messageQueue.filter(x=>x.status==='queued').map(x=>Number(x.nextRetryAt)||0).filter(x=>x>now).sort((a,b)=>a-b)[0];if(future)scheduleMessageRetry(future-now);return;}
    if(!navigator.onLine){entry.status='queued';setMessageDeliveryUi(entry.clientId,'queued');saveMessageQueue();return;}
    state.messageSending=true;entry.status='sending';setMessageDeliveryUi(entry.clientId,'sending');saveMessageQueue();
    try{
      const data=await api('message',{room_code:state.roomCode,message:entry.message,client_message_id:entry.clientId});
      entry.serverId=Number(data.chat?.message_id)||entry.serverId||0;entry.status=data.chat?.delivered?'delivered':'awaiting';entry.attempts=0;entry.nextRetryAt=0;entry.error='';
      setMessageDeliveryUi(entry.clientId,entry.status==='delivered'?'delivered':'awaiting');
      if(entry.status==='delivered')state.messageQueue=state.messageQueue.filter(x=>x.clientId!==entry.clientId);
      saveMessageQueue();state.lastMessageSendAt=Date.now();
      // The message is already accepted by the server here. Stop the sending
      // spinner immediately and trigger a quick poll only for delivery/read state.
      if(!state.polling)schedulePoll(90);
    }catch(error){
      entry.attempts=(Number(entry.attempts)||0)+1;entry.error=String(error?.message||'');
      if(isTransientMessageError(error)){
        entry.status='queued';const base=/زیاد است|429/.test(entry.error)?2400:Math.min(12000,700*Math.pow(1.7,Math.min(entry.attempts,6)));entry.nextRetryAt=Date.now()+base+Math.floor(Math.random()*300);setMessageDeliveryUi(entry.clientId,'queued');
      }else{entry.status='failed';entry.nextRetryAt=0;setMessageDeliveryUi(entry.clientId,'failed');flash(entry.error||'ارسال پیام انجام نشد.','error');}
      saveMessageQueue();
    }finally{
      state.messageSending=false;
      const spacing=Math.max(220,650-(Date.now()-state.lastMessageSendAt));scheduleMessageRetry(spacing);
    }
  }
  function reconcileQueuedMessage(serverMessage){
    const clientId=String(serverMessage?.client_message_id||'');if(!clientId)return false;
    const entry=state.messageQueue.find(x=>x.clientId===clientId);
    const row=document.querySelector('[data-client-message-id="'+CSS.escape(clientId)+'"]');
    if(!entry&&!row)return false;
    if(entry){entry.serverId=Number(serverMessage.id)||entry.serverId||0;entry.status=serverMessage.delivered_at?'delivered':'awaiting';entry.nextRetryAt=0;}
    if(row){row.classList.remove('is-pending');const avatar=row.querySelector('.message-avatar');if(avatar)fillAvatarNode(avatar,serverMessage.avatar_url||CURRENT_USER_AVATAR,serverMessage.username||CURRENT_USER_NAME,serverMessage.avatar_frame||CURRENT_USER_AVATAR_FRAME);const time=row.querySelector('.message-time');if(time){const label=messageClock(serverMessage.created_at);if(label&&time.firstChild)time.firstChild.nodeValue=label;}setMessageDeliveryUi(clientId,serverMessage.delivered_at?'delivered':(entry?.status||'awaiting'));}
    if(serverMessage.delivered_at){state.messageQueue=state.messageQueue.filter(x=>x.clientId!==clientId);saveMessageQueue();}
    return true;
  }
  function applyDeliveryReceipt(maxDeliveredId){
    const maxId=Number(maxDeliveredId)||0;if(maxId<=0)return;
    let changed=false;
    state.messageQueue.forEach(entry=>{if(entry.serverId>0&&entry.serverId<=maxId&&entry.status!=='delivered'){entry.status='delivered';setMessageDeliveryUi(entry.clientId,'delivered');changed=true;}});
    if(changed){state.messageQueue=state.messageQueue.filter(x=>x.status!=='delivered');saveMessageQueue();}
  }
  window.addEventListener('online',()=>{state.messageQueue.forEach(x=>{if(x.status==='sending'){x.status='queued';x.nextRetryAt=0;setMessageDeliveryUi(x.clientId,'queued');}});saveMessageQueue();drainMessageQueue();});
  window.addEventListener('offline',()=>{state.messageQueue.forEach(x=>{if(x.status!=='failed')setMessageDeliveryUi(x.clientId,'queued');});});

  function normalizeRoom(value){
    value=(value||'').trim();
    try{ const u=new URL(value,location.origin); const q=u.searchParams.get('room'); if(q) value=q; }catch(e){}
    return value.replace(/[^A-Za-z0-9_-]/g,'');
  }
  function normalizeVideoUrl(value){
    try{const u=new URL((value||'').trim());return (u.protocol==='http:'||u.protocol==='https:')?u.href:'';}catch(e){return '';}
  }
  function subtitleQueryFromUrl(value){
    try{
      const u=new URL(value);let name=decodeURIComponent((u.pathname.split('/').pop()||'').replace(/\.[a-z0-9]{2,5}$/i,''));
      name=name.replace(/[._-]+/g,' ').replace(/\b(2160p|1080p|720p|480p|bluray|brrip|webrip|web dl|webdl|hdrip|x264|x265|h264|h265|hevc|10bit|farsi|dubbed|dual audio|film2media|aac|dts)\b/gi,' ').replace(/\s+/g,' ').trim();
      return name.slice(0,120);
    }catch(e){return '';}
  }
  function prefillSubtitleQueryFromUrl(value){
    const input=$('subkadeQuery');if(!input||input.value.trim())return;const guess=subtitleQueryFromUrl(value);if(guess)input.value=guess;
  }
  function openSubkadeSearch(event){
    if(event)event.preventDefault();const input=$('subkadeQuery');const query=(input?.value||'').trim();
    if(!query){flash('نام انگلیسی فیلم یا سریال را برای جستجوی زیرنویس وارد کن.','error');input?.focus();return;}
    const target='https://subkade.ir/?s='+encodeURIComponent(query);const opened=window.open(target,'_blank','noopener,noreferrer');
    if(!opened)location.href=target;
  }
  function scrollToFaq(){
    closePlayerSettings();const faq=$('watchPartyFaq');if(!faq)return;faq.scrollIntoView({behavior:'smooth',block:'start'});
  }
  async function api(action, payload={}, method='POST'){
    const startedAt=performance.now();
    const controller=typeof AbortController==='function'?new AbortController():null;
    const timeoutMs=action==='poll'?8000:15000;
    const timeoutId=controller?setTimeout(()=>controller.abort(),timeoutMs):null;
    const options={
      method,
      credentials:'same-origin',
      cache:'no-store',
      keepalive:false,
      headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest'}
    };
    if(controller)options.signal=controller.signal;
    let url=API+'?action='+encodeURIComponent(action);
    if(method==='POST'){
      const body=new URLSearchParams();
      body.set('csrf_token',CSRF); body.set('action',action);
      Object.entries(payload).forEach(([k,v])=>body.set(k,String(v ?? '')));
      options.headers['Content-Type']='application/x-www-form-urlencoded;charset=UTF-8';
      options.headers['X-CSRF-Token']=CSRF;
      options.body=body.toString();
    } else {
      const qs=new URLSearchParams(payload);
      qs.set('_ts',String(Date.now()));
      url += '&'+qs.toString();
    }
    try{
      const res=await fetch(url,options);
      let data={}; try{data=await res.json();}catch(e){throw new Error('پاسخ JSON معتبر نیست');}
      data.__rtt_ms=Math.max(0,performance.now()-startedAt);
      if(!res.ok || !data.success){ const base=data.message || data.error || ('HTTP '+res.status); if(data.technical && window.console)console.error('[WatchParty technical]',data.technical); throw new Error(base); }
      return data;
    }catch(error){
      if(error?.name==='AbortError')throw new Error('مهلت ارتباط با اتاق تمام شد؛ اتصال دوباره امتحان می‌شود.');
      throw error;
    }finally{
      if(timeoutId)clearTimeout(timeoutId);
    }
  }
  function normalizeRoomBackground(key){
    key=String(key||'simple').trim();
    return ROOM_BACKGROUND_KEYS.includes(key)?key:'simple';
  }
  function applyRoomBackground(key){
    key=normalizeRoomBackground(key);state.roomBackground=key;
    document.documentElement.dataset.bmBackground=key;
    document.body?.setAttribute('data-room-background',key);
    document.querySelectorAll('[data-room-background]').forEach(btn=>{const on=btn.dataset.roomBackground===key;btn.classList.toggle('active',on);btn.setAttribute('aria-pressed',on?'true':'false');});
    // Keep the portaled/mobile chat on the exact same room wallpaper. The chat
    // panel can move from the player to <body>, so copy the resolved wallpaper
    // variables onto it after every room update.
    const chat=$('playerChatPanel');
    if(chat){
      chat.dataset.roomBackground=key;
      const rootStyle=getComputedStyle(document.documentElement);
      const wallpaper=rootStyle.getPropertyValue('--bm-wallpaper').trim();
      const size=rootStyle.getPropertyValue('--bm-wallpaper-size').trim();
      const position=rootStyle.getPropertyValue('--bm-wallpaper-position').trim();
      if(wallpaper)chat.style.setProperty('--bm-chat-wallpaper',wallpaper);
      if(size)chat.style.setProperty('--bm-chat-wallpaper-size',size);
      if(position)chat.style.setProperty('--bm-chat-wallpaper-position',position);
    }
  }
  async function saveRoomBackground(key){
    key=normalizeRoomBackground(key);
    if(!state.roomCode){flash('اول وارد اتاق شو.','error');return;}
    if(state.role!=='host'){flash('پس‌زمینه اتاق فقط توسط میزبان VIP تغییر می‌کند.','error');return;}
    const grid=$('roomBackgroundGrid');grid?.classList.add('bm-room-background-saving');
    try{const data=await api('room_settings',{room_code:state.roomCode,background_key:key,theme_key:'default'});applyRoomBackground(data.settings?.background_key||key);window.dispatchEvent(new CustomEvent('bm:watch-party-background',{detail:{background_key:data.settings?.background_key||key}}));flash('ظاهر اتاق و چت برای هر دو نفر اعمال شد.');}
    catch(e){flash(e.message||'ذخیره پس‌زمینه انجام نشد.','error');}
    finally{grid?.classList.remove('bm-room-background-saving');}
  }
  function setRoom(code, role, expiresAt, secondsLeft=0, expiresEpoch=0){
    const roomChanged=state.roomCode!==code;
    state.roomCode=code; state.role=role || state.role; state.expiresAt=expiresAt || state.expiresAt;
    // V148.61.9.48: room invite tokens are case-sensitive. Expose the exact active
    // token so auxiliary modules (Voice Beta) never reconstruct or alter its case.
    window.BM_WP_ACTIVE_ROOM_CODE=String(code||'');
    state.expiresEpoch=Math.max(0,Number(expiresEpoch)||state.expiresEpoch||0);
    const serverSeconds=Math.max(0,Number(secondsLeft)||0);
    if(serverSeconds>0){state.expiryAnchorSeconds=serverSeconds;state.expiryAnchorClientMs=Date.now();}
    else if(state.expiresEpoch>0){state.expiryAnchorSeconds=Math.max(0,state.expiresEpoch-Math.floor(Date.now()/1000));state.expiryAnchorClientMs=Date.now();}
    state.expiryFinalizing=false;
    if(roomChanged){state.chatPrimed=false;state.chatUnread=0;updateChatUnread();$('messages').innerHTML='<div class="empty-side">هنوز پیامی ارسال نشده</div>';bmV51ResetChatWindow();loadMessageQueue(code);}
    state.inviteUrl=location.origin+location.pathname+'?room='+encodeURIComponent(code);
    $('roomCodeView').textContent=code || '—'; $('joinCode').value=code || '';
    $('expiresView').textContent=state.expiresAt || '—';
    $('roleBadge').textContent=state.role==='host'?'میزبان':'مهمان';
    $('roleBadge').className='status-pill '+(state.role==='host'?'host':'guest');
    $('sideRoleValue').textContent=state.role==='host'?'میزبان و کنترل‌کننده':'همراه تماشا';
    $('playerRoleText').textContent=state.role==='host'?'میزبان · کنترل پخش':'مهمان · همگام با میزبان';
    document.body.classList.add('room-active');
    $('lobbyPanel')?.classList.add('is-collapsed');
    $('roomStage')?.classList.remove('is-locked');
    $('roomToolsBtn')?.classList.remove('hidden');
    updateControlAccess();
    history.replaceState({},'',location.pathname+'?room='+encodeURIComponent(code));
    startPolling(); startCountdown();
  }
  async function createRoom(){
    if(!ACCESS_READY){flash('قابلیت Watch Party در حال حاضر غیرفعال است.','error');return;}
    if(!CAN_CREATE){flash('ساخت اتاق فقط برای اعضای VIP فعال است؛ با لینک دعوت وارد شو.','error');return;}
    $('createBtn').disabled=true;
    try{
      const data=await api('create',{movie_id:$('movieId').value,archive_no:$('archiveNo').value,media_type:$('mediaType').value,source_ref:$('sourceRef').value});
      setRoom(data.room.invite_code,'host',data.room.expires_at,data.room.seconds_left,data.room.expires_at_epoch);
      applyRoomBackground(data.room.background_key||USER_BACKGROUND||'simple');
      flash('اتاق خصوصی ساخته شد؛ حالا لینک مستقیم ویدئو را وارد کن.'); log('ROOM CREATED',data.room); setTimeout(openTools,180);
    }catch(e){flash(e.message,'error');log('CREATE ERROR',e.message);}finally{$('createBtn').disabled=false;}
  }
  async function joinRoom(raw){
    if(!ACCESS_READY){flash('قابلیت Watch Party در حال حاضر غیرفعال است.','error');return;}
    const code=normalizeRoom(raw || $('joinCode').value);
    if(!code){flash('کد اتاق معتبر نیست.','error');return;}
    $('joinBtn').disabled=true;
    try{
      const data=await api('join',{room_code:code});
      setRoom(code,data.membership.member_role,data.membership.expires_at,data.membership.seconds_left,data.membership.expires_at_epoch);
      flash(data.membership.member_role==='host'?'اتاق میزبان باز شد.':(IS_ANONYMOUS_COMPANION?'به‌عنوان همراه مهمان، رایگان وارد اتاق شدی.':'به اتاق وارد شدی.')); log('ROOM JOINED',data.membership);
      await poll();
    }catch(e){flash(e.message,'error');log('JOIN ERROR',e.message);}finally{$('joinBtn').disabled=false;}
  }
  // Critical room actions are bound before optional player/header enhancements.
  // This keeps room creation working even if a non-essential UI capability is unavailable.
  const earlyCreateBtn=$('createBtn');
  const earlyJoinBtn=$('joinBtn');
  if(earlyCreateBtn) earlyCreateBtn.addEventListener('click',createRoom);
  if(earlyJoinBtn) earlyJoinBtn.addEventListener('click',()=>joinRoom($('joinCode')?.value||''));

  // Invite links must be recognized before any optional player/header enhancement runs.
  // A failure in a secondary UI feature must never prevent a guest from joining the room.
  if(INITIAL_ROOM){
    $('joinCode').value=INITIAL_ROOM;
    Promise.resolve().then(()=>joinRoom(INITIAL_ROOM));
  } else if(!ACCESS_READY){
    log('WATCH PARTY DISABLED');
  }

  function nextPollDelay(){
    // Polling faster than the media connection can repeatedly steal mobile browser
    // connection slots from the video range request. One-second sync is still fast,
    // while keeping the guest stream stable for long sessions.
    if(document.hidden)return 2200;
    if(state.role==='host')return 1250;
    return state.remoteState && !state.remoteState.paused ? 900 : 1400;
  }
  function schedulePoll(delay=nextPollDelay()){
    clearTimeout(state.pollTimer);
    if(!state.roomCode)return;
    state.pollTimer=setTimeout(poll,delay);
  }
  function startPolling(){
    clearTimeout(state.pollTimer); state.lastEventId=0; state.lastMessageId=0;
    state.lastAppliedSequence=0; state.remoteGeneration=0;
    poll();
    clearInterval(state.stateTimer);
    state.stateTimer=setInterval(()=>{
      if(state.role==='host' && !video.paused && video.src)sendControl('state');
      if(state.role!=='host' && state.userActivated && state.remoteState && !state.remoteState.paused){
        const now=Date.now();
        if(now-state.lastDriftCheckAt>=5000){
          state.lastDriftCheckAt=now;
          queueRemoteState(state.remoteState,currentEstimatedServerMs(),false,'drift');
        }
      }
    },4000);
    startGuestPlaybackWatchdog();
  }
  function currentEstimatedServerMs(){
    if(!state.remoteServerNowMs)return Date.now();
    return state.remoteServerNowMs + Math.max(0,Date.now()-state.remoteReceivedClientMs);
  }
  function estimatedRemoteTarget(remote=state.remoteState,serverNowMs=currentEstimatedServerMs()){
    if(!remote)return Math.max(0,Number(video.currentTime)||0);
    const paused=Boolean(remote.paused);
    const buffering=Boolean(remote.buffering);
    const rate=Math.max(.5,Math.min(2,Number(remote.playback_rate)||1));
    const base=Math.max(0,Number(remote.current_time)||0);
    const updatedAtMs=Math.max(0,Number(remote.updated_at_ms)||0);
    const elapsed=(!paused&&!buffering&&updatedAtMs>0)?Math.max(0,(Number(serverNowMs)-updatedAtMs)/1000)*rate:0;
    let target=base+elapsed;
    if(Number.isFinite(video.duration)&&video.duration>0)target=Math.min(target,Math.max(0,video.duration-.05));
    return Math.max(0,target);
  }
  function bufferedAheadAt(time=Number(video.currentTime)||0){
    try{
      for(let i=0;i<video.buffered.length;i++){
        const start=video.buffered.start(i),end=video.buffered.end(i);
        if(time>=start-.08&&time<=end+.08)return Math.max(0,end-time);
      }
    }catch(e){}
    return 0;
  }
  function isTimeBuffered(time){
    try{
      for(let i=0;i<video.buffered.length;i++){
        if(time>=video.buffered.start(i)-.12&&time<=video.buffered.end(i)-.08)return true;
      }
    }catch(e){}
    return false;
  }
  function markMediaProgress(force=false){
    const now=Date.now();
    const current=Number(video.currentTime)||0;
    const moved=Math.abs(current-state.lastMediaTime)>.12;
    if(force||moved){
      state.lastMediaTime=current;
      state.lastMediaProgressAt=now;
      state.stallStartedAt=0;
      state.stallAttempts=0;
      if(video.readyState>=3)$('partyBuffering').classList.remove('show');
    }
  }
  async function reloadGuestMedia(target){
    if(state.sourceReloading||state.role==='host'||!state.userActivated)return;
    const src=state.loadedSharedUrl||video.currentSrc||video.src;
    if(!src)return;
    state.sourceReloading=true;
    state.pendingResumeTarget=Math.max(0,Number(target)||Number(video.currentTime)||0);
    const muted=video.muted,volume=video.volume;
    log('GUEST SOURCE RECONNECT',{target:Number(state.pendingResumeTarget.toFixed(3)),networkState:video.networkState,readyState:video.readyState});
    $('syncBadge').innerHTML='<span class="dot"></span> بازیابی پخش همراه';
    $('partyBuffering').classList.add('show');
    const finish=()=>{state.sourceReloading=false;state.lastMediaProgressAt=Date.now();};
    const onMeta=()=>{
      const resume=estimatedRemoteTarget(state.remoteState,currentEstimatedServerMs())||state.pendingResumeTarget;
      try{video.currentTime=Math.max(0,resume-.18);}catch(e){}
      video.muted=muted;video.volume=volume;video.playbackRate=state.basePlaybackRate||1;
    };
    const onCanPlay=async()=>{
      try{if(!state.desiredPaused)await video.play();}catch(e){log('GUEST RECONNECT PLAY BLOCKED',e?.message||'blocked');}
      finish();
    };
    video.addEventListener('loadedmetadata',onMeta,{once:true});
    video.addEventListener('canplay',onCanPlay,{once:true});
    try{
      video.pause();
      video.src=src;
      video.load();
    }catch(e){finish();log('GUEST SOURCE RECONNECT ERROR',e?.message||e);}
    setTimeout(()=>{if(state.sourceReloading)finish();},14000);
  }
  async function checkGuestPlaybackHealth(){
    if(state.role==='host'||!state.roomCode||!video.src||!state.userActivated||state.desiredPaused||state.remoteState?.paused||video.ended||document.hidden){
      state.stallStartedAt=0;state.lastMediaTime=Number(video.currentTime)||0;state.lastMediaProgressAt=Date.now();return;
    }
    const now=Date.now();
    const current=Number(video.currentTime)||0;
    if(Math.abs(current-state.lastMediaTime)>.12){markMediaProgress(true);return;}
    const stalledFor=now-state.lastMediaProgressAt;
    if(stalledFor<6500)return;
    if(!state.stallStartedAt)state.stallStartedAt=state.lastMediaProgressAt;
    if(now-state.lastStallRecoveryAt<4500)return;
    state.lastStallRecoveryAt=now;state.stallAttempts++;
    const target=estimatedRemoteTarget();
    const ahead=bufferedAheadAt(current);
    log('GUEST STALL CHECK',{stalledFor,attempt:state.stallAttempts,current:Number(current.toFixed(3)),target:Number(target.toFixed(3)),bufferedAhead:Number(ahead.toFixed(2)),readyState:video.readyState,networkState:video.networkState});
    $('partyBuffering').classList.add('show');
    if(video.paused&&!state.desiredPaused){try{await video.play();}catch(e){}}
    // Prefer the already buffered data. Repeated seeks create a new HTTP Range
    // request and were the main cause of the guest freezing after a few minutes.
    if(stalledFor>=10000&&isTimeBuffered(target)&&Math.abs(target-current)>1.2){
      try{video.currentTime=Math.max(0,target-.12);state.lastHardSeekAt=now;}catch(e){}
      try{if(!state.desiredPaused)await video.play();}catch(e){}
      return;
    }
    if(stalledFor>=16000&&state.stallAttempts>=3&&now-state.lastStallRecoveryAt>=0){
      await reloadGuestMedia(target);
    }
  }
  function startGuestPlaybackWatchdog(){
    clearInterval(state.stallTimer);
    state.lastMediaTime=Number(video.currentTime)||0;
    state.lastMediaProgressAt=Date.now();
    state.stallTimer=setInterval(checkGuestPlaybackHealth,2000);
  }
  function applyRuntimeFeatureFlags(data){
    const chatEnabled=data?.chat_enabled!==false;
    const chatBtn=$('playerChatBtn');
    const chatPanel=$('playerChatPanel');
    const chatSound=$('chatSoundSettingRow');
    if(chatBtn){chatBtn.style.setProperty('display',chatEnabled?'':'none',chatEnabled?'':'important');if(chatEnabled)chatBtn.style.removeProperty('display');}
    if(chatPanel){if(chatEnabled)chatPanel.style.removeProperty('display');else chatPanel.style.setProperty('display','none','important');}
    if(chatSound){if(chatEnabled)chatSound.style.removeProperty('display');else chatSound.style.setProperty('display','none','important');}
    if(!chatEnabled){state.chatUnread=0;updateChatUnread();$('chatPreviewToast')?.classList.remove('show');if(state.chatOpen)closePlayerChat();}
  }
  async function poll(){
    if(!state.roomCode || state.polling){schedulePoll();return;}
    state.polling=true;
    try{
      const data=await api('poll',{room_code:state.roomCode,after_event_id:state.lastEventId,after_message_id:state.lastMessageId,after_voice_signal_id:Math.max(0,Number(window.BM_WP_VOICE_AFTER_SIGNAL_ID||0))},'GET');
      applyRuntimeFeatureFlags(data);
      window.dispatchEvent(new CustomEvent('bm:watch-party-poll',{detail:data}));
      state.lastPollSuccessAt=Date.now();state.pollFailureCount=0;
      $('sideSyncValue').textContent='متصل';
      state.expiresAt=data.room.expires_at || state.expiresAt; state.expiresEpoch=Math.max(0,Number(data.room.expires_at_epoch)||state.expiresEpoch||0); state.expiryAnchorSeconds=Math.max(0,Number(data.room.seconds_left)||0); state.expiryAnchorClientMs=Date.now(); $('expiresView').textContent=state.expiresAt;
      applyRoomBackground(data.room?.background_key||'simple');
      const me=(data.members||[]).find(m=>Number(m.user_id)===CURRENT_USER_ID); if(me && me.member_role!==state.role){state.role=me.member_role;setRoom(state.roomCode,state.role,state.expiresAt,state.expiryAnchorSeconds,state.expiresEpoch);}
      renderMembers(data.members||[],data.room.max_members||2);
      renderMessages(data.messages||[],state.chatPrimed);
      applyDeliveryReceipt(data.my_delivered_through_id||0);
      state.chatPrimed=true;
      const actionEvents=data.events||[];
      for(const ev of actionEvents) state.lastEventId=Math.max(state.lastEventId,Number(ev.id)||0);
      for(const msg of (data.messages||[])) state.lastMessageId=Math.max(state.lastMessageId,Number(msg.id)||0);
      syncSharedSource(data.room?.shared_source_url||'');
      syncSharedSubtitle(data.room?.shared_subtitle_url||'');
      const incomingState=data.state||{};
      const previousState=state.remoteState;
      const sequence=Number(incomingState.sequence_no||0);
      const latestAction=[...actionEvents].reverse().find(ev=>['play','pause','seek','source_change'].includes(String(ev.event_type||'')));
      const actionName=latestAction?String(latestAction.event_type||'state'):'state';
      const explicitTimelineChange=Boolean(latestAction && ['seek','pause','play','source_change'].includes(actionName));
      const backwardHeartbeat=Boolean(
        !explicitTimelineChange && previousState && !previousState.paused && !incomingState.paused &&
        Number(incomingState.current_time||0) < Number(previousState.current_time||0)-0.75
      );
      if(!backwardHeartbeat){
        state.remoteState=incomingState;
      }else if(Date.now()-state.lastSyncLogAt>1500){
        log('STALE HEARTBEAT IGNORED',{sequence,from:Number(previousState.current_time||0),to:Number(incomingState.current_time||0)});
        state.lastSyncLogAt=Date.now();
      }
      const halfRtt=Math.min(1000,Math.max(0,Number(data.__rtt_ms)||0)/2);
      state.remoteServerNowMs=(Number(data.server_time_ms)||Date.now())+halfRtt;
      state.remoteReceivedClientMs=Date.now();
      const forceSync=Boolean(latestAction && Number(latestAction.sequence_no||0)>state.lastAppliedSequence);
      if(state.role!=='host' && !backwardHeartbeat && (sequence>state.lastAppliedSequence || forceSync)){
        state.lastAppliedSequence=Math.max(state.lastAppliedSequence,sequence,Number(latestAction?.sequence_no||0));
        queueRemoteState(state.remoteState,currentEstimatedServerMs(),forceSync,actionName);
      }else if(state.role==='host'){
        $('syncBadge').innerHTML='<span class="dot on"></span> متصل'; $('sideSyncValue').textContent='متصل';
      }
      state.lastSequence=sequence || state.lastSequence;
    }catch(e){
      state.pollFailureCount++;
      if(state.pollFailureCount>=3){$('syncBadge').innerHTML='<span class="dot"></span> در حال اتصال مجدد';$('sideSyncValue').textContent='اتصال مجدد';}
      log('POLL ERROR',{message:e.message,failures:state.pollFailureCount});
      if(/زمان ۴ ساعته اتاق واقعاً تمام شده|room_expired/.test(e.message)){
        stopRoom(true);
        flash('۴ ساعت اتاق تمام شد؛ لینک، پیام‌ها و داده‌های اتاق حذف شدند.','error');
      }else if(/اتاق پیدا نشد|room_not_found/.test(e.message)){
        stopRoom(true);
        flash('اتاق پیدا نشد؛ این پیام دیگر به‌عنوان پایان ۴ ساعته نمایش داده نمی‌شود.','error');
      }
    }
    finally{state.polling=false;schedulePoll(state.pollFailureCount?Math.min(3000,800+state.pollFailureCount*450):nextPollDelay());}
  }
  function queueRemoteState(remote,serverNowMs,force=false,reason='state'){
    if(state.role==='host')return Promise.resolve();
    const generation=++state.remoteGeneration;
    const snapshot={...remote};
    state.remoteQueue=state.remoteQueue.catch(()=>null).then(()=>applyRemoteState(snapshot,serverNowMs,force,reason,generation));
    return state.remoteQueue;
  }
  function syncSharedSource(rawUrl){
    const url=normalizeVideoUrl(rawUrl);
    if(!url || state.loadedSharedUrl===url)return;
    $('videoUrl').value=url;
    loadVideoSource(url,true);
    if(state.role!=='host') flash('لینک ویدئو از میزبان دریافت و داخل پلیر بارگذاری شد. حالا روی «آماده‌ام» بزن.');
    log('REMOTE VIDEO SOURCE RECEIVED',url);
  }
  async function applyRemoteState(remote,serverNowMs=Date.now(),force=false,reason='state',generation=state.remoteGeneration){
    if(generation!==state.remoteGeneration||!video.src||!remote||video.readyState<1)return;
    const paused=Boolean(remote.paused);
    const buffering=Boolean(remote.buffering);
    const rate=Math.max(.5,Math.min(2,Number(remote.playback_rate)||1));
    state.basePlaybackRate=rate;updateSettingsSummary();
    const target=estimatedRemoteTarget(remote,serverNowMs);
    const local=Number(video.currentTime)||0;
    const diff=target-local;
    const absDiff=Math.abs(diff);
    const now=Date.now();
    const mediaUnstable=video.readyState<3||state.stallStartedAt>0||state.sourceReloading;
    const explicitAction=force&&['play','pause','seek','source_change','metadata','activate'].includes(String(reason));
    state.desiredPaused=paused;
    state.applying=true;
    try{
      if(paused){
        if(!video.paused)video.pause();
        video.playbackRate=rate;
        if((explicitAction&&absDiff>.18)||absDiff>1.25){
          try{video.currentTime=target;state.lastHardSeekAt=now;}catch(e){}
        }
      }else if(!state.userActivated){
        if(absDiff>.25&&video.readyState>=2){try{video.currentTime=target;}catch(e){}}
        video.playbackRate=rate;
        $('syncBadge').innerHTML='<span class="dot"></span> یک‌بار «آماده‌ام» را بزن';
      }else{
        let hardSeek=false;
        if(!mediaUnstable){
          if(explicitAction&&absDiff>.32)hardSeek=true;
          else if(!force&&absDiff>4.5&&now-state.lastHardSeekAt>15000)hardSeek=true;
        }
        if(hardSeek){
          try{video.currentTime=target;state.lastHardSeekAt=now;}catch(e){}
          video.playbackRate=rate;
        }else if(mediaUnstable){
          // While the guest is buffering, preserve the current HTTP range request.
          // Seeking here repeatedly was exhausting the media connection and leaving
          // the guest spinner stuck while the host continued normally.
          video.playbackRate=rate;
        }else if(absDiff>.28){
          const correction=absDiff>1.8?.055:.03;
          video.playbackRate=diff>0?Math.min(1.08,rate+correction):Math.max(.92,rate-correction);
        }else{
          video.playbackRate=rate;
        }
        if(video.paused&&generation===state.remoteGeneration&&!state.desiredPaused&&!state.sourceReloading){
          try{
            await video.play();
          }catch(err){
            if(generation===state.remoteGeneration&&!state.desiredPaused){
              $('syncBadge').innerHTML='<span class="dot"></span> لمس «آماده‌ام»';
              log('AUTOPLAY BLOCKED',err?.message||'browser policy');
            }
          }
        }
      }
      if(generation!==state.remoteGeneration)return;
      if(state.userActivated){
        const shown=Math.min(9.99,Math.abs(target-(Number(video.currentTime)||0))).toFixed(2);
        $('syncBadge').innerHTML=buffering
          ? '<span class="dot"></span> میزبان در حال بافر'
          : mediaUnstable
            ? '<span class="dot"></span> در حال پایدارسازی پخش'
            : `<span class="dot on"></span> همگام ±${shown}ث`;
      }
      const seq=Number(remote.sequence_no||0);
      const shouldLog=force||reason!=='drift'||absDiff>.9||seq!==state.lastSyncLogSequence;
      if(shouldLog&&Date.now()-state.lastSyncLogAt>900){
        log('SYNC',{reason,sequence:seq,target:Number(target.toFixed(3)),local:Number((Number(video.currentTime)||0).toFixed(3)),diff:Number(diff.toFixed(3)),paused,buffering,mediaUnstable,hardSeekAt:state.lastHardSeekAt});
        state.lastSyncLogAt=Date.now();state.lastSyncLogSequence=seq;
      }
    }finally{
      setTimeout(()=>{if(generation===state.remoteGeneration)state.applying=false;},180);
    }
  }
  function captureControlSnapshot(event,extra={}){
    return {
      room_code:state.roomCode,
      event,
      current_time:Number(video.currentTime)||0,
      paused:video.paused?1:0,
      playback_rate:Number(video.playbackRate)||1,
      buffering:0,
      source_ref:$('sourceRef').value,
      source_url:extra.source_url||'',
      subtitle_url:extra.subtitle_url||''
    };
  }
  function isDuplicateHostAction(event,snapshot){
    if(event==='state')return false;
    const now=Date.now();
    const sameEvent=state.lastHostAction===event;
    const sameTime=Math.abs((state.lastHostActionTime||0)-snapshot.current_time)<.08;
    if(sameEvent && sameTime && now-state.lastHostActionAt<450)return true;
    state.lastHostAction=event; state.lastHostActionAt=now; state.lastHostActionTime=snapshot.current_time;
    return false;
  }
  function sendControl(event, extra={}){
    if(!state.roomCode || state.role!=='host' || state.applying)return Promise.resolve(null);
    const snapshot=captureControlSnapshot(event,extra);
    if(isDuplicateHostAction(event,snapshot))return Promise.resolve(null);
    if(event==='state' && state.controlBusy){
      state.pendingHeartbeat=snapshot;
      return Promise.resolve(null);
    }
    const run=async(payload)=>{
      state.controlBusy=true;
      try{
        const data=await api('control',payload);
        state.lastSequence=Number(data.state?.sequence_no||state.lastSequence);
        if(payload.event!=='state')log('CONTROL '+payload.event,{time:Number(payload.current_time.toFixed(3)),sequence:state.lastSequence});
        return data;
      }catch(e){log('CONTROL ERROR',e.message);throw e;}
      finally{
        state.controlBusy=false;
        if(state.pendingHeartbeat && state.roomCode && state.role==='host'){
          const pending=state.pendingHeartbeat; state.pendingHeartbeat=null;
          setTimeout(()=>sendControl('state'),30);
        }
      }
    };
    state.controlQueue=state.controlQueue.catch(()=>null).then(()=>run(snapshot));
    return state.controlQueue;
  }
  function fillAvatarNode(node,url,name,frame='none'){
    node.textContent='';
    const allowedFrames=['none','gold_glow','purple_glow','rainbow','starlight','light_flow'];
    node.dataset.bmFrame=allowedFrames.includes(String(frame||''))?String(frame):'none';
    const fallback=String(name||'?').trim().charAt(0).toUpperCase()||'?';
    let safe=String(url||'').trim().replace(/\\/g,'/');
    if(safe.startsWith('assets/avatars/')||safe.startsWith('uploads/avatars/'))safe='/'+safe;
    if(safe.startsWith('/assets/avatars/')||safe.startsWith('/uploads/avatars/')){
      const img=document.createElement('img');img.src=safe;img.alt='';img.loading='lazy';img.decoding='async';
      img.addEventListener('error',()=>{node.textContent=fallback;},{once:true});
      node.appendChild(img);
    }else node.textContent=fallback;
    return node;
  }
  function createAvatarNode(className,url,name,frame='none'){
    const node=document.createElement('span');node.className=className;
    return fillAvatarNode(node,url,name,frame);
  }
  function createVipMemberBadge(isVip){
    if(!isVip)return null;
    const badge=document.createElement('span');
    badge.className='bm-vip-member-badge is-compact';
    badge.title='عضو VIP بانک مووی';
    badge.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m3 7 4.5 4L12 4l4.5 7L21 7l-2 10H5L3 7Z"/><path d="M6 18h12"/></svg><span>VIP</span>';
    return badge;
  }
  function createAdminVerifiedBadge(isAdmin){
    if(!isAdmin)return null;
    const badge=document.createElement('span');
    badge.className='bm-admin-verified-badge';
    badge.title='مدیر تأییدشده بانک مووی';
    badge.setAttribute('aria-label','مدیر تأییدشده');
    badge.innerHTML='<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';
    return badge;
  }
  function renderMembers(members,max){
    $('memberCount').textContent=`${members.length}/${max}`;
    $('memberCountTop').textContent=`${members.length} نفر`;
    const box=$('members'); box.textContent='';
    if(!members.length){box.innerHTML='<div class="empty-side">هنوز کسی داخل اتاق نیست</div>';return;}
    members.forEach(m=>{
      const row=document.createElement('div'); row.className='member';
      const avatar=createAvatarNode('member-avatar',m.avatar_url,m.username,m.avatar_frame);
      const meta=document.createElement('span'); meta.className='member-meta';
      const name=document.createElement('strong');
      const nameText=document.createElement('span');nameText.textContent=m.username+(Number(m.user_id)===CURRENT_USER_ID?' · شما':'');
      name.appendChild(nameText);const memberAdmin=createAdminVerifiedBadge(Boolean(m.is_admin));if(memberAdmin)name.appendChild(memberAdmin);const memberVip=createVipMemberBadge(Boolean(m.is_vip));if(memberVip)name.appendChild(memberVip);
      const sub=document.createElement('small'); sub.textContent=m.member_role==='host'?'کنترل پخش':'همراه تماشا';
      meta.append(name,sub);
      const live=document.createElement('span'); live.className='member-live'; live.innerHTML='<i></i> آنلاین';
      row.append(avatar,meta,live); box.appendChild(row);
    });
  }
  function stickerFromMessage(value){
    const match=String(value||'').trim().match(STICKER_MESSAGE_RE);
    if(!match)return null;
    const pack=String(match[1]||'').toLowerCase();
    const id=String(match[2]||'').toLowerCase();
    const sticker=STICKER_MAPS[pack]?.get(id) || null;
    return sticker ? Object.assign({pack}, sticker) : null;
  }
  const playerStickerOverlayQueue=[];
  let playerStickerOverlayBusy=false;
  function showPlayerStickerOverlay(sticker,username,mine=false){
    if(!sticker||!sticker.url||!$('playerStickerLayer'))return;
    playerStickerOverlayQueue.push({sticker,username:String(username||''),mine:Boolean(mine)});
    if(playerStickerOverlayQueue.length>5)playerStickerOverlayQueue.splice(0,playerStickerOverlayQueue.length-5);
    if(!playerStickerOverlayBusy)playNextPlayerStickerOverlay();
  }
  function playNextPlayerStickerOverlay(){
    const layer=$('playerStickerLayer');
    if(!layer){playerStickerOverlayQueue.length=0;playerStickerOverlayBusy=false;return;}
    const next=playerStickerOverlayQueue.shift();
    if(!next){playerStickerOverlayBusy=false;return;}
    playerStickerOverlayBusy=true;
    layer.textContent='';
    const pop=document.createElement('div');pop.className='player-sticker-pop'+(next.mine?' mine':'');
    const sticker=next.sticker;
    const isImage=String(sticker.media_type||'').toLowerCase()==='image'||/\.(?:webp|png|jpe?g|gif)(?:$|\?)/i.test(String(sticker.url||''));
    let media;
    if(isImage){
      media=document.createElement('img');media.src=String(sticker.url||'');media.alt='استیکر';media.decoding='async';media.draggable=false;
    }else{
      media=document.createElement('video');media.src=String(sticker.url||'');media.autoplay=true;media.loop=true;media.muted=true;media.playsInline=true;media.preload='metadata';media.setAttribute('disablepictureinpicture','');
    }
    pop.appendChild(media);layer.appendChild(pop);
    requestAnimationFrame(()=>requestAnimationFrame(()=>pop.classList.add('show')));
    const visibleFor=isImage?3000:3600;
    setTimeout(()=>{
      pop.classList.remove('show');pop.classList.add('leave');
      setTimeout(()=>{
        if(media.tagName==='VIDEO'){try{media.pause();media.removeAttribute('src');media.load();}catch(e){}}
        pop.remove();playerStickerOverlayBusy=false;playNextPlayerStickerOverlay();
      },300);
    },visibleFor);
  }
  function messageClock(value){
    if(!value)return '';
    const parsed=new Date(String(value).replace(' ','T')+'+03:30');
    if(Number.isNaN(parsed.getTime()))return '';
    return parsed.toLocaleTimeString('fa-IR',{hour:'2-digit',minute:'2-digit'});
  }

  /* V51 — chat-only long-session guard. Send/Poll/Delivery/Player are untouched. */
  const BM_V51_CHAT_PAGE=20;
  const BM_V51_CHAT_MAX=120;
  let bmV51ChatBudget=BM_V51_CHAT_PAGE;
  let bmV51HistoryLoading=false;
  let bmV51HistoryExhausted=false;
  let bmV55HistoryAtEdge=false;
  let bmV55HistoryScrollRaf=0;
  function bmV51ResetChatWindow(){bmV51ChatBudget=BM_V51_CHAT_PAGE;bmV51HistoryLoading=false;bmV51HistoryExhausted=false;bmV55HistoryAtEdge=false;const tools=$('chatHistoryTools');if(tools)tools.hidden=true;const btn=$('chatLoadMoreBtn');if(btn){btn.disabled=false;btn.classList.remove('is-loading');}}
  function bmV51ReleaseChatRow(row){if(!row)return;row.querySelectorAll('video.chat-sticker-webm').forEach(media=>{try{media.pause();media.removeAttribute('src');media.load();}catch(e){}});row.remove();}
  function bmV51ServerRows(){const box=$('messages');return box?Array.from(box.querySelectorAll('.message-row[data-message-id]')):[];}
  function bmV51OldestMessageId(){let min=0;bmV51ServerRows().forEach(row=>{const id=Number(row.dataset.messageId)||0;if(id>0&&(min===0||id<min))min=id;});return min;}
  function bmV51PruneToBudget(){const rows=bmV51ServerRows(),limit=Math.max(BM_V51_CHAT_PAGE,Math.min(BM_V51_CHAT_MAX,bmV51ChatBudget));for(let i=0;i<Math.max(0,rows.length-limit);i++)bmV51ReleaseChatRow(rows[i]);}
  function bmV51RefreshHistoryButton(){const tools=$('chatHistoryTools'),btn=$('chatLoadMoreBtn');if(!tools||!btn)return;const hasRows=bmV51ServerRows().length>0;tools.hidden=Boolean(!state.roomCode||bmV51HistoryExhausted||!hasRows||(!bmV55HistoryAtEdge&&!bmV51HistoryLoading));btn.disabled=bmV51HistoryLoading;btn.classList.toggle('is-loading',bmV51HistoryLoading);const small=btn.querySelector('.chat-history-copy small');if(small)small.textContent=bmV51HistoryLoading?'در حال دریافت…':'برای بارگذاری لمس کنید';}
  function bmV55UpdateHistoryEdge(){const box=$('messages');if(!box)return;const next=box.scrollTop<=10;if(next===bmV55HistoryAtEdge&&!bmV51HistoryLoading)return;bmV55HistoryAtEdge=next;bmV51RefreshHistoryButton();}
  function bmV55OnMessagesScroll(){if(bmV55HistoryScrollRaf)return;bmV55HistoryScrollRaf=requestAnimationFrame(()=>{bmV55HistoryScrollRaf=0;bmV55UpdateHistoryEdge();});}
  function bmV51BuildHistoryRow(m){
    const mine=Number(m.user_id)===CURRENT_USER_ID;
    const row=document.createElement('div');row.className='message-row '+(mine?'mine':'');const mid=Number(m.id)||0;if(mid>0)row.dataset.messageId=String(mid);if(m.client_message_id)row.dataset.clientMessageId=String(m.client_message_id);
    const avatar=createAvatarNode('message-avatar',m.avatar_url,m.username,m.avatar_frame),item=document.createElement('div');item.className='message '+(mine?'mine':'');
    const b=document.createElement('b'),author=document.createElement('span');author.textContent=mine?'شما':m.username;b.appendChild(author);const admin=createAdminVerifiedBadge(Boolean(m.is_admin));if(admin)b.appendChild(admin);const vip=createVipMemberBadge(Boolean(m.is_vip));if(vip)b.appendChild(vip);
    const sticker=stickerFromMessage(m.message),time=document.createElement('small');time.className='message-time';time.textContent=messageClock(m.created_at);if(mine){const status=document.createElement('span');status.className='message-delivery-slot';status.innerHTML=messageStatusMarkup(m.delivered_at?'delivered':'awaiting');time.appendChild(status);}
    if(sticker){item.classList.add('is-sticker');const image=String(sticker.media_type||'').toLowerCase()==='image'||/\.(?:webp|png|jpe?g|gif)(?:$|\?)/i.test(String(sticker.url||''));let media;if(image){media=document.createElement('img');media.className='chat-sticker-webm chat-sticker-image';media.src=String(sticker.url||'');media.alt='استیکر';media.loading='lazy';media.decoding='async';media.draggable=false;}else{media=document.createElement('video');media.className='chat-sticker-webm';media.src=String(sticker.url||'');media.autoplay=state.chatOpen;media.loop=true;media.muted=true;media.playsInline=true;media.preload='metadata';media.setAttribute('disablepictureinpicture','');}item.append(b,media,time);}else{const text=document.createElement('span');text.className='message-text';text.textContent=m.message;item.append(b,text,time);}row.append(avatar,item);return row;
  }
  async function bmV51LoadOlderMessages(){
    if(bmV51HistoryLoading||bmV51HistoryExhausted||!state.roomCode)return;const before=bmV51OldestMessageId();if(before<=0)return;bmV51HistoryLoading=true;bmV51RefreshHistoryButton();
    try{const url='/watch_party_history.php?room_code='+encodeURIComponent(state.roomCode)+'&before_message_id='+encodeURIComponent(before)+'&limit='+BM_V51_CHAT_PAGE;const response=await fetch(url,{method:'GET',credentials:'same-origin',cache:'no-store',headers:{Accept:'application/json','X-Requested-With':'XMLHttpRequest'}});const data=await response.json().catch(()=>({}));if(!response.ok||!data.success)throw new Error(data.message||'دریافت پیام‌های قبلی انجام نشد.');const rows=Array.isArray(data.messages)?data.messages:[];if(!rows.length){bmV51HistoryExhausted=true;return;}const box=$('messages');if(!box)return;if(box.querySelector('.empty-side'))box.textContent='';const oldHeight=box.scrollHeight,oldTop=box.scrollTop,frag=document.createDocumentFragment();rows.forEach(m=>frag.appendChild(bmV51BuildHistoryRow(m)));box.insertBefore(frag,box.firstChild);bmV51ChatBudget=Math.min(BM_V51_CHAT_MAX,bmV51ChatBudget+rows.length);bmV51HistoryExhausted=!Boolean(data.has_more);requestAnimationFrame(()=>{box.scrollTop=oldTop+(box.scrollHeight-oldHeight);bmV55UpdateHistoryEdge();});}
    catch(e){flash(e.message||'دریافت پیام‌های قبلی انجام نشد.','error');}finally{bmV51HistoryLoading=false;bmV51RefreshHistoryButton();}
  }
  function bmV51PauseChatMedia(){$('messages')?.querySelectorAll('video.chat-sticker-webm').forEach(v=>{try{v.pause();}catch(e){}});}
  function bmV51ResumeChatMedia(){if(!state.chatOpen||document.hidden)return;$('messages')?.querySelectorAll('video.chat-sticker-webm').forEach(v=>{try{v.play().catch(()=>{});}catch(e){}});}

  function renderMessages(messages,notify=false){
    const box=$('messages');
    if(!messages.length)return;
    const firstChatBatch=!state.chatPrimed&&state.lastMessageId===0;
    if(firstChatBatch)bmV51HistoryExhausted=messages.length<=BM_V51_CHAT_PAGE;
    if(box.querySelector('.empty-side'))box.textContent='';
    messages.forEach(m=>{
      const mine=Number(m.user_id)===CURRENT_USER_ID;
      if(mine && m.client_message_id && reconcileQueuedMessage(m)){const pending=document.querySelector('[data-client-message-id="'+CSS.escape(String(m.client_message_id))+'"]');if(pending&&Number(m.id)>0)pending.dataset.messageId=String(Number(m.id));return;}
      const row=document.createElement('div');row.className='message-row '+(mine?'mine':'');if(Number(m.id)>0)row.dataset.messageId=String(Number(m.id));if(m.client_message_id)row.dataset.clientMessageId=String(m.client_message_id);
      const avatar=createAvatarNode('message-avatar',m.avatar_url,m.username,m.avatar_frame);
      const item=document.createElement('div');item.className='message '+(mine?'mine':'');
      const b=document.createElement('b');
      const author=document.createElement('span');author.textContent=mine?'شما':m.username;b.appendChild(author);
      const messageAdmin=createAdminVerifiedBadge(Boolean(m.is_admin));if(messageAdmin)b.appendChild(messageAdmin);
      const messageVip=createVipMemberBadge(Boolean(m.is_vip));if(messageVip)b.appendChild(messageVip);
      const sticker=stickerFromMessage(m.message);
      const time=document.createElement('small'); time.className='message-time'; time.textContent=messageClock(m.created_at);
      if(mine){const statusSlot=document.createElement('span');statusSlot.className='message-delivery-slot';statusSlot.innerHTML=messageStatusMarkup(m.delivered_at?'delivered':'awaiting');time.appendChild(statusSlot);}
      if(sticker){
        item.classList.add('is-sticker');
        const isImage=String(sticker.media_type||'').toLowerCase()==='image' || /\.(?:webp|png|jpe?g|gif)(?:$|\?)/i.test(String(sticker.url||''));
        let media;
        if(isImage){
          media=document.createElement('img');
          media.className='chat-sticker-webm chat-sticker-image';
          media.src=String(sticker.url||'');
          media.alt='استیکر '+String(window.BM_WP_STICKER_PACKS?.[sticker.pack]?.label || sticker.pack);
          media.loading='lazy';media.decoding='async';media.draggable=false;
        }else{
          media=document.createElement('video');
          media.className='chat-sticker-webm';
          media.src=String(sticker.url||'');
          media.autoplay=true;media.loop=true;media.muted=true;media.playsInline=true;media.preload='metadata';
          media.setAttribute('aria-label','استیکر '+String(window.BM_WP_STICKER_PACKS?.[sticker.pack]?.label || sticker.pack));
          media.setAttribute('disablepictureinpicture','');
        }
        item.append(b,media,time);
      }else{
        const t=document.createElement('span');t.className='message-text';t.textContent=m.message;
        item.append(b,t,time);
      }
      row.append(avatar,item);box.appendChild(row);
      if(notify && sticker && !mine)showPlayerStickerOverlay(sticker,m.username,false);
      if(notify && !mine) incomingChatMessage(m);
    });
    bmV51PruneToBudget();
    box.scrollTop=box.scrollHeight;
    bmV55HistoryAtEdge=false;
    bmV51RefreshHistoryButton();
  }
  function incomingChatMessage(message){
    if(!state.chatOpen){
      state.chatUnread=Math.min(99,state.chatUnread+1);
      updateChatUnread();
      showChatPreview(message);
      if(state.chatSoundEnabled)playChatTone();
      try{navigator.vibrate?.(35);}catch(e){}
    }
  }
  function updateChatUnread(){
    const value=state.chatUnread>99?'۹۹+':String(state.chatUnread).replace(/\d/g,d=>'۰۱۲۳۴۵۶۷۸۹'[d]);
    $('chatUnread').textContent=value;$('chatUnread').classList.toggle('show',state.chatUnread>0);
    $('sideUnreadValue').textContent=value||'۰';
    const chatBtn=$('playerChatBtn');
    const wrapper=$('playerWrapper');
    wrapper?.classList.toggle('has-chat-unread',state.chatUnread>0);
    if(state.chatUnread>0){chatBtn.classList.remove('pulse');void chatBtn.offsetWidth;chatBtn.classList.add('pulse');}else chatBtn.classList.remove('pulse');
  }
  function showChatPreview(message){
    clearTimeout(state.chatPreviewTimer);
    fillAvatarNode($('chatPreviewAvatar'),message.avatar_url,message.username,message.avatar_frame);
    const previewName=$('chatPreviewName');previewName.textContent='';
    const previewAuthor=document.createElement('span');previewAuthor.textContent=message.username||'پیام جدید';previewName.appendChild(previewAuthor);
    const previewAdmin=createAdminVerifiedBadge(Boolean(message.is_admin));if(previewAdmin)previewName.appendChild(previewAdmin);
    const previewVip=createVipMemberBadge(Boolean(message.is_vip));if(previewVip)previewName.appendChild(previewVip);
    const previewSticker=stickerFromMessage(message.message);
    $('chatPreviewMessage').textContent=previewSticker?('استیکر '+String(window.BM_WP_STICKER_PACKS?.[previewSticker.pack]?.label || previewSticker.pack)):(message.message||'');
    $('chatPreviewToast').classList.add('show');
    // پیام جدید فقط بخش چت را بیدار می‌کند؛ کنترل‌های فیلم مزاحم تصویر نمی‌شوند.
    state.chatPreviewTimer=setTimeout(()=>$('chatPreviewToast').classList.remove('show'),5200);
  }
  function playChatTone(){
    try{
      const AudioCtx=window.AudioContext||window.webkitAudioContext;if(!AudioCtx)return;
      const ctx=playChatTone.ctx||(playChatTone.ctx=new AudioCtx());
      if(ctx.state==='suspended')ctx.resume().catch(()=>{});
      const osc=ctx.createOscillator(),gain=ctx.createGain();
      osc.type='sine';osc.frequency.setValueAtTime(720,ctx.currentTime);osc.frequency.exponentialRampToValueAtTime(980,ctx.currentTime+.08);
      gain.gain.setValueAtTime(.0001,ctx.currentTime);gain.gain.exponentialRampToValueAtTime(.065,ctx.currentTime+.015);gain.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.15);
      osc.connect(gain);gain.connect(ctx.destination);osc.start();osc.stop(ctx.currentTime+.16);
    }catch(e){}
  }
  function compactChatMode(){return Boolean((navigator.maxTouchPoints||0)>0 || 'ontouchstart' in window || window.innerWidth<=1024 || window.matchMedia?.('(pointer: coarse)').matches);}
  function updateViewportMetrics(){
    const vv=window.visualViewport;
    const visibleHeight=Math.max(180,Math.round(vv?.height||window.innerHeight||document.documentElement.clientHeight||600));
    const visibleWidth=Math.max(280,Math.round(vv?.width||window.innerWidth||document.documentElement.clientWidth||360));
    const layoutHeight=Math.max(visibleHeight,Math.round(window.innerHeight||visibleHeight));
    const offsetTop=Math.max(0,Math.round(vv?.offsetTop||0));
    const offsetLeft=Math.max(0,Math.round(vv?.offsetLeft||0));
    const keyboardOffset=Math.max(0,layoutHeight-visibleHeight-offsetTop);
    document.documentElement.style.setProperty('--wp-visible-height',visibleHeight+'px');
    document.documentElement.style.setProperty('--wp-visible-width',visibleWidth+'px');
    document.documentElement.style.setProperty('--wp-viewport-top',offsetTop+'px');
    document.documentElement.style.setProperty('--wp-viewport-left',offsetLeft+'px');
    document.documentElement.style.setProperty('--wp-keyboard-offset',keyboardOffset+'px');
    const focused=document.activeElement===$('chatInput');
    document.body.classList.toggle('wp-keyboard-open',focused&&(keyboardOffset>45||visibleHeight<Math.round(screen.height*.72)));
  }
  let viewportMetricsRaf=0;
  function requestViewportMetrics(){
    if(viewportMetricsRaf)return;
    viewportMetricsRaf=requestAnimationFrame(()=>{viewportMetricsRaf=0;updateViewportMetrics();});
  }
  function ensureChatPortal(){
    const panel=$('playerChatPanel');
    const fullscreenHost=document.fullscreenElement;
    const viewportSheet=compactChatMode();
    const host=fullscreenHost || (viewportSheet?document.body:chatPanelHome);
    if(panel.parentNode!==host)host.appendChild(panel);
    panel.classList.toggle('is-viewport-sheet',viewportSheet||Boolean(fullscreenHost));
    applyRoomBackground(state.roomBackground||USER_BACKGROUND||'simple');
    updateViewportMetrics();
  }
  function restoreChatPortal(){
    const panel=$('playerChatPanel');
    if(panel.parentNode!==chatPanelHome)chatPanelHome.insertBefore(panel,chatPanelAnchor);
    panel.classList.remove('is-viewport-sheet');
    document.body.classList.remove('wp-keyboard-open','wp-chat-modal-open');
    updateViewportMetrics();
  }
  function openPlayerChat(){
    if(!state.roomCode){flash('اول وارد یک اتاق شو.','error');return;}
    closePlayerSettings();
    state.chatOpenScrollX=window.scrollX||0;
    state.chatOpenScrollY=window.scrollY||0;
    state.chatOpen=true;state.chatUnread=0;updateChatUnread();showControls(true);
    ensureChatPortal();
    document.body.classList.add('wp-chat-modal-open');
    $('chatPreviewToast').classList.remove('show');$('playerChatPanel').classList.add('open');$('playerChatBtn').classList.add('active');bmV51ResumeChatMedia();
    requestAnimationFrame(()=>{
      requestViewportMetrics();
      if(!document.fullscreenElement && Math.abs((window.scrollY||0)-state.chatOpenScrollY)>2){
        window.scrollTo(state.chatOpenScrollX,state.chatOpenScrollY);
      }
      const messages=$('messages');
      if(messages)messages.scrollTop=messages.scrollHeight;
      // On a touch device the input is never focused automatically. This avoids
      // the keyboard/VisualViewport jump seen in the supplied video.
      if(!compactChatMode())setTimeout(()=>{$('chatInput').focus({preventScroll:true});requestViewportMetrics();},120);
    });
  }
  function closePlayerChat(){
    state.chatOpen=false;$('playerChatPanel').classList.remove('open');$('playerChatBtn').classList.remove('active');bmV51PauseChatMedia();
    $('chatInput')?.blur();setTimeout(restoreChatPortal,180);if(!video.paused)scheduleControlsHide(1800);
  }
  async function sendMessage(ev){ev.preventDefault();const input=$('chatInput');const message=input.value.trim();if(!message||!state.roomCode)return;input.value='';input.dispatchEvent(new Event('input',{bubbles:true}));enqueueMessage(message);}
  function loadVideoSource(src,isShared=false){
    if(!src)return;
    const clean=normalizeVideoUrl(src);
    state.loadedSharedUrl=isShared&&clean?clean:'';
    state.remoteGeneration++;
    state.sourceReloading=false;state.pendingResumeTarget=0;state.stallStartedAt=0;state.stallAttempts=0;
    state.lastHardSeekAt=0;state.lastMediaTime=0;state.lastMediaProgressAt=Date.now();
    video.src=src;video.load();$('videoEmpty').classList.add('hidden');$('activateOverlay').classList.remove('hidden');state.userActivated=false;updatePlayerUi();
    video.playbackRate=state.basePlaybackRate||1;
    log(isShared?'SHARED VIDEO SOURCE LOADED':'LOCAL VIDEO SOURCE LOADED');
  }
  async function publishVideoUrl(){
    if(!state.roomCode){flash('اول یک اتاق بساز یا وارد اتاق شو.','error');return;}
    if(state.role!=='host'){flash('فقط میزبان می‌تواند لینک ویدئو را برای اتاق تعیین کند.','error');return;}
    const url=normalizeVideoUrl($('videoUrl').value);
    if(!url){flash('لینک معتبر http یا https وارد کن.','error');return;}
    $('loadUrlBtn').disabled=true;
    try{
      loadVideoSource(url,true);
      prefillSubtitleQueryFromUrl(url);
      await sendControl('source_change',{source_url:url,subtitle_url:''});
      flash('ویدئو برای عضو دوم اتاق آماده شد.');
      log('VIDEO SOURCE PUBLISHED',url); closeTools();
    }catch(e){flash(e.message,'error');}
    finally{$('loadUrlBtn').disabled=false;}
  }
  async function finalizeExpiredRoom(){
    if(state.expiryFinalizing||!state.roomCode)return;
    state.expiryFinalizing=true;
    const code=state.roomCode;
    clearTimeout(state.pollTimer);clearInterval(state.stateTimer);clearInterval(state.countdownTimer);
    try{await api('poll',{room_code:code,after_event_id:state.lastEventId,after_message_id:state.lastMessageId,after_voice_signal_id:Math.max(0,Number(window.BM_WP_VOICE_AFTER_SIGNAL_ID||0))},'GET');}
    catch(e){/* The strict server lookup deletes the expired room before returning 404. */}
    stopRoom(true);
    flash('چهار ساعت اتاق تمام شد؛ لینک ویدئو، پیام‌ها، اعضا و وضعیت پخش کامل حذف شدند.','error');
  }
  function startCountdown(){
    clearInterval(state.countdownTimer);
    const tick=()=>{
      let leftSeconds=0;
      if(state.expiryAnchorClientMs>0){leftSeconds=Math.max(0,state.expiryAnchorSeconds-Math.floor((Date.now()-state.expiryAnchorClientMs)/1000));}
      else if(state.expiresEpoch>0){leftSeconds=Math.max(0,state.expiresEpoch-Math.floor(Date.now()/1000));}
      else{$('countdown').textContent='—';return;}
      const h=Math.floor(leftSeconds/3600),m=Math.floor(leftSeconds%3600/60),sec=Math.floor(leftSeconds%60);
      $('countdown').textContent=`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(sec).padStart(2,'0')}`;
      if(leftSeconds<=0)finalizeExpiredRoom();
    };
    tick();state.countdownTimer=setInterval(tick,1000);
  }
  async function leaveRoom(){if(!state.roomCode)return;const closing=state.role==='host';if(!confirm(closing?'اتاق و تمام پیام‌ها و داده‌هایش همین حالا حذف شود؟':'از اتاق خارج می‌شوی؟'))return;try{await api(closing?'close':'leave',{room_code:state.roomCode});flash(closing?'اتاق و همه داده‌های وابسته حذف شد.':'از اتاق خارج شدی.');}catch(e){flash(e.message,'error');}stopRoom(true);}
  function stopRoom(clearUrl){clearTimeout(state.pollTimer);clearInterval(state.stateTimer);clearInterval(state.countdownTimer);clearInterval(state.stallTimer);window.BM_WP_ACTIVE_ROOM_CODE='';state.roomCode='';state.role='';state.expiresAt='';state.expiresEpoch=0;state.expiryAnchorSeconds=0;state.expiryAnchorClientMs=0;state.expiryFinalizing=false;state.lastEventId=0;state.lastMessageId=0;state.lastAppliedSequence=0;state.loadedSharedUrl='';state.sharedSubtitleUrl='';state.loadedSubtitleUrl='';state.subtitleSource='';state.subtitleFetchToken++;state.remoteState=null;state.remoteServerNowMs=0;state.remoteReceivedClientMs=0;state.userActivated=false;state.remoteGeneration++;state.pendingHeartbeat=null;state.chatPrimed=false;state.chatUnread=0;state.stallStartedAt=0;state.stallAttempts=0;state.sourceReloading=false;state.pollFailureCount=0;updateChatUnread();closePlayerChat();closePlayerSettings();$('roomCodeView').textContent='—';$('roleBadge').textContent='بدون اتاق';$('roleBadge').className='status-pill';$('syncBadge').innerHTML='<span class="dot"></span> آفلاین';$('sideSyncValue').textContent='آفلاین';$('sideRoleValue').textContent='—';$('playerRoleText').textContent='اتاق خصوصی';document.body.classList.remove('room-active');applyRoomBackground(USER_BACKGROUND||'simple');$('lobbyPanel')?.classList.remove('is-collapsed');$('roomStage')?.classList.add('is-locked');$('roomToolsBtn')?.classList.add('hidden');updateControlAccess();if(clearUrl)history.replaceState({},'',location.pathname);}


  function safeStore(key,value){try{localStorage.setItem(key,String(value));}catch(e){}}
  function safeLoad(key,fallback){try{const v=localStorage.getItem(key);return v===null?fallback:v;}catch(e){return fallback;}}
  function openSettingsPanel(name='main'){
    $('playerSettings').querySelectorAll('[data-settings-panel]').forEach(panel=>panel.classList.toggle('active',panel.dataset.settingsPanel===name));
  }
  function openPlayerSettings(){closePlayerChat();document.body.classList.add('wp-player-settings-open');$('playerSettingsBackdrop')?.classList.add('open');$('playerSettings').classList.add('open');$('partySettingsBtn').classList.add('active');openSettingsPanel('main');showControls(true);}
  function closePlayerSettings(){document.body.classList.remove('wp-player-settings-open');$('playerSettingsBackdrop')?.classList.remove('open');$('playerSettings').classList.remove('open');$('partySettingsBtn')?.classList.remove('active');}
  function togglePlayerSettings(){$('playerSettings').classList.contains('open')?closePlayerSettings():openPlayerSettings();}
  function settingChoice(title,desc,value,active,handler){
    const button=document.createElement('button');button.type='button';button.className='setting-choice'+(active?' active':'');button.dataset.value=String(value);
    const main=document.createElement('span');main.className='setting-row-main';const txt=document.createElement('span');txt.className='setting-text';const strong=document.createElement('strong');strong.textContent=title;txt.appendChild(strong);if(desc){const small=document.createElement('small');small.textContent=desc;txt.appendChild(small);}main.appendChild(txt);
    const check=document.createElement('span');check.className='setting-check';check.innerHTML='<svg viewBox="0 0 24 24" fill="none"><path d="M20 6L9 17l-5-5"/></svg>';button.append(main,check);button.addEventListener('click',handler);return button;
  }
  function buildSettingsChoices(){
    const speedBox=$('speedChoices');speedBox.textContent='';
    [[.5,'0.5x','خیلی آهسته'],[.75,'0.75x','آهسته'],[1,'1x','عادی'],[1.25,'1.25x','کمی سریع'],[1.5,'1.5x','سریع'],[2,'2x','خیلی سریع']].forEach(([value,title,desc])=>speedBox.appendChild(settingChoice(title,desc,value,Math.abs(state.basePlaybackRate-value)<.001,()=>setPlaybackSpeed(value))));
    const pictureBox=$('pictureChoices');pictureBox.textContent='';
    [['fit','عادی','نمایش کامل تصویر'],['fill','پرکننده','پر کردن قاب و برش کناره‌ها'],['stretch','کشیده 16:9','پر کردن قاب بدون حاشیه'],['zoom','زوم سینمایی','بزرگ‌نمایی کنترل‌شده']].forEach(([value,title,desc])=>pictureBox.appendChild(settingChoice(title,desc,value,state.pictureMode===value,()=>setPictureMode(value))));
    const sleepBox=$('sleepChoices');sleepBox.textContent='';
    [[0,'خاموش','تایمر فعال نیست'],[15,'۱۵ دقیقه',''],[30,'۳۰ دقیقه',''],[45,'۴۵ دقیقه',''],[60,'۶۰ دقیقه',''],[90,'۹۰ دقیقه',''],[120,'۱۲۰ دقیقه','']].forEach(([value,title,desc])=>sleepBox.appendChild(settingChoice(title,desc,value,(value===0&&!state.sleepEndsAt),()=>setSleepTimer(value))));
  }
  function updateSettingsSummary(){
    $('speedValue').textContent=(Math.round((state.basePlaybackRate||1)*100)/100)+'x';
    const pictureNames={fit:'عادی',fill:'پرکننده',stretch:'کشیده',zoom:'زوم'};$('pictureValue').textContent=pictureNames[state.pictureMode]||'عادی';
    $('brightnessValue').textContent=Math.round(state.brightness*100)+'%';$('brightnessPercent').textContent=Math.round(state.brightness*100)+'%';
    $('subtitleValue').textContent=state.subtitleCues.length?(state.subtitleEnabled?'روشن':'خاموش'):'بدون فایل';
    $('subtitleToggleRow').classList.toggle('on',state.subtitleEnabled);
    $('theatreSettingRow').classList.toggle('on',state.theatreMode);$('chatSoundSettingRow').classList.toggle('on',state.chatSoundEnabled);
    $('sleepValue').textContent=state.sleepEndsAt?'فعال':'خاموش';
    if(!$('speedChoices').children.length||!$('pictureChoices').children.length||!$('sleepChoices').children.length)buildSettingsChoices();
    else{
      $('speedChoices').querySelectorAll('.setting-choice').forEach(btn=>btn.classList.toggle('active',Math.abs(Number(btn.dataset.value)-state.basePlaybackRate)<.001));
      $('pictureChoices').querySelectorAll('.setting-choice').forEach(btn=>btn.classList.toggle('active',btn.dataset.value===state.pictureMode));
    }
  }
  function setPlaybackSpeed(value){
    value=Math.max(.5,Math.min(2,Number(value)||1));
    if(state.role!=='host'){flash('سرعت پخش همگام فقط توسط میزبان تغییر می‌کند.','error');return;}
    state.basePlaybackRate=value;video.playbackRate=value;sendControl('state');updateSettingsSummary();openSettingsPanel('main');flash('سرعت پخش روی هر دو پلیر تنظیم شد.');
  }
  function setPictureMode(mode){
    const valid=['fit','fill','stretch','zoom'];state.pictureMode=valid.includes(mode)?mode:'fit';
    $('playerWrapper').classList.remove('picture-fit','picture-fill','picture-stretch','picture-zoom');$('playerWrapper').classList.add('picture-'+state.pictureMode);safeStore('bm_wp_picture_mode',state.pictureMode);updateSettingsSummary();openSettingsPanel('main');
  }
  function setBrightness(value){state.brightness=Math.max(.4,Math.min(1.6,Number(value)||1));video.style.filter=`brightness(${state.brightness})`;safeStore('bm_wp_brightness',state.brightness);updateSettingsSummary();}
  function toggleTheatre(){state.theatreMode=!state.theatreMode;document.body.classList.toggle('theatre-mode',state.theatreMode);updateSettingsSummary();closePlayerSettings();}
  function toggleChatSound(){state.chatSoundEnabled=!state.chatSoundEnabled;safeStore('bm_wp_chat_sound',state.chatSoundEnabled?'1':'0');updateSettingsSummary();}
  async function togglePip(){
    if(!document.pictureInPictureEnabled||!video.requestPictureInPicture){flash('مرورگر از تصویر در تصویر پشتیبانی نمی‌کند.','error');return;}
    try{if(document.pictureInPictureElement)await document.exitPictureInPicture();else await video.requestPictureInPicture();}catch(e){flash('فعال‌سازی تصویر در تصویر ممکن نشد.','error');}
  }
  function setScreenLocked(locked){state.screenLocked=Boolean(locked);$('playerWrapper').classList.toggle('locked',state.screenLocked);closePlayerChat();closePlayerSettings();if(state.screenLocked)flash('کنترل‌های پلیر قفل شدند.');}
  function setSleepTimer(minutes){
    clearTimeout(state.sleepTimer);state.sleepTimer=null;state.sleepEndsAt=0;
    minutes=Number(minutes)||0;
    if(minutes>0){state.sleepEndsAt=Date.now()+minutes*60000;state.sleepTimer=setTimeout(()=>{state.sleepEndsAt=0;if(state.role==='host'){video.pause();flash('زمان‌سنج خواب پایان یافت و پخش برای اتاق متوقف شد.');}else{state.userActivated=false;video.pause();$('activateOverlay').classList.remove('hidden');flash('زمان‌سنج خواب پایان یافت؛ برای ادامه دوباره «آماده‌ام» را بزن.');}updateSettingsSummary();},minutes*60000);flash(`زمان‌سنج ${minutes} دقیقه‌ای فعال شد.`);}
    updateSettingsSummary();openSettingsPanel('main');
  }
  function parseClock(value){
    const clean=String(value||'').trim().replace(',', '.');const parts=clean.split(':').map(Number);if(parts.some(n=>!Number.isFinite(n)))return 0;
    if(parts.length===3)return parts[0]*3600+parts[1]*60+parts[2];if(parts.length===2)return parts[0]*60+parts[1];return Number(parts[0])||0;
  }
  function stripSubtitleTags(value){return String(value||'').replace(/\{\\[^}]+\}/g,'').replace(/<[^>]+>/g,'').replace(/\\N/gi,'\n').trim();}
  function parseSubtitleText(raw,name='subtitle'){
    raw=String(raw||'').replace(/^\uFEFF/,'').replace(/\r/g,'');const cues=[];
    if(/\.ass$|\.ssa$/i.test(name)||/^\[Script Info\]/mi.test(raw)){
      raw.split('\n').forEach(line=>{if(!/^Dialogue:/i.test(line))return;const body=line.replace(/^Dialogue:\s*/i,'');const parts=body.split(',');if(parts.length<10)return;const start=parseClock(parts[1]),end=parseClock(parts[2]),text=stripSubtitleTags(parts.slice(9).join(','));if(end>start&&text)cues.push({start,end,text});});
      return cues.sort((a,b)=>a.start-b.start);
    }
    const blocks=raw.replace(/^WEBVTT[^\n]*\n+/i,'').split(/\n{2,}/);
    blocks.forEach(block=>{const lines=block.split('\n').filter(Boolean);let timeIndex=lines.findIndex(line=>line.includes('-->'));if(timeIndex<0)return;const times=lines[timeIndex].split('-->');const start=parseClock(times[0]),end=parseClock(times[1].trim().split(/\s+/)[0]);const text=stripSubtitleTags(lines.slice(timeIndex+1).join('\n'));if(end>start&&text)cues.push({start,end,text});});
    return cues.sort((a,b)=>a.start-b.start);
  }
  function normalizeSubtitleUrl(value){
    value=String(value||'').trim();if(!value)return '';
    try{const url=new URL(value,location.origin);return /^https?:$/.test(url.protocol)?url.href:'';}catch(e){return '';}
  }
  function subtitleFetchCandidates(url){
    url=normalizeSubtitleUrl(url);if(!url)return [];
    const candidates=[url];
    candidates.push('/api6.php?subtitle_url='+encodeURIComponent(url));
    candidates.push('/api4.php?subtitle_url='+encodeURIComponent(url));
    return [...new Set(candidates)];
  }
  function subtitleNameFromUrl(url){
    try{return decodeURIComponent(new URL(url,location.origin).pathname.split('/').pop()||'subtitle.vtt');}catch(e){return 'subtitle.vtt';}
  }
  function setSubtitleStatus(title,description){
    if($('subtitleFileName'))$('subtitleFileName').textContent=title||'انتخاب فایل زیرنویس';
    const status=$('subtitleFileStatus');
    if(status){
      const strong=status.querySelector('strong'),small=status.querySelector('small');
      if(strong)strong.textContent=title||'فایلی بارگذاری نشده';
      if(small)small.textContent=description||'تنظیمات زیرنویس فقط روی همین دستگاه اعمال می‌شود.';
    }
  }
  async function loadSharedSubtitleUrl(url){
    url=normalizeSubtitleUrl(url);if(!url)return false;
    const token=++state.subtitleFetchToken;
    setSubtitleStatus('در حال دریافت زیرنویس…','زیرنویس همراه لینک فیلم در حال آماده‌سازی است.');
    let lastError=null;
    for(const candidate of subtitleFetchCandidates(url)){
      try{
        const internal=candidate.startsWith('/');
        const response=await fetch(candidate,{credentials:internal?'same-origin':'omit',cache:'no-store',headers:{Accept:'text/vtt,text/plain,*/*'}});
        if(!response.ok)throw new Error('HTTP '+response.status);
        const raw=await response.text();
        const name=subtitleNameFromUrl(url);
        const cues=parseSubtitleText(raw,name);
        if(!cues.length)throw new Error('empty subtitle');
        if(token!==state.subtitleFetchToken||url!==state.sharedSubtitleUrl)return false;
        state.subtitleCues=cues;state.subtitleEnabled=true;state.subtitleActiveIndex=-1;
        state.loadedSubtitleUrl=url;state.subtitleSource='auto';
        setSubtitleStatus('زیرنویس خودکار',`${cues.length} خط همراه فیلم برای این دستگاه آماده شد.`);
        updateSubtitleOverlay(true);updateSettingsSummary();
        flash('زیرنویس فیلم خودکار بارگذاری شد.');
        return true;
      }catch(error){lastError=error;log('AUTO SUBTITLE LOAD FAILED',{candidate,error:error?.message||String(error)});}
    }
    if(token===state.subtitleFetchToken&&url===state.sharedSubtitleUrl){
      state.loadedSubtitleUrl='';
      setSubtitleStatus('زیرنویس خودکار باز نشد','می‌توانی فایل SRT، VTT، ASS یا SSA را دستی انتخاب کنی.');
      flash('زیرنویس خودکار دریافت نشد؛ بارگذاری دستی همچنان در دسترس است.','error');
    }
    return false;
  }
  function syncSharedSubtitle(value){
    const url=normalizeSubtitleUrl(value);
    if(url===state.sharedSubtitleUrl)return;
    state.sharedSubtitleUrl=url;
    state.subtitleFetchToken++;
    if(!url){
      if(state.subtitleSource==='auto'){
        state.subtitleCues=[];state.subtitleActiveIndex=-1;state.loadedSubtitleUrl='';state.subtitleSource='';
        $('subtitleOverlay').textContent='';setSubtitleStatus('فایلی بارگذاری نشده','برای این لینک، زیرنویس خودکار ثبت نشده است.');updateSettingsSummary();
      }
      return;
    }
    loadSharedSubtitleUrl(url);
  }
  async function loadSubtitleFile(file){
    if(!file)return;try{const raw=await file.text();const cues=parseSubtitleText(raw,file.name);if(!cues.length)throw new Error('no cues');state.subtitleCues=cues;state.subtitleEnabled=true;state.subtitleActiveIndex=-1;state.subtitleSource='manual';state.loadedSubtitleUrl=state.sharedSubtitleUrl;$('subtitleFileName').textContent=file.name;const status=$('subtitleFileStatus');if(status){status.querySelector('strong').textContent=file.name;status.querySelector('small').textContent=`${cues.length} خط زیرنویس آماده پخش است.`;}updateSubtitleOverlay(true);updateSettingsSummary();flash(`${cues.length} خط زیرنویس بارگذاری شد.`);}catch(e){flash('فایل زیرنویس قابل خواندن نبود.','error');}
  }
  function removeSubtitle(){state.subtitleCues=[];state.subtitleActiveIndex=-1;state.subtitleSource='manual-disabled';state.loadedSubtitleUrl=state.sharedSubtitleUrl;$('subtitleUpload').value='';$('subtitleFileName').textContent='انتخاب فایل زیرنویس';const status=$('subtitleFileStatus');if(status){status.querySelector('strong').textContent='فایلی بارگذاری نشده';status.querySelector('small').textContent='تنظیمات زیرنویس فقط روی همین دستگاه اعمال می‌شود.';}$('subtitleOverlay').textContent='';updateSettingsSummary();}
  function updateSubtitleOverlay(force=false){
    const box=$('subtitleOverlay');if(!state.subtitleEnabled||!state.subtitleCues.length){if(box.textContent)box.textContent='';state.subtitleActiveIndex=-1;return;}
    const time=(Number(video.currentTime)||0)-state.subtitleDelay;let index=state.subtitleActiveIndex;
    if(index<0||!state.subtitleCues[index]||time<state.subtitleCues[index].start||time>state.subtitleCues[index].end){index=state.subtitleCues.findIndex(c=>time>=c.start&&time<=c.end);}
    if(!force&&index===state.subtitleActiveIndex)return;state.subtitleActiveIndex=index;box.textContent='';if(index>=0){const span=document.createElement('span');span.textContent=state.subtitleCues[index].text;box.appendChild(span);}
  }
  function setSubtitleStyle(){const box=$('subtitleOverlay');box.style.setProperty('--subtitle-color',state.subtitleColor);box.style.setProperty('--subtitle-scale',state.subtitleScale);box.style.setProperty('--subtitle-bottom',Math.round(state.subtitleBottom)+'px');box.style.setProperty('--subtitle-bg-alpha',String(state.subtitleBackground));safeStore('bm_wp_subtitle_color',state.subtitleColor);safeStore('bm_wp_subtitle_scale',state.subtitleScale);safeStore('bm_wp_subtitle_bottom',Math.round(state.subtitleBottom));safeStore('bm_wp_subtitle_bg',state.subtitleBackground);}
  function scheduleControlsHide(delay=3000){
    const wrapper=$('playerWrapper');
    clearTimeout(state.controlsTimer);
    if(state.screenLocked||video.paused||state.chatOpen||$('playerSettings').classList.contains('open'))return;
    state.controlsTimer=setTimeout(()=>{
      if(!video.paused&&!state.chatOpen&&!$('playerSettings').classList.contains('open'))wrapper.classList.add('controls-hidden');
    },Math.max(1200,Number(delay)||3000));
  }
  function showControls(sticky=false){
    const wrapper=$('playerWrapper');if(state.screenLocked)return;
    wrapper.classList.remove('controls-hidden');clearTimeout(state.controlsTimer);
    if(!sticky)scheduleControlsHide(3000);
  }
  function initPremiumPlayer(){
    state.pictureMode=safeLoad('bm_wp_picture_mode','fit');
    state.brightness=Math.max(.4,Math.min(1.6,Number(safeLoad('bm_wp_brightness','1'))||1));
    state.chatSoundEnabled=safeLoad('bm_wp_chat_sound','1')!=='0';
    state.subtitleColor=safeLoad('bm_wp_subtitle_color','#ffffff');
    state.subtitleScale=Math.max(.65,Math.min(1.8,Number(safeLoad('bm_wp_subtitle_scale','1'))||1));
    const mobileSubtitleLayout=Boolean(window.matchMedia&&matchMedia('(max-width:700px)').matches);
    const defaultSubtitleBottom=mobileSubtitleLayout?56:86;
    let storedSubtitleBottom=safeLoad('bm_wp_subtitle_bottom','');
    /* v148.61.8: migrate only the previous automatic mobile default (136px). Manual values remain untouched. */
    if(mobileSubtitleLayout&&safeLoad('bm_wp_subtitle_default_v148618','')!=='1'){
      const oldValue=Number(storedSubtitleBottom);
      if(storedSubtitleBottom===''||!Number.isFinite(oldValue)||oldValue===136){
        storedSubtitleBottom=String(defaultSubtitleBottom);
        safeStore('bm_wp_subtitle_bottom',storedSubtitleBottom);
      }
      safeStore('bm_wp_subtitle_default_v148618','1');
    }
    state.subtitleBottom=Math.max(24,Math.min(220,Number(storedSubtitleBottom)||defaultSubtitleBottom));
    state.subtitleBackground=Math.max(0,Math.min(.85,Number(safeLoad('bm_wp_subtitle_bg','.42'))||0));
    setPictureMode(state.pictureMode);setBrightness(state.brightness);setSubtitleStyle();$('brightnessRange').value=String(Math.round(state.brightness*100));$('subtitleSizeRange').value=String(Math.round(state.subtitleScale*100));$('subtitleSizeValue').textContent=Math.round(state.subtitleScale*100)+'%';$('subtitlePositionRange').value=String(Math.round(state.subtitleBottom));$('subtitlePositionValue').textContent=Math.round(state.subtitleBottom)+'px';$('subtitleBackgroundRange').value=String(Math.round(state.subtitleBackground*100));$('subtitleBackgroundValue').textContent=Math.round(state.subtitleBackground*100)+'%';updateSettingsSummary();
    if(!document.pictureInPictureEnabled)$('partyPipBtn').classList.add('hidden');
  }


  function formatTime(seconds){
    seconds=Math.max(0,Math.floor(Number(seconds)||0));
    const h=Math.floor(seconds/3600),m=Math.floor((seconds%3600)/60),s=seconds%60;
    return h>0?`${h}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }
  function updateControlAccess(){
    const host=state.role==='host';
    ['partyPlayBtn','partyCenterPlay','partyBackBtn','partyForwardBtn','partyProgress'].forEach(id=>{
      const el=$(id); if(!el)return; el.disabled=!host; el.classList.toggle('guest-locked',!host);
    });
    $('hostOnlySource')?.classList.toggle('hidden',!host);
    $('roomAppearanceSection')?.classList.toggle('hidden',!host);
    $('guestControlHint')?.classList.toggle('hidden',host);
    $('playerChatBtn').disabled=!state.roomCode;
  }
  function updatePlayerUi(){
    const duration=Number(video.duration)||0,current=Number(video.currentTime)||0;
    $('partyCurrent').textContent=formatTime(current);
    $('partyDuration').textContent=formatTime(duration);
    const progress=duration>0?Math.min(100,Math.max(0,(current/duration)*100)):0;
    $('partyProgress').value=String(progress);
    $('partyProgress').style.setProperty('--progress',progress+'%');
    const paused=video.paused;
    $('playerWrapper').classList.toggle('paused',paused);
    $('partyPlayBtn').classList.toggle('is-playing',!paused);
    $('partyCenterPlay').classList.toggle('hidden',!video.src || state.role!=='host' || !state.userActivated);
    $('partyCenterPlay').classList.toggle('is-playing',!paused);
    $('partyPlayIcon').innerHTML=paused?'<polygon points="5 3 19 12 5 21 5 3"/>':'<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>';
    $('partyCenterIcon').innerHTML=$('partyPlayIcon').innerHTML;
    $('partyBuffering').classList.toggle('show',video.readyState<3 && !video.paused && !!video.src);
    updateSubtitleOverlay();
  }
  function hostAction(action){
    if(state.role!=='host'){flash('کنترل پخش فقط دست میزبان است.','error');return;}
    action();
  }
  function togglePlay(){hostAction(()=>video.paused?video.play().catch(err=>mediaNotice(mediaPlayErrorMessage(err),'error')):video.pause());}
  function seekBy(delta){hostAction(()=>{video.currentTime=Math.max(0,Math.min(Number(video.duration)||Infinity,(Number(video.currentTime)||0)+delta));});}
  function toggleMute(){video.muted=!video.muted;updateVolumeUi();}
  function updateVolumeUi(){
    $('partyVolume').value=String(Math.round((video.muted?0:video.volume)*100));
    $('partyVolumeIcon').innerHTML=(video.muted||video.volume===0)?'<path d="M11 5L6 9H2v6h4l5 4V5z"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>':'<path d="M11 5L6 9H2v6h4l5 4V5z"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>';
  }
  function isMobilePlaybackDevice(){
    return Boolean(window.matchMedia?.('(max-width: 950px), (pointer: coarse)').matches);
  }
  async function lockLandscapeOrientation(){
    if(!isMobilePlaybackDevice())return true;
    try{
      if(screen.orientation?.lock){
        try{await screen.orientation.lock('landscape');return true;}catch(e){await screen.orientation.lock('landscape-primary');return true;}
      }
      const legacy=screen.lockOrientation||screen.mozLockOrientation||screen.msLockOrientation;
      if(typeof legacy==='function')return legacy.call(screen,'landscape');
    }catch(e){log('ORIENTATION LOCK',e?.message||'not supported');}
    return false;
  }
  function unlockOrientation(){
    try{screen.orientation?.unlock?.();}catch(e){}
  }
  async function requestPlayerFullscreen(wrapper){
    if(wrapper.requestFullscreen){
      try{return await wrapper.requestFullscreen({navigationUI:'hide'});}catch(e){return await wrapper.requestFullscreen();}
    }
    if(wrapper.webkitRequestFullscreen)return wrapper.webkitRequestFullscreen();
    if(video.webkitEnterFullscreen)return video.webkitEnterFullscreen();
    throw new Error('مرورگر حالت تمام‌صفحه را پشتیبانی نمی‌کند.');
  }
  async function toggleFullscreen(){
    const wrapper=$('playerWrapper');
    try{
      if(document.fullscreenElement||document.webkitFullscreenElement){
        if(document.exitFullscreen)await document.exitFullscreen();
        else document.webkitExitFullscreen?.();
        unlockOrientation();
        return;
      }
      await requestPlayerFullscreen(wrapper);
      if(isMobilePlaybackDevice()){
        const locked=await lockLandscapeOrientation();
        if(!locked)flash('تمام‌صفحه فعال شد؛ مرورگر اجازه چرخش خودکار نداد، گوشی را افقی کن.','error');
      }
    }catch(e){flash(e?.message||'فعال‌کردن تمام‌صفحه ممکن نشد.','error');}
  }
  function openTools(){ document.body.classList.add('wp-room-tools-open'); $('roomToolsPanel').classList.add('open'); $('toolBackdrop').classList.add('open'); }
  function closeTools(){ document.body.classList.remove('wp-room-tools-open'); $('roomToolsPanel').classList.remove('open'); $('toolBackdrop').classList.remove('open'); }

  $('partyPlayBtn').addEventListener('click',togglePlay);
  $('partyCenterPlay').addEventListener('click',()=>state.userActivated?togglePlay():$('activateBtn').click());
  $('partyBackBtn').addEventListener('click',()=>seekBy(-10));
  $('partyForwardBtn').addEventListener('click',()=>seekBy(10));
  $('partyProgress').addEventListener('input',e=>hostAction(()=>{const d=Number(video.duration)||0;if(d)video.currentTime=d*(Number(e.target.value)||0)/100;}));
  $('partyVolumeBtn').addEventListener('click',toggleMute);
  $('partyVolume').addEventListener('input',e=>{video.muted=false;video.volume=Math.max(0,Math.min(1,(Number(e.target.value)||0)/100));updateVolumeUi();});
  $('partyFullscreenBtn').addEventListener('click',toggleFullscreen);
  $('partyPipBtn').addEventListener('click',togglePip);
  $('partySettingsBtn').addEventListener('click',togglePlayerSettings);
  $('closePlayerSettingsBtn').addEventListener('click',closePlayerSettings);
  $('playerSettingsBackdrop')?.addEventListener('click',closePlayerSettings);
  $('playerSettings').querySelectorAll('[data-open-settings]').forEach(btn=>btn.addEventListener('click',()=>openSettingsPanel(btn.dataset.openSettings)));
  $('playerSettings').querySelectorAll('.settings-back').forEach(btn=>btn.addEventListener('click',()=>openSettingsPanel('main')));
  $('subkadeSearchForm')?.addEventListener('submit',openSubkadeSearch);
  $('openFullFaqBtn')?.addEventListener('click',scrollToFaq);
  $('faqJumpBtn')?.addEventListener('click',scrollToFaq);
  $('theatreSettingRow').addEventListener('click',toggleTheatre);
  $('chatSoundSettingRow').addEventListener('click',toggleChatSound);
  $('sourceSettingRow').addEventListener('click',()=>{closePlayerSettings();if(state.role==='host')openTools();else flash('منبع ویدئو فقط توسط میزبان تغییر می‌کند.','error');});
  $('brightnessRange').addEventListener('input',e=>setBrightness((Number(e.target.value)||100)/100));
  $('subtitleUpload').addEventListener('change',e=>loadSubtitleFile(e.target.files?.[0]));
  $('subtitleToggleRow').addEventListener('click',()=>{state.subtitleEnabled=!state.subtitleEnabled;updateSubtitleOverlay(true);updateSettingsSummary();});
  $('subtitleDelayRange').addEventListener('input',e=>{state.subtitleDelay=Number(e.target.value)||0;$('subtitleDelayValue').textContent=(state.subtitleDelay>0?'+':'')+state.subtitleDelay.toFixed(1)+'s';updateSubtitleOverlay(true);});
  $('subtitleSizeRange').addEventListener('input',e=>{state.subtitleScale=(Number(e.target.value)||100)/100;$('subtitleSizeValue').textContent=Math.round(state.subtitleScale*100)+'%';setSubtitleStyle();updateSubtitleOverlay(true);});
  $('subtitlePositionRange').addEventListener('input',e=>{state.subtitleBottom=Math.max(24,Math.min(220,Number(e.target.value)||56));$('subtitlePositionValue').textContent=Math.round(state.subtitleBottom)+'px';setSubtitleStyle();});
  $('subtitleBackgroundRange').addEventListener('input',e=>{state.subtitleBackground=Math.max(0,Math.min(.85,(Number(e.target.value)||0)/100));$('subtitleBackgroundValue').textContent=Math.round(state.subtitleBackground*100)+'%';setSubtitleStyle();});
  $('playerSettings').querySelectorAll('.subtitle-color-btn').forEach(btn=>btn.addEventListener('click',()=>{state.subtitleColor=btn.dataset.subtitleColor||'#fff';$('playerSettings').querySelectorAll('.subtitle-color-btn').forEach(x=>x.classList.toggle('active',x===btn));setSubtitleStyle();}));
  $('resetSubtitleStyleBtn').addEventListener('click',()=>{const mobile=window.matchMedia&&matchMedia('(max-width:700px)').matches;state.subtitleScale=1;state.subtitleBottom=mobile?56:86;state.subtitleBackground=.42;state.subtitleColor='#ffffff';$('subtitleSizeRange').value='100';$('subtitleSizeValue').textContent='100%';$('subtitlePositionRange').value=String(state.subtitleBottom);$('subtitlePositionValue').textContent=state.subtitleBottom+'px';$('subtitleBackgroundRange').value='42';$('subtitleBackgroundValue').textContent='42%';$('playerSettings').querySelectorAll('.subtitle-color-btn').forEach(btn=>btn.classList.toggle('active',btn.dataset.subtitleColor==='#ffffff'));setSubtitleStyle();updateSubtitleOverlay(true);flash('ظاهر زیرنویس بازنشانی شد.');});
  $('removeSubtitleBtn').addEventListener('click',removeSubtitle);
  $('partyLockBtn').addEventListener('click',()=>setScreenLocked(true));$('unlockPlayerBtn').addEventListener('click',()=>setScreenLocked(false));
  $('playerChatBtn').addEventListener('click',()=>state.chatOpen?closePlayerChat():openPlayerChat());$('closePlayerChatBtn').addEventListener('click',closePlayerChat);$('chatPreviewToast').addEventListener('click',openPlayerChat);$('chatPreviewToast').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();openPlayerChat();}});
  $('chatInput').addEventListener('focus',()=>{document.body.classList.add('wp-chat-modal-open');ensureChatPortal();setTimeout(updateViewportMetrics,40);setTimeout(updateViewportMetrics,260);});
  $('chatInput').addEventListener('blur',()=>{setTimeout(updateViewportMetrics,120);});
  window.addEventListener('resize',updateViewportMetrics,{passive:true});
  window.addEventListener('orientationchange',()=>setTimeout(updateViewportMetrics,180),{passive:true});
  if(window.visualViewport){visualViewport.addEventListener('resize',requestViewportMetrics,{passive:true});visualViewport.addEventListener('scroll',requestViewportMetrics,{passive:true});}
  updateViewportMetrics();
  document.querySelectorAll('[data-room-background]').forEach(btn=>btn.addEventListener('click',()=>saveRoomBackground(btn.dataset.roomBackground)));
  applyRoomBackground(USER_BACKGROUND||'simple');
  $('roomToolsBtn').addEventListener('click',openTools);
  $('closeToolsBtn').addEventListener('click',closeTools);
  $('toolBackdrop').addEventListener('click',closeTools);
  video.addEventListener('timeupdate',()=>{updatePlayerUi();markMediaProgress();});
  video.addEventListener('durationchange',updatePlayerUi);
  video.addEventListener('volumechange',updateVolumeUi);
  video.addEventListener('waiting',()=>{
    updatePlayerUi();
    if(state.role!=='host'&&state.userActivated&&!state.desiredPaused){
      if(!state.stallStartedAt)state.stallStartedAt=Date.now();
      $('syncBadge').innerHTML='<span class="dot"></span> در حال دریافت ادامه ویدئو';
    }
  });
  video.addEventListener('stalled',()=>{
    if(state.role!=='host'&&state.userActivated&&!state.desiredPaused){
      if(!state.stallStartedAt)state.stallStartedAt=Date.now();
      $('partyBuffering').classList.add('show');
      log('MEDIA STALLED',{time:Number(video.currentTime)||0,readyState:video.readyState,networkState:video.networkState,bufferedAhead:bufferedAheadAt()});
    }
  });
  video.addEventListener('playing',()=>{markMediaProgress(true);updatePlayerUi();scheduleControlsHide(3000);});
  video.addEventListener('click',()=>{if(!state.screenLocked&&state.userActivated)togglePlay();});
  $('playerWrapper').addEventListener('pointermove',()=>showControls());$('playerWrapper').addEventListener('pointerdown',()=>showControls());$('playerControls').addEventListener('pointerenter',()=>showControls(true));
  const handleFullscreenChange=async()=>{
    const fullscreenActive=Boolean(document.fullscreenElement||document.webkitFullscreenElement);
    document.body.classList.toggle('player-fullscreen',fullscreenActive);
    $('partyFullscreenBtn').classList.toggle('active',fullscreenActive);
    $('partyFullscreenBtn').setAttribute('aria-pressed',fullscreenActive?'true':'false');
    if(fullscreenActive&&isMobilePlaybackDevice())await lockLandscapeOrientation();
    if(!fullscreenActive)unlockOrientation();
    if(state.chatOpen)ensureChatPortal();else restoreChatPortal();
    updateViewportMetrics();showControls(false);
  };
  document.addEventListener('fullscreenchange',handleFullscreenChange);
  document.addEventListener('webkitfullscreenchange',handleFullscreenChange);
  window.addEventListener('pagehide',unlockOrientation,{passive:true});
  initPremiumPlayer(); updateControlAccess(); updatePlayerUi(); updateVolumeUi(); updateChatUnread();

  $('copyBtn').addEventListener('click',async()=>{if(!state.inviteUrl)return;try{await navigator.clipboard.writeText(state.inviteUrl);flash('لینک دعوت کپی شد.');}catch(e){prompt('لینک دعوت:',state.inviteUrl);}}); $('leaveBtn').addEventListener('click',leaveRoom); $('chatLoadMoreBtn')?.addEventListener('click',bmV51LoadOlderMessages); $('messages')?.addEventListener('scroll',bmV55OnMessagesScroll,{passive:true}); document.addEventListener('visibilitychange',()=>{if(document.hidden)bmV51PauseChatMedia();else bmV51ResumeChatMedia();}); $('chatForm').addEventListener('submit',sendMessage);
  $('loadUrlBtn')?.addEventListener('click',publishVideoUrl);
  $('activateBtn').addEventListener('click',async()=>{
    if(!video.src){flash('اول لینک مستقیم ویدئو را داخل پلیر بارگذاری کن.','error');return;}
    state.userActivated=true;
    try{
      // تلاش پخش فقط داخل ژست واقعی کاربر انجام می‌شود؛ روی موبایل پیام خطا بر اساس علت واقعی تفکیک می‌شود.
      await video.play();
      if(state.role!=='host'){
        if(state.remoteState?.paused)video.pause();
        queueRemoteState(state.remoteState||{},currentEstimatedServerMs(),true,'activate');
        poll();
      }
      $('activateOverlay').classList.add('hidden');updatePlayerUi();flash(state.role==='host'?'پلیر آماده است؛ کنترل پخش با شماست.':'همگام‌سازی فعال شد؛ پخش با میزبان حرکت می‌کند.');
    }catch(e){
      state.userActivated=false;
      mediaNotice(mediaPlayErrorMessage(e),'error');
      log('MEDIA UNLOCK ERROR',{name:e?.name||'',message:e?.message||'play failed',src:video.currentSrc||video.src});
    }
  });
  video.addEventListener('play',()=>{
    updatePlayerUi();
    showControls(false);
    scheduleControlsHide(3000);
    if(state.role==='host')sendControl('play');
  });
  video.addEventListener('pause',()=>{
    updatePlayerUi();
    clearTimeout(state.controlsTimer);
    $('playerWrapper').classList.remove('controls-hidden');
    if(state.role==='host' && !video.ended)sendControl('pause');
  });
  video.addEventListener('seeking',()=>{
    if(state.role==='host')state.hostSeeking=true;
  });
  video.addEventListener('seeked',()=>{
    if(state.role==='host' && state.hostSeeking){
      state.hostSeeking=false;
      sendControl('seek');
    }
  });
  video.addEventListener('ended',()=>{
    if(state.role==='host')sendControl('pause');
  });
  video.addEventListener('loadedmetadata',()=>{
    if(state.role!=='host' && state.remoteState){
      queueRemoteState(state.remoteState,currentEstimatedServerMs(),true,'metadata');
    }
  });
  video.addEventListener('canplay',()=>{
    markMediaProgress(true);
    if(state.role!=='host'&&state.userActivated&&state.remoteState&&!state.remoteState.paused){
      queueRemoteState(state.remoteState,currentEstimatedServerMs(),false,'canplay');
    }
  });
  video.addEventListener('loadeddata',()=>markMediaProgress(true));
  video.addEventListener('emptied',()=>{state.lastMediaTime=0;state.lastMediaProgressAt=Date.now();state.stallStartedAt=0;});
  video.addEventListener('error',()=>{
    const code=Number(video.error?.code)||0;
    const failedSrc=video.currentSrc||video.src||'';
    const generation=state.remoteGeneration;
    log('VIDEO ERROR',{code,src:failedSrc,networkState:video.networkState,readyState:video.readyState});

    // خطاهای 3 و 4 روی بعضی مرورگرهای موبایل هنگام تعویض منبع گذرا هستند؛
    // اگر همان منبع بعداً آماده شد/پخش شد، هیچ هشدار گمراه‌کننده‌ای به کاربر نشان نده.
    if(code===3 || code===4){
      setTimeout(()=>{
        if(generation!==state.remoteGeneration)return;
        const sameSrc=(video.currentSrc||video.src||'')===failedSrc;
        const recovered=!video.error || video.readyState>=2 || !video.paused;
        if(!sameSrc || recovered)return;
        mediaNotice('پخش هنوز آماده نشده؛ یک بار دیگر دکمه پخش را بزن.','error');
      },1100);
      return;
    }

    let message='پخش ویدئو متوقف شد.';
    if(code===1)message='پخش لغو شد.';
    else if(code===2)message='ارتباط با منبع ویدئو برقرار نشد؛ چند لحظه بعد دوباره تلاش کن.';
    mediaNotice(message,'error');
  });
  document.addEventListener('pointerdown',e=>{
    if($('playerSettings').classList.contains('open')&&!e.target.closest('#playerSettings')&&!e.target.closest('#partySettingsBtn'))closePlayerSettings();
    if(state.chatOpen&&!e.target.closest('#playerChatPanel')&&!e.target.closest('#playerChatBtn')&&!e.target.closest('#chatPreviewToast'))closePlayerChat();
  });
  document.addEventListener('keydown',e=>{
    if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName))return;
    if(e.key==='Escape'){closePlayerChat();closePlayerSettings();return;}
    if(!state.roomCode)return;
    const key=e.key.toLowerCase();
    if(key==='c'){e.preventDefault();state.chatOpen?closePlayerChat():openPlayerChat();}
    else if(key==='f'){e.preventDefault();toggleFullscreen();}
    else if(key==='m'){e.preventDefault();toggleMute();}
    else if(key==='p'){e.preventDefault();togglePip();}
    else if(key==='l'){e.preventDefault();setScreenLocked(true);}
    else if(key===' '){e.preventDefault();togglePlay();}
    else if(e.key==='ArrowRight'){e.preventDefault();seekBy(10);}
    else if(e.key==='ArrowLeft'){e.preventDefault();seekBy(-10);}
  });
  window.addEventListener('beforeunload',()=>{clearTimeout(state.pollTimer);clearInterval(state.stateTimer);clearTimeout(state.sleepTimer);clearTimeout(state.controlsTimer);});
})();
</script>
<script src="/assets/js/bm-watch-party-low-end-v148611.js?v=148611" defer></script>
<link rel="stylesheet" href="/assets/css/bm-watch-party-pro-host-v14861930.css?v=14861930">
<link rel="stylesheet" href="/assets/css/bm-watch-party-room-appearance-v14861931.css?v=14861931">
<link rel="stylesheet" href="/assets/css/bm-watch-party-chat-extras-v14861937.css?v=14861937">
<script>window.BM_WP_PRO_HOST_CONFIG={csrf:<?= json_encode($csrf, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>,currentUserId:<?= (int)$user['id'] ?>,canCreate:<?= $canCreate ? 'true' : 'false' ?>};</script>
<script src="/assets/js/bm-watch-party-pro-host-v14861931.js?v=14861931" defer></script>
<script src="/assets/js/bm-watch-party-chat-media-v14861938.js?v=14861938" defer></script>
<link rel="stylesheet" href="/assets/css/bm-watch-party-voice-v14861952.css?v=14861952">
<script>
window.BM_WP_VOICE_TEST = <?= json_encode([
  'enabled' => $bmVoiceTestEnabled,
  'userId' => (int)($user['id'] ?? 0),
  'actorId' => $bmVoiceTestEnabled ? bm_watch_party_voice_actor_id($user) : 0,
  'isGuest' => !empty($user['is_watch_party_guest']),
  'username' => (string)($user['username'] ?? ''),
  'csrf' => $csrf,
  'nonce' => $bmVoiceTestEnabled ? bm_watch_party_voice_session_nonce($user) : '',
  'api' => '/watch_party_api.php',
  'iceServers' => $bmVoiceIceServers,
  'turnReady' => $bmVoiceTurnReady,
  'beta' => false,
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>
<script src="/assets/js/bm-watch-party-voice-v14861952.js?v=14861952" defer></script>

<style id="bm-watch-party-home-footer-v40">
/* V40 — RESET: exact homepage mobile dock values copied from index-inline-1.css.
   No portal, no custom multicolor repaint, no footer-specific theme system. */
@media (max-width:991px){
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]{
    position:fixed!important;
    left:50%!important;
    right:auto!important;
    top:auto!important;
    bottom:max(10px,env(safe-area-inset-bottom))!important;
    transform:translateX(-50%)!important;
    width:min(calc(100% - 26px),540px)!important;
    max-width:540px!important;
    height:74px!important;
    min-height:74px!important;
    display:flex!important;
    flex-direction:row!important;
    direction:ltr!important;
    align-items:center!important;
    justify-content:space-around!important;
    gap:4px!important;
    padding:7px 10px!important;
    margin:0!important;
    z-index:1000!important;
    border-radius:32px!important;
    background:
      radial-gradient(circle at 50% -20%,rgba(var(--accent-rgb),.18),transparent 46%),
      linear-gradient(180deg,rgba(24,30,38,.96),rgba(13,17,24,.94))!important;
    border:1px solid rgba(var(--accent-rgb),.18)!important;
    box-shadow:0 18px 38px rgba(0,0,0,.38),0 0 0 1px rgba(var(--accent-rgb),.05),inset 0 1px 0 rgba(255,255,255,.06)!important;
    backdrop-filter:blur(22px) saturate(145%)!important;
    -webkit-backdrop-filter:blur(22px) saturate(145%)!important;
    overflow:visible!important;
    opacity:1;
    visibility:visible!important;
    pointer-events:auto!important;
    filter:none;
    isolation:auto!important;
    contain:none!important;
    transition:transform .28s cubic-bezier(.2,.8,.2,1),opacity .22s ease,filter .22s ease,height .22s ease,border-radius .22s ease!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::before,
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::after{
    content:""!important;
    display:block!important;
    position:absolute!important;
    pointer-events:none!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::before{
    inset:-12px 20px auto 20px!important;
    height:34px!important;
    border-radius:0 0 36px 36px!important;
    background:radial-gradient(ellipse at center,rgba(var(--accent-rgb),.20),transparent 68%)!important;
    filter:blur(8px)!important;
    z-index:-1!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::after{
    inset:0!important;
    border-radius:inherit!important;
    background:linear-gradient(180deg,rgba(255,255,255,.08),transparent 42%)!important;
    z-index:0!important;
    box-shadow:none!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item{
    position:relative!important;
    z-index:1!important;
    flex:1 1 0!important;
    max-width:132px!important;
    min-width:62px!important;
    width:auto!important;
    height:58px!important;
    min-height:58px!important;
    padding:8px 10px!important;
    margin:0!important;
    display:flex!important;
    flex-direction:column!important;
    align-items:center!important;
    justify-content:center!important;
    gap:4px!important;
    cursor:pointer!important;
    opacity:.68!important;
    text-decoration:none!important;
    color:rgba(255,255,255,.82)!important;
    border:0!important;
    border-radius:28px!important;
    background:transparent!important;
    box-shadow:none!important;
    transform:none!important;
    transition:opacity .22s ease,background .22s ease,color .22s ease,transform .22s ease,box-shadow .22s ease!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item:hover{
    opacity:1!important;
    background:rgba(255,255,255,.05)!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active{
    min-width:96px!important;
    opacity:1!important;
    color:var(--accent)!important;
    background:linear-gradient(180deg,rgba(var(--accent-rgb),.24),rgba(var(--accent-rgb),.11))!important;
    border:1px solid rgba(var(--accent-rgb),.20)!important;
    box-shadow:0 12px 26px rgba(0,0,0,.24),0 0 22px rgba(var(--accent-rgb),.10),inset 0 1px 0 rgba(255,255,255,.08)!important;
    transform:translateY(-4px)!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active::before{
    content:""!important;
    display:block!important;
    position:absolute!important;
    inset:-5px!important;
    border-radius:32px!important;
    background:radial-gradient(circle at 50% 0%,rgba(var(--accent-rgb),.24),transparent 64%)!important;
    z-index:-1!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item::after{display:none!important}
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item svg{
    width:23px!important;
    height:23px!important;
    min-width:23px!important;
    min-height:23px!important;
    stroke:currentColor!important;
    fill:none!important;
    stroke-width:2.2!important;
    transform:none!important;
    filter:none!important;
    transition:transform .22s ease,stroke .22s ease!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active svg{transform:translateY(-1px)!important}
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item .nav-label{
    display:block!important;
    max-width:78px!important;
    margin:0!important;
    color:currentColor!important;
    font-size:10px!important;
    font-weight:800!important;
    line-height:1.1!important;
    white-space:nowrap!important;
    overflow:hidden!important;
    text-overflow:ellipsis!important;
  }
  /* Same homepage smart dock states. */
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav].nav-hidden{
    transform:translate(-50%,calc(100% + 26px))!important;
    opacity:0!important;
    pointer-events:none!important;
    filter:blur(1px)!important;
  }
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav].nav-compact{
    height:66px!important;
    min-height:66px!important;
    border-radius:30px!important;
    opacity:.96!important;
  }
}
@media(max-width:380px){
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]{width:calc(100% - 18px)!important;padding-inline:6px!important}
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item{min-width:54px!important;padding-inline:7px!important}
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active{min-width:84px!important}
  html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item .nav-label{font-size:9px!important;max-width:62px!important}
}
@media(min-width:992px){html body.watch-party-page .bottom-nav[data-mobile-bottom-nav]{display:none!important}}
</style>
<script id="bm-watch-party-home-footer-v40-js">
(function(){
  'use strict';
  function init(){
    var nav=document.querySelector('body.watch-party-page .bottom-nav[data-mobile-bottom-nav]');
    if(!nav)return;

    /* V49: low-end phones use the shared static dock. Do not install Watch Party's
       own scroll/RAF smart-floating controller on those devices. */
    if(document.documentElement.classList.contains('bm-nav-static')){
      nav.classList.remove('nav-hidden','nav-compact');
      nav.removeAttribute('aria-hidden');
      return;
    }

    /* Reset everything left by the V34-V39 experiments. */
    nav.classList.remove('bm-wp-home-dock-v39','bm-wp-home-active','bm-unified-bottom-nav-v14861917','nav-hidden','nav-compact');
    nav.removeAttribute('style');
    nav.removeAttribute('aria-hidden');
    nav.querySelectorAll('.nav-item').forEach(function(item){
      item.classList.remove('bm-wp-home-active');
      item.removeAttribute('style');
      item.classList.toggle('active',item.getAttribute('data-bm-nav-kind')==='home' || item.getAttribute('href')==='/');
    });

    /* Exact homepage smart-bottom-nav behavior. */
    var lastY=window.scrollY||0,ticking=false,minDelta=12;
    function shouldKeepVisible(){
      var activeElement=document.activeElement;
      return window.innerWidth>=992 ||
        window.scrollY<120 ||
        document.body.style.overflow==='hidden' ||
        document.querySelector('.player-chat-panel.open') ||
        document.querySelector('.sidebar-menu.open') ||
        (activeElement&&['INPUT','TEXTAREA','SELECT'].includes(activeElement.tagName));
    }
    function update(){
      var y=window.scrollY||0,diff=y-lastY;
      if(shouldKeepVisible()){
        nav.classList.remove('nav-hidden');
        nav.classList.toggle('nav-compact',y>220);
        lastY=y;ticking=false;return;
      }
      if(Math.abs(diff)>minDelta){
        nav.classList.toggle('nav-hidden',diff>0);
        nav.classList.toggle('nav-compact',y>220&&diff<=0);
        lastY=y;
      }
      ticking=false;
    }
    window.addEventListener('scroll',function(){if(!ticking){requestAnimationFrame(update);ticking=true;}},{passive:true});
    window.addEventListener('resize',update,{passive:true});
    document.addEventListener('focusin',update);
    document.addEventListener('focusout',function(){setTimeout(update,80)});
    update();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
</script>


<script src="/assets/js/bm-uiverse-elements-v42.js?v=42.0" defer></script>

<style id="bm-watch-party-lowend-static-dock-v49">
/* V49 — Watch Party obeys the same low-end static dock policy as the rest of BankMovie.
   High-end devices are intentionally untouched and keep the existing floating glass dock. */
@media (max-width:991px){
  html.bm-nav-static body.watch-party-page{
    padding-bottom:calc(76px + env(safe-area-inset-bottom,0px))!important;
  }
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav],
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav].nav-hidden,
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav].nav-compact{
    position:fixed!important;
    left:0!important;
    right:0!important;
    top:auto!important;
    bottom:0!important;
    transform:none!important;
    width:100%!important;
    max-width:none!important;
    min-height:68px!important;
    height:calc(68px + env(safe-area-inset-bottom,0px))!important;
    margin:0!important;
    padding:7px 10px calc(7px + env(safe-area-inset-bottom,0px))!important;
    border-radius:18px 18px 0 0!important;
    opacity:1!important;
    visibility:visible!important;
    pointer-events:auto!important;
    overflow:hidden!important;
    filter:none!important;
    -webkit-filter:none!important;
    -webkit-backdrop-filter:none!important;
    backdrop-filter:none!important;
    transition:none!important;
    animation:none!important;
    will-change:auto!important;
    background:
      linear-gradient(180deg,rgba(var(--accent-rgb,47,124,255),.20),rgba(var(--accent-rgb,47,124,255),.065)),
      linear-gradient(180deg,rgba(25,27,34,.99),rgba(11,13,19,.997))!important;
    border:0!important;
    border-top:1px solid rgba(var(--accent-rgb,47,124,255),.42)!important;
    box-shadow:0 -8px 22px rgba(0,0,0,.24),inset 0 1px 0 rgba(var(--accent-rgb,47,124,255),.18)!important;
  }
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::before,
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav]::after{
    display:none!important;
    content:none!important;
    filter:none!important;
  }
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item{
    flex:1 1 0!important;
    min-width:0!important;
    max-width:none!important;
    height:54px!important;
    min-height:54px!important;
    padding:7px 4px!important;
    margin:0!important;
    border-radius:16px!important;
    color:rgba(255,255,255,.88)!important;
    background:transparent!important;
    border:0!important;
    box-shadow:none!important;
    opacity:1!important;
    transform:none!important;
    transition:none!important;
    animation:none!important;
    filter:none!important;
    will-change:auto!important;
  }
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active{
    color:var(--accent,#2f7cff)!important;
    background:rgba(var(--accent-rgb,47,124,255),.13)!important;
    border:0!important;
    box-shadow:inset 0 1px 0 rgba(var(--accent-rgb,47,124,255),.32),0 2px 7px rgba(0,0,0,.10)!important;
  }
  html.bm-nav-static body.watch-party-page .bottom-nav[data-mobile-bottom-nav]>.nav-item.active::after{
    display:none!important;
    content:none!important;
  }
}
</style>

</body>
</html>
