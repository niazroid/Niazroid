<?php
declare(strict_types=1);

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-store');

$configUrl = 'https://' . preg_replace('/:\d+$/', '', (string)($_SERVER['HTTP_HOST'] ?? 'bankmovie.top')) . '/app_config.php';

echo "BankMovie V90 recovery check\n";
echo "Open this URL directly in the browser too:\n";
echo $configUrl . "\n\n";
echo "Expected in app_config.php JSON:\n";
echo "recovery_build = v90-archive-config\n";
echo "archive1_enabled = true / archive1_hidden = false\n";
echo "archive2_enabled = true / archive2_hidden = false\n";
echo "archive3_enabled = true / archive3_hidden = false\n";
echo "archive2_api_url = current-domain/api5.php\n";
