<?php
// admin_edit_movie.php - ویرایش فیلم با سیستم لاگین جدید
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
$adminPanelHealth = admin_panel_bootstrap($pdo);
$csrf_token = admin_csrf_token();
admin_enforce_csrf();

$movieId = intval($_GET['id'] ?? 0);
$movie = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
$movie->execute([$movieId]);
$movie = $movie->fetch();

if(!$movie){
  header('Location: admin.php');
  exit;
}

// دریافت اطلاعات تکمیلی از movie_extra_info
$extraInfo = $pdo->prepare("SELECT * FROM movie_extra_info WHERE imdb_code = ?");
$extraInfo->execute([$movie['imdb_code']]);
$extraInfo = $extraInfo->fetch() ?: [];

// دریافت لینک‌ها
$softLinks = $pdo->prepare("SELECT * FROM softsub_links WHERE movie_id = ?");
$softLinks->execute([$movieId]);
$softLinks = $softLinks->fetchAll();

$dubLinks = $pdo->prepare("SELECT * FROM dubbed_links WHERE movie_id = ?");
$dubLinks->execute([$movieId]);
$dubLinks = $dubLinks->fetchAll();

// ============================================
// لیست کامل کشورها (از عکس‌های ارسالی)
// ============================================
$allCountries = [
  'Afghanistan', 'Albania', 'Algeria', 'Argentina', 'Armenia', 'Australia', 'Austria', 
  'Azerbaijan', 'Bangladesh', 'Belarus', 'Belgium', 'Brazil', 'Bulgaria', 'Canada', 
  'Chile', 'China', 'Colombia', 'Croatia', 'Cuba', 'Czech Republic', 'Denmark', 
  'Dominican Republic', 'Ecuador', 'Egypt', 'Finland', 'France', 'Georgia', 'Germany', 
  'Greece', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran', 'Iraq', 
  'Ireland', 'Israel', 'Italy', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kuwait', 
  'Latvia', 'Lebanon', 'Lithuania', 'Luxembourg', 'Malaysia', 'Mauritius', 'Mexico', 
  'Morocco', 'Netherlands', 'New Zealand', 'Nigeria', 'North Korea', 'Norway', 'Oman', 
  'Pakistan', 'Peru', 'Philippines', 'Poland', 'Portugal', 'Qatar', 'Romania', 'Russia', 
  'Saudi Arabia', 'Serbia', 'Singapore', 'Slovakia', 'Slovenia', 'South Africa', 
  'South Korea', 'Soviet Union', 'Spain', 'Sri Lanka', 'Sudan', 'Sweden', 'Switzerland', 
  'Syria', 'Taiwan', 'Tajikistan', 'Thailand', 'Tunisia', 'Turkey', 'Turkmenistan', 
  'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States of America', 
  'Uruguay', 'Uzbekistan', 'Venezuela', 'Vietnam', 'Yemen'
];
sort($allCountries);

// ============================================
// لیست کامل زبان‌های اصلی
// ============================================
$allLanguages = [
  'English', 'Persian (Farsi)', 'Spanish', 'French', 'German', 'Italian', 'Portuguese', 
  'Russian', 'Arabic', 'Turkish', 'Dutch', 'Polish', 'Ukrainian', 'Romanian', 
  'Czech', 'Swedish', 'Greek', 'Hungarian', 'Hebrew', 'Thai', 'Vietnamese', 
  'Korean', 'Japanese', 'Chinese (Mandarin)', 'Hindi', 'Bengali', 'Urdu', 'Malay', 
  'Indonesian', 'Filipino', 'Swahili', 'Afrikaans', 'Serbian', 'Croatian', 
  'Bulgarian', 'Slovak', 'Slovenian', 'Estonian', 'Latvian', 'Lithuanian', 
  'Georgian', 'Armenian', 'Azerbaijani', 'Kazakh', 'Uzbek', 'Turkmen', 'Tajik', 
  'Pashto', 'Nepali', 'Sinhala', 'Burmese', 'Khmer', 'Lao', 'Mongolian'
];
sort($allLanguages);

// ============================================
// دریافت لیست ژانرها از دیتابیس
// ============================================
$genresList = $pdo->query("
  SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres, ',', n), ',', -1)) as genre
  FROM movies 
  CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers
  WHERE genres IS NOT NULL AND genres != ''
  HAVING genre != '' AND genre IS NOT NULL
  ORDER BY genre
")->fetchAll(PDO::FETCH_COLUMN);

// رده‌های سنی و وضعیت‌های سریال
$ratedList = ['G', 'PG', 'PG-13', 'R', 'NC-17', 'TV-Y', 'TV-Y7', 'TV-G', 'TV-PG', 'TV-14', 'TV-MA'];
$statusList = ['Returning Series', 'Ended', 'Canceled', 'In Production', 'Planned'];

// تبدیل کشورها و زبان‌های فعلی به آرایه برای نمایش تیک خورده
$currentCountries = !empty($movie['country']) ? array_map('trim', explode(',', $movie['country'])) : [];
$currentLanguages = !empty($extraInfo['language']) ? array_map('trim', explode(',', $extraInfo['language'])) : [];
$currentGenres = !empty($movie['genres']) ? array_map('trim', explode(',', $movie['genres'])) : [];

$message = '';
$error = '';

function admin_edit_upsert_extra(PDO $pdo, string $imdbCode, array $data): void {
  $imdbCode = trim($imdbCode);
  if($imdbCode === '' || !admin_panel_table_exists($pdo, 'movie_extra_info')) return;
  $allowed = ['language','production_companies','status','rated','seasons','episodes'];
  $filtered = [];
  foreach($allowed as $column){
    if(array_key_exists($column, $data) && admin_panel_column_exists($pdo, 'movie_extra_info', $column)) $filtered[$column] = $data[$column];
  }
  if(!$filtered) return;
  $set=[]; $values=[];
  foreach($filtered as $column=>$value){ $set[]='`'.$column.'` = ?'; $values[]=$value; }
  if(admin_panel_column_exists($pdo, 'movie_extra_info', 'updated_at')) $set[]='updated_at = NOW()';
  $stmt=$pdo->prepare('UPDATE movie_extra_info SET '.implode(', ',$set).' WHERE imdb_code = ?');
  $stmt->execute(array_merge($values,[$imdbCode]));
  $check=$pdo->prepare('SELECT COUNT(*) FROM movie_extra_info WHERE imdb_code = ?'); $check->execute([$imdbCode]);
  if((int)$check->fetchColumn()>0) return;
  $columns=['imdb_code']; $ph=['?']; $insertValues=[$imdbCode];
  foreach($filtered as $column=>$value){ $columns[]='`'.$column.'`'; $ph[]='?'; $insertValues[]=$value; }
  if(admin_panel_column_exists($pdo, 'movie_extra_info', 'updated_at')){ $columns[]='updated_at'; $ph[]='NOW()'; }
  $pdo->prepare('INSERT INTO movie_extra_info ('.implode(',',$columns).') VALUES ('.implode(',',$ph).')')->execute($insertValues);
}

if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_movie'])){
  $title = trim($_POST['title'] ?? '');
  $titleFa = trim($_POST['title_fa'] ?? '');
  $type = $_POST['type'] ?? 'movie';
  $year = intval($_POST['year'] ?? 0);
  $imdbRate = floatval($_POST['imdb_rate'] ?? 0);
  $imdbVotes = intval($_POST['imdb_votes'] ?? 0);
  $imdbCode = trim($_POST['imdb_code'] ?? '');
  $description = trim($_POST['description'] ?? '');
  $director = trim($_POST['director'] ?? '');
  $actors = trim($_POST['actors'] ?? '');
  $productionCompanies = trim($_POST['production_companies'] ?? '');
  $status = trim($_POST['status'] ?? '');
  $rated = trim($_POST['rated'] ?? '');
  $seasons = !empty($_POST['seasons']) ? intval($_POST['seasons']) : null;
  $episodes = !empty($_POST['episodes']) ? intval($_POST['episodes']) : null;
  
  // کشورها و زبان‌ها از چکباکس‌ها
  $country = isset($_POST['countries']) && is_array($_POST['countries']) ? implode(', ', array_map('trim', $_POST['countries'])) : '';
  $language = isset($_POST['languages']) && is_array($_POST['languages']) ? implode(', ', array_map('trim', $_POST['languages'])) : '';
  // ژانرها از چکباکس
  $genres = isset($_POST['genres_list']) ? trim($_POST['genres_list']) : '';
  
  if(empty($title)){
    $error = "عنوان انگلیسی الزامی است";
  } else {
    try {
      $pdo->beginTransaction();
      
      // بروزرسانی جدول movies
      $stmt = $pdo->prepare("UPDATE movies SET 
        title=?, title_fa=?, type=?, year=?, imdb_rate=?, imdb_votes=?, imdb_code=?, description=?,
        genres=?, director=?, country=?, actors=?, updated_at=NOW() 
        WHERE id=?");
      $stmt->execute([$title, $titleFa, $type, $year, $imdbRate, $imdbVotes, $imdbCode, $description,
              $genres, $director, $country, $actors, $movieId]);
      
      // بروزرسانی یا درج در movie_extra_info، حتی روی دیتابیس قدیمی بدون UNIQUE
      if(!empty($imdbCode)){
        admin_edit_upsert_extra($pdo, $imdbCode, [
          'language'=>$language, 'production_companies'=>$productionCompanies, 'status'=>$status,
          'rated'=>$rated, 'seasons'=>$seasons, 'episodes'=>$episodes
        ]);
      }
      
      // حذف لینک‌های قدیمی
      $pdo->prepare("DELETE FROM softsub_links WHERE movie_id=?")->execute([$movieId]);
      $pdo->prepare("DELETE FROM dubbed_links WHERE movie_id=?")->execute([$movieId]);
      
      // لینک‌های زیرنویس دار
      if(isset($_POST['soft_quality']) && is_array($_POST['soft_quality'])){
        $softStmt = $pdo->prepare("INSERT INTO softsub_links (movie_id, quality, url, size, season) VALUES (?, ?, ?, ?, ?)");
        for($i=0; $i<count($_POST['soft_quality']); $i++){
          if(!empty($_POST['soft_url'][$i])){
            $season = ($type !== 'movie') ? intval($_POST['soft_season'][$i] ?? 1) : null;
            $softStmt->execute([$movieId, $_POST['soft_quality'][$i], $_POST['soft_url'][$i], $_POST['soft_size'][$i] ?? '', $season]);
          }
        }
      }
      
      // لینک‌های دوبله فارسی
      if(isset($_POST['dub_quality']) && is_array($_POST['dub_quality'])){
        $dubStmt = $pdo->prepare("INSERT INTO dubbed_links (movie_id, quality, url, size, season) VALUES (?, ?, ?, ?, ?)");
        for($i=0; $i<count($_POST['dub_quality']); $i++){
          if(!empty($_POST['dub_url'][$i])){
            $season = ($type !== 'movie') ? intval($_POST['dub_season'][$i] ?? 1) : null;
            $dubStmt->execute([$movieId, $_POST['dub_quality'][$i], $_POST['dub_url'][$i], $_POST['dub_size'][$i] ?? '', $season]);
          }
        }
      }
      // آپلود کاور جدید
      if(isset($_FILES['poster']) && ($_FILES['poster']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE){
        admin_safe_image_upload($_FILES['poster'], 'posters/', (string)($imdbCode ?: $movieId), 82);
      }
      
      $pdo->commit();
      $message = "تغییرات با موفقیت ذخیره شد";
      header("Location: admin_edit_movie.php?id=$movieId&msg=" . urlencode($message));
      exit;
    } catch(Throwable $e){
      if($pdo->inTransaction()) $pdo->rollBack();
      $error = "خطا در ذخیره: " . $e->getMessage();
    }
  }
}

if(isset($_GET['msg'])) $message = $_GET['msg'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ویرایش فیلم | پنل مدیریت بانک مووی</title>
  <style>

/* ================= BankMovie Admin Pro UI v2 ================= */
:root{
  --pro-bg:#07090d;
  --pro-surface:rgba(18,22,30,.78);
  --pro-surface-2:rgba(11,14,20,.88);
  --pro-border:rgba(255,255,255,.09);
  --pro-border-strong:rgba(54,255,159,.32);
  --pro-text:#f7fbff;
  --pro-muted:#9aa6b5;
  --pro-accent:#36ff9f;
  --pro-accent-2:#38bdf8;
  --pro-danger:#fb7185;
  --pro-warning:#fbbf24;
  --pro-radius:26px;
  --pro-shadow:0 28px 80px rgba(0,0,0,.42);
}
html{scroll-behavior:smooth;}
body, body.admin-shell{
  background:
    radial-gradient(circle at 85% -5%, rgba(54,255,159,.12), transparent 34%),
    radial-gradient(circle at 5% 15%, rgba(56,189,248,.10), transparent 32%),
    linear-gradient(180deg,#090b10,#050609 72%) !important;
  color:var(--pro-text) !important;
  font-family:Vazirmatn, IRANSans, Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif !important;
  letter-spacing:-.01em;
}
body::before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.025) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.025) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,rgba(0,0,0,.9),transparent 78%);}
.container{width:min(100%,1640px) !important;}
.header,.admin-header,.card,.add-collection-form,.login-box{
  background:linear-gradient(145deg,rgba(20,25,34,.86),rgba(9,12,18,.78)) !important;
  border:1px solid var(--pro-border) !important;
  box-shadow:var(--pro-shadow) !important;
  backdrop-filter:blur(24px) saturate(145%) !important;
}
.header,.admin-header{position:sticky;top:14px;z-index:50;border-radius:30px !important;}
.card{border-radius:var(--pro-radius) !important;overflow:hidden;}
.card:hover,.collection-card:hover,.movie-row:hover,.movie-item:hover,.link-row:hover{border-color:var(--pro-border-strong) !important;box-shadow:0 22px 70px rgba(0,0,0,.34) !important;}
.card h2,.card h3,.card-header h3,h2,h3,h4,.logo,.logo-text{
  letter-spacing:-.03em;
}
.logo svg,.logo-area svg,.card h2 svg,.card h3 svg,.card-header svg,.back-btn svg,.btn svg,.btn-secondary svg{filter:drop-shadow(0 0 12px rgba(54,255,159,.22));}
input,select,textarea,.search-input{
  background:rgba(4,7,12,.72) !important;
  border:1px solid rgba(255,255,255,.10) !important;
  border-radius:18px !important;
  color:var(--pro-text) !important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.03) !important;
}
input:focus,select:focus,textarea:focus,.search-input:focus{
  border-color:var(--pro-accent) !important;
  box-shadow:0 0 0 4px rgba(54,255,159,.12), inset 0 1px 0 rgba(255,255,255,.05) !important;
}
label{color:var(--pro-muted) !important;font-weight:650 !important;}
.btn,.btn-new-collection,button[type="submit"]{
  background:linear-gradient(135deg,var(--pro-accent),#7dd3fc) !important;
  color:#03110a !important;
  border:0 !important;
  border-radius:999px !important;
  box-shadow:0 16px 34px rgba(54,255,159,.18) !important;
}
.btn:hover,.btn-new-collection:hover,button[type="submit"]:hover{transform:translateY(-2px);box-shadow:0 22px 45px rgba(54,255,159,.24) !important;}
.btn-secondary,.back-btn,.back-link,.tab,.pagination a{
  background:rgba(255,255,255,.065) !important;
  border:1px solid rgba(255,255,255,.10) !important;
  color:var(--pro-text) !important;
  border-radius:999px !important;
}
.btn-secondary:hover,.back-btn:hover,.back-link:hover,.tab.active,.pagination a.active,.pagination a:hover{
  color:#03110a !important;
  background:linear-gradient(135deg,var(--pro-accent),#7dd3fc) !important;
  border-color:transparent !important;
}
.btn-danger,.remove-link{
  background:rgba(251,113,133,.12) !important;
  border:1px solid rgba(251,113,133,.32) !important;
  color:#fecdd3 !important;
  border-radius:999px !important;
}
.btn-danger:hover,.remove-link:hover{background:rgba(251,113,133,.22) !important;}
.badge{border:1px solid rgba(255,255,255,.10);background:rgba(255,255,255,.07);border-radius:999px;padding:.24rem .62rem;}
.badge-warning{background:rgba(251,191,36,.13) !important;color:#fde68a !important;border-color:rgba(251,191,36,.25) !important;}
table{width:100%;border-collapse:separate !important;border-spacing:0 10px !important;}
th{color:var(--pro-muted) !important;font-size:12px;text-transform:none;background:rgba(255,255,255,.045) !important;}
td,th{padding:14px 16px !important;border-bottom:0 !important;}
tbody tr{background:rgba(255,255,255,.035) !important;box-shadow:0 10px 30px rgba(0,0,0,.16);}
tbody tr td:first-child{border-radius:0 18px 18px 0;} tbody tr td:last-child{border-radius:18px 0 0 18px;}
.movie-row,.movie-item,.link-row,.collection-card,.admin-pick-item,.search-result-item,.live-search-result-item{
  background:rgba(5,8,14,.66) !important;
  border:1px solid var(--pro-border) !important;
  border-radius:22px !important;
}
.collection-list{grid-template-columns:repeat(auto-fill,minmax(220px,1fr)) !important;}
.collection-cover,.poster-preview img,.poster-preview{box-shadow:0 18px 38px rgba(0,0,0,.28);}
.checkbox-grid,.genres-checkbox-group{background:rgba(4,7,12,.58) !important;border-color:var(--pro-border) !important;}
.checkbox-item,.genre-checkbox{border:1px solid transparent;}
.checkbox-item:hover,.genre-checkbox:hover{border-color:var(--pro-border-strong) !important;background:rgba(54,255,159,.09) !important;}
.toast{background:rgba(8,12,18,.92) !important;border-radius:999px !important;box-shadow:var(--pro-shadow) !important;}
.modal{backdrop-filter:blur(10px);}
.modal-content{background:linear-gradient(145deg,rgba(20,25,34,.96),rgba(9,12,18,.94)) !important;border:1px solid var(--pro-border-strong) !important;border-radius:30px !important;box-shadow:var(--pro-shadow) !important;}
@media(max-width:860px){body{padding:14px !important}.header,.admin-header{position:relative;top:0}.card{padding:18px !important}.form-grid{grid-template-columns:1fr !important}td,th{white-space:nowrap}.admin-actions{width:100%;justify-content:space-between}.collection-list{grid-template-columns:repeat(2,minmax(0,1fr)) !important}}
@media(max-width:520px){.collection-list{grid-template-columns:1fr !important}.action-buttons,.collection-actions{justify-content:stretch}.btn,.btn-secondary,.back-btn,.back-link{width:100%;justify-content:center}.logo,.logo-text{font-size:20px !important}}


    /* تمام استایل‌های قبلی بدون تغییر */
    * { margin: 0; padding: 0; box-sizing: border-box; }
    :root {
      --bg-primary: #0a0a0c;
      --bg-secondary: #121215;
      --bg-card: rgba(18, 18, 22, 0.7);
      --accent: #36ff9f;
      --accent-dark: #2ecc8a;
      --accent-glow: rgba(54, 255, 159, 0.15);
      --text-primary: #ffffff;
      --text-secondary: #a0a0a8;
      --border: rgba(255, 255, 255, 0.08);
      --border-accent: rgba(54, 255, 159, 0.3);
      --danger: #ff5555;
      --danger-glow: rgba(255, 85, 85, 0.15);
      --gradient: linear-gradient(135deg, #36ff9f, #2ecc8a);
    }
    body { background: var(--bg-primary); color: var(--text-primary); font-family: system-ui, sans-serif; padding: 24px; }
    .container { max-width: 1200px; margin: 0 auto; }
    .header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 32px; padding-bottom: 20px; border-bottom: 1px solid var(--border); flex-wrap: wrap; gap: 16px; }
    .logo { font-size: 24px; font-weight: 800; background: var(--gradient); -webkit-background-clip: text; background-clip: text; color: transparent; display: flex; align-items: center; gap: 10px; }
    .back-btn { background: var(--bg-card); backdrop-filter: blur(10px); border: 1px solid var(--border); padding: 8px 20px; border-radius: 40px; color: var(--text-primary); text-decoration: none; font-size: 14px; transition: all 0.2s; display: inline-flex; align-items: center; gap: 8px; }
    .back-btn:hover { border-color: var(--accent); background: var(--accent-glow); transform: translateY(-2px); }
    .card { background: var(--bg-card); backdrop-filter: blur(12px); border: 1px solid var(--border); border-radius: 32px; padding: 28px; margin-bottom: 28px; transition: all 0.3s ease; }
    .card:hover { border-color: var(--border-accent); box-shadow: 0 8px 32px rgba(0, 0, 0, 0.3); }
    .card h2 { color: var(--accent); font-size: 26px; margin-bottom: 28px; display: flex; align-items: center; gap: 12px; border-right: 3px solid var(--accent); padding-right: 16px; }
    .card h3 { color: var(--accent); font-size: 18px; margin: 24px 0 16px 0; display: flex; align-items: center; gap: 10px; }
    .form-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 20px; margin-bottom: 20px; }
    .form-group { margin-bottom: 0; }
    .form-group.full-width { grid-column: 1 / -1; }
    label { display: block; margin-bottom: 8px; font-size: 13px; font-weight: 500; color: var(--text-secondary); letter-spacing: 0.3px; }
    input, select, textarea { width: 100%; padding: 12px 16px; background: rgba(10, 10, 12, 0.8); border: 1px solid var(--border); border-radius: 20px; color: var(--text-primary); font-size: 14px; transition: all 0.2s; }
    input:focus, select:focus, textarea:focus { outline: none; border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-glow); }
    .info-section { background: rgba(54, 255, 159, 0.03); border-radius: 24px; padding: 20px; margin: 20px 0; border: 1px solid var(--border-accent); }
    .info-section h4 { color: var(--accent); margin-bottom: 16px; font-size: 16px; }
    .checkbox-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
      gap: 8px;
      max-height: 300px;
      overflow-y: auto;
      padding: 12px;
      background: var(--bg-card);
      border-radius: 20px;
      border: 1px solid var(--border);
      margin-top: 10px;
    }
    .checkbox-item {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 13px;
      padding: 4px 8px;
      border-radius: 8px;
      cursor: pointer;
      transition: 0.2s;
    }
    .checkbox-item:hover { background: rgba(54,255,159,0.1); }
    .checkbox-item input { width: 16px; height: 16px; margin: 0; cursor: pointer; }
    .checkbox-item label { margin: 0; cursor: pointer; font-size: 13px; color: var(--text-primary); }
    .genres-checkbox-group { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 10px; max-height: 150px; overflow-y: auto; padding: 10px; background: var(--bg-card); border-radius: 20px; }
    .genre-checkbox { display: flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.05); padding: 6px 12px; border-radius: 40px; cursor: pointer; transition: 0.2s; }
    .genre-checkbox:hover { background: rgba(54,255,159,0.15); }
    .genre-checkbox input { width: auto; margin: 0; }
    .link-row { background: rgba(0, 0, 0, 0.3); border-radius: 24px; padding: 20px; margin-bottom: 16px; border: 1px solid var(--border); position: relative; }
    .link-row .row-3 { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 12px; margin-top: 12px; }
    .remove-link { position: absolute; top: 12px; left: 12px; background: var(--danger-glow); color: var(--danger); border: 1px solid rgba(255, 85, 85, 0.3); padding: 4px 12px; border-radius: 40px; font-size: 11px; cursor: pointer; }
    .remove-link:hover { background: rgba(255, 85, 85, 0.3); transform: scale(0.98); }
    .btn { background: var(--gradient); color: #000; border: none; padding: 12px 28px; border-radius: 60px; font-weight: 700; font-size: 14px; cursor: pointer; transition: all 0.2s; display: inline-flex; align-items: center; gap: 10px; }
    .btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(54, 255, 159, 0.3); }
    .btn-secondary { background: rgba(255, 255, 255, 0.08); color: var(--text-primary); border: 1px solid var(--border); padding: 10px 20px; border-radius: 60px; font-size: 13px; cursor: pointer; display: inline-flex; align-items: center; gap: 8px; }
    .btn-secondary:hover { background: var(--accent-glow); border-color: var(--accent); }
    .poster-preview { display: flex; align-items: center; gap: 20px; flex-wrap: wrap; margin-bottom: 20px; }
    .poster-preview img { width: 100px; height: 150px; border-radius: 16px; object-fit: cover; background: #1a1a1e; border: 1px solid var(--border); }
    .toast { position: fixed; bottom: 30px; right: 30px; background: var(--bg-secondary); border: 1px solid var(--accent); border-radius: 60px; padding: 14px 28px; z-index: 1000; animation: slideIn 0.3s ease; backdrop-filter: blur(10px); display: flex; align-items: center; gap: 10px; font-size: 14px; }
    .toast.error { border-color: var(--danger); }
    @keyframes slideIn { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
    .action-buttons { display: flex; gap: 16px; justify-content: flex-end; margin-top: 32px; flex-wrap: wrap; }
    .icon { width: 18px; height: 18px; stroke: currentColor; stroke-width: 1.8; fill: none; vertical-align: middle; }
    @media (max-width: 768px) {
      body { padding: 16px; }
      .card { padding: 20px; }
      .form-grid { grid-template-columns: 1fr; }
      .checkbox-grid { grid-template-columns: repeat(auto-fill, minmax(130px, 1fr)); }
      .action-buttons { justify-content: center; }
      .link-row .row-3 { grid-template-columns: 1fr; }
    }
  

/* ================= BankMovie Admin Ultra Pro v3 Overrides ================= */
:root{--admin-bg:#06080d;--admin-panel:rgba(13,17,25,.78);--admin-line:rgba(255,255,255,.10);--admin-line-strong:rgba(54,255,159,.34);--admin-text:#f8fbff;--admin-muted:#96a3b4;--admin-green:#36ff9f;--admin-blue:#67e8f9;--admin-red:#fb7185;--admin-radius:28px;}
body{padding:26px;background:radial-gradient(circle at 82% 0,rgba(54,255,159,.16),transparent 32%),radial-gradient(circle at 8% 18%,rgba(103,232,249,.12),transparent 30%),linear-gradient(180deg,#0a0d14,#05070b 78%) !important;color:var(--admin-text) !important;}
.container{max-width:1540px !important;}.header{position:sticky;top:14px;z-index:50;padding:18px 22px !important;border-radius:32px !important;background:linear-gradient(135deg,rgba(20,26,38,.88),rgba(8,11,18,.84)) !important;border:1px solid var(--admin-line) !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;backdrop-filter:blur(22px);}
.logo{font-size:clamp(20px,2vw,30px) !important;}.card,.info-section{position:relative;background:linear-gradient(150deg,rgba(19,25,37,.82),rgba(7,10,16,.76)) !important;border:1px solid var(--admin-line) !important;border-radius:32px !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;}.card:before{content:"";position:absolute;inset:0 0 auto 0;height:1px;background:linear-gradient(90deg,transparent,rgba(54,255,159,.45),transparent);opacity:.7;}
.card h2,.card h3,.info-section h4{color:#fff !important;}.form-grid{gap:18px !important;}input,select,textarea,.mini-filter-input{background:rgba(3,6,12,.72) !important;border:1px solid rgba(255,255,255,.11) !important;border-radius:18px !important;color:var(--admin-text) !important;}input:focus,select:focus,textarea:focus,.mini-filter-input:focus{border-color:var(--admin-green) !important;box-shadow:0 0 0 4px rgba(54,255,159,.13) !important;}.mini-filter-input{width:100%;margin:0 0 10px 0;padding:11px 14px !important;font-size:13px;}.checkbox-grid.filterable-checklist,.genres-checkbox-group.filterable-checklist{max-height:260px !important;background:rgba(4,8,14,.62) !important;border-radius:20px !important;border:1px solid rgba(255,255,255,.09) !important;}.checkbox-item,.genre-checkbox{min-height:36px;background:rgba(255,255,255,.035);border:1px solid transparent;border-radius:14px !important;}.checkbox-item:hover,.genre-checkbox:hover{background:rgba(54,255,159,.10) !important;border-color:rgba(54,255,159,.28) !important;}.link-row{background:linear-gradient(135deg,rgba(12,17,26,.78),rgba(4,7,12,.68)) !important;border:1px solid rgba(255,255,255,.09) !important;border-radius:24px !important;}.btn{background:linear-gradient(135deg,var(--admin-green),var(--admin-blue)) !important;color:#03110a !important;}.btn-secondary,.back-btn{background:rgba(255,255,255,.065) !important;border:1px solid rgba(255,255,255,.10) !important;}.poster-preview img{box-shadow:0 22px 52px rgba(0,0,0,.36);}.toast{background:rgba(8,12,18,.94) !important;border-radius:999px !important;box-shadow:0 24px 70px rgba(0,0,0,.34) !important;}@media(max-width:760px){body{padding:14px}.header{position:relative;top:0}.card{padding:18px !important}}

  </style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<?php if (!function_exists('bm_site_bool') || bm_site_bool('ui_neon_checkbox_enabled', true)): ?>
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-uiverse-v14843.css?v=14843">
<link rel="stylesheet" href="/assets/css/bm-neon-checkbox-adapter-v14843.css?v=14843">
<style id="bm-neon-checkbox-settings">.neon-checkbox{--primary:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_color','#00ffaa'),ENT_QUOTES,'UTF-8') : '#00ffaa' ?>;--primary-dark:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_dark_color','#00cc88'),ENT_QUOTES,'UTF-8') : '#00cc88' ?>;--primary-light:<?= function_exists('bm_site_get') ? htmlspecialchars((string)bm_site_get('ui_neon_checkbox_light_color','#88ffdd'),ENT_QUOTES,'UTF-8') : '#88ffdd' ?>;--size:<?= function_exists('bm_site_get') ? max(24,min(38,(int)bm_site_get('ui_neon_checkbox_size',30))) : 30 ?>px}</style>
<script src="/assets/js/bm-neon-checkbox-v14843.js?v=14843" defer></script>
<?php endif; ?>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="admin-shell bm-admin-unified">
<div class="container">
  <div class="header">
    <div class="logo">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg>
      بانک مووی | ویرایش فیلم
    </div>
    <a href="admin.php" class="back-btn">
      <svg class="icon" viewBox="0 0 24 24" stroke="currentColor"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
      بازگشت به مدیریت
    </a>
  </div>
  
  <?php if($message): ?>
  <div class="toast">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#36ff9f"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
    <?= htmlspecialchars($message) ?>
  </div>
  <script>setTimeout(()=>document.querySelector('.toast')?.remove(),3000);</script>
  <?php endif; ?>
  
  <?php if($error): ?>
  <div class="toast error">
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#ff5555"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
    <?= htmlspecialchars($error) ?>
  </div>
  <script>setTimeout(()=>document.querySelector('.toast')?.remove(),4000);</script>
  <?php endif; ?>
  
  <form method="POST" enctype="multipart/form-data" id="editForm">
      <?= admin_csrf_input() ?>
    <input type="hidden" name="edit_movie" value="1">
    
    <div class="card">
      <h2>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 14.66V20a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5.34"/><polygon points="18 2 22 6 12 16 8 16 8 12 18 2"/></svg>
        ویرایش: <?= htmlspecialchars($movie['title_fa'] ?: $movie['title']) ?>
      </h2>
      
      <div class="form-grid">
        <div class="form-group"><label>عنوان (انگلیسی)</label><input type="text" name="title" value="<?= htmlspecialchars($movie['title']) ?>" required></div>
        <div class="form-group"><label>عنوان (فارسی)</label><input type="text" name="title_fa" value="<?= htmlspecialchars($movie['title_fa']) ?>"></div>
        <div class="form-group"><label>نوع</label><select name="type" id="movieType"><option value="movie" <?= $movie['type']=='movie'?'selected':'' ?>>فیلم سینمایی</option><option value="tvSeries" <?= $movie['type']=='tvSeries'?'selected':'' ?>>سریال</option></select></div>
        <div class="form-group"><label>سال</label><input type="number" name="year" value="<?= htmlspecialchars($movie['year']) ?>"></div>
        <div class="form-group"><label>امتیاز IMDb</label><input type="number" step="0.1" name="imdb_rate" value="<?= htmlspecialchars($movie['imdb_rate']) ?>"></div>
        <div class="form-group"><label>تعداد رای‌ها</label><input type="number" name="imdb_votes" value="<?= htmlspecialchars($movie['imdb_votes']) ?>"></div>
        <div class="form-group"><label>کد IMDb</label><input type="text" name="imdb_code" id="imdbCode" value="<?= htmlspecialchars($movie['imdb_code']) ?>" placeholder="tt1234567"></div>
      </div>
      
      <!-- اطلاعات تکمیلی با چکباکس کشور و زبان -->
      <div class="info-section">
        <h4>اطلاعات تکمیلی</h4>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
          
          <!-- کشورها (چکباکس چندستونه) -->
          <div class="form-group">
            <label>کشور(ها)</label>
            <input type="search" class="mini-filter-input" data-filter-target="countriesChecklist" placeholder="جستجوی کشور...">
            <div class="checkbox-grid filterable-checklist" id="countriesChecklist">
              <?php foreach($allCountries as $c): ?>
              <label class="checkbox-item">
                <input type="checkbox" name="countries[]" value="<?= htmlspecialchars($c) ?>" <?= in_array($c, $currentCountries) ? 'checked' : '' ?>>
                <span><?= htmlspecialchars($c) ?></span>
              </label>
              <?php endforeach; ?>
            </div>
          </div>
          
          <!-- زبان‌ها (چکباکس چندستونه) -->
          <div class="form-group">
            <label>زبان(ها)</label>
            <input type="search" class="mini-filter-input" data-filter-target="languagesChecklist" placeholder="جستجوی زبان...">
            <div class="checkbox-grid filterable-checklist" id="languagesChecklist">
              <?php foreach($allLanguages as $l): ?>
              <label class="checkbox-item">
                <input type="checkbox" name="languages[]" value="<?= htmlspecialchars($l) ?>" <?= in_array($l, $currentLanguages) ? 'checked' : '' ?>>
                <span><?= htmlspecialchars($l) ?></span>
              </label>
              <?php endforeach; ?>
            </div>
          </div>
          
          <div class="form-group"><label>کارگردان</label><input type="text" name="director" value="<?= htmlspecialchars($movie['director']) ?>" placeholder="نام کارگردان"></div>
          <div class="form-group"><label>بازیگران (با کاما)</label><input type="text" name="actors" value="<?= htmlspecialchars($movie['actors']) ?>" placeholder="نام بازیگران"></div>
          <div class="form-group"><label>شرکت‌های تولیدکننده</label><input type="text" name="production_companies" value="<?= htmlspecialchars($extraInfo['production_companies'] ?? '') ?>" placeholder="مثال: Warner Bros"></div>
          <div class="form-group"><label>وضعیت (فقط سریال)</label>
            <select name="status">
              <option value="">انتخاب کنید</option>
              <?php foreach($statusList as $s): ?>
                <option value="<?= htmlspecialchars($s) ?>" <?= ($extraInfo['status'] ?? '') == $s ? 'selected' : '' ?>><?= htmlspecialchars($s) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label>رده سنی</label>
            <select name="rated">
              <option value="">انتخاب کنید</option>
              <?php foreach($ratedList as $r): ?>
                <option value="<?= htmlspecialchars($r) ?>" <?= ($extraInfo['rated'] ?? '') == $r ? 'selected' : '' ?>><?= htmlspecialchars($r) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group"><label>تعداد فصل‌ها (سریال)</label><input type="number" name="seasons" value="<?= htmlspecialchars($extraInfo['seasons'] ?? '') ?>" placeholder="0"></div>
          <div class="form-group"><label>تعداد قسمت‌ها (سریال)</label><input type="number" name="episodes" value="<?= htmlspecialchars($extraInfo['episodes'] ?? '') ?>" placeholder="0"></div>
        </div>
        
        <!-- ژانرها (چکباکس) -->
        <div class="form-group">
          <label>ژانرها</label>
          <input type="search" class="mini-filter-input" data-filter-target="genresCheckboxGroup" placeholder="جستجوی ژانر...">
          <div class="genres-checkbox-group filterable-checklist" id="genresCheckboxGroup">
            <?php foreach($genresList as $genre): ?>
            <label class="genre-checkbox">
              <input type="checkbox" value="<?= htmlspecialchars($genre) ?>" <?= in_array($genre, $currentGenres) ? 'checked' : '' ?>>
              <span><?= htmlspecialchars($genre) ?></span>
            </label>
            <?php endforeach; ?>
          </div>
          <input type="hidden" name="genres_list" id="genresHidden" value="<?= htmlspecialchars($movie['genres']) ?>">
          <small style="color: var(--text-secondary);">ژانرهای انتخاب شده با کاما ذخیره می‌شوند</small>
        </div>
      </div>
      
      <div class="form-group full-width">
        <label>خلاصه داستان</label>
        <textarea name="description" rows="5"><?= htmlspecialchars($movie['description']) ?></textarea>
      </div>
      
      <div class="poster-preview">
        <?php $posterPath = 'posters/' . ($movie['imdb_code'] ?: $movie['id']) . '.webp'; ?>
        <img src="<?= $posterPath ?>" id="posterPreview" onerror="this.style.display='none'">
        <div style="flex:1">
          <label>کاور جدید (اختیاری)</label>
          <input type="file" name="poster" id="posterInput" accept="image/jpeg,image/png,image/webp">
        </div>
      </div>
    </div>
    
    <!-- لینک‌های زیرنویس دار -->
    <div class="card">
      <h3>لینک‌های زیرنویس فارسی</h3>
      <div id="softLinksContainer">
        <?php if(count($softLinks) > 0): ?>
          <?php foreach($softLinks as $link): ?>
          <div class="link-row">
            <button type="button" class="remove-link" onclick="this.closest('.link-row').remove()">حذف</button>
            <div class="row-3">
              <input type="text" name="soft_quality[]" value="<?= htmlspecialchars($link['quality']) ?>" placeholder="کیفیت">
              <input type="text" name="soft_url[]" value="<?= htmlspecialchars($link['url']) ?>" placeholder="لینک دانلود">
              <input type="text" name="soft_size[]" value="<?= htmlspecialchars($link['size']) ?>" placeholder="حجم">
              <?php if($movie['type'] !== 'movie'): ?>
              <input type="number" name="soft_season[]" value="<?= $link['season'] ?>" placeholder="شماره فصل" class="season-field">
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
        <div class="link-row">
          <button type="button" class="remove-link" onclick="this.closest('.link-row').remove()">حذف</button>
          <div class="row-3">
            <input type="text" name="soft_quality[]" placeholder="کیفیت">
            <input type="text" name="soft_url[]" placeholder="لینک دانلود">
            <input type="text" name="soft_size[]" placeholder="حجم">
            <?php if($movie['type'] !== 'movie'): ?>
            <input type="number" name="soft_season[]" placeholder="شماره فصل" class="season-field">
            <?php endif; ?>
          </div>
        </div>
      </div>
      <button type="button" id="addSoftLinkBtn" class="btn-secondary" style="margin-top: 12px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        افزودن لینک زیرنویس دیگر
      </button>
    </div>
    
    <!-- لینک‌های دوبله فارسی -->
    <div class="card">
      <h3>لینک‌های دوبله فارسی</h3>
      <div id="dubLinksContainer">
        <?php if(count($dubLinks) > 0): ?>
          <?php foreach($dubLinks as $link): ?>
          <div class="link-row">
            <button type="button" class="remove-link" onclick="this.closest('.link-row').remove()">حذف</button>
            <div class="row-3">
              <input type="text" name="dub_quality[]" value="<?= htmlspecialchars($link['quality']) ?>" placeholder="کیفیت">
              <input type="text" name="dub_url[]" value="<?= htmlspecialchars($link['url']) ?>" placeholder="لینک دانلود">
              <input type="text" name="dub_size[]" value="<?= htmlspecialchars($link['size']) ?>" placeholder="حجم">
              <?php if($movie['type'] !== 'movie'): ?>
              <input type="number" name="dub_season[]" value="<?= $link['season'] ?>" placeholder="شماره فصل" class="season-field">
              <?php endif; ?>
            </div>
          </div>
          <?php endforeach; ?>
        <?php endif; ?>
        <div class="link-row">
          <button type="button" class="remove-link" onclick="this.closest('.link-row').remove()">حذف</button>
          <div class="row-3">
            <input type="text" name="dub_quality[]" placeholder="کیفیت">
            <input type="text" name="dub_url[]" placeholder="لینک دانلود">
            <input type="text" name="dub_size[]" placeholder="حجم">
            <?php if($movie['type'] !== 'movie'): ?>
            <input type="number" name="dub_season[]" placeholder="شماره فصل" class="season-field">
            <?php endif; ?>
          </div>
        </div>
      </div>
      <button type="button" id="addDubLinkBtn" class="btn-secondary" style="margin-top: 12px;">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        افزودن لینک دوبله دیگر
      </button>
    </div>
    
    <div class="action-buttons">
      <button type="submit" class="btn">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
        ذخیره تمام تغییرات
      </button>
      <a href="admin.php" class="btn-secondary" style="text-decoration: none;">انصراف</a>
    </div>
  </form>
</div>

<script>


function initChecklistFilters(){
  document.querySelectorAll('.mini-filter-input[data-filter-target]').forEach(input=>{
    if(input.dataset.ready === '1') return;
    input.dataset.ready = '1';
    input.addEventListener('input', function(){
      const target = document.getElementById(this.dataset.filterTarget);
      if(!target) return;
      const term = this.value.trim().toLowerCase();
      target.querySelectorAll('label').forEach(item=>{
        const text = item.textContent.trim().toLowerCase();
        item.style.display = text.includes(term) ? '' : 'none';
      });
    });
  });
}
initChecklistFilters();
document.addEventListener('DOMContentLoaded', initChecklistFilters);

// پیش‌نمایش کاور هنگام انتخاب فایل
const posterInput = document.getElementById('posterInput');
const posterPreview = document.getElementById('posterPreview');
if(posterInput && posterPreview) {
  posterInput.addEventListener('change', function(e) {
    if(e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = function(ev) {
        posterPreview.src = ev.target.result;
        posterPreview.style.display = 'block';
      }
      reader.readAsDataURL(e.target.files[0]);
    }
  });
}

// تبدیل چکباکس‌های ژانر به رشته کاما جدا قبل از submit
const editForm = document.getElementById('editForm');
const genresHidden = document.getElementById('genresHidden');
if(editForm) {
  editForm.addEventListener('submit', function(e) {
    const selectedGenres = [];
    document.querySelectorAll('#genresCheckboxGroup input:checked').forEach(cb => {
      selectedGenres.push(cb.value);
    });
    genresHidden.value = selectedGenres.join(', ');
  });
}

// نمایش/مخفی کردن فیلدهای شماره فصل بر اساس نوع فیلم
function toggleSeasonFields() {
  const isSeries = document.getElementById('movieType').value === 'tvSeries';
  document.querySelectorAll('.season-field').forEach(field => {
    field.style.display = isSeries ? 'block' : 'none';
  });
}

const movieTypeSelect = document.getElementById('movieType');
if (movieTypeSelect) {
  movieTypeSelect.addEventListener('change', toggleSeasonFields);
  toggleSeasonFields(); // تنظیم اولیه
}

// افزودن ردیف لینک زیرنویس
function createLinkRow(type) {
  const div = document.createElement('div');
  div.className = 'link-row';
  const isSeries = document.getElementById('movieType').value !== 'movie';
  const seasonField = isSeries ? `<input type="number" name="${type}_season[]" placeholder="شماره فصل" class="season-field">` : '';
  div.innerHTML = `
    <button type="button" class="remove-link" onclick="this.closest('.link-row').remove()">حذف</button>
    <div class="row-3">
      <input type="text" name="${type}_quality[]" placeholder="کیفیت" class="link-quality">
      <input type="text" name="${type}_url[]" placeholder="لینک دانلود" class="link-url">
      <input type="text" name="${type}_size[]" placeholder="حجم" class="link-size">
      ${seasonField}
    </div>
  `;
  return div;
}

const addSoftBtn = document.getElementById('addSoftLinkBtn');
const softContainer = document.getElementById('softLinksContainer');
if(addSoftBtn) {
  addSoftBtn.addEventListener('click', () => {
    softContainer.appendChild(createLinkRow('soft'));
  });
}

const addDubBtn = document.getElementById('addDubLinkBtn');
const dubContainer = document.getElementById('dubLinksContainer');
if(addDubBtn) {
  addDubBtn.addEventListener('click', () => {
    dubContainer.appendChild(createLinkRow('dub'));
  });
}

// حذف ردیف‌های موجود (دکمه‌های remove-link در DOM کار می‌کنند چون onclick مستقیم دارند)
</script>

<script>
window.ADMIN_CSRF_TOKEN = <?= json_encode($csrf_token ?? admin_csrf_token(), JSON_UNESCAPED_UNICODE) ?>;
(function(){
  function addCsrfToForms(){
    document.querySelectorAll('form').forEach(function(form){
      var method = (form.getAttribute('method') || 'GET').toUpperCase();
      if(method !== 'POST') return;
      if(!form.querySelector('input[name="csrf_token"]')){
        var input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'csrf_token';
        input.value = window.ADMIN_CSRF_TOKEN;
        form.appendChild(input);
      }
    });
  }
  addCsrfToForms();
  document.addEventListener('DOMContentLoaded', addCsrfToForms);
  var nativeFetch = window.fetch;
  if(nativeFetch){
    window.fetch = function(resource, init){
      init = init || {};
      var method = (init.method || 'GET').toUpperCase();
      if(method === 'POST'){
        init.headers = new Headers(init.headers || {});
        init.headers.set('X-CSRF-Token', window.ADMIN_CSRF_TOKEN);
        if(init.body instanceof FormData && !init.body.has('csrf_token')){
          init.body.append('csrf_token', window.ADMIN_CSRF_TOKEN);
        } else if(typeof init.body === 'string' && init.headers.get('Content-Type') && init.headers.get('Content-Type').includes('application/x-www-form-urlencoded') && !init.body.includes('csrf_token=')){
          init.body += (init.body ? '&' : '') + 'csrf_token=' + encodeURIComponent(window.ADMIN_CSRF_TOKEN);
        }
      }
      return nativeFetch(resource, init);
    };
  }

    document.addEventListener('click', function(e){
        var a = e.target.closest && e.target.closest('a[href]');
        if(!a) return;
        var href = a.getAttribute('href') || '';
        var unsafe = ['delete_movie','delete_story','add_to_admin_pick','remove_from_admin_pick','approve_comment','reject_comment','delete_comment','delete_request','delete'];
        var hasUnsafe = unsafe.some(function(k){ return href.indexOf(k + '=') !== -1; });
        if(hasUnsafe && href.indexOf('csrf_token=') === -1){
            a.setAttribute('href', href + (href.indexOf('?') === -1 ? '?' : '&') + 'csrf_token=' + encodeURIComponent(window.ADMIN_CSRF_TOKEN));
        }
    }, true);
})();
</script>

<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
</body>
</html>
