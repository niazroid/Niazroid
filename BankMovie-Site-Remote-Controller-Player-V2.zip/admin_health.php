<?php
declare(strict_types=1);
require_once __DIR__ . '/includes/admin_guard.php';
require_admin();
require_once __DIR__ . '/includes/admin_panel_bootstrap.php';
$csrfToken = admin_csrf_token();
admin_enforce_csrf();

$repairMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['repair'])) {
    $result = admin_panel_bootstrap($pdo, true);
    $repairMessage = $result['ok']
        ? 'بررسی و ترمیم سازگاری پنل با موفقیت انجام شد.'
        : 'ترمیم اجرا شد اما چند مورد هنوز به تنظیم Permission یا دسترسی دیتابیس نیاز دارد.';
}
$health = admin_panel_bootstrap($pdo, true);

// BankMovie V123: اندازه‌گیری مستقیم MySQL و گزارش درخواست‌های کند صفحه فیلم.
$dbPingMs = null;
$dbPingError = '';
try {
    $dbPingStarted = microtime(true);
    $pdo->query('SELECT 1')->fetchColumn();
    $dbPingMs = round((microtime(true) - $dbPingStarted) * 1000, 2);
} catch (Throwable $e) {
    $dbPingError = $e->getMessage();
}

if (!function_exists('bm_admin_tail_lines')) {
    function bm_admin_tail_lines(string $path, int $limit = 25): array {
        if (!is_file($path) || !is_readable($path)) return [];
        $lines = @file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (!is_array($lines)) return [];
        return array_slice($lines, -max(1, $limit));
    }
}
if (!function_exists('bm_admin_perf_diagnosis')) {
    function bm_admin_perf_diagnosis(array $row): array {
        $notes = is_array($row['notes'] ?? null) ? $row['notes'] : [];
        $largest = is_array($row['largest_stage'] ?? null) ? $row['largest_stage'] : [];
        $stage = (string)($largest['name'] ?? 'نامشخص');
        $dbMs = (float)($notes['db_connect_ms'] ?? 0);
        $cache = is_array($notes['detail_cache'] ?? null) ? $notes['detail_cache'] : [];
        $cacheState = (string)($cache['state'] ?? '');
        if (!empty($row['fatal'])) return ['خطای PHP', 'bad'];
        if ($dbMs >= 900 || isset($notes['db_connection_error'])) return ['هاست / MySQL', 'bad'];
        if (str_contains($stage, 'external-detail') || ($cacheState === 'miss' && (float)($cache['fetch_ms'] ?? 0) >= 1200)) {
            return ['سرور آرشیو خارجی', 'warn'];
        }
        if (str_contains($stage, 'config-and-session') && (float)($largest['delta_ms'] ?? 0) >= 1200) {
            return ['اتصال، سشن یا قفل دیتابیس', 'warn'];
        }
        return ['پردازش PHP / کوئری صفحه', 'ok'];
    }
}

$slowRequestRows = [];
$slowRequestLog = __DIR__ . '/_bankmovie_private/slow-requests.log';
foreach (array_reverse(bm_admin_tail_lines($slowRequestLog, 30)) as $line) {
    $decoded = json_decode($line, true);
    if (!is_array($decoded)) continue;
    [$diagnosis, $diagnosisClass] = bm_admin_perf_diagnosis($decoded);
    $decoded['_diagnosis'] = $diagnosis;
    $decoded['_diagnosis_class'] = $diagnosisClass;
    $slowRequestRows[] = $decoded;
}

$requiredTables = [
    'movies','movie_extra_info','softsub_links','dubbed_links','users','comments','comment_likes',
    'movie_requests','stories','story_views','slider_slides','admin_picks','collections','collection_movies',
    'notifications','movie_ratings','admin_banners','admin_quick_replies','admin_recycle_bin','admin_activity_logs'
];
$tableRows = [];
foreach ($requiredTables as $table) {
    $exists = admin_panel_table_exists($pdo, $table);
    $count = null;
    if ($exists) {
        try { $count = (int)$pdo->query("SELECT COUNT(*) FROM `{$table}`")->fetchColumn(); }
        catch (Throwable $e) { $count = null; }
    }
    $tableRows[] = ['name'=>$table, 'exists'=>$exists, 'count'=>$count];
}

$requiredColumns = [
    'stories' => ['type','file_path','caption','link','story_order','created_at'],
    'slider_slides' => ['image_path','title_fa','title_en','subtitle_fa','subtitle_en','link','slide_order','is_active','rating','votes'],
    'collections' => ['title','title_fa','slug','description','cover_image','status'],
    'collection_movies' => ['collection_id','movie_id','sort_order'],
    'movie_requests' => ['status','admin_response','updated_at'],
    'softsub_links' => ['movie_id','quality','url','size','season'],
    'dubbed_links' => ['movie_id','quality','url','size','season'],
    'users' => ['role','first_comment_approved'],
    'admin_banners' => ['title','position','image_path','link_url','starts_at','ends_at','is_active']
];
$columnRows = [];
foreach ($requiredColumns as $table => $columns) {
    foreach ($columns as $column) {
        $columnRows[] = ['table'=>$table, 'column'=>$column, 'exists'=>admin_panel_column_exists($pdo, $table, $column)];
    }
}

$directories = ['posters','uploads','uploads/stories','uploads/slider','uploads/collections','uploads/banners','logs','cache'];
$directoryRows = [];
foreach ($directories as $dir) {
    $full = __DIR__ . '/' . $dir;
    $directoryRows[] = [
        'name'=>$dir,
        'exists'=>is_dir($full),
        'writable'=>is_dir($full) && is_writable($full),
        'permission'=>is_dir($full) ? substr(sprintf('%o', fileperms($full)), -4) : '—'
    ];
}

$runtimeRows = [
    ['name'=>'PHP', 'value'=>PHP_VERSION, 'ok'=>version_compare(PHP_VERSION, '8.0', '>=')],
    ['name'=>'PDO MySQL', 'value'=>extension_loaded('pdo_mysql') ? 'فعال' : 'غیرفعال', 'ok'=>extension_loaded('pdo_mysql')],
    ['name'=>'Fileinfo', 'value'=>extension_loaded('fileinfo') ? 'فعال' : 'غیرفعال', 'ok'=>extension_loaded('fileinfo')],
    ['name'=>'DOM/XML', 'value'=>class_exists('DOMDocument') ? 'فعال' : 'غیرفعال؛ ابزار ورود از HTML کار نمی‌کند', 'ok'=>class_exists('DOMDocument')],
    ['name'=>'mbstring', 'value'=>extension_loaded('mbstring') ? 'فعال' : 'غیرفعال؛ متن فارسی با fallback پردازش می‌شود', 'ok'=>extension_loaded('mbstring')],
    ['name'=>'تبدیل WebP', 'value'=>(function_exists('imagewebp') || class_exists('Imagick')) ? 'فعال' : 'غیرفعال؛ آپلود کاور فیلم نیازمند GD/WebP یا Imagick است', 'ok'=>(function_exists('imagewebp') || class_exists('Imagick'))],
    ['name'=>'cURL', 'value'=>extension_loaded('curl') ? 'فعال' : 'غیرفعال', 'ok'=>extension_loaded('curl')],
    ['name'=>'upload_max_filesize', 'value'=>(string)ini_get('upload_max_filesize'), 'ok'=>true],
    ['name'=>'post_max_size', 'value'=>(string)ini_get('post_max_size'), 'ok'=>true],
    ['name'=>'max_file_uploads', 'value'=>(string)ini_get('max_file_uploads'), 'ok'=>true],
];

$allTablesOk = !array_filter($tableRows, fn($row) => !$row['exists'] && $row['name'] !== 'comment_likes');
$allColumnsOk = !array_filter($columnRows, fn($row) => !$row['exists']);
$allDirsOk = !array_filter($directoryRows, fn($row) => !$row['exists'] || !$row['writable']);
$overallOk = $health['ok'] && $allTablesOk && $allColumnsOk && $allDirsOk;
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>عیب‌یابی پنل مدیریت | BankMovie</title>
<style>
:root{color-scheme:dark;--bg:#07090d;--card:#111722;--line:#263143;--text:#f7fbff;--muted:#9aa6b5;--ok:#36ff9f;--bad:#fb7185;--warn:#fbbf24}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 90% 0,rgba(54,255,159,.1),transparent 30%),var(--bg);color:var(--text);font-family:Tahoma,Arial,sans-serif}.wrap{width:min(1180px,calc(100% - 28px));margin:24px auto 60px}.top,.card{background:linear-gradient(145deg,rgba(20,25,34,.95),rgba(9,12,18,.94));border:1px solid var(--line);border-radius:24px;box-shadow:0 25px 70px rgba(0,0,0,.35)}.top{padding:22px;display:flex;justify-content:space-between;gap:16px;align-items:center}.top h1{font-size:23px;margin:0 0 8px}.top p{margin:0;color:var(--muted);line-height:1.8}.actions{display:flex;gap:10px;flex-wrap:wrap}.btn{border:0;border-radius:999px;padding:11px 17px;font-weight:700;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;background:linear-gradient(135deg,var(--ok),#7dd3fc);color:#03110a}.btn.secondary{background:#1c2533;color:var(--text);border:1px solid var(--line)}.summary{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:18px 0}.metric{padding:18px;border-radius:20px;background:var(--card);border:1px solid var(--line)}.metric b{display:block;font-size:26px;margin-bottom:5px}.metric span{color:var(--muted);font-size:13px}.card{padding:20px;margin-top:16px}.card h2{font-size:18px;margin:0 0 16px}.notice{padding:14px 16px;border-radius:17px;margin:14px 0;line-height:1.8;border:1px solid}.notice.ok{border-color:rgba(54,255,159,.35);background:rgba(54,255,159,.08)}.notice.bad{border-color:rgba(251,113,133,.4);background:rgba(251,113,133,.08)}table{width:100%;border-collapse:collapse;min-width:650px}th,td{text-align:right;padding:12px;border-bottom:1px solid var(--line);font-size:13px}th{color:var(--muted)}.scroll{overflow:auto}.status{display:inline-flex;border-radius:999px;padding:5px 10px;font-size:12px;font-weight:700}.status.ok{background:rgba(54,255,159,.12);color:var(--ok)}.status.bad{background:rgba(251,113,133,.12);color:var(--bad)}.status.warn{background:rgba(251,191,36,.12);color:var(--warn)}.perf-guide{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:12px 0 16px}.perf-guide div{padding:12px;border-radius:15px;background:rgba(255,255,255,.025);border:1px solid var(--line);color:var(--muted);font-size:12px;line-height:1.8}.perf-guide b{color:var(--text);display:block}.uri{max-width:330px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;direction:ltr;text-align:left}.mono{direction:ltr;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.notice.info{border-color:rgba(125,211,252,.35);background:rgba(125,211,252,.07)}ul{line-height:2;color:var(--muted)}code{direction:ltr;display:inline-block}@media(max-width:780px){.top{align-items:flex-start;flex-direction:column}.summary{grid-template-columns:repeat(2,1fr)}.perf-guide{grid-template-columns:1fr}}
</style>

<link rel="stylesheet" href="/assets/css/bm-admin-unified-v1.css?v=1.1">
</head>
<body class="bm-admin-unified"><div class="wrap">
<div class="top"><div><h1>عیب‌یابی و ترمیم پنل مدیریت</h1><p>این صفحه اختلاف‌های دیتابیس و Permission بعد از انتقال هاست را بررسی می‌کند و هیچ محتوایی را حذف نمی‌کند.</p></div><div class="actions"><a class="btn secondary" href="admin.php">بازگشت به پنل</a><form method="post"><?= admin_csrf_input() ?><button class="btn" name="repair" value="1" type="submit">بررسی و ترمیم دوباره</button></form></div></div>
<?php if($repairMessage): ?><div class="notice <?= $overallOk?'ok':'bad' ?>"><?= admin_escape($repairMessage) ?></div><?php endif; ?>
<div class="notice <?= $overallOk?'ok':'bad' ?>"><strong><?= $overallOk ? 'پنل از نظر ساختار پایه آماده است.' : 'چند مشکل باقی مانده است.' ?></strong><?php if(!$overallOk): ?> موارد قرمز را بررسی کن؛ مشکلات Permission باید از File Manager هاست اصلاح شوند.<?php endif; ?></div>
<div class="summary">
<div class="metric"><b><?= count(array_filter($tableRows,fn($r)=>$r['exists'])) ?>/<?= count($tableRows) ?></b><span>جدول‌های موجود</span></div>
<div class="metric"><b><?= count(array_filter($columnRows,fn($r)=>$r['exists'])) ?>/<?= count($columnRows) ?></b><span>ستون‌های ضروری</span></div>
<div class="metric"><b><?= count(array_filter($directoryRows,fn($r)=>$r['writable'])) ?>/<?= count($directoryRows) ?></b><span>پوشه‌های قابل نوشتن</span></div>
<div class="metric"><b><?= count($health['changes']) ?></b><span>موارد ترمیم‌شده</span></div>
</div>
<div class="card" id="movie-performance">
<h2>تشخیص کندی و خطاهای موقت صفحه فیلم</h2>
<div class="notice info"><strong>تست زنده MySQL:</strong> <?php if($dbPingMs !== null): ?><span class="status <?= $dbPingMs < 120 ? 'ok' : ($dbPingMs < 700 ? 'warn' : 'bad') ?>"><?= number_format($dbPingMs, 2) ?> ms</span><?php else: ?><span class="status bad">ناموفق</span> <?= admin_escape($dbPingError) ?><?php endif; ?> — این عدد فقط زمان پاسخ مستقیم دیتابیس در همین لحظه است.</div>
<div class="perf-guide">
<div><b>DB Connect بالا</b>اگر مقدار اتصال نزدیک یک ثانیه یا بیشتر باشد، فشار MySQL، محدودیت Connection یا هاست عامل اصلی است.</div>
<div><b>External Detail بالا</b>اگر کندترین مرحله دریافت جزئیات خارجی باشد، سرور آرشیو دیر پاسخ داده؛ V123 نسخه کش‌شده را سریع تحویل می‌دهد.</div>
<div><b>Config / Session بالا</b>معمولاً نشانه قفل جدول یا اجرای تغییر ساختار در درخواست عمومی است؛ V123 ساخت جدول را از مسیر داغ خارج کرده است.</div>
</div>
<?php if($slowRequestRows): ?>
<div class="scroll"><table><thead><tr><th>زمان</th><th>کل</th><th>کندترین مرحله</th><th>اتصال DB</th><th>کش جزئیات</th><th>تشخیص</th><th>آدرس</th></tr></thead><tbody>
<?php foreach($slowRequestRows as $row):
$largest = is_array($row['largest_stage'] ?? null) ? $row['largest_stage'] : [];
$notes = is_array($row['notes'] ?? null) ? $row['notes'] : [];
$cache = is_array($notes['detail_cache'] ?? null) ? $notes['detail_cache'] : [];
?>
<tr>
<td class="mono"><?= admin_escape((string)($row['time'] ?? '—')) ?></td>
<td><b><?= number_format((float)($row['total_ms'] ?? 0), 0) ?> ms</b></td>
<td><code><?= admin_escape((string)($largest['name'] ?? '—')) ?></code><br><small><?= number_format((float)($largest['delta_ms'] ?? 0), 0) ?> ms</small></td>
<td><?= isset($notes['db_connect_ms']) ? number_format((float)$notes['db_connect_ms'], 0).' ms' : '—' ?></td>
<td><code><?= admin_escape((string)($cache['state'] ?? '—')) ?></code></td>
<td><span class="status <?= admin_escape((string)$row['_diagnosis_class']) ?>"><?= admin_escape((string)$row['_diagnosis']) ?></span></td>
<td><div class="uri" title="<?= admin_escape((string)($row['uri'] ?? '')) ?>"><?= admin_escape((string)($row['uri'] ?? '—')) ?></div></td>
</tr><?php endforeach; ?>
</tbody></table></div>
<?php else: ?>
<div class="notice ok">هنوز درخواست کندی ثبت نشده است. بعد از نصب V123، هر صفحه‌ای که بیشتر از ۲٫۵ ثانیه طول بکشد خودکار اینجا ثبت می‌شود؛ چند صفحه فیلم را باز کن و دوباره همین بخش را ببین.</div>
<?php endif; ?>
</div>
<?php if($health['changes']): ?><div class="card"><h2>تغییرات خودکار انجام‌شده</h2><ul><?php foreach($health['changes'] as $change): ?><li><?= admin_escape($change) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if($health['errors']): ?><div class="card"><h2>خطاهای باقی‌مانده</h2><ul><?php foreach($health['errors'] as $item): ?><li style="color:var(--bad)"><?= admin_escape($item) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<div class="card"><h2>جدول‌های دیتابیس</h2><div class="scroll"><table><thead><tr><th>جدول</th><th>وضعیت</th><th>تعداد رکورد</th></tr></thead><tbody><?php foreach($tableRows as $row): ?><tr><td><code><?= admin_escape($row['name']) ?></code></td><td><span class="status <?= $row['exists']?'ok':'bad' ?>"><?= $row['exists']?'موجود':'ناموجود' ?></span></td><td><?= $row['count']===null?'—':number_format($row['count']) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card"><h2>ستون‌های موردنیاز پنل</h2><div class="scroll"><table><thead><tr><th>جدول</th><th>ستون</th><th>وضعیت</th></tr></thead><tbody><?php foreach($columnRows as $row): ?><tr><td><code><?= admin_escape($row['table']) ?></code></td><td><code><?= admin_escape($row['column']) ?></code></td><td><span class="status <?= $row['exists']?'ok':'bad' ?>"><?= $row['exists']?'موجود':'ناموجود' ?></span></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card"><h2>پوشه‌های آپلود و دسترسی نوشتن</h2><div class="scroll"><table><thead><tr><th>مسیر</th><th>وجود</th><th>قابل نوشتن</th><th>Permission</th></tr></thead><tbody><?php foreach($directoryRows as $row): ?><tr><td><code><?= admin_escape($row['name']) ?></code></td><td><span class="status <?= $row['exists']?'ok':'bad' ?>"><?= $row['exists']?'بله':'خیر' ?></span></td><td><span class="status <?= $row['writable']?'ok':'bad' ?>"><?= $row['writable']?'بله':'خیر' ?></span></td><td><code><?= $row['permission'] ?></code></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="card"><h2>وضعیت PHP هاست</h2><div class="scroll"><table><thead><tr><th>مورد</th><th>مقدار</th><th>وضعیت</th></tr></thead><tbody><?php foreach($runtimeRows as $row): ?><tr><td><?= admin_escape($row['name']) ?></td><td><?= admin_escape($row['value']) ?></td><td><span class="status <?= $row['ok']?'ok':'bad' ?>"><?= $row['ok']?'مناسب':'نیازمند بررسی' ?></span></td></tr><?php endforeach; ?></tbody></table></div></div>
</div></body></html>
