<?php
$errorCode = 502;
require __DIR__ . '/includes/error_bootstrap.php';
require __DIR__ . '/includes/error_template.php';
