<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
@include_once __DIR__ . '/includes/_bm_support_widget.php';

/**
 * /view_all - مشاهده همه + پشتیبانی از آرشیو ۱ (archive1_watchlist)
 * نسخه اصلاح‌شده: هر دو آرشیو پشتیبانی می‌شوند
 */
require_once 'config.php';
require_once __DIR__ . '/includes/public_assets.php';
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/bm_analytics.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$currentUser = $currentUser ?? null;
if (!$currentUser && isset($_COOKIE['session_token'])) {
    try {
        $userObj = new User($pdo);
        $currentUser = $userObj->checkSession($_COOKIE['session_token']) ?: null;
    } catch (Throwable $e) {
        $currentUser = null;
    }
}

$userTheme = $currentUser['theme'] ?? ($_COOKIE['user_theme'] ?? 'dark-green');
$userLang  = $_COOKIE['user_lang']  ?? ($currentUser['language'] ?? 'fa');
$userLang  = in_array($userLang, ['fa','en'], true) ? $userLang : 'fa';

$themes = [
    'dark-green'  => ['primary' => '#2f7cff', 'name' => 'آبی پیش‌فرض',    'name_en' => 'Default Blue'],
    'dark-blue'   => ['primary' => '#3b82f6', 'name' => 'آبی مشکی',    'name_en' => 'Dark Blue'],
    'dark-purple' => ['primary' => '#8b5cf6', 'name' => 'بنفش مشکی',   'name_en' => 'Dark Purple'],
    'dark-pink'   => ['primary' => '#ec4899', 'name' => 'صورتی مشکی',  'name_en' => 'Dark Pink'],
    'dark-red'    => ['primary' => '#ef4444', 'name' => 'قرمز مشکی',   'name_en' => 'Dark Red'],
    'dark-orange' => ['primary' => '#f97316', 'name' => 'نارنجی مشکی', 'name_en' => 'Dark Orange'],
    'dark-cyan'   => ['primary' => '#06b6d4', 'name' => 'فسفری مشکی', 'name_en' => 'Dark Cyan'],
    'dark-white'  => ['primary' => '#ffffff', 'name' => 'سفید مشکی',   'name_en' => 'Dark White'],
    'dark-black'  => ['primary' => '#888888', 'name' => 'دارک مطلق',   'name_en' => 'Pure Dark'],
];
if (!isset($themes[$userTheme])) $userTheme = 'dark-green';
$currentTheme = $themes[$userTheme];
$themeHex = ltrim($currentTheme['primary'], '#');
if (strlen($themeHex) === 3) $themeHex = $themeHex[0].$themeHex[0].$themeHex[1].$themeHex[1].$themeHex[2].$themeHex[2];
$currentThemeRgbCss = hexdec(substr($themeHex,0,2)).','.hexdec(substr($themeHex,2,2)).','.hexdec(substr($themeHex,4,2));

$dir      = $userLang === 'fa' ? 'rtl' : 'ltr';
$langAttr = $userLang === 'fa' ? 'fa' : 'en';

if (!function_exists('e')) {
    function e($s) { return htmlspecialchars((string)($s ?? ''), ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
}
if (!function_exists('escapeHtml')) {
    function escapeHtml($s) { return htmlspecialchars((string)($s ?? ''), ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8'); }
}

if (!function_exists('bm_view_all_poster_url')) {
    function bm_view_all_poster_url($poster, array $item = []): string {
        if (is_array($poster)) $poster = $poster['medium'] ?? ($poster['full'] ?? ($poster['large'] ?? ''));
        $poster = trim((string)$poster);
        if ($poster === '' || !function_exists('bm_poster_wrap_url')) return $poster;
        return bm_poster_wrap_url($poster, [
            'type' => (string)($item['type'] ?? $item['item_type'] ?? 'movie'),
            'title' => (string)($item['title'] ?? $item['item_title'] ?? $item['title_fa'] ?? $item['item_title_fa'] ?? ''),
            'title_fa' => (string)($item['title_fa'] ?? $item['item_title_fa'] ?? ''),
            'year' => (string)($item['year'] ?? $item['item_year'] ?? ''),
        ]);
    }
}

$t = [
    'fa' => [
        'home' => 'خانه', 'search' => 'جستجو', 'profile' => 'پروفایل', 'player' => 'پلیر',
        'request' => 'درخواست', 'auth' => 'ثبت‌نام و ورود', 'account' => 'حساب',
        'login' => 'ورود', 'register' => 'ثبت‌نام', 'logout' => 'خروج',
        'admin_panel' => 'پنل مدیریت', 'notifications' => 'اعلان‌ها',
        'no_notifications' => 'هیچ اعلانی وجود ندارد',
        'donate' => 'حمایت مالی', 'support_us' => 'حمایت مالی',
        'support_text' => 'تمام خدمات سایت رایگان است. با یک حمایت کوچک کمک کنید.',
        'close' => 'بستن',
    ],
    'en' => [
        'home' => 'Home', 'search' => 'Search', 'profile' => 'Profile', 'player' => 'Player',
        'request' => 'Request', 'auth' => 'Login/Register', 'account' => 'Account',
        'login' => 'Login', 'register' => 'Register', 'logout' => 'Logout',
        'admin_panel' => 'Admin Panel', 'notifications' => 'Notifications',
        'no_notifications' => 'No notifications',
        'donate' => 'Donate', 'support_us' => 'Support Us',
        'support_text' => 'All services are free. Support server costs.',
        'close' => 'Close',
    ]
];

// Notifications
$notificationsList = [];
$latestNotification = null;
try {
    $stmt = $pdo->prepare("SELECT * FROM notifications WHERE is_active=1 AND expires_at>NOW() ORDER BY created_at DESC LIMIT 20");
    $stmt->execute();
    $notificationsList = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $latestNotification = $notificationsList[0] ?? null;
} catch (Throwable $e) {}

$type   = $_GET['type'] ?? 'all';
$page   = max(1, (int)($_GET['page'] ?? 1));
$perPage = 30;
$offset = ($page - 1) * $perPage;

$isLoggedIn    = (bool)$currentUser;
$currentUserId = $currentUser ? (int)$currentUser['id'] : null;

$pageTitleFa = '';
$pageTitleEn = '';
$where = [];
$movies = [];
$total = 0;
$errorMessage = null;
$orderBy = 'id DESC';

// ===== آرشیو ۱ - واچ‌لیست فیلم ۲ مدیا =====
// این بخش داده‌ها را از JSON ذخیره‌شده در دیتابیس می‌خواند
$isArchive1WatchList = false;
$archive1Items = [];

if ($type === 'archive1_watchlist') {
    $isArchive1WatchList = true;
    $pageTitleFa = 'نشانه‌ها';
    $pageTitleEn = 'Archive 1 Watchlist';

    if (!$isLoggedIn) {
        $errorMessage = $userLang === 'fa' ? 'برای مشاهده نشانه‌های آرشیو ۱ باید وارد شوید' : 'Please login to view Archive 1 watchlist';
    } else {
        // ایجاد جدول اگر وجود نداشت
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS archive1_watchlist (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id INT UNSIGNED NOT NULL,
                item_link VARCHAR(500) NOT NULL,
                item_title VARCHAR(300) NOT NULL DEFAULT '',
                item_title_fa VARCHAR(300) NOT NULL DEFAULT '',
                item_year VARCHAR(10) DEFAULT NULL,
                item_poster VARCHAR(500) DEFAULT NULL,
                item_imdb_rate DECIMAL(3,1) DEFAULT NULL,
                item_type VARCHAR(20) DEFAULT 'movie',
                added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_user_link (user_id, item_link(200)),
                KEY idx_user (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Throwable $e) {}

        try {
            $stmt = $pdo->prepare("SELECT * FROM archive1_watchlist WHERE user_id=? ORDER BY added_at DESC LIMIT ? OFFSET ?");
            $stmt->execute([$currentUserId, $perPage, $offset]);
            $archive1Items = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM archive1_watchlist WHERE user_id=?");
            $cntStmt->execute([$currentUserId]);
            $total = (int)$cntStmt->fetchColumn();
        } catch (Throwable $e) {
            $errorMessage = $userLang === 'fa' ? 'خطا در بارگذاری' : 'Load error';
        }
    }
}

// ===== آرشیو ۱ — کتگوری (ترکی، کره‌ای، انیمه) =====
$isArc1Category  = false;
$arc1CatItems    = [];
$arc1CatHasMore  = false;
$arc1CatNextPage = null;
$arc1CatError    = null;

// ===== آرشیو ۱ — مشاهده همه آپدیت فیلم/سریال =====
$isArc1Updates      = false;
$arc1UpdatesKind    = 'movies';
$arc1UpdatesItems   = [];
$arc1UpdatesHasMore = false;
$arc1UpdatesError   = null;

// ===== آرشیو ۱ — مشاهده همه نتایج سرچ زنده =====
$isArc1Search      = false;
$arc1SearchQuery   = '';
$arc1SearchItems   = [];
$arc1SearchHasMore = false;
$arc1SearchError   = null;

// ===== آرشیو ۳ =====
$isArc3List    = false;
$arc3Kind      = '';
$arc3Query     = '';
$arc3Items     = [];
$arc3HasMore   = false;
$arc3Error     = null;

// ===== آرشیو ۴ =====
$isArc4List    = false;
$arc4Kind      = '';
$arc4Query     = '';
$arc4Items     = [];
$arc4HasMore   = false;
$arc4Error     = null;

if ($type === 'arc3_search') {
    $isArc3List = true;
    $arc3Kind = 'search';
    $arc3Query = trim($_GET['q'] ?? '');
    $pageTitleFa = $arc3Query !== '' ? 'نتایج جستجوی آرشیو ۳: ' . $arc3Query : 'نتایج جستجوی آرشیو ۳';
    $pageTitleEn = $arc3Query !== '' ? 'Archive 3 Search: ' . $arc3Query : 'Archive 3 Search Results';
    if (!bm_archive_user_can_access('archive3', $currentUser ?? null)) {
        $arc3Error = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_user_can_access('archive3', $currentUser ?? null)) {
        $arc3Error = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive3')) {
        $arc3Error = bm_archive_disabled_message('archive3');
    } elseif ($arc3Query === '') {
        $arc3Error = $userLang === 'fa' ? 'عبارت جستجو خالی است' : 'Search query is empty';
    } else {
        try {
            require_once __DIR__ . '/includes/api6_lib.php';
            $r = api6_search(['s'=>$arc3Query, 'page'=>$page]);
            $arc3Items = $r['movies'] ?? [];
            $arc3HasMore = !empty($r['has_more']);
            $total = count($arc3Items);
        } catch (Throwable $e) { $arc3Error = $e->getMessage(); }
    }
}

if ($type === 'arc3_section') {
    $isArc3List = true;
    $arc3Kind = trim($_GET['kind'] ?? 'new_movies');
    $arc3Names = [
        'new_series'          => ['fa'=>'سریال‌های جدید', 'en'=>'New Series'],
        'new_movies'          => ['fa'=>'فیلم‌های جدید', 'en'=>'New Movies'],
        'animations'          => ['fa'=>'انیمه / انیمیشن جدید', 'en'=>'New Anime / Animation'],
        'updated_animations'  => ['fa'=>'انیمیشن‌های به‌روز شده', 'en'=>'Updated Animations'],
        'updated_anime'       => ['fa'=>'انیمه‌های به‌روز شده', 'en'=>'Updated Anime'],
    ];
    if (!isset($arc3Names[$arc3Kind])) $arc3Kind = 'new_movies';
    $pageTitleFa = $arc3Names[$arc3Kind]['fa'];
    $pageTitleEn = $arc3Names[$arc3Kind]['en'];
    if (!bm_archive_is_enabled('archive3')) {
        $arc3Error = bm_archive_disabled_message('archive3');
    } else {
        try {
            require_once __DIR__ . '/includes/api6_lib.php';
            $r = api6_search(api6_section_params($arc3Kind, $page));
            $arc3Items = $r['movies'] ?? [];
            $arc3HasMore = !empty($r['has_more']);
            $total = count($arc3Items);
        } catch (Throwable $e) { $arc3Error = $e->getMessage(); }
    }
}

if ($type === 'arc4_search') {
    $isArc4List = true;
    $arc4Kind = 'search';
    $arc4Query = trim($_GET['q'] ?? '');
    $pageTitleFa = $arc4Query !== '' ? 'نتایج جستجوی آرشیو ۴: ' . $arc4Query : 'نتایج جستجوی آرشیو ۴';
    $pageTitleEn = $arc4Query !== '' ? 'Archive 4 Search: ' . $arc4Query : 'Archive 4 Search Results';
    if (!bm_archive_user_can_access('archive4', $currentUser ?? null)) {
        $arc4Error = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive4')) {
        $arc4Error = bm_archive_disabled_message('archive4');
    } elseif ($arc4Query === '') {
        $arc4Error = $userLang === 'fa' ? 'عبارت جستجو خالی است' : 'Search query is empty';
    } else {
        try {
            require_once __DIR__ . '/includes/api4_lib.php';
            $r = api4_search(['s'=>$arc4Query, 'page'=>$page]);
            $arc4Items = $r['movies'] ?? [];
            $arc4HasMore = !empty($r['has_more']);
            $total = count($arc4Items);
        } catch (Throwable $e) { $arc4Error = $e->getMessage(); }
    }
}

if ($type === 'arc4_section') {
    $isArc4List = true;
    $arc4Kind = trim($_GET['kind'] ?? 'new_movies');
    $arc4Names = [
        'new_series'          => ['fa'=>'سریال‌های جدید', 'en'=>'New Series'],
        'new_movies'          => ['fa'=>'فیلم‌های جدید', 'en'=>'New Movies'],
        'animations'          => ['fa'=>'انیمه / انیمیشن جدید', 'en'=>'New Anime / Animation'],
        'updated_animations'  => ['fa'=>'انیمیشن‌های به‌روز شده', 'en'=>'Updated Animations'],
        'updated_anime'       => ['fa'=>'انیمه‌های به‌روز شده', 'en'=>'Updated Anime'],
    ];    if (!isset($arc4Names[$arc4Kind])) $arc4Kind = 'new_movies';
    $pageTitleFa = $arc4Names[$arc4Kind]['fa'];
    $pageTitleEn = $arc4Names[$arc4Kind]['en'];
    if (!bm_archive_user_can_access('archive4', $currentUser ?? null)) {
        $arc4Error = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive4')) {
        $arc4Error = bm_archive_disabled_message('archive4');
    } else {
        try {
        require_once __DIR__ . '/includes/api4_lib.php';
        $r = api4_search(api4_section_params($arc4Kind, $page));
        $arc4Items = $r['movies'] ?? [];
        $arc4HasMore = !empty($r['has_more']);
        $total = count($arc4Items);
        } catch (Throwable $e) { $arc4Error = $e->getMessage(); }
    }
}

if ($type === 'arc1_search') {
    $isArc1Search = true;
    $arc1SearchQuery = trim($_GET['q'] ?? '');
    $pageTitleFa = $arc1SearchQuery !== '' ? 'نتایج جستجو: ' . $arc1SearchQuery : 'نتایج جستجوی آرشیو ۱';
    $pageTitleEn = $arc1SearchQuery !== '' ? 'Search Results: ' . $arc1SearchQuery : 'Archive 1 Search Results';

    if (!bm_archive_user_can_access('archive1', $currentUser ?? null)) {
        $arc1SearchError = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive1')) {
        $arc1SearchError = bm_archive_disabled_message('archive1');
    } elseif ($arc1SearchQuery === '') {
        $arc1SearchError = $userLang === 'fa' ? 'عبارت جستجو خالی است' : 'Search query is empty';
    } else {
        try {
            require_once __DIR__ . '/includes/api2_lib.php';
            $arc1SearchItems = advancedSearch(['s' => $arc1SearchQuery, 'page' => $page]);
            $arc1SearchHasMore = count($arc1SearchItems) >= 20;
            $total = count($arc1SearchItems); // تعداد آیتم‌های همین صفحه
        } catch (Throwable $e) {
            $arc1SearchError = $e->getMessage();
        }
    }
}

if ($type === 'arc1_updates') {
    $isArc1Updates = true;
    $arc1UpdatesKind = trim($_GET['kind'] ?? 'movies');
    $arc1UpdatesKind = in_array($arc1UpdatesKind, ['movies', 'movie', 'series'], true) ? $arc1UpdatesKind : 'movies';
    $apiKind = in_array($arc1UpdatesKind, ['series'], true) ? 'series' : 'movies';

    if ($apiKind === 'series') {
        $pageTitleFa = 'سریال‌های آپدیت شده';
        $pageTitleEn = 'Updated Series';
        $arc1UpdatesKind = 'series';
    } else {
        $pageTitleFa = 'فیلم‌های آپدیت شده';
        $pageTitleEn = 'Updated Movies';
        $arc1UpdatesKind = 'movies';
    }

    if (!bm_archive_user_can_access('archive1', $currentUser ?? null)) {
        $arc1UpdatesError = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive1')) {
        $arc1UpdatesError = bm_archive_disabled_message('archive1');
    } else {
        try {
            require_once __DIR__ . '/includes/api2_lib.php';
            $arc1UpdateResult   = getUpdatedList($apiKind, $page);
            $arc1UpdatesItems   = $arc1UpdateResult['movies'] ?? [];
            $arc1UpdatesHasMore = !empty($arc1UpdateResult['has_more']);
            // صفحه اول اکنون از ادغام اسلایدر آپدیت‌ها و صفحه اول کامل آرشیو ساخته می‌شود.
            // مقدار has_more و next_page مستقیماً از صفحه‌بندی واقعی منبع می‌آیند.
            $total = count($arc1UpdatesItems); // تعداد آیتم‌های صفحه فعلی
        } catch (Throwable $e) {
            $arc1UpdatesError = $e->getMessage();
        }
    }
}

if ($type === 'arc1_category') {
    $isArc1Category = true;
    $arc1Cat = trim($_GET['cat'] ?? '');
    $arc1CatNames = [
        'turkish'   => ['fa' => 'سریال‌های ترکی',     'en' => 'Turkish Series'],
        'korean'    => ['fa' => 'سریال‌های کره‌ای',   'en' => 'Korean Series'],
        'anime'     => ['fa' => 'انیمه',              'en' => 'Anime'],
        'dubbed-fa' => ['fa' => 'فیلم‌های دوبله فارسی', 'en' => 'Persian Dubbed Movies'],
        'top-movies'=> ['fa' => '۲۵۰ فیلم برتر',        'en' => 'Top 250 Movies'],
        'top-series'=> ['fa' => '۲۵۰ سریال برتر',       'en' => 'Top 250 Series'],
        'top-2026'  => ['fa' => 'برترین فیلم‌های 2026', 'en' => 'Best Movies of 2026'],
    ];
    if (!isset($arc1CatNames[$arc1Cat])) {
        $arc1Cat = 'turkish';
    }
    $pageTitleFa = $arc1CatNames[$arc1Cat]['fa'];
    $pageTitleEn = $arc1CatNames[$arc1Cat]['en'];

    if (!bm_archive_user_can_access('archive1', $currentUser ?? null)) {
        $arc1CatError = $userLang === 'fa' ? 'محتوا یافت نشد.' : 'Content not found.';
    } elseif (!bm_archive_is_enabled('archive1')) {
        $arc1CatError = bm_archive_disabled_message('archive1');
    } else {
        try {
            require_once __DIR__ . '/includes/api2_lib.php';
            $arc1Result     = getCategoryList($arc1Cat, $page);
            $arc1CatItems   = $arc1Result['movies'] ?? [];
            $arc1CatHasMore = $arc1Result['has_more'] ?? false;
            $total = count($arc1CatItems); // برای نمایش تعداد فعلی صفحه
        } catch (Throwable $e) {
            $arc1CatError = $e->getMessage();
        }
    }
}

// ===== سایر انواع (کد اصلی) =====
if (!$isArchive1WatchList && !$isArc1Category && !$isArc1Updates && !$isArc1Search && !$isArc3List && !$isArc4List) {
    switch ($type) {
        case 'history':
            $pageTitleFa = 'تاریخچه تماشا'; $pageTitleEn = 'Watch History';
            if (!$isLoggedIn) {
                $errorMessage = $userLang === 'fa' ? 'برای مشاهده تاریخچه باید وارد شوید' : 'Please login';
            } else {
                $stmt = $pdo->prepare("SELECT m.*,w.current_time,w.duration,w.last_watched,ROUND((w.current_time/NULLIF(w.duration,0))*100) as progress FROM watch_history w JOIN movies m ON w.movie_id=m.id WHERE w.user_id=? ORDER BY w.last_watched DESC LIMIT ? OFFSET ?");
                $stmt->execute([$currentUserId, $perPage, $offset]);
                $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM watch_history WHERE user_id=?");
                $cntStmt->execute([$currentUserId]);
                $total = (int)$cntStmt->fetchColumn();
            }
            break;
        case 'watchlist':
            $pageTitleFa = 'نشانه شده‌ها'; $pageTitleEn = 'My Watchlist';
            if (!$isLoggedIn) {
                $errorMessage = $userLang === 'fa' ? 'برای مشاهده نشانه‌ها باید وارد شوید' : 'Please login';
            } else {
                $stmt = $pdo->prepare("SELECT m.*,w.added_at FROM watchlist w JOIN movies m ON w.movie_id=m.id WHERE w.user_id=? ORDER BY w.added_at DESC LIMIT ? OFFSET ?");
                $stmt->execute([$currentUserId, $perPage, $offset]);
                $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $cntStmt = $pdo->prepare("SELECT COUNT(*) FROM watchlist WHERE user_id=?");
                $cntStmt->execute([$currentUserId]);
                $total = (int)$cntStmt->fetchColumn();
            }
            break;
        case 'new-movies':
            $pageTitleFa = 'فیلم‌های جدید'; $pageTitleEn = 'New Movies';
            $where[] = "type='movie'"; $orderBy = "created_at DESC,id DESC"; break;
        case 'updated-series':
            $pageTitleFa = 'سریال‌های آپدیت'; $pageTitleEn = 'Updated Series';
            $where[] = "(type='tvSeries' OR type='tvMiniSeries')"; $orderBy = "COALESCE(updated_at,created_at) DESC,id DESC"; break;
        case 'animations':
            $pageTitleFa = 'انیمیشن'; $pageTitleEn = 'Animation';
            $where[] = "(genres LIKE '%Animation%' OR genres LIKE '%Kids%' OR type='animation')"; $orderBy = "created_at DESC,year DESC,imdb_rate DESC"; break;
        case 'new-releases':
            $pageTitleFa = 'جدیدترین اکران'; $pageTitleEn = 'New Releases';
            $where[] = "year >= YEAR(CURRENT_DATE)-2 AND year>0"; $orderBy = "year DESC,id DESC"; break;
        case 'top-movies':
            $pageTitleFa = 'برترین فیلم‌ها'; $pageTitleEn = 'Top Rated Movies';
            $where[] = "type='movie' AND imdb_rate>=7"; $orderBy = "imdb_rate DESC,imdb_votes DESC"; break;
        case 'top-series':
            $pageTitleFa = 'برترین سریال‌ها'; $pageTitleEn = 'Top Rated Series';
            $where[] = "type LIKE '%Series%' AND imdb_rate>=7"; $orderBy = "imdb_rate DESC,imdb_votes DESC"; break;
        case 'dubbed':
            $pageTitleFa = 'دوبله فارسی'; $pageTitleEn = 'Persian Dubbed';
            $stmt = $pdo->prepare("SELECT DISTINCT m.* FROM movies m INNER JOIN dubbed_links d ON m.id=d.movie_id ORDER BY m.imdb_rate DESC,m.id DESC LIMIT ? OFFSET ?");
            $stmt->execute([$perPage, $offset]);
            $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $total = (int)$pdo->query("SELECT COUNT(DISTINCT m.id) FROM movies m INNER JOIN dubbed_links d ON m.id=d.movie_id")->fetchColumn();
            break;
        case 'admin-picks':
            $pageTitleFa = 'پیشنهادات ویژه ادمین'; $pageTitleEn = 'Admin Picks';
            $stmt = $pdo->prepare("SELECT m.* FROM admin_picks ap JOIN movies m ON ap.movie_id=m.id ORDER BY ap.pick_order ASC LIMIT ? OFFSET ?");
            $stmt->execute([$perPage, $offset]);
            $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $total = (int)$pdo->query("SELECT COUNT(*) FROM admin_picks")->fetchColumn();
            break;
        case 'top-user-rated':
            $pageTitleFa = 'محبوب‌ترین نزد کاربران'; $pageTitleEn = 'Top User Rated';
            $stmt = $pdo->prepare("SELECT m.*,COALESCE(r.avg_rating,0) as user_rating,COALESCE(r.total_votes,0) as total_votes FROM movies m LEFT JOIN movie_ratings r ON m.id=r.movie_id WHERE COALESCE(r.total_votes,0)>0 ORDER BY COALESCE(r.total_votes,0) DESC,COALESCE(r.avg_rating,0) DESC LIMIT ? OFFSET ?");
            $stmt->execute([$perPage, $offset]);
            $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $total = (int)$pdo->query("SELECT COUNT(DISTINCT m.id) FROM movies m LEFT JOIN movie_ratings r ON m.id=r.movie_id WHERE COALESCE(r.total_votes,0)>0")->fetchColumn();
            break;
        case 'popular_views':
            // محرمانه: آمار پربازدید فقط داخل پنل مدیریت نمایش داده می‌شود.
            if (($currentUser['role'] ?? '') !== 'admin') {
                $errorMessage = $userLang === 'fa' ? 'این بخش فقط برای مدیریت در دسترس است.' : 'This section is only available for admins.';
                $movies = [];
                $total = 0;
                break;
            }
            $pageTitleFa = 'فیلم‌های پربازدید'; $pageTitleEn = 'Popular Movies';
            try {
                bm_analytics_init($pdo);
                $stmt = $pdo->prepare("SELECT m.*, COUNT(v.id) AS view_count FROM bm_visit_events v INNER JOIN movies m ON m.id=v.movie_id WHERE v.page_type='movie' AND v.movie_id IS NOT NULL GROUP BY m.id ORDER BY view_count DESC, MAX(v.created_at) DESC LIMIT ? OFFSET ?");
                $stmt->execute([$perPage, $offset]);
                $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $total = (int)$pdo->query("SELECT COUNT(*) FROM (SELECT m.id FROM bm_visit_events v INNER JOIN movies m ON m.id=v.movie_id WHERE v.page_type='movie' AND v.movie_id IS NOT NULL GROUP BY m.id) t")->fetchColumn();
            } catch(Throwable $e) { $movies = []; $total = 0; }
            break;
        case 'updated':
            $pageTitleFa = 'آپدیت اخیر'; $pageTitleEn = 'Recent Updates';
            $orderBy = "updated_at DESC,id DESC"; break;
        default:
            $type = 'all'; $pageTitleFa = 'همه فیلم و سریال‌ها'; $pageTitleEn = 'All Movies & Series';
            $where[] = "1=1"; break;
    }

    if (!in_array($type, ['history','watchlist','dubbed','admin-picks','top-user-rated','popular_views'], true) && !$errorMessage) {
        $whereSql = !empty($where) ? "WHERE ".implode(" AND ", $where) : "";
        $stmt = $pdo->prepare("SELECT * FROM movies $whereSql ORDER BY $orderBy LIMIT ? OFFSET ?");
        $stmt->execute([$perPage, $offset]);
        $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $total = (int)$pdo->query("SELECT COUNT(*) FROM movies $whereSql")->fetchColumn();
    }
}
// بستن بلاک arc1_category هم اینجا تموم میشه (بلاک بالا تنها شرط داشت)

$totalCount = (int)$total;
$lastPage   = $totalCount > 0 ? (int)ceil($totalCount / $perPage) : 1;

// بج‌های دوبله/زیرنویس
if (!$isArchive1WatchList && !empty($movies)) {
    $movieIds = array_values(array_unique(array_filter(array_map('intval', array_column($movies, 'id')))));
    if (!empty($movieIds)) {
        $ph = implode(',', array_fill(0, count($movieIds), '?'));
        $softCounts = []; $dubCounts = [];
        try {
            $stmt = $pdo->prepare("SELECT movie_id,COUNT(*) AS cnt FROM softsub_links WHERE movie_id IN ($ph) GROUP BY movie_id");
            $stmt->execute($movieIds);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $softCounts[(int)$r['movie_id']] = (int)$r['cnt'];
            $stmt = $pdo->prepare("SELECT movie_id,COUNT(*) AS cnt FROM dubbed_links WHERE movie_id IN ($ph) GROUP BY movie_id");
            $stmt->execute($movieIds);
            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) $dubCounts[(int)$r['movie_id']] = (int)$r['cnt'];
        } catch (Throwable $e) {}
        foreach ($movies as &$mv) {
            $mid = (int)($mv['id'] ?? 0);
            $mv['soft_count'] = $softCounts[$mid] ?? 0;
            $mv['dub_count']  = $dubCounts[$mid] ?? 0;
        }
        unset($mv);
    }
}

// واچ‌لیست کاربر (برای بج قلب)
$userWatchlist    = [];
$userWatchlistSet = [];
if ($isLoggedIn && !$isArchive1WatchList && !empty($movies)) {
    $imdbCodes = array_values(array_filter(array_column($movies, 'imdb_code')));
    if (!empty($imdbCodes)) {
        $ph = implode(',', array_fill(0, count($imdbCodes), '?'));
        $stmt = $pdo->prepare("SELECT m.imdb_code FROM watchlist w JOIN movies m ON w.movie_id=m.id WHERE w.user_id=? AND m.imdb_code IN ($ph)");
        $stmt->execute(array_merge([$currentUserId], $imdbCodes));
        $userWatchlist    = $stmt->fetchAll(PDO::FETCH_COLUMN);
        $userWatchlistSet = array_flip($userWatchlist);
    }
}
?>
<!DOCTYPE html>
<html lang="<?= $langAttr ?>" dir="<?= $dir ?>">
<head>
<meta name="theme-color" content="#05050a">
    <!-- BankMovie favicon v37 -->
    <link rel="icon" href="/favicon.ico?v=102.2" sizes="any">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/icons/favicon-32.png?v=37">
    <link rel="icon" type="image/png" sizes="192x192" href="/assets/icons/favicon-192.png?v=102.2">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
<title><?= e($userLang === 'fa' ? $pageTitleFa : $pageTitleEn) ?> | BankMovie</title>
<style>
@font-face{font-family:'BonVF';src:url('/assets/fonts/bonVF.woff2') format('woff2');font-weight:100 900;font-display:swap}
*{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent}
:root{--bg-primary:#08090d;--bg-secondary:#101116;--bg-tertiary:#171922;--bg-card:#0e1017;--bg-card-hover:#151926;--accent:<?= e($currentTheme['primary']) ?>;--accent-rgb:<?= e($currentThemeRgbCss) ?>;--accent-dark:<?= e($currentTheme['primary']) ?>cc;--accent-glow:rgba(var(--accent-rgb),.14);--text-primary:#fff;--text-secondary:#a4a8b6;--text-tertiary:#6e7384;--border-subtle:rgba(255,255,255,.075);--border-accent:rgba(var(--accent-rgb),.28);--gradient-hero:linear-gradient(135deg,#fff,var(--accent));--gradient-donate:linear-gradient(135deg,#ff3366,#ff6633);--shadow-soft:0 18px 50px rgba(0,0,0,.38)}
html{scroll-behavior:smooth}
body{min-height:100vh;background:radial-gradient(circle at 18% -10%,rgba(var(--accent-rgb),.16),transparent 34%),radial-gradient(circle at 88% 12%,rgba(59,130,246,.08),transparent 36%),#08090d;color:var(--text-primary);font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,Segoe UI,sans-serif;overflow-x:hidden;padding-bottom:104px}
button,input,select,textarea,a,p,h1,h2,h3,h4,h5,h6,span,div{font-family:var(--bm-site-font, 'BonVF'),system-ui,-apple-system,Segoe UI,sans-serif}
::-webkit-scrollbar{width:7px;height:7px}::-webkit-scrollbar-track{background:#101116}::-webkit-scrollbar-thumb{background:var(--accent);border-radius:10px}svg{display:block}

.header{position:sticky;top:0;z-index:100;background:rgba(8,9,13,.74);border-bottom:1px solid rgba(255,255,255,.07);backdrop-filter:blur(22px);transition:.22s ease}.header.header-solid{background:rgba(8,9,13,.94);box-shadow:0 16px 34px rgba(0,0,0,.24)}.header-inner{max-width:1400px;height:68px;margin:0 auto;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:18px}.logo{display:inline-flex;align-items:center;gap:10px;text-decoration:none;color:#fff;min-width:0}.logo-icon{width:34px;height:34px}.logo-text{font-size:18px;font-weight:900;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent}.desktop-nav{display:flex;align-items:center;gap:8px;flex:1;justify-content:center}.desktop-nav-item{display:inline-flex;align-items:center;gap:8px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:760;padding:10px 14px;border-radius:999px;border:1px solid transparent;transition:.2s ease}.desktop-nav-item svg{width:17px;height:17px;stroke:currentColor}.desktop-nav-item:hover,.desktop-nav-item.active{color:#fff;background:rgba(255,255,255,.055);border-color:rgba(255,255,255,.08)}.header-actions{display:flex;align-items:center;gap:10px;flex-shrink:0}.menu-btn,.notif-bell{width:42px;height:42px;border-radius:50%;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle);display:flex;align-items:center;justify-content:center;cursor:pointer;position:relative;color:#fff;transition:.2s}.menu-btn svg,.notif-bell svg{width:20px;height:20px;stroke:currentColor}.menu-btn:hover,.notif-bell:hover{background:var(--accent-glow);border-color:var(--border-accent);color:var(--accent)}.notif-badge{position:absolute;top:7px;right:9px;width:8px;height:8px;background:#ff3b5c;border-radius:50%}.donate-btn{display:inline-flex;align-items:center;gap:7px;background:var(--gradient-donate);border-radius:999px;padding:10px 16px;font-size:12px;font-weight:850;color:#fff;border:none;cursor:pointer;transition:.2s}.donate-btn:hover{transform:translateY(-1px)}.auth-dropdown{position:relative}.auth-trigger,.user-trigger{height:42px;display:flex;align-items:center;gap:8px;background:rgba(255,255,255,.045);border:1px solid var(--border-subtle);border-radius:999px;padding:0 13px;font-size:12px;font-weight:760;color:#fff;cursor:pointer;transition:.2s}.auth-dropdown:hover .auth-menu{opacity:1;visibility:visible;transform:translateY(6px)}.auth-menu{position:absolute;top:100%;left:0;min-width:190px;background:rgba(17,19,28,.96);border:1px solid var(--border-subtle);border-radius:18px;padding:8px;box-shadow:var(--shadow-soft);backdrop-filter:blur(18px);opacity:0;visibility:hidden;transform:translateY(0);transition:.2s;z-index:120}.auth-menu a{display:flex;align-items:center;gap:9px;text-decoration:none;color:var(--text-secondary);font-size:12px;font-weight:760;padding:10px 12px;border-radius:13px}.auth-menu a:hover{background:var(--accent-glow);color:var(--accent)}.auth-menu svg{width:16px;height:16px}
.menu-overlay{position:fixed;inset:0;background:rgba(0,0,0,.68);backdrop-filter:blur(8px);z-index:180;opacity:0;visibility:hidden;transition:.22s}.menu-overlay.active{opacity:1;visibility:visible}.sidebar-menu{position:fixed;top:0;bottom:0;right:0;width:min(330px,88vw);background:rgba(13,15,23,.96);border-left:1px solid var(--border-subtle);z-index:190;transform:translateX(105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px);display:flex;flex-direction:column}.sidebar-menu.open{transform:translateX(0)}[dir=ltr] .sidebar-menu{right:auto;left:0;transform:translateX(-105%)}[dir=ltr] .sidebar-menu.open{transform:translateX(0)}.sidebar-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.sidebar-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.sidebar-user{margin:18px 18px 10px;padding:18px;border:1px solid var(--border-subtle);border-radius:24px;background:linear-gradient(145deg,rgba(var(--accent-rgb),.12),rgba(255,255,255,.035));text-align:center}.sidebar-avatar{width:58px;height:58px;border-radius:50%;margin:0 auto 10px;background:rgba(var(--accent-rgb),.12);border:1px solid var(--border-accent);display:flex;align-items:center;justify-content:center;color:var(--accent)}.sidebar-avatar svg{width:28px;height:28px}.sidebar-username{font-weight:900}.sidebar-userrole{margin-top:3px;color:var(--text-tertiary);font-size:12px}.sidebar-nav,.sidebar-footer{padding:10px 14px;display:flex;flex-direction:column;gap:6px}.sidebar-nav{flex:1}.sidebar-item{display:flex;align-items:center;gap:12px;text-decoration:none;color:var(--text-secondary);font-size:13px;font-weight:780;padding:13px 14px;border-radius:16px;transition:.18s}.sidebar-item:hover,.sidebar-item.active{background:var(--accent-glow);color:var(--accent)}.sidebar-item svg{width:19px;height:19px;stroke:currentColor}.notif-sidebar{position:fixed;top:0;bottom:0;left:0;width:min(380px,92vw);background:rgba(13,15,23,.97);border-right:1px solid var(--border-subtle);z-index:185;transform:translateX(-105%);transition:.28s cubic-bezier(.2,.8,.2,1);backdrop-filter:blur(22px)}[dir=ltr] .notif-sidebar{left:auto;right:0;transform:translateX(105%);border-right:none;border-left:1px solid var(--border-subtle)}.notif-sidebar.open{transform:translateX(0)}.notif-header{height:74px;padding:0 20px;border-bottom:1px solid var(--border-subtle);display:flex;justify-content:space-between;align-items:center}.notif-header h3{font-size:18px;color:var(--accent)}.notif-close{width:38px;height:38px;border-radius:50%;border:1px solid var(--border-subtle);background:rgba(255,255,255,.04);color:#fff;display:flex;align-items:center;justify-content:center;cursor:pointer}.notif-list{padding:16px;display:flex;flex-direction:column;gap:10px}.notif-item{padding:14px;border-radius:18px;background:rgba(255,255,255,.04);border:1px solid var(--border-subtle)}.notif-message{font-size:13px;line-height:1.7}.notif-date{margin-top:8px;color:var(--text-tertiary);font-size:11px}
/* V65: shared/V64 footer-nav CSS is the only owner on View All. */
.modal{display:none;position:fixed;inset:0;background:rgba(0,0,0,.82);backdrop-filter:blur(14px);z-index:10020;align-items:center;justify-content:center;padding:22px}.modal.active{display:flex}.modal-content{background:linear-gradient(180deg,#151823,#0f1118);border:1px solid var(--border-subtle);border-radius:30px;max-width:420px;width:100%;padding:26px;text-align:center;box-shadow:var(--shadow-soft)}.btn-primary{height:46px;border-radius:999px;background:var(--accent);color:#050505;font-weight:900;display:inline-flex;align-items:center;justify-content:center;width:100%;border:none;cursor:pointer}
.page-title{max-width:1400px;margin:0 auto 20px;padding:28px 20px 0}.page-title h1{font-size:30px;font-weight:900;background:var(--gradient-hero);-webkit-background-clip:text;background-clip:text;color:transparent}.page-title h1 span{font-size:16px;color:var(--accent);background:none;-webkit-text-fill-color:var(--accent)}.page-title .count{color:var(--text-tertiary);font-size:14px;margin-top:8px}
.result-tools{max-width:1400px;margin:0 auto 18px;padding:0 20px;display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap}.result-hint{display:inline-flex;align-items:center;gap:8px;color:var(--text-tertiary);font-size:12px;font-weight:760}.result-hint svg{width:16px;height:16px;stroke:var(--accent)}
.movies-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:0 20px 20px;max-width:1400px;margin:0 auto;align-items:start}.grid-item{border-radius:26px;overflow:hidden;background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(255,255,255,.022));border:1px solid rgba(255,255,255,.075);box-shadow:0 18px 46px rgba(0,0,0,.22);transform:translateZ(0);isolation:isolate;cursor:pointer;transition:.2s;text-decoration:none;color:inherit;display:block;position:relative}.grid-item:before{content:"";position:absolute;inset:0;border-radius:inherit;background:linear-gradient(135deg,rgba(var(--accent-rgb),.18),transparent 34%,rgba(255,255,255,.045));opacity:0;transition:.28s;pointer-events:none;z-index:3}.grid-item:hover{transform:translateY(-8px);border-color:rgba(var(--accent-rgb),.34);box-shadow:0 24px 56px rgba(0,0,0,.46)}.grid-item:hover:before{opacity:1}.poster-shell{position:relative;width:100%;aspect-ratio:2/3;overflow:hidden;background:linear-gradient(145deg,#11141d,#050608)}.poster-shell .grid-poster{width:100%;height:100%;object-fit:cover;display:block;transition:transform .45s cubic-bezier(.2,.8,.2,1),filter .3s;will-change:transform}.grid-item:hover .poster-shell .grid-poster{transform:scale(1.055);filter:saturate(1.08) contrast(1.04)}.poster-shell:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.34) 0%,transparent 30%,rgba(0,0,0,.08) 48%,rgba(0,0,0,.86) 100%);z-index:1;pointer-events:none}.poster-shine{position:absolute;inset:-30% -80%;background:linear-gradient(115deg,transparent 42%,rgba(255,255,255,.14),transparent 58%);transform:translateX(-55%) rotate(4deg);opacity:0;transition:.55s;z-index:2;pointer-events:none}.grid-item:hover .poster-shine{opacity:1;transform:translateX(55%) rotate(4deg)}.poster-top-row{position:absolute;top:10px;left:10px;right:10px;display:flex;align-items:flex-start;justify-content:space-between;gap:8px;z-index:4;pointer-events:none}.imdb-poster-badge{display:inline-flex;align-items:center;gap:6px;min-height:27px;padding:4px 7px;background:rgba(0,0,0,.72);border:1px solid rgba(255,255,255,.13);border-radius:10px;backdrop-filter:blur(12px)}.imdb-poster-badge b{display:inline-flex;align-items:center;height:18px;padding:0 5px;border-radius:5px;background:#f5c518;color:#050505;font-weight:950;font-size:10px;line-height:1;font-family:Arial,sans-serif}.imdb-poster-badge .imdb-mini-svg{width:30px;height:15px;display:block;object-fit:contain;border-radius:3px}.imdb-poster-badge em{font-style:normal;color:#fff;font-weight:900;font-size:11px}.year-poster-badge{display:inline-flex;align-items:center;justify-content:center;min-height:27px;padding:4px 9px;border-radius:10px;background:rgba(var(--accent-rgb),.88);color:#050505;font-weight:950;font-size:11px}.watchlist-icon-grid{position:absolute;top:48px;inset-inline-end:10px;width:34px;height:34px;z-index:5;border:1px solid rgba(255,255,255,.14);background:rgba(0,0,0,.58);backdrop-filter:blur(12px);color:#fff;display:flex;align-items:center;justify-content:center;border-radius:50%;cursor:pointer;transition:.2s}.watchlist-icon-grid:hover{background:rgba(var(--accent-rgb),.18);border-color:rgba(var(--accent-rgb),.45);color:var(--accent)}.watchlist-icon-grid.active svg{fill:var(--accent);stroke:var(--accent)}.watchlist-icon-grid svg{width:16px;height:16px;stroke:currentColor;fill:none;stroke-width:1.5}.poster-bottom-badges{position:absolute;left:10px;right:10px;bottom:10px;z-index:4;display:flex;align-items:center;gap:6px;flex-wrap:wrap;pointer-events:none}.poster-media-badge{display:inline-flex;align-items:center;gap:5px;min-height:24px;padding:4px 8px;border-radius:999px;background:rgba(0,0,0,.64);border:1px solid rgba(255,255,255,.11);color:#fff;font-size:10px;font-weight:850;backdrop-filter:blur(10px)}.poster-media-badge svg{width:12px;height:12px;stroke:currentColor;fill:none}.poster-media-badge.dub{color:var(--accent);border-color:rgba(var(--accent-rgb),.38);background:rgba(var(--accent-rgb),.12)}.poster-media-badge.soft{color:#9dc2ff;border-color:rgba(90,142,255,.34);background:rgba(68,112,255,.12)}.card-hover-layer{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.42);z-index:3;opacity:0;transition:.24s;pointer-events:none}.grid-item:hover .card-hover-layer{opacity:1}.card-hover-layer span{display:inline-flex;align-items:center;gap:7px;padding:10px 14px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.16);color:#fff;font-size:12px;font-weight:900;backdrop-filter:blur(14px)}.grid-info{position:relative;z-index:2}.pro-grid-info{padding:12px!important;background:linear-gradient(180deg,rgba(13,16,24,.98),rgba(7,8,12,.99));border-top:1px solid rgba(255,255,255,.055)}.grid-title-fa{font-size:13px;font-weight:900;letter-spacing:-.2px;line-height:1.55;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.grid-title-en{font-size:10.5px;color:rgba(255,255,255,.47);margin-bottom:10px;direction:ltr;text-align:start;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.grid-meta.pro-meta{display:flex;align-items:center;justify-content:flex-start;gap:8px;color:var(--text-secondary);font-size:10.5px}.grid-badge.pro-type{font-weight:900;border:1px solid rgba(var(--accent-rgb),.24);background:rgba(var(--accent-rgb),.10);color:var(--accent);padding:4px 9px;border-radius:20px;font-size:10px}
/* Archive 1 Watchlist Cards */
.a1-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:0 20px 20px;max-width:1400px;margin:0 auto}
.a1-card{background:linear-gradient(180deg,rgba(255,255,255,.07),rgba(255,255,255,.022));border:1px solid rgba(255,255,255,.075);border-radius:26px;overflow:hidden;text-decoration:none;color:inherit;display:block;transition:.2s;position:relative}
.a1-card:hover{transform:translateY(-8px);border-color:rgba(var(--accent-rgb),.34);box-shadow:0 24px 56px rgba(0,0,0,.46)}
.a1-card .poster-shell{position:relative;width:100%;aspect-ratio:2/3;overflow:hidden;background:#11141d}
.a1-card .poster-shell img{width:100%;height:100%;object-fit:cover;transition:transform .45s}
.a1-card:hover .poster-shell img{transform:scale(1.055)}
.a1-poster-overlay{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.3),transparent 30%,rgba(0,0,0,.8) 100%);z-index:1}
.a1-badges{position:absolute;bottom:10px;left:10px;right:10px;z-index:2;display:flex;gap:6px;flex-wrap:wrap;pointer-events:none}
.a1-badge{display:inline-flex;align-items:center;gap:4px;padding:4px 8px;border-radius:999px;background:rgba(0,0,0,.65);border:1px solid rgba(255,255,255,.12);color:#fff;font-size:10px;font-weight:800;backdrop-filter:blur(8px)}.a1-badge .imdb-mini-svg{width:28px;height:14px;display:block;object-fit:contain;border-radius:3px}
.a1-badge.ext{color:var(--accent);border-color:rgba(var(--accent-rgb),.35);background:rgba(var(--accent-rgb),.12)}
.a1-remove{position:absolute;top:8px;inset-inline-end:8px;width:32px;height:32px;border-radius:50%;background:rgba(255,68,68,.15);border:1px solid rgba(255,68,68,.2);color:#ff9999;display:flex;align-items:center;justify-content:center;cursor:pointer;z-index:4;transition:.2s;font-size:16px}
.a1-remove:hover{background:rgba(255,68,68,.35)}
.a1-info{padding:11px 11px 13px;background:linear-gradient(180deg,rgba(13,16,24,.98),rgba(7,8,12,.99));border-top:1px solid rgba(255,255,255,.055)}
.a1-title{font-size:13px;font-weight:900;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:3px}
.a1-title-en{font-size:10px;color:rgba(255,255,255,.45);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.empty-state{text-align:center;padding:80px 20px;color:var(--text-tertiary);grid-column:1/-1}.empty-state svg{width:80px;height:80px;margin:0 auto 20px;opacity:.5}.page-link{background:var(--bg-secondary);border:1px solid var(--border-subtle);border-radius:40px;padding:8px 16px;color:var(--text-primary);text-decoration:none;font-size:13px;transition:.2s;display:inline-flex;align-items:center;gap:6px}.page-link:hover{border-color:var(--accent);background:var(--accent-glow)}.page-link.active{background:var(--accent);color:#000}.pagination{display:flex;justify-content:center;gap:8px;margin:34px 0 50px;flex-wrap:wrap}
.toast-container{position:fixed;top:80px;right:16px;left:16px;z-index:10001;display:flex;flex-direction:column;gap:8px;pointer-events:none}.toast{background:var(--bg-tertiary);border:1px solid var(--border-accent);border-radius:60px;padding:12px 20px;animation:slideIn .3s;pointer-events:auto;backdrop-filter:blur(10px);font-size:13px;text-align:center;max-width:400px;margin:0 auto}.loading-overlay{position:fixed;inset:0;background:#0a0a0c;z-index:9999;display:flex;align-items:center;justify-content:center;transition:.5s}.loading-overlay.hide{opacity:0;visibility:hidden;pointer-events:none}.loading-spinner{width:50px;height:50px;border:3px solid var(--border-subtle);border-top-color:var(--accent);border-radius:50%;animation:spin 1s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}@keyframes slideIn{from{transform:translateX(100%);opacity:0}to{transform:translateX(0);opacity:1}}
.footer-space{height:18px}
@media(max-width:991px){.desktop-nav,.auth-dropdown{display:none}.header-inner{height:62px;padding:0 14px}.movies-grid,.a1-grid{padding:0 12px 20px}.page-title{padding:20px 12px 0}.result-tools{padding:0 12px}}
@media(min-width:992px){body{padding-bottom:50px}.menu-btn{display:none}}
@media(max-width:540px){.movies-grid,.a1-grid{grid-template-columns:repeat(2,1fr)!important;gap:14px}}
@media(min-width:600px){.movies-grid,.a1-grid{grid-template-columns:repeat(4,1fr);gap:20px}}
@media(min-width:900px){.movies-grid,.a1-grid{grid-template-columns:repeat(5,1fr);gap:24px}}
@media(min-width:1200px){.movies-grid,.a1-grid{grid-template-columns:repeat(6,1fr)}}
</style>

<style id="bm-imdb-viewall-size-fix">
/* Robust IMDb logo sizing for View All cards */
img.imdb-mini-svg, .imdb-mini-svg{
    width:28px!important;
    height:auto!important;
    max-width:28px!important;
    max-height:14px!important;
    object-fit:contain!important;
    display:inline-block!important;
    vertical-align:middle!important;
    flex:0 0 auto!important;
}
.a1-badge img.imdb-mini-svg, .a1-badge .imdb-mini-svg{
    width:25px!important;
    height:13px!important;
    max-width:25px!important;
    max-height:13px!important;
}
.imdb-poster-badge img.imdb-mini-svg, .imdb-poster-badge .imdb-mini-svg{
    width:28px!important;
    height:14px!important;
    max-width:28px!important;
    max-height:14px!important;
}
.a1-badge{line-height:1!important;align-items:center!important;gap:5px!important}
.imdb-poster-badge{line-height:1!important;align-items:center!important}
</style>
<!-- BankMovie performance hints: CSS only + tiny low-power detector; no PHP/site logic changed. -->
<script>(function(){try{var d=document.documentElement,m=function(q){return window.matchMedia&&matchMedia(q).matches},c=navigator.connection||navigator.mozConnection||navigator.webkitConnection;if(m('(prefers-reduced-motion: reduce)')||(c&&c.saveData)||(m('(max-width: 768px)')&&((navigator.deviceMemory&&navigator.deviceMemory<=4)||(navigator.hardwareConcurrency&&navigator.hardwareConcurrency<=4))))d.classList.add('bm-low-power')}catch(e){}})();</script>
<script id="bm-device-tier">(function(d,n){try{var r=d.documentElement,m=function(q){return !!(window.matchMedia&&matchMedia(q).matches)},c=n.connection||n.mozConnection||n.webkitConnection||{},w=m('(max-width:900px)'),e=String(c.effectiveType||''),mem=Number(n.deviceMemory||0),cpu=Number(n.hardwareConcurrency||0),re=m('(prefers-reduced-motion:reduce)'),save=!!c.saveData,slow=/slow-2g|2g/.test(e),ultra=w&&(save||slow||(mem&&mem<=2)||(cpu&&cpu<=2)),low=re||save||slow||(w&&((mem&&mem<=3)||(cpu&&cpu<=4))),lite=w&&(low||(mem&&mem<=4)||(cpu&&cpu<=4));if(w)r.classList.add('bm-scroll-lite');if(low)r.classList.add('bm-low-power');if(lite)r.classList.add('bm-mobile-lite');if(ultra)r.classList.add('bm-ultra-lite');window.__BM_DEVICE_TIER__={mobile:w,low:low,lite:lite,ultra:ultra,saveData:save,effectiveType:e,memory:mem,cores:cpu}}catch(x){}})(document,navigator);</script>
<link rel="preload" href="/assets/css/bm-performance.css?v=mobile-lite66" as="style">
<link rel="stylesheet" href="/assets/css/bm-performance.css?v=mobile-lite66">
<link rel="stylesheet" href="/assets/css/bm-blue-black-theme.css?v=blue92">
<link rel="stylesheet" href="/assets/css/bm-ui-v93.css?v=93">
<!-- BankMovie PWA v95 -->
<link rel="manifest" href="/manifest.php?v=102.2">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="بانک مووی">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/icons/favicon-180.png?v=102.2">
<link rel="stylesheet" href="/assets/css/bm-header-v106.css?v=109">

<link rel="stylesheet" href="/assets/css/bm-premium-ui-v143.css?v=143">
<link rel="stylesheet" href="/assets/css/bm-footer-home-sync-v14861921.css?v=14861921">
</head>
<body data-theme="<?= e($userTheme) ?>" class="view-all-page">
<?php require __DIR__ . '/partials/loading_manager_assets.php'; ?>

<div class="toast-container" id="toastContainer"></div>
<div class="menu-overlay" id="menuOverlay"></div>

<div class="sidebar-menu" id="sidebarMenu">
    <div class="sidebar-header"><span class="logo-text">BankMovie</span><button class="sidebar-close" id="closeMenuBtn" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <?php if ($currentUser): ?>
    <div class="sidebar-user"><div class="sidebar-avatar"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg></div><div class="sidebar-username"><?= e($currentUser['username'] ?? '') ?></div><div class="sidebar-userrole"><?= $currentUser['role'] === 'admin' ? 'ادمین' : 'کاربر' ?></div></div>
    <?php endif; ?>
    <div class="sidebar-nav">
        <a href="/" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2h-5v-7H9v7H4a2 2 0 0 1-2-2z"/></svg><span><?= $t[$userLang]['home'] ?></span></a>
        <a href="/search" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg><span><?= $t[$userLang]['search'] ?></span></a>
        <a href="/player" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg><span><?= $t[$userLang]['player'] ?></span></a>
        <a href="archive1.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10"/></svg><span>آرشیو ۱</span></a>
        <a href="/collections" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 15a4 4 0 0 1-4 4H7l-4 4V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/></svg><span><?= $userLang==='fa'?'کالکشن‌ها':'Collections' ?></span></a>
        <?php if ($currentUser): ?><a href="/profile" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg><span><?= $t[$userLang]['profile'] ?></span></a><?php if ($currentUser['role'] === 'admin'): ?><a href="/admin.php" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg><span><?= $t[$userLang]['admin_panel'] ?></span></a><?php endif; ?><?php endif; ?>
    </div>
    <div class="sidebar-footer">
        <?php if ($currentUser): ?><a href="/logout" class="sidebar-item" onclick="return confirm('خروج؟')"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg><span><?= $t[$userLang]['logout'] ?></span></a>
        <?php else: ?><a href="/login" class="sidebar-item"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg><span><?= $t[$userLang]['login'] ?></span></a><?php endif; ?>
    </div>
</div>

<div class="notif-sidebar" id="notifSidebar">
    <div class="notif-header"><h3><?= $t[$userLang]['notifications'] ?></h3><button class="notif-close" id="closeNotifSidebar" type="button"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg></button></div>
    <div class="notif-list">
        <?php if ($notificationsList): foreach ($notificationsList as $n): ?><div class="notif-item"><div class="notif-message"><?= nl2br(e($n['message'] ?? '')) ?></div><div class="notif-date"><?= e(date('Y/m/d H:i', strtotime($n['created_at']))) ?></div></div><?php endforeach; else: ?><div style="text-align:center;padding:30px;color:var(--text-tertiary)"><?= $t[$userLang]['no_notifications'] ?></div><?php endif; ?>
    </div>
</div>

<?php require __DIR__ . '/partials/shared_header.php'; ?>
<script src="/assets/js/bm-header-tweaks.js?v=1486199" defer></script>


<div class="page-title">
    <h1><?= e($userLang === 'fa' ? $pageTitleFa : $pageTitleEn) ?> <span><?= e($userLang === 'fa' ? $pageTitleEn : $pageTitleFa) ?></span></h1>
    <?php if (!$errorMessage && $totalCount > 0): ?>
    <div class="count"><?= number_format($totalCount) ?> <?= $userLang === 'fa' ? 'عنوان' : 'items' ?></div>
    <?php endif; ?>
</div>

<?php if ($errorMessage): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($errorMessage) ?></p><a href="/login" class="page-link"><?= $userLang === 'fa' ? 'ورود' : 'Login' ?></a></div></div>

<?php elseif ($isArchive1WatchList): ?>
    <!-- ===== آرشیو ۱ واچ‌لیست ===== -->
    <?php if (!empty($archive1Items)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg>نشانه‌های آرشیو ۱ (فیلم ۲ مدیا) - لینک مستقیم به صفحه فیلم</div>
    </div>
    <div class="a1-grid" id="a1WatchGrid">
        <?php foreach ($archive1Items as $item): ?>
        <div class="a1-card" data-id="<?= (int)$item['id'] ?>">
            <a href="<?= e($item['item_link']) ?>" target="_blank" rel="noopener" style="text-decoration:none;color:inherit;display:block">
                <div class="poster-shell">
                    <?php if (!empty($item['item_poster'])): ?>
                    <img src="<?= e(bm_view_all_poster_url($item['item_poster'], $item)) ?>" alt="<?= e($item['item_title_fa'] ?: $item['item_title']) ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                    <?php else: ?>
                    <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                    <?php endif; ?>
                    <div class="a1-poster-overlay"></div>
                    <div class="a1-badges">
                        <?php if (!empty($item['item_year'])): ?><span class="a1-badge"><?= e($item['item_year']) ?></span><?php endif; ?>
                        <?php if (!empty($item['item_imdb_rate']) && $item['item_imdb_rate'] > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$item['item_imdb_rate'], 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                        <span class="a1-badge ext">آرشیو ۱</span>
                    </div>
                </div>
                <div class="a1-info">
                    <div class="a1-title"><?= e($item['item_title_fa'] ?: $item['item_title']) ?></div>
                    <div class="a1-title-en"><?= e($item['item_title']) ?></div>
                </div>
            </a>
            <button class="a1-remove" title="حذف از نشانه‌ها" data-id="<?= (int)$item['id'] ?>" onclick="removeA1(this)">×</button>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg><p><?= $userLang === 'fa' ? 'هنوز چیزی به نشانه‌های آرشیو ۱ اضافه نکرده‌اید' : 'No items in Archive 1 watchlist yet' ?></p><a href="archive1.php" class="page-link">برو به آرشیو ۱</a></div></div>
    <?php endif; ?>

<?php elseif ($isArc1Category): ?>
    <!-- ===== آرشیو ۱ — کتگوری ===== -->
    <?php if ($arc1CatError): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($arc1CatError) ?></p></div></div>
    <?php elseif (!empty($arc1CatItems)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg><?= e($pageTitleFa) ?> — صفحه <?= (int)$page ?></div>
    </div>
    <div class="a1-grid" id="arc1CatGrid">
        <?php foreach ($arc1CatItems as $item):
            $isSeries = ($item['type'] ?? 'movie') === 'series';
            $movieUrl = '/movie/arc1-' . rawurlencode($item['slug']);
        ?>
        <a href="<?= e($movieUrl) ?>" class="a1-card" aria-label="<?= e($item['title'] ?? '') ?>">
            <div class="poster-shell">
                <?php if (!empty($item['poster'])): ?>
                <img src="<?= e(bm_view_all_poster_url($item['poster'], $item)) ?>" alt="<?= e($item['title'] ?? '') ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                <?php endif; ?>
                <div class="a1-poster-overlay"></div>
                <div class="a1-badges">
                    <?php if (!empty($item['year'])): ?><span class="a1-badge"><?= e($item['year']) ?></span><?php endif; ?>
                    <?php if (!empty($item['rating']) && $item['rating'] > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$item['rating'], 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                    <span class="a1-badge ext"><?= $isSeries ? 'سریال' : 'فیلم' ?></span>
                </div>
            </div>
            <div class="a1-info">
                <div class="a1-title"><?= e($item['title'] ?? '') ?></div>
                <?php if (!empty($item['update_note'])): ?><div class="a1-title-en"><?= e($item['update_note']) ?></div><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <!-- صفحه‌بندی آرشیو ۱ -->
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?type=arc1_category&cat=<?= e($arc1Cat) ?>&page=<?= $page - 1 ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a>
        <?php for ($i = max(1, $page - 2); $i < $page; $i++): ?>
        <a href="?type=arc1_category&cat=<?= e($arc1Cat) ?>&page=<?= $i ?>" class="page-link"><?= $i ?></a>
        <?php endfor; ?>
        <?php endif; ?>
        <span class="page-link active"><?= $page ?></span>
        <?php if ($arc1CatHasMore): ?>
        <a href="?type=arc1_category&cat=<?= e($arc1Cat) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $page + 1 ?></a>
        <a href="?type=arc1_category&cat=<?= e($arc1Cat) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php endif; ?>
        <?php /* اگر صفحه‌های بیشتری وجود داشته باشد، دکمه بعدی نمایش داده می‌شود */ ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php endif; ?>

<?php elseif ($isArc1Updates): ?>
    <!-- ===== آرشیو ۱ — مشاهده همه آپدیت‌ها ===== -->
    <?php if ($arc1UpdatesError): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($arc1UpdatesError) ?></p></div></div>
    <?php elseif (!empty($arc1UpdatesItems)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M21 12a9 9 0 0 1-9 9m9-9a9 9 0 0 0-9-9m9 9h-4m-5 9A9 9 0 0 1 3 12m9 9v-4M3 12a9 9 0 0 1 9-9m-9 9h4m7-9a9 9 0 0 1 9 9"/><circle cx="12" cy="12" r="3"/></svg><?= e($pageTitleFa) ?> — صفحه <?= (int)$page ?></div>
        <a href="/" class="page-link"><?= $userLang === 'fa' ? 'بازگشت به خانه' : 'Back home' ?></a>
    </div>
    <div class="a1-grid" id="arc1UpdatesGrid">
        <?php foreach ($arc1UpdatesItems as $item):
            $isSeries = ($item['type'] ?? 'movie') === 'series';
            $movieUrl = '/movie/arc1-' . rawurlencode($item['slug'] ?? ($item['id'] ?? ''));
            $ratingValue = $item['rating'] ?? 0;
            if (is_array($ratingValue)) $ratingValue = $ratingValue['imdb'] ?? 0;
        ?>
        <a href="<?= e($movieUrl) ?>" class="a1-card" aria-label="<?= e($item['title'] ?? '') ?>">
            <div class="poster-shell">
                <?php if (!empty($item['poster'])): ?>
                <img src="<?= e(bm_view_all_poster_url($item['poster'], $item)) ?>" alt="<?= e($item['title'] ?? '') ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                <?php endif; ?>
                <div class="a1-poster-overlay"></div>
                <div class="a1-badges">
                    <?php if (!empty($item['year'])): ?><span class="a1-badge"><?= e($item['year']) ?></span><?php endif; ?>
                    <?php if (!empty($ratingValue) && $ratingValue > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$ratingValue, 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                    <span class="a1-badge ext"><?= $isSeries ? 'سریال' : 'فیلم' ?></span>
                </div>
            </div>
            <div class="a1-info">
                <div class="a1-title"><?= e($item['title'] ?? '') ?></div>
                <?php if (!empty($item['update_note'])): ?><div class="a1-title-en"><?= e($item['update_note']) ?></div><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?type=arc1_updates&kind=<?= e($arc1UpdatesKind) ?>&page=<?= $page - 1 ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a>
        <?php for ($i = max(1, $page - 2); $i < $page; $i++): ?>
        <a href="?type=arc1_updates&kind=<?= e($arc1UpdatesKind) ?>&page=<?= $i ?>" class="page-link"><?= $i ?></a>
        <?php endfor; ?>
        <?php endif; ?>
        <span class="page-link active"><?= $page ?></span>
        <?php if ($arc1UpdatesHasMore): ?>
        <a href="?type=arc1_updates&kind=<?= e($arc1UpdatesKind) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $page + 1 ?></a>
        <a href="?type=arc1_updates&kind=<?= e($arc1UpdatesKind) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php endif; ?>

<?php elseif ($isArc1Search): ?>
    <!-- ===== آرشیو ۱ — مشاهده همه نتایج سرچ ===== -->
    <?php if ($arc1SearchError): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($arc1SearchError) ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php elseif (!empty($arc1SearchItems)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>نتایج کامل سرچ «<?= e($arc1SearchQuery) ?>»</div>
        <a href="/" class="page-link"><?= $userLang === 'fa' ? 'بازگشت به خانه' : 'Back home' ?></a>
    </div>
    <div class="a1-grid" id="arc1SearchGrid">
        <?php foreach ($arc1SearchItems as $item):
            $isSeries = ($item['type'] ?? 'movie') === 'series';
            $movieUrl = '/movie/arc1-' . rawurlencode($item['slug'] ?? ($item['id'] ?? ''));
            $ratingValue = $item['rating'] ?? 0;
            if (is_array($ratingValue)) $ratingValue = $ratingValue['imdb'] ?? 0;
        ?>
        <a href="<?= e($movieUrl) ?>" class="a1-card" aria-label="<?= e($item['title'] ?? '') ?>">
            <div class="poster-shell">
                <?php if (!empty($item['poster'])): ?>
                <img src="<?= e(bm_view_all_poster_url($item['poster'], $item)) ?>" alt="<?= e($item['title'] ?? '') ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                <?php endif; ?>
                <div class="a1-poster-overlay"></div>
                <div class="a1-badges">
                    <?php if (!empty($item['year'])): ?><span class="a1-badge"><?= e($item['year']) ?></span><?php endif; ?>
                    <?php if (!empty($ratingValue) && $ratingValue > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$ratingValue, 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                    <span class="a1-badge ext"><?= $isSeries ? 'سریال' : 'فیلم' ?></span>
                </div>
            </div>
            <div class="a1-info">
                <div class="a1-title"><?= e($item['title'] ?? '') ?></div>
                <?php if (!empty($item['update_note'])): ?><div class="a1-title-en"><?= e($item['update_note']) ?></div><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?type=arc1_search&q=<?= rawurlencode($arc1SearchQuery) ?>&page=<?= $page - 1 ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a>
        <?php for ($i = max(1, $page - 2); $i < $page; $i++): ?>
        <a href="?type=arc1_search&q=<?= rawurlencode($arc1SearchQuery) ?>&page=<?= $i ?>" class="page-link"><?= $i ?></a>
        <?php endfor; ?>
        <?php endif; ?>
        <span class="page-link active"><?= $page ?></span>
        <?php if ($arc1SearchHasMore): ?>
        <a href="?type=arc1_search&q=<?= rawurlencode($arc1SearchQuery) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $page + 1 ?></a>
        <a href="?type=arc1_search&q=<?= rawurlencode($arc1SearchQuery) ?>&page=<?= $page + 1 ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php endif; ?>

<?php elseif ($isArc4List): ?>
    <!-- ===== آرشیو ۴ ===== -->
    <?php if ($arc4Error): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($arc4Error) ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php elseif (!empty($arc4Items)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg><?= e($pageTitleFa) ?> — آرشیو ۴</div>
        <a href="/" class="page-link"><?= $userLang === 'fa' ? 'بازگشت به خانه' : 'Back home' ?></a>
    </div>
    <div class="a1-grid" id="arc4Grid">
        <?php foreach ($arc4Items as $item):
            $itemType = $item['type'] ?? 'movie';
            $mediaKind = $item['media_kind'] ?? '';
            $isSeries = $itemType === 'series';
            $isAnimation = $mediaKind === 'animation';
            $isAnime = $mediaKind === 'anime' || $itemType === 'anime';
            $label = $isAnimation ? 'انیمیشن' : ($isAnime ? 'انیمه' : ($isSeries ? 'سریال' : 'فیلم'));
            $updateText = trim((string)($item['status_text'] ?? ($item['status'] ?? '')));
            $updateText = preg_replace('/^دانلود\s+.+?\s*:\s*/u', '', $updateText);
            $arc4DetailId = trim((string)($item['detail_id'] ?? ''));
            if ($arc4DetailId === '' && !empty($item['source_post_id'])) $arc4DetailId = 'p' . (int)$item['source_post_id'];
            if ($arc4DetailId === '') $arc4DetailId = trim((string)($item['slug'] ?? ($item['id'] ?? ($item['imdb_code'] ?? ''))));
            $movieUrl = '/movie/arc4-' . rawurlencode($arc4DetailId);
            $ratingValue = $item['rating'] ?? 0;
            if (is_array($ratingValue)) $ratingValue = $ratingValue['imdb'] ?? 0;
        ?>
        <a href="<?= e($movieUrl) ?>" class="a1-card" aria-label="<?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?>">
            <div class="poster-shell">
                <?php if (!empty($item['poster'])): ?>
                <img src="<?= e(bm_view_all_poster_url($item['poster'], $item)) ?>" alt="<?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                <?php endif; ?>
                <div class="a1-poster-overlay"></div>
                <div class="a1-badges">
                    <?php if (!empty($item['year'])): ?><span class="a1-badge"><?= e($item['year']) ?></span><?php endif; ?>
                    <?php if (!empty($ratingValue) && $ratingValue > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$ratingValue, 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                    <span class="a1-badge ext"><?= e($label) ?></span>
                </div>
            </div>
            <div class="a1-info">
                <div class="a1-title"><bdi dir="auto"><?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?></bdi></div>
                <?php if (!empty($item['title']) && !empty($item['title_fa']) && $item['title'] !== $item['title_fa']): ?><div class="a1-title-en"><?= e($item['title']) ?></div><?php endif; ?>
                <?php if (($isSeries || $isAnime || $isAnimation) && $updateText !== ''): ?><div class="a1-title-en" title="<?= e($updateText) ?>"><?= e($updateText) ?></div><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="pagination">
        <?php
            $baseHref = $arc4Kind === 'search'
                ? '?type=arc4_search&q=' . rawurlencode($arc4Query) . '&page='
                : '?type=arc4_section&kind=' . rawurlencode($arc4Kind) . '&page=';
        ?>
        <?php if ($page > 1): ?>
        <a href="<?= e($baseHref . ($page - 1)) ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a>
        <?php for ($i = max(1, $page - 2); $i < $page; $i++): ?>
        <a href="<?= e($baseHref . $i) ?>" class="page-link"><?= $i ?></a>
        <?php endfor; ?>
        <?php endif; ?>
        <span class="page-link active"><?= $page ?></span>
        <?php if ($arc4HasMore): ?>
        <a href="<?= e($baseHref . ($page + 1)) ?>" class="page-link"><?= $page + 1 ?></a>
        <a href="<?= e($baseHref . ($page + 1)) ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php endif; ?>


<?php elseif ($isArc3List): ?>
    <!-- ===== آرشیو ۳ ===== -->
    <?php if ($arc3Error): ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg><p><?= e($arc3Error) ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php elseif (!empty($arc3Items)): ?>
    <div class="result-tools">
        <div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M2 12h20"/></svg><?= e($pageTitleFa) ?> — آرشیو ۳</div>
        <a href="/" class="page-link"><?= $userLang === 'fa' ? 'بازگشت به خانه' : 'Back home' ?></a>
    </div>
    <div class="a1-grid" id="arc3Grid">
        <?php foreach ($arc3Items as $item):
            $itemType = $item['type'] ?? 'movie';
            $mediaKind = $item['media_kind'] ?? '';
            $isSeries = $itemType === 'series';
            $isAnimation = $mediaKind === 'animation';
            $isAnime = $mediaKind === 'anime' || $itemType === 'anime';
            $label = $isAnimation ? 'انیمیشن' : ($isAnime ? 'انیمه' : ($isSeries ? 'سریال' : 'فیلم'));
            $updateText = trim((string)($item['status_text'] ?? ($item['status'] ?? '')));
            $updateText = preg_replace('/^دانلود\s+.+?\s*:\s*/u', '', $updateText);
            $arc3DetailId = $item['detail_id'] ?? (!empty($item['source_post_id']) ? ('p' . $item['source_post_id']) : ($item['slug'] ?? ($item['id'] ?? ($item['imdb_code'] ?? ''))));
            $movieUrl = '/movie/arc3-' . rawurlencode((string)$arc3DetailId);
            $ratingValue = $item['rating'] ?? 0;
            if (is_array($ratingValue)) $ratingValue = $ratingValue['imdb'] ?? 0;
        ?>
        <a href="<?= e($movieUrl) ?>" class="a1-card" aria-label="<?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?>">
            <div class="poster-shell">
                <?php if (!empty($item['poster'])): ?>
                <img src="<?= e(bm_view_all_poster_url($item['poster'], $item)) ?>" alt="<?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?>" loading="lazy" onerror="this.src='/uploads/no.png'">
                <?php else: ?>
                <div style="width:100%;height:100%;background:linear-gradient(135deg,#1a1a2e,#16213e);display:flex;align-items:center;justify-content:center"><svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)"><rect x="2" y="4" width="20" height="16" rx="2"/><path d="M10 9l5 3-5 3V9z"/></svg></div>
                <?php endif; ?>
                <div class="a1-poster-overlay"></div>
                <div class="a1-badges">
                    <?php if (!empty($item['year'])): ?><span class="a1-badge"><?= e($item['year']) ?></span><?php endif; ?>
                    <?php if (!empty($ratingValue) && $ratingValue > 0): ?><span class="a1-badge is-imdb"><span class="bm-imdb-score"><?= number_format((float)$ratingValue, 1) ?></span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span><?php endif; ?>
                    <span class="a1-badge ext"><?= e($label) ?></span>
                </div>
            </div>
            <div class="a1-info">
                <div class="a1-title"><bdi dir="auto"><?= e($item['title_fa'] ?? ($item['title'] ?? '')) ?></bdi></div>
                <?php if (!empty($item['title']) && !empty($item['title_fa']) && $item['title'] !== $item['title_fa']): ?><div class="a1-title-en"><?= e($item['title']) ?></div><?php endif; ?>
                <?php if (($isSeries || $isAnime || $isAnimation) && $updateText !== ''): ?><div class="a1-title-en" title="<?= e($updateText) ?>"><?= e($updateText) ?></div><?php endif; ?>
            </div>
        </a>
        <?php endforeach; ?>
    </div>
    <div class="pagination">
        <?php
            $baseHref = $arc3Kind === 'search'
                ? '?type=arc3_search&q=' . rawurlencode($arc3Query) . '&page='
                : '?type=arc3_section&kind=' . rawurlencode($arc3Kind) . '&page=';
        ?>
        <?php if ($page > 1): ?>
        <a href="<?= e($baseHref . ($page - 1)) ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a>
        <?php for ($i = max(1, $page - 2); $i < $page; $i++): ?>
        <a href="<?= e($baseHref . $i) ?>" class="page-link"><?= $i ?></a>
        <?php endfor; ?>
        <?php endif; ?>
        <span class="page-link active"><?= $page ?></span>
        <?php if ($arc3HasMore): ?>
        <a href="<?= e($baseHref . ($page + 1)) ?>" class="page-link"><?= $page + 1 ?></a>
        <a href="<?= e($baseHref . ($page + 1)) ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a>
        <?php endif; ?>
    </div>
    <?php else: ?>
    <div class="a1-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p><a href="/" class="page-link">بازگشت</a></div></div>
    <?php endif; ?>

<?php elseif (!empty($movies)): ?>
    <div class="result-tools"><div class="result-hint"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M4 6h16M4 12h10M4 18h7"/></svg><?= $userLang === 'fa' ? 'امتیاز IMDb، سال، دوبله و زیرنویس روی پوستر نمایش داده می‌شوند.' : 'IMDb rating, year, dub and subtitle badges shown on poster.' ?></div></div>
    <div class="movies-grid" id="moviesGrid"></div>
    <?php if ($lastPage > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?><a href="?type=<?= e($type) ?>&page=<?= $page-1 ?>" class="page-link">« <?= $userLang === 'fa' ? 'قبلی' : 'Prev' ?></a><?php endif; ?>
        <?php for ($i = max(1,$page-2); $i <= min($lastPage,$page+2); $i++): ?><a href="?type=<?= e($type) ?>&page=<?= $i ?>" class="page-link <?= $i==$page?'active':'' ?>"><?= $i ?></a><?php endfor; ?>
        <?php if ($page < $lastPage): ?><a href="?type=<?= e($type) ?>&page=<?= $page+1 ?>" class="page-link"><?= $userLang === 'fa' ? 'بعدی' : 'Next' ?> »</a><?php endif; ?>
    </div>
    <?php endif; ?>
<?php else: ?>
    <div class="movies-grid"><div class="empty-state"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="2" y="4" width="20" height="16" rx="2"/></svg><p><?= $userLang === 'fa' ? 'نتیجه‌ای یافت نشد' : 'No results found' ?></p></div></div>
<?php endif; ?>

<div class="footer-space"></div>

<?php if (function_exists('bm_render_support_card') && (!function_exists('bm_site_bool') || bm_site_bool('support_before_footer', true))) { bm_render_support_card('view_all.php', 'standalone'); } ?>
<?php require_once __DIR__ . '/includes/_bm_site_footer.php'; bm_render_site_footer($userLang ?? ($_COOKIE['user_lang'] ?? 'fa')); ?>
<?php require __DIR__ . '/partials/shared_bottom_nav.php'; ?>

<div id="donateModal" class="modal"><div class="modal-content"><div style="background:var(--gradient-donate);width:70px;height:70px;border-radius:50%;margin:0 auto 18px;display:flex;align-items:center;justify-content:center;"><svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div><h3 style="margin-bottom:10px;font-size:22px;"><?= $t[$userLang]['support_us'] ?></h3><p style="color:var(--text-secondary);margin-bottom:20px;font-size:13px;line-height:1.8;"><?= $t[$userLang]['support_text'] ?></p><button id="openDonateLink" class="btn-primary"><?= $t[$userLang]['donate'] ?></button><button id="closeDonateModal" type="button" style="margin-top:12px;background:none;border:none;color:var(--text-tertiary);cursor:pointer;display:block;width:100%"><?= $t[$userLang]['close'] ?></button></div></div>

<script>
const moviesData       = <?= json_encode($movies, JSON_UNESCAPED_UNICODE) ?>;
const userWatchlistSet = <?= json_encode($userWatchlistSet, JSON_UNESCAPED_UNICODE) ?>;
const isLoggedIn       = <?= $isLoggedIn ? 'true' : 'false' ?>;
const userLang         = '<?= $userLang ?>';
const DEFAULT_POSTER   = '/uploads/no.png';
const isA1WatchList    = <?= $isArchive1WatchList ? 'true' : 'false' ?>;

function showToast(msg) {
    const c = document.getElementById('toastContainer');
    c.querySelectorAll('.toast').forEach(t => t.remove());
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg;
    c.appendChild(t); setTimeout(() => t.remove(), 3000);
}
function hideLoading() {
    const ov = document.getElementById('loadingOverlay');
    if (ov) { ov.classList.add('hide'); setTimeout(() => ov.style.display = 'none', 500); }
}

// حذف آیتم از واچ‌لیست آرشیو ۱
async function removeA1(btn) {
    const id = btn.dataset.id;
    const card = btn.closest('.a1-card');
    try {
        const fd = new FormData();
        fd.append('action', 'remove');
        fd.append('id', id);
        const res = await fetch('/ajax_archive1_watchlist.php', { method: 'POST', body: fd });
        const data = await res.json();
        if (data.success) {
            card && card.remove();
            showToast(userLang === 'fa' ? 'حذف شد' : 'Removed');
        } else showToast(data.error || 'خطا');
    } catch(e) { showToast('خطا در ارتباط'); }
}

function setupMenu() {
    const mb = document.getElementById('menuBtn'), sb = document.getElementById('sidebarMenu'),
          ov = document.getElementById('menuOverlay'), cb = document.getElementById('closeMenuBtn');
    if (!mb||!sb||!ov||!cb) return;
    const open = () => { sb.classList.add('open'); ov.classList.add('active'); document.body.style.overflow='hidden'; };
    const close = () => { sb.classList.remove('open'); ov.classList.remove('active'); document.body.style.overflow=''; };
    mb.addEventListener('click', open); cb.addEventListener('click', close); ov.addEventListener('click', close);
    window.addEventListener('resize', () => { if (window.innerWidth >= 992) close(); });
}
/* V65: shared header keeps one state; no View All header-solid scroll switch. */
/* V65: removed legacy View All footer-nav scroll controller. */
function setupNotifAndDonate() {
    const bell=document.getElementById('notifBell'),nsb=document.getElementById('notifSidebar'),ncb=document.getElementById('closeNotifSidebar');
    if(bell&&nsb&&ncb){bell.addEventListener('click',()=>nsb.classList.add('open'));ncb.addEventListener('click',()=>nsb.classList.remove('open'));document.addEventListener('click',e=>{if(nsb.classList.contains('open')&&!nsb.contains(e.target)&&!bell.contains(e.target))nsb.classList.remove('open');});}
    const db=document.getElementById('donateModalBtn'),dm=document.getElementById('donateModal'),dcm=document.getElementById('closeDonateModal'),odl=document.getElementById('openDonateLink');
    if(db&&dm)db.onclick=()=>dm.classList.add('active');if(dcm&&dm)dcm.onclick=()=>dm.classList.remove('active');if(odl&&dm)odl.onclick=()=>{window.open('https://daramet.com/manuel','_blank');dm.classList.remove('active');};if(dm)dm.addEventListener('click',e=>{if(e.target===dm)dm.classList.remove('active');});
}

function escHtml(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function bmSlugifyTitle(v){return String(v||'movie').normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'').replace(/-+/g,'-')||'movie';}
function bmMovieUrl(m){const s=bmSlugifyTitle(m.title||m.title_en||m.title_fa||'movie'),id=m.id||m.movie_id||'';return `/movie/${s}${id?'-'+encodeURIComponent(id):''}`;}

async function toggleWatchlist(imdbCode, element) {
    if (!isLoggedIn) { showToast(userLang==='fa'?'لطفاً وارد شوید':'Please login'); setTimeout(()=>window.location.href='/login',1500); return; }
    const isActive = element.classList.contains('active');
    const fd = new FormData(); fd.append('action', isActive?'remove':'add'); fd.append('imdb_code', imdbCode);
    try {
        const res = await fetch('/ajax_watchlist.php', { method:'POST', body:fd });
        const data = await res.json();
        if (data.success) {
            if (data.added) { element.classList.add('active'); element.querySelector('svg').setAttribute('fill','var(--accent)'); showToast(userLang==='fa'?'افزودن به نشانه‌ها':'Added'); }
            else { element.classList.remove('active'); element.querySelector('svg').setAttribute('fill','none'); showToast(userLang==='fa'?'حذف از نشانه‌ها':'Removed'); }
        } else showToast(data.error||(userLang==='fa'?'خطا':'Error'));
    } catch(e) { showToast(userLang==='fa'?'خطا در ارتباط':'Error'); }
}

function renderMoviesGrid() {
    const container = document.getElementById('moviesGrid');
    if (!container || isA1WatchList) { hideLoading(); return; }
    if (!moviesData || moviesData.length === 0) {
        container.innerHTML = `<div class="empty-state"><p>${userLang==='fa'?'نتیجه‌ای یافت نشد':'No results'}</p></div>`;
        hideLoading(); return;
    }
    container.innerHTML = moviesData.map(m => {
        const typeLabel = m.type==='movie'?(userLang==='fa'?'فیلم':'Movie'):(userLang==='fa'?'سریال':'Series');
        const inWl = userWatchlistSet[m.imdb_code] !== undefined;
        const rating = parseFloat(m.user_rating||m.imdb_rate||0);
        const ratingStr = Number.isFinite(rating)&&rating>0 ? rating.toFixed(1) : 'N/A';
        const poster = m.imdb_code ? `/posters/${m.imdb_code}.webp` : DEFAULT_POSTER;
        const hasDub  = parseInt(m.dub_count||0,10) > 0;
        const hasSoft = parseInt(m.soft_count||0,10) > 0;
        const dubBadge  = hasDub ? `<span class="poster-media-badge dub"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v3M8 22h8"/></svg>${userLang==='fa'?'دوبله':'Dub'}</span>` : '';
        const softBadge = hasSoft ? `<span class="poster-media-badge soft"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M7 15h4M13 15h4M7 11h10"/></svg>${userLang==='fa'?'زیرنویس':'Sub'}</span>` : '';
        const fallback  = (!hasDub&&!hasSoft) ? `<span class="poster-media-badge">${typeLabel}</span>` : '';
        const pct = m.progress&&m.progress>0&&m.progress<95 ? Number(m.progress) : 0;
        const progress = pct > 0 ? `<div style="position:absolute;left:10px;right:10px;bottom:42px;height:3px;background:rgba(255,255,255,.22);border-radius:999px;overflow:hidden;z-index:5"><div style="height:100%;background:var(--accent);width:${pct}%"></div></div>` : '';
        return `<a href="${bmMovieUrl(m)}" class="grid-item" aria-label="${escHtml(m.title_fa||m.title)}">
            <div class="poster-shell">
                <img class="grid-poster" src="${poster}" loading="lazy" alt="${escHtml(m.title_fa||m.title)}" onerror="this.src='${DEFAULT_POSTER}'">
                <div class="poster-shine"></div>
                <div class="poster-top-row"><span class="imdb-poster-badge"><span class="bm-imdb-score">${escHtml(ratingStr)}</span><img class="imdb-mini-svg" src="/assets/brand/imdb-logo.svg" alt="IMDb" loading="lazy"></span>${m.year?`<span class="year-poster-badge">${escHtml(m.year)}</span>`:''}</div>
                <div class="watchlist-icon-grid ${inWl?'active':''}" data-imdb="${escHtml(m.imdb_code)}"><svg viewBox="0 0 24 24" fill="${inWl?'var(--accent)':'none'}" stroke="currentColor"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg></div>
                ${progress}
                <div class="poster-bottom-badges">${dubBadge}${softBadge}${fallback}</div>
                <div class="card-hover-layer"><span>${userLang==='fa'?'مشاهده جزئیات':'View details'}</span></div>
            </div>
            <div class="grid-info pro-grid-info"><div class="grid-title-fa">${escHtml(m.title_fa||m.title)}</div><div class="grid-title-en">${escHtml(m.title||'')}</div><div class="grid-meta pro-meta"><span class="grid-badge pro-type">${typeLabel}</span></div></div>
        </a>`;
    }).join('');
    document.querySelectorAll('.watchlist-icon-grid').forEach(icon => {
        icon.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); toggleWatchlist(icon.dataset.imdb, icon); });
    });
    hideLoading();
}

if (moviesData && moviesData.length > 0 && !isA1WatchList) renderMoviesGrid();
else hideLoading();
setupMenu(); setupNotifAndDonate();
</script>
<script src="/assets/js/bm-performance.js?v=mobile-lite66" defer></script>
<script src="/assets/js/pwa.js?v=95" defer></script>

<script src="/assets/js/bm-premium-ui-v143.js?v=143" defer></script>
</body>
</html>
