<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/includes/download_redirect.php';
require_once __DIR__ . '/includes/poster_redirect.php';
require_once __DIR__ . '/includes/bm_runtime_performance.php';
bm_perf_boot(['entry' => basename((string)($_SERVER['SCRIPT_NAME'] ?? 'config.php'))]);
// config.php - نسخه امن‌تر و پایدار
// نکته: مقدارهای دیتابیس را روی سرور خودت تنظیم کن. رمز واقعی را داخل چت یا فایل عمومی نگذار.

// ============================================
// تنظیمات مسیرها و لاگ
// ============================================
$folders = ['logs', 'cache', 'posters', 'uploads', 'uploads/collections', 'uploads/stories', 'uploads/slider', 'uploads/banners'];
foreach ($folders as $folder) {
    $path = __DIR__ . '/' . $folder;
    if (!is_dir($path)) {
        @mkdir($path, 0755, true);
    }
}

ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', function_exists('bm_security_private_path') ? bm_security_private_path('php-error.log') : (__DIR__ . '/logs/php-error.log'));
date_default_timezone_set('Asia/Tehran');

// ============================================
// تنظیمات دیتابیس
// پیشنهاد بهتر: این مقدارها را از ENV بخوان.
// ============================================
define('DB_HOST', bm_security_secret('db_host', 'BANKMOVIE_DB_HOST', 'localhost'));
define('DB_NAME', bm_security_secret('db_name', 'BANKMOVIE_DB_NAME'));
define('DB_USER', bm_security_secret('db_user', 'BANKMOVIE_DB_USER'));
define('DB_PASS', bm_security_secret('db_pass', 'BANKMOVIE_DB_PASS'));

// ============================================
// تنظیمات سبک دامنه و SEO (بدون اتصال دیتابیس)
// ============================================
require_once __DIR__ . '/includes/site_bootstrap.php';
require_once __DIR__ . '/includes/site_content_control.php';

define('TELEGRAM_BOT_TOKEN', bm_security_secret('telegram_bot_token', 'BANKMOVIE_TELEGRAM_BOT_TOKEN'));
define('TELEGRAM_WEBHOOK_URL', bm_security_secret('telegram_webhook_url', 'BANKMOVIE_TELEGRAM_WEBHOOK_URL', rtrim(SITE_URL, '/') . '/bot.php'));

// ============================================
// اتصال به دیتابیس
// ============================================
if (DB_NAME === '' || DB_USER === '' || DB_PASS === '') {
    error_log('BankMovie database secrets are not configured.');
    http_response_code(503);
    die('تنظیمات امن دیتابیس کامل نشده است. فایل private/secrets را بررسی کنید.');
}

$pdoOptions = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::ATTR_PERSISTENT => false,
    PDO::ATTR_TIMEOUT => 5,
];
// PDO::MYSQL_ATTR_INIT_COMMAND فقط وقتی pdo_mysql در محیط فعال باشد وجود دارد.
if (defined('PDO::MYSQL_ATTR_INIT_COMMAND')) {
    $pdoOptions[constant('PDO::MYSQL_ATTR_INIT_COMMAND')] = "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci";
}

$pdo = null;
$lastDbError = null;
$dbStartedAt = microtime(true);
for ($dbAttempt = 0; $dbAttempt < 3; $dbAttempt++) {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            $pdoOptions
        );
        break;
    } catch (PDOException $e) {
        $lastDbError = $e;
        $driverCode = (int)($e->errorInfo[1] ?? 0);
        $sqlState = (string)($e->errorInfo[0] ?? $e->getCode());
        $isTransient = str_starts_with($sqlState, '08') || in_array($driverCode, [1040, 1203, 2002, 2006, 2013], true);
        if (!$isTransient || $dbAttempt >= 2) break;
        usleep(($dbAttempt + 1) * 180000);
    }
}
bm_perf_note('db_connect_ms', round((microtime(true) - $dbStartedAt) * 1000, 2));
if (!$pdo instanceof PDO) {
    $message = $lastDbError ? $lastDbError->getMessage() : 'Unknown database connection error';
    error_log("DB Connection Error: " . $message);
    bm_perf_note('db_connection_error', $message);
    http_response_code(500);
    die("خطا در اتصال به دیتابیس. لطفاً چند ثانیه بعد دوباره تلاش کنید.");
}

// ============================================
// سشن امن روی دیتابیس با انقضای شناور
// ============================================
bm_schema_once($pdo, 'db-sessions', 2, static function (PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS db_sessions (
        session_id VARCHAR(128) PRIMARY KEY,
        session_data TEXT,
        expires_at DATETIME,
        INDEX idx_expires (expires_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
});

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

// مهمان‌ها کوتاه‌مدت‌اند؛ کاربر یا ادمین فعال تا ۷ روز پس از آخرین فعالیت حفظ می‌شود.
const BM_GUEST_SESSION_TTL = 7200;
const BM_AUTH_SESSION_TTL  = 604800;

final class BankMovieDbSessionHandler implements SessionHandlerInterface, SessionUpdateTimestampHandlerInterface {
    public function __construct(private PDO $pdo) {}

    public function open(string $path, string $name): bool {
        return true;
    }

    public function close(): bool {
        return true;
    }

    private function isAuthenticatedData(string $data): bool {
        if ($data === '') return false;

        foreach (['user_id', 'admin_logged', 'admin_username', 'admin'] as $key) {
            if (str_contains($data, $key)) {
                return true;
            }
        }
        return false;
    }

    private function ttlForData(string $data): int {
        return $this->isAuthenticatedData($data)
            ? BM_AUTH_SESSION_TTL
            : BM_GUEST_SESSION_TTL;
    }

    private function expiresAt(string $data): string {
        return date('Y-m-d H:i:s', time() + $this->ttlForData($data));
    }

    public function read(string $id): string|false {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT session_data
                 FROM db_sessions
                 WHERE session_id = ? AND expires_at > NOW()
                 LIMIT 1"
            );
            $stmt->execute([$id]);
            $data = $stmt->fetchColumn();
            return $data === false ? '' : (string)$data;
        } catch (PDOException $e) {
            error_log("Session read error: " . $e->getMessage());
            return '';
        }
    }

    public function write(string $id, string $data): bool {
        try {
            // Session کاملاً خالی مهمان، رکورد جدید نسازد.
            if ($data === '') {
                $stmt = $this->pdo->prepare("DELETE FROM db_sessions WHERE session_id = ?");
                $stmt->execute([$id]);
                return true;
            }

            $stmt = $this->pdo->prepare(
                "INSERT INTO db_sessions (session_id, session_data, expires_at)
                 VALUES (?, ?, ?)
                 ON DUPLICATE KEY UPDATE
                    session_data = VALUES(session_data),
                    expires_at = VALUES(expires_at)"
            );
            return $stmt->execute([$id, $data, $this->expiresAt($data)]);
        } catch (PDOException $e) {
            error_log("Session write error: " . $e->getMessage());
            return false;
        }
    }

    public function destroy(string $id): bool {
        try {
            $stmt = $this->pdo->prepare("DELETE FROM db_sessions WHERE session_id = ?");
            return $stmt->execute([$id]);
        } catch (PDOException $e) {
            error_log("Session destroy error: " . $e->getMessage());
            return false;
        }
    }

    public function gc(int $max_lifetime): int|false {
        try {
            // یک حاشیه امن یک‌ساعته برای جلوگیری از حذف در درخواست‌های هم‌زمان.
            $stmt = $this->pdo->prepare(
                "DELETE FROM db_sessions
                 WHERE expires_at IS NULL
                    OR expires_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)"
            );
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $e) {
            error_log("Session gc error: " . $e->getMessage());
            return false;
        }
    }

    public function validateId(string $id): bool {
        try {
            $stmt = $this->pdo->prepare(
                "SELECT 1 FROM db_sessions
                 WHERE session_id = ? AND expires_at > NOW()
                 LIMIT 1"
            );
            $stmt->execute([$id]);
            return (bool)$stmt->fetchColumn();
        } catch (PDOException $e) {
            error_log("Session validate error: " . $e->getMessage());
            return false;
        }
    }

    public function updateTimestamp(string $id, string $data): bool {
        try {
            // حتی اگر محتوای Session تغییر نکند، زمان انقضا با هر درخواست تمدید می‌شود.
            $stmt = $this->pdo->prepare(
                "UPDATE db_sessions
                 SET expires_at = ?
                 WHERE session_id = ?"
            );
            $stmt->execute([$this->expiresAt($data), $id]);

            if ($stmt->rowCount() > 0) {
                return true;
            }
            return $this->write($id, $data);
        } catch (PDOException $e) {
            error_log("Session timestamp update error: " . $e->getMessage());
            return false;
        }
    }
}

ini_set('session.use_strict_mode', '1');
ini_set('session.gc_probability', '0');
ini_set('session.gc_divisor', '100');
ini_set('session.gc_maxlifetime', (string)BM_AUTH_SESSION_TTL);

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'domain' => '',
    'secure' => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);

$bmSessionHandler = new BankMovieDbSessionHandler($pdo);
session_set_save_handler($bmSessionHandler, true);

// فقط Sessionهایی پاک می‌شوند که بیش از یک ساعت از انقضای واقعی‌شان گذشته باشد.
try {
    if (random_int(1, 100) === 1) {
        $pdo->exec(
            "DELETE FROM db_sessions
             WHERE expires_at IS NULL
                OR expires_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)
             LIMIT 5000"
        );
    }
} catch (Throwable $e) {
    error_log("Session cleanup error: " . $e->getMessage());
}

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Cookie سشن کاربر یا ادمین فعال نیز با هر درخواست برای ۷ روز تمدید می‌شود.
$bmHasAuthenticatedPhpSession =
    !empty($_SESSION['user_id']) ||
    !empty($_SESSION['admin_logged']) ||
    !empty($_SESSION['admin_username']) ||
    !empty($_SESSION['admin']);

if ($bmHasAuthenticatedPhpSession && session_id() !== '' && !headers_sent()) {
    setcookie(session_name(), session_id(), [
        'expires' => time() + BM_AUTH_SESSION_TTL,
        'path' => '/',
        'domain' => '',
        'secure' => $isHttps,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

// ============================================
// Helperها
// ============================================
function bm_cookie_options(bool $httpOnly = false): array {
    $secure = function_exists('bm_security_is_https') ? bm_security_is_https() : false;

    return [
        'expires' => time() + 31536000,
        'path' => '/',
        'domain' => '',
        'secure' => $secure,
        'httponly' => $httpOnly,
        'samesite' => 'Lax',
    ];
}

if (!function_exists('bm_session_cookie_options')) {
    function bm_session_cookie_options(int $ttl = 604800): array {
        $secure = function_exists('bm_security_is_https') ? bm_security_is_https() : false;
        return [
            'expires' => time() + $ttl,
            'path' => '/',
            'domain' => '',
            'secure' => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ];
    }
}

if (!function_exists('bm_user_csrf_token')) {
    function bm_user_csrf_token(): string {
        if (empty($_SESSION['csrf_token'])) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }
        return $_SESSION['csrf_token'];
    }
}

if (!function_exists('bm_user_csrf_field')) {
    function bm_user_csrf_field(): string {
        return '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(bm_user_csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
    }
}

if (!function_exists('bm_request_is_same_origin')) {
    function bm_request_is_same_origin(): bool {
        $host = strtolower((string)($_SERVER['HTTP_HOST'] ?? ''));
        if ($host === '') return false;
        foreach (['HTTP_ORIGIN', 'HTTP_REFERER'] as $key) {
            $value = (string)($_SERVER[$key] ?? '');
            if ($value === '') continue;
            $p = @parse_url($value);
            $h = strtolower((string)($p['host'] ?? ''));
            return $h !== '' && hash_equals($host, $h);
        }
        // Backward-compatible fallback for older same-site XHR that may not send Origin/Referer.
        return empty($_SERVER['HTTP_ORIGIN']) && empty($_SERVER['HTTP_REFERER']);
    }
}

if (!function_exists('bm_verify_user_csrf')) {
    function bm_verify_user_csrf(): bool {
        $expected = (string)($_SESSION['csrf_token'] ?? '');
        $sent = $_POST['csrf_token'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        return is_string($sent) && $expected !== '' && hash_equals($expected, $sent);
    }
}

if (!function_exists('bm_require_user_csrf')) {
    function bm_require_user_csrf(bool $json = false, bool $allowSameOriginFallback = true): void {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') return;
        if (bm_verify_user_csrf()) return;
        if ($allowSameOriginFallback && bm_request_is_same_origin()) return;
        http_response_code(419);
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'invalid csrf token'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        exit('درخواست نامعتبر است. صفحه را تازه‌سازی کنید.');
    }
}

if (!function_exists('bm_require_post')) {
    function bm_require_post(bool $json = true): void {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') return;
        http_response_code(405);
        if ($json) {
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(['success' => false, 'error' => 'method not allowed'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        exit('Method not allowed');
    }
}

if (!function_exists('bm_csrf_url')) {
    function bm_csrf_url(string $url): string {
        $sep = str_contains($url, '?') ? '&' : '?';
        return $url . $sep . 'csrf_token=' . urlencode(bm_user_csrf_token());
    }
}

if (!function_exists('bm_require_get_csrf')) {
    function bm_require_get_csrf(array $unsafeKeys): void {
        foreach ($unsafeKeys as $key) {
            if (!isset($_GET[$key])) continue;
            $expected = (string)($_SESSION['csrf_token'] ?? '');
            $sent = (string)($_GET['csrf_token'] ?? '');
            if ($expected !== '' && hash_equals($expected, $sent)) return;
            http_response_code(419);
            exit('درخواست نامعتبر است. لطفاً از داخل سایت دوباره اقدام کنید.');
        }
    }
}



// ============================================
// Helperهای URL سئو برای فیلم/سریال
// لینک اصلی دیگر imdb_code را نشان نمی‌دهد و به شکل /movie/english-title-id ساخته می‌شود.
// ============================================
if (!function_exists('bm_slugify')) {
    function bm_slugify($text, string $fallback = 'movie'): string {
        $text = trim((string)($text ?? ''));
        if ($text === '') {
            $text = $fallback;
        }
        $text = str_replace(['&', '+'], ' and ', $text);
        if (function_exists('iconv')) {
            $converted = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text);
            if (is_string($converted) && $converted !== '') {
                $text = $converted;
            }
        }
        $text = strtolower($text);
        $text = preg_replace('/[^a-z0-9]+/', '-', $text);
        $text = trim((string)$text, '-');
        $text = preg_replace('/-+/', '-', $text);
        return $text !== '' ? $text : $fallback;
    }
}

if (!function_exists('bm_movie_url')) {
    function bm_movie_url($movie): string {
        $movie = is_array($movie) ? $movie : [];
        $title = $movie['title'] ?? $movie['title_en'] ?? $movie['movie_title_en'] ?? $movie['movie_title'] ?? $movie['title_fa'] ?? 'movie';
        $slug = bm_slugify($title, 'movie');
        $id = 0;
        foreach (['id', 'movie_id'] as $key) {
            if (isset($movie[$key]) && is_numeric($movie[$key]) && (int)$movie[$key] > 0) {
                $id = (int)$movie[$key];
                break;
            }
        }
        return '/movie/' . $slug . ($id > 0 ? '-' . $id : '');
    }
}

if (!function_exists('bm_find_movie_by_seo_slug')) {
    function bm_find_movie_by_seo_slug(PDO $pdo, string $slug): ?array {
        $slug = trim($slug, "/ \t\n\r\0\x0B");
        if ($slug === '' || !preg_match('/^[a-z0-9-]+$/i', $slug)) {
            return null;
        }

        if (preg_match('/-(\d+)$/', $slug, $m)) {
            $stmt = $pdo->prepare('SELECT * FROM movies WHERE id = ? LIMIT 1');
            $stmt->execute([(int)$m[1]]);
            $movie = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($movie) {
                return $movie;
            }
        }

        // پشتیبانی اختیاری برای دیتابیس‌هایی که ستون slug دارند.
        try {
            $stmt = $pdo->prepare('SELECT * FROM movies WHERE slug = ? LIMIT 1');
            $stmt->execute([$slug]);
            $movie = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($movie) {
                return $movie;
            }
        } catch (Throwable $e) {
            // ستون slug الزامی نیست.
        }

        // fallback برای لینک‌های فقط-عنوان؛ برای کارایی، لینک‌های تولیدی پروژه همیشه id دارند.
        try {
            $stmt = $pdo->query("SELECT * FROM movies WHERE title IS NOT NULL AND title != '' ORDER BY id DESC");
            while ($movie = $stmt->fetch(PDO::FETCH_ASSOC)) {
                if (bm_slugify($movie['title'] ?? 'movie') === $slug) {
                    return $movie;
                }
            }
        } catch (Throwable $e) {
            return null;
        }
        return null;
    }
}

// ============================================
// کلاس Movie
// ============================================
class Movie {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function __destruct() {
        $this->pdo = null;
    }

    public function getByImdb($imdbCode) {
        $stmt = $this->pdo->prepare("SELECT * FROM movies WHERE imdb_code = ?");
        $stmt->execute([$imdbCode]);
        $movie = $stmt->fetch();

        if ($movie) {
            $stmt = $this->pdo->prepare("SELECT * FROM softsub_links WHERE movie_id = ?");
            $stmt->execute([$movie['id']]);
            $movie['softsub_links'] = $stmt->fetchAll();

            $stmt = $this->pdo->prepare("SELECT * FROM dubbed_links WHERE movie_id = ?");
            $stmt->execute([$movie['id']]);
            $movie['dubbed_links'] = $stmt->fetchAll();
        }

        return $movie;
    }

    public function search($keyword, $limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("
            SELECT id, imdb_code, title, title_fa, year, imdb_rate, type
            FROM movies
            WHERE title LIKE ? OR title_fa LIKE ? OR imdb_code LIKE ? OR actors LIKE ?
            LIMIT {$limit}
        ");
        $search = "%{$keyword}%";
        $stmt->execute([$search, $search, $search, $search]);
        return $stmt->fetchAll();
    }

    public function getNewReleases($limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT * FROM movies WHERE year >= YEAR(CURRENT_DATE)-2 AND year>0 ORDER BY year DESC, id DESC LIMIT {$limit}");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getTopRated($type = 'movie', $limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        if ($type === 'series') {
            $stmt = $this->pdo->prepare("SELECT * FROM movies WHERE (type='tvSeries' OR type='tvMiniSeries') AND imdb_rate >= 7 ORDER BY imdb_rate DESC, imdb_votes DESC LIMIT {$limit}");
            $stmt->execute();
        } else {
            $stmt = $this->pdo->prepare("SELECT * FROM movies WHERE type = ? AND imdb_rate >= 7 ORDER BY imdb_rate DESC, imdb_votes DESC LIMIT {$limit}");
            $stmt->execute([$type]);
        }
        return $stmt->fetchAll();
    }

    public function getDubbed($limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT DISTINCT m.* FROM movies m INNER JOIN dubbed_links d ON m.id=d.movie_id ORDER BY m.imdb_rate DESC LIMIT {$limit}");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getAdminPicks($limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT m.* FROM admin_picks ap JOIN movies m ON ap.movie_id=m.id ORDER BY ap.pick_order ASC LIMIT {$limit}");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getStats() {
        return $this->pdo->query("
            SELECT
                (SELECT COUNT(*) FROM movies) AS total,
                (SELECT COUNT(*) FROM movies WHERE type='movie') AS movies,
                (SELECT COUNT(*) FROM movies WHERE type='tvSeries' OR type='tvMiniSeries') AS series
        ")->fetch();
    }

    public function getUpdatedMovies($limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT * FROM movies WHERE updated_at > DATE_SUB(NOW(), INTERVAL 30 DAY) ORDER BY updated_at DESC, id DESC LIMIT {$limit}");
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function getTopUserRated($limit = 20) {
        $limit = max(1, min(100, (int)$limit));
        $stmt = $this->pdo->prepare("
            SELECT m.*, COALESCE(r.avg_rating,0) AS user_rating, COALESCE(r.total_votes,0) AS total_votes
            FROM movies m
            LEFT JOIN movie_ratings r ON m.id=r.movie_id
            WHERE COALESCE(r.total_votes,0)>=3 AND COALESCE(r.avg_rating,0)>=3.5
            ORDER BY r.avg_rating DESC, r.total_votes DESC
            LIMIT {$limit}
        ");
        $stmt->execute();
        $results = $stmt->fetchAll();

        if (!$results) {
            $stmt = $this->pdo->prepare("
                SELECT m.*, AVG(c.rating) AS user_rating, COUNT(c.id) AS total_votes
                FROM movies m
                INNER JOIN comments c ON m.id=c.movie_id
                WHERE c.rating>0 AND c.status='active' AND c.parent_id IS NULL
                GROUP BY m.id
                HAVING COUNT(c.id)>=3 AND AVG(c.rating)>=3.5
                ORDER BY AVG(c.rating) DESC, COUNT(c.id) DESC
                LIMIT {$limit}
            ");
            $stmt->execute();
            $results = $stmt->fetchAll();
        }

        return $results;
    }

    public function getRelatedMovies($imdbCode, $limit = 10) {
        $limit = max(1, min(30, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT genres FROM movies WHERE imdb_code = ?");
        $stmt->execute([$imdbCode]);
        $genres = $stmt->fetchColumn();

        if (empty($genres)) return [];

        $genreArray = array_filter(array_map('trim', explode(',', $genres)));
        $conditions = [];
        $params = [$imdbCode];

        foreach ($genreArray as $genre) {
            if (strlen($genre) > 2) {
                $conditions[] = "genres LIKE ?";
                $params[] = "%{$genre}%";
            }
        }

        if (!$conditions) return [];

        $sql = "SELECT id, imdb_code, title, title_fa, year, imdb_rate, type
                FROM movies
                WHERE imdb_code != ? AND (" . implode(" OR ", $conditions) . ")
                ORDER BY imdb_rate DESC
                LIMIT {$limit}";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public function getMoviesWithoutPoster($limit = 100) {
        $limit = max(1, min(500, (int)$limit));
        $stmt = $this->pdo->prepare("SELECT id, imdb_code, title, title_fa FROM movies WHERE imdb_code IS NOT NULL AND imdb_code != '' ORDER BY id DESC LIMIT {$limit}");
        $stmt->execute();
        $movies = $stmt->fetchAll();

        $result = [];
        foreach ($movies as $m) {
            if (!file_exists(__DIR__ . "/posters/" . $m['imdb_code'] . ".webp")) {
                $result[] = $m;
            }
        }

        return $result;
    }
}

// ============================================
// نشست‌های کاربری با توکن هش‌شده و سازگاری با نشست‌های قدیمی
// ============================================
if (!function_exists('bm_user_token_is_valid')) {
    function bm_user_token_is_valid(string $token): bool {
        return (bool)preg_match('/^[a-f0-9]{64}$/i', $token);
    }
}

if (!function_exists('bm_user_token_storage')) {
    function bm_user_token_storage(string $token): string {
        // 64 characters total for compatibility with existing VARCHAR(64) schemas.
        // The v2: prefix prevents a stolen database value from being replayed as a bearer token.
        return 'v2:' . substr(hash('sha256', $token), 0, 61);
    }
}

if (!function_exists('bm_user_token_candidates')) {
    function bm_user_token_candidates(string $token): array {
        if (!bm_user_token_is_valid($token)) return [];
        // First candidate is the secure representation. The raw token remains only
        // for transparent migration of sessions created by older BankMovie builds.
        return [bm_user_token_storage($token), $token];
    }
}

if (!function_exists('bm_user_session_insert')) {
    function bm_user_session_insert(PDO $pdo, int $userId, string $token, string $expiresAt): void {
        if (!bm_user_token_is_valid($token)) throw new InvalidArgumentException('Invalid session token');
        $stmt = $pdo->prepare('INSERT INTO user_sessions (user_id, session_token, expires_at) VALUES (?, ?, ?)');
        $stmt->execute([$userId, bm_user_token_storage($token), $expiresAt]);
    }
}

if (!function_exists('bm_user_session_delete')) {
    function bm_user_session_delete(PDO $pdo, string $token): void {
        $candidates = bm_user_token_candidates($token);
        if (!$candidates) return;
        $stmt = $pdo->prepare('DELETE FROM user_sessions WHERE session_token IN (?, ?)');
        $stmt->execute($candidates);
    }
}

if (!function_exists('bm_user_session_extend')) {
    function bm_user_session_extend(PDO $pdo, string $token, string $expiresAt): void {
        $candidates = bm_user_token_candidates($token);
        if (!$candidates) return;
        $stmt = $pdo->prepare('UPDATE user_sessions SET expires_at = ? WHERE session_token IN (?, ?)');
        $stmt->execute([$expiresAt, $candidates[0], $candidates[1]]);
    }
}

// ============================================
// کلاس User
// ============================================
class User {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function __destruct() {
        $this->pdo = null;
    }

    public function checkSession($token) {
        $token = trim((string)$token);
        $candidates = bm_user_token_candidates($token);
        if (!$candidates) return false;

        $stmt = $this->pdo->prepare("
            SELECT u.*, s.session_token AS _matched_session_token
            FROM user_sessions s
            JOIN users u ON s.user_id=u.id
            WHERE s.session_token IN (?, ?) AND s.expires_at>NOW()
            LIMIT 1
        ");
        $stmt->execute($candidates);
        $user = $stmt->fetch();

        if ($user) {
            $matched = (string)($user['_matched_session_token'] ?? '');
            unset($user['_matched_session_token']);

            // Transparently migrate an old plaintext token to the v2 hash.
            if ($matched !== '' && hash_equals($token, $matched)) {
                try {
                    $migrate = $this->pdo->prepare('UPDATE user_sessions SET session_token = ? WHERE session_token = ?');
                    $migrate->execute([$candidates[0], $matched]);
                    $matched = $candidates[0];
                } catch (Throwable $e) {
                    error_log('Session token migration failed: ' . $e->getMessage());
                }
            }

            $refresh = $this->pdo->prepare("
                UPDATE user_sessions
                SET expires_at = DATE_ADD(NOW(), INTERVAL 7 DAY)
                WHERE session_token = ?
                  AND expires_at < DATE_ADD(NOW(), INTERVAL 6 DAY)
            ");
            $refresh->execute([$matched !== '' ? $matched : $candidates[0]]);
        }

        return $user;
    }

    public function login($username, $password) {
        $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username=? OR email=? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', time() + 604800);
            bm_user_session_insert($this->pdo, (int)$user['id'], $token, $expires);

            return ['success' => true, 'user' => $user, 'token' => $token];
        }

        return ['success' => false, 'error' => 'نام کاربری یا رمز عبور اشتباه است'];
    }

    public function logout($token) {
        bm_user_session_delete($this->pdo, trim((string)$token));
        return true;
    }

    public function changeTheme($userId, $theme) {
        $allowed = ['dark-green','dark-blue','dark-purple','dark-pink','dark-red','dark-orange','dark-cyan','dark-white','dark-black'];
        if (!in_array($theme, $allowed, true)) $theme = 'dark-green';
        $this->pdo->prepare("UPDATE users SET theme=? WHERE id=?")->execute([$theme, $userId]);
        return true;
    }

    public function changeLanguage($userId, $language) {
        $language = in_array($language, ['fa', 'en'], true) ? $language : 'fa';
        $this->pdo->prepare("UPDATE users SET language=? WHERE id=?")->execute([$language, $userId]);
        return true;
    }
}

// ============================================
// توابع کش
// ============================================
function getCachedGenres($pdo, $forceRefresh = false) {
    $cacheFile = __DIR__ . '/cache/genres.json';

    if (!$forceRefresh && file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
        $data = file_get_contents($cacheFile);
        if ($data) {
            $res = json_decode($data, true);
            if (is_array($res)) return $res;
        }
    }

    $genres = $pdo->query("
        SELECT DISTINCT TRIM(SUBSTRING_INDEX(SUBSTRING_INDEX(genres,',',n),',',-1)) AS genre
        FROM movies
        CROSS JOIN (SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5) numbers
        WHERE genres IS NOT NULL AND genres != ''
        HAVING genre != ''
        ORDER BY genre
    ")->fetchAll(PDO::FETCH_COLUMN);

    file_put_contents($cacheFile, json_encode($genres, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $genres;
}

function getCachedCountries($pdo, $forceRefresh = false) {
    $cacheFile = __DIR__ . '/cache/countries.json';

    if (!$forceRefresh && file_exists($cacheFile) && (time() - filemtime($cacheFile)) < 86400) {
        $data = file_get_contents($cacheFile);
        if ($data) {
            $res = json_decode($data, true);
            if (is_array($res)) return $res;
        }
    }

    $countries = $pdo->query("SELECT DISTINCT TRIM(country) AS country FROM movies WHERE country IS NOT NULL AND country != '' ORDER BY country")
        ->fetchAll(PDO::FETCH_COLUMN);

    file_put_contents($cacheFile, json_encode($countries, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    return $countries;
}

// ============================================
// نمونه‌های اولیه
// ============================================
$movie = new Movie($pdo);
$user = new User($pdo);

$currentUser = null;
if (!empty($_COOKIE['session_token'])) {
    $currentUser = $user->checkSession($_COOKIE['session_token']);

    if ($currentUser && !headers_sent()) {
        // Cookie ورود کاربر فعال هم با هر درخواست برای ۷ روز تمدید می‌شود.
        setcookie('session_token', $_COOKIE['session_token'], bm_session_cookie_options(604800));
    }
}

// Normalize expired VIP memberships before any page, API or legacy role
// check can grant a paid capability. This makes expiry effective immediately.
try {
    require_once __DIR__ . '/includes/vip_features.php';
    if ($currentUser) {
        bm_vip_expire_user_if_needed($pdo, $currentUser);

        // v148.61.9.3 — Site themes are a VIP-only capability. Any theme saved
        // before this change is disabled as soon as a standard/expired member
        // loads the site. Admin accounts retain access.
        if (!bm_vip_benefit_allowed('custom_theme', $currentUser)) {
            $savedTheme = trim((string)($currentUser['theme'] ?? ''));
            if ($savedTheme !== '' && $savedTheme !== 'dark-green') {
                try {
                    $themeReset = $pdo->prepare("UPDATE users SET theme='dark-green' WHERE id=?");
                    $themeReset->execute([(int)$currentUser['id']]);
                } catch (Throwable $themeError) {
                    error_log('VIP theme reset failed: ' . $themeError->getMessage());
                }
            }
            $currentUser['theme'] = 'dark-green';
            if (!headers_sent()) setcookie('user_theme', 'dark-green', bm_cookie_options(false));
            $_COOKIE['user_theme'] = 'dark-green';
        }


        // v148.61.9.7 — custom site fonts are also a VIP-only capability.
        // The preference lives in a browser cookie; once VIP expires (or the
        // capability is disabled) the cookie is removed and the admin-defined
        // default site font takes over immediately.
        if (!bm_vip_benefit_allowed('custom_font', $currentUser)) {
            if (!headers_sent() && isset($_COOKIE['user_font'])) {
                $fontCookie = bm_cookie_options(false);
                $fontCookie['expires'] = time() - 3600;
                setcookie('user_font', '', $fontCookie);
            }
            unset($_COOKIE['user_font']);
        }
    }
} catch (Throwable $e) {
    error_log('VIP expiry bootstrap error: ' . $e->getMessage());
}

if (!$currentUser) {
    if (!isset($_COOKIE['user_theme'])) {
        setcookie('user_theme', 'dark-green', bm_cookie_options(false));
    }
    if (!isset($_COOKIE['user_lang'])) {
        setcookie('user_lang', 'fa', bm_cookie_options(false));
    }
}

// Hidden VIP Watch Party foundation. Housekeeping runs at most once per configured
// interval and hard-deletes rooms (plus all dependent rows) after four hours.
try {
    require_once __DIR__ . '/includes/watch_party.php';
    bm_watch_party_housekeeping_maybe($pdo);
} catch (Throwable $e) {
    error_log('Watch Party bootstrap error: ' . $e->getMessage());
}
?>
