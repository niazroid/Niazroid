BANKMOVIE V7.43 — APP API POLICY ENGINE REPAIR
===============================================

هدف این نسخه ظاهر نیست؛ مسیر کامل BM Admin -> bankmovie_remote_config.json -> app_config/API -> Android تعمیر شده است.

ریشه باگ‌های اصلی که اصلاح شدند
--------------------------------
1) سیاست‌های Android و سیاست عمومی وب‌سایت در چند مسیر با هم قاطی می‌شدند. از V7.43 کنترل آرشیوهای اپ فقط از app_archive_policy در تنظیمات BM Admin خوانده می‌شود.
2) وقتی Download=Public ولی Stream=VIP بود، بعضی Adapterها یک URL مشترک برای دانلود و پخش داشتند. حذف URL برای قفل Stream باعث می‌شد دانلود عمومی هم «لینک وجود ندارد» نشان بدهد. حالا تا وقتی یکی از قابلیت‌ها مجاز است URL مشترک حفظ می‌شود و قفل هر قابلیت با download_gate / stream_gate جداگانه به Android اعلام می‌شود.
3) Hidden / Disabled / Locked قبلاً می‌توانستند به خطای HTTP یا Scraper برسند و اپ فقط «لود نشد» ببیند. حالا Policy قبل از Scraper/DB بررسی می‌شود و State ساختاریافته با HTTP 200 و پیام مدیریت برمی‌گردد.
4) نام Sectionهای Adapterها با نام Toggleهای BM Admin در همه آرشیوها یکی نبود. Aliasهای archive1/2/3/4 قبل از Policy lookup نرمال شده‌اند.
5) Config کش‌شده نسل قدیمی می‌توانست تنظیم جدید BM Admin را رد کند. V7.43 cache namespace مستقل دارد و پاسخ تازه bankmovie.top همیشه authoritative است.
6) آرشیوی که Hidden/Disabled می‌شود دیگر نباید به عنوان selected archive مرده باقی بماند؛ Android به اولین آرشیو قابل استفاده منتقل می‌شود.
7) download wrapper در مسیر app_api به حالت fail-open تغییر کرده تا خرابی اختیاری gateway باعث حذف لینک Public نشود.

Single-domain موقت
-------------------
طبق درخواست این نسخه تمام Control/API endpointهای Android را موقتاً روی دامنه زیر ثابت می‌کند:
https://bankmovie.top

مسیرهای ثابت:
- /app_config.php
- /app_api.php
- /app_user_api.php
- /archive1_live.php
- /api6.php
- /api4.php

URL واقعی فایل‌های ویدئو/CDN و سرویس‌های خارجی مثل Telegram بازنویسی نمی‌شوند؛ فقط Control Plane بانک‌مووی تک‌دامنه شده است.

کنترل مستقل هر آرشیو
--------------------
برای Archive 1/2/3/4 مستقل:
- Archive state: Enabled / Disabled / Hidden
- Archive access: Public / Member / VIP / Admin
- Download access: Public / Member / VIP / Admin / Disabled
- Stream access: Public / Member / VIP / Admin / Disabled
- Watch Party
- Internal Player
- External Players
- All Players
- disabled_message
- Toggle + access_scope مستقل برای Sectionهای Home

فایل‌های اصلی تغییرکرده
-----------------------
- server-required/includes/app_archive_policy.php
- server-required/app_api.php
- server-required/api4.php
- server-required/api6.php
- server-required/archive1_live.php
- server-required/app_config.php
- server-required/bm_admin.php
- app/src/main/java/ir/bankmoviee/app/MainActivity.kt
- app/src/main/java/ir/bankmoviee/app/AccountApi.kt
- app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt

نصب هاست
---------
محتویات Host Patch را با حفظ مسیرها روی همان bankmovie.top جایگزین کن.
فایل live به نام bankmovie_remote_config.json داخل Patch قرار داده نشده تا تنظیمات فعلی BM Admin پاک نشوند.
بعد از Upload، یک بار داخل BM Admin «ذخیره همه تنظیمات» را بزن تا config_revision جدید ایجاد شود.
