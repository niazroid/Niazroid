<?php
/**
 * Android-only archive policy engine.
 *
 * V7.43 goals:
 * - one canonical policy source: bankmovie_remote_config.json on bankmovie.top
 * - no leakage from website archive policy into Android
 * - structured app responses for hidden/disabled/locked states
 * - public download/stream really stay public
 * - section visibility/access follows BM Admin exactly
 */
require_once __DIR__ . '/archive_control.php';

if (!function_exists('bm_app_policy_header_value')) {
    function bm_app_policy_header_value(string $name): string {
        $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
        return trim((string)($_SERVER[$key] ?? ''));
    }
}

if (!function_exists('bm_app_policy_is_app_client')) {
    function bm_app_policy_is_app_client(): bool {
        if (strtolower(trim((string)($_GET['client'] ?? ''))) === 'app') return true;
        if (bm_app_policy_header_value('X-BM-App-Key') !== '') return true;
        return stripos((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 'BankmovieAndroid') !== false;
    }
}

if (!function_exists('bm_app_policy_current_user')) {
    function bm_app_policy_current_user() {
        if (function_exists('bm_app_current_user')) return bm_app_current_user();
        static $resolved = false;
        static $viewer = null;
        if ($resolved) return $viewer;
        $resolved = true;

        $token = bm_app_policy_header_value('X-BM-User-Token');
        if ($token === '') {
            $authorization = bm_app_policy_header_value('Authorization');
            if (preg_match('/^Bearer\s+(.+)$/i', $authorization, $m)) $token = trim((string)$m[1]);
        }
        if ($token === '') return null;

        global $pdo;
        if (!($pdo instanceof PDO)) {
            $configPath = dirname(__DIR__) . '/config.php';
            if (is_file($configPath)) {
                try { require_once $configPath; } catch (Throwable $e) {}
            }
        }
        if (!class_exists('User') || !($pdo instanceof PDO)) return null;
        try {
            $candidate = (new User($pdo))->checkSession($token);
            if (is_array($candidate)) $viewer = $candidate;
        } catch (Throwable $e) {
            error_log('BankMovie app policy user lookup failed: ' . $e->getMessage());
        }
        return $viewer;
    }
}

if (!function_exists('bm_app_archive_policy_config')) {
    function bm_app_archive_policy_config(): array {
        static $cache = null;
        static $mtime = -1;
        $path = dirname(__DIR__) . '/bankmovie_remote_config.json';
        $nowMtime = is_file($path) ? (int)@filemtime($path) : 0;
        if (is_array($cache) && $mtime === $nowMtime) return $cache;
        $mtime = $nowMtime;
        $saved = [];
        if (is_file($path)) {
            $raw = @file_get_contents($path);
            $json = is_string($raw) ? json_decode($raw, true) : null;
            if (is_array($json)) $saved = $json;
        }
        $cache = $saved;
        return $saved;
    }
}

if (!function_exists('bm_app_policy_normalize_scope')) {
    function bm_app_policy_normalize_scope($scope, string $fallback = 'public'): string {
        $scope = strtolower(trim((string)$scope));
        return in_array($scope, ['public','member','vip','admin','disabled'], true) ? $scope : $fallback;
    }
}

if (!function_exists('bm_app_archive_policy_row')) {
    function bm_app_archive_policy_row(string $archiveId): array {
        $archiveId = strtolower(trim($archiveId));
        if (!preg_match('/^archive([1-4])$/', $archiveId, $m)) return [];
        $n = (int)$m[1];
        $cfg = bm_app_archive_policy_config();
        $features = is_array($cfg['features']['archives'] ?? null) ? $cfg['features']['archives'] : [];
        $policies = is_array($cfg['app_archive_policy'] ?? null) ? $cfg['app_archive_policy'] : [];
        $row = is_array($policies[$archiveId] ?? null) ? $policies[$archiveId] : [];
        $appFeatures = is_array($cfg['features'] ?? null) ? $cfg['features'] : [];

        $hidden = array_key_exists('hidden', $row)
            ? !empty($row['hidden'])
            : !empty($features["archive{$n}_hidden"]);
        $enabled = array_key_exists('enabled', $row)
            ? !empty($row['enabled'])
            : (!array_key_exists("archive{$n}_enabled", $features) || !empty($features["archive{$n}_enabled"]));
        if ($hidden) $enabled = false;

        $accessScope = bm_app_policy_normalize_scope($row['access_scope'] ?? 'public', 'public');
        if ($accessScope === 'disabled') $accessScope = 'public';
        $downloadScope = bm_app_policy_normalize_scope(
            $row['download_access_scope'] ?? (!empty($features["archive{$n}_download_vip"]) ? 'vip' : 'public'),
            'public'
        );
        $streamScope = bm_app_policy_normalize_scope(
            $row['stream_access_scope'] ?? (!empty($features["archive{$n}_stream_vip"]) ? 'vip' : 'public'),
            'public'
        );
        $watchPartyScope = bm_app_policy_normalize_scope($row['watch_party_access_scope'] ?? ($appFeatures['watch_party_scope'] ?? 'vip'), 'vip');
        $internalPlayerScope = bm_app_policy_normalize_scope($row['internal_player_access_scope'] ?? ($appFeatures['internal_player_scope'] ?? 'public'), 'public');
        $externalPlayerScope = bm_app_policy_normalize_scope($row['external_player_access_scope'] ?? ($appFeatures['external_player_scope'] ?? 'public'), 'public');
        $allPlayersScope = bm_app_policy_normalize_scope($row['all_players_access_scope'] ?? ($appFeatures['all_players_scope'] ?? 'public'), 'public');

        $state = $hidden ? 'hidden' : ($enabled ? 'enabled' : 'disabled');
        $message = trim((string)($row['disabled_message'] ?? ''));
        if ($message === '') $message = "این آرشیو در اپ موقتاً غیرفعال شده است.";

        return [
            'archive_id' => $archiveId,
            'state' => $state,
            'enabled' => $enabled,
            'hidden' => $hidden,
            'access_scope' => $accessScope,
            'download_access_scope' => $downloadScope,
            'stream_access_scope' => $streamScope,
            'watch_party_access_scope' => $watchPartyScope,
            'internal_player_access_scope' => $internalPlayerScope,
            'external_player_access_scope' => $externalPlayerScope,
            'all_players_access_scope' => $allPlayersScope,
            'disabled_message' => $message,
        ];
    }
}

if (!function_exists('bm_app_archive_is_enabled')) {
    function bm_app_archive_is_enabled(string $archiveId): bool {
        $row = bm_app_archive_policy_row($archiveId);
        return !empty($row['enabled']) && empty($row['hidden']);
    }
}

if (!function_exists('bm_app_archive_is_hidden')) {
    function bm_app_archive_is_hidden(string $archiveId): bool {
        return !empty(bm_app_archive_policy_row($archiveId)['hidden']);
    }
}

if (!function_exists('bm_app_archive_user_can_access')) {
    function bm_app_archive_user_can_access(string $archiveId, $user = null): bool {
        $row = bm_app_archive_policy_row($archiveId);
        if (empty($row['enabled']) || !empty($row['hidden'])) return false;
        $scope = (string)($row['access_scope'] ?? 'public');
        return function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
    }
}

if (!function_exists('bm_app_archive_feature_scope')) {
    function bm_app_archive_feature_scope(string $archiveId, string $feature): string {
        $row = bm_app_archive_policy_row($archiveId);
        $map = [
            'download' => 'download_access_scope',
            'stream' => 'stream_access_scope',
            'watch_party' => 'watch_party_access_scope',
            'internal_player' => 'internal_player_access_scope',
            'external_player' => 'external_player_access_scope',
            'all_players' => 'all_players_access_scope',
        ];
        $key = $map[$feature] ?? 'download_access_scope';
        return bm_app_policy_normalize_scope($row[$key] ?? 'public', 'public');
    }
}

if (!function_exists('bm_app_archive_feature_user_can_access')) {
    function bm_app_archive_feature_user_can_access(string $archiveId, string $feature, $user = null): bool {
        if (!bm_app_archive_user_can_access($archiveId, $user)) return false;
        $scope = bm_app_archive_feature_scope($archiveId, $feature);
        if ($scope === 'disabled') return false;
        return function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
    }
}

if (!function_exists('bm_app_scope_message')) {
    function bm_app_scope_message(string $scope, string $feature, string $archiveLabel = 'این آرشیو'): string {
        $scope = bm_app_policy_normalize_scope($scope, 'public');
        $subject = $feature === 'stream' ? 'پخش آنلاین' : ($feature === 'download' ? 'دانلود' : 'دسترسی');
        if ($scope === 'member') return "$subject $archiveLabel فقط برای کاربران واردشده فعال است.";
        if ($scope === 'vip') return "$subject $archiveLabel ویژه اعضای VIP است.";
        if ($scope === 'admin') return "$subject $archiveLabel فقط برای مدیر فعال است.";
        if ($scope === 'disabled') return "$subject $archiveLabel از پنل مدیریت غیرفعال شده است.";
        return "$subject $archiveLabel فعال است.";
    }
}

if (!function_exists('bm_app_archive_policy_snapshot')) {
    function bm_app_archive_policy_snapshot(string $archiveId): array {
        $row = bm_app_archive_policy_row($archiveId);
        return [
            'state' => (string)($row['state'] ?? 'enabled'),
            'enabled' => !empty($row['enabled']),
            'hidden' => !empty($row['hidden']),
            'access_scope' => (string)($row['access_scope'] ?? 'public'),
            'download_access_scope' => (string)($row['download_access_scope'] ?? 'public'),
            'stream_access_scope' => (string)($row['stream_access_scope'] ?? 'public'),
            'watch_party_access_scope' => (string)($row['watch_party_access_scope'] ?? 'vip'),
            'internal_player_access_scope' => (string)($row['internal_player_access_scope'] ?? 'public'),
            'external_player_access_scope' => (string)($row['external_player_access_scope'] ?? 'public'),
            'all_players_access_scope' => (string)($row['all_players_access_scope'] ?? 'public'),
            'disabled_message' => (string)($row['disabled_message'] ?? ''),
        ];
    }
}

if (!function_exists('bm_app_archive_state_payload')) {
    function bm_app_archive_state_payload(string $archiveId, $user = null): array {
        $row = bm_app_archive_policy_row($archiveId);
        $archiveNumber = preg_replace('/\D+/', '', $archiveId);
        $label = 'آرشیو ' . ($archiveNumber !== '' ? $archiveNumber : '');
        $base = [
            'archive' => (int)$archiveNumber,
            'archive_id' => $archiveId,
            'archive_policy' => bm_app_archive_policy_snapshot($archiveId),
            'movies' => [], 'items' => [], 'results' => [], 'downloads' => [],
            'has_more' => false,
        ];
        if (!empty($row['hidden'])) {
            return array_merge($base, [
                'status' => 'hidden',
                'archive_hidden' => true,
                'message' => (string)$row['disabled_message'],
            ]);
        }
        if (empty($row['enabled'])) {
            return array_merge($base, [
                'status' => 'disabled',
                'archive_disabled' => true,
                'message' => (string)$row['disabled_message'],
            ]);
        }
        $scope = (string)($row['access_scope'] ?? 'public');
        $allowed = function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
        if (!$allowed) {
            return array_merge($base, [
                'status' => 'locked',
                'archive_locked' => true,
                'access_scope' => $scope,
                'message' => bm_app_scope_message($scope, 'access', $label),
            ]);
        }
        return array_merge($base, ['status' => 'success', 'message' => "$label آماده است."]);
    }
}

if (!function_exists('bm_app_archive_section_policy')) {
    function bm_app_archive_section_policy(string $archiveId, string $section): array {
        if (!preg_match('/^archive([1-4])$/', $archiveId, $m)) return ['enabled'=>true,'access_scope'=>'public'];
        $n = (int)$m[1];
        $section = strtolower(trim($section));
        $section = str_replace('-', '_', $section);
        if ($section === '') return ['enabled'=>true,'access_scope'=>'public'];
        $cfg = bm_app_archive_policy_config();
        $row = is_array($cfg['home_section_policy'][$archiveId] ?? null) ? $cfg['home_section_policy'][$archiveId] : [];
        $raw = $row[$section] ?? null;
        if (is_array($raw)) {
            $enabled = array_key_exists('enabled', $raw) ? !empty($raw['enabled']) : true;
            $scope = bm_app_policy_normalize_scope($raw['access_scope'] ?? 'public', 'public');
            return ['enabled'=>$enabled,'access_scope'=>$scope];
        }
        if (is_bool($raw)) return ['enabled'=>$raw,'access_scope'=>'public'];
        if (is_string($raw) && trim($raw) !== '') return ['enabled'=>true,'access_scope'=>bm_app_policy_normalize_scope($raw,'public')];

        $homeKey = "archive{$n}_sections";
        if (array_key_exists($homeKey, (array)($cfg['home'] ?? []))) {
            $enabledList = array_map(static fn($v): string => strtolower(str_replace('-', '_', trim((string)$v))), (array)$cfg['home'][$homeKey]);
            return ['enabled'=>in_array($section, $enabledList, true), 'access_scope'=>'public'];
        }
        return ['enabled'=>true,'access_scope'=>'public'];
    }
}

if (!function_exists('bm_app_archive_section_user_can_access')) {
    function bm_app_archive_section_user_can_access(string $archiveId, string $section, $user = null): bool {
        $row = bm_app_archive_section_policy($archiveId, $section);
        if (empty($row['enabled'])) return false;
        $scope = (string)($row['access_scope'] ?? 'public');
        if ($scope === 'disabled') return false;
        return function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public';
    }
}

if (!function_exists('bm_app_archive_section_state_payload')) {
    function bm_app_archive_section_state_payload(string $archiveId, string $section, $user = null): array {
        $archiveNumber = (int)preg_replace('/\D+/', '', $archiveId);
        $row = bm_app_archive_section_policy($archiveId, $section);
        $scope = (string)($row['access_scope'] ?? 'public');
        $enabled = !empty($row['enabled']);
        $allowed = $enabled && $scope !== 'disabled' && (function_exists('bm_archive_scope_allows') ? bm_archive_scope_allows($scope, $user) : $scope === 'public');
        if (!$enabled || $scope === 'disabled') {
            $status = 'disabled';
            $message = 'این بخش از آرشیو توسط مدیریت غیرفعال شده است.';
        } elseif (!$allowed) {
            $status = 'locked';
            $message = bm_app_scope_message($scope, 'access', 'این بخش');
        } else {
            $status = 'success';
            $message = '';
        }
        return [
            'status'=>$status,
            'archive'=>$archiveNumber,
            'section'=>$section,
            'section_disabled'=>!$enabled || $scope === 'disabled',
            'section_locked'=>$enabled && !$allowed,
            'section_access_scope'=>$scope,
            'message'=>$message,
            'items'=>[], 'movies'=>[], 'results'=>[], 'has_more'=>false, 'next_page'=>0,
            'archive_policy'=>bm_app_archive_policy_snapshot($archiveId),
        ];
    }
}

if (!function_exists('bm_app_archive_apply_payload_policy')) {
    function bm_app_archive_apply_payload_policy(string $archiveId, $payload, $user = null, array $context = []) {
        if (!is_array($payload)) return $payload;
        $isList = array_is_list($payload);
        $row = bm_app_archive_policy_row($archiveId);
        $downloadScope = (string)($row['download_access_scope'] ?? 'public');
        $streamScope = (string)($row['stream_access_scope'] ?? 'public');
        $archiveAllowed = bm_app_archive_user_can_access($archiveId, $user);
        $downloadAllowed = $archiveAllowed && bm_app_archive_feature_user_can_access($archiveId, 'download', $user);
        $streamAllowed = $archiveAllowed && bm_app_archive_feature_user_can_access($archiveId, 'stream', $user);

        // IMPORTANT: Android policy is intentionally independent from website
        // blocked-items rules. Public in BM Admin must mean public in the app.
        //
        // Many archive adapters expose ONE shared media URL for both download and
        // playback. Stripping that shared URL for only one denied capability used
        // to destroy the other, allowed capability (for example: download=public,
        // stream=vip => "no download links"). Keep shared media rows whenever at
        // least one capability is allowed and let the explicit *_locked/gate fields
        // below drive the Android UI. Only remove media URLs when BOTH capabilities
        // are denied for the current viewer.
        if (!$downloadAllowed && !$streamAllowed) {
            if (function_exists('bm_archive_strip_download_payload')) $payload = bm_archive_strip_download_payload($payload);
            if (function_exists('bm_archive_strip_stream_payload')) $payload = bm_archive_strip_stream_payload($payload);
        }

        if (!$isList) {
            $policy = bm_app_archive_policy_snapshot($archiveId);
            $payload['archive_policy'] = $policy;
            $payload['archive_state'] = (string)($policy['state'] ?? 'enabled');
            $payload['archive_hidden'] = !empty($policy['hidden']);
            $payload['archive_enabled'] = !empty($policy['enabled']);
            foreach (['item','movie','detail'] as $key) {
                if (isset($payload[$key]) && is_array($payload[$key]) && !array_is_list($payload[$key])) {
                    $payload[$key]['archive_policy'] = $policy;
                    $payload[$key]['archive_state'] = $payload['archive_state'];
                    $payload[$key]['download_access_scope'] = $downloadScope;
                    $payload[$key]['stream_access_scope'] = $streamScope;
                }
            }
        }

        if (!$isList && !$downloadAllowed) {
            $msg = bm_app_scope_message($downloadScope, 'download', 'این آرشیو');
            $payload['downloads_locked'] = true;
            $payload['download_message'] = $msg;
            $payload['download_gate'] = $downloadScope;
            foreach (['item','movie','detail'] as $key) if (isset($payload[$key]) && is_array($payload[$key])) {
                $payload[$key]['downloads_locked'] = true;
                $payload[$key]['download_message'] = $msg;
                $payload[$key]['download_gate'] = $downloadScope;
            }
        }
        if (!$isList && !$streamAllowed) {
            $msg = bm_app_scope_message($streamScope, 'stream', 'این آرشیو');
            $payload['stream_locked'] = true;
            $payload['stream_message'] = $msg;
            $payload['stream_gate'] = $streamScope;
            foreach (['item','movie','detail'] as $key) if (isset($payload[$key]) && is_array($payload[$key])) {
                $payload[$key]['stream_locked'] = true;
                $payload[$key]['stream_message'] = $msg;
                $payload[$key]['stream_gate'] = $streamScope;
            }
        }
        return $payload;
    }
}

if (!function_exists('bm_app_archive_sections')) {
    function bm_app_archive_sections(string $archiveId, array $fallback = []): array {
        if (!preg_match('/^archive([1-4])$/', $archiveId, $m)) return $fallback;
        $cfg = bm_app_archive_policy_config();
        $key = 'archive' . (int)$m[1] . '_sections';
        if (!array_key_exists($key, (array)($cfg['home'] ?? []))) return $fallback;
        $rows = is_array($cfg['home'][$key] ?? null) ? $cfg['home'][$key] : [];
        $out=[];
        foreach ($rows as $row) { $v=trim((string)$row); if ($v!=='' && !in_array($v,$out,true)) $out[]=$v; }
        return $out;
    }
}
