#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$MAIN" && -f "$WF" ]] || { echo VERIFY_V7471_10_FILES_MISSING; exit 1; }

grep -Fq 'V7.47.1.10 TV DRAWER LEFT-CLOSE' "$MAIN"
grep -Fq 'if (tvSideNavExpanded && keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT)' "$MAIN"
grep -Fq 'setTvSideNavExpanded(false)' "$MAIN"
grep -Fq 'requestTvContentEntryFocus()' "$MAIN"

python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
needle='private fun showProfile() {\n        showProfileMobileV736()\n    }'
assert needle in s, 'profile dispatcher is not unified'
start=s.index('private fun showProfileMobileV736()')
end=s.index('private fun showProfile()', start)
block=s[start:end]
assert 'val backdropUrl = AccountSession.authBackground(this@MainActivity)' in block
assert 'createBlurEffect(18f, 18f' not in block
assert 'bm_tv_profile_header_card' in block
assert 'bm_tv_profile_primary' in block
assert 'bm_v70_profile_actions_grid' in block
assert 'bm_v70_profile_utility_grid' in block
assert 'activateV71ProfileBootstrap(page)' in block
assert 'val gap = dp(if (isTvLike()) 9 else 4)' in block
print('V7471_10_PROFILE_BLOCK_OK')
PY

bash verify_v7471_8_tv_drawer_click_bridge.sh
bash verify_v7471_9_boxoffice_profile_unified_ui.sh
grep -Fq 'Bankmovie-v2.3-V7.47.1.10-TV-DRAWER-PROFILE-MOBILE-MATCH-FULLSOURCE.zip' "$WF"
grep -Fq 'verify_v7471_10_tv_drawer_profile_mobile_match.sh' "$WF"
echo VERIFY_V7471_10_TV_DRAWER_PROFILE_MOBILE_MATCH_OK
