#!/usr/bin/env python3
"""Static guard for BankMovie Media3 player repair. Device verification still required."""
from pathlib import Path
import re
root=Path(__file__).parent
activity=(root/'app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
bridge=(root/'app/src/main/java/ir/bankmoviee/app/Media3PlaybackBridge.kt').read_text()
gradle=(root/'app/build.gradle').read_text()
workflow=(root/'.github/workflows/build-bankmovie.yml').read_text()
assert not re.search(r'\bjavaClass\.getMethod\(',activity), 'R8-unsafe reflection in PlayerActivity'
for code in ['mp.getAudioTracks()', 'mp.getSpuTracks()', 'mp.setAudioTrack(id)',
             'mp.setSpuTrack(id)', 'mp.getAudioTrack()', 'mp.getSpuTrack()','mp.setDisplayMode(modes[modeIndex])']:
    assert code in activity or code.replace('mp.setDisplayMode','player?.setDisplayMode') in activity, code
assert 'onUserSeek()' in activity
assert 'resumeTarget = 0L' in activity and 'resumeGuardUntil = 0L' in activity
assert 'if (player !== mp || resumeTarget == 0L || resumeGuardUntil == 0L) return' in activity
assert 'refreshOpenTrackSheet?.invoke()' in activity
assert 'refreshOpenTrackSheet = { if (dialog.isShowing) drawTrackRows() }' in activity
assert 'ThemeWindowLoadingView(this@PlayerActivity)' in activity
assert 'Media3Player.Event.Buffering ->' in activity
assert 'Media3Player.Event.TracksChanged ->' in activity
assert 'fun setDisplayMode(mode: String)' in bridge
for code in ['RESIZE_MODE_ZOOM', 'RESIZE_MODE_FILL', 'RESIZE_MODE_FIT','override fun onTracksChanged(tracks: Tracks)']:
    assert code in bridge
assert 'org.videolan.android:libvlc' not in gradle
assert "compileSdk 36" in gradle and 'targetSdk 35' in gradle
assert 'assembleAbi2LiteRelease' in workflow and 'assembleAbi4FullRelease' in workflow
assert 'Expected exactly 8' in workflow or 'len(found) != 8' in workflow or '8 APK' in workflow
assert workflow.count('uses: actions/upload-artifact@v4') >= 9
print('MEDIA3_PLAYBACK_FIX_STATIC_CHECKS_OK (not an APK or device test)')
