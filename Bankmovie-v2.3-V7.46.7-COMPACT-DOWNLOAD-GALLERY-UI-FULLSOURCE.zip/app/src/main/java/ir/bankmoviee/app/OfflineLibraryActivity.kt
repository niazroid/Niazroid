package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.StatFs
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * V7.46.7 compact visual correction for the local/offline gallery.
 *
 * The screen stays 100% offline-first: every card comes from InternalDownloadStore,
 * local poster cache and local files.  The visual language now matches the new
 * downloader mockup while keeping the active BankMovie accent palette.
 */
class OfflineLibraryActivity : Activity() {
    private companion object {
        const val FILTER_ALL = "all"
        const val FILTER_MOVIES = "movies"
        const val FILTER_SERIES = "series"
    }

    private lateinit var root: FrameLayout
    private lateinit var list: LinearLayout
    private lateinit var allTab: TextView
    private lateinit var moviesTab: TextView
    private lateinit var seriesTab: TextView
    private lateinit var readyText: TextView
    private lateinit var usageText: TextView
    private lateinit var usageProgress: ProgressBar
    private var filter = FILTER_ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = UiPreferences.palette(this)
        window.statusBarColor = p.background
        window.navigationBarColor = p.background
        buildUi()
        refreshLibrary()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refreshLibrary()
    }

    private fun buildUi() {
        val p = UiPreferences.palette(this)
        root = FrameLayout(this).apply { setBackgroundColor(p.background) }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(if (isTvLike()) 28 else 16), dp(10), dp(if (isTvLike()) 28 else 16), dp(30))
        }
        scroll.addView(page)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        page.addView(buildHeader(), LinearLayout.LayoutParams(-1, dp(if (isTvLike()) 78 else 64)))

        page.addView(TextView(this).apply {
            text = "فیلم‌ها و قسمت‌هایی که با دانلودر داخلی بانک مووی ذخیره شده‌اند؛ بدون اینترنت، هر زمان و هر جا تماشا کنید."
            setTextColor(p.muted)
            textSize = if (isTvLike()) 12.8f else 11.6f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.09f)
            setPadding(dp(3), 0, dp(3), dp(12))
        })

        page.addView(buildStorageCard(), LinearLayout.LayoutParams(-1, dp(if (isTvLike()) 92 else 84)).apply {
            bottomMargin = dp(14)
        })

        val tabsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            isFillViewport = true
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        allTab = filterTab("همه", FILTER_ALL, R.drawable.ic_nav_grid)
        moviesTab = filterTab("فیلم‌ها", FILTER_MOVIES, R.drawable.ic_bm_film)
        seriesTab = filterTab("سریال‌ها", FILTER_SERIES, R.drawable.ic_bm_series)
        val tabHeight = dp(if (isTvLike()) 46 else 42)
        tabs.addView(allTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(5) })
        tabs.addView(moviesTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginStart = dp(5); marginEnd = dp(5) })
        tabs.addView(seriesTab, LinearLayout.LayoutParams(0, tabHeight, 1f).apply { marginEnd = dp(5) })
        tabsScroll.addView(tabs, ViewGroup.LayoutParams(-1, tabHeight))
        page.addView(tabsScroll, LinearLayout.LayoutParams(-1, tabHeight).apply { bottomMargin = dp(14) })

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        page.addView(list, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
    }

    private fun buildHeader(): View {
        val p = UiPreferences.palette(this)
        return FrameLayout(this).apply {
            clipChildren = false
            clipToPadding = false

            addView(iconButton(R.drawable.ic_bm_back, "بازگشت") { finish() }, FrameLayout.LayoutParams(dp(if (isTvLike()) 48 else 44), dp(if (isTvLike()) 48 else 44), Gravity.LEFT or Gravity.CENTER_VERTICAL))

            val titleBox = LinearLayout(this@OfflineLibraryActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                addView(ImageView(this@OfflineLibraryActivity).apply {
                    setImageResource(R.drawable.ic_offline_gallery)
                    setColorFilter(p.primary2)
                    setPadding(dp(5), dp(5), dp(5), dp(5))
                    contentDescription = "گالری آفلاین"
                }, LinearLayout.LayoutParams(dp(if (isTvLike()) 34 else 30), dp(if (isTvLike()) 34 else 30)).apply { marginStart = dp(7) })
                addView(TextView(this@OfflineLibraryActivity).apply {
                    text = "گالری آفلاین"
                    setTextColor(p.text)
                    textSize = if (isTvLike()) 25f else 21.5f
                    typeface = BankmovieFonts.black(this@OfflineLibraryActivity)
                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                })
            }
            addView(titleBox, FrameLayout.LayoutParams(-2, -1, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply {
                leftMargin = dp(56)
            })
        }
    }

    private fun buildStorageCard(): View {
        val p = UiPreferences.palette(this)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            background = glass(19, elevated = true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            isClickable = true
            isFocusable = true
            setOnClickListener { startActivity(Intent(this@OfflineLibraryActivity, DownloadsActivity::class.java)) }
            focusScale(this)

            val readyBox = LinearLayout(this@OfflineLibraryActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                readyText = TextView(this@OfflineLibraryActivity).apply {
                    setTextColor(p.text)
                    textSize = 11.6f
                    typeface = BankmovieFonts.medium(this@OfflineLibraryActivity)
                    gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
                }
                addView(readyText, LinearLayout.LayoutParams(0, -2, 1f))
                addView(TextView(this@OfflineLibraryActivity).apply {
                    text = "›"
                    setTextColor(p.primary2)
                    textSize = 23f
                    gravity = Gravity.CENTER
                }, LinearLayout.LayoutParams(dp(22), dp(36)))
            }
            addView(readyBox, LinearLayout.LayoutParams(0, -1, 0.42f).apply { marginEnd = dp(6) })

            addView(View(this@OfflineLibraryActivity).apply {
                setBackgroundColor(Color.argb(50, 255, 255, 255))
            }, LinearLayout.LayoutParams(dp(1), -1).apply { marginStart = dp(8); marginEnd = dp(8) })

            val usageBox = LinearLayout(this@OfflineLibraryActivity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                val labelRow = LinearLayout(this@OfflineLibraryActivity).apply {
                    orientation = LinearLayout.HORIZONTAL
                    layoutDirection = View.LAYOUT_DIRECTION_RTL
                    gravity = Gravity.CENTER_VERTICAL
                    addView(TextView(this@OfflineLibraryActivity).apply {
                        text = "فضای مصرفی"
                        setTextColor(p.text)
                        textSize = 11.2f
                        typeface = BankmovieFonts.medium(this@OfflineLibraryActivity)
                        gravity = Gravity.RIGHT
                    }, LinearLayout.LayoutParams(0, -2, 1f))
                    usageText = TextView(this@OfflineLibraryActivity).apply {
                        setTextColor(p.muted)
                        textSize = 10.4f
                        gravity = Gravity.LEFT
                    }
                    addView(usageText)
                }
                addView(labelRow, LinearLayout.LayoutParams(-1, -2))
                usageProgress = ProgressBar(this@OfflineLibraryActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
                    max = 1000
                    progressTintList = ColorStateList.valueOf(p.primary)
                    progressBackgroundTintList = ColorStateList.valueOf(UiPreferences.blend(p.panel2, Color.WHITE, 0.06f))
                }
                addView(usageProgress, LinearLayout.LayoutParams(-1, dp(5)).apply { topMargin = dp(7) })
            }
            addView(usageBox, LinearLayout.LayoutParams(0, -1, 0.58f))

            addView(ImageView(this@OfflineLibraryActivity).apply {
                setImageResource(R.drawable.ic_bm_storage)
                setColorFilter(p.primary2)
                setPadding(dp(7), dp(7), dp(7), dp(7))
            }, 0, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(7) })
        }
    }

    private fun completedItems(): List<JSONObject> = InternalDownloadStore.all(this)
        .filter { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED && InternalDownloadStore.exists(this, it) }

    private fun refreshLibrary() {
        if (!::list.isInitialized) return
        val all = completedItems()
        val movies = all.filterNot(::isSeriesItem)
        val series = all.filter(::isSeriesItem)
        val used = all.sumOf(::fileSize)
        val totalSpace = runCatching { StatFs(filesDir.absolutePath).totalBytes }.getOrDefault(0L).coerceAtLeast(used)
        val progress = if (totalSpace > 0L) ((used.toDouble() / totalSpace.toDouble()) * 1000.0).toInt().coerceIn(0, 1000) else 0
        readyText.text = "${all.size} فایل آماده پخش"
        usageText.text = if (totalSpace > 0L) "${humanBytes(used)} از ${humanBytes(totalSpace)}" else humanBytes(used)
        usageProgress.progress = progress

        allTab.text = "همه  ${all.size}"
        moviesTab.text = "فیلم‌ها  ${movies.size}"
        seriesTab.text = "سریال‌ها  ${series.size}"
        bindTab(allTab, filter == FILTER_ALL)
        bindTab(moviesTab, filter == FILTER_MOVIES)
        bindTab(seriesTab, filter == FILTER_SERIES)
        list.removeAllViews()

        val visible = when (filter) {
            FILTER_MOVIES -> movies
            FILTER_SERIES -> series
            else -> all
        }
        if (visible.isEmpty()) {
            renderEmpty()
            return
        }

        if (filter != FILTER_SERIES && movies.any { it in visible }) {
            sectionTitle("فیلم‌ها", movies.count { it in visible })
            movies.filter { it in visible }
                .sortedByDescending { it.optLong("updated_at", it.optLong("created_at")) }
                .forEach { list.addView(mediaCard(it), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) }) }
        }

        val visibleSeries = series.filter { it in visible }
        if (visibleSeries.isNotEmpty()) {
            val grouped = visibleSeries.groupBy { seriesGroupKey(it) }.toSortedMap(String.CASE_INSENSITIVE_ORDER)
            grouped.forEach { (_, items) ->
                val title = items.firstOrNull()?.optString("title").orEmpty().ifBlank { "سریال" }
                sectionTitle(title, items.size)
                items.sortedWith(compareBy<JSONObject> { it.optInt("season", 0).let { s -> if (s > 0) s else 9999 } }
                    .thenBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 9999 } }
                    .thenBy { qualityRank(it.optString("quality")) })
                    .forEach { list.addView(mediaCard(it), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(13) }) }
            }
        }
    }

    private fun renderEmpty() {
        val p = UiPreferences.palette(this)
        list.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glass(20, elevated = true)
            setPadding(dp(18), dp(28), dp(18), dp(28))
            addView(ImageView(this@OfflineLibraryActivity).apply {
                setImageResource(R.drawable.ic_bm_empty_download)
                setColorFilter(p.primary2)
            }, LinearLayout.LayoutParams(dp(58), dp(58)).apply { bottomMargin = dp(12) })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "هنوز فایلی در گالری آفلاین نیست"
                setTextColor(p.text)
                textSize = 15.5f
                typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "فایل‌هایی که با دانلودر داخلی بانک مووی کامل شوند، اینجا برای پخش بدون اینترنت نمایش داده می‌شوند."
                setTextColor(p.muted)
                textSize = 11.2f
                gravity = Gravity.CENTER
                setLineSpacing(dp(2).toFloat(), 1.08f)
                setPadding(dp(8), dp(7), dp(8), dp(14))
            })
            addView(wideActionButton("مشاهده دانلودها", R.drawable.ic_download, false) {
                startActivity(Intent(this@OfflineLibraryActivity, DownloadsActivity::class.java))
            }, LinearLayout.LayoutParams(dp(190), dp(44)))
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun sectionTitle(title: String, count: Int) {
        val p = UiPreferences.palette(this)
        list.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(6), dp(2), dp(8))
            addView(View(this@OfflineLibraryActivity).apply {
                background = rounded(p.primary, dp(999), Color.TRANSPARENT)
            }, LinearLayout.LayoutParams(dp(3), dp(26)).apply { marginStart = dp(8) })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = title
                setTextColor(p.text)
                textSize = 16.5f
                typeface = BankmovieFonts.black(this@OfflineLibraryActivity)
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "$count فایل"
                setTextColor(p.muted)
                textSize = 10.2f
                gravity = Gravity.CENTER
                background = glass(999, false)
                setPadding(dp(9), dp(5), dp(9), dp(5))
            })
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun mediaCard(item: JSONObject): View {
        val p = UiPreferences.palette(this)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = glass(19, elevated = true)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            clipChildren = false
            clipToPadding = false
        }

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.TOP
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = glass(15, false)
            val local = item.optString("poster_local_path")
            val bitmap = local.takeIf { it.isNotBlank() }?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
            if (bitmap != null) setImageBitmap(bitmap) else {
                setImageResource(R.drawable.bankmovie_logo_transparent)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(12), dp(12), dp(12), dp(12))
            }
        }
        top.addView(poster, LinearLayout.LayoutParams(dp(if (isTvLike()) 90 else 82), dp(if (isTvLike()) 126 else 116)).apply { marginEnd = dp(10) })

        val info = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.RIGHT
        }
        info.addView(TextView(this).apply {
            text = item.optString("title").ifBlank { "BankMovie" }
            setTextColor(p.text)
            textSize = 15.2f
            typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })

        val tags = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val tagRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
        }
        val season = item.optInt("season", 0)
        val episode = item.optInt("episode", 0)
        if (season > 0 || episode > 0) {
            val label = buildString {
                if (season > 0) append("فصل $season")
                if (season > 0 && episode > 0) append(" • ")
                if (episode > 0) append("قسمت $episode")
            }
            tagRow.addView(metaPill(label, R.drawable.ic_bm_series, p.primary2), pillParams())
        } else {
            tagRow.addView(metaPill("فیلم", R.drawable.ic_bm_film, p.primary2), pillParams())
        }
        item.optString("quality").trim().takeIf { it.isNotBlank() }?.let {
            tagRow.addView(metaPill(it.uppercase(Locale.US), R.drawable.ic_bm_film, p.primary2), pillParams())
        }
        item.optString("kind").trim().takeIf { it.isNotBlank() }?.let {
            tagRow.addView(metaPill(it, R.drawable.ic_bm_headphones, Color.rgb(34, 205, 166)), pillParams())
        }
        tags.addView(tagRow)
        info.addView(tags, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(6) })

        val fileRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            addView(ImageView(this@OfflineLibraryActivity).apply {
                setImageResource(R.drawable.ic_bm_file)
                setColorFilter(p.primary2)
            }, LinearLayout.LayoutParams(dp(19), dp(19)).apply { marginStart = dp(6) })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "${humanBytes(fileSize(item))}   |   ${item.optString("file_name").ifBlank { "فایل دانلودی" }}"
                setTextColor(p.muted)
                textSize = 9.8f
                gravity = Gravity.RIGHT
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.MIDDLE
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        info.addView(fileRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))

        top.addView(iconButton(R.drawable.ic_bm_more, "گزینه‌های بیشتر") { showItemMenu(item) }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(6) })
        card.addView(top)

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            weightSum = 4f
            clipChildren = false
            clipToPadding = false
        }
        // Keep all four actions visible like the approved reference; no clipped horizontal row.
        actions.addView(wideActionButton("حذف", R.drawable.ic_bm_trash, true) { confirmDelete(item) }, actionParams(first = true))
        actions.addView(wideActionButton("اشتراک‌گذاری", R.drawable.ic_bm_share, false) { shareOffline(item) }, actionParams())
        actions.addView(wideActionButton("ارسال به دستگاه", R.drawable.ic_bm_send_to_device, false) { sendToDevice(item) }, actionParams())
        actions.addView(wideActionButton("پخش آفلاین", R.drawable.ic_bm_play_offline, false) { playOffline(item) }, actionParams(last = true))
        card.addView(actions, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
        return card
    }

    private fun filterTab(label: String, key: String, iconRes: Int): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 11.2f
        typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
        maxLines = 1
        includeFontPadding = false
        setPadding(dp(9), 0, dp(9), 0)
        compoundDrawablePadding = dp(5)
        setCompoundDrawablesRelativeWithIntrinsicBounds(tintedDrawable(iconRes, UiPreferences.palette(this@OfflineLibraryActivity).muted, dp(16)), null, null, null)
        isClickable = true
        isFocusable = true
        setOnClickListener { filter = key; refreshLibrary() }
        focusScale(this)
    }

    private fun bindTab(view: TextView, selected: Boolean) {
        val p = UiPreferences.palette(this)
        val color = if (selected) p.onPrimary else p.text
        view.setTextColor(color)
        view.compoundDrawablesRelative.firstOrNull()?.setTint(color)
        view.background = if (selected) glassTint(p.primary, 999) else glass(999, true)
    }

    private fun metaPill(label: String, iconRes: Int, accent: Int): TextView = TextView(this).apply {
        text = label
        setTextColor(accent)
        textSize = 9.8f
        typeface = BankmovieFonts.medium(this@OfflineLibraryActivity)
        gravity = Gravity.CENTER
        includeFontPadding = false
        compoundDrawablePadding = dp(5)
        setCompoundDrawablesRelativeWithIntrinsicBounds(tintedDrawable(iconRes, accent, dp(14)), null, null, null)
        setPadding(dp(8), 0, dp(8), 0)
        background = rounded(Color.argb(24, Color.red(accent), Color.green(accent), Color.blue(accent)), dp(999), Color.argb(90, Color.red(accent), Color.green(accent), Color.blue(accent)))
    }

    private fun pillParams() = LinearLayout.LayoutParams(-2, dp(29)).apply { marginStart = dp(5) }
    private fun actionParams(first: Boolean = false, last: Boolean = false) = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        if (!first) marginEnd = dp(3)
        if (!last) marginStart = dp(3)
    }

    private fun wideActionButton(label: String, iconRes: Int, danger: Boolean, click: () -> Unit): LinearLayout {
        val p = UiPreferences.palette(this)
        val accent = if (danger) Color.rgb(255, 78, 105) else p.primary2
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
            background = if (danger) rounded(Color.argb(55, 205, 22, 58), dp(15), Color.argb(150, 255, 45, 85)) else glassTint(p.primary, 15)
            isClickable = true
            isFocusable = true
            addView(ImageView(this@OfflineLibraryActivity).apply {
                setImageResource(iconRes)
                setColorFilter(if (danger) Color.rgb(255, 102, 126) else p.primary2)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginStart = dp(5) })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = label
                setTextColor(if (danger) Color.rgb(255, 128, 145) else p.text)
                textSize = 9.4f
                typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
                gravity = Gravity.CENTER
                maxLines = 1
            })
            setOnClickListener { click() }
            focusScale(this)
        }
    }

    private fun iconButton(iconRes: Int, description: String, click: () -> Unit): ImageView = ImageView(this).apply {
        val p = UiPreferences.palette(this@OfflineLibraryActivity)
        setImageResource(iconRes)
        setColorFilter(p.text)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = glass(14, true)
        contentDescription = description
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
        focusScale(this)
    }

    private fun showItemMenu(item: JSONObject) {
        val labels = arrayOf("پخش آفلاین", "ارسال به دستگاه", "اشتراک‌گذاری", "حذف")
        AlertDialog.Builder(this)
            .setTitle(item.optString("title").ifBlank { "BankMovie" })
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> playOffline(item)
                    1 -> sendToDevice(item)
                    2 -> shareOffline(item)
                    3 -> confirmDelete(item)
                }
            }
            .show()
    }

    private fun mediaMeta(item: JSONObject): String {
        val tokens = mutableListOf<String>()
        val season = item.optInt("season", 0)
        val episode = item.optInt("episode", 0)
        if (season > 0) tokens += "فصل $season"
        if (episode > 0) tokens += "قسمت $episode"
        item.optString("quality").takeIf { it.isNotBlank() }?.let { tokens += it }
        item.optString("kind").takeIf { it.isNotBlank() }?.let { tokens += it }
        val archive = item.optInt("archive", 0)
        if (archive in 1..4) tokens += "آرشیو $archive"
        return tokens.joinToString(" • ").ifBlank { if (isSeriesItem(item)) "قسمت سریال" else "فیلم" }
    }

    private fun isSeriesItem(item: JSONObject): Boolean {
        val type = item.optString("media_type").lowercase(Locale.US)
        if (type.contains("series") || type.contains("serial") || type.contains("episode") || type.contains("tv")) return true
        if (item.optInt("season", 0) > 0 || item.optInt("episode", 0) > 0) return true
        val sample = item.optString("file_name") + " " + item.optString("title")
        return Regex("(?i)(?:S\\d{1,2}E\\d{1,3}|\\bE\\d{1,3}\\b|فصل\\s*\\d+|قسمت\\s*\\d+)").containsMatchIn(sample)
    }

    private fun seriesGroupKey(item: JSONObject): String {
        val content = item.optString("content_id").trim()
        if (content.isNotBlank()) return "${item.optInt("archive", 0)}:$content"
        return item.optString("title").trim().lowercase(Locale.US).ifBlank { item.optString("file_name").substringBefore("S", "series") }
    }

    private fun qualityRank(raw: String): Int = when {
        raw.contains("2160", true) || raw.contains("4k", true) -> 0
        raw.contains("1080", true) -> 1
        raw.contains("720", true) -> 2
        raw.contains("480", true) -> 3
        else -> 9
    }

    private fun downloadedUri(item: JSONObject): Pair<Uri, String>? {
        val mime = InternalDownloadStore.mimeForName(item.optString("file_name"))
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank() || !InternalDownloadStore.exists(this, item)) null else Uri.parse(raw) to mime
        } else {
            val file = File(item.optString("path"))
            if (!file.exists()) null else FileProvider.getUriForFile(this, "$packageName.files", file) to mime
        }
    }

    private fun offlinePlaybackSource(item: JSONObject): String? {
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            raw.takeIf { it.isNotBlank() && InternalDownloadStore.exists(this, item) }
        } else {
            val file = File(item.optString("path"))
            file.takeIf { it.isFile && it.length() > 0L }?.absolutePath
        }
    }

    private fun playOffline(item: JSONObject) {
        val source = offlinePlaybackSource(item)
        val shareTarget = downloadedUri(item)
        if (source.isNullOrBlank() || shareTarget == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            refreshLibrary()
            return
        }
        runCatching {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra(PlayerActivity.EXTRA_VIDEO_URL, source)
                putExtra(PlayerActivity.EXTRA_TITLE, item.optString("title").ifBlank { "BankMovie" })
                putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, "offline:${item.optString("id")}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }.onFailure {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareTarget.first, shareTarget.second)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(this, "امکان پخش فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun sendToDevice(item: JSONObject) {
        val target = downloadedUri(item) ?: run {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show(); return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                putExtra(Intent.EXTRA_TITLE, item.optString("title"))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "ارسال به دستگاه"))
        }.onFailure { Toast.makeText(this, "برنامه‌ای برای ارسال فایل پیدا نشد", Toast.LENGTH_SHORT).show() }
    }

    private fun shareOffline(item: JSONObject) {
        val target = downloadedUri(item) ?: run {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show(); return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "اشتراک‌گذاری فایل"))
        }.onFailure { Toast.makeText(this, "امکان اشتراک‌گذاری فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
    }

    private fun confirmDelete(item: JSONObject) {
        AlertDialog.Builder(this)
            .setTitle("حذف از گالری آفلاین")
            .setMessage("فایل دانلودشده از حافظه دستگاه هم حذف شود؟")
            .setNegativeButton("انصراف", null)
            .setNeutralButton("فقط حذف رکورد") { _, _ ->
                InternalDownloadStore.remove(this, item.optString("id"), false)
                refreshLibrary()
            }
            .setPositiveButton("حذف فایل") { _, _ ->
                InternalDownloadStore.remove(this, item.optString("id"), true)
                refreshLibrary()
            }
            .show()
    }

    private fun cleanupMissing() {
        val missing = InternalDownloadStore.all(this).filter {
            it.optString("status") == InternalDownloadStore.STATUS_COMPLETED && !InternalDownloadStore.exists(this, it)
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "مورد گم‌شده‌ای پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        missing.forEach { InternalDownloadStore.remove(this, it.optString("id"), false) }
        Toast.makeText(this, "${missing.size} رکورد گم‌شده پاک شد", Toast.LENGTH_SHORT).show()
        refreshLibrary()
    }

    private fun fileSize(item: JSONObject): Long {
        val total = item.optLong("total", 0L)
        if (total > 0L) return total
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank()) 0L else runCatching { DocumentFile.fromSingleUri(this, Uri.parse(raw))?.length() ?: 0L }.getOrDefault(0L)
        } else {
            File(item.optString("path")).takeIf { it.exists() }?.length() ?: 0L
        }
    }

    private fun tintedDrawable(resId: Int, color: Int, sizeDp: Int): Drawable? = ContextCompat.getDrawable(this, resId)?.mutate()?.apply {
        setTint(color)
        setBounds(0, 0, dp(sizeDp), dp(sizeDp))
    }

    private fun focusScale(view: View) {
        view.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.04f else 1f).scaleY(if (has) 1.04f else 1f).setDuration(110L).start()
        }
    }

    private fun glass(radius: Int, elevated: Boolean = false): GradientDrawable {
        val p = UiPreferences.palette(this)
        val base = p.panel2
        val top = UiPreferences.blend(base, Color.WHITE, if (elevated) 0.09f else 0.055f)
        val bottom = UiPreferences.blend(base, Color.BLACK, 0.08f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(
            Color.argb(if (elevated) 238 else 220, Color.red(top), Color.green(top), Color.blue(top)),
            Color.argb(if (elevated) 226 else 208, Color.red(bottom), Color.green(bottom), Color.blue(bottom))
        )).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(if (elevated) 90 else 62, 255, 255, 255))
        }
    }

    private fun glassTint(accent: Int, radius: Int): GradientDrawable {
        val p = UiPreferences.palette(this)
        val top = UiPreferences.blend(p.panel2, accent, 0.30f)
        val bottom = UiPreferences.blend(p.panel2, Color.BLACK, 0.07f)
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(150, Color.red(accent), Color.green(accent), Color.blue(accent)))
        }
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (Color.alpha(stroke) > 0) setStroke(dp(1), stroke)
    }

    private fun humanBytes(value: Long): String {
        val v = value.coerceAtLeast(0L)
        return when {
            v >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.2f GB", v / (1024.0 * 1024.0 * 1024.0))
            v >= 1024L * 1024L -> String.format(Locale.US, "%.0f MB", v / (1024.0 * 1024.0))
            v >= 1024L -> String.format(Locale.US, "%.0f KB", v / 1024.0)
            else -> "$v B"
        }
    }

    private fun isTvLike(): Boolean = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
