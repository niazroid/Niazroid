package libbox

import (
	"fmt"
	"github.com/sagernet/sing-box/experimental/clashapi"
)

// A single sample preserves both directions; calling Now() separately
// for upstream and downstream would consume/double-read the same interval.
// The returned JSON contains numeric counters only, never proxy credentials.
func (s *BoxService) GhostTrafficJSON() string {
	var up, down, totalUp, totalDown int64
	if server := s.instance.Router().ClashServer(); server != nil {
		if clash, ok := server.(*clashapi.Server); ok {
			up, down = clash.TrafficManager().Now()
			totalUp, totalDown = clash.TrafficManager().Total()
		}
	}
	return fmt.Sprintf(`{"up":%d,"down":%d,"totalUp":%d,"totalDown":%d}`, up, down, totalUp, totalDown)
}
