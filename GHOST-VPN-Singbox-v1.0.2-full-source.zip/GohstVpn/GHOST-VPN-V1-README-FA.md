# GHOST VPN 1.0.0 (build 9)

- نام اپلیکیشن: GHOST VPN، نسخه 1.0.0+9. شناسهٔ برنامه تغییر نکرده است.
- گزینه و دیالوگ «واردکردن دستی چند کانفیگ» حذف شده‌اند. متد منحصراً مربوط به ورود متن دستی نیز حذف شده است.
- ورود URL اشتراک با HTTP/HTTPS، ورود فایل و QR و اشتراک‌های ذخیره‌شده باقی مانده‌اند.
- پچ‌های لازم پیام‌های فارسی و راست‌به‌چپ شدن کارت‌ها مستقیماً به سورس اعمال شده‌اند.
- امکانات قبلی VPN و ایمپورت لینک‌های دریافتی از اشتراک حفظ شده‌اند.
- اگر نسخهٔ قبلی با شناسهٔ `.dev` یا کلید امضای متفاوت ساخته شده، آپدیت درجا روی آن ممکن نیست.
- نصب APK از بیرون Google Play ممکن است هشدار Play Protect داشته باشد؛ تغییر نام/شماره نسخه یا امضای APK به‌تنهایی این هشدار را حذف نمی‌کند.
- GHOST VPN براساس FlClash / Mihomo ساخته شده؛ ارجاع و مجوزهای متن‌باز اصلی باید حفظ شوند.

Build recipe: use GHOST-VPN-github-actions-V20-v1-release.yml with GHOST-VPN-FlClash-v1.0.0-full-source.zip in repository ROOT. CI checks the signature & version using official Android build tools after APK generation.
