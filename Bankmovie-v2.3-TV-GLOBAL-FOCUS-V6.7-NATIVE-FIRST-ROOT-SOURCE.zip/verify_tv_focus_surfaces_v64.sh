#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

need "$MAIN" 'private val tvDirectionalActions = WeakHashMap<View, MutableMap<Int, () -> Boolean>>()'
need "$MAIN" 'private fun prepareTvFocusAncestors(target: View)'
need "$MAIN" 'private fun requestTvFocusVerified(target: View?): Boolean'
need "$MAIN" 'private fun handleTvGridDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'private fun wireTvGridSurface(grid: GridLayout)'
need "$MAIN" 'tvGrids.forEach { wireTvGridSurface(it) }'
need "$MAIN" 'private fun requestHomeTvWeeklyItemEntry(): Boolean'
need "$MAIN" 'bindTvDirectionalAction(tab, android.view.KeyEvent.KEYCODE_DPAD_DOWN) { requestHomeTvWeeklyItemEntry() }'
need "$MAIN" 'Continue Watching'
need "$MAIN" 'wireTvHorizontalRow(row, rightEdgeToSideNav = true) { more }'
need "$MAIN" 'val tvBoxOfficeRows = mutableListOf<View>()'
need "$MAIN" 'wireTvVerticalSequence(tvBoxOfficeRows)'
need "$MAIN" 'wireTvDeterministicSurface(page)'
need "$MAIN" 'tag = "bm_tv_search_more_filters"'
need "$MAIN" 'preferredFocus = typeChips.values.firstOrNull() ?: applyButton'

# Exact compile regression from V6.1 must remain fixed.
if grep -A4 -F 'private fun positionRailAtNewest(' "$MAIN" | grep -Fq 'row: LinearLayout,'; then
  echo 'V6.4 compile guard failed: positionRailAtNewest still requires LinearLayout' >&2
  exit 1
fi
need "$MAIN" 'row: ViewGroup,'

echo 'TV_FOCUS_SURFACES_V64_OK'
