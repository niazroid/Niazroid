#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need(){ grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$MAIN" 'private fun applyNativeNextFocusId(source: View?, keyCode: Int, target: View?)'
need "$MAIN" 'AlertDialog owns a separate Window'
need "$MAIN" 'ROOT FIX 2.3/V6.6: never create the initial Weekly focus children while'
need "$MAIN" 'private fun wireTvContinueRailExact(header: View, row: ViewGroup)'
need "$MAIN" 'private fun wireTvContinueFullListExact(list: ViewGroup)'
need "$MAIN" 'API order is not guaranteed to match the displayed rank.'
need "$MAIN" 'MainActivity.dispatchKeyEvent'
need "$MAIN" 'view.setOnKeyListener { _, keyCode, event ->'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_BUILD_SOURCE_2_3.txt' 'focusPatch=V6.6 VIDEO ROOT'
need 'BANKMOVIE_BUILD_SOURCE_2_3.txt' 'sourceTag=BANKMOVIE-TV-2.3-V66-20260906'
echo 'TV_FOCUS_V66_VIDEO_ROOT_OK'
