#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing V6.5/V6.6 marker: $2" >&2; exit 1; }; }

# Weekly: V6.6 supersedes the old detached-child rebuild. Initial TV render must
# happen only after attach; refresh remains as an empty-row fallback.
need "$MAIN" 'private var tvHomeWeeklyRefreshAction: (() -> Unit)? = null'
need "$MAIN" 'ROOT FIX 2.3/V6.6: never create the initial Weekly focus children while'
need "$MAIN" 'private fun requestHomeTvWeeklyItemEntry(): Boolean {'

# Continue Watching exact rails/full-list.
need "$MAIN" 'tag = "bm_tv_profile_continue_row"'
need "$MAIN" 'tag = "bm_tv_continue_full_list"'
need "$MAIN" 'private fun wireTvContinueRailExact(header: View, row: ViewGroup)'
need "$MAIN" 'private fun wireTvContinueFullListExact(list: ViewGroup)'

# Box Office strict rank order + direct row keys.
need "$MAIN" 'val wireBoxOffice = {'
need "$MAIN" 'API order is not guaranteed to match the displayed rank.'
need "$MAIN" '"boxoffice" -> content.findViewWithTag<View>("bm_tv_boxoffice_row_0")'
python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
a=s.index('private fun showBoxOffice()')
b=s.index('private fun showCollections()', a)
chunk=s[a:b]
for line in chunk.splitlines():
    if line.strip().startswith('wireTvDeterministicSurface(page)'):
        raise SystemExit('V6.5/V6.6 guard failed: Box Office still uses geometry deterministic surface')
PY

# Advanced filters: dialog-local direct key routing plus native nextFocus fallback.
need "$MAIN" 'fun wireAdvancedFiltersTvExact()'
need "$MAIN" 'fun installDirectRoutes(view: View, routes: Map<Int, () -> View?>)'
need "$MAIN" 'AlertDialog receives DPAD in its own Window.'
need "$MAIN" 'android.view.KeyEvent.KEYCODE_DPAD_DOWN to { firstSelector ?: yearFromInput }'
need "$MAIN" 'dialog.setOnKeyListener'

# Non-Home controls must never become a hard dead end.
need "$MAIN" 'Other screens must NOT swallow a direction when our explicit'
need "$MAIN" 'V6.7 ROOT: never swallow an unhandled DPAD event.'

echo 'TV_FOCUS_SURFACES_V65_ROOT_OK'
