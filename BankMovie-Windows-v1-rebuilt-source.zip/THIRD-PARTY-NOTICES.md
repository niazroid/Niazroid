# Third-Party Notices

BankMovie Windows uses:

- Microsoft.Web.WebView2 — Microsoft, licensed under the Microsoft software license terms applicable to WebView2.

V1 external-player edition does **not** bundle LibVLC, VLC binaries, codecs, or any other media engine.
External players are installed and licensed separately by the user.
