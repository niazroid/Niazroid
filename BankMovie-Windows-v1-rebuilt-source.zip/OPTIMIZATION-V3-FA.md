# BankMovie Windows V1 — Optimization / Direct Player V3

## هدف

این Revision برای کاهش لگ WebView2 و اجرای مستقیم پلیرهای خارجی ساخته شده است، بدون برگرداندن پلیر داخلی.

## اصلاحات Performance

1. Performance Mode برای تمام نسخه‌های Windows App فعال است؛ دیگر فقط با تعداد CPU core تصمیم‌گیری نمی‌شود.
2. افکت‌های پرهزینه animation / transition / backdrop-filter / hover transform در WebView ویندوز محدود شده‌اند.
3. `window.__BM_DEVICE_TIER__` قبل از اسکریپت‌های سایت روی lite/ultra قرار می‌گیرد تا `bm-performance.js` lazy image و توقف autoplay تزئینی را فعال کند.
4. MutationObserver سنگین Bridge که روی هر تغییر DOM همه button/linkها را scan می‌کرد حذف شده است.
5. هنگام Minimize شدن پنجره، WebView2 با `TrySuspendAsync()` suspend و پس از Restore با `Resume()` فعال می‌شود.
6. اجرای External Player روی UI thread انجام نمی‌شود.
7. مسیر executable پلیرهای نصب‌شده در طول Session cache می‌شود.
8. Extension/Sync/Translate/MediaRouter غیرضروری WebView2 غیرفعال شده‌اند؛ GPU acceleration عمداً خاموش نشده است.

## اصلاحات Direct Player

- Bridge V3 از `data-bm-play-action` پشتیبانی می‌کند.
- سایت با `window.bmGetPlayChoiceUrl()` URL دقیق کیفیت انتخاب‌شده را به App می‌دهد.
- VLC / KMPlayer / PotPlayer داخل Windows App مستقیم اجرا می‌شوند.
- انتخاب صریح VLC دیگر در صورت نصب نبودن VLC به PotPlayer fallback نمی‌کند؛ خطای واضح نمایش داده می‌شود.
- پخش عمومی `auto` همچنان fallback دارد و اولویت پیش‌فرض آن VLC سپس PotPlayer است.
- mpv / MPC-HC / MPC-BE / SMPlayer / GOM / WMP همچنان در Launcher پشتیبانی می‌شوند.

## ترتیب Deploy

1. فایل `BankMovie-Windows-v1-rebuilt-source.zip` جدید را با همین نام در root ریپوی Build جایگزین کنید.
2. فایل Workflow فعلی بدون تغییر قابل استفاده است.
3. Patch وب V3 را روی سایت Deploy کنید تا مودال پخش URL دقیق انتخاب‌شده را به Bridge بدهد.
4. بعد از Deploy وب، cache مرورگر/PWA با Service Worker version جدید refresh می‌شود.

## تست پیشنهادی

- Home: اسکرول سریع، hover کارت‌ها، جابه‌جایی بین صفحات.
- Minimize برای 15 ثانیه و Restore؛ صفحه باید بدون reload برگردد.
- Movie: یک کیفیت مشخص را انتخاب کنید و سپس VLC؛ همان URL باید در VLC باز شود.
- KMPlayer و PotPlayer را جداگانه تست کنید.
- با VLC uninstall شده روی دکمه VLC کلیک کنید؛ نباید PotPlayer ناخواسته باز شود.
- Generic Play/auto: اگر VLC نصب است VLC باز شود؛ در غیر این صورت پلیر بعدی نصب‌شده انتخاب شود.
