# BankMovie Windows V9 — .NET داخل خود EXE

در V9، برنامه به صورت `win-x64`, `self-contained`, `single-file` منتشر می‌شود.

- .NET 8 / Windows Desktop Runtime داخل `BankMovie.exe` باندل می‌شود.
- کاربر به نصب جداگانه .NET نیاز ندارد.
- Installer هیچ فایل `windowsdesktop-runtime-*.exe` را دانلود یا اجرا نمی‌کند.
- `EnableCompressionInSingleFile=true` برای کاهش حجم فعال است.
- `IncludeNativeLibrariesForSelfExtract=true` باعث می‌شود کتابخانه‌های native لازم نیز در single-file قرار بگیرند و هنگام اجرا در cache موقت استخراج شوند؛ این «نصب .NET» نیست.
- `PublishTrimmed=false` برای جلوگیری از ریسک شکستن WPF/WebView2 حفظ شده است.
- `PublishReadyToRun=false` برای جلوگیری از افزایش بی‌مورد حجم خاموش است.
- VLC / KMPlayer / PotPlayer همچنان external-player هستند و داخل برنامه باندل نمی‌شوند.
- WebView2 Runtime مستقل از .NET است؛ Setup فقط bootstrapper وب‌ویو را برای سیستم‌های فاقد WebView2 نگه می‌دارد.

Workflow خروجی را کنترل می‌کند:
1. `BankMovie.exe` باید حداقل 25 MiB باشد تا Publish اشتباهاً framework-dependent نشده باشد.
2. فایل‌های runtime مثل `coreclr.dll`, `hostfxr.dll` نباید به صورت sidecar کنار EXE باشند.
3. ZIP تو در تو در سورس ممنوع است.
