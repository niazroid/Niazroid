# BankMovie Windows V8 — .NET داخل خود Setup

- برنامه دوباره Framework-dependent و سبک است.
- فایل کامل و آفلاین Microsoft .NET 8 Desktop Runtime x64 داخل `BankMovie-Windows-v1-Setup-x64.exe` Embed می‌شود.
- Setup با دسترسی Administrator اجرا می‌شود تا نصب Runtime شکست خاموش نداشته باشد.
- Runtime قبل از اولین اجرای BankMovie به‌صورت Silent نصب می‌شود.
- بعد از نصب، Setup وجود `Microsoft.WindowsDesktop.App 8.0.x` را دوباره از Registry چک می‌کند؛ اگر نصب واقعاً انجام نشده باشد BankMovie را اجرا نمی‌کند و Setup خطای واقعی می‌دهد.
- اگر Runtime از قبل وجود داشته باشد، نصب دوباره Skip می‌شود.
- VLC / KMPlayer / PotPlayer Direct Play و Windows Bridge تغییر نکرده‌اند.
- ZIP توی ZIP ساخته نمی‌شود.

Runtime باندل‌شده در Build فعلی: Microsoft .NET Desktop Runtime 8.0.30 Windows x64.
