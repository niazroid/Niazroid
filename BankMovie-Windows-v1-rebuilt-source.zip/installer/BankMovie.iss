#ifndef MyAppVersion
#define MyAppVersion "1.0.0"
#endif
#ifndef SourceDir
#define SourceDir "..\publish"
#endif
#ifndef WebView2Bootstrapper
#define WebView2Bootstrapper "MicrosoftEdgeWebview2Setup.exe"
#endif

#define MyAppName "BankMovie"
#define MyAppPublisher "BankMovie"
#define MyAppExeName "BankMovie.exe"

[Setup]
AppId={{6B09B7ED-78A4-4A82-8C58-05A16301E09D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\BankMovie
DefaultGroupName=BankMovie
DisableProgramGroupPage=yes
OutputBaseFilename=BankMovie-Setup-x64
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
SetupIconFile=..\src\BankMovie.Windows\Resources\BankMovie.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
VersionInfoVersion={#MyAppVersion}
VersionInfoProductName=BankMovie Windows
VersionInfoCompany=BankMovie

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
; V9: BankMovie.exe is self-contained: the .NET 8 runtime is already INSIDE the EXE.
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
; WebView2 is a browser runtime, not .NET. Keep its bootstrapper only for machines missing WebView2.
Source: "{#WebView2Bootstrapper}"; DestDir: "{tmp}"; DestName: "MicrosoftEdgeWebview2Setup.exe"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\BankMovie"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\BankMovie"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Registry]
; Windows-only helper protocol for direct VLC/KMPlayer launch from the web build.
Root: HKCU; Subkey: "Software\Classes\bankmovie-player"; ValueType: string; ValueData: "URL:BankMovie Player Protocol"; Flags: uninsdeletekey
Root: HKCU; Subkey: "Software\Classes\bankmovie-player"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""
Root: HKCU; Subkey: "Software\Classes\bankmovie-player\DefaultIcon"; ValueType: string; ValueData: "{app}\{#MyAppExeName},0"
Root: HKCU; Subkey: "Software\Classes\bankmovie-player\shell\open\command"; ValueType: string; ValueData: """{app}\{#MyAppExeName}"" ""%1"""

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch BankMovie"; Flags: nowait postinstall skipifsilent; Check: CanLaunchBankMovie

[Code]
var
  WebView2OK: Boolean;

function WebView2Installed: Boolean;
var
  Version: string;
begin
  Result := RegQueryStringValue(HKLM64, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version)
    or RegQueryStringValue(HKLM32, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version)
    or RegQueryStringValue(HKCU, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version);
end;

procedure InstallWebView2IfNeeded;
var
  ResultCode: Integer;
  BootstrapperPath: string;
begin
  if WebView2Installed then
  begin
    Log('Microsoft WebView2 Runtime is already installed.');
    Exit;
  end;

  BootstrapperPath := ExpandConstant('{tmp}\MicrosoftEdgeWebview2Setup.exe');
  WizardForm.StatusLabel.Caption := 'Installing Microsoft WebView2 Runtime...';

  if not Exec(BootstrapperPath, '/silent /install', '', SW_HIDE,
    ewWaitUntilTerminated, ResultCode) then
  begin
    WebView2OK := False;
    RaiseException('Could not start the Microsoft WebView2 Runtime installer.');
  end;

  if not WebView2Installed then
  begin
    WebView2OK := False;
    RaiseException(Format('Microsoft WebView2 Runtime installation failed (exit code %d).', [ResultCode]));
  end;
end;

procedure InitializeWizard;
begin
  WebView2OK := True;
end;

procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssPostInstall then
    InstallWebView2IfNeeded;
end;

function CanLaunchBankMovie: Boolean;
begin
  Result := WebView2OK;
end;
