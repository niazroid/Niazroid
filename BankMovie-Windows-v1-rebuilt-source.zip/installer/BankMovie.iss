#ifndef MyAppVersion
#define MyAppVersion "1.0.0"
#endif
#ifndef SourceDir
#define SourceDir "..\publish"
#endif
#ifndef WebView2Bootstrapper
#define WebView2Bootstrapper "MicrosoftEdgeWebview2Setup.exe"
#endif

#define MyAppName "BankMovie"
#define MyAppPublisher "BankMovie"
#define MyAppExeName "BankMovie.exe"

[Setup]
AppId={{6B09B7ED-78A4-4A82-8C58-05A16301E09D}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\BankMovie
DefaultGroupName=BankMovie
DisableProgramGroupPage=yes
OutputBaseFilename=BankMovie-Setup-x64
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=lowest
SetupIconFile=..\src\BankMovie.Windows\Resources\BankMovie.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
VersionInfoVersion={#MyAppVersion}
VersionInfoProductName=BankMovie Windows
VersionInfoCompany=BankMovie

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"; Flags: unchecked

[Files]
Source: "{#SourceDir}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#WebView2Bootstrapper}"; DestDir: "{tmp}"; DestName: "MicrosoftEdgeWebview2Setup.exe"; Flags: deleteafterinstall

[Icons]
Name: "{autoprograms}\BankMovie"; Filename: "{app}\{#MyAppExeName}"
Name: "{autodesktop}\BankMovie"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{tmp}\MicrosoftEdgeWebview2Setup.exe"; Parameters: "/silent /install"; StatusMsg: "Installing Microsoft WebView2 Runtime..."; Flags: waituntilterminated skipifdoesntexist; Check: not WebView2Installed
Filename: "{app}\{#MyAppExeName}"; Description: "Launch BankMovie"; Flags: nowait postinstall skipifsilent

[Code]
function WebView2Installed: Boolean;
var
  Version: string;
begin
  Result := RegQueryStringValue(HKLM64, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version)
    or RegQueryStringValue(HKLM32, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version)
    or RegQueryStringValue(HKCU, 'SOFTWARE\Microsoft\EdgeUpdate\Clients\{F1E7E9D8-5C41-4C16-8E72-8E6C0A8431B0}', 'pv', Version);
end;
