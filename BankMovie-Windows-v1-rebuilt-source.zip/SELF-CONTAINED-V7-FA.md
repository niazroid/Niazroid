# BankMovie Windows V7 — Self-contained .NET

- .NET 8 Desktop Runtime is bundled inside the BankMovie single-file publish.
- Users do not need to install .NET separately.
- Single-file assembly compression is enabled to reduce size.
- WPF/WebView2 trimming remains disabled for reliability.
- WebView2 bootstrapper remains in Setup for systems without WebView2 Runtime.
- No nested Portable ZIP is generated.
- VLC / KMPlayer / PotPlayer direct-launch bridge is unchanged.
