# BankMovie Windows V1 — External Player Edition

نسخه عمومی برنامه همچنان **V1 / 1.0.0** است.

## معماری پخش

پلیر داخلی به‌طور کامل از برنامه حذف شده است. برنامه دیگر LibVLC یا هیچ موتور ویدیویی داخلی همراه خودش ندارد.

هنگام کلیک روی پخش:

- لینک مستقیم ویدیو از صفحه بانک‌مووی گرفته می‌شود.
- اگر کاربر روی نام یک پلیر خارجی کلیک کند همان پلیر اجرا می‌شود.
- اگر دکمه پخش عمومی باشد، اولین پلیر نصب‌شده طبق Priority اجرا می‌شود.
- خود فایل ویدیو در مرورگر باز نمی‌شود؛ URL مستقیم به executable پلیر داده می‌شود.

پلیرهای شناسایی‌شده:

- PotPlayer
- VLC
- mpv
- MPC-HC
- MPC-BE
- KMPlayer
- SMPlayer
- GOM Player
- Windows Media Player

دکمه MX Player در نسخه ویندوز به حالت Auto نگاشت می‌شود چون MX Player نسخه دسکتاپ Windows ندارد.

## تشخیص نصب پلیر

برنامه مسیر پلیرها را از این منابع پیدا می‌کند:

1. Windows App Paths Registry در HKCU/HKLM و Registry 32/64 bit
2. Program Files / Program Files (x86) / LocalAppData
3. PATH ویندوز

اگر پلیر انتخابی نصب نباشد و `fallbackToAnyInstalled=true` باشد، برنامه به اولین پلیر نصب‌شده بعدی می‌رود.

## تنظیم Priority

در `appsettings.json`:

```json
"externalPlayers": {
  "priority": ["potplayer", "vlc", "mpv", "mpc-hc", "mpc-be", "kmplayer"],
  "fallbackToAnyInstalled": true
}
```

## Build

نیازمندی‌ها:

- Windows x64
- .NET 8 SDK
- Microsoft WebView2 Runtime

در GitHub Actions:

- Restore
- Build Release x64
- Publish Self-contained
- بررسی می‌شود که هیچ فایل LibVLC در خروجی وجود نداشته باشد
- ساخت Portable ZIP
- ساخت Installer با Inno Setup

## نکته امنیتی

فقط URLهای `http://` و `https://` برای پخش مستقیم قبول می‌شوند.
آرگومان‌ها با `ProcessStartInfo.ArgumentList` ارسال می‌شوند و از shell command string استفاده نمی‌شود.
