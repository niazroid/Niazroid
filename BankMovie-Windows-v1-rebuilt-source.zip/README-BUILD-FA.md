# BankMovie Windows — خط توسعه Version 1

این پروژه از این نقطه **فقط Version 1** است. تا وقتی کلاینت ویندوز به وضعیت کامل و قابل انتشار نرسیده، شماره عمومی برنامه، فایل اجرایی و Installer روی `1 / 1.0.0` می‌ماند و با هر تغییر افزایش پیدا نمی‌کند.

## معماری فعلی

- رابط اصلی سایت داخل **WebView2** با Session و Cookie دائمی کاربر باز می‌شود.
- کلیک روی دکمه پخش سایت توسط Bridge ویندوز گرفته می‌شود و به **پلیر Native** تحویل داده می‌شود.
- پلیر از **LibVLC** داخلی استفاده می‌کند؛ نصب VLC جداگانه لازم نیست.
- Bridge برای آینده قرارداد مستقیم `window.BankMovieWindows.play(...)` و Context سریال/قسمت دارد تا PHP سایت بتواند بدون DOM-hack اطلاعات کامل پخش را به برنامه بدهد.
- Remote Config از `app_config.php?platform=windows&app_version=1` خوانده می‌شود و در صورت نبود/خطا، برنامه با تنظیمات محلی ادامه می‌دهد.

## امکانات پایه پلیر v1

- MP4 / MKV / HLS و فرمت‌های پشتیبانی‌شده LibVLC
- Hardware Decode با امکان خاموش‌کردن
- حالت Low-End برای سیستم‌های ضعیف
- Play / Pause، Seek قابل تنظیم، Volume، Mute، Fullscreen
- Resume از محل قبلی
- سرعت پخش 0.5x تا 2x
- انتخاب Audio Track
- انتخاب SoftSub داخلی
- افزودن SRT / ASS / SSA / VTT خارجی
- Subtitle Delay
- کنترل اندازه، رنگ، حاشیه، پس‌زمینه و فاصله زیرنویس؛ Apply با بازسازی سریع Engine در همان Timestamp
- پنل فصل/قسمت و Previous / Next / Auto Next، وقتی سایت لیست Episode را به Bridge بدهد
- Always on Top
- Auto-hide کنترل‌ها و Shortcutهای کیبورد/ماوس

## Shortcutها

- `Space`: پخش / توقف
- `← / →`: عقب / جلو
- `↑ / ↓`: صدا
- `M`: بی‌صدا
- `F`: تمام‌صفحه
- `S`: تنظیمات
- `E`: لیست قسمت‌ها
- `N / P`: قسمت بعد / قبل
- `Ctrl + L`: بازکردن دستی لینک در پلیر
- Double Click روی ویدیو: Fullscreen
- Mouse Wheel روی پلیر: صدا

## Build با GitHub Actions

محتویات ZIP را مستقیم در ریشه Repository قرار بده و Workflow با نام **Build BankMovie Windows v1** را اجرا کن. خروجی:

- `BankMovie-Windows-v1-Setup-x64.exe`
- `BankMovie-Windows-v1-Portable-x64.zip`
- `SHA256SUMS.txt`

Workflow عمداً Version را روی `1.0.0` قفل می‌کند.

## قرارداد سایت و اپ

فایل `docs/WINDOWS-PLAYBACK-BRIDGE-FA.md` قرارداد پیشنهادی PHP/JavaScript سایت با پلیر ویندوز را توضیح می‌دهد. برای انتخاب فصل/قسمت حرفه‌ای، سایت باید Context هر سریال را با این قرارداد تحویل اپ بدهد.
