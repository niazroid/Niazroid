# وضعیت Publish V9

نسخه V9 به صورت **Self-contained Single-file** ساخته می‌شود؛ .NET 8 داخل خود `BankMovie.exe` قرار دارد و کاربر نباید .NET را جدا نصب کند. Setup نیز دیگر installer جداگانه .NET را اجرا نمی‌کند. جزئیات در `DOTNET-IN-EXE-V9-FA.md`.

# BankMovie Windows V1 — Setup با .NET داخلی

نسخه عمومی برنامه همچنان **V1 / 1.0.0** است.

## معماری فعلی

- خود BankMovie به‌صورت **Framework-dependent** منتشر می‌شود تا فایل‌های برنامه سبک بمانند.
- **Microsoft .NET 8 Desktop Runtime x64 داخل فایل Setup نهایی Embed می‌شود**.
- کاربر هیچ Runtime جداگانه‌ای دانلود یا دستی نصب نمی‌کند؛ Setup قبل از اولین اجرای BankMovie آن را Silent نصب و سپس وجود Runtime را Verify می‌کند.
- اگر Runtime از قبل نصب باشد، Setup از نصب دوباره رد می‌شود.
- Setup برای اینکه نصب Runtime شکست خاموش نداشته باشد با Administrator اجرا می‌شود.
- WebView2 نیز توسط Setup بررسی/نصب می‌شود.
- ZIP توی ZIP ساخته نمی‌شود.

## پخش خارجی

پلیر داخلی وجود ندارد. URL مستقیم به پلیر خارجی انتخاب‌شده داده می‌شود. Bridge مربوط به VLC / KMPlayer / PotPlayer حفظ شده است.

## Build

Workflow موجود در `.github/workflows/build-windows.yml`:

1. سورس را Extract می‌کند.
2. .NET 8 SDK را برای Build آماده می‌کند.
3. BankMovie را Framework-dependent برای `win-x64` Publish می‌کند.
4. فایل رسمی `windowsdesktop-runtime-8.0.30-win-x64.exe` را از Microsoft دانلود و امضای Authenticode آن را Verify می‌کند.
5. WebView2 bootstrapper را آماده می‌کند.
6. Inno Setup را با مسیر Runtime فراخوانی می‌کند تا Runtime **داخل خود `BankMovie-Windows-v1-Setup-x64.exe`** قرار بگیرد.
7. اگر Setup نهایی آن‌قدر کوچک باشد که Runtime داخلش نباشد، Build عمداً Fail می‌شود.
8. SHA-256 خروجی‌ها تولید می‌شود.

## نصب روی سیستم کاربر

کاربر فقط این فایل را اجرا می‌کند:

`BankMovie-Windows-v1-Setup-x64.exe`

نیازی به نصب دستی .NET نیست.
