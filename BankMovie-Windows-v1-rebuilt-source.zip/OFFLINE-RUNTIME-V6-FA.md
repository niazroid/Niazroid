# BankMovie Windows V1 — Offline Runtime V6

- برنامه همچنان framework-dependent و سبک publish می‌شود.
- Setup رسمی، نصب‌کننده آفلاین Microsoft .NET 8 Desktop Runtime x64 را داخل خودش حمل می‌کند.
- اگر .NET 8 Desktop Runtime از قبل نصب باشد، مرحله نصب Runtime رد می‌شود.
- اگر نصب نباشد، Setup آن را silent و بدون نیاز به اینترنت نصب می‌کند.
- Microsoft WebView2 bootstrapper نیز مثل قبل توسط Setup مدیریت می‌شود.
- VLC / KMPlayer / PotPlayer داخل برنامه bundle نشده‌اند و Direct Play آن‌ها حفظ شده است.
- Portable ZIP تولید نمی‌شود؛ بنابراین GitHub Artifact شامل ZIP توی ZIP نخواهد بود.
- حجم فایل Setup از V5 بیشتر می‌شود، چون Runtime آفلاین .NET داخل Installer قرار می‌گیرد؛ این افزایش حجم عمدی است تا کاربر هیچ Runtime جداگانه‌ای نصب نکند.
