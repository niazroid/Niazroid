# قرارداد BankMovie Site → Windows Player

هدف این قرارداد این است که نسخه ویندوز به CSS و ظاهر سایت وابسته نباشد. DOM interception فعلی فقط fallback است؛ مسیر اصلی باید Context صریح باشد.

## روش پیشنهادی 1 — JavaScript Context

قبل از دکمه‌های پخش صفحه فیلم/سریال:

```html
<script>
window.__BM_WINDOWS_PLAYBACK_CONTEXT__ = {
  mediaId: "12345",
  seriesId: "12345",
  title: "Dexter",
  seasonNumber: 1,
  episodeNumber: 1,
  episodes: [
    {
      id: "e1",
      title: "Episode 1",
      seasonNumber: 1,
      episodeNumber: 1,
      url: "https://.../video.mkv",
      subtitleUrl: "https://.../sub.srt"
    }
  ]
};
</script>
```

روی دکمه پخش فقط یکی از Attributeهای زیر کافی است:

```html
<button data-bm-windows-play data-url="https://.../video.mkv" data-subtitle-url="https://.../sub.srt">پخش</button>
```

## روش پیشنهادی 2 — Direct API

داخل WebView2 شیء زیر توسط برنامه تزریق می‌شود:

```js
window.BankMovieWindows.play({
  url: 'https://.../video.mkv',
  subtitleUrl: 'https://.../sub.srt',
  label: 'Dexter S01E01',
  mediaId: '12345',
  seriesId: '12345',
  seasonNumber: 1,
  episodeNumber: 1,
  episodes: []
});
```

در مرورگر عادی قبل از استفاده، وجود `window.BankMovieWindows` را چک کن. بنابراین رفتار وب برای Chrome/Firefox دست‌نخورده می‌ماند.

## نکته امنیتی برای نسخه نهایی

در نسخه نهایی بهتر است `url` خام ویدیو از DOM حذف شود و سایت به اپ یک **Playback Ticket کوتاه‌عمر** بدهد. اپ Ticket را با Cookie کاربر به API بانک مووی می‌فرستد و Stream URL، Subtitle، Audio Tracks و Episode Playlist را دریافت می‌کند. این مرحله باید همراه تغییر PHP سایت انجام شود.
