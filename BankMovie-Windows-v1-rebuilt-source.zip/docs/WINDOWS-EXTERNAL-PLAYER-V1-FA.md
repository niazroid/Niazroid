# Windows V1 — Direct External Player Bridge

## تغییر اصلی

پلیر داخلی حذف شده و Bridge ویندوز فقط نقش انتقال لینک به پلیر خارجی را دارد.

## رفتار Bridge

اسکریپت WebView به‌صورت Capture روی کنترل‌های پخش و انتخاب پلیر گوش می‌دهد.
پلیرهای VLC / PotPlayer / KMPlayer / MPC-HC / MPC-BE / mpv / SMPlayer / GOM را از متن و data-attribute تشخیص می‌دهد.

برای دکمه‌های پخش عمومی مقدار `player=auto` ارسال می‌شود.

پیام WebView:

```json
{
  "type": "external-player",
  "player": "vlc",
  "url": "https://cdn.example/video.mkv",
  "subtitleUrl": "https://cdn.example/subtitle.srt",
  "referer": "https://bankmovie.top/movie/...",
  "userAgent": "..."
}
```

## حذف پلیر داخلی

حذف شده‌اند:

- PlayerWindow.xaml / .cs
- OpenMediaWindow.xaml / .cs
- LibVLCSharp.WPF
- VideoLAN.LibVLC.Windows
- PlayerPreferences
- PlaybackHistoryStore مربوط به پلیر داخلی
- دکمه ▶ در Title Bar
- میانبر Ctrl+L پلیر داخلی

## اجرای مستقیم

برنامه executable نصب‌شده را پیدا می‌کند و URL را مستقیم به همان process می‌دهد.
برای mpv و VLC در صورت وجود Referer/User-Agent نیز ارسال می‌شود.


## اصلاح Performance / Direct Launch

- Bridge V3 دکمه‌های واقعی سایت با `data-bm-play-action` را مستقیم می‌گیرد.
- انتخاب VLC / KMPlayer / PotPlayer دقیقاً همان پلیر را اجرا می‌کند و به پلیر دیگری fallback نمی‌کند.
- پخش عمومی `auto` با اولویت VLC و سپس PotPlayer/mpv/MPC اجرا می‌شود.
- اسکن سنگین و دائمی DOM برای مخفی‌کردن پلیر داخلی حذف شد.
- حالت Performance ویندوز افکت‌های blur/animation/hover پرهزینه را غیرفعال می‌کند.
- هنگام Minimize، WebView2 suspend می‌شود تا CPU/RAM فعال کمتری مصرف کند و پس از Restore resume می‌شود.
- جست‌وجوی executable پلیرها cache می‌شود و launch روی UI thread انجام نمی‌شود.
