# وضعیت خط توسعه Windows v1

## انجام‌شده در بازسازی پایه

- شماره نسخه عمومی و Build روی `1 / 1.0.0` قفل شد.
- Workflow قدیمی v1.3 حذف و Build مستقیم سورس جایگزین شد.
- Shell برنامه و Loading/Offline UI تمیزتر شد.
- WebView2 Bridge مستقل از CSS سایت طراحی شد و API مستقیم `window.BankMovieWindows.play()` اضافه شد.
- پلیر Native بازطراحی شد و کنترل‌ها به صورت شناور و بدون باکس بزرگ هستند.
- تنظیمات سرعت، Audio Track، Subtitle Track، فایل زیرنویس خارجی و Subtitle Delay اضافه شد.
- تنظیم اندازه/رنگ/Outline/Background/Margin زیرنویس با بازسازی Engine در Timestamp جاری اضافه شد.
- Resume، Auto-save موقعیت، Fullscreen، Keyboard/Mouse shortcuts، Always-on-top و Low-End Mode اضافه شد.
- Episode Playlist / Previous / Next / Auto Next به مدل پلیر اضافه شد.
- Remote Config پایه و fallback آفلاین اضافه شد.

## مرحله‌های بعدی در همان Version 1

1. Patch سمت سایت برای Playback Context استاندارد و Playlist دقیق فصل/قسمت.
2. Playback Ticket امضاشده به جای ارسال URL خام از DOM.
3. Remote Controller کامل Windows در پنل مدیریت.
4. Quality selector استاندارد و انتخاب Source بدون وابستگی به HTML سایت.
5. Crash logging محلی + ارسال اختیاری diagnostics.
6. تست واقعی روی Windows 10/11 و سیستم ضعیف، سپس بهینه‌سازی GPU/CPU/RAM.
7. بعد از تکمیل همه این مراحل تازه درباره تغییر Version تصمیم گرفته می‌شود؛ تا آن زمان Version همان 1 است.
