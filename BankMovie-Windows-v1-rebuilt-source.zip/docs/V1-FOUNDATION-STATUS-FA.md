# وضعیت خط توسعه Windows v1

نسخه عمومی همچنان **V1 / 1.0.0** است.

## وضعیت فعلی

- Shell برنامه و WebView2 پایدار است.
- Remote Config و Maintenance fallback فعال است.
- پلیر داخلی از V1 حذف شده است.
- هیچ LibVLC یا codec/runtime داخلی همراه برنامه منتشر نمی‌شود.
- پخش با Bridge مستقیم به پلیر خارجی نصب‌شده روی ویندوز منتقل می‌شود.
- Generic Play به Auto می‌رود و اولین پلیر نصب‌شده طبق Priority اجرا می‌شود.
- انتخاب VLC / PotPlayer / KMPlayer / MPC-HC / MPC-BE / mpv / SMPlayer / GOM از UI سایت مستقیم به همان برنامه می‌رود.
- MX Player روی Windows به Auto نگاشت می‌شود.
- لینک فقط وقتی پذیرفته می‌شود که HTTP/HTTPS معتبر باشد.
- executable پلیر از Registry App Paths، مسیرهای رایج و PATH پیدا می‌شود.
- ارسال آرگومان با `ProcessStartInfo.ArgumentList` انجام می‌شود.

## مرحله‌های بعدی در همان Version 1

1. تست واقعی با چند CDN و فرمت MP4/MKV/HLS روی Windows 10/11.
2. تست VLC / PotPlayer / KMPlayer / MPC / mpv روی نصب واقعی.
3. در صورت نیاز Playback Ticket امضاشده سمت سرور برای لینک‌های محافظت‌شده.
4. تنظیم Remote Priority پلیرها از پنل مدیریت.
5. Crash logging محلی + diagnostics اختیاری.
6. بعد از تکمیل همه مراحل تازه درباره تغییر Version تصمیم گرفته می‌شود؛ تا آن زمان Version همان 1 است.
