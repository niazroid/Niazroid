# Remote Config نسخه ویندوز

برنامه در شروع تلاش می‌کند JSON را از `remoteConfigUrl` در `appsettings.json` بگیرد. خطای شبکه باعث توقف برنامه نمی‌شود.

Schema پایه:

```json
{
  "enabled": true,
  "maintenance": false,
  "maintenanceMessage": "",
  "requiredVersion": "1",
  "texts": {
    "windows_offline_title": "اتصال برقرار نشد",
    "windows_offline_description": "اتصال اینترنت را بررسی کن"
  },
  "player": {
    "networkCachingMs": 1800,
    "seekSeconds": 10,
    "hardwareDecoding": true,
    "autoNextEpisode": true,
    "lowEndMode": false
  }
}
```

`requiredVersion` تا پایان خط توسعه Version 1 باید روی `1` بماند.
