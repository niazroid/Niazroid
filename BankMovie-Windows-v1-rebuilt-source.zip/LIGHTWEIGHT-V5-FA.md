# BankMovie Windows Lightweight V5

- انتشار Windows به حالت framework-dependent تغییر کرد؛ .NET 8 Desktop Runtime دیگر داخل برنامه باندل نمی‌شود.
- WebView2 همچنان با bootstrapper نصب‌کننده مدیریت می‌شود.
- مرحله ساخت Portable ZIP حذف شد تا GitHub Artifact دیگر ZIP داخل ZIP نداشته باشد.
- Workflow اگر فایل‌های اصلی runtime دات‌نت داخل publish دیده شوند یا حجم publish از 25 MiB بیشتر شود fail می‌شود.
- Direct launch برای VLC / KMPlayer / PotPlayer بدون تغییر باقی مانده است.

پیش‌نیاز اجرا: Microsoft .NET 8 Desktop Runtime x64 باید روی ویندوز نصب باشد.
