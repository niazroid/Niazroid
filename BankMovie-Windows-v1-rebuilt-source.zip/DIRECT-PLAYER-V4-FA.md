# Direct Player V4 — VLC / KMPlayer

- داخل BankMovie Windows، دکمه VLC فقط VLC را اجرا می‌کند.
- دکمه KMPlayer فقط KMPlayer را اجرا می‌کند.
- برای انتخاب صریح هیچ fallback به پلیر دیگر وجود ندارد.
- تشخیص VLC/KMPlayer از App Paths، Uninstall Registry، Program Files/LocalAppData و PATH انجام می‌شود.
- در مرورگر Windows، اگر BankMovie نصب باشد، پروتکل `bankmovie-player://` لینک را به برنامه می‌دهد و همان VLC/KMPlayer را اجرا می‌کند.
- Android و iOS دست‌نخورده‌اند؛ Intent و VLC iOS قبلی حفظ شده‌اند.
