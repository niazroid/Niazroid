namespace BankMovie.Windows.Models;

public sealed class RemoteConfig
{
    public bool Enabled { get; set; } = true;
    public bool Maintenance { get; set; }
    public string? MaintenanceMessage { get; set; }
    public string? RequiredVersion { get; set; }
    public Dictionary<string, string> Texts { get; set; } = new(StringComparer.OrdinalIgnoreCase);
}
