namespace BankMovie.Windows.Models;

public sealed class RemoteConfig
{
    public bool Enabled { get; set; } = true;
    public bool Maintenance { get; set; }
    public string? MaintenanceMessage { get; set; }
    public string? RequiredVersion { get; set; }
    public Dictionary<string, string> Texts { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    public RemotePlayerConfig Player { get; set; } = new();
}

public sealed class RemotePlayerConfig
{
    public uint? NetworkCachingMs { get; set; }
    public int? SeekSeconds { get; set; }
    public bool? HardwareDecoding { get; set; }
    public bool? AutoNextEpisode { get; set; }
    public bool? LowEndMode { get; set; }
}
