namespace BankMovie.Windows.Models;

public sealed class AppConfig
{
    public string SiteUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public string HomeUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public string RemoteConfigUrl { get; set; } = "https://bankmovie.top/app_config.php?platform=windows&app_version=1";
    public List<string> AllowedHosts { get; set; } = ["bankmovie.top", "www.bankmovie.top"];
    public PlayerConfig Player { get; set; } = new();
}

public sealed class PlayerConfig
{
    public uint NetworkCachingMs { get; set; } = 1800;
    public bool HardwareDecoding { get; set; } = true;
    public bool RememberPosition { get; set; } = true;
    public bool AutoLoadProvidedSubtitle { get; set; } = true;
    public int SeekSeconds { get; set; } = 10;
    public bool AutoNextEpisode { get; set; } = true;
    public string PerformancePreset { get; set; } = "auto";
}
