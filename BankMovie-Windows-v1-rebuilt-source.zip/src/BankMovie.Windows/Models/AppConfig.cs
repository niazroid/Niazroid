namespace BankMovie.Windows.Models;

public sealed class AppConfig
{
    public string SiteUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public string HomeUrl { get; set; } = "https://bankmovie.top/?source=windows-app";
    public string RemoteConfigUrl { get; set; } = "https://bankmovie.top/app_config.php?platform=windows&app_version=1";
    public List<string> AllowedHosts { get; set; } = ["bankmovie.top", "www.bankmovie.top"];
    public ExternalPlayerConfig ExternalPlayers { get; set; } = new();
}

public sealed class ExternalPlayerConfig
{
    public List<string> Priority { get; set; } = ["vlc", "potplayer", "mpv", "mpc-hc", "mpc-be", "kmplayer"];
    public bool FallbackToAnyInstalled { get; set; } = true;
    public bool FallbackForExplicitSelection { get; set; } = false;
}
