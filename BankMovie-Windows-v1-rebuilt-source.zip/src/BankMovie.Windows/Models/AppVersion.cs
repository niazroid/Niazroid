namespace BankMovie.Windows.Models;

public static class AppVersion
{
    // Development policy: keep the public Windows version at 1 until the
    // product is declared complete. Build/revision numbers must not change it.
    public const string Public = "1";
    public const string Semantic = "1.0.0";
    public const string UserAgent = "BankMovie-Windows/1";
}
