namespace BankMovie.Windows.Models;

public sealed class PlayerPreferences
{
    public int Volume { get; set; } = 90;
    public double PlaybackRate { get; set; } = 1.0;
    public int SeekSeconds { get; set; } = 10;
    public bool AutoNextEpisode { get; set; } = true;
    public bool AlwaysOnTop { get; set; }
    public bool HardwareDecoding { get; set; } = true;
    public bool LowEndMode { get; set; }

    public int SubtitleFontSize { get; set; } = 28;
    public string SubtitleColor { get; set; } = "#FFFFFF";
    public int SubtitleOutlineThickness { get; set; } = 2;
    public int SubtitleBackgroundOpacity { get; set; } = 0;
    public int SubtitleMargin { get; set; } = 36;
    public int SubtitleDelayMs { get; set; }
}
