namespace BankMovie.Windows.Models;

public sealed class PlayerLaunchRequest
{
    public required string Url { get; init; }
    public string Player { get; init; } = "auto";
    public string? SubtitleUrl { get; init; }
    public string? Title { get; init; }
    public string? Referer { get; init; }
    public string? UserAgent { get; init; }
    public string? CookieHeader { get; init; }
}

public sealed class PlayerLaunchResult
{
    public bool Success { get; init; }
    public string? PlayerId { get; init; }
    public string? PlayerName { get; init; }
    public bool UsedFallback { get; init; }
    public string? Error { get; init; }

    public static PlayerLaunchResult Ok(string playerId, string playerName, bool usedFallback) => new()
    {
        Success = true,
        PlayerId = playerId,
        PlayerName = playerName,
        UsedFallback = usedFallback
    };

    public static PlayerLaunchResult Failed(string error) => new() { Success = false, Error = error };
}

public sealed record DetectedExternalPlayer(string Id, string Name, string Path);

public sealed class WebBridgeMessage
{
    public string? Type { get; set; }
    public string? Player { get; set; }
    public string? Url { get; set; }
    public string? SubtitleUrl { get; set; }
    public string? Label { get; set; }
    public string? Referer { get; set; }
    public string? UserAgent { get; set; }
}
