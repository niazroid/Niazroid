namespace BankMovie.Windows.Models;

public sealed class PlaybackRequest
{
    public required string Url { get; init; }
    public string? SubtitleUrl { get; init; }
    public string? Title { get; init; }
    public string? Referer { get; init; }
    public string? UserAgent { get; init; }
    public string? CookieHeader { get; init; }
    public string? MediaId { get; init; }
    public string? SeriesId { get; init; }
    public int? SeasonNumber { get; init; }
    public int? EpisodeNumber { get; init; }
    public int CurrentEpisodeIndex { get; init; } = -1;
    public IReadOnlyList<PlaybackEpisode> Episodes { get; init; } = Array.Empty<PlaybackEpisode>();
}

public sealed class PlaybackEpisode
{
    public string? Id { get; init; }
    public required string Url { get; init; }
    public string? SubtitleUrl { get; init; }
    public string? Title { get; init; }
    public int? SeasonNumber { get; init; }
    public int? EpisodeNumber { get; init; }
}

public sealed class WebBridgeMessage
{
    public string? Type { get; set; }
    public string? Url { get; set; }
    public string? SubtitleUrl { get; set; }
    public string? Label { get; set; }
    public string? Referer { get; set; }
    public string? UserAgent { get; set; }
    public string? MediaId { get; set; }
    public string? SeriesId { get; set; }
    public int? SeasonNumber { get; set; }
    public int? EpisodeNumber { get; set; }
    public List<WebBridgeEpisode>? Episodes { get; set; }
}

public sealed class WebBridgeEpisode
{
    public string? Id { get; set; }
    public string? Url { get; set; }
    public string? SubtitleUrl { get; set; }
    public string? Title { get; set; }
    public int? SeasonNumber { get; set; }
    public int? EpisodeNumber { get; set; }
}
