using System.Windows;

namespace BankMovie.Windows;

public partial class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        // V1 external-player edition intentionally ships no internal media engine.
        // Playback is delegated to the user's installed Windows player.
    }
}
