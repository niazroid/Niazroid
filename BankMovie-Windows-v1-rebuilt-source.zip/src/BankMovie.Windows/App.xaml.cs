using System.Windows;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;

namespace BankMovie.Windows;

public partial class App : System.Windows.Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // bankmovie-player:// is the web-to-desktop helper used only on Windows.
        // It lets a normal Windows browser hand an exact stream URL to VLC/KMPlayer
        // without changing Android/iOS behavior.
        if (e.Args.Length > 0 && TryHandlePlayerProtocol(e.Args[0]))
        {
            Shutdown();
            return;
        }

        var window = new MainWindow();
        MainWindow = window;
        window.Show();
    }

    private static bool TryHandlePlayerProtocol(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw) ||
            !Uri.TryCreate(raw.Trim().Trim('"'), UriKind.Absolute, out var uri) ||
            !string.Equals(uri.Scheme, "bankmovie-player", StringComparison.OrdinalIgnoreCase))
        {
            return false;
        }

        try
        {
            var query = ParseQuery(uri.Query);
            query.TryGetValue("url", out var url);
            query.TryGetValue("player", out var player);
            query.TryGetValue("subtitle", out var subtitle);
            query.TryGetValue("title", out var title);
            query.TryGetValue("referer", out var referer);

            if (!IsHttpUrl(url))
            {
                MessageBox.Show("لینک پخش معتبر نیست.", "BankMovie", MessageBoxButton.OK, MessageBoxImage.Warning);
                return true;
            }

            var config = ConfigService.Load();
            var request = new PlayerLaunchRequest
            {
                Url = url!,
                Player = string.IsNullOrWhiteSpace(player) ? "auto" : player!,
                SubtitleUrl = IsHttpUrl(subtitle) ? subtitle : null,
                Title = title,
                Referer = IsHttpUrl(referer) ? referer : null,
                UserAgent = AppVersion.UserAgent
            };

            var result = ExternalPlayerLauncher.Launch(request, config.ExternalPlayers);
            if (!result.Success)
            {
                MessageBox.Show(result.Error ?? "پلیر انتخاب‌شده قابل اجرا نبود.", "BankMovie", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("اجرای پلیر ناموفق بود.\n" + ex.Message, "BankMovie", MessageBoxButton.OK, MessageBoxImage.Warning);
        }

        return true;
    }

    private static Dictionary<string, string> ParseQuery(string query)
    {
        var result = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var text = (query ?? string.Empty).TrimStart('?');
        foreach (var pair in text.Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var parts = pair.Split('=', 2);
            var key = Decode(parts[0]);
            if (key.Length == 0) continue;
            result[key] = parts.Length > 1 ? Decode(parts[1]) : string.Empty;
        }
        return result;
    }

    private static string Decode(string value)
    {
        try { return Uri.UnescapeDataString((value ?? string.Empty).Replace("+", " ")); }
        catch { return value ?? string.Empty; }
    }

    private static bool IsHttpUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";
}
