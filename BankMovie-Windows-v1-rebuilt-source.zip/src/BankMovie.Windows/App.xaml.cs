using System.Windows;
using BankMovie.Windows.Models;
using LibVLCSharp.Shared;

namespace BankMovie.Windows;

public partial class App : System.Windows.Application
{
    public static bool PlayerEngineAvailable { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        try
        {
            Core.Initialize();
            // Probe once so a broken native runtime is reported at startup.
            using var probe = new LibVLC("--no-video-title-show", "--quiet");
            probe.SetAppId("ir.bankmovie.windows", AppVersion.Public, "BankMovie");
            probe.SetUserAgent("BankMovie Windows", AppVersion.UserAgent);
            PlayerEngineAvailable = true;
        }
        catch (Exception ex)
        {
            PlayerEngineAvailable = false;
            MessageBox.Show(
                "موتور پخش داخلی بارگذاری نشد. مرور سایت فعال می‌ماند، اما پلیر تا نصب صحیح فایل‌های موتور در دسترس نیست.\n\n" + ex.Message,
                "BankMovie Player",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    public static LibVLC CreatePlayerEngine(PlayerPreferences preferences, PlayerConfig config)
    {
        if (!PlayerEngineAvailable) throw new InvalidOperationException("Player engine is not available.");

        var color = ParseRgbInteger(preferences.SubtitleColor);
        var options = new List<string>
        {
            "--no-video-title-show",
            "--no-snapshot-preview",
            "--quiet",
            $"--network-caching={config.NetworkCachingMs}",
            $"--freetype-fontsize={preferences.SubtitleFontSize}",
            $"--freetype-color={color}",
            $"--freetype-outline-thickness={preferences.SubtitleOutlineThickness}",
            $"--freetype-background-opacity={preferences.SubtitleBackgroundOpacity}",
            $"--sub-margin={preferences.SubtitleMargin}"
        };

        if (preferences.LowEndMode)
        {
            options.Add("--drop-late-frames");
            options.Add("--skip-frames");
            options.Add("--no-video-wallpaper");
        }

        LibVLC engine;
        try
        {
            engine = new LibVLC(options.ToArray());
        }
        catch
        {
            // Never lose playback because a particular VLC build does not
            // expose one of the subtitle renderer options.
            engine = new LibVLC("--no-video-title-show", "--no-snapshot-preview", "--quiet", $"--network-caching={config.NetworkCachingMs}");
        }
        engine.SetAppId("ir.bankmovie.windows", AppVersion.Public, "BankMovie");
        engine.SetUserAgent("BankMovie Windows", AppVersion.UserAgent);
        return engine;
    }

    private static int ParseRgbInteger(string? value)
    {
        try
        {
            var text = (value ?? "#FFFFFF").Trim().TrimStart('#');
            if (text.Length == 8) text = text[^6..];
            return Convert.ToInt32(text, 16);
        }
        catch
        {
            return 0xFFFFFF;
        }
    }
}
