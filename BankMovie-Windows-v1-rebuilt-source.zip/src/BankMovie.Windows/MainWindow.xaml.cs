using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace BankMovie.Windows;

public partial class MainWindow : Window
{
    private readonly AppConfig _config = ConfigService.Load();
    private RemoteConfig? _remote;
    private bool _webReady;
    private bool _webSuspended;

    private const string DesktopBridgeScript = """
(() => {
  if (window.__bmWindowsBridgeInstalled) return;
  window.__bmWindowsBridgeInstalled = true;
  window.__BANKMOVIE_WINDOWS_APP__ = Object.freeze({ version: '1', bridge: 3, internalPlayer: false, performanceMode: true });
  document.documentElement.classList.add('bm-windows-app', 'bm-windows-external-player-only', 'bm-windows-performance');
  try {
    window.__BM_DEVICE_TIER__ = Object.assign({}, window.__BM_DEVICE_TIER__ || {}, {
      mobile: false,
      lite: true,
      ultra: true,
      windowsApp: true
    });
  } catch (_) {}

  const style = document.createElement('style');
  style.textContent = `
    html.bm-windows-app { scroll-behavior:auto !important; background:#05070c !important; }
    html.bm-windows-performance *, html.bm-windows-performance *::before, html.bm-windows-performance *::after {
      animation-duration:0.001ms !important;
      animation-iteration-count:1 !important;
      transition-duration:0.001ms !important;
      scroll-behavior:auto !important;
    }
    html.bm-windows-performance .glass,
    html.bm-windows-performance [class*="glass"],
    html.bm-windows-performance [style*="backdrop-filter"],
    html.bm-windows-performance #siteHeader,
    html.bm-windows-performance .header,
    html.bm-windows-performance .desktop-header,
    html.bm-windows-performance .mobile-header,
    html.bm-windows-performance .bm-cinematic-tabs,
    html.bm-windows-performance .bm-app-mini-card,
    html.bm-windows-performance .watchlist-icon-grid,
    html.bm-windows-performance .imdb-card-badge,
    html.bm-windows-performance .year-badge,
    html.bm-windows-performance .genre-chip,
    html.bm-windows-performance .country-chip,
    html.bm-windows-performance .quick-action,
    html.bm-windows-performance .bm-ad-badge,
    html.bm-windows-performance .imdb-rating-badge {
      backdrop-filter:none !important;
      -webkit-backdrop-filter:none !important;
      will-change:auto !important;
    }
    html.bm-windows-performance .movie-card,
    html.bm-windows-performance .scroll-card,
    html.bm-windows-performance .grid-item,
    html.bm-windows-performance .collection-card,
    html.bm-windows-performance .related-card,
    html.bm-windows-performance .content-card,
    html.bm-windows-performance .archive-card,
    html.bm-windows-performance .result-card,
    html.bm-windows-performance .poster-card { will-change:auto !important; }
    html.bm-windows-performance .movie-card:hover,
    html.bm-windows-performance .scroll-card:hover,
    html.bm-windows-performance .grid-item:hover,
    html.bm-windows-performance .collection-card:hover,
    html.bm-windows-performance .related-card:hover,
    html.bm-windows-performance .content-card:hover,
    html.bm-windows-performance .archive-card:hover,
    html.bm-windows-performance .result-card:hover,
    html.bm-windows-performance .poster-card:hover {
      transform:none !important;
      filter:none !important;
      -webkit-filter:none !important;
    }
    html.bm-windows-performance .bm-promo-banner::before,
    html.bm-windows-performance .hero-glow,
    html.bm-windows-performance .bm-ad-glow,
    html.bm-windows-performance .bm-header-search-glow,
    html.bm-windows-performance [class*="skeleton"]::before { animation:none !important; }
    .bm-windows-app [data-pwa-install],
    .bm-windows-app #installPwaButton,
    .bm-windows-app .pwa-install-button,
    .bm-windows-app .install-app-btn { display:none !important; }

    /* Internal/BankMovie player is intentionally removed in the Windows app. */
    .bm-windows-external-player-only [data-player="internal"],
    .bm-windows-external-player-only [data-player="bankmovie"],
    .bm-windows-external-player-only [data-bm-player="internal"],
    .bm-windows-external-player-only [data-bm-player="bankmovie"],
    .bm-windows-external-player-only [data-player-name="internal"],
    .bm-windows-external-player-only [data-bm-play-action="internal"],
    .bm-windows-external-player-only .bm-internal-player,
    .bm-windows-external-player-only .internal-player-btn,
    .bm-windows-external-player-only .bankmovie-player-btn { display:none !important; }
  `;
  document.documentElement.appendChild(style);

  const directPlaySelector = [
    '[data-bm-windows-play]',
    '[data-direct-player="1"][data-url]',
    '.bm-local-play-choice',
    '.bm-download-play-choice',
    '.bm-poster-play',
    '.arc1-play-btn',
    '.arc1-play-inline[data-url]'
  ].join(',');

  const externalChoiceSelector = [
    '[data-external-player]',
    '[data-bm-play-action]',
    '[data-player-name]',
    '[data-bm-player]',
    '[data-player]',
    '.bm-external-player',
    '.external-player-btn',
    '.player-choice',
    '.player-option',
    'a[href^="vlc:"]',
    'a[href^="potplayer:"]',
    'a[href^="kmplayer:"]',
    'a[href^="mpv:"]'
  ].join(',');

  const safeText = v => String(v || '').trim();
  function isHttpUrl(value) {
    try {
      const u = new URL(value, location.href);
      return u.protocol === 'http:' || u.protocol === 'https:';
    } catch (_) { return false; }
  }
  function absolute(value) {
    if (!value) return '';
    try { return new URL(value, location.href).href; } catch (_) { return ''; }
  }
  function decodeLoose(value) {
    let out = safeText(value);
    for (let i = 0; i < 3; i++) {
      try {
        const next = decodeURIComponent(out);
        if (next === out) break;
        out = next;
      } catch (_) { break; }
    }
    return out;
  }
  function extractHttp(value) {
    const raw = decodeLoose(value);
    if (!raw) return '';
    if (isHttpUrl(raw)) return absolute(raw);
    const match = raw.match(/https?:\/\/[^\s"'<>]+/i);
    if (!match) return '';
    return absolute(match[0]);
  }
  function readContext() {
    try {
      const direct = window.__BM_WINDOWS_PLAYBACK_CONTEXT__ || window.BankMovieWindowsPlayback;
      if (direct && typeof direct === 'object') return direct;
    } catch (_) {}
    try {
      const script = document.querySelector('#bm-windows-playback-context[type="application/json"]');
      if (script?.textContent) return JSON.parse(script.textContent);
    } catch (_) {}
    return {};
  }
  function nearestRow(target) {
    try {
      return target.closest('.arc1-link-row,.download-link,.premium-download-card,.episode-item,.episode-card,.movie-detail,.movie-hero,.download-item,.link-row');
    } catch (_) { return null; }
  }
  function resolveUrl(target) {
    const context = readContext();

    // The site's playback modal keeps the exact selected quality URL in closure state.
    // Prefer its explicit getter and never guess another quality from the page.
    if (target.getAttribute?.('data-bm-play-action')) {
      if (typeof window.bmGetPlayChoiceUrl === 'function') {
        try {
          const active = extractHttp(window.bmGetPlayChoiceUrl());
          if (active) return active;
        } catch (_) {}
      }
      return '';
    }

    const attrs = [
      'data-url','data-play-url','data-stream-url','data-media-url','data-video-url','data-href','onclick'
    ];
    for (const attr of attrs) {
      const value = extractHttp(target.getAttribute?.(attr));
      if (value) return value;
    }

    if (target.tagName === 'A') {
      const value = extractHttp(target.getAttribute('href'));
      if (value) return value;
    }

    const row = nearestRow(target);
    if (row) {
      for (const attr of attrs) {
        const value = extractHttp(row.getAttribute?.(attr));
        if (value) return value;
      }
      try {
        const node = row.querySelector('[data-url],[data-play-url],[data-stream-url],[data-media-url],[data-video-url],a[href]');
        if (node) {
          for (const attr of attrs) {
            const value = extractHttp(node.getAttribute?.(attr));
            if (value) return value;
          }
          if (node.tagName === 'A') {
            const value = extractHttp(node.getAttribute('href'));
            if (value) return value;
          }
        }
      } catch (_) {}
    }

    if (typeof window.bmGetCurrentMoviePlayUrl === 'function') {
      try {
        const value = extractHttp(window.bmGetCurrentMoviePlayUrl());
        if (value) return value;
      } catch (_) {}
    }

    return extractHttp(context.url || context.playUrl || context.streamUrl || '');
  }
  function resolveSubtitle(target, url) {
    let value = extractHttp(target.getAttribute?.('data-subtitle-url'));
    if (!value && typeof window.bmFindSubtitleForVideoUrl === 'function' && url) {
      try { value = extractHttp(window.bmFindSubtitleForVideoUrl(url)); } catch (_) {}
    }
    return value;
  }
  function resolveLabel(target) {
    const context = readContext();
    const direct = safeText(target.getAttribute?.('data-label'));
    if (direct) return direct;
    try {
      const row = nearestRow(target);
      const node = row?.querySelector?.('.quality,.bm-archive2-quality-halo,.download-type-badge,.title,.episode-title');
      if (node?.textContent) return safeText(node.textContent).replace(/\s+/g, ' ');
    } catch (_) {}
    return safeText(context.title) || safeText(document.querySelector('h1,.movie-title,.hero-title')?.textContent) || document.title || 'BankMovie';
  }
  function normalizePlayerName(value) {
    const raw = safeText(value).toLowerCase();
    if (!raw) return '';
    if (raw === 'pot' || raw.includes('potplayer') || raw.includes('pot player')) return 'potplayer';
    if (raw === 'vlc' || raw.includes('vlc')) return 'vlc';
    if (raw === 'km' || raw.includes('kmplayer') || raw.includes('km player')) return 'kmplayer';
    if (raw === 'mx' || raw.includes('mxplayer') || raw.includes('mx player')) return 'auto';
    if (raw.includes('mpc-hc') || raw.includes('mpc hc') || raw.includes('mpchc')) return 'mpc-hc';
    if (raw.includes('mpc-be') || raw.includes('mpc be') || raw.includes('mpcbe')) return 'mpc-be';
    if (raw.includes('mpv')) return 'mpv';
    if (raw.includes('smplayer') || raw.includes('sm player')) return 'smplayer';
    if (raw.includes('gom')) return 'gom';
    if (raw.includes('windows media') || raw.includes('wmplayer')) return 'wmp';
    if (raw.includes('mx player') || raw.includes('mxplayer')) return 'auto';
    if (raw.includes('internal') || raw.includes('bankmovie') || raw.includes('داخلی')) return 'auto';
    return '';
  }
  function resolvePlayer(target) {
    const attrs = ['data-external-player','data-bm-play-action','data-player-name','data-bm-player','data-player','title','aria-label','href','onclick'];
    for (const attr of attrs) {
      const player = normalizePlayerName(target.getAttribute?.(attr));
      if (player) return player;
    }
    return normalizePlayerName(target.textContent || '');
  }
  function sendLaunch(target, event, forcedPlayer) {
    const url = resolveUrl(target);
    if (!isHttpUrl(url)) return false;

    const player = forcedPlayer || resolvePlayer(target) || 'auto';
    const subtitleUrl = resolveSubtitle(target, url);
    const label = resolveLabel(target);

    event?.preventDefault?.();
    event?.stopPropagation?.();
    event?.stopImmediatePropagation?.();

    try {
      window.chrome.webview.postMessage({
        type: 'external-player',
        player,
        url,
        subtitleUrl,
        label,
        referer: location.href,
        userAgent: navigator.userAgent
      });
      return true;
    } catch (_) { return false; }
  }

  function hideInternalPlayerChoices(root) {
    const scope = root && root.querySelectorAll ? root : document;
    const nodes = scope.querySelectorAll('button,a,[role="button"],[data-player],[data-bm-player],[data-player-name]');
    nodes.forEach(node => {
      const fingerprint = [
        node.getAttribute?.('data-player'),
        node.getAttribute?.('data-bm-player'),
        node.getAttribute?.('data-player-name'),
        node.getAttribute?.('title'),
        node.getAttribute?.('aria-label'),
        node.textContent
      ].map(safeText).join(' ').toLowerCase();
      if (fingerprint.includes('پلیر داخلی') || fingerprint.includes('internal player') || fingerprint.includes('bankmovie player')) {
        node.style.setProperty('display', 'none', 'important');
        node.setAttribute('aria-hidden', 'true');
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => hideInternalPlayerChoices(document), { once:true });
  } else hideInternalPlayerChoices(document);

  document.addEventListener('click', event => {
    const externalTarget = event.target?.closest?.(externalChoiceSelector);
    if (externalTarget) {
      const player = resolvePlayer(externalTarget);
      if (player) {
        if (sendLaunch(externalTarget, event, player)) return;
      }
    }

    const directTarget = event.target?.closest?.(directPlaySelector);
    if (directTarget) sendLaunch(directTarget, event, 'auto');
  }, true);

  window.BankMovieWindows = Object.freeze({
    version: '1',
    internalPlayer: false,
    play(payload) {
      const data = payload || {};
      const url = extractHttp(data.url || data.playUrl || data.streamUrl || '');
      if (!isHttpUrl(url)) return false;
      try {
        window.chrome.webview.postMessage({
          type: 'external-player',
          player: normalizePlayerName(data.player || data.playerName || '') || 'auto',
          url,
          subtitleUrl: extractHttp(data.subtitleUrl || data.subtitle || ''),
          label: safeText(data.label || data.title || document.title),
          referer: location.href,
          userAgent: navigator.userAgent
        });
        return true;
      } catch (_) { return false; }
    },
    launch(player, url, subtitleUrl) {
      return this.play({ player, url, subtitleUrl });
    }
  });
})();
""";

    public MainWindow()
    {
        InitializeComponent();
        Browser.DefaultBackgroundColor = System.Drawing.Color.FromArgb(5, 7, 12);
        Loaded += MainWindow_Loaded;
        StateChanged += MainWindow_StateChanged;
        Closed += MainWindow_Closed;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _remote = await RemoteConfigService.TryLoadAsync(_config.RemoteConfigUrl);
        ApplyRemoteUi();
        if (_remote?.Maintenance == true)
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
            OfflineOverlay.Visibility = Visibility.Visible;
            OfflineTitle.Text = "بانک مووی موقتاً در دسترس نیست";
            OfflineDescription.Text = string.IsNullOrWhiteSpace(_remote.MaintenanceMessage) ? "در حال انجام به‌روزرسانی هستیم." : _remote.MaintenanceMessage;
            return;
        }
        await InitializeBrowserAsync();
    }

    private void ApplyRemoteUi()
    {
        if (_remote?.Texts is not { } texts) return;
        if (texts.TryGetValue("windows_offline_title", out var title) && !string.IsNullOrWhiteSpace(title)) OfflineTitle.Text = title;
        if (texts.TryGetValue("windows_offline_description", out var description) && !string.IsNullOrWhiteSpace(description)) OfflineDescription.Text = description;
    }

    private async Task InitializeBrowserAsync()
    {
        try
        {
            var dataDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie", "WebView2");
            System.IO.Directory.CreateDirectory(dataDir);
            var environmentOptions = new CoreWebView2EnvironmentOptions
            {
                AdditionalBrowserArguments = "--disable-extensions --disable-component-extensions-with-background-pages --disable-default-apps --disable-sync --no-first-run --disable-features=Translate,MediaRouter"
            };
            var environment = await CoreWebView2Environment.CreateAsync(browserExecutableFolder: null, userDataFolder: dataDir, options: environmentOptions);
            await Browser.EnsureCoreWebView2Async(environment);

            var settings = Browser.CoreWebView2.Settings;
            settings.AreDefaultContextMenusEnabled = false;
            settings.AreDevToolsEnabled = false;
            settings.IsStatusBarEnabled = false;
            settings.IsZoomControlEnabled = true;
            settings.AreBrowserAcceleratorKeysEnabled = true;
            settings.IsBuiltInErrorPageEnabled = false;
            settings.AreHostObjectsAllowed = false;
            settings.IsWebMessageEnabled = true;

            await Browser.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(DesktopBridgeScript);
            Browser.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
            Browser.CoreWebView2.NavigationStarting += CoreWebView2_NavigationStarting;
            Browser.CoreWebView2.NavigationCompleted += CoreWebView2_NavigationCompleted;
            Browser.CoreWebView2.DocumentTitleChanged += (_, _) => Dispatcher.Invoke(() => PageTitle.Text = Browser.CoreWebView2.DocumentTitle ?? "بانک مووی");
            Browser.CoreWebView2.HistoryChanged += (_, _) => Dispatcher.Invoke(UpdateHistoryButtons);
            Browser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
            Browser.CoreWebView2.DownloadStarting += CoreWebView2_DownloadStarting;
            Browser.CoreWebView2.ProcessFailed += (_, _) => Dispatcher.Invoke(ShowOffline);

            _webReady = true;
            Navigate(_config.SiteUrl);
        }
        catch (Exception ex)
        {
            ShowOffline();
            MessageBox.Show("WebView2 راه‌اندازی نشد:\n" + ex.Message, "BankMovie", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var message = JsonSerializer.Deserialize<WebBridgeMessage>(e.WebMessageAsJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (message?.Type != "external-player" || !IsSafeMediaUrl(message.Url)) return;

            var cookieHeader = await GetCookieHeaderAsync(message.Url!);
            var request = new PlayerLaunchRequest
            {
                Url = message.Url!,
                Player = string.IsNullOrWhiteSpace(message.Player) ? "auto" : message.Player,
                SubtitleUrl = IsSafeMediaUrl(message.SubtitleUrl) ? message.SubtitleUrl : null,
                Title = message.Label,
                Referer = IsSafeMediaUrl(message.Referer) ? message.Referer : Browser.Source?.ToString(),
                UserAgent = string.IsNullOrWhiteSpace(message.UserAgent) ? AppVersion.UserAgent : message.UserAgent,
                CookieHeader = cookieHeader
            };

            var result = await Task.Run(() => ExternalPlayerLauncher.Launch(request, _config.ExternalPlayers));
            if (!result.Success)
            {
                MessageBox.Show(result.Error ?? "پلیر خارجی قابل اجرا نبود.", "BankMovie", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("لینک ویدیو قابل ارسال به پلیر نبود.\n" + ex.Message, "BankMovie", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async Task<string?> GetCookieHeaderAsync(string url)
    {
        try
        {
            var cookies = await Browser.CoreWebView2.CookieManager.GetCookiesAsync(url);
            return cookies.Count == 0 ? null : string.Join("; ", cookies.Select(c => $"{c.Name}={c.Value}"));
        }
        catch { return null; }
    }

    private void CoreWebView2_NavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        if (!IsInternalNavigation(e.Uri))
        {
            e.Cancel = true;
            OpenExternal(e.Uri);
            return;
        }

        LoadingOverlay.Visibility = Visibility.Visible;
        OfflineOverlay.Visibility = Visibility.Collapsed;
    }

    private void CoreWebView2_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        if (!e.IsSuccess) ShowOffline();
        else OfflineOverlay.Visibility = Visibility.Collapsed;
        UpdateHistoryButtons();
    }

    private void CoreWebView2_NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (IsInternalNavigation(e.Uri)) Navigate(e.Uri);
        else OpenExternal(e.Uri);
    }

    private void CoreWebView2_DownloadStarting(object? sender, CoreWebView2DownloadStartingEventArgs e)
    {
        try
        {
            var suggested = System.IO.Path.GetFileName(e.ResultFilePath);
            if (string.IsNullOrWhiteSpace(suggested)) suggested = "BankMovie-download";
            var dialog = new SaveFileDialog { FileName = suggested, Title = "ذخیره فایل بانک مووی" };
            if (dialog.ShowDialog(this) == true)
            {
                e.ResultFilePath = dialog.FileName;
                e.Handled = false;
            }
            else e.Cancel = true;
        }
        catch { }
    }

    private void Navigate(string? url)
    {
        if (!_webReady || string.IsNullOrWhiteSpace(url)) return;
        try { Browser.CoreWebView2.Navigate(url); }
        catch { ShowOffline(); }
    }

    private bool IsInternalNavigation(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme is not ("http" or "https")) return false;
        return _config.AllowedHosts.Any(host => string.Equals(uri.Host, host, StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsSafeMediaUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";

    private static void OpenExternal(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return;
        try { Process.Start(new ProcessStartInfo(uri.ToString()) { UseShellExecute = true }); } catch { }
    }

    private void ShowOffline()
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        OfflineOverlay.Visibility = Visibility.Visible;
    }

    private void UpdateHistoryButtons()
    {
        if (!_webReady) return;
        BackButton.IsEnabled = Browser.CoreWebView2.CanGoBack;
        ForwardButton.IsEnabled = Browser.CoreWebView2.CanGoForward;
    }

    private async void MainWindow_StateChanged(object? sender, EventArgs e)
    {
        if (!_webReady || Browser.CoreWebView2 is null) return;

        if (WindowState == WindowState.Minimized)
        {
            if (_webSuspended) return;
            try { _webSuspended = await Browser.CoreWebView2.TrySuspendAsync(); } catch { }
            return;
        }

        if (_webSuspended)
        {
            try { Browser.CoreWebView2.Resume(); } catch { }
            _webSuspended = false;
        }
    }

    private void MainWindow_Closed(object? sender, EventArgs e)
    {
        try { Browser.Dispose(); } catch { }
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleMaximize();
        else if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Back_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoBack) Browser.CoreWebView2.GoBack(); }
    private void Forward_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoForward) Browser.CoreWebView2.GoForward(); }
    private void Reload_Click(object sender, RoutedEventArgs e) { if (_webReady) Browser.CoreWebView2.Reload(); }
    private void Home_Click(object sender, RoutedEventArgs e) => Navigate(_config.HomeUrl);
    private void Retry_Click(object sender, RoutedEventArgs e) => Navigate(_config.SiteUrl);
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void ToggleMaximize() => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
}
