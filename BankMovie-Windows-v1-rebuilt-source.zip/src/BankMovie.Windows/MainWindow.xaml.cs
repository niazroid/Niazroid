using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Input;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace BankMovie.Windows;

public partial class MainWindow : Window
{
    private readonly AppConfig _config = ConfigService.Load();
    private RemoteConfig? _remote;
    private bool _webReady;
    private PlayerWindow? _activePlayer;

    private const string DesktopBridgeScript = """
(() => {
  if (window.__bmWindowsBridgeInstalled) return;
  window.__bmWindowsBridgeInstalled = true;
  window.__BANKMOVIE_WINDOWS_APP__ = Object.freeze({ version: '1', bridge: 1 });
  document.documentElement.classList.add('bm-windows-app');
  const lowEnd = (navigator.hardwareConcurrency || 8) <= 4;
  if (lowEnd) document.documentElement.classList.add('bm-windows-lowend');

  const style = document.createElement('style');
  style.textContent = `
    html.bm-windows-app { scroll-behavior:auto !important; background:#05070c !important; }
    .bm-windows-lowend *, .bm-windows-lowend *::before, .bm-windows-lowend *::after {
      animation-duration:0.01ms !important; animation-iteration-count:1 !important;
      transition-duration:80ms !important; backdrop-filter:none !important; -webkit-backdrop-filter:none !important;
    }
    .bm-windows-app [data-pwa-install],
    .bm-windows-app #installPwaButton,
    .bm-windows-app .pwa-install-button,
    .bm-windows-app .install-app-btn { display:none !important; }
  `;
  document.documentElement.appendChild(style);

  const playSelector = [
    '[data-bm-windows-play]',
    '[data-direct-player="1"][data-url]',
    '.bm-local-play-choice',
    '.bm-download-play-choice',
    '.bm-poster-play',
    '.arc1-play-btn',
    '.arc1-play-inline[data-url]'
  ].join(',');

  const safeText = v => String(v || '').trim();
  const asInt = value => {
    const parsed = Number.parseInt(String(value || ''), 10);
    return Number.isFinite(parsed) ? parsed : null;
  };
  function isHttpUrl(value) {
    try { const u = new URL(value, location.href); return u.protocol === 'http:' || u.protocol === 'https:'; }
    catch (_) { return false; }
  }
  function absolute(value) {
    if (!value) return '';
    try { return new URL(value, location.href).href; } catch (_) { return ''; }
  }
  function nearestText(el, selector) {
    try {
      const row = el.closest('.arc1-link-row,.download-link,.premium-download-card,.movie-detail,.movie-hero,.episode-item,.episode-card');
      const node = row && row.querySelector(selector);
      return node ? safeText(node.textContent).replace(/\s+/g, ' ') : '';
    } catch (_) { return ''; }
  }
  function readContext() {
    try {
      const direct = window.__BM_WINDOWS_PLAYBACK_CONTEXT__ || window.BankMovieWindowsPlayback;
      if (direct && typeof direct === 'object') return direct;
    } catch (_) {}
    try {
      const script = document.querySelector('#bm-windows-playback-context[type="application/json"]');
      if (script?.textContent) return JSON.parse(script.textContent);
    } catch (_) {}
    return {};
  }
  function normalizeEpisode(raw) {
    if (!raw || typeof raw !== 'object') return null;
    const url = absolute(raw.url || raw.playUrl || raw.streamUrl || '');
    if (!isHttpUrl(url)) return null;
    return {
      id: safeText(raw.id || raw.episodeId),
      url,
      subtitleUrl: absolute(raw.subtitleUrl || raw.subtitle || ''),
      title: safeText(raw.title || raw.label),
      seasonNumber: asInt(raw.seasonNumber ?? raw.season),
      episodeNumber: asInt(raw.episodeNumber ?? raw.episode)
    };
  }
  function resolvePlay(target) {
    const context = readContext();
    let url = safeText(target.getAttribute('data-url') || target.getAttribute('data-play-url'));
    if (!url && target.tagName === 'A') url = safeText(target.getAttribute('href'));
    if (!url && typeof window.bmGetCurrentMoviePlayUrl === 'function') {
      try { url = safeText(window.bmGetCurrentMoviePlayUrl()); } catch (_) {}
    }
    url = absolute(url);

    let subtitleUrl = safeText(target.getAttribute('data-subtitle-url'));
    if (!subtitleUrl && url && typeof window.bmFindSubtitleForVideoUrl === 'function') {
      try { subtitleUrl = safeText(window.bmFindSubtitleForVideoUrl(url)); } catch (_) {}
    }
    subtitleUrl = absolute(subtitleUrl);

    let label = safeText(target.getAttribute('data-label'));
    if (!label) label = [nearestText(target,'.quality,.bm-archive2-quality-halo'), nearestText(target,'.download-type-badge')].filter(Boolean).join(' · ');
    if (!label) label = safeText(context.title) || safeText(document.querySelector('h1,.movie-title,.hero-title')?.textContent) || document.title || 'BankMovie Player';

    let rawEpisodes = Array.isArray(context.episodes) ? context.episodes : [];
    if (!rawEpisodes.length) {
      try {
        rawEpisodes = Array.from(document.querySelectorAll('[data-episode][data-url],[data-episode-number][data-play-url]')).map(node => ({
          id: node.getAttribute('data-episode-id') || '',
          url: node.getAttribute('data-url') || node.getAttribute('data-play-url') || '',
          subtitleUrl: node.getAttribute('data-subtitle-url') || '',
          title: node.getAttribute('data-label') || safeText(node.textContent),
          seasonNumber: node.getAttribute('data-season') || node.getAttribute('data-season-number'),
          episodeNumber: node.getAttribute('data-episode') || node.getAttribute('data-episode-number')
        }));
      } catch (_) {}
    }
    const episodes = rawEpisodes.map(normalizeEpisode).filter(Boolean);

    return {
      url, subtitleUrl, label,
      mediaId: safeText(context.mediaId || target.getAttribute('data-media-id')),
      seriesId: safeText(context.seriesId || target.getAttribute('data-series-id')),
      seasonNumber: asInt(target.getAttribute('data-season') || context.seasonNumber || context.season),
      episodeNumber: asInt(target.getAttribute('data-episode') || context.episodeNumber || context.episode),
      episodes
    };
  }
  function sendPlay(target, event) {
    const item = resolvePlay(target);
    if (!isHttpUrl(item.url)) return false;
    event?.preventDefault?.();
    event?.stopPropagation?.();
    event?.stopImmediatePropagation?.();
    try {
      window.chrome.webview.postMessage({
        type: 'play',
        ...item,
        referer: location.href,
        userAgent: navigator.userAgent
      });
      return true;
    } catch (_) { return false; }
  }

  document.addEventListener('click', event => {
    const target = event.target?.closest?.(playSelector);
    if (target) sendPlay(target, event);
  }, true);

  window.BankMovieWindows = Object.freeze({
    version: '1',
    play(payload) {
      try { window.chrome.webview.postMessage({ type:'play', referer:location.href, userAgent:navigator.userAgent, ...(payload || {}) }); return true; }
      catch (_) { return false; }
    }
  });

  window.addEventListener('keydown', event => {
    if (event.ctrlKey && event.key.toLowerCase() === 'l') {
      event.preventDefault();
      window.chrome.webview.postMessage({ type:'open-manual-player' });
    }
  });
})();
""";

    public MainWindow()
    {
        InitializeComponent();
        Browser.DefaultBackgroundColor = System.Drawing.Color.FromArgb(5, 7, 12);
        Loaded += MainWindow_Loaded;
    }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _remote = await RemoteConfigService.TryLoadAsync(_config.RemoteConfigUrl);
        RemoteConfigService.ApplyPlayerOverrides(_config, _remote);
        ApplyRemoteUi();
        if (_remote?.Maintenance == true)
        {
            LoadingOverlay.Visibility = Visibility.Collapsed;
            OfflineOverlay.Visibility = Visibility.Visible;
            OfflineTitle.Text = "بانک مووی موقتاً در دسترس نیست";
            OfflineDescription.Text = string.IsNullOrWhiteSpace(_remote.MaintenanceMessage) ? "در حال انجام به‌روزرسانی هستیم." : _remote.MaintenanceMessage;
            return;
        }
        await InitializeBrowserAsync();
    }

    private void ApplyRemoteUi()
    {
        if (_remote?.Texts is not { } texts) return;
        if (texts.TryGetValue("windows_offline_title", out var title) && !string.IsNullOrWhiteSpace(title)) OfflineTitle.Text = title;
        if (texts.TryGetValue("windows_offline_description", out var description) && !string.IsNullOrWhiteSpace(description)) OfflineDescription.Text = description;
    }

    private async Task InitializeBrowserAsync()
    {
        try
        {
            var dataDir = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie", "WebView2");
            System.IO.Directory.CreateDirectory(dataDir);
            var environment = await CoreWebView2Environment.CreateAsync(userDataFolder: dataDir);
            await Browser.EnsureCoreWebView2Async(environment);

            var settings = Browser.CoreWebView2.Settings;
            settings.AreDefaultContextMenusEnabled = false;
            settings.AreDevToolsEnabled = false;
            settings.IsStatusBarEnabled = false;
            settings.IsZoomControlEnabled = true;
            settings.AreBrowserAcceleratorKeysEnabled = true;
            settings.IsBuiltInErrorPageEnabled = false;

            await Browser.CoreWebView2.AddScriptToExecuteOnDocumentCreatedAsync(DesktopBridgeScript);
            Browser.CoreWebView2.WebMessageReceived += CoreWebView2_WebMessageReceived;
            Browser.CoreWebView2.NavigationStarting += CoreWebView2_NavigationStarting;
            Browser.CoreWebView2.NavigationCompleted += CoreWebView2_NavigationCompleted;
            Browser.CoreWebView2.DocumentTitleChanged += (_, _) => Dispatcher.Invoke(() => PageTitle.Text = Browser.CoreWebView2.DocumentTitle ?? "بانک مووی");
            Browser.CoreWebView2.HistoryChanged += (_, _) => Dispatcher.Invoke(UpdateHistoryButtons);
            Browser.CoreWebView2.NewWindowRequested += CoreWebView2_NewWindowRequested;
            Browser.CoreWebView2.DownloadStarting += CoreWebView2_DownloadStarting;
            Browser.CoreWebView2.ProcessFailed += (_, _) => Dispatcher.Invoke(ShowOffline);

            _webReady = true;
            Navigate(_config.SiteUrl);
        }
        catch (Exception ex)
        {
            ShowOffline();
            MessageBox.Show("WebView2 راه‌اندازی نشد:\n" + ex.Message, "BankMovie", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void CoreWebView2_WebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            var message = JsonSerializer.Deserialize<WebBridgeMessage>(e.WebMessageAsJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            if (message?.Type == "open-manual-player")
            {
                OpenManualPlayer();
                return;
            }
            if (message?.Type != "play" || !IsSafeMediaUrl(message.Url)) return;

            var cookieHeader = await GetCookieHeaderAsync(message.Url!);
            var episodes = (message.Episodes ?? [])
                .Where(x => IsSafeMediaUrl(x.Url))
                .Select(x => new PlaybackEpisode
                {
                    Id = x.Id,
                    Url = x.Url!,
                    SubtitleUrl = IsSafeMediaUrl(x.SubtitleUrl) ? x.SubtitleUrl : null,
                    Title = x.Title,
                    SeasonNumber = x.SeasonNumber,
                    EpisodeNumber = x.EpisodeNumber
                })
                .ToList();

            var currentIndex = episodes.FindIndex(x => string.Equals(x.Url, message.Url, StringComparison.OrdinalIgnoreCase));
            var request = new PlaybackRequest
            {
                Url = message.Url!,
                SubtitleUrl = IsSafeMediaUrl(message.SubtitleUrl) ? message.SubtitleUrl : null,
                Title = message.Label,
                Referer = IsSafeMediaUrl(message.Referer) ? message.Referer : Browser.Source?.ToString(),
                UserAgent = string.IsNullOrWhiteSpace(message.UserAgent) ? AppVersion.UserAgent : message.UserAgent,
                CookieHeader = cookieHeader,
                MediaId = message.MediaId,
                SeriesId = message.SeriesId,
                SeasonNumber = message.SeasonNumber,
                EpisodeNumber = message.EpisodeNumber,
                Episodes = episodes,
                CurrentEpisodeIndex = currentIndex
            };
            OpenPlayer(request);
        }
        catch (Exception ex)
        {
            MessageBox.Show("لینک پخش قابل بازکردن نبود.\n" + ex.Message, "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private async Task<string?> GetCookieHeaderAsync(string url)
    {
        try
        {
            var cookies = await Browser.CoreWebView2.CookieManager.GetCookiesAsync(url);
            return cookies.Count == 0 ? null : string.Join("; ", cookies.Select(c => $"{c.Name}={c.Value}"));
        }
        catch { return null; }
    }

    private void CoreWebView2_NavigationStarting(object? sender, CoreWebView2NavigationStartingEventArgs e)
    {
        LoadingOverlay.Visibility = Visibility.Visible;
        OfflineOverlay.Visibility = Visibility.Collapsed;
        if (!IsInternalNavigation(e.Uri))
        {
            e.Cancel = true;
            OpenExternal(e.Uri);
        }
    }

    private void CoreWebView2_NavigationCompleted(object? sender, CoreWebView2NavigationCompletedEventArgs e)
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        if (!e.IsSuccess) ShowOffline();
        else OfflineOverlay.Visibility = Visibility.Collapsed;
        UpdateHistoryButtons();
    }

    private void CoreWebView2_NewWindowRequested(object? sender, CoreWebView2NewWindowRequestedEventArgs e)
    {
        e.Handled = true;
        if (IsInternalNavigation(e.Uri)) Navigate(e.Uri);
        else OpenExternal(e.Uri);
    }

    private void CoreWebView2_DownloadStarting(object? sender, CoreWebView2DownloadStartingEventArgs e)
    {
        try
        {
            var suggested = System.IO.Path.GetFileName(e.ResultFilePath);
            if (string.IsNullOrWhiteSpace(suggested)) suggested = "BankMovie-download";
            var dialog = new SaveFileDialog { FileName = suggested, Title = "ذخیره فایل بانک مووی" };
            if (dialog.ShowDialog(this) == true)
            {
                e.ResultFilePath = dialog.FileName;
                e.Handled = false;
            }
            else e.Cancel = true;
        }
        catch { }
    }

    private void Navigate(string? url)
    {
        if (!_webReady || string.IsNullOrWhiteSpace(url)) return;
        try { Browser.CoreWebView2.Navigate(url); }
        catch { ShowOffline(); }
    }

    private bool IsInternalNavigation(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return false;
        if (uri.Scheme is not ("http" or "https")) return false;
        return _config.AllowedHosts.Any(host => string.Equals(uri.Host, host, StringComparison.OrdinalIgnoreCase));
    }

    private static bool IsSafeMediaUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";

    private static void OpenExternal(string? value)
    {
        if (!Uri.TryCreate(value, UriKind.Absolute, out var uri)) return;
        try { Process.Start(new ProcessStartInfo(uri.ToString()) { UseShellExecute = true }); } catch { }
    }

    private void OpenPlayer(PlaybackRequest request)
    {
        if (!App.PlayerEngineAvailable)
        {
            MessageBox.Show("موتور پخش داخلی در دسترس نیست.", "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // Never leave multiple native players and a fully-rendering WebView competing
        // for GPU/CPU. This is especially important on integrated/older graphics.
        try { _activePlayer?.Close(); } catch { }
        _activePlayer = new PlayerWindow(request, _config.Player) { Owner = this };
        _activePlayer.Closed += (_, _) =>
        {
            _activePlayer = null;
            ResumeBrowserAfterPlayback();
        };

        SuspendBrowserForPlayback();
        _activePlayer.Show();
        _activePlayer.Activate();
    }

    private async void SuspendBrowserForPlayback()
    {
        if (!_webReady) return;
        try
        {
            Browser.Visibility = Visibility.Hidden;
            await Browser.CoreWebView2.TrySuspendAsync();
        }
        catch { }
    }

    private void ResumeBrowserAfterPlayback()
    {
        if (!_webReady) return;
        try { Browser.CoreWebView2.Resume(); } catch { }
        Browser.Visibility = Visibility.Visible;
    }

    private void OpenManualPlayer()
    {
        var dialog = new OpenMediaWindow { Owner = this };
        if (dialog.ShowDialog() == true && IsSafeMediaUrl(dialog.MediaUrl))
        {
            OpenPlayer(new PlaybackRequest
            {
                Url = dialog.MediaUrl!,
                SubtitleUrl = IsSafeMediaUrl(dialog.SubtitleUrl) ? dialog.SubtitleUrl : null,
                Title = "BankMovie Player",
                Referer = Browser.Source?.ToString(),
                UserAgent = AppVersion.UserAgent
            });
        }
    }

    private void ShowOffline()
    {
        LoadingOverlay.Visibility = Visibility.Collapsed;
        OfflineOverlay.Visibility = Visibility.Visible;
    }

    private void UpdateHistoryButtons()
    {
        if (!_webReady) return;
        BackButton.IsEnabled = Browser.CoreWebView2.CanGoBack;
        ForwardButton.IsEnabled = Browser.CoreWebView2.CanGoForward;
    }

    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleMaximize();
        else if (e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Back_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoBack) Browser.CoreWebView2.GoBack(); }
    private void Forward_Click(object sender, RoutedEventArgs e) { if (_webReady && Browser.CoreWebView2.CanGoForward) Browser.CoreWebView2.GoForward(); }
    private void Reload_Click(object sender, RoutedEventArgs e) { if (_webReady) Browser.CoreWebView2.Reload(); }
    private void Home_Click(object sender, RoutedEventArgs e) => Navigate(_config.HomeUrl);
    private void Retry_Click(object sender, RoutedEventArgs e) => Navigate(_config.SiteUrl);
    private void OpenPlayer_Click(object sender, RoutedEventArgs e) => OpenManualPlayer();
    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void ToggleMaximize() => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
}
