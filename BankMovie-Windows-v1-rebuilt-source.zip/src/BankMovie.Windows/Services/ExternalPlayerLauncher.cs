using System.Diagnostics;
using Microsoft.Win32;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public static class ExternalPlayerLauncher
{
    private static readonly object DetectionLock = new();
    private static readonly Dictionary<string, string?> ExecutableCache = new(StringComparer.OrdinalIgnoreCase);

    private sealed record PlayerSpec(
        string Id,
        string DisplayName,
        string[] ExecutableNames,
        string[] CommonPaths);

    private static readonly PlayerSpec[] Specs =
    [
        new("potplayer", "PotPlayer", ["PotPlayerMini64.exe", "PotPlayerMini.exe"],
        [
            @"DAUM\PotPlayer\PotPlayerMini64.exe",
            @"DAUM\PotPlayer\PotPlayerMini.exe",
            @"PotPlayer\PotPlayerMini64.exe",
            @"PotPlayer\PotPlayerMini.exe"
        ]),
        new("vlc", "VLC", ["vlc.exe"],
        [
            @"VideoLAN\VLC\vlc.exe",
            @"Programs\VideoLAN\VLC\vlc.exe",
            @"VLC\vlc.exe"
        ]),
        new("mpv", "mpv", ["mpv.exe"],
        [
            @"mpv\mpv.exe"
        ]),
        new("mpc-hc", "MPC-HC", ["mpc-hc64.exe", "mpc-hc.exe"],
        [
            @"MPC-HC\mpc-hc64.exe",
            @"MPC-HC\mpc-hc.exe"
        ]),
        new("mpc-be", "MPC-BE", ["mpc-be64.exe", "mpc-be.exe"],
        [
            @"MPC-BE x64\mpc-be64.exe",
            @"MPC-BE\mpc-be64.exe",
            @"MPC-BE\mpc-be.exe"
        ]),
        new("kmplayer", "KMPlayer", ["KMPlayer64.exe", "KMPlayer.exe", "KMP64.exe"],
        [
            @"KMPlayer 64X\KMPlayer64.exe",
            @"KMPlayer 64X\KMPlayer.exe",
            @"The KMPlayer\KMPlayer.exe",
            @"KMPlayer\KMPlayer.exe",
            @"KMPlayer\KMPlayer64.exe",
            @"PandoraTV\KMPlayer\KMPlayer.exe"
        ]),
        new("smplayer", "SMPlayer", ["smplayer.exe"],
        [
            @"SMPlayer\smplayer.exe"
        ]),
        new("gom", "GOM Player", ["GOM.exe", "GOM64.exe"],
        [
            @"GRETECH\GomPlayer\GOM.exe",
            @"GOM\GOMPlayer\GOM64.exe"
        ]),
        new("wmp", "Windows Media Player", ["wmplayer.exe"],
        [
            @"Windows Media Player\wmplayer.exe"
        ])
    ];

    private static readonly string[] DefaultPriority =
    [
        "vlc", "potplayer", "mpv", "mpc-hc", "mpc-be", "kmplayer", "smplayer", "gom", "wmp"
    ];

    public static PlayerLaunchResult Launch(PlayerLaunchRequest request, ExternalPlayerConfig? config = null)
    {
        if (!IsHttpUrl(request.Url))
            return PlayerLaunchResult.Failed("لینک ویدیو معتبر نیست.");

        config ??= new ExternalPlayerConfig();
        var requested = NormalizePlayerId(request.Player);
        var candidates = BuildCandidateOrder(requested, config);

        foreach (var playerId in candidates)
        {
            var spec = Specs.FirstOrDefault(x => x.Id == playerId);
            if (spec is null) continue;

            var executable = FindExecutableCached(spec);
            if (string.IsNullOrWhiteSpace(executable)) continue;

            try
            {
                var psi = BuildStartInfo(spec, executable, request);
                var process = Process.Start(psi);
                if (process is not null)
                {
                    return PlayerLaunchResult.Ok(spec.Id, spec.DisplayName, requested != "auto" && requested != spec.Id);
                }
            }
            catch
            {
                // Try the next installed player. One broken player must not block playback.
            }
        }

        if (requested != "auto")
        {
            var selected = Specs.FirstOrDefault(x => x.Id == requested);
            return PlayerLaunchResult.Failed($"{selected?.DisplayName ?? requested} روی ویندوز پیدا نشد یا قابل اجرا نیست.");
        }

        return PlayerLaunchResult.Failed(
            "هیچ پلیر خارجی سازگار روی ویندوز پیدا نشد. VLC، PotPlayer، KMPlayer، MPC-HC/MPC-BE یا mpv را نصب کن.");
    }

    public static IReadOnlyList<DetectedExternalPlayer> DetectInstalled()
    {
        var list = new List<DetectedExternalPlayer>();
        foreach (var spec in Specs)
        {
            var path = FindExecutable(spec);
            if (!string.IsNullOrWhiteSpace(path))
                list.Add(new DetectedExternalPlayer(spec.Id, spec.DisplayName, path));
        }
        return list;
    }

    private static IReadOnlyList<string> BuildCandidateOrder(string requested, ExternalPlayerConfig config)
    {
        var priority = (config.Priority ?? [])
            .Select(NormalizePlayerId)
            .Where(x => x != "auto" && Specs.Any(s => s.Id == x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (priority.Count == 0) priority.AddRange(DefaultPriority);

        var result = new List<string>();
        var explicitSelection = requested != "auto" && Specs.Any(s => s.Id == requested);
        if (explicitSelection) result.Add(requested);

        if (!explicitSelection || config.FallbackForExplicitSelection)
        {
            if (config.FallbackToAnyInstalled || requested == "auto") result.AddRange(priority);
            result.AddRange(DefaultPriority);
        }

        return result.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    public static string NormalizePlayerId(string? value)
    {
        var raw = (value ?? string.Empty).Trim().ToLowerInvariant();
        if (raw.Length == 0) return "auto";

        raw = raw.Replace("_", "-").Replace(" ", "-");
        if (raw.Contains("potplayer") || raw is "pot") return "potplayer";
        if (raw.Contains("vlc")) return "vlc";
        if (raw.Contains("kmplayer") || raw is "km-player" or "km") return "kmplayer";
        if (raw.Contains("mpc-hc") || raw.Contains("mpchc")) return "mpc-hc";
        if (raw.Contains("mpc-be") || raw.Contains("mpcbe")) return "mpc-be";
        if (raw is "mpv" || raw.Contains("mpv-player")) return "mpv";
        if (raw.Contains("smplayer")) return "smplayer";
        if (raw.Contains("gom")) return "gom";
        if (raw.Contains("windows-media") || raw.Contains("wmplayer") || raw is "wmp") return "wmp";

        // MX Player has no native Windows desktop edition. Route its website button
        // to the user's first installed Windows player instead of opening a dead URI.
        if (raw.Contains("mxplayer") || raw.Contains("mx-player") || raw == "mx") return "auto";

        // Internal/BankMovie player requests are intentionally redirected to an
        // installed external player. V1 no longer ships an internal media engine.
        if (raw.Contains("internal") || raw.Contains("bankmovie")) return "auto";
        return "auto";
    }

    private static ProcessStartInfo BuildStartInfo(PlayerSpec spec, string executable, PlayerLaunchRequest request)
    {
        var psi = new ProcessStartInfo
        {
            FileName = executable,
            UseShellExecute = false,
            WorkingDirectory = System.IO.Path.GetDirectoryName(executable) ?? string.Empty
        };

        switch (spec.Id)
        {
            case "vlc":
                psi.ArgumentList.Add("--started-from-file");
                if (!string.IsNullOrWhiteSpace(request.Referer)) psi.ArgumentList.Add($"--http-referrer={request.Referer}");
                if (!string.IsNullOrWhiteSpace(request.UserAgent)) psi.ArgumentList.Add($"--http-user-agent={request.UserAgent}");
                if (IsHttpUrl(request.SubtitleUrl)) psi.ArgumentList.Add($"--sub-file={request.SubtitleUrl}");
                psi.ArgumentList.Add(request.Url);
                break;

            case "mpv":
                psi.ArgumentList.Add("--force-window=yes");
                if (!string.IsNullOrWhiteSpace(request.Referer)) psi.ArgumentList.Add($"--referrer={request.Referer}");
                if (!string.IsNullOrWhiteSpace(request.UserAgent)) psi.ArgumentList.Add($"--user-agent={request.UserAgent}");
                if (!string.IsNullOrWhiteSpace(request.CookieHeader)) psi.ArgumentList.Add($"--http-header-fields=Cookie: {request.CookieHeader}");
                if (IsHttpUrl(request.SubtitleUrl)) psi.ArgumentList.Add($"--sub-file={request.SubtitleUrl}");
                psi.ArgumentList.Add("--");
                psi.ArgumentList.Add(request.Url);
                break;

            case "mpc-hc":
            case "mpc-be":
                psi.ArgumentList.Add("/play");
                psi.ArgumentList.Add(request.Url);
                break;

            default:
                psi.ArgumentList.Add(request.Url);
                break;
        }

        return psi;
    }

    private static string? FindExecutableCached(PlayerSpec spec)
    {
        lock (DetectionLock)
        {
            if (ExecutableCache.TryGetValue(spec.Id, out var cached)) return cached;
        }

        var detected = FindExecutable(spec);
        lock (DetectionLock) ExecutableCache[spec.Id] = detected;
        return detected;
    }

    private static string? FindExecutable(PlayerSpec spec)
    {
        foreach (var exeName in spec.ExecutableNames)
        {
            var appPath = FindAppPath(exeName);
            if (IsExecutableFile(appPath)) return appPath;
        }

        var fromUninstall = FindFromUninstallRegistry(spec);
        if (IsExecutableFile(fromUninstall)) return fromUninstall;

        foreach (var root in ProgramRoots())
        {
            foreach (var relative in spec.CommonPaths)
            {
                var candidate = System.IO.Path.Combine(root, relative);
                if (IsExecutableFile(candidate)) return candidate;
            }
        }

        foreach (var exeName in spec.ExecutableNames)
        {
            var fromPath = FindOnPath(exeName);
            if (IsExecutableFile(fromPath)) return fromPath;
        }

        return null;
    }

    private static string? FindAppPath(string exeName)
    {
        var hives = new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine };
        var views = Environment.Is64BitOperatingSystem
            ? new[] { RegistryView.Registry64, RegistryView.Registry32 }
            : new[] { RegistryView.Registry32 };

        foreach (var hive in hives)
        {
            foreach (var view in views)
            {
                try
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var key = baseKey.OpenSubKey($@"SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\{exeName}");
                    var value = key?.GetValue(null) as string;
                    value = value?.Trim().Trim('"');
                    if (IsExecutableFile(value)) return value;
                }
                catch { }
            }
        }
        return null;
    }

    private static string? FindFromUninstallRegistry(PlayerSpec spec)
    {
        var nameNeedles = spec.Id switch
        {
            "vlc" => new[] { "vlc media player", "videolan vlc", "vlc" },
            "kmplayer" => new[] { "kmplayer", "the kmplayer" },
            "potplayer" => new[] { "potplayer" },
            _ => Array.Empty<string>()
        };
        if (nameNeedles.Length == 0) return null;

        var hives = new[] { RegistryHive.CurrentUser, RegistryHive.LocalMachine };
        var views = Environment.Is64BitOperatingSystem
            ? new[] { RegistryView.Registry64, RegistryView.Registry32 }
            : new[] { RegistryView.Registry32 };

        foreach (var hive in hives)
        {
            foreach (var view in views)
            {
                try
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var uninstall = baseKey.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall");
                    if (uninstall is null) continue;

                    foreach (var subName in uninstall.GetSubKeyNames())
                    {
                        using var sub = uninstall.OpenSubKey(subName);
                        var displayName = (sub?.GetValue("DisplayName") as string ?? string.Empty).Trim().ToLowerInvariant();
                        if (!nameNeedles.Any(n => displayName.Contains(n, StringComparison.OrdinalIgnoreCase))) continue;

                        var displayIcon = (sub?.GetValue("DisplayIcon") as string ?? string.Empty).Trim();
                        var iconExe = CleanDisplayIconPath(displayIcon);
                        if (IsExecutableFile(iconExe) && spec.ExecutableNames.Any(n => string.Equals(System.IO.Path.GetFileName(iconExe), n, StringComparison.OrdinalIgnoreCase)))
                            return iconExe;

                        var installLocation = (sub?.GetValue("InstallLocation") as string ?? string.Empty).Trim().Trim('"');
                        if (System.IO.Directory.Exists(installLocation))
                        {
                            foreach (var exeName in spec.ExecutableNames)
                            {
                                var direct = System.IO.Path.Combine(installLocation, exeName);
                                if (IsExecutableFile(direct)) return direct;
                            }
                        }
                    }
                }
                catch { }
            }
        }
        return null;
    }

    private static string? CleanDisplayIconPath(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return null;
        var text = value.Trim();
        if (text.StartsWith('"'))
        {
            var end = text.IndexOf('"', 1);
            if (end > 1) return text[1..end];
        }
        var comma = text.LastIndexOf(',');
        if (comma > 2) text = text[..comma];
        return text.Trim().Trim('"');
    }

    private static IEnumerable<string> ProgramRoots()
    {
        var roots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var folder in new[]
                 {
                     Environment.SpecialFolder.ProgramFiles,
                     Environment.SpecialFolder.ProgramFilesX86,
                     Environment.SpecialFolder.LocalApplicationData
                 })
        {
            var path = Environment.GetFolderPath(folder);
            if (!string.IsNullOrWhiteSpace(path)) roots.Add(path);
        }
        return roots;
    }

    private static string? FindOnPath(string executable)
    {
        var pathValue = Environment.GetEnvironmentVariable("PATH") ?? string.Empty;
        foreach (var part in pathValue.Split(System.IO.Path.PathSeparator, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            try
            {
                var candidate = System.IO.Path.Combine(part.Trim('"'), executable);
                if (System.IO.File.Exists(candidate)) return candidate;
            }
            catch { }
        }
        return null;
    }

    private static bool IsExecutableFile(string? value) =>
        !string.IsNullOrWhiteSpace(value)
        && value.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)
        && System.IO.File.Exists(value);

    private static bool IsHttpUrl(string? value) =>
        Uri.TryCreate(value, UriKind.Absolute, out var uri) && uri.Scheme is "http" or "https";
}
