using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public sealed class PlayerPreferencesStore
{
    private readonly string _path;
    private readonly object _gate = new();

    public PlayerPreferencesStore()
    {
        var root = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie");
        System.IO.Directory.CreateDirectory(root);
        _path = System.IO.Path.Combine(root, "player-preferences.json");
    }

    public PlayerPreferences Load(PlayerConfig defaults)
    {
        PlayerPreferences value;
        var loaded = false;
        lock (_gate)
        {
            try
            {
                if (System.IO.File.Exists(_path))
                {
                    value = JsonSerializer.Deserialize<PlayerPreferences>(System.IO.File.ReadAllText(_path)) ?? new PlayerPreferences();
                    loaded = true;
                }
                else value = new PlayerPreferences();
            }
            catch
            {
                value = new PlayerPreferences();
            }
        }

        if (!loaded)
        {
            value.HardwareDecoding = defaults.HardwareDecoding;
            value.SeekSeconds = defaults.SeekSeconds;
            value.AutoNextEpisode = defaults.AutoNextEpisode;
            value.LowEndMode = string.Equals(defaults.PerformancePreset, "low", StringComparison.OrdinalIgnoreCase)
                               || (string.Equals(defaults.PerformancePreset, "auto", StringComparison.OrdinalIgnoreCase) && Environment.ProcessorCount <= 4);
        }
        return Normalize(value);
    }

    public void Save(PlayerPreferences value)
    {
        value = Normalize(value);
        lock (_gate)
        {
            try
            {
                var temp = _path + ".tmp";
                System.IO.File.WriteAllText(temp, JsonSerializer.Serialize(value, new JsonSerializerOptions { WriteIndented = true }));
                System.IO.File.Move(temp, _path, true);
            }
            catch
            {
                // Playback must never fail because preferences could not be persisted.
            }
        }
    }

    private static PlayerPreferences Normalize(PlayerPreferences value)
    {
        value.Volume = Math.Clamp(value.Volume, 0, 100);
        value.PlaybackRate = Math.Clamp(value.PlaybackRate, 0.5, 2.0);
        value.SeekSeconds = Math.Clamp(value.SeekSeconds, 5, 60);
        value.SubtitleFontSize = Math.Clamp(value.SubtitleFontSize, 16, 64);
        value.SubtitleOutlineThickness = Math.Clamp(value.SubtitleOutlineThickness, 0, 6);
        value.SubtitleBackgroundOpacity = Math.Clamp(value.SubtitleBackgroundOpacity, 0, 220);
        value.SubtitleMargin = Math.Clamp(value.SubtitleMargin, 0, 180);
        value.SubtitleDelayMs = Math.Clamp(value.SubtitleDelayMs, -10_000, 10_000);
        if (string.IsNullOrWhiteSpace(value.SubtitleColor)) value.SubtitleColor = "#FFFFFF";
        return value;
    }
}
