using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public static class ConfigService
{
    public static AppConfig Load()
    {
        try
        {
            var path = System.IO.Path.Combine(AppContext.BaseDirectory, "appsettings.json");
            if (!System.IO.File.Exists(path)) return new AppConfig();
            var json = System.IO.File.ReadAllText(path);
            return JsonSerializer.Deserialize<AppConfig>(json, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }) ?? new AppConfig();
        }
        catch
        {
            return new AppConfig();
        }
    }
}
