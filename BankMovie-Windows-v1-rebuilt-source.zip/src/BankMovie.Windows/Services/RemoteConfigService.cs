using System.Net.Http;
using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public static class RemoteConfigService
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(3.5) };

    public static async Task<RemoteConfig?> TryLoadAsync(string? url, CancellationToken cancellationToken = default)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return null;
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, uri);
            request.Headers.TryAddWithoutValidation("User-Agent", AppVersion.UserAgent);
            using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            if (!response.IsSuccessStatusCode) return null;
            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            return await JsonSerializer.DeserializeAsync<RemoteConfig>(stream, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }, cancellationToken);
        }
        catch
        {
            return null;
        }
    }
}
