using System.Net.Http;
using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public static class RemoteConfigService
{
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(3.5) };

    public static async Task<RemoteConfig?> TryLoadAsync(string? url, CancellationToken cancellationToken = default)
    {
        if (!Uri.TryCreate(url, UriKind.Absolute, out var uri) || uri.Scheme is not ("http" or "https")) return null;
        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Get, uri);
            request.Headers.TryAddWithoutValidation("User-Agent", AppVersion.UserAgent);
            using var response = await Http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
            if (!response.IsSuccessStatusCode) return null;
            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            return await JsonSerializer.DeserializeAsync<RemoteConfig>(stream, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }, cancellationToken);
        }
        catch
        {
            return null;
        }
    }

    public static void ApplyPlayerOverrides(AppConfig config, RemoteConfig? remote)
    {
        if (remote?.Player is not { } player) return;
        if (player.NetworkCachingMs is > 250 and < 20_000) config.Player.NetworkCachingMs = player.NetworkCachingMs.Value;
        if (player.SeekSeconds is >= 5 and <= 60) config.Player.SeekSeconds = player.SeekSeconds.Value;
        if (player.HardwareDecoding.HasValue) config.Player.HardwareDecoding = player.HardwareDecoding.Value;
        if (player.AutoNextEpisode.HasValue) config.Player.AutoNextEpisode = player.AutoNextEpisode.Value;
        if (player.LowEndMode.HasValue) config.Player.PerformancePreset = player.LowEndMode.Value ? "low" : "auto";
    }
}
