using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Threading;
using BankMovie.Windows.Models;
using BankMovie.Windows.Services;
using LibVLCSharp.Shared;
using Microsoft.Win32;

namespace BankMovie.Windows;

public partial class PlayerWindow : Window
{
    private PlaybackRequest _request;
    private readonly PlayerConfig _config;
    private readonly PlaybackHistoryStore _history = new();
    private readonly PlayerPreferencesStore _preferencesStore = new();
    private PlayerPreferences _preferences;

    private readonly DispatcherTimer _uiTimer;
    private readonly DispatcherTimer _hideControlsTimer;
    private readonly DispatcherTimer _hudTimer;

    private LibVLC? _engine;
    private MediaPlayer? _mediaPlayer;
    private Media? _media;
    private bool _draggingProgress;
    private bool _isFullscreen;
    private bool _restoredPosition;
    private bool _providedSubtitleAdded;
    private bool _suppressSettingsEvents;
    private bool _suppressEpisodeSelection;
    private long _lastHistorySave;
    private long _lastTrackRefreshTick;
    private long _lastBufferUiTick;
    private long _pendingSeekMs;
    private bool _pendingResumePlaying;
    private string _lastTrackSignature = "";

    private sealed record RateChoice(string Label, double Value)
    {
        public override string ToString() => Label;
    }

    private sealed record ColorChoice(string Label, string Hex)
    {
        public override string ToString() => Label;
    }

    private sealed record EpisodeListItem(int Index, string Label)
    {
        public override string ToString() => Label;
    }

    public PlayerWindow(PlaybackRequest request, PlayerConfig config)
    {
        _request = request;
        _config = config;
        _preferences = _preferencesStore.Load(config);
        _suppressSettingsEvents = true;
        InitializeComponent();

        _uiTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(_preferences.LowEndMode ? 1000 : 500) };
        _uiTimer.Tick += UiTimer_Tick;
        _hideControlsTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2.8) };
        _hideControlsTimer.Tick += (_, _) => HideControls();
        _hudTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(900) };
        _hudTimer.Tick += (_, _) =>
        {
            _hudTimer.Stop();
            CenterHud.Visibility = Visibility.Collapsed;
        };

        InitializeSettingsUi();
        UpdateRequestUi();
        Loaded += PlayerWindow_Loaded;
    }

    private void InitializeSettingsUi()
    {
        _suppressSettingsEvents = true;
        SpeedCombo.ItemsSource = new[]
        {
            new RateChoice("0.5×", 0.5), new RateChoice("0.75×", 0.75), new RateChoice("1×", 1.0),
            new RateChoice("1.25×", 1.25), new RateChoice("1.5×", 1.5), new RateChoice("1.75×", 1.75), new RateChoice("2×", 2.0)
        };
        SpeedCombo.SelectedItem = ((IEnumerable<RateChoice>)SpeedCombo.ItemsSource).OrderBy(x => Math.Abs(x.Value - _preferences.PlaybackRate)).First();

        SubtitleColorCombo.ItemsSource = new[]
        {
            new ColorChoice("سفید", "#FFFFFF"),
            new ColorChoice("زرد سینمایی", "#FFD85A"),
            new ColorChoice("آبی روشن", "#9ED7FF"),
            new ColorChoice("سبز روشن", "#A8F0B5"),
            new ColorChoice("صورتی روشن", "#FFB7DD")
        };
        SubtitleColorCombo.SelectedItem = ((IEnumerable<ColorChoice>)SubtitleColorCombo.ItemsSource)
            .FirstOrDefault(x => string.Equals(x.Hex, _preferences.SubtitleColor, StringComparison.OrdinalIgnoreCase))
            ?? ((IEnumerable<ColorChoice>)SubtitleColorCombo.ItemsSource).First();

        SubtitleDelaySlider.Value = _preferences.SubtitleDelayMs;
        SubtitleSizeSlider.Value = _preferences.SubtitleFontSize;
        SubtitleOutlineSlider.Value = _preferences.SubtitleOutlineThickness;
        SubtitleBackgroundSlider.Value = _preferences.SubtitleBackgroundOpacity;
        SubtitleMarginSlider.Value = _preferences.SubtitleMargin;
        HardwareDecodeCheck.IsChecked = _preferences.HardwareDecoding;
        LowEndModeCheck.IsChecked = _preferences.LowEndMode;
        AutoNextCheck.IsChecked = _preferences.AutoNextEpisode;
        AlwaysOnTopCheck.IsChecked = _preferences.AlwaysOnTop;
        Topmost = _preferences.AlwaysOnTop;
        VolumeSlider.Value = _preferences.Volume;
        _suppressSettingsEvents = false;
        RefreshSettingsLabels();
    }

    private void RefreshSettingsLabels()
    {
        VolumeText.Text = $"{_preferences.Volume}%";
        SubtitleDelayText.Text = $"{_preferences.SubtitleDelayMs:+#;-#;0} ms";
        SubtitleSizeText.Text = _preferences.SubtitleFontSize.ToString();
    }

    private void PlayerWindow_Loaded(object sender, RoutedEventArgs e)
    {
        if (!App.PlayerEngineAvailable)
        {
            StatusText.Text = "موتور پخش در دسترس نیست";
            return;
        }
        ShowVideoPlaceholder("در حال آماده‌سازی پخش", "اتصال امن به سرور ویدیو…");
        StartPlayback();
        _uiTimer.Start();
        ShowControls();
    }

    private void StartPlayback(long seekToMs = 0, bool resumePlaying = true)
    {
        ShowVideoPlaceholder("در حال آماده‌سازی پخش", "در حال دریافت اطلاعات استریم…");
        DisposePlaybackEngine();

        _restoredPosition = seekToMs > 0;
        _providedSubtitleAdded = false;
        _lastTrackSignature = "";
        _pendingSeekMs = Math.Max(0, seekToMs);
        _pendingResumePlaying = resumePlaying;
        _lastHistorySave = 0;

        try
        {
            _engine = App.CreatePlayerEngine(_preferences, _config);
            _mediaPlayer = new MediaPlayer(_engine)
            {
                EnableHardwareDecoding = _preferences.HardwareDecoding,
                NetworkCaching = _config.NetworkCachingMs,
                Volume = _preferences.Volume,
                EnableKeyInput = false,
                EnableMouseInput = false
            };
            VideoView.MediaPlayer = _mediaPlayer;

            _mediaPlayer.Opening += (_, _) => Dispatcher.BeginInvoke(() =>
            {
                StatusText.Text = "در حال اتصال به ویدیو…";
                ShowVideoPlaceholder("در حال اتصال", "سرور ویدیو در حال پاسخ‌گویی است…");
            });
            _mediaPlayer.Playing += (_, _) => Dispatcher.BeginInvoke(() =>
            {
                StatusText.Text = "در حال پخش";
                HideVideoPlaceholder();
            });
            _mediaPlayer.EncounteredError += (_, _) => Dispatcher.BeginInvoke(() =>
            {
                StatusText.Text = "خطا در پخش؛ لینک یا اتصال را بررسی کن";
                ShowVideoPlaceholder("پخش شروع نشد", "این لینک برای پلیر داخلی قابل خواندن نبود یا سرور پاسخ نداد.", true);
            });
            _mediaPlayer.Buffering += (_, args) =>
            {
                var now = Environment.TickCount64;
                if (now - _lastBufferUiTick < 350 && args.Cache < 100) return;
                _lastBufferUiTick = now;
                Dispatcher.BeginInvoke(() =>
                {
                    StatusText.Text = args.Cache >= 100 ? "در حال پخش" : $"در حال بافر… {args.Cache:0}%";
                    if (args.Cache < 100 && VideoPlaceholder.Visibility == Visibility.Visible)
                    {
                        VideoPlaceholderTitle.Text = "در حال بافر";
                        VideoPlaceholderDetail.Text = $"{args.Cache:0}%";
                    }
                });
            };
            _mediaPlayer.EndReached += (_, _) => Dispatcher.BeginInvoke(HandleEndReached);

            _media = new Media(_engine, new Uri(_request.Url));
            _media.AddOption($":network-caching={_config.NetworkCachingMs}");
            _media.AddOption(":file-caching=900");
            _media.AddOption(":no-video-title-show");
            if (!string.IsNullOrWhiteSpace(_request.Referer)) _media.AddOption(":http-referrer=" + _request.Referer);
            if (!string.IsNullOrWhiteSpace(_request.UserAgent)) _media.AddOption(":http-user-agent=" + _request.UserAgent);
            if (!string.IsNullOrWhiteSpace(_request.CookieHeader)) _media.AddOption(":http-cookie=" + _request.CookieHeader);

            if (!_mediaPlayer.Play(_media))
            {
                StatusText.Text = "پخش شروع نشد";
                ShowVideoPlaceholder("پخش شروع نشد", "موتور پخش نتوانست این لینک را باز کند.", true);
            }
            else StatusText.Text = "در حال اتصال به ویدیو…";

            ApplyPlaybackRate(_preferences.PlaybackRate);
            ApplySubtitleDelay(_preferences.SubtitleDelayMs);
        }
        catch (Exception ex)
        {
            StatusText.Text = "راه‌اندازی پلیر ناموفق بود";
            ShowVideoPlaceholder("خطای پلیر", "موتور پخش راه‌اندازی نشد.", true);
            MessageBox.Show("پلیر داخلی راه‌اندازی نشد.\n" + ex.Message, "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void UiTimer_Tick(object? sender, EventArgs e)
    {
        var mp = _mediaPlayer;
        if (mp is null) return;

        var length = Math.Max(0, mp.Length);
        var time = Math.Max(0, mp.Time);

        if (_pendingSeekMs > 0 && length > 0)
        {
            var target = Math.Min(_pendingSeekMs, Math.Max(0, length - 1000));
            mp.Time = target;
            if (!_pendingResumePlaying) mp.SetPause(true);
            _pendingSeekMs = 0;
        }

        if (!_draggingProgress)
        {
            ProgressSlider.Maximum = Math.Max(1, length);
            ProgressSlider.Value = Math.Min(time, ProgressSlider.Maximum);
        }

        CurrentTimeText.Text = FormatTime(time);
        DurationText.Text = FormatTime(length);
        PlayPauseButton.Content = mp.IsPlaying ? "❚❚" : "▶";
        MuteButton.Content = mp.Mute || mp.Volume == 0 ? "🔇" : "🔊";
        if (mp.IsPlaying) StatusText.Text = "در حال پخش";
        else if (mp.State == VLCState.Paused) StatusText.Text = "توقف موقت";

        TryRestorePosition(mp, length);
        TryAddProvidedSubtitle(mp);
        var now = Environment.TickCount64;
        var trackRefreshEvery = _preferences.LowEndMode ? 4000 : 2200;
        if (now - _lastTrackRefreshTick >= trackRefreshEvery)
        {
            _lastTrackRefreshTick = now;
            RefreshTracks(mp);
        }
        SaveHistoryIfNeeded(mp, length, time);
    }

    private void TryRestorePosition(MediaPlayer mp, long length)
    {
        if (_restoredPosition || !_config.RememberPosition || length <= 0 || mp.Time < 0) return;
        _restoredPosition = true;
        var saved = _history.Get(_request.Url);
        if (saved > 15_000 && saved < length * 0.95)
        {
            mp.Time = saved;
            ShowHud("ادامه از", FormatTime(saved));
        }
    }

    private void TryAddProvidedSubtitle(MediaPlayer mp)
    {
        if (_providedSubtitleAdded || !_config.AutoLoadProvidedSubtitle || string.IsNullOrWhiteSpace(_request.SubtitleUrl)) return;
        if (mp.State is not (VLCState.Playing or VLCState.Paused)) return;
        _providedSubtitleAdded = true;
        try
        {
            if (mp.AddSlave(MediaSlaveType.Subtitle, _request.SubtitleUrl!, true))
            {
                _lastTrackSignature = "";
                ShowHud("زیرنویس", "فعال شد");
            }
        }
        catch
        {
            StatusText.Text = "زیرنویس خارجی بارگذاری نشد";
        }
    }

    private void RefreshTracks(MediaPlayer mp)
    {
        try
        {
            var subtitles = mp.SpuDescription ?? [];
            var audio = mp.AudioTrackDescription ?? [];
            var signature = string.Join('|', subtitles.Select(x => $"s{x.Id}:{x.Name}")) + "#" + string.Join('|', audio.Select(x => $"a{x.Id}:{x.Name}"));
            if (signature == _lastTrackSignature) return;
            _lastTrackSignature = signature;

            var selectedSpu = mp.Spu;
            var selectedAudio = mp.AudioTrack;
            _suppressSettingsEvents = true;
            SubtitleCombo.ItemsSource = subtitles.Select(x => new TrackChoice(x.Id, NormalizeTrackName(x.Name, x.Id == -1 ? "زیرنویس خاموش" : $"زیرنویس {x.Id}"))).ToList();
            AudioCombo.ItemsSource = audio.Select(x => new TrackChoice(x.Id, NormalizeTrackName(x.Name, $"صدا {x.Id}"))).ToList();
            SubtitleCombo.SelectedItem = ((IEnumerable<TrackChoice>)SubtitleCombo.ItemsSource).FirstOrDefault(x => x.Id == selectedSpu);
            AudioCombo.SelectedItem = ((IEnumerable<TrackChoice>)AudioCombo.ItemsSource).FirstOrDefault(x => x.Id == selectedAudio);
            _suppressSettingsEvents = false;
        }
        catch
        {
            _suppressSettingsEvents = false;
        }
    }

    private void SaveHistoryIfNeeded(MediaPlayer mp, long length, long time)
    {
        if (!_config.RememberPosition || length <= 0 || time <= 0) return;
        if (Math.Abs(time - _lastHistorySave) < 5_000) return;
        _lastHistorySave = time;
        if (time >= length * 0.95) _history.Clear(_request.Url);
        else _history.Set(_request.Url, time);
    }

    private void HandleEndReached()
    {
        _history.Clear(_request.Url);
        PlayPauseButton.Content = "▶";
        StatusText.Text = "پخش تمام شد";
        if (_preferences.AutoNextEpisode && CanGoNextEpisode())
        {
            ShowHud("قسمت بعد", "در حال پخش");
            PlayEpisode(_request.CurrentEpisodeIndex + 1);
        }
    }

    private void PlayPause_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        _mediaPlayer.SetPause(_mediaPlayer.IsPlaying);
        ShowControls();
    }

    private void SeekBack_Click(object sender, RoutedEventArgs e) => SeekBy(-_preferences.SeekSeconds * 1000L);
    private void SeekForward_Click(object sender, RoutedEventArgs e) => SeekBy(_preferences.SeekSeconds * 1000L);

    private void SeekBy(long delta)
    {
        if (_mediaPlayer is null) return;
        var target = Math.Clamp(_mediaPlayer.Time + delta, 0, Math.Max(0, _mediaPlayer.Length));
        _mediaPlayer.Time = target;
        ShowHud(delta < 0 ? "عقب" : "جلو", $"{Math.Abs(delta) / 1000} ثانیه");
        ShowControls();
    }

    private void Mute_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        _mediaPlayer.Mute = !_mediaPlayer.Mute;
        ShowHud("صدا", _mediaPlayer.Mute ? "خاموش" : $"{_mediaPlayer.Volume}%");
    }

    private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_suppressSettingsEvents) return;
        var value = Math.Clamp((int)e.NewValue, 0, 100);
        VolumeText.Text = $"{value}%";
        _preferences.Volume = value;
        if (_mediaPlayer is not null) _mediaPlayer.Volume = value;
        SavePreferences();
    }

    private void SpeedCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSettingsEvents || SpeedCombo.SelectedItem is not RateChoice rate) return;
        _preferences.PlaybackRate = rate.Value;
        ApplyPlaybackRate(rate.Value);
        SavePreferences();
        ShowHud("سرعت", rate.Label);
    }

    private void ApplyPlaybackRate(double rate)
    {
        var mp = _mediaPlayer;
        if (mp is null) return;
        InvokeOptional(mp, "SetRate", (float)Math.Clamp(rate, 0.5, 2.0));
    }

    private void AudioCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSettingsEvents || _mediaPlayer is null || AudioCombo.SelectedItem is not TrackChoice item) return;
        _mediaPlayer.SetAudioTrack(item.Id);
    }

    private void SubtitleCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSettingsEvents || _mediaPlayer is null || SubtitleCombo.SelectedItem is not TrackChoice item) return;
        _mediaPlayer.SetSpu(item.Id);
    }

    private void AddSubtitle_Click(object sender, RoutedEventArgs e)
    {
        if (_mediaPlayer is null) return;
        var dialog = new OpenFileDialog
        {
            Title = "انتخاب زیرنویس",
            Filter = "Subtitle files|*.srt;*.ass;*.ssa;*.vtt;*.sub;*.idx|All files|*.*"
        };
        if (dialog.ShowDialog(this) != true) return;
        try
        {
            var uri = new Uri(dialog.FileName).AbsoluteUri;
            if (_mediaPlayer.AddSlave(MediaSlaveType.Subtitle, uri, true))
            {
                _lastTrackSignature = "";
                ShowHud("زیرنویس", "اضافه شد");
            }
        }
        catch (Exception ex)
        {
            MessageBox.Show("زیرنویس بارگذاری نشد.\n" + ex.Message, "BankMovie Player", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void SubtitleDelaySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_suppressSettingsEvents) return;
        _preferences.SubtitleDelayMs = (int)e.NewValue;
        SubtitleDelayText.Text = $"{_preferences.SubtitleDelayMs:+#;-#;0} ms";
        ApplySubtitleDelay(_preferences.SubtitleDelayMs);
        SavePreferences();
    }

    private void ApplySubtitleDelay(int milliseconds)
    {
        if (_mediaPlayer is null) return;
        // LibVLC uses microseconds for SPU delay.
        InvokeOptional(_mediaPlayer, "SetSpuDelay", milliseconds * 1000L);
    }

    private void SubtitleSizeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (_suppressSettingsEvents) return;
        _preferences.SubtitleFontSize = (int)e.NewValue;
        SubtitleSizeText.Text = _preferences.SubtitleFontSize.ToString();
    }

    private void SubtitleColorCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressSettingsEvents || SubtitleColorCombo.SelectedItem is not ColorChoice color) return;
        _preferences.SubtitleColor = color.Hex;
    }

    private void SubtitleOutlineSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_suppressSettingsEvents) _preferences.SubtitleOutlineThickness = (int)e.NewValue;
    }

    private void SubtitleBackgroundSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_suppressSettingsEvents) _preferences.SubtitleBackgroundOpacity = (int)e.NewValue;
    }

    private void SubtitleMarginSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
    {
        if (!_suppressSettingsEvents) _preferences.SubtitleMargin = (int)e.NewValue;
    }

    private void ApplySubtitleStyle_Click(object sender, RoutedEventArgs e)
    {
        SavePreferences();
        var time = Math.Max(0, _mediaPlayer?.Time ?? 0);
        var playing = _mediaPlayer?.IsPlaying == true;
        StartPlayback(time, playing);
        ShowHud("زیرنویس", "ظاهر اعمال شد");
    }

    private void PerformanceOption_Changed(object sender, RoutedEventArgs e)
    {
        if (_suppressSettingsEvents) return;
        _preferences.HardwareDecoding = HardwareDecodeCheck.IsChecked == true;
        _preferences.LowEndMode = LowEndModeCheck.IsChecked == true;
        _preferences.AutoNextEpisode = AutoNextCheck.IsChecked == true;
        _uiTimer.Interval = TimeSpan.FromMilliseconds(_preferences.LowEndMode ? 1000 : 500);
        SavePreferences();
    }

    private void AlwaysOnTop_Changed(object sender, RoutedEventArgs e)
    {
        if (_suppressSettingsEvents) return;
        _preferences.AlwaysOnTop = AlwaysOnTopCheck.IsChecked == true;
        Topmost = _preferences.AlwaysOnTop;
        SavePreferences();
    }

    private void SavePreferences() => _preferencesStore.Save(_preferences);

    private void ProgressSlider_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e) => _draggingProgress = true;

    private void ProgressSlider_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (_mediaPlayer is not null) _mediaPlayer.Time = (long)ProgressSlider.Value;
        _draggingProgress = false;
    }

    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        EpisodesPanel.Visibility = Visibility.Collapsed;
        SettingsPanel.Visibility = SettingsPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        ShowControls();
    }

    private void CloseSettings_Click(object sender, RoutedEventArgs e) => SettingsPanel.Visibility = Visibility.Collapsed;

    private void Episodes_Click(object sender, RoutedEventArgs e)
    {
        if (_request.Episodes.Count == 0) return;
        SettingsPanel.Visibility = Visibility.Collapsed;
        EpisodesPanel.Visibility = EpisodesPanel.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible;
        ShowControls();
    }

    private void CloseEpisodes_Click(object sender, RoutedEventArgs e) => EpisodesPanel.Visibility = Visibility.Collapsed;

    private void PrevEpisode_Click(object sender, RoutedEventArgs e)
    {
        if (CanGoPreviousEpisode()) PlayEpisode(_request.CurrentEpisodeIndex - 1);
    }

    private void NextEpisode_Click(object sender, RoutedEventArgs e)
    {
        if (CanGoNextEpisode()) PlayEpisode(_request.CurrentEpisodeIndex + 1);
    }

    private bool CanGoPreviousEpisode() => _request.CurrentEpisodeIndex > 0 && _request.CurrentEpisodeIndex < _request.Episodes.Count;
    private bool CanGoNextEpisode() => _request.CurrentEpisodeIndex >= 0 && _request.CurrentEpisodeIndex + 1 < _request.Episodes.Count;

    private void EpisodeList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (_suppressEpisodeSelection || EpisodeList.SelectedItem is not EpisodeListItem item) return;
        if (item.Index != _request.CurrentEpisodeIndex) PlayEpisode(item.Index);
    }

    private void PlayEpisode(int index)
    {
        if (index < 0 || index >= _request.Episodes.Count) return;
        SaveCurrentPosition();
        var episode = _request.Episodes[index];
        _request = new PlaybackRequest
        {
            Url = episode.Url,
            SubtitleUrl = episode.SubtitleUrl,
            Title = string.IsNullOrWhiteSpace(episode.Title) ? _request.Title : episode.Title,
            Referer = _request.Referer,
            UserAgent = _request.UserAgent,
            CookieHeader = _request.CookieHeader,
            MediaId = episode.Id,
            SeriesId = _request.SeriesId,
            SeasonNumber = episode.SeasonNumber,
            EpisodeNumber = episode.EpisodeNumber,
            Episodes = _request.Episodes,
            CurrentEpisodeIndex = index
        };
        UpdateRequestUi();
        StartPlayback();
        EpisodesPanel.Visibility = Visibility.Collapsed;
    }

    private void UpdateRequestUi()
    {
        MediaTitle.Text = string.IsNullOrWhiteSpace(_request.Title) ? "BankMovie Player" : _request.Title;
        EpisodeMetaText.Text = BuildEpisodeMeta(_request.SeasonNumber, _request.EpisodeNumber);
        EpisodePanelSubtitle.Text = string.IsNullOrWhiteSpace(EpisodeMetaText.Text) ? "قسمت‌های موجود" : EpisodeMetaText.Text;

        _suppressEpisodeSelection = true;
        var items = _request.Episodes.Select((episode, index) => new EpisodeListItem(index, BuildEpisodeLabel(episode, index))).ToList();
        EpisodeList.ItemsSource = items;
        if (_request.CurrentEpisodeIndex >= 0 && _request.CurrentEpisodeIndex < items.Count)
            EpisodeList.SelectedIndex = _request.CurrentEpisodeIndex;
        _suppressEpisodeSelection = false;

        var hasEpisodes = items.Count > 0;
        EpisodePanelButton.Visibility = hasEpisodes ? Visibility.Visible : Visibility.Collapsed;
        PrevEpisodeButton.Visibility = hasEpisodes ? Visibility.Visible : Visibility.Collapsed;
        NextEpisodeButton.Visibility = hasEpisodes ? Visibility.Visible : Visibility.Collapsed;
        PrevEpisodeButton.IsEnabled = CanGoPreviousEpisode();
        NextEpisodeButton.IsEnabled = CanGoNextEpisode();
    }

    private static string BuildEpisodeLabel(PlaybackEpisode episode, int index)
    {
        var meta = BuildEpisodeMeta(episode.SeasonNumber, episode.EpisodeNumber);
        if (!string.IsNullOrWhiteSpace(episode.Title)) return string.IsNullOrWhiteSpace(meta) ? episode.Title! : $"{meta} · {episode.Title}";
        return string.IsNullOrWhiteSpace(meta) ? $"قسمت {index + 1}" : meta;
    }

    private static string BuildEpisodeMeta(int? season, int? episode)
    {
        if (season is > 0 && episode is > 0) return $"فصل {season} · قسمت {episode}";
        if (episode is > 0) return $"قسمت {episode}";
        if (season is > 0) return $"فصل {season}";
        return "";
    }

    private void Fullscreen_Click(object sender, RoutedEventArgs e) => ToggleFullscreen();

    private void ToggleFullscreen()
    {
        _isFullscreen = !_isFullscreen;
        if (_isFullscreen)
        {
            WindowState = WindowState.Maximized;
            TopBar.Visibility = Visibility.Collapsed;
        }
        else
        {
            WindowState = WindowState.Normal;
            TopBar.Visibility = Visibility.Visible;
            Mouse.OverrideCursor = null;
        }
        ShowControls();
    }

    private void Window_KeyDown(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Space: PlayPause_Click(sender, e); e.Handled = true; break;
            case Key.Left: SeekBy(-_preferences.SeekSeconds * 1000L); e.Handled = true; break;
            case Key.Right: SeekBy(_preferences.SeekSeconds * 1000L); e.Handled = true; break;
            case Key.Up: VolumeSlider.Value = Math.Min(100, VolumeSlider.Value + 5); ShowHud("صدا", $"{(int)VolumeSlider.Value}%"); e.Handled = true; break;
            case Key.Down: VolumeSlider.Value = Math.Max(0, VolumeSlider.Value - 5); ShowHud("صدا", $"{(int)VolumeSlider.Value}%"); e.Handled = true; break;
            case Key.M: Mute_Click(sender, e); e.Handled = true; break;
            case Key.F: ToggleFullscreen(); e.Handled = true; break;
            case Key.S: Settings_Click(sender, e); e.Handled = true; break;
            case Key.E: Episodes_Click(sender, e); e.Handled = true; break;
            case Key.N: NextEpisode_Click(sender, e); e.Handled = true; break;
            case Key.P: PrevEpisode_Click(sender, e); e.Handled = true; break;
            case Key.Escape:
                if (SettingsPanel.Visibility == Visibility.Visible) SettingsPanel.Visibility = Visibility.Collapsed;
                else if (EpisodesPanel.Visibility == Visibility.Visible) EpisodesPanel.Visibility = Visibility.Collapsed;
                else if (_isFullscreen) ToggleFullscreen();
                e.Handled = true;
                break;
        }
    }

    private void InteractionLayer_MouseMove(object sender, MouseEventArgs e) => ShowControls();

    private void InteractionLayer_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleFullscreen();
        else ShowControls();
    }

    private void InteractionLayer_MouseWheel(object sender, MouseWheelEventArgs e)
    {
        VolumeSlider.Value = Math.Clamp(VolumeSlider.Value + (e.Delta > 0 ? 5 : -5), 0, 100);
        ShowHud("صدا", $"{(int)VolumeSlider.Value}%");
        ShowControls();
        e.Handled = true;
    }

    private void ShowControls()
    {
        ControlsRoot.Opacity = 1;
        ControlsRoot.IsHitTestVisible = true;
        if (!_isFullscreen) TopBar.Visibility = Visibility.Visible;
        else TopBar.Visibility = Visibility.Visible;
        Mouse.OverrideCursor = null;
        _hideControlsTimer.Stop();
        if (_mediaPlayer?.IsPlaying == true && SettingsPanel.Visibility != Visibility.Visible && EpisodesPanel.Visibility != Visibility.Visible)
            _hideControlsTimer.Start();
    }

    private void HideControls()
    {
        _hideControlsTimer.Stop();
        if (SettingsPanel.Visibility == Visibility.Visible || EpisodesPanel.Visibility == Visibility.Visible) return;
        ControlsRoot.Opacity = 0;
        ControlsRoot.IsHitTestVisible = false;
        TopBar.Visibility = Visibility.Collapsed;
        if (_isFullscreen) Mouse.OverrideCursor = Cursors.None;
    }

    private void ShowVideoPlaceholder(string title, string detail, bool error = false)
    {
        if (!Dispatcher.CheckAccess())
        {
            Dispatcher.BeginInvoke(() => ShowVideoPlaceholder(title, detail, error));
            return;
        }
        VideoPlaceholder.Visibility = Visibility.Visible;
        VideoPlaceholderTitle.Text = title;
        VideoPlaceholderDetail.Text = detail;
        VideoPlaceholderTitle.Foreground = error
            ? new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(255, 132, 132))
            : new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(244, 248, 255));
        VideoLoadingProgress.Visibility = error ? Visibility.Collapsed : Visibility.Visible;
    }

    private void HideVideoPlaceholder()
    {
        if (!Dispatcher.CheckAccess())
        {
            Dispatcher.BeginInvoke(HideVideoPlaceholder);
            return;
        }
        VideoPlaceholder.Visibility = Visibility.Collapsed;
    }

    private void ShowHud(string title, string value)
    {
        HudTitle.Text = title;
        HudValue.Text = value;
        CenterHud.Visibility = Visibility.Visible;
        _hudTimer.Stop();
        _hudTimer.Start();
    }

    private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount == 2) ToggleMaximize();
        else if (!_isFullscreen && e.ButtonState == MouseButtonState.Pressed) DragMove();
    }

    private void Minimize_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
    private void Maximize_Click(object sender, RoutedEventArgs e) => ToggleMaximize();
    private void Close_Click(object sender, RoutedEventArgs e) => Close();
    private void ToggleMaximize() => WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;

    private void SaveCurrentPosition()
    {
        if (_mediaPlayer is null || !_config.RememberPosition) return;
        var length = _mediaPlayer.Length;
        var time = _mediaPlayer.Time;
        if (length > 0 && time > 10_000 && time < length * 0.95) _history.Set(_request.Url, time);
        else if (length > 0 && time >= length * 0.95) _history.Clear(_request.Url);
    }

    private void Window_Closing(object? sender, CancelEventArgs e)
    {
        _uiTimer.Stop();
        _hideControlsTimer.Stop();
        _hudTimer.Stop();
        SaveCurrentPosition();
        SavePreferences();
        Mouse.OverrideCursor = null;
        DisposePlaybackEngine();
    }

    private void DisposePlaybackEngine()
    {
        try { VideoView.MediaPlayer = null; } catch { }
        try { _mediaPlayer?.Stop(); } catch { }
        try { _mediaPlayer?.Dispose(); } catch { }
        try { _media?.Dispose(); } catch { }
        try { _engine?.Dispose(); } catch { }
        _mediaPlayer = null;
        _media = null;
        _engine = null;
    }

    private static void InvokeOptional(object target, string methodName, params object[] values)
    {
        try
        {
            var methods = target.GetType().GetMethods(BindingFlags.Instance | BindingFlags.Public)
                .Where(m => string.Equals(m.Name, methodName, StringComparison.Ordinal) && m.GetParameters().Length == values.Length);
            foreach (var method in methods)
            {
                try
                {
                    method.Invoke(target, values);
                    return;
                }
                catch { }
            }
        }
        catch { }
    }

    private static string FormatTime(long milliseconds)
    {
        var span = TimeSpan.FromMilliseconds(Math.Max(0, milliseconds));
        return span.TotalHours >= 1 ? span.ToString(@"hh\:mm\:ss") : span.ToString(@"mm\:ss");
    }

    private static string NormalizeTrackName(string? value, string fallback)
    {
        var text = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
        if (text.Equals("Disable", StringComparison.OrdinalIgnoreCase)) return "زیرنویس خاموش";
        return text;
    }
}
