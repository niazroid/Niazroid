-- Isolated Lua control logic test; not a real MPV rendering or Windows test.
local bindings,events,commands={}, {}, {}
local props={pause=true,duration=3600,['time-pos']=60,volume=50,speed=1,['media-title']='Movie {unsafe}', ['track-list']={{id=1,type='sub',lang='fas',codec='ass'},{id=2,type='audio',lang='eng'}}}
local time,xx,yy,ow,oh=0,0,0,1280,720
local ov={update=function()end};local timer
local mp={create_osd_overlay=function()return ov end,get_time=function()return time end,get_osd_size=function()return ow,oh,ow/oh end,get_mouse_pos=function()return xx,yy end,get_property=function(n,d)return props[n] or d end,get_property_number=function(n,d)return props[n] or d end,get_property_bool=function(n,d)if props[n]==nil then return d end return props[n] end,get_property_native=function(n,d)return props[n] or d end,set_property=function(n,v)props[n]=v end,set_property_bool=function(n,v)props[n]=v end,set_property_number=function(n,v)props[n]=v end,commandv=function(...)local a={...};commands[#commands+1]=a;if a[1]=='cycle' then props[a[2]]=not props[a[2]] end end,add_forced_key_binding=function(k,n,f)bindings[k]=f end,register_event=function(k,f)events[k]=f end,observe_property=function()end,add_periodic_timer=function(_,f)timer=f end,osd_message=function()end}
package.loaded.mp=mp
dofile('player/cinema.lua')
local function click(x,y)xx,yy=x,y;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});bindings.MBTN_LEFT({event='up'})end
assert(ov.data:find('Movie',1,true));assert(not ov.data:find('{unsafe}',1,true));assert(ov.data:find('F67C32',1,true));events['playback-restart']();timer()
click(640,341);assert(props.pause==false)
click(640,341);assert(props.pause==true)
bindings.RIGHT();assert(commands[#commands][1]=='seek' and commands[#commands][2]==10)
click(640,632);assert(commands[#commands][1]=='seek' and commands[#commands][3]=='absolute-percent+exact')
click(1017,679);assert(ov.data:find('Subtitles',1,true));assert(ov.data:find('fas',1,true))
-- menu is near bottom right; choose subtitle row 2
click(1050,585);assert(props.sid=='1')
click(1161,679);assert(not ov.data:find('Movie',1,true));bindings.ESC();assert(ov.data:find('Movie',1,true))
props.pause=false;time=10;timer();assert(ov.data=='');bindings.MOUSE_MOVE();assert(ov.data~='')
for _,size in ipairs({{640,360},{1920,1080},{800,600},{3440,1440}}) do ow,oh=size[1],size[2];timer();assert(ov.res_x>0 and ov.res_y>0 and #ov.data>0)end
print('PASS: Lua overlay title escaping, playback toggle, skip, seek, subtitle selection, lock, auto-hide, responsive sizes')
