-- BankMovie native cinema controls. Original ASS vector UI; no browser or external scripts.
local mp = require 'mp'
local overlay = mp.create_osd_overlay('ass-events')
local W,H,scale = 1280,720,1
local hit,parts={},{}
local visible, locked, dragging, menu, loading = true,false,false,nil,true
local last=mp.get_time()
local blue='F67C32' -- ASS BGR, #327CF6
local white='FFFFFF'
local function esc(s)
    return tostring(s or ''):gsub('[%z\1-\31\127]',' '):gsub('\\','＼'):gsub('{','｛'):gsub('}','｝')
end
local function prop(n,d) return mp.get_property_number(n,d or 0) end
local function bool(n,d) return mp.get_property_bool(n,d or false) end
local function fmt(v)
    v=math.max(0,math.floor(v or 0)); local h=math.floor(v/3600)
    if h>0 then return string.format('%d:%02d:%02d',h,math.floor(v/60)%60,v%60) end
    return string.format('%02d:%02d',math.floor(v/60),v%60)
end
local function add(s) parts[#parts+1]=s end
local function draw(x,y,p,color,a)
    add(string.format('{\\an7\\pos(%.2f,%.2f)\\bord0\\shad0\\1c&H%s&\\1a&H%02X&\\p1}%s{\\p0}',x,y,color or white,a or 0,p))
end
local function rect(x,y,w,h,c,a)
    if w<=0 or h<=0 then return end
    draw(x,y,string.format('m 0 0 l %.2f 0 %.2f %.2f 0 %.2f',w,w,h,h),c,a)
end
local function circle(x,y,r,c,a)
    local k=r*0.55228475
    draw(x-r,y-r,string.format('m %.2f 0 b %.2f 0 %.2f %.2f %.2f %.2f b %.2f %.2f %.2f %.2f %.2f %.2f b %.2f %.2f 0 %.2f 0 %.2f b 0 %.2f %.2f 0 %.2f 0',r,r+k,2*r,r-k,2*r,r,2*r,r+k,r+k,2*r,r,2*r,r-k,2*r,r+k,r,r-k,r-k,r),c,a)
end
local function text(x,y,s,size,align,color,bold)
    add(string.format('{\\an%d\\pos(%.2f,%.2f)\\fnSegoe UI\\fs%d\\b%d\\bord0.6\\shad0\\3c&H000000&\\1c&H%s&}%s',align or 5,x,y,size,bold and 1 or 0,color or white,esc(s)))
end
local function button(x,y,r,fn)
    hit[#hit+1]={x=x-r,y=y-r,w=r*2,h=r*2,fn=fn}
end
local function area(x,y,w,h,fn) hit[#hit+1]={x=x,y=y,w=w,h=h,fn=fn} end
local function wake() visible=true; last=mp.get_time() end
local function togglePause() if not locked then if bool('eof-reached') then mp.commandv('seek',0,'absolute+exact');mp.set_property_bool('pause',false) else mp.commandv('cycle','pause') end end end
local function seek(v) if not locked then mp.commandv('seek',v,'relative+exact') end end
local function full() mp.commandv('cycle','fullscreen') end
local function switchMenu(which) if menu==which then menu=nil else menu=which end; wake() end
local function volume(v) mp.set_property_number('volume',math.max(0,math.min(100,v))); if v>0 then mp.set_property_bool('mute',false) end end
local function seekAt(x)
    local d=prop('duration');if d>0 and not locked then mp.commandv('seek',math.max(0,math.min(100,(x-18)/(W-36)*100)),'absolute-percent+exact') end
end
local function arc(x,y,r,start,span,thick,c)
    local pts={}; local n=math.max(8,math.floor(span/7))
    for i=0,n do local t=math.rad(start+span*i/n);pts[#pts+1]=string.format('%.2f %.2f',r+math.cos(t)*r,r+math.sin(t)*r) end
    for i=n,0,-1 do local t=math.rad(start+span*i/n);pts[#pts+1]=string.format('%.2f %.2f',r+math.cos(t)*(r-thick),r+math.sin(t)*(r-thick)) end
    draw(x-r,y-r,'m '..pts[1]..' l '..table.concat(pts,' ',2),c)
end
local function playIcon(x,y,paused,s)
    if paused then draw(x-9*s,y-12*s,string.format('m 0 0 l %.2f %.2f 0 %.2f',20*s,12*s,24*s),white)
    else rect(x-9*s,y-12*s,6*s,24*s,white); rect(x+3*s,y-12*s,6*s,24*s,white) end
end
local function skipIcon(x,y,forward)
    arc(x,y-3,13,forward and 35 or 145,282,2.6,white)
    if forward then draw(x+5,y-19,'m 0 0 l 10 7 0 13',white) else draw(x-15,y-19,'m 10 0 l 0 7 10 13',white) end
    text(x,y+4,'10',10,5,white,true)
end
local function icon(x,y,kind)
    if kind=='full' then
        for _,sx in ipairs({-1,1}) do for _,sy in ipairs({-1,1}) do rect(x+sx*11-(sx==1 and 6 or 0),y+sy*9,6,2,white);rect(x+sx*11,y+sy*9-(sy==1 and 5 or 0),2,6,white) end end
    elseif kind=='volume' then
        draw(x-10,y-10,'m 0 6 l 5 6 12 0 12 20 5 14 0 14',white)
        if bool('mute') or prop('volume')==0 then text(x+9,y,'×',17) else arc(x-1,y,12,-52,104,2,white) end
    elseif kind=='sub' then
        rect(x-12,y-9,24,18,white);rect(x-10,y-7,20,14,'000000');text(x,y,'CC',11,5,white,true)
    elseif kind=='settings' then
        for i=0,7 do local t=i*math.pi/4;circle(x+math.cos(t)*10,y+math.sin(t)*10,2.7,white) end
        arc(x,y,10,0,360,3,white)
    elseif kind=='lock' then
        arc(x,y-3,8,180,180,2,white);rect(x-9,y-1,18,12,white);rect(x-7,y+1,14,8,'000000')
        if not locked then rect(x+5,y-8,4,5,'000000') end
    elseif kind=='close' then text(x,y,'×',29) end
end
local function menuRows()
    local rows={}
    if menu=='sub' or menu=='audio' then
        local typ=menu;local key=typ=='sub' and 'sid' or 'aid'
        if typ=='sub' then rows[#rows+1]={label='Off',selected=mp.get_property(key)=='no',fn=function()mp.set_property(key,'no');menu=nil end} end
        for _,t in ipairs(mp.get_property_native('track-list',{}) or {}) do if t.type==typ then
            local id=t.id;local label=(t.title or t.lang or (typ=='sub' and 'Subtitle' or 'Audio'))..(t.codec and ('  ·  '..t.codec) or '')
            rows[#rows+1]={label=label,selected=t.selected,fn=function()mp.set_property(key,tostring(id));menu=nil end}
        end end
    elseif menu=='settings' then
        rows={{label='Audio tracks',fn=function()menu='audio' end},{label='Subtitles',fn=function()menu='sub' end},{label='Playback speed  ·  '..string.format('%.2gx',prop('speed',1)),fn=function()menu='speed' end},{label='Volume  ·  '..math.floor(prop('volume'))..'%',fn=function()menu='volume' end}}
    elseif menu=='speed' then
        for _,v in ipairs({0.5,0.75,1,1.25,1.5,2}) do local s=v;rows[#rows+1]={label=tostring(s)..'x',selected=math.abs(prop('speed',1)-s)<0.01,fn=function()mp.set_property_number('speed',s);menu=nil end} end
    elseif menu=='volume' then
        for _,v in ipairs({0,25,50,75,100}) do local val=v;rows[#rows+1]={label=tostring(val)..'%',selected=math.floor(prop('volume'))==val,fn=function()volume(val);menu=nil end} end
    end
    return rows
end
local dragX=nil
local menuOffset=0
local lastFrame=''
local function render()
    local ow,oh=mp.get_osd_size();if not ow or not oh or ow<1 or oh<1 then return end
    scale=math.min(ow/640,oh/460,1.6);W=ow/scale;H=oh/scale
    local buffering=loading or bool('paused-for-cache') or bool('seeking')
    local paused=bool('pause') or bool('eof-reached')
    local show=visible or paused or buffering or menu~=nil or dragging
    if locked then show=visible end
    parts={};hit={}
    if not show then if lastFrame~='' then overlay.data='';overlay:update();lastFrame='' end;return end
    if locked then icon(W-30,H-30,'lock');button(W-30,H-30,26,function()locked=false;wake()end)
    else
        for i=0,15 do local a=math.floor(115+i*8.7);rect(0,i*4,W,4,'000000',a);rect(0,H-(i+1)*6,W,6,'000000',a) end
        text(18,16,mp.get_property('media-title','BankMovie'),18,7,white,true)
        icon(W-28,25,'close');button(W-28,25,24,function()mp.commandv('quit')end)
        local cx,cy=W/2,H/2-12
        local r=math.min(34,H*0.065);local spacing=r+math.min(58,W*0.09)
        circle(cx,cy,r,white,205);playIcon(cx,cy,paused or buffering,0.9)
        if buffering then arc(cx,cy,r+5,(mp.get_time()*260)%360,115,3,blue) end
        button(cx,cy,r+6,togglePause)
        for _,dir in ipairs({-1,1}) do local delta=dir;local x=cx+dir*spacing;circle(x,cy,25,'000000',115);skipIcon(x,cy,dir==1);button(x,cy,29,function()seek(delta*10)end) end
        local y=H-56;local dur=prop('duration');local pos=prop('time-pos');local frac=dur>0 and math.max(0,math.min(1,pos/dur)) or 0
        if dragging and dragX then frac=math.max(0,math.min(1,(dragX-18)/(W-36)));pos=frac*dur end
        rect(18,y,W-36,3,white,190)
        local cache=mp.get_property_native('demuxer-cache-state',{}) or {}
        local buffered=pos;for _,range in ipairs(cache['seekable-ranges'] or {}) do if range.start<=pos and range['end']>=pos then buffered=math.max(buffered,range['end']) end end
        if dur>0 then rect(18,y,(W-36)*math.min(1,buffered/dur),3,white,100) end
        rect(18,y,(W-36)*frac,3,blue);circle(18+(W-36)*frac,y+1.5,4,white)
        area(12,y-12,W-24,26,function(x)dragging=true;dragX=x end)
        local by=H-26
        playIcon(29,by,paused,0.55);button(29,by,17,togglePause)
        icon(68,by,'volume');button(68,by,17,function()switchMenu('volume')end)
        text(94,by,fmt(pos)..' / '..fmt(dur),13,4,white)
        icon(W-30,by,'full');button(W-30,by,20,full)
        icon(W-76,by,'lock');button(W-76,by,20,function()locked=true;menu=nil;wake()end)
        icon(W-122,by,'settings');button(W-122,by,20,function()switchMenu('settings')end)
        icon(W-168,by,'sub');button(W-168,by,20,function()switchMenu('sub')end)
        if menu then
            local rows=menuRows(); local maxRows=math.max(1,math.floor((H-120)/36));local shown=math.min(#rows,maxRows)
            menuOffset=math.max(0,math.min(menuOffset,#rows-shown));local mw=math.min(330,W-32);local mx=W-mw-18;local my=H-83-shown*36-42
            rect(mx,my,mw,shown*36+42,'111111',18);text(mx+14,my+13,menu=='sub' and 'Subtitles' or menu:gsub('^%l',string.upper),17,7,white,true)
            text(mx+mw-18,my+19,'×',21);button(mx+mw-18,my+19,18,function()menu=nil;menuOffset=0 end)
            for i=1,shown do local row=rows[i+menuOffset];local ry=my+42+(i-1)*36
                if row.selected then rect(mx+5,ry,mw-10,34,blue,155) end
                -- Clip long track names to panel, without cutting UTF-8 bytes.
                add(string.format('{\\an4\\pos(%.2f,%.2f)\\clip(%.0f,%.0f,%.0f,%.0f)\\fnSegoe UI\\fs15\\bord0\\shad0\\1c&HFFFFFF&}%s',mx+14,ry+18,mx+8,ry,mx+mw-12,ry+36,esc(row.label)))
                area(mx,ry,mw,36,row.fn)
            end
            if #rows==0 then text(mx+mw/2,my+24,'No tracks',13) end
        end
    end
    local data=table.concat(parts,'\n');local rw,rh=math.floor(W),math.floor(H)
    if data~=lastFrame or overlay.res_x~=rw or overlay.res_y~=rh then overlay.res_x=rw;overlay.res_y=rh;overlay.data=data;overlay:update();lastFrame=data end
end
local function point() local x,y=mp.get_mouse_pos();return (x or -1)/scale,(y or -1)/scale end
local function move() wake();if dragging then dragX=point() end;render()end
local function click(e)
    if e.event=='up' then if dragging then local x=point();seekAt(x);dragging=false;dragX=nil;render() end;return end
    if e.event~='down' and e.event~='press' then return end
    if not visible and not bool('pause') and not loading and not bool('paused-for-cache') then wake();render();return end
    wake();local x,y=point();for i=#hit,1,-1 do local b=hit[i];if x>=b.x and x<=b.x+b.w and y>=b.y and y<=b.y+b.h then b.fn(x,y);render();return end end
    if menu then menu=nil;menuOffset=0 elseif not locked then togglePause() end;render()
end
mp.add_forced_key_binding('MOUSE_MOVE','bm-move',move)
mp.add_forced_key_binding('MBTN_LEFT','bm-click',click,{complex=true})
mp.add_forced_key_binding('MBTN_LEFT_DBL','bm-double',function()end)
mp.add_forced_key_binding('WHEEL_UP','bm-wheel-up',function()if menu then menuOffset=math.max(0,menuOffset-1) elseif not locked then volume(prop('volume')+5) end;wake();render()end)
mp.add_forced_key_binding('WHEEL_DOWN','bm-wheel-down',function()if menu then menuOffset=menuOffset+1 elseif not locked then volume(prop('volume')-5) end;wake();render()end)
local keys={SPACE=togglePause,LEFT=function()seek(-10)end,RIGHT=function()seek(10)end,UP=function()if not locked then volume(prop('volume')+5)end end,DOWN=function()if not locked then volume(prop('volume')-5)end end,f=function()if not locked then full()end end,ESC=function()if locked then locked=false elseif menu then menu=nil elseif bool('fullscreen') then mp.set_property_bool('fullscreen',false) else mp.commandv('quit')end end,m=function()if not locked then mp.commandv('cycle','mute')end end,j=function()if not locked then switchMenu('sub')end end,q=function()mp.commandv('quit')end}
for k,fn in pairs(keys) do mp.add_forced_key_binding(k,'bm-key-'..k,function()fn();wake();render()end,{repeatable=k=='LEFT' or k=='RIGHT' or k=='UP' or k=='DOWN'}) end
mp.register_event('start-file',function()loading=true;wake()end)
mp.register_event('file-loaded',function()
    -- A supplied subtitle is preferred; the track menu can override it.
    for _,t in ipairs(mp.get_property_native('track-list',{}) or {}) do if t.type=='sub' and t.external then mp.set_property('sid',tostring(t.id));break end end
    wake()
end)
mp.register_event('playback-restart',function()loading=false;wake()end)
mp.register_event('end-file',function(e)loading=false;if e.reason=='error' then mp.osd_message('Playback failed',5)end;wake()end)
mp.observe_property('pause','bool',function()wake();render()end)
mp.add_periodic_timer(0.08,function()if mp.get_time()-last>3 and not dragging and not menu then visible=false end;render()end)
render()
