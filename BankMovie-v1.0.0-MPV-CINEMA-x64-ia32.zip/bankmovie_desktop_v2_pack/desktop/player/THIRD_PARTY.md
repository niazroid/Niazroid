# MPV distribution notice
BankMovie uses a separate, unmodified MPV executable, not code from OskolKhan. The custom BankMovie Lua controls communicate using MPV's public Lua API.

- MPV 0.42.0 release and sources: https://github.com/mpv-player/mpv/releases/tag/v0.42.0
- Build recipes and dependency definitions: https://github.com/mpv-player/mpv/tree/v0.42.0/ci
- MPV license information: https://github.com/mpv-player/mpv/blob/v0.42.0/Copyright
- FFmpeg: https://ffmpeg.org/ ; libass: https://github.com/libass/libass
- The full upstream binary archive is extracted into the installer resources; its original license and documentation files are retained. MPV and its bundled dependencies have their own licenses, including GPL components.
- Before publicly redistributing the installers, the distributor must verify the applicable license notices and provide access to the complete corresponding source (including build scripts and dependency versions) for the exact bundled binaries, as required by their licenses. These links are starting points, not a claim of completed license compliance.
