'use strict';
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
function bundledPlayer(resourcesPath, packaged, root=path.join(__dirname,'..')) {
  const base = packaged ? resourcesPath : root;
  const exe = path.join(base, packaged ? 'mpv' : 'vendor/mpv', 'mpv.exe');
  const script = path.join(base, 'player', 'cinema.lua');
  if (!fs.existsSync(exe) || !fs.existsSync(script)) return null;
  return {id:'bm-mpv',name:'BankMovie (MPV)',path:exe,script,score:1000,subtitleSupport:true};
}
function cleanTitle(value) {return String(value||'').replace(/[\x00-\x1f\x7f]/g,' ').trim().slice(0,240);}
function argsFor(player, target, meta={}, local=false) {
  if (typeof target!=='string'||!target||/[\x00-\x1f]/.test(target)) throw Error('Invalid media path');
  if(local){if(!path.isAbsolute(target))throw Error('Invalid local media path');}
  else {const u=new URL(target);if(!['https:','http:'].includes(u.protocol)||u.username||u.password)throw Error('Invalid media URL');}
  const args=['--no-config','--load-scripts=no','--osc=no','--input-default-bindings=no','--input-builtin-dragging=no','--input-builtin-drag-and-drop=no','--ytdl=no','--load-unsafe-playlists=no','--tls-verify=yes','--no-terminal','--force-window=yes','--idle=no','--keep-open=yes','--geometry=80%x80%','--hwdec=auto-safe','--cache=auto','--sub-auto='+ (local?'exact':'no'),'--audio-file-auto=no','--cover-art-auto=no','--slang=fa,fas,per,persian,en,eng','--script='+player.script];
  const title=cleanTitle(meta.title || (local?path.basename(target):'BankMovie'));
  if(title)args.push('--force-media-title='+title);
  if(meta.subtitlePath)args.push('--sub-file='+meta.subtitlePath);
  args.push('--',target);
  return args;
}
async function launch(player,target,meta={},local=false,spawnFn=spawn){
  const args=argsFor(player,target,meta,local);
  await new Promise((resolve,reject)=>{
    const child=spawnFn(player.path,args,{cwd:path.dirname(player.path),shell:false,detached:true,stdio:'ignore',windowsHide:false});
    child.once('error',()=>reject(new Error('اجرای موتور MPV ناموفق بود.')));
    child.once('spawn',()=>{child.unref();resolve();});
  });
  return {ok:true,player:{id:player.id,name:player.name},subtitleApplied:Boolean(meta.subtitlePath)};
}
module.exports={bundledPlayer,argsFor,launch};
