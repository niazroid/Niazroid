#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYCHK'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
section=s[s.index('private fun sectionHeader('):s.index('private fun legacyTvSectionHeader(')]
helper=s[s.index('private fun tintHomeContentIcon('):s.index('private fun sectionHeader(')]
detail=s[s.index('private fun renderDetail(page: LinearLayout, item: JSONObject)'):s.index('private fun commentAvatarView(')]
mixer=s[s.index('private fun showDiscover()'):s.index('private fun showCategories()',s.index('private fun showDiscover()'))]
# The same mobile hero dimensions and artwork clipping apply to ALL archives.
assert 'val forcePosterHero' not in detail
assert 'val artwork = if (hasRealBackdrop) rawBackdrop else poster' in detail
assert 'layoutParams = LinearLayout.LayoutParams(-1, dp(472))' in detail
assert 'hero.addView(heroImg, FrameLayout.LayoutParams(-1, -1, Gravity.TOP))' in detail
assert 'if (posterOnlyArtwork) loadBalancedDetailPoster(artwork, heroImg)' in detail
assert 'val top = ((target.height - renderedHeight) * 0.40f)' in s
# The legacy 72dp hero play overlay was intentionally redesigned in V20.
# Keep the centered glass play icon, now lifted to 204dp to clear long titles.
assert 'FrameLayout.LayoutParams(dp(62), dp(62), Gravity.TOP or Gravity.CENTER_HORIZONTAL)' in detail
assert 'topMargin = dp(204)' in detail
assert 'Color.argb(192, 45, 54, 67)' in detail
assert 'dp(308)' not in detail and 'dp(442)' not in detail
assert detail.index('hero.addView(heroImg,') < detail.index('hero.addView(playOrb,') < detail.index('page.addView(hero)') < detail.index('detailLatestUpdatePill(item)') < detail.index('bankRatingStrip(item)')
# Dynamic icons use a colour matrix, not a destructive opaque tint.
assert 'tintHomeContentIcon(this, artRes, accent)' in section
assert 'palette.primary2' in section
assert 'UiPreferences.blend(accent, Color.WHITE' in section
for country in ('china','korea','turkey'):
    assert f'artRes == R.drawable.bm_site_neon_{country}' in helper
assert 'android.graphics.ColorMatrixColorFilter' in helper
for category in ('anime','animation','collections','movie','series','dub','subtitle','top'):
    assert f'R.drawable.bm_site_neon_{category}' in section or f'R.drawable.bm_site_neon_{category}' in helper
# Open by default; animated collapse/expand reuses episodes/links section helper.
assert 'mixer.visibility = View.VISIBLE' in mixer
assert 'animateExpandable(mixer, mixerExpanded, 260L)' in mixer
assert 'mixerTransitionRunning = true' in mixer
assert 'mixer.visibility = if (mixer.visibility == View.VISIBLE)' not in mixer
assert 'private fun animateExpandable(' in s
# Fundamental package identity is maintained.
b=Path('app/build.gradle').read_text()
assert "applicationId 'ir.bankmoviee.app'" in b and 'versionName "2.4"' in b
print('VERIFY_V24_ARCHIVE_HERO_THEME_MIXER_V8_OK')
PYCHK
