-- Run ONLY on the BankMovie database. NO UPDATE, DELETE or schema changes.
-- Shows potentially split external comment identities including Archive 1.
SELECT ai.archive_no, ai.virtual_movie_id, ai.slug, ai.item_title,
       ai.item_year, COUNT(c.id) AS comment_count,
       SUM(CASE WHEN LOWER(TRIM(c.status)) IN ('approved','active','1') THEN 1 ELSE 0 END) AS public_count,
       SUM(CASE WHEN LOWER(TRIM(c.status)) = 'pending' THEN 1 ELSE 0 END) AS pending_count
FROM archive1_items ai
LEFT JOIN archive1_comments c ON c.movie_id = ai.virtual_movie_id
WHERE ai.archive_no IN (1,3,4,5)
GROUP BY ai.archive_no, ai.virtual_movie_id, ai.slug, ai.item_title, ai.item_year
ORDER BY ai.archive_no, comment_count DESC LIMIT 200;
-- Find multiple IDs for the same normalized title in the *same* archive.
SELECT archive_no, LOWER(TRIM(item_title)) AS normalized_title,
       item_year, COUNT(*) AS identity_count,
       GROUP_CONCAT(virtual_movie_id ORDER BY virtual_movie_id) AS candidate_ids
FROM archive1_items
WHERE item_title <> '' AND archive_no IN (1,3,4,5)
GROUP BY archive_no, LOWER(TRIM(item_title)), item_year
HAVING COUNT(*) > 1
ORDER BY identity_count DESC LIMIT 100;
