#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_user_api.php >/dev/null
php -l server-required/includes/bm_comment_identity.php >/dev/null
php -d zend.assertions=1 -d assert.exception=1 verify_v22_5_6_comment_alias_runtime.php
python3 - <<'PYTEST'
from pathlib import Path
main = Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
api = Path('server-required/app_user_api.php').read_text()
helper = Path('server-required/includes/bm_comment_identity.php').read_text()
assert 'val tvCompactHeader = isTvLike()' in main
assert 'if (isTvLike()) return legacyTvSectionHeader' not in main
assert 'if (tvCompactHeader) applyTvFocusHalo(this' in main
assert 'add(t("چی ببینیم؟", "Discover")' in main
assert 'if (!tv) { // Video Explorer previews/remote network calls are mobile-only.' in main
assert 'private fun showDiscover() {\n        // Native Discover is available' in main
assert 'focusFirstTvClickable(page)' in main
assert 'bm_user_api_comment_owner_movie_id' in api
assert "'movie_ids'=>$group['ids']" in api
assert 'INSERT IGNORE INTO archive1_items' in api
assert 'UPDATE archive1_comments SET movie_id=' not in api
assert 'function bm_comment_thread_group' in helper
assert "preg_replace('~^[0-9]{3,}__~'" in helper
assert 'SELECT virtual_movie_id, slug' in helper
assert 'UPDATE archive1_comments SET movie_id' not in api
assert Path('SITE_PATCH_REQUIRED/includes/bm_comment_identity.php').read_bytes() == Path('server-required/includes/bm_comment_identity.php').read_bytes()
assert 'private fun loadImage(' in main
assert 'topMargin = dp(204)' in main  # already working; don't move Play again
print('VERIFY_V22_5_6_COMMENT_TV_DISCOVER_OK')
PYTEST
