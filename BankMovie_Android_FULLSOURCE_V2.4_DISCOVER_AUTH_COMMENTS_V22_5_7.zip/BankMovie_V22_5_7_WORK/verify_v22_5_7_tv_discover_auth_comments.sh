#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_user_api.php >/dev/null
php -l server-required/includes/bm_comment_identity.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=Path('app/src/main/java/ir/bankmoviee/app/AccountApi.kt').read_text()
p=Path('server-required/app_user_api.php').read_text()
h=Path('server-required/includes/bm_comment_identity.php').read_text()
assert 'Pair("discover", R.drawable.ic_nav_discover), { showDiscover() }' in m
assert '"discover", "profile"' in m
assert '// Native Discover: make the initial controls' in m
assert 'if (!tv) { // Video Explorer previews/remote network calls are mobile-only.' in m
assert 'R.drawable.ic_auth_lock else R.drawable.ic_auth_user' in m
assert 'setImageResource(iconResource)' in m
assert 'AccountApi.listComments(this, item, requestedPage, 10, selectedSort)' in m
assert 'uri.getQueryParameter("slug")' in a
assert 'action == "comments_list" || action.startsWith("comment_")' in a
assert 'val bases = if (commentAction) listOf(commentOrigin)' in a
assert 'setOf("archive4", "archive2", "serialblog"' in a
assert "'thread_ids'=>$movieIds" in p
assert 'function bm_comment_thread_group' in h
assert 'UPDATE archive1_comments SET movie_id' not in p
assert 'topMargin = dp(204)' in m
assert Path('server-required/includes/bm_comment_identity.php').read_bytes()==Path('SITE_PATCH_REQUIRED/includes/bm_comment_identity.php').read_bytes()
print('VERIFY_V22_5_7_TV_DISCOVER_AUTH_COMMENTS_OK')
PYTEST
