#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYCHK'
from pathlib import Path
src=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
push=Path('app/src/main/java/ir/bankmoviee/app/AdminPushJobService.kt').read_text()
loader=Path('app/src/main/java/ir/bankmoviee/app/OrbitalGlowLoaderView.kt').read_text()
tools=Path('SITE_PATCH_V11/_lider/tools/bm_admin.php').read_text()
center=Path('SITE_PATCH_V11/_lider/admin_control_center.php').read_text()
admin=Path('SITE_PATCH_V11/_lider/admin.php').read_text()
index=Path('SITE_PATCH_V11/index.php').read_text()
assert 'private fun sanitizeArchive(archive: Int)' in src and '5 -> 5' in src
assert 'remoteArchiveOrder.filter { archiveVisible(it) }' in src and 'bm_archive_order_v11' in src
assert 'archive5ApiUrl("section=' in src and 'archive5ApiUrl("id=' in src
# Poster cards now accept both string URLs and JSON objects (full/medium/url/etc.).
# Guard the new normalizer instead of requiring the removed direct optJSONObject call.
assert 'setOf(3, 4, 5)' in src
assert 'fun posterString(value: Any?)' in src
assert 'is JSONObject -> sequenceOf("full", "medium", "url", "src", "large", "original", "thumbnail")' in src
assert 'posterString(item.opt(key))' in src and 'item.put("poster", poster)' in src
assert 'LocalNotificationStore.unreadCount(this@MainActivity)' in src
assert 'refreshBell()' in src and 'UiPreferences.accentColor(this@MainActivity)' in src
assert 'recent.sortedBy' in push and '30L * 60L * 1000L' in push
assert 'UiPreferences.accentColor(context)' in loader
assert 'bm_v11_archive_order_enabled' in tools and 'bm_v11_watchlist_quota' in tools
assert "2=>'آرشیو ۲'" in tools and "5=>'آرشیو ۵'" in tools
assert "foreach ([6,7] as $siteArchiveNumber)" in tools
assert 'bm_ad_archive_dashboard_data()' in tools
assert 'bm_archive_order_from_post' in admin and 'watchlist_free_limit' in admin
assert 'foreach (bm_archive_known_ids() as $id)' in center
assert 'bm_archive_should_render_tab($bmAid' in index
assert "in_array($bmAid, ['archive6','archive7'], true)" not in index
print('V11_SOURCE_CONTRACTS_OK')
PYCHK
for path in SITE_PATCH_V11/index.php SITE_PATCH_V11/_lider/*.php SITE_PATCH_V11/_lider/tools/*.php; do php -l "$path" >/dev/null; done
echo V11_PHP_AND_ANDROID_SOURCE_CHECKS_OK
