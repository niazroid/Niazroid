<?php
/** BankMovie V22.5.7 comment identity reconciliation.
 * Shared by the website and Android API. All SELECTs: never migrates votes/replies.
 */
if (!function_exists('bm_comment_thread_identity')) {
    function bm_comment_thread_lower(string $value): string {
        return function_exists('mb_strtolower') ? mb_strtolower($value, 'UTF-8') : strtolower($value);
    }
    function bm_comment_thread_identity(string $slug, int $archive): string {
        $slug = trim($slug);
        if ($slug === '') return '';
        // Official permalink and query-string format are both accepted.
        if (preg_match('~^https?://~i', $slug) || str_contains($slug, 'movie.php?')) {
            $parts = @parse_url($slug);
            if (is_array($parts)) {
                parse_str((string)($parts['query'] ?? ''), $qs);
                if (isset($qs['arc']) && (int)$qs['arc'] !== $archive) return '';
                if (!empty($qs['slug'])) $slug = (string)$qs['slug'];
                elseif (preg_match('~(?:^|/)movie/arc([1345])-([^/?#]+)~i', (string)($parts['path'] ?? ''), $m)) {
                    if ((int)$m[1] !== $archive) return '';
                    $slug = $m[2];
                }
            }
        }
        $slug = trim(rawurldecode($slug), "/ \t\n\r");
        $slug = preg_replace('~^arc[134567]-~i', '', $slug);
        $slug = preg_replace('~^[0-9]{3,}__~', '', $slug);
        return bm_comment_thread_lower($slug);
    }
    function bm_comment_thread_hash(int $archive, string $slug): int {
        return 1000000000 + (abs(crc32('arc'.$archive.':'.$slug)) % 1000000000);
    }
    function bm_comment_thread_group(PDO $pdo, int $archive, string $slug, int $incomingId,
                                     string $title = '', string $year = ''): array {
        $archive = in_array($archive, [1,3,4,5,6,7], true) ? $archive : 1;
        $rawSlug = trim(rawurldecode($slug), "/ \t\n\r");
        $normalized = bm_comment_thread_identity($rawSlug, $archive);
        if ($normalized === '') return ['id'=>$incomingId, 'ids'=>[$incomingId]];
        $year = trim($year);
        $title = trim($title);
        $normalizedId = bm_comment_thread_hash($archive, $normalized);
        // Valid historical exact slugs; incomingId is NOT trusted unconditionally.
        $slugVariants = [$normalized, $rawSlug];
        $matches = [];
        $candidateRows = [];
        try {
            $stmt = $pdo->prepare('SELECT virtual_movie_id, slug, item_link, item_title, item_title_fa, item_year, item_type
                                   FROM archive1_items
                                   WHERE archive_no=? AND (slug=? OR slug=? OR slug LIKE ? OR item_title=? OR item_title_fa=?) LIMIT 200');
            $stmt->execute([$archive, $rawSlug, $normalized, '%__'.$normalized, $title, $title]);
            $candidateRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (Throwable $error) {
            error_log('BM comment identity SELECT: '.$error->getMessage());
            // A legacy database without item_link must still resolve safely.
            try {
                $stmt = $pdo->prepare('SELECT virtual_movie_id, slug, item_title, item_title_fa, item_year, item_type
                                       FROM archive1_items WHERE archive_no=? AND (slug=? OR slug=? OR slug LIKE ? OR item_title=? OR item_title_fa=?) LIMIT 200');
                $stmt->execute([$archive, $rawSlug, $normalized, '%__'.$normalized, $title, $title]);
                $candidateRows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            } catch (Throwable $ignored) {}
        }
        $anchorType = '';
        foreach ($candidateRows as $row) {
            if (bm_comment_thread_identity((string)($row['slug'] ?? ''), $archive) === $normalized) {
                $anchorType = bm_comment_thread_lower(trim((string)($row['item_type'] ?? '')));
                if ($anchorType !== '') break;
            }
        }
        foreach ($candidateRows as $row) {
            $rowSlug = trim((string)($row['slug'] ?? ''));
            $slugMatches = bm_comment_thread_identity($rowSlug, $archive) === $normalized;
            $rowYear = trim((string)($row['item_year'] ?? ''));
            if ($year !== '' && $year !== '0' && $rowYear !== '' && $rowYear !== '0' && $year !== $rowYear) continue;
            $rowTitle = trim((string)($row['item_title'] ?? ''));
            $rowFa = trim((string)($row['item_title_fa'] ?? ''));
            $titleMatches = $title !== '' && (
                bm_comment_thread_lower($title) === bm_comment_thread_lower($rowTitle) ||
                bm_comment_thread_lower($title) === bm_comment_thread_lower($rowFa));
            $strongTitleYear = $titleMatches && $year !== '' && $year !== '0' && $rowYear !== '' && $rowYear !== '0' && $year === $rowYear;
            $rowType = bm_comment_thread_lower(trim((string)($row['item_type'] ?? '')));
            if (!$slugMatches && (!$strongTitleYear || $anchorType === '' || $rowType !== $anchorType)) continue;
            $id=(int)($row['virtual_movie_id'] ?? 0);
            if ($id <= 0) continue;
            $matches[] = $id;
            $slugVariants[] = $rowSlug;
            // Existing records can preserve a URL containing an older slug.
            $linkSlug = bm_comment_thread_identity((string)($row['item_link'] ?? ''), $archive);
            if ($linkSlug !== '' && $linkSlug === $normalized) $slugVariants[] = $linkSlug;
        }
        $candidates = [$normalizedId];
        foreach (array_unique($slugVariants) as $variant) {
            $variant = trim($variant);
            if ($variant === '') continue;
            // Only include unprefixed IDs for this recognized archive/slug family.
            $candidates[] = bm_comment_thread_hash($archive, $variant);
        }
        $candidates = array_merge($candidates, $matches);
        // The caller may supply a historically stored id only if we can prove it
        // belongs to one of the accepted slug variants or metadata rows.
        if (in_array($incomingId, $candidates, true)) $candidates[] = $incomingId;
        $candidates = array_values(array_unique(array_filter(array_map('intval',$candidates), static fn($id) => $id > 0)));
        sort($candidates, SORT_NUMERIC);
        $canonical = $matches ? min($matches) : $normalizedId;
        return ['id'=>$canonical, 'ids'=>$candidates];
    }
}
