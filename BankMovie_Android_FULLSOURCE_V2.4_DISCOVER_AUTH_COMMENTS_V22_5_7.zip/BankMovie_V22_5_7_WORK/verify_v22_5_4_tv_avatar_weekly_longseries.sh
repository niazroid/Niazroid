#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
php -l server-required/app_api.php >/dev/null
php -l server-required/app_user_api.php >/dev/null
php -l SITE_PATCH_REQUIRED/app_user_api.php >/dev/null
php -l SITE_PATCH_REQUIRED/includes/user_avatar.php >/dev/null
php -l SITE_PATCH_REQUIRED/includes/bm_account_weekly.php >/dev/null
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=Path('server-required/app_user_api.php').read_text()
s=Path('server-required/app_api.php').read_text()
u=Path('SITE_PATCH_REQUIRED/includes/user_avatar.php').read_text()
e=Path('app/src/main/java/ir/bankmoviee/app/ExplorerActivity.kt').read_text()
for x in ('bm_account_credential_limits','username_changed_at','password_changed_at',
          'SELECT password, username FROM users WHERE id = ? AND status = ? FOR UPDATE',
          'ACCOUNT_WEEKLY_LIMIT','DELETE FROM user_sessions WHERE user_id = ?'):
    assert x in a, x
for x in ('showAccountSecurityDialog(false)','showAccountSecurityDialog(true)',
          'showAvatarGroup(selectedGroup)','actorAvatars.chunked(24)',
          'if (isTvLike()) {','private fun nextEpisodesButton',
          'private fun loadNextEpisodePage',
          'nextEpisodesButton(item)','legacyTvSectionHeader',
          'bm_site_neon_movie','bm_site_neon_series',
          'bm_site_neon_anime','bm_site_neon_animation'):
    assert x in m, x
assert 'add(t("چی ببینیم؟", "Discover")' in m
assert 'if (!tv) { // Video Explorer previews/remote network calls are mobile-only.' in m
assert 'packageManager.hasSystemFeature("android.software.leanback")' in e
for x in ('function bm_app_downloads_from_db_movie','bm_app_archive_apply_payload_policy'):
    assert x in s, x
assert "'actor_' . str_pad" in a and "'actor_' . str_pad" in u
assets=list(Path('SITE_PATCH_REQUIRED/assets/avatars').glob('actor_*.webp'))
assert len(assets)==150, len(assets)
assert all(f.stat().st_size>2000 for f in assets)
assert 'archive5' in m and 'archive5ApiUrl' in m
print('VERIFY_V22_5_4_TV_AVATAR_WEEKLY_LONGSERIES_OK')
PYTEST
