<?php
require __DIR__ . '/server-required/includes/bm_comment_identity.php';
class BMStubStatement extends PDOStatement {
    public function __construct(private array $rows) {}
    public function execute(?array $params = null): bool { return true; }
    public function fetchAll(int $mode = PDO::FETCH_DEFAULT, mixed ...$args): array { return $this->rows; }
}
class BMStubPdo extends PDO {
    public function __construct(private array $rows) {}
    public function prepare(string $query, array $options = []): PDOStatement|false { return new BMStubStatement($this->rows); }
}
$rows = [
 ['virtual_movie_id'=>1097180657, 'slug'=>'76906__spider-man-brand-new-day','item_title'=>'Spider-Man: Brand New Day','item_title_fa'=>'','item_year'=>'2026','item_type'=>'movie'],
 ['virtual_movie_id'=>1503453644, 'slug'=>'spider-man-brand-new-day','item_title'=>'Spider-Man: Brand New Day','item_title_fa'=>'','item_year'=>'0','item_type'=>'movie'],
];
$db = new BMStubPdo($rows);
$a = bm_comment_thread_group($db, 1, '76906__spider-man-brand-new-day', 1097180657, 'Spider-Man: Brand New Day', '2026');
$b = bm_comment_thread_group($db, 1, 'spider-man-brand-new-day', 1503453644, 'Spider-Man: Brand New Day', '2026');
assert($a['id'] === $b['id']);
assert(in_array(1097180657,$a['ids'],true) && in_array(1503453644,$b['ids'],true));
assert($a['ids'] === $b['ids']);
$different = bm_comment_thread_group($db, 1, 'spider-man-brand-new-day', 1503453644, 'Spider-Man: Brand New Day', '2024');
assert(!in_array(1097180657, $different['ids'], true), 'Different known years must not alias');
echo 'BM_COMMENT_ALIAS_PARITY_OK: '.json_encode($a).PHP_EOL;
