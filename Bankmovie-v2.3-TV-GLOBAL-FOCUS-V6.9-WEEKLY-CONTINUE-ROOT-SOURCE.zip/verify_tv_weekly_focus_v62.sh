#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# Weekly Schedule must remain part of TV Home and have an explicit focus bridge.
need "$MAIN" 'addWeeklyScheduleSection(homeBody, bootJson?.optJSONObject("weekly_schedule"))'
need "$MAIN" 'private data class HomeTvWeeklyFocusRegistration('
need "$MAIN" 'private var tvHomeWeeklyFocusRegistration: HomeTvWeeklyFocusRegistration? = null'
need "$MAIN" 'private fun homeTvWeeklyEntryTarget(): View?'
need "$MAIN" 'private fun handleHomeWeeklyDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleHomeWeeklyDirectionalFocus(focused, keyCode)?.let { return it }'
need "$MAIN" 'private fun requestHomeTvWeeklyEntry(): Boolean'
need "$MAIN" 'else requestHomeTvWeeklyEntry()'
need "$MAIN" 'wireHomeWeeklyFocus()'
need "$MAIN" 'tag = "bm_home_telegram"'
need "$MAIN" '(items.firstOrNull() ?: telegram)?.let { tab.nextFocusDownId = it.id }'
need "$MAIN" 'telegram?.let { item.nextFocusDownId = it.id }'

# Weekly day rebuilds must preserve real focus instead of letting Android jump mid-page.
need "$MAIN" 'isSelected = active'
need "$MAIN" 'val restoreTabFocus = tv && (clicked.hasFocus() || isDescendantOf(currentFocus, clicked))'
need "$MAIN" 'tabsRow.getChildAtOrNull(selectedIndex)?.let { requestHomeTvFocus(it) }'

# A transient home-feed timeout must not erase a previously valid Weekly schedule.
need "$MAIN" 'weekly_schedule_cache_v2'
need "$MAIN" 'val weeklyMaxAge = 7L * 24L * 60L * 60L * 1000L'

# Home rebuild must never keep a Weekly registration from a previous generation.
need "$MAIN" 'tvHomeWeeklyFocusRegistration = null'

echo 'TV_WEEKLY_FOCUS_V62_OK'
