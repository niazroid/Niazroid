package ir.bankmoviee.app

import android.app.Activity
import android.app.Application
import android.os.Bundle

class BankmovieApplication : Application(), Application.ActivityLifecycleCallbacks {
    override fun onCreate() {
        super.onCreate()
        // Store crash details for the next manual diagnostic submission. Never swallow crashes.
        val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            BmDiagnostics.record(this, "uncaught_crash:${thread.name}", error = error)
            if (previousHandler != null) previousHandler.uncaughtException(thread, error)
            else android.os.Process.killProcess(android.os.Process.myPid())
        }
        // V7.47.1.20: native appearance is local-only; drop any legacy bridge
        // state before account refresh or website profile data can be consumed.
        UiPreferences.detachAppAppearanceFromWebsite(this)
        registerActivityLifecycleCallbacks(this)
        BankMoviePush.ensureSubscribed(this)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        RemoteTextStore.install(activity)
    }

    override fun onActivityResumed(activity: Activity) {
        RemoteTextStore.install(activity)
    }

    override fun onActivityStarted(activity: Activity) = Unit
    override fun onActivityPaused(activity: Activity) = Unit
    override fun onActivityStopped(activity: Activity) = Unit
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
    override fun onActivityDestroyed(activity: Activity) = Unit
}
