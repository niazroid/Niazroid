#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V6.9 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V6.9 WEEKLY CONTINUE ROOT'
need "$MARKER" 'verifierPatch=V6.9 WEEKLY+CONTINUE DIRECT ROUTER'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V69-20260907'
need 'app/build.gradle' 'versionName "2.3"'

# V6.9 must own these two surfaces before V6.8 compatibility routing.
need "$MAIN" 'private fun handleV69WeeklyContinueDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleV69WeeklyContinueDirectionalFocus(focused, keyCode)?.let { return it }'
need "$MAIN" 'private fun v69MoveIfConfirmed(target: View?): Boolean?'
need "$MAIN" 'return if (requestTvFocusVerified(view)) true else null'
need "$MAIN" 'tag == "bm_v69_surface_weekly"'

# Weekly first render: direct/native sequence and frame-stable rewiring.
need "$MAIN" 'private fun wireV69WeeklySurface()'
need "$MAIN" 'tab.tag = "bm_v69_weekly_tab_$index"'
need "$MAIN" 'item.tag = "bm_v69_weekly_item_$index"'
need "$MAIN" 'selectedTab.nextFocusDownId = firstItem.id'
need "$MAIN" 'item.setOnKeyListener { _, keyCode, event ->'
need "$MAIN" 'section.postOnAnimation {'
need "$MAIN" 'wireV69WeeklySurface()'
need "$MAIN" 'return requestTvFocusVerified(v69WeeklyItems(registration).firstOrNull())'

# Continue profile entry is content-first; View all is horizontal end-cap only.
need "$MAIN" 'private fun wireV69ContinueRail(header: View, row: ViewGroup)'
need "$MAIN" 'card.tag = "bm_v69_continue_rail_item_$index"'
need "$MAIN" 'private fun v69ProfileContinueAboveTargets(): List<View>'
need "$MAIN" 'source.nextFocusDownId = first.id'
need "$MAIN" 'last.nextFocusLeftId = moreView.id'
need "$MAIN" 'moreView.nextFocusRightId = last.id'
need "$MAIN" 'v69MoveIfConfirmed(cards.getOrNull(index + 1) ?: more) == true'

python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
# Active Weekly/Continue paths must not call the V6.8 routers anymore.
if s.count('wireV68WeeklySurface()') != 1:  # declaration only
    raise SystemExit('V6.9 guard failed: active V6.8 Weekly wiring still exists')
if 'wireV68ContinueRail(continueHeader, row)' in s:
    raise SystemExit('V6.9 guard failed: profile Continue still invokes V6.8 rail wiring')
# Do not regress the two surfaces the user already confirmed fixed.
for marker in [
    'tag = "bm_v68_surface_boxoffice"',
    'fun wireAdvancedFiltersTvV68()',
    'genericTvRouting = false',
]:
    if marker not in s:
        raise SystemExit('V6.9 unexpectedly removed confirmed-good V6.8 surface marker: ' + marker)
PY

echo 'TV_FOCUS_V69_WEEKLY_CONTINUE_ROOT_OK'
