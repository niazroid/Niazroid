# BankMovie Pass 6.1 — Kotlin Compile Fix

خطای `Assignment type mismatch: Boolean? / Boolean` در خواندن وضعیت فعال و مخفی آرشیو ۴ اصلاح شد. اکنون در صورت نبودن بخش `features.archives`، مقدار تنظیمات `archives.4` و سپس مقدار امن پیش‌فرض استفاده می‌شود.
