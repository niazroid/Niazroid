#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'

grep -F 'remoteArchive4Enabled = featureArchives?.optBoolean' "$MAIN"
grep -F '?: (archive4Config?.optBoolean("enabled", true) ?: true)' "$MAIN"
grep -F 'remoteArchive4Hidden = featureArchives?.optBoolean' "$MAIN"
grep -F '?: (archive4Config?.optBoolean("hidden", false) ?: false)' "$MAIN"

! grep -Fx '        remoteArchive4Enabled = featureArchives?.optBoolean("archive4_enabled", archive4Config?.optBoolean("enabled", true) ?: true)' "$MAIN"
! grep -Fx '        remoteArchive4Hidden = featureArchives?.optBoolean("archive4_hidden", archive4Config?.optBoolean("hidden", false) ?: false)' "$MAIN"

echo PASS6_1_KOTLIN_COMPILE_FIX_OK
