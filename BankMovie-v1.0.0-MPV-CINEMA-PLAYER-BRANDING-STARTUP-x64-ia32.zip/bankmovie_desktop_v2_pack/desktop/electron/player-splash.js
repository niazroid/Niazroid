'use strict';
const fs=require('fs'),path=require('path');
// Milestones originate in the privileged launcher or MPV, never the renderer.
const stages={prepare:[10,'آماده‌سازی پلیر'],spawn:[30,'در حال اجرای موتور MPV'],opening:[45,'در حال اتصال و باز کردن رسانه'],loaded:[70,'رسانه باز شد؛ آماده‌سازی پخش'],ready:[100,'آماده پخش']};
function readStage(dir){for(const name of ['error','ready','loaded','opening']){try{if(fs.existsSync(path.join(dir,name)))return name;}catch{}}return '';}
class PlayerSplash{
 constructor({BrowserWindow,temp,dialog,owner,timeout=90000}){
  this.dir=fs.mkdtempSync(path.join(temp,'bm-player-start-'));this.dialog=dialog;this.owner=owner;this.finished=false;this.cancelled=false;this.stage='prepare';
  try{
   this.window=new BrowserWindow({width:760,height:391,useContentSize:true,frame:false,resizable:false,fullscreenable:false,alwaysOnTop:true,skipTaskbar:true,show:false,backgroundColor:'#030b17',icon:path.join(__dirname,'../src/assets/bankmovie-icon.png'),webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true,preload:path.join(__dirname,'player-splash-preload.js')}});
   const w=this.window;w.webContents.setWindowOpenHandler(()=>({action:'deny'}));w.webContents.on('will-navigate',e=>e.preventDefault());w.webContents.on('will-frame-navigate',e=>e.preventDefault());
   w.webContents.on('before-input-event',(e,input)=>{if(input.key==='Escape'&&input.type==='keyDown'){e.preventDefault();this.cancel();}});
   w.on('closed',()=>{if(!this.finished)this.cancel();});w.webContents.on('did-finish-load',()=>{if(!this.finished&&!w.isDestroyed())this.update(this.stage);});
   w.once('ready-to-show',()=>{if(!this.finished&&!w.isDestroyed())w.show();});
   w.loadFile(path.join(__dirname,'player-splash.html')).catch(()=>{if(!this.finished)this.fail('نمایش صفحه آماده‌سازی ناموفق بود.');});
   this.timer=setInterval(()=>this.poll(),100);this.deadline=setTimeout(()=>this.fail('آماده شدن پلیر بیش از حد طول کشید. اتصال یا لینک پخش را بررسی کنید.'),timeout);
  }catch(e){this.finish(true);throw e;}
 }
 update(stage){if(this.finished||!stages[stage])return;if(stages[stage][0]<stages[this.stage][0])return;this.stage=stage;const w=this.window;if(w&&!w.isDestroyed()&&!w.webContents.isDestroyed())w.webContents.send('bm-player-splash:stage',stages[stage]);}
 poll(){if(this.finished)return;const s=readStage(this.dir);if(s==='error')this.fail('باز کردن یا رمزگشایی رسانه ناموفق بود.');else if(s==='ready'){this.update('ready');this.finish(false);}else if(s)this.update(s);}
 attach(child){this.child=child;if(this.cancelled){try{child.kill();}catch{}return;}if(this.finished)return;this.update('spawn');child.once('exit',()=>{if(!this.finished){this.poll();if(!this.finished)this.fail('پلیر پیش از آماده‌شدن بسته شد.');}});child.once('error',()=>{if(!this.finished)this.fail('اجرای موتور MPV ناموفق بود.');});}
 assertActive(){if(this.cancelled)throw Error('آماده‌سازی پلیر لغو شد.');}
 cancel(){this.finish(true);}
 fail(message){if(this.finished)return;this.finish(true);try{const opts={type:'error',title:'BankMovie Player',message,buttons:['باشه']};const p=this.owner&&!this.owner.isDestroyed()?this.dialog.showMessageBox(this.owner,opts):this.dialog.showMessageBox(opts);Promise.resolve(p).catch(()=>{});}catch{}}
 finish(kill=false){if(this.finished)return;this.finished=true;this.cancelled=kill;clearInterval(this.timer);clearTimeout(this.deadline);if(kill&&this.child)try{this.child.kill();}catch{}const w=this.window;if(w&&!w.isDestroyed())w.destroy();try{fs.rmSync(this.dir,{recursive:true,force:true});}catch{}}
}
module.exports={PlayerSplash,readStage,stages};
