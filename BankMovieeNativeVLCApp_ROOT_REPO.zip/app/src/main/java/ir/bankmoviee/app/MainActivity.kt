package ir.bankmoviee.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.SslErrorHandler
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var webView: WebView
    private lateinit var progressBar: ProgressBar
    private lateinit var offlineBox: View
    private lateinit var offlineText: TextView
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var fullScreenContainer: FrameLayout

    private val fileChooserRequestCode = 7001

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.bankWebView)
        progressBar = findViewById(R.id.webProgress)
        offlineBox = findViewById(R.id.offlineBox)
        offlineText = findViewById(R.id.offlineText)
        fullScreenContainer = findViewById(R.id.fullScreenContainer)

        CookieManager.getInstance().setAcceptCookie(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            allowFileAccess = false
            allowContentAccess = true
            userAgentString = userAgentString + AppConfig.USER_AGENT_SUFFIX
        }

        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        webView.webViewClient = BankMovieeWebViewClient()
        webView.webChromeClient = BankMovieeChromeClient()
        webView.setDownloadListener(BankMovieeDownloadListener())

        if (savedInstanceState == null) {
            webView.loadUrl(AppConfig.BASE_URL)
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onBackPressed() {
        when {
            customView != null -> hideCustomView()
            webView.canGoBack() -> webView.goBack()
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.destroy()
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == fileChooserRequestCode) {
            val callback = filePathCallback ?: return
            filePathCallback = null
            val result = WebChromeClient.FileChooserParams.parseResult(resultCode, data)
            callback.onReceiveValue(result)
        }
    }

    private fun openNativePlayer(playUri: Uri) {
        val videoUrl = playUri.getQueryParameter("video")
        if (!UrlTools.isHttpUrl(videoUrl)) {
            Toast.makeText(this, "لینک ویدیو معتبر نیست", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(this, PlayerActivity::class.java).apply {
            data = playUri
            putExtra(PlayerActivity.EXTRA_VIDEO_URL, videoUrl)
            putExtra(PlayerActivity.EXTRA_TITLE, playUri.getQueryParameter("title"))
            putExtra(PlayerActivity.EXTRA_SUBTITLE_URL, playUri.getQueryParameter("subtitle"))
            putExtra(PlayerActivity.EXTRA_REFERER, playUri.getQueryParameter("referer") ?: webView.url)
        }
        startActivity(intent)
    }

    private fun openDirectVideo(url: String) {
        val pageTitle = webView.title ?: "BankMoviee"
        val playUri = UrlTools.buildPlayUri(videoUrl = url, title = pageTitle, referer = webView.url)
        openNativePlayer(playUri)
    }

    private fun handleSpecialUri(uri: Uri?): Boolean {
        uri ?: return false
        val scheme = uri.scheme?.lowercase(Locale.US) ?: return false

        if (scheme == AppConfig.APP_SCHEME && uri.host == AppConfig.PLAY_HOST) {
            openNativePlayer(uri)
            return true
        }

        val raw = uri.toString()
        if (UrlTools.isDirectVideoUrl(raw)) {
            openDirectVideo(raw)
            return true
        }

        if (scheme == "intent") {
            return try {
                val intent = Intent.parseUri(raw, Intent.URI_INTENT_SCHEME)
                startActivity(intent)
                true
            } catch (_: Exception) {
                true
            }
        }

        if (scheme in listOf("tel", "mailto", "sms", "tg", "whatsapp")) {
            return try {
                startActivity(Intent(Intent.ACTION_VIEW, uri))
                true
            } catch (_: ActivityNotFoundException) {
                true
            }
        }

        return false
    }

    private fun injectBankMovieeBridge() {
        val js = """
            (function(){
                if (window.__BankMovieeNativeBridgeInstalled) return;
                window.__BankMovieeNativeBridgeInstalled = true;

                function enc(v){ return encodeURIComponent(v || ''); }
                function firstText(selectors){
                    for (var i=0;i<selectors.length;i++){
                        var el = document.querySelector(selectors[i]);
                        if (el && el.textContent && el.textContent.trim()) return el.textContent.trim();
                    }
                    return document.title || 'BankMoviee';
                }
                function absUrl(url){
                    try { return new URL(url, location.href).href; } catch(e){ return url || ''; }
                }
                function findSubtitleNear(btn){
                    var raw = btn.getAttribute('data-subtitle') || btn.getAttribute('data-sub') || btn.getAttribute('data-srt') || '';
                    if (raw) return absUrl(raw);
                    var box = btn.closest('.download-link,.arc1-link-row,.premium-download-card,.arc1-ep-card,.download-section');
                    if (!box) return '';
                    var sub = box.querySelector('[data-subtitle],[data-sub],[data-srt]');
                    if (sub) return absUrl(sub.getAttribute('data-subtitle') || sub.getAttribute('data-sub') || sub.getAttribute('data-srt') || '');
                    var a = box.querySelector('a[href$=".srt"],a[href$=".ass"],a[href$=".ssa"],a[href$=".vtt"]');
                    if (a) return absUrl(a.href);
                    return '';
                }
                function openNative(btn, url){
                    if (!url) return false;
                    url = absUrl(url);
                    if (!/^https?:\/\//i.test(url)) return false;
                    var title = firstText(['.movie-title-fa','.movie-title-en','.movie-title','h1']);
                    var label = btn.getAttribute('data-label') || '';
                    var season = btn.getAttribute('data-season') || '';
                    var episode = btn.getAttribute('data-episode') || '';
                    var subtitle = findSubtitleNear(btn);
                    var deep = 'bankmoviee://play?video=' + enc(url)
                        + '&title=' + enc(title)
                        + '&label=' + enc(label)
                        + '&season=' + enc(season)
                        + '&episode=' + enc(episode)
                        + '&subtitle=' + enc(subtitle)
                        + '&referer=' + enc(location.href);
                    location.href = deep;
                    return true;
                }

                document.addEventListener('click', function(e){
                    var btn = e.target && e.target.closest ? e.target.closest('.arc1-play-btn,[data-bm-native-play],a[href^="bankmoviee://play"]') : null;
                    if (!btn) return;
                    var href = btn.getAttribute('href') || '';
                    if (href.indexOf('bankmoviee://play') === 0) return;
                    var url = btn.getAttribute('data-url') || btn.getAttribute('data-video') || href;
                    if (openNative(btn, url)) {
                        e.preventDefault();
                        e.stopPropagation();
                        if (e.stopImmediatePropagation) e.stopImmediatePropagation();
                    }
                }, true);

                document.addEventListener('submit', function(){}, true);
                console.log('BankMoviee Android native VLC bridge is active');
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun showCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
        if (customView != null) {
            callback.onCustomViewHidden()
            return
        }
        customView = view
        customViewCallback = callback
        fullScreenContainer.visibility = View.VISIBLE
        fullScreenContainer.addView(view, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        webView.visibility = View.GONE
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    private fun hideCustomView() {
        val view = customView ?: return
        fullScreenContainer.removeView(view)
        fullScreenContainer.visibility = View.GONE
        webView.visibility = View.VISIBLE
        customView = null
        customViewCallback?.onCustomViewHidden()
        customViewCallback = null
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
    }

    private inner class BankMovieeWebViewClient : WebViewClient() {
        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
            val uri = request?.url ?: return false
            if (handleSpecialUri(uri)) return true
            return false
        }

        @Deprecated("Deprecated in Java")
        override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
            val uri = url?.let { Uri.parse(it) } ?: return false
            if (handleSpecialUri(uri)) return true
            return false
        }

        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
            progressBar.visibility = View.VISIBLE
            offlineBox.visibility = View.GONE
        }

        override fun onPageFinished(view: WebView?, url: String?) {
            progressBar.visibility = View.GONE
            injectBankMovieeBridge()
        }

        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
            super.onReceivedHttpError(view, request, errorResponse)
            if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 500) {
                offlineText.text = "مشکل موقت در اتصال به سایت. دوباره تلاش کن."
                offlineBox.visibility = View.VISIBLE
            }
        }

        override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
            // برای امنیت کاربر خطای SSL را رد می‌کنیم. اگر هاست SSL مشکل داشته باشد باید روی سرور حل شود.
            handler?.cancel()
            offlineText.text = "خطای امنیتی SSL. گواهی سایت را بررسی کن."
            offlineBox.visibility = View.VISIBLE
        }
    }

    private inner class BankMovieeChromeClient : WebChromeClient() {
        override fun onProgressChanged(view: WebView?, newProgress: Int) {
            progressBar.progress = newProgress
            progressBar.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE
        }

        override fun onShowFileChooser(
            webView: WebView?,
            filePathCallback: ValueCallback<Array<Uri>>?,
            fileChooserParams: FileChooserParams?
        ): Boolean {
            this@MainActivity.filePathCallback?.onReceiveValue(null)
            this@MainActivity.filePathCallback = filePathCallback
            return try {
                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                }
                startActivityForResult(intent, fileChooserRequestCode)
                true
            } catch (_: ActivityNotFoundException) {
                this@MainActivity.filePathCallback = null
                false
            }
        }

        override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
            if (view != null && callback != null) showCustomView(view, callback)
        }

        override fun onHideCustomView() {
            hideCustomView()
        }
    }

    private inner class BankMovieeDownloadListener : DownloadListener {
        override fun onDownloadStart(url: String?, userAgent: String?, contentDisposition: String?, mimeType: String?, contentLength: Long) {
            if (UrlTools.isDirectVideoUrl(url)) {
                openDirectVideo(url!!)
                return
            }
            if (!UrlTools.isHttpUrl(url)) return
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimeType)
                request.addRequestHeader("User-Agent", userAgent ?: webView.settings.userAgentString)
                CookieManager.getInstance().getCookie(url)?.let { request.addRequestHeader("Cookie", it) }
                request.setTitle("BankMoviee Download")
                request.setDescription("در حال دانلود فایل")
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, Uri.parse(url).lastPathSegment ?: "bankmoviee_file")
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(request)
                Toast.makeText(this@MainActivity, "دانلود شروع شد", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "دانلود مستقیم توسط سیستم ممکن نشد", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
