package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_SUBTITLE_URL = "subtitle_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_REFERER = "referer"
        private const val REQUEST_SUBTITLE = 8101
    }

    private lateinit var vlcLayout: VLCVideoLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var statusText: TextView
    private lateinit var currentTimeText: TextView
    private lateinit var durationText: TextView
    private lateinit var playPauseBtn: ImageButton
    private lateinit var seekBar: SeekBar

    private var libVLC: LibVLC? = null
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isSeeking = false
    private var controlsVisible = true
    private var externalSubtitleApplied = false
    private var videoUrl: String = ""
    private var subtitleUrl: String = ""
    private var referer: String = ""

    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
        setContentView(R.layout.activity_player)

        bindViews()
        readIntent()
        setupControls()

        if (!UrlTools.isHttpUrl(videoUrl)) {
            Toast.makeText(this, "لینک پخش معتبر نیست", Toast.LENGTH_LONG).show()
            finish()
            return
        }

        titleText.text = intent.getStringExtra(EXTRA_TITLE)?.takeIf { it.isNotBlank() } ?: "BankMoviee Player"
        startVlc(videoUrl)
    }

    private fun bindViews() {
        vlcLayout = findViewById(R.id.vlcVideoLayout)
        topBar = findViewById(R.id.playerTopBar)
        bottomBar = findViewById(R.id.playerBottomBar)
        titleText = findViewById(R.id.playerTitle)
        statusText = findViewById(R.id.playerStatus)
        currentTimeText = findViewById(R.id.currentTime)
        durationText = findViewById(R.id.durationTime)
        playPauseBtn = findViewById(R.id.playPauseBtn)
        seekBar = findViewById(R.id.seekBar)
    }

    private fun readIntent() {
        val data = intent.data
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL)
            ?: data?.getQueryParameter("video")
            ?: ""
        subtitleUrl = intent.getStringExtra(EXTRA_SUBTITLE_URL)
            ?: data?.getQueryParameter("subtitle")
            ?: ""
        referer = intent.getStringExtra(EXTRA_REFERER)
            ?: data?.getQueryParameter("referer")
            ?: ""
    }

    private fun setupControls() {
        findViewById<ImageButton>(R.id.closeBtn).setOnClickListener { finish() }
        playPauseBtn.setOnClickListener { togglePlayPause() }
        findViewById<ImageButton>(R.id.rewindBtn).setOnClickListener { seekBy(-10_000) }
        findViewById<ImageButton>(R.id.forwardBtn).setOnClickListener { seekBy(10_000) }
        findViewById<ImageButton>(R.id.audioBtn).setOnClickListener { showAudioTracks() }
        findViewById<ImageButton>(R.id.subtitleBtn).setOnClickListener { showSubtitleTracks() }
        findViewById<ImageButton>(R.id.addSubtitleBtn).setOnClickListener { pickSubtitleFile() }
        findViewById<ImageButton>(R.id.rotateBtn).setOnClickListener { toggleOrientation() }

        findViewById<View>(R.id.playerRoot).setOnClickListener { toggleControls() }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) { isSeeking = true }
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                val mp = mediaPlayer ?: return
                val length = mp.length
                if (length > 0) {
                    val target = (seekBar?.progress ?: 0) * length / 1000L
                    mp.time = target
                }
                isSeeking = false
            }
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) {
                    val length = mediaPlayer?.length ?: 0L
                    if (length > 0) currentTimeText.text = formatMs(progress * length / 1000L)
                }
            }
        })
    }

    private fun startVlc(url: String) {
        statusText.text = "در حال آماده‌سازی پلیر VLC..."

        val args = arrayListOf(
            "--network-caching=2500",
            "--file-caching=2500",
            "--live-caching=2500",
            "--http-reconnect",
            "--audio-time-stretch",
            "--subsdec-encoding=UTF-8",
            "--android-display-chroma=RV32"
        )

        libVLC = LibVLC(this, args)
        mediaPlayer = MediaPlayer(libVLC).apply {
            attachViews(vlcLayout, null, false, false)
            setEventListener { event ->
                runOnUiThread {
                    when (event.type) {
                        MediaPlayer.Event.Opening -> statusText.text = "در حال باز کردن لینک..."
                        MediaPlayer.Event.Buffering -> statusText.text = "بافر: ${event.buffering.toInt()}٪"
                        MediaPlayer.Event.Playing -> {
                            statusText.text = "در حال پخش با موتور VLC"
                            setPlayIcon(false)
                            applyExternalSubtitleIfNeeded()
                        }
                        MediaPlayer.Event.Paused -> {
                            statusText.text = "توقف موقت"
                            setPlayIcon(true)
                        }
                        MediaPlayer.Event.Stopped -> setPlayIcon(true)
                        MediaPlayer.Event.EndReached -> {
                            statusText.text = "پخش تمام شد"
                            setPlayIcon(true)
                        }
                        MediaPlayer.Event.EncounteredError -> {
                            statusText.text = "خطا در پخش. لینک یا دسترسی سرور را بررسی کن."
                            Toast.makeText(this, "خطا در پخش ویدیو", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
        }

        val media = Media(libVLC, Uri.parse(url)).apply {
            setHWDecoderEnabled(true, false)
            addOption(":network-caching=2500")
            addOption(":http-reconnect")
            addOption(":http-user-agent=Mozilla/5.0 BankMovieeAndroid/1.0")
            if (referer.isNotBlank()) addOption(":http-referrer=$referer")
        }

        mediaPlayer?.media = media
        media.release()
        mediaPlayer?.play()
        handler.post(progressRunnable)
    }

    private fun applyExternalSubtitleIfNeeded() {
        if (externalSubtitleApplied) return
        if (!UrlTools.isSubtitleUrl(subtitleUrl)) return
        try {
            mediaPlayer?.addSlave(Media.Slave.Type.Subtitle, subtitleUrl, true)
            externalSubtitleApplied = true
            Toast.makeText(this, "زیرنویس خارجی اضافه شد", Toast.LENGTH_SHORT).show()
        } catch (_: Throwable) {
            Toast.makeText(this, "زیرنویس خارجی اضافه نشد", Toast.LENGTH_SHORT).show()
        }
    }

    private fun togglePlayPause() {
        val mp = mediaPlayer ?: return
        if (mp.isPlaying) mp.pause() else mp.play()
    }

    private fun seekBy(deltaMs: Long) {
        val mp = mediaPlayer ?: return
        val length = mp.length
        val next = if (length > 0) min(max(mp.time + deltaMs, 0L), length) else max(mp.time + deltaMs, 0L)
        mp.time = next
        updateProgress()
    }

    private fun updateProgress() {
        if (isSeeking) return
        val mp = mediaPlayer ?: return
        val length = mp.length
        val time = mp.time
        currentTimeText.text = formatMs(time)
        durationText.text = if (length > 0) formatMs(length) else "--:--"
        if (length > 0) seekBar.progress = ((time * 1000L) / length).toInt().coerceIn(0, 1000)
    }

    private fun showAudioTracks() {
        val mp = mediaPlayer ?: return
        val tracks = mp.audioTracks?.toList().orEmpty()
        if (tracks.isEmpty()) {
            Toast.makeText(this, "ترک صوتی پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val names = tracks.map { it.name ?: "Audio ${it.id}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("انتخاب صدا")
            .setItems(names) { _, which ->
                mp.setAudioTrack(tracks[which].id)
                Toast.makeText(this, names[which], Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun showSubtitleTracks() {
        val mp = mediaPlayer ?: return
        val list = mutableListOf<Pair<Int, String>>()
        list.add(-1 to "خاموش")
        mp.spuTracks?.forEach { list.add(it.id to (it.name ?: "Subtitle ${it.id}")) }

        if (list.size == 1) {
            Toast.makeText(this, "زیرنویس داخلی پیدا نشد؛ می‌تونی فایل SRT/ASS اضافه کنی", Toast.LENGTH_LONG).show()
        }

        AlertDialog.Builder(this)
            .setTitle("انتخاب زیرنویس")
            .setItems(list.map { it.second }.toTypedArray()) { _, which ->
                mp.setSpuTrack(list[which].first)
                Toast.makeText(this, list[which].second, Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun pickSubtitleFile() {
        try {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/x-subrip",
                    "text/plain",
                    "text/vtt",
                    "application/octet-stream"
                ))
            }
            startActivityForResult(intent, REQUEST_SUBTITLE)
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "فایل‌منیجر پیدا نشد", Toast.LENGTH_SHORT).show()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_SUBTITLE && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Throwable) {}
            try {
                mediaPlayer?.addSlave(Media.Slave.Type.Subtitle, uri.toString(), true)
                Toast.makeText(this, "زیرنویس اضافه شد", Toast.LENGTH_SHORT).show()
            } catch (_: Throwable) {
                Toast.makeText(this, "زیرنویس اضافه نشد", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun toggleOrientation() {
        requestedOrientation = if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        } else {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        }
    }

    private fun toggleControls() {
        controlsVisible = !controlsVisible
        val visibility = if (controlsVisible) View.VISIBLE else View.GONE
        topBar.visibility = visibility
        bottomBar.visibility = visibility
    }

    private fun setPlayIcon(showPlay: Boolean) {
        playPauseBtn.setImageResource(if (showPlay) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause)
    }

    private fun formatMs(ms: Long): String {
        val totalSeconds = max(0L, ms / 1000L)
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.US, "%02d:%02d", minutes, seconds)
        }
    }

    override fun onPause() {
        super.onPause()
        mediaPlayer?.pause()
    }

    override fun onResume() {
        super.onResume()
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        )
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try {
            mediaPlayer?.stop()
            mediaPlayer?.detachViews()
            mediaPlayer?.release()
            libVLC?.release()
        } catch (_: Throwable) {}
        super.onDestroy()
    }
}
