package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.documentfile.provider.DocumentFile
import org.json.JSONObject
import java.io.File
import java.util.Locale

/**
 * V7.46.5 offline-first media library.
 *
 * Only files completed by BankMovie's InternalDownloadService are shown here.
 * The screen does not make any network request: posters are read from the local
 * cache created when the download starts and playback uses the downloaded file.
 */
class OfflineLibraryActivity : Activity() {
    private companion object {
        const val FILTER_ALL = "all"
        const val FILTER_MOVIES = "movies"
        const val FILTER_SERIES = "series"
    }

    private lateinit var root: FrameLayout
    private lateinit var list: LinearLayout
    private lateinit var allTab: TextView
    private lateinit var moviesTab: TextView
    private lateinit var seriesTab: TextView
    private lateinit var summary: TextView
    private var filter = FILTER_ALL

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = UiPreferences.palette(this)
        window.statusBarColor = p.background
        window.navigationBarColor = p.background
        buildUi()
        refreshLibrary()
    }

    override fun onResume() {
        super.onResume()
        if (::list.isInitialized) refreshLibrary()
    }

    private fun buildUi() {
        val p = UiPreferences.palette(this)
        root = FrameLayout(this).apply { setBackgroundColor(p.background) }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(if (isTvLike()) 34 else 16), dp(18), dp(if (isTvLike()) 34 else 16), dp(34))
        }
        scroll.addView(page)
        root.addView(scroll, FrameLayout.LayoutParams(-1, -1))

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(TextView(this).apply {
            text = "کتابخانه آفلاین"
            setTextColor(p.text)
            textSize = if (isTvLike()) 26f else 22f
            typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        header.addView(TextView(this).apply {
            text = "‹"
            setTextColor(p.text)
            textSize = 32f
            gravity = Gravity.CENTER
            background = rounded(Color.argb(34, 255, 255, 255), dp(16), Color.argb(55, 255, 255, 255))
            isClickable = true
            isFocusable = true
            setOnClickListener { finish() }
            focusScale(this)
        }, LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginStart = dp(10) })
        page.addView(header)

        page.addView(TextView(this).apply {
            text = "فیلم‌ها و قسمت‌هایی که با دانلودر داخلی بانک مووی ذخیره شده‌اند؛ بدون اینترنت هم قابل پخش و مدیریت هستند."
            setTextColor(p.muted)
            textSize = 12.5f
            gravity = Gravity.RIGHT
            setLineSpacing(dp(2).toFloat(), 1.06f)
            setPadding(0, dp(8), 0, dp(14))
        })

        summary = TextView(this).apply {
            setTextColor(p.text)
            textSize = 13f
            typeface = BankmovieFonts.medium(this@OfflineLibraryActivity)
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            background = rounded(Color.argb(26, 255, 255, 255), dp(18), Color.argb(48, 255, 255, 255))
            setPadding(dp(14), dp(11), dp(14), dp(11))
        }
        page.addView(summary, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        val tabsScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        fun tab(label: String, key: String): TextView = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            textSize = 12.5f
            typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
            isClickable = true
            isFocusable = true
            setPadding(dp(18), 0, dp(18), 0)
            setOnClickListener { filter = key; refreshLibrary() }
            focusScale(this)
        }
        allTab = tab("همه", FILTER_ALL)
        moviesTab = tab("فیلم‌ها", FILTER_MOVIES)
        seriesTab = tab("سریال‌ها", FILTER_SERIES)
        tabs.addView(allTab, LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(6) })
        tabs.addView(moviesTab, LinearLayout.LayoutParams(-2, dp(44)).apply { marginEnd = dp(6) })
        tabs.addView(seriesTab, LinearLayout.LayoutParams(-2, dp(44)))
        tabsScroll.addView(tabs)
        page.addView(tabsScroll, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(12) })

        val manageRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        manageRow.addView(smallButton("مدیریت دانلودها", false) {
            startActivity(Intent(this, DownloadsActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginEnd = dp(5) })
        manageRow.addView(smallButton("پاکسازی موارد گم‌شده", true) { cleanupMissing() }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { marginStart = dp(5) })
        page.addView(manageRow, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(16) })

        list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        page.addView(list, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
    }

    private fun completedItems(): List<JSONObject> = InternalDownloadStore.all(this)
        .filter { it.optString("status") == InternalDownloadStore.STATUS_COMPLETED && InternalDownloadStore.exists(this, it) }

    private fun refreshLibrary() {
        if (!::list.isInitialized) return
        val all = completedItems()
        val movies = all.filterNot(::isSeriesItem)
        val series = all.filter(::isSeriesItem)
        summary.text = "${all.size} فایل آماده پخش  •  ${humanBytes(all.sumOf(::fileSize))}  •  ${movies.size} فیلم  •  ${series.size} قسمت سریال"
        bindTab(allTab, filter == FILTER_ALL)
        bindTab(moviesTab, filter == FILTER_MOVIES)
        bindTab(seriesTab, filter == FILTER_SERIES)
        list.removeAllViews()

        val visible = when (filter) {
            FILTER_MOVIES -> movies
            FILTER_SERIES -> series
            else -> all
        }
        if (visible.isEmpty()) {
            renderEmpty()
            return
        }

        if (filter != FILTER_SERIES && movies.any { it in visible }) {
            sectionTitle("فیلم‌ها", movies.count { it in visible })
            movies.filter { it in visible }
                .sortedByDescending { it.optLong("updated_at", it.optLong("created_at")) }
                .forEach { list.addView(mediaCard(it), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }) }
        }

        val visibleSeries = series.filter { it in visible }
        if (visibleSeries.isNotEmpty()) {
            val grouped = visibleSeries.groupBy { seriesGroupKey(it) }
                .toSortedMap(String.CASE_INSENSITIVE_ORDER)
            grouped.forEach { (_, items) ->
                val title = items.firstOrNull()?.optString("title").orEmpty().ifBlank { "سریال" }
                sectionTitle(title, items.size)
                items.sortedWith(compareBy<JSONObject> { it.optInt("season", 0).let { s -> if (s > 0) s else 9999 } }
                    .thenBy { it.optInt("episode", 0).let { e -> if (e > 0) e else 9999 } }
                    .thenBy { qualityRank(it.optString("quality")) })
                    .forEach { list.addView(mediaCard(it), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }) }
            }
        }
    }

    private fun renderEmpty() {
        val p = UiPreferences.palette(this)
        list.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = rounded(Color.argb(26, 255, 255, 255), dp(22), Color.argb(50, 255, 255, 255))
            setPadding(dp(20), dp(30), dp(20), dp(30))
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "هنوز فایل آفلاینی نداری"
                setTextColor(p.text)
                textSize = 18f
                typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
                gravity = Gravity.CENTER
            })
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "هر چیزی را با دانلودر داخلی بانک مووی دانلود کنی، بعد از کامل‌شدن اینجا می‌آید."
                setTextColor(p.muted)
                textSize = 12.5f
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(16))
            })
            addView(smallButton("رفتن به دانلودها", false) { startActivity(Intent(this@OfflineLibraryActivity, DownloadsActivity::class.java)) }, LinearLayout.LayoutParams(-1, dp(46)))
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun sectionTitle(title: String, count: Int) {
        val p = UiPreferences.palette(this)
        list.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), dp(10), dp(2), dp(8))
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = title
                setTextColor(p.text)
                textSize = 17f
                typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
                gravity = Gravity.RIGHT
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
            addView(TextView(this@OfflineLibraryActivity).apply {
                text = "$count فایل"
                setTextColor(p.muted)
                textSize = 11f
                gravity = Gravity.CENTER
                background = rounded(Color.argb(30, 255, 255, 255), dp(999), Color.argb(55, 255, 255, 255))
                setPadding(dp(10), dp(5), dp(10), dp(5))
            })
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun mediaCard(item: JSONObject): View {
        val p = UiPreferences.palette(this)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            background = rounded(Color.argb(30, 255, 255, 255), dp(20), Color.argb(58, 255, 255, 255))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER_VERTICAL
        }
        val poster = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = rounded(Color.argb(38, 255, 255, 255), dp(14), Color.argb(55, 255, 255, 255))
            val local = item.optString("poster_local_path")
            val bitmap = local.takeIf { it.isNotBlank() }?.let { runCatching { BitmapFactory.decodeFile(it) }.getOrNull() }
            if (bitmap != null) setImageBitmap(bitmap) else {
                setImageResource(R.drawable.bankmovie_logo_transparent)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(10), dp(10), dp(10), dp(10))
            }
        }
        top.addView(poster, LinearLayout.LayoutParams(dp(82), dp(112)).apply { marginEnd = dp(12) })
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.RIGHT }
        info.addView(TextView(this).apply {
            text = item.optString("title").ifBlank { "BankMovie" }
            setTextColor(p.text)
            textSize = 15.5f
            typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        })
        info.addView(TextView(this).apply {
            text = mediaMeta(item)
            setTextColor(p.muted)
            textSize = 11.6f
            gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, 0)
        })
        info.addView(TextView(this).apply {
            text = "${humanBytes(fileSize(item))}  •  ${item.optString("file_name").ifBlank { "فایل دانلودی" }}"
            setTextColor(p.muted)
            textSize = 10.7f
            gravity = Gravity.RIGHT
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.MIDDLE
            setPadding(0, dp(5), 0, 0)
        })
        top.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(top)

        val actionsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        actions.addView(actionButton("پخش آفلاین", false) { playOffline(item) }, LinearLayout.LayoutParams(dp(120), dp(42)).apply { marginEnd = dp(5) })
        actions.addView(actionButton("اشتراک", false) { shareOffline(item) }, LinearLayout.LayoutParams(dp(88), dp(42)).apply { marginEnd = dp(5) })
        actions.addView(actionButton("حذف", true) { confirmDelete(item) }, LinearLayout.LayoutParams(dp(78), dp(42)))
        actionsScroll.addView(actions)
        card.addView(actionsScroll, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(10) })
        return card
    }

    private fun mediaMeta(item: JSONObject): String {
        val tokens = mutableListOf<String>()
        val season = item.optInt("season", 0)
        val episode = item.optInt("episode", 0)
        if (season > 0) tokens += "فصل $season"
        if (episode > 0) tokens += "قسمت $episode"
        item.optString("quality").takeIf { it.isNotBlank() }?.let { tokens += it }
        item.optString("kind").takeIf { it.isNotBlank() }?.let { tokens += it }
        val archive = item.optInt("archive", 0)
        if (archive in 1..4) tokens += "آرشیو $archive"
        return tokens.joinToString(" • ").ifBlank { if (isSeriesItem(item)) "قسمت سریال" else "فیلم" }
    }

    private fun isSeriesItem(item: JSONObject): Boolean {
        val type = item.optString("media_type").lowercase(Locale.US)
        if (type.contains("series") || type.contains("serial") || type.contains("episode") || type.contains("tv")) return true
        if (item.optInt("season", 0) > 0 || item.optInt("episode", 0) > 0) return true
        val sample = (item.optString("file_name") + " " + item.optString("title"))
        return Regex("(?i)(?:S\\d{1,2}E\\d{1,3}|\\bE\\d{1,3}\\b|فصل\\s*\\d+|قسمت\\s*\\d+)").containsMatchIn(sample)
    }

    private fun seriesGroupKey(item: JSONObject): String {
        val content = item.optString("content_id").trim()
        if (content.isNotBlank()) return "${item.optInt("archive", 0)}:$content"
        return item.optString("title").trim().lowercase(Locale.US).ifBlank { item.optString("file_name").substringBefore("S", "series") }
    }

    private fun qualityRank(raw: String): Int = when {
        raw.contains("2160", true) || raw.contains("4k", true) -> 0
        raw.contains("1080", true) -> 1
        raw.contains("720", true) -> 2
        raw.contains("480", true) -> 3
        else -> 9
    }

    private fun downloadedUri(item: JSONObject): Pair<Uri, String>? {
        val mime = InternalDownloadStore.mimeForName(item.optString("file_name"))
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank() || !InternalDownloadStore.exists(this, item)) null else Uri.parse(raw) to mime
        } else {
            val file = File(item.optString("path"))
            if (!file.exists()) null else FileProvider.getUriForFile(this, "$packageName.files", file) to mime
        }
    }

    private fun offlinePlaybackSource(item: JSONObject): String? {
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            raw.takeIf { it.isNotBlank() && InternalDownloadStore.exists(this, item) }
        } else {
            val file = File(item.optString("path"))
            file.takeIf { it.isFile && it.length() > 0L }?.absolutePath
        }
    }

    private fun playOffline(item: JSONObject) {
        val source = offlinePlaybackSource(item)
        val shareTarget = downloadedUri(item)
        if (source.isNullOrBlank() || shareTarget == null) {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
            refreshLibrary()
            return
        }
        runCatching {
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                // App-owned files are passed as a real local path. SAF/document
                // downloads keep their content:// URI; PlayerActivity opens those
                // through a FileDescriptor so LibVLC can read them fully offline.
                putExtra(PlayerActivity.EXTRA_VIDEO_URL, source)
                putExtra(PlayerActivity.EXTRA_TITLE, item.optString("title").ifBlank { "BankMovie" })
                putExtra(PlayerActivity.EXTRA_PROGRESS_KEY, "offline:${item.optString("id")}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            })
        }.onFailure {
            runCatching {
                startActivity(Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(shareTarget.first, shareTarget.second)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                })
            }.onFailure { Toast.makeText(this, "امکان پخش فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun shareOffline(item: JSONObject) {
        val target = downloadedUri(item) ?: run {
            Toast.makeText(this, "فایل پیدا نشد", Toast.LENGTH_SHORT).show(); return
        }
        runCatching {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = target.second
                putExtra(Intent.EXTRA_STREAM, target.first)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "اشتراک‌گذاری فایل"))
        }.onFailure { Toast.makeText(this, "امکان اشتراک‌گذاری فایل وجود ندارد", Toast.LENGTH_SHORT).show() }
    }

    private fun confirmDelete(item: JSONObject) {
        AlertDialog.Builder(this)
            .setTitle("حذف از کتابخانه آفلاین")
            .setMessage("فایل دانلودشده از حافظه دستگاه هم حذف شود؟")
            .setNegativeButton("انصراف", null)
            .setNeutralButton("فقط حذف رکورد") { _, _ ->
                InternalDownloadStore.remove(this, item.optString("id"), false)
                refreshLibrary()
            }
            .setPositiveButton("حذف فایل") { _, _ ->
                InternalDownloadStore.remove(this, item.optString("id"), true)
                refreshLibrary()
            }
            .show()
    }

    private fun cleanupMissing() {
        val missing = InternalDownloadStore.all(this).filter {
            it.optString("status") == InternalDownloadStore.STATUS_COMPLETED && !InternalDownloadStore.exists(this, it)
        }
        if (missing.isEmpty()) {
            Toast.makeText(this, "مورد گم‌شده‌ای پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        missing.forEach { InternalDownloadStore.remove(this, it.optString("id"), false) }
        Toast.makeText(this, "${missing.size} رکورد گم‌شده پاک شد", Toast.LENGTH_SHORT).show()
        refreshLibrary()
    }

    private fun fileSize(item: JSONObject): Long {
        val total = item.optLong("total", 0L)
        if (total > 0L) return total
        return if (item.optString("storage_mode") == InternalDownloadStore.STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank()) 0L else runCatching { DocumentFile.fromSingleUri(this, Uri.parse(raw))?.length() ?: 0L }.getOrDefault(0L)
        } else {
            File(item.optString("path")).takeIf { it.exists() }?.length() ?: 0L
        }
    }

    private fun bindTab(view: TextView, selected: Boolean) {
        val p = UiPreferences.palette(this)
        view.setTextColor(if (selected) Color.WHITE else p.muted)
        view.background = if (selected) rounded(p.primary, dp(999), Color.TRANSPARENT)
        else rounded(Color.argb(25, 255, 255, 255), dp(999), Color.argb(48, 255, 255, 255))
    }

    private fun smallButton(label: String, danger: Boolean, click: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 12f
        typeface = BankmovieFonts.bold(this@OfflineLibraryActivity)
        setTextColor(Color.WHITE)
        background = if (danger) rounded(Color.argb(42, 225, 45, 60), dp(15), Color.argb(95, 225, 45, 60))
        else rounded(Color.argb(34, 255, 255, 255), dp(15), Color.argb(58, 255, 255, 255))
        isClickable = true
        isFocusable = true
        setOnClickListener { click() }
        focusScale(this)
    }

    private fun actionButton(label: String, danger: Boolean, click: () -> Unit): TextView = smallButton(label, danger, click)

    private fun focusScale(view: View) {
        view.setOnFocusChangeListener { v, has ->
            v.animate().scaleX(if (has) 1.04f else 1f).scaleY(if (has) 1.04f else 1f).setDuration(110L).start()
        }
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        setColor(fill)
        cornerRadius = radius.toFloat()
        if (Color.alpha(stroke) > 0) setStroke(dp(1), stroke)
    }

    private fun humanBytes(value: Long): String {
        val v = value.coerceAtLeast(0L)
        return when {
            v >= 1024L * 1024L * 1024L -> String.format(Locale.US, "%.1f GB", v / (1024.0 * 1024.0 * 1024.0))
            v >= 1024L * 1024L -> String.format(Locale.US, "%.0f MB", v / (1024.0 * 1024.0))
            v >= 1024L -> String.format(Locale.US, "%.0f KB", v / 1024.0)
            else -> "$v B"
        }
    }

    private fun isTvLike(): Boolean = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
