package ir.bankmoviee.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.FrameLayout
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.util.Locale

/**
 * BankMovie V17 Explorer: the same proven V16.4 site reel experience, locally
 * bundled with the APK (HTML, styling, SVG and JS), served against the user's
 * configured BankMovie /api_explorer.php. Not an external website or browser.
 *
 * This screen has zero credentials: no Lookapo cookies, API keys or app tokens.
 * All three providers respect the live BM ADMIN settings on the website API.
 * The native bridge is deliberately restricted to search and native playback.
 */
class ExplorerActivity : Activity() {
    companion object {
        const val RESULT_ARCHIVE_QUERY = "bm_explorer_search_query"
    }

    private lateinit var web: WebView
    private var fullscreenView: View? = null
    private var fullscreenCallback: WebChromeClient.CustomViewCallback? = null
    private lateinit var frame: FrameLayout
    private val base: String get() = AppConfig.BASE_DOMAIN.trimEnd('/')

    private fun hexadecimal(color: Int): String = String.format(Locale.US, "#%06X", color and 0xFFFFFF)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        val palette = UiPreferences.palette(this)
        window.statusBarColor = palette.background
        window.navigationBarColor = palette.background

        frame = FrameLayout(this)
        setContentView(frame)
        web = WebView(this).apply {
            setBackgroundColor(palette.background)
            isFocusable = true
            isFocusableInTouchMode = true
            overScrollMode = View.OVER_SCROLL_NEVER
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.loadsImagesAutomatically = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW
            addJavascriptInterface(AppBridge(), "BankMovieApp")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val target = request?.url ?: return true
                    if (target.path == "/search" && !target.getQueryParameter("q").isNullOrBlank()) {
                        deliverSearch(target.getQueryParameter("q").orEmpty())
                    }
                    // No offsite or unrelated navigation from the bundled explorer.
                    return true
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    if (view == null || fullscreenView != null) { callback?.onCustomViewHidden(); return }
                    fullscreenView = view
                    fullscreenCallback = callback
                    frame.addView(view, FrameLayout.LayoutParams(-1, -1))
                    web.visibility = View.GONE
                }
                override fun onHideCustomView() {
                    fullscreenView?.let { frame.removeView(it) }
                    fullscreenView = null
                    fullscreenCallback?.onCustomViewHidden()
                    fullscreenCallback = null
                    web.visibility = View.VISIBLE
                }
            }
        }
        frame.addView(web, FrameLayout.LayoutParams(-1, -1))

        val bundled = assets.open("bm_explorer_v17.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val css = assets.open("bm_explorer_v17.css").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val javascript = assets.open("bm_explorer_v17.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val html = bundled
            .replace("/*_BM_CSS_*/", css.replace("</style>", "<\\/style>", ignoreCase = true))
            .replace("/*_BM_JS_*/", javascript.replace("</script>", "<\\/script>", ignoreCase = true))
            .replace("/*_BM_ACCENT_*/", hexadecimal(UiPreferences.readableAccent(this)))
            .replace("/*_BM_BG_*/", hexadecimal(palette.background))
            .replace("/*_BM_TEXT_*/", hexadecimal(palette.text))
            .replace("/*_BM_MUTED_*/", hexadecimal(palette.muted))

        // HTTPS base makes the bundled page same-origin with /api_explorer.php,
        // so its usual relative requests, cover CDN and safe server streams work.
        web.loadDataWithBaseURL("$base/discover.php", html, "text/html", "UTF-8", null)
    }

    private fun deliverSearch(value: String) {
        val query = value.trim().take(160)
        if (query.isBlank()) return
        setResult(RESULT_OK, Intent().putExtra(RESULT_ARCHIVE_QUERY, query))
        finish()
    }

    private inner class AppBridge {
        @JavascriptInterface
        fun close() { runOnUiThread { finish() } }

        @JavascriptInterface
        fun searchArchive(query: String?) { runOnUiThread { deliverSearch(query.orEmpty()) } }

        @JavascriptInterface
        fun nativePlayback(value: String?, title: String?) {
            val raw = value.orEmpty().trim()
            val uri = runCatching { Uri.parse(raw) }.getOrNull()
            val host = uri?.host.orEmpty()
            if (uri?.scheme != "https" || host.isBlank() ||
                host.equals("localhost", true) || host == "127.0.0.1" ||
                host.endsWith(".local", true)) {
                runOnUiThread { Toast.makeText(this@ExplorerActivity, "آدرس پخش معتبر نیست", Toast.LENGTH_SHORT).show() }
                return
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                web.evaluateJavascript("document.querySelectorAll('.reel-video').forEach(v=>v.pause())", null)
                startActivity(Intent(this@ExplorerActivity, PlayerActivity::class.java).apply {
                    putExtra(PlayerActivity.EXTRA_VIDEO_URL, raw)
                    putExtra(PlayerActivity.EXTRA_TITLE, title.orEmpty().take(120).ifBlank { "اکسپلور بانک‌مووی" })
                })
            }
        }
    }

    @Deprecated("Back navigation")
    override fun onBackPressed() {
        if (fullscreenView != null) {
            web.webChromeClient?.onHideCustomView()
            return
        }
        if (!::web.isInitialized) { super.onBackPressed(); return }
        web.evaluateJavascript("(function(){let d=document.getElementById('detailModal');if(d&&d.classList.contains('show')){d.querySelector('[data-detail-close]')?.click();return 'handled'}let r=document.getElementById('reelsModal');if(r&&r.classList.contains('show')){r.querySelector('[data-reel-close]')?.click();return 'handled'}return 'exit'})()") { value ->
            if (value == "\"exit\"" && !isFinishing) finish()
        }
    }

    override fun onPause() {
        if (::web.isInitialized) web.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        if (::web.isInitialized) web.onResume()
    }

    override fun onDestroy() {
        if (::web.isInitialized) {
            web.loadUrl("about:blank")
            (web.parent as? ViewGroup)?.removeView(web)
            web.removeJavascriptInterface("BankMovieApp")
            web.destroy()
        }
        super.onDestroy()
    }
}
