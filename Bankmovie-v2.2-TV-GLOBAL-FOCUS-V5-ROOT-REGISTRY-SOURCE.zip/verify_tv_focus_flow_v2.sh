#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# Profile: any focus inside the account header reveals the complete avatar/name card.
need "$MAIN" 'tag = "bm_tv_profile_header_card"'
need "$MAIN" 'hasTaggedAncestor(v, "bm_tv_profile_header_card")'
need "$MAIN" 'if (currentScreen == "profile" && v.hasFocus()) profileScroll.scrollTo(0, 0)'

# Home startup: normal TV entry resolves Archive 1 first; explicit archive selection/back restore is preserved.
need "$MAIN" 'private var tvHomeArchiveSelectionExplicit = false'
need "$MAIN" 'private var tvHomeInitialArchiveForBuild = 1'
need "$MAIN" 'val preserveArchive = restoringNavigation || tvHomeArchiveSelectionExplicit'
need "$MAIN" '"home" -> content.findViewWithTag<View>("bm_archive_segment_$tvHomeInitialArchiveForBuild")'
need "$MAIN" 'val initialTarget = preferredArchive ?: firstQuickTab ?: watch'

# Home V4: use stable logical row child order, not geometry/async focus IDs.
need "$MAIN" 'HOME TV FOCUS FLOW V4'
need "$MAIN" 'private var tvHomePosterEntryPending = false'
need "$MAIN" 'private fun homeTvDirectMediaRow('
need "$MAIN" 'val cards = (0 until row.childCount).map { row.getChildAt(it) }.filter {'
need "$MAIN" 'private fun homeTvFirstVisualPoster(): View?'
need "$MAIN" 'private fun fulfillPendingHomePosterEntry()'
need "$MAIN" 'tvHomePosterEntryPending = true'
need "$MAIN" 'uiHandler.postDelayed({ fulfillPendingHomePosterEntry() }, delay)'
need "$MAIN" 'if (currentScreen == "home") fulfillPendingHomePosterEntry()'
need "$MAIN" 'private fun requestHomeTvFocus(target: View?): Boolean'
need "$MAIN" 'if (number < 8) view.postDelayed({ attempt(number + 1) }'
need "$MAIN" 'revealHomeTvTarget(view)'
need "$MAIN" 'val nextCard = section.cardsRightToLeft.getOrNull(cardIndex + 1)'
need "$MAIN" 'val previousCard = section.cardsRightToLeft.getOrNull(cardIndex - 1)'
need "$MAIN" 'val previousRail = previousCards.getOrNull(cardIndex) ?: previousCards.lastOrNull()'
need "$MAIN" 'val nextRail = nextCards?.getOrNull(cardIndex) ?: nextCards?.lastOrNull()'
need "$MAIN" 'requestHomeTvFocus(nextCard ?: section.more)'
need "$MAIN" 'return requestHomeFirstPosterFromArchive()'

# These old failure modes must stay gone.
if grep -Fq '.sortedByDescending { it.centerX }' "$MAIN"; then
  echo 'Geometry-based Home row ordering is back; TV focus can race layout again.' >&2
  exit 1
fi
if grep -Fq 'targetIsMedia' "$MAIN"; then
  echo 'Old async nextFocus target gate is still present.' >&2
  exit 1
fi
if grep -Fq 'honor the explicit section "View all" link' "$MAIN"; then
  echo 'Old vertical View-all Home focus routing is still present.' >&2
  exit 1
fi

# Search/list paging: async list growth must preserve current logical position.
need "$MAIN" 'private fun restoreTvFocusAfterMutation('
need "$MAIN" 'private fun focusedChildIndex(container: ViewGroup, focus: View? = currentFocus): Int'
need "$MAIN" 'tag = "bm_tv_load_more"'
need "$MAIN" 'pendingManualGridIndex = focusedChildIndex(grid, before)'
need "$MAIN" 'restoreTvFocusAfterMutation(page, pendingManualFocus, grid, pendingManualGridIndex)'
count="$(grep -Fc 'restoreTvFocusAfterMutation(page, focusBeforeMutation, grid, focusIndexBeforeMutation)' "$MAIN")"
if [[ "$count" -lt 5 ]]; then
  echo "Expected focus preservation in at least 5 async result/list paths; found $count" >&2
  exit 1
fi

bash verify_tv_focus_flow_v5.sh
echo 'TV_FOCUS_FLOW_V4_OK'
