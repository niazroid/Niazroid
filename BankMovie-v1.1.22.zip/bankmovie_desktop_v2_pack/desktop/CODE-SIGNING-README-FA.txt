این بسته برای Build اجباریِ امضاشده آماده شده است.
Workflow بدون گواهی معتبر خروجی نمی‌سازد.
Secrets لازم:
WINDOWS_CERTIFICATE_PFX_BASE64
WINDOWS_CERTIFICATE_PASSWORD
