# BankMovie Desktop 1.1.16

- فقط hotfix بیلد NSIS.
- رفع warning 6010 تابع BM_GUIINIT در مرحله BUILD_UNINSTALLER.
- فایل نمونه zar-software2-4.exe در این پچ استفاده یا تغییر داده نشده است.
