# BankMovie Desktop 1.9.2

- اتصال Archive 4 به Cinamatic با fallback مستقیم صفحه جزئیات برای لینک‌های واقعی پخش/دانلود.
- Pause دانلود قفل می‌شود تا تا زمان Resume دوباره خودکار شروع نشود.
- انیمیشن دکمه دانلود فقط بعد از کلیک اجرا می‌شود، نه Hover.
- Progress Scrollbar واقعی و Drag-able برای تمام Carouselهای افقی، سازگار با RTL/LTR.
- بازطراحی Comments: آواتار، نشان تایید، امتیاز ستاره‌ای، sort، Reply داخلی، Spoiler، Sticker/Emoji، Like/Dislike و ارسال Optimistic.
- دکمه Trailer شبیه CTA سایت.
- تم‌های Blue (پیش‌فرض)، OLED، Light و Violet. تم پیش‌فرض آبی است.
- زبان فارسی/English و انتخاب Auto/Manual Player نسخه قبل حفظ شده است.
