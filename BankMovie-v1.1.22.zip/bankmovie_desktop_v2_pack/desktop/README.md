# BankMovie Windows

## اجرا برای توسعه
نیازمندی: Node.js 20+ / npm

```bash
npm install
npm start
```

## ساخت Setup ویندوز

```bash
npm install
npm run build:win
```

خروجی electron-builder داخل پوشه `dist/` ساخته می‌شود.

## ترتیب اتصال
1. برنامه ابتدا `https://bankmovie.top/desktop_config.php` را می‌خواند.
2. محتوا را از `desktop_api.php` می‌گیرد (fallback: `app_api.php`).
3. حساب، واچ‌لیست، کامنت، اعلان و Watch Party از `app_user_api.php` استفاده می‌کنند.
4. HMAC حساب در Electron main process ساخته می‌شود؛ user token در renderer قرار نمی‌گیرد.
5. session token با `safeStorage` ویندوز رمز می‌شود، اگر سیستم پشتیبانی کند.

قبل از تست login/register، server patch را نصب کن؛ محتوای عمومی حتی قبل از patch هم از fallback API قابل تست است.

## اجرای سریع روی Windows
اگر Node.js نصب است، `RUN_DEV.bat` را اجرا کن. برای ساخت Setup، `BUILD_SETUP.bat` را اجرا کن؛ خروجی در `dist/` ساخته می‌شود.

## تغییرات نسخه 1.1.0
- دانلودر crash-safe شده و دیگر روی `webContents == null` خطا نمی‌دهد.
- پخش فقط با پلیر خارجی انجام می‌شود: PotPlayer / VLC / KMPlayer.
- پلیرهای نصب‌شده خودکار از Registry، PATH و مسیرهای رایج ویندوز شناسایی می‌شوند.
- در Settings می‌توان Auto یا یکی از پلیرهای پیدا‌شده را انتخاب کرد.
- زیرنویس جداگانه در صورت وجود `subtitle_url` به پلیر خارجی داده می‌شود.
- Slider صفحه Home فقط از Slider اصلی سایت (`boot.sliders`) می‌آید، مستقل از آرشیو انتخابی است و target/link واقعی اسلاید را باز می‌کند.
- «ادامه تماشا» موقتاً از رابط حذف شده است.
- سریال‌ها فصل -> قسمت -> کیفیت/دوبله/زیرنویس تفکیک می‌شوند.
