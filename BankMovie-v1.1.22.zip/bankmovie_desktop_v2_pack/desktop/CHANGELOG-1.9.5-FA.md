# BankMovie Desktop v1.9.5

- افزایش خوانایی و اندازه متن‌های ریز در رابط کاربری
- اصلاح کنتراست هدر، Hero و دکمه مشاهده
- بازنویسی resolver دکمه مشاهده Slider با fallback جستجو
- اصلاح Search و Watch Party در Light Theme
- بازطراحی Login/Register با ظاهر سایت BankMovie
- صفحه Update مشابه هویت بصری BankMovie و اتصال به Desktop Remote Config
