// Desktop runtime contains no static API credentials.
module.exports = Object.freeze({
  domain: process.env.BM_DESKTOP_DOMAIN || 'https://bankmovie.top'
});
