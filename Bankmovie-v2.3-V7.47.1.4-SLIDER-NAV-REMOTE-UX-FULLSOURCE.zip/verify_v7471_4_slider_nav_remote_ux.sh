#!/usr/bin/env bash
set -euo pipefail
MAIN="app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
ONBOARD="app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"
VAULT="app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt"
WORKFLOW=".github/workflows/build-bankmovie.yml"

for f in "$MAIN" "$ONBOARD" "$VAULT" "$WORKFLOW"; do test -s "$f"; done

# Slider: app_home_feed must refresh an already-visible Home when authoritative sliders arrive.
grep -q 'authoritative slider feed' "$MAIN"
grep -q 'previousSliders != mergedSliders' "$MAIN"
grep -A25 'previousSliders != mergedSliders' "$MAIN" | grep -q 'showHome()'

# Quick setup exposes the same persisted mobile navigation style used by Settings.
grep -q 'private var mobileNavStyle = "classic"' "$ONBOARD"
grep -q 'KEY_MOBILE_NAV_STYLE, mobileNavStyle' "$ONBOARD"
grep -q 'مدل ناوبری موبایل' "$ONBOARD"
grep -q 'Triple("center_fab"' "$ONBOARD"

# Back transition + bottom sheet contract.
grep -q 'native-feeling back transition' "$MAIN"
grep -q 'PathInterpolator(0.16f, 1f, 0.30f, 1f)' "$MAIN"
grep -q 'bottom sheets have only two resting states' "$MAIN"
modal_block="$(grep -A170 'private fun wireV728DraggableBottomSheet' "$MAIN")"
! grep -q '0.42f' <<<"$modal_block"
grep -q 'dismissDown()' <<<"$modal_block"

# Movie copy-link is removed; series may still copy individual links and bulk by season.
grep -q 'val seriesDownloadLink = itemContentType(item) == "series"' "$MAIN"
grep -q 'clientMode == "adm_copy" && seriesDownloadLink' "$MAIN"
grep -q 'openAdmOnly(url, allowClipboardFallback = seriesDownloadLink)' "$MAIN"
grep -q 'private fun openAdmOnly(url: String, allowClipboardFallback: Boolean = true)' "$MAIN"
grep -q 'همه فصل‌ها' "$MAIN"
grep -q 'selectedSeason\[0\] == 0' "$MAIN"

# RuntimeVault decode must point remote config/secondary host at bankmoviez.top.
python3 - <<'PY'
import re
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt').read_text(encoding='utf-8')
def decode(name):
    m=re.search(rf'private val {name}Data = intArrayOf\(([^)]*)\)',s)
    q=re.search(rf'private const val {name}Seed = (\d+)',s)
    if not m or not q: raise SystemExit(f'missing vault field: {name}')
    data=[int(x.strip()) for x in m.group(1).split(',') if x.strip()]
    seed=int(q.group(1))
    return ''.join(chr(v ^ ((seed+i*31+((i*i*7)&0xff)) & 0xffff)) for i,v in enumerate(data))
expected={
 'CONFIG_URL_PRIMARY':'https://bankmoviez.top/app_config.php',
 'CONFIG_URL_SECONDARY':'https://www.bankmoviez.top/app_config.php',
 'HOST_SECONDARY':'bankmoviez.top',
 'HOST_SECONDARY_WWW':'www.bankmoviez.top',
}
for k,v in expected.items():
    actual=decode(k)
    if actual != v: raise SystemExit(f'{k}: {actual!r} != {v!r}')
print('RuntimeVault remote controller OK')
PY

# Exact old remote domain must be gone from runtime/server text (package id is intentionally unchanged).
if grep -RIn --exclude-dir=build --exclude='*.zip' 'bankmoviee[.]ir' app server-required >/tmp/v7471_4_old_domain.txt; then
  cat /tmp/v7471_4_old_domain.txt
  echo 'Old remote controller domain is still present.' >&2
  exit 1
fi

grep -q 'V7.47.1.4 Slider + Navigation + Remote UX Hotfix' "$WORKFLOW"
grep -q 'verify_v7471_4_slider_nav_remote_ux.sh' "$WORKFLOW"
grep -q 'Bankmovie-v2.3-V7.47.1.4-SLIDER-NAV-REMOTE-UX-FULLSOURCE.zip' "$WORKFLOW"

echo VERIFY_V7471_4_SLIDER_NAV_REMOTE_UX_OK
