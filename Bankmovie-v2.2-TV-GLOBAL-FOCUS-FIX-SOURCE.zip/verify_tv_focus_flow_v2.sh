#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

# Profile: any focus inside the account header reveals the complete avatar/name card.
need "$MAIN" 'tag = "bm_tv_profile_header_card"'
need "$MAIN" 'hasTaggedAncestor(v, "bm_tv_profile_header_card")'
need "$MAIN" 'if (currentScreen == "profile" && v.hasFocus()) profileScroll.scrollTo(0, 0)'

# Home: normal TV entry resolves Archive 1 first; explicit archive selection/back restore is preserved.
need "$MAIN" 'private var tvHomeArchiveSelectionExplicit = false'
need "$MAIN" 'private var tvHomeInitialArchiveForBuild = 1'
need "$MAIN" 'val preserveArchive = restoringNavigation || tvHomeArchiveSelectionExplicit'
need "$MAIN" '"home" -> content.findViewWithTag<View>("bm_archive_segment_$tvHomeInitialArchiveForBuild")'
need "$MAIN" 'val initialTarget = preferredArchive ?: firstQuickTab ?: watch'

# Home row traversal: Archive -> rightmost/newest poster -> remaining posters -> View all end-cap.
need "$MAIN" 'Archive 1 -> newest/rightmost poster -> remaining posters -> View all.'
need "$MAIN" '.sortedByDescending { it.centerX }'
need "$MAIN" 'segment.nextFocusDownId = firstPoster.id'
need "$MAIN" 'leftmost.nextFocusLeftId = section.more.id'
need "$MAIN" 'section.more.nextFocusRightId = leftmost.id'
need "$MAIN" 'keyCode == android.view.KeyEvent.KEYCODE_DPAD_DOWN && targetIsMedia'
need "$MAIN" 'currentIsMedia && keyCode == android.view.KeyEvent.KEYCODE_DPAD_LEFT'

if grep -Fq 'honor the explicit section "View all" link' "$MAIN"; then
  echo 'Old vertical View-all Home focus routing is still present.' >&2
  exit 1
fi
if grep -Fq 'section.cards.forEach { node -> node.view.nextFocusUpId = section.more.id }' "$MAIN"; then
  echo 'Home posters still route UP into View all.' >&2
  exit 1
fi

# Search/list paging: async list growth must preserve the current card/column instead of child #0.
need "$MAIN" 'private fun restoreTvFocusAfterMutation('
need "$MAIN" 'private fun focusedChildIndex(container: ViewGroup, focus: View? = currentFocus): Int'
need "$MAIN" 'tag = "bm_tv_load_more"'
need "$MAIN" 'pendingManualGridIndex = focusedChildIndex(grid, before)'
need "$MAIN" 'restoreTvFocusAfterMutation(page, pendingManualFocus, grid, pendingManualGridIndex)'
count="$(grep -Fc 'restoreTvFocusAfterMutation(page, focusBeforeMutation, grid, focusIndexBeforeMutation)' "$MAIN")"
if [[ "$count" -lt 5 ]]; then
  echo "Expected focus preservation in at least 5 async result/list paths; found $count" >&2
  exit 1
fi

echo 'TV_FOCUS_FLOW_V2_OK'
