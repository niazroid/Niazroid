# اصلاح نسخه 2.0.2

- فضای نام `System.Net.Http` به `Api6Client.cs` اضافه شد.
- `HttpClient`، `HttpRequestMessage`، `HttpMethod` و `HttpCompletionOption` اکنون به‌صورت صریح قابل شناسایی‌اند.
- نسخه پروژه به 2.0.2 افزایش یافت.
