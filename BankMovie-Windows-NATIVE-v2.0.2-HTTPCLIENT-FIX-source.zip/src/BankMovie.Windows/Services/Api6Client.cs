using System.Collections.ObjectModel;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using BankMovie.Windows.Models;

namespace BankMovie.Windows.Services;

public sealed class Api6Client : IDisposable
{
    private readonly HttpClient _http;
    private readonly AppSettings _settings;

    public Api6Client(AppSettings settings)
    {
        _settings = settings;
        _http = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(Math.Clamp(settings.RequestTimeoutSeconds, 8, 60))
        };
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("BankMovieWindowsNative/2.0");
        _http.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue { NoCache = true };
    }

    public AppSettings Settings => _settings;

    public Task<ApiListResult> GetSectionAsync(string section, int page = 1, int limit = 20, CancellationToken cancellationToken = default)
    {
        return GetListAsync(new Dictionary<string, string?>
        {
            ["section"] = section,
            ["page"] = page.ToString(CultureInfo.InvariantCulture),
            ["limit"] = limit.ToString(CultureInfo.InvariantCulture)
        }, cancellationToken);
    }

    public Task<ApiListResult> SearchAsync(SearchQuery query, CancellationToken cancellationToken = default)
    {
        var values = new Dictionary<string, string?>
        {
            ["q"] = query.Query,
            ["type"] = query.Type == "all" ? string.Empty : query.Type,
            ["genre"] = query.Genre,
            ["year"] = query.Year,
            ["imdbScore"] = query.ImdbScore,
            ["lang"] = query.Language,
            ["sort"] = query.Sort,
            ["page"] = Math.Max(1, query.Page).ToString(CultureInfo.InvariantCulture),
            ["limit"] = "30"
        };
        return GetListAsync(values, cancellationToken);
    }

    public async Task<SearchOptions> GetSearchOptionsAsync(CancellationToken cancellationToken = default)
    {
        using var document = await GetDocumentAsync(new Dictionary<string, string?> { ["search_options"] = "1" }, cancellationToken);
        var root = document.RootElement;
        var options = new SearchOptions();
        FillOptions(root, "types", options.Types);
        FillOptions(root, "genres", options.Genres);
        FillOptions(root, "years", options.Years);
        FillOptions(root, "imdb_scores", options.ImdbScores);
        FillOptions(root, "languages", options.Languages);
        FillOptions(root, "sorts", options.Sorts);
        EnsureDefaultOptions(options);
        return options;
    }

    public async Task<MovieItem> GetDetailsAsync(MovieItem seed, CancellationToken cancellationToken = default)
    {
        var identifier = FirstNotEmpty(seed.DetailId, seed.Id, seed.Slug);
        var parameters = new Dictionary<string, string?>();
        if (!string.IsNullOrWhiteSpace(seed.SourceUrl) && Uri.TryCreate(seed.SourceUrl, UriKind.Absolute, out _))
            parameters["url"] = seed.SourceUrl;
        else
            parameters["id"] = identifier;

        using var document = await GetDocumentAsync(parameters, cancellationToken);
        var root = document.RootElement;
        JsonElement detail;
        if (TryGetObject(root, out detail, "item", "movie"))
        {
            // found wrapped detail
        }
        else
        {
            detail = root;
        }

        var movie = ParseMovie(detail);
        MergeSeed(movie, seed);
        var links = FindLinks(detail, root);
        movie.Links = new ObservableCollection<MediaLink>(links
            .Where(x => !string.IsNullOrWhiteSpace(x.Url))
            .OrderBy(x => x.Season)
            .ThenBy(x => x.Episode)
            .ThenByDescending(x => x.QualityScore)
            .ThenBy(x => x.KindLabel));
        movie.HasOnline = movie.HasOnline || movie.Links.Any(x => x.IsPlayable && !x.IsAudio);

        var related = FindArray(detail, "related", "related_movies") ?? FindArray(root, "related", "related_movies");
        if (related.HasValue && related.Value.ValueKind == JsonValueKind.Array)
        {
            movie.Related = new ObservableCollection<MovieItem>(related.Value.EnumerateArray()
                .Where(x => x.ValueKind == JsonValueKind.Object)
                .Select(ParseMovie));
        }
        return movie;
    }

    private async Task<ApiListResult> GetListAsync(Dictionary<string, string?> parameters, CancellationToken cancellationToken)
    {
        using var document = await GetDocumentAsync(parameters, cancellationToken);
        var root = document.RootElement;
        var array = FindArray(root, "movies", "items", "results", "data");
        var items = new ObservableCollection<MovieItem>();
        if (array.HasValue && array.Value.ValueKind == JsonValueKind.Array)
        {
            foreach (var element in array.Value.EnumerateArray())
            {
                if (element.ValueKind == JsonValueKind.Object) items.Add(ParseMovie(element));
            }
        }
        return new ApiListResult
        {
            Items = items,
            Page = GetInt(root, "page") ?? GetInt(root, "current_page") ?? 1,
            Count = GetInt(root, "count") ?? items.Count,
            HasMore = GetBool(root, "has_more") ?? ((GetInt(root, "next_page") ?? 0) > 0),
            NextPage = GetInt(root, "next_page")
        };
    }

    private async Task<JsonDocument> GetDocumentAsync(Dictionary<string, string?> parameters, CancellationToken cancellationToken)
    {
        var uri = BuildUri(parameters);
        Exception? lastError = null;
        for (var attempt = 0; attempt < 2; attempt++)
        {
            try
            {
                using var request = new HttpRequestMessage(HttpMethod.Get, uri);
                using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
                var content = await response.Content.ReadAsStringAsync(cancellationToken);
                if (!response.IsSuccessStatusCode)
                {
                    var apiMessage = TryReadApiMessage(content);
                    throw new Api6Exception(apiMessage ?? $"خطای دریافت اطلاعات ({(int)response.StatusCode})", response.StatusCode);
                }
                if (string.IsNullOrWhiteSpace(content)) throw new Api6Exception("پاسخ خالی از سرور دریافت شد.");
                var document = JsonDocument.Parse(content);
                var status = GetString(document.RootElement, "status").ToLowerInvariant();
                if (status is "error" or "disabled" or "failed")
                {
                    var message = GetString(document.RootElement, "message");
                    document.Dispose();
                    throw new Api6Exception(string.IsNullOrWhiteSpace(message) ? "آرشیو در دسترس نیست." : message);
                }
                return document;
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                lastError = ex;
                if (attempt == 0) await Task.Delay(450, cancellationToken);
            }
        }
        throw lastError is Api6Exception apiError
            ? apiError
            : new Api6Exception("اتصال به BankMovie برقرار نشد. اینترنت را بررسی و دوباره تلاش کنید.", null, lastError);
    }

    private Uri BuildUri(Dictionary<string, string?> parameters)
    {
        var query = string.Join("&", parameters
            .Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
            .Select(pair => $"{Uri.EscapeDataString(pair.Key)}={Uri.EscapeDataString(pair.Value!.Trim())}"));
        var separator = _settings.Api6Url.Contains('?') ? "&" : "?";
        return new Uri(_settings.Api6Url + (query.Length > 0 ? separator + query : string.Empty));
    }

    private MovieItem ParseMovie(JsonElement element)
    {
        var mediaKind = GetString(element, "media_kind").ToLowerInvariant();
        var type = GetString(element, "type").ToLowerInvariant();
        if (mediaKind is "anime" or "animation") type = mediaKind;

        var movie = new MovieItem
        {
            Id = FirstNotEmpty(GetString(element, "id"), GetString(element, "detail_id"), GetString(element, "slug"), GetString(element, "source_post_id")),
            DetailId = FirstNotEmpty(GetString(element, "detail_id"), GetString(element, "id"), GetString(element, "slug")),
            SourceUrl = FirstNotEmpty(GetString(element, "source_url"), GetString(element, "web_url_abs"), GetString(element, "web_url"), GetString(element, "url")),
            Slug = GetString(element, "slug"),
            Title = WebUtility.HtmlDecode(GetString(element, "title")),
            TitleFa = WebUtility.HtmlDecode(GetString(element, "title_fa")),
            FullTitle = WebUtility.HtmlDecode(GetString(element, "full_title")),
            Type = type,
            MediaKind = mediaKind,
            Poster = NormalizeUrl(FirstNotEmpty(GetString(element, "poster"), GetString(element, "image"), GetString(element, "cover_image"))),
            Backdrop = NormalizeUrl(FirstNotEmpty(GetString(element, "backdrop"), GetString(element, "background"), GetString(element, "backdrop_url"))),
            Year = GetInt(element, "year"),
            Rating = GetDouble(element, "rating") ?? GetDouble(element, "imdb") ?? GetDouble(element, "imdb_score"),
            Runtime = GetInt(element, "runtime") ?? GetInt(element, "duration"),
            Description = WebUtility.HtmlDecode(GetString(element, "description")),
            LongDescription = WebUtility.HtmlDecode(GetString(element, "long_description")),
            Status = WebUtility.HtmlDecode(GetString(element, "status")),
            Trailer = NormalizeUrl(GetString(element, "trailer")),
            HasDubbed = GetBool(element, "has_dubbed") ?? false,
            HasSubtitle = GetBool(element, "has_subtitle") ?? false,
            HasOnline = GetBool(element, "has_online") ?? false,
            Genres = ReadStringList(element, "genres", "genre"),
            Countries = ReadStringList(element, "country", "countries"),
            Actors = ReadStringList(element, "actors", "casts", "cast"),
            Directors = ReadStringList(element, "directors", "director"),
            Writers = ReadStringList(element, "writers", "writer")
        };
        if (string.IsNullOrWhiteSpace(movie.TitleFa)) movie.TitleFa = FirstNotEmpty(movie.FullTitle, movie.Title);
        if (string.IsNullOrWhiteSpace(movie.Title)) movie.Title = movie.TitleFa;
        if (string.IsNullOrWhiteSpace(movie.Backdrop)) movie.Backdrop = movie.Poster;
        return movie;
    }

    private List<MediaLink> FindLinks(JsonElement detail, JsonElement root)
    {
        JsonElement? links = FindArray(detail, "downloads", "links");
        if (links is null && detail.TryGetProperty("play", out var play) && play.ValueKind == JsonValueKind.Object)
            links = FindArray(play, "links", "items");
        links ??= FindArray(root, "downloads", "links");
        if (links is null && root.TryGetProperty("play", out var rootPlay) && rootPlay.ValueKind == JsonValueKind.Object)
            links = FindArray(rootPlay, "links", "items");

        var result = new List<MediaLink>();
        if (!links.HasValue || links.Value.ValueKind != JsonValueKind.Array) return result;
        foreach (var element in links.Value.EnumerateArray())
        {
            if (element.ValueKind != JsonValueKind.Object) continue;
            var rawType = GetString(element, "type").ToLowerInvariant();
            var type = rawType switch
            {
                "dubbed" => "dub",
                "hard-sub" => "hardsub",
                "soft-sub" => "softsub",
                _ => rawType
            };
            var link = new MediaLink
            {
                Url = NormalizeUrl(GetString(element, "url")),
                Quality = GetString(element, "quality"),
                Type = type,
                TypeFa = WebUtility.HtmlDecode(GetString(element, "type_fa")),
                DisplayLabel = WebUtility.HtmlDecode(FirstNotEmpty(GetString(element, "display_label"), GetString(element, "label"))),
                Size = GetString(element, "size"),
                Season = GetInt(element, "season") ?? 0,
                Episode = GetInt(element, "episode") ?? 0,
                IsDirect = GetBool(element, "is_direct") ?? true,
                IsDownload = GetBool(element, "is_download") ?? false,
                IsPlayable = GetBool(element, "is_playable") ?? true,
                IsAudio = GetBool(element, "is_audio") ?? type == "audio"
            };
            if (string.IsNullOrWhiteSpace(link.DisplayLabel))
            {
                link.DisplayLabel = string.Join(" • ", new[] { link.Quality, link.KindLabel, link.Size }.Where(x => !string.IsNullOrWhiteSpace(x)));
            }
            result.Add(link);
        }
        return result;
    }

    private void FillOptions(JsonElement root, string property, ObservableCollection<OptionItem> target)
    {
        if (!root.TryGetProperty(property, out var array) || array.ValueKind != JsonValueKind.Array) return;
        foreach (var element in array.EnumerateArray())
        {
            switch (element.ValueKind)
            {
                case JsonValueKind.String:
                    var text = element.GetString() ?? string.Empty;
                    if (!string.IsNullOrWhiteSpace(text)) target.Add(new OptionItem { Value = text, Label = text });
                    break;
                case JsonValueKind.Number:
                    var number = element.ToString();
                    target.Add(new OptionItem { Value = number, Label = number });
                    break;
                case JsonValueKind.Object:
                    var value = FirstNotEmpty(GetString(element, "value"), GetString(element, "key"), GetString(element, "id"), GetString(element, "year"), GetString(element, "label"), GetString(element, "name"));
                    var label = FirstNotEmpty(GetString(element, "label"), GetString(element, "title"), GetString(element, "name"), value);
                    if (!string.IsNullOrWhiteSpace(value)) target.Add(new OptionItem { Value = value, Label = label, Count = GetInt(element, "count") });
                    break;
            }
        }
    }

    private static void EnsureDefaultOptions(SearchOptions options)
    {
        if (options.Types.Count == 0)
        {
            options.Types.Add(new OptionItem { Value = "all", Label = "همه" });
            options.Types.Add(new OptionItem { Value = "movie", Label = "فیلم" });
            options.Types.Add(new OptionItem { Value = "series", Label = "سریال" });
            options.Types.Add(new OptionItem { Value = "animation", Label = "انیمیشن" });
            options.Types.Add(new OptionItem { Value = "anime", Label = "انیمه" });
        }
        else if (options.Types.All(x => x.Value != "all")) options.Types.Insert(0, new OptionItem { Value = "all", Label = "همه" });

        if (options.ImdbScores.Count == 0)
        {
            options.ImdbScores.Add(new OptionItem { Value = string.Empty, Label = "همه امتیازها" });
            for (var score = 9; score >= 5; score--) options.ImdbScores.Add(new OptionItem { Value = score.ToString(), Label = $"حداقل {score}" });
        }
        if (options.Languages.Count == 0)
        {
            options.Languages.Add(new OptionItem { Value = string.Empty, Label = "همه نسخه‌ها" });
            options.Languages.Add(new OptionItem { Value = "دوبله", Label = "دوبله" });
            options.Languages.Add(new OptionItem { Value = "زیرنویس", Label = "زیرنویس" });
        }
        if (options.Sorts.Count == 0)
        {
            options.Sorts.Add(new OptionItem { Value = "newest", Label = "جدیدترین" });
            options.Sorts.Add(new OptionItem { Value = "rating", Label = "بالاترین امتیاز" });
            options.Sorts.Add(new OptionItem { Value = "year_desc", Label = "سال انتشار" });
            options.Sorts.Add(new OptionItem { Value = "title", Label = "عنوان" });
        }
        if (options.Genres.Count == 0) options.Genres.Add(new OptionItem { Value = string.Empty, Label = "همه ژانرها" });
        else if (options.Genres.All(x => !string.IsNullOrWhiteSpace(x.Value))) options.Genres.Insert(0, new OptionItem { Value = string.Empty, Label = "همه ژانرها" });
        if (options.Years.Count == 0) options.Years.Add(new OptionItem { Value = string.Empty, Label = "همه سال‌ها" });
        else if (options.Years.All(x => !string.IsNullOrWhiteSpace(x.Value))) options.Years.Insert(0, new OptionItem { Value = string.Empty, Label = "همه سال‌ها" });
    }

    private List<string> ReadStringList(JsonElement element, params string[] properties)
    {
        foreach (var property in properties)
        {
            if (!element.TryGetProperty(property, out var value)) continue;
            if (value.ValueKind == JsonValueKind.Array)
            {
                var list = new List<string>();
                foreach (var item in value.EnumerateArray())
                {
                    var text = item.ValueKind switch
                    {
                        JsonValueKind.String => item.GetString() ?? string.Empty,
                        JsonValueKind.Object => FirstNotEmpty(GetString(item, "name"), GetString(item, "title"), GetString(item, "label")),
                        _ => item.ToString()
                    };
                    text = WebUtility.HtmlDecode(text).Trim();
                    if (!string.IsNullOrWhiteSpace(text)) list.Add(text);
                }
                return list.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
            }
            if (value.ValueKind == JsonValueKind.String)
            {
                return (value.GetString() ?? string.Empty)
                    .Split([',', '،', '|'], StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                    .Select(WebUtility.HtmlDecode)
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .ToList();
            }
        }
        return [];
    }

    private string NormalizeUrl(string raw)
    {
        var value = WebUtility.HtmlDecode(raw ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(value) || value.Equals("null", StringComparison.OrdinalIgnoreCase)) return string.Empty;
        if (value.StartsWith("//")) return "https:" + value;
        if (Uri.TryCreate(value, UriKind.Absolute, out var absolute)) return absolute.ToString();
        return new Uri(new Uri(_settings.SiteRoot.TrimEnd('/') + "/"), value.TrimStart('/')).ToString();
    }

    private static void MergeSeed(MovieItem target, MovieItem seed)
    {
        target.Id = FirstNotEmpty(target.Id, seed.Id);
        target.DetailId = FirstNotEmpty(target.DetailId, seed.DetailId);
        target.SourceUrl = FirstNotEmpty(target.SourceUrl, seed.SourceUrl);
        target.Slug = FirstNotEmpty(target.Slug, seed.Slug);
        target.Title = FirstNotEmpty(target.Title, seed.Title);
        target.TitleFa = FirstNotEmpty(target.TitleFa, seed.TitleFa);
        target.FullTitle = FirstNotEmpty(target.FullTitle, seed.FullTitle);
        target.Type = FirstNotEmpty(target.Type, seed.Type);
        target.MediaKind = FirstNotEmpty(target.MediaKind, seed.MediaKind);
        target.Poster = FirstNotEmpty(target.Poster, seed.Poster);
        target.Backdrop = FirstNotEmpty(target.Backdrop, seed.Backdrop, seed.Poster);
        target.Year ??= seed.Year;
        target.Rating ??= seed.Rating;
        target.Runtime ??= seed.Runtime;
        target.Description = FirstNotEmpty(target.Description, seed.Description);
        target.LongDescription = FirstNotEmpty(target.LongDescription, seed.LongDescription, seed.Description);
        target.Status = FirstNotEmpty(target.Status, seed.Status);
        if (target.Genres.Count == 0) target.Genres = seed.Genres;
        if (target.Countries.Count == 0) target.Countries = seed.Countries;
        if (target.Actors.Count == 0) target.Actors = seed.Actors;
        if (target.Directors.Count == 0) target.Directors = seed.Directors;
    }

    private static JsonElement? FindArray(JsonElement element, params string[] properties)
    {
        foreach (var property in properties)
        {
            if (element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Array)
                return value;
        }
        return null;
    }

    private static bool TryGetObject(JsonElement element, out JsonElement result, params string[] properties)
    {
        foreach (var property in properties)
        {
            if (element.ValueKind == JsonValueKind.Object && element.TryGetProperty(property, out var value) && value.ValueKind == JsonValueKind.Object)
            {
                result = value;
                return true;
            }
        }
        result = default;
        return false;
    }

    private static string GetString(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return string.Empty;
        return value.ValueKind switch
        {
            JsonValueKind.String => value.GetString() ?? string.Empty,
            JsonValueKind.Number => value.ToString(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            _ => string.Empty
        };
    }

    private static int? GetInt(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        if (value.ValueKind == JsonValueKind.Number && value.TryGetInt32(out var number)) return number;
        var text = value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString();
        if (string.IsNullOrWhiteSpace(text)) return null;
        var digits = new string(text.Where(char.IsDigit).ToArray());
        return int.TryParse(digits, NumberStyles.Integer, CultureInfo.InvariantCulture, out number) ? number : null;
    }

    private static double? GetDouble(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        if (value.ValueKind == JsonValueKind.Number && value.TryGetDouble(out var number)) return number;
        var text = value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString();
        if (string.IsNullOrWhiteSpace(text)) return null;
        text = text.Replace(',', '.');
        return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out number) ? number : null;
    }

    private static bool? GetBool(JsonElement element, string property)
    {
        if (element.ValueKind != JsonValueKind.Object || !element.TryGetProperty(property, out var value)) return null;
        if (value.ValueKind is JsonValueKind.True or JsonValueKind.False) return value.GetBoolean();
        var text = value.ValueKind == JsonValueKind.String ? value.GetString() : value.ToString();
        return text?.Trim().ToLowerInvariant() switch
        {
            "1" or "true" or "yes" or "on" => true,
            "0" or "false" or "no" or "off" => false,
            _ => null
        };
    }

    private static string? TryReadApiMessage(string content)
    {
        try
        {
            using var document = JsonDocument.Parse(content);
            var message = GetString(document.RootElement, "message");
            return string.IsNullOrWhiteSpace(message) ? null : message;
        }
        catch
        {
            return null;
        }
    }

    private static string FirstNotEmpty(params string[] values) =>
        values.FirstOrDefault(value => !string.IsNullOrWhiteSpace(value))?.Trim() ?? string.Empty;

    public void Dispose() => _http.Dispose();
}

public sealed class Api6Exception : Exception
{
    public Api6Exception(string message, HttpStatusCode? statusCode = null, Exception? innerException = null)
        : base(message, innerException)
    {
        StatusCode = statusCode;
    }

    public HttpStatusCode? StatusCode { get; }
}
