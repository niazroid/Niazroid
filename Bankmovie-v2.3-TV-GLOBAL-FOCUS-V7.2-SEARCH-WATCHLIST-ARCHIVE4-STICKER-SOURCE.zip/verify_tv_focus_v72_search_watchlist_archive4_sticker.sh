#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.2 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT'
need "$MARKER" 'verifierPatch=V7.2 SEARCH-IME + WATCHLIST-PHYSICAL-RTL + ARCHIVE4-PALETTE + DETAIL-SEAM + STICKER-DPAD'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V72-20260907'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_2_SEARCH_WATCHLIST_ARCHIVE4_STICKER_FIX_FA.md' 'Search + Watchlist RTL + Archive4 Palette + Detail Seam + Comment/Reply Sticker TV'

# Search: short OK on the real TV EditText must explicitly request the IME.
need "$MAIN" 'private fun requestTvSoftKeyboard(input: EditText): Boolean'
need "$MAIN" 'imm?.restartInput(input)'
need "$MAIN" 'imm?.showSoftInput(input, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)'
need "$MAIN" 'focusedEditor?.tag == "bm_tv_search_input"'
need "$MAIN" 'requestTvSoftKeyboard(focusedEditor)'

# Watchlist: own the surface and route by physical X, not RTL child arithmetic.
need "$MAIN" 'private fun wireV72WatchlistGrid(grid: GridLayout)'
need "$MAIN" 'view.getLocationOnScreen(loc)'
need "$MAIN" 'val physicalRow = rowCells(raw)'
need "$MAIN" 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)'
need "$MAIN" 'wireV72WatchlistGrid(grid)'

# Archive 4 poster palette and hero seam containment.
need "$MAIN" 'val forceArchive4PosterPalette = detailArchiveForArtwork == 4 && poster.isNotBlank()'
need "$MAIN" 'val tiny = Bitmap.createScaledBitmap(bitmap, 2, 2, true)'
need "$MAIN" 'V7.2: the old 8dp hard guard still exposed a bright palette band'
need "$MAIN" 'FrameLayout.LayoutParams(-1, dp(42), Gravity.BOTTOM)'
need "$MAIN" 'FrameLayout.LayoutParams(-1, dp(14), Gravity.BOTTOM)'

# Comment/reply media picker: physical horizontal direction + explicit vertical rows.
need "$MAIN" 'fun wireCommentMediaPickerTv()'
need "$MAIN" 'val tabsByPhysicalX = liveTabs.sortedBy(::centerX)'
need "$MAIN" 'val physicalRow = cells.filter { it.first / cols == row }.sortedBy { centerX(it.second) }'
need "$MAIN" 'android.view.KeyEvent.KEYCODE_DPAD_UP ->'
need "$MAIN" 'android.view.KeyEvent.KEYCODE_DPAD_DOWN -> move(at(raw + cols))'

echo 'TV_FOCUS_V72_SEARCH_WATCHLIST_ARCHIVE4_STICKER_OK'
