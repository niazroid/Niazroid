#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v72_search_watchlist_archive4_sticker.sh
  echo 'V7_2_COMPAT_OK'
  exit 0
fi
if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V7.0 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V7.0 WEEKLY PROFILE ROOT'
need "$MARKER" 'verifierPatch=V7.0 LIVE-WEEKLY + RTL-PROFILE ROUTER'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V70-20260907'
need 'app/build.gradle' 'versionName "2.3"'
need 'BANKMOVIE_TV_FOCUS_V7_0_WEEKLY_PROFILE_ROOT_FA.md' 'Weekly + Profile Root'

# V7.0 must run before V6.9/V6.8 compatibility routers.
need "$MAIN" 'private fun handleV70WeeklyProfileDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleV70WeeklyProfileDirectionalFocus(focused, keyCode)?.let { return it }'

# Weekly live-row router and first-render recovery.
need "$MAIN" 'private fun wireV70WeeklySurface()'
need "$MAIN" 'registration.section.tag = "bm_v70_surface_weekly"'
need "$MAIN" 'tab.tag = "bm_v70_weekly_tab_$index"'
need "$MAIN" 'item.tag = "bm_v70_weekly_item_$index"'
need "$MAIN" 'tvDirectionalActions.remove(tab)'
need "$MAIN" 'tab.setOnKeyListener(null)'
need "$MAIN" 'focusedChildIndex(registration.tabsRow, focused)'
need "$MAIN" 'focusedChildIndex(registration.itemsRow, focused)'
need "$MAIN" 'private fun v70FocusWeeklyStable(target: View?): Boolean'
need "$MAIN" 'listOf(16L, 40L, 80L, 140L).forEach { delay ->'
need "$MAIN" 'wireV70WeeklySurface()'
need "$MAIN" 'return v70FocusWeeklyStable(target)'
need "$MAIN" 'private var tvV70WeeklyItemsArmedGeneration = -1'
need "$MAIN" 'item.isFocusable = weeklyItemsArmed'
need "$MAIN" 'private fun v70EnterWeeklyItems(registration: HomeTvWeeklyFocusRegistration): Boolean'
need "$MAIN" 'return v70EnterWeeklyItems(registration)'
need "$MAIN" 'tvV70WeeklyItemsArmedGeneration = -1'

# Profile RTL router: LEFT increases child index, RIGHT decreases it.
need "$MAIN" 'tag = "bm_v70_profile_actions_grid"'
need "$MAIN" 'tag = "bm_v70_profile_utility_grid"'
need "$MAIN" 'private fun wireV70ProfileSurface(page: View)'
need "$MAIN" 'cells.getOrNull(index + 1)?.let { requestTvFocusVerified(it) } ?: true'
need "$MAIN" 'val previous = cells.getOrNull(index - 1)'
need "$MAIN" 'page.postOnAnimation {'
need "$MAIN" 'if (currentScreen == "profile") wireV70ProfileSurface(page)'

python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
# Old V6.9 weekly wiring must be declaration-only. Continue remains intentionally V6.9.
if s.count('wireV69WeeklySurface()') != 1:
    raise SystemExit('V7.0 guard failed: active V6.9 Weekly wiring still exists')
# Confirm the two already-good surfaces were not removed.
for marker in [
    'tag = "bm_v68_surface_boxoffice"',
    'fun wireAdvancedFiltersTvV68()',
    'private fun wireV69ContinueRail(header: View, row: ViewGroup)',
]:
    if marker not in s:
        raise SystemExit('V7.0 unexpectedly removed confirmed-good surface marker: ' + marker)
# The generic profile GridLayout route is known LTR-oriented; V7 must be before it.
a=s.index('handleV70WeeklyProfileDirectionalFocus(focused, keyCode)?.let { return it }')
b=s.index('handleTvGridDirectionalFocus(focused, keyCode)?.let { return it }')
if a >= b:
    raise SystemExit('V7.0 profile router is not before generic GridLayout routing')
PY

echo 'TV_FOCUS_V70_WEEKLY_PROFILE_ROOT_OK'
