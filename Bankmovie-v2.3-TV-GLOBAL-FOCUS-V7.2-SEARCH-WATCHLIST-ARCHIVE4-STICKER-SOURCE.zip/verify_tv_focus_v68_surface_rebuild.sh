#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v72_search_watchlist_archive4_sticker.sh
  echo 'V7_2_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
MARKER='BANKMOVIE_BUILD_SOURCE_2_3.txt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V6.8 marker: $2" >&2; exit 1; }; }

need "$MARKER" 'focusPatch=V6.8 SURFACE REBUILD ROOT'
need "$MARKER" 'sourceTag=BANKMOVIE-TV-2.3-V68-20260907'
need 'app/build.gradle' 'versionName "2.3"'

# One router owns the managed surfaces before all legacy/global focus paths.
need "$MAIN" 'private fun handleV68ManagedSurfaceDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'handleV68ManagedSurfaceDirectionalFocus(focused, keyCode)?.let { return it }'
need "$MAIN" 'private fun v68ConsumeOrMove(target: View?): Boolean'
need "$MAIN" 'view.postOnAnimation { v68RequestFocus(view) }'

# Generic geometry must be disabled for managed surfaces.
need "$MAIN" 'private fun applyTvFocusToClickableTree(view: View, buildDirectionalGraph: Boolean = true)'
need "$MAIN" 'if (buildDirectionalGraph) {'
need "$MAIN" 'applyTvFocusToClickableTree(section, buildDirectionalGraph = false)'
need "$MAIN" 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)'
need "$MAIN" 'applyTvFocusToClickableTree(body, buildDirectionalGraph = genericTvRouting)'

# Weekly: first render and changed-day render share the same index router.
need "$MAIN" 'private fun wireV68WeeklySurface()'
need "$MAIN" 'view.tag = "bm_v68_weekly_tab_$index"'
need "$MAIN" 'view.tag = "bm_v68_weekly_item_$index"'
need "$MAIN" 'return v68RequestFocus(target)'
need "$MAIN" 'return v68RequestFocus(items.firstOrNull())'
need "$MAIN" 'wireV68WeeklySurface()'

# Box Office: strict #1..N list, hard edges, no geometry graph.
need "$MAIN" 'tag = "bm_v68_surface_boxoffice"'
need "$MAIN" 'row.tag = "bm_v68_boxoffice_item_$i"'
need "$MAIN" 'wireV68BoxOfficeSurface(tvBoxOfficeRows)'
need "$MAIN" '"boxoffice" -> content.findViewWithTag<View>("bm_v68_boxoffice_item_0")'

# Continue Watching: one focus owner per card for rail and full list.
need "$MAIN" 'private fun wireV68ContinueRail(header: View, row: ViewGroup)'
need "$MAIN" 'it.tag = "bm_v68_continue_rail_item_$index"'
need "$MAIN" 'private fun wireV68ContinueFullList(list: ViewGroup)'
need "$MAIN" 'tag = "bm_v68_continue_full_item_$index"'
need "$MAIN" 'wireV68ContinueFullList(list)'

# Advanced Filters: Dialog owns a single key router; no delayed generic graph.
need "$MAIN" 'fun wireAdvancedFiltersTvV68()'
need "$MAIN" 'V6.8: Advanced Filters has one router: Dialog.setOnKeyListener.'
need "$MAIN" 'genericTvRouting = false'
need "$MAIN" 'preferredFocus = typeChips[state.type] ?: typeChipOrder.firstOrNull() ?: applyButton'
need "$MAIN" 'fun focus(target: View?): Boolean = target?.let { v68RequestFocus(it) } ?: true'

python3 - "$MAIN" <<'PY'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
# V6.8 surfaces must no longer invoke the legacy surface routers.
for forbidden in [
    'wireTvContinueRailExact(continueHeader, row)',
    'wireTvContinueFullListExact(list)',
    'handleHomeWeeklyDirectionalFocus(focused, keyCode)?.let { return it }',
    'wireHomeWeeklyFocus()\n',
]:
    if forbidden in s:
        raise SystemExit('V6.8 legacy surface invocation is still active: ' + forbidden.strip())

a=s.index('private fun showBoxOffice()')
b=s.index('private fun showCollections()', a)
box=s[a:b]
if 'wireTvVerticalSequence(tvBoxOfficeRows)' in box or 'val wireBoxOffice = {' in box:
    raise SystemExit('V6.8 Box Office still invokes the legacy router')
if 'applyTvFocusToClickableTree(page, buildDirectionalGraph = false)' not in box:
    raise SystemExit('V6.8 Box Office generic graph is not disabled')

a=s.index('private fun showAdvancedFiltersDialog(')
b=s.index('private fun advancedSearchAccordion(', a)
adv=s[a:b]
if 'wireAdvancedFiltersTvExact' in adv:
    raise SystemExit('V6.8 Advanced Filters still invokes the legacy exact router')
if 'setOnKeyListener { _, keyCode, event ->' in adv.split('fun wireAdvancedFiltersTvV68()',1)[1].split('dialog = AlertDialog.Builder',1)[0]:
    raise SystemExit('V6.8 Advanced Filters still installs per-view key listeners')
PY

echo 'TV_FOCUS_V68_SURFACE_REBUILD_ROOT_OK'
