#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v72_search_watchlist_archive4_sticker.sh
  echo 'V7_2_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need(){ grep -Fq "$2" "$1" || { echo "Missing V6.7 marker: $2" >&2; exit 1; }; }
need "$MAIN" 'genericTvRouting: Boolean = true'
need "$MAIN" 'if (genericTvRouting) wireTvDeterministicSurface(body)'
need "$MAIN" 'dialog.setOnKeyListener'
need "$MAIN" 'genericTvRouting = false'
need "$MAIN" 'tag = "bm_tv_continue_card"'
need "$MAIN" 'isClickable = false'
need "$MAIN" 'isFocusable = false'
need "$MAIN" 'Do not lie to dispatchKeyEvent.'
need "$MAIN" 'return false'
need "$MAIN" 'V6.7 ROOT: never swallow an unhandled DPAD event.'
need "$MAIN" 'if (currentScreen == "boxoffice") {'
need "$MAIN" 'resolve Continue Watching from the live row/list instead'
if grep -Fq 'return if (currentScreen == "home") {' "$MAIN"; then
  echo 'V6.7 guard failed: Home still blanket-swallows DPAD' >&2
  exit 1
fi
python3 - "$MAIN" <<'PY2'
import sys
from pathlib import Path
s=Path(sys.argv[1]).read_text()
a=s.index('private fun requestHomeTvWeeklyItemEntry()')
b=s.index('private fun homeTvWeeklySelectedTab()', a)
chunk=s[a:b]
if 'return registration.itemsRow.childCount > 0' in chunk:
    raise SystemExit('V6.7 guard failed: Weekly still reports queued success without focus')
if 'requestTvFocusVerified(firstItem)' not in chunk:
    raise SystemExit('V6.7 guard failed: Weekly does not verify real focus')
PY2
echo 'TV_FOCUS_V67_NATIVE_FIRST_ROOT_OK'
