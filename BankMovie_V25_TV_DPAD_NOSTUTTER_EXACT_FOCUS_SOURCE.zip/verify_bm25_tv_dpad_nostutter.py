#!/usr/bin/env python3
"""Guard TV focus hot path against O(N) scans, scroll fights, and Back fade lag.
Source-shape checks only; real 4K / 60 Hz TV profiling remains necessary.
"""
from pathlib import Path
s=(Path(__file__).parent/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
def chunk(a,b):
    assert a in s and b in s, (a,b)
    return s.split(a,1)[1].split(b,1)[0]
remember=chunk('private fun rememberTvFocusPosition(', 'private fun scrollTvFocusedIntoView(')
home_focus=chunk('private fun requestHomeTvFocus(target: View?)', 'private fun reconcileHomeTvFocusAndViewport(')
verify=chunk('private fun reconcileHomeTvFocusAndViewport(', 'private fun homeTvFirstVisualPoster(')
restore=chunk('private fun tryRestoreHomeSession()', 'private fun restoreRetainedNavigationScreen(')
lifecycle=chunk('private fun rebindHomeTvFocusAfterLifecycle()', 'private fun handleHomePosterDirectionalFocus(')
generic=chunk('private fun requestTvFocusVerified(target: View?)', '// V6.8 SURFACE REBUILD')
assert 'collectTvFocusables(' not in remember, 'Full screen scan on every focus change'
assert 'tvLastContentFocus = view' in remember, 'Focused identity must remain exact'
assert '\n        releaseTvFocusScrollGuards(content)' not in home_focus, 'Full tree scan on DPAD'
assert 'requestHomeTvFocusWithoutAutoScroll(view)' in home_focus
assert 'tvHomeVerticalMotion?.cancel()' in home_focus
assert 'tvHomeHorizontalMotion?.cancel()' in home_focus
assert home_focus.count('view.postOnAnimation') == 1
assert 'view.postDelayed(' not in home_focus
assert 'settleHomeTvPosterViewport(view)' not in verify, 'No resettling during active animation'
assert 'requestHomeTvFocusWithoutAutoScroll(view)' in verify
assert 'content.animate().alpha(1f)' not in restore
assert 'snapshot.homeRailOffsets.forEach' in restore
assert 'requestHomeTvFocusWithoutAutoScroll(target)' in restore
assert 'releaseTvFocusScrollGuards(content)' not in restore
assert 'releaseTvFocusScrollGuards(content)' not in lifecycle
assert 'if (tvDirectionalActions.isEmpty()) wireHomePosterRows()' in lifecycle
assert 'return requestHomeTvFocus(view)' in generic
assert 'private fun animateHomeTvVertical(' in s
assert 'private fun animateHomeTvHorizontal(' in s
assert 'duration = 135L' in s and 'duration = 120L' in s
assert 'private fun requestHomeTvFocusWithoutAutoScroll(' in s
assert 'tvHomeActivatedPoster?.takeIf' in s
print('BANKMOVIE_TV_DPAD_NOSTUTTER_GUARDS_OK (source only)')
