#!/usr/bin/env bash
set -euo pipefail
python3 - <<'PYTEST'
from pathlib import Path
import re
p=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
w=Path('.github/workflows/build-bankmovie.yml').read_text()
for token in (
    'Intent.ACTION_OPEN_DOCUMENT', 'Intent.CATEGORY_OPENABLE',
    'REQ_LOCAL_SUBTITLE', 'contentResolver.openInputStream(source)',
    'MAX_LOCAL_SUBTITLE_BYTES', 'mp.addSlave(Media.Slave.Type.Subtitle, file.absolutePath, true)',
    'handler.postDelayed({ attachManualSubtitle(mp) }, 250L)',
    'subtitleDelayMs.toLong() * 1000L' if False else 'delayMs.toLong() * 1000L',
    '"−۰٫۰۱" to -10', '"+۰٫۰۱" to 10',
    'if (!settingsApplied) applySubtitleDelay()',
    'manualSubtitleSource != tracks[index].url',
):
    assert token in p, f'Missing functional player feature: {token}'
for token in (
    'val securityNote = LinearLayout(this).apply',
    'امکان تغییر هر ۷ روز یک‌بار',
    'setImageResource(if (changePassword) R.drawable.ic_auth_lock else R.drawable.ic_auth_user)',
    'val current = field(t("رمز عبور فعلی"',
    'val confirm = if (changePassword) field(t("تکرار رمز جدید"',
    'AccountApi.changePassword(this, oldPassword, nextPassword, repeatPassword, callback)',
    'AccountApi.changeUsername(this, username, oldPassword, callback)',
    'dialog.window?.setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT)',
):
    assert token in m, f'Missing account validation/design: {token}'
assert 'BankMovie_Android_FULLSOURCE_V2.4_MANUAL_SUBTITLE_PROFILE_REDESIGN_V22_5_7_10.zip' in w
assert w.count('bash verify_v22_5_7_10_manual_subtitle_profile.sh') == 1
print('VERIFY_V22_5_7_10_SUBTITLE_PROFILE_OK')
PYTEST
