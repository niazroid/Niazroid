package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.animation.PathInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Lightweight day/night switch with a high-contrast sun for light mode. */
class BmThemeSwitchView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var progress = 0f // 0 = day, 1 = night
    private var animator: ValueAnimator? = null
    private var listener: ((Boolean) -> Unit)? = null
    var dark: Boolean = true
        private set

    init {
        isClickable = true
        isFocusable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        setOnClickListener { setDark(!dark, true, true) }
    }

    fun setOnDarkChangeListener(block: (Boolean) -> Unit) { listener = block }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isEnabled && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == KeyEvent.KEYCODE_ENTER ||
                keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                keyCode == KeyEvent.KEYCODE_BUTTON_A ||
                keyCode == KeyEvent.KEYCODE_SPACE)) {
            performClick()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }


    fun setDark(value: Boolean, animate: Boolean = false, notify: Boolean = false) {
        dark = value
        val target = if (value) 1f else 0f
        animator?.cancel()
        if (animate) {
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 420L
                interpolator = PathInterpolator(0.2f, 0.85f, 0.25f, 1f)
                addUpdateListener { progress = it.animatedValue as Float; invalidate() }
                start()
            }
        } else {
            progress = target
            invalidate()
        }
        contentDescription = if (dark) "تم مشکی" else "تم روشن"
        if (notify) listener?.invoke(value)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val radius = h / 2f
        rect.set(0f, 0f, w, h)

        paint.style = Paint.Style.FILL
        paint.color = blend(Color.rgb(73, 160, 224), Color.rgb(25, 29, 45), progress)
        paint.setShadowLayer(h * 0.045f, 0f, h * 0.025f, Color.argb(65, 0, 0, 0))
        canvas.drawRoundRect(rect, radius, radius, paint)
        paint.clearShadowLayer()

        // Day clouds remain clearly visible but never cover the sun.
        val dayAlpha = (255f * (1f - progress)).toInt().coerceIn(0, 255)
        paint.color = Color.argb(dayAlpha, 246, 252, 255)
        val cloudR = h * 0.14f
        val cloudY = h * (0.78f + progress * 0.85f)
        for (i in 0..4) {
            canvas.drawCircle(w * (0.53f + i * 0.105f), cloudY - (i % 2) * cloudR * 0.36f, cloudR, paint)
        }

        // Night stars.
        paint.color = Color.argb((245f * progress).toInt().coerceIn(0, 245), 255, 255, 255)
        val starY = h * (0.25f + (1f - progress) * -0.65f)
        listOf(0.14f to 1f, 0.29f to 0.72f, 0.43f to 0.52f).forEach { (xf, scale) ->
            drawStar(canvas, w * xf, starY + h * (xf - 0.2f) * 0.20f, h * 0.055f * scale, paint)
        }

        val centerX = h * 0.50f + (w - h) * progress
        val centerY = h / 2f
        val bodyR = h * 0.31f

        // Soft expanding halo around the moving sun/moon.
        paint.style = Paint.Style.FILL
        paint.color = Color.argb(30, 255, 255, 255)
        canvas.drawCircle(centerX, centerY, h * 0.61f, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = h * 0.075f
        paint.color = Color.argb(34, 255, 255, 255)
        canvas.drawCircle(centerX, centerY, h * 0.48f, paint)

        // Sun rays fade out as night arrives. The dark outline keeps the sun visible on light screens.
        val rayAlpha = (255f * (1f - progress)).toInt().coerceIn(0, 255)
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = h * 0.045f
        paint.color = Color.argb(rayAlpha, 255, 223, 78)
        for (i in 0 until 8) {
            val a = Math.toRadians((i * 45.0))
            val r1 = bodyR * 1.17f
            val r2 = bodyR * 1.38f
            canvas.drawLine(
                centerX + cos(a).toFloat() * r1,
                centerY + sin(a).toFloat() * r1,
                centerX + cos(a).toFloat() * r2,
                centerY + sin(a).toFloat() * r2,
                paint
            )
        }

        paint.style = Paint.Style.FILL
        paint.color = blend(Color.rgb(255, 211, 45), Color.rgb(204, 210, 221), progress)
        paint.setShadowLayer(h * 0.09f, 0f, h * 0.045f, Color.argb(110, 0, 0, 0))
        canvas.drawCircle(centerX, centerY, bodyR, paint)
        paint.clearShadowLayer()

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = h * 0.026f
        paint.color = blend(Color.rgb(182, 126, 0), Color.rgb(143, 151, 170), progress)
        canvas.drawCircle(centerX, centerY, bodyR, paint)
        paint.style = Paint.Style.FILL

        // Moon craters.
        paint.color = Color.argb((190f * progress).toInt().coerceIn(0, 190), 143, 151, 173)
        canvas.drawCircle(centerX - bodyR * 0.35f, centerY + bodyR * 0.19f, bodyR * 0.22f, paint)
        canvas.drawCircle(centerX + bodyR * 0.29f, centerY + bodyR * 0.03f, bodyR * 0.12f, paint)
        canvas.drawCircle(centerX - bodyR * 0.02f, centerY - bodyR * 0.39f, bodyR * 0.08f, paint)
    }

    private fun drawStar(canvas: Canvas, x: Float, y: Float, r: Float, p: Paint) {
        val path = Path()
        path.moveTo(x, y - r)
        path.lineTo(x + r * 0.28f, y - r * 0.28f)
        path.lineTo(x + r, y)
        path.lineTo(x + r * 0.28f, y + r * 0.28f)
        path.lineTo(x, y + r)
        path.lineTo(x - r * 0.28f, y + r * 0.28f)
        path.lineTo(x - r, y)
        path.lineTo(x - r * 0.28f, y - r * 0.28f)
        path.close()
        canvas.drawPath(path, p)
    }

    private fun blend(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    )
}
