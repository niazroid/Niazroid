package ir.bankmoviee.app

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.Locale

object InternalDownloadStore {
    const val PREFS = "bankmovie_internal_downloads"
    private const val KEY_ITEMS = "items"

    const val STATUS_QUEUED = "queued"
    const val STATUS_DOWNLOADING = "downloading"
    const val STATUS_PAUSED = "paused"
    const val STATUS_COMPLETED = "completed"
    const val STATUS_FAILED = "failed"
    const val STATUS_CANCELLED = "cancelled"

    const val STORAGE_FILE = "file"
    const val STORAGE_TREE = "tree"

    private val lock = Any()

    fun idFor(url: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(url.toByteArray(Charsets.UTF_8))
        return bytes.take(10).joinToString("") { "%02x".format(it) }
    }

    fun all(context: Context): MutableList<JSONObject> = synchronized(lock) {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ITEMS, "[]") ?: "[]"
        val array = try { JSONArray(raw) } catch (_: Throwable) { JSONArray() }
        MutableList(array.length()) { index -> JSONObject(array.optJSONObject(index)?.toString() ?: "{}") }
            .filter { it.optString("id").isNotBlank() }
            .sortedByDescending { it.optLong("created_at", 0L) }
            .toMutableList()
    }

    fun get(context: Context, id: String): JSONObject? = all(context).firstOrNull { it.optString("id") == id }

    fun upsert(context: Context, item: JSONObject) = synchronized(lock) {
        val list = all(context)
        val id = item.optString("id")
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index >= 0) list[index] = JSONObject(item.toString()) else list.add(0, JSONObject(item.toString()))
        save(context, list)
    }

    fun update(context: Context, id: String, block: (JSONObject) -> Unit): JSONObject? = synchronized(lock) {
        val list = all(context)
        val index = list.indexOfFirst { it.optString("id") == id }
        if (index < 0) return@synchronized null
        val item = JSONObject(list[index].toString())
        block(item)
        list[index] = item
        save(context, list)
        JSONObject(item.toString())
    }

    fun exists(context: Context, item: JSONObject): Boolean {
        return if (item.optString("storage_mode") == STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isBlank()) false else runCatching {
                DocumentFile.fromSingleUri(context, Uri.parse(raw))?.exists() == true
            }.getOrDefault(false)
        } else {
            val path = item.optString("path")
            path.isNotBlank() && File(path).exists()
        }
    }

    fun deleteDownloadedFile(context: Context, item: JSONObject) {
        if (item.optString("storage_mode") == STORAGE_TREE) {
            val raw = item.optString("document_uri")
            if (raw.isNotBlank()) runCatching {
                DocumentFile.fromSingleUri(context, Uri.parse(raw))?.delete()
            }
        } else {
            val path = item.optString("path")
            if (path.isNotBlank()) runCatching { File(path).delete() }
        }
    }

    fun remove(context: Context, id: String, deleteFile: Boolean = false) = synchronized(lock) {
        val list = all(context)
        val item = list.firstOrNull { it.optString("id") == id }
        if (deleteFile && item != null) deleteDownloadedFile(context, item)
        save(context, list.filterNot { it.optString("id") == id })
    }

    fun clearCompleted(context: Context) = synchronized(lock) {
        val list = all(context)
        save(context, list.filterNot { it.optString("status") == STATUS_COMPLETED })
    }

    fun create(
        url: String,
        title: String,
        quality: String,
        kind: String,
        displayLabel: String,
        fileName: String,
        path: String
    ): JSONObject = JSONObject().apply {
        put("id", idFor(url))
        put("url", url)
        put("title", title.ifBlank { "Bankmovie" })
        put("quality", quality)
        put("kind", kind)
        put("display_label", displayLabel)
        put("file_name", fileName)
        put("path", path)
        put("storage_mode", STORAGE_FILE)
        put("tree_uri", "")
        put("document_uri", "")
        put("location_label", "")
        put("status", STATUS_QUEUED)
        put("downloaded", 0L)
        put("total", 0L)
        put("speed", 0L)
        put("error", "")
        put("created_at", System.currentTimeMillis())
        put("updated_at", System.currentTimeMillis())
    }

    fun safeFileName(title: String, quality: String, kind: String, url: String): String {
        val extension = extensionFromUrl(url)
        val base = listOf(title, quality, kind)
            .filter { it.isNotBlank() }
            .joinToString(" - ")
            .replace(Regex("[\\/:*?\"<>|\\u0000-\\u001F]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
            .take(110)
            .ifBlank { "Bankmovie-${idFor(url)}" }
        return "$base.$extension"
    }

    fun mimeForName(fileName: String): String {
        return when (fileName.substringAfterLast('.', "").lowercase(Locale.US)) {
            "mkv" -> "video/x-matroska"
            "m3u8" -> "application/vnd.apple.mpegurl"
            "mp3" -> "audio/mpeg"
            "mka" -> "audio/x-matroska"
            "srt" -> "application/x-subrip"
            "vtt" -> "text/vtt"
            else -> "video/mp4"
        }
    }

    private fun extensionFromUrl(url: String): String {
        val clean = url.substringBefore('?').substringBefore('#')
        val ext = clean.substringAfterLast('.', "").lowercase(Locale.US)
        return if (ext.matches(Regex("[a-z0-9]{2,5}"))) ext else "mp4"
    }

    private fun save(context: Context, items: List<JSONObject>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject(it.toString())) }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ITEMS, array.toString()).apply()
    }
}
