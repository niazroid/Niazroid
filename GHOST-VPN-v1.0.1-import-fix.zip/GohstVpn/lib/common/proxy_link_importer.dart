/// Local conversion of share-link subscriptions to Mihomo's YAML/JSON format.
///
/// No subscription URL, proxy credential or server name is sent to a third
/// party. A failed conversion is never silently replaced by a working-looking
/// but incompatible node; successful nodes are retained and failures reported.
import 'dart:convert';
import 'dart:typed_data';

import 'package:fl_clash/common/gohst_display_name.dart';

class ProxyLinkImporter {
  static final RegExp _uuidPattern = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );
  static final RegExp _shareLink = RegExp(
    r'(?:vless|vmess|trojan|ss|hysteria2|hy2)://[^\s<>`"\x27]+',
    caseSensitive: false,
  );
  static final RegExp _unsupportedLink = RegExp(
    r'(?:ssr|tuic|hysteria)://',
    caseSensitive: false,
  );

  static bool isNodeLink(String input) => _shareLink.matchAsPrefix(input.trimLeft()) != null;

  static int countLinks(String input) => _shareLink.allMatches(input).length;

  static Uint8List normalize(
    Uint8List bytes, {
    void Function(List<String>)? onWarnings,
  }) {
    String source;
    try {
      source = utf8.decode(bytes).trim().replaceFirst('\uFEFF', '');
    } on FormatException {
      return bytes;
    }
    if (source.isEmpty) return bytes;
    // Native Mihomo YAML and JSON must pass through without modification.
    if (source.startsWith('{') ||
        RegExp(r'^(?:proxies|proxy-providers|mixed-port|port|socks-port|rules):',
                caseSensitive: false)
            .hasMatch(source)) {
      return bytes;
    }

    var content = source;
    if (!content.contains('://')) {
      try {
        final decoded = _decodeBase64(content.replaceAll(RegExp(r'\s+'), ''));
        if (_shareLink.hasMatch(decoded) || _unsupportedLink.hasMatch(decoded)) {
          content = decoded;
        }
      } on FormatException {
        // Not a share-link subscription; preserve for the original parser.
      }
    }
    if (!_shareLink.hasMatch(content)) return bytes;

    final links = _shareLink
        .allMatches(content)
        .map((match) => match.group(0)!)
        .map((link) => link.replaceFirst(RegExp(r'[\]\)>,;]+$'), ''))
        .toList();
    final proxies = <Map<String, Object>>[];
    final warnings = <String>[];
    final unsupported = _unsupportedLink.allMatches(content).length;
    if (unsupported > 0) {
      warnings.add('$unsupported unsupported share-link protocol(s) skipped');
    }
    final names = <String>{};
    for (final (index, link) in links.indexed) {
      try {
        final scheme = link.substring(0, link.indexOf('://')).toLowerCase();
        final node = switch (scheme) {
          'vless' => _parseVless(link),
          'vmess' => _parseVmess(link),
          'trojan' => _parseTrojan(link),
          'ss' => _parseShadowsocks(link),
          'hy2' || 'hysteria2' => _parseHysteria2(link),
          _ => throw const FormatException('unsupported protocol'),
        };
        final original = node['name'] as String;
        var name = original;
        for (var number = 2; names.contains(name); number++) {
          name = '$original ($number)';
        }
        names.add(name);
        node['name'] = name;
        proxies.add(node);
      } on FormatException catch (error) {
        // Never reveal passwords, node UUIDs or subscription tokens in a log.
        warnings.add('Link ${index + 1}: ${error.message}');
      }
    }
    if (proxies.isEmpty) {
      throw FormatException(
        'No compatible proxy nodes found.\n${warnings.join('\n')}',
      );
    }
    if (warnings.isNotEmpty) onWarnings?.call(List.unmodifiable(warnings));
    final namesList = proxies.map((node) => node['name'] as String).toList();
    final configuration = <String, Object>{
      'mixed-port': 7890,
      'allow-lan': false,
      'mode': 'rule',
      'log-level': 'warning',
      'proxies': proxies,
      'proxy-groups': [
        {
          'name': 'GHOST VPN',
          'type': 'select',
          'proxies': [...namesList, 'DIRECT'],
        },
      ],
      'rules': ['MATCH,GHOST VPN'],
    };
    return Uint8List.fromList(utf8.encode(jsonEncode(configuration)));
  }

  static String _decodeBase64(String raw) {
    final prepared = base64.normalize(raw.replaceAll('-', '+').replaceAll('_', '/'));
    return utf8.decode(base64.decode(prepared));
  }

  static Uri _validUri(String link, String scheme) {
    final uri = Uri.tryParse(link);
    if (uri == null || uri.scheme.toLowerCase() != scheme || uri.host.isEmpty) {
      throw const FormatException('invalid share link');
    }
    if (uri.port < 1 || uri.port > 65535) {
      throw const FormatException('invalid server port');
    }
    return uri;
  }

  static String _label(String fragment, String fallback) {
    final name = gohstDisplayName(fragment);
    return name.isEmpty ? fallback : name;
  }

  static List<String> _values(String? value) =>
      (value ?? '').split(',').where((part) => part.trim().isNotEmpty).toList();

  static bool _explicitlyInsecure(Map<String, String> query) =>
      query['insecure'] == '1' || query['allowInsecure'] == '1' ||
      query['allow_insecure'] == '1';

  static Map<String, Object> _parseVless(String link) {
    final uri = _validUri(link, 'vless');
    if (!_uuidPattern.hasMatch(uri.userInfo)) {
      throw const FormatException('invalid VLESS UUID');
    }
    final p = uri.queryParameters;
    final transport = (p['type'] ?? 'tcp').toLowerCase();
    if (!{'tcp', 'ws', 'grpc', 'http', 'h2', 'xhttp', 'httpupgrade'}
        .contains(transport)) {
      throw FormatException('unsupported transport "$transport"');
    }
    final header = (p['headerType'] ?? 'none').toLowerCase();
    if (transport == 'tcp' && !{'none', 'http', ''}.contains(header)) {
      throw FormatException('unsupported TCP header "$header"');
    }
    final network = transport == 'tcp' && header == 'http'
        ? 'http'
        : transport == 'httpupgrade'
            ? 'ws'
            : transport == 'http'
                ? 'h2'
                : transport;
    final security = (p['security'] ?? 'none').toLowerCase();
    if (!{'none', '', 'tls', 'reality'}.contains(security)) {
      throw FormatException('unsupported security "$security"');
    }
    final node = <String, Object>{
      'name': _label(uri.fragment, '${uri.host}:${uri.port}'),
      'type': 'vless',
      'server': uri.host,
      'port': uri.port,
      'uuid': uri.userInfo,
      'udp': true,
      'network': network,
    };
    final enc = p['encryption'] ?? 'none';
    if (enc != 'none' && enc.isNotEmpty) node['encryption'] = enc;
    if ((p['flow'] ?? '').isNotEmpty) node['flow'] = p['flow']!;
    if (security == 'tls' || security == 'reality') {
      node['tls'] = true;
      if ((p['sni'] ?? '').isNotEmpty) node['servername'] = p['sni']!;
      if ((p['fp'] ?? '').isNotEmpty) node['client-fingerprint'] = p['fp']!;
      if ((p['alpn'] ?? '').isNotEmpty) node['alpn'] = _values(p['alpn']);
      if (_explicitlyInsecure(p)) node['skip-cert-verify'] = true;
      if (security == 'reality') {
        final pbk = p['pbk'] ?? '';
        if (pbk.isEmpty) throw const FormatException('Reality public key missing');
        node['reality-opts'] = <String, Object>{
          'public-key': pbk,
          if ((p['sid'] ?? '').isNotEmpty) 'short-id': p['sid']!,
        };
      }
      final pin = p['pcs'];
      if (pin != null && pin.isNotEmpty) {
        if (!RegExp(r'^[0-9a-fA-F]{64}$').hasMatch(pin)) {
          throw const FormatException('invalid certificate pin');
        }
        node['fingerprint'] = pin.toUpperCase();
      }
    }
    if (network == 'ws') {
      node['ws-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'headers': {'Host': p['host']!},
        if (transport == 'httpupgrade') 'v2ray-http-upgrade': true,
        if (int.tryParse(p['ed'] ?? '') case final int earlyData when earlyData > 0)
          'max-early-data': earlyData,
        if ((p['eh'] ?? '').isNotEmpty) 'early-data-header-name': p['eh']!,
      };
    } else if (network == 'http' && header == 'http') {
      // Xray's TCP HTTP header camouflage maps to Mihomo's HTTP transport.
      // Without this mapping an entire class of otherwise valid nodes was
      // previously discarded during subscription import.
      node['http-opts'] = <String, Object>{
        'method': 'GET',
        'path': _values(p['path']).isEmpty ? ['/'] : _values(p['path']),
        if ((p['host'] ?? '').isNotEmpty) 'headers': {
          'Host': _values(p['host']),
        },
      };
    } else if (network == 'xhttp') {
      final options = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'host': p['host']!,
        if ((p['mode'] ?? '').isNotEmpty) 'mode': p['mode']!,
      };
      final extra = p['extra'];
      if (extra != null && extra.isNotEmpty) {
        try {
          final object = jsonDecode(extra);
          if (object is Map) {
            // Only documented transport knobs; reject arbitrary nested data.
            for (final key in [
              'no-grpc-header', 'x-padding-bytes', 'x-padding-obfs-mode',
              'x-padding-key', 'x-padding-header', 'x-padding-placement',
              'x-padding-method', 'uplink-http-method', 'session-placement',
              'session-key', 'session-table', 'session-length',
              'seq-placement', 'seq-key', 'uplink-data-placement',
              'uplink-data-key', 'uplink-chunk-size',
            ]) {
              final value = object[key];
              if (value is String || value is bool || value is int) {
                options[key] = value;
              }
            }
            final headers = object['headers'];
            if (headers is Map && headers.keys.every((k) => k is String) &&
                headers.values.every((v) => v is String)) {
              options['headers'] = Map<String, String>.from(headers);
            }
          }
        } on FormatException {
          throw const FormatException('invalid xHTTP extra options');
        }
      }
      node['xhttp-opts'] = options;
    } else if (network == 'grpc') {
      node['grpc-opts'] = <String, Object>{
        'grpc-service-name': p['serviceName'] ?? '',
      };
    } else if (network == 'h2') {
      node['h2-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'host': _values(p['host']),
      };
    }
    return node;
  }

  static Map<String, Object> _parseVmess(String link) {
    final payload = link.substring(link.indexOf('://') + 3).split('#').first;
    Map<String, dynamic> data;
    try {
      final decoded = jsonDecode(_decodeBase64(payload));
      if (decoded is! Map) throw const FormatException('invalid VMess data');
      data = Map<String, dynamic>.from(decoded);
    } on FormatException {
      throw const FormatException('invalid VMess base64 JSON');
    }
    String field(String key) => data[key]?.toString() ?? '';
    final host = field('add');
    final port = int.tryParse(field('port')) ?? 0;
    final uuid = field('id');
    if (host.isEmpty || port < 1 || port > 65535 || !_uuidPattern.hasMatch(uuid)) {
      throw const FormatException('invalid VMess server, port or UUID');
    }
    final net = field('net').isEmpty ? 'tcp' : field('net').toLowerCase();
    final header = field('type').toLowerCase();
    if (!{'tcp', 'ws', 'grpc', 'h2', 'http'}.contains(net)) {
      throw FormatException('unsupported VMess transport "$net"');
    }
    final network = net == 'tcp' && header == 'http' ? 'http' : net;
    final name = field('ps');
    final node = <String, Object>{
      'name': name.isEmpty ? '$host:$port' : name,
      'type': 'vmess',
      'server': host,
      'port': port,
      'uuid': uuid,
      'alterId': int.tryParse(field('aid')) ?? 0,
      'cipher': field('scy').isEmpty ? 'auto' : field('scy'),
      'udp': true,
      'network': network,
    };
    if (field('tls').toLowerCase() == 'tls') {
      node['tls'] = true;
      if (field('sni').isNotEmpty) node['servername'] = field('sni');
      if (field('fp').isNotEmpty) node['client-fingerprint'] = field('fp');
      if (field('alpn').isNotEmpty) node['alpn'] = _values(field('alpn'));
    }
    if (network == 'ws') {
      node['ws-opts'] = <String, Object>{
        'path': field('path').isEmpty ? '/' : field('path'),
        if (field('host').isNotEmpty) 'headers': {'Host': field('host')},
      };
    } else if (network == 'http') {
      node['http-opts'] = <String, Object>{
        'method': 'GET',
        'path': field('path').isEmpty ? ['/'] : _values(field('path')),
        if (field('host').isNotEmpty) 'headers': {'Host': _values(field('host'))},
      };
    } else if (network == 'h2') {
      node['h2-opts'] = <String, Object>{
        'path': field('path').isEmpty ? '/' : field('path'),
        if (field('host').isNotEmpty) 'host': _values(field('host')),
      };
    } else if (network == 'grpc') {
      node['grpc-opts'] = <String, Object>{
        'grpc-service-name': field('path'),
      };
    }
    return node;
  }

  static Map<String, Object> _parseTrojan(String link) {
    final uri = _validUri(link, 'trojan');
    if (uri.userInfo.isEmpty) throw const FormatException('missing Trojan password');
    final p = uri.queryParameters;
    final network = (p['type'] ?? 'tcp').toLowerCase();
    if (!{'tcp', 'ws', 'grpc'}.contains(network)) {
      throw FormatException('unsupported Trojan transport "$network"');
    }
    final node = <String, Object>{
      'name': _label(uri.fragment, '${uri.host}:${uri.port}'),
      'type': 'trojan',
      'server': uri.host,
      'port': uri.port,
      'password': Uri.decodeComponent(uri.userInfo),
      'udp': true,
      'network': network,
      if ((p['sni'] ?? '').isNotEmpty) 'sni': p['sni']!,
      if ((p['fp'] ?? '').isNotEmpty) 'client-fingerprint': p['fp']!,
      if ((p['alpn'] ?? '').isNotEmpty) 'alpn': _values(p['alpn']),
      if (_explicitlyInsecure(p)) 'skip-cert-verify': true,
    };
    if (network == 'ws') {
      node['ws-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'headers': {'Host': p['host']!},
      };
    } else if (network == 'grpc') {
      node['grpc-opts'] = <String, Object>{
        'grpc-service-name': p['serviceName'] ?? '',
      };
    }
    return node;
  }

  static Map<String, Object> _parseShadowsocks(String link) {
    final uri = Uri.tryParse(link);
    if (uri == null || uri.scheme.toLowerCase() != 'ss') {
      throw const FormatException('invalid Shadowsocks link');
    }
    if (uri.queryParameters.containsKey('plugin')) {
      throw const FormatException('Shadowsocks plugin requires separate configuration');
    }
    var content = link.substring(5).split('#').first.split('?').first;
    if (!content.contains('@')) {
      try {
        content = _decodeBase64(content);
      } on FormatException {
        throw const FormatException('invalid Shadowsocks base64');
      }
    } else {
      final at = content.lastIndexOf('@');
      final user = content.substring(0, at);
      final address = content.substring(at + 1);
      if (!user.contains(':')) {
        try {
          content = '${_decodeBase64(user)}@$address';
        } on FormatException {
          throw const FormatException('invalid Shadowsocks credentials');
        }
      }
    }
    final at = content.lastIndexOf('@');
    if (at <= 0) throw const FormatException('invalid Shadowsocks address');
    final pair = Uri.decodeComponent(content.substring(0, at));
    final sep = pair.indexOf(':');
    if (sep <= 0 || sep == pair.length - 1) {
      throw const FormatException('invalid Shadowsocks cipher/password');
    }
    final address = Uri.tryParse('ss://user@${content.substring(at + 1)}');
    if (address == null || address.host.isEmpty ||
        address.port < 1 || address.port > 65535) {
      throw const FormatException('invalid Shadowsocks host/port');
    }
    return <String, Object>{
      'name': _label(uri.fragment, '${address.host}:${address.port}'),
      'type': 'ss',
      'server': address.host,
      'port': address.port,
      'cipher': pair.substring(0, sep),
      'password': pair.substring(sep + 1),
      'udp': true,
    };
  }

  static Map<String, Object> _parseHysteria2(String link) {
    final actualScheme = link.substring(0, link.indexOf('://')).toLowerCase();
    final uri = _validUri(link, actualScheme);
    final p = uri.queryParameters;
    if (uri.userInfo.isEmpty) throw const FormatException('missing Hysteria2 password');
    final node = <String, Object>{
      'name': _label(uri.fragment, '${uri.host}:${uri.port}'),
      'type': 'hysteria2',
      'server': uri.host,
      'port': uri.port,
      'password': Uri.decodeComponent(uri.userInfo),
      if ((p['sni'] ?? '').isNotEmpty) 'sni': p['sni']!,
      if ((p['alpn'] ?? '').isNotEmpty) 'alpn': _values(p['alpn']),
      if ((p['obfs'] ?? '').isNotEmpty) 'obfs': p['obfs']!,
      if ((p['obfs-password'] ?? p['obfsPassword'] ?? '').isNotEmpty)
        'obfs-password': p['obfs-password'] ?? p['obfsPassword']!,
      if (_explicitlyInsecure(p)) 'skip-cert-verify': true,
    };
    return node;
  }
}
