import 'dart:convert';
import 'dart:typed_data';

import 'package:fl_clash/common/proxy_link_importer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const nodeId = '00000000-0000-4000-8000-000000000001';
  const a = 'vless://$nodeId@vpn.example:443?security=tls&type=xhttp&'
      'path=%2F&host=edge.example&sni=edge.example&fp=chrome&alpn=h2#A';
  const b = 'vless://$nodeId@vpn2.example:8443?security=reality&type=tcp&'
      'pbk=examplepublickey&sid=aa&fp=chrome&sni=cdn.example#B';

  String normalizeText(String text) => utf8.decode(ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode(text))));

  test('manual multiple VLESS nodes preserve xhttp and reality settings', () {
    final conf = jsonDecode(normalizeText('$a\n$b')) as Map;
    final nodes = conf['proxies'] as List;
    expect(nodes.length, 2);
    expect(nodes[0]['network'], 'xhttp');
    expect(nodes[0]['xhttp-opts']['path'], '/');
    expect(nodes[1]['reality-opts']['short-id'], 'aa');
  });

  test('fragment is displayed as readable text after importing VLESS URI', () {
    final uri = 'vless://$nodeId@vpn.example:443?security=tls&type=ws#%F0%9F%87%A9%F0%9F%87%AA%20Germany%201';
    final config = jsonDecode(normalizeText(uri)) as Map;
    final nodes = config['proxies'] as List;
    expect(nodes.first['name'], '🇩🇪 Germany 1');
  });

  test('base64 VLESS subscription is recognized', () {
    final encoded = base64Encode(utf8.encode('$a\n$b'));
    final conf = jsonDecode(normalizeText(encoded)) as Map;
    expect((conf['proxies'] as List).length, 2);
  });

  test('valid nodes are imported while skipped nodes are reported', () {
    final warnings = <String>[];
    final result = ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode('$a\ntuic://unsupported')),
      onWarnings: warnings.addAll,
    );
    expect((jsonDecode(utf8.decode(result)) as Map)['proxies'].length, 1);
    expect(warnings.single, contains('unsupported share-link'));
    expect(() => normalizeText('vless://@:-1?security=none'), throwsFormatException);
  });

  test('YAML configs are left unchanged', () {
    const yaml = 'proxies: []\nrules: []\n';
    expect(normalizeText(yaml), yaml);
  });

  test('TLS verification is never disabled unless explicitly requested', () {
    final nodes = (jsonDecode(normalizeText(a)) as Map)['proxies'] as List;
    expect(nodes.first.containsKey('skip-cert-verify'), false);
  });
  test('Telegram numbered and markdown paste imports all nodes', () {
    final input = '1) `$a`\n2. $b\n> $a';
    final config = jsonDecode(normalizeText(input)) as Map;
    final nodes = config['proxies'] as List;
    expect(nodes.length, 3);
    expect(nodes.first['name'], 'A');
    expect(nodes.last['name'], 'A (2)');
    expect(ProxyLinkImporter.countLinks(input), 3);
  });

  test('unsupported protocols reported but valid VLESS preserved', () {
    final warnings = <String>[];
    final data = ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode('$a\ntuic://unsupported')),
      onWarnings: warnings.addAll,
    );
    expect((jsonDecode(utf8.decode(data)) as Map)['proxies'].length, 1);
    expect(warnings.single, contains('unsupported share-link'));
  });
  test('VLESS TCP HTTP camouflage is converted instead of discarded', () {
    const source = 'vless://$nodeId@vpn.example:80?type=tcp&headerType=http&'
        'host=cdn.example&path=%2Fvideo#TCP-HTTP';
    final node = (jsonDecode(normalizeText(source)) as Map)['proxies'][0] as Map;
    expect(node['network'], 'http');
    expect(node['http-opts']['method'], 'GET');
    expect(node['http-opts']['headers']['Host'], ['cdn.example']);
    expect(node['http-opts']['path'], ['/video']);
  });

  test('mixed VLESS, VMess, Trojan, Shadowsocks and Hysteria2 subscriptions', () {
    final vmess = base64Encode(utf8.encode(jsonEncode({
      'v': '2', 'ps': 'VMess sample', 'add': 'vmess.example',
      'port': '443', 'id': nodeId, 'aid': '0', 'net': 'ws',
      'host': 'ws.example', 'path': '/socket', 'tls': 'tls', 'sni': 'vmess.example'
    })));
    const vless = 'vless://$nodeId@vpn.example:443?security=tls&type=ws#VLESS';
    const trojan = 'trojan://password@trojan.example:443?type=grpc&'
        'serviceName=service&sni=trojan.example#Trojan';
    final ss = base64Encode(utf8.encode('aes-128-gcm:password'));
    const hy2 = 'hysteria2://password@hy2.example:443?'
        'sni=hy2.example&obfs=salamander&obfs-password=obfssecret#HY2';
    final input = [vless, 'vmess://$vmess', trojan,
      'ss://$ss@ss.example:8388#Shadowsocks', hy2].join('\n');
    final result = jsonDecode(normalizeText(input)) as Map;
    final nodes = result['proxies'] as List;
    expect(nodes.map((node) => node['type']).toList(),
        ['vless', 'vmess', 'trojan', 'ss', 'hysteria2']);
    expect(nodes[1]['ws-opts']['headers']['Host'], 'ws.example');
    expect(nodes[2]['grpc-opts']['grpc-service-name'], 'service');
    expect(nodes[3]['cipher'], 'aes-128-gcm');
    expect(nodes[4]['obfs'], 'salamander');
    final encoded = base64Encode(utf8.encode(input));
    expect((jsonDecode(normalizeText(encoded)) as Map)['proxies'].length, 5);
  });

  test('unsupported extras are reported without leaking passwords', () {
    const source = 'vless://$nodeId@vpn.example:443?type=ws#A\n'
      'ss://YWVzLTEyOC1nY206cGFzcw@ss.example:8388?plugin=unknown#B\n'
      'tuic://secret@tuic.example:443#C';
    final warnings = <String>[];
    final nodes = (jsonDecode(utf8.decode(ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode(source)),
      onWarnings: warnings.addAll,
    ))) as Map)['proxies'] as List;
    expect(nodes.length, 1);
    expect(warnings.join(' '), contains('plugin'));
    expect(warnings.join(' '), contains('unsupported'));
    expect(warnings.join(' '), isNot(contains('secret')));
    expect(warnings.join(' '), isNot(contains('password')));
  });

  test('httpupgrade retains the HTTP upgrade flag', () {
    const link = 'vless://$nodeId@vpn.example:443?type=httpupgrade&'
        'security=tls&path=%2Fdata&host=cdn.example#Upgrade';
    final node = (jsonDecode(normalizeText(link)) as Map)['proxies'][0];
    expect(node['network'], 'ws');
    expect(node['ws-opts']['v2ray-http-upgrade'], true);
  });

}

// Regression cases from real-world subscription *formats*; credentials and
// hostnames below are deliberately fictional.
// Keep compatibility tests independent of any provider or live network.
