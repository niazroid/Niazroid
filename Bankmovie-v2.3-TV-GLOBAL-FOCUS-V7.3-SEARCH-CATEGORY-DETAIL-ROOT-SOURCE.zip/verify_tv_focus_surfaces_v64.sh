#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.3 SEARCH CATEGORY DETAIL ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v73_search_category_detail.sh
  echo 'V7_3_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.2 SEARCH WATCHLIST ARCHIVE4 STICKER ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v72_search_watchlist_archive4_sticker.sh
  echo 'V7_2_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.1 PROFILE ABOUT DRAWER PREVIEW ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v71_profile_about_drawer.sh
  echo 'V7_1_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V7.0 WEEKLY PROFILE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v70_weekly_profile.sh
  echo 'V7_0_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.9 WEEKLY CONTINUE ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v69_weekly_continue.sh
  echo 'V6_9_COMPAT_OK'
  exit 0
fi

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need() { grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }

need "$MAIN" 'private val tvDirectionalActions = WeakHashMap<View, MutableMap<Int, () -> Boolean>>()'
need "$MAIN" 'private fun prepareTvFocusAncestors(target: View)'
need "$MAIN" 'private fun requestTvFocusVerified(target: View?): Boolean'
need "$MAIN" 'private fun handleTvGridDirectionalFocus(focused: View, keyCode: Int): Boolean?'
need "$MAIN" 'private fun wireTvGridSurface(grid: GridLayout)'
need "$MAIN" 'tvGrids.forEach { wireTvGridSurface(it) }'
need "$MAIN" 'private fun requestHomeTvWeeklyItemEntry(): Boolean'
need "$MAIN" 'bindTvDirectionalAction(tab, android.view.KeyEvent.KEYCODE_DPAD_DOWN) { requestHomeTvWeeklyItemEntry() }'
need "$MAIN" 'Continue Watching'
need "$MAIN" 'wireTvHorizontalRow(row, rightEdgeToSideNav = true) { more }'
need "$MAIN" 'val tvBoxOfficeRows = mutableListOf<View>()'
need "$MAIN" 'wireTvVerticalSequence(tvBoxOfficeRows)'
need "$MAIN" 'wireTvDeterministicSurface(page)'
need "$MAIN" 'tag = "bm_tv_search_more_filters"'
need "$MAIN" 'preferredFocus = typeChips.values.firstOrNull() ?: applyButton'

# Exact compile regression from V6.1 must remain fixed.
if grep -A4 -F 'private fun positionRailAtNewest(' "$MAIN" | grep -Fq 'row: LinearLayout,'; then
  echo 'V6.4 compile guard failed: positionRailAtNewest still requires LinearLayout' >&2
  exit 1
fi
need "$MAIN" 'row: ViewGroup,'

echo 'TV_FOCUS_SURFACES_V64_OK'
