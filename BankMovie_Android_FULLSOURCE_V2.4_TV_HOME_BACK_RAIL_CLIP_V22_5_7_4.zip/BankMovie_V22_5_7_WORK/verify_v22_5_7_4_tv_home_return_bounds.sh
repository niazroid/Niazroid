#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PYTEST'
from pathlib import Path
m=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
unclamp=m[m.index('    private fun unclampFocusGlow('):m.index('    private fun collectTvFocusables(')]
walk=m[m.index('    private fun applyTvFocusToClickableTree('):m.index('    private fun focusFirstTvClickable(')]
restore=m[m.index('    private fun restoreRetainedNavigationScreen('):m.index('    private fun pushCurrentScreenForBack(')]
assert '(isTvLike() && currentScreen == "home" && parent is HorizontalBankmovieSmoothScrollView)' in unclamp
assert '(currentScreen == "home" && v is HorizontalBankmovieSmoothScrollView)' in walk
assert 'parent.clipChildren = true' in unclamp and 'v.clipChildren = true' in walk
assert 'captureTvHomeRailOffsets(retainedChildren)' in m
assert 'tvHomeRailOffsets: List<Pair<HorizontalBankmovieSmoothScrollView, Int>>' in m
assert 'restoreRetainedTvHomeViewport(snapshot, homeScroll)' in restore
assert 'snapshot.focusedView?.takeIf' in restore
assert 'savedX.coerceIn(0, maxX)' in m
assert 'snapshot.scrollY.coerceIn(0, maxY)' in m
assert 'if (snapshot.screen == "home")' in restore
assert 'if (currentScreen == "discover"' in m
assert 'topMargin = dp(204)' in m
print('VERIFY_V22_5_7_4_TV_HOME_RETURN_BOUNDS_OK')
PYTEST
