'use strict';
// Local per-account activity. No stream URLs or credentials are retained.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {identity}=require('./continue-watching');
const hash=v=>crypto.createHash('sha256').update(String(v)).digest('hex');
const str=(v,max=240)=>String(v??'').trim().slice(0,max);
function image(v){try{const u=new URL(v);return u.protocol==='https:'&&!u.username&&!u.password&&u.href.length<=1800?u.href:'';}catch{return '';}}
const aliases={action:'اکشن',adventure:'ماجراجویی',animation:'انیمیشن',anime:'انیمه',biography:'زندگینامه',comedy:'کمدی',crime:'جنایی',documentary:'مستند',drama:'درام',family:'خانوادگی',fantasy:'فانتزی',history:'تاریخی',horror:'ترسناک',music:'موزیک',mystery:'معمایی',romance:'عاشقانه','science fiction':'علمی‌تخیلی','sci-fi':'علمی‌تخیلی','sci_fi':'علمی‌تخیلی',sport:'ورزشی',thriller:'هیجان‌انگیز',war:'جنگی',western:'وسترن'};
function genres(v){const a=Array.isArray(v)?v:typeof v==='string'?v.split(/[,،|/;]+/):[];return [...new Set(a.map(x=>str(typeof x==='object'?(x?.name_fa||x?.title_fa||x?.name||x?.title||x?.label||''):x,55)).filter(x=>x&&!/^\d+$/.test(x)).map(x=>aliases[x.toLowerCase()]||x))].slice(0,12);}
function json(file){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return null;}}
function checkpoint(dir){return ['a','b'].map(slot=>{try{const a=fs.readFileSync(path.join(dir,slot),'utf8').trim().split(/\s+/).map(Number);const [seq,seconds,position,duration,done]=a;if(a.length!==5||!Number.isSafeInteger(seq)||seq<1||!Number.isFinite(seconds)||seconds<0||!Number.isFinite(position)||position<0||!Number.isFinite(duration)||duration<=0||position>duration+5||![0,1].includes(done))return null;return {seq,seconds,position:Math.min(position,duration),duration,done:!!done};}catch{return null;}}).filter(Boolean).sort((a,b)=>b.seq-a.seq)[0]||null;}
const empty=()=>({seconds:0,movies:0,series:0,genres:[],history:[],cover:''});
function create(root){
 const scoped=scope=>path.join(root,hash(scope));
 function begin(scope,meta,source={}){const id=identity(meta);if(!scope||!id)return '';const dir=path.join(scoped(scope),'sessions',crypto.randomBytes(16).toString('hex'));fs.mkdirSync(dir,{recursive:true});const number=v=>Number.isSafeInteger(Number(v))?Math.max(0,Number(v)):0;fs.writeFileSync(path.join(dir,'meta.json'),JSON.stringify({...id,title:str(meta.title),poster:image(meta.poster),backdrop:image(meta.backdrop),genres:genres(meta.genres),season:number(source.season),episode:number(source.episode),started:Date.now()}));return dir;}
 function snapshot(scope){const out=empty();if(!scope)return out;const base=scoped(scope),all=new Map(),weights=new Map();let rows=[];try{rows=fs.readdirSync(path.join(base,'sessions'),{withFileTypes:true});}catch{}
 for(const f of rows){if(!f.isDirectory()||!/^[a-f0-9]{32}$/.test(f.name))continue;const dir=path.join(base,'sessions',f.name),m=json(path.join(dir,'meta.json')),p=checkpoint(dir);if(!m||!identity(m)||!p||p.seconds<1)continue;const {seq,...play}=p;const row={...m,...play,session:f.name};out.seconds+=p.seconds;const old=all.get(m.key);if(!old||m.started>old.started)all.set(m.key,row);const g=genres(m.genres);for(const name of g)weights.set(name,(weights.get(name)||0)+p.seconds/g.length);}
 const list=[...all.values()].sort((a,b)=>b.started-a.started);out.movies=list.filter(r=>r.type==='movie').length;out.series=list.filter(r=>r.type==='series').length;out.history=list.slice(0,150);const total=[...weights.values()].reduce((a,b)=>a+b,0);out.genres=[...weights].sort((a,b)=>b[1]-a[1]).map(([name,seconds])=>({name,percent:seconds/total*100}));const cover=json(path.join(base,'cover.json'))?.key;out.cover=typeof cover==='string'&&list.some(r=>r.key===cover&&r.backdrop)?cover:'';return out;}
 function setCover(scope,key){if(!scope)return false;const s=snapshot(scope);if(key!==''&&!s.history.some(r=>r.key===key&&r.backdrop))return false;const base=scoped(scope);fs.mkdirSync(base,{recursive:true});const tmp=path.join(base,'cover.tmp');fs.writeFileSync(tmp,JSON.stringify({key}));fs.renameSync(tmp,path.join(base,'cover.json'));return true;}
 return {begin,snapshot,setCover};
}
module.exports={create,genres,checkpoint};
