'use strict';
const assert=require('node:assert/strict'),fs=require('fs'),path=require('path'),os=require('os');
const A=require('../electron/profile-activity'),C=require('../electron/continue-watching');
const root=fs.mkdtempSync(path.join(os.tmpdir(),'bm-profile-activity-'));
try{
 const store=A.create(path.join(root,'activity')),resume=C.create(path.join(root,'resume')),scope='account:19';
 const movie={archive:1,type:'movie',id:'a',title:'Example',genres:['Action',{name_fa:'درام'},'اکشن'],poster:'https://example.org/p.jpg',backdrop:'https://example.org/bg.jpg'};
 const source={url:'https://example.org/media?token=SECRET',quality:'1080p'};
 const a=store.begin(scope,movie,source);fs.writeFileSync(path.join(a,'b'),'1 120 800 1000 0');
 fs.writeFileSync(path.join(a,'a'),'2 130 900 1000 0');fs.writeFileSync(path.join(a,'b'),'3 131 90');
 assert.equal(store.snapshot(scope).seconds,130,'torn checkpoint keeps last complete sample');
 const b=store.begin(scope,movie,source);fs.writeFileSync(path.join(b,'b'),'1 20 1000 1000 1');
 const series={...movie,id:'b',type:'series',genres:'comedy, drama'};const c=store.begin(scope,series,{...source,season:2,episode:3});fs.writeFileSync(path.join(c,'b'),'1 50 100 500 0');
 const guest=store.begin('guest',movie,source);fs.writeFileSync(path.join(guest,'b'),'1 99 100 500 0');
 const result=A.create(path.join(root,'activity')).snapshot(scope);assert.equal(result.seconds,200);assert.equal(result.movies,1);assert.equal(result.series,1);assert.equal(result.history.length,2);assert.equal(result.history.find(x=>x.id==='b').episode,3);assert.ok(Math.abs(result.genres.reduce((n,g)=>n+g.percent,0)-100)<.001);assert.equal(result.genres[0].name,'درام');
 assert.equal(store.snapshot('account:20').seconds,0);assert.equal(store.snapshot('guest').seconds,99);assert.equal(store.snapshot(null).seconds,0);
 assert.ok(!fs.readFileSync(path.join(a,'meta.json'),'utf8').includes('SECRET'));assert.ok(!fs.readFileSync(path.join(a,'meta.json'),'utf8').includes('/media'));
 const r=resume.begin(scope,movie,source);fs.writeFileSync(path.join(r,'b'),'1 100 500 0');assert.equal(resume.remove(scope,C.identity(movie).key),true);assert.equal(store.snapshot(scope).seconds,200,'removing resume does not erase history');
 assert.equal(store.setCover(scope,C.identity(movie).key),true);assert.equal(store.snapshot(scope).cover,C.identity(movie).key);assert.equal(store.setCover('account:20',C.identity(movie).key),false);assert.equal(store.setCover(scope,'../../escape'),false);assert.equal(store.setCover(scope,''),true);
 console.log('PASS activity: elapsed time, completion, distinct titles, genres, persistence, isolation, no stream URL, separate resume and safe cover');
}finally{fs.rmSync(root,{recursive:true,force:true});}
