local f=assert(io.open('player/cinema.lua','r'));local code=f:read('*a');f:close()
local snippet=assert(code:match("(local activityDir=os.getenv%('BM_PROFILE_DIR'%)[%s%S]-)\n%-%- Local continue%-watching journal"))
local props={['time-pos']=100,duration=1800,speed=1,pause=false,['paused-for-cache']=false,seeking=false};local t=0;local events,obs,timers,writes={},{},{},{}
local mp={get_time=function()return t end,get_property_number=function(k,default)return props[k] or default end,get_property_bool=function(k,default)if props[k]==nil then return default end;return props[k]end,register_event=function(k,fn)events[k]=fn end,observe_property=function(k,_,fn)obs[k]=fn end,add_periodic_timer=function(k,fn)timers[k]=fn end}
local env=setmetatable({mp=mp,os={getenv=function()return 'activity' end},io={open=function(path)return {write=function(_,value)writes[#writes+1]=value end,close=function()end}end}},{__index=_G});assert(load(snippet,'activity','t',env))()
local function step(time,pos)t=time;props['time-pos']=pos;timers[1]()end
local function last()local a,b,c,d,e=writes[#writes]:match('(%d+) ([%d%.]+) ([%d%.]+) ([%d%.]+) (%d)');return tonumber(b),tonumber(c),tonumber(e)end
assert(#writes==0);events['playback-restart']();step(1,101);assert(last()==1);step(2,102);assert(last()==2)
props.pause=true;obs.pause();step(3,102);step(4,102);assert(last()==2)
props.pause=false;obs.pause();step(5,103);assert(last()==3)
props['paused-for-cache']=true;obs['paused-for-cache']();step(6,103);step(7,103);assert(last()==3)
props['paused-for-cache']=false;obs['paused-for-cache']();events.seek();props['time-pos']=500;events['playback-restart']();step(8,501);assert(last()==4)
step(9,900);assert(last()==4,'jump not counted');step(10,901);assert(last()==5)
obs['eof-reached']('eof-reached',true);local n,p,done=last();assert(n==5 and p==1800 and done==1)
step(11,1799);n,p,done=last();assert(n==5 and p==1800 and done==1)
print('PASS local activity Lua: wall time, pause, buffering, seek, EOF, no artificial seconds')
