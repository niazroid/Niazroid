'use strict';
// Standalone source-level behavior smoke checks. No Electron install or server needed.
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const vm = require('node:vm');
const { pathToFileURL } = require('node:url');
const crypto = require('node:crypto');
const {publicKey:testPublicKey, privateKey:testPrivateKey} = crypto.generateKeyPairSync('rsa', { modulusLength:2048, publicKeyEncoding:{type:'spki',format:'pem'}, privateKeyEncoding:{type:'pkcs8',format:'pem'} });

const root = path.resolve(__dirname, '..');
const source = fs.readFileSync(path.join(root, 'electron/main.js'),'utf8');
const work = fs.mkdtempSync(path.join(os.tmpdir(), 'bm-v146-smoke-'));
let encrypted = false, minimized=0, commands=0;
const handlers = new Map(), events = new Map();
const mockApp = {
  setName(){}, setAppUserModelId(){},
  getVersion(){ return '1.1.46'; },
  getPath(which){ return which === 'userData' ? work : work; },
  whenReady(){ return new Promise(()=>{}); }, // prevent Electron window creation
  on(){}, isReady(){return true;}
};
const mockElectron = {
  app:mockApp, BrowserWindow:function(){},
  ipcMain:{handle:(k,fn)=>handlers.set(k,fn),on:(k,fn)=>events.set(k,fn)},
  dialog:{},shell:{},session:{},Notification:{},protocol:{registerSchemesAsPrivileged(){}},
  safeStorage:{
    isEncryptionAvailable:()=>encrypted,
    encryptString:s=>Buffer.from('mock:'+s),
    decryptString:buf=>buf.toString().slice(5)
  }
};
const clonedProcess = {platform:process.platform,env:{...process.env},pid:process.pid};
const realChild = require('node:child_process');
const requireMock=(name)=>{
  if(name==='electron') return mockElectron;
  if(name==='./runtime.generated') return {...require(path.join(root,'electron/runtime.generated.js')), configPublicKey:testPublicKey};
  if(name==='./discover-protocol')return require(path.join(root,'electron/discover-protocol.js'));
  if(name==='./content-failover')return require(path.join(root,'electron/content-failover.js'));
  if(name==='child_process') return {...realChild,execFileSync(){commands++;return '';}};
  return require(name);
};
const ctx=vm.createContext({
  require:requireMock, __dirname:path.join(root,'electron'),__filename:path.join(root,'electron/main.js'),
  module:{exports:{}},exports:{},process:clonedProcess,Buffer,URL,URLSearchParams,AbortController,
  setTimeout,clearTimeout,setInterval,clearInterval,console,fetch:()=>{throw new Error('Network must not be used by smoke tests');}
});
try {
  vm.runInContext(source,ctx,{filename:'electron/main.js',timeout:5000});
  assert.equal(handlers.size,34,'all privileged handle IPC channels registered');
  assert.equal(events.size,3,'all one-way window IPC channels registered');
  const index=pathToFileURL(path.join(root,'src/index.html')).href;
  const web={id:9,isDestroyed:()=>false,getURL:()=>index,mainFrame:{processId:33,routingId:44}};
  ctx.__testWindow={isDestroyed:()=>false,webContents:web,minimize:()=>{minimized++;}};
  vm.runInContext('win = __testWindow',ctx);
  const valid={sender:web,senderFrame:{processId:33,routingId:44,url:index}};
  const wrongFrame={sender:web,senderFrame:{processId:33,routingId:45,url:index}};
  const wrongFile={sender:web,senderFrame:{processId:33,routingId:44,url:'file:///tmp/evil.html'}};
  const wrongWin={sender:{...web,id:10},senderFrame:{processId:33,routingId:44,url:index}};
  async function rejectsAll(event){
    for(const [channel,fn] of handlers){
      await assert.rejects(async()=>fn(event),/نامعتبر/,`blocked IPC ${channel}`);
    }
  }
  (async()=>{
    await rejectsAll(wrongFrame);
    await rejectsAll(wrongFile);
    await rejectsAll(wrongWin);
    assert.ok(!handlers.has('bm-party-panel:state'),'separate chat IPC removed');
    assert.ok(!handlers.has('bm-party-panel:action'),'separate chat IPC removed');
    const settings=await handlers.get('settings:get')(valid);
    assert.ok(settings && typeof settings==='object','valid main-frame IPC allowed');
    events.get('window:minimize')(wrongFrame);
    assert.equal(minimized,0,'subframe send ignored');
    events.get('window:minimize')(valid);
    assert.equal(minimized,1,'trusted main frame send accepted');

    // With OS storage unavailable, token must NOT appear in desktop-state.json.
    vm.runInContext("saveToken('smoke-secret-123')",ctx);
    let state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authToken,'','no plaintext disk token');
    assert.equal(vm.runInContext('loadToken()',ctx),'smoke-secret-123','session continues in RAM');
    vm.runInContext("saveToken('')",ctx);
    assert.equal(vm.runInContext('loadToken()',ctx),'','logout clears RAM token');

    encrypted=true;
    vm.runInContext("saveToken('safe-storage-token')",ctx);
    state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authEncrypted,true,'encrypted account token marked');
    assert.equal(vm.runInContext('loadToken()',ctx),'safe-storage-token','OS-protected token roundtrip');
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({authEncrypted:false,authToken:'old-plaintext-token'}));
    assert.equal(vm.runInContext('loadToken()',ctx),'old-plaintext-token','legacy token loads');
    state=JSON.parse(fs.readFileSync(path.join(work,'desktop-state.json'),'utf8'));
    assert.equal(state.authEncrypted,true,'legacy plaintext automatically migrated');
    assert.notEqual(state.authToken,'old-plaintext-token','legacy secret no longer plaintext');

    // Simulate old history and a new app process after an in-place upgrade.
    const history=require(path.join(root,'electron/continue-watching.js'));
    const existing=history.create(path.join(work,'continue-watching-v1'));
    const movie={id:'old-film',archive:1,type:'movie',title:'Old film'};
    const journal=existing.begin('account:19',movie,{url:'https://example.com/old.mp4',quality:'1080p'});
    fs.writeFileSync(path.join(journal,'a'),'1 426.375 1200 0\n');
    vm.runInContext("bmContinueBindAccount({success:true,user:{id:19}},loadToken())",ctx);
    assert.equal(vm.runInContext('bmContinueScope()',ctx),'account:19');
    // First launch after updating from the old format: no saved binding yet.
    vm.runInContext(`writeState({continueAccount:null});bmContinueUser=null;bmContinueTokenHash=null;
      var previousUserRequest=userRequest;userRequest=async()=>{const data={success:true,user:{id:19}};bmContinueBindAccount(data,loadToken());return data;};`,ctx);
    assert.equal((await handlers.get('continue:list')(valid))[0].position,426.375,'old history loaded without playing another film');
    vm.runInContext('userRequest=previousUserRequest',ctx);
    // New process: no in-memory account, no new film, no network response required.
    vm.runInContext('bmContinueUser=null;bmContinueTokenHash=null;',ctx);
    const restored=await handlers.get('continue:list')(valid);
    assert.equal(restored.length,1);assert.equal(restored[0].position,426.375);
    assert.equal(restored[0].key,history.identity(movie).key);
    vm.runInContext("saveToken('different-account-token');bmContinueBindAccount({success:true,user:{id:20}},loadToken())",ctx);
    assert.equal((await handlers.get('continue:list')(valid)).length,0,'new account cannot inherit old history');
    vm.runInContext("saveToken('');",ctx);
    assert.equal((await handlers.get('continue:list')(valid)).length,0,'logout does not expose account history');
    vm.runInContext("saveToken('old-plaintext-token');bmContinueBindAccount({success:true,user:{id:19}},loadToken())",ctx);
    assert.equal((await handlers.get('continue:list')(valid))[0].position,426.375,'same account recovers older history after login');
    assert.ok(!fs.readFileSync(path.join(work,'desktop-state.json'),'utf8').includes('old-plaintext-token'));

    // Offline config must be reconstructed from a *signed* envelope; an
    // unsigned or altered cache can never earn a _verified flag.
    const cfg={content_domain:'https://bankmovie.top',api_base_url:'https://bankmovie.top/v1',features:{weekly_schedule_enabled:true}};
    const payload=Buffer.from(JSON.stringify(cfg));
    const envelope={schema:'bm-win-config-envelope-v1',alg:'RS256',payload:payload.toString('base64url'),signature:crypto.sign('RSA-SHA256',payload,testPrivateKey).toString('base64url')};
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({bmVerifiedRemoteConfigEnvelope:envelope,bmVerifiedRemoteConfigAt:Date.now()}));
    const offline=await vm.runInContext('loadRemoteConfig(true)',ctx);
    assert.equal(offline._verified,true,'offline signed config verified');
    assert.equal(offline.features.weekly_schedule_enabled,true,'offline features preserved');
    envelope.payload=Buffer.from(JSON.stringify({...cfg,features:{weekly_schedule_enabled:false}})).toString('base64url');
    fs.writeFileSync(path.join(work,'desktop-state.json'),JSON.stringify({bmVerifiedRemoteConfigEnvelope:envelope,bmVerifiedRemoteConfigAt:Date.now()}));
    const tampered=await vm.runInContext('loadRemoteConfig(true)',ctx);
    assert.equal(tampered._verified,false,'tampered offline config rejected');

    // Lightweight performance guard: registry/where discovery must be cached.
    clonedProcess.platform='win32';
    vm.runInContext('detectPlayers()',ctx);
    const firstCalls=commands;
    assert.ok(firstCalls>0,'initial player discovery ran');
    vm.runInContext('detectPlayers()',ctx);
    assert.equal(commands,firstCalls,'second discovery used cache');


    // Failover only to controller-signed HTTPS mirrors. Reject fraudulent origins.
    const fo=require(path.join(root,'electron/content-failover.js'));
    assert.equal(fo.normalHost('http://bad.example.com'),'');
    assert.equal(fo.normalHost('https://localhost'),'');
    assert.equal(fo.normalHost('https://example.com:8443'),'');
    assert.equal(fo.normalHost('https://bankmoviez.top'),'https://bankmoviez.top');
    assert.deepEqual(fo.sources('https://bankmovie.top',['https://bankmoviez.top','https://bankmoviez.top']),['https://bankmovie.top','https://bankmoviez.top']);
    assert.equal(fo.replaceOrigin('https://bankmovie.top/v1/desktop_api.php?action=boot','https://bankmoviez.top'),'https://bankmoviez.top/v1/desktop_api.php?action=boot');
    assert.throws(()=>fo.replaceOrigin('https://bankmovie.top/admin.php','https://bankmoviez.top'));
    const signedCfg={...cfg,content_sources:['https://bankmoviez.top']};
    const signedBytes=Buffer.from(JSON.stringify(signedCfg));
    const signedEnvelope={schema:'bm-win-config-envelope-v1',alg:'RS256',payload:signedBytes.toString('base64url'),signature:crypto.sign('RSA-SHA256',signedBytes,testPrivateKey).toString('base64url')};
    const verified=vm.runInContext('bmVerifyControllerEnvelope(__signedEnvelope)',Object.assign(ctx,{__signedEnvelope:signedEnvelope}));
    assert.equal(verified.content_sources[0],'https://bankmoviez.top');
    const evilCfg={...cfg,content_sources:['http://127.0.0.1']};
    const evilBytes=Buffer.from(JSON.stringify(evilCfg));
    const evilEnvelope={schema:'bm-win-config-envelope-v1',alg:'RS256',payload:evilBytes.toString('base64url'),signature:crypto.sign('RSA-SHA256',evilBytes,testPrivateKey).toString('base64url')};
    ctx.__signedEnvelope=evilEnvelope;
    assert.throws(()=>vm.runInContext('bmVerifyControllerEnvelope(__signedEnvelope)',ctx),/دامنه/);

    // The real signer binds method, exact route, body, nonce and access token ID.
    const identity=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
    ctx.__identity={privateKey:identity.privateKey,publicKey:identity.publicKey,deviceId:'test-device'};
    vm.runInContext('bmDeviceIdentity=()=>__identity;bmEnsureDeviceAccess=async()=>({token:"test-jwt",jti:"test-jti"});',ctx);
    const reqBody=JSON.stringify({action:'watch_party_status'});
    ctx.__reqBody=reqBody;
    const h=await vm.runInContext('windowsV1AuthHeaders("https://bankmovie.top/v1/desktop_user_api.php",{method:"POST",body:__reqBody})',ctx);
    const canon=['BM-WIN-DPOP-1','POST','/v1/desktop_user_api.php',h['X-BM-DPoP-Ts'],h['X-BM-DPoP-Nonce'],crypto.createHash('sha256').update(reqBody).digest('hex'),'test-jti'].join('\n');
    assert.equal(crypto.verify('sha256',Buffer.from(canon),identity.publicKey,Buffer.from(h['X-BM-DPoP'],'base64url')),true);
    assert.equal(crypto.verify('sha256',Buffer.from(canon.replace('POST','GET')),identity.publicKey,Buffer.from(h['X-BM-DPoP'],'base64url')),false);
    for(const url of ['https://bankmovie.top/app_user_api.php','http://bankmovie.top/v1/desktop_user_api.php','https://evil.example/v1/desktop_user_api.php','https://user@bankmovie.top/v1/desktop_user_api.php']){
      ctx.__badUrl=url;
      await assert.rejects(()=>vm.runInContext('windowsV1AuthHeaders(__badUrl)',ctx),/امضاشده/);
    }

    // Mock a failed TLS connection; the fallback must remain HTTPS and only
    // use hosts from the signed list. Never bypass a 401 authorization error.
    vm.runInContext('runtimeConfig={_verified:true,content_sources:["https://bankmoviez.top"]};windowsV1AuthHeaders=async()=>({});',ctx);
    let seen=[];
    ctx.fetch=async(url)=>{
      seen.push(String(url));
      if(String(url).startsWith('https://bankmovie.top'))throw new TypeError('certificate verify failed');
      return {ok:true,status:200,text:async()=>JSON.stringify({success:true,mirror:true})};
    };
    let response=await vm.runInContext('fetchJson("https://bankmovie.top/v1/desktop_api.php?action=boot")',ctx);
    assert.equal(response.mirror,true,'SSL failure switches to signed HTTPS mirror');
    assert.deepEqual(seen.map(u=>new URL(u).host),['bankmovie.top','bankmoviez.top']);
    seen=[];vm.runInContext('bmContentBadUntil[DEFAULT.domain]=0;bmContentBadUntil["https://bankmoviez.top"]=0;',ctx);
    ctx.fetch=async(url)=>{seen.push(String(url));return {ok:false,status:403,text:async()=>JSON.stringify({success:false,message:'Not allowed'})};};
    await assert.rejects(()=>vm.runInContext('fetchJson("https://bankmovie.top/v1/desktop_api.php?action=boot")',ctx),/Not allowed/);
    assert.equal(seen.length,1,'403 does not fall through to another server');
    ctx.fetch=()=>{throw new Error('Network must not be used by smoke tests')};

    // Critical API calls must not follow redirects with bearer/DPoP headers.
    assert.match(source,/await fetch\(url, \{ \.\.\.options, redirect:'error', signal:ctrl\.signal/);
    assert.match(source,/bmVerifyControllerEnvelope\(state\.bmVerifiedRemoteConfigEnvelope\)/);
    assert.match(source,/remoteSession\.on\('will-download', event=>event\.preventDefault\(\)\)/);
    console.log(`PASS: ${handlers.size} invoke channels + ${events.size} event channels guarded; account tokens, signed config & player cache checks passed.`);
  })().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>fs.rmSync(work,{recursive:true,force:true}));
} catch(e) { fs.rmSync(work,{recursive:true,force:true}); throw e; }
