#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
auth='app/src/main/java/ir/bankmoviee/app/AuthActivity.kt'
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'
draw='app/src/main/res/drawable'

bash verify_v7431_section_hard_hide.sh

grep -Fq 'sourceMainUpdateTwentyEighthHotfixTag=BANKMOVIE-2.3-V744-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt

test -s "$draw/ic_repo_close.xml"
test -s "$draw/ic_repo_confirm.xml"
test -s "$draw/ic_repo_language.xml"
test -s "$draw/ic_player_volume_uiverse.xml"

grep -Fq 'setImageResource(R.drawable.ic_repo_close)' "$main"
grep -Fq 'setImageResource(R.drawable.ic_repo_confirm)' "$main"
grep -Fq 'downloadBoxPlayerUrl' "$main"
grep -Fq 'bypassArchivePlaybackGates = true' "$main"
grep -Fq '!bypassArchivePlaybackGates && archiveVipGateRequired(item, "stream")' "$main"
grep -Fq 'val internalPlayerLocked = !bypassArchivePlaybackGates' "$main"
grep -Fq 'val externalPlayersLocked = !bypassArchivePlaybackGates' "$main"

grep -Fq 'V7.44 auth motion fix' "$auth"
grep -Fq 'wireDraggableAuthCard(card, dragHandle)' "$auth"
grep -Fq 'card.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f).setDuration(180L)' "$auth"

grep -Fq 'setImageResource(R.drawable.ic_repo_language)' "$player"
grep -Fq 'setImageResource(R.drawable.ic_player_volume_uiverse)' "$player"
grep -Fq 'private fun showVolumeGestureHud(volume: Int, maxVolume: Int)' "$player"
grep -Fq 'showVolumeGestureHud(vol, maxVol)' "$player"

python3 - <<'PY'
import xml.etree.ElementTree as ET
for p in [
    'app/src/main/res/drawable/ic_repo_close.xml',
    'app/src/main/res/drawable/ic_repo_confirm.xml',
    'app/src/main/res/drawable/ic_repo_language.xml',
    'app/src/main/res/drawable/ic_player_volume_uiverse.xml',
]:
    ET.parse(p)
print('V744_VECTOR_XML_OK')
PY

echo V744_VIP_AUTH_PLAYER_POLISH_VERIFY_OK
