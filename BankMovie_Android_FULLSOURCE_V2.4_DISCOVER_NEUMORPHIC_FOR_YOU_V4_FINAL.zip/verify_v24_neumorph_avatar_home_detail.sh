#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
for name in ['bm_home_updated_movies','bm_home_updated_series','bm_home_anime_art','bm_home_turkey']:
 assert Path('app/src/main/res/drawable-nodpi/'+name+'.webp').stat().st_size>100
 assert Path('app/src/main/assets/site-home-art/'+name+'.svg').stat().st_size>100
 assert 'R.drawable.'+name in s
assert 'configuredAvatar' in s and 'profileAvatarView' in s and 'navVip' in s
assert 'legacyTvSectionHeader' in s and 'if (isTvLike()) return legacyTvSectionHeader' in s
assert 'forcePosterHero' in s and 'bottomMargin = dp(139)' in s
assert 'background = neumorphicSurface(18)' in s
assert 'marginEnd = dp(12)' in s
assert 'clipToOutline = true' in s
assert 'android.webkit.WebView(this)' not in s[s.index('private fun showDiscover()'):s.index('private fun showCategories()',s.index('private fun showDiscover()'))]
assert 'versionName "2.4"' in Path('app/build.gradle').read_text()
assert "applicationId 'ir.bankmoviee.app'" in Path('app/build.gradle').read_text()
d=s[s.index('val playOrb = FrameLayout(this).apply'):]
assert d.index('hero.addView(heroPosterShell') < d.index('hero.addView(playOrb'), 'poster must be below play overlay'
print('VERIFY_V24_NEUMORPH_AVATAR_HOME_DETAIL_OK')
PY
