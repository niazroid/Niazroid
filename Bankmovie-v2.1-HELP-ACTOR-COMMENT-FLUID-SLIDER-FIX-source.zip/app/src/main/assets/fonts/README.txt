Font assets are injected by the GitHub Actions workflow from files stored at the repository root:
- irancell [@fontbazi].zip
- Cinema(1).otf
- Diako Hima Regular-@Fontsplua(1).ttf
- Nic [@fontbazi].ttf

Expected generated asset names:
- irancell_regular.ttf
- irancell_medium.ttf
- irancell_semibold.ttf
- irancell_bold.ttf
- irancell_black.ttf
- cinema.otf
- diako_hima.ttf
- nic.ttf
