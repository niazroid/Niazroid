package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.graphics.drawable.AnimatedImageDrawable
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.GridLayout
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.util.UUID
import org.webrtc.AudioSource
import org.webrtc.AudioTrack
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import org.webrtc.audio.JavaAudioDeviceModule
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.MediaInfo
import com.google.android.gms.cast.MediaMetadata
import com.google.android.gms.cast.framework.CastButtonFactory
import com.google.android.gms.cast.framework.CastContext
import com.google.android.gms.cast.framework.CastSession
import com.google.android.gms.cast.framework.SessionManagerListener
import com.google.android.gms.cast.framework.media.RemoteMediaClient
import com.google.android.gms.cast.MediaLoadRequestData
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PLAYLIST_FILE = "playlist_file"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RESUME_POSITION = "resume_position"
        const val EXTRA_WATCH_PARTY_ROOM_CODE = "watch_party_room_code"
        const val EXTRA_WATCH_PARTY_ROLE = "watch_party_role"
        const val EXTRA_WATCH_PARTY_INVITE_URL = "watch_party_invite_url"
        private const val REQ_WATCH_PARTY_AUDIO = 7401
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue: Int get() = UiPreferences.accentColor(this)
    private val blue2: Int get() = UiPreferences.blend(blue, Color.WHITE, 0.28f)
    private val blue3: Int get() = Color.argb(170, Color.red(blue), Color.green(blue), Color.blue(blue))
    private val panel = Color.argb(230, 12, 12, 14)
    private val stroke = Color.argb(115, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 192, 202)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private var requestedResumePosition = 0L
    private var resumeTarget = 0L
    private var resumeGuardUntil = 0L
    private var seekJumpMs = 10000L
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchStartBrightness = 0.5f
    private var touchStartVolume = 0
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var nextPromptShownKey = ""
    private var skipNextOnce = false
    private var nextPromptDialog: AlertDialog? = null
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var playbackRetryCount = 0
    private var bufferingStartedAt = 0L
    private var recentLongBufferCount = 0
    private var decoderAutoFallbackUsed = false
    private var lifecycleRestorePending = false
    private var lifecycleWasPlaying = false
    private var lifecyclePosition = 0L
    private var lifecyclePausedAt = 0L
    private var pauseAfterLifecycleRestore = false
    private var subtitleDelayMs = 0
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackgroundMode = "black"
    private var subtitleFontMode = "system"
    private var subtitleBold = true
    private var lastEnabledSpuTrack = 0
    private var preferredAudioTrackId = Int.MIN_VALUE
    private var preferredSubtitleTrackId = Int.MIN_VALUE
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }


    // PASS 4 — Native Watch Party state. The app talks to the exact same tables
    // used by the website through app_user_api.php, so web and Android can share a room.
    private var partyRoomCode = ""
    private var partyRole = ""
    private var partyInviteUrl = ""
    private var partyIsHost = false
    private var partyActive = false
    private var partyApplyingRemote = false
    private var partyLastEventId = 0L
    private var partyLastMessageId = 0L
    private var partyLastVoiceSignalId = 0L
    private var partyLastSequence = -1L
    private var partyServerOffsetMs = 0L
    private var partyLastPollAt = 0L
    private var partyLastHeartbeatAt = 0L
    private var partyLastHostActionAt = 0L
    private var partyMembers = JSONArray()
    private var partyThemeKey = "simple"
    private var partyRoomTitle = ""
    private var partyRoomPoster = ""
    private var partyChatEnabled = true
    private var partyVoiceEnabled = false
    private var partyVoicePeerAvailable = false
    private var partyPollInFlight = false
    private var partyDock: LinearLayout? = null
    private var partyStatusChip: TextView? = null
    private var partyChatScroll: ScrollView? = null
    private var partyChatList: LinearLayout? = null
    private var partyChatDialog: AlertDialog? = null
    private val partyMessageIdsShown = linkedSetOf<Long>()
    private var partyUnreadChat = 0
    private var partyChatButton: View? = null

    private val partyPollRunnable = object : Runnable {
        override fun run() {
            if (partyActive && !isFinishing && !isDestroyed) {
                pollWatchParty()
                if (partyIsHost) sendWatchPartyHeartbeatIfNeeded()
                handler.postDelayed(this, 850L)
            }
        }
    }

    // Voice Call / WebRTC. PHP/MySQL carry signaling only; audio stays peer-to-peer.
    private var rtcFactory: PeerConnectionFactory? = null
    private var rtcAudioSource: AudioSource? = null
    private var rtcAudioTrack: AudioTrack? = null
    private var rtcPeer: PeerConnection? = null
    private var rtcAudioDevice: JavaAudioDeviceModule? = null
    private var voiceCallToken = ""
    private var voiceCallStatus = ""
    private var voiceIsCaller = false
    private var voiceMuted = false
    private var pendingVoiceStartAfterPermission = false
    private var pendingVoiceAcceptAfterPermission = false
    private val pendingRemoteIce = mutableListOf<IceCandidate>()
    private var pendingRemoteOfferSdp = ""
    private var incomingVoiceDialog: AlertDialog? = null
    private var voiceStatusDialog: AlertDialog? = null
    private var lastIncomingVoiceToken = ""

    private var castContext: CastContext? = null
    private var castResumePosition = 0L
    private var castLoadedUrl = ""
    private val castSessionListener = object : SessionManagerListener<CastSession> {
        override fun onSessionStarting(session: CastSession) {}
        override fun onSessionStarted(session: CastSession, sessionId: String) {
            castCurrentMedia(session, player?.time?.coerceAtLeast(0L) ?: requestedResumePosition)
        }
        override fun onSessionStartFailed(session: CastSession, error: Int) {
            Toast.makeText(this@PlayerActivity, "اتصال Cast برقرار نشد", Toast.LENGTH_SHORT).show()
        }
        override fun onSessionSuspended(session: CastSession, reason: Int) {}
        override fun onSessionResuming(session: CastSession, sessionId: String) {}
        override fun onSessionResumed(session: CastSession, wasSuspended: Boolean) {
            val remote = session.remoteMediaClient
            val remoteId = remote?.mediaInfo?.contentId.orEmpty()
            if (remoteId.isBlank() || remoteId != videoUrl) {
                castCurrentMedia(session, player?.time?.coerceAtLeast(0L) ?: requestedResumePosition)
            } else {
                runCatching { player?.pause() }
                showHud("پخش روی Cast ادامه دارد")
            }
        }
        override fun onSessionResumeFailed(session: CastSession, error: Int) {}
        override fun onSessionEnding(session: CastSession) {
            castResumePosition = session.remoteMediaClient?.approximateStreamPosition?.coerceAtLeast(0L) ?: 0L
        }
        override fun onSessionEnded(session: CastSession, error: Int) {
            castLoadedUrl = ""
            if (castResumePosition > 0L && videoUrl.isNotBlank() && !isFinishing) {
                requestedResumePosition = castResumePosition
                castResumePosition = 0L
                handler.postDelayed({ launchPlayerSafely(videoUrl) }, 140L)
            }
        }
    }

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        try {
            parseIncoming()
            loadUiPreferences()
            if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
            if (currentIndex !in tracks.indices) currentIndex = 0
            videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
            title = tracks.getOrNull(currentIndex)?.title ?: title
            progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
            if (videoUrl.isBlank()) throw IllegalArgumentException("Empty playback URL")
            currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
            initCastFramework()
            buildUi()
            if (partyRoomCode.isNotBlank()) {
                partyActive = true
                partyIsHost = partyRole.equals("host", true)
                buildWatchPartyOverlay()
                handler.removeCallbacks(partyPollRunnable)
                handler.postDelayed(partyPollRunnable, 350L)
            }
            switchTo(currentIndex)
        } catch (_: Throwable) {
            Toast.makeText(this, "این نسخه پخش معتبر نیست؛ نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private var currentBrightness = 0.55f

    private fun loadUiPreferences() {
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackgroundMode = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleDelayMs = UiPreferences.subtitleDelayMs(this)
        subtitleFontMode = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePositionIndex = UiPreferences.subtitlePosition(this)
        seekJumpMs = UiPreferences.seekSeconds(this).toLong() * 1000L
        autoPlayNext = UiPreferences.autoNext(this)
    }

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        requestedResumePosition = intent.getLongExtra(EXTRA_RESUME_POSITION, 0L).coerceAtLeast(0L)
        partyRoomCode = intent.getStringExtra(EXTRA_WATCH_PARTY_ROOM_CODE).orEmpty().trim()
        partyRole = intent.getStringExtra(EXTRA_WATCH_PARTY_ROLE).orEmpty().trim()
        partyInviteUrl = intent.getStringExtra(EXTRA_WATCH_PARTY_INVITE_URL).orEmpty().trim()
        val payloadFile = intent.getStringExtra(EXTRA_PLAYLIST_FILE).orEmpty()
        val json = if (payloadFile.isNotBlank()) {
            runCatching {
                File(payloadFile).takeIf { it.isFile && it.length() in 1..2_500_000L }?.readText(Charsets.UTF_8).orEmpty()
            }.getOrDefault("").ifBlank { intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty() }
        } else {
            intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty()
        }
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until min(arr.length(), 160)) {
                    val it = arr.optJSONObject(i) ?: continue
                    if (it.optString("url").isBlank()) continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, Color.red(blue), Color.green(blue), Color.blue(blue)))
            setStroke(dp(2), Color.argb(205, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), blue2)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            v.foreground = if (has) playerFocusDrawable(radiusDp) else originalForeground
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.translationZ = if (has) dp(8).toFloat() else 0f
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(if (has) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun focusPlayButton() {
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                if (v is android.view.ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                }
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 55)
    }

    private fun initCastFramework() {
        try {
            castContext = CastContext.getSharedInstance(this)
            castContext?.sessionManager?.addSessionManagerListener(castSessionListener, CastSession::class.java)
        } catch (_: Throwable) {
            castContext = null
        }
    }

    private fun ccAudioSubtitleButton(click: () -> Unit): View {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            isClickable = true
            isFocusable = true
            contentDescription = "صدا و زیرنویس"
            applyPlayerFocus(this, 20, 1.08f, 0f)
            setOnClickListener { click() }
            addView(TextView(this@PlayerActivity).apply {
                text = "CC"
                setTextColor(Color.BLACK)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                includeFontPadding = false
                letterSpacing = -0.03f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    setColor(Color.WHITE)
                    cornerRadius = dp(3).toFloat()
                }
            }, FrameLayout.LayoutParams(dp(29), dp(21), Gravity.CENTER))
        }
    }

    private fun createCastRouteButton(): View {
        return try {
            MediaRouteButton(this).apply {
                setBackgroundColor(Color.TRANSPARENT)
                contentDescription = "Cast"
                CastButtonFactory.setUpMediaRouteButton(applicationContext, this)
                applyPlayerFocus(this, 20, 1.08f, 0f)
            }
        } catch (_: Throwable) {
            simplePlayerIcon(R.drawable.ic_player_cast_fallback) {
                Toast.makeText(this, "Google Cast روی این دستگاه در دسترس نیست", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun castContentType(url: String): String {
        val clean = url.substringBefore('?').lowercase(Locale.US)
        return when {
            clean.endsWith(".m3u8") -> "application/x-mpegURL"
            clean.endsWith(".mpd") -> "application/dash+xml"
            clean.endsWith(".webm") -> "video/webm"
            clean.endsWith(".mkv") -> "video/x-matroska"
            clean.endsWith(".ts") -> "video/mp2t"
            else -> "video/mp4"
        }
    }

    private fun currentCastSession(): CastSession? = try { castContext?.sessionManager?.currentCastSession } catch (_: Throwable) { null }

    private fun currentRemoteClient(): RemoteMediaClient? = currentCastSession()?.remoteMediaClient

    private fun castCurrentMedia(session: CastSession, positionMs: Long) {
        val url = videoUrl.trim()
        if (url.isBlank()) return
        val remote = session.remoteMediaClient ?: return
        val metadata = MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE).apply {
            putString(MediaMetadata.KEY_TITLE, title.ifBlank { "Bankmovie" })
            currentLabel().takeIf { it.isNotBlank() }?.let { putString(MediaMetadata.KEY_SUBTITLE, it) }
        }
        val mediaInfo = MediaInfo.Builder(url)
            .setStreamType(MediaInfo.STREAM_TYPE_BUFFERED)
            .setContentType(castContentType(url))
            .setMetadata(metadata)
            .build()
        remote.load(
            MediaLoadRequestData.Builder()
                .setMediaInfo(mediaInfo)
                .setAutoplay(true)
                .setCurrentTime(positionMs.coerceAtLeast(0L))
                .build()
        )
        castLoadedUrl = url
        castResumePosition = positionMs.coerceAtLeast(0L)
        runCatching { player?.pause() }
        showHud("پخش مستقیم روی Cast")
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = VLCVideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(58, 0, 0, 0), Color.TRANSPARENT)
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { if (partyActive) showPartyRoomSheet() else finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(50), dp(50)))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        subText = TextView(this).apply {
            text = currentLabel()
            setTextColor(muted)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        info.addView(titleText)
        info.addView(subText)
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        actions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(58), dp(48)).apply { marginStart = dp(3) })
        actions.addView(ccAudioSubtitleButton { showAudioSubtitleSettingsSheet() }, LinearLayout.LayoutParams(dp(50), dp(48)).apply { marginStart = dp(3) })
        actions.addView(createCastRouteButton(), LinearLayout.LayoutParams(dp(50), dp(48)).apply { marginStart = dp(1) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_pip) { enterPipMode() }, LinearLayout.LayoutParams(dp(50), dp(48)))
        topBar.addView(actions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(74), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        val jumpLabel = (seekJumpMs / 1000L).toString()
        val rewind = circleAction(R.drawable.ic_player_replay, jumpLabel) { seekBy(-seekJumpMs) }.apply { id = View.generateViewId() }
        val play = FrameLayout(this).apply {
            id = View.generateViewId()
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, jumpLabel) { seekBy(seekJumpMs) }.apply { id = View.generateViewId() }
        rewind.nextFocusRightId = play.id
        play.nextFocusLeftId = rewind.id
        play.nextFocusRightId = forward.id
        forward.nextFocusLeftId = play.id
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginEnd = dp(22) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(82), dp(82)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(70), dp(70)).apply { marginStart = dp(22) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(104), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(4), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(225, 0, 0, 0))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        val bottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            // Utility controls live on the opposite/right edge, away from the
            // timeline start and closer to the top-right playback tools.
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        val settingsButton = glassIconButton(R.drawable.ic_player_settings) { showSettingsSheet() }
        bottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(58), dp(32)).apply { marginEnd = dp(8) })
        bottomActions.addView(settingsButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        bottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(48), dp(48)).apply { marginEnd = dp(6) })
        bottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(48), dp(48)))
        bottomBar.addView(bottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(4); gravity = Gravity.RIGHT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(116), Gravity.BOTTOM))

        // Use the same state transition as the normal lock button. The previous
        // direct boolean assignment left this unlock icon visible after unlocking.
        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { toggleLock() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(18) })

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                val progress = s?.progress ?: 0
                val remote = currentRemoteClient()
                if (remote != null) {
                    val length = remote.streamDuration.coerceAtLeast(0L)
                    if (length > 0L) remote.seek((progress.toLong() * length) / 1000L)
                } else {
                    val p = player ?: return
                    if (p.length > 0) p.time = (progress.toLong() * p.length) / 1000L
                }
                if (partyActive && partyIsHost) sendWatchPartyControl("seek")
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    // ---------------------------------------------------------------------
    // PASS 4 — Native Watch Party room UI + sync + chat + stickers + voice
    // ---------------------------------------------------------------------
    private fun partyGlass(radius: Int = 22, alpha: Int = 224, strokeAlpha: Int = 72): GradientDrawable {
        val base = Color.rgb(24, 25, 29)
        val top = Color.argb(alpha.coerceIn(0,255), 38, 39, 44)
        val bottom = Color.argb((alpha - 18).coerceIn(0,255), Color.red(base), Color.green(base), Color.blue(base))
        return GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), Color.argb(strokeAlpha.coerceIn(0,255), 255,255,255))
        }
    }

    private fun partyAccent(radius: Int = 20): GradientDrawable =
        GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.rgb(91, 74, 230), Color.rgb(48, 128, 249))).apply {
            cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.argb(180, 181, 199, 255))
        }

    private fun partyIcon(icon: Int, description: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            contentDescription = description
            background = partyGlass(18, 232, 76)
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 18, 1.08f, 0f)
            setOnClickListener { click() }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(icon); setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER))
        }
    }

    private fun buildWatchPartyOverlay() {
        partyStatusChip = TextView(this).apply {
            text = if (partyIsHost) "●  میزبان · همگام" else "●  همراه · همگام"
            setTextColor(Color.WHITE)
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = partyGlass(999, 218, 68)
            setPadding(dp(13), dp(7), dp(13), dp(7))
            isClickable = true; isFocusable = true
            applyPlayerFocus(this, 999, 1.04f, 0f)
            setOnClickListener { showPartyRoomSheet() }
        }
        root.addView(partyStatusChip, FrameLayout.LayoutParams(-2, dp(38), Gravity.TOP or Gravity.RIGHT).apply {
            topMargin = dp(80); rightMargin = dp(18)
        })

        partyDock = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(6), dp(6), dp(6), dp(6))
            background = partyGlass(24, 218, 64)
        }
        val phone = partyIcon(R.drawable.ic_party_phone, "Voice Call") { onVoiceButtonPressed() }
        val chat = partyIcon(R.drawable.ic_party_chat, "گفت‌وگو") { showWatchPartyChat() }
        partyChatButton = chat
        val members = partyIcon(R.drawable.ic_party_members, "اعضای اتاق") { showPartyMembers() }
        val theme = partyIcon(R.drawable.ic_party_theme, "تم اتاق") { showPartyThemes() }
        partyDock?.addView(phone, LinearLayout.LayoutParams(dp(50), dp(50)).apply { bottomMargin = dp(7) })
        partyDock?.addView(chat, LinearLayout.LayoutParams(dp(50), dp(50)).apply { bottomMargin = dp(7) })
        partyDock?.addView(members, LinearLayout.LayoutParams(dp(50), dp(50)).apply { bottomMargin = dp(7) })
        partyDock?.addView(theme, LinearLayout.LayoutParams(dp(50), dp(50)))
        root.addView(partyDock, FrameLayout.LayoutParams(dp(64), -2, Gravity.RIGHT or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })
        applyPartyTheme("simple")
    }

    private fun updatePartyStatusChip() {
        val count = partyMembers.length()
        val label = if (partyIsHost) "میزبان" else "همراه"
        partyStatusChip?.text = "●  $label · ${if (count > 0) "$count نفر" else "همگام"}"
        partyStatusChip?.setTextColor(if (partyPollInFlight) Color.rgb(220,224,232) else Color.WHITE)
        updateChatBadge()
    }

    private fun updateChatBadge() {
        val button = partyChatButton as? FrameLayout ?: return
        val old = button.findViewWithTag<View>("party_unread")
        if (partyUnreadChat <= 0) { old?.let { button.removeView(it) }; return }
        val badge = (old as? TextView) ?: TextView(this).apply {
            tag = "party_unread"; setTextColor(Color.WHITE); textSize = 8f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; background = rounded(Color.rgb(239,68,68), 999, Color.WHITE)
            button.addView(this, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.TOP or Gravity.RIGHT).apply { topMargin = -dp(3); rightMargin = -dp(3) })
        }
        badge.text = partyUnreadChat.coerceAtMost(99).toString()
    }

    private fun pollWatchParty() {
        if (!partyActive || partyRoomCode.isBlank() || partyPollInFlight) return
        partyPollInFlight = true
        val requestStart = System.currentTimeMillis()
        AccountApi.watchPartyPoll(this, partyRoomCode, partyLastEventId, partyLastMessageId, partyLastVoiceSignalId) { result ->
            val requestEnd = System.currentTimeMillis()
            partyPollInFlight = false
            partyLastPollAt = requestEnd
            if (!result.success || result.json == null) {
                if (result.statusCode == 404 || result.json?.optString("error") == "room_expired") {
                    partyActive = false
                    handler.removeCallbacks(partyPollRunnable)
                    Toast.makeText(this, result.message.ifBlank { "اتاق Watch Party پایان یافت" }, Toast.LENGTH_LONG).show()
                }
                updatePartyStatusChip()
                return@watchPartyPoll
            }
            val json = result.json
            json.optLong("server_time_ms", 0L).takeIf { it > 0L }?.let { server ->
                val midpoint = requestStart + (requestEnd - requestStart) / 2L
                val candidate = server - midpoint
                partyServerOffsetMs = if (partyServerOffsetMs == 0L) candidate else ((partyServerOffsetMs * 3L + candidate) / 4L)
            }
            partyRole = json.optString("member_role", partyRole)
            partyIsHost = partyRole.equals("host", true)
            partyChatEnabled = json.optBoolean("chat_enabled", true)

            json.optJSONObject("room")?.let { room ->
                partyThemeKey = room.optString("background_key", partyThemeKey)
                partyRoomTitle = room.optString("content_title", partyRoomTitle)
                partyRoomPoster = room.optString("poster_url", partyRoomPoster)
                applyPartyTheme(partyThemeKey)
                val shared = room.optString("shared_source_url").trim()
                if (!partyIsHost && shared.isNotBlank() && shared != videoUrl) {
                    partyApplyingRemote = true
                    videoUrl = shared
                    requestedResumePosition = 0L
                    handler.postDelayed({
                        launchPlayerSafely(shared)
                        partyApplyingRemote = false
                    }, 80L)
                }
            }

            val events = json.optJSONArray("events") ?: JSONArray()
            for (i in 0 until events.length()) partyLastEventId = max(partyLastEventId, events.optJSONObject(i)?.optLong("id", 0L) ?: 0L)
            val messages = json.optJSONArray("messages") ?: JSONArray()
            handlePartyMessages(messages)
            partyMembers = json.optJSONArray("members") ?: partyMembers
            handleVoicePoll(json.optJSONObject("voice"))
            if (!partyIsHost) json.optJSONObject("state")?.let { applyWatchPartyState(it, json.optLong("server_time_ms", requestEnd + partyServerOffsetMs)) }
            updatePartyStatusChip()
        }
    }

    private fun applyWatchPartyState(state: JSONObject, serverTimeMs: Long) {
        val seq = state.optLong("sequence_no", -1L)
        if (seq < partyLastSequence) return
        partyLastSequence = seq
        val paused = state.optBoolean("paused", true)
        val rate = state.optDouble("playback_rate", 1.0).toFloat().coerceIn(0.5f, 2f)
        var target = state.optDouble("current_time", 0.0).coerceAtLeast(0.0)
        val updatedAt = state.optLong("updated_at_ms", 0L)
        if (!paused && updatedAt > 0L) {
            val effectiveServerNow = if (serverTimeMs > 0L) serverTimeMs else System.currentTimeMillis() + partyServerOffsetMs
            target += ((effectiveServerNow - updatedAt).coerceAtLeast(0L) / 1000.0) * rate
        }
        val p = player ?: return
        val local = p.time.coerceAtLeast(0L) / 1000.0
        val drift = target - local
        partyApplyingRemote = true
        try {
            if (paused && p.isPlaying) p.pause()
            if (!paused && !p.isPlaying) p.play()
            when {
                kotlin.math.abs(drift) > 1.15 -> {
                    p.time = (target * 1000.0).toLong().coerceAtLeast(0L)
                    p.setRate(rate)
                }
                !paused && kotlin.math.abs(drift) > 0.28 -> {
                    val correction = if (drift > 0) 0.035f else -0.035f
                    p.setRate((rate + correction).coerceIn(0.92f, 1.08f))
                }
                else -> p.setRate(rate)
            }
            currentSpeed = rate
            playIcon.setImageResource(if (paused) R.drawable.ic_player_play else R.drawable.ic_player_pause)
        } catch (_: Throwable) {
        } finally {
            handler.postDelayed({ partyApplyingRemote = false }, 90L)
        }
    }

    private fun currentPartyPositionSeconds(): Double {
        val remote = currentRemoteClient()
        return if (remote != null) remote.approximateStreamPosition.coerceAtLeast(0L) / 1000.0
        else (player?.time ?: 0L).coerceAtLeast(0L) / 1000.0
    }

    private fun currentPartyPaused(): Boolean {
        val remote = currentRemoteClient()
        return if (remote != null) !remote.isPlaying else player?.isPlaying != true
    }

    private fun sendWatchPartyControl(event: String) {
        if (!partyActive || !partyIsHost || partyApplyingRemote || partyRoomCode.isBlank()) return
        partyLastHostActionAt = System.currentTimeMillis()
        AccountApi.watchPartyControl(
            this, partyRoomCode, event, currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed,
            buffering = false, sourceUrl = if (event == "source_change") videoUrl else ""
        ) { result ->
            result.json?.optJSONObject("state")?.optLong("sequence_no", -1L)?.let { if (it >= 0) partyLastSequence = max(partyLastSequence, it) }
        }
    }

    private fun sendWatchPartyHeartbeatIfNeeded() {
        val now = System.currentTimeMillis()
        if (!partyActive || !partyIsHost || partyApplyingRemote || now - partyLastHeartbeatAt < 2300L || now - partyLastHostActionAt < 650L) return
        partyLastHeartbeatAt = now
        AccountApi.watchPartyControl(this, partyRoomCode, "state", currentPartyPositionSeconds(), currentPartyPaused(), currentSpeed) {}
    }

    private fun handlePartyMessages(messages: JSONArray) {
        for (i in 0 until messages.length()) {
            val message = messages.optJSONObject(i) ?: continue
            val id = message.optLong("id", 0L)
            if (id <= 0L) continue
            partyLastMessageId = max(partyLastMessageId, id)
            if (!partyMessageIdsShown.add(id)) continue
            appendPartyMessage(message)
            val media = message.optJSONObject("media")
            if (media != null && media.optString("url").isNotBlank()) showPartyReaction(media)
            if (partyChatDialog?.isShowing != true) partyUnreadChat++
        }
        while (partyMessageIdsShown.size > 220) partyMessageIdsShown.remove(partyMessageIdsShown.first())
        updateChatBadge()
    }

    private fun showWatchPartyChat() {
        if (!partyChatEnabled) { Toast.makeText(this, "گفت‌وگوی اتاق غیرفعال است", Toast.LENGTH_SHORT).show(); return }
        partyUnreadChat = 0; updateChatBadge()
        lateinit var dialog: AlertDialog
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(10), dp(10), dp(10), dp(10)); background = partyGlass(26, 246, 82)
        }
        val head = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL }
        head.addView(LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT
            addView(TextView(this@PlayerActivity).apply { text="گفت‌وگوی خصوصی"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT })
            addView(TextView(this@PlayerActivity).apply { text="پیام‌ها با پایان اتاق حذف می‌شوند"; setTextColor(muted); textSize=10f; gravity=Gravity.RIGHT })
        }, LinearLayout.LayoutParams(0,-2,1f))
        head.addView(TextView(this).apply { text="×"; setTextColor(Color.WHITE); textSize=24f; gravity=Gravity.CENTER; background=partyGlass(999,210,54); setOnClickListener { dialog.dismiss() } }, LinearLayout.LayoutParams(dp(42),dp(42)).apply { marginStart=dp(8) })
        shell.addView(head, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(8) })

        partyChatList = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(4),dp(4),dp(4),dp(4)) }
        partyChatScroll = ScrollView(this).apply { addView(partyChatList); isFillViewport=true }
        shell.addView(partyChatScroll, LinearLayout.LayoutParams(-1,0,1f))

        val composer = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; setPadding(0,dp(8),0,0) }
        val send = TextView(this).apply { text="➤"; setTextColor(Color.WHITE); textSize=20f; gravity=Gravity.CENTER; background=partyAccent(999); isClickable=true; isFocusable=true; applyPlayerFocus(this,999,1.06f,0f) }
        val input = EditText(this).apply {
            hint="پیام بنویسید..."; setHintTextColor(Color.rgb(130,134,146)); setTextColor(Color.WHITE); textSize=12.5f
            maxLines=3; background=partyGlass(999,214,66); setPadding(dp(14),0,dp(14),0); layoutDirection=View.LAYOUT_DIRECTION_RTL; gravity=Gravity.RIGHT or Gravity.CENTER_VERTICAL
        }
        val sticker = TextView(this).apply { text="☺"; setTextColor(Color.WHITE); textSize=20f; gravity=Gravity.CENTER; background=partyGlass(999,220,62); isClickable=true; isFocusable=true; setOnClickListener { showPartyStickerPicker() } }
        composer.addView(send, LinearLayout.LayoutParams(dp(48),dp(48)).apply { marginStart=dp(7) })
        composer.addView(input, LinearLayout.LayoutParams(0,dp(48),1f).apply { marginStart=dp(7) })
        composer.addView(sticker, LinearLayout.LayoutParams(dp(48),dp(48)))
        send.setOnClickListener {
            val value=input.text?.toString()?.trim().orEmpty()
            if (value.isNotBlank()) { sendPartyMessage(value); input.setText("") }
        }
        shell.addView(composer)
        dialog = AlertDialog.Builder(this).setView(shell).create()
        partyChatDialog = dialog
        dialog.setOnDismissListener { partyChatDialog=null; partyChatList=null; partyChatScroll=null }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val width = if (isTvLike()) (resources.displayMetrics.widthPixels * 0.48f).toInt() else (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val height = (resources.displayMetrics.heightPixels * 0.82f).toInt()
        dialog.window?.setLayout(width, height)
        dialog.window?.attributes = dialog.window?.attributes?.apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }
        // The poll is incremental, so ask for a fresh window if chat was opened late.
        partyMessageIdsShown.clear(); partyLastMessageId = 0L
        pollWatchParty()
    }

    private fun appendPartyMessage(message: JSONObject) {
        val list = partyChatList ?: return
        val row = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)); background=partyGlass(16,205,45)
        }
        val username = message.optString("username").ifBlank { "همراه" }
        val vip = message.optBoolean("is_vip", false)
        val admin = message.optBoolean("is_admin", false)
        row.addView(TextView(this).apply {
            text = username + when { admin -> "  ADMIN"; vip -> "  VIP"; else -> "" }
            setTextColor(if (vip || admin) Color.rgb(255,198,67) else Color.rgb(174,188,224)); textSize=10.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT
        })
        val textValue = message.optString("text").ifBlank { message.optString("message") }
        if (textValue.isNotBlank() && !textValue.startsWith("[bm-sticker:")) {
            row.addView(TextView(this).apply { text=textValue; setTextColor(Color.WHITE); textSize=12.5f; gravity=Gravity.RIGHT; setLineSpacing(dp(2).toFloat(),1f) }, LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(4) })
        }
        message.optJSONObject("media")?.optString("url")?.takeIf { it.isNotBlank() }?.let { url ->
            row.addView(ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; background=partyGlass(14,190,42); loadPartyImage(url,this) }, LinearLayout.LayoutParams(dp(132),dp(100)).apply { gravity=Gravity.RIGHT; topMargin=dp(6) })
        }
        list.addView(row, LinearLayout.LayoutParams(-1,-2).apply { bottomMargin=dp(6) })
        partyChatScroll?.post { partyChatScroll?.fullScroll(View.FOCUS_DOWN) }
    }

    private fun sendPartyMessage(message: String) {
        if (!partyActive || partyRoomCode.isBlank()) return
        val clientId = "android_${UUID.randomUUID().toString().replace("-","").take(40)}"
        AccountApi.watchPartyMessage(this, partyRoomCode, message, clientId) { result ->
            if (!result.success) Toast.makeText(this, result.message.ifBlank { "پیام ارسال نشد" }, Toast.LENGTH_SHORT).show()
            else handler.postDelayed({ pollWatchParty() }, 120L)
        }
    }

    private fun showPartyStickerPicker() {
        AccountApi.commentMediaCatalog(this) { result ->
            val packs=result.json?.optJSONArray("packs") ?: JSONArray()
            if (!result.success || packs.length()==0) { Toast.makeText(this,result.message.ifBlank { "استیکرها دریافت نشد" },Toast.LENGTH_SHORT).show(); return@commentMediaCatalog }
            lateinit var dialog: AlertDialog
            val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(10),dp(10),dp(10),dp(10)); background=partyGlass(24,246,82) }
            shell.addView(TextView(this).apply { text="استیکر و GIF"; setTextColor(Color.WHITE); textSize=16f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT; setPadding(dp(5),dp(2),dp(5),dp(8)) })
            val scroll=ScrollView(this)
            val grid=GridLayout(this).apply { columnCount=if(isTvLike()) 5 else 4; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
            var shown=0
            loop@ for(i in 0 until packs.length()) {
                val pack=packs.optJSONObject(i)?:continue
                val slug=pack.optString("slug").ifBlank { pack.optString("key") }
                val items=pack.optJSONArray("items")?:JSONArray()
                for(j in 0 until items.length()) {
                    if(shown>=60) break@loop
                    val it=items.optJSONObject(j)?:continue
                    val id=it.optString("id"); val url=it.optString("url")
                    if(slug.isBlank()||id.isBlank()||url.isBlank()) continue
                    val card=FrameLayout(this).apply {
                        background=partyGlass(14,205,45); isClickable=true; isFocusable=true; applyPlayerFocus(this,14,1.06f,0f)
                        addView(ImageView(this@PlayerActivity).apply { scaleType=ImageView.ScaleType.CENTER_CROP; loadPartyImage(url,this) },FrameLayout.LayoutParams(-1,-1).apply { setMargins(dp(4),dp(4),dp(4),dp(4)) })
                        setOnClickListener { sendPartyMessage("[bm-sticker:$slug:$id]"); dialog.dismiss() }
                    }
                    val spec=GridLayout.spec(GridLayout.UNDEFINED,1f)
                    grid.addView(card,GridLayout.LayoutParams(spec,spec).apply { width=dp(if(isTvLike())110 else 76); height=dp(if(isTvLike())90 else 68); setMargins(dp(4),dp(4),dp(4),dp(4)) })
                    shown++
                }
            }
            scroll.addView(grid); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
            shell.addView(TextView(this).apply { text="بستن"; setTextColor(Color.WHITE); gravity=Gravity.CENTER; background=partyGlass(16,215,55); setOnClickListener { dialog.dismiss() } },LinearLayout.LayoutParams(-1,dp(42)).apply { topMargin=dp(8) })
            dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(650) else (resources.displayMetrics.widthPixels*0.86f).toInt(),(resources.displayMetrics.heightPixels*0.78f).toInt())
        }
    }

    private fun loadPartyImage(url: String, target: ImageView) {
        Thread {
            try {
                val conn=(URL(url).openConnection() as HttpURLConnection).apply { connectTimeout=8000; readTimeout=10000; useCaches=true; setRequestProperty("User-Agent","BankmovieAndroidNative/2.1-WatchParty") }
                val bytes=conn.inputStream.use { input -> input.readBytes().let { if(it.size>5_000_000) ByteArray(0) else it } }
                conn.disconnect(); if(bytes.isEmpty()) return@Thread
                if(Build.VERSION.SDK_INT>=28) {
                    val drawable=ImageDecoder.decodeDrawable(ImageDecoder.createSource(ByteBuffer.wrap(bytes)))
                    runOnUiThread { if(!isFinishing){ target.setImageDrawable(drawable); if(drawable is AnimatedImageDrawable) drawable.start() } }
                } else {
                    val bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                    runOnUiThread { if(!isFinishing) target.setImageBitmap(bitmap) }
                }
            } catch (_:Throwable) {}
        }.start()
    }

    private fun showPartyReaction(media: JSONObject) {
        val url=media.optString("url"); if(url.isBlank()||!partyActive) return
        val image=ImageView(this).apply { scaleType=ImageView.ScaleType.CENTER_CROP; alpha=0f; scaleX=0.75f; scaleY=0.75f; background=partyGlass(24,170,42); loadPartyImage(url,this) }
        root.addView(image,FrameLayout.LayoutParams(dp(150),dp(150),Gravity.CENTER).apply { leftMargin=dp(220) })
        image.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).withEndAction {
            image.postDelayed({ image.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(240L).withEndAction { runCatching { root.removeView(image) } }.start() },2200L)
        }.start()
    }

    private fun showPartyMembers() {
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; setPadding(dp(14),dp(14),dp(14),dp(14)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="اعضای اتاق  ${partyMembers.length()}/2"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT })
        for(i in 0 until partyMembers.length()) {
            val m=partyMembers.optJSONObject(i)?:continue
            shell.addView(LinearLayout(this).apply {
                orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; setPadding(dp(10),dp(8),dp(10),dp(8)); background=partyGlass(16,206,44)
                addView(TextView(this@PlayerActivity).apply { text="●"; setTextColor(Color.rgb(46,213,132)); textSize=11f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(dp(28),-2))
                addView(LinearLayout(this@PlayerActivity).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.RIGHT; addView(TextView(this@PlayerActivity).apply { text=m.optString("username").ifBlank{"همراه"}; setTextColor(Color.WHITE); textSize=13f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT }); addView(TextView(this@PlayerActivity).apply { text=if(m.optString("member_role")=="host") "میزبان · کنترل پخش" else "همراه"; setTextColor(muted); textSize=9.5f; gravity=Gravity.RIGHT }) },LinearLayout.LayoutParams(0,-2,1f))
            },LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(8) })
        }
        shell.addView(TextView(this).apply { text="کپی لینک دعوت"; setTextColor(Color.WHITE); textSize=12.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; background=partyAccent(18); setOnClickListener { copyPartyInvite(); Toast.makeText(this@PlayerActivity,"لینک دعوت کپی شد",Toast.LENGTH_SHORT).show() } },LinearLayout.LayoutParams(-1,dp(46)).apply { topMargin=dp(12) })
        shell.addView(TextView(this).apply { text="بستن"; setTextColor(Color.WHITE); gravity=Gravity.CENTER; background=partyGlass(16,210,55); setOnClickListener { dialog.dismiss() } },LinearLayout.LayoutParams(-1,dp(42)).apply { topMargin=dp(8) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(520) else (resources.displayMetrics.widthPixels*0.82f).toInt(),-2)
    }

    private fun copyPartyInvite() {
        val url=partyInviteUrl.ifBlank { AppConfig.BASE_DOMAIN.trimEnd('/') + "/watch-party?room=" + Uri.encode(partyRoomCode) }
        val cb=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("BankMovie Watch Party",url))
    }

    private fun showPartyRoomSheet() {
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; layoutDirection=View.LAYOUT_DIRECTION_RTL; setPadding(dp(14),dp(14),dp(14),dp(14)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="سینمای خصوصی BankMovie"; setTextColor(Color.WHITE); textSize=18f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT })
        shell.addView(TextView(this).apply { text=(partyRoomTitle.ifBlank{title})+"\n"+(if(partyIsHost)"شما میزبان و کنترل‌کننده هستید" else "پخش با میزبان همگام می‌شود"); setTextColor(muted); textSize=11f; gravity=Gravity.RIGHT; setPadding(0,dp(7),0,dp(12)) })
        val actions=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; layoutDirection=View.LAYOUT_DIRECTION_RTL }
        fun action(label:String,click:()->Unit)=TextView(this).apply { text=label; setTextColor(Color.WHITE); textSize=11.5f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; background=partyGlass(16,216,58); setOnClickListener { click() } }
        actions.addView(action("دعوت") { copyPartyInvite(); Toast.makeText(this,"کپی شد",Toast.LENGTH_SHORT).show() },LinearLayout.LayoutParams(0,dp(44),1f).apply { marginStart=dp(5) })
        actions.addView(action("اعضا") { dialog.dismiss(); showPartyMembers() },LinearLayout.LayoutParams(0,dp(44),1f).apply { marginStart=dp(5);marginEnd=dp(5) })
        actions.addView(action("تم اتاق") { dialog.dismiss(); showPartyThemes() },LinearLayout.LayoutParams(0,dp(44),1f).apply { marginEnd=dp(5) })
        shell.addView(actions)
        shell.addView(TextView(this).apply { text=if(partyIsHost)"بستن اتاق و خروج" else "خروج از اتاق"; setTextColor(Color.rgb(255,138,154)); textSize=12f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER; background=partyGlass(16,215,60); setOnClickListener { dialog.dismiss(); leaveWatchPartyAndFinish() } },LinearLayout.LayoutParams(-1,dp(44)).apply { topMargin=dp(10) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(560) else (resources.displayMetrics.widthPixels*0.84f).toInt(),-2)
    }

    private fun showPartyThemes() {
        val themes=listOf(
            "simple" to "ساده", "purple_dream" to "رویای بنفش", "teal_mist" to "مه آبی", "golden" to "طلایی",
            "forest" to "جنگل", "pink_cloud" to "رویای پونی", "interstellar" to "میان ستاره‌ای", "pony" to "پونی", "pizza" to "پیتزا",
            "darkness" to "تاریکی", "romantic_hearts" to "عاشقانه", "galaxy_nova" to "کهکشانی", "starlight" to "ستاره‌ای", "aurora" to "شفق قطبی"
        )
        lateinit var dialog:AlertDialog
        val shell=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(12),dp(12),dp(12),dp(12)); background=partyGlass(24,246,82) }
        shell.addView(TextView(this).apply { text="تم و پس‌زمینه اتاق"; setTextColor(Color.WHITE); textSize=17f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.RIGHT; setPadding(0,0,0,dp(8)) })
        val scroll=ScrollView(this); val grid=GridLayout(this).apply { columnCount=3; alignmentMode=GridLayout.ALIGN_BOUNDS; useDefaultMargins=false }
        themes.forEach { (key,label) ->
            val color=partyThemeColor(key)
            val card=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(dp(5),dp(5),dp(5),dp(5)); background=if(key==partyThemeKey) rounded(Color.argb(72,Color.red(blue),Color.green(blue),Color.blue(blue)),16,blue2) else partyGlass(16,205,45); isClickable=partyIsHost; isFocusable=partyIsHost; applyPlayerFocus(this,16,1.05f,0f)
                addView(View(this@PlayerActivity).apply { background=GradientDrawable(GradientDrawable.Orientation.TL_BR,intArrayOf(color,Color.rgb(20,21,26))).apply { cornerRadius=dp(12).toFloat() } },LinearLayout.LayoutParams(-1,dp(55)))
                addView(TextView(this@PlayerActivity).apply { text=label; setTextColor(Color.WHITE); textSize=10f; typeface=Typeface.DEFAULT_BOLD; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,dp(28)))
                setOnClickListener { if(partyIsHost) AccountApi.watchPartyRoomSettings(this@PlayerActivity,partyRoomCode,key){r->if(r.success){partyThemeKey=key;applyPartyTheme(key);dialog.dismiss()}else Toast.makeText(this@PlayerActivity,r.message,Toast.LENGTH_SHORT).show()} }
            }
            grid.addView(card,GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED,1f),GridLayout.spec(GridLayout.UNDEFINED,1f)).apply { width=dp(if(isTvLike())160 else 105); height=dp(96); setMargins(dp(4),dp(4),dp(4),dp(4)) })
        }
        scroll.addView(grid); shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        if(!partyIsHost) shell.addView(TextView(this).apply { text="انتخاب تم فقط در اختیار میزبان VIP است"; setTextColor(muted); textSize=10f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,-2).apply { topMargin=dp(6) })
        dialog=AlertDialog.Builder(this).setView(shell).create(); dialog.show(); dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT)); dialog.window?.setLayout(if(isTvLike())dp(590) else (resources.displayMetrics.widthPixels*0.9f).toInt(),(resources.displayMetrics.heightPixels*0.82f).toInt())
    }

    private fun partyThemeColor(key:String):Int=when(key){
        "purple_dream"->Color.rgb(126,53,210); "teal_mist"->Color.rgb(20,150,153); "golden"->Color.rgb(204,146,24); "forest"->Color.rgb(22,116,67);
        "pink_cloud"->Color.rgb(182,72,130); "interstellar"->Color.rgb(60,43,127); "pony"->Color.rgb(178,92,136); "pizza"->Color.rgb(142,74,35); "darkness"->Color.rgb(24,27,34);
        "romantic_hearts"->Color.rgb(171,46,93); "galaxy_nova"->Color.rgb(91,34,130); "starlight"->Color.rgb(38,68,137); "aurora"->Color.rgb(19,135,111);
        else->Color.rgb(45,49,58)
    }

    private fun applyPartyTheme(key:String) {
        val c=partyThemeColor(key)
        partyDock?.background=GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,intArrayOf(Color.argb(215,Color.red(c),Color.green(c),Color.blue(c)),Color.argb(230,22,23,28))).apply { cornerRadius=dp(24).toFloat(); setStroke(dp(1),Color.argb(90,255,255,255)) }
    }

    private fun leaveWatchPartyAndFinish() {
        if (!partyActive) { finish(); return }
        partyActive=false; handler.removeCallbacks(partyPollRunnable)
        hangupVoice(false)
        AccountApi.watchPartyLeave(this,partyRoomCode,partyIsHost) { finish() }
        handler.postDelayed({ if(!isFinishing) finish() },700L)
    }

    // ------------------------------- Voice Call -------------------------------
    private fun onVoiceButtonPressed() {
        if (!partyActive) return
        if (voiceCallToken.isNotBlank() && voiceCallStatus in setOf("ringing","connecting","active")) { showVoiceStatusSheet(); return }
        if (!partyVoiceEnabled && !partyVoicePeerAvailable) { Toast.makeText(this,"همراه هنوز برای Voice Call آماده نیست",Toast.LENGTH_SHORT).show(); return }
        if (ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED) {
            pendingVoiceStartAfterPermission=true; ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),REQ_WATCH_PARTY_AUDIO); return
        }
        startVoiceCall()
    }

    override fun onRequestPermissionsResult(requestCode:Int,permissions:Array<out String>,grantResults:IntArray){
        super.onRequestPermissionsResult(requestCode,permissions,grantResults)
        if(requestCode==REQ_WATCH_PARTY_AUDIO){
            val granted=grantResults.isNotEmpty()&&grantResults[0]==PackageManager.PERMISSION_GRANTED
            when {
                granted && pendingVoiceAcceptAfterPermission -> acceptVoiceCall()
                granted && pendingVoiceStartAfterPermission -> startVoiceCall()
                !granted -> Toast.makeText(this,"برای Voice Call دسترسی میکروفون لازم است",Toast.LENGTH_LONG).show()
            }
            pendingVoiceStartAfterPermission=false
            pendingVoiceAcceptAfterPermission=false
        }
    }

    private fun startVoiceCall() {
        AccountApi.watchPartyVoiceStart(this,partyRoomCode){result->
            if(!result.success){Toast.makeText(this,result.message.ifBlank{"تماس شروع نشد"},Toast.LENGTH_LONG).show();return@watchPartyVoiceStart}
            val call=result.json?.optJSONObject("call")?:return@watchPartyVoiceStart
            updateVoiceCall(call)
            if(voiceIsCaller){ ensureRtcPeer(); createAndSendOffer() }
            showVoiceStatusSheet()
        }
    }

    private fun handleVoicePoll(voice:JSONObject?) {
        if(voice==null){partyVoiceEnabled=false;partyVoicePeerAvailable=false;return}
        partyVoiceEnabled=voice.optBoolean("enabled",false)
        partyVoicePeerAvailable=voice.optBoolean("peer_available",false)
        val call=voice.optJSONObject("call")
        if(call!=null){
            val previousToken=voiceCallToken; updateVoiceCall(call)
            if(voiceCallStatus=="ringing"&&!voiceIsCaller&&voiceCallToken.isNotBlank()&&voiceCallToken!=lastIncomingVoiceToken) showIncomingVoiceCall(call)
            if(previousToken.isNotBlank()&&voiceCallToken==previousToken&&voiceCallStatus in setOf("ended","rejected","missed")) releaseRtc()
        }
        val signals=voice.optJSONArray("signals")?:JSONArray()
        for(i in 0 until signals.length()){
            val sig=signals.optJSONObject(i)?:continue; partyLastVoiceSignalId=max(partyLastVoiceSignalId,sig.optLong("id",0L)); handleVoiceSignal(sig)
        }
        partyLastVoiceSignalId=max(partyLastVoiceSignalId,voice.optLong("last_signal_id",0L))
    }

    private fun updateVoiceCall(call:JSONObject){
        voiceCallToken=call.optString("token",voiceCallToken); voiceCallStatus=call.optString("status",voiceCallStatus); voiceIsCaller=call.optBoolean("is_caller",voiceIsCaller); voiceMuted=call.optBoolean("mine_muted",voiceMuted)
    }

    private fun showIncomingVoiceCall(call:JSONObject){
        lastIncomingVoiceToken=call.optString("token"); incomingVoiceDialog?.dismiss(); lateinit var d:AlertDialog
        val peer=call.optJSONObject("peer")?.optString("username").orEmpty().ifBlank{"همراه"}
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(dp(18),dp(18),dp(18),dp(18));background=partyGlass(26,248,86);addView(TextView(this@PlayerActivity).apply{text="تماس صوتی از $peer";setTextColor(Color.WHITE);textSize=18f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.CENTER});addView(TextView(this@PlayerActivity).apply{text="بدون خروج از فیلم با هم حرف بزنید";setTextColor(muted);textSize=10.5f;gravity=Gravity.CENTER},LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(6)});val row=LinearLayout(this@PlayerActivity).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};row.addView(TextView(this@PlayerActivity).apply{text="پاسخ";setTextColor(Color.WHITE);gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;background=partyAccent(18);setOnClickListener{acceptVoiceCall();d.dismiss()}},LinearLayout.LayoutParams(0,dp(46),1f).apply{marginStart=dp(5)});row.addView(TextView(this@PlayerActivity).apply{text="رد";setTextColor(Color.rgb(255,145,160));gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD;background=partyGlass(18,218,58);setOnClickListener{rejectVoiceCall();d.dismiss()}},LinearLayout.LayoutParams(0,dp(46),1f).apply{marginEnd=dp(5)});addView(row,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(14)})}
        d=AlertDialog.Builder(this).setView(box).create();incomingVoiceDialog=d;d.setOnDismissListener{incomingVoiceDialog=null};d.show();d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));d.window?.setLayout(if(isTvLike())dp(520)else(resources.displayMetrics.widthPixels*.78f).toInt(),-2)
    }

    private fun acceptVoiceCall(){
        if(voiceCallToken.isBlank())return
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){pendingVoiceAcceptAfterPermission=true;ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),REQ_WATCH_PARTY_AUDIO);return}
        AccountApi.watchPartyVoiceAction(this,partyRoomCode,voiceCallToken,"accept"){r->if(r.success){r.json?.optJSONObject("call")?.let(::updateVoiceCall);ensureRtcPeer();if(pendingRemoteOfferSdp.isNotBlank()){val s=pendingRemoteOfferSdp;pendingRemoteOfferSdp="";acceptRemoteOfferAndAnswer(s)}}else Toast.makeText(this,r.message,Toast.LENGTH_SHORT).show()}
    }
    private fun rejectVoiceCall(){ if(voiceCallToken.isNotBlank())AccountApi.watchPartyVoiceAction(this,partyRoomCode,voiceCallToken,"reject"){}; releaseRtc() }

    private fun showVoiceStatusSheet(){
        voiceStatusDialog?.dismiss(); lateinit var d:AlertDialog
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;layoutDirection=View.LAYOUT_DIRECTION_RTL;setPadding(dp(16),dp(16),dp(16),dp(16));background=partyGlass(24,246,82);addView(TextView(this@PlayerActivity).apply{text=when(voiceCallStatus){"ringing"->"در حال تماس...";"connecting"->"در حال اتصال Voice Call";"active"->"Voice Call متصل است";else->"Voice Call"};setTextColor(Color.WHITE);textSize=17f;typeface=Typeface.DEFAULT_BOLD;gravity=Gravity.RIGHT});val row=LinearLayout(this@PlayerActivity).apply{orientation=LinearLayout.HORIZONTAL;layoutDirection=View.LAYOUT_DIRECTION_RTL};row.addView(TextView(this@PlayerActivity).apply{text=if(voiceMuted)"وصل کردن میکروفون" else "بی‌صدا";setTextColor(Color.WHITE);gravity=Gravity.CENTER;background=partyGlass(16,218,58);setOnClickListener{toggleVoiceMute();d.dismiss()}},LinearLayout.LayoutParams(0,dp(44),1f).apply{marginStart=dp(5)});row.addView(TextView(this@PlayerActivity).apply{text="قطع تماس";setTextColor(Color.rgb(255,140,155));gravity=Gravity.CENTER;background=partyGlass(16,218,58);setOnClickListener{hangupVoice(true);d.dismiss()}},LinearLayout.LayoutParams(0,dp(44),1f).apply{marginEnd=dp(5)});addView(row,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(12)})}
        d=AlertDialog.Builder(this).setView(box).create();voiceStatusDialog=d;d.setOnDismissListener{voiceStatusDialog=null};d.show();d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT));d.window?.setLayout(if(isTvLike())dp(500)else(resources.displayMetrics.widthPixels*.75f).toInt(),-2)
    }

    private fun toggleVoiceMute(){voiceMuted=!voiceMuted;rtcAudioTrack?.setEnabled(!voiceMuted);if(voiceCallToken.isNotBlank())AccountApi.watchPartyVoiceAction(this,partyRoomCode,voiceCallToken,"mute",voiceMuted){} }
    private fun hangupVoice(send:Boolean){val token=voiceCallToken;if(send&&token.isNotBlank())AccountApi.watchPartyVoiceAction(this,partyRoomCode,token,"hangup"){};voiceCallStatus="ended";voiceCallToken="";releaseRtc()}

    private fun ensureRtcPeer():Boolean{
        if(rtcPeer!=null)return true
        if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)return false
        return try{
            if(rtcFactory==null){PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this).setEnableInternalTracer(false).createInitializationOptions());rtcAudioDevice=JavaAudioDeviceModule.builder(this).setUseHardwareAcousticEchoCanceler(true).setUseHardwareNoiseSuppressor(true).createAudioDeviceModule();rtcFactory=PeerConnectionFactory.builder().setAudioDeviceModule(rtcAudioDevice).createPeerConnectionFactory();rtcAudioSource=rtcFactory?.createAudioSource(MediaConstraints());rtcAudioTrack=rtcFactory?.createAudioTrack("bm_wp_audio",rtcAudioSource)?.apply{setEnabled(!voiceMuted)}}
            val iceServers=listOf(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer(),PeerConnection.IceServer.builder("stun:stun1.l.google.com:19302").createIceServer())
            val cfg=PeerConnection.RTCConfiguration(iceServers).apply{sdpSemantics=PeerConnection.SdpSemantics.UNIFIED_PLAN;continualGatheringPolicy=PeerConnection.ContinualGatheringPolicy.GATHER_CONTINUALLY}
            rtcPeer=rtcFactory?.createPeerConnection(cfg,object:PeerConnection.Observer{
                override fun onSignalingChange(newState:PeerConnection.SignalingState){}
                override fun onIceConnectionChange(newState:PeerConnection.IceConnectionState){if(newState==PeerConnection.IceConnectionState.CONNECTED||newState==PeerConnection.IceConnectionState.COMPLETED){if(voiceCallToken.isNotBlank())AccountApi.watchPartyVoiceAction(this@PlayerActivity,partyRoomCode,voiceCallToken,"connected"){};voiceCallStatus="active"}else if(newState==PeerConnection.IceConnectionState.FAILED){if(voiceCallToken.isNotBlank())sendVoiceSignal("reconnect",JSONObject().put("reason","network"))}}
                override fun onIceConnectionReceivingChange(receiving:Boolean){}
                override fun onIceGatheringChange(newState:PeerConnection.IceGatheringState){}
                override fun onIceCandidate(candidate:IceCandidate){sendVoiceSignal("ice",JSONObject().put("candidate",candidate.sdp).put("sdpMid",candidate.sdpMid).put("sdpMLineIndex",candidate.sdpMLineIndex))}
                override fun onIceCandidatesRemoved(candidates:Array<IceCandidate>){}
                override fun onAddStream(stream:MediaStream){}
                override fun onRemoveStream(stream:MediaStream){}
                override fun onDataChannel(channel:DataChannel){}
                override fun onRenegotiationNeeded(){}
                override fun onAddTrack(receiver:RtpReceiver,mediaStreams:Array<MediaStream>){}
            })
            rtcAudioTrack?.let{track->rtcPeer?.addTrack(track,listOf("bm_wp_stream"))}
            pendingRemoteIce.toList().forEach{rtcPeer?.addIceCandidate(it)};pendingRemoteIce.clear()
            audioManager.mode=android.media.AudioManager.MODE_IN_COMMUNICATION
            @Suppress("DEPRECATION")
            if(Build.VERSION.SDK_INT<31) audioManager.isSpeakerphoneOn=true
            rtcPeer!=null
        }catch(_:Throwable){releaseRtc();false}
    }

    private fun createAndSendOffer(){val pc=rtcPeer?:return;val constraints=MediaConstraints().apply{mandatory.add(MediaConstraints.KeyValuePair("OfferToReceiveAudio","true"))};pc.createOffer(object:SdpObserver{override fun onCreateSuccess(desc:SessionDescription){pc.setLocalDescription(simpleSdpObserver(),desc);sendVoiceSignal("offer",JSONObject().put("type","offer").put("sdp",desc.description))};override fun onSetSuccess(){};override fun onCreateFailure(error:String?){};override fun onSetFailure(error:String?){}},constraints)}
    private fun acceptRemoteOfferAndAnswer(sdp:String){if(!ensureRtcPeer())return;val pc=rtcPeer?:return;pc.setRemoteDescription(object:SdpObserver{override fun onSetSuccess(){pc.createAnswer(object:SdpObserver{override fun onCreateSuccess(desc:SessionDescription){pc.setLocalDescription(simpleSdpObserver(),desc);sendVoiceSignal("answer",JSONObject().put("type","answer").put("sdp",desc.description))};override fun onSetSuccess(){};override fun onCreateFailure(error:String?){};override fun onSetFailure(error:String?){}},MediaConstraints())};override fun onCreateSuccess(desc:SessionDescription){};override fun onCreateFailure(error:String?){};override fun onSetFailure(error:String?){}},SessionDescription(SessionDescription.Type.OFFER,sdp))}
    private fun acceptRemoteAnswer(sdp:String){if(!ensureRtcPeer())return;rtcPeer?.setRemoteDescription(simpleSdpObserver(),SessionDescription(SessionDescription.Type.ANSWER,sdp))}
    private fun simpleSdpObserver()=object:SdpObserver{override fun onCreateSuccess(desc:SessionDescription){};override fun onSetSuccess(){};override fun onCreateFailure(error:String?){};override fun onSetFailure(error:String?){} }
    private fun sendVoiceSignal(type:String,payload:JSONObject){if(voiceCallToken.isBlank())return;val id="android_${UUID.randomUUID().toString().replace("-","").take(36)}";AccountApi.watchPartyVoiceSignal(this,partyRoomCode,voiceCallToken,type,id,payload){} }
    private fun handleVoiceSignal(signal:JSONObject){
        if(signal.optString("call_token")!=voiceCallToken&&voiceCallToken.isNotBlank())return
        val type=signal.optString("signal_type");val payload=signal.optJSONObject("payload")?:return
        when(type){"offer"->{val sdp=payload.optString("sdp");if(sdp.isBlank())return;if(voiceCallStatus=="ringing"&&!voiceIsCaller)pendingRemoteOfferSdp=sdp else acceptRemoteOfferAndAnswer(sdp)};"answer"->{val sdp=payload.optString("sdp");if(sdp.isNotBlank())acceptRemoteAnswer(sdp)};"ice"->{val c=payload.optString("candidate");if(c.isNotBlank()){val ice=IceCandidate(payload.optString("sdpMid").takeIf{it.isNotBlank()},payload.optInt("sdpMLineIndex",0),c);if(rtcPeer!=null)rtcPeer?.addIceCandidate(ice)else pendingRemoteIce.add(ice)}};"reconnect"->{if(voiceIsCaller&&rtcPeer!=null)createAndSendOffer()}}
    }
    private fun releaseRtc(){runCatching{rtcPeer?.close()};rtcPeer=null;runCatching{rtcAudioTrack?.dispose()};rtcAudioTrack=null;runCatching{rtcAudioSource?.dispose()};rtcAudioSource=null;runCatching{rtcFactory?.dispose()};rtcFactory=null;runCatching{rtcAudioDevice?.release()};rtcAudioDevice=null;pendingRemoteIce.clear();pendingRemoteOfferSdp="";audioManager.mode=android.media.AudioManager.MODE_NORMAL}

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(23), dp(23), Gravity.CENTER).apply { rightMargin = dp(8) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 11.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.045f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(28), dp(28)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 11.2f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    private fun launchPlayerSafely(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) {
            Toast.makeText(this, "لینک پخش خالی است", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        try {
            startPlayer(clean)
        } catch (_: Throwable) {
            releasePlayer()
            if (hardwareDecoder) {
                hardwareDecoder = false
                handler.postDelayed({ runCatching { startPlayer(clean) }.onFailure {
                    Toast.makeText(this, "این نسخه با پلیر داخلی سازگار نیست؛ نسخه دیگری را امتحان کنید", Toast.LENGTH_LONG).show()
                    finish()
                } }, 300L)
            } else {
                Toast.makeText(this, "این نسخه با پلیر داخلی سازگار نیست؛ نسخه دیگری را امتحان کنید", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun irancellSubtitleFontPath(): String? {
        val assetName = BankmovieFonts.assetFileName(subtitleFontMode) ?: return null
        val dir = File(filesDir, "subtitle_fonts")
        val out = File(dir, assetName)
        if (out.isFile && out.length() > 4096L) return out.absolutePath
        return runCatching {
            dir.mkdirs()
            assets.open("fonts/$assetName").use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.takeIf { it.isFile && it.length() > 4096L }?.absolutePath
        }.getOrNull()
    }

    private fun isMeteredOrMobileNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching {
            val network = cm.activeNetwork ?: return@runCatching true
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching true
            cm.isActiveNetworkMetered || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        }.getOrDefault(true)
    }

    private fun stableCacheMs(isAdaptive: Boolean): Int {
        if (!isAdaptive) return if (DeviceProfile.isLowEnd(this)) 2200 else 1700
        return when {
            isMeteredOrMobileNetwork() -> 6500
            DeviceProfile.isLowEnd(this) -> 5200
            else -> 4200
        }
    }

    private fun startPlayer(url: String) {
        releasePlayer()
        resumeApplied = false
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        // Restore the previously stable player buffering. The aggressive TV
        // adaptive/caching patch caused decoder artifacts on some televisions.
        val cacheMs = stableCacheMs(isDash || isHls)
        val subtitleBgColor = UiPreferences.subtitleBackgroundColor(this) and 0xFFFFFF
        val subtitleBgOpacity = UiPreferences.subtitleBackgroundOpacity(this)
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--drop-late-frames",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-color=${subtitleTextColor and 0xFFFFFF}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-color=$subtitleBgColor",
            "--freetype-background-opacity=$subtitleBgOpacity"
        )
        if (subtitleBold) libOptions.add("--freetype-bold")
        irancellSubtitleFontPath()?.let { fontPath ->
            libOptions.add("--freetype-font=$fontPath")
        }
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=rate")
            libOptions.add("--adaptive-use-access")
        }
        val lib = LibVLC(this, libOptions)
        vlc = lib
        val mp = MediaPlayer(lib)
        player = mp
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Buffering -> {
                        val percent = event.buffering
                        if (percent < 1f && bufferingStartedAt == 0L) bufferingStartedAt = System.currentTimeMillis()
                        if (percent >= 99f && bufferingStartedAt > 0L) {
                            val stalledFor = System.currentTimeMillis() - bufferingStartedAt
                            bufferingStartedAt = 0L
                            if (stalledFor >= 4500L) recentLongBufferCount += 1
                            if (recentLongBufferCount >= 3 && hardwareDecoder && !decoderAutoFallbackUsed) {
                                decoderAutoFallbackUsed = true
                                val keep = player?.time?.coerceAtLeast(0L) ?: 0L
                                hardwareDecoder = false
                                requestedResumePosition = keep
                                showHud("حالت پایدار تصویر فعال شد")
                                handler.postDelayed({ launchPlayerSafely(videoUrl) }, 180L)
                            }
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        playbackRetryCount = 0
                        bufferingStartedAt = 0L
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        if (pauseAfterLifecycleRestore) {
                            pauseAfterLifecycleRestore = false
                            handler.postDelayed({ runCatching { player?.pause() } }, 180L)
                        }
                        applyMode()
                        applySubtitleDelay()
                        handler.postDelayed({ applySubtitleVisibility() }, 350L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 500L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 1300L)
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val stored = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            val saved = max(stored, requestedResumePosition)
                            if (saved > 15000L) {
                                fun applyResumeSeek() {
                                    try {
                                        val current = player?.time ?: 0L
                                        if (current < saved - 5000L) player?.time = saved
                                    } catch (_: Throwable) {}
                                }
                                applyResumeSeek()
                                listOf(300L, 800L, 1600L, 3000L, 5000L, 8000L, 11000L).forEach { delayMs ->
                                    handler.postDelayed({ applyResumeSeek() }, delayMs)
                                }
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    MediaPlayer.Event.Paused -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.Stopped -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.EndReached -> playNext()
                    MediaPlayer.Event.EncounteredError -> {
                        if (playbackRetryCount < 2) {
                            playbackRetryCount += 1
                            if (playbackRetryCount == 1) hardwareDecoder = false
                            Toast.makeText(this, "خطا در پخش؛ تلاش مجدد ${playbackRetryCount}/2", Toast.LENGTH_SHORT).show()
                            handler.postDelayed({ launchPlayerSafely(videoUrl) }, 850L)
                        } else {
                            Toast.makeText(this, "این لینک با پلیر داخلی سازگار نیست؛ کیفیت یا نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
                            releasePlayer()
                        }
                    }
                }
            }
        }
        val media = Media(lib, Uri.parse(url))
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        if (subtitleBold) media.addOption(":freetype-bold")
        irancellSubtitleFontPath()?.let { media.addOption(":freetype-font=$it") }
        media.addOption(":freetype-color=${subtitleTextColor and 0xFFFFFF}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-color=$subtitleBgColor")
        media.addOption(":freetype-background-opacity=$subtitleBgOpacity")
        val resumePrefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val resumeStableKey = progressKey.ifBlank { "progress_$videoUrl" }
        val resumeBeforePlay = max(
            resumePrefs.getLong(
                resumeStableKey,
                resumePrefs.getLong("progress_$videoUrl", 0L)
            ),
            requestedResumePosition
        )
        resumeTarget = resumeBeforePlay
        resumeGuardUntil = System.currentTimeMillis() + 12000L
        if (resumeBeforePlay > 15000L) {
            media.addOption(":start-time=${resumeBeforePlay / 1000L}")
        }
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=rate")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int) {
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        nextPromptShownKey = ""
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        title = tracks[index].title
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        requestedResumePosition = UiPreferences.prefs(this).getLong(progressKey, UiPreferences.prefs(this).getLong("progress_$videoUrl", 0L))
        updateLabels()
        refreshTopActions()
        val castSession = currentCastSession()
        if (castSession != null) {
            castCurrentMedia(castSession, requestedResumePosition)
        } else {
            launchPlayerSafely(videoUrl)
        }
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }.trim()
        val normalized = base.lowercase(Locale.US).replace("‌", " ")
        val alreadyHasEpisode = normalized.contains("قسمت ${t.episode}") || normalized.contains("episode ${t.episode}") || normalized.contains("e${t.episode}")
        val alreadyHasSeason = normalized.contains("فصل ${t.season}") || normalized.contains("season ${t.season}") || normalized.contains("s${t.season}")
        val episodeHead = when {
            t.season > 0 && t.episode > 0 && !(alreadyHasSeason || alreadyHasEpisode) -> "فصل ${t.season} • قسمت ${t.episode}"
            t.episode > 0 && !alreadyHasEpisode -> "قسمت ${t.episode}"
            t.season > 0 && !alreadyHasSeason -> "فصل ${t.season}"
            else -> ""
        }
        val standard = streamStandard(t.url)
        return listOf(episodeHead, base, standard).filter { it.isNotBlank() }.distinct().joinToString(" • ")
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(muted)
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private data class NativeTrackOption(val id: Int, val name: String)

    private fun nativeTrackOptions(methodName: String): List<NativeTrackOption> {
        val mp = player ?: return emptyList()
        return try {
            val raw = mp.javaClass.getMethod(methodName).invoke(mp)
            val values: List<Any?> = when (raw) {
                is Array<*> -> raw.toList()
                is Iterable<*> -> raw.toList()
                else -> emptyList()
            }
            values.mapNotNull { item ->
                if (item == null) return@mapNotNull null
                val id = try {
                    item.javaClass.getMethod("getId").invoke(item) as? Int
                } catch (_: Throwable) {
                    try { item.javaClass.getField("id").getInt(item) } catch (_: Throwable) { null }
                } ?: return@mapNotNull null
                val name = try {
                    item.javaClass.getMethod("getName").invoke(item)?.toString()
                } catch (_: Throwable) {
                    try { item.javaClass.getField("name").get(item)?.toString() } catch (_: Throwable) { null }
                }.orEmpty().ifBlank { "Track $id" }
                NativeTrackOption(id, name)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun currentNativeTrack(methodName: String): Int {
        val mp = player ?: return -1
        return try { (mp.javaClass.getMethod(methodName).invoke(mp) as? Int) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun setNativeTrack(methodName: String, id: Int): Boolean {
        val mp = player ?: return false
        return try {
            val result = mp.javaClass.getMethod(methodName, Integer.TYPE).invoke(mp, id)
            result !is Boolean || result
        } catch (_: Throwable) {
            false
        }
    }

    private fun applySubtitleVisibility() {
        if (!subtitleEnabled) {
            val current = currentNativeTrack("getSpuTrack")
            if (current >= 0) lastEnabledSpuTrack = current
            setNativeTrack("setSpuTrack", -1)
            return
        }
        val current = currentNativeTrack("getSpuTrack")
        if (current >= 0) return
        val available = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        val target = available.firstOrNull { it.id == lastEnabledSpuTrack } ?: available.firstOrNull()
        if (target != null) setNativeTrack("setSpuTrack", target.id)
    }

    private fun applyPreferredNativeTracks() {
        if (preferredAudioTrackId != Int.MIN_VALUE && preferredAudioTrackId >= 0) {
            setNativeTrack("setAudioTrack", preferredAudioTrackId)
        }
        if (!subtitleEnabled || preferredSubtitleTrackId == -1) {
            setNativeTrack("setSpuTrack", -1)
            return
        }
        if (preferredSubtitleTrackId != Int.MIN_VALUE && preferredSubtitleTrackId >= 0) {
            lastEnabledSpuTrack = preferredSubtitleTrackId
            setNativeTrack("setSpuTrack", preferredSubtitleTrackId)
        }
    }

    private fun showNativeTrackDialog(titleValue: String, audio: Boolean) {
        val options = nativeTrackOptions(if (audio) "getAudioTracks" else "getSpuTracks")
        val current = currentNativeTrack(if (audio) "getAudioTrack" else "getSpuTrack")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(248, 18, 18, 21), dp(28), Color.argb(150, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(sectionTitle(titleValue))
        var dialog: AlertDialog? = null
        if (!audio) {
            box.addView(sheetButton("خاموش${if (current < 0) "  ✓" else ""}") {
                subtitleEnabled = false
                UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, false).apply()
                applySubtitleVisibility()
                dialog?.dismiss()
                showHud("زیرنویس غیرفعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        options.filter { audio || it.id >= 0 }.forEach { option ->
            box.addView(sheetButton("${option.name}${if (option.id == current) "  ✓" else ""}") {
                if (audio) setNativeTrack("setAudioTrack", option.id)
                else {
                    subtitleEnabled = true
                    lastEnabledSpuTrack = option.id
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    setNativeTrack("setSpuTrack", option.id)
                }
                dialog?.dismiss()
                showHud(if (audio) "ترک صدا تغییر کرد" else "زیرنویس فعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        if (options.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "ترکی برای انتخاب پیدا نشد"
                setTextColor(muted)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(250, 17, 17, 20), dp(30), Color.argb(155, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        scroll.addView(box)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات پخش"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_settings)
            setColorFilter(blue)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(Color.argb(32, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(15), Color.argb(120, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("صدا و زیرنویس"))
        box.addView(settingButton("صدا، زیرنویس و ظاهر", subtitleStyleLabel(), "انتخاب ترک صدا و زیرنویس، خاموش‌کردن، رنگ، پس‌زمینه، اندازه و فونت") { showAudioSubtitleSettingsSheet() })

        box.addView(settingsMiniLabel("پخش"))
        box.addView(settingButton("سرعت پخش", speedLabel(), "تنظیم از 0.5x تا 2x") { showSpeedSheet() })
        box.addView(settingButton("زمان پرش", "${seekJumpMs / 1000L} ثانیه", "مقدار عقب و جلو رفتن") {
            val values = listOf(5L, 10L, 30L, 60L)
            val currentIndex = values.indexOf(seekJumpMs / 1000L).let { if (it < 0) 1 else it }
            val next = values[(currentIndex + 1) % values.size]
            seekJumpMs = next * 1000L
            UiPreferences.prefs(this).edit().putInt(UiPreferences.KEY_SEEK_SECONDS, next.toInt()).apply()
            showHud("زمان پرش: $next ثانیه")
        })
        box.addView(settingButton("پخش خودکار قسمت بعد", if (autoPlayNext) "روشن" else "خاموش", "پس از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("پخش خودکار: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری", "برای دستگاه‌های ضعیف حالت سخت‌افزاری بهتر است") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("دیکودر: ${if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری"}")
        })
        box.addView(settingButton("تصویر در تصویر", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("تایمر خواب", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("قفل کنترل‌ها", if (controlsLocked) "قفل" else "باز", "قفل‌کردن دکمه‌ها و ژست‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(blue)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(245, 28, 28, 32), dp(18), Color.argb(72, 255, 255, 255))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(blue2)
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.argb(246, 27, 63, 104), dp(28), Color.argb(96, 190, 220, 255))
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showAudioSubtitleSettingsSheet() {
        var localEnabled = subtitleEnabled
        var localTextColor = subtitleTextColor
        var localBgMode = subtitleBackgroundMode
        var localFontMode = subtitleFontMode
        var localScale = subtitleScale
        var localPosition = subtitlePositionIndex
        var localDelay = subtitleDelayMs
        var localAudioTrack = currentNativeTrack("getAudioTrack")
        var localSubtitleTrack = currentNativeTrack("getSpuTrack")

        val audioOptions = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
        val subtitleOptions = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
        if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.argb(250, 17, 17, 20), dp(30), Color.argb(155, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(TextView(this).apply {
            text = "صدا و زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_audio)
            setColorFilter(blue)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(Color.argb(32, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(15), Color.argb(120, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        fun optionButton(label: String, selected: () -> Boolean, click: () -> Unit): TextView {
            lateinit var view: TextView
            view = TextView(this).apply {
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(13), 0, dp(13), 0)
                maxLines = 2
                setOnClickListener { click() }
                applyPlayerFocus(this, 17, 1.03f, 0f)
            }
            fun refresh() {
                val active = selected()
                view.text = label + if (active) "   ✓" else ""
                view.background = if (active) rounded(Color.argb(90, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(16), blue) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (active) blue2 else Color.WHITE)
            }
            view.tag = Runnable { refresh() }
            refresh()
            return view
        }

        fun refreshOptions(container: LinearLayout) {
            for (i in 0 until container.childCount) {
                (container.getChildAt(i).tag as? Runnable)?.run()
            }
        }

        box.addView(settingsMiniLabel("ترک صدا"))
        val audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (audioOptions.isEmpty()) {
            audioBox.addView(TextView(this).apply {
                text = "ترک صدای جداگانه‌ای در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = rounded(Color.rgb(28, 28, 32), dp(15), Color.argb(70, 255, 255, 255))
            })
        } else {
            audioOptions.forEach { option ->
                val button = optionButton(option.name, { localAudioTrack == option.id }) {
                    localAudioTrack = option.id
                    refreshOptions(audioBox)
                }
                audioBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            }
        }
        box.addView(audioBox)

        box.addView(settingsMiniLabel("زیرنویس"))
        val subtitleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        subtitleBox.addView(optionButton("خاموش", { !localEnabled || localSubtitleTrack < 0 }) {
            localEnabled = false
            localSubtitleTrack = -1
            refreshOptions(subtitleBox)
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        subtitleOptions.forEach { option ->
            val button = optionButton(option.name, { localEnabled && localSubtitleTrack == option.id }) {
                localEnabled = true
                localSubtitleTrack = option.id
                refreshOptions(subtitleBox)
            }
            subtitleBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        }
        if (subtitleOptions.isEmpty()) {
            subtitleBox.addView(TextView(this).apply {
                text = "زیرنویس داخلی در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
            })
        }
        box.addView(subtitleBox)

        box.addView(settingsMiniLabel("رنگ متن"))
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, dp(6)) }
        fun refreshColorViews() {
            colorViews.forEachIndexed { i, view ->
                view.text = if (colors[i] == localTextColor) "✓" else ""
                view.background = rounded(colors[i], dp(999), if (colors[i] == localTextColor) blue2 else Color.argb(90, 255, 255, 255))
                view.setTextColor(if (colors[i] == Color.BLACK) Color.WHITE else Color.BLACK)
            }
        }
        colors.forEachIndexed { index, color ->
            val v = TextView(this).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localTextColor = color; refreshColorViews() }
                applyPlayerFocus(this, 999, 1.08f, 0f)
            }
            colorViews.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColorViews()
        box.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("پس‌زمینه زیرنویس"))
        val bgOptions = listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی")
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        fun refreshBgButtons() {
            bgButtons.forEach { (key, view) ->
                val selected = key == localBgMode
                view.background = if (selected) rounded(blue, dp(15), blue2) else rounded(Color.rgb(30, 30, 34), dp(15), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        bgOptions.forEachIndexed { index, pair ->
            val v = TextView(this).apply {
                text = pair.second
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localBgMode = pair.first; refreshBgButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBgButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("فونت زیرنویس"))
        val fontButtons = mutableListOf<Pair<String, TextView>>()
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshFontButtons() {
            fontButtons.forEach { (key, view) ->
                val selected = key == localFontMode
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val v = TextView(this).apply {
                text = option.faLabel
                textSize = 13f
                typeface = BankmovieFonts.forMode(this@PlayerActivity, option.key, true)
                gravity = Gravity.CENTER
                setOnClickListener { localFontMode = option.key; refreshFontButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            fontButtons += option.key to v
            fontRow.addView(v, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshFontButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(fontRow)
        }, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("جای زیرنویس"))
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        val positionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshPositionButtons() {
            positionButtons.forEach { (index, view) ->
                val selected = index == localPosition
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        subtitlePositions.forEachIndexed { index, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localPosition = index; refreshPositionButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            positionButtons += index to v
            positionRow.addView(v, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshPositionButtons()
        box.addView(positionRow, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("اندازه و هماهنگی"))
        val sizeValue = TextView(this).apply { text = "اندازه متن: $localScale%"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeValue)
        val sizeSeek = SeekBar(this).apply {
            max = 90
            progress = (localScale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localScale = 80 + progress; sizeValue.text = "اندازه متن: $localScale%" }
            }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })

        val delayValue = TextView(this).apply { text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(delayValue)
        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localDelay = progress * 100 - 10000; delayValue.text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s" }
            }
        })
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        val applyButton = TextView(this).apply {
            text = "اعمال صدا و زیرنویس"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(blue, dp(22), blue2)
            applyPlayerFocus(this, 23, 1.035f, 0f)
        }
        box.addView(applyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val dialog = dialogOf(scroll)
        applyButton.setOnClickListener {
            val styleChanged = localTextColor != subtitleTextColor || localBgMode != subtitleBackgroundMode || localFontMode != subtitleFontMode || localScale != subtitleScale || localPosition != subtitlePositionIndex || localDelay != subtitleDelayMs
            subtitleEnabled = localEnabled
            subtitleTextColor = localTextColor
            subtitleBackgroundMode = localBgMode
            subtitleFontMode = localFontMode
            subtitleScale = localScale
            subtitlePositionIndex = localPosition
            subtitleDelayMs = localDelay
            preferredAudioTrackId = localAudioTrack
            preferredSubtitleTrackId = if (localEnabled) localSubtitleTrack else -1
            UiPreferences.prefs(this).edit()
                .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
                .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
                .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackgroundMode)
                .putString(UiPreferences.KEY_SUB_FONT, subtitleFontMode)
                .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
                .putInt(UiPreferences.KEY_SUB_DELAY, subtitleDelayMs)
                .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePositionIndex)
                .apply()
            dialog.dismiss()
            if (styleChanged) {
                restartKeepingTime("تنظیمات صدا و زیرنویس اعمال شد")
            } else {
                applyPreferredNativeTracks()
                applySubtitleDelay()
                showHud("صدا و زیرنویس اعمال شد")
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        showAudioSubtitleSettingsSheet()
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String {
        val colorLabel = when (subtitleTextColor) {
            Color.YELLOW -> "زرد"
            Color.BLACK -> "مشکی"
            Color.RED -> "قرمز"
            Color.BLUE -> "آبی"
            Color.GREEN -> "سبز"
            else -> "سفید"
        }
        val bgLabel = when (subtitleBackgroundMode) {
            "black" -> "پس‌زمینه مشکی"
            "white" -> "پس‌زمینه سفید"
            "yellow" -> "پس‌زمینه زرد"
            "red" -> "پس‌زمینه قرمز"
            "blue" -> "پس‌زمینه آبی"
            "pink" -> "پس‌زمینه صورتی"
            else -> "شفاف"
        }
        val fontLabel = BankmovieFonts.label(subtitleFontMode)
        return "$colorLabel • $bgLabel • $fontLabel • $subtitleScale%"
    }

    private fun applySubtitleDelay() {
        try { player?.javaClass?.getMethod("setSpuDelay", java.lang.Long.TYPE)?.invoke(player, subtitleDelayMs * 1000L) } catch (_: Throwable) {}
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        requestedResumePosition = pos
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode(showError: Boolean = true) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val width = videoLayout.width.takeIf { it > 0 } ?: root.width.takeIf { it > 0 } ?: 16
                val height = videoLayout.height.takeIf { it > 0 } ?: root.height.takeIf { it > 0 } ?: 9
                val ratio = android.util.Rational(width.coerceAtLeast(1), height.coerceAtLeast(1))
                val builder = PictureInPictureParams.Builder()
                    .setAspectRatio(ratio)
                enterPictureInPictureMode(builder.build())
            } catch (_: Throwable) {
                if (showError) Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else if (showError) {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(white)
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun dialogOf(view: View): AlertDialog {
        return AlertDialog.Builder(this).setView(view).create().also { dialog ->
            dialog.setOnShowListener {
                val win = dialog.window
                win?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win?.setDimAmount(0.58f)
                win?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val decor = win?.decorView
                decor?.animate()?.cancel()
                if (decor != null) {
                    decor.alpha = 0f
                    decor.scaleX = 0.97f
                    decor.scaleY = 0.97f
                    decor.translationY = dp(10).toFloat()
                    decor.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                applyPlayerFocusTree(view)
                view.postDelayed({
                    fun first(v: View): Boolean {
                        if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                            v.requestFocus()
                            return true
                        }
                        if (v is android.view.ViewGroup) {
                            for (i in 0 until v.childCount) if (first(v.getChildAt(i))) return true
                        }
                        return false
                    }
                    first(view)
                }, 95L)
            }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(210, 8, 18, 36), dp(16), Color.argb(180, 55, 104, 188))
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun toggle() {
        val remote = currentRemoteClient()
        if (remote != null) {
            if (remote.isPlaying) remote.pause() else remote.play()
            playIcon.setImageResource(if (remote.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
            if (partyActive && partyIsHost) {
                val pausedNow = !remote.isPlaying
                sendWatchPartyControl(if (pausedNow) "pause" else "play")
            }
            hideBarsLater()
            return
        }
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        if (partyActive && partyIsHost) sendWatchPartyControl(if (p.isPlaying) "play" else "pause")
        hideBarsLater()
    }

    private fun seekBy(delta: Long) {
        val remote = currentRemoteClient()
        if (remote != null) {
            val len = remote.streamDuration.coerceAtLeast(0L)
            val now = remote.approximateStreamPosition.coerceAtLeast(0L)
            val target = if (len > 0) min(max(now + delta, 0L), len) else max(now + delta, 0L)
            remote.seek(target)
            if (partyActive && partyIsHost) sendWatchPartyControl("seek")
            updateProgress()
            hideBarsLater()
            return
        }
        val p = player ?: return
        val len = p.length
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        if (partyActive && partyIsHost) sendWatchPartyControl("seek")
        updateProgress()
        hideBarsLater()
    }

    private fun nextEpisodeIndex(): Int {
        val current = tracks.getOrNull(currentIndex) ?: return -1
        if (current.episode <= 0 && current.season <= 0) return -1
        val candidates = tracks.withIndex().filter { (_, track) ->
            track.episode > 0 && (
                track.season > current.season ||
                    (track.season == current.season && track.episode > current.episode)
                )
        }
        if (candidates.isEmpty()) return -1
        val targetPair = candidates.minWithOrNull(
            compareBy<IndexedValue<Track>> { it.value.season }
                .thenBy { it.value.episode }
        ) ?: return -1
        val sameEpisode = candidates.filter {
            it.value.season == targetPair.value.season && it.value.episode == targetPair.value.episode
        }
        return (sameEpisode.firstOrNull {
            it.value.quality.equals(current.quality, true) && isSubtitle(it.value) == isSubtitle(current)
        } ?: sameEpisode.firstOrNull {
            isSubtitle(it.value) == isSubtitle(current) && isAudioOnly(it.value) == isAudioOnly(current)
        } ?: sameEpisode.first()).index
    }

    private fun nextEpisodeTitle(index: Int): String {
        val target = tracks.getOrNull(index) ?: return "قسمت بعدی"
        return if (target.season > 0) "فصل ${target.season} • قسمت ${target.episode}" else "قسمت ${target.episode}"
    }

    private fun maybePromptNextEpisode(time: Long, length: Long) {
        if (!autoPlayNext || length <= 0L || time <= 0L) return
        val nextIndex = nextEpisodeIndex()
        if (nextIndex < 0) return
        val current = tracks.getOrNull(currentIndex) ?: return
        val key = "${current.season}:${current.episode}:${current.url}"
        if (nextPromptShownKey == key || time.toDouble() / length.toDouble() < 0.95) return
        nextPromptShownKey = key
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        nextPromptDialog = AlertDialog.Builder(this)
            .setTitle("قسمت بعدی آماده است")
            .setMessage("${nextEpisodeTitle(nextIndex)} پخش شود؟")
            .setPositiveButton("بله، پخش کن") { _, _ ->
                skipNextOnce = false
                switchTo(nextIndex)
            }
            .setNegativeButton("نه، همین قسمت") { _, _ ->
                skipNextOnce = true
                showHud("در همین قسمت می‌مانیم")
            }
            .create().also { dialog ->
                dialog.setOnDismissListener { nextPromptDialog = null }
                dialog.show()
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.rgb(18, 18, 22)))
            }
    }

    private fun playNext() {
        if (!autoPlayNext || skipNextOnce) {
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        val next = nextEpisodeIndex()
        if (next >= 0 && nextPromptDialog == null) maybePromptNextEpisode(player?.time ?: 0L, player?.length ?: 0L)
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        val mp = player ?: return
        when (modes[modeIndex]) {
            "FIT" -> { setAspect(mp, null); setScale(mp, 0f) }
            "CROP" -> { setAspect(mp, null); setScale(mp, 1.2f) }
            "STRETCH" -> {
                videoLayout.post {
                    val w = max(root.width, resources.displayMetrics.widthPixels)
                    val h = max(root.height, resources.displayMetrics.heightPixels)
                    setAspect(mp, "$w:$h")
                    setScale(mp, 0f)
                }
            }
        }
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
        if (::unlockOverlay.isInitialized) {
            unlockOverlay.visibility = if (controlsLocked) View.VISIBLE else View.GONE
        }
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        centerControls.visibility = View.GONE
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartY = e.y
                touchStartBrightness = currentBrightness
                touchStartVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val dy = e.y - touchStartY
                if (gestureMode == 0 && abs(dy) > abs(dx) && abs(dy) > dp(18)) {
                    handler.removeCallbacks(longPressRunnable)
                    gestureMode = if (touchStartX < root.width / 2f) 1 else 2
                }
                if (gestureMode == 1) {
                    val delta = (touchStartY - e.y) / root.height
                    currentBrightness = (touchStartBrightness + delta * 1.6f).coerceIn(0.05f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = currentBrightness
                    window.attributes = lp
                    showHud("روشنایی ${ (currentBrightness * 100).roundToInt() }٪")
                    return true
                } else if (gestureMode == 2) {
                    val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    val delta = ((touchStartY - e.y) / root.height * maxVol).roundToInt()
                    val vol = (touchStartVolume + delta).coerceIn(0, maxVol)
                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vol, 0)
                    val percent = (vol * 100f / maxVol).roundToInt()
                    showHud("صدا ${percent}٪")
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            if (controlsVisible) hideControls() else showControls()
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val remote = currentRemoteClient()
            val p = player
            val savedTime = (remote?.approximateStreamPosition ?: p?.time ?: 0L).coerceAtLeast(0L)
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            val duration = (remote?.streamDuration ?: p?.length ?: 0L).coerceAtLeast(0L)
            getSharedPreferences("bm_smart_cinema", MODE_PRIVATE).edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .putLong("${stableKey}_duration", duration)
                .putLong("progress_${videoUrl}_duration", duration)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val remote = currentRemoteClient()
        if (remote != null) {
            val len = remote.streamDuration.coerceAtLeast(0L)
            val time = remote.approximateStreamPosition.coerceAtLeast(0L)
            if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
            currentTimeText.text = fmt(time)
            totalTimeText.text = if (len > 0) fmt(len) else "--:--"
            playIcon.setImageResource(if (remote.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
            savePlaybackProgress(false)
            return
        }
        val p = player ?: return
        val len = p.length
        var time = p.time
        if (resumeTarget > 15000L && System.currentTimeMillis() < resumeGuardUntil) {
            if (time < resumeTarget - 5000L) {
                try { p.time = resumeTarget } catch (_: Throwable) {}
                time = p.time
            } else {
                resumeTarget = 0L
            }
        }
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        if (len > 0L) maybePromptNextEpisode(time, len)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: MediaPlayer, ratio: String?) {
        try { mp.javaClass.getMethod("setAspectRatio", String::class.java).invoke(mp, ratio) } catch (_: Throwable) {}
    }

    private fun setScale(mp: MediaPlayer, scale: Float) {
        try { mp.javaClass.getMethod("setScale", java.lang.Float.TYPE).invoke(mp, scale) } catch (_: Throwable) {}
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    showSubtitleStyleSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        if (lifecycleRestorePending && videoUrl.isNotBlank()) {
            val target = lifecyclePosition.coerceAtLeast(0L)
            val shouldPlay = lifecycleWasPlaying
            val awayFor = System.currentTimeMillis() - lifecyclePausedAt
            lifecycleRestorePending = false
            requestedResumePosition = max(requestedResumePosition, target)
            pauseAfterLifecycleRestore = !shouldPlay
            // Recreate LibVLC and its video surface after screen lock/app switching.
            // Reattaching only the old surface leaves a black frame on several phones.
            handler.postDelayed({
                if (!isFinishing && !isDestroyed) launchPlayerSafely(videoUrl)
            }, if (awayFor > 500L) 70L else 160L)
        }
    }

    private fun releasePlayer() {
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        player = null
        vlc = null
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            !isFinishing &&
            player?.isPlaying == true &&
            videoUrl.isNotBlank()
        ) {
            enterPipMode(showError = false)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: android.content.res.Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            handler.removeCallbacks(hideRunnable)
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.GONE
            hudBox.visibility = View.GONE
            controlsVisible = false
        } else if (!controlsLocked) {
            showControls()
        }
    }

    override fun onPause() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing) {
            val current = player
            lifecyclePosition = (current?.time ?: 0L).coerceAtLeast(0L)
            lifecycleWasPlaying = current?.isPlaying == true
            lifecyclePausedAt = System.currentTimeMillis()
            lifecycleRestorePending = videoUrl.isNotBlank()
            runCatching { current?.pause() }
            if (partyActive && partyIsHost && lifecycleWasPlaying) sendWatchPartyControl("pause")
        }
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onDestroy() {
        savePlaybackProgress(true)
        nextPromptDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        runCatching { partyChatDialog?.dismiss() }
        runCatching { incomingVoiceDialog?.dismiss() }
        releaseRtc()
        try { castContext?.sessionManager?.removeSessionManagerListener(castSessionListener, CastSession::class.java) } catch (_: Throwable) {}
        releasePlayer()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
