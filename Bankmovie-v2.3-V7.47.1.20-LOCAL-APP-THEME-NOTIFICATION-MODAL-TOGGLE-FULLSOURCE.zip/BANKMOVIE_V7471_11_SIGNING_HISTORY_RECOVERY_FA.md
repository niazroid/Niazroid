# BankMovie V7.47.1.11 — Signing History Recovery

این هات‌فیکس فقط Workflow امضای Stable را مقاوم‌تر می‌کند و کد اپ را تغییر نمی‌دهد.

- Checkout با `fetch-depth: 0` انجام می‌شود تا commitهای قدیمی در دسترس باشند.
- مسیرهای فعلی مثل `BANKMOVIE_KEYSTORE_B64` و `bankmovie_update.jks` همچنان اولویت دارند.
- همه‌ی FULLSOURCEهای موجود در repository به‌صورت recursive بررسی می‌شوند.
- اگر فایل‌های قدیمی پاک شده باشند، blobهای FULLSOURCE در Git history بررسی می‌شوند.
- اگر ZIP تاریخی با Git LFS ذخیره شده باشد، Workflow تلاش می‌کند همان object را بازیابی کند.
- کلید فقط وقتی پذیرفته می‌شود که SHA-256 آن دقیقاً با کلید Stable اصلی BankMovie برابر باشد:
  `b73994bc2228e91763fde6d049fa792e44bcfce4f1359bef8d0bd6cd6d2f7b39`
- محتوای keystore هیچ‌وقت در log چاپ نمی‌شود.

اگر FULLSOURCE قدیمی با force-push/history rewrite از تاریخچه Git هم حذف شده باشد، recovery ممکن نیست و باید `BANKMOVIE_KEYSTORE_B64` یا خود `bankmovie_update.jks` برگردانده شود.
