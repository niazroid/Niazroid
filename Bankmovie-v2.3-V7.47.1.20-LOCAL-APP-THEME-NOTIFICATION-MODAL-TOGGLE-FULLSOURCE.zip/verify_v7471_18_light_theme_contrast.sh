#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
UI="$ROOT/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
TOGGLE="$ROOT/app/src/main/java/ir/bankmoviee/app/BmToggleView.kt"
NOTICE="$ROOT/app/src/main/java/ir/bankmoviee/app/BmNotice.kt"
ONBOARD="$ROOT/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"

for f in "$MAIN" "$UI" "$TOGGLE" "$NOTICE" "$ONBOARD"; do test -s "$f"; done

# Independent semantic Light palette: near-white pages, opaque white cards,
# dark readable text, dynamic accent and measured on-accent foreground.
grep -Fq 'background = Color.rgb(250, 250, 251)' "$UI"
grep -Fq 'panel = Color.WHITE' "$UI"
grep -Fq 'text = Color.rgb(17, 18, 20)' "$UI"
grep -Fq 'muted = Color.rgb(82, 86, 94)' "$UI"
grep -Fq 'faint = Color.rgb(108, 112, 121)' "$UI"
grep -Fq 'contrastRatio(Color.BLACK, primary) >= contrastRatio(Color.WHITE, primary)' "$UI"
grep -Fq 'fun readableAccent(context: Context, minimumContrast: Float = 4.5f)' "$UI"

# Dark glass transparency is forbidden on neutral Light surfaces.
grep -Fq 'val effectiveAlpha = if (p.light) 255 else fillAlpha.coerceIn(0, 255)' "$MAIN"
grep -Fq 'val bottomAlpha = if (p.light) 255 else' "$MAIN"
grep -Fq 'val topAlpha = if (p.light) 255 else fillAlpha.coerceIn(0, 255)' "$MAIN"

# Bottom navigation uses opaque Light chrome, dark inactive foreground and
# current user Accent for the selected destination.
grep -Fq 'bottomNav.background = if (p.light) rounded(p.panel, dp(lightRadius), p.stroke) else background' "$MAIN"
grep -Fq 'Color.rgb(63, 68, 76)' "$MAIN"
grep -Fq 'val activeAccent = if (p.light) UiPreferences.readableAccent(this) else p.primary' "$MAIN"
grep -Fq 'val activeColor = activeAccent' "$MAIN"
grep -Fq 'alpha = if (active) 1f else if (p.light) 0.96f else 0.92f' "$MAIN"
grep -Fq 'alpha = if (active || isCenterFab) 1f else if (p.light) 0.96f else 0.88f' "$MAIN"

# Detail/download surfaces must use semantic foregrounds instead of the old
# screen-specific white override.
grep -Fq 'private fun alphaPrimary(): Int = UiPreferences.palette(this).text' "$MAIN"
grep -Fq 'private fun alphaSecondaryText(): Int = UiPreferences.palette(this).muted' "$MAIN"
grep -Fq 'setColorFilter(if (p.light) UiPreferences.readableAccent(this@MainActivity) else Color.WHITE)' "$MAIN"
grep -Fq 'page.setBackgroundColor(if (detailPalette.light) detailPalette.background else Color.rgb(4, 4, 6))' "$MAIN"

# Profile, comments, avatar picker and VIP gates have explicit Light semantic foregrounds.
grep -Fq 'setTextColor(if (palette.light) palette.text else Color.WHITE)' "$MAIN"
grep -Fq 'setHintTextColor(p.muted); setTextColor(p.text)' "$MAIN"
grep -Fq 'val sheetBg = if (p.light) p.background else Color.rgb(5, 15, 31)' "$MAIN"
grep -Fq 'setTextColor(if (palette.light) palette.muted else Color.rgb(198, 206, 221))' "$MAIN"

# Dynamic Accent must remain readable even for very light accents.
grep -Fq 'palette.onPrimary' "$TOGGLE"
grep -Fq 'UiPreferences.contrastRatio(Color.BLACK, accent)' "$NOTICE"
grep -Fq 'UiPreferences.contrastRatio(Color.BLACK, primary)' "$ONBOARD"

# Numeric contrast audit for the neutral Light-theme text tokens and inactive nav.
python3 - <<'PY'
from math import isfinite

def lum(rgb):
    vals=[]
    for v in rgb:
        c=v/255.0
        vals.append(c/12.92 if c <= 0.04045 else ((c+0.055)/1.055)**2.4)
    return 0.2126*vals[0]+0.7152*vals[1]+0.0722*vals[2]

def ratio(a,b):
    x,y=lum(a),lum(b)
    hi,lo=max(x,y),min(x,y)
    return (hi+0.05)/(lo+0.05)

white=(255,255,255)
checks={
    'primary text': ((17,18,20), white, 7.0),
    'secondary text': ((82,86,94), white, 4.5),
    'tertiary text': ((108,112,121), white, 4.5),
    'bottom-nav inactive': ((63,68,76), white, 4.5),
}
for name,(fg,bg,minimum) in checks.items():
    r=ratio(fg,bg)
    if not isfinite(r) or r < minimum:
        raise SystemExit(f'LIGHT_CONTRAST_FAIL {name}: {r:.2f} < {minimum:.2f}')
    print(f'LIGHT_CONTRAST_OK {name}: {r:.2f}:1')

# The user's exact Accent remains the fill/indicator color. Foreground Accent
# ink is allowed to darken along the same hue path until it reaches 4.5:1.
accents={
    'gold':(245,184,46),'orange':(249,115,22),'red':(239,68,68),
    'purple':(139,92,246),'pink':(236,72,153),'teal':(6,182,212),
    'white':(244,244,245),'gray':(139,139,146),'green':(25,166,84),'blue':(47,124,255)
}
def blend_black(rgb,t): return tuple(round(v*(1-t)) for v in rgb)
for name,base in accents.items():
    candidate=base
    if ratio(candidate,white)<4.5:
        amount=0.08
        while amount<=0.880001:
            candidate=blend_black(base,amount)
            if ratio(candidate,white)>=4.5: break
            amount+=0.05
    r=ratio(candidate,white)
    if r<4.5: raise SystemExit(f'ACCENT_INK_FAIL {name}: {r:.2f}')
    print(f'ACCENT_INK_OK {name}: {r:.2f}:1')
PY

echo BANKMOVIE_V7471_18_LIGHT_THEME_CONTRAST_OK
