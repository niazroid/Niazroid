# BankMovie V7.47.1.11 — TV Drawer Focus Handoff

- رفع قفل شدن DPAD بعد از بستن منوی کناری TV.
- وقتی Drawer باز است، قبل از bootstrapهای Home/Box Office/Profile مالک DPAD است.
- خروج از Drawer دیگر ابتدا Rail را مخفی نمی‌کند؛ ابتدا یک View معتبر داخل Content فوکس می‌گیرد، سپس Drawer بسته می‌شود.
- بعد از بسته‌شدن، فوکس تا سه بار با فاصله کوتاه verify/retry می‌شود تا روی firmwareهایی که currentFocus را موقتاً null می‌کنند قفل ایجاد نشود.
- Sticky UP/DOWN، OK click bridge، ظاهر Profile V7.47.1.10 و سایر اصلاحات قبلی حفظ شده‌اند.
