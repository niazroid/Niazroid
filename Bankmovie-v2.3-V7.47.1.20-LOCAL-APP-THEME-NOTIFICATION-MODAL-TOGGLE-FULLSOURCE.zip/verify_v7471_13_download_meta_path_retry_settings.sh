#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
DL='app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt'
PREF='app/src/main/java/ir/bankmoviee/app/DownloadPreferences.kt'
LOC='app/src/main/java/ir/bankmoviee/app/DownloadLocationPrefs.kt'
SVC='app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt'
SESSION='app/src/main/java/ir/bankmoviee/app/AccountSession.kt'
for f in "$MAIN" "$DL" "$PREF" "$LOC" "$SVC" "$SESSION"; do [[ -f "$f" ]] || { echo "MISSING:$f"; exit 1; }; done

grep -Fq 'private fun normalizedDownloadSize(raw: String): String' "$MAIN"
grep -Fq 'private fun downloadMetaSummary(link: JSONObject): String' "$MAIN"
grep -Fq 'حجم فایل: ${ltr(size)}' "$MAIN"
grep -Fq 'کیفیت: ${ltr(quality)}' "$MAIN"
grep -Fq 'val label = downloadMetaSummary(link)' "$MAIN"

grep -Fq 'private const val KEY_RETRY_ENABLED = "retry_enabled"' "$PREF"
grep -Fq 'fun retryCount(context: Context): Int' "$PREF"
grep -Fq ').coerceIn(1, 20)' "$PREF"
grep -Fq 'fun retryDelaySeconds(context: Context): Int' "$PREF"

grep -Fq 'fun exactPath(context: Context): String' "$LOC"
grep -Fq 'DocumentsContract.getTreeDocumentId(uri)' "$LOC"
grep -Fq 'DownloadLocationPrefs.exactPath(this@DownloadsActivity)' "$DL"
grep -Fq 'text = "بازیابی خطاهای موقت"' "$DL"
grep -Fq 'text = "تعداد تلاش مجدد"' "$DL"
grep -Fq 'max = 19' "$DL"
grep -Fq 'retryCount = (progress + 1).coerceIn(1, 20)' "$DL"
grep -Fq 'retryDelaySeconds' "$DL"
grep -Fq 'retryDelayButtons' "$DL"

grep -Fq 'if (DownloadPreferences.retryEnabled(this)) DownloadPreferences.retryCount(this).coerceIn(1, 20) else 0' "$SVC"
grep -Fq 'DownloadPreferences.retryDelaySeconds(this).coerceIn(2, 300)' "$SVC"
grep -Fq 'val delay = configuredRetryDelaySeconds().toLong().coerceAtMost(300L)' "$SVC"
grep -Fq 'download_retry_count", 4).coerceIn(0, 20)' "$SESSION"

python3 - <<'PY'
from pathlib import Path
main=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
dl=Path('app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt').read_text()
svc=Path('app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt').read_text()
assert 'Regex("(?i)\\\\bfile\\\\s*size' in main, 'download size regex escaping regressed'
assert '"\\u2066$value\\u2069"' in main, 'LTR bidi isolation missing'
assert 'configuredRetryDelaySeconds().toLong() * attempt' not in svc, 'retry delay still multiplies by attempt'
assert 'DownloadPreferences.save(' in dl and 'retryEnabled,' in dl and 'retryCount,' in dl and 'retryDelaySeconds' in dl
print('V7471_13_STRUCTURAL_GUARDS_OK')
PY

bash verify_v7471_12_3_update_versioncode.sh
echo VERIFY_V7471_13_DOWNLOAD_META_PATH_RETRY_SETTINGS_OK
