package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.animation.AccelerateDecelerateInterpolator
import java.lang.ref.WeakReference
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Shared, low-cost shimmer placeholder for posters. All active placeholders use
 * one animator, so a grid does not create dozens of independent animations.
 */
class PosterShimmerDrawable(
    private val reducedMotion: Boolean = false,
    private val lightTheme: Boolean = false
) : Drawable() {

    companion object {
        private val active = CopyOnWriteArrayList<WeakReference<PosterShimmerDrawable>>()
        private var animator: ValueAnimator? = null

        @Synchronized
        private fun ensureAnimator() {
            if (animator?.isRunning == true) return
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1050L
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                interpolator = AccelerateDecelerateInterpolator()
                addUpdateListener { valueAnimator ->
                    val value = valueAnimator.animatedValue as Float
                    val stale = mutableListOf<WeakReference<PosterShimmerDrawable>>()
                    active.forEach { ref ->
                        val drawable = ref.get()
                        if (drawable == null || !drawable.running) {
                            stale += ref
                        } else {
                            drawable.phase = value
                            drawable.invalidateSelf()
                        }
                    }
                    if (stale.isNotEmpty()) active.removeAll(stale.toSet())
                    if (active.isEmpty()) {
                        valueAnimator.cancel()
                        animator = null
                    }
                }
                start()
            }
        }

        @Synchronized
        private fun register(drawable: PosterShimmerDrawable) {
            active.removeAll { it.get() == null || it.get() === drawable }
            active += WeakReference(drawable)
            ensureAnimator()
        }

        @Synchronized
        private fun unregister(drawable: PosterShimmerDrawable) {
            active.removeAll { it.get() == null || it.get() === drawable }
            if (active.isEmpty()) {
                animator?.cancel()
                animator = null
            }
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var phase = 0.15f
    private var drawableAlpha = 255
    private var running = false

    fun start() {
        if (running) return
        running = true
        if (!reducedMotion) register(this) else invalidateSelf()
    }

    fun stop() {
        if (!running) return
        running = false
        unregister(this)
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        if (b.isEmpty) return
        paint.alpha = drawableAlpha
        paint.shader = null
        paint.color = if (lightTheme) Color.rgb(236, 239, 243) else Color.rgb(16, 23, 34)
        canvas.drawRect(b, paint)

        val width = b.width().toFloat().coerceAtLeast(1f)
        val stripe = width * if (reducedMotion) 0.72f else 0.48f
        val center = if (reducedMotion) b.left + width * 0.42f
        else b.left + (width + stripe) * phase - stripe * 0.5f
        paint.shader = LinearGradient(
            center - stripe,
            0f,
            center + stripe,
            0f,
            if (lightTheme) {
                intArrayOf(
                    Color.argb(35, 255, 255, 255),
                    Color.argb(if (reducedMotion) 120 else 205, 255, 255, 255),
                    Color.argb(35, 255, 255, 255)
                )
            } else {
                intArrayOf(
                    Color.argb(18, 255, 255, 255),
                    Color.argb(if (reducedMotion) 38 else 72, 255, 255, 255),
                    Color.argb(18, 255, 255, 255)
                )
            },
            floatArrayOf(0f, 0.5f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawRect(b, paint)
        paint.shader = null
    }

    override fun setAlpha(alpha: Int) {
        drawableAlpha = alpha.coerceIn(0, 255)
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
