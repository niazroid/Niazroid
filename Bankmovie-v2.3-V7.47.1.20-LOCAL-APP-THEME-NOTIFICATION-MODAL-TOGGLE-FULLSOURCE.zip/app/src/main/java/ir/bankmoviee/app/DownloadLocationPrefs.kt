package ir.bankmoviee.app

import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.DocumentsContract
import java.io.File

object DownloadLocationPrefs {
    private const val PREFS = "bankmovie_download_location"
    private const val KEY_MODE = "mode"
    private const val KEY_TREE_URI = "tree_uri"
    private const val KEY_TREE_LABEL = "tree_label"
    private const val KEY_CONFIGURED = "configured"

    const val MODE_APP = "app"
    const val MODE_TREE = "tree"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasChoice(context: Context): Boolean = prefs(context).getBoolean(KEY_CONFIGURED, false)

    fun mode(context: Context): String = prefs(context).getString(KEY_MODE, MODE_APP) ?: MODE_APP

    fun treeUri(context: Context): Uri? {
        val raw = prefs(context).getString(KEY_TREE_URI, "").orEmpty()
        return if (raw.isBlank()) null else runCatching { Uri.parse(raw) }.getOrNull()
    }

    fun setAppFolder(context: Context) {
        prefs(context).edit()
            .putBoolean(KEY_CONFIGURED, true)
            .putString(KEY_MODE, MODE_APP)
            .remove(KEY_TREE_URI)
            .remove(KEY_TREE_LABEL)
            .apply()
    }

    fun setTree(context: Context, uri: Uri) {
        val label = uri.lastPathSegment
            ?.substringAfterLast(':')
            ?.replace("%2F", "/", true)
            ?.ifBlank { "پوشه انتخاب‌شده" }
            ?: "پوشه انتخاب‌شده"
        prefs(context).edit()
            .putBoolean(KEY_CONFIGURED, true)
            .putString(KEY_MODE, MODE_TREE)
            .putString(KEY_TREE_URI, uri.toString())
            .putString(KEY_TREE_LABEL, label)
            .apply()
    }

    fun appFolder(context: Context): File {
        return File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), "Bankmovie").apply { mkdirs() }
    }

    fun displayName(context: Context): String {
        return if (mode(context) == MODE_TREE && treeUri(context) != null) {
            prefs(context).getString(KEY_TREE_LABEL, "پوشه انتخاب‌شده") ?: "پوشه انتخاب‌شده"
        } else {
            "حافظه برنامه / Movies / Bankmovie"
        }
    }

    fun exactPath(context: Context): String {
        if (mode(context) != MODE_TREE || treeUri(context) == null) {
            return appFolder(context).absolutePath
        }
        val uri = treeUri(context) ?: return appFolder(context).absolutePath
        if (uri.authority == "com.android.externalstorage.documents") {
            val documentId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull().orEmpty()
            if (documentId.contains(':')) {
                val volume = documentId.substringBefore(':').trim()
                val relative = documentId.substringAfter(':').trim('/').replace("%2F", "/", true)
                val root = if (volume.equals("primary", true)) "/storage/emulated/0" else "/storage/$volume"
                return if (relative.isBlank()) root else "$root/$relative"
            }
        }
        return uri.toString()
    }
}
