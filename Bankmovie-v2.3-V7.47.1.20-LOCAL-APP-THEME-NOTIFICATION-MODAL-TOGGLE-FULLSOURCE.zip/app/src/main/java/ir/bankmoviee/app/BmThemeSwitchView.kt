package ir.bankmoviee.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.KeyEvent
import android.view.View
import android.view.animation.PathInterpolator
import kotlin.math.cos
import kotlin.math.sin

/**
 * Native BankMovie day/night switch inspired by the supplied Uiverse control.
 * Dark = black sky + moon/stars on the left. Light = blue sky + orange sun/clouds
 * on the right. The control is fully drawn in Canvas so it works on Android/TV
 * without WebView/CSS dependencies.
 */
class BmThemeSwitchView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var progress = 0f // 0 = dark/night, 1 = light/day
    private var animator: ValueAnimator? = null
    private var listener: ((Boolean) -> Unit)? = null

    var dark: Boolean = true
        private set

    init {
        isClickable = true
        isFocusable = true
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        setOnClickListener { setDark(!dark, animate = true, notify = true) }
    }

    fun setOnDarkChangeListener(block: (Boolean) -> Unit) {
        listener = block
    }

    fun setDark(value: Boolean, animate: Boolean = false, notify: Boolean = false) {
        dark = value
        val target = if (value) 0f else 1f
        animator?.cancel()
        if (animate) {
            animator = ValueAnimator.ofFloat(progress, target).apply {
                duration = 420L
                interpolator = PathInterpolator(0.2f, 0.85f, 0.25f, 1f)
                addUpdateListener {
                    progress = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            progress = target
            invalidate()
        }
        contentDescription = if (dark) "تم مشکی" else "تم سفید"
        if (notify) listener?.invoke(dark)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isEnabled && (keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
                keyCode == KeyEvent.KEYCODE_ENTER ||
                keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
                keyCode == KeyEvent.KEYCODE_BUTTON_A ||
                keyCode == KeyEvent.KEYCODE_SPACE)) {
            performClick()
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val radius = h / 2f
        rect.set(0f, 0f, w, h)

        // Black night -> Uiverse-like blue day.
        paint.style = Paint.Style.FILL
        paint.color = blend(Color.rgb(8, 9, 12), Color.rgb(98, 207, 240), progress)
        paint.setShadowLayer(h * 0.035f, 0f, h * 0.02f, Color.argb(60, 0, 0, 0))
        canvas.drawRoundRect(rect, radius, radius, paint)
        paint.clearShadowLayer()

        // Border remains visible in both themes.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = dp(1f)
        paint.color = blend(Color.rgb(75, 78, 84), Color.rgb(69, 139, 158), progress)
        canvas.drawRoundRect(rect, radius, radius, paint)
        paint.style = Paint.Style.FILL

        // Night stars on the right, fade/slide upward as day arrives.
        val starAlpha = ((1f - progress) * 255f).toInt().coerceIn(0, 255)
        paint.color = Color.argb(starAlpha, 255, 255, 255)
        val starOffsetY = -h * 0.80f * progress
        val stars = arrayOf(
            Triple(0.60f, 0.23f, 0.055f),
            Triple(0.78f, 0.52f, 0.042f),
            Triple(0.74f, 0.18f, 0.032f),
            Triple(0.60f, 0.70f, 0.038f),
            Triple(0.43f, 0.12f, 0.027f)
        )
        stars.forEach { (xf, yf, rf) -> drawStar(canvas, w * xf, h * yf + starOffsetY, h * rf, paint) }

        // Day clouds slide in from the left, matching the provided CSS motion.
        val cloudAlpha = (progress * 255f).toInt().coerceIn(0, 255)
        val cloudShift = -w * 0.40f * (1f - progress)
        paint.color = Color.argb(cloudAlpha, 255, 255, 255)
        val cloudBaseX = w * 0.13f + cloudShift
        val cloudBaseY = h * 0.72f
        val cloudR = h * 0.13f
        val cloudData = arrayOf(
            floatArrayOf(0f, -0.16f, 1.00f),
            floatArrayOf(0.12f, 0.05f, 1.18f),
            floatArrayOf(0.25f, 0.22f, 1.08f),
            floatArrayOf(0.39f, 0.15f, 1.00f),
            floatArrayOf(0.52f, 0.26f, 0.92f),
            floatArrayOf(0.66f, 0.18f, 0.88f)
        )
        cloudData.forEach { c ->
            canvas.drawCircle(cloudBaseX + w * c[0], cloudBaseY + h * c[1], cloudR * c[2], paint)
        }

        // Darker rear clouds add depth in day mode.
        paint.color = Color.argb((progress * 92f).toInt().coerceIn(0, 92), 70, 91, 102)
        canvas.drawCircle(cloudBaseX + w * 0.18f, cloudBaseY - h * 0.14f, cloudR * 0.95f, paint)
        canvas.drawCircle(cloudBaseX + w * 0.35f, cloudBaseY + h * 0.04f, cloudR * 1.05f, paint)

        // Knob: moon on left -> orange sun on right.
        val knobR = h * 0.36f
        val leftX = knobR + h * 0.12f
        val rightX = w - knobR - h * 0.12f
        val cx = leftX + (rightX - leftX) * progress
        val cy = h / 2f

        paint.setShadowLayer(h * 0.07f, 0f, h * 0.035f, Color.argb(105, 0, 0, 0))
        paint.color = blend(Color.WHITE, Color.rgb(255, 153, 0), progress)
        canvas.drawCircle(cx, cy, knobR, paint)
        paint.clearShadowLayer()

        // Moon craters fade out during transition to day.
        val craterAlpha = ((1f - progress) * 215f).toInt().coerceIn(0, 215)
        paint.color = Color.argb(craterAlpha, 85, 85, 85)
        canvas.drawCircle(cx - knobR * 0.40f, cy + knobR * 0.25f, knobR * 0.13f, paint)
        canvas.drawCircle(cx - knobR * 0.06f, cy - knobR * 0.11f, knobR * 0.25f, paint)
        canvas.drawCircle(cx + knobR * 0.40f, cy - knobR * 0.36f, knobR * 0.10f, paint)

        // Subtle sun rays appear only in light mode.
        val rayAlpha = (progress * 150f).toInt().coerceIn(0, 150)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = h * 0.035f
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = Color.argb(rayAlpha, 255, 193, 57)
        for (i in 0 until 8) {
            val a = Math.toRadians((i * 45.0))
            val r1 = knobR * 1.08f
            val r2 = knobR * 1.23f
            canvas.drawLine(
                cx + cos(a).toFloat() * r1,
                cy + sin(a).toFloat() * r1,
                cx + cos(a).toFloat() * r2,
                cy + sin(a).toFloat() * r2,
                paint
            )
        }
        paint.style = Paint.Style.FILL
    }

    private fun drawStar(canvas: Canvas, x: Float, y: Float, r: Float, p: Paint) {
        val path = Path()
        path.moveTo(x, y - r)
        path.lineTo(x + r * 0.25f, y - r * 0.25f)
        path.lineTo(x + r, y)
        path.lineTo(x + r * 0.25f, y + r * 0.25f)
        path.lineTo(x, y + r)
        path.lineTo(x - r * 0.25f, y + r * 0.25f)
        path.lineTo(x - r, y)
        path.lineTo(x - r * 0.25f, y - r * 0.25f)
        path.close()
        canvas.drawPath(path, p)
    }

    private fun blend(a: Int, b: Int, t: Float): Int {
        val f = t.coerceIn(0f, 1f)
        return Color.rgb(
            (Color.red(a) + (Color.red(b) - Color.red(a)) * f).toInt(),
            (Color.green(a) + (Color.green(b) - Color.green(a)) * f).toInt(),
            (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * f).toInt()
        )
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
}
