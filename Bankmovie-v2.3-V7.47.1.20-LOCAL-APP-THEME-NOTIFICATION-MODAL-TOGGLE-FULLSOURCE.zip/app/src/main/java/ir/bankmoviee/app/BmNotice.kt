package ir.bankmoviee.app

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

object BmNotice {
    enum class Kind { SUCCESS, INFO, WARNING, ERROR }
    private const val TAG = "bm_notice_overlay"

    fun show(context: Context, message: String, kind: Kind = Kind.INFO, durationMs: Long = 2400L) {
        val activity = context as? Activity
        if (activity == null || activity.isFinishing) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            return
        }
        activity.runOnUiThread {
            val decor = activity.window.decorView as? ViewGroup
            if (decor == null) {
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                return@runOnUiThread
            }
            decor.findViewWithTag<View>(TAG)?.let { decor.removeView(it) }
            val palette = UiPreferences.palette(activity)
            val accent = when (kind) {
                Kind.SUCCESS -> Color.rgb(33, 190, 112)
                Kind.WARNING -> Color.rgb(245, 177, 47)
                Kind.ERROR -> Color.rgb(232, 76, 91)
                Kind.INFO -> palette.primary
            }
            val iconText = when (kind) {
                Kind.SUCCESS -> "✓"
                Kind.WARNING -> "!"
                Kind.ERROR -> "×"
                Kind.INFO -> "i"
            }
            val title = when (kind) {
                Kind.SUCCESS -> "انجام شد"
                Kind.WARNING -> "توجه"
                Kind.ERROR -> "خطا"
                Kind.INFO -> "بانک مووی"
            }
            val row = LinearLayout(activity).apply {
                tag = TAG
                orientation = LinearLayout.HORIZONTAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(activity, 13), dp(activity, 10), dp(activity, 13), dp(activity, 10))
                background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(
                    UiPreferences.blend(palette.panel, accent, if (palette.light) 0.06f else 0.16f),
                    palette.panel
                )).apply {
                    cornerRadius = dp(activity, 22).toFloat()
                    setStroke(dp(activity, 1), Color.argb(155, Color.red(accent), Color.green(accent), Color.blue(accent)))
                }
                elevation = dp(activity, 18).toFloat()
                alpha = 0f
                translationY = dp(activity, 56).toFloat()
            }
            row.addView(TextView(activity).apply {
                text = iconText
                setTextColor(if (UiPreferences.contrastRatio(Color.BLACK, accent) >= UiPreferences.contrastRatio(Color.WHITE, accent)) Color.BLACK else Color.WHITE)
                textSize = 20f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(accent) }
            }, LinearLayout.LayoutParams(dp(activity, 40), dp(activity, 40)).apply { marginEnd = dp(activity, 12) })
            row.addView(LinearLayout(activity).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.RIGHT
                addView(TextView(activity).apply {
                    text = title
                    setTextColor(palette.text)
                    textSize = 12.8f
                    typeface = BankmovieFonts.bold(activity)
                    gravity = Gravity.RIGHT
                })
                addView(TextView(activity).apply {
                    text = message
                    setTextColor(palette.muted)
                    textSize = 11.8f
                    typeface = BankmovieFonts.regular(activity)
                    gravity = Gravity.RIGHT
                    maxLines = 2
                    setPadding(0, dp(activity, 2), 0, 0)
                })
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val params = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM
            ).apply {
                marginStart = dp(activity, 18)
                marginEnd = dp(activity, 18)
                bottomMargin = dp(activity, 102)
            }
            decor.addView(row, params)
            row.animate().alpha(1f).translationY(0f).setDuration(230L)
                .setInterpolator(PathInterpolator(0.16f, 1f, 0.3f, 1f)).start()
            Handler(Looper.getMainLooper()).postDelayed({
                if (row.parent != null) {
                    row.animate().alpha(0f).translationY(dp(activity, 30).toFloat()).setDuration(180L)
                        .setInterpolator(PathInterpolator(0.4f, 0f, 1f, 1f))
                        .withEndAction { (row.parent as? ViewGroup)?.removeView(row) }.start()
                }
            }, durationMs)
        }
    }

    private fun dp(context: Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()
}
