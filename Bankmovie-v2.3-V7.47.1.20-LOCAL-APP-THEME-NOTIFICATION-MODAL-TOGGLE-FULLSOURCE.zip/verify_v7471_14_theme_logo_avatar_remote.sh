#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
UI="$ROOT/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
API="$ROOT/app/src/main/java/ir/bankmoviee/app/AccountApi.kt"
VAULT="$ROOT/app/src/main/java/ir/bankmoviee/app/RuntimeVault.kt"

for f in black blue cyan green orange pink purple red white; do
  test -f "$ROOT/app/src/main/res/drawable-nodpi/bankmovie_logo_dark_${f}.webp"
done

grep -q 'fun brandLogoRes(context: Context)' "$UI"
grep -q 'KEY_SITE_THEME' "$UI"
if ! grep -q 'putString(UiPreferences.KEY_SITE_THEME, siteTheme)' "$API"; then
  grep -q 'Compatibility no-op. Never import website `theme` into KEY_ACCENT' "$API"
  grep -q 'Logo artwork now follows only the locally selected in-app Accent' "$UI"
fi
grep -q 'Visual order mirrors the supplied reference' "$MAIN"
grep -q 'Color.rgb(20, 204, 224)' "$MAIN"
grep -q 'R.drawable.ic_bm_check' "$MAIN"

if grep -R -n 'setImageResource(R.drawable.bankmovie_logo_transparent)' "$ROOT/app/src/main/java"; then
  echo 'FAIL: static full-logo binding remains in Android source' >&2
  exit 1
fi

python3 - "$VAULT" <<'PY'
import re, sys
p=open(sys.argv[1], encoding='utf-8').read()
def d(name):
    arr=[int(x.strip()) for x in re.search(rf'private val {name}Data = intArrayOf\(([^)]*)\)',p).group(1).split(',')]
    seed=int(re.search(rf'private const val {name}Seed = (\d+)',p).group(1))
    return ''.join(chr(v ^ ((seed+i*31+((i*i*7)&0xff))&0xffff)) for i,v in enumerate(arr))
assert d('CONFIG_URL_PRIMARY') == 'https://bankmoviez.top/app_config.php'
assert d('CONFIG_URL_SECONDARY') == 'https://www.bankmoviez.top/app_config.php'
assert d('HOST_SECONDARY') == 'bankmoviez.top'
assert d('HOST_SECONDARY_WWW') == 'www.bankmoviez.top'
print('RuntimeVault controller:', d('CONFIG_URL_PRIMARY'))
PY

echo 'OK: themed logo, avatar sheet and bankmoviez.top controller verified.'
