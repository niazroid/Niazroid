#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
main="$root/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
onboard="$root/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"
ui="$root/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"

for f in "$main" "$onboard" "$ui"; do test -s "$f"; done

grep -q 'text = t("تم برنامه", "App theme")' "$main"
grep -q 'sectionTitle(tr("تم برنامه", "App theme"))' "$onboard"
grep -q '"light" -> SetupPalette(' "$onboard"
grep -q '"light" -> Palette(' "$ui"

# V20 replaces the two flat choice buttons with the requested day/night switch.
if grep -q 'BmThemeSwitchView(this)' "$main"; then
  grep -q 'UiPreferences.saveThemeSelection(this@MainActivity, if (isDark) "black" else "light")' "$main"
  grep -q 'BmThemeSwitchView(this)' "$onboard"
  grep -q 'UiPreferences.saveThemeSelection(this@OnboardingActivity, theme)' "$onboard"
else
  grep -q 'premiumChoice(t("سفید", "Light"), selectedTheme == "light")' "$main"
  grep -q 'premiumChoice(t("مشکی", "Black"), selectedTheme != "light")' "$main"
  grep -Eq 'AccountApi\.updateAppTheme\(this, "light"\)|putString\(UiPreferences\.KEY_THEME, "light"\)' "$main"
  grep -Eq 'AccountApi\.updateAppTheme\(this, "black"\)|putString\(UiPreferences\.KEY_THEME, "black"\)' "$main"
  grep -q 'choice(tr("سفید", "Light"), theme == "light")' "$onboard"
  grep -q 'choice(tr("مشکی", "Black"), theme != "light")' "$onboard"
fi

echo BANKMOVIE_V7471_17_THEME_SELECTOR_SETTINGS_OK
