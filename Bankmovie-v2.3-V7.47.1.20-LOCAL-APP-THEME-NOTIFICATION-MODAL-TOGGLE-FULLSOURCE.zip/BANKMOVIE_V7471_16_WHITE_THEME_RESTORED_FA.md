# BankMovie V7.47.1.16 — بازگشت تم سفید

- تم سفید واقعی و قابل انتخاب دوباره فعال شد.
- پالت روشن با متن اصلی مشکی، متن ثانویه خاکستری و کارت‌های سفید پیاده شد.
- Status/Navigation bar در Light Theme به حالت آیکن تیره می‌رود.
- Glass surfaces اصلی Home/Detail/Drawer/Search/Profile/Downloads با Light Theme هماهنگ شدند.
- Offline Library surfaces برای تم روشن اصلاح شد.
- انتخاب تم داخل تنظیمات ظاهر دوباره فعال شد.
- لوگوی داینامیک نسخه V7.47.1.14 حفظ شده است.
- قابلیت Emergency HTTP/SSL نسخه V7.47.1.15 در این سورس وجود ندارد؛ پایه این نسخه V7.47.1.14 است.
- Player video canvas و overlayهای ضروری پخش برای خوانایی سینمایی عمداً تیره می‌مانند.
