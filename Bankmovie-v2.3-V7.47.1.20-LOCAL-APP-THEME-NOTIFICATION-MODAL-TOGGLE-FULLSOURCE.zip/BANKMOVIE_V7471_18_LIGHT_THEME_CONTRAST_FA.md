# BankMovie V7.47.1.18 — Light Theme Contrast Hardened

این نسخه Light Theme را به‌صورت مستقل از Dark Theme سخت‌گیری می‌کند؛ هدف فقط سفید کردن پس‌زمینه نیست، بلکه جلوگیری از متن/آیکون سفید روی کارت سفید، نشت لایه‌های شفاف Dark و محوشدن Bottom Navigation است.

## تغییرهای اصلی

- پالت روشن مستقل با پس‌زمینه نزدیک سفید، کارت‌های opaque، متن اصلی `#111214` و متن ثانویه خوانا.
- انتخاب `onPrimary` بر اساس مقایسه واقعی contrast سیاه و سفید با Accent انتخابی کاربر.
- سطح‌های Glass در Light Theme دیگر alpha شفاف Dark را استفاده نمی‌کنند.
- Bottom Navigation در Light Theme opaque است؛ آیتم عادی تیره و آیتم فعال با Accent فعلی کاربر نمایش داده می‌شود.
- Detail، کیفیت‌های پخش/دانلود، Synopsis، More Info و اکشن‌ها از foregroundهای semantic استفاده می‌کنند.
- Profile، VIP، Comment UI، Avatar Picker، Watch Party و modalهای اصلی برای Light foreground مستقل دارند.
- Toggle و Notice برای Accentهای خیلی روشن نیز foreground متضاد انتخاب می‌کنند.
- verifier نسخه 18 نسبت کنتراست توکن‌های متن اصلی، ثانویه، tertiary و آیتم غیرفعال Bottom Navigation را عددی بررسی می‌کند.

Heroهای تصویری و خود محیط Player عمداً سینمایی/تیره باقی می‌مانند؛ متن سفید فقط روی همان سطح‌های صریحاً تیره/تصویری استفاده می‌شود.
