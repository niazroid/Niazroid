#!/usr/bin/env bash
set -euo pipefail
BUILD='app/build.gradle'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$BUILD" && -f "$WF" ]] || { echo VERIFY_V7471_12_3_FILES_MISSING; exit 1; }
grep -Fq 'V7.47.1.12.3 UPDATE VERSIONCODE FIX' "$BUILD"
grep -Fq 'BANKMOVIE_VERSION_CODE' "$BUILD"
if grep -Fq 'versionCode 5400000 + runNumber' "$BUILD"; then
  echo VERIFY_V7471_12_3_OLD_RUNNUMBER_VERSIONCODE_PRESENT
  exit 1
fi
grep -Fq 'Set monotonic Android versionCode' "$WF"
grep -Fq 'date -u +%s' "$WF"
grep -Fq 'aapt_bin dump badging' "$WF" || grep -Fq 'dump badging' "$WF"
grep -Fq 'b73994bc2228e91763fde6d049fa792e44bcfce4f1359bef8d0bd6cd6d2f7b39' "$WF"
echo VERIFY_V7471_12_3_UPDATE_VERSIONCODE_OK
