# BankMovie V7.47.1.20 — Local App Theme + Notification Contrast + Modal Handle + Day/Night Toggle

این نسخه ظاهر اپ را به‌طور کامل از تم وب‌سایت/اکانت جدا می‌کند.

- رنگ Accent اپ (آبی، نارنجی، سبز و...) فقط داخل خود اپ ذخیره می‌شود و لاگین/Refresh اکانت آن را از تم سایت بازنویسی نمی‌کند.
- Light/Black نیز فقط روی دستگاه ذخیره می‌شود؛ endpoint قدیمی `app_theme_update` دیگر توسط اپ صدا زده نمی‌شود.
- کلید قدیمی `ui_site_theme_key` در migration پاک می‌شود و لوگو فقط از Accent محلی اپ پیروی می‌کند.
- انتخاب Light/Black در Quick Setup و Settings → Appearance با سوییچ native الهام‌گرفته از Uiverse انجام می‌شود: ماه/ستاره در حالت مشکی و خورشید/ابر در حالت سفید.
- متن بدنه اعلان‌ها و اکشن خطرناک «پاک کردن همه» در Light Theme کنتراست واقعی دارند و alpha متن مهم ۱ است.
- Drag handle تمام Bottom Sheetهای اصلی و مودال‌های Player در Light/Dark واضح‌تر شده است.

این نسخه ادامه‌ی V7.47.1.19 است و اصلاحات Hero edge-to-edge، Light skeleton، Collection و Box Office را حفظ می‌کند.
