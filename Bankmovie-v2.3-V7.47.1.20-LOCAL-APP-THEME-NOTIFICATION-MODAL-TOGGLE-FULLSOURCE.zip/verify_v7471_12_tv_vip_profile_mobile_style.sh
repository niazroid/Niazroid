#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
BUILD='BANKMOVIE_BUILD_SOURCE_2_3.txt'
NOTE='BANKMOVIE_V7471_12_TV_VIP_MOBILE_STYLE_PROFILE_HERO_CLEANUP_FA.md'
[[ -f "$MAIN" && -f "$WF" && -f "$BUILD" && -f "$NOTE" ]] || { echo VERIFY_V7471_12_FILES_MISSING; exit 1; }

# Profile: TV keeps the mobile visual language but does not render the auth poster backdrop.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
start=s.index('private fun showProfileMobileV736()')
end=s.index('private fun showProfile()', start) if 'private fun showProfile()' in s[start:] else s.index('private fun profileActionTile', start)
block=s[start:end]
assert 'if (!isTvLike() && backdropUrl.isNotBlank()) {' in block, 'TV profile hero still renders auth backdrop'
assert 'bm_tv_profile_header_card' in block
assert 'bm_tv_profile_primary' in block
print('V7471_12_PROFILE_TV_HERO_NO_BACKDROP_OK')
PY

# VIP: mobile remains on the mobile renderer; TV carries the same mobile visual vocabulary
# while preserving explicit remote focus tags/routes.
grep -Fq 'showVipPlansMobileV736(vip, initialPlan)' "$MAIN"
grep -Fq 'val featureData = listOf(' "$MAIN"
grep -Fq 'bm_v714_vip_plan_$i' "$MAIN"
grep -Fq 'bm_v714_vip_discount' "$MAIN"
grep -Fq 'bm_v714_vip_purchase' "$MAIN"
grep -Fq 'applyTvFocusHalo(this, 20, 1.03f, 0f)' "$MAIN"
grep -Fq 'mainUpdateV7471_12Hotfix=V7.47.1.12 TV VIP MOBILE LOOK + PROFILE HERO CLEANUP' "$BUILD"
grep -Fq 'ظاهر صفحه خرید اشتراک VIP در تلویزیون' "$NOTE"
# Accept the repaired 12.1 package/workflow as the cumulative successor.
grep -Eq 'Bankmovie-v2\.3-V7\.47\.1\.12(\.[12])?-TV-VIP-MOBILE-STYLE-PROFILE-HERO-CLEANUP(-KOTLIN-HOTFIX)?-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.12\.3-UPDATE-VERSIONCODE-HOTFIX-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.13-DOWNLOAD-META-PATH-RETRY-SETTINGS-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.14-THEME-LOGO-AVATAR-REMOTE-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.16-WHITE-THEME-RESTORED-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.17-WHITE-THEME-SELECTOR-QUICK-APPEARANCE-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.18-LIGHT-THEME-CONTRAST-HARDENED-FULLSOURCE\.zip' "$WF"
echo VERIFY_V7471_12_TV_VIP_PROFILE_MOBILE_STYLE_OK
