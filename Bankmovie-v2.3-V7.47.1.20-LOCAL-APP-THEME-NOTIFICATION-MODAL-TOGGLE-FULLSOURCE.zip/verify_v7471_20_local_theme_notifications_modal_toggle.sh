#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MAIN="$ROOT/app/src/main/java/ir/bankmoviee/app/MainActivity.kt"
UI="$ROOT/app/src/main/java/ir/bankmoviee/app/UiPreferences.kt"
API="$ROOT/app/src/main/java/ir/bankmoviee/app/AccountApi.kt"
APP="$ROOT/app/src/main/java/ir/bankmoviee/app/BankmovieApplication.kt"
ONBOARD="$ROOT/app/src/main/java/ir/bankmoviee/app/OnboardingActivity.kt"
SWITCH="$ROOT/app/src/main/java/ir/bankmoviee/app/BmThemeSwitchView.kt"
PLAYER="$ROOT/app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt"

for f in "$MAIN" "$UI" "$API" "$APP" "$ONBOARD" "$SWITCH" "$PLAYER"; do test -s "$f"; done

# App appearance is local-only; website/account theme data must not overwrite it.
grep -Fq 'KEY_APP_APPEARANCE_LOCAL_V20' "$UI"
grep -Fq 'fun detachAppAppearanceFromWebsite(context: Context)' "$UI"
grep -Fq '.remove(KEY_SITE_THEME)' "$UI"
grep -Fq 'Logo artwork now follows only the locally selected in-app Accent.' "$UI"
grep -Fq 'UiPreferences.detachAppAppearanceFromWebsite(this)' "$APP"
grep -Fq 'Compatibility no-op. Never import website `theme` into KEY_ACCENT.' "$API"
grep -Fq 'App-only Light/Black persistence.' "$API"
if grep -Fq 'putString(UiPreferences.KEY_ACCENT, accent)' "$API"; then
  echo 'FAIL: website theme still writes native Accent' >&2
  exit 1
fi
if grep -Fq 'action = "app_theme_update"' "$API"; then
  echo 'FAIL: native Light/Black mode still calls account theme endpoint' >&2
  exit 1
fi

# Requested Uiverse-style day/night switch is present in Quick Setup and Appearance.
grep -Fq 'class BmThemeSwitchView' "$SWITCH"
grep -Fq '0 = dark/night, 1 = light/day' "$SWITCH"
grep -Fq 'Color.rgb(98, 207, 240)' "$SWITCH"
grep -Fq 'Color.rgb(255, 153, 0)' "$SWITCH"
grep -Fq 'BmThemeSwitchView(this)' "$MAIN"
grep -Fq 'BmThemeSwitchView(this)' "$ONBOARD"
grep -Fq 'UiPreferences.saveThemeSelection(this@MainActivity, if (isDark) "black" else "light")' "$MAIN"
grep -Fq 'UiPreferences.saveThemeSelection(this@OnboardingActivity, theme)' "$ONBOARD"

# Notification content has semantic Light-theme contrast, including dangerous header action.
grep -Fq 'if (notificationPalette.light) Color.rgb(164, 30, 48)' "$MAIN"
grep -Fq 'setTextColor(notificationPalette.faint)' "$MAIN"
grep -Fq 'setTextColor(if (unread) notificationPalette.muted else notificationPalette.faint)' "$MAIN"
grep -Fq 'alpha = 1f' "$MAIN"

# Every mobile bottom-sheet handle is now visible in both Light and Dark themes.
grep -Fq 'private fun sheetDragHandleDrawable(): GradientDrawable' "$MAIN"
grep -Fq 'Color.rgb(139, 144, 153)' "$MAIN"
grep -Fq 'background = sheetDragHandleDrawable()' "$MAIN"
grep -Fq 'modalPalette.light) Color.rgb(139, 144, 153)' "$PLAYER"

# Sanity: old near-invisible handles must not remain in the main modal system.
if grep -Fq 'rounded(Color.argb(105, 235, 239, 246), dp(999), Color.TRANSPARENT)' "$MAIN"; then
  echo 'FAIL: legacy translucent modal handle remains' >&2
  exit 1
fi
if grep -Fq 'rounded(Color.argb(88, 255, 255, 255), dp(999), Color.TRANSPARENT)' "$MAIN"; then
  echo 'FAIL: legacy white-on-light playable-sheet handle remains' >&2
  exit 1
fi

echo BANKMOVIE_V7471_20_LOCAL_THEME_NOTIFICATIONS_MODAL_TOGGLE_OK
