# BankMovie V7.47.1.14 — Theme Logo + Avatar Sheet + Remote Controller

## تغییرات اپ اندروید

- لوگوی BankMovie دیگر ثابت نیست و بر اساس تم/Accent فعال انتخاب می‌شود.
- ۹ لوگوی رسمی تم سایت از `assets/brand/themes` به `drawable-nodpi` اضافه شدند.
- کلید دقیق تم سایت (`dark-green`, `dark-blue`, `dark-purple`, `dark-pink`, `dark-red`, `dark-orange`, `dark-cyan`, `dark-white`, `dark-black`) هنگام Sync حساب ذخیره می‌شود تا حتی دو تم آبی لوگوی درست خودشان را داشته باشند.
- تمام محل‌های نمایش لوگوی کامل در MainActivity و OfflineLibraryActivity به لوگوی Theme-aware متصل شدند.
- تغییر دستی Accent داخل اپ، کلید Theme قدیمی سایت را پاک می‌کند تا لوگو فوراً با انتخاب محلی هماهنگ شود.

## مودال انتخاب آواتار

- Bottom Sheet موبایل مطابق رفرنس بازطراحی شد: پس‌زمینه Navy/Glass، Drag Handle، دکمه بستن گرد، تیتر و توضیح راست‌چین.
- دکمه آپلود VIP با گرادیان Cyan → Blue → Purple و آیکن Plus گرد سفید ساخته شد.
- آواتارها در گرید ۴ ستونه و با ترتیب تصویری رفرنس چیده شدند.
- خود آواتارها به صورت دایره‌ای نمایش داده می‌شوند، کارت‌ها Glass/Navy هستند و آیتم انتخاب‌شده Ring فیروزه‌ای + Badge تیک دارد.
- اندازه سلول‌ها روی موبایل Responsive است و برای TV اندازه بزرگ‌تر و Focus Halo حفظ شده است.

## Remote Controller

- سورس اصلی اپ از قبل روی `https://bankmoviez.top/app_config.php` و `https://www.bankmoviez.top/app_config.php` بود؛ همان ساختار حفظ شد.
- `bankmoviez.top` فقط Controller است و وارد لیست سرور محتوایی/API نمی‌شود.
- در بسته سایت، Default/Fallback مربوط به `controller_domain` از `bankmoviee.ir` به `bankmoviez.top` منتقل شد و فیلد Controller همچنان از پنل مدیریت قابل تغییر است.
- ارجاع‌های `bankmoviee.ir` مربوط به تبلیغات Yektanet/Legacy Site دست‌نخورده ماندند چون Controller اپ نیستند.
