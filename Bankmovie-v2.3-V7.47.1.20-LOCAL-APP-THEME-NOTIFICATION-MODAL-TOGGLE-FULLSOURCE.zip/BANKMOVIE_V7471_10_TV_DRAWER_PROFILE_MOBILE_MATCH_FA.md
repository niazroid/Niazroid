# BankMovie V7.47.1.10

- منوی TV: وقتی Rail باز است، LEFT منو را قطعی می‌بندد و فوکس را به محتوای صفحه برمی‌گرداند؛ حتی اگر فوکس Android TV موقتاً null/stale شود.
- Profile تلویزیون دیگر UI جدا ندارد و همان ساختار Profile موبایل را استفاده می‌کند.
- Hero پروفایل دوباره از `AccountSession.authBackground`، یعنی همان پوستر ورود/ثبت‌نام موبایل، استفاده می‌کند.
- blur آواتار از Hero پروفایل حذف شد.
- آیتم‌های کامل نسخه موبایل (Settings, Downloads, Watch Party, VIP, Notifications, Recent visits و utilityها) روی TV هم وجود دارند.
- فاصله کارت‌های اکشن روی TV بیشتر و ارتفاع کارت‌ها برای فوکس ریموت تنظیم شد.
- Box Office unified UI نسخه قبل بدون تغییر حفظ شد.
