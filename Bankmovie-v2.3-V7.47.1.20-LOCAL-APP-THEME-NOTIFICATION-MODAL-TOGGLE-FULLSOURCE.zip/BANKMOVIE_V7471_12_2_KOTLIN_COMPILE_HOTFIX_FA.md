# BANKMOVIE V7.47.1.12.2 - Kotlin Compile Hotfix

- خطای نوع `planRows` در رندر موبایل VIP رفع شد و دوباره `Pair<LinearLayout, JSONObject>` است.
- `refreshPurchase` در رندر TV قبل از listener تعریف و بعد از ساخته‌شدن دکمه مقداردهی می‌شود تا Kotlin آن را resolve کند.
- ظاهر VIP تلویزیون و حذف بک‌گراند هیروی پروفایل TV از V7.47.1.12 حفظ شده است.
