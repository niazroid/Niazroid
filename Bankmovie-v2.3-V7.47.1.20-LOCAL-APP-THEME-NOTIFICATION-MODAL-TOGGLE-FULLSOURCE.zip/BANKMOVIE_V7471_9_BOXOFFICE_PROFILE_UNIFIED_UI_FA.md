# BankMovie V7.47.1.9 — Box Office + Profile Unified UI

این نسخه روی V7.47.1.8 ساخته شده و فقط ظاهرهای درخواستی را یکدست می‌کند؛ فیکس‌های TV Drawer، Click Bridge، Offline Gallery Focus و Downloader حفظ شده‌اند.

## Box Office
- ظاهر TV از شاخه مستقل بنفش/لیستی خارج شد و از ساختار نسخه موبایل استفاده می‌کند.
- پوستر بزرگ مرکزی، شماره رتبه روی پوستر، عنوان و ردیف‌های Weeks / Weekend Gross / Total Gross در TV نیز همان زبان بصری موبایل را دارند.
- اندازه‌ها برای TV بزرگ‌تر شده‌اند، ولی `bm_v68_boxoffice_item_*`، bootstrap فوکس رتبه 1 و مسیر UP/DOWN قبلی حفظ شده‌اند.

## Profile
- Hero پروفایل موبایل و TV از زبان بصری Hero مشخصات فرد/بازیگر استفاده می‌کند: آواتار بزرگ‌شده و blur شده در پس‌زمینه، fade مشکی و آواتار دایره‌ای واضح روی foreground.
- کارت‌های آماری، اکشن‌های اصلی و utility icons به dark/translucent surfaces با icon bubble دایره‌ای و accent اپ منتقل شدند.
- دکمه‌های ورود، ویرایش آواتار، خروج، VIP و action grid منطق قبلی خود را حفظ کرده‌اند.
- صفحه Profile در TV و موبایل background تیره واحد دارد تا Hero و کارت‌ها یکپارچه دیده شوند.

## Verify
- verifierهای قبلی V7.45.4 تا V7.47.1.8 پاس شدند.
- verifier جدید `verify_v7471_9_boxoffice_profile_unified_ui.sh` اضافه شد.
- YAML، XML و PHP lint پاس شدند.
