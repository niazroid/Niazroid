# BankMovie V7.47.1.19 — Theme Account + Detail Hero + Light Skeleton + Box Office

این نسخه ادامه‌ی V7.47.1.18 است و چهار مشکل گزارش‌شده را یک‌جا اصلاح می‌کند.

## 1) ذخیره تم روی حساب کاربری
- انتخاب Light/Black در اپ ابتدا به‌صورت محلی ذخیره می‌شود و UI فوری عوض می‌شود.
- اگر کاربر لاگین باشد، مقدار `app_theme_mode` با API حساب همگام می‌شود.
- اگر شبکه/سرور در لحظه‌ی تغییر در دسترس نباشد، انتخاب محلی برنمی‌گردد؛ فلگ pending نگه داشته می‌شود تا همگام‌سازی بعدی انجام شود.
- در login/refresh، انتخاب pending محلی نسبت به مقدار قدیمی سرور اولویت دارد تا سایت نتواند تم انتخاب‌شده در اپ را ناخواسته override کند.
- تم رنگی سایت/Accent مستقل باقی مانده و با Light/Black قاطی نشده است.

### تغییر لازم روی سایت
فایل `server-required/app_user_api.php` این نسخه باید روی API سایت Deploy شود. این فایل ستون `app_theme_mode` را به schema کاربران اضافه می‌کند و action جدید `app_theme_update` را ارائه می‌دهد.

## 2) Hero صفحه فیلم و سریال
- فاصله‌ی سفید دو طرف پوستر/Backdrop در موبایل حذف شد و Hero واقعاً edge-to-edge است.
- محتوای پایین همچنان inset استاندارد دارد.
- پایین Hero یک fade نرم چندمرحله‌ای اضافه شد تا انتقال از تصویر به اطلاعات مثل اسلایدر Home طبیعی باشد.

## 3) Skeletonهای Light Theme
- Shimmer/Skeleton دیگر از رنگ Dark در Light استفاده نمی‌کند.
- Detail، poster cards، actor، content rows و fallbackها palette-aware شدند.
- Collection و Collection Items skeleton اختصاصی Grid دارند و دیگر skeleton نامرتبط Detail نمایش داده نمی‌شود.

## 4) Box Office Light Theme
- Background، Card، Border، Text، Metric rows، rank badge و separator برای Light مستقل شدند.
- Skeleton باکس آفیس در Light از card روشن + shimmer روشن استفاده می‌کند.
- Dark Theme قبلی حفظ شده است.

## بررسی‌ها
- verifierهای V7.47.1.4 تا V7.47.1.19 مرتبط اجرا شده‌اند.
- `verify_v7471_19_theme_account_hero_skeleton_boxoffice.sh` پاس شده است.
- `php -l server-required/app_user_api.php` پاس شده است.
- verifier کنتراست V7.47.1.18 همچنان پاس می‌شود.
