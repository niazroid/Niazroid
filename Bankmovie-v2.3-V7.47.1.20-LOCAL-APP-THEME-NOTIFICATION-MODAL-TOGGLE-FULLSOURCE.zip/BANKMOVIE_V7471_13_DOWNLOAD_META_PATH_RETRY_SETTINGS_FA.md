# BankMovie V7.47.1.13 — Download Meta / Exact Path / Retry Settings

## تغییرات
- متن متادیتای مودال دانلود بازنویسی شد تا حجم و کیفیت با فاصله و جهت صحیح نمایش داده شوند؛ مثال: `حجم فایل: 589 MB • کیفیت: 540p`.
- واحدهای رایج حجم مثل `589MB`، `1.5GB`، `مگابایت` و `گیگابایت` قبل از نمایش نرمال می‌شوند.
- مسیر ذخیره‌سازی در تنظیمات دانلود به‌صورت دقیق نمایش داده می‌شود. برای پوشه داخلی برنامه `absolutePath` و برای پوشه انتخاب‌شده SAF تا حد ممکن مسیر `/storage/...` نمایش داده می‌شود؛ در providerهای دیگر URI دقیق نمایش داده می‌شود.
- بخش «بازیابی خطاهای موقت» به تنظیمات Downloader اضافه شد:
  - روشن/خاموش کردن تلاش مجدد خودکار
  - تعداد تلاش قابل تنظیم از 1 تا 20
  - فاصله بین تلاش‌ها قابل انتخاب
- سرویس دانلود از تنظیمات شخصی کاربر برای retry استفاده می‌کند؛ اگر خاموش باشد retry خودکار صفر است.
- فاصله retry همان مقدار انتخاب‌شده کاربر است و دیگر با شماره تلاش ضرب نمی‌شود.
- فوکوس تلویزیون برای کنترل‌های جدید retry حفظ شده است.

## فایل‌های اصلی تغییر یافته
- `app/src/main/java/ir/bankmoviee/app/MainActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadsActivity.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadPreferences.kt`
- `app/src/main/java/ir/bankmoviee/app/DownloadLocationPrefs.kt`
- `app/src/main/java/ir/bankmoviee/app/InternalDownloadService.kt`
- `app/src/main/java/ir/bankmoviee/app/AccountSession.kt`
