# BankMovie V7.47.1.12.3 - Update VersionCode Hotfix

- `versionCode` دیگر از `GITHUB_RUN_NUMBER` ساخته نمی‌شود.
- Workflow در ابتدای هر build یک `BANKMOVIE_VERSION_CODE` صعودی بر اساس Unix epoch seconds می‌سازد.
- همه APKهای خروجی بعد از build با `aapt dump badging` بررسی می‌شوند تا versionCode دقیقاً با مقدار همان release یکی باشد.
- Stable signing key و Signing History Recovery بدون تغییر حفظ شده‌اند.
- هدف این hotfix جلوگیری از `version downgrade` هنگام نصب روی نسخه قبلی است.
