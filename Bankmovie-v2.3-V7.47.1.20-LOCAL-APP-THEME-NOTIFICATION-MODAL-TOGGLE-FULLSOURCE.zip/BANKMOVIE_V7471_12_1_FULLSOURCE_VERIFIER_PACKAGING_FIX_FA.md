# BankMovie V7.47.1.12.1

این هات‌فیکس خطای GitHub Actions نسخه 7.47.1.12 را رفع می‌کند.

علت خطا: فایل `verify_v7471_12_tv_vip_profile_mobile_style.sh` در Patch ساخته شده بود اما داخل FullSOURCE قرار نگرفته بود، در حالی که Workflow آن را اجرا می‌کرد.

اصلاحات:
- verifier نسخه 7.47.1.12 داخل ریشه FullSOURCE قرار گرفت.
- Workflow داخلی و خارجی روی FullSOURCE تعمیرشده 7.47.1.12.1 هماهنگ شدند.
- Signing History Recovery حفظ شد.
- verifierهای cumulative قبلی برای نسخه 7.47.1.12/12.1 سازگار شدند.
