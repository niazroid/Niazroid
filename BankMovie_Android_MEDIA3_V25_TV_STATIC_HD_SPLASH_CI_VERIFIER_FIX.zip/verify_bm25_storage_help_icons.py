#!/usr/bin/env python3
"""Check source-level safety changes. Not an APK or physical-device test."""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent
pkg=root/'app/src/main/java/ir/bankmoviee/app'
main=(pkg/'MainActivity.kt').read_text()
down=(pkg/'DownloadsActivity.kt').read_text()
off=(pkg/'OfflineLibraryActivity.kt').read_text()
storage=(pkg/'BmDeviceStorage.kt').read_text()
block=main.split('val instructions = listOf(',1)[1].split(')\n        instructions.forEachIndexed',1)[0]
assert block.count('            t("') == 6
assert 'پاک کنید' in block and 'Clear Data' in block and 'هشدار' not in block and 'Warning:' not in block
assert 'addView(head, LinearLayout.LayoutParams(-1, -2))' in main
assert 'LinearLayout.LayoutParams(0, -2, 1f)' in main
assert 'BmDeviceStorage.snapshot(this)' in down and 'BmDeviceStorage.snapshot(this)' in off
assert '"فضای دستگاه"' in down and '"فضای دستگاه"' in off
assert 'stats.totalBytes' in storage and 'stats.availableBytes' in storage
assert 'total - available' in storage
assert 'R.drawable.bm_ic_update_download_user' in main
assert 'R.drawable.bm_ic_view_all_left_user' in main
assert 'ic_nav_collection, { dialog.dismiss(); startActivity(Intent(this, OfflineLibraryActivity::class.java))' not in main
for n in ['bm_ic_update_download_user','bm_ic_view_all_left_user','bm_ic_view_all_right_user']:
    ET.parse(root / 'app/src/main/res/drawable' / (n+'.xml'))
assert 'versionName "2.5"' in (root/'app/build.gradle').read_text()
assert "applicationId 'ir.bankmoviee.app'" in (root/'app/build.gradle').read_text()
print('BM25_ROLLBACK_STORAGE_HELP_ICONS_STATIC_OK')

# Kotlin compile-scope regression guard: only sectionHeader declares `palette`;
# legacyTvSectionHeader declares `p` in both branches.
legacy = main.split('private fun legacyTvSectionHeader(', 1)[1].split('\n    private fun ', 1)[0]
assert legacy.count('applyLocalizedViewAllArrow(this)') == 2
assert 'compoundDrawableTintList = android.content.res.ColorStateList.valueOf(palette.text)' not in legacy
