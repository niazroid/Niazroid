import 'package:flutter_test/flutter_test.dart';
import 'package:fl_clash/common/ghost_active_server.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/models/models.dart';

void main() {
  final groups = [
    const Group(
      name: 'GLOBAL',
      type: GroupType.Selector,
      now: 'DIRECT',
      all: [Proxy(name: 'DIRECT', type: 'Direct')],
    ),
    const Group(
      name: 'GohstVpn',
      type: GroupType.Selector,
      all: [
        Proxy(name: '🇩🇪 GER | FAST 2', type: 'Vless'),
        Proxy(name: '🇫🇮 FNL | FAST 1', type: 'Vless'),
      ],
    ),
  ];

  test('dashboard prefers the selected subscription node over GLOBAL DIRECT', () {
    const profile = Profile(
      id: 1,
      autoUpdateDuration: Duration(hours: 1),
      currentGroupName: 'GLOBAL',
      selectedMap: {'GLOBAL': 'DIRECT', 'GohstVpn': '🇩🇪 GER | FAST 2'},
    );
    final selected = resolveGhostActiveServer(groups, profile);
    expect(selected?.group.name, 'GohstVpn');
    expect(selected?.proxy.name, '🇩🇪 GER | FAST 2');
  });

  test('no fake connection when only DIRECT is selected', () {
    const profile = Profile(
      id: 2,
      autoUpdateDuration: Duration(hours: 1),
      selectedMap: {'GLOBAL': 'DIRECT', 'GohstVpn': 'DIRECT'},
    );
    expect(resolveGhostActiveServer(groups, profile), isNull);
  });
}
