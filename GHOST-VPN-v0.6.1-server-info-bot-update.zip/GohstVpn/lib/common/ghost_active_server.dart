import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/models/models.dart';

/// The selected *subscription node*, not the GLOBAL/DIRECT routing policy.
/// Both Home and the subscription-refresh toast use this resolver so a node
/// selected in Servers is displayed/tested consistently in Home.
typedef GhostActiveServer = ({Group group, Proxy proxy});

const _notNodes = <String>{
  'DIRECT', 'REJECT', 'REJECT-DROP', 'PASS', 'COMPATIBLE',
};

GhostActiveServer? resolveGhostActiveServer(
  List<Group> groups,
  Profile? profile,
) {
  if (profile == null) return null;

  final selectors = groups.where((group) =>
      group.type == GroupType.Selector &&
      group.name.toUpperCase() != 'GLOBAL').toList();
  final preferred = <Group>[
    ...selectors.where((group) => group.name == profile.currentGroupName),
    ...selectors.where((group) => profile.selectedMap.containsKey(group.name)),
    ...selectors,
  ];
  final checked = <String>{};

  for (final group in preferred) {
    if (!checked.add(group.name)) continue;
    final selected = group.getCurrentSelectedName(
      profile.selectedMap[group.name] ?? '',
    );
    if (selected.isEmpty) continue;
    final actual = computeRealSelectedProxyState(
      selected,
      groups: groups,
      selectedMap: profile.selectedMap,
    ).proxyName;
    if (actual.isEmpty || _notNodes.contains(actual.toUpperCase())) continue;

    // Real node must actually exist in the core groups; don't show a selector
    // name, a placeholder or a guessed country as a connected endpoint.
    final node = groups
        .expand((candidate) => candidate.all)
        .where((proxy) => proxy.name == actual &&
            !_notNodes.contains(proxy.name.toUpperCase()) &&
            !{'select', 'selector', 'url-test', 'fallback', 'load-balance'}
                .contains(proxy.type.toLowerCase()))
        .firstOrNull;
    if (node != null) return (group: group, proxy: node);
  }
  return null;
}
