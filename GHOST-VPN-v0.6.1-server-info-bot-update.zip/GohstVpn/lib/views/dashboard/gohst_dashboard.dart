import 'dart:async';
import 'package:flutter/material.dart' as m;
import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/common/gohst_display_name.dart';
import 'package:fl_clash/common/gohst_subscription_notice.dart';
import 'package:fl_clash/common/ghost_purchase_bot.dart';
import 'package:fl_clash/common/ghost_active_server.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/models/models.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/widgets/widgets.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_svg/flutter_svg.dart';

class GohstDashboardView extends ConsumerStatefulWidget {
  const GohstDashboardView({super.key});

  @override
  ConsumerState<GohstDashboardView> createState() => _GohstDashboardState();
}

class _GohstDashboardState extends ConsumerState<GohstDashboardView> {
  Timer? _pingTimer;
  bool _testingSelected = false;
  bool _refreshingProfile = false;
  DateTime? _lastPingChecked;
  String? _lastPingNode;

  @override
  void initState() {
    super.initState();
    _pingTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      unawaited(_checkCurrentServerPing());
    });
  }

  @override
  void dispose() {
    _pingTimer?.cancel();
    super.dispose();
  }

  Future<void> _checkCurrentServerPing() async {
    if (!mounted || _testingSelected || !ref.read(isStartProvider)) {
      return;
    }
    final active = resolveGhostActiveServer(
      ref.read(groupsProvider), ref.read(currentProfileProvider),
    );
    if (active == null) return;
    final actual = active.proxy.name;
    if (_lastPingNode != actual) {
      _lastPingChecked = null;
    }
    ref.read(delayDataSourceProvider.notifier).clearNodeDelays([actual]);
    setState(() {
      _lastPingChecked = null;
      _lastPingNode = actual;
      _testingSelected = true;
    });
    try {
      await ref.read(proxiesActionProvider.notifier).proxyDelayTest(active.proxy, active.group.testUrl);
      if (mounted) {
        setState(() => _lastPingChecked = DateTime.now());
      }
    } catch (_) {
      // A failed test is not a successful latency sample.
      if (mounted) {
        setState(() => _lastPingChecked = DateTime.now());
      }
    } finally {
      if (mounted) {
        setState(() => _testingSelected = false);
      }
    }
  }

  Future<void> _refreshProfile() async {
    if (_refreshingProfile) {
      return;
    }
    final profile = ref.read(currentProfileProvider);
    if (profile == null || profile.type == ProfileType.file) {
      return;
    }
    setState(() => _refreshingProfile = true);
    try {
      await ref.read(profilesActionProvider.notifier).updateProfile(profile, showLoading: true);
      if (mounted) {
        final active = resolveGhostActiveServer(
          ref.read(groupsProvider), ref.read(currentProfileProvider),
        );
        if (active != null) {
          await ref.read(proxiesActionProvider.notifier)
              .delayTestGroups([active.group]);
        }
      }
    } catch (error) {
      if (mounted) {
        m.ScaffoldMessenger.of(context).showSnackBar(m.SnackBar(
          content: Text(_label(context, 'به‌روزرسانی اشتراک ناموفق بود', 'Subscription refresh failed')),
        ));
      }
    } finally {
      if (mounted) {
        setState(() => _refreshingProfile = false);
      }
    }
  }

  String _label(BuildContext context, String fa, String en) =>
      Localizations.localeOf(context).languageCode == 'fa' ? fa : en;

  void _open(WidgetRef ref, PageLabel page) {
    ref.read(currentPageLabelProvider.notifier).toPage(page);
  }

  String _countryName(String rawName) {
    final normalized = gohstDisplayName(rawName);
    final flags = normalized.runes.where((r) => r >= 0x1F1E6 && r <= 0x1F1FF).take(2).toList();
    if (flags.length != 2) {
      final lower = normalized.toLowerCase();
      const countryTerms = {
        'finland': 'Finland', 'germany': 'Germany', 'turkey': 'Turkey',
        'france': 'France', 'netherlands': 'Netherlands', 'latvia': 'Latvia',
        'united states': 'United States', 'canada': 'Canada', 'singapore': 'Singapore',
      };
      for (final term in countryTerms.entries) {
        if (lower.contains(term.key)) {
          return term.value;
        }
      }
      return '—';
    }
    final code = String.fromCharCodes(flags.map((r) => r - 0x1F1E6 + 65));
    const countries = {
      'FI': 'Finland', 'DE': 'Germany', 'TR': 'Turkey',
      'FR': 'France', 'NL': 'Netherlands', 'US': 'United States',
      'GB': 'United Kingdom', 'CA': 'Canada', 'LV': 'Latvia',
      'SE': 'Sweden', 'SG': 'Singapore', 'AE': 'UAE',
    };
    return countries[code] ?? code;
  }

  Widget _metric(BuildContext context, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: ShapeDecoration(
          color: context.colorScheme.surfaceContainerHighest,
          shape: AppShape.lg,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: context.textTheme.labelMedium),
            const SizedBox(height: 6),
            Text(
              value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: context.textTheme.titleMedium?.toSoftBold,
            ),
          ],
        ),
      ),
    );
  }

  Widget _subscriptionMetric(BuildContext context, {required String label,
      required double? value, required String suffix, required m.IconData icon,
      required String unknown}) {
    return Expanded(child: m.Container(
      padding: const m.EdgeInsets.all(13),
      decoration: m.BoxDecoration(
        color: context.colorScheme.surfaceContainerHigh,
        borderRadius: m.BorderRadius.circular(18),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        m.Icon(icon, size: 20, color: context.colorScheme.primary),
        const SizedBox(height: 8),
        Text(label, style: context.textTheme.labelMedium),
        const SizedBox(height: 6),
        if (value == null)
          Text(unknown, style: context.textTheme.titleMedium?.toSoftBold)
        else
          m.TweenAnimationBuilder<double>(
            tween: m.Tween<double>(begin: 0, end: value),
            duration: const Duration(milliseconds: 950),
            curve: m.Curves.easeOutCubic,
            builder: (context, count, _) => Text(
              suffix == 'GB' ? '${count.toStringAsFixed(1)} GB'
                  : '${count.round()} $suffix',
              style: context.textTheme.titleLarge?.toSoftBold,
              maxLines: 1, overflow: TextOverflow.ellipsis,
            ),
          ),
      ]),
    ));
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<bool>(isStartProvider, (previous, next) {
      if (next && previous != next) {
        // Test the newly connected server rather than displaying a cached ping.
        m.WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) {
            unawaited(_checkCurrentServerPing());
          }
        });
      }
    });
    GohstSubscriptionNotice.instance.ensureLoaded();
    final profile = ref.watch(currentProfileProvider);
    final isStarted = ref.watch(isStartProvider);
    final isSuspended = ref.watch(suspendProvider);
    // The GLOBAL selector can resolve to DIRECT even when the user's
    // subscription group has an explicitly selected VLESS node. Reuse the
    // same source of truth as Servers for the name, country and ping.
    final groups = ref.watch(groupsProvider);
    final selectedMap = ref.watch(selectedMapProvider);
    final selectedProfile = profile?.copyWith(selectedMap: selectedMap);
    final active = resolveGhostActiveServer(groups, selectedProfile);
    final selectedNode = active?.proxy.name;
    final selectedTestUrl = active?.group.testUrl;
    final isDirectMode = ref.watch(
      patchClashConfigProvider.select((config) => config.mode == Mode.direct),
    );
    final info = profile?.subscriptionInfo;
    final used = (info?.upload ?? 0) + (info?.download ?? 0);
    final total = info?.total ?? 0;
    final hasTraffic = total > 0;
    final int? remaining = hasTraffic ? (total > used ? total - used : 0) : null;
    final expire = info?.expire ?? 0;
    final daysLeft = expire > 0
        ? ((DateTime.fromMillisecondsSinceEpoch(expire * 1000)
                        .difference(DateTime.now())
                        .inHours +
                    23) ~/
                24)
            .clamp(0, 999999)
        : null;
    final bool dataExhausted = hasTraffic && remaining == 0;
    final bool daysExpired = daysLeft != null && daysLeft == 0;
    final bool dataLow = hasTraffic && remaining != null && (remaining / total <= 0.10);
    final bool daysLow = daysLeft != null && daysLeft <= 5;
    final bool subscriptionUrgent = dataExhausted || daysExpired;
    final bool subscriptionWarn = subscriptionUrgent || dataLow || daysLow;
    final connectedText = isStarted
        ? (isSuspended
              ? _label(context, 'اتصال موقتاً متوقف است', 'Connection suspended')
              : _label(context, 'متصل', 'Connected'))
        : _label(context, 'قطع', 'Disconnected');

    return CommonScaffold(
      title: 'GHOST VPN',
      body: ListView(
        padding: EdgeInsets.fromLTRB(
          16,
          20 + context.appBarInset,
          16,
          28 + BottomInsetScope.of(context),
        ),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 22),
              child: Column(
                children: [
                  m.Image.asset('assets/images/ghost_brand_logo.png',
                    height: 114, fit: m.BoxFit.contain,
                    semanticLabel: 'GHOST VPN'),
                  const SizedBox(height: 8),
                  GohstConnectionToggle(
                    connected: isStarted,
                    enabled: profile != null,
                    onToggle: () => ref.read(commonActionProvider.notifier).toggleRunning(),
                  ),
                  const SizedBox(height: 12),
                  Text(connectedText, style: context.textTheme.headlineSmall?.toSoftBold),
                  const SizedBox(height: 16),
                  m.InkWell(
                    onTap: () => _open(ref, PageLabel.proxies),
                    borderRadius: m.BorderRadius.circular(16),
                    child: m.Container(
                      width: double.infinity,
                      padding: const m.EdgeInsets.all(14),
                      decoration: m.BoxDecoration(
                        color: context.colorScheme.surfaceContainerHigh,
                        borderRadius: m.BorderRadius.circular(16),
                      ),
                      child: Row(children: [
                        m.Icon(m.Icons.public_outlined, color: context.colorScheme.primary),
                        const SizedBox(width: 10),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_label(context, 'سرور انتخاب‌شده', 'Selected server'), style: context.textTheme.labelSmall),
                            const SizedBox(height: 4),
                            Text(selectedNode == null
                                ? _label(context, 'برای انتخاب سرور لمس کنید', 'Tap to choose a server')
                                : gohstDisplayName(selectedNode),
                              maxLines: 2, overflow: TextOverflow.ellipsis,
                              style: context.textTheme.titleMedium?.toSoftBold),
                            if (selectedNode != null) ...[
                              const SizedBox(height: 5),
                              Text(_countryName(selectedNode) == '—'
                                  ? _label(context, 'کشور نامشخص', 'Country unknown')
                                  : _countryName(selectedNode), style: context.textTheme.bodySmall),
                            ],
                          ],
                        )),
                        const m.Icon(m.Icons.chevron_right),
                      ]),
                    ),
                  ),
                  if (isDirectMode && isStarted) ...[
                    const SizedBox(height: 6),
                    Text(_label(context,
                      'توجه: حالت مسیریابی Direct فعال است؛ نمایش سرور به معنی عبور ترافیک از آن نیست.',
                      'Direct routing mode is enabled; the selected server may not carry traffic.'),
                      style: context.textTheme.bodySmall),
                  ],
                  const SizedBox(height: 10),
                  Row(children: [
                    m.Icon(m.Icons.speed_outlined, size: 17, color: context.colorScheme.primary),
                    const SizedBox(width: 6),
                    Builder(builder: (context) {
                      final delay = selectedNode == null ? null : ref.watch(delayProvider(proxyName: selectedNode, testUrl: selectedTestUrl));
                      final status = selectedNode == null
                          ? '--'
                          : _testingSelected ? _label(context, 'در حال تست...', 'Testing...')
                          : delay == null ? (_lastPingChecked != null && _lastPingNode == selectedNode
                              ? 'Timeout' : _label(context, 'هنوز تست نشده', 'Not tested'))
                          : delay > 0 ? '$delay ms' : 'Timeout';
                      return Text('${_label(context, 'پینگ', 'Ping')}: $status',
                          style: context.textTheme.bodyMedium);
                    }),
                    const Spacer(),
                    if (_lastPingChecked != null && _lastPingNode == selectedNode)
                      Text(_label(context, 'تست اخیر', 'Latest test'), style: context.textTheme.labelSmall),
                    m.IconButton(
                      tooltip: _label(context, 'تست دوباره پینگ', 'Retest ping'),
                      onPressed: _testingSelected || selectedNode == null
                          ? null : _checkCurrentServerPing,
                      icon: const m.Icon(m.Icons.refresh, size: 19),
                    ),
                  ]),
                  const SizedBox(height: 8),
                  Builder(builder: (context) {
                    final sample = ref.watch(trafficsProvider).list.safeLast(const Traffic());
                    return Row(children: [
                      _metric(context, _label(context, 'دانلود ↓', 'Download ↓'),
                          isStarted ? '${sample.down.traffic.show}/s' : '0 B/s'),
                      const SizedBox(width: 10),
                      _metric(context, _label(context, 'آپلود ↑', 'Upload ↑'),
                          isStarted ? '${sample.up.traffic.show}/s' : '0 B/s'),
                    ]);
                  }),
                  const SizedBox(height: 14),
                  const GohstSmartConnect(),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          _label(context, 'اشتراک من', 'My subscription'),
                          style: context.textTheme.titleMedium?.toSoftBold,
                        ),
                      ),
                      m.IconButton(
                        tooltip: _label(context, 'به‌روزرسانی اشتراک', 'Refresh subscription'),
                        onPressed: _refreshingProfile || profile == null ? null : _refreshProfile,
                        icon: _refreshingProfile
                            ? const m.SizedBox(width: 22, height: 22, child: m.CircularProgressIndicator(strokeWidth: 2))
                            : SvgPicture.asset('assets/images/gohst_refresh.svg',
                                width: 22, height: 22,
                                colorFilter: m.ColorFilter.mode(context.colorScheme.primary, m.BlendMode.srcIn)),
                      ),
                      TextButton(
                        onPressed: () => _open(ref, PageLabel.profiles),
                        child: Text(_label(context, 'مدیریت', 'Manage')),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _subscriptionMetric(context,
                        label: _label(context, 'حجم باقی‌مانده', 'Remaining data'),
                        value: remaining == null ? null : remaining / (1024 * 1024 * 1024),
                        suffix: 'GB', icon: m.Icons.data_usage_outlined,
                        unknown: _label(context, 'نامشخص', 'Unknown')),
                      const SizedBox(width: 10),
                      _subscriptionMetric(context,
                        label: _label(context, 'روز باقی‌مانده', 'Days left'),
                        value: daysLeft?.toDouble(), suffix: _label(context, 'روز', 'days'),
                        icon: m.Icons.event_available_outlined,
                        unknown: _label(context, 'نامشخص', 'Unknown')),
                    ],
                  ),
                  if (subscriptionWarn) ...[
                    const SizedBox(height: 12),
                    m.Container(
                      width: double.infinity,
                      padding: const m.EdgeInsets.all(14),
                      decoration: m.BoxDecoration(
                        color: subscriptionUrgent ? const m.Color(0xFF401519) : const m.Color(0xFF3C2915),
                        borderRadius: m.BorderRadius.circular(16),
                        border: m.Border.all(color: subscriptionUrgent
                          ? const m.Color(0xFFEF4444) : const m.Color(0xFFFFB65B)),
                      ),
                      child: m.Column(crossAxisAlignment: m.CrossAxisAlignment.start, children: [
                        m.Row(children: [
                          m.Icon(subscriptionUrgent ? m.Icons.error_outline : m.Icons.notifications_active_outlined,
                            color: subscriptionUrgent ? const m.Color(0xFFFF9090) : const m.Color(0xFFFFCC76)),
                          const SizedBox(width: 8),
                          m.Expanded(child: m.Text(subscriptionUrgent
                            ? _label(context, 'اشتراک شما به پایان رسیده', 'Your subscription has expired')
                            : _label(context, 'اشتراک شما رو به اتمام است', 'Your subscription is running low'),
                            style: const m.TextStyle(fontWeight: m.FontWeight.w700, color: m.Colors.white))),
                        ]),
                        const SizedBox(height: 9),
                        m.Text(
                          [
                            if (daysLeft != null) _label(context, '$daysLeft روز باقی مانده', '$daysLeft days left'),
                            if (remaining != null) _label(context,
                              '${(remaining / (1024*1024*1024)).toStringAsFixed(1)} گیگابایت باقی مانده',
                              '${(remaining / (1024*1024*1024)).toStringAsFixed(1)} GB left'),
                          ].join(' · '),
                          style: const m.TextStyle(color: m.Color(0xFFF5DADA))),
                        const SizedBox(height: 12),
                        GhostTelegramPurchaseButton(label: _label(context,
                          'خرید از ربات تلگرام', 'Buy via Telegram bot')),
                      ]),
                    ),
                  ],
                  if (hasTraffic) ...[
                    const SizedBox(height: 14),
                    m.TweenAnimationBuilder<double>(
                      tween: m.Tween<double>(begin: 0, end: (used / total).clamp(0, 1).toDouble()),
                      duration: const Duration(milliseconds: 1100),
                      curve: m.Curves.easeOutCubic,
                      builder: (context, progress, _) => m.ClipRRect(
                        borderRadius: m.BorderRadius.circular(8),
                        child: m.LinearProgressIndicator(
                          value: progress,
                          minHeight: 9,
                          backgroundColor: context.colorScheme.surfaceContainerHighest,
                        ),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      '${_label(context, 'مصرف شده', 'Used')}: ${used.traffic.show} / ${total.traffic.show}',
                      style: context.textTheme.bodySmall,
                    ),
                  ] else ...[
                    const SizedBox(height: 12),
                    Text(
                      _label(
                        context,
                        'نمایش حجم و انقضا به اطلاعات ارسالی سرویس‌دهنده بستگی دارد.',
                        'Data and expiry require subscription metadata from your provider.',
                      ),
                      style: context.textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ),
          ValueListenableBuilder<Map<int, String>>(
            valueListenable: GohstSubscriptionNotice.instance.notices,
            builder: (context, notices, _) {
              final notice = profile == null ? null : notices[profile.id];
              if (notice == null || notice.isEmpty) {
                return const SizedBox.shrink();
              }
              return Padding(
                padding: const EdgeInsets.only(top: 14),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        m.Icon(m.Icons.campaign_outlined, color: context.colorScheme.primary),
                        const SizedBox(width: 12),
                        Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_label(context, 'اطلاعیه اشتراک', 'Subscription notice'),
                              style: context.textTheme.titleSmall?.toSoftBold),
                            const SizedBox(height: 6),
                            SelectableText(notice, style: context.textTheme.bodyMedium),
                          ],
                        )),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

/// Holographic sliding switch inspired by the user-supplied CSS. Implemented
/// in Flutter so it controls the real VPN state and supports accessibility.
class GohstConnectionToggle extends StatelessWidget {
  const GohstConnectionToggle({
    super.key,
    required this.connected,
    required this.enabled,
    required this.onToggle,
  });

  final bool connected;
  final bool enabled;
  final VoidCallback onToggle;

  @override
  Widget build(BuildContext context) {
    final accent = context.colorScheme.primary;
    return m.Semantics(
      label: connected ? 'Disconnect VPN' : 'Connect VPN',
      button: true,
      toggled: connected,
      enabled: enabled,
      child: m.Opacity(
        opacity: enabled ? 1 : 0.4,
        child: m.InkWell(
          borderRadius: m.BorderRadius.circular(40),
          onTap: enabled ? onToggle : null,
          child: m.AnimatedContainer(
            duration: const Duration(milliseconds: 360),
            curve: m.Curves.easeOutCubic,
            width: 174,
            height: 62,
            padding: const EdgeInsets.all(5),
            decoration: m.BoxDecoration(
              borderRadius: m.BorderRadius.circular(35),
              gradient: m.LinearGradient(colors: [
                context.colorScheme.surfaceContainerHighest,
                context.colorScheme.surfaceContainerLow,
              ]),
              border: m.Border.all(color: connected ? accent : context.colorScheme.outlineVariant, width: 1.5),
              boxShadow: connected
                  ? [m.BoxShadow(color: accent.withValues(alpha: 0.24), blurRadius: 16)]
                  : null,
            ),
            child: m.Stack(children: [
              m.Align(
                alignment: connected ? m.Alignment.centerLeft : m.Alignment.centerRight,
                child: m.Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 19),
                  child: m.Text(connected ? 'ON' : 'OFF',
                      style: m.TextStyle(color: connected ? accent : context.colorScheme.onSurfaceVariant,
                          fontSize: 12, fontWeight: m.FontWeight.bold, letterSpacing: 2)),
                ),
              ),
              m.AnimatedAlign(
                duration: const Duration(milliseconds: 360),
                curve: m.Curves.easeOutCubic,
                alignment: connected ? m.Alignment.centerRight : m.Alignment.centerLeft,
                child: m.Container(
                  height: 50,
                  width: 50,
                  decoration: m.BoxDecoration(
                    shape: m.BoxShape.circle,
                    gradient: m.RadialGradient(colors: connected
                        ? [accent.withValues(alpha: 0.9), accent]
                        : [const m.Color(0xFF35383C), const m.Color(0xFF17191D)]),
                    boxShadow: [m.BoxShadow(color: connected
                        ? accent.withValues(alpha: 0.35)
                        : const m.Color(0x44000000), blurRadius: 10)],
                  ),
                  child: m.Icon(connected ? m.Icons.shield_outlined : m.Icons.power_settings_new,
                      color: m.Colors.white, size: 24),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

/// Performs a *real* URL delay test, discards failed/timeout results, then
/// changes only a user-selectable group. No fabricated ping measurements.
class GohstSmartConnect extends ConsumerStatefulWidget {
  const GohstSmartConnect({super.key});

  @override
  ConsumerState<GohstSmartConnect> createState() => _GohstSmartConnectState();
}

class _GohstSmartConnectState extends ConsumerState<GohstSmartConnect> {
  bool _running = false;

  Future<void> _chooseBest() async {
    if (_running) {
      return;
    }
    setState(() => _running = true);
    try {
      final selectableGroups = ref.read(groupsProvider)
          .where((g) => g.type == GroupType.Selector && g.all.any((p) => _usable(p)))
          .toList();
      if (selectableGroups.isEmpty) {
        throw StateError('No selectable server groups');
      }
      // Use the primary selector, not GLOBAL or rule-created nested groups.
      final group = selectableGroups.firstWhere(
        (g) => g.name != 'GLOBAL',
        orElse: () => selectableGroups.first,
      );
      ref.read(delayDataSourceProvider.notifier)
          .clearNodeDelays(group.all.map((p) => p.name));
      await ref.read(proxiesActionProvider.notifier).delayTestGroups([group]);
      final allDelays = ref.read(delayDataSourceProvider);
      Proxy? winner;
      int? minDelay;
      for (final proxy in group.all) {
        if (!_usable(proxy)) {
          continue;
        }
        int? delay;
        for (final values in allDelays.values) {
          final value = values[proxy.name];
          if (value != null && value > 0 && (delay == null || value < delay)) {
            delay = value;
          }
        }
        if (delay != null && (minDelay == null || delay < minDelay)) {
          minDelay = delay;
          winner = proxy;
        }
      }
      if (winner == null) {
        throw StateError('All tested servers timed out');
      }
      await ref.read(proxiesActionProvider.notifier).changeProxy(
        groupName: group.name, proxyName: winner.name,
      );
      if (ref.read(currentProfileProvider)?.selectedMap[group.name] != winner.name) {
        throw StateError('Server selection was not accepted by the core');
      }
      if (!ref.read(isStartProvider)) {
        ref.read(commonActionProvider.notifier).toggleRunning();
      }
      if (mounted) {
        m.ScaffoldMessenger.of(context).showSnackBar(m.SnackBar(
          content: Text('${gohstDisplayName(winner.name)} · $minDelay ms'),
        ));
      }
    } catch (error) {
      if (mounted) {
        m.ScaffoldMessenger.of(context).showSnackBar(m.SnackBar(
          content: Text('Smart Connect: $error'),
        ));
      }
    } finally {
      if (mounted) {
        setState(() => _running = false);
      }
    }
  }

  bool _usable(Proxy p) =>
      !{'DIRECT', 'REJECT', 'REJECT-DROP', 'COMPATIBLE', 'PASS'}.contains(p.name.toUpperCase()) &&
      !{'direct', 'reject', 'selector', 'url-test', 'fallback', 'load-balance'}.contains(p.type.toLowerCase());

  @override
  Widget build(BuildContext context) => m.OutlinedButton.icon(
    onPressed: _running ? null : _chooseBest,
    icon: _running
        ? const m.SizedBox(width: 16, height: 16, child: m.CircularProgressIndicator(strokeWidth: 2))
        : const m.Icon(m.Icons.auto_awesome_outlined, size: 18),
    label: Text(_running ? 'Testing...' : 'Smart Connect'),
  );
}
