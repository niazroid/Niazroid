# BankMovie Desktop 1.9.0

- همگام‌سازی زنده Download Manager با Main Process؛ پیشرفت، سرعت، ETA، Pause/Resume/Cancel بدون خروج و ورود مجدد صفحه.
- حذف repaint دوبل progress event و حفظ scroll صفحه دانلودها.
- اعلان Windows برای شروع، تکمیل، لغو و توقف دانلود.
- تفکیک فیلم و سریال، پوستر، فصل/قسمت، بازکردن فایل و نمایش پوشه.
- ثبت دیدگاه به‌صورت optimistic؛ رابط کاربری منتظر پاسخ کند سرور نمی‌ماند و دریافت دیدگاه‌ها در پس‌زمینه انجام می‌شود.
- پنجره Trailer با reference پایدار و focus اجباری تا حالت «فقط صدا» رخ ندهد.
- سازگار با Desktop Gateway 1.9.0 برای Archive 4 / Cinamatic و policy مشترک VIP سایت.
- بدون App Key/Secret ثابت در کلاینت.
