# BankMovie Desktop 1.9.1

- افزودن زبان English و فارسی با جهت RTL/LTR و ذخیره در تنظیمات.
- انتقال کنترل زبان و تم ماه/خورشید به Settings.
- انتخاب پلیر دستی + Auto (Recommended) بر اساس تشخیص PotPlayer/VLC/KMPlayer.
- استفاده از CTA دانلود متحرک، آیکن‌های Pause/Resume/Delete و نشان تکمیل.
- بازطراحی Like/Dislike دیدگاه‌ها.
- حذف آدرس‌های API/دامنه از Settings.
- حذف آیتم دانلود از لیست به‌صورت لحظه‌ای بدون حذف فایل تکمیل‌شده.
