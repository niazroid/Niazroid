package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PLAYLIST_FILE = "playlist_file"
        const val EXTRA_PROGRESS_KEY = "progress_key"
        const val EXTRA_RESUME_POSITION = "resume_position"
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue: Int get() = UiPreferences.accentColor(this)
    private val blue2: Int get() = UiPreferences.blend(blue, Color.WHITE, 0.28f)
    private val blue3: Int get() = Color.argb(170, Color.red(blue), Color.green(blue), Color.blue(blue))
    private val panel = Color.argb(230, 12, 12, 14)
    private val stroke = Color.argb(115, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(190, 192, 202)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private var requestedResumePosition = 0L
    private var resumeTarget = 0L
    private var resumeGuardUntil = 0L
    private var seekJumpMs = 10000L
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchStartBrightness = 0.5f
    private var touchStartVolume = 0
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var nextPromptShownKey = ""
    private var skipNextOnce = false
    private var nextPromptDialog: AlertDialog? = null
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var playbackRetryCount = 0
    private var bufferingStartedAt = 0L
    private var recentLongBufferCount = 0
    private var decoderAutoFallbackUsed = false
    private var lifecycleRestorePending = false
    private var lifecycleWasPlaying = false
    private var lifecyclePosition = 0L
    private var lifecyclePausedAt = 0L
    private var pauseAfterLifecycleRestore = false
    private var subtitleDelayMs = 0
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleEnabled = true
    private var subtitleTextColor = Color.YELLOW
    private var subtitleBackgroundMode = "black"
    private var subtitleFontMode = "system"
    private var subtitleBold = true
    private var lastEnabledSpuTrack = 0
    private var preferredAudioTrackId = Int.MIN_VALUE
    private var preferredSubtitleTrackId = Int.MIN_VALUE
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        try {
            parseIncoming()
            loadUiPreferences()
            if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
            if (currentIndex !in tracks.indices) currentIndex = 0
            videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
            title = tracks.getOrNull(currentIndex)?.title ?: title
            progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
            if (videoUrl.isBlank()) throw IllegalArgumentException("Empty playback URL")
            currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
            buildUi()
            switchTo(currentIndex)
        } catch (_: Throwable) {
            Toast.makeText(this, "این نسخه پخش معتبر نیست؛ نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private var currentBrightness = 0.55f

    private fun loadUiPreferences() {
        subtitleEnabled = UiPreferences.subtitleEnabled(this)
        subtitleTextColor = UiPreferences.subtitleTextColor(this)
        subtitleBackgroundMode = UiPreferences.subtitleBackgroundMode(this)
        subtitleScale = UiPreferences.subtitleScale(this)
        subtitleDelayMs = UiPreferences.subtitleDelayMs(this)
        subtitleFontMode = UiPreferences.subtitleFontMode(this)
        subtitleBold = UiPreferences.subtitleBold(this)
        subtitlePositionIndex = UiPreferences.subtitlePosition(this)
        seekJumpMs = UiPreferences.seekSeconds(this).toLong() * 1000L
        autoPlayNext = UiPreferences.autoNext(this)
    }

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        requestedResumePosition = intent.getLongExtra(EXTRA_RESUME_POSITION, 0L).coerceAtLeast(0L)
        val payloadFile = intent.getStringExtra(EXTRA_PLAYLIST_FILE).orEmpty()
        val json = if (payloadFile.isNotBlank()) {
            runCatching {
                File(payloadFile).takeIf { it.isFile && it.length() in 1..2_500_000L }?.readText(Charsets.UTF_8).orEmpty()
            }.getOrDefault("").ifBlank { intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty() }
        } else {
            intent.getStringExtra(EXTRA_PLAYLIST_JSON).orEmpty()
        }
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until min(arr.length(), 160)) {
                    val it = arr.optJSONObject(i) ?: continue
                    if (it.optString("url").isBlank()) continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun isTvLike(): Boolean {
        val mode = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
        return mode == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || resources.configuration.smallestScreenWidthDp >= 600
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, Color.red(blue), Color.green(blue), Color.blue(blue)))
            setStroke(dp(2), Color.argb(205, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), blue2)
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        if (!isTvLike()) return
        if (view.getTag(R.id.bm_tv_focus_bound) == true) return
        view.setTag(R.id.bm_tv_focus_bound, true)
        val originalForeground = view.foreground
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        if (android.os.Build.VERSION.SDK_INT >= 26) view.defaultFocusHighlightEnabled = false
        var parent = view.parent
        while (parent is android.view.ViewGroup) {
            parent.clipChildren = false
            parent.clipToPadding = false
            parent = parent.parent
        }
        view.setOnFocusChangeListener { v, has ->
            v.animate().cancel()
            v.foreground = if (has) playerFocusDrawable(radiusDp) else originalForeground
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.translationZ = if (has) dp(8).toFloat() else 0f
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(if (has) 145L else 105L)
                .setInterpolator(android.view.animation.DecelerateInterpolator())
                .start()
        }
    }

    private fun focusPlayButton() {
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                if (v is android.view.ViewGroup) {
                    v.clipChildren = false
                    v.clipToPadding = false
                }
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 55)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = VLCVideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(14), dp(6))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(175, 0, 0, 0), Color.argb(58, 0, 0, 0), Color.TRANSPARENT)
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        subText = TextView(this).apply {
            text = currentLabel()
            setTextColor(muted)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
        }
        info.addView(titleText)
        info.addView(subText)
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(0, 0, 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        actions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(50), dp(40)).apply { marginStart = dp(2) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_audio) { showAudioSubtitleSettingsSheet() }, LinearLayout.LayoutParams(dp(42), dp(40)).apply { marginStart = dp(2) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_cc) { showSubtitleStyleSheet() }, LinearLayout.LayoutParams(dp(42), dp(40)).apply { marginStart = dp(2) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_quality) { showQualitySheet() }, LinearLayout.LayoutParams(dp(42), dp(40)))
        topBar.addView(actions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(66), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER
        }
        val jumpLabel = (seekJumpMs / 1000L).toString()
        val rewind = circleAction(R.drawable.ic_player_replay, jumpLabel) { seekBy(-seekJumpMs) }.apply { id = View.generateViewId() }
        val play = FrameLayout(this).apply {
            id = View.generateViewId()
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, jumpLabel) { seekBy(seekJumpMs) }.apply { id = View.generateViewId() }
        rewind.nextFocusRightId = play.id
        play.nextFocusLeftId = rewind.id
        play.nextFocusRightId = forward.id
        forward.nextFocusLeftId = play.id
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginEnd = dp(22) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(68), dp(68)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(58), dp(58)).apply { marginStart = dp(22) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(90), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(18), dp(4), dp(18), dp(10))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.argb(120, 0, 0, 0), Color.argb(225, 0, 0, 0))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        val bottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.LEFT or Gravity.CENTER_VERTICAL
            setPadding(0, dp(2), 0, 0)
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        val settingsButton = glassIconButton(R.drawable.ic_player_settings) { showSettingsSheet() }
        bottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(8) })
        bottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(8) })
        bottomActions.addView(settingsButton, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginEnd = dp(8) })
        bottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(54), dp(30)).apply { marginStart = dp(2) })
        bottomBar.addView(bottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(5); gravity = Gravity.LEFT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(106), Gravity.BOTTOM))

        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { controlsLocked = false; showControls(); updateLockUi() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })

        setContentView(root)
        BankmovieFonts.applyToTree(this, root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                val p = player ?: return
                if (p.length > 0) p.time = ((s?.progress ?: 0).toLong() * p.length) / 1000L
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER).apply { rightMargin = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.045f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, FrameLayout.LayoutParams(dp(18), dp(18), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = ColorDrawable(Color.TRANSPARENT)
            elevation = 0f
            applyPlayerFocus(this, 999, 1.10f, 0f)
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(22), dp(22)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    private fun launchPlayerSafely(url: String) {
        val clean = url.trim()
        if (clean.isBlank()) {
            Toast.makeText(this, "لینک پخش خالی است", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        try {
            startPlayer(clean)
        } catch (_: Throwable) {
            releasePlayer()
            if (hardwareDecoder) {
                hardwareDecoder = false
                handler.postDelayed({ runCatching { startPlayer(clean) }.onFailure {
                    Toast.makeText(this, "این نسخه با پلیر داخلی سازگار نیست؛ نسخه دیگری را امتحان کنید", Toast.LENGTH_LONG).show()
                    finish()
                } }, 300L)
            } else {
                Toast.makeText(this, "این نسخه با پلیر داخلی سازگار نیست؛ نسخه دیگری را امتحان کنید", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun irancellSubtitleFontPath(): String? {
        val assetName = BankmovieFonts.assetFileName(subtitleFontMode) ?: return null
        val dir = File(filesDir, "subtitle_fonts")
        val out = File(dir, assetName)
        if (out.isFile && out.length() > 4096L) return out.absolutePath
        return runCatching {
            dir.mkdirs()
            assets.open("fonts/$assetName").use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            out.takeIf { it.isFile && it.length() > 4096L }?.absolutePath
        }.getOrNull()
    }

    private fun isMeteredOrMobileNetwork(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return runCatching {
            val network = cm.activeNetwork ?: return@runCatching true
            val caps = cm.getNetworkCapabilities(network) ?: return@runCatching true
            cm.isActiveNetworkMetered || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
        }.getOrDefault(true)
    }

    private fun stableCacheMs(isAdaptive: Boolean): Int {
        if (!isAdaptive) return if (DeviceProfile.isLowEnd(this)) 2200 else 1700
        return when {
            isMeteredOrMobileNetwork() -> 6500
            DeviceProfile.isLowEnd(this) -> 5200
            else -> 4200
        }
    }

    private fun startPlayer(url: String) {
        releasePlayer()
        resumeApplied = false
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        // Restore the previously stable player buffering. The aggressive TV
        // adaptive/caching patch caused decoder artifacts on some televisions.
        val cacheMs = stableCacheMs(isDash || isHls)
        val subtitleBgColor = UiPreferences.subtitleBackgroundColor(this) and 0xFFFFFF
        val subtitleBgOpacity = UiPreferences.subtitleBackgroundOpacity(this)
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--drop-late-frames",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-color=${subtitleTextColor and 0xFFFFFF}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-color=$subtitleBgColor",
            "--freetype-background-opacity=$subtitleBgOpacity"
        )
        if (subtitleBold) libOptions.add("--freetype-bold")
        irancellSubtitleFontPath()?.let { fontPath ->
            libOptions.add("--freetype-font=$fontPath")
        }
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=rate")
            libOptions.add("--adaptive-use-access")
        }
        val lib = LibVLC(this, libOptions)
        vlc = lib
        val mp = MediaPlayer(lib)
        player = mp
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Buffering -> {
                        val percent = event.buffering
                        if (percent < 1f && bufferingStartedAt == 0L) bufferingStartedAt = System.currentTimeMillis()
                        if (percent >= 99f && bufferingStartedAt > 0L) {
                            val stalledFor = System.currentTimeMillis() - bufferingStartedAt
                            bufferingStartedAt = 0L
                            if (stalledFor >= 4500L) recentLongBufferCount += 1
                            if (recentLongBufferCount >= 3 && hardwareDecoder && !decoderAutoFallbackUsed) {
                                decoderAutoFallbackUsed = true
                                val keep = player?.time?.coerceAtLeast(0L) ?: 0L
                                hardwareDecoder = false
                                requestedResumePosition = keep
                                showHud("حالت پایدار تصویر فعال شد")
                                handler.postDelayed({ launchPlayerSafely(videoUrl) }, 180L)
                            }
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        playbackRetryCount = 0
                        bufferingStartedAt = 0L
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        if (pauseAfterLifecycleRestore) {
                            pauseAfterLifecycleRestore = false
                            handler.postDelayed({ runCatching { player?.pause() } }, 180L)
                        }
                        applyMode()
                        applySubtitleDelay()
                        handler.postDelayed({ applySubtitleVisibility() }, 350L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 500L)
                        handler.postDelayed({ applyPreferredNativeTracks() }, 1300L)
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val stored = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            val saved = max(stored, requestedResumePosition)
                            if (saved > 15000L) {
                                fun applyResumeSeek() {
                                    try {
                                        val current = player?.time ?: 0L
                                        if (current < saved - 5000L) player?.time = saved
                                    } catch (_: Throwable) {}
                                }
                                applyResumeSeek()
                                listOf(300L, 800L, 1600L, 3000L, 5000L, 8000L, 11000L).forEach { delayMs ->
                                    handler.postDelayed({ applyResumeSeek() }, delayMs)
                                }
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    MediaPlayer.Event.Paused -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.Stopped -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.EndReached -> playNext()
                    MediaPlayer.Event.EncounteredError -> {
                        if (playbackRetryCount < 2) {
                            playbackRetryCount += 1
                            if (playbackRetryCount == 1) hardwareDecoder = false
                            Toast.makeText(this, "خطا در پخش؛ تلاش مجدد ${playbackRetryCount}/2", Toast.LENGTH_SHORT).show()
                            handler.postDelayed({ launchPlayerSafely(videoUrl) }, 850L)
                        } else {
                            Toast.makeText(this, "این لینک با پلیر داخلی سازگار نیست؛ کیفیت یا نسخه دیگری را انتخاب کنید", Toast.LENGTH_LONG).show()
                            releasePlayer()
                        }
                    }
                }
            }
        }
        val media = Media(lib, Uri.parse(url))
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        if (subtitleBold) media.addOption(":freetype-bold")
        irancellSubtitleFontPath()?.let { media.addOption(":freetype-font=$it") }
        media.addOption(":freetype-color=${subtitleTextColor and 0xFFFFFF}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-color=$subtitleBgColor")
        media.addOption(":freetype-background-opacity=$subtitleBgOpacity")
        val resumePrefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
        val resumeStableKey = progressKey.ifBlank { "progress_$videoUrl" }
        val resumeBeforePlay = max(
            resumePrefs.getLong(
                resumeStableKey,
                resumePrefs.getLong("progress_$videoUrl", 0L)
            ),
            requestedResumePosition
        )
        resumeTarget = resumeBeforePlay
        resumeGuardUntil = System.currentTimeMillis() + 12000L
        if (resumeBeforePlay > 15000L) {
            media.addOption(":start-time=${resumeBeforePlay / 1000L}")
        }
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=rate")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int) {
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        nextPromptShownKey = ""
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        title = tracks[index].title
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        requestedResumePosition = UiPreferences.prefs(this).getLong(progressKey, UiPreferences.prefs(this).getLong("progress_$videoUrl", 0L))
        updateLabels()
        refreshTopActions()
        launchPlayerSafely(videoUrl)
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }.trim()
        val normalized = base.lowercase(Locale.US).replace("‌", " ")
        val alreadyHasEpisode = normalized.contains("قسمت ${t.episode}") || normalized.contains("episode ${t.episode}") || normalized.contains("e${t.episode}")
        val alreadyHasSeason = normalized.contains("فصل ${t.season}") || normalized.contains("season ${t.season}") || normalized.contains("s${t.season}")
        val episodeHead = when {
            t.season > 0 && t.episode > 0 && !(alreadyHasSeason || alreadyHasEpisode) -> "فصل ${t.season} • قسمت ${t.episode}"
            t.episode > 0 && !alreadyHasEpisode -> "قسمت ${t.episode}"
            t.season > 0 && !alreadyHasSeason -> "فصل ${t.season}"
            else -> ""
        }
        val standard = streamStandard(t.url)
        return listOf(episodeHead, base, standard).filter { it.isNotBlank() }.distinct().joinToString(" • ")
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(muted)
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private data class NativeTrackOption(val id: Int, val name: String)

    private fun nativeTrackOptions(methodName: String): List<NativeTrackOption> {
        val mp = player ?: return emptyList()
        return try {
            val raw = mp.javaClass.getMethod(methodName).invoke(mp)
            val values: List<Any?> = when (raw) {
                is Array<*> -> raw.toList()
                is Iterable<*> -> raw.toList()
                else -> emptyList()
            }
            values.mapNotNull { item ->
                if (item == null) return@mapNotNull null
                val id = try {
                    item.javaClass.getMethod("getId").invoke(item) as? Int
                } catch (_: Throwable) {
                    try { item.javaClass.getField("id").getInt(item) } catch (_: Throwable) { null }
                } ?: return@mapNotNull null
                val name = try {
                    item.javaClass.getMethod("getName").invoke(item)?.toString()
                } catch (_: Throwable) {
                    try { item.javaClass.getField("name").get(item)?.toString() } catch (_: Throwable) { null }
                }.orEmpty().ifBlank { "Track $id" }
                NativeTrackOption(id, name)
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun currentNativeTrack(methodName: String): Int {
        val mp = player ?: return -1
        return try { (mp.javaClass.getMethod(methodName).invoke(mp) as? Int) ?: -1 } catch (_: Throwable) { -1 }
    }

    private fun setNativeTrack(methodName: String, id: Int): Boolean {
        val mp = player ?: return false
        return try {
            val result = mp.javaClass.getMethod(methodName, Integer.TYPE).invoke(mp, id)
            result !is Boolean || result
        } catch (_: Throwable) {
            false
        }
    }

    private fun applySubtitleVisibility() {
        if (!subtitleEnabled) {
            val current = currentNativeTrack("getSpuTrack")
            if (current >= 0) lastEnabledSpuTrack = current
            setNativeTrack("setSpuTrack", -1)
            return
        }
        val current = currentNativeTrack("getSpuTrack")
        if (current >= 0) return
        val available = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        val target = available.firstOrNull { it.id == lastEnabledSpuTrack } ?: available.firstOrNull()
        if (target != null) setNativeTrack("setSpuTrack", target.id)
    }

    private fun applyPreferredNativeTracks() {
        if (preferredAudioTrackId != Int.MIN_VALUE && preferredAudioTrackId >= 0) {
            setNativeTrack("setAudioTrack", preferredAudioTrackId)
        }
        if (!subtitleEnabled || preferredSubtitleTrackId == -1) {
            setNativeTrack("setSpuTrack", -1)
            return
        }
        if (preferredSubtitleTrackId != Int.MIN_VALUE && preferredSubtitleTrackId >= 0) {
            lastEnabledSpuTrack = preferredSubtitleTrackId
            setNativeTrack("setSpuTrack", preferredSubtitleTrackId)
        }
    }

    private fun showNativeTrackDialog(titleValue: String, audio: Boolean) {
        val options = nativeTrackOptions(if (audio) "getAudioTracks" else "getSpuTracks")
        val current = currentNativeTrack(if (audio) "getAudioTrack" else "getSpuTrack")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(248, 18, 18, 21), dp(28), Color.argb(150, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        box.addView(sectionTitle(titleValue))
        var dialog: AlertDialog? = null
        if (!audio) {
            box.addView(sheetButton("خاموش${if (current < 0) "  ✓" else ""}") {
                subtitleEnabled = false
                UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, false).apply()
                applySubtitleVisibility()
                dialog?.dismiss()
                showHud("زیرنویس غیرفعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        options.filter { audio || it.id >= 0 }.forEach { option ->
            box.addView(sheetButton("${option.name}${if (option.id == current) "  ✓" else ""}") {
                if (audio) setNativeTrack("setAudioTrack", option.id)
                else {
                    subtitleEnabled = true
                    lastEnabledSpuTrack = option.id
                    UiPreferences.prefs(this).edit().putBoolean(UiPreferences.KEY_SUB_ENABLED, true).apply()
                    setNativeTrack("setSpuTrack", option.id)
                }
                dialog?.dismiss()
                showHud(if (audio) "ترک صدا تغییر کرد" else "زیرنویس فعال شد")
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(7) })
        }
        if (options.isEmpty()) {
            box.addView(TextView(this).apply {
                text = "ترکی برای انتخاب پیدا نشد"
                setTextColor(muted)
                textSize = 13f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(18), dp(12), dp(18))
            })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(250, 17, 17, 20), dp(30), Color.argb(155, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        scroll.addView(box)

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        header.addView(TextView(this).apply {
            text = "تنظیمات پخش"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_settings)
            setColorFilter(blue)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(Color.argb(32, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(15), Color.argb(120, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(header, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("صدا و زیرنویس"))
        box.addView(settingButton("صدا، زیرنویس و ظاهر", subtitleStyleLabel(), "انتخاب ترک صدا و زیرنویس، خاموش‌کردن، رنگ، پس‌زمینه، اندازه و فونت") { showAudioSubtitleSettingsSheet() })

        box.addView(settingsMiniLabel("پخش"))
        box.addView(settingButton("سرعت پخش", speedLabel(), "تنظیم از 0.5x تا 2x") { showSpeedSheet() })
        box.addView(settingButton("زمان پرش", "${seekJumpMs / 1000L} ثانیه", "مقدار عقب و جلو رفتن") {
            val values = listOf(5L, 10L, 30L, 60L)
            val currentIndex = values.indexOf(seekJumpMs / 1000L).let { if (it < 0) 1 else it }
            val next = values[(currentIndex + 1) % values.size]
            seekJumpMs = next * 1000L
            UiPreferences.prefs(this).edit().putInt(UiPreferences.KEY_SEEK_SECONDS, next.toInt()).apply()
            showHud("زمان پرش: $next ثانیه")
        })
        box.addView(settingButton("پخش خودکار قسمت بعد", if (autoPlayNext) "روشن" else "خاموش", "پس از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("پخش خودکار: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری", "برای دستگاه‌های ضعیف حالت سخت‌افزاری بهتر است") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("دیکودر: ${if (hardwareDecoder) "سخت‌افزاری" else "نرم‌افزاری"}")
        })
        box.addView(settingButton("تصویر در تصویر", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("تایمر خواب", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("قفل کنترل‌ها", if (controlsLocked) "قفل" else "باز", "قفل‌کردن دکمه‌ها و ژست‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(blue)
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(245, 28, 28, 32), dp(18), Color.argb(72, 255, 255, 255))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(blue2)
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(muted)
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.argb(246, 27, 63, 104), dp(28), Color.argb(96, 190, 220, 255))
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showAudioSubtitleSettingsSheet() {
        var localEnabled = subtitleEnabled
        var localTextColor = subtitleTextColor
        var localBgMode = subtitleBackgroundMode
        var localFontMode = subtitleFontMode
        var localScale = subtitleScale
        var localPosition = subtitlePositionIndex
        var localDelay = subtitleDelayMs
        var localAudioTrack = currentNativeTrack("getAudioTrack")
        var localSubtitleTrack = currentNativeTrack("getSpuTrack")

        val audioOptions = nativeTrackOptions("getAudioTracks").filter { it.id >= 0 }
        val subtitleOptions = nativeTrackOptions("getSpuTracks").filter { it.id >= 0 }
        if (localAudioTrack < 0) localAudioTrack = audioOptions.firstOrNull()?.id ?: -1
        if (localEnabled && localSubtitleTrack < 0) localSubtitleTrack = subtitleOptions.firstOrNull()?.id ?: -1

        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.argb(250, 17, 17, 20), dp(30), Color.argb(155, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }
        scroll.addView(box)

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        head.addView(TextView(this).apply {
            text = "صدا و زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 22f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_player_audio)
            setColorFilter(blue)
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = rounded(Color.argb(32, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(15), Color.argb(120, Color.red(blue), Color.green(blue), Color.blue(blue)))
        }, LinearLayout.LayoutParams(dp(42), dp(42)))
        box.addView(head, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        fun optionButton(label: String, selected: () -> Boolean, click: () -> Unit): TextView {
            lateinit var view: TextView
            view = TextView(this).apply {
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER_VERTICAL or Gravity.RIGHT
                setPadding(dp(13), 0, dp(13), 0)
                maxLines = 2
                setOnClickListener { click() }
                applyPlayerFocus(this, 17, 1.03f, 0f)
            }
            fun refresh() {
                val active = selected()
                view.text = label + if (active) "   ✓" else ""
                view.background = if (active) rounded(Color.argb(90, Color.red(blue), Color.green(blue), Color.blue(blue)), dp(16), blue) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (active) blue2 else Color.WHITE)
            }
            view.tag = Runnable { refresh() }
            refresh()
            return view
        }

        fun refreshOptions(container: LinearLayout) {
            for (i in 0 until container.childCount) {
                (container.getChildAt(i).tag as? Runnable)?.run()
            }
        }

        box.addView(settingsMiniLabel("ترک صدا"))
        val audioBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (audioOptions.isEmpty()) {
            audioBox.addView(TextView(this).apply {
                text = "ترک صدای جداگانه‌ای در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
                background = rounded(Color.rgb(28, 28, 32), dp(15), Color.argb(70, 255, 255, 255))
            })
        } else {
            audioOptions.forEach { option ->
                val button = optionButton(option.name, { localAudioTrack == option.id }) {
                    localAudioTrack = option.id
                    refreshOptions(audioBox)
                }
                audioBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
            }
        }
        box.addView(audioBox)

        box.addView(settingsMiniLabel("زیرنویس"))
        val subtitleBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        subtitleBox.addView(optionButton("خاموش", { !localEnabled || localSubtitleTrack < 0 }) {
            localEnabled = false
            localSubtitleTrack = -1
            refreshOptions(subtitleBox)
        }, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        subtitleOptions.forEach { option ->
            val button = optionButton(option.name, { localEnabled && localSubtitleTrack == option.id }) {
                localEnabled = true
                localSubtitleTrack = option.id
                refreshOptions(subtitleBox)
            }
            subtitleBox.addView(button, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        }
        if (subtitleOptions.isEmpty()) {
            subtitleBox.addView(TextView(this).apply {
                text = "زیرنویس داخلی در این فایل پیدا نشد"
                setTextColor(muted)
                textSize = 12.5f
                gravity = Gravity.RIGHT
                setPadding(dp(12), dp(13), dp(12), dp(13))
            })
        }
        box.addView(subtitleBox)

        box.addView(settingsMiniLabel("رنگ متن"))
        val colors = listOf(Color.WHITE, Color.YELLOW, Color.BLACK, Color.RED, Color.BLUE, Color.GREEN, Color.rgb(255, 193, 7))
        val colorViews = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL; setPadding(0, dp(6), 0, dp(6)) }
        fun refreshColorViews() {
            colorViews.forEachIndexed { i, view ->
                view.text = if (colors[i] == localTextColor) "✓" else ""
                view.background = rounded(colors[i], dp(999), if (colors[i] == localTextColor) blue2 else Color.argb(90, 255, 255, 255))
                view.setTextColor(if (colors[i] == Color.BLACK) Color.WHITE else Color.BLACK)
            }
        }
        colors.forEachIndexed { index, color ->
            val v = TextView(this).apply {
                textSize = 15f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localTextColor = color; refreshColorViews() }
                applyPlayerFocus(this, 999, 1.08f, 0f)
            }
            colorViews.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(7) })
        }
        refreshColorViews()
        box.addView(android.widget.HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(colorRow) }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        box.addView(settingsMiniLabel("پس‌زمینه زیرنویس"))
        val bgOptions = listOf("transparent" to "شفاف", "black" to "مشکی", "white" to "سفید", "yellow" to "زرد", "red" to "قرمز", "blue" to "آبی", "pink" to "صورتی")
        val bgButtons = mutableListOf<Pair<String, TextView>>()
        val bgRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, dp(4), 0, dp(4))
        }
        fun refreshBgButtons() {
            bgButtons.forEach { (key, view) ->
                val selected = key == localBgMode
                view.background = if (selected) rounded(blue, dp(15), blue2) else rounded(Color.rgb(30, 30, 34), dp(15), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        bgOptions.forEachIndexed { index, pair ->
            val v = TextView(this).apply {
                text = pair.second
                textSize = 12f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localBgMode = pair.first; refreshBgButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            bgButtons.add(pair.first to v)
            bgRow.addView(v, LinearLayout.LayoutParams(dp(82), dp(43)).apply { if (index > 0) marginStart = dp(5) })
        }
        refreshBgButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(bgRow)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })

        box.addView(settingsMiniLabel("فونت زیرنویس"))
        val fontButtons = mutableListOf<Pair<String, TextView>>()
        val fontRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshFontButtons() {
            fontButtons.forEach { (key, view) ->
                val selected = key == localFontMode
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        BankmovieFonts.options.forEachIndexed { index, option ->
            val v = TextView(this).apply {
                text = option.faLabel
                textSize = 13f
                typeface = BankmovieFonts.forMode(this@PlayerActivity, option.key, true)
                gravity = Gravity.CENTER
                setOnClickListener { localFontMode = option.key; refreshFontButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            fontButtons += option.key to v
            fontRow.addView(v, LinearLayout.LayoutParams(dp(112), dp(46)).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshFontButtons()
        box.addView(android.widget.HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(fontRow)
        }, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("جای زیرنویس"))
        val positionButtons = mutableListOf<Pair<Int, TextView>>()
        val positionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.RIGHT
            setPadding(0, dp(4), 0, dp(10))
        }
        fun refreshPositionButtons() {
            positionButtons.forEach { (index, view) ->
                val selected = index == localPosition
                view.background = if (selected) rounded(blue, dp(16), blue2) else rounded(Color.rgb(30, 30, 34), dp(16), Color.argb(80, 255, 255, 255))
                view.setTextColor(if (selected) UiPreferences.palette(this).onPrimary else Color.WHITE)
            }
        }
        subtitlePositions.forEachIndexed { index, label ->
            val v = TextView(this).apply {
                text = label
                textSize = 13f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setOnClickListener { localPosition = index; refreshPositionButtons() }
                applyPlayerFocus(this, 17, 1.035f, 0f)
            }
            positionButtons += index to v
            positionRow.addView(v, LinearLayout.LayoutParams(0, dp(46), 1f).apply { if (index > 0) marginStart = dp(7) })
        }
        refreshPositionButtons()
        box.addView(positionRow, LinearLayout.LayoutParams(-1, -2))

        box.addView(settingsMiniLabel("اندازه و هماهنگی"))
        val sizeValue = TextView(this).apply { text = "اندازه متن: $localScale%"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(sizeValue)
        val sizeSeek = SeekBar(this).apply {
            max = 90
            progress = (localScale - 80).coerceIn(0, 90)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localScale = 80 + progress; sizeValue.text = "اندازه متن: $localScale%" }
            }
        })
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(6) })

        val delayValue = TextView(this).apply { text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s"; setTextColor(Color.WHITE); textSize = 13.5f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.RIGHT }
        box.addView(delayValue)
        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((localDelay + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(90, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) { localDelay = progress * 100 - 10000; delayValue.text = "هماهنگی زیرنویس: ${"%.1f".format(Locale.US, localDelay / 1000f)}s" }
            }
        })
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })

        val applyButton = TextView(this).apply {
            text = "اعمال صدا و زیرنویس"
            setTextColor(UiPreferences.palette(this@PlayerActivity).onPrimary)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(blue, dp(22), blue2)
            applyPlayerFocus(this, 23, 1.035f, 0f)
        }
        box.addView(applyButton, LinearLayout.LayoutParams(-1, dp(52)))

        val dialog = dialogOf(scroll)
        applyButton.setOnClickListener {
            val styleChanged = localTextColor != subtitleTextColor || localBgMode != subtitleBackgroundMode || localFontMode != subtitleFontMode || localScale != subtitleScale || localPosition != subtitlePositionIndex || localDelay != subtitleDelayMs
            subtitleEnabled = localEnabled
            subtitleTextColor = localTextColor
            subtitleBackgroundMode = localBgMode
            subtitleFontMode = localFontMode
            subtitleScale = localScale
            subtitlePositionIndex = localPosition
            subtitleDelayMs = localDelay
            preferredAudioTrackId = localAudioTrack
            preferredSubtitleTrackId = if (localEnabled) localSubtitleTrack else -1
            UiPreferences.prefs(this).edit()
                .putBoolean(UiPreferences.KEY_SUB_ENABLED, subtitleEnabled)
                .putInt(UiPreferences.KEY_SUB_TEXT_COLOR, subtitleTextColor)
                .putString(UiPreferences.KEY_SUB_BG_MODE, subtitleBackgroundMode)
                .putString(UiPreferences.KEY_SUB_FONT, subtitleFontMode)
                .putInt(UiPreferences.KEY_SUB_SCALE, subtitleScale)
                .putInt(UiPreferences.KEY_SUB_DELAY, subtitleDelayMs)
                .putInt(UiPreferences.KEY_SUB_POSITION, subtitlePositionIndex)
                .apply()
            dialog.dismiss()
            if (styleChanged) {
                restartKeepingTime("تنظیمات صدا و زیرنویس اعمال شد")
            } else {
                applyPreferredNativeTracks()
                applySubtitleDelay()
                showHud("صدا و زیرنویس اعمال شد")
            }
        }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        showAudioSubtitleSettingsSheet()
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String {
        val colorLabel = when (subtitleTextColor) {
            Color.YELLOW -> "زرد"
            Color.BLACK -> "مشکی"
            Color.RED -> "قرمز"
            Color.BLUE -> "آبی"
            Color.GREEN -> "سبز"
            else -> "سفید"
        }
        val bgLabel = when (subtitleBackgroundMode) {
            "black" -> "پس‌زمینه مشکی"
            "white" -> "پس‌زمینه سفید"
            "yellow" -> "پس‌زمینه زرد"
            "red" -> "پس‌زمینه قرمز"
            "blue" -> "پس‌زمینه آبی"
            "pink" -> "پس‌زمینه صورتی"
            else -> "شفاف"
        }
        val fontLabel = BankmovieFonts.label(subtitleFontMode)
        return "$colorLabel • $bgLabel • $fontLabel • $subtitleScale%"
    }

    private fun applySubtitleDelay() {
        try { player?.javaClass?.getMethod("setSpuDelay", java.lang.Long.TYPE)?.invoke(player, subtitleDelayMs * 1000L) } catch (_: Throwable) {}
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        requestedResumePosition = pos
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (_: Throwable) {
                Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(white)
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun dialogOf(view: View): AlertDialog {
        return AlertDialog.Builder(this).setView(view).create().also { dialog ->
            dialog.setOnShowListener {
                val win = dialog.window
                win?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
                win?.setDimAmount(0.58f)
                win?.addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND)
                val decor = win?.decorView
                decor?.animate()?.cancel()
                if (decor != null) {
                    decor.alpha = 0f
                    decor.scaleX = 0.97f
                    decor.scaleY = 0.97f
                    decor.translationY = dp(10).toFloat()
                    decor.animate()
                        .alpha(1f)
                        .scaleX(1f)
                        .scaleY(1f)
                        .translationY(0f)
                        .setDuration(180L)
                        .setInterpolator(android.view.animation.DecelerateInterpolator())
                        .start()
                }
                applyPlayerFocusTree(view)
                view.postDelayed({
                    fun first(v: View): Boolean {
                        if (v.isFocusable && v.isEnabled && v.visibility == View.VISIBLE && v.hasOnClickListeners()) {
                            v.requestFocus()
                            return true
                        }
                        if (v is android.view.ViewGroup) {
                            for (i in 0 until v.childCount) if (first(v.getChildAt(i))) return true
                        }
                        return false
                    }
                    first(view)
                }, 95L)
            }
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(210, 8, 18, 36), dp(16), Color.argb(180, 55, 104, 188))
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun toggle() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        hideBarsLater()
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        val len = p.length
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        updateProgress()
        hideBarsLater()
    }

    private fun nextEpisodeIndex(): Int {
        val current = tracks.getOrNull(currentIndex) ?: return -1
        if (current.episode <= 0 && current.season <= 0) return -1
        val candidates = tracks.withIndex().filter { (_, track) ->
            track.episode > 0 && (
                track.season > current.season ||
                    (track.season == current.season && track.episode > current.episode)
                )
        }
        if (candidates.isEmpty()) return -1
        val targetPair = candidates.minWithOrNull(
            compareBy<IndexedValue<Track>> { it.value.season }
                .thenBy { it.value.episode }
        ) ?: return -1
        val sameEpisode = candidates.filter {
            it.value.season == targetPair.value.season && it.value.episode == targetPair.value.episode
        }
        return (sameEpisode.firstOrNull {
            it.value.quality.equals(current.quality, true) && isSubtitle(it.value) == isSubtitle(current)
        } ?: sameEpisode.firstOrNull {
            isSubtitle(it.value) == isSubtitle(current) && isAudioOnly(it.value) == isAudioOnly(current)
        } ?: sameEpisode.first()).index
    }

    private fun nextEpisodeTitle(index: Int): String {
        val target = tracks.getOrNull(index) ?: return "قسمت بعدی"
        return if (target.season > 0) "فصل ${target.season} • قسمت ${target.episode}" else "قسمت ${target.episode}"
    }

    private fun maybePromptNextEpisode(time: Long, length: Long) {
        if (!autoPlayNext || length <= 0L || time <= 0L) return
        val nextIndex = nextEpisodeIndex()
        if (nextIndex < 0) return
        val current = tracks.getOrNull(currentIndex) ?: return
        val key = "${current.season}:${current.episode}:${current.url}"
        if (nextPromptShownKey == key || time.toDouble() / length.toDouble() < 0.95) return
        nextPromptShownKey = key
        skipNextOnce = false
        nextPromptDialog?.dismiss()
        nextPromptDialog = AlertDialog.Builder(this)
            .setTitle("قسمت بعدی آماده است")
            .setMessage("${nextEpisodeTitle(nextIndex)} پخش شود؟")
            .setPositiveButton("بله، پخش کن") { _, _ ->
                skipNextOnce = false
                switchTo(nextIndex)
            }
            .setNegativeButton("نه، همین قسمت") { _, _ ->
                skipNextOnce = true
                showHud("در همین قسمت می‌مانیم")
            }
            .create().also { dialog ->
                dialog.setOnDismissListener { nextPromptDialog = null }
                dialog.show()
                dialog.window?.setBackgroundDrawable(ColorDrawable(Color.rgb(18, 18, 22)))
            }
    }

    private fun playNext() {
        if (!autoPlayNext || skipNextOnce) {
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        val next = nextEpisodeIndex()
        if (next >= 0 && nextPromptDialog == null) maybePromptNextEpisode(player?.time ?: 0L, player?.length ?: 0L)
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        val mp = player ?: return
        when (modes[modeIndex]) {
            "FIT" -> { setAspect(mp, null); setScale(mp, 0f) }
            "CROP" -> { setAspect(mp, null); setScale(mp, 1.2f) }
            "STRETCH" -> {
                videoLayout.post {
                    val w = max(root.width, resources.displayMetrics.widthPixels)
                    val h = max(root.height, resources.displayMetrics.heightPixels)
                    setAspect(mp, "$w:$h")
                    setScale(mp, 0f)
                }
            }
        }
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        centerControls.visibility = View.GONE
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartY = e.y
                touchStartBrightness = currentBrightness
                touchStartVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val dy = e.y - touchStartY
                if (gestureMode == 0 && abs(dy) > abs(dx) && abs(dy) > dp(18)) {
                    handler.removeCallbacks(longPressRunnable)
                    gestureMode = if (touchStartX < root.width / 2f) 1 else 2
                }
                if (gestureMode == 1) {
                    val delta = (touchStartY - e.y) / root.height
                    currentBrightness = (touchStartBrightness + delta * 1.6f).coerceIn(0.05f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = currentBrightness
                    window.attributes = lp
                    showHud("روشنایی ${ (currentBrightness * 100).roundToInt() }٪")
                    return true
                } else if (gestureMode == 2) {
                    val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    val delta = ((touchStartY - e.y) / root.height * maxVol).roundToInt()
                    val vol = (touchStartVolume + delta).coerceIn(0, maxVol)
                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vol, 0)
                    val percent = (vol * 100f / maxVol).roundToInt()
                    showHud("صدا ${percent}٪")
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            if (controlsVisible) hideControls() else showControls()
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        val p = player ?: return
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val savedTime = p.time.coerceAtLeast(0L)
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            val duration = p.length.coerceAtLeast(0L)
            getSharedPreferences("bm_smart_cinema", MODE_PRIVATE).edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .putLong("${stableKey}_duration", duration)
                .putLong("progress_${videoUrl}_duration", duration)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val p = player ?: return
        val len = p.length
        var time = p.time
        if (resumeTarget > 15000L && System.currentTimeMillis() < resumeGuardUntil) {
            if (time < resumeTarget - 5000L) {
                try { p.time = resumeTarget } catch (_: Throwable) {}
                time = p.time
            } else {
                resumeTarget = 0L
            }
        }
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        if (len > 0L) maybePromptNextEpisode(time, len)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: MediaPlayer, ratio: String?) {
        try { mp.javaClass.getMethod("setAspectRatio", String::class.java).invoke(mp, ratio) } catch (_: Throwable) {}
    }

    private fun setScale(mp: MediaPlayer, scale: Float) {
        try { mp.javaClass.getMethod("setScale", java.lang.Float.TYPE).invoke(mp, scale) } catch (_: Throwable) {}
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(seekJumpMs)
                    showHud("${seekJumpMs / 1000L} ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    showSubtitleStyleSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
        if (lifecycleRestorePending && videoUrl.isNotBlank()) {
            val target = lifecyclePosition.coerceAtLeast(0L)
            val shouldPlay = lifecycleWasPlaying
            val awayFor = System.currentTimeMillis() - lifecyclePausedAt
            lifecycleRestorePending = false
            requestedResumePosition = max(requestedResumePosition, target)
            pauseAfterLifecycleRestore = !shouldPlay
            // Recreate LibVLC and its video surface after screen lock/app switching.
            // Reattaching only the old surface leaves a black frame on several phones.
            handler.postDelayed({
                if (!isFinishing && !isDestroyed) launchPlayerSafely(videoUrl)
            }, if (awayFor > 500L) 70L else 160L)
        }
    }

    private fun releasePlayer() {
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        player = null
        vlc = null
    }

    override fun onPause() {
        val inPip = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && isInPictureInPictureMode
        if (!inPip && !isFinishing) {
            val current = player
            lifecyclePosition = (current?.time ?: 0L).coerceAtLeast(0L)
            lifecycleWasPlaying = current?.isPlaying == true
            lifecyclePausedAt = System.currentTimeMillis()
            lifecycleRestorePending = videoUrl.isNotBlank()
            runCatching { current?.pause() }
        }
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onDestroy() {
        savePlaybackProgress(true)
        nextPromptDialog?.dismiss()
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
