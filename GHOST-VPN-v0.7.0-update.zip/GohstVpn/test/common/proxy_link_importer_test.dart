import 'dart:convert';
import 'dart:typed_data';

import 'package:fl_clash/common/proxy_link_importer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const nodeId = '00000000-0000-4000-8000-000000000001';
  const a = 'vless://$nodeId@vpn.example:443?security=tls&type=xhttp&'
      'path=%2F&host=edge.example&sni=edge.example&fp=chrome&alpn=h2#A';
  const b = 'vless://$nodeId@vpn2.example:8443?security=reality&type=tcp&'
      'pbk=examplepublickey&sid=aa&fp=chrome&sni=cdn.example#B';

  String normalizeText(String text) => utf8.decode(ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode(text))));

  test('manual multiple VLESS nodes preserve xhttp and reality settings', () {
    final conf = jsonDecode(normalizeText('$a\n$b')) as Map;
    final nodes = conf['proxies'] as List;
    expect(nodes.length, 2);
    expect(nodes[0]['network'], 'xhttp');
    expect(nodes[0]['xhttp-opts']['path'], '/');
    expect(nodes[1]['reality-opts']['short-id'], 'aa');
  });

  test('fragment is displayed as readable text after importing VLESS URI', () {
    final uri = 'vless://$nodeId@vpn.example:443?security=tls&type=ws#%F0%9F%87%A9%F0%9F%87%AA%20Germany%201';
    final config = jsonDecode(normalizeText(uri)) as Map;
    final nodes = config['proxies'] as List;
    expect(nodes.first['name'], '🇩🇪 Germany 1');
  });

  test('base64 VLESS subscription is recognized', () {
    final encoded = base64Encode(utf8.encode('$a\n$b'));
    final conf = jsonDecode(normalizeText(encoded)) as Map;
    expect((conf['proxies'] as List).length, 2);
  });

  test('valid nodes are imported while skipped nodes are reported', () {
    final warnings = <String>[];
    final result = ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode('$a\nvmess://unsupported')),
      onWarnings: warnings.addAll,
    );
    expect((jsonDecode(utf8.decode(result)) as Map)['proxies'].length, 1);
    expect(warnings.single, contains('unsupported non-VLESS'));
    expect(() => normalizeText('vless://@:-1?security=none'), throwsFormatException);
  });

  test('YAML configs are left unchanged', () {
    const yaml = 'proxies: []\nrules: []\n';
    expect(normalizeText(yaml), yaml);
  });

  test('TLS verification is never disabled unless explicitly requested', () {
    final nodes = (jsonDecode(normalizeText(a)) as Map)['proxies'] as List;
    expect(nodes.first.containsKey('skip-cert-verify'), false);
  });
  test('Telegram numbered and markdown paste imports all nodes', () {
    final input = '1) `$a`\n2. $b\n> $a';
    final config = jsonDecode(normalizeText(input)) as Map;
    final nodes = config['proxies'] as List;
    expect(nodes.length, 3);
    expect(nodes.first['name'], 'A');
    expect(nodes.last['name'], 'A (2)');
    expect(ProxyLinkImporter.countLinks(input), 3);
  });

  test('unsupported protocols reported but valid VLESS preserved', () {
    final warnings = <String>[];
    final data = ProxyLinkImporter.normalize(
      Uint8List.fromList(utf8.encode('$a\nvmess://unsupported')),
      onWarnings: warnings.addAll,
    );
    expect((jsonDecode(utf8.decode(data)) as Map)['proxies'].length, 1);
    expect(warnings.single, contains('unsupported non-VLESS'));
  });
}
