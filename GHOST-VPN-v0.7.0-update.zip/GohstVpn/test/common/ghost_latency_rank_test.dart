import 'package:fl_clash/common/ghost_latency_rank.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('lower successful ping ranks ahead of slower and timed out nodes', () {
    final values = <int?>[null, 0, 202, 165, -1, 185];
    values.sort(compareGhostLatency);
    expect(values.take(3).toList(), [165, 185, 202]);
    expect(values.skip(3).every((value) => value == null || value <= 0), true);
  });
  test('ties are stable for untested nodes', () {
    expect(compareGhostLatency(null, 0), 0);
    expect(compareGhostLatency(170, 170), 0);
  });
}
