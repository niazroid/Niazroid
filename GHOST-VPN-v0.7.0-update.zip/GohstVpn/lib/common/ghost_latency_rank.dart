/// Successful latency samples are sorted from fastest to slowest.
/// A timeout or an unmeasured server always belongs at the bottom.
int compareGhostLatency(int? a, int? b) {
  final aSuccess = a != null && a > 0;
  final bSuccess = b != null && b > 0;
  if (aSuccess != bSuccess) {
    return aSuccess ? -1 : 1;
  }
  if (aSuccess && bSuccess) {
    return a!.compareTo(b!);
  }
  return 0;
}
