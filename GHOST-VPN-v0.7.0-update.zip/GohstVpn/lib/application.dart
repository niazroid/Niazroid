import 'dart:async';
import 'dart:io';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:fl_clash/common/common.dart';
import 'package:fl_clash/common/ghost_active_server.dart';
import 'package:fl_clash/common/window.dart';
import 'package:fl_clash/bootstrap.dart';
import 'package:fl_clash/common/system_dns.dart';
import 'package:fl_clash/enum/enum.dart';
import 'package:fl_clash/icons/icons.dart';
import 'package:fl_clash/l10n/l10n.dart';
import 'package:fl_clash/manager/hotkey_manager.dart';
import 'package:fl_clash/manager/manager.dart';
import 'package:fl_clash/plugins/app.dart';
import 'package:fl_clash/providers/providers.dart';
import 'package:fl_clash/state.dart';
import 'package:fl_clash/widgets/focus.dart';
import 'package:fl_clash/widgets/keyboard_inset_hold.dart';
import 'package:material_ui/material_ui.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'pages/pages.dart';

Widget buildManagerStack({
  required bool isDesktop,
  required Future<void> Function(List<ConnectivityResult> results)
  onConnectivityChanged,
  required Widget child,
}) {
  final platformApp = isDesktop
      ? WindowHeaderContainer(child: child)
      : VpnManager(child: child);
  final state = AppStateManager(
    child: CoreManager(
      child: ConnectivityManager(
        onConnectivityChanged: onConnectivityChanged,
        child: platformApp,
      ),
    ),
  );
  final platformState = isDesktop
      ? WindowManager(
          child: TrayManager(
            child: HotKeyManager(child: ProxyManager(child: state)),
          ),
        )
      : AndroidManager(child: TileManager(child: state));
  return AppEnvManager(
    child: LocaleManager(
      child: StatusManager(child: ThemeManager(child: platformState)),
    ),
  );
}

class Application extends ConsumerStatefulWidget {
  const Application({super.key});

  @override
  ConsumerState<Application> createState() => ApplicationState();
}

const _actionIconTheme = ActionIconThemeData(
  backButtonIconBuilder: _backButtonIcon,
  closeButtonIconBuilder: _closeButtonIcon,
);

Widget _backButtonIcon(BuildContext context) =>
    GlyphIcon(AppGlyphs.backFor(Theme.of(context).platform));

Widget _closeButtonIcon(BuildContext context) =>
    const GlyphIcon(AppGlyphs.close);

class ApplicationState extends ConsumerState<Application>
    with WidgetsBindingObserver {
  Timer? _autoUpdateProfilesTaskTimer;
  OverlayEntry? _syncToastEntry;
  Timer? _syncToastTimer;
  bool _preHasVpn = false;
  bool _syncingSubscriptions = false;
  DateTime _lastForegroundRefresh = DateTime.now();

  final _pageTransitionsTheme = const PageTransitionsTheme(
    builders: <TargetPlatform, PageTransitionsBuilder>{
      TargetPlatform.android: commonSharedXPageTransitions,
      TargetPlatform.windows: commonSharedXPageTransitions,
      TargetPlatform.linux: commonSharedXPageTransitions,
      TargetPlatform.macOS: commonSharedXPageTransitions,
    },
  );

  ColorScheme _getAppColorScheme({required Brightness brightness}) {
    return ref.read(genColorSchemeProvider(brightness));
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    SystemNavigator.setFrameworkHandlesBack(true);
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) async {
      if (globalState.navigatorKey.currentContext != null) {
        await bootstrap.attach();
      } else {
        exit(0);
      }
      _autoUpdateProfilesTask();
      // Start after bootstrap has loaded the profile and started Mihomo.
      unawaited(_refreshSubscriptionsAndPing(force: true));
      _initLink();
      if (!safeModeBuild) {
        unawaited(app?.initShortcuts());
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state != AppLifecycleState.resumed || !globalState.isAttach) {
      return;
    }
    final now = DateTime.now();
    // A short cooldown prevents repeated calls on Android permission dialogs.
    // Each meaningful return to the foreground refreshes enabled subscriptions.
    if (now.difference(_lastForegroundRefresh) < const Duration(seconds: 10)) {
      return;
    }
    _lastForegroundRefresh = now;
    unawaited(_refreshSubscriptionsAndPing(force: true));
  }

  void _initLink() {
    linkManager.initAppLinksListen((url) async {
      unawaited(window?.show());
      final message = currentAppLocalizations.createProfileFromUrlTip(url);
      final parts = message.split(url);
      final res = await dialogs.showMessage(
        title: currentAppLocalizations.addProfile,
        message: TextSpan(
          children: [
            TextSpan(text: parts.first),
            TextSpan(
              text: url,
              style: TextStyle(
                color: context.colorScheme.primary,
                decoration: TextDecoration.underline,
                decorationColor: context.colorScheme.primary,
              ),
            ),
            if (parts.length > 1) TextSpan(text: parts.last),
          ],
        ),
      );
      if (res != true) {
        return;
      }
      unawaited(
        ref.read(profilesActionProvider.notifier).addProfileFormURL(url),
      );
    });
  }

  /// Fresh-launch and foreground refresh, then test the currently active
  /// selector. Never connect the VPN automatically and never guess ping data.
  Future<void> _refreshSubscriptionsAndPing({bool force = false}) async {
    if (_syncingSubscriptions || !globalState.isAttach) {
      return;
    }
    _syncingSubscriptions = true;
    try {
      final action = ref.read(profilesActionProvider.notifier);
      if (force) {
        await action.refreshEnabledProfilesOnLaunch();
      } else {
        await action.autoUpdateProfiles();
      }
      if (!mounted) {
        return;
      }
      final updated = action.lastRefreshUpdated;
      final failed = action.lastRefreshFailed;
      final attempted = action.lastRefreshAttempted;
      bool testedPing = false;
      int? currentPingMs;
      final profile = ref.read(currentProfileProvider);
      if (profile == null) {
        _showSyncToast(updated, failed, attempted, testedPing, currentPingMs);
        return;
      }
      // Applying a changed subscription can rebuild the core's group list.
      // Read the new state after the completed refresh, not before it.
      final active = resolveGhostActiveServer(
        ref.read(groupsProvider), profile,
      );
      if (active != null) {
        await ref.read(proxiesActionProvider.notifier)
            .delayTestGroups([active.group]);
        testedPing = true;
        final measured = ref.read(delayProvider(
          proxyName: active.proxy.name,
          testUrl: active.group.testUrl,
        ));
        if (measured != null && measured > 0) {
          currentPingMs = measured;
        }
      }
      _showSyncToast(updated, failed, attempted, testedPing, currentPingMs);
    } catch (error) {
      commonPrint.log('Subscription refresh or latency test failed: ${compactError(error)}',
          logLevel: LogLevel.warning);
      _showSyncToast(0, 1, 1, false, null);
    } finally {
      _syncingSubscriptions = false;
    }
  }

  void _showSyncToast(int updated, int failed, int attempted, bool testedPing, int? currentPingMs) {
    if (!mounted || attempted == 0) {
      return;
    }
    final ctx = globalState.navigatorKey.currentContext;
    if (ctx == null) {
      return;
    }
    final overlay = globalState.navigatorKey.currentState?.overlay;
    if (overlay == null) {
      return;
    }
    final success = updated > 0 && failed == 0;
    final partial = updated > 0 && failed > 0;
    final color = success ? const Color(0xFF219B3C)
        : partial ? const Color(0xFFAF7317) : const Color(0xFFB42932);
    final label = success
        ? '$updated اشتراک با موفقیت به‌روز شد${currentPingMs != null ? ' · پینگ فعلی: $currentPingMs ms' : testedPing ? ' · تست پینگ انجام شد' : ''}'
        : partial ? '$updated اشتراک به‌روز شد، $failed مورد خطا داشت'
        : 'به‌روزرسانی اشتراک ناموفق بود ($failed مورد)';
    _syncToastTimer?.cancel();
    _syncToastEntry?.remove();
    _syncToastEntry?.dispose();
    final entry = OverlayEntry(builder: (overlayContext) => Positioned(
      top: MediaQuery.paddingOf(overlayContext).top + 12,
      left: 14,
      right: 14,
      child: Material(
        elevation: 9,
        shadowColor: color.withValues(alpha: 0.5),
        color: color,
        borderRadius: BorderRadius.circular(15),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
          child: Row(children: [
            SvgPicture.asset(success ? 'assets/images/ghost_toast_success.svg' : 'assets/images/ghost_toast_failed.svg',
              width: 24, height: 24),
            const SizedBox(width: 10),
            Expanded(child: Text(label, textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.white,
                fontWeight: FontWeight.w600, fontSize: 14))),
          ]),
        ),
      ),
    ));
    overlay.insert(entry);
    _syncToastEntry = entry;
    _syncToastTimer = Timer(const Duration(seconds: 4), () {
      if (_syncToastEntry != entry) {
        return;
      }
      entry.remove();
      entry.dispose();
      _syncToastEntry = null;
    });
  }

  void _autoUpdateProfilesTask() {
    _autoUpdateProfilesTaskTimer?.cancel();
    _autoUpdateProfilesTaskTimer = Timer.periodic(const Duration(hours: 1), (_) {
      unawaited(_refreshSubscriptionsAndPing());
    });
  }

  Future<void> _handleConnectivityChanged(
    List<ConnectivityResult> results,
  ) async {
    commonPrint.log('connectivityChanged ${results.toString()}');
    unawaited(systemDnsCoordinator?.resync() ?? Future.value());
    unawaited(ref.read(systemActionProvider.notifier).updateLocalIp());
    final hasVpn = results.contains(ConnectivityResult.vpn);
    if (_preHasVpn == hasVpn) {
      ref.read(routeTrackerProvider.notifier).bumpHostEpoch();
    }
    _preHasVpn = hasVpn;
  }

  @override
  Widget build(context) {
    return Consumer(
      builder: (_, ref, child) {
        final locale = ref.watch(
          appSettingProvider.select((state) => state.locale),
        );
        final themeProps = ref.watch(themeSettingProvider);
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          navigatorKey: globalState.navigatorKey,
          onNavigationNotification: (_) => true,
          localizationsDelegates: const [
            AppLocalizations.delegate,
            ...GlobalMaterialLocalizations.delegates,
          ],
          builder: (context, child) {
            return buildManagerStack(
              isDesktop: system.isDesktop,
              onConnectivityChanged: _handleConnectivityChanged,
              child: RemoteFocusAdapter(enabled: system.isTV, child: child!),
            );
          },
          scrollBehavior: const BaseScrollBehavior(),
          title: appName,
          locale: getLocaleForString(locale),
          supportedLocales: AppLocalizations.delegate.supportedLocales,
          themeMode: themeProps.themeMode,
          theme: ThemeData(
            useMaterial3: true,
            pageTransitionsTheme: _pageTransitionsTheme,
            actionIconTheme: _actionIconTheme,
            colorScheme: _getAppColorScheme(brightness: Brightness.light),
          ).withAppShapes,
          darkTheme: ThemeData(
            useMaterial3: true,
            pageTransitionsTheme: _pageTransitionsTheme,
            actionIconTheme: _actionIconTheme,
            colorScheme: _getAppColorScheme(brightness: Brightness.dark),
          ).withAppShapes,
          home: KeyboardInsetHold(child: child!),
        );
      },
      child: const HomePage(),
    );
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    linkManager.destroy();
    _syncToastTimer?.cancel();
    _syncToastEntry?.remove();
    _syncToastEntry?.dispose();
    _syncToastEntry = null;
    _autoUpdateProfilesTaskTimer?.cancel();
    super.dispose();
  }
}
