const $ = (q, root=document) => root.querySelector(q);
const $$ = (q, root=document) => [...root.querySelectorAll(q)];
const esc = (v='') => String(v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const cleanUrl = (v='') => /^https?:\/\//i.test(String(v)) ? String(v) : '';
const fmtBytes = n => !n ? '—' : n > 1073741824 ? `${(n/1073741824).toFixed(1)} GB` : n > 1048576 ? `${(n/1048576).toFixed(1)} MB` : `${(n/1024).toFixed(0)} KB`;
const pct = (a,b) => b > 0 ? Math.min(100, Math.round(a/b*100)) : 0;
const sleep = ms => new Promise(r => setTimeout(r,ms));

const mockItems = Array.from({length:12},(_,i)=>({
  archive:1,id:`demo-${i+1}`,type:i%3===0?'series':'movie',title:`Midnight ${i+1}`,title_fa:`عنوان نمایشی ${i+1}`,
  year:2026-(i%4),rating:(8.7-i*.08).toFixed(1),poster:'',backdrop:'',description:'نسخه مرورگر فقط برای پیش‌نمایش رابط کاربری است.'
}));
const mockBridge = () => ({
  bootstrap: async()=>({config:{_online:false,active_domain:'https://bankmovie.top',features:{},desktop:{enabled:true,features:{}},app_archive_policy:{},home:{archive1_sections:['updated_movies','updated_series']}},settings:{downloadDir:'Downloads',preferredArchive:1,externalPlayer:false},hasToken:false,version:'preview'}),
  content: async(action,p={})=> action==='boot'?{status:'success',sliders:mockItems.slice(0,4),collections:[],archives:[1,2,3,4,5]}:action==='detail'?{status:'success',item:{...mockItems[0],description:'این پیش‌نمایش آفلاین است. در Electron داده واقعی از bankmovie.top خوانده می‌شود.',genres:['درام','معمایی'],play:{links:[{quality:'1080P',display_label:'1080P • سافت‌ساب',url:'',is_playable:false,is_download:false}]},related:mockItems.slice(1,7)}}:{status:'success',items:mockItems,page:1,has_more:false},
  user:async(a)=>a==='config'?{success:true,features:{},vip:{plans:[]}}:{success:false,message:'در حالت مرورگر حساب کاربری غیرفعال است'},
  getSettings:async()=>({downloadDir:'Downloads',preferredArchive:1,externalPlayer:false}), setSettings:async x=>x, getHistory:async()=>[], saveHistory:async()=>[], clearHistory:async()=>true, chooseDownloadDir:async()=>'Downloads', download:async()=>({id:'demo'}), downloadAction:async()=>true, openExternal:async()=>true, showItem:async()=>true, onDownload:()=>{}, logoutLocal:async()=>true,
  window:{minimize(){},maximize(){},close(){}}
});
const bridge = window.bankmovie || mockBridge();

const state = {
  config:null, settings:null, appVersion:'', user:null, stats:null, userConfig:null,
  archive:1, currentDetail:null, watchlist:[], history:[], downloads:new Map(), party:null, partyTimer:null,
  lastView:'home', homeCache:null, searchPage:1
};

const SECTION_LABELS = {
  updated_movies:'جدیدترین فیلم‌ها',updated_series:'جدیدترین سریال‌ها',new_movies:'فیلم‌های جدید',new_series:'سریال‌های جدید',
  korean_series:'سریال کره‌ای',dubbed:'دوبله فارسی',chinese_series:'سریال چینی',top_2026:'برترین‌های سال',top_movies:'Top 250 فیلم',top_series:'Top 250 سریال',anime:'انیمه',turkish:'ترکی',collections:'کالکشن‌ها',
  animation:'انیمیشن',action:'اکشن',drama:'درام',updated_animations:'انیمیشن‌های بروزشده',updated_anime:'انیمه بروزشده',dubbed_movies:'فیلم دوبله',subtitled_movies:'فیلم زیرنویس',dubbed_series:'سریال دوبله',subtitled_series:'سریال زیرنویس',mini_series:'مینی‌سریال',turkish_series:'سریال ترکی'
};
const ARCHIVE_NAMES={1:'آرشیو ۱',2:'آرشیو ۲',3:'آرشیو ۳',4:'آرشیو ۴',5:'آرشیو ۵'};

function toast(message,type=''){
  const el=$('#toast'); el.textContent=message; el.className=`toast show ${type}`; clearTimeout(toast.t); toast.t=setTimeout(()=>el.className='toast',2600);
}
function setLoading(text='در حال دریافت اطلاعات…'){$('#view').innerHTML=`<div class="loading-screen"><div class="spinner"></div><p>${esc(text)}</p></div>`}
function feature(name, fallback=true){
  const desktop=state.config?.desktop?.features || {}; if(Object.prototype.hasOwnProperty.call(desktop,name)) return !!desktop[name];
  const common=state.config?.features || {}; if(Object.prototype.hasOwnProperty.call(common,name)) return !!common[name]; return fallback;
}
function archivePolicy(no){
  const key=`archive${Number(no)}`; const p=state.config?.app_archive_policy?.[key] || state.config?.archive_policy?.[key] || {};
  const d=state.config?.desktop?.archives?.[key] || {}; return {...p,...d};
}
function enabledArchives(){
  return [1,2,3,4,5].filter(n=>{const p=archivePolicy(n);return p.hidden!==true && p.enabled!==false});
}
function setActiveNav(view){$$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view)); state.lastView=view}
function img(url,alt='',cls=''){return cleanUrl(url)?`<img class="${cls}" src="${esc(url)}" alt="${esc(alt)}" loading="lazy" onerror="this.style.display='none'">`:''}
function itemTitle(it){return it?.title_fa || it?.title || 'بدون عنوان'}
function itemId(it){return it?.id || it?.slug || it?.detail_id || it?.imdb_code || ''}
function card(it){
  const poster=cleanUrl(it.poster||it.image||''); const type=(it.type==='series'?'سریال':'فیلم');
  return `<article class="media-card" data-card='${encodeURIComponent(JSON.stringify({archive:it.archive||state.archive,id:itemId(it),type:it.type||'movie',title:it.title||'',title_fa:it.title_fa||'',poster:poster,year:it.year||'',rating:it.rating||'',source:it.source||'',imdb_code:it.imdb_code||''}))}'>
    <div class="poster">${poster?img(poster,itemTitle(it)):`<div style="height:100%;display:grid;place-items:center;color:#444;font-size:36px">BM</div>`}<span class="card-badge">${esc(it.rating||type)}</span></div>
    <div class="card-info"><strong>${esc(itemTitle(it))}</strong><small><span>${esc(it.year||'')} · ${type}</span><span>${it.rating?'★ '+esc(it.rating):''}</span></small></div>
  </article>`;
}
function bindCards(root=document){
  $$('[data-card]',root).forEach(el=>el.addEventListener('click',()=>{try{openDetail(JSON.parse(decodeURIComponent(el.dataset.card)))}catch(e){toast(e.message,'error')}}));
}
function sectionHtml(title,items,archive,section){
  if(!items?.length)return '';
  return `<section class="section"><div class="section-head"><div><h2>${esc(title)}</h2><small>${esc(ARCHIVE_NAMES[archive]||'')}</small></div><button class="link-btn" data-browse-section="${esc(section)}" data-archive="${archive}">مشاهده همه ‹</button></div><div class="rail">${items.map(card).join('')}</div></section>`;
}
function homeSectionsFor(archive){
  const key=`archive${archive}_sections`; const arr=state.config?.home?.[key]; if(Array.isArray(arr)&&arr.length)return arr;
  return archive===1?['updated_movies','updated_series','dubbed','anime']:archive===2?['updated_movies','updated_series','action','drama']:archive===3?['new_movies','new_series','korean_series']:archive===4?['new_movies','new_series']:['new_movies','new_series','animation'];
}

async function init(){
  bindWindowButtons();
  try{
    const boot=await bridge.bootstrap(); state.config=boot.config||{}; state.settings=boot.settings||{}; state.appVersion=boot.version||''; state.archive=Number(state.settings.preferredArchive||enabledArchives()[0]||1);
    setupArchiveSelect(); applyRemoteNotice(); updateConnectionBadge(); bridge.onDownload(onDownloadUpdate); state.history=await bridge.getHistory();
    if(boot.hasToken) await refreshMe(false); await loadUserConfig(); updateProfile(); bindGlobalUI(); await showHome();
  }catch(e){setLoading('خطا در راه‌اندازی');toast(e.message||'خطای راه‌اندازی','error')}
}
function bindWindowButtons(){
  $$('[data-win]').forEach(b=>b.addEventListener('click',()=>{const a=b.dataset.win;if(a==='min')bridge.window.minimize();if(a==='max')bridge.window.maximize();if(a==='close')bridge.window.close()}));
}
function updateConnectionBadge(){const e=$('#connectionBadge');const online=state.config?._online!==false;e.textContent=online?'متصل به bankmovie.top':'حالت fallback';e.className=online?'online':'offline'}
function setupArchiveSelect(){
  const s=$('#archiveSelect');s.innerHTML=enabledArchives().map(n=>`<option value="${n}" ${n===state.archive?'selected':''}>${ARCHIVE_NAMES[n]}</option>`).join('');
  s.onchange=async()=>{state.archive=Number(s.value);await bridge.setSettings({preferredArchive:state.archive});if(['movies','series'].includes(state.lastView))showBrowse(state.lastView)};
}
function applyRemoteNotice(){
  const n=state.config?.desktop?.notice || state.config?.notice || {}; const el=$('#notice');
  if(n.enabled && (n.message||n.title)){el.innerHTML=`<strong>${esc(n.title||'اطلاعیه')}</strong> ${esc(n.message||'')}`;el.classList.remove('hidden')} else el.classList.add('hidden');
}
async function loadUserConfig(){try{state.userConfig=await bridge.user('config',{},'POST')}catch{state.userConfig={features:{}}}}
async function refreshMe(noisy=true){
  try{const r=await bridge.user('me',{},'POST');if(r?.success){state.user=r.user;state.stats=r.stats||null}else state.user=null}catch(e){state.user=null;if(noisy)toast(e.message,'error')}updateProfile();return state.user;
}
function updateProfile(){
  const name=$('#profileName'),hint=$('#profileHint'),av=$('#profileAvatar');
  if(state.user){name.textContent=state.user.full_name||state.user.username||'کاربر';hint.textContent=state.user.is_vip?'VIP فعال':(state.user.email||'حساب کاربری');av.innerHTML=cleanUrl(state.user.avatar)?img(state.user.avatar,'avatar'):esc((state.user.username||'BM').slice(0,2).toUpperCase())}
  else{name.textContent='حساب کاربری';hint.textContent='ورود / ثبت‌نام';av.textContent='BM'}
}
function bindGlobalUI(){
  $('#nav').addEventListener('click',e=>{const b=e.target.closest('[data-view]');if(!b)return;route(b.dataset.view)});
  $('#profileNav').onclick=()=>showProfile();
  $('#refreshBtn').onclick=()=>route(state.lastView,true);
  $('#quickSearch').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.currentTarget.value.trim())showSearch(e.currentTarget.value.trim())});
  document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#quickSearch').focus()}});
  $('#modal').addEventListener('click',e=>{if(e.target.matches('[data-close-modal]'))closeModal()});
}
async function route(view,force=false){
  setActiveNav(view); if(state.partyTimer&&view!=='party'){clearInterval(state.partyTimer);state.partyTimer=null}
  if(view==='home')return showHome(force);if(view==='movies'||view==='series')return showBrowse(view);if(view==='search')return showSearch('');
  if(view==='watchlist')return showWatchlist();if(view==='downloads')return showDownloads();if(view==='notifications')return showNotifications();if(view==='party')return showParty();if(view==='settings')return showSettings();
}

async function showHome(force=false){
  setActiveNav('home'); setLoading('در حال چیدن صفحه اصلی…');
  try{
    if(!state.homeCache||force){
      const boot=await bridge.content('boot',{limit:12});
      const archives=enabledArchives(); const rails=[];
      for(const a of archives){
        const sections=homeSectionsFor(a).filter(x=>x!=='collections').slice(0,a===state.archive?3:1);
        for(const sec of sections){try{const r=await bridge.content('section',{archive:a,section:sec,page:1,limit:14});if(r?.items?.length)rails.push({a,sec,items:r.items})}catch{}}
      }
      state.homeCache={boot,rails};
    }
    renderHome(state.homeCache);
  }catch(e){$('#view').innerHTML=`<div class="empty">${esc(e.message)}</div>`;toast(e.message,'error')}
}
function renderHome({boot,rails}){
  const sliders=boot?.sliders?.length?boot.sliders:(rails[0]?.items||mockItems);const hero=sliders[0]||mockItems[0];
  const bg=cleanUrl(hero.backdrop||hero.background||hero.poster||'');
  const continueItems=(state.history||[]).slice(0,12).map(h=>h.item).filter(Boolean);
  $('#view').innerHTML=`<section class="hero">${bg?`<div class="hero-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="hero-content"><div class="eyebrow">BANKMOVIE • WINDOWS</div><h1>${esc(itemTitle(hero))}<small>${esc(hero.title&&hero.title!==itemTitle(hero)?hero.title:'')}</small></h1><div class="meta"><span class="chip gold">★ ${esc(hero.rating||'—')}</span><span class="chip">${esc(hero.year||'')}</span><span class="chip">${hero.type==='series'?'سریال':'فیلم'}</span><span class="chip">${esc(ARCHIVE_NAMES[hero.archive||1])}</span></div><p class="desc">${esc(hero.description||hero.update_note||'جدیدترین عنوان منتخب بانک‌مووی')}</p><div class="actions"><button class="btn primary" id="heroOpen">▶ مشاهده جزئیات</button><button class="btn ghost" id="heroWatchlist">♡ لیست من</button></div></div></section>${continueItems.length?sectionHtml('ادامه تماشا',continueItems,0,'continue_watching'):''}${rails.map(r=>sectionHtml(SECTION_LABELS[r.sec]||r.sec,r.items,r.a,r.sec)).join('')}`;
  $('#heroOpen').onclick=()=>openDetail(hero);$('#heroWatchlist').onclick=()=>quickWatchlist(hero);bindCards();
  $$('[data-browse-section]').forEach(b=>b.onclick=()=>{if(b.dataset.browseSection==='continue_watching')return;showBrowseSection(Number(b.dataset.archive),b.dataset.browseSection)});
}

async function showBrowse(kind='movies'){
  setActiveNav(kind);setLoading();const type=kind==='series'?'series':'movie';const sec=type==='series'?(state.archive<=2?'updated_series':'new_series'):(state.archive<=2?'updated_movies':'new_movies');
  try{const r=await bridge.content('section',{archive:state.archive,section:sec,page:1,limit:48});renderGridPage(kind==='series'?'سریال‌ها':'فیلم‌ها',`${ARCHIVE_NAMES[state.archive]} • ${SECTION_LABELS[sec]||sec}`,r.items||[])}catch(e){renderError(e)}
}
async function showBrowseSection(archive,section){
  state.archive=archive;$('#archiveSelect').value=String(archive);setActiveNav(section.includes('series')?'series':'movies');setLoading();
  try{const r=await bridge.content('section',{archive,section,page:1,limit:60});renderGridPage(SECTION_LABELS[section]||section,ARCHIVE_NAMES[archive],r.items||[])}catch(e){renderError(e)}
}
function renderGridPage(title,sub,items){$('#view').innerHTML=`<div class="page-title"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><span class="chip">${items.length} عنوان</span></div>${items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">موردی پیدا نشد.</div>'}`;bindCards()}

async function showSearch(initial=''){
  setActiveNav('search');
  $('#view').innerHTML=`<div class="page-title"><div><h1>جستجوی پیشرفته</h1><p>عنوان، ژانر، کشور، سال و نوع محتوا</p></div></div><form id="searchForm" class="filters"><input class="form-control" name="q" placeholder="نام فیلم یا سریال" value="${esc(initial)}"><select name="archive"><option value="all">همه آرشیوها</option>${enabledArchives().map(n=>`<option value="${n}">${ARCHIVE_NAMES[n]}</option>`).join('')}</select><select name="type"><option value="">همه</option><option value="movie">فیلم</option><option value="series">سریال</option></select><input class="form-control" name="genre" placeholder="ژانر"><input class="form-control" name="country" placeholder="کشور"><button class="btn primary">جستجو</button></form><div id="searchResults"><div class="empty">عبارت جستجو را وارد کن.</div></div>`;
  const f=$('#searchForm');f.onsubmit=async e=>{e.preventDefault();await performSearch(new FormData(f))};if(initial)performSearch(new FormData(f));
}
async function performSearch(fd){
  const out=$('#searchResults');out.innerHTML='<div class="loading-screen" style="height:280px"><div class="spinner"></div></div>';
  const p=Object.fromEntries(fd.entries());p.page=1;p.limit=60;
  try{const r=await bridge.content('search',p);const items=r.items||r.results||[];out.innerHTML=items.length?`<div class="grid">${items.map(card).join('')}</div>`:'<div class="empty">نتیجه‌ای پیدا نشد.</div>';bindCards(out)}catch(e){out.innerHTML=`<div class="empty">${esc(e.message)}</div>`}
}

async function openDetail(item){
  setLoading('در حال دریافت جزئیات…');
  try{const r=await bridge.content('detail',{archive:item.archive||state.archive,id:itemId(item),type:item.type||''});state.currentDetail=r.item||r;renderDetail(state.currentDetail);loadComments(state.currentDetail)}catch(e){renderError(e)}
}
function renderDetail(d){
  const bg=cleanUrl(d.backdrop||d.background||d.poster||'');const poster=cleanUrl(d.poster||'');const links=d.play?.links||d.downloads||d.links||[];const related=d.related||[];
  const inList=state.watchlist.some(w=>watchKey(w)===watchKey(d));
  $('#view').innerHTML=`<div class="detail"><section class="detail-hero">${bg?`<div class="detail-bg" style="background-image:url('${esc(bg)}')"></div>`:''}<div class="detail-inner"><div class="detail-copy"><div class="eyebrow">${esc(ARCHIVE_NAMES[d.archive]||'BANKMOVIE')}</div><h1 class="detail-title">${esc(itemTitle(d))}</h1><div class="meta"><span class="chip gold">★ ${esc(d.rating||'—')}</span><span class="chip">${esc(d.year||'')}</span><span class="chip">${d.type==='series'?'سریال':'فیلم'}</span>${(d.genres||[]).slice(0,3).map(g=>`<span class="chip">${esc(typeof g==='string'?g:(g.name||g.title||''))}</span>`).join('')}</div><p class="description">${esc(d.long_description||d.description||'توضیحی ثبت نشده است.')}</p><div class="actions"><button class="btn red" id="playBest">▶ پخش</button><button class="btn ghost" id="watchBtn">${inList?'♥ حذف از لیست':'♡ افزودن به لیست'}</button>${d.trailer_url?'<button class="btn ghost" id="trailerBtn">تریلر</button>':''}</div></div>${poster?`<img class="detail-poster" src="${esc(poster)}">`:''}</div></section><div class="detail-body"><div class="tabs"><button class="tab active" data-detail-tab="sources">پخش و دانلود</button><button class="tab" data-detail-tab="comments">دیدگاه‌ها</button><button class="tab" data-detail-tab="info">اطلاعات</button></div><div id="detailTab">${renderSources(d,links)}</div>${related.length?`<section class="section"><div class="section-head"><h2>پیشنهادهای مشابه</h2></div><div class="rail">${related.map(card).join('')}</div></section>`:''}</div></div>`;
  bindCards();$('#watchBtn').onclick=()=>quickWatchlist(d,true);if($('#trailerBtn'))$('#trailerBtn').onclick=()=>bridge.openExternal(d.trailer_url);
  $('#playBest').onclick=()=>{const s=links.find(x=>x.is_playable!==false&&x.url)||links.find(x=>x.url);s?playSource(s):toast('لینک پخش موجود نیست','error')};
  $$('[data-source-play]').forEach(b=>b.onclick=()=>playSource(links[Number(b.dataset.sourcePlay)]));$$('[data-source-download]').forEach(b=>b.onclick=()=>downloadSource(links[Number(b.dataset.sourceDownload)],d));
  $$('[data-detail-tab]').forEach(t=>t.onclick=()=>switchDetailTab(t.dataset.detailTab,d,links,t));
}
function renderSources(d,links){
  if(!links.length)return '<div class="empty">برای این عنوان لینک پخش یا دانلودی موجود نیست.</div>';
  const rows=links.map((s,i)=>`<div class="source-row"><div class="source-main"><span class="quality">${esc(s.quality||'AUTO')}</span><span><strong>${esc(s.display_label||s.label||s.type_fa||'نسخه رسانه')}</strong><small>${s.season?`فصل ${s.season} `:''}${s.episode?`قسمت ${s.episode} `:''}${esc(s.size||'')}</small></span></div><div class="source-actions">${s.is_playable!==false&&s.url?`<button class="btn ghost slim" data-source-play="${i}">▶ پخش</button>`:''}${s.is_download!==false&&s.url?`<button class="btn primary slim" data-source-download="${i}">⇩ دانلود</button>`:''}</div></div>`).join('');
  return `<div class="sources">${rows}</div>`;
}
function switchDetailTab(name,d,links,tab){$$('[data-detail-tab]').forEach(x=>x.classList.remove('active'));tab.classList.add('active');const box=$('#detailTab');if(name==='sources')box.innerHTML=renderSources(d,links),bindSourceButtons(d,links);if(name==='comments')renderCommentsBox(d);if(name==='info')box.innerHTML=renderInfo(d)}
function bindSourceButtons(d,links){$$('[data-source-play]').forEach(b=>b.onclick=()=>playSource(links[Number(b.dataset.sourcePlay)]));$$('[data-source-download]').forEach(b=>b.onclick=()=>downloadSource(links[Number(b.dataset.sourceDownload)],d))}
function renderInfo(d){return `<div class="panel"><div class="form-grid"><div class="field"><label>عنوان اصلی</label><div>${esc(d.title||'—')}</div></div><div class="field"><label>سال</label><div>${esc(d.year||'—')}</div></div><div class="field"><label>زبان</label><div>${esc(d.language||'—')}</div></div><div class="field"><label>کشور</label><div>${esc(Array.isArray(d.country)?d.country.join('، '):(d.country||'—'))}</div></div><div class="field"><label>شبکه</label><div>${esc(d.network||'—')}</div></div><div class="field"><label>مدت</label><div>${esc(d.runtime||'—')}</div></div></div></div>`}
async function playSource(s){
  if(!s?.url)return toast('لینک پخش معتبر نیست','error');if(state.settings?.externalPlayer)return bridge.openExternal(s.url);
  openModal(`<button class="icon-btn close-modal" data-close-player>×</button><div class="player-wrap"><video controls autoplay playsinline src="${esc(s.url)}"></video></div>`,true);$('[data-close-player]').onclick=closeModal;
  const v=$('#modal video'),d=state.currentDetail;if(v&&d){const key=watchKey(d);const prior=(state.history||[]).find(x=>x.key===key&&x.sourceUrl===s.url);v.addEventListener('loadedmetadata',()=>{if(prior?.position>5&&prior.position<v.duration-15)v.currentTime=prior.position},{once:true});let last=0;v.addEventListener('timeupdate',async()=>{if(Date.now()-last<5000)return;last=Date.now();state.history=await bridge.saveHistory({key,item:{archive:d.archive,id:itemId(d),type:d.type,title:d.title,title_fa:d.title_fa,poster:d.poster,year:d.year,rating:d.rating,source:d.source},sourceUrl:s.url,quality:s.quality||'',position:Math.floor(v.currentTime||0),duration:Math.floor(v.duration||0)});});}
}
async function downloadSource(s,d){try{const ext=(()=>{try{return new URL(s.url).pathname.split('.').pop().split(/[?#]/)[0]}catch{return 'mp4'}})();const name=`${itemTitle(d)}${s.season?` - S${s.season}`:''}${s.episode?`E${s.episode}`:''} - ${s.quality||'video'}.${ext}`;await bridge.download({url:s.url,fileName:name,title:itemTitle(d),quality:s.quality||'',poster:d.poster||''});toast('دانلود به صف اضافه شد','ok');$('#downloadCount').textContent=String(Math.max(1,state.downloads.size))}catch(e){toast(e.message,'error')}}

function watchKey(it){return it?.storage_key||it?._key||`${it?.archive||1}|${it?.type||'movie'}|${itemId(it)}`}
async function ensureWatchlist(){if(!state.user)return[];try{const r=await bridge.user('watchlist_list',{},'POST');state.watchlist=r.items||[];return state.watchlist}catch{return[]}}
async function quickWatchlist(item,rerender=false){
  if(!state.user){showAuthModal();return}await ensureWatchlist();const key=watchKey(item);const old=state.watchlist.find(x=>watchKey(x)===key);
  try{const body=old?{removed_keys:[watchKey(old)],items:[]}:{removed_keys:[],items:[item]};const r=await bridge.user('watchlist_sync',body,'POST');state.watchlist=r.items||[];toast(old?'از لیست حذف شد':'به لیست اضافه شد','ok');if(rerender&&state.currentDetail)renderDetail(state.currentDetail)}catch(e){toast(e.message,'error')}
}
async function showWatchlist(){setActiveNav('watchlist');if(!state.user)return showAuthGate('برای دیدن لیست شخصی وارد حساب شو.');setLoading();await ensureWatchlist();renderGridPage('لیست من','همگام با حساب BankMovie',state.watchlist)}

let commentsCache=[];
async function loadComments(d){try{const r=await bridge.user('comments_list',{item:d,page:1,limit:20,sort:'latest'},'POST');commentsCache=r.items||r.comments||[]}catch{commentsCache=[]}}
function renderCommentsBox(d){
  const box=$('#detailTab');box.innerHTML=`${state.user?`<div class="comment-form"><textarea class="form-control" id="commentText" placeholder="دیدگاهت را بنویس…"></textarea><button class="btn primary" id="sendComment">ارسال</button></div>`:'<div class="panel" style="margin-bottom:10px">برای ثبت دیدگاه وارد حساب شو.</div>'}<div id="commentsList" class="comments">${commentsCache.length?commentsCache.map(c=>commentHtml(c,0)).join(''):'<div class="empty">هنوز دیدگاهی ثبت نشده است.</div>'}</div>`;
  if($('#sendComment'))$('#sendComment').onclick=async()=>{const text=$('#commentText').value.trim();if(text.length<3)return toast('متن دیدگاه کوتاه است','error');try{await bridge.user('comment_add',{item:d,comment:text,rating:0,spoiler:0},'POST');$('#commentText').value='';await reloadComments(d,'دیدگاه ثبت شد')}catch(e){toast(e.message,'error')}};
  $$('[data-comment-action]').forEach(b=>b.onclick=()=>commentAction(b.dataset.commentAction,Number(b.dataset.commentId),b.dataset.commentText||'',d));
}
function commentHtml(c,depth=0){
  const buttons=state.user?`<div class="source-actions" style="margin-top:8px;justify-content:flex-start;flex-wrap:wrap"><button class="btn ghost slim" data-comment-action="like" data-comment-id="${c.id}">👍 ${c.like_count||0}</button><button class="btn ghost slim" data-comment-action="dislike" data-comment-id="${c.id}">👎 ${c.dislike_count||0}</button><button class="btn ghost slim" data-comment-action="reply" data-comment-id="${c.id}">پاسخ</button>${c.can_report?`<button class="btn ghost slim" data-comment-action="report" data-comment-id="${c.id}">گزارش</button>`:''}${c.can_edit?`<button class="btn ghost slim" data-comment-action="edit" data-comment-id="${c.id}" data-comment-text="${esc(c.comment_raw||c.comment||'')}">ویرایش</button>`:''}${c.can_pin?`<button class="btn ghost slim" data-comment-action="pin" data-comment-id="${c.id}">${c.is_pinned?'برداشتن پین':'پین'}</button>`:''}${c.can_delete?`<button class="btn ghost slim" data-comment-action="delete" data-comment-id="${c.id}">حذف</button>`:''}</div>`:'';
  return `<div class="comment" style="margin-right:${Math.min(depth,3)*18}px"><div class="comment-head"><strong>${esc(c.username||c.user?.username||'کاربر')} ${c.badge?`• ${esc(c.badge)}`:''}</strong><span>${esc(c.date_text||c.created_at||'')}</span></div><p>${c.spoiler?'⚠️ Spoiler — ':''}${esc(c.comment||c.text||'')}</p>${buttons}${(c.replies||[]).map(r=>commentHtml(r,depth+1)).join('')}</div>`
}
async function reloadComments(d,message=''){await loadComments(d);renderCommentsBox(d);if(message)toast(message,'ok')}
async function commentAction(action,id,text,d){
  if(!state.user)return showAuthModal();
  try{
    if(action==='like'||action==='dislike')await bridge.user('comment_vote',{item:d,comment_id:id,type:action},'POST');
    else if(action==='reply'){const v=prompt('متن پاسخ:');if(!v)return;await bridge.user('comment_reply',{item:d,parent_id:id,comment:v,rating:0,spoiler:0},'POST')}
    else if(action==='report'){const v=prompt('توضیح گزارش (اختیاری):','');if(v===null)return;await bridge.user('comment_report',{item:d,comment_id:id,reason:'other',details:v},'POST')}
    else if(action==='edit'){const v=prompt('ویرایش دیدگاه:',text);if(!v)return;await bridge.user('comment_edit',{item:d,comment_id:id,comment:v,spoiler:0},'POST')}
    else if(action==='pin')await bridge.user('comment_pin',{item:d,comment_id:id},'POST');
    else if(action==='delete'){if(!confirm('دیدگاه حذف شود؟'))return;await bridge.user('comment_delete',{item:d,comment_id:id},'POST')}
    await reloadComments(d,action==='report'?'گزارش ثبت شد':'انجام شد');
  }catch(e){toast(e.message,'error')}
}

function onDownloadUpdate(d){state.downloads.set(d.id,d);$('#downloadCount').textContent=[...state.downloads.values()].filter(x=>!['completed','cancelled','interrupted'].includes(x.state)).length||'';if(state.lastView==='downloads')renderDownloads()}
function showDownloads(){setActiveNav('downloads');renderDownloads()}
function renderDownloads(){
  const arr=[...state.downloads.values()];$('#view').innerHTML=`<div class="page-title"><div><h1>دانلودها</h1><p>${esc(state.settings?.downloadDir||'')}</p></div><button class="btn ghost" id="chooseFolder">تغییر پوشه</button></div><div id="downloadRows">${arr.length?arr.map(downloadHtml).join(''):'<div class="empty">هنوز دانلودی در این نشست شروع نشده است.</div>'}</div>`;
  $('#chooseFolder').onclick=async()=>{state.settings.downloadDir=await bridge.chooseDownloadDir();renderDownloads()};$$('[data-dl-action]').forEach(b=>b.onclick=()=>bridge.downloadAction(b.dataset.id,b.dataset.dlAction));$$('[data-show-file]').forEach(b=>b.onclick=()=>bridge.showItem(b.dataset.showFile));
}
function downloadHtml(d){const p=pct(d.received,d.total);return `<div class="download-row"><div><strong>${esc(d.title||d.fileName||'دانلود')}</strong><small>${esc(d.quality||'')} • ${fmtBytes(d.received)} / ${fmtBytes(d.total)}</small><div class="progress"><i style="width:${p}%"></i></div></div><div><span class="chip">${esc(d.state||'شروع')}</span></div><div class="source-actions">${d.state==='progressing'&&!d.paused?`<button class="btn ghost slim" data-dl-action="pause" data-id="${d.id}">توقف</button>`:''}${d.paused?`<button class="btn primary slim" data-dl-action="resume" data-id="${d.id}">ادامه</button>`:''}${d.state==='completed'&&d.savePath?`<button class="btn ghost slim" data-show-file="${esc(d.savePath)}">فایل</button>`:`<button class="btn ghost slim" data-dl-action="cancel" data-id="${d.id}">لغو</button>`}</div></div>`}

async function showNotifications(){
  setActiveNav('notifications');if(!state.user)return showAuthGate('اعلان‌ها بعد از ورود به حساب نمایش داده می‌شوند.');setLoading();
  try{const r=await bridge.user('notifications_list',{page:1,limit:40},'POST');const items=r.items||[];state.stats=r.stats||state.stats;$('#notifCount').textContent=state.stats?.unread_notifications||'';$('#view').innerHTML=`<div class="page-title"><div><h1>اعلان‌ها</h1><p>پیام‌های شخصی و مدیریتی</p></div><button class="btn ghost" id="readAll">خواندن همه</button></div>${items.length?`<div class="comments">${items.map(n=>`<div class="comment"><div class="comment-head"><strong>${esc(n.title||'اعلان')}</strong><span>${esc(n.date_text||'')}</span></div><p>${esc(n.message||'')}</p></div>`).join('')}</div>`:'<div class="empty">اعلان جدیدی نداری.</div>'}`;$('#readAll').onclick=async()=>{await bridge.user('notifications_read_all',{},'POST');toast('همه اعلان‌ها خوانده شد','ok');showNotifications()}}catch(e){renderError(e)}
}

async function showParty(){
  setActiveNav('party');setLoading('در حال آماده‌سازی Watch Party…');
  try{const st=await bridge.user('watch_party_status',{},'POST');if(!st.enabled)return renderGridPage('Watch Party','این قابلیت غیرفعال است',[]);renderPartyLobby(st)}catch(e){renderError(e)}
}
function renderPartyLobby(st){
  $('#view').innerHTML=`<div class="page-title"><div><h1>Watch Party</h1><p>تماشای همزمان، چت و کنترل میزبان</p></div><span class="chip ${st.is_vip?'gold':''}">${st.is_vip?'VIP':'حساب عادی'}</span></div><div class="settings-grid"><div class="panel"><h3>ورود به اتاق</h3><div class="field"><label>کد اتاق</label><input id="roomCode" placeholder="مثلاً ABC123"></div><div style="margin-top:10px"><button class="btn primary" id="joinRoom">ورود</button></div></div><div class="panel"><h3>ساخت اتاق</h3><p style="color:#858990;font-size:11px;line-height:1.8">ساخت اتاق برای VIP فعال است. اگر از صفحه جزئیات وارد شوی، عنوان فعلی خودکار به اتاق منتقل می‌شود.</p><button class="btn ghost" id="createRoom" ${st.is_vip?'':'disabled'}>ساخت برای عنوان فعلی</button></div></div>`;
  $('#joinRoom').onclick=()=>joinParty($('#roomCode').value.trim());$('#createRoom').onclick=()=>createParty();
}
async function createParty(){if(!state.currentDetail)return toast('اول یک فیلم یا سریال باز کن','error');try{const d=state.currentDetail;const source=(d.play?.links||[]).find(x=>x.url)||{};const r=await bridge.user('watch_party_create',{movie_id:Number(d.db_id||d.movie_id||0),archive_no:Number(d.archive||1),media_type:d.type||'movie',source_ref:itemId(d),source_url:source.url||'',subtitle_url:'',content_title:itemTitle(d),poster_url:d.poster||''},'POST');const code=r.room?.invite_code||r.room?.room_code;if(code)openPartyRoom(code,r.room)}catch(e){toast(e.message,'error')}}
async function joinParty(code){if(!code)return toast('کد اتاق را وارد کن','error');try{const r=await bridge.user('watch_party_join',{room_code:code},'POST');openPartyRoom(code,r.membership||{})}catch(e){toast(e.message,'error')}}
function openPartyRoom(code,meta={}){state.party={code,afterEvent:0,afterMessage:0};renderPartyRoom(code,meta);pollParty();state.partyTimer=setInterval(pollParty,3500)}
function renderPartyRoom(code,meta){$('#view').innerHTML=`<div class="page-title"><div><h1>اتاق ${esc(code)}</h1><p>${esc(meta.content_title||'Watch Party فعال')}</p></div><button class="btn ghost" id="leaveParty">خروج</button></div><div class="party-shell"><div class="panel"><h3>وضعیت پخش</h3><div id="partyState" class="empty" style="padding:40px">در حال همگام‌سازی…</div></div><div class="panel party-chat"><h3>گفتگو</h3><div class="chat-list" id="chatList"></div><div class="chat-compose"><input class="form-control" id="chatText" placeholder="پیام…"><button class="btn primary" id="sendChat">ارسال</button></div></div></div>`;$('#leaveParty').onclick=async()=>{try{await bridge.user('watch_party_leave',{room_code:code},'POST')}catch{}state.party=null;clearInterval(state.partyTimer);state.partyTimer=null;showParty()};$('#sendChat').onclick=sendPartyMessage}
async function pollParty(){if(!state.party)return;try{const r=await bridge.user('watch_party_poll',{room_code:state.party.code,after_event_id:state.party.afterEvent,after_message_id:state.party.afterMessage},'POST');const ev=r.events||[];const msg=r.messages||[];if(ev.length)state.party.afterEvent=Math.max(state.party.afterEvent,...ev.map(x=>Number(x.id||x.event_id||0)));if(msg.length){state.party.afterMessage=Math.max(state.party.afterMessage,...msg.map(x=>Number(x.id||x.message_id||0)));const list=$('#chatList');if(list){msg.forEach(m=>list.insertAdjacentHTML('beforeend',`<div class="chat-msg"><strong>${esc(m.username||m.display_name||'کاربر')}:</strong> ${esc(m.text||m.message||'')}</div>`));list.scrollTop=list.scrollHeight}}if($('#partyState')){const s=r.state||{};$('#partyState').innerHTML=`<div class="meta"><span class="chip">${s.is_paused?'⏸ توقف':'▶ در حال پخش'}</span><span class="chip">${Math.round(Number(s.position_seconds||0))} ثانیه</span><span class="chip">${esc(r.member_role||'guest')}</span></div>`}}catch(e){console.warn(e)}}
async function sendPartyMessage(){const input=$('#chatText');const m=input?.value.trim();if(!m||!state.party)return;try{await bridge.user('watch_party_message',{room_code:state.party.code,message:m,client_message_id:`win-${Date.now()}`},'POST');input.value='';await pollParty()}catch(e){toast(e.message,'error')}}

function showProfile(){setActiveNav('');if(state.user)return renderProfile();showAuthModal()}
function renderProfile(){
  $('#view').innerHTML=`<div class="page-title"><div><h1>${esc(state.user.full_name||state.user.username)}</h1><p>${esc(state.user.email||'')}</p></div><span class="chip gold">${state.user.is_vip?'VIP فعال':'کاربر BankMovie'}</span></div><div class="settings-grid"><div class="panel"><h3>حساب</h3><p>نام کاربری: ${esc(state.user.username||'')}</p><p>عضویت VIP: ${state.user.is_vip?'فعال':'غیرفعال'}</p><p>انقضا: ${esc(state.user.vip_expires_at||'—')}</p><div class="actions"><button class="btn ghost" id="avatarBtn">تغییر آواتار</button><button class="btn ghost" id="logoutBtn">خروج از حساب</button></div></div><div class="panel"><h3>آمار</h3><div class="meta"><span class="chip">لیست من: ${state.stats?.watchlist_count||0}</span><span class="chip">اعلان خوانده‌نشده: ${state.stats?.unread_notifications||0}</span></div></div></div>`;
  $('#avatarBtn').onclick=showAvatarModal;
  $('#logoutBtn').onclick=async()=>{try{await bridge.user('logout',{},'POST')}catch{}await bridge.logoutLocal();state.user=null;state.watchlist=[];updateProfile();showHome();toast('از حساب خارج شدی','ok')}
}
async function showAvatarModal(){const avatars=state.userConfig?.avatars||[];openModal(`<button class="icon-btn close-modal" data-close-avatar>×</button><h2>انتخاب آواتار</h2><div class="grid" style="grid-template-columns:repeat(4,1fr)">${avatars.map(a=>`<button class="panel" style="cursor:pointer;color:#fff" data-avatar="${esc(a.key)}">${img(a.url,a.label)}<div>${esc(a.label)}</div></button>`).join('')}</div>${state.user?.can_upload_avatar?`<div class="field" style="margin-top:12px"><label>آواتار اختصاصی VIP</label><input type="file" id="avatarFile" accept="image/png,image/jpeg,image/webp,image/gif"></div>`:''}`);$('[data-close-avatar]').onclick=closeModal;$$('[data-avatar]').forEach(b=>b.onclick=async()=>{try{const r=await bridge.user('avatar_update',{avatar_key:b.dataset.avatar},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار ذخیره شد','ok')}catch(e){toast(e.message,'error')}});if($('#avatarFile'))$('#avatarFile').onchange=e=>{const f=e.target.files?.[0];if(!f)return;const rd=new FileReader();rd.onload=async()=>{try{const r=await bridge.user('avatar_upload',{image_base64:rd.result},'POST');state.user=r.user;updateProfile();closeModal();toast('آواتار اختصاصی ذخیره شد','ok')}catch(err){toast(err.message,'error')}};rd.readAsDataURL(f)}}
function showAuthGate(text){$('#view').innerHTML=`<div class="empty"><p>${esc(text)}</p><button class="btn primary" id="authGateBtn">ورود / ثبت‌نام</button></div>`;$('#authGateBtn').onclick=showAuthModal}
function showAuthModal(){
  openModal(`<button class="icon-btn close-modal" data-close-auth>×</button><div style="min-width:min(470px,80vw)"><div class="page-title"><div><h1>حساب BankMovie</h1><p>ورود و لیست شخصی روی همه دستگاه‌ها</p></div></div><div class="tabs"><button class="tab active" data-auth-tab="login">ورود</button><button class="tab" data-auth-tab="register">ثبت‌نام</button></div><div id="authBody">${loginForm()}</div></div>`);$('[data-close-auth]').onclick=closeModal;$$('[data-auth-tab]').forEach(t=>t.onclick=()=>{$$('[data-auth-tab]').forEach(x=>x.classList.remove('active'));t.classList.add('active');$('#authBody').innerHTML=t.dataset.authTab==='login'?loginForm():registerForm();bindAuthForms()});bindAuthForms();
}
function loginForm(){return `<form id="loginForm" class="form-grid"><div class="field full"><label>نام کاربری یا ایمیل</label><input name="identity" required></div><div class="field full"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field full"><button class="btn primary">ورود</button></div></form>`}
function registerForm(){return `<form id="registerForm" class="form-grid"><div class="field full"><label>نام کاربری</label><input name="username" required></div><div class="field full"><label>ایمیل</label><input name="email" type="email" required></div><div class="field"><label>رمز عبور</label><input name="password" type="password" required></div><div class="field"><label>تکرار رمز</label><input name="confirm_password" type="password" required></div><div class="field full"><button class="btn primary">ساخت حساب</button></div></form>`}
function bindAuthForms(){
  if($('#loginForm'))$('#loginForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('login',b,'POST');if(!r.success)throw new Error(r.message||'ورود انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('خوش آمدی','ok');route(state.lastView||'home')}catch(err){toast(err.message,'error')}};
  if($('#registerForm'))$('#registerForm').onsubmit=async e=>{e.preventDefault();const b=Object.fromEntries(new FormData(e.currentTarget));try{const r=await bridge.user('register',b,'POST');if(!r.success)throw new Error(r.message||'ثبت‌نام انجام نشد');state.user=r.user;state.stats=r.stats;closeModal();updateProfile();toast('حساب ساخته شد','ok')}catch(err){toast(err.message,'error')}};
}

async function showSettings(){
  setActiveNav('settings');state.settings=await bridge.getSettings();const cfg=state.config||{};const df=cfg.desktop?.features||{};
  $('#view').innerHTML=`<div class="page-title"><div><h1>تنظیمات</h1><p>نسخه ${esc(state.appVersion)} • ${esc(cfg.active_domain||'bankmovie.top')}</p></div></div><div class="settings-grid"><div class="panel"><h3>پخش و دانلود</h3><div class="field"><label>پوشه دانلود</label><input id="downloadDir" value="${esc(state.settings.downloadDir||'')}" readonly></div><div style="margin-top:8px"><button class="btn ghost" id="chooseDir">انتخاب پوشه</button></div><div class="field" style="margin-top:14px"><label><input type="checkbox" id="externalPlayer" ${state.settings.externalPlayer?'checked':''}> باز کردن لینک پخش با برنامه/مرورگر سیستم</label></div></div><div class="panel"><h3>کنترل ریموت</h3><div class="field"><label>Controller</label><input id="controllerUrl" dir="ltr" value="${esc(state.settings.controllerUrl||'https://bankmovie.top/desktop_config.php')}"></div><div class="meta"><span class="chip">API: ${esc(cfg.api_url||'')}</span></div><div class="actions"><button class="btn primary" id="saveSettings">ذخیره و اتصال مجدد</button><button class="btn ghost" id="clearHistory">پاک کردن تاریخچه تماشا</button></div></div><div class="panel"><h3>قابلیت‌های فعال</h3><div class="meta">${Object.entries({...cfg.features,...df}).filter(([,v])=>typeof v==='boolean'&&v).slice(0,18).map(([k])=>`<span class="chip">${esc(k.replaceAll('_',' '))}</span>`).join('')}</div></div><div class="panel"><h3>آرشیوها</h3>${enabledArchives().map(n=>{const p=archivePolicy(n);return `<div class="source-row"><div class="source-main"><span class="quality">${n}</span><span><strong>${ARCHIVE_NAMES[n]}</strong><small>${esc(p.access_scope||'public')} • download: ${esc(p.download_access_scope||'public')}</small></span></div></div>`}).join('')}</div></div>`;
  $('#chooseDir').onclick=async()=>{$('#downloadDir').value=await bridge.chooseDownloadDir()};$('#saveSettings').onclick=async()=>{state.settings=await bridge.setSettings({externalPlayer:$('#externalPlayer').checked,controllerUrl:$('#controllerUrl').value.trim()});toast('تنظیمات ذخیره شد؛ برای دریافت کانفیگ جدید Refresh را بزن.','ok')};$('#clearHistory').onclick=async()=>{await bridge.clearHistory();state.history=[];toast('تاریخچه پاک شد','ok')};
}

function openModal(html,wide=false){const m=$('#modal'),b=$('#modalBox');b.innerHTML=html;b.style.maxWidth=wide?'min(1150px,94vw)':'';b.style.padding=wide?'10px':'19px';m.classList.remove('hidden')}
function closeModal(){$('#modal').classList.add('hidden');const v=$('#modal video');if(v){v.pause();v.removeAttribute('src')}}
function renderError(e){$('#view').innerHTML=`<div class="empty"><h3>ارتباط با سرور انجام نشد</h3><p>${esc(e.message||e)}</p><button class="btn ghost" id="retryBtn">تلاش دوباره</button></div>`;$('#retryBtn').onclick=()=>route(state.lastView,true);toast(e.message||String(e),'error')}

document.addEventListener('DOMContentLoaded',init);
