const { app, BrowserWindow, ipcMain, dialog, shell, session, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const AUTH = require('./desktop-auth.generated');

const DEFAULT = Object.freeze({
  controllerUrl: 'https://bankmovie.top/desktop_config.php',
  domain: 'https://bankmovie.top',
  apiUrl: 'https://bankmovie.top/desktop_api.php',
  fallbackApiUrl: 'https://bankmovie.top/app_api.php',
  accountApiUrl: 'https://bankmovie.top/app_user_api.php'
});

let win = null;
let runtimeConfig = null;
const pendingDownloadMeta = new Map();
const downloadItems = new Map();

function statePath() { return path.join(app.getPath('userData'), 'desktop-state.json'); }
function readState() {
  try { return JSON.parse(fs.readFileSync(statePath(), 'utf8')); } catch { return {}; }
}
function writeState(next) {
  const current = readState();
  const merged = { ...current, ...next };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(merged, null, 2));
  return merged;
}
function saveToken(token) {
  if (!token) return writeState({ authToken: '' });
  if (safeStorage.isEncryptionAvailable()) {
    return writeState({ authToken: safeStorage.encryptString(token).toString('base64'), authEncrypted: true });
  }
  return writeState({ authToken: token, authEncrypted: false });
}
function loadToken() {
  const s = readState();
  if (!s.authToken) return '';
  try {
    return s.authEncrypted && safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(s.authToken, 'base64'))
      : String(s.authToken);
  } catch { return ''; }
}
function settings() {
  const s = readState();
  return {
    downloadDir: s.downloadDir || app.getPath('downloads'),
    preferredArchive: Number(s.preferredArchive || 1),
    externalPlayer: Boolean(s.externalPlayer),
    controllerUrl: s.controllerUrl || DEFAULT.controllerUrl
  };
}
function normalizeBase(url, fallback) {
  try { const u = new URL(url || fallback); return u.toString(); } catch { return fallback; }
}
async function fetchJson(url, options = {}, timeoutMs = 22000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal, headers: { 'Accept': 'application/json', 'X-BM-Client': 'windows', ...(options.headers || {}) } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (!res.ok && !data?.success) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function loadRemoteConfig(force = false) {
  if (runtimeConfig && !force) return runtimeConfig;
  const local = settings();
  const controller = normalizeBase(local.controllerUrl, DEFAULT.controllerUrl);
  try {
    const remote = await fetchJson(controller, { cache: 'no-store' }, 12000);
    const domain = String(remote.active_domain || remote.desktop?.active_domain || DEFAULT.domain).replace(/\/$/, '');
    runtimeConfig = {
      ...remote,
      active_domain: domain,
      api_url: remote.desktop_api_url || remote.api_url || `${domain}/desktop_api.php`,
      account_api_url: remote.account_api_url || `${domain}/app_user_api.php`,
      controller_url: controller,
      _online: true
    };
  } catch (error) {
    runtimeConfig = {
      platform: 'windows', active_domain: DEFAULT.domain,
      api_url: DEFAULT.fallbackApiUrl, desktop_api_url: DEFAULT.apiUrl,
      account_api_url: DEFAULT.accountApiUrl, controller_url: controller,
      features: {}, desktop: { enabled: true, features: {} }, _online: false,
      _error: error.message
    };
  }
  return runtimeConfig;
}
function queryUrl(base, params = {}) {
  const u = new URL(base);
  Object.entries(params).forEach(([k,v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach(x => u.searchParams.append(k, String(x)));
    else u.searchParams.set(k, String(v));
  });
  return u;
}
async function contentRequest(action, params = {}) {
  const cfg = await loadRemoteConfig();
  const candidates = [cfg.api_url, cfg.desktop_api_url, DEFAULT.fallbackApiUrl].filter(Boolean);
  let last;
  for (const base of [...new Set(candidates)]) {
    const url = queryUrl(base, { action, ...params }).toString();
    try {
      const { ts, sign } = signFor(url);
      const token = loadToken();
      const headers = {
        'X-BM-App-Key': AUTH.appKey,
        'X-BM-Ts': ts,
        'X-BM-Sign': sign,
        'X-BM-Client': 'windows',
        'X-BM-Download-System': '2'
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
        headers['X-BM-User-Token'] = token;
      }
      return await fetchJson(url, { cache: 'no-store', headers });
    } catch (e) { last = e; }
  }
  throw last || new Error('سرور محتوا در دسترس نیست');
}
function signFor(url) {
  const u = new URL(url);
  const ts = String(Math.floor(Date.now() / 1000));
  const pathQuery = u.pathname + (u.search ? u.search : '');
  const sign = crypto.createHmac('sha256', AUTH.appSecret).update(`${ts}|${pathQuery}`).digest('hex');
  return { ts, sign };
}
async function userRequest(action, body = {}, method = 'POST') {
  const cfg = await loadRemoteConfig();
  const url = queryUrl(cfg.account_api_url || DEFAULT.accountApiUrl, method === 'GET' ? { action, ...body } : {});
  const { ts, sign } = signFor(url);
  const token = loadToken();
  const headers = {
    'X-BM-App-Key': AUTH.appKey,
    'X-BM-Ts': ts,
    'X-BM-Sign': sign,
    'X-BM-Notification-Protocol': '2',
    'Content-Type': 'application/json'
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  const opts = { method, headers, cache: 'no-store' };
  if (method !== 'GET') opts.body = JSON.stringify({ action, ...body });
  const data = await fetchJson(url.toString(), opts);
  if ((action === 'login' || action === 'register') && data?.token) saveToken(data.token);
  if (action === 'logout') saveToken('');
  return data;
}
function safeFileName(name) {
  return String(name || 'BankMovie').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'BankMovie';
}
function installDownloadHooks() {
  session.defaultSession.on('will-download', (_event, item, webContents) => {
    const url = item.getURL();
    const meta = pendingDownloadMeta.get(url) || {};
    pendingDownloadMeta.delete(url);
    const id = meta.id || crypto.randomUUID();
    const folder = settings().downloadDir;
    fs.mkdirSync(folder, { recursive: true });
    const ext = path.extname(new URL(url).pathname) || '.mp4';
    item.setSavePath(path.join(folder, safeFileName(meta.fileName || item.getFilename() || `BankMovie-${id}${ext}`)));
    downloadItems.set(id, item);
    const send = (payload) => { if (!webContents.isDestroyed()) webContents.send('download:update', { id, url, ...meta, ...payload }); };
    send({ state: 'starting', received: 0, total: item.getTotalBytes(), savePath: item.getSavePath() });
    item.on('updated', (_e, state) => send({ state, received: item.getReceivedBytes(), total: item.getTotalBytes(), paused: item.isPaused(), savePath: item.getSavePath() }));
    item.once('done', (_e, state) => { send({ state, received: item.getReceivedBytes(), total: item.getTotalBytes(), savePath: item.getSavePath() }); downloadItems.delete(id); });
  });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    frame: false, backgroundColor: '#060708', show: false,
    icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, '../src/index.html'));
  win.once('ready-to-show', () => win.show());
}

app.whenReady().then(() => { installDownloadHooks(); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('bootstrap', async () => ({ config: await loadRemoteConfig(true), settings: settings(), hasToken: Boolean(loadToken()), version: app.getVersion() }));
ipcMain.handle('content:request', (_e, action, params) => contentRequest(action, params));
ipcMain.handle('user:request', (_e, action, body, method) => userRequest(action, body || {}, method || 'POST'));
ipcMain.handle('auth:clear', () => { saveToken(''); return true; });
ipcMain.handle('settings:get', () => settings());
ipcMain.handle('history:get', () => Array.isArray(readState().watchHistory) ? readState().watchHistory : []);
ipcMain.handle('history:upsert', (_e, entry) => {
  const current = Array.isArray(readState().watchHistory) ? readState().watchHistory : [];
  const key = String(entry?.key || ''); if (!key) return current;
  const next = [{ ...entry, updatedAt: Date.now() }, ...current.filter(x => String(x.key) !== key)].slice(0, 60);
  writeState({ watchHistory: next }); return next;
});
ipcMain.handle('history:clear', () => { writeState({ watchHistory: [] }); return true; });
ipcMain.handle('settings:set', (_e, patch) => { writeState(patch || {}); runtimeConfig = null; return settings(); });
ipcMain.handle('settings:choose-download-dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], defaultPath: settings().downloadDir });
  if (r.canceled || !r.filePaths[0]) return settings().downloadDir;
  writeState({ downloadDir: r.filePaths[0] }); return r.filePaths[0];
});
ipcMain.handle('download:add', (_e, meta) => {
  if (!meta?.url || !/^https?:\/\//i.test(meta.url)) throw new Error('لینک دانلود معتبر نیست');
  const id = crypto.randomUUID(); pendingDownloadMeta.set(meta.url, { ...meta, id }); session.defaultSession.downloadURL(meta.url); return { id };
});
ipcMain.handle('download:action', (_e, id, action) => {
  const item = downloadItems.get(id); if (!item) return false;
  if (action === 'pause') item.pause(); else if (action === 'resume') item.resume(); else if (action === 'cancel') item.cancel();
  return true;
});
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
ipcMain.handle('shell:show-item', (_e, filePath) => { shell.showItemInFolder(filePath); return true; });
ipcMain.on('window:minimize', () => win?.minimize());
ipcMain.on('window:maximize', () => win?.isMaximized() ? win.unmaximize() : win?.maximize());
ipcMain.on('window:close', () => win?.close());
