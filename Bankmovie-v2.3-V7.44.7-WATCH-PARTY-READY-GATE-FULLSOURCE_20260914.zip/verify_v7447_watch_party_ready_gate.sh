#!/usr/bin/env bash
set -euo pipefail
player='app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt'

bash verify_v7446_watch_party_neon_ui.sh

grep -Fq 'sourceMainUpdateThirtyFifthHotfixTag=BANKMOVIE-2.3-V7447-20260914' BANKMOVIE_BUILD_SOURCE_2_3.txt

grep -Fq 'setCancelable(false)' "$player"
grep -Fq 'dialog.setCanceledOnTouchOutside(false)' "$player"
grep -Fq 'STATE_PARTY_READY_CONFIRMED' "$player"
grep -Fq 'STATE_PARTY_PLAYBACK_STARTED' "$player"
grep -Fq 'if (!partyActive || partyRoomCode.isBlank() || partyReadyConfirmed) return' "$player"
grep -Fq 'if (partyLobbyDialog?.isShowing == true) return' "$player"
grep -Fq 'if (partyActive && !partyReadyConfirmed && partyRoomCode.isNotBlank() && partyLobbyDialog?.isShowing != true)' "$player"
grep -Fq 'برای ادامه ابتدا روی «شروع تماشا / آماده‌ام» بزنید' "$player"
grep -Fq 'showPartyMembers()' "$player"

# Ensure members action no longer destroys the lobby before opening the child sheet.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
needle='actions.addView(actionButton("دعوت اعضای اتاق", R.drawable.ic_party_members) {'
i=s.index(needle)
chunk=s[i:i+700]
assert 'showPartyMembers()' in chunk
assert 'dialog.dismiss(); showPartyMembers()' not in chunk

# Ready must be set before the intentional dismiss so the defensive re-open hook
# cannot resurrect the lobby after the accepted action.
needle='setOnClickListener {\n                // This is the one and only action allowed to release the lobby gate.'
i=s.index(needle)
chunk=s[i:i+420]
assert chunk.index('partyReadyConfirmed = true') < chunk.index('dialog.dismiss()')
print('V7447_READY_GATE_ORDER_OK')
PY

# Basic source-shape sanity outside comments/strings.
python3 - <<'PY'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/PlayerActivity.kt').read_text()
stack=[]; i=0; state='code'; n=len(s)
while i<n:
    c=s[i]; nx=s[i+1] if i+1<n else ''
    if state=='code':
        if c=='/' and nx=='/': state='line'; i+=2; continue
        if c=='/' and nx=='*': state='block'; i+=2; continue
        if s[i:i+3]=='"""': state='triple'; i+=3; continue
        if c=='"': state='string'; i+=1; continue
        if c=="'": state='char'; i+=1; continue
        if c in '([{': stack.append(c)
        elif c in ')]}':
            pairs={')':'(',']':'[','}':'{'}
            assert stack and stack[-1]==pairs[c], (c,i,stack[-1:] if stack else [])
            stack.pop()
        i+=1; continue
    if state=='line':
        if c=='\n': state='code'
        i+=1; continue
    if state=='block':
        if c=='*' and nx=='/': state='code'; i+=2; continue
        i+=1; continue
    if state=='string':
        if c=='\\': i+=2; continue
        if c=='"': state='code'
        i+=1; continue
    if state=='char':
        if c=='\\': i+=2; continue
        if c=="'": state='code'
        i+=1; continue
    if state=='triple':
        if s[i:i+3]=='"""': state='code'; i+=3; continue
        i+=1
assert state=='code' and not stack, (state, stack[-10:])
print('V7447_KOTLIN_SHAPE_OK')
PY

echo V7447_WATCH_PARTY_READY_GATE_VERIFY_OK
