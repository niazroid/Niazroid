const { app, BrowserWindow, ipcMain, dialog, shell, session, safeStorage, Notification } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn, execFileSync } = require('child_process');
const RUNTIME = require('./runtime.generated');

const DEFAULT = Object.freeze({
  controllerUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_config.php`,
  domain: String(RUNTIME.domain || '').replace(/\/$/,''),
  apiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_api.php`,
  fallbackApiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_api.php`,
  accountApiUrl: `${String(RUNTIME.domain || '').replace(/\/$/,'')}/desktop_user_api.php`
});

let win = null;
let runtimeConfig = null;
const pendingDownloadMeta = new Map(); // id -> meta
const pendingDownloadUrl = new Map();  // original URL -> id
const cancelledPendingDownloads = new Set();
const downloadItems = new Map();
const downloadState = new Map();
const downloadMonitors = new Map();
const forcedPausedDownloads = new Set();
const childWindows = new Set();

function statePath() { return path.join(app.getPath('userData'), 'desktop-state.json'); }
function readState() {
  try { return JSON.parse(fs.readFileSync(statePath(), 'utf8')); } catch { return {}; }
}
function writeState(next) {
  const current = readState();
  const merged = { ...current, ...next };
  fs.mkdirSync(path.dirname(statePath()), { recursive: true });
  fs.writeFileSync(statePath(), JSON.stringify(merged, null, 2));
  return merged;
}
function saveToken(token) {
  if (!token) return writeState({ authToken: '' });
  if (safeStorage.isEncryptionAvailable()) {
    return writeState({ authToken: safeStorage.encryptString(token).toString('base64'), authEncrypted: true });
  }
  return writeState({ authToken: token, authEncrypted: false });
}
function loadToken() {
  const s = readState();
  if (!s.authToken) return '';
  try {
    return s.authEncrypted && safeStorage.isEncryptionAvailable()
      ? safeStorage.decryptString(Buffer.from(s.authToken, 'base64'))
      : String(s.authToken);
  } catch { return ''; }
}
function settings() {
  const s = readState();
  return {
    downloadDir: s.downloadDir || app.getPath('downloads'),
    preferredArchive: Number(s.preferredArchive || 1),
    preferredPlayer: String(s.preferredPlayer || 'auto'),
    language: String(s.language || 'fa') === 'en' ? 'en' : 'fa'
  };
}
function normalizeBase(url, fallback) {
  try { const u = new URL(url || fallback); return u.toString(); } catch { return fallback; }
}
async function fetchJson(url, options = {}, timeoutMs = 22000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...options, signal: ctrl.signal, headers: { 'Accept': 'application/json', 'X-BM-Client': 'windows', ...(options.headers || {}) } });
    const text = await res.text();
    let data;
    try { data = JSON.parse(text); } catch { throw new Error(`پاسخ JSON معتبر نیست (${res.status})`); }
    if (!res.ok && !data?.success) throw new Error(data?.message || `HTTP ${res.status}`);
    return data;
  } finally { clearTimeout(timer); }
}
async function loadRemoteConfig(force = false) {
  if (runtimeConfig && !force) return runtimeConfig;
  const controller = normalizeBase(DEFAULT.controllerUrl, DEFAULT.controllerUrl);
  try {
    const remote = await fetchJson(controller, { cache: 'no-store' }, 12000);
    const domain = String(remote.active_domain || remote.desktop?.active_domain || DEFAULT.domain).replace(/\/$/, '');
    runtimeConfig = {
      ...remote,
      active_domain: domain,
      api_url: remote.desktop_api_url || remote.api_url || `${domain}/desktop_api.php`,
      account_api_url: remote.account_api_url || `${domain}/desktop_user_api.php`,
      controller_url: controller,
      _online: true
    };
  } catch (error) {
    runtimeConfig = {
      platform: 'windows', active_domain: DEFAULT.domain,
      api_url: DEFAULT.fallbackApiUrl, desktop_api_url: DEFAULT.apiUrl,
      account_api_url: DEFAULT.accountApiUrl, controller_url: controller,
      features: {}, desktop: { enabled: true, features: {} }, _online: false,
      _error: error.message
    };
  }
  return runtimeConfig;
}
function queryUrl(base, params = {}) {
  const u = new URL(base);
  Object.entries(params).forEach(([k,v]) => {
    if (v === undefined || v === null || v === '') return;
    if (Array.isArray(v)) v.forEach(x => u.searchParams.append(k, String(x)));
    else u.searchParams.set(k, String(v));
  });
  return u;
}
async function contentRequest(action, params = {}) {
  const cfg = await loadRemoteConfig();
  // Desktop calls the server-side facade. Static API signing secrets never ship in the EXE.
  const candidates = [cfg.desktop_api_url, cfg.api_url, DEFAULT.apiUrl].filter(Boolean);
  let last;
  for (const base of [...new Set(candidates)]) {
    const url = queryUrl(base, { action, ...params }).toString();
    try {
      const token = loadToken();
      const headers = {
        'X-BM-Client': 'windows',
        'X-BM-Download-System': '2'
      };
      if (token) {
        headers.Authorization = `Bearer ${token}`;
        headers['X-BM-User-Token'] = token;
      }
      return await fetchJson(url, { cache: 'no-store', headers });
    } catch (e) { last = e; }
  }
  const msg = String(last?.message || '');
  if (/\.php\b|https?:\/\/|bankmovie|runtime|api\d*[_-]?lib|source[_ -]?unavailable/i.test(msg)) {
    throw new Error('ارتباط با این بخش برقرار نشد. لطفاً دوباره تلاش کنید.');
  }
  throw last || new Error('سرور محتوا در دسترس نیست');
}
async function userRequest(action, body = {}, method = 'POST') {
  const cfg = await loadRemoteConfig();
  const url = queryUrl(cfg.account_api_url || DEFAULT.accountApiUrl, method === 'GET' ? { action, ...body } : {});
  const token = loadToken();
  const headers = {
    'X-BM-Client': 'windows',
    'X-BM-Notification-Protocol': '2',
    'Content-Type': 'application/json'
  };
  if (token) {
    headers.Authorization = `Bearer ${token}`;
    headers['X-BM-User-Token'] = token;
  }
  const opts = { method, headers, cache: 'no-store' };
  if (method !== 'GET') opts.body = JSON.stringify({ action, ...body });
  const data = await fetchJson(url.toString(), opts);
  if ((action === 'login' || action === 'register') && data?.token) saveToken(data.token);
  if (action === 'logout') saveToken('');
  return data;
}
function safeFileName(name) {
  return String(name || 'BankMovie').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').replace(/\s+/g, ' ').trim().slice(0, 150) || 'BankMovie';
}

const PLAYER_DEFS = [
  {
    id: 'potplayer', name: 'PotPlayer', score: 100,
    exes: ['PotPlayerMini64.exe','PotPlayerMini.exe','PotPlayer.exe'],
    paths: [
      ['ProgramFiles','DAUM','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles','PotPlayer','PotPlayerMini64.exe'],
      ['ProgramFiles(x86)','DAUM','PotPlayer','PotPlayerMini.exe'],
      ['ProgramFiles(x86)','PotPlayer','PotPlayerMini.exe']
    ]
  },
  {
    id: 'vlc', name: 'VLC', score: 95,
    exes: ['vlc.exe'],
    paths: [
      ['ProgramFiles','VideoLAN','VLC','vlc.exe'],
      ['ProgramFiles(x86)','VideoLAN','VLC','vlc.exe']
    ]
  },
  {
    id: 'kmplayer', name: 'KMPlayer', score: 80,
    exes: ['KMPlayer64.exe','KMPlayer.exe'],
    paths: [
      ['ProgramFiles','KMPlayer 64X','KMPlayer64.exe'],
      ['ProgramFiles','KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','The KMPlayer','KMPlayer.exe'],
      ['ProgramFiles(x86)','KMPlayer','KMPlayer.exe']
    ]
  }
];

function uniqExisting(paths) {
  const seen = new Set();
  return paths.filter(p => {
    if (!p) return false;
    const q = path.resolve(p);
    if (seen.has(q.toLowerCase()) || !fs.existsSync(q)) return false;
    seen.add(q.toLowerCase());
    return true;
  });
}
function appPathFromRegistry(exe) {
  if (process.platform !== 'win32') return '';
  const roots = ['HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths', 'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\App Paths'];
  for (const root of roots) {
    try {
      const out = execFileSync('reg.exe', ['query', `${root}\\${exe}`, '/ve'], { encoding:'utf8', windowsHide:true, timeout:1800 });
      const m = out.match(/REG_(?:EXPAND_)?SZ\s+(.+)$/mi);
      if (m && fs.existsSync(m[1].trim())) return m[1].trim();
    } catch {}
  }
  return '';
}
function appPathFromWhere(exe) {
  if (process.platform !== 'win32') return '';
  try {
    const out = execFileSync('where.exe', [exe], { encoding:'utf8', windowsHide:true, timeout:1800 });
    return out.split(/\r?\n/).map(x=>x.trim()).find(x=>x && fs.existsSync(x)) || '';
  } catch { return ''; }
}
function detectPlayers() {
  if (process.platform !== 'win32') return [];
  const found = [];
  for (const def of PLAYER_DEFS) {
    const candidates = [];
    for (const parts of def.paths) {
      const root = process.env[parts[0]];
      if (root) candidates.push(path.join(root, ...parts.slice(1)));
    }
    for (const exe of def.exes) {
      candidates.push(appPathFromRegistry(exe));
      candidates.push(appPathFromWhere(exe));
    }
    const existing = uniqExisting(candidates);
    if (existing.length) {
      const executable = existing.find(x => /64\.exe$/i.test(x)) || existing[0];
      found.push({ id:def.id, name:def.name, path:executable, score:def.score, subtitleSupport:def.id !== 'kmplayer' });
    }
  }
  return found.sort((a,b)=>b.score-a.score);
}
function selectedPlayer(preferred = 'auto') {
  const players = detectPlayers();
  if (!players.length) return null;
  if (preferred && preferred !== 'auto') return players.find(p=>p.id===preferred) || players[0];
  return players[0];
}
async function materializeSubtitle(url) {
  if (!url || !/^https?:\/\//i.test(url)) return '';
  const ctrl = new AbortController();
  const timer = setTimeout(()=>ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { signal:ctrl.signal, redirect:'follow' });
    if (!res.ok) return '';
    const buf = Buffer.from(await res.arrayBuffer());
    if (!buf.length || buf.length > 8 * 1024 * 1024) return '';
    let ext = '.srt';
    try {
      const e = path.extname(new URL(url).pathname).toLowerCase();
      if (['.srt','.vtt','.ass','.ssa','.sub'].includes(e)) ext = e;
    } catch {}
    const dir = path.join(app.getPath('temp'), 'BankMovie', 'subtitles');
    fs.mkdirSync(dir, { recursive:true });
    const file = path.join(dir, `${crypto.createHash('sha1').update(url).digest('hex')}${ext}`);
    fs.writeFileSync(file, buf);
    return file;
  } catch { return ''; }
  finally { clearTimeout(timer); }
}
async function launchExternalPlayer(meta = {}) {
  const url = String(meta.url || '');
  if (!/^https?:\/\//i.test(url)) throw new Error('لینک پخش معتبر نیست');
  const pref = String(meta.preferredPlayer || settings().preferredPlayer || 'auto');
  const player = selectedPlayer(pref);
  if (!player) throw new Error('هیچ‌کدام از VLC، PotPlayer یا KMPlayer روی ویندوز پیدا نشد. یکی از آن‌ها را نصب کن.');
  const subtitlePath = await materializeSubtitle(String(meta.subtitleUrl || ''));
  const args = [];
  if (player.id === 'vlc') {
    args.push(url, '--one-instance');
    if (subtitlePath) args.push(`--sub-file=${subtitlePath}`);
  } else if (player.id === 'potplayer') {
    args.push(url);
    if (subtitlePath) args.push(`/sub=${subtitlePath}`);
  } else {
    args.push(url);
  }
  try {
    const child = spawn(player.path, args, { detached:true, stdio:'ignore', windowsHide:false });
    child.unref();
  } catch (e) {
    throw new Error(`اجرای ${player.name} ناموفق بود: ${e.message}`);
  }
  return { ok:true, player:{ id:player.id, name:player.name, path:player.path }, subtitleApplied:Boolean(subtitlePath && player.subtitleSupport) };
}


async function fetchBoxOffice(){
  const url = `${DEFAULT.domain}/api_boxoffice.php?mode=weekend`;
  return fetchJson(url, { cache:'no-store', headers:{ 'Accept':'application/json', 'X-BM-Client':'windows' } });
}

async function openWebWindow(url, title='BankMovie'){
  const raw=String(url||'').trim();
  if(!/^https?:\/\//i.test(raw)) throw new Error('لینک وب معتبر نیست');
  const child=new BrowserWindow({
    width:1180,height:760,minWidth:900,minHeight:620,
    parent:win||undefined,modal:false,show:false,
    backgroundColor:'#05070b',title:String(title||'BankMovie'),
    autoHideMenuBar:true,
    webPreferences:{contextIsolation:true,nodeIntegration:false,sandbox:true}
  });
  // Keep a strong reference so Electron cannot collect a trailer window while it
  // is still playing. This also makes audio-only / invisible trailer behavior
  // impossible when the BrowserWindow is alive.
  childWindows.add(child);
  child.once('closed',()=>childWindows.delete(child));
  child.setMenuBarVisibility(false);
  child.once('ready-to-show',()=>{ if(!child.isDestroyed()) child.show(); });
  await child.loadURL(raw);
  // ready-to-show can fire before loadURL resolves for media pages. Always force
  // the window visible afterwards so a trailer can never become "audio only".
  if(!child.isDestroyed()){
    child.show();
    child.focus();
  }
  return true;
}


function sendToMainWindow(channel, payload) {
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
    try { win.webContents.send(channel, payload); } catch {}
  }
}
function nativeDownloadNotification(title, body) {
  try {
    if (Notification.isSupported()) {
      new Notification({
        title: String(title || 'BankMovie'),
        body: String(body || ''),
        icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
        silent: false
      }).show();
    }
  } catch {}
}


function mergeDownloadState(id, patch = {}) {
  const prev = downloadState.get(id) || {};
  const next = { ...prev, ...patch, id, at: Date.now() };
  downloadState.set(id, next);
  return next;
}
function publishDownloadState(id, patch = {}, preferredWebContents = null) {
  const next = mergeDownloadState(id, patch);
  const targets = [];
  if (preferredWebContents && typeof preferredWebContents.isDestroyed === 'function' && !preferredWebContents.isDestroyed()) targets.push(preferredWebContents);
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed() && !targets.includes(win.webContents)) targets.push(win.webContents);
  for (const target of targets) {
    try { target.send('download:update', next); } catch {}
  }
  return next;
}
function downloadSnapshot() {
  return [...downloadState.values()].sort((a,b)=>Number(b.at||b.queuedAt||0)-Number(a.at||a.queuedAt||0));
}
function clearDownloadMonitor(id) {
  const timer = downloadMonitors.get(id);
  if (timer) clearInterval(timer);
  downloadMonitors.delete(id);
}
function startDownloadMonitor(id, item, sourceWebContents) {
  clearDownloadMonitor(id);
  let lastBytes = item.getReceivedBytes();
  let lastAt = Date.now();
  const timer = setInterval(() => {
    if (!downloadItems.has(id)) { clearDownloadMonitor(id); return; }
    const now = Date.now();
    if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
    const received = item.getReceivedBytes();
    const dt = Math.max(.05, (now-lastAt)/1000);
    const speed = Math.max(0, received-lastBytes)/dt;
    lastBytes = received;
    lastAt = now;
    publishDownloadState(id, {
      state: item.isPaused() ? 'progressing' : 'progressing',
      received,
      total: item.getTotalBytes(),
      paused: forcedPausedDownloads.has(id) || item.isPaused(),
      savePath: item.getSavePath(),
      speed
    }, sourceWebContents);
  }, 500);
  downloadMonitors.set(id, timer);
}

function installDownloadHooks() {
  session.defaultSession.on('will-download', (_event, item, sourceWebContents) => {
    const url = item.getURL();
    const chain = typeof item.getURLChain === 'function' ? item.getURLChain() : [url];

    let id = '';
    for (const u of chain) {
      if (pendingDownloadUrl.has(u)) { id = pendingDownloadUrl.get(u); break; }
    }
    if (!id && pendingDownloadUrl.has(url)) id = pendingDownloadUrl.get(url);
    if (!id) {
      const first = pendingDownloadMeta.keys().next();
      if (!first.done) id = first.value;
    }

    const meta = id ? (pendingDownloadMeta.get(id) || {}) : {};
    if (!id) id = crypto.randomUUID();

    pendingDownloadMeta.delete(id);
    for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) {
      if (mappedId === id) pendingDownloadUrl.delete(u);
    }

    const folder = settings().downloadDir;
    fs.mkdirSync(folder, { recursive: true });
    let ext = '.mp4';
    try { ext = path.extname(new URL(url).pathname) || '.mp4'; } catch {}
    const requestedName = meta.fileName || item.getFilename() || `BankMovie-${id}${ext}`;
    item.setSavePath(path.join(folder, safeFileName(requestedName)));
    downloadItems.set(id, item);

    if (cancelledPendingDownloads.has(id)) {
      cancelledPendingDownloads.delete(id);
      try { item.cancel(); } catch {}
      publishDownloadState(id, { url, ...meta, state:'cancelled', received:0, total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
      downloadItems.delete(id);
      return;
    }

    publishDownloadState(id, { url, ...meta, state:'starting', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() }, sourceWebContents);
    startDownloadMonitor(id, item, sourceWebContents);

    // Delay the native "started" notification slightly so a request that fails
    // immediately does not show both "started" and an error at the same time.
    const notifyTimer=setTimeout(()=>{
      const st=downloadState.get(id);
      if(st && !['cancelled','interrupted','completed'].includes(st.state)){
        nativeDownloadNotification('دانلود شروع شد', meta.title || meta.fileName || 'BankMovie');
      }
    },700);

    item.on('updated', (_e, state) => {
      if (forcedPausedDownloads.has(id) && !item.isPaused()) { try { item.pause(); } catch {} }
      publishDownloadState(id, {
        state,
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:forcedPausedDownloads.has(id) || item.isPaused(),
        savePath:item.getSavePath()
      }, sourceWebContents);
    });

    item.once('done', (_e, state) => {
      clearTimeout(notifyTimer);
      clearDownloadMonitor(id);
      publishDownloadState(id, {
        state,
        received:item.getReceivedBytes(),
        total:item.getTotalBytes(),
        paused:false,
        savePath:item.getSavePath(),
        finishedAt:Date.now()
      }, sourceWebContents);
      downloadItems.delete(id);
      forcedPausedDownloads.delete(id);
      if (state === 'completed') nativeDownloadNotification('دانلود کامل شد', meta.title || item.getFilename() || 'BankMovie');
      else if (state === 'cancelled') nativeDownloadNotification('دانلود لغو شد', meta.title || item.getFilename() || 'BankMovie');
      else nativeDownloadNotification('دانلود متوقف شد', meta.title || item.getFilename() || 'BankMovie');
    });
  });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1480, height: 920, minWidth: 1100, minHeight: 700,
    frame: false, backgroundColor: '#060708', show: false,
    icon: path.join(__dirname, '../src/assets/bankmovie-icon.png'),
    webPreferences: { preload: path.join(__dirname, 'preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true }
  });
  win.loadFile(path.join(__dirname, '../src/index.html'));
  const sendFullscreenState = () => {
    if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) {
      win.webContents.send('window:fullscreen-state', win.isFullScreen());
    }
  };
  win.on('enter-full-screen', sendFullscreenState);
  win.on('leave-full-screen', sendFullscreenState);
  win.once('ready-to-show', () => { win.show(); sendFullscreenState(); });
}

app.whenReady().then(() => { installDownloadHooks(); createWindow(); app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); }); });
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('bootstrap', async () => ({ config: await loadRemoteConfig(true), settings: settings(), players: detectPlayers(), hasToken: Boolean(loadToken()), version: app.getVersion() }));
ipcMain.handle('content:request', (_e, action, params) => contentRequest(action, params));
ipcMain.handle('user:request', (_e, action, body, method) => userRequest(action, body || {}, method || 'POST'));
ipcMain.handle('auth:clear', () => { saveToken(''); return true; });
ipcMain.handle('settings:get', () => settings());
ipcMain.handle('settings:set', (_e, patch) => { writeState(patch || {}); runtimeConfig = null; return settings(); });
ipcMain.handle('settings:choose-download-dir', async () => {
  const r = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'], defaultPath: settings().downloadDir });
  if (r.canceled || !r.filePaths[0]) return settings().downloadDir;
  writeState({ downloadDir: r.filePaths[0] }); return r.filePaths[0];
});
ipcMain.handle('download:add', (_e, meta) => {
  if (!meta?.url || !/^https?:\/\//i.test(meta.url)) throw new Error('لینک دانلود معتبر نیست');
  const id = crypto.randomUUID();
  const payload = { ...meta, id, queuedAt: Date.now(), state:'queued', received:0, total:0, paused:false };
  pendingDownloadMeta.set(id, payload);
  pendingDownloadUrl.set(meta.url, id);
  publishDownloadState(id, payload);
  if (win && !win.isDestroyed() && win.webContents && !win.webContents.isDestroyed()) win.webContents.downloadURL(meta.url);
  else session.defaultSession.downloadURL(meta.url);
  return { id, state:downloadState.get(id) };
});
ipcMain.handle('download:list', () => downloadSnapshot());
ipcMain.handle('download:action', (_e, id, action) => {
  id=String(id||'');
  const item = downloadItems.get(id);
  if (!item) {
    if (action === 'cancel' && pendingDownloadMeta.has(id)) {
      cancelledPendingDownloads.add(id);
      const meta = pendingDownloadMeta.get(id) || {};
      pendingDownloadMeta.delete(id);
      for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) if (mappedId === id) pendingDownloadUrl.delete(u);
      return publishDownloadState(id, { ...meta, state:'cancelled', received:0, total:0, paused:false, finishedAt:Date.now() });
    }
    return downloadState.get(id) || null;
  }
  if (action === 'remove') {
    try { if (item && !item.isDestroyed?.()) item.cancel(); } catch {}
    clearDownloadMonitor(id);
    downloadItems.delete(id);
    forcedPausedDownloads.delete(id);
    pendingDownloadMeta.delete(id);
    for (const [u, mappedId] of [...pendingDownloadUrl.entries()]) if (mappedId === id) pendingDownloadUrl.delete(u);
    downloadState.delete(id);
    return { id, removed:true };
  }
  if (action === 'pause') {
    forcedPausedDownloads.add(id);
    try { item.pause(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:true, savePath:item.getSavePath() });
  }
  if (action === 'resume') {
    forcedPausedDownloads.delete(id);
    try { item.resume(); } catch {}
    return publishDownloadState(id, { state:'progressing', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath() });
  }
  if (action === 'cancel') {
    forcedPausedDownloads.delete(id);
    try { item.cancel(); } catch {}
    clearDownloadMonitor(id);
    const snapshot=publishDownloadState(id, { state:'cancelled', received:item.getReceivedBytes(), total:item.getTotalBytes(), paused:false, savePath:item.getSavePath(), finishedAt:Date.now() });
    downloadItems.delete(id);
    return snapshot;
  }
  return downloadState.get(id) || null;
});
ipcMain.handle('file:open', async (_e, filePath) => {
  if (!filePath || !fs.existsSync(filePath)) return false;
  const err = await shell.openPath(filePath);
  return err === '';
});
ipcMain.handle('player:list', () => detectPlayers());
ipcMain.handle('player:play', (_e, meta) => launchExternalPlayer(meta || {}));
ipcMain.handle('boxoffice:get', () => fetchBoxOffice());
ipcMain.handle('browser:open', (_e, url, title) => openWebWindow(url, title));
ipcMain.handle('shell:open', (_e, url) => shell.openExternal(url));
ipcMain.handle('shell:show-item', (_e, filePath) => { shell.showItemInFolder(filePath); return true; });
ipcMain.on('window:minimize', () => win?.minimize());
ipcMain.on('window:maximize', () => win?.isMaximized() ? win.unmaximize() : win?.maximize());
ipcMain.handle('window:fullscreen', () => {
  if (!win || win.isDestroyed()) return false;
  const next = !win.isFullScreen();
  win.setFullScreen(next);
  return next;
});
ipcMain.on('window:close', () => win?.close());
