-- Exercise the actual production MPV event handlers, without opening a network link.
local f=assert(io.open('player/cinema.lua','r'));local code=f:read('*a');f:close()
local policy=assert(code:match('(local mediaRetry=.-)local brandPath='))
local eventsCode=assert(code:match("(mp.register_event%('start%-file'.-)mp.observe_property%('pause'"))
local https='https://cdn.example.org/movie.mkv';local http='http://cdn.example.org/movie.mkv'
local function run(original,alt,party,resume,log,second,ready)
  local events,writes,commands={},{},{};local message
  local env=setmetatable({partyDir=party,startupDir='startup',startupDone=false,wake=function()end,
    os={getenv=function(k)return ({BM_MEDIA_ORIGINAL=original,BM_MEDIA_ALTERNATIVE=alt,BM_MEDIA_START=resume})[k] end},
    io={open=function(p)writes[p]=true;return {close=function()end} end},
    mp={enable_messages=function()end,register_event=function(k,fn)events[k]=fn end,commandv=function(...)commands[#commands+1]={...};return true end,
      osd_message=function(x)message=x end,get_property_native=function()return {} end,set_property=function()return true end}},{__index=_G})
  assert(load(policy..eventsCode,'transport','t',env))()
  events['start-file']();assert(writes['startup/opening']);if ready then events['file-loaded']();events['playback-restart']() end
  for _,e in ipairs(log)do if events['log-message'] then events['log-message'](e) end end
  events['end-file']({reason='error'})
  if second then events['start-file']();events['end-file']({reason='error'}) end
  return writes,commands,message
end
local cert={{prefix='ffmpeg',text='tls: certificate verification failed'}}
local w,c,m=run(https,http,nil,'123.456',cert,false,false);assert(w['startup/retrying'] and not w['startup/error'] and not m);assert(c[1][1]=='loadfile' and c[1][2]==http and c[1][5]=='start=123.456,hr-seek=yes')
w,c=run(https,http,nil,nil,cert,true,false);assert(#c==1 and w['startup/retry-error'])
w,c=run(https,http,nil,nil,{{prefix='ffmpeg',text='HTTP error 403 Forbidden'},cert[1]},false,false);assert(#c==0 and w['startup/error'])
w,c=run(https,http,nil,nil,{{prefix='ffmpeg/video',text='Decoder failed'}},false,false);assert(#c==0 and w['startup/error'])
w,c=run(https,'',nil,nil,cert,false,false);assert(#c==0 and w['startup/tls-error'])
w,c=run(https,http,'party',nil,cert,false,false);assert(#c==0 and w['startup/error'])
w,c=run(https,http,nil,nil,cert,false,true);assert(#c==0 and w['startup/ready'] and not w['startup/retrying'])
w,c=run(http,https,nil,nil,{{prefix='stream',text='Connection refused'}},false,false);assert(#c==1 and c[1][2]==https)
w,c=run(https,http,nil,nil,{{prefix='stream',text='Connection refused'}},false,false);assert(#c==0 and w['startup/error'])
w,c=run(https,http,nil,nil,{{prefix='cplayer',text='TLS handshake failed'}},false,false);assert(#c==0)
print('PASS: MPV startup transport real event handler, one alternate, resume, TLS-only downgrade, HTTP upgrade, deny/decoder/party guards')
