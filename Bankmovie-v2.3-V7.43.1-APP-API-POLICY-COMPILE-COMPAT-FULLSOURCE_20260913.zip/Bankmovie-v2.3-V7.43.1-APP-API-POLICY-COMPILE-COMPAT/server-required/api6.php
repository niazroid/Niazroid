<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
if (is_file(__DIR__ . '/includes/session_lifecycle.php')) {
    require_once __DIR__ . '/includes/session_lifecycle.php';
    if (function_exists('bm_session_lifecycle_boot')) bm_session_lifecycle_boot($pdo ?? null);
}
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/app_archive_policy.php';
require_once __DIR__ . '/includes/download_redirect.php';
require_once __DIR__ . '/api6_lib.php';
header('Content-Type: application/json; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

$api6AppClient = strtolower(trim((string)($_GET['client'] ?? ''))) === 'app';
$api6PolicyV2 = $api6AppClient && function_exists('bm_app_policy_protocol_v2') && bm_app_policy_protocol_v2();
$api6Viewer = $api6AppClient && function_exists('bm_app_policy_current_user') ? bm_app_policy_current_user() : null;

function api6_json($payload, $code = 200) {
    global $api6AppClient, $api6PolicyV2, $api6Viewer;
    if ($api6AppClient) {
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive3', false);
        if ($api6PolicyV2 && function_exists('bm_app_archive_apply_payload_policy')) {
            $payload = bm_app_archive_apply_payload_policy('archive3', $payload, $api6Viewer);
            $code = 200;
        } elseif (function_exists('bm_app_archive_apply_payload_policy_legacy')) {
            $payload = bm_app_archive_apply_payload_policy_legacy('archive3', $payload, $api6Viewer);
        }
    } else {
        if (function_exists('bm_archive_apply_payload_policy')) $payload = bm_archive_apply_payload_policy('archive3', $payload, null);
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive3', false);
    }
    http_response_code((int)$code);
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function api6_control_section_key($section) {
    $section = strtolower(trim((string)$section));
    $map = array(
        'new_movies'=>'new_movies','updated_movies'=>'new_movies','movies'=>'new_movies','movie'=>'new_movies',
        'new_series'=>'new_series','updated_series'=>'new_series','series'=>'new_series',
        'updated_animations'=>'updated_animations','animations'=>'updated_animations','animation'=>'updated_animations',
        'updated_anime'=>'updated_anime','anime'=>'updated_anime',
        'dubbed_movies'=>'dubbed_movies','dubbed'=>'dubbed_movies',
        'subtitled_movies'=>'subtitled_movies','subtitled'=>'subtitled_movies',
        'collections'=>'collections','collection'=>'collections',
    );
    return $map[$section] ?? '';
}

function api6_app_section_allowed($section) {
    global $api6Viewer;
    $key = api6_control_section_key($section);
    if ($key === '') return true;
    return function_exists('bm_app_archive_section_user_can_access')
        ? bm_app_archive_section_user_can_access('archive3', $key, $api6Viewer)
        : true;
}

try {
    if (isset($_GET['ping']) || isset($_GET['status']) || isset($_GET['auth_status'])) {
        if ($api6PolicyV2) {
            $state = bm_app_archive_state_payload('archive3', $api6Viewer);
            $state['endpoint'] = 'api6';
            api6_json($state, 200);
        }
        api6_json(array(
            'status' => 'success',
            'enabled' => bm_archive_is_enabled('archive3'),
            'archive' => 3,
            'endpoint' => 'api6',
            'message' => bm_archive_is_enabled('archive3') ? 'آرشیو ۳ آماده است.' : bm_archive_disabled_message('archive3'),
        ));
    }

    if ($api6PolicyV2) {
        $state = bm_app_archive_state_payload('archive3', $api6Viewer);
        if (($state['status'] ?? 'success') !== 'success') api6_json($state, 200);
    } elseif (!bm_archive_is_enabled('archive3')) {
        api6_json(array(
            'status' => 'disabled',
            'archive' => 3,
            'message' => bm_archive_disabled_message('archive3'),
            'movies' => array(),
            'downloads' => array(),
            'has_more' => false,
        ), 503);
    }

    if (isset($_GET['sections'])) {
        api6_json(array('status' => 'success', 'archive' => 3, 'sections' => array_keys(api6_section_catalog())));
    }
    if (isset($_GET['search_options']) || isset($_GET['filters']) || isset($_GET['options'])) {
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), api6_search_options()));
    }
    if (isset($_GET['genres'])) {
        $options = api6_search_options();
        api6_json(array(
            'status' => 'success',
            'archive' => 3,
            'genres' => array_map(function($row) { return $row['value']; }, $options['genres']),
            'genre_options' => $options['genres'],
            'counts_source' => $options['counts_source'],
        ));
    }
    if (isset($_GET['years'])) {
        $options = api6_search_options();
        api6_json(array(
            'status' => 'success',
            'archive' => 3,
            'years' => $options['years'],
            'counts_source' => $options['counts_source'],
        ));
    }

    if (isset($_GET['section'])) {
        $section = trim((string)$_GET['section']);
        if ($api6PolicyV2 && !api6_app_section_allowed($section)) {
            $key = api6_control_section_key($section);
            api6_json(bm_app_archive_section_state_payload('archive3', $key !== '' ? $key : $section, $api6Viewer), 200);
        }
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = api6_search(api6_section_params($section, $page));
        $result['section'] = $section;
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), $result));
    }

    if (isset($_GET['updates']) || isset($_GET['archive'])) {
        $kind = trim((string)(isset($_GET['updates']) ? $_GET['updates'] : $_GET['archive']));
        $page = max(1, (int)($_GET['page'] ?? 1));
        if (in_array($kind, array('series','tv'), true)) $section = 'new_series';
        elseif (in_array($kind, array('updated_anime','anime'), true)) $section = 'updated_anime';
        elseif (in_array($kind, array('updated_animations','animation'), true)) $section = 'updated_animations';
        elseif ($kind === 'animations') $section = 'animations';
        else $section = 'new_movies';
        if ($api6PolicyV2 && !api6_app_section_allowed($section)) {
            $key = api6_control_section_key($section);
            api6_json(bm_app_archive_section_state_payload('archive3', $key !== '' ? $key : $section, $api6Viewer), 200);
        }
        $result = api6_search(api6_section_params($section, $page));
        $result['section'] = $section;
        api6_json(array_merge(array('status' => 'success', 'archive' => 3), $result));
    }

    if (isset($_GET['id']) || isset($_GET['url'])) {
        $identifier = isset($_GET['url']) ? (string)$_GET['url'] : (string)$_GET['id'];
        api6_json(api6_get_details($identifier));
    }

    $params = array(
        's' => trim((string)($_GET['s'] ?? ($_GET['q'] ?? ''))),
        'type' => trim((string)($_GET['type'] ?? ($_GET['post-type'] ?? 'all'))),
        'genre' => trim((string)($_GET['genre'] ?? ($_GET['_genre'] ?? ''))),
        'sort' => trim((string)($_GET['sort'] ?? ($_GET['sortby'] ?? 'newest'))),
        'country' => trim((string)($_GET['country'] ?? ($_GET['_country'] ?? ''))),
        'director' => trim((string)($_GET['director'] ?? '')),
        'actor' => trim((string)($_GET['actor'] ?? '')),
        'yearse' => trim((string)($_GET['yearse'] ?? ($_GET['year'] ?? ''))),
        'year' => trim((string)($_GET['year'] ?? ($_GET['yearse'] ?? ''))),
        'fromYear' => trim((string)($_GET['fromYear'] ?? ($_GET['min_year'] ?? ''))),
        'toYear' => trim((string)($_GET['toYear'] ?? ($_GET['max_year'] ?? ''))),
        'rates' => trim((string)($_GET['rates'] ?? ($_GET['_rates'] ?? ($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))))),
        'rating' => trim((string)($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))),
        'imdbScore' => trim((string)($_GET['imdbScore'] ?? ($_GET['rates'] ?? ($_GET['rating'] ?? '')))),
        'score' => trim((string)($_GET['score'] ?? ($_GET['_score'] ?? ''))),
        'lang' => trim((string)($_GET['lang'] ?? '')),
        'dubbed' => !empty($_GET['dubbed']) || !empty($_GET['doble']),
        'subtitle' => !empty($_GET['subtitle']),
        'playonline' => !empty($_GET['playonline']),
        'page' => max(1, (int)($_GET['page'] ?? 1)),
    );

    api6_json(array_merge(array('status' => 'success', 'archive' => 3), api6_search($params)));
} catch (Throwable $e) {
    api6_json(array(
        'status' => 'error',
        'archive' => 3,
        'message' => 'دریافت اطلاعات آرشیو ۳ انجام نشد.',
        'error' => $e->getMessage(),
        'movies' => array(),
        'has_more' => false,
    ), 500);
}
