<?php
require_once __DIR__ . '/archive1_live_lib.php';
require_once __DIR__ . '/includes/security_bootstrap.php';
if (is_file(__DIR__ . '/config.php')) require_once __DIR__ . '/config.php';
if (is_file(__DIR__ . '/includes/session_lifecycle.php')) {
    require_once __DIR__ . '/includes/session_lifecycle.php';
    if (function_exists('bm_session_lifecycle_boot')) bm_session_lifecycle_boot($pdo ?? null);
}
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/app_archive_policy.php';
require_once __DIR__ . '/includes/download_redirect.php';

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-BM-User-Token');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$bma1AppClient = strtolower(trim((string)($_GET['client'] ?? ''))) === 'app';
$bma1PolicyV2 = $bma1AppClient && function_exists('bm_app_policy_protocol_v2') && bm_app_policy_protocol_v2();
$bma1Viewer = $bma1AppClient && function_exists('bm_app_policy_current_user') ? bm_app_policy_current_user() : null;

function bma1_json($payload, $code = 200) {
    global $bma1AppClient, $bma1PolicyV2, $bma1Viewer;
    if ($bma1AppClient) {
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive1', false);
        if ($bma1PolicyV2 && function_exists('bm_app_archive_apply_payload_policy')) {
            $payload = bm_app_archive_apply_payload_policy('archive1', $payload, $bma1Viewer);
            $code = 200;
        } elseif (function_exists('bm_app_archive_apply_payload_policy_legacy')) {
            $payload = bm_app_archive_apply_payload_policy_legacy('archive1', $payload, $bma1Viewer);
        }
    }
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

function bma1_control_section_key($section) {
    $section = strtolower(trim((string)$section));
    $map = array(
        'updated_movies'=>'updated_movies','movies'=>'updated_movies','movie'=>'updated_movies',
        'updated_series'=>'updated_series','series'=>'updated_series',
        'dubbed'=>'dubbed',
        'chinese_series'=>'chinese_series',
        'korean_series'=>'korean_series',
        'top_2026'=>'top_2026',
        'anime'=>'anime',
        'turkish'=>'turkish',
        'collections'=>'collections','collection'=>'collections',
    );
    return $map[$section] ?? '';
}

try {
    if ($bma1PolicyV2) {
        $state = bm_app_archive_state_payload('archive1', $bma1Viewer);
        if (isset($_GET['ping'])) {
            $state['api'] = 'archive1_live';
            $state['source'] = 'bankmovie';
            $state['version'] = '1.3.0-v743-policy';
            bma1_json($state, 200);
        }
        if (($state['status'] ?? 'success') !== 'success') bma1_json($state, 200);
    }
    if (isset($_GET['ping'])) {
        bma1_json([
            'status' => 'success',
            'api' => 'archive1_live',
            'source' => 'oldtowns',
            'version' => '1.2.0-v21-advanced-search'
        ]);
    }

    if (isset($_GET['advanced'])) {
        $page = max(1, (int)($_GET['page'] ?? $_GET['paged'] ?? 1));
        $limit = max(1, min(100, (int)($_GET['limit'] ?? 40)));
        $params = [
            's' => trim((string)($_GET['s'] ?? '')),
            'type' => trim((string)($_GET['type'] ?? 'both')),
            'genre_id' => trim((string)($_GET['genre_id'] ?? $_GET['genre'] ?? '')),
            'sortby' => trim((string)($_GET['sortby'] ?? $_GET['sort'] ?? 'newest')),
            'rating' => trim((string)($_GET['rating'] ?? $_GET['imdbrate'] ?? '0')),
            'country_id' => trim((string)($_GET['country_id'] ?? $_GET['madeby'] ?? '')),
            'dubbed' => !empty($_GET['dubbed']) || !empty($_GET['dubbled']),
            'subtitle' => !empty($_GET['subtitle']),
            'year_from' => trim((string)($_GET['year_from'] ?? $_GET['min_year'] ?? '')),
            'year_to' => trim((string)($_GET['year_to'] ?? $_GET['max_year'] ?? '')),
        ];

        $url = bma1_advanced_url($params, $page);
        $cacheKey = hash('sha256', 'advanced|' . $url . '|' . $limit);
        $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_a1_' . $cacheKey . '.json';

        if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 180) {
            $cached = @file_get_contents($cacheFile);
            if (is_string($cached) && $cached !== '') {
                header('X-Bankmovie-Cache: HIT');
                if ($bma1AppClient) {
                    $decoded = json_decode($cached, true);
                    if (is_array($decoded)) bma1_json($decoded, 200);
                }
                echo $cached;
                exit;
            }
        }

        $html = bma1_fetch_html($url);
        $result = bma1_parse_listing_html($html, $url, 'advanced', $page, $limit);
        $result['search_mode'] = 'advanced';
        $result['filters'] = $params;
        if ($bma1PolicyV2) bma1_json($result, 200);
        $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (is_string($encoded)) @file_put_contents($cacheFile, $encoded, LOCK_EX);
        header('X-Bankmovie-Cache: MISS');
        echo $encoded;
        exit;
    }

    $section = trim((string)($_GET['section'] ?? 'dubbed'));
    if (!in_array($section, ['dubbed', 'chinese_series'], true)) {
        bma1_json(['status' => 'error', 'error' => 'unsupported_section'], 400);
    }
    if ($bma1PolicyV2) {
        $key = bma1_control_section_key($section);
        if ($key !== '' && function_exists('bm_app_archive_section_user_can_access') && !bm_app_archive_section_user_can_access('archive1', $key, $bma1Viewer)) {
            bma1_json(bm_app_archive_section_state_payload('archive1', $key, $bma1Viewer), 200);
        }
    }
    $page = max(1, (int)($_GET['page'] ?? 1));
    $limit = max(1, min(60, (int)($_GET['limit'] ?? 24)));
    $url = bma1_section_url($section, $page);

    $cacheKey = hash('sha256', $url . '|' . $limit);
    $cacheFile = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'bankmovie_a1_' . $cacheKey . '.json';
    if (is_file($cacheFile) && (time() - filemtime($cacheFile)) < 180) {
        $cached = @file_get_contents($cacheFile);
        if (is_string($cached) && $cached !== '') {
            header('X-Bankmovie-Cache: HIT');
            if ($bma1PolicyV2) {
                $decoded = json_decode($cached, true);
                if (is_array($decoded)) bma1_json($decoded, 200);
            }
            echo $cached;
            exit;
        }
    }

    $html = bma1_fetch_html($url);
    $result = bma1_parse_listing_html($html, $url, $section, $page, $limit);
    if ($bma1PolicyV2) bma1_json($result, 200);
    $encoded = json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if (is_string($encoded)) @file_put_contents($cacheFile, $encoded, LOCK_EX);
    header('X-Bankmovie-Cache: MISS');
    echo $encoded;
} catch (Throwable $e) {
    bma1_json([
        'status' => 'error',
        'source' => 'archive1_live',
        'error' => 'temporary_upstream_error',
        'message' => $e->getMessage()
    ], 502);
}
