<?php
require_once __DIR__ . '/includes/security_bootstrap.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/session_lifecycle.php';
bm_session_lifecycle_boot($pdo ?? null);
require_once __DIR__ . '/includes/archive_control.php';
require_once __DIR__ . '/includes/app_archive_policy.php';
require_once __DIR__ . '/includes/download_redirect.php';
require_once __DIR__ . '/includes/api4_lib.php';

bm_security_enforce_rate_limit('api4_public', 420, 300, bm_security_client_ip(), true);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');

function api4_json($payload, $code = 200) {
    global $api4PolicyV2;
    $context = ['identifier'=>(string)($_GET['url'] ?? ($_GET['id'] ?? ''))];
    $appClient = strtolower(trim((string)($_GET['client'] ?? ''))) === 'app';
    if ($appClient) {
        if ($api4PolicyV2) {
            // V7.43+ policy protocol: fail-open wrapping before independent feature stripping.
            if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive4', false);
            if (function_exists('bm_app_archive_apply_payload_policy')) {
                $payload = bm_app_archive_apply_payload_policy('archive4', $payload, $GLOBALS['currentUser'] ?? null, $context);
            }
            $code = 200;
        } else {
            // Legacy app contract used by installed 2.2/pre-V7.43 builds.
            if (function_exists('bm_app_archive_apply_payload_policy_legacy')) {
                $payload = bm_app_archive_apply_payload_policy_legacy('archive4', $payload, $GLOBALS['currentUser'] ?? null, $context);
            }
            if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive4', true);
        }
    } else {
        if (function_exists('bm_archive_apply_payload_policy')) {
            $payload = bm_archive_apply_payload_policy('archive4', $payload, $GLOBALS['currentUser'] ?? null, $context);
        }
        if (function_exists('bm_dl_wrap_payload')) $payload = bm_dl_wrap_payload($payload, false, 'archive4', false);
    }
    if (function_exists('bm_poster_wrap_payload')) $payload = bm_poster_wrap_payload($payload);
    http_response_code((int)$code);
    echo json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

// Archive 4 audience is controlled from the archive manager.
// Public mode is the default. In administrator-only mode direct API/detail/
// subtitle requests are protected as well as the visible UI tab.
$api4AppClient = strtolower(trim((string)($_GET['client'] ?? ''))) === 'app';
$api4PolicyV2 = $api4AppClient && function_exists('bm_app_policy_protocol_v2') && bm_app_policy_protocol_v2();
$api4Viewer = $api4AppClient && function_exists('bm_app_policy_current_user')
    ? bm_app_policy_current_user()
    : ($currentUser ?? null);
if ($api4AppClient) $GLOBALS['currentUser'] = $api4Viewer;
$api4CanAccess = $api4AppClient
    ? (function_exists('bm_app_archive_user_can_access') && bm_app_archive_user_can_access('archive4', $api4Viewer))
    : (function_exists('bm_archive_user_can_access') && bm_archive_user_can_access('archive4', $currentUser ?? null));
if ($api4PolicyV2) {
    $api4State = bm_app_archive_state_payload('archive4', $api4Viewer);
    if (($api4State['status'] ?? 'success') !== 'success') api4_json($api4State, 200);
} elseif (!$api4CanAccess) {
    api4_json(array('status' => 'error', 'error' => 'not_found'), 404);
}

if (isset($_GET['subtitle_url'])) {
    $subtitleAllowed = $api4AppClient
        ? bm_app_archive_feature_user_can_access('archive4', 'stream', $api4Viewer)
        : bm_archive_feature_user_can_access('archive4', 'stream', $currentUser ?? null);
    if (!$subtitleAllowed) {
        http_response_code(404);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'subtitle_error';
        exit;
    }
    try {
        $subtitleUrl = trim((string)$_GET['subtitle_url']);
        $body = api4_fetch_subtitle_url($subtitleUrl);
        $path = strtolower((string)(parse_url($subtitleUrl, PHP_URL_PATH) ?: ''));
        $ctype = preg_match('~\.vtt$~i', $path) ? 'text/vtt; charset=utf-8' : 'text/plain; charset=utf-8';
        header('Content-Type: ' . $ctype);
        echo $body;
    } catch (Throwable $e) {
        http_response_code(400);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'subtitle_error';
    }
    exit;
}


function api4_control_section_key($section) {
    $section = strtolower(trim((string)$section));
    $map = array(
        'new_movies'=>'new_movies','updated_movies'=>'new_movies','movies'=>'new_movies','movie'=>'new_movies',
        'new_series'=>'new_series','updated_series'=>'new_series','series'=>'new_series',
        'updated_animations'=>'updated_animations','animations'=>'updated_animations','animation'=>'updated_animations',
        'updated_anime'=>'updated_anime','anime'=>'updated_anime',
        'collections'=>'collections','collection'=>'collections',
    );
    return $map[$section] ?? '';
}

function api4_section_allowed($section) {
    $controlKey = api4_control_section_key($section);
    if ($controlKey === '') return true;
    if (strtolower(trim((string)($_GET['client'] ?? ''))) === 'app') {
        if (!function_exists('bm_app_policy_protocol_v2') || !bm_app_policy_protocol_v2()) return true;
        return function_exists('bm_app_archive_section_user_can_access')
            ? bm_app_archive_section_user_can_access('archive4', $controlKey, $GLOBALS['currentUser'] ?? null)
            : true;
    }
    if (!function_exists('bm_archive_section_enabled')) return true;
    return bm_archive_section_enabled('archive4', $controlKey);
}

function api4_disabled_section_payload($section) {
    $key = api4_control_section_key($section);
    if (strtolower(trim((string)($_GET['client'] ?? ''))) === 'app' && function_exists('bm_app_policy_protocol_v2') && bm_app_policy_protocol_v2() && function_exists('bm_app_archive_section_state_payload')) {
        return bm_app_archive_section_state_payload('archive4', $key !== '' ? $key : (string)$section, $GLOBALS['currentUser'] ?? null);
    }
    return array(
        'status' => 'success',
        'archive' => 4,
        'section' => (string)$section,
        'section_disabled' => true,
        'message' => 'این بخش از آرشیو ۴ توسط مدیریت غیرفعال شده است.',
        'items' => array(),
        'movies' => array(),
        'results' => array(),
        'has_more' => false,
        'next_page' => 0,
    );
}

header('Content-Type: application/json; charset=utf-8');

try {
    if (isset($_GET['ping']) || isset($_GET['status']) || isset($_GET['auth_status'])) {
        api4_json(array(
            'status' => 'success',
            'enabled' => $api4AppClient ? bm_app_archive_is_enabled('archive4') : bm_archive_is_enabled('archive4'),
            'archive' => 4,
            'endpoint' => 'api4',
            'access_scope' => $api4AppClient ? (string)(bm_app_archive_policy_row('archive4')['access_scope'] ?? 'public') : (function_exists('bm_archive_access_scope') ? bm_archive_access_scope('archive4') : 'public'),
            'message' => ($api4AppClient ? bm_app_archive_is_enabled('archive4') : bm_archive_is_enabled('archive4')) ? 'آرشیو ۴ آماده است.' : 'آرشیو ۴ موقتاً در دسترس نیست.',
        ));
    }

    if (!($api4AppClient ? bm_app_archive_is_enabled('archive4') : bm_archive_is_enabled('archive4'))) {
        if ($api4PolicyV2) api4_json(bm_app_archive_state_payload('archive4', $api4Viewer), 200);
        api4_json(array(
            'status' => 'disabled',
            'archive' => 4,
            'message' => $api4AppClient ? (string)(bm_app_archive_policy_row('archive4')['disabled_message'] ?? 'این آرشیو در اپ موقتاً غیرفعال است.') : bm_archive_disabled_message('archive4'),
            'movies' => array(),
            'downloads' => array(),
            'has_more' => false,
        ), 503);
    }

    if (isset($_GET['sections'])) {
        api4_json(array('status' => 'success', 'archive' => 4, 'sections' => array_keys(api4_section_catalog())));
    }
    if (isset($_GET['search_options']) || isset($_GET['filters']) || isset($_GET['options'])) {
        api4_json(array_merge(array('status' => 'success', 'archive' => 4), api4_search_options()));
    }
    if (isset($_GET['genres'])) {
        $options = api4_search_options();
        api4_json(array(
            'status' => 'success',
            'archive' => 4,
            'genres' => array_map(function($row) { return $row['value']; }, $options['genres']),
            'genre_options' => $options['genres'],
            'counts_source' => $options['counts_source'],
        ));
    }
    if (isset($_GET['years'])) {
        $options = api4_search_options();
        api4_json(array(
            'status' => 'success',
            'archive' => 4,
            'years' => $options['years'],
            'counts_source' => $options['counts_source'],
        ));
    }

    if (isset($_GET['section'])) {
        $section = trim((string)$_GET['section']);
        if (!api4_section_allowed($section)) api4_json(api4_disabled_section_payload($section), $api4AppClient ? 200 : 200);
        $page = max(1, (int)($_GET['page'] ?? 1));
        $result = api4_search(api4_section_params($section, $page));
        $result['section'] = $section;
        api4_json(array_merge(array('status' => 'success', 'archive' => 4), $result));
    }

    if (isset($_GET['updates']) || isset($_GET['archive'])) {
        $kind = trim((string)(isset($_GET['updates']) ? $_GET['updates'] : $_GET['archive']));
        $page = max(1, (int)($_GET['page'] ?? 1));
        if (in_array($kind, array('series','tv'), true)) $section = 'new_series';
        elseif (in_array($kind, array('updated_anime','anime'), true)) $section = 'updated_anime';
        elseif (in_array($kind, array('updated_animations','animation'), true)) $section = 'updated_animations';
        elseif ($kind === 'animations') $section = 'animations';
        else $section = 'new_movies';
        if ($api4AppClient && !api4_section_allowed($section)) api4_json(api4_disabled_section_payload($section), 200);
        $result = api4_search(api4_section_params($section, $page));
        $result['section'] = $section;
        api4_json(array_merge(array('status' => 'success', 'archive' => 4), $result));
    }

    if (isset($_GET['id']) || isset($_GET['url'])) {
        $identifier = isset($_GET['url']) ? (string)$_GET['url'] : (string)$_GET['id'];
        api4_json(api4_get_details($identifier));
    }

    $params = array(
        's' => trim((string)($_GET['s'] ?? ($_GET['q'] ?? ''))),
        'type' => trim((string)($_GET['type'] ?? ($_GET['post-type'] ?? 'all'))),
        'genre' => trim((string)($_GET['genre'] ?? ($_GET['_genre'] ?? ''))),
        'sort' => trim((string)($_GET['sort'] ?? ($_GET['sortby'] ?? 'newest'))),
        'country' => trim((string)($_GET['country'] ?? ($_GET['_country'] ?? ''))),
        'director' => trim((string)($_GET['director'] ?? '')),
        'actor' => trim((string)($_GET['actor'] ?? '')),
        'yearse' => trim((string)($_GET['yearse'] ?? ($_GET['year'] ?? ''))),
        'year' => trim((string)($_GET['year'] ?? ($_GET['yearse'] ?? ''))),
        'fromYear' => trim((string)($_GET['fromYear'] ?? ($_GET['min_year'] ?? ''))),
        'toYear' => trim((string)($_GET['toYear'] ?? ($_GET['max_year'] ?? ''))),
        'rates' => trim((string)($_GET['rates'] ?? ($_GET['_rates'] ?? ($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))))),
        'rating' => trim((string)($_GET['rating'] ?? ($_GET['imdbScore'] ?? ''))),
        'imdbScore' => trim((string)($_GET['imdbScore'] ?? ($_GET['rates'] ?? ($_GET['rating'] ?? '')))),
        'score' => trim((string)($_GET['score'] ?? ($_GET['_score'] ?? ''))),
        'lang' => trim((string)($_GET['lang'] ?? '')),
        'dubbed' => !empty($_GET['dubbed']) || !empty($_GET['doble']),
        'subtitle' => !empty($_GET['subtitle']),
        'playonline' => !empty($_GET['playonline']),
        'page' => max(1, (int)($_GET['page'] ?? 1)),
    );

    api4_json(array_merge(array('status' => 'success', 'archive' => 4), api4_search($params)));
} catch (Throwable $e) {
    api4_json(array(
        'status' => 'error',
        'archive' => 4,
        'message' => 'دریافت اطلاعات آرشیو ۴ انجام نشد.',
        'error' => 'internal_error',
        'movies' => array(),
        'has_more' => false,
    ), 500);
}
