#!/usr/bin/env bash
set -euo pipefail
main='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
policy='server-required/includes/app_archive_policy.php'
app_api='server-required/app_api.php'
api4='server-required/api4.php'
api6='server-required/api6.php'
arc1='server-required/archive1_live.php'

for f in "$main" "$policy" "$app_api" "$api4" "$api6" "$arc1"; do
  test -s "$f" || { echo "missing: $f" >&2; exit 1; }
done

grep -Fq 'sourceMainUpdateTwentySeventhHotfixTag=BANKMOVIE-2.3-V7431-20260913' BANKMOVIE_BUILD_SOURCE_2_3.txt
# Exact compile hotfix from the Actions log.
grep -Fq 'archiveDisabledMessage(pair.first)' "$main"
! grep -Fq 'archiveDisabledMessage(safe)' <(sed -n '16720,16742p' "$main")
# New clients opt in; old installed clients do not.
grep -Fq 'setRequestProperty("X-BM-Policy-Version", "2")' "$main"
grep -Fq 'function bm_app_policy_protocol_v2()' "$policy"
grep -Fq 'function bm_app_archive_apply_payload_policy_legacy' "$policy"
grep -Fq 'Backward-compat contract for already-installed 2.2 / pre-V7.43 clients.' "$app_api"
grep -Fq 'function_exists('\''bm_app_policy_protocol_v2'\'') && bm_app_policy_protocol_v2()' "$app_api"
grep -Fq '$api4PolicyV2' "$api4"
grep -Fq '$api6PolicyV2' "$api6"
grep -Fq '$bma1PolicyV2' "$arc1"

for f in "$policy" "$app_api" "$api4" "$api6" "$arc1" server-required/app_config.php server-required/bm_admin.php; do
  php -l "$f" >/dev/null
done

# Protocol negotiation behavior.
php <<'PHP'
<?php
require 'server-required/includes/app_archive_policy.php';
function a($cond,$msg){ if(!$cond){fwrite(STDERR,"ASSERT: $msg\n"); exit(13);} }
unset($_GET['policy_v'], $_POST['policy_v'], $_SERVER['HTTP_X_BM_POLICY_VERSION']);
a(bm_app_policy_protocol_v2() === false, 'legacy request must not opt into V2');
$_SERVER['HTTP_X_BM_POLICY_VERSION']='2';
a(bm_app_policy_protocol_v2() === true, 'header must opt into V2');
unset($_SERVER['HTTP_X_BM_POLICY_VERSION']);
$_GET['policy_v']='2';
a(bm_app_policy_protocol_v2() === true, 'query must opt into V2');
echo "V7431_PROTOCOL_COMPAT_OK\n";
PHP

echo V7431_COMPILE_LEGACY_COMPAT_VERIFY_OK
