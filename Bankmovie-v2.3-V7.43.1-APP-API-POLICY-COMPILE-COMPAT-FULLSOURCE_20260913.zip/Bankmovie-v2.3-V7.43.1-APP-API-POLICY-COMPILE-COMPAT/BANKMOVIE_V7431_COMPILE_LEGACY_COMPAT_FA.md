BANKMOVIE V7.43.1 — KOTLIN COMPILE FIX + LEGACY CLIENT COMPATIBILITY
===================================================================

این Hotfix دو هدف دارد:

1) رفع خطای واقعی Kotlin در Build V7.43
- در MainActivity داخل Toggle آرشیوهای صفحه دسته‌بندی، متغیر safe خارج از scope استفاده شده بود.
- archiveDisabledMessage(safe) به archiveDisabledMessage(pair.first) اصلاح شد.
- خطای GitHub Actions: Unresolved reference 'safe' در MainActivity.kt:16733 رفع شد.

2) محافظت از نسخه‌های نصب‌شده قدیمی مثل 2.2
- Policy Engine ساختاریافته V7.43 از این نسخه به بعد فقط برای کلاینتی فعال می‌شود که صریحاً X-BM-Policy-Version: 2 بفرستد.
- V7.43.1 این Header را روی app_api و endpointهای direct app ارسال می‌کند.
- نسخه‌های قدیمی که این Header را ندارند، قرارداد Legacy را دریافت می‌کنند و ناگهان با State/HTTP جدید V7.43 روبه‌رو نمی‌شوند.
- app_api برای Legacy همان semantics قبلی 404/lock را نگه می‌دارد.
- api4/api6/archive1_live نیز State ساختاریافته و Section policy جدید را فقط برای Policy V2 فعال می‌کنند.
- فیلدهای جدید app_config همچنان additive هستند؛ نسخه قدیمی می‌تواند آن‌ها را نادیده بگیرد.

نکته مهم:
- این Compatibility Layer به معنی این است که کنترل‌های جدید و پیام‌های دقیق V7.43 برای V7.43.1+ تضمین می‌شوند.
- نسخه‌های خیلی قدیمی مانند 2.2 قرارداد قدیمی خودشان را حفظ می‌کنند؛ بنابراین ممکن است پیام‌های جدید Hidden/Disabled را به شکل جدید نمایش ندهند، ولی API آن‌ها با تغییر قرارداد V7.43 شکسته نمی‌شود.
