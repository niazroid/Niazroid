#!/usr/bin/env python3
"""Safety guard for requested TV polish (static checks, not Android runtime tests)."""
from pathlib import Path
import re
root=Path(__file__).resolve().parent
main=(root/'app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text(encoding='utf-8')
scroll=(root/'app/src/main/java/ir/bankmoviee/app/BankmovieSmoothScrollView.kt').read_text(encoding='utf-8')
card=main.split('private fun unifiedNetworkFailureCard(',1)[1].split('private fun errorView(',1)[0]
assert 'bm_no_wifi_original' in card
assert 'bm_v14_clapperboard' not in card, 'Decorative clapperboard must not reappear'
assert 'fun errorActionButton(' in card and 'LinearLayout.HORIZONTAL' in card
assert 'clipToOutline = true' in card and 'clipChildren = true' in card
assert 'setCompoundDrawablesRelativeWithIntrinsicBounds(' not in card
assert card.count('actions.addView(errorActionButton(') == 2
assert 'bm_home_error_retry' in card and 'bm_home_error_channel' in card
assert 'bm_unified_network_error' in main and 'homeFailedRailBoxes' in main
assert 'v is TextView || v.tag == "bm_v73_detail_more_info"' in main
assert 'if (isTvLike()) -2 else -1' in main
assert 'LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.RIGHT }' in main
assert 'private fun animateTvPosterRailFocus(' in main
assert 'rail.smoothScrollTo(desired, 0)' in main
assert 'coerceIn(0, maxX)' in main
assert 'scroller.tag = "bm_tv_home_rail"' in main
assert 'managedHomePosterFocus' in scroll
assert 'tag != "bm_tv_home_rail"' in scroll
assert 'private fun clampRetainedTvHomeRailOffsets()' in main
assert 'tryRestoreHomeSession()' in main
assert 'if (isTvLike()) {\n            retainedHomeSession = null\n            return false' not in main
assert 'if (isTvLike()) {\n            retainedHomeSession = null\n            return\n' not in main
assert 'resetHomeTvRailViewportsToNewest()' not in main.split('private fun rebindHomeTvFocusAfterLifecycle()',1)[1].split('private fun handleHomePosterDirectionalFocus(',1)[0]
assert 'override fun onTrimMemory(level: Int)' in main
assert 'navigationHistory.add { restorer() }' not in main.split('private fun pushCurrentScreenForBack()',1)[1].split('private fun runBackNavigationMotion(',1)[0]
print('TV_SMOOTH_CACHE_UI_STATIC_OK (not an Android build or device test)')
