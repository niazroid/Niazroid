#!/usr/bin/env bash
set -euo pipefail

if [[ -f BANKMOVIE_BUILD_SOURCE_2_3.txt ]] && grep -Fq 'focusPatch=V6.8 SURFACE REBUILD ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  bash verify_tv_focus_v68_surface_rebuild.sh
  echo 'V6_8_COMPAT_OK'
  exit 0
fi
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
need(){ grep -Fq "$2" "$1" || { echo "Missing marker: $2" >&2; exit 1; }; }
need "$MAIN" 'private fun applyNativeNextFocusId(source: View?, keyCode: Int, target: View?)'
need "$MAIN" 'AlertDialog owns a separate Window'
need "$MAIN" 'ROOT FIX 2.3/V6.6: never create the initial Weekly focus children while'
need "$MAIN" 'private fun wireTvContinueRailExact(header: View, row: ViewGroup)'
need "$MAIN" 'private fun wireTvContinueFullListExact(list: ViewGroup)'
need "$MAIN" 'API order is not guaranteed to match the displayed rank.'
need "$MAIN" 'MainActivity.dispatchKeyEvent'
need "$MAIN" 'view.setOnKeyListener { _, keyCode, event ->'
need 'app/build.gradle' 'versionName "2.3"'
if grep -Fq 'focusPatch=V6.7 NATIVE-FIRST ROOT' BANKMOVIE_BUILD_SOURCE_2_3.txt; then
  # V6.7 is a strict successor of V6.6. Validate the newer root patch instead of
  # rejecting the build because the historical V6.6 source tag is intentionally gone.
  bash verify_tv_focus_v67.sh
  echo 'TV_FOCUS_V66_VIDEO_ROOT_COMPAT_OK'
  exit 0
fi
need 'BANKMOVIE_BUILD_SOURCE_2_3.txt' 'focusPatch=V6.6 VIDEO ROOT'
need 'BANKMOVIE_BUILD_SOURCE_2_3.txt' 'sourceTag=BANKMOVIE-TV-2.3-V66-20260906'
echo 'TV_FOCUS_V66_VIDEO_ROOT_OK'
