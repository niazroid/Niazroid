-- Isolated Lua control logic test; not a real MPV rendering or Windows test.
local bindings,events,commands={}, {}, {}
local props={pause=true,duration=3600,['time-pos']=60,volume=50,speed=1,['media-title']='Movie {unsafe}', aid='1',sid='1',['track-list']={{id=1,type='sub',lang='fas',codec='subrip',title='Film2Media - Namava'},{id=2,type='sub',lang='fas',codec='ass',title='Film2Media - Filimo'},{id=1,type='audio',lang='eng',codec='aac',title='Original'},{id=2,type='audio',lang='fas',codec='aac',title='Persian dub'}}}
local time,xx,yy,ow,oh=0,0,0,1280,720
local ov={update=function()end};local timer
local mp={create_osd_overlay=function()return ov end,get_time=function()return time end,get_osd_size=function()return ow,oh,ow/oh end,get_mouse_pos=function()return xx,yy end,get_property=function(n,d)return props[n] or d end,get_property_number=function(n,d)return props[n] or d end,get_property_bool=function(n,d)if props[n]==nil then return d end return props[n] end,get_property_native=function(n,d)return props[n] or d end,set_property=function(n,v)props[n]=v;return true end,set_property_bool=function(n,v)props[n]=v;return true end,set_property_number=function(n,v)props[n]=v;return true end,commandv=function(...)local a={...};commands[#commands+1]=a;if a[1]=='cycle' then props[a[2]]=not props[a[2]] end;return true end,add_forced_key_binding=function(k,n,f)bindings[k]=f end,register_event=function(k,f)events[k]=f end,observe_property=function()end,add_periodic_timer=function(_,f)timer=f end,osd_message=function()end}
local inputRequest
local filePath=os.tmpname();os.remove(filePath)
local prefsData, fileData
local originalOpen,originalGetenv=io.open,os.getenv
os.getenv=function(k)if k=='LOCALAPPDATA' then return 'test-local-appdata' end;return originalGetenv(k)end
io.open=function(p,mode) if p=='test-local-appdata/BankMovie-player-settings.json' then
  if mode=='wb' then return {write=function(_,v)fileData=v end,close=function()end} end
  if fileData then return {read=function()return fileData end,close=function()end} end
  return nil
end;return originalOpen(p,mode)end
package.loaded['mp.utils']={format_json=function(t)prefsData={};for k,v in pairs(t)do prefsData[k]=v end;return 'mock-json' end,parse_json=function()return prefsData end,file_info=function(p)if p=='C:\\movie.srt' then return {is_file=true} elseif p=='C:\\' then return {is_dir=true} end end,readdir=function(p,t) if p=='C:\\' and t=='files' then return {'movie.srt','ignore.exe'} end;return {} end}
package.loaded['mp.input']={get=function(o)inputRequest=o end}
mp.remove_key_binding=function(n)end
package.loaded.mp=mp
mp.set_property_native=function(n,v)props[n]=v;return true end

dofile('player/cinema.lua')
local function click(x,y)xx,yy=x,y;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});bindings.MBTN_LEFT({event='up'})end
local function geometry()local sc=math.min(ow/760,oh/480,1.15);return ow/sc,oh/sc,sc end
local function at(x,y)local _,_,sc=geometry();click(x*sc,y*sc)end
local function geomPanel(count)
    local w,h=geometry();local shown=math.min(count,math.max(1,math.floor((h-182)/52)))
    local mw=math.min(370,w-32);local mx=w-mw-18;local my=h-75-(82+shown*52+10)
    return mx,my,mw,shown
end
local function rowAt(count,i,offset)local mx,my,mw=geomPanel(count);at(mx+mw-90,my+82+(i-1-(offset or 0))*52+26)end
local function tabAt(count,i)local mx,my,mw=geomPanel(count);at(mx+12+(i-.5)*(mw-24)/4,my+59)end
local function barAt(count,i,start,endv,offset)
    local mx,my,mw=geomPanel(count);local x=mx+14+17;local width=mw-26-34;local y=my+82+(i-1-(offset or 0))*52+2+48-14+2
    local _,_,sc=geometry();xx,yy=(x+width*start)*sc,y*sc;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='down'});xx=(x+width*endv)*sc;bindings.MOUSE_MOVE();bindings.MBTN_LEFT({event='up'})
end
local function swatchAt(count,i,j,total)local mx,my,mw=geomPanel(count);at(mx+14+8+(j-.5)*(mw-26-16)/total,my+82+(i-1)*52+34)end
local function snap(name) if os.getenv('BM_TEST_RENDER') then local f=originalOpen('/tmp/bm-ui-'..name..'.assdata','wb');f:write(ov.res_x..' '..ov.res_y..'\n'..ov.data);f:close()end end
assert(ov.data:find('Movie',1,true));assert(not ov.data:find('{unsafe}',1,true));events['playback-restart']();timer()
local w,h=geometry();local cy=math.min(h*.48,h-126);local step=math.min(42,w*.055);local sx=w-30-step*3
at(w/2,cy);assert(props.pause==false);at(w/2,cy);assert(props.pause==true)
bindings.RIGHT();assert(commands[#commands][1]=='seek' and commands[#commands][2]==10)
at(w/2,h-56);assert(commands[#commands][1]=='seek' and commands[#commands][3]=='absolute-percent+exact')
at(sx-35,h-26);assert(ov.data:find('Film2Media - Namava',1,true));assert(not ov.data:find('Persian dub',1,true));snap('sub')
rowAt(5,3);assert(props.sid=='2' and props.aid=='1' and props['sub-visibility']==true)
rowAt(5,1);assert(props.sid=='no' and props.aid=='1')
tabAt(5,2);assert(ov.data:find('Persian dub',1,true));assert(not ov.data:find('Film2Media - Namava',1,true));rowAt(3,2);assert(props.aid=='2' and props.sid=='no');snap('audio')
-- direct audio access and four tabs
at(sx-82-35,h-26);assert(not ov.data:find('Persian dub',1,true));at(sx-82-35,h-26);assert(ov.data:find('Persian dub',1,true))
tabAt(3,4);snap('style');rowAt(11,1);rowAt(15,2);assert(props['sub-font']=='Tahoma');assert(prefsData['sub-font']=='Tahoma')
bindings.ESC();barAt(11,2,.2,.75);assert(props['sub-font-size']==81);assert(prefsData['sub-font-size']==81)
swatchAt(11,3,2,8);assert(props['sub-color']=='#FFD54A');swatchAt(11,3,8,8);snap('color');barAt(5,2,1,0);assert(props['sub-color']=='#00D54A');assert(prefsData['sub-color']=='#00D54A');bindings.ESC()
barAt(11,4,.9,.2);assert(props['sub-pos']==60);rowAt(11,5);assert(props['sub-ass-override']=='force')
barAt(11,7,.1,.5);assert(props['sub-outline-size']==3)
-- scroll and drag scrollbar, open background by scrolling down
for i=1,3 do bindings.WHEEL_DOWN()end
rowAt(11,10,3);rowAt(5,2);assert(props['sub-back-color']=='#A6000000');barAt(5,5,.6,.4);assert(props['sub-back-color']=='#66000000');bindings.ESC()
-- sub file browser, invalid extension excluded, no typed color required
tabAt(11,3);rowAt(5,4);assert(ov.data:find('C:',1,true));rowAt(2,2);assert(ov.data:find('movie.srt',1,true) and not ov.data:find('ignore.exe',1,true));rowAt(3,3);assert(commands[#commands][1]=='sub-add' and commands[#commands][2]=='C:\\movie.srt')
rowAt(5,5);barAt(5,1,.5,.6);assert(math.abs(props['sub-delay']-1)<.01);bindings.ESC()
tabAt(5,2);rowAt(3,3);barAt(5,1,.5,.6);assert(math.abs(props['audio-delay']-1)<.01)
bindings.ESC();tabAt(3,1);barAt(7,4,.4,.8);assert(math.abs(props.speed-1.7)<.01);rowAt(7,5);rowAt(8,2);assert(props['video-aspect-override']=='16:9');barAt(8,6,0,.5);assert(props.panscan==.5)
-- close menu via top right then check volume, fullscreen, lock, auto-hide
local mx,my,mw=geomPanel(8);at(mx+mw-25,my+24)
at(w-30-step*2,h-26);rowAt(7,7);barAt(2,1,0,0);rowAt(2,2);time=301;props.pause=false;timer();assert(props.pause==true);local smx,smy,smw=geomPanel(2);at(smx+smw-25,smy+24);time=0;timer()
at(29,h-26);at(34+104,h-88);assert(math.abs(props.volume-50)<1);at(29,h-26)
at(w-30,h-26);assert(props.fullscreen==true);bindings.ESC();assert(props.fullscreen==false)
at(w-30-step,h-26);assert(not ov.data:find('Movie',1,true));bindings.ESC();assert(ov.data:find('Movie',1,true));assert(ov.data:find('\\p4',1,true))
props.pause=false;time=10;timer();assert(ov.data=='');bindings.MOUSE_MOVE();assert(ov.data~='')
for _,size in ipairs({{320,180},{640,360},{1920,1080},{800,600},{3440,1440},{1280,400}}) do ow,oh=size[1],size[2];timer();local w,h=geometry();local step=math.min(42,w*.055);at(w-30-step*2,h-26);assert(ov.data:find('تنظیمات پخش',1,true));local mx,my,mw=geomPanel(7);assert(my>=0 and mx>=0 and mx+mw<=w);at(mx+mw-25,my+24)end
props['sub-font']=nil;props['sub-color']=nil;dofile('player/cinema.lua');assert(props['sub-font']=='Tahoma' and props['sub-color']=='#00D54A')
io.open=originalOpen;os.getenv=originalGetenv
print('PASS: separate audio/subtitle IDs, visible buttons, real slider drag, color swatches and custom RGB, font, ASS, file browser, audio/sub delays, speed and aspect, saved prefs, responsive layout and playback controls')
