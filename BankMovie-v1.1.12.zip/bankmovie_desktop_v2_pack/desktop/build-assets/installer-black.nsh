!macro customHeader
  !define MUI_BGCOLOR "000000"
  !define MUI_TEXTCOLOR "F5F8FC"
  !define MUI_INSTFILESPAGE_COLORS "F5F8FC 000000"
!macroend

!macro customInit
  SetCtlColors $HWNDPARENT F5F8FC 000000
!macroend
