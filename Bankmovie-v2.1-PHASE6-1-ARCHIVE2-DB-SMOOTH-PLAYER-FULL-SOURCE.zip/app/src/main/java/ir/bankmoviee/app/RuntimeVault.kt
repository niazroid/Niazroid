package ir.bankmoviee.app

/**
 * Keeps bootstrap endpoints and request credentials out of the APK's plain
 * string table. This is hardening, not perfect secrecy: runtime traffic can
 * still be inspected on a controlled device. Real server-side secrets must
 * never depend on client obscurity alone.
 */
internal object RuntimeVault {
    private val BASE_URLData = intArrayOf(4927, 4873, 5061, 4995, 5168, 5275, 5410, 5288, 5485, 5316, 5415, 5264, 5590, 5606, 5395, 5414, 5410, 5672, 5711, 5866, 5825, 5598)
    private const val BASE_URLSeed = 4951
    private val BASE_DOMAINData = intArrayOf(9216, 9466, 9398, 9588, 9511, 9608, 9777, 9655, 9794, 9687, 9780, 9831, 9889, 9973, 9728, 9737, 9789, 10043, 10076, 10237, 10166)
    private const val BASE_DOMAINSeed = 9320
    private val ACCOUNT_API_URLData = intArrayOf(13585, 13803, 13735, 13925, 13846, 14073, 14080, 13958, 14163, 13990, 14085, 14198, 14256, 14276, 14321, 14104, 14092, 14401, 14583, 14538, 14501, 14396, 14398, 14537, 14673, 14536, 14702, 14814, 14632, 14729, 14824, 14816, 14633, 14934, 14877, 14917, 14893, 14867)
    private const val ACCOUNT_API_URLSeed = 13689
    private val GENRE_ASSET_BASE_URLData = intArrayOf(18146, 18116, 18064, 18262, 18181, 18414, 18543, 18325, 18464, 18361, 18450, 18501, 18563, 18643, 18670, 18667, 18463, 18862, 18912, 18905, 18838, 18699, 18705, 18873, 19009, 18893, 19032, 19149, 19057, 19307, 19117, 19196, 18968, 19253, 19255, 19305)
    private const val GENRE_ASSET_BASE_URLSeed = 18058
    private val CONFIG_URL_PRIMARYData = intArrayOf(22515, 22453, 22401, 22599, 22772, 22751, 22910, 22756, 22833, 22664, 23011, 22868, 22930, 22946, 23007, 23034, 23022, 23284, 23179, 23214, 23173, 23066, 23264, 23211, 23347, 23270, 23390, 23456, 23297, 23675, 23472, 23492, 23381, 23569, 23613, 23591)
    private const val CONFIG_URL_PRIMARYSeed = 22427
    private val CONFIG_URL_SECONDARYData = intArrayOf(26820, 26790, 26994, 26936, 27115, 27084, 27213, 27123, 27142, 27035, 27376, 27195, 27517, 27313, 27340, 27341, 27385, 27532, 27586, 27575, 27768, 27497, 27635, 27548, 27684, 27541, 27693, 27791, 27886, 27976, 27779, 27859, 27810, 27906, 27918, 27928)
    private const val CONFIG_URL_SECONDARYSeed = 26796
    private val APP_API_URLData = intArrayOf(31189, 31127, 31331, 31273, 31450, 31549, 31580, 31426, 31511, 31594, 31681, 31498, 31820, 31616, 31677, 31708, 31688, 31958, 31977, 31872, 32107, 31864, 31938, 31885, 32021, 31876, 32062, 32129, 32248, 32273, 32139, 32173, 32237)
    private const val APP_API_URLSeed = 31165
    private val ARCHIVE1_LIVE_URLData = intArrayOf(39863, 40049, 40013, 39947, 40120, 40211, 40378, 40224, 40437, 40268, 40383, 40424, 40494, 40574, 40347, 40382, 40362, 40624, 40647, 40802, 40777, 40534, 40612, 40813, 40932, 40597, 40936, 41061, 40918, 41040, 41026, 40843, 40918, 41171, 41212, 41141, 41179, 41121, 41093)
    private const val ARCHIVE1_LIVE_URLSeed = 39903
    private val HOST_PRIMARYData = intArrayOf(6729, 6704, 6891, 6828, 7034, 6938, 7063, 6962, 7046, 6940, 7219, 7078, 7421)
    private const val HOST_PRIMARYSeed = 6699
    private val HOST_PRIMARY_WWWData = intArrayOf(11083, 11029, 11233, 11254, 11338, 11495, 11420, 11271, 11417, 11493, 11608, 11401, 11717, 11531, 11620, 11613, 11614)
    private const val HOST_PRIMARY_WWWSeed = 11068
    private val HOST_SECONDARYData = intArrayOf(15407, 15378, 15561, 15490, 15700, 15864, 15989, 15636, 15968, 15797, 15947, 15774, 16065)
    private const val HOST_SECONDARYSeed = 15437
    private val HOST_SECONDARY_WWWData = intArrayOf(19753, 19955, 19919, 19924, 20008, 20169, 20346, 20197, 20347, 20163, 20262, 20331, 20391, 20414, 20248, 20281, 20286)
    private const val HOST_SECONDARY_WWWSeed = 19806
    private val TELEGRAM_URLData = intArrayOf(24071, 24289, 24253, 24443, 24360, 24451, 24586, 24496, 24659, 24467, 24588, 24694, 24828, 24803, 24636, 24617, 24596, 24872, 24886, 25037, 24962, 24908, 24842, 25056, 25157, 25034)
    private const val TELEGRAM_URLSeed = 24175
    private val TELEGRAM_HANDLEData = intArrayOf(24627, 24790, 24709, 24902, 24848, 25076, 25201, 25064, 25196, 25056, 25132, 25159, 25234)
    private const val TELEGRAM_HANDLESeed = 24689
    private val APP_KEYData = intArrayOf(28434, 28667, 28565, 28781, 28722, 28894, 29012, 28879, 28993, 28890, 28989, 29026, 29157, 29181, 29001, 28939, 29010, 29184, 29262, 29356)
    private const val APP_KEYSeed = 28528
    private val APP_SECRETData = intArrayOf(28856, 28866, 28906, 29049, 29017, 29098, 29184, 29139, 29194, 29182, 29253, 29202, 29315, 29319, 29420, 29248, 29203, 29509, 29679, 29589, 29678, 29565, 29527, 29600, 29727, 29611, 29766, 29824, 29804, 30004, 29913, 29882, 29701, 30064, 30045, 29961, 29999, 30042, 30198, 30182, 30251, 30297, 30176, 30333, 30371, 30314, 30431, 30458, 30311, 30578, 30425, 30379, 30607, 30681, 30627, 30675, 30768, 30811, 30901, 30644, 30804, 30875, 30844, 30872)
    private const val APP_SECRETSeed = 28801

    private fun decode(data: IntArray, seed: Int): String {
        val chars = CharArray(data.size)
        for (i in data.indices) {
            val key = (seed + i * 31 + ((i * i * 7) and 0xff)) and 0xffff
            chars[i] = (data[i] xor key).toChar()
        }
        return String(chars)
    }

    val base_url: String get() = decode(BASE_URLData, BASE_URLSeed)
    val base_domain: String get() = decode(BASE_DOMAINData, BASE_DOMAINSeed)
    val account_api_url: String get() = decode(ACCOUNT_API_URLData, ACCOUNT_API_URLSeed)
    val genre_asset_base_url: String get() = decode(GENRE_ASSET_BASE_URLData, GENRE_ASSET_BASE_URLSeed)
    val config_url_primary: String get() = decode(CONFIG_URL_PRIMARYData, CONFIG_URL_PRIMARYSeed)
    val config_url_secondary: String get() = decode(CONFIG_URL_SECONDARYData, CONFIG_URL_SECONDARYSeed)
    val app_api_url: String get() = decode(APP_API_URLData, APP_API_URLSeed)
    val archive1_live_url: String get() = decode(ARCHIVE1_LIVE_URLData, ARCHIVE1_LIVE_URLSeed)
    val host_primary: String get() = decode(HOST_PRIMARYData, HOST_PRIMARYSeed)
    val host_primary_www: String get() = decode(HOST_PRIMARY_WWWData, HOST_PRIMARY_WWWSeed)
    val host_secondary: String get() = decode(HOST_SECONDARYData, HOST_SECONDARYSeed)
    val host_secondary_www: String get() = decode(HOST_SECONDARY_WWWData, HOST_SECONDARY_WWWSeed)
    val telegram_url: String get() = decode(TELEGRAM_URLData, TELEGRAM_URLSeed)
    val telegram_handle: String get() = decode(TELEGRAM_HANDLEData, TELEGRAM_HANDLESeed)
    val app_key: String get() = decode(APP_KEYData, APP_KEYSeed)
    val app_secret: String get() = decode(APP_SECRETData, APP_SECRETSeed)
}
