package ir.bankmoviee.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat

object DownloadScheduleManager {
    private const val PREFS = "bankmovie_download_schedule"
    private const val KEY_START_AT = "start_at"
    const val ACTION_FIRE = "ir.bankmoviee.app.download.SCHEDULE_FIRE"
    private const val REQUEST_CODE = 19121

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun startAt(context: Context): Long = prefs(context).getLong(KEY_START_AT, 0L)

    fun isActive(context: Context): Boolean = startAt(context) > System.currentTimeMillis()

    fun schedule(context: Context, atMillis: Long) {
        val safeAt = atMillis.coerceAtLeast(System.currentTimeMillis() + 5_000L)
        prefs(context).edit().putLong(KEY_START_AT, safeAt).apply()
        arm(context, safeAt)
    }

    fun cancel(context: Context) {
        prefs(context).edit().remove(KEY_START_AT).apply()
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.cancel(pendingIntent(context))
    }

    fun reschedule(context: Context) {
        val at = startAt(context)
        if (at <= 0L) return
        if (at <= System.currentTimeMillis()) {
            fireNow(context)
        } else {
            arm(context, at)
        }
    }

    private fun arm(context: Context, atMillis: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pendingIntent(context)
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && alarm.canScheduleExactAlarms() ->
                alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ->
                alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, atMillis, pi)
            else -> alarm.set(AlarmManager.RTC_WAKEUP, atMillis, pi)
        }
    }

    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, DownloadScheduleReceiver::class.java).apply { action = ACTION_FIRE }
        return PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun fireNow(context: Context) {
        prefs(context).edit().remove(KEY_START_AT).apply()
        InternalDownloadStore.releaseScheduled(context)
        val service = Intent(context, InternalDownloadService::class.java).apply {
            action = InternalDownloadService.ACTION_RESTORE
        }
        ContextCompat.startForegroundService(context, service)
    }
}

class DownloadScheduleReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != DownloadScheduleManager.ACTION_FIRE) return
        DownloadScheduleManager.fireNow(context)
    }
}
