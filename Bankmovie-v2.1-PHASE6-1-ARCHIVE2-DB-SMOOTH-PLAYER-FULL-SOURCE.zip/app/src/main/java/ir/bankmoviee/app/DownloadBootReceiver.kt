package ir.bankmoviee.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat

/** Restores queued downloads after reboot or app replacement without changing saved files. */
class DownloadBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action.orEmpty()
        if (action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED, Intent.ACTION_LOCKED_BOOT_COMPLETED)) return
        AdminPushScheduler.ensureScheduled(context)
        AdminPushScheduler.runNow(context)
        runCatching { DownloadScheduleManager.reschedule(context) }
        if (InternalDownloadStore.recoverable(context).isEmpty()) return
        val service = Intent(context, InternalDownloadService::class.java).apply { this.action = InternalDownloadService.ACTION_RESTORE }
        ContextCompat.startForegroundService(context, service)
    }
}
