const fs = require('fs');
const path = require('path');
const JavaScriptObfuscator = require('javascript-obfuscator');
const root = path.resolve(__dirname, '..');
const targets = ['electron/main.js', 'electron/preload.js', 'electron/runtime.generated.js'];
const opts = {
  compact: true,
  identifierNamesGenerator: 'hexadecimal',
  renameGlobals: false,
  stringArray: true,
  rotateStringArray: true,
  shuffleStringArray: true,
  stringArrayThreshold: 0.90,
  stringArrayEncoding: ['base64'],
  splitStrings: true,
  splitStringsChunkLength: 8,
  controlFlowFlattening: false,
  deadCodeInjection: false,
  selfDefending: false,
  transformObjectKeys: false,
  unicodeEscapeSequence: false
};
for (const rel of targets) {
  const file = path.join(root, rel);
  const source = fs.readFileSync(file, 'utf8');
  const out = JavaScriptObfuscator.obfuscate(source, opts).getObfuscatedCode();
  fs.writeFileSync(file, out, 'utf8');
}
