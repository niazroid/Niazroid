// BankMovie Windows v1.1.40 — zero-secret client runtime.
// Only a PUBLIC verification key ships in the app. It cannot sign configs or issue tokens.
module.exports = Object.freeze({
  controllerDomainB64: 'aHR0cHM6Ly9iYW5rbW92aWV6LnRvcA==',
  contentDomainB64: 'aHR0cHM6Ly9iYW5rbW92aWUudG9w',
  domainB64: 'aHR0cHM6Ly9iYW5rbW92aWUudG9w',
  configPublicKey: '-----BEGIN PUBLIC KEY-----\nMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAsRtMbNPRn62rDAatJx8k\nx4qjMNibq2RHU+hFqRGqk5ETpC+H51V4y6+q8/Dp10wgoZy8BGfSrOTc+QFPD45w\nzM6d67xNPUKlgnJMsC93evKmIAw1Rlu2OlEPgWwb49owSTyC+r15QFYYQeUd/ftx\nIsutZTUtqepcg4LRJD4WepLXtvFpiuy2iZlKrj55Y2H+jGQQCw26RNlulMfGKLfe\nlRwgp7P5vkCR674qmSKNmCmhkgjNsB/ZcB4GoNRB9LCfpzY8S1f4DoRvBkFWhnOu\nwlNDLxZRqNvDT+7dc74XRk8ZNXQIA2YmR3LR0J1Lzz1lMevrAIxpef4vNTs1XjCb\nLwMcz0Er5Wv8RpOs4YDGkGnaEtIzQP2ZTiyuwRdLXiaHBzxNALevvSFRma58Ma6X\nIiOBMzIIg6uVhKnXiUNkN4fKETog2GFFUs/5UJYUFUWIuD7b/oVeBswRvtqSkiHU\nrDV+YLg3vNz7rlHgiroVC9NRjFfpYxxY2GOoQ6BKifs1AgMBAAE=\n-----END PUBLIC KEY-----\n'
});
