// Only signed controller configuration may expand trusted HTTPS content origins.
'use strict';
function normalHost(raw) {
  try {
    const u = new URL(String(raw||''));
    if (u.protocol !== 'https:' || u.port || u.username || u.password || u.search || u.hash ||
        (u.pathname && u.pathname !== '/') || u.hostname.length>253 ||
        !/^[a-z0-9-]+(?:\.[a-z0-9-]+)+$/i.test(u.hostname) ||
        /^(?:localhost|.*\.localhost|.*\.local|.*\.internal)$/i.test(u.hostname) ||
        /\.(?:0|test|invalid)$/i.test(u.hostname)) return '';
    return u.origin;
  } catch { return ''; }
}
function sources(primary, extra=[]) {
  const base=normalHost(primary); if(!base) throw new Error('Primary content origin invalid');
  const out=[base];
  for (const v of Array.isArray(extra)?extra:[]) {
    const next=normalHost(typeof v==='string'?v:(v && v.base_url));
    if(next && !out.includes(next) && out.length<5)out.push(next);
  }
  return out;
}
function replaceOrigin(raw, origin) {
  const old=new URL(String(raw));
  if(old.protocol!=='https:' || !/^\/v1\/[a-zA-Z0-9_-]+\.php$/.test(old.pathname)) throw new Error('Not a Windows content API endpoint');
  return origin + old.pathname + old.search;
}
function retryable(status){return status===502||status===503||status===504||status>=500;}
function candidateOrigins(primary, extras, badUntil={}, now=Date.now()) {
  const all=sources(primary,extras);
  // Never give up on the primary: retry it when cooldown elapses.
  const up=all.filter(o=>!badUntil[o] || badUntil[o]<=now);
  const down=all.filter(o=>badUntil[o] && badUntil[o]>now);
  return [...up,...down];
}
module.exports={normalHost,sources,replaceOrigin,retryable,candidateOrigins};
