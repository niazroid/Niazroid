# BankMovie Windows 1.1.38

- کنترلر ریموت ویندوز به `https://bankmoviez.top/v1/desktop_config.php` منتقل شد.
- دامنه محتوای ویندوز مستقل و روی `https://bankmovie.top` باقی ماند.
- همه درخواست‌های محتوایی ویندوز از مسیر `/v1/` عبور می‌کنند.
- درخواست‌های `/v1/` با `X-BM-App-Key / X-BM-Ts / X-BM-Sign` امضا می‌شوند.
- API مستقیم آرشیو 1 و 3 نیز به `/v1/api2.php` و `/v1/api6.php` منتقل شد.
- Android و APIهای روت سایت دست‌نخورده می‌مانند.
