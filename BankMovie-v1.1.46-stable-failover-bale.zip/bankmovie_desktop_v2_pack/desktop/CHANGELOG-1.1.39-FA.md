# BankMovie Windows 1.1.39

- حذف کامل Secret ثابت از EXE و Build.
- Remote Controller امضاشده روی `bankmoviez.top`.
- کلید اختصاصی P-256 برای هر نصب ویندوز؛ Private Key با Electron `safeStorage`/Windows DPAPI نگهداری می‌شود.
- Challenge یک‌بارمصرف و Access Token کوتاه‌عمر از Controller.
- DPoP-like proof روی تک‌تک درخواست‌های `/v1/` شامل method/path/timestamp/nonce/body hash.
- Replay protection سمت `bankmovie.top`.
- تمام APIهای Windows داخل `/v1/`؛ Android و APIهای فعلی روت دست‌نخورده‌اند.
- Box Office نیز از مسیر محافظت‌شده `/v1/api_boxoffice.php` استفاده می‌کند.
- Last-known-good Remote Config برای تحمل اختلال موقت Controller.
