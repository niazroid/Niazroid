# BankMovie Windows 1.1.40

- تمدید خودکار و پیش‌دستانه توکن دستگاه بدون وقفه کاربر
- Force re-token از پنل مدیر و invalidation نسلی توکن‌ها
- پاکسازی قطعی فایل‌های موقت امنیتی + کنترل دستی در پنل
- اصلاح هویت اعلان‌های Windows به BankMovie به‌جای Electron
- سخت‌سازی Electron با ASAR integrity/fuses در Build
- Obfuscation فقط برای سخت‌تر کردن Reverse Engineering؛ امنیت اصلی همچنان Zero-Secret است
- Android و APIهای فعلی موبایل بدون تغییر
