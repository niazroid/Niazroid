/* Native local document: original site UI, separate origin and no Electron preload in the child. */
const BM_DISCOVER_ORIGIN='bm-discover://local';
let bmDiscoverFrame=null;
const BM_DISCOVER_MODES=new Set(['desktop_bootstrap','catalog','explorer','explorer_item','decade','category','featured_collections','collections','lookup','for_you','mood','sentence','mixer','taste','similar','personal','surprise','popular','daily']);
function bmDiscoverTheme(){return document.documentElement.dataset.bmPalette||'dark-green'}
function bmDiscoverAllowed(){return bm1124SectionEnabled('discover',true)&&bm1124SectionEnabled('advanced_search',true)&&feature('advanced_search_enabled')&&enabledArchives().includes(2)}
function bmDiscoverNavigate(raw){
 if(typeof raw!=='string'||!/^\/(?!\/)/.test(raw)||raw.length>2048||raw.includes('..'))return;
 const u=new URL(raw,'https://bankmovie.top');if(u.origin!=='https://bankmovie.top')return;
 let m=u.pathname.match(/^\/movie\/[a-z0-9-]+-(\d+)\/?$/i);if(m)return openDetail({id:m[1],archive:2,source:'db_movies'});
 if(u.pathname==='/movie.php'&&/^tt\d{5,12}$/.test(u.searchParams.get('imdb')||''))return openDetail({id:u.searchParams.get('imdb'),archive:2,source:'db_movies'});
 m=u.pathname.match(/^\/collection\/([^/]+)\/?$/);if(m){let slug;try{slug=decodeURIComponent(m[1])}catch{return}if(/^[\p{L}\p{N}_-]{1,160}$/u.test(slug))return openCollection(slug)}
 if(u.pathname==='/collections')return route('collections');if(u.pathname==='/genres')return route('genres');
 if(u.pathname==='/search'||u.pathname==='/search.php')return showSearch((u.searchParams.get('q')||u.searchParams.get('genre')||u.searchParams.get('country')||'').slice(0,160));
 if(u.pathname==='/view_all'){const cat=u.searchParams.get('cat');if(cat==='top-movies'||cat==='top-series')return bm196Top250Navigate(cat==='top-series'?'series':'movies')}
 if(u.pathname==='/')return route('home');
}
window.addEventListener('message',async e=>{
 const frame=bmDiscoverFrame,m=e.data;if(!frame?.isConnected||e.source!==frame.contentWindow||e.origin!==BM_DISCOVER_ORIGIN||m?.bmDiscover!==1||!bmDiscoverAllowed())return;
 if(m.action==='navigate'){bmDiscoverNavigate(m.payload?.path);return}
 if(m.action==='reels'){frame.parentElement.classList.toggle('bm-discover-reels',m.payload?.open===true);return}
 if(!Number.isSafeInteger(m.id)||m.id<1)return;
 const send=(result,error)=>{if(frame.isConnected)frame.contentWindow.postMessage({bmDiscover:1,id:m.id,result,error},BM_DISCOVER_ORIGIN)};
 try{if(m.action==='init')return send({theme:bmDiscoverTheme(),smoothScroll:window.BMScroll?.enabled()!==false,loggedIn:!!state.user});
 const p=m.payload;if(!p||typeof p!=='object'||Array.isArray(p)||JSON.stringify(p).length>12000)throw Error('درخواست نامعتبر');
 let result;if(m.action==='recommend'&&BM_DISCOVER_MODES.has(p.mode||'mood')){const {action,...body}=p;result=await bridge.user('discover_native',body,'POST')}
 else if(m.action==='feedback'&&/^\d{1,12}$/.test(String(p.movie_id))&&['like','seen','less','clear'].includes(p.preference)){result=await bridge.user('discover_feedback',{movie_id:p.movie_id,preference:p.preference},'POST')}
 else throw Error('درخواست نامعتبر');
 if(!result?.success)throw Error(result?.message||'دریافت اطلاعات ناموفق بود');send(result.data||{});
 }catch(err){send(null,String(err?.message||err).slice(0,250))}
});
if(typeof ResizeObserver!=='undefined'){const h=$('#appHeader');if(h)new ResizeObserver(()=>{if(bmDiscoverFrame?.isConnected)bmDiscoverFrame.parentElement.style.setProperty('--bm-discover-header',h.offsetHeight+'px')}).observe(h)}
new MutationObserver(()=>{const f=bmDiscoverFrame;if(f?.isConnected)f.contentWindow.postMessage({bmDiscover:1,theme:bmDiscoverTheme()},BM_DISCOVER_ORIGIN)}).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme','data-bm-palette']});
async function bmShowNativeDiscover(){
 if(!bmDiscoverAllowed()){renderError(Error('این بخش فعلاً در دسترس نیست.'));return}
 setActiveNav('discover');const view=$('#view');view.classList.remove('bm-discover-reels');view.replaceChildren();view.style.setProperty('--bm-discover-header',($('#appHeader')?.offsetHeight||96)+'px');const f=document.createElement('iframe');f.id='bm-discover-frame';f.title='چی ببینیم؟';f.setAttribute('sandbox','allow-scripts allow-same-origin');f.setAttribute('referrerpolicy','no-referrer');bmDiscoverFrame=f;f.src=BM_DISCOVER_ORIGIN+'/discover';view.append(f);$('#mainScroller').scrollTop=0;
}

window.addEventListener("bm-smooth-scroll-change",e=>{const f=bmDiscoverFrame;if(f?.isConnected)f.contentWindow.postMessage({bmDiscover:1,smoothScroll:e.detail===true},BM_DISCOVER_ORIGIN)});
