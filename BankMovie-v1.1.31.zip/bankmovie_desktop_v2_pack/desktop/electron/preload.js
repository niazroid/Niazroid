const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('bankmovie', {
  bootstrap: () => ipcRenderer.invoke('bootstrap'),
  content: (action, params = {}) => ipcRenderer.invoke('content:request', action, params),
  searchOptions: (archive = 3) => ipcRenderer.invoke('search:options', archive),
  advancedSearch: (params = {}) => ipcRenderer.invoke('search:advanced', params),
  archive1Actor: (params = {}) => ipcRenderer.invoke('archive1:actor', params),
  user: (action, body = {}, method = 'POST') => ipcRenderer.invoke('user:request', action, body, method),
  logoutLocal: () => ipcRenderer.invoke('auth:clear'),
  getSettings: () => ipcRenderer.invoke('settings:get'),
  setSettings: (patch) => ipcRenderer.invoke('settings:set', patch),
  chooseDownloadDir: () => ipcRenderer.invoke('settings:choose-download-dir'),
  download: (meta) => ipcRenderer.invoke('download:add', meta),
  downloads: () => ipcRenderer.invoke('download:list'),
  downloadAction: (id, action) => ipcRenderer.invoke('download:action', id, action),
  getPlayers: () => ipcRenderer.invoke('player:list'),
  playExternal: (meta) => ipcRenderer.invoke('player:play', meta),
  boxOffice: () => ipcRenderer.invoke('boxoffice:get'),
  openWeb: (url, title = 'BankMovie') => ipcRenderer.invoke('browser:open', url, title),
  openExternal: (url) => ipcRenderer.invoke('shell:open', url),
  showItem: (filePath) => ipcRenderer.invoke('shell:show-item', filePath),
  openFile: (filePath) => ipcRenderer.invoke('file:open', filePath),
  onDownload: (cb) => ipcRenderer.on('download:update', (_e, payload) => cb(payload)),
  window: {
    minimize: () => ipcRenderer.send('window:minimize'),
    maximize: () => ipcRenderer.send('window:maximize'),
    toggleFullscreen: () => ipcRenderer.invoke('window:fullscreen'),
    onFullscreenState: (cb) => ipcRenderer.on('window:fullscreen-state', (_e, active) => cb(Boolean(active))),
    close: () => ipcRenderer.send('window:close')
  }
});
