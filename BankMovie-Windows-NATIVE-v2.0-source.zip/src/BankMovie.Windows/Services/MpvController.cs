using System.Collections.Concurrent;
using System.Diagnostics;
using System.Globalization;
using System.IO.Pipes;
using System.Text;
using System.Text.Json;

namespace BankMovie.Windows.Services;

public sealed class MpvController : IAsyncDisposable
{
    private readonly ConcurrentDictionary<long, TaskCompletionSource<JsonElement>> _pending = new();
    private readonly SemaphoreSlim _writeGate = new(1, 1);
    private Process? _process;
    private NamedPipeClientStream? _pipe;
    private StreamReader? _reader;
    private StreamWriter? _writer;
    private CancellationTokenSource? _readerCts;
    private Task? _readerTask;
    private long _requestId;
    private bool _disposed;

    public event EventHandler? ProcessExited;
    public bool IsReady => _pipe?.IsConnected == true && _process is { HasExited: false };

    public async Task StartAsync(IntPtr hostHandle, string executablePath, CancellationToken cancellationToken = default)
    {
        if (_disposed) throw new ObjectDisposedException(nameof(MpvController));
        if (IsReady) return;
        if (!File.Exists(executablePath)) throw new FileNotFoundException("فایل mpv.exe در کنار برنامه پیدا نشد.", executablePath);

        var pipeName = $"bankmovie-mpv-{Guid.NewGuid():N}";
        var logDirectory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "BankMovie", "logs");
        Directory.CreateDirectory(logDirectory);
        var logPath = Path.Combine(logDirectory, "mpv.log");

        var startInfo = new ProcessStartInfo
        {
            FileName = executablePath,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardError = false,
            RedirectStandardOutput = false,
            WorkingDirectory = Path.GetDirectoryName(executablePath) ?? AppContext.BaseDirectory
        };
        startInfo.ArgumentList.Add($"--wid={hostHandle.ToInt64().ToString(CultureInfo.InvariantCulture)}");
        startInfo.ArgumentList.Add($"--input-ipc-server=\\.\pipe\{pipeName}");
        startInfo.ArgumentList.Add("--idle=yes");
        startInfo.ArgumentList.Add("--force-window=yes");
        startInfo.ArgumentList.Add("--keep-open=yes");
        startInfo.ArgumentList.Add("--no-terminal");
        startInfo.ArgumentList.Add("--no-config");
        startInfo.ArgumentList.Add("--osc=no");
        startInfo.ArgumentList.Add("--input-default-bindings=no");
        startInfo.ArgumentList.Add("--cursor-autohide=no");
        startInfo.ArgumentList.Add("--hwdec=auto-safe");
        startInfo.ArgumentList.Add("--sub-auto=fuzzy");
        startInfo.ArgumentList.Add("--sub-codepage=utf-8");
        startInfo.ArgumentList.Add("--alang=fa,farsi,per,pes,en");
        startInfo.ArgumentList.Add("--slang=fa,farsi,per,pes,en");
        startInfo.ArgumentList.Add("--volume=75");
        startInfo.ArgumentList.Add($"--log-file={logPath}");

        _process = new Process { StartInfo = startInfo, EnableRaisingEvents = true };
        _process.Exited += (_, _) => ProcessExited?.Invoke(this, EventArgs.Empty);
        if (!_process.Start()) throw new InvalidOperationException("اجرای موتور پخش mpv ممکن نشد.");

        _pipe = new NamedPipeClientStream(".", pipeName, PipeDirection.InOut, PipeOptions.Asynchronous);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(12));
        try
        {
            await _pipe.ConnectAsync(timeout.Token);
        }
        catch
        {
            TryKillProcess();
            throw new InvalidOperationException("ارتباط برنامه با موتور پخش برقرار نشد. فایل گزارش mpv در پوشه LocalAppData ذخیره شده است.");
        }

        _reader = new StreamReader(_pipe, new UTF8Encoding(false), false, 4096, leaveOpen: true);
        _writer = new StreamWriter(_pipe, new UTF8Encoding(false), 4096, leaveOpen: true)
        {
            AutoFlush = true,
            NewLine = "\n"
        };
        _readerCts = new CancellationTokenSource();
        _readerTask = Task.Run(() => ReaderLoopAsync(_readerCts.Token));
    }

    public Task LoadAsync(string url, double startSeconds = 0, CancellationToken cancellationToken = default)
    {
        if (string.IsNullOrWhiteSpace(url)) throw new ArgumentException("لینک پخش خالی است.", nameof(url));
        var command = SendCommandAsync(["loadfile", url, "replace"], cancellationToken);
        if (startSeconds <= 1) return command;
        return LoadAndSeekAsync(command, startSeconds, cancellationToken);
    }

    private async Task LoadAndSeekAsync(Task command, double startSeconds, CancellationToken cancellationToken)
    {
        await command;
        await Task.Delay(700, cancellationToken);
        await SetPropertyAsync("time-pos", startSeconds, cancellationToken);
    }

    public Task TogglePauseAsync(CancellationToken cancellationToken = default) => SendCommandAsync(["cycle", "pause"], cancellationToken);
    public Task SeekAsync(double seconds, CancellationToken cancellationToken = default) => SendCommandAsync(["seek", seconds, "relative+exact"], cancellationToken);
    public Task SeekAbsoluteAsync(double seconds, CancellationToken cancellationToken = default) => SendCommandAsync(["seek", Math.Max(0, seconds), "absolute+exact"], cancellationToken);
    public Task CycleSubtitleAsync(CancellationToken cancellationToken = default) => SendCommandAsync(["cycle", "sub"], cancellationToken);
    public Task CycleAudioAsync(CancellationToken cancellationToken = default) => SendCommandAsync(["cycle", "audio"], cancellationToken);

    public Task SetPropertyAsync(string property, object value, CancellationToken cancellationToken = default) =>
        SendCommandAsync(["set_property", property, value], cancellationToken);

    public async Task<double?> GetDoublePropertyAsync(string property, CancellationToken cancellationToken = default)
    {
        var data = await SendCommandForDataAsync(["get_property", property], cancellationToken);
        return data.ValueKind switch
        {
            JsonValueKind.Number when data.TryGetDouble(out var value) => value,
            JsonValueKind.String when double.TryParse(data.GetString(), NumberStyles.Float, CultureInfo.InvariantCulture, out var value) => value,
            _ => null
        };
    }

    public async Task<bool?> GetBoolPropertyAsync(string property, CancellationToken cancellationToken = default)
    {
        var data = await SendCommandForDataAsync(["get_property", property], cancellationToken);
        return data.ValueKind switch
        {
            JsonValueKind.True => true,
            JsonValueKind.False => false,
            JsonValueKind.Number when data.TryGetInt32(out var value) => value != 0,
            JsonValueKind.String when bool.TryParse(data.GetString(), out var value) => value,
            _ => null
        };
    }

    public async Task<string?> GetStringPropertyAsync(string property, CancellationToken cancellationToken = default)
    {
        var data = await SendCommandForDataAsync(["get_property", property], cancellationToken);
        return data.ValueKind == JsonValueKind.String ? data.GetString() : data.ToString();
    }

    private async Task SendCommandAsync(object[] command, CancellationToken cancellationToken)
    {
        _ = await SendCommandForDataAsync(command, cancellationToken);
    }

    private async Task<JsonElement> SendCommandForDataAsync(object[] command, CancellationToken cancellationToken)
    {
        if (!IsReady || _writer is null) throw new InvalidOperationException("موتور پخش آماده نیست.");
        var requestId = Interlocked.Increment(ref _requestId);
        var completion = new TaskCompletionSource<JsonElement>(TaskCreationOptions.RunContinuationsAsynchronously);
        _pending[requestId] = completion;
        using var registration = cancellationToken.Register(() => completion.TrySetCanceled(cancellationToken));
        var payload = JsonSerializer.Serialize(new Dictionary<string, object>
        {
            ["command"] = command,
            ["request_id"] = requestId
        });

        await _writeGate.WaitAsync(cancellationToken);
        try
        {
            await _writer.WriteLineAsync(payload.AsMemory(), cancellationToken);
            await _writer.FlushAsync(cancellationToken);
        }
        catch
        {
            _pending.TryRemove(requestId, out _);
            throw;
        }
        finally
        {
            _writeGate.Release();
        }

        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(5));
        try
        {
            return await completion.Task.WaitAsync(timeout.Token);
        }
        finally
        {
            _pending.TryRemove(requestId, out _);
        }
    }

    private async Task ReaderLoopAsync(CancellationToken cancellationToken)
    {
        if (_reader is null) return;
        try
        {
            while (!cancellationToken.IsCancellationRequested && IsReady)
            {
                var line = await _reader.ReadLineAsync(cancellationToken);
                if (line is null) break;
                using var document = JsonDocument.Parse(line);
                var root = document.RootElement;
                if (!root.TryGetProperty("request_id", out var idElement) || !idElement.TryGetInt64(out var requestId)) continue;
                if (!_pending.TryGetValue(requestId, out var completion)) continue;
                var error = root.TryGetProperty("error", out var errorElement) ? errorElement.GetString() : null;
                if (!string.IsNullOrWhiteSpace(error) && !string.Equals(error, "success", StringComparison.OrdinalIgnoreCase))
                {
                    completion.TrySetException(new InvalidOperationException($"خطای mpv: {error}"));
                    continue;
                }
                var data = root.TryGetProperty("data", out var dataElement) ? dataElement.Clone() : default;
                completion.TrySetResult(data);
            }
        }
        catch (OperationCanceledException)
        {
            // normal shutdown
        }
        catch (Exception ex)
        {
            foreach (var completion in _pending.Values) completion.TrySetException(ex);
        }
    }

    public async ValueTask DisposeAsync()
    {
        if (_disposed) return;
        _disposed = true;
        try
        {
            if (IsReady) await SendCommandAsync(["quit"], CancellationToken.None);
        }
        catch
        {
            // ignored during shutdown
        }
        _readerCts?.Cancel();
        if (_readerTask is not null)
        {
            try { await _readerTask.WaitAsync(TimeSpan.FromSeconds(2)); } catch { }
        }
        _writer?.Dispose();
        _reader?.Dispose();
        _pipe?.Dispose();
        TryKillProcess();
        _process?.Dispose();
        _readerCts?.Dispose();
        _writeGate.Dispose();
    }

    private void TryKillProcess()
    {
        try
        {
            if (_process is { HasExited: false }) _process.Kill(entireProcessTree: true);
        }
        catch
        {
            // ignored
        }
    }
}
