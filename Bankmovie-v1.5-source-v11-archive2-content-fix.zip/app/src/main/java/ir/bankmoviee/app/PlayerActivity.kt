package ir.bankmoviee.app

import android.app.Activity
import android.app.AlertDialog
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class PlayerActivity : Activity() {

    companion object {
        const val EXTRA_VIDEO_URL = "video_url"
        const val EXTRA_TITLE = "title"
        const val EXTRA_PLAYLIST_JSON = "playlist_json"
        const val EXTRA_PROGRESS_KEY = "progress_key"
    }

    data class Track(
        val url: String,
        val title: String,
        val quality: String,
        val type: String,
        val label: String,
        val typeFa: String,
        val displayLabel: String,
        val isAudio: Boolean,
        val season: Int,
        val episode: Int,
        val progressKey: String
    )

    private val blue = Color.rgb(0, 108, 255)
    private val blue2 = Color.rgb(30, 160, 255)
    private val blue3 = Color.argb(160, 35, 95, 255)
    private val panel = Color.argb(145, 5, 8, 15)
    private val stroke = Color.argb(145, 255, 255, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(178, 189, 208)

    private lateinit var root: FrameLayout
    private lateinit var videoLayout: VLCVideoLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var centerControls: LinearLayout
    private lateinit var titleText: TextView
    private lateinit var subText: TextView
    private lateinit var seek: SeekBar
    private lateinit var currentTimeText: TextView
    private lateinit var totalTimeText: TextView
    private lateinit var hudBox: TextView
    private lateinit var playIcon: ImageView
    private lateinit var playButtonBox: FrameLayout
    private lateinit var fitIcon: ImageView
    private lateinit var lockIcon: ImageView
    private lateinit var unlockOverlay: FrameLayout

    private var vlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private val tracks = mutableListOf<Track>()
    private var currentIndex = 0
    private var title = "Bankmovie"
    private var videoUrl = ""
    private var progressKey = ""
    private val modes = arrayOf("FIT", "CROP", "STRETCH")
    private val modeTitles = arrayOf("متناسب", "برش سینمایی", "کشیده")
    private var modeIndex = 0
    private var controlsLocked = false
    private var lastTap = 0L
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchStartBrightness = 0.5f
    private var touchStartVolume = 0
    private var gestureMode = 0 // 0 none, 1 brightness, 2 volume
    private var controlsVisible = true
    private var sleepMinutes = 0
    private var currentSpeed = 1.0f
    private var hardwareDecoder = true
    private var autoPlayNext = true
    private var lastProgressSaveAt = 0L
    private var resumeApplied = false
    private var subtitleDelayMs = 0
    private var subtitleScale = 112
    private var subtitlePositionIndex = 0
    private val subtitlePositions = arrayOf("پایین", "وسط", "بالا")
    private val subtitleMargins = arrayOf("70", "205", "350")
    private var subtitleColorIndex = 1
    private val subtitleColorLabels = arrayOf("سفید", "زرد", "آبی", "سبز", "قرمز", "بنفش", "مشکی")
    private val subtitleColorValues = arrayOf("16777215", "16776960", "3394815", "65280", "16733525", "11141290", "0")
    private var longPress2x = false
    private val longPressRunnable = Runnable {
        longPress2x = true
        setTemporarySpeed(true)
    }
    private val audioManager by lazy { getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager }

    private val hideRunnable = Runnable { if (!controlsLocked) hideControls() }
    private val hudHideRunnable = Runnable { hudBox.visibility = View.GONE }
    private val sleepRunnable = Runnable {
        Toast.makeText(this, "زمان خواب رسید", Toast.LENGTH_SHORT).show()
        finish()
    }
    private val progressRunnable = object : Runnable {
        override fun run() {
            updateProgress()
            handler.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        enterImmersive()
        parseIncoming()
        if (tracks.isEmpty() && videoUrl.isNotBlank()) tracks.add(Track(videoUrl, title, "", "", "", "", "", false, 0, 0, progressKey.ifBlank { "progress_$videoUrl" }))
        if (currentIndex !in tracks.indices) currentIndex = 0
        videoUrl = tracks.getOrNull(currentIndex)?.url ?: videoUrl
        title = tracks.getOrNull(currentIndex)?.title ?: title
        progressKey = tracks.getOrNull(currentIndex)?.progressKey?.ifBlank { progressKey } ?: progressKey
        currentBrightness = if (window.attributes.screenBrightness > 0f) window.attributes.screenBrightness else 0.55f
        buildUi()
        switchTo(currentIndex)
    }

    private var currentBrightness = 0.55f

    private fun parseIncoming() {
        videoUrl = intent.getStringExtra(EXTRA_VIDEO_URL) ?: ""
        title = intent.getStringExtra(EXTRA_TITLE) ?: "Bankmovie"
        progressKey = intent.getStringExtra(EXTRA_PROGRESS_KEY) ?: ""
        val json = intent.getStringExtra(EXTRA_PLAYLIST_JSON) ?: ""
        if (json.isNotBlank()) {
            try {
                val obj = JSONObject(json)
                currentIndex = obj.optInt("selectedIndex", 0)
                val arr = obj.optJSONArray("tracks") ?: JSONArray()
                for (i in 0 until arr.length()) {
                    val it = arr.optJSONObject(i) ?: continue
                    tracks.add(
                        Track(
                            it.optString("url"),
                            it.optString("title", title),
                            it.optString("quality"),
                            it.optString("type"),
                            it.optString("label"),
                            it.optString("type_fa"),
                            it.optString("display_label"),
                            it.optBoolean("is_audio", false),
                            it.optInt("season", 0),
                            it.optInt("episode", 0),
                            it.optString("progress_key").ifBlank { "progress_${it.optString("url")}" }
                        )
                    )
                }
            } catch (_: Throwable) {}
        }
    }

    private fun playerFocusDrawable(radiusDp: Int): android.graphics.drawable.Drawable {
        val glow = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.argb(50, 255, 180, 32))
            setStroke(dp(2), Color.argb(190, 255, 184, 38))
        }
        val ring = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(Color.TRANSPARENT)
            setStroke(dp(3), Color.rgb(255, 220, 90))
        }
        return android.graphics.drawable.LayerDrawable(arrayOf(glow, ring)).apply {
            setLayerInset(1, dp(4), dp(4), dp(4), dp(4))
        }
    }

    private fun applyPlayerFocus(view: View, radiusDp: Int = 22, scale: Float = 1.06f, normalElevation: Float = 0f) {
        view.isFocusable = true
        view.isClickable = true
        view.isFocusableInTouchMode = false
        view.setOnFocusChangeListener { v, has ->
            v.foreground = if (has) playerFocusDrawable(radiusDp) else null
            v.elevation = if (has) dp(24).toFloat() else normalElevation
            v.animate()
                .scaleX(if (has) scale else 1f)
                .scaleY(if (has) scale else 1f)
                .setDuration(135)
                .start()
        }
    }

    private fun focusPlayButton() {
        if (::playButtonBox.isInitialized) {
            playButtonBox.requestFocus()
        } else {
            root.requestFocus()
        }
    }

    private fun applyPlayerFocusTree(view: View) {
        view.postDelayed({
            fun walk(v: View) {
                val skip = v is ScrollView || v is SeekBar
                if (!skip && v.hasOnClickListeners()) {
                    applyPlayerFocus(v, 20, 1.055f, v.elevation)
                }
                if (v is android.view.ViewGroup) {
                    for (i in 0 until v.childCount) walk(v.getChildAt(i))
                }
            }
            walk(view)
        }, 160)
    }

    private fun buildUi() {
        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        videoLayout = VLCVideoLayout(this).apply {
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            isFocusable = true
            isFocusableInTouchMode = true
        }
        root.addView(videoLayout, FrameLayout.LayoutParams(-1, -1))

        hudBox = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(Color.argb(210, 0, 0, 0), dp(20), Color.argb(120, 255, 255, 255))
            visibility = View.GONE
        }
        root.addView(hudBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(28) })

        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(8))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(145, 0, 0, 0), Color.argb(0, 0, 0, 0))
            )
        }

        val back = glassIconButton(R.drawable.ic_player_back) { finish() }
        topBar.addView(back, LinearLayout.LayoutParams(dp(44), dp(44)))

        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        titleText = TextView(this).apply {
            text = title
            setTextColor(white)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            gravity = Gravity.CENTER
        }
        subText = TextView(this).apply {
            text = currentLabel()
            setTextColor(muted)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.CENTER
        }
        info.addView(titleText)
        info.addView(subText)
        topBar.addView(info, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10); marginEnd = dp(10) })

        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = rounded(Color.argb(82, 255, 255, 255), dp(24), Color.argb(65, 255, 255, 255))
            elevation = dp(10).toFloat()
        }
        actions.addView(simplePlayerIconWithText(R.drawable.ic_speedometer, speedLabel()) { showSpeedSheet() }, LinearLayout.LayoutParams(dp(50), dp(38)).apply { marginStart = dp(7) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_audio) { quickTypeSwitch(false) }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(7) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_cc) { quickTypeSwitch(true) }, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(7) })
        actions.addView(simplePlayerIcon(R.drawable.ic_player_settings) { showSettingsSheet() }, LinearLayout.LayoutParams(dp(38), dp(38)))
        topBar.addView(actions)
        root.addView(topBar, FrameLayout.LayoutParams(-1, dp(72), Gravity.TOP))

        centerControls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val rewind = circleAction(R.drawable.ic_player_replay, "10") { seekBy(-10000) }
        val play = FrameLayout(this).apply {
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(Color.argb(35, 0, 0, 0))
                setStroke(dp(2), Color.argb(220, 255, 255, 255))
            }
            elevation = dp(8).toFloat()
            applyPlayerFocus(this, 999, 1.12f, dp(8).toFloat())
            setOnClickListener { toggle() }
        }
        playButtonBox = play
        playIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_player_pause)
            setColorFilter(Color.WHITE)
        }
        play.addView(playIcon, FrameLayout.LayoutParams(dp(34), dp(34), Gravity.CENTER))
        val forward = circleAction(R.drawable.ic_player_forward, "10") { seekBy(10000) }
        centerControls.addView(rewind, LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginEnd = dp(18) })
        centerControls.addView(play, LinearLayout.LayoutParams(dp(70), dp(70)))
        centerControls.addView(forward, LinearLayout.LayoutParams(dp(56), dp(56)).apply { marginStart = dp(18) })
        root.addView(centerControls, FrameLayout.LayoutParams(-1, dp(96), Gravity.CENTER))

        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            setPadding(dp(16), dp(6), dp(16), dp(12))
            background = android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(0, 2, 8, 18), Color.argb(220, 2, 8, 18), Color.argb(246, 2, 8, 18))
            )
        }

        val timeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        currentTimeText = TextView(this).apply { text = "00:00"; setTextColor(white); textSize = 10.5f }
        totalTimeText = TextView(this).apply { text = "--:--"; setTextColor(muted); textSize = 10.5f; gravity = Gravity.END }
        timeRow.addView(currentTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        timeRow.addView(totalTimeText, LinearLayout.LayoutParams(0, -2, 1f))
        bottomBar.addView(timeRow)

        seek = SeekBar(this).apply {
            max = 1000
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            thumbTintList = android.content.res.ColorStateList.valueOf(blue2)
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        bottomBar.addView(seek, LinearLayout.LayoutParams(-1, dp(34)).apply { topMargin = dp(2) })

        val bottomActions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(5), dp(8), dp(5))
            background = rounded(Color.argb(78, 255, 255, 255), dp(24), Color.argb(68, 255, 255, 255))
            elevation = dp(10).toFloat()
        }
        val fitButton = glassIconButton(R.drawable.ic_player_fit) { nextMode() }
        fitIcon = fitButton.getChildAt(0) as ImageView
        val lockButton = glassIconButton(R.drawable.ic_player_lock) { toggleLock() }
        lockIcon = lockButton.getChildAt(0) as ImageView
        val standardBadge = TextView(this).apply {
            text = streamBadgeText()
            visibility = if (text.isBlank()) View.GONE else View.VISIBLE
            setTextColor(Color.rgb(210, 225, 255))
            textSize = 10.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(82, 139, 92, 246), dp(12), Color.argb(90, 255, 255, 255))
        }
        bottomActions.addView(standardBadge, LinearLayout.LayoutParams(dp(54), dp(30)).apply { marginEnd = dp(8) })
        bottomActions.addView(fitButton, LinearLayout.LayoutParams(dp(38), dp(38)))
        bottomActions.addView(lockButton, LinearLayout.LayoutParams(dp(38), dp(38)).apply { marginStart = dp(8) })
        bottomBar.addView(bottomActions, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8); gravity = Gravity.RIGHT })
        root.addView(bottomBar, FrameLayout.LayoutParams(-1, dp(110), Gravity.BOTTOM))

        unlockOverlay = glassIconButton(R.drawable.ic_player_unlock) { controlsLocked = false; showControls(); updateLockUi() }.apply { visibility = View.GONE }
        root.addView(unlockOverlay, FrameLayout.LayoutParams(dp(46), dp(46), Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = dp(16) })

        setContentView(root)
        applyPlayerFocusTree(root)
        root.postDelayed({ focusPlayButton() }, 300)

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) {
                val p = player ?: return
                if (p.length > 0) p.time = ((s?.progress ?: 0).toLong() * p.length) / 1000L
                hideBarsLater()
            }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {}
        })

        videoLayout.setOnTouchListener { _, e -> handleVideoTouch(e) }
        hideBarsLater()
    }

    private fun simplePlayerIcon(iconRes: Int, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(Color.argb(62, 255, 255, 255), dp(18), Color.argb(55, 255, 255, 255))
            applyPlayerFocus(this, 20, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_lock) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }, FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER))
        }
    }

    private fun simplePlayerIconWithText(iconRes: Int, label: String, click: () -> Unit): FrameLayout {
        return FrameLayout(this).apply {
            background = rounded(Color.argb(62, 255, 255, 255), dp(21), Color.argb(55, 255, 255, 255))
            applyPlayerFocus(this, 22, 1.10f, 0f)
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER).apply { rightMargin = dp(7) })
            addView(TextView(this@PlayerActivity).apply {
                text = label.replace("نرمال", "1x").replace(".0x", "x")
                setTextColor(Color.WHITE)
                textSize = 10.5f
                typeface = Typeface.DEFAULT_BOLD
            }, FrameLayout.LayoutParams(-2, -2, Gravity.RIGHT or Gravity.TOP).apply { rightMargin = dp(2); topMargin = dp(0) })
        }
    }

    private fun topActionButton(iconRes: Int, label: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), 0, dp(7), 0)
            background = rounded(Color.argb(150, 6, 14, 28), dp(18), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    click()
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(17), dp(17)).apply { marginEnd = dp(4) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 10.2f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun typeSwitchButton(iconRes: Int, label: String, subtitle: Boolean): LinearLayout {
        val active = tracks.getOrNull(currentIndex)?.let { isSubtitle(it) == subtitle } ?: false
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), 0, dp(8), 0)
            background = if (active) {
                android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.argb(230, 25, 115, 255), Color.argb(210, 92, 60, 255))).apply {
                    cornerRadius = dp(20).toFloat()
                    setStroke(dp(1), Color.argb(210, 190, 225, 255))
                }
            } else rounded(Color.argb(150, 6, 14, 28), dp(20), Color.argb(155, 55, 99, 170))
            setOnClickListener {
                if (!controlsLocked) {
                    quickTypeSwitch(subtitle)
                    hideBarsLater()
                }
            }
            addView(ImageView(this@PlayerActivity).apply {
                setImageResource(iconRes)
                setColorFilter(Color.WHITE)
            }, LinearLayout.LayoutParams(dp(18), dp(18)).apply { marginEnd = dp(5) })
            addView(TextView(this@PlayerActivity).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 11f
                gravity = Gravity.CENTER
                typeface = Typeface.DEFAULT_BOLD
                maxLines = 1
            })
        }
    }

    private fun glassIconButton(iconRes: Int, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = rounded(Color.argb(78, 255, 255, 255), dp(18), Color.argb(68, 255, 255, 255))
            elevation = dp(7).toFloat()
            applyPlayerFocus(this, 20, 1.08f, dp(7).toFloat())
            setOnClickListener {
                if (!controlsLocked || iconRes == R.drawable.ic_player_unlock) {
                    click()
                    hideBarsLater()
                }
            }
        }
        box.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        return box
    }

    private fun circleAction(iconRes: Int, smallLabel: String, click: () -> Unit): FrameLayout {
        val box = FrameLayout(this).apply {
            background = rounded(Color.argb(92, 0, 0, 0), dp(999), Color.argb(185, 255, 255, 255))
            applyPlayerFocus(this, 999, 1.13f, dp(6).toFloat())
            setOnClickListener { click(); hideBarsLater() }
        }
        val stack = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        stack.addView(ImageView(this).apply {
            setImageResource(iconRes)
            setColorFilter(Color.WHITE)
        }, LinearLayout.LayoutParams(dp(22), dp(22)))
        stack.addView(TextView(this).apply {
            text = smallLabel
            setTextColor(Color.WHITE)
            textSize = 10f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
        })
        box.addView(stack, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        return box
    }

    private fun startPlayer(url: String) {
        releasePlayer()
        resumeApplied = false
        val isDash = url.lowercase(Locale.US).contains(".mpd") || url.lowercase(Locale.US).contains("format=mpd") || url.lowercase(Locale.US).contains("dash")
        val isHls = url.lowercase(Locale.US).contains(".m3u8") || url.lowercase(Locale.US).contains("hls")
        val cacheMs = if (isDash || isHls) 4200 else 1600
        val libOptions = arrayListOf(
            "--network-caching=$cacheMs",
            "--file-caching=$cacheMs",
            "--live-caching=$cacheMs",
            "--http-reconnect",
            "--audio-time-stretch",
            "--subsdec-encoding=UTF-8",
            "--sub-text-scale=$subtitleScale",
            "--freetype-rel-fontsize=22",
            "--sub-margin=${subtitleMargins[subtitlePositionIndex]}",
            "--freetype-font=Arial",
            "--freetype-bold",
            "--freetype-color=${subtitleColorValues[subtitleColorIndex]}",
            "--freetype-outline-color=0",
            "--freetype-outline-thickness=3",
            "--freetype-background-opacity=0"
        )
        if (isDash || isHls) {
            libOptions.add("--adaptive-logic=highest")
            libOptions.add("--adaptive-use-access")
        }
        val lib = LibVLC(this, libOptions)
        vlc = lib
        val mp = MediaPlayer(lib)
        player = mp
        mp.attachViews(videoLayout, null, false, false)
        mp.setEventListener { event ->
            runOnUiThread {
                when (event.type) {
                    MediaPlayer.Event.Playing -> {
                        playIcon.setImageResource(R.drawable.ic_player_pause)
                        applyMode()
                        applySubtitleDelay()
                        if (!resumeApplied) {
                            resumeApplied = true
                            val prefs = getSharedPreferences("bm_smart_cinema", MODE_PRIVATE)
                            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
                            val saved = prefs.getLong(stableKey, prefs.getLong("progress_$videoUrl", 0L))
                            if (saved > 15000L) {
                                try { player?.time = saved } catch (_: Throwable) {}
                                showHud("ادامه از ${fmt(saved)}")
                            }
                        }
                        updateLabels()
                    }
                    MediaPlayer.Event.Paused -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.Stopped -> playIcon.setImageResource(R.drawable.ic_player_play)
                    MediaPlayer.Event.EndReached -> playNext()
                    MediaPlayer.Event.EncounteredError -> {
                        Toast.makeText(this, "خطا در پخش؛ در حال تلاش مجدد", Toast.LENGTH_SHORT).show()
                        handler.postDelayed({ try { startPlayer(videoUrl) } catch (_: Throwable) {} }, 900)
                    }
                }
            }
        }
        val media = Media(lib, Uri.parse(url))
        media.setHWDecoderEnabled(hardwareDecoder, false)
        media.addOption(":input-repeat=0")
        media.addOption(":http-reconnect=true")
        media.addOption(":network-caching=$cacheMs")
        media.addOption(":subsdec-encoding=UTF-8")
        media.addOption(":freetype-font=Arial")
        media.addOption(":freetype-bold")
        media.addOption(":freetype-color=${subtitleColorValues[subtitleColorIndex]}")
        media.addOption(":freetype-outline-color=0")
        media.addOption(":freetype-outline-thickness=3")
        media.addOption(":freetype-background-opacity=0")
        if (isDash || isHls) {
            media.addOption(":demux=adaptive")
            media.addOption(":adaptive-logic=highest")
            media.addOption(":adaptive-use-access=true")
        }
        mp.media = media
        media.release()
        mp.play()
        if (currentSpeed != 1.0f) {
            try { mp.setRate(currentSpeed) } catch (_: Throwable) {}
        }
        applySubtitleDelay()
        handler.removeCallbacks(progressRunnable)
        handler.post(progressRunnable)
    }

    private fun switchTo(index: Int) {
        if (index !in tracks.indices) return
        if (player != null && videoUrl.isNotBlank()) savePlaybackProgress(true)
        currentIndex = index
        title = tracks[index].title
        videoUrl = tracks[index].url
        progressKey = tracks[index].progressKey.ifBlank { "progress_$videoUrl" }
        updateLabels()
        refreshTopActions()
        startPlayer(videoUrl)
        showHud(currentLabel().ifBlank { "در حال پخش" })
    }

    private fun refreshTopActions() {
        // Simple VLC/MX-style top controls stay fixed.
    }


    private fun updateLabels() {
        titleText.text = title
        subText.text = currentLabel()
    }

    private fun currentLabel(): String = tracks.getOrNull(currentIndex)?.let { trackLabel(it) } ?: ""

    private fun streamStandard(url: String): String {
        val u = url.lowercase(Locale.US)
        return when {
            u.contains(".mpd") || u.contains("format=mpd") || u.contains("dash") -> "DASH"
            u.contains(".m3u8") || u.contains("hls") -> "HLS"
            else -> ""
        }
    }

    private fun streamBadgeText(): String {
        val s = streamStandard(videoUrl)
        return if (s.isBlank()) "" else s
    }

    private fun trackLabel(t: Track): String {
        val head = if (t.season > 0 || t.episode > 0) "فصل ${t.season} قسمت ${t.episode} • " else ""
        val typeFa = when {
            t.typeFa.isNotBlank() -> t.typeFa
            isSubtitle(t) -> "زیرنویس"
            isAudioOnly(t) -> "صوت دوبله"
            else -> "دوبله"
        }
        val base = t.displayLabel.ifBlank { (t.quality.ifBlank { "کیفیت نامشخص" }) + " • " + typeFa }
        val standard = streamStandard(t.url)
        return head + base + if (standard.isNotBlank()) " • $standard" else ""
    }

    private fun isSubtitle(t: Track): Boolean {
        val s = (t.type + " " + t.typeFa + " " + t.displayLabel + " " + t.label + " " + t.url).lowercase(Locale.US)
        return s.contains("sub") || s.contains("subtitle") || s.contains("زیر")
    }

    private fun isAudioOnly(t: Track): Boolean = t.isAudio || t.url.lowercase(Locale.US).endsWith(".mka") || t.url.lowercase(Locale.US).endsWith(".mp3")

    private fun showSourceSheet() {
        if (tracks.isEmpty()) return
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        scroll.addView(box)
        var dialog: AlertDialog? = null
        val isSeries = tracks.any { it.season > 0 || it.episode > 0 }
        if (isSeries) {
            tracks.groupBy { it.season }.toSortedMap().forEach { entry ->
                box.addView(sectionTitle(if (entry.key > 0) "فصل ${entry.key}" else "قسمت‌ها"))
                entry.value.groupBy { it.episode }.toSortedMap().forEach { ep ->
                    box.addView(TextView(this).apply {
                        text = if (ep.key > 0) "قسمت ${ep.key}" else "لینک‌ها"
                        setTextColor(muted)
                        textSize = 13f
                        setPadding(0, dp(8), 0, dp(4))
                    })
                    val first = ep.value.firstOrNull() ?: return@forEach
                    val idx = tracks.indexOf(first)
                    box.addView(sheetButton("${trackLabel(first)}${if (idx == currentIndex) "  ●" else ""}") {
                        dialog?.dismiss(); switchTo(idx)
                    }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
                }
            }
        } else {
            tracks.forEachIndexed { idx, t ->
                box.addView(sheetButton("${trackLabel(t)}${if (idx == currentIndex) "  ●" else ""}") {
                    dialog?.dismiss(); switchTo(idx)
                }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(4); bottomMargin = dp(4) })
            }
        }
        dialog = dialogOf(scroll)
        dialog.show()
    }

    private fun scopedTracks(): List<Track> {
        val current = tracks.getOrNull(currentIndex)
        return if (current != null && (current.season > 0 || current.episode > 0)) {
            tracks.filter { it.season == current.season && it.episode == current.episode }
        } else tracks.toList()
    }

    private fun showQualitySheet() {
        val scoped = scopedTracks().filter { !isAudioOnly(it) }
        if (scoped.isEmpty()) return
        val unique = linkedMapOf<String, Track>()
        scoped.forEach { if (it.quality.isNotBlank() && !unique.containsKey(it.quality)) unique[it.quality] = it }
        if (unique.isEmpty()) return Toast.makeText(this, "کیفیتی پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("انتخاب کیفیت"))
        var dialog: AlertDialog? = null
        unique.forEach { q, sample ->
            box.addView(sheetButton(q + if (sample.quality == tracks.getOrNull(currentIndex)?.quality) "  ●" else "") {
                dialog?.dismiss()
                val current = tracks.getOrNull(currentIndex)
                val target = scoped.firstOrNull { it.quality == q && it.type == current?.type } ?: scoped.firstOrNull { it.quality == q }
                val idx = tracks.indexOf(target)
                if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun quickTypeSwitch(subtitleOnly: Boolean) {
        val current = tracks.getOrNull(currentIndex)
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) {
            Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
            return
        }
        val preferred = scoped.firstOrNull { it.quality == current?.quality } ?: scoped.firstOrNull()
        val idx = tracks.indexOf(preferred)
        if (idx >= 0 && idx != currentIndex) {
            switchTo(idx)
        } else {
            showTypeSheet(subtitleOnly)
        }
    }

    private fun showTypeSheet(subtitleOnly: Boolean) {
        val scoped = scopedTracks().filter { if (subtitleOnly) isSubtitle(it) else (!isSubtitle(it) && !isAudioOnly(it)) }
        if (scoped.isEmpty()) return Toast.makeText(this, if (subtitleOnly) "نسخه زیرنویس پیدا نشد" else "نسخه دوبله پیدا نشد", Toast.LENGTH_SHORT).show()
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle(if (subtitleOnly) "زیرنویس" else "صدا / دوبله"))
        var dialog: AlertDialog? = null
        scoped.forEach { t ->
            val idx = tracks.indexOf(t)
            box.addView(sheetButton("${t.quality.ifBlank { "نامشخص" }}${if (idx == currentIndex) "  ●" else ""}") {
                dialog?.dismiss(); if (idx >= 0) switchTo(idx)
            }, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(5) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun showSettingsSheet() {
        val scroll = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(Color.argb(246, 27, 63, 104), dp(30), Color.argb(105, 210, 230, 255))
        }
        scroll.addView(box)

        box.addView(sectionTitle("تنظیمات پلیر"))
        box.addView(settingsMiniLabel("پخش"))
        box.addView(settingButton("سرعت پخش", speedLabel(), "کشیدنی از 0.5x تا 2x بدون توقف ویدیو") { showSpeedSheet() })
        box.addView(settingButton("ترک صدا", "دوبله / نسخه صوتی", "انتخاب نسخه دوبله یا صدای موجود") { quickTypeSwitch(false) })
        box.addView(settingButton("Auto Play Next", if (autoPlayNext) "روشن" else "خاموش", "بعد از پایان قسمت، قسمت بعدی پخش شود") {
            autoPlayNext = !autoPlayNext
            showHud("Auto Play Next: ${if (autoPlayNext) "روشن" else "خاموش"}")
        })

        box.addView(settingsMiniLabel("زیرنویس"))
        box.addView(settingButton("تنظیمات زیرنویس", subtitleStyleLabel(), "عقب/جلو، اندازه و جایگاه به صورت کشیدنی") { showSubtitleStyleSheet() })
        box.addView(settingButton("نسخه زیرنویس", "انتخاب نسخه", "فقط نسخه‌های زیرنویس از API") { quickTypeSwitch(true) })

        box.addView(settingsMiniLabel("سیستم"))
        box.addView(settingButton("دیکودر", if (hardwareDecoder) "Hardware" else "Software", "تعویض بین Hardware و Software") {
            hardwareDecoder = !hardwareDecoder
            restartKeepingTime("Decoder: ${if (hardwareDecoder) "Hardware" else "Software"}")
        })
        box.addView(settingButton("Picture in Picture", "فعال‌سازی", "برای اندروید 8 به بالا") { enterPipMode() })
        box.addView(settingButton("Sleep Timer", if (sleepMinutes > 0) "${sleepMinutes} دقیقه" else "خاموش", "خاموشی خودکار پلیر") { showSleepSheet() })
        box.addView(settingButton("Lock Controls", if (controlsLocked) "قفل" else "باز", "قفل کردن کنترل‌ها") { toggleLock() })

        val dialog = dialogOf(scroll)
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun settingsMiniLabel(label: String): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(Color.rgb(220, 220, 220))
            textSize = 11.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, dp(12), 0, dp(6))
        }
    }

    private fun settingButton(title: String, value: String, sub: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.argb(58, 255, 255, 255), dp(16), Color.argb(70, 255, 255, 255))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            applyPlayerFocus(this, 17, 1.025f, 0f)
            setOnClickListener { click() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) }

            val row = LinearLayout(this@PlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutDirection = View.LAYOUT_DIRECTION_RTL
            }
            row.addView(TextView(this@PlayerActivity).apply {
                text = title
                setTextColor(Color.WHITE)
                textSize = 14.2f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.RIGHT
            }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(TextView(this@PlayerActivity).apply {
                text = value
                setTextColor(Color.rgb(225, 236, 255))
                textSize = 12.2f
                gravity = Gravity.LEFT
                maxLines = 1
            }, LinearLayout.LayoutParams(-2, -2).apply { marginStart = dp(10) })
            addView(row)
            addView(TextView(this@PlayerActivity).apply {
                text = sub
                setTextColor(Color.rgb(198, 212, 232))
                textSize = 11.3f
                gravity = Gravity.RIGHT
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showSpeedSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = rounded(Color.argb(246, 27, 63, 104), dp(28), Color.argb(96, 190, 220, 255))
        }
        box.addView(sectionTitle("سرعت پخش"))
        val value = TextView(this).apply {
            text = speedLabel()
            setTextColor(Color.WHITE)
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(10))
        }
        box.addView(value)

        val speedSeek = SeekBar(this).apply {
            max = 150
            progress = ((currentSpeed - 0.5f) * 100f).roundToInt().coerceIn(0, 150)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(speedSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(8); bottomMargin = dp(8) })

        box.addView(TextView(this).apply {
            text = "از 0.5x تا 2.0x"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 12f
            gravity = Gravity.CENTER
        })

        speedSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val sp = ((50 + progress) / 100f).coerceIn(0.5f, 2.0f)
                currentSpeed = (sp * 100f).roundToInt() / 100f
                try { player?.setRate(currentSpeed) } catch (_: Throwable) {}
                value.text = speedLabel()
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSubtitleStyleSheet() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(22), dp(24), dp(18))
            background = rounded(Color.argb(248, 29, 63, 101), dp(30), Color.argb(105, 210, 230, 255))
        }

        box.addView(TextView(this).apply {
            text = "تنظیمات زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 24f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(14))
        })

        box.addView(TextView(this).apply {
            text = "زیرنویس‌های داخلی فیلم (Soft Sub):"
            setTextColor(Color.rgb(215, 225, 240))
            textSize = 13.5f
            gravity = Gravity.RIGHT
            setPadding(0, 0, 0, dp(8))
        })

        box.addView(TextView(this).apply {
            text = "◉  خاموش / بدون زیرنویس"
            setTextColor(Color.rgb(238, 242, 248))
            textSize = 14.2f
            gravity = Gravity.RIGHT
            setPadding(0, dp(6), 0, dp(12))
        })

        box.addView(View(this).apply { setBackgroundColor(Color.argb(82, 255, 255, 255)) }, LinearLayout.LayoutParams(-1, 1).apply { bottomMargin = dp(14) })

        box.addView(TextView(this).apply {
            text = "انتخاب زیرنویس از فایل گوشی"
            setTextColor(Color.WHITE)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(235, 35, 45), dp(24), Color.argb(70, 255, 180, 185))
            setOnClickListener { showHud("انتخاب فایل زیرنویس در نسخه بعدی فعال می‌شود") }
            applyPlayerFocus(this, 24, 1.025f, 0f)
        }, LinearLayout.LayoutParams(-1, dp(56)).apply { bottomMargin = dp(18) })

        box.addView(View(this).apply { setBackgroundColor(Color.argb(82, 255, 255, 255)) }, LinearLayout.LayoutParams(-1, 1).apply { bottomMargin = dp(16) })

        val delayValue = TextView(this).apply {
            text = "عقب / جلو زیرنویس: ${"%.1f".format(Locale.US, subtitleDelayMs / 1000f)}s"
            setTextColor(Color.WHITE)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }
        box.addView(delayValue)

        val delaySeek = SeekBar(this).apply {
            max = 200
            progress = ((subtitleDelayMs + 10000) / 100).coerceIn(0, 200)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(delaySeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(10) })

        val sizeValue = TextView(this).apply {
            text = "اندازه فونت: ${subtitleScale}%"
            setTextColor(Color.WHITE)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }
        box.addView(sizeValue)

        val sizeSeek = SeekBar(this).apply {
            max = 80
            progress = (subtitleScale - 80).coerceIn(0, 80)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(sizeSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(10) })

        val positionValue = TextView(this).apply {
            text = "جایگاه زیرنویس: ${subtitlePositions[subtitlePositionIndex]}"
            setTextColor(Color.WHITE)
            textSize = 14.5f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.RIGHT
        }
        box.addView(positionValue)

        val positionSeek = SeekBar(this).apply {
            max = subtitlePositions.size - 1
            progress = subtitlePositionIndex.coerceIn(0, subtitlePositions.size - 1)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(235, 35, 45))
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(255, 70, 80))
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.argb(95, 255, 255, 255))
            applyPlayerFocus(this, 18, 1.02f, 0f)
        }
        box.addView(positionSeek, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(5); bottomMargin = dp(12) })

        val colorRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            gravity = Gravity.CENTER
        }
        fun colorChip(label: String, index: Int, color: Int): TextView {
            return TextView(this).apply {
                text = label
                setTextColor(if (index == 6) Color.WHITE else Color.rgb(18, 24, 36))
                textSize = 12.5f
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                background = rounded(color, dp(18), if (subtitleColorIndex == index) Color.rgb(235, 35, 45) else Color.argb(65, 255, 255, 255))
                setOnClickListener {
                    subtitleColorIndex = index
                    showHud("رنگ زیرنویس: ${subtitleColorLabels[subtitleColorIndex]}")
                }
                applyPlayerFocus(this, 18, 1.035f, 0f)
            }
        }
        colorRow.addView(colorChip("سفید", 0, Color.WHITE), LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        colorRow.addView(colorChip("زرد", 1, Color.YELLOW), LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        colorRow.addView(colorChip("آبی", 2, Color.rgb(130, 185, 255)), LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(5) })
        colorRow.addView(colorChip("مشکی", 6, Color.rgb(25, 28, 36)), LinearLayout.LayoutParams(0, dp(38), 1f))
        box.addView(colorRow, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val close = TextView(this).apply {
            text = "بستن"
            setTextColor(Color.WHITE)
            textSize = 14.2f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(Color.argb(65, 255, 255, 255), dp(20), Color.argb(80, 255, 255, 255))
            applyPlayerFocus(this, 20, 1.025f, 0f)
        }
        box.addView(close, LinearLayout.LayoutParams(-1, dp(46)))

        delaySeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                subtitleDelayMs = (progress * 100) - 10000
                delayValue.text = "عقب / جلو زیرنویس: ${"%.1f".format(Locale.US, subtitleDelayMs / 1000f)}s"
                applySubtitleDelay()
                showHud(delayValue.text.toString())
            }
        })
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                subtitleScale = (80 + progress).coerceIn(80, 160)
                sizeValue.text = "اندازه فونت: ${subtitleScale}%"
                showHud("اندازه زیرنویس: ${subtitleScale}%")
            }
        })
        positionSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onStartTrackingTouch(s: SeekBar?) { handler.removeCallbacks(hideRunnable) }
            override fun onStopTrackingTouch(s: SeekBar?) { hideBarsLater() }
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                subtitlePositionIndex = progress.coerceIn(0, subtitlePositions.size - 1)
                positionValue.text = "جایگاه زیرنویس: ${subtitlePositions[subtitlePositionIndex]}"
                showHud(positionValue.text.toString())
            }
        })

        val dialog = dialogOf(ScrollView(this).apply { addView(box) })
        close.setOnClickListener { dialog.dismiss() }
        dialog.show()
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
    }

    private fun showSleepSheet() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(14), dp(14), dp(14)) }
        box.addView(sectionTitle("Sleep Timer"))
        var dialog: AlertDialog? = null
        listOf(0 to "خاموش", 15 to "15 دقیقه", 30 to "30 دقیقه", 45 to "45 دقیقه", 60 to "60 دقیقه").forEach { item ->
            box.addView(sheetButton(item.second + if (sleepMinutes == item.first) "  ●" else "") {
                setSleepTimer(item.first)
                dialog?.dismiss()
            }, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(4); bottomMargin = dp(4) })
        }
        dialog = dialogOf(ScrollView(this).apply { addView(box) })
        dialog.show()
    }

    private fun speedLabel(): String = if (currentSpeed == 1.0f) "نرمال" else "${currentSpeed}x"

    private fun subtitleStyleLabel(): String = "${subtitleColorLabels[subtitleColorIndex]} • ${subtitleScale}% • ${subtitlePositions[subtitlePositionIndex]}"

    private fun applySubtitleDelay() {
        try { player?.javaClass?.getMethod("setSpuDelay", java.lang.Long.TYPE)?.invoke(player, subtitleDelayMs * 1000L) } catch (_: Throwable) {}
    }

    private fun restartKeepingTime(message: String) {
        val pos = player?.time ?: 0L
        startPlayer(videoUrl)
        handler.postDelayed({
            try { player?.time = pos } catch (_: Throwable) {}
            showHud(message)
        }, 650)
    }

    private fun setTemporarySpeed(active: Boolean) {
        try { player?.setRate(if (active) 2.0f else currentSpeed) } catch (_: Throwable) {}
        showHud(if (active) "2X" else "سرعت پخش: ${speedLabel()}")
    }

    private fun enterPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                enterPictureInPictureMode(PictureInPictureParams.Builder().build())
            } catch (_: Throwable) {
                Toast.makeText(this, "Picture in Picture روی این دستگاه فعال نشد", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(this, "Picture in Picture برای اندروید 8 به بالا است", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setSleepTimer(minutes: Int) {
        sleepMinutes = minutes
        handler.removeCallbacks(sleepRunnable)
        if (minutes > 0) handler.postDelayed(sleepRunnable, minutes * 60_000L)
        showHud(if (minutes > 0) "خواب: ${minutes} دقیقه" else "حالت خواب خاموش شد")
    }

    private fun sectionTitle(label: String): TextView = TextView(this).apply {
        text = label
        setTextColor(white)
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun dialogOf(view: View): AlertDialog {
        return AlertDialog.Builder(this).setView(view).create().also {
            it.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            view.postDelayed({ applyPlayerFocusTree(view) }, 180)
        }
    }

    private fun sheetButton(label: String, click: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(white)
            textSize = 14f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.argb(210, 8, 18, 36), dp(16), Color.argb(180, 55, 104, 188))
            applyPlayerFocus(this, 18, 1.035f, 0f)
            setOnClickListener { click() }
        }
    }

    private fun toggle() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else p.play()
        playIcon.setImageResource(if (p.isPlaying) R.drawable.ic_player_pause else R.drawable.ic_player_play)
        hideBarsLater()
    }

    private fun seekBy(delta: Long) {
        val p = player ?: return
        val len = p.length
        p.time = if (len > 0) min(max(p.time + delta, 0L), len) else max(p.time + delta, 0L)
        updateProgress()
        hideBarsLater()
    }

    private fun playNext() {
        if (!autoPlayNext) {
            showHud("پخش خودکار قسمت بعد خاموش است")
            playIcon.setImageResource(R.drawable.ic_player_play)
            return
        }
        if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
    }

    private fun nextMode() {
        modeIndex = (modeIndex + 1) % modes.size
        applyMode()
        showHud("حالت تصویر: ${modeTitles[modeIndex]}")
        hideBarsLater()
    }

    private fun applyMode() {
        val mp = player ?: return
        when (modes[modeIndex]) {
            "FIT" -> { setAspect(mp, null); setScale(mp, 0f) }
            "CROP" -> { setAspect(mp, null); setScale(mp, 1.2f) }
            "STRETCH" -> {
                videoLayout.post {
                    val w = max(root.width, resources.displayMetrics.widthPixels)
                    val h = max(root.height, resources.displayMetrics.heightPixels)
                    setAspect(mp, "$w:$h")
                    setScale(mp, 0f)
                }
            }
        }
    }

    private fun toggleLock() {
        controlsLocked = !controlsLocked
        updateLockUi()
        if (controlsLocked) {
            topBar.visibility = View.GONE
            bottomBar.visibility = View.GONE
            centerControls.visibility = View.GONE
            unlockOverlay.visibility = View.VISIBLE
            controlsVisible = false
            showHud("قفل شد")
        } else {
            unlockOverlay.visibility = View.GONE
            showControls()
            showHud("قفل باز شد")
            focusPlayButton()
        }
    }

    private fun updateLockUi() {
        lockIcon.setImageResource(if (controlsLocked) R.drawable.ic_player_unlock else R.drawable.ic_player_lock)
    }

    private fun showControls() {
        if (controlsLocked) return
        controlsVisible = true
        topBar.visibility = View.VISIBLE
        bottomBar.visibility = View.VISIBLE
        centerControls.visibility = View.VISIBLE
        hideBarsLater()
    }

    private fun hideControls() {
        if (controlsLocked) return
        controlsVisible = false
        topBar.visibility = View.GONE
        bottomBar.visibility = View.GONE
        centerControls.visibility = View.GONE
    }

    private fun hideBarsLater() {
        handler.removeCallbacks(hideRunnable)
        if (!controlsLocked) handler.postDelayed(hideRunnable, 3500)
    }

    private fun showHud(msg: String) {
        hudBox.text = msg
        hudBox.visibility = View.VISIBLE
        handler.removeCallbacks(hudHideRunnable)
        handler.postDelayed(hudHideRunnable, 1100)
    }

    private fun handleVideoTouch(e: MotionEvent): Boolean {
        if (controlsLocked && e.action != MotionEvent.ACTION_UP) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = e.x
                touchStartY = e.y
                touchStartBrightness = currentBrightness
                touchStartVolume = audioManager.getStreamVolume(android.media.AudioManager.STREAM_MUSIC)
                gestureMode = 0
                longPress2x = false
                handler.removeCallbacks(longPressRunnable)
                handler.postDelayed(longPressRunnable, 480)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - touchStartX
                val dy = e.y - touchStartY
                if (gestureMode == 0 && abs(dy) > abs(dx) && abs(dy) > dp(18)) {
                    handler.removeCallbacks(longPressRunnable)
                    gestureMode = if (touchStartX < root.width / 2f) 1 else 2
                }
                if (gestureMode == 1) {
                    val delta = (touchStartY - e.y) / root.height
                    currentBrightness = (touchStartBrightness + delta * 1.6f).coerceIn(0.05f, 1f)
                    val lp = window.attributes
                    lp.screenBrightness = currentBrightness
                    window.attributes = lp
                    showHud("روشنایی ${ (currentBrightness * 100).roundToInt() }٪")
                    return true
                } else if (gestureMode == 2) {
                    val maxVol = audioManager.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC)
                    val delta = ((touchStartY - e.y) / root.height * maxVol).roundToInt()
                    val vol = (touchStartVolume + delta).coerceIn(0, maxVol)
                    audioManager.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, vol, 0)
                    val percent = (vol * 100f / maxVol).roundToInt()
                    showHud("صدا ${percent}٪")
                    return true
                }
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                    hideBarsLater()
                    return true
                }
                if (controlsLocked) {
                    unlockOverlay.visibility = View.VISIBLE
                    return true
                }
                if (gestureMode != 0) {
                    hideBarsLater()
                    return true
                }
                val now = System.currentTimeMillis()
                if (now - lastTap < 280) {
                    if (e.x < root.width / 2f) seekBy(-10000) else seekBy(10000)
                    lastTap = 0L
                } else {
                    lastTap = now
                    handler.postDelayed({
                        if (System.currentTimeMillis() - lastTap >= 260) {
                            if (controlsVisible) hideControls() else showControls()
                        }
                    }, 270)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                handler.removeCallbacks(longPressRunnable)
                if (longPress2x) {
                    longPress2x = false
                    setTemporarySpeed(false)
                }
            }
        }
        return true
    }

    private fun savePlaybackProgress(force: Boolean = false) {
        val p = player ?: return
        if (videoUrl.isBlank()) return
        val now = System.currentTimeMillis()
        if (!force && now - lastProgressSaveAt < 8000L) return
        lastProgressSaveAt = now
        try {
            val savedTime = p.time.coerceAtLeast(0L)
            val stableKey = progressKey.ifBlank { "progress_$videoUrl" }
            getSharedPreferences("bm_smart_cinema", MODE_PRIVATE).edit()
                .putLong(stableKey, savedTime)
                .putLong("progress_$videoUrl", savedTime)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun updateProgress() {
        val p = player ?: return
        val len = p.length
        val time = p.time
        if (len > 0) seek.progress = ((time * 1000L) / len).toInt().coerceIn(0, 1000)
        currentTimeText.text = fmt(time)
        totalTimeText.text = if (len > 0) fmt(len) else "--:--"
        savePlaybackProgress(false)
    }

    private fun fmt(ms: Long): String {
        if (ms <= 0) return "00:00"
        val total = ms / 1000L
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s) else String.format(Locale.US, "%02d:%02d", m, s)
    }

    private fun setAspect(mp: MediaPlayer, ratio: String?) {
        try { mp.javaClass.getMethod("setAspectRatio", String::class.java).invoke(mp, ratio) } catch (_: Throwable) {}
    }

    private fun setScale(mp: MediaPlayer, scale: Float) {
        try { mp.javaClass.getMethod("setScale", java.lang.Float.TYPE).invoke(mp, scale) } catch (_: Throwable) {}
    }

    private fun rounded(color: Int, radius: Int, strokeColor: Int): android.graphics.drawable.GradientDrawable {
        return android.graphics.drawable.GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            if (strokeColor != Color.TRANSPARENT) setStroke(dp(1), strokeColor)
        }
    }

    private fun enterImmersive() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
    }

    override fun dispatchKeyEvent(event: android.view.KeyEvent): Boolean {
        if (event.action != android.view.KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        val key = event.keyCode

        fun focusLooksLikePlayerChrome(): Boolean {
            val f = currentFocus ?: return false
            return f != root && f != videoLayout
        }

        when (key) {
            android.view.KeyEvent.KEYCODE_BACK -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }
                if (controlsVisible) {
                    hideControls()
                    return true
                }
                finish()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_SPACE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY,
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                if (controlsLocked) {
                    controlsLocked = false
                    unlockOverlay.visibility = View.GONE
                    showControls()
                    updateLockUi()
                    showHud("قفل باز شد")
                    focusPlayButton()
                    return true
                }

                if (!controlsVisible) {
                    showControls()
                    focusPlayButton()
                    return true
                }

                val f = currentFocus
                if (f != null && f != root && f != videoLayout && f != seek) {
                    return super.dispatchKeyEvent(event)
                }

                toggle()
                showControls()
                focusPlayButton()
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_LEFT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(-300000)
                    showHud("۵ دقیقه عقب")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(-10000)
                    showHud("۱۰ ثانیه عقب")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> {
                if (controlsLocked) return true
                showControls()
                if (currentFocus == seek) {
                    seekBy(300000)
                    showHud("۵ دقیقه جلو")
                    seek.requestFocus()
                    return true
                }
                if (!controlsVisible || !focusLooksLikePlayerChrome()) {
                    seekBy(10000)
                    showHud("۱۰ ثانیه جلو")
                    focusPlayButton()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MEDIA_REWIND -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(-30000)
                    showHud("۳۰ ثانیه عقب")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                if (!controlsLocked) {
                    showControls()
                    seekBy(30000)
                    showHud("۳۰ ثانیه جلو")
                    if (currentFocus == seek) seek.requestFocus()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) focusPlayButton()
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (controlsLocked) return true
                showControls()
                if (!focusLooksLikePlayerChrome()) {
                    seek.requestFocus()
                    hideBarsLater()
                    return true
                }
                hideBarsLater()
                return super.dispatchKeyEvent(event)
            }

            android.view.KeyEvent.KEYCODE_MENU,
            android.view.KeyEvent.KEYCODE_SETTINGS -> {
                if (!controlsLocked) {
                    showControls()
                    showSettingsSheet()
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_CAPTIONS,
            android.view.KeyEvent.KEYCODE_C -> {
                if (!controlsLocked) {
                    showControls()
                    quickTypeSwitch(true)
                }
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> {
                if (currentIndex + 1 < tracks.size) switchTo(currentIndex + 1)
                return true
            }

            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                if (currentIndex - 1 >= 0) switchTo(currentIndex - 1)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    override fun onResume() {
        super.onResume()
        enterImmersive()
    }

    private fun releasePlayer() {
        try {
            player?.stop()
            player?.detachViews()
            player?.release()
            vlc?.release()
        } catch (_: Throwable) {}
        player = null
        vlc = null
    }

    override fun onPause() {
        savePlaybackProgress(true)
        super.onPause()
    }

    override fun onDestroy() {
        savePlaybackProgress(true)
        handler.removeCallbacksAndMessages(null)
        releasePlayer()
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
