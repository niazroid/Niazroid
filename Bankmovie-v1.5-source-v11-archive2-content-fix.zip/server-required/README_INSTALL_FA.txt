بسته سرور آرشیو ۱ و آرشیو ۲ بانک مووی — V11
===========================================

این چهار فایل را کنار app_api.php و app_config.php در ریشه سایت قرار دهید:
- archive1_live.php
- archive1_live_lib.php
- api5.php
- api5_lib.php

تغییرات V11 آرشیو ۲:
- ترکیب فیلم‌های اکران 2025 و 2026 در یک خروجی
- فیلتر دقیق فیلم و سریال تا سریال داخل بخش فیلم نیاید
- پاک‌سازی عنوان کارت‌ها و حذف عبارت‌های تبلیغاتی
- حذف فصل و قسمت اشتباه از لینک‌های فیلم سینمایی
- حفظ فصل و قسمت واقعی برای سریال‌ها

تست‌ها:
- https://YOUR-DOMAIN/archive1_live.php?ping=1
- https://YOUR-DOMAIN/archive1_live.php?section=dubbed&page=1
- https://YOUR-DOMAIN/archive1_live.php?section=chinese_series&page=1
- https://YOUR-DOMAIN/api5.php?ping=1
- https://YOUR-DOMAIN/api5.php?section=movies_2025_2026&page=1
- https://YOUR-DOMAIN/api5.php?section=new_series&page=1

اپ به‌صورت پیش‌فرض همین مسیرها را از دامنه فعال سایت می‌خواند و نیازی به تغییر دستی نیست.
برای مسیر سفارشی می‌توانید این کلیدها را به bankmovie_remote_config.json اضافه کنید:

"archive1_live_api_url": "https://YOUR-DOMAIN/archive1_live.php",
"archive2_api_url": "https://YOUR-DOMAIN/api5.php",
"archive1_source_url": "https://www.oldtowns.top"

نیازمندی PHP:
- curl
- dom
- mbstring
