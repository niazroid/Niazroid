// Generated at build time from private environment/GitHub Actions secrets.
// Do not commit production values here.
module.exports = Object.freeze({
  domain: process.env.BM_DESKTOP_DOMAIN || '',
  appKey: process.env.BM_DESKTOP_APP_KEY || '',
  appSecret: process.env.BM_DESKTOP_APP_SECRET || ''
});
