#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
MAIN=app/src/main/java/ir/bankmoviee/app/MainActivity.kt
ICON=app/src/main/res/drawable/ic_nav_discover.xml
test -s "$ICON"
python3 - <<'PYMAIN'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
a=s.index('    private fun showDiscover() {')
b=s.index('    private fun showCategories()',a)
n=s[a:b]
for marker in ('/api_discover.php?', 'openFilm(item)', 'showDetail(nativeItem(item))', '"featured_collections"', '"explorer"', '"mixer"', '"catalog"'):
    assert marker in n, f'missing native discover check: {marker}'
assert 'WebView(this)' not in n and '.loadUrl(' not in n, 'webview still active in native discover'
assert 'showNotificationCenter()' in s
assert 'discoverActorSearchCard(person)' in s
assert 'ic_nav_discover' in s
print('VERIFY_V24_NATIVE_DISCOVER_OK')
PYMAIN
