#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$MAIN" && -f "$WF" ]] || { echo VERIFY_V7471_11_FILES_MISSING; exit 1; }

grep -Fq 'V7.47.1.11 TV DRAWER FOCUS HANDOFF' "$MAIN"
grep -Fq 'private fun resolveTvContentEntryTarget(): View?' "$MAIN"
grep -Fq 'private fun closeTvSideNavToContent(): Boolean' "$MAIN"
grep -Fq 'android.view.KeyEvent.KEYCODE_DPAD_LEFT -> return closeTvSideNavToContent()' "$MAIN"
grep -Fq 'target.requestFocus()' "$MAIN"
grep -Fq 'content.post { verify(0) }' "$MAIN"
python3 - <<'PY2'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
start=s.index('private fun closeTvSideNavToContent(): Boolean')
end=s.index('private fun requestTvContentEntryFocus()', start)
block=s[start:end]
assert block.index('target.requestFocus()') < block.index('setTvSideNavExpanded(false)'), 'drawer collapses before content focus request'
h=s.index('private fun handleTvDirectionalFocus(keyCode: Int): Boolean')
hend=s.index('private fun wireTvFocusGraph', h)
hb=s[h:hend]
assert hb.index('if (tvSideNavExpanded)') < hb.index('handleV74715BoxOfficeBootstrap'), 'screen bootstrap still precedes drawer owner'
assert 'android.view.KeyEvent.KEYCODE_DPAD_RIGHT -> return true' in hb
assert hb.count('closeTvSideNavToContent()') >= 2
print('V7471_11_DRAWER_HANDOFF_ORDER_OK')
PY2
bash verify_v7471_10_tv_drawer_profile_mobile_match.sh
grep -Fq 'SOURCE_ZIP: BankMovie_Android_FULLSOURCE_V2.4_NATIVE_DISCOVER_FIX.zip' "$WF"
grep -Fq 'verify_v7471_11_tv_drawer_focus_handoff.sh' "$WF"
echo VERIFY_V7471_11_TV_DRAWER_FOCUS_HANDOFF_OK
