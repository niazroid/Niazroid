# BankMovie 2.4 — رفع خطای CI با نام ZIP قدیمی

## علت
تست‌های قدیمی `verify_v7471_*` به‌جای بررسی سورس فعلی به نام ZIPهای نسخه 2.3 وابسته بودند. پس از تغییر نام پروژه به 2.4، بررسی `verify_v7471_4_slider_nav_remote_ux.sh` با `VERIFY_V7471_4_FULLSOURCE_MISSING` متوقف می‌شد.

## اصلاح
تست‌های مبتنی بر نام فایل اصلاح شدند تا `SOURCE_ZIP` بسته مشخص و جدید 2.4 را در Workflow شناسایی کنند. بررسی‌های واقعی اجزای اپ (ناوبری، جستجو، تلویزیون، پروفایل، پخش و ...) حفظ شده‌اند.

## نصب روی GitHub
1. ZIP جدید `BankMovie_Android_FULLSOURCE_V2.4_DISCOVER_ALL6_CI_HOTFIX.zip` را در **ریشه ریپازیتوری** آپلود کنید.
2. فایل `build-bankmovie-v2.4-CI-HOTFIX.yml` را در مسیر `.github/workflows/build-bankmovie.yml` قرار دهید (نام مقصد **دقیقاً** `build-bankmovie.yml` باشد).
3. تغییرات را commit کنید و از Actions، Workflow را اجرا کنید.
4. Workflow اول فایل ZIP جدید را بررسی و باز می‌کند؛ سپس ۸ نسخه APK را می‌سازد.

## نتیجه تست محلی
- `verify_v7471_4_slider_nav_remote_ux.sh`: پاس شد.
- `verify_v7471_5_player_tv_focus_unified_ui.sh`: پاس شد.
- تست‌های 9، 10، 11، 12 و 12.2 با بررسی اسم بسته جدید: پاس شد.
- تست نحوی YAML و Bash: پاس شد.
- ساخت کامل Android APK اینجا اجرا نشده؛ اگر Gradle در GitHub خطا بدهد، لاگ مرحله Build را ارسال کنید.

**توجه:** این Hotfix نسخه اندروید را همچنان `2.4` نگه می‌دارد، شناسه بسته و روش امضای APK را عوض نمی‌کند، هیچ فایل سرور را نصب نمی‌کند و نسخه‌های قدیمی اپ روی گوشی کاربران را تغییر نمی‌دهد.
