# BankMovie 2.5 — Profile / Home / Search navigation redesign

This release builds upon TV DPAD Unlock V2.5 without changing package id, keystore / signing, Media3 engine, archive images, app versionName or eight separate APK artifacts.

## Mobile
- Continue Watching has moved from Profile to Home, immediately after the archive chooser / optional ad and before the catalogue rows. Reuses existing stored progress data and playback links; only renders when there are existing items.
- Search initially shows at most the latest 20 **opened titles** from the same local `history` data. This is a list of visited movie/series details, **not** a log of typed search terms. The section disappears when typing a search query and returns when the query is cleared.
- Its `مشاهده بیشتر` button uses the existing `InlineSpinnerButton` arc. It opens the same complete local history view (max 100 entries). Once a new title is opened the oldest history record is discarded upon reaching 100. Older malformed history arrays are pruned from the end to 100 when read.
- Back navigation restores the existing Search UI and updates only its recent-visit strip rather than resetting the catalogue and its scroll position.
- Profile now contains login/avatar, real saved/downloaded/viewed counts, essential action grid, one wide VIP card **below** the action grid, help/about/cleanup (when enabled), Telegram and account actions (if logged in). Duplicate mobile profile history and Continue Watching rails removed.
- VIP card reads `vip_remaining_days`, `vip_lifetime`, `vip_expires_at` and account role from existing AccountSession; it never displays a made-up plan duration. Unavailable duration shows a generic active VIP status.

## Android TV
- Previous TV profile/TV Home/TV Search layouts and DPAD focus order remain **unchanged** in this release, following the first-poster focus lock regression. The new navigation placement is intentionally mobile-only until verified with physical TV DPAD testing. This prevents reintroducing TV focus lock.

## CI
- Same signed application id `ir.bankmoviee.app` and eight APK build artifacts, with the original APK signing guard intact. VersionName remains 2.5; versionCode is generated monotonically by the existing workflow.
- Build not executed locally: Android SDK/Gradle Android environment unavailable. Only source static checks are local. Real device testing is required before publishing.
