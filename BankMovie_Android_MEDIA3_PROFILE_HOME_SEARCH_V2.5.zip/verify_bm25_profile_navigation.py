#!/usr/bin/env python3
"""BankMovie V2.5 profile/search/home semantic source guards; not an APK test."""
from pathlib import Path
s = (Path(__file__).parent / "app/src/main/java/ir/bankmoviee/app/MainActivity.kt").read_text()
checks = {
    "mobile home Continue Watching section": 'private fun addMobileHomeContinueWatching(target: LinearLayout)' in s and 'addMobileHomeContinueWatching(homeBody)' in s,
    "mobile Search last-20-opened preview": 'private fun mobileSearchRecentlyOpened(): View?' in s and 'storeItems("history").take(20)' in s,
    "search preview host and refresh": 'bm25_search_recent_host' in s and 'refreshMobileSearchRecent()' in s,
    "no search-history copy": 'showLocalList(t("صد بازدید آخر", "Last 100 visits"), "history"' in s,
    "last-100 cap on write": 'upsertStoreItem("history", item, 100)' in s,
    "legacy history tail limit": 'minOf(arr.length(), 100)' in s,
    "TV focus migration gated": 'if (isTvLike()) {\n            addProfileContinueSection(page)' in s,
    "real profile counts": 'storeItems("history").size' in s and 'storeItems("favorites").size' in s and 'InternalDownloadStore.all(this).size' in s,
    "mobile VIP status card": 'page.addView(subscription, LinearLayout.LayoutParams(-1, -2)' in s and 'vip -> accountVipStatusText(user, compact = false)' in s,
    "profile contains security settings": 'showAccountSecurityDialog(false)' in s and 'showAccountSecurityDialog(true)' in s,
    "same spinner for View all": 'sectionHeader(title, more = {' in s and 'showLocalList(t("صد بازدید آخر"' in s,
}
for label, ok in checks.items():
    if not ok: raise SystemExit("FAIL_BM25_PROFILE_NAVIGATION " + label)
    print('PASS_BM25_PROFILE_NAVIGATION',label)
print('BM25_PROFILE_NAVIGATION_SOURCE_OK (not a compile or device test)')
