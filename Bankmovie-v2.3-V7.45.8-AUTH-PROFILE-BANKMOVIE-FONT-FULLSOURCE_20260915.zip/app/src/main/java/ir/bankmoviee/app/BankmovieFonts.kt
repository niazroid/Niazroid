package ir.bankmoviee.app

import android.content.Context
import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

object BankmovieFonts {
    data class FontOption(val key: String, val faLabel: String, val enLabel: String)

    private val cache = linkedMapOf<String, Typeface>()

    /**
     * V7.45.8: the website's Filimo variable face becomes the BankMovie house
     * font. The build workflow converts the site's WOFF2 into the Android asset
     * `bankmovie_filimo.ttf`; the font binary is intentionally not committed to
     * source. Other legacy choices stay available in Settings/Quick Setup.
     */
    val options = listOf(
        FontOption("bankmovie", "بانک مووی", "BankMovie"),
        FontOption("font", "ایرانسل", "Irancell"),
        FontOption("iransans", "ایران‌سنس X", "IRANSansX"),
        FontOption("diako", "دیاکو هیما", "Diako Hima"),
        FontOption("nic", "نیک", "Nic"),
        FontOption("cinema", "سینما", "Cinema"),
        FontOption("system", "سیستمی", "System")
    )

    @Synchronized
    private fun asset(context: Context, fileName: String, fallback: () -> Typeface): Typeface {
        cache[fileName]?.let { return it }
        val loaded = runCatching {
            val downloaded = java.io.File(context.filesDir, "fonts/$fileName")
            if (downloaded.isFile && downloaded.length() > 1024L) {
                Typeface.createFromFile(downloaded)
            } else {
                Typeface.createFromAsset(context.assets, "fonts/$fileName")
            }
        }.getOrElse { fallback() }
        cache[fileName] = loaded
        return loaded
    }

    private fun bankmovieBase(context: Context): Typeface = asset(context, "bankmovie_filimo.ttf") {
        Typeface.create("sans-serif", Typeface.NORMAL)
    }

    private fun irancellRegular(context: Context): Typeface = asset(context, "irancell_regular.ttf") {
        bankmovieBase(context)
    }

    private fun irancellMedium(context: Context): Typeface = asset(context, "irancell_medium.ttf") {
        irancellRegular(context)
    }

    private fun irancellSemiBold(context: Context): Typeface = asset(context, "irancell_semibold.ttf") {
        Typeface.create(irancellRegular(context), Typeface.BOLD)
    }

    private fun irancellBold(context: Context): Typeface = asset(context, "irancell_bold.ttf") {
        irancellSemiBold(context)
    }

    private fun irancellBlack(context: Context): Typeface = asset(context, "irancell_black.ttf") {
        irancellBold(context)
    }

    // Core UI helpers now use the BankMovie house font. `forMode("font")`
    // explicitly selects Irancell, so the legacy choice remains functional.
    fun regular(context: Context): Typeface = bankmovieBase(context)
    fun medium(context: Context): Typeface = bankmovieBase(context)
    fun semiBold(context: Context): Typeface = Typeface.create(bankmovieBase(context), Typeface.BOLD)
    fun bold(context: Context): Typeface = Typeface.create(bankmovieBase(context), Typeface.BOLD)
    fun black(context: Context): Typeface = Typeface.create(bankmovieBase(context), Typeface.BOLD)

    fun iranSansRegular(context: Context): Typeface = asset(context, "iransansx_regular.ttf") { regular(context) }
    fun iranSansMedium(context: Context): Typeface = asset(context, "iransansx_medium.ttf") { iranSansRegular(context) }
    fun iranSansBold(context: Context): Typeface = asset(context, "iransansx_bold.ttf") {
        Typeface.create(iranSansMedium(context), Typeface.BOLD)
    }

    fun diako(context: Context): Typeface = asset(context, "diako_hima.ttf") { regular(context) }
    fun nic(context: Context): Typeface = asset(context, "nic.ttf") { regular(context) }
    fun cinema(context: Context): Typeface = asset(context, "cinema.otf") { regular(context) }

    fun forMode(context: Context, mode: String, bold: Boolean = false): Typeface {
        return when (mode) {
            "bankmovie" -> if (bold) this.bold(context) else regular(context)
            "font" -> if (bold) irancellBold(context) else irancellRegular(context)
            "iransans" -> if (bold) iranSansBold(context) else iranSansRegular(context)
            "diako" -> Typeface.create(diako(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            "nic" -> Typeface.create(nic(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            "cinema" -> Typeface.create(cinema(context), if (bold) Typeface.BOLD else Typeface.NORMAL)
            else -> Typeface.create(Typeface.DEFAULT, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
    }

    fun label(mode: String, english: Boolean = false): String {
        val option = options.firstOrNull { it.key == mode } ?: options.first()
        return if (english) option.enLabel else option.faLabel
    }

    fun assetFileName(mode: String): String? = when (mode) {
        "bankmovie" -> "bankmovie_filimo.ttf"
        "font" -> "irancell_regular.ttf"
        "iransans" -> "iransansx_regular.ttf"
        "diako" -> "diako_hima.ttf"
        "nic" -> "nic.ttf"
        "cinema" -> "cinema.otf"
        else -> null
    }

    fun applyToTree(context: Context, view: View) {
        val mode = UiPreferences.appFontMode(context)
        fun walk(node: View) {
            if (node is TextView) {
                val oldStyle = node.typeface?.style ?: Typeface.NORMAL
                node.typeface = forMode(context, mode, oldStyle and Typeface.BOLD != 0)
            }
            if (node is ViewGroup) {
                for (i in 0 until node.childCount) walk(node.getChildAt(i))
            }
        }
        walk(view)
    }
}
