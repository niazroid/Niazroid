Font binaries are injected at GitHub Actions build time and are not committed inside this source archive.

V7.45.8 default app font:
- BankMovie = the exact Filimo Demo Variable face already used by the website.
- Workflow first looks for repository-root `filimo-demo-variable-vf.woff2`.
- If it is not present, Workflow downloads the same website asset from:
  https://bankmovie.top/assets/fonts/filimo-demo-variable-vf.woff2
- It is converted to Android TTF as `bankmovie_filimo.ttf` before Gradle runs.

Other repository-root font files kept from previous releases:
- irancell [@fontbazi].zip
- Cinema.otf
- Diako Hima Regular-@Fontsplua.ttf
- Nic [@fontbazi].ttf
- IRANSansXFaNum-regular*.woff2
- IRANSansXFaNum-medium*.woff2
- IRANSansXFaNum-bold*.woff2

Generated Android asset names:
- bankmovie_filimo.ttf
- irancell_regular.ttf
- irancell_medium.ttf
- irancell_semibold.ttf
- irancell_bold.ttf
- irancell_black.ttf
- cinema.otf
- diako_hima.ttf
- nic.ttf
- iransansx_regular.ttf
- iransansx_medium.ttf
- iransansx_bold.ttf

The workflow fails before Gradle if any required font asset is missing, so the app can no longer silently fall back to the system font because a font injection step was skipped.
