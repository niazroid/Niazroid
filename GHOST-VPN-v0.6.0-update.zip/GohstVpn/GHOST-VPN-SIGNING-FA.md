# امضای ثابت نسخه‌های GHOST VPN

این پروژه هیچ کلید خصوصی را داخل سورس یا ZIP قرار نمی‌دهد. **کلید امضا را فقط یک بار، روی دستگاه خودتان بسازید** و از فایل JKS و رمزهای آن نسخه پشتیبان امن نگه دارید.

## ساخت Keystore جدید (فقط یک‌بار)

```bash
keytool -genkeypair -v -keystore ghost-release.jks -alias ghost -keyalg RSA -keysize 3072 -validity 10000
```

رمزهایی امن انتخاب کنید. فایل `ghost-release.jks` را در GitHub عمومی آپلود نکنید.

## GitHub Secrets لازم

Settings → Secrets and variables → Actions → New repository secret:

- `GHOST_KEYSTORE_B64`: محتوای Base64 فایل keystore (نه مسیر فایل)
- `GHOST_STORE_PASSWORD`: رمز Keystore
- `GHOST_KEY_ALIAS`: نام alias؛ برای مثال `ghost`
- `GHOST_KEY_PASSWORD`: رمز کلید

تبدیل keystore به Base64 (Linux/macOS):

```bash
base64 < ghost-release.jks | tr -d '\n'
```

در Windows PowerShell:

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes('ghost-release.jks'))
```

محتوا را فقط به Secret منتقل کنید. **هرگز در Pull Request، لاگ یا Issue کپی نکنید.**

## لینک ربات تلگرام

Settings → Secrets and variables → Actions → Variables → New repository variable

- نام: `GHOST_TELEGRAM_BOT_URL`
- مقدار: آدرس واقعی ربات مانند `https://t.me/YOUR_REAL_BOT` (پس از دریافت لینک از صاحب پروژه)

تا وقتی آدرس واقعی ثبت نشود، دکمه خرید پیام تنظیم‌نبودن ربات را نمایش می‌دهد و به لینک ساختگی نمی‌رود.

## به‌روزرسانی نسخه‌های نصب‌شده

باید **هم `applicationId` و هم امضای APK** با نسخه نصب‌شده یکسان باشند. خروجی‌های قبلی GitHub که با Debug Key و شناسه `.dev` ساخته شده‌اند، با Release امضاشده جدید **مستقیماً آپدیت نخواهند شد**. احتمالاً برای نخستین انتقال به نسخه Release نیاز به خروجی گرفتن از تنظیمات، حذف نسخه آزمایشی و نصب مجدد دارید. سپس تا وقتی همین Keystore را نگه دارید و versionCode را افزایش دهید، نسخه‌های آینده روی هم نصب می‌شوند.
