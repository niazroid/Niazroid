import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

/// Supplied at build time, never guessed. Example: https://t.me/MyRealBot
const ghostTelegramBotUrl = String.fromEnvironment('GHOST_TELEGRAM_BOT_URL');

Future<void> openGhostPurchaseBot(BuildContext context) async {
  final url = Uri.tryParse(ghostTelegramBotUrl);
  if (url == null || url.scheme != 'https' || url.host != 't.me' ||
      url.pathSegments.isEmpty || url.pathSegments.first.isEmpty) {
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(const SnackBar(
      content: Text('لینک ربات تلگرام GHOST VPN هنوز ثبت نشده است.'),
      behavior: SnackBarBehavior.floating,
    ));
    return;
  }
  final ok = await launchUrl(url, mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) {
    ScaffoldMessenger.maybeOf(context)?.showSnackBar(const SnackBar(
      content: Text('باز کردن تلگرام انجام نشد. اتصال اینترنت را بررسی کنید.'),
      behavior: SnackBarBehavior.floating,
    ));
  }
}

/// Touch-friendly Flutter rendition of the Telegram button inspiration.
/// The white Telegram icon capsule expands briefly when tapped.
class GhostTelegramPurchaseButton extends StatefulWidget {
  const GhostTelegramPurchaseButton({super.key, required this.label});

  final String label;

  @override
  State<GhostTelegramPurchaseButton> createState() => _GhostTelegramPurchaseButtonState();
}

class _GhostTelegramPurchaseButtonState extends State<GhostTelegramPurchaseButton> {
  bool _pressed = false;

  Future<void> _onTap() async {
    if (_pressed) {
      return;
    }
    setState(() => _pressed = true);
    await Future<void>.delayed(const Duration(milliseconds: 360));
    if (!mounted) {
      return;
    }
    setState(() => _pressed = false);
    await openGhostPurchaseBot(context);
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      final width = constraints.maxWidth;
      return Semantics(
        button: true,
        label: widget.label,
        child: Material(
          color: const Color(0xFF098BD8),
          borderRadius: BorderRadius.circular(14),
          clipBehavior: Clip.antiAlias,
          child: InkWell(
            onTap: _onTap,
            child: SizedBox(
              height: 48,
              width: width,
              child: Stack(children: [
                Center(child: AnimatedDefaultTextStyle(
                  duration: const Duration(milliseconds: 260),
                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold,
                    color: _pressed ? const Color(0xFF086599) : Colors.white),
                  child: Text(widget.label, textAlign: TextAlign.center),
                )),
                Positioned(
                  left: 5,
                  top: 5,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 350),
                    curve: Curves.easeOutCubic,
                    height: 38,
                    width: _pressed ? width - 10 : 38,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(_pressed ? 11 : 24),
                    ),
                    child: const Center(child: Icon(Icons.send_rounded,
                      color: Color(0xFF098BD8), size: 20)),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );
    });
  }
}
