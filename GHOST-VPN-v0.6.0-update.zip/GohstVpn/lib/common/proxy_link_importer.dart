/// Import VLESS share links and base64-encoded VLESS subscriptions locally.
///
/// No third-party conversion service is used: credentials never leave the app
/// except when the user fetches their subscription from its provider.
import 'dart:convert';
import 'dart:typed_data';
import 'package:fl_clash/common/gohst_display_name.dart';

class ProxyLinkImporter {
  static final RegExp _uuidPattern = RegExp(
    r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$',
  );

  static bool isNodeLink(String input) =>
      input.trimLeft().toLowerCase().startsWith('vless://');

  static Uint8List normalize(
    Uint8List bytes, {
    void Function(List<String>)? onWarnings,
  }) {
    String source;
    try {
      source = utf8.decode(bytes, allowMalformed: false).trim().replaceFirst('\uFEFF', '');
    } on FormatException {
      return bytes;
    }
    if (source.isEmpty) return bytes;
    if (source.startsWith('{') || source.startsWith('proxies:') ||
        source.startsWith('proxy-providers:') || source.startsWith('mixed-port:')) {
      return bytes;
    }

    var content = source;
    if (!content.contains('://')) {
      final compact = content.replaceAll(RegExp(r'\s+'), '');
      if (compact.length > 24 && RegExp(r'^[A-Za-z0-9+/=_-]+$').hasMatch(compact)) {
        try {
          final decoded = utf8.decode(base64.decode(base64.normalize(
            compact.replaceAll('-', '+').replaceAll('_', '/'),
          )));
          if (decoded.contains('vless://')) content = decoded.trim();
        } on FormatException {
          // Not a VLESS share-link subscription; leave it to the core.
        }
      }
    }
    if (!content.contains('vless://')) return bytes;

    final links = content.split(RegExp(r'[\r\n]+')).map((line) => line.trim())
        .where((line) => line.isNotEmpty && !line.startsWith('#')).toList();
    if (links.isEmpty || !links.any(isNodeLink)) return bytes;
    final proxies = <Map<String, Object>>[];
    final errors = <String>[];
    final names = <String>{};
    for (final (index, link) in links.indexed) {
      if (!isNodeLink(link)) {
        errors.add('Line ${index + 1}: unsupported protocol');
        continue;
      }
      try {
        final node = _parseVless(link);
        var name = node['name'] as String;
        final original = name;
        var number = 2;
        while (names.contains(name)) {
          name = '$original ($number)';
          number++;
        }
        node['name'] = name;
        names.add(name);
        proxies.add(node);
      } on FormatException catch (error) {
        // Intentionally omit node secrets from exception text and logs.
        errors.add('Line ${index + 1}: ${error.message}');
      }
    }
    if (proxies.isEmpty) {
      throw FormatException('No supported VLESS configurations were found.\n${errors.join('\n')}');
    }
    // Keep valid nodes even when an unrelated line is malformed. Always
    // report the skipped lines to the calling UI; never silently discard them.
    if (errors.isNotEmpty) onWarnings?.call(List.unmodifiable(errors));
    final proxyNames = proxies.map((item) => item['name'] as String).toList();
    final jsonDocument = <String, Object>{
      'mixed-port': 7890,
      'allow-lan': false,
      'mode': 'rule',
      'log-level': 'warning',
      'proxies': proxies,
      'proxy-groups': [
        {'name': 'GHOST VPN', 'type': 'select', 'proxies': [...proxyNames, 'DIRECT']},
      ],
      'rules': ['MATCH,GHOST VPN'],
    };
    // JSON syntax is a valid subset of YAML 1.2, and Mihomo's config parser
    // accepts it. Encoding also escapes arbitrary labels safely.
    return Uint8List.fromList(utf8.encode(jsonEncode(jsonDocument)));
  }

  static Map<String, Object> _parseVless(String link) {
    final uri = Uri.tryParse(link);
    if (uri == null || uri.scheme.toLowerCase() != 'vless') {
      throw const FormatException('invalid VLESS URI');
    }
    final uuid = uri.userInfo;
    if (!_uuidPattern.hasMatch(uuid) || uri.host.isEmpty || uri.port < 1 || uri.port > 65535) {
      throw const FormatException('invalid server, port, or UUID');
    }
    final p = uri.queryParameters;
    final transport = (p['type'] ?? 'tcp').toLowerCase();
    const transports = {'tcp', 'ws', 'grpc', 'http', 'h2', 'xhttp'};
    if (!transports.contains(transport)) {
      throw FormatException('unsupported transport "$transport"');
    }
    if (transport == 'tcp' && (p['headerType'] ?? 'none') != 'none') {
      throw const FormatException('TCP HTTP header camouflage is not translated safely');
    }
    final security = (p['security'] ?? 'none').toLowerCase();
    if (!{'none', '', 'tls', 'reality'}.contains(security)) {
      throw FormatException('unsupported security "$security"');
    }
    final enc = p['encryption'] ?? 'none';
    final name = gohstDisplayName(uri.fragment);
    final result = <String, Object>{
      'name': name.isNotEmpty ? name : '${uri.host}:${uri.port}',
      'type': 'vless',
      'server': uri.host,
      'port': uri.port,
      'uuid': uuid,
      'udp': true,
      'network': transport == 'h2' ? 'h2' : transport,
    };
    if (enc != 'none' && enc.isNotEmpty) result['encryption'] = enc;
    final flow = p['flow'];
    if (flow != null && flow.isNotEmpty) result['flow'] = flow;
    if (security == 'tls' || security == 'reality') {
      result['tls'] = true;
      final sni = p['sni'];
      if (sni != null && sni.isNotEmpty) result['servername'] = sni;
      final fp = p['fp'];
      if (fp != null && fp.isNotEmpty) result['client-fingerprint'] = fp;
      final alpn = p['alpn'];
      if (alpn != null && alpn.isNotEmpty) {
        result['alpn'] = alpn.split(',').where((x) => x.isNotEmpty).toList();
      }
      if (p['insecure'] == '1' || p['allowInsecure'] == '1') {
        result['skip-cert-verify'] = true;
      }
      if (security == 'reality') {
        final pbk = p['pbk'] ?? '';
        if (pbk.isEmpty) throw const FormatException('Reality public key missing');
        result['reality-opts'] = <String, Object>{
          'public-key': pbk,
          if ((p['sid'] ?? '').isNotEmpty) 'short-id': p['sid']!,
        };
      }
      // pcs is the TLS peer certificate SHA256 pin (not a uTLS fingerprint).
      // Only accept the full SHA256 digest; NEVER silently disable TLS checks.
      final pin = p['pcs'];
      if (pin != null && pin.isNotEmpty) {
        if (!RegExp(r'^[0-9a-fA-F]{64}$').hasMatch(pin)) {
          throw const FormatException('invalid certificate pin (pcs)');
        }
        result['fingerprint'] = pin.toUpperCase();
      }
    }
    if (transport == 'ws') {
      result['ws-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'headers': {'Host': p['host']!},
      };
    } else if (transport == 'xhttp') {
      result['xhttp-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'host': p['host']!,
        if ((p['mode'] ?? '') != '' && p['mode'] != 'auto') 'mode': p['mode']!,
      };
    } else if (transport == 'grpc') {
      result['grpc-opts'] = <String, Object>{'grpc-service-name': p['serviceName'] ?? ''};
    } else if (transport == 'h2' || transport == 'http') {
      result['h2-opts'] = <String, Object>{
        'path': p['path'] ?? '/',
        if ((p['host'] ?? '').isNotEmpty) 'host': [p['host']!],
      };
    }
    return result;
  }
}
