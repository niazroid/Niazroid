#!/usr/bin/env bash
set -euo pipefail
MAIN='app/src/main/java/ir/bankmoviee/app/MainActivity.kt'
WF='.github/workflows/build-bankmovie.yml'
[[ -f "$MAIN" && -f "$WF" ]] || { echo VERIFY_V7471_12_2_FILES_MISSING; exit 1; }
python3 - <<'PY2'
from pathlib import Path
s=Path('app/src/main/java/ir/bankmoviee/app/MainActivity.kt').read_text()
mobile_start=s.index('private fun showVipPlansMobileV736(')
tv_start=s.index('private fun showVipPlansDialog(', mobile_start)
mobile=s[mobile_start:tv_start]
assert 'val planRows = mutableListOf<Pair<LinearLayout, JSONObject>>()' in mobile, 'mobile VIP planRows must be Pair'
assert 'planRows += row to plan' in mobile, 'mobile VIP plan row Pair append missing'
assert 'mutableListOf<Triple<LinearLayout, JSONObject, Boolean>>()' not in mobile, 'TV Triple leaked into mobile VIP renderer'

tv_end=s.index('private fun openVipPlanPurchase(', tv_start)
tv=s[tv_start:tv_end]
assert 'val planRows = mutableListOf<Triple<LinearLayout, JSONObject, Boolean>>()' in tv, 'TV VIP planRows Triple missing'
assert 'planRows += Triple(row, plan, featured)' in tv, 'TV VIP Triple append missing'
decl=tv.index('lateinit var refreshPurchase: () -> Unit')
listener=tv.index('refreshPurchase()', decl)
assign=tv.index('refreshPurchase = {', listener)
first_call_after_assign=tv.index('refreshPurchase()', assign)
assert decl < listener < assign < first_call_after_assign, 'TV purchase refresh declaration/assignment order is invalid'
assert "setOnClickListener { selected = plan; refreshRows(); refreshPurchase() }" in tv
print('V7471_12_2_KOTLIN_COMPILE_GUARDS_OK')
PY2
grep -Eq 'Bankmovie-v2\.3-V7\.47\.1\.12\.2-TV-VIP-MOBILE-STYLE-PROFILE-HERO-CLEANUP-KOTLIN-HOTFIX-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.12\.3-UPDATE-VERSIONCODE-HOTFIX-FULLSOURCE\.zip|Bankmovie-v2\.3-V7\.47\.1\.13-DOWNLOAD-META-PATH-RETRY-SETTINGS-FULLSOURCE\.zip' "$WF"
echo VERIFY_V7471_12_2_KOTLIN_COMPILE_HOTFIX_OK
